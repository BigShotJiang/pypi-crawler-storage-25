
    
from dataclasses import dataclass
from typing import Any, Dict

from qlsdk.core.dict_utils import filter_dict_keys
from qlsdk.core.utils import to_bytes
from qlsdk.lse.exception import EStimConfigError
from qlsdk.lse.type import WaveFormEnum


class ParadigmConfig(object):
    def __init__(self, time_stamp, pkg_id, channels, impedance):
        self.time_stamp = time_stamp
        self.pkg_id = pkg_id
        self.channels = channels
        self.impedance = impedance
        
    def parse(json_data: Dict[str, Any]) -> 'ParadigmConfig':
        return ParadigmConfig(
            time_stamp=json_data.get("time_stamp"),
            pkg_id=json_data.get("pkg_id"),
            channels=json_data.get("channels"),
            impedance=json_data.get("impedance")
        )

@dataclass
class EStimBaseConfig:
    anode_channels: list        # 必要参数 电极通道-阳极    
    cathode_channels: list      # 必要参数 电极通道-阴极
    # 电流强度（单位：微安）
    current_intensity: int
    # 是否伪刺激
    sham: bool = None
    # 延迟参数（单位：毫秒）
    delay_ms: int = None 
    # 延迟参数（单位：微秒）
    delay_us: int = None 
    # 刺激时长（单位：毫秒）
    duration: int = None 
    # 刺激上升时长（单位：毫秒）
    ramp_up_ms: int = None 
    # 刺激下降时长（单位：毫秒）
    ramp_down_ms: int = None 
    # 是否循环刺激
    loop: bool = None 
    # 循环刺激次数
    loop_num: int = None 
    # 循环刺激间隔（单位：毫秒）
    loop_interval_ms: int = None 
    wave_form: int = None              # 必要参数 波形类型
    
    def __post_init__(self):  
        if self.wave_form not in WaveFormEnum._value2member_map_:
            raise EStimConfigError(f"无效的波形类型: {self.wave_form}")  
        
        if self.anode_channels is None or self.cathode_channels is None:
            raise EStimConfigError("电极通道不能为空")
        
        if len(self.anode_channels) == 0 or len(self.cathode_channels) == 0:
            raise EStimConfigError("电极通道必须为非负整数")
        
        if self.anode_channels == self.cathode_channels:
            raise EStimConfigError("正极和负极通道不能相同")
        
        # 当前可用通道数1、2、3、4，后续如果设备支持更多通道可以调整此处逻辑
        if len(self.anode_channels) > 4 or len(self.cathode_channels) > 4:
            raise EStimConfigError("电极通道编号不能超过4")
        
        if (self.delay_ms and self.delay_ms < -1) or (self.delay_us and self.delay_us < -1):
            raise EStimConfigError("延迟参数必须为非负整数")
        
        if self.duration is None or self.duration <= 0:
            raise EStimConfigError("刺激时长必须为正整数")
        
        if (self.ramp_up_ms is not None and self.ramp_up_ms < 0) or (self.ramp_down_ms is not None and self.ramp_down_ms < 0):
            raise EStimConfigError("上升/下降时长必须为非负整数")
        
        if self.loop and self.loop_num <= 0:
            raise EStimConfigError("循环刺激次数必须为正整数")
        
        if self.current_intensity is None or self.current_intensity < -25000 or self.current_intensity > 25000:
            raise EStimConfigError("电流强度应在-25000到25000之间")
        
    def to_json(self) -> Dict[str, Any]:
        
        # 通道-阳极
        pos_channels = int.from_bytes(to_bytes(self.anode_channels, 8), byteorder='big')
        # 通道-阴极
        neg_channels = int.from_bytes(to_bytes(self.cathode_channels, 8), byteorder='big')
        
        cfg = {
                "wType": self.wave_form,
                "PosCh": pos_channels,
                "NegCh": neg_channels,
                "IsSham": 1 if self.sham else 0,
                "du_ms": self.duration,
                "isLoop": 1 if self.loop else 0
            }
        
        if self.ramp_up_ms and self.ramp_up_ms >= 0:
            cfg["sm_ms"] = self.ramp_up_ms
        
        if self.ramp_down_ms and self.ramp_down_ms >= 0:
            cfg["do_ms"] = self.ramp_down_ms
        
        if self.delay_ms and self.delay_ms >= 0:
            cfg["dy_ms"] = self.delay_ms
        
        if self.delay_us and self.delay_us >= 0:
            cfg["dy_us"] = self.delay_us   
            
        if self.loop:
            cfg["lpCnt"] = self.loop_num
            cfg["lpIntvl"] = self.loop_interval_ms
         
        return cfg   
    
@dataclass
class tDCSConfig(EStimBaseConfig):
    wave_form: int = WaveFormEnum.tDCS.value  
    def __init__(self, **kwargs):
        super().__init__(**kwargs)    
        
    def to_json(self) -> Dict[str, Any]:
        cfg = super().to_json()
        cfg["amp"] = self.current_intensity
        return cfg
                
@dataclass
class tACSConfig(EStimBaseConfig):    
    frequency: float = None # 频率，单位Hz
    wave_form: int = WaveFormEnum.tACS.value  
    
    def __init__(self, **kwargs):
        self.frequency = kwargs.pop("frequency")
        super().__init__(**kwargs)   
        
    def __post_init__(self):
        if self.frequency is None or self.frequency <0 or self.frequency > 2050:
            raise EStimConfigError("频率必须为正数, 且不超过2050Hz（精度0.1Hz）")
        
        return super().__post_init__()
        
    def to_json(self) -> Dict[str, Any]:
        cfg = super().to_json()
        cfg["amp"] = self.current_intensity
        cfg["freq"] = self.frequency
        return cfg
                
@dataclass
class SquareConfig(EStimBaseConfig):
    frequency: float = None # 频率，单位Hz
    duty_cycle: int = None  # 占空比(0,100] 单位%
    wave_form: int = WaveFormEnum.SQUARE.value  
    def __init__(self, **kwargs):
        self.frequency = kwargs.pop("frequency")
        self.duty_cycle = kwargs.pop("duty_cycle")
        super().__init__(**kwargs)  
        
    def __post_init__(self):
        if self.frequency is None or self.frequency <0 or self.frequency > 1000:
            raise EStimConfigError("频率必须为正数, 且不超过1000Hz（精度0.1Hz）")
        if self.duty_cycle is None or self.duty_cycle <= 0 or self.duty_cycle > 100:
            raise EStimConfigError("占空比必须在(0,100]范围内")
    
    def to_json(self) -> Dict[str, Any]:
        cfg = super().to_json()
        cfg["amp"] = self.current_intensity
        cfg["freq"] = self.frequency
        cfg["dtyCyc"] = self.duty_cycle
        return cfg   
     
@dataclass   
class nCESConfig(EStimBaseConfig):
    wave_form: int = WaveFormEnum.nCES.value  
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
    def to_json(self) -> Dict[str, Any]:
        cfg = super().to_json()
        cfg["amp"] = self.current_intensity
        return cfg
    
class PulseConfig(EStimBaseConfig):
    # 正向脉冲电流
    pos_current: int = None
    # 正向脉冲时间
    pos_pulse_us: int = None
    # 负向脉冲电流
    neg_current: int = None
    # 负向脉冲时间
    neg_pulse_us: int = None
    # 死区时间
    dead_us: int = None
    # 脉冲次数
    pulse_num: int = 1
    # 脉冲间隔
    pulse_interval_us: int = None
    frequency: float = None # 频率，单位Hz
    wave_form: int = WaveFormEnum.PULSE.value  
    
    def __init__(self, **kwargs):
        self.pos_current = kwargs.pop("pos_current")
        self.pos_pulse_us = kwargs.pop("pos_pulse_us")
        self.neg_current = kwargs.pop("neg_current")
        self.neg_pulse_us = kwargs.pop("neg_pulse_us")
        self.dead_us = kwargs.pop("dead_us")
        self.pulse_interval_us = kwargs.pop("pulse_interval_us")
        if kwargs.get("pulse_num") is not None:
            self.pulse_num = kwargs.pop("pulse_num")
        self.frequency = kwargs.pop("frequency")
        kwargs['current_intensity'] = 0
        super().__init__(**kwargs) 
        
    def __post_init__(self):
        if self.frequency is None or self.frequency <0 or self.frequency > 1000:
            raise EStimConfigError("频率必须为正数, 且不超过1000Hz（精度0.1Hz）")
        if self.pos_current is None or self.pos_current < -25000 or self.pos_current > 25000:
            raise EStimConfigError("正向脉冲电流必须在[-25000, 25000]微安范围内")
        if self.neg_current is None or self.neg_current > 25000 or self.neg_current < -25000:
            raise EStimConfigError("负向脉冲电流必须在[-25000, 25000]微安范围内")
        if self.pos_pulse_us is None or self.pos_pulse_us < 0:
            raise EStimConfigError("正向脉冲时间必须为正整数")
        if self.neg_pulse_us is None or self.neg_pulse_us < 0:
            raise EStimConfigError("负向脉冲时间必须为正整数")
        if self.dead_us is None or self.dead_us < 0:
            raise EStimConfigError("死区时间必须为非负整数")
        if self.pulse_interval_us is None or self.pulse_interval_us < 0:
            raise EStimConfigError("脉冲间隔必须为非负整数")
        
    def to_json(self) -> Dict[str, Any]:
        cfg = super().to_json()
        #电流大小
        if self.pos_current is None:
            self.pos_current = abs(self.current_intensity)
        if self.neg_current is None:
            self.neg_current = -abs(self.current_intensity)
                
        cfg["Current"] = self.pos_current 
        cfg["Pulset"] = self.pos_pulse_us
        cfg["nCurrent"] = self.neg_current
        cfg["nPulset"] = self.neg_pulse_us 
        cfg["Deadt"] = self.dead_us 
        cfg["RptCnt"] = self.pulse_num
        cfg["RptIntvl"] = self.pulse_interval_us 
        cfg["WaveFreq"] = self.frequency
            
        return cfg    
        
@dataclass
class RandomNoiseConfig(EStimBaseConfig):
    
    # 随机种子，不能为0
    seed: float = 1
    # 高通截止频率1
    freq_band_high: int = None
    # 低通截止频率1
    freq_band_low: int = None
    # # 高通截止频率2
    # high_freq_2: int = None
    # # 低通截止频率2
    # low_freq_2: int = None
    wave_form: int = WaveFormEnum.RANDOM.value  
    
    def __init__(self, **kwargs):
        self.freq_band_high = kwargs.pop("freq_band_high")
        self.freq_band_low = kwargs.pop("freq_band_low")
        self.seed = kwargs.pop("seed")  
        super().__init__(**kwargs)    
        
    def __post_init__(self):
        if self.freq_band_high is None or self.freq_band_high <= 0:
            raise EStimConfigError("高通截止频率必须为正整数")
        if self.freq_band_low is None or self.freq_band_low <= 0:
            raise EStimConfigError("低通截止频率必须为正整数")
        if self.freq_band_high >= self.freq_band_low:
            raise EStimConfigError("高通截止频率必须小于低通截止频率")
        if self.seed == 0:
            raise EStimConfigError("随机种子不能为0")
        
    def to_json(self) -> Dict[str, Any]:
        cfg = super().to_json()
        cfg["Current"] = self.current_intensity
        cfg["hfp1"] = self.freq_band_high
        cfg["lfp1"] = self.freq_band_low
            
        if self.seed and self.seed > 0:
            cfg["seed"] = self.seed
        return cfg

class EStimConfigFactory:
    @staticmethod
    def create_config(type: int, **kwargs) -> EStimBaseConfig:
        if type == WaveFormEnum.tDCS.value:
            required_keys = {"wave_form", "anode_channels", "cathode_channels", "current_intensity", "sham", "delay_ms", "delay_us", "duration", "ramp_up_ms", "ramp_down_ms", "loop", "loop_num", "loop_interval_ms"}
            params = filter_dict_keys(kwargs, required_keys)
            return tDCSConfig(**params)
        elif type == WaveFormEnum.tACS.value:
            required_keys = {"wave_form", "anode_channels", "cathode_channels", "current_intensity", "sham", "delay_ms", "delay_us", "duration", "ramp_up_ms", "ramp_down_ms", "loop", "loop_num", "loop_interval_ms", "frequency"}
            params = filter_dict_keys(kwargs, required_keys)
            return tACSConfig(**params)
        elif type == WaveFormEnum.SQUARE.value:
            required_keys = {"wave_form", "anode_channels", "cathode_channels", "current_intensity", "sham", "delay_ms", "delay_us", "duration", "ramp_up_ms", "ramp_down_ms", "loop", "loop_num", "loop_interval_ms", "frequency", "duty_cycle"}
            params = filter_dict_keys(kwargs, required_keys)
            return SquareConfig(**params)
        elif type == WaveFormEnum.nCES.value:
            required_keys = {"wave_form", "anode_channels", "cathode_channels", "current_intensity", "sham", "delay_ms", "delay_us", "duration", "ramp_up_ms", "ramp_down_ms", "loop", "loop_num", "loop_interval_ms"}
            params = filter_dict_keys(kwargs, required_keys)
            return nCESConfig(**params)
        elif type == WaveFormEnum.PULSE.value:
            required_keys = {"wave_form", "anode_channels", "cathode_channels", "sham", "delay_ms", "delay_us", "duration", "ramp_up_ms", "ramp_down_ms", "loop", "loop_num", "loop_interval_ms", "pos_current", "pos_pulse_us", "neg_current", "neg_pulse_us", "dead_us", "pulse_num", "pulse_interval_us", "frequency"}
            params = filter_dict_keys(kwargs, required_keys)
            return PulseConfig(**params)
        elif type == WaveFormEnum.RANDOM.value:
            required_keys = {"wave_form", "anode_channels", "cathode_channels", "current_intensity", "sham", "delay_ms", "delay_us", "duration", "ramp_up_ms", "ramp_down_ms", "loop", "loop_num", "loop_interval_ms", "freq_band_max", "freq_band_min", "seed"}
            params = filter_dict_keys(kwargs, required_keys)
            if kwargs.get("freq_band_max"):
                params["freq_band_high"] = params.pop("freq_band_max")
            if kwargs.get("freq_band_min"):
                params["freq_band_low"] = params.pop("freq_band_min")
            return RandomNoiseConfig(**params)
        else:
            raise ValueError(f"Unsupported wave form type: {type}")
        
    @staticmethod
    def from_json(json_data: Dict[str, Any]) -> EStimBaseConfig:
        wave_form = json_data.get("wave_form")
        if wave_form is None:
            raise ValueError("JSON参数缺少必要的波形类型参数: wave_form")
        
        return EStimConfigFactory.create_config(wave_form, **json_data)
        
@dataclass        
class LightSoundStimConfig:
    light_channel: int   # 光刺激通道，[0,4)
    # 光照频率(Hz, 精度：0.1Hz，范围：[0-200])
    light_freq: float
    # 光照占空比(范围：[0-100])
    light_duty_cycle: float
    # 光照强度（lux, 范围：[0-8000])
    light_intensity: float
    # 声音频率(Hz, 精度：0.1Hz，范围：[0-200])
    sound_channel: int   # 声刺激通道，[0,2)
    sound_freq: float
    # 声音占空比(范围：[0-100])
    sound_duty_cycle: float
    # 光刺激启动延迟时间(单位：微秒，精度：1微秒)
    light_delay_us: int = -1
    # 声音刺激启动延迟时间(单位：微秒，精度：1微秒)
    sound_delay_us: int = -1
    # 音频名称
    audio_name: str = 'SIN_WAVE'
    # 音频音量（范围：[0-100])
    audio_volume: float= 30
    # 音频载波频率（仅audio_name=SIN_WAVE时有效，单位：Hz, 精度： 范围：200-10000）
    audio_carrier_freq: float = 10000
    # 持续时长（单位：秒， 精度: 0.001秒）
    duration: float = 0
    linear_amplitude = 32767
    
    def __post_init__(self):
        if self.light_channel is not None:
            if (self.light_channel < 0 or self.light_channel >= 4):
                raise ValueError("光刺激通道必须在[0,4)范围内")
            if self.light_freq < 0 or self.light_freq > 200:
                raise ValueError("光照频率必须在0-200Hz范围内")
            if self.light_duty_cycle < 0 or self.light_duty_cycle > 100:
                raise ValueError("光照占空比必须在0-100范围内")
            if self.light_intensity < 0 or self.light_intensity > 8000:
                raise ValueError("光照强度必须在0-8000 lux范围内")
            
        if self.sound_channel is not None:
            if (self.sound_channel < 0 or self.sound_channel >= 2):
                raise ValueError("声刺激通道必须在[0,2)范围内")
            if self.sound_freq < 0 or self.sound_freq > 200:
                raise ValueError("声音频率必须在0-200Hz范围内")
            if self.sound_duty_cycle < 0 or self.sound_duty_cycle > 100:
                raise ValueError("声音占空比必须在0-100范围内")
            if self.audio_volume < 0 or self.audio_volume > 100:
                raise ValueError("音频音量必须在0-100范围内")
        if self.audio_name == 'SIN_WAVE':
            if self.audio_carrier_freq < 200 or self.audio_carrier_freq > 10000:
                raise ValueError("音频载波频率必须在200-10000Hz范围内")
        if self.duration < 0:
            raise ValueError("持续时长必须为非负数")
        if self.linear_amplitude is not None and (self.linear_amplitude < 0 or self.linear_amplitude > 32767):
            raise ValueError("线性幅值必须在0-32767范围内")
        
    def to_json(self) -> Dict[str, Any]:
        cfg =  {
            "duration_s": self.duration,
            "Audio": "NONE\x00",
        }    
        
        if self.audio_name is not None:
            if self.sound_channel is None:
                self.sound_channel = 0
            cfg["Ach"] = self.sound_channel
            cfg["Audio"] = self.audio_name
            cfg["Avolume"] = self.audio_volume
            cfg["Afreq"] = self.sound_freq
            cfg["Aduty"] = self.sound_duty_cycle
            cfg["Ady_us"] = self.sound_delay_us
            cfg["ABaseAmp"] = self.linear_amplitude
            
        if self.audio_name == 'SIN_WAVE':
            cfg["ABaseFreq"] = self.audio_carrier_freq
            
        if self.light_intensity is not None:
            if self.light_channel is None:
                self.light_channel = 0
            cfg['Lch'] = self.light_channel
            cfg['Lfreq'] = self.light_freq
            cfg['Lintensity'] = self.light_intensity
            cfg['Lduty'] = self.light_duty_cycle   
            cfg['Ldy_us'] = self.light_delay_us 
        
        return cfg