from enum import IntEnum


class ResultCodeEnum(IntEnum):
    OK = 0x00                   #指令执行成功
    Fail = 0x01                 #指令执行失败
    Busy = 0x02                 #繁忙中，指令未执行
    Invalid_Parameter = 0x03    #指令参数无效
    Unknown_Command = 0x04      #未知指令
    Error_Format = 0x05         #指令错误格式
    Timeout = 0xFF              #指令执行超时
    
    
RESULT_DESC: dict[ResultCodeEnum, str] = {
    ResultCodeEnum.OK: "成功",
    ResultCodeEnum.Fail: "失败",
    ResultCodeEnum.Busy: "设备繁忙",
    ResultCodeEnum.Invalid_Parameter: "参数无效",
    ResultCodeEnum.Unknown_Command: "指令无效",
    ResultCodeEnum.Error_Format: "格式错误",
    ResultCodeEnum.Timeout: "超时"
}    