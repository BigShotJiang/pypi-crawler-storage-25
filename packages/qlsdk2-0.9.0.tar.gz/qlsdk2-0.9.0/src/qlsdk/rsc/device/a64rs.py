from datetime import datetime
from loguru import logger
from qlsdk.core.entity import ImpedancePacket, RscPacket
from qlsdk.persist import RscEDFHandler
from qlsdk.persist.trigger_log import TriggerFile
from qlsdk.rsc.command import StartStimulationCommand, TriggerOutCommand
from qlsdk.rsc.device.base import QLBaseDevice, intersection_positions
from qlsdk.rsc.device.device_factory import DeviceFactory
from qlsdk.rsc.interface import IDevice
from qlsdk.rsc.device.base import QLBaseDevice

class A64RS(QLBaseDevice):
    
    device_type = 0x33  # A64RS设备类型标识符 0x33
    # 合法通道列表（1-64）
    all_channels = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64]
    
    def __init__(self, socket):
        super().__init__(socket)  
    
    @classmethod
    def from_parent(cls, parent:IDevice) -> IDevice:
        rlt = cls(parent.socket)
        rlt.device_id = parent.device_id
        rlt._device_no = parent.device_no
        return rlt        
        
    def init_edf_handler(self):
        self._edf_handler = RscEDFHandler(self.sample_rate,  self.sample_range * 1000 , - self.sample_range * 1000, self.resolution)  
        self._edf_handler.set_device_type(self.device_type)
        self._edf_handler.set_device_no(self.device_no)
        self._edf_handler.set_storage_path(self._storage_path)
        self._edf_handler.set_file_prefix(self._file_prefix if self._file_prefix else 'A64RS')
        logger.debug(f"EDF Handler initialized")
        
    # 设置采集参数
    def set_acq_param(self, channels:list, sample_rate: int = 500, sample_range:int = 188):
        # 通道合法性校验
        self._channel_validate(channels)
        # 保存原始通道参数
        self._acq_param["original_channels"] = channels
                
        # 更新采集参数
        self._acq_param["channels"] = channels
        self._acq_param["sample_rate"] = sample_rate
        self._acq_param["sample_range"] = sample_range
        self._acq_channels = channels
        self._sample_rate = sample_rate
        self._sample_range = sample_range
        
        logger.debug(f"A64RS: set_acq_param: {self._acq_param}")   
        
        # 参数改变后，重置通道位置映射
        self._reverse_ch_pos  = None  
    
    @property
    def acq_channels(self):
        if self._acq_channels is None:
            # 初始化通道参数为1-11
            self.set_acq_param(A64RS.all_channels)
        return self._acq_channels  
    
    def set_impedance_channels(self, channels:list):
        # 通道合法性校验
        self._channel_validate(channels)
        # 保存原始通道参数
        self._impedance_channels_origin = channels
        self._impedance_channels = channels
        
        # 初始化位置映射
        self._impedance_ch_pos  = None  
        
    def get_impedance_channels(self): 
        if self._impedance_channels is None or len(self._impedance_channels) == 0:
            self.set_impedance_channels(A64RS.all_channels)
        return self._impedance_channels   
    
    def _channel_validate(self, channels: list):
        # 重复通道校验
        if len(channels) != len(set(channels)):
            raise ValueError(f"通道参数有误，存在重复通道: {channels}")
        
        # 通道范围校验
        if len(set(channels) - set(A64RS.all_channels)) > 0:
                raise ValueError(f"通道参数有误，本设备支持通道{A64RS.all_channels}，但传入的通道参数为: {channels}")
    
    def _impedance_wrapper(self, body: bytes):        
        packet = ImpedancePacket().transfer(body)   
        impedance_channels = self.get_impedance_channels() 
        if impedance_channels is not None and len(impedance_channels) > 0:
            # 只保留设置的阻抗通道
            channel_pos = intersection_positions(packet.channels, impedance_channels)
            packet.impedance = [packet.impedance[i] for i in channel_pos]
            packet.channels = [packet.channels[i] for i in channel_pos]
            
        # 升级为类变量，减少计算
        if self._impedance_ch_pos is None:
            self._impedance_ch_pos = map_indices(impedance_channels, packet.channels)
            
        packet.channels = self._impedance_channels_origin
        packet.impedance = [packet.impedance[i] for i in self._impedance_ch_pos]
            
        return packet
    
    # 信号数据转换(默认不处理)
    def _signal_wrapper(self, body: bytes):
        if body is None:
            return
        data = RscPacket().transfer(body)
        
        # 升级为类变量，减少计算
        if self._reverse_ch_pos is None:
            self._reverse_ch_pos = map_indices(self._acq_param["channels"], data.channels)
        
        # 更新通道（数据）顺序和输入一致
        data.channels = self._acq_param["original_channels"]
        data.eeg = [data.eeg[i] for i in self._reverse_ch_pos]
        
        return data
        
    def get_stim_param(self) -> bytes:
        return self.stim_paradigm.to_bytes_a64()
    def start_stimulation(self):
        if self.stim_paradigm is None:
            logger.warning("刺激参数未设置，请先设置刺激参数")
            return
        logger.info(f"[设备-{self.device_no}]启动电刺激")  
        msg = StartStimulationCommand.build(self).pack()
        # logger.debug(f"start_stimulation message is {msg.hex()}")
        self.socket.sendall(msg)
        # t = Thread(target=self._stop_stimulation_trigger, args=(self.stim_paradigm.duration,), daemon=True)
        # t.start()
        if self.trigger_file is None:
            super()._init_trigger_file()
            
        self.trigger_file.add_record("start stimulation")
        
    def trigger_out(self):
        msg = TriggerOutCommand.build(self).pack()
        self.socket.sendall(msg)
        self.trigger("trigger out")
        
def map_indices(A, B):
    """
    
    参数:
        A: 源数组（无重复值）
        B: 目标数组（无重复值）
    
    返回:
        C: 与A长度相同的数组，元素为A中对应值在B中的索引（不存在则为-1）
    """
    # 创建B的值到索引的映射字典（O(n)操作）
    b_map = {value: idx for idx, value in enumerate(B)}
    
    # 遍历A，获取每个元素在B中的位置（O(m)操作）
    return [b_map.get(a, -1) for a in A]

# 注册A64RS设备到DeviceFactory
DeviceFactory.register(A64RS.device_type, A64RS) 