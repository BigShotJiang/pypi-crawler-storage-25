from dataclasses import dataclass
from datetime import datetime
from enum import IntEnum
from multiprocessing import Lock
import os
from loguru import logger


class EventType(IntEnum):
    """事件类型枚举"""
    CONNECTED = 1
    START_IMPEDANCE_MEASURE = 2
    STOP_IMPEDANCE_MEASURE = 3
    START_ACQUISITION = 4
    STOP_ACQUISITION = 5
    START_STIMULATION = 6
    STOP_STIMULATION = 7
    STIMULATION_STOP = 8
    CUSTOM = 100

@dataclass
class TriggerRecord:
    event_description: str
    event_type: int = 0
    device_time: int = 0
    
    def to_csv_line(self) -> str:
        """转换为CSV格式的行"""
        # 转义逗号和换行符
        description = self.event_description.replace(',', '，').replace('\n', '\\n').replace('\r', '\\r')
        cur_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
        return f"{cur_time},{self.device_time},{self.event_type},{description}"
    
class TriggerFile():
    def __init__(self, 
            log_file: str = "trigger_log.csv", 
            max_file_size: int = 10 * 1024 * 1024,  # 10MB
            backup_count: int = 5):
        self.log_file = log_file
        self.max_file_size = max_file_size
        self.backup_count = backup_count
        self.lock = Lock()  # 线程安全锁
        
        # 确保目录存在
        os.makedirs(os.path.dirname(os.path.abspath(log_file)), exist_ok=True)
        
        # 初始化日志文件
        self._init_log_file()
        
        # logger.info(f"TriggerLogger 初始化完成，日志文件: {os.path.abspath(log_file)}")
    
    def _init_log_file(self):
        """初始化日志文件，添加表头"""
        if not os.path.exists(self.log_file):
            with self.lock:
                with open(self.log_file, 'w', encoding='utf-8') as f:
                    # 写入CSV表头
                    f.write("系统时间(YYYY-MM-DD HH:MM:SS.ffffff),设备时间戳(毫秒),事件类型编码,事件描述\n")
            # logger.info(f"创建新的日志文件: {self.log_file}")
        
    def add_record(self, 
                   event_description: str,
                   device_time: int = 0, 
                   event_type: int = 0) -> bool:
        
        try:            
            record = TriggerRecord(
                device_time=device_time,
                event_type=event_type,
                event_description=event_description
            )
            
            # 写入文件
            with self.lock:
                with open(self.log_file, 'a', encoding='utf-8') as f:
                    f.write(record.to_csv_line() + '\n')
            
            # logger.debug(f"记录添加成功: {record}")
            return True
            
        except IOError as e:
            logger.error(f"添加Trigger失败: {e}")
            return False
        except Exception as e:
            logger.error(f"添加Trigger异常: {e}")
            return False