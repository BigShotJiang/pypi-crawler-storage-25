def filter_dict_keys(source_dict: dict, keys_to_keep: set) -> dict:
    """
    从源字典中提取指定key集合
    
    Args:
        source_dict: 源字典，key不固定
        keys_to_keep: 要保留的key集合
    
    Returns:
        只包含指定key的新字典
    """
    return {k: v for k, v in source_dict.items() if k in keys_to_keep}