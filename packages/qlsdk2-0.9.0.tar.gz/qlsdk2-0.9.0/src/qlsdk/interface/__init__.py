from .parser import IParser

from .device import IDevice


'''
    设备消息解析器
'''
class DeviceMessageParser:
    pass