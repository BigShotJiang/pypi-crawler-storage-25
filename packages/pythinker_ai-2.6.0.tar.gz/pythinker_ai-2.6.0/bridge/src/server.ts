/**
 * WebSocket server for Python-Node.js bridge communication.
 * Security: binds to 127.0.0.1 only; requires BRIDGE_TOKEN auth; rejects browser Origin headers.
 */

import { WebSocketServer, WebSocket } from 'ws';
import { WhatsAppClient, InboundMessage } from './whatsapp.js';

interface SendCommand {
  type: 'send';
  to: string;
  text: string;
}

interface SendMediaCommand {
  type: 'send_media';
  to: string;
  filePath: string;
  mimetype: string;
  caption?: string;
  fileName?: string;
}

const PRESENCE_STATES = new Set(['available', 'unavailable', 'composing', 'recording', 'paused']);

interface PresenceCommand {
  type: 'presence';
  to?: string;
  state: 'available' | 'unavailable' | 'composing' | 'recording' | 'paused';
}

interface ReadCommand {
  type: 'read';
  keys: Array<{ remoteJid: string; id: string; fromMe?: boolean }>;
}

type BridgeCommand = SendCommand | SendMediaCommand | PresenceCommand | ReadCommand;

export interface SocketTuning {
  keepAliveIntervalMs?: number;
  connectTimeoutMs?: number;
  defaultQueryTimeoutMs?: number;
}

interface BridgeMessage {
  type: 'message' | 'status' | 'qr' | 'error';
  [key: string]: unknown;
}

export class BridgeServer {
  private wss: WebSocketServer | null = null;
  private wa: WhatsAppClient | null = null;
  private clients: Set<WebSocket> = new Set();

  constructor(
    private port: number,
    private authDir: string,
    private token: string,
    private pairingPhone?: string,
    private tuning: SocketTuning = {},
  ) {}

  async start(): Promise<void> {
    if (!this.token.trim()) {
      throw new Error('BRIDGE_TOKEN is required');
    }

    this.wss = await this.bindWebSocketServer();
    console.log(`🌉 Bridge server listening on ws://127.0.0.1:${this.port}`);
    console.log('🔒 Token authentication enabled');

    // Initialize WhatsApp client
    this.wa = new WhatsAppClient({
      authDir: this.authDir,
      pairingPhone: this.pairingPhone,
      keepAliveIntervalMs: this.tuning.keepAliveIntervalMs,
      connectTimeoutMs: this.tuning.connectTimeoutMs,
      defaultQueryTimeoutMs: this.tuning.defaultQueryTimeoutMs,
      onMessage: (msg) => this.broadcast({ type: 'message', ...msg }),
      onQR: (qr) => this.broadcast({ type: 'qr', qr }),
      onStatus: (status) => this.broadcast({ type: 'status', status }),
    });

    // Handle WebSocket connections
    this.wss.on('connection', (ws) => {
      // Require auth handshake as first message
      const timeout = setTimeout(() => ws.close(4001, 'Auth timeout'), 5000);
      ws.once('message', (data) => {
        clearTimeout(timeout);
        try {
          const msg = JSON.parse(data.toString());
          if (msg.type === 'auth' && msg.token === this.token) {
            console.log('🔗 Python client authenticated');
            this.setupClient(ws);
          } else {
            ws.close(4003, 'Invalid token');
          }
        } catch {
          ws.close(4003, 'Invalid auth message');
        }
      });
    });

    // Connect to WhatsApp
    await this.wa.connect();
  }

  private bindWebSocketServer(): Promise<WebSocketServer> {
    // Bind to localhost only — never expose to external network.
    const server = new WebSocketServer({
      host: '127.0.0.1',
      port: this.port,
      verifyClient: (info, done) => {
        const origin = info.origin || info.req.headers.origin;
        if (origin) {
          console.warn(`Rejected WebSocket connection with Origin header: ${origin}`);
          done(false, 403, 'Browser-originated WebSocket connections are not allowed');
          return;
        }
        done(true);
      },
    });

    return new Promise((resolve, reject) => {
      const cleanup = () => {
        server.off('error', onError);
        server.off('listening', onListening);
      };
      const onError = (error: Error) => {
        cleanup();
        server.close();
        reject(this.describeListenError(error));
      };
      const onListening = () => {
        cleanup();
        server.on('error', (error) => {
          console.error('Bridge WebSocket server error:', this.describeListenError(error));
        });
        resolve(server);
      };
      server.once('error', onError);
      server.once('listening', onListening);
    });
  }

  private describeListenError(error: Error): Error {
    const err = error as NodeJS.ErrnoException;
    if (err.code === 'EADDRINUSE') {
      return new Error(
        `WhatsApp bridge port ${this.port} is already in use on 127.0.0.1. `
        + 'Stop the existing bridge process, or start this bridge with a different BRIDGE_PORT.',
      );
    }
    return error;
  }

  private setupClient(ws: WebSocket): void {
    this.clients.add(ws);

    ws.on('message', async (data) => {
      try {
        const cmd = JSON.parse(data.toString()) as BridgeCommand;
        await this.handleCommand(cmd);
        const ackTo = 'to' in cmd ? cmd.to : undefined;
        ws.send(JSON.stringify({ type: 'sent', to: ackTo }));
      } catch (error) {
        console.error('Error handling command:', error);
        ws.send(JSON.stringify({ type: 'error', error: String(error) }));
      }
    });

    ws.on('close', () => {
      console.log('🔌 Python client disconnected');
      this.clients.delete(ws);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      this.clients.delete(ws);
    });
  }

  private async handleCommand(cmd: BridgeCommand): Promise<void> {
    if (!this.wa) return;

    if (cmd.type === 'send') {
      await this.wa.sendMessage(cmd.to, cmd.text);
    } else if (cmd.type === 'send_media') {
      await this.wa.sendMedia(cmd.to, cmd.filePath, cmd.mimetype, cmd.caption, cmd.fileName);
    } else if (cmd.type === 'presence') {
      if (!PRESENCE_STATES.has(cmd.state)) {
        throw new Error(`Invalid presence state: ${String(cmd.state)}`);
      }
      await this.wa.setPresence(cmd.to, cmd.state);
    } else if (cmd.type === 'read') {
      if (!Array.isArray(cmd.keys)) {
        throw new Error('read command requires keys[]');
      }
      await this.wa.sendReadReceipt(cmd.keys);
    }
  }

  private broadcast(msg: BridgeMessage): void {
    const data = JSON.stringify(msg);
    for (const client of this.clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    }
  }

  async stop(): Promise<void> {
    // Close all client connections
    for (const client of this.clients) {
      client.close();
    }
    this.clients.clear();

    // Close WebSocket server
    if (this.wss) {
      this.wss.close();
      this.wss = null;
    }

    // Disconnect WhatsApp
    if (this.wa) {
      await this.wa.disconnect();
      this.wa = null;
    }
  }
}
