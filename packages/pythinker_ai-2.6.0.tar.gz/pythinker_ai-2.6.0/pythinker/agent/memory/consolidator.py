"""Consolidator: lightweight token-budget triggered consolidation."""

from __future__ import annotations

import asyncio
import weakref
from datetime import datetime
from typing import TYPE_CHECKING, Any, Callable

from loguru import logger

# Import the package itself, not the symbol, so test monkeypatches against
# `pythinker.agent.memory.estimate_message_tokens` are observed at call time.
# (Tests in tests/agent/test_loop_consolidation_tokens.py rely on this.)
from pythinker.agent import memory as _memory_pkg
from pythinker.agent.budget import BudgetPolicy
from pythinker.agent.memory.store import MemoryStore
from pythinker.utils.helpers import async_estimate_prompt_tokens_chain, estimate_prompt_tokens_chain
from pythinker.utils.prompt_templates import render_template

if TYPE_CHECKING:
    from pythinker.providers.base import LLMProvider
    from pythinker.session.manager import Session, SessionManager


class Consolidator:
    """Lightweight consolidation: summarizes evicted messages into history.jsonl."""

    _MAX_CONSOLIDATION_ROUNDS = 5
    _MAX_CHUNK_MESSAGES = 60  # hard cap per consolidation round

    _SAFETY_BUFFER = 1024  # extra headroom for tokenizer estimation drift

    def __init__(
        self,
        store: MemoryStore,
        provider: LLMProvider,
        model: str,
        sessions: SessionManager,
        context_window_tokens: int,
        build_messages: Callable[..., list[dict[str, Any]]],
        get_tool_definitions: Callable[[], list[dict[str, Any]]],
        max_completion_tokens: int = 4096,
        encoding: str = "cl100k_base",
    ):
        self.store = store
        self.provider = provider
        self.model = model
        self.sessions = sessions
        self.context_window_tokens = context_window_tokens
        self.max_completion_tokens = max_completion_tokens
        self.encoding = encoding
        self._build_messages = build_messages
        self._get_tool_definitions = get_tool_definitions
        self._locks: weakref.WeakValueDictionary[str, asyncio.Lock] = (
            weakref.WeakValueDictionary()
        )

    def set_provider(
        self,
        provider: LLMProvider,
        model: str,
        context_window_tokens: int,
        encoding: str = "cl100k_base",
    ) -> None:
        """Hot-swap provider+model+context-window. Called from
        AgentLoop._apply_provider_snapshot. ``max_completion_tokens`` follows
        the new provider's GenerationSettings."""
        self.provider = provider
        self.model = model
        self.context_window_tokens = context_window_tokens
        self.max_completion_tokens = provider.generation.max_tokens
        self.encoding = encoding

    @property
    def policy(self) -> BudgetPolicy:
        """Return token budget zones for this consolidator's model settings."""
        return BudgetPolicy.for_model(
            window=self.context_window_tokens,
            output_reserve=self.max_completion_tokens,
        )

    def get_lock(self, session_key: str) -> asyncio.Lock:
        """Return the shared consolidation lock for one session."""
        return self._locks.setdefault(session_key, asyncio.Lock())

    def pick_consolidation_boundary(
        self,
        session: Session,
        tokens_to_remove: int,
    ) -> tuple[int, int] | None:
        """Pick a user-turn boundary that removes enough old prompt tokens."""
        start = session.last_consolidated
        if start >= len(session.messages) or tokens_to_remove <= 0:
            return None

        removed_tokens = 0
        last_boundary: tuple[int, int] | None = None
        for idx in range(start, len(session.messages)):
            message = session.messages[idx]
            if idx > start and message.get("role") == "user":
                last_boundary = (idx, removed_tokens)
                if removed_tokens >= tokens_to_remove:
                    return last_boundary
            removed_tokens += _memory_pkg.estimate_message_tokens(message)

        return last_boundary

    def pick_consolidation_boundary_relaxed(
        self,
        session: Session,
        tokens_to_remove: int,
    ) -> tuple[int, int] | None:
        """Fallback picker for when no user-turn boundary exists in the tail."""
        start = session.last_consolidated
        if start >= len(session.messages) or tokens_to_remove <= 0:
            return None

        strict = self.pick_consolidation_boundary(session, tokens_to_remove)
        if strict is not None:
            return strict

        removed_tokens = 0
        for idx in range(start, len(session.messages)):
            message = session.messages[idx]
            removed_tokens += _memory_pkg.estimate_message_tokens(message)
            if idx == start:
                continue
            if message.get("role") == "assistant" and not message.get("tool_calls"):
                return idx, removed_tokens

        return len(session.messages), removed_tokens

    def _cap_consolidation_boundary(
        self,
        session: Session,
        end_idx: int,
    ) -> int | None:
        """Clamp the chunk size without breaking the user-turn boundary."""
        start = session.last_consolidated
        if end_idx - start <= self._MAX_CHUNK_MESSAGES:
            return end_idx

        capped_end = start + self._MAX_CHUNK_MESSAGES
        for idx in range(capped_end, start, -1):
            if session.messages[idx].get("role") == "user":
                return idx
        return None

    def estimate_session_prompt_tokens(
        self,
        session: Session,
        *,
        session_summary: str | None = None,
        current_message: str = "[token-probe]",
    ) -> tuple[int, str]:
        """Estimate current prompt size for the normal session history view."""
        history = session.get_history(max_messages=0)
        channel, chat_id = (session.key.split(":", 1) if ":" in session.key else (None, None))
        probe_messages = self._build_messages(
            history=history,
            current_message=current_message,
            channel=channel,
            chat_id=chat_id,
            session_summary=session_summary,
        )
        return estimate_prompt_tokens_chain(
            self.provider,
            self.model,
            probe_messages,
            self._get_tool_definitions(),
            encoding=self.encoding,
        )

    async def async_estimate_session_prompt_tokens(
        self,
        session: Session,
        *,
        session_summary: str | None = None,
        current_message: str = "[token-probe]",
    ) -> tuple[int, str]:
        """Async prompt estimate for consolidation, using provider counters when available."""
        if "estimate_session_prompt_tokens" in self.__dict__:
            try:
                return self.estimate_session_prompt_tokens(
                    session,
                    session_summary=session_summary,
                    current_message=current_message,
                )
            except TypeError:
                return self.estimate_session_prompt_tokens(
                    session,
                    session_summary=session_summary,
                )
        history = session.get_history(max_messages=0)
        channel, chat_id = (session.key.split(":", 1) if ":" in session.key else (None, None))
        probe_messages = self._build_messages(
            history=history,
            current_message=current_message,
            channel=channel,
            chat_id=chat_id,
            session_summary=session_summary,
        )
        return await async_estimate_prompt_tokens_chain(
            self.provider,
            self.model,
            probe_messages,
            self._get_tool_definitions(),
            encoding=self.encoding,
        )

    async def archive(self, messages: list[dict]) -> str | None:
        """Summarize messages via LLM and append to history.jsonl.

        Returns the summary text on success, None if nothing to archive.
        """
        if not messages:
            return None
        try:
            formatted = MemoryStore._format_messages(messages)
            response = await self.provider.chat_with_retry(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": render_template(
                            "agent/consolidator_archive.md",
                            strip=True,
                        ),
                    },
                    {"role": "user", "content": formatted},
                ],
                tools=None,
                tool_choice=None,
            )
            if response.finish_reason == "error":
                raise RuntimeError(f"LLM returned error: {response.content}")
            summary = response.content or "[no summary]"
            self.store.append_history(summary)
            return summary
        except Exception:
            logger.warning("Consolidation LLM call failed, raw-dumping to history")
            self.store.raw_archive(messages)
            return None

    async def maybe_consolidate_by_tokens(
        self,
        session: Session,
        *,
        session_summary: str | None = None,
        current_message: str | None = None,
    ) -> None:
        """Loop: archive old messages until prompt fits within safe budget.

        The budget reserves space for completion tokens and a safety buffer
        so the LLM request never exceeds the context window.
        """
        if self.context_window_tokens <= 0:
            return

        lock = self.get_lock(session.key)
        async with lock:
            # Refresh session reference: AutoCompact.compact_idle_session may
            # have replaced messages on disk while this call was waiting on
            # the lock. Re-read so we don't archive a stale tail.
            fresh = self.sessions.get_or_create(session.key)
            if fresh is not session:
                session = fresh
            if not session.messages:
                return
            policy = self.policy
            budget = policy.soft
            target = policy.target
            try:
                estimated, source = await self.async_estimate_session_prompt_tokens(
                    session,
                    session_summary=session_summary,
                    current_message=current_message or "[token-probe]",
                )
            except Exception:
                logger.exception("Token estimation failed for {}", session.key)
                estimated, source = 0, "error"
            if estimated <= 0:
                return
            if estimated < budget:
                unconsolidated_count = len(session.messages) - session.last_consolidated
                logger.debug(
                    "Token consolidation idle {}: {}/{} via {}, msgs={}",
                    session.key,
                    estimated,
                    self.context_window_tokens,
                    source,
                    unconsolidated_count,
                )
                return

            last_summary = None
            for round_num in range(self._MAX_CONSOLIDATION_ROUNDS):
                if estimated <= target:
                    break

                boundary = self.pick_consolidation_boundary_relaxed(
                    session,
                    max(1, estimated - target),
                )
                if boundary is None:
                    logger.debug(
                        "Token consolidation: no safe boundary for {} (round {})",
                        session.key,
                        round_num,
                    )
                    break

                end_idx = boundary[0]
                end_idx = self._cap_consolidation_boundary(session, end_idx)
                if end_idx is None:
                    logger.debug(
                        "Token consolidation: no capped boundary for {} (round {})",
                        session.key,
                        round_num,
                    )
                    break

                chunk = session.messages[session.last_consolidated:end_idx]
                if not chunk:
                    break

                logger.info(
                    "Token consolidation round {} for {}: {}/{} via {}, chunk={} msgs",
                    round_num,
                    session.key,
                    estimated,
                    self.context_window_tokens,
                    source,
                    len(chunk),
                )
                summary = await self.archive(chunk)
                if summary:
                    last_summary = summary
                else:
                    break
                session.last_consolidated = end_idx
                self.sessions.save(session)

                try:
                    estimated, source = await self.async_estimate_session_prompt_tokens(
                        session,
                        session_summary=session_summary,
                        current_message=current_message or "[token-probe]",
                    )
                except Exception:
                    logger.exception("Token estimation failed for {}", session.key)
                    estimated, source = 0, "error"
                if estimated <= 0:
                    break

            # Persist the last summary to session metadata so it can be injected
            # into the runtime context on the next prepare_session() call, aligning
            # the summary injection strategy with AutoCompact._archive().
            if last_summary and last_summary != "(nothing)":
                session.metadata["_last_summary"] = {
                    "text": last_summary,
                    "last_active": session.updated_at.isoformat(),
                }
                self.sessions.save(session)

    async def compact_idle_session(
        self,
        session_key: str,
        max_suffix: int = 8,
    ) -> str | None:
        """Hard-truncate an idle session under the consolidation lock.

        Single lock-protected path used by AutoCompact so background token
        consolidation and idle TTL compaction can't race on the same session.

        Returns the summary text on success, ``None`` if the LLM failed
        (``archive()`` fell back to raw_archive), or ``""`` if there was
        nothing to archive.
        """
        from pythinker.session.manager import Session

        lock = self.get_lock(session_key)
        async with lock:
            self.sessions.invalidate(session_key)
            session = self.sessions.get_or_create(session_key)

            tail = list(session.messages[session.last_consolidated:])
            if not tail:
                session.updated_at = datetime.now()
                self.sessions.save(session)
                return ""

            probe = Session(
                key=session.key,
                messages=tail.copy(),
                created_at=session.created_at,
                updated_at=session.updated_at,
                metadata={},
                last_consolidated=0,
            )
            probe.retain_recent_legal_suffix(max_suffix)
            kept = probe.messages
            cut = len(tail) - len(kept)
            archive_msgs = tail[:cut]

            if not archive_msgs and not kept:
                session.updated_at = datetime.now()
                self.sessions.save(session)
                return ""

            last_active = session.updated_at
            summary: str | None = ""
            if archive_msgs:
                summary = await self.archive(archive_msgs)

            if summary and summary != "(nothing)":
                session.metadata["_last_summary"] = {
                    "text": summary,
                    "last_active": last_active.isoformat(),
                }

            session.messages = kept
            session.last_consolidated = 0
            session.updated_at = datetime.now()
            self.sessions.save(session)

            if archive_msgs:
                logger.info(
                    "Idle-session compact for {}: archived={}, kept={}, summary={}",
                    session_key,
                    len(archive_msgs),
                    len(kept),
                    bool(summary),
                )

            return summary
