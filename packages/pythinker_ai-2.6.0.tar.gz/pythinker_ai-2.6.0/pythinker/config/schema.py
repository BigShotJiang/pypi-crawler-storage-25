"""Configuration schema using Pydantic."""

from pathlib import Path
from typing import Any, Literal

from pydantic import AliasChoices, BaseModel, ConfigDict, Field, model_validator
from pydantic.alias_generators import to_camel
from pydantic_settings import BaseSettings

from pythinker.cron.types import CronSchedule


class Base(BaseModel):
    """Base model that accepts both camelCase and snake_case keys."""

    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)

class ChannelsConfig(Base):
    """Configuration for chat channels.

    Built-in and plugin channel configs are stored as extra fields (dicts).
    Each channel parses its own config in __init__.
    Per-channel "streaming": true enables streaming output (requires send_delta impl).
    """

    model_config = ConfigDict(extra="allow")

    send_progress: bool = True  # stream agent's text progress to the channel
    send_tool_hints: bool = False  # stream tool-call hints (e.g. read_file("…"))
    send_max_retries: int = Field(default=3, ge=0, le=10)  # Max delivery attempts (initial send included)
    transcription_provider: str = "groq"  # Voice transcription backend: "groq" or "openai"
    transcription_language: str | None = Field(default=None, pattern=r"^[a-z]{2,3}$")  # Optional ISO-639-1 hint for audio transcription


class DreamConfig(Base):
    """Dream memory consolidation configuration."""

    _HOUR_MS = 3_600_000

    interval_h: int = Field(default=2, ge=1)  # Every 2 hours by default
    cron: str | None = Field(default=None, exclude=True)  # Legacy compatibility override
    model_override: str | None = Field(
        default=None,
        validation_alias=AliasChoices("modelOverride", "model", "model_override"),
    )  # Optional Dream-specific model override
    max_batch_size: int = Field(default=20, ge=1)  # Max history entries per run
    # Bumped from 10 to 15 in #3212 (exp002: +30% dedup, no accuracy loss; >15 plateaus).
    max_iterations: int = Field(default=15, ge=1)  # Max tool calls per Phase 2
    # Per-line git-blame age annotation in Phase 1 prompt (see #3212). Default
    # on — set to False to feed MEMORY.md raw if a specific LLM reacts poorly
    # to the `← Nd` suffix or you want deterministic, git-independent prompts.
    annotate_line_ages: bool = True

    def build_schedule(self, timezone: str) -> CronSchedule:
        """Build the runtime schedule, preferring the legacy cron override if present."""
        if self.cron:
            return CronSchedule(kind="cron", expr=self.cron, tz=timezone)
        return CronSchedule(kind="every", every_ms=self.interval_h * self._HOUR_MS)

    def describe_schedule(self) -> str:
        """Return a human-readable summary for logs and startup output."""
        if self.cron:
            return f"cron {self.cron} (legacy)"
        hours = self.interval_h
        return f"every {hours}h"


class InlineFallbackConfig(Base):
    """One inline fallback model configuration."""

    model: str
    provider: str
    max_tokens: int | None = None
    context_window_tokens: int | None = None
    temperature: float | None = None
    reasoning_effort: str | None = None


FallbackCandidate = str | InlineFallbackConfig


class ModelPresetConfig(Base):
    """A named set of model + generation parameters for quick switching."""

    model: str
    provider: str = "auto"
    max_tokens: int = 8192
    context_window_tokens: int = 65_536
    temperature: float = 0.1
    reasoning_effort: str | None = None


class AgentDefaults(Base):
    """Default agent configuration."""

    workspace: str = "~/.pythinker/workspace"
    model_preset: str | None = None  # Active preset name — takes precedence over fields below
    model: str = "openai-codex/gpt-5.5"
    alternate_models: list[str] = Field(
        default_factory=list
    )  # Same-provider models surfaced in the WebUI model-switcher dropdown
    provider: str = (
        "auto"  # Provider name (e.g. "anthropic", "openrouter") or "auto" for auto-detection
    )
    max_tokens: int = 8192
    context_window_tokens: int | None = None
    context_block_limit: int | None = None
    temperature: float = 0.1
    max_tool_iterations: int = 200
    max_tool_result_chars: int = 16_000
    provider_retry_mode: Literal["standard", "persistent"] = "standard"
    reasoning_effort: str | None = None  # minimal / low / medium / high / xhigh - enables LLM thinking mode
    timezone: str = "UTC"  # IANA timezone, e.g. "Asia/Shanghai", "America/New_York"
    unified_session: bool = False  # Share one session across all channels (single-user multi-device)
    disabled_skills: list[str] = Field(default_factory=list)  # Skill names to exclude from loading (e.g. ["summarize", "skill-creator"])
    fallback_models: list[FallbackCandidate] = Field(default_factory=list)  # Ordered fallback list (preset names or inline configs)
    session_ttl_minutes: int = Field(
        default=0,
        ge=0,
        validation_alias=AliasChoices("idleCompactAfterMinutes", "sessionTtlMinutes"),
        serialization_alias="idleCompactAfterMinutes",
    )  # Auto-compact idle threshold in minutes (0 = disabled)
    dream: DreamConfig = Field(default_factory=DreamConfig)


class AgentsConfig(Base):
    """Agent configuration."""

    defaults: AgentDefaults = Field(default_factory=AgentDefaults)


class ProviderConfig(Base):
    """LLM provider configuration."""

    api_key: str | None = None
    api_base: str | None = None
    extra_headers: dict[str, str] | None = None  # Custom headers (e.g. APP-Code for AiHubMix)
    extra_body: dict[str, Any] | None = None  # Extra fields merged into every request body


class ProvidersConfig(Base):
    """Configuration for LLM providers."""

    custom: ProviderConfig = Field(default_factory=ProviderConfig)  # Any OpenAI-compatible endpoint
    azure_openai: ProviderConfig = Field(default_factory=ProviderConfig)  # Azure OpenAI (model = deployment name)
    anthropic: ProviderConfig = Field(default_factory=ProviderConfig)
    openai: ProviderConfig = Field(default_factory=ProviderConfig)
    openrouter: ProviderConfig = Field(default_factory=ProviderConfig)
    deepseek: ProviderConfig = Field(default_factory=ProviderConfig)
    groq: ProviderConfig = Field(default_factory=ProviderConfig)
    zhipu: ProviderConfig = Field(default_factory=ProviderConfig)
    dashscope: ProviderConfig = Field(default_factory=ProviderConfig)
    vllm: ProviderConfig = Field(default_factory=ProviderConfig)
    ollama: ProviderConfig = Field(default_factory=ProviderConfig)  # Ollama local models
    lm_studio: ProviderConfig = Field(default_factory=ProviderConfig)  # LM Studio local models
    ovms: ProviderConfig = Field(default_factory=ProviderConfig)  # OpenVINO Model Server (OVMS)
    gemini: ProviderConfig = Field(default_factory=ProviderConfig)
    moonshot: ProviderConfig = Field(default_factory=ProviderConfig)
    minimax: ProviderConfig = Field(default_factory=ProviderConfig)
    minimax_anthropic: ProviderConfig = Field(default_factory=ProviderConfig)  # MiniMax Anthropic endpoint (thinking)
    mistral: ProviderConfig = Field(default_factory=ProviderConfig)
    stepfun: ProviderConfig = Field(default_factory=ProviderConfig)  # Step Fun
    xiaomi_mimo: ProviderConfig = Field(default_factory=ProviderConfig)  # Xiaomi MIMO
    ant_ling: ProviderConfig = Field(default_factory=ProviderConfig)  # Ant Ling
    aihubmix: ProviderConfig = Field(default_factory=ProviderConfig)  # AiHubMix API gateway
    huggingface: ProviderConfig = Field(default_factory=ProviderConfig)  # Hugging Face Inference Providers (HF_TOKEN, hf_...)
    skywork: ProviderConfig = Field(default_factory=ProviderConfig)  # Skywork / APIFree gateway
    siliconflow: ProviderConfig = Field(default_factory=ProviderConfig)  # SiliconFlow
    volcengine: ProviderConfig = Field(default_factory=ProviderConfig)  # VolcEngine
    volcengine_coding_plan: ProviderConfig = Field(default_factory=ProviderConfig)  # VolcEngine Coding Plan
    byteplus: ProviderConfig = Field(default_factory=ProviderConfig)  # BytePlus (VolcEngine international)
    byteplus_coding_plan: ProviderConfig = Field(default_factory=ProviderConfig)  # BytePlus Coding Plan
    openai_codex: ProviderConfig = Field(default_factory=ProviderConfig, exclude=True)  # OpenAI Codex (OAuth)
    github_copilot: ProviderConfig = Field(default_factory=ProviderConfig, exclude=True)  # Github Copilot (OAuth)
    qianfan: ProviderConfig = Field(default_factory=ProviderConfig)  # Qianfan (Baidu)
    # --- Extension providers (OpenAI-compatible) ---
    xai: ProviderConfig = Field(default_factory=ProviderConfig)
    cerebras: ProviderConfig = Field(default_factory=ProviderConfig)
    together: ProviderConfig = Field(default_factory=ProviderConfig)
    fireworks: ProviderConfig = Field(default_factory=ProviderConfig)
    chutes: ProviderConfig = Field(default_factory=ProviderConfig)
    nvidia: ProviderConfig = Field(default_factory=ProviderConfig)
    deepinfra: ProviderConfig = Field(default_factory=ProviderConfig)
    venice: ProviderConfig = Field(default_factory=ProviderConfig)
    arcee: ProviderConfig = Field(default_factory=ProviderConfig)
    synthetic: ProviderConfig = Field(default_factory=ProviderConfig)
    kimi_coding: ProviderConfig = Field(default_factory=ProviderConfig)
    tencent: ProviderConfig = Field(default_factory=ProviderConfig)
    vercel_ai_gateway: ProviderConfig = Field(default_factory=ProviderConfig)
    perplexity: ProviderConfig = Field(default_factory=ProviderConfig)
    kilocode: ProviderConfig = Field(default_factory=ProviderConfig)
    sglang: ProviderConfig = Field(default_factory=ProviderConfig)
    litellm: ProviderConfig = Field(default_factory=ProviderConfig)


class HeartbeatConfig(Base):
    """Heartbeat service configuration."""

    enabled: bool = True
    interval_s: int = 30 * 60  # 30 minutes
    keep_recent_messages: int = 8


class ApiConfig(Base):
    """OpenAI-compatible API server configuration."""

    host: str = "127.0.0.1"  # Safer default: local-only bind.
    port: int = 8900
    timeout: float = 120.0  # Per-request timeout in seconds.


class GatewayConfig(Base):
    """Gateway/server configuration."""

    host: str = "127.0.0.1"  # Safer default: local-only bind.
    port: int = 18790
    heartbeat: HeartbeatConfig = Field(default_factory=HeartbeatConfig)


class WebSearchProviderConfig(Base):
    """Per-provider credentials for web search.

    Empty fields fall through to the corresponding env var at runtime.
    """

    api_key: str = ""
    base_url: str = ""  # SearXNG only; ignored by other providers


class WebSearchConfig(Base):
    """Web search tool configuration."""

    # Kept as `str` (not `Literal`) so an unknown value in an existing
    # config does not raise a validation error on load. Runtime preserves
    # today's behaviour: execute() returns "Error: unknown search provider..."
    # for unknown values. The wizard's picker prevents new misspellings.
    provider: str = "duckduckgo"
    providers: dict[str, WebSearchProviderConfig] = Field(default_factory=dict)
    max_results: int = 5
    timeout: int = 30  # Wall-clock timeout (seconds) for search operations

    # Deprecated; kept for one minor version, migrated on load.
    api_key: str = ""
    base_url: str = ""

    def credentials_for(self, provider: str) -> WebSearchProviderConfig:
        """Resolve credentials for a provider. Returns an empty config if absent."""
        return self.providers.get(provider) or WebSearchProviderConfig()


class BrowserConfig(Base):
    """Sandboxed-browser tool configuration. See docs/configuration.md."""

    enable: bool = False
    mode: Literal["auto", "launch", "cdp"] = "auto"
    cdp_url: str = "http://127.0.0.1:9222"
    headless: bool = True
    executable_path: str | None = None
    auto_provision: bool = True
    provision_timeout_s: int = Field(default=300, ge=1)
    default_timeout_ms: int = 15_000
    navigation_timeout_ms: int = 30_000
    eval_timeout_ms: int = 5_000
    snapshot_max_chars: int = 20_000
    idle_ttl_seconds: int = 600
    disconnect_on_idle: bool = False
    max_pages_per_context: int = Field(default=5, ge=1, le=50)
    storage_state_dir: str | None = None  # None ⇒ <data_dir>/browser/

    def signature(self) -> tuple[object, ...]:
        """Fields that require rebuilding the browser manager when changed."""
        return (
            self.enable,
            self.mode,
            self.cdp_url,
            self.headless,
            self.executable_path,
            self.auto_provision,
            self.provision_timeout_s,
            self.default_timeout_ms,
            self.navigation_timeout_ms,
            self.eval_timeout_ms,
            self.snapshot_max_chars,
            self.idle_ttl_seconds,
            self.disconnect_on_idle,
            self.max_pages_per_context,
            self.storage_state_dir,
        )


class WebToolsConfig(Base):
    """Web tools configuration."""

    enable: bool = True
    proxy: str | None = (
        None  # HTTP/SOCKS5 proxy URL, e.g. "http://127.0.0.1:7890" or "socks5://127.0.0.1:1080"
    )
    search: WebSearchConfig = Field(default_factory=WebSearchConfig)
    browser: BrowserConfig = Field(default_factory=BrowserConfig)


class ExecToolConfig(Base):
    """Shell exec tool configuration."""

    enable: bool = True
    timeout: int = 60
    path_append: str = ""
    sandbox: str = ""  # sandbox backend: "" (none) or "bwrap"
    allowed_env_keys: list[str] = Field(default_factory=list)  # Env var names to pass through to subprocess (e.g. ["GOPATH", "JAVA_HOME"])

class MCPServerConfig(Base):
    """MCP server connection configuration (stdio or HTTP)."""

    type: Literal["stdio", "sse", "streamableHttp"] | None = None  # auto-detected if omitted
    command: str = ""  # Stdio: command to run (e.g. "npx")
    args: list[str] = Field(default_factory=list)  # Stdio: command arguments
    env: dict[str, str] = Field(default_factory=dict)  # Stdio: extra env vars
    url: str = ""  # HTTP/SSE: endpoint URL
    headers: dict[str, str] = Field(default_factory=dict)  # HTTP/SSE: custom headers
    tool_timeout: int = 30  # seconds before a tool call is cancelled
    enabled_tools: list[str] = Field(default_factory=lambda: ["*"])  # Only register these tools; accepts raw MCP names or wrapped mcp_<server>_<tool> names; ["*"] = all tools; [] = no tools

class MyToolConfig(Base):
    """Self-inspection tool configuration."""

    enable: bool = True  # register the `my` tool (agent runtime state inspection)
    allow_set: bool = False  # let `my` modify loop state (read-only if False)


class ImageGenerationConfig(Base):
    """generate_image tool configuration."""

    enabled: bool = False
    provider: str = "openrouter"  # openrouter, gemini, minimax, aihubmix
    model: str = "openai/gpt-5.4-image-2"
    default_aspect_ratio: str = "1:1"
    default_image_size: str = "1K"
    max_images_per_turn: int = Field(default=4, ge=1, le=8)
    save_dir: str = "generated"


class ToolsConfig(Base):
    """Tools configuration."""

    web: WebToolsConfig = Field(default_factory=WebToolsConfig)
    exec: ExecToolConfig = Field(default_factory=ExecToolConfig)
    my: MyToolConfig = Field(default_factory=MyToolConfig)
    image_generation: ImageGenerationConfig = Field(default_factory=ImageGenerationConfig)
    restrict_to_workspace: bool = False  # restrict all tool access to workspace directory
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)
    ssrf_whitelist: list[str] = Field(default_factory=list)  # CIDR ranges to exempt from SSRF blocking (e.g. ["100.64.0.0/10"] for Tailscale)


class UpdatesConfig(Base):
    """Update-check / self-update configuration."""

    check: bool = True
    notify: bool = True
    auto: Literal["off", "patch"] = "off"
    check_interval_h: int = 24
    prereleases: bool = False


class CliTuiConfig(Base):
    """TUI-only preferences (theme, etc.)."""

    theme: str = "default"


class CliConfig(Base):
    """CLI surface preferences."""

    tui: CliTuiConfig = Field(default_factory=CliTuiConfig)


class LoggingConfig(Base):
    """Loguru sink configuration.

    ``level`` is the persistent default (read from config.json on startup);
    the ``--verbose`` / ``--quiet`` CLI flags and the ``PYTHINKER_LOG_LEVEL``
    env var override it at runtime. Without this, loguru's out-of-the-box
    sink fires at DEBUG, which floods the gateway's stdout with internal
    lifecycle events on every channel handshake.
    """

    level: Literal["TRACE", "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"


class RuntimeConfig(Base):
    """Governed-execution runtime knobs.

    Off-by-default: the platform behaves identically to pre-runtime versions
    until an operator opts in.

    Policy semantics when ``policy_enabled=True``:
      - If ``manifests_dir`` is set and contains active manifests, allow-lists
        come from the manifests (per-agent ``allowed_tools``).
      - Else if ``policy_migration_mode == "allow-all"``, every tool is
        permitted for the default agent (logged at WARN on startup so the
        operator knows policy is effectively a no-op).
      - Otherwise the default is **deny-all**: every tool call is rejected
        with a "no allow-list configured" reason. This is intentional —
        ``policy_enabled=True`` without an allow-list is treated as a
        misconfiguration, not as an implicit allow-all.

    Each field maps to a single subsystem:

    - policy_enabled        → PolicyService.authorize_*
    - policy_migration_mode → opt-in escape hatch for "policy on, allow all"
    - telemetry_sink        → TelemetrySink installed at startup
    - telemetry_jsonl_path  → JSONLSink target (only when sink is "jsonl" or "both")
    - session_cache_max     → SessionManager._cache cap (LRU eviction)
    - max_*                 → BudgetCounters defaults stamped on every RequestContext
                              by AgentLoop._normalize_context (Task 4b)
    - manifests_dir         → AgentRegistry.load_dir() target; None disables manifest
                              lookups; when set, becomes the source of truth for
                              PolicyService.allowed_tools
    """

    policy_enabled: bool = False
    policy_migration_mode: Literal["allow-all"] | None = None
    telemetry_sink: Literal["off", "log", "jsonl", "both"] = "off"
    telemetry_jsonl_path: str | None = None
    session_cache_max: int = Field(default=256, ge=1)
    max_tool_calls_per_turn: int = Field(default=0, ge=0)  # 0 = disabled
    max_wall_clock_s: float = Field(default=0.0, ge=0.0)  # 0 = disabled
    max_subagent_recursion_depth: int = Field(default=3, ge=0)
    manifests_dir: str | None = None
    default_agent_id: str = "default"  # which manifest agent_id is bound to inbound contexts
    # Each entry is a "<channel>:<sender_id>" identifier rejected at ingress
    # when policy_enabled is true (e.g. "slack:U_BAD" or "telegram:42"). Empty
    # by default so the field is opt-in and harmless when policy is off.
    blocked_senders: list[str] = Field(default_factory=list)


class ModelMetadataOverride(Base):
    """User-supplied model metadata override."""

    provider: str | None = None
    aliases: list[str] = Field(default_factory=list)
    input_tokens: int | None = None
    max_output_tokens: int | None = None
    total_context_tokens: int | None = None
    encoding: str | None = None
    supports_tools: bool | None = None
    supports_vision: bool | None = None
    supports_json_schema: bool | None = None
    supports_reasoning: bool | None = None
    preferred_api: str | None = None
    input_cost_per_million: float | None = None
    cached_input_cost_per_million: float | None = None
    output_cost_per_million: float | None = None
    currency: str | None = None
    pricing_source_url: str | None = None
    long_context_threshold_tokens: int | None = None
    long_context_input_multiplier: float | None = None
    long_context_output_multiplier: float | None = None


class ModelsConfig(Base):
    """Global model metadata settings."""

    metadata_mode: Literal["off", "auto", "static", "online"] = "auto"
    metadata_cache_ttl_hours: int = 168
    allow_online_metadata_refresh: bool = False
    overrides: dict[str, ModelMetadataOverride] = Field(default_factory=dict)
    azure_deployments: dict[str, str] = Field(default_factory=dict)


class Config(BaseSettings):
    """Root configuration for pythinker."""

    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    channels: ChannelsConfig = Field(default_factory=ChannelsConfig)
    providers: ProvidersConfig = Field(default_factory=ProvidersConfig)
    models: ModelsConfig = Field(default_factory=ModelsConfig)
    api: ApiConfig = Field(default_factory=ApiConfig)
    gateway: GatewayConfig = Field(default_factory=GatewayConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)
    runtime: RuntimeConfig = Field(default_factory=RuntimeConfig)
    updates: UpdatesConfig = Field(default_factory=UpdatesConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    cli: CliConfig = Field(default_factory=CliConfig)
    model_presets: dict[str, ModelPresetConfig] = Field(
        default_factory=dict,
        validation_alias=AliasChoices("modelPresets", "model_presets"),
    )

    @model_validator(mode="after")
    def _validate_model_preset(self) -> "Config":
        if "default" in self.model_presets:
            raise ValueError("model_preset name 'default' is reserved for agents.defaults")
        name = self.agents.defaults.model_preset
        if name and name != "default" and name not in self.model_presets:
            raise ValueError(f"model_preset {name!r} not found in model_presets")
        for fallback in self.agents.defaults.fallback_models:
            if isinstance(fallback, str) and fallback not in self.model_presets:
                raise ValueError(f"fallback_models entry {fallback!r} not found in model_presets")
        return self

    def resolve_default_preset(self) -> ModelPresetConfig:
        """Return the implicit ``default`` preset built from agents.defaults fields."""
        d = self.agents.defaults
        return ModelPresetConfig(
            model=d.model,
            provider=d.provider,
            max_tokens=d.max_tokens,
            context_window_tokens=d.context_window_tokens or 65_536,
            temperature=d.temperature,
            reasoning_effort=d.reasoning_effort,
        )

    def resolve_preset(self, name: str | None = None) -> ModelPresetConfig:
        """Return effective model params from a named preset or the implicit default."""
        name = self.agents.defaults.model_preset if name is None else name
        if not name or name == "default":
            return self.resolve_default_preset()
        if name not in self.model_presets:
            raise KeyError(f"model_preset {name!r} not found in model_presets")
        return self.model_presets[name]

    @property
    def workspace_path(self) -> Path:
        """Get expanded workspace path."""
        return Path(self.agents.defaults.workspace).expanduser()

    def _match_provider(
        self,
        model: str | None = None,
        *,
        preset: "ModelPresetConfig | None" = None,
    ) -> tuple["ProviderConfig | None", str | None]:
        """Match provider config and its registry name. Returns (config, spec_name).

        When ``preset`` is supplied and ``preset.provider != "auto"``, the preset's
        forced provider takes precedence over ``agents.defaults.provider`` — so a
        preset that pins a model to a non-default provider gets that provider's
        credentials and api_base, not the model-name heuristic's pick.
        """
        from pythinker.providers.registry import PROVIDERS, find_by_name

        forced = self.agents.defaults.provider
        if preset is not None and preset.provider != "auto":
            forced = preset.provider
        if forced != "auto":
            spec = find_by_name(forced)
            if spec:
                p = getattr(self.providers, spec.name, None)
                return (p, spec.name) if p else (None, None)
            return None, None

        model_lower = (model or self.agents.defaults.model).lower()
        model_normalized = model_lower.replace("-", "_")
        model_prefix = model_lower.split("/", 1)[0] if "/" in model_lower else ""
        normalized_prefix = model_prefix.replace("-", "_")

        def _kw_matches(kw: str) -> bool:
            kw = kw.lower()
            return kw in model_lower or kw.replace("-", "_") in model_normalized

        # Explicit provider prefix wins — prevents `github-copilot/...codex` matching openai_codex.
        for spec in PROVIDERS:
            p = getattr(self.providers, spec.name, None)
            if p and model_prefix and normalized_prefix == spec.name:
                if spec.is_oauth or spec.is_local or p.api_key:
                    return p, spec.name

        # Match by keyword (order follows PROVIDERS registry)
        for spec in PROVIDERS:
            p = getattr(self.providers, spec.name, None)
            if p and any(_kw_matches(kw) for kw in spec.keywords):
                if spec.is_oauth or spec.is_local or p.api_key:
                    return p, spec.name

        # Fallback: configured local providers can route models without
        # provider-specific keywords (for example plain "llama3.2" on Ollama).
        # Prefer providers whose detect_by_base_keyword matches the configured api_base
        # (e.g. Ollama's "11434" in "http://localhost:11434") over plain registry order.
        local_fallback: tuple[ProviderConfig, str] | None = None
        for spec in PROVIDERS:
            if not spec.is_local:
                continue
            p = getattr(self.providers, spec.name, None)
            if not (p and p.api_base):
                continue
            if spec.detect_by_base_keyword and spec.detect_by_base_keyword in p.api_base:
                return p, spec.name
            if local_fallback is None:
                local_fallback = (p, spec.name)
        if local_fallback:
            return local_fallback

        # Fallback: gateways first, then others (follows registry order)
        # OAuth providers are NOT valid fallbacks — they require explicit model selection
        for spec in PROVIDERS:
            if spec.is_oauth:
                continue
            p = getattr(self.providers, spec.name, None)
            if p and p.api_key:
                return p, spec.name
        return None, None

    def _trace_match_provider(self, model: str | None = None) -> dict[str, object]:
        """Return provider matching metadata without changing the hot path result."""
        from pythinker.providers.registry import find_by_name

        model_value = model or self.agents.defaults.model
        provider_config, provider_name = self._match_provider(model_value)
        if provider_name is None:
            return {
                "model": model_value,
                "matched_spec": None,
                "matched_keyword": None,
                "match_phase": "none",
                "resolved_api_base": None,
            }

        spec = find_by_name(provider_name)
        phase = "api-key-fallback"
        keyword: str | None = None
        forced = self.agents.defaults.provider
        model_lower = model_value.lower()
        model_normalized = model_lower.replace("-", "_")
        model_prefix = model_lower.split("/", 1)[0] if "/" in model_lower else ""
        normalized_prefix = model_prefix.replace("-", "_")

        if forced != "auto":
            phase = "forced-provider"
            keyword = forced
        elif normalized_prefix == provider_name:
            phase = "prefix-match"
            keyword = f"{model_prefix}/" if model_prefix else provider_name
        elif spec is not None:
            for candidate in spec.keywords:
                candidate_lower = candidate.lower()
                if candidate_lower in model_lower or candidate_lower.replace("-", "_") in model_normalized:
                    phase = "keyword-match"
                    keyword = candidate
                    break
            if keyword is None and spec.is_local and provider_config and provider_config.api_base:
                phase = "local-fallback"
                keyword = provider_name

        resolved_api_base = None
        if provider_config and provider_config.api_base:
            resolved_api_base = provider_config.api_base
        elif spec and spec.default_api_base:
            resolved_api_base = spec.default_api_base

        return {
            "model": model_value,
            "matched_spec": provider_name,
            "matched_keyword": keyword,
            "match_phase": phase,
            "resolved_api_base": resolved_api_base,
        }

    def get_provider(
        self,
        model: str | None = None,
        *,
        preset: "ModelPresetConfig | None" = None,
    ) -> ProviderConfig | None:
        """Get matched provider config (api_key, api_base, extra_headers). Falls back to first available."""
        p, _ = self._match_provider(model, preset=preset)
        return p

    def get_provider_name(
        self,
        model: str | None = None,
        *,
        preset: "ModelPresetConfig | None" = None,
    ) -> str | None:
        """Get the registry name of the matched provider (e.g. "deepseek", "openrouter")."""
        _, name = self._match_provider(model, preset=preset)
        return name

    def get_api_key(
        self,
        model: str | None = None,
        *,
        preset: "ModelPresetConfig | None" = None,
    ) -> str | None:
        """Get API key for the given model. Falls back to first available key."""
        p = self.get_provider(model, preset=preset)
        return p.api_key if p else None

    def get_api_base(
        self,
        model: str | None = None,
        *,
        preset: "ModelPresetConfig | None" = None,
    ) -> str | None:
        """Get API base URL for the given model, falling back to the provider default when present."""
        from pythinker.providers.registry import find_by_name

        p, name = self._match_provider(model, preset=preset)
        if p and p.api_base:
            return p.api_base
        if name:
            spec = find_by_name(name)
            if spec and spec.default_api_base:
                return spec.default_api_base
        return None

    model_config = ConfigDict(env_prefix="PYTHINKER_", env_nested_delimiter="__")
