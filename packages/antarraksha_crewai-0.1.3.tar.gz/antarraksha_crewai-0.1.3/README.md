# antarraksha-crewai

Antarraksha AI Agent Enforcement SDK for CrewAI.

## Installation

```bash
pip install antarraksha-crewai
```

## Quick Start

Instantiate the Antarraksha guardrail and call its check methods from inside your CrewAI tasks or tool wrappers. Registration happens automatically on first use — no login, no API key, no signup required.

```python
from antarraksha_crewai import AntarrakshaGuardrail

guardrail = AntarrakshaGuardrail(agent_id="my-crew-agent")

result = guardrail.check_tool_call(tool_name="search_web", parameters={"query": "..."})
if result["decision"] == "DENY":
    raise PermissionError(result["reason"])

result = guardrail.check_llm_call(model_name="gpt-4o", prompt_length=512)
if result["decision"] == "DENY":
    raise PermissionError(result["reason"])
```

Wire `check_tool_call` into your tool callbacks and `check_llm_call` into your LLM wrapper. Every intercepted call is logged and visible at `https://antarraksha.ai/registry`.

## Parameters

| Parameter | Default | Description |
|---|---|---|
| `agent_id` | `None` | Unique identifier for your agent. Triggers auto-registration on first use. |
| `base_url` | `"https://antarraksha.ai"` | Antarraksha endpoint. Override for self-hosted / dev. |
| `passport_id` | `None` | Optional pre-issued passport ID (e.g. `ANTK-PASS-xxx`). |
| `sdk_key` | `None` | Optional pre-issued SDK key. If omitted and `agent_id` is set, the SDK auto-registers and obtains one. |
| `fail_closed` | `True` | If `True`, deny on enforcement-server unreachable. Set `False` for fail-open during early integration. |

## Corporate Network Note

If you're behind a corporate TLS-inspection proxy and see `SSLCertVerificationError`, install:

```bash
pip install pip-system-certs
```

This makes Python trust your Windows / macOS system certificate store.
