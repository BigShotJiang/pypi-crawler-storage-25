# mcping

Minecraft server status query tool supporting both Java and Bedrock editions.

## Installation

```bash
pip install 100-mcping
```

## Usage

```bash
# Java Edition
mcping hypixel.net

# Specify port
mcping my.server.com -p 25565

# Bedrock Edition
mcping play.hydrogen.rip -p 19132 --bedrock

# Output JSON
mcping hypixel.net --json

# Other options
mcping my.server.com --player-limit 20   # Show more players
mcping my.server.com --no-players        # Hide player list
mcping my.server.com --no-srv           # Disable SRV resolution
mcping my.server.com --timeout 15        # Adjust timeout
```

## As a Python Library

```python
import asyncio
from mcping.java_ping import mcping as java_ping
from mcping.bedrock_ping import mcping_bedrock

async def main():
    # Java Edition
    result = await java_ping("hypixel.net")
    if result.success:
        print(f"Latency: {result.latency_ms}ms")
        print(f"Online: {result.players_online}/{result.players_max}")

    # Bedrock Edition
    result_bedrock = await mcping_bedrock("play.hydrogen.rip", 19132)
    if result_bedrock.success:
        print(f"Latency: {result_bedrock.latency_ms}ms")

asyncio.run(main())
```

## Options

| Option | Description | Default |
|--------|-------------|---------|
| `host` | Server address | Required |
| `-p, --port` | Port | Java: 25565 / Bedrock: 19132 |
| `-b, --bedrock` | Bedrock Edition | — |
| `--timeout` | Timeout in seconds | 10 |
| `--player-limit` | Max players to show | 5 |
| `--no-players` | Hide player list | — |
| `--no-srv` | Disable SRV resolution | — |
| `--json` | JSON output | — |

## License

GPLv3
