// Bloom Composite Pass
//
// Blends the accumulated bloom result (from mip 0 of the bloom chain)
// with the original HDR scene color using linear interpolation.
// Output replaces the scene color buffer for subsequent passes (e.g., tone mapping).

{$ include 'core/full_screen_vertex' $}

{{ struct_definitions }}

// Group 0: Persistent feature resources (Feature-owned, long-lived)
@group(0) @binding(0) var tex_sampler: sampler;
@group(0) @binding(1) var<uniform> u_bloom: CompositeUniforms;

// Group 1: Transient RDG textures (PassNode-owned, per-frame)
@group(1) @binding(0) var original_texture: texture_2d<f32>;
@group(1) @binding(1) var bloom_texture: texture_2d<f32>;

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
    let uv = in.uv;
    let original = textureSampleLevel(original_texture, tex_sampler, uv, 0.0);
    let bloom = textureSampleLevel(bloom_texture, tex_sampler, uv, 0.0);

    // Additive blend: original + bloom × strength
    let result = original.rgb + bloom.rgb * u_bloom.bloom_strength;

    // The original LearnOpenGL text(https://learnopengl.com/Guest-Articles/2022/Phys.-Based-Bloom) uses "mix", 
    // but I believe "additive" seems to be more appropriate. 
    // TODO: confirm the correct approach.
    // let result = mix(original.rgb, bloom.rgb, u_bloom.bloom_strength);

    return vec4<f32>(result, original.a);
}
