// ── UV Transform Application (Mixin) ────────────────────────────────────
//
// Applies per-map UV transforms for all texture maps using the material's
// transform matrices.  Uses template variables (e.g. MAP_UV) to select
// which UV channel each map reads from.
//
// This is a template mixin because it directly assigns to struct fields
// of the caller's `out: VertexOutput` variable.
//
// Required local variables:
//   - out: VertexOutput  (mutable, receives transformed UVs)
//   - in: VertexInput    (read-only, provides raw UV channels)
//
// Required global resources:
//   - u_material.*_transform: mat3x3<f32> (UV transform matrices)

$$ if HAS_MAP is defined
    out.map_uv = (u_material.map_transform * vec3<f32>(in.uv{{MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_NORMAL_MAP is defined
    out.normal_map_uv = (u_material.normal_map_transform * vec3<f32>(in.uv{{NORMAL_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_SPECULAR_MAP is defined
    out.specular_map_uv = (u_material.specular_map_transform * vec3<f32>(in.uv{{SPECULAR_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_SPECULAR_INTENSITY_MAP is defined
    out.specular_intensity_map_uv = (u_material.specular_intensity_map_transform * vec3<f32>(in.uv{{SPECULAR_INTENSITY_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_AO_MAP is defined
    out.ao_map_uv = (u_material.ao_map_transform * vec3<f32>(in.uv{{AO_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_LIGHT_MAP is defined
    out.light_map_uv = (u_material.light_map_transform * vec3<f32>(in.uv{{LIGHT_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_EMISSIVE_MAP is defined
    out.emissive_map_uv = (u_material.emissive_map_transform * vec3<f32>(in.uv{{EMISSIVE_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_METALNESS_MAP is defined
    out.metalness_map_uv = (u_material.metalness_map_transform * vec3<f32>(in.uv{{METALNESS_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_ROUGHNESS_MAP is defined
    out.roughness_map_uv = (u_material.roughness_map_transform * vec3<f32>(in.uv{{ROUGHNESS_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_CLEARCOAT_MAP is defined
    out.clearcoat_map_uv = (u_material.clearcoat_map_transform * vec3<f32>(in.uv{{CLEARCOAT_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_CLEARCOAT_NORMAL_MAP is defined
    out.clearcoat_normal_map_uv = (u_material.clearcoat_normal_map_transform * vec3<f32>(in.uv{{CLEARCOAT_NORMAL_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_CLEARCOAT_ROUGHNESS_MAP is defined
    out.clearcoat_roughness_map_uv = (u_material.clearcoat_roughness_map_transform * vec3<f32>(in.uv{{CLEARCOAT_ROUGHNESS_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_IRIDESCENCE_MAP is defined
    out.iridescence_map_uv = (u_material.iridescence_map_transform * vec3<f32>(in.uv{{IRIDESCENCE_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_IRIDESCENCE_THICKNESS_MAP is defined
    out.iridescence_thickness_map_uv = (u_material.iridescence_thickness_map_transform * vec3<f32>(in.uv{{IRIDESCENCE_THICKNESS_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_ANISOTROPY_MAP is defined
    out.anisotropy_map_uv = (u_material.anisotropy_map_transform * vec3<f32>(in.uv{{ANISOTROPY_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_SHEEN_COLOR_MAP is defined
    out.sheen_color_map_uv = (u_material.sheen_color_map_transform * vec3<f32>(in.uv{{SHEEN_COLOR_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_SHEEN_ROUGHNESS_MAP is defined
    out.sheen_roughness_map_uv = (u_material.sheen_roughness_map_transform * vec3<f32>(in.uv{{SHEEN_ROUGHNESS_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_TRANSMISSION_MAP is defined
    out.transmission_map_uv = (u_material.transmission_map_transform * vec3<f32>(in.uv{{TRANSMISSION_MAP_UV or ''}}, 1.0)).xy;
$$ endif

$$ if HAS_THICKNESS_MAP is defined
    out.thickness_map_uv = (u_material.thickness_map_transform * vec3<f32>(in.uv{{THICKNESS_MAP_UV or ''}}, 1.0)).xy;
$$ endif
