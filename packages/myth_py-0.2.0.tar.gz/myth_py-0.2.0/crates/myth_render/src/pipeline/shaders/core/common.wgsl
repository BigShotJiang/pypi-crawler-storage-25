// ── Common Shader Utilities ──────────────────────────────────────────────
//
// Math helpers, physical constants, core lighting structs, and base BRDF
// functions shared by all material models.

fn pow2( x: f32 ) -> f32 {
    return x * x;
}

fn pow4( x: f32 ) -> f32 {
    let x2 = x * x;
    return x2 * x2;
}

const PI: f32 = 3.141592653589793;
const RECIPROCAL_PI: f32 = 0.3183098861837907;
const EPSILON = 1e-6;


fn getDistanceAttenuation(light_distance: f32, cutoff_distance: f32, decay_exponent: f32) -> f32 {
    var distance_falloff: f32 = 1.0 / max( pow( light_distance, decay_exponent ), 0.01 );
    if ( cutoff_distance > 0.0 ) {
        distance_falloff *= pow2( saturate( 1.0 - pow4( light_distance / cutoff_distance ) ) );
    }
    return distance_falloff;
}

fn getSpotAttenuation( cone_cosine: f32, penumbra_cosine: f32, angle_cosine: f32 ) -> f32 {
    return smoothstep( cone_cosine, penumbra_cosine, angle_cosine );
}

fn getAmbientLightIrradiance( ambientlight_color: vec3<f32> ) -> vec3<f32> {
    let irradiance = ambientlight_color;
    return irradiance;
}

struct IncidentLight {
    color: vec3<f32>,
    visible: bool,
    direction: vec3<f32>,
};

struct GeometricContext {
    position: vec3<f32>,
    normal: vec3<f32>,
    view_dir: vec3<f32>,
    $$ if USE_CLEARCOAT is defined
    clearcoat_normal: vec3<f32>,
    $$ endif
};

struct ReflectedLight {
    direct_diffuse: vec3<f32>,
    direct_specular: vec3<f32>,
    indirect_diffuse: vec3<f32>,
    indirect_specular: vec3<f32>,
};

fn BRDF_Lambert(diffuse_color: vec3<f32>) -> vec3<f32> {
    return RECIPROCAL_PI * diffuse_color;
}

fn F_Schlick(f0: vec3<f32>, f90: f32, dot_vh: f32,) -> vec3<f32> {
    let fresnel = exp2( ( - 5.55473 * dot_vh - 6.98316 ) * dot_vh );
    return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}

fn F_Schlick_f(f0: f32, f90: f32, dot_vh: f32,) -> f32 {
    let fresnel = exp2( ( - 5.55473 * dot_vh - 6.98316 ) * dot_vh );
    return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}

$$ if HAS_NORMAL_MAP is defined or HAS_CLEARCOAT_NORMAL_MAP is defined or USE_ANISOTROPY is defined
fn getTangentFrame( eye_pos: vec3<f32>, surf_norm: vec3<f32>, uv: vec2<f32>) -> mat3x3<f32> {
    let q0 = dpdx( eye_pos.xyz );
    let q1 = dpdy( eye_pos.xyz );
    let st0 = dpdx( uv.xy );
    let st1 = dpdy( uv.xy );
    let N = surf_norm;
    let q1perp = cross( q1, N );
    let q0perp = cross( N, q0 );
    let T = q1perp * st0.x + q0perp * st1.x;
    let B = q1perp * st0.y + q0perp * st1.y;
    let det = max( dot( T, T ), dot( B, B ) );
    let scale = select(inverseSqrt(det), 0.0, det == 0.0);

    return mat3x3f(T * scale, -B * scale, N);
}

fn perturbNormal2Arb( eye_pos: vec3<f32>, surf_norm: vec3<f32>, map_n: vec3<f32>, uv: vec2<f32>, is_front: bool) -> vec3<f32> {
    let tbn = getTangentFrame( eye_pos, surf_norm, uv );
    let face_direction = f32(is_front) * 2.0 - 1.0;
    let scaled_map_n = vec3f(map_n.xy * face_direction, map_n.z);
    let perturb_normal = tbn * scaled_map_n;
    return normalize( perturb_normal );
}

$$ endif
