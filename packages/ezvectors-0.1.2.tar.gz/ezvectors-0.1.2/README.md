# ezvectors

A fast and lightweight 2D vector class for Python. No dependencies required.

I built this because I needed vectors for my initial prototype of a 2D [physics engine](https://github.com/adyanthm/physics) and using NumPy for some really simple vector math is genuinely slower than pure Python. The overhead of calling into compiled C code through Python's FFI for something as small as adding two floats together completely negates any performance benefit. So I wrote my own vector library!

`ezvectors` gives you a `Vector2` class that uses `__slots__` for a small memory footprint, avoids unnecessary object allocation in arithmetic, and works seamlessly with plain tuples.

You can install `ezvectors` via pip:

```bash
pip install ezvectors
```

## Usage

```python
from ezvectors import Vector2

a = Vector2(3, 4)
b = Vector2(1, 2)

a + b             # Vector2(4, 6)
a - (1, 1)        # Vector2(2, 3) — tuples work everywhere
a * 2             # Vector2(6, 8)
a.magnitude()     # 5.0
a.normalize()     # Vector2(0.6, 0.8)
a.dot(b)          # 11
a.distance_to(b)  # 2.8284...
a.rotate_deg(90)  # Vector2(-4, 3)
```

Full API reference and examples in [documentation.md](https://github.com/adyanthm/ezvectors/blob/main/documentation.md).

## Tests

```bash
pip install pytest
pytest tests/
```

## License

MIT — see [LICENSE.md](LICENSE.md).
