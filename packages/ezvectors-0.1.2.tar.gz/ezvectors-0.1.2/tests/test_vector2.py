import pytest
import math
from ezvectors import Vector2

def test_initialization():
    v1 = Vector2(3, 4)
    assert v1.x == 3
    assert v1.y == 4
    
    v2 = Vector2((5, 6))
    assert v2.x == 5
    assert v2.y == 6
    
    v3 = Vector2(v1)
    assert v3.x == 3
    assert v3.y == 4

def test_representation():
    v = Vector2(3, 4)
    assert repr(v) == "Vector2(3, 4)"

def test_equality():
    v1 = Vector2(1, 2)
    v2 = Vector2(1, 2)
    v3 = Vector2(2, 3)
    
    assert v1 == v2
    assert v1 != v3
    assert v1 == (1, 2)
    assert v1 != (2, 3)
    assert v1 != "not a vector"

def test_addition():
    v1 = Vector2(3, 4)
    v2 = Vector2(5, 6)
    
    assert v1 + v2 == Vector2(8, 10)
    assert v1 + (1, 1) == Vector2(4, 5)

def test_subtraction():
    v1 = Vector2(5, 6)
    v2 = Vector2(3, 4)
    
    assert v1 - v2 == Vector2(2, 2)
    assert v1 - (1, 1) == Vector2(4, 5)

def test_multiplication():
    v = Vector2(3, 4)
    assert v * 2 == Vector2(6, 8)
    assert 2 * v == Vector2(6, 8)

def test_division():
    v = Vector2(3, 4)
    assert v / 2 == Vector2(1.5, 2.0)

def test_negation():
    v = Vector2(3, 4)
    assert -v == Vector2(-3, -4)

def test_iteration():
    v = Vector2(3, 4)
    x, y = v
    assert x == 3
    assert y == 4

def test_getitem():
    v = Vector2(3, 4)
    assert v[0] == 3
    assert v[1] == 4
    assert v[-2] == 3
    assert v[-1] == 4
    
    with pytest.raises(IndexError):
        v[2]

def test_magnitude():
    v = Vector2(3, 4)
    assert v.magnitude() == 5.0
    assert v.magnitude_squared() == 25

def test_normalize():
    v = Vector2(3, 4)
    v_norm = v.normalize()
    assert math.isclose(v_norm.magnitude(), 1.0)
    assert math.isclose(v_norm.x, 3/5.0)
    assert math.isclose(v_norm.y, 4/5.0)
    
    v_zero = Vector2(0, 0)
    assert v_zero.normalize() == Vector2(0, 0)

def test_dot():
    v1 = Vector2(3, 4)
    v2 = Vector2(5, 6)
    assert v1.dot(v2) == 3*5 + 4*6
    assert v1.dot((5, 6)) == 3*5 + 4*6

def test_distance_to():
    v1 = Vector2(0, 0)
    v2 = Vector2(3, 4)
    assert v1.distance_to(v2) == 5.0
    assert v1.distance_to((3, 4)) == 5.0

def test_cross():
    v1 = Vector2(3, 4)
    v2 = Vector2(5, 6)
    assert v1.cross(v2) == 3*6 - 4*5
    assert v1.cross((5, 6)) == 3*6 - 4*5

def test_rotate():
    v = Vector2(1, 0)
    v_rot = v.rotate(math.pi / 2)
    assert math.isclose(v_rot.x, 0, abs_tol=1e-9)
    assert math.isclose(v_rot.y, 1, abs_tol=1e-9)

def test_rotate_deg():
    v = Vector2(1, 0)
    v_rot = v.rotate_deg(90)
    assert math.isclose(v_rot.x, 0, abs_tol=1e-9)
    assert math.isclose(v_rot.y, 1, abs_tol=1e-9)

def test_angle():
    v = Vector2(1, 1)
    assert math.isclose(v.angle(), math.pi / 4)

def test_conversion():
    v = Vector2(3, 4)
    assert v.to_tuple() == (3, 4)
    assert Vector2.from_tuple((3, 4)) == v
