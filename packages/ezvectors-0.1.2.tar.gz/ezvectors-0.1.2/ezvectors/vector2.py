import math

class Vector2:

    __slots__ = ("x", "y")
    
    def __init__(self, x, y=None):
      if y is None:
        x, y = x
      self.x = x
      self.y = y
      
    def __repr__(self):
      return f"Vector2({self.x}, {self.y})"
      
    def __eq__(self, other):
      if isinstance(other, Vector2):
        return self.x == other.x and self.y == other.y
      try:
        ox, oy = other
        return self.x == ox and self.y == oy
      except (TypeError, ValueError):
        return NotImplemented

    def __ne__(self, other):
      eq = self.__eq__(other)
      if eq is NotImplemented:
        return NotImplemented
      return not eq

    def __add__(self, other):
      if isinstance(other, Vector2):
        return Vector2(self.x + other.x, self.y + other.y)
      try:
        ox, oy = other
        return Vector2(self.x + ox, self.y + oy)
      except (TypeError, ValueError):
        return NotImplemented
      
    def __sub__(self, other):
      if isinstance(other, Vector2):
        return Vector2(self.x - other.x, self.y - other.y)
      try:
        ox, oy = other
        return Vector2(self.x - ox, self.y - oy)
      except (TypeError, ValueError):
        return NotImplemented
      
    def __mul__(self, scalar):
      return Vector2(
        self.x * scalar,
        self.y * scalar
      )
      
    __rmul__ = __mul__
  
    def __truediv__(self, scalar):
      return Vector2(
        self.x / scalar,
        self.y / scalar
      )

    def __neg__(self):
      return Vector2(
        -self.x,
        -self.y
      )
      
    def __iter__(self):
      yield self.x
      yield self.y

    def __getitem__(self, index):
      if index == 0 or index == -2:
          return self.x
      if index == 1 or index == -1:
          return self.y
      raise IndexError("Vector2 index out of range")
      
    def magnitude(self):
      return math.sqrt(self.x**2 + self.y**2)
      
    def magnitude_squared(self):
      return self.x**2 + self.y**2
      
    def normalize(self):
      length = math.sqrt(self.x**2 + self.y**2)
      if length == 0:
        return Vector2(0, 0)
      return Vector2(self.x / length, self.y / length)
      
    def dot(self, other):
      if isinstance(other, Vector2):
        return self.x * other.x + self.y * other.y
      try:
        ox, oy = other
        return self.x * ox + self.y * oy
      except (TypeError, ValueError):
        raise TypeError("dot operand must be a Vector2 or iterable of length 2")
      
    def distance_to(self, other):
      if isinstance(other, Vector2):
        return math.sqrt((other.x - self.x)**2 + (other.y - self.y)**2)
      try:
        ox, oy = other
        return math.sqrt((ox - self.x)**2 + (oy - self.y)**2)
      except (TypeError, ValueError):
        raise TypeError("distance_to operand must be a Vector2 or iterable of length 2")
      
    def to_tuple(self):
      return (self.x, self.y)
      
    @classmethod
    def from_tuple(cls, tup):
      return cls(tup)
      
    def cross(self, other):
      if isinstance(other, Vector2):
        return self.x * other.y - self.y * other.x
      try:
        ox, oy = other
        return self.x * oy - self.y * ox
      except (TypeError, ValueError):
        raise TypeError("cross operand must be a Vector2 or iterable of length 2")

    def rotate(self, angle):
      cos_a = math.cos(angle)
      sin_a = math.sin(angle)
      return Vector2(
        self.x * cos_a - self.y * sin_a,
        self.x * sin_a + self.y * cos_a
      )
      
    def rotate_deg(self, angle):
      return self.rotate(math.radians(angle))

    def angle(self):
      return math.atan2(self.y, self.x)