# Documentation

## Creating Vectors

The constructor takes either two numbers or a single iterable.

```python
from ezvectors import Vector2

v = Vector2(3, 4)       # from x, y
v = Vector2((3, 4))     # from a tuple
v = Vector2([3, 4])     # from a list
v = Vector2(other_vec)  # copy another Vector2
```

Access components directly:

```python
v.x  # 3
v.y  # 4
```

## Arithmetic

All arithmetic operators return new vectors. The original is never modified.

```python
a = Vector2(3, 4)
b = Vector2(1, 2)

a + b       # Vector2(4, 6)
a - b       # Vector2(2, 2)
a * 3       # Vector2(9, 12)
3 * a       # Vector2(9, 12)
a / 2       # Vector2(1.5, 2.0)
-a          # Vector2(-3, -4)
```

Tuples and lists work as the right-hand operand:

```python
a + (1, 1)  # Vector2(4, 5)
a - [1, 1]  # Vector2(2, 3)
```

## Equality

Vectors compare by value, not identity. You can also compare directly against tuples.

```python
Vector2(1, 2) == Vector2(1, 2)  # True
Vector2(1, 2) == (1, 2)         # True
Vector2(1, 2) != (3, 4)         # True
```

## Indexing and Iteration

Vectors support indexing (including negative indices) and unpacking.

```python
v = Vector2(10, 20)

v[0]    # 10
v[1]    # 20
v[-1]   # 20
v[-2]   # 10

x, y = v  # unpacking
list(v)   # [10, 20]
```

## Methods

### `magnitude()`

Returns the length of the vector.

```python
Vector2(3, 4).magnitude()  # 5.0
```

### `magnitude_squared()`

Returns the squared length. Useful when you only need to compare distances and want to avoid the `sqrt` call.

```python
Vector2(3, 4).magnitude_squared()  # 25
```

### `normalize()`

Returns a unit vector pointing in the same direction. Returns `Vector2(0, 0)` for zero vectors.

```python
Vector2(3, 4).normalize()  # Vector2(0.6, 0.8)
Vector2(0, 0).normalize()  # Vector2(0, 0)
```

### `dot(other)`

Dot product. Accepts a `Vector2` or any 2-element iterable.

```python
Vector2(3, 4).dot(Vector2(1, 2))  # 11
Vector2(3, 4).dot((1, 2))         # 11
```

### `cross(other)`

2D cross product (returns a scalar). This is the z-component of the 3D cross product if both vectors were extended to 3D with z=0.

```python
Vector2(3, 4).cross(Vector2(5, 6))  # -2
```

### `distance_to(other)`

Euclidean distance between two points. Accepts a `Vector2` or a tuple.

```python
Vector2(0, 0).distance_to(Vector2(3, 4))  # 5.0
Vector2(0, 0).distance_to((3, 4))          # 5.0
```

### `rotate(angle)`

Rotates the vector by the given angle in **radians**, counterclockwise.

```python
import math
Vector2(1, 0).rotate(math.pi / 2)  # Vector2(~0, 1)
```

### `rotate_deg(angle)`

Same as `rotate()`, but takes the angle in **degrees**.

```python
Vector2(1, 0).rotate_deg(90)  # Vector2(~0, 1)
```

### `angle()`

Returns the angle of the vector in radians, measured counterclockwise from the positive x-axis. Uses `atan2`.

```python
Vector2(1, 1).angle()   # 0.7853... (π/4)
Vector2(0, 1).angle()   # 1.5707... (π/2)
Vector2(-1, 0).angle()  # 3.1415... (π)
```

### `to_tuple()`

Returns the vector as a plain `(x, y)` tuple.

```python
Vector2(3, 4).to_tuple()  # (3, 4)
```

### `Vector2.from_tuple(tup)` (classmethod)

Creates a vector from a tuple. Equivalent to `Vector2(tup)`, but reads more explicitly in code that deals heavily with tuples.

```python
Vector2.from_tuple((3, 4))  # Vector2(3, 4)
```

## Running Tests

The test suite uses [pytest](https://docs.pytest.org/). Install it and run from the project root:

```bash
pip install pytest
pytest tests/
```

To run with verbose output:

```bash
pytest tests/ -v
```

To run a specific test:

```bash
pytest tests/test_vector2.py::test_dot
```
