import pytest
from pydantic import ValidationError
from llm_adapter.models import LLMRequest, OpenAIConfig

def test_request_validation_success():
    req = LLMRequest(system_message="test", prompt="hi", temperature=1.5)
    assert req.temperature == 1.5

def test_request_validation_fail_range():
    with pytest.raises(ValidationError):
        # Temperature must be <= 2.0
        LLMRequest(system_message="test", prompt="hi", temperature=5.0)

def test_config_validation_fail_missing_token():
    with pytest.raises(ValidationError):
        # OpenAI requires a token
        OpenAIConfig(service="GPT", model="gpt-4")