import pytest
import httpx
from llm_adapter.models import LLMRequest, OpenAIConfig
from llm_adapter.providers.openai import OpenAIAdapter

def test_openai_submit_success(mocker):
    # 1. Setup Mock Response
    mock_response = mocker.Mock(spec=httpx.Response)
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "choices": [{"message": {"content": "Mocked Answer"}}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}
    }
    
    # 2. Patch the httpx.Client.post method
    mocker.patch("httpx.Client.post", return_value=mock_response)

    # 3. Execute
    config = OpenAIConfig(service="GPT", token="fake-key")
    adapter = OpenAIAdapter(config)
    req = LLMRequest(system_message="sys", prompt="user")
    res = adapter.submit(req)

    # 4. Assertions
    assert res.content == "Mocked Answer"
    assert res.provider == "OpenAI"
    assert res.usage["total_tokens"] == 15