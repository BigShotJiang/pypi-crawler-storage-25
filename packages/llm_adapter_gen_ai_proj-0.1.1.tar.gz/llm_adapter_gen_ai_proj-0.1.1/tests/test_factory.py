from llm_adapter import LLMAdapter, OpenAIConfig
from llm_adapter.providers.openai import OpenAIAdapter

def test_factory_returns_openai():
    config = OpenAIConfig(service="GPT", token="fake-key")
    adapter = LLMAdapter.get_adapter(config)
    assert isinstance(adapter, OpenAIAdapter)
    assert adapter.api_key == "fake-key"