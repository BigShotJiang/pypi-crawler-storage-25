from abc import ABC, abstractmethod
from .models import LLMRequest, LLMResponse

class BaseAdapter(ABC):
    @abstractmethod
    def submit(self, request: LLMRequest) -> LLMResponse:
        pass