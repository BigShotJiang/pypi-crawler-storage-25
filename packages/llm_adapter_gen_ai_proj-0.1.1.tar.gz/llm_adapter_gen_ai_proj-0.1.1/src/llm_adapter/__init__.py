from .models import (
    LLMRequest, 
    LLMResponse, 
    OpenAIConfig, 
    BedrockConfig, 
    ServiceConfig
)

from .models import ServiceConfig, OpenAIConfig, BedrockConfig
from .base import BaseAdapter
from .providers.openai import OpenAIAdapter
from .providers.bedrock import BedrockAdapter

class LLMAdapter:
    @staticmethod
    def get_adapter(config: ServiceConfig) -> BaseAdapter:
        if isinstance(config, OpenAIConfig):
            return OpenAIAdapter(config)
        elif isinstance(config, BedrockConfig):
            return BedrockAdapter(config)
            
        raise ValueError("Unknown configuration type")