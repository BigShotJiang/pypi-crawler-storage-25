from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, Dict, Any, Union, Literal

class LLMRequest(BaseModel):
    system_message: str = Field(..., description="The behavioral instruction for the AI")
    prompt: str = Field(..., description="The user's specific query")
    temperature: float = Field(default=0.7, ge=0, le=2)
    max_tokens: int = Field(default=500)

class LLMResponse(BaseModel):
    content: str
    usage: Dict[str, int]  # e.g., {"prompt_tokens": 50, "completion_tokens": 100}
    provider: str
    model_name: str

class OpenAIConfig(BaseModel):
    service: Literal["GPT"]
    token: str
    model: str = "gpt-4"
    api_url: HttpUrl = Field(default="https://api.openai.com/v1/chat/completions")
    timeout: float = 30.0

class BedrockConfig(BaseModel):
    service: Literal["BEDROCK"]
    region: str = "us-east-1"
    model: str = "anthropic.claude-3-haiku-20240307-v1:0"
    timeout: float = 60.0

# This type alias allows the Factory to accept either config type
ServiceConfig = Union[OpenAIConfig, BedrockConfig]