import json
import boto3
from botocore.config import Config
from ..base import BaseAdapter
from ..models import LLMRequest, LLMResponse, BedrockConfig

class BedrockAdapter(BaseAdapter):
    def __init__(self, config: BedrockConfig):
        # Retry config handles transient AWS network issues
        retry_config = Config(
            region_name=config.region,
            retries={'max_attempts': 3, 'mode': 'standard'}
        )
        
        # This client will automatically find credentials in any environment
        self.client = boto3.client("bedrock-runtime", config=retry_config)
        self.model_id = config.model
        self.timeout = config.timeout

    def submit(self, request: LLMRequest) -> LLMResponse:
        # Mapping generic request to Bedrock/Claude's specific body format
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": request.max_tokens,
            "system": request.system_message,
            "messages": [
                {"role": "user", "content": request.prompt}
            ],
            "temperature": request.temperature
        })

        try:
            response = self.client.invoke_model(
                body=body, 
                modelId=self.model_id,
                accept="application/json",
                contentType="application/json"
            )
            
            response_body = json.loads(response.get("body").read())

            return LLMResponse(
                content=response_body["content"][0]["text"],
                usage={
                    "prompt_tokens": response_body["usage"]["input_tokens"],
                    "completion_tokens": response_body["usage"]["output_tokens"],
                    "total_tokens": (
                        response_body["usage"]["input_tokens"] + 
                        response_body["usage"]["output_tokens"]
                    )
                },
                provider="AWS Bedrock",
                model_name=self.model_id
            )

        except Exception as e:
            raise RuntimeError(f"Bedrock invocation failed: {str(e)}")