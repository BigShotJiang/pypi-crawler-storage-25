import httpx
from ..base import BaseAdapter
from ..models import LLMRequest, LLMResponse, OpenAIConfig

class OpenAIAdapter(BaseAdapter):
    def __init__(self, config: OpenAIConfig):
        # Because we use the Pydantic model, these are guaranteed to exist
        self.api_key = config.token
        self.base_url = str(config.api_url)  # HttpUrl to string
        self.model = config.model
        self.timeout = config.timeout

    def submit(self, request: LLMRequest) -> LLMResponse:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        # Mapping our generic request to OpenAI's specific JSON format
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": request.system_message},
                {"role": "user", "content": request.prompt}
            ],
            "temperature": request.temperature,
            "max_tokens": request.max_tokens
        }

        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.post(self.base_url, headers=headers, json=payload)
                
                # Automatically raises an exception for 4xx/5xx responses
                response.raise_for_status()
                
                data = response.json()

            # Mapping OpenAI's response back to our generic LLMResponse
            return LLMResponse(
                content=data["choices"][0]["message"]["content"],
                usage={
                    "prompt_tokens": data["usage"]["prompt_tokens"],
                    "completion_tokens": data["usage"]["completion_tokens"],
                    "total_tokens": data["usage"]["total_tokens"]
                },
                provider="OpenAI",
                model_name=self.model
            )

        except httpx.HTTPStatusError as e:
            # Handle specific API errors (Unauthorized, Rate Limited, etc.)
            raise RuntimeError(f"OpenAI API Error ({e.response.status_code}): {e.response.text}")
        except httpx.RequestError as e:
            # Handle network-level errors (DNS, Connection Timeout)
            raise ConnectionError(f"Failed to connect to OpenAI at {self.base_url}: {e}")