# europatech

Official Python SDK for the [Europa Tech](https://europa-tech.org) real estate tokenization API.

## Installation

```bash
pip install europatech
```

## Quick Start

```python
from europatech import EuropaTech

client = EuropaTech(api_key="your-api-key")

# List available properties
objects = client.list_objects()
for obj in objects:
    print(f"{obj.name}: {obj.available_shares} shares available")

# Get your portfolio
portfolio = client.get_portfolio()
print(f"Total value: EUR {portfolio.total_value}")

# Get room prices
rooms = client.list_rooms("obj-001")
for room in rooms:
    print(f"{room.name}: EUR {room.share_price}/share")
```

## API Reference

### Objects

```python
client.list_objects()                      # List all properties
client.get_object("obj-001")               # Get property details
client.list_rooms("obj-001")               # Get rooms with share prices
```

### Portfolio

```python
client.get_portfolio()                     # Your holdings
client.list_transactions(page=1, limit=20) # Transaction history
```

### P2P Marketplace

```python
client.list_p2p()                          # Active listings
client.create_p2p_listing(                 # Sell shares
    object_id="obj-001",
    room_id="room-101",
    shares=5,
    price_per_share=70.0,
)
client.cancel_p2p_listing("listing-id")    # Cancel listing
```

### Investment

```python
client.invest(                             # Buy shares
    object_id="obj-001",
    room_id="room-101",
    shares=10,
    payment_method="CARD",
)
```

### Market & Fund

```python
client.get_market_rates()                  # EUR/USD, BTC, ETH rates
client.get_fund()                          # AUM, distributions
```

### Compliance

```python
client.get_compliance_status()             # KYC/AML status
```

## Webhooks

```python
from europatech.webhooks import verify_webhook, parse_webhook_event

# Verify signature
is_valid = verify_webhook(request.body, request.headers["X-EuropaTech-Signature"], secret)

# Parse event
event = parse_webhook_event(request.body)
print(event.type)  # "investment.completed"
```

## Context Manager

```python
with EuropaTech(api_key="your-key") as client:
    objects = client.list_objects()
```

## License

MIT — Europa Tech Enterprise S.R.L.
