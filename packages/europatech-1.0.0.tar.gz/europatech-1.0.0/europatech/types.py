"""Type definitions for Europa Tech API responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


class ApiError(Exception):
    """API error with status code and error code."""

    def __init__(self, status: int, message: str, code: str = "UNKNOWN_ERROR") -> None:
        super().__init__(message)
        self.status = status
        self.code = code


@dataclass(frozen=True)
class Room:
    id: str
    name: str
    number: int
    share_price: float
    total_shares: int
    available_shares: int
    status: str


@dataclass(frozen=True)
class RealEstateObject:
    id: str
    name: str
    location: str
    image_url: str
    status: str
    total_shares: int
    available_shares: int
    rooms: list[Room] = field(default_factory=list)


@dataclass(frozen=True)
class Holding:
    object_id: str
    object_name: str
    room_id: str
    room_name: str
    shares: int
    share_price: float
    value: float
    purchased_at: str


@dataclass(frozen=True)
class Portfolio:
    total_value: float
    total_shares: int
    total_invested: float
    holdings: list[Holding] = field(default_factory=list)


@dataclass(frozen=True)
class Transaction:
    id: str
    type: str
    object_id: str
    room_id: str
    shares: int
    price_per_share: float
    total_amount: float
    status: str
    created_at: str


@dataclass(frozen=True)
class P2PListing:
    id: str
    object_id: str
    room_id: str
    seller_id: str
    shares: int
    price_per_share: float
    status: str
    created_at: str


@dataclass(frozen=True)
class MarketRates:
    eur_usd: float
    btc_eur: float
    eth_eur: float
    updated_at: str


@dataclass(frozen=True)
class InvestResult:
    transaction_id: str
    status: str
    total_amount: float
    currency: str


@dataclass(frozen=True)
class Distribution:
    month: str
    revenue: float
    expenses: float
    net_profit: float
    distributed_per_share: float
    status: str


@dataclass(frozen=True)
class Fund:
    total_aum: float
    total_investors: int
    total_properties: int
    total_rooms: int
    distributions: list[Distribution] = field(default_factory=list)


@dataclass(frozen=True)
class ComplianceStatus:
    kyc_status: str
    kyc_level: int
    aml_status: str
    investment_limit: float
    invested_amount: float
