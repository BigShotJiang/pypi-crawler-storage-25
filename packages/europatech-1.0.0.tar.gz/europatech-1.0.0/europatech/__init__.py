"""Official Python SDK for the Europa Tech real estate tokenization API."""

from europatech.client import EuropaTech
from europatech.types import (
    RealEstateObject,
    Room,
    Portfolio,
    Holding,
    Transaction,
    P2PListing,
    MarketRates,
    InvestResult,
    Fund,
    Distribution,
    ComplianceStatus,
    ApiError,
)

__version__ = "1.0.0"
__all__ = [
    "EuropaTech",
    "RealEstateObject",
    "Room",
    "Portfolio",
    "Holding",
    "Transaction",
    "P2PListing",
    "MarketRates",
    "InvestResult",
    "Fund",
    "Distribution",
    "ComplianceStatus",
    "ApiError",
]
