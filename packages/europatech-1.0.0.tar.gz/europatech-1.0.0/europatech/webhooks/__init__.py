"""Webhook verification for Europa Tech."""

from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass
from typing import Any, Literal


def verify_webhook(payload: str | bytes, signature: str, secret: str) -> bool:
    """Verify an incoming Europa Tech webhook signature (HMAC-SHA256).

    Args:
        payload: Raw request body.
        signature: Value of the X-EuropaTech-Signature header.
        secret: Your webhook secret from the dashboard.

    Returns:
        True if the signature is valid.

    Example::

        from europatech.webhooks import verify_webhook

        @app.post("/webhook")
        def handle_webhook(request):
            sig = request.headers["X-EuropaTech-Signature"]
            if not verify_webhook(request.body, sig, WEBHOOK_SECRET):
                return {"error": "Invalid signature"}, 401
            event = parse_webhook_event(request.body)
            ...
    """
    if not payload or not signature or not secret:
        return False

    if isinstance(payload, str):
        payload = payload.encode()

    expected = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    sig = signature.removeprefix("sha256=")

    return hmac.compare_digest(expected, sig)


WebhookEventType = Literal[
    "investment.completed",
    "investment.failed",
    "p2p.listing.created",
    "p2p.listing.sold",
    "p2p.listing.cancelled",
    "distribution.published",
    "kyc.approved",
    "kyc.rejected",
    "transfer.completed",
]


@dataclass(frozen=True)
class WebhookEvent:
    id: str
    type: WebhookEventType
    created_at: str
    data: dict[str, Any]


def parse_webhook_event(payload: str | bytes) -> WebhookEvent:
    """Parse a webhook payload into a typed event object."""
    raw = payload if isinstance(payload, str) else payload.decode()
    d = json.loads(raw)
    return WebhookEvent(
        id=d["id"],
        type=d["type"],
        created_at=d.get("createdAt", ""),
        data=d.get("data", {}),
    )
