"""Europa Tech API client."""

from __future__ import annotations

from typing import Any, Optional

import httpx

from europatech.types import (
    ApiError,
    ComplianceStatus,
    Distribution,
    Fund,
    Holding,
    InvestResult,
    MarketRates,
    P2PListing,
    Portfolio,
    RealEstateObject,
    Room,
    Transaction,
)

DEFAULT_BASE_URL = "https://api.europa-tech.org"


def _to_snake(name: str) -> str:
    """Convert camelCase to snake_case."""
    result: list[str] = []
    for c in name:
        if c.isupper() and result:
            result.append("_")
        result.append(c.lower())
    return "".join(result)


def _snake_keys(data: Any) -> Any:
    """Recursively convert dict keys from camelCase to snake_case."""
    if isinstance(data, dict):
        return {_to_snake(k): _snake_keys(v) for k, v in data.items()}
    if isinstance(data, list):
        return [_snake_keys(item) for item in data]
    return data


class EuropaTech:
    """Official Europa Tech API client.

    Usage::

        from europatech import EuropaTech

        client = EuropaTech(api_key="your-api-key")
        objects = client.list_objects()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "X-SDK-Version": "python/1.0.0",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> "EuropaTech":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def _request(self, method: str, path: str, json: Any = None) -> Any:
        resp = self._client.request(method, path, json=json)
        if resp.status_code >= 400:
            try:
                body = resp.json()
                msg = body.get("error", resp.reason_phrase)
                code = body.get("code", "UNKNOWN_ERROR")
            except Exception:
                msg = resp.reason_phrase
                code = "UNKNOWN_ERROR"
            raise ApiError(resp.status_code, msg, code)
        return resp.json()

    # ─── Objects ──────────────────────────────────────────

    def list_objects(self) -> list[RealEstateObject]:
        """List all real estate objects."""
        data = self._request("GET", "/api/v1/objects")["data"]
        return [RealEstateObject(**_snake_keys(o)) for o in data]

    def get_object(self, object_id: str) -> RealEstateObject:
        """Get a single object by ID."""
        data = self._request("GET", f"/api/v1/objects/{object_id}")["data"]
        return RealEstateObject(**_snake_keys(data))

    def list_rooms(self, object_id: str) -> list[Room]:
        """Get rooms for an object."""
        data = self._request("GET", f"/api/v1/objects/{object_id}/rooms")["data"]
        return [Room(**_snake_keys(r)) for r in data]

    # ─── Portfolio ────────────────────────────────────────

    def get_portfolio(self) -> Portfolio:
        """Get current user's portfolio."""
        raw = _snake_keys(self._request("GET", "/api/v1/portfolio")["data"])
        raw["holdings"] = [Holding(**h) for h in raw.get("holdings", [])]
        return Portfolio(**raw)

    def list_transactions(
        self,
        page: int = 1,
        limit: int = 20,
        type: Optional[str] = None,
    ) -> list[Transaction]:
        """List portfolio transactions."""
        params = f"?page={page}&limit={limit}"
        if type:
            params += f"&type={type}"
        data = self._request("GET", f"/api/v1/portfolio/transactions{params}")["data"]
        return [Transaction(**_snake_keys(t)) for t in data]

    # ─── P2P Marketplace ──────────────────────────────────

    def list_p2p(self) -> list[P2PListing]:
        """List P2P listings."""
        data = self._request("GET", "/api/v1/p2p")["data"]
        return [P2PListing(**_snake_keys(l)) for l in data]

    def create_p2p_listing(
        self,
        object_id: str,
        room_id: str,
        shares: int,
        price_per_share: float,
    ) -> P2PListing:
        """Create a P2P sell listing."""
        data = self._request("POST", "/api/v1/p2p", json={
            "objectId": object_id,
            "roomId": room_id,
            "shares": shares,
            "pricePerShare": price_per_share,
        })["data"]
        return P2PListing(**_snake_keys(data))

    def cancel_p2p_listing(self, listing_id: str) -> None:
        """Cancel a P2P listing."""
        self._request("DELETE", f"/api/v1/p2p/{listing_id}")

    # ─── Market ───────────────────────────────────────────

    def get_market_rates(self) -> MarketRates:
        """Get current market rates."""
        data = self._request("GET", "/api/v1/market/rates")["data"]
        return MarketRates(**_snake_keys(data))

    # ─── Investment ───────────────────────────────────────

    def invest(
        self,
        object_id: str,
        room_id: str,
        shares: int,
        payment_method: str = "CARD",
    ) -> InvestResult:
        """Execute a share purchase."""
        data = self._request("POST", "/api/v1/invest", json={
            "objectId": object_id,
            "roomId": room_id,
            "shares": shares,
            "paymentMethod": payment_method,
        })["data"]
        return InvestResult(**_snake_keys(data))

    # ─── Fund ─────────────────────────────────────────────

    def get_fund(self) -> Fund:
        """Get fund overview."""
        raw = _snake_keys(self._request("GET", "/api/v1/fund")["data"])
        raw["distributions"] = [Distribution(**d) for d in raw.get("distributions", [])]
        return Fund(**raw)

    # ─── Compliance ───────────────────────────────────────

    def get_compliance_status(self) -> ComplianceStatus:
        """Get current user's KYC/AML compliance status."""
        data = self._request("GET", "/api/v1/compliance/status")["data"]
        return ComplianceStatus(**_snake_keys(data))
