import devito
print("loaded")
