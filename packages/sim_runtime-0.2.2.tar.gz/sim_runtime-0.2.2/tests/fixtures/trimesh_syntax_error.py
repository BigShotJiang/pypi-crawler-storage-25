import trimesh
def broken(:
