import os
from dataclasses import dataclass
from typing import Optional

SDK_VERSION = "1.4.0"


@dataclass
class ClientConfig:
    """Configuration for the Reasoning Layer client.

    Required fields: ``base_url`` and ``tenant_id``. All other fields have
    sensible defaults. If ``api_key`` is not provided, the client will fall
    back to the ``API_KEY`` environment variable.
    """

    base_url: str
    tenant_id: str

    user_id: Optional[str] = None
    namespace_id: Optional[str] = None
    authenticated_user: Optional[str] = None
    api_key: Optional[str] = None

    timeout_ms: int = 30000
    max_retries: int = 3
    retry_on_503: bool = False

    def __post_init__(self):
        if self.api_key is None:
            self.api_key = "Bearer " + (os.environ.get("API_KEY") or "")
