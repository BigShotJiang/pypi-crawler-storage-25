from typing import Any, Optional, Dict


class ReasoningLayerError(Exception):
    """
    Base error class for all Reasoning Layer SDK errors.

    All errors thrown by the SDK extend this class, enabling catch-all handling:

    try:
        ...
    except ReasoningLayerError as e:
        ...
    """


class ApiError(ReasoningLayerError, TypeError):
    """
    HTTP API error (4xx/5xx response from the backend).

    Carries the HTTP status code, parsed response body, and response headers.
    """

    def __init__(
        self,
        message: str | None,
        status: int | None,
        body: Any,
        headers: Dict[str, str],
        error_code: str | int | None = None,
    ) -> None:
        self.status = status
        self.body = body
        self.headers = headers
        self.error_code = error_code
        full_msg = message
        super(ApiError, self).__init__(full_msg)


class BadRequestError(ApiError):
    """HTTP 400"""


class AuthenticationError(ApiError):
    """HTTP 401"""


class ForbiddenError(ApiError):
    """HTTP 403"""


class NotFoundError(ApiError):
    """HTTP 404"""


class ConstraintViolationError(ApiError):
    """
    HTTP 409 — constraint violation with structured details.
    """

    def __init__(
        self,
        message: str | None,
        body: Any,
        headers: Dict[str, str],
        error_code: str | int | None = None,
        term_id: Optional[str] = None,
        feature: Optional[str] = None,
        constraint: Optional[str] = None,
    ):
        super().__init__(message, 409, body, headers, error_code)
        self.term_id = term_id
        self.feature = feature
        self.constraint = constraint


class RateLimitError(ApiError):
    """
    HTTP 429 — rate limited.
    """

    def __init__(
        self,
        message: str | None,
        body: Any,
        headers: Dict[str, str],
        error_code: str | int | None = None,
        retry_after: Optional[int] = None,
        limit: Optional[int] = None,
        remaining: Optional[int] = None,
    ):
        super().__init__(message, 429, body, headers, error_code)
        self.retry_after = retry_after
        self.limit = limit
        self.remaining = remaining


class InternalServerError(ApiError):
    """HTTP 500+"""


class TimeoutError(ReasoningLayerError):
    def __init__(self, timeout_ms: int):
        super().__init__(f"Request timed out after {timeout_ms}ms")
        self.timeout_ms = timeout_ms


class ValidationError(ReasoningLayerError):
    def __init__(self, message: str, field: Optional[str] = None):
        super().__init__(message)
        self.field = field


class NetworkError(ReasoningLayerError):
    def __init__(self, message: str, cause: Optional[Exception] = None):
        super().__init__(message, cause)


def parse_numeric_header(headers: Dict[str, str], name: str) -> Optional[int]:
    value = headers.get(name.lower())
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


def create_api_error(status: int, body: Any, headers: Dict[str, str]) -> ApiError:
    error_code = body.get("error") if isinstance(body, dict) else None
    message = body.get("message") if isinstance(body, dict) else f"HTTP {status}"

    if status == 400:
        return BadRequestError(message, error_code, body, headers)

    if status == 401:
        return AuthenticationError(message, error_code, body, headers)

    if status == 403:
        return ForbiddenError(message, error_code, body, headers)

    if status == 404:
        return NotFoundError(message, error_code, body, headers)

    if status == 409:
        details = body.get("details", {}) if isinstance(body, dict) else {}
        return ConstraintViolationError(
            message,
            body,
            headers,
            error_code,
            term_id=details.get("term_id"),
            feature=details.get("feature"),
            constraint=details.get("constraint"),
        )

    if status == 429:
        return RateLimitError(
            message,
            body,
            headers,
            error_code,
            retry_after=parse_numeric_header(headers, "retry-after"),
            limit=parse_numeric_header(headers, "x-ratelimit-limit"),
            remaining=parse_numeric_header(headers, "x-ratelimit-remaining"),
        )

    if status >= 500:
        return InternalServerError(message, status, body, headers, error_code)

    return ApiError(message, status, body, headers, error_code)
