from .config import ClientConfig
from .generated.api_client import ApiClient, Configuration
from .resources.action_reviews import ActionReviewsClient
from .resources.admin import AdminClient
from .resources.analysis import AnalysisClient
from .resources.arithmetic import ArithmeticClient
from .resources.audit import AuditClient
from .resources.causal import CausalClient
from .resources.cdl import CdlClient
from .resources.cognitive import CognitiveClient
from .resources.cognitive_agents_episodic_memory import (
    CognitiveAgentsEpisodicMemoryClient,
)
from .resources.cognitive_agents_htn import CognitiveAgentsHtnClient
from .resources.cognitive_agents_messaging import CognitiveAgentsMessagingClient
from .resources.cognitive_agents_plan_library import CognitiveAgentsPlanLibraryClient
from .resources.collections import CollectionsClient
from .resources.communities import CommunitiesClient
from .resources.constraints import ConstraintsClient
from .resources.context import ContextClient
from .resources.control import ControlClient
from .resources.conversation import ConversationClient
from .resources.copy import CopyClient
from .resources.discovery import DiscoveryClient
from .resources.document_analysis import DocumentAnalysisClient
from .resources.execution import ExecutionClient
from .resources.extraction import ExtractionClient
from .resources.functions import FunctionsClient
from .resources.fuzzy import FuzzyClient
from .resources.generation import GenerationClient
from .resources.health import HealthClient
from .resources.ilp import IlpClient
from .resources.image_extraction import ImageExtractionClient
from .resources.ingestion import IngestionClient
from .resources.inference import InferenceClient
from .resources.namespaces import NamespacesClient
from .resources.neuro_symbolic import NeuroSymbolicClient
from .resources.ontology import OntologyClient
from .resources.ontology_bridge import OntologyBridgeClient
from .resources.osfql import OsfqlClient
from .resources.oversight import OversightClient
from .resources.preferences import PreferencesClient
from .resources.proof import ProofEngineClient
from .resources.query import QueryClient
from .resources.rag import RagClient
from .resources.reasoning import ReasoningClient
from .resources.reviews import ReviewsClient
from .resources.rl_training import RlTrainingClient
from .resources.row_polymorphism import RowPolymorphismClient
from .resources.scenarios import ScenariosClient
from .resources.snapshots import SnapshotsClient
from .resources.sort import SortsClient
from .resources.spaces import SpacesClient
from .resources.statistical import StatisticalClient
from .resources.structured_ingestion import StructuredIngestionClient
from .resources.strings import StringsClient
from .resources.synthetic import SyntheticClient
from .resources.templates import TemplatesClient
from .resources.terms import TermsClient
from .resources.types import TypesClient
from .resources.ui import UiClient
from .resources.visualization import VisualizationClient
from .resources.webhook_actions import WebhookActionsClient


class ReasoningLayerClient:
    """User-facing entry point for the Reasoning Layer SDK."""

    def __init__(self, config: ClientConfig) -> None:
        conf = Configuration(
            host=config.base_url,
            retries=config.max_retries,
        )
        self._api_client = ApiClient(configuration=conf)
        self._config = config

        if config.tenant_id:
            self._api_client.set_default_header("X-Tenant-Id", config.tenant_id)
        if config.api_key:
            self._api_client.set_default_header("Authorization", config.api_key)

        # Expose resource clients
        self.action_reviews = ActionReviewsClient(self._api_client)
        self.admin = AdminClient(self._api_client)
        self.analysis = AnalysisClient(self._api_client)
        self.arithmetic = ArithmeticClient(self._api_client)
        self.audit = AuditClient(self._api_client)
        self.causal = CausalClient(self._api_client)
        self.cdl = CdlClient(self._api_client)
        self.cognitive = CognitiveClient(self._api_client)
        self.cognitive_agents_episodic_memory = CognitiveAgentsEpisodicMemoryClient(
            self._api_client
        )
        self.cognitive_agents_htn = CognitiveAgentsHtnClient(self._api_client)
        self.cognitive_agents_messaging = CognitiveAgentsMessagingClient(
            self._api_client
        )
        self.cognitive_agents_plan_library = CognitiveAgentsPlanLibraryClient(
            self._api_client
        )
        self.collections = CollectionsClient(self._api_client)
        self.communities = CommunitiesClient(self._api_client)
        self.constraints = ConstraintsClient(self._api_client)
        self.context = ContextClient(self._api_client)
        self.control = ControlClient(self._api_client)
        self.conversation = ConversationClient(self._api_client)
        self.copy = CopyClient(self._api_client)
        self.discovery = DiscoveryClient(self._api_client)
        self.document_analysis = DocumentAnalysisClient(self._api_client)
        self.execution = ExecutionClient(self._api_client)
        self.extraction = ExtractionClient(self._api_client)
        self.functions = FunctionsClient(self._api_client)
        self.fuzzy = FuzzyClient(self._api_client)
        self.generation = GenerationClient(self._api_client)
        self.health = HealthClient(self._api_client)
        self.ilp = IlpClient(self._api_client)
        self.image_extraction = ImageExtractionClient(self._api_client)
        self.ingestion = IngestionClient(self._api_client)
        self.inference = InferenceClient(self._api_client)
        self.namespaces = NamespacesClient(self._api_client)
        self.neuro_symbolic = NeuroSymbolicClient(self._api_client)
        self.ontology = OntologyClient(self._api_client)
        self.ontology_bridge = OntologyBridgeClient(self._api_client)
        self.osfql = OsfqlClient(self._api_client)
        self.oversight = OversightClient(self._api_client)
        self.preferences = PreferencesClient(self._api_client)
        self.proof = ProofEngineClient(self._api_client)
        self.query = QueryClient(self._api_client)
        self.rag = RagClient(self._api_client)
        self.reasoning = ReasoningClient(self._api_client)
        self.reviews = ReviewsClient(self._api_client)
        self.rl_training = RlTrainingClient(self._api_client)
        self.row_polymorphism = RowPolymorphismClient(self._api_client)
        self.scenarios = ScenariosClient(self._api_client)
        self.snapshots = SnapshotsClient(self._api_client)
        self.sorts = SortsClient(self._api_client)
        self.spaces = SpacesClient(self._api_client)
        self.statistical = StatisticalClient(self._api_client)
        self.structured_ingestion = StructuredIngestionClient(self._api_client)
        self.strings = StringsClient(self._api_client)
        self.synthetic = SyntheticClient(self._api_client)
        self.templates = TemplatesClient(self._api_client)
        self.terms = TermsClient(self._api_client)
        self.types = TypesClient(self._api_client)
        self.ui = UiClient(self._api_client)
        self.visualization = VisualizationClient(self._api_client)
        self.webhook_actions = WebhookActionsClient(self._api_client)
