"""Convenience builders for constructing Reasoning Layer domain objects.

Example::

    from reasoning_layer_python_sdk.builders import Value, TermInput

    client.terms.create(
        sort_id=person_id,
        owner_id=tenant_id,
        features={
            "name": Value.string("Alice"),
            "age": Value.integer(30),
            "active": Value.boolean(True),
            "friend": Value.reference(friend_id),
        },
    )

    client.inference.backward_chain(
        goal=TermInput.reference(goal_term_id),
    )
"""

from typing import Any, Dict, List, Optional
from uuid import UUID

from ..generated.models.boolean import Boolean
from ..generated.models.feature_input_value_dto import FeatureInputValueDto
from ..generated.models.fuzzy_number import FuzzyNumber
from ..generated.models.fuzzy_number_value import FuzzyNumberValue
from ..generated.models.fuzzy_scalar import FuzzyScalar
from ..generated.models.fuzzy_scalar_value import FuzzyScalarValue
from ..generated.models.inline import Inline
from ..generated.models.inline_by_name import InlineByName
from ..generated.models.integer import Integer
from ..generated.models.list import List as ListModel
from ..generated.models.real import Real
from ..generated.models.reference import Reference
from ..generated.models.reference1 import Reference1
from ..generated.models.set import Set as SetModel
from ..generated.models.set_value import SetValue
from ..generated.models.string import String
from ..generated.models.term_input_dto import TermInputDto
from ..generated.models.uninstantiated import Uninstantiated
from ..generated.models.value_dto import ValueDto


class Value:
    """Factory for ``ValueDto`` instances.

    Every static method returns a ready-to-use ``ValueDto`` that can be placed
    directly in a term's ``features`` dict.
    """

    @staticmethod
    def string(value: str) -> ValueDto:
        """Create a string value."""
        return ValueDto.model_construct(
            actual_instance=String(type="String", value=value)
        )

    @staticmethod
    def integer(value: int) -> ValueDto:
        """Create an integer value."""
        return ValueDto.model_construct(
            actual_instance=Integer(type="Integer", value=value)
        )

    @staticmethod
    def real(value: float) -> ValueDto:
        """Create a real (float) value."""
        return ValueDto.model_construct(actual_instance=Real(type="Real", value=value))

    @staticmethod
    def boolean(value: bool) -> ValueDto:
        """Create a boolean value."""
        return ValueDto.model_construct(
            actual_instance=Boolean(type="Boolean", value=value)
        )

    @staticmethod
    def reference(term_id: UUID) -> ValueDto:
        """Create a reference to another term."""
        return ValueDto.model_construct(
            actual_instance=Reference1(type="Reference", value=term_id)
        )

    @staticmethod
    def uninstantiated() -> ValueDto:
        """Create an uninstantiated / logic-variable value."""
        return ValueDto.model_construct(
            actual_instance=Uninstantiated(type="Uninstantiated")
        )

    @staticmethod
    def list_of(*values: ValueDto) -> ValueDto:
        """Create a list of ``ValueDto`` items."""
        return ValueDto.model_construct(
            actual_instance=ListModel(type="List", value=list(values))
        )

    @staticmethod
    def fuzzy_scalar(
        value: float,
        *,
        membership: float = 1.0,
    ) -> ValueDto:
        """Create a fuzzy scalar with an optional membership degree."""
        return ValueDto.model_construct(
            actual_instance=FuzzyScalar(
                type="FuzzyScalar",
                value=FuzzyScalarValue(value=value, membership=membership),
            )
        )

    @staticmethod
    def fuzzy_number(value: FuzzyNumberValue) -> ValueDto:
        """Create a fuzzy number from a pre-built ``FuzzyNumberValue``."""
        return ValueDto.model_construct(
            actual_instance=FuzzyNumber(type="FuzzyNumber", value=value)
        )

    @staticmethod
    def set_value(
        lower: List[UUID],
        upper: Optional[List[UUID]] = None,
        sort_constraint: Optional[UUID] = None,
    ) -> ValueDto:
        """Create a set-valued feature with lower/upper bounds."""
        return ValueDto.model_construct(
            actual_instance=SetModel(  # type: ignore[call-overload]
                type="Set",
                value=SetValue(
                    lower=lower,
                    upper=upper or [],
                    sort_constraint=sort_constraint,
                ),
            )
        )


def _coerce_inline_feature(value: Any) -> FeatureInputValueDto:
    """Convert a plain Python value into a ``FeatureInputValueDto``."""
    if isinstance(value, FeatureInputValueDto):
        return value
    if isinstance(value, bool):
        return FeatureInputValueDto.model_construct(actual_instance=value)
    if isinstance(value, int):
        return FeatureInputValueDto.model_construct(actual_instance=value)
    if isinstance(value, float):
        return FeatureInputValueDto.model_construct(actual_instance=value)
    if isinstance(value, str):
        return FeatureInputValueDto.model_construct(actual_instance=value)
    if isinstance(value, list):
        return FeatureInputValueDto.model_construct(
            actual_instance=[_coerce_inline_feature(item) for item in value]
        )
    raise TypeError(f"Cannot coerce {type(value).__name__} to FeatureInputValueDto")


def _coerce_inline_features(
    features: Dict[str, Any],
) -> Dict[str, FeatureInputValueDto]:
    """Coerce every value in a feature dict to ``FeatureInputValueDto``."""
    return {k: _coerce_inline_feature(v) for k, v in features.items()}


class TermInput:
    """Factory for ``TermInputDto`` instances.

    These are used as *goals*, *facts*, and *clauses* in inference calls.
    """

    @staticmethod
    def reference(term_id: UUID) -> TermInputDto:
        """Reference an existing term by ID."""
        return TermInputDto(actual_instance=Reference(term_id=term_id))

    @staticmethod
    def inline(
        sort_id: UUID,
        features: Optional[Dict[str, Any]] = None,
    ) -> TermInputDto:
        """Define a term inline with a sort ID and optional features."""
        return TermInputDto(
            actual_instance=Inline(
                sort_id=sort_id,
                features=_coerce_inline_features(features or {}),
            )
        )

    @staticmethod
    def by_name(
        sort_name: str,
        features: Optional[Dict[str, Any]] = None,
    ) -> TermInputDto:
        """Define a term inline with a sort name (resolved server-side)."""
        return TermInputDto(
            actual_instance=InlineByName(
                sort_name=sort_name,
                features=_coerce_inline_features(features or {}),
            )
        )
