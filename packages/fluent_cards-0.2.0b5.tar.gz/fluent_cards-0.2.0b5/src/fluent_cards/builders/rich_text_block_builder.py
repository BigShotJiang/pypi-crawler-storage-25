from __future__ import annotations
from typing import Callable, TYPE_CHECKING
from ..enums import HorizontalAlignment, Spacing

if TYPE_CHECKING:
    from .text_run_builder import TextRunBuilder


class RichTextBlockBuilder:
    """Fluent builder for creating RichTextBlock elements."""

    def __init__(self):
        self._rich_text: dict = {'type': 'RichTextBlock', 'inlines': []}

    def with_id(self, id: str) -> RichTextBlockBuilder:
        """Sets the unique identifier for the RichTextBlock.

        Args:
            id: The unique identifier.

        Returns:
            The builder instance for method chaining.
        """
        self._rich_text['id'] = id
        return self

    def with_horizontal_alignment(self, alignment: HorizontalAlignment) -> RichTextBlockBuilder:
        """Sets the horizontal alignment of the rich text block.

        Args:
            alignment: The horizontal alignment.

        Returns:
            The builder instance for method chaining.
        """
        self._rich_text['horizontalAlignment'] = alignment.value
        return self

    def with_spacing(self, spacing: Spacing) -> RichTextBlockBuilder:
        """Sets the spacing before the rich text block.

        Args:
            spacing: The spacing value.

        Returns:
            The builder instance for method chaining.
        """
        self._rich_text['spacing'] = spacing.value
        return self

    def with_is_visible(self, is_visible: bool) -> RichTextBlockBuilder:
        """Sets whether the element is visible."""
        self._rich_text['isVisible'] = is_visible
        return self

    def with_separator(self, separator: bool = True) -> RichTextBlockBuilder:
        """Sets whether a separator line is drawn above the element."""
        self._rich_text['separator'] = separator
        return self

    def with_height(self, height: str) -> RichTextBlockBuilder:
        """Sets the height of the element."""
        self._rich_text['height'] = height
        return self

    def with_fallback(self, fallback) -> RichTextBlockBuilder:
        """Sets the fallback content if the element is unsupported."""
        self._rich_text['fallback'] = fallback
        return self

    def with_requires(self, key: str, version: str) -> RichTextBlockBuilder:
        """Sets a feature requirement for the element."""
        if 'requires' not in self._rich_text:
            self._rich_text['requires'] = {}
        self._rich_text['requires'][key] = version
        return self

    def with_rtl(self, rtl: bool = True) -> RichTextBlockBuilder:
        """Sets right-to-left text direction."""
        self._rich_text['rtl'] = rtl
        return self

    def add_text(self, text: str) -> RichTextBlockBuilder:
        """Adds a plain text inline string to the rich text block.

        Args:
            text: The text content to add.

        Returns:
            The builder instance for method chaining.
        """
        self._rich_text['inlines'].append(text)
        return self

    def add_text_run(self, configure: Callable[[TextRunBuilder], None]) -> RichTextBlockBuilder:
        """Adds a formatted TextRun inline to the rich text block.

        Args:
            configure: A callable that receives a TextRunBuilder to configure the inline.

        Returns:
            The builder instance for method chaining.
        """
        from .text_run_builder import TextRunBuilder
        b = TextRunBuilder()
        configure(b)
        self._rich_text['inlines'].append(b.build())
        return self

    def build(self) -> dict:
        """Builds and returns the configured RichTextBlock dictionary.

        Returns:
            The configured RichTextBlock dictionary.
        """
        return self._rich_text
