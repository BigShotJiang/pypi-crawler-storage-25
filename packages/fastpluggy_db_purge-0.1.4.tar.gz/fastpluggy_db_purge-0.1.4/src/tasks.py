import logging

from fastpluggy_plugin.tasks_worker import TaskWorker
from fastpluggy.core.database import session_scope

from .config import DbPurgeConfig
from .models import PurgeRuleDB
from .service import execute_purge, get_declared_targets

logger = logging.getLogger(__name__)


@TaskWorker.register(name="db_purge_all", description="Run all configured purge rules", allow_concurrent=False)
def db_purge_all():
    """Execute purge on all enabled rules."""
    config = DbPurgeConfig()
    total_deleted = 0
    results = []

    with session_scope() as db:
        rules = db.query(PurgeRuleDB).filter(PurgeRuleDB.enabled == True).all()
        logger.info("db_purge_all: found %d enabled rules", len(rules))
        declared = get_declared_targets()

        for rule in rules:
            decl = declared.get(rule.table_name)
            timestamp_column = (
                rule.timestamp_column
                or (decl["timestamp_column"] if decl else None)
                or config.default_timestamp_column
            )
            result = execute_purge(
                db=db,
                table_name=rule.table_name,
                retention_days=rule.retention_days or config.default_retention_days,
                timestamp_column=timestamp_column,
                batch_size=config.batch_size,
                dry_run=False,
                executed_by="scheduled",
            )
            results.append(result)
            total_deleted += result["rows_deleted"]
            logger.info(
                "db_purge_all: %s — deleted %d rows (%s)",
                rule.table_name, result["rows_deleted"], result["status"],
            )

    return {
        "tables_processed": len(results),
        "total_rows_deleted": total_deleted,
        "results": results,
    }
