# MostlyRight Deployment (Sprint 2g)

Fresh GCP VM. systemd services, no Docker. This directory is the entire deploy surface.

## Files

| File | Purpose |
|---|---|
| `mostlyright-poller.service` | AWC METAR poller (60s interval) |
| `mostlyright-merger.service` | AWC+IEM merge scheduler (15min interval) |
| `mostlyright-climate.service` + `.timer` | Daily NWS CLI sync (07:00 UTC) |
| `mostlyright-api.service` | FastAPI via uvicorn (0.0.0.0:8000) |
| `mostlyright-health.service` | Local watermark staleness server (127.0.0.1:8080) |
| `mostlyright-r2sync.service` + `.timer` | R2 → local parquet sync (every 5min) |
| `mostlyright-alert@.service` | OnFailure handler, instantiated per failing unit |
| `deploy.sh` | One-command deploy (ssh + git pull + restart) |
| `r2sync.sh` | Called by the r2sync timer |
| `alert-on-failure.sh` | Called by the alert@.service template |

## VM specification

```
Provider:  GCP Compute Engine
Machine:   e2-medium (2 vCPU, 4 GB RAM)
Disk:      50 GB pd-ssd
Region:    us-east4 (closest to NWS/IEM servers)
OS:        Ubuntu 24.04 LTS
Cost:      ~$25–30/month
```

The original therminal MVP ran Go on similar hardware. Python needs at least the
same because each API query loads a station-year parquet into memory (~100–200MB).
`e2-small` (2 GB RAM) is enough for the pollers alone but chokes the API under
concurrent queries, so budget for `e2-medium`.

## One-time VM provisioning

```bash
# 1. Create the VM
gcloud compute instances create mostlyright \
  --project=<PROJECT> \
  --zone=us-east4-a \
  --machine-type=e2-medium \
  --image-family=ubuntu-2404-lts-amd64 \
  --image-project=ubuntu-os-cloud \
  --boot-disk-size=50GB \
  --boot-disk-type=pd-ssd \
  --tags=http-server,https-server

# 2. SSH and provision
gcloud compute ssh mostlyright --zone=us-east4-a

# --- on the VM ---
sudo apt-get update
sudo apt-get install -y python3.12 python3.12-venv python3.12-dev git build-essential \
  awscli curl

# 3. Create the mostlyright user (runtime AND deploy target, see step 8 below
#    for why we don't separate them)
sudo useradd --system --create-home --shell /bin/bash mostlyright
sudo mkdir -p /data /opt/mostlyright/logs
sudo chown -R mostlyright:mostlyright /data /opt/mostlyright

# 4. Add the deploy SSH key so your dev box can ssh in as mostlyright.
#    Replace the ed25519 line with your actual public key.
sudo -u mostlyright mkdir -p /home/mostlyright/.ssh
sudo -u mostlyright chmod 700 /home/mostlyright/.ssh
sudo -u mostlyright tee /home/mostlyright/.ssh/authorized_keys <<'KEY'
ssh-ed25519 AAAA... your-deploy-key-here
KEY
sudo -u mostlyright chmod 600 /home/mostlyright/.ssh/authorized_keys

# 5. Clone repo + venv (as the mostlyright user — it owns /opt/mostlyright)
sudo -u mostlyright bash <<'EOF'
cd /opt/mostlyright
git clone https://github.com/Tarabcak/mostlyright.git .
python3.12 -m venv .venv
.venv/bin/pip install --upgrade pip wheel
.venv/bin/pip install -e .
EOF

# 6. Create /opt/mostlyright/.env with secrets (see below)
sudo -u mostlyright nano /opt/mostlyright/.env
sudo chmod 600 /opt/mostlyright/.env

# 7. Install the install-units script at a root-owned path. Do NOT leave it
#    in /opt/mostlyright where the mostlyright user could modify it — the
#    sudoers rule in step 8 points at this fixed path, so leaving the script
#    in a mostlyright-writable location would turn the NOPASSWD rule into a
#    privilege escalation.
sudo install -o root -g root -m 0755 \
  /opt/mostlyright/deploy/install-units.sh \
  /usr/local/sbin/mostlyright-install-units

# 8. Populate /etc/systemd/system from the repo for the first time.
sudo /usr/local/sbin/mostlyright-install-units
sudo systemctl daemon-reload

# 9. Sudoers: `deploy.sh` runs sudo for systemctl daemon-reload and
#    systemctl restart only. NOT install-units — unit-file installs are a
#    manual operator step (see "Updating systemd unit files" and "Security
#    notes" sections below for why).
sudo tee /etc/sudoers.d/mostlyright-deploy <<'SUDOERS'
mostlyright ALL=(root) NOPASSWD: /bin/systemctl daemon-reload
mostlyright ALL=(root) NOPASSWD: /bin/systemctl restart mostlyright-*
mostlyright ALL=(root) NOPASSWD: /bin/systemctl start mostlyright-*
SUDOERS
sudo chmod 440 /etc/sudoers.d/mostlyright-deploy
sudo visudo -c  # syntax check

# 10. Enable + start
sudo systemctl enable --now \
  mostlyright-poller.service \
  mostlyright-merger.service \
  mostlyright-api.service \
  mostlyright-health.service \
  mostlyright-climate.timer \
  mostlyright-r2sync.timer

# 11. Verify
sudo systemctl status mostlyright-poller mostlyright-merger mostlyright-api mostlyright-health
curl -s http://127.0.0.1:8080/health | jq .
```

### Why the runtime user is also the deploy user

An earlier draft split this into two users: `mostlyright` for the services and
`deployer` for ssh-based deploys. That split hit a wall on the first real
deploy because `deployer` couldn't `git fetch` inside `/opt/mostlyright` (owned
by `mostlyright`) or `pip install` into the venv (also owned by `mostlyright`).
Fixing it cleanly would have required either opening up group-write across the
repo tree and venv (weakens isolation) or adding `sudo -u mostlyright` plumbing
to every command in `deploy.sh` (ugly).

Collapsing to a single user sidesteps both problems. The `mostlyright` user
has a shell, owns the tree, can `git pull`, can `pip install`, and has narrow
NOPASSWD sudo for exactly three systemctl commands. See the Security notes
section below for exactly what a compromised `mostlyright` account can and
cannot do — the honest answer is "corrupt data and Python code it already
runs, but not escalate to root."

## Required `.env` file

```ini
# /opt/mostlyright/.env — chmod 600, owned by mostlyright:mostlyright

# R2 (Cloudflare) — source of truth for parquet
# AWS-standard names. Used by r2sync.sh, the merger live upload (Sprint 2g-s2),
# the climate daily sync, and the backfill_all R2 client.
R2_BUCKET=mostlyright-parquet
R2_ENDPOINT=https://<account>.r2.cloudflarestorage.com
R2_ACCESS_KEY_ID=<redacted>
R2_SECRET_ACCESS_KEY=<redacted>
R2_SYNC_DEST=/data

# Telegram alerting — empty token disables alerting without crashing
TELEGRAM_TOKEN=<bot-token>
TELEGRAM_CHAT_ID=<chat-id>

# FastAPI
DATA_DIR=/data
API_KEYS=key1,key2,key3
```

`API_KEYS` can be empty in dev mode; the API logs a warning and disables auth.
For production, generate keys with `openssl rand -hex 32`.

**Legacy R2 env var names are deprecated but still read as a fallback.** Older
`.env` files using `R2_ACCOUNT_ID`, `R2_ACCESS_KEY`, `R2_SECRET_KEY`, and
`R2_BUCKET` continue to work, and `R2Client.from_env()` logs a deprecation
warning when it falls back. Migrate to the AWS-standard names above on the
next `.env` edit. The Python code prefers AWS-standard names whenever both
sets are set in the same file.

## Sprint 2g-s2 deploy sequence (live R2 upload)

When rolling out the s2 change (live R2 upload + env-var unification) on a VM
that has been running s1, the order matters: deploy code first, then
backfill the current year to close the deploy-time gap, then restart the
services. The first merge cycle after restart re-uploads everything as a
permanent fix, but the manual backfill closes the gap immediately so the
API has zero-second exposure.

```bash
# 1. Pull and install the new code (existing deploy.sh handles this).
ssh mostlyright@<vm> "cd /opt/mostlyright && deploy/deploy.sh"

# 2. BEFORE restarting the merger and climate timer, run a one-shot
#    fresh backfill of the current year for all stations. --no-resume
#    bypasses backfill_progress.json so we get a guaranteed full run for
#    every station even if a prior progress file is missing or partial.
#    GHCNh 404s harmlessly for the current year (NCEI publication lag);
#    IEM and climate fetch any data the live merger may have missed; the
#    upload step (upload_after_merge) globs ALL year files for each
#    station and pushes them, so the on-disk current-year parquet that
#    the merger has been accumulating gets uploaded too.
ssh mostlyright@<vm> "cd /opt/mostlyright && \
  source .venv/bin/activate && \
  python -m ingest.backfill_all \
    --data-dir /data \
    --years $(date +%Y) \
    --upload \
    --no-resume"

# 3. Restart the merger and climate units. The first merge cycle also
#    re-uploads everything (Sprint 2g-s2 decision 6 — unconditional
#    upload per cycle), so this is a triple belt: manual backfill +
#    cycle re-upload + ongoing every-cycle sync.
ssh mostlyright@<vm> "sudo systemctl restart mostlyright-merger.service"
ssh mostlyright@<vm> "sudo systemctl restart mostlyright-climate.timer"

# 4. Verify the R2 bucket has fresh files for every station.
#    $R2_BUCKET and $R2_ENDPOINT come from the `.env` you already sourced
#    in the deploy session. Do NOT hardcode the bucket name here — the
#    name in your `.env` is authoritative.
aws s3 ls "s3://${R2_BUCKET}/weather/observations/" \
  --endpoint-url "$R2_ENDPOINT" --recursive | grep "$(date +%Y).parquet"
# Expect: 20 lines, one per station, all with recent LastModified timestamps.

aws s3 ls "s3://${R2_BUCKET}/weather/climate/" \
  --endpoint-url "$R2_ENDPOINT" --recursive | grep "$(date +%Y).parquet"
# Expect: 20 lines, one per station, recent LastModified.

# 5. Hit the API for a sample station and verify it returns observations
#    through "today" (or as recent as the source allows). End-to-end check
#    that there's no user-visible gap.
curl -s -H "X-API-Key: $MR_API_KEY" \
  "https://api.mostlyright.com/observations?station=NYC&start=$(date -v-1d +%Y-%m-%d)" \
  | jq '.observations | length'
# Expect: non-zero count, with at least one observation from yesterday/today.
```

If the deploy verification fails (backfill errors, R2 has no fresh files,
API returns an empty array), DO NOT declare the deploy done — roll back,
debug, and retry. The point of this step is to catch the gap-fill failure
on the day of the deploy, not three days later when a quant emails saying
"where's NYC for the last week?"

`--no-resume` only affects the current invocation; it does not delete or
rewrite `backfill_progress.json`. Subsequent routine backfills (e.g., a
future 2027 run) still see the file and behave normally with their own
resume semantics.

## Everyday deploys

After the one-time provisioning, every deploy is a single command from a dev box:

```bash
deploy/deploy.sh mostlyright@<vm-ip>
```

The script fetches origin, resets to `origin/main` (override with
`DEPLOY_REF=<branch|tag|sha>`), runs `pip install -e .`, checks for systemd
unit drift between the repo and `/etc/systemd/system`, reloads systemd,
restarts the services, and curls `localhost:8080/health`. A non-200 health
response causes the deploy to exit non-zero AND dumps the last 50 lines of
each service's journal.

**deploy.sh intentionally does NOT install unit-file changes.** If the
drift check finds a `.service` or `.timer` file in the repo that differs
from what's installed in `/etc/systemd/system`, deploy.sh warns loudly and
proceeds with a code-only deploy. Unit-file updates require the operator
to run a manual step from a privileged session — see the next section.
See "Security notes" below for why this split exists.

**Trust boundary:** `DEPLOY_REF` becomes a `git reset --hard` target on the
VM. Only pass refs you trust. Never set it to a PR branch from a fork or
an untrusted user-supplied value — arbitrary commit contents will be
checked out and then `pip install -e .`'d.

## Updating systemd unit files (manual operator step)

deploy.sh ships Python code automatically but NOT systemd unit files. This
is a deliberate security tradeoff (see "Security notes" below). When you
add a new `.service`/`.timer` to `deploy/` or modify an existing one, here
is the end-to-end procedure:

1. Land the unit-file change in `main` via a normal PR. Don't do this in a
   hotfix on the VM.
2. SSH in as a user with full root. On GCP Compute Engine this is usually
   your own Google account via `gcloud compute ssh <vm-name>`, NOT the
   `mostlyright` account that everyday deploys use.
3. Pull the latest code into the mostlyright clone first so
   `install-units.sh` reads the updated files. **Pin the remote URL
   explicitly** and **disable git hooks** — don't rely on the stored
   `.git/config`, because `mostlyright` can edit it, and don't let
   repo-side hooks execute under the `sudo -u mostlyright` wrapper:

   ```bash
   sudo -u mostlyright git -c core.hooksPath=/dev/null -C /opt/mostlyright \
     fetch --tags https://github.com/Tarabcak/mostlyright.git main
   sudo -u mostlyright git -c core.hooksPath=/dev/null -C /opt/mostlyright \
     reset --hard FETCH_HEAD
   ```

   Note: `reset --hard FETCH_HEAD` not `origin/main`. `FETCH_HEAD` is
   whatever the explicit URL just returned, so a tampered `origin` ref
   in `.git/config` can't redirect this reset.

4. Eyeball the deploy directory before installing. `install-units.sh`
   skips symlinks but a new regular file planted by a compromised
   account would still be copied. The previous step (`git reset --hard`)
   should have reset the working tree to clean upstream state, but an
   extra glance never hurts:

   ```bash
   ls -la /opt/mostlyright/deploy/*.service /opt/mostlyright/deploy/*.timer
   ```

5. Install the new unit files and reload systemd:

   ```bash
   sudo /usr/local/sbin/mostlyright-install-units
   sudo systemctl daemon-reload
   ```

   **If `install-units.sh` itself changed in the repo** (not just the
   `.service`/`.timer` files), also re-copy the script to
   `/usr/local/sbin` first. The copy at `/usr/local/sbin` is frozen at
   whatever version was current during the original provisioning:

   ```bash
   sudo install -o root -g root -m 0755 \
     /opt/mostlyright/deploy/install-units.sh \
     /usr/local/sbin/mostlyright-install-units
   ```

6. For **new** units that weren't previously installed, enable them so
   they survive a reboot. Existing units that were only modified do not
   need this step:

   ```bash
   sudo systemctl enable mostlyright-<new-unit-name>.service
   ```

7. Restart affected services (the mostlyright-* sudoers rule covers
   this, but since you already have full root in this session it's
   equivalent):

   ```bash
   sudo systemctl restart mostlyright-poller mostlyright-merger  # etc
   ```

8. Exit the privileged session. Everyday deploys continue via
   `deploy.sh mostlyright@<host>` as usual — that path no longer needs
   root because the units are already up to date.

If you forget step 5, the next `deploy.sh` run will detect the drift and
print instructions pointing you right back here. The drift check also
flags NEW units (absent from `/etc/systemd/system`) separately from
modified ones, with a matching `systemctl enable` reminder.

## Security notes

The deploy model has one honest gap and two mitigations worth naming.

**Honest gap: a compromised `mostlyright` account can corrupt data and
run arbitrary code as `mostlyright`, but cannot escalate to root.**

Concretely, if an attacker gets an interactive shell as `mostlyright`
(stolen SSH key, compromised Python dependency, etc.) they can:

- Write to `/data` and `/opt/mostlyright` (including Python code the
  services execute). The services run as `mostlyright`, so arbitrary
  Python code is already executable by this account. This is by design.
- Read the `.env` file (`TELEGRAM_TOKEN`, `R2_*`, `API_KEYS`) since it's
  readable by the mostlyright user.
- Call the three sudoers commands: `systemctl daemon-reload`,
  `systemctl restart mostlyright-*`, `systemctl start mostlyright-*`.
- **Persist via `.env` injection.** Every unit has
  `EnvironmentFile=/opt/mostlyright/.env`, and `.env` is mostlyright-writable.
  A compromised mostlyright could add `LD_PRELOAD=/opt/mostlyright/evil.so`
  or `PYTHONPATH=/opt/mostlyright/evil` to `.env` and then
  `sudo systemctl restart mostlyright-poller`. Systemd reads the new env
  file and the dynamic linker / Python loader would pick up the payload
  on the next restart. `NoNewPrivileges=true` does NOT block this — that
  bit only prevents capability gain and setuid execution, not ordinary
  `LD_PRELOAD` behavior. `PrivateTmp=true` blocks `/tmp`-based payloads
  (each service gets a private empty `/tmp`), but `/opt/mostlyright` and
  `/data` are readable by the service. This is still code execution as
  `mostlyright`, not root — but it is a persistence mechanism that
  survives ssh key rotation, and it's worth naming.

They CANNOT:

- Write to `/etc/systemd/system/`, `/usr/local/sbin/`, `/etc`, `/usr`,
  `/root`, `/var/lib`, or any other root-owned path.
- Invoke `/usr/local/sbin/mostlyright-install-units` (not in sudoers).
- Escalate via `systemctl restart`, because the unit files in
  `/etc/systemd/system/` are root-owned and cannot be modified without
  write access to `/etc`. `.env` injection (above) can influence what
  the restarted process does, but the restarted process still runs as
  `mostlyright` with `NoNewPrivileges=true`, so no capability or UID
  transition happens.
- Hijack the manual "Updating systemd unit files" operator procedure,
  **provided the operator follows it as written**. The procedure pins
  the git remote URL explicitly (`https://github.com/Tarabcak/mostlyright.git`)
  rather than trusting `/opt/mostlyright/.git/config` (which mostlyright
  can edit), and it passes `-c core.hooksPath=/dev/null` to disable
  repo-side git hooks. Both defenses close a theoretical path where a
  compromised mostlyright tampers with the git config or drops a
  `post-checkout` hook to run code under the operator's `sudo -u
  mostlyright` wrapper. If the operator skips the pinning and runs a
  plain `git fetch origin` instead, this defense is gone — so the
  procedure's step 3 is load-bearing, not cosmetic.

**Why install-units is not in sudoers (even though it's "more convenient"):**
An earlier draft of this README had `mostlyright` sudo for
`/usr/local/sbin/mostlyright-install-units` so that `deploy.sh` could ship
unit-file changes automatically. Vu's second review flagged a privilege
escalation path that broke that design:

1. Compromised `mostlyright` edits `/opt/mostlyright/deploy/mostlyright-poller.service`
2. Keeps `User=mostlyright` (so any naive validator passes)
3. Adds a line like `ExecStart=+/bin/sh -c 'cp /bin/bash /tmp/rs; chmod u+s /tmp/rs'`
4. The `+` prefix on `ExecStart=` tells systemd to run that command with
   full root privileges, IGNORING the `User=` directive
5. Attacker runs `deploy.sh`, which (in the old design) called
   `sudo /usr/local/sbin/mostlyright-install-units`, which copied the
   modified unit file to `/etc/systemd/system/`
6. Attacker runs `sudo systemctl restart mostlyright-poller` (allowed by
   sudoers). Systemd starts the service, honors `ExecStart=+`, and the
   root shell is now at `/tmp/rs`.

A naive denylist validator for `ExecStart=+` isn't enough either — systemd
has several other bypass directives (`ExecStart=!`, `ExecStart=!!`,
`BindPaths=`, `RootDirectory=`, `Environment=LD_PRELOAD=...`, ...) and
maintaining a complete allowlist against a moving systemd codebase is
impractical. The correct fix is upstream: remove the sudoers rule
entirely so a compromised `mostlyright` simply cannot trigger an install.

The cost is operational: unit-file changes are now a manual step for a
human operator with full root. That's ~once per sprint based on historical
change rate, and the "Updating systemd unit files" procedure above takes
under a minute.

**Mitigation 2 (already shipped): host hardening.**
Every service file sets `ProtectSystem=strict`, `ProtectHome=true`,
`PrivateTmp=true`, `NoNewPrivileges=true`, and scopes `ReadWritePaths=`
to just `/data` and `/opt/mostlyright/logs`. This means a compromised
*service* cannot even modify `/opt/mostlyright/deploy/` — only an
interactive ssh session as `mostlyright` can. The attack surface for
the service itself is genuinely smaller than the attack surface for
the ssh user.

## Alerting

Telegram alerts fire on:

- **Unit crash** — every service has `OnFailure=mostlyright-alert@%n.service`,
  which runs `alert-on-failure.sh` with the crashed unit name. The script pulls
  the last 20 journal lines and posts them. If `TELEGRAM_TOKEN` is empty the
  alert is silently skipped (the `alerting.send_alert` call returns `False`
  without raising).
- **Watermark staleness** — the `mostlyright-health` service exposes 503 on
  `localhost:8080/health` whenever any station's watermark is older than 2h.
  To turn that into a Telegram alert, install the watchdog script below at
  `/opt/mostlyright/deploy/staleness-watchdog.sh` (chmod 755, owner
  `mostlyright`), then wire it into cron:

  ```bash
  sudo tee /opt/mostlyright/deploy/staleness-watchdog.sh > /dev/null <<'SH'
  #!/usr/bin/env bash
  # Cron doesn't inherit systemd EnvironmentFile, so we must source .env
  # ourselves. Without this, TELEGRAM_TOKEN is undefined and the alert
  # silently never fires.
  set -uo pipefail
  if [ -f /opt/mostlyright/.env ]; then
    set -a
    # shellcheck disable=SC1091
    . /opt/mostlyright/.env
    set +a
  fi
  if ! curl -sf http://127.0.0.1:8080/health > /dev/null; then
    /opt/mostlyright/.venv/bin/python -c \
      'import os; from ingest.alerting import alert_on_failure; \
       alert_on_failure("health", "watermark stale", \
         token=os.environ.get("TELEGRAM_TOKEN", ""), \
         chat_id=os.environ.get("TELEGRAM_CHAT_ID", ""))'
  fi
  SH
  sudo chmod 755 /opt/mostlyright/deploy/staleness-watchdog.sh
  sudo chown mostlyright:mostlyright /opt/mostlyright/deploy/staleness-watchdog.sh

  # Install the cron entry (runs as mostlyright so the .env file is readable)
  sudo -u mostlyright crontab -l 2>/dev/null > /tmp/mr-cron
  echo '*/5 * * * * /opt/mostlyright/deploy/staleness-watchdog.sh' >> /tmp/mr-cron
  sudo -u mostlyright crontab /tmp/mr-cron
  rm /tmp/mr-cron
  ```

  Key points the original one-liner missed:
  - Cron inherits an almost-empty environment. `.env` must be sourced.
  - `os.environ.get("KEY", "")` (not `os.environ["KEY"]`) so a missing var
    doesn't `KeyError` — `alert_on_failure` already handles empty credentials
    and logs a warning instead of crashing.

Alerting failures never crash the pipeline — `send_alert` swallows every error.

## Traffic switch: Go API → Python API

The existing therminal Go API is live. The Python API (FastAPI, `api.app:app`)
is a drop-in replacement with identical endpoints and response format.

**Phase 1 — Parallel run (24h minimum)**

1. Deploy Python API on the new VM, port 8000. Keep Go API on its VM.
2. Run both for 24h. Compare a representative sample of queries:

   ```bash
   # Smoke test: same station, same window, both endpoints
   curl -sH "X-API-Key: $KEY" https://go-api.example.com/v1/observations?station=NYC&start=... > go.json
   curl -sH "X-API-Key: $KEY" https://py-api.example.com/v1/observations?station=NYC&start=... > py.json
   diff <(jq -S . go.json) <(jq -S . py.json)
   ```

3. Rollback criteria (before cutover): any schema drift, any p99 > 2s, any 5xx
   rate > 1% on the Python side.

**Phase 2 — DNS cutover**

1. Lower the api DNS TTL to 60s the day before cutover.
2. Flip the proxy (nginx upstream or Cloudflare DNS record) to the Python VM.
3. Watch error rate and latency in 1-minute windows for the first hour.

**Phase 3 — Rollback (if needed)**

If within the first hour:

- Error rate > 5%, OR
- p99 latency > 2s,

then revert DNS/proxy to the Go API within 5 minutes. The Go VM stays warm as a
cold standby for 2 weeks, at which point you decommission it if no issues
surfaced.

## Health check response shape

```json
{
  "status": "ok",                                // or "degraded"
  "uptime_s": 1234.5,
  "watermarks": {"ATL": "2026-04-07T12:00:00Z"},
  "stale_stations": [],
  "max_age_hours": 2.0
}
```

HTTP 200 when `stale_stations` is empty, 503 otherwise.

## Operational notes

- Services are independently restartable (`systemctl restart mostlyright-poller`).
- Journals: `sudo journalctl -u mostlyright-poller -f`.
- Data volume: `/data` is 50GB, current footprint ~5GB. Growth is ~50MB/month.
- The `mostlyright` user is both the runtime user and the deploy ssh target.
  It has narrow NOPASSWD sudo for exactly THREE commands: `systemctl
  daemon-reload`, `systemctl restart mostlyright-*`, and `systemctl start
  mostlyright-*`. Nothing else. In particular, it cannot invoke
  `/usr/local/sbin/mostlyright-install-units` — see the "Security notes"
  section for why this restriction exists and "Updating systemd unit files"
  for the manual operator workflow that replaces it.
- The alert service (`mostlyright-alert@.service`) runs with
  `SupplementaryGroups=systemd-journal` so it can read other units' journals
  via `journalctl -u <unit>`. Without that group grant, the alert would
  silently degrade to `<no logs>` because a plain system user on Ubuntu
  cannot read system unit journals.
- `StrictHostKeyChecking=accept-new` trusts new host keys on first connect. If
  the VM is rebuilt, the old key remains in `known_hosts` and ssh will refuse
  to reconnect — run `ssh-keygen -R <vm-ip>` to drop the stale entry, or
  pre-populate known_hosts with `ssh-keyscan` during provisioning.
- **Station code quirk:** `mostlyright-poller.service` uses ICAO codes
  (`KATL,KNYC,...`) because the AWC poller validates with `^[A-Z]{3,4}$`.
  `mostlyright-merger.service` uses internal codes (`ATL,NYC,...`) because
  the merger validates against `ingest.stations.STATIONS`. Do not mix them.
- Pre-production smoke test: `DEPLOY_REF=HEAD deploy/deploy.sh mostlyright@staging`.
