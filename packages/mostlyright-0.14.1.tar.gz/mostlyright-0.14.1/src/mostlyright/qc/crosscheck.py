"""IEM cross-check — compare GHCNh observations against IEM for QC.

IEM applies filtering on top of raw METAR data that catches sensor errors
(500kt wind, 180 F temperature). When GHCNh has a record that IEM doesn't,
or when IEM's value differs significantly, that's a data quality signal.
"""

from __future__ import annotations


def iem_crosscheck(ghcnh_obs: dict | None, iem_obs: dict | None) -> list[str]:
    """Compare a GHCNh observation against IEM for QC.

    Returns list of flags. Empty = data agrees. Non-empty = investigate.
    """
    flags: list[str] = []

    if ghcnh_obs is None or iem_obs is None:
        return flags

    # Temperature divergence (>2 C)
    g_temp = ghcnh_obs.get("temp_c")
    i_temp = iem_obs.get("temp_c")
    if g_temp is not None and i_temp is not None:
        delta = abs(g_temp - i_temp)
        if delta > 2.0:
            flags.append(
                f"temp_c divergence: GHCNh={g_temp} IEM={i_temp} delta={delta:.1f}C"
            )

    # GHCNh has temp but IEM filtered it (possible sensor error)
    if ghcnh_obs.get("temp_c") is not None and iem_obs.get("temp_c") is None:
        flags.append("GHCNh has temp but IEM filtered it — possible sensor error")

    # Wind speed divergence (>5kt)
    g_wind = ghcnh_obs.get("wind_speed_kt")
    i_wind = iem_obs.get("wind_speed_kt")
    if g_wind is not None and i_wind is not None:
        if abs(g_wind - i_wind) > 5:
            flags.append(f"wind_speed divergence: GHCNh={g_wind}kt IEM={i_wind}kt")

    # SLP divergence (>3mb)
    g_slp = ghcnh_obs.get("sea_level_pressure_mb")
    i_slp = iem_obs.get("sea_level_pressure_mb")
    if g_slp is not None and i_slp is not None:
        if abs(g_slp - i_slp) > 3.0:
            flags.append(f"slp divergence: GHCNh={g_slp} IEM={i_slp}")

    # Visibility divergence (>2mi)
    g_vis = ghcnh_obs.get("visibility_miles")
    i_vis = iem_obs.get("visibility_miles")
    if g_vis is not None and i_vis is not None:
        if abs(g_vis - i_vis) > 2.0:
            flags.append(f"visibility divergence: GHCNh={g_vis}mi IEM={i_vis}mi")

    return flags
