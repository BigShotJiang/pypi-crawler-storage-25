"""Quality control modules."""
