"""Shared forecast-source constants and parse functions.

Lives under ``src/mostlyright`` (not ``ingest/``) so pip-installed SDK
users can import them for the live forecast path without pulling in any
server-side dependencies. The ingest-side modules (``ingest/sources/*``)
re-export from here for backward compat and layer the HTTP/backfill
logic on top.

The split is: anything needed to PARSE a raw upstream record into our
schema goes here. Anything that FETCHES/BACKFILLS lives in ingest.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# HTTP timeouts (shared — same 60s value on both sides)
# ---------------------------------------------------------------------------

IEM_HTTP_TIMEOUT = 60.0
OM_HTTP_TIMEOUT = 60.0

# ---------------------------------------------------------------------------
# IEM MOS — URLs + model list
# ---------------------------------------------------------------------------

IEM_MOS_BULK_URL = "https://mesonet.agron.iastate.edu/cgi-bin/request/mos.py"
IEM_MODELS: tuple[str, ...] = ("NBS", "NBE", "GFS")

# IEM field name -> our forecast schema field name
FIELD_MAP: dict[str, str] = {
    "tmp": "temperature_f",
    "dpt": "dewpoint_f",
    "wsp": "wind_speed_kt",
    "wdr": "wind_direction_deg",
    "gst": "wind_gust_kt",
    "cld": "cloud_cover_code",
    "sky": "sky_cover_pct",
    "cig": "ceiling_cat",
    "vis": "visibility_cat",
    "p06": "pop_6hr_pct",
    "p12": "pop_12hr_pct",
    "q06": "qpf_6hr_in",
    "q12": "qpf_12hr_in",
    "snw": "snow_flag",
    "typ": "precip_type",
    "pzr": "freezing_rain_pct",
    "psn": "snow_prob_pct",
    "ppl": "sleet_prob_pct",
    "pra": "rain_prob_pct",
    "t06": "thunder_prob_6hr",
    "t12": "thunder_prob_12hr",
    "n_x": "max_min_temp_f",
    "tws": "transport_wind_speed",
    "twd": "transport_wind_dir",
    "mht": "mixing_height",
    "hid": "haines_index",
    "sol": "solar_radiation",
    "lcb": "low_cloud_base",
    "slv": "snow_level",
}

# Sentinel values that should be mapped to None.
#
# IEM MOS text products use a handful of magic numbers for "missing" and
# "unlimited" that vary per field. Source: the Iowa Mesonet / NWS MOS bulletin
# spec (github.com/akrherz/iem — `htdocs/cgi-bin/request/mos.py` and the
# original NWS MOS ``mdl_mos.f90`` source). Every value listed here was
# verified empirically against at least one representative station-week of
# raw IEM responses before being mapped to None.
#
#   cig: -88 — ceiling "unlimited" (no cloud layer at all)
#   vis: -88 — visibility "unlimited" (parallels ``cig``)
#   slv: -88 — snow level "missing" / not applicable
#
# If you add a field here, include a comment with the source of the value
# and the scope of the empirical check you performed.
IEM_SENTINELS: dict[str, dict[int, None]] = {
    "cig": {-88: None},
    "vis": {-88: None},
    "slv": {-88: None},
}

# Fields that must be str|None in the parquet schema. IEM occasionally returns
# a bare numeric 0 (JSON number) for these instead of a string (e.g. t06/t12
# return 0 instead of "0/5" when there is no thunderstorm activity). Coerce to
# str at parse time so PyArrow never sees a float in a string column.
_STRING_SCHEMA_FIELDS: frozenset[str] = frozenset(
    {
        "cloud_cover_code",
        "snow_flag",
        "precip_type",
        "thunder_prob_6hr",
        "thunder_prob_12hr",
    }
)


# ---------------------------------------------------------------------------
# Open-Meteo — URLs + models + variables
# ---------------------------------------------------------------------------

HISTORICAL_FORECAST_URL = "https://historical-forecast-api.open-meteo.com/v1/forecast"
LIVE_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

# Open-Meteo free tier limit on ``forecast_days`` — 16 days = 384 hours.
# A live query with ``horizon_h > OM_MAX_HORIZON_H`` should raise
# ValueError client-side instead of letting the upstream 400 bubble up
# as an opaque httpx error.
OM_MAX_HORIZON_H = 384

# Earliest archival date per Open-Meteo model (used by the backfill
# orchestrator to clip the start date). Models available from:
#   gfs_seamless:     2021-03-23
#   ncep_hrrr_conus:  2018-01-01
#   ncep_nbm_conus:   2024-10-08
#   ecmwf_ifs025:     2024-02-03
#   ecmwf_aifs025:    2025-02-20
OPEN_METEO_MODELS: dict[str, str] = {
    "gfs_seamless": "2021-03-23",
    "ncep_hrrr_conus": "2018-01-01",
    "ncep_nbm_conus": "2024-10-08",
    "ecmwf_ifs025": "2024-02-03",
    "ecmwf_aifs025": "2025-02-20",
}

HOURLY_VARIABLES = [
    "temperature_2m",
    "dew_point_2m",
    "relative_humidity_2m",
    "apparent_temperature",
    "wind_speed_10m",
    "wind_direction_10m",
    "wind_gusts_10m",
    "pressure_msl",
    "surface_pressure",
    "cloud_cover",
    "visibility",
    "weather_code",
    "precipitation",
    "precipitation_probability",
    "rain",
    "snowfall",
    "shortwave_radiation",
    "direct_radiation",
    "cape",
    "freezing_level_height",
    "snow_depth",
]

VARIABLE_MAP: dict[str, str] = {
    "temperature_2m": "temperature_c",
    "dew_point_2m": "dewpoint_c",
    "relative_humidity_2m": "relative_humidity_pct",
    # Grey area vs raw-as-reported rule: apparent_temperature is a derived/computed
    # field (feels-like from temperature + wind + humidity). Normally computed fields
    # belong client-side in the SDK. We store it here because Open-Meteo returns it
    # directly in the API response — we treat it as "raw-as-reported-by-Open-Meteo"
    # rather than computing it ourselves. This is a known exception to the rule.
    "apparent_temperature": "apparent_temperature_c",
    "wind_speed_10m": "wind_speed_kmh",
    "wind_direction_10m": "wind_direction_deg",
    "wind_gusts_10m": "wind_gusts_kmh",
    "pressure_msl": "pressure_msl_hpa",
    "surface_pressure": "surface_pressure_hpa",
    "cloud_cover": "cloud_cover_pct",
    "visibility": "visibility_m",
    "weather_code": "weather_code",
    "precipitation": "precipitation_mm",
    "precipitation_probability": "precipitation_probability_pct",
    "rain": "rain_mm",
    "snowfall": "snowfall_cm",
    "shortwave_radiation": "shortwave_radiation_wm2",
    "direct_radiation": "direct_radiation_wm2",
    "cape": "cape_jkg",
    "freezing_level_height": "freezing_level_m",
    "snow_depth": "snow_depth_m",
}


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _normalize_timestamp(ts: str) -> str:
    """Normalize IEM timestamp to UTC Z-suffix format.

    IEM returns timestamps like "2026-04-01T00:00:00.000" without a timezone
    indicator. These are UTC. Strip any trailing milliseconds and append 'Z'.

    >>> _normalize_timestamp("2026-04-01T00:00:00.000")
    '2026-04-01T00:00:00Z'
    >>> _normalize_timestamp("2026-04-01T06:00:00Z")
    '2026-04-01T06:00:00Z'
    """
    cleaned = ts.rstrip("Z")
    if "." in cleaned:
        cleaned = cleaned[: cleaned.index(".")]
    return cleaned + "Z"


def _f_to_c(f: float | int | None) -> float | None:
    """Convert Fahrenheit to Celsius. No rounding.

    Returns None if input is None.
    """
    if f is None:
        return None
    return (f - 32) * 5 / 9


def _apply_sentinels(field: str, value: Any) -> Any:
    """Replace sentinel values with None for the given field."""
    if field in IEM_SENTINELS and value in IEM_SENTINELS[field]:
        return IEM_SENTINELS[field][value]
    return value


def _icao_to_station_code(icao: str) -> str:
    """Convert ICAO code to MostlyRight station code.

    Drops leading 'K' for CONUS stations: KORD -> ORD, KNYC -> NYC.
    """
    if icao.startswith("K") and len(icao) == 4:
        return icao[1:]
    return icao


def _parse_iem_record(
    raw: dict[str, Any], station_code: str | None = None
) -> dict[str, Any]:
    """Parse a single IEM MOS record into forecast schema dict.

    Maps IEM field names to our schema, normalises timestamps, computes
    forecast_hour, and converts temperatures to Celsius.

    If station_code is not provided, derives it from the raw 'station' field
    by stripping the leading 'K' prefix (KORD -> ORD).
    """
    issued_at = _normalize_timestamp(raw["runtime"])
    valid_at = _normalize_timestamp(raw["ftime"])

    issued_dt = datetime.fromisoformat(issued_at)
    valid_dt = datetime.fromisoformat(valid_at)
    forecast_hour = int((valid_dt - issued_dt).total_seconds() / 3600)
    if forecast_hour < 0:
        log.warning(
            "%s %s: negative forecast_hour=%d (issued=%s valid=%s) — writing as-is",
            station_code or raw.get("station", "?"),
            raw.get("model", "?"),
            forecast_hour,
            issued_at,
            valid_at,
        )

    if station_code is None:
        station_code = _icao_to_station_code(raw.get("station", ""))

    record: dict[str, Any] = {
        "station_code": station_code,
        "model": raw.get("model", ""),
        "issued_at": issued_at,
        "valid_at": valid_at,
        "forecast_hour": forecast_hour,
        "source": "iem",
        "ingested_at": None,
    }

    for iem_field, schema_field in FIELD_MAP.items():
        value = raw.get(iem_field)
        value = _apply_sentinels(iem_field, value)
        record[schema_field] = value

    # Coerce string-typed fields. IEM occasionally returns a bare numeric 0
    # for t06/t12 instead of the expected "0/5" string. Convert so PyArrow
    # never sees a float in a pa.string() column.
    #
    # Thunder probability gets field-specific coercion: the MOS convention
    # is ``count/total``. A bare 0 means "no thunder in any window", so the
    # semantically faithful string is "0/5". Source: NWS MDL MOS spec.
    thunder_zero_fields = frozenset({"thunder_prob_6hr", "thunder_prob_12hr"})
    for _f in _STRING_SCHEMA_FIELDS:
        _v = record.get(_f)
        if _v is None or isinstance(_v, str):
            continue
        if _f in thunder_zero_fields and _v == 0:
            record[_f] = "0/5"
        else:
            record[_f] = str(_v)

    # Temperature conversions — store both F and C, no rounding.
    temp_f = record.get("temperature_f")
    record["temperature_c"] = _f_to_c(temp_f)

    dpt_f = record.get("dewpoint_f")
    record["dewpoint_c"] = _f_to_c(dpt_f)

    return record


def _unix_to_rfc3339(ts: int) -> str:
    """Convert unix timestamp to UTC Z-suffix RFC3339 string.

    Uses timezone-aware ``fromtimestamp`` — ``datetime.utcfromtimestamp`` is
    deprecated in 3.12 and returns a naive datetime that implicitly claims UTC.
    """
    return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
