"""Anthropic-compatible tool definitions for MostlyRight SDK methods.

Hand-authored (not dynamically generated from signatures) so that enum
constraints and cross-parameter notes can be expressed precisely.

Usage::
    from mostlyright._tools import get_tool_definitions
    tools = get_tool_definitions()
    # Pass directly to anthropic.messages.create(..., tools=tools)

When market methods are implemented in Sprint 3, add their definitions to
_TOOL_DEFINITIONS_MARKET and expose via include_market=True in as_tools().
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# Core tool definitions (always included)
# ---------------------------------------------------------------------------

_TOOL_DEFINITIONS: list[dict[str, Any]] = [
    {
        "name": "observations",
        "description": (
            "Get weather observations with optional temporal transform DSL. "
            "Returns METAR/SPECI records for a station and date range. "
            "Use as_of for point-in-time correctness in inference loops. "
            "Example: observations('NYC', from_date='2024-01-01', to_date='2024-01-07', format='toon') "
            "returns a compact TOON string. "
            "Example with DSL: observations('NYC', from_date='2024-01-01', to_date='2024-12-31', "
            "features=['temp_f.lag(24h)', 'temp_f.rolling_mean(7d)'], format='toon')."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC', 'ATL').",
                },
                "from_date": {
                    "type": "string",
                    "description": "Start date (YYYY-MM-DD).",
                },
                "to_date": {
                    "type": "string",
                    "description": "End date (YYYY-MM-DD).",
                },
                "as_of": {
                    "type": "string",
                    "description": (
                        "UTC timestamp (ISO 8601). When provided, results are filtered "
                        "to observed_at <= as_of. Use for point-in-time inference."
                    ),
                },
                "obs_type": {
                    "type": "string",
                    "description": "Filter by observation type.",
                    "enum": ["METAR", "SPECI"],
                },
                "units": {
                    "type": "string",
                    "description": "Unit system.",
                    "enum": ["raw", "metric", "imperial"],
                },
                "format": {
                    "type": "string",
                    "description": "Output format. 'toon' returns a compact TOON string.",
                    "enum": ["toon"],
                },
                "columns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Subset of columns to return. Omit for all 30 raw fields. "
                        "Example: ['observed_at', 'temp_f', 'dewpoint_f']."
                    ),
                },
                "features": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Temporal DSL transform expressions to compute and append. "
                        "Example: ['temp_f.lag(24h)', 'temp_f.rolling_mean(7d)', 'hour_sin']. "
                        "Use feature_catalog() to discover available expressions."
                    ),
                },
                "limit": {
                    "type": "number",
                    "description": "Max records to return. Default 1000.",
                },
                "offset": {
                    "type": "number",
                    "description": "Pagination offset. Default 0.",
                },
            },
            "required": ["station"],
        },
    },
    {
        "name": "climate",
        "description": (
            "Get daily climate reports from the NWS CLI. "
            "These are the authoritative source for Kalshi settlement values "
            "(cli_high_f, cli_low_f)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC', 'ATL').",
                },
                "from_date": {
                    "type": "string",
                    "description": "Start date (YYYY-MM-DD).",
                },
                "to_date": {
                    "type": "string",
                    "description": "End date (YYYY-MM-DD).",
                },
                "units": {
                    "type": "string",
                    "description": "Unit system.",
                    "enum": ["raw", "metric", "imperial"],
                },
                "format": {
                    "type": "string",
                    "description": "Output format.",
                    "enum": ["toon"],
                },
                "limit": {
                    "type": "number",
                    "description": "Max records. Default 1000.",
                },
            },
            "required": ["station"],
        },
    },
    {
        "name": "climate_gaps",
        "description": (
            "Find gaps in climate history for a station. "
            "Returns date ranges where NWS CLI records are missing."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC').",
                },
                "from_date": {
                    "type": "string",
                    "description": "Start date (YYYY-MM-DD).",
                },
                "to_date": {
                    "type": "string",
                    "description": "End date (YYYY-MM-DD).",
                },
            },
            "required": ["station"],
        },
    },
    {
        "name": "data_version",
        "description": (
            "Return a reproducible version token for the dataset at a point in time. "
            "Two queries with the same token have identical underlying data."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC').",
                },
                "as_of": {
                    "type": "string",
                    "description": "Query watermark (UTC ISO 8601).",
                },
                "from_date": {
                    "type": "string",
                    "description": "Optional start date for observations window.",
                },
                "to_date": {
                    "type": "string",
                    "description": "Optional end date for observations window.",
                },
            },
            "required": ["station", "as_of"],
        },
    },
    {
        "name": "snapshot",
        "description": (
            "Return everything an AI agent would have known at UTC moment as_of. "
            "Includes filtered observations, climate (if published), and forecasts. "
            "Check climate_unavailable_reason when climate is None. "
            "Example: snapshot('NYC', as_of='2024-07-04T18:00:00Z', format='toon') "
            "returns a compact context-injectable TOON string. "
            "For stations not in the registry, pass tz_override='America/Chicago'."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC', 'KATL').",
                },
                "as_of": {
                    "type": "string",
                    "description": "UTC query timestamp (ISO 8601 string).",
                },
                "cli_publication_delay_hours": {
                    "type": "number",
                    "description": (
                        "Hours after midnight LST until CLI is assumed published. "
                        "Default 10."
                    ),
                },
                "include_forecast": {
                    "type": "boolean",
                    "description": "Include forecast data if available. Default false.",
                },
                "tz_override": {
                    "type": "string",
                    "description": (
                        "IANA timezone name for stations not in the registry "
                        "(e.g. 'America/Chicago'). Required when querying a station "
                        "whose timezone is unknown."
                    ),
                },
                "format": {
                    "type": "string",
                    "description": "Output format. 'toon' returns a compact TOON string.",
                    "enum": ["toon"],
                },
            },
            "required": ["station", "as_of"],
        },
    },
    {
        "name": "pairs",
        "description": (
            "Return one row per settlement date joining observations + climate + forecast. "
            "Primary training surface for Kalshi settlement models. "
            "Key columns: cli_high_f, cli_low_f (settlement source), obs_high_f, obs_low_f, "
            "fcst_high_f, fcst_low_f, fcst_issued_at, fcst_qpf_6hr_in. "
            "Example: pairs('NYC', '2024-01-01', '2024-12-31', format='toon') "
            "returns a compact TOON string (~3x fewer tokens than JSON). "
            "forecast_model is case-insensitive: 'gfs' and 'GFS' both work."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC').",
                },
                "from_date": {
                    "type": "string",
                    "description": "Start date (YYYY-MM-DD).",
                },
                "to_date": {
                    "type": "string",
                    "description": "End date (YYYY-MM-DD).",
                },
                "include_forecast": {
                    "type": "boolean",
                    "description": "Join forecast data if available. Default false.",
                },
                "forecast_model": {
                    "type": "string",
                    "description": (
                        "Filter IEM MOS records to this model. "
                        "None = best available run. Case-insensitive."
                    ),
                    "enum": ["NBS", "NBE", "GFS"],
                },
                "tz_override": {
                    "type": "string",
                    "description": (
                        "IANA timezone name for stations not in the registry "
                        "(e.g. 'America/Chicago'). Required when querying a station "
                        "whose timezone is unknown."
                    ),
                },
                "format": {
                    "type": "string",
                    "description": "Output format. 'toon' returns a compact TOON string.",
                    "enum": ["toon"],
                },
            },
            "required": ["station", "from_date", "to_date"],
        },
    },
    {
        "name": "feature_catalog",
        "description": (
            "Return all available features with descriptions and metadata. "
            "Use format='json' for JSON-serializable output in tool-use context."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "include_transforms": {
                    "type": "boolean",
                    "description": "Include derived transform features. Default true.",
                },
                "source_filter": {
                    "type": "string",
                    "description": "Filter to one source.",
                    "enum": [
                        "observation",
                        "climate",
                        "computed",
                        "transform",
                        "forecast_iem",
                        "forecast_openmeteo",
                        "satellite",
                        "pairs",
                        "market",
                    ],
                },
                "format": {
                    "type": "string",
                    "description": (
                        "Output format. 'json' = list of dicts. "
                        "'toon' = compact TOON string."
                    ),
                    "enum": ["toon", "json"],
                },
            },
            "required": [],
        },
    },
    {
        "name": "describe",
        "description": (
            "Return an LLM-ready summary of available features for a station. "
            "Suitable for inclusion in a system prompt."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC').",
                },
            },
            "required": ["station"],
        },
    },
    {
        "name": "availability",
        "description": (
            "Return actual data availability for a station. "
            "Call this before building training loops to avoid empty-result queries."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC', 'KATL').",
                },
                "as_of": {
                    "type": "string",
                    "description": (
                        "UTC timestamp for freshness_hours calculation. "
                        "Default: current UTC time."
                    ),
                },
                "data_type": {
                    "type": "string",
                    "description": "Filter to one data type.",
                    "enum": ["all", "observations", "climate", "forecast"],
                },
            },
            "required": ["station"],
        },
    },
    {
        "name": "stations",
        "description": (
            "Return all stations with active Kalshi markets and SDK support. "
            "Call this at session start to get valid station codes and timezones."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "station",
        "description": (
            "Return metadata for a single station by code. "
            "Accepts 3-letter NWS ('NYC') or 4-letter ICAO ('KNYC'), case-insensitive."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC' or 'KNYC').",
                },
            },
            "required": ["code"],
        },
    },
    {
        "name": "schema",
        "description": (
            "Return the JSON Schema for a data entity. "
            "Note: 'pairs' is not supported — use feature_catalog(source_filter='pairs')."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "entity": {
                    "type": "string",
                    "description": "Entity name.",
                    "enum": [
                        "observation",
                        "climate",
                        "snapshot",
                        "data_version",
                        "forecast",
                        "forecast_series",
                        "candle",
                        "market",
                        "market_unified",
                        "synoptic_extremes",
                        "omo",
                        "brackets",
                    ],
                },
            },
            "required": ["entity"],
        },
    },
    {
        "name": "capabilities",
        "description": (
            "Return a structured summary of all SDK methods and their parameters. "
            "Includes version, method index, valid stations, and data types."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "forecasts",
        "description": (
            "Get historical IEM MOS forecasts (discrete model runs with "
            "issued_at). Settlement models train on these for paired inference "
            "against mostlyright.live.get_forecast(source='iem'). "
            "IEM MOS models: NBS, NBE, GFS. "
            "Example: forecasts('NYC', from_date='2024-07-01', "
            "to_date='2024-07-07', model='NBS', format='toon') returns a "
            "compact TOON string."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC').",
                },
                "from_date": {
                    "type": "string",
                    "description": "Start date (YYYY-MM-DD). Default: last 30 days.",
                },
                "to_date": {
                    "type": "string",
                    "description": "End date (YYYY-MM-DD). Default: today.",
                },
                "model": {
                    "type": "string",
                    "description": (
                        "IEM MOS model. NBS = National Blend short-range, "
                        "NBE = National Blend extended, GFS = Global Forecast System."
                    ),
                    "enum": ["NBS", "NBE", "GFS"],
                },
                "columns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Subset of columns to return. Omit for all 38 fields. "
                        "Example: ['valid_at', 'temperature_f', 'pop_6hr_pct']."
                    ),
                },
                "format": {
                    "type": "string",
                    "description": "Output format. 'toon' returns a compact TOON string.",
                    "enum": ["toon"],
                },
            },
            "required": ["station"],
        },
    },
    {
        "name": "forecast_series",
        "description": (
            "Get historical Open-Meteo hourly forecast series (seamless, no "
            "issued_at — every record treated as one continuous run). Paired "
            "with mostlyright.live.get_forecast(source='open_meteo'). "
            "Open-Meteo models use identifiers like 'gfs_seamless' and "
            "'ncep_hrrr_conus'. All values are SI/metric (°C, km/h, mm)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code (e.g. 'NYC').",
                },
                "from_date": {
                    "type": "string",
                    "description": "Start date (YYYY-MM-DD). Default: last 30 days.",
                },
                "to_date": {
                    "type": "string",
                    "description": "End date (YYYY-MM-DD). Default: today.",
                },
                "model": {
                    "type": "string",
                    "description": "Open-Meteo model identifier.",
                    "enum": [
                        "gfs_seamless",
                        "ncep_hrrr_conus",
                        "ncep_nbm_conus",
                        "ecmwf_ifs025",
                        "ecmwf_aifs025",
                    ],
                },
                "columns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "Subset of columns to return. Omit for all 26 fields."
                    ),
                },
                "format": {
                    "type": "string",
                    "description": "Output format. 'toon' returns a compact TOON string.",
                    "enum": ["toon"],
                },
            },
            "required": ["station"],
        },
    },
    {
        "name": "estimate_tokens",
        "description": (
            "Estimate token count for a data query without fetching records. "
            "Use before fetching large date ranges to avoid context overflow."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "station": {
                    "type": "string",
                    "description": "Station code.",
                },
                "from_date": {
                    "type": "string",
                    "description": "Start date (YYYY-MM-DD).",
                },
                "to_date": {
                    "type": "string",
                    "description": "End date (YYYY-MM-DD).",
                },
                "method": {
                    "type": "string",
                    "description": "Data method to estimate.",
                    "enum": [
                        "observations",
                        "climate",
                        "pairs",
                        "forecasts",
                        "forecast_series",
                    ],
                },
                "format": {
                    "type": "string",
                    "description": "Output format for the estimate.",
                    "enum": ["toon", "json"],
                },
            },
            "required": ["station", "from_date", "to_date"],
        },
    },
]

# ---------------------------------------------------------------------------
# Market tool definitions (include_market=True)
# ---------------------------------------------------------------------------
# To be populated when Sprint 3 ships Kalshi market methods.

_TOOL_DEFINITIONS_MARKET: list[dict[str, Any]] = []


def get_tool_definitions(
    *,
    include_market: bool = False,
    include_experimental: bool = False,
) -> list[dict[str, Any]]:
    """Return Anthropic-compatible tool definitions for SDK methods.

    Args:
        include_market: Include market methods (raise NotImplementedError until
            Sprint 3). Default False.
        include_experimental: Include experimental methods. Default False.

    Returns:
        List of tool definition dicts, each with "name", "description",
        "input_schema" keys. Returns a copy (not the mutable original).
    """
    tools = list(_TOOL_DEFINITIONS)
    if include_market:
        tools = tools + list(_TOOL_DEFINITIONS_MARKET)
    return tools
