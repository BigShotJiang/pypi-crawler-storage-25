"""Feature catalog — structured list of all available features with metadata.

feature_catalog() returns a list of FeatureEntry objects describing:
  - Raw observation fields (30 storage fields from specs/observation.json)
  - Computed SDK fields (relative_humidity, feels_like_f)
  - Climate record fields (from specs/climate.json)
  - IEM MOS forecast fields (from specs/forecast.json)
  - Open-Meteo forecast series fields (from specs/forecast_series.json)
  - GOES satellite fields (from sprint2/goes-satellite; stubs until merged)
  - Pairs output columns (from pairs.py build_pairs_row output)
  - Market fields (from specs/market_unified.json)
  - Available temporal transforms and their naming convention

Designed for AI agent consumption: an agent can call feature_catalog()
to discover what data is available before building feature vectors.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class FeatureEntry:
    """Metadata for a single feature.

    Attributes:
        name: Column name as it appears in the SDK output.
        source: Data entity this field comes from ("observation", "climate",
            "computed", "transform", "forecast_iem", "forecast_openmeteo",
            "satellite", "pairs", "market").
        dtype: Expected Python/numpy dtype hint ("float", "int", "str", "bool").
        unit: Physical unit (e.g. "degF", "kt", "mb", "inches"). None = dimensionless.
        description: Human-readable description.
        available_transforms: List of DSL transform spec templates applicable to
            this field. Empty for non-numeric or non-temporal fields.
        nullable: True if the field may be None/NaN in practice.
        settlement_field: True if this field is used for Kalshi settlement.
    """

    name: str
    source: str
    dtype: str
    unit: str | None
    description: str
    available_transforms: list[str] = field(default_factory=list)
    nullable: bool = True
    settlement_field: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "source": self.source,
            "dtype": self.dtype,
            "unit": self.unit,
            "description": self.description,
            "available_transforms": self.available_transforms,
            "nullable": self.nullable,
            "settlement_field": self.settlement_field,
        }


# ---------------------------------------------------------------------------
# Transform template generator
# ---------------------------------------------------------------------------

_TEMPORAL_WINDOWS = ["1h", "3h", "6h", "12h", "24h", "48h", "7d"]
_ROLLING_OPS = [
    "rolling_mean",
    "rolling_median",
    "rolling_min",
    "rolling_max",
    "rolling_std",
    "rolling_count",
]


def _temporal_transforms(field_name: str) -> list[str]:
    """Generate DSL transform spec strings for a numeric observation field.

    Returns the full list of applicable DSL specs: lag, diff, diff2, and each
    rolling op across all supported windows.
    """
    specs: list[str] = []
    for w in _TEMPORAL_WINDOWS:
        specs.append(f"{field_name}.lag({w})")
        specs.append(f"{field_name}.diff({w})")
        specs.append(f"{field_name}.diff2({w})")
        for op in _ROLLING_OPS:
            specs.append(f"{field_name}.{op}({w})")
    return specs


# ---------------------------------------------------------------------------
# Catalog definition — Observation fields
# ---------------------------------------------------------------------------

#: Raw observation fields (30 storage fields from specs/observation.json)
_OBSERVATION_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="station_code",
        source="observation",
        dtype="str",
        unit=None,
        description="NWS station code (3-4 letters).",
        nullable=False,
    ),
    FeatureEntry(
        name="observed_at",
        source="observation",
        dtype="str",
        unit=None,
        description="UTC timestamp of observation (RFC3339).",
        available_transforms=[
            "hour_sin",
            "hour_cos",
            "day_of_year_sin",
            "day_of_year_cos",
        ],
        nullable=False,
    ),
    FeatureEntry(
        name="observation_type",
        source="observation",
        dtype="str",
        unit=None,
        description="METAR (routine hourly) or SPECI (special significant-weather).",
        nullable=False,
    ),
    FeatureEntry(
        name="source",
        source="observation",
        dtype="str",
        unit=None,
        description="Data source: awc (live), iem (near-real-time), ghcnh (historical).",
        nullable=False,
    ),
    FeatureEntry(
        name="temp_f",
        source="observation",
        dtype="float",
        unit="degF",
        description="Temperature in Fahrenheit. ASOS native precision (whole °F via T-group).",
        available_transforms=_temporal_transforms("temp_f"),
    ),
    FeatureEntry(
        name="temp_c",
        source="observation",
        dtype="float",
        unit="degC",
        description="Temperature in Celsius. From T-group when available (0.1°C resolution).",
        available_transforms=_temporal_transforms("temp_c"),
    ),
    FeatureEntry(
        name="dewpoint_f",
        source="observation",
        dtype="float",
        unit="degF",
        description="Dewpoint in Fahrenheit.",
        available_transforms=_temporal_transforms("dewpoint_f"),
    ),
    FeatureEntry(
        name="dewpoint_c",
        source="observation",
        dtype="float",
        unit="degC",
        description="Dewpoint in Celsius.",
        available_transforms=_temporal_transforms("dewpoint_c"),
    ),
    FeatureEntry(
        name="wind_dir_degrees",
        source="observation",
        dtype="int",
        unit="degrees",
        description="Wind direction (0-360). Null = calm or variable.",
    ),
    FeatureEntry(
        name="wind_speed_kt",
        source="observation",
        dtype="int",
        unit="kt",
        description="Sustained wind speed in knots (2-min average).",
        available_transforms=_temporal_transforms("wind_speed_kt"),
    ),
    FeatureEntry(
        name="wind_gust_kt",
        source="observation",
        dtype="int",
        unit="kt",
        description="Wind gust in knots (peak 3-sec in past 10 min). Only when reported.",
        available_transforms=_temporal_transforms("wind_gust_kt"),
    ),
    FeatureEntry(
        name="altimeter_inhg",
        source="observation",
        dtype="float",
        unit="inHg",
        description="Altimeter setting (inches of mercury). 0.01 inHg precision.",
        available_transforms=_temporal_transforms("altimeter_inhg"),
    ),
    FeatureEntry(
        name="sea_level_pressure_mb",
        source="observation",
        dtype="float",
        unit="mb",
        description="Sea level pressure (millibars). 0.1 hPa precision from remarks.",
        available_transforms=_temporal_transforms("sea_level_pressure_mb"),
    ),
    FeatureEntry(
        name="sky_cover_1",
        source="observation",
        dtype="str",
        unit=None,
        description="Cloud cover layer 1: CLR/SKC/FEW/SCT/BKN/OVC/VV.",
    ),
    FeatureEntry(
        name="sky_base_1_ft",
        source="observation",
        dtype="int",
        unit="ft",
        description="Cloud base height for layer 1 (feet AGL).",
        available_transforms=_temporal_transforms("sky_base_1_ft"),
    ),
    FeatureEntry(
        name="sky_cover_2",
        source="observation",
        dtype="str",
        unit=None,
        description="Cloud cover layer 2.",
    ),
    FeatureEntry(
        name="sky_base_2_ft",
        source="observation",
        dtype="int",
        unit="ft",
        description="Cloud base height for layer 2 (feet AGL).",
    ),
    FeatureEntry(
        name="sky_cover_3",
        source="observation",
        dtype="str",
        unit=None,
        description="Cloud cover layer 3.",
    ),
    FeatureEntry(
        name="sky_base_3_ft",
        source="observation",
        dtype="int",
        unit="ft",
        description="Cloud base height for layer 3 (feet AGL).",
    ),
    FeatureEntry(
        name="sky_cover_4",
        source="observation",
        dtype="str",
        unit=None,
        description="Cloud cover layer 4.",
    ),
    FeatureEntry(
        name="sky_base_4_ft",
        source="observation",
        dtype="int",
        unit="ft",
        description="Cloud base height for layer 4 (feet AGL).",
    ),
    FeatureEntry(
        name="visibility_miles",
        source="observation",
        dtype="float",
        unit="miles",
        description="Visibility in statute miles. Quantized (~18 discrete values, max=10).",
        available_transforms=_temporal_transforms("visibility_miles"),
    ),
    FeatureEntry(
        name="weather_codes",
        source="observation",
        dtype="str",
        unit=None,
        description="Present weather phenomena (e.g. '-RA', 'TSRA', 'SN'). Null = none.",
    ),
    FeatureEntry(
        name="precip_1hr_inches",
        source="observation",
        dtype="float",
        unit="inches",
        description="Precipitation last hour (inches). Trace = 0.0. Null = not reported.",
        available_transforms=_temporal_transforms("precip_1hr_inches"),
    ),
    FeatureEntry(
        name="peak_wind_gust_kt",
        source="observation",
        dtype="int",
        unit="kt",
        description="Peak wind gust from METAR remarks (PK WND).",
    ),
    FeatureEntry(
        name="peak_wind_dir",
        source="observation",
        dtype="int",
        unit="degrees",
        description="Peak wind direction from PK WND remark.",
    ),
    FeatureEntry(
        name="peak_wind_time",
        source="observation",
        dtype="str",
        unit=None,
        description="Peak wind time (HHMM) from PK WND remark.",
    ),
    FeatureEntry(
        name="snow_depth_inches",
        source="observation",
        dtype="float",
        unit="inches",
        description="Snow depth on ground (IEM only — not available from AWC).",
        available_transforms=_temporal_transforms("snow_depth_inches"),
    ),
    FeatureEntry(
        name="qc_field",
        source="observation",
        dtype="int",
        unit=None,
        description="Quality control bitmask from AWC. Bit 0=COR, 1=AUTO, 2=AO2.",
    ),
    FeatureEntry(
        name="raw_metar",
        source="observation",
        dtype="str",
        unit=None,
        description="Raw METAR text string. Authoritative source.",
    ),
]

# ---------------------------------------------------------------------------
# Computed SDK fields
# ---------------------------------------------------------------------------

#: Computed SDK fields (not stored, derived at load time)
_COMPUTED_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="relative_humidity",
        source="computed",
        dtype="float",
        unit="percent",
        description="Relative humidity (0-100). Magnus formula from temp_c + dewpoint_c.",
        available_transforms=_temporal_transforms("relative_humidity"),
    ),
    FeatureEntry(
        name="feels_like_f",
        source="computed",
        dtype="float",
        unit="degF",
        description="Feels-like temperature (NWS algorithm): wind chill or heat index.",
        available_transforms=_temporal_transforms("feels_like_f"),
    ),
]

# ---------------------------------------------------------------------------
# Climate fields (settlement source)
# ---------------------------------------------------------------------------

#: NWS CLI climate fields (settlement source)
_CLIMATE_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="observation_date",
        source="climate",
        dtype="str",
        unit=None,
        description="Settlement date (YYYY-MM-DD). Kalshi contract date.",
        nullable=False,
    ),
    FeatureEntry(
        name="high_temp_f",
        source="climate",
        dtype="float",
        unit="degF",
        description="Daily high temperature. PRIMARY KALSHI SETTLEMENT FIELD for NHIGH contracts.",
        settlement_field=True,
    ),
    FeatureEntry(
        name="low_temp_f",
        source="climate",
        dtype="float",
        unit="degF",
        description="Daily low temperature. PRIMARY KALSHI SETTLEMENT FIELD for NLOW contracts.",
        settlement_field=True,
    ),
    FeatureEntry(
        name="report_type",
        source="climate",
        dtype="str",
        unit=None,
        description="NWS CLI report type: final > ncei_final > correction > preliminary > estimated.",
        nullable=False,
    ),
]

# ---------------------------------------------------------------------------
# IEM MOS forecast fields (specs/forecast.json)
# ---------------------------------------------------------------------------

_FORECAST_IEM_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="model",
        source="forecast_iem",
        dtype="str",
        unit=None,
        description="Forecast model identifier (e.g. 'GFS', 'NBM', 'HRRR').",
        nullable=False,
    ),
    FeatureEntry(
        name="issued_at",
        source="forecast_iem",
        dtype="str",
        unit=None,
        description="Model run issue time (RFC3339 UTC). Groups records into model runs.",
        nullable=False,
    ),
    FeatureEntry(
        name="valid_at",
        source="forecast_iem",
        dtype="str",
        unit=None,
        description="Forecast valid time (RFC3339 UTC). One record per forecast hour.",
        nullable=False,
    ),
    FeatureEntry(
        name="forecast_hour",
        source="forecast_iem",
        dtype="int",
        unit="hours",
        description="Hours from issued_at to valid_at (forecast lead time).",
    ),
    FeatureEntry(
        name="temperature_f",
        source="forecast_iem",
        dtype="float",
        unit="degF",
        description="Hourly forecast temperature (°F). Aggregated max/min to fcst_high_f/fcst_low_f in pairs.",
    ),
    FeatureEntry(
        name="temperature_c",
        source="forecast_iem",
        dtype="float",
        unit="degC",
        description="Hourly forecast temperature (°C).",
    ),
    FeatureEntry(
        name="dewpoint_f",
        source="forecast_iem",
        dtype="float",
        unit="degF",
        description="Forecast dewpoint (°F).",
    ),
    FeatureEntry(
        name="dewpoint_c",
        source="forecast_iem",
        dtype="float",
        unit="degC",
        description="Forecast dewpoint (°C).",
    ),
    FeatureEntry(
        name="wind_speed_kt",
        source="forecast_iem",
        dtype="float",
        unit="kt",
        description="Forecast sustained wind speed (knots).",
    ),
    FeatureEntry(
        name="wind_direction_deg",
        source="forecast_iem",
        dtype="int",
        unit="degrees",
        description="Forecast wind direction (0-360).",
    ),
    FeatureEntry(
        name="wind_gust_kt",
        source="forecast_iem",
        dtype="float",
        unit="kt",
        description="Forecast wind gust (knots).",
    ),
    FeatureEntry(
        name="sky_cover_pct",
        source="forecast_iem",
        dtype="float",
        unit="percent",
        description="Forecast sky cover percentage.",
    ),
    FeatureEntry(
        name="pop_6hr_pct",
        source="forecast_iem",
        dtype="float",
        unit="percent",
        description="Probability of precipitation (PoP) for 6-hour period. Max over window → fcst_pop_6hr_pct in pairs.",
    ),
    FeatureEntry(
        name="pop_12hr_pct",
        source="forecast_iem",
        dtype="float",
        unit="percent",
        description="Probability of precipitation (PoP) for 12-hour period.",
    ),
    FeatureEntry(
        name="qpf_6hr_in",
        source="forecast_iem",
        dtype="float",
        unit="inches",
        description="Quantitative precipitation forecast, 6-hour accumulation. Sum over window → fcst_qpf_6hr_in in pairs.",
    ),
    FeatureEntry(
        name="qpf_12hr_in",
        source="forecast_iem",
        dtype="float",
        unit="inches",
        description="Quantitative precipitation forecast, 12-hour accumulation.",
    ),
    FeatureEntry(
        name="max_min_temp_f",
        source="forecast_iem",
        dtype="float",
        unit="degF",
        description="Combined max/min temperature scalar (n_x value). Not used for pairs aggregation — use temperature_f.",
        nullable=True,
    ),
    FeatureEntry(
        name="snow_flag",
        source="forecast_iem",
        dtype="str",
        unit=None,
        description="Snow flag string ('Y'/'N'). Not a boolean.",
    ),
    FeatureEntry(
        name="thunder_prob_6hr",
        source="forecast_iem",
        dtype="str",
        unit=None,
        description="Probability of thunderstorms in 6-hour window (categorical string, e.g. '0/5').",
    ),
    FeatureEntry(
        name="thunder_prob_12hr",
        source="forecast_iem",
        dtype="str",
        unit=None,
        description="Probability of thunderstorms in 12-hour window (categorical string).",
    ),
    FeatureEntry(
        name="freezing_rain_pct",
        source="forecast_iem",
        dtype="float",
        unit="percent",
        description="Probability of freezing rain.",
    ),
    FeatureEntry(
        name="snow_prob_pct",
        source="forecast_iem",
        dtype="float",
        unit="percent",
        description="Probability of snow.",
    ),
]

# ---------------------------------------------------------------------------
# Open-Meteo forecast fields (specs/forecast_series.json — all metric/SI)
# ---------------------------------------------------------------------------

_FORECAST_OM_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="model",
        source="forecast_openmeteo",
        dtype="str",
        unit=None,
        description="Open-Meteo model identifier (e.g. 'open-meteo-gfs', 'open-meteo-era5').",
        nullable=False,
    ),
    FeatureEntry(
        name="valid_at",
        source="forecast_openmeteo",
        dtype="str",
        unit=None,
        description="Forecast valid time (RFC3339 UTC). No issued_at — all records treated as one run.",
        nullable=False,
    ),
    FeatureEntry(
        name="temperature_c",
        source="forecast_openmeteo",
        dtype="float",
        unit="degC",
        description="Hourly forecast temperature (°C). Convert to °F: temp_c*9/5+32. Aggregated max/min in pairs.",
    ),
    FeatureEntry(
        name="apparent_temperature_c",
        source="forecast_openmeteo",
        dtype="float",
        unit="degC",
        description="Feels-like temperature (°C). NWS-style combo of wind chill / heat index.",
    ),
    FeatureEntry(
        name="dewpoint_c",
        source="forecast_openmeteo",
        dtype="float",
        unit="degC",
        description="Forecast dewpoint (°C).",
    ),
    FeatureEntry(
        name="relative_humidity_pct",
        source="forecast_openmeteo",
        dtype="float",
        unit="percent",
        description="Relative humidity (0-100%).",
    ),
    FeatureEntry(
        name="wind_speed_kmh",
        source="forecast_openmeteo",
        dtype="float",
        unit="km/h",
        description="Forecast sustained wind speed (km/h).",
    ),
    FeatureEntry(
        name="wind_direction_deg",
        source="forecast_openmeteo",
        dtype="int",
        unit="degrees",
        description="Forecast wind direction (0-360).",
    ),
    FeatureEntry(
        name="wind_gusts_kmh",
        source="forecast_openmeteo",
        dtype="float",
        unit="km/h",
        description="Forecast wind gusts (km/h).",
    ),
    FeatureEntry(
        name="precipitation_mm",
        source="forecast_openmeteo",
        dtype="float",
        unit="mm",
        description="Hourly precipitation accumulation (mm). Note: not directly comparable to fcst_qpf_6hr_in.",
    ),
    FeatureEntry(
        name="precipitation_probability_pct",
        source="forecast_openmeteo",
        dtype="float",
        unit="percent",
        description="Probability of precipitation (0-100%). Max over window → fcst_pop_6hr_pct when Open-Meteo used.",
    ),
    FeatureEntry(
        name="rain_mm",
        source="forecast_openmeteo",
        dtype="float",
        unit="mm",
        description="Hourly rain accumulation (mm).",
    ),
    FeatureEntry(
        name="snowfall_cm",
        source="forecast_openmeteo",
        dtype="float",
        unit="cm",
        description="Hourly snowfall (cm).",
    ),
    FeatureEntry(
        name="cloud_cover_pct",
        source="forecast_openmeteo",
        dtype="float",
        unit="percent",
        description="Total cloud cover (0-100%).",
    ),
    FeatureEntry(
        name="visibility_m",
        source="forecast_openmeteo",
        dtype="float",
        unit="meters",
        description="Forecast visibility (meters).",
    ),
    FeatureEntry(
        name="pressure_msl_hpa",
        source="forecast_openmeteo",
        dtype="float",
        unit="hPa",
        description="Mean sea level pressure (hPa).",
    ),
    FeatureEntry(
        name="cape_jkg",
        source="forecast_openmeteo",
        dtype="float",
        unit="J/kg",
        description="Convective Available Potential Energy (CAPE). Proxy for thunderstorm risk.",
    ),
    FeatureEntry(
        name="shortwave_radiation_wm2",
        source="forecast_openmeteo",
        dtype="float",
        unit="W/m²",
        description="Shortwave solar radiation (W/m²).",
    ),
    FeatureEntry(
        name="freezing_level_m",
        source="forecast_openmeteo",
        dtype="float",
        unit="meters",
        description="Altitude of 0°C isotherm (freezing level) in meters.",
    ),
    FeatureEntry(
        name="snow_depth_m",
        source="forecast_openmeteo",
        dtype="float",
        unit="meters",
        description="Snow depth on ground (meters).",
    ),
    FeatureEntry(
        name="weather_code",
        source="forecast_openmeteo",
        dtype="int",
        unit=None,
        description="WMO weather interpretation code.",
    ),
    FeatureEntry(
        name="surface_pressure_hpa",
        source="forecast_openmeteo",
        dtype="float",
        unit="hPa",
        description="Surface pressure (hPa). Differs from pressure_msl_hpa at elevation.",
    ),
    FeatureEntry(
        name="direct_radiation_wm2",
        source="forecast_openmeteo",
        dtype="float",
        unit="W/m²",
        description="Direct solar radiation (W/m²). Distinct from shortwave_radiation_wm2.",
    ),
]

# ---------------------------------------------------------------------------
# GOES satellite fields (stub — requires sprint2/goes-satellite)
# ---------------------------------------------------------------------------

_SATELLITE_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="channel_2_reflectance",
        source="satellite",
        dtype="float",
        unit="percent",
        description="GOES-16/18 Ch2 (0.64µm red visible) reflectance. Daytime cloud detection.",
    ),
    FeatureEntry(
        name="channel_9_brightness_temp_c",
        source="satellite",
        dtype="float",
        unit="degC",
        description="GOES Ch9 (6.9µm mid-level water vapor) brightness temperature.",
    ),
    FeatureEntry(
        name="channel_13_brightness_temp_c",
        source="satellite",
        dtype="float",
        unit="degC",
        description="GOES Ch13 (10.3µm clean longwave IR) brightness temperature. Cloud-top temperature.",
    ),
    FeatureEntry(
        name="cloud_top_height_m",
        source="satellite",
        dtype="float",
        unit="meters",
        description="Derived cloud top height (meters). From IR brightness temperature.",
    ),
    FeatureEntry(
        name="total_precipitable_water_mm",
        source="satellite",
        dtype="float",
        unit="mm",
        description="Total column precipitable water vapor (mm). From GOES sounder.",
    ),
    FeatureEntry(
        name="lifted_index",
        source="satellite",
        dtype="float",
        unit="degC",
        description="Lifted index (instability). Negative = convective potential.",
    ),
    FeatureEntry(
        name="satellite_observed_at",
        source="satellite",
        dtype="str",
        unit=None,
        description="Satellite scan timestamp (RFC3339 UTC).",
        nullable=False,
    ),
    FeatureEntry(
        name="satellite_source",
        source="satellite",
        dtype="str",
        unit=None,
        description="Satellite source identifier (e.g. 'goes-16', 'goes-18').",
        nullable=False,
    ),
]

# ---------------------------------------------------------------------------
# Pairs output columns (from build_pairs_row)
# ---------------------------------------------------------------------------

_PAIRS_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="date",
        source="pairs",
        dtype="str",
        unit=None,
        description="Settlement date (YYYY-MM-DD LST). Primary key for pairs rows.",
        nullable=False,
    ),
    FeatureEntry(
        name="cli_high_f",
        source="pairs",
        dtype="float",
        unit="degF",
        description="NWS CLI daily high (Kalshi NHIGH settlement value). Null until CLI published.",
        settlement_field=True,
    ),
    FeatureEntry(
        name="cli_low_f",
        source="pairs",
        dtype="float",
        unit="degF",
        description="NWS CLI daily low (Kalshi NLOW settlement value). Null until CLI published.",
        settlement_field=True,
    ),
    FeatureEntry(
        name="obs_high_f",
        source="pairs",
        dtype="float",
        unit="degF",
        description="Max observed temperature from METARs in settlement window.",
    ),
    FeatureEntry(
        name="obs_low_f",
        source="pairs",
        dtype="float",
        unit="degF",
        description="Min observed temperature from METARs in settlement window.",
    ),
    FeatureEntry(
        name="obs_mean_f",
        source="pairs",
        dtype="float",
        unit="degF",
        description="Mean observed temperature from METARs in settlement window.",
    ),
    FeatureEntry(
        name="obs_total_precip_in",
        source="pairs",
        dtype="float",
        unit="inches",
        description="Total precipitation from METARs (sum of precip_1hr_inches).",
    ),
    FeatureEntry(
        name="obs_count",
        source="pairs",
        dtype="int",
        unit=None,
        description="Number of METAR observations in the settlement window.",
        nullable=False,
    ),
    FeatureEntry(
        name="fcst_high_f",
        source="pairs",
        dtype="float",
        unit="degF",
        description="Forecast daily high: max(temperature_f) in window from best IEM MOS run, or max(temperature_c*9/5+32) from Open-Meteo.",
    ),
    FeatureEntry(
        name="fcst_low_f",
        source="pairs",
        dtype="float",
        unit="degF",
        description="Forecast daily low: min(temperature_f) in window from best IEM MOS run, or min(temperature_c*9/5+32) from Open-Meteo.",
    ),
    FeatureEntry(
        name="fcst_model",
        source="pairs",
        dtype="str",
        unit=None,
        description="Forecast model used (e.g. 'GFS', 'NBM', 'open-meteo-gfs'). Null if no forecast available.",
    ),
    FeatureEntry(
        name="fcst_issued_at",
        source="pairs",
        dtype="str",
        unit=None,
        description="Issue time of the selected IEM MOS model run. Null for Open-Meteo (no issued_at).",
    ),
    FeatureEntry(
        name="fcst_pop_6hr_pct",
        source="pairs",
        dtype="float",
        unit="percent",
        description="Max PoP (probability of precip) for 6-hour periods in window. From IEM MOS pop_6hr_pct or Open-Meteo precipitation_probability_pct.",
    ),
    FeatureEntry(
        name="fcst_qpf_6hr_in",
        source="pairs",
        dtype="float",
        unit="inches",
        description="Sum of 6-hour QPF values in window (IEM MOS only). Null for Open-Meteo.",
    ),
    FeatureEntry(
        name="obs_mean_dewpoint_f",
        source="pairs",
        dtype="float",
        unit="degF",
        description="Mean dewpoint from METARs in settlement window.",
    ),
    FeatureEntry(
        name="obs_max_wind_kt",
        source="pairs",
        dtype="float",
        unit="kt",
        description="Max wind speed from METARs in settlement window.",
    ),
    FeatureEntry(
        name="obs_max_gust_kt",
        source="pairs",
        dtype="float",
        unit="kt",
        description="Max wind gust from METARs in settlement window.",
    ),
    FeatureEntry(
        name="station",
        source="pairs",
        dtype="str",
        unit=None,
        description="Station code (normalized, e.g. 'NYC').",
        nullable=False,
    ),
    FeatureEntry(
        name="market_close_utc",
        source="pairs",
        dtype="str",
        unit=None,
        description="Kalshi market close UTC timestamp (4:30 PM LST). Forecast run cutoff.",
        nullable=False,
    ),
    FeatureEntry(
        name="cli_report_type",
        source="pairs",
        dtype="str",
        unit=None,
        description="NWS CLI report type for the settlement date.",
    ),
]

# ---------------------------------------------------------------------------
# Market fields (specs/market_unified.json)
# ---------------------------------------------------------------------------

_MARKET_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="market_ticker",
        source="market",
        dtype="str",
        unit=None,
        description="Kalshi/Polymarket market ticker (unique identifier).",
        nullable=False,
    ),
    FeatureEntry(
        name="exchange",
        source="market",
        dtype="str",
        unit=None,
        description="Exchange: 'kalshi' or 'polymarket'. Multi-exchange discriminator field.",
        nullable=False,
    ),
    FeatureEntry(
        name="yes_bid",
        source="market",
        dtype="float",
        unit="cents",
        description="Best bid for YES contract (cents, 0-100). Kalshi FixedPointDollars × 100.",
    ),
    FeatureEntry(
        name="yes_ask",
        source="market",
        dtype="float",
        unit="cents",
        description="Best ask for YES contract (cents, 0-100).",
    ),
    FeatureEntry(
        name="yes_last",
        source="market",
        dtype="float",
        unit="cents",
        description="Last trade price for YES (cents, 0-100).",
    ),
    FeatureEntry(
        name="volume",
        source="market",
        dtype="int",
        unit="contracts",
        description="Total contracts traded.",
    ),
    FeatureEntry(
        name="open_interest",
        source="market",
        dtype="int",
        unit="contracts",
        description="Open interest (outstanding contracts).",
    ),
    FeatureEntry(
        name="settlement_date",
        source="market",
        dtype="str",
        unit=None,
        description="Market settlement date (YYYY-MM-DD). Links to pairs rows.",
    ),
    FeatureEntry(
        name="settlement_field",
        source="market",
        dtype="str",
        unit=None,
        description="Which weather stat this market settles on: 'high_temp_f' or 'low_temp_f'.",
    ),
    FeatureEntry(
        name="result",
        source="market",
        dtype="str",
        unit=None,
        description="Market result: 'yes', 'no', or None if still open.",
    ),
]

# ---------------------------------------------------------------------------
# Derived weather operation fields (from transforms)
# ---------------------------------------------------------------------------

_WEATHER_OP_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="wind_chill",
        source="transform",
        dtype="float",
        unit="degF",
        description="NWS wind chill formula. Valid for temp<=50F and wind>3mph. Spec: wind_chill(temp_f, wind_speed_kt)",
    ),
    FeatureEntry(
        name="heat_index",
        source="transform",
        dtype="float",
        unit="degF",
        description="NWS Rothfusz heat index. Valid for temp>=80F with RH. Spec: heat_index(temp_f, relative_humidity)",
    ),
    FeatureEntry(
        name="spread__temp_f__dewpoint_f",
        source="transform",
        dtype="float",
        unit="degF",
        description="Dewpoint spread (temp_f - dewpoint_f). Larger = drier air. Spec: spread(temp_f, dewpoint_f)",
    ),
]

#: Calendar transform features (from timestamp)
_CALENDAR_FIELDS: list[FeatureEntry] = [
    FeatureEntry(
        name="hour_sin",
        source="transform",
        dtype="float",
        unit=None,
        description="Cyclical hour-of-day encoding (sin). Spec: hour_sin",
        nullable=False,
    ),
    FeatureEntry(
        name="hour_cos",
        source="transform",
        dtype="float",
        unit=None,
        description="Cyclical hour-of-day encoding (cos). Spec: hour_cos",
        nullable=False,
    ),
    FeatureEntry(
        name="day_of_year_sin",
        source="transform",
        dtype="float",
        unit=None,
        description="Cyclical day-of-year encoding (sin). Spec: day_of_year_sin",
        nullable=False,
    ),
    FeatureEntry(
        name="day_of_year_cos",
        source="transform",
        dtype="float",
        unit=None,
        description="Cyclical day-of-year encoding (cos). Spec: day_of_year_cos",
        nullable=False,
    ),
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def feature_catalog(
    include_transforms: bool = True,
    source_filter: str | None = None,
) -> list[FeatureEntry]:
    """Return all available features with descriptions and metadata.

    Designed for AI agent discovery: call this first to understand what
    data is available, then use the ``features=`` parameter to request
    specific transforms.

    Args:
        include_transforms: Include derived transform features (weather ops,
            calendar encoding). Defaults to True.
        source_filter: If provided, only return features from this source.
            One of: "observation", "computed", "climate", "transform",
            "forecast_iem", "forecast_openmeteo", "satellite", "pairs", "market".

    Returns:
        List of FeatureEntry objects with name, unit, description, and
        available_transforms for numeric fields.

    Example::

        from mostlyright import MostlyRightClient
        client = MostlyRightClient()
        catalog = client.feature_catalog()
        # Find all temperature fields
        temp_fields = [f for f in catalog if "temp" in f.name and f.unit == "degF"]
        # Find settlement fields
        settlement = [f for f in catalog if f.settlement_field]
    """
    entries: list[FeatureEntry] = []
    entries.extend(_OBSERVATION_FIELDS)
    entries.extend(_COMPUTED_FIELDS)
    entries.extend(_CLIMATE_FIELDS)
    entries.extend(_FORECAST_IEM_FIELDS)
    entries.extend(_FORECAST_OM_FIELDS)
    entries.extend(_SATELLITE_FIELDS)
    entries.extend(_PAIRS_FIELDS)
    entries.extend(_MARKET_FIELDS)
    if include_transforms:
        entries.extend(_WEATHER_OP_FIELDS)
        entries.extend(_CALENDAR_FIELDS)

    if source_filter is not None:
        entries = [e for e in entries if e.source == source_filter]

    return entries


def describe(station: str) -> str:
    """Return an LLM-ready summary of available features for a station.

    Generated from live feature_catalog() — not a static string. Counts are
    accurate to the current catalog state.

    Args:
        station: Station code (e.g. "NYC", "KATL"). Used for context only.

    Returns:
        Multi-line string suitable for inclusion in an LLM system prompt.
    """
    catalog = feature_catalog(include_transforms=False)
    by_source: dict[str, list[FeatureEntry]] = {}
    for e in catalog:
        by_source.setdefault(e.source, []).append(e)

    all_catalog = feature_catalog(include_transforms=True)
    transform_count = sum(
        len(e.available_transforms)
        for e in all_catalog
        if e.source in ("observation", "computed")
    )

    settlement = [e for e in catalog if e.settlement_field]

    lines = [
        f"MostlyRight feature catalog for station {station}",
        "",
        f"Settlement fields (Kalshi authoritative): {', '.join(e.name for e in settlement)}",
        "",
        "Feature groups:",
    ]
    source_labels = {
        "observation": "Raw METAR observations",
        "computed": "Computed SDK fields",
        "climate": "NWS CLI climate (settlement source)",
        "forecast_iem": "IEM MOS forecast (hourly, with issued_at)",
        "forecast_openmeteo": "Open-Meteo forecast (hourly, metric/SI)",
        "satellite": "GOES satellite (sprint2/goes-satellite)",
        "pairs": "Pairs output columns (training surface)",
        "market": "Market data (multi-exchange, cents)",
    }
    for source, label in source_labels.items():
        group = by_source.get(source, [])
        if group:
            lines.append(f"  {label}: {len(group)} fields")

    lines.extend(
        [
            "",
            f"Temporal transforms available: {transform_count}+ DSL specs",
            "  Ops: lag, diff, diff2, rolling_mean/median/min/max/std/count",
            f"  Windows: {', '.join(_TEMPORAL_WINDOWS)}",
            "",
            "Usage:",
            "  observations(station, features=['temp_f.lag(24h)', 'hour_sin'])",
            "  pairs(station, from_date, to_date, include_forecast=True)",
            "  snapshot(station, as_of='2024-07-04T18:00:00Z')",
        ]
    )
    return "\n".join(lines)
