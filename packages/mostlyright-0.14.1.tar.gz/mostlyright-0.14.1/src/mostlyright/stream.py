"""Async observation stream — yields new observations from AWC.

client.stream(station) returns an async generator that yields Observation
objects as new METARs are published by the Aviation Weather Center.

Design:
  - Polls AWC (via WeatherLive) every `interval` seconds.
  - Yields only NEW observations (deduped by observed_at).
  - Uses asyncio.sleep for non-blocking delays.
  - Stops after `max_obs` observations (default: unlimited).
  - Raises StopAsyncIteration when done or on context exit.

Error handling:
  - Permanent errors (401 AuthenticationError, 403 ForbiddenError,
    404 NotFoundError) are re-raised immediately — retrying won't help.
  - Transient errors (5xx ServerError, network failures) trigger a sleep
    and retry.

Usage::

    import asyncio
    from mostlyright import MostlyRightClient

    async def main():
        client = MostlyRightClient()
        async for obs in client.stream("NYC", max_obs=10):
            print(obs.temp_f, obs.observed_at)

    asyncio.run(main())
"""

from __future__ import annotations

import asyncio
from collections import OrderedDict
from typing import TYPE_CHECKING, AsyncGenerator

from mostlyright.exceptions import AuthenticationError, ForbiddenError, NotFoundError
from mostlyright.weather.live import WeatherLive  # needed for patch target in tests

if TYPE_CHECKING:
    from mostlyright.models.observation import Observation
    from mostlyright.config import TherminalConfig

# Default poll interval: 60 seconds (AWC updates every 2-6 minutes)
DEFAULT_POLL_INTERVAL = 60.0

# Dedupe window: keep track of the last N observed_at values
_DEDUPE_WINDOW = 100

# Permanent errors — retrying will not help
_PERMANENT_ERRORS = (AuthenticationError, ForbiddenError, NotFoundError)


async def stream_observations(
    station: str,
    config: "TherminalConfig | None" = None,
    interval: float = DEFAULT_POLL_INTERVAL,
    max_obs: int | None = None,
    *,
    units: str | None = None,
    timeout: float | None = None,
) -> AsyncGenerator["Observation", None]:
    """Async generator yielding new METAR observations from AWC.

    Polls AWC at `interval` seconds and dedupes by observed_at.
    Only observations not seen in the current session are yielded.

    Args:
        station: Station code (e.g. "NYC", "ATL").
        config: SDK config. Uses defaults if not provided.
        interval: Poll interval in seconds. Default 60.
        max_obs: Stop after this many observations. None = unlimited.
        units: Unit system (raw/metric/imperial). Default raw.
        timeout: Stop streaming after this many seconds. None = unlimited.
            Returns normally when timeout elapses (does not raise).
            Useful for bounded agent inference loops.

    Yields:
        Observation objects for each new METAR.

    Raises:
        AuthenticationError: On 401 — invalid credentials (permanent).
        ForbiddenError: On 403 — access denied (permanent).
        NotFoundError: On 404 — station not found (permanent).
        TherminalError: On other errors after retries.

    Example::

        async for obs in stream_observations("NYC", max_obs=5):
            print(f"{obs.observed_at}: {obs.temp_f}°F")
    """
    from mostlyright.config import TherminalConfig

    cfg = config or TherminalConfig()
    live = WeatherLive(config=cfg)

    seen: OrderedDict[str, None] = OrderedDict()
    count = 0
    start_time = asyncio.get_event_loop().time() if timeout is not None else None

    try:
        while max_obs is None or count < max_obs:
            # Check timeout before each poll
            if timeout is not None and start_time is not None:
                if asyncio.get_event_loop().time() - start_time >= timeout:
                    return

            try:
                observations = live.latest(
                    station=station,
                    hours=2,
                    units=units,
                )
            except _PERMANENT_ERRORS:
                # 401/403/404 — retrying won't help, surface immediately
                raise
            except Exception:
                # Transient: 5xx, network timeout, connection reset, etc.
                await asyncio.sleep(interval)
                continue

            for obs in observations:
                key = obs.observed_at
                if key not in seen:
                    seen[key] = None
                    if len(seen) > _DEDUPE_WINDOW:
                        seen.popitem(last=False)  # O(1) FIFO eviction
                    yield obs
                    count += 1
                    if max_obs is not None and count >= max_obs:
                        return
                    # Check timeout after each yielded obs
                    if timeout is not None and start_time is not None:
                        if asyncio.get_event_loop().time() - start_time >= timeout:
                            return

            await asyncio.sleep(interval)
    finally:
        live.close()
