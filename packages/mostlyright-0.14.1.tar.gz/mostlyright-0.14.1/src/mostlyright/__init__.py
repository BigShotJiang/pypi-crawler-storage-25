"""MostlyRight — settlement truth layer for prediction markets.

Usage:
    from mostlyright import MostlyRightClient
    client = MostlyRightClient()
    obs = client.observations("ATL")

    # Backward compat (drop-in from therminal-py):
    from mostlyright import TherminalClient  # same class
"""

from mostlyright import live
from mostlyright._convert import (
    convert_observation,
    inches_to_mm,
    kt_to_mph,
    kt_to_ms,
    mi_to_km,
)
from mostlyright.client import MostlyRightClient, TherminalClient
from mostlyright.exceptions import (
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TherminalError,
    ValidationError,
)
from mostlyright.weather.forecasts import ForecastHistory

__all__ = [
    "AuthenticationError",
    "ForbiddenError",
    "ForecastHistory",
    "MostlyRightClient",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "TherminalClient",
    "TherminalError",
    "ValidationError",
    "convert_observation",
    "inches_to_mm",
    "kt_to_mph",
    "kt_to_ms",
    "live",
    "mi_to_km",
]
