"""Real-time METAR observations direct from AWC.

Fetches live weather data from aviationweather.gov, returning observation
dicts identical in schema to WeatherHistory.observations().
"""

from __future__ import annotations

import re
import time
from typing import Any

import httpx

from mostlyright._convert import convert_observation
from mostlyright._http import _VERSION
from mostlyright.config import TherminalConfig
from mostlyright.exceptions import RateLimitError, ServerError, TherminalError
from mostlyright.models import Observation
from mostlyright.weather._awc import awc_to_observation

AWC_BASE = "https://aviationweather.gov/api/data/metar"

_ICAO_RE = re.compile(r"^[A-Z0-9]{3,4}$")


def station_to_icao(code: str) -> str:
    """Convert 3-letter station code to ICAO (prepend K for CONUS)."""
    upper = code.strip().upper()
    if not _ICAO_RE.match(upper):
        raise TherminalError(f"Invalid station code: {code!r}")
    if len(upper) == 3:
        return f"K{upper}"
    return upper


class WeatherLive:
    """Real-time METAR observations direct from AWC.

    Fetches live weather data from aviationweather.gov, returning observation
    dicts identical in schema to WeatherHistory.observations().
    """

    def __init__(self, config: TherminalConfig | None = None) -> None:
        self._config = config or TherminalConfig()
        self._client = httpx.Client(
            timeout=self._config.live_timeout,
            headers={"User-Agent": f"mostlyright-py/{_VERSION}"},
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> WeatherLive:
        return self

    def __exit__(self, *a: Any) -> None:
        self.close()

    # -- Public methods -----------------------------------------------

    def current(
        self,
        station: str | list[str] | None = None,
        *,
        units: str | None = None,
        tz: str | None = None,
        as_dataframe: bool = False,
    ) -> list[Observation] | Any:
        """Get latest METAR observation(s).

        Args:
            station: Station code(s). "ATL" or ["ATL", "NYC"].
            units: Unit system override (raw/metric/imperial).
            tz: Timezone override (reserved for future use).
            as_dataframe: Return as Pandas DataFrame.
        """
        stations, resolved = self._resolve(station, units=units, tz=tz)
        raw = self._fetch(stations, hours=1)
        observations = [Observation.from_dict(d) for d in raw]
        if resolved["units"] and resolved["units"] != "raw":
            observations = [
                convert_observation(o, resolved["units"]) for o in observations
            ]
        if as_dataframe:
            return _obs_to_dataframe([o.to_dict() for o in observations])
        return observations

    def latest(
        self,
        station: str | list[str] | None = None,
        *,
        hours: int = 1,
        units: str | None = None,
        tz: str | None = None,
        as_dataframe: bool = False,
    ) -> list[Observation] | Any:
        """Get recent METAR observations for the last N hours.

        Args:
            station: Station code(s).
            hours: Hours of history (1-360, default 1).
            units: Unit system override.
            tz: Timezone override.
            as_dataframe: Return as Pandas DataFrame.
        """
        stations, resolved = self._resolve(station, units=units, tz=tz)
        clamped_hours = min(max(hours, 1), 360)
        raw = self._fetch(stations, hours=clamped_hours)
        observations = [Observation.from_dict(d) for d in raw]
        if resolved["units"] and resolved["units"] != "raw":
            observations = [
                convert_observation(o, resolved["units"]) for o in observations
            ]
        if as_dataframe:
            return _obs_to_dataframe([o.to_dict() for o in observations])
        return observations

    # -- Internal -----------------------------------------------------

    def _resolve(
        self,
        station: str | list[str] | None,
        *,
        units: str | None = None,
        tz: str | None = None,
    ) -> tuple[list[str], dict[str, str | None]]:
        """Normalize station + resolve config defaults."""
        resolved = self._config.resolve(
            units=units,
            tz=tz,
            station=station if isinstance(station, str) else None,
        )

        if isinstance(station, list):
            return list(station), resolved

        effective = station if station is not None else resolved["station"]
        if effective is None:
            raise TherminalError("No station specified and no default in config")

        return [effective], resolved

    def _fetch(
        self,
        stations: list[str],
        hours: int,
    ) -> list[dict[str, Any]]:
        """Fetch from AWC and map to observation dicts."""
        icao_codes = [station_to_icao(s) for s in stations]
        ids = ",".join(icao_codes)
        params = {"ids": ids, "format": "json", "hours": str(hours)}

        resp = self._request_with_retry(AWC_BASE, params=params)

        try:
            raw_json = resp.json()
        except (ValueError, KeyError):
            return []

        if not isinstance(raw_json, list):
            return []

        station_set = set(stations)
        observations: list[dict[str, Any]] = []
        for item in raw_json:
            if not isinstance(item, dict):
                continue
            obs = awc_to_observation(item)
            if obs is not None and obs["station_code"] in station_set:
                observations.append(obs)

        return observations

    def _request_with_retry(
        self, url: str, params: dict[str, str] | None = None
    ) -> httpx.Response:
        """Make GET request with retry logic for rate limits and server errors."""
        attempts = 0
        max_retries = self._config.max_retries

        while True:
            try:
                resp = self._client.get(url, params=params)
            except httpx.TimeoutException:
                raise TherminalError("AWC request timed out") from None
            except httpx.HTTPError as exc:
                raise TherminalError(f"AWC request failed: {exc}") from exc

            if resp.status_code == 429:
                try:
                    retry_after = int(resp.headers.get("Retry-After", "60"))
                except (ValueError, TypeError):
                    retry_after = 60
                if attempts < max_retries:
                    attempts += 1
                    time.sleep(min(retry_after, 10))
                    continue
                raise RateLimitError(retry_after=retry_after)

            if resp.status_code >= 500:
                if attempts < max_retries:
                    attempts += 1
                    time.sleep(2**attempts)
                    continue
                body = resp.text[:200]
                raise ServerError(
                    f"AWC API error {resp.status_code}: {body}",
                    status_code=resp.status_code,
                )

            if not resp.is_success:
                raise TherminalError(
                    f"AWC API error {resp.status_code}: {resp.text[:200]}"
                )

            return resp


def _obs_to_dataframe(obs: list[dict[str, Any]]) -> Any:
    """Convert observation dict list to DataFrame with datetime index."""
    from mostlyright._http import to_dataframe

    return to_dataframe(obs, index_col="observed_at")
