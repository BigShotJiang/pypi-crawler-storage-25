"""Historical forecast access via the MostlyRight API.

ForecastHistory is the training-time counterpart to ``mostlyright.live.get_forecast``
— quants train models on years of historical forecasts pulled from the
MostlyRight API (which reads from R2), then feed live forecasts to the
trained model for inference. Column parity between the two paths is the
contract; see architecture/dataset-pattern.md.

Mirrors the shape of ``mostlyright.weather.client.WeatherHistory`` so a
reader who understands ``observations()`` can read ``forecasts()`` without
learning a new abstraction.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mostlyright._http import HttpSession, to_dataframe
from mostlyright.config import TherminalConfig


class ForecastHistory:
    """Historical forecast access via the MostlyRight API.

    Args:
        config: SDK configuration (base_url, timeout, api_key).
        _session: Optional shared HttpSession from a parent client. When
            provided, close() becomes a no-op for this instance.
    """

    def __init__(
        self,
        config: TherminalConfig | None = None,
        _session: HttpSession | None = None,
    ) -> None:
        self._config = config or TherminalConfig()
        self._http = _session or HttpSession(self._config)
        self._owns_session = _session is None

    def close(self) -> None:
        if self._owns_session:
            self._http.close()

    def __enter__(self) -> ForecastHistory:
        return self

    def __exit__(self, *a: Any) -> None:
        self.close()

    # -- Forecasts (IEM MOS, discrete runs with issued_at) ------------

    def forecasts(
        self,
        station: str,
        from_date: str | None = None,
        to_date: str | None = None,
        model: str | None = None,
        *,
        fmt: str | None = None,
        columns: list[str] | None = None,
        as_dataframe: bool = False,
        save_path: str | Path | None = None,
    ) -> Any:
        """Fetch historical IEM MOS forecasts.

        The API response is ``{"forecasts": [...rows...]}``; this method
        unwraps to plain list-of-dicts or a DataFrame.

        Args:
            station: Station code ("NYC", "KATL").
            from_date: Start date (YYYY-MM-DD). Default: 30 days ago.
            to_date: End date (YYYY-MM-DD). Default: today.
            model: Filter to one MOS model ("NBS", "NBE", "GFS").
            fmt: "toon" for compact text, "parquet"/"csv" for downloads.
            columns: Subset of columns to return.
            as_dataframe: When True and fmt is None, return a DataFrame.
                Default False — matches observations/climate convention.
            save_path: Where to save downloaded parquet/csv bytes.

        Returns:
            list[dict], DataFrame (as_dataframe=True), TOON string
            (fmt="toon"), or Path (fmt="parquet"/"csv").
        """
        return self._fetch_forecast_entity(
            path="/forecasts",
            wrap_key="forecasts",
            index_col="valid_at",
            default_filename="forecasts",
            station=station,
            from_date=from_date,
            to_date=to_date,
            model=model,
            fmt=fmt,
            columns=columns,
            as_dataframe=as_dataframe,
            save_path=save_path,
        )

    # -- Forecast series (Open-Meteo, seamless hourly) ----------------

    def forecast_series(
        self,
        station: str,
        from_date: str | None = None,
        to_date: str | None = None,
        model: str | None = None,
        *,
        fmt: str | None = None,
        columns: list[str] | None = None,
        as_dataframe: bool = False,
        save_path: str | Path | None = None,
    ) -> Any:
        """Fetch historical Open-Meteo forecast series.

        The API response is ``{"forecast_series": [...rows...]}``.

        Args:
            station: Station code.
            from_date: Start date (YYYY-MM-DD). Default: 30 days ago.
            to_date: End date (YYYY-MM-DD). Default: today.
            model: Filter to one Open-Meteo model ("gfs_seamless", etc).
            fmt: "toon" / "parquet" / "csv".
            columns: Subset of columns.
            as_dataframe: Return pandas DataFrame. Default False
                (matches observations/climate convention).
            save_path: Where to save downloaded bytes.
        """
        return self._fetch_forecast_entity(
            path="/forecast_series",
            wrap_key="forecast_series",
            index_col="valid_at",
            default_filename="forecast_series",
            station=station,
            from_date=from_date,
            to_date=to_date,
            model=model,
            fmt=fmt,
            columns=columns,
            as_dataframe=as_dataframe,
            save_path=save_path,
        )

    # -- Shared fetch path --------------------------------------------

    def _fetch_forecast_entity(
        self,
        *,
        path: str,
        wrap_key: str,
        index_col: str,
        default_filename: str,
        station: str,
        from_date: str | None,
        to_date: str | None,
        model: str | None,
        fmt: str | None,
        columns: list[str] | None,
        as_dataframe: bool,
        save_path: str | Path | None,
    ) -> Any:
        params: dict[str, Any] = {
            "station": station,
            "from_date": from_date,
            "to_date": to_date,
            "model": model,
        }

        # Parquet / CSV go through handle_format (file download semantics
        # shared with WeatherHistory.observations/climate).
        if fmt in ("parquet", "csv"):
            return self._http.handle_format(
                path,
                params,
                fmt,
                columns,
                as_dataframe,
                index_col,
                default_filename,
                save_path,
            )

        # TOON is a plain-text body — fetch raw bytes and decode.
        if fmt == "toon":
            params["format"] = "toon"
            if columns:
                params["columns"] = ",".join(columns)
            content = self._http.get_bytes(path, params)
            return content.decode("utf-8")

        # JSON path (default). Forecasts do not paginate (confirmed in
        # api/routes/_read_helpers.py::_ENTITY_CONFIG).
        if columns:
            params["columns"] = ",".join(columns)
        payload = self._http.get(path, params)

        rows: list[dict[str, Any]]
        if isinstance(payload, dict):
            # Guard against a non-list wrap_key value. If the API (or an
            # intermediary) returns ``{"forecasts": "some string"}`` the
            # naive ``list(payload.get(...))`` would turn that string into a
            # list of characters and silently pass garbage downstream.
            wrapped = payload.get(wrap_key, [])
            rows = list(wrapped) if isinstance(wrapped, list) else []
        elif isinstance(payload, list):
            # Defensive: if the server returns an unwrapped list, accept it
            rows = list(payload)
        else:
            rows = []

        if as_dataframe:
            # Intentionally do NOT pass index_col here. The live path
            # (``mostlyright.live.get_forecast``) returns a plain DataFrame
            # with ``valid_at`` as a column, and the column parity contract
            # (architecture/dataset-pattern.md) requires both paths to produce
            # identical column sets. Setting an index would hide ``valid_at``
            # from ``df.columns`` and silently violate parity.
            return to_dataframe(rows)
        return rows
