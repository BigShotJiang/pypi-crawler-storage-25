"""MostlyRight weather data sources."""
