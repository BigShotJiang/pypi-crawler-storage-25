"""Client for weather data endpoints (observations, climate, climate_gaps).

Method signatures identical to therminal-py for drop-in migration.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mostlyright._convert import convert_observation
from mostlyright._http import HttpSession, to_dataframe
from mostlyright.config import TherminalConfig
from mostlyright.models import Observation


class WeatherHistory:
    """Client for historical weather data (observations, climate, climate_gaps)."""

    def __init__(
        self,
        config: TherminalConfig | None = None,
        _session: HttpSession | None = None,
    ) -> None:
        self._config = config or TherminalConfig()
        self._http = _session or HttpSession(self._config)
        self._owns_session = _session is None

    def close(self) -> None:
        if self._owns_session:
            self._http.close()

    def __enter__(self) -> WeatherHistory:
        return self

    def __exit__(self, *a: Any) -> None:
        self.close()

    # -- Observations -------------------------------------------------

    def observations(
        self,
        station: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        obs_type: str | None = None,
        resolution: str | None = None,
        units: str | None = None,
        tz: str | None = None,
        fmt: str | None = None,
        columns: list[str] | None = None,
        limit: int = 1000,
        offset: int = 0,
        as_dataframe: bool = False,
        save_path: str | Path | None = None,
    ) -> list[Observation] | Path | Any:
        """Get weather observations (METAR/SPECI)."""
        resolved = self._config.resolve(units=units, tz=tz, station=station)
        params: dict[str, Any] = {
            "station": resolved["station"],
            "from_date": from_date,
            "to_date": to_date,
            "obs_type": obs_type,
            "resolution": resolution,
            "offset": offset,
        }

        if fmt in ("csv", "parquet"):
            params["limit"] = limit
            return self._http.handle_format(
                "/observations",
                params,
                fmt,
                columns,
                as_dataframe,
                "observed_at",
                "observations",
                save_path,
            )

        if as_dataframe and fmt is None and limit == 1000:
            return self._http.handle_format(
                "/observations",
                {**params},
                "parquet",
                columns,
                True,
                "observed_at",
                "observations",
                save_path,
            )

        if limit != 1000:
            params["limit"] = limit
        if columns:
            params["columns"] = ",".join(columns)
        data = self._http.get_all("/observations", params)

        observations = [Observation.from_dict(d) for d in data]
        if resolved["units"] and resolved["units"] != "raw":
            observations = [
                convert_observation(o, resolved["units"]) for o in observations
            ]

        if as_dataframe:
            return to_dataframe(
                [o.to_dict() for o in observations], index_col="observed_at"
            )

        return observations

    # -- Climate ------------------------------------------------------

    def climate(
        self,
        station: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        units: str | None = None,
        fmt: str | None = None,
        columns: list[str] | None = None,
        limit: int = 1000,
        offset: int = 0,
        as_dataframe: bool = False,
        save_path: str | Path | None = None,
    ) -> list[dict[str, Any]] | Path | Any:
        """Get daily climate reports (NWS CLI products)."""
        resolved = self._config.resolve(units=units, station=station)
        params: dict[str, Any] = {
            "station": resolved["station"],
            "from_date": from_date,
            "to_date": to_date,
            "offset": offset,
        }

        if fmt in ("csv", "parquet"):
            params["limit"] = limit
            return self._http.handle_format(
                "/climate",
                params,
                fmt,
                columns,
                as_dataframe,
                "observation_date",
                "climate",
                save_path,
            )

        if as_dataframe and fmt is None and limit == 1000:
            return self._http.handle_format(
                "/climate",
                {**params},
                "parquet",
                columns,
                True,
                "observation_date",
                "climate",
                save_path,
            )

        if limit != 1000:
            params["limit"] = limit
        if columns:
            params["columns"] = ",".join(columns)
        data = self._http.get_all("/climate", params)

        if as_dataframe:
            return to_dataframe(data, index_col="observation_date")

        return data

    # -- Analysis -----------------------------------------------------

    def climate_gaps(
        self,
        station: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        as_dataframe: bool = False,
    ) -> list[dict[str, Any]] | Any:
        """Find gaps in climate report history for a station."""
        resolved = self._config.resolve(station=station)
        params: dict[str, Any] = {
            "station": resolved["station"],
            "from_date": from_date,
            "to_date": to_date,
        }
        data = self._http.get("/climate/gaps", params)
        return to_dataframe(data) if as_dataframe else data


# Backward compat alias
WeatherClient = WeatherHistory
