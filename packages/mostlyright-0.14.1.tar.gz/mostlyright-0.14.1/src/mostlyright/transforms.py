"""Temporal transforms for weather observation DataFrames.

Provides a DSL for specifying feature transforms on irregularly-spaced
METAR data. All operations are time-aware and correct for irregular spacing.

DSL syntax::

    "temp_f.lag(24h)"               # value 24 hours ago
    "temp_f.lag(7d)"                # value 7 days ago
    "temp_f.diff(24h)"              # current minus 24h-ago value
    "temp_f.diff2(24h)"             # second-order difference
    "temp_f.rolling_mean(6h)"       # 6-hour trailing rolling mean
    "wind_speed_kt.rolling_max(12h)"
    "temp_f.rolling_median(6h)"
    "temp_f.rolling_min(3h)"
    "temp_f.rolling_std(6h)"
    "temp_f.rolling_count(6h)"
    "day_of_year_sin"               # cyclical day-of-year encoding
    "day_of_year_cos"
    "hour_sin"                      # cyclical hour-of-day encoding
    "hour_cos"
    "spread(temp_f, dewpoint_f)"    # temp_f - dewpoint_f
    "wind_chill(temp_f, wind_speed_kt)"   # NWS wind chill
    "heat_index(temp_f, relative_humidity)"  # NWS heat index

Output column names::

    "temp_f__lag_24h"
    "temp_f__diff_24h"
    "temp_f__rolling_mean_6h"
    "day_of_year_sin"
    "spread__temp_f__dewpoint_f"
    "wind_chill"
    "heat_index"

NOT included: z-scores, anomaly detection, forecast bias, or any signal
computation. This is purely data preparation.

Available feature groups (for ``features=`` parameter on client methods):

  - Temporal:  ``"field.lag(Nh)"``, ``"field.diff(Nh)"``, ``"field.diff2(Nh)"``,
               ``"field.rolling_mean(Nh)"``, ``"field.rolling_median(Nh)"``,
               ``"field.rolling_min(Nh)"``, ``"field.rolling_max(Nh)"``,
               ``"field.rolling_std(Nh)"``, ``"field.rolling_count(Nh)"``
  - Calendar:  ``"day_of_year_sin"``, ``"day_of_year_cos"``,
               ``"hour_sin"``, ``"hour_cos"``
  - Cross:     ``"spread(field1, field2)"``, ``"wind_chill(temp_f, wind_kt)"``,
               ``"heat_index(temp_f, rh)"``

Requires pandas (soft dependency)::

    pip install pandas
"""

from __future__ import annotations

import math
import re
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    import pandas as pd

# ---------------------------------------------------------------------------
# DSL constants
# ---------------------------------------------------------------------------

# Matches: field_name.op_name(NNh) or field_name.op_name(NNd)
# op_name may contain digits (e.g. diff2 for second-order difference)
_FIELD_OP_RE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\.([a-z][a-z0-9_]*)\((\d+[hd])\)$")

# Cross-feature functions
_CROSS_RE = re.compile(r"^(spread|wind_chill|heat_index)\(([^)]+)\)$")

_CALENDAR_FEATURES: frozenset[str] = frozenset(
    {"day_of_year_sin", "day_of_year_cos", "hour_sin", "hour_cos"}
)

_TEMPORAL_OPS: frozenset[str] = frozenset(
    {
        "lag",
        "diff",
        "diff2",
        "rolling_mean",
        "rolling_median",
        "rolling_min",
        "rolling_max",
        "rolling_std",
        "rolling_count",
    }
)

_KT_TO_MPH = 1.15078


# ---------------------------------------------------------------------------
# Window parsing
# ---------------------------------------------------------------------------


def _parse_window(s: str) -> Any:  # returns pd.Timedelta
    """Parse '24h' or '7d' to pd.Timedelta."""
    import pandas as pd  # noqa: PLC0415

    n = int(s[:-1])
    unit = s[-1]
    if unit == "h":
        return pd.Timedelta(hours=n)
    if unit == "d":
        return pd.Timedelta(days=n)
    raise ValueError(f"Unknown window unit in {s!r}. Use 'h' (hours) or 'd' (days).")


# ---------------------------------------------------------------------------
# FeatureSpec — parsed representation of one feature string
# ---------------------------------------------------------------------------


class FeatureSpec:
    """Parsed feature spec. Validates the DSL string and stores components.

    Args:
        spec: Feature spec string, e.g. ``"temp_f.lag(24h)"`` or ``"hour_sin"``.

    Raises:
        ValueError: If the spec cannot be parsed or the op is unknown.
    """

    def __init__(self, spec: str) -> None:
        self.raw: str = spec.strip()
        self.kind: str  # "temporal" | "calendar" | "cross"
        self.output_col: str

        # --- Calendar feature ---
        if self.raw in _CALENDAR_FEATURES:
            self.kind = "calendar"
            self.output_col = self.raw
            return

        # --- Cross-feature derived op: func(arg1, arg2) ---
        m = _CROSS_RE.match(self.raw)
        if m:
            self.kind = "cross"
            self.func: str = m.group(1)
            self.args: list[str] = [a.strip() for a in m.group(2).split(",")]
            if len(self.args) != 2:
                raise ValueError(
                    f"{self.func}() requires exactly 2 arguments, "
                    f"got {len(self.args)}: {self.raw!r}"
                )
            if self.func == "spread":
                self.output_col = f"spread__{self.args[0]}__{self.args[1]}"
            else:
                # "wind_chill" or "heat_index"
                self.output_col = self.func
            return

        # --- Temporal: field.op(window) ---
        m2 = _FIELD_OP_RE.match(self.raw)
        if m2:
            self.kind = "temporal"
            self.field: str = m2.group(1)
            self.op: str = m2.group(2)
            self.window_str: str = m2.group(3)
            if self.op not in _TEMPORAL_OPS:
                raise ValueError(
                    f"Unknown transform op: {self.op!r}. "
                    f"Valid ops: {sorted(_TEMPORAL_OPS)}"
                )
            self.output_col = f"{self.field}__{self.op}_{self.window_str}"
            return

        raise ValueError(
            f"Cannot parse feature spec: {spec!r}. "
            "Expected 'field.op(window)', 'calendar_feature', "
            "or 'cross_func(arg1, arg2)'."
        )

    def __repr__(self) -> str:
        return f"FeatureSpec({self.raw!r} → {self.output_col!r})"


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def apply_features(
    df: pd.DataFrame,
    features: list[str],
    time_col: str = "observed_at",
) -> pd.DataFrame:
    """Apply feature transform specs to an observations DataFrame.

    The DataFrame must contain `time_col` with UTC-aware or UTC-naive
    ISO-format timestamps. Data is sorted by `time_col` before transforms
    are applied (required for correct rolling/lag calculations on irregular
    METAR spacing).

    Args:
        df: DataFrame of observations. Must contain `time_col`.
        features: List of feature spec strings. Empty list returns df unchanged.
        time_col: Column name holding observation timestamps.

    Returns:
        New DataFrame with original columns plus one column per feature.
        Rows are in ascending time order. The original DataFrame is not modified.

    Raises:
        ImportError: If pandas is not installed.
        ValueError: If a feature spec cannot be parsed.
        KeyError: If a required column is missing for a cross-feature op.
    """
    try:
        import pandas as pd  # noqa: PLC0415
    except ImportError:
        raise ImportError(
            "pandas is required for feature transforms. "
            "Install with: pip install mostlyright[parquet]"
        ) from None

    if not features:
        return df.copy()

    # Parse all specs up front so bad specs fail fast before any computation.
    specs = [FeatureSpec(f) for f in features]

    if df.empty:
        result = df.copy()
        for spec in specs:
            result[spec.output_col] = pd.Series(dtype="float64")
        return result

    # Ensure timestamp column is datetime.
    result = df.copy()
    if time_col in result.columns:
        col = result[time_col]
        if not pd.api.types.is_datetime64_any_dtype(col):
            result[time_col] = pd.to_datetime(col, utc=True)

    # Sort ascending by time — required for searchsorted-based lag and rolling.
    result = result.sort_values(time_col).reset_index(drop=True)

    for spec in specs:
        if spec.kind == "temporal":
            _apply_temporal(result, spec, time_col)
        elif spec.kind == "calendar":
            _apply_calendar(result, spec, time_col)
        elif spec.kind == "cross":
            _apply_cross(result, spec)

    return result


# ---------------------------------------------------------------------------
# Temporal transforms
# ---------------------------------------------------------------------------


def _apply_temporal(df: pd.DataFrame, spec: FeatureSpec, time_col: str) -> None:
    """Compute and attach temporal feature column in-place."""
    window = _parse_window(spec.window_str)
    field = spec.field
    op = spec.op

    if op == "lag":
        df[spec.output_col] = _lag(df, field, time_col, window)
    elif op == "diff":
        lagged = _lag(df, field, time_col, window)
        df[spec.output_col] = df[field] - lagged
    elif op == "diff2":
        # Second-order: diff of diff
        lag1 = _lag(df, field, time_col, window)
        diff1 = df[field] - lag1
        diff1_series = diff1.copy()
        # Lag of diff1 at same window. ``df[time_col]`` returns a Series for
        # a str column — cast explicitly so the type checker knows.
        time_series = cast("pd.Series", df[time_col])
        diff1_lagged = _lag_series(time_series, diff1_series, window)
        df[spec.output_col] = diff1 - diff1_lagged
    else:
        # Rolling aggregates
        df[spec.output_col] = _rolling(df, field, time_col, window, op)


def _lag(df: pd.DataFrame, field: str, time_col: str, window: Any) -> pd.Series:
    """For each row at time t, return field value at the latest time <= t - window.

    Uses binary search (searchsorted) — correct for irregular METAR spacing.
    """
    import numpy as np  # noqa: PLC0415
    import pandas as pd  # noqa: PLC0415

    # ``.values`` on a Series can return a numpy array OR a pandas
    # ExtensionArray (e.g. for Float64 nullable dtypes). ``np.asarray``
    # coerces both to the ndarray that ``np.searchsorted`` requires.
    times = np.asarray(df[time_col].values)
    values = np.asarray(df[field].values)

    target_times = df[time_col] - window
    results: list[Any] = []

    for t_target in target_times:
        # Find the rightmost position where times <= t_target
        pos = int(np.searchsorted(times, t_target.to_datetime64(), side="right")) - 1
        if pos >= 0:
            v = values[pos]
            results.append(None if (isinstance(v, float) and math.isnan(v)) else v)
        else:
            results.append(None)

    return pd.array(results, dtype="Float64")  # type: ignore[call-overload]


def _lag_series(time_col: pd.Series, series: pd.Series, window: Any) -> pd.Series:
    """Lag an arbitrary Series by the given time window."""
    import numpy as np  # noqa: PLC0415
    import pandas as pd  # noqa: PLC0415

    times = np.asarray(time_col.values)
    values = np.asarray(series.values)
    target_times = time_col - window
    results: list[Any] = []

    for t_target in target_times:
        pos = int(np.searchsorted(times, t_target.to_datetime64(), side="right")) - 1
        if pos >= 0:
            v = values[pos]
            results.append(None if (isinstance(v, float) and math.isnan(v)) else v)
        else:
            results.append(None)

    return pd.array(results, dtype="Float64")  # type: ignore[call-overload]


def _rolling(
    df: pd.DataFrame, field: str, time_col: str, window: Any, op: str
) -> pd.Series:
    """Time-based rolling aggregate on irregularly-spaced data.

    Uses a DatetimeIndex + pandas rolling(window, closed='left') to include
    all observations in [t - window, t]. min_periods=1 avoids NaN at edges.
    """

    # Build a temporary series with DatetimeIndex.
    s = df.set_index(time_col)[field].astype("float64")

    # closed='left' means the window is [t - window, t), excluding current row.
    # closed='right' means (t - window, t], excluding the oldest boundary.
    # We use closed='right' so the window includes the current observation.
    roller = s.rolling(window=window, min_periods=1, closed="right")

    if op == "rolling_mean":
        rolled = roller.mean()
    elif op == "rolling_median":
        rolled = roller.median()
    elif op == "rolling_min":
        rolled = roller.min()
    elif op == "rolling_max":
        rolled = roller.max()
    elif op == "rolling_std":
        rolled = roller.std(ddof=1)
    elif op == "rolling_count":
        rolled = roller.count()
    else:
        raise ValueError(f"Unknown rolling op: {op!r}")

    # Reset index so result aligns with df's integer index. pandas typing
    # narrows ``rolled`` to Series|DataFrame|ndarray here; in practice every
    # branch above returns a Series, and ``reset_index(drop=True)`` on a
    # Series always returns a Series — cast to keep the return type tight.
    rolled_series = cast("pd.Series", rolled).reset_index(drop=True)
    return cast("pd.Series", rolled_series)


# ---------------------------------------------------------------------------
# Calendar / cyclical features
# ---------------------------------------------------------------------------


def _apply_calendar(df: pd.DataFrame, spec: FeatureSpec, time_col: str) -> None:
    """Compute cyclical calendar feature and attach in-place."""
    import numpy as np  # noqa: PLC0415

    ts = cast("pd.Series", df[time_col])
    name = spec.raw

    if name == "day_of_year_sin":
        doy = ts.dt.day_of_year
        df[name] = np.sin(2 * math.pi * doy / 365.25)
    elif name == "day_of_year_cos":
        doy = ts.dt.day_of_year
        df[name] = np.cos(2 * math.pi * doy / 365.25)
    elif name == "hour_sin":
        hour = ts.dt.hour + ts.dt.minute / 60.0
        df[name] = np.sin(2 * math.pi * hour / 24.0)
    elif name == "hour_cos":
        hour = ts.dt.hour + ts.dt.minute / 60.0
        df[name] = np.cos(2 * math.pi * hour / 24.0)


# ---------------------------------------------------------------------------
# Cross-feature derived ops
# ---------------------------------------------------------------------------


def _apply_cross(df: pd.DataFrame, spec: FeatureSpec) -> None:
    """Compute cross-feature derived op and attach in-place."""
    func = spec.func
    args = spec.args

    if func == "spread":
        col_a, col_b = args[0], args[1]
        if col_a not in df.columns or col_b not in df.columns:
            raise KeyError(
                f"spread() requires columns {col_a!r} and {col_b!r}; "
                f"available: {list(df.columns)}"
            )
        df[spec.output_col] = df[col_a].astype("float64") - df[col_b].astype("float64")

    elif func == "wind_chill":
        temp_col, wind_col = args[0], args[1]
        if temp_col not in df.columns or wind_col not in df.columns:
            raise KeyError(
                f"wind_chill() requires columns {temp_col!r} and {wind_col!r}; "
                f"available: {list(df.columns)}"
            )
        df[spec.output_col] = df.apply(
            lambda row: _nws_wind_chill(row[temp_col], row[wind_col]),
            axis=1,
        )

    elif func == "heat_index":
        temp_col, rh_col = args[0], args[1]
        if temp_col not in df.columns or rh_col not in df.columns:
            raise KeyError(
                f"heat_index() requires columns {temp_col!r} and {rh_col!r}; "
                f"available: {list(df.columns)}"
            )
        df[spec.output_col] = df.apply(
            lambda row: _nws_heat_index(row[temp_col], row[rh_col]),
            axis=1,
        )


# ---------------------------------------------------------------------------
# NWS formula implementations (mirrors _convert.py, no rounding)
# ---------------------------------------------------------------------------


def _nws_wind_chill(temp_f: Any, wind_kt: Any) -> float | None:
    """NWS wind chill formula in °F. Returns temp_f when conditions not met.

    Valid for temp <= 50°F and wind > 3 mph. No rounding.
    """
    if temp_f is None:
        return None
    try:
        t = float(temp_f)
        if not math.isfinite(t):
            return None
        w_mph = float(wind_kt) * _KT_TO_MPH if wind_kt is not None else 0.0
        if t <= 50.0 and w_mph > 3.0:
            return (
                35.74 + 0.6215 * t - 35.75 * (w_mph**0.16) + 0.4275 * t * (w_mph**0.16)
            )
        return t
    except (ValueError, TypeError, OverflowError):
        return None


def _nws_heat_index(temp_f: Any, rh: Any) -> float | None:
    """NWS heat index (Rothfusz regression) in °F. No rounding.

    Valid for temp >= 80°F with known RH. Returns temp_f otherwise.
    """
    if temp_f is None:
        return None
    try:
        t = float(temp_f)
        if not math.isfinite(t):
            return None
        if rh is None or not math.isfinite(float(rh)):
            return t
        h = float(rh)

        if t < 80.0:
            return t

        # Step 1: Steadman simplified
        simple = 0.5 * (t + 61.0 + (t - 68.0) * 1.2 + h * 0.094)
        if (simple + t) / 2.0 < 80.0:
            return simple

        # Step 2: Rothfusz regression
        hi = (
            -42.379
            + 2.04901523 * t
            + 10.14333127 * h
            - 0.22475541 * t * h
            - 0.00683783 * t * t
            - 0.05481717 * h * h
            + 0.00122874 * t * t * h
            + 0.00085282 * t * h * h
            - 0.00000199 * t * t * h * h
        )

        # Step 3: NWS adjustments
        if h < 13.0 and 80.0 <= t <= 112.0:
            hi -= ((13.0 - h) / 4.0) * math.sqrt((17.0 - abs(t - 95.0)) / 17.0)
        elif h > 85.0 and 80.0 <= t <= 87.0:
            hi += ((h - 85.0) / 10.0) * ((87.0 - t) / 5.0)

        return hi
    except (ValueError, TypeError, OverflowError):
        return None


# ---------------------------------------------------------------------------
# Exported constants
# ---------------------------------------------------------------------------

#: All temporal op names available in the DSL.
TEMPORAL_OPS: frozenset[str] = _TEMPORAL_OPS

#: All calendar feature names available in the DSL.
CALENDAR_FEATURES: frozenset[str] = _CALENDAR_FEATURES

#: Cross-feature function names.
CROSS_FUNCTIONS: frozenset[str] = frozenset({"spread", "wind_chill", "heat_index"})

#: Union of all feature spec groups — used by feature_catalog().
FEATURE_GROUPS: frozenset[str] = TEMPORAL_OPS | CALENDAR_FEATURES | CROSS_FUNCTIONS
