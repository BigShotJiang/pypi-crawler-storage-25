"""pyarrow schemas for forecast datasets.

Schemas are built from ``mostlyright._forecast_columns`` — that module is
the single source of truth for field names and declared dtypes, and it
has zero pyarrow dependency so the live SDK path can import column names
without dragging pyarrow into ``from mostlyright import MostlyRightClient``.

Lives under ``src/mostlyright`` (not ``ingest/``) so the SDK can use
these schemas when installed from a wheel. The ``ingest`` side re-exports
from here for backward compat — writers and readers continue to use the
same ``FORECAST_SCHEMA`` / ``FORECAST_SERIES_SCHEMA`` constants so
field-name drift is impossible.
"""

from __future__ import annotations

from typing import Callable

import pyarrow as pa

from mostlyright._forecast_columns import FORECAST_FIELDS, FORECAST_SERIES_FIELDS

# Mapping of dtype-name-string → pyarrow type factory. Kept small on
# purpose — if a new dtype string appears in ``_forecast_columns``,
# ``_build_schema`` raises KeyError so the omission is loud, not silent.
_DTYPE_FACTORIES: dict[str, Callable[[], pa.DataType]] = {
    "string": pa.string,
    "int32": pa.int32,
    "int64": pa.int64,
    "float64": pa.float64,
}


def _build_schema(fields: tuple[tuple[str, str], ...]) -> pa.Schema:
    built: list[pa.Field] = []
    for name, dtype in fields:
        factory = _DTYPE_FACTORIES.get(dtype)
        if factory is None:
            raise ValueError(
                f"Unknown dtype {dtype!r} for field {name!r}. "
                f"Add it to _DTYPE_FACTORIES in mostlyright/_forecast_schema.py."
            )
        built.append(pa.field(name, factory()))
    return pa.schema(built)


FORECAST_SCHEMA: pa.Schema = _build_schema(FORECAST_FIELDS)
FORECAST_SERIES_SCHEMA: pa.Schema = _build_schema(FORECAST_SERIES_FIELDS)
