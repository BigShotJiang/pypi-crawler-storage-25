"""Forecast column definitions — pure python, no pyarrow.

Why this file exists: ``_forecast_schema.py`` builds pyarrow schemas, which
means it has to ``import pyarrow`` at module load. Before Sprint 2l the
live forecast path (``mostlyright.live.forecasts``) reached into those
schemas just to get the column name list, which pulled pyarrow into the
import graph of ``from mostlyright import MostlyRightClient``.

Splitting the column names out here lets core-SDK consumers (``live``) use
the column lists without pyarrow. ``_forecast_schema.py`` still imports
from here to build the pyarrow schemas for server-side parquet I/O. One
source of truth for field names + declared dtypes; zero pyarrow dependency
in the SDK-core import graph.

Adding a column:
  1. Add ``(name, dtype)`` to the relevant ``*_FIELDS`` tuple below.
  2. The ``_forecast_schema.py`` pyarrow build picks it up automatically.
  3. Update ``specs/forecast.json`` or ``specs/forecast_series.json`` so
     the JSON Schema stays in sync.

``dtype`` values are the string names of pyarrow primitive constructors.
Supported values: ``"string"``, ``"int32"``, ``"int64"``, ``"float64"``.
Adding a new dtype requires a matching entry in
``_forecast_schema._DTYPE_FACTORIES`` — the schema builder raises
``ValueError`` with the field + dtype in the message if the mapping is
missing, so omissions are loud.
"""

from __future__ import annotations

# IEM MOS — discrete model runs with issued_at.
FORECAST_FIELDS: tuple[tuple[str, str], ...] = (
    ("station_code", "string"),
    ("model", "string"),
    ("source", "string"),
    ("issued_at", "string"),
    ("valid_at", "string"),
    ("forecast_hour", "int32"),
    ("ingested_at", "string"),
    ("temperature_f", "float64"),
    ("dewpoint_f", "float64"),
    ("temperature_c", "float64"),
    ("dewpoint_c", "float64"),
    ("wind_speed_kt", "int32"),
    ("wind_direction_deg", "int32"),
    ("wind_gust_kt", "int32"),
    ("cloud_cover_code", "string"),
    ("sky_cover_pct", "int32"),
    ("ceiling_cat", "int32"),
    ("visibility_cat", "int32"),
    ("pop_6hr_pct", "float64"),
    ("pop_12hr_pct", "float64"),
    ("qpf_6hr_in", "float64"),
    ("qpf_12hr_in", "float64"),
    ("snow_flag", "string"),
    ("precip_type", "string"),
    ("freezing_rain_pct", "int32"),
    ("snow_prob_pct", "int32"),
    ("sleet_prob_pct", "int32"),
    ("rain_prob_pct", "int32"),
    ("thunder_prob_6hr", "string"),
    ("thunder_prob_12hr", "string"),
    ("max_min_temp_f", "float64"),
    ("transport_wind_speed", "int32"),
    ("transport_wind_dir", "int32"),
    ("mixing_height", "int32"),
    ("haines_index", "int32"),
    ("solar_radiation", "int32"),
    ("low_cloud_base", "int32"),
    ("snow_level", "int32"),
)

# Open-Meteo — seamless hourly series, no issued_at.
FORECAST_SERIES_FIELDS: tuple[tuple[str, str], ...] = (
    ("station_code", "string"),
    ("model", "string"),
    ("source", "string"),
    ("valid_at", "string"),
    ("ingested_at", "string"),
    ("temperature_c", "float64"),
    ("dewpoint_c", "float64"),
    ("relative_humidity_pct", "float64"),
    ("apparent_temperature_c", "float64"),
    ("wind_speed_kmh", "float64"),
    ("wind_direction_deg", "int32"),
    ("wind_gusts_kmh", "float64"),
    ("pressure_msl_hpa", "float64"),
    ("surface_pressure_hpa", "float64"),
    ("cloud_cover_pct", "int32"),
    ("visibility_m", "float64"),
    ("weather_code", "int32"),
    ("precipitation_mm", "float64"),
    ("precipitation_probability_pct", "int32"),
    ("rain_mm", "float64"),
    ("snowfall_cm", "float64"),
    ("shortwave_radiation_wm2", "float64"),
    ("direct_radiation_wm2", "float64"),
    ("cape_jkg", "float64"),
    ("freezing_level_m", "float64"),
    ("snow_depth_m", "float64"),
)

FORECAST_COLUMNS: tuple[str, ...] = tuple(name for name, _ in FORECAST_FIELDS)
FORECAST_SERIES_COLUMNS: tuple[str, ...] = tuple(
    name for name, _ in FORECAST_SERIES_FIELDS
)
