"""Live upstream endpoints for MostlyRight SDK.

These bypass the MostlyRight API entirely — the SDK calls the upstream
forecast source (IEM, Open-Meteo) directly from the quant's machine. This
is the inference-time path paired with the historical MostlyRight API
(the training-time path). See architecture/dataset-pattern.md for the
paired-contract column parity rule.
"""

from __future__ import annotations

from mostlyright.live.forecasts import get_forecast

__all__ = ["get_forecast"]
