"""Live forecast fetch — direct from IEM MOS or Open-Meteo.

Columns MUST match the historical API response (column parity contract).
IEM: reuses ``ingest.sources.iem_mos._parse_iem_record`` so the schema is
the single source of truth for IEM field names. Open-Meteo: reuses
``VARIABLE_MAP`` for the same reason.

The SDK live Open-Meteo call hits the LIVE forecast endpoint
(``api.open-meteo.com/v1/forecast``), NOT the historical endpoint that
``ingest/sources/open_meteo.py`` uses. Same VARIABLE_MAP, different URL.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any

import httpx

from mostlyright._forecast_columns import FORECAST_COLUMNS, FORECAST_SERIES_COLUMNS
from mostlyright._forecast_parse import (
    HOURLY_VARIABLES,
    IEM_HTTP_TIMEOUT as _IEM_TIMEOUT,
    IEM_MODELS,
    IEM_MOS_BULK_URL,
    LIVE_FORECAST_URL,
    OM_HTTP_TIMEOUT as _OM_TIMEOUT,
    OM_MAX_HORIZON_H,
    OPEN_METEO_MODELS,
    VARIABLE_MAP,
    _parse_iem_record,
    _unix_to_rfc3339,
)
from mostlyright._stations import STATIONS, StationInfo

if TYPE_CHECKING:  # pragma: no cover - typing only
    import pandas as pd

_VALID_SOURCES = frozenset({"iem", "open_meteo"})
_VALID_IEM_MODELS = frozenset(IEM_MODELS)
_VALID_OM_MODELS = frozenset(OPEN_METEO_MODELS)


def _station_or_raise(station: str) -> StationInfo:
    code = station.strip().upper()
    if len(code) == 4 and code.startswith("K"):
        code = code[1:]
    info = STATIONS.get(code)
    if info is None:
        raise ValueError(
            f"Unknown station {station!r}. Valid codes: {sorted(STATIONS)}."
        )
    return info


def _iem_live_url(station: StationInfo, model: str, horizon_h: int) -> str:
    today = datetime.now(timezone.utc).date()
    end = today + timedelta(days=max(1, (horizon_h + 23) // 24))
    sts = datetime(today.year, today.month, today.day, tzinfo=timezone.utc)
    ets_date = end + timedelta(days=1)
    ets = datetime(ets_date.year, ets_date.month, ets_date.day, tzinfo=timezone.utc)
    return (
        f"{IEM_MOS_BULK_URL}"
        f"?station={station.icao}"
        f"&model={model}"
        f"&sts={sts.strftime('%Y-%m-%dT%H:%MZ')}"
        f"&ets={ets.strftime('%Y-%m-%dT%H:%MZ')}"
        f"&format=json"
    )


def _require_pandas() -> Any:
    """Import pandas or raise the canonical MostlyRight extras-hint error.

    Every live-forecast call path funnels through one of the helpers below,
    so catching the ImportError here gives core-only installs (``pip install
    mostlyright`` without ``[parquet]``) a single, actionable message instead
    of a bare ``ModuleNotFoundError: No module named 'pandas'``.
    """
    try:
        import pandas as pd  # noqa: PLC0415
    except ImportError:
        raise ImportError(
            "pandas is required for live forecast output. "
            "Install with: pip install mostlyright[parquet]"
        ) from None
    return pd


def _empty_frame(columns: list[str]) -> "pd.DataFrame":
    pd = _require_pandas()
    return pd.DataFrame(columns=columns)


def _get_iem_live(station: StationInfo, model: str, horizon_h: int) -> "pd.DataFrame":
    pd = _require_pandas()

    url = _iem_live_url(station, model, horizon_h)
    with httpx.Client(timeout=_IEM_TIMEOUT) as client:
        resp = client.get(url)
        resp.raise_for_status()
        raw_records = resp.json()

    if not isinstance(raw_records, list) or not raw_records:
        return _empty_frame(list(FORECAST_COLUMNS))

    # Parse records defensively — IEM has been observed returning malformed rows
    # in the past (missing `runtime`/`ftime`). Drop those rather than crashing
    # the entire live call; a warning would be preferred but the SDK has no
    # logger configured at this level yet.
    records: list[dict[str, Any]] = []
    for raw in raw_records:
        try:
            records.append(_parse_iem_record(raw, station.code))
        except (KeyError, ValueError, TypeError):
            continue

    # Server-side IEM filters by `model=`, but be defensive: drop any record
    # whose parsed model does not match what the caller asked for so an
    # upstream bug can't produce a mixed-model DataFrame. Case-insensitive
    # match because upstream capitalization can drift (Vu PR #33 R1).
    #
    # After match: canonicalize the stored model to the caller's value so
    # downstream consumers (e.g. ``df["model"].eq("NBS").all()``) don't get
    # whatever case IEM echoed back (Vu PR #33 R2 P2). If IEM ever drifts to
    # ``"nbs"``, we still return ``"NBS"`` in the DataFrame column.
    model_upper = model.upper()
    records = [
        {**r, "model": model}
        for r in records
        if (r.get("model") or "").upper() == model_upper
    ]

    # Latest run only: for live forecasts, the quant wants the most recent
    # issued_at. IEM commonly returns 00Z, 06Z, 12Z, 18Z runs in one response.
    issued_values = [r["issued_at"] for r in records if r.get("issued_at")]
    if not issued_values:
        return _empty_frame(list(FORECAST_COLUMNS))
    latest_issued = max(issued_values)
    records = [r for r in records if r.get("issued_at") == latest_issued]

    # Construct with the column list so missing keys become NaN and the
    # column order matches FORECAST_COLUMNS exactly (parity with the
    # pyarrow schema in _forecast_schema.py, which is built from the
    # same tuple).
    return pd.DataFrame(records, columns=list(FORECAST_COLUMNS))


def _get_open_meteo_live(
    station: StationInfo, model: str, horizon_h: int
) -> "pd.DataFrame":
    pd = _require_pandas()

    if horizon_h > OM_MAX_HORIZON_H:
        raise ValueError(
            f"horizon_h={horizon_h} exceeds Open-Meteo max "
            f"{OM_MAX_HORIZON_H}h ({OM_MAX_HORIZON_H // 24} days)."
        )
    forecast_days = max(1, (horizon_h + 23) // 24)
    params: dict[str, Any] = {
        "latitude": station.latitude,
        "longitude": station.longitude,
        "hourly": ",".join(HOURLY_VARIABLES),
        "models": model,
        "forecast_days": forecast_days,
        "timeformat": "unixtime",
        "timezone": "GMT",
    }

    with httpx.Client(timeout=_OM_TIMEOUT) as client:
        resp = client.get(LIVE_FORECAST_URL, params=params)
        resp.raise_for_status()
        data = resp.json()

    hourly: dict[str, list[Any]] = data.get("hourly", {}) or {}
    timestamps: list[int] = hourly.get("time", []) or []

    if not timestamps:
        return _empty_frame(list(FORECAST_SERIES_COLUMNS))

    records: list[dict[str, Any]] = []
    for idx, ts in enumerate(timestamps):
        record: dict[str, Any] = {
            "station_code": station.code,
            "model": model,
            "source": "open_meteo",
            "valid_at": _unix_to_rfc3339(ts),
            "ingested_at": None,
        }
        for om_var, schema_var in VARIABLE_MAP.items():
            values = hourly.get(om_var, []) or []
            record[schema_var] = values[idx] if idx < len(values) else None
        records.append(record)

    return pd.DataFrame(records, columns=list(FORECAST_SERIES_COLUMNS))


def get_forecast(
    station: str,
    *,
    model: str = "NBS",
    horizon_h: int = 72,
    source: str = "iem",
) -> "pd.DataFrame":
    """Fetch the latest live forecast for a station.

    Calls the upstream forecast source (IEM MOS or Open-Meteo) directly.
    Returns a DataFrame with columns matching the historical MostlyRight
    API response (column parity — see architecture/dataset-pattern.md).

    Args:
        station: 3-letter NWS code ("NYC") or 4-letter ICAO ("KNYC").
        model: Forecast model. IEM: "NBS", "NBE", or "GFS". Open-Meteo:
            "gfs_seamless", "ncep_hrrr_conus", etc.
        horizon_h: Forecast horizon in hours. Default 72.
        source: "iem" (default) or "open_meteo".

    Returns:
        pandas.DataFrame with FORECAST_SCHEMA columns (source="iem") or
        FORECAST_SERIES_SCHEMA columns (source="open_meteo").

    Raises:
        ValueError: Unknown station or unknown source.
    """
    if source not in _VALID_SOURCES:
        raise ValueError(f"Unknown source {source!r}. Valid: {sorted(_VALID_SOURCES)}.")
    info = _station_or_raise(station)
    if source == "iem":
        if model not in _VALID_IEM_MODELS:
            raise ValueError(
                f"Unknown IEM model {model!r}. Valid: {sorted(_VALID_IEM_MODELS)}."
            )
        return _get_iem_live(info, model, horizon_h)
    if model not in _VALID_OM_MODELS:
        raise ValueError(
            f"Unknown Open-Meteo model {model!r}. Valid: {sorted(_VALID_OM_MODELS)}."
        )
    return _get_open_meteo_live(info, model, horizon_h)
