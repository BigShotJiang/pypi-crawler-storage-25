"""SDK preprocessing module — client-side data quality transforms.

These run AFTER data is fetched from the API or AWC. They do not mutate
the input, returning new copies with values clipped or flagged.
"""

from __future__ import annotations

from typing import Any

from mostlyright.qc.crosscheck import iem_crosscheck as _iem_crosscheck
from mostlyright.weather._bounds import (
    SLP_MAX_MB,
    SLP_MIN_MB,
    TEMP_MAX_C,
    TEMP_MIN_C,
    WIND_GUST_MAX,
    WIND_SPEED_MAX,
)

# Default thresholds for clip_outliers (field -> (min, max))
DEFAULT_THRESHOLDS: dict[str, tuple[float, float]] = {
    "temp_c": (TEMP_MIN_C, TEMP_MAX_C),
    "dewpoint_c": (TEMP_MIN_C, TEMP_MAX_C),
    "temp_f": (TEMP_MIN_C * 9 / 5 + 32, TEMP_MAX_C * 9 / 5 + 32),
    "dewpoint_f": (TEMP_MIN_C * 9 / 5 + 32, TEMP_MAX_C * 9 / 5 + 32),
    "wind_speed_kt": (0, WIND_SPEED_MAX),
    "wind_gust_kt": (0, WIND_GUST_MAX),
    "sea_level_pressure_mb": (SLP_MIN_MB, SLP_MAX_MB),
    "visibility_miles": (0.0, 99.99),
    "altimeter_inhg": (25.0, 32.5),
}


def clip_outliers(
    observations: list[dict[str, Any]],
    thresholds: dict[str, tuple[float, float]] | None = None,
) -> list[dict[str, Any]]:
    """Null out-of-bounds values in observations.

    Returns new list of new dicts. Does NOT mutate input.

    Args:
        observations: List of observation dicts.
        thresholds: Override thresholds. Keys are field names, values are (min, max).
    """
    bounds = thresholds if thresholds is not None else DEFAULT_THRESHOLDS
    result: list[dict[str, Any]] = []

    for obs in observations:
        clipped = dict(obs)
        for field, (lo, hi) in bounds.items():
            val = clipped.get(field)
            if val is not None and not (lo <= val <= hi):
                clipped[field] = None
        result.append(clipped)

    return result


def iem_crosscheck(
    ghcnh_obs: dict[str, Any] | None,
    iem_obs: dict[str, Any] | None,
) -> list[str]:
    """Compare a GHCNh observation against IEM for QC.

    Wraps qc/crosscheck.py for SDK users.
    Returns list of flags. Empty = data agrees. Non-empty = investigate.
    """
    return _iem_crosscheck(ghcnh_obs, iem_obs)


def describe() -> str:
    """Document what preprocessing functions are available and what they do."""
    return """MostlyRight Preprocessing Module
================================

clip_outliers(observations, thresholds=DEFAULT_THRESHOLDS)
    Null out-of-bounds sensor values in observation dicts.
    Uses physics-based thresholds from observation.json schema:
    - temp_c: [-90, 60] (world records: -89.2 C / 56.7 C)
    - wind_speed_kt: [0, 200]
    - sea_level_pressure_mb: [870, 1084]
    - visibility_miles: [0, 99.99]
    Returns new list (immutable, does not mutate input).

iem_crosscheck(ghcnh_obs, iem_obs)
    Compare a GHCNh observation against IEM for data quality.
    IEM applies QC filtering that catches sensor errors (500kt wind, 180 F).
    Returns list of flags:
    - Empty list: data agrees across sources
    - Non-empty: investigate (temp divergence >2C, wind >5kt, SLP >3mb)

describe()
    This function. Returns documentation string.
"""
