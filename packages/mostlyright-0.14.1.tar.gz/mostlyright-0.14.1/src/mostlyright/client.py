"""MostlyRightClient facade — convenience class composing WeatherHistory.

Method signatures identical to therminal-py. The migration is:
    from therminal import TherminalClient
    -->
    from mostlyright import MostlyRightClient  # or TherminalClient (compat alias)

Market methods raise NotImplementedError until Sprint 3 (Kalshi).
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, AsyncGenerator, cast

from mostlyright._http import HttpSession
from mostlyright.catalog import describe as _describe_fn
from mostlyright.catalog import feature_catalog as _feature_catalog_fn
from mostlyright.config import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, TherminalConfig
from mostlyright.models.station import StationInfo, _STATION_REGISTRY
from mostlyright.snapshot import DataSnapshot, build_snapshot
from mostlyright.versioning import DataVersion
from mostlyright.weather.client import WeatherHistory
from mostlyright.weather.forecasts import ForecastHistory

if TYPE_CHECKING:
    from mostlyright.models.availability import DataAvailability
    from mostlyright.models.observation import Observation

_NOT_IMPL_MSG = "Market methods available in v1.0. See Sprint 3."


class MostlyRightClient:
    """Convenience facade composing WeatherHistory + AI-native SDK extensions.

    Args:
        base_url: API base URL. Defaults to https://api.mostlyright.md
        timeout: Request timeout in seconds. Defaults to 30.
        config: SDK configuration. Overrides base_url/timeout if provided.
    """

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        config: TherminalConfig | None = None,
    ) -> None:
        self._config = config or TherminalConfig(base_url=base_url, timeout=timeout)
        self._http = HttpSession(self._config)
        self._weather = WeatherHistory(config=self._config, _session=self._http)
        self._forecasts = ForecastHistory(config=self._config, _session=self._http)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> MostlyRightClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # -- Health -------------------------------------------------------

    def health(self) -> dict[str, Any]:
        """Check API health status."""
        return self._http.get("/health")

    # -- Weather delegates --------------------------------------------

    def observations(
        self,
        station: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        *,
        as_of: str | None = None,
        obs_type: str | None = None,
        resolution: str | None = None,
        units: str | None = None,
        tz: str | None = None,
        format: str | None = None,
        columns: list[str] | None = None,
        features: list[str] | None = None,
        limit: int = 1000,
        offset: int = 0,
        as_dataframe: bool = False,
        save_path: str | Path | None = None,
    ) -> Any:
        """Get weather observations with optional temporal transform DSL.

        Args:
            station: Station code (e.g. "NYC", "ATL").
            from_date: Start date (YYYY-MM-DD).
            to_date: End date (YYYY-MM-DD).
            as_of: UTC timestamp (ISO 8601). When provided, results are filtered
                to observed_at <= as_of. Use this for point-in-time correctness
                in inference loops. Example: "2026-04-12T14:00:00Z".
                If provided without to_date, today's date is used as the API
                partition bound and as_of is applied as a post-filter.
                Note: comparison is done via datetime objects (not raw strings)
                so timezone suffixes other than Z are handled correctly.
            obs_type: Filter by observation type ("METAR" or "SPECI").
            resolution: Temporal resolution.
            units: Unit system (raw/metric/imperial).
            tz: Timezone for output timestamps.
            format: Output format. "toon" returns TOON v3.0 string.
            columns: Subset of columns to return.
            features: Temporal transform DSL specs, e.g.
                ["temp_f.lag(24h)", "hour_sin", "temp_f.rolling_mean(6h)"].
                Applied client-side after fetching. Returns DataFrame when set.
            limit: Max records. Default 1000.
            offset: Pagination offset.
            as_dataframe: Return pandas DataFrame if True.
            save_path: Save results to parquet file.

        Returns:
            List of dicts, DataFrame (if as_dataframe=True or features set),
            or TOON string (if format="toon").

        Raises:
            ValueError: If both format and as_dataframe are set.
        """
        if format is not None and as_dataframe:
            raise ValueError(
                "format and as_dataframe are mutually exclusive. "
                "Use format='toon' for TOON string output, "
                "or as_dataframe=True for a pandas DataFrame."
            )

        # Derive date bounds from as_of when not explicitly given.
        # Parse as_of to UTC first so offset timestamps (e.g. +14:00)
        # derive correct dates even when the UTC day differs.
        if as_of and (not from_date or not to_date):
            from mostlyright.snapshot import _parse_as_of as _p  # noqa: PLC0415

            _as_of_utc = _p(as_of)
            _as_of_date = _as_of_utc.strftime("%Y-%m-%d")
            _as_of_year = _as_of_utc.strftime("%Y")
        else:
            _as_of_date = None
            _as_of_year = None
        effective_to_date = to_date or (_as_of_date if as_of else None)
        effective_from_date = from_date or (f"{_as_of_year}-01-01" if as_of else None)

        # Don't pass format="toon" to WeatherHistory — it doesn't support it.
        # We handle TOON encoding at this level after fetching.
        wh_fmt = format if format != "toon" else None

        result = self._weather.observations(
            station=station,
            from_date=effective_from_date,
            to_date=effective_to_date,
            obs_type=obs_type,
            resolution=resolution,
            units=units,
            tz=tz,
            fmt=wh_fmt,
            columns=columns,
            limit=limit,
            offset=offset,
            as_dataframe=as_dataframe or bool(features),
            save_path=save_path,
        )

        # WeatherHistory.observations() has a Union return type
        # (list | Path | DataFrame). Narrow via isinstance below so the
        # type checker follows the branches.
        result: Any = result  # explicit: intentional Any to let isinstance narrow

        # as_of post-filter: use datetime comparison (not string) to handle tz suffixes
        if as_of:
            from mostlyright.snapshot import _parse_as_of  # noqa: PLC0415

            as_of_dt = _parse_as_of(as_of)
            as_of_normalized = as_of_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
            if isinstance(result, list):
                result = [
                    r for r in result if r.get("observed_at", "") <= as_of_normalized
                ]
            elif hasattr(result, "loc"):  # DataFrame
                # observed_at may be a column or the index depending on
                # the WeatherHistory return path
                df_result: Any = result  # narrow locally for the DataFrame branch
                if "observed_at" in df_result.columns:
                    result = df_result[df_result["observed_at"] <= as_of_normalized]
                elif df_result.index.name == "observed_at":
                    result = df_result[df_result.index <= as_of_normalized]

        if features:
            import pandas as pd  # noqa: PLC0415
            from mostlyright.transforms import apply_features  # noqa: PLC0415

            if isinstance(result, list):
                result = pd.DataFrame(result)
            result = apply_features(
                cast("pd.DataFrame", result),
                features=features,
                time_col="observed_at",
            )

        # TOON encoding for observations (not supported by WeatherHistory)
        if format == "toon":
            from mostlyright._toon import encode_tabular  # noqa: PLC0415

            if isinstance(result, list):
                # Convert Observation objects to dicts if needed.
                # ``encode_tabular`` wants ``list[dict[str, Any]]``; the explicit
                # dict-building below guarantees each row is such a mapping.
                rows: list[dict[str, Any]] = []
                for r in result:
                    if isinstance(r, dict):
                        rows.append(cast("dict[str, Any]", r))
                    elif hasattr(r, "to_dict"):
                        rows.append(r.to_dict())
                    else:
                        rows.append(dict(r))
                return encode_tabular(rows, name="observations")
            if hasattr(result, "to_dict"):  # DataFrame
                df_any: Any = result
                return encode_tabular(
                    df_any.reset_index().to_dict("records"), name="observations"
                )

        return result

    def climate(
        self,
        station: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        units: str | None = None,
        format: str | None = None,
        columns: list[str] | None = None,
        limit: int = 1000,
        offset: int = 0,
        as_dataframe: bool = False,
        save_path: str | Path | None = None,
    ) -> Any:
        """Get daily climate reports. Delegates to WeatherHistory.

        Raises:
            ValueError: If both format and as_dataframe are set.
        """
        if format is not None and as_dataframe:
            raise ValueError(
                "format and as_dataframe are mutually exclusive. "
                "Use format='toon' for TOON string output, "
                "or as_dataframe=True for a pandas DataFrame."
            )
        # Don't pass format="toon" to WeatherHistory — handle at this level
        wh_fmt = format if format != "toon" else None
        result = self._weather.climate(
            station=station,
            from_date=from_date,
            to_date=to_date,
            units=units,
            fmt=wh_fmt,
            columns=columns,
            limit=limit,
            offset=offset,
            as_dataframe=as_dataframe,
            save_path=save_path,
        )
        if format == "toon" and isinstance(result, list):
            from mostlyright._toon import encode_tabular  # noqa: PLC0415

            return encode_tabular(result, name="climate")
        return result

    def climate_gaps(
        self,
        station: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        as_dataframe: bool = False,
    ) -> Any:
        """Find gaps in climate history. Delegates to WeatherHistory."""
        return self._weather.climate_gaps(
            station=station,
            from_date=from_date,
            to_date=to_date,
            as_dataframe=as_dataframe,
        )

    # -- Forecast delegates -------------------------------------------

    def forecasts(
        self,
        station: str,
        from_date: str | None = None,
        to_date: str | None = None,
        model: str | None = None,
        *,
        format: str | None = None,
        columns: list[str] | None = None,
        as_dataframe: bool = False,
        save_path: str | Path | None = None,
    ) -> Any:
        """Historical IEM MOS forecasts from the API.

        Paired with ``mostlyright.live.get_forecast(source="iem")`` — both
        return columns matching FORECAST_SCHEMA (column parity contract).

        Args:
            station: Station code (e.g. "NYC").
            from_date: Start date (YYYY-MM-DD). Default: last 30 days.
            to_date: End date (YYYY-MM-DD).
            model: IEM MOS model filter ("NBS", "NBE", "GFS").
            format: Output format. "toon" returns a TOON string.
            columns: Subset of columns to return.
            as_dataframe: Return pandas DataFrame. Default False (matches
                observations/climate convention — opt into DataFrame when
                training).
            save_path: If set, download parquet bytes to this path.

        Raises:
            ValueError: If both format and as_dataframe=True.
        """
        if format is not None and as_dataframe:
            raise ValueError(
                "format and as_dataframe are mutually exclusive. "
                "Use format='toon' for TOON string output, "
                "or as_dataframe=True for a pandas DataFrame."
            )
        return self._forecasts.forecasts(
            station=station,
            from_date=from_date,
            to_date=to_date,
            model=model,
            fmt=format,
            columns=columns,
            as_dataframe=as_dataframe,
            save_path=save_path,
        )

    def forecast_series(
        self,
        station: str,
        from_date: str | None = None,
        to_date: str | None = None,
        model: str | None = None,
        *,
        format: str | None = None,
        columns: list[str] | None = None,
        as_dataframe: bool = False,
        save_path: str | Path | None = None,
    ) -> Any:
        """Historical Open-Meteo forecast series from the API.

        Paired with ``mostlyright.live.get_forecast(source="open_meteo")``.

        Args:
            station: Station code.
            from_date: Start date.
            to_date: End date.
            model: Open-Meteo model ("gfs_seamless", "ncep_hrrr_conus", etc).
            format: "toon" for compact text.
            columns: Subset of columns.
            as_dataframe: Return pandas DataFrame. Default False.
            save_path: Where to save downloaded parquet bytes.

        Raises:
            ValueError: If both format and as_dataframe=True.
        """
        if format is not None and as_dataframe:
            raise ValueError(
                "format and as_dataframe are mutually exclusive. "
                "Use format='toon' for TOON string output, "
                "or as_dataframe=True for a pandas DataFrame."
            )
        return self._forecasts.forecast_series(
            station=station,
            from_date=from_date,
            to_date=to_date,
            model=model,
            fmt=format,
            columns=columns,
            as_dataframe=as_dataframe,
            save_path=save_path,
        )

    # -- AI-native SDK extensions -------------------------------------

    def data_version(
        self,
        station: str,
        as_of: str,
        from_date: str | None = None,
        to_date: str | None = None,
    ) -> DataVersion:
        """Return a reproducible version token for the dataset at a point in time.

        Args:
            station: Normalized station code (e.g. "NYC").
            as_of: Query watermark (UTC ISO 8601). Stored as metadata, not hashed.
            from_date: Optional start date for observations window.
            to_date: Optional end date for observations window.

        Returns:
            DataVersion with a deterministic token based on station + observations.
        """
        # Use as_of[:10] as to_date bound if not explicitly given, and
        # filter to observed_at <= as_of for point-in-time correctness.
        effective_to_date = to_date or as_of[:10]
        # Paginate to avoid truncation at the default limit=1000
        _PAGE_SIZE = 5000
        obs: list[dict] = []
        _offset = 0
        while True:
            # No fmt / save_path / as_dataframe: WeatherHistory.observations
            # returns list[dict] here, but its Union return type confuses the
            # type checker — cast once.
            page = cast(
                "list[dict[str, Any]]",
                self._weather.observations(
                    station=station,
                    from_date=from_date,
                    to_date=effective_to_date,
                    limit=_PAGE_SIZE,
                    offset=_offset,
                ),
            )
            obs.extend(page)
            if len(page) < _PAGE_SIZE:
                break
            _offset += _PAGE_SIZE
        # Point-in-time filter: exclude observations after as_of
        from mostlyright.snapshot import _parse_as_of  # noqa: PLC0415

        as_of_dt = _parse_as_of(as_of)
        as_of_normalized = as_of_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        obs = [r for r in obs if r.get("observed_at", "") <= as_of_normalized]
        timestamps = [r["observed_at"] for r in obs if "observed_at" in r]
        # Use the normalized station code so KNYC and NYC produce identical tokens
        from mostlyright.snapshot import _station_code_normalized as _norm  # noqa: PLC0415

        return DataVersion.from_timestamps(
            station=_norm(station),
            as_of=as_of,
            observation_timestamps=timestamps,
        )

    def snapshot(
        self,
        station: str,
        as_of: str,
        *,
        cli_publication_delay_hours: float = 10.0,
        include_forecast: bool = False,
        tz_override: str | None = None,
        format: str | None = None,
    ) -> DataSnapshot | str:
        """Return everything an AI agent would have known at UTC moment as_of.

        Filters observations to [window_start_utc, as_of] (both bounds).
        Climate is withheld until cli_publication_delay_hours after midnight LST.

        Args:
            station: Station code (e.g. "NYC", "KATL").
            as_of: UTC query timestamp (ISO 8601 string).
            cli_publication_delay_hours: Hours after midnight LST until CLI
                is assumed published. Default 10 (10 AM local standard time).
            include_forecast: Include forecast data if available. Default False.
                (Requires sprint2/forecast-backfill to be merged.)
            tz_override: IANA timezone name for unknown stations.
            format: Output format. "toon" returns a TOON v3.0 encoded string
                instead of a DataSnapshot object. Useful for context injection
                where token budget matters. Default None (return DataSnapshot).

        Returns:
            DataSnapshot with observations, climate, forecasts (stub), and
            a DataVersion token. Or a TOON string if format="toon".

        Raises:
            ValueError: If station timezone is unknown and tz_override not given.
        """
        from mostlyright.snapshot import (  # noqa: PLC0415
            _station_code_normalized,
            settlement_date_for,
            settlement_window_utc,
        )
        from mostlyright.models.observation import Observation  # noqa: PLC0415

        code = _station_code_normalized(station)
        settlement_date = settlement_date_for(as_of, code, tz_override=tz_override)
        win_start, win_end = settlement_window_utc(
            settlement_date, code, tz_override=tz_override
        )

        # Fetch all observations for the window (API pre-filters by date)
        win_start_date = win_start.strftime("%Y-%m-%d")
        win_end_date = win_end.strftime("%Y-%m-%d")
        raw_obs = cast(
            "list[dict[str, Any]]",
            self._weather.observations(
                station=code,
                from_date=win_start_date,
                to_date=win_end_date,
                limit=500,
            ),
        )
        observations = [Observation.from_dict(r) for r in raw_obs]

        # Fetch climate for the settlement date
        raw_climate = cast(
            "list[dict[str, Any]]",
            self._weather.climate(
                station=code,
                from_date=settlement_date,
                to_date=settlement_date,
            ),
        )

        snap = build_snapshot(
            station=code,
            as_of=as_of,
            observations=observations,
            all_climate=raw_climate,
            cli_publication_delay_hours=cli_publication_delay_hours,
            tz_override=tz_override,
        )
        if format == "toon":
            return snap.to_toon()
        return snap

    def pairs(
        self,
        station: str,
        from_date: str,
        to_date: str,
        *,
        include_forecast: bool = False,
        forecast_model: str | None = None,
        as_dataframe: bool = False,
        format: str | None = None,
        tz_override: str | None = None,
    ) -> Any:
        """Return one row per settlement date joining observations + climate + forecast.

        Primary training surface for Kalshi settlement models.
        Key output columns: cli_high_f, cli_low_f, obs_high_f, obs_low_f,
        fcst_high_f, fcst_low_f, fcst_model, fcst_pop_6hr_pct,
        fcst_issued_at, fcst_qpf_6hr_in.

        All fcst_* keys are always present in every row. They are None when
        forecast data is unavailable.

        Args:
            station: Station code (e.g. "NYC").
            from_date: Start date (YYYY-MM-DD).
            to_date: End date (YYYY-MM-DD).
            include_forecast: Join forecast data if available. Default False.
                When True, fetches both /forecasts (IEM MOS) and
                /forecast_series (Open-Meteo) for the range, groups by
                settlement date, and passes both to build_pairs(). IEM MOS
                is preferred when both are available for the same date;
                Open-Meteo is used as the fallback.
            forecast_model: Filter to a specific IEM MOS forecast model.
                Accepted values: "NBS", "NBE", "GFS".
                None (default) = best available (latest issued_at run).
                Raises ValueError if model name is not recognized.

                Note: this parameter filters IEM MOS records only. Open-Meteo
                series are fetched separately and used as the fallback when
                IEM MOS returns no rows for a settlement window.
            as_dataframe: Return pandas DataFrame indexed by date.
            format: "toon" returns TOON v3.0 tabular string.
            tz_override: IANA timezone name override for stations not in the
                known timezone map (e.g. "America/Chicago"). Matches
                snapshot()'s tz_override parameter.

        Returns:
            List of row dicts, pandas DataFrame (if as_dataframe=True),
            or TOON string (if format="toon").

        Raises:
            ValueError: If both format and as_dataframe are set, or if
                forecast_model is not a recognized value.
        """
        if format is not None and as_dataframe:
            raise ValueError(
                "format and as_dataframe are mutually exclusive. "
                "Use format='toon' for TOON string output, "
                "or as_dataframe=True for a pandas DataFrame."
            )

        _VALID_FORECAST_MODELS = frozenset({"NBS", "NBE", "GFS"})
        if forecast_model is not None:
            forecast_model = forecast_model.upper()
        if forecast_model is not None and forecast_model not in _VALID_FORECAST_MODELS:
            raise ValueError(
                f"Unknown forecast_model {forecast_model!r}. "
                f"Accepted values: {sorted(_VALID_FORECAST_MODELS)}."
            )

        from mostlyright.pairs import (  # noqa: PLC0415
            build_pairs,
            date_range,
            pairs_to_dataframe,
            pairs_to_toon,
        )
        from mostlyright.snapshot import settlement_date_for  # noqa: PLC0415

        code = station.strip().upper()
        if len(code) == 4 and code.startswith("K"):
            code = code[1:]

        dates = date_range(from_date, to_date)

        # Fetch all observations for the range. Extend to_date by 1 day
        # to capture post-midnight-UTC observations for stations west of
        # UTC (e.g. NYC settlement window extends to next-day 04:59Z).
        # Paginate to avoid silent truncation on long ranges.
        from datetime import date as _date_cls  # noqa: PLC0415
        from datetime import timedelta  # noqa: PLC0415

        extended_to = (_date_cls.fromisoformat(to_date) + timedelta(days=1)).isoformat()
        _PAGE_SIZE = 5000
        raw_obs: list[dict[str, Any]] = []
        offset = 0
        while True:
            page = cast(
                "list[dict[str, Any]]",
                self._weather.observations(
                    station=code,
                    from_date=from_date,
                    to_date=extended_to,
                    limit=_PAGE_SIZE,
                    offset=offset,
                ),
            )
            raw_obs.extend(page)
            if len(page) < _PAGE_SIZE:
                break
            offset += _PAGE_SIZE
        # Group observations by settlement date (LST-aware, not UTC date slice)
        obs_by_date: dict[str, list[dict[str, Any]]] = {d: [] for d in dates}
        for r in raw_obs:
            observed_at = r.get("observed_at", "")
            if not observed_at:
                continue
            obs_date = settlement_date_for(observed_at, code)
            if obs_date in obs_by_date:
                obs_by_date[obs_date].append(r)

        # Fetch climate for the range
        raw_climate = cast(
            "list[dict[str, Any]]",
            self._weather.climate(
                station=code,
                from_date=from_date,
                to_date=to_date,
            ),
        )
        climate_by_date: dict[str, dict[str, Any] | None] = {}
        for r in raw_climate:
            obs_date = r.get("observation_date", "")
            if obs_date:
                climate_by_date[obs_date] = r

        # Forecast: wired in Sprint 2h-s3. Fetch IEM MOS (/forecasts) AND
        # Open-Meteo (/forecast_series) so build_pairs() can choose the
        # preferred source per settlement date — IEM wins when both have
        # data, Open-Meteo is the fallback. Records are distinguished by
        # whether they carry an ``issued_at`` field.
        forecasts_by_date: dict[str, list[dict[str, Any]] | None] | None = None
        if include_forecast:
            import logging  # noqa: PLC0415

            from mostlyright.exceptions import (  # noqa: PLC0415
                RateLimitError,
                ServerError,
            )

            _log = logging.getLogger(__name__)
            # Narrow on purpose: only transient network / server-side failures
            # are "optional" here. Auth/validation/404 errors subclass
            # TherminalError but indicate caller misconfiguration — those
            # should surface, not silently degrade fcst_* to None.
            _TRANSIENT_EXC: tuple[type[BaseException], ...] = (
                RateLimitError,
                ServerError,
                OSError,
            )
            raw_forecasts: list[dict[str, Any]] = []
            try:
                raw_forecasts.extend(
                    self._forecasts.forecasts(
                        station=code,
                        from_date=from_date,
                        to_date=extended_to,
                        model=forecast_model,
                        as_dataframe=False,
                    )
                )
            except _TRANSIENT_EXC as exc:
                _log.warning(
                    "pairs(): /forecasts fetch failed for %s (%s); "
                    "fcst_* will fall back to Open-Meteo if available",
                    code,
                    exc.__class__.__name__,
                )
            # Open-Meteo: fallback source (no issued_at). Always fetched when
            # include_forecast=True so build_pairs_row can use it whenever
            # IEM MOS yields no window records.
            try:
                raw_forecasts.extend(
                    self._forecasts.forecast_series(
                        station=code,
                        from_date=from_date,
                        to_date=extended_to,
                        as_dataframe=False,
                    )
                )
            except _TRANSIENT_EXC as exc:
                _log.warning(
                    "pairs(): /forecast_series fetch failed for %s (%s)",
                    code,
                    exc.__class__.__name__,
                )

            grouped: dict[str, list[dict[str, Any]]] = {d: [] for d in dates}
            for r in raw_forecasts:
                valid_at = r.get("valid_at", "")
                if not valid_at:
                    continue
                settle = settlement_date_for(valid_at, code, tz_override=tz_override)
                if settle in grouped:
                    grouped[settle].append(r)
            forecasts_by_date = {d: grouped.get(d) or None for d in dates}

        rows = build_pairs(
            code,
            dates,
            obs_by_date,
            climate_by_date,
            forecasts_by_date,
            forecast_model=forecast_model,
            tz_override=tz_override,
        )

        if format == "toon":
            return pairs_to_toon(rows)
        if as_dataframe:
            return pairs_to_dataframe(rows)
        return rows

    def feature_catalog(
        self,
        *,
        include_transforms: bool = True,
        source_filter: str | None = None,
        format: str | None = None,
    ) -> list[dict] | str:
        """Return all available features with descriptions and metadata.

        Args:
            include_transforms: Include derived transform features. Default True.
            source_filter: Filter to one source ("observation", "climate",
                "forecast_iem", "forecast_openmeteo", "satellite", "pairs",
                "market", "computed", "transform").
            format: Output format. "toon" returns a TOON tabular string
                (~60% fewer tokens than JSON). None (default) returns
                list of dicts (JSON-serializable).

        Returns:
            List of dicts (default or format="json"), or TOON string (format="toon").
        """
        entries = _feature_catalog_fn(
            include_transforms=include_transforms,
            source_filter=source_filter,
        )
        if format == "toon":
            from mostlyright._toon import encode_tabular  # noqa: PLC0415

            # Flatten list fields (available_transforms) to semicolon-joined strings
            # so encode_tabular gets uniform primitive-value rows.
            flat_rows = [
                {
                    k: (";".join(v) if isinstance(v, list) else v)
                    for k, v in e.to_dict().items()
                }
                for e in entries
            ]
            return encode_tabular(flat_rows, name="feature_catalog")
        return [e.to_dict() for e in entries]

    def describe(self, station: str) -> str:
        """Return an LLM-ready summary of available features for a station.

        Generated from live feature_catalog(). Not a static string.

        Args:
            station: Station code (e.g. "NYC"). Used for context in the output.

        Returns:
            Multi-line string suitable for LLM system prompt inclusion.
        """
        return _describe_fn(station)

    async def stream(
        self,
        station: str,
        *,
        interval: float = 60.0,
        max_obs: int | None = None,
        units: str | None = None,
        timeout: float | None = None,
    ) -> AsyncGenerator["Observation", None]:
        """Async generator yielding new METAR observations from AWC.

        Polls AWC at `interval` seconds. Only new observations (by observed_at)
        are yielded. Permanent errors (401/403/404) are re-raised immediately.
        Transient errors (5xx, network) trigger a retry after `interval` seconds.

        Args:
            station: Station code (e.g. "NYC", "ATL").
            interval: Poll interval in seconds. Default 60.
            max_obs: Stop after this many observations. None = unlimited.
            units: Unit system (raw/metric/imperial). Default raw.
            timeout: Stop streaming after this many seconds. None = unlimited.
                Returns normally when timeout elapses (does not raise).
                Useful for bounded agent inference loops.

        Yields:
            Observation objects for each new METAR.

        Raises:
            AuthenticationError: 401 — invalid API credentials.
            ForbiddenError: 403 — access denied.
            NotFoundError: 404 — station not found.
        """
        from mostlyright.stream import stream_observations  # noqa: PLC0415

        async for obs in stream_observations(
            station,
            config=self._config,
            interval=interval,
            max_obs=max_obs,
            units=units,
            timeout=timeout,
        ):
            yield obs

    # -- Data availability --------------------------------------------

    def availability(
        self,
        station: str,
        *,
        as_of: str | None = None,
        data_type: str = "all",
    ) -> "DataAvailability":
        """Return actual data availability for a station.

        Queries the API to determine what date ranges have data. Call this
        before building training loops to avoid empty-result queries.

        Requires the REST API to be running — there is no local fallback.

        Args:
            station: Station code (e.g. "NYC", "KATL").
            as_of: If provided, compute freshness_hours relative to this UTC
                timestamp. Default: current UTC time.
            data_type: Filter to one data type. One of:
                "all" (default), "observations", "climate", "forecast".

        Returns:
            DataAvailability with earliest/latest/count per data type.

        Example::
            avail = client.availability("NYC")
            print(avail.observations.earliest)  # "2018-06-15"
            print(avail.observations.freshness_hours)  # 1.3
        """
        from mostlyright.snapshot import _station_code_normalized  # noqa: PLC0415
        from mostlyright.models.availability import DataAvailability, RangeInfo  # noqa: PLC0415

        code = _station_code_normalized(station)
        params: dict[str, str] = {}
        if as_of:
            params["as_of"] = as_of
        if data_type != "all":
            params["data_type"] = data_type

        from urllib.parse import urlencode  # noqa: PLC0415

        path = f"/availability/{code}"
        if params:
            path = f"{path}?{urlencode(params)}"

        raw = self._http.get(path)

        def _range(d: dict[str, Any] | None) -> RangeInfo:
            if d is None:
                return RangeInfo(
                    earliest=None, latest=None, count=None, freshness_hours=None
                )
            return RangeInfo(
                earliest=d.get("earliest"),
                latest=d.get("latest"),
                count=d.get("count"),
                freshness_hours=d.get("freshness_hours"),
            )

        forecast_raw = raw.get("forecast")
        return DataAvailability(
            station=raw.get("station", code),
            as_of=raw.get("as_of", ""),
            observations=_range(raw.get("observations")),
            climate=_range(raw.get("climate")),
            forecast=_range(forecast_raw) if forecast_raw is not None else None,
        )

    # -- Station registry ---------------------------------------------

    def stations(self) -> list[StationInfo]:
        """Return all stations with active Kalshi markets and SDK support.

        Returns:
            List of StationInfo objects sorted by station code.
        """
        return sorted(_STATION_REGISTRY.values(), key=lambda s: s.code)

    def station(self, code: str) -> StationInfo:
        """Return metadata for a single station by code.

        Accepts 3-letter NWS code ("NYC") or 4-letter ICAO ("KNYC").

        Args:
            code: Station code, case-insensitive.

        Returns:
            StationInfo for the requested station.

        Raises:
            NotFoundError: If station code is not in the registry.
        """
        from mostlyright.snapshot import _station_code_normalized  # noqa: PLC0415
        from mostlyright.exceptions import NotFoundError  # noqa: PLC0415

        normalized = _station_code_normalized(code)
        info = _STATION_REGISTRY.get(normalized)
        if info is None:
            raise NotFoundError(
                f"Station {code!r} not in registry. Call stations() to list valid codes."
            )
        return info

    # -- Capabilities + schema ----------------------------------------

    def capabilities(self) -> dict:
        """Return a structured summary of all SDK methods and their parameters.

        Returns:
            Dict with keys:
              "version": SDK version from importlib.metadata
              "methods": list of method summary dicts (name, description, params)
              "stations": list of valid station codes
              "rate_limits": dict (null values until Sprint 2g implements limits)
              "data_types": list of supported data type names

        Usage::
            caps = client.capabilities()
            # f"Available methods: {[m['name'] for m in caps['methods']]}"
        """
        import importlib.metadata  # noqa: PLC0415
        from mostlyright._capabilities import _METHOD_INDEX  # noqa: PLC0415

        try:
            version = importlib.metadata.version("mostlyright")
        except importlib.metadata.PackageNotFoundError:
            version = "unknown"

        return {
            "version": version,
            "methods": list(_METHOD_INDEX),
            "stations": sorted(_STATION_REGISTRY.keys()),
            "rate_limits": {
                "requests_per_minute": None,
                "note": "Not yet enforced",
            },
            "data_types": [
                "observations",
                "climate",
                "forecasts",
                "forecast_series",
                "snapshot",
                "pairs",
                "feature_catalog",
            ],
        }

    def schema(self, entity: str) -> dict:
        """Return the JSON Schema for a data entity.

        Args:
            entity: Entity name. One of:
                "observation", "climate", "snapshot", "data_version",
                "forecast" (singular, the raw record schema),
                "forecast_series", "candle",
                "market", "market_unified", "synoptic_extremes", "omo",
                "brackets".

                Note: "pairs" is not supported. specs/settlement-join.json
                describes the observation-settlement join schema, not the
                pairs() output columns. A specs/pairs.json spec is deferred
                to Sprint 4. Until then, use
                feature_catalog(source_filter="pairs") to inspect pairs columns.

        Returns:
            JSON Schema dict (parsed from specs/*.json).

        Raises:
            ValueError: If entity name is not recognized.

        Usage::
            obs_schema = client.schema("observation")
            required = obs_schema["required"]  # list of required field names
        """
        from mostlyright._capabilities import load_schema  # noqa: PLC0415

        return load_schema(entity)

    # -- Tool schema export -------------------------------------------

    def as_tools(
        self,
        *,
        include_market: bool = False,
        include_experimental: bool = False,
    ) -> list[dict]:
        """Return Anthropic-compatible tool definitions for all callable SDK methods.

        Args:
            include_market: Include market methods. Default False (market methods
                raise NotImplementedError until Sprint 3 — including them risks
                agent confusion when calls fail).
            include_experimental: Include methods marked experimental. Default False.

        Returns:
            List of tool definition dicts in Anthropic tool-use format. Each dict
            has keys: "name", "description", "input_schema".

        Usage::
            import anthropic
            client = MostlyRightClient()
            tools = client.as_tools()
            response = anthropic.Anthropic().messages.create(
                model="claude-opus-4-6",
                tools=tools,
                messages=[{"role": "user", "content": "Get NYC observations for July 4"}],
            )
        """
        from mostlyright._tools import get_tool_definitions  # noqa: PLC0415

        return get_tool_definitions(
            include_market=include_market,
            include_experimental=include_experimental,
        )

    # -- Token estimation ---------------------------------------------

    def estimate_tokens(
        self,
        station: str,
        from_date: str,
        to_date: str,
        *,
        method: str = "observations",
        format: str = "toon",
        columns: list[str] | None = None,
    ) -> dict:
        """Estimate token count for a data query without fetching records.

        Args:
            station: Station code.
            from_date: Start date (YYYY-MM-DD).
            to_date: End date (YYYY-MM-DD).
            method: Data method to estimate. One of:
                "observations" (default), "climate", "pairs".
            format: Output format for the estimate. "toon" (default) or "json".
            columns: If provided, estimate based on column subset only.

        Returns:
            Dict with keys:
              "estimated_rows": int — approximate row count
              "estimated_tokens": int — approximate token count
              "format": str — format used for estimate
              "note": str | None — calibration status or caveats
              "suggested_limit": int | None — limit value to stay under 4096 tokens

        Example::
            est = client.estimate_tokens("NYC", "2020-01-01", "2024-12-31")
            if est["estimated_tokens"] > 4096:
                rows = client.observations("NYC", "2024-01-01", "2024-12-31",
                                           format="toon", limit=est["suggested_limit"])
        """
        from datetime import date as _date  # noqa: PLC0415

        _VALID_METHODS = frozenset(
            {"observations", "climate", "pairs", "forecasts", "forecast_series"}
        )
        if method not in _VALID_METHODS:
            raise ValueError(
                f"Unknown method {method!r}. One of: {sorted(_VALID_METHODS)}."
            )

        # Approximate tokens per record.
        # Calibrated against real NYC METAR data (2024) and pairs output.
        # TOON values measured from encode_tabular output / 4 (chars-to-tokens).
        # JSON values measured from json.dumps output / 4.
        # Forecast estimates: IEM MOS has ~38 fields per row, Open-Meteo ~26.
        _TOON_TOKENS_PER_ROW = {
            "observations": 8,  # 30-field METAR row in TOON: ~32 chars → ~8 tok
            "climate": 6,  # NWS CLI daily row: ~24 chars → ~6 tok
            "pairs": 6,  # pairs row (6 core cols): ~24 chars → ~6 tok
            "forecasts": 10,  # 38-field IEM MOS row in TOON: ~40 chars → ~10 tok
            "forecast_series": 7,  # 26-field Open-Meteo row in TOON: ~28 chars → ~7 tok
        }
        _JSON_TOKENS_PER_ROW = {
            "observations": 25,  # 30-field METAR row in JSON: ~100 chars → ~25 tok
            "climate": 18,  # NWS CLI daily row in JSON: ~72 chars → ~18 tok
            "pairs": 19,  # pairs row in JSON: ~76 chars → ~19 tok
            "forecasts": 32,  # 38-field IEM MOS row in JSON: ~128 chars → ~32 tok
            "forecast_series": 22,  # 26-field Open-Meteo row in JSON: ~88 chars → ~22 tok
        }

        days = (_date.fromisoformat(to_date) - _date.fromisoformat(from_date)).days + 1
        if method == "observations":
            estimated_rows = days * 24  # ~24 obs/day average for ASOS
        elif method == "forecasts":
            # IEM MOS: ~4 runs/day × ~18-hour horizon ≈ 72 rows/day after
            # stacking multiple issued_at runs in one date window.
            estimated_rows = days * 72
        elif method == "forecast_series":
            # Open-Meteo: seamless hourly = 24 rows/day (no overlapping runs).
            estimated_rows = days * 24
        else:
            estimated_rows = days

        tokens_per_row = (
            _TOON_TOKENS_PER_ROW[method]
            if format == "toon"
            else _JSON_TOKENS_PER_ROW[method]
        )
        estimated_tokens = estimated_rows * tokens_per_row
        suggested_limit = (
            max(1, int(4096 / tokens_per_row)) if estimated_tokens > 4096 else None
        )

        return {
            "estimated_rows": estimated_rows,
            "estimated_tokens": estimated_tokens,
            "format": format,
            "note": "Calibrated against NYC 2024 pairs/observation data.",
            "suggested_limit": suggested_limit,
        }

    # -- Market methods (NotImplemented until Sprint 3) ---------------

    def series(self, **kwargs: Any) -> Any:
        raise NotImplementedError(_NOT_IMPL_MSG)

    def series_detail(self, ticker: str) -> Any:
        raise NotImplementedError(_NOT_IMPL_MSG)

    def markets(self, **kwargs: Any) -> Any:
        raise NotImplementedError(_NOT_IMPL_MSG)

    def market(self, ticker: str) -> Any:
        raise NotImplementedError(_NOT_IMPL_MSG)

    def candles(self, **kwargs: Any) -> Any:
        raise NotImplementedError(_NOT_IMPL_MSG)

    def lob(self, **kwargs: Any) -> Any:
        raise NotImplementedError(_NOT_IMPL_MSG)


# Backward compat alias — drop-in migration from therminal-py
TherminalClient = MostlyRightClient
