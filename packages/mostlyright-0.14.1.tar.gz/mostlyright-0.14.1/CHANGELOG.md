# Changelog

All notable changes to this project will be documented in this file.

## [0.14.1] - 2026-04-22

### Fixed
- **`client.schema(entity)` was broken in the 0.14.0 wheel.** The `specs/*.json` files shipped in the sdist but not in the wheel, so every PyPI install raised `FileNotFoundError: '.../specs/observation.json'` on `client.schema()`. Caught by Vu in the post-publish codex review (PR #40). 0.14.0 will be yanked on PyPI after 0.14.1 is live.
- **Move `specs/` into the package** (`src/mostlyright/specs/`) so the wheel ships them automatically. `_capabilities.SPECS_DIR` now resolves via `Path(__file__).parent / "specs"` — works for both editable and wheel installs. Downstream consumers (`ingest.storage.forecast_parquet`, `validation/conftest.py`, `tests/conftest.py`, `tests/test_sdk_versioning.py`, `validation/tests/test_schema_event.py`) all switched to `from mostlyright._capabilities import SPECS_DIR`.

### Added
- **PEP 561 `py.typed` marker** at `src/mostlyright/py.typed`. The existing `Typing :: Typed` classifier was claiming type information that wasn't actually shipping; this makes the claim honest.
- **Regression tests** that build the actual wheel and inspect it:
  - `tests/test_packaging.py::TestWheelContents::test_specs_ship_in_wheel` — builds the wheel, asserts every JSON Schema referenced by `_SCHEMA_FILES` is inside.
  - `tests/test_packaging.py::TestWheelContents::test_pytyped_marker_ships_in_wheel` — ensures the marker ships too.
  - `tests/test_install_clean_venv.py::test_client_schema_loads_spec_in_wheel_install` (live) — installs the built wheel into a fresh venv and calls `client.schema()` for all 12 advertised entities. Reproduces Vu's exact failure mode before the fix.

### Changed
- `scripts/verify_pypi_install.sh` header documents exit codes 0/1/2 (was stale at "0 success / 1 failure").
- `pyproject.toml` sdist include list drops the now-redundant `specs/*.json` entry — files are covered by `src/mostlyright/**`.

## [0.14.0] - 2026-04-22

### Changed
- **SDK default `base_url` migrated to `https://api.mostlyright.md`** (was `api.mostlyright.xyz`). Part of the Sprint 2m domain migration. `config.py:DEFAULT_BASE_URL`, `client.py` docstring, `tests/test_sdk_config.py`, `docs/QUICKSTART.md`, `tests/test_sdk_forecast_smoke.py`, `tests/test_sdk_column_parity.py`, `tests/test_quant_workflow_local_e2e.py`, and `scripts/verify_pypi_install.sh` all updated. Historical roadmap docs intentionally keep the `.xyz` reference as a point-in-time record.

### Added
- **PyPI publish — `pip install mostlyright`** (Sprint 2l). First release on PyPI. SDK installs with ~2 top-level dependencies (`httpx`, `jsonschema`) instead of the 9 that the editable dev install pulled. Server-only and parquet-only deps moved into optional-dependencies groups.
- **`src/mostlyright/_forecast_columns.py`** — pure-python column-name tuples for the IEM MOS and Open-Meteo forecast schemas. `_forecast_schema.py` builds the pyarrow schemas from these tuples; `live/forecasts.py` imports the column list directly and no longer drags pyarrow into `from mostlyright import MostlyRightClient`. Single source of truth for field names and declared dtypes.
- **`pyproject.toml` extras split**: core install ships only the SDK runtime. `[parquet]` pulls pandas + pyarrow for DataFrame / parquet paths. `[server]` pulls boto3 + fastapi + uvicorn on top of parquet for the VM deploy. `[dev]` pulls `[server,parquet]` plus pytest / ruff / build / twine.
- **Full package metadata** for the PyPI landing page: `description`, `license = "MIT"`, authors, keywords, classifiers (3.11 + 3.12, explicitly not 3.10), urls (homepage / repo / issues / changelog / docs), and SPDX license-files.
- **`LICENSE`** — MIT.
- **SDK-facing `README.md`** — lead-in with install + 5-line quickstart, training + inference workflows, auth, 20-station list, error handling, schema pointers. Keeps under 200 lines; links to `docs/QUICKSTART.md` for the longer walkthrough.
- **`docs/QUICKSTART.md`** — deeper walkthrough of every data method with format options, settlement window conventions, token estimation, and the error hierarchy.
- **`scripts/verify_pypi_install.sh`** — Phase 2 E2E release gate. Creates a fresh venv, installs from TestPyPI (or real PyPI), runs the README quickstart, and exits 0 / 1. Kept as a shell script (not pytest) because it depends on remote PyPI state.
- **Packaging / install tests**: `tests/test_packaging.py` (23 structural checks — metadata, dep split, license, README shape, import boundary, ImportError hint text) plus three live test files (`test_install_clean_venv.py`, `test_install_server_extras.py`, `test_quant_workflow_local_e2e.py`) that prove the dep split holds in a real venv.

### Changed
- `_http.py` User-Agent version now derived from `importlib.metadata.version("mostlyright")` instead of a hard-coded `_VERSION = "0.9.0"` string that had drifted several releases out of date.
- `_http.py`, `transforms.py`, `pairs.py` ImportError hints when pandas is missing now point at `pip install mostlyright[parquet]` (matches the pyproject extras group) instead of the obsolete `[pandas]` form.
- `docs/AGENT.md` version header bumped from v0.12.0 to v0.14.0.

### Removed
- Module-level `import pyarrow` in `src/mostlyright/_forecast_schema.py`'s import graph from the SDK public path. The file itself still imports pyarrow (it's intentionally a server-only helper shipped in the wheel so ingest can import it), but core-SDK consumers reach only `_forecast_columns` now.

## [0.13.0] - 2026-04-16

### Added
- **R2-first read path for observations and climate** (Sprint 2j). `GET /observations` and `GET /climate` now read from Cloudflare R2 via the shared `r2_dataset` reader, matching the Profile B pattern already in use for forecasts. The VM is no longer the source of truth for served data — if the VM dies, data is safe.
- **Generalized `api/routes/_read_helpers.py`** — replaces the forecast-only `_forecast_helpers.py`. Handles all four entities (forecasts, forecast_series, observations, climate) with per-entity config (date field, supported formats, pagination, model/as_of/obs_type support, strip columns). Route files are now thin wrappers calling `read_and_format(entity=...)`.
- **`ingest/storage/obs_writer.py`** — mirrors `forecast_writer.py` for observations and climate. `write_through_observations` and `write_through_climate` stage records, merge into year partitions, upload to R2, and delete the local file only after a successful PUT. Cross-station year-scope protection prevents a NYC/2024 + ATL/2025 batch from sweeping a pre-existing ATL/2024 partition (Vu R5 P2 fix, mirrored from forecast_writer).
- **`READ_BACKEND=local` rollback toggle**. Setting the env var swaps the R2 read for the local-disk reader from `ingest.storage.parquet`. The toggle is resolved per call (not cached at import), so tests and a production rollback can flip it without restart. Local readers (`read_observations`, `read_climate`) are preserved as the safety net.
- **Per-cycle watermark advancement** reads max `observed_at` from staging BEFORE `write_through_observations` drains it. Sprint 2j deletes local year partitions post-upload, so the old path (reading the year file after merge) would return an empty result — this pre-drain read keeps IEM gap narrowing alive through the migration.
- **`/climate/gaps` DoS guard** — rejects windows beyond 10 years with HTTP 400 before hitting R2. Prevents an unbounded `YYYY-YYYY` range from driving day-by-day iteration into a CPU sink.
- **Live + SDK e2e tests**: `test_api_observations_live.py`, `test_api_climate_live.py`, `test_obs_writer_live.py`, `test_sdk_observations_e2e.py`, `test_sdk_climate_e2e.py`. Every new path has coverage against real R2 and through the full SDK stack.
- **Unit tests for coverage gaps caught in review**: CSV column order preservation for observations + climate, `/climate/gaps` DoS range rejection.

### Changed
- `api/routes/observations.py` and `api/routes/climate.py` collapsed into thin wrappers around `read_and_format`. `_make_observations_router(data_dir)` keeps its signature (data_dir is forwarded to the local-fallback path).
- `merge_scheduler.run_merge_cycle` now calls `write_through_observations` once per cycle. The per-station merge + upload loop is consolidated in `obs_writer`. Watermark advancement reads from staging before write-through.
- `climate_sync.sync_daily_climate` and `backfill_climate` switched to `write_through_climate`.
- `/climate/gaps` now reads from R2 via `read_dataset` (with local fallback when `READ_BACKEND=local`).
- Observations station-code handling is now case-insensitive (`_station_code_normalized` is applied before validation), matching forecasts. Old behavior rejected mixed-case codes like `Atl` with 404; new behavior resolves to the canonical uppercase form.
- CSV output for `/observations` and `/climate` now honors the caller's positional column order (SDK consumers parse by position) rather than re-sorting alphabetically.
- `_upload_and_cleanup` uses `safe_exc_message(exc)` rather than `exc_info=True`, preventing the R2 endpoint URL (which embeds the account id) from leaking into the systemd journal via the chained traceback on transient outages.

### Removed
- `api/routes/_forecast_helpers.py` — replaced by `_read_helpers.py`.
- Sprint 2g-s2 quiet-station self-heal upload path from `merge_scheduler` and `climate_sync`. Post-Sprint-2j the local year file is deleted after a successful upload, so "re-upload every cycle even when quiet" has nothing to upload.

### Tests
- 2180 passing (+70 vs 0.12.0: write-through, R2-backed routes, CSV order, DoS guard, live, SDK e2e).
- 24 obsolete Sprint 2g-s2 quiet-station self-heal tests marked `@_SPRINT_2J_OBSOLETE` with a migration note.

## [0.12.0] - 2026-04-14

### Added
- **R2 dataset reader** (`ingest/storage/r2_dataset.py`). Shared pyarrow S3FileSystem reader for all Profile B (R2-first) datasets. Returns `pa.Table` with column pushdown and year filtering. One connection pool (module-level singleton), one ListDir call per read (not N HEAD requests). Entity routing mirrors `r2.py::_key_for_entity`. Schema-aware empty tables prevent `KeyError` on empty results.
- **Dataset pattern convention** (`architecture/dataset-pattern.md`). Written convention for adding datasets to MostlyRight. Two profiles (A: local-first for observations/climate, B: R2-first for forecasts/forecast_series). Component table, column parity rule, write-through protocol, failure modes, naming conventions, and a 20-step checklist for new datasets.
- **Measurement test results** on production VM (34.11.124.46). R2 streaming: 2.41s for 547k rows / 133MB (threshold: <5s). Concurrent memory: 486MB peak RSS with 3 simultaneous pulls (threshold: <500MB). Both pass. R2-first pattern validated for forecasts.
- **28 unit tests** covering column pushdown, year filtering, entity routing, schema-aware empty tables, filter parameter, non-parquet file safety, env var parsing, and edge cases.
- **5 live tests** reading existing forecast data from R2, verifying schema and column set.
- **10 validation tests** ensuring `dataset-pattern.md` has all required sections and components.

### Fixed
- Race condition in `_get_filesystem()` double-checked locking: `_BUCKET` now assigned before `_FS` so threads never see `_FS != None` with `_BUCKET=""`.
- `years=None` path now enumerates `*.parquet` files explicitly instead of passing directory to `pa_ds.dataset()`, preventing `ArrowInvalid` crash on non-parquet files (`.tmp`, `.DS_Store`).
- Pre-existing test failure: `pytest.importorskip("pandas")` moved before the call that needs it in `test_sdk_stream.py`.

## [0.11.0] - 2026-04-07

### Added
- **Live R2 upload from the merger** (Sprint 2g-s2). The merger now mirrors every station's current-year observations parquet to R2 on every merge cycle (~15 min). The daily climate sync mirrors every station's climate parquet once per day. R2 becomes a real-time backup of VM disk for the current year. Data loss window on VM death drops from "until the next manual backfill" (effectively unbounded) to "one merge interval" for observations and "one day" for climate.
- **Quiet-station upload self-healing.** A station with no new staging data still re-uploads its existing year file every cycle. The uploads are gated only on the file existing on disk, not on whether merge_staging produced new rows. A station that's been silent since deploy stays in sync; a transient R2 5xx on cycle N is automatically corrected on cycle N+1.
- **AWS-standard R2 env var names** unified across the Python ingest code and the existing `deploy/r2sync.sh` shell timer. `R2Client.from_env()` reads `R2_ENDPOINT`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`, `R2_BUCKET` first. Legacy names (`R2_ACCOUNT_ID`, `R2_ACCESS_KEY`, `R2_SECRET_KEY`, `R2_BUCKET`) are still accepted as a fallback for one release with a deprecation WARNING. The `.env` on a production VM now needs only one set of R2 variables shared across the merger, climate daily sync, r2sync timer, and `backfill_all`.
- **Shared `init_r2_client()` helper** in `ingest/storage/r2.py` (logs at WARNING when env vars are missing so operators who silence INFO still see that R2 mirroring is off). Both `ingest/merger.py` and `ingest/climate.py` use it; no more duplicated try/except in CLI files.
- **Public `R2Uploader` Protocol** in `ingest/storage/r2.py`, replacing two duplicate private Protocols in `merge_scheduler.py` and `climate_sync.py`. Single source of truth for the upload contract.
- **`_safe_exc_message(exc)` helper** that strips `https?://...` substrings from exception messages before logging. Operators get the full S3 error code (`NoSuchKey`, `AccessDenied`) for ClientError without the Cloudflare account-id-bearing endpoint URL leaking from `EndpointConnectionError` / `SSLError` into the systemd journal on every transient outage.
- **Sprint 2g-s2 deploy sequence** documented in `deploy/README.md`: `deploy.sh` → `backfill_all --years $(date +%Y) --upload --no-resume` (closes the deploy-time gap immediately) → restart merger + climate timer → `aws s3 ls` verification → API smoke check. `--no-resume` is mandatory because relying on `backfill_progress.json` would silently skip stations whose progress entries are missing or partial.
- **39 new tests** across three files: 10 in `tests/test_r2_env_vars.py` (AWS-standard precedence, legacy fallback, deprecation warning, mixed-set conflict resolution, missing env vars), 5 in `TestSafeExcMessage` (URL stripping for https/http/multiple URLs/empty messages/URL-free pass-through), 22 in `tests/test_r2_live_upload.py` (run_scheduler kwarg passthrough, merger and climate CLI startup, quiet-station regression, year rollover via frozen datetime, merge-failure isolation), and 5 in `tests/test_r2_integration.py` (multi-station full cycles, byte-identical key layout vs `backfill_all`'s `upload_after_merge` for both observations and climate, live R2 round-trip with `@pytest.mark.live`).

### Changed
- `run_scheduler(...)` accepts an `r2_client: R2Uploader | None = None` kwarg and forwards it to `run_merge_cycle`.
- `run_merge_cycle` drops the `if result is not None:` gate around the R2 upload. The upload now runs every cycle for every station, gated only on the year file existing on disk. Watermark updates stay gated on successful merge — that's still correct.
- `sync_daily_climate(stations, base_dir, r2_client=None)` accepts an optional uploader and applies the same unconditional-upload semantics as the merger. Climate uses `datetime.now(timezone.utc).year` for the year computation, matching the merger so both paths cross the year rollover at the same instant.
- `R2Client.__init__` gains a keyword-only `endpoint_url: str | None = None` parameter for callers that already have a full endpoint URL (the new AWS-standard `from_env` path uses it). The legacy positional signature `(account_id, access_key, secret_key, bucket)` is preserved.
- `deploy/README.md` `.env` section adds a deprecation note for the legacy R2 var names and the full Sprint 2g-s2 deploy sequence with `${R2_BUCKET}`-based verification commands.

## [0.10.0] - 2026-04-07

### Added
- GCP deploy infrastructure (Sprint 2g): systemd unit files for poller, merger, climate sync, FastAPI, local health server, and R2→local parquet sync. Every unit hardened with `ProtectSystem=strict`, `ProtectHome=true`, `PrivateTmp=true`, `NoNewPrivileges=true`. One-command `deploy/deploy.sh` (ssh → git reset --hard → pip install → restart → health check) with full journal dump on failure.
- Telegram alerting (`ingest/alerting.py`): `send_alert`, `alert_on_failure`, `check_watermark_staleness`, `stale_stations_from_watermarks`. Functions never raise; alert failures never crash the monitored worker. Token and chat_id are always parameters, never module-level env lookups. Logs never leak the token (exception messages redacted because `httpx.HTTPStatusError.__str__` embeds request URLs).
- Local health check server (`ingest/health.py`): `ThreadingHTTPServer` on `127.0.0.1:8080`. `GET /health` returns 200 when all watermarks fresh, 503 when any stale. Single watermark file read per request to avoid a TOCTOU race with the merger's atomic rename. Wrapped in try/except so any crash returns 503 rather than dropping the client.
- Systemd `OnFailure=` template (`deploy/mostlyright-alert@.service`) instantiated per crashed unit. The handler script pulls the last 20 journal lines via `journalctl`, passes them to Python via env vars (no shell-quoting tricks, `<<'PYEOF'` disables bash expansion), and posts a Telegram alert with the unit name and log tail.
- `deploy/README.md` runbook: VM spec (GCP e2-medium, 50GB SSD, us-east4, Ubuntu 24.04), provisioning walkthrough, sudoers snippet covering both `daemon-reload` and `restart mostlyright-*`, staleness watchdog script that sources `.env` before invoking Python (cron inherits an empty env), Go → Python API traffic switch with 24h parallel run and 5-minute DNS rollback, station-code quirk note (poller uses ICAO codes, merger uses internal codes).
- 29 new tests: 20 in `tests/test_alerting.py` (send_alert happy/HTTP/network/timeout/missing-creds, alert_on_failure format + no-crash, check_watermark_staleness fresh/stale/mixed/corrupt/unparseable/boundary, 1 live Telegram smoke test), 9 in `tests/test_ingest_health.py` (happy 200, degraded 503, routing 404, method 405, all using OS-assigned ports to avoid TOCTOU flakiness).

### Changed
- Bumped project version in `pyproject.toml` from `0.8.0` (stale) to `0.10.0` to match the CHANGELOG release history.

## [0.9.0] - 2026-04-06

### Added
- Unit conversion: `convert_observation(obs, "metric")` converts wind to m/s, visibility to km, precip to mm. `convert_observation(obs, "imperial")` converts wind to mph. Returns new Observation via `dataclasses.replace()`. No rounding, raw float64.
- Standalone converters: `kt_to_ms`, `kt_to_mph`, `mi_to_km`, `inches_to_mm`. All exported from `mostlyright`. NaN/inf guarded.
- API `obs_type` filter: `GET /observations?station=NYC&obs_type=METAR` returns only METAR (excludes SPECI). Case-insensitive.
- API `columns` filter: `GET /observations?columns=temp_c,wind_speed_kt` returns only requested fields. Validates against schema, 400 for unknown columns. Works on both `/observations` and `/climate`.
- Rate limit stub headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset` on every API response. Stub values, no enforcement (Sprint 2g).
- WeatherLive returns `list[Observation]`: `current()` and `latest()` now return typed Observation objects with unit conversion applied. `_fetch()` stays `list[dict]` internally.
- SDK client-side conversion: `units="metric"` on `observations()` converts wind/vis/precip. `units`/`tz` removed from API params (conversion is client-side only). `as_dataframe=True` path also applies conversion.
- 41 new tests (1,241 total): conversion unit tests, API filtering tests, rate limit header tests, WeatherLive Observation return tests, e2e metric workflow tests.

### Changed
- CLAUDE.md: enforced "never work on main" rule for sprint sessions.
- Sprint prompt updated: branch creation mandatory, not optional.

## [0.8.0] - 2026-04-06

### Added
- FastAPI weather API: 4 endpoints (`/health`, `/observations`, `/climate`, `/climate/gaps`). JSON, CSV, parquet output. API key auth middleware with health exempt. Input validation (station 404, bad date 400, inverted range 400).
- Python SDK: `TherminalClient` facade with identical method signatures to therminal-py. Drop-in migration: `from therminal` becomes `from mostlyright`. Weather methods (observations, climate, climate_gaps, health). Market methods raise NotImplementedError (Sprint 3).
- SDK config: 4-layer resolution (defaults < TOML < env < kwargs). Reads `~/.mostlyright.toml` with `~/.therminal.toml` fallback. MOSTLYRIGHT_* env vars override THERMINAL_*.
- WeatherLive: real-time METAR from AWC (aviationweather.gov). `current()` and `latest()` with batch station support. Station code validation, retry on 429/5xx.
- Preprocessing module: `clip_outliers()` nulls out-of-bounds sensor values, `iem_crosscheck()` wraps QC crosscheck, `describe()` documents available transforms.
- SDK error hierarchy: TherminalError, NotFoundError, RateLimitError, ValidationError, AuthenticationError, ForbiddenError, ServerError. HTTP status codes mapped automatically.
- HttpSession: shared HTTP client with auto-pagination (`get_all`), format routing (csv/parquet download), typed exception mapping.
- 307 new tests: 198 API tests (72 unit + 126 integration parametric matrix) + 109 SDK tests. 1,149 total.

## [0.7.0] - 2026-04-06

### Added
- R2 upload client (`r2.py`): S3-compatible Cloudflare R2 uploads with boto3. Entity validation, upload verification, paginated listing. R2 key layout: `weather/{entity}/station={CODE}/{YEAR}.parquet`.
- Full backfill CLI (`backfill_all.py`): orchestrates GHCNh + IEM gap-fill + climate for all 20 stations. Resume on failure via progress file. R2 upload gated on both GHCNh + IEM completion (no partial data in R2).
- IEM METAR/SPECI split: separate requests for report_type=3 (METAR) and report_type=4 (SPECI). IEM strips SPECI keyword from raw METAR text, so split requests are the only way to tag observation_type correctly. 183,476 SPECI reports now correctly classified.
- Schema version metadata: all parquet files embed `schema_version: "1.0"` and `entity` in file metadata. Readers can detect version mismatch after schema changes.
- Round-trip precision tests: 4 tests verifying exact float64 equality through write/read cycle for all 9 float fields + nulls + climate + extreme values.
- R2 integration in merge scheduler: uploads updated year partition after each merge cycle. Best-effort, never blocks merge.
- IEM polite delay (1s between requests) to prevent university server 503s.
- Coverage analysis script (`scripts/analyze_coverage.py`): timezone-aware crosscheck of CLI highs vs observation max, hourly gap detection, source/type ratio reporting.
- CLAUDE.md review rules: python-reviewer mandatory on every review, data integrity check mandatory when touching pipeline code.
- 66 new tests (842 total).

### Fixed
- IEM monthly chunking: end date now exclusive (first of next month). Previously missed all observations on the last day of each month (IEM's date filter is exclusive). Every month-end was missing 18+ hours of local daytime data.
- IEM observation_type: all IEM-sourced observations were tagged as METAR regardless of actual type. Now correctly tagged via split requests.
- R2 upload gating: observations only upload to R2 when both GHCNh and IEM steps complete. Previously uploaded GHCNh-only partial data on IEM failure.

## [0.6.0] - 2026-04-04

### Added
- IEM CLI climate parser (`_climate.py`): parses daily high/low temperature from IEM's cli.py JSON endpoint. Infers report type (final/correction/preliminary) from product timestamp vs observation date. Temperature bounds from climate.json schema (high: -60/150°F, low: -80/130°F). THIS IS THE KALSHI SETTLEMENT SOURCE.
- Climate parquet storage: `CLIMATE_SCHEMA` (9 fields), `write_climate_staging`, `merge_climate`, `read_climate`. Dedup uses report_type_priority with strict > (not >=). First-seen final is preserved as settlement truth.
- Climate sync module (`climate_sync.py`): `download_cli` with retry (via `download_with_retry`), response shape validation, IEM rate limiting (1s delay). `backfill_climate` for multi-year download. `sync_daily_climate` for daily refresh.
- Climate CLI: `python -m ingest.climate --station ATL --years 2020,2025 --data-dir data`. Year bounds validation. `--station` and `--years` required together.
- 76 new tests (776 total): parser (report type inference, record parsing, temp bounds), storage (write/read/dedup strict >, single-batch dedup), sync (download, cache, backfill 404/500, daily sync error isolation), timezone (PHX no-DST, Eastern DST transition, passthrough), CLI (arg parsing, year validation).

### Fixed
- IEM temp_f/temp_c consistency: when derived °C is out of bounds, raw °F is also nulled (previously temp_f=500 while temp_c=None).
- 404 years now visible in GHCNh coverage reports (per_year_counts[year]=0 instead of invisible).
- Coverage rounding vs threshold consistency: iem_primary flag now uses rounded coverage_pct.
- KeyError crash on invalid station code in backfill_all_stations: validates codes up front.
- bounded_float logging now includes field context (temp_c, dewpoint_c).
- CLAUDE.md test count corrected (700+ not 2,600+).
- _MAX_YEAR in backfill.py now dynamic (date.today().year + 1).
- DEFAULT_STATIONS derived from STATIONS dict (was hardcoded duplicate).
- T-group regex restricted to after RMK in raw METAR (prevents false positives).
- NCEI polite delay (1s) between GHCNh downloads.
- KNYC documented as non-ASOS station (may lack T-group).

## [0.5.0] - 2026-04-04

### Added
- T-group parsing in AWC transform (`_awc.py`): extracts tenths-precision temperature from METAR remarks `T{sSSS}{sDDD}`, overriding whole-degree body group. ASOS always includes T-group. Eliminates #1 training/live mismatch risk (0.3-0.7°F precision gap between AWC live and IEM/GHCNh backfill).
- Temperature bounds (`_bounds.py`): `TEMP_MIN_C = -90.0`, `TEMP_MAX_C = 60.0` (world records ±margin). `bounded_float()` returns None for out-of-range values with audit logging. Applied in all 3 parsers (AWC, IEM, GHCNh).
- AWC poller defaults expanded to all 20 stations (`awc_runner.py`): `DEFAULT_STATIONS` now includes all 20 ICAO codes. `python -m ingest.poller` polls all stations without flags.
- Merger help text lists all 20 station codes (`merger.py`).
- 48 new tests (700 total): T-group parsing (10 tests), T-group integration (5), AWC temp bounds (11), IEM temp bounds (6), GHCNh temp bounds (8), poller defaults (6), merger defaults (3).

### Changed
- AWC parser applies temp bounds after T-group override.
- IEM parser bounds °C conversion (raw °F preserved for audit).
- GHCNh parser bounds °C after QC filtering.

## [0.4.0] - 2026-04-04

### Added
- 20-station expansion: replaced 2-station dict with all 20 Kalshi-traded NWS stations (ATL, AUS, BOS, DCA, DEN, DFW, HOU, LAS, LAX, MDW, MIA, MSP, MSY, NYC, OKC, PHL, PHX, SAT, SEA, SFO). JFK removed (not Kalshi-traded). All GHCNh IDs verified against NCEI.
- Multi-station backfill CLI: `python -m ingest.backfill --all` backfills all 20 stations. `--station` and `--all` are mutually exclusive. Default years changed from 2000-2025 to 2020-2025.
- Coverage reporting: `backfill_all_stations()` computes per-station-year hourly coverage (actual/expected, leap-aware). Station-years below 50% flagged as IEM-primary for Session 2 gap-fill.
- Immutable result types: `BackfillResult` uses `tuple` and `MappingProxyType` instead of mutable `list`/`dict`. `AllStationsResult` and `CoverageEntry` dataclasses added.
- Year bounds validation: CLI rejects years outside 1950-2030.
- ATL test fixtures: GHCNh PSV and IEM CSV fixtures for Atlanta (replaces JFK in all backfill tests).
- 27 new tests (652 total): station expansion validation (unique codes, ICAO format, no JFK), coverage calculation (full, low, boundary, multi-year), multi-station orchestration (parallel, 404 resilience, exception isolation), CLI parsing (--all flag, year bounds).

### Changed
- All test files updated from JFK to ATL references (test_backfill.py, test_merge_scheduler.py, test_watermarks.py).
- CLAUDE.md CLI examples updated to reflect --all flag and ATL station.

## [0.3.0] - 2026-04-03

### Added
- AWC METAR live poller (`ingest/sources/awc_poller.py`): `fetch_latest()` fetches live METARs from AWC API with async HTTP, exponential backoff retry on 5xx, broad `httpx.RequestError` handling. `poll_and_stage()` transforms via shared `awc_to_observation` and writes to staging parquet.
- Poller runner (`ingest/sources/awc_runner.py`): async loop with `httpx.AsyncClient` connection pooling, 60s default interval, error resilience (never crashes on transient failures), graceful SIGINT/SIGTERM shutdown.
- CLI entry point (`ingest/poller.py`): `python -m ingest.poller --interval 60 --data-dir data --stations KNYC,KJFK`. Input validation for ICAO codes and minimum interval (10s).
- Merge scheduler (`ingest/sources/merge_scheduler.py`): `iem_sweep()` fetches last 36h of IEM data per station with `skip_cache=True` to fill AWC gaps. `run_merge_cycle()` sweeps IEM (best-effort) then merges all staging into year partitions with source-priority dedup. `run_scheduler()` sync loop with SIGINT/SIGTERM clean shutdown.
- Watermark persistence (`ingest/watermarks.py`): `read_watermarks()` loads per-station timestamps from JSON (returns empty dict on missing/corrupt file for safe cold start). `write_watermarks()` atomic write via .tmp+rename. `latest_observed_at()` finds max observed_at from year partitions with previous-year fallback for Jan 1 edge case.
- Merge scheduler watermark integration: `iem_sweep()` accepts watermarks to narrow IEM download window from 2-day default to watermark minus 1 hour. `run_merge_cycle()` reads watermarks before IEM sweep, updates per-station watermarks after each successful merge (never moves backward). `run_scheduler()` logs watermark state on startup.
- Merger CLI (`ingest/merger.py`): `python -m ingest.merger --interval 900 --data-dir data --stations NYC,JFK`. Minimum interval 60s. `--watermark-file` flag (default: `{data-dir}/watermarks.json`).
- `skip_cache` parameter on `download_iem()`: when True, re-downloads even if cached file exists. Enables live IEM sweep freshness without breaking backfill callers.
- Tests shared conftest (`tests/conftest.py`): `observation_schema` fixture for test directory scope.
- 54 new tests (625 total): AWC poller fetch/stage/runner (14), merge scheduler sweep/cycle/scheduler (17 including AWC gap-fill-by-IEM integration, error isolation, skip_cache), watermark read/write/latest/integration (24 including cold start, backward prevention, write failure resilience). 4 live integration tests (deselected by default).
- pytest-asyncio dependency for async test support.

### Changed
- Retry constants (MAX_RETRIES, TRANSIENT_CODES) imported from shared `_http.py` instead of duplicated.

## [0.2.0] - 2026-04-02

### Added
- Backfill pipeline: GHCNh download + IEM gap-fill + cross-source quality report for JFK
- Station mapping (`ingest/stations.py`): StationInfo frozen dataclass with GHCNh ID, ICAO, timezone. JFK first, structure supports all 20 Kalshi stations.
- GHCNh backfill runner (`ingest/sources/ghcnh_backfill.py`): download_ghcnh (per-year PSV, cache, exponential backoff retry), backfill_ghcnh (orchestrate download/parse/stage/merge per year, skip 404s, BackfillResult with per-year counts).
- IEM gap-fill runner (`ingest/sources/iem_gap_fill.py`): download_iem (monthly chunking, cache, retry), gap_fill_iem (download/parse/merge, compute net-new + GHCNh overwrites, GapFillResult).
- Quality report (`ingest/sources/quality_report.py`): cross_check_quality reads merged parquet, pairs sources by timestamp, runs iem_crosscheck, produces QualityReport with flag counts + gap analysis.
- CLI runner (`ingest/backfill.py`): ties GHCNh backfill + IEM gap-fill + quality report together. Supports --station, --years, and --data-dir args.
- Shared QC crosscheck module (`src/mostlyright/qc/crosscheck.py`): extracted iem_crosscheck from test file to shared location. Added visibility divergence check (>2mi threshold).
- 30 new tests (551 total): station mapping (4), GHCNh download mock HTTP (6), GHCNh backfill orchestration (4), IEM download mock HTTP (5), IEM gap-fill orchestration (3), quality report (6), live integration tests for both sources (2 deselected by default).
- SDK package structure (`src/mostlyright/`) with editable install via hatchling
- Unit conversion module (`_convert.py`): celsius_to_fahrenheit, fahrenheit_to_celsius, hpa_to_inhg (WMO 0.0295299875), compute_relative_humidity (Magnus), compute_feels_like (NWS algorithm). Zero rounding anywhere.
- Observation frozen dataclass with 30 storage fields + 2 computed fields (relative_humidity, feels_like_f derived at load time). New additive fields: temp_c, dewpoint_c, qc_field.
- `to_storage_dict()` method that strips computed fields for parquet-safe serialization
- AWC METAR transform (`weather/_awc.py`): maps AWC JSON to observation schema dict with source="awc". Handles VRB wind, 10+ visibility, trace precip, SLP bounds (870-1084 hPa), qc_field bitmask, cloud layer type safety, obsTime sanity checks.
- GHCNh PSV parser (`weather/_ghcnh.py`): parse_ghcnh_row, parse_ghcnh_file, ghcnh_station_to_code. Quality_Code filtering on all variables including sky cover layers. Weather code validation filters bare numeric WMO codes. Datetime validation behind regex.
- IEM METAR CSV parser (`weather/_iem.py`): iem_to_observation, parse_iem_file. Handles "M" missing values, "T" trace precip, timestamp parsing, SPECI detection from METAR text, peak wind time extraction. Bounds validation matching AWC/GHCNh patterns.
- Shared schema bounds module (`weather/_bounds.py`): constants and validation helpers extracted from all 3 parsers. Single source of truth for schema-derived bounds.
- Parquet storage layer (`ingest/storage/parquet.py`): write_staging (grouped by station+date, atomic tmp+rename), merge_staging (year partitions, dedup by station/time/type, source priority AWC>IEM>GHCNh), read_observations. JSON Schema validation before write, bad records quarantined with error_reason column. Hive-style partitioning.
- 348 new tests (551 total across project): 91 IEM parser, 93 GHCNh parser, 134 AWC/convert/observation/parquet, 30 backfill pipeline. Real JFK fixtures for IEM CSV and GHCNh PSV integration tests.

### Changed
- Source priority corrected to AWC(3) > IEM(2) > GHCNh(1) across all architecture docs and schema comments
- AWC `_safe_int` uses `round()` (not `int()`) for cross-source consistency with GHCNh/IEM
- pyproject.toml: renamed to `mostlyright`, added hatchling build system, pyright config, pyarrow dependency

## [0.1.0] - 2026-03-31

### Added
- Initial monorepo with Sprint 1 deliverables: 9 JSON Schema specs, 203 validation tests, research docs, architecture docs
