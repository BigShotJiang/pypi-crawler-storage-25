"""Haybarn extension 'crypto' for haybarn 1.5.2.

Data-only package. The binary lives next to this file as
'crypto.duckdb_extension.gz'; haybarn discovers it via the haybarn-metadata.json
blob in this distribution's dist-info/ directory.
"""
