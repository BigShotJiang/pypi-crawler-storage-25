# encoding: utf-8

import ckan.plugins.toolkit as toolkit
import click
from ckan import model

from . import helpers
from . import streaming
from . import tasks


def get_commands():
    return [cli]


@click.group('downloadall')
@click.help_option('-h', '--help')
def cli():
    pass


@cli.command('update-zip', short_help='Update zip file for a dataset')
@click.argument('dataset_ref')
@click.option('--synchronous', '-s',
              help='Do it in the same process (not the worker)',
              is_flag=True)
@click.option('--force', '-f',
              help='Force generation of zip file',
              is_flag=True)
def update_zip(dataset_ref, synchronous, force):
    """ update-zip <package-name>

    Generates zip file for a dataset, downloading its resources.
    Datasets above the stream threshold are skipped (they are streamed on
    demand instead).
    """
    context = {'model': model, 'session': model.Session, 'ignore_auth': True}
    try:
        pkg_dict = toolkit.get_action('package_show')(
            context, {'id': dataset_ref})
    except toolkit.ObjectNotFound:
        raise click.ClickException(
            'Dataset not found: {}'.format(dataset_ref))

    if streaming.should_stream(pkg_dict):
        click.secho(
            'Skipped (above stream threshold – will be streamed on demand): '
            '{}'.format(dataset_ref),
            fg='yellow')
        return

    skip_if_no_changes = True
    if force:
        skip_if_no_changes = False

    if synchronous:
        tasks.update_zip(dataset_ref, skip_if_no_changes)
    else:
        toolkit.enqueue_job(
            tasks.update_zip, [dataset_ref, skip_if_no_changes],
            title='DownloadAll {operation} "{name}" {id}'.format(
                operation='cli-requested', name=dataset_ref,
                id=dataset_ref),
            queue=helpers.get_queue_name(),
            rq_kwargs={"timeout": helpers.get_job_timeout()})
    click.secho('update-zip: SUCCESS', fg='green', bold=True)


@cli.command('update-all-zips',
             short_help='Update zip files for all datasets')
@click.option('--synchronous', '-s',
              help='Do it in the same process (not the worker)',
              is_flag=True)
@click.option('--force', '-f',
              help='Force generation of zip file',
              is_flag=True)
def update_all_zips(synchronous, force):
    """ update-all-zips

    Generates zip file for all datasets that are below the stream threshold.
    Datasets at or above the threshold are skipped – their ZIPs are generated
    on demand at download time.
    """
    context = {'model': model, 'session': model.Session, 'ignore_auth': True}
    datasets = toolkit.get_action('package_list')(context, {})

    skipped = 0
    processed = 0

    for i, dataset_name in enumerate(datasets):
        try:
            pkg_dict = toolkit.get_action('package_show')(
                context, {'id': dataset_name})
        except toolkit.ObjectNotFound:
            click.echo('Dataset not found, skipping: {}'.format(dataset_name))
            continue

        if streaming.should_stream(pkg_dict):
            click.echo(
                'Skipping {}/{} {} (above stream threshold)'.format(
                    i + 1, len(datasets), dataset_name))
            skipped += 1
            continue

        skip_if_no_changes = True
        if force:
            skip_if_no_changes = False

        processed += 1
        if synchronous:
            click.echo(
                'Processing {}/{} {}'.format(i + 1, len(datasets), dataset_name))
            tasks.update_zip(dataset_name, skip_if_no_changes)
        else:
            click.echo(
                'Queuing {}/{} {}'.format(i + 1, len(datasets), dataset_name))
            toolkit.enqueue_job(
                tasks.update_zip, [dataset_name, skip_if_no_changes],
                title='DownloadAll {operation} "{name}" {id}'.format(
                    operation='cli-requested', name=dataset_name,
                    id=dataset_name),
                queue=helpers.get_queue_name(),
                rq_kwargs={"timeout": helpers.get_job_timeout()})

    click.secho(
        'update-all-zips: SUCCESS  (processed: {}, skipped as streamable: {})'
        .format(processed, skipped),
        fg='green', bold=True)
