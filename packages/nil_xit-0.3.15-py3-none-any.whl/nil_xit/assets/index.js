var Bt = Object.defineProperty;
var dt = (i) => {
  throw TypeError(i);
};
var Et = (i, t, e) => t in i ? Bt(i, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : i[t] = e;
var a = (i, t, e) => Et(i, typeof t != "symbol" ? t + "" : t, e), nt = (i, t, e) => t.has(i) || dt("Cannot " + e);
var o = (i, t, e) => (nt(i, t, "read from private field"), e ? e.call(i) : t.get(i)), P = (i, t, e) => t.has(i) ? dt("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(i) : t.set(i, e), p = (i, t, e, s) => (nt(i, t, "write to private field"), s ? s.call(i, e) : t.set(i, e), e), at = (i, t, e) => (nt(i, t, "access private method"), e);
import { cF as ot, cG as bt } from "./svelte/store.js";
const rt = 2, k = 4, A = 4, g = 4, x = new Int32Array(2), _t = new Float32Array(x.buffer), ft = new Float64Array(x.buffer), st = new Uint16Array(new Uint8Array([1, 0]).buffer)[0] === 1;
var ct;
(function(i) {
  i[i.UTF8_BYTES = 1] = "UTF8_BYTES", i[i.UTF16_STRING = 2] = "UTF16_STRING";
})(ct || (ct = {}));
class y {
  /**
   * Create a new ByteBuffer with a given array of bytes (`Uint8Array`)
   */
  constructor(t) {
    this.bytes_ = t, this.position_ = 0, this.text_decoder_ = new TextDecoder();
  }
  /**
   * Create and allocate a new ByteBuffer with a given size.
   */
  static allocate(t) {
    return new y(new Uint8Array(t));
  }
  clear() {
    this.position_ = 0;
  }
  /**
   * Get the underlying `Uint8Array`.
   */
  bytes() {
    return this.bytes_;
  }
  /**
   * Get the buffer's position.
   */
  position() {
    return this.position_;
  }
  /**
   * Set the buffer's position.
   */
  setPosition(t) {
    this.position_ = t;
  }
  /**
   * Get the buffer's capacity.
   */
  capacity() {
    return this.bytes_.length;
  }
  readInt8(t) {
    return this.readUint8(t) << 24 >> 24;
  }
  readUint8(t) {
    return this.bytes_[t];
  }
  readInt16(t) {
    return this.readUint16(t) << 16 >> 16;
  }
  readUint16(t) {
    return this.bytes_[t] | this.bytes_[t + 1] << 8;
  }
  readInt32(t) {
    return this.bytes_[t] | this.bytes_[t + 1] << 8 | this.bytes_[t + 2] << 16 | this.bytes_[t + 3] << 24;
  }
  readUint32(t) {
    return this.readInt32(t) >>> 0;
  }
  readInt64(t) {
    return BigInt.asIntN(64, BigInt(this.readUint32(t)) + (BigInt(this.readUint32(t + 4)) << BigInt(32)));
  }
  readUint64(t) {
    return BigInt.asUintN(64, BigInt(this.readUint32(t)) + (BigInt(this.readUint32(t + 4)) << BigInt(32)));
  }
  readFloat32(t) {
    return x[0] = this.readInt32(t), _t[0];
  }
  readFloat64(t) {
    return x[st ? 0 : 1] = this.readInt32(t), x[st ? 1 : 0] = this.readInt32(t + 4), ft[0];
  }
  writeInt8(t, e) {
    this.bytes_[t] = e;
  }
  writeUint8(t, e) {
    this.bytes_[t] = e;
  }
  writeInt16(t, e) {
    this.bytes_[t] = e, this.bytes_[t + 1] = e >> 8;
  }
  writeUint16(t, e) {
    this.bytes_[t] = e, this.bytes_[t + 1] = e >> 8;
  }
  writeInt32(t, e) {
    this.bytes_[t] = e, this.bytes_[t + 1] = e >> 8, this.bytes_[t + 2] = e >> 16, this.bytes_[t + 3] = e >> 24;
  }
  writeUint32(t, e) {
    this.bytes_[t] = e, this.bytes_[t + 1] = e >> 8, this.bytes_[t + 2] = e >> 16, this.bytes_[t + 3] = e >> 24;
  }
  writeInt64(t, e) {
    this.writeInt32(t, Number(BigInt.asIntN(32, e))), this.writeInt32(t + 4, Number(BigInt.asIntN(32, e >> BigInt(32))));
  }
  writeUint64(t, e) {
    this.writeUint32(t, Number(BigInt.asUintN(32, e))), this.writeUint32(t + 4, Number(BigInt.asUintN(32, e >> BigInt(32))));
  }
  writeFloat32(t, e) {
    _t[0] = e, this.writeInt32(t, x[0]);
  }
  writeFloat64(t, e) {
    ft[0] = e, this.writeInt32(t, x[st ? 0 : 1]), this.writeInt32(t + 4, x[st ? 1 : 0]);
  }
  /**
   * Return the file identifier.   Behavior is undefined for FlatBuffers whose
   * schema does not include a file_identifier (likely points at padding or the
   * start of a the root vtable).
   */
  getBufferIdentifier() {
    if (this.bytes_.length < this.position_ + k + A)
      throw new Error("FlatBuffers: ByteBuffer is too short to contain an identifier.");
    let t = "";
    for (let e = 0; e < A; e++)
      t += String.fromCharCode(this.readInt8(this.position_ + k + e));
    return t;
  }
  /**
   * Look up a field in the vtable, return an offset into the object, or 0 if the
   * field is not present.
   */
  __offset(t, e) {
    const s = t - this.readInt32(t);
    return e < this.readInt16(s) ? this.readInt16(s + e) : 0;
  }
  /**
   * Initialize any Table-derived type to point to the union at the given offset.
   */
  __union(t, e) {
    return t.bb_pos = e + this.readInt32(e), t.bb = this, t;
  }
  /**
   * Create a JavaScript string from UTF-8 data stored inside the FlatBuffer.
   * This allocates a new string and converts to wide chars upon each access.
   *
   * To avoid the conversion to string, pass Encoding.UTF8_BYTES as the
   * "optionalEncoding" argument. This is useful for avoiding conversion when
   * the data will just be packaged back up in another FlatBuffer later on.
   *
   * @param offset
   * @param opt_encoding Defaults to UTF16_STRING
   */
  __string(t, e) {
    t += this.readInt32(t);
    const s = this.readInt32(t);
    t += k;
    const n = this.bytes_.subarray(t, t + s);
    return e === ct.UTF8_BYTES ? n : this.text_decoder_.decode(n);
  }
  /**
   * Handle unions that can contain string as its member, if a Table-derived type then initialize it,
   * if a string then return a new one
   *
   * WARNING: strings are immutable in JS so we can't change the string that the user gave us, this
   * makes the behaviour of __union_with_string different compared to __union
   */
  __union_with_string(t, e) {
    return typeof t == "string" ? this.__string(e) : this.__union(t, e);
  }
  /**
   * Retrieve the relative offset stored at "offset"
   */
  __indirect(t) {
    return t + this.readInt32(t);
  }
  /**
   * Get the start of data of a vector whose offset is stored at "offset" in this object.
   */
  __vector(t) {
    return t + this.readInt32(t) + k;
  }
  /**
   * Get the length of a vector whose offset is stored at "offset" in this object.
   */
  __vector_len(t) {
    return this.readInt32(t + this.readInt32(t));
  }
  __has_identifier(t) {
    if (t.length != A)
      throw new Error("FlatBuffers: file identifier must be length " + A);
    for (let e = 0; e < A; e++)
      if (t.charCodeAt(e) != this.readInt8(this.position() + k + e))
        return !1;
    return !0;
  }
  /**
   * A helper function for generating list for obj api
   */
  createScalarList(t, e) {
    const s = [];
    for (let n = 0; n < e; ++n) {
      const r = t(n);
      r !== null && s.push(r);
    }
    return s;
  }
  /**
   * A helper function for generating list for obj api
   * @param listAccessor function that accepts an index and return data at that index
   * @param listLength listLength
   * @param res result list
   */
  createObjList(t, e) {
    const s = [];
    for (let n = 0; n < e; ++n) {
      const r = t(n);
      r !== null && s.push(r.unpack());
    }
    return s;
  }
}
class w {
  /**
   * Create a FlatBufferBuilder.
   */
  constructor(t) {
    this.minalign = 1, this.vtable = null, this.vtable_in_use = 0, this.isNested = !1, this.object_start = 0, this.vtables = [], this.vector_num_elems = 0, this.force_defaults = !1, this.string_maps = null, this.text_encoder = new TextEncoder();
    let e;
    t ? e = t : e = 1024, this.bb = y.allocate(e), this.space = e;
  }
  clear() {
    this.bb.clear(), this.space = this.bb.capacity(), this.minalign = 1, this.vtable = null, this.vtable_in_use = 0, this.isNested = !1, this.object_start = 0, this.vtables = [], this.vector_num_elems = 0, this.force_defaults = !1, this.string_maps = null;
  }
  /**
   * In order to save space, fields that are set to their default value
   * don't get serialized into the buffer. Forcing defaults provides a
   * way to manually disable this optimization.
   *
   * @param forceDefaults true always serializes default values
   */
  forceDefaults(t) {
    this.force_defaults = t;
  }
  /**
   * Get the ByteBuffer representing the FlatBuffer. Only call this after you've
   * called finish(). The actual data starts at the ByteBuffer's current position,
   * not necessarily at 0.
   */
  dataBuffer() {
    return this.bb;
  }
  /**
   * Get the bytes representing the FlatBuffer. Only call this after you've
   * called finish().
   */
  asUint8Array() {
    return this.bb.bytes().subarray(this.bb.position(), this.bb.position() + this.offset());
  }
  /**
   * Prepare to write an element of `size` after `additional_bytes` have been
   * written, e.g. if you write a string, you need to align such the int length
   * field is aligned to 4 bytes, and the string data follows it directly. If all
   * you need to do is alignment, `additional_bytes` will be 0.
   *
   * @param size This is the of the new element to write
   * @param additional_bytes The padding size
   */
  prep(t, e) {
    t > this.minalign && (this.minalign = t);
    const s = ~(this.bb.capacity() - this.space + e) + 1 & t - 1;
    for (; this.space < s + t + e; ) {
      const n = this.bb.capacity();
      this.bb = w.growByteBuffer(this.bb), this.space += this.bb.capacity() - n;
    }
    this.pad(s);
  }
  pad(t) {
    for (let e = 0; e < t; e++)
      this.bb.writeInt8(--this.space, 0);
  }
  writeInt8(t) {
    this.bb.writeInt8(this.space -= 1, t);
  }
  writeInt16(t) {
    this.bb.writeInt16(this.space -= 2, t);
  }
  writeInt32(t) {
    this.bb.writeInt32(this.space -= 4, t);
  }
  writeInt64(t) {
    this.bb.writeInt64(this.space -= 8, t);
  }
  writeFloat32(t) {
    this.bb.writeFloat32(this.space -= 4, t);
  }
  writeFloat64(t) {
    this.bb.writeFloat64(this.space -= 8, t);
  }
  /**
   * Add an `int8` to the buffer, properly aligned, and grows the buffer (if necessary).
   * @param value The `int8` to add the buffer.
   */
  addInt8(t) {
    this.prep(1, 0), this.writeInt8(t);
  }
  /**
   * Add an `int16` to the buffer, properly aligned, and grows the buffer (if necessary).
   * @param value The `int16` to add the buffer.
   */
  addInt16(t) {
    this.prep(2, 0), this.writeInt16(t);
  }
  /**
   * Add an `int32` to the buffer, properly aligned, and grows the buffer (if necessary).
   * @param value The `int32` to add the buffer.
   */
  addInt32(t) {
    this.prep(4, 0), this.writeInt32(t);
  }
  /**
   * Add an `int64` to the buffer, properly aligned, and grows the buffer (if necessary).
   * @param value The `int64` to add the buffer.
   */
  addInt64(t) {
    this.prep(8, 0), this.writeInt64(t);
  }
  /**
   * Add a `float32` to the buffer, properly aligned, and grows the buffer (if necessary).
   * @param value The `float32` to add the buffer.
   */
  addFloat32(t) {
    this.prep(4, 0), this.writeFloat32(t);
  }
  /**
   * Add a `float64` to the buffer, properly aligned, and grows the buffer (if necessary).
   * @param value The `float64` to add the buffer.
   */
  addFloat64(t) {
    this.prep(8, 0), this.writeFloat64(t);
  }
  addFieldInt8(t, e, s) {
    (this.force_defaults || e != s) && (this.addInt8(e), this.slot(t));
  }
  addFieldInt16(t, e, s) {
    (this.force_defaults || e != s) && (this.addInt16(e), this.slot(t));
  }
  addFieldInt32(t, e, s) {
    (this.force_defaults || e != s) && (this.addInt32(e), this.slot(t));
  }
  addFieldInt64(t, e, s) {
    (this.force_defaults || e !== s) && (this.addInt64(e), this.slot(t));
  }
  addFieldFloat32(t, e, s) {
    (this.force_defaults || e != s) && (this.addFloat32(e), this.slot(t));
  }
  addFieldFloat64(t, e, s) {
    (this.force_defaults || e != s) && (this.addFloat64(e), this.slot(t));
  }
  addFieldOffset(t, e, s) {
    (this.force_defaults || e != s) && (this.addOffset(e), this.slot(t));
  }
  /**
   * Structs are stored inline, so nothing additional is being added. `d` is always 0.
   */
  addFieldStruct(t, e, s) {
    e != s && (this.nested(e), this.slot(t));
  }
  /**
   * Structures are always stored inline, they need to be created right
   * where they're used.  You'll get this assertion failure if you
   * created it elsewhere.
   */
  nested(t) {
    if (t != this.offset())
      throw new TypeError("FlatBuffers: struct must be serialized inline.");
  }
  /**
   * Should not be creating any other object, string or vector
   * while an object is being constructed
   */
  notNested() {
    if (this.isNested)
      throw new TypeError("FlatBuffers: object serialization must not be nested.");
  }
  /**
   * Set the current vtable at `voffset` to the current location in the buffer.
   */
  slot(t) {
    this.vtable !== null && (this.vtable[t] = this.offset());
  }
  /**
   * @returns Offset relative to the end of the buffer.
   */
  offset() {
    return this.bb.capacity() - this.space;
  }
  /**
   * Doubles the size of the backing ByteBuffer and copies the old data towards
   * the end of the new buffer (since we build the buffer backwards).
   *
   * @param bb The current buffer with the existing data
   * @returns A new byte buffer with the old data copied
   * to it. The data is located at the end of the buffer.
   *
   * uint8Array.set() formally takes {Array<number>|ArrayBufferView}, so to pass
   * it a uint8Array we need to suppress the type check:
   * @suppress {checkTypes}
   */
  static growByteBuffer(t) {
    const e = t.capacity();
    if (e & 3221225472)
      throw new Error("FlatBuffers: cannot grow buffer beyond 2 gigabytes.");
    const s = e << 1, n = y.allocate(s);
    return n.setPosition(s - e), n.bytes().set(t.bytes(), s - e), n;
  }
  /**
   * Adds on offset, relative to where it will be written.
   *
   * @param offset The offset to add.
   */
  addOffset(t) {
    this.prep(k, 0), this.writeInt32(this.offset() - t + k);
  }
  /**
   * Start encoding a new object in the buffer.  Users will not usually need to
   * call this directly. The FlatBuffers compiler will generate helper methods
   * that call this method internally.
   */
  startObject(t) {
    this.notNested(), this.vtable == null && (this.vtable = []), this.vtable_in_use = t;
    for (let e = 0; e < t; e++)
      this.vtable[e] = 0;
    this.isNested = !0, this.object_start = this.offset();
  }
  /**
   * Finish off writing the object that is under construction.
   *
   * @returns The offset to the object inside `dataBuffer`
   */
  endObject() {
    if (this.vtable == null || !this.isNested)
      throw new Error("FlatBuffers: endObject called without startObject");
    this.addInt32(0);
    const t = this.offset();
    let e = this.vtable_in_use - 1;
    for (; e >= 0 && this.vtable[e] == 0; e--)
      ;
    const s = e + 1;
    for (; e >= 0; e--)
      this.addInt16(this.vtable[e] != 0 ? t - this.vtable[e] : 0);
    const n = 2;
    this.addInt16(t - this.object_start);
    const r = (s + n) * rt;
    this.addInt16(r);
    let c = 0;
    const l = this.space;
    t: for (e = 0; e < this.vtables.length; e++) {
      const f = this.bb.capacity() - this.vtables[e];
      if (r == this.bb.readInt16(f)) {
        for (let d = rt; d < r; d += rt)
          if (this.bb.readInt16(l + d) != this.bb.readInt16(f + d))
            continue t;
        c = this.vtables[e];
        break;
      }
    }
    return c ? (this.space = this.bb.capacity() - t, this.bb.writeInt32(this.space, c - t)) : (this.vtables.push(this.offset()), this.bb.writeInt32(this.bb.capacity() - t, this.offset() - t)), this.isNested = !1, t;
  }
  /**
   * Finalize a buffer, poiting to the given `root_table`.
   */
  finish(t, e, s) {
    const n = s ? g : 0;
    if (e) {
      const r = e;
      if (this.prep(this.minalign, k + A + n), r.length != A)
        throw new TypeError("FlatBuffers: file identifier must be length " + A);
      for (let c = A - 1; c >= 0; c--)
        this.writeInt8(r.charCodeAt(c));
    }
    this.prep(this.minalign, k + n), this.addOffset(t), n && this.addInt32(this.bb.capacity() - this.space), this.bb.setPosition(this.space);
  }
  /**
   * Finalize a size prefixed buffer, pointing to the given `root_table`.
   */
  finishSizePrefixed(t, e) {
    this.finish(t, e, !0);
  }
  /**
   * This checks a required field has been set in a given table that has
   * just been constructed.
   */
  requiredField(t, e) {
    const s = this.bb.capacity() - t, n = s - this.bb.readInt32(s);
    if (!(e < this.bb.readInt16(n) && this.bb.readInt16(n + e) != 0))
      throw new TypeError("FlatBuffers: field " + e + " must be set");
  }
  /**
   * Start a new array/vector of objects.  Users usually will not call
   * this directly. The FlatBuffers compiler will create a start/end
   * method for vector types in generated code.
   *
   * @param elem_size The size of each element in the array
   * @param num_elems The number of elements in the array
   * @param alignment The alignment of the array
   */
  startVector(t, e, s) {
    this.notNested(), this.vector_num_elems = e, this.prep(k, t * e), this.prep(s, t * e);
  }
  /**
   * Finish off the creation of an array and all its elements. The array must be
   * created with `startVector`.
   *
   * @returns The offset at which the newly created array
   * starts.
   */
  endVector() {
    return this.writeInt32(this.vector_num_elems), this.offset();
  }
  /**
   * Encode the string `s` in the buffer using UTF-8. If the string passed has
   * already been seen, we return the offset of the already written string
   *
   * @param s The string to encode
   * @return The offset in the buffer where the encoded string starts
   */
  createSharedString(t) {
    if (!t)
      return 0;
    if (this.string_maps || (this.string_maps = /* @__PURE__ */ new Map()), this.string_maps.has(t))
      return this.string_maps.get(t);
    const e = this.createString(t);
    return this.string_maps.set(t, e), e;
  }
  /**
   * Encode the string `s` in the buffer using UTF-8. If a Uint8Array is passed
   * instead of a string, it is assumed to contain valid UTF-8 encoded data.
   *
   * @param s The string to encode
   * @return The offset in the buffer where the encoded string starts
   */
  createString(t) {
    if (t == null)
      return 0;
    let e;
    return t instanceof Uint8Array ? e = t : e = this.text_encoder.encode(t), this.addInt8(0), this.startVector(1, e.length, 1), this.bb.setPosition(this.space -= e.length), this.bb.bytes().set(e, this.space), this.endVector();
  }
  /**
   * Create a byte vector.
   *
   * @param v The bytes to add
   * @returns The offset in the buffer where the byte vector starts
   */
  createByteVector(t) {
    return t == null ? 0 : (this.startVector(1, t.length, 1), this.bb.setPosition(this.space -= t.length), this.bb.bytes().set(t, this.space), this.endVector());
  }
  /**
   * A helper function to pack an object
   *
   * @returns offset of obj
   */
  createObjectOffset(t) {
    return t === null ? 0 : typeof t == "string" ? this.createString(t) : t.pack(this);
  }
  /**
   * A helper function to pack a list of object
   *
   * @returns list of offsets of each non null object
   */
  createObjectOffsetList(t) {
    const e = [];
    for (let s = 0; s < t.length; ++s) {
      const n = t[s];
      if (n !== null)
        e.push(this.createObjectOffset(n));
      else
        throw new TypeError("FlatBuffers: Argument for createObjectOffsetList cannot contain null.");
    }
    return e;
  }
  createStructOffsetList(t, e) {
    return e(this, t.length), this.createObjectOffsetList(t.slice().reverse()), this.endVector();
  }
}
var u;
(function(i) {
  i[i.Client_Unique_FrameInfo_Request = 0] = "Client_Unique_FrameInfo_Request", i[i.Client_Tagged_FrameInfo_Request = 1] = "Client_Tagged_FrameInfo_Request", i[i.Server_Unique_FrameInfo_Response = 2] = "Server_Unique_FrameInfo_Response", i[i.Server_Tagged_FrameInfo_Response = 3] = "Server_Tagged_FrameInfo_Response", i[i.Client_File_Request = 6] = "Client_File_Request", i[i.Server_File_Response = 7] = "Server_File_Response", i[i.Client_Unique_FrameCache = 10] = "Client_Unique_FrameCache", i[i.Client_Tagged_FrameCache = 11] = "Client_Tagged_FrameCache", i[i.Client_Unique_Frame_Loaded = 12] = "Client_Unique_Frame_Loaded", i[i.Client_Tagged_Frame_Loaded = 13] = "Client_Tagged_Frame_Loaded", i[i.Client_Unique_Frame_Subscribe = 14] = "Client_Unique_Frame_Subscribe", i[i.Client_Tagged_Frame_Subscribe = 15] = "Client_Tagged_Frame_Subscribe", i[i.Client_Unique_Frame_Unsubscribe = 16] = "Client_Unique_Frame_Unsubscribe", i[i.Client_Tagged_Frame_Unsubscribe = 17] = "Client_Tagged_Frame_Unsubscribe", i[i.Client_Unique_Value_Request = 18] = "Client_Unique_Value_Request", i[i.Client_Tagged_Value_Request = 19] = "Client_Tagged_Value_Request", i[i.Server_Unique_Value_Response = 20] = "Server_Unique_Value_Response", i[i.Server_Tagged_Value_Response = 21] = "Server_Tagged_Value_Response", i[i.Unique_Value_Update = 22] = "Unique_Value_Update", i[i.Tagged_Value_Update = 23] = "Tagged_Value_Update", i[i.Client_Unique_Signal_Request = 24] = "Client_Unique_Signal_Request", i[i.Client_Tagged_Signal_Request = 25] = "Client_Tagged_Signal_Request", i[i.Server_Unique_Signal_Response = 26] = "Server_Unique_Signal_Response", i[i.Server_Tagged_Signal_Response = 27] = "Server_Tagged_Signal_Response", i[i.Client_Unique_Signal_Notify = 28] = "Client_Unique_Signal_Notify", i[i.Client_Tagged_Signal_Notify = 29] = "Client_Tagged_Signal_Notify";
})(u || (u = {}));
class L {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsSignal(t, e) {
    return (e || new L()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsSignal(t, e) {
    return t.setPosition(t.position() + g), (e || new L()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  static startSignal(t) {
    t.startObject(1);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static endSignal(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), e;
  }
  static createSignal(t, e) {
    return L.startSignal(t), L.addId(t, e), L.endSignal(t);
  }
  unpack() {
    return new zt(this.id());
  }
  unpackTo(t) {
    t.id = this.id();
  }
}
class zt {
  constructor(t = null) {
    a(this, "id");
    this.id = t;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0;
    return L.createSignal(t, e);
  }
}
class N {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsTaggedFrameLoaded(t, e) {
    return (e || new N()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsTaggedFrameLoaded(t, e) {
    return t.setPosition(t.position() + g), (e || new N()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  tag(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  static startTaggedFrameLoaded(t) {
    t.startObject(2);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addTag(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static endTaggedFrameLoaded(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), e;
  }
  static createTaggedFrameLoaded(t, e, s) {
    return N.startTaggedFrameLoaded(t), N.addId(t, e), N.addTag(t, s), N.endTaggedFrameLoaded(t);
  }
  unpack() {
    return new pt(this.id(), this.tag());
  }
  unpackTo(t) {
    t.id = this.id(), t.tag = this.tag();
  }
}
class pt {
  constructor(t = null, e = null) {
    a(this, "id");
    a(this, "tag");
    this.id = t, this.tag = e;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = this.tag !== null ? t.createString(this.tag) : 0;
    return N.createTaggedFrameLoaded(t, e, s);
  }
}
class B {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsTaggedFrameSubscribe(t, e) {
    return (e || new B()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsTaggedFrameSubscribe(t, e) {
    return t.setPosition(t.position() + g), (e || new B()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  tag(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  static startTaggedFrameSubscribe(t) {
    t.startObject(2);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addTag(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static endTaggedFrameSubscribe(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), e;
  }
  static createTaggedFrameSubscribe(t, e, s) {
    return B.startTaggedFrameSubscribe(t), B.addId(t, e), B.addTag(t, s), B.endTaggedFrameSubscribe(t);
  }
  unpack() {
    return new It(this.id(), this.tag());
  }
  unpackTo(t) {
    t.id = this.id(), t.tag = this.tag();
  }
}
class It {
  constructor(t = null, e = null) {
    a(this, "id");
    a(this, "tag");
    this.id = t, this.tag = e;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = this.tag !== null ? t.createString(this.tag) : 0;
    return B.createTaggedFrameSubscribe(t, e, s);
  }
}
class S {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsTaggedSignalNotify(t, e) {
    return (e || new S()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsTaggedSignalNotify(t, e) {
    return t.setPosition(t.position() + g), (e || new S()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  frameId(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  tag(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  signalId(t) {
    const e = this.bb.__offset(this.bb_pos, 8);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  value(t) {
    const e = this.bb.__offset(this.bb_pos, 10);
    return e ? this.bb.readUint8(this.bb.__vector(this.bb_pos + e) + t) : 0;
  }
  valueLength() {
    const t = this.bb.__offset(this.bb_pos, 10);
    return t ? this.bb.__vector_len(this.bb_pos + t) : 0;
  }
  valueArray() {
    const t = this.bb.__offset(this.bb_pos, 10);
    return t ? new Uint8Array(this.bb.bytes().buffer, this.bb.bytes().byteOffset + this.bb.__vector(this.bb_pos + t), this.bb.__vector_len(this.bb_pos + t)) : null;
  }
  static startTaggedSignalNotify(t) {
    t.startObject(4);
  }
  static addFrameId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addTag(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static addSignalId(t, e) {
    t.addFieldOffset(2, e, 0);
  }
  static addValue(t, e) {
    t.addFieldOffset(3, e, 0);
  }
  static createValueVector(t, e) {
    t.startVector(1, e.length, 1);
    for (let s = e.length - 1; s >= 0; s--)
      t.addInt8(e[s]);
    return t.endVector();
  }
  static startValueVector(t, e) {
    t.startVector(1, e, 1);
  }
  static endTaggedSignalNotify(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), t.requiredField(e, 8), e;
  }
  static createTaggedSignalNotify(t, e, s, n, r) {
    return S.startTaggedSignalNotify(t), S.addFrameId(t, e), S.addTag(t, s), S.addSignalId(t, n), S.addValue(t, r), S.endTaggedSignalNotify(t);
  }
  unpack() {
    return new wt(this.frameId(), this.tag(), this.signalId(), this.bb.createScalarList(this.value.bind(this), this.valueLength()));
  }
  unpackTo(t) {
    t.frameId = this.frameId(), t.tag = this.tag(), t.signalId = this.signalId(), t.value = this.bb.createScalarList(this.value.bind(this), this.valueLength());
  }
}
class wt {
  constructor(t = null, e = null, s = null, n = []) {
    a(this, "frameId");
    a(this, "tag");
    a(this, "signalId");
    a(this, "value");
    this.frameId = t, this.tag = e, this.signalId = s, this.value = n;
  }
  pack(t) {
    const e = this.frameId !== null ? t.createString(this.frameId) : 0, s = this.tag !== null ? t.createString(this.tag) : 0, n = this.signalId !== null ? t.createString(this.signalId) : 0, r = S.createValueVector(t, this.value);
    return S.createTaggedSignalNotify(t, e, s, n, r);
  }
}
class E {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsTaggedSignalRequest(t, e) {
    return (e || new E()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsTaggedSignalRequest(t, e) {
    return t.setPosition(t.position() + g), (e || new E()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  tag(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  static startTaggedSignalRequest(t) {
    t.startObject(2);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addTag(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static endTaggedSignalRequest(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), e;
  }
  static createTaggedSignalRequest(t, e, s) {
    return E.startTaggedSignalRequest(t), E.addId(t, e), E.addTag(t, s), E.endTaggedSignalRequest(t);
  }
  unpack() {
    return new mt(this.id(), this.tag());
  }
  unpackTo(t) {
    t.id = this.id(), t.tag = this.tag();
  }
}
class mt {
  constructor(t = null, e = null) {
    a(this, "id");
    a(this, "tag");
    this.id = t, this.tag = e;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = this.tag !== null ? t.createString(this.tag) : 0;
    return E.createTaggedSignalRequest(t, e, s);
  }
}
class q {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsTaggedSignalResponse(t, e) {
    return (e || new q()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsTaggedSignalResponse(t, e) {
    return t.setPosition(t.position() + g), (e || new q()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  tag(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  signals(t, e) {
    const s = this.bb.__offset(this.bb_pos, 8);
    return s ? (e || new L()).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos + s) + t * 4), this.bb) : null;
  }
  signalsLength() {
    const t = this.bb.__offset(this.bb_pos, 8);
    return t ? this.bb.__vector_len(this.bb_pos + t) : 0;
  }
  static startTaggedSignalResponse(t) {
    t.startObject(3);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addTag(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static addSignals(t, e) {
    t.addFieldOffset(2, e, 0);
  }
  static createSignalsVector(t, e) {
    t.startVector(4, e.length, 4);
    for (let s = e.length - 1; s >= 0; s--)
      t.addOffset(e[s]);
    return t.endVector();
  }
  static startSignalsVector(t, e) {
    t.startVector(4, e, 4);
  }
  static endTaggedSignalResponse(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), t.requiredField(e, 8), e;
  }
  static createTaggedSignalResponse(t, e, s, n) {
    return q.startTaggedSignalResponse(t), q.addId(t, e), q.addTag(t, s), q.addSignals(t, n), q.endTaggedSignalResponse(t);
  }
  unpack() {
    return new Dt(this.id(), this.tag(), this.bb.createObjList(this.signals.bind(this), this.signalsLength()));
  }
  unpackTo(t) {
    t.id = this.id(), t.tag = this.tag(), t.signals = this.bb.createObjList(this.signals.bind(this), this.signalsLength());
  }
}
class Dt {
  constructor(t = null, e = null, s = []) {
    a(this, "id");
    a(this, "tag");
    a(this, "signals");
    this.id = t, this.tag = e, this.signals = s;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = this.tag !== null ? t.createString(this.tag) : 0, n = q.createSignalsVector(t, t.createObjectOffsetList(this.signals));
    return q.createTaggedSignalResponse(t, e, s, n);
  }
}
class z {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsTaggedValueRequest(t, e) {
    return (e || new z()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsTaggedValueRequest(t, e) {
    return t.setPosition(t.position() + g), (e || new z()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  tag(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  static startTaggedValueRequest(t) {
    t.startObject(2);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addTag(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static endTaggedValueRequest(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), e;
  }
  static createTaggedValueRequest(t, e, s) {
    return z.startTaggedValueRequest(t), z.addId(t, e), z.addTag(t, s), z.endTaggedValueRequest(t);
  }
  unpack() {
    return new vt(this.id(), this.tag());
  }
  unpackTo(t) {
    t.id = this.id(), t.tag = this.tag();
  }
}
class vt {
  constructor(t = null, e = null) {
    a(this, "id");
    a(this, "tag");
    this.id = t, this.tag = e;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = this.tag !== null ? t.createString(this.tag) : 0;
    return z.createTaggedValueRequest(t, e, s);
  }
}
class m {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsValue(t, e) {
    return (e || new m()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsValue(t, e) {
    return t.setPosition(t.position() + g), (e || new m()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  value(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.readUint8(this.bb.__vector(this.bb_pos + e) + t) : 0;
  }
  valueLength() {
    const t = this.bb.__offset(this.bb_pos, 6);
    return t ? this.bb.__vector_len(this.bb_pos + t) : 0;
  }
  valueArray() {
    const t = this.bb.__offset(this.bb_pos, 6);
    return t ? new Uint8Array(this.bb.bytes().buffer, this.bb.bytes().byteOffset + this.bb.__vector(this.bb_pos + t), this.bb.__vector_len(this.bb_pos + t)) : null;
  }
  static startValue(t) {
    t.startObject(2);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addValue(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static createValueVector(t, e) {
    t.startVector(1, e.length, 1);
    for (let s = e.length - 1; s >= 0; s--)
      t.addInt8(e[s]);
    return t.endVector();
  }
  static startValueVector(t, e) {
    t.startVector(1, e, 1);
  }
  static endValue(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), e;
  }
  static createValue(t, e, s) {
    return m.startValue(t), m.addId(t, e), m.addValue(t, s), m.endValue(t);
  }
  unpack() {
    return new ht(this.id(), this.bb.createScalarList(this.value.bind(this), this.valueLength()));
  }
  unpackTo(t) {
    t.id = this.id(), t.value = this.bb.createScalarList(this.value.bind(this), this.valueLength());
  }
}
class ht {
  constructor(t = null, e = []) {
    a(this, "id");
    a(this, "value");
    this.id = t, this.value = e;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = m.createValueVector(t, this.value);
    return m.createValue(t, e, s);
  }
}
class U {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsTaggedValueResponse(t, e) {
    return (e || new U()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsTaggedValueResponse(t, e) {
    return t.setPosition(t.position() + g), (e || new U()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  tag(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  values(t, e) {
    const s = this.bb.__offset(this.bb_pos, 8);
    return s ? (e || new m()).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos + s) + t * 4), this.bb) : null;
  }
  valuesLength() {
    const t = this.bb.__offset(this.bb_pos, 8);
    return t ? this.bb.__vector_len(this.bb_pos + t) : 0;
  }
  static startTaggedValueResponse(t) {
    t.startObject(3);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addTag(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static addValues(t, e) {
    t.addFieldOffset(2, e, 0);
  }
  static createValuesVector(t, e) {
    t.startVector(4, e.length, 4);
    for (let s = e.length - 1; s >= 0; s--)
      t.addOffset(e[s]);
    return t.endVector();
  }
  static startValuesVector(t, e) {
    t.startVector(4, e, 4);
  }
  static endTaggedValueResponse(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), t.requiredField(e, 8), e;
  }
  static createTaggedValueResponse(t, e, s, n) {
    return U.startTaggedValueResponse(t), U.addId(t, e), U.addTag(t, s), U.addValues(t, n), U.endTaggedValueResponse(t);
  }
  unpack() {
    return new Gt(this.id(), this.tag(), this.bb.createObjList(this.values.bind(this), this.valuesLength()));
  }
  unpackTo(t) {
    t.id = this.id(), t.tag = this.tag(), t.values = this.bb.createObjList(this.values.bind(this), this.valuesLength());
  }
}
class Gt {
  constructor(t = null, e = null, s = []) {
    a(this, "id");
    a(this, "tag");
    a(this, "values");
    this.id = t, this.tag = e, this.values = s;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = this.tag !== null ? t.createString(this.tag) : 0, n = U.createValuesVector(t, t.createObjectOffsetList(this.values));
    return U.createTaggedValueResponse(t, e, s, n);
  }
}
class j {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsTaggedValueUpdate(t, e) {
    return (e || new j()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsTaggedValueUpdate(t, e) {
    return t.setPosition(t.position() + g), (e || new j()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  tag(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  value(t) {
    const e = this.bb.__offset(this.bb_pos, 8);
    return e ? (t || new m()).__init(this.bb.__indirect(this.bb_pos + e), this.bb) : null;
  }
  static startTaggedValueUpdate(t) {
    t.startObject(3);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addTag(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static addValue(t, e) {
    t.addFieldOffset(2, e, 0);
  }
  static endTaggedValueUpdate(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), t.requiredField(e, 8), e;
  }
  unpack() {
    return new Ft(this.id(), this.tag(), this.value() !== null ? this.value().unpack() : null);
  }
  unpackTo(t) {
    t.id = this.id(), t.tag = this.tag(), t.value = this.value() !== null ? this.value().unpack() : null;
  }
}
class Ft {
  constructor(t = null, e = null, s = null) {
    a(this, "id");
    a(this, "tag");
    a(this, "value");
    this.id = t, this.tag = e, this.value = s;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = this.tag !== null ? t.createString(this.tag) : 0, n = this.value !== null ? this.value.pack(t) : 0;
    return j.startTaggedValueUpdate(t), j.addId(t, e), j.addTag(t, s), j.addValue(t, n), j.endTaggedValueUpdate(t);
  }
}
class Y {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsUniqueFrameLoaded(t, e) {
    return (e || new Y()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsUniqueFrameLoaded(t, e) {
    return t.setPosition(t.position() + g), (e || new Y()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  static startUniqueFrameLoaded(t) {
    t.startObject(1);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static endUniqueFrameLoaded(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), e;
  }
  static createUniqueFrameLoaded(t, e) {
    return Y.startUniqueFrameLoaded(t), Y.addId(t, e), Y.endUniqueFrameLoaded(t);
  }
  unpack() {
    return new St(this.id());
  }
  unpackTo(t) {
    t.id = this.id();
  }
}
class St {
  constructor(t = null) {
    a(this, "id");
    this.id = t;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0;
    return Y.createUniqueFrameLoaded(t, e);
  }
}
class Z {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsUniqueFrameSubscribe(t, e) {
    return (e || new Z()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsUniqueFrameSubscribe(t, e) {
    return t.setPosition(t.position() + g), (e || new Z()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  static startUniqueFrameSubscribe(t) {
    t.startObject(1);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static endUniqueFrameSubscribe(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), e;
  }
  static createUniqueFrameSubscribe(t, e) {
    return Z.startUniqueFrameSubscribe(t), Z.addId(t, e), Z.endUniqueFrameSubscribe(t);
  }
  unpack() {
    return new qt(this.id());
  }
  unpackTo(t) {
    t.id = this.id();
  }
}
class qt {
  constructor(t = null) {
    a(this, "id");
    this.id = t;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0;
    return Z.createUniqueFrameSubscribe(t, e);
  }
}
class V {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsUniqueSignalNotify(t, e) {
    return (e || new V()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsUniqueSignalNotify(t, e) {
    return t.setPosition(t.position() + g), (e || new V()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  frameId(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  signalId(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  value(t) {
    const e = this.bb.__offset(this.bb_pos, 8);
    return e ? this.bb.readUint8(this.bb.__vector(this.bb_pos + e) + t) : 0;
  }
  valueLength() {
    const t = this.bb.__offset(this.bb_pos, 8);
    return t ? this.bb.__vector_len(this.bb_pos + t) : 0;
  }
  valueArray() {
    const t = this.bb.__offset(this.bb_pos, 8);
    return t ? new Uint8Array(this.bb.bytes().buffer, this.bb.bytes().byteOffset + this.bb.__vector(this.bb_pos + t), this.bb.__vector_len(this.bb_pos + t)) : null;
  }
  static startUniqueSignalNotify(t) {
    t.startObject(3);
  }
  static addFrameId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addSignalId(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static addValue(t, e) {
    t.addFieldOffset(2, e, 0);
  }
  static createValueVector(t, e) {
    t.startVector(1, e.length, 1);
    for (let s = e.length - 1; s >= 0; s--)
      t.addInt8(e[s]);
    return t.endVector();
  }
  static startValueVector(t, e) {
    t.startVector(1, e, 1);
  }
  static endUniqueSignalNotify(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), e;
  }
  static createUniqueSignalNotify(t, e, s, n) {
    return V.startUniqueSignalNotify(t), V.addFrameId(t, e), V.addSignalId(t, s), V.addValue(t, n), V.endUniqueSignalNotify(t);
  }
  unpack() {
    return new Ut(this.frameId(), this.signalId(), this.bb.createScalarList(this.value.bind(this), this.valueLength()));
  }
  unpackTo(t) {
    t.frameId = this.frameId(), t.signalId = this.signalId(), t.value = this.bb.createScalarList(this.value.bind(this), this.valueLength());
  }
}
class Ut {
  constructor(t = null, e = null, s = []) {
    a(this, "frameId");
    a(this, "signalId");
    a(this, "value");
    this.frameId = t, this.signalId = e, this.value = s;
  }
  pack(t) {
    const e = this.frameId !== null ? t.createString(this.frameId) : 0, s = this.signalId !== null ? t.createString(this.signalId) : 0, n = V.createValueVector(t, this.value);
    return V.createUniqueSignalNotify(t, e, s, n);
  }
}
class $ {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsUniqueSignalRequest(t, e) {
    return (e || new $()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsUniqueSignalRequest(t, e) {
    return t.setPosition(t.position() + g), (e || new $()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  static startUniqueSignalRequest(t) {
    t.startObject(1);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static endUniqueSignalRequest(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), e;
  }
  static createUniqueSignalRequest(t, e) {
    return $.startUniqueSignalRequest(t), $.addId(t, e), $.endUniqueSignalRequest(t);
  }
  unpack() {
    return new Vt(this.id());
  }
  unpackTo(t) {
    t.id = this.id();
  }
}
class Vt {
  constructor(t = null) {
    a(this, "id");
    this.id = t;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0;
    return $.createUniqueSignalRequest(t, e);
  }
}
class R {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsUniqueSignalResponse(t, e) {
    return (e || new R()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsUniqueSignalResponse(t, e) {
    return t.setPosition(t.position() + g), (e || new R()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  signals(t, e) {
    const s = this.bb.__offset(this.bb_pos, 6);
    return s ? (e || new L()).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos + s) + t * 4), this.bb) : null;
  }
  signalsLength() {
    const t = this.bb.__offset(this.bb_pos, 6);
    return t ? this.bb.__vector_len(this.bb_pos + t) : 0;
  }
  static startUniqueSignalResponse(t) {
    t.startObject(2);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addSignals(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static createSignalsVector(t, e) {
    t.startVector(4, e.length, 4);
    for (let s = e.length - 1; s >= 0; s--)
      t.addOffset(e[s]);
    return t.endVector();
  }
  static startSignalsVector(t, e) {
    t.startVector(4, e, 4);
  }
  static endUniqueSignalResponse(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), e;
  }
  static createUniqueSignalResponse(t, e, s) {
    return R.startUniqueSignalResponse(t), R.addId(t, e), R.addSignals(t, s), R.endUniqueSignalResponse(t);
  }
  unpack() {
    return new Ht(this.id(), this.bb.createObjList(this.signals.bind(this), this.signalsLength()));
  }
  unpackTo(t) {
    t.id = this.id(), t.signals = this.bb.createObjList(this.signals.bind(this), this.signalsLength());
  }
}
class Ht {
  constructor(t = null, e = []) {
    a(this, "id");
    a(this, "signals");
    this.id = t, this.signals = e;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = R.createSignalsVector(t, t.createObjectOffsetList(this.signals));
    return R.createUniqueSignalResponse(t, e, s);
  }
}
class X {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsUniqueValueRequest(t, e) {
    return (e || new X()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsUniqueValueRequest(t, e) {
    return t.setPosition(t.position() + g), (e || new X()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  static startUniqueValueRequest(t) {
    t.startObject(1);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static endUniqueValueRequest(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), e;
  }
  static createUniqueValueRequest(t, e) {
    return X.startUniqueValueRequest(t), X.addId(t, e), X.endUniqueValueRequest(t);
  }
  unpack() {
    return new Rt(this.id());
  }
  unpackTo(t) {
    t.id = this.id();
  }
}
class Rt {
  constructor(t = null) {
    a(this, "id");
    this.id = t;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0;
    return X.createUniqueValueRequest(t, e);
  }
}
class O {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsUniqueValueResponse(t, e) {
    return (e || new O()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsUniqueValueResponse(t, e) {
    return t.setPosition(t.position() + g), (e || new O()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  values(t, e) {
    const s = this.bb.__offset(this.bb_pos, 6);
    return s ? (e || new m()).__init(this.bb.__indirect(this.bb.__vector(this.bb_pos + s) + t * 4), this.bb) : null;
  }
  valuesLength() {
    const t = this.bb.__offset(this.bb_pos, 6);
    return t ? this.bb.__vector_len(this.bb_pos + t) : 0;
  }
  static startUniqueValueResponse(t) {
    t.startObject(2);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addValues(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static createValuesVector(t, e) {
    t.startVector(4, e.length, 4);
    for (let s = e.length - 1; s >= 0; s--)
      t.addOffset(e[s]);
    return t.endVector();
  }
  static startValuesVector(t, e) {
    t.startVector(4, e, 4);
  }
  static endUniqueValueResponse(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), e;
  }
  static createUniqueValueResponse(t, e, s) {
    return O.startUniqueValueResponse(t), O.addId(t, e), O.addValues(t, s), O.endUniqueValueResponse(t);
  }
  unpack() {
    return new Wt(this.id(), this.bb.createObjList(this.values.bind(this), this.valuesLength()));
  }
  unpackTo(t) {
    t.id = this.id(), t.values = this.bb.createObjList(this.values.bind(this), this.valuesLength());
  }
}
class Wt {
  constructor(t = null, e = []) {
    a(this, "id");
    a(this, "values");
    this.id = t, this.values = e;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = O.createValuesVector(t, t.createObjectOffsetList(this.values));
    return O.createUniqueValueResponse(t, e, s);
  }
}
class G {
  constructor() {
    a(this, "bb", null);
    a(this, "bb_pos", 0);
  }
  __init(t, e) {
    return this.bb_pos = t, this.bb = e, this;
  }
  static getRootAsUniqueValueUpdate(t, e) {
    return (e || new G()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  static getSizePrefixedRootAsUniqueValueUpdate(t, e) {
    return t.setPosition(t.position() + g), (e || new G()).__init(t.readInt32(t.position()) + t.position(), t);
  }
  id(t) {
    const e = this.bb.__offset(this.bb_pos, 4);
    return e ? this.bb.__string(this.bb_pos + e, t) : null;
  }
  value(t) {
    const e = this.bb.__offset(this.bb_pos, 6);
    return e ? (t || new m()).__init(this.bb.__indirect(this.bb_pos + e), this.bb) : null;
  }
  static startUniqueValueUpdate(t) {
    t.startObject(2);
  }
  static addId(t, e) {
    t.addFieldOffset(0, e, 0);
  }
  static addValue(t, e) {
    t.addFieldOffset(1, e, 0);
  }
  static endUniqueValueUpdate(t) {
    const e = t.endObject();
    return t.requiredField(e, 4), t.requiredField(e, 6), e;
  }
  unpack() {
    return new Ot(this.id(), this.value() !== null ? this.value().unpack() : null);
  }
  unpackTo(t) {
    t.id = this.id(), t.value = this.value() !== null ? this.value().unpack() : null;
  }
}
class Ot {
  constructor(t = null, e = null) {
    a(this, "id");
    a(this, "value");
    this.id = t, this.value = e;
  }
  pack(t) {
    const e = this.id !== null ? t.createString(this.id) : 0, s = this.value !== null ? this.value.pack(t) : 0;
    return G.startUniqueValueUpdate(t), G.addId(t, e), G.addValue(t, s), G.endUniqueValueUpdate(t);
  }
}
const Yt = 1e4;
var M, lt, b, J, K, D, T, h;
class Zt {
  constructor(t) {
    P(this, M);
    P(this, b);
    // 0 idle, 1 has connected, 2 keep reconnecting, 3 stopped
    P(this, J);
    P(this, K);
    P(this, D);
    P(this, T);
    P(this, h);
    p(this, T, t), p(this, b, 0), p(this, J, /* @__PURE__ */ new Set()), p(this, K, /* @__PURE__ */ new Set()), p(this, D, /* @__PURE__ */ new Set()), p(this, h, null);
  }
  async wait() {
    return new Promise((t, e) => {
      let s = this.on_connect(() => {
        s(), t();
      });
      this.start();
    });
  }
  on_message(t) {
    return o(this, D).add(t), () => o(this, D).delete(t);
  }
  on_connect(t) {
    return o(this, J).add(t), () => o(this, J).delete(t);
  }
  on_disconnect(t) {
    return o(this, K).add(t), () => o(this, K).delete(t);
  }
  // non-blocking (run is blocking in c++)
  // calling it again should not do anything
  start() {
    o(this, h) == null && o(this, b) !== 1 && o(this, b) !== 3 && (p(this, h, new WebSocket(o(this, T))), o(this, h).binaryType = "arraybuffer", o(this, h).onopen = () => {
      if (o(this, b) == 3)
        this.stop();
      else {
        p(this, b, 1);
        for (const t of o(this, J))
          t(o(this, T));
      }
    }, o(this, h).onclose = () => {
      if (o(this, b) === 1) {
        for (const t of o(this, K))
          t(o(this, T));
        p(this, b, 2), at(this, M, lt).call(this);
      }
    }, o(this, h).onerror = () => {
      o(this, b) !== 1 && o(this, b) !== 3 ? (p(this, b, 2), at(this, M, lt).call(this)) : o(this, b) === 3 && this.stop();
    }, o(this, h).onmessage = (t) => {
      if (o(this, D).size > 0) {
        const e = new Uint8Array(t.data);
        if (e.byteLength < 4)
          return;
        for (const s of o(this, D))
          s(o(this, T), e);
      }
    });
  }
  stop() {
    p(this, b, 3), o(this, h) != null && (o(this, h).close(), p(this, h, null));
  }
  restart() {
    p(this, b, 0), o(this, h) != null && (o(this, h).close(), p(this, h, null)), this.start();
  }
  publish(t) {
    return o(this, h) != null && o(this, b) == 1 ? (o(this, h).send(t.buffer), !0) : !1;
  }
  send(t, e) {
    return t === o(this, T) ? this.publish(e) : !1;
  }
}
M = new WeakSet(), lt = function() {
  o(this, h) != null && (o(this, h).close(), p(this, h, null)), setTimeout(() => this.start(), 1e3);
}, b = new WeakMap(), J = new WeakMap(), K = new WeakMap(), D = new WeakMap(), T = new WeakMap(), h = new WeakMap();
const v = (i) => {
  const t = new Uint8Array(4);
  return new DataView(t.buffer).setUint32(0, i, !0), t;
}, F = (i) => {
  const t = new Uint8Array(i.reduce((s, n) => s + n.length, 0));
  let e = 0;
  for (const s of i)
    t.set(s, e), e += s.length;
  return t;
}, kt = async (i, t, e) => {
  if (t.byteLength < 4)
    throw new Error("service_fetch requires a request with a 4-byte header");
  return new Promise((s, n) => {
    let r = () => {
    }, c = () => {
    };
    const l = setTimeout(() => {
      r(), c(), n("timed out, cancelled");
    }, Yt);
    c = i.on_connect(() => i.publish(t)), r = i.on_message((f, d) => {
      const _ = e(new DataView(d.buffer).getUint32(0, !0), d.slice(4));
      _ != null && (clearTimeout(l), r(), c(), s(_));
    }), i.publish(t);
  });
};
function $t(i) {
  return new Worker(
    "" + new URL("bundler.js", import.meta.url).href,
    {
      name: i == null ? void 0 : i.name
    }
  );
}
const Xt = async (i) => new Promise((t, e) => {
  const s = new $t();
  s.postMessage({
    type: "init",
    host: i.host,
    id: i.id,
    cdn_url: i.cdn_url,
    tag: i.tag
  }), s.addEventListener("message", async (n) => {
    n.data.ok ? t(await import(
      /* @vite-ignore */
      n.data.code
    )) : e(n.data.err), s.terminate();
  });
}), yt = (i) => i ? Array.from(i) : Array(), Jt = {
  server_value_response: u.Server_Tagged_Value_Response,
  make_value_request: (i, t) => {
    const e = new w(), s = new vt(i, t);
    return e.finish(s.pack(e)), F([v(u.Client_Tagged_Value_Request), e.asUint8Array()]);
  },
  eval_value_response: (i, t, e) => {
    try {
      const s = U.getRootAsTaggedValueResponse(new y(e));
      if (s.id() === i && t === s.tag())
        return s;
    } catch {
      return;
    }
  }
}, Kt = {
  value_update: u.Tagged_Value_Update,
  get_value_update: (i, t, e) => {
    try {
      const s = j.getRootAsTaggedValueUpdate(new y(e));
      if (s.id() === i && t === s.tag()) return s;
    } catch {
      return;
    }
  },
  make_value_update: (i, t, e, s) => {
    const n = new w(), r = new Ft(i, t);
    return r.value = new ht(e, yt(s)), n.finish(r.pack(n)), F([v(u.Tagged_Value_Update), n.asUint8Array()]);
  }
}, Qt = {
  signal_response: u.Server_Tagged_Signal_Response,
  make_signal_request: (i, t) => {
    const e = new w(), s = new mt(i, t);
    return e.finish(s.pack(e)), F([v(u.Client_Tagged_Signal_Request), e.asUint8Array()]);
  },
  make_signal_response: (i) => {
    try {
      return q.getRootAsTaggedSignalResponse(new y(i));
    } catch {
      return;
    }
  },
  make_signal_notify: (i, t, e, s) => {
    const n = new w(), r = yt(s), c = new wt(i, t, e, r);
    return n.finish(c.pack(n)), F([v(u.Client_Tagged_Signal_Notify), n.asUint8Array()]);
  }
}, Tt = {
  make_subscribe_msg: (i, t) => {
    const e = new w(), s = new It(i, t);
    return e.finish(s.pack(e)), F([v(u.Client_Tagged_Frame_Subscribe), e.asUint8Array()]);
  },
  make_loaded_msg: (i, t) => {
    const e = new w(), s = new pt(i, t);
    return e.finish(s.pack(e)), F([v(u.Client_Tagged_Frame_Loaded), e.asUint8Array()]);
  }
};
u.Server_Tagged_FrameInfo_Response;
const At = (i) => i ? Array.from(i) : Array(), Mt = {
  server_value_response: u.Server_Unique_Value_Response,
  make_value_request: (i, t) => {
    const e = new w(), s = new Rt(i);
    return e.finish(s.pack(e)), F([v(u.Client_Unique_Value_Request), e.asUint8Array()]);
  },
  eval_value_response: (i, t, e) => {
    try {
      const s = O.getRootAsUniqueValueResponse(new y(e));
      if (s.id() === i)
        return s;
    } catch {
      return;
    }
  }
}, te = {
  value_update: u.Unique_Value_Update,
  get_value_update: (i, t, e) => {
    try {
      const s = G.getRootAsUniqueValueUpdate(new y(e));
      if (s.id() === i) return s;
    } catch {
      return;
    }
  },
  make_value_update: (i, t, e, s) => {
    const n = new w(), r = new Ot(i);
    return r.value = new ht(e, At(s)), n.finish(r.pack(n)), F([v(u.Unique_Value_Update), n.asUint8Array()]);
  }
}, ee = {
  signal_response: u.Server_Unique_Signal_Response,
  make_signal_request: (i, t) => {
    const e = new w(), s = new Vt(i);
    return e.finish(s.pack(e)), F([v(u.Client_Unique_Signal_Request), e.asUint8Array()]);
  },
  make_signal_response: (i) => {
    try {
      return R.getRootAsUniqueSignalResponse(new y(i));
    } catch {
      return;
    }
  },
  make_signal_notify: (i, t, e, s) => {
    const n = new w(), r = At(s), c = new Ut(i, e, r);
    return n.finish(c.pack(n)), F([v(u.Client_Unique_Signal_Notify), n.asUint8Array()]);
  }
}, Lt = {
  make_subscribe_msg: (i, t) => {
    const e = new w(), s = new qt(i);
    return e.finish(s.pack(e)), F([v(u.Client_Unique_Frame_Subscribe), e.asUint8Array()]);
  },
  make_loaded_msg: (i, t) => {
    const e = new w(), s = new St(i);
    return e.finish(s.pack(e)), F([v(u.Client_Unique_Frame_Loaded), e.asUint8Array()]);
  }
};
u.Server_Unique_FrameInfo_Response;
const gt = (i) => {
}, se = (i) => new Uint8Array(i ?? []), ie = (i, t) => {
  if (i == null || t.length !== i.length)
    return !1;
  const e = t.length;
  for (let s = 0; s < e; s++)
    if (t[s] !== i[s])
      return !1;
  return !0;
}, jt = async ({ id: i, tag: t, service: e }) => {
  const s = t == null ? Mt : Jt, n = await kt(
    e,
    s.make_value_request(i, t),
    (d, _) => {
      if (d === s.server_value_response)
        return s.eval_value_response(i, t, _);
    }
  );
  if (n == null)
    throw new Error("Failed to fetch values for frame");
  const r = /* @__PURE__ */ new Map(), c = t == null ? te : Kt;
  let l = !1;
  const f = n.valuesLength();
  for (let d = 0; d < f; ++d) {
    const _ = n.values(d), H = _ == null ? void 0 : _.id();
    if (_ == null || H == null) continue;
    const I = ot(se(_.unpack().value));
    I.subscribe((C) => {
      C != null && !l && e.publish(c.make_value_update(i, t, H, C));
    }), r.set(H, I);
  }
  return e.on_message((d, _) => {
    var Q, tt;
    if (_.byteLength < 4)
      return;
    const H = new DataView(_.buffer, _.byteOffset, _.byteLength).getUint32(0, !0), I = _.slice(4), C = c.value_update;
    if (H === C) {
      const W = c.get_value_update(i, t, I), et = (Q = W == null ? void 0 : W.value()) == null ? void 0 : Q.id();
      if (W == null || et == null)
        return;
      const it = r.get(et);
      if (it == null)
        return;
      const ut = new Uint8Array(((tt = W.unpack().value) == null ? void 0 : tt.value) ?? []);
      ie(bt(it), ut) || (l = !0, it.set(ut), l = !1);
    }
  }), r;
}, Ct = async ({ id: i, tag: t, service: e }) => {
  const s = t == null ? ee : Qt, n = await kt(
    e,
    s.make_signal_request(i, t),
    (l, f) => {
      if (l === s.signal_response)
        return s.make_signal_response(f);
    }
  );
  if (n == null)
    throw new Error("Failed to fetch signals for frame");
  const r = /* @__PURE__ */ new Map(), c = n.signalsLength();
  for (let l = 0; l < c; ++l) {
    const f = n.signals(l), d = f == null ? void 0 : f.id();
    d != null && r.set(d, (_) => {
      e.publish(s.make_signal_notify(i, t, d, _));
    });
  }
  return r;
}, Pt = (i) => ((t, e, s) => {
  if (s == null)
    return i.get(t) ?? ot(e);
  const n = i.get(t);
  if (n != null) {
    let r = bt(n), c = s.decode(r);
    return {
      set: (l) => {
        c = l, r = s.encode(c), n.set(r);
      },
      subscribe: (l) => n.subscribe((f) => {
        f !== r && (r = f, c = s.decode(r)), l(c);
      }),
      update: (l) => {
        n.update((f) => (c = l(c), r = s.encode(c), r));
      }
    };
  }
  return ot(e);
}), xt = (i) => ((t, e) => {
  if (e == null)
    return i.get(t) ?? gt;
  const s = i.get(t);
  return s != null ? (n) => s(e(n)) : gt;
}), ne = async (i, t, e, s, n) => {
  const r = new Zt(i);
  await r.wait();
  const [c, l, { nil_xit_fn: f }] = await Promise.all([
    jt({ id: t, tag: e ?? null, service: r }),
    Ct({ id: t, tag: e ?? null, service: r }),
    Xt({ host: i, cdn_url: s, id: t, tag: e ?? null })
  ]), d = {
    svelte: () => import("./svelte/index.js"),
    "svelte/store": () => import("./svelte/store.js").then((I) => I.cH),
    "svelte/animate": () => import("./svelte/animate.js"),
    "svelte/reactivity": () => import("./svelte/reactivity.js"),
    "svelte/easing": () => import("./svelte/easing.js"),
    "svelte/events": () => import("./svelte/events.js"),
    "svelte/motion": () => import("./svelte/motion.js"),
    "svelte/transition": () => import("./svelte/transition.js"),
    // @ts-ignore
    "svelte/internal/disclose-version": () => import("./svelte/internal/disclose-version.js"),
    // @ts-ignore
    "svelte/internal/client": () => import("./svelte/internal/client.js").then((I) => I.i),
    "@nil-/xit": () => import("./index2.js")
    // TAG: DEV -- uncomment for local development
  }, _ = (I) => I in d ? d[I]() : import(
    /* @vite-ignore */
    I
  ), { action: H } = await f(_);
  return (I) => {
    const C = e == null ? Lt : Tt;
    r.publish(C.make_subscribe_msg(t, e ?? null)), r.publish(C.make_loaded_msg(t, e ?? null)), r.on_connect(() => r.publish(C.make_subscribe_msg(t, e ?? null)));
    const Q = /* @__PURE__ */ new Map();
    Q.set("nil.xit", {
      values: Pt(c),
      signals: xt(l),
      id: t,
      tag: e,
      load_frame_ui: n,
      load_frame_data: async (W, et) => ae({ frame: W, tag: et, service: r })
    });
    const { destroy: tt } = H(I, Q);
    return {
      destroy: () => {
        r.stop(), tt();
      }
    };
  };
}, ae = async ({
  frame: i,
  tag: t,
  service: e
}) => {
  const [s, n] = await Promise.all([
    jt({ id: i, tag: t ?? null, service: e }),
    Ct({ id: i, tag: t ?? null, service: e })
  ]), r = t == null ? Lt : Tt;
  e.publish(r.make_subscribe_msg(i, t ?? null)), e.publish(r.make_loaded_msg(i, t ?? null));
  const c = e.on_connect(() => e.publish(r.make_subscribe_msg(i, t ?? null)));
  return {
    values: Pt(s),
    signals: xt(n),
    unload: () => c()
  };
}, Nt = async ({
  host: i,
  cdn_url: t,
  frame: e,
  tag: s
}) => {
  const n = async (r, c) => {
    const l = await Nt({
      host: i,
      cdn_url: t,
      frame: r,
      tag: c
    });
    return (f) => l(f);
  };
  return ne(
    i,
    e,
    s,
    t,
    async (r, c) => n(r, c)
  );
}, le = async (i, t) => (await Nt(t))(i);
export {
  le as create_component,
  ae as create_frame,
  Nt as create_frame_ui
};
