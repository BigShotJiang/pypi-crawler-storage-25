import { cx as n } from "./svelte/store.js";
import "./svelte/internal/client.js";
const c = {
  encode: (e) => new TextEncoder().encode(JSON.stringify(e)),
  decode: (e) => JSON.parse(new TextDecoder().decode(e))
}, d = {
  encode: (e) => new Uint8Array([e ? 1 : 0]),
  decode: (e) => e[0] === 1
}, i = {
  encode: (e) => {
    const t = new ArrayBuffer(8);
    return new DataView(t).setBigInt64(0, BigInt(e), !0), new Uint8Array(t);
  },
  decode: (e) => {
    if (e.byteLength !== 8) throw new Error("Invalid buffer size for int64");
    return Number(new DataView(e.buffer, e.byteOffset, e.byteLength).getBigInt64(0, !0));
  }
}, f = {
  encode: (e) => {
    const t = new ArrayBuffer(8);
    return new DataView(t).setFloat64(0, e), new Uint8Array(t);
  },
  decode: (e) => new DataView(e.buffer, e.byteOffset, e.byteLength).getFloat64(0)
}, s = {
  encode: (e) => new TextEncoder().encode(e),
  decode: (e) => new TextDecoder().decode(e)
}, w = () => n("nil.xit");
export {
  d as codec_bool,
  f as codec_double,
  c as codec_json_from_string,
  i as codec_number,
  s as codec_string,
  w as xit
};
