"""
Approval workflow — gates agent actions that require human confirmation.

When the PolicyEngine resolves an autonomy level of APPROVAL (level 1),
the agent creates an ApprovalRequest here.  The request stays pending
until a human resolves it (approve / deny) or the configured timeout
elapses.

In v0.2+ the manager supports async wait/resume: the agent loop blocks
on an asyncio.Event until a human responds via CLI prompt or Cloud/Web
channel command.
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from typing import Any

from loguru import logger

from workpilot.config.schema import ApprovalConfig, AutonomyLevel, ChannelType

# ── Data model ──────────────────────────────────────────────────────────────


class ApprovalStatus(str, Enum):
    """Lifecycle states for an approval request."""

    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    TIMEOUT = "timeout"


@dataclass
class ApprovalRequest:
    """A single pending-approval record.

    Attributes
    ----------
    id:
        Unique request identifier (UUID4).
    tool_name:
        The tool that triggered the approval requirement.
    args:
        The arguments the tool would be called with.
    agent_name:
        The agent that requested the action.
    autonomy_level:
        The resolved autonomy level at creation time.
    channel:
        Channel through which the approval was requested.
    status:
        Current lifecycle state.
    created_at:
        UTC timestamp of request creation.
    resolved_at:
        UTC timestamp of resolution, or ``None`` if still pending.
    resolver:
        Identity of the human who resolved the request, or ``None``.
    """

    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    tool_name: str = ""
    args: dict[str, Any] = field(default_factory=dict)
    agent_name: str = ""
    autonomy_level: AutonomyLevel = AutonomyLevel.APPROVAL
    channel: ChannelType = ChannelType.CLI
    channel_id: str = ""
    score: int | None = None  # v2: risk score 0-10 or None
    reason: str = ""
    always_allow: bool = True  # whether "Always Allow" is available (from policy table)
    trigger: str = ""  # e.g. "📅 Scheduled: daily-cleanup", "" for interactive
    status: ApprovalStatus = ApprovalStatus.PENDING
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    resolved_at: datetime | None = None
    resolver: str | None = None
    action: str = ""  # "approve", "deny", "always" — set on resolution
    teams_activity_id: str | None = None  # Teams card ActivityId for cross-channel updates


# ── Manager ─────────────────────────────────────────────────────────────────


class ApprovalManager:
    """Manages the lifecycle of approval requests.

    Parameters
    ----------
    config:
        Approval workflow settings (timeout, escalation channels, etc.).
    """

    def __init__(self, config: ApprovalConfig) -> None:
        self._config = config
        self._pending: dict[str, ApprovalRequest] = {}
        self._waiters: dict[str, asyncio.Event] = {}
        self._resolved: dict[str, ApprovalRequest] = {}
        logger.debug(
            "ApprovalManager initialised — timeout={}s, auto_approve={}s, escalation={}",
            config.timeout_seconds,
            config.auto_approve_timeout,
            config.escalation_channels,
        )

    # ── Cleanup ───────────────────────────────────────────────────────

    def _cleanup_stale_resolved(self) -> None:
        """Remove resolved entries older than 60 seconds."""
        cutoff = datetime.now(UTC) - timedelta(seconds=60)
        stale = [
            rid
            for rid, req in self._resolved.items()
            if req.resolved_at and req.resolved_at < cutoff
        ]
        for rid in stale:
            del self._resolved[rid]

    # ── Create request ──────────────────────────────────────────────────

    async def request_approval(
        self,
        tool_name: str,
        args: dict[str, Any],
        agent_name: str,
        channel: ChannelType | None,
        channel_id: str = "",
        score: int | None = None,
        reason: str = "",
        always_allow: bool = True,
        trigger: str = "",
    ) -> ApprovalRequest:
        """Create an approval request and register it as pending.

        Parameters
        ----------
        tool_name:
            The tool requiring approval.
        args:
            Proposed tool call arguments.
        agent_name:
            Agent identity requesting the action.
        channel:
            Channel the approval prompt should be sent through.

        Returns
        -------
        ApprovalRequest
            The newly created (PENDING) request.
        """
        self._cleanup_stale_resolved()

        request = ApprovalRequest(
            tool_name=tool_name,
            args=args,
            agent_name=agent_name,
            autonomy_level=AutonomyLevel.APPROVAL,
            channel=ChannelType.of(channel, self._config.default_channel),
            channel_id=channel_id,
            score=score,
            reason=reason,
            always_allow=always_allow,
            trigger=trigger,
        )
        self._pending[request.id] = request
        self._waiters[request.id] = asyncio.Event()
        logger.info(
            "Approval requested: id={} tool={} agent={} channel={}",
            request.id,
            tool_name,
            agent_name,
            channel,
        )
        return request

    # ── Resolve ─────────────────────────────────────────────────────────

    def resolve(self, request_id: str, approved: bool, resolver: str, *, action: str = "") -> None:
        """Resolve a pending request.

        Parameters
        ----------
        request_id:
            The UUID of the request to resolve.
        approved:
            ``True`` to approve, ``False`` to deny.
        resolver:
            Identity of the human resolving the request.
        action:
            Original action verb ("approve", "deny", "always").

        Raises
        ------
        KeyError
            If ``request_id`` is not found among pending requests.
        ValueError
            If the request has already been resolved.
        """
        if request_id not in self._pending:
            raise KeyError(f"Approval request not found: {request_id}")

        request = self._pending[request_id]
        if request.status != ApprovalStatus.PENDING:
            raise ValueError(f"Request {request_id} already resolved as {request.status.value}")

        request.status = ApprovalStatus.APPROVED if approved else ApprovalStatus.DENIED
        request.resolved_at = datetime.now(UTC)
        request.resolver = resolver
        request.action = action or ("approve" if approved else "deny")

        logger.info(
            "Approval resolved: id={} status={} resolver={}",
            request_id,
            request.status.value,
            resolver,
        )

        # Move to resolved dict and signal the waiter
        del self._pending[request_id]
        self._resolved[request_id] = request
        waiter = self._waiters.pop(request_id, None)
        if waiter:
            waiter.set()

    # ── Async wait/resume ───────────────────────────────────────────────

    async def wait_for_resolution(
        self,
        request_id: str,
        auto_approve_timeout: int | None = None,
        reject_timeout: int | None = None,
    ) -> ApprovalRequest:
        """Block until the request is resolved or times out.

        Parameters
        ----------
        request_id:
            The UUID of the pending request.
        auto_approve_timeout:
            If set (Timeout-auto policy action), auto-approve after this
            many seconds.  ``None`` means this is not a Timeout-auto action.
        reject_timeout:
            If set (Human policy action), reject after this many seconds.
            ``None`` means wait indefinitely (null score — always wait for human).

        Returns
        -------
        ApprovalRequest
            The resolved request (status is APPROVED, DENIED, or TIMEOUT).
        """
        waiter = self._waiters.get(request_id)
        if waiter is None:
            # Already resolved (e.g. by CLI inline prompt)
            resolved = self._resolved.pop(request_id, None)
            if resolved:
                return resolved
            raise KeyError(f"No waiter for request {request_id}")

        if auto_approve_timeout is not None:
            timeout: float | None = auto_approve_timeout
        elif reject_timeout is not None:
            timeout = reject_timeout
        else:
            timeout = None  # wait forever (null score)

        try:
            await asyncio.wait_for(waiter.wait(), timeout=timeout)
        except TimeoutError:
            # Timeout — auto-approve for Timeout-auto, reject for Human
            request = self._pending.pop(request_id, None)
            self._waiters.pop(request_id, None)
            if request is None:
                # Race: resolved between wait and timeout
                resolved = self._resolved.pop(request_id, None)
                if resolved:
                    return resolved
                raise KeyError(f"Request {request_id} vanished during timeout")

            if auto_approve_timeout is not None:
                # Timeout-auto: auto-approve on timeout
                request.status = ApprovalStatus.APPROVED
                request.resolver = "auto-approve-timeout"
                request.action = "approve"
                logger.info(
                    "Approval auto-approved on timeout: id={} tool={}",
                    request_id,
                    request.tool_name,
                )
            else:
                # Human: reject on timeout
                request.status = ApprovalStatus.TIMEOUT
                request.resolver = "timeout"
                request.action = "deny"
                logger.warning(
                    "Approval timed out (rejected): id={} tool={}",
                    request_id,
                    request.tool_name,
                )
            request.resolved_at = datetime.now(UTC)
            return request

        # Resolved by human — pick up the result
        resolved = self._resolved.pop(request_id, None)
        self._waiters.pop(request_id, None)
        if resolved:
            return resolved
        raise KeyError(f"Resolved request {request_id} not found in results")

    # ── Partial wait (for escalation) ────────────────────────────────

    async def wait_partial(self, request_id: str, timeout: float) -> bool:
        """Wait up to *timeout* seconds for resolution without auto-resolving.

        Returns ``True`` if the request was resolved within the window,
        ``False`` if the timeout elapsed while still PENDING.  Unlike
        :meth:`wait_for_resolution`, this does **not** auto-approve or reject
        on timeout — the caller decides what to do next.
        """
        waiter = self._waiters.get(request_id)
        if waiter is None:
            # Already resolved (e.g. by CLI inline prompt) or unknown
            return request_id in self._resolved
        try:
            await asyncio.wait_for(waiter.wait(), timeout=timeout)
            return True
        except TimeoutError:
            return False

    def is_pending(self, request_id: str) -> bool:
        """Return ``True`` if *request_id* is still awaiting resolution."""
        return request_id in self._pending

    @property
    def escalation_channels(self) -> list[ChannelType]:
        """Static fallback channels from ``ApprovalConfig``."""
        return self._config.escalation_channels

    # ── Queries ─────────────────────────────────────────────────────────

    def get_request(self, request_id: str) -> ApprovalRequest | None:
        """Get a request by ID from pending or resolved."""
        return self._pending.get(request_id) or self._resolved.get(request_id)

    def get_pending(self) -> list[ApprovalRequest]:
        """Return all currently pending approval requests.

        Requests that have timed out are automatically marked before
        being filtered out.
        """
        # Sweep timeouts first
        for req_id in list(self._pending):
            self.check_timeout(req_id)

        return [req for req in self._pending.values() if req.status == ApprovalStatus.PENDING]

    def check_timeout(self, request_id: str) -> bool:
        """Check whether a pending request has exceeded its timeout.

        If timed out the request's status is updated to ``TIMEOUT`` and
        it is removed from the pending map.

        Parameters
        ----------
        request_id:
            The UUID of the request to check.

        Returns
        -------
        bool
            ``True`` if the request has timed out, ``False`` otherwise.
            Also returns ``False`` if the request is not found.
        """
        request = self._pending.get(request_id)
        if request is None:
            return False

        elapsed = (datetime.now(UTC) - request.created_at).total_seconds()
        if elapsed >= self._config.timeout_seconds:
            request.status = ApprovalStatus.TIMEOUT
            request.resolved_at = datetime.now(UTC)
            del self._pending[request_id]
            self._resolved[request_id] = request
            # Signal any waiter so wait_for_resolution unblocks
            waiter = self._waiters.pop(request_id, None)
            if waiter:
                waiter.set()
            logger.warning(
                "Approval request timed out: id={} tool={} elapsed={:.0f}s",
                request_id,
                request.tool_name,
                elapsed,
            )
            return True

        return False
