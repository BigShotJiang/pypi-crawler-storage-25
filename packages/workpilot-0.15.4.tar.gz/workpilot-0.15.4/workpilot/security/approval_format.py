"""
Channel-specific approval prompt formatters.

Each formatter renders an approval request for a specific channel type:
- CLI:   rich text prompt with ANSI colour
- Cloud: structured JSON for web chat clients
- Teams: Bot Framework Activity with Adaptive Card

Shared helpers:
- ``risk_level()``      — score → (label, web_color, cli_ansi)
- ``action_preview()``  — tool+args → human-readable one-liner
- ``trigger_context()`` — metadata → trigger line with emoji (or empty)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from workpilot.config.schema import ChannelType

# ── Helpers ────────────────────────────────────────────────────────────────────

# (max_score_inclusive, label, web_color, cli_ansi)
_RISK_LEVELS: list[tuple[int | None, str, str, str]] = [
    (2, "low", "#22c55e", "\033[32m"),
    (4, "medium", "#eab308", "\033[33m"),
    (6, "elevated", "#f59e0b", "\033[33m"),
    (8, "high", "#ef4444", "\033[31m"),
    (10, "critical", "#dc2626", "\033[35m"),
]
_UNKNOWN_LEVEL = ("unknown", "#a855f7", "\033[35m")


def risk_level(score: int | None) -> tuple[str, str, str]:
    """Map a numeric risk score to ``(label, web_color, cli_ansi)``.

    >>> risk_level(None)
    ('unknown', '#a855f7', '\\033[35m')
    >>> risk_level(3)[0]
    'medium'
    """
    if score is None:
        return _UNKNOWN_LEVEL
    for max_score, label, web_color, cli_ansi in _RISK_LEVELS:
        if max_score is not None and score <= max_score:
            return label, web_color, cli_ansi
    return _UNKNOWN_LEVEL  # out-of-range fallback


_PREVIEW_EXTRACTORS: dict[str, Any] = {
    "shell": lambda a: a.get("command", ""),
    "write_file": lambda a: f"Write \u2192 {a.get('path', '?')}",
    "edit_file": lambda a: f"Edit \u2192 {a.get('path', '?')}",
    "read_file": lambda a: f"Read \u2192 {a.get('path', '?')}",
    "http_request": lambda a: f"{a.get('method', 'GET')} {a.get('url', '?')}",
    "git": lambda a: f"git {a.get('subcommand', '')} {a.get('args', '')}".strip(),
    "web_search": lambda a: f"Search: {a.get('query', '?')}",
    "web_fetch": lambda a: f"Fetch: {a.get('url', '?')}",
    "spawn": lambda a: f"Spawn agent: {a.get('agent', a.get('agent_name', '?'))}",
}


# Keys likely to contain human-readable content (preferred for preview)
_PREVIEW_PREFERRED_KEYS = (
    "message",
    "content",
    "body",
    "text",
    "query",
    "prompt",
    "command",
    "url",
    "path",
)
# Keys likely to contain IDs (skip for preview)
_PREVIEW_SKIP_KEYS = (
    "id",
    "conversation_id",
    "conversationId",
    "channel_id",
    "thread_id",
    "session_id",
)


def action_preview(tool_name: str, args: dict[str, Any]) -> str:
    """Extract a human-readable action summary from *tool_name* and *args*.

    Returns a single line, max 120 chars, newlines replaced with spaces.
    """
    extractor = _PREVIEW_EXTRACTORS.get(tool_name)
    if extractor:
        raw = str(extractor(args))
    elif args:
        # Prefer meaningful keys (message, content, etc.) over IDs
        raw = ""
        for key in _PREVIEW_PREFERRED_KEYS:
            if key in args and args[key]:
                raw = str(args[key])
                break
        if not raw:
            # Fall back to first non-ID value
            for k, v in args.items():
                if k.lower() not in _PREVIEW_SKIP_KEYS and v:
                    raw = str(v)
                    break
        if not raw:
            raw = str(next(iter(args.values())))
    else:
        raw = tool_name
    raw = raw.replace("\n", " ").replace("\r", "")
    return raw[:120] + ("..." if len(raw) > 120 else "")


_TRIGGER_MAP: dict[str, tuple[str, str]] = {
    "cron": ("\U0001f4c5", "Scheduled"),  # 📅
    "heartbeat": ("\U0001f493", "Heartbeat"),  # 💓
    "subagent": ("\U0001f916", "Sub-agent"),  # 🤖
}


def trigger_context(metadata: dict[str, Any]) -> str:
    """Derive a trigger line (with emoji) from *metadata*.

    Returns an empty string for interactive sources.

    >>> trigger_context({"source": "cron", "job_name": "daily-cleanup"})
    '📅 Scheduled: daily-cleanup'
    >>> trigger_context({"source": "cloud_teams"})
    ''
    """
    source = metadata.get("source", "")
    entry = _TRIGGER_MAP.get(source)
    if not entry:
        return ""
    emoji, label = entry
    if source == "cron":
        job_name = metadata.get("job_name", "")
        return f"{emoji} {label}: {job_name}" if job_name else f"{emoji} {label}"
    if source == "subagent":
        agent = metadata.get("agent_name", "")
        return f"{emoji} {label}: {agent}" if agent else f"{emoji} {label}"
    return f"{emoji} {label}"


# ── Formatters ─────────────────────────────────────────────────────────────────


class ApprovalFormatter(ABC):
    """Abstract base for channel-specific approval formatters."""

    @abstractmethod
    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> str | dict[str, Any]:
        """Format an approval request for display.

        Parameters
        ----------
        request:
            The ``ApprovalRequest`` object.
        classify_result:
            The ``RiskScore`` from the Risk Scorer (has ``.score`` and ``.reason``).
        auto_timeout:
            Seconds until auto-approve (Timeout-auto action). ``None`` = not auto-approve.
        reject_timeout:
            Seconds until auto-reject (Human action). ``None`` = wait indefinitely.

        Returns
        -------
        str | dict
            Formatted content: plain text for CLI, dict for structured channels.
        """


class CLIApprovalFormatter(ApprovalFormatter):
    """Rich text prompt for CLI with risk-coloured header and action preview."""

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> str:
        score = classify_result.score
        level, _, cli_ansi = risk_level(score)
        reset = "\033[0m"
        bold = "\033[1m"

        score_str = f"{score} / 10" if score is not None else "? / 10"
        preview = action_preview(request.tool_name, request.args)
        trigger = getattr(request, "trigger", "")
        always_allow = getattr(request, "always_allow", True)

        args_lines = "\n".join(f"    {k} = {v!r}" for k, v in list(request.args.items())[:8])

        if auto_timeout is not None:
            timeout_line = f"  Proceeding in {auto_timeout}s unless you deny..."
        elif reject_timeout is not None:
            timeout_line = f"  Waiting for your decision ({reject_timeout}s remaining)"
        else:
            timeout_line = "  Waiting for your decision"

        always_hint = "  [a]lways" if always_allow else ""
        trigger_line = f"  {trigger}\n\n" if trigger else ""

        separator = "\u2500" * 62
        return (
            f"\n{bold}\u26a0  APPROVAL REQUIRED{reset}"
            f"                              {cli_ansi}{level.upper()} {score_str}{reset}\n"
            f"{separator}\n"
            f"  {bold}{preview}{reset}\n\n"
            f"  {classify_result.reason}\n\n"
            f"{trigger_line}"
            f"  Tool:    {request.tool_name}\n"
            f"  Agent:   {request.agent_name}\n"
            f"  Args:\n{args_lines}\n\n"
            f"{timeout_line}\n\n"
            f"  [y]es  [n]o{always_hint}  > "
        )


# ── Shared Adaptive Card builder ───────────────────────────────────────────────

_AC_COLORS: dict[str, str] = {
    "unknown": "Accent",
    "low": "Good",
    "medium": "Warning",
    "elevated": "Warning",
    "high": "Attention",
    "critical": "Attention",
}


_OUTCOME_LABELS: dict[str, str] = {
    "approved": "\u2705 Approved",
    "approved_always": "\u2705 Approved (Always)",
    "approved_timeout": "\u2705 Approved (Auto)",
    "denied": "\u274c Denied",
    "denied_timeout": "\u274c Denied (Timeout)",
    "timeout": "\u274c Denied (Timeout)",
    "resolved": "\u2611 Resolved",
}
_OUTCOME_AC_COLORS: dict[str, str] = {
    "approved": "Good",
    "approved_always": "Good",
    "approved_timeout": "Good",
    "denied": "Attention",
    "denied_timeout": "Warning",
    "timeout": "Warning",
    "resolved": "Default",
}


def build_resolved_card(
    *,
    tool_name: str,
    action_preview: str,
    score: float | int | None = None,
    outcome: str = "approved",
    agent_name: str = "",
    reason: str = "",
) -> dict[str, Any]:
    """Public helper — build a resolved Adaptive Card for cross-channel updates."""
    return _build_resolved_card(
        {
            "tool_name": tool_name,
            "action_preview": action_preview,
            "score": score,
            "agent_name": agent_name,
            "reason": reason,
        },
        outcome,
    )


def _build_resolved_card(fields: dict[str, Any], outcome: str) -> dict[str, Any]:
    """Build a resolved Adaptive Card — read-only, no actions.

    Single source of truth for resolved card structure.  Used by:
    - Python: embedded in Action.Submit data → Gateway uses directly
    - JS client: ``_buildResolvedCard()`` mirrors this structure
    """
    label = _OUTCOME_LABELS.get(outcome, _OUTCOME_LABELS["resolved"])
    color = _OUTCOME_AC_COLORS.get(outcome, "Default")
    score = fields.get("score")
    score_str = f"{score} / 10" if score is not None else "?"

    body: list[dict[str, Any]] = [
        # Outcome header — no risk badge (decision is done, risk level is noise)
        {
            "type": "TextBlock",
            "text": f"{label} \u00b7 {fields.get('tool_name', '')}",
            "weight": "Bolder",
            "color": color,
            "wrap": True,
        },
        {
            "type": "Container",
            "style": "emphasis",
            "spacing": "Small",
            "items": [
                {
                    "type": "TextBlock",
                    "text": fields.get("action_preview") or fields.get("tool_name", ""),
                    "fontType": "Monospace",
                    "wrap": True,
                }
            ],
        },
    ]

    reason = fields.get("reason")
    if reason:
        body.append(
            {
                "type": "TextBlock",
                "text": reason,
                "wrap": True,
                "spacing": "Small",
                "isSubtle": True,
            }
        )

    trigger = fields.get("trigger")
    if trigger:
        body.append(
            {
                "type": "TextBlock",
                "text": trigger,
                "size": "Small",
                "isSubtle": True,
                "spacing": "Small",
                "wrap": True,
            }
        )

    body.append(
        {
            "type": "FactSet",
            "spacing": "Medium",
            "facts": [
                {"title": "Tool", "value": fields.get("tool_name", "")},
                {"title": "Agent", "value": fields.get("agent_name", "")},
                {"title": "Score", "value": score_str},
            ],
        }
    )

    return {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "type": "AdaptiveCard",
        "version": "1.4",
        "body": body,
    }


def _build_adaptive_card(
    request: Any,
    classify_result: Any,
    auto_timeout: int | None = None,
    reject_timeout: int | None = None,
) -> dict[str, Any]:
    """Build an Adaptive Card v1.4 content dict for an approval request.

    Used by all non-CLI formatters.  Teams wraps this in a Bot Framework
    Activity; Web UI / WebChat renders via the ``adaptivecards`` JS SDK.
    """
    score = classify_result.score
    level, _, _ = risk_level(score)
    ac_color = _AC_COLORS.get(level, "Default")
    preview = action_preview(request.tool_name, request.args)
    trigger = getattr(request, "trigger", "")
    always_allow = getattr(request, "always_allow", True)
    score_str = f"{score} / 10" if score is not None else "?"

    # ── Body ──────────────────────────────────────────────────────────
    body: list[dict[str, Any]] = [
        # Header: title + risk badge
        {
            "type": "ColumnSet",
            "columns": [
                {
                    "type": "Column",
                    "width": "stretch",
                    "items": [
                        {
                            "type": "TextBlock",
                            "text": "\u26a0 Approval Required",
                            "weight": "Bolder",
                            "size": "Medium",
                            "wrap": True,
                        }
                    ],
                },
                {
                    "type": "Column",
                    "width": "auto",
                    "verticalContentAlignment": "Center",
                    "items": [
                        {
                            "type": "TextBlock",
                            "text": level.upper(),
                            "weight": "Bolder",
                            "size": "Small",
                            "color": ac_color,
                        }
                    ],
                },
            ],
        },
        # Action preview
        {
            "type": "Container",
            "style": "emphasis",
            "spacing": "Small",
            "items": [
                {
                    "type": "TextBlock",
                    "text": preview,
                    "fontType": "Monospace",
                    "wrap": True,
                    "weight": "Bolder",
                }
            ],
        },
        # Risk explanation
        {
            "type": "TextBlock",
            "text": classify_result.reason,
            "wrap": True,
            "spacing": "Small",
        },
    ]

    if trigger:
        body.append(
            {
                "type": "TextBlock",
                "text": trigger,
                "size": "Small",
                "isSubtle": True,
                "spacing": "Small",
                "wrap": True,
            }
        )

    body.append(
        {
            "type": "FactSet",
            "spacing": "Medium",
            "facts": [
                {"title": "Tool", "value": request.tool_name},
                {"title": "Agent", "value": request.agent_name},
                {"title": "Score", "value": score_str},
            ],
        }
    )

    if auto_timeout is not None:
        body.append(
            {
                "type": "TextBlock",
                "text": f"\u23f1 Proceeding in {auto_timeout}s unless you deny...",
                "size": "Small",
                "isSubtle": True,
                "spacing": "Small",
                "wrap": True,
            }
        )
    elif reject_timeout is not None:
        body.append(
            {
                "type": "TextBlock",
                "text": f"\u23f1 Waiting for your decision ({reject_timeout}s remaining)",
                "size": "Small",
                "isSubtle": True,
                "spacing": "Small",
                "wrap": True,
            }
        )

    body.append(
        {
            "type": "TextBlock",
            "text": "Or reply **yes** / **no** / **always**",
            "size": "Small",
            "isSubtle": True,
            "spacing": "None",
            "wrap": True,
        }
    )

    # ── Actions ───────────────────────────────────────────────────────
    # Each button carries a pre-built resolved card JSON so the Gateway
    # can PUT it directly without building its own card.
    card_fields = {
        "tool_name": request.tool_name,
        "action_preview": preview,
        "reason": classify_result.reason,
        "score": score,
        "risk_level": level,
        "agent_name": request.agent_name,
        "trigger": trigger,
    }

    def _submit_data(action_label: str, outcome: str) -> dict[str, Any]:
        return {
            "approval_action": action_label,
            "approval_request_id": request.id,
            "resolved_card": _build_resolved_card(card_fields, outcome),
        }

    actions: list[dict[str, Any]] = [
        {
            "type": "Action.Submit",
            "title": "\u2713 Approve",
            "style": "positive",
            "data": _submit_data("approve", "approved"),
        },
        {
            "type": "Action.Submit",
            "title": "\u2717 Deny",
            "style": "destructive",
            "data": _submit_data("deny", "denied"),
        },
    ]

    if always_allow:
        actions.append(
            {
                "type": "Action.Submit",
                "title": "Always Allow",
                "data": _submit_data("always", "approved_always"),
            }
        )

    return {
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "type": "AdaptiveCard",
        "version": "1.4",
        "body": body,
        "actions": actions,
    }


# ── Formatters (non-CLI) ──────────────────────────────────────────────────────


class CloudApprovalFormatter(ApprovalFormatter):
    """Structured JSON for Web UI / WebChat clients.

    Includes an ``adaptive_card`` field containing the Adaptive Card v1.4
    content.  Web clients render this via the ``adaptivecards`` JS SDK.
    Flat fields (``tool_name``, ``score``, etc.) are kept for backward
    compatibility and session persistence.
    """

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> dict[str, Any]:
        score = classify_result.score
        level, web_color, _ = risk_level(score)
        args_summary = {k: str(v)[:200] for k, v in list(request.args.items())[:10]}
        return {
            "type": "approval_request",
            "request_id": request.id,
            "tool_name": request.tool_name,
            "action_preview": action_preview(request.tool_name, request.args),
            "risk_level": level,
            "risk_color": web_color,
            "args": args_summary,
            "score": score,
            "reason": classify_result.reason,
            "agent_name": request.agent_name,
            "trigger": getattr(request, "trigger", ""),
            "auto_timeout": auto_timeout,
            "reject_timeout": reject_timeout,
            "always_allow": getattr(request, "always_allow", True),
            "adaptive_card": _build_adaptive_card(
                request, classify_result, auto_timeout, reject_timeout
            ),
        }


class TeamsApprovalFormatter(ApprovalFormatter):
    """Bot Framework Activity with Adaptive Card for Teams.

    Produces a complete ``{"type": "message", "attachments": [...]}`` dict
    that the Cloud Gateway passes through unchanged via ``TryParseActivity``
    Case 1 (``type=message`` with ``attachments`` array).
    """

    def format_request(
        self,
        request: Any,
        classify_result: Any,
        auto_timeout: int | None = None,
        *,
        reject_timeout: int | None = None,
    ) -> dict[str, Any]:
        card = _build_adaptive_card(request, classify_result, auto_timeout, reject_timeout)
        return {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": card,
                }
            ],
        }


def get_approval_formatter(
    channel_name: ChannelType,
    push_target: str | None = None,
) -> ApprovalFormatter:
    """Factory — return the appropriate formatter for a channel.

    Parameters
    ----------
    channel_name:
        The target channel type.
    push_target:
        For cloud channels, ``"teams"`` selects the Teams Activity formatter.
    """
    if channel_name == ChannelType.CLI:
        return CLIApprovalFormatter()
    if push_target == "teams":
        return TeamsApprovalFormatter()
    return CloudApprovalFormatter()
