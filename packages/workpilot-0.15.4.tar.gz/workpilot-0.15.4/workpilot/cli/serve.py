"""workpilot serve — web server command and PID management helpers."""

from __future__ import annotations

import asyncio
import json as _json
import os
import socket
import subprocess
from pathlib import Path

import typer
from rich.panel import Panel

from workpilot import __version__
from workpilot.runtime import Runtime

# ── Web server PID helpers ────────────────────────────────────────────────────


def _web_pid_file() -> Path:
    from workpilot.utils.helpers import get_data_dir

    data_dir = get_data_dir()
    new_path = data_dir / "web.pid"
    old_path = data_dir / "gateway.pid"
    # Migrate legacy pid file
    if old_path.exists() and not new_path.exists():
        try:
            old_path.rename(new_path)
        except OSError:
            pass
    return new_path


def _try_unlink(path: Path) -> None:
    """Remove *path* ignoring FileNotFoundError and PermissionError/OSError.

    plain unlink(missing_ok=True) still raises on PermissionError (e.g. a
    locked pid file held by antivirus), which would bubble up and block
    web server startup or the single-instance check.
    """
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def _is_port_listening(port: int) -> bool:
    """Return True if *port* is currently bound on localhost.

    Uses socket.create_connection so both IPv4 (127.0.0.1) and IPv6 (::1)
    listeners are detected — create_connection iterates all resolved addresses
    for "localhost" and succeeds as soon as any of them connect.
    """
    try:
        with socket.create_connection(("localhost", port), timeout=1.0):
            return True
    except OSError:
        return False


def _check_web_running() -> tuple[int, int] | None:
    """Return (pid, port) if a web server instance is running, else None.

    Uses port-listening check as the primary liveness signal — this is
    cross-platform reliable and avoids Windows PID-reuse false positives
    that made stale pid files block startup permanently.
    """
    pid_file = _web_pid_file()
    if not pid_file.exists():
        return None
    try:
        data = _json.loads(pid_file.read_text(encoding="utf-8"))
        pid: int = int(data["pid"])
        port: int = int(data["port"])
    except Exception:
        _try_unlink(pid_file)
        return None

    # Sanity-check parsed values before using them in os.kill / socket calls.
    # os.kill(-1, 0) on POSIX signals all processes; negative/zero ports and
    # ports > 65535 are invalid and create_connection would raise immediately.
    if not (pid >= 1 and 1 <= port <= 65535):
        _try_unlink(pid_file)
        return None

    # Primary check: is anything listening on the recorded port?
    if not _is_port_listening(port):
        _try_unlink(pid_file)
        return None

    # Port is occupied — verify the PID is still alive.
    # On Windows, os.kill(pid, 0) is unreliable: it can raise PermissionError
    # for both "process exists but owned by another user" and "process doesn't
    # exist" (PID-reuse). So we only trust ProcessLookupError (definitive no)
    # and treat everything else as "probably ours" — if someone else stole
    # our port, the web server startup will fail with a clear bind-error anyway.
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        # Process definitely gone — port is taken by something else
        _try_unlink(pid_file)
        return None
    except (PermissionError, OSError):
        if os.name == "nt":
            # On Windows, verify process existence via tasklist
            try:
                result = subprocess.run(
                    ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if "python" not in result.stdout.lower():
                    _try_unlink(pid_file)
                    return None
            except Exception:
                # tasklist failed — don't block startup
                _try_unlink(pid_file)
                return None

    return pid, port


def _write_web_pid(pid: int, port: int) -> None:
    _web_pid_file().write_text(_json.dumps({"pid": pid, "port": port}), encoding="utf-8")


def _remove_web_pid() -> None:
    _try_unlink(_web_pid_file())


# ── serve command ─────────────────────────────────────────────────────────────


def serve(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
    host: str | None = typer.Option(None, "--host", help="Override bind host"),
    port: int | None = typer.Option(None, "--port", help="Override bind port"),
) -> None:
    """Start the multi-channel web server (FastAPI + uvicorn). Alias: s"""
    from workpilot.cli.commands import _load_config_safe, console

    try:
        from workpilot.web.server import WebServer  # noqa: F401
    except ImportError:
        console.print(
            "[red]Error:[/red] FastAPI and uvicorn are required for the web server.\n"
            "  Install with: [bold]pip install fastapi uvicorn[/bold]"
        )
        raise typer.Exit(1)

    # Single-instance guard
    running = _check_web_running()
    if running:
        existing_pid, existing_port = running
        console.print(
            Panel(
                f"[yellow]Web server already running[/yellow]\n\n"
                f"  PID  : [bold]{existing_pid}[/bold]\n"
                f"  Port : [bold]{existing_port}[/bold]\n"
                f"  URL  : [cyan]http://localhost:{existing_port}[/cyan]\n\n"
                f"To stop it: [bold]kill {existing_pid}[/bold]",
                title="Already Running",
                border_style="yellow",
            )
        )
        raise typer.Exit(1)

    with console.status("[bold cyan]Loading configuration\u2026"):
        cfg = _load_config_safe(config, profile)
    web_cfg = cfg.channels.web

    # Allow CLI overrides for host / port
    if host is not None:
        web_cfg.host = host
    if port is not None:
        web_cfg.port = port

    with console.status("[bold cyan]Initializing runtime\u2026"):
        rt = Runtime(cfg)

    _pid = os.getpid()

    # Solid block W-chevron (from logo.svg) + gradient text below
    # 7-stop gradient: purple → blue → green
    from rich.text import Text

    F = "\u2588"  # full block

    C1 = "bold #D2A8FF"  # purple (far left)
    C2 = "bold #BEB0FF"  # light purple
    C3 = "bold #A9BAFF"  # purple-blue
    C4 = "bold #79C0FF"  # blue (center)
    C5 = "bold #6DCAAA"  # blue-green
    C6 = "bold #5ECE7A"  # light green
    C7 = "bold #56D364"  # green (far right)

    # Connected W: center peak + 4 strokes, 5 rows, 20 chars wide
    # fmt: off
    _ROWS: list[list[tuple[str, str]]] = [
        [(" "*9, ""),       (F*2, C4),                             (" "*9, "")],
        [(F*2, C1),         (" "*6, ""), (F*4, C4),                (" "*6, ""), (F*2, C7)],
        [(" "+F*2, C1),     (" "*4, ""), (F*2, C3), ("  ", ""), (F*2, C5), (" "*4, ""), (F*2+" ", C7)],
        [(" "*2+F*2, C2),   ("  ", ""),  (F*2, C3), (" "*4, ""),  (F*2, C5), ("  ", ""),  (F*2+" "*2, C6)],
        [(" "*3+F*4, C2),   (" "*6, ""),                           (F*4+" "*3, C6)],
    ]
    # fmt: on

    # Gradient text: per-letter color purple → blue → green
    _LETTERS = [
        ("W", "#D2A8FF"), ("o", "#C3ADFF"), ("r", "#A9B6FF"), ("k", "#8FBEFF"),
        ("P", "#79C0FF"), ("i", "#6DC8B2"), ("l", "#62CE82"), ("o", "#56D364"),
        ("t", "#56D364"),
    ]  # fmt: skip

    logo = Text()
    logo.append(" " * 10 + "\u2726\n", style=C4)
    for parts in _ROWS:
        for text, style in parts:
            logo.append(text, style=style)
        logo.append("\n")
    logo.append("\n   ")
    for ch, color in _LETTERS:
        logo.append(ch, style=f"bold {color}")
        logo.append(" ")
    url = f"http://{web_cfg.host}:{web_cfg.port}"
    from rich.text import Text as _Text

    status_line = _Text.from_markup(
        f"\n\n  [bold]v{__version__}[/bold]  [dim]|[/dim]  "
        f"[green]\u25cf[/green] Listening on [bold cyan]{url}[/bold cyan]"
    )
    console.print(
        Panel(
            logo + status_line,
            border_style="cyan",
            padding=(1, 2),
        )
    )

    # Ask whether to open browser BEFORE starting the server (so the prompt
    # doesn't conflict with uvicorn log output).
    def _browse_url(host: str, port: int) -> str:
        """Build a browser-safe URL, handling all-interfaces and IPv6."""
        h = "localhost" if host in ("0.0.0.0", "::", "") else host
        if ":" in h and not h.startswith("["):
            h = f"[{h}]"  # bracket IPv6 literals
        return f"http://{h}:{port}" if port else f"http://{h}"

    def _on_started(bound_port: int) -> None:
        _write_web_pid(_pid, bound_port)
        if not web_cfg.enabled:
            return

        # Decide whether to open the browser.
        # If cloud used shared-app fallback (primary app blocked), open
        # automatically — the user likely cannot use MSAL popup either.
        _cloud_fallback = False
        cloud_ch = rt.channel_manager.get("cloud") if hasattr(rt, "channel_manager") else None
        if cloud_ch and getattr(cloud_ch, "_using_shared_app", False):
            _cloud_fallback = True

        # When a temp key was generated, always open the browser — the key
        # is only delivered via URL fragment, so skipping would lock the user out.
        _ws = getattr(rt, "_web_server", None)
        temp_key = getattr(_ws, "temp_key", None) if _ws else None
        should_open = _cloud_fallback or bool(temp_key)
        if not should_open:
            import sys

            try:
                is_tty = sys.stdin.isatty() and sys.stdout.isatty()
            except Exception:
                is_tty = False
            if is_tty:
                try:
                    from workpilot.cli.commands import _select_with_timeout

                    url_preview = _browse_url(web_cfg.host, bound_port)
                    _OPEN_OPTS: list[tuple[str, str]] = [
                        ("Open browser", url_preview),
                        ("Skip", ""),
                    ]
                    choice = _select_with_timeout(
                        _OPEN_OPTS, default=0, timeout=4, timeout_choice=1
                    )
                    should_open = choice == 0
                except KeyboardInterrupt:
                    raise
                except Exception as exc:
                    from loguru import logger as _logger

                    _logger.debug("Browser prompt failed, skipping: {}", exc)

        url = _browse_url(web_cfg.host, bound_port)
        if temp_key:
            url += f"#key={temp_key}"

        if should_open:
            try:
                import threading
                import time
                import webbrowser

                def _open() -> None:
                    time.sleep(1.0)
                    webbrowser.open(url)

                threading.Thread(target=_open, daemon=True).start()
            except Exception as exc:
                from loguru import logger

                logger.debug("Failed to open browser: {}", exc)

    try:
        asyncio.run(rt.run_web_server(on_started=_on_started))
    except KeyboardInterrupt:
        console.print("\nShutting down web server...")
    finally:
        _remove_web_pid()


# Backward compatibility aliases
_gateway_pid_file = _web_pid_file
_check_gateway_running = _check_web_running
