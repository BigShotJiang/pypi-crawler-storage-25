import copy
import sys
import re
from collections.abc import Iterable
from functools import partial
from typing import Annotated, Any, Callable, Generator, Literal

from dotdict3 import DotDict
from loguru import logger
from pydantic import Field

from chunklet.common.batch_runner import run_in_batch
from chunklet.common.logging_utils import log_info
from chunklet.common.token_utils import count_tokens
from chunklet.common.validation import IterableOfStr, validate_input
from chunklet.document_chunker.span_finder import DeterministicSpanFinder
from chunklet.exceptions import (
    CallbackError,
    InvalidInputError,
    MissingTokenCounterError,
)
from chunklet.sentence_splitter import BaseSplitter, SentenceSplitter


CLAUSE_END_PATTERN = re.compile(r"(?<=[;,’：—)&…])\s")
SECTION_BREAK_PATTERN = re.compile(
    r"^\s*#{1,6}\s+.+?$|"  # markdown headings (# - ######)
    r"^\s*([-*_])\s*(?:\1){2,}\s*$|"  # thematic breaks (---, ***, ___)
    r"^\s*<\/?(?:details|summary|section|article)\b[^>]*>|"  # HTML sectioning
    r"^\s*<hr\s*\/?>",  # HTML horizontal rule
    re.M | re.I,
)


class PlainTextChunker:
    """
    A powerful text chunking utility offering flexible strategies for optimal text segmentation.

    Key Features:
        - Flexible Constraint-Based Chunking: Segment text by specifying limits on sentence count, token count and section breaks or combination of them.
        - Clause-Level Overlap: Ensures semantic continuity between chunks by overlapping
    at natural clause boundaries with Customizable continuation marker.
        - Multilingual Support: Leverages language-specific algorithms and detection for broad coverage.
        - Pluggable Token Counters: Integrate custom token counting functions (e.g., for specific LLM tokenizers).
        - Parallel Processing: Efficiently handles batch chunking of multiple texts using multiprocessing.
        - Memory friendly batching: Yields chunks one at a time, reducing memory usage, especially for very large documents.
    """

    @validate_input
    def __init__(
        self,
        sentence_splitter: Any | None = None,
        verbose: bool = False,
        continuation_marker: str = "...",
        token_counter: Callable[[str], int] | None = None,
    ):
        """
        Initialize The PlainTextChunker.

        Args:
            sentence_splitter: An optional BaseSplitter instance.
                If None, a default SentenceSplitter will be initialized.
            verbose: Enable verbose logging.
            continuation_marker: The marker to prepend to unfitted clauses. Defaults to '...'.
            token_counter: Function that counts tokens in text.
                If None, must be provided when calling chunk() methods.

        Raises:
            InvalidInputError: If any of the input arguments are invalid or if the provided `sentence_splitter` is not an instance of `BaseSplitter`.
        """
        self._verbose = verbose
        self.token_counter = token_counter
        self.continuation_marker = continuation_marker

        if sentence_splitter is not None and not isinstance(
            sentence_splitter, BaseSplitter
        ):
            raise InvalidInputError(
                f"The provided sentence_splitter must be an instance of BaseSplitter, "
                f"but got {type(sentence_splitter).__name__}."
            )

        self.sentence_splitter = sentence_splitter or SentenceSplitter()
        self.sentence_splitter.verbose = self._verbose

    @property
    def verbose(self) -> bool:
        """Get the verbosity status."""
        return self._verbose

    @verbose.setter
    def verbose(self, value: bool):
        """Set the verbosity and propagate to sentence_splitter."""
        self._verbose = value
        self.sentence_splitter.verbose = value

    def _create_chunks(
        self,
        chunks: Iterable[str],
        base_metadata: dict[str, Any],
        span_finder: DeterministicSpanFinder,
    ) -> list[DotDict]:
        """
        Helper to create a list of DotDict objects for chunks with embedded metadata and auto-assigned chunk numbers.

        Args:
            chunks: An iterable (e.g., list or generator) of raw text strings,
                each representing a chunk of content.
            base_metadata: A dictionary containing document-level metadata
                (e.g., 'source' file path, 'page_count' for PDFs) to be embedded
                into each chunk's metadata.
            span_finder: The span finder instance for locating chunks.

        Returns:
            A list of `DotDict` objects. Each `DotDict` contains:

                - 'content' (str): The text of the chunk.
                - 'metadata' (dict): A dictionary including 'chunk_num' (int)
                    and all key-value pairs from `base_metadata`.
        """
        chunks_out = []
        for i, chunk_str in enumerate(chunks, start=1):
            chunk = DotDict({})
            chunk.content = chunk_str.strip()
            chunk.metadata = copy.deepcopy(base_metadata)
            chunk.metadata["chunk_num"] = i
            chunk.metadata["span"] = span_finder.find_span(
                chunk_str.removeprefix(self.continuation_marker)
            )
            chunks_out.append(chunk)
        return chunks_out

    def _get_overlap_clauses(
        self,
        sentences: list[str],
        overlap_percent: int | float,
    ) -> list[str]:
        """
        Extracts a specified number of clauses from the end of the previous chunk
        to create overlap for the next chunk.
        It optionally prepends a continuation marker in some cases.

        Args:
            sentences: A list of sentences to be chunked.
            overlap_percent: Percentage of overlap between chunks (0-75).

        Returns:
            A list of clauses as overlap.
        """
        clauses = [
            clause for sent in sentences for clause in CLAUSE_END_PATTERN.split(sent)
        ]

        overlap_num = round(len(clauses) * overlap_percent / 100)

        if overlap_num == 0:
            return []

        overlapped_clauses = clauses[-overlap_num:]

        # The Condition to add the continuation marker
        if (
            overlapped_clauses
            and overlapped_clauses[0]
            and not overlapped_clauses[0][0].isupper()
        ):
            overlapped_clauses[0] = (
                f"{self.continuation_marker} " + overlapped_clauses[0]
            )
        return overlapped_clauses

    def _find_clauses_that_fit(
        self,
        sentence: str,
        remaining_tokens: int,
        token_counter: Callable[[str], int],
    ) -> tuple[str, str]:
        """
        Splits a sentence into clauses and fits them into a token budget.

        This method takes a sentence and attempts to fit its component clauses
        into the number of remaining tokens available. It returns the fitted
        and unfitted portions as joined strings.

        Args:
            sentence: The input string to be split into clauses.
            remaining_tokens: The number of tokens available to fit clauses into.
            token_counter: The function needed for token counting.

        Returns:
            A tuple containing two strings:

                - The clauses that fit within the token budget (joined as a string).
                - The remaining unfitted clauses (joined as a string).
        """
        clauses = CLAUSE_END_PATTERN.split(sentence)

        fitted = []
        unfitted = []
        for i in range(len(clauses)):
            clause_tokens = count_tokens(clauses[i], token_counter)

            if clause_tokens <= remaining_tokens:
                fitted.append(clauses[i])
                remaining_tokens -= clause_tokens
            else:
                unfitted = clauses[i:]
                break

        return " ".join(fitted), " ".join(unfitted)

    def _resolve_unpunctuated_text(
        self,
        text: str,
        max_tokens: int,
        token_counter: Callable[[str], int],
    ) -> str:
        """
        Applies greedy token cutoff to a long, unpunctuated string.

        Splits the text into segments (words/parts) and greedily adds them
        to a 'fitted' part until the max_tokens limit is reached.

        Args:
            text: The input string to be processed.
            max_tokens: The maximum number of tokens allowed in the fitted part.
            token_counter: The function used to count tokens.

        Returns:
            The fitted part of the text, truncated to fit within max_tokens.
        """
        token_count = 0
        fitted_parts = []
        for part in re.split(r"[ /\\]", text):
            part_tokens = count_tokens(part + "...", token_counter)
            if token_count + part_tokens > max_tokens:
                break
            fitted_parts.append(part)
        return " ".join(fitted_parts) + "..."

    def _prepare_next_chunk(
        self,
        curr_chunk: list[str],
        overlap_percent: float,
        max_tokens: int,
        max_sentences: int,
        max_section_breaks: int,
        token_counter: Callable[[str], int] | None,
        constraint_counter: dict,
    ) -> list[str]:
        """
        Prepare data for the next chunk after splitting.

        Applies overlap clauses and calculates counts for tokens, sentences, and headings
        based on the provided constraints, updating the state dict.

        Args:
            curr_chunk: The current chunk sentences.
            overlap_percent: Percentage of overlap to apply.
            max_tokens: Maximum tokens per chunk.
            token_counter: Function to count tokens.
            max_sentences: Maximum sentences per chunk.
            max_section_breaks: Maximum section breaks per chunk.
            constraint_counter: State dict to update with counts.

        Returns:
            The prepared next chunk.
        """
        overlap_clauses = self._get_overlap_clauses(curr_chunk, overlap_percent)

        constraint_counter["token_count"] = 0
        if max_tokens != sys.maxsize:
            constraint_counter["token_count"] = sum(
                count_tokens(s, token_counter) for s in overlap_clauses
            )

        constraint_counter["sentence_count"] = 0
        if max_sentences != sys.maxsize:
            # Consider clause as sentence
            constraint_counter["sentence_count"] = len(overlap_clauses)

        constraint_counter["heading_count"] = 0
        if max_section_breaks != sys.maxsize:
            constraint_counter["heading_count"] = sum(
                1 for s in overlap_clauses if SECTION_BREAK_PATTERN.match(s)
            )

        return overlap_clauses

    def _group_by_chunk(
        self,
        sentences: list[str],
        token_counter: Callable[[str], int] | None,
        max_tokens: int,
        max_sentences: int,
        max_section_breaks: int,
        overlap_percent: int | float,
    ) -> list[str]:
        """
        Groups sentences into chunks based on the specified constraints.
        Applies overlap logic between consecutive chunks.

        Args:
            sentences: A list of sentences to be chunked.
            token_counter: The token counting function.
            max_tokens: Maximum number of tokens per chunk.
            max_sentences: Maximum number of sentences per chunk.
            max_section_breaks: Maximum number of section breaks per chunk.
            overlap_percent: Percentage of overlap between chunks.

        Returns:
            A list of chunk strings.
        """
        chunks = []
        curr_chunk = []
        constraint_counter = {
            "token_count": 0,
            "sentence_count": 0,
            "heading_count": 0,
        }

        index = 0
        while index < len(sentences):
            sentence = sentences[index]

            if SECTION_BREAK_PATTERN.match(sentence):
                is_heading = True
                sentence = "\n" + sentence
            else:
                is_heading = False

            sentence_tokens = (
                count_tokens(sentence + "\n", token_counter)
                if max_tokens != sys.maxsize
                else 0
            )

            sentence_limit_reached = constraint_counter["sentence_count"] + 1 > max_sentences
            heading_limit_reached = (
                is_heading and constraint_counter["heading_count"] + 1 > max_section_breaks
            )
            token_limit_reached = (
                max_tokens != sys.maxsize
                and constraint_counter["token_count"] + sentence_tokens > max_tokens
            )

            if token_limit_reached or sentence_limit_reached or heading_limit_reached:
                # for token-based mode, try splitting further
                if token_limit_reached:
                    remaining_tokens = max_tokens - constraint_counter["token_count"]
                    fitted, unfitted = self._find_clauses_that_fit(
                        sentence,
                        remaining_tokens,
                        token_counter,
                    )

                    # --- Handle long, unpunctuated sentences with Greedy Token Cutoff ---
                    # This applies if the sentence itself is too long for a single chunk
                    # This is likely a long string with no clause breaks
                    # and _find_clauses_that_fit would return it as unfitted.
                    # (e.g, urls, bad formated text, image uris).
                    if not curr_chunk and not fitted and unfitted:
                        curr_chunk = [
                            self._resolve_unpunctuated_text(
                                text=sentence,
                                max_tokens=max_tokens,
                                token_counter=token_counter,
                            )
                        ]
                        index += 1
                        continue

                    curr_chunk.append(fitted)

                    if unfitted:
                        # We need to process the remnants separately
                        sentences[index] = unfitted

                else:
                    unfitted = ""

                chunks.append("\n".join(curr_chunk))  # Considered complete

                curr_chunk = self._prepare_next_chunk(
                    curr_chunk=curr_chunk,
                    overlap_percent=overlap_percent,
                    max_tokens=max_tokens,
                    max_sentences=max_sentences,
                    max_section_breaks=max_section_breaks,
                    token_counter=token_counter,
                    constraint_counter=constraint_counter,
                )

            else:
                curr_chunk.append(sentence)
                constraint_counter["token_count"] += sentence_tokens
                constraint_counter["sentence_count"] += 1
                if is_heading:
                    constraint_counter["heading_count"] += 1
                index += 1

        # Add the last chunk if it exists
        if curr_chunk:
            chunks.append("\n".join(curr_chunk))

        return chunks

    def _validate_constraints(
        self,
        max_tokens: int | None,
        max_sentences: int | None,
        max_section_breaks: int | None,
        token_counter: Callable[[str], int] | None,
    ) -> None:
        """
        Validate chunking constraints and raise errors if invalid.

        Ensures that at least one chunking limit is specified and that a token counter
        is available when token-based limits are used.

        Args:
            max_tokens: Maximum tokens per chunk.
            max_sentences: Maximum sentences per chunk.
            max_section_breaks: Maximum section breaks per chunk.
            token_counter: Token counting function.

        Raises:
            InvalidInputError: If no chunking limits are provided.
            MissingTokenCounterError: If token limits are set but no token counter is available.
        """
        # Validate that at least one limit is provided
        if not any((max_tokens, max_sentences, max_section_breaks)):
            raise InvalidInputError(
                "At least one of 'max_tokens', 'max_sentences', or 'max_section_breaks' must be provided."
            )

        # If token_counter is required but not provided
        if max_tokens is not None and not (token_counter or self.token_counter):
            raise MissingTokenCounterError()

    @validate_input
    def chunk(
        self,
        text: str,
        *,
        lang: str = "auto",
        max_tokens: Annotated[int | None, Field(ge=12)] = None,
        max_sentences: Annotated[int | None, Field(ge=1)] = None,
        max_section_breaks: Annotated[int | None, Field(ge=1)] = None,
        overlap_percent: Annotated[int, Field(ge=0, le=75)] = 20,
        offset: Annotated[int, Field(ge=0)] = 0,
        token_counter: Callable[[str], int] | None = None,
        base_metadata: dict[str, Any] | None = None,
    ) -> list[DotDict]:
        """
        Chunks a single text into smaller pieces based on specified parameters.
        Supports flexible constraint-based chunking, clause-level overlap,
        and custom token counters.

        Args:
            text: The input text to chunk.
            lang: The language of the text (e.g., 'en', 'fr', 'auto'). Defaults to "auto".
            max_tokens: Maximum number of tokens per chunk. Must be >= 12.
            max_sentences: Maximum number of sentences per chunk. Must be >= 1.
            max_section_breaks: Maximum number of section breaks per chunk. Must be >= 1.
            overlap_percent: Percentage of overlap between chunks (0-75). Defaults to 20
            offset: Starting sentence offset for chunking. Defaults to 0.
            token_counter: Optional token counting function.
                Required for token-based modes only.
            base_metadata: Optional dictionary to be included with each chunk.

        Returns:
            A list of `DotDict` objects, each containing the chunk content and metadata.

        Raises:
            InvalidInputError: If any chunking configuration parameter is invalid.
            MissingTokenCounterError: If `max_tokens` is provided but no `token_counter` is provided.
            CallbackError: If an error occurs during sentence splitting or token counting within a chunking task.
        """
        self._validate_constraints(
            max_tokens, max_sentences, max_section_breaks, token_counter
        )

        log_info(
            self.verbose,
            "Starting chunk processing for text starting with: {}.",
            f"{text[:100]}...",
        )

        # Adjust limits for _group_by_chunk's internal use
        if max_tokens is None:
            max_tokens = sys.maxsize
        if max_sentences is None:
            max_sentences = sys.maxsize
        if max_section_breaks is None:
            max_section_breaks = sys.maxsize

        if not text.strip():
            log_info(self.verbose, "Input text is empty. Returning empty list.")
            return []

        try:
            sentences = self.sentence_splitter.split_text(
                text,
                lang,
            )
        except Exception as e:
            raise CallbackError(
                f"An error occurred during the sentence splitting process.\nDetails: {e}\n"
                "💡 Hint: This may be due to an issue with the underlying sentence splitting library."
            ) from e

        if not sentences:
            return []

        offset = round(offset)
        if offset >= len(sentences):
            logger.warning(
                "Offset {} >= total sentences {}. Returning empty list.",
                offset,
                len(sentences),
            )
            return []

        chunks = self._group_by_chunk(
            sentences[offset:],
            token_counter=token_counter or self.token_counter,
            max_tokens=max_tokens,
            max_sentences=max_sentences,
            max_section_breaks=max_section_breaks,
            overlap_percent=overlap_percent,
        )

        # Note: We use DeterministicSpanFinder because sentence splitter may modify text
        # (e.g., normalize whitespace, fix encoding), making exact span tracking difficult.
        span_finder = DeterministicSpanFinder(text)
        return self._create_chunks(chunks, base_metadata or {}, span_finder)

    @validate_input
    def batch_chunk(
        self,
        texts: IterableOfStr,
        *,
        lang: str = "auto",
        max_tokens: Annotated[int | None, Field(ge=12)] = None,
        max_sentences: Annotated[int | None, Field(ge=1)] = None,
        max_section_breaks: Annotated[int | None, Field(ge=1)] = None,
        overlap_percent: Annotated[int, Field(ge=0, le=75)] = 20,
        offset: Annotated[int, Field(ge=0)] = 0,
        token_counter: Callable[[str], int] | None = None,
        separator: Any = None,
        base_metadata: dict[str, Any] | None = None,
        n_jobs: Annotated[int, Field(ge=1)] | None = None,
        show_progress: bool = True,
        on_errors: Literal["raise", "skip", "break"] = "raise",
    ) -> Generator[Any, None, None]:
        """
        Processes a batch of texts in parallel, splitting each into chunks.
        Leverages multiprocessing for efficient batch chunking.

        If a task fails, `chunklet` will now stop processing and return the results
        of the tasks that completed successfully, preventing wasted work.

        Args:
            texts: A non-string iterable of input texts to be chunked.
            lang: The language of the text (e.g., 'en', 'fr', 'auto'). Defaults to "auto".
            max_tokens: Maximum number of tokens per chunk. Must be >= 12.
            max_sentences: Maximum number of sentences per chunk. Must be >= 1.
            max_section_breaks: Maximum number of section breaks per chunk. Must be >= 1.
            overlap_percent: Percentage of overlap between chunks (0-85).
            offset: Starting sentence offset for chunking. Defaults to 0.
            token_counter: The token counting function.
                Required if `max_tokens` is set.
            separator: A value to be yielded after the chunks of each text are processed.
                Note: None cannot be used as a separator.
            base_metadata: Optional dictionary to be included with each chunk.
            n_jobs: Number of parallel workers to use. If None, uses all available CPUs.
                Must be >= 1 if specified.
            show_progress: Flag to show or disable the loading bar.
            on_errors: How to handle errors during processing.
                Defaults to 'raise'.

        Yields:
            A `DotDict` object containing the chunk content and metadata, or any separator object.

        Raises:
            InvalidInputError: If `texts` is not an iterable of strings, or if `n_jobs` is less than 1.
            MissingTokenCounterError: If `max_tokens` is provided but no `token_counter` is provided.
            CallbackError: If an error occurs during sentence splitting
                or token counting within a chunking task.
        """
        chunk_func = partial(
            self.chunk,
            lang=lang,
            max_tokens=max_tokens,
            max_sentences=max_sentences,
            overlap_percent=overlap_percent,
            max_section_breaks=max_section_breaks,
            offset=offset,
            base_metadata=base_metadata,
            token_counter=token_counter or self.token_counter,
        )

        yield from run_in_batch(
            func=chunk_func,
            iterable_of_args=texts,
            iterable_name="texts",
            n_jobs=n_jobs,
            show_progress=show_progress,
            on_errors=on_errors,
            separator=separator,
            verbose=self.verbose,
        )
