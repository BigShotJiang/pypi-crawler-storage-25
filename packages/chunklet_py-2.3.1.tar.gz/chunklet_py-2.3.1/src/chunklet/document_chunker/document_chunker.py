import warnings
from itertools import chain, tee
from pathlib import Path
from typing import Annotated, Any, Callable, Generator, Iterable, Literal

from dotdict3 import DotDict
from loguru import logger
from more_itertools import ilen, split_at
from pydantic import Field

try:
    from striprtf.striprtf import rtf_to_text
except ImportError:  # pragma: no cover
    rtf_to_text = None

try:
    from charset_normalizer import from_path
except ImportError:  # pragma: no cover
    from_path = None

from chunklet.base_chunker import BaseChunker
from chunklet.common.deprecation import deprecated_callable
from chunklet.common.logging_utils import log_info
from chunklet.common.path_utils import read_text_file
from chunklet.common.validation import IterableOfStr, IterableOfPath, validate_input
from chunklet.document_chunker._plain_text_chunker import PlainTextChunker
from chunklet.document_chunker.converters import (
    html_2_md,
    latex_2_md,
    rst_2_md,
    table_2_md,
)
from chunklet.document_chunker.processors import (
    docx_processor,
    epub_processor,
    odt_processor,
    pdf_processor,
)
from chunklet.document_chunker.registry import custom_processor_registry
from chunklet.exceptions import InvalidInputError, UnsupportedFileTypeError
from chunklet.sentence_splitter import BaseSplitter


class DocumentChunker(BaseChunker):
    """
    A comprehensive document chunker that handles various file formats.

    This class provides a high-level interface to chunk text from different
    document types. It automatically detects the file format and uses the
    appropriate method to extract content before passing it to an underlying
    `PlainTextChunker` instance.

    Key Features:
        - Multi-Format Support: Chunks text from PDF, TXT, MD, and RST files.
        - Metadata Enrichment: Automatically adds source file path and other
      document-level metadata (e.g., PDF page numbers) to each chunk.
        - Bulk Processing: Efficiently chunks multiple documents in a single call.
        - Pluggable Document processors: Integrate custom processors allowing definition
    of specific logic for extracting text from various file types.
    """

    BUILTIN_SUPPORTED_EXTENSIONS = {
        ".csv",
        ".docx",
        ".epub",
        ".hml",
        ".html",
        ".md",
        ".odt",
        ".pdf",
        ".rst",
        ".rtf",
        ".tex",
        ".txt",
        ".xlsx",
    }

    def __init__(
        self,
        sentence_splitter: Any | None = None,
        verbose: bool = False,
        continuation_marker: str = "...",
        token_counter: Callable[[str], int] | None = None,
    ):
        """
        Initializes the DocumentChunker.

        Args:
            sentence_splitter: An optional BaseSplitter instance.
                If None, a default SentenceSplitter will be initialized.
            verbose: Enable verbose logging.
            continuation_marker: The marker to prepend to unfitted clauses. Defaults to '...'.
            token_counter: Function that counts tokens in text.
                If None, must be provided when calling chunk() methods.

        Raises:
            InvalidInputError: If any of the input arguments are invalid or if the provided `sentence_splitter` is not an instance of `BaseSplitter`.
        """
        self._verbose = verbose
        self.token_counter = token_counter
        self.continuation_marker = continuation_marker

        # Explicit type validation for sentence_splitter
        if sentence_splitter is not None and not isinstance(
            sentence_splitter, BaseSplitter
        ):
            raise InvalidInputError(
                f"The provided sentence_splitter must be an instance of BaseSplitter, "
                f"but got {type(sentence_splitter).__name__}."
            )

        self.plain_text_chunker = PlainTextChunker(
            sentence_splitter=sentence_splitter,
            verbose=self._verbose,
            continuation_marker=self.continuation_marker,
            token_counter=self.token_counter,
        )

        self.processors = {
            ".pdf": pdf_processor.PDFProcessor,
            ".epub": epub_processor.EPUBProcessor,
            ".docx": docx_processor.DOCXProcessor,
            ".odt": odt_processor.ODTProcessor,
        }
        self.converters = {
            ".html": html_2_md.html_to_md,
            ".hml": html_2_md.html_to_md,
            ".rst": rst_2_md.rst_to_md,
            ".tex": latex_2_md.latex_to_md,
            ".csv": table_2_md.table_to_md,
            ".xlsx": table_2_md.table_to_md,
        }

    @property
    def supported_extensions(self):
        """Get the supported extensions, including the custom ones."""
        return (
            self.BUILTIN_SUPPORTED_EXTENSIONS
            | custom_processor_registry.processors.keys()
        )

    @property
    def verbose(self) -> bool:
        """Get the verbosity status."""
        return self._verbose

    @verbose.setter
    def verbose(self, value: bool):
        """Set the verbosity and propagate to plain_text_chunker."""
        self._verbose = value
        self.plain_text_chunker.verbose = value

    def _validate_and_get_extension(self, path: Path) -> str:
        """
        Validates the file path and returns its lowercased extension.

        This method ensures the path exists and the file type is supported.

        Args:
            path: The Path object of the document file.

        Returns:
            The lowercased file extension.

        Raises:
            FileNotFoundError: If provided file path not found.
            UnsupportedFileTypeError: If the file extension is not supported or is missing.
        """
        extension = path.suffix.lower()

        if not extension:
            raise UnsupportedFileTypeError(
                f"Invalid path '{path}' provided. Path must have a recognizable extension."
            )

        if not path.is_file():
            raise FileNotFoundError(
                f"The file '{path}' can't be found.\n"
                "💡 Hint: Check the path for typos, ensure the file exists, and verify it's not a directory."
            )

        if extension not in self.supported_extensions:
            raise UnsupportedFileTypeError(
                f"File type '{extension}' is not supported.\nSupported extensions are: "
                f"{self.supported_extensions}\n"
                "💡 Hint: You can add support for other file types by registring a custom processor."
            )

        return extension

    def _read(self, path: str | Path, ext: str) -> str:
        """
        Read text content from a file using charset detection, handling special formats like RTF.

        Args:
            path: Path to the file
            ext: File extension

        Returns:
            The text content of the file
        """
        content = read_text_file(path)

        if ext == ".rtf":
            if rtf_to_text is None:
                raise ImportError(
                    "The 'striprtf' library is not installed. "
                    "Please install it with 'pip install 'striprtf>=0.0.29'' or install the document processing extras "
                    "with 'pip install chunklet-py[structured-document]'"
                )
            return rtf_to_text(content)
        else:  # For .txt, .md, and others handled by simple read
            return content

    def _extract_text_and_metadata(
        self, path: str | Path, ext: str
    ) -> tuple[str | Generator[str, None, None], dict[str, Any]]:
        """
        Extracts text content and metadata from a document.

        Args:
            path: The path to the document file.
            ext: The file extension.

        Returns:
            A tuple containing
            either a string (for simple text files) or a generator of strings (for processed documents)
            and a dictionary of metadata.
        """
        log_info(self.verbose, "Extracting text from file {}", path)

        # Prioritize custom processors from registry
        if custom_processor_registry.is_registered(ext):
            texts_and_metadata, processor_name = custom_processor_registry.extract_data(
                str(path), ext
            )
            log_info(self.verbose, "Used registered processor: {}", processor_name)
            text_or_gen, metadata = texts_and_metadata
            metadata["source"] = metadata.get("source", str(path))
            return text_or_gen, metadata

        elif ext in self.processors:
            processor_class = self.processors[ext]
            processor = processor_class(path)
            return processor.extract_text(), processor.extract_metadata()

        elif ext in self.converters:
            text_content = self.converters[ext](path)

        else:
            text_content = self._read(path, ext)

        return text_content, {"source": str(path)}

    def _prepare_batch_documents(self, paths: Iterable[str | Path], on_errors: str) -> dict:
        """
        Prepares documents for batch processing by extracting text and metadata from multiple paths.

        This method iterates through a list of file paths,
        validates each path, handles any validation or processing errors,
        and extracts the content and metadata from each valid file. It uses a memory-efficient approach
        by creating a master generator for all text content rather than loading
        it all into memory.

        Args:
            paths: An iterable of file paths to process.
            on_errors: Defines the error
                handling strategy for validation or processing failures.

        Returns:
            A dictionary containing the prepared data, with the
                following keys:
                - "path_section_counts": A mapping of file paths to the
                  number of sections (e.g., pages) within them.
                - "all_texts_gen": A single generator that yields
                  the text content of all documents sequentially.
                - "all_metadata": A list of metadata dictionaries, one
                  for each successfully processed document.
        """
        sections_per_path = {}
        all_metadata = []
        texts_to_chain = []

        for i, path in enumerate(paths):
            try:
                path = Path(path)
                ext = self._validate_and_get_extension(path)

                text_content_or_generator, document_metadata = self._extract_text_and_metadata(
                    path, ext
                )
                all_metadata.append(document_metadata)

                if isinstance(text_content_or_generator, Generator):
                    g1, g2 = tee(text_content_or_generator)
                    sections_per_path[str(path)] = ilen(g1)
                    texts_to_chain.append(g2)
                else:
                    sections_per_path[str(path)] = 1

                    # Wrap in a list to prevent breakking the str into chars
                    texts_to_chain.append([text_content_or_generator])
            except Exception as e:
                if on_errors == "raise":
                    logger.error(
                        "Document processing failed for '{}'.\nReason: {}.",
                        path,
                        e,
                    )
                    raise
                elif on_errors == "break":
                    logger.error(
                        "Stopping due to validation error on '{}' at paths[{}].\nReason: {}.",
                        path,
                        i,
                        e,
                    )
                    break
                else:  # skip
                    logger.warning(
                        "Skipping document '{}' at paths[{}] due to validation failure.\nReason: {}.",
                        path,
                        i,
                        e,
                    )
                    continue

        return {
            "path_to_section_counts": sections_per_path,
            "all_texts_gen": chain.from_iterable(texts_to_chain),
            "all_metadata": all_metadata,
        }

    @validate_input
    def chunk_text(
        self,
        text: str,
        *,
        lang: str = "auto",
        max_tokens: Annotated[int | None, Field(ge=12)] = None,
        max_sentences: Annotated[int | None, Field(ge=1)] = None,
        max_section_breaks: Annotated[int | None, Field(ge=1)] = None,
        overlap_percent: Annotated[int, Field(ge=0, le=75)] = 20,
        offset: Annotated[int, Field(ge=0)] = 0,
        token_counter: Callable[[str], int] | None = None,
        base_metadata: dict[str, Any] | None = None,
    ) -> list[DotDict]:
        """
        Chunks raw text content.

        Args:
            text: The raw text to chunk.
            lang: The language of the text (e.g., 'en', 'fr', 'auto'). Defaults to "auto".
            max_tokens: Maximum number of tokens per chunk. Must be >= 12.
            max_sentences: Maximum number of sentences per chunk. Must be >= 1.
            max_section_breaks: Maximum number of section breaks per chunk.
                Section breaks include Markdown headings (# to ######), horizontal rules (---, ***, ___), and <details> tags.
                Must be >= 1.
            overlap_percent: Percentage of overlap between chunks (0-85).
            offset: Starting sentence offset for chunking. Defaults to 0.
            token_counter: Optional token counting function.
                Required if `max_tokens` is provided.
            base_metadata: Optional dictionary to be included with each chunk.

        Returns:
            A list of `DotDict` objects, each representing a chunk.
        """
        params = {k: v for k, v in locals().items() if k != "self"}
        params["token_counter"] = params.get("token_counter") or self.token_counter
        return self.plain_text_chunker.chunk(**params)

    @validate_input
    def chunk_texts(
        self,
        texts: IterableOfStr,
        *,
        lang: str = "auto",
        max_tokens: Annotated[int | None, Field(ge=12)] = None,
        max_sentences: Annotated[int | None, Field(ge=1)] = None,
        max_section_breaks: Annotated[int | None, Field(ge=1)] = None,
        overlap_percent: Annotated[int, Field(ge=0, le=75)] = 20,
        offset: Annotated[int, Field(ge=0)] = 0,
        token_counter: Callable[[str], int] | None = None,
        base_metadata: dict[str, Any] | None = None,
        separator: Any = None,
        n_jobs: Annotated[int, Field(ge=1)] | None = None,
        show_progress: bool = True,
        on_errors: Literal["raise", "skip", "break"] = "raise",
    ) -> Generator[DotDict, None, None]:
        """
        Chunks multiple text contents.

        Args:
            texts: A non-string iterable of texts to chunk.
            lang: The language of the text (e.g., 'en', 'fr', 'auto'). Defaults to "auto".
            max_tokens: Maximum number of tokens per chunk. Must be >= 12.
            max_sentences: Maximum number of sentences per chunk. Must be >= 1.
            max_section_breaks: Maximum number of section breaks per chunk.
                Section breaks include Markdown headings (# to ######), horizontal rules (---, ***, ___), and <details> tags.
                Must be >= 1.
            overlap_percent: Percentage of overlap between chunks (0-85).
            offset: Starting sentence offset for chunking. Defaults to 0.
            token_counter: Optional token counting function.
                Required if `max_tokens` is provided.
            base_metadata: Optional dictionary to be included with each chunk.
            separator: A value to be yielded after the chunks of each text are processed.
            n_jobs: Number of parallel workers.
            show_progress: Show progress bar.
            on_errors: How to handle errors.

        yields:
            `DotDict` object, representing a chunk with its content and metadata.

        Raises:
            InvalidInputError: If the input arguments aren't valid.
            UnsupportedFileTypeError: If the file extension is not supported or is missing.
            MissingTokenCounterError: If `max_tokens` is provided but no `token_counter` is provided.
            CallbackError: If a callback function (e.g., custom processors callbacks) fails during execution.
        """
        params = {k: v for k, v in locals().items() if k != "self"}
        params["token_counter"] = params["token_counter"] or self.token_counter
        yield from self.plain_text_chunker.batch_chunk(**params)

    @validate_input
    def chunk_file(
        self,
        path: str | Path,
        *,
        lang: str = "auto",
        max_tokens: Annotated[int | None, Field(ge=12)] = None,
        max_sentences: Annotated[int | None, Field(ge=1)] = None,
        max_section_breaks: Annotated[int | None, Field(ge=1)] = None,
        overlap_percent: Annotated[int, Field(ge=0, le=75)] = 20,
        offset: Annotated[int, Field(ge=0)] = 0,
        token_counter: Callable[[str], int] | None = None,
    ) -> list[DotDict]:
        """
        Chunks a single document from a given path.

        This method automatically detects the file type and uses the appropriate
        processor to extract text before chunking. It then adds document-level
        metadata to each resulting chunk.

        Args:
            path: The path to the document file.
            lang: The language of the text (e.g., 'en', 'fr', 'auto'). Defaults to "auto".
            max_tokens: Maximum number of tokens per chunk. Must be >= 12.
            max_sentences: Maximum number of sentences per chunk. Must be >= 1.
            max_section_breaks: Maximum number of section breaks per chunk.
                Section breaks include Markdown headings (# to ######), horizontal rules (---, ***, ___), and <details> tags.
                Must be >= 1.
            overlap_percent: Percentage of overlap between chunks (0-85).
            offset: Starting sentence offset for chunking. Defaults to 0.
            token_counter: Optional token counting function.
                Required if `max_tokens` is provided.

        Returns:
            A list of `DotDict` objects, each representing
            a chunk with its content and metadata.

        Raises:
            InvalidInputError: If the input arguments aren't valid.
            FileNotFoundError: If provided file path not found.
            UnsupportedFileTypeError: If the file extension is not supported or is missing.
            MissingTokenCounterError: If `max_tokens` is provided but no `token_counter` is provided.
            CallbackError: If a callback function (e.g., custom processors callbacks) fails during execution.
        """
        path = Path(path)
        ext = self._validate_and_get_extension(path)

        text_content, document_metadata = self._extract_text_and_metadata(path, ext)

        if not isinstance(text_content, str):
            raise UnsupportedFileTypeError(
                f"File type '{ext}' is not supported by the general chunk method.\n"
                "Reason: The processor for this file returns iterable, "
                "so it must be processed in parallel for efficiency.\n"
                "💡 Hint: use `chunker.chunk_files([file.ext])` for this file type."
            )

        log_info(self.verbose, "Starting chunk processing for path: {}.", path)

        chunks_out = self.plain_text_chunker.chunk(
            text=text_content,
            lang=lang,
            max_tokens=max_tokens,
            max_sentences=max_sentences,
            max_section_breaks=max_section_breaks,
            overlap_percent=overlap_percent,
            offset=offset,
            token_counter=token_counter or self.token_counter,
        )

        for chunk in chunks_out:
            chunk.metadata.update(document_metadata)

        log_info(self.verbose, "Generated {} chunks for {}.", len(chunks_out), path)

        return chunks_out

    @validate_input
    def chunk_files(
        self,
        paths: IterableOfPath,
        *,
        lang: str = "auto",
        max_tokens: Annotated[int | None, Field(ge=12)] = None,
        max_sentences: Annotated[int | None, Field(ge=1)] = None,
        max_section_breaks: Annotated[int | None, Field(ge=1)] = None,
        overlap_percent: Annotated[int, Field(ge=0, le=75)] = 20,
        offset: Annotated[int, Field(ge=0)] = 0,
        token_counter: Callable[[str], int] | None = None,
        separator: Any = None,
        n_jobs: Annotated[int, Field(ge=1)] | None = None,
        show_progress: bool = True,
        on_errors: Literal["raise", "skip", "break"] = "raise",
    ) -> Generator[DotDict, None, None]:
        """
        Chunks multiple documents from a list of file paths.

        This method is a memory-efficient generator that yields chunks as they
        are processed, without loading all documents into memory at once. It
        handles various file types.

        Args:
            paths: A non-string iterable of paths to the document files.
            lang: The language of the text (e.g., 'en', 'fr', 'auto'). Defaults to "auto".
            max_tokens: Maximum number of tokens per chunk. Must be >= 12.
            max_sentences: Maximum number of sentences per chunk. Must be >= 1.
            max_section_breaks: Maximum number of section breaks per chunk.
                Section breaks include Markdown headings (# to ######), horizontal rules (---, ***, ___), and <details> tags.
                Must be >= 1.
            overlap_percent: Percentage of overlap between chunks (0-85).
            offset: Starting sentence offset for chunking. Defaults to 0.
            token_counter: Optional token counting function.
                Required if `max_tokens` is provided.
            separator: A value to be yielded after the chunks of each text are processed.
                Note: None cannot be used as a separator.

            n_jobs: Number of parallel workers to use. If None, uses all available CPUs.
                   Must be >= 1 if specified.
            show_progress: Flag to show or disable the loading bar.
            on_errors: How to handle errors during processing. Can be 'raise', 'ignore', or 'break'.

        yields:
            `DotDict` object, representing a chunk with its content and metadata.

        Raises:
            InvalidInputError: If the input arguments aren't valid.
            FileNotFoundError: If provided file path not found.
            UnsupportedFileTypeError: If the file extension is not supported or is missing.
            MissingTokenCounterError: If `max_tokens` is provided but no `token_counter` is provided.
            CallbackError: If a callback function (e.g., custom processors callbacks) fails during execution.
        """
        sentinel = object()

        batch_documents = self._prepare_batch_documents(paths, on_errors)

        all_chunks_gen = self.plain_text_chunker.batch_chunk(
            texts=list(batch_documents["all_texts_gen"]),
            lang=lang,
            max_tokens=max_tokens,
            max_sentences=max_sentences,
            max_section_breaks=max_section_breaks,
            overlap_percent=overlap_percent,
            offset=offset,
            token_counter=token_counter or self.token_counter,
            separator=sentinel,
            n_jobs=n_jobs,
            show_progress=show_progress,
            on_errors=on_errors,
        )

        all_chunk_groups = split_at(all_chunks_gen, lambda x: x is sentinel)
        sections_per_path = batch_documents["path_to_section_counts"]
        all_metadata = batch_documents["all_metadata"]

        # HACK: Since a sentinel is always at the end of the gen,
        # the last list of the groups will be an empty one.
        # The only work-around to add a sentinel at paths
        paths = list(sections_per_path.keys()) + [None]

        # If no files were successfully processed, return empty
        if not sections_per_path:
            return

        doc_count = 0
        curr_path = paths[0]
        for chunks in all_chunk_groups:
            if sections_per_path.get(curr_path, 0) == 0:
                if separator is not None:
                    yield separator

                doc_count += 1
                curr_path = paths[doc_count]
                if curr_path is None:
                    return

            for i, ch in enumerate(chunks, start=1):
                doc_metadata = all_metadata[doc_count]
                doc_metadata["section_count"] = sections_per_path[curr_path]
                doc_metadata["curr_section"] = i

                ch["metadata"].update(doc_metadata)
                yield ch

            sections_per_path[curr_path] -= 1

    @deprecated_callable(
        use_instead="chunk_file or chunk_text", deprecated_in="2.2.0", removed_in="3.0.0"
    )
    def chunk(  # pragma: no cover
        self,
        path: str | Path,
        *,
        lang: str = "auto",
        max_tokens: Annotated[int | None, Field(ge=12)] = None,
        max_sentences: Annotated[int | None, Field(ge=1)] = None,
        max_section_breaks: Annotated[int | None, Field(ge=1)] = None,
        overlap_percent: Annotated[int, Field(ge=0, le=75)] = 20,
        offset: Annotated[int, Field(ge=0)] = 0,
        token_counter: Callable[[str], int] | None = None,
    ) -> list[DotDict]:
        """
        Chunk a document file into semantic pieces.

        Note:
            Deprecated since v2.2.0. Will be removed in v3.0.0. Use `chunk_file` instead.
        """
        params = {k: v for k, v in locals().items() if k != "self"}
        params["token_counter"] = params["token_counter"] or self.token_counter
        return self.chunk_file(**params)

    @deprecated_callable(
        use_instead="chunk_files or chunk_texts", deprecated_in="2.2.0", removed_in="3.0.0"
    )
    def batch_chunk(  # pragma: no cover
        self,
        paths: IterableOfPath,
        *,
        lang: str = "auto",
        max_tokens: Annotated[int | None, Field(ge=12)] = None,
        max_sentences: Annotated[int | None, Field(ge=1)] = None,
        max_section_breaks: Annotated[int | None, Field(ge=1)] = None,
        overlap_percent: Annotated[int, Field(ge=0, le=75)] = 20,
        offset: Annotated[int, Field(ge=0)] = 0,
        token_counter: Callable[[str], int] | None = None,
        separator: Any = None,
        n_jobs: Annotated[int, Field(ge=1)] | None = None,
        show_progress: bool = True,
        on_errors: Literal["raise", "skip", "break"] = "raise",
    ) -> Generator[DotDict, None, None]:
        """
        Batch chunk multiple document files.

        Note:
            Deprecated since v2.2.0. Will be removed in v3.0.0. Use `chunk_files` instead.
        """
        params = {k: v for k, v in locals().items() if k != "self"}
        params["token_counter"] = params["token_counter"] or self.token_counter
        yield from self.chunk_files(**params)
