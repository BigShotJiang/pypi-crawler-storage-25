import torch
import torch.nn.functional as F

class SignalExtractor:
    """Extracts training signals for difficulty estimation."""
    
    @staticmethod
    def extract_per_sample_loss(logits: torch.Tensor, targets: torch.Tensor, ignore_index: int = -100) -> torch.Tensor:
        """
        Computes the true per-sample loss.
        logits: (batch_size, seq_len, vocab_size)
        targets: (batch_size, seq_len)
        Returns:
            per_sample_loss: (batch_size,)
        """
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = targets[..., 1:].contiguous()
        
        loss_fct = torch.nn.CrossEntropyLoss(ignore_index=ignore_index, reduction='none')
        
        batch_size = shift_logits.size(0)
        # Flatten for loss computation
        token_losses = loss_fct(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))
        token_losses = token_losses.view(batch_size, -1)
        
        # Calculate valid tokens per sample
        valid_tokens = (shift_labels != ignore_index).sum(dim=1).float()
        valid_tokens = torch.clamp(valid_tokens, min=1.0)
        
        # Mean loss per sample
        per_sample_loss = token_losses.sum(dim=1) / valid_tokens
        return per_sample_loss

    @staticmethod
    def extract_entropy(logits: torch.Tensor, targets: torch.Tensor, ignore_index: int = -100) -> torch.Tensor:
        """
        Computes the per-sample predictive entropy.
        Extreme Memory Efficiency: processes samples individually AND uses vocab chunking.
        Returns: (batch_size,)
        """
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = targets[..., 1:].contiguous()
        
        batch_size, seq_len, vocab_size = shift_logits.shape
        per_sample_entropy = torch.zeros(batch_size, device=logits.device)
        
        for i in range(batch_size):
            sample_logits = shift_logits[i]  # (seq_len, vocab_size)
            sample_labels = shift_labels[i]  # (seq_len)
            
            # 1. Calculate logsumexp for normalization (seq_len, 1)
            lse = torch.logsumexp(sample_logits, dim=-1, keepdim=True)
            
            # 2. Chunked Entropy calculation: H = sum( exp(x-lse) * (lse-x) )
            entropy = torch.zeros(seq_len, device=logits.device)
            chunk_size = 32768
            
            for start in range(0, vocab_size, chunk_size):
                end = min(start + chunk_size, vocab_size)
                chunk = sample_logits[:, start:end] # (seq_len, chunk_size)
                
                # prob_chunk = exp(x - lse)
                p_chunk = (chunk - lse).exp()
                
                # -p * log(p) = p * (lse - x)
                entropy += (p_chunk * (lse - chunk)).sum(dim=-1)
                
                del chunk, p_chunk
                
            mask = (sample_labels != ignore_index).float()
            valid_tokens = torch.clamp(mask.sum(), min=1.0)
            
            per_sample_entropy[i] = (entropy * mask).sum() / valid_tokens
            
            del lse, entropy
            
        return per_sample_entropy
