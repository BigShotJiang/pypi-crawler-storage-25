import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Optional, Dict, Any, Callable
from tqdm import tqdm

from cyrapeft.config.config import CyraConfig
from cyrapeft.core.model import AdaptiveLoRAModel
from cyrapeft.controller.controller import AlphaController
from cyrapeft.controller.pid_controller import PIDController
from cyrapeft.difficulty.difficulty_model import DifficultyEstimator
from cyrapeft.difficulty.features import assemble_features
from cyrapeft.signals.extractor import SignalExtractor
from cyrapeft.memory.replay_buffer import PrioritizedReplayBuffer
from cyrapeft.optimization.loss import WeightedLoss
from cyrapeft.evaluation.metrics import MetricsTracker
from cyrapeft.utils.logging import logger

class CyraTrainer:
    """
    Core training loop implementing Adaptive LoRA with Control Systems.
    """
    def __init__(
        self, 
        model: AdaptiveLoRAModel,
        config: CyraConfig,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader] = None,
        device: torch.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu'),
        use_ray: bool = False
    ):
        self.model = model
        self.config = config
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.use_ray = use_ray
        
        self.model.to(self.device)
        
        # Difficulty Model
        self.difficulty_model = DifficultyEstimator(input_dim=4, hidden_dim=config.difficulty.hidden_dim).to(self.device)
        
        self.controller = PIDController(
            kp=config.controller.kp,
            ki=config.controller.ki,
            kd=config.controller.kd,
            target=config.controller.target_difficulty,
            min_val=config.controller.alpha_min,
            max_val=config.controller.alpha_max,
            epsilon=config.controller.epsilon,
            lambda_reg=config.controller.lambda_reg,
            integral_clamp=config.controller.integral_clamp,
            update_scale=config.controller.update_scale
        )
        
        # 4. Swarm Optimizer (Meta-Heuristic Tuning)
        self.swarm = None
        if config.swarm.enabled:
            from ..optimization.swarm import SwarmOptimizer
            self.swarm = SwarmOptimizer(num_particles=config.swarm.num_particles)
        
        # Optimizers
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=config.learning_rate)
        self.difficulty_optimizer = torch.optim.Adam(self.difficulty_model.parameters(), lr=config.difficulty.learning_rate)
        
        # 5. Learning Rate Scheduler
        num_training_steps = len(self.train_loader) * config.epochs
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=num_training_steps)
        
        # Components
        self.replay_buffer = PrioritizedReplayBuffer(capacity=config.memory.capacity, alpha=config.memory.alpha)
        self.metrics = MetricsTracker()
        
    def train(self):
        logger.info("Starting Adaptive LoRA Training...")
        self.model.train()
        self.difficulty_model.train()
        
        global_step = 0
        self.optimizer.zero_grad()
        self.difficulty_optimizer.zero_grad()
        
        for epoch in range(self.config.epochs):
            logger.info(f"Epoch {epoch+1}/{self.config.epochs}")
            
            # Progress bar
            pbar = tqdm(self.train_loader, desc=f"Training")
            
            for batch in pbar:
                # 1. Mix with replay buffer if enabled
                if self.config.memory.enabled and self.replay_buffer.size > 0:
                    # In a real implementation, you'd collate these properly. 
                    # For simplicity, we just train on the fresh batch here,
                    # and optionally do a second pass or mix tensors.
                    # This serves as the structural foundation.
                    pass 
                
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch.get('labels', input_ids).to(self.device)
                
                # 2. Forward pass
                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
                logits = outputs.logits
                
                # 3. Actual Loss (Attached to graph for main model training)
                per_sample_loss = SignalExtractor.extract_per_sample_loss(logits, labels)
                
                # 4. Extract Signals for Difficulty Estimation (Detached)
                with torch.no_grad():
                    entropy = SignalExtractor.extract_entropy(logits, labels)
                    seq_lengths = attention_mask.sum(dim=1)
                    
                    # Grad norm approximation (optional/heuristic)
                    grad_norms = torch.zeros_like(per_sample_loss)
                    
                    features = assemble_features(per_sample_loss.detach(), entropy, seq_lengths, grad_norms)
                
                # 5. Estimate Difficulty (Used for weighting and replay)
                difficulties = self.difficulty_model(features)
                
                # 5. Controller Update & LoRA Alpha Adjustment
                if self.config.controller.enabled:
                    current_diff = difficulties.mean().item()
                    current_alpha = self.model.module.current_alpha if hasattr(self.model, "module") else self.model.current_alpha
                    
                    new_alpha = self.controller.update(current_diff, current_alpha)
                    
                    # Ensure underlying AdaptiveLoRAModel updates alpha
                    if hasattr(self.model, "module"):
                        self.model.module.set_alpha(new_alpha)
                    else:
                        self.model.set_alpha(new_alpha)
                    self.metrics.update({"alpha": new_alpha})
                    
                # 6. Compute Weighted Loss
                if self.config.difficulty.enabled:
                    loss = WeightedLoss.compute(per_sample_loss, difficulties)
                else:
                    loss = per_sample_loss.mean()
                
                # 7. Model Update with Gradient Accumulation
                loss = loss / self.config.gradient_accumulation_steps
                
                # PRE-BACKWARD MEMORY CLEANUP
                # Logits and Entropy are no longer needed, and they are massive (GBs)
                del logits, entropy
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                
                loss.backward()
                
                if (global_step + 1) % self.config.gradient_accumulation_steps == 0:
                    self.optimizer.step()
                    self.scheduler.step()
                    self.optimizer.zero_grad()
                
                # 8. Train Difficulty Model (Self-supervised target: normalized loss)
                if self.config.difficulty.enabled:
                    target_difficulty = (per_sample_loss.detach() - per_sample_loss.mean().detach()) / (per_sample_loss.std().detach() + 1e-8)
                    target_difficulty = torch.sigmoid(target_difficulty)
                    
                    diff_loss = nn.MSELoss()(difficulties, target_difficulty.detach())
                    
                    self.difficulty_optimizer.zero_grad()
                    diff_loss.backward()
                    self.difficulty_optimizer.step()
                
                # 9. Update Replay Buffer
                if self.config.memory.enabled:
                    for i in range(input_ids.size(0)):
                        sample = {
                            'input_ids': input_ids[i].cpu(),
                            'attention_mask': attention_mask[i].cpu(),
                            'labels': labels[i].cpu()
                        }
                        self.replay_buffer.add(sample, priority=difficulties[i].item())
                
                # 10. Track Metrics
                current_alpha = self.model.module.current_alpha if hasattr(self.model, "module") else self.model.current_alpha
                self.metrics.update({
                    "train_loss": loss.item(),
                    "alpha": current_alpha,
                    "mean_difficulty": difficulties.mean().item(),
                    "step": global_step
                })
                
                pbar.set_postfix({
                    "loss": f"{loss.item():.4f}",
                    "alpha": f"{current_alpha:.2f}",
                    "diff": f"{difficulties.mean().item():.3f}"
                })
                
                if self.use_ray:
                    import ray.train
                    ray.train.report({
                        "loss": loss.item(),
                        "alpha": current_alpha,
                        "mean_difficulty": difficulties.mean().item(),
                        "step": global_step,
                        "epoch": epoch
                    })
                
                # 11. Swarm Meta-Optimization (Global Synchronization)
                if self.swarm and global_step % self.config.swarm.update_interval == 0:
                    import torch.distributed as dist
                    is_dist = dist.is_initialized()
                    
                    # 1. Rank 0 calculates the new best parameters
                    if not is_dist or dist.get_rank() == 0:
                        best_params = self.swarm.step(loss.item())
                        param_tensor = torch.tensor([
                            best_params['learning_rate'],
                            best_params['kp'],
                            best_params['ki'],
                            best_params['kd']
                        ], device=self.device)
                    else:
                        param_tensor = torch.zeros(4, device=self.device)
                    
                    # 2. Broadcast winning parameters to all GPUs
                    if is_dist:
                        dist.broadcast(param_tensor, src=0)
                    
                    # 3. All workers apply the same synchronized parameters
                    lr, kp, ki, kd = param_tensor.tolist()
                    
                    for param_group in self.optimizer.param_groups:
                        param_group['lr'] = lr
                    
                    self.controller.kp = kp
                    self.controller.ki = ki
                    self.controller.kd = kd
                    
                    if not is_dist or dist.get_rank() == 0:
                        logger.info(f"Swarm Update (Step {global_step}): LR={lr:.2e}, PID=[{kp:.3f}, {ki:.3f}, {kd:.3f}]")
                    
                global_step += 1
                
            # Optional: Evaluation phase
            if self.val_loader:
                self.evaluate()
                
        logger.info("Training Complete.")
        
        # Save metrics to disk for research analysis
        if self.config.output_dir:
            import os
            import json
            os.makedirs(self.config.output_dir, exist_ok=True)
            metrics_path = os.path.join(self.config.output_dir, "metrics.json")
            with open(metrics_path, "w") as f:
                json.dump(self.metrics.history, f, indent=4)
            logger.info(f"Research metrics saved to {metrics_path}")
            
            # Save the adapters
            logger.info(f"Saving fine-tuned adapters to {self.config.output_dir}")
            if hasattr(self.model, "save_pretrained"):
                self.model.save_pretrained(self.config.output_dir)
            elif hasattr(self.model, "model") and hasattr(self.model.model, "save_pretrained"):
                self.model.model.save_pretrained(self.config.output_dir)
            
        return self.metrics.history

    def evaluate(self):
        self.model.eval()
        total_loss = 0
        with torch.no_grad():
            for batch in tqdm(self.val_loader, desc="Evaluating"):
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch.get('labels', input_ids).to(self.device)
                
                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                total_loss += outputs.loss.item()
                
        avg_loss = total_loss / len(self.val_loader)
        perplexity = self.metrics.compute_perplexity(avg_loss)
        
        self.metrics.update({"val_loss": avg_loss, "perplexity": perplexity})
        logger.info(f"Validation Loss: {avg_loss:.4f} | Perplexity: {perplexity:.4f}")
        self.model.train()
