class PIDController:
    """
    A stabilized discrete-time PID controller for dynamic scaling of LoRA alpha.
    """
    def __init__(self, kp: float, ki: float, kd: float, target: float, min_val: float, max_val: float,
                 epsilon: float = 0.01, lambda_reg: float = 0.001, integral_clamp: float = 10.0,
                 update_scale: float = 0.1):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.target = target
        self.min_val = min_val
        self.max_val = max_val
        self.epsilon = epsilon
        self.lambda_reg = lambda_reg
        self.integral_clamp = integral_clamp
        self.update_scale = update_scale
        
        self.prev_error = 0.0
        self.integral = 0.0
        
    def update(self, current_value: float, current_alpha: float) -> float:
        """
        Update the alpha value with stability guards.
        """
        # 1. Error with Deadzone
        error = self.target - current_value
        if abs(error) < self.epsilon:
            error = 0.0
            
        # 2. Leaky Integral with Anti-Windup Clamping
        self.integral = (0.95 * self.integral) + error
        self.integral = max(-self.integral_clamp, min(self.integral_clamp, self.integral))
        
        # 3. Derivative
        derivative = error - self.prev_error
        self.prev_error = error
        
        # 4. Bidirectional Adjustment (Scaled for stability)
        adjustment = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)
        adjustment *= self.update_scale
        
        # 5. Alpha Regularization (Decay towards 0 to provide downward pressure)
        decay = self.lambda_reg * current_alpha
        
        # 6. Apply Update and Hard Bounds
        new_alpha = current_alpha + adjustment - decay
        new_alpha = max(self.min_val, min(self.max_val, new_alpha))
        
        return new_alpha
