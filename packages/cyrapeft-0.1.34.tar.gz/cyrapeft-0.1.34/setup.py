from setuptools import setup, find_packages

setup(
    name="cyrapeft",
    version="0.1.34",
    description="Cybernetic Regulatory Adaptive PEFT (CyraPEFT) - Difficulty-Aware Control Systems for LoRA",
    author="Shrey",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "torch>=2.0.0",
        "transformers>=4.30.0",
        "peft>=0.5.0",
        "numpy",
        "pyyaml",
        "tqdm",
        "bitsandbytes>=0.46.1",
        "ray[train]",
        "pandas",
        "datasets"
    ],
    python_requires=">=3.8",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Programming Language :: Python :: 3",
    ],
    entry_points={
        "console_scripts": [
            "cyrapeft=cyrapeft.cli:main",
        ],
    },
)
