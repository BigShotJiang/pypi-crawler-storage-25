Deploy the current branch.
