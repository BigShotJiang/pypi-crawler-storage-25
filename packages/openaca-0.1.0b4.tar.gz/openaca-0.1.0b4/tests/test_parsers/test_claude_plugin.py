import json
from pathlib import Path

from tools.parsers.claude_plugin import parse, parse_at_install_root

REPOS = Path(__file__).parent.parent / "fixtures" / "repos"


def test_plugin_self_identity():
    manifest = REPOS / "sample-plugin" / ".claude-plugin" / "plugin.json"
    refs = parse(manifest)
    plugin_self = [
        r
        for r in refs
        if r.component_identity and r.component_identity.startswith("claude-plugin/")
    ]
    assert len(plugin_self) == 1
    assert plugin_self[0].component_identity == "claude-plugin/deployment-tools"


def test_plugin_dependencies():
    manifest = REPOS / "sample-plugin" / ".claude-plugin" / "plugin.json"
    refs = parse(manifest)
    deps = [
        r
        for r in refs
        if r.component_identity and r.component_identity.startswith("claude-plugin-dep/")
    ]
    identities = {r.component_identity for r in deps}
    assert "claude-plugin-dep/helper-lib" in identities
    assert "claude-plugin-dep/secrets-vault@~2.1.0" in identities


def test_plugin_inlined_mcp_servers():
    manifest = REPOS / "sample-plugin" / ".claude-plugin" / "plugin.json"
    refs = parse(manifest)
    npm_mcp = [r for r in refs if r.ecosystem == "npm"]
    assert len(npm_mcp) == 1
    assert npm_mcp[0].name == "@company/mcp-server"
    assert npm_mcp[0].version == "1.0.4"
    binary_mcp = [
        r
        for r in refs
        if r.component_identity and r.component_identity.startswith("mcp-stdio/binary:")
    ]
    assert len(binary_mcp) == 1


def test_dependencies_as_string_does_not_produce_bogus_refs(tmp_path):
    """Malformed `dependencies: "foo,bar"` must not iterate chars as dep names."""
    manifest = tmp_path / "plugin.json"
    manifest.write_text('{"name": "my-plugin", "dependencies": "foo,bar"}')
    refs = parse(manifest)
    dep_refs = [
        r
        for r in refs
        if r.component_identity and r.component_identity.startswith("claude-plugin-dep/")
    ]
    assert dep_refs == []


def test_top_level_array_does_not_raise(tmp_path):
    manifest = tmp_path / "plugin.json"
    manifest.write_text("[]")
    assert parse(manifest) == []


def test_top_level_null_does_not_raise(tmp_path):
    manifest = tmp_path / "plugin.json"
    manifest.write_text("null")
    assert parse(manifest) == []


def test_plugin_self_identity_carries_component_type_not_ecosystem():
    """Plugin is an agent component type; source ecosystem is unknown unless
    the manifest or lockfile provides a real source coordinate."""
    manifest = REPOS / "sample-plugin" / ".claude-plugin" / "plugin.json"
    refs = parse(manifest)
    plugin_self = next(r for r in refs if r.component_identity == "claude-plugin/deployment-tools")
    assert plugin_self.ecosystem is None
    assert plugin_self.extra["component_type"] == "plugin"
    assert plugin_self.name == "deployment-tools"
    assert plugin_self.version == "1.2.0"


def test_mcp_servers_string_path_resolves_from_plugin_root():
    """Plan 007 bug fix: mcpServers as a string path resolves from the plugin
    root (manifest.parent.parent), not the manifest's directory. Resolving
    from the manifest dir would land in `.claude-plugin/.mcp.json` instead
    of `<plugin-root>/.mcp.json`."""
    manifest = REPOS / "sample-plugin-string-mcp" / ".claude-plugin" / "plugin.json"
    refs = parse(manifest)
    npm_refs = [r for r in refs if r.ecosystem == "npm"]
    assert len(npm_refs) == 1
    assert npm_refs[0].name == "@example/test-mcp"
    assert npm_refs[0].version == "1.0.0"


def test_mcp_servers_absolute_path_is_skipped(tmp_path):
    """An absolute path as mcpServers string must be silently rejected.

    Python's Path division replaces the root entirely for absolute paths:
    `plugin_root / "/abs/path"` yields `/abs/path`, not something inside
    the plugin root. The resolver must detect this via is_relative_to and
    skip the file rather than reading arbitrary host paths.
    """
    external = tmp_path / "external.mcp.json"
    external.write_text(
        json.dumps({"mcpServers": {"evil": {"command": "npx", "args": ["-y", "evil-pkg"]}}})
    )
    plugin_dir = tmp_path / "myplugin" / ".claude-plugin"
    plugin_dir.mkdir(parents=True)
    manifest = plugin_dir / "plugin.json"
    manifest.write_text(
        json.dumps({"name": "abs-plugin", "version": "1.0.0", "mcpServers": str(external)})
    )
    refs = parse(manifest)
    assert sum(1 for r in refs if r.extra.get("component_type") == "plugin") == 1
    assert all(r.ecosystem != "npm" for r in refs)


def test_mcp_servers_traversal_path_is_skipped(tmp_path):
    """A relative path that escapes plugin_root via .. must be silently rejected."""
    external = tmp_path / "external.mcp.json"
    external.write_text(
        json.dumps({"mcpServers": {"evil": {"command": "npx", "args": ["-y", "evil-pkg"]}}})
    )
    plugin_dir = tmp_path / "myplugin" / ".claude-plugin"
    plugin_dir.mkdir(parents=True)
    manifest = plugin_dir / "plugin.json"
    # Traversal from <tmp>/myplugin/ up to <tmp>/ to reach external.mcp.json
    manifest.write_text(
        json.dumps(
            {"name": "trav-plugin", "version": "1.0.0", "mcpServers": "../external.mcp.json"}
        )
    )
    refs = parse(manifest)
    assert sum(1 for r in refs if r.extra.get("component_type") == "plugin") == 1
    assert all(r.ecosystem != "npm" for r in refs)


def test_plugin_non_string_version_coerced_to_none(tmp_path):
    """A plugin.json with a numeric version (e.g. `"version": 1`) must not crash.
    The non-string value is coerced to None so the ref is still emitted without
    a version rather than propagating an integer to packaging.Version."""
    manifest = tmp_path / "plugin.json"
    manifest.write_text(json.dumps({"name": "my-plugin", "version": 1}))
    refs = parse(manifest)
    plugin_self = [r for r in refs if r.extra.get("component_type") == "plugin"]
    assert len(plugin_self) == 1
    assert plugin_self[0].name == "my-plugin"
    assert plugin_self[0].version is None
    assert plugin_self[0].component_identity == "claude-plugin/my-plugin"


def test_mcp_servers_string_path_missing_target_does_not_raise(tmp_path):
    """If the string-path target file doesn't exist, the parser should
    silently skip rather than raise."""
    plugin_dir = tmp_path / ".claude-plugin"
    plugin_dir.mkdir()
    manifest = plugin_dir / "plugin.json"
    manifest.write_text(
        '{"name": "missing-mcp-plugin", "version": "0.1.0", "mcpServers": "./.mcp.json"}'
    )
    # No .mcp.json file at the plugin root → just emit the self-identity ref.
    refs = parse(manifest)
    assert any(r.extra.get("component_type") == "plugin" for r in refs)
    assert all(r.ecosystem != "npm" for r in refs)


# parse_at_install_root: endpoint-mode entry point.
# Identical inputs to repo-mode but path resolution is anchored at the
# install root rather than the manifest's parent directory.


def test_parse_at_install_root_returns_empty_when_plugin_json_absent(tmp_path):
    """No plugin.json at <install_root>/.claude-plugin/ — return []."""
    assert parse_at_install_root(tmp_path, attributed_to="claude-plugin/x@1.0") == []


def test_parse_at_install_root_emits_dependencies_with_attribution(tmp_path):
    plugin_dir = tmp_path / ".claude-plugin"
    plugin_dir.mkdir()
    (plugin_dir / "plugin.json").write_text(
        json.dumps(
            {
                "name": "p",
                "version": "1.0",
                "dependencies": ["helper-lib", {"name": "secrets-vault", "version": "2.1.0"}],
            }
        )
    )
    refs = parse_at_install_root(tmp_path, attributed_to="claude-plugin/p@1.0")
    assert len(refs) == 2
    assert all(r.attributed_to == "claude-plugin/p@1.0" for r in refs)
    identities = sorted(r.component_identity or "" for r in refs)
    assert identities == ["claude-plugin-dep/helper-lib", "claude-plugin-dep/secrets-vault@2.1.0"]


def test_parse_at_install_root_emits_inline_mcp_servers_with_attribution(tmp_path):
    plugin_dir = tmp_path / ".claude-plugin"
    plugin_dir.mkdir()
    (plugin_dir / "plugin.json").write_text(
        json.dumps(
            {
                "name": "p",
                "version": "1.0",
                "mcpServers": {"foo": {"command": "npx", "args": ["-y", "@example/foo@1.2.3"]}},
            }
        )
    )
    refs = parse_at_install_root(tmp_path, attributed_to="claude-plugin/p@1.0")
    npm_refs = [r for r in refs if r.ecosystem == "npm"]
    assert len(npm_refs) == 1
    assert npm_refs[0].attributed_to == "claude-plugin/p@1.0"


def test_parse_at_install_root_string_path_resolves_from_install_root(tmp_path):
    """A string-path mcpServers must resolve relative to install_root, not
    relative to <install_root>/.claude-plugin/. Verify by placing .mcp.json
    at <install_root>/.mcp.json (the install root) and pointing plugin.json
    at "./.mcp.json" — the repo-mode resolution would land at
    <install_root>/.claude-plugin/.mcp.json instead."""
    plugin_dir = tmp_path / ".claude-plugin"
    plugin_dir.mkdir()
    (plugin_dir / "plugin.json").write_text(
        json.dumps({"name": "p", "version": "1.0", "mcpServers": "./.mcp.json"})
    )
    # File at install root, NOT under .claude-plugin/.
    (tmp_path / ".mcp.json").write_text(
        json.dumps({"mcpServers": {"foo": {"command": "npx", "args": ["-y", "@x/y@1.0"]}}})
    )
    refs = parse_at_install_root(tmp_path, attributed_to="claude-plugin/p@1.0")
    npm_refs = [r for r in refs if r.ecosystem == "npm"]
    assert len(npm_refs) == 1
    assert npm_refs[0].name == "@x/y"
    assert npm_refs[0].attributed_to == "claude-plugin/p@1.0"


def test_parse_at_install_root_rejects_path_traversal(tmp_path):
    """A `../` in mcpServers must not escape the install root."""
    external = tmp_path / "outside.mcp.json"
    external.write_text(
        json.dumps({"mcpServers": {"evil": {"command": "npx", "args": ["-y", "evil-pkg"]}}})
    )
    install_root = tmp_path / "install"
    plugin_dir = install_root / ".claude-plugin"
    plugin_dir.mkdir(parents=True)
    (plugin_dir / "plugin.json").write_text(
        json.dumps({"name": "trav", "version": "1.0", "mcpServers": "../outside.mcp.json"})
    )
    refs = parse_at_install_root(install_root, attributed_to="claude-plugin/trav@1.0")
    assert all(r.ecosystem != "npm" for r in refs)


def test_parse_at_install_root_does_not_emit_plugin_self_identity(tmp_path):
    """The endpoint caller emits the self-identity ref from the lockfile
    (more accurate version + sha than plugin.json). This function must NOT
    also emit a self-identity ref."""
    plugin_dir = tmp_path / ".claude-plugin"
    plugin_dir.mkdir()
    (plugin_dir / "plugin.json").write_text(json.dumps({"name": "p", "version": "1.0"}))
    refs = parse_at_install_root(tmp_path, attributed_to="claude-plugin/p@1.0")
    assert all(r.ecosystem != "claude-plugin" for r in refs)
    assert refs == []  # no deps, no mcpServers → empty


def test_parse_at_install_root_skips_malformed_plugin_json(tmp_path):
    plugin_dir = tmp_path / ".claude-plugin"
    plugin_dir.mkdir()
    (plugin_dir / "plugin.json").write_text("{not json")
    assert parse_at_install_root(tmp_path, attributed_to="claude-plugin/x@1.0") == []


def test_parse_at_install_root_skips_non_object_plugin_json(tmp_path):
    plugin_dir = tmp_path / ".claude-plugin"
    plugin_dir.mkdir()
    (plugin_dir / "plugin.json").write_text("[]")
    assert parse_at_install_root(tmp_path, attributed_to="claude-plugin/x@1.0") == []
