"""Candidate overlay seeding helpers."""
