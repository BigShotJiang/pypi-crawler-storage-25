"""BPS AI Agent Core — base package for the agent ecosystem."""

__version__ = "0.1.0"

from bpsai_agent_core.agent import AgentConfig, BaseAgent
from bpsai_agent_core.card import AgentCapabilities, AgentCard, AgentProvider, AgentSkill
from bpsai_agent_core.enforcement import (
    AsyncEnforcementRule,
    EnforcementResult,
    EnforcementRule,
)
from bpsai_agent_core.hooks import PhaseHook, PhaseRegistry
from bpsai_agent_core.llm import LLMCall
from bpsai_agent_core.loop import LoopRunner
from bpsai_agent_core.quality import QualityObservation, QualityProfile
from bpsai_agent_core.tick import Phase, PhaseResult, TickContext, TickResult

__all__ = [
    "AgentConfig",
    "AgentCapabilities",
    "AgentCard",
    "AgentProvider",
    "AgentSkill",
    "AsyncEnforcementRule",
    "BaseAgent",
    "EnforcementResult",
    "EnforcementRule",
    "LLMCall",
    "LoopRunner",
    "Phase",
    "PhaseHook",
    "PhaseRegistry",
    "PhaseResult",
    "QualityObservation",
    "QualityProfile",
    "TickContext",
    "TickResult",
]
