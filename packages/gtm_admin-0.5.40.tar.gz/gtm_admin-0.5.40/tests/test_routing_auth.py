"""Tests for auth router endpoints."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

import gtm_admin.auth as auth_module
from gtm_admin.database import get_session
from gtm_admin.deps import get_current_user
from gtm_admin.models import User, UserRole
from gtm_admin.router import create_router


# Use a stable test secret so JWT tokens are verifiable within tests.
auth_module.configure("test-secret")


def _make_app() -> FastAPI:
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")
    return app


def _session_with_user(user: User | None, user_count: int = 1):
    """Return an async session factory that resolves the given user and count."""

    async def _override():
        session = AsyncMock()

        async def _mock_get(model_cls, pk):
            if model_cls is User:
                return user
            return None

        session.get = _mock_get

        result = MagicMock()
        result.scalar_one.return_value = user_count
        session.execute = AsyncMock(return_value=result)
        session.add = MagicMock()
        yield session

    return _override


def _make_client(user: User | None = None, user_count: int = 1) -> TestClient:
    app = _make_app()
    app.dependency_overrides[get_session] = _session_with_user(user, user_count)
    # Auth endpoints are mostly unauthenticated; override only where needed.
    return TestClient(app)


# ---------------------------------------------------------------------------
# GET /health
# ---------------------------------------------------------------------------


def test_health():
    client = _make_client()
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


# ---------------------------------------------------------------------------
# GET /auth/setup-status
# ---------------------------------------------------------------------------


def test_setup_status_required_when_no_users():
    client = _make_client(user_count=0)
    resp = client.get("/api/auth/setup-status")
    assert resp.status_code == 200
    assert resp.json() == {"setupRequired": True}


def test_setup_status_not_required_when_users_exist():
    client = _make_client(user_count=1)
    resp = client.get("/api/auth/setup-status")
    assert resp.status_code == 200
    assert resp.json() == {"setupRequired": False}


# ---------------------------------------------------------------------------
# POST /auth/setup
# ---------------------------------------------------------------------------


def test_setup_creates_admin_when_empty():
    app = _make_app()
    app.dependency_overrides[get_session] = _session_with_user(None, user_count=0)
    client = TestClient(app)
    resp = client.post("/api/auth/setup", json={"username": "admin", "password": "secret", "email": "a@b.com"})
    assert resp.status_code == 201
    assert resp.json() == {"username": "admin"}


def test_setup_conflicts_when_already_configured():
    # user_count > 0 means setup already happened
    app = _make_app()
    app.dependency_overrides[get_session] = _session_with_user(None, user_count=1)
    client = TestClient(app)
    resp = client.post("/api/auth/setup", json={"username": "admin", "password": "secret", "email": "a@b.com"})
    assert resp.status_code == 409


# ---------------------------------------------------------------------------
# POST /auth/token (login)
# ---------------------------------------------------------------------------


def _user_with_password(username: str, password: str) -> User:
    return User(
        username=username,
        hashed_password=auth_module.hash_password(password),
        role=UserRole.admin,
    )


def test_login_valid_credentials():
    user = _user_with_password("alice", "correct-pw")
    client = _make_client(user=user)
    resp = client.post(
        "/api/auth/token",
        data={"username": "alice", "password": "correct-pw"},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert "access_token" in body
    assert body["token_type"] == "bearer"


def test_login_wrong_password():
    user = _user_with_password("alice", "correct-pw")
    client = _make_client(user=user)
    resp = client.post(
        "/api/auth/token",
        data={"username": "alice", "password": "wrong-pw"},
    )
    assert resp.status_code == 401


def test_login_unknown_user():
    client = _make_client(user=None)
    resp = client.post(
        "/api/auth/token",
        data={"username": "nobody", "password": "pw"},
    )
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# POST /auth/register
# ---------------------------------------------------------------------------


def test_register_new_user():
    """Registering a username that doesn't exist yet should return 201."""
    app = _make_app()

    async def _session_no_existing():
        session = AsyncMock()
        # No existing user with that username
        session.get = AsyncMock(return_value=None)
        session.add = MagicMock()
        yield session

    current_user = MagicMock(username="admin")
    app.dependency_overrides[get_session] = _session_no_existing
    app.dependency_overrides[get_current_user] = lambda: current_user
    client = TestClient(app)

    resp = client.post(
        "/api/auth/register",
        data={"username": "newuser", "password": "pw"},
    )
    assert resp.status_code == 201
    assert resp.json()["username"] == "newuser"


def test_register_duplicate_user():
    """Registering a username that already exists should return 409."""
    existing = _user_with_password("bob", "pw")
    app = _make_app()

    async def _session_existing():
        session = AsyncMock()
        session.get = AsyncMock(return_value=existing)
        yield session

    app.dependency_overrides[get_session] = _session_existing
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")
    client = TestClient(app)

    resp = client.post(
        "/api/auth/register",
        data={"username": "bob", "password": "pw"},
    )
    assert resp.status_code == 409


def test_register_requires_authentication():
    """Without a valid bearer token the endpoint should return 401."""
    client = _make_client()
    resp = client.post(
        "/api/auth/register",
        data={"username": "x", "password": "y"},
    )
    assert resp.status_code == 401
