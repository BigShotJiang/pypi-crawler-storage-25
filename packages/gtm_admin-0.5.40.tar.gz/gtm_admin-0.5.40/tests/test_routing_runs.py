"""Tests for workflow-runs read endpoints (stats, list, detail).

Cancel and rerun are covered in test_cancel.py and test_rerun.py.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

from fastapi import FastAPI
from fastapi.testclient import TestClient

from gtm_admin.database import get_session
from gtm_admin.deps import get_current_user
from gtm_admin.models import TriggerType, Workflow, WorkflowRun, WorkflowStatus
from gtm_admin.router import create_router


def _build_run(
    run_id: int = 1,
    workflow_id: int = 1,
    status: WorkflowStatus = WorkflowStatus.success,
) -> WorkflowRun:
    return WorkflowRun(
        id=run_id,
        workflow_id=workflow_id,
        status=status,
        triggered_by=TriggerType.manual,
        data={"trigger_context": {}, "nodes": [], "inputs": {}, "outputs": {}},
    )


def _make_client(
    run: WorkflowRun | None = None,
    runs: list[WorkflowRun] | None = None,
    workflows: list[Workflow] | None = None,
    status_counts: list[tuple] | None = None,
):
    """Build a TestClient with a flexible mock session."""
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    _runs = runs or ([] if run is None else [run])
    _workflows = workflows or [Workflow(id=1, name="wf_one")]
    _status_counts = status_counts or []

    async def _override_session():
        session = AsyncMock()

        async def _mock_get(model_cls, pk):
            if model_cls is WorkflowRun:
                return run
            if model_cls is Workflow:
                return next((w for w in _workflows if w.id == pk), None)
            return None

        session.get = _mock_get

        exec_calls: list = []

        async def _mock_execute(stmt):
            result = MagicMock()
            idx = len(exec_calls)
            exec_calls.append(stmt)
            if idx == 0:
                # stats query: group-by status counts
                result.all.return_value = _status_counts
                result.scalar_one.return_value = len(_runs)
            else:
                result.scalar_one.return_value = len(_runs)
            return result

        # Each exec() call in an endpoint returns something different:
        # list_runs:   [0]=roots, [1]=children, [2]=workflows
        # detail run:  [0]=children, [1]=workflows  (grandchildren skipped if no children)
        # stats:       [0]=active runs, [1]=recent runs, [2]=workflows
        exec_seq = [_runs, [], _workflows, _workflows]
        exec_idx_box = [0]

        async def _mock_exec(stmt):
            r = MagicMock()
            idx = exec_idx_box[0]
            exec_idx_box[0] += 1
            data = exec_seq[idx] if idx < len(exec_seq) else []
            r.all.return_value = data
            r.first.return_value = data[0] if data else None
            return r

        session.execute = _mock_execute
        session.exec = _mock_exec

        yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")

    return TestClient(app)


# ---------------------------------------------------------------------------
# GET /workflow-runs/stats
# ---------------------------------------------------------------------------


def test_get_stats_returns_200():
    client = _make_client()
    resp = client.get("/api/workflow-runs/stats")
    assert resp.status_code == 200
    body = resp.json()
    # All WorkflowStatus variants must be present in counts
    assert "pending" in body["counts"]
    assert "running" in body["counts"]
    assert "success" in body["counts"]
    assert "failed" in body["counts"]
    assert "cancelled" in body["counts"]
    assert "active" in body
    assert "recent" in body


def _unauthenticated_client() -> TestClient:
    """Client with a mocked session but no auth override — expects 401 responses."""
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    async def _null_session():
        yield AsyncMock()

    app.dependency_overrides[get_session] = _null_session
    return TestClient(app)


def test_get_stats_requires_auth():
    resp = _unauthenticated_client().get("/api/workflow-runs/stats")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# GET /workflow-runs
# ---------------------------------------------------------------------------


def test_list_runs_returns_200_and_total_count_header():
    run = _build_run()
    client = _make_client(run=run, runs=[run])
    resp = client.get("/api/workflow-runs")
    assert resp.status_code == 200
    assert "X-Total-Count" in resp.headers


def test_list_runs_empty():
    client = _make_client(runs=[])
    resp = client.get("/api/workflow-runs")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_runs_pagination_params_accepted():
    run = _build_run()
    client = _make_client(run=run, runs=[run])
    resp = client.get("/api/workflow-runs?offset=0&limit=10")
    assert resp.status_code == 200


def test_list_runs_status_filter_accepted():
    run = _build_run(status=WorkflowStatus.success)
    client = _make_client(run=run, runs=[run])
    resp = client.get("/api/workflow-runs?status=success")
    assert resp.status_code == 200


def test_list_runs_workflow_name_filter_accepted():
    run = _build_run()
    client = _make_client(run=run, runs=[run])
    resp = client.get("/api/workflow-runs?workflow_name=wf_one")
    assert resp.status_code == 200


def test_list_runs_requires_auth():
    resp = _unauthenticated_client().get("/api/workflow-runs")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# GET /workflow-runs/{id}
# ---------------------------------------------------------------------------


def test_get_run_by_id_found():
    run = _build_run()
    client = _make_client(run=run)
    resp = client.get(f"/api/workflow-runs/{run.id}")
    assert resp.status_code == 200
    body = resp.json()
    assert body["id"] == run.id
    assert body["status"] == run.status.value


def test_get_run_by_id_not_found():
    client = _make_client(run=None)
    resp = client.get("/api/workflow-runs/9999")
    assert resp.status_code == 404


def test_get_run_by_id_requires_auth():
    resp = _unauthenticated_client().get("/api/workflow-runs/1")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# GET /execution-buckets
# ---------------------------------------------------------------------------


def test_execution_buckets_returns_200():
    client = _make_client(runs=[])
    resp = client.get("/api/execution-buckets?from=0&to=60000&step=10000")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


def test_execution_buckets_requires_auth():
    resp = _unauthenticated_client().get("/api/execution-buckets?from=0&to=60000&step=10000")
    assert resp.status_code == 401
