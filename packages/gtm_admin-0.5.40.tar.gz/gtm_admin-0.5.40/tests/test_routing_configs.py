"""Tests for config CRUD endpoints."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

from fastapi import FastAPI
from fastapi.testclient import TestClient

from gtm_admin.database import get_session
from gtm_admin.deps import get_current_user
from gtm_admin.models import ConfigRecord
from gtm_admin.router import create_router


def _build_config(cfg_id: int = 1) -> ConfigRecord:
    return ConfigRecord(
        id=cfg_id,
        key="MY_KEY",
        value="some-value",
        type="string",
    )


def _make_client(record: ConfigRecord | None = None, records: list[ConfigRecord] | None = None):
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    _records = records if records is not None else ([] if record is None else [record])

    async def _override_session():
        session = AsyncMock()

        async def _mock_get(model_cls, pk):
            if model_cls is ConfigRecord:
                return record
            return None

        session.get = _mock_get

        async def _mock_exec(stmt):
            r = MagicMock()
            r.all.return_value = _records
            return r

        session.exec = _mock_exec
        session.add = MagicMock()

        async def _mock_refresh(obj):
            # Simulate assigning an id on new records
            if obj.id is None:
                obj.id = 99

        session.refresh = _mock_refresh
        yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")
    return TestClient(app)


# ---------------------------------------------------------------------------
# GET /configs
# ---------------------------------------------------------------------------


def test_list_configs_empty():
    client = _make_client(records=[])
    resp = client.get("/api/configs")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_configs_returns_all():
    records = [_build_config(1), _build_config(2)]
    client = _make_client(records=records)
    resp = client.get("/api/configs")
    assert resp.status_code == 200
    assert len(resp.json()) == 2


def _unauthenticated_client() -> TestClient:
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    async def _null_session():
        yield AsyncMock()

    app.dependency_overrides[get_session] = _null_session
    return TestClient(app)


def test_list_configs_requires_auth():
    resp = _unauthenticated_client().get("/api/configs")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# POST /configs
# ---------------------------------------------------------------------------


def test_create_config_returns_201():
    client = _make_client()
    resp = client.post("/api/configs", json={"key": "NEW_KEY", "value": "v", "type": "string"})
    assert resp.status_code == 201
    body = resp.json()
    assert body["key"] == "NEW_KEY"


def test_create_config_requires_auth():
    resp = _unauthenticated_client().post("/api/configs", json={"key": "K", "value": "v", "type": "string"})
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# PATCH /configs/{id}
# ---------------------------------------------------------------------------


def test_update_config_not_found():
    client = _make_client(record=None)
    resp = client.patch("/api/configs/999", json={"value": "new"})
    assert resp.status_code == 404


def test_update_config_success():
    cfg = _build_config()
    client = _make_client(record=cfg)
    resp = client.patch(f"/api/configs/{cfg.id}", json={"value": "updated"})
    assert resp.status_code == 200
    assert resp.json()["value"] == "updated"


# ---------------------------------------------------------------------------
# DELETE /configs/{id}
# ---------------------------------------------------------------------------


def test_delete_config_not_found():
    client = _make_client(record=None)
    resp = client.delete("/api/configs/999")
    assert resp.status_code == 404


def test_delete_config_success():
    cfg = _build_config()
    client = _make_client(record=cfg)
    resp = client.delete(f"/api/configs/{cfg.id}")
    assert resp.status_code == 204
