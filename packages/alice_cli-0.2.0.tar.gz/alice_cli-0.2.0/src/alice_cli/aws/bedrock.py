"""Bedrock Runtime client wrapper with automatic retry logic."""

from __future__ import annotations

from typing import Any

import boto3

from alice_cli.logging import get_logger
from alice_cli.retry import with_bedrock_retry

log = get_logger(__name__)


class BedrockClient:
    """Wrapper for the boto3 bedrock-runtime client.

    Adds automatic retry logic for transient errors (throttling, service
    unavailability) using the existing ``with_bedrock_retry`` decorator from
    ``alice_cli.retry``.

    Implements the ``BedrockRuntimeClient`` protocol so it can be used
    anywhere that protocol is expected.

    Example::

        session = boto3.Session(profile_name="drcc-ai", region_name="us-east-1")
        client = BedrockClient.from_session(session)
        response = client.converse(modelId="...", messages=[...])
    """

    def __init__(self, client: Any) -> None:
        self._client = client

    @classmethod
    def from_session(cls, session: boto3.Session) -> BedrockClient:
        """Create a BedrockClient from an existing boto3 Session."""
        return cls(session.client("bedrock-runtime"))

    @classmethod
    def from_credentials(
        cls,
        access_key: str,
        secret_key: str,
        region: str,
    ) -> BedrockClient:
        """Create a BedrockClient from API key credentials."""
        session = boto3.Session(
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region,
        )
        return cls.from_session(session)

    @with_bedrock_retry
    def converse(
        self,
        *,
        modelId: str,
        messages: list[dict[str, Any]],
        inferenceConfig: dict[str, Any] | None = None,
        system: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Invoke the Converse API with automatic retry on transient errors.

        Args:
            modelId: Model ID or inference profile ARN.
            messages: List of message dicts with ``role`` and ``content``.
            inferenceConfig: Optional inference configuration (e.g. maxTokens).
            system: Optional system prompt list.
            **kwargs: Additional parameters forwarded to boto3.

        Returns:
            Response dict with ``output`` and ``usage`` keys.

        Raises:
            ClientError: If the API call fails after exhausting retries.
            BotoCoreError: On low-level connection errors after retries.
        """
        call_kwargs: dict[str, Any] = {"modelId": modelId, "messages": messages}

        if inferenceConfig is not None:
            call_kwargs["inferenceConfig"] = inferenceConfig
        if system is not None:
            call_kwargs["system"] = system
        call_kwargs.update(kwargs)

        log.debug(
            "bedrock_converse",
            model_id=modelId,
            message_count=len(messages),
            has_system=system is not None,
            max_tokens=(inferenceConfig or {}).get("maxTokens"),
        )

        response = self._client.converse(**call_kwargs)

        usage = response.get("usage", {})
        log.debug(
            "bedrock_converse_success",
            model_id=modelId,
            input_tokens=usage.get("inputTokens", 0),
            output_tokens=usage.get("outputTokens", 0),
        )

        return response  # type: ignore[no-any-return]
