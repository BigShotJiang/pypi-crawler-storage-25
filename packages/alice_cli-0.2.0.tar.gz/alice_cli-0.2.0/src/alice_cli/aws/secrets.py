"""Secrets Manager client wrapper with automatic retry logic."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from alice_cli.aws.session import get_session
from alice_cli.retry import with_secrets_retry

if TYPE_CHECKING:
    import boto3


class SecretsManagerClientWrapper:
    """Wrapper for the boto3 secretsmanager client.

    Adds automatic retry logic for transient Secrets Manager errors.

    Implements the ``SecretsManagerClient`` protocol.

    Example::

        session = boto3.Session(profile_name="drcc-ai", region_name="us-east-1")
        client = SecretsManagerClientWrapper.from_session(session)
        response = client.get_secret_value(SecretId="drcc/ai/bedrock-api-keys/jdoe@jhu.edu")
    """

    def __init__(self, client: Any) -> None:
        self._client = client

    @classmethod
    def from_session(cls, session: boto3.Session) -> SecretsManagerClientWrapper:
        """Create a SecretsManagerClientWrapper from an existing boto3 Session."""
        return cls(session.client("secretsmanager"))

    @classmethod
    def from_credentials(
        cls,
        access_key: str,
        secret_key: str,
        region: str,
    ) -> SecretsManagerClientWrapper:
        """Create a SecretsManagerClientWrapper from API key credentials."""
        session = get_session(region=region, access_key=access_key, secret_key=secret_key)
        return cls.from_session(session)

    @classmethod
    def for_profile(cls, profile: str, region: str) -> SecretsManagerClientWrapper:
        """Create using a cached session for the given SSO profile."""
        session = get_session(profile=profile, region=region)
        return cls.from_session(session)

    @with_secrets_retry
    def get_secret_value(
        self,
        *,
        SecretId: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Get a secret value with automatic retry on transient errors.

        Args:
            SecretId: The secret name or ARN.

        Returns:
            Response dict with ``SecretString`` key.

        Raises:
            ClientError: If the secret is not found or access is denied.
        """
        return self._client.get_secret_value(SecretId=SecretId, **kwargs)  # type: ignore[no-any-return]

    @with_secrets_retry
    def list_secrets(
        self,
        *,
        Filters: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List secrets with automatic retry on transient errors.

        Args:
            Filters: Optional list of filter dicts.

        Returns:
            Response dict with ``SecretList`` key.
        """
        call_kwargs: dict[str, Any] = {}
        if Filters is not None:
            call_kwargs["Filters"] = Filters
        call_kwargs.update(kwargs)
        return self._client.list_secrets(**call_kwargs)  # type: ignore[no-any-return]
