"""AWS client utilities for alice-cli."""
