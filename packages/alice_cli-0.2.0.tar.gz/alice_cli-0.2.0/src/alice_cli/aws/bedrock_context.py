"""Centralized Bedrock client creation and authentication.

Eliminates the ~60-line API-key-vs-SSO branching block that was previously
duplicated across every command that calls the Bedrock Converse API.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from alice_cli import personality
from alice_cli.auth import detect_identity_from_key, detect_jhed
from alice_cli.aws.bedrock import BedrockClient
from alice_cli.aws.session import get_session
from alice_cli.console import print_status, spinner
from alice_cli.logging import get_logger
from alice_cli.secrets import build_secret_path, fetch_credentials

if TYPE_CHECKING:
    from alice_cli.models import CLIConfig

log = get_logger(__name__)


@dataclass
class BedrockContext:
    """Authenticated context for Bedrock operations.

    Attributes:
        client: boto3 bedrock-runtime client, ready to call ``converse()``.
        jhed: User's JHED identifier (extracted from STS or API key alias).
        inference_profile_arns: Mapping of model alias → inference profile ARN.
            Pass this to ``resolve_model_id()`` when resolving model aliases.
        config: The CLI configuration used to create this context.
    """

    client: Any
    jhed: str
    inference_profile_arns: dict[str, str]
    config: CLIConfig


def create_bedrock_context(config: CLIConfig) -> BedrockContext:
    """Authenticate and return a ready-to-use Bedrock context.

    Handles both API-key mode and SSO profile mode transparently.

    **API-key mode** (``config.bedrock_secret_key`` is set, ``config.profile``
    is unset): skips STS and Secrets Manager, uses the stored key directly.

    **SSO profile mode**: calls STS ``get-caller-identity`` to detect the JHED,
    then fetches credentials from Secrets Manager to obtain inference profile ARNs.

    Args:
        config: Resolved CLI configuration.

    Returns:
        BedrockContext with authenticated client and inference profile ARNs.

    Raises:
        AuthError: If STS identity detection fails.
        SecretError: If credentials cannot be fetched from Secrets Manager.

    Example::

        context = create_bedrock_context(config)
        resolved_id = resolve_model_id(model_alias, context.inference_profile_arns)
        response = context.client.converse(modelId=resolved_id, messages=[...])
    """
    if config.bedrock_secret_key and not config.profile:
        # ── API Key Mode ──────────────────────────────────────────────────────
        jhed = detect_identity_from_key(config.bedrock_access_key)
        print_status(personality.status_using_api_key(jhed), config.quiet)
        log.debug("bedrock_context_created", auth_mode="api_key", jhed=jhed)

        session = get_session(
            region=config.region,
            access_key=config.bedrock_access_key or "",
            secret_key=config.bedrock_secret_key,
        )
        return BedrockContext(
            client=BedrockClient.from_session(session),
            jhed=jhed,
            inference_profile_arns=config.inference_profile_arns or {},
            config=config,
        )

    else:
        # ── SSO Profile Mode ──────────────────────────────────────────────────
        with spinner(personality.status_detecting_identity(), config.quiet):
            result = detect_jhed(config.profile, config.region)
        jhed = result.jhed
        print_status(personality.status_identity_detected(jhed), config.quiet)

        secret_path = build_secret_path(config.namespace, config.environment, jhed)
        assert config.profile is not None  # detect_jhed() already raised if profile is None
        with spinner(personality.status_fetching_secret(), config.quiet):
            creds = fetch_credentials(config.profile, config.region, secret_path)

        log.debug(
            "bedrock_context_created",
            auth_mode="sso",
            jhed=jhed,
            profile=config.profile,
            has_inference_profiles=bool(creds.inference_profile_arns),
        )

        session = get_session(profile=config.profile, region=config.region)
        return BedrockContext(
            client=BedrockClient.from_session(session),
            jhed=jhed,
            inference_profile_arns=creds.inference_profile_arns,
            config=config,
        )
