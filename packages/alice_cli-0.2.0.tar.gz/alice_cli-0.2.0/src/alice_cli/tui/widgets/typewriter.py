"""Typewriter-effect label widget for the ALiCE TUI."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.widgets import Static

if TYPE_CHECKING:
    from textual.timer import Timer


class Typewriter(Static):
    """Reveals text one character at a time, like an old terminal printer."""

    DEFAULT_CSS = """
    Typewriter {
        color: #FFB000;
    }
    """

    def __init__(
        self,
        text: str,
        *,
        speed: float = 0.03,
        id: str | None = None,
        classes: str | None = None,
    ) -> None:
        super().__init__("", id=id, classes=classes)
        self._full_text = text
        self._speed = speed
        self._pos = 0
        self._timer: Timer | None = None

    def on_mount(self) -> None:
        self._pos = 0
        self.update("")
        self._timer = self.set_interval(self._speed, self._reveal)

    def _reveal(self) -> None:
        self._pos += 1
        self.update(self._full_text[: self._pos] + "█")
        if self._pos >= len(self._full_text):
            if self._timer is not None:
                self._timer.stop()
            self.update(self._full_text)
