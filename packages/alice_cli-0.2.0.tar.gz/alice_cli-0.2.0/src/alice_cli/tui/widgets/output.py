"""Scrollable output panel widget for the ALiCE TUI."""

from __future__ import annotations

from textual.widgets import RichLog


class OutputPanel(RichLog):
    """Scrollable RichLog widget for displaying command output."""

    pass
