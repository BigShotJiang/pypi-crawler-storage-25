"""Persistent ALiCE header bar for TUI sub-screens."""

from __future__ import annotations

from textual.widgets import Static

from alice_cli.logo import LOGO_COMPACT


class AliceHeaderBar(Static):
    """Slim amber header bar displaying the ALiCE logo. Use on every sub-screen."""

    DEFAULT_CSS = """
    AliceHeaderBar {
        width: 100%;
        height: 1;
        background: #2A1F00;
        color: #FFD866;
        text-style: bold;
        text-align: center;
        dock: top;
    }
    """

    def __init__(self) -> None:
        super().__init__(LOGO_COMPACT)
