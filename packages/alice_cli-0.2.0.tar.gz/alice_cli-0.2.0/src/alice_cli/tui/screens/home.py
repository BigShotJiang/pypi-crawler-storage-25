"""Home screen for the ALiCE TUI — banner and verb menu."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.containers import Grid
from textual.screen import Screen
from textual.widgets import Button, Footer

from alice_cli.tui.widgets.banner import BannerWidget
from alice_cli.tui.widgets.clock import TerminalClock
from alice_cli.tui.widgets.typewriter import Typewriter

if TYPE_CHECKING:
    from textual.app import ComposeResult

# Verbs that have dedicated TUI screens
_SCREEN_VERBS = {"compose", "diagnose", "get-secret", "invoke", "status"}

# All verbs shown in the menu (17 items)
VERB_LIST: list[str] = [
    "auth",
    "chat",
    "compose",
    "dialog",
    "invoke",
    "summarize",
    "appraise",
    "batch",
    "compare",
    "recall",
    "get-secret",
    "list-models",
    "list-aliases",
    "list-secrets",
    "diagnose",
    "config",
    "status",
]


class HomeScreen(Screen[None]):
    """Landing screen with ASCII banner and verb menu."""

    DEFAULT_CSS = """
    HomeScreen Grid {
        grid-size: 3 6;
        grid-gutter: 1 2;
        align: center middle;
        padding: 1 4;
        height: auto;
    }

    HomeScreen Grid Button {
        width: 100%;
        min-width: 18;
        content-align: center middle;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
    ]

    def compose(self) -> ComposeResult:
        yield BannerWidget()
        yield Typewriter("TERMINAL READY — SELECT COMMAND", id="home-status")
        with Grid():
            for verb in VERB_LIST:
                yield Button(verb, id=f"btn-{verb}")
        yield TerminalClock()
        yield Footer()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle verb button presses."""
        verb = event.button.id
        if verb is None:
            return
        # Strip the "btn-" prefix
        verb = verb.removeprefix("btn-")

        if verb == "compose":
            from alice_cli.tui.screens.compose import ComposeScreen

            self.app.push_screen(ComposeScreen())
        elif verb == "invoke":
            from alice_cli.tui.screens.invoke import InvokeScreen

            self.app.push_screen(InvokeScreen())
        elif verb == "get-secret":
            from alice_cli.tui.screens.get_secret import GetSecretScreen

            self.app.push_screen(GetSecretScreen())
        elif verb == "status":
            from alice_cli.tui.screens.status import StatusScreen

            self.app.push_screen(StatusScreen())
        elif verb == "diagnose":
            from alice_cli.tui.screens.diagnose import DiagnoseScreen

            self.app.push_screen(DiagnoseScreen())
        else:
            self.notify(f"'{verb}' is CLI-only for now. Use: alice {verb}", severity="information")
