"""Model invocation screen for the ALiCE TUI."""

from __future__ import annotations

from typing import TYPE_CHECKING

import boto3
from botocore.exceptions import ClientError
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import Screen
from textual.widgets import Button, Footer, Input, Label, TextArea

from alice_cli.constants import DEFAULT_MAX_TOKENS
from alice_cli.models import DEFAULT_MODEL_ALIAS, MODEL_ALIASES, resolve_model_id
from alice_cli.tui.widgets.clock import TerminalClock
from alice_cli.tui.widgets.header_bar import AliceHeaderBar
from alice_cli.tui.widgets.output import OutputPanel

if TYPE_CHECKING:
    from textual.app import ComposeResult

_DEFAULT_MODEL_ID = DEFAULT_MODEL_ALIAS


class InvokeScreen(Screen[None]):
    """Interactive Bedrock model invocation screen."""

    BINDINGS = [
        Binding("escape", "pop_screen", "Back"),
    ]

    def compose(self) -> ComposeResult:
        alias_hint = "  ".join(f"{m.alias}={m.description}" for m in MODEL_ALIASES)
        yield AliceHeaderBar()
        with Vertical():
            yield Label("Invoke Bedrock Model", id="invoke-title")
            yield Label(f"Model (alias or full ID):  {alias_hint}")
            yield Input(
                value=_DEFAULT_MODEL_ID,
                placeholder="e.g. opus, haiku, sonnet, or full model ID",
                id="model-id-input",
            )
            yield Label("Prompt:")
            yield TextArea(id="prompt-input")
            yield Button("Chat", id="btn-invoke", variant="primary")
            yield OutputPanel(id="output-panel")
        yield TerminalClock()
        yield Footer()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle the Invoke button press."""
        if event.button.id != "btn-invoke":
            return
        self._invoke_model()

    def _invoke_model(self) -> None:
        """Call Bedrock runtime and display the response."""
        config = self.app.alice_config  # type: ignore[attr-defined]

        model_input = self.query_one("#model-id-input", Input)
        prompt_area = self.query_one("#prompt-input", TextArea)
        output = self.query_one("#output-panel", OutputPanel)

        model_id = resolve_model_id(model_input.value.strip())
        prompt_text = prompt_area.text.strip()

        output.clear()

        if not prompt_text:
            output.write("[#FF6600]Error: Please enter a prompt.[/]")
            return

        if not model_id:
            output.write("[#FF6600]Error: Please enter a model ID.[/]")
            return

        try:
            session = boto3.Session(
                profile_name=config.profile,
                region_name=config.region,
            )
            client = session.client("bedrock-runtime")

            response = client.converse(
                modelId=model_id,
                messages=[
                    {
                        "role": "user",
                        "content": [{"text": prompt_text}],
                    }
                ],
                inferenceConfig={"maxTokens": DEFAULT_MAX_TOKENS},
            )

            output_message = response.get("output", {}).get("message", {})
            content_blocks = output_message.get("content", [])
            text_parts = [block["text"] for block in content_blocks if "text" in block]
            output_text = "\n".join(text_parts)
            output.write(output_text)
        except ClientError as exc:
            output.write(f"[#FF6600]Error: Bedrock API error: {exc}[/]")
        except Exception as exc:
            output.write(f"[#FF6600]Unexpected error: {exc}[/]")
