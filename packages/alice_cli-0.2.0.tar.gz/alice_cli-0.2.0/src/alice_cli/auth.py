"""JHED detection from STS/SSO caller identity."""

from __future__ import annotations

from botocore.exceptions import BotoCoreError, ClientError

from alice_cli import personality
from alice_cli.aws.session import get_session
from alice_cli.aws.sts import STSClientWrapper
from alice_cli.errors import AuthError
from alice_cli.logging import get_logger
from alice_cli.models import JHEDResult

log = get_logger(__name__)


def detect_identity_from_key(access_key: str | None) -> str:
    """Extract a display name from the Bedrock access key alias.

    The ``BEDROCK_ACCESS_KEY`` (``service_credential_alias``) follows the
    pattern ``BedrockAPIKey-<JHED>-at-<ACCOUNT>``.  We extract the JHED
    portion when the pattern matches, otherwise return the raw value.

    Returns ``"unknown"`` when the access key is empty / absent.
    """
    if not access_key:
        log.debug("identity_detection_failed", reason="empty_access_key")
        return "unknown"

    # Pattern: BedrockAPIKey-<jhed>-at-<account_id>
    if access_key.startswith("BedrockAPIKey-") and "-at-" in access_key:
        jhed = access_key.removeprefix("BedrockAPIKey-").split("-at-", maxsplit=1)[0]
        log.debug("identity_detected_from_key", jhed=jhed, method="api_key")
        return jhed

    log.debug("identity_passthrough", access_key_prefix=access_key[:15])
    return access_key


def detect_jhed(profile: str | None, region: str) -> JHEDResult:
    """Call STS get-caller-identity and extract the JHED from the ARN session name.

    Args:
        profile: AWS CLI profile name, or None if not provided.
        region: AWS region to use for the STS call.

    Returns:
        JHEDResult with jhed, session_name, and full ARN.

    Raises:
        AuthError: If no profile is provided, STS call fails, or JHED cannot be extracted.
    """
    if profile is None:
        log.warning("auth_failed", reason="no_profile")
        raise AuthError(personality.error_no_profile())

    log.debug("sts_call_starting", profile=profile, region=region)
    try:
        session = get_session(profile=profile, region=region)
        sts = STSClientWrapper.from_session(session)
        identity = sts.get_caller_identity()
    except (ClientError, BotoCoreError) as exc:
        from alice_cli.error_handler import extract_aws_error, handle_sts_error

        error = extract_aws_error(exc)
        log.error("sts_call_failed", profile=profile, region=region, **error.to_dict())
        raise handle_sts_error(exc, profile=profile) from exc

    arn: str = identity["Arn"]
    # ARN format: arn:aws:sts::ACCOUNT:assumed-role/ROLE/session_name
    session_name = arn.rsplit("/", maxsplit=1)[-1]

    if "@" not in session_name:
        log.warning("jhed_extraction_failed", session_name=session_name, arn=arn)
        raise AuthError(personality.error_jhed_extraction(session_name))

    jhed = session_name.split("@", maxsplit=1)[0]
    log.info("auth_success", jhed=jhed, profile=profile, region=region, method="sso")

    return JHEDResult(jhed=jhed, session_name=session_name, arn=arn)
