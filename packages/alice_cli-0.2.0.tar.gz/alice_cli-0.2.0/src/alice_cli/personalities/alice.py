"""Alice personality — the warm, Wonderland-themed default voice."""

from __future__ import annotations

from alice_cli.logo import LOGO


class AlicePersonality:
    """Original ALiCE voice. Friendly, warm, research-companion energy."""

    name = "alice"

    @property
    def banner(self) -> str:
        return LOGO

    # --- Greetings ---
    def greeting(self, jhed: str) -> str:
        return f"Hello, {jhed}! ALiCE here — let me grab your credentials."

    # --- Success ---
    @property
    def success_key_retrieved(self) -> str:
        return "Your Bedrock key is ready. Happy researching!"

    @property
    def success_claude_launch(self) -> str:
        return "Launching Claude Code for you — enjoy the ride."

    @property
    def success_agent_composed(self) -> str:
        return "Your Strands agent is ready to go. Happy building!"

    # --- Errors ---
    def error_no_profile(self) -> str:
        return (
            "I need an AWS profile or a Bedrock API key to get started.\n"
            "  Use --profile <NAME>, set AWS_PROFILE, or provide --api-key / BEDROCK_API_KEY."
        )

    def error_sso_expired(self, profile: str) -> str:
        return (
            f"Your SSO session seems to have expired.\n"
            f"  Run: aws sso login --profile {profile}\n"
            f"  Then try again — I'll be right here."
        )

    def error_jhed_extraction(self, session_name: str) -> str:
        return (
            f"I couldn't figure out your JHED from the session: {session_name}\n"
            "  This usually means the SSO session name isn't in the expected email format."
        )

    def error_revoked(self) -> str:
        return (
            "It looks like your Bedrock access has been revoked.\n"
            "  Reach out to the DRCC team to get this sorted out."
        )

    def error_empty_credential(self) -> str:
        return (
            "Your secret exists but the credential is empty — it may need rotation.\n"
            "  Contact the DRCC team for help."
        )

    def error_secret_not_found(self, secret_path: str) -> str:
        return (
            f"I couldn't find a secret at: {secret_path}\n"
            "  Make sure your email is in the staff list and your SSO session is active."
        )

    def error_dependency_missing(self, name: str, install_hint: str) -> str:
        return (
            f"I need '{name}' to continue, but it's not installed.\n"
            f"  Install it with: {install_hint}"
        )

    def error_python_version(self, current: str, minimum: str) -> str:
        return (
            f"Python {minimum}+ is required, but you're running {current}.\n"
            "  Please upgrade Python and try again."
        )

    def error_claude_not_found(self) -> str:
        return (
            "I can't find 'claude' on your PATH.\n"
            "  Install Claude Code first: https://docs.anthropic.com/en/docs/claude-code"
        )

    def error_no_inference_profile(self, alias: str) -> str:
        return (
            f"No inference profile found for '{alias}' in your credentials.\n"
            "  Run 'alice list-aliases' to see available models, or pass a full model ID."
        )

    def error_cheshire_gate_not_configured(self) -> str:
        return (
            "Cheshire Gate is not configured.\n"
            "  Ask your admin to deploy the cheshire-gate Terraform module,\n"
            "  or check that the SSM parameters exist under /<namespace>/<env>/cheshire-gate/."
        )

    # --- Hints ---
    @property
    def hint_font(self) -> str:
        return "For the best experience, set your terminal font to " "Source Code Pro or Fira Code."

    @property
    def hint_eval_usage(self) -> str:
        return "Tip: eval $(alice get-key --eval) loads credentials into your shell."

    @property
    def hint_claude_shortcut(self) -> str:
        return "Tip: alice auth --claude launches Claude Code in one step."

    # --- Status ---
    def status_detecting_identity(self) -> str:
        return "Checking your identity..."

    def status_fetching_secret(self) -> str:
        return "Fetching your Bedrock credentials..."

    def status_identity_detected(self, jhed: str) -> str:
        return f"Detected identity: {jhed}"

    def status_invoking_model(self, model_id: str) -> str:
        return f"Thinking… (model: [bold]{model_id}[/bold])"

    def status_model_ready(self, model_id: str) -> str:
        return f"Response from [bold]{model_id}[/bold]"

    def status_resolved_profile(self, alias: str) -> str:
        return f"Using inference profile for [bold]{alias}[/bold]"

    def status_fetching_models(self) -> str:
        return "Fetching available foundation models…"

    def status_checking_session(self) -> str:
        return "Checking SSO session…"

    def status_using_api_key(self, identity: str = "") -> str:
        if identity and identity != "unknown":
            return f"Using Bedrock API key as [bold]{identity}[/bold]"
        return "Using Bedrock API key"

    def status_checking_quota(self) -> str:
        return "Peeking through the Cheshire Gate…"

    # --- Compose ---
    def compose_greeting(self) -> str:
        return "Let's build an agent together — I'll walk you through it."

    # --- Quota ---
    def quota_no_usage(self, period: str) -> str:
        return f"No token usage recorded for {period} — the gate is wide open."

    def quota_summary(self, total_tokens: int, request_count: int) -> str:
        return f"{total_tokens:,} tokens across {request_count:,} requests this period."

    def quota_exceeded(self, used: int, limit: int) -> str:
        return (
            f"You've used {used:,} of your {limit:,} token quota.\n"
            "  The Cheshire Cat has blocked the path — contact your admin for a limit increase."
        )
