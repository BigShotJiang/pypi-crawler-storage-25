"""alice quota — Check your Cheshire Gate token usage and remaining budget."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import boto3
import click
from botocore.exceptions import BotoCoreError, ClientError

from alice_cli import personality
from alice_cli.auth import detect_identity_from_key, detect_jhed
from alice_cli.console import (
    err_console,
    print_banner,
    print_status,
    print_success,
    spinner,
)
from alice_cli.errors import AliceCLIError

if TYPE_CHECKING:
    from alice_cli.models import CLIConfig


def _resolve_quota_table(config: CLIConfig) -> str:
    """Discover the Cheshire Gate DynamoDB table name via SSM."""
    ssm_name = f"/{config.namespace}/{config.environment}/cheshire-gate/quota-table"
    try:
        session = boto3.Session(profile_name=config.profile, region_name=config.region)
        ssm = session.client("ssm")
        resp = ssm.get_parameter(Name=ssm_name)
        return str(resp["Parameter"]["Value"])
    except (ClientError, BotoCoreError) as exc:
        raise AliceCLIError(
            f"Could not find Cheshire Gate quota table via SSM ({ssm_name}).\n"
            f"  Is the cheshire-gate module deployed? Error: {exc}"
        ) from exc


def _get_usage(config: CLIConfig, table_name: str, user_id: str, period: str) -> dict[str, Any]:
    """Read the user's token usage from DynamoDB."""
    try:
        session = boto3.Session(profile_name=config.profile, region_name=config.region)
        dynamodb = session.resource("dynamodb")
        table = dynamodb.Table(table_name)
        resp = table.get_item(Key={"user_id": user_id, "period": period})
        item: dict[str, Any] = resp.get("Item", {})
        return item
    except (ClientError, BotoCoreError) as exc:
        raise AliceCLIError(f"Could not read quota table: {exc}") from exc


@click.command("quota")
@click.option("--period", default=None, help="Period to check (YYYY-MM, default: current month)")
@click.pass_context
def quota_cmd(ctx: click.Context, period: str | None) -> None:
    """View your token usage and remaining quota.

    \b
    Examples:
        alice quota
        alice quota --period 2026-02
    """
    config: CLIConfig = ctx.obj["config"]
    print_banner(personality.BANNER, config.quiet)

    # Resolve identity
    if config.bedrock_secret_key and not config.profile:
        user_id = detect_identity_from_key(config.bedrock_access_key)
        print_status(personality.status_using_api_key(user_id), config.quiet)
    else:
        with spinner(personality.status_detecting_identity(), config.quiet):
            result = detect_jhed(config.profile, config.region)
        user_id = result.jhed
        print_status(personality.status_identity_detected(user_id), config.quiet)

    # Resolve period
    resolved_period = period or datetime.now(UTC).strftime("%Y-%m")

    # Discover table and fetch usage
    with spinner(personality.status_checking_quota(), config.quiet):
        table_name = _resolve_quota_table(config)
        usage = _get_usage(config, table_name, user_id, resolved_period)

    input_tokens = int(usage.get("input_tokens", 0))
    output_tokens = int(usage.get("output_tokens", 0))
    total_tokens = input_tokens + output_tokens
    request_count = int(usage.get("request_count", 0))
    last_updated = usage.get("last_updated", "never")

    # Display
    err_console.print()
    err_console.print("  [bold]Cheshire Gate — Token Usage[/bold]")
    err_console.print(f"  User:          [cyan]{user_id}[/cyan]")
    err_console.print(f"  Period:        {resolved_period}")
    err_console.print()
    err_console.print(f"  Input tokens:  {input_tokens:>12,}")
    err_console.print(f"  Output tokens: {output_tokens:>12,}")
    err_console.print(f"  Total tokens:  {total_tokens:>12,}")
    err_console.print(f"  Requests:      {request_count:>12,}")
    err_console.print(f"  Last activity: {last_updated}")
    err_console.print()

    if total_tokens == 0:
        print_status(personality.quota_no_usage(resolved_period), config.quiet)
    else:
        print_success(personality.quota_summary(total_tokens, request_count), config.quiet)
