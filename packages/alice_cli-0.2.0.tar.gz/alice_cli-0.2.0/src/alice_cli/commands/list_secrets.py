"""alice list-secrets — List secrets under the current namespace/environment."""

from __future__ import annotations

import boto3
import click
from botocore.exceptions import ClientError

from alice_cli import personality
from alice_cli.auth import detect_jhed
from alice_cli.console import print_banner, print_status, print_table
from alice_cli.errors import AliceCLIError


def _is_visible_to_user(secret_name: str, jhed: str) -> bool:
    """Determine whether a secret should be visible to the authenticated user.

    Secrets under the ``bedrock-api-keys/`` subtree are only visible if they
    belong to the current user (i.e. the name contains the user's JHED).
    All other secrets are visible to everyone.
    """
    marker = "/bedrock-api-keys/"
    if marker not in secret_name:
        return True
    # Extract the portion after the marker and check ownership
    idx = secret_name.find(marker)
    after_marker = secret_name[idx + len(marker) :]
    return after_marker.startswith(f"{jhed}@")


@click.command("list-secrets")
@click.pass_context
def list_secrets(ctx: click.Context) -> None:
    """List secrets in the current namespace."""
    config = ctx.obj["config"]

    print_banner(personality.BANNER, config.quiet)

    # Detect the current user's JHED for filtering
    jhed_result = detect_jhed(config.profile, config.region)

    prefix = f"{config.namespace}/{config.environment}/"
    print_status(f"Listing secrets under: {prefix}", config.quiet)

    session = boto3.Session(profile_name=config.profile, region_name=config.region)
    client = session.client("secretsmanager")

    secrets: list[dict[str, str]] = []
    try:
        paginator = client.get_paginator("list_secrets")
        for page in paginator.paginate(
            Filters=[{"Key": "name", "Values": [prefix]}],
        ):
            for secret in page.get("SecretList", []):
                name = secret.get("Name", "")

                # Filter out other users' bedrock-api-keys
                if not _is_visible_to_user(name, jhed_result.jhed):
                    continue

                last_changed = secret.get("LastChangedDate", "")
                # Format datetime if present
                if hasattr(last_changed, "strftime"):
                    last_changed = last_changed.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    last_changed = str(last_changed)
                secrets.append({"name": name, "last_changed": last_changed})
    except ClientError as exc:
        raise AliceCLIError(f"Secrets Manager error: {exc}") from exc

    rows = [[s["name"], s["last_changed"]] for s in secrets]

    print_table(
        title=f"Secrets under {prefix}",
        columns=["Name", "Last Changed"],
        rows=rows,
    )
