"""alice invoke — Invoke a Bedrock model with a prompt."""

from __future__ import annotations

import click
from botocore.exceptions import BotoCoreError, ClientError

from alice_cli import personality
from alice_cli.aws.bedrock_context import create_bedrock_context
from alice_cli.console import (
    err_console,
    print_banner,
    print_rule,
    print_status,
    print_success,
    spinner,
)
from alice_cli.constants import DEFAULT_MAX_TOKENS
from alice_cli.errors import AliceCLIError
from alice_cli.logging import get_logger
from alice_cli.models import DEFAULT_MODEL_ALIAS, SaveFormat, model_help_text, resolve_model_id
from alice_cli.save import save_session

log = get_logger(__name__)


@click.command("invoke", context_settings={"ignore_unknown_options": True})
@click.option("--model-id", default=DEFAULT_MODEL_ALIAS, help=model_help_text())
@click.option(
    "-o",
    "--output",
    "save_path",
    default=None,
    type=click.Path(),
    help="Write session output to a local file",
)
@click.option(
    "-f",
    "--format",
    "fmt",
    default="markdown",
    type=click.Choice(["markdown", "json", "text"], case_sensitive=False),
    help="Output file format (default: markdown)",
)
@click.argument("prompt", nargs=-1, type=click.UNPROCESSED, required=True)
@click.pass_context
def invoke_cmd(
    ctx: click.Context, model_id: str, save_path: str | None, fmt: str, prompt: tuple[str, ...]
) -> None:
    """Send a prompt to a Bedrock model."""
    config = ctx.obj["config"]

    prompt_text = " ".join(prompt).strip()
    if not prompt_text:
        raise AliceCLIError("Please provide a prompt after the options.")

    print_banner(personality.BANNER, config.quiet)

    # ── Authenticate and build Bedrock client ─────────────────────────────────
    context = create_bedrock_context(config)
    resolved_id = resolve_model_id(model_id, context.inference_profile_arns)
    if resolved_id != model_id:
        print_status(personality.status_resolved_profile(model_id), config.quiet)
        log.debug("model_resolved_to_profile", alias=model_id, resolved=resolved_id)

    # ── Invoke model ──────────────────────────────────────────────────────────
    log.debug(
        "bedrock_invoke_starting",
        model_alias=model_id,
        model_id=resolved_id,
        prompt_length=len(prompt_text),
        jhed=context.jhed,
    )
    with spinner(personality.status_invoking_model(model_id), config.quiet):
        try:
            response = context.client.converse(
                modelId=resolved_id,
                messages=[{"role": "user", "content": [{"text": prompt_text}]}],
                inferenceConfig={"maxTokens": DEFAULT_MAX_TOKENS},
            )
            log.info(
                "bedrock_invoke_success",
                model_id=resolved_id,
                input_tokens=response.get("usage", {}).get("inputTokens", 0),
                output_tokens=response.get("usage", {}).get("outputTokens", 0),
            )
        except (ClientError, BotoCoreError) as exc:
            from alice_cli.error_handler import extract_aws_error, handle_bedrock_error

            error = extract_aws_error(exc)
            log.error("bedrock_invoke_failed", model_id=resolved_id, **error.to_dict())
            raise handle_bedrock_error(exc, model_id=resolved_id) from exc

    # Parse and display response
    output_message = response.get("output", {}).get("message", {})
    content_blocks = output_message.get("content", [])
    text_parts = [block["text"] for block in content_blocks if "text" in block]
    output_text = "\n".join(text_parts)

    log.debug("response_parsed", response_length=len(output_text))

    print_success(personality.status_model_ready(model_id), config.quiet)
    print_rule(config.quiet)
    if output_text.strip():
        from rich.markdown import Markdown

        err_console.print(Markdown(output_text))
    else:
        err_console.print("[dim](empty response)[/dim]")

    if save_path:
        save_session(
            path=save_path,
            prompt=prompt_text,
            model=model_id,
            content=output_text,
            quiet=config.quiet,
            fmt=SaveFormat(fmt.lower()),
        )
