"""AgentCore Memory client wrapping STM and LTM operations.

Provides :class:`MemoryClient` — a thin wrapper around the ``bedrock-agentcore``
Memory SDK that isolates SDK specifics and enables graceful degradation when the
service is unreachable or the memory resource is not active.
"""

from __future__ import annotations

import logging
from typing import Any

from alice_cli.agentcore_deps import require_agentcore
from alice_cli.errors import MemoryError

logger = logging.getLogger(__name__)


class MemoryClient:
    """Wraps AgentCore Memory SDK for STM and LTM operations.

    Parameters
    ----------
    memory_name:
        Name of the AgentCore Memory resource (e.g. ``alice-memory``).
    region:
        AWS region for the AgentCore Memory service.
    """

    def __init__(self, memory_name: str, region: str) -> None:
        require_agentcore()
        self._memory_name = memory_name
        self._region = region
        self._client = self._create_client()

    def _create_client(self) -> Any:
        """Create the AgentCore Memory SDK client."""
        try:
            from bedrock_agentcore.memory import AgentCoreMemory  # type: ignore[import-not-found]

            return AgentCoreMemory(
                memory_name=self._memory_name,
                region=self._region,
            )
        except Exception as exc:
            raise MemoryError(
                f"Failed to create AgentCore Memory client for '{self._memory_name}': {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # STM operations
    # ------------------------------------------------------------------

    def store_event(self, session_id: str, role: str, content: str) -> None:
        """Store a conversation event (user or assistant message) in STM.

        Parameters
        ----------
        session_id:
            UUID4 identifying the conversation session.
        role:
            Message role — ``"user"`` or ``"assistant"``.
        content:
            The message text.
        """
        try:
            self._client.store_event(
                session_id=session_id,
                role=role,
                content=content,
            )
        except Exception as exc:
            raise MemoryError(f"Failed to store STM event: {exc}") from exc

    def get_events(self, session_id: str) -> list[dict[str, Any]]:
        """Retrieve all STM events for a session, ordered chronologically.

        Returns an empty list if the session has no events or the service is
        unreachable.
        """
        try:
            events = self._client.get_events(session_id=session_id)
            return list(events) if events else []
        except Exception as exc:
            logger.warning("Failed to retrieve STM events for session %s: %s", session_id, exc)
            return []

    def delete_events(self, session_id: str) -> None:
        """Delete all STM events for a session."""
        try:
            self._client.delete_events(session_id=session_id)
        except Exception as exc:
            raise MemoryError(
                f"Failed to delete STM events for session {session_id}: {exc}"
            ) from exc

    def list_sessions(self) -> list[dict[str, Any]]:
        """List all sessions with their metadata (session ID, timestamp, message count).

        Returns an empty list if no sessions exist or the service is unreachable.
        """
        try:
            sessions = self._client.list_sessions()
            return list(sessions) if sessions else []
        except Exception as exc:
            logger.warning("Failed to list sessions: %s", exc)
            return []

    # ------------------------------------------------------------------
    # LTM operations
    # ------------------------------------------------------------------

    def store_fact(self, text: str) -> None:
        """Store a fact or knowledge item in long-term memory.

        Raises :class:`MemoryError` if the memory resource lacks LTM strategies.
        """
        try:
            self._client.store_fact(text=text)
        except Exception as exc:
            msg = str(exc)
            if "strategy" in msg.lower() or "ltm" in msg.lower():
                raise MemoryError(
                    "LTM requires memory strategies to be configured on the memory resource. "
                    "Set up LTM strategies before using 'thread remember'."
                ) from exc
            raise MemoryError(f"Failed to store LTM fact: {exc}") from exc

    def search_facts(self, query: str, limit: int = 10) -> list[dict[str, Any]]:
        """Perform semantic search over stored LTM facts.

        Returns results ordered by relevance score (descending). Returns an
        empty list if no facts match or the service is unreachable.
        """
        try:
            results = self._client.search_facts(query=query, limit=limit)
            return list(results) if results else []
        except Exception as exc:
            logger.warning("Failed to search LTM facts: %s", exc)
            return []

    def clear_facts(self) -> None:
        """Clear all LTM facts from the memory resource."""
        try:
            self._client.clear_facts()
        except Exception as exc:
            raise MemoryError(f"Failed to clear LTM facts: {exc}") from exc

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def check_status(self) -> str:
        """Check the status of the Memory resource.

        Returns the status string (e.g. ``"ACTIVE"``).

        Raises :class:`MemoryError` if the resource is not ACTIVE or
        unreachable, with instructions to create it.
        """
        try:
            status = self._client.check_status()
            if status != "ACTIVE":
                raise MemoryError(
                    f"Memory resource '{self._memory_name}' is in state '{status}'. "
                    "It must be ACTIVE before use. "
                    "Create it with: agentcore memory create"
                )
            return str(status)
        except MemoryError:
            raise
        except Exception as exc:
            raise MemoryError(
                f"Memory resource '{self._memory_name}' is not reachable: {exc}. "
                "Create it with: agentcore memory create"
            ) from exc
