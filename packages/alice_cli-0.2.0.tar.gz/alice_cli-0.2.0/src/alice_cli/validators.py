"""Dependency checks for the alice CLI.

Validates that required external tools and Python version are available
before the CLI attempts operations that depend on them.
"""

from __future__ import annotations

import shutil
import sys

from alice_cli import personality
from alice_cli.errors import DependencyError


def check_aws_cli() -> None:
    """Raise DependencyError if the ``aws`` CLI is not on PATH."""
    if shutil.which("aws") is None:
        raise DependencyError(
            personality.error_dependency_missing("aws", "https://aws.amazon.com/cli/")
        )


def check_jq() -> None:
    """Raise DependencyError if ``jq`` is not on PATH."""
    if shutil.which("jq") is None:
        raise DependencyError(
            personality.error_dependency_missing("jq", "https://jqlang.github.io/jq/download/")
        )


def check_python_version() -> None:
    """Raise DependencyError if Python is older than 3.12."""
    if sys.version_info < (3, 12):  # noqa: UP036
        raise DependencyError(
            "Python 3.12 or higher is required. "
            f"You are running Python {sys.version_info.major}.{sys.version_info.minor}."
        )
