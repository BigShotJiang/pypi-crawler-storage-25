"""Secrets Manager credential retrieval and validation."""

from __future__ import annotations

import json
from typing import Any

from botocore.exceptions import BotoCoreError, ClientError
from cachetools import TTLCache, cached  # type: ignore[import-untyped,unused-ignore]

from alice_cli import personality
from alice_cli.aws.secrets import SecretsManagerClientWrapper
from alice_cli.aws.session import get_session
from alice_cli.errors import SecretError
from alice_cli.logging import get_logger
from alice_cli.models import CredentialSet
from alice_cli.retry import with_secrets_retry

log = get_logger(__name__)

# Cache inference profile ARNs for 5 minutes
_inference_profile_cache: TTLCache[str, dict[str, str]] = TTLCache(maxsize=20, ttl=300)


def build_secret_path(namespace: str, environment: str, jhed: str) -> str:
    """Construct the Secrets Manager path for a JHED's Bedrock API key.

    Args:
        namespace: Organizational prefix (e.g. "drcc").
        environment: Deployment stage (e.g. "ai").
        jhed: The user's JHED identifier.

    Returns:
        The full secret path: {namespace}/{environment}/bedrock-api-keys/{jhed}@jhu.edu
    """
    return f"{namespace}/{environment}/bedrock-api-keys/{jhed}@jhu.edu"


@cached(_inference_profile_cache)  # type: ignore[untyped-decorator,misc,unused-ignore]
def fetch_inference_profiles(
    access_key: str, secret_key: str, region: str, secret_path: str
) -> dict[str, str]:
    """Retrieve inference profile ARNs from Secrets Manager using API key credentials.

    Results are cached for 5 minutes to reduce API calls.
    Returns an empty dict if the secret cannot be read or has no ARNs.

    Args:
        access_key: AWS access key ID
        secret_key: AWS secret access key
        region: AWS region
        secret_path: Secret path in Secrets Manager

    Returns:
        Dict mapping model aliases to inference profile ARNs
    """
    try:
        session = get_session(region=region, access_key=access_key, secret_key=secret_key)
        client = session.client("secretsmanager")
        response = client.get_secret_value(SecretId=secret_path)
        secret: dict[str, Any] = json.loads(response["SecretString"])
        arns: dict[str, str] = secret.get("inference_profile_arns", {})
        return arns
    except (ClientError, BotoCoreError, json.JSONDecodeError, KeyError):
        return {}


def _fetch_secret_json(profile: str, region: str, secret_path: str) -> dict[str, Any]:
    """Retrieve and parse a secret's JSON payload.

    Returns the parsed dict. Raises SecretError on failure.
    """
    try:
        session = get_session(profile=profile, region=region)
        client = SecretsManagerClientWrapper.from_session(session)
        response = client.get_secret_value(SecretId=secret_path)
    except (ClientError, BotoCoreError) as exc:
        from alice_cli.error_handler import handle_secrets_error

        raise handle_secrets_error(exc, secret_path=secret_path) from exc

    result: dict[str, Any] = json.loads(response["SecretString"])
    return result


@with_secrets_retry
def fetch_credentials(profile: str, region: str, secret_path: str) -> CredentialSet:
    """Retrieve and validate Bedrock credentials from Secrets Manager.

    Automatically retries on transient AWS errors with exponential backoff.

    Args:
        profile: AWS CLI profile name.
        region: AWS region for the Secrets Manager call.
        secret_path: Full secret path in Secrets Manager.

    Returns:
        A CredentialSet with the parsed credentials.

    Raises:
        SecretError: If the secret is not found, revoked, or has an empty credential after retries.
    """
    log.debug("fetch_credentials_starting", secret_path=secret_path, profile=profile, region=region)
    try:
        session = get_session(profile=profile, region=region)
        client = SecretsManagerClientWrapper.from_session(session)
        response = client.get_secret_value(SecretId=secret_path)
        log.info("credentials_fetched", secret_path=secret_path)
    except (ClientError, BotoCoreError) as exc:
        from alice_cli.error_handler import extract_aws_error, handle_secrets_error

        error = extract_aws_error(exc)
        log.error("fetch_credentials_failed", secret_path=secret_path, **error.to_dict())
        raise handle_secrets_error(exc, secret_path=secret_path) from exc

    raw_json: str = response["SecretString"]
    secret = json.loads(raw_json)

    if secret.get("status") == "REVOKED":
        log.warning("credentials_revoked", secret_path=secret_path)
        raise SecretError(personality.error_revoked())

    credential_secret = secret.get("service_credential_secret", "")
    if not credential_secret:
        raise SecretError(personality.error_empty_credential())

    return CredentialSet(
        bearer_token=credential_secret,
        access_key=secret.get("service_credential_alias", ""),
        secret_key=credential_secret,
        region=secret.get("region", region),
        status=secret.get("status", ""),
        raw_json=raw_json,
        inference_profile_arns=secret.get("inference_profile_arns", {}),
    )
