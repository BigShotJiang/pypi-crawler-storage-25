"""Rich console instance and output helpers.

All UX output goes to stderr; stdout is reserved for machine-readable data.
Every helper respects the ``quiet`` flag except :func:`print_error`, which
always prints because errors should never be silenced.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table

if TYPE_CHECKING:
    from collections.abc import Iterator

# Shared console bound to stderr — all informational output goes here.
err_console = Console(stderr=True)


def print_banner(banner: str, quiet: bool) -> None:
    """Print the ASCII art banner unless quiet mode is active."""
    if not quiet:
        err_console.print(banner, style="bold blue")


def print_status(message: str, quiet: bool) -> None:
    """Print a status message to stderr unless quiet mode is active."""
    if not quiet:
        err_console.print(f"  [dim]→[/dim] {message}")


def print_success(message: str, quiet: bool) -> None:
    """Print a success message to stderr unless quiet mode is active."""
    if not quiet:
        err_console.print(f"  [green]✓[/green] {message}")


def print_error(message: str) -> None:
    """Print an error panel to stderr. Errors always print regardless of quiet mode."""
    err_console.print(Panel(message, title="[red]Error[/red]", border_style="red"))


def print_table(title: str, columns: list[str], rows: list[list[str]]) -> None:
    """Print a Rich table to stderr. Used by list-models, config, list-secrets."""
    table = Table(title=title)
    for col in columns:
        table.add_column(col)
    for row in rows:
        table.add_row(*row)
    err_console.print(table)


def print_rule(quiet: bool) -> None:
    """Print a horizontal rule to stderr unless quiet mode is active."""
    if not quiet:
        err_console.print(Rule(style="dim"))


@contextmanager
def spinner(message: str, quiet: bool) -> Iterator[None]:
    """Show a Rich spinner while a block executes.

    In quiet mode the spinner is suppressed entirely.
    """
    if quiet:
        yield
    else:
        with err_console.status(f"  {message}", spinner="dots"):
            yield
