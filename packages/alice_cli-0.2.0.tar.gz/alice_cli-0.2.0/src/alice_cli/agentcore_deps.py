"""Lazy-import helpers for the optional ``bedrock-agentcore`` SDK.

Every AgentCore command calls :func:`require_agentcore` at the top of its
handler so that users who never touch AgentCore features pay zero import cost.
This mirrors the pattern used in ``cli.py`` for the ``textual`` TUI extra.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import types

from alice_cli.errors import AliceCLIError


def require_agentcore() -> None:
    """Raise :class:`AliceCLIError` if ``bedrock-agentcore`` is not installed."""
    try:
        import bedrock_agentcore  # type: ignore[import-not-found]  # noqa: F401
    except ImportError as exc:
        raise AliceCLIError(
            "AgentCore commands need the 'bedrock-agentcore' package.\n"
            "  Install it with: poetry install --extras agentcore"
        ) from exc


def import_agentcore() -> types.ModuleType:
    """Lazily import and return the ``bedrock_agentcore`` module.

    Calls :func:`require_agentcore` first to produce a friendly error when the
    extra is missing.
    """
    require_agentcore()
    import bedrock_agentcore  # type: ignore[import-not-found,unused-ignore]

    return bedrock_agentcore  # type: ignore[no-any-return]
