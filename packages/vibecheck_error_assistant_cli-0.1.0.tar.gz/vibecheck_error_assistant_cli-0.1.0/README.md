# VibeCheck CLI

VibeCheck runs your command, catches failures, and translates technical stderr into beginner-friendly guidance.

## Install (MVP)

From project root:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

After install, you can use the `vibecheck` command directly.

## Configure

```bash
cp .env.example .env
# edit .env and set VIBECHECK_GITHUB_TOKEN
```

## Usage

Single command mode:

```bash
vibecheck python buggy_sample.py
```

Interactive mode (tool waits in terminal):

```bash
vibecheck --shell
```

Then type commands like:

```bash
python buggy_sample.py
node buggy_advanced.js
```

Exit interactive mode with `exit` or `quit`.

## Useful Flags

```bash
vibecheck --level beginner python buggy_sample.py
vibecheck --level advanced node buggy_advanced.js
vibecheck --print-raw-error python buggy_sample.py
```

## Exit Codes

- Returns `0` when wrapped command succeeds.
- Returns wrapped command's non-zero exit code when command fails.
- Returns `2` on configuration errors.
