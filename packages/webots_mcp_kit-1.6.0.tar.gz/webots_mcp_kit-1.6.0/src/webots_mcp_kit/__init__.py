"""webots-mcp-kit package."""

__all__ = ["__version__"]

__version__ = "1.6.0"
