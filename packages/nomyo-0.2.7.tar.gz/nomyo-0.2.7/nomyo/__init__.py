"""
NOMYO Secure Python Chat Client

OpenAI-compatible secure chat client with end-to-end encryption.
"""

from .nomyo import SecureChatCompletion
from .SecureCompletionClient import (
    SecurityError,
    APIError,
    AuthenticationError,
    InvalidRequestError,
    APIConnectionError,
    ForbiddenError,
    RateLimitError,
    ServerError,
    ServiceUnavailableError
)

__all__ = [
    'SecureChatCompletion',
    'SecurityError',
    'APIError',
    'AuthenticationError',
    'InvalidRequestError',
    'APIConnectionError',
    'ForbiddenError',
    'RateLimitError',
    'ServerError',
    'ServiceUnavailableError',
]

# Import secure memory module if available; extend __all__ only for what was imported
try:
    from .SecureMemory import (
        get_memory_protection_info,
        disable_secure_memory,
        enable_secure_memory,
        secure_bytearray,
        secure_bytes,  # Deprecated, use secure_bytearray instead
        SecureBuffer
    )
    __all__ += [
        'get_memory_protection_info',
        'disable_secure_memory',
        'enable_secure_memory',
        'secure_bytearray',
        'secure_bytes',
        'SecureBuffer',
    ]
except ImportError:
    pass

__version__ = "0.2.7"
__author__ = "NOMYO AI"
__license__ = "Apache-2.0"
