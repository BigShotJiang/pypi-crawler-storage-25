"""端口占用清理工具。"""
from __future__ import annotations

import os
import subprocess
import sys


def kill_port_occupants(port: int) -> list[int]:
    """杀掉占用指定端口的外部进程（排除自身），返回已杀 PID 列表。"""
    if sys.platform == "win32":
        return _kill_port_win(port)
    return _kill_port_unix(port)


def _kill_port_win(port: int) -> list[int]:
    try:
        out = subprocess.run(
            ["netstat", "-ano"],
            capture_output=True, text=True, timeout=5,
        ).stdout
        pids: set[int] = set()
        my_pid = os.getpid()
        for line in out.splitlines():
            if f":{port}" in line and "LISTENING" in line:
                parts = line.split()
                try:
                    pid = int(parts[-1])
                    if pid not in (0, my_pid):
                        pids.add(pid)
                except (ValueError, IndexError):
                    pass
        killed = []
        for pid in pids:
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/F"],
                    capture_output=True, timeout=5,
                )
                killed.append(pid)
            except Exception:
                pass
        return killed
    except Exception:
        return []


def _kill_port_unix(port: int) -> list[int]:
    import signal as _sig

    try:
        out = subprocess.run(
            ["lsof", "-ti", f":{port}"],
            capture_output=True, text=True, timeout=5,
        ).stdout
        my_pid = os.getpid()
        pids: set[int] = set()
        for line in out.strip().splitlines():
            try:
                pid = int(line.strip())
                if pid not in (0, my_pid):
                    pids.add(pid)
            except ValueError:
                pass
        killed = []
        for pid in pids:
            try:
                os.kill(pid, _sig.SIGKILL)
                killed.append(pid)
            except Exception:
                pass
        return killed
    except Exception:
        return []
