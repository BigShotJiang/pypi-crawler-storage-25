"""丸子MCP - Cursor AI 聊天桥接工具"""

__version__ = "0.1.0"
