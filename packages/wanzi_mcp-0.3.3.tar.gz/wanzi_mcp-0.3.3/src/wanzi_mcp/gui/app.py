"""pywebview GUI 窗口：包裹本地 Web 页面。"""

from __future__ import annotations

import webview


def start_gui(port: int = 8765):
    url = f"http://localhost:{port}/"
    webview.create_window(
        "丸子 MCP",
        url,
        width=920,
        height=660,
        min_size=(640, 400),
        text_select=True,
    )
    webview.start()
