"""
agentloop-py-openai — drop-in OpenAI SDK wrapper for AgentLoop.

    from openai import OpenAI
    from agentloop import AgentLoop
    from agentloop_openai import wrap_openai

    openai = wrap_openai(
        OpenAI(),
        loop=AgentLoop(api_key="ak_..."),
    )

    # Unchanged OpenAI call — AgentLoop hooks fire automatically
    resp = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "hello"}],
        agentloop={"user_id": "u_123"},
    )

    # Streaming works the same way (added in v0.2.0):
    stream = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "hello"}],
        stream=True,
    )
    for chunk in stream:
        print(chunk.choices[0].delta.content or "", end="")

For async code, use AsyncOpenAI + wrap_async_openai:

    from openai import AsyncOpenAI
    from agentloop.aio import AsyncAgentLoop
    from agentloop_openai import wrap_async_openai

    async with AsyncAgentLoop(api_key="ak_...") as loop:
        openai = wrap_async_openai(AsyncOpenAI(), loop=loop)
        stream = await openai.chat.completions.create(..., stream=True)
        async for chunk in stream:
            ...
"""

from ._ask import (
    PerCallOptions,
    WrapOptions,
    ask_with_agentloop,
    ask_with_agentloop_async,
)
from ._streaming import AgentLoopAsyncStream, AgentLoopStream
from ._wrap import wrap_async_openai, wrap_openai

__all__ = [
    # Sync
    "wrap_openai",
    "ask_with_agentloop",
    # Async
    "wrap_async_openai",
    "ask_with_agentloop_async",
    # Streaming wrappers (exposed for users who want to construct manually)
    "AgentLoopStream",
    "AgentLoopAsyncStream",
    # Configuration
    "PerCallOptions",
    "WrapOptions",
]

__version__ = "0.2.1"
