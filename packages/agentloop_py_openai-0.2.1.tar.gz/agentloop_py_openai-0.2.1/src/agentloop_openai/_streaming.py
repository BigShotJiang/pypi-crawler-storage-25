"""
Streaming support for the OpenAI wrapper.

When the user passes stream=True to chat.completions.create, OpenAI returns
an iterator of ChatCompletionChunk objects. We wrap that iterator so:

  - The user iterates as normal (chunks arrive in real time, no buffering)
  - We accumulate content + tool calls into a complete response
  - When the stream ends, we call loop.log_turn() with the assembled answer

Both sync (Stream / AsyncStream from openai) and async iteration are supported.

Edge cases worth knowing:

  - **Partial streams** (user breaks/cancels mid-stream): logged with
    metadata.partial=True so reviewers can filter or ignore them. We log
    via __del__ and a context-manager exit hook. Not bulletproof — if
    Python exits before GC runs the partial may be lost — but covers
    the common cases.

  - **Tool calls**: rendered into the agent_response field as
    "[Called <name>(<arguments>)]" lines, in order they completed.
    Reviewers see the assistant's intent without needing to dig into
    metadata. Partial tool calls (call started but no completion event)
    are not rendered.

  - **Errors mid-stream**: if the underlying stream raises, we don't log.
    There's no "answer" to log and reviewers don't want broken records.
    The original exception propagates up to the user's code unchanged.

The streaming and non-streaming code paths share the search+inject phase
(handled by the caller) and the post-call detect_signals + log_turn phase
(this module's responsibility).
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator, Iterator

logger = logging.getLogger("agentloop.openai.streaming")


class _Accumulator:
    """Collects content chunks and tool call fragments from an OpenAI stream.

    OpenAI delivers content in `delta.content` (text fragments) and tool
    calls in `delta.tool_calls` (a list of partial tool-call deltas, each
    with an index, optional id/name/arguments fragments). We reassemble
    both during iteration; assembled output is read once at end-of-stream.
    """

    def __init__(self) -> None:
        self._text_parts: list[str] = []
        # Map from tool-call index -> {"name": str, "arguments": str, "id": str}
        # We use a dict keyed on the index OpenAI sends so out-of-order
        # fragments still assemble correctly.
        self._tool_calls: dict[int, dict[str, str]] = {}
        self._chunk_count = 0

    def absorb(self, chunk: Any) -> None:
        """Pull content + tool-call deltas out of one chunk and accumulate.

        Tolerates malformed chunks (missing fields, unexpected types) by
        skipping them. We are an observer, not a parser — the user's code
        gets the raw chunks; we just want a best-effort answer to log.
        """
        self._chunk_count += 1
        try:
            choices = getattr(chunk, "choices", None) or []
            if not choices:
                return
            delta = getattr(choices[0], "delta", None)
            if delta is None:
                return

            content = getattr(delta, "content", None)
            if isinstance(content, str) and content:
                self._text_parts.append(content)

            tool_calls = getattr(delta, "tool_calls", None)
            if tool_calls:
                for tc in tool_calls:
                    self._absorb_tool_call_fragment(tc)
        except Exception as e:  # noqa: BLE001
            # Never fail iteration because of an accumulator hiccup
            logger.debug("accumulator absorb error: %s", e)

    def _absorb_tool_call_fragment(self, fragment: Any) -> None:
        """Merge a tool-call delta fragment into the assembled tool calls."""
        try:
            idx = getattr(fragment, "index", None)
            if idx is None:
                return

            entry = self._tool_calls.setdefault(idx, {"name": "", "arguments": "", "id": ""})

            tc_id = getattr(fragment, "id", None)
            if tc_id:
                entry["id"] = tc_id

            fn = getattr(fragment, "function", None)
            if fn is not None:
                name = getattr(fn, "name", None)
                if name:
                    entry["name"] = name
                args = getattr(fn, "arguments", None)
                if isinstance(args, str):
                    entry["arguments"] += args
        except Exception as e:  # noqa: BLE001
            logger.debug("accumulator tool-call fragment error: %s", e)

    def assembled_answer(self) -> str:
        """Render the accumulated content + tool calls as one string.

        Tool calls render as "[Called <name>(<arguments>)]" lines after
        any text content. Reviewers see the agent's full intent in one field.
        Tool call arguments are pretty-printed JSON when valid, otherwise
        rendered as the raw string we received.
        """
        parts: list[str] = []
        text = "".join(self._text_parts).strip()
        if text:
            parts.append(text)

        if self._tool_calls:
            for idx in sorted(self._tool_calls.keys()):
                tc = self._tool_calls[idx]
                name = tc.get("name") or "<unknown>"
                args_raw = tc.get("arguments") or ""
                args_pretty = _pretty_args(args_raw)
                parts.append(f"[Called {name}({args_pretty})]")

        return "\n".join(parts)

    @property
    def chunk_count(self) -> int:
        return self._chunk_count


def _pretty_args(raw: str) -> str:
    """Render tool-call arguments as compact JSON if valid, else raw string."""
    if not raw:
        return ""
    try:
        return json.dumps(json.loads(raw), separators=(", ", ": "))
    except (json.JSONDecodeError, ValueError):
        # The model is partway through generating valid JSON, or it
        # decided to be creative. Show what we have rather than nothing.
        return raw


class AgentLoopStream:
    """Sync iterator wrapper around an OpenAI stream.

    Forwards every chunk to the caller. After the stream is exhausted (or
    the wrapper goes out of scope), calls loop.log_turn() once with the
    assembled answer. If the stream is consumed only partially, the turn
    is logged with metadata.partial=True so reviewers can filter.
    """

    def __init__(
        self,
        underlying_stream: Iterator[Any],
        *,
        question: str,
        memories: Any,
        config: Any,
        per_call: Any,
    ) -> None:
        self._underlying = underlying_stream
        self._question = question
        self._memories = memories
        self._config = config
        self._per_call = per_call
        self._accumulator = _Accumulator()
        self._exhausted = False
        self._logged = False
        self._errored = False

    def __iter__(self) -> "AgentLoopStream":
        return self

    def __next__(self) -> Any:
        try:
            chunk = next(self._underlying)
        except StopIteration:
            self._exhausted = True
            self._log_turn_once()
            raise
        except Exception:
            # The underlying stream raised — pass through, but mark errored
            # so we don't log a half-baked turn. Reviewers don't need to see
            # turns where the LLM call itself blew up.
            self._errored = True
            raise
        else:
            self._accumulator.absorb(chunk)
            return chunk

    def __enter__(self) -> "AgentLoopStream":
        # If the underlying stream is a context manager, enter it. OpenAI's
        # Stream class supports `with stream:` for guaranteed cleanup.
        enter = getattr(self._underlying, "__enter__", None)
        if callable(enter):
            enter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> Any:
        # Mark errored if exiting via exception, then forward to underlying.
        if exc_type is not None:
            self._errored = True
        # Log whatever we have on the way out — even partial — but only if
        # we got at least one chunk and the stream wasn't an outright error.
        self._log_turn_once()
        ex = getattr(self._underlying, "__exit__", None)
        if callable(ex):
            return ex(exc_type, exc_val, exc_tb)
        return None

    def __del__(self) -> None:
        # GC fallback — log on cleanup if the user iterated without a
        # context manager and dropped the iterator early.
        try:
            self._log_turn_once()
        except Exception:  # noqa: BLE001
            # __del__ must not raise
            pass

    # Pass-through for OpenAI Stream object methods we don't override
    def __getattr__(self, name: str) -> Any:
        return getattr(self._underlying, name)

    # ---- internal ----------------------------------------------------------

    def _log_turn_once(self) -> None:
        if self._logged or self._errored:
            return
        self._logged = True

        if self._accumulator.chunk_count == 0:
            # Nothing to log — never received a chunk.
            return

        answer = self._accumulator.assembled_answer()
        if not answer:
            # All chunks received but nothing assembled (no content, no
            # tool calls). Skip — no useful turn for reviewers.
            return

        from ._ask import _detect_and_log  # local import avoids cycle
        _detect_and_log(
            question=self._question,
            answer=answer,
            memories=self._memories,
            config=self._config,
            per_call=self._per_call,
            partial=not self._exhausted,
        )


class AgentLoopAsyncStream:
    """Async iterator wrapper. Same contract as AgentLoopStream but uses
    `async for` and `await` for both stream consumption and log_turn.
    """

    def __init__(
        self,
        underlying_stream: AsyncIterator[Any],
        *,
        question: str,
        memories: Any,
        config: Any,
        per_call: Any,
    ) -> None:
        self._underlying = underlying_stream
        self._question = question
        self._memories = memories
        self._config = config
        self._per_call = per_call
        self._accumulator = _Accumulator()
        self._exhausted = False
        self._logged = False
        self._errored = False

    def __aiter__(self) -> "AgentLoopAsyncStream":
        return self

    async def __anext__(self) -> Any:
        try:
            chunk = await self._underlying.__anext__()
        except StopAsyncIteration:
            self._exhausted = True
            await self._log_turn_once_async()
            raise
        except Exception:
            self._errored = True
            raise
        else:
            self._accumulator.absorb(chunk)
            return chunk

    async def __aenter__(self) -> "AgentLoopAsyncStream":
        enter = getattr(self._underlying, "__aenter__", None)
        if callable(enter):
            await enter()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> Any:
        if exc_type is not None:
            self._errored = True
        await self._log_turn_once_async()
        ex = getattr(self._underlying, "__aexit__", None)
        if callable(ex):
            return await ex(exc_type, exc_val, exc_tb)
        return None

    def __getattr__(self, name: str) -> Any:
        return getattr(self._underlying, name)

    async def _log_turn_once_async(self) -> None:
        if self._logged or self._errored:
            return
        self._logged = True

        if self._accumulator.chunk_count == 0:
            return

        answer = self._accumulator.assembled_answer()
        if not answer:
            return

        from ._ask import _detect_and_log_async  # local import avoids cycle
        await _detect_and_log_async(
            question=self._question,
            answer=answer,
            memories=self._memories,
            config=self._config,
            per_call=self._per_call,
            partial=not self._exhausted,
        )
