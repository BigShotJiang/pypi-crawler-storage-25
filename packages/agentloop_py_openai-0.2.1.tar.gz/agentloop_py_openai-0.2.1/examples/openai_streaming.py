"""
Streaming example: same code as a normal OpenAI streaming call, AgentLoop
hooks fire automatically (search before, log after).

Run with:
    pip install agentloop-py agentloop-py-openai openai
    export OPENAI_API_KEY=...
    export AGENTLOOP_API_KEY=ak_live_...
    python openai_streaming.py
"""

import os

from openai import OpenAI

from agentloop import AgentLoop
from agentloop_openai import wrap_openai


def main() -> None:
    loop = AgentLoop(api_key=os.environ["AGENTLOOP_API_KEY"])

    openai = wrap_openai(OpenAI(), loop=loop)

    # Identical to a vanilla OpenAI streaming call. The wrapper auto-runs:
    #   1. memory search (before the LLM call)
    #   2. memory injection into the system prompt
    #   3. token-by-token passthrough as you iterate
    #   4. log_turn (after stream ends, with assembled response)
    stream = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "What's the Pix limit at night?"},
        ],
        stream=True,
        agentloop={"user_id": "u_demo", "tags": ["streaming_demo"]},
    )

    print("Response (streaming):")
    for chunk in stream:
        delta = chunk.choices[0].delta.content or ""
        print(delta, end="", flush=True)
    print()
    print()
    print("Done. Check the AgentLoop dashboard — this turn is in the review queue.")


if __name__ == "__main__":
    main()
