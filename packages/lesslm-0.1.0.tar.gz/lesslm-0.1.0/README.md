# lesslm

Official CLI for installing LessLM premium specialized Claude Code agents.

Proprietary software — see [LICENSE](./LICENSE). Public install via PyPI; not open-source, not redistributable.

## Install

```bash
uv tool install lesslm
# or
pipx install lesslm
```

## Use

```bash
lesslm activate LSLM-XXXX-XXXX-XXXX-XXXX   # one-time, after purchase
lesslm install dataset-creator
lesslm install --all
lesslm list
lesslm deactivate                          # frees a slot
```

License keys are issued at [lesslm.ai/pricing](https://lesslm.ai/pricing).

## Development

```bash
uv sync
uv run pytest
uv run ruff check src tests
uv run mypy src
```

See `knowledge/usage_guides/DEVELOPER_GUIDE.md`.
