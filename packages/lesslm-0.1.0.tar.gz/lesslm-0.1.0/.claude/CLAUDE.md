# CLAUDE.md — lesslm-cli

## Project

The user-facing Python CLI for activating a LessLM premium-agents license and installing the agents into the user's Claude Code agents directory. **Proprietary** (LicenseRef-Proprietary, see `LICENSE`), published to public PyPI as `lesslm` for install convenience — source visible in the wheel but not open-source, not redistributable.

Companion: `LessLM/lesslm-site` — the Next.js site at `lesslm.ai` whose API this CLI consumes.

## Stack

Python 3.11+, `uv`, Click, httpx, pydantic v2, platformdirs.

## Conventions

- src layout, snake_case modules.
- `StrEnum` for closed sets (`AgentSlug`).
- All hardcoded paths and timeouts in `constants.py`.
- Credential file is chmod 600 — guarded by tests.
- Zip extraction strips path-traversal entries — guarded by tests.

## Pre-publish gate

Do not run `uv publish` until the orchestrator's `knowledge/team_lead_homework/founder/2026_05_04_PAID_AGENTS_CONTRACT_CONFIRMATION.md` reads `CLEARED`.
