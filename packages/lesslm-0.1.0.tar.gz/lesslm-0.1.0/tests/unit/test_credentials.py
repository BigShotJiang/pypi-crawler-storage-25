import os
import stat
from pathlib import Path

import pytest

from lesslm import credentials


@pytest.fixture
def isolated_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    return tmp_path


def test_save_load_roundtrip(isolated_config: Path) -> None:
    creds = credentials.Credentials(
        license_key="LSLM-AAAA-BBBB-CCCC-DDDD",
        instance_id="inst_123",
        instance_name="laptop",
    )
    path = credentials.save(creds)
    assert path.exists()
    mode = stat.S_IMODE(os.stat(path).st_mode)
    assert mode == 0o600

    loaded = credentials.load()
    assert loaded == creds


def test_load_returns_none_when_missing(isolated_config: Path) -> None:
    assert credentials.load() is None


def test_clear_removes_file(isolated_config: Path) -> None:
    creds = credentials.Credentials(
        license_key="LSLM-AAAA-BBBB-CCCC-DDDD",
        instance_id="inst_123",
        instance_name="laptop",
    )
    credentials.save(creds)
    credentials.clear()
    assert credentials.load() is None
