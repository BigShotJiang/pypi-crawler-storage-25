from lesslm.constants import AgentSlug


def test_agent_slugs_are_string_values() -> None:
    assert AgentSlug.DATASET_CREATOR == "dataset-creator"
    assert AgentSlug.LORA_EDUCATOR == "lora-educator"
    assert str(AgentSlug.DATASET_CREATOR) == "dataset-creator"
