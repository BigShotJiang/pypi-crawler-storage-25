import io
import zipfile
from pathlib import Path

import pytest

from lesslm import installer


def _make_zip(entries: dict[str, bytes]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, data in entries.items():
            zf.writestr(name, data)
    return buf.getvalue()


def test_target_dir_global(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    out = installer.target_dir(project_local=False)
    assert out == tmp_path / ".claude" / "agents"


def test_target_dir_project(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    out = installer.target_dir(project_local=True)
    assert out == tmp_path / ".claude" / "agents"


def test_unpack_skips_path_traversal(tmp_path: Path, httpx_mock) -> None:
    blob = _make_zip(
        {
            "dataset-creator.md": b"# agent body",
            "../evil.md": b"oops",
        }
    )
    httpx_mock.add_response(url="https://example.com/zip", content=blob)
    written = installer.fetch_and_unpack("https://example.com/zip", tmp_path)
    names = [w.name for w in written]
    assert "dataset-creator.md" in names
    assert "evil.md" not in names


def test_unpack_keeps_only_md_files(tmp_path: Path, httpx_mock) -> None:
    blob = _make_zip(
        {
            "lora-educator.md": b"# agent body",
            "MANIFEST.txt": b"sha256: abc",
            "README.md": b"# readme",
        }
    )
    httpx_mock.add_response(url="https://example.com/zip2", content=blob)
    written = installer.fetch_and_unpack("https://example.com/zip2", tmp_path)
    names = [w.name for w in written]
    assert "lora-educator.md" in names
    assert "README.md" in names
    assert "MANIFEST.txt" not in names


def test_unpack_rejects_non_zip(tmp_path: Path, httpx_mock) -> None:
    httpx_mock.add_response(url="https://example.com/bad", content=b"not a zip")
    with pytest.raises(RuntimeError, match="not a valid zip"):
        installer.fetch_and_unpack("https://example.com/bad", tmp_path)
