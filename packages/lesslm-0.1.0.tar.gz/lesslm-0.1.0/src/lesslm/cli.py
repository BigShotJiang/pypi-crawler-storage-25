"""LessLM CLI — activate license, install premium agents."""

from __future__ import annotations

import logging
import sys

import click

from . import __version__, api_client, credentials, installer
from .constants import AgentSlug

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
    stream=sys.stderr,
)


@click.group()
@click.version_option(__version__, prog_name="lesslm")
def main() -> None:
    """LessLM — install premium specialized Claude Code agents."""


@main.command()
@click.argument("license_key")
def activate(license_key: str) -> None:
    """Activate LICENSE_KEY on this machine. Stores credentials at ~/.config/lesslm/."""
    instance_name = credentials.default_instance_name()
    try:
        result = api_client.activate(license_key, instance_name)
    except RuntimeError as exc:
        click.echo(click.style(str(exc), fg="red"), err=True)
        sys.exit(1)

    if not result.get("valid") or not result.get("instance"):
        msg = result.get("error") or "License activation rejected by server."
        click.echo(click.style(f"Activation failed: {msg}", fg="red"), err=True)
        sys.exit(1)

    instance_id = result["instance"]["id"]
    creds = credentials.Credentials(
        license_key=license_key, instance_id=instance_id, instance_name=instance_name
    )
    path = credentials.save(creds)
    click.echo(click.style(f"Activated. Credentials saved to {path}.", fg="green"))


@main.command()
@click.argument("agent", required=False)
@click.option("--all", "all_agents", is_flag=True, help="Install every available premium agent.")
@click.option("--project", is_flag=True, help="Install into ./.claude/agents/ instead of ~/.claude/agents/.")
def install(agent: str | None, all_agents: bool, project: bool) -> None:
    """Install AGENT (or all agents with --all) into your Claude Code agents directory."""
    if all_agents and agent:
        click.echo(click.style("Pass either AGENT or --all, not both.", fg="red"), err=True)
        sys.exit(2)
    if not all_agents and not agent:
        click.echo(click.style("Specify an agent slug or --all.", fg="red"), err=True)
        sys.exit(2)

    creds = credentials.require()
    slugs: list[str] = (
        [a.value for a in AgentSlug] if all_agents else [_canonical_slug(agent or "")]
    )
    dest = installer.target_dir(project_local=project)

    for slug in slugs:
        try:
            resp = api_client.download_url(creds.license_key, creds.instance_id, slug)
        except RuntimeError as exc:
            click.echo(click.style(f"[{slug}] {exc}", fg="red"), err=True)
            sys.exit(1)

        url = resp.get("url")
        if not url:
            err = resp.get("error", "no url returned")
            click.echo(click.style(f"[{slug}] download denied: {err}", fg="red"), err=True)
            sys.exit(1)

        written = installer.fetch_and_unpack(url, dest)
        for w in written:
            click.echo(f"[{slug}] wrote {w}")
        click.echo(click.style(f"[{slug}] installed.", fg="green"))


@main.command(name="list")
def list_cmd() -> None:
    """List installed premium agents in the global Claude Code agents directory."""
    dest = installer.target_dir(project_local=False)
    if not dest.exists():
        click.echo("(none)")
        return
    for p in sorted(dest.iterdir()):
        click.echo(p.name)


@main.command()
def deactivate() -> None:
    """Deactivate this machine and free a license slot."""
    creds = credentials.load()
    if creds is None:
        click.echo("Nothing to deactivate.")
        return
    # Server-side deactivation is best-effort — we still clear local creds.
    try:
        api_client.validate(creds.license_key, creds.instance_id)  # cheap reachability ping
    except RuntimeError as exc:
        click.echo(click.style(f"Warning: server unreachable ({exc}). Clearing local creds anyway.", fg="yellow"))
    credentials.clear()
    click.echo(click.style("Deactivated locally. Slot will free server-side via support if needed.", fg="green"))


def _canonical_slug(value: str) -> str:
    try:
        return AgentSlug(value).value
    except ValueError as exc:
        valid = ", ".join(a.value for a in AgentSlug)
        raise click.BadParameter(f"Unknown agent '{value}'. Valid: {valid}") from exc
