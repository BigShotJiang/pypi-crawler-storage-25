"""HTTP client for the lesslm.ai API.

Server is the source of truth for license state — never trust local cache.
"""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx

from .constants import (
    DEFAULT_API_BASE,
    DOWNLOAD_PATH,
    HTTP_TIMEOUT_SECONDS,
    VALIDATE_PATH,
)

logger = logging.getLogger(__name__)


def _api_base() -> str:
    return os.environ.get("LESSLM_API_BASE", DEFAULT_API_BASE).rstrip("/")


def _post(path: str, payload: dict[str, Any]) -> dict[str, Any]:
    url = f"{_api_base()}{path}"
    try:
        with httpx.Client(timeout=HTTP_TIMEOUT_SECONDS) as client:
            resp = client.post(url, json=payload)
    except httpx.HTTPError as exc:
        logger.error(
            "http transport error",
            extra={"error": str(exc), "url": url, "func": "_post"},
        )
        raise RuntimeError(f"Network error talking to {url}: {exc}") from exc

    if resp.status_code >= 500:
        logger.error(
            "server error",
            extra={"status": resp.status_code, "url": url, "body": resp.text[:500]},
        )
        raise RuntimeError(f"Server error {resp.status_code} from {url}")

    try:
        return resp.json()
    except ValueError as exc:
        logger.error(
            "invalid json from server",
            extra={"error": str(exc), "url": url, "body": resp.text[:500]},
        )
        raise RuntimeError(f"Invalid JSON from {url}") from exc


def activate(license_key: str, instance_name: str) -> dict[str, Any]:
    return _post(
        VALIDATE_PATH,
        {"license_key": license_key, "instance_name": instance_name, "action": "activate"},
    )


def validate(license_key: str, instance_id: str) -> dict[str, Any]:
    return _post(
        VALIDATE_PATH,
        {"license_key": license_key, "instance_id": instance_id, "action": "validate"},
    )


def download_url(license_key: str, instance_id: str, agent: str) -> dict[str, Any]:
    return _post(
        DOWNLOAD_PATH,
        {"license_key": license_key, "instance_id": instance_id, "agent": agent},
    )
