"""Local credential store for the LessLM CLI.

Stores license key + Lemon Squeezy instance ID at
``$XDG_CONFIG_HOME/lesslm/credentials.json`` (chmod 600).
"""

from __future__ import annotations

import logging
import os
import socket
import stat
from pathlib import Path

from platformdirs import user_config_dir
from pydantic import BaseModel, Field

from .constants import CONFIG_DIR_NAME, CREDENTIALS_FILENAME

logger = logging.getLogger(__name__)


class Credentials(BaseModel):
    license_key: str = Field(min_length=8, max_length=128)
    instance_id: str = Field(min_length=1, max_length=128)
    instance_name: str = Field(min_length=1, max_length=128)


def _credentials_path() -> Path:
    return Path(user_config_dir(CONFIG_DIR_NAME)) / CREDENTIALS_FILENAME


def default_instance_name() -> str:
    try:
        return f"{socket.gethostname()}-{os.getuid()}"
    except OSError as exc:
        logger.error(
            "failed to derive instance name",
            extra={"error": str(exc), "func": "default_instance_name"},
        )
        raise


def save(creds: Credentials) -> Path:
    path = _credentials_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(creds.model_dump_json(indent=2))
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)
        return path
    except OSError as exc:
        logger.error(
            "failed to save credentials",
            extra={"error": str(exc), "path": str(path), "func": "save"},
        )
        raise


def load() -> Credentials | None:
    path = _credentials_path()
    if not path.exists():
        return None
    try:
        return Credentials.model_validate_json(path.read_text())
    except (OSError, ValueError) as exc:
        logger.error(
            "failed to load credentials",
            extra={"error": str(exc), "path": str(path), "func": "load"},
        )
        raise


def clear() -> None:
    path = _credentials_path()
    try:
        if path.exists():
            path.unlink()
    except OSError as exc:
        logger.error(
            "failed to clear credentials",
            extra={"error": str(exc), "path": str(path), "func": "clear"},
        )
        raise


def require() -> Credentials:
    creds = load()
    if creds is None:
        raise RuntimeError("Not activated. Run: lesslm activate <LICENSE_KEY>")
    return creds
