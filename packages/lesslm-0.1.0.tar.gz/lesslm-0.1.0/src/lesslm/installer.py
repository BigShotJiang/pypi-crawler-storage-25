"""Download + unpack premium agents into the user's Claude Code agents directory."""

from __future__ import annotations

import io
import logging
import zipfile
from pathlib import Path

import httpx

from .constants import (
    CLAUDE_AGENTS_DIR_GLOBAL,
    CLAUDE_AGENTS_DIR_PROJECT,
    DOWNLOAD_TIMEOUT_SECONDS,
)

logger = logging.getLogger(__name__)


def target_dir(project_local: bool) -> Path:
    if project_local:
        return Path.cwd() / CLAUDE_AGENTS_DIR_PROJECT
    return Path(CLAUDE_AGENTS_DIR_GLOBAL).expanduser()


def fetch_and_unpack(signed_url: str, dest: Path) -> list[Path]:
    """Stream a signed URL into memory, validate as zip, unpack to ``dest``.

    Returns the list of files written.
    """
    try:
        with httpx.Client(timeout=DOWNLOAD_TIMEOUT_SECONDS) as client:
            resp = client.get(signed_url)
            resp.raise_for_status()
            blob = resp.content
    except httpx.HTTPError as exc:
        logger.error(
            "agent zip download failed",
            extra={"error": str(exc), "func": "fetch_and_unpack"},
        )
        raise RuntimeError(f"Download failed: {exc}") from exc

    try:
        zf = zipfile.ZipFile(io.BytesIO(blob))
    except zipfile.BadZipFile as exc:
        logger.error(
            "downloaded artifact is not a valid zip",
            extra={"error": str(exc), "size": len(blob)},
        )
        raise RuntimeError("Downloaded artifact is not a valid zip") from exc

    dest.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for member in zf.infolist():
        name = member.filename
        if name.endswith("/") or ".." in Path(name).parts or Path(name).is_absolute():
            logger.warning("skipping unsafe zip entry", extra={"entry": name})
            continue
        flat = Path(name).name
        # Only .md files belong in .claude/agents/. MANIFEST.txt and other
        # bookkeeping files stay in the zip but are not unpacked there.
        if not flat.endswith(".md"):
            continue
        out = dest / flat
        out.write_bytes(zf.read(member))
        written.append(out)

    return written
