from enum import StrEnum


class AgentSlug(StrEnum):
    DATASET_CREATOR = "dataset-creator"
    LORA_EDUCATOR = "lora-educator"


DEFAULT_API_BASE = "https://lesslm.ai"
VALIDATE_PATH = "/api/license/validate"
DOWNLOAD_PATH = "/api/download"

CONFIG_DIR_NAME = "lesslm"
CREDENTIALS_FILENAME = "credentials.json"

CLAUDE_AGENTS_DIR_GLOBAL = "~/.claude/agents"
CLAUDE_AGENTS_DIR_PROJECT = ".claude/agents"

HTTP_TIMEOUT_SECONDS = 30
DOWNLOAD_TIMEOUT_SECONDS = 120
