# DEVELOPER_GUIDE

## Table of Contents
- [Summary](#summary)
- [Layout](#layout)
- [Local setup](#local-setup)
- [Conventions](#conventions)
- [Pointing the CLI at a non-prod server](#pointing-the-cli-at-a-non-prod-server)
- [Publishing to PyPI](#publishing-to-pypi)

---

## Summary

`lesslm` is the user-facing Python CLI for activating a license and installing premium agents. It talks to `https://lesslm.ai/api/license/validate` and `/api/download` (served by the `lesslm-site` repo). The CLI is **proprietary** software — see `LICENSE` (proprietary EULA, "All rights reserved"). It is published to public PyPI as a regular wheel for install convenience, but the source is not open-source and not redistributable. Agent payloads are private artifacts in Cloudflare R2 served via short-TTL signed URLs.

## Layout

```
src/lesslm/
├── __init__.py          # version
├── cli.py               # Click commands (activate, install, list, deactivate)
├── api_client.py        # HTTP calls to lesslm.ai
├── credentials.py       # Local credential store (~/.config/lesslm/credentials.json, chmod 600)
├── installer.py         # Download + unpack zip into ~/.claude/agents/
└── constants.py         # AgentSlug enum, paths, timeouts
tests/unit/              # pytest + pytest-httpx
```

## Local setup

```bash
uv sync
uv run pytest
uv run lesslm --help
```

Python 3.11+. `StrEnum` is required (3.11+).

## Conventions

Per the org-wide standards in `~/.claude/CLAUDE.md`:

- src layout, `pyproject.toml`, no `requirements.txt`.
- Constants and enums in `constants.py`. No hardcoded slugs in CLI logic.
- Fail-fast: every public function logs structured errors via `logging.extra` and re-raises.
- License keys never logged in plaintext (server side enforces redaction; CLI doesn't log them).
- `httpx` for HTTP, not `requests`.
- `pydantic` v2 for any data shape (currently just `Credentials`).

## Pointing the CLI at a non-prod server

```bash
LESSLM_API_BASE=http://localhost:3000 lesslm activate TEST-KEY
```

Used during local end-to-end testing against a `lesslm-site` dev server.

## Publishing to PyPI

Do **not** publish until the contract gate clears (`knowledge/team_lead_homework/founder/2026_05_04_PAID_AGENTS_CONTRACT_CONFIRMATION.md` reads `CLEARED`).

Once cleared:

```bash
uv build
uv publish    # requires PYPI_TOKEN
```

Tag the release in git first: `git tag v0.1.0 && git push --tags`.
