# Security Policy

## Supported versions

vocaboot is Alpha (`0.1.0`). Security fixes target `main` only. During the
Alpha series (0.1.x) there is no LTS branch; users are expected to track
`main` for security updates. From the first 1.0.0 release onward this
policy will be revised to list the supported branch / version matrix.

## Reporting a vulnerability

**Do not file a public GitHub issue for security findings.**

Use GitHub's
[private vulnerability reporting](https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing-information-about-vulnerabilities/privately-reporting-a-security-vulnerability)
on this repository. The maintainers will:

1. Acknowledge receipt within **72 hours**.
2. Provide an initial assessment (impact, scope) within **7 days**.
3. Coordinate a disclosure timeline (default: 90-day public disclosure after
   a fix is available).

Reports involving the **supply chain** of bundled third-party assets (vocoder
checkpoint, WavLM weights, reference voice) — i.e. published artefacts whose
sha256 in `docs/ckpt_registry.md` no longer matches the upstream — are
treated as P0 (immediate ckpt invalidation; users see a hash-mismatch error
at runtime).

## Scope

In scope:

- Privacy guard bypass (`src/vocaboot/privacy.py`,
  `tests/test_user_audio_guard.py`) — anything that would let a user voice
  path leak into the failure museum, logs, or any other persisted artefact.
- Checkpoint / weight supply-chain tampering — anything that would let a
  vocoder or WavLM weight on disk pass the runtime sha256 gate while being
  the wrong artefact.
- Consent flag bypass (`audio_ingest`) — anything that would let user audio
  reach Tier 2 verification without the consent flags being present.
- License-gate bypass (`license_check`) — anything that would let
  CC-BY-NC-SA-licensed weights load without `--accept-nc`.

Out of scope:

- Resource exhaustion via deliberately malformed `.ds` score files (vocaboot
  does not run in a server context; CLI users own the input).
- Vulnerabilities in third-party dependencies (transformers, torch, librosa,
  onnxruntime) — report those upstream; vocaboot will track and version-pin
  as needed.

  Specifically, **CVE-2026-1839 / GHSA-69w3-r845-3855**
  (`transformers.Trainer._load_rng_state` arbitrary code execution via
  malicious `rng_state.pth`) is **not reachable from vocaboot's code
  path**: vocaboot imports `transformers` solely for
  `WavLMModel.from_pretrained()` inference in
  `src/vocaboot/profile_match.py:333`. The `Trainer` class is never
  imported or instantiated, and no `rng_state.pth` is ever loaded. The
  alert will resolve automatically when `transformers>=5.0.0` becomes
  available on PyPI and the `[verify-similarity]` upper bound bumps.

## Hall of fame

A `HALL_OF_FAME.md` will be added once the first valid security report is
received and fixed, listing reporters who consent to being credited.
