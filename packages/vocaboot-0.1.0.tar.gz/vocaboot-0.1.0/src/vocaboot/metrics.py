"""Numeric audio metrics for agent B (Layer 6).

Each metric returns a value and a two-sided 95% bootstrap CI per R5. A CI
that straddles the metric's "no-effect" threshold means *the result is
undetermined* — agent B returns REVIEW, not APPROVE.

Stage 1 metrics:

  - :func:`f0_stability`: cycle-to-cycle F0 jitter on the voiced portion of
    the signal. ``direction="lower_better"``; threshold default ``+0.02``
    means tolerated jitter ≤ 2 % cycle-to-cycle.
  - :func:`hnr`: harmonic-to-noise ratio in dB, derived from pyworld's
    aperiodicity. ``direction="higher_better"``, threshold 0 dB.

Stage 2 step 3a metric:

  - :func:`mcd`: Mel Cepstral Distortion in dB between a synthesized output
    and a reference voice's MFCC. ``direction="lower_better"``. DTW-aligned
    (lazy ``librosa.sequence.dtw`` import behind ``[verify-similarity]``);
    CI uses :func:`bootstrap_ci` with ``block_size=25`` (≈ 250 ms at 10 ms
    hop) because cepstra are frame-by-frame time-correlated and plain
    percentile bootstrap under-estimates CI.

All three metrics gracefully degrade to an undetermined
:class:`MetricResult` when the input is too short or has no voiced frames.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np

Direction = Literal["higher_better", "lower_better"]


@dataclass(frozen=True)
class MetricResult:
    """A numeric metric reading with a bootstrap CI.

    ``direction`` tells :attr:`passes` which side of the threshold counts
    as a passing metric, so museum entries and CLI display can carry the
    raw, sign-honest reading instead of a sign-flipped surrogate.

    ``threshold_ci`` is an optional 2-sided uncertainty band around the
    threshold itself. When set, :attr:`passes` enforces a **strict
    2-sided** gate: the metric CI must be disjoint from the band on the
    *better* side. This treats the threshold as a calibrated quantity
    with non-zero SE rather than a point estimate; with ``threshold_ci=
    None`` the legacy 1-sided gate (CI bound vs the point :attr:`threshold`)
    applies so non-canary metrics keep their existing semantics.
    """

    name: str
    value: float
    ci_low: float
    ci_high: float
    threshold: float
    direction: Direction = "higher_better"
    threshold_ci: tuple[float, float] | None = None

    def __post_init__(self) -> None:
        if self.threshold_ci is not None:
            t_lo, t_hi = self.threshold_ci
            if not (t_lo <= t_hi):
                raise ValueError(
                    f"threshold_ci must satisfy t_lo <= t_hi, got ({t_lo}, {t_hi})"
                )

    @property
    def is_determined(self) -> bool:
        """True if the metric CI does not straddle the threshold (or threshold CI).

        When ``threshold_ci`` is set, "straddle" means the metric CI overlaps
        the threshold band on both sides; "determined" requires the metric CI
        to sit entirely above or entirely below the threshold band.
        """
        if self.threshold_ci is not None:
            t_lo, t_hi = self.threshold_ci
            return self.ci_low > t_hi or self.ci_high < t_lo
        return self.ci_low > self.threshold or self.ci_high < self.threshold

    @property
    def passes(self) -> bool:
        """True iff the CI is strictly on the *better* side of the threshold.

        With ``threshold_ci`` set (R5-strict 2-sided gate):
          ``higher_better`` ⇔ ``ci_low > threshold_ci[1]`` (metric strictly above the band)
          ``lower_better``  ⇔ ``ci_high < threshold_ci[0]`` (metric strictly below the band)

        Without ``threshold_ci`` (legacy 1-sided):
          ``higher_better`` ⇔ ``ci_low > threshold``
          ``lower_better``  ⇔ ``ci_high < threshold``
        """
        if self.threshold_ci is not None:
            t_lo, t_hi = self.threshold_ci
            if self.direction == "higher_better":
                return self.ci_low > t_hi
            return self.ci_high < t_lo
        if self.direction == "higher_better":
            return self.ci_low > self.threshold
        return self.ci_high < self.threshold


def bootstrap_ci(
    samples: np.ndarray,
    *,
    n_resamples: int = 1000,
    alpha: float = 0.05,
    rng: np.random.Generator | None = None,
    block_size: int | None = None,
) -> tuple[float, float]:
    """Return a two-sided (alpha/2, 1-alpha/2) bootstrap CI of the mean.

    ``block_size=None`` (default) — plain percentile bootstrap, suitable
    for i.i.d. samples (``f0_stability`` jitter, ``hnr`` per-frame).

    ``block_size=B`` — **moving block bootstrap**, mandatory for
    time-correlated samples (MCD per-frame readings, WavLM frame
    embeddings). Each resample concatenates ``ceil(T/B)`` contiguous
    blocks of size ``B`` drawn uniformly with replacement from the
    series, then trims to length ``T``. Plain percentile bootstrap on
    time-correlated data under-estimates CI width and violates R5.
    """
    if samples.ndim != 1 or samples.size == 0:
        raise ValueError("bootstrap_ci needs a non-empty 1-D sample array")
    rng = rng if rng is not None else np.random.default_rng()
    t = samples.size
    if block_size is None:
        idx = rng.integers(0, t, size=(n_resamples, t))
        resampled = samples[idx]
    else:
        if block_size < 1:
            raise ValueError("block_size must be ≥ 1")
        if block_size > t:
            raise ValueError(
                f"block_size {block_size} exceeds sample length {t} — "
                "block bootstrap needs at least one full block per sample"
            )
        n_blocks = (t + block_size - 1) // block_size
        starts = rng.integers(0, t - block_size + 1, size=(n_resamples, n_blocks))
        offsets = np.arange(block_size)
        indices = (starts[:, :, None] + offsets[None, None, :]).reshape(n_resamples, -1)
        resampled = samples[indices[:, :t]]
    means = resampled.mean(axis=1)
    lo, hi = np.quantile(means, [alpha / 2, 1 - alpha / 2])
    return float(lo), float(hi)


_F0_FLOOR_HZ = 80.0
_F0_CEIL_HZ = 800.0


def _voiced_f0(audio: np.ndarray, sample_rate: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (f0, t_axis, voiced_mask) using pyworld harvest + stonemask."""
    import pyworld as pw

    x = np.asarray(audio, dtype=np.float64)
    if x.ndim != 1:
        raise ValueError(f"metrics input must be mono (ndim=1), got ndim={x.ndim}")
    f0, t_axis = pw.harvest(x, sample_rate, f0_floor=_F0_FLOOR_HZ, f0_ceil=_F0_CEIL_HZ)
    f0 = pw.stonemask(x, f0, t_axis, sample_rate)
    voiced = f0 > 0
    return f0, t_axis, voiced


def _undetermined(
    name: str,
    threshold: float,
    *,
    direction: Direction = "higher_better",
    threshold_ci: tuple[float, float] | None = None,
) -> MetricResult:
    """A MetricResult whose CI brackets the threshold (band) by definition.

    With ``threshold_ci`` set, the synthetic CI brackets the
    threshold band itself (`ci_low = t_lo - 1.0`, `ci_high = t_hi + 1.0`) so
    :attr:`MetricResult.is_determined` correctly reports ``False`` under the
    2-sided strict rule.
    """
    if threshold_ci is not None:
        t_lo, t_hi = threshold_ci
        return MetricResult(
            name=name,
            value=float("nan"),
            ci_low=t_lo - 1.0,
            ci_high=t_hi + 1.0,
            threshold=threshold,
            direction=direction,
            threshold_ci=threshold_ci,
        )
    return MetricResult(
        name=name,
        value=float("nan"),
        ci_low=threshold - 1.0,
        ci_high=threshold + 1.0,
        threshold=threshold,
        direction=direction,
    )


def f0_stability(
    audio: np.ndarray,
    sample_rate: int,
    *,
    threshold: float = 0.02,
    rng: np.random.Generator | None = None,
) -> MetricResult:
    """Cycle-to-cycle F0 jitter on the voiced portion, with a bootstrap CI.

    Jitter = mean |Δf0/f0|, stored directly with ``direction="lower_better"``
    (the prior ``-jitter`` sign-flip trick made
    museum entries and CLI display sign-uncertain). ``threshold`` is the
    upper bound on tolerated jitter (default 0.02 = 2 % cycle-to-cycle).

    APPROVE ⇔ CI strictly below threshold (jitter confidently below 2 %).
    REVIEW when the signal has fewer than 4 voiced frames.
    """
    f0, _t, voiced = _voiced_f0(audio, sample_rate)
    voiced_f0 = f0[voiced]
    if voiced_f0.size < 4:
        return _undetermined("f0_stability", threshold, direction="lower_better")
    diffs = np.diff(voiced_f0)
    jitter = np.abs(diffs) / voiced_f0[:-1]
    lo, hi = bootstrap_ci(jitter, rng=rng)
    return MetricResult(
        name="f0_stability",
        value=float(jitter.mean()),
        ci_low=lo,
        ci_high=hi,
        threshold=threshold,
        direction="lower_better",
    )


def hnr(
    audio: np.ndarray,
    sample_rate: int,
    *,
    threshold: float = 0.0,
    rng: np.random.Generator | None = None,
) -> MetricResult:
    """Mean harmonic-to-noise ratio in dB on the voiced portion.

    Derived from pyworld's per-frame aperiodicity:

        HNR_dB(frame) = -10·log10(mean(ap²) over frequency bins)

    APPROVE ⇔ CI entirely above 0 dB (signal dominantly harmonic on voiced
    frames). REVIEW when fewer than 4 voiced frames.
    """
    import pyworld as pw

    x = np.asarray(audio, dtype=np.float64)
    f0, t_axis, voiced = _voiced_f0(audio, sample_rate)
    if voiced.sum() < 4:
        return _undetermined("hnr", threshold, direction="higher_better")
    ap = pw.d4c(x, f0, t_axis, sample_rate)
    voiced_ap = ap[voiced]
    eps = 1e-10
    mean_ap_sq = np.clip(np.mean(voiced_ap**2, axis=1), eps, 1.0)
    hnr_db = -10.0 * np.log10(mean_ap_sq)
    lo, hi = bootstrap_ci(hnr_db, rng=rng)
    return MetricResult(
        name="hnr",
        value=float(hnr_db.mean()),
        ci_low=lo,
        ci_high=hi,
        threshold=threshold,
        direction="higher_better",
    )


# ---------------------------------------------------------------------------
# MFCC pinned parameters (Stage 2 step 3b).
#
# Profile and verify paths MUST extract MFCC with identical parameters — any
# drift silently turns MCD into a "different settings" artefact instead of a
# real voice distance. ``tests/test_mfcc_params_pinned.py`` structurally
# locks every constant below; the WavLM sha256 pin in ``ckpt_registry.md``
# uses the same supply-chain pattern.
# ---------------------------------------------------------------------------

MFCC_SAMPLE_RATE = 16000     # WavLM input rate; identical rate avoids resample inside MCD
MFCC_N_COEF = 25             # extract c_0..c_24; MCD slices [_MCD_COEF_LO:MFCC_N_COEF] = c_1..c_24 (24 coeffs, Kominek 2008)
MFCC_N_FFT = 400             # 25 ms @ 16 kHz
MFCC_HOP_LENGTH = 160        # 10 ms @ 16 kHz (matches _MCD_BLOCK_MS / hop = 25-frame block ≈ 250 ms)
MFCC_WIN_LENGTH = 400        # full FFT window
MFCC_N_MELS = 80             # HuBERT / wav2vec2 / ESPnet speech convention (librosa default is 128; pinned explicitly)
MFCC_WINDOW = "hann"         # melspectrogram default; pinned so a future librosa default cannot drift either arm
MFCC_POWER = 2.0             # power-spectrum exponent for melspectrogram
MFCC_FMIN = 0.0              # mel filter min Hz
MFCC_FMAX: float | None = None  # mel filter max Hz; None → Nyquist (sr/2) — pinned None so the default cannot drift
MFCC_DCT_TYPE = 2            # type-II DCT, the speech-ASR convention
MFCC_NORM = "ortho"          # orthonormal DCT — preserves Parseval
MFCC_HTK = False             # Slaney mel (librosa default), not HTK
MFCC_LIFTER = 0              # no cepstral liftering
MFCC_CENTER = True           # symmetric padding so frame 0 corresponds to t=0
MFCC_PAD_MODE = "constant"   # zero-pad the leading/trailing context

# MCD bootstrap block duration in milliseconds. Time-correlated cepstra
# need block bootstrap (R5); 250 ms is the de-correlation distance for
# 10 ms-hop MFCC frames. At the pinned ``MFCC_HOP_LENGTH=160`` (10 ms),
# this resolves to 25 frames. If ``MFCC_HOP_LENGTH`` ever changes, the
# block stays at 250 ms in wall-clock time — the threshold band below
# is calibrated against this duration, not against "25 frames".
_MCD_BLOCK_MS = 250
_MCD_BLOCK_SIZE_DEFAULT = max(1, _MCD_BLOCK_MS * MFCC_SAMPLE_RATE // (1000 * MFCC_HOP_LENGTH))

# Calibrated 2026-05-12 against the N=5 OpenJTalk-HMM canary distribution:
# voice arm CI [222, 367] dB; synth-4-partial arm CI [1071, 1259] dB
# (block bootstrap, ``_MCD_BLOCK_MS=250``). The 500 dB anchor sits in the
# 704 dB separability gap. Note: this is the librosa-MFCC-scale equivalent
# of the Kominek 2008 6-8 dB anchor; native MCEP via pysptk would re-anchor
# to the literature value but is deferred to 0.2.0 because pysptk has no
# PyPI wheels (CHANGELOG ``Deferred`` §dormant #3).
_MCD_THRESHOLD_DEFAULT_DB = 500.0

# Public R5-strict 2-sided uncertainty band around the calibrated point,
# ±10% of the anchor. ``agent_verify.run`` passes this as ``threshold_ci=``
# so the Tier 2 gate refuses to commit when a candidate CI straddles
# [450, 550] dB. The N=5 canary arms sit strictly outside the band with
# margin (voice CI [222, 367] < 450; synth CI [1071, 1259] > 550) so
# passes/is_determined outcomes are unchanged from the legacy 1-sided
# gate — the band activates only on near-threshold candidates that the
# point gate would silently mis-classify.
MCD_THRESHOLD_BAND_DB: tuple[float, float] = (450.0, 550.0)

_MCD_N_RESAMPLES_DEFAULT = 300
_MCD_COEF_LO = 1   # skip c_0 (energy) — convention from Kominek, Schultz & Black SLTU 2008
_MCD_DB_SCALE = 10.0 / np.log(10.0)


def mfcc_extract(audio: np.ndarray) -> np.ndarray:
    """Extract MFCC with pinned parameters; returns ``(T_frames, MFCC_N_COEF)`` float32.

    Audio MUST already be at :data:`MFCC_SAMPLE_RATE` (16 kHz) mono — callers
    do not get to choose a rate. The reference path (``profile_match.build``)
    and the candidate path (``agent_verify`` Tier 2 wire-in) both call this
    helper on the same 16 kHz array that WavLM consumes, so MFCC and WavLM
    frame timings stay locked.

    Drift between the two arms would silently turn MCD into a
    settings-mismatch artifact instead of a voice distance. The drift test
    in ``tests/test_mfcc_params_pinned.py`` locks the constants AND inspects
    the actual ``librosa.feature.mfcc`` kwargs to catch any future bypass.

    Lazy imports librosa (ships with the ``[verify-similarity]`` extra).
    """
    if audio.ndim != 1 or audio.size == 0:
        raise ValueError(
            f"mfcc_extract needs a non-empty 1-D mono signal; got "
            f"shape={audio.shape}, size={audio.size}"
        )
    import librosa

    mfcc = librosa.feature.mfcc(
        y=audio.astype(np.float32, copy=False),
        sr=MFCC_SAMPLE_RATE,
        n_mfcc=MFCC_N_COEF,
        n_fft=MFCC_N_FFT,
        hop_length=MFCC_HOP_LENGTH,
        win_length=MFCC_WIN_LENGTH,
        n_mels=MFCC_N_MELS,
        window=MFCC_WINDOW,
        power=MFCC_POWER,
        fmin=MFCC_FMIN,
        fmax=MFCC_FMAX,
        dct_type=MFCC_DCT_TYPE,
        norm=MFCC_NORM,
        htk=MFCC_HTK,
        lifter=MFCC_LIFTER,
        center=MFCC_CENTER,
        pad_mode=MFCC_PAD_MODE,
    )
    # librosa returns (n_mfcc, T); the MCD API expects (T, n_mfcc).
    return np.ascontiguousarray(mfcc.T, dtype=np.float32)


def mcd(
    a_mfcc: np.ndarray,
    b_mfcc: np.ndarray,
    *,
    threshold: float = _MCD_THRESHOLD_DEFAULT_DB,
    threshold_ci: tuple[float, float] | None = None,
    n_resamples: int = _MCD_N_RESAMPLES_DEFAULT,
    block_size: int = _MCD_BLOCK_SIZE_DEFAULT,
    rng: np.random.Generator | None = None,
) -> MetricResult:
    """Mel Cepstral Distortion (dB) between two MFCC sequences, DTW-aligned.

    ``a_mfcc`` and ``b_mfcc`` are ``(T, n_coef)`` MFCC arrays with
    ``n_coef >= 25`` (we use coefficients 1..24, skipping ``c_0`` /
    energy per Kominek et al. 2008). The point estimate is the mean per
    DTW-aligned-frame MCD; the CI is block-bootstrapped over per-frame
    MCD values with ``block_size`` contiguous-frame blocks (default 25 ≈
    250 ms at 10 ms hop) — see :func:`bootstrap_ci`.

    ``direction="lower_better"``: ``passes`` ⇔ CI upper bound below
    ``threshold`` (default 500 dB — calibrated 2026-05-12 against the
    OpenJTalk-HMM canary distribution per ``docs/quality_gate.md`` L86;
    the literature 6 dB Kominek 2008 placeholder applied to native MCEP
    and does not transfer to librosa's log-mel-power DCT scale).

    Returns an undetermined :class:`MetricResult` when either sequence is
    shorter than ``block_size`` frames (block bootstrap needs at least
    one full block per resample).

    Lazy imports ``librosa.sequence`` for DTW; the ``[verify-similarity]``
    and ``[diffsinger]`` extras both pull in librosa.
    """
    if a_mfcc.ndim != 2 or b_mfcc.ndim != 2:
        raise ValueError("mcd needs (T, n_coef) 2-D MFCC arrays")
    if a_mfcc.shape[1] < MFCC_N_COEF or b_mfcc.shape[1] < MFCC_N_COEF:
        raise ValueError(
            f"mcd needs ≥ {MFCC_N_COEF} MFCC coefficients per frame "
            f"(skipping c_0); got a={a_mfcc.shape[1]}, b={b_mfcc.shape[1]}"
        )
    if a_mfcc.shape[0] < block_size or b_mfcc.shape[0] < block_size:
        return _undetermined(
            "mcd", threshold, direction="lower_better", threshold_ci=threshold_ci
        )

    from librosa.sequence import dtw as _dtw

    _, path = _dtw(X=a_mfcc.T, Y=b_mfcc.T, metric="euclidean", subseq=False)
    pairs_a = a_mfcc[path[:, 0], _MCD_COEF_LO:MFCC_N_COEF]
    pairs_b = b_mfcc[path[:, 1], _MCD_COEF_LO:MFCC_N_COEF]
    diffs_sq = (pairs_a - pairs_b) ** 2
    per_frame_mcd_db = _MCD_DB_SCALE * np.sqrt(2.0 * diffs_sq.sum(axis=1))

    rng = rng if rng is not None else np.random.default_rng()
    ci_block = min(block_size, per_frame_mcd_db.size)
    lo, hi = bootstrap_ci(
        per_frame_mcd_db,
        n_resamples=n_resamples,
        rng=rng,
        block_size=ci_block,
    )
    return MetricResult(
        name="mcd",
        value=float(per_frame_mcd_db.mean()),
        ci_low=lo,
        ci_high=hi,
        threshold=threshold,
        direction="lower_better",
        threshold_ci=threshold_ci,
    )


_WAVLM_COSINE_DEFAULT_THRESHOLD = 0.60  # spec stage_2.md criterion #1 (HMM/4-partial separable)
_WAVLM_COSINE_DEFAULT_N_RESAMPLES = 300
_WAVLM_COSINE_DEFAULT_BLOCK_SIZE = 25   # ≈ 500 ms at WavLM's 20 ms frame stride — time-correlated frames


def wavlm_cosine(
    reference_emb: np.ndarray,
    candidate_emb: np.ndarray,
    *,
    threshold: float = _WAVLM_COSINE_DEFAULT_THRESHOLD,
    threshold_ci: tuple[float, float] | None = None,
    n_resamples: int = _WAVLM_COSINE_DEFAULT_N_RESAMPLES,
    block_size: int = _WAVLM_COSINE_DEFAULT_BLOCK_SIZE,
    rng: np.random.Generator | None = None,
) -> MetricResult:
    """Cosine similarity between a reference and a candidate WavLM ``(T, D)`` embedding.

    Bootstrap CI uses **block bootstrap** (``block_size`` contiguous frames per
    resample) over candidate frames against a fixed reference mean — plain
    i.i.d. percentile bootstrap on time-correlated WavLM frames under-estimates
    CI and violates R5 (``docs/quality_gate.md`` L68 — "Time-correlated
    samples must pass ``block_size`` to engage the block bootstrap path").

    The argument order ``(reference_emb, candidate_emb)`` is semantic, not
    syntactic: the candidate is what we resample, the reference mean is the
    fixed pole. ``profile_match.match_distance`` follows the same convention
    (``candidate_emb`` resampled, ``profile_mean`` fixed) so CI bounds carry
    a single, consistent meaning across the gate.

    Thin wrapper around :class:`vocaboot.profile_match.WavLMSpeakerSimilarity`
    so the verify layer has a metric-shaped surface (``metrics.wavlm_cosine``
    → :class:`MetricResult`) without duplicating the WavLM extraction code.
    Lazy imports :mod:`vocaboot.profile_match` to avoid circular module load.
    """
    from vocaboot.profile_match import WavLMSpeakerSimilarity

    impl = WavLMSpeakerSimilarity(
        threshold=threshold,
        n_resamples=n_resamples,
        block_size=block_size,
    )
    raw = impl.mean_cosine(reference_emb, candidate_emb, rng=rng)
    return MetricResult(
        name="wavlm_cosine",
        value=raw.value,
        ci_low=raw.ci_low,
        ci_high=raw.ci_high,
        threshold=threshold,
        direction="higher_better",
        threshold_ci=threshold_ci,
    )
