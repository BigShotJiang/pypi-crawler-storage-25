"""SVS engine (Layer 4) — ONNX vocoder + synthetic acoustic fallback.

Two synthesis paths share the same registry-pinned NSF-HiFiGAN vocoder:

  - **Synthetic acoustic** (Stage 1 smoke / `vocaboot demo`): when
    ``voice_ckpt`` is the literal string ``"synthetic"`` (or ``None``), the
    engine produces a **4-partial harmonic oscillator** driven by the score's
    note sequence — *not* a vocal-tract-filtered voice. The phoneme sequence
    (``ph_seq``) is **deliberately ignored** at Stage 1; vowel formants,
    consonant transients and prosody are deferred to the BYO acoustic path
    (Stage 2). The output suffices to prove the end-to-end smoke pipeline
    works without depending on a license-clean acoustic checkpoint (see
    Stage 0 result (B) in ``docs/ckpt_registry.md``); it does *not* sound
    like a singing voice.
  - **BYO acoustic** (user-supplied DiffSinger ONNX): planned for Stage 2
    once a phoneme-encoder + variance + acoustic dispatch is wired.
    Currently raises :class:`EngineNotWiredError`.

The vocoder file is **not** bundled. :mod:`vocaboot.pipeline` enforces the
``--accept-nc`` gate before invoking ``synth`` on the synthetic path, since
the bundled vocoder is CC-BY-NC-SA-4.0. ``_load_vocoder`` independently
re-verifies the registry-pinned SHA-256 at every call to refuse tampered
or unexpected weights.
"""

from __future__ import annotations

import hashlib
import os
from pathlib import Path

import numpy as np

from vocaboot.input import Score
from vocaboot.license_check import LicenseRefusedError

SAMPLE_RATE = 44100
N_MEL = 128
HOP = 512
WIN = 2048
F_MIN = 40
F_MAX = 16000

_DEFAULT_VOCODER_CACHE = (
    Path.home() / ".cache" / "vocaboot" / "ckpts"
    / "nsf_hifigan_onnx_v1" / "nsf_hifigan_onnx" / "nsf_hifigan.onnx"
)
_VOCODER_ENV = "VOCABOOT_VOCODER_PATH"
_PINNED_VOCODER_SHA256 = "a3e26672a8c655e3faf65f31cb4339a7fbca7758ba86be9af89e03dced7c3fa4"

_NOTE_OFFSETS = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


class EngineNotWiredError(NotImplementedError):
    """Raised when the BYO acoustic path is requested before Stage 2."""


class VocoderNotFoundError(FileNotFoundError):
    """The registry-pinned NSF-HiFiGAN vocoder is not on disk."""


class VocoderHashMismatchError(RuntimeError):
    """The vocoder on disk does not match the registry-pinned SHA-256."""


def vocoder_path() -> Path:
    """Resolve the vocoder ONNX path (env override > default cache)."""
    env_value = os.environ.get(_VOCODER_ENV)
    return Path(env_value) if env_value else _DEFAULT_VOCODER_CACHE


def _sha256_of_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_vocoder(*, accept_nc: bool = False):
    """Load the registry-pinned NSF-HiFiGAN vocoder.

    The NC gate here is the **inner choke point** for defense-in-depth: even
    Python-API callers that bypass ``vocaboot.pipeline`` cannot reach the
    vocoder without explicitly setting ``accept_nc=True``. This is paired
    with the CLI-level ``--accept-nc`` flag and the pipeline.run guard so
    license refusal applies at four layers (CLI → pipeline → synth →
    _load_vocoder). The NC check fires **before** any optional-dep import
    so the refusal is deterministic regardless of which extras are installed.
    """
    if not accept_nc:
        raise LicenseRefusedError(
            "NSF-HiFiGAN vocoder is CC-BY-NC-SA-4.0. Pass accept_nc=True "
            "(or --accept-nc at the CLI) to confirm personal, non-commercial use."
        )

    import onnxruntime as ort

    p = vocoder_path()
    if not p.is_file():
        raise VocoderNotFoundError(
            f"vocaboot vocoder not found at {p}. "
            f"Set {_VOCODER_ENV} to override, or run `vocaboot demo --download-ckpt` "
            f"to fetch openvpi NSF-HiFiGAN (CC-BY-NC-SA-4.0; SHA-256 pinned to "
            f"{_PINNED_VOCODER_SHA256})."
        )
    actual = _sha256_of_file(p)
    if actual != _PINNED_VOCODER_SHA256:
        raise VocoderHashMismatchError(
            f"vocoder at {p} has SHA-256 {actual} but the registry pins "
            f"{_PINNED_VOCODER_SHA256}. Refusing to load a tampered or "
            f"unexpected vocoder. Re-download from "
            f"https://github.com/openvpi/vocoders/releases."
        )
    return ort.InferenceSession(str(p), providers=["CPUExecutionProvider"])


def _note_to_hz(note: str) -> float:
    """Parse a name like 'C4' / 'F#5' / 'r' into Hz. Rest / unknown → 0.0."""
    s = note.strip()
    if not s or s.lower() in ("r", "rest", "-"):
        return 0.0
    letter = s[0].upper()
    if letter not in _NOTE_OFFSETS:
        return 0.0
    semitone = _NOTE_OFFSETS[letter]
    i = 1
    if i < len(s) and s[i] in "#b":
        semitone += 1 if s[i] == "#" else -1
        i += 1
    try:
        octave = int(s[i:])
    except (ValueError, IndexError):
        return 0.0
    midi = (octave + 1) * 12 + semitone
    return float(440.0 * 2 ** ((midi - 69) / 12))


def _synthetic_mel_and_f0(score: Score) -> tuple[np.ndarray, np.ndarray]:
    """Build (log-mel [T, 128], f0 [T]) from a score's note sequence.

    Generates a 4-partial harmonic oscillator (amplitudes 0.5 / 0.25 / 0.12
    / 0.08, post-scaled by 0.3) at each note's f0, concatenated according to
    ``score.note_dur``. The phoneme sequence is **deliberately ignored** —
    this is a smoke fallback, not vowel-formant synthesis. The result is
    converted to log-mel matching the NSF-HiFiGAN training params.
    """
    import librosa

    n_samples = round(sum(score.note_dur) * SAMPLE_RATE)
    audio = np.zeros(n_samples, dtype=np.float32)
    f0_track = np.zeros(n_samples, dtype=np.float32)

    cursor = 0
    for note, dur in zip(score.note_seq, score.note_dur, strict=False):
        seg_len = round(dur * SAMPLE_RATE)
        end = min(cursor + seg_len, n_samples)
        hz = _note_to_hz(note)
        if hz > 0 and end > cursor:
            t = np.arange(end - cursor) / SAMPLE_RATE
            sig = 0.5 * np.sin(2 * np.pi * hz * t)
            sig += 0.25 * np.sin(2 * np.pi * 2 * hz * t)
            sig += 0.12 * np.sin(2 * np.pi * 3 * hz * t)
            sig += 0.08 * np.sin(2 * np.pi * 4 * hz * t)
            audio[cursor:end] = 0.3 * sig
            f0_track[cursor:end] = hz
        cursor = end

    mel = librosa.feature.melspectrogram(
        y=audio,
        sr=SAMPLE_RATE,
        n_fft=WIN,
        hop_length=HOP,
        win_length=WIN,
        n_mels=N_MEL,
        fmin=F_MIN,
        fmax=F_MAX,
        power=1.0,
    )
    log_mel = np.log(np.maximum(mel, 1e-5)).astype(np.float32).T

    # librosa.melspectrogram uses center=True by default, so frame i is
    # centered at sample i * HOP (audio is reflect-padded internally).
    # The off-by-half-frame previously here (i + 0.5) caused a 5.8 ms drift.
    n_frames = log_mel.shape[0]
    frame_idx = np.clip(
        (np.arange(n_frames) * HOP).astype(int), 0, n_samples - 1
    )
    f0_frames = f0_track[frame_idx].astype(np.float32)
    return log_mel, f0_frames


def _is_synthetic(voice_ckpt) -> bool:
    if voice_ckpt is None:
        return True
    s = str(voice_ckpt).strip().lower()
    return s in ("synthetic", "none", "")


def synth(
    score: Score,
    voice_ckpt: Path | str | None,
    *,
    per_phoneme_note_seq: tuple[str, ...] | None = None,
    per_phoneme_note_dur: tuple[float, ...] | None = None,
    sample_rate: int = SAMPLE_RATE,
    accept_nc: bool = False,
) -> np.ndarray:
    """Synthesize a mono float32 audio array from ``score`` using a vocoder.

    The synthetic-acoustic path (``voice_ckpt='synthetic'``) is the Stage 1
    smoke target. The BYO acoustic path is reserved for Stage 2.

    ``accept_nc`` must be ``True`` to load the CC-BY-NC-SA-4.0 NSF-HiFiGAN
    vocoder — this is the inner choke point of the three-layer NC gate
    (CLI → pipeline → svs_engine). Python-API callers that bypass pipeline
    still cannot reach the vocoder without consenting here.
    """
    if sample_rate != SAMPLE_RATE:
        raise ValueError(
            f"vocaboot Stage 1 vocoder is locked to {SAMPLE_RATE} Hz, got {sample_rate}"
        )

    # BYO acoustic path raises before touching any optional dep / NC weight,
    # so it's checked first.
    if not _is_synthetic(voice_ckpt):
        raise EngineNotWiredError(
            f"BYO acoustic path (--voice {voice_ckpt}) lands in Stage 2. "
            f"For Stage 1 smoke, pass --voice synthetic."
        )

    # Synthetic path WILL load the NC vocoder. The NC gate must fire BEFORE
    # any optional-dep import (librosa) so the refusal is deterministic
    # regardless of which extras are installed. ``_load_vocoder`` below
    # re-checks (defense-in-depth) for callers that reach it directly.
    if not accept_nc:
        raise LicenseRefusedError(
            "NSF-HiFiGAN vocoder is CC-BY-NC-SA-4.0. Pass accept_nc=True "
            "(or --accept-nc at the CLI) to confirm personal, non-commercial use."
        )

    mel, f0 = _synthetic_mel_and_f0(score)
    sess = _load_vocoder(accept_nc=accept_nc)
    mel_input = mel[None, :, :]
    f0_input = f0[None, :]
    wav = sess.run(["waveform"], {"mel": mel_input, "f0": f0_input})[0]
    return np.asarray(wav[0], dtype=np.float32)
