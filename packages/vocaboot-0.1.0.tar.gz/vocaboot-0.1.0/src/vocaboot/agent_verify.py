"""Agent-verify gate (Layer 6).

Single operating mode: pyworld F0 / HNR with R5 bootstrap CIs. **No
subprocess, no Claude dependency, $0 install footprint.** OSS adopters
who do not have Claude Code installed never pay for verify.

History note (2026-05-12, step 5e): an opt-in ``VerifyMode.AGENT`` was
designed in Round 35 to add an Agent A subprocess (``claude -p``)
running a static codereview against the pipeline files. Round-26-style
re-review surfaced the same LLM-as-judge fragility that previously got
Agent C excluded from the verdict (number-fabrication regression),
applied identically to Agent A. The mode was therefore removed before
wiring; per-commit code review is delegated to CI (kluster integration
+ GitHub Actions), where it belongs.

Aggregation: APPROVE ⇔ numeric metrics all pass with CI strictly above
their thresholds. Any determined-and-failing metric → REJECT. Anything
in between (CI straddles threshold, undetermined data, silence) → REVIEW.
Agent C (qualitative LLM-as-judge advisory) still runs as
**museum-annotation only**; it is structurally excluded from the verdict.

Speaker-similarity metrics (WavLM cosine, ECAPA-TDNN) join this gate in
Stage 2 once profile-match lands, behind the ``[verify-similarity]`` extra
(declared in ``pyproject.toml`` alongside ``[verify]``) so the default
Stage 1 install stays footprint-minimal. The Stage 2 wire-in is gated by
``docs/stage_2.md`` acceptance criterion 5 and the WavLM-base sha256 pin
in ``docs/ckpt_registry.md``.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING

from vocaboot import metrics
from vocaboot.agent_advisory import (
    Advisory,
    gather_advisory,
)
from vocaboot.metrics import MetricResult

if TYPE_CHECKING:
    from vocaboot.input import Score
    from vocaboot.profile_match import VoiceProfile


class Verdict(str, Enum):
    APPROVE = "APPROVE"
    REVIEW = "REVIEW"
    REJECT = "REJECT"


@dataclass(frozen=True)
class GateResult:
    """The whole gate's structured output."""

    verdict: Verdict
    metrics: tuple[MetricResult, ...]
    advisories: tuple[Advisory, ...]  # NOT used by ``verdict``


def _numeric_verdict(metric_results: tuple[MetricResult, ...]) -> Verdict:
    """Apply the numeric-only verdict rule.

    APPROVE ⇔ every metric is determined *and* passes its threshold.
    REJECT  ⇔ any metric is determined *and* fails its threshold.
    REVIEW  otherwise (some metric undetermined / CI straddles).
    """
    if all(m.passes for m in metric_results):
        return Verdict.APPROVE
    if any(m.is_determined and not m.passes for m in metric_results):
        return Verdict.REJECT
    return Verdict.REVIEW


def run(
    audio_path: Path | str,
    *,
    score: Score,
    ckpt: Path,
    reference_voice: VoiceProfile | None = None,
) -> GateResult:
    """Run the agent-verify gate on a generated wav.

    ``score`` and ``ckpt`` are kept in the signature for Stage 1 caller
    parity (Agent C wiring and museum-entry recording are deferred to a
    later stage). They do not influence the verdict.

    ``reference_voice`` controls verify tier (Stage 2 step 3b,
    ``docs/stage_2.md`` §agent_verify.run extension):

    * ``None`` → **Tier 1 only**: the legacy pyworld f0_stability + hnr
      path. APPROVE here proves the pipeline rings — any harmonic-rich
      signal (including the synthetic 4-partial oscillator from
      :mod:`vocaboot.svs_engine`) clears the Tier 1 thresholds.
    * supplied :class:`VoiceProfile` (``schema_version=2``) → **Tier 2**:
      adds :func:`metrics.mcd` (against
      ``reference_voice.mfcc_cepstra``) and :func:`metrics.wavlm_cosine`
      (against ``reference_voice.wavlm_embedding``) to the verdict. The
      synthetic 4-partial oscillator REJECTs in Tier 2 (MCD CI strictly
      above the band AND cosine CI strictly below 0.60 against a real
      voice), closing criterion #1 of the Stage 2 spec.

    Why ``VoiceProfile`` rather than ``Path``: a ``Path`` parameter would
    let agent_verify trigger ``profile_match.build`` (torch + transformers
    + WavLM weights) when called, breaking the import-safe property of the
    verify module. The ``Path → VoiceProfile`` conversion is the
    responsibility of the CLI / ``pipeline.run`` layer — they are also the
    only layers that pass through the ``audio_ingest`` consent gate, so the
    R15 audit trail is preserved and Stage 2.5's MCP boundary invariant
    (Claude cannot manufacture a ``VoiceProfile``) holds without an extra
    runtime check.
    """
    import numpy as np
    import soundfile as sf

    from vocaboot.privacy import refuse_if_protected

    refuse_if_protected(audio_path, kind="verify_target")
    audio, sr = sf.read(str(audio_path), always_2d=False)
    if audio.ndim > 1:
        audio = audio.mean(axis=1)
    audio = np.ascontiguousarray(audio, dtype=np.float64)
    f0 = metrics.f0_stability(audio, sr)
    h = metrics.hnr(audio, sr)
    numeric: tuple[MetricResult, ...] = (f0, h)

    if reference_voice is not None:
        ref_mfcc = reference_voice.mfcc_cepstra
        ref_wavlm = reference_voice.wavlm_embedding
        if ref_mfcc is None:
            raise ValueError(
                "Tier 2 verify requires a VoiceProfile with mfcc_cepstra "
                "populated (schema_version=2). The supplied reference has "
                "no MFCC fields — rebuild the profile via "
                "`vocaboot profile` to populate them. See "
                "docs/stage_2.md §Schema_version=2 contract."
            )
        # Lazy import: profile_match pulls librosa + torch + transformers
        # only when feature extraction runs, keeping the Tier 1 path on
        # the default install footprint.
        from vocaboot.profile_match import extract_for_verify

        cand_wavlm, cand_mfcc = extract_for_verify(audio_path)
        mcd_result = metrics.mcd(
            cand_mfcc,
            ref_mfcc,
            threshold_ci=metrics.MCD_THRESHOLD_BAND_DB,
        )
        # Reference is the fixed pole, candidate is what we bootstrap over
        # — argument order (reference, candidate) is semantic, not syntactic.
        cos_result = metrics.wavlm_cosine(ref_wavlm, cand_wavlm)
        numeric = (f0, h, mcd_result, cos_result)

    verdict = _numeric_verdict(numeric)
    advisories = gather_advisory(audio_path)
    return GateResult(verdict=verdict, metrics=numeric, advisories=advisories)
