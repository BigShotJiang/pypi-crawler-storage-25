"""Checkpoint license gate + CC-BY-NC-SA-4.0 attribution emission (Layer 2).

Refuses checkpoints whose license is incompatible with the default OSS tier
(Apache-2.0, MIT, CC-BY-4.0, CC0). Community DiffSinger checkpoints under
CC-BY-NC-SA require the user to pass ``--accept-nc`` and confirm
non-commercial personal use.

**Attribution emission (Stage 1 step 5d)**: when ``accept_nc=True`` triggers
the NC vocoder path, :func:`emit_attribution_notice` writes the bundled
``LICENSE_NOTICE.txt`` next to the output wav and prints a 4-line summary
to stdout. This satisfies CC-BY-NC-SA-4.0 §3(a)(1) (creator + URI +
license indicator) and §3(a)(1)(B) (modification indicator) on every NC
run, not just on first install.
"""

from __future__ import annotations

import sys
from pathlib import Path

LICENSE_NOTICE_SUFFIX = ".LICENSE_NOTICE.txt"

# SPDX identifiers we accept without further user opt-in.
DEFAULT_TIER: frozenset[str] = frozenset(
    {"Apache-2.0", "MIT", "CC-BY-4.0", "CC0-1.0", "CC0"}
)

# SPDX identifiers we accept only with explicit non-commercial opt-in.
NC_TIER: frozenset[str] = frozenset(
    {"CC-BY-NC-SA-4.0", "CC-BY-NC-4.0", "CC-BY-NC-SA-3.0"}
)


class LicenseRefusedError(ValueError):
    """Raised when a checkpoint's license is not loadable in the current mode."""


def check_license(
    license_spdx: str,
    *,
    ckpt_path: Path | str,
    accept_nc: bool = False,
) -> None:
    """Refuse incompatible licenses. No-op when the license is acceptable."""
    if license_spdx in DEFAULT_TIER:
        return
    if license_spdx in NC_TIER:
        if accept_nc:
            return
        raise LicenseRefusedError(
            f"refusing {ckpt_path}: license {license_spdx} is non-commercial. "
            f"Pass --accept-nc to use this checkpoint for personal, non-commercial use only."
        )
    raise LicenseRefusedError(
        f"refusing {ckpt_path}: license {license_spdx!r} is outside the allow-list "
        f"(default tier: {sorted(DEFAULT_TIER)}, NC tier with --accept-nc: {sorted(NC_TIER)})."
    )


def resolve_license_notice_text() -> str:
    """Return the bundled CC-BY-NC-SA-4.0 attribution notice text.

    Delegates path resolution to :mod:`vocaboot._resources` so the
    wheel-vs-editable fallback is shared with the demo-score resolver.
    """
    from vocaboot import _resources

    dev = Path(__file__).resolve().parent / "_data" / "LICENSE_NOTICE.txt"
    return _resources.bundled_resource_text(
        "_data/LICENSE_NOTICE.txt", dev_tree_fallback=dev
    )


def emit_attribution_notice(out_wav: Path, *, stream=None) -> Path:
    """Write the CC-BY-NC-SA-4.0 attribution next to ``out_wav`` and stdout-summarize.

    Returns the absolute path of the written notice file. The full
    license text is on disk; the stdout summary is intentionally short
    (4 lines) so it does not flood pipelines that grep the wav banner.

    ``stream`` defaults to a *lazy* ``sys.stdout`` lookup so test capture
    (``capsys``, ``CliRunner``) sees the output. Caching ``sys.stdout`` at
    import time would bypass pytest's stdout redirection.
    """
    if stream is None:
        stream = sys.stdout
    if not isinstance(out_wav, Path):
        out_wav = Path(out_wav)
    notice_text = resolve_license_notice_text()
    notice_path = out_wav.with_name(out_wav.name + LICENSE_NOTICE_SUFFIX)
    # Idempotent: skip the write when the file already exists with the
    # exact bundled content. This preserves user-edited derivative-work
    # attribution (e.g. downstream "modified by …" lines) on re-emit.
    if not (notice_path.exists() and notice_path.read_text(encoding="utf-8") == notice_text):
        notice_path.write_text(notice_text, encoding="utf-8")
    summary = (
        "vocaboot: NSF-HiFiGAN vocoder is CC-BY-NC-SA-4.0\n"
        "  Provider: OpenVPI Community / DiffSinger Community\n"
        "  Source:   https://github.com/openvpi/vocoders/releases\n"
        f"  Full notice: {notice_path}\n"
    )
    stream.write(summary)
    stream.flush()
    return notice_path
