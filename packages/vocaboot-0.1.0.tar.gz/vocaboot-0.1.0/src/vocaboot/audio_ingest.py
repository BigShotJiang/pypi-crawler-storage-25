"""User-audio ingest contextmanager (Stage 2, Layer 5).

Bridge between the privacy gate (Stage 1.5-B) and the profile / synth flow.
Wraps a user-supplied audio path with a consent-checked, R15-safe lifecycle:

  1. ``privacy.refuse_user_audio_without_consent`` runs *before* anything
     else. If either consent flag is missing, the ingest raises
     :class:`ConsentRequiredError` and no tmp dir is created.
  2. ``privacy.refuse_if_protected`` resolves symlinks and refuses paths
     that match a protected reference pattern — a symlink pointing at
     ``~/.ssh/id_rsa`` (or a user-private voice corpus) is caught here,
     not at copy time.
  3. The sha256 of the **original** audio file is computed once. Both
     :class:`IngestedAudio` and downstream :func:`profile_match.build`
     consume the same precomputed value rather than re-hashing the tmp copy.
  4. ``tempfile.mkdtemp(prefix='vocaboot-ingest-')`` creates a per-call,
     ``0o700`` temporary directory. The user audio is ``shutil.copy2``'d
     into it and the copy is ``chmod 0o600``'d before yield so that a
     concurrent process on a multi-user host cannot read the buffered copy
     even momentarily.
  5. On exit (success **or** exception), ``shutil.rmtree`` removes the tmp
     dir without ``ignore_errors`` — a real-world cleanup failure
     (read-only fs, deleted dir, permissions) is surfaced rather than
     silently leaving a directory behind. The original audio path is
     untouched in every code path.

Museum key contract: callers that want a museum failure
entry from ingest **must** key the audio path under :data:`_MUSEUM_KEY_MAP`
(``"reference"`` → ``"reference_voice_path"``, ``"target"`` →
``"target_voice_path"``). Both keys are members of
:data:`vocaboot.museum._USER_AUDIO_REDACT_KEYS`, so the path is fully
redacted to ``"<redacted-user-audio>"`` rather than scrubbed to
``{basename, sha256}`` — basenames of user files would otherwise leak.

MCP boundary invariant (Stage 2.5 forward-declaration): this surface is
exposed by **CLI and Python API only**. The Stage 2.5 MCP server does not
publish ``ingest()`` as a tool. Downstream MCP tools take an already-built
:class:`IngestedAudio` (or its persisted :class:`VoiceProfile`) so Claude
cannot manufacture consent through an MCP ``bool`` argument. The CLI
accepts consent via flags or via ``VOCABOOT_CONSENT_NO_STORE`` /
``VOCABOOT_CONSENT_NO_REDISTRIBUTE`` env vars; a Python caller passing
literal ``True`` is permitted for tests and library use.
"""

from __future__ import annotations

import contextlib
import hashlib
import os
import shutil
import stat
import tempfile
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from vocaboot.privacy import (
    ConsentRequiredError,  # noqa: F401  (re-exported for CLI convenience)
    refuse_if_protected,
    refuse_user_audio_without_consent,
)

Intent = Literal["reference", "target"]

_TMP_PREFIX = "vocaboot-ingest-"

_MUSEUM_KEY_MAP: dict[Intent, str] = {
    "reference": "reference_voice_path",
    "target": "target_voice_path",
}

_CONSENT_NO_STORE_ENV = "VOCABOOT_CONSENT_NO_STORE"
_CONSENT_NO_REDISTRIBUTE_ENV = "VOCABOOT_CONSENT_NO_REDISTRIBUTE"


@dataclass(frozen=True)
class IngestedAudio:
    """Consent-checked, R15-safe wrapper around a temporary copy of user audio.

    ``path`` points at the **tmp copy** managed by :func:`ingest` — it is
    deleted when the contextmanager exits and must not be retained by the
    caller. ``source_sha256`` identifies the original artifact (computed
    on the user-supplied path, not the tmp copy) so downstream code can
    pin provenance without re-reading the audio.
    """

    path: Path
    intent: Intent
    consent_no_store: bool
    consent_no_redistribute: bool
    source_sha256: str


def museum_key_for(intent: Intent) -> str:
    """Return the museum redact-key name for the given intent.

    Callers that build museum failure entries from an ingest exception
    must route the audio path under this key so
    :data:`vocaboot.museum._USER_AUDIO_REDACT_KEYS` redacts it. Using an
    ad-hoc ``"_path"``-suffixed key (e.g. ``"tmp_copy_path"``) would fall
    through to the generic ``{basename, sha256}`` scrubber and leak the
    original file name through the tmp basename.
    """
    if intent not in _MUSEUM_KEY_MAP:
        raise ValueError(
            f"unknown ingest intent {intent!r}; valid intents: "
            f"{sorted(_MUSEUM_KEY_MAP)}"
        )
    return _MUSEUM_KEY_MAP[intent]


def _sha256_of_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _validate_regular_file(p: Path) -> None:
    """Refuse non-regular files (FIFO, device, socket) before copy.

    ``shutil.copy2`` on a FIFO blocks forever; on a device file it can
    succeed silently with garbage content. We require a real ``REG`` stat
    type before any copy is attempted. The path is resolved (symlink
    followed) first so a symlink to ``/dev/zero`` is still caught.
    """
    try:
        resolved = p.resolve(strict=True)
    except FileNotFoundError as e:
        raise FileNotFoundError(
            f"audio_ingest: source file {p} does not exist"
        ) from e
    st = resolved.stat()
    if not stat.S_ISREG(st.st_mode):
        raise ValueError(
            f"audio_ingest: refusing non-regular source {p} (resolved={resolved}); "
            f"only regular files are accepted (FIFO / device / socket refused)."
        )


def _consent_from_env(name: str) -> bool:
    """Read a consent env var as a strict boolean (``"1"``, ``"true"`` accepted)."""
    raw = os.environ.get(name, "").strip().lower()
    return raw in ("1", "true", "yes", "on")


def resolve_consent_no_store(cli_flag: bool) -> bool:
    """Combine the CLI flag and ``VOCABOOT_CONSENT_NO_STORE`` env var (OR)."""
    return bool(cli_flag) or _consent_from_env(_CONSENT_NO_STORE_ENV)


def resolve_consent_no_redistribute(cli_flag: bool) -> bool:
    """Combine the CLI flag and ``VOCABOOT_CONSENT_NO_REDISTRIBUTE`` env var (OR)."""
    return bool(cli_flag) or _consent_from_env(_CONSENT_NO_REDISTRIBUTE_ENV)


@contextlib.contextmanager
def ingest(
    audio: Path | str,
    *,
    intent: Intent,
    consent_no_store: bool,
    consent_no_redistribute: bool,
) -> Iterator[IngestedAudio]:
    """Yield a consent-checked, R15-safe :class:`IngestedAudio`.

    Five-step contract (``docs/stage_2.md``):

      1. ``refuse_user_audio_without_consent`` + ``refuse_if_protected``
         (both before any tmp work)
      2. compute ``source_sha256`` on the **original** path
      3. ``mkdtemp(prefix="vocaboot-ingest-")`` inside ``try``/``finally``
      4. ``copy2`` + ``chmod 0o600`` → yield ``IngestedAudio(path=tmp, ...)``
      5. ``finally: rmtree`` (no ``ignore_errors``; cleanup failures surface)

    Use as::

        with ingest(p, intent="reference",
                    consent_no_store=True,
                    consent_no_redistribute=True) as ia:
            profile = profile_match.build(
                ia.path, precomputed_sha256=ia.source_sha256
            )
    """
    audio_path = Path(audio)
    # Step 1: consent + protected-path refusals BEFORE any tmp work.
    refuse_user_audio_without_consent(
        audio_path,
        consent_no_store=consent_no_store,
        consent_no_redistribute=consent_no_redistribute,
        intent=intent,
    )
    refuse_if_protected(audio_path, kind="user_audio")
    _validate_regular_file(audio_path)

    # Step 2: hash the ORIGINAL, not the tmp copy. profile_match.build
    # can reuse this via its precomputed_sha256= kwarg, avoiding a 2nd
    # full-file read.
    source_sha256 = _sha256_of_file(audio_path)

    # Step 3: per-call tmp dir; mkdtemp is 0o700 by Python contract.
    tmp_dir = Path(tempfile.mkdtemp(prefix=_TMP_PREFIX))
    try:
        # Step 4: copy2 preserves mtime; chmod 0o600 overrides the umask so
        # the copy is not group-readable on multi-user hosts.
        tmp_file = tmp_dir / audio_path.name
        shutil.copy2(str(audio_path), str(tmp_file))
        os.chmod(tmp_file, 0o600)
        yield IngestedAudio(
            path=tmp_file,
            intent=intent,
            consent_no_store=consent_no_store,
            consent_no_redistribute=consent_no_redistribute,
            source_sha256=source_sha256,
        )
    finally:
        # Step 5: surface cleanup failures rather than ignore them.
        shutil.rmtree(tmp_dir)
