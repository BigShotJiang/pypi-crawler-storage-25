"""vocaboot — terminal-first singing voice synthesis framework."""

__version__ = "0.1.0"
