"""Voice profile builder and matcher (Stage 2, Layer 5).

Turns a reference audio into a (T, D) WavLM-base embedding + F0 statistics +
spectral-centroid summary, then measures cosine similarity to candidate audio
through a Stage-3-compatible :class:`SpeakerSimilarityProtocol` surface.

Storage choice: the WavLM embedding is held as ``bytes`` + ``shape`` + ``dtype``
rather than a live ``np.ndarray`` because ``@dataclass(frozen=True)`` only
forbids field rebinding — ``arr[0] = 0`` on an ndarray field would still
succeed and silently mutate a shared profile. ``bytes`` are structurally
immutable and the embedding is reconstructed lazily through the
:py:attr:`VoiceProfile.wavlm_embedding` property.

Supply chain: WavLM-base weights are not bundled. The full HuggingFace
repository layout (`config.json`, `preprocessor_config.json`,
`pytorch_model.bin`, etc.) lives under ``~/.cache/vocaboot/models/wavlm-base/``
(override the directory containing the bin via ``VOCABOOT_WAVLM_PATH``,
which points at the artifact file itself). The runtime sha256 of the
on-disk ``pytorch_model.bin`` is verified against the registry pin in
``docs/ckpt_registry.md`` (kept in sync by ``tests/test_ckpt_registry_pin_consistency.py``)
before any inference — defense-in-depth identical to the NSF-HiFiGAN
vocoder gate.

The whole module is import-safe without the ``[verify-similarity]`` extra:
torch / transformers / librosa / pyworld are imported lazily inside the
helpers that need them, so callers that only touch :class:`VoiceProfile`
round-trip can do so on a vanilla install.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable

import numpy as np

from vocaboot.metrics import (
    MFCC_SAMPLE_RATE as _WAVLM_SAMPLE_RATE,
)
from vocaboot.metrics import (
    MetricResult,
    mfcc_extract,
)

_WAVLM_CACHE_DEFAULT = (
    Path.home() / ".cache" / "vocaboot" / "models" / "wavlm-base" / "pytorch_model.bin"
)
_WAVLM_ENV = "VOCABOOT_WAVLM_PATH"
_PINNED_WAVLM_SHA256 = "b41ab60fdcdc113ff164212c72b371dcd420a5773ca1f6c8f54d6809225ce072"
_PINNED_WAVLM_REVISION = "efa81aae7ff777e464159e0f877d54eac5b84f81"

_PROFILE_SCHEMA_VERSION = 2
_SPEAKER_COSINE_DEFAULT_THRESHOLD = 0.70
_SPEAKER_COSINE_DEFAULT_BLOCK_SIZE = 25   # ≈ 500 ms at WavLM's 20 ms frame stride


class WavLMNotFoundError(FileNotFoundError):
    """WavLM-base weights are not on disk under the registry cache path."""


class WavLMHashMismatchError(RuntimeError):
    """WavLM weights on disk do not match the registry-pinned sha256."""


@dataclass(frozen=True)
class F0Stats:
    """Voiced-portion F0 statistics in Hz."""

    mean_hz: float
    std_hz: float
    min_hz: float
    max_hz: float
    voiced_fraction: float


@dataclass(frozen=True)
class VoiceProfile:
    """Target-voice fingerprint (Stage 2 spec, ``docs/stage_2.md`` §Module surfaces).

    ``wavlm_embedding_bytes`` is the raw little-endian byte serialization of a
    ``(T, D)`` float32 (default) embedding. Reconstruct via
    :py:attr:`wavlm_embedding`. ``mfcc_cepstra_bytes`` similarly holds a
    ``(T_frames, MFCC_N_COEF)`` float32 cepstrogram extracted with the
    pinned parameters in :mod:`vocaboot.metrics` (Stage 2 step 3b — MFCC
    population lives in :func:`build`, the only layer that owns the
    audio-feature extraction pipeline). The bytes representation
    guarantees structural immutability under
    ``@dataclass(frozen=True)`` — ``arr[0] = 0`` would still mutate an
    ndarray field through Python's object identity.

    ``schema_version`` is bumped to 2 in Stage 2 step 3b. Legacy
    ``schema_version=1`` sidecars (no ``mfcc_cepstra_*`` fields, no MCD
    reference) are rejected by :meth:`from_json_dict` — pre-alpha
    acceptable break documented in ``docs/stage_2.md`` §Schema_version=2
    contract. The dataclass-side ``mfcc_cepstra_*`` defaults remain
    ``None`` so callers can still construct a partial profile in-memory
    for tests (e.g. WavLM-only round-trip when MCD is out of scope), but
    the on-disk schema enforces populated fields at version 2.
    """

    wavlm_embedding_bytes: bytes
    wavlm_embedding_shape: tuple[int, int]
    wavlm_embedding_dtype: str
    f0_stats: F0Stats
    spectral_centroid_mean: float
    duration_seconds: float
    source_sha256: str
    mfcc_cepstra_bytes: bytes | None = None
    mfcc_cepstra_shape: tuple[int, int] | None = None
    mfcc_cepstra_dtype: str | None = None
    schema_version: int = _PROFILE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        """Enforce the schema=2 MFCC triple atomicity (R17 audit, 2026-05-12).

        The three ``mfcc_cepstra_*`` fields are conceptually one payload.
        Allowing one to be ``None`` while another is set silently degrades
        the ``mfcc_cepstra`` property to ``None`` even though bytes are
        present, masking data loss. The on-disk JSON path already refuses
        this via :meth:`from_json_dict`, but the in-memory dataclass
        constructor used to leak the partial state — this check closes it.
        """
        triple = (
            self.mfcc_cepstra_bytes,
            self.mfcc_cepstra_shape,
            self.mfcc_cepstra_dtype,
        )
        n_set = sum(1 for x in triple if x is not None)
        if n_set not in (0, 3):
            raise ValueError(
                f"VoiceProfile mfcc_cepstra_{{bytes,shape,dtype}} must be all-None "
                f"(WavLM-only partial profile, in-memory tests) or all-set "
                f"(schema=2 with MCD reference). Got partial: "
                f"bytes={'set' if triple[0] is not None else 'None'}, "
                f"shape={'set' if triple[1] is not None else 'None'}, "
                f"dtype={'set' if triple[2] is not None else 'None'}."
            )

    @property
    def wavlm_embedding(self) -> np.ndarray:
        """Reconstruct the embedding as a read-only ndarray view of the bytes."""
        arr = np.frombuffer(
            self.wavlm_embedding_bytes,
            dtype=np.dtype(self.wavlm_embedding_dtype),
        ).reshape(self.wavlm_embedding_shape)
        return arr

    @property
    def mfcc_cepstra(self) -> np.ndarray | None:
        """Reconstruct the MFCC sequence as a read-only ndarray, or ``None``.

        Returns ``None`` when any of the three ``mfcc_cepstra_*`` fields is
        unpopulated (in-memory partial profile). Callers that require MCD
        readiness (``agent_verify`` Tier 2 path) must check for ``None``
        and either error or downgrade to WavLM-only verification.
        """
        if (
            self.mfcc_cepstra_bytes is None
            or self.mfcc_cepstra_shape is None
            or self.mfcc_cepstra_dtype is None
        ):
            return None
        return np.frombuffer(
            self.mfcc_cepstra_bytes,
            dtype=np.dtype(self.mfcc_cepstra_dtype),
        ).reshape(self.mfcc_cepstra_shape)

    def to_json_dict(self) -> dict:
        """Return a JSON-serializable dict (bytes go through base64)."""
        mfcc_b64 = (
            base64.b64encode(self.mfcc_cepstra_bytes).decode("ascii")
            if self.mfcc_cepstra_bytes is not None
            else None
        )
        return {
            "schema_version": self.schema_version,
            "wavlm_embedding_b64": base64.b64encode(self.wavlm_embedding_bytes).decode("ascii"),
            "wavlm_embedding_shape": list(self.wavlm_embedding_shape),
            "wavlm_embedding_dtype": self.wavlm_embedding_dtype,
            "mfcc_cepstra_b64": mfcc_b64,
            "mfcc_cepstra_shape": (
                list(self.mfcc_cepstra_shape)
                if self.mfcc_cepstra_shape is not None
                else None
            ),
            "mfcc_cepstra_dtype": self.mfcc_cepstra_dtype,
            "f0_stats": asdict(self.f0_stats),
            "spectral_centroid_mean": self.spectral_centroid_mean,
            "duration_seconds": self.duration_seconds,
            "source_sha256": self.source_sha256,
        }

    @classmethod
    def from_json_dict(cls, data: dict) -> VoiceProfile:
        """Inverse of :meth:`to_json_dict`; refuses unknown ``schema_version``.

        Legacy ``schema_version=1`` sidecars carry no ``mfcc_cepstra_*``
        fields and therefore cannot serve as a Tier 2 MCD reference. They
        are rejected with a "rebuild via vocaboot profile" instruction
        (``docs/stage_2.md`` §Schema_version=2 contract — Alpha-grade
        break, no migration path).
        """
        version = int(data.get("schema_version", _PROFILE_SCHEMA_VERSION))
        if version != _PROFILE_SCHEMA_VERSION:
            raise ValueError(
                f"VoiceProfile schema_version {version!r} not supported by "
                f"this build (expected {_PROFILE_SCHEMA_VERSION}). Legacy "
                f"schema=1 sidecars predate the Stage 2 step 3b MFCC field "
                f"set and cannot serve as a Tier 2 MCD reference — rebuild "
                f"via `vocaboot profile` (pre-alpha acceptable break, see "
                f"docs/stage_2.md §Schema_version=2 contract)."
            )
        embedding_bytes = base64.b64decode(data["wavlm_embedding_b64"].encode("ascii"))
        shape_list = data["wavlm_embedding_shape"]
        if len(shape_list) != 2:
            raise ValueError(
                f"VoiceProfile shape must be 2-D (T, D), got {shape_list!r}"
            )
        shape: tuple[int, int] = (int(shape_list[0]), int(shape_list[1]))

        mfcc_b64 = data.get("mfcc_cepstra_b64")
        mfcc_bytes: bytes | None
        mfcc_shape: tuple[int, int] | None
        mfcc_dtype: str | None
        if mfcc_b64 is not None:
            mfcc_bytes = base64.b64decode(mfcc_b64.encode("ascii"))
            mfcc_shape_list = data.get("mfcc_cepstra_shape")
            if mfcc_shape_list is None or len(mfcc_shape_list) != 2:
                raise ValueError(
                    f"VoiceProfile mfcc_cepstra_shape must be 2-D "
                    f"(T_frames, MFCC_N_COEF), got {mfcc_shape_list!r}"
                )
            mfcc_shape = (int(mfcc_shape_list[0]), int(mfcc_shape_list[1]))
            mfcc_dtype_raw = data.get("mfcc_cepstra_dtype")
            if mfcc_dtype_raw is None:
                raise ValueError(
                    "VoiceProfile has mfcc_cepstra_b64 but no "
                    "mfcc_cepstra_dtype — JSON is internally inconsistent."
                )
            mfcc_dtype = str(mfcc_dtype_raw)
        else:
            mfcc_bytes = None
            mfcc_shape = None
            mfcc_dtype = None

        return cls(
            wavlm_embedding_bytes=embedding_bytes,
            wavlm_embedding_shape=shape,
            wavlm_embedding_dtype=str(data["wavlm_embedding_dtype"]),
            f0_stats=F0Stats(**data["f0_stats"]),
            spectral_centroid_mean=float(data["spectral_centroid_mean"]),
            duration_seconds=float(data["duration_seconds"]),
            source_sha256=str(data["source_sha256"]),
            mfcc_cepstra_bytes=mfcc_bytes,
            mfcc_cepstra_shape=mfcc_shape,
            mfcc_cepstra_dtype=mfcc_dtype,
            schema_version=version,
        )


def save(profile: VoiceProfile, out_path: Path | str) -> Path:
    """Persist a :class:`VoiceProfile` to a JSON sidecar; returns the path."""
    out = Path(out_path)
    out.write_text(
        json.dumps(profile.to_json_dict(), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return out


def load(json_path: Path | str) -> VoiceProfile:
    """Read a :class:`VoiceProfile` JSON sidecar produced by :func:`save`."""
    p = Path(json_path)
    return VoiceProfile.from_json_dict(json.loads(p.read_text(encoding="utf-8")))


def wavlm_weights_path() -> Path:
    """Resolve the WavLM-base weights path (env override > registry cache)."""
    env_value = os.environ.get(_WAVLM_ENV)
    return Path(env_value) if env_value else _WAVLM_CACHE_DEFAULT


def _sha256_of_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _verify_wavlm_weights(p: Path) -> None:
    """Refuse weights whose sha256 doesn't match the registry pin.

    The pin (`_PINNED_WAVLM_SHA256`) is mirrored in ``docs/ckpt_registry.md``
    and enforced by ``tests/test_ckpt_registry_pin_consistency.py``. Any
    mismatch — tampering, an unexpected upstream revision, a partial
    download — raises :class:`WavLMHashMismatchError` before transformers
    sees the bytes.
    """
    actual = _sha256_of_file(p)
    if actual != _PINNED_WAVLM_SHA256:
        raise WavLMHashMismatchError(
            f"WavLM weights at {p} have sha256 {actual} but vocaboot pins "
            f"{_PINNED_WAVLM_SHA256}. Refusing to load tampered or unexpected "
            f"weights. Re-download from https://huggingface.co/microsoft/wavlm-base."
        )


def _load_wavlm_model():
    """Verify on-disk weights, then load WavLM-base via transformers.

    Lazy imports — :mod:`torch` and :mod:`transformers` ship with the
    optional ``[verify-similarity]`` extra. The default install does not
    pay for them.
    """
    p = wavlm_weights_path()
    if not p.is_file():
        raise WavLMNotFoundError(
            f"WavLM-base weights not at {p}. Run "
            f"`huggingface_hub.snapshot_download(repo_id='microsoft/wavlm-base', "
            f"revision='{_PINNED_WAVLM_REVISION}', local_dir='{p.parent}')` to "
            f"populate the full HF layout, or point {_WAVLM_ENV} at a "
            f"pre-downloaded pytorch_model.bin. See docs/ckpt_registry.md "
            f"§'Stage 2 verify-similarity weights'."
        )
    _verify_wavlm_weights(p)
    import torch
    from transformers import WavLMModel

    model = WavLMModel.from_pretrained(str(p.parent))
    model.eval()
    return model, torch


def _load_audio_16k(audio: Path | str) -> np.ndarray:
    """Load + resample to 16 kHz mono float32 (WavLM's training rate)."""
    import librosa

    y, _sr = librosa.load(str(audio), sr=_WAVLM_SAMPLE_RATE, mono=True)
    return np.ascontiguousarray(y, dtype=np.float32)


def _wavlm_embed(audio_16k: np.ndarray) -> np.ndarray:
    """Return WavLM-base ``last_hidden_state`` as (T, D) float32."""
    model, torch = _load_wavlm_model()
    with torch.no_grad():
        x = torch.from_numpy(audio_16k).unsqueeze(0)
        hidden = model(x).last_hidden_state.squeeze(0).cpu().numpy()
    return np.ascontiguousarray(hidden, dtype=np.float32)


def _f0_stats_from_audio(audio: np.ndarray, sample_rate: int) -> F0Stats:
    """Compute :class:`F0Stats` on voiced frames via pyworld harvest + stonemask."""
    import pyworld as pw

    x = np.asarray(audio, dtype=np.float64)
    f0, t_axis = pw.harvest(x, sample_rate, f0_floor=80.0, f0_ceil=800.0)
    f0 = pw.stonemask(x, f0, t_axis, sample_rate)
    voiced = f0[f0 > 0]
    if voiced.size == 0 or f0.size == 0:
        return F0Stats(0.0, 0.0, 0.0, 0.0, 0.0)
    return F0Stats(
        mean_hz=float(voiced.mean()),
        std_hz=float(voiced.std()),
        min_hz=float(voiced.min()),
        max_hz=float(voiced.max()),
        voiced_fraction=float(voiced.size / f0.size),
    )


def _spectral_centroid_mean(audio: np.ndarray, sample_rate: int) -> float:
    """Mean of the spectral centroid (Hz) across all frames."""
    import librosa

    sc = librosa.feature.spectral_centroid(
        y=audio.astype(np.float32), sr=sample_rate
    )
    return float(sc.mean())


def build(
    reference_wav: Path | str,
    *,
    precomputed_sha256: str | None = None,
) -> VoiceProfile:
    """Build a :class:`VoiceProfile` from a reference audio file.

    Stage 2 acceptance criterion 4: ``build(wav)`` → :func:`save` → :func:`load`
    → :func:`match_distance(loaded, wav)` returns cosine ≥ 0.99 (numerical
    identity within float tolerance). pyworld + spectral centroid run at the
    file's native rate; WavLM and MFCC run at 16 kHz (resampled inside).

    ``precomputed_sha256`` lets :mod:`vocaboot.audio_ingest` pass its own
    hash of the *original* (pre-tmp-copy) audio so we do not re-hash the
    file. Without it, ``build`` falls back to hashing whatever path the
    caller hands in (the contract for direct Python-API users).
    """
    p = Path(reference_wav)
    import soundfile as sf

    audio_native, native_sr = sf.read(str(p), always_2d=False)
    if audio_native.ndim > 1:
        audio_native = audio_native.mean(axis=1)
    audio_native = np.ascontiguousarray(audio_native, dtype=np.float32)
    duration = float(audio_native.size / max(native_sr, 1))

    audio_16k = (
        audio_native if native_sr == _WAVLM_SAMPLE_RATE else _load_audio_16k(p)
    )
    embedding = _wavlm_embed(audio_16k)
    if embedding.ndim != 2 or embedding.size == 0:
        raise RuntimeError(
            f"WavLM embedding for {p} has unexpected shape {embedding.shape}; "
            f"refusing to build a profile from a degenerate embedding."
        )

    # MFCC extraction (Stage 2 step 3b): runs on
    # the same 16 kHz audio that WavLM consumes so the reference cepstrogram
    # is parameter-identical to the candidate cepstrogram extracted in
    # ``agent_verify`` Tier 2 path. Pin lives in ``vocaboot.metrics`` as
    # ``MFCC_*`` public constants; drift is structurally caught by
    # ``tests/test_mfcc_params_pinned.py``.
    mfcc = mfcc_extract(audio_16k)
    if mfcc.ndim != 2 or mfcc.size == 0:
        raise RuntimeError(
            f"MFCC extraction for {p} returned unexpected shape "
            f"{mfcc.shape}; refusing to build a profile."
        )

    f0_stats = _f0_stats_from_audio(audio_native, native_sr)
    sc_mean = _spectral_centroid_mean(audio_native, native_sr)
    source_sha = (
        precomputed_sha256 if precomputed_sha256 is not None else _sha256_of_file(p)
    )

    return VoiceProfile(
        wavlm_embedding_bytes=embedding.tobytes(),
        wavlm_embedding_shape=(int(embedding.shape[0]), int(embedding.shape[1])),
        wavlm_embedding_dtype=str(embedding.dtype),
        mfcc_cepstra_bytes=mfcc.tobytes(),
        mfcc_cepstra_shape=(int(mfcc.shape[0]), int(mfcc.shape[1])),
        mfcc_cepstra_dtype=str(mfcc.dtype),
        f0_stats=f0_stats,
        spectral_centroid_mean=sc_mean,
        duration_seconds=duration,
        source_sha256=source_sha,
    )


def extract_for_verify(audio_path: Path | str) -> tuple[np.ndarray, np.ndarray]:
    """Return ``(wavlm_embedding, mfcc_cepstra)`` at 16 kHz from an audio file.

    Lightweight feature extraction for the ``agent_verify`` Tier 2 path —
    pulls only the two features that drive the Tier 2 metrics
    (:func:`metrics.wavlm_cosine` + :func:`metrics.mcd`) without the f0 /
    spectral-centroid / sha256 work that :func:`build` does for a full
    :class:`VoiceProfile`. agent_verify already computes f0_stability /
    hnr on the output via :mod:`vocaboot.metrics`, so re-running pyworld
    inside :func:`build` would double the cost.

    Both features come from the **same 16 kHz array** so MFCC and WavLM
    are frame-aligned to identical audio bytes — the parameter pin in
    :mod:`vocaboot.metrics` (``MFCC_*`` constants) is then sufficient to
    guarantee MCD reads a real voice distance rather than a settings
    mismatch.
    """
    audio_16k = _load_audio_16k(audio_path)
    embedding = _wavlm_embed(audio_16k)
    mfcc = mfcc_extract(audio_16k)
    return embedding, mfcc


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity between two 1-D vectors; 0 on zero-norm inputs."""
    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))
    if na == 0.0 or nb == 0.0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def _undetermined_speaker_cosine(
    threshold: float,
    *,
    name: str = "speaker_cosine",
    threshold_ci: tuple[float, float] | None = None,
) -> MetricResult:
    if threshold_ci is not None:
        t_lo, t_hi = threshold_ci
        return MetricResult(
            name=name,
            value=float("nan"),
            ci_low=t_lo - 1.0,
            ci_high=t_hi + 1.0,
            threshold=threshold,
            direction="higher_better",
            threshold_ci=threshold_ci,
        )
    return MetricResult(
        name=name,
        value=float("nan"),
        ci_low=threshold - 1.0,
        ci_high=threshold + 1.0,
        threshold=threshold,
        direction="higher_better",
    )


def _bootstrap_mean_cosine(
    candidate_emb: np.ndarray,
    reference_mean: np.ndarray,
    *,
    n_resamples: int,
    rng: np.random.Generator,
    block_size: int = _SPEAKER_COSINE_DEFAULT_BLOCK_SIZE,
) -> tuple[float, float]:
    """Bootstrap a 95% CI on cos(mean(resampled_frames), reference_mean).

    The candidate is what we resample, the reference mean is the fixed pole.
    We re-sample candidate frames with replacement, recompute the mean
    embedding for each resample, then compute its cosine to the (fixed)
    reference mean.

    Block bootstrap (R5 compliance, ``docs/quality_gate.md`` L68): WavLM
    embeddings are frame-by-frame time-correlated, so we draw contiguous
    blocks of ``block_size`` frames rather than i.i.d. frames. Plain
    percentile bootstrap on time-correlated samples under-estimates CI
    width. ``block_size`` is clipped to ``T`` when the candidate is shorter
    than one full block.
    """
    t_frames = candidate_emb.shape[0]
    effective_block = max(1, min(block_size, t_frames))
    n_blocks = (t_frames + effective_block - 1) // effective_block
    starts = rng.integers(
        0, t_frames - effective_block + 1, size=(n_resamples, n_blocks)
    )
    offsets = np.arange(effective_block)
    indices = (starts[:, :, None] + offsets[None, None, :]).reshape(n_resamples, -1)
    indices = indices[:, :t_frames]
    # shape (n_resamples, t_frames, D) → mean over t_frames axis
    means = candidate_emb[indices].mean(axis=1)
    ref_norm = float(np.linalg.norm(reference_mean))
    if ref_norm == 0.0:
        return float(reference_mean.sum()) * 0.0, float(reference_mean.sum()) * 0.0
    means_norm = np.linalg.norm(means, axis=1)
    safe = means_norm > 0
    cosines = np.zeros(n_resamples, dtype=np.float64)
    cosines[safe] = (means[safe] @ reference_mean) / (means_norm[safe] * ref_norm)
    lo, hi = np.quantile(cosines, [0.025, 0.975])
    return float(lo), float(hi)


def match_distance(
    profile: VoiceProfile,
    candidate_wav: Path | str,
    *,
    threshold: float = _SPEAKER_COSINE_DEFAULT_THRESHOLD,
    threshold_ci: tuple[float, float] | None = None,
    n_resamples: int = 300,
    block_size: int = _SPEAKER_COSINE_DEFAULT_BLOCK_SIZE,
    rng: np.random.Generator | None = None,
) -> MetricResult:
    """Bootstrap-CI'd cosine similarity between a profile and a candidate wav.

    Returns a :class:`MetricResult` named ``"speaker_cosine"`` under the
    "larger is better" convention. The point estimate is
    ``cos(mean_t(profile_emb), mean_t(candidate_emb))``; the CI is
    block-bootstrapped (``block_size`` contiguous frames per resample) over
    candidate frames against a fixed profile mean.

    Stage 2 acceptance criterion 2 (discrimination canary): different
    speakers ⇒ ``value ≤ 0.7``; identity ⇒ ``value ≥ 0.99``.
    """
    candidate_path = Path(candidate_wav)
    audio_16k = _load_audio_16k(candidate_path)
    candidate_emb = _wavlm_embed(audio_16k)
    if candidate_emb.ndim != 2 or candidate_emb.shape[0] == 0:
        return _undetermined_speaker_cosine(threshold, threshold_ci=threshold_ci)

    profile_mean = profile.wavlm_embedding.mean(axis=0)
    candidate_mean = candidate_emb.mean(axis=0)
    value = _cosine(candidate_mean, profile_mean)

    rng = rng if rng is not None else np.random.default_rng()
    ci_low, ci_high = _bootstrap_mean_cosine(
        candidate_emb,
        profile_mean,
        n_resamples=n_resamples,
        rng=rng,
        block_size=block_size,
    )
    return MetricResult(
        name="speaker_cosine",
        value=value,
        ci_low=ci_low,
        ci_high=ci_high,
        threshold=threshold,
        direction="higher_better",
        threshold_ci=threshold_ci,
    )


@runtime_checkable
class SpeakerSimilarityProtocol(Protocol):
    """Stage 2 / Stage 3 shared speaker-embedding contract.

    Declaring this in Stage 2 avoids the rewrite-to-shared-base-class
    scenario that would otherwise hit in Stage 3 when SVC consumes a
    :class:`VoiceProfile` as a target through the same embed / mean_cosine
    API surface (``docs/stage_2.md`` criterion 9).
    """

    def embed(self, audio: Path) -> np.ndarray: ...

    def mean_cosine(self, a: np.ndarray, b: np.ndarray) -> MetricResult: ...


@dataclass(frozen=True)
class WavLMSpeakerSimilarity:
    """Concrete :class:`SpeakerSimilarityProtocol` implementation for Stage 2.

    Frozen dataclass with three tunables (``threshold``, ``n_resamples``,
    ``block_size``); construction is cheap and instances are immutable so
    they can serve as Protocol implementations. Stage 3 SVC will provide a
    parallel implementation backed by its own embedder while keeping the
    same public ``embed`` / ``mean_cosine`` signatures.
    """

    threshold: float = _SPEAKER_COSINE_DEFAULT_THRESHOLD
    n_resamples: int = 300
    block_size: int = _SPEAKER_COSINE_DEFAULT_BLOCK_SIZE
    threshold_ci: tuple[float, float] | None = None

    def embed(self, audio: Path | str) -> np.ndarray:
        return _wavlm_embed(_load_audio_16k(audio))

    def mean_cosine(
        self,
        reference: np.ndarray,
        candidate: np.ndarray,
        *,
        rng: np.random.Generator | None = None,
    ) -> MetricResult:
        """Cosine of mean embeddings, with block-bootstrap CI over candidate frames.

        The reference is the fixed pole and the candidate is what we resample
        — bootstrap CI semantics demand a clear "which side varies" choice.
        Callers must pass embeddings in ``(reference, candidate)`` order so
        the CI consistently measures the candidate's frame-distribution
        variability, not the reference's. ``metrics.wavlm_cosine`` and
        ``match_distance`` follow the same convention.
        """
        if (
            reference.ndim != 2
            or candidate.ndim != 2
            or reference.shape[0] == 0
            or candidate.shape[0] == 0
        ):
            return _undetermined_speaker_cosine(
                self.threshold, threshold_ci=self.threshold_ci
            )
        mean_ref = reference.mean(axis=0)
        mean_cand = candidate.mean(axis=0)
        value = _cosine(mean_cand, mean_ref)
        rng = rng if rng is not None else np.random.default_rng()
        ci_low, ci_high = _bootstrap_mean_cosine(
            candidate,
            mean_ref,
            n_resamples=self.n_resamples,
            rng=rng,
            block_size=self.block_size,
        )
        return MetricResult(
            name="speaker_cosine",
            value=value,
            ci_low=ci_low,
            ci_high=ci_high,
            threshold=self.threshold,
            direction="higher_better",
            threshold_ci=self.threshold_ci,
        )
