"""Score alignment helpers (Layer 3).

Converts a per-syllable :class:`vocaboot.input.Score` into the per-phoneme
arrays that the DiffSinger ONNX session expects. The mapping is deliberately
shallow — vocaboot does *not* re-quantize timing; mismatched input is the
loader's responsibility, not this layer's.
"""

from __future__ import annotations

from vocaboot.input import Score


def per_phoneme_note_dur(score: Score) -> tuple[float, ...]:
    """Expand per-syllable note_dur to per-phoneme duration.

    Each note covers a contiguous block of phonemes whose ph_dur values sum
    to the note's duration. We rely on the score being already aligned, which
    ``vocaboot.input.load_ds`` enforces; here we just propagate.
    """
    return score.ph_dur


def per_phoneme_note_seq(score: Score) -> tuple[str, ...]:
    """Expand per-syllable note_seq to per-phoneme pitch labels.

    Walks ph_dur and accumulates time until the next note boundary. CV pairs
    map cleanly because ``load_ds`` validated equal totals.
    """
    if len(score.note_seq) == len(score.ph_seq):
        return score.note_seq

    out: list[str] = []
    note_idx = 0
    note_remaining = score.note_dur[0]
    for dur in score.ph_dur:
        if note_remaining <= 0 and note_idx + 1 < len(score.note_dur):
            note_idx += 1
            note_remaining = score.note_dur[note_idx]
        out.append(score.note_seq[note_idx])
        note_remaining -= dur
    return tuple(out)
