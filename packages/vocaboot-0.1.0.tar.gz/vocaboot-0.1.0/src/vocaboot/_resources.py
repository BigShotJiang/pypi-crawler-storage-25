"""Internal bundled-resource resolver (not a layer module — surface helper).

Shared resolution path for files shipped inside the vocaboot package
(``src/vocaboot/_data/*``). Two locations must work transparently:

  1. **Wheel install** — ``importlib.resources`` finds the file at
     ``vocaboot/_data/<name>``. Wheels bundle ``_data/`` automatically
     (hatchling default for non-``.py`` files inside the package); the
     ``examples/short.ds → vocaboot/_data/short.ds`` ``force-include``
     in ``pyproject.toml`` mirrors the dev-tree copy at build time.
  2. **Editable install / source tree** — ``importlib.resources`` may
     return a non-existent path or raise; fall back to a relative
     path supplied by the caller.

This helper is intentionally *underscore-prefixed* (private) so it does
not count toward the layer-module ceiling (≤ 12). Callers — ``cli`` and
``license_check`` — pass their own dev-tree fallback path because the
two resources live in different relative spots (``examples/short.ds``
vs ``src/vocaboot/_data/LICENSE_NOTICE.txt``).
"""

from __future__ import annotations

from pathlib import Path


class BundledResourceNotFoundError(FileNotFoundError):
    """Neither the wheel-bundled nor the dev-tree path resolved."""


def bundled_resource_path(
    relative_inside_package: str,
    *,
    dev_tree_fallback: Path,
) -> Path:
    """Locate a packaged data file.

    ``relative_inside_package`` is the path inside the ``vocaboot``
    package (e.g. ``"_data/short.ds"``). ``dev_tree_fallback`` is the
    absolute or relative path used when the wheel-bundled copy is not
    present (editable install / running from source). Raises
    ``BundledResourceNotFoundError`` if neither resolves — a corrupted
    install; callers should surface as exit 1.
    """
    try:
        import importlib.resources as ir

        ref = ir.files("vocaboot").joinpath(relative_inside_package)
        if ref.is_file():
            # `as_file` would be more correct for zipped wheels, but
            # vocaboot wheels are not zip-only and the bundled files are
            # tiny; the str(ref) → Path round-trip is enough.
            return Path(str(ref))
    except (ModuleNotFoundError, AttributeError, TypeError):
        pass

    if dev_tree_fallback.is_file():
        return dev_tree_fallback

    raise BundledResourceNotFoundError(
        f"vocaboot resource not found: tried importlib.resources "
        f"('vocaboot/{relative_inside_package}') and dev-tree fallback "
        f"({dev_tree_fallback}). Reinstall vocaboot."
    )


def bundled_resource_text(
    relative_inside_package: str,
    *,
    dev_tree_fallback: Path,
    encoding: str = "utf-8",
) -> str:
    """Convenience: read a packaged data file as text."""
    return bundled_resource_path(
        relative_inside_package, dev_tree_fallback=dev_tree_fallback
    ).read_text(encoding=encoding)
