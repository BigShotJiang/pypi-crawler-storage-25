"""Audio writer (Layer 5).

Single responsibility: write a float32 ndarray to a 16-bit PCM wav at the
declared sample rate. I/O only — *no* signal-quality checks here.

Clip detection, NaN/Inf detection, RMS sanity, and any other signal-quality
assertion belongs to the agent-verify gate (Layer 6, ``vocaboot.agent_verify``,
specifically agent A codereview + agent B numeric metrics). Keeping this
module thin lets the verify gate own the entire judgement surface.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import soundfile as sf


def write_wav(audio: np.ndarray, out: Path | str, sample_rate: int) -> Path:
    """Write `audio` (float32, mono) to `out` as 16-bit PCM. Returns the path."""
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if audio.ndim != 1:
        raise ValueError(f"expected mono audio (ndim=1), got ndim={audio.ndim}")
    sf.write(out, audio.astype(np.float32), sample_rate, subtype="PCM_16")
    return out
