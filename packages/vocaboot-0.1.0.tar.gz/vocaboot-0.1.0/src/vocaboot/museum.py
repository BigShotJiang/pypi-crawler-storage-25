"""Failure museum (Layer 8, R8).

Persists every failed run under ``_failures/<timestamp>_<reason>/`` so the
next attempt cannot repeat the same mistake. Three auto-triggers per the
architect Round 35 spec: engine error, agent-verify REJECT, consecutive
REJECT counter +1.

**R15 leak防止**: ``detail`` の中の path-like value はそのまま書かず、
``{basename, sha256}`` にスクラブしてから永続化する。フルパスが残ると
museum entry が leak チャネルになるため。
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

_PATH_LIKE_KEY_SUFFIXES = ("_path", "_paths", "_file", "_files")
_PATH_LIKE_KEYS = frozenset({"path", "paths", "file", "files"})

# User-audio keys are hard-excluded from museum: even ``{basename, sha256}``
# (the usual R15 scrub output) would leak — a basename like
# ``alice_voice_20260512.wav`` is identifying. Stage 2 any-song surfaces
# tag their inputs with these keys so the museum cannot persist them at all.
_USER_AUDIO_REDACT_KEYS = frozenset({
    "user_voice_path",
    "user_voice",
    "target_voice_path",
    "target_voice",
    "reference_voice_path",
    "reference_voice",
    "any_song_path",
    "any_song",
})
_USER_AUDIO_REDACTED = "<redacted-user-audio>"


def _is_path_like_key(key: str) -> bool:
    return key in _PATH_LIKE_KEYS or any(key.endswith(s) for s in _PATH_LIKE_KEY_SUFFIXES)


def _is_user_audio_key(key: str) -> bool:
    return key in _USER_AUDIO_REDACT_KEYS


_FILE_HASH_CHUNK = 1 << 20  # 1 MiB chunks; avoids OOM on long wav files.


def _hash_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        while True:
            chunk = f.read(_FILE_HASH_CHUNK)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _scrub_path_value(value: object) -> object:
    if not isinstance(value, (str, Path)):
        return value
    p = Path(str(value))
    out: dict[str, str] = {"basename": p.name}
    try:
        if p.is_file():
            out["sha256"] = _hash_file(p)
        else:
            out["sha256"] = "<missing>"
    except OSError:
        out["sha256"] = "<read-error>"
    return out


_CYCLE_PLACEHOLDER = "<cycle>"


def scrub_detail(
    detail: object,
    *,
    parent_key: str = "",
    _seen: set[int] | None = None,
) -> object:
    """Recursively replace path-like values with {basename, sha256} dicts.

    Walks nested dicts and lists/tuples. A value is treated as a path when its
    *key* (or the parent key, for list/tuple elements) is path-like, OR when
    the value itself is a :class:`pathlib.Path` instance (regardless of key).
    Non-path scalars pass through unchanged.

    **Cycle guard**: museum is the failure-path of last resort (R8) — it must
    survive cyclic references in exception detail. When a container is
    re-entered, it is replaced with ``"<cycle>"`` instead of recursing into a
    RecursionError.
    """
    seen = _seen if _seen is not None else set()

    if isinstance(detail, (dict, list, tuple)):
        obj_id = id(detail)
        if obj_id in seen:
            return _CYCLE_PLACEHOLDER
        seen = seen | {obj_id}

    if isinstance(detail, dict):
        return {
            k: (
                _USER_AUDIO_REDACTED
                if _is_user_audio_key(str(k))
                else scrub_detail(v, parent_key=str(k), _seen=seen)
            )
            for k, v in detail.items()
        }
    if isinstance(detail, (list, tuple)):
        scrubbed_seq = [scrub_detail(v, parent_key=parent_key, _seen=seen) for v in detail]
        return list(scrubbed_seq) if isinstance(detail, list) else tuple(scrubbed_seq)
    if isinstance(detail, Path):
        return _scrub_path_value(detail)
    if isinstance(detail, str) and _is_path_like_key(parent_key):
        return _scrub_path_value(detail)
    return detail


def archive_failure(
    *,
    root: Path | str,
    reason: str,
    detail: dict[str, object] | None = None,
) -> Path:
    """Create a timestamped failure entry. Returns the entry directory.

    ``detail`` is passed through :func:`scrub_detail` before being written, so
    full filesystem paths never reach the persisted ``metadata.json``.
    """
    root = Path(root)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    safe_reason = "".join(c if c.isalnum() or c in "-_" else "_" for c in reason)[:60]
    entry = root / f"{stamp}_{safe_reason}"
    entry.mkdir(parents=True, exist_ok=True)
    payload = {
        "reason": reason,
        "detail": scrub_detail(detail or {}),
        "timestamp_utc": stamp,
    }
    (entry / "metadata.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return entry
