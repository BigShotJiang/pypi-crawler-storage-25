"""Score input loader (Layer 1).

Reads DiffSinger v2.5 ``.ds`` files into a typed dataclass. Validation is
strict: the loader refuses to return a score whose ph_dur / note_dur totals
disagree, because that mismatch is a known step-5 blocker.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Score:
    """A single DiffSinger v2.5 score segment."""

    offset: float
    text: str
    ph_seq: tuple[str, ...]
    ph_dur: tuple[float, ...]
    note_seq: tuple[str, ...]
    note_dur: tuple[float, ...]
    note_slur: tuple[int, ...]
    lang: str
    license: str
    f0_timestep: float

    @property
    def total_seconds(self) -> float:
        return sum(self.ph_dur)


class ScoreFormatError(ValueError):
    """Raised when a .ds file is malformed or internally inconsistent."""


def load_ds(path: Path | str) -> Score:
    """Parse a DiffSinger ``.ds`` file and validate per-syllable alignment."""
    path = Path(path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not (isinstance(payload, list) and len(payload) == 1):
        raise ScoreFormatError(f"{path}: expected a JSON array with one segment")

    entry = payload[0]
    required = ("ph_seq", "ph_dur", "note_seq", "note_dur", "note_slur", "lang", "license")
    missing = [f for f in required if f not in entry]
    if missing:
        raise ScoreFormatError(f"{path}: missing required fields {missing}")

    ph_seq = tuple(entry["ph_seq"].split())
    ph_dur = tuple(float(x) for x in entry["ph_dur"].split())
    note_seq = tuple(entry["note_seq"].split())
    note_dur = tuple(float(x) for x in entry["note_dur"].split())
    note_slur = tuple(int(x) for x in entry["note_slur"].split())

    if len(ph_dur) == 0 or len(note_dur) == 0:
        raise ScoreFormatError(f"{path}: ph_dur and note_dur must be non-empty")
    if len(ph_seq) != len(ph_dur):
        raise ScoreFormatError(f"{path}: ph_seq ({len(ph_seq)}) != ph_dur ({len(ph_dur)})")
    if not (len(note_seq) == len(note_dur) == len(note_slur)):
        raise ScoreFormatError(
            f"{path}: note_seq/note_dur/note_slur token counts must agree: "
            f"{len(note_seq)}/{len(note_dur)}/{len(note_slur)}"
        )
    if abs(sum(ph_dur) - sum(note_dur)) > 1e-6:
        raise ScoreFormatError(
            f"{path}: ph_dur total {sum(ph_dur)} != note_dur total {sum(note_dur)}; "
            f"score is not self-consistent"
        )

    return Score(
        offset=float(entry.get("offset", 0.0)),
        text=str(entry.get("text", "")),
        ph_seq=ph_seq,
        ph_dur=ph_dur,
        note_seq=note_seq,
        note_dur=note_dur,
        note_slur=note_slur,
        lang=str(entry["lang"]),
        license=str(entry["license"]),
        f0_timestep=float(entry.get("f0_timestep", 0.01161)),
    )
