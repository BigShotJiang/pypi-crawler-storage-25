"""Privacy guard (Layer 0, R11/R15).

Refuses any input path that matches a protected reference pattern. The guard
must be structurally robust:

  - **NFKC + lower normalization** so full-width / katakana / mixed-script
    spellings cannot trivially bypass the substring match.
  - **Symlink resolve** so a link named ``voice.onnx`` pointing at a protected
    file is still refused.
  - **External patterns file** (``VOCABOOT_PROTECTED_PATTERNS`` env, or
    ``~/.config/vocaboot/protected_patterns.txt``) so private substring lists
    stay out of the OSS source tree. The default in-repo list intentionally
    holds only generic markers; project-specific names belong in the user's
    config file.

Per R11/R15: protected reference data is the user's, never vocaboot's; we
never load it as model input, never embed it, never publish it.

**Threat model — non-malicious.** This guard exists to stop the user from
accidentally pointing vocaboot at their own protected reference file
(typo, shell glob, symlink, history-recall). It is not a defense against
an adversary who can swap filesystem entries between this check and the
subsequent read (TOCTOU). Adversarial fd-based ingestion belongs in
``audio_ingest`` and is out of scope here.
"""

from __future__ import annotations

import os
import unicodedata
from pathlib import Path

# Generic placeholders kept in-source so the guard is non-empty on a fresh
# clone. Project-specific names belong in the external patterns file.
DEFAULT_PROTECTED_SUBSTRINGS: tuple[str, ...] = (
    "protected_voice",
    "target_profile_full",
)

USER_PATTERNS_ENV = "VOCABOOT_PROTECTED_PATTERNS"
USER_PATTERNS_DEFAULT = Path.home() / ".config" / "vocaboot" / "protected_patterns.txt"


class ProtectedReferenceError(ValueError):
    """Raised when a path matches a protected reference pattern."""


class ConsentRequiredError(ValueError):
    """Raised when user audio input arrives without explicit consent flags."""


def _normalize(text: str) -> str:
    """NFKC normalize + lowercase. Folds full-width / compat forms."""
    return unicodedata.normalize("NFKC", text).lower()


def _load_user_patterns() -> tuple[str, ...]:
    """Load extra patterns from env or default config file. Returns ()."""
    env_path = os.environ.get(USER_PATTERNS_ENV)
    path = Path(env_path).expanduser() if env_path else USER_PATTERNS_DEFAULT
    if not path.is_file():
        return ()
    extras: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        extras.append(_normalize(s))
    return tuple(extras)


def _all_patterns() -> tuple[str, ...]:
    base = tuple(_normalize(s) for s in DEFAULT_PROTECTED_SUBSTRINGS)
    return base + _load_user_patterns()


def _resolved_text(path: Path | str) -> str:
    """Return both the resolved and raw path text, joined for matching.

    We check both because a protected file may not exist on the local disk
    (e.g. CI sandbox), in which case ``resolve`` returns the lexical path —
    but the raw user-supplied text is still meaningful.
    """
    p = Path(path).expanduser()
    try:
        resolved = str(p.resolve(strict=False))
    except (OSError, RuntimeError):
        resolved = str(p.absolute())
    return f"{resolved}\n{Path(path)!s}"


def is_protected_path(path: Path | str) -> bool:
    """True if `path` matches any protected reference substring after NFKC."""
    text = _normalize(_resolved_text(path))
    return any(p in text for p in _all_patterns())


def refuse_if_protected(path: Path | str, kind: str = "checkpoint") -> None:
    """Raise ProtectedReferenceError if `path` is protected. No-op otherwise."""
    if is_protected_path(path):
        raise ProtectedReferenceError(
            f"refusing to load {kind} at {path}: matches protected reference pattern. "
            f"vocaboot must never accept private reference voice data as input. "
            f"If this is a false positive, remove the matching substring from "
            f"{USER_PATTERNS_DEFAULT} or the {USER_PATTERNS_ENV} env-pointed file."
        )


def refuse_user_audio_without_consent(
    path: Path | str,
    *,
    consent_no_store: bool,
    consent_no_redistribute: bool,
    intent: str = "reference",
) -> None:
    """Refuse any-song / user-audio input until both consent flags are True.

    Stage 2 introduces two user-audio surfaces — *reference voice* for
    profile-match and *target voice* for self-train SVS — both of which
    carry distinct legal / privacy exposure:

    - **no_store** (R15): vocaboot must not archive user audio.
      :func:`vocaboot.museum.scrub_detail` hard-excludes ``user_voice``
      keys (full redaction, not the usual ``{basename, sha256}``) so a
      future REJECT does not leak even the file name.
    - **no_redistribute** (CC-BY-NC-SA-4.0): running the NC vocoder on
      user audio and posting the output is bound by the NC clause; the
      user must acknowledge this before vocaboot accepts the input.

    Both flags are mandatory. ``intent`` is recorded in the error message
    (``"reference"`` or ``"target"``) so the caller knows which surface
    triggered the refusal; it does not affect the gate logic.
    """
    missing: list[str] = []
    if not consent_no_store:
        missing.append("consent_no_store")
    if not consent_no_redistribute:
        missing.append("consent_no_redistribute")
    if missing:
        raise ConsentRequiredError(
            f"refusing user audio ({intent}) at {path}: missing consent flag(s) "
            f"{', '.join(missing)}. Stage 2 any-song input requires both "
            f"'no_store' (R15) and 'no_redistribute' (NC vocoder clause) "
            f"acknowledgements before vocaboot loads the audio."
        )
