"""Stage 1 pipeline glue.

Wires the layered modules into the end-to-end synth flow:

    score path  ──▶ input.load_ds ──▶ score_align.expand
                                            │
                                            ▼
                                    svs_engine.synth ──▶ output.write_wav
                                                                │
        license_check.check_license  privacy.refuse_if_protected │
        (voice ckpt)                 (voice ckpt + score path)   │
                                                                 ▼
                                            agent_verify.run (numeric)
                                                                 │
                                            museum on REJECT / REVIEW
                                            and on engine error

The agent-verify gate is *mandatory* and runs pyworld F0 / HNR with R5
bootstrap CIs ($0, no Claude). ``skip_agent_verify=True`` (CLI:
``--no-agent-verify``) skips the gate for unit-testing the synth path
in isolation. Code review is delegated to CI (kluster + GHA), not run
per-synth (step 5e 2026-05-12 — Round-26-style LLM-as-judge fragility
applied identically to Agent A, so the AGENT mode was removed before
wiring).

R15: ``score_path`` is checked by the privacy guard too — a private score
filename must not reach the museum. R8: engine exceptions are archived
before re-raising so a step-5 wiring bug is not just lost.

CC-BY-NC-SA-4.0 attribution (step 5d): whenever ``accept_nc=True`` triggers
the NC vocoder path, :func:`vocaboot.license_check.emit_attribution_notice`
writes the bundled ``LICENSE_NOTICE.txt`` next to the output wav and
prints a 4-line summary to stdout. This satisfies the
distributor-attribution clause on every NC run.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from vocaboot import (
    agent_verify,
    license_check,
    museum,
    output,
    privacy,
    score_align,
    svs_engine,
)
from vocaboot import input as score_input

if TYPE_CHECKING:
    from vocaboot.profile_match import VoiceProfile

DEFAULT_FAILURES_ROOT = Path("_failures")


@dataclass(frozen=True)
class SmokeResult:
    """End-to-end stage 1 run summary."""

    wav_path: Path
    verdict: agent_verify.Verdict
    metrics: tuple[agent_verify.MetricResult, ...]
    license_notice_path: Path | None = None


def run(
    *,
    voice: Path | str,
    score_path: Path,
    out: Path,
    sample_rate: int = 44100,
    ckpt_license: str = "CC0-1.0",
    accept_nc: bool = False,
    skip_agent_verify: bool = False,
    failures_root: Path | None = None,
    reference_voice: VoiceProfile | None = None,
) -> SmokeResult:
    """Run the full Stage 1 pipeline against a single score and ckpt.

    Caller is responsible for choosing a ckpt that matches the registry; this
    function only enforces the *license* gate, the privacy gate, and the
    agent-verify (numeric) gate. It does not download or fetch checkpoints.

    ``reference_voice`` (Stage 2 step 3b, R17 audit 2026-05-12): when a
    ``VoiceProfile`` (``schema_version=2``) is supplied, the post-synth gate
    runs at **Tier 2** (adds MCD + WavLM cosine against the profile);
    ``None`` keeps Tier 1 behavior. The CLI / Python caller is responsible
    for loading the profile through :func:`vocaboot.profile_match.load`
    (which carries the audio_ingest consent trail) — pipeline never
    constructs a profile itself, preserving Stage 2.5's MCP boundary
    invariant (Claude cannot manufacture a VoiceProfile from MCP arguments).

    **Verdict caveat**: the Tier 1 verdict is computed from pyworld F0 / HNR
    with R5 bootstrap CIs. APPROVE on the synthetic-acoustic path proves the
    pipeline rings — it does **not** prove the output sounds like a voice.
    Tier 2 (``reference_voice`` supplied) adds spectral/timbral discrimination.
    """
    privacy.refuse_if_protected(voice, kind="checkpoint")
    privacy.refuse_if_protected(score_path, kind="score")

    # The synthetic-acoustic path still routes through the CC-BY-NC-SA-4.0
    # vocoder, so the NC gate applies even when the user did not supply a
    # voice ckpt. Without this check, --voice synthetic could load NC weights
    # silently — license laundering hazard (ア-C1 fix, 2026-05-12 critic).
    if svs_engine._is_synthetic(voice) and not accept_nc:
        raise license_check.LicenseRefusedError(
            "vocaboot --voice synthetic uses the registry-pinned NSF-HiFiGAN "
            "vocoder, which is CC-BY-NC-SA-4.0. Pass --accept-nc to confirm "
            "personal, non-commercial use."
        )
    license_check.check_license(ckpt_license, ckpt_path=voice, accept_nc=accept_nc)
    score = score_input.load_ds(score_path)
    aligned_note_seq = score_align.per_phoneme_note_seq(score)
    aligned_note_dur = score_align.per_phoneme_note_dur(score)

    failures = failures_root if failures_root is not None else DEFAULT_FAILURES_ROOT

    try:
        audio = svs_engine.synth(
            score,
            voice,
            per_phoneme_note_seq=aligned_note_seq,
            per_phoneme_note_dur=aligned_note_dur,
            accept_nc=accept_nc,
        )
    except svs_engine.EngineNotWiredError:
        # Step-5 sentinel — surfaces to the caller without museum noise.
        raise
    except Exception as exc:  # pragma: no cover  (step 5 onnx errors)
        museum.archive_failure(
            root=failures,
            reason="engine_error",
            detail={
                "exc_type": type(exc).__name__,
                "msg": str(exc)[:500],
                "ckpt_path": str(voice),
                "score_path": str(score_path),
            },
        )
        raise

    wav_path = output.write_wav(audio, out, sample_rate)

    # CC-BY-NC-SA-4.0 attribution: emit *after* the wav exists, so the
    # notice sits next to the file users will share/inspect. We only do
    # this when accept_nc=True — the only path that actually loaded NC
    # weights. License-clean future paths (default-tier ckpts) skip this.
    notice_path: Path | None = None
    if accept_nc:
        notice_path = license_check.emit_attribution_notice(wav_path)

    if skip_agent_verify:
        return SmokeResult(
            wav_path=wav_path,
            verdict=agent_verify.Verdict.REVIEW,
            metrics=(),
            license_notice_path=notice_path,
        )

    gate = agent_verify.run(
        wav_path, score=score, ckpt=voice, reference_voice=reference_voice
    )
    if gate.verdict in (agent_verify.Verdict.REJECT, agent_verify.Verdict.REVIEW):
        museum.archive_failure(
            root=failures,
            reason=f"stage_1_agent_verify_{gate.verdict.value.lower()}",
            detail={
                "wav_path": str(wav_path),
                "score_path": str(score_path),
                "ckpt_path": str(voice),
                "metrics": [m.name for m in gate.metrics],
                # R8 trace: persist whether this failure was on an NC path
                # so post-mortems show the license context too.
                "license_notice_path": str(notice_path) if notice_path else None,
            },
        )
    return SmokeResult(
        wav_path=wav_path,
        verdict=gate.verdict,
        metrics=gate.metrics,
        license_notice_path=notice_path,
    )
