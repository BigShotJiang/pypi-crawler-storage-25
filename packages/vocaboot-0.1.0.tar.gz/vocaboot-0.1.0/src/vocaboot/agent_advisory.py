"""Agent C — definitional advisory (Layer 6, case A).

Agent C is structurally excluded from the final verdict. It runs after agent A
+ agent B have already decided (APPROVE / REVIEW / REJECT). Its sole job is to
annotate the museum entry with qualitative observations that future iterations
can learn from — never to flip a verdict.

If you find yourself reading agent C output to override agent A/B, stop.
That's a known failure mode (Round 26 number-fabrication regression).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Advisory:
    """One advisory note. Never counted toward verdict."""

    note: str
    confidence: float  # 0.0 .. 1.0, hint only


def gather_advisory(_audio_path: Path | str) -> tuple[Advisory, ...]:
    """Run agent C on a generated wav. Returns a tuple of advisory notes.

    Stage 1 returns an empty tuple — agent C is wired in step 5 when there
    is real audio to advise on. The aggregator must accept ``()`` as a
    valid agent C result.
    """
    return ()
