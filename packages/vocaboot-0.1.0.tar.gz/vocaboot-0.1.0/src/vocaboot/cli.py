"""vocaboot CLI entry point (click.group).

Subcommands:

  * ``vocaboot synth``  — BYO ckpt + score (the original Stage 1 surface).
  * ``vocaboot demo``   — registry-pinned NC vocoder + bundled
    ``examples/short.ds``. The OSS-1 invariant (`pip install vocaboot[…]`
    + ``vocaboot demo --accept-nc`` → smoke wav) lands here.

The pre-5c flat form (``vocaboot --voice X --score Y …``) was removed
during 0.0.x development and never reached a public release; the first
published release (0.1.0) ships only the subcommand surface. All flat
invocations must migrate to ``vocaboot synth``.

Exit code map (CI-friendly, REVIEW ≠ REJECT — same for every subcommand):

  0   APPROVE          gate cleared (or NUMERIC mode and metrics passed)
  2   privacy refuse   --voice or --score matched a protected reference
  3   engine not wired step-5 stub raised EngineNotWiredError
  5   REVIEW           gate undetermined (CI straddled threshold etc.)
  6   REJECT           gate rejected; museum entry written
  7   license refused  --voice license outside allow-list / NC without opt-in
  1   unexpected       any other unhandled exception (click default)
"""

from __future__ import annotations

import sys
from pathlib import Path

import click

from vocaboot import __version__
from vocaboot.agent_verify import Verdict
from vocaboot.license_check import LicenseRefusedError
from vocaboot.privacy import ConsentRequiredError, ProtectedReferenceError, refuse_if_protected
from vocaboot.svs_engine import EngineNotWiredError


def _default_demo_score() -> Path:
    """Resolve the bundled ``examples/short.ds`` for ``vocaboot demo``.

    Wheel installs find it at ``vocaboot/_data/short.ds`` (force-include
    in pyproject.toml); editable / source-tree installs fall back to
    ``examples/short.ds``. The resolver itself lives in
    :mod:`vocaboot._resources`.
    """
    from vocaboot import _resources

    dev_path = Path(__file__).resolve().parent.parent.parent / "examples" / "short.ds"
    return _resources.bundled_resource_path(
        "_data/short.ds", dev_tree_fallback=dev_path
    )


def _exit_for_verdict(verdict: Verdict) -> int:
    if verdict is Verdict.APPROVE:
        return 0
    if verdict is Verdict.REVIEW:
        return 5
    return 6


def _run_pipeline(
    *,
    voice_value: Path | str,
    score: Path,
    out: Path,
    sample_rate: int,
    ckpt_license: str,
    accept_nc: bool,
    no_agent_verify: bool,
    failures_root: Path | None,
    engine: str,
    reference_profile_path: Path | None = None,
) -> None:
    """Shared pipeline entry — both ``synth`` and ``demo`` end up here.

    Translates pipeline exceptions into the documented exit codes (3, 7)
    and the gate verdict into 0 / 5 / 6. When ``reference_profile_path``
    is supplied, the JSON sidecar is loaded into a :class:`VoiceProfile`
    and forwarded to ``pipeline.run`` so the gate runs at Tier 2.
    """
    click.echo(f"vocaboot {__version__} — stage 1 scaffold")
    click.echo(f"  engine      = {engine}")
    click.echo(f"  voice       = {voice_value}")
    click.echo(f"  score       = {score}")
    click.echo(f"  out         = {out}")
    click.echo(f"  sample_rate = {sample_rate}")
    if reference_profile_path is not None:
        click.echo(f"  reference   = {reference_profile_path} (Tier 2 verify)")

    try:
        refuse_if_protected(voice_value, kind="checkpoint")
        refuse_if_protected(score, kind="score")
    except ProtectedReferenceError as e:
        click.echo(str(e), err=True)
        sys.exit(2)

    reference_voice = None
    if reference_profile_path is not None:
        from vocaboot import profile_match

        reference_voice = profile_match.load(reference_profile_path)

    from vocaboot import pipeline

    try:
        result = pipeline.run(
            voice=voice_value,
            score_path=score,
            out=out,
            sample_rate=sample_rate,
            ckpt_license=ckpt_license,
            accept_nc=accept_nc,
            skip_agent_verify=no_agent_verify,
            failures_root=failures_root,
            reference_voice=reference_voice,
        )
    except LicenseRefusedError as e:
        click.echo(str(e), err=True)
        sys.exit(7)
    except EngineNotWiredError as e:
        click.echo(str(e), err=True)
        sys.exit(3)

    click.echo(
        f"synth ok → {result.wav_path}  verdict={result.verdict.value}"
    )
    sys.exit(_exit_for_verdict(result.verdict))


def _shared_options(f):
    """Apply the option set common to ``synth`` and ``demo``.

    Kept as a decorator factory rather than ``@click.pass_context`` plumbing:
    each subcommand owns its own signature, the help text stays per-command,
    and the option ordering is deterministic for ``--help`` output.
    """
    f = click.option(
        "--engine",
        type=click.Choice(["diffsinger"], case_sensitive=False),
        default="diffsinger",
        show_default=True,
        help="SVS engine. Stage 1 ships diffsinger only; more in stage 3+.",
    )(f)
    f = click.option(
        "--out",
        type=click.Path(dir_okay=False, path_type=Path),
        default=Path("out.wav"),
        show_default=True,
        help="Output wav path.",
    )(f)
    f = click.option(
        "--sample-rate",
        type=int,
        default=44100,
        show_default=True,
        help="Output sample rate (Hz).",
    )(f)
    f = click.option(
        "--accept-nc",
        is_flag=True,
        help=(
            "Acknowledge non-commercial-only weights (CC-BY-NC-SA-4.0 tier). "
            "Personal use only — the vocoder is bound by the NC clause even "
            "though CC FAQ says generated output is not."
        ),
    )(f)
    f = click.option(
        "--no-agent-verify",
        is_flag=True,
        help="Skip the post-synthesis agent-verify gate (testing only).",
    )(f)
    f = click.option(
        "--failures-root",
        type=click.Path(file_okay=False, path_type=Path),
        default=None,
        help="Override the failure-museum root. Default: ./_failures",
    )(f)
    return f


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, prog_name="vocaboot")
def main() -> None:
    """vocaboot — terminal-friendly singing voice synthesis.

    Run ``vocaboot demo --accept-nc`` for the 5-second smoke wav, or
    ``vocaboot synth --voice <ckpt> --score <ds>`` to drive your own
    checkpoint.
    """


@main.command(name="synth")
@_shared_options
@click.option(
    "--voice",
    type=str,
    required=True,
    help=(
        "Path to the SVS checkpoint (.onnx) or the literal 'synthetic' "
        "for the oscillator fallback. Bring your own; vocaboot bundles "
        "no acoustic weights."
    ),
)
@click.option(
    "--score",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    required=True,
    help="Score file. Stage 1 accepts a DiffSinger .ds JSON.",
)
@click.option(
    "--ckpt-license",
    type=str,
    default="CC0-1.0",
    show_default=True,
    help="SPDX identifier of the supplied --voice. Refused if outside the allow-list.",
)
@click.option(
    "--reference-profile",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help=(
        "Path to a VoiceProfile JSON sidecar (produced by `vocaboot profile`). "
        "Supplying it engages Tier 2 verify (MCD + WavLM cosine against the "
        "reference) in addition to the Tier 1 f0/HNR metrics."
    ),
)
def synth(
    engine: str,
    voice: str,
    score: Path,
    out: Path,
    sample_rate: int,
    ckpt_license: str,
    accept_nc: bool,
    no_agent_verify: bool,
    failures_root: Path | None,
    reference_profile: Path | None,
) -> None:
    """Synthesize a wav from a user-supplied ckpt and score."""
    voice_value: Path | str
    if voice.strip().lower() == "synthetic":
        voice_value = "synthetic"
    else:
        voice_path = Path(voice)
        if not voice_path.is_file():
            click.echo(
                f"--voice {voice}: not a file, and not the literal 'synthetic'.",
                err=True,
            )
            sys.exit(2)
        voice_value = voice_path

    _run_pipeline(
        voice_value=voice_value,
        score=score,
        out=out,
        sample_rate=sample_rate,
        ckpt_license=ckpt_license,
        accept_nc=accept_nc,
        no_agent_verify=no_agent_verify,
        failures_root=failures_root,
        engine=engine,
        reference_profile_path=reference_profile,
    )


@main.command(name="demo")
@_shared_options
@click.option(
    "--score",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help=(
        "Override the bundled examples/short.ds (testing convenience). "
        "Default: the package-bundled 5-second smoke score."
    ),
)
def demo(
    engine: str,
    out: Path,
    score: Path | None,
    sample_rate: int,
    accept_nc: bool,
    no_agent_verify: bool,
    failures_root: Path | None,
) -> None:
    """Run the OSS-1 quick-start smoke (synthetic + bundled score).

    The synthetic-acoustic path uses the registry-pinned NSF-HiFiGAN
    vocoder (CC-BY-NC-SA-4.0), so ``--accept-nc`` is **mandatory** —
    we do not silently auto-accept the NC clause for you. The vocoder
    is downloaded to ``~/.cache/vocaboot/ckpts/...`` on first run if
    not already present (SHA-256 pinned).

    Example::

        vocaboot demo --accept-nc
    """
    if not accept_nc:
        click.echo(
            "vocaboot demo: --accept-nc is mandatory. The bundled smoke path "
            "uses the registry-pinned NSF-HiFiGAN vocoder, which is "
            "CC-BY-NC-SA-4.0. Pass --accept-nc to confirm personal, "
            "non-commercial use (CC FAQ says generated output is not bound "
            "by the model's NC clause, but the act of running NC weights is).",
            err=True,
        )
        sys.exit(7)

    score_path = score if score is not None else _default_demo_score()

    _run_pipeline(
        voice_value="synthetic",
        score=score_path,
        out=out,
        sample_rate=sample_rate,
        ckpt_license="CC-BY-NC-SA-4.0",
        accept_nc=accept_nc,
        no_agent_verify=no_agent_verify,
        failures_root=failures_root,
        engine=engine,
    )


@main.command(name="ingest")
@click.argument(
    "audio",
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
)
@click.option(
    "--intent",
    type=click.Choice(["reference", "target"], case_sensitive=False),
    required=True,
    help="Why this audio is being ingested. 'reference' = profile-match source (Stage 2); 'target' = self-train target (Stage 3).",
)
@click.option(
    "--consent-no-store",
    is_flag=True,
    help=(
        "Acknowledge that vocaboot may load this audio into memory and write "
        "a tmp copy that is deleted on contextmanager exit. R15 (no server "
        "persistence) acknowledgement. Also accepts VOCABOOT_CONSENT_NO_STORE=1."
    ),
)
@click.option(
    "--consent-no-redistribute",
    is_flag=True,
    help=(
        "Acknowledge that any future synthesis driven from this audio under "
        "the CC-BY-NC-SA-4.0 vocoder is bound by the NC clause. This is the "
        "ingest-time pre-condition; --accept-nc is the synth-time act. "
        "Also accepts VOCABOOT_CONSENT_NO_REDISTRIBUTE=1."
    ),
)
@click.option(
    "--failures-root",
    type=click.Path(file_okay=False, path_type=Path),
    default=None,
    help="Override the failure-museum root for consent-refuse archives.",
)
def ingest(
    audio: Path,
    intent: str,
    consent_no_store: bool,
    consent_no_redistribute: bool,
    failures_root: Path | None,
) -> None:
    """Consent-check a user audio path and surface the tmp-copy lifecycle.

    On success, prints the tmp path to stdout (the copy is removed when the
    CLI exits). On consent refusal, writes a museum entry under the redacted
    user-audio key and exits 7. The Stage 2.5 MCP server does not expose
    this subcommand — consent flags are required to come from a human via
    CLI or env var (Stage 2.5 MCP boundary invariant).
    """
    from vocaboot import audio_ingest, museum

    intent_value = intent.lower()
    resolved_no_store = audio_ingest.resolve_consent_no_store(consent_no_store)
    resolved_no_redistribute = audio_ingest.resolve_consent_no_redistribute(
        consent_no_redistribute
    )
    failures_root_value = failures_root if failures_root is not None else Path("_failures")

    try:
        refuse_if_protected(audio, kind="user_audio")
    except ProtectedReferenceError as e:
        click.echo(str(e), err=True)
        sys.exit(2)

    try:
        with audio_ingest.ingest(
            audio,
            intent=intent_value,  # type: ignore[arg-type]
            consent_no_store=resolved_no_store,
            consent_no_redistribute=resolved_no_redistribute,
        ) as ia:
            click.echo(f"ingest ok → {ia.path}  sha256={ia.source_sha256[:12]}…")
        sys.exit(0)
    except ConsentRequiredError as e:
        click.echo(str(e), err=True)
        museum.archive_failure(
            root=failures_root_value,
            reason=f"stage_2_consent_refused_{intent_value}",
            detail={audio_ingest.museum_key_for(intent_value): str(audio)},  # type: ignore[arg-type]
        )
        sys.exit(7)


if __name__ == "__main__":  # pragma: no cover
    main()
