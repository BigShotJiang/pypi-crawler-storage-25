# vocaboot — `examples/voice/`

This directory holds **license-clean** reference voice samples used by the Stage 2 Tier 2 verify gate (`docs/quality_gate.md`, criterion 1 in `docs/stage_2.md`).

## Sample policy

Every sample in this directory must satisfy:

1. **License** in {`CC0-1.0`, `MIT`, `CC-BY-3.0`, `CC-BY-4.0`, `CC-BY-SA-4.0`} — the same allow-list as `docs/ckpt_registry.md` Default tier extended for raw vocal audio samples. CC-BY-3.0 is included because it is the predecessor of CC-BY-4.0, OSI-aligned, Debian-main-distributed, and semantically equivalent (Attribution + derivative OK); the version bump 3.0 → 4.0 adds anti-DRM and 30-day cure clauses but does not change the substantive permissions vocaboot relies on. CC-BY-SA is accepted here because vocaboot's source code is Apache-2.0 (not SA), and the sample is *referenced*, not redistributed under a derivative license; the ShareAlike clause applies only if we re-license the sample.
2. **Duration** ≤ 10 seconds — the Tier 2 canary needs only enough voiced frames to extract a stable WavLM embedding (~3 seconds is enough; 10 s gives headroom).
3. **Sample rate** 16 kHz mono PCM minimum (we resample to 16 kHz internally for WavLM). The sample may be at any rate vocaboot can resample from.
4. **No identifying metadata** — strip ID3 / Vorbis tags, file name must not encode the speaker ID directly (Stage 1.5-B `_USER_AUDIO_REDACT_KEYS` policy spirit).
5. **Provenance** documented in this README and pinned by sha256 in `docs/ckpt_registry.md`.

## Surveyed sources (Stage 2 step 0a, updated R14 round-7 2026-05-12)

| Source | License | Direct download? | Notes |
|---|---|---|---|
| **Open JTalk + hts-voice-nitech-jp-atr503-m001** (chosen) | engine BSD-3-clause, voice **CC-BY-3.0** | `apt install` + local CLI generation | NIT (Nagoya Institute of Technology) + Tokyo Tech. Japanese HMM-parametric synthesis. License extracted verbatim from `/usr/share/doc/hts-voice-nitech-jp-atr503-m001/copyright`. Debian places the voice deb in multiverse because the upstream HTK toolkit (used in *training*, not redistributed in the voice data) has a non-free EULA — NIT's release of the trained voice data under CC-BY-3.0 is unaffected. **Chosen Stage 2 PR1b reference** (R14 round-7). |
| Mozilla Common Voice (ja) | **CC0-1.0** | bulk download (email signup) | The full corpus is CC0 but the distribution requires acknowledging the per-clip terms via the download page. Round-5 rejected: email signup not automatable from CI. |
| OpenSLR JVS | (corpus page says "Research / Non-commercial / Personal use" — **not** a formal CC-BY-SA-4.0 release; only tags are CC-BY-SA-4.0) | Google Drive 3.5 GB zip (browser confirm-token gate) | Round-7 rejected: license terms restrict OSS-repo redistribution + 3.5 GB Google Drive zip is not curl-automatable for CI. (Previously believed to be CC-BY-SA-4.0 on the audio — this was a documentation phantom.) |
| LibriSpeech (en) | CC-BY-4.0 | direct tarball | English-only; usable as a non-Japanese fallback only. |
| Wikimedia Commons (ja audio) | mixed (CC0 / CC-BY-SA / public domain) | direct file URL | Per-file license must be verified before use. Round-5 candidate, retired in round-6 due to no-takedown-fallback + no-pre-screen risk (criterion #1 phantom against `wavlm_cosine` ≥ 0.60). Remains a defense-in-depth backup. |
| piper-ja TTS | n/a — **not in the piper-voices catalogue** | n/a | Round-6 candidate, retired in round-7 after stock check confirmed `rhasspy/piper-voices` has 28 languages but no `ja` directory. |
| espeak-ng synthetic | GPL-3.0+ (engine), output user's | n/a (locally generated) | Deterministic, cross-platform reproducible, but rule-based synthesis (lower fidelity than HMM); kept as last-resort fallback below Open JTalk. |

## Stage 2 PR1b — Open JTalk reference acquisition (R14 round-7 path / round-8 architecture, 2026-05-12)

The Stage 2 step-3-precondition PR1b lands `examples/voice/tier2_reference_ja.wav` and the registry pin.

**Source-of-truth convention (R14 round-8 architect verdict)**: the **stored wav is the source of truth**. CI verifies it by sha256 + size + sample_rate + duration; CI does **not** regenerate from `apt`-installed packages. This immunizes the pipeline against Ubuntu mirror state (deb security rebuilds change `.htsvoice` bytes at fixed version pins) and keeps cross-platform CI (macOS / Windows / WSL / Linux) working without `apt`. The reproduction recipe below is the **human-maintainer regeneration path**, used only when the upstream license / rights-holder / file integrity requires a re-roll.

**Quick path (recommended)**: run the maintainer script — it verifies all three apt dependencies, generates the wav at 16 kHz, and prints the 4-axis pin (sha256 + size_bytes + sample_rate + duration_seconds) ready for paste into `docs/ckpt_registry.md`:

```bash
bash scripts/regenerate_tier2_reference.sh
```

If a dependency is missing the script prints the exact `apt install` command to run, then exits. The script is **maintainer-only**; CI never invokes it (round-8 SoT convention — see top of this section).

Manual recipe (for transparency / non-bash environments):

1. Install:
   ```bash
   sudo apt install open-jtalk hts-voice-nitech-jp-atr503-m001 open-jtalk-mecab-naist-jdic
   ```
2. Locate the voice file (varies by distro/version):
   ```bash
   VOICE=$(dpkg -L hts-voice-nitech-jp-atr503-m001 | grep '\.htsvoice$')
   DIC=/var/lib/mecab/dic/open-jtalk/naist-jdic
   ```
3. Generate the sample wav (**16 kHz mono — locked at WavLM input rate so no internal resample sits between the stored bytes and the metric**):
   ```bash
   echo "音声合成のサンプルです" | open_jtalk -x "$DIC" -m "$VOICE" -s 16000 -ow examples/voice/tier2_reference_ja.wav
   ```
4. Compute the 4-axis pin and commit it to `docs/ckpt_registry.md` `tier2-reference-voice` block:
   ```bash
   python -c "import hashlib, wave; \
     p='examples/voice/tier2_reference_ja.wav'; \
     b=open(p,'rb').read(); \
     w=wave.open(p,'rb'); \
     print(f'sha256:           {hashlib.sha256(b).hexdigest()}'); \
     print(f'size_bytes:       {len(b)}'); \
     print(f'sample_rate:      {w.getframerate()}'); \
     print(f'duration_seconds: {round(w.getnframes()/w.getframerate(), 3)}')"
   ```
5. Run the drift test:
   ```bash
   pytest tests/test_ckpt_registry_pin_consistency.py::test_tier2_reference_voice_pins_match_registry -xvs
   ```
   This asserts the file's runtime sha256 / size / sample_rate / duration_seconds **all** match the registry pins — defense-in-depth across the WavLM and vocoder pins, with root-cause separation between regeneration drift (sha256 mismatches but sample_rate matches) and file corruption (size or duration anomalous).

**File name policy**: `tier2_reference_ja.wav` encodes the **purpose** (`tier2_reference`) and **language** (`ja`) only. The engine name (`openjtalk`) and speaker ID (`nitech_jp_atr503_m001`) are both deliberately excluded from the path. Engine identity lives in `docs/ckpt_registry.md` `tier2-reference-voice.source_engine`; speaker ID redaction follows the Stage 1.5-B `_USER_AUDIO_REDACT_KEYS` policy. A future engine pivot (espeak-ng / different voice / different language) becomes a registry-block swap rather than a repo-wide file rename — the metric layer and tests reference the file by `artifact_path` from the registry, not by hard-coded name.

## Stage 2 step 3b — Tier 2 multi-canary APPROVE arm (R14 round-10, 2026-05-12)

The Tier 2 verify gate (`docs/quality_gate.md`, `docs/stage_2.md` criterion #1) tests two arms against the reference profile built from `tier2_reference_ja.wav`:

- **APPROVE arm**: real voice samples that should pass the gate (`mcd` CI low ≤ threshold AND `wavlm_cosine` CI high ≥ threshold)
- **REJECT arm**: synthetic 4-partial oscillator output that should fail at least one metric

The R14 round-9 R17 audit closure used **N=1** for the APPROVE arm (`tier2_canary_ja_alt.wav` only). The R14 round-10 5-体並列 audit (analyst + critic + verifier) judged this an R5 violation — the bootstrap CI on a single wav captures only frame-level resampling SE, not the **inter-sample SE** that determines whether the APPROVE threshold itself has estimable variance. Round-10 widens the APPROVE arm to **N=5** sentences from the same HMM speaker, varying prosody and length:

| wav (1-indexed in the calibration set) | sentence | duration |
|---|---|---|
| `tier2_canary_ja_alt.wav` (voice_01) | 今日はいい天気ですね | 6.42 s |
| `tier2_canary_voice_02.wav` | 明日は雨が降るかもしれません | 8.415 s |
| `tier2_canary_voice_03.wav` | 私は東京に住んでいます | 8.625 s |
| `tier2_canary_voice_04.wav` | コンピューターは便利な道具です | 8.475 s |
| `tier2_canary_voice_05.wav` | 新しい本を買いました | 7.380 s |

All five share the same engine (`open_jtalk` BSD-3-clause), same voice data (`hts-voice-nitech-jp-atr503-m001` CC-BY-3.0), same sample rate (16 kHz mono), and same speaker — only the input text varies. This keeps the speaker-identity question controlled while exposing sentence-within-speaker variance to the bootstrap CI on the APPROVE threshold.

**Speaker-bank evaluation** (true inter-speaker SE, e.g. JVS / Mozilla CV ja) is deferred to Stage 3 (`speaker_cosine` ECAPA-TDNN, target-quality tier). The N=5 round-10 set is the **minimum defensible Stage 2 closure anchor**, not the eventual target. The round-10 memory at `vocaboot-stage2-step3b-r14-round10-2026-05-12.md` records the audit rationale and Stage 3 hand-off.

**Reproduction**: `bash scripts/regenerate_tier2_canary_voice_arm.sh` regenerates the four `tier2_canary_voice_0{2,3,4,5}.wav` files and prints their 4-axis pins. `bash scripts/regenerate_tier2_canary_alt.sh` (round-9 maintainer-only path) regenerates voice_01 separately so the round-9 R17 audit history remains script-traceable.

## License attribution (CC-BY-3.0 obligation)

The output `tier2_reference_ja.wav` is a derivative of the `hts-voice-nitech-jp-atr503-m001` voice data, which is released under CC-BY-3.0 by Nagoya Institute of Technology + Tokyo Institute of Technology. Per the CC-BY-3.0 Attribution clause:

```
Voice data: hts-voice-nitech-jp-atr503-m001 (CC-BY-3.0)
  Copyright 2003-2012 Nagoya Institute of Technology, Department of Computer Science
  Copyright 2003-2008 Tokyo Institute of Technology, Interdisciplinary Graduate School of Science and Engineering
  Synthesis engine: Open JTalk (BSD-3-clause), https://open-jtalk.sourceforge.net/
  Generated by: vocaboot Stage 2 PR1b reproduction recipe (see above)
```

This block is repeated in the per-run `LICENSE_NOTICE.txt` that `vocaboot.license_check` emits when the verify-similarity extra loads the canary file.

## Takedown / removal

If the upstream license terms change, or the rights-holder requests removal, replace the `tier2_reference_ja.wav` file by re-running the reproduction recipe against a different surveyed source (Mozilla CV ja or Wikimedia Commons ja PD as fallbacks). The `tier2-reference-voice` block in `docs/ckpt_registry.md` is the single source of truth for the active sample — update both the file and the registry pin together (`tests/test_ckpt_registry_pin_consistency.py` enforces consistency). The 4-axis pin makes accidental file replacement detectable at PR review time (any axis mismatch reads as an explicit "you changed the canary").

## Why this exists

R14-round-2 critic Q1(a) noted that "license-clean voice sample acquisition" was the unresolved Stage 0 result (B) -class problem at the Tier 2 level. Without this README, the Stage 2 PR could pick any sample (e.g. a personal recording — R15 violation, or an NC-licensed corpus — license breach). The policy + sha256 pin make the supply chain auditable end-to-end.
