# Contributing to vocaboot

vocaboot is at Alpha (`0.1.0`). The scope is intentionally narrow: a
terminal-first, Claude-Code-MCP-ready singing-voice-synthesis quality gate
around third-party engines. Contributions that align with that scope are
welcome.

## Quick start

```bash
git clone https://github.com/hinanohart/vocaboot.git
cd vocaboot
python -m venv .venv && source .venv/bin/activate
pip install -e '.[verify,dev]'
pytest -q
```

For Tier 2 verify metrics (`mcd`, `wavlm_cosine`), add `verify-similarity`:

```bash
pip install -e '.[verify,verify-similarity,dev]'
```

The first run downloads ~360 MB of WavLM-base weights to
`~/.cache/vocaboot/models/wavlm-base/` (CC-BY-SA-3.0; see
`docs/ckpt_registry.md`).

See `docs/install.md` for platform-specific notes.

## Reporting bugs / regressions

File a GitHub issue. Include:

- the exact command you ran
- the full stderr / stack trace
- vocaboot version (`pip show vocaboot`)
- Python version and OS

**Do not** attach personal voice recordings or copyrighted material. The
project's R15 (privacy) policy refuses any input path matching
`DEFAULT_PROTECTED_SUBSTRINGS` (`src/vocaboot/privacy.py`); contributors
maintain a private extension list under
`~/.config/vocaboot/protected_patterns.txt` that is **never committed**.

## Failure museum (`_failures/`)

vocaboot keeps a failure museum (`R8` in the maintainer convention) of
reproducer cases at `_failures/<incident-id>/`. Each entry contains a
sanitised `metadata.json` (paths reduced to `{basename, sha256}`) and a
human-readable `README.md`. Large binaries (`*.wav`, `*.mp4`) are
git-ignored under `_failures/`; metadata is committed so the audit trail
survives a clean clone.

When you reproduce a bug, the recommended flow is:

1. Reproduce locally; let `museum.archive_failure` capture the scrubbed
   `metadata.json` under `_failures/<incident-id>/`.
2. File a GitHub issue referencing the incident ID; attach the
   `metadata.json` snippet only — never raw audio.
3. If the maintainer asks for the audio sample, share it out-of-band
   (encrypted email / private gist with `expires=24h`) — never commit it.

## Pull requests

- Branch from `main`. Keep PRs small and single-concern.
- Run `ruff check src tests` and `pytest -q` locally before pushing.
- Tier 2 changes (anything touching `profile_match.py`, `audio_ingest.py`,
  the WavLM pin in `docs/ckpt_registry.md`, or `metrics.{mcd,wavlm_cosine}`)
  must also pass `pytest -q -k 'profile_match or stage2 or similarity'`
  with the `verify-similarity` extra installed.
- Update `CHANGELOG.md` under `## Unreleased`.

## License

By contributing, you agree that your contributions are licensed under
Apache-2.0 (`LICENSE`). vocaboot does **not** require a separate CLA.

## Code of Conduct

Participation is governed by `CODE_OF_CONDUCT.md` (Contributor Covenant
v2.1).

## Security

Security-sensitive findings should not be filed as public issues. See
`SECURITY.md` for the private disclosure path.
