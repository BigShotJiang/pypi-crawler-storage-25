# Changelog

All notable changes to vocaboot are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] — 2026-05-13

First Alpha cut. Stage 1 smoke is end-to-end runnable; Stage 2 verify
metrics wire-in (MCD + WavLM cosine) is feature-complete with one
remaining 1-sided gate on the WavLM-cosine arm (tracked under
"Deferred"). Supersedes the in-flight `0.0.1` snapshot from 2026-05-12.
Not yet on PyPI — install from source per `docs/install.md`.

### Added
- `metrics.MCD_THRESHOLD_BAND_DB = (450.0, 550.0)` — public R5-strict
  2-sided uncertainty band around the calibrated 500 dB anchor (±10%
  envelope). `agent_verify.run` passes this as `threshold_ci=` to
  `metrics.mcd` so the production path uses the strict 2-sided gate,
  not the legacy 1-sided fallback. The N=5 canary distribution sits
  strictly outside the band with margin (voice CI [222, 367] < 450;
  synth CI [1071, 1259] > 550), so the wire-in is a structural
  refinement of the gate, not a behaviour change on existing canaries.
- `tests/test_stage2_pipeline.py::test_mcd_threshold_band_wired_in_production` —
  AST-walk contract test on `agent_verify.run` so a future refactor
  cannot silently revert the production path to the 1-sided gate.
- Failure museum (`_failures/`) — sanitised reproducer cases, committed
  metadata, gitignored audio binaries.
- Tier 2 verify metrics: `mcd` (block-bootstrap CI) + `wavlm_cosine`
  (optional `[verify-similarity]` extra).
- Reference voice canary (`examples/voice/tier2_reference_ja.wav`,
  OpenJTalk + nitech, CC-BY-3.0).
- Privacy guard (`src/vocaboot/privacy.py`) — NFKC-normalised substring
  match + symlink resolve; in-repo defaults are generic placeholders,
  project-specific patterns live in `~/.config/vocaboot/protected_patterns.txt`.
- CI workflow skeleton (`.github/workflows/ci.yml`) — pytest matrix on
  Python 3.10/3.11/3.12 (ubuntu) + 3.12 (macos), plus a separate
  `verify-similarity` job with WavLM weight caching.
- Governance: `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SECURITY.md`,
  `NOTICE`, this `CHANGELOG.md`, `docs/install.md`.

### Fixed
- WavLM checkpoint license declared in `docs/ckpt_registry.md` corrected
  from `MIT` to `CC-BY-SA-3.0` (the HF model card has no `license:` field
  and links to `microsoft/UniSpeech/LICENSE` as the single authoritative
  source). Apache-2.0 compatibility is preserved because vocaboot consumes
  the weights from the user's cache and does not redistribute them — §4(b)
  ShareAlike does not propagate.
- R15 privacy hygiene: removed maintainer-specific identifiers from the
  in-repo source tree. Test fixtures and gitignore patterns migrated to
  the generic `protected_voice` placeholder; project-specific patterns now
  live in the user's local config file as designed.
- R15 audit-log paths in `docs/stage_2.md` and `examples/voice/README.md`
  no longer reference the maintainer's absolute home directory. Audit
  logs are filename-only references (off-tree maintainer records).

### Deferred (target: 0.2.0)
- **Dormant phantom #3 — librosa-MFCC scale dependency**: pysptk-based
  MCD migration (`pysptk.mcep` + WORLD F0, mcep order=24, alpha=0.41
  from the round-10 B2 probe). Blocked on pysptk PyPI wheel
  availability (currently source-only build; CI on Windows/macOS
  cannot reproduce). 0.1.0 ships librosa-MFCC + calibrated 500 dB
  threshold band; the migration replaces both with the literature
  6-8 dB Kominek anchor.
- **Dormant phantom #5 — alpha=0.41 vs HTS-standard 0.42 mismatch**:
  the round-10 B2 probe selected `alpha=0.41` empirically; HTS /
  Kominek 2008 native MCEP uses `alpha=0.42` at 16 kHz. The 0.01 gap
  is small but unverified; resolve when pysptk migration lands (the
  alpha choice has to be re-bound to the actual training data domain).
- **wavlm_cosine threshold_ci (mcd-only round-11 closure)**: round-11
  wired `threshold_ci` into the MCD arm of the Tier 2 gate
  (`metrics.MCD_THRESHOLD_BAND_DB`). The WavLM-cosine arm still
  uses the 1-sided gate against the point threshold 0.60 because the
  N=5 canary distribution has not yet been measured against the
  separability arms for cosine. Round-12 target: measure the
  voice / synth cosine arms and add `WAVLM_COSINE_THRESHOLD_BAND`
  symmetric to the MCD constant.
- **MCD band re-anchor (R5 strict)**: the `±10%` envelope around
  500 dB is a heuristic anchored on the N=5 calibration's midpoint,
  not a bootstrap CI of the calibration itself. Resolve when N
  expands (Stage 3 ECAPA-TDNN canary, also 0.2.0).
- Engine-agnostic pivot (Stage-3 SVC / Stage-4 NL).
- Inter-speaker canary expansion (Stage 3 ECAPA-TDNN).

## 0.0.1 — 2026-05-12 (superseded)

In-flight Pre-Alpha snapshot, never released. Superseded by 0.1.0 on
2026-05-13 (kept here as a footnote so the version sequence is legible;
there is no `v0.0.1` git tag).
