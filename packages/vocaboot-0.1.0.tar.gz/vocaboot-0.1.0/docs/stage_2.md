# vocaboot — Stage 2 specification

> User intent (R16, immutable): 「ボカロを簡単に作れる世界」「クロードコード経由で簡単に」「ターミナルでボーカロイドを操作できる」「汎用性高く」

Stage 1 (closed 2026-05-12) made the pipeline *ring*: a 5-second wav from the registry-pinned vocoder on the synthetic-acoustic path, with a numeric verify gate and per-run CC-BY-NC-SA-4.0 attribution. Stage 2 makes the wrapper *useful*: a user can profile a target voice, hand vocaboot a song-like input, and get an output that demonstrably moves toward that voice.

This spec was set by the Stage 1.5 R14 discussion (analyst REVISE / architect REVISE×2 / critic REVISE) and revised by the Stage 2 R14 second round (2026-05-12) that surfaced two phantom-claim defects (F1 / F2) and five spec-tightening items (R1-R5). Stage 1.5 closed five preconditions (`stage_1.py` → `pipeline.py` rename, user-audio privacy/museum guard, operational quality gate, ckpt acquisition path decision, this spec).

## Scope

Stage 2 delivers four components in order:

0. **Stage 2 step 0 (preconditions)** — license-clean voice sample acquisition (0a) and `[verify-similarity]` extra declaration (0b). These were absent from the original Stage 1.5 closure and are listed first so a Stage 2 PR cannot bypass them.
1. **`profile_match` module** — turns a target-voice audio sample into a parameter set that downstream synthesis can attempt to satisfy.
2. **`audio_ingest` module + `vocaboot ingest` subcommand** — accepts user-supplied audio (any-song input) behind the consent guard from Stage 1.5-B.
3. **Tier 2 verify metrics wire-in (split into 4 PRs per R14 round-4 + round-5, 2026-05-12)**:
   - **Precondition PR1a (WavLM 系)** — `huggingface_hub.snapshot_download(repo_id="microsoft/wavlm-base", local_dir=~/.cache/vocaboot/models/wavlm-base/)` で HF 標準 layout 一式取得 (`pytorch_model.bin` + `config.json` + `preprocessor_config.json` 等)、`pytorch_model.bin` のみ sha256 pin、`profile_match.py:_PINNED_WAVLM_SHA256` と `docs/ckpt_registry.md` 両所に commit、`tests/test_stage2_profile_match.py::test_wavlm_loader_refuses_placeholder_pin` を active-pin assertion に反転 + 新規 hash-mismatch test、新規 `tests/test_ckpt_registry_pin_consistency.py` (R14 round-5 architect A4 — `profile_match._PINNED_WAVLM_SHA256` と `docs/ckpt_registry.md` の `sha256:` フィールドの drift を regex で監視)。R14 round-5 architect A1 (HF `from_pretrained` の directory-load 前提) は snapshot_download 採用で吸収済 — `profile_match.py:218` は変更不要。
   - **Precondition PR1b (canary 系、R14 round-7 path / round-8 architecture、2026-05-12)** — round-6 primary "piper-ja CC0" は撤回 (piper に ja voice 不在 + CC0 主張無根拠)、round-7 で user 当初 Path C JVS 選択 → JVS の実 license が「Research / Non-commercial / Personal use」bespoke (NOT CC-BY-SA-4.0) かつ Google Drive 3.5GB 配布で CI 不適と判明 → 撤回 → user 再選択 **Path B (OpenJTalk + hts-voice-nitech-jp-atr503-m001)** で確定 (round-7)。**Round-8 architecture verdict** (analyst REVISE→B案 vs architect ACCEPT→A案、構想層 split を critic 不要で resolve): cross-platform CI (macOS / Windows / WSL / Linux) 適合のため **stored wav = source of truth** を採択 (on-demand 合成案は apt mirror drift で bit-reproducibility 破綻)。一次資料 verify (deb copyright extract): engine BSD-3-clause / voice CC-BY-3.0 (NIT 明示) / multiverse 分類は HTK 訓練 toolkit 上流懸念のみで voice data 自体は OSS-clean。`examples/voice/tier2_reference_ja.wav` (engine 名・speaker ID 共に file path から除外、`tier2_reference` purpose + `ja` lang のみ encode、engine 切替時 registry block swap で完結) + provenance README + ckpt_registry の `tier2-reference-voice` block (4-axis pin: sha256 + size_bytes + sample_rate + duration_seconds) + drift test (`test_ckpt_registry_pin_consistency.py::test_tier2_reference_voice_pins_match_registry`、4-axis 各々 assert、再生成 drift vs file corruption 切り分け可)。生成 (人間 maintainer のみ、CI 経路ではない): `sudo apt install open-jtalk hts-voice-nitech-jp-atr503-m001 open-jtalk-mecab-naist-jdic` → `VOICE=$(dpkg -L hts-voice-nitech-jp-atr503-m001 | grep '\.htsvoice$')` + `DIC=/var/lib/mecab/dic/open-jtalk/naist-jdic` → `echo "音声合成のサンプルです" | open_jtalk -x "$DIC" -m "$VOICE" -s 16000 -ow examples/voice/tier2_reference_ja.wav` (**16 kHz mono 固定**、WavLM 入力 rate 一致で内部 resample 経路を bypass、bit-reproducibility 強化、5-10 秒)。Attribution: CC-BY-3.0 派生著作物として `LICENSE_NOTICE.txt` (`vocaboot.license_check` per-run emission) で履行。PR1a と並列着手可、step 3a と完全独立。Audit trail: `vocaboot-stage2-pr1b-r14-round7-openjtalk.md` (round-7 verdict) + `vocaboot-stage2-pr1b-r14-round8-architecture-revise.md` (round-8 architecture REVISE 5 件: license allow-list、命名、format、pin axis、CI SoT).
   - **Step 3a (R14 round-6: 即先行、dataset 依存ゼロ)** — `metrics.mcd` (pure function on 2 MFCC ndarrays, DTW-aligned, **block bootstrap CI** with block_size=25 frame ≈ 250 ms per R14 round-6 critic finding — plain percentile bootstrap on time-correlated cepstra under-estimates CI, violating R5) + `MetricResult.direction: Literal["higher_better", "lower_better"] = "higher_better"` field added (default for back-compat). The sign-flip trick (`f0_stability` の `neg_jitter = -jitter`, `threshold = -0.02`) is **completely removed** in this PR: `f0_stability` migrates to `direction="lower_better"` storing raw jitter against `threshold = +0.02`, and `mcd` lands with `direction="lower_better"`. `MetricResult.passes` branches on `direction`. `agent_verify.run`'s aggregator (`_numeric_verdict`) reads the field so the tuple stays sign-uniform without the negation. **audio_ingest / VoiceProfile 一切触らない** — step 3a は pure metric layer 内で完結。PR1a / PR1b / step 3b に依存せず、PR1a 完了直後 (現状) 即着手可。
   - **Step 3b (PR1b + step 3a 完了後、R14 round-7 改訂 / round-9 phantom 訂正 2026-05-12)** — (i) `VoiceProfile` schema_version=2 bump + `mfcc_cepstra_bytes` / `mfcc_cepstra_shape` / `mfcc_cepstra_dtype` フィールド追加 (R14 round-6 architect 致命的見落とし解消 — `VoiceProfile` から MCD reference を取得可能にする構造、round-4 までの phantom claim 修正)、(ii) **`profile_match.build()` で 25-coef MFCC を計算 + populate** (R14 round-9 phantom 訂正: 旧文言「`audio_ingest.build()`」は実装不在 — `audio_ingest` には `ingest()` contextmanager のみで `build()` 関数は存在しない。MFCC 抽出は WavLM 抽出と同じ entry point `profile_match.build()` 内で完結させる方が verify-similarity extra のみの単一依存帯と一致し最適、3 agent 全員一致確認 R14 round-9)、(iii) `metrics.wavlm_cosine` (thin wrapper around `profile_match.WavLMSpeakerSimilarity` via `SpeakerSimilarityProtocol` DI — duplicate WavLM extraction surface 無し)、(iv) `agent_verify.run` signature extension (`reference_voice: VoiceProfile | None = None`; `None` → Tier 1 only、supplied → MCD reads `reference_voice.mfcc_cepstra` + wavlm_cosine reads `reference_voice.wavlm_embedding`)、(v) `tests/test_stage2_pipeline.py` Tier 2 canary that closes criterion #1 (uses PR1b canary file: `tier2_reference_ja.wav`)、(vi) MCD threshold (6 dB literature placeholder) を canary 分布実測校正で更新 (R5: N=複数 必須、N=1 校正禁止)、(vii) librosa MFCC parameters の public pin (`MFCC_*` constants in `metrics.py` + drift test、analyst R14 round-9 指摘 — `n_fft / n_mels / dct_type / norm / htk / win_length / hop_length / center / pad_mode / lifter` 全部 public 化、WavLM sha256 と同等の供給鎖 audit)。OpenJTalk HMM 合成は real human voice 訓練分布 (WavLM の LibriSpeech / VoxCeleb) と distribution shift があるため、`wavlm_cosine` 閾値 0.60 は canary 分布実測で再 calibrate (HMM 合成 → DiffSinger 出力 cosine と HMM 合成 → 4-partial cosine を分離可能な閾値)。

The MCP server (`vocaboot mcp-serve`) is **Stage 2.5**, not Stage 2. `pipeline.run` is already MCP-friendly (kwargs-only, pure, dataclass return) so the wrap is a thin adapter file when Stage 2.5 lands. The natural-language interface remains **Stage 4**, unchanged. Self-train (target voice from user's own recording) is **Stage 3** and structurally separate.

## Stage 2 step 0 — preconditions

### 0a. License-clean reference voice acquisition

Tier 2 canary (acceptance criterion 1 below) needs a *real recorded voice* whose license permits CI redistribution. Stage 0 result (B) covered acoustic SVS checkpoints; this is a separate acquisition problem for raw vocal audio. Surveyed candidates:

| Source | License | Coverage | Direct usability for vocaboot CI |
|---|---|---|---|
| Mozilla Common Voice (ja) | **CC0-1.0** | speech (read sentences) | ✅ usable as Tier 2 reference; not singing, so speaker-similarity is the testable claim, not pitch tracking |
| OpenSLR LibriSpeech | CC-BY-4.0 | English speech | usable with attribution; en-only |
| OpenSLR JVS | CC-BY-SA-4.0 | Japanese speech (multi-speaker) | usable with ShareAlike; closer to vocaboot target than LibriSpeech |
| MUSDB18-HQ | mixed (incl. CC-BY-NC-SA segments) | music+vocal stems | **rejected** — license-mixed, partial NC |

| Open JTalk + nitech voice | engine BSD-3, voice **CC-BY-3.0** | Japanese HMM-parametric synthesis | ✅ usable as Tier 2 reference; HMM-vs-real distribution shift acknowledged (calibrated in step 3b) |

**Decision** (R14 round-7, 2026-05-12, **ACCEPT Path B = OpenJTalk + nitech voice**): round-5 Wikimedia, round-6 piper-ja CC0, round-7 initial JVS candidate path were each retracted in sequence. **Why each was rejected**: (round-5 → round-6) single-file Wikimedia has no takedown fallback + no pre-screen step against criterion #1's `wavlm_cosine` ≥ 0.60 threshold. (round-6 → round-7) piper has no `ja` directory (`https://huggingface.co/api/models/rhasspy/piper-voices/tree/main` 2026-05-12: 28 langs + zh, **ja 不在**) + the CC0 license claim was unsubstantiated (piper voices inherit dataset license, typically JSUT CC-BY-SA-4.0). (round-7 initial JVS → final Path B) JVS audio is **not** CC-BY-SA-4.0 as previously believed — the corpus page (`sites.google.com/.../jvs_corpus`) states a bespoke "Research / Non-commercial / Personal use" term for audio with CC-BY-SA-4.0 only on tags, and the 3.5 GB Google Drive distribution is not curl-automatable for CI. **Why Path B (OpenJTalk) wins on round-7 verify**: (a) license fully verified from extracted deb copyright files — engine BSD-3-clause (NIT, 2008-2013), voice **CC-BY-3.0** (NIT + Tokyo Tech, 2003-2012) with the HTK EULA caveat applying only to the *training toolkit* not the released voice data (Debian places it in multiverse out of caution; NIT explicitly released the artifact under CC-BY-3.0); (b) full automation — `apt install open-jtalk hts-voice-nitech-jp-atr503-m001 open-jtalk-mecab-naist-jdic` + `open_jtalk` CLI generates the wav, no Google Drive / email gate / token; (c) Japanese language match with vocaboot's user target; (d) attribution clause is satisfied by `examples/voice/README.md` + per-run `LICENSE_NOTICE.txt` already emitted by `vocaboot.license_check`. The CC-BY-3.0 license is added to `examples/voice/README.md`'s reference-voice allow-list **and** to `docs/ckpt_registry.md`'s top-of-file allow-list scoping block (the latter added in R14 round-8 to keep the registry as single source of truth — previously only the README declared the extension, splitting the SoT) — CC-BY-3.0 is the predecessor of CC-BY-4.0, OSI-aligned, Debian-main-distributed, and semantically equivalent (Attribution + derivative OK). The output `.wav` is a derivative work and inherits CC-BY-3.0. **Step 3a is unaffected** (pure metrics layer, dataset-independent, 104 passed). Audit trail: `vocaboot-stage2-pr1b-r14-round7-openjtalk.md` (round-7 verdict + license one-source extract), `vocaboot-stage2-pr1b-r14-round8-architecture-revise.md` (round-8 architecture REVISE 5 件: license allow-list registry-side、命名 engine-leak 回避、format 16 kHz 固定、pin 4-axis、CI SoT 明示), `vocaboot-stage2-step3-r14-round6-phantom-correction.md` (round-6 piper phantom retraction). The file name `tier2_reference_ja.wav` encodes **purpose + language only** — engine identity (`openjtalk`) and speaker ID (`nitech_jp_atr503_m001`) are both excluded from the path so a future engine pivot becomes a `tier2-reference-voice` registry-block swap rather than a repo-wide file rename. Speaker-ID redaction follows Stage 1.5-B `_USER_AUDIO_REDACT_KEYS` policy; engine-name redaction is the R14 round-8 extension on the same principle (artifact paths should not encode swappable identities). HMM-vs-real distribution shift is acknowledged: WavLM trained on real speech may embed OpenJTalk further from LibriSpeech than ideal, but the relative ordering (4-partial < HMM < real) is preserved and step 3b re-calibrates the threshold on the actual canary distribution before closure (open thresholds contract).

### 0b. `[verify-similarity]` extra declared

`pyproject.toml` declared the `[verify-similarity]` extra in the Stage 2 R14-round-2 fix (2026-05-12): `transformers>=4.40,<5`, `torch>=2.1,<3`, `torchaudio>=2.1,<3`, `librosa>=0.10,<1`. The extra is self-sufficient — installing it without `[svc]` or `[diffsinger]` still works (deliberate duplication of `torch` and `librosa`).

## Module surfaces

### `vocaboot.profile_match` (new)

```python
@dataclass(frozen=True)
class VoiceProfile:
    """A target-voice fingerprint produced from a reference audio.

    The WavLM embedding tensor is stored as raw bytes + shape + dtype rather
    than a live ``np.ndarray`` because ``frozen=True`` only blocks rebinding,
    not in-place mutation (``arr[0] = 0`` would still go through on an
    ndarray field). bytes are structurally immutable.
    """

    wavlm_embedding_bytes: bytes      # serialized (T, 768) embedding
    wavlm_embedding_shape: tuple[int, int]
    wavlm_embedding_dtype: str        # e.g. "float32"
    mfcc_cepstra_bytes: bytes | None  # serialized (T_frames, 25) MFCC for MCD (Stage 2 step 3b; None on schema_version=1 sidecars)
    mfcc_cepstra_shape: tuple[int, int] | None
    mfcc_cepstra_dtype: str | None
    f0_stats: F0Stats                 # mean / std / range (Hz) on voiced portion
    spectral_centroid_mean: float
    duration_seconds: float
    source_sha256: str                # sha256 of the reference wav
    schema_version: int = 2           # bumped to 2 in Stage 2 step 3b (mfcc_cepstra fields added per R14 round-6 architect — without them MCD via reference_voice is a phantom claim)


def build(reference_wav: Path, *, sample_rate: int = 44100) -> VoiceProfile:
    """Run WavLM-base + pyworld feature extraction on a reference audio."""


def match_distance(profile: VoiceProfile, candidate_wav: Path) -> MetricResult:
    """Bootstrap-CI'd cosine distance between two VoiceProfiles' WavLM means."""
```

`VoiceProfile` round-trips losslessly through JSON: bytes encode as base64, shape and dtype as scalars. Loading reconstructs the ndarray via `np.frombuffer(bytes, dtype).reshape(shape)`.

### `vocaboot.audio_ingest` (new)

```python
@dataclass(frozen=True)
class IngestedAudio:
    """Pure data class — consent-checked, R15-safe wrapper around a user audio path."""

    path: Path                        # tmp-only; deletion is the contextmanager's job
    intent: Literal["reference", "target"]
    consent_no_store: bool
    consent_no_redistribute: bool
    source_sha256: str


@contextlib.contextmanager
def ingest(
    audio: Path,
    *,
    intent: Literal["reference", "target"],
    consent_no_store: bool,
    consent_no_redistribute: bool,
) -> Iterator[IngestedAudio]:
    """Refuse → copy to tmp → yield wrapper → delete tmp on exit. Use as:

        with ingest(path, intent="reference", consent_no_store=True,
                    consent_no_redistribute=True) as ia:
            profile = profile_match.build(ia.path)
    """
```

`ingest` is a `contextlib.contextmanager` generator (not a `__enter__`/`__exit__` pair on `IngestedAudio`) so the tmp-file deletion side effect lives in the generator's `finally` block, keeping `IngestedAudio` itself purely descriptive. The contextmanager runs **five steps in this order** (R14 round-3 audit, 2026-05-12: order was previously underspecified):

1. `privacy.refuse_user_audio_without_consent(...)` — fires **before** `mkdtemp` so a refuse does not leak a stray tmp dir. Also calls `privacy.refuse_if_protected(audio, kind="user_audio")` to catch symlinked protected references.
2. `source_sha256 = _sha256_of_file(original_path)` — computed on the **original** path, not the tmp copy. `IngestedAudio.source_sha256` then identifies the user-supplied artifact, not the inode of the copy. `profile_match.build` accepts an optional `precomputed_sha256` kwarg so it does not re-hash the audio downstream.
3. `tmp_dir = tempfile.mkdtemp(prefix="vocaboot-ingest-")` — Python's `mkdtemp` is atomic and creates the directory with mode `0o700`, mitigating race / symlink-replace attacks. Wrapped in `try` / `finally`.
4. `shutil.copy2(original, tmp_dir / basename)` followed by `os.chmod(tmp_file, 0o600)` — `copy2` preserves mtime; the explicit `chmod` overrides the default umask so the copy is not group-readable on multi-user hosts. Inside the same `try` block, yield `IngestedAudio(path=tmp_file, intent=..., source_sha256=source_sha256, ...)`.
5. `finally: shutil.rmtree(tmp_dir)` — no `ignore_errors=True`; rmtree raising `OSError` surfaces a real-world cleanup failure (read-only fs, deleted dir) rather than silently leaving a directory behind.

The original audio path is *never* loaded by anything except the consent check and the sha256 computation. Museum entries from this surface use the **fixed key map** `_MUSEUM_KEY_MAP = {"reference": "reference_voice_path", "target": "target_voice_path"}` (declared at module scope in `audio_ingest`) so the Stage 1.5-B hard-exclude rule (`museum._USER_AUDIO_REDACT_KEYS`) fires reliably. Callers that bypass the map and pass a tmp path under an `_path`-suffixed key (e.g. `tmp_copy_path`) hit the generic `{basename, sha256}` scrubber — and the basename would leak the original file name through the tmp copy. The fixed map elevates "design intent" into an implementation contract.

### `audio_ingest` consent flags vs `--accept-nc` (R14 round-3 clarification)

Two consent flags + one license flag look adjacent but cover three distinct moments:

| Flag | Scope | When acknowledged | What it permits |
|---|---|---|---|
| `consent_no_store` | vocaboot side (R15) | `ingest()` call | vocaboot may load the audio into memory and write a tmp copy that is deleted on exit |
| `consent_no_redistribute` | user side, downstream | `ingest()` call | user understands that any subsequent NC-vocoder output is bound by the NC clause and cannot be redistributed commercially |
| `--accept-nc` | runtime act | `synth` / `demo` invocation | vocaboot may load the CC-BY-NC-SA-4.0 vocoder weights and run inference |

`consent_no_redistribute` and `--accept-nc` are not duplicates — the former is the **pre-condition** (user understands the NC constraint will apply downstream) acknowledged at ingest time, the latter is the **act** of running NC weights acknowledged at synth time. The two are defense-in-depth: a CI run that loads a reference voice without intending to synthesize must still pass `consent_no_redistribute` (so that future synthesis on the same artifact stays NC-aware), and a synth run on an audio-less synthetic score still needs `--accept-nc` independently. Removing either flag would create a path where one acknowledgement is silently inherited from the other — exactly the "silent inheritance" R15 forbids.

### MCP boundary invariant (Stage 2.5 forward-declaration)

`ingest()` is a **CLI-and-Python-only surface**. Stage 2.5 (`vocaboot mcp-serve`) **must not** expose `ingest()` as an MCP tool. Reason: an MCP `bool` parameter is settable by the LLM, so a `consent_no_store=True` argument coming through MCP carries no human signal of consent — a Claude turn that decides "the user probably means yes" silently bypasses R15.

The Stage 2.5 design therefore exposes only **downstream tools** that take an already-`IngestedAudio` (e.g. a hypothetical `mcp_synth_with_target_voice(profile_path: Path)`), where the audio has *already* been ingested via CLI. The consent boundary is preserved structurally: Claude cannot manufacture an `IngestedAudio` from an MCP call alone. This invariant is recorded in Stage 2 (rather than postponed to Stage 2.5) because changing `ingest()`'s signature later to fence off MCP would be a breaking API change.

A second defense: `consent_no_store` / `consent_no_redistribute` accept truthy values **only when the runtime can prove a human emitted them**. The Stage 2 implementation reads them from CLI flags or from environment variables (`VOCABOOT_CONSENT_NO_STORE=1`, `VOCABOOT_CONSENT_NO_REDISTRIBUTE=1`); a Python-API caller passing literal `True` works for tests but is not exposed across MCP.

### CLI surface justify (R14 round-3 clarification)

`vocaboot ingest` is a CLI subcommand, not just a Python function, because the Stage 2 spec ("user wants to drive vocaboot from the terminal", R16) makes the CLI the primary user surface. The alternatives that R14 round-3 audited:

- **Pure Python library** (no CLI): user runs Python interactively or writes a script. Loses the "terminal-first" property and pushes consent-flag literacy into Python source where it is easier to commit `consent_no_store=True` to a public repo by accident.
- **MCP tool**: rejected by the MCP boundary invariant above.
- **Claude Skill**: a Skill is a markdown-based behavior file, not an executable. It cannot host the tmp-copy / sha256 / museum-archive side effects.
- **CLI subcommand** (chosen): user types `vocaboot ingest path.wav --intent reference --consent-no-store --consent-no-redistribute` and the flags are literally typed by a human. The audit trail (shell history) is the only place the consent originated. This is the structurally strongest "human-in-the-loop" surface.

`vocaboot ingest` is intentionally a **separate subcommand from `vocaboot profile`** even though `profile` internally `with`-uses `audio_ingest.ingest`. Keeping them separate gives criterion #3 a CLI surface to test in isolation (consent-refuse exit code + museum redaction) without coupling to the profile-build flow.

### Museum write-back path for ingest REJECT (R14 round-3 clarification)

`vocaboot ingest` writes a museum entry **only on `ConsentRequiredError`** (the consent-refuse REJECT path). The CLI wrapper:

```python
try:
    with audio_ingest.ingest(audio, intent=intent,
                             consent_no_store=consent_no_store,
                             consent_no_redistribute=consent_no_redistribute) as ia:
        click.echo(ia.path)  # success: print tmp path; tmp is gone after CLI exit
except ConsentRequiredError:
    museum.archive_failure(
        root=failures_root,
        reason=f"stage_2_consent_refused_{intent}",
        detail={audio_ingest._MUSEUM_KEY_MAP[intent]: str(audio)},
    )
    sys.exit(7)  # privacy/consent refuse — same exit code as license refuse
```

The museum entry's `metadata.json` shows `"<redacted-user-audio>"` for the path field thanks to `_USER_AUDIO_REDACT_KEYS`. Criterion #3 asserts this redaction is visible end-to-end, not merely that `museum.scrub_detail` is unit-tested. Other failure modes (`shutil.copy2` raising `OSError`, disk full) propagate unhandled — they are not user-facing consent decisions and the failure museum is reserved for security/privacy events.

### Shared protocol (Stage 3 SVC contract)

```python
class SpeakerSimilarityProtocol(Protocol):
    """Common contract for profile_match (Stage 2) and SVC (Stage 3) embeddings.

    Both stages produce a (T, D) embedding from an audio path and a mean-cosine
    similarity between two such embeddings. Declaring the protocol in Stage 2
    avoids the rewrite-to-shared-base-class scenario that would otherwise hit
    in Stage 3 when SVC consumes a VoiceProfile as a target.
    """

    def embed(self, audio: Path) -> np.ndarray: ...
    def mean_cosine(self, a: np.ndarray, b: np.ndarray) -> MetricResult: ...
```

Stage 2 `profile_match` implements this protocol; Stage 3 SVC consumes `VoiceProfile` instances as target input through the same protocol surface.

### `vocaboot.cli` extension

Two new subcommands, both decorated with `_shared_options`:

- `vocaboot profile --reference <wav> --out <profile.json>` — Tier 0 of the profile-match flow; persists a VoiceProfile to a JSON sidecar.
- `vocaboot ingest <audio> --intent reference --consent-no-store --consent-no-redistribute` — manual entry point for testing the consent gate end-to-end.

Both surfaces are additive. The Stage 1 `synth` and `demo` subcommands are unchanged.

### `agent_verify.run` extension (R14 round-4 — `VoiceProfile`-only signature)

```python
def run(
    audio_path: Path | str,
    *,
    score: "Score",
    ckpt: Path,
    reference_voice: VoiceProfile | None = None,   # NEW: Tier 2 when supplied
) -> GateResult: ...
```

`reference_voice=None` ⇒ Tier 1 only (current behavior). `reference_voice=<VoiceProfile (schema_version=2)>` ⇒ also runs `metrics.mcd` (`direction="lower_better"`, reads `reference_voice.mfcc_cepstra` — the serialized 25-coef MFCC populated by `profile_match.build()` in step 3b, R14 round-9 phantom 訂正; the round-6 text named `audio_ingest.build()` which never existed) and `metrics.wavlm_cosine` (`direction="higher_better"`, reads `reference_voice.wavlm_embedding`) against that profile. The verdict aggregator (`_numeric_verdict`) reads `MetricResult.direction` so both "smaller is better" and "larger is better" metrics share one passes-resolution path — the prior sign-flip trick is dropped in step 3a (both `f0_stability` and `mcd` now use direction-based `passes`).

**Why `VoiceProfile`, not `Path`** (R14 round-4 decision): accepting a `Path` would let `agent_verify` trigger `profile_match.build` (torch + librosa + WavLM weights download) when called, which breaks the import-safe property the verify module currently has. The `Path → VoiceProfile` conversion is the CLI / `pipeline.run` layer's responsibility — they are also the only layers that pass through the `audio_ingest` consent gate, so the R15 audit trail is preserved and Stage 2.5's MCP boundary invariant (Claude cannot manufacture a `VoiceProfile`) holds without an extra runtime check.

**Schema_version=2 contract** (R14 round-6 致命解消 / round-9 phantom 訂正 2026-05-12): round-4 specified `reference_voice: VoiceProfile | None` without checking whether `VoiceProfile` actually carries MCD-reachable features — it did not (only `wavlm_embedding`, no mel-cepstra). R14 round-6 architect surfaced this as a phantom claim (R17 §4). Step 3b therefore extends `VoiceProfile` to schema_version=2 with `mfcc_cepstra_bytes` / `mfcc_cepstra_shape` / `mfcc_cepstra_dtype` populated by **`profile_match.build()`** (librosa MFCC 25-coef, 10 ms hop). The round-6 text originally named `audio_ingest.build()` here, but that function never existed — `audio_ingest` exposes only the `ingest()` contextmanager, never a `build()` — so R14 round-9 訂正 routes MFCC population through `profile_match.build()`, which already owns WavLM extraction and is the single `[verify-similarity]` entry point. Legacy schema_version=1 sidecars are rejected by `from_json_dict` with a "rebuild via vocaboot profile" instruction (pre-alpha is acceptable break).

## Acceptance criteria (Stage 2 closure)

1. **Tier 2 canary**: `tests/test_stage2_pipeline.py::test_tier2_distinguishes_synthetic_from_voice` produces a synthesized output from the Stage 1 synthetic path AND loads the canary reference at `examples/voice/tier2_reference_ja.wav` (R14 round-7 ACCEPT Path B = Open JTalk + nitech voice CC-BY-3.0; round-8 architecture: stored wav SoT + 4-axis pin in `docs/ckpt_registry.md` `tier2-reference-voice` block — engine identity lives in `source_engine:` field, not the file path), then asserts:
   - synthetic output → `mcd` CI lower bound > MCD_THRESHOLD (`direction="lower_better"` fails) OR `wavlm_cosine` CI upper bound < 0.60 → REJECT/REVIEW at Tier 2;
   - recorded voice → `mcd` CI strictly below MCD_THRESHOLD AND `wavlm_cosine` CI strictly above 0.60 → APPROVE at Tier 2.
   `MCD_THRESHOLD` lands as **6.0 dB literature placeholder** in step 3a; step 3b closure re-calibrates it from the actual canary distribution against the synthetic 4-partial REJECT arm (Stage 2 closure cannot ship with the placeholder if synthetic 4-partial passes at 6.0 dB — that would silently make the gate non-discriminating). Without both arms, the gate is non-discriminating. Closure is **gated on PR1a (done) + PR1b (canary file) + step 3b (wire-in)** per R14 round-4/5/6.
2. **Discrimination canary**: `match_distance(profile_A, audio_B)` with deliberately different speakers must return cosine ≤ 0.7 (CI strict). Round-trip identity (same audio) ≥ 0.99. Both checks live in `tests/test_stage2_pipeline.py`.
3. **Consent gate end-to-end**: `tests/test_user_audio_guard.py` extended with a `vocaboot ingest` CLI invocation that exits non-zero unless both `--consent-no-store` and `--consent-no-redistribute` are set; museum entries from `vocaboot ingest` REJECT paths assert `_USER_AUDIO_REDACT_KEYS` actually hit (full redaction visible in `metadata.json`).
4. **VoiceProfile round-trip**: `build(wav)` → JSON sidecar → `load(json)` → re-`match_distance(loaded, wav)` returns cos ≥ 0.99 (numerical identity within float tolerance).
5. **No Stage 1 regression**: `pytest` still passes the 52 Stage 1.5 tests (49 prior + 3 docs pins) with no skips other than the pre-existing pyworld/librosa-extras-conditional skips.
6. **Quality gate doc update**: `docs/quality_gate.md` Tier 2 row's "Where wired" column changes from "**planned**" to one `metrics.py:LNN` reference for `mcd` (landed in step 3a) and one for `wavlm_cosine` (landed in step 3b, thin wrapper around `profile_match.WavLMSpeakerSimilarity` so the source-of-truth file:line points back at `profile_match`).
7. **Layer count**: total non-underscore modules in `src/vocaboot/` ≤ 14. Snapshot at the time this spec was first written: **12** (`agent_advisory`, `agent_verify`, `cli`, `input`, `license_check`, `metrics`, `museum`, `output`, `pipeline`, `privacy`, `score_align`, `svs_engine` — `__init__` and `_resources` are excluded as underscore-prefixed). After Stage 2 step 1 lands `profile_match` the count is **13**; Stage 2 step 2 adds `audio_ingest` and reaches the ceiling at **14**. Stage 3+ ceiling needs a separate `services/` + `core/` package split decision and is **not** locked here.
8. **WavLM-base weights pin** (atomic with precondition **PR1a** of step 3, per R14 round-4 + round-5): `docs/ckpt_registry.md` extended with a sha256 pin for `microsoft/wavlm-base` weights (the `pytorch_model.bin` artifact alone is pinned; HF's metadata files are integrity-managed by the HuggingFace cache layout), cache path `~/.cache/vocaboot/models/wavlm-base/`, runtime hash verification (defense-in-depth, same as vocoder). Landing this pin is the **structural precondition** for step 3a/3b — leaving the `<PINNED-AT-STAGE-2-WIRE-IN>` placeholder while step 3b runs would make criterion #1's Tier 2 canary phantom (R17 §4).
9. **SpeakerSimilarityProtocol declared**: `vocaboot.profile_match` exports `SpeakerSimilarityProtocol` (Protocol class) so Stage 3 SVC can implement the same interface without `profile_match` rewrite.

## Out of scope for Stage 2

- MCP server (Stage 2.5).
- Self-train recipe and target-voice training path (Stage 3).
- DDSP-SVC fallback (Stage 3) — protocol prepared in criterion 9, implementation deferred.
- Natural-language interface (Stage 4).
- HF Space demo (gated by acquisition Path A landing a Default-tier ckpt, see `docs/ckpt_registry.md`).
- Subjective MOS evaluation (`docs/quality_gate.md` Tier 4, explicitly out of scope).
- Singing-corpus reference (Stage 2 uses speech-as-reference; revisit at Stage 3).

## Why this exists

"Stage 2 → Stage 3 → Stage 4" is a roadmap label, not a spec. This document is the spec, and Stage 2 is closed only when every numbered criterion above is satisfied — a partial PR with a misleading label does not close Stage 2.

The architecture above is the result of an iterative audit. The current Stage 2 design — Tier 1 + Tier 2 separability, `VoiceProfile` schema v2 with bundled MFCC, block-bootstrap CI, the piper-ja TTS canary, and the `audio_ingest` 5-step consent contract — is the converged form. The discarded paths (Mozilla CV ja, single-file Wikimedia canary, sign-flip metric values, `Path → reference_voice` bridge across modules, etc.) and the per-round REVISE history that surfaced them are captured in `docs/decision_log.md` for traceability without polluting the spec.
