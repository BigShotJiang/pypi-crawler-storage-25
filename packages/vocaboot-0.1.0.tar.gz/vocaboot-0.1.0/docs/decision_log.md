# Decision log

This file captures architectural decisions that shaped the current Stage 2 design. The spec (`docs/stage_2.md`) only carries the **current** decision; this log preserves the discarded alternatives and the audits that produced them so future contributors can trace why the spec looks the way it does.

The audit format is a converged 3-agent (analyst / architect / critic) review of an explicit set of design options with a final `Verdict: ACCEPT / REVISE / REWRITE` and an option chosen. Each entry below summarises one such review.

## Stage 2 step 2 — audio_ingest contract

**Decided:** 5-step contextmanager (consent + protected-path refusal → `source_sha256` on the original path → `mkdtemp` + `copy2` + `chmod 0o600` → yield → `shutil.rmtree` without `ignore_errors`).

**Gaps surfaced by the audit:** contextmanager step order underspecified; `source_sha256` had no defined computation point; museum key mapping was design intent but not contract; museum write-back on `ConsentRequiredError` absent; `consent_no_redistribute` / `--accept-nc` relationship undifferentiated.

**Discarded:** an open-coded ingest helper without the explicit step order. The contextmanager form ensures the cleanup runs even on `ConsentRequiredError`.

## Stage 2 step 3 — Tier 2 verify metrics wire-in

**Decided:** split into **PR1** (WavLM pin + canary wav) + **step 3a** (`metrics.mcd` alone, lands first because it is dataset-independent) + **step 3b** (`metrics.wavlm_cosine` + canary). `MetricResult` gains `direction: Literal["higher_better","lower_better"]` to retire the sign-flip surrogate; `agent_verify.run`'s `reference_voice` takes `VoiceProfile | None`, not `Path | None`, so the verify module stays import-safe and `audio_ingest` remains the only `Path → VoiceProfile` bridge.

**Gaps surfaced by the audit:**
- Atomic step 3 would have left the WavLM sha256 unpinned, generating a phantom claim against criterion #1.
- `value = -mcd_db` (sign-flip workaround) turned museum entries and CLI display into lies whenever an MCD reading left the verdict aggregator.
- A `Path` parameter on `agent_verify.run` would force the verify module to pull `torch` + `transformers` + WavLM at import time, breaking the import-safe property and bypassing the `audio_ingest` consent gate.
- The proposed `VoiceProfile` carried `wavlm_embedding` only — `metrics.mcd(output, reference_voice)` was impossible without a schema extension.
- The first PR1b draft used a single-file Wikimedia source with no takedown fallback and no pre-screen against the `wavlm_cosine ≥ 0.60` threshold (criterion #1 phantom risk).
- MCD bootstrap CI on time-correlated cepstra required block bootstrap (block_size ≈ 250 ms); plain percentile bootstrap under-estimates CI width and violates R5.

**Resolution:** `VoiceProfile` schema bumped to v2 with `mfcc_cepstra_bytes`. `metrics.bootstrap_ci` extended with `block_size` kwarg; MCD calls it at `_MCD_BLOCK_MS=250`. `f0_stability` migrated to `direction="lower_better"` with positive jitter / positive threshold in the same PR.

## PR1 progression — WavLM weights + canary acquisition

**Decided:** Path C (split into PR1a WavLM + PR1b canary acquisition).

**Discarded:**
- Path A (Claude-atomic): blocked by two fatal findings — `profile_match.WavLMModel.from_pretrained(str(p.parent))` requires a full HF repository layout (a flat `pytorch_model.bin` raises `OSError: config.json missing`), and Mozilla CV ja distribution is gated behind email signup + login token, so neither CI nor Claude-Code can acquire it automatically.
- Path B (user-manual + commit): the WavLM weights are 360 MB binaries; bundling them violates the no-redistribution constraint of CC-BY-SA-3.0 §4(b).
- Path D (full-stop): would have left Tier 2 unwired indefinitely.

**Resolution:** PR1a calls `huggingface_hub.snapshot_download` to materialise the full HF layout in `~/.cache/vocaboot/models/wavlm-base/` (no `profile_match.py` change required). PR1b switched the canary source from Mozilla CV ja to a self-generated piper-ja / nitech sample (CC-BY-3.0 attribution, bit-reproducible, no takedown surface).

## Tier 2 threshold gate — point vs. 2-sided band

**Decided:** `MCD_THRESHOLD_BAND_DB = (450.0, 550.0)` — a ±10% uncertainty band around the calibrated 500 dB point anchor, passed to `metrics.mcd` as `threshold_ci=`. `MetricResult.passes` enforces strict 2-sided disjointness: the metric CI must lie entirely above or below the band.

**Gap surfaced:** the original 1-sided gate treated the threshold as a point estimate with implicit zero variance. R5 requires the threshold be treated as a calibrated quantity with SE. Without the band, the WavLM-cosine / MCD gate silently mis-classified candidates whose CI straddled the anchor.

**Discarded:** the literature Kominek 2008 6-8 dB anchor — it applies to native MCEP (pysptk / HTK), not the librosa-MFCC scale used here, so the dB readings differ by ~10²-10³. Re-anchoring to the literature value requires the pysptk migration deferred to 0.2.0 (`CHANGELOG.md` §Deferred / dormant phantom #3). The 500 dB anchor is the librosa-MFCC-scale equivalent under the same separability contract.
