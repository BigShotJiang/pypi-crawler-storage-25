# vocaboot — Checkpoint Registry

`vocaboot` bundles **no** model weights. This file is a registry of upstream checkpoints whose licenses are compatible with our agent-verify pipeline and whose authors permit redistribution-by-link.

Every entry has:

- **license**: SPDX identifier. For **ckpt entries** (acoustic / vocoder, role = `acoustic` | `vocoder`): Apache-2.0 / MIT / CC-BY-4.0 / CC0 acceptable for the default tier; CC-BY-NC-SA variants accepted only with `--accept-nc` opt-in for personal use. For **reference-voice entries** (Tier 2 verify anchors, role = `reference-anchor`): allow-list extended to {CC0-1.0, MIT, CC-BY-3.0, CC-BY-4.0, CC-BY-SA-4.0} per `examples/voice/README.md` — CC-BY-3.0 is the Debian-main-distributed predecessor of CC-BY-4.0 (semantically equivalent: Attribution + derivative OK), and CC-BY-SA-4.0 is accepted because the audio is metric-consumed (read-only by `metrics.wavlm_cosine` / `metrics.mcd`), not redistributed under a derivative license.
- **sha256**: file integrity pin. Reference-voice entries additionally pin **size_bytes + sample_rate + duration_seconds** for 4-axis drift detection (root-cause separation between regeneration drift vs file corruption).
- **engine**: which `--engine` flag accepts this checkpoint (or `verify-similarity` for Tier 2 metric anchors).
- **source**: upstream URL.

This file is human-curated. **SHA-256 runtime verification by `vocaboot.license_check` is a Stage 1 step 2 deliverable** (promoted from "Stage 0 follow-up"): without it, a user can pass any `--ckpt-license` SPDX string and bypass the NC gate. Stage 1 step 2 also wires the **attribution emission** required by CC-BY-NC-SA-4.0 distributors (license text copy + community notice + project page link), output to stdout and persisted under the failure museum's `LICENSE_NOTICE.txt`.

## Format

```yaml
- name: <human-readable-id>
  engine: diffsinger
  license: Apache-2.0
  sha256: <64-hex-digits>
  source: <https URL>
  notes: <optional, language coverage / sampling rate / mel config>
```

## Stage 0 — ckpt acquisition gate (closed 2026-05-12, result: B)

Stage 0 ckpt research closed with **0 Apache-2.0 / MIT / CC-BY-4.0 / CC0 acoustic + vocoder pairs** for the DiffSinger format. Per-component findings:

- **vocoder**: `nvidia/bigvgan_v2_44khz_128band_512x` (MIT) and `charactr/vocos-mel-24khz` (MIT) are license-clean, but neither's mel format (general 80-bin) is drop-in compatible with DiffSinger's F0-conditioned NSF 44.1 kHz / 128-bin mel. A vocoder bridge is required to use them.
- **acoustic**: every public DiffSinger voicebank surveyed — `qixuan`, `renri`, `nyaru`, `mitsudate` plus `TIGER DiffSinger`, `Nishiren AI`, `yousa-ling`, `LIEE Immortal Idol`, `Lotte V`, `Opencpop`-derived — is CC-BY-NC-SA-4.0 or stricter (custom NC, RAIL-M, audio-no-redistribute). The openvpi *code* is Apache-2.0 but the *weights* are explicitly CC-BY-NC-SA-4.0.

Acceptance gate per entry (still applies to new candidates):

  1. License SPDX ∈ {Apache-2.0, MIT, CC-BY-4.0, CC0}.
  2. Upstream URL resolves; redistribution-by-link is permitted by the author.
  3. SHA-256 of the downloaded artifact matches the published value.
  4. Smoke synthesis succeeds with `examples/short.ds` under the numeric verify gate (default).

Until a Default-tier pair clears the gate, vocaboot operates on the dual-path documented in the project README: **`--accept-nc` opt-in** for personal smoke, **self-train** for commercial / OSS-clean redistribution.

## Acquisition path decision (Stage 1.5-D, 2026-05-12)

Stage 0 closed with a 0-match survey. Three exit paths exist; vocaboot does not gate forever on a literal Default-tier pair appearing upstream. The Stage 1.5 prerequisite is to **name the path explicitly** so OSS-release readiness has a measurable trigger.

### Path A — wait for Default-tier ckpt to land upstream

Trigger: a new public release of an Apache-2.0 / MIT / CC-BY-4.0 / CC0 DiffSinger-compatible acoustic checkpoint **paired** with a 44.1 kHz / 128-bin / NSF-conditioned mel vocoder (or a license-clean vocoder + a mel adapter).

Cost to vocaboot: zero — we wait. Risk: the wait is unbounded; openvpi's stated policy in 2026-05 is that all community voicebanks ship under CC-BY-NC-SA-4.0 or stricter, and the upstream code-license / weight-license split is intentional. The literature on "permissive SVS weight releases" is empty as of 2026-05-12. **This path is not the default.**

### Path B — release OSS now under NC-only / `--accept-nc` opt-in (chosen)

Trigger: ship vocaboot's wrapper + verify gate publicly while the only working artifact remains the CC-BY-NC-SA-4.0 NSF-HiFiGAN vocoder. The user pays the NC clause every run via the existing four-layer gate (CLI → pipeline → synth → `_load_vocoder`) and the per-run `LICENSE_NOTICE.txt` (`vocaboot.license_check.emit_attribution_notice`).

Readiness gate (must all hold at release time):

- README opens with the NC status — no marketing claim of "free voice synthesis" without the NC qualifier.
- `vocaboot demo --accept-nc` is the only smoke-default path; `vocaboot synth` requires the user to bring a license-declared ckpt (`--ckpt-license` defaults to `CC0-1.0` and is refused unless it matches the registry-pinned allow-list).
- A clear "How to get a Default-tier (commercial) build" section pointing at Path C (self-train).
- HF Space demo is **not** wired (NC-host gray-area, see Round 35 critic C3); the demo medium is a local screencast (mp4) or a CodeSandbox-style read-only widget that does not run the vocoder server-side.

This is vocaboot's chosen path because (a) the wrapper has demonstrable value even on the NC tier (the only public terminal-CLI / Claude-Code-MCP-ready SVS frontend), (b) the NC clause is enforced not waved away, and (c) Path A's wait is unbounded.

### Path C — ship a self-train kit (Stage 3, queued)

Trigger: vocaboot bundles a self-train recipe (DiffSinger Apache-2.0 training code + `nvidia/bigvgan_v2_44khz_128band_512x` MIT vocoder + a mel-format adapter) so a user with 1–3 hours of self-recorded singing data and ~12 GPU-hours of compute can produce a Default-tier acoustic checkpoint themselves.

Scope: this is a *contribution path*, not a Stage 1 deliverable. The mel-format adapter (DiffSinger F0-conditioned 128-bin mel → BigVGAN 128-bin general mel) is the load-bearing piece and lives in Stage 3.

**Decision (2026-05-12)**: vocaboot proceeds on **Path B** for the initial public release. Path C is queued for Stage 3. Path A remains a passive watcher — if an upstream Default-tier pair lands, it is added to the registry automatically and ` vocaboot demo` switches default to it (no `--accept-nc` required).

## Stage 2 verify-similarity weights (WavLM-base, CC-BY-SA-3.0)

Stage 2's Tier 2 verify metrics (`mcd` + `wavlm_cosine`) depend on the WavLM-base self-supervised speech model. Upstream license is **CC-BY-SA-3.0** per `microsoft/UniSpeech/LICENSE` (the HF model card carries no `license:` YAML field and links downstream readers to the upstream LICENSE as the single source of truth). vocaboot's Apache-2.0 source is compatible because the weights are **never redistributed by vocaboot** — they are downloaded by the end user on first use to `~/.cache/vocaboot/models/wavlm-base/` and consumed by metrics only (no derivative artefact is published), so CC-BY-SA-3.0 §4b ShareAlike does not trigger. Attribution is provided via the project `NOTICE` file and this `ckpt_registry.md` entry — these carry the upstream LICENSE URL, SPDX identifier, and `cache_path` so any user inspecting their cache directory can trace the artefact's origin (per-run wav-side `LICENSE_NOTICE.txt` emission is reserved for redistributable derivative outputs — currently the NSF-HiFiGAN vocoder only — and is out of scope for WavLM since no derivative artefact is published). Like the vocoder, the weights are runtime-verified by sha256, defense-in-depth against tampered or unexpected weights.

```yaml
- name: wavlm-base
  role: speaker-embedding (Tier 2 verify)
  engine: verify-similarity
  license: CC-BY-SA-3.0
  license_source: https://github.com/microsoft/UniSpeech/blob/main/LICENSE  # HF card has no YAML license field; upstream LICENSE is the sole authoritative declaration
  revision: efa81aae7ff777e464159e0f877d54eac5b84f81   # pinned commit (PR1a, R14 round-5)
  artifact_url: https://huggingface.co/microsoft/wavlm-base/resolve/efa81aae7ff777e464159e0f877d54eac5b84f81/pytorch_model.bin
  sha256: b41ab60fdcdc113ff164212c72b371dcd420a5773ca1f6c8f54d6809225ce072
  source: https://huggingface.co/microsoft/wavlm-base
  cache_path: ~/.cache/vocaboot/models/wavlm-base/pytorch_model.bin
  size_bytes: 377617425                          # exact bytes of the pinned revision
  notes: |
    Loaded via transformers >= 4.40 (declared in pyproject [verify-similarity]).
    Acquisition: `huggingface_hub.snapshot_download(repo_id="microsoft/wavlm-base",
    revision="efa81aae7ff777e464159e0f877d54eac5b84f81",
    local_dir="~/.cache/vocaboot/models/wavlm-base/")` — populates the full HF
    layout (config.json + preprocessor_config.json + pytorch_model.bin) so
    `WavLMModel.from_pretrained(local_dir)` succeeds. Subsequent invocations
    hit the cache. Tampering refused by sha256 mismatch on the bin file alone,
    same as the vocoder gate (svs_engine._load_vocoder). The sha256 is mirrored
    in src/vocaboot/profile_match.py:_PINNED_WAVLM_SHA256 and the pair is
    pinned by tests/test_ckpt_registry_pin_consistency.py to prevent drift.
```

The Stage 2 **step 3 precondition PR1** (R14 round-4, 2026-05-12) is the atomic unit that lands `metrics.wavlm_cosine`'s prerequisite: (a) download the weights once, (b) compute the sha256, (c) commit it back to the `sha256:` field above, (d) flip `tests/test_stage2_profile_match.py::test_wavlm_loader_refuses_placeholder_pin` to an active-pin assertion. PR1a closed 2026-05-12 with `b41ab60f…ce072` pinned. Until then this entry is a *contract* — `vocaboot` refuses to load WavLM weights whose runtime sha256 does not match the registry pin, but the registry pin itself is `<PINNED-AT-STAGE-2-WIRE-IN>` so the codepath errors clearly during development. Step 3a (`metrics.mcd`) does not depend on the pin and **may** land before PR1 — but step 3b (`metrics.wavlm_cosine` + `tests/test_stage2_pipeline.py` Tier 2 canary) is structurally blocked on PR1 to avoid manufacturing a phantom claim against acceptance criterion #1 (R17 §4).

## Stage 2 Tier 2 reference voice (PR1b, R14 round-8 ACCEPT — Open JTalk + nitech, CC-BY-3.0)

Stage 2's Tier 2 verify gate (`metrics.mcd` + `metrics.wavlm_cosine`) compares user-synth output against a license-clean reference voice. Unlike WavLM weights, this reference wav **is bundled** in the repo (`examples/voice/tier2_reference_ja.wav`, ~80 KB at 16 kHz mono). The rationale (R14 round-8 architect verdict, 2026-05-12) is **cross-platform CI bit-reproducibility**: regenerating the wav from `apt`-installed packages would couple CI to Ubuntu mirror state (deb security rebuilds change `.htsvoice` bytes even at fixed version pins), breaking the per-byte sha256 anchor the metric ratio depends on. **Stored wav = source of truth; the reproduction recipe is a human-maintainer regeneration path, never a CI step.**

```yaml
- name: tier2-reference-voice
  role: reference-anchor (Tier 2 verify MCD + wavlm_cosine canary)
  engine: verify-similarity
  language: ja
  artifact_path: examples/voice/tier2_reference_ja.wav      # repo-relative, bundled
  license: CC-BY-3.0                                         # voice data license (NIT + Tokyo Tech)
  source_engine: open-jtalk (BSD-3-clause, Nagoya Institute of Technology 2008-2013)
  source_voice: hts-voice-nitech-jp-atr503-m001 (CC-BY-3.0, NIT 2003-2012 + Tokyo Tech 2003-2008)
  sha256: 9fc900cb2df345a2f9532c15434983440640fddf500c59cc22d9a1d5af9a1484
  size_bytes: 251564                                         # 44-byte RIFF header + 125760 frames * 2 bytes (16-bit PCM)
  sample_rate: 16000                                         # locked at 16 kHz (= WavLM input rate, no internal resample)
  duration_seconds: 7.860000                                 # 125760 frames / 16000 Hz = 7.86 s (within ≤ 10 s policy)
  attribution: |
    Voice data: hts-voice-nitech-jp-atr503-m001 (CC-BY-3.0)
      Copyright 2003-2012 Nagoya Institute of Technology, Department of Computer Science
      Copyright 2003-2008 Tokyo Institute of Technology, Interdisciplinary Graduate School of Science and Engineering
    Synthesis engine: Open JTalk (BSD-3-clause), https://open-jtalk.sourceforge.net/
    Emitted per-run by vocaboot.license_check.emit_attribution_notice via examples/voice/LICENSE_NOTICE.txt.
  reproduction_recipe: |
    # Human maintainer only — CI uses the stored wav, never regenerates.
    # See examples/voice/README.md "Stage 2 PR1b" section for the full recipe.
    sudo apt install open-jtalk hts-voice-nitech-jp-atr503-m001 open-jtalk-mecab-naist-jdic
    VOICE=$(dpkg -L hts-voice-nitech-jp-atr503-m001 | grep '\.htsvoice$')
    DIC=/var/lib/mecab/dic/open-jtalk/naist-jdic
    echo "音声合成のサンプルです" | open_jtalk -x "$DIC" -m "$VOICE" -s 16000 -ow examples/voice/tier2_reference_ja.wav
  notes: |
    Pinned by sha256 + size_bytes + sample_rate + duration_seconds (4-axis drift
    detection — parallelism with the WavLM block's revision+sha256+size_bytes
    triple). The sample_rate is locked at 16 kHz to match WavLM's input rate so
    no internal resample sits between the stored bytes and the metric.
    Mirrored in tests/test_ckpt_registry_pin_consistency.py with one assertion
    per axis (re-generation drift vs file corruption are distinguishable at
    test-failure time).
    HMM-vs-real distribution shift acknowledged: WavLM (trained on real human
    speech — LibriSpeech / VoxCeleb) embeds OpenJTalk's HMM-parametric output
    further from natural speech than ideal, but the relative ordering
    (4-partial synthetic < HMM-parametric < real human) is preserved and step
    3b re-calibrates the wavlm_cosine threshold on the actual canary
    distribution before Stage 2 closure (open thresholds contract).
    Engine-name leak is avoided in the file path (`tier2_reference_ja.wav`,
    not `openjtalk_ja_sample.wav`) so a future engine pivot (espeak-ng /
    different voice / different language) is a registry-block swap rather
    than a repo-wide file rename. The engine identity lives in the
    `source_engine:` field only.
```

The Stage 2 **step 3 precondition PR1b** (R14 round-7 path, round-8 architecture) is the atomic unit that lands the reference wav and pin: (a) `apt install open-jtalk hts-voice-nitech-jp-atr503-m001 open-jtalk-mecab-naist-jdic` on a maintainer host, (b) generate the wav with `-s 16000` (`open_jtalk` recipe above), (c) place it at `examples/voice/tier2_reference_ja.wav`, (d) compute sha256 + size_bytes + duration_seconds and commit them back to the four `<PINNED-AT-PR1B-WIRE-IN>` slots above, (e) extend `tests/test_ckpt_registry_pin_consistency.py` with `test_tier2_reference_voice_pins_match_registry` (4-axis: sha256 / size_bytes / sample_rate / duration_seconds, wav header parsed via stdlib `wave`). Until then this entry is a *contract* — `metrics.wavlm_cosine` + `metrics.mcd` against the canary refuse to load until the registry pins are populated. Step 3b (Tier 2 canary closure) is structurally blocked on PR1b for the same R17 §4 reason as PR1a was on the WavLM pin.

### Tier 2 canary "APPROVE arm" voice — second sentence, same speaker (R17 audit 2026-05-12)

The R17 audit found that the original step-3b canary measured Arm 2 (`recorded voice → APPROVE at Tier 2`) by comparing `tier2_reference_ja.wav` to itself, which is an identity tautology (mcd = 0.0, cosine = 1.0). Acceptance criterion #1 demands the APPROVE arm test a **different recording**. We add a second wav from the same HMM voice (same speaker, no extra license footprint) reading a different sentence — close enough to the reference for MCD < threshold and cosine > 0.60, but not numerically identical:

```yaml
- name: tier2-canary-alt-voice
  role: APPROVE-arm canary (Tier 2 verify, different sentence from reference)
  engine: verify-similarity
  language: ja
  artifact_path: examples/voice/tier2_canary_ja_alt.wav      # repo-relative, bundled
  license: CC-BY-3.0                                         # same voice data, same license
  source_engine: open-jtalk (BSD-3-clause, Nagoya Institute of Technology 2008-2013)
  source_voice: hts-voice-nitech-jp-atr503-m001 (CC-BY-3.0, NIT 2003-2012 + Tokyo Tech 2003-2008)
  sha256: c5f7f8f313d69c4c7812b2125286811fa3f3f8539c13cb2f52f26a06c79f2855
  size_bytes: 205484                                         # 44-byte RIFF header + 102720 frames * 2 bytes (16-bit PCM)
  sample_rate: 16000                                         # 16 kHz mono (matches reference for parameter-pinned MFCC/WavLM)
  duration_seconds: 6.420000                                 # 102720 frames / 16000 Hz = 6.42 s (within ≤ 10 s policy)
  attribution: |
    Same voice data and engine as tier2-reference-voice (CC-BY-3.0); a different
    sentence ("今日はいい天気ですね") is read so the Tier 2 APPROVE arm is
    not an identity tautology against the reference.
  reproduction_recipe: |
    bash scripts/regenerate_tier2_canary_alt.sh
  notes: |
    Pinned 4-axis (sha256 + size_bytes + sample_rate + duration_seconds), same
    convention as tier2-reference-voice. The APPROVE arm asserts mcd CI < 6.0 dB
    AND wavlm_cosine CI > 0.60 against the reference profile; the REJECT arm
    (synthetic 4-partial oscillator) asserts at least one Tier 2 metric fails.
    Both arms in the same test, per docs/stage_2.md criterion #1 "両腕".
```

### Tier 2 multi-canary voice arm — N=5 sentences for inter-sample SE (R14 round-10 2026-05-12)

The R14 round-9 R17 audit closure used N=1 (`tier2_canary_ja_alt.wav`) as the APPROVE-arm anchor. The round-10 5-体並列 audit (analyst + critic + verifier) judged this an R5 violation — the frame-level bootstrap CI on a single wav does **not** include inter-sample SE, so the APPROVE threshold itself has no estimable variance. Round-10 widens the voice arm to N=5 sentences (same HMM speaker, varied prosody / length) so the calibration distribution captures sentence-within-speaker variance. Multi-speaker bank evaluation (true inter-speaker SE) is deferred to Stage 3 (`speaker_cosine` / ECAPA-TDNN target-quality tier).

The reference profile remains built from `tier2_reference_ja.wav` (single source of truth for the speaker identity). The 5 voice-arm samples below are compared against that profile to produce the APPROVE-arm bootstrap CI:

- `tier2_canary_ja_alt.wav` (entry above, voice_01 in the calibration set)
- `tier2_canary_voice_02.wav` ... `tier2_canary_voice_05.wav` (entries below)

```yaml
- name: tier2-canary-voice-02
  role: APPROVE-arm canary (Tier 2 verify, multi-anchor #2)
  engine: verify-similarity
  language: ja
  artifact_path: examples/voice/tier2_canary_voice_02.wav
  license: CC-BY-3.0
  source_engine: open-jtalk (BSD-3-clause, Nagoya Institute of Technology 2008-2013)
  source_voice: hts-voice-nitech-jp-atr503-m001 (CC-BY-3.0, NIT 2003-2012 + Tokyo Tech 2003-2008)
  sha256: 485342fa1bc7d272326dac08a39932bd45cd3645d1c8cc6221bf38b7abb92a12
  size_bytes: 269324
  sample_rate: 16000
  duration_seconds: 8.415
  attribution: |
    Same voice data and engine as tier2-reference-voice (CC-BY-3.0); sentence
    "明日は雨が降るかもしれません" reads as the 2nd APPROVE-arm calibration
    sample. The 5-sample voice arm captures sentence-within-speaker variance
    for the APPROVE threshold's bootstrap CI.
  reproduction_recipe: |
    bash scripts/regenerate_tier2_canary_voice_arm.sh

- name: tier2-canary-voice-03
  role: APPROVE-arm canary (Tier 2 verify, multi-anchor #3)
  engine: verify-similarity
  language: ja
  artifact_path: examples/voice/tier2_canary_voice_03.wav
  license: CC-BY-3.0
  source_engine: open-jtalk (BSD-3-clause, Nagoya Institute of Technology 2008-2013)
  source_voice: hts-voice-nitech-jp-atr503-m001 (CC-BY-3.0, NIT 2003-2012 + Tokyo Tech 2003-2008)
  sha256: 6152b5822d260ab8021060e6cd78fc54ae6a972f05973c8d16f9237c6d4fdc3f
  size_bytes: 276044
  sample_rate: 16000
  duration_seconds: 8.625
  attribution: |
    Sentence "私は東京に住んでいます", 3rd APPROVE-arm calibration sample.
  reproduction_recipe: |
    bash scripts/regenerate_tier2_canary_voice_arm.sh

- name: tier2-canary-voice-04
  role: APPROVE-arm canary (Tier 2 verify, multi-anchor #4)
  engine: verify-similarity
  language: ja
  artifact_path: examples/voice/tier2_canary_voice_04.wav
  license: CC-BY-3.0
  source_engine: open-jtalk (BSD-3-clause, Nagoya Institute of Technology 2008-2013)
  source_voice: hts-voice-nitech-jp-atr503-m001 (CC-BY-3.0, NIT 2003-2012 + Tokyo Tech 2003-2008)
  sha256: 65469a12c979f8fb16d5cd16b71081f94e6b351424de13f24d56ba683dee9392
  size_bytes: 271244
  sample_rate: 16000
  duration_seconds: 8.475
  attribution: |
    Sentence "コンピューターは便利な道具です", 4th APPROVE-arm calibration sample.
  reproduction_recipe: |
    bash scripts/regenerate_tier2_canary_voice_arm.sh

- name: tier2-canary-voice-05
  role: APPROVE-arm canary (Tier 2 verify, multi-anchor #5)
  engine: verify-similarity
  language: ja
  artifact_path: examples/voice/tier2_canary_voice_05.wav
  license: CC-BY-3.0
  source_engine: open-jtalk (BSD-3-clause, Nagoya Institute of Technology 2008-2013)
  source_voice: hts-voice-nitech-jp-atr503-m001 (CC-BY-3.0, NIT 2003-2012 + Tokyo Tech 2003-2008)
  sha256: 00bd18423105490858189c798b224505890d84f7329b7acb4314fdd970f2b315
  size_bytes: 236204
  sample_rate: 16000
  duration_seconds: 7.380
  attribution: |
    Sentence "新しい本を買いました", 5th APPROVE-arm calibration sample.
  reproduction_recipe: |
    bash scripts/regenerate_tier2_canary_voice_arm.sh
```

## Default tier (license-clean, redistributable by link)

```yaml
# Empty as of 2026-05-12 — Stage 0 ckpt research yielded 0 matches.
# Reopen the gate when an upstream Apache-2.0/MIT/CC-BY-4.0/CC0 acoustic + vocoder
# pair (compatible mel format) is published.
```

## Restricted tier (CC-BY-NC-SA, `--accept-nc` opt-in required)

Community DiffSinger checkpoints below are released under CC-BY-NC-SA-4.0. `vocaboot` refuses to load them unless the user passes `--accept-nc` *and* the runtime is configured for personal, non-commercial use. This is enforced by `vocaboot.license_check`.

Concrete candidates surveyed by the Stage 0 research (informational; users obtain artifacts directly from publishers). Direct artifact URLs + SHA-256 pin will be added to each entry as part of the Stage 1 step 2 `vocaboot demo` deliverable (`source:` below currently points at the publisher landing page, not the artifact itself).

```yaml
- name: nsf-hifigan-onnx-20221211
  role: vocoder
  engine: diffsinger
  license: CC-BY-NC-SA-4.0
  artifact_url: https://github.com/openvpi/vocoders/releases/download/nsf-hifigan-v1/nsf_hifigan_onnx_20221211.zip
  zip_sha256: 3cf1b69a3057861b8fcc23094724a65239bad4d4c8258e9a8752c5fdfbca843a
  onnx_sha256: a3e26672a8c655e3faf65f31cb4339a7fbca7758ba86be9af89e03dced7c3fa4
  onnx_inner_path: nsf_hifigan_onnx/nsf_hifigan.onnx
  source: https://github.com/openvpi/vocoders/releases
  io:
    inputs:
      - mel: float32 [1, n_frames, 128]
      - f0:  float32 [1, n_frames]
    outputs:
      - waveform: float32 [1, n_samples]
  hyper:
    sample_rate: 44100
    mel_bins: 128
    hop_size: 512
    win_size: 2048
    f_min: 40
    f_max: 16000
  notes: |
    44.1 kHz / 128-bin mel / hop 512. The drop-in vocoder for openvpi
    DiffSinger acoustic checkpoints. SHA-256 confirmed against the
    artifact downloaded 2026-05-12.
    Attribution (CC-BY-NC-SA-4.0 distributor obligation, emitted by
    vocaboot's LICENSE_NOTICE.txt):
      - A copy of the CC-BY-NC-SA-4.0 license text
      - "Models provided by the OpenVPI Community / DiffSinger Community"
      - Link: https://openvpi.github.io/vocoders/

- name: qixuan
  role: acoustic
  engine: diffsinger
  license: CC-BY-NC-SA-4.0
  source: https://openvpi.github.io/voicebanks/  # publisher
  notes: Community female JP voicebank, paired with openvpi NSF-HiFiGAN.

- name: renri
  role: acoustic
  engine: diffsinger
  license: CC-BY-NC-SA-4.0
  source: https://openvpi.github.io/voicebanks/

- name: nyaru
  role: acoustic
  engine: diffsinger
  license: CC-BY-NC-SA-4.0
  source: https://openvpi.github.io/voicebanks/

- name: mitsudate
  role: acoustic
  engine: diffsinger
  license: CC-BY-NC-SA-4.0
  source: https://openvpi.github.io/voicebanks/
```

## Output wav licensing (NC opt-in path)

When the user passes `--accept-nc`, the resulting `.wav` is the user's copyright, and CC's public position is that **CC license conditions on the model do not automatically extend to model outputs** ([Creative Commons FAQ](https://creativecommons.org/faq/#do-i-need-permission-to-use-a-cc-licensed-work-as-input-to-train-an-ai-model), [Using CC-licensed Works for AI Training, 2025](https://creativecommons.org/wp-content/uploads/2025/05/Using-CC-licensed-Works-for-AI-Training.pdf)). The conservative practical reading:

- The output `.wav` itself is **not** automatically CC-BY-NC-SA-4.0.
- The **act of running** NC weights is bound by the NC clause; commercial generation/distribution requires the self-train path.
- Fine-tuning the openvpi vocoder or acoustic weights produces a derivative work that **does** inherit CC-BY-NC-SA-4.0 by the ShareAlike clause. The self-train path below avoids this by training the acoustic from scratch and using an MIT-licensed vocoder.

## Self-train path (Apache-2.0, OSS-clean redistribution — **not $0**)

For users who need OSS-clean weights (commercial, redistribution, etc.), the surveyed path is:

  1. Train an acoustic model using the **openvpi/DiffSinger** training code (Apache-2.0) on user-owned audio data.
  2. Pair with one of the MIT vocoders below behind an adapter that converts DiffSinger's mel format to the vocoder's expected format:
     - `nvidia/bigvgan_v2_44khz_128band_512x` (MIT, 44.1 kHz, 128-bin general mel)
     - `charactr/vocos-mel-24khz` (MIT, 24 kHz, 80-bin mel)
     - `patriotyk/vocos-mel-hifigan-compat-44100khz` (MIT, 44.1 kHz HiFiGAN-compat)

**Cost reality** (the $0 invariant covers inference only, not self-train):

- GPU: 8 GB+ VRAM (RTX 3060 or rented Colab Pro / A100 hours).
- Labeled audio: 1–3 hours of singing data with phoneme alignment and pitch curve annotation.
- Training time: ~12–48 GPU-hours for a usable acoustic model.
- Engineering: the mel-format adapter (from DiffSinger F0-conditioned NSF mel to BigVGAN/Vocos 80/128-bin mel) is **a Stage 3+ contribution path**, not bundled in Stage 1/2.

vocaboot's Stage 1/2 scope is the wrapper + verify gate. The self-train path is documented as a future direction, not a one-command workflow.

## Engine pivot (deferred, not rejected)

Stage 0 ckpt research was scoped to DiffSinger format. If Stage 0 is re-opened against another SVS framework, the candidates surveyed at that time were:

| Framework | License (framework) | License (default weights) | Action |
|---|---|---|---|
| nnsvs/nnsvs | MIT | per-voicebank, Hayagriva / NIT-SONG070 etc. | Re-Stage-0 first if DiffSinger fails to deliver Stage 1 step 2 |
| RVC v2 | MIT | base trained on VCTK, commercial-friendly | Already slated for Stage 3 SVC fallback (not a Stage 1 SVS pivot) |
| Seed-VC | MIT | base trained on multiple datasets | Voice-conversion only; not an SVS engine |

The current decision is **DiffSinger maintained, dual-path adopted**. A later engine pivot is permitted but requires a fresh Stage 0 round.

## Why this exists

Plan G (a prior failed iteration of this project) attempted to fine-tune a model from scratch and shipped its own weights. That path is structurally forbidden here — `vocaboot` is a *wrapper*, not a *trainer*. The registry exists so that when the wrapper changes hands, the supply chain of weights is auditable.
