# vocaboot — Quality Gate (operational definition)

> User intent (R16, immutable): 「絶対に最高の完成」「将来クロードコード経由でボカロを簡単に作れる世界を作りたい」「ターミナルでボーカロイドを操作できる」「汎用性高く」「課金はしたくない」「オープンソース」

This document is the operational answer to *"what does «最高の完成» mean for vocaboot?"*. "最高" cannot be left as a phantom adjective applied to a roadmap; it has to bind to **measurable thresholds with bootstrap CIs (R5)** that the existing `agent_verify` gate (or its Stage 2/3 extensions) can evaluate.

The gate is intentionally tiered, not single-pass: every tier corresponds to a different question, and the project advances by clearing the next tier rather than by clearing one global cutoff. Skipping tiers is forbidden because a Tier-N+1 claim that has not cleared Tier-N is a phantom claim (R17 §4).

## Tier ladder

| Tier | Question | Metrics | Threshold | Where wired | Stage |
|---|---|---|---|---|---|
| **1 — rings** | does the pipeline output a non-silent, harmonically structured signal at all? | `f0_stability` (`metrics.py`, `direction="lower_better"`), `hnr` (`metrics.py`, `direction="higher_better"`) | `f0_stability` CI < 0.02 (jitter < 2 %) **and** `hnr` CI > 0 dB | `agent_verify.run` (`agent_verify.py:79-151`) | Stage 1 — **closed 2026-05-12** |
| **2 — voice-like** | does the output sound like a *voice* (formant structure + timbre), distinguishable from the synthetic 4-partial oscillator? | + `mcd` (mel cepstral distortion, dB, `direction="lower_better"`), `wavlm_cosine` (WavLM-base self-similarity to a reference voice, `direction="higher_better"`) | `mcd` ≤ 500 dB (CI upper bound, librosa-MFCC scale calibrated 2026-05-12 from canary distribution), `wavlm_cosine` ≥ 0.60 (CI lower bound) | `metrics.py` (`mcd`, step 3a) + `metrics.py` (`wavlm_cosine` block-bootstrap wrapper, step 3b) → `profile_match.py` (`WavLMSpeakerSimilarity` SoT, 3-tunable frozen dataclass); wire in `agent_verify.py` via `reference_voice: VoiceProfile \| None` kwarg; production wire in `pipeline.run` + CLI `vocaboot synth --reference-profile` | Stage 2 — **closed 2026-05-13 (R14 round-10: N=5 multi-canary + threshold_ci field + B2 probe ACCEPT; dormant phantoms tracked for round-11)** |
| **3 — target-quality** | does the output match a *specific target voice* the user has profiled? | + `speaker_cosine` (ECAPA-TDNN cosine to user target), `vuv_f1` (voiced/unvoiced F1 vs reference) | `speaker_cosine` ≥ 0.80, `vuv_f1` ≥ 0.95 | **planned** — `[verify-target]` extra | Stage 3 |
| **4 — out of scope** | does the output pass *subjective MOS* by blind raters? | MOS ≥ 4.0 (ITU-T Rec. P.800 5-point), n ≥ 10 raters, bootstrap CI lower bound ≥ 3.5 | **explicitly out of vocaboot's scope** — see "Subjective MOS is out of scope" below | n/a | — |

Verdicts inside every tier follow the existing `Verdict` semantics (`agent_verify.py:46-49`):

- **APPROVE** — every numeric metric is *determined* and its CI is strictly on the passing side of the threshold.
- **REJECT** — at least one numeric metric is *determined* and its CI is strictly on the failing side.
- **REVIEW** — at least one metric is undetermined (CI straddles the threshold) and none are REJECT-determined. The museum (`museum.py:101`) gets the entry so a human can adjudicate.

Tier progression is monotonic: a Stage N PR must demonstrate Tier-N APPROVE on a corpus (not a single sample) before the gate is considered cleared at that tier.

## Metric definitions

### Tier 1 — already wired

`f0_stability` and `hnr` are implemented and tested today; this section is for cross-reference.

* **`f0_stability`** — mean of `|Δf0/f0|` over voiced frames, computed from `pyworld.harvest` + `pyworld.stonemask`. `direction="lower_better"` (R14 round-6 migration — the prior sign-flip storing `−|Δf0/f0|` was retired in step 3a); threshold `0.02` means tolerated jitter ≤ 2 % cycle-to-cycle. Bootstrap CI (`metrics.py` `bootstrap_ci`) at α = 0.05.
* **`hnr`** — `−10·log10(mean(ap²))` where `ap` is pyworld's per-frame aperiodicity (`pw.d4c`). Threshold 0 dB; CI strictly above means signal is harmonically dominant on the voiced portion.

Both metrics gracefully degrade to *undetermined* when `voiced.sum() < 4` (silence or all-noise), surfaced via `MetricResult.is_determined == False` (`metrics.py:37-40`).

### Tier 2 — to wire in Stage 2

**`mcd` (Mel Cepstral Distortion, dB)** — standard objective measure for voice synthesis quality (Kominek, Schultz & Black, *Synthesizer voice quality of new languages calibrated with mean mel cepstral distortion*, SLTU 2008, https://www.isca-archive.org/sltu_2008/kominek08_sltu.html). For a synthesized signal `ŷ` and reference `y`, both converted to 25-coefficient mel-cepstra (`MFCC_1..MFCC_25`, DTW-aligned):

```
MCD(y, ŷ) = (10 / ln 10) · sqrt( 2 · Σ_{k=1..24} (c_k(y) − c_k(ŷ))² )   [dB, averaged over frames]
```

The 6.0 dB threshold was a **literature placeholder** taken from speech-TTS calibration (Kominek et al. 2008) that applied to native MCEP (HTK / pysptk-style mel-cepstrum). vocaboot's MCD reads ``librosa.feature.mfcc`` output — log-mel-power on a Slaney mel filterbank, DCT-orthonormal — which scales an order of magnitude differently. **R17 audit closure 2026-05-12** observed the canary distribution as ``synth-4partial vs tier2`` ≈ 1172 dB (CI [1071, 1259]) versus ``tier2-canary-alt vs tier2 reference`` ≈ 293 dB (CI [222, 367]), with a 704 dB separability gap; the default threshold lands at **500 dB** inside that gap (``metrics._MCD_THRESHOLD_DEFAULT_DB`` carries the rationale in-source). The literature 6.0 dB number is preserved as historical context only.

**Bootstrap CI for `mcd`** (R14 round-6 critic): cepstra are frame-by-frame time-correlated, so the plain percentile bootstrap (`metrics.bootstrap_ci`, used for `f0_stability` / `hnr`) under-estimates CI on MCD. `mcd` must call `bootstrap_ci(..., block_size=25)` (≈ 250 ms at 10 ms hop) — the block bootstrap path respects time correlation by re-sampling contiguous frame blocks rather than i.i.d. frames.

**`wavlm_cosine`** — cosine similarity between WavLM-base (Chen et al., *WavLM: Large-Scale Self-Supervised Pre-Training for Full Stack Speech Processing*, IEEE/ACM TASLP 2022) frame-level embeddings of the output and a reference voice. Cutoff 0.60 separates "voice-like" from "synthetic-like" outputs on the LibriTTS-derived benchmarks WavLM authors report. This metric lives behind the `[verify-similarity]` extra (declared in `pyproject.toml`; weights pinned by sha256 in `docs/ckpt_registry.md`).

**Direction convention (R14 round-4, 2026-05-12)** — `MetricResult` carries a `direction: Literal["higher_better", "lower_better"]` field. `mcd` is naturally "smaller is better" (0 dB is perfect identity) and stores its dB reading directly with `direction="lower_better"`; `wavlm_cosine` and the Tier 1 metrics store their score with `direction="higher_better"`. `MetricResult.passes` branches on `direction`: a `higher_better` metric passes when CI lower bound > threshold, a `lower_better` metric passes when CI upper bound < threshold. This replaces the prior sign-flip trick (`value = -mcd_db`, `threshold = -6.0`) — that workaround was sign-uniform inside the aggregator but lied to museum entries and CLI display, where a stored `-4.3` was meaningless and a user reading a REJECT entry could not recover the underlying dB without knowing the convention. The verdict aggregator (`agent_verify.py:_numeric_verdict`) reads `direction` and stays sign-uniform without the negation.

### Tier 3 — to wire in Stage 3

**`speaker_cosine`** — cosine similarity between ECAPA-TDNN (Desplanques et al., *ECAPA-TDNN: Emphasized Channel Attention, Propagation and Aggregation in TDNN Based Speaker Verification*, Interspeech 2020) utterance embeddings of the output and the user's profiled target voice. 0.80 corresponds to the speaker verification EER operating point on VoxCeleb 1 verification.

**`vuv_f1`** — voiced/unvoiced classification F1 score frame-by-frame, vs. a reference. 0.95 is the conventional pass cutoff for production TTS/SVS.

### Tier 4 — explicitly out of scope

Subjective MOS (ITU-T Rec. P.800) requires a panel of blind human raters and per-sample listening sessions. This is incompatible with vocaboot's `$0 invariant` (CPU-only, no API budget) and with the project's R15 / "禁句: 商用クオリティ" constraint (recorded in the failure museum). vocaboot will *not* gate on subjective MOS internally; downstream researchers who need MOS evaluations should run them against vocaboot outputs externally and contribute results back as datasets, not as gating thresholds in this repo.

## Wiring contract

Every Tier 2+ metric must implement:

1. The same `MetricResult` shape (`metrics.py:27-44`) — `name`, `value`, `ci_low`, `ci_high`, `threshold`, `direction` (added in Stage 2 step 3a per R14 round-4).
2. Bootstrap CI per R5 — use `bootstrap_ci` (`metrics.py:47-66`). Time-correlated samples (frame-by-frame MFCC for MCD, frame-by-frame WavLM embeddings for `wavlm_cosine`) **must** pass `block_size=25` (≈ 250 ms at 10 ms hop) to engage the block bootstrap path; plain percentile bootstrap on time-correlated data violates R5 by under-estimating CI width.
3. `is_determined` true ⇔ CI strictly excludes the threshold; otherwise surface as REVIEW, not silent APPROVE.
4. Lazy import of heavy deps (torch / transformers / onnxruntime model weights) behind the appropriate `[verify-similarity]` / `[verify-target]` extra so the Stage 1 install footprint does not regress.

`agent_verify.run` (`agent_verify.py:79-151`) accepts `reference_voice: VoiceProfile | None = None` (Stage 2 step 3b, R14 round-9 Path α, 2026-05-12). When `None`, the gate runs the Tier 1 metrics only (`f0_stability` + `hnr`) — back-compat with Stage 1 callers. When a `schema_version=2` `VoiceProfile` is supplied, the gate additionally runs `metrics.mcd` against `reference_voice.mfcc_cepstra` and `metrics.wavlm_cosine` against `reference_voice.wavlm_embedding`. The candidate (output) features are extracted by `profile_match.extract_for_verify` (`profile_match.py`) — a lightweight WavLM + MFCC pair that skips f0 / spectral-centroid / sha256 since `agent_verify` already computes f0_stability + hnr from the same audio. **Why `VoiceProfile`, not `Path`** (R14 round-4 decision): a `Path` parameter would let `agent_verify` trigger `profile_match.build` (torch + transformers + WavLM weights) when called, breaking the import-safe property the verify module currently has. The `Path → VoiceProfile` conversion is the responsibility of the CLI / `pipeline.run` layer — they are also the only layers that pass through the `audio_ingest` consent gate, so the R15 audit trail is preserved and Stage 2.5's MCP boundary invariant (Claude cannot manufacture a `VoiceProfile`) holds without an extra runtime check. The verdict aggregator (`_numeric_verdict`, `agent_verify.py:65-76`) reads `MetricResult.direction` so the mixed `higher_better` / `lower_better` tuple shares one passes-resolution path.

## CI canary

Tier 1 canary is already in place: `test_stage1_synthetic_smoke_wav_end_to_end` (`tests/test_stage1_pipeline.py`) produces a 5-second wav and verifies non-zero RMS + 44.1 kHz duration. Stage 2 must land a parallel canary that:

- runs the wired Tier 2 metrics on the same synthetic-acoustic output,
- asserts that the **synthetic** output **fails** Tier 2 (`mcd` > 6 dB OR `wavlm_cosine` < 0.60) — i.e. Tier 2 distinguishes synthetic from voice, not just "rings",
- and that a recorded human voice sample **passes** Tier 2.

Without the second arm, Tier 2 is provably non-discriminating and the gate is phantom.

## Open thresholds (to be re-validated on Stage 2 corpus)

These cutoffs are starting points cited from the literature for *general* TTS/SVS; vocaboot's CC-BY-NC-SA-4.0-restricted DiffSinger corpus is likely to need recalibration. **Contract** (R14 round-6 — promoted from TODO to closure-blocking): Stage 2 step 3b closure must produce a per-metric calibration histogram (synthetic 4-partial REJECT arm distribution + PR1b canary APPROVE arm distribution) and adjust thresholds so the two arms separate with bootstrap-CI margin to spare. A literature threshold that allows the synthetic 4-partial to pass is a failed gate (R17 §4 phantom against `docs/stage_2.md` criterion #1) and blocks merge.

**Histogram observed at closure** (R17 audit 2026-05-12, ``tests/test_stage2_pipeline.py::test_tier2_distinguishes_synthetic_from_voice`` emits the live values to stdout under ``pytest -s``):

| Arm | metric | value | CI | threshold | passes |
|---|---|---|---|---|---|
| synth 4-partial vs `tier2_reference_ja.wav` | `mcd` | 1172 dB | [1071, 1259] | 500 | ✗ (REJECT contribution) |
| synth 4-partial vs `tier2_reference_ja.wav` | `wavlm_cosine` | 0.357 | [0.350, 0.362] | 0.60 | ✗ (REJECT contribution) |
| `tier2_canary_ja_alt.wav` vs `tier2_reference_ja.wav` profile | `mcd` | 293 dB | [222, 367] | 500 | ✓ (APPROVE contribution) |
| `tier2_canary_ja_alt.wav` vs `tier2_reference_ja.wav` profile | `wavlm_cosine` | 0.92 | [0.76, 0.91] | 0.60 | ✓ (APPROVE contribution) |

Both arms remain in their respective sides of the threshold with bootstrap-CI margin (mcd separation 704 dB; wavlm_cosine separation 0.40). The APPROVE-arm canary is a **different OpenJTalk-HMM sentence** by the same speaker — not an identity tautology against the reference, which the pre-audit version inadvertently was.

## Why this exists

This file replaces the phantom phrase "Stage 2-4 で最高の完成に近づく" that previously lived only in chat. Without operational thresholds:

- A future "Stage 2 closed" claim would be unverifiable (R17 §3).
- The CI cannot regression-test quality (only structure / control flow).
- "最高" drifts into whatever the most recent PR happens to do well.

The tier ladder makes the user's "絶対に最高の完成" claim bindable: vocaboot reaches "最高" when every output clears Tier 3 with bootstrap-CI margin to spare. Tier 4 (subjective MOS) is acknowledged but ceded to downstream research because it cannot be gated in CI on a `$0` budget.
