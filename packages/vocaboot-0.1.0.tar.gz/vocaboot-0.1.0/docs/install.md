# Installing vocaboot

vocaboot is a Python ≥ 3.10 package. Install from source until a 0.1.0
PyPI release lands.

## Baseline install

```bash
git clone https://github.com/hinanohart/vocaboot.git
cd vocaboot
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -e '.[verify,dev]'
pytest -q
```

The baseline install brings in `pyworld`, `scipy`, `pytest`, `ruff`, `mypy`
and the core SVS dependencies. It is enough to run the Stage 1 smoke and
the Tier 1 (`f0_stability`, `score_grammar`) verify gate.

## Optional extras

| extra                | adds                                                  | when to install                     |
|----------------------|-------------------------------------------------------|-------------------------------------|
| `diffsinger`         | `onnxruntime`, `librosa`, `scipy`                     | Stage 1 DiffSinger acoustic path    |
| `verify`             | `pyworld`, `scipy`                                    | Tier 1 verify metrics               |
| `verify-similarity`  | `transformers`, `torch`, `torchaudio`, `librosa`, `huggingface_hub` | Tier 2 verify (`mcd`, `wavlm_cosine`) |
| `svc`                | `torch`, `torchaudio`                                 | Stage 3 SVC (deferred to 0.2.0)     |
| `mcp`                | `mcp`                                                 | Stage 2.5 MCP server                |
| `dev`                | `pytest`, `ruff`, `mypy`                              | contributor workflow                |

Combine extras with comma-separation: `pip install -e '.[verify-similarity,dev]'`.

## WavLM weights (verify-similarity)

The first `vocaboot verify` (or `pytest`) that exercises `wavlm_cosine`
downloads ~360 MB of WavLM-base weights to:

```
~/.cache/vocaboot/models/wavlm-base/
```

The download is sha256-pinned (`docs/ckpt_registry.md`). Upstream license
is **CC-BY-SA-3.0** (`microsoft/UniSpeech/LICENSE`). vocaboot consumes
the weights from the cache only; nothing is re-published. See `NOTICE` for
the attribution chain.

To pre-fetch the weights (e.g. before going offline):

```python
from huggingface_hub import snapshot_download
snapshot_download(
    repo_id="microsoft/wavlm-base",
    revision="efa81aae7ff777e464159e0f877d54eac5b84f81",
    local_dir="~/.cache/vocaboot/models/wavlm-base/",
)
```

## Tier 2 reference voice canary

The CC-BY-3.0 reference voice (`examples/voice/tier2_reference_ja.wav`,
~80 KB) is bundled in the repo. For self-regeneration on a maintainer
host (Linux/WSL):

```bash
sudo apt install open-jtalk hts-voice-nitech-jp-atr503-m001 \
                 open-jtalk-mecab-naist-jdic
bash scripts/regenerate_tier2_canary_voice_arm.sh
```

See `examples/voice/README.md` for the full canary expansion and
attribution.

## Platform notes

- **Linux (ubuntu / WSL)**: baseline tested under Python 3.10/3.11/3.12.
- **macOS**: baseline tested under Python 3.12.
- **Windows (native)**: baseline supported. The reference-voice
  *regeneration* recipe is Linux-only because it uses `apt`; the bundled
  wav is bit-reproducible and works on Windows for verify.

## Privacy / consent

vocaboot refuses to ingest user audio under any of these conditions:

1. Path contains a substring in `DEFAULT_PROTECTED_SUBSTRINGS`
   (`src/vocaboot/privacy.py`) or the user's
   `~/.config/vocaboot/protected_patterns.txt`.
2. `ingest()` is called without `consent_no_store=True,
   consent_no_redistribute=True`.

The defaults are designed so that the most common accident path (running
`vocaboot ingest` on the user's own reference voice without thinking about
it) raises a `ProtectedReferenceError` or `ConsentRequiredError` and stops
the pipeline before any persisted artefact records the input.

To add **project-specific protected patterns** without committing them to
the OSS source tree, create
`~/.config/vocaboot/protected_patterns.txt` (one substring per line) — the
guard's `_load_user_patterns()` merges them into the default list at
runtime.
