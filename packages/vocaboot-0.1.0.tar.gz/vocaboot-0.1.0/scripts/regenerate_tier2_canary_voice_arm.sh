#!/usr/bin/env bash
# Regenerate the Tier 2 multi-canary voice-arm wavs (R14 round-10, 2026-05-12).
#
# Background: round-9 closed Stage 2 step 3b on a SINGLE canary (tier2_canary_ja_alt.wav).
# The 5-体並列 audit (analyst + critic + verifier) judged this an R5 violation —
# "Δ 主張前に bootstrap CI / SE 必須". A 1-sample anchor's frame bootstrap CI does
# not include inter-sample SE, so the threshold can be calibrated only point-wise.
# Round-10 widens the voice arm to N=5 sentences (same HMM speaker, varied prosody)
# so the calibration distribution captures sentence-within-speaker variance.
#
# Same HMM voice as tier2_reference_ja.wav (nitech-jp-atr503-m001, CC-BY-3.0) is
# used intentionally: mixing speakers (e.g. nitech + mei) would make wavlm_cosine
# to the reference profile inversely depend on speaker identity rather than on
# the "is this a real voice?" question we are gating in Tier 2. Multi-speaker
# bank evaluation is deferred to Stage 3 (target-quality / speaker_cosine).
#
# Outputs (alongside existing tier2_canary_ja_alt.wav):
#   examples/voice/tier2_canary_voice_02.wav
#   examples/voice/tier2_canary_voice_03.wav
#   examples/voice/tier2_canary_voice_04.wav
#   examples/voice/tier2_canary_voice_05.wav
#
# Together with tier2_canary_ja_alt.wav (= voice_01 in the calibration set), this
# gives N=5 voice-arm samples for bootstrap CI on the APPROVE threshold.
#
# Human-maintainer-only path: CI never runs this; CI consumes the stored wavs.
#
# Usage:
#   bash scripts/regenerate_tier2_canary_voice_arm.sh

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$REPO_ROOT/examples/voice"
SAMPLE_RATE=16000

cd "$REPO_ROOT"
mkdir -p "$OUT_DIR"

if ! command -v open_jtalk >/dev/null 2>&1; then
    echo "ERROR: open_jtalk command not found. See scripts/regenerate_tier2_reference.sh for install hints." >&2
    exit 1
fi

VOICE=$(dpkg -L hts-voice-nitech-jp-atr503-m001 2>/dev/null | grep '\.htsvoice$' | head -n 1 || true)
if [[ -z "${VOICE}" || ! -f "${VOICE}" ]]; then
    echo "ERROR: hts-voice-nitech-jp-atr503-m001 voice file not found." >&2
    exit 1
fi

DIC="/var/lib/mecab/dic/open-jtalk/naist-jdic"
if [[ ! -d "${DIC}" ]]; then
    echo "ERROR: NAIST jdic directory not found at /var/lib/mecab/dic/open-jtalk/naist-jdic." >&2
    exit 1
fi

# 4 new sentences. Chosen to give prosodic / length variation while staying in
# common-vocabulary, present-tense Japanese (avoids dialect / archaic forms).
# Existing tier2_canary_ja_alt.wav holds the 1st calibration sample
# ("今日はいい天気ですね") and remains a separate maintainer responsibility.
declare -a SENTENCES=(
    "明日は雨が降るかもしれません"
    "私は東京に住んでいます"
    "コンピューターは便利な道具です"
    "新しい本を買いました"
)
declare -a OUT_FILES=(
    "tier2_canary_voice_02.wav"
    "tier2_canary_voice_03.wav"
    "tier2_canary_voice_04.wav"
    "tier2_canary_voice_05.wav"
)

echo "Using HMM voice: ${VOICE}" >&2
echo "Sample rate: ${SAMPLE_RATE} Hz mono" >&2
echo "" >&2

for i in "${!SENTENCES[@]}"; do
    OUT="$OUT_DIR/${OUT_FILES[$i]}"
    TEXT="${SENTENCES[$i]}"
    echo "[${i}] Generating ${OUT_FILES[$i]} <- \"${TEXT}\"" >&2
    echo "${TEXT}" | open_jtalk -x "${DIC}" -m "${VOICE}" -s "${SAMPLE_RATE}" -ow "${OUT}"
    if [[ ! -f "${OUT}" ]]; then
        echo "ERROR: open_jtalk did not produce ${OUT}" >&2
        exit 1
    fi
done

echo "" >&2
echo "Per-wav 4-axis pin (paste into docs/ckpt_registry.md):" >&2
echo "" >&2

for fname in "${OUT_FILES[@]}"; do
    OUT="$OUT_DIR/$fname"
    SHA=$(sha256sum "${OUT}" | awk '{print $1}')
    SIZE=$(stat -c '%s' "${OUT}")
    # Read RIFF WAVE header for sample rate (offset 24, 4 bytes little-endian)
    # and data chunk size (offset 40, 4 bytes), then derive duration as
    # data_bytes / (sample_rate * bytes_per_sample * channels).
    SR=$(python3 -c "
import struct
with open('${OUT}', 'rb') as f:
    f.seek(24)
    sr = struct.unpack('<I', f.read(4))[0]
print(sr)
")
    DUR=$(python3 -c "
import wave
with wave.open('${OUT}', 'rb') as w:
    print(f'{w.getnframes() / w.getframerate():.3f}')
")
    echo "- name: ${fname%.wav}"
    echo "  role: reference-anchor"
    echo "  engine: verify-similarity"
    echo "  license: CC-BY-3.0"
    echo "  sha256: ${SHA}"
    echo "  size_bytes: ${SIZE}"
    echo "  sample_rate: ${SR}"
    echo "  duration_seconds: ${DUR}"
    echo "  source: regenerate locally via scripts/regenerate_tier2_canary_voice_arm.sh"
    echo ""
done

echo "Done. ${#OUT_FILES[@]} wavs generated." >&2
