#!/usr/bin/env bash
# Regenerate examples/voice/tier2_canary_ja_alt.wav from Open JTalk + nitech voice.
#
# Sibling of regenerate_tier2_reference.sh — same HMM voice (nitech-jp-atr503-m001,
# CC-BY-3.0), DIFFERENT sentence. Purpose: Tier 2 canary Arm 2 needs a "second
# recorded voice" so the APPROVE arm of docs/stage_2.md criterion #1 measures
# "recorded voice → APPROVE" rather than the trivial "ref vs ref → identity"
# tautology. Using the same HMM speaker keeps wavlm_cosine high (> 0.60 expected)
# and MCD low (< 6.0 dB expected) — i.e. APPROVE for "similar real voice",
# distinct from the synthetic 4-partial REJECT arm. R17 audit 2026-05-12 closure.
#
# Human-maintainer-only path: CI never runs this; CI consumes the stored wav.
#
# Usage:
#   bash scripts/regenerate_tier2_canary_alt.sh

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$REPO_ROOT/examples/voice"
OUT="$OUT_DIR/tier2_canary_ja_alt.wav"
TEXT="今日はいい天気ですね"
SAMPLE_RATE=16000

cd "$REPO_ROOT"
mkdir -p "$OUT_DIR"

if ! command -v open_jtalk >/dev/null 2>&1; then
    echo "ERROR: open_jtalk command not found. See scripts/regenerate_tier2_reference.sh for install hints." >&2
    exit 1
fi

VOICE=$(dpkg -L hts-voice-nitech-jp-atr503-m001 2>/dev/null | grep '\.htsvoice$' | head -n 1 || true)
if [[ -z "${VOICE}" || ! -f "${VOICE}" ]]; then
    echo "ERROR: hts-voice-nitech-jp-atr503-m001 voice file not found." >&2
    exit 1
fi

DIC="/var/lib/mecab/dic/open-jtalk/naist-jdic"
if [[ ! -d "${DIC}" ]]; then
    echo "ERROR: NAIST jdic directory not found at /var/lib/mecab/dic/open-jtalk/naist-jdic." >&2
    exit 1
fi

echo "Generating ${OUT} (${SAMPLE_RATE} Hz mono) ..." >&2
echo "Using voice: ${VOICE}" >&2

echo "${TEXT}" | open_jtalk -x "${DIC}" -m "${VOICE}" -s "${SAMPLE_RATE}" -ow "${OUT}"

if [[ ! -f "${OUT}" ]]; then
    echo "ERROR: open_jtalk completed but ${OUT} was not produced." >&2
    exit 1
fi

python3 - "$OUT" <<'PY'
import hashlib
import pathlib
import sys
import wave

p = pathlib.Path(sys.argv[1])
data = p.read_bytes()
with wave.open(str(p), "rb") as w:
    sample_rate = w.getframerate()
    n_frames = w.getnframes()
    duration = n_frames / sample_rate
    channels = w.getnchannels()
    sample_width = w.getsampwidth()

print()
print(f"=== {p.name} 4-axis pin (paste into docs/ckpt_registry.md tier2-canary-alt-voice) ===")
print(f"  sha256:           {hashlib.sha256(data).hexdigest()}")
print(f"  size_bytes:       {len(data)}")
print(f"  sample_rate:      {sample_rate}")
print(f"  duration_seconds: {duration:.6f}")
print()
print(f"--- additional integrity (for sanity) ---")
print(f"  channels:         {channels}")
print(f"  sample_width:     {sample_width} bytes ({sample_width * 8} bit)")
print(f"  n_frames:         {n_frames}")
PY
