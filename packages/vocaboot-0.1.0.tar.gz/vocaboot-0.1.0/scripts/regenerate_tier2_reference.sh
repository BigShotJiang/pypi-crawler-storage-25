#!/usr/bin/env bash
# Regenerate examples/voice/tier2_reference_ja.wav from Open JTalk + nitech voice.
#
# Human-maintainer-only path (R14 round-8 architecture verdict, 2026-05-12):
# CI never runs this — CI consumes the stored wav as source of truth. This
# script exists so a maintainer can rebuild the canary when the upstream
# license / rights-holder / file-integrity audit requires a re-roll. After
# successful regeneration the 4-axis pin (sha256 + size_bytes + sample_rate
# + duration_seconds) is printed to stdout for hand-commit into
# `docs/ckpt_registry.md` `tier2-reference-voice` block.
#
# Dependencies (apt, Ubuntu / Debian; universe + multiverse required):
#   open-jtalk                          # BSD-3-clause synthesis engine
#   hts-voice-nitech-jp-atr503-m001     # CC-BY-3.0 voice data (NIT + Tokyo Tech)
#   open-jtalk-mecab-naist-jdic         # NAIST Japanese dictionary
#
# Usage:
#   bash scripts/regenerate_tier2_reference.sh

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$REPO_ROOT/examples/voice"
OUT="$OUT_DIR/tier2_reference_ja.wav"
TEXT="音声合成のサンプルです"
SAMPLE_RATE=16000

cd "$REPO_ROOT"
mkdir -p "$OUT_DIR"

# --- dependency verification --------------------------------------------------

if ! command -v open_jtalk >/dev/null 2>&1; then
    cat >&2 <<'EOF'
ERROR: open_jtalk command not found.

Install with:
    sudo apt install -y open-jtalk hts-voice-nitech-jp-atr503-m001 open-jtalk-mecab-naist-jdic

(Both `universe` and `multiverse` apt sources must be enabled — the voice
data deb is in multiverse because the upstream HTK training toolkit has a
non-free EULA. NIT released the trained voice data under CC-BY-3.0; the
multiverse classification reflects Debian's caution about the training
provenance, not the voice data redistribution rights.)
EOF
    exit 1
fi

VOICE=$(dpkg -L hts-voice-nitech-jp-atr503-m001 2>/dev/null | grep '\.htsvoice$' | head -n 1 || true)
if [[ -z "${VOICE}" || ! -f "${VOICE}" ]]; then
    cat >&2 <<'EOF'
ERROR: hts-voice-nitech-jp-atr503-m001 voice file not found.

Install with:
    sudo apt install -y hts-voice-nitech-jp-atr503-m001
EOF
    exit 1
fi

DIC="/var/lib/mecab/dic/open-jtalk/naist-jdic"
if [[ ! -d "${DIC}" ]]; then
    cat >&2 <<'EOF'
ERROR: NAIST jdic directory not found at /var/lib/mecab/dic/open-jtalk/naist-jdic.

Install with:
    sudo apt install -y open-jtalk-mecab-naist-jdic
EOF
    exit 1
fi

# --- generate -----------------------------------------------------------------

echo "Generating ${OUT} (${SAMPLE_RATE} Hz mono) ..." >&2
echo "Using voice: ${VOICE}" >&2
echo "Using dict:  ${DIC}" >&2

echo "${TEXT}" | open_jtalk -x "${DIC}" -m "${VOICE}" -s "${SAMPLE_RATE}" -ow "${OUT}"

if [[ ! -f "${OUT}" ]]; then
    echo "ERROR: open_jtalk completed but ${OUT} was not produced." >&2
    exit 1
fi

# --- 4-axis pin emission (stdout, copy into docs/ckpt_registry.md) ------------

python3 - "$OUT" <<'PY'
import hashlib
import pathlib
import sys
import wave

p = pathlib.Path(sys.argv[1])
data = p.read_bytes()
with wave.open(str(p), "rb") as w:
    sample_rate = w.getframerate()
    n_frames = w.getnframes()
    duration = n_frames / sample_rate
    channels = w.getnchannels()
    sample_width = w.getsampwidth()

print()
print(f"=== {p.name} 4-axis pin (paste into docs/ckpt_registry.md tier2-reference-voice) ===")
print(f"  sha256:           {hashlib.sha256(data).hexdigest()}")
print(f"  size_bytes:       {len(data)}")
print(f"  sample_rate:      {sample_rate}")
print(f"  duration_seconds: {duration:.6f}")
print()
print(f"--- additional integrity (for sanity) ---")
print(f"  channels:         {channels}")
print(f"  sample_width:     {sample_width} bytes ({sample_width * 8} bit)")
print(f"  n_frames:         {n_frames}")
PY
