"""Stage 1 pipeline integration tests.

The synth + agent-verify wires are stubs until step 5 finishes wiring the
ONNX session and the agent runners. These tests pin down the *control flow*
contract: errors fan out cleanly, license + privacy guards fire before any
engine call, the verify gate's signature stays Round 26-safe, and the CLI
exit codes match the pipeline verdicts.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from vocaboot import pipeline
from vocaboot.agent_verify import Verdict
from vocaboot.cli import main
from vocaboot.license_check import LicenseRefusedError
from vocaboot.privacy import ProtectedReferenceError
from vocaboot.svs_engine import EngineNotWiredError

EXAMPLES = Path(__file__).resolve().parent.parent / "examples"
SHORT_DS = EXAMPLES / "short.ds"


def _write_dummy_ckpt(tmp_path: Path, name: str = "voice.onnx") -> Path:
    p = tmp_path / name
    p.write_bytes(b"")
    return p


def test_stage1_privacy_guard_fires_first(tmp_path) -> None:
    """A protected ckpt path must be refused before any engine call."""
    bad = _write_dummy_ckpt(tmp_path, name="protected_voice_voice.onnx")
    with pytest.raises(ProtectedReferenceError):
        pipeline.run(voice=bad, score_path=SHORT_DS, out=tmp_path / "out.wav")


def test_stage1_privacy_guard_also_covers_score_path(tmp_path) -> None:
    """C-ア2 fix: score_path is also protected (R15 leak prevention)."""
    ckpt = _write_dummy_ckpt(tmp_path)
    bad_score = tmp_path / "protected_voice_song.ds"
    bad_score.write_text(SHORT_DS.read_text(encoding="utf-8"), encoding="utf-8")
    with pytest.raises(ProtectedReferenceError):
        pipeline.run(voice=ckpt, score_path=bad_score, out=tmp_path / "out.wav")


def test_privacy_rejects_fullwidth_nfkc_variant(tmp_path) -> None:
    """C-ア3 fix: NFKC-normalized full-width spelling must not bypass the guard."""
    from vocaboot.privacy import is_protected_path

    # 'ｐｒｏｔｅｃｔｅｄ＿ｖｏｉｃｅ' (full-width latin) → NFKC → 'protected_voice'
    assert is_protected_path(tmp_path / "ｐｒｏｔｅｃｔｅｄ＿ｖｏｉｃｅ_voice.onnx")
    # Mixed-case ASCII still matches.
    assert is_protected_path(tmp_path / "PROTECTED_VOICE_voice.onnx")
    # Innocuous names still pass.
    assert not is_protected_path(tmp_path / "generic_voice.onnx")


def test_stage1_license_check_refuses_nc_without_opt_in(tmp_path) -> None:
    """CC-BY-NC-SA must be refused when --accept-nc is not set."""
    ckpt = _write_dummy_ckpt(tmp_path)
    with pytest.raises(LicenseRefusedError):
        pipeline.run(
            voice=ckpt,
            score_path=SHORT_DS,
            out=tmp_path / "out.wav",
            ckpt_license="CC-BY-NC-SA-4.0",
            accept_nc=False,
        )


def test_stage1_engine_stub_raises_until_step5(tmp_path) -> None:
    """After privacy + license pass, the engine stub must surface its own error."""
    ckpt = _write_dummy_ckpt(tmp_path)
    with pytest.raises(EngineNotWiredError):
        pipeline.run(voice=ckpt, score_path=SHORT_DS, out=tmp_path / "out.wav")


def test_cli_engine_stub_exits_with_code_3(tmp_path) -> None:
    """CLI must translate EngineNotWiredError into a non-zero exit so CI catches it."""
    ckpt = _write_dummy_ckpt(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["synth", "--voice", str(ckpt), "--score", str(SHORT_DS),
         "--out", str(tmp_path / "out.wav")],
    )
    assert result.exit_code == 3, result.output


def test_cli_does_not_expose_verify_flag(tmp_path) -> None:
    """Step 5e: ``--verify`` flag is gone (Round-26 LLM-as-judge fragility).

    OSS adopters must not see a Claude-dependent verify path in the help.
    """
    runner = CliRunner()
    help_result = runner.invoke(main, ["synth", "--help"])
    assert help_result.exit_code == 0
    assert "--verify" not in help_result.output

    ckpt = _write_dummy_ckpt(tmp_path)
    result = runner.invoke(
        main,
        ["synth", "--voice", str(ckpt), "--score", str(SHORT_DS),
         "--out", str(tmp_path / "out.wav")],
    )
    # Exit 3 (engine stub) means we got past privacy + license + got into
    # the synth step. No `verify =` banner line either (flag removed).
    assert "verify" not in result.output.lower() or "--verify" not in result.output
    assert result.exit_code == 3, result.output


def test_cli_review_and_reject_use_distinct_exit_codes(tmp_path, monkeypatch) -> None:
    """M1/M5 fix: REVIEW (5) and REJECT (6) must be distinguishable to CI."""
    import numpy as np

    from vocaboot import agent_verify as av
    from vocaboot import svs_engine

    ckpt = _write_dummy_ckpt(tmp_path)

    def fake_synth(score, voice, **_):
        return np.zeros(int(44100 * score.total_seconds), dtype=np.float32)

    monkeypatch.setattr(svs_engine, "synth", fake_synth)

    def make_gate(verdict: av.Verdict):
        def fake_run(_audio, *, score, ckpt, reference_voice=None):
            return av.GateResult(
                verdict=verdict,
                metrics=(),
                advisories=(),
            )

        return fake_run

    runner = CliRunner()

    monkeypatch.setattr(av, "run", make_gate(av.Verdict.REVIEW))
    out_path = tmp_path / "out.wav"
    review_result = runner.invoke(
        main,
        ["synth", "--voice", str(ckpt), "--score", str(SHORT_DS),
         "--out", str(out_path),
         "--failures-root", str(tmp_path / "_failures_review")],
    )
    assert review_result.exit_code == 5, review_result.output

    monkeypatch.setattr(av, "run", make_gate(av.Verdict.REJECT))
    reject_result = runner.invoke(
        main,
        ["synth", "--voice", str(ckpt), "--score", str(SHORT_DS),
         "--out", str(out_path),
         "--failures-root", str(tmp_path / "_failures_reject")],
    )
    assert reject_result.exit_code == 6, reject_result.output


def test_stage1_score_path_round_trip(tmp_path) -> None:
    """Confirm the locked-in examples/short.ds parses through input.load_ds."""
    from vocaboot.input import load_ds

    score = load_ds(SHORT_DS)
    assert score.total_seconds == pytest.approx(5.0)
    assert score.lang == "ja"
    assert len(score.ph_seq) == len(score.ph_dur) == 10
    assert len(score.note_seq) == len(score.note_dur) == len(score.note_slur) == 5


def test_stage1_run_with_skip_returns_review(tmp_path, monkeypatch) -> None:
    """With --no-agent-verify and a fake synth, the run returns REVIEW."""
    import numpy as np

    from vocaboot import svs_engine

    ckpt = _write_dummy_ckpt(tmp_path)

    def fake_synth(score, voice, **_):
        return np.zeros(int(44100 * score.total_seconds), dtype=np.float32)

    monkeypatch.setattr(svs_engine, "synth", fake_synth)
    result = pipeline.run(
        voice=ckpt,
        score_path=SHORT_DS,
        out=tmp_path / "out.wav",
        skip_agent_verify=True,
    )
    assert result.wav_path.exists()
    assert result.verdict is Verdict.REVIEW


def test_agent_verify_run_signature_is_numeric_only() -> None:
    """Step 5e: ``mode`` / ``pipeline_files`` / ``agent_a`` are gone.

    The signature must take only ``audio_path`` (positional) plus
    ``score`` and ``ckpt`` (keyword-only, kept for Stage 2 advisory).
    """
    import inspect

    from vocaboot import agent_verify

    sig = inspect.signature(agent_verify.run)
    params = sig.parameters
    for required in ("score", "ckpt"):
        assert required in params, f"agent_verify.run missing {required!r}"
        assert params[required].kind is inspect.Parameter.KEYWORD_ONLY
    # Symbols removed in step 5e.
    for removed in ("mode", "pipeline_files"):
        assert removed not in params, f"agent_verify.run still has {removed!r}"
    assert not hasattr(agent_verify, "VerifyMode")
    assert not hasattr(agent_verify, "aggregate")


def test_museum_scrubs_path_values(tmp_path) -> None:
    """C-ア2 fix: museum.archive_failure must not persist full file paths."""
    from vocaboot import museum

    secret_path = tmp_path / "protected_voice_private.ds"
    secret_path.write_text("private content", encoding="utf-8")
    entry = museum.archive_failure(
        root=tmp_path / "_failures",
        reason="test_scrub",
        detail={"score_path": str(secret_path), "note": "freeform string is fine"},
    )
    payload = json.loads((entry / "metadata.json").read_text(encoding="utf-8"))
    scrubbed = payload["detail"]["score_path"]
    assert isinstance(scrubbed, dict)
    assert scrubbed["basename"] == "protected_voice_private.ds"
    assert len(scrubbed["sha256"]) == 64
    # Full path must not appear anywhere in the persisted JSON.
    metadata_files = list((tmp_path / "_failures").rglob("metadata.json"))
    assert metadata_files, "metadata.json must exist"
    metadata_text = metadata_files[0].read_text(encoding="utf-8")
    assert str(secret_path) not in metadata_text
    # Non-path string is left untouched.
    assert payload["detail"]["note"] == "freeform string is fine"


def test_stage1_synthetic_refuses_without_accept_nc(tmp_path) -> None:
    """ア-C1 fix: --voice synthetic uses the NC vocoder, so accept_nc must be required."""
    with pytest.raises(LicenseRefusedError, match="non-commercial"):
        pipeline.run(
            voice="synthetic",
            score_path=SHORT_DS,
            out=tmp_path / "out.wav",
            ckpt_license="CC0-1.0",  # the synthetic path bypasses ckpt_license normally
            accept_nc=False,
            skip_agent_verify=True,
        )


def test_svs_engine_synth_direct_refuses_without_accept_nc() -> None:
    """ア-C1' (defense-in-depth): Python API bypass of pipeline must also be blocked.

    A 3rd-party caller that imports vocaboot.svs_engine.synth directly must
    hit the NC gate **before** any optional-dep (librosa) is touched — the
    refusal is deterministic regardless of which extras are installed.
    """
    from vocaboot import svs_engine
    from vocaboot.input import load_ds

    score = load_ds(SHORT_DS)
    with pytest.raises(LicenseRefusedError, match="non-commercial"):
        svs_engine.synth(score, "synthetic")  # default accept_nc=False


def test_load_vocoder_refuses_without_accept_nc() -> None:
    """ア-CRIT ね-3: inner choke point must refuse independently of synth().

    A caller that bypasses synth() and reaches ``_load_vocoder`` directly
    (e.g. for a custom vocoder pipeline) still hits the NC gate.
    """
    from vocaboot.svs_engine import _load_vocoder

    with pytest.raises(LicenseRefusedError, match="non-commercial"):
        _load_vocoder()  # default accept_nc=False; no librosa/onnxruntime needed


def test_svs_engine_synth_direct_with_accept_nc(tmp_path) -> None:
    """The accept_nc=True path either runs (vocoder present) or surfaces
    a clean VocoderNotFoundError — but not a LicenseRefusedError.

    Skipped in minimal-deps envs where librosa is absent.
    """
    pytest.importorskip("librosa")
    pytest.importorskip("onnxruntime")

    from vocaboot import svs_engine
    from vocaboot.input import load_ds
    from vocaboot.svs_engine import VocoderNotFoundError

    score = load_ds(SHORT_DS)
    try:
        audio = svs_engine.synth(score, "synthetic", accept_nc=True)
    except VocoderNotFoundError:
        pytest.skip("vocoder cache not populated; smoke unreachable")
    else:
        assert audio.ndim == 1
        assert audio.size > 0


def test_stage1_synthetic_smoke_wav_end_to_end(tmp_path) -> None:
    """step 5a-4: --voice synthetic must produce a non-trivial wav via the vocoder.

    This is the Stage 1 "actually rings" milestone: no ckpt download required,
    just the registry-pinned vocoder in ~/.cache/vocaboot.
    """
    pytest.importorskip("librosa")
    pytest.importorskip("onnxruntime")
    pytest.importorskip("soundfile")
    import soundfile as sf

    from vocaboot import pipeline
    from vocaboot.agent_verify import Verdict
    from vocaboot.svs_engine import vocoder_path

    if not vocoder_path().is_file():
        pytest.skip(
            "registry-pinned NSF-HiFiGAN vocoder not on disk; "
            "this test requires --accept-nc smoke setup"
        )

    out = tmp_path / "smoke.wav"
    result = pipeline.run(
        voice="synthetic",
        score_path=SHORT_DS,
        out=out,
        ckpt_license="CC-BY-NC-SA-4.0",
        accept_nc=True,
        skip_agent_verify=True,
    )
    assert result.wav_path.is_file()
    assert result.verdict is Verdict.REVIEW  # skip_agent_verify=True

    audio, sr = sf.read(result.wav_path)
    assert sr == 44100
    assert audio.ndim == 1
    duration = audio.shape[0] / sr
    # The short.ds score is locked to 5.0 s; tolerate one vocoder frame of jitter.
    assert 4.95 < duration < 5.05, f"unexpected duration {duration}"

    import numpy as np

    rms = float(np.sqrt((audio.astype(np.float32) ** 2).mean()))
    assert rms > 0.005, f"smoke wav rms={rms} is suspiciously silent"


def test_museum_scrub_handles_cyclic_reference(tmp_path) -> None:
    """ア-CRIT-1: self / transitive / list cycles must not crash the museum."""
    from vocaboot import museum

    # Self-cycle.
    cyclic: dict[str, object] = {"name": "cycle_test"}
    cyclic["self"] = cyclic
    entry = museum.archive_failure(
        root=tmp_path / "_failures",
        reason="self_cycle",
        detail=cyclic,
    )
    payload = json.loads((entry / "metadata.json").read_text(encoding="utf-8"))
    assert payload["detail"]["self"] == "<cycle>"

    # Transitive cycle (A → B → A) inside dicts.
    a: dict[str, object] = {"tag": "a"}
    b: dict[str, object] = {"tag": "b"}
    a["b"] = b
    b["a"] = a
    entry2 = museum.archive_failure(
        root=tmp_path / "_failures",
        reason="transitive_cycle",
        detail=a,
    )
    p2 = json.loads((entry2 / "metadata.json").read_text(encoding="utf-8"))
    assert p2["detail"]["b"]["a"] == "<cycle>"

    # List-cycle: a list contains itself.
    cyclic_list: list[object] = ["x"]
    cyclic_list.append(cyclic_list)
    entry3 = museum.archive_failure(
        root=tmp_path / "_failures",
        reason="list_cycle",
        detail={"items": cyclic_list},
    )
    p3 = json.loads((entry3 / "metadata.json").read_text(encoding="utf-8"))
    assert p3["detail"]["items"][1] == "<cycle>"

    # DAG (shared but not cyclic) must NOT be flagged as cycle.
    shared = {"label": "shared"}
    parent = {"a": shared, "b": shared}
    entry4 = museum.archive_failure(
        root=tmp_path / "_failures",
        reason="dag_no_cycle",
        detail=parent,
    )
    p4 = json.loads((entry4 / "metadata.json").read_text(encoding="utf-8"))
    assert p4["detail"]["a"] == {"label": "shared"}
    assert p4["detail"]["b"] == {"label": "shared"}


def test_agent_verify_silence_yields_review(tmp_path) -> None:
    """Silence has no voiced frames → both metrics are undetermined → REVIEW.

    Step 5e replaced the AGENT-mode short-circuit with the single
    numeric path; the silent-wav case still must surface as REVIEW so
    CI flags it for inspection rather than passing it as APPROVE.
    """
    pytest.importorskip("pyworld")
    pytest.importorskip("soundfile")
    import numpy as np
    import soundfile as sf

    from vocaboot import agent_verify as av
    from vocaboot.input import load_ds

    score = load_ds(SHORT_DS)
    ckpt = _write_dummy_ckpt(tmp_path)

    wav = tmp_path / "x.wav"
    sf.write(wav, np.zeros(44100, dtype=np.float32), 44100, subtype="PCM_16")

    result = av.run(wav, score=score, ckpt=ckpt)
    assert result.verdict is av.Verdict.REVIEW
    # Both metrics are undetermined on silence — surfaced via REVIEW.
    assert len(result.metrics) == 2
    assert not any(m.is_determined for m in result.metrics)


def test_museum_scrub_recurses_into_nested_structures(tmp_path) -> None:
    """onset-2: nested dict/list values that are path-like must also be scrubbed."""
    from vocaboot import museum

    secret = tmp_path / "protected_voice_inner.ds"
    secret.write_text("nested-secret", encoding="utf-8")
    secret_other = tmp_path / "another_secret.wav"
    secret_other.write_text("x", encoding="utf-8")

    detail = {
        "outer": {
            "score_path": str(secret),
            "metrics": [
                {"name": "f0", "value": 1.0},
            ],
        },
        "extra_paths": [str(secret), str(secret_other)],
        "plain_string": "not a path",
    }
    entry = museum.archive_failure(
        root=tmp_path / "_failures",
        reason="test_nested",
        detail=detail,
    )
    payload = json.loads((entry / "metadata.json").read_text(encoding="utf-8"))
    inner = payload["detail"]["outer"]["score_path"]
    assert isinstance(inner, dict) and inner["basename"] == "protected_voice_inner.ds"
    assert len(inner["sha256"]) == 64

    paths_list = payload["detail"]["extra_paths"]
    assert all(isinstance(item, dict) and "basename" in item for item in paths_list)

    # plain_string field's key is not path-like → untouched
    assert payload["detail"]["plain_string"] == "not a path"

    # metrics list of dicts must keep its primitives untouched (only path-like keys scrub)
    assert payload["detail"]["outer"]["metrics"][0] == {"name": "f0", "value": 1.0}


def test_cli_demo_refuses_without_accept_nc(tmp_path) -> None:
    """OSS-1 step 5c: ``vocaboot demo`` must refuse without --accept-nc.

    The bundled smoke path is NC-licensed; auto-accepting the NC clause
    on the user's behalf is legal exposure. Exit 7 = license refused.
    """
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["demo", "--out", str(tmp_path / "out.wav"),
         "--failures-root", str(tmp_path / "_failures")],
    )
    assert result.exit_code == 7, result.output
    assert "--accept-nc is mandatory" in result.output


def test_cli_demo_default_score_resolves(tmp_path) -> None:
    """``vocaboot demo --accept-nc`` (no --score) must locate examples/short.ds.

    Stops short of running the vocoder when the cache is empty so the test
    works in minimal-deps envs — we just need to confirm the score path is
    resolved and the banner echoes it.
    """
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["demo", "--accept-nc",
         "--out", str(tmp_path / "out.wav"),
         "--no-agent-verify",
         "--failures-root", str(tmp_path / "_failures")],
    )
    # Two acceptable outcomes:
    #   - librosa/onnxruntime/vocoder all present → exit 0/5/6 (gate verdict)
    #   - missing optional deps or vocoder cache → exit 1 (unhandled exc)
    # In either case the resolved score path must appear in the banner.
    assert "short.ds" in result.output, result.output


def test_stage1_emits_license_notice_when_accept_nc(tmp_path, monkeypatch, capsys) -> None:
    """step 5d: accept_nc=True must write <out>.LICENSE_NOTICE.txt next to the wav.

    CC-BY-NC-SA-4.0 attribution is a per-run distributor obligation; a
    one-time README mention is insufficient. The notice must reach the
    user every time the NC vocoder is invoked.
    """
    import numpy as np

    from vocaboot import svs_engine

    def fake_synth(score, voice, **_):
        return np.zeros(int(44100 * score.total_seconds), dtype=np.float32)

    monkeypatch.setattr(svs_engine, "synth", fake_synth)

    out = tmp_path / "smoke.wav"
    result = pipeline.run(
        voice="synthetic",
        score_path=SHORT_DS,
        out=out,
        ckpt_license="CC-BY-NC-SA-4.0",
        accept_nc=True,
        skip_agent_verify=True,
    )
    assert result.wav_path.exists()
    assert result.license_notice_path is not None
    assert result.license_notice_path.exists()
    assert result.license_notice_path == out.with_name(out.name + ".LICENSE_NOTICE.txt")

    notice_text = result.license_notice_path.read_text(encoding="utf-8")
    for required in (
        "CC-BY-NC-SA-4.0",
        "OpenVPI Community",
        "DiffSinger Community",
        "https://github.com/openvpi/vocoders",
        "a3e26672a8c655e3faf65f31cb4339a7fbca7758ba86be9af89e03dced7c3fa4",
    ):
        assert required in notice_text, f"LICENSE_NOTICE.txt missing literal {required!r}"

    # stdout banner summary (4 lines): provider + source + full-notice path.
    captured = capsys.readouterr()
    assert "OpenVPI Community" in captured.out
    assert str(result.license_notice_path) in captured.out


def test_stage1_no_notice_when_default_tier_ckpt(tmp_path, monkeypatch) -> None:
    """Negative: a license-clean (CC0) ckpt must NOT emit a NC notice.

    The notice carries CC-BY-NC-SA-4.0 attribution; emitting it for a
    default-tier ckpt would be both misleading and a R17 defect. This
    nails down the future ckpt path (post-Stage-0-result-B reopen)
    where ``accept_nc=False`` is the normal happy path.
    """
    import numpy as np

    from vocaboot import svs_engine

    def fake_synth(score, voice, **_):
        return np.zeros(int(44100 * score.total_seconds), dtype=np.float32)

    monkeypatch.setattr(svs_engine, "synth", fake_synth)
    ckpt = _write_dummy_ckpt(tmp_path)

    out = tmp_path / "clean.wav"
    result = pipeline.run(
        voice=ckpt,
        score_path=SHORT_DS,
        out=out,
        ckpt_license="CC0-1.0",
        accept_nc=False,
        skip_agent_verify=True,
    )
    assert result.wav_path.exists()
    assert result.license_notice_path is None
    sidecar = out.with_name(out.name + ".LICENSE_NOTICE.txt")
    assert not sidecar.exists(), "default-tier ckpt must not produce a NC notice"


def test_emit_attribution_notice_stream_override(tmp_path) -> None:
    """Unit test: ``emit_attribution_notice`` writes summary to a passed-in stream."""
    import io

    from vocaboot import license_check

    out_wav = tmp_path / "unit.wav"
    out_wav.write_bytes(b"\x00\x00")  # placeholder; we only care about the sidecar
    buf = io.StringIO()
    notice_path = license_check.emit_attribution_notice(out_wav, stream=buf)
    assert notice_path == out_wav.with_name("unit.wav.LICENSE_NOTICE.txt")
    assert notice_path.is_file()
    summary = buf.getvalue()
    assert summary.startswith("vocaboot: NSF-HiFiGAN vocoder is CC-BY-NC-SA-4.0")
    assert "OpenVPI Community" in summary
    assert str(notice_path) in summary


def test_resolve_license_notice_text_raises_when_missing(tmp_path, monkeypatch) -> None:
    """Unit test: bundled-resource resolver surfaces a clear error if _data is gone.

    Simulates a corrupted install (no wheel ``_data/LICENSE_NOTICE.txt``
    *and* no source-tree fallback). The error must be actionable.
    """
    from vocaboot import _resources

    class _MissingRef:
        def is_file(self) -> bool:
            return False

    class _Files:
        def joinpath(self, _name: str):
            return _MissingRef()

    fake_ir_files = lambda _pkg: _Files()  # noqa: E731
    monkeypatch.setattr("importlib.resources.files", fake_ir_files)

    with pytest.raises(_resources.BundledResourceNotFoundError, match="Reinstall vocaboot"):
        _resources.bundled_resource_path(
            "_data/LICENSE_NOTICE.txt",
            dev_tree_fallback=tmp_path / "nonexistent.txt",
        )


def test_cli_demo_writes_license_notice(tmp_path, monkeypatch) -> None:
    """``vocaboot demo --accept-nc`` must also persist LICENSE_NOTICE.txt.

    End-to-end through the CLI layer to confirm the attribution wire
    survives click + pipeline.run integration. We fake svs_engine.synth
    to avoid pulling in librosa/onnxruntime in minimal-deps envs.
    """
    import numpy as np

    from vocaboot import svs_engine

    def fake_synth(score, voice, **_):
        return np.zeros(int(44100 * score.total_seconds), dtype=np.float32)

    monkeypatch.setattr(svs_engine, "synth", fake_synth)

    out = tmp_path / "demo.wav"
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["demo", "--accept-nc",
         "--out", str(out),
         "--no-agent-verify",
         "--failures-root", str(tmp_path / "_failures")],
    )
    notice = out.with_name(out.name + ".LICENSE_NOTICE.txt")
    assert notice.is_file(), result.output
    assert "OpenVPI Community" in notice.read_text(encoding="utf-8")


def test_cli_demo_score_override(tmp_path) -> None:
    """``vocaboot demo --score X`` must honor the override (test friction guard).

    Without override-ability the default ``out.wav`` would race across tests
    and the bundled score would be unmodifiable for negative-path tests.
    """
    # Reuse the locked-in smoke score by file path; only the override path
    # is exercised, not synth itself.
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["demo", "--accept-nc",
         "--score", str(SHORT_DS),
         "--out", str(tmp_path / "out.wav"),
         "--no-agent-verify",
         "--failures-root", str(tmp_path / "_failures")],
    )
    # Banner must echo the override path.
    assert str(SHORT_DS) in result.output, result.output


def test_stage1_failures_root_defaults_to_local_dir(tmp_path, monkeypatch) -> None:
    """M2 fix: failures_root=None must NOT silently skip the museum."""
    import numpy as np

    from vocaboot import agent_verify as av
    from vocaboot import pipeline as s1
    from vocaboot import svs_engine

    ckpt = _write_dummy_ckpt(tmp_path)

    def fake_synth(score, voice, **_):
        return np.zeros(int(44100 * score.total_seconds), dtype=np.float32)

    def fake_run(_audio, *, score, ckpt, reference_voice=None):
        return av.GateResult(
            verdict=av.Verdict.REJECT,
            metrics=(),
            advisories=(),
        )

    monkeypatch.setattr(svs_engine, "synth", fake_synth)
    monkeypatch.setattr(av, "run", fake_run)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(s1, "DEFAULT_FAILURES_ROOT", tmp_path / "_failures")

    result = pipeline.run(
        voice=ckpt,
        score_path=SHORT_DS,
        out=tmp_path / "out.wav",
        failures_root=None,
    )
    assert result.verdict is Verdict.REJECT
    assert any((tmp_path / "_failures").iterdir()), "REJECT must create a museum entry"
