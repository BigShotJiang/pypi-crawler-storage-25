"""Stage 2 profile_match tests.

Two test bands:

  * **Always-on**: dataclass shape, immutability, JSON sidecar round-trip,
    Protocol runtime_checkable behavior, WavLM weight-loader gates. These
    run on a vanilla install (no ``[verify-similarity]`` extra needed) — the
    embedding can be synthesized directly into ``VoiceProfile`` bytes.
  * **Gated**: end-to-end ``build`` → ``save`` → ``load`` → ``match_distance``
    identity (criterion 4) and the cross-speaker discrimination canary
    (criterion 2). Skipped only when transformers / torch / librosa /
    soundfile / pyworld are absent **or** the WavLM-base weights have not
    been downloaded to the cache path yet (the registry pin landed in
    PR1a — clean CI runs without ``[verify-similarity]`` still skip cleanly).
"""

from __future__ import annotations

import base64
import json
from pathlib import Path

import numpy as np
import pytest

from vocaboot import profile_match
from vocaboot.metrics import MetricResult
from vocaboot.profile_match import (
    _PINNED_WAVLM_SHA256,
    _PROFILE_SCHEMA_VERSION,
    F0Stats,
    SpeakerSimilarityProtocol,
    VoiceProfile,
    WavLMHashMismatchError,
    WavLMNotFoundError,
    WavLMSpeakerSimilarity,
)


def _synthetic_profile(
    *,
    t_frames: int = 8,
    embed_dim: int = 16,
    seed: int = 0,
) -> VoiceProfile:
    """Build a VoiceProfile from a deterministic synthetic embedding.

    Avoids the WavLM dependency for storage-shape tests. ``embed_dim=16``
    instead of WavLM's 768 keeps the JSON sidecar fixture small.
    """
    rng = np.random.default_rng(seed)
    embedding = rng.standard_normal((t_frames, embed_dim)).astype(np.float32)
    return VoiceProfile(
        wavlm_embedding_bytes=embedding.tobytes(),
        wavlm_embedding_shape=(t_frames, embed_dim),
        wavlm_embedding_dtype=str(embedding.dtype),
        f0_stats=F0Stats(
            mean_hz=220.0,
            std_hz=5.0,
            min_hz=210.0,
            max_hz=230.0,
            voiced_fraction=0.85,
        ),
        spectral_centroid_mean=1800.0,
        duration_seconds=3.2,
        source_sha256="0" * 64,
    )


def test_voice_profile_field_set_matches_spec() -> None:
    """All Stage 2 spec fields must be present on the dataclass."""
    profile = _synthetic_profile()
    for field in (
        "wavlm_embedding_bytes",
        "wavlm_embedding_shape",
        "wavlm_embedding_dtype",
        "f0_stats",
        "spectral_centroid_mean",
        "duration_seconds",
        "source_sha256",
        "schema_version",
    ):
        assert hasattr(profile, field), f"VoiceProfile missing field {field!r}"
    assert profile.schema_version == _PROFILE_SCHEMA_VERSION


def test_voice_profile_embedding_property_reconstructs_bytes() -> None:
    """The ``wavlm_embedding`` property must rebuild the original ndarray exactly."""
    rng = np.random.default_rng(123)
    embedding = rng.standard_normal((6, 32)).astype(np.float32)
    profile = VoiceProfile(
        wavlm_embedding_bytes=embedding.tobytes(),
        wavlm_embedding_shape=(6, 32),
        wavlm_embedding_dtype=str(embedding.dtype),
        f0_stats=F0Stats(0.0, 0.0, 0.0, 0.0, 0.0),
        spectral_centroid_mean=0.0,
        duration_seconds=1.0,
        source_sha256="abc",
    )
    reconstructed = profile.wavlm_embedding
    assert reconstructed.shape == (6, 32)
    assert reconstructed.dtype == np.float32
    np.testing.assert_array_equal(reconstructed, embedding)


def test_voice_profile_embedding_view_is_read_only() -> None:
    """``frombuffer`` returns a read-only view — mutation must raise.

    R3 immutability guarantee: even after reconstruction, the embedding
    cannot be silently mutated through a shared reference.
    """
    profile = _synthetic_profile()
    arr = profile.wavlm_embedding
    with pytest.raises(ValueError):
        arr[0, 0] = 999.0


def test_voice_profile_is_frozen_dataclass() -> None:
    """frozen=True must forbid field rebinding."""
    from dataclasses import FrozenInstanceError

    profile = _synthetic_profile()
    with pytest.raises(FrozenInstanceError):
        profile.spectral_centroid_mean = 0.0  # type: ignore[misc]


def test_json_sidecar_round_trip_preserves_embedding(tmp_path: Path) -> None:
    """build → save → load must round-trip the embedding bit-exactly."""
    profile = _synthetic_profile(t_frames=12, embed_dim=24, seed=42)
    sidecar = tmp_path / "voice.json"
    profile_match.save(profile, sidecar)
    loaded = profile_match.load(sidecar)

    np.testing.assert_array_equal(loaded.wavlm_embedding, profile.wavlm_embedding)
    assert loaded.wavlm_embedding_shape == profile.wavlm_embedding_shape
    assert loaded.wavlm_embedding_dtype == profile.wavlm_embedding_dtype
    assert loaded.f0_stats == profile.f0_stats
    assert loaded.spectral_centroid_mean == profile.spectral_centroid_mean
    assert loaded.duration_seconds == profile.duration_seconds
    assert loaded.source_sha256 == profile.source_sha256
    assert loaded.schema_version == profile.schema_version


def test_json_sidecar_uses_base64_for_bytes(tmp_path: Path) -> None:
    """The on-disk format must be JSON-safe text (base64), not binary blob."""
    profile = _synthetic_profile()
    sidecar = tmp_path / "voice.json"
    profile_match.save(profile, sidecar)
    raw = sidecar.read_text(encoding="utf-8")
    payload = json.loads(raw)
    assert "wavlm_embedding_b64" in payload
    # base64 decode → equal length in bytes to the original.
    decoded = base64.b64decode(payload["wavlm_embedding_b64"].encode("ascii"))
    assert len(decoded) == len(profile.wavlm_embedding_bytes)


def test_json_sidecar_refuses_unknown_schema_version(tmp_path: Path) -> None:
    """A sidecar with a future schema_version must surface a clear error."""
    profile = _synthetic_profile()
    sidecar = tmp_path / "voice.json"
    profile_match.save(profile, sidecar)
    payload = json.loads(sidecar.read_text(encoding="utf-8"))
    payload["schema_version"] = 9999
    sidecar.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(ValueError, match="schema_version"):
        profile_match.load(sidecar)


def test_speaker_similarity_protocol_runtime_checkable() -> None:
    """WavLMSpeakerSimilarity must satisfy the Protocol structurally.

    The Protocol is declared ``runtime_checkable`` so Stage 3 SVC can
    isinstance-check its own implementation against the same contract.
    """
    sim = WavLMSpeakerSimilarity()
    assert isinstance(sim, SpeakerSimilarityProtocol)


def test_speaker_similarity_protocol_required_methods() -> None:
    """The protocol must declare exactly ``embed`` and ``mean_cosine``.

    These two method names are the Stage 3 SVC contract — renaming them
    silently would break the cross-stage compatibility guarantee.
    """
    assert hasattr(SpeakerSimilarityProtocol, "embed")
    assert hasattr(SpeakerSimilarityProtocol, "mean_cosine")


def test_wavlm_loader_refuses_missing_weights(monkeypatch, tmp_path) -> None:
    """``_load_wavlm_model`` must raise WavLMNotFoundError when the cache is empty."""
    monkeypatch.setenv("VOCABOOT_WAVLM_PATH", str(tmp_path / "absent.bin"))
    with pytest.raises(WavLMNotFoundError):
        profile_match._load_wavlm_model()


def test_wavlm_loader_refuses_hash_mismatch(monkeypatch, tmp_path) -> None:
    """Bytes whose sha256 does not match the registry pin must refuse to load.

    Defense-in-depth against a tampered weights file at the cache path — the
    loader hashes the bytes and raises :class:`WavLMHashMismatchError` before
    transformers ever sees them. This test fires the mismatch arm; the
    real-weights arm is exercised by the gated e2e tests below.
    """
    assert not _PINNED_WAVLM_SHA256.startswith("<"), (
        "_PINNED_WAVLM_SHA256 must be a real hash (PR1a landed the pin); "
        "if you intentionally reverted to the placeholder, restore the pin "
        "before running this test"
    )
    fake = tmp_path / "pytorch_model.bin"
    fake.write_bytes(b"not real weights")
    monkeypatch.setenv("VOCABOOT_WAVLM_PATH", str(fake))
    with pytest.raises(WavLMHashMismatchError) as excinfo:
        profile_match._load_wavlm_model()
    msg = str(excinfo.value)
    assert _PINNED_WAVLM_SHA256 in msg
    assert "have sha256" in msg


def test_wavlm_cache_path_env_override(monkeypatch, tmp_path) -> None:
    """``VOCABOOT_WAVLM_PATH`` must take precedence over the default cache."""
    target = tmp_path / "custom" / "wavlm.bin"
    monkeypatch.setenv("VOCABOOT_WAVLM_PATH", str(target))
    assert profile_match.wavlm_weights_path() == target

    monkeypatch.delenv("VOCABOOT_WAVLM_PATH", raising=False)
    default = profile_match.wavlm_weights_path()
    assert "wavlm-base" in str(default)
    assert "vocaboot" in str(default)


def test_cosine_helper_handles_zero_norm() -> None:
    """``_cosine`` must return 0 (not NaN) on zero-norm inputs."""
    z = np.zeros(8, dtype=np.float32)
    v = np.ones(8, dtype=np.float32)
    assert profile_match._cosine(z, v) == 0.0
    assert profile_match._cosine(v, z) == 0.0


def test_match_distance_undetermined_helper_brackets_threshold() -> None:
    """The undetermined-fallback must produce a CI straddling the threshold.

    Ensures ``MetricResult.is_determined`` is False — the aggregator will
    surface REVIEW rather than APPROVE/REJECT when audio is degenerate.
    """
    result = profile_match._undetermined_speaker_cosine(threshold=0.7)
    assert isinstance(result, MetricResult)
    assert not result.is_determined
    assert result.ci_low < 0.7 < result.ci_high


# ---------------------------------------------------------------------------
# Gated end-to-end tests. These require:
#   1. transformers / torch / librosa / soundfile / pyworld installed
#      ([verify-similarity] + [verify] extras).
#   2. WavLM-base weights downloaded and the registry sha256 placeholder
#      replaced with the real hash. Until the Stage 2 wire-in PR lands, these
#      skip cleanly so CI still passes.
# ---------------------------------------------------------------------------


def _wavlm_e2e_ready() -> bool:
    """True when end-to-end WavLM identity / discrimination tests can run.

    Uses ``__import__`` + ``ImportError`` rather than ``pytest.importorskip``:
    the latter raises ``pytest.skip()`` on a missing module, which would
    short-circuit the helper *before* our ``if not _wavlm_e2e_ready():``
    guard can decide, leaving the calling test silently skipped instead of
    surfacing a clear "deps missing" skip message.
    """
    for mod in ("transformers", "torch", "librosa", "soundfile", "pyworld"):
        try:
            __import__(mod)
        except ImportError:
            return False
    return profile_match.wavlm_weights_path().is_file()


def test_match_distance_round_trip_identity(tmp_path: Path) -> None:
    """Criterion 4: build → save → load → match against the same audio ⇒ cos ≥ 0.99."""
    if not _wavlm_e2e_ready():
        pytest.skip("WavLM weights / [verify-similarity] deps not available")

    pytest.importorskip("soundfile")
    import soundfile as sf

    sr = 16000
    t = np.arange(2 * sr) / sr
    signal = 0.3 * np.sin(2 * np.pi * 220.0 * t).astype(np.float32)
    wav_path = tmp_path / "identity.wav"
    sf.write(str(wav_path), signal, sr)

    profile = profile_match.build(wav_path)
    sidecar = tmp_path / "identity.json"
    profile_match.save(profile, sidecar)
    loaded = profile_match.load(sidecar)

    result = profile_match.match_distance(
        loaded,
        wav_path,
        n_resamples=64,
        rng=np.random.default_rng(0),
    )
    assert result.value >= 0.99, (
        f"round-trip identity must yield cos≥0.99, got {result.value}"
    )


def test_match_distance_discrimination_canary(tmp_path: Path) -> None:
    """Criterion 2: deliberately different speakers ⇒ cos ≤ 0.7.

    Two synthetic harmonic signals at distinct fundamentals stand in for
    distinct speakers when no recorded corpus is available locally.
    """
    if not _wavlm_e2e_ready():
        pytest.skip("WavLM weights / [verify-similarity] deps not available")

    pytest.importorskip("soundfile")
    import soundfile as sf

    sr = 16000
    t = np.arange(2 * sr) / sr
    signal_a = 0.3 * np.sin(2 * np.pi * 110.0 * t).astype(np.float32)
    signal_b = (
        0.3
        * (
            np.sin(2 * np.pi * 440.0 * t)
            + 0.5 * np.sin(2 * np.pi * 880.0 * t)
            + 0.3 * np.sin(2 * np.pi * 1320.0 * t)
        ).astype(np.float32)
    )

    a_path = tmp_path / "a.wav"
    b_path = tmp_path / "b.wav"
    sf.write(str(a_path), signal_a, sr)
    sf.write(str(b_path), signal_b, sr)

    profile_a = profile_match.build(a_path)
    result = profile_match.match_distance(
        profile_a, b_path, n_resamples=64, rng=np.random.default_rng(0)
    )
    assert result.value <= 0.7, (
        f"cross-speaker canary must yield cos≤0.7, got {result.value}"
    )


# ---------------------------------------------------------------------------
# Stage 2 step 3b — VoiceProfile schema_version=2 + mfcc_cepstra_* fields.
# R14 round-9 phantom 訂正: MFCC population lives in profile_match.build
# (not the previously phantom-referenced audio_ingest.build); these tests
# lock the dataclass shape, the optional-field semantics, the JSON
# round-trip including base64-encoded MFCC bytes, and the legacy schema=1
# rejection contract.
# ---------------------------------------------------------------------------


def _synthetic_profile_with_mfcc(
    *,
    t_frames: int = 8,
    embed_dim: int = 16,
    n_mfcc_frames: int = 50,
    n_mfcc_coef: int = 25,
    seed: int = 0,
) -> VoiceProfile:
    """Synthetic schema_version=2 profile with both WavLM and MFCC populated."""
    rng = np.random.default_rng(seed)
    embedding = rng.standard_normal((t_frames, embed_dim)).astype(np.float32)
    mfcc = rng.standard_normal((n_mfcc_frames, n_mfcc_coef)).astype(np.float32)
    return VoiceProfile(
        wavlm_embedding_bytes=embedding.tobytes(),
        wavlm_embedding_shape=(t_frames, embed_dim),
        wavlm_embedding_dtype=str(embedding.dtype),
        mfcc_cepstra_bytes=mfcc.tobytes(),
        mfcc_cepstra_shape=(n_mfcc_frames, n_mfcc_coef),
        mfcc_cepstra_dtype=str(mfcc.dtype),
        f0_stats=F0Stats(
            mean_hz=220.0,
            std_hz=5.0,
            min_hz=210.0,
            max_hz=230.0,
            voiced_fraction=0.85,
        ),
        spectral_centroid_mean=1800.0,
        duration_seconds=3.2,
        source_sha256="0" * 64,
    )


def test_voice_profile_has_mfcc_cepstra_fields() -> None:
    """schema_version=2 must carry mfcc_cepstra_bytes / shape / dtype."""
    profile = _synthetic_profile_with_mfcc()
    for field in (
        "mfcc_cepstra_bytes",
        "mfcc_cepstra_shape",
        "mfcc_cepstra_dtype",
    ):
        assert hasattr(profile, field), f"VoiceProfile missing field {field!r}"
    assert profile.schema_version == 2


def test_voice_profile_mfcc_cepstra_property_reconstructs_bytes() -> None:
    """The ``mfcc_cepstra`` property must rebuild the original ndarray exactly."""
    rng = np.random.default_rng(321)
    mfcc = rng.standard_normal((40, 25)).astype(np.float32)
    profile = VoiceProfile(
        wavlm_embedding_bytes=b"\x00" * 64,
        wavlm_embedding_shape=(2, 8),
        wavlm_embedding_dtype="float32",
        mfcc_cepstra_bytes=mfcc.tobytes(),
        mfcc_cepstra_shape=(40, 25),
        mfcc_cepstra_dtype=str(mfcc.dtype),
        f0_stats=F0Stats(0.0, 0.0, 0.0, 0.0, 0.0),
        spectral_centroid_mean=0.0,
        duration_seconds=1.0,
        source_sha256="abc",
    )
    reconstructed = profile.mfcc_cepstra
    assert reconstructed is not None
    assert reconstructed.shape == (40, 25)
    assert reconstructed.dtype == np.float32
    np.testing.assert_array_equal(reconstructed, mfcc)


def test_voice_profile_mfcc_cepstra_property_none_when_unpopulated() -> None:
    """Profile without mfcc_cepstra_* must yield ``None`` (not raise).

    Lets callers downgrade to WavLM-only verification rather than crash.
    The legacy schema_version=1 JSON path is rejected separately by
    :meth:`VoiceProfile.from_json_dict`, but in-memory partial profiles
    (e.g. WavLM-only test fixtures) remain constructible.
    """
    profile = _synthetic_profile()  # legacy fixture, mfcc_cepstra defaults None
    assert profile.mfcc_cepstra is None


def test_voice_profile_mfcc_cepstra_view_is_read_only() -> None:
    """``frombuffer`` returns a read-only view; mutation must raise."""
    profile = _synthetic_profile_with_mfcc()
    arr = profile.mfcc_cepstra
    assert arr is not None
    with pytest.raises(ValueError):
        arr[0, 0] = 999.0


def test_json_sidecar_round_trip_preserves_mfcc_cepstra(tmp_path: Path) -> None:
    """schema=2 build → save → load must round-trip MFCC bytes bit-exactly."""
    profile = _synthetic_profile_with_mfcc(seed=11)
    sidecar = tmp_path / "voice_v2.json"
    profile_match.save(profile, sidecar)
    loaded = profile_match.load(sidecar)
    assert loaded.schema_version == 2
    assert loaded.mfcc_cepstra_shape == profile.mfcc_cepstra_shape
    assert loaded.mfcc_cepstra_dtype == profile.mfcc_cepstra_dtype
    np.testing.assert_array_equal(loaded.mfcc_cepstra, profile.mfcc_cepstra)


def test_json_sidecar_carries_mfcc_b64_payload(tmp_path: Path) -> None:
    """On-disk format must encode MFCC bytes as base64 ASCII, not binary."""
    profile = _synthetic_profile_with_mfcc()
    sidecar = tmp_path / "voice_v2.json"
    profile_match.save(profile, sidecar)
    payload = json.loads(sidecar.read_text(encoding="utf-8"))
    assert "mfcc_cepstra_b64" in payload
    assert "mfcc_cepstra_shape" in payload
    assert "mfcc_cepstra_dtype" in payload
    decoded = base64.b64decode(payload["mfcc_cepstra_b64"].encode("ascii"))
    assert profile.mfcc_cepstra_bytes is not None
    assert len(decoded) == len(profile.mfcc_cepstra_bytes)


def test_json_sidecar_refuses_legacy_schema_v1(tmp_path: Path) -> None:
    """Legacy schema_version=1 sidecars must be rejected with a clear error.

    These predate the Stage 2 step 3b MFCC field set and therefore
    cannot serve as a Tier 2 MCD reference — rebuilding via
    ``vocaboot profile`` is required (pre-alpha acceptable break per
    R14 round-6 + ``docs/stage_2.md`` §Schema_version=2 contract).
    """
    profile = _synthetic_profile()
    sidecar = tmp_path / "voice_v1.json"
    profile_match.save(profile, sidecar)
    payload = json.loads(sidecar.read_text(encoding="utf-8"))
    payload["schema_version"] = 1
    sidecar.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(ValueError, match="schema_version") as excinfo:
        profile_match.load(sidecar)
    assert "rebuild" in str(excinfo.value).lower()


def test_voice_profile_rejects_partial_mfcc_triple() -> None:
    """schema=2 invariant: mfcc_cepstra_{bytes,shape,dtype} must be all-set or all-None.

    Allowing one to be ``None`` while another is set silently degrades the
    ``mfcc_cepstra`` property to ``None`` even though bytes are present —
    data loss masquerading as ``mfcc_cepstra=None``. The ``__post_init__``
    check is the in-memory mirror of ``from_json_dict``'s on-disk refusal,
    closing the previously-leaking constructor path (R17 audit 2026-05-12).
    """
    rng = np.random.default_rng(0)
    mfcc = rng.standard_normal((40, 25)).astype(np.float32)
    with pytest.raises(ValueError, match=r"all-None.*or all-set"):
        VoiceProfile(
            wavlm_embedding_bytes=b"\x00" * 64,
            wavlm_embedding_shape=(2, 8),
            wavlm_embedding_dtype="float32",
            mfcc_cepstra_bytes=mfcc.tobytes(),
            mfcc_cepstra_shape=None,  # partial: bytes set, shape None
            mfcc_cepstra_dtype=str(mfcc.dtype),
            f0_stats=F0Stats(0.0, 0.0, 0.0, 0.0, 0.0),
            spectral_centroid_mean=0.0,
            duration_seconds=1.0,
            source_sha256="abc",
        )


def test_json_sidecar_with_mfcc_b64_inconsistent_dtype_raises(tmp_path: Path) -> None:
    """A sidecar with mfcc_cepstra_b64 but no dtype must surface a clear error."""
    profile = _synthetic_profile_with_mfcc()
    sidecar = tmp_path / "voice_v2.json"
    profile_match.save(profile, sidecar)
    payload = json.loads(sidecar.read_text(encoding="utf-8"))
    payload["mfcc_cepstra_dtype"] = None
    sidecar.write_text(json.dumps(payload), encoding="utf-8")

    with pytest.raises(ValueError, match="mfcc_cepstra_dtype"):
        profile_match.load(sidecar)
