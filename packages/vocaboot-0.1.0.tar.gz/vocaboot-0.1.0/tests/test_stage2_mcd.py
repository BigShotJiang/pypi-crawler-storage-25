"""Stage 2 step 3a — ``metrics.mcd`` + ``MetricResult.direction`` + block bootstrap.

These tests are **dataset-independent** by design: MCD is exercised on
synthetic MFCC ndarrays so the suite runs without PR1b's reference audio
having landed. Step 3b adds the wired-in canary against piper-ja (or
Wikimedia/JVS fallback) in ``tests/test_stage2_pipeline.py``.
"""

from __future__ import annotations

import numpy as np
import pytest

from vocaboot.metrics import (
    _MCD_THRESHOLD_DEFAULT_DB,
    MetricResult,
    bootstrap_ci,
    mcd,
)

# ---------- MetricResult.direction field -----------------------------------


def test_metric_result_direction_default_is_higher_better() -> None:
    """Back-compat: existing call sites without ``direction=`` keep semantics."""
    r = MetricResult(name="x", value=1.0, ci_low=0.5, ci_high=1.5, threshold=0.0)
    assert r.direction == "higher_better"
    assert r.passes  # CI lower bound (0.5) > threshold (0.0)


def test_metric_result_lower_better_passes_when_ci_strictly_below() -> None:
    r = MetricResult(
        name="x",
        value=3.0,
        ci_low=2.0,
        ci_high=4.0,
        threshold=5.0,
        direction="lower_better",
    )
    assert r.is_determined
    assert r.passes


def test_metric_result_lower_better_fails_when_ci_strictly_above() -> None:
    r = MetricResult(
        name="x",
        value=7.0,
        ci_low=6.0,
        ci_high=8.0,
        threshold=5.0,
        direction="lower_better",
    )
    assert r.is_determined
    assert not r.passes


def test_metric_result_undetermined_never_passes_either_direction() -> None:
    for direction in ("higher_better", "lower_better"):
        r = MetricResult(
            name="x",
            value=float("nan"),
            ci_low=4.0,
            ci_high=6.0,
            threshold=5.0,
            direction=direction,
        )
        assert not r.is_determined
        assert not r.passes


# ---- MetricResult.threshold_ci (R14 round-10 R5-strict gate) ---------------
# verifier audit 2026-05-12 flagged the threshold_ci infrastructure as untested
# in tests/ — the field, the 2-sided strict passes branch, and the kwarg
# pass-through across mcd/wavlm_cosine/match_distance all exist in code but
# no test exercised the 2-sided path, leaving it as "infrastructure phantom"
# (R17 §4). These tests close that gap so the threshold_ci branch is gated.


def test_metric_result_threshold_ci_higher_better_passes_above_band() -> None:
    """``ci_low > threshold_ci[1]`` ⇒ ``higher_better`` passes 2-sided strict."""
    r = MetricResult(
        name="x",
        value=2.0,
        ci_low=1.5,
        ci_high=2.5,
        threshold=1.0,
        direction="higher_better",
        threshold_ci=(0.8, 1.2),
    )
    assert r.is_determined
    assert r.passes  # ci_low (1.5) > threshold_ci high (1.2)


def test_metric_result_threshold_ci_lower_better_passes_below_band() -> None:
    """``ci_high < threshold_ci[0]`` ⇒ ``lower_better`` passes 2-sided strict."""
    r = MetricResult(
        name="x",
        value=3.0,
        ci_low=2.0,
        ci_high=4.0,
        threshold=5.0,
        direction="lower_better",
        threshold_ci=(4.8, 5.2),
    )
    assert r.is_determined
    assert r.passes  # ci_high (4.0) < threshold_ci low (4.8)


def test_metric_result_threshold_ci_overlap_is_undetermined() -> None:
    """Metric CI overlapping the threshold band must report undetermined.

    Catches the case where a metric reading sits inside the threshold CI —
    the legacy 1-sided gate would have flipped on this depending on direction,
    but the 2-sided strict rule reports it as 'not gateable' (neither side
    of the band is clear).
    """
    r = MetricResult(
        name="x",
        value=5.0,
        ci_low=4.5,
        ci_high=5.5,
        threshold=5.0,
        direction="higher_better",
        threshold_ci=(4.8, 5.2),
    )
    assert not r.is_determined  # CI [4.5, 5.5] overlaps band [4.8, 5.2]
    assert not r.passes


def test_metric_result_threshold_ci_higher_better_fails_below_band() -> None:
    """``ci_high < threshold_ci[0]`` for ``higher_better`` ⇒ determined fail."""
    r = MetricResult(
        name="x",
        value=0.5,
        ci_low=0.4,
        ci_high=0.6,
        threshold=1.0,
        direction="higher_better",
        threshold_ci=(0.8, 1.2),
    )
    assert r.is_determined  # CI sits strictly below the band
    assert not r.passes     # 'higher_better' fail


def test_metric_result_threshold_ci_lower_better_fails_above_band() -> None:
    """``ci_low > threshold_ci[1]`` for ``lower_better`` ⇒ determined fail."""
    r = MetricResult(
        name="x",
        value=10.0,
        ci_low=9.0,
        ci_high=11.0,
        threshold=5.0,
        direction="lower_better",
        threshold_ci=(4.8, 5.2),
    )
    assert r.is_determined  # CI sits strictly above the band
    assert not r.passes     # 'lower_better' fail


def test_mcd_threshold_ci_kwarg_flows_to_metric_result() -> None:
    """``mcd(threshold_ci=...)`` must propagate into the returned MetricResult."""
    pytest.importorskip("librosa")
    rng = np.random.default_rng(0)
    a = _synthetic_mfcc(n_frames=200, rng=np.random.default_rng(1))
    b = _synthetic_mfcc(
        n_frames=200,
        rng=np.random.default_rng(2),
        offset=np.linspace(5.0, 10.0, 25),
    )
    result = mcd(
        a,
        b,
        threshold=10.0,
        threshold_ci=(9.5, 10.5),
        rng=rng,
    )
    assert result.threshold == 10.0
    assert result.threshold_ci == (9.5, 10.5)
    # CI strictly above 10.5 ⇒ determined fail (lower_better)
    if result.ci_low > 10.5:
        assert result.is_determined
        assert not result.passes


# ---------- bootstrap_ci with block_size -----------------------------------


def test_bootstrap_ci_block_size_returns_ordered_finite_ci() -> None:
    rng = np.random.default_rng(42)
    samples = rng.normal(loc=1.0, scale=0.1, size=200)
    lo, hi = bootstrap_ci(
        samples,
        n_resamples=300,
        rng=np.random.default_rng(0),
        block_size=25,
    )
    assert np.isfinite(lo) and np.isfinite(hi)
    assert lo < hi
    assert 0.9 < lo < 1.0 < hi < 1.1


def test_bootstrap_ci_block_size_widens_ci_on_autocorrelated_series() -> None:
    """Block bootstrap CI should be ≥ plain percentile CI on AR(1) data.

    Theory (R14 round-6 critic): plain percentile bootstrap on
    time-correlated samples under-estimates CI width because resampling
    i.i.d. frames breaks the correlation structure. Block bootstrap
    preserves it. The expected outcome is **wider** CIs from the block
    path on AR(1) (positively-autocorrelated) data.
    """
    rng = np.random.default_rng(7)
    n = 400
    phi = 0.85
    eps = rng.normal(size=n)
    ar1 = np.empty(n)
    ar1[0] = eps[0]
    for i in range(1, n):
        ar1[i] = phi * ar1[i - 1] + eps[i]

    plain_lo, plain_hi = bootstrap_ci(
        ar1, n_resamples=500, rng=np.random.default_rng(0), block_size=None
    )
    block_lo, block_hi = bootstrap_ci(
        ar1, n_resamples=500, rng=np.random.default_rng(0), block_size=25
    )
    plain_width = plain_hi - plain_lo
    block_width = block_hi - block_lo
    assert block_width > plain_width, (
        f"block bootstrap on autocorrelated series should widen CI; "
        f"plain={plain_width:.4f}, block={block_width:.4f}"
    )


def test_bootstrap_ci_block_size_rejects_oversized_block() -> None:
    with pytest.raises(ValueError, match="exceeds sample length"):
        bootstrap_ci(
            np.arange(10, dtype=np.float64),
            n_resamples=10,
            block_size=11,
            rng=np.random.default_rng(0),
        )


def test_bootstrap_ci_block_size_rejects_nonpositive() -> None:
    with pytest.raises(ValueError, match="block_size must be ≥ 1"):
        bootstrap_ci(
            np.arange(10, dtype=np.float64),
            n_resamples=10,
            block_size=0,
            rng=np.random.default_rng(0),
        )


# ---------- mcd ------------------------------------------------------------


def _synthetic_mfcc(
    n_frames: int,
    n_coef: int = 25,
    *,
    rng: np.random.Generator,
    scale: float = 1.0,
    offset: np.ndarray | None = None,
) -> np.ndarray:
    """Generate a smooth (low-frequency) synthetic MFCC sequence.

    Cepstra of real speech have strong frame-to-frame correlation; we
    mimic that with a slow random walk so the block bootstrap path is
    exercised on realistically autocorrelated values.
    """
    increments = rng.normal(scale=scale * 0.05, size=(n_frames, n_coef))
    walk = np.cumsum(increments, axis=0)
    if offset is not None:
        walk = walk + offset[None, :]
    return walk


def test_mcd_identity_round_trip_is_near_zero() -> None:
    pytest.importorskip("librosa")
    rng = np.random.default_rng(0)
    mfcc = _synthetic_mfcc(n_frames=200, rng=rng)
    result = mcd(mfcc, mfcc, rng=np.random.default_rng(0))
    assert result.name == "mcd"
    assert result.direction == "lower_better"
    # Default threshold tracks ``metrics._MCD_THRESHOLD_DEFAULT_DB`` (symbolic
    # reference, R14 round-10 phantom-fix 2026-05-12) — the prior literal
    # ``500.0`` assertion was a config-coupling test that would have broken
    # silently if the canary calibration produced a different anchor. The
    # default is canary-calibrated against librosa's log-mel-power DCT scale,
    # not Kominek 2008's native MCEP (the 6 dB literature placeholder was
    # retired because the scales differ by ~10^2-10^3).
    assert result.threshold == _MCD_THRESHOLD_DEFAULT_DB
    assert result.is_determined
    assert result.value == pytest.approx(0.0, abs=1e-6)
    assert result.passes


def test_mcd_discrimination_two_disjoint_sequences_exceeds_threshold() -> None:
    """Disjoint synthetic MFCCs ⇒ MCD CI lower bound > test threshold ⇒ REJECT.

    Uses an explicit low ``threshold=10`` so this unit test exercises the
    ``lower_better`` passes branch independent of the canary-calibrated
    500 dB default (which is anchored on real wav scales, not the small
    abstract MFCCs this fixture produces).
    """
    pytest.importorskip("librosa")
    offset_a = np.zeros(25)
    offset_b = np.linspace(5.0, 10.0, 25)
    a = _synthetic_mfcc(n_frames=200, rng=np.random.default_rng(1), offset=offset_a)
    b = _synthetic_mfcc(n_frames=200, rng=np.random.default_rng(2), offset=offset_b)
    result = mcd(a, b, threshold=10.0, rng=np.random.default_rng(0))
    assert result.is_determined
    assert not result.passes
    assert result.ci_low > 10.0, (
        f"disjoint MFCCs should produce MCD CI strictly above 10 dB; got CI=({result.ci_low}, {result.ci_high})"
    )


def test_mcd_undetermined_when_input_shorter_than_block() -> None:
    rng = np.random.default_rng(0)
    short = _synthetic_mfcc(n_frames=10, rng=rng)
    full = _synthetic_mfcc(n_frames=100, rng=rng)
    result = mcd(short, full, block_size=25)
    assert not result.is_determined
    assert not result.passes


def test_mcd_rejects_too_few_coefficients() -> None:
    rng = np.random.default_rng(0)
    a = _synthetic_mfcc(n_frames=100, n_coef=10, rng=rng)
    b = _synthetic_mfcc(n_frames=100, n_coef=10, rng=rng)
    with pytest.raises(ValueError, match="MFCC coefficients per frame"):
        mcd(a, b)


def test_mcd_rejects_non_2d_input() -> None:
    rng = np.random.default_rng(0)
    flat = rng.normal(size=100)
    with pytest.raises(ValueError, match=r"2-D MFCC"):
        mcd(flat, flat)
