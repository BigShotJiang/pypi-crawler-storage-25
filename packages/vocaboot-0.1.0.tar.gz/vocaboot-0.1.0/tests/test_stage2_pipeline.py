"""Stage 2 Tier 2 verify wiring (step 3b — agent_verify.run with reference_voice).

Closes ``docs/stage_2.md`` acceptance criterion #1: the Tier 2 gate
must both REJECT a synthesized non-voice signal AND APPROVE a real
recorded voice when both are evaluated against the same reference
:class:`vocaboot.profile_match.VoiceProfile`. Without **both arms** the
gate is non-discriminating — passing only one half (e.g. asserting
REJECT-only) lets a future bug that pushes everything to APPROVE slip
through silently.

Two recordings of the same Open JTalk + nitech voice (CC-BY-3.0):

  * ``tier2_reference_ja.wav`` — sentence A ("音声合成のサンプルです").
    Read into the reference ``VoiceProfile``; defines the target voice
    against which Tier 2 metrics measure.
  * ``tier2_canary_ja_alt.wav`` — sentence B ("今日はいい天気ですね").
    Different recording, same HMM speaker. Drives the APPROVE arm so
    Arm 2 is no longer an identity tautology against the reference
    (R17 audit 2026-05-12 closure — see ``docs/ckpt_registry.md``
    ``tier2-canary-alt-voice`` block).

Tests skip cleanly when:

  * ``[verify-similarity]`` deps (transformers / torch / librosa /
    soundfile / pyworld) are absent, OR
  * the WavLM-base weights have not been downloaded to the registry
    cache path, OR
  * either Tier 2 wav is missing (maintainer-only regeneration via the
    ``bash scripts/regenerate_tier2_*.sh`` scripts).
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from vocaboot import agent_verify, profile_match
from vocaboot.agent_verify import Verdict
from vocaboot.input import load_ds

_REPO_ROOT = Path(__file__).resolve().parent.parent
_EXAMPLES = _REPO_ROOT / "examples"
_SHORT_DS = _EXAMPLES / "short.ds"
_TIER2_REF_WAV = _EXAMPLES / "voice" / "tier2_reference_ja.wav"

# Tier 2 APPROVE-arm calibration set (R14 round-10, 2026-05-12): N=5 sentences
# from the same HMM speaker as the reference profile. The frame-level bootstrap
# CI on a single wav (the prior R17 audit closure's N=1 setup) cannot include
# inter-sample SE, so the calibration threshold itself had no estimable
# variance. N=5 sentence-within-speaker variance lets us compute a separability
# margin between the voice and synth arms and gate it as an assert.
_TIER2_VOICE_ARM_WAVS: tuple[Path, ...] = (
    _EXAMPLES / "voice" / "tier2_canary_ja_alt.wav",
    _EXAMPLES / "voice" / "tier2_canary_voice_02.wav",
    _EXAMPLES / "voice" / "tier2_canary_voice_03.wav",
    _EXAMPLES / "voice" / "tier2_canary_voice_04.wav",
    _EXAMPLES / "voice" / "tier2_canary_voice_05.wav",
)

# Tier 2 REJECT-arm calibration set: N=5 synth realizations with varied
# duration so the bootstrap CI captures synth-side dispersion (not just a
# single deterministic point reading). Different durations produce different
# DTW alignments against the reference, which is the natural variation source
# at the metric layer.
_TIER2_SYNTH_ARM_DURATIONS: tuple[float, ...] = (3.0, 3.5, 4.0, 4.5, 5.0)

# Required Tier 2 separability margins (R14 round-10 calibration anchor).
# voice arm vs synth arm bootstrap-CI bounds must be disjoint by at least
# these margins — anything tighter is too close to the noise floor to gate
# defensibly. Calibrated against the librosa-MFCC + WavLM-base scale; if the
# B2 probe (task #88) finds pysptk.mcep transferable to Kominek 6 dB, these
# constants will be re-calibrated alongside the threshold defaults.
_MCD_SEPARABILITY_MARGIN_DB = 100.0   # synth_mcd_lo_min - voice_mcd_hi_max
_COSINE_SEPARABILITY_MARGIN = 0.10    # voice_cos_lo_min - synth_cos_hi_max


def _wavlm_e2e_ready() -> bool:
    """True when WavLM weights + extras + all 5 voice canary wavs are present."""
    for mod in ("transformers", "torch", "librosa", "soundfile", "pyworld"):
        try:
            __import__(mod)
        except ImportError:
            return False
    if not profile_match.wavlm_weights_path().is_file():
        return False
    if not _TIER2_REF_WAV.is_file():
        return False
    return all(p.is_file() for p in _TIER2_VOICE_ARM_WAVS)


def _write_dummy_ckpt(tmp_path: Path) -> Path:
    p = tmp_path / "voice.onnx"
    p.write_bytes(b"")
    return p


def _synth_4partial_wav(
    out: Path,
    *,
    sample_rate: int = 16000,
    duration: float = 3.0,
) -> None:
    """Write a synthetic 4-partial harmonic wav (smoke-path 'rings' signal).

    The 4-partial harmonic sum passes pyworld's f0_stability + hnr thresholds
    (Tier 1) because it is dominantly harmonic, but it carries no speech
    formant structure — WavLM and MFCC place it far from any real voice.
    The Tier 2 gate must therefore REJECT it when the reference is real
    voice, even though Tier 1 would APPROVE.
    """
    import soundfile as sf

    t = np.arange(int(sample_rate * duration)) / sample_rate
    signal = 0.3 * (
        np.sin(2 * np.pi * 220.0 * t)
        + 0.5 * np.sin(2 * np.pi * 440.0 * t)
        + 0.3 * np.sin(2 * np.pi * 660.0 * t)
        + 0.2 * np.sin(2 * np.pi * 880.0 * t)
    )
    sf.write(str(out), signal.astype(np.float32), sample_rate)


def test_tier2_distinguishes_synthetic_from_voice(tmp_path: Path) -> None:
    """Criterion #1 両腕 (R14 round-10): synth→REJECT AND voice→APPROVE with N=5 calibration.

    The R14 round-9 R17 audit closure ran this gate at N=1 (single voice
    canary + single synth realization). The round-10 5-体並列 audit judged
    that an R5 violation — frame-level bootstrap CI on N=1 cannot capture
    inter-sample SE. Round-10 widens both arms to N=5 (5 voice sentences x
    5 synth durations) so the test gates on **separability margin** rather
    than on a single anchor sample's exact value.

    Per-sample assertions (each voice wav must individually pass, each synth
    wav must individually fail at least one Tier 2 metric) keep the legacy
    semantic intact. The new aggregate separability margin (computed from
    bootstrap-CI bounds across the calibration distributions) is the R5-
    strict gate the round-10 audit demanded.
    """
    if not _wavlm_e2e_ready():
        pytest.skip(
            "WavLM weights / [verify-similarity] deps / tier2 canary wavs "
            "not all available — Tier 2 canary skipped"
        )

    score = load_ds(_SHORT_DS)
    ckpt = _write_dummy_ckpt(tmp_path)
    tier2_profile = profile_match.build(_TIER2_REF_WAV)

    # --- Arm 1: N=5 synthetic 4-partial outputs vs real voice → REJECT ---
    synth_mcd_ci_lows: list[float] = []
    synth_mcd_ci_highs: list[float] = []
    synth_cos_ci_lows: list[float] = []
    synth_cos_ci_highs: list[float] = []
    for i, dur in enumerate(_TIER2_SYNTH_ARM_DURATIONS):
        synth_wav = tmp_path / f"synthetic_{i}.wav"
        _synth_4partial_wav(synth_wav, duration=dur)
        synth_gate = agent_verify.run(
            synth_wav,
            score=score,
            ckpt=ckpt,
            reference_voice=tier2_profile,
        )
        synth_metrics = {m.name: m for m in synth_gate.metrics}
        tier2_synth_fail = (
            synth_metrics["mcd"].is_determined and not synth_metrics["mcd"].passes
        ) or (
            synth_metrics["wavlm_cosine"].is_determined
            and not synth_metrics["wavlm_cosine"].passes
        )
        assert tier2_synth_fail, (
            f"synth_{i} (dur={dur}s) vs tier2 voice → at least one Tier 2 "
            f"metric must FAIL its threshold; got mcd={synth_metrics['mcd']}, "
            f"wavlm_cosine={synth_metrics['wavlm_cosine']}"
        )
        assert synth_gate.verdict is Verdict.REJECT, (
            f"synth_{i} arm verdict expected REJECT, got "
            f"{synth_gate.verdict.value}; metrics="
            f"{[(m.name, m.value, m.passes) for m in synth_gate.metrics]}"
        )
        synth_mcd_ci_lows.append(synth_metrics["mcd"].ci_low)
        synth_mcd_ci_highs.append(synth_metrics["mcd"].ci_high)
        synth_cos_ci_lows.append(synth_metrics["wavlm_cosine"].ci_low)
        synth_cos_ci_highs.append(synth_metrics["wavlm_cosine"].ci_high)

    # --- Arm 2: N=5 voice canary wavs vs tier2 profile → APPROVE ---------
    # Tier 2 specifically: each voice canary must pass MCD AND wavlm_cosine.
    # Overall verdict (Tier 1 + Tier 2 combined) is intentionally NOT asserted
    # per wav — f0_stability on the OpenJTalk HMM canaries straddles 0.02
    # depending on the sentence, and a strictly-failed Tier 1 metric forces
    # overall REJECT even when Tier 2 metrics pass perfectly. The round-10
    # multi-canary widening is a Tier 2 separability gate; the Tier 1
    # boundary belongs to Stage 1, not this test.
    voice_mcd_ci_lows: list[float] = []
    voice_mcd_ci_highs: list[float] = []
    voice_cos_ci_lows: list[float] = []
    voice_cos_ci_highs: list[float] = []
    for voice_wav in _TIER2_VOICE_ARM_WAVS:
        voice_gate = agent_verify.run(
            voice_wav,
            score=score,
            ckpt=ckpt,
            reference_voice=tier2_profile,
        )
        voice_metrics = {m.name: m for m in voice_gate.metrics}
        assert voice_metrics["mcd"].passes, (
            f"voice canary {voice_wav.name}: Tier 2 MCD must pass; "
            f"got {voice_metrics['mcd']}"
        )
        assert voice_metrics["wavlm_cosine"].passes, (
            f"voice canary {voice_wav.name}: Tier 2 wavlm_cosine must pass; "
            f"got {voice_metrics['wavlm_cosine']}"
        )
        voice_mcd_ci_lows.append(voice_metrics["mcd"].ci_low)
        voice_mcd_ci_highs.append(voice_metrics["mcd"].ci_high)
        voice_cos_ci_lows.append(voice_metrics["wavlm_cosine"].ci_low)
        voice_cos_ci_highs.append(voice_metrics["wavlm_cosine"].ci_high)

    # --- Aggregate separability margin (R5-strict gate, the round-10 ask)
    # MCD is lower_better: synth has HIGH mcd, voice has LOW mcd → margin
    # is synth_lo_min - voice_hi_max (i.e. the worst-case gap between the
    # synth-distribution lower envelope and the voice-distribution upper
    # envelope). Cosine is higher_better: voice has HIGH cosine, synth has
    # LOW cosine → margin is voice_lo_min - synth_hi_max.
    voice_mcd_hi_max = max(voice_mcd_ci_highs)
    synth_mcd_lo_min = min(synth_mcd_ci_lows)
    voice_cos_lo_min = min(voice_cos_ci_lows)
    synth_cos_hi_max = max(synth_cos_ci_highs)

    mcd_margin = synth_mcd_lo_min - voice_mcd_hi_max
    cos_margin = voice_cos_lo_min - synth_cos_hi_max

    assert mcd_margin > _MCD_SEPARABILITY_MARGIN_DB, (
        f"MCD calibration margin {mcd_margin:.2f} dB ≤ required "
        f"{_MCD_SEPARABILITY_MARGIN_DB} dB. "
        f"voice_mcd_hi_max={voice_mcd_hi_max:.2f}, "
        f"synth_mcd_lo_min={synth_mcd_lo_min:.2f}. "
        f"voice CI uppers={[f'{x:.1f}' for x in voice_mcd_ci_highs]}, "
        f"synth CI lowers={[f'{x:.1f}' for x in synth_mcd_ci_lows]}"
    )
    assert cos_margin > _COSINE_SEPARABILITY_MARGIN, (
        f"WavLM cosine calibration margin {cos_margin:.3f} ≤ required "
        f"{_COSINE_SEPARABILITY_MARGIN}. "
        f"voice_cos_lo_min={voice_cos_lo_min:.3f}, "
        f"synth_cos_hi_max={synth_cos_hi_max:.3f}. "
        f"voice CI lowers={[f'{x:.3f}' for x in voice_cos_ci_lows]}, "
        f"synth CI uppers={[f'{x:.3f}' for x in synth_cos_ci_highs]}"
    )


def test_tier2_metric_set_includes_mcd_and_wavlm_cosine(tmp_path: Path) -> None:
    """When ``reference_voice`` is supplied, the gate adds MCD + wavlm_cosine.

    The Tier 1 baseline (``f0_stability`` + ``hnr``) is retained so a
    Tier 2 verdict is defense-in-depth across the harmonic / spectral
    / speaker axes rather than a single similarity threshold.
    """
    if not _wavlm_e2e_ready():
        pytest.skip("WavLM weights / [verify-similarity] deps not available")

    score = load_ds(_SHORT_DS)
    ckpt = _write_dummy_ckpt(tmp_path)
    tier2_profile = profile_match.build(_TIER2_REF_WAV)

    gate = agent_verify.run(
        _TIER2_REF_WAV,
        score=score,
        ckpt=ckpt,
        reference_voice=tier2_profile,
    )
    metric_names = [m.name for m in gate.metrics]
    assert metric_names == ["f0_stability", "hnr", "mcd", "wavlm_cosine"], (
        f"Tier 2 must include exactly the 4 metrics in this order; "
        f"got {metric_names}"
    )


def test_mcd_threshold_band_wired_in_production() -> None:
    """``agent_verify.run`` must pass MCD ``threshold_ci`` from the public band.

    The 2-sided ``threshold_ci`` gate is structurally easy to bypass — a
    refactor that drops the kwarg would silently fall back to the legacy
    1-sided gate and the existing canary tests still pass (the voice / synth
    arms are separable enough that the 1-sided gate gets the right answer
    by accident). This contract locks both the call-site (AST walk) and
    the band shape so the regression cannot land undetected.
    """
    import ast
    import inspect

    from vocaboot import agent_verify, metrics

    src = inspect.getsource(agent_verify.run)
    tree = ast.parse(src)
    mcd_calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "mcd"
    ]
    assert mcd_calls, "agent_verify.run no longer calls metrics.mcd — Tier 2 wire-in regressed"
    for call in mcd_calls:
        kwargs = {kw.arg for kw in call.keywords if kw.arg is not None}
        assert "threshold_ci" in kwargs, (
            f"metrics.mcd(...) in agent_verify.run does not pass threshold_ci; "
            f"production path is back on the 1-sided gate. Got kwargs={sorted(kwargs)}"
        )
    band = metrics.MCD_THRESHOLD_BAND_DB
    assert isinstance(band, tuple) and len(band) == 2
    t_lo, t_hi = band
    assert 0.0 < t_lo < t_hi, (
        f"MCD_THRESHOLD_BAND_DB must be a strictly-positive lo < hi pair; got {band}"
    )
    assert t_lo < metrics._MCD_THRESHOLD_DEFAULT_DB < t_hi, (
        f"Calibrated point threshold {metrics._MCD_THRESHOLD_DEFAULT_DB} must sit "
        f"inside the band {band} so the band represents uncertainty around "
        f"the calibrated anchor."
    )


def test_tier1_default_when_no_reference_voice(tmp_path: Path) -> None:
    """``reference_voice=None`` must keep the legacy Tier 1 metric set."""
    pytest.importorskip("pyworld")
    pytest.importorskip("soundfile")
    import soundfile as sf

    score = load_ds(_SHORT_DS)
    ckpt = _write_dummy_ckpt(tmp_path)

    sr = 16000
    t = np.arange(2 * sr) / sr
    audio = (0.3 * np.sin(2 * np.pi * 220.0 * t)).astype(np.float32)
    wav = tmp_path / "tier1.wav"
    sf.write(str(wav), audio, sr)

    gate = agent_verify.run(wav, score=score, ckpt=ckpt)
    metric_names = [m.name for m in gate.metrics]
    assert metric_names == ["f0_stability", "hnr"], (
        f"Tier 1 default must surface exactly f0_stability + hnr; "
        f"got {metric_names}"
    )


def test_tier2_rejects_profile_without_mfcc_fields(tmp_path: Path) -> None:
    """Tier 2 verify requires a schema=2 profile with MFCC populated.

    A partially-constructed profile (WavLM only, mfcc_cepstra=None)
    must surface a clear ValueError rather than silently downgrading
    to WavLM-only verification — the caller asked for Tier 2 and got
    no MCD coverage, which is a contract violation.
    """
    pytest.importorskip("pyworld")
    pytest.importorskip("soundfile")
    import soundfile as sf

    from vocaboot.profile_match import F0Stats, VoiceProfile

    score = load_ds(_SHORT_DS)
    ckpt = _write_dummy_ckpt(tmp_path)

    sr = 16000
    audio = (0.3 * np.sin(2 * np.pi * 220.0 * np.arange(sr) / sr)).astype(np.float32)
    wav = tmp_path / "in.wav"
    sf.write(str(wav), audio, sr)

    # Partial profile: WavLM only, no MFCC (schema_version=2 default OK
    # because the dataclass keeps mfcc_cepstra_* as Optional defaults).
    partial = VoiceProfile(
        wavlm_embedding_bytes=b"\x00" * 64,
        wavlm_embedding_shape=(2, 8),
        wavlm_embedding_dtype="float32",
        f0_stats=F0Stats(0.0, 0.0, 0.0, 0.0, 0.0),
        spectral_centroid_mean=0.0,
        duration_seconds=1.0,
        source_sha256="abc",
    )
    with pytest.raises(ValueError, match="mfcc_cepstra"):
        agent_verify.run(wav, score=score, ckpt=ckpt, reference_voice=partial)
