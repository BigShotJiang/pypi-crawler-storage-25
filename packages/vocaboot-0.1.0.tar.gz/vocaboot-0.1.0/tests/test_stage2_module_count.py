"""Stage 2 criterion #7 — total non-underscore module count in ``src/vocaboot/`` ≤ 14.

The R14 round-10 verifier audit (2026-05-12) found this gate was structurally
unenforced: ``docs/stage_2.md`` criterion #7 names a ceiling but no test
walked the module set. Adding a module beyond the ceiling would not have
broken any test — purely a process gate, not a structural one. This test
puts the assertion in the test suite so a future module addition either
fits under the ceiling or surfaces an explicit Stage 3 trigger (split the
``services/`` + ``core/`` decision the spec defers).

Underscore-prefixed modules (``__init__``, ``_resources``) are excluded per
the spec snapshot in ``docs/stage_2.md`` L231.
"""

from __future__ import annotations

from pathlib import Path

_PACKAGE_ROOT = Path(__file__).resolve().parent.parent / "src" / "vocaboot"
_MODULE_CEILING = 14


def _public_modules() -> list[Path]:
    return sorted(
        p for p in _PACKAGE_ROOT.glob("*.py") if not p.stem.startswith("_")
    )


def test_stage2_module_count_under_ceiling() -> None:
    """``src/vocaboot/`` must hold ≤ 14 non-underscore modules (spec criterion #7)."""
    modules = _public_modules()
    names = [p.stem for p in modules]
    assert len(modules) <= _MODULE_CEILING, (
        f"Stage 2 criterion #7 ceiling exceeded: {len(modules)} non-underscore "
        f"modules in src/vocaboot/, ceiling is {_MODULE_CEILING}. modules={names}. "
        "Adding new modules at this point requires the Stage 3 services/core "
        "package split decision (docs/stage_2.md L231) — do not raise the "
        "ceiling here without re-opening that decision."
    )


def test_stage2_module_count_matches_spec_snapshot() -> None:
    """The non-underscore module set must match the Stage 2 spec snapshot exactly.

    Catches accidental renames (`profile_match.py` → `profile.py`) and silent
    module removals that the count-only gate above would not detect.
    """
    expected = {
        "agent_advisory",
        "agent_verify",
        "audio_ingest",
        "cli",
        "input",
        "license_check",
        "metrics",
        "museum",
        "output",
        "pipeline",
        "privacy",
        "profile_match",
        "score_align",
        "svs_engine",
    }
    actual = {p.stem for p in _public_modules()}
    assert actual == expected, (
        f"Stage 2 module set drift. extra={actual - expected}, "
        f"missing={expected - actual}. Update docs/stage_2.md L231 + this "
        "expected set together if the change is intentional."
    )
