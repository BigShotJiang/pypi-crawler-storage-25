"""Pin consistency between code/artifact and registry.

The WavLM-base sha256 lives in two places: ``profile_match._PINNED_WAVLM_SHA256``
(the runtime gate) and ``docs/ckpt_registry.md`` (the supply-chain audit trail).
A drift between the two would let a future edit silently relax the verifier on
one side. R14 round-5 architect A4 made this a structural test rather than a
review-time check. The same idea applies to the revision SHA pin and to the
artifact URL — if a new upstream revision lands, all three (code constant,
registry ``revision:`` field, registry ``artifact_url:`` field) must move
together.

R14 round-8 extends the pattern to the Tier 2 reference voice
(``examples/voice/tier2_reference_ja.wav``, Open JTalk + nitech CC-BY-3.0).
The wav itself is the runtime artifact — no code constant mirrors it because
the metric layer loads from the registry-declared ``artifact_path:`` — so the
drift test compares the *file's runtime properties* against the registry
pins. Four axes (``sha256`` + ``size_bytes`` + ``sample_rate`` +
``duration_seconds``) are pinned independently to keep root-cause separation
at test-failure time: re-generation drift typically perturbs ``sha256`` alone
(deterministic HMM synthesis byte-identical only if the engine + voice deb +
text + sample-rate flag all match), while accidental file replacement /
wrong-format substitution shows up as ``size_bytes`` or ``sample_rate``
anomalies. ``duration_seconds`` catches a re-trim or different input text.
"""

from __future__ import annotations

import hashlib
import re
import wave
from pathlib import Path

import pytest

from vocaboot.profile_match import _PINNED_WAVLM_REVISION, _PINNED_WAVLM_SHA256

_REPO_ROOT = Path(__file__).resolve().parent.parent
_REGISTRY = _REPO_ROOT / "docs" / "ckpt_registry.md"


def _find_block(name: str) -> str:
    """Return the YAML block whose ``- name: {name}`` heads the entry.

    Slices the registry text from the ``- name: {name}`` line up to the next
    boundary, where boundary = next ``- name: <something>`` entry OR next
    ``## `` markdown section heading (whichever comes first). The
    section-heading boundary prevents the slice from sweeping past the
    yaml block into the following prose, which is important when an
    entry's ``notes: |`` literal scalar carries multi-paragraph commentary
    that has no closing ``- name:`` sibling until much later in the file.
    """
    text = _REGISTRY.read_text(encoding="utf-8")
    head_pattern = re.compile(rf"^- name:\s*{re.escape(name)}\s*$", re.MULTILINE)
    m = head_pattern.search(text)
    assert m, f"{name!r} entry not found in {_REGISTRY}"
    tail = text[m.start():]
    boundary = re.search(r"^(?:- name:\s*\S|## )", tail[1:], re.MULTILINE)
    if boundary:
        return tail[: 1 + boundary.start()]
    return tail


def _wavlm_block() -> str:
    """Return the YAML block whose ``- name: wavlm-base`` heads the entry."""
    return _find_block("wavlm-base")


def _tier2_reference_voice_block() -> str:
    """Return the YAML block whose ``- name: tier2-reference-voice`` heads the entry."""
    return _find_block("tier2-reference-voice")


def _tier2_canary_alt_voice_block() -> str:
    """Return the YAML block whose ``- name: tier2-canary-alt-voice`` heads the entry."""
    return _find_block("tier2-canary-alt-voice")


def _artifact_path_from_block(block: str, *, entry_label: str) -> Path:
    m = re.search(r"^\s*artifact_path:\s*(\S+)\s*(?:#.*)?$", block, re.MULTILINE)
    assert m, f"artifact_path line not found in {entry_label} entry:\n{block}"
    return _REPO_ROOT / m.group(1)


# ---- WavLM (PR1a, R14 round-5) ----------------------------------------------


def test_wavlm_sha256_matches_registry() -> None:
    """``_PINNED_WAVLM_SHA256`` must equal the registry ``sha256:`` field."""
    block = _wavlm_block()
    m = re.search(r"^\s*sha256:\s*([0-9a-fA-F]{64})\s*$", block, re.MULTILINE)
    assert m, f"sha256 line not found in wavlm-base registry entry:\n{block}"
    assert m.group(1) == _PINNED_WAVLM_SHA256, (
        "drift between profile_match._PINNED_WAVLM_SHA256 and "
        "docs/ckpt_registry.md sha256: — update both together"
    )


def test_wavlm_revision_matches_registry() -> None:
    """``_PINNED_WAVLM_REVISION`` must equal the registry ``revision:`` field."""
    block = _wavlm_block()
    m = re.search(r"^\s*revision:\s*([0-9a-fA-F]{40})\b", block, re.MULTILINE)
    assert m, f"revision line not found in wavlm-base registry entry:\n{block}"
    assert m.group(1) == _PINNED_WAVLM_REVISION, (
        "drift between profile_match._PINNED_WAVLM_REVISION and "
        "docs/ckpt_registry.md revision: — update both together"
    )


def test_wavlm_artifact_url_uses_pinned_revision() -> None:
    """``artifact_url:`` must embed the pinned revision SHA, not ``main``."""
    block = _wavlm_block()
    m = re.search(r"^\s*artifact_url:\s*(\S+)\s*$", block, re.MULTILINE)
    assert m, f"artifact_url line not found:\n{block}"
    url = m.group(1)
    assert _PINNED_WAVLM_REVISION in url, (
        f"artifact_url {url!r} does not pin the revision SHA "
        f"{_PINNED_WAVLM_REVISION!r}; ``main`` is not reproducible"
    )


# ---- Tier 2 reference voice (PR1b, R14 round-7 path / round-8 architecture) -


def _tier2_artifact_path() -> Path:
    block = _tier2_reference_voice_block()
    m = re.search(
        r"^\s*artifact_path:\s*(\S+)\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, (
        f"artifact_path line not found in tier2-reference-voice entry:\n{block}"
    )
    return _REPO_ROOT / m.group(1)


def test_tier2_reference_voice_artifact_path_exists() -> None:
    """Registry ``artifact_path:`` must resolve to a file on disk.

    Precondition for the four drift tests below — without the file the drift
    tests would fail with misleading ``FileNotFoundError`` rather than a
    clear "path mismatch" diagnostic.
    """
    path = _tier2_artifact_path()
    assert path.is_file(), (
        f"tier2-reference-voice artifact_path {path!r} does not exist. "
        "Regenerate with `bash scripts/regenerate_tier2_reference.sh`."
    )


def test_tier2_reference_voice_sha256_matches_registry() -> None:
    """The runtime sha256 of the wav must equal the registry ``sha256:`` field.

    sha256 drift typically indicates regeneration with a different engine
    version, voice deb, input text, or sample-rate flag.
    """
    block = _tier2_reference_voice_block()
    m = re.search(
        r"^\s*sha256:\s*([0-9a-fA-F]{64})\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, f"sha256 line not found in tier2-reference-voice entry:\n{block}"
    registry_sha = m.group(1)

    path = _tier2_artifact_path()
    runtime_sha = hashlib.sha256(path.read_bytes()).hexdigest()

    assert runtime_sha == registry_sha, (
        "drift between examples/voice/tier2_reference_ja.wav and "
        "docs/ckpt_registry.md sha256: — runtime regeneration likely changed "
        "the file. Update both the file and the 4-axis pin together via "
        "`bash scripts/regenerate_tier2_reference.sh` and commit the new pin."
    )


def test_tier2_reference_voice_size_bytes_matches_registry() -> None:
    """File size must equal the registry ``size_bytes:`` field.

    Size drift without an accompanying sha256 drift is structurally
    impossible (sha256 covers every byte) — independent assertion exists so
    accidental wrong-format replacement (e.g. an MP3 in a .wav path) yields
    a fast, specific failure rather than a cryptic sha256 mismatch.
    """
    block = _tier2_reference_voice_block()
    m = re.search(
        r"^\s*size_bytes:\s*(\d+)\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, (
        f"size_bytes line not found in tier2-reference-voice entry:\n{block}"
    )
    registry_size = int(m.group(1))

    path = _tier2_artifact_path()
    runtime_size = path.stat().st_size

    assert runtime_size == registry_size, (
        f"drift in tier2_reference_ja.wav size_bytes: registry={registry_size}, "
        f"runtime={runtime_size} — likely accidental file replacement or "
        "wrong-format substitution."
    )


def test_tier2_reference_voice_sample_rate_matches_registry() -> None:
    """WAV header sample_rate must equal the registry ``sample_rate:`` field.

    Sample rate is locked at 16 kHz to match WavLM's input rate (no internal
    resample between the stored bytes and the metric). A drift here means
    the wav was regenerated without the ``-s 16000`` flag.
    """
    block = _tier2_reference_voice_block()
    m = re.search(
        r"^\s*sample_rate:\s*(\d+)\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, (
        f"sample_rate line not found in tier2-reference-voice entry:\n{block}"
    )
    registry_rate = int(m.group(1))

    path = _tier2_artifact_path()
    with wave.open(str(path), "rb") as w:
        runtime_rate = w.getframerate()

    assert runtime_rate == registry_rate, (
        f"drift in tier2_reference_ja.wav sample_rate: registry={registry_rate}, "
        f"runtime={runtime_rate} — regenerated without `-s 16000`?"
    )


def test_tier2_reference_voice_duration_seconds_matches_registry() -> None:
    """WAV frames / sample_rate must equal the registry ``duration_seconds:`` field.

    Duration drift catches re-trims or regeneration with different input
    text. Tolerance is one frame's worth of float-precision slack (the
    arithmetic is integer-frames / integer-rate, so identity holds to
    well under ``1e-6``).
    """
    block = _tier2_reference_voice_block()
    m = re.search(
        r"^\s*duration_seconds:\s*([\d.]+)\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, (
        f"duration_seconds line not found in tier2-reference-voice entry:\n{block}"
    )
    registry_duration = float(m.group(1))

    path = _tier2_artifact_path()
    with wave.open(str(path), "rb") as w:
        runtime_duration = w.getnframes() / w.getframerate()

    assert runtime_duration == pytest.approx(registry_duration, abs=1e-6), (
        f"drift in tier2_reference_ja.wav duration_seconds: "
        f"registry={registry_duration}, runtime={runtime_duration} — file "
        "was likely re-trimmed or regenerated with different input text."
    )


# ---- Tier 2 canary APPROVE-arm voice (R17 audit 2026-05-12, Arm 2 fix) ------


def test_tier2_canary_alt_voice_artifact_path_exists() -> None:
    """Registry ``artifact_path:`` for the alt canary must resolve to a file."""
    block = _tier2_canary_alt_voice_block()
    path = _artifact_path_from_block(block, entry_label="tier2-canary-alt-voice")
    assert path.is_file(), (
        f"tier2-canary-alt-voice artifact_path {path!r} does not exist. "
        "Regenerate with `bash scripts/regenerate_tier2_canary_alt.sh`."
    )


def test_tier2_canary_alt_voice_sha256_matches_registry() -> None:
    """Runtime sha256 of tier2_canary_ja_alt.wav must equal registry pin."""
    block = _tier2_canary_alt_voice_block()
    m = re.search(
        r"^\s*sha256:\s*([0-9a-fA-F]{64})\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, f"sha256 line not found in tier2-canary-alt-voice entry:\n{block}"
    registry_sha = m.group(1)

    path = _artifact_path_from_block(block, entry_label="tier2-canary-alt-voice")
    runtime_sha = hashlib.sha256(path.read_bytes()).hexdigest()

    assert runtime_sha == registry_sha, (
        "drift between examples/voice/tier2_canary_ja_alt.wav and "
        "docs/ckpt_registry.md tier2-canary-alt-voice sha256: — regenerate "
        "with `bash scripts/regenerate_tier2_canary_alt.sh` and commit the new pin."
    )


def test_tier2_canary_alt_voice_size_bytes_matches_registry() -> None:
    block = _tier2_canary_alt_voice_block()
    m = re.search(
        r"^\s*size_bytes:\s*(\d+)\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, f"size_bytes line not found in tier2-canary-alt-voice entry:\n{block}"
    registry_size = int(m.group(1))

    path = _artifact_path_from_block(block, entry_label="tier2-canary-alt-voice")
    runtime_size = path.stat().st_size

    assert runtime_size == registry_size, (
        f"drift in tier2_canary_ja_alt.wav size_bytes: registry={registry_size}, "
        f"runtime={runtime_size}"
    )


def test_tier2_canary_alt_voice_sample_rate_matches_registry() -> None:
    block = _tier2_canary_alt_voice_block()
    m = re.search(
        r"^\s*sample_rate:\s*(\d+)\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, f"sample_rate line not found in tier2-canary-alt-voice entry:\n{block}"
    registry_rate = int(m.group(1))

    path = _artifact_path_from_block(block, entry_label="tier2-canary-alt-voice")
    with wave.open(str(path), "rb") as w:
        runtime_rate = w.getframerate()

    assert runtime_rate == registry_rate, (
        f"drift in tier2_canary_ja_alt.wav sample_rate: registry={registry_rate}, "
        f"runtime={runtime_rate} — regenerated without `-s 16000`?"
    )


def test_tier2_canary_alt_voice_duration_seconds_matches_registry() -> None:
    block = _tier2_canary_alt_voice_block()
    m = re.search(
        r"^\s*duration_seconds:\s*([\d.]+)\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, f"duration_seconds line not found in tier2-canary-alt-voice entry:\n{block}"
    registry_duration = float(m.group(1))

    path = _artifact_path_from_block(block, entry_label="tier2-canary-alt-voice")
    with wave.open(str(path), "rb") as w:
        runtime_duration = w.getnframes() / w.getframerate()

    assert runtime_duration == pytest.approx(registry_duration, abs=1e-6), (
        f"drift in tier2_canary_ja_alt.wav duration_seconds: "
        f"registry={registry_duration}, runtime={runtime_duration}"
    )


# ---- Tier 2 multi-canary voice arm (R14 round-10, 2026-05-12) ----------------
#
# The R14 round-10 5-体並列 audit found the round-9 closure used N=1 calibration
# (only ``tier2-canary-alt-voice``), which violates R5 — the bootstrap CI on a
# single wav cannot include inter-sample SE. Round-10 widens the APPROVE arm to
# N=5 wavs (same HMM speaker, varied sentences). Tests parametrize over the 4
# new entries; the 1st sample (tier2-canary-alt-voice) is gated by the block
# of tests immediately above. Together they form the N=5 calibration set.

_TIER2_VOICE_ARM_NAMES = (
    "tier2-canary-voice-02",
    "tier2-canary-voice-03",
    "tier2-canary-voice-04",
    "tier2-canary-voice-05",
)


@pytest.mark.parametrize("canary_name", _TIER2_VOICE_ARM_NAMES)
def test_tier2_canary_voice_arm_artifact_path_exists(canary_name: str) -> None:
    block = _find_block(canary_name)
    path = _artifact_path_from_block(block, entry_label=canary_name)
    assert path.is_file(), (
        f"{canary_name} artifact_path {path!r} does not exist. "
        "Regenerate with `bash scripts/regenerate_tier2_canary_voice_arm.sh`."
    )


@pytest.mark.parametrize("canary_name", _TIER2_VOICE_ARM_NAMES)
def test_tier2_canary_voice_arm_sha256_matches_registry(canary_name: str) -> None:
    block = _find_block(canary_name)
    m = re.search(
        r"^\s*sha256:\s*([0-9a-fA-F]{64})\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, f"sha256 line not found in {canary_name} entry:\n{block}"
    registry_sha = m.group(1)

    path = _artifact_path_from_block(block, entry_label=canary_name)
    runtime_sha = hashlib.sha256(path.read_bytes()).hexdigest()

    assert runtime_sha == registry_sha, (
        f"drift between {path} and docs/ckpt_registry.md {canary_name} sha256: "
        "— regenerate with `bash scripts/regenerate_tier2_canary_voice_arm.sh` "
        "and commit the new pin."
    )


@pytest.mark.parametrize("canary_name", _TIER2_VOICE_ARM_NAMES)
def test_tier2_canary_voice_arm_size_bytes_matches_registry(canary_name: str) -> None:
    block = _find_block(canary_name)
    m = re.search(r"^\s*size_bytes:\s*(\d+)\s*(?:#.*)?$", block, re.MULTILINE)
    assert m, f"size_bytes line not found in {canary_name} entry:\n{block}"
    registry_size = int(m.group(1))

    path = _artifact_path_from_block(block, entry_label=canary_name)
    runtime_size = path.stat().st_size

    assert runtime_size == registry_size, (
        f"drift in {path} size_bytes: registry={registry_size}, "
        f"runtime={runtime_size}"
    )


@pytest.mark.parametrize("canary_name", _TIER2_VOICE_ARM_NAMES)
def test_tier2_canary_voice_arm_sample_rate_matches_registry(canary_name: str) -> None:
    block = _find_block(canary_name)
    m = re.search(r"^\s*sample_rate:\s*(\d+)\s*(?:#.*)?$", block, re.MULTILINE)
    assert m, f"sample_rate line not found in {canary_name} entry:\n{block}"
    registry_rate = int(m.group(1))

    path = _artifact_path_from_block(block, entry_label=canary_name)
    with wave.open(str(path), "rb") as w:
        runtime_rate = w.getframerate()

    assert runtime_rate == registry_rate, (
        f"drift in {path} sample_rate: registry={registry_rate}, "
        f"runtime={runtime_rate} — regenerated without `-s 16000`?"
    )


@pytest.mark.parametrize("canary_name", _TIER2_VOICE_ARM_NAMES)
def test_tier2_canary_voice_arm_duration_seconds_matches_registry(
    canary_name: str,
) -> None:
    block = _find_block(canary_name)
    m = re.search(
        r"^\s*duration_seconds:\s*([\d.]+)\s*(?:#.*)?$", block, re.MULTILINE
    )
    assert m, f"duration_seconds line not found in {canary_name} entry:\n{block}"
    registry_duration = float(m.group(1))

    path = _artifact_path_from_block(block, entry_label=canary_name)
    with wave.open(str(path), "rb") as w:
        runtime_duration = w.getnframes() / w.getframerate()

    assert runtime_duration == pytest.approx(registry_duration, abs=1e-6), (
        f"drift in {path} duration_seconds: registry={registry_duration}, "
        f"runtime={runtime_duration}"
    )
