"""Stage 2 step 2 — audio_ingest tests.

Three coverage bands:

  * **contract**: 5-step ordering, tmp dir lifecycle, sha256 sourced from
    original (not the copy), 0o600 mode on the copy, symlink resolve,
    rejection of non-regular files.
  * **bypass guard**: ConsentRequiredError fires *before* any tmp dir is
    created; refuse_if_protected catches symlinks to protected references.
  * **CLI E2E (Stage 2 acceptance criterion #3)**: ``vocaboot ingest``
    refuses with exit 7 when consent flags are missing, writes a museum
    entry under the redacted-user-audio key, and the consent env vars
    work as a substitute for the CLI flags (R14 round-3 invariant).
"""

from __future__ import annotations

import json
import os
import stat
import sys
from pathlib import Path

import pytest
from click.testing import CliRunner

from vocaboot import audio_ingest
from vocaboot.audio_ingest import (
    _CONSENT_NO_REDISTRIBUTE_ENV,
    _CONSENT_NO_STORE_ENV,
    _MUSEUM_KEY_MAP,
    IngestedAudio,
    ingest,
    museum_key_for,
)
from vocaboot.cli import main
from vocaboot.privacy import ConsentRequiredError


def _make_audio(tmp_path: Path, name: str = "song.wav", payload: bytes = b"\x00" * 32) -> Path:
    """Write a regular-file placeholder. The bytes content is irrelevant — no
    audio decoder runs in this test (consent + sha256 + copy only)."""
    audio = tmp_path / name
    audio.write_bytes(payload)
    return audio


def test_ingest_yields_consent_checked_wrapper(tmp_path: Path) -> None:
    """Happy path: both flags set → IngestedAudio yielded, tmp path exists in scope."""
    audio = _make_audio(tmp_path)
    with ingest(
        audio,
        intent="reference",
        consent_no_store=True,
        consent_no_redistribute=True,
    ) as ia:
        assert isinstance(ia, IngestedAudio)
        assert ia.intent == "reference"
        assert ia.consent_no_store is True
        assert ia.consent_no_redistribute is True
        assert ia.path.is_file()
        # The copy lives in a fresh tmp dir, not in the source dir.
        assert ia.path.parent != audio.parent
        assert ia.path.parent.name.startswith("vocaboot-ingest-")


def test_ingest_removes_tmp_dir_on_exit(tmp_path: Path) -> None:
    """tmp dir lifecycle: parent dir must be gone after the with-block exits."""
    audio = _make_audio(tmp_path)
    captured_path: list[Path] = []
    with ingest(
        audio,
        intent="reference",
        consent_no_store=True,
        consent_no_redistribute=True,
    ) as ia:
        captured_path.append(ia.path.parent)
        assert ia.path.parent.is_dir()
    # finally-block cleanup must have removed the dir.
    assert not captured_path[0].exists(), "tmp dir must be deleted on exit"


def test_ingest_removes_tmp_dir_on_exception(tmp_path: Path) -> None:
    """finally must run even when the with-block body raises."""
    audio = _make_audio(tmp_path)
    captured_path: list[Path] = []
    with pytest.raises(RuntimeError, match="inside-block"), ingest(
        audio,
        intent="reference",
        consent_no_store=True,
        consent_no_redistribute=True,
    ) as ia:
        captured_path.append(ia.path.parent)
        raise RuntimeError("inside-block")
    assert not captured_path[0].exists()


def test_ingest_refuses_without_consent_before_tmp_dir(tmp_path: Path, monkeypatch) -> None:
    """Step 1 fires before step 3: no tmp dir created on consent refusal."""
    audio = _make_audio(tmp_path)
    mkdtemp_called = {"value": False}

    import tempfile as _tempfile

    original_mkdtemp = _tempfile.mkdtemp

    def _wrapped(*args, **kwargs):
        mkdtemp_called["value"] = True
        return original_mkdtemp(*args, **kwargs)

    monkeypatch.setattr(_tempfile, "mkdtemp", _wrapped)

    with pytest.raises(ConsentRequiredError), ingest(
        audio,
        intent="reference",
        consent_no_store=False,
        consent_no_redistribute=False,
    ):
        pytest.fail("contextmanager body must not run when consent is missing")

    assert mkdtemp_called["value"] is False, (
        "mkdtemp must not be called when the consent gate refuses"
    )


def test_ingest_source_sha256_is_original_not_copy(tmp_path: Path) -> None:
    """source_sha256 must reflect the original audio, not the tmp copy."""
    import hashlib

    payload = b"specific-bytes-for-this-test" * 7
    audio = _make_audio(tmp_path, payload=payload)
    expected = hashlib.sha256(payload).hexdigest()

    with ingest(
        audio,
        intent="reference",
        consent_no_store=True,
        consent_no_redistribute=True,
    ) as ia:
        assert ia.source_sha256 == expected


def test_ingest_tmp_copy_has_0o600_permissions(tmp_path: Path) -> None:
    """The copy must be ``0o600`` so a multi-user host cannot read it."""
    if sys.platform == "win32":
        pytest.skip("POSIX permission semantics not enforced on Windows")
    audio = _make_audio(tmp_path)
    with ingest(
        audio,
        intent="reference",
        consent_no_store=True,
        consent_no_redistribute=True,
    ) as ia:
        mode = stat.S_IMODE(ia.path.stat().st_mode)
        assert mode == 0o600, f"expected 0o600 on tmp copy, got 0o{mode:o}"


def test_ingest_refuses_protected_symlink(tmp_path: Path, monkeypatch) -> None:
    """A symlink pointing at a protected reference path must be refused.

    The privacy guard's substring match runs against the resolved path, so
    a symlink ``decoy.wav -> /private/protected_voice_dummy.wav`` is caught at
    step 1, before any tmp work happens.
    """
    target = tmp_path / "protected_voice_dummy.wav"
    target.write_bytes(b"\x00" * 8)
    link = tmp_path / "decoy.wav"
    link.symlink_to(target)
    from vocaboot.privacy import ProtectedReferenceError

    with pytest.raises(ProtectedReferenceError), ingest(
        link,
        intent="reference",
        consent_no_store=True,
        consent_no_redistribute=True,
    ):
        pytest.fail("must not enter the body for a protected symlink")


def test_ingest_refuses_non_regular_file(tmp_path: Path) -> None:
    """FIFO / device files must be rejected before copy (no infinite block)."""
    if sys.platform == "win32":
        pytest.skip("POSIX FIFO not available on Windows")
    fifo = tmp_path / "audio.fifo"
    os.mkfifo(str(fifo))
    with pytest.raises(ValueError, match="non-regular"), ingest(
        fifo,
        intent="reference",
        consent_no_store=True,
        consent_no_redistribute=True,
    ):
        pytest.fail("must refuse FIFO before yielding")


def test_museum_key_map_uses_redact_keys() -> None:
    """The fixed key map must contain only keys in ``_USER_AUDIO_REDACT_KEYS``.

    Otherwise the museum redaction contract is silently broken for ingest
    failure entries.
    """
    from vocaboot.museum import _USER_AUDIO_REDACT_KEYS

    for intent, key in _MUSEUM_KEY_MAP.items():
        assert key in _USER_AUDIO_REDACT_KEYS, (
            f"intent={intent!r} maps to {key!r}, which is not in "
            f"_USER_AUDIO_REDACT_KEYS — museum redaction would fail"
        )


def test_museum_key_for_rejects_unknown_intent() -> None:
    """``museum_key_for`` must raise on unknown intents to fail fast."""
    with pytest.raises(ValueError, match="unknown ingest intent"):
        museum_key_for("training")  # type: ignore[arg-type]


def test_resolve_consent_reads_env_var(monkeypatch) -> None:
    """env vars (``VOCABOOT_CONSENT_*=1``) must work as a CLI flag substitute."""
    monkeypatch.setenv(_CONSENT_NO_STORE_ENV, "1")
    monkeypatch.setenv(_CONSENT_NO_REDISTRIBUTE_ENV, "true")
    assert audio_ingest.resolve_consent_no_store(False) is True
    assert audio_ingest.resolve_consent_no_redistribute(False) is True

    monkeypatch.setenv(_CONSENT_NO_STORE_ENV, "0")
    monkeypatch.delenv(_CONSENT_NO_REDISTRIBUTE_ENV, raising=False)
    assert audio_ingest.resolve_consent_no_store(False) is False
    assert audio_ingest.resolve_consent_no_redistribute(False) is False


def test_resolve_consent_cli_flag_or_env_var(monkeypatch) -> None:
    """CLI flag and env var combine via OR — either alone is enough."""
    monkeypatch.delenv(_CONSENT_NO_STORE_ENV, raising=False)
    assert audio_ingest.resolve_consent_no_store(True) is True
    monkeypatch.setenv(_CONSENT_NO_STORE_ENV, "1")
    assert audio_ingest.resolve_consent_no_store(False) is True


# ---------------------------------------------------------------------------
# CLI E2E (Stage 2 acceptance criterion #3)
# ---------------------------------------------------------------------------


def test_cli_ingest_refuses_without_consent_flags(tmp_path: Path) -> None:
    """``vocaboot ingest`` with no consent flags must exit 7 + write museum entry.

    Criterion #3: museum entry must redact the audio path under the
    user-audio key, end-to-end through the CLI surface.
    """
    audio = _make_audio(tmp_path, name="user_personal_recording.wav")
    failures_root = tmp_path / "_failures"

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "ingest",
            str(audio),
            "--intent",
            "reference",
            "--failures-root",
            str(failures_root),
        ],
        env={"VOCABOOT_CONSENT_NO_STORE": "", "VOCABOOT_CONSENT_NO_REDISTRIBUTE": ""},
    )
    assert result.exit_code == 7, (
        f"expected exit 7 (consent refuse), got {result.exit_code}: {result.output}"
    )
    assert "consent_no_store" in result.output
    assert "consent_no_redistribute" in result.output

    # museum entry written, audio path fully redacted under reference_voice_path.
    entries = list(failures_root.iterdir())
    assert len(entries) == 1
    payload = json.loads((entries[0] / "metadata.json").read_text(encoding="utf-8"))
    assert payload["detail"]["reference_voice_path"] == "<redacted-user-audio>"
    assert payload["reason"].startswith("stage_2_consent_refused_")
    # The basename must NOT appear anywhere in metadata.json.
    metadata_text = (entries[0] / "metadata.json").read_text(encoding="utf-8")
    assert "user_personal_recording.wav" not in metadata_text


def test_cli_ingest_target_intent_uses_target_voice_path_key(tmp_path: Path) -> None:
    """intent=target must route the museum redact-key to target_voice_path."""
    audio = _make_audio(tmp_path, name="training_voice_sample.wav")
    failures_root = tmp_path / "_failures"

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "ingest",
            str(audio),
            "--intent",
            "target",
            "--failures-root",
            str(failures_root),
        ],
        env={"VOCABOOT_CONSENT_NO_STORE": "", "VOCABOOT_CONSENT_NO_REDISTRIBUTE": ""},
    )
    assert result.exit_code == 7
    entries = list(failures_root.iterdir())
    payload = json.loads((entries[0] / "metadata.json").read_text(encoding="utf-8"))
    assert "target_voice_path" in payload["detail"]
    assert payload["detail"]["target_voice_path"] == "<redacted-user-audio>"
    assert "reference_voice_path" not in payload["detail"]


def test_cli_ingest_succeeds_with_both_consent_flags(tmp_path: Path) -> None:
    """Both flags + valid audio → exit 0 + stdout shows tmp path + sha prefix."""
    audio = _make_audio(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "ingest",
            str(audio),
            "--intent",
            "reference",
            "--consent-no-store",
            "--consent-no-redistribute",
        ],
        env={"VOCABOOT_CONSENT_NO_STORE": "", "VOCABOOT_CONSENT_NO_REDISTRIBUTE": ""},
    )
    assert result.exit_code == 0, f"got exit {result.exit_code}: {result.output}"
    assert "ingest ok" in result.output
    assert "sha256=" in result.output
    # The temp dir is gone now; the path printed referenced it but won't exist.


def test_cli_ingest_consent_env_vars_substitute_for_flags(tmp_path: Path) -> None:
    """``VOCABOOT_CONSENT_*=1`` env vars must replace the CLI flags entirely."""
    audio = _make_audio(tmp_path)
    runner = CliRunner()
    result = runner.invoke(
        main,
        ["ingest", str(audio), "--intent", "reference"],
        env={
            "VOCABOOT_CONSENT_NO_STORE": "1",
            "VOCABOOT_CONSENT_NO_REDISTRIBUTE": "1",
        },
    )
    assert result.exit_code == 0, f"got exit {result.exit_code}: {result.output}"
    assert "ingest ok" in result.output


def test_cli_ingest_help_documents_mcp_boundary_via_flag_help() -> None:
    """The help text must surface the env var fallback names (audit trail aid)."""
    runner = CliRunner()
    result = runner.invoke(main, ["ingest", "--help"])
    assert result.exit_code == 0
    for token in (
        "--intent",
        "--consent-no-store",
        "--consent-no-redistribute",
        "VOCABOOT_CONSENT_NO_STORE",
        "VOCABOOT_CONSENT_NO_REDISTRIBUTE",
        "--accept-nc",  # cross-reference to the synth-time act
    ):
        assert token in result.output, f"help missing {token!r}"
