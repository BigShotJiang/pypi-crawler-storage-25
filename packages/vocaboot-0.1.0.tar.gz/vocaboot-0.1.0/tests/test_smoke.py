"""Smoke tests for the vocaboot package scaffold."""

from __future__ import annotations

import json
from pathlib import Path

from click.testing import CliRunner

import vocaboot
from vocaboot.cli import main

REPO_ROOT = Path(__file__).resolve().parent.parent


def test_version() -> None:
    assert isinstance(vocaboot.__version__, str)
    assert vocaboot.__version__.count(".") == 2


def test_cli_version_flag() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert vocaboot.__version__ in result.output


def test_cli_help_lists_subcommands() -> None:
    """Top-level ``vocaboot --help`` must list both synth and demo subcommands."""
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    for sub in ("synth", "demo"):
        assert sub in result.output


def test_cli_synth_help_lists_required_flags() -> None:
    """``vocaboot synth --help`` keeps the original Stage 1 flag set."""
    runner = CliRunner()
    result = runner.invoke(main, ["synth", "--help"])
    assert result.exit_code == 0
    for flag in ("--engine", "--voice", "--score", "--out"):
        assert flag in result.output


def test_cli_demo_help_documents_mandatory_accept_nc() -> None:
    """The demo subcommand help must surface the NC mandatory consent."""
    runner = CliRunner()
    result = runner.invoke(main, ["demo", "--help"])
    assert result.exit_code == 0
    assert "--accept-nc" in result.output


def test_cli_rejects_protected_voice_path(tmp_path) -> None:
    fake_ckpt = tmp_path / "protected_voice_dummy.onnx"
    fake_ckpt.write_bytes(b"")
    fake_score = tmp_path / "score.ds"
    fake_score.write_text("{}")
    runner = CliRunner()
    result = runner.invoke(
        main, ["synth", "--voice", str(fake_ckpt), "--score", str(fake_score)]
    )
    assert result.exit_code == 2
    assert "protected reference pattern" in result.output


def test_example_short_ds_is_valid_json() -> None:
    """examples/short.ds is the canonical Stage 1 smoke input. Must stay JSON-parseable
    *and* internally consistent: ph_seq/ph_dur token counts agree, note_seq/note_dur
    token counts agree, and sum(ph_dur) == sum(note_dur). The 5-second budget keeps
    the smoke run CPU-feasible.
    """
    short_ds = REPO_ROOT / "examples" / "short.ds"
    assert short_ds.exists(), "examples/short.ds is the locked-in Stage 1 smoke score"
    payload = json.loads(short_ds.read_text(encoding="utf-8"))
    assert isinstance(payload, list) and len(payload) == 1
    entry = payload[0]
    for required in ("ph_seq", "ph_dur", "note_seq", "note_dur", "note_slur", "lang", "license"):
        assert required in entry, f"short.ds missing required field {required!r}"
    assert entry["license"] in {"CC0-1.0", "CC0", "Apache-2.0", "MIT", "CC-BY-4.0"}

    ph_seq = entry["ph_seq"].split()
    ph_dur = [float(x) for x in entry["ph_dur"].split()]
    note_seq = entry["note_seq"].split()
    note_dur = [float(x) for x in entry["note_dur"].split()]
    note_slur = entry["note_slur"].split()

    assert len(ph_seq) == len(ph_dur), "ph_seq and ph_dur must have equal token counts"
    assert len(note_seq) == len(note_dur) == len(note_slur), (
        "note_seq, note_dur, note_slur must have equal token counts"
    )
    assert abs(sum(ph_dur) - sum(note_dur)) < 1e-6, (
        f"ph_dur total ({sum(ph_dur)}) must equal note_dur total ({sum(note_dur)})"
    )
    assert abs(sum(note_dur) - 5.0) < 1e-6, (
        f"smoke score is locked to 5.0s for CPU feasibility; got {sum(note_dur)}s"
    )


def test_numeric_verdict_rules() -> None:
    """The numeric-only verdict: all pass → APPROVE, any determined-fail → REJECT.

    Step 5e (2026-05-12): the prior aggregate(agent_a, agent_b) rule was
    removed when --verify=agent was deleted (Round-26-style LLM-as-judge
    fragility applied to Agent A). The new gate is a single-axis judgement.
    """
    from vocaboot.agent_verify import Verdict, _numeric_verdict
    from vocaboot.metrics import MetricResult

    def _mk(
        name: str,
        value: float,
        ci_low: float,
        ci_high: float,
        threshold: float,
        direction: str = "higher_better",
    ) -> MetricResult:
        return MetricResult(
            name=name,
            value=value,
            ci_low=ci_low,
            ci_high=ci_high,
            threshold=threshold,
            direction=direction,
        )

    # Both pass: f0_stability (lower_better) CI strictly below 0.02, hnr (higher_better) CI strictly above 0 → APPROVE.
    f0_pass = _mk("f0_stability", 0.01, 0.005, 0.015, 0.02, "lower_better")
    hnr_pass = _mk("hnr", 6.0, 4.0, 8.0, 0.0)
    assert _numeric_verdict((f0_pass, hnr_pass)) is Verdict.APPROVE

    # One determined-fail: f0 CI strictly above 0.02 (jitter exceeds 2 %) → REJECT.
    f0_fail = _mk("f0_stability", 0.05, 0.04, 0.06, 0.02, "lower_better")
    assert _numeric_verdict((f0_fail, hnr_pass)) is Verdict.REJECT

    # One undetermined (CI straddles 0.02) → REVIEW.
    f0_straddle = _mk("f0_stability", 0.02, 0.01, 0.03, 0.02, "lower_better")
    assert _numeric_verdict((f0_straddle, hnr_pass)) is Verdict.REVIEW


def test_metrics_bootstrap_ci_basic() -> None:
    """bootstrap_ci returns a finite, ordered CI for a simple Gaussian sample."""
    import numpy as np

    from vocaboot.metrics import bootstrap_ci

    rng = np.random.default_rng(42)
    samples = rng.normal(loc=1.0, scale=0.1, size=200)
    lo, hi = bootstrap_ci(samples, n_resamples=300, rng=np.random.default_rng(0))
    assert lo < hi
    assert 0.9 < lo < 1.0 < hi < 1.1


def test_metric_f0_stability_approves_clean_harmonic() -> None:
    """A clean harmonic 220 Hz signal must read as F0-stable with a tight CI."""
    import pytest

    pytest.importorskip("pyworld")
    import numpy as np

    from vocaboot.metrics import f0_stability

    sr = 44100
    t = np.arange(2 * sr) / sr
    sig = np.zeros_like(t)
    for k in range(1, 6):
        sig += (1.0 / k) * np.sin(2 * np.pi * k * 220.0 * t)
    sig = (0.3 * sig).astype(np.float32)

    result = f0_stability(sig, sr, rng=np.random.default_rng(0))
    assert result.name == "f0_stability"
    assert result.threshold == 0.02
    assert result.direction == "lower_better"
    assert result.is_determined
    assert result.passes  # CI entirely below 0.02 (jitter < 2 %)


def test_metric_hnr_approves_clean_harmonic() -> None:
    """A clean harmonic 220 Hz signal must read as harmonic-dominant (HNR > 0)."""
    import pytest

    pytest.importorskip("pyworld")
    import numpy as np

    from vocaboot.metrics import hnr

    sr = 44100
    t = np.arange(2 * sr) / sr
    sig = np.zeros_like(t)
    for k in range(1, 6):
        sig += (1.0 / k) * np.sin(2 * np.pi * k * 220.0 * t)
    sig = (0.3 * sig).astype(np.float32)

    result = hnr(sig, sr, rng=np.random.default_rng(0))
    assert result.name == "hnr"
    assert result.threshold == 0.0
    assert result.is_determined
    assert result.passes


def test_metrics_return_undetermined_on_silence() -> None:
    """Silence has no voiced frames; metrics must surface REVIEW (CI straddles)."""
    import pytest

    pytest.importorskip("pyworld")
    import numpy as np

    from vocaboot.metrics import f0_stability, hnr

    sr = 44100
    silence = np.zeros(2 * sr, dtype=np.float32)

    f0_result = f0_stability(silence, sr)
    assert not f0_result.is_determined, "silence f0_stability must be undetermined"

    hnr_result = hnr(silence, sr)
    assert not hnr_result.is_determined, "silence hnr must be undetermined"


def test_input_rejects_empty_ph_dur(tmp_path) -> None:
    """load_ds must refuse a score with empty ph_dur/note_dur to prevent IndexError downstream."""
    import json

    from vocaboot.input import ScoreFormatError, load_ds

    empty = tmp_path / "empty.ds"
    empty.write_text(
        json.dumps(
            [
                {
                    "offset": 0.0,
                    "text": "",
                    "ph_seq": "",
                    "ph_dur": "",
                    "note_seq": "",
                    "note_dur": "",
                    "note_slur": "",
                    "lang": "ja",
                    "license": "CC0-1.0",
                }
            ]
        )
    )
    try:
        load_ds(empty)
    except ScoreFormatError as e:
        assert "non-empty" in str(e)
    else:
        raise AssertionError("load_ds should have raised ScoreFormatError")


def test_stage_2_spec_exists_and_names_acceptance_criteria() -> None:
    """Stage 1.5-E + R14-round-2: docs/stage_2.md must define Stage 2 scope.

    The Stage 1.5 R14 debate concluded that 'Stage 2 → Stage 3 → Stage 4' as a
    roadmap label is not a spec. R14-round-2 (2026-05-12) added: license-clean
    voice acquisition (step 0a), [verify-similarity] extra (step 0b),
    contextmanager surface (R1), MCD sign reversal (R2), VoiceProfile
    immutability (R3), SpeakerSimilarityProtocol (R4), Stage 3 contract (R5).
    """
    spec = REPO_ROOT / "docs" / "stage_2.md"
    assert spec.exists(), "docs/stage_2.md is the Stage 1.5-E artifact"
    text = spec.read_text(encoding="utf-8")
    for required in (
        "profile_match",
        "audio_ingest",
        "VoiceProfile",
        "Tier 2",
        "mcd",
        "wavlm_cosine",
        "Acceptance criteria",
        "consent",
        "Stage 2.5",
        "Out of scope",
        # R14-round-2 markers (regression防止):
        "step 0",
        "Common Voice",
        "verify-similarity",
        "contextlib.contextmanager",
        "wavlm_embedding_bytes",     # R3 immutability
        "SpeakerSimilarityProtocol",  # R4 Stage 3 contract
        "schema_version",            # R3 forward-compat
    ):
        assert required in text, f"docs/stage_2.md missing literal {required!r}"


def test_pyproject_declares_verify_similarity_extra() -> None:
    """R14-round-2 F1 regression guard: [verify-similarity] extra MUST be declared.

    Round-2 surfaced that ``agent_verify.py`` + ``docs/quality_gate.md`` +
    ``docs/stage_2.md`` all claimed the extra was 'already declared' while
    ``pyproject.toml`` had only ``[verify]`` — a textbook R17 §4 phantom claim.
    This test pins the fix so future doc/code edits cannot drift back.
    """
    pyproject = REPO_ROOT / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    assert "verify-similarity = [" in text, (
        "pyproject.toml must declare the [verify-similarity] extra "
        "(Stage 2 step 0b precondition)"
    )
    # WavLM (transformers) is the load-bearing dep; if it's missing the
    # extra is declared but useless.
    assert "transformers" in text


def test_examples_voice_dir_carries_license_policy() -> None:
    """Stage 2 step 0a: examples/voice/ must hold a license policy README.

    The Stage 2 wire-in PR can pick from the surveyed sources, but it
    cannot pick *anything* — only entries from the allow-list. The README
    is the contract; this test guards against a silent deletion of the
    policy doc that would re-open the acquisition gap.
    """
    voice_dir = REPO_ROOT / "examples" / "voice"
    assert voice_dir.is_dir(), "examples/voice/ is the Stage 2 step 0a artifact"
    readme = voice_dir / "README.md"
    assert readme.exists(), "examples/voice/README.md is the license policy"
    text = readme.read_text(encoding="utf-8")
    for required in (
        "License",
        "CC0",
        "CC-BY",
        "sha256",
        "Stage 2 PR1b",                       # PR1b section anchor (renamed from "wire-in PR responsibility" at R14 round-7 path confirmation)
        "tier2_reference_ja.wav",             # canonical PR1b artifact filename (round-8: engine-name-leak-free)
        "Open JTalk",                         # chosen synthesis engine (round-7 ACCEPT Path B)
        "CC-BY-3.0",                          # voice data license (allow-list-extended at round-7/8)
        "Mozilla Common Voice",               # surveyed-source fallback row
        "JVS",                                # retracted-source row (kept for audit trail)
        "_USER_AUDIO_REDACT_KEYS",            # speaker-ID redaction policy linkage
    ):
        assert required in text, f"examples/voice/README.md missing literal {required!r}"


def test_ckpt_registry_pins_wavlm_for_stage2() -> None:
    """Stage 2 R14-round-2 criterion 8: docs/ckpt_registry.md must contract WavLM.

    The pin sha256 may still be ``<PINNED-AT-STAGE-2-WIRE-IN>`` (the Stage 2
    PR fills it in), but the registry entry, license, cache path, and runtime
    verification contract must all be present so the supply chain is auditable
    end-to-end before any code touches Tier 2.
    """
    registry = REPO_ROOT / "docs" / "ckpt_registry.md"
    text = registry.read_text(encoding="utf-8")
    for required in (
        "wavlm-base",
        "Tier 2 verify",
        "verify-similarity",
        "~/.cache/vocaboot/models/wavlm-base",
        "MIT",
    ):
        assert required in text, f"ckpt_registry.md missing WavLM pin literal {required!r}"


def test_quality_gate_doc_exists_and_defines_tier_ladder() -> None:
    """docs/quality_gate.md is the operational definition of '最高の完成'.

    Stage 1.5-C requires a tier ladder (Tier 1 — rings, Tier 2 — voice-like,
    Tier 3 — target-quality, Tier 4 — out of scope) with thresholds tied to
    bootstrap CIs (R5). Without this doc, '最高' is a phantom adjective and
    Stage 2+ closure claims become unverifiable (R17 §3).
    """
    gate = REPO_ROOT / "docs" / "quality_gate.md"
    assert gate.exists(), "docs/quality_gate.md is the Stage 1.5-C artifact"
    text = gate.read_text(encoding="utf-8")
    for required in (
        "Tier 1",
        "Tier 2",
        "Tier 3",
        "Tier 4",
        "f0_stability",
        "hnr",
        "mcd",
        "wavlm_cosine",
        "speaker_cosine",
        "vuv_f1",
        "bootstrap CI",
        "out of scope",
        "MetricResult",
    ):
        assert required in text, f"docs/quality_gate.md missing literal {required!r}"


def test_ckpt_registry_doc_exists_and_forbids_nc_by_default() -> None:
    """docs/ckpt_registry.md must encode the architect Round 35 license rules."""
    registry = REPO_ROOT / "docs" / "ckpt_registry.md"
    assert registry.exists(), "docs/ckpt_registry.md is the architect Round 35 step-2 artifact"
    text = registry.read_text(encoding="utf-8")
    for required in (
        "Apache-2.0",
        "MIT",
        "CC-BY-4.0",
        "CC0",
        "CC-BY-NC-SA",
        "sha256",
        "license_check",
    ):
        assert required in text, f"ckpt_registry.md missing literal {required!r}"


def test_ckpt_registry_names_chosen_acquisition_path() -> None:
    """Stage 1.5-D: docs/ckpt_registry.md must name an explicit acquisition path.

    The release plan has to pick one of {A: wait, B: NC-only public, C: self-train kit}
    or the OSS-release gate becomes phantom. Stage 1.5 selected Path B; this test
    pins that decision so future doc rewrites cannot quietly drop the exit strategy.
    """
    registry = REPO_ROOT / "docs" / "ckpt_registry.md"
    text = registry.read_text(encoding="utf-8")
    for required in (
        "Acquisition path decision",
        "Path A",
        "Path B",
        "Path C",
        "Path B",
        "self-train",
    ):
        assert required in text, f"ckpt_registry.md missing literal {required!r}"
    # The chosen path must be explicit. "Path B" alone is ambiguous; the
    # commitment phrase ("chosen") must appear near "Path B".
    assert "chosen" in text.lower(), "acquisition path decision must be explicit"
