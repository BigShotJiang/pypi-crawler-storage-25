"""User-audio guard tests (Stage 1.5-B, pre-Stage-2).

Validates two new Stage 2 prerequisites:

  * :func:`vocaboot.privacy.refuse_user_audio_without_consent` — both
    consent flags (``no_store`` + ``no_redistribute``) must be True or
    the function raises ``ConsentRequiredError``.
  * :mod:`vocaboot.museum` redacts ``user_voice`` / ``target_voice`` /
    ``reference_voice`` / ``any_song`` keyed values to
    ``"<redacted-user-audio>"`` — not even the basename leaks.

The Stage 2 CLI surface (``--consent-no-store`` etc.) is *not* wired in
Stage 1.5; only the underlying function + museum behavior land here so
the Stage 2 build cannot accidentally bypass the gate.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest


def test_refuse_user_audio_blocks_when_both_flags_missing(tmp_path: Path) -> None:
    """Default (both flags False) must refuse with both names in the message."""
    from vocaboot.privacy import ConsentRequiredError, refuse_user_audio_without_consent

    audio = tmp_path / "song.wav"
    audio.write_bytes(b"\x00\x00")
    with pytest.raises(ConsentRequiredError) as exc:
        refuse_user_audio_without_consent(
            audio, consent_no_store=False, consent_no_redistribute=False
        )
    msg = str(exc.value)
    assert "consent_no_store" in msg
    assert "consent_no_redistribute" in msg
    assert "reference" in msg  # default intent


def test_refuse_user_audio_blocks_when_one_flag_missing(tmp_path: Path) -> None:
    """Either flag alone is insufficient — both are mandatory."""
    from vocaboot.privacy import ConsentRequiredError, refuse_user_audio_without_consent

    audio = tmp_path / "song.wav"
    audio.write_bytes(b"\x00\x00")

    with pytest.raises(ConsentRequiredError, match="consent_no_redistribute"):
        refuse_user_audio_without_consent(
            audio, consent_no_store=True, consent_no_redistribute=False
        )

    with pytest.raises(ConsentRequiredError, match="consent_no_store"):
        refuse_user_audio_without_consent(
            audio, consent_no_store=False, consent_no_redistribute=True
        )


def test_refuse_user_audio_passes_with_full_consent(tmp_path: Path) -> None:
    """Both flags True → no-op (no exception, no return value)."""
    from vocaboot.privacy import refuse_user_audio_without_consent

    audio = tmp_path / "song.wav"
    audio.write_bytes(b"\x00\x00")
    # Must not raise.
    refuse_user_audio_without_consent(
        audio, consent_no_store=True, consent_no_redistribute=True
    )


def test_refuse_user_audio_intent_appears_in_error(tmp_path: Path) -> None:
    """``intent='target'`` (self-train SVS) must surface in the message."""
    from vocaboot.privacy import ConsentRequiredError, refuse_user_audio_without_consent

    audio = tmp_path / "self.wav"
    audio.write_bytes(b"\x00\x00")
    with pytest.raises(ConsentRequiredError, match="target"):
        refuse_user_audio_without_consent(
            audio,
            consent_no_store=False,
            consent_no_redistribute=False,
            intent="target",
        )


def test_museum_redacts_user_voice_path(tmp_path: Path) -> None:
    """``user_voice_path`` key must be redacted to ``"<redacted-user-audio>"``.

    Not ``{basename, sha256}`` — full redaction. A basename like
    ``alice_voice_20260512.wav`` is identifying on its own.
    """
    from vocaboot import museum

    secret = tmp_path / "alice_personal_recording.wav"
    secret.write_bytes(b"\x00\x00")

    entry = museum.archive_failure(
        root=tmp_path / "_failures",
        reason="test_user_voice_redact",
        detail={
            "user_voice_path": str(secret),
            "score_path": str(secret),  # for comparison: this key gets the usual scrub
        },
    )
    payload = json.loads((entry / "metadata.json").read_text(encoding="utf-8"))

    # user_voice_path: full redaction.
    assert payload["detail"]["user_voice_path"] == "<redacted-user-audio>"

    # score_path: usual {basename, sha256} scrub still applies.
    assert isinstance(payload["detail"]["score_path"], dict)
    assert payload["detail"]["score_path"]["basename"] == "alice_personal_recording.wav"

    # The user-audio basename must NOT leak through metadata text under user_voice_path.
    metadata_text = (entry / "metadata.json").read_text(encoding="utf-8")
    # score_path leaks basename (intentional, that's the documented Stage 1 behavior);
    # but user_voice_path must be fully redacted.
    assert metadata_text.count("alice_personal_recording.wav") == 1, (
        "user_voice_path must NOT contribute a basename occurrence"
    )


def test_museum_redacts_all_user_audio_key_variants(tmp_path: Path) -> None:
    """All Stage 2 input-key variants must trigger the hard-exclude rule."""
    from vocaboot import museum

    detail = {
        "user_voice_path": "/private/user/voice.wav",
        "user_voice": "/private/user/voice2.wav",
        "target_voice_path": "/private/target.wav",
        "target_voice": "/private/target2.wav",
        "reference_voice_path": "/private/ref.wav",
        "reference_voice": "/private/ref2.wav",
        "any_song_path": "/private/song.wav",
        "any_song": "/private/song2.wav",
    }
    entry = museum.archive_failure(
        root=tmp_path / "_failures",
        reason="test_all_variants",
        detail=detail,
    )
    payload = json.loads((entry / "metadata.json").read_text(encoding="utf-8"))
    for key in detail:
        assert payload["detail"][key] == "<redacted-user-audio>", (
            f"{key} must be fully redacted, got {payload['detail'][key]}"
        )
