"""``librosa`` version pin must stay in the documented range.

R14 round-9 R17 audit (2026-05-12) raised this as a remaining gap: the
``metrics.py`` MFCC pins (``MFCC_*`` 16 constants) rely on librosa's
default ``mel_norm='slaney'`` and ``dct_type=2 norm='ortho'`` behaviour.
A librosa 1.x release could change those defaults silently, drifting the
canary calibration without sha256 / threshold mismatches firing.

Asserting the pyproject ``librosa>=0.10,<1`` range in a test makes the
upgrade an explicit, reviewable decision: lifting to ``librosa>=1`` would
fail this test, forcing a re-calibration of the canary distribution and
the MFCC pin constants (or a re-evaluation of the B2 probe in task #88
that picks pysptk.mcep over librosa.feature.mfcc altogether).
"""

from __future__ import annotations

import re
from pathlib import Path

_PYPROJECT = Path(__file__).resolve().parent.parent / "pyproject.toml"
_EXPECTED_LIBROSA_PIN = "librosa>=0.10,<1"


def test_librosa_pin_present_in_pyproject() -> None:
    """``pyproject.toml`` must declare the librosa version pin verbatim.

    Both `[verify-similarity]` and `[svc]` extras carry this dependency
    (per pyproject L38 + L70) — a future cleanup that removes one extra's
    librosa dep must still leave the other in place because the MFCC
    pin contract spans both verify and downstream SVC code paths.
    """
    text = _PYPROJECT.read_text(encoding="utf-8")
    count = len(re.findall(re.escape(_EXPECTED_LIBROSA_PIN), text))
    assert count >= 2, (
        f"pyproject.toml must declare {_EXPECTED_LIBROSA_PIN!r} in at least 2 "
        f"places ([verify-similarity] + [svc] extras); found {count}. "
        "If a librosa upgrade is intentional, update metrics._MCD_THRESHOLD_*, "
        "re-calibrate the canary distribution, and refresh this test together."
    )


def test_no_librosa_1x_in_pyproject() -> None:
    """Guard against silent librosa 1.x adoption.

    Any text matching ``librosa>=1`` or ``librosa==1`` (without the ``<1``
    ceiling) would mean a librosa-1 dependency landed without re-calibration.
    """
    text = _PYPROJECT.read_text(encoding="utf-8")
    forbidden = re.compile(r'librosa\s*(>=|==)\s*1(?!\s*,?\s*<)', re.IGNORECASE)
    m = forbidden.search(text)
    assert m is None, (
        f"pyproject.toml declares a librosa 1.x dependency: {m.group()!r}. "
        "MFCC default behaviour (mel_norm, DCT scaling) may have changed; "
        "re-calibrate the canary distribution and the threshold constants "
        "before lifting the pin (or adopt the B2 probe path with pysptk.mcep)."
    )
