"""MFCC parameter pin consistency (Stage 2 step 3b, R14 round-9 analyst gap).

The librosa MFCC parameters used by ``profile_match.build`` (reference
voice) and ``agent_verify`` Tier 2 path (candidate output) MUST stay
parameter-identical — drift between the two arms would silently turn MCD
into a "different settings" artifact instead of a real voice distance.
The pin pattern follows ``tests/test_ckpt_registry_pin_consistency.py``:
public module constants are the single source of truth, and the tests
assert their values against a frozen baseline. Any intentional bump
updates both the constants and the assertions in the same commit so a
review surfaces the change explicitly.
"""

from __future__ import annotations

import inspect

import numpy as np
import pytest

from vocaboot import metrics

_PINNED_MFCC_PARAMS: dict[str, object] = {
    "MFCC_SAMPLE_RATE": 16000,
    "MFCC_N_COEF": 25,
    "MFCC_N_FFT": 400,
    "MFCC_HOP_LENGTH": 160,
    "MFCC_WIN_LENGTH": 400,
    "MFCC_N_MELS": 80,
    "MFCC_WINDOW": "hann",
    "MFCC_POWER": 2.0,
    "MFCC_FMIN": 0.0,
    "MFCC_FMAX": None,
    "MFCC_DCT_TYPE": 2,
    "MFCC_NORM": "ortho",
    "MFCC_HTK": False,
    "MFCC_LIFTER": 0,
    "MFCC_CENTER": True,
    "MFCC_PAD_MODE": "constant",
}


_MISSING = object()


def test_mfcc_constants_match_pinned_baseline() -> None:
    """Each ``MFCC_*`` constant must match the frozen baseline.

    Drift in any single parameter changes the cepstrogram that
    ``profile_match.build`` and ``agent_verify`` Tier 2 path produce;
    an intentional bump requires updating both the metrics constant
    and ``_PINNED_MFCC_PARAMS`` in the same commit so a reviewer
    sees the change explicitly.
    """
    for name, expected in _PINNED_MFCC_PARAMS.items():
        actual = getattr(metrics, name, _MISSING)
        assert actual is not _MISSING, (
            f"metrics.{name} not exported — pin must remain a public "
            f"module constant so this drift test can lock it."
        )
        assert actual == expected, (
            f"metrics.{name} drifted: pinned baseline={expected!r}, "
            f"runtime={actual!r}. Update both metrics.{name} and "
            f"_PINNED_MFCC_PARAMS in the same commit."
        )


def test_mfcc_mcd_uses_mfcc_n_coef_symbolically() -> None:
    """``mcd`` must reference ``MFCC_N_COEF`` rather than a numeric literal.

    The MCD validator (``a_mfcc.shape[1] >= MFCC_N_COEF``) and slice
    (``[:, _MCD_COEF_LO:MFCC_N_COEF]``) drift safely only if both sides
    of the bound use the same symbol — a hard-coded ``25`` in ``mcd``
    would silently de-link from the pin.
    """
    src = inspect.getsource(metrics.mcd)
    assert "MFCC_N_COEF" in src, (
        "metrics.mcd must reference MFCC_N_COEF for its coefficient "
        "validation / slice — a numeric literal would drift silently."
    )


def test_mfcc_sample_rate_is_the_wavlm_input_rate_source_of_truth() -> None:
    """``MFCC_SAMPLE_RATE`` must be the single source of truth for 16 kHz.

    ``profile_match`` re-exports the same value as a module-private alias
    (``_WAVLM_SAMPLE_RATE``) by importing from ``metrics``. A drift between
    the two would mean MFCC and WavLM describe different time grids,
    breaking MCD framing.
    """
    from vocaboot import profile_match

    assert profile_match._WAVLM_SAMPLE_RATE is metrics.MFCC_SAMPLE_RATE
    assert metrics.MFCC_SAMPLE_RATE == 16000


def test_mfcc_extract_passes_pinned_kwargs_to_librosa(monkeypatch) -> None:
    """``mfcc_extract`` must forward every pinned kwarg to ``librosa.feature.mfcc``.

    The constants alone do not prove the librosa call uses them — a
    refactor that drops one keyword would leave the constant in place but
    silently fall back to the librosa default. This test patches
    ``librosa.feature.mfcc`` to capture the actual kwargs, then asserts
    each pinned value reaches librosa.
    """
    librosa = pytest.importorskip("librosa")

    captured: dict[str, object] = {}
    real_mfcc = librosa.feature.mfcc

    def spy(*args, **kwargs):
        captured.update(kwargs)
        return real_mfcc(*args, **kwargs)

    monkeypatch.setattr(librosa.feature, "mfcc", spy)

    audio = np.zeros(metrics.MFCC_SAMPLE_RATE, dtype=np.float32)
    metrics.mfcc_extract(audio)

    expected = {
        "sr": metrics.MFCC_SAMPLE_RATE,
        "n_mfcc": metrics.MFCC_N_COEF,
        "n_fft": metrics.MFCC_N_FFT,
        "hop_length": metrics.MFCC_HOP_LENGTH,
        "win_length": metrics.MFCC_WIN_LENGTH,
        "n_mels": metrics.MFCC_N_MELS,
        "window": metrics.MFCC_WINDOW,
        "power": metrics.MFCC_POWER,
        "fmin": metrics.MFCC_FMIN,
        "fmax": metrics.MFCC_FMAX,
        "dct_type": metrics.MFCC_DCT_TYPE,
        "norm": metrics.MFCC_NORM,
        "htk": metrics.MFCC_HTK,
        "lifter": metrics.MFCC_LIFTER,
        "center": metrics.MFCC_CENTER,
        "pad_mode": metrics.MFCC_PAD_MODE,
    }
    for key, value in expected.items():
        assert key in captured, f"librosa.feature.mfcc was not called with {key!r}"
        assert captured[key] == value, (
            f"librosa.feature.mfcc got {key}={captured[key]!r}, expected {value!r}"
        )


def test_mfcc_extract_returns_time_major_n_coef() -> None:
    """``mfcc_extract`` must return ``(T_frames, MFCC_N_COEF)`` float32."""
    pytest.importorskip("librosa")
    audio = (
        np.random.default_rng(0)
        .normal(scale=0.1, size=metrics.MFCC_SAMPLE_RATE)
        .astype(np.float32)
    )
    mfcc = metrics.mfcc_extract(audio)
    assert mfcc.ndim == 2
    assert mfcc.shape[1] == metrics.MFCC_N_COEF
    assert mfcc.dtype == np.float32
    # Time axis grows with hop_length — one second of audio gives roughly
    # sr / hop_length frames (plus padding on either edge under center=True).
    expected_frames_floor = metrics.MFCC_SAMPLE_RATE // metrics.MFCC_HOP_LENGTH
    assert mfcc.shape[0] >= expected_frames_floor, (
        f"mfcc_extract returned only {mfcc.shape[0]} frames for 1 s of "
        f"audio; expected at least {expected_frames_floor}"
    )


def test_mfcc_extract_rejects_empty_or_multichannel_audio() -> None:
    """Multichannel or empty signals must raise — silent broadcast hides bugs."""
    with pytest.raises(ValueError, match="non-empty 1-D mono"):
        metrics.mfcc_extract(np.zeros(0, dtype=np.float32))
    with pytest.raises(ValueError, match="non-empty 1-D mono"):
        metrics.mfcc_extract(np.zeros((2, 1000), dtype=np.float32))
