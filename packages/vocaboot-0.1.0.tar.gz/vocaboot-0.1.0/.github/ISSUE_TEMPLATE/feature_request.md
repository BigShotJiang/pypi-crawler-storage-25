---
name: Feature request
about: Suggest a feature or change
title: ''
labels: enhancement
---

## Problem

What pain point does this address? Link to a concrete use case.

## Proposed behaviour

What you'd like vocaboot to do.

## Scope check

vocaboot's scope is intentionally narrow: terminal-first, Claude-Code-MCP-
ready SVS quality gate around third-party engines. Stage 3 (SVC) and
Stage 4 (NL) are deferred to a later release cycle and currently
out-of-scope. If your proposal lands outside the current scope, that's
fine — call it out so we can decide whether to expand scope or defer.

## Alternatives considered

Any workarounds, related projects, or upstream feature requests you
already evaluated.
