---
name: Bug report
about: Report a reproducible failure
title: ''
labels: bug
---

## Description

What happened. What you expected to happen.

## Reproduction

```bash
# exact command(s) you ran
```

## Environment

- vocaboot version: `pip show vocaboot | grep Version`
- Python version: `python --version`
- OS: linux / macos / windows + version
- Extras installed: `verify` / `verify-similarity` / ...

## Stack trace / output

```
paste full stderr here
```

## Failure museum entry (optional but helpful)

If a `_failures/<incident-id>/metadata.json` was produced, paste it here
**without** any raw audio. Audio samples are R15-protected and must be
shared out-of-band only if the maintainer requests them.
