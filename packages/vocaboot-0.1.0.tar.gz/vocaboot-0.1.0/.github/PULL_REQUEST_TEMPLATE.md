## Summary

One or two sentences. Why does this change exist?

## Changes

- bullet list of user-visible changes

## Test plan

- [ ] `ruff check src tests` clean
- [ ] `pytest -q` passes locally
- [ ] If Tier 2-touching: `pytest -q -k 'profile_match or stage2 or similarity'`
      passes with `[verify-similarity]` installed
- [ ] `CHANGELOG.md` updated under `## Unreleased`

## R15 / privacy

- [ ] No personal identifiers, user voice samples, or absolute home-directory
      paths added to source, tests, or docs
- [ ] Test fixtures use generic placeholders (e.g. `protected_voice`) — not
      real names or recordings
