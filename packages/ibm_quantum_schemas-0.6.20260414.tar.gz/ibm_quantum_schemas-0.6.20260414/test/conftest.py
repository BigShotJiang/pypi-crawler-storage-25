# This code is a Qiskit project.
#
# (C) Copyright IBM 2026.
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

"""Pytest configuration and fixtures."""

import zlib
from io import BytesIO

import pybase64
import pytest
from qiskit.circuit import Parameter, QuantumCircuit
from qiskit.qpy import QPY_VERSION
from qiskit.qpy import dump as qpy_dump
from samplomatic.ssv import SSV


def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line(
        "markers",
        "skip_if_qiskit_too_old_for_qpy: Skip test if qpy_version parameter exceeds QPY_VERSION.",
    )

    config.addinivalue_line(
        "markers",
        "skip_if_samplomatic_too_old_for_ssv: Skip test if ssv parameter exceeds SSV.",
    )


def pytest_runtest_setup(item):
    """Setup for tests."""
    # skip a test it requires a qpy_version newer than currently installed qiskit supports
    if item.get_closest_marker("skip_if_qiskit_too_old_for_qpy") is not None:
        qpy_version = item.callspec.params.get("qpy_version")
        if qpy_version is not None and qpy_version > QPY_VERSION:
            pytest.skip(
                f"qpy_version={qpy_version} exceeds QPY_VERSION={QPY_VERSION}, a newer version of "
                "qiskit is required."
            )

    # skip a test it requires an ssv newer than currently installed samplomatic supports
    if item.get_closest_marker("skip_if_samplomatic_too_old_for_ssv") is not None:
        ssv = item.callspec.params.get("ssv")
        if ssv is not None and ssv > SSV:
            pytest.skip(f"ssv={ssv} exceeds SSV={SSV}, a newer version of samplomatic is required.")


@pytest.fixture
def compressed_qpy_circuit_v13() -> str:
    """Fixture to create a base64-encoded, zlib-compressed QPY circuit (version 13).

    Returns:
        Base64-encoded string of the compressed QPY circuit data.
    """
    circuit = QuantumCircuit(2)
    circuit.h(0)
    circuit.cx(0, 1)

    buffer = BytesIO()
    qpy_dump(circuit, buffer, version=13)
    qpy_data = buffer.getvalue()
    compressed = zlib.compress(qpy_data)
    encoded = pybase64.b64encode(compressed).decode("utf-8")

    return encoded


@pytest.fixture
def valid_typed_qpy_circuit_dict_v13(compressed_qpy_circuit_v13) -> dict:
    """Fixture to create a valid TypedQpyCircuitModel dict with QPY v13.

    Args:
        compressed_qpy_circuit_v13: Base64-encoded compressed QPY circuit (version 13).

    Returns:
        Dictionary with __type__ and __value__ fields for TypedQpyCircuitModel.
    """
    return {"__type__": "QuantumCircuit", "__value__": compressed_qpy_circuit_v13}


@pytest.fixture
def compressed_qpy_circuit_v13_parametrized() -> str:
    """Fixture to create a base64-encoded, zlib-compressed QPY circuit (version 13).

    Returns:
        Base64-encoded string of the compressed QPY circuit data.
    """
    circuit = QuantumCircuit(2)
    theta = Parameter("theta")
    phi = Parameter("phi")
    gamma = Parameter("gamma")
    circuit.ry(theta, 0)
    circuit.rx(phi, 1)
    circuit.rz(gamma, 0)
    circuit.cx(0, 1)

    buffer = BytesIO()
    qpy_dump(circuit, buffer, version=13)
    qpy_data = buffer.getvalue()
    compressed = zlib.compress(qpy_data)
    encoded = pybase64.b64encode(compressed).decode("utf-8")

    return encoded


@pytest.fixture
def valid_typed_qpy_circuit_dict_v13_parametrized(compressed_qpy_circuit_v13_parametrized) -> dict:
    """Fixture to create a valid TypedQpyCircuitModel dict with QPY v13.

    Args:
        compressed_qpy_circuit_v13: Base64-encoded compressed QPY circuit (version 13).

    Returns:
        Dictionary with __type__ and __value__ fields for TypedQpyCircuitModel.
    """
    return {"__type__": "QuantumCircuit", "__value__": compressed_qpy_circuit_v13_parametrized}
