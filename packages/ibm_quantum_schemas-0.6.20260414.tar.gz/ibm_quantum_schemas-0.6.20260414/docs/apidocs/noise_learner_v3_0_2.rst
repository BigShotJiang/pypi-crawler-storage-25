.. automodule:: ibm_quantum_schemas.noise_learner_v3.version_0_2
   :no-members:
   :no-inherited-members:
   :no-special-members:
