"""
Enrich the seed ingredient cache with SMILES and computed properties.

Fetches canonical SMILES from PubChem for all ingredients that have CIDs,
then computes charge_type from SMILES patterns. This is a build-time script —
results are committed to seed_ingredients.json so users don't need to run it.

Usage:
    python scripts/enrich_seed_cache.py
    python scripts/enrich_seed_cache.py --expand   # Also add common ingredients
"""

from __future__ import annotations

import json
import sys
import time
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path

SEED_PATH = Path(__file__).parent.parent / "src" / "openmix" / "resolver" / "seed_ingredients.json"

# Rate limit: PubChem allows 5 req/sec, we'll do 3 to be safe
MIN_INTERVAL = 0.35


def fetch_smiles_by_cid(cid: int) -> str | None:
    """Fetch canonical SMILES from PubChem by CID."""
    url = (
        f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/"
        f"property/CanonicalSMILES/JSON"
    )
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        props = data.get("PropertyTable", {}).get("Properties", [])
        if props:
            return props[0].get("CanonicalSMILES")
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, OSError):
        pass
    return None


def fetch_properties_by_cid(cid: int) -> dict | None:
    """Fetch full properties from PubChem by CID."""
    url = (
        f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{cid}/"
        f"property/IsomericSMILES,CanonicalSMILES,MolecularWeight,XLogP,"
        f"HBondDonorCount,HBondAcceptorCount,TPSA/JSON"
    )
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        props = data.get("PropertyTable", {}).get("Properties", [])
        if props:
            p = props[0]
            # PubChem returns SMILES under varying field names
            smiles = (p.get("CanonicalSMILES")
                      or p.get("IsomericSMILES")
                      or p.get("SMILES")
                      or p.get("ConnectivitySMILES"))
            return {
                "smiles": smiles,
                "mw": p.get("MolecularWeight"),
                "log_p": p.get("XLogP"),
                "hbd": p.get("HBondDonorCount"),
                "hba": p.get("HBondAcceptorCount"),
                "tpsa": p.get("TPSA"),
                "pubchem_cid": cid,
            }
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, OSError):
        pass
    return None


def lookup_by_name(name: str) -> dict | None:
    """Look up an ingredient by name on PubChem (name search + property fetch)."""
    encoded = urllib.parse.quote(name)
    # Step 1: name → CID
    search_url = (
        f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/"
        f"{encoded}/cids/JSON"
    )
    try:
        req = urllib.request.Request(search_url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        cids = data.get("IdentifierList", {}).get("CID", [])
        if not cids:
            return None
        time.sleep(MIN_INTERVAL)
        # Step 2: CID → properties
        return fetch_properties_by_cid(cids[0])
    except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError, OSError):
        return None


def infer_charge(smiles: str) -> str:
    """Infer charge type from SMILES string."""
    has_neg = "[O-]" in smiles or "S(=O)(=O)[O-]" in smiles or "C(=O)[O-]" in smiles
    has_pos = "[N+]" in smiles or "[NH3+]" in smiles
    if has_neg and has_pos:
        return "amphoteric"
    elif has_neg:
        return "anionic"
    elif has_pos:
        return "cationic"
    return "nonionic"


# Common formulation ingredients to expand the cache
EXPANSION_INGREDIENTS = [
    # Surfactants & emulsifiers
    "Cocamidopropyl Betaine", "Decyl Glucoside", "Coco-Glucoside",
    "Lauryl Glucoside", "PEG-40 Hydrogenated Castor Oil",
    "Sorbitan Oleate", "Sorbitan Stearate",
    "Ceteareth-20", "Steareth-21", "Steareth-2",
    "Sodium Cocoyl Isethionate", "Sodium Cocoyl Glutamate",
    "Sodium Lauroyl Sarcosinate",
    # Actives
    "Bakuchiol", "Arbutin", "Tranexamic Acid",
    "Azelaic Acid", "Kojic Acid", "Madecassoside",
    "Asiaticoside", "Ectoin", "Bisabolol",
    "Ergothioneine", "Resveratrol", "Quercetin",
    "Epigallocatechin Gallate", "Coenzyme Q10",
    "Alpha-Lipoic Acid",
    # Humectants & emollients
    "Squalane", "Isopropyl Myristate", "Isopropyl Palmitate",
    "Cetyl Ethylhexanoate", "Dicaprylyl Carbonate",
    "C12-15 Alkyl Benzoate", "Diisopropyl Adipate",
    "Jojoba Esters", "Shea Butter",
    "Trehalose", "Erythritol", "Xylitol",
    "Sodium PCA", "Betaine",
    # Thickeners & film formers
    "Hydroxypropyl Methylcellulose", "Hydroxyethyl Cellulose",
    "Acrylates/C10-30 Alkyl Acrylate Crosspolymer",
    "Sclerotium Gum", "Gellan Gum", "Pullulan",
    # Preservatives & chelators
    "Chlorphenesin", "Dehydroacetic Acid",
    "Sodium Dehydroacetate", "Sodium Phytate",
    "Tetrasodium EDTA", "Trisodium Ethylenediamine Disuccinate",
    # pH adjusters
    "Triethanolamine", "Aminomethyl Propanol",
    "Sodium Lactate", "Sodium Citrate",
    "Lactic Acid", "Malic Acid", "Tartaric Acid",
    "Phosphoric Acid", "Potassium Hydroxide",
    # Sunscreen actives
    "Zinc Oxide", "Titanium Dioxide",
    "Ethylhexyl Methoxycinnamate", "Butyl Methoxydibenzoylmethane",
    "Ethylhexyl Salicylate", "Homosalate",
    "Octocrylene", "Bemotrizinol", "Bisoctrizole",
    # Supplement ingredients
    "Thiamine Hydrochloride", "Riboflavin",
    "Pyridoxine Hydrochloride", "Cyanocobalamin",
    "Methylcobalamin", "Folic Acid", "Biotin",
    "Calcium Carbonate", "Ferrous Sulfate",
    "Iron Bisglycinate", "Zinc Oxide",
    "Magnesium Stearate", "Microcrystalline Cellulose",
    "Croscarmellose Sodium", "Maltodextrin",
    "Gelatin", "Pectin",
    # Beverage & food
    "Sucralose", "Stevia Rebaudiana Extract",
    "Guar Gum", "Carrageenan", "Locust Bean Gum",
    "Sodium Alginate", "Sodium Carboxymethyl Cellulose",
    "Lecithin", "Modified Corn Starch",
    # Pharma excipients
    "Lactose Monohydrate", "Povidone",
    "Hydroxypropyl Cellulose", "Magnesium Oxide",
    "Colloidal Silicon Dioxide", "Stearic Acid",
    "Talc", "Pregelatinized Starch",
]


def main():
    expand = "--expand" in sys.argv

    with open(SEED_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    print(f"Seed cache: {len(data)} ingredients")

    # Phase 1: Fetch SMILES for existing entries that have CIDs but no SMILES
    missing_smiles = [
        (name, props) for name, props in data.items()
        if not props.get("smiles") and props.get("pubchem_cid")
    ]
    print(f"Missing SMILES: {len(missing_smiles)}")

    for i, (name, props) in enumerate(missing_smiles):
        cid = props["pubchem_cid"]
        print(f"  [{i+1}/{len(missing_smiles)}] {name} (CID {cid})...", end=" ", flush=True)

        result = fetch_properties_by_cid(cid)
        if result:
            smiles = result.get("smiles")
            if smiles:
                props["smiles"] = smiles
                # Also backfill any missing properties
                if props.get("log_p") is None and result.get("log_p") is not None:
                    props["log_p"] = result["log_p"]
                if props.get("hbd") is None and result.get("hbd") is not None:
                    props["hbd"] = result["hbd"]
                if props.get("hba") is None and result.get("hba") is not None:
                    props["hba"] = result["hba"]
                if props.get("tpsa") is None and result.get("tpsa") is not None:
                    props["tpsa"] = result["tpsa"]
                # Compute charge
                props["charge_type"] = infer_charge(smiles)
                print(f"OK (LogP={props.get('log_p')}, charge={props['charge_type']})")
            else:
                print("no SMILES available")
        else:
            print("failed")

        time.sleep(MIN_INTERVAL)

    # Phase 2: Compute charge_type for entries that have SMILES but no charge
    for name, props in data.items():
        if props.get("smiles") and not props.get("charge_type"):
            props["charge_type"] = infer_charge(props["smiles"])

    # Phase 3: Expand with common ingredients (if --expand)
    if expand:
        existing_upper = {k.upper().strip() for k in data}
        new_ingredients = [
            name for name in EXPANSION_INGREDIENTS
            if name.upper().strip() not in existing_upper
        ]
        print(f"\nExpanding: {len(new_ingredients)} new ingredients to look up")

        added = 0
        for i, name in enumerate(new_ingredients):
            print(f"  [{i+1}/{len(new_ingredients)}] {name}...", end=" ", flush=True)

            result = lookup_by_name(name)
            if result:
                smiles = result.get("smiles")
                if smiles:
                    result["charge_type"] = infer_charge(smiles)
                data[name] = result
                added += 1
                logp = result.get("log_p", "?")
                print(f"OK (CID={result.get('pubchem_cid')}, LogP={logp})")
            else:
                print("not found")

            time.sleep(MIN_INTERVAL)

        print(f"Added {added} new ingredients")

    # Save
    with open(SEED_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    # Stats
    has_smiles = sum(1 for p in data.values() if p.get("smiles"))
    has_logp = sum(1 for p in data.values() if p.get("log_p") is not None)
    has_charge = sum(1 for p in data.values() if p.get("charge_type"))
    print(f"\nFinal: {len(data)} ingredients")
    print(f"  SMILES: {has_smiles}")
    print(f"  LogP: {has_logp}")
    print(f"  Charge: {has_charge}")


if __name__ == "__main__":
    main()
