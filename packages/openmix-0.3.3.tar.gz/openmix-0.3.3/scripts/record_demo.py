#!/usr/bin/env python3
"""
Demo script for terminal GIF recording.

Showcases the discourse engine catching real pharmaceutical
incompatibilities through mechanism-based prediction -- including
a drug NOT in the knowledge base rules.

Run this, record the terminal output with a screen recorder or
asciinema, and convert to GIF.

    python scripts/record_demo.py
"""

import time
import sys


def slow_print(text, delay=0.02):
    """Print with a slight delay for recording readability."""
    for line in text.split("\n"):
        print(line)
        time.sleep(delay)
    print()


def main():
    slow_print("""
  OpenMix v0.3.1 -- Multi-Perspective Formulation Discourse
  =========================================================
  RDKit is for molecules. OpenMix is for mixtures.
""")

    time.sleep(0.5)

    # --- Demo 1: Pharma discourse with mechanism prediction ---
    slow_print("  Demo 1: Pharma -- Novel Drug + Known Excipients")
    slow_print("  Memantine is NOT in the knowledge base.")
    slow_print("  Can the physics perspective predict the interaction?")
    time.sleep(0.5)

    from openmix.resolver.resolve import _session_cache
    _session_cache.clear()

    from openmix import Formula
    from openmix.discourse import evaluate_discourse

    tablet = Formula(
        name="Memantine 10mg Tablet",
        ingredients=[
            ("Memantine", 5.0),
            ("Lactose Monohydrate", 55.0),
            ("Microcrystalline Cellulose", 28.0),
            ("Magnesium Stearate", 1.0),
            ("Povidone", 3.0),
            ("Water", 8.0),
        ],
        category="pharma",
    )

    disc = evaluate_discourse(tablet)
    slow_print(str(disc), delay=0.01)

    time.sleep(1)

    # --- Demo 2: Skincare discourse with protocol ---
    slow_print("  Demo 2: Skincare -- Protocol catches manufacturing error")
    time.sleep(0.5)

    from openmix.protocol import Protocol, Phase, ProcessStep

    serum = Formula(
        name="Vitamin C + Retinol Serum",
        ingredients=[
            ("Water", 60.0), ("Ascorbic Acid", 15.0), ("Squalane", 10.0),
            ("Glycerin", 8.0), ("Retinol", 1.0), ("Niacinamide", 3.0),
            ("Phenoxyethanol", 1.0), ("Tocopherol", 0.5),
            ("Xanthan Gum", 0.3), ("Disodium EDTA", 0.1),
            ("Citric Acid", 0.1), ("Cetyl Alcohol", 1.0),
        ],
        target_ph=3.5,
        category="skincare",
    )

    protocol = Protocol(
        phases=[
            Phase("A", "Water Phase", 75.0,
                  ["Water", "Glycerin", "Ascorbic Acid", "Niacinamide",
                   "Xanthan Gum", "Citric Acid", "Disodium EDTA"]),
            Phase("B", "Oil Phase", 75.0,
                  ["Squalane", "Retinol", "Cetyl Alcohol", "Tocopherol"]),
            Phase("C", "Cool-Down", 40.0, ["Phenoxyethanol"]),
        ],
        steps=[
            ProcessStep("heat", "A", {"temp_c": 75, "duration_min": 10}),
            ProcessStep("heat", "B", {"temp_c": 75, "duration_min": 10}),
            ProcessStep("combine", "B", {"into": "A"}),
            ProcessStep("cool", "all", {"target_c": 40}),
            ProcessStep("add", "C", {}),
        ],
        equipment=["overhead stirrer"],
    )

    disc2 = evaluate_discourse(serum, protocol=protocol)
    slow_print(str(disc2), delay=0.01)

    time.sleep(1)

    # --- Demo 3: Dangerous combo ---
    slow_print("  Demo 3: Safety -- Catches toxic gas formation")
    time.sleep(0.3)

    from openmix import validate

    dangerous = Formula(
        ingredients=[
            ("Sodium Hypochlorite", 5.0),
            ("Ammonia", 3.0),
            ("Water", 92.0),
        ],
        category="home_care",
    )
    report = validate(dangerous)
    slow_print(str(report), delay=0.01)

    slow_print("""
  =========================================================
  273 rules | 6 domains | 4 perspectives | evidence hierarchy

  pip install openmix
  github.com/vijayvkrishnan/openmix
  =========================================================
""")


if __name__ == "__main__":
    main()
