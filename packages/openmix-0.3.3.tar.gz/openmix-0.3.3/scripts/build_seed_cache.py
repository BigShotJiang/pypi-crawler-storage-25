#!/usr/bin/env python3
"""
Build the seed ingredient cache from PubChem.

Resolves the most common formulation ingredients and saves them
as seed_ingredients.json for shipping with the package.

Usage:
    python scripts/build_seed_cache.py
"""

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from openmix.resolver.pubchem import lookup_pubchem

# Common formulation ingredients across all domains
# These are the ingredients most likely to appear in experiments
SEED_INGREDIENTS = [
    # Solvents & Bases
    "Water", "Ethanol", "Isopropyl Alcohol", "Propylene Glycol",
    "Butylene Glycol", "Propanediol", "Glycerin", "Pentylene Glycol",
    "Ethoxydiglycol", "Dimethyl Sulfoxide",

    # Humectants
    "Sodium Hyaluronate", "Hyaluronic Acid", "Betaine", "Sorbitol",
    "Panthenol", "Allantoin", "Urea", "Trehalose", "Sodium PCA",
    "Lactic Acid",

    # Emollients & Oils
    "Squalane", "Dimethicone", "Cyclomethicone", "Isopropyl Myristate",
    "Isopropyl Palmitate", "Cetyl Alcohol", "Cetearyl Alcohol",
    "Stearyl Alcohol", "Stearic Acid", "Oleic Acid", "Linoleic Acid",
    "Caprylic/Capric Triglyceride", "Jojoba Oil", "Mineral Oil",

    # Emulsifiers
    "Polysorbate 20", "Polysorbate 60", "Polysorbate 80",
    "Sorbitan Oleate", "Sorbitan Stearate",
    "Glyceryl Stearate", "PEG-100 Stearate",
    "Ceteareth-20", "Steareth-20", "Steareth-2",
    "Lecithin", "Sodium Lauryl Sulfate", "Sodium Laureth Sulfate",
    "Cocamidopropyl Betaine", "Coco-Glucoside", "Decyl Glucoside",

    # Actives — Skincare
    "Ascorbic Acid", "Sodium Ascorbyl Phosphate", "Ascorbyl Glucoside",
    "Niacinamide", "Retinol", "Retinal", "Retinyl Palmitate",
    "Bakuchiol", "Arbutin", "Tranexamic Acid", "Kojic Acid",
    "Glycolic Acid", "Salicylic Acid", "Mandelic Acid", "Azelaic Acid",
    "Ferulic Acid", "Resveratrol", "Adenosine",
    "Copper Tripeptide-1", "Palmitoyl Tripeptide-1",
    "Tocopherol", "Tocopheryl Acetate",

    # Preservatives
    "Phenoxyethanol", "Ethylhexylglycerin", "Caprylyl Glycol",
    "Sodium Benzoate", "Potassium Sorbate", "Benzyl Alcohol",
    "Sorbic Acid", "Dehydroacetic Acid", "Chlorphenesin",
    "Methylparaben", "Propylparaben",

    # Thickeners & Polymers
    "Xanthan Gum", "Carbomer", "Hydroxyethylcellulose",
    "Sodium Carboxymethyl Cellulose", "Guar Gum", "Pectin",
    "Gelatin", "Agar", "Carrageenan",
    "Polyquaternium-7", "Polyquaternium-10",

    # pH Adjusters & Chelators
    "Citric Acid", "Sodium Hydroxide", "Triethanolamine",
    "Sodium Citrate", "Disodium EDTA", "Phytic Acid",
    "Sodium Phosphate", "Potassium Hydroxide",

    # Antioxidants
    "BHT", "BHA", "Ascorbyl Palmitate",

    # Sunscreen
    "Avobenzone", "Octinoxate", "Titanium Dioxide", "Zinc Oxide",
    "Octocrylene",

    # Supplements — Vitamins
    "Cholecalciferol", "Ergocalciferol", "Menaquinone",
    "Pyridoxine Hydrochloride", "Thiamine Hydrochloride",
    "Riboflavin", "Cyanocobalamin", "Methylcobalamin",
    "Folic Acid", "Biotin", "Pantothenic Acid",

    # Supplements — Minerals
    "Calcium Carbonate", "Calcium Citrate", "Ferrous Sulfate",
    "Ferrous Fumarate", "Iron Bisglycinate", "Zinc Oxide",
    "Zinc Gluconate", "Zinc Bisglycinate", "Magnesium Citrate",
    "Magnesium Oxide", "Magnesium Glycinate",

    # Pharma — Common Excipients
    "Microcrystalline Cellulose", "Lactose", "Mannitol",
    "Croscarmellose Sodium", "Crospovidone", "Povidone",
    "Magnesium Stearate", "Sodium Stearyl Fumarate",
    "Hydroxypropyl Methylcellulose", "Polyethylene Glycol",
    "Poloxamer 188", "Poloxamer 407",

    # Food — Common Additives
    "Sodium Alginate", "Calcium Chloride", "Sodium Metabisulfite",
    "Sodium Nitrite", "Maltodextrin", "Sucrose", "Glucose",
    "Acacia Gum", "Sodium Caseinate",

    # Surfactants — Anionic
    "Sodium Cocoyl Glutamate", "Disodium Cocoyl Glutamate",
    "Sodium Lauroyl Sarcosinate", "Sodium Cocoamphoacetate",

    # Conditioning
    "Cetrimonium Chloride", "Behentrimonium Chloride",
    "Polyquaternium-6", "Polyquaternium-68",

    # Botanicals
    "Aloe Barbadensis Leaf Juice", "Chamomilla Recutita Extract",
    "Camellia Sinensis Leaf Extract", "Centella Asiatica Extract",
    "Calendula Officinalis Extract", "Rosa Canina Seed Oil",
    "Simmondsia Chinensis Seed Oil", "Argania Spinosa Kernel Oil",
    "Helianthus Annuus Seed Oil", "Prunus Amygdalus Dulcis Oil",
    "Cocos Nucifera Oil", "Olea Europaea Fruit Oil",
    "Persea Gratissima Oil", "Ricinus Communis Seed Oil",
    "Butyrospermum Parkii Butter", "Theobroma Cacao Seed Butter",
]


def main():
    output_path = Path(__file__).parent.parent / "src" / "openmix" / "resolver" / "seed_ingredients.json"

    print(f"Building seed cache for {len(SEED_INGREDIENTS)} ingredients...")
    cache = {}
    resolved = 0
    failed = 0

    for i, name in enumerate(SEED_INGREDIENTS):
        result = lookup_pubchem(name)
        if result:
            cache[name] = result
            resolved += 1
            status = f"OK (CID: {result.get('pubchem_cid')})"
        else:
            failed += 1
            status = "FAILED"

        print(f"  [{i+1}/{len(SEED_INGREDIENTS)}] {name}: {status}")

    print(f"\nResolved: {resolved}/{len(SEED_INGREDIENTS)} ({resolved/len(SEED_INGREDIENTS)*100:.0f}%)")
    print(f"Failed: {failed}")

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(cache, f, indent=2)
    print(f"Saved to {output_path}")


if __name__ == "__main__":
    main()
