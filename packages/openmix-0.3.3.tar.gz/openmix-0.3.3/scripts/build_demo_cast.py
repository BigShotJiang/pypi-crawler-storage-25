"""
Build an asciinema .cast file showing the real OpenMix experience.

Replays actual observe() output on a complex multi-active serum.
All output is from the real system, no fabrication.

Usage:
    python scripts/build_demo_cast.py
    agg demo.cast assets/demo.gif --font-size 14
"""

import json
import subprocess

CAST_PATH = "demo.cast"
WIDTH = 105
HEIGHT = 50

events = []
t = 0.0


def pause(seconds):
    global t
    t += seconds


def type_text(text, char_delay=0.035):
    global t
    for ch in text:
        events.append([round(t, 4), "o", ch])
        t += char_delay


def emit(text, delay_after=0.02):
    global t
    events.append([round(t, 4), "o", text])
    t += delay_after


def emit_line(text, delay_after=0.02):
    emit(text + "\r\n", delay_after)


# --- Capture real output ---
real_output = subprocess.run(
    ["python", "-c", """
from openmix import Formula, observe

cream = Formula(
    name="Triple Active Anti-Aging Serum",
    ingredients=[
        ("Water", 60.0), ("Ascorbic Acid", 15.0), ("Niacinamide", 5.0),
        ("Retinol", 1.0), ("Squalane", 10.0), ("Cetearyl Alcohol", 3.0),
        ("Glycerin", 3.0), ("Ferulic Acid", 0.5), ("Phenoxyethanol", 0.5),
        ("Sodium Hydroxide", 0.5), ("Citric Acid", 0.5), ("Propanediol", 1.0),
    ],
    target_ph=3.5,
    category="skincare",
)
print(observe(cream))
"""],
    capture_output=True, text=True,
).stdout.strip()

# --- Build the recording ---

# Python REPL prompt
pause(0.8)
emit("$ ")
pause(0.3)
type_text("python")
pause(0.3)
emit("\r\n")
pause(0.4)
emit(">>> ")
pause(0.3)

# Import
type_text("from openmix import Formula, observe")
emit("\r\n")
pause(0.2)
emit(">>> ")
pause(0.3)

# Create formula
type_text("serum = Formula(")
emit("\r\n")
emit("... ")
type_text('    name="Triple Active Anti-Aging Serum",')
emit("\r\n")
emit("... ")
type_text("    ingredients=[")
emit("\r\n")

ingredients = [
    '("Water", 60.0), ("Ascorbic Acid", 15.0), ("Niacinamide", 5.0),',
    '("Retinol", 1.0), ("Squalane", 10.0), ("Cetearyl Alcohol", 3.0),',
    '("Glycerin", 3.0), ("Ferulic Acid", 0.5), ("Phenoxyethanol", 0.5),',
    '("Sodium Hydroxide", 0.5), ("Citric Acid", 0.5), ("Propanediol", 1.0),',
]
for line in ingredients:
    emit("... ")
    type_text(f"        {line}", char_delay=0.015)
    emit("\r\n")

emit("... ")
type_text("    ],")
emit("\r\n")
emit("... ")
type_text("    target_ph=3.5, category=\"skincare\")")
emit("\r\n")
pause(0.3)
emit(">>> ")
pause(0.4)

# Call observe
type_text("print(observe(serum))")
emit("\r\n")
pause(0.8)

# Print real output with controlled pacing
for line in real_output.split("\n"):
    # Slower for important lines, faster for routine
    if any(kw in line for kw in ["SOFT", "HARD", "[!]", "Concern count"]):
        emit_line(line, delay_after=0.08)
    elif any(kw in line for kw in ["Physics Observation", "Resolved:", "Violations"]):
        emit_line(line, delay_after=0.06)
    elif line.strip() == "":
        emit_line("", delay_after=0.03)
    else:
        emit_line(line, delay_after=0.04)

pause(4.0)

# --- Write ---
header = {
    "version": 2,
    "width": WIDTH,
    "height": HEIGHT,
    "title": "OpenMix: Physics Observation Engine",
    "env": {"TERM": "xterm-256color", "SHELL": "/bin/bash"},
}

with open(CAST_PATH, "w") as f:
    f.write(json.dumps(header) + "\n")
    for event in events:
        f.write(json.dumps(event) + "\n")

print(f"Events: {len(events)}, Duration: {t:.1f}s")
print(f"Written to {CAST_PATH}")
