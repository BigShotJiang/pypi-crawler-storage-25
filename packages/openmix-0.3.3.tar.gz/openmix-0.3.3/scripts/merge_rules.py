"""
Merge new interaction rules into the knowledge base.

Reads new rules from a YAML file, deduplicates against existing rules,
and appends non-duplicate rules to incompatible_pairs.yaml.

Usage:
    python scripts/merge_rules.py new_rules.yaml
    python scripts/merge_rules.py new_rules.yaml --dry-run
"""

import sys
import yaml
from pathlib import Path

KB_PATH = Path("src/openmix/knowledge/data/incompatible_pairs.yaml")


def normalize_pair(a: str, b: str) -> tuple[str, str]:
    a, b = a.upper().strip(), b.upper().strip()
    return (min(a, b), max(a, b))


def main():
    if len(sys.argv) < 2:
        print("Usage: python scripts/merge_rules.py <new_rules.yaml> [--dry-run]")
        sys.exit(1)

    new_path = Path(sys.argv[1])
    dry_run = "--dry-run" in sys.argv

    # Load existing
    with open(KB_PATH, "r", encoding="utf-8") as f:
        existing = yaml.safe_load(f)

    existing_pairs = set()
    for r in existing:
        existing_pairs.add(normalize_pair(r["a"], r["b"]))

    print(f"Existing: {len(existing)} rules")

    # Load new
    with open(new_path, "r", encoding="utf-8") as f:
        new_rules = yaml.safe_load(f)

    if not new_rules:
        print("No new rules found")
        sys.exit(0)

    # Deduplicate
    to_add = []
    dupes = 0
    for r in new_rules:
        pair = normalize_pair(r["a"], r["b"])
        if pair in existing_pairs:
            dupes += 1
            print(f"  DUPE: {r['a']} + {r['b']}")
        else:
            to_add.append(r)
            existing_pairs.add(pair)

    print(f"New: {len(new_rules)} rules ({dupes} duplicates, {len(to_add)} to add)")

    if dry_run:
        print("Dry run, not writing")
        sys.exit(0)

    # Append to file
    with open(KB_PATH, "r", encoding="utf-8") as f:
        content = f.read()

    with open(KB_PATH, "a", encoding="utf-8") as f:
        f.write("\n\n# =============================================================================\n")
        f.write("# EXPANDED RULES — Added via merge_rules.py\n")
        f.write("# =============================================================================\n\n")
        f.write(yaml.dump(to_add, default_flow_style=False, allow_unicode=True,
                          sort_keys=False, width=100))

    # Verify
    with open(KB_PATH, "r", encoding="utf-8") as f:
        final = yaml.safe_load(f)
    print(f"Final: {len(final)} rules")


if __name__ == "__main__":
    main()
