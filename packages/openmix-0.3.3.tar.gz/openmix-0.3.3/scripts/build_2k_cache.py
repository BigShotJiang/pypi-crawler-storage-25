"""
Build the 2K seed ingredient cache from a curated master list.

Merges the existing seed cache with ~2000 common formulation ingredients
across skincare, pharma, supplements, food, home care, and solvents.
Resolves all through PubChem.

Usage:
    python scripts/build_2k_cache.py
"""

from __future__ import annotations

import json
import time
from pathlib import Path

from scripts.enrich_seed_cache import (
    fetch_properties_by_cid,
    lookup_by_name,
    infer_charge,
    SEED_PATH,
)

# Master ingredient list: ~2000 across 6 domains
# Sources: INCI Dictionary, USP-NF, FDA GRAS, EU Cosmetics Annex, Codex Alimentarius
MASTER_LIST = [
    # === SKINCARE / COSMETICS ===
    # Surfactants
    "Sodium Lauryl Sulfate", "Sodium Laureth Sulfate", "Cocamidopropyl Betaine",
    "Sodium Cocoyl Isethionate", "Disodium Laureth Sulfosuccinate",
    "Sodium Cocoyl Glutamate", "Sodium Lauroyl Sarcosinate", "Decyl Glucoside",
    "Lauryl Glucoside", "Coco-Glucoside", "Cocamidopropyl Hydroxysultaine",
    "Sodium Cocoamphoacetate", "Cetrimonium Chloride", "Cetrimonium Bromide",
    "Behentrimonium Chloride", "Behentrimonium Methosulfate",
    "Stearalkonium Chloride", "Sodium Methyl Cocoyl Taurate",
    "Disodium Cocoamphodiacetate", "Ammonium Lauryl Sulfate",
    "Cocamide DEA", "Cocamide MEA", "Sodium Cocoyl Glycinate",
    "Potassium Cocoyl Glycinate",
    # Emollients
    "Caprylic/Capric Triglyceride", "Isopropyl Myristate", "Isopropyl Palmitate",
    "Cetyl Ethylhexanoate", "Ethylhexyl Palmitate", "Diisopropyl Adipate",
    "Octyldodecanol", "Dicaprylyl Ether", "Squalane", "Squalene",
    "Hydrogenated Polyisobutene", "Isononyl Isononanoate", "Ethylhexyl Stearate",
    "Myristyl Myristate", "Cetyl Palmitate", "Dicaprylyl Carbonate",
    # Humectants
    "Glycerin", "Butylene Glycol", "Propylene Glycol", "Sodium Hyaluronate",
    "Hyaluronic Acid", "Sodium PCA", "Panthenol", "Sorbitol", "Trehalose",
    "Betaine", "Urea", "Xylitol", "Pentylene Glycol", "Hexylene Glycol",
    "Caprylyl Glycol", "Dipropylene Glycol", "1,2-Hexanediol",
    "Ethylhexylglycerin", "Sodium Lactate", "Propanediol", "Erythritol",
    # Emulsifiers
    "Cetearyl Alcohol", "Ceteareth-20", "Polysorbate 20", "Polysorbate 60",
    "Polysorbate 80", "Sorbitan Oleate", "Sorbitan Stearate", "Glyceryl Stearate",
    "PEG-100 Stearate", "Steareth-2", "Steareth-21", "Lecithin",
    "Hydrogenated Lecithin", "Cetearyl Glucoside", "Sucrose Stearate",
    "Sucrose Palmitate", "PEG-40 Hydrogenated Castor Oil", "Sorbitan Isostearate",
    # Thickeners
    "Carbomer", "Xanthan Gum", "Hydroxyethylcellulose",
    "Hydroxypropyl Methylcellulose", "Sodium Polyacrylate", "Cellulose Gum",
    "Sclerotium Gum", "Gellan Gum", "Bentonite", "Hectorite", "Silica",
    "Magnesium Aluminum Silicate",
    # Preservatives
    "Phenoxyethanol", "Methylparaben", "Propylparaben", "Ethylparaben",
    "Chlorphenesin", "Sodium Benzoate", "Potassium Sorbate", "Dehydroacetic Acid",
    "Benzyl Alcohol", "Sorbic Acid", "Benzoic Acid",
    "Iodopropynyl Butylcarbamate", "Undecylenic Acid", "Levulinic Acid",
    # Actives
    "Niacinamide", "Salicylic Acid", "Glycolic Acid", "Retinol",
    "Retinyl Palmitate", "Retinal", "Ascorbic Acid", "Ascorbyl Glucoside",
    "Sodium Ascorbyl Phosphate", "Ascorbyl Tetraisopalmitate",
    "Tranexamic Acid", "Azelaic Acid", "Kojic Acid", "Arbutin",
    "Mandelic Acid", "Lactic Acid", "Tartaric Acid", "Malic Acid",
    "Phytic Acid", "Ferulic Acid", "Caffeic Acid", "Bakuchiol", "Resveratrol",
    "Allantoin", "Bisabolol", "Madecassoside", "Asiaticoside", "Ectoin",
    "Adenosine", "Ceramide NP", "Ceramide AP", "Phytosphingosine",
    "Cholesterol", "Beta-Glucan", "Gluconolactone", "Lactobionic Acid",
    # Sunscreens
    "Homosalate", "Octisalate", "Octocrylene", "Avobenzone", "Oxybenzone",
    "Octinoxate", "Zinc Oxide", "Titanium Dioxide", "Bemotrizinol",
    "Ethylhexyl Triazone",
    # Silicones
    "Dimethicone", "Cyclopentasiloxane", "Cyclohexasiloxane", "Dimethiconol",
    "Amodimethicone", "Phenyl Trimethicone", "PEG-10 Dimethicone",
    "Caprylyl Methicone",
    # Fatty alcohols & acids
    "Cetyl Alcohol", "Stearyl Alcohol", "Behenyl Alcohol", "Myristyl Alcohol",
    "Stearic Acid", "Palmitic Acid", "Myristic Acid", "Lauric Acid",
    "Oleic Acid", "Linoleic Acid", "Linolenic Acid", "Behenic Acid",
    "Caprylic Acid", "Capric Acid", "Isostearic Acid", "Ricinoleic Acid",
    # Botanical oils
    "Simmondsia Chinensis Seed Oil", "Argania Spinosa Kernel Oil",
    "Cocos Nucifera Oil", "Olea Europaea Fruit Oil", "Helianthus Annuus Seed Oil",
    "Ricinus Communis Seed Oil", "Cannabis Sativa Seed Oil",
    "Rosa Canina Seed Oil", "Vitis Vinifera Seed Oil", "Sesamum Indicum Seed Oil",
    "Macadamia Integrifolia Seed Oil", "Camellia Oleifera Seed Oil",
    # Botanical extracts
    "Camellia Sinensis Leaf Extract", "Glycyrrhiza Glabra Root Extract",
    "Curcuma Longa Root Extract", "Vitis Vinifera Seed Extract",
    "Echinacea Purpurea Extract", "Ginkgo Biloba Leaf Extract",
    "Panax Ginseng Root Extract",
    # Peptides
    "Palmitoyl Tripeptide-1", "Palmitoyl Tetrapeptide-7",
    "Palmitoyl Pentapeptide-4", "Acetyl Hexapeptide-8",
    "Copper Tripeptide-1", "Carnosine",
    # Vitamins & antioxidants
    "Tocopherol", "Tocopheryl Acetate", "Ascorbyl Palmitate",
    "Cholecalciferol", "Ergocalciferol", "Menaquinone",
    "Ubiquinone", "Idebenone", "Astaxanthin", "Glutathione", "Phloretin",
    "Epigallocatechin Gallate", "BHT", "BHA", "Alpha-Lipoic Acid",
    # Chelators & pH
    "Disodium EDTA", "Tetrasodium EDTA", "Sodium Phytate", "Citric Acid",
    "Sodium Gluconate", "Triethanolamine", "Aminomethyl Propanol",
    "Sodium Hydroxide", "Potassium Hydroxide", "Phosphoric Acid",
    "Sodium Bicarbonate", "Tromethamine", "Arginine", "Sodium Citrate",
    # Fragrance allergens
    "Linalool", "Limonene", "Citronellol", "Geraniol", "Eugenol",
    "Coumarin", "Benzyl Benzoate", "Citral", "Hexyl Cinnamal", "Farnesol",
    # Misc cosmetic
    "Water", "Kaolin", "Talc", "Hydrogenated Castor Oil", "Beeswax",
    "Candelilla Wax", "Carnauba Wax", "Petrolatum", "Mineral Oil", "Lanolin",
    "Zinc Pyrithione", "Camphor", "Menthol", "Sodium Chloride",
    "Magnesium Sulfate",

    # === PHARMACEUTICAL EXCIPIENTS ===
    "Povidone", "Copovidone", "Hydroxypropyl Cellulose", "Methylcellulose",
    "Ethylcellulose", "Polyvinyl Alcohol", "Pregelatinized Starch",
    "Corn Starch", "Sodium Alginate", "Gelatin", "Acacia", "Dextrin",
    "Maltodextrin", "Lactose Monohydrate", "Microcrystalline Cellulose",
    "Mannitol", "Dibasic Calcium Phosphate", "Calcium Sulfate", "Sucrose",
    "Dextrose", "Isomalt", "Calcium Carbonate", "Magnesium Carbonate",
    "Croscarmellose Sodium", "Crospovidone", "Sodium Starch Glycolate",
    "Alginic Acid", "Magnesium Stearate", "Sodium Stearyl Fumarate",
    "Calcium Stearate", "Glyceryl Behenate", "Colloidal Silicon Dioxide",
    "Tricalcium Phosphate", "Shellac", "Triethyl Citrate", "Triacetin",
    "Saccharin Sodium", "Acesulfame Potassium", "Sucralose", "Aspartame",
    "Steviol Glycosides", "Maltitol", "Poloxamer 188", "Poloxamer 407",
    "Docusate Sodium", "Alpha-Cyclodextrin", "Beta-Cyclodextrin",
    "Gamma-Cyclodextrin", "Hydroxypropyl-Beta-Cyclodextrin",
    "Polyethylene Glycol 200", "Polyethylene Glycol 300",
    "Polyethylene Glycol 400", "Polyethylene Glycol 600",
    "Polyethylene Glycol 1000", "Polyethylene Glycol 1500",
    "Polyethylene Glycol 4000", "Polyethylene Glycol 8000",
    "Benzalkonium Chloride", "Chlorobutanol", "Phenol", "Metacresol",
    "Chlorhexidine Gluconate", "Sodium Phosphate Monobasic",
    "Sodium Phosphate Dibasic", "Sodium Acetate", "Acetic Acid",
    "Histidine", "Succinic Acid", "Meglumine", "Sodium Ascorbate",
    "Sodium Metabisulfite", "Sodium Sulfite", "Propyl Gallate",
    "Cysteine Hydrochloride", "Carbomer 940", "Carbomer 974P", "Carbomer 980",
    "Ethanol", "Isopropyl Alcohol", "Dimethyl Sulfoxide",
    "N-Methyl-2-Pyrrolidone", "Sesame Oil", "Cottonseed Oil",
    "Medium-Chain Triglycerides", "Cocoa Butter", "Simethicone", "Pullulan",
    "Zein", "Peppermint Oil",

    # === SUPPLEMENT INGREDIENTS ===
    "Thiamine Hydrochloride", "Thiamine Mononitrate", "Benfotiamine",
    "Riboflavin", "Niacin", "Calcium D-Pantothenate",
    "Pyridoxine Hydrochloride", "Pyridoxal-5-Phosphate", "Biotin",
    "Folic Acid", "Cyanocobalamin", "Methylcobalamin", "Hydroxocobalamin",
    "Calcium Ascorbate", "Magnesium Ascorbate", "D-Alpha-Tocopherol",
    "Mixed Tocopherols", "Phytonadione", "Menaquinone-4", "Menaquinone-7",
    "Pantothenic Acid", "Magnesium Oxide", "Magnesium Citrate",
    "Magnesium Bisglycinate", "Magnesium Taurate", "Magnesium Threonate",
    "Magnesium Malate", "Magnesium Chloride", "Magnesium Lactate",
    "Zinc Gluconate", "Zinc Bisglycinate", "Zinc Picolinate", "Zinc Sulfate",
    "Zinc Carnosine", "Calcium Citrate", "Calcium Phosphate", "Calcium Lactate",
    "Iron Bisglycinate", "Ferrous Sulfate", "Ferrous Fumarate",
    "Ferrous Gluconate", "Ferric Pyrophosphate", "Potassium Chloride",
    "Potassium Gluconate", "Potassium Citrate", "Selenomethionine",
    "Chromium Picolinate", "Manganese Gluconate", "Copper Gluconate",
    "Copper Bisglycinate", "Boron Citrate", "Strontium Citrate",
    "L-Glutamine", "L-Lysine", "L-Arginine", "L-Citrulline", "L-Tyrosine",
    "L-Theanine", "L-Tryptophan", "5-Hydroxytryptophan", "L-Carnitine",
    "Acetyl-L-Carnitine", "N-Acetyl Cysteine", "L-Glycine", "L-Proline",
    "Taurine", "L-Leucine", "L-Isoleucine", "L-Valine", "Beta-Alanine",
    "Creatine Monohydrate", "Berberine Hydrochloride", "Quercetin",
    "Curcumin", "Lactobacillus Acidophilus", "Lactobacillus Rhamnosus",
    "Lactobacillus Plantarum", "Bifidobacterium Longum",
    "Bifidobacterium Lactis", "Saccharomyces Boulardii", "Bacillus Coagulans",
    "Coenzyme Q10", "Ubiquinol", "Phosphatidylserine", "Phosphatidylcholine",
    "Choline Bitartrate", "Citicoline", "Glucosamine Sulfate",
    "Chondroitin Sulfate", "Methylsulfonylmethane", "Collagen Peptides",
    "Spirulina", "Chlorella", "Lutein", "Zeaxanthin", "Lycopene",
    "Melatonin", "Inulin", "Fructooligosaccharides", "Bromelain", "Papain",
    "Nattokinase", "Lactoferrin", "Nicotinamide Mononucleotide",
    "Nicotinamide Riboside", "D-Mannose", "Myo-Inositol",

    # === FOOD ADDITIVES ===
    "Soy Lecithin", "Sunflower Lecithin", "Sodium Stearoyl Lactylate",
    "Calcium Stearoyl Lactylate", "Polysorbate 65", "Sorbitan Monostearate",
    "Sorbitan Tristearate", "Polyglycerol Polyricinoleate", "Guar Gum",
    "Locust Bean Gum", "Carrageenan", "Pectin",
    "Sodium Carboxymethylcellulose", "Agar-Agar", "Konjac Glucomannan",
    "Tara Gum", "Gum Arabic", "Modified Corn Starch", "Modified Tapioca Starch",
    "Curdlan", "Sodium Caseinate", "Calcium Caseinate", "Chitosan",
    "Calcium Propionate", "Sodium Nitrite", "Sodium Nitrate", "Nisin",
    "Natamycin", "TBHQ", "Sodium Erythorbate", "Erythorbic Acid",
    "Sulfur Dioxide", "Potassium Metabisulfite", "Propionic Acid",
    "Fumaric Acid", "Adipic Acid", "Sodium Acid Pyrophosphate",
    "Monocalcium Phosphate", "Disodium Phosphate", "Trisodium Phosphate",
    "Sodium Hexametaphosphate", "Cream of Tartar", "Neotame", "Advantame",
    "Rebaudioside A", "Monk Fruit Extract", "Allulose", "Polydextrose",
    "Glucose Syrup", "Fructose", "Annatto Extract", "Turmeric Oleoresin",
    "Paprika Oleoresin", "Caramel Color", "Chlorophyllin", "Vanillin",
    "Ethyl Vanillin", "Monosodium Glutamate", "Disodium Inosinate",
    "Disodium Guanylate", "Yeast Extract", "Maltol", "Ethyl Maltol",
    "Ammonium Bicarbonate", "Silicon Dioxide", "Calcium Silicate",
    "Sodium Aluminosilicate", "Amylase", "Protease", "Lipase", "Cellulase",
    "Pectinase", "Lactase", "Invertase", "Transglutaminase", "Glucose Oxidase",

    # === HOME CARE ===
    "Linear Alkylbenzene Sulfonate", "Alpha-Olefin Sulfonate",
    "Lauramine Oxide", "Cocamine Oxide", "Didecyldimethylammonium Chloride",
    "Sodium Carbonate", "Sodium Tripolyphosphate", "Sodium Silicate",
    "Sodium Metasilicate", "Sodium Sesquicarbonate", "Sodium Hypochlorite",
    "Hydrogen Peroxide", "Sodium Percarbonate", "Sodium Perborate",
    "Calcium Hypochlorite", "Peracetic Acid", "Sodium Dichloroisocyanurate",
    "2-Butoxyethanol", "D-Limonene", "Pine Oil",
    "Dipropylene Glycol Methyl Ether", "Acetone", "Sodium Sulfate",
    "Calcium Chloride", "Borax", "Boric Acid",

    # === SOLVENTS ===
    "Ethoxydiglycol", "Propylene Carbonate", "Dimethyl Isosorbide",
    "Ethyl Acetate", "Methanol", "Toluene", "Hexane", "Dichloromethane",
    "Tetrahydrofuran", "Cyclohexane", "Ethyl Lactate",
]


def main():
    # Load existing cache
    with open(SEED_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
    print(f"Existing cache: {len(data)} ingredients")

    # Find new ingredients to add
    existing_upper = {k.upper().strip() for k in data}
    new_names = []
    for name in MASTER_LIST:
        if name.upper().strip() not in existing_upper:
            new_names.append(name)

    # Deduplicate the new list
    seen = set()
    deduped = []
    for name in new_names:
        key = name.upper().strip()
        if key not in seen:
            seen.add(key)
            deduped.append(name)
    new_names = deduped

    print(f"New ingredients to resolve: {len(new_names)}")
    print(f"Target total: {len(data) + len(new_names)}")
    print()

    added = 0
    failed = []
    for i, name in enumerate(new_names):
        print(f"  [{i+1}/{len(new_names)}] {name}...", end=" ", flush=True)
        result = lookup_by_name(name)
        if result and result.get("smiles"):
            result["charge_type"] = infer_charge(result["smiles"])
            data[name] = result
            added += 1
            print(f"OK (LogP={result.get('log_p')})")
        else:
            failed.append(name)
            print("not found")
        time.sleep(0.25)

    # Save
    with open(SEED_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    has_smiles = sum(1 for p in data.values() if p.get("smiles"))
    has_logp = sum(1 for p in data.values() if p.get("log_p") is not None)
    has_charge = sum(1 for p in data.values() if p.get("charge_type"))

    print(f"\nFinal: {len(data)} ingredients")
    print(f"  SMILES: {has_smiles}")
    print(f"  LogP: {has_logp}")
    print(f"  Charge: {has_charge}")
    print(f"  Added: {added}, Failed: {len(failed)}")
    if failed:
        print(f"  Failed names: {failed[:20]}...")


if __name__ == "__main__":
    main()
