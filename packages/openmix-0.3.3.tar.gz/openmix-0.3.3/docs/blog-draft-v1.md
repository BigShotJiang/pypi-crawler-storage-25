# The Missing Layer in Computational Chemistry: Open Infrastructure for Mixture Science

*Vijay Krishnan, March 2026*

---

## Why Mixtures Are Hard

Computational chemistry has made extraordinary progress on individual molecules. RDKit computes molecular descriptors. AlphaFold predicts protein structure. ChemProp and MoLFormer predict molecular properties with increasing accuracy. DeepChem provides a unified framework for molecular machine learning.

All of this work operates on the same fundamental unit: a single molecule, represented as a graph or a SMILES string, with properties that can be computed or predicted from its structure alone.

Formulation science operates on a different unit entirely: the mixture. A shampoo is 12 surfactants, polymers, and thickeners in water. A pharmaceutical tablet is an active ingredient embedded in a matrix of excipients. A cosmetic serum is a dozen actives and functional ingredients at precise concentrations, in specific phases, at a target pH.

The properties of these systems are not sums of their parts. When you mix an anionic surfactant with a cationic polymer, the resulting coacervate has properties that neither component has alone. When you dissolve a hydrophobic drug in a binary solvent mixture, the solubility depends on the interaction between all three components, not just the drug's LogP. When you combine Retinol with Ascorbic Acid at low pH, both degrade faster than either would alone.

Thermodynamics provides the precise language for this challenge. An "ideal mixture" is one where properties are simple mole-fraction-weighted averages of pure component properties: the enthalpy of mixing is zero, the volume of mixing is zero. Real mixtures deviate from this because of intermolecular interactions between unlike molecules. These deviations, called *excess properties*, are exactly what formulation scientists care about and exactly what additive models cannot capture.

Ethanol and water, for instance, contract when mixed. The volume of the mixture is measurably less than the sum of the pure volumes because water molecules fill structural gaps in the ethanol network. The excess enthalpy of the system reflects the formation of hydrogen bonds between unlike molecules that are stronger than those between like molecules. These are emergent properties of the mixture, invisible in the properties of either component alone.

Scale this to a real formulation with 12-20 components, where surfactants self-assemble above critical micelle concentrations, polymers undergo conformational changes in the presence of salts, and pH-dependent ionization shifts the effective charge balance, and the non-additivity becomes the dominant factor.

The established computational approaches to mixture prediction reflect this difficulty. COSMO-RS (Klamt, 1995) predicts thermodynamic properties from quantum-chemical calculations on individual molecules, using screening charge density surfaces to compute interaction energies. It works well for simple solvent systems but requires a quantum-chemical calculation for each molecule and struggles with the self-assembly, kinetic phenomena, and many-body effects that dominate real formulations. Hansen Solubility Parameters (Hansen, 1967) offer a simpler heuristic: represent molecules as points in a three-dimensional space (dispersion, polarity, hydrogen bonding) where "like dissolves like." Mixture properties are assumed to be volume-fraction-weighted averages, strictly additive, no interaction terms. Useful for initial solvent screening but fundamentally limited for complex biological systems.

Neither approach scales to the combinatorial reality of modern formulation. A cosmetics company might work with 500 ingredients. The number of possible 12-ingredient combinations at varying concentrations is astronomical. The knowledge about which combinations work, and why, lives in institutional memory, proprietary databases, and the heads of experienced formulation scientists.

There is no open-source framework for computational mixture science. No shared representation for formulations. No public benchmark for mixture property prediction. No open knowledge base of ingredient interactions.

OpenMix is our attempt to build that infrastructure.

---

## Observations, Not Scores

The first design decision in OpenMix was architectural, and it came from studying how existing AI-for-science systems evaluate their outputs.

Most autonomous chemistry systems use a scalar objective function: a score from 0-100, a predicted yield, a computed stability metric. The agent optimizes against this number. This works for engineering: hill-climbing toward a known objective is well-understood. Bayesian optimization, reinforcement learning, and even simple LLM iteration loops can all optimize a scalar.

Buehler's SparksMatter system takes a more principled approach, computing actual physical properties (energy above hull, band gap, elastic modulus) with physically meaningful thresholds rather than arbitrary weighted scores. This is the right direction: physics as computational tools, with physical quantities that have real units and real interpretations.

We took this principle further. OpenMix's observation engine reports structured physics observations, each containing what was measured, what physics predicted, and whether they agree:

```python
from openmix import Formula, observe

cream = Formula(
    name="Retinol Night Cream",
    ingredients=[
        ("Water", 60.0), ("Retinol", 2.0), ("Squalane", 15.0),
        ("Cetyl Alcohol", 5.0), ("Glycerin", 8.0),
        ("Niacinamide", 5.0), ("Ascorbic Acid", 5.0),
    ],
    target_ph=5.5,
    category="skincare",
)
print(observe(cream))
```

```
Violations (0 hard, 2 soft):
  [SOFT (conf 0.7)] RETINOL + ASCORBIC ACID
    Retinol is unstable in the acidic conditions required for L-Ascorbic Acid.
  [SOFT (conf 0.5)] NIACINAMIDE + ASCORBIC ACID
    At low pH, niacinamide may convert to nicotinic acid. Widely debated.

MOLECULAR:
  [!] Squalane: LogP 14.7 at 15.0% -- hydrophobic
      LogP 14.7 suggests poor water solubility. Ensure adequate emulsifier.

STRUCTURAL:
  [!] Water-based formula without detected preservative

PHASE:
  [?] Hydrophobic phase: 22.0% -- Retinol (2.0%), Squalane (15.0%),
      Cetyl Alcohol (5.0%)

PH:
  [ ] Niacinamide: 99% deprotonated at pH 5.5 (pKa 3.35). Within optimal range 5.0-7.0.
  [!] Ascorbic Acid: 96% ionized at pH 5.5 (pKa 4.17). Ascorbate anion is susceptible
      to oxidative degradation. Optimal pH: 2.5-3.5.

Concern count: 4.1
```

Each observation is a structured record: category, subject, what was observed, what was expected, whether they agree, the source of the expectation, and a confidence score. The system reports what it sees. The consumer of the observations (human or agent) decides what to do about it.

This architecture choice has a consequence that turned out to be the most interesting part of the project.

---

## One Chassis, Two Modes

Engineering and discovery look like different activities, but they share the same cognitive operation: compare expectations to observations.

An engineer designing a stable shampoo has expectations about how surfactants interact, what pH range is needed, whether the emulsion system will hold. When observations match expectations, the formula is on track. When they disagree, the engineer adjusts the formula to resolve the discrepancy. The goal is convergence: zero discrepancies, a formula that behaves as expected.

A researcher investigating a novel drug-excipient interaction also has expectations. But when observations disagree with expectations, the researcher does something fundamentally different. Instead of adjusting the formula to match the expectation, they investigate the discrepancy itself. The expectation might be wrong. The disagreement might reveal something new.

This distinction maps directly to the history of scientific discovery. Fleming expected a contaminated petri dish to show uniform bacterial growth. The observation (a clear zone around the mold) disagreed with the expectation. He investigated the discrepancy instead of discarding the plate. Mojica expected the repeated DNA sequences in archaea to be junk. They weren't. The GLP-1 receptor agonists developed for diabetes showed unexpected weight loss. Someone investigated instead of dismissing the side effect.

The pattern is consistent: expectation existed, something violated it, someone noticed the violation, they investigated rather than dismissing, and the investigation revealed something new. Discovery is the investigation of surprise.

In OpenMix, the same observation engine serves both purposes:

**Engineering mode** treats discrepancies as problems. The optimization target is zero concerns. The autonomous experiment runner uses this mode to iterate toward stable, manufacturable formulations. Every discrepancy the physics engine reports is something the LLM agent tries to resolve.

**Discovery mode** treats discrepancies as signals. Hard violations still block (bleach and ammonia produce toxic chloramine gas regardless of your intent). But soft violations surface as "signals" and low-confidence observations surface as "knowledge gaps." The system explicitly flags where its expectations might be wrong.

```python
obs = observe(formula, mode="discovery")
obs.signals       # Soft violations: interesting interactions to explore
obs.discoveries   # Low-confidence discrepancies: expectations that may be wrong
```

The same infrastructure, two fundamentally different uses. A consumer goods company uses engineering mode to develop products. A pharmaceutical researcher uses discovery mode to investigate which interactions the knowledge base might have wrong.

This framing owes a debt to Buehler's multi-agent scientific discovery systems (ScienceClaw, VibeGen), which demonstrated that scientific reasoning can be decomposed into distinct cognitive modes. Our approach differs architecturally (a single observation engine with mode selection rather than a multi-agent swarm), but the insight that engineering and discovery are different operations on the same substrate is shared.

---

## The Identity Problem

Before you can reason about mixture physics, you need to know what the molecules are. This sounds trivial. It is not.

Formulation scientists work in domain-specific nomenclature. A cosmetic chemist uses INCI names: "Cetearyl Alcohol," "Polysorbate 80," "Sodium Cocoyl Glutamate." A pharmaceutical scientist uses USP names and brand names. A food scientist uses E-numbers and common names.

Computational chemistry tools work in SMILES, InChI, and molecular graphs.

The bridge between these worlds is OpenMix's ingredient resolver. Given any ingredient name, it resolves to a canonical molecular identity with physicochemical properties:

```
"Niacinamide" → SMILES: c1ccc(c(c1)C(=O)N)N
              → LogP: -0.4, MW: 122.12, TPSA: 56.0
              → charge: nonionic, HBD: 1, HBA: 3
```

Three-tier lookup: a seed cache of 2,400+ ingredients ships with the package, a persistent user cache grows from lookups, and PubChem's 116M-compound database serves as the runtime fallback. On our benchmark (938 unique molecules from MixtureSolDB), the resolver achieved a 94% hit rate.

This bridge is essential. Without it, a formulation is a list of names. With it, a formulation becomes a molecular system whose physics can be computed.

---

## Molecular Features Are the Primary Signal

We evaluated this claim on MixtureSolDB (Vasconcelos et al. 2026), a dataset of 146,000 experimental solubility measurements across 807 organic compounds dissolved in 750 binary solvent mixtures at temperatures from 252K to 383K. The data comes from 1,115 peer-reviewed sources. 28% of the solutes are FDA-approved drugs.

The prediction task: given a compound, a binary solvent mixture at a specific ratio, and a temperature, predict the log-solubility (mole fraction).

We compared two feature representations:

**Composition features** (3 dimensions): solvent fractions and temperature. The model knows the mixture ratio and conditions but has no information about the molecular identity of any component.

**Molecular features** (23 dimensions): composition features plus LogP, molecular weight, TPSA, hydrogen bond donors, and hydrogen bond acceptors for all three components (solute, solvent 1, solvent 2), plus interaction terms (LogP delta between solute and weighted mixture, TPSA delta, hydrogen bond complementarity).

All molecular properties were computed by the OpenMix resolver from SMILES strings in the dataset. No RDKit required at runtime.

| Evaluation | Composition Only | + Molecular Features |
|-----------|:---:|:---:|
| Random split (XGBoost, n=146K) | R² 0.15 | **R² 0.91** |
| Leave-solutes-out (80 held-out compounds) | R² 0.13 | **R² 0.52** |

The random split result confirms that molecular features are the dominant signal. Composition alone explains 15% of variance; adding 20 molecular descriptors explains 91%. The model learns, for example, that hydrophobic solutes (high LogP) dissolve poorly in polar solvent mixtures (high TPSA) and that molecular weight affects solubility non-linearly.

The leave-solutes-out result is more revealing. 80 compounds were held out entirely from training. The model had never seen their molecular descriptors. With composition alone (R² 0.13), prediction on unseen compounds is essentially random. With molecular features (R² 0.52), the model captures generalizable structure-property relationships.

The gap between 0.91 and 0.52 quantifies the generalization frontier. Simple molecular descriptors (LogP, MW, TPSA) capture broad physicochemical trends: hydrophobic solutes dissolve better in nonpolar solvents, smaller molecules are generally more soluble, polar surfaces predict hydrogen bonding capacity. These are first-order effects. What five scalar descriptors cannot capture are the second-order effects: specific molecular interactions, conformational flexibility, binding geometries, and the non-additive behavior where a third component modifies the interaction between the other two.

The top predictive features are solvent molecular weight, solute molecular weight, solute LogP, mixture-weighted LogP, and TPSA delta. These are basic physicochemical properties, resolved from SMILES by the OpenMix resolver. The fact that these five numbers improve R² by a factor of 6 on random splits and 4 on unseen compounds illustrates the state of the field: mixture science lacks even the basic computational infrastructure that molecular science takes for granted.

We validated this further on DE-INTERACT (Larasati et al. 2023), a dataset of 4,248 drug-excipient compatibility pairs across 470 drugs and 266 excipients with PubChem CACTVS fingerprints. The task is binary classification: compatible or incompatible. Adding molecular descriptors from the resolver improved leave-drugs-out AUROC from 0.868 to 0.903 and incompatibility detection F1 from 0.229 to 0.296. A different domain, a different task type, and the same finding: molecular features from the resolver improve generalization to unseen compounds.

Closing the generalization gap requires richer molecular representations. The mixture fingerprint literature (Buin et al., 2021; Chew et al., 2025) has shown that learned, permutation-invariant representations of multi-component systems outperform handcrafted descriptors, particularly for non-linear mixture behavior. CheMixHub's benchmarks (Rajaonson et al., 2025) confirm this: pre-trained molecular language models (MolT5) beat both GNNs and traditional cheminformatics descriptors across most tasks. OpenMix's descriptor-based baseline establishes the floor. Learned representations would raise the ceiling. The framework is designed to accommodate both, and this is the direction Layer 2 takes.

---

## The Knowledge Base

Beyond molecular physics, formulation science encodes decades of domain expertise about ingredient interactions. OpenMix represents this knowledge as structured YAML rules, each with a confidence score, a literature citation, optional conditions, and optional mitigations:

```yaml
- a: RETINOL
  b: ASCORBIC ACID
  type: soft
  confidence: 0.7
  source: "Skin Pharmacol Physiol 2006"
  conditions:
    ph_below: 4.0
  severity_by_mode:
    safety: warning
    formulation: info
    discovery: ignore
  mitigation: "Use retinyl palmitate or separate into AM/PM routine"
  message: >
    Retinol is unstable in the acidic conditions required for
    L-Ascorbic Acid (pH 2.5-3.5). Both lose efficacy.
```

85 rules span 6 domains: skincare (21 rules), pharma (15), supplements (13), food science (10), home care (21), and beverages (5). Rules are classified as hard (unconditional, dangerous: bleach + ammonia → chloramine gas) or soft (conditional, context-dependent: niacinamide + vitamin C at low pH).

Three validation modes control how rules are applied. In safety mode, all rules fire. In formulation mode, soft rules provide informational messages with mitigations. In discovery mode, only hard rules fire, giving researchers freedom to explore debated interactions.

When OpenMix validates a formula in a domain with thin rule coverage, it says so explicitly. A clean validation report in a domain with 5 rules is less meaningful than a clean report in a domain with 40. This kind of epistemic honesty, knowing the limits of what you know, is essential for tools used in scientific contexts.

The knowledge base is designed for community contribution. Chemists add rules in YAML without writing code. Each rule requires a literature source and a confidence score. The goal is a shared, version-controlled repository of formulation knowledge that improves over time.

---

## The Data Gap

While building FormulaBench (our benchmark for formulation property prediction), we encountered a finding that may be as significant as any of our results: the data infrastructure for formulation science barely exists.

We surveyed publicly available datasets for multi-component formulation outcomes. The inventory:

- **Shampoo stability** (Velho et al. 2024, Nature Scientific Data): 812 formulations, 18 ingredients. The only public cosmetic formulation stability dataset with proper labels.
- **MixtureSolDB** (Vasconcelos et al. 2026): 175,000 solubility measurements, but these are compound-in-binary-solvent systems, not full multi-component formulations.
- **CheMixHub** (Rajaonson et al. 2025): ~500,000 mixture property measurements across 7 datasets, primarily thermophysical properties of simple binary/ternary mixtures.
- **Drug-excipient compatibility** (DE-INTERACT, Larasati et al. 2023): 3,728 binary drug-excipient pairs. Classification, not formulation-level.

Every large consumer goods company has thousands of formulations with stability data. Every pharmaceutical company has extensive excipient compatibility databases. This data exists, but it is locked inside corporate R&D departments.

The absence of public multi-component formulation datasets is the single largest bottleneck for computational formulation science. ImageNet catalyzed computer vision. GLUE catalyzed NLP. Formulation science has no equivalent benchmark.

FormulaBench is our attempt to start building one. It currently includes three tasks (shampoo stability, pharmaceutical solubility, binary mixture solubility) with defined splits, baselines, and evaluation protocols. The MixtureSolDB integration demonstrates what becomes possible when data and molecular infrastructure meet. We need more datasets, more domains, and more outcome types to build a benchmark that the community can rally around.

---

## Architecture and Roadmap

OpenMix is designed as layered infrastructure. Each layer is independently useful and builds on the ones below:

```
Layer 4: EXPERIMENT       Autonomous agents, cloud lab integration, active learning
Layer 3: OPTIMIZE         Multi-objective design, Bayesian search, ingredient substitution
Layer 2: PREDICT          Trained mixture models, learned representations, FormulaBench
Layer 1.5: OBSERVE  ←     Physics observation engine, dual modes, molecular scoring
Layer 1: VALIDATE         85 rules, 3 modes, coverage honesty
Layer 0: FOUNDATION       Formulation schema, ingredient resolver, knowledge base
```

Layers 0 through 1.5 are shipped. Layer 2 is next, motivated directly by the leave-solutes-out gap (R² 0.52 vs 0.91). The question Layer 2 addresses: can learned molecular representations for mixtures close that gap? If a GNN or transformer trained on mixture outcome data can push the leave-solutes-out R² from 0.52 toward 0.91, that would be a meaningful contribution to both the ML and formulation science communities.

Layers 3 and 4 depend on Layer 2 producing reliable predictions. Multi-objective optimization requires a differentiable objective. Autonomous experimentation requires a model confident enough to guide laboratory investment. The architecture makes these dependencies explicit.

---

## Related Work

OpenMix is part of a growing ecosystem of AI-for-science tools. Several have directly influenced our design.

**Buehler's autonomous materials discovery systems.** The progression from AtomAgents (Ghafarollahi & Buehler, 2024, PNAS 2025) through SciAgents (Advanced Materials, 2025) to SparksMatter (2025) and ScienceClaw x Infinite (2026) represents the most ambitious attempt at multi-agent scientific discovery. Each system chains specialized LLM agents with physics simulations (molecular dynamics, DFT) to design materials autonomously. SparksMatter's approach to evaluation is particularly relevant: it computes actual physical properties (energy above hull, band gap, elastic modulus) with physically meaningful thresholds rather than arbitrary scores. We adopted this principle for the observation engine. Where we differ is architectural: ScienceClaw coordinates 300+ agents through emergent artifact exchange and pressure-based scoring. OpenMix uses a single observation engine with mode selection. The tradeoff is scope versus interpretability. A multi-agent swarm can cover more ground; a single engine produces observations that are easier to audit and debug.

**The AI Scientist** (Lu et al., 2024; Sakana AI, published in Nature) demonstrated end-to-end automated research at ~$15 per paper: idea generation, experiment implementation, paper writing, and automated peer review. Version 2 (Yamada et al., 2025) submitted AI-generated papers to ICLR workshops, with one scoring above the median of human submissions. The relevant lesson for formulation science is that the bottleneck is rarely ideation or execution. It is evaluation and data. The AI Scientist works because ML experiments are cheap compute. Formulation experiments require physical labs. This asymmetry is why OpenMix prioritizes the observation and prediction layers before the autonomous experimentation layer.

**ChemCrow** (Bran et al., 2024, Nature Machine Intelligence) and **Coscientist** (Boiko et al., 2023, Nature) showed that LLMs augmented with chemistry tools can perform multi-step chemical reasoning and even control cloud lab hardware. ChemCrow integrates 18 tools (reaction predictors, safety checks, property calculators) and autonomously synthesized an insect repellent and three organocatalysts. Coscientist closed the digital-to-physical loop by controlling Emerald Cloud Lab equipment to optimize palladium-catalyzed cross-coupling reactions. Both systems operate on single molecules and reactions. OpenMix extends the same tool-augmented-LLM principle to multi-component mixture science, where the reasoning must consider how ingredients interact at specific concentrations and conditions.

**CheMixHub** (Rajaonson et al., 2025) provides the most comprehensive benchmark for mixture property prediction, with ~500K measurements across 11 tasks and 7 datasets. Their evaluation protocols (random, leave-molecules-out, leave-mixtures-out) directly informed our benchmark design. A key finding: pre-trained molecular language model representations (MolT5) outperform both GNN and traditional cheminformatics descriptors across most tasks, but XGBoost with handcrafted features remains competitive on 7 of 11 tasks. The exceptions, where tree-based models fail, are precisely the tasks with strong non-additive behavior (excess enthalpy of mixing). This aligns with our MixtureSolDB findings: simple molecular descriptors capture most of the signal, but the hardest prediction problems require representations that encode interaction physics.

**Mixture representation.** The question of how to featurize a multi-component mixture for ML remains open. Concatenating molecular fingerprints creates an artificial dependence on component ordering (Buin et al., 2021, JCIM). Weighted sums are permutation-invariant but lose pairwise interaction information. Set2Set architectures (Chew et al., 2025, npj Computational Materials) use LSTM and attention to learn order-invariant representations and identified promising formulations 2-3x faster than random search. OpenMix's observation engine takes an orthogonal approach: rather than learning representations end-to-end, it generates interpretable physics-based observations that can serve as features for any downstream model. The two approaches are complementary.

---

## Try It

```bash
pip install openmix
```

```python
from openmix import Formula, observe

formula = Formula(
    ingredients=[
        ("Water", 60.0), ("Retinol", 2.0), ("Squalane", 15.0),
        ("Cetyl Alcohol", 5.0), ("Glycerin", 8.0),
        ("Niacinamide", 5.0), ("Ascorbic Acid", 5.0),
    ],
    category="skincare",
)
# Engineering: what needs fixing?
print(observe(formula, mode="engineering"))

# Discovery: what's surprising?
print(observe(formula, mode="discovery"))
```

GitHub: [github.com/vijayvkrishnan/openmix](https://github.com/vijayvkrishnan/openmix)

OpenMix is Apache 2.0 licensed. The highest-impact contributions are domain knowledge (YAML interaction rules for pharma, food, materials science) and benchmark datasets (formulations with known outcomes). If you have formulation data that could become part of FormulaBench, we want to hear from you.

---

*OpenMix resolves any ingredient to its molecular identity and observes formulations through physics, out of the box, no training data required. The knowledge base catches dangerous interactions. The experiment runner automates exploration. And because evaluation is pluggable, proprietary stability data becomes a force multiplier. The more diverse your ingredient space, the more the molecular features differentiate.*
