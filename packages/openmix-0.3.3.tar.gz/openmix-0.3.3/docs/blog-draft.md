# The Missing Layer in Computational Chemistry: Open Infrastructure for Mixture Science

*Vijay Krishnan, April 2026*

---

## Why Mixtures Are Hard

Computational chemistry has made extraordinary progress on individual molecules. RDKit computes molecular descriptors. AlphaFold predicts protein structure. ChemProp and MoLFormer predict molecular properties with increasing accuracy. DeepChem provides a unified framework for molecular machine learning.

All of this work operates on the same fundamental unit: a single molecule, represented as a graph or a SMILES string, with properties that can be computed or predicted from its structure alone.

Formulation science operates on a different unit entirely: the mixture. A shampoo is 12 surfactants, polymers, and thickeners in water. A pharmaceutical tablet is an active ingredient embedded in a matrix of excipients. A cosmetic serum is a dozen actives and functional ingredients at precise concentrations, in specific phases, at a target pH.

The properties of these systems are not sums of their parts. When you mix an anionic surfactant with a cationic polymer, the resulting coacervate has properties that neither component has alone. When you dissolve a hydrophobic drug in a binary solvent mixture, the solubility depends on the interaction between all three components, not just the drug's LogP. When you combine Retinol with Ascorbic Acid at low pH, both degrade faster than either would alone.

Thermodynamics provides the precise language for this challenge. An "ideal mixture" is one where properties are simple mole-fraction-weighted averages of pure component properties: the enthalpy of mixing is zero, the volume of mixing is zero. Real mixtures deviate from this because of intermolecular interactions between unlike molecules. These deviations, called *excess properties*, are exactly what formulation scientists care about and exactly what additive models cannot capture.

Ethanol and water, for instance, contract when mixed. The volume of the mixture is measurably less than the sum of the pure volumes because water molecules fill structural gaps in the ethanol network. The excess enthalpy of the system reflects the formation of hydrogen bonds between unlike molecules that are stronger than those between like molecules. These are emergent properties of the mixture, invisible in the properties of either component alone.

Scale this to a real formulation with 12-20 components, where surfactants self-assemble above critical micelle concentrations, polymers undergo conformational changes in the presence of salts, and pH-dependent ionization shifts the effective charge balance, and the non-additivity becomes the dominant factor.

The established computational approaches to mixture prediction reflect this difficulty. COSMO-RS (Klamt, 1995) predicts thermodynamic properties from quantum-chemical calculations on individual molecules, using screening charge density surfaces to compute interaction energies. It works well for simple solvent systems but requires a quantum-chemical calculation for each molecule and struggles with the self-assembly, kinetic phenomena, and many-body effects that dominate real formulations. Hansen Solubility Parameters (Hansen, 1967) offer a simpler heuristic: represent molecules as points in a three-dimensional space (dispersion, polarity, hydrogen bonding) where "like dissolves like." Mixture properties are assumed to be volume-fraction-weighted averages, strictly additive, no interaction terms. Useful for initial solvent screening but fundamentally limited for complex biological systems.

Neither approach scales to the combinatorial reality of modern formulation. A cosmetics company might work with 500 ingredients. The number of possible 12-ingredient combinations at varying concentrations is astronomical. The knowledge about which combinations work, and why, lives in institutional memory, proprietary databases, and the heads of experienced formulation scientists.

There is no open-source framework for computational mixture science. No shared representation for formulations. No public benchmark for mixture property prediction. No open knowledge base of ingredient interactions.

OpenMix is our attempt to build that infrastructure.

---

## Observations, Not Scores

The first design decision in OpenMix was architectural, and it came from studying how existing AI-for-science systems evaluate their outputs.

Most autonomous chemistry systems use a scalar objective function: a score from 0-100, a predicted yield, a computed stability metric. The agent optimizes against this number. This works for engineering: hill-climbing toward a known objective is well-understood. Bayesian optimization, reinforcement learning, and even simple LLM iteration loops can all optimize a scalar.

Buehler's SparksMatter system takes a more principled approach, computing actual physical properties (energy above hull, band gap, elastic modulus) with physically meaningful thresholds rather than arbitrary weighted scores. This is the right direction: physics as computational tools, with physical quantities that have real units and real interpretations.

We took this principle further. OpenMix's observation engine reports structured physics observations, each containing what was measured, what physics predicted, and whether they agree:

```python
from openmix import Formula, observe

cream = Formula(
    name="Retinol Night Cream",
    ingredients=[
        ("Water", 60.0), ("Retinol", 2.0), ("Squalane", 15.0),
        ("Cetyl Alcohol", 5.0), ("Glycerin", 8.0),
        ("Niacinamide", 5.0), ("Ascorbic Acid", 5.0),
    ],
    target_ph=5.5,
    category="skincare",
)
print(observe(cream))
```

```
Violations (0 hard, 2 soft):
  [SOFT (conf 0.7)] RETINOL + ASCORBIC ACID
    Retinol is unstable in the acidic conditions required for L-Ascorbic Acid.
  [SOFT (conf 0.5)] NIACINAMIDE + ASCORBIC ACID
    At low pH, niacinamide may convert to nicotinic acid. Widely debated.

MOLECULAR:
  [!] Squalane: LogP 14.7 at 15.0% -- hydrophobic
      LogP 14.7 suggests poor water solubility. Ensure adequate emulsifier.

STRUCTURAL:
  [!] Water-based formula without detected preservative

PHASE:
  [?] Hydrophobic phase: 22.0% -- Retinol (2.0%), Squalane (15.0%),
      Cetyl Alcohol (5.0%)

PH:
  [ ] Niacinamide: 99% deprotonated at pH 5.5 (pKa 3.35). Within optimal range.
  [!] Ascorbic Acid: 96% ionized at pH 5.5 (pKa 4.17). Susceptible to
      oxidative degradation. Optimal pH: 2.5-3.5.

Concern count: 4.1
```

Each observation is a structured record: category, subject, what was observed, what was expected, whether they agree, the source of the expectation, and a confidence score. The system reports what it sees. The consumer of the observations decides what to do about it.

This architecture choice has a consequence that turned out to be the most interesting part of the project.

---

## One Chassis, Two Modes

Engineering and discovery look like different activities, but they share the same cognitive operation: compare expectations to observations.

An engineer designing a stable shampoo has expectations about how surfactants interact, what pH range is needed, whether the emulsion system will hold. When observations match expectations, the formula is on track. When they disagree, the engineer adjusts the formula to resolve the discrepancy. The goal is convergence: zero discrepancies, a formula that behaves as expected.

A researcher investigating a novel drug-excipient interaction also has expectations. But when observations disagree with expectations, the researcher does something fundamentally different. Instead of adjusting the formula to match the expectation, they investigate the discrepancy itself. The expectation might be wrong. The disagreement might reveal something new.

This distinction maps directly to the history of scientific discovery. Fleming expected a contaminated petri dish to show uniform bacterial growth. The observation (a clear zone around the mold) disagreed with the expectation. He investigated the discrepancy instead of discarding the plate. Mojica expected the repeated DNA sequences in archaea to be junk. They weren't. The GLP-1 receptor agonists developed for diabetes showed unexpected weight loss. Someone investigated instead of dismissing the side effect.

The pattern is consistent: expectation existed, something violated it, someone noticed the violation, they investigated rather than dismissing, and the investigation revealed something new. Discovery is the investigation of surprise.

In OpenMix, the same observation engine serves both purposes:

**Engineering mode** treats discrepancies as problems. The optimization target is zero concerns. The autonomous experiment runner uses this mode to iterate toward stable, manufacturable formulations. Every discrepancy the physics engine reports is something the LLM agent tries to resolve.

**Discovery mode** treats discrepancies as signals. Hard violations still block (bleach and ammonia produce toxic chloramine gas regardless of your intent). But soft violations surface as "signals" and low-confidence observations surface as "knowledge gaps." The system explicitly flags where its expectations might be wrong.

```python
obs = observe(formula, mode="discovery")
obs.signals       # Soft violations: interesting interactions to explore
obs.discoveries   # Low-confidence discrepancies: expectations that may be wrong
```

The same infrastructure, two fundamentally different uses. A consumer goods company uses engineering mode to develop products. A pharmaceutical researcher uses discovery mode to investigate which interactions the knowledge base might have wrong.

---

## Multiple Perspectives, Classified Disagreements

A single evaluation framework has blind spots. The physics engine knows about LogP and charge balance but has no opinion about whether MgSt catalyzes Maillard reactions. The knowledge base knows about documented drug-excipient interactions but cannot predict interactions for novel drugs. A machine learning model knows what worked before but cannot explain why.

The discourse engine evaluates formulations from multiple computational perspectives simultaneously. Each perspective has different tools, different knowledge, and different evidence:

- **Physics**: molecular properties computed from SMILES (LogP, charge density, HLB, functional groups via RDKit SMARTS)
- **Chemistry**: 273 curated interaction rules with literature sources, confidence scores, and conditional logic
- **Data**: findings from prior experiments, accumulated across runs with confidence tracking
- **Process**: manufacturing protocol evaluation (thermal limits, phase assignment, homogenization, pH adjustment)

The output is classified by how the perspectives relate:

**Agreement**: perspectives concur. The assessment is reliable.

**Correction**: one perspective has significantly stronger evidence. A computational prediction from molecular structure overrides an LLM's unsupported reasoning. An empirical result from three prior experiments overrides a heuristic rule of thumb. The evidence hierarchy is explicit: empirical data > computation > rules > heuristics > LLM reasoning.

**True disagreement**: perspectives have comparable evidence but reach different conclusions. Neither can disprove the other. These are the cases worth investigating. A physics perspective that flags poor water solubility based on LogP, contradicted by a data perspective showing the ingredient working in three prior formulations, reveals a gap in the physics model. That ingredient might be an emulsifier whose hydrophobicity is the point.

**Knowledge gap**: no perspective has enough information. The system says "we don't know" rather than silently producing a partial assessment.

```python
from openmix.discourse import evaluate_discourse

disc = evaluate_discourse(formula, protocol=protocol, memory=memory)
disc.agreements           # All perspectives concur
disc.corrections          # Stronger evidence overrides weaker
disc.true_disagreements   # Comparable evidence, different conclusions
disc.knowledge_gaps       # Nobody has enough information
```

This classification matters because it determines the response. Corrections get applied. Knowledge gaps get flagged for lab testing. True disagreements get investigated. The discourse engine does not average the perspectives or pick the most conservative answer. It makes the disagreement structure visible.

---

## The Identity Problem

Before you can reason about mixture physics, you need to know what the molecules are. This sounds trivial. It is not.

Formulation scientists work in domain-specific nomenclature. A cosmetic chemist uses INCI names: "Cetearyl Alcohol," "Polysorbate 80," "Sodium Cocoyl Glutamate." A pharmaceutical scientist uses USP names and brand names. A food scientist uses E-numbers and common names.

Computational chemistry tools work in SMILES, InChI, and molecular graphs.

The bridge between these worlds is OpenMix's ingredient resolver. Given any ingredient name, it resolves to a canonical molecular identity with physicochemical properties:

```
"Niacinamide" -> SMILES: c1ccc(c(c1)C(=O)N)N
              -> LogP: -0.4, MW: 122.12, TPSA: 56.0
              -> charge: nonionic, HBD: 1, HBA: 3
```

Three-tier lookup: a seed cache of 2,400+ ingredients ships with the package, a persistent user cache grows from lookups, and PubChem's 116M-compound database serves as the runtime fallback. On our benchmark (938 unique molecules from MixtureSolDB), the resolver achieved a 94% hit rate.

This bridge is essential. Without it, a formulation is a list of names. With it, a formulation becomes a molecular system whose physics can be computed.

---

## Mechanism-Based Prediction

Ingredient interaction databases are lookup tables. Documented interaction A + B exists? Flag it. Novel pair? Silence.

OpenMix takes a different approach for pharmaceutical formulations. The physics perspective detects reactive functional groups directly from molecular structure using RDKit SMARTS pattern matching: primary amines, esters, thiols, phenols, catechols, carboxylic acids, and aldehydes. Each functional group maps to specific degradation mechanisms:

- Primary amine + reducing sugar excipient = Maillard reaction risk
- Ester + alkaline excipient = hydrolysis risk
- Thiol + peroxide-containing excipient = oxidation risk
- Catechol + metal-containing excipient = chelation risk

An excipient property database classifies common excipients by their reactive properties: lactose and glucose as reducing sugars, PVP and polysorbate 80 as peroxide-containing, magnesium stearate and calcium carbonate as alkaline.

The result: OpenMix predicts drug-excipient interactions for drugs it has never seen before. Memantine, an NMDA antagonist prescribed for Alzheimer's disease, is not in the 273-rule knowledge base. When evaluated with a lactose-based tablet formulation, the physics perspective detects Memantine's primary amine from its SMILES string (fetched from PubChem), classifies lactose monohydrate as a reducing sugar, and predicts Maillard reaction risk with 0.9 confidence.

This prediction is correct. Memantine's primary amine is known to undergo Maillard reaction with lactose, confirmed by accelerated stability studies. The system arrived at this conclusion through molecular structure analysis, generalizable to any drug with a detectable amine group.

Alongside the 273 curated rules (95 pharma-specific, covering Maillard reactions, chelation, MgSt-catalyzed hydrolysis, PVP peroxide oxidation, and enteric coating dissolution), the mechanism-based prediction extends coverage to the full space of structurally characterizable drugs.

---

## Physics on Real Data

We tested whether physics-derived features improve stability prediction on real formulation data.

**Surfactant charge balance.** Using literature-derived charge densities (meq/g) for each surfactant class, we computed the molar charge ratio Z for 812 shampoo formulations from the Velho et al. (2024) dataset. Polyquaternium-6 (a high-charge-density cationic polymer at 6.2 meq/g) contributes roughly 3x more cationic charge per gram than Polyquaternium-7 (2.3 meq/g). Standard concentration-based features treat them identically.

Charge densities were computed from molecular weights and published monomer compositions (Wang & Dubin, Langmuir 2023; Thompson, Macromol. Chem. Phys. 2023), then applied to the dataset without fitting:

| Charge Ratio Z | Stable | Total | Stability Rate |
|---|---|---|---|
| Outside danger zone | 152 | 402 | 38% |
| 0.5 - 2.0 (danger zone) | 7 | 87 | 8% |

Fisher's exact test: odds ratio 6.95, p < 0.0000001. Formulations near charge neutralization (Z approaching 1.0) are 7x more likely to be unstable. This is a physics-first result: no training data, no model fitting, charge densities from the literature applied directly to formulation compositions.

**Stability prediction.** We trained XGBoost classifiers on the same dataset using three feature sets:

| Features | Mean AUROC (10-split LIO) |
|---|---|
| Composition only (18 raw percentages) | 0.713 |
| + Physics (Z ratio, charge density, nonionic shielding) | 0.735 |

Physics-informed features improve leave-ingredients-out generalization by +3.1%, winning 9 of 10 random splits. The improvement is modest but consistent and grounded in thermodynamics.

**Mixture solubility.** On MixtureSolDB (Vasconcelos et al. 2026), 146,000 experimental solubility measurements across 807 compounds, molecular features from the resolver improve leave-solutes-out R^2 from 0.13 (composition alone) to 0.52. Simple molecular descriptors (LogP, MW, TPSA) capture broad physicochemical trends. The gap between random-split R^2 (0.91) and leave-solutes-out R^2 (0.52) quantifies the generalization frontier for descriptor-based mixture prediction.

---

## The Knowledge Base

Beyond molecular physics, formulation science encodes decades of domain expertise about ingredient interactions. OpenMix represents this knowledge as structured YAML rules, each with a confidence score, a literature citation, optional conditions, and optional mitigations:

```yaml
- a: RETINOL
  b: ASCORBIC ACID
  type: soft
  confidence: 0.7
  source: "Skin Pharmacol Physiol 2006"
  conditions:
    ph_below: 4.0
  severity_by_mode:
    safety: warning
    formulation: info
    discovery: ignore
  mitigation: "Use retinyl palmitate or separate into AM/PM routine"
  message: >
    Retinol is unstable in the acidic conditions required for
    L-Ascorbic Acid (pH 2.5-3.5). Both lose efficacy.
```

273 rules span 6 domains: skincare, pharma (95 rules covering the top prescribed drugs), supplements, food science, home care, and beverages. Rules are classified as hard (unconditional, dangerous: bleach + ammonia produces toxic chloramine gas) or soft (conditional, context-dependent: niacinamide + vitamin C at low pH).

Three validation modes control how rules are applied. In safety mode, all rules fire. In formulation mode, soft rules provide informational messages with mitigations. In discovery mode, only hard rules fire, giving researchers freedom to explore debated interactions.

When OpenMix validates a formula in a domain with thin rule coverage, it says so explicitly. A clean validation report in a domain with 5 rules is less meaningful than a clean report in a domain with 95. This kind of epistemic honesty is essential for tools used in scientific contexts.

The knowledge base is designed for community contribution. Chemists add rules in YAML without writing code. Each rule requires a literature source and a confidence score. The goal is a shared, version-controlled repository of formulation knowledge that improves over time.

---

## Experiment Memory

The autonomous experiment runner learns across runs. A three-layer memory system persists findings with confidence scores:

- **Index**: lightweight summary of every experiment (loaded into the LLM's system prompt)
- **Logs**: complete trial data from each run (fetched on demand)
- **Discoveries**: cross-run findings extracted by a consolidation cycle after each experiment

When the same ingredient appears in the best trial across three experiments, its confidence increases. When an ingredient is consistently tried then dropped, that avoidance is recorded. New experiments receive prior knowledge as hints, but the observation engine remains the source of truth.

In practice, the memory system reduces convergence time. An experiment in a domain where prior runs have established a stable base (preservative system, humectant selection, chelator) converges in 1-2 iterations instead of 7+, because the LLM starts with ingredients that have been validated computationally in prior runs.

---

## The Data Gap

While building FormulaBench, our benchmark for formulation property prediction, we encountered a finding that may be as significant as any of our results: the data infrastructure for formulation science barely exists.

We surveyed publicly available datasets for multi-component formulation outcomes. The inventory:

- **Shampoo stability** (Velho et al. 2024, Nature Scientific Data): 812 formulations, 18 ingredients. The only public cosmetic formulation stability dataset with proper labels.
- **MixtureSolDB** (Vasconcelos et al. 2026): 175,000 solubility measurements, but these are compound-in-binary-solvent systems, not full multi-component formulations.
- **CheMixHub** (Rajaonson et al. 2025): ~500,000 mixture property measurements across 7 datasets, primarily thermophysical properties of simple binary/ternary mixtures.
- **Drug-excipient compatibility** (DE-INTERACT, Patel et al. 2023): 4,248 binary drug-excipient pairs. Classification, not formulation-level.

Every large consumer goods company has thousands of formulations with stability data. Every pharmaceutical company has extensive excipient compatibility databases. This data exists, but it is locked inside corporate R&D departments.

The absence of public multi-component formulation datasets is the single largest bottleneck for computational formulation science. ImageNet catalyzed computer vision. GLUE catalyzed NLP. Formulation science has no equivalent benchmark.

FormulaBench is our attempt to start building one. It currently includes four tasks with defined splits, baselines, and evaluation protocols. We need more datasets, more domains, and more outcome types to build a benchmark that the community can rally around.

---

## Architecture and Roadmap

OpenMix is designed as layered infrastructure. Each layer is independently useful and builds on the ones below:

```
Layer 4: EXPERIMENT       Autonomous agents, cloud lab integration, active learning
Layer 3: OPTIMIZE         Multi-objective design, Bayesian search, substitution
Layer 2: PREDICT          Trained mixture models, learned representations
Layer 1.5: DISCOURSE  <-  Multi-perspective evaluation, evidence hierarchy
Layer 1: OBSERVE          Physics engine, 273 rules, functional group detection
Layer 0: FOUNDATION       Formula + Protocol schema, resolver, knowledge base
```

Layers 0 through 1.5 are shipped. Layer 2 is next: can learned molecular representations for mixtures close the generalization gap (R^2 0.52 vs 0.91 on leave-solutes-out)? If a GNN or transformer trained on mixture outcome data can push that number toward 0.91, that would be a meaningful contribution to both the ML and formulation science communities.

Layers 3 and 4 depend on Layer 2 producing reliable predictions. Multi-objective optimization requires a differentiable objective. Autonomous experimentation requires a model confident enough to guide laboratory investment. The architecture makes these dependencies explicit.

---

## Related Work

OpenMix is part of a growing ecosystem of AI-for-science tools.

**Buehler's autonomous materials discovery systems.** The progression from AtomAgents through SciAgents to SparksMatter represents the most ambitious attempt at multi-agent scientific discovery. SparksMatter's approach to evaluation is particularly relevant: it computes actual physical properties with physically meaningful thresholds rather than arbitrary scores. We adopted this principle for the observation engine. Where we differ is architectural: ScienceClaw coordinates 300+ agents through emergent artifact exchange. OpenMix uses a structured discourse engine with an explicit evidence hierarchy. The tradeoff is scope versus interpretability.

**Virtual Lab** (Zou et al., 2024). Multiple AI agents with different scientific expertise hold structured research meetings. The most relevant precedent for OpenMix's discourse engine, though Virtual Lab uses LLM-based agents with prompt-defined expertise, while OpenMix's perspectives are backed by different computational tools (RDKit, knowledge base, experiment memory, protocol rules).

**The AI Scientist** (Lu et al., 2024; Sakana AI, published in Nature). End-to-end automated research at ~$15 per paper. The relevant lesson for formulation science is that the bottleneck is rarely ideation or execution. It is evaluation and data. The AI Scientist works because ML experiments are cheap compute. Formulation experiments require physical labs. This asymmetry is why OpenMix prioritizes the observation and prediction layers before autonomous experimentation.

**ChemCrow** (Bran et al., 2024, Nature Machine Intelligence) and **Coscientist** (Boiko et al., 2023, Nature). LLMs augmented with chemistry tools performing multi-step chemical reasoning and controlling cloud lab hardware. Both systems operate on single molecules and reactions. OpenMix extends the same tool-augmented principle to multi-component mixture science.

**CheMixHub** (Rajaonson et al., 2025). The most comprehensive benchmark for mixture property prediction. Their evaluation protocols (random, leave-molecules-out, leave-mixtures-out) directly informed our benchmark design. A key finding: pre-trained molecular language model representations (MolT5) outperform both GNN and traditional cheminformatics descriptors across most tasks. OpenMix's descriptor-based baseline establishes the floor. Learned representations would raise the ceiling.

---

## Try It

```bash
pip install openmix
```

```python
from openmix import Formula
from openmix.discourse import evaluate_discourse

tablet = Formula(
    name="Amlodipine 5mg Tablet",
    ingredients=[
        ("Amlodipine", 2.0), ("Lactose", 60.0),
        ("Microcrystalline Cellulose", 25.0),
        ("Magnesium Stearate", 1.0), ("Povidone", 3.0),
        ("Water", 9.0),
    ],
    category="pharma",
)
disc = evaluate_discourse(tablet)
disc.print_rich()
```

CLI:
```bash
openmix discourse formula.yaml        # Multi-perspective evaluation
openmix observe formula.yaml           # Physics observations
openmix validate formula.yaml          # Rule-based validation
openmix run "Design a stable serum"    # Autonomous experiment (needs API key)
openmix memory --discoveries           # View accumulated findings
openmix demo                           # Try it now (no API key)
```

MCP server (for AI agent integration):
```bash
python -m openmix.mcp_server           # 8 tools: discourse, observe, validate, ...
```

Tutorial: [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/vijayvkrishnan/openmix/blob/main/notebooks/tutorial.ipynb)

GitHub: [github.com/vijayvkrishnan/openmix](https://github.com/vijayvkrishnan/openmix)

OpenMix is Apache 2.0 licensed. The highest-impact contributions are domain knowledge (YAML interaction rules for pharma, food, materials science) and benchmark datasets (formulations with known outcomes). If you have formulation data that could become part of FormulaBench, we want to hear from you.

---

*OpenMix resolves any ingredient to its molecular identity and observes formulations through physics, out of the box, no training data required. The knowledge base catches dangerous interactions. The discourse engine surfaces where our understanding is incomplete. And because evaluation is pluggable, proprietary stability data becomes a force multiplier.*
