#!/usr/bin/env python3
"""
Layer 2: Trained mixture property prediction models.

Tests whether richer molecular representations close the generalization
gap on mixture solubility prediction.

Current baseline (5 descriptors/molecule): R2 0.91 random, 0.52 LSO.
Question: do Morgan fingerprints or learned representations do better
on compounds the model has never seen?

Usage:
    python examples/train_mixture_models.py
    python examples/train_mixture_models.py --quick
"""

from __future__ import annotations

import sys
import time
import numpy as np
from pathlib import Path

from sklearn.metrics import mean_absolute_error, r2_score
from xgboost import XGBRegressor

from openmix.benchmarks.mixture_solubility import MixtureSolubility, MixtureSolRecord

# RDKit for Morgan fingerprints
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors
from rdkit import RDLogger
RDLogger.DisableLog("rdApp.*")


# ---------------------------------------------------------------------------
# Molecular representations
# ---------------------------------------------------------------------------

_fp_cache: dict[str, np.ndarray] = {}
_desc_cache: dict[str, np.ndarray] = {}


def morgan_fingerprint(smiles: str, radius: int = 2, n_bits: int = 2048) -> np.ndarray:
    """Compute Morgan fingerprint from SMILES."""
    if smiles in _fp_cache:
        return _fp_cache[smiles]

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        result = np.zeros(n_bits, dtype=np.float32)
    else:
        gen = AllChem.GetMorganGenerator(radius=radius, fpSize=n_bits)
        fp = gen.GetFingerprint(mol)
        result = np.array(fp, dtype=np.float32)

    _fp_cache[smiles] = result
    return result


def rdkit_descriptors(smiles: str) -> np.ndarray:
    """Compute RDKit molecular descriptors from SMILES."""
    if smiles in _desc_cache:
        return _desc_cache[smiles]

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        result = np.zeros(8, dtype=np.float32)
    else:
        result = np.array([
            Descriptors.MolLogP(mol),
            Descriptors.MolWt(mol),
            Descriptors.TPSA(mol),
            Descriptors.NumHDonors(mol),
            Descriptors.NumHAcceptors(mol),
            Descriptors.NumRotatableBonds(mol),
            Descriptors.RingCount(mol),
            Descriptors.FractionCSP3(mol),
        ], dtype=np.float32)

    _desc_cache[smiles] = result
    return result


# ---------------------------------------------------------------------------
# Feature builders
# ---------------------------------------------------------------------------

def tier1_features(record: MixtureSolRecord) -> np.ndarray:
    """Composition only: solvent fractions + temperature."""
    return np.array([
        record.solvent1_fraction,
        record.solvent2_fraction,
        record.temperature_k,
    ], dtype=np.float32)


def tier2_descriptors(record: MixtureSolRecord) -> np.ndarray:
    """Composition + RDKit descriptors (8 per component) + interaction terms."""
    t1 = tier1_features(record)

    solute = rdkit_descriptors(record.solute_smiles)
    solv1 = rdkit_descriptors(record.solvent1_smiles)
    solv2 = rdkit_descriptors(record.solvent2_smiles)

    # Interaction terms
    f1, f2 = record.solvent1_fraction, record.solvent2_fraction
    mix_logp = solv1[0] * f1 + solv2[0] * f2
    logp_delta = abs(solute[0] - mix_logp)
    mix_tpsa = solv1[2] * f1 + solv2[2] * f2
    tpsa_delta = abs(solute[2] - mix_tpsa)
    hbond_complement = solute[3] * (solv1[4] * f1 + solv2[4] * f2) + \
                       solute[4] * (solv1[3] * f1 + solv2[3] * f2)

    interactions = np.array([
        mix_logp, logp_delta, tpsa_delta, hbond_complement,
    ], dtype=np.float32)

    return np.concatenate([t1, solute, solv1, solv2, interactions])


def tier3_morgan(record: MixtureSolRecord) -> np.ndarray:
    """Composition + Morgan fingerprints for all three components."""
    t1 = tier1_features(record)

    fp_solute = morgan_fingerprint(record.solute_smiles)
    fp_solv1 = morgan_fingerprint(record.solvent1_smiles)
    fp_solv2 = morgan_fingerprint(record.solvent2_smiles)

    # Weighted mixture fingerprint
    f1, f2 = record.solvent1_fraction, record.solvent2_fraction
    fp_mix = fp_solv1 * f1 + fp_solv2 * f2

    # Interaction fingerprint: element-wise product of solute and mixture
    fp_interact = fp_solute * fp_mix

    return np.concatenate([t1, fp_solute, fp_mix, fp_interact])


def tier4_combined(record: MixtureSolRecord) -> np.ndarray:
    """Everything: composition + descriptors + Morgan FPs + interactions."""
    desc = tier2_descriptors(record)
    morgan = tier3_morgan(record)
    return np.concatenate([desc, morgan])


TIERS = {
    "Tier 1: Composition only": (tier1_features, 3),
    "Tier 2: RDKit descriptors": (tier2_descriptors, 31),
    "Tier 3: Morgan fingerprints": (tier3_morgan, 6147),
    "Tier 4: Descriptors + Morgan": (tier4_combined, 6178),
}


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------

def evaluate_xgb(X_train, y_train, X_test, y_test):
    """Train XGBoost and return metrics."""
    model = XGBRegressor(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.1,
        random_state=42,
        tree_method="hist",
    )
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    return {
        "mae": mean_absolute_error(y_test, preds),
        "r2": r2_score(y_test, preds),
        "model": model,
    }


def evaluate_mlp(X_train, y_train, X_test, y_test):
    """Train a neural network and return metrics."""
    from sklearn.neural_network import MLPRegressor
    from sklearn.preprocessing import StandardScaler

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)

    model = MLPRegressor(
        hidden_layer_sizes=(256, 128, 64),
        activation="relu",
        max_iter=200,
        early_stopping=True,
        validation_fraction=0.1,
        random_state=42,
    )
    model.fit(X_train_s, y_train)
    preds = model.predict(X_test_s)
    return {
        "mae": mean_absolute_error(y_test, preds),
        "r2": r2_score(y_test, preds),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run():
    quick = "--quick" in sys.argv
    max_records = 15000 if quick else None

    print("Loading MixtureSolDB...", flush=True)
    ds = MixtureSolubility(binary_only=True, max_records=max_records)
    print(ds)
    print()

    # Precompute fingerprints and descriptors
    all_smiles = set()
    for r in ds.records:
        all_smiles.add(r.solute_smiles)
        all_smiles.add(r.solvent1_smiles)
        all_smiles.add(r.solvent2_smiles)

    print(f"Computing molecular representations for {len(all_smiles)} molecules...",
          end=" ", flush=True)
    t0 = time.time()
    valid = 0
    for smi in all_smiles:
        morgan_fingerprint(smi)
        rdkit_descriptors(smi)
        mol = Chem.MolFromSmiles(smi)
        if mol is not None:
            valid += 1
    print(f"{valid}/{len(all_smiles)} valid SMILES ({time.time()-t0:.1f}s)")
    print()

    # Splits
    train_rand, val_rand, test_rand = ds.split_random(test_size=0.1, val_size=0.1, seed=42)
    n_hold = max(10, ds.unique_solutes // 10)
    train_lso, test_lso = ds.split_leave_solutes_out(n_held_out=n_hold, seed=42)

    print(f"Random split: train={len(train_rand)} val={len(val_rand)} test={len(test_rand)}")
    print(f"Leave-solutes-out: train={len(train_lso)} test={len(test_lso)} "
          f"({n_hold} solutes held out)")
    print()

    # Results storage
    results = {}

    for tier_name, (feat_fn, expected_dims) in TIERS.items():
        print(f"{'=' * 70}")
        print(f"  {tier_name} ({expected_dims} features)")
        print(f"{'=' * 70}")

        # Build features
        print("  Building features...", end=" ", flush=True)
        t0 = time.time()

        X_train_r = np.array([feat_fn(r) for r in train_rand], dtype=np.float32)
        X_test_r = np.array([feat_fn(r) for r in test_rand], dtype=np.float32)
        y_train_r = np.array([r.log_solubility for r in train_rand], dtype=np.float32)
        y_test_r = np.array([r.log_solubility for r in test_rand], dtype=np.float32)

        X_train_l = np.array([feat_fn(r) for r in train_lso], dtype=np.float32)
        X_test_l = np.array([feat_fn(r) for r in test_lso], dtype=np.float32)
        y_train_l = np.array([r.log_solubility for r in train_lso], dtype=np.float32)
        y_test_l = np.array([r.log_solubility for r in test_lso], dtype=np.float32)

        print(f"({time.time()-t0:.1f}s, shape={X_train_r.shape})")

        # XGBoost
        print("  XGBoost (random)...", end=" ", flush=True)
        res_xgb_r = evaluate_xgb(X_train_r, y_train_r, X_test_r, y_test_r)
        print(f"MAE={res_xgb_r['mae']:.4f}  R2={res_xgb_r['r2']:.4f}")

        print("  XGBoost (LSO)...", end=" ", flush=True)
        res_xgb_l = evaluate_xgb(X_train_l, y_train_l, X_test_l, y_test_l)
        print(f"MAE={res_xgb_l['mae']:.4f}  R2={res_xgb_l['r2']:.4f}")

        # MLP (skip for tier 3/4 on full dataset - too slow)
        if X_train_r.shape[1] <= 100 or quick:
            print("  MLP (random)...", end=" ", flush=True)
            res_mlp_r = evaluate_mlp(X_train_r, y_train_r, X_test_r, y_test_r)
            print(f"MAE={res_mlp_r['mae']:.4f}  R2={res_mlp_r['r2']:.4f}")

            print("  MLP (LSO)...", end=" ", flush=True)
            res_mlp_l = evaluate_mlp(X_train_l, y_train_l, X_test_l, y_test_l)
            print(f"MAE={res_mlp_l['mae']:.4f}  R2={res_mlp_l['r2']:.4f}")
        else:
            print("  MLP (skipped for high-dim features on full dataset)")
            res_mlp_r = {"mae": None, "r2": None}
            res_mlp_l = {"mae": None, "r2": None}

        results[tier_name] = {
            "xgb_random": res_xgb_r,
            "xgb_lso": res_xgb_l,
            "mlp_random": res_mlp_r,
            "mlp_lso": res_mlp_l,
        }
        print()

    # Summary
    print("=" * 70)
    print(f"  {'Representation':<35} {'XGB Random':>12} {'XGB LSO':>12} {'MLP LSO':>12}")
    print(f"  {'':35} {'R2':>12} {'R2':>12} {'R2':>12}")
    print("  " + "-" * 71)
    for tier_name, res in results.items():
        xr = res["xgb_random"]["r2"]
        xl = res["xgb_lso"]["r2"]
        ml = res["mlp_lso"]["r2"]
        ml_str = f"{ml:.4f}" if ml is not None else "---"
        print(f"  {tier_name:<35} {xr:>12.4f} {xl:>12.4f} {ml_str:>12}")
    print("=" * 70)
    print()
    print("Key question: does the LSO R2 improve with richer representations?")
    print("Baseline (5 PubChem descriptors, previous run): LSO R2 = 0.52")


if __name__ == "__main__":
    run()
