#!/usr/bin/env python3
"""
Asymmetric cross-attention model for mixture solubility prediction.

The hypothesis: directed attention from solute to solvents captures
non-additive mixture interactions that concatenation/averaging misses.

The solute "attends" to the solvent environment. The model learns
which solute substructures interact with which solvent properties,
weighted by solvent fraction.

Usage:
    python examples/train_attention_model.py
    python examples/train_attention_model.py --quick
"""

from __future__ import annotations

import sys
import time
import numpy as np

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import mean_absolute_error, r2_score

from openmix.benchmarks.mixture_solubility import MixtureSolubility, MixtureSolRecord

from rdkit import Chem
from rdkit.Chem import AllChem
from rdkit import RDLogger
RDLogger.DisableLog("rdApp.*")


# ---------------------------------------------------------------------------
# Molecular encoding
# ---------------------------------------------------------------------------

_fp_cache: dict[str, np.ndarray] = {}


def morgan_fp(smiles: str, radius: int = 2, n_bits: int = 1024) -> np.ndarray:
    if smiles in _fp_cache:
        return _fp_cache[smiles]
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        result = np.zeros(n_bits, dtype=np.float32)
    else:
        gen = AllChem.GetMorganGenerator(radius=radius, fpSize=n_bits)
        fp = gen.GetFingerprint(mol)
        result = np.array(fp, dtype=np.float32)
    _fp_cache[smiles] = result
    return result


def build_tensors(records: list[MixtureSolRecord]):
    """Build input tensors: solute FP, solvent1 FP, solvent2 FP, fractions, temp, target."""
    n = len(records)
    fp_dim = 1024

    solute_fps = np.zeros((n, fp_dim), dtype=np.float32)
    solv1_fps = np.zeros((n, fp_dim), dtype=np.float32)
    solv2_fps = np.zeros((n, fp_dim), dtype=np.float32)
    context = np.zeros((n, 3), dtype=np.float32)  # frac1, frac2, temp
    targets = np.zeros(n, dtype=np.float32)

    for i, r in enumerate(records):
        solute_fps[i] = morgan_fp(r.solute_smiles)
        solv1_fps[i] = morgan_fp(r.solvent1_smiles)
        solv2_fps[i] = morgan_fp(r.solvent2_smiles)
        context[i] = [r.solvent1_fraction, r.solvent2_fraction, r.temperature_k / 400.0]
        targets[i] = r.log_solubility

    return (
        torch.tensor(solute_fps),
        torch.tensor(solv1_fps),
        torch.tensor(solv2_fps),
        torch.tensor(context),
        torch.tensor(targets),
    )


# ---------------------------------------------------------------------------
# Model
# ---------------------------------------------------------------------------

class SoluteAttentionModel(nn.Module):
    """
    Asymmetric cross-attention for mixture solubility.

    Architecture:
      1. Encode solute, solvent1, solvent2 through separate MLPs into
         a shared embedding space.
      2. Compute attention weights: how much does the solute attend to
         each solvent? Weighted by solvent fraction.
      3. The attended solvent representation captures the effective
         solvation environment as seen by the solute.
      4. Concatenate solute embedding + attended environment + context,
         predict log-solubility.

    The key asymmetry: the solute queries, the solvents are keys/values.
    This respects the physical asymmetry of dissolution.
    """

    def __init__(self, fp_dim: int = 1024, embed_dim: int = 128, n_heads: int = 4):
        super().__init__()

        # Component encoders (separate because solute and solvent play different roles)
        self.solute_encoder = nn.Sequential(
            nn.Linear(fp_dim, 256),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(256, embed_dim),
        )
        self.solvent_encoder = nn.Sequential(
            nn.Linear(fp_dim, 256),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(256, embed_dim),
        )

        # Cross-attention: solute attends to solvents
        self.cross_attention = nn.MultiheadAttention(
            embed_dim=embed_dim,
            num_heads=n_heads,
            batch_first=True,
        )

        # Pairwise interaction: explicit solute-solvent interaction
        self.interaction_net = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
        )

        # Prediction head
        self.predictor = nn.Sequential(
            nn.Linear(embed_dim * 3 + 3, 128),  # solute + attended + interaction + context
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1),
        )

    def forward(self, solute_fp, solv1_fp, solv2_fp, context):
        # Encode
        solute_emb = self.solute_encoder(solute_fp)  # (B, embed_dim)
        solv1_emb = self.solvent_encoder(solv1_fp)   # (B, embed_dim)
        solv2_emb = self.solvent_encoder(solv2_fp)   # (B, embed_dim)

        # Stack solvents as key/value sequence: (B, 2, embed_dim)
        solvent_seq = torch.stack([solv1_emb, solv2_emb], dim=1)

        # Solute as query: (B, 1, embed_dim)
        solute_query = solute_emb.unsqueeze(1)

        # Cross-attention: solute attends to solvents
        attended, attn_weights = self.cross_attention(
            solute_query, solvent_seq, solvent_seq
        )
        attended = attended.squeeze(1)  # (B, embed_dim)

        # Fraction-weighted solvent mixture embedding
        frac1 = context[:, 0:1]  # (B, 1)
        frac2 = context[:, 1:2]
        mix_emb = solv1_emb * frac1 + solv2_emb * frac2

        # Explicit solute-mixture interaction
        interaction = self.interaction_net(
            torch.cat([solute_emb, mix_emb], dim=-1)
        )

        # Predict
        combined = torch.cat([solute_emb, attended, interaction, context], dim=-1)
        return self.predictor(combined).squeeze(-1)


# ---------------------------------------------------------------------------
# Training
# ---------------------------------------------------------------------------

def train_model(
    model, train_loader, val_data, epochs=50, lr=1e-3, device="cpu",
):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, patience=5, factor=0.5
    )
    criterion = nn.MSELoss()

    val_solute, val_s1, val_s2, val_ctx, val_y = [t.to(device) for t in val_data]
    best_val_loss = float("inf")
    best_state = None
    patience_counter = 0

    for epoch in range(epochs):
        model.train()
        train_loss = 0
        n_batches = 0

        for batch in train_loader:
            solute, s1, s2, ctx, y = [t.to(device) for t in batch]
            optimizer.zero_grad()
            pred = model(solute, s1, s2, ctx)
            loss = criterion(pred, y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            train_loss += loss.item()
            n_batches += 1

        # Validation
        model.eval()
        with torch.no_grad():
            val_pred = model(val_solute, val_s1, val_s2, val_ctx)
            val_loss = criterion(val_pred, val_y).item()

        scheduler.step(val_loss)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            patience_counter = 0
        else:
            patience_counter += 1

        if (epoch + 1) % 10 == 0 or epoch == 0:
            print(f"    Epoch {epoch+1:>3}: train={train_loss/n_batches:.4f} "
                  f"val={val_loss:.4f} lr={optimizer.param_groups[0]['lr']:.1e}")

        if patience_counter >= 10:
            print(f"    Early stopping at epoch {epoch+1}")
            break

    if best_state:
        model.load_state_dict(best_state)
    return model


def evaluate_model(model, test_data, device="cpu"):
    model.eval()
    solute, s1, s2, ctx, y = [t.to(device) for t in test_data]
    with torch.no_grad():
        pred = model(solute, s1, s2, ctx)
    pred_np = pred.cpu().numpy()
    y_np = y.cpu().numpy()
    return {
        "mae": mean_absolute_error(y_np, pred_np),
        "r2": r2_score(y_np, pred_np),
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run():
    quick = "--quick" in sys.argv
    max_records = 15000 if quick else None
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Device: {device}")

    print("Loading MixtureSolDB...", flush=True)
    ds = MixtureSolubility(binary_only=True, max_records=max_records)
    print(ds)
    print()

    # Precompute fingerprints
    all_smiles = set()
    for r in ds.records:
        all_smiles.update([r.solute_smiles, r.solvent1_smiles, r.solvent2_smiles])

    print(f"Computing Morgan fingerprints for {len(all_smiles)} molecules...",
          end=" ", flush=True)
    t0 = time.time()
    for smi in all_smiles:
        morgan_fp(smi)
    print(f"({time.time()-t0:.1f}s)")
    print()

    # === Random split ===
    print("=" * 70)
    print("  Random Split")
    print("=" * 70)

    train, val, test = ds.split_random(test_size=0.1, val_size=0.1, seed=42)
    print(f"  Train: {len(train)}  Val: {len(val)}  Test: {len(test)}")

    train_tensors = build_tensors(train)
    val_tensors = build_tensors(val)
    test_tensors = build_tensors(test)

    train_dataset = TensorDataset(*train_tensors)
    train_loader = DataLoader(train_dataset, batch_size=512, shuffle=True)

    model = SoluteAttentionModel(fp_dim=1024, embed_dim=128, n_heads=4).to(device)
    param_count = sum(p.numel() for p in model.parameters())
    print(f"  Model parameters: {param_count:,}")
    print()

    print("  Training...")
    model = train_model(model, train_loader, val_tensors, epochs=80, device=device)

    res_random = evaluate_model(model, test_tensors, device=device)
    print(f"\n  Random split:  MAE={res_random['mae']:.4f}  R2={res_random['r2']:.4f}")
    print()

    # === Leave-solutes-out ===
    print("=" * 70)
    print("  Leave-Solutes-Out")
    print("=" * 70)

    n_hold = max(10, ds.unique_solutes // 10)
    train_lso, test_lso = ds.split_leave_solutes_out(n_held_out=n_hold, seed=42)
    print(f"  Train: {len(train_lso)}  Test: {len(test_lso)} ({n_hold} solutes held out)")

    # Use 10% of training as validation
    val_size = len(train_lso) // 10
    val_lso = train_lso[:val_size]
    train_lso_actual = train_lso[val_size:]

    train_tensors_l = build_tensors(train_lso_actual)
    val_tensors_l = build_tensors(val_lso)
    test_tensors_l = build_tensors(test_lso)

    train_dataset_l = TensorDataset(*train_tensors_l)
    train_loader_l = DataLoader(train_dataset_l, batch_size=512, shuffle=True)

    model_lso = SoluteAttentionModel(fp_dim=1024, embed_dim=128, n_heads=4).to(device)

    print("  Training...")
    model_lso = train_model(
        model_lso, train_loader_l, val_tensors_l, epochs=80, device=device
    )

    res_lso = evaluate_model(model_lso, test_tensors_l, device=device)
    print(f"\n  Leave-solutes-out:  MAE={res_lso['mae']:.4f}  R2={res_lso['r2']:.4f}")
    print()

    # === Summary ===
    print("=" * 70)
    print("  RESULTS")
    print("=" * 70)
    print(f"  {'Model':<40} {'Random R2':>12} {'LSO R2':>12}")
    print("  " + "-" * 64)
    print(f"  {'XGB + 5 PubChem descriptors (baseline)':<40} {'0.9137':>12} {'0.5187':>12}")
    print(f"  {'XGB + 31 RDKit descriptors':<40} {'0.9418':>12} {'0.4911':>12}")
    print(f"  {'XGB + Morgan FP (6147)':<40} {'0.8888':>12} {'0.3672':>12}")
    print(f"  {'XGB + Descriptors + Morgan (6178)':<40} {'0.9238':>12} {'0.5112':>12}")
    print(f"  {'Attention model (this run)':<40} {res_random['r2']:>12.4f} {res_lso['r2']:>12.4f}")
    print("=" * 70)
    print()
    print(f"  Baseline LSO ceiling: ~0.52")
    print(f"  Attention model LSO:  {res_lso['r2']:.4f}")
    if res_lso["r2"] > 0.55:
        print(f"  Improvement: +{res_lso['r2'] - 0.52:.4f} over baseline")
    else:
        print(f"  No meaningful improvement over baseline")


if __name__ == "__main__":
    run()
