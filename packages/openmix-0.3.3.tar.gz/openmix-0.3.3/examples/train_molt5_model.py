#!/usr/bin/env python3
"""
MolT5 pre-trained embeddings for mixture solubility prediction.

Uses the MolT5-small molecular language model to encode each component
into a 512-dim embedding, then predicts mixture solubility.

This establishes the ceiling for representation-based approaches.
If MolT5 embeddings significantly beat descriptors on leave-solutes-out,
the gap is in molecular representation. If not, the gap is elsewhere.

Usage:
    python examples/train_molt5_model.py
    python examples/train_molt5_model.py --quick
"""

from __future__ import annotations

import sys
import time
import numpy as np

from sklearn.metrics import mean_absolute_error, r2_score
from xgboost import XGBRegressor

from openmix.benchmarks.mixture_solubility import MixtureSolubility, MixtureSolRecord

import torch
from transformers import AutoTokenizer, AutoModel


# ---------------------------------------------------------------------------
# MolT5 embedding computation
# ---------------------------------------------------------------------------

_tokenizer = None
_model = None
_embed_cache: dict[str, np.ndarray] = {}


def _load_molt5():
    global _tokenizer, _model
    if _tokenizer is None:
        print("  Loading MolT5-small...", end=" ", flush=True)
        _tokenizer = AutoTokenizer.from_pretrained(
            "laituan245/molt5-small", model_max_length=512
        )
        _model = AutoModel.from_pretrained("laituan245/molt5-small")
        _model.eval()
        print("done")


def molt5_embedding(smiles: str) -> np.ndarray:
    """Get 512-dim MolT5 embedding for a SMILES string."""
    if smiles in _embed_cache:
        return _embed_cache[smiles]

    _load_molt5()
    inputs = _tokenizer(smiles, return_tensors="pt", padding=True, truncation=True)
    with torch.no_grad():
        outputs = _model.encoder(**inputs)
        emb = outputs.last_hidden_state.mean(dim=1).squeeze(0).numpy()

    _embed_cache[smiles] = emb.astype(np.float32)
    return _embed_cache[smiles]


def batch_embed(smiles_list: list[str], batch_size: int = 32) -> None:
    """Pre-compute embeddings for a list of SMILES."""
    _load_molt5()
    uncached = [s for s in smiles_list if s not in _embed_cache]
    if not uncached:
        return

    for i in range(0, len(uncached), batch_size):
        batch = uncached[i:i + batch_size]
        inputs = _tokenizer(batch, return_tensors="pt", padding=True, truncation=True)
        with torch.no_grad():
            outputs = _model.encoder(**inputs)
            embs = outputs.last_hidden_state.mean(dim=1).numpy()

        for smi, emb in zip(batch, embs):
            _embed_cache[smi] = emb.astype(np.float32)

        if (i // batch_size) % 10 == 0:
            print(f"    {i + len(batch)}/{len(uncached)}", flush=True)


# ---------------------------------------------------------------------------
# Feature builders
# ---------------------------------------------------------------------------

def molt5_features(record: MixtureSolRecord) -> np.ndarray:
    """MolT5 embeddings for all three components + composition."""
    solute_emb = molt5_embedding(record.solute_smiles)
    solv1_emb = molt5_embedding(record.solvent1_smiles)
    solv2_emb = molt5_embedding(record.solvent2_smiles)

    f1, f2 = record.solvent1_fraction, record.solvent2_fraction

    # Weighted mixture embedding
    mix_emb = solv1_emb * f1 + solv2_emb * f2

    # Interaction: element-wise product of solute and mixture
    interact_emb = solute_emb * mix_emb

    ctx = np.array([f1, f2, record.temperature_k / 400.0], dtype=np.float32)

    return np.concatenate([solute_emb, mix_emb, interact_emb, ctx])


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run():
    quick = "--quick" in sys.argv
    max_records = 15000 if quick else None

    print("Loading MixtureSolDB...")
    ds = MixtureSolubility(binary_only=True, max_records=max_records)
    print(ds)
    print()

    # Precompute all embeddings
    all_smiles = list(set(
        s for r in ds.records
        for s in [r.solute_smiles, r.solvent1_smiles, r.solvent2_smiles]
    ))
    print(f"Computing MolT5 embeddings for {len(all_smiles)} molecules...")
    t0 = time.time()
    batch_embed(all_smiles)
    print(f"  Done ({time.time()-t0:.1f}s)")
    print()

    # Splits
    train_r, val_r, test_r = ds.split_random(test_size=0.1, val_size=0.1, seed=42)
    n_hold = max(10, ds.unique_solutes // 10)
    train_l, test_l = ds.split_leave_solutes_out(n_held_out=n_hold, seed=42)

    print(f"Random: train={len(train_r)} test={len(test_r)}")
    print(f"LSO: train={len(train_l)} test={len(test_l)} ({n_hold} held out)")
    print()

    # Build features
    print("Building MolT5 features...", end=" ", flush=True)
    t0 = time.time()
    X_tr = np.array([molt5_features(r) for r in train_r], dtype=np.float32)
    X_te = np.array([molt5_features(r) for r in test_r], dtype=np.float32)
    y_tr = np.array([r.log_solubility for r in train_r])
    y_te = np.array([r.log_solubility for r in test_r])

    X_tl = np.array([molt5_features(r) for r in train_l], dtype=np.float32)
    X_el = np.array([molt5_features(r) for r in test_l], dtype=np.float32)
    y_tl = np.array([r.log_solubility for r in train_l])
    y_el = np.array([r.log_solubility for r in test_l])
    print(f"({time.time()-t0:.1f}s, shape={X_tr.shape})")
    print()

    # XGBoost on MolT5 features
    print("Training XGBoost on MolT5 features...")
    print("  Random split...", end=" ", flush=True)
    model_r = XGBRegressor(n_estimators=300, max_depth=6, learning_rate=0.1,
                           random_state=42, tree_method="hist")
    model_r.fit(X_tr, y_tr)
    pred_r = model_r.predict(X_te)
    r2_rand = r2_score(y_te, pred_r)
    mae_rand = mean_absolute_error(y_te, pred_r)
    print(f"R2={r2_rand:.4f}  MAE={mae_rand:.4f}")

    print("  LSO split...", end=" ", flush=True)
    model_l = XGBRegressor(n_estimators=300, max_depth=6, learning_rate=0.1,
                           random_state=42, tree_method="hist")
    model_l.fit(X_tl, y_tl)
    pred_l = model_l.predict(X_el)
    r2_lso = r2_score(y_el, pred_l)
    mae_lso = mean_absolute_error(y_el, pred_l)
    print(f"R2={r2_lso:.4f}  MAE={mae_lso:.4f}")
    print()

    # Summary
    print("=" * 70)
    print(f"  {'Model':<40} {'Random R2':>12} {'LSO R2':>12}")
    print("  " + "-" * 64)
    print(f"  {'XGB + 5 PubChem descriptors':<40} {'0.914':>12} {'0.519':>12}")
    print(f"  {'XGB + 31 RDKit descriptors':<40} {'0.942':>12} {'0.491':>12}")
    print(f"  {'XGB + Morgan FP (6147)':<40} {'0.889':>12} {'0.367':>12}")
    print(f"  {'XGB + MolT5 embeddings ({X_tr.shape[1]})':<40} {r2_rand:>12.4f} {r2_lso:>12.4f}")
    print("=" * 70)
    print()

    if r2_lso > 0.55:
        print(f"  MolT5 breaks the ceiling: {r2_lso:.4f} vs 0.52 baseline")
        print(f"  The gap was in molecular representation.")
    elif r2_lso > 0.50:
        print(f"  MolT5 matches the baseline: ~{r2_lso:.2f}")
        print(f"  Pre-trained representations don't help much here.")
    else:
        print(f"  MolT5 underperforms: {r2_lso:.4f} vs 0.52 baseline")
        print(f"  The bottleneck is not molecular representation.")


if __name__ == "__main__":
    run()
