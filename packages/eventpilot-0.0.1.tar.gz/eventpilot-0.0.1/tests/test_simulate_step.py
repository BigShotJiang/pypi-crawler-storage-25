"""Tests for EventPilot Python SDK — TestEnv.simulate_step."""
import pytest

from eventpilot import handler, step, StepResult, StepError
from eventpilot import TestEnv, new_state


def make_handler():
    @handler("h")
    class H:
        async def run(self, state):
            await self.next_step(self.step0)
            await self.next_step(self.step1)

        @step("step0")
        async def step0(self, state):
            return StepResult(data={"s0": True})

        @step("step1")
        async def step1(self, state):
            return StepResult(data={"s1": True})

        @step("multiply")
        async def multiply(self, state):
            x = state.get_int("x")
            return StepResult(data={"result": x * 3})

        @step("enrich")
        async def enrich(self, state):
            existing = state.get_string("existing_key")
            return StepResult(data={"enriched": f"got:{existing}"})

        @step("bad-step")
        async def bad_step(self, state):
            raise StepError("something went wrong", retryable=False)

        @step("read-payload")
        async def read_payload(self, state):
            p = state.parse_payload()
            return StepResult(data={"order_id": p["order_id"]})

        @step("void-step")
        async def void_step(self, state):
            pass  # returns None

    return H


async def test_simulate_step_runs_in_isolation():
    H = make_handler()
    env = TestEnv()
    env.register(H)

    state = new_state("h").with_context(x=7).build()
    sr = await env.simulate_step("h", "multiply", state)

    assert sr.data["result"] == 21


async def test_simulate_step_does_not_affect_other_steps():
    ran = {"step0": False, "step1": False}

    @handler("h2")
    class H2:
        async def run(self, state):
            await self.next_step(self.step0)
            await self.next_step(self.step1)

        @step("step0")
        async def step0(self, state):
            ran["step0"] = True
            return StepResult(data={"s0": True})

        @step("step1")
        async def step1(self, state):
            ran["step1"] = True
            return StepResult(data={"s1": True})

    env = TestEnv()
    env.register(H2)

    state = new_state("h2").build()
    await env.simulate_step("h2", "step1", state)

    assert ran["step0"] is False
    assert ran["step1"] is True


async def test_simulate_step_with_prior_context():
    H = make_handler()
    env = TestEnv()
    env.register(H)

    state = new_state("h").with_context(existing_key="hello").build()
    sr = await env.simulate_step("h", "enrich", state)
    assert sr.data["enriched"] == "got:hello"


async def test_simulate_step_raises_step_error():
    H = make_handler()
    env = TestEnv()
    env.register(H)

    state = new_state("h").build()
    with pytest.raises(StepError, match="something went wrong"):
        await env.simulate_step("h", "bad-step", state)


async def test_simulate_step_payload_available():
    H = make_handler()
    env = TestEnv()
    env.register(H)

    state = new_state("h").with_payload({"order_id": "ord_999"}).build()
    sr = await env.simulate_step("h", "read-payload", state)
    assert sr.data["order_id"] == "ord_999"


async def test_simulate_step_missing_handler_raises():
    env = TestEnv()
    state = new_state("missing").build()
    with pytest.raises(KeyError):
        await env.simulate_step("missing", "step", state)


async def test_simulate_step_missing_step_raises():
    H = make_handler()
    env = TestEnv()
    env.register(H)

    state = new_state("h").build()
    with pytest.raises(KeyError):
        await env.simulate_step("h", "nonexistent-step", state)


async def test_simulate_step_returns_none_as_empty_step_result():
    """Steps returning None get wrapped as StepResult()."""
    H = make_handler()
    env = TestEnv()
    env.register(H)

    state = new_state("h").build()
    result = await env.simulate_step("h", "void-step", state)
    assert isinstance(result, StepResult)
    assert result.data == {}
