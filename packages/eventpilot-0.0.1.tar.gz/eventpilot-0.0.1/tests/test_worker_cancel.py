"""Tests for per-workflow cancellation in the Python SDK Worker."""
import asyncio
from unittest.mock import MagicMock

import pytest

from eventpilot.worker import Worker


class TestWorkerCancellation:
    """Unit tests for Worker cancellation tracking."""

    def _make_worker(self) -> Worker:
        return Worker(addr="localhost:50051")

    def test_mark_workflow_cancelled_records_reason(self):
        w = self._make_worker()
        w._mark_workflow_cancelled("wf-1", "user requested")
        assert w._is_workflow_cancelled("wf-1") == "user requested"

    def test_is_workflow_cancelled_returns_none_for_unknown(self):
        w = self._make_worker()
        assert w._is_workflow_cancelled("wf-unknown") is None

    def test_clear_workflow_cancellation(self):
        w = self._make_worker()
        w._mark_workflow_cancelled("wf-1", "reason")
        w._clear_workflow_cancellation("wf-1")
        assert w._is_workflow_cancelled("wf-1") is None
        assert "wf-1" not in w._workflow_tasks

    @pytest.mark.asyncio
    async def test_mark_cancelled_cancels_running_task(self):
        w = self._make_worker()
        cancelled = asyncio.Event()

        async def long_running():
            try:
                await asyncio.sleep(3600)
            except asyncio.CancelledError:
                cancelled.set()
                raise

        task = asyncio.create_task(long_running())
        w._workflow_tasks["wf-1"] = task

        w._mark_workflow_cancelled("wf-1", "orchestrator cancel")

        # Give the event loop a tick so cancellation propagates
        await asyncio.sleep(0)
        assert cancelled.is_set()
        assert task.cancelled()

    @pytest.mark.asyncio
    async def test_mark_cancelled_no_task_is_safe(self):
        """Cancelling a workflow with no running task should not raise."""
        w = self._make_worker()
        w._mark_workflow_cancelled("wf-no-task", "reason")
        assert w._is_workflow_cancelled("wf-no-task") == "reason"

    def test_clear_nonexistent_is_safe(self):
        """Clearing cancellation for a workflow that was never tracked should not raise."""
        w = self._make_worker()
        w._clear_workflow_cancellation("wf-nonexistent")  # should not raise
