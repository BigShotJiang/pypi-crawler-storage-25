"""Tests for EventPilot Python SDK — WorkflowState accessor methods."""
import json
import pytest
from datetime import datetime

from eventpilot import WorkflowState, StepResult


def make_state(context=None, payload=None):
    """Build a minimal WorkflowState for testing."""
    return WorkflowState(
        workflow_id="test-wf",
        workflow_type="test_handler",
        handler_version="1.0.0",
        version=1,
        status="RUNNING",
        current_handler="test_handler",
        current_step=0,
        context=context or {},
        trigger_payload=payload or b"",
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )


# ── get_string ─────────────────────────────────────────────────────────────


def test_get_string_present():
    s = make_state({"name": "alice"})
    assert s.get_string("name") == "alice"


def test_get_string_missing_returns_default():
    s = make_state()
    assert s.get_string("missing") == ""
    assert s.get_string("missing", default="fallback") == "fallback"


def test_get_string_wrong_type_returns_default():
    s = make_state({"n": 42})
    assert s.get_string("n") == ""


# ── get_int ────────────────────────────────────────────────────────────────


def test_get_int_native_int():
    s = make_state({"n": 7})
    assert s.get_int("n") == 7


def test_get_int_float_coercion():
    # JSON numbers often unmarshal as float
    s = make_state({"n": 42.0})
    assert s.get_int("n") == 42


def test_get_int_missing_returns_default():
    s = make_state()
    assert s.get_int("missing") == 0
    assert s.get_int("missing", default=99) == 99


def test_get_int_bool_not_coerced():
    # True is a bool, not an int (even though bool is a subclass of int in Python)
    s = make_state({"flag": True})
    assert s.get_int("flag") == 0  # bool is excluded


def test_get_int_string_returns_default():
    s = make_state({"n": "not-a-number"})
    assert s.get_int("n") == 0


# ── get_float ──────────────────────────────────────────────────────────────


def test_get_float_native_float():
    s = make_state({"pi": 3.14})
    assert abs(s.get_float("pi") - 3.14) < 1e-10


def test_get_float_int_coercion():
    s = make_state({"n": 5})
    assert s.get_float("n") == 5.0


def test_get_float_missing_returns_default():
    s = make_state()
    assert s.get_float("missing") == 0.0
    assert s.get_float("missing", default=1.5) == 1.5


def test_get_float_bool_not_coerced():
    s = make_state({"flag": True})
    assert s.get_float("flag") == 0.0


# ── get_bool ───────────────────────────────────────────────────────────────


def test_get_bool_true():
    s = make_state({"flag": True})
    assert s.get_bool("flag") is True


def test_get_bool_false():
    s = make_state({"flag": False})
    assert s.get_bool("flag") is False


def test_get_bool_missing_returns_default():
    s = make_state()
    assert s.get_bool("missing") is False
    assert s.get_bool("missing", default=True) is True


def test_get_bool_non_bool_returns_default():
    s = make_state({"n": 1})
    assert s.get_bool("n") is False  # 1 is not a bool in our strict check


# ── get_string_list ────────────────────────────────────────────────────────


def test_get_string_list_native_list():
    s = make_state({"tags": ["a", "b", "c"]})
    result = s.get_string_list("tags")
    assert result == ["a", "b", "c"]


def test_get_string_list_missing_returns_none():
    s = make_state()
    assert s.get_string_list("missing") is None


def test_get_string_list_non_list_returns_none():
    s = make_state({"n": "not-a-list"})
    assert s.get_string_list("n") is None


def test_get_string_list_mixed_types_returns_none():
    s = make_state({"tags": ["a", 1, "b"]})
    # The implementation checks if all items are strings
    result = s.get_string_list("tags")
    assert result is None


# ── parse_payload & get_payload_map ────────────────────────────────────────


def test_parse_payload_returns_dict():
    s = make_state(payload=json.dumps({"order_id": "ord_1", "amount": 99}).encode())
    p = s.parse_payload()
    assert p["order_id"] == "ord_1"
    assert p["amount"] == 99


def test_parse_payload_empty_raises():
    s = make_state()
    with pytest.raises(ValueError, match="empty"):
        s.parse_payload()


def test_get_payload_map_valid():
    s = make_state(payload=b'{"key": "value"}')
    m = s.get_payload_map()
    assert m["key"] == "value"


def test_get_payload_map_non_object_raises():
    s = make_state(payload=b'["a", "b"]')
    with pytest.raises(ValueError, match="not a JSON object"):
        s.get_payload_map()


def test_parse_payload_into_dataclass():
    from dataclasses import dataclass

    @dataclass
    class Order:
        order_id: str
        amount: float

    s = make_state(payload=json.dumps({"order_id": "ord_1", "amount": 50.0}).encode())
    order = s.parse_payload(target_type=Order)
    assert isinstance(order, Order)
    assert order.order_id == "ord_1"
    assert order.amount == 50.0


# ── context helpers interaction ────────────────────────────────────────────


def test_context_modifications_are_independent():
    """Modifying a copy of context should not affect the original state."""
    s = make_state({"x": 1})
    ctx_copy = dict(s.context)
    ctx_copy["x"] = 999
    assert s.context["x"] == 1
