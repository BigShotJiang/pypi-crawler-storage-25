"""Tests for M2/M3 features: queries, signals, heartbeats, determinism, versioning, metrics."""
from __future__ import annotations

import asyncio
from typing import Any, Dict, List

import pytest

from eventpilot import (
    MetricsRecorder,
    StepResult,
    TestEnv,
    TestStatus,
    WorkflowState,
    handler,
    new_state,
    query,
    scheduled,
    signal,
    step,
)


# ---------------------------------------------------------------------------
# Query decorator
# ---------------------------------------------------------------------------


@handler("query-demo")
class QueryDemo:
    async def run(self, state: WorkflowState):
        await self.next_step(self.stage_one)

    @step("stage-one")
    async def stage_one(self, state: WorkflowState) -> StepResult:
        return StepResult(data={"stage": "one"})

    @query("get_stage")
    async def get_stage(self, state: WorkflowState) -> Dict[str, Any]:
        return {"stage": state.get_string("stage")}


async def test_query_registered():
    assert "get_stage" in QueryDemo._ep_handler_queries


async def test_query_env_invocation():
    env = TestEnv()
    env.register(QueryDemo)
    state = new_state("query-demo").with_context(stage="two").build()
    result = await env.query("query-demo", "get_stage", state)
    assert result == {"stage": "two"}


# ---------------------------------------------------------------------------
# Signal decorator — metadata registration
# ---------------------------------------------------------------------------


@handler("signal-demo")
class SignalDemo:
    async def run(self, state: WorkflowState):
        pass

    @signal("approval")
    async def on_approval(self, state, payload):
        state.context["approved"] = payload.get("ok", False)


async def test_signal_registered():
    assert "approval" in SignalDemo._ep_handler_signals


# ---------------------------------------------------------------------------
# Determinism helpers
# ---------------------------------------------------------------------------


@handler("determinism-demo")
class DeterminismDemo:
    async def run(self, state: WorkflowState):
        t = await self.now()
        r = await self.random()
        v = await self.side_effect("external-id", lambda: "id-abc")
        state.context["out"] = {"t": t, "r": r, "v": v}


async def test_determinism_memoizes_values():
    env = TestEnv()
    env.register(DeterminismDemo)
    r1 = await env.trigger("determinism-demo", {})
    assert r1.status == TestStatus.COMPLETED
    # Same run: values were captured in context under side_effect keys.
    assert "__ep_side_effect_now" in r1.context
    assert "__ep_side_effect_random" in r1.context
    assert r1.context["__ep_side_effect_external-id"] == "id-abc"


# ---------------------------------------------------------------------------
# Version patch
# ---------------------------------------------------------------------------


@handler("version-demo")
class VersionDemo:
    async def run(self, state: WorkflowState):
        v = await self.get_version("fraud-check", default=2)
        state.context["version"] = v


async def test_version_default_recorded():
    env = TestEnv()
    env.register(VersionDemo)
    r = await env.trigger("version-demo", {})
    assert r.status == TestStatus.COMPLETED
    assert r.context["__ep_version_fraud-check"] == 2


# ---------------------------------------------------------------------------
# Heartbeats
# ---------------------------------------------------------------------------


@handler("heartbeat-demo")
class HeartbeatDemo:
    async def run(self, state: WorkflowState):
        await self.next_step(self.long_step)

    @step("long-step")
    async def long_step(self, state: WorkflowState) -> StepResult:
        await self.heartbeat(progress={"pct": 50})
        await self.heartbeat(progress=b"raw-bytes")
        return StepResult(data={"done": True})


async def test_heartbeats_captured():
    env = TestEnv()
    env.register(HeartbeatDemo)
    r = await env.trigger("heartbeat-demo", {})
    assert r.status == TestStatus.COMPLETED
    hb = env.heartbeats
    assert len(hb) == 2
    assert hb[0]["progress"] == b'{"pct": 50}'
    assert hb[1]["progress"] == b"raw-bytes"


# ---------------------------------------------------------------------------
# @scheduled class decorator
# ---------------------------------------------------------------------------


@scheduled(cron="0 * * * *", name="hourly")
@handler("sched-demo")
class SchedDemo:
    async def run(self, state: WorkflowState):
        pass


async def test_scheduled_metadata_attached():
    entries = SchedDemo._ep_handler_schedules
    assert len(entries) == 1
    assert entries[0]["cron"] == "0 * * * *"
    assert entries[0]["name"] == "hourly"


def test_scheduled_rejects_empty():
    with pytest.raises(ValueError):
        @scheduled()
        @handler("bad-sched")
        class _X:
            async def run(self, state):
                pass


# ---------------------------------------------------------------------------
# MetricsRecorder
# ---------------------------------------------------------------------------


class _Recorder:
    def __init__(self) -> None:
        self.events: List[tuple] = []

    def record_step_started(self, handler, step, workflow_id):
        self.events.append(("started", handler, step))

    def record_step_completed(self, handler, step, workflow_id, duration_ms):
        self.events.append(("completed", handler, step))

    def record_step_failed(self, handler, step, workflow_id, error_code, retryable):
        self.events.append(("failed", handler, step, error_code, retryable))


@handler("metrics-demo")
class MetricsDemo:
    async def run(self, state: WorkflowState):
        await self.next_step(self.one)

    @step("one")
    async def one(self, state: WorkflowState) -> StepResult:
        return StepResult(data={"ok": True})


async def test_metrics_recorder_invoked():
    env = TestEnv()
    env.register(MetricsDemo)
    # Inject recorder manually since TestEnv doesn't accept it yet.
    recorder = _Recorder()

    async def run_with_recorder():
        handler_class = env._handler_classes["metrics-demo"]
        import json as _json
        from eventpilot.types import WorkflowState as _WS
        state = _WS(
            workflow_id="wf", workflow_type="metrics-demo", handler_version="t", version=1,
            status="RUNNING", current_handler="metrics-demo", current_step=0,
            trigger_payload=_json.dumps({}).encode(),
        )
        state._metrics_recorder = recorder
        state._checkpoint_fn = lambda *a, **kw: asyncio.sleep(0)
        instance = handler_class()
        instance._ep_state = state
        await instance.run(state)

    await run_with_recorder()
    kinds = [e[0] for e in recorder.events]
    assert "started" in kinds and "completed" in kinds


# ---------------------------------------------------------------------------
# Strict JSON serialization at checkpoint time
# ---------------------------------------------------------------------------


def test_strict_json_dumps():
    from eventpilot.worker import _json_dumps_strict

    assert _json_dumps_strict({"a": 1}, what="ctx") == '{"a": 1}'

    class NotJSON:
        pass

    with pytest.raises(TypeError):
        _json_dumps_strict(NotJSON(), what="ctx[x]")


# ---------------------------------------------------------------------------
# Checkpoint retry: verify retry helper semantics (mock stream)
# ---------------------------------------------------------------------------


def _fake_checkpoint(workflow_id="wf", step_name="s"):
    """Stand-in for a StepCheckpoint proto — the retry helper only reads
    ``workflow_id`` and ``step_name`` for logs, so a simple object suffices
    when the generated proto module isn't available in a test environment."""

    class _C:
        pass

    c = _C()
    c.workflow_id = workflow_id
    c.step_name = step_name
    c.step_index = 0
    return c


async def test_checkpoint_retry_succeeds_after_transient_failure(monkeypatch):
    from eventpilot import worker as worker_mod
    from eventpilot.worker import Worker

    # Bypass proto load — the helper only wraps the message, never inspects it.
    class _FakePb2:
        @staticmethod
        def WorkerMessage(**_kw):
            return None

    monkeypatch.setattr(worker_mod, "_protos", lambda: (_FakePb2, None))

    attempts = {"n": 0}

    class FlakyStream:
        async def write(self, msg):
            attempts["n"] += 1
            if attempts["n"] < 3:
                raise RuntimeError("simulated transient")

    w = Worker(addr="unused")
    ok = await w._send_checkpoint(FlakyStream(), _fake_checkpoint())
    assert ok is True
    assert attempts["n"] == 3


async def test_checkpoint_retry_exhausts_and_raises(monkeypatch):
    from eventpilot import worker as worker_mod
    from eventpilot.worker import CheckpointWriteError, Worker

    class _FakePb2:
        @staticmethod
        def WorkerMessage(**_kw):
            return None

    monkeypatch.setattr(worker_mod, "_protos", lambda: (_FakePb2, None))

    class DeadStream:
        async def write(self, msg):
            raise RuntimeError("down")

    w = Worker(addr="unused")
    with pytest.raises(CheckpointWriteError):
        await w._send_checkpoint(DeadStream(), _fake_checkpoint())
