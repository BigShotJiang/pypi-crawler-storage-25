"""Stage 4 Python SDK grouping / handler-execution tests (issue #23)."""
from __future__ import annotations

from datetime import datetime
from unittest.mock import AsyncMock, patch

import pytest

from eventpilot import WorkflowState


def _state(**overrides):
    """Build a minimal WorkflowState, letting overrides supply the IDs."""
    defaults = dict(
        workflow_id="grp-root",
        handler_execution_id="he-root",
        workflow_type="h",
        handler_version="1.0.0",
        version=1,
        status="RUNNING",
        current_handler="h",
        current_step=0,
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    defaults.update(overrides)
    return WorkflowState(**defaults)


def test_workflow_id_returns_grouping_id():
    """workflow_id holds the grouping id; handler_execution_id is the per-run PK."""
    s = _state(
        workflow_id="grp-root",
        handler_execution_id="he-child-2",
        parent_handler_execution_id="he-parent-1",
    )
    assert s.workflow_id == "grp-root"
    assert s.handler_execution_id == "he-child-2"
    assert s.parent_handler_execution_id == "he-parent-1"


def test_handler_execution_id_is_unique_across_same_group():
    """Two handler runs sharing a grouping id still have distinct PKs."""
    a = _state(workflow_id="grp-X", handler_execution_id="he-A")
    b = _state(workflow_id="grp-X", handler_execution_id="he-B")

    assert a.workflow_id == b.workflow_id
    assert a.handler_execution_id != b.handler_execution_id


def test_parent_workflow_id_is_parent_chain_and_independent_of_parent_handler():
    """parent_workflow_id is the parent chain's workflow_id (child-workflow tracing).

    It does NOT mirror parent_handler_execution_id — those are two independent
    pointers that happen to both be populated when emitting a child workflow.
    """
    s = _state(
        workflow_id="grp-child-chain",
        handler_execution_id="he-child-root",
        parent_handler_execution_id="he-emitter",
        parent_workflow_id="grp-parent-chain",
    )
    assert s.parent_workflow_id == "grp-parent-chain"
    assert s.parent_handler_execution_id == "he-emitter"

    # A state with a parent handler but no parent chain (inherited chain case)
    # has parent_workflow_id unset.
    s2 = _state(parent_handler_execution_id="he-parent-7")
    assert s2.parent_workflow_id == ""


def test_handler_execution_id_defaults_to_workflow_id_for_legacy_callers():
    """Tests that only supply workflow_id still get a usable PK (root case)."""
    # Omit handler_execution_id from kwargs — __post_init__ should back-fill.
    defaults = dict(
        workflow_id="only-wf-id",
        workflow_type="h",
        handler_version="1.0.0",
        version=1,
        status="RUNNING",
        current_handler="h",
        current_step=0,
        created_at=datetime.now(),
        updated_at=datetime.now(),
    )
    s = WorkflowState(**defaults)
    assert s.handler_execution_id == "only-wf-id"


@pytest.mark.asyncio
async def test_emit_stamps_grouping_and_parent_headers():
    """emit() stamps workflow_id + parent_handler_execution_id envelope headers."""
    s = _state(
        workflow_id="grp-X",
        handler_execution_id="he-emitter",
    )
    s._grpc_addr = "localhost:0"

    captured = {}

    class FakeStub:
        async def PublishEvent(self, req):
            captured["headers"] = dict(req.headers)
            captured["event_name"] = req.event_name

            class _Resp:
                workflow_id = "child-grp-id"

            return _Resp()

    class FakeChannel:
        async def close(self):
            pass

    with patch("eventpilot.types.load_eventpilot_protos") as load_protos, \
         patch("grpc.aio.insecure_channel", return_value=FakeChannel()) as _ch:
        fake_pb2 = type("pb2", (), {"PublishEventRequest": lambda **kw: _Req(**kw)})
        fake_pb2_grpc = type(
            "pb2_grpc",
            (),
            {"EventPilotServiceStub": lambda channel: FakeStub()},
        )
        load_protos.return_value = (fake_pb2, fake_pb2_grpc)

        result = await s.emit("some.event", {"ok": True})

    assert result == "child-grp-id"
    assert captured["event_name"] == "some.event"
    assert captured["headers"] == {
        "workflow_id": "grp-X",
        "parent_handler_execution_id": "he-emitter",
    }


class _Req:
    """Minimal stand-in for the proto PublishEventRequest used by emit()."""

    def __init__(self, *, event_name="", payload=b"", headers=None, **kwargs):
        self.event_name = event_name
        self.payload = payload
        self.headers = headers or {}
        for k, v in kwargs.items():
            setattr(self, k, v)


@pytest.mark.asyncio
async def test_emit_with_new_workflow_stamps_parent_chain_and_drops_workflow_id():
    """With new_workflow=True, emit() stamps parent_workflow_id (not workflow_id)
    so the orchestrator mints a fresh grouping id for the child chain."""
    s = _state(
        workflow_id="grp-parent",
        handler_execution_id="he-emitter",
    )
    s._grpc_addr = "localhost:0"

    captured = {}

    class FakeStub:
        async def PublishEvent(self, req):
            captured["headers"] = dict(req.headers)

            class _Resp:
                workflow_id = "new-child-grp"

            return _Resp()

    class FakeChannel:
        async def close(self):
            pass

    with patch("eventpilot.types.load_eventpilot_protos") as load_protos, \
         patch("grpc.aio.insecure_channel", return_value=FakeChannel()):
        fake_pb2 = type("pb2", (), {"PublishEventRequest": lambda **kw: _Req(**kw)})
        fake_pb2_grpc = type(
            "pb2_grpc",
            (),
            {"EventPilotServiceStub": lambda channel: FakeStub()},
        )
        load_protos.return_value = (fake_pb2, fake_pb2_grpc)

        await s.emit("some.event", {"ok": True}, new_workflow=True)

    assert captured["headers"] == {
        "parent_workflow_id": "grp-parent",
        "parent_handler_execution_id": "he-emitter",
    }


@pytest.mark.asyncio
async def test_emit_without_grpc_addr_raises():
    """Without a worker-injected gRPC address, emit() raises instead of silently succeeding."""
    s = _state()
    s._grpc_addr = ""
    with pytest.raises(RuntimeError, match="gRPC"):
        await s.emit("x", {})
