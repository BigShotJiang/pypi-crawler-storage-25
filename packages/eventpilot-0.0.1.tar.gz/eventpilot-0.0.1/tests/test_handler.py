"""Tests for EventPilot Python SDK — class-based handler workflow execution via TestEnv."""
import pytest

from eventpilot import handler, step, StepResult, StepError, Defer
from eventpilot import TestEnv, TestStatus, TriggerOptions


# ── Single & multi-step workflows ──────────────────────────────────────────


async def test_single_step_completes():
    @handler("single")
    class Single:
        async def run(self, state):
            await self.next_step(self.work)

        @step("work")
        async def work(self, state):
            return StepResult(data={"ok": True})

    env = TestEnv()
    env.register(Single)
    result = await env.trigger("single", {"x": 1})

    assert result.status == TestStatus.COMPLETED
    assert result.context["ok"] is True


async def test_multi_step_completes_in_order():
    order = []

    @handler("multi")
    class Multi:
        async def run(self, state):
            await self.next_step(self.step1)
            await self.next_step(self.step2)
            await self.next_step(self.step3)

        @step("step1")
        async def step1(self, state):
            order.append(1)
            return StepResult(data={"step1_done": True})

        @step("step2")
        async def step2(self, state):
            assert state.context.get("step1_done") is True
            order.append(2)
            return StepResult(data={"step2_done": True})

        @step("step3")
        async def step3(self, state):
            assert state.context.get("step2_done") is True
            order.append(3)
            return StepResult(data={"all_done": True})

    env = TestEnv()
    env.register(Multi)
    result = await env.trigger("multi", None)

    assert result.status == TestStatus.COMPLETED
    assert order == [1, 2, 3]
    assert result.context["all_done"] is True
    assert len(result.step_results) == 3


async def test_step_data_accumulated_in_context():
    @handler("accum")
    class Accum:
        async def run(self, state):
            await self.next_step(self.s1)
            await self.next_step(self.s2)

        @step("s1")
        async def s1(self, state):
            return StepResult(data={"a": 1})

        @step("s2")
        async def s2(self, state):
            return StepResult(data={"b": state.context["a"] + 1})

    env = TestEnv()
    env.register(Accum)
    result = await env.trigger("accum", None)

    assert result.status == TestStatus.COMPLETED
    assert result.context["a"] == 1
    assert result.context["b"] == 2


# ── Branching ─────────────────────────────────────────────────────────────


async def test_branching_vip_path():
    ran = {"vip": False, "regular": False}

    @handler("branch")
    class Branch:
        async def run(self, state):
            await self.next_step(self.validate)
            if state.get_bool("is_vip"):
                await self.next_step(self.vip_charge)
            else:
                await self.next_step(self.regular_charge)

        @step("validate")
        async def validate(self, state):
            payload = state.parse_payload()
            return StepResult(data={"is_vip": payload.get("vip", False)})

        @step("vip-charge")
        async def vip_charge(self, state):
            ran["vip"] = True
            return StepResult(data={"charge_id": "vip_1"})

        @step("regular-charge")
        async def regular_charge(self, state):
            ran["regular"] = True
            return StepResult(data={"charge_id": "reg_1"})

    env = TestEnv()
    env.register(Branch)

    result = await env.trigger("branch", {"vip": True})
    assert result.status == TestStatus.COMPLETED
    assert ran["vip"] is True
    assert ran["regular"] is False

    # Regular path
    ran["vip"] = False
    env2 = TestEnv()
    env2.register(Branch)
    result2 = await env2.trigger("branch", {"vip": False})
    assert result2.status == TestStatus.COMPLETED
    assert ran["vip"] is False
    assert ran["regular"] is True


# ── Payload ────────────────────────────────────────────────────────────────


async def test_payload_available_in_step():
    @handler("payload-handler")
    class PayloadHandler:
        async def run(self, state):
            await self.next_step(self.read_payload)

        @step("read-payload")
        async def read_payload(self, state):
            p = state.parse_payload()
            return StepResult(data={"order_id": p["order_id"]})

    env = TestEnv()
    env.register(PayloadHandler)
    result = await env.trigger("payload-handler", {"order_id": "ord_123"})

    assert result.status == TestStatus.COMPLETED
    assert result.context["order_id"] == "ord_123"


# ── Retry behaviour ────────────────────────────────────────────────────────


async def test_retryable_error_retries_and_succeeds():
    attempts = {"count": 0}

    @handler("retry-handler", max_retries=5)
    class RetryHandler:
        async def run(self, state):
            await self.next_step(self.flaky)

        @step("flaky")
        async def flaky(self, state):
            attempts["count"] += 1
            if attempts["count"] < 3:
                raise StepError("transient failure", retryable=True)
            return StepResult(data={"done": True})

    env = TestEnv()
    env.register(RetryHandler)
    result = await env.trigger("retry-handler", None)

    assert result.status == TestStatus.COMPLETED
    assert result.context["done"] is True
    assert len(result.retry_history) == 2


async def test_max_retries_fails_after_limit():
    @handler("always-fail", max_retries=3)
    class AlwaysFail:
        async def run(self, state):
            await self.next_step(self.fail_step)

        @step("fail-step")
        async def fail_step(self, state):
            raise StepError("always fails", retryable=True)

    env = TestEnv()
    env.register(AlwaysFail)
    result = await env.trigger("always-fail", None)

    assert result.status == TestStatus.FAILED
    assert len(result.retry_history) == 4  # initial + 3 retries


async def test_non_retryable_fails_immediately():
    @handler("non-retryable", max_retries=10)
    class NonRetryable:
        async def run(self, state):
            await self.next_step(self.fatal)

        @step("fatal")
        async def fatal(self, state):
            raise StepError("permanent failure", retryable=False)

    env = TestEnv()
    env.register(NonRetryable)
    result = await env.trigger("non-retryable", None)

    assert result.status == TestStatus.FAILED
    assert len(result.retry_history) == 1  # no retries


async def test_plain_exception_is_retryable():
    calls = {"n": 0}

    @handler("plain-exc", max_retries=3)
    class PlainExc:
        async def run(self, state):
            await self.next_step(self.step)

        @step("step")
        async def step(self, state):
            calls["n"] += 1
            if calls["n"] < 2:
                raise ValueError("plain error")
            return StepResult(data={"ok": True})

    env = TestEnv()
    env.register(PlainExc)
    result = await env.trigger("plain-exc", None)

    assert result.status == TestStatus.COMPLETED


async def test_retry_skips_completed_steps():
    """On retry, steps that already completed replay from cache — not re-executed."""
    ran = {"s1": 0, "s2": 0}

    @handler("retry-skip", max_retries=3)
    class RetrySkip:
        async def run(self, state):
            await self.next_step(self.s1)
            await self.next_step(self.s2)

        @step("s1")
        async def s1(self, state):
            ran["s1"] += 1
            return StepResult(data={"s1_done": True})

        @step("s2")
        async def s2(self, state):
            ran["s2"] += 1
            if ran["s2"] < 2:
                raise StepError("s2 transient", retryable=True)
            return StepResult(data={"s2_done": True})

    env = TestEnv()
    env.register(RetrySkip)
    result = await env.trigger("retry-skip", None)

    assert result.status == TestStatus.COMPLETED
    assert ran["s1"] == 1, "s1 should only run once (replayed on retry)"
    assert ran["s2"] == 2, "s2 should run twice (failed then succeeded)"


# ── Defer ──────────────────────────────────────────────────────────────────


async def test_defer_exception_returns_deferred():
    @handler("defer-handler")
    class DeferHandler:
        async def run(self, state):
            await self.next_step(self.defer_step)

        @step("defer-step")
        async def defer_step(self, state):
            raise Defer(delay_ms=5000)

    env = TestEnv()
    env.register(DeferHandler)
    result = await env.trigger("defer-handler", None)

    assert result.status == TestStatus.DEFERRED


async def test_defer_in_result_returns_deferred():
    @handler("defer-result")
    class DeferResult:
        async def run(self, state):
            await self.next_step(self.defer_via_result)

        @step("defer-via-result")
        async def defer_via_result(self, state):
            return StepResult(defer_ms=2000)

    env = TestEnv()
    env.register(DeferResult)
    result = await env.trigger("defer-result", None)

    assert result.status == TestStatus.DEFERRED


async def test_defer_ms_on_next_step_overrides():
    @handler("defer-override")
    class DeferOverride:
        async def run(self, state):
            await self.next_step(self.the_step, defer_ms=3000)

        @step("the-step")
        async def the_step(self, state):
            return StepResult(data={"ran": True})

    env = TestEnv()
    env.register(DeferOverride)
    result = await env.trigger("defer-override", None)

    assert result.status == TestStatus.DEFERRED


# ── TriggerOptions ─────────────────────────────────────────────────────────


async def test_initial_context_available_in_step():
    @handler("ctx-handler")
    class CtxHandler:
        async def run(self, state):
            await self.next_step(self.read_ctx)

        @step("read-ctx")
        async def read_ctx(self, state):
            val = state.get_string("seed_key")
            assert val == "seed_value"
            return StepResult(data={"read": True})

    env = TestEnv()
    env.register(CtxHandler)
    result = await env.trigger(
        "ctx-handler",
        None,
        TriggerOptions(initial_context={"seed_key": "seed_value"}),
    )

    assert result.status == TestStatus.COMPLETED


# ── Register guards ────────────────────────────────────────────────────────


def test_register_raises_on_non_handler():
    env = TestEnv()
    with pytest.raises(TypeError):
        env.register(object)


def test_register_raises_on_duplicate():
    @handler("dup")
    class Dup:
        async def run(self, state):
            pass

    env = TestEnv()
    env.register(Dup)
    with pytest.raises(ValueError, match="already registered"):
        env.register(Dup)


async def test_trigger_raises_on_unregistered():
    env = TestEnv()
    with pytest.raises(KeyError):
        await env.trigger("not_registered", None)


def test_handler_missing_run_raises():
    with pytest.raises(TypeError, match="run"):
        @handler("no-run")
        class NoRun:
            @step("some-step")
            async def some_step(self, state):
                return StepResult()


# ── Step results ───────────────────────────────────────────────────────────


async def test_step_results_contain_metadata():
    @handler("meta-handler")
    class MetaHandler:
        async def run(self, state):
            await self.next_step(self.work)

        @step("work")
        async def work(self, state):
            return StepResult(data={"x": 1}, result="step-result")

    env = TestEnv()
    env.register(MetaHandler)
    result = await env.trigger("meta-handler", None)

    assert result.status == TestStatus.COMPLETED
    sr = result.step_results.get(0)
    assert sr is not None
    assert sr.step_name == "work"
    assert sr.result == "step-result"
    assert sr.data == {"x": 1}


# Compensation was removed until the orchestrator dispatches it; see README.


async def test_next_step_by_string_name():
    """next_step can be called with a string step name."""

    @handler("string-ref")
    class StringRef:
        async def run(self, state):
            await self.next_step("do-work")

        @step("do-work")
        async def do_work(self, state):
            return StepResult(data={"done": True})

    env = TestEnv()
    env.register(StringRef)
    result = await env.trigger("string-ref", None)
    assert result.status == TestStatus.COMPLETED
    assert result.context["done"] is True


def test_event_handler_type_and_subscribes_to():
    """handler_type and subscribes_to are stored on the decorated class."""

    @handler(
        "inventory-sync",
        handler_type="event",
        subscribes_to=["order.created", "order.cancelled"],
    )
    class InventorySync:
        async def run(self, state):
            await self.next_step(self.sync)

        @step("sync")
        async def sync(self, state):
            return StepResult(data={"synced": True})

    assert InventorySync._ep_handler_type == "event"
    assert InventorySync._ep_handler_subscribes_to == ["order.created", "order.cancelled"]


def test_task_handler_defaults():
    """By default, handler_type is 'task' and subscribes_to is empty."""

    @handler("simple-task")
    class SimpleTask:
        async def run(self, state):
            pass

    assert SimpleTask._ep_handler_type == "task"
    assert SimpleTask._ep_handler_subscribes_to == []
