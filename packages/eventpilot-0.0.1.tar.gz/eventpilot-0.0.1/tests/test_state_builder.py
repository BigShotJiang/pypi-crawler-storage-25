"""Tests for EventPilot Python SDK — StateBuilder and new_state."""
import json
import pytest

from eventpilot import StateBuilder, new_state
from eventpilot import StepResult


# ── StateBuilder ───────────────────────────────────────────────────────────


def test_state_builder_defaults():
    state = StateBuilder("my_handler").build()
    assert state.workflow_id == "test-wf"
    assert state.current_handler == "my_handler"
    assert state.workflow_type == "my_handler"
    assert state.current_step == 0
    assert state.context == {}
    assert state.step_results == {}
    assert state.trigger_payload == b""


def test_state_builder_with_payload_dict():
    state = StateBuilder("h").with_payload({"order_id": "ord_1"}).build()
    assert state.trigger_payload != b""
    p = json.loads(state.trigger_payload)
    assert p["order_id"] == "ord_1"


def test_state_builder_with_payload_string():
    state = StateBuilder("h").with_payload("hello").build()
    assert json.loads(state.trigger_payload) == "hello"


def test_state_builder_with_context_kwargs():
    state = (
        StateBuilder("h")
        .with_context(name="alice", score=42, active=True)
        .build()
    )
    assert state.context["name"] == "alice"
    assert state.context["score"] == 42
    assert state.context["active"] is True


def test_state_builder_with_context_accumulates():
    state = (
        StateBuilder("h")
        .with_context(a=1)
        .with_context(b=2)
        .build()
    )
    assert state.context["a"] == 1
    assert state.context["b"] == 2


def test_state_builder_with_step():
    state = (
        StateBuilder("h")
        .with_step(0, name="step0", data={"result": "ok"})
        .build()
    )
    sr = state.step_results.get(0)
    assert sr is not None
    assert sr.data == {"result": "ok"}


def test_state_builder_with_step_default_data():
    state = StateBuilder("h").with_step(1).build()
    sr = state.step_results.get(1)
    assert sr is not None
    assert sr.data == {}


def test_state_builder_at_step():
    state = StateBuilder("h").at_step(5).build()
    assert state.current_step == 5


def test_state_builder_chaining():
    """Verify that all builder methods return self for fluent chaining."""
    state = (
        StateBuilder("h")
        .with_payload({"x": 1})
        .with_context(y=2)
        .with_step(0, data={"z": 3})
        .at_step(1)
        .build()
    )
    assert state.current_step == 1
    assert state.context["y"] == 2
    assert state.step_results[0].data["z"] == 3


# ── new_state helper ───────────────────────────────────────────────────────


def test_new_state_returns_state_builder():
    builder = new_state("my_handler")
    assert isinstance(builder, StateBuilder)


def test_new_state_sets_handler_name():
    state = new_state("test_handler").build()
    assert state.current_handler == "test_handler"


def test_new_state_full_chain():
    state = (
        new_state("order_handler")
        .with_payload({"order_id": "ord_123"})
        .with_context(user_id="usr_456")
        .at_step(2)
        .build()
    )
    p = json.loads(state.trigger_payload)
    assert p["order_id"] == "ord_123"
    assert state.context["user_id"] == "usr_456"
    assert state.current_step == 2
