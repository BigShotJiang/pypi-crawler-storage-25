"""Publisher for EventPilot v3 SDK."""
import json
import logging
from typing import Any, Optional

import grpc
from ._protos import load_eventpilot_protos

# Setup logger
logger = logging.getLogger("eventpilot.sdk.publisher")

_eventpilot_pb2 = None
_eventpilot_pb2_grpc = None


def _protos():
    global _eventpilot_pb2, _eventpilot_pb2_grpc
    if _eventpilot_pb2 is None or _eventpilot_pb2_grpc is None:
        _eventpilot_pb2, _eventpilot_pb2_grpc = load_eventpilot_protos()
    return _eventpilot_pb2, _eventpilot_pb2_grpc


class Publisher:
    """Publisher for publishing events to EventPilot."""

    def __init__(self, addr: str, *, http_addr: str = ""):
        self.addr = addr
        self.http_addr = http_addr
        self.channel: Optional[grpc.aio.Channel] = None
        self.stub = None

    async def connect(self):
        """Connect to EventPilot."""
        _, eventpilot_pb2_grpc = _protos()
        self.channel = grpc.aio.insecure_channel(self.addr)
        self.stub = eventpilot_pb2_grpc.EventPilotServiceStub(self.channel)

    async def close(self):
        """Close the connection."""
        if self.channel:
            await self.channel.close()

    async def publish_event(
        self,
        event_name: str,
        payload: bytes,
        workflow_id: str = "",
        delay_ms: int = 0,
        scheduled_at_ms: int = 0,
    ) -> str:
        """Publish an event to start a workflow.

        Args:
            delay_ms: Delay in milliseconds before dispatch (0 = immediate).
            scheduled_at_ms: Absolute UTC timestamp (ms) for dispatch.
                Takes precedence over delay_ms if both are set.
        """
        eventpilot_pb2, _ = _protos()
        if not self.stub:
            await self.connect()

        req = eventpilot_pb2.PublishEventRequest(
            event_name=event_name,
            payload=payload,
            workflow_id=workflow_id,
            delay_ms=delay_ms,
            scheduled_at_ms=scheduled_at_ms,
        )

        resp = await self.stub.PublishEvent(req)
        logger.info(f"Event published: workflow_id={resp.workflow_id}")
        return resp.workflow_id

    async def get_workflow(self, workflow_id: str):
        """Get the state of a workflow."""
        eventpilot_pb2, _ = _protos()
        if not self.stub:
            await self.connect()

        req = eventpilot_pb2.GetWorkflowRequest(workflow_id=workflow_id)
        resp = await self.stub.GetWorkflow(req)

        if not resp.state:
            raise ValueError(f"Workflow not found: {workflow_id}")

        return resp.state

    async def retry_dlq(self, dlq_entry_id: str) -> str:
        """Retry a failed workflow from the DLQ."""
        eventpilot_pb2, _ = _protos()
        if not self.stub:
            await self.connect()

        req = eventpilot_pb2.RetryDLQRequest(dlq_entry_id=dlq_entry_id)
        resp = await self.stub.RetryDLQ(req)

        logger.info(f"DLQ entry retried: workflow_id={resp.workflow_id}")
        return resp.workflow_id

    async def list_workflows(
        self,
        *,
        status: str = "",
        event_name: str = "",
        handler: str = "",
        handler_version: str = "",
        created_after: str = "",
        created_before: str = "",
        updated_after: str = "",
        updated_before: str = "",
        parent_workflow_id: str = "",
        workflow_id: str = "",
        workflow_id_prefix: str = "",
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]:
        """List workflows with optional filters.

        Requires ``http_addr`` to be set on the Publisher.

        Args:
            status: Filter by status (RUNNING, COMPLETED, FAILED, etc.).
            event_name: Filter by trigger event / workflow type name.
            handler: Filter by handler name.
            handler_version: Filter by handler version.
            created_after: Only workflows created after this time (RFC3339).
            created_before: Only workflows created before this time (RFC3339).
            updated_after: Only workflows updated after this time (RFC3339).
            updated_before: Only workflows updated before this time (RFC3339).
            parent_workflow_id: Filter by parent workflow ID.
            workflow_id: Filter by exact workflow ID.
            workflow_id_prefix: Filter by workflow ID prefix.
            limit: Maximum number of results (default 50).
            offset: Pagination offset (default 0).

        Returns:
            List of workflow summary dicts.
        """
        if not self.http_addr:
            raise ValueError(
                "list_workflows requires an HTTP address — pass http_addr to Publisher()"
            )
        import aiohttp

        params: dict[str, str] = {"limit": str(limit)}
        if offset:
            params["offset"] = str(offset)
        if status:
            params["status"] = status
        if event_name:
            params["event_name"] = event_name
        if handler:
            params["handler"] = handler
        if handler_version:
            params["handler_version"] = handler_version
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before
        if updated_after:
            params["updated_after"] = updated_after
        if updated_before:
            params["updated_before"] = updated_before
        if parent_workflow_id:
            params["parent_workflow_id"] = parent_workflow_id
        if workflow_id:
            params["workflow_id"] = workflow_id
        if workflow_id_prefix:
            params["workflow_id_prefix"] = workflow_id_prefix

        url = f"{self.http_addr}/workflows"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                if resp.status >= 400:
                    text = await resp.text()
                    raise RuntimeError(
                        f"Failed to list workflows: status={resp.status} body={text}"
                    )
                data = await resp.json()
                return data.get("workflows", [])

    async def send_signal(
        self,
        workflow_id: str,
        signal_name: str,
        payload: Any = None,
    ) -> None:
        """Send a named signal to a running workflow.

        If the workflow is already waiting for this signal it resumes immediately;
        otherwise the signal is buffered in the workflow's inbox.

        Requires ``http_addr`` to be set on the Publisher.
        """
        if not self.http_addr:
            raise ValueError(
                "send_signal requires an HTTP address — pass http_addr to Publisher()"
            )
        import aiohttp

        body = {"payload": payload or {}}
        url = f"{self.http_addr}/workflows/{workflow_id}/signals/{signal_name}"
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=body) as resp:
                if resp.status >= 400:
                    text = await resp.text()
                    raise RuntimeError(
                        f"Failed to send signal: status={resp.status} body={text}"
                    )
                logger.info(
                    f"Signal sent: workflow_id={workflow_id} signal={signal_name}"
                )

    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
