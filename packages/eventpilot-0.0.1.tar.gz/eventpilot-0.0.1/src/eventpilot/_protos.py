"""Helpers for loading generated EventPilot protobuf modules."""

from __future__ import annotations

import sys
from pathlib import Path


def load_eventpilot_protos():
    """Return ``(eventpilot_pb2, eventpilot_pb2_grpc)`` modules."""
    try:
        from eventpilot.v1 import eventpilot_pb2, eventpilot_pb2_grpc

        return eventpilot_pb2, eventpilot_pb2_grpc
    except ImportError:
        current_dir = Path(__file__).resolve().parent
        potential_paths = [
            current_dir.parent.parent.parent.parent.parent / "lib" / "protos" / "gen" / "python",
            Path("/app/lib/protos/gen/python"),
            current_dir.parent.parent / "lib" / "protos" / "gen" / "python",
        ]

        for path in potential_paths:
            if not path.exists():
                continue
            sys.path.append(str(path))
            try:
                from eventpilot.v1 import eventpilot_pb2, eventpilot_pb2_grpc

                return eventpilot_pb2, eventpilot_pb2_grpc
            except ImportError:
                continue

    raise ImportError("Could not find generated eventpilot protos.")
