"""Polling helper for EventPilot SDK."""
import time
from typing import Any, Callable, Coroutine, Dict, Optional, Tuple

from .types import StepError, StepResult, WorkflowState


# CheckFunc returns (data_dict, is_done). Raise an exception to fail immediately.
CheckFunc = Callable[[WorkflowState], Coroutine[Any, Any, Tuple[Dict[str, Any], bool]]]


def poll(
    interval_ms: int,
    timeout_ms: int,
    check: CheckFunc,
    prefix: str = "poll",
):
    """Returns a step function that polls until check returns done=True.

    Tracks {prefix}_started_at and {prefix}_count in workflow context automatically.
    Uses StepResult.defer_ms for the polling interval (new pattern).

    Args:
        interval_ms: Milliseconds between poll attempts.
        timeout_ms: Maximum milliseconds before timing out (0 = no timeout).
        check: Async function(state) -> (data_dict, is_done).
        prefix: Prefix for context keys. Defaults to "poll".
    """
    started_at_key = f"{prefix}_started_at"
    count_key = f"{prefix}_count"

    async def step_fn(state: WorkflowState) -> StepResult:
        poll_count = state.get_int(count_key, 0) + 1
        started_at = state.get_float(started_at_key, 0.0)
        if started_at == 0.0:
            started_at = time.time()

        # Check timeout
        if timeout_ms > 0:
            elapsed_ms = (time.time() - started_at) * 1000
            if elapsed_ms > timeout_ms:
                raise StepError(
                    f"polling timed out after {timeout_ms}ms",
                    retryable=False,
                )

        # Run check
        data, done = await check(state)

        # Build context data
        context_data = {
            started_at_key: started_at,
            count_key: poll_count,
        }
        if data:
            context_data.update(data)

        if not done:
            return StepResult(data=context_data, defer_ms=interval_ms)

        return StepResult(data=context_data)

    return step_fn
