"""HTTP app primitives for EventPilot handler execution."""

from __future__ import annotations

import hmac
import json
import math
from dataclasses import dataclass
from hashlib import sha256
from typing import Any, Dict, Mapping, MutableMapping, Optional

from .types import StepError, StepResult, WorkflowState, _DeferSignal, _StepFailed


@dataclass
class ExecutionResponse:
    status_code: int
    body: Dict[str, Any]


class EventPilotApp:
    """Handler registry and execution surface for HTTP push workers."""

    def __init__(self, signing_secret: str = "") -> None:
        self.signing_secret = signing_secret
        self._handlers: Dict[str, type] = {}

    def register(self, handler_class: type) -> None:
        if not getattr(handler_class, "_ep_is_handler", False):
            raise TypeError(
                f"{handler_class!r} is not a handler class. "
                "Decorate it with @handler(...) before registering."
            )
        self._handlers[handler_class._ep_handler_name] = handler_class

    def manifest(self) -> Dict[str, Any]:
        handlers = []
        for cls in self._handlers.values():
            handlers.append(
                {
                    "name": cls._ep_handler_name,
                    "type": getattr(cls, "_ep_handler_type", "task") or "task",
                    "subscribes_to": getattr(cls, "_ep_handler_subscribes_to", []) or [],
                    "max_retries": cls._ep_handler_max_retries,
                    "retry_backoff_ms": cls._ep_handler_retry_backoff_ms,
                    "steps": [getattr(s, "_ep_step_name", s.__name__) for s in cls._ep_handler_steps_meta],
                }
            )
        return {"sdk_version": "2.0", "handlers": handlers}

    async def handle(
        self,
        method: str,
        body: bytes = b"",
        headers: Optional[Mapping[str, str]] = None,
    ) -> ExecutionResponse:
        if method == "GET":
            return ExecutionResponse(status_code=200, body=self.manifest())
        if method != "POST":
            return ExecutionResponse(status_code=405, body={"error": "method not allowed"})

        if self.signing_secret:
            hdrs = headers or {}
            timestamp = hdrs.get("EP-Timestamp", "")
            signature = hdrs.get("EP-Signature", "")
            try:
                self._verify_signature(timestamp, signature, body)
            except ValueError as exc:
                return ExecutionResponse(status_code=401, body={"error": str(exc)})

        try:
            req = json.loads(body.decode("utf-8") if body else "{}")
        except json.JSONDecodeError:
            return ExecutionResponse(status_code=400, body={"error": "invalid JSON"})
        result = await self.execute(req)
        return ExecutionResponse(status_code=result["status_code"], body=result["body"])

    async def execute(self, request: MutableMapping[str, Any]) -> Dict[str, Any]:
        handler_name = str(request.get("handler_name", ""))
        handler_class = self._handlers.get(handler_name)
        if handler_class is None:
            return {"status_code": 404, "body": {"error": f"handler not found: {handler_name}"}}

        payload = request.get("trigger_payload")
        if isinstance(payload, str):
            trigger_payload = payload.encode("utf-8")
        elif isinstance(payload, bytes):
            trigger_payload = payload
        else:
            trigger_payload = json.dumps(payload or {}).encode("utf-8")

        state = WorkflowState(
            workflow_id=str(request.get("workflow_id", "")),
            workflow_type=handler_name,
            handler_version=str(request.get("handler_version", "")) or handler_class._ep_handler_version,
            version=int(request.get("version", 0) or 0),
            status=str(request.get("status", "RUNNING")),
            current_handler=handler_name,
            current_step=int(request.get("step_index", 0) or 0),
            context=dict(request.get("context", {}) or {}),
            retry_count=int(request.get("retry_count", 0) or 0),
            trigger_payload=trigger_payload,
        )

        state._next_step_index = int(request.get("step_index", 0) or 0)

        step_checkpoints: Dict[str, Any] = {}

        async def checkpoint_fn(step_index: int, step_name: str, result: StepResult):
            step_checkpoints["step_index"] = step_index
            step_checkpoints["step_name"] = step_name
            step_checkpoints["data"] = result.data or {}
            step_checkpoints["result"] = result.result
            step_checkpoints["side_effect_key"] = result.side_effect_key
            if result.defer_ms is not None:
                step_checkpoints["defer_seconds"] = max(1, math.ceil(result.defer_ms / 1000))

        state._checkpoint_fn = checkpoint_fn

        instance = handler_class()
        instance._ep_state = state

        try:
            await instance.run(state)
            return {
                "status_code": 200,
                "body": {
                    "context": state.context,
                    "step": step_checkpoints,
                },
            }
        except _DeferSignal as signal:
            defer_seconds = max(1, math.ceil((signal.result.defer_ms or 0) / 1000))
            return {
                "status_code": 206,
                "body": {
                    "defer_seconds": defer_seconds,
                    "context": state.context,
                },
            }
        except _StepFailed as failure:
            retryable = getattr(failure.error, "retryable", True)
            status_code = 500 if retryable else 400
            return {
                "status_code": status_code,
                "body": {
                    "error": str(failure.error),
                    "retryable": retryable,
                },
            }
        except StepError as err:
            status_code = 500 if err.retryable else 400
            return {
                "status_code": status_code,
                "body": {
                    "error": str(err),
                    "retryable": err.retryable,
                },
            }

    def _verify_signature(self, timestamp: str, signature: str, body: bytes) -> None:
        if not timestamp or not signature:
            raise ValueError("missing EP-Timestamp or EP-Signature")
        signed_payload = f"{timestamp}.".encode("utf-8") + body
        digest = hmac.new(self.signing_secret.encode("utf-8"), signed_payload, sha256).hexdigest()
        expected = f"sha256={digest}"
        if not hmac.compare_digest(expected, signature):
            raise ValueError("invalid signature")
