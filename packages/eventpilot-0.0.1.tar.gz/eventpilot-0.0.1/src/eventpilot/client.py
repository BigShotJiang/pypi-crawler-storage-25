"""Modern EventPilot API client over HTTP.

Exposes both a sync (``EventPilotClient``) and an async (``AsyncEventPilotClient``)
interface. Sync calls are safe to make from non-async code; async calls are
required from inside a running event loop to avoid blocking it.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode


class EventPilotAPIError(RuntimeError):
    """Raised for EventPilot API errors."""


# ---------------------------------------------------------------------------
# Async client (primary implementation)
# ---------------------------------------------------------------------------


@dataclass
class AsyncEventPilotClient:
    """Async client for EventPilot HTTP APIs.

    Uses aiohttp under the hood. Safe to call from async workers without
    blocking the event loop.
    """

    base_url: str
    api_key: str = ""
    timeout_seconds: float = 30.0

    async def publish_event(
        self,
        event_name: str,
        payload: Dict[str, Any],
        workflow_id: str = "",
        delay_ms: int = 0,
        scheduled_at_ms: int = 0,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"event_name": event_name, "payload": payload}
        if workflow_id:
            body["workflow_id"] = workflow_id
        if delay_ms > 0:
            body["delay_ms"] = delay_ms
        if scheduled_at_ms > 0:
            body["scheduled_at_ms"] = scheduled_at_ms
        return await self._post_json("/events", body)

    async def send(
        self,
        event_name: str,
        payload: Dict[str, Any],
        workflow_id: str = "",
        delay_ms: int = 0,
        scheduled_at_ms: int = 0,
    ) -> Dict[str, Any]:
        return await self.publish_event(
            event_name, payload,
            workflow_id=workflow_id,
            delay_ms=delay_ms,
            scheduled_at_ms=scheduled_at_ms,
        )

    async def dispatch(
        self,
        task_name: str,
        payload: Dict[str, Any],
        wait_for_result: bool = False,
        timeout_seconds: int = 30,
        workflow_id: str = "",
        delay_ms: int = 0,
        scheduled_at_ms: int = 0,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "task_name": task_name,
            "payload": payload,
            "wait_for_result": wait_for_result,
            "timeout_seconds": timeout_seconds,
        }
        if workflow_id:
            body["workflow_id"] = workflow_id
        if delay_ms > 0:
            body["delay_ms"] = delay_ms
        if scheduled_at_ms > 0:
            body["scheduled_at_ms"] = scheduled_at_ms
        return await self._post_json("/tasks", body)

    async def get_workflow(self, workflow_id: str) -> Dict[str, Any]:
        return await self._get_json(f"/workflows/{workflow_id}")

    async def list_workflows(
        self, status: str = "", limit: int = 50
    ) -> List[Dict[str, Any]]:
        query = {"limit": str(limit)}
        if status:
            query["status"] = status
        data = await self._get_json(f"/workflows?{urlencode(query)}")
        return list(data.get("workflows", []))

    async def cancel_workflow(self, workflow_id: str, reason: str = "") -> Dict[str, Any]:
        return await self._post_json(
            f"/workflows/{workflow_id}/cancel", {"reason": reason}
        )

    async def send_signal(
        self, workflow_id: str, signal_name: str, payload: Any = None
    ) -> Dict[str, Any]:
        return await self._post_json(
            f"/workflows/{workflow_id}/signals/{signal_name}",
            {"payload": payload if payload is not None else {}},
        )

    async def list_dlq(self) -> List[Dict[str, Any]]:
        data = await self._get_json("/workflows/dlq")
        return list(data.get("entries", []))

    async def retry_dlq(self, dlq_entry_id: str) -> Dict[str, Any]:
        return await self._post_json(f"/workflows/dlq/{dlq_entry_id}/retry", {})

    async def get_stats(self) -> Dict[str, Any]:
        return await self._get_json("/stats")

    # ---- Schedule CRUD ----

    async def create_schedule(
        self,
        name: str,
        event_name: str,
        schedule_type: str = "cron",
        cron_expr: str = "",
        interval_sec: int = 0,
        payload: Optional[Dict[str, Any]] = None,
        description: str = "",
        enabled: bool = True,
        timezone: str = "UTC",
        jitter_sec: int = 0,
        overlap_policy: str = "allow",
        pause_on_failure: int = 0,
        metadata: Optional[Dict[str, Any]] = None,
        max_concurrent: int = 0,
        max_fires_per_window: int = 0,
        window_sec: int = 0,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "name": name,
            "event_name": event_name,
            "schedule_type": schedule_type,
            "enabled": enabled,
            "timezone": timezone,
        }
        if description:
            body["description"] = description
        if cron_expr:
            body["cron_expr"] = cron_expr
        if interval_sec > 0:
            body["interval_sec"] = interval_sec
        if payload is not None:
            body["payload"] = payload
        if jitter_sec > 0:
            body["jitter_sec"] = jitter_sec
        if overlap_policy != "allow":
            body["overlap_policy"] = overlap_policy
        if pause_on_failure > 0:
            body["pause_on_failure"] = pause_on_failure
        if metadata is not None:
            body["metadata"] = metadata
        if max_concurrent > 0:
            body["max_concurrent"] = max_concurrent
        if max_fires_per_window > 0:
            body["max_fires_per_window"] = max_fires_per_window
        if window_sec > 0:
            body["window_sec"] = window_sec
        return await self._post_json("/schedules", body)

    async def list_schedules(self) -> List[Dict[str, Any]]:
        data = await self._get_json("/schedules")
        return list(data.get("schedules", []))

    async def get_schedule(self, schedule_id: str) -> Dict[str, Any]:
        return await self._get_json(f"/schedules/{schedule_id}")

    async def update_schedule(self, schedule_id: str, **kwargs: Any) -> Dict[str, Any]:
        return await self._request_json("PUT", f"/schedules/{schedule_id}", kwargs)

    async def delete_schedule(self, schedule_id: str) -> Dict[str, Any]:
        return await self._request_json("DELETE", f"/schedules/{schedule_id}")

    async def pause_schedule(self, schedule_id: str) -> Dict[str, Any]:
        return await self._post_json(f"/schedules/{schedule_id}/pause", {})

    async def resume_schedule(self, schedule_id: str) -> Dict[str, Any]:
        return await self._post_json(f"/schedules/{schedule_id}/resume", {})

    async def get_schedule_history(
        self, schedule_id: str, limit: int = 50
    ) -> List[Dict[str, Any]]:
        data = await self._get_json(f"/schedules/{schedule_id}/history?limit={limit}")
        return list(data.get("executions", []))

    async def get_schedule_next_fires(
        self, schedule_id: str, count: int = 5
    ) -> List[str]:
        data = await self._get_json(f"/schedules/{schedule_id}/next?count={count}")
        return list(data.get("times", []))

    # ---- HTTP helpers ----

    async def _get_json(self, path: str) -> Dict[str, Any]:
        return await self._request_json("GET", path)

    async def _post_json(self, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
        return await self._request_json("POST", path, body)

    async def _request_json(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        import aiohttp

        url = f"{self.base_url.rstrip('/')}{path}"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        timeout = aiohttp.ClientTimeout(total=self.timeout_seconds)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.request(
                method, url, headers=headers,
                data=json.dumps(body).encode("utf-8") if body is not None else None,
            ) as resp:
                text = await resp.text()
                if resp.status >= 400:
                    raise EventPilotAPIError(
                        f"EventPilot API error {resp.status}: {text}"
                    )
                return json.loads(text) if text else {}


# ---------------------------------------------------------------------------
# Sync client (thin wrapper around the async one)
# ---------------------------------------------------------------------------


@dataclass
class EventPilotClient:
    """Sync client for EventPilot HTTP APIs.

    Safe to call from scripts and non-async code. Do NOT call from inside a
    running event loop — use ``AsyncEventPilotClient`` instead, which is
    non-blocking.
    """

    base_url: str
    api_key: str = ""
    timeout_seconds: float = 30.0

    def _async(self) -> AsyncEventPilotClient:
        return AsyncEventPilotClient(
            base_url=self.base_url,
            api_key=self.api_key,
            timeout_seconds=self.timeout_seconds,
        )

    def _run(self, coro):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop is not None and loop.is_running():
            raise RuntimeError(
                "EventPilotClient (sync) cannot be called from inside a "
                "running event loop — use AsyncEventPilotClient instead."
            )
        return asyncio.run(coro)

    def publish_event(self, *args, **kwargs):
        return self._run(self._async().publish_event(*args, **kwargs))

    def send(self, *args, **kwargs):
        return self._run(self._async().send(*args, **kwargs))

    def dispatch(self, *args, **kwargs):
        return self._run(self._async().dispatch(*args, **kwargs))

    def get_workflow(self, *args, **kwargs):
        return self._run(self._async().get_workflow(*args, **kwargs))

    def list_workflows(self, *args, **kwargs):
        return self._run(self._async().list_workflows(*args, **kwargs))

    def cancel_workflow(self, *args, **kwargs):
        return self._run(self._async().cancel_workflow(*args, **kwargs))

    def send_signal(self, *args, **kwargs):
        return self._run(self._async().send_signal(*args, **kwargs))

    def list_dlq(self, *args, **kwargs):
        return self._run(self._async().list_dlq(*args, **kwargs))

    def retry_dlq(self, *args, **kwargs):
        return self._run(self._async().retry_dlq(*args, **kwargs))

    def get_stats(self):
        return self._run(self._async().get_stats())

    def create_schedule(self, *args, **kwargs):
        return self._run(self._async().create_schedule(*args, **kwargs))

    def list_schedules(self):
        return self._run(self._async().list_schedules())

    def get_schedule(self, schedule_id: str):
        return self._run(self._async().get_schedule(schedule_id))

    def update_schedule(self, schedule_id: str, **kwargs):
        return self._run(self._async().update_schedule(schedule_id, **kwargs))

    def delete_schedule(self, schedule_id: str):
        return self._run(self._async().delete_schedule(schedule_id))

    def pause_schedule(self, schedule_id: str):
        return self._run(self._async().pause_schedule(schedule_id))

    def resume_schedule(self, schedule_id: str):
        return self._run(self._async().resume_schedule(schedule_id))

    def get_schedule_history(self, schedule_id: str, limit: int = 50):
        return self._run(self._async().get_schedule_history(schedule_id, limit))

    def get_schedule_next_fires(self, schedule_id: str, count: int = 5):
        return self._run(self._async().get_schedule_next_fires(schedule_id, count))
