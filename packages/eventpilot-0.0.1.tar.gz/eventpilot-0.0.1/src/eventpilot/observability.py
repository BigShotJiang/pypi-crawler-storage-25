"""Observability hooks for the EventPilot worker.

Two pluggable extension points:

- ``MetricsRecorder`` — lightweight protocol for emitting per-step metrics
  (duration, retries, defers, cancels). Applications implement the methods
  they care about; no base class required.
- ``WorkflowLogAdapter`` — convenience wrapper that injects workflow_id /
  step / attempt into every log line's ``extra=`` payload, so structured
  log aggregators can filter and correlate without parsing messages.

OpenTelemetry integration is optional. If ``opentelemetry-api`` is
installed (``eventpilot[otel]``) and a tracer provider is configured, the
worker wraps each step in a span named ``eventpilot.step.<name>`` with
workflow attributes; otherwise the helpers degrade to no-ops.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Dict, Optional, Protocol


class MetricsRecorder(Protocol):
    """Pluggable metrics sink the worker calls around step execution.

    Each method is optional — implement only what you care about. The
    worker catches and logs exceptions so a broken recorder never fails
    a workflow.
    """

    def record_step_started(self, handler: str, step: str, workflow_id: str) -> None: ...

    def record_step_completed(
        self, handler: str, step: str, workflow_id: str, duration_ms: float
    ) -> None: ...

    def record_step_failed(
        self, handler: str, step: str, workflow_id: str, error_code: str, retryable: bool
    ) -> None: ...

    def record_step_deferred(
        self, handler: str, step: str, workflow_id: str, delay_ms: int
    ) -> None: ...

    def record_workflow_cancelled(
        self, handler: str, workflow_id: str, reason: str
    ) -> None: ...


def _safe_call(recorder: Optional[MetricsRecorder], method: str, *args, **kwargs) -> None:
    """Invoke a recorder method if present, swallowing exceptions."""
    if recorder is None:
        return
    fn = getattr(recorder, method, None)
    if fn is None:
        return
    try:
        fn(*args, **kwargs)
    except Exception:  # noqa: BLE001 — observability must not break execution.
        logging.getLogger("eventpilot.sdk.metrics").exception(
            "MetricsRecorder.%s raised", method
        )


# ---------------------------------------------------------------------------
# Structured logging
# ---------------------------------------------------------------------------


class WorkflowLogAdapter(logging.LoggerAdapter):
    """LoggerAdapter that injects workflow correlation fields into ``extra=``."""

    def process(self, msg: str, kwargs: Dict[str, Any]):
        extra = kwargs.setdefault("extra", {})
        for k, v in self.extra.items():
            extra.setdefault(k, v)
        return msg, kwargs


def workflow_logger(
    base: logging.Logger,
    *,
    workflow_id: str,
    handler: str = "",
    step: str = "",
    attempt: int = 0,
) -> WorkflowLogAdapter:
    """Return a LoggerAdapter seeded with workflow correlation context."""
    return WorkflowLogAdapter(
        base,
        {
            "workflow_id": workflow_id,
            "ep_handler": handler,
            "ep_step": step,
            "ep_attempt": attempt,
        },
    )


# ---------------------------------------------------------------------------
# OpenTelemetry (optional)
# ---------------------------------------------------------------------------


def _get_tracer():
    try:
        from opentelemetry import trace

        return trace.get_tracer("eventpilot")
    except Exception:
        return None


@contextmanager
def step_span(handler: str, step: str, workflow_id: str):
    """Context manager that wraps a step execution in an OTel span (no-op if OTel absent)."""
    tracer = _get_tracer()
    if tracer is None:
        yield None
        return
    with tracer.start_as_current_span(f"eventpilot.step.{step}") as span:
        try:
            span.set_attribute("eventpilot.handler", handler)
            span.set_attribute("eventpilot.step", step)
            span.set_attribute("eventpilot.workflow_id", workflow_id)
        except Exception:
            pass
        yield span
