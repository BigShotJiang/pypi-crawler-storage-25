"""
In-process test environment for EventPilot handlers.

Lets you test handlers and individual steps without a running server.

Usage::

    import asyncio
    from eventpilot import handler, step, StepResult, WorkflowState
    from eventpilot.testing import TestEnv, TestStatus

    @handler("order-processing")
    class OrderProcessing:

        async def run(self, state: WorkflowState):
            await self.next_step(self.validate)
            await self.next_step(self.charge)

        @step("validate")
        async def validate(self, state: WorkflowState) -> StepResult:
            return StepResult(data={"valid": True})

        @step("charge")
        async def charge(self, state: WorkflowState) -> StepResult:
            return StepResult(data={"charged": True})

    async def test_order():
        env = TestEnv()
        env.register(OrderProcessing)

        result = await env.trigger("order-processing", {"order_id": "ord_123"})

        assert result.status == TestStatus.COMPLETED
        assert result.context["charged"] is True

    asyncio.run(test_order())
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from .types import (
    Defer, StepError, StepResult, WorkflowState, _DeferSignal, _StepFailed, _find_step_method
)

# Prevent pytest from collecting SDK helper classes as test classes.
__test__ = False


class TestStatus(str, Enum):
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    DEFERRED = "DEFERRED"


@dataclass
class TestStepResult:
    step_index: int
    step_name: str
    data: Dict[str, Any] = field(default_factory=dict)
    result: Any = None
    duration_ms: int = 0


@dataclass
class TestRetry:
    step_index: int
    step_name: str
    attempt: int
    error: str


@dataclass
class TestResult:
    status: TestStatus = TestStatus.COMPLETED
    context: Dict[str, Any] = field(default_factory=dict)
    step_results: Dict[int, TestStepResult] = field(default_factory=dict)
    failure_reason: str = ""
    failed_at_step: int = 0
    deferred_at_step: int = 0
    retry_history: List[TestRetry] = field(default_factory=list)


@dataclass
class TriggerOptions:
    """Configuration for a single trigger() call."""
    max_retries: int = 0
    initial_context: Dict[str, Any] = field(default_factory=dict)
    start_from_step: int = 0


class TestEnv:
    """In-process test environment for EventPilot handlers.

    Runs handler.run() in the calling coroutine without a server.
    """

    def __init__(self) -> None:
        self._handler_classes: Dict[str, type] = {}
        # Named signals delivered to the workflow during run(). Keyed by
        # (workflow_id, signal_name) → list of payloads. ``signal()`` pushes,
        # ``wait_for_signal()`` (via wait_for_event) checks the queue on replay.
        self._signal_inbox: Dict[tuple, List[Any]] = {}
        # Pre-seeded event payloads for wait_for_event() — keyed by (workflow_id, event_name).
        self._event_inbox: Dict[tuple, List[Any]] = {}
        self._heartbeats: List[Dict[str, Any]] = []
        self._advance_time_ms = 0

    def register(self, handler_class) -> None:
        """Register a handler class. Raises if not decorated with @handler."""
        if not getattr(handler_class, '_ep_is_handler', False):
            raise TypeError(
                f"{handler_class!r} is not a handler class. "
                "Decorate it with @handler(...) before registering."
            )
        name = handler_class._ep_handler_name
        if name in self._handler_classes:
            raise ValueError(f"Handler {name!r} already registered")
        self._handler_classes[name] = handler_class

    async def trigger(
        self,
        handler_name: str,
        payload: Any = None,
        opts: Optional[TriggerOptions] = None,
    ) -> TestResult:
        """Run a registered handler end-to-end and return the outcome.

        payload can be bytes, a dict, or any JSON-serialisable value.
        """
        handler_class = self._handler_classes.get(handler_name)
        if handler_class is None:
            raise KeyError(
                f"Handler {handler_name!r} not registered — call register() first"
            )

        opt = opts or TriggerOptions()

        if isinstance(payload, (bytes, bytearray)):
            payload_bytes = bytes(payload)
        elif payload is None:
            payload_bytes = b"{}"
        else:
            payload_bytes = json.dumps(payload).encode()

        max_retries = opt.max_retries if opt.max_retries > 0 else handler_class._ep_handler_max_retries
        result = TestResult(context=dict(opt.initial_context))

        state = self._build_state(handler_name, 0, payload_bytes, result)
        state._next_step_index = 0
        last_step_index = [0]

        async def in_process_checkpoint(idx: int, step_name: str, step_result: StepResult):
            last_step_index[0] = idx
            if step_result.defer_ms is None:
                data = step_result.data or {}
                cache_key = f"__ep_step_{step_name}"
                state.context.update(data)
                state.context[cache_key] = data
                result.context.update(data)
            result.step_results[idx] = TestStepResult(
                step_index=idx,
                step_name=step_name,
                data=step_result.data or {},
                result=step_result.result,
            )

        state._checkpoint_fn = in_process_checkpoint

        async def in_process_heartbeat(step_index: int, progress: bytes):
            self._heartbeats.append({
                "workflow_id": state.workflow_id,
                "step_index": step_index,
                "progress": progress,
            })

        state._heartbeat_fn = in_process_heartbeat

        # Retry loop — mirrors orchestrator behaviour: re-run run() on failure,
        # completed steps are replayed from cache, only the failed step re-executes.
        for attempt in range(1, max_retries + 2):
            instance = handler_class()
            instance._ep_state = state

            try:
                await instance.run(state)
                result.status = TestStatus.COMPLETED
                return result
            except _DeferSignal:
                result.status = TestStatus.DEFERRED
                result.deferred_at_step = last_step_index[0]
                return result
            except _StepFailed as sf:
                result.retry_history.append(
                    TestRetry(
                        step_index=last_step_index[0],
                        step_name=sf.step_name,
                        attempt=attempt,
                        error=str(sf.error),
                    )
                )
                if not sf.retryable or attempt > max_retries:
                    result.status = TestStatus.FAILED
                    result.failure_reason = str(sf.error)
                    result.failed_at_step = last_step_index[0]
                    return result
                # Next attempt: state already has cached completed steps,
                # failed step is not cached → will re-execute naturally.

        # Unreachable, but satisfy type checker
        return result

    def signal(self, workflow_id: str, name: str, payload: Any = None) -> None:
        """Enqueue a signal payload for ``wait_for_signal`` to consume."""
        key = (workflow_id, name)
        self._signal_inbox.setdefault(key, []).append(payload)

    def deliver_event(self, workflow_id: str, event_name: str, payload: Any = None) -> None:
        """Enqueue an event payload for ``wait_for_event`` to consume."""
        key = (workflow_id, event_name)
        self._event_inbox.setdefault(key, []).append(payload)

    async def query(self, handler_name: str, name: str, state: WorkflowState) -> Any:
        """Invoke a ``@query``-decorated method on a fresh handler instance."""
        handler_class = self._handler_classes.get(handler_name)
        if handler_class is None:
            raise KeyError(f"Handler {handler_name!r} not registered")
        queries = getattr(handler_class, "_ep_handler_queries", {})
        fn = queries.get(name)
        if fn is None:
            raise KeyError(f"Query {name!r} not declared on handler {handler_name!r}")
        instance = handler_class()
        instance._ep_state = state
        return await fn(instance, state)

    def advance_time(self, ms: int) -> None:
        """Advance the test clock by ``ms`` milliseconds.

        Causes sleeps and defers of ≤ remaining advanced-time to be treated
        as already expired on the next trigger() retry of the same workflow.
        """
        self._advance_time_ms += int(ms)

    @property
    def heartbeats(self) -> List[Dict[str, Any]]:
        """All ``self.heartbeat(progress=...)`` calls observed during run()."""
        return list(self._heartbeats)

    async def simulate_step(
        self,
        handler_name: str,
        step_name: str,
        state: WorkflowState,
    ) -> StepResult:
        """Run a single named step in isolation, bypassing next_step durability.

        Useful for unit-testing an individual step function directly.
        """
        handler_class = self._handler_classes.get(handler_name)
        if handler_class is None:
            raise KeyError(f"Handler {handler_name!r} not registered")

        instance = handler_class()
        func = _find_step_method(instance, step_name)
        bound = getattr(instance, func.__name__)
        result = await bound(state)
        return result if result is not None else StepResult()

    def _build_state(
        self,
        handler_name: str,
        step_index: int,
        payload_bytes: bytes,
        result: TestResult,
    ) -> WorkflowState:
        ctx = dict(result.context)
        # Root handler execution: grouping id equals the PK. __post_init__
        # copies workflow_id → handler_execution_id when the latter is unset,
        # but make it explicit here so tests can rely on either accessor.
        execution_id = f"test-wf-{int(time.time() * 1e9)}"
        return WorkflowState(
            workflow_id=execution_id,
            handler_execution_id=execution_id,
            workflow_type=handler_name,
            handler_version="test",
            version=1,
            status="RUNNING",
            current_handler=handler_name,
            current_step=step_index,
            context=ctx,
            trigger_payload=payload_bytes,
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )


# ── StateBuilder ──────────────────────────────────────────────────────────────


class StateBuilder:
    """Fluent builder for WorkflowState objects — handy for simulate_step tests."""

    def __init__(self, handler_name: str) -> None:
        self._state = WorkflowState(
            workflow_id="test-wf",
            handler_execution_id="test-wf",
            workflow_type=handler_name,
            handler_version="test",
            version=1,
            status="RUNNING",
            current_handler=handler_name,
            current_step=0,
            created_at=datetime.now(),
            updated_at=datetime.now(),
        )

    def with_payload(self, payload: Any) -> "StateBuilder":
        """Set the trigger payload from any JSON-serialisable value."""
        self._state.trigger_payload = json.dumps(payload).encode()
        return self

    def with_context(self, **kwargs: Any) -> "StateBuilder":
        """Set key-value pairs in the workflow context."""
        self._state.context.update(kwargs)
        return self

    def with_step(
        self, index: int, name: str = "", data: Optional[Dict[str, Any]] = None
    ) -> "StateBuilder":
        """Record a completed step result (for steps that depend on prior output)."""
        self._state.step_results[index] = StepResult(data=data or {})
        return self

    def at_step(self, index: int) -> "StateBuilder":
        """Set the current step index."""
        self._state.current_step = index
        return self

    def build(self) -> WorkflowState:
        """Return the constructed WorkflowState."""
        return self._state


def new_state(handler_name: str) -> StateBuilder:
    """Create a fresh StateBuilder for the given handler."""
    return StateBuilder(handler_name)
