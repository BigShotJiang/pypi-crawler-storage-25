"""Worker implementation for EventPilot SDK."""
import asyncio
import json
import logging
import signal
from datetime import datetime
from typing import Any, Dict, Optional, Set

import grpc

from ._protos import load_eventpilot_protos
from .types import (
    BackoffStrategy,
    ChildWorkflowResult,
    Defer,
    ErrorType,
    RetryPolicy,
    StepError,
    StepResult,
    StepTimeouts,
    TimeoutActionFail,
    TimeoutActionRetry,
    TimeoutActionSkip,
    TimeoutKind,
    WorkflowError,
    WorkflowState,
    _ChildWorkflowSignal,
    _DeferSignal,
    _StepFailed,
)

logger = logging.getLogger("eventpilot.sdk.worker")


class CheckpointWriteError(RuntimeError):
    """Raised when a StepCheckpoint cannot be delivered to the orchestrator.

    Signals the handler to abort its current run() invocation. The orchestrator
    will re-dispatch the workflow on its own retry budget once the worker
    reconnects — this guarantees at-least-once step delivery.
    """

_eventpilot_pb2 = None
_eventpilot_pb2_grpc = None


def _protos():
    global _eventpilot_pb2, _eventpilot_pb2_grpc
    if _eventpilot_pb2 is None or _eventpilot_pb2_grpc is None:
        _eventpilot_pb2, _eventpilot_pb2_grpc = load_eventpilot_protos()
    return _eventpilot_pb2, _eventpilot_pb2_grpc


class Worker:
    """Worker that connects to EventPilot and processes handler executions."""

    def __init__(
        self,
        addr: str,
        heartbeat_seconds: int = 30,
        drain_timeout_seconds: float = 30.0,
        max_concurrent_steps: int = 0,
        max_concurrent_per_handler: Optional[Dict[str, int]] = None,
        http_addr: str = "",
        metrics_recorder: Optional[Any] = None,
    ):
        self.addr = addr
        self.http_addr = http_addr
        self.metrics_recorder = metrics_recorder
        self.handler_classes: Dict[str, type] = {}
        self.worker_id: Optional[str] = None
        self.heartbeat_seconds = heartbeat_seconds
        self.drain_timeout_seconds = drain_timeout_seconds
        self.channel: Optional[grpc.aio.Channel] = None
        self.stub = None
        self._abort: Optional[asyncio.Event] = None
        self._in_flight: Set[asyncio.Task] = set()

        # Per-workflow cancellation tracking (mirrors Go SDK pattern).
        # _workflow_tasks maps workflow_id → the asyncio.Task running its handler.
        # _cancelled_workflows maps workflow_id → cancellation reason.
        self._workflow_tasks: Dict[str, asyncio.Task] = {}
        self._cancelled_workflows: Dict[str, str] = {}

        # Worker-side concurrency caps. A global semaphore bounds total
        # in-flight handler executions; per-handler semaphores isolate one
        # runaway handler from starving every other registered handler. A
        # value of 0 (or missing key) means "unlimited" — no semaphore is
        # created and there is no acquire overhead.
        self._global_sem: Optional[asyncio.Semaphore] = (
            asyncio.Semaphore(max_concurrent_steps) if max_concurrent_steps > 0 else None
        )
        # Operator-declared overrides win over handler-declared defaults at
        # registration time. Stored as a cap count; the semaphore is created
        # lazily in register() once we know the per-handler default too.
        self._per_handler_caps: Dict[str, int] = dict(max_concurrent_per_handler or {})
        self._per_handler_sem: Dict[str, asyncio.Semaphore] = {}

    def register(self, handler_class):
        """Register a handler class (decorated with @handler) with this worker."""
        if not getattr(handler_class, '_ep_is_handler', False):
            raise TypeError(
                f"{handler_class!r} is not a handler class. "
                "Decorate it with @handler(...) before registering."
            )
        name = handler_class._ep_handler_name
        self.handler_classes[name] = handler_class

        # Provision the per-handler semaphore unless an operator override
        # is already in place (operator wins — they know the production
        # deployment's constraints better than the handler author).
        declared_cap = int(getattr(handler_class, "_ep_handler_max_concurrency", 0) or 0)
        effective_cap = self._per_handler_caps.get(name, declared_cap)
        if effective_cap > 0 and name not in self._per_handler_sem:
            self._per_handler_sem[name] = asyncio.Semaphore(effective_cap)

        logger.info(
            f"Registered handler: {name} "
            f"(version={handler_class._ep_handler_version}, "
            f"steps={len(handler_class._ep_handler_steps_meta)}, "
            f"max_concurrency={effective_cap or 'unlimited'})"
        )

    def stop(self) -> None:
        """Signal the worker to drain in-flight handlers and exit cleanly.

        Idempotent. Safe to call from a signal handler installed via
        ``loop.add_signal_handler`` or from another coroutine.
        """
        if self._abort is not None:
            self._abort.set()

    def _install_signal_handlers(self) -> None:
        """Wire SIGINT and SIGTERM to ``stop()`` for the running event loop.

        Best-effort: on platforms where ``add_signal_handler`` is unavailable
        (e.g. Windows without ProactorEventLoop), this is a no-op and callers
        must call ``stop()`` themselves.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, self.stop)
            except (NotImplementedError, RuntimeError):
                pass

    async def start(self, install_signal_handlers: bool = True):
        """Connect to EventPilot and start processing. Reconnects with exponential backoff.

        When ``install_signal_handlers`` is true (the default), SIGINT and
        SIGTERM trigger a graceful drain: the worker stops accepting new step
        dispatches and waits up to ``drain_timeout_seconds`` for in-flight
        handlers to checkpoint before closing the stream.
        """
        self._abort = asyncio.Event()
        if install_signal_handlers:
            self._install_signal_handlers()

        # Register any @scheduled schedules declared on registered handlers.
        await self._register_declared_schedules()

        self._reconnect_backoff = 1.0
        self._reconnect_min_backoff = 1.0
        self._reconnect_max_backoff = 30.0
        attempt = 0

        while not self._abort.is_set():
            attempt += 1
            if attempt > 1:
                logger.info(
                    f"Reconnection attempt #{attempt} (backoff={self._reconnect_backoff}s)"
                )

            try:
                await self._run_stream()
                logger.info("Stream ended gracefully")
                break
            except asyncio.CancelledError:
                logger.info("Worker stopping...")
                raise
            except Exception as e:
                if self._abort.is_set():
                    break
                logger.warning(
                    f"Stream error: {e} - reconnecting in {self._reconnect_backoff}s"
                )
                try:
                    await asyncio.sleep(self._reconnect_backoff)
                except asyncio.CancelledError:
                    logger.info("Worker stopping during reconnection backoff...")
                    raise
                # Exponential backoff; reset happens only after the stream
                # registers successfully (see _run_stream).
                self._reconnect_backoff = min(
                    self._reconnect_backoff * 2, self._reconnect_max_backoff
                )

        if self._abort.is_set():
            logger.info("Worker draining on abort signal")

    async def _run_stream(self):
        """Handle a single stream connection lifecycle."""
        _, eventpilot_pb2_grpc = _protos()
        self.channel = grpc.aio.insecure_channel(self.addr)
        self.stub = eventpilot_pb2_grpc.EventPilotServiceStub(self.channel)

        stream = self.stub.WorkerStream()

        for handler_class in self.handler_classes.values():
            await self._send_registration(stream, handler_class)

            msg = await stream.read()
            if msg == grpc.aio.EOF:
                raise RuntimeError("Stream closed before registration ack")
            if not msg.HasField("registration_ack"):
                raise RuntimeError("Expected registration ack")

            ack = msg.registration_ack
            if not ack.success:
                raise RuntimeError(f"Registration failed: {ack.error}")

            self.worker_id = ack.worker_id
            logger.info(
                f"Registration successful: handler={handler_class._ep_handler_name} "
                f"worker_id={self.worker_id}"
            )
            # Registration succeeded — reset reconnect backoff so a healthy
            # period between failures doesn't inherit the prior backoff.
            if hasattr(self, "_reconnect_min_backoff"):
                self._reconnect_backoff = self._reconnect_min_backoff

        heartbeat_task = asyncio.create_task(self._send_heartbeats(stream))
        abort_wait = asyncio.create_task(self._abort.wait()) if self._abort else None

        logger.info("Entering message loop, waiting for handler requests...")
        try:
            while True:
                read_task = asyncio.create_task(stream.read())
                waiters = {read_task}
                if abort_wait is not None:
                    waiters.add(abort_wait)
                done, _ = await asyncio.wait(
                    waiters, return_when=asyncio.FIRST_COMPLETED
                )
                if abort_wait is not None and abort_wait in done:
                    read_task.cancel()
                    try:
                        await read_task
                    except (asyncio.CancelledError, Exception):
                        pass
                    logger.info("Abort requested — draining in-flight handlers")
                    break
                msg = read_task.result()
                if msg == grpc.aio.EOF:
                    raise RuntimeError("Stream closed by server")
                if msg.HasField("execute_handler"):
                    req = msg.execute_handler
                    task = asyncio.create_task(
                        self._handle_handler_request(stream, req)
                    )
                    self._in_flight.add(task)
                    task.add_done_callback(self._in_flight.discard)
                elif msg.HasField("execute_on_timeout"):
                    req = msg.execute_on_timeout
                    task = asyncio.create_task(
                        self._handle_on_timeout_request(stream, req)
                    )
                    self._in_flight.add(task)
                    task.add_done_callback(self._in_flight.discard)
                elif msg.HasField("cancel_workflow"):
                    cancel = msg.cancel_workflow
                    logger.info(
                        f"Workflow cancelled: {cancel.workflow_id} reason={cancel.reason}"
                    )
                    self._mark_workflow_cancelled(cancel.workflow_id, cancel.reason)
                else:
                    logger.warning("Received unknown message type: %s", msg)
        except asyncio.CancelledError:
            raise
        finally:
            if self._in_flight:
                logger.info(
                    f"Draining {len(self._in_flight)} in-flight handler(s) "
                    f"(timeout={self.drain_timeout_seconds}s)"
                )
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*self._in_flight, return_exceptions=True),
                        timeout=self.drain_timeout_seconds,
                    )
                except asyncio.TimeoutError:
                    logger.warning(
                        "Drain timeout exceeded — some handlers did not complete"
                    )
            heartbeat_task.cancel()
            try:
                await heartbeat_task
            except asyncio.CancelledError:
                pass
            if abort_wait is not None and not abort_wait.done():
                abort_wait.cancel()
                try:
                    await abort_wait
                except asyncio.CancelledError:
                    pass
            await self.close()

    async def close(self):
        """Close the gRPC channel."""
        if self.channel:
            await self.channel.close()

    async def _register_declared_schedules(self) -> None:
        """Push @scheduled schedules to the server via the HTTP API.

        Called once at worker start. Silently skipped when ``http_addr`` is
        not configured (so schedules can be declared locally without a live
        server for unit tests) — log a warning in that case.
        """
        schedules_by_handler = [
            (cls._ep_handler_name, getattr(cls, "_ep_handler_schedules", []))
            for cls in self.handler_classes.values()
        ]
        if not any(s for _, s in schedules_by_handler):
            return
        if not self.http_addr:
            logger.warning(
                "Handlers declare @scheduled but Worker(http_addr=...) not set; "
                "schedules will NOT be registered with the server"
            )
            return

        from .client import AsyncEventPilotClient
        client = AsyncEventPilotClient(base_url=self.http_addr)
        for handler_name, schedules in schedules_by_handler:
            for entry in schedules:
                try:
                    await client.create_schedule(
                        name=entry["name"],
                        event_name=handler_name,
                        schedule_type="cron" if entry["cron"] else "interval",
                        cron_expr=entry["cron"],
                        interval_sec=entry["interval_sec"],
                        payload=entry["payload"],
                        timezone=entry["timezone"],
                        enabled=entry["enabled"],
                        jitter_sec=entry["jitter_sec"],
                        overlap_policy=entry["overlap_policy"],
                    )
                    logger.info(
                        f"Registered schedule: {entry['name']} for handler={handler_name}"
                    )
                except Exception as e:
                    # Already-exists is common on restart; log and continue.
                    logger.info(
                        f"Schedule {entry['name']} not (re)registered: {e}"
                    )

    async def _send_registration(self, stream, handler_class):
        """Send HandlerRegistration proto for a handler class."""
        eventpilot_pb2, _ = _protos()
        retry_policy_proto = _handler_retry_policy_to_proto(handler_class, eventpilot_pb2)
        step_timeouts_proto = _step_timeouts_to_proto(
            getattr(handler_class, "_ep_handler_step_timeouts", None),
            eventpilot_pb2,
        )
        # Map handler_type string to proto enum value.
        ht_str = getattr(handler_class, "_ep_handler_type", "task") or "task"
        ht_enum = {
            "task": eventpilot_pb2.HANDLER_TYPE_TASK,
            "event": eventpilot_pb2.HANDLER_TYPE_EVENT,
        }.get(ht_str, eventpilot_pb2.HANDLER_TYPE_TASK)

        run_timeout_ms = int(getattr(handler_class, "_ep_handler_run_timeout_ms", 0) or 0)
        has_on_timeout = getattr(handler_class, "_ep_handler_on_timeout", None) is not None

        registration = eventpilot_pb2.HandlerRegistration(
            handler_name=handler_class._ep_handler_name,
            handler_version=handler_class._ep_handler_version,
            has_compensation=handler_class._ep_handler_has_compensation,
            rate_limit_scope=handler_class._ep_handler_rate_limit_scope,
            rate_limit_per_sec=handler_class._ep_handler_rate_limit_rate,
            max_concurrency=int(getattr(handler_class, "_ep_handler_max_concurrency", 0) or 0),
            priority=int(getattr(handler_class, "_ep_handler_priority", 0) or 0),
            store_intermediate_steps=handler_class._ep_handler_store_intermediate_steps,
            handler_type=ht_enum,
            subscribes_to=getattr(handler_class, "_ep_handler_subscribes_to", []) or [],
            run_timeout_ms=run_timeout_ms,
            has_on_timeout=has_on_timeout,
            min_event_version=int(getattr(handler_class, "_ep_handler_min_event_version", 0) or 0),
            max_event_version=int(getattr(handler_class, "_ep_handler_max_event_version", 0) or 0),
            cancel_on=[
                eventpilot_pb2.CancelOnRule(
                    event_name=r.get("event", ""),
                    match_expression=r.get("match", ""),
                )
                for r in (getattr(handler_class, "_ep_handler_cancel_on", None) or [])
            ],
        )
        if retry_policy_proto is not None:
            registration.retry_policy.CopyFrom(retry_policy_proto)
        if step_timeouts_proto is not None:
            registration.step_timeouts.CopyFrom(step_timeouts_proto)
        msg = eventpilot_pb2.WorkerMessage(registration=registration)
        await stream.write(msg)

    async def _send_heartbeats(self, stream):
        """Send periodic heartbeats to keep the stream alive."""
        eventpilot_pb2, _ = _protos()
        try:
            while True:
                await asyncio.sleep(self.heartbeat_seconds)
                msg = eventpilot_pb2.WorkerMessage(
                    heartbeat=eventpilot_pb2.WorkerHeartbeat(worker_id=self.worker_id)
                )
                await stream.write(msg)
        except asyncio.CancelledError:
            pass

    async def _acquire_slot(self, handler_name: str):
        """Acquire global + per-handler concurrency slots.

        Returns an async context manager. When both are unlimited this is
        effectively zero-overhead — no semaphore is created and the inner
        body executes immediately.
        """
        acquired: list[asyncio.Semaphore] = []
        if self._global_sem is not None:
            await self._global_sem.acquire()
            acquired.append(self._global_sem)
        handler_sem = self._per_handler_sem.get(handler_name)
        if handler_sem is not None:
            try:
                await handler_sem.acquire()
                acquired.append(handler_sem)
            except BaseException:
                # Roll back the global acquisition if the per-handler one
                # failed (e.g. cancellation) so slots don't leak.
                if self._global_sem is not None:
                    self._global_sem.release()
                raise
        return acquired

    def _release_slots(self, acquired):
        for sem in acquired:
            sem.release()

    def _mark_workflow_cancelled(self, workflow_id: str, reason: str) -> None:
        """Record cancellation and cancel the in-flight task if one exists."""
        self._cancelled_workflows[workflow_id] = reason
        task = self._workflow_tasks.get(workflow_id)
        if task is not None and not task.done():
            task.cancel()

    def _is_workflow_cancelled(self, workflow_id: str) -> Optional[str]:
        """Return the cancellation reason if the workflow was cancelled, else None."""
        return self._cancelled_workflows.get(workflow_id)

    def _clear_workflow_cancellation(self, workflow_id: str) -> None:
        """Remove cancellation tracking for a workflow."""
        self._cancelled_workflows.pop(workflow_id, None)
        self._workflow_tasks.pop(workflow_id, None)

    async def _handle_handler_request(self, stream, req):
        """Handle an execute_handler request by instantiating the class and calling run()."""
        proto_state = req.state
        handler_name = proto_state.current_handler
        # Worker-local cancellation/task tracking keys on the per-handler-
        # execution PK, because the orchestrator's CancelWorkflow message
        # carries the PK (handler_execution_id) — not the grouping id.
        workflow_id = getattr(proto_state, "handler_execution_id", "") or proto_state.workflow_id

        handler_class = self.handler_classes.get(handler_name)
        if not handler_class:
            logger.error(f"Handler not found: {handler_name}")
            return

        # Check if this workflow was already cancelled before we start.
        cancel_reason = self._is_workflow_cancelled(workflow_id)
        if cancel_reason is not None:
            logger.info(f"Skipping pre-cancelled workflow: {workflow_id} reason={cancel_reason}")
            self._clear_workflow_cancellation(workflow_id)
            return

        # Register the current task so _mark_workflow_cancelled can cancel it.
        current_task = asyncio.current_task()
        if current_task is not None:
            self._workflow_tasks[workflow_id] = current_task

        acquired = await self._acquire_slot(handler_name)
        try:
            await self._handle_handler_request_inner(stream, req, handler_class, proto_state)
        finally:
            self._release_slots(acquired)
            self._clear_workflow_cancellation(workflow_id)

    async def _handle_handler_request_inner(self, stream, req, handler_class, proto_state):
        state = self._proto_to_state(proto_state, req.trigger_payload)
        state._grpc_addr = self.addr
        state._next_step_index = max(0, req.resume_from_step + 1) if req.resume_from_step >= 0 else 0

        instance = handler_class()
        instance._ep_state = state

        # Inject checkpoint callback
        async def checkpoint_fn(step_index: int, step_name: str, result: StepResult, *, child_workflow: dict = None):
            checkpoint = self._build_named_checkpoint(state, step_index, step_name, result, child_workflow=child_workflow)
            await self._send_checkpoint(stream, checkpoint)

        async def heartbeat_fn(step_index: int, progress: bytes):
            handler_execution_id = state.handler_execution_id or state.workflow_id
            await self._send_step_heartbeat(stream, handler_execution_id, step_index, progress)

        state._checkpoint_fn = checkpoint_fn
        state._heartbeat_fn = heartbeat_fn
        state._metrics_recorder = self.metrics_recorder

        logger.info(
            "Executing handler: workflow=%s handler=%s start_step_index=%s",
            state.workflow_id, handler_name, state._next_step_index,
            extra={
                "workflow_id": state.workflow_id,
                "ep_handler": handler_name,
                "ep_attempt": state.attempt,
            },
        )

        try:
            await instance.run(state)
            # run() completed — send a handler_complete signal
            try:
                await self._send_handler_complete(stream, state)
            except CheckpointWriteError as ce:
                logger.error(
                    f"Failed to persist handler_complete checkpoint "
                    f"workflow={state.workflow_id}: {ce}"
                )
        except asyncio.CancelledError:
            # Task was cancelled — check if this was an orchestrator-initiated cancellation.
            cancel_reason = self._is_workflow_cancelled(state.workflow_id) or "workflow cancelled"
            logger.info(
                f"Handler cancelled: workflow={state.workflow_id} reason={cancel_reason}"
            )
            if self.metrics_recorder is not None:
                from .observability import _safe_call
                _safe_call(
                    self.metrics_recorder, "record_workflow_cancelled",
                    handler_class._ep_handler_name, state.workflow_id, cancel_reason,
                )
            await self._send_cancel_checkpoint(stream, state, cancel_reason)
        except _ChildWorkflowSignal:
            # Child workflow checkpoint already sent — handler defers until child completes (or immediately for async)
            logger.info(f"Handler deferred for child workflow: workflow={state.workflow_id}")
        except _DeferSignal:
            # A step deferred — checkpoint already sent by next_step, nothing more to do
            logger.info(f"Handler deferred: workflow={state.workflow_id}")
        except CheckpointWriteError as e:
            # Checkpoint delivery failed permanently — don't try another send
            # (stream is likely closed). Orchestrator re-dispatches the
            # workflow once the worker reconnects; at-least-once semantics
            # mean step may execute twice, so handlers must rely on
            # side_effect_key idempotency for externally-visible work.
            logger.error(
                f"Handler aborted: checkpoint write failed "
                f"workflow={state.workflow_id}: {e}"
            )
            return
        except _StepFailed as sf:
            err = sf.error
            logger.error(
                f"Handler step failed: workflow={state.workflow_id} "
                f"step={sf.step_name} retryable={sf.retryable} error={err}"
            )
            try:
                await self._send_failure_checkpoint(stream, state, err)
            except CheckpointWriteError as ce:
                logger.error(
                    f"Failed to persist failure checkpoint "
                    f"workflow={state.workflow_id}: {ce}"
                )
        except StepError as err:
            logger.error(f"Handler raised StepError: workflow={state.workflow_id} error={err}")
            try:
                await self._send_failure_checkpoint(stream, state, err)
            except CheckpointWriteError as ce:
                logger.error(
                    f"Failed to persist failure checkpoint "
                    f"workflow={state.workflow_id}: {ce}"
                )
        except Exception as e:
            logger.exception(f"Handler run() raised unexpected error: workflow={state.workflow_id}")
            try:
                await self._send_failure_checkpoint(stream, state, e)
            except CheckpointWriteError as ce:
                logger.error(
                    f"Failed to persist failure checkpoint "
                    f"workflow={state.workflow_id}: {ce}"
                )

    def _proto_to_state(self, proto_state, trigger_payload: bytes) -> WorkflowState:
        """Convert proto WorkflowState to SDK WorkflowState."""
        handler_execution_id = getattr(proto_state, "handler_execution_id", "") or proto_state.workflow_id
        grouping_workflow_id = proto_state.workflow_id or handler_execution_id
        parent_handler_execution_id = getattr(proto_state, "parent_handler_execution_id", "")
        parent_workflow_id = getattr(proto_state, "parent_workflow_id", "")

        state = WorkflowState(
            workflow_id=grouping_workflow_id,
            workflow_type=proto_state.workflow_type,
            handler_version=proto_state.handler_version,
            version=proto_state.version,
            status=proto_state.status,
            current_handler=proto_state.current_handler,
            current_step=proto_state.current_step,
            step_results={},
            context={},
            payload_refs=dict(proto_state.payload_refs),
            error_history=[],
            retry_count=proto_state.retry_count,
            total_steps=proto_state.total_steps,
            trigger_event_id=proto_state.trigger_event_id,
            trigger_payload=trigger_payload,
            handler_execution_id=handler_execution_id,
            parent_handler_execution_id=parent_handler_execution_id,
            parent_workflow_id=parent_workflow_id,
        )

        if proto_state.resume_at_ms > 0:
            state.resume_at = datetime.fromtimestamp(proto_state.resume_at_ms / 1000)
        if proto_state.created_at_ms > 0:
            state.created_at = datetime.fromtimestamp(proto_state.created_at_ms / 1000)
        if proto_state.updated_at_ms > 0:
            state.updated_at = datetime.fromtimestamp(proto_state.updated_at_ms / 1000)

        for k, v in proto_state.context.items():
            try:
                state.context[k] = json.loads(v)
            except json.JSONDecodeError:
                state.context[k] = v

        for err in proto_state.error_history:
            state.error_history.append(
                WorkflowError(
                    step_index=err.step_index,
                    error=err.error,
                    timestamp=datetime.fromtimestamp(err.timestamp_ms / 1000),
                    attempt=err.attempt,
                )
            )

        return state

    def _build_named_checkpoint(
        self,
        state: WorkflowState,
        step_index: int,
        step_name: str,
        result: StepResult,
        *,
        child_workflow: dict = None,
    ):
        """Build a StepCheckpoint proto from a step execution result."""
        eventpilot_pb2, _ = _protos()
        # StepCheckpoint is keyed by the per-handler-execution PK. Populate
        # both the legacy ``workflow_id`` field and the new
        # ``handler_execution_id`` field with the PK so pre- and post-Stage-2
        # orchestrators both route the checkpoint correctly.
        handler_execution_id = state.handler_execution_id or state.workflow_id
        checkpoint = eventpilot_pb2.StepCheckpoint(
            workflow_id=handler_execution_id,
            handler_execution_id=handler_execution_id,
            step_index=step_index,
            step_name=step_name,
        )

        # Child workflow checkpoint — atomic emit+wait.
        if child_workflow is not None:
            cw_proto = eventpilot_pb2.ChildWorkflowCheckpoint(
                event_name=child_workflow.get("event_name", ""),
                payload=child_workflow.get("payload", b""),
                workflow_id=child_workflow.get("workflow_id", ""),
                wait_for_result=child_workflow.get("wait_for_result", False),
                timeout_ms=int(child_workflow.get("timeout_ms", 0)),
                timeout_reason=child_workflow.get("timeout_reason", ""),
                idempotency_key=child_workflow.get("idempotency_key", ""),
                headers=child_workflow.get("headers", {}),
                cancel_on_parent_cancel=child_workflow.get("cancel_on_parent_cancel", False),
            )
            checkpoint.child_workflow.CopyFrom(cw_proto)
            checkpoint.success.CopyFrom(eventpilot_pb2.StepSuccess())
            return checkpoint

        if result is None:
            result = StepResult()

        if result.defer_ms is not None or result.defer_deadline_ms is not None:
            defer_msg = eventpilot_pb2.StepDefer()
            if result.defer_deadline_ms is not None:
                defer_msg.deadline_ms = result.defer_deadline_ms
            elif result.defer_ms is not None:
                defer_msg.delay_ms = result.defer_ms
            checkpoint.defer.CopyFrom(defer_msg)
            if result.data:
                checkpoint.context_updates.update(_serialize_context(result.data))
            if hasattr(result, '_wait_for_event') and result._wait_for_event:
                we = result._wait_for_event
                checkpoint.wait_for_event.CopyFrom(eventpilot_pb2.EventWait(
                    event_name=we.get("event", ""),
                    correlation_key=we.get("correlation_key", ""),
                    timeout_ms=we.get("timeout_ms", 0),
                ))
            return checkpoint

        result_bytes = b""
        if result.result is not None:
            result_bytes = _json_dumps_strict(result.result, what="StepResult.result").encode("utf-8")

        context_updates = {}
        if result.data:
            context_updates = _serialize_context(result.data)

        side_effect_result = b""
        if result.side_effect_result is not None:
            side_effect_result = _json_dumps_strict(
                result.side_effect_result, what="StepResult.side_effect_result"
            ).encode("utf-8")

        checkpoint.success.CopyFrom(eventpilot_pb2.StepSuccess(result=result_bytes))
        checkpoint.context_updates.update(context_updates)
        checkpoint.idempotency_key = result.side_effect_key or ""
        checkpoint.side_effect_result = side_effect_result

        return checkpoint

    async def _send_handler_complete(self, stream, state: WorkflowState):
        """Send a handler_complete marker after run() finishes successfully."""
        eventpilot_pb2, _ = _protos()
        handler_execution_id = state.handler_execution_id or state.workflow_id
        checkpoint = eventpilot_pb2.StepCheckpoint(
            workflow_id=handler_execution_id,
            handler_execution_id=handler_execution_id,
            step_index=state._next_step_index,
            step_name="__handler_complete__",
            handler_complete=True,
        )
        checkpoint.success.CopyFrom(eventpilot_pb2.StepSuccess())
        await self._send_checkpoint(stream, checkpoint)

    async def _send_failure_checkpoint(self, stream, state: WorkflowState, error: Exception):
        """Send a failure checkpoint when run() raises an unhandled exception.

        Accepts any ``Exception``. If it's a ``StepError``, its ``code`` /
        ``error_type`` / ``details`` / ``retryable`` flags are forwarded so
        the orchestrator can apply per-code retry overrides.
        """
        eventpilot_pb2, _ = _protos()
        handler_execution_id = state.handler_execution_id or state.workflow_id
        checkpoint = eventpilot_pb2.StepCheckpoint(
            workflow_id=handler_execution_id,
            handler_execution_id=handler_execution_id,
            step_index=state._next_step_index,
            step_name="__handler_error__",
        )
        checkpoint.failure.CopyFrom(_failure_from_exception(error, eventpilot_pb2))
        await self._send_checkpoint(stream, checkpoint)

    async def _send_cancel_checkpoint(self, stream, state: WorkflowState, reason: str):
        """Send a failure checkpoint with CANCELLED error type when a workflow is cancelled."""
        eventpilot_pb2, _ = _protos()
        handler_execution_id = state.handler_execution_id or state.workflow_id
        checkpoint = eventpilot_pb2.StepCheckpoint(
            workflow_id=handler_execution_id,
            handler_execution_id=handler_execution_id,
            step_index=state._next_step_index,
            step_name="__handler_cancelled__",
        )
        checkpoint.failure.CopyFrom(eventpilot_pb2.StepFailure(
            error=reason,
            non_retryable=True,
            error_type=int(ErrorType.CANCELLED),
        ))
        try:
            await self._send_checkpoint(stream, checkpoint)
        except Exception:
            # Stream may already be closed if orchestrator cancelled us —
            # log but don't propagate since the workflow is already terminal.
            logger.debug(f"Could not send cancel checkpoint for {state.workflow_id} (stream may be closed)")

    async def _send_step_heartbeat(
        self, stream, workflow_id: str, step_index: int, progress: bytes
    ) -> None:
        """Emit a ``StepHeartbeat`` for a currently-executing step.

        Best-effort: failures are logged but not raised — missing a heartbeat
        is not a correctness problem, only a liveness/progress signal.
        """
        eventpilot_pb2, _ = _protos()
        import time as _time

        try:
            msg = eventpilot_pb2.WorkerMessage(
                step_heartbeat=eventpilot_pb2.StepHeartbeat(
                    workflow_id=workflow_id,
                    handler_execution_id=workflow_id,
                    step_index=int(step_index),
                    timestamp_ms=int(_time.time() * 1000),
                    progress_payload=progress or b"",
                )
            )
            await stream.write(msg)
        except Exception as e:
            logger.warning(
                f"Step heartbeat send failed workflow={workflow_id} step={step_index}: {e}"
            )

    async def _send_checkpoint(self, stream, checkpoint) -> bool:
        """Write a checkpoint message to the stream with bounded retries.

        Checkpoints are the durability boundary: losing one means the step's
        result never reaches the orchestrator. We retry transient send failures
        with exponential backoff (100ms → 3.2s, 6 attempts ≈ 6.3s total). On
        persistent failure we raise ``CheckpointWriteError`` so the caller
        surfaces the error and the orchestrator re-dispatches the step.
        """
        eventpilot_pb2, _ = _protos()
        msg = eventpilot_pb2.WorkerMessage(checkpoint=checkpoint)

        delay = 0.1
        max_attempts = 6
        last_err: Optional[Exception] = None
        for attempt in range(1, max_attempts + 1):
            try:
                await stream.write(msg)
                if attempt > 1:
                    logger.info(
                        f"Checkpoint sent on attempt {attempt} "
                        f"(workflow={checkpoint.workflow_id} step={checkpoint.step_name})"
                    )
                return True
            except asyncio.CancelledError:
                raise
            except Exception as e:
                last_err = e
                if attempt >= max_attempts:
                    break
                logger.warning(
                    f"Checkpoint send failed (attempt {attempt}/{max_attempts}) "
                    f"workflow={checkpoint.workflow_id} step={checkpoint.step_name}: {e} "
                    f"— retrying in {delay}s"
                )
                try:
                    await asyncio.sleep(delay)
                except asyncio.CancelledError:
                    raise
                delay = min(delay * 2, 2.0)

        logger.error(
            f"Checkpoint send failed permanently after {max_attempts} attempts "
            f"workflow={checkpoint.workflow_id} step={checkpoint.step_name}: {last_err}"
        )
        raise CheckpointWriteError(
            f"failed to send checkpoint for workflow={checkpoint.workflow_id} "
            f"step={checkpoint.step_name}: {last_err}"
        ) from last_err


    async def _handle_on_timeout_request(self, stream, req):
        """Handle an execute_on_timeout request from the orchestrator."""
        eventpilot_pb2, _ = _protos()
        proto_state = req.state
        handler_name = proto_state.current_handler
        step_index = int(req.step_index)
        step_name = req.step_name
        kind = TimeoutKind(req.timeout_kind)
        message = req.timeout_message

        handler_class = self.handler_classes.get(handler_name)
        handler_execution_id = getattr(proto_state, "handler_execution_id", "") or proto_state.workflow_id
        if not handler_class:
            logger.error(f"on_timeout: handler {handler_name!r} not found")
            await self._send_on_timeout_outcome(stream, eventpilot_pb2, handler_execution_id,
                eventpilot_pb2.OnTimeoutOutcome(
                    workflow_id=handler_execution_id,
                    handler_execution_id=handler_execution_id,
                    fail=eventpilot_pb2.OnTimeoutFail(error=f"handler not found: {handler_name}"),
                ))
            return

        # Resolve step-level on_timeout first, then handler-level.
        on_timeout_fn = None
        steps_meta = getattr(handler_class, "_ep_handler_steps_meta", [])
        if 0 <= step_index < len(steps_meta):
            on_timeout_fn = getattr(steps_meta[step_index], "_ep_on_timeout", None)
        if on_timeout_fn is None:
            on_timeout_fn = getattr(handler_class, "_ep_handler_on_timeout", None)

        if on_timeout_fn is None:
            await self._send_on_timeout_outcome(stream, eventpilot_pb2, handler_execution_id,
                eventpilot_pb2.OnTimeoutOutcome(
                    workflow_id=handler_execution_id,
                    handler_execution_id=handler_execution_id,
                    fail=eventpilot_pb2.OnTimeoutFail(error=message),
                ))
            return

        state = self._proto_to_state(proto_state, req.trigger_payload)

        try:
            if asyncio.iscoroutinefunction(on_timeout_fn):
                action = await on_timeout_fn(state, step_name, step_index, kind, message)
            else:
                action = on_timeout_fn(state, step_name, step_index, kind, message)
        except Exception as e:
            logger.exception(f"on_timeout callback raised: workflow={proto_state.workflow_id}")
            action = TimeoutActionFail(error=str(e))

        if action is None:
            action = TimeoutActionFail(error=message)

        # Build context updates from state. Non-JSON values raise explicitly
        # so bugs surface at dev time rather than corrupting workflow state.
        context_updates = {}
        for k, v in state.context.items():
            if isinstance(v, str):
                context_updates[k] = v
            else:
                context_updates[k] = _json_dumps_strict(
                    v, what=f"state.context[{k!r}]"
                )

        outcome = eventpilot_pb2.OnTimeoutOutcome(
            workflow_id=handler_execution_id,
            handler_execution_id=handler_execution_id,
            context_updates=context_updates,
        )

        if isinstance(action, TimeoutActionFail):
            outcome.fail.CopyFrom(eventpilot_pb2.OnTimeoutFail(error=action.error))
        elif isinstance(action, TimeoutActionRetry):
            outcome.retry.CopyFrom(eventpilot_pb2.OnTimeoutRetry(delay_ms=int(action.delay_ms)))
        elif isinstance(action, TimeoutActionSkip):
            skip = eventpilot_pb2.OnTimeoutSkip(skip_to_step=int(action.skip_to_step))
            if action.result is not None:
                skip.result = _json_dumps_strict(
                    action.result, what="TimeoutActionSkip.result"
                ).encode("utf-8")
            outcome.skip.CopyFrom(skip)
        else:
            outcome.fail.CopyFrom(eventpilot_pb2.OnTimeoutFail(error=message))

        await self._send_on_timeout_outcome(stream, eventpilot_pb2, handler_execution_id, outcome)

    async def _send_on_timeout_outcome(self, stream, eventpilot_pb2, workflow_id, outcome):
        """Send an OnTimeoutOutcome message back to the orchestrator."""
        try:
            msg = eventpilot_pb2.WorkerMessage(on_timeout_outcome=outcome)
            await stream.write(msg)
        except Exception as e:
            logger.exception(f"Failed to send on_timeout outcome for workflow={workflow_id}: {e}")


# --- Serialization helpers ------------------------------------------------


def _json_dumps_strict(value, *, what: str) -> str:
    """JSON-serialize ``value`` or raise ``TypeError`` with a clear hint.

    Handlers occasionally stash non-JSON values (datetimes, dataclasses, sets)
    in context or step results and previously these got silently str()'d by
    json.dumps with default=str, corrupting workflow state. This wrapper
    refuses and points the user at the offending field.
    """
    try:
        return json.dumps(value)
    except (TypeError, ValueError) as e:
        raise TypeError(
            f"{what} is not JSON-serializable ({type(value).__name__}): {e}. "
            "Convert to a dict / list / str / number / bool / None before "
            "checkpointing (e.g. dataclasses.asdict, pydantic model_dump, "
            "datetime.isoformat())."
        ) from e


def _serialize_context(data: Dict[str, Any]) -> Dict[str, str]:
    """Serialize every value in ``data`` with the strict JSON helper."""
    return {
        k: _json_dumps_strict(v, what=f"step result context[{k!r}]")
        for k, v in data.items()
    }


# --- Proto conversion helpers (module-level so app.py can reuse them) ---


def _retry_policy_to_proto(policy: Optional[RetryPolicy], eventpilot_pb2):
    """Convert SDK RetryPolicy → proto RetryPolicy. Returns None if policy is None."""
    if policy is None:
        return None
    proto = eventpilot_pb2.RetryPolicy(
        max_attempts=int(policy.max_attempts),
        max_elapsed_ms=int(policy.max_elapsed_ms),
        initial_interval_ms=int(policy.initial_interval_ms),
        max_interval_ms=int(policy.max_interval_ms),
        backoff_coefficient=float(policy.backoff_coefficient),
        strategy=int(policy.strategy),
        jitter_ratio=float(policy.jitter_ratio),
        retry_schedule_ms=list(policy.retry_schedule_ms),
        non_retryable_error_codes=list(policy.non_retryable_error_codes),
    )
    for code, override in policy.error_code_overrides.items():
        override_proto = _retry_policy_to_proto(override, eventpilot_pb2)
        if override_proto is not None:
            proto.error_code_overrides[code].CopyFrom(override_proto)
    return proto


def _handler_retry_policy_to_proto(handler_class, eventpilot_pb2):
    """Build the wire RetryPolicy for a handler.

    Prefers an explicit ``retry_policy=`` on ``@handler``; otherwise folds the
    legacy ``max_retries`` / ``retry_backoff_ms`` convenience fields into an
    equivalent policy. Returns None when neither is set.
    """
    explicit = getattr(handler_class, "_ep_handler_retry_policy", None)
    if explicit is not None:
        return _retry_policy_to_proto(explicit, eventpilot_pb2)
    max_retries = getattr(handler_class, "_ep_handler_max_retries", 0) or 0
    backoff_ms = getattr(handler_class, "_ep_handler_retry_backoff_ms", 0) or 0
    if max_retries == 0 and backoff_ms == 0:
        return None
    return eventpilot_pb2.RetryPolicy(
        max_attempts=int(max_retries),
        initial_interval_ms=int(backoff_ms),
    )


def _step_timeouts_to_proto(timeouts: Optional[StepTimeouts], eventpilot_pb2):
    """Convert SDK StepTimeouts → proto StepTimeouts. Returns None if None."""
    if timeouts is None:
        return None
    return eventpilot_pb2.StepTimeouts(
        schedule_to_start_ms=int(timeouts.schedule_to_start_ms),
        start_to_close_ms=int(timeouts.start_to_close_ms),
        schedule_to_close_ms=int(timeouts.schedule_to_close_ms),
        heartbeat_timeout_ms=int(timeouts.heartbeat_timeout_ms),
    )


def _failure_from_exception(err: Exception, eventpilot_pb2):
    """Translate a Python exception into the wire StepFailure shape.

    If ``err`` is a ``StepError``, its ``code`` / ``error_type`` / ``details``
    are forwarded so per-code retry overrides and classification apply.
    Non-StepError exceptions become retryable APPLICATION failures.
    """
    if isinstance(err, StepError):
        error_type = err.error_type
        if error_type == ErrorType.UNSPECIFIED:
            error_type = ErrorType.APPLICATION
        return eventpilot_pb2.StepFailure(
            error=err.message,
            non_retryable=not err.retryable,
            error_code=err.code,
            error_type=int(error_type),
            details=err.details or b"",
        )
    return eventpilot_pb2.StepFailure(
        error=str(err),
        non_retryable=False,
        error_type=int(ErrorType.APPLICATION),
    )
