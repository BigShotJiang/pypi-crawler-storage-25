"""EventPilot Python SDK public API."""

from .app import EventPilotApp
from .client import AsyncEventPilotClient, EventPilotAPIError, EventPilotClient
from .observability import MetricsRecorder, WorkflowLogAdapter, workflow_logger
from .poll import poll
from .testing import StateBuilder, TestEnv, TestResult, TestStatus, TriggerOptions, new_state
from .types import (
    BackoffStrategy,
    ChildWorkflowOptions,
    ChildWorkflowResult,
    Defer,
    DurableState,
    ErrorType,
    ReplayNonDeterminismError,
    RetryAttempt,
    RetryPolicy,
    SignalsAPI,
    StepError,
    StepResult,
    StepRetryState,
    StepTimeouts,
    TimeoutActionFail,
    TimeoutActionRetry,
    TimeoutActionSkip,
    TimeoutKind,
    WorkflowState,
    handler,
    poison_message_error,
    query,
    rate_limited_error,
    scheduled,
    signal,
    step,
)

__all__ = [
    "AsyncEventPilotClient",
    "BackoffStrategy",
    "ChildWorkflowOptions",
    "ChildWorkflowResult",
    "Defer",
    "DurableState",
    "ErrorType",
    "EventPilotAPIError",
    "EventPilotApp",
    "EventPilotClient",
    "MetricsRecorder",
    "WorkflowLogAdapter",
    "workflow_logger",
    "Publisher",
    "ReplayNonDeterminismError",
    "RetryAttempt",
    "RetryPolicy",
    "SignalsAPI",
    "StateBuilder",
    "StepError",
    "StepResult",
    "poison_message_error",
    "query",
    "rate_limited_error",
    "scheduled",
    "signal",
    "StepRetryState",
    "StepTimeouts",
    "TimeoutActionFail",
    "TimeoutActionRetry",
    "TimeoutActionSkip",
    "TimeoutKind",
    "TestEnv",
    "TestResult",
    "TestStatus",
    "TriggerOptions",
    "Worker",
    "WorkflowState",
    "handler",
    "new_state",
    "poll",
    "step",
]


def __getattr__(name: str):
    if name == "Publisher":
        from .publisher import Publisher

        return Publisher
    if name == "Worker":
        from .worker import Worker

        return Worker
    raise AttributeError(f"module 'eventpilot' has no attribute {name!r}")
