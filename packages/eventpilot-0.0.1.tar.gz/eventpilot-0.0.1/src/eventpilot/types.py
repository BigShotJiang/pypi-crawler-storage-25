"""Types for EventPilot v3 SDK."""
from dataclasses import dataclass, field
from datetime import datetime
from enum import IntEnum
from typing import Any, Callable, Dict, List, Optional, Type, TypeVar
import json
from ._protos import load_eventpilot_protos


T = TypeVar("T")


class TimeoutKind(IntEnum):
    """Classifies which timeout fired. Mirrors proto TimeoutKind."""

    UNSPECIFIED = 0
    START_TO_CLOSE = 1
    SCHEDULE_TO_CLOSE = 2
    SCHEDULE_TO_START = 3
    HEARTBEAT = 4
    WORKFLOW_RUN = 5


class BackoffStrategy(IntEnum):
    """How the next retry delay is computed. Mirrors proto BackoffStrategy."""

    UNSPECIFIED = 0  # defaults to EXPONENTIAL on the server
    EXPONENTIAL = 1
    LINEAR = 2
    FIBONACCI = 3
    FIXED = 4


class ErrorType(IntEnum):
    """Classifies a step failure for retry decisioning. Mirrors proto ErrorType."""

    UNSPECIFIED = 0
    APPLICATION = 1
    TIMEOUT = 2
    CANCELLED = 3
    TERMINATED = 4
    RATE_LIMITED = 5
    CIRCUIT_OPEN = 6
    VALIDATION = 7


@dataclass
class RetryPolicy:
    """Per-step retry configuration. Mirrors proto RetryPolicy field-for-field."""

    max_attempts: int = 0  # 0 = unlimited, bounded by max_elapsed_ms
    max_elapsed_ms: int = 0  # wall-clock cap across all attempts
    initial_interval_ms: int = 0  # default 100 on server
    max_interval_ms: int = 0  # cap on a single computed delay
    backoff_coefficient: float = 0.0  # default 2.0 on server
    strategy: BackoffStrategy = BackoffStrategy.UNSPECIFIED
    jitter_ratio: float = 0.0  # [0.0, 1.0], default 0.2 on server
    retry_schedule_ms: List[int] = field(default_factory=list)
    non_retryable_error_codes: List[str] = field(default_factory=list)
    error_code_overrides: Dict[str, "RetryPolicy"] = field(default_factory=dict)


@dataclass
class StepTimeouts:
    """Per-step timeouts. Mirrors proto StepTimeouts. All values in ms; 0 disables."""

    schedule_to_start_ms: int = 0
    start_to_close_ms: int = 0
    schedule_to_close_ms: int = 0
    heartbeat_timeout_ms: int = 0


@dataclass
class TimeoutActionFail:
    """Tell the orchestrator to fail the workflow with the given error."""
    error: str = ""


@dataclass
class TimeoutActionRetry:
    """Tell the orchestrator to retry the timed-out step after a delay."""
    delay_ms: int = 1000


@dataclass
class TimeoutActionSkip:
    """Tell the orchestrator to skip to the next (or a specific) step."""
    skip_to_step: int = 0  # 0 = next step
    result: Any = None  # optional result to record for the skipped step


# Union type for on_timeout callback return values.
OnTimeoutAction = Any  # TimeoutActionFail | TimeoutActionRetry | TimeoutActionSkip


@dataclass
class StepRetryState:
    """Read-only snapshot of a step's retry budget. Returned by the orchestrator."""

    attempt: int = 0
    first_attempted_at: Optional[datetime] = None
    last_attempted_at: Optional[datetime] = None
    next_retry_at: Optional[datetime] = None
    last_error_code: str = ""
    last_error_message: str = ""
    last_error_type: ErrorType = ErrorType.UNSPECIFIED
    total_elapsed_ms: int = 0


@dataclass
class RetryAttempt:
    """Structured audit record for a single attempt at a step."""

    step_index: int = 0
    attempt: int = 0
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    error_type: ErrorType = ErrorType.UNSPECIFIED
    error_code: str = ""
    error_message: str = ""
    next_backoff_ms: int = 0
    backoff_reason: str = ""


@dataclass
class WorkflowError:
    """Represents an error that occurred during workflow execution."""
    step_index: int
    error: str
    timestamp: datetime
    attempt: int


@dataclass
class StepResult:
    """Result returned by a step execution function."""
    data: Dict[str, Any] = field(default_factory=dict)
    result: Any = None
    side_effect_key: str = ""
    side_effect_result: Any = None
    defer_ms: Optional[int] = None
    defer_deadline_ms: Optional[int] = None


@dataclass
class WorkflowState:
    """Current state of a workflow.

    Field semantics after Stage 2 (issue #23):

    - ``workflow_id`` is the **grouping / trace id** shared by every handler
      execution in a single user-initiated event chain. The root handler's
      ``workflow_id`` equals its own ``handler_execution_id``; descendants
      inherit it via envelope headers.
    - ``handler_execution_id`` is the per-handler-execution primary key.
      Always unique.
    - ``parent_handler_execution_id`` is the direct parent handler run that
      spawned this one (empty for root executions).
    - ``parent_workflow_id`` is the parent chain's ``workflow_id`` when this
      run belongs to a child workflow started via
      ``publisher.publish(..., new_workflow=True)``. Empty for runs that
      inherit the emitter's chain.
    """
    workflow_id: str
    workflow_type: str
    handler_version: str
    version: int
    status: str
    current_handler: str
    current_step: int
    step_results: Dict[int, StepResult] = field(default_factory=dict)
    context: Dict[str, Any] = field(default_factory=dict)
    payload_refs: Dict[str, str] = field(default_factory=dict)
    error_history: List[WorkflowError] = field(default_factory=list)
    retry_count: int = 0
    resume_at: Optional[datetime] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    total_steps: int = 0
    trigger_event_id: str = ""
    trigger_payload: bytes = b""
    idempotency_keys: Dict[str, bool] = field(default_factory=dict)
    attempt_log: List["RetryAttempt"] = field(default_factory=list)
    step_retries: Dict[int, "StepRetryState"] = field(default_factory=dict)
    last_progress: Optional[bytes] = None
    # Per-handler-execution primary key. Always unique. When unset, falls back
    # to ``workflow_id`` to preserve legacy behaviour for tests that construct
    # a WorkflowState directly without wiring both IDs.
    handler_execution_id: str = ""
    # Direct parent handler run that spawned this one. Empty for root.
    parent_handler_execution_id: str = ""
    # Parent chain's workflow_id when this run belongs to a child workflow
    # started via publish(..., new_workflow=True). Empty for runs that inherit
    # the emitter's chain.
    parent_workflow_id: str = ""

    # Injected by worker for Emit support
    _grpc_addr: str = ""

    # Injected by worker for class-based handler execution
    _checkpoint_fn: Optional[Callable] = field(default=None, repr=False)
    _heartbeat_fn: Optional[Callable] = field(default=None, repr=False)
    _metrics_recorder: Optional[Any] = field(default=None, repr=False)
    _next_step_index: int = field(default=0, repr=False)
    # Durable typed state registry. Keyed by "__ep_state_<ClassName>".
    _states: Dict[str, "DurableState"] = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        # Legacy callers still construct WorkflowState with only ``workflow_id``
        # set; treat that as the PK too so tests and shim paths keep working.
        if not self.handler_execution_id:
            self.handler_execution_id = self.workflow_id

    def has_executed_side_effect(self, key: str) -> bool:
        """Check if a side effect with the given idempotency key was already executed.

        Use this before making external API calls to avoid duplicate
        charges/actions on retry.
        """
        return self.idempotency_keys.get(key, False)

    @property
    def attempt(self) -> int:
        """Current step retry attempt (0-indexed)."""
        sr = self.step_retries.get(self.current_step)
        if sr is not None:
            return sr.attempt
        return 0

    @property
    def last_error(self) -> Optional[str]:
        """Error message from the last failed attempt of the current step."""
        sr = self.step_retries.get(self.current_step)
        if sr is not None:
            return sr.last_error_message
        return None

    # --- Context Helper Methods ---

    def get_string(self, key: str, default: str = "") -> str:
        """Get a string value from the workflow context."""
        v = self.context.get(key)
        if v is None or not isinstance(v, str):
            return default
        return v

    def get_int(self, key: str, default: int = 0) -> int:
        """Get an int value from the workflow context. Handles float→int conversion."""
        v = self.context.get(key)
        if v is None:
            return default
        if isinstance(v, int) and not isinstance(v, bool):
            return v
        if isinstance(v, float):
            return int(v)
        return default

    def get_float(self, key: str, default: float = 0.0) -> float:
        """Get a float value from the workflow context."""
        v = self.context.get(key)
        if v is None:
            return default
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return float(v)
        return default

    def get_bool(self, key: str, default: bool = False) -> bool:
        """Get a bool value from the workflow context."""
        v = self.context.get(key)
        if v is None or not isinstance(v, bool):
            return default
        return v

    def get_string_list(self, key: str) -> Optional[List[str]]:
        """Get a list of strings from the workflow context."""
        v = self.context.get(key)
        if v is None or not isinstance(v, list):
            return None
        if all(isinstance(item, str) for item in v):
            return v
        return None

    # --- Payload Parsing ---

    def parse_payload(self, target_type: Type[T] = None) -> Any:
        """Parse the trigger payload as JSON and optionally validate it.

        - ``target_type=None`` → returns the raw parsed JSON value.
        - ``target_type`` is a ``@dataclass`` → instantiates with the parsed dict.
        - ``target_type`` is a Pydantic ``BaseModel`` (v2) → validates and
          returns the model instance. Requires ``eventpilot[typed]``.
        """
        if not self.trigger_payload:
            raise ValueError("trigger payload is empty")
        data = json.loads(self.trigger_payload)
        if target_type is None:
            return data
        # Pydantic v2 model detection (without requiring pydantic at import time).
        model_validate = getattr(target_type, "model_validate", None)
        if callable(model_validate):
            return model_validate(data)
        if hasattr(target_type, "__dataclass_fields__"):
            return target_type(**data)
        # Fallback: try constructor with dict unpacking.
        return target_type(**data) if isinstance(data, dict) else target_type(data)

    def get_payload_map(self) -> Dict[str, Any]:
        """Parse the trigger payload as a dict."""
        data = self.parse_payload()
        if not isinstance(data, dict):
            raise ValueError("trigger payload is not a JSON object")
        return data

    # --- Emit (Publisher Injection) ---

    async def emit(self, event_name: str, payload: Any, *, new_workflow: bool = False) -> str:
        """Publish an event to EventPilot using the worker's gRPC connection.

        Default path (inherited chain): stamps envelope headers so the
        orchestrator links the published event into this workflow's chain:

        - ``workflow_id`` → this workflow's grouping id (trace-id equivalent)
        - ``parent_handler_execution_id`` → this handler execution's PK

        With ``new_workflow=True`` (child-workflow tracing): the emitted event
        starts a fresh workflow chain whose ``parent_workflow_id`` links back
        to the current chain. ``workflow_id`` is NOT stamped so the orchestrator
        generates a fresh grouping id. ``parent_handler_execution_id`` is still
        stamped for handler-level causality.

        Returns the workflow ID of the newly created workflow.
        """
        if not self._grpc_addr:
            raise RuntimeError("Emit is not available: worker gRPC address not set")

        if isinstance(payload, bytes):
            payload_bytes = payload
        else:
            payload_bytes = json.dumps(payload).encode("utf-8")

        import grpc as grpc_mod
        eventpilot_pb2, eventpilot_pb2_grpc = load_eventpilot_protos()

        headers: Dict[str, str] = {}
        if self.handler_execution_id:
            headers["parent_handler_execution_id"] = self.handler_execution_id
        if new_workflow:
            if self.workflow_id:
                headers["parent_workflow_id"] = self.workflow_id
        else:
            if self.workflow_id:
                headers["workflow_id"] = self.workflow_id

        channel = grpc_mod.aio.insecure_channel(self._grpc_addr)
        try:
            stub = eventpilot_pb2_grpc.EventPilotServiceStub(channel)
            resp = await stub.PublishEvent(eventpilot_pb2.PublishEventRequest(
                event_name=event_name,
                payload=payload_bytes,
                headers=headers,
            ))
            return resp.workflow_id
        finally:
            await channel.close()


class Defer(Exception):
    """Exception that signals the framework to re-execute this step after a delay."""

    def __init__(self, delay_ms: int):
        self.delay_ms = delay_ms
        super().__init__(f"Defer execution for {delay_ms}ms")


class StepError(Exception):
    """Exception for step errors with retry decisioning metadata.

    Mirrors Go ``sdk.StepError``. ``code`` is a domain-specific string matched
    against ``RetryPolicy.non_retryable_error_codes`` and
    ``error_code_overrides``. ``error_type`` classifies the failure for the
    orchestrator; it defaults to APPLICATION when unset. ``details`` is an
    arbitrary bytes payload (typically JSON) forwarded with the failure.
    """

    def __init__(
        self,
        message: str,
        *,
        retryable: bool = True,
        code: str = "",
        error_type: ErrorType = ErrorType.UNSPECIFIED,
        details: bytes = b"",
    ):
        self.message = message
        self.retryable = retryable
        self.code = code
        self.error_type = error_type
        self.details = details
        super().__init__(message)


def poison_message_error(code: str, message: str) -> "StepError":
    """Build a non-retryable StepError indicating the payload can never succeed.

    The orchestrator will send this directly to the DLQ without any retry
    attempts. Use this for malformed inputs, invalid schemas, or business
    rule violations that retrying cannot fix.

    Usage::

        if not validate_schema(payload):
            raise poison_message_error("E_INVALID_SCHEMA", "payload missing required field 'amount'")
    """
    return StepError(
        message,
        retryable=False,
        code=code,
        error_type=ErrorType.VALIDATION,
    )


def rate_limited_error(retry_after_ms: int, message: str = "rate limited") -> "StepError":
    """Build a StepError tagged RATE_LIMITED with an upstream-supplied Retry-After hint.

    The orchestrator reads ``details.retry_after_ms`` and prefers it over the
    policy's computed backoff. The first few rate-limit denials per step are
    "freebies" — deferrals that do not burn the attempt budget — matching
    Temporal's semantics and preventing DLQ pollution when an upstream is
    simply busy.

    Usage::

        if resp.status_code == 429:
            retry_after = int(resp.headers.get("Retry-After", "1")) * 1000
            raise rate_limited_error(retry_after, "stripe 429")
    """
    import json as _json
    payload = _json.dumps({"retry_after_ms": int(retry_after_ms)}).encode("utf-8")
    return StepError(
        message,
        retryable=True,
        error_type=ErrorType.RATE_LIMITED,
        details=payload,
    )


# ---------------------------------------------------------------------------
# Class-based handler API
# ---------------------------------------------------------------------------

def step(
    name: str,
    *,
    rate_limit_scope: str = "",
    rate_limit_rate: int = 0,
    max_concurrency: int = 0,
    max_retries: int = 0,
    retry_policy: Optional[RetryPolicy] = None,
    step_timeouts: Optional[StepTimeouts] = None,
    on_timeout: Optional[Callable] = None,
    output_type: Any = None,
):
    """Decorator that marks an async method as a handler step.

    Attaches metadata to the function but does NOT wrap it — the method remains
    directly callable for unit testing. Use self.next_step(method) from run()
    to execute it durably.

    Usage::

        @step("charge-payment", rate_limit_scope="gateway", rate_limit_rate=100)
        async def charge_payment(self, state: WorkflowState) -> StepResult:
            ...

    """
    def decorator(func):
        func._ep_step_name = name
        func._ep_rate_limit_scope = rate_limit_scope
        func._ep_rate_limit_rate = rate_limit_rate
        func._ep_max_concurrency = max_concurrency
        func._ep_max_retries = max_retries
        func._ep_retry_policy = retry_policy
        func._ep_step_timeouts = step_timeouts
        func._ep_on_timeout = on_timeout
        func._ep_output_type = output_type
        func._ep_is_step = True
        return func

    return decorator


def _find_step_method(instance, name: str):
    """Find a step method on an instance by its @step name."""
    for attr_name in type(instance).__dict__:
        attr = type(instance).__dict__[attr_name]
        if getattr(attr, '_ep_step_name', None) == name:
            return attr
    raise KeyError(f"No @step with name {name!r} found on {type(instance).__name__}")


async def _ep_next_step(self, step_or_name, *, defer_ms=None):
    """Durable step execution. Injected as next_step on handler classes by @handler.

    - If the step already ran (cached in state.context), returns immediately.
    - Otherwise executes the step method, checkpoints, caches the result.
    - defer_ms: if set, wraps the result as a deferred step.
    """
    state: WorkflowState = self._ep_state

    # Resolve to the underlying function (to read _ep_ metadata)
    if isinstance(step_or_name, str):
        func = _find_step_method(self, step_or_name)
        bound = getattr(self, func.__name__)
    else:
        # bound method passed: self.validate_order
        bound = step_or_name
        func = getattr(bound, '__func__', bound)

    step_name = getattr(func, '_ep_step_name', func.__name__)
    cache_key = f"__ep_step_{step_name}"

    # Replay: return cached result without executing
    if cache_key in state.context:
        cached = state.context[cache_key]
        return StepResult(data=cached if isinstance(cached, dict) else {})

    # Execute the step method, with optional metrics + OTel span wrapping.
    import time as _time
    from .observability import _safe_call, step_span

    recorder = state._metrics_recorder
    handler_name = state.current_handler
    workflow_id = state.workflow_id
    _safe_call(recorder, "record_step_started", handler_name, step_name, workflow_id)

    started = _time.perf_counter()
    try:
        with step_span(handler_name, step_name, workflow_id), _StepScope(state):
            result = await bound(state)
    except Defer as d:
        result = StepResult(defer_ms=d.delay_ms)
        _safe_call(
            recorder, "record_step_deferred", handler_name, step_name, workflow_id, d.delay_ms,
        )
    except StepError as e:
        _safe_call(
            recorder, "record_step_failed", handler_name, step_name, workflow_id,
            e.code, e.retryable,
        )
        raise _StepFailed(step_name, e) from None
    except Exception as e:
        _safe_call(
            recorder, "record_step_failed", handler_name, step_name, workflow_id, "", True,
        )
        raise _StepFailed(step_name, StepError(str(e), retryable=True)) from None
    else:
        duration_ms = (_time.perf_counter() - started) * 1000.0
        _safe_call(
            recorder, "record_step_completed", handler_name, step_name, workflow_id, duration_ms,
        )

    if result is None:
        result = StepResult()

    # Apply runtime defer override
    if defer_ms is not None:
        result = StepResult(
            data=result.data,
            result=result.result,
            side_effect_key=result.side_effect_key,
            side_effect_result=result.side_effect_result,
            defer_ms=defer_ms,
        )

    # Merge dirty durable state into this checkpoint's context updates.
    if result.data is None:
        result = StepResult(
            data={}, result=result.result,
            side_effect_key=result.side_effect_key,
            side_effect_result=result.side_effect_result,
            defer_ms=result.defer_ms,
            defer_deadline_ms=result.defer_deadline_ms,
        )
    _flush_dirty_states(state, result.data)

    # Checkpoint via callback injected by worker (or test env)
    if state._checkpoint_fn:
        idx = state._next_step_index
        state._next_step_index += 1
        await state._checkpoint_fn(idx, step_name, result)

    # If deferred, stop here — don't cache, run() should not continue
    if result.defer_ms is not None:
        raise _DeferSignal(result)

    # Cache and merge into context
    data = result.data or {}
    state.context.update(data)
    state.context[cache_key] = data

    return result


class _DeferSignal(Exception):
    """Internal signal raised by next_step when a step defers execution."""
    def __init__(self, result: StepResult):
        self.result = result


class _StepFailed(Exception):
    """Internal signal raised by next_step when a step fails.

    Carries the step name and original error so the caller (TestEnv / worker)
    can implement retry logic with proper metadata.
    """
    def __init__(self, step_name: str, error: Exception):
        self.step_name = step_name
        self.error = error
        self.retryable = error.retryable if isinstance(error, StepError) else True
        super().__init__(str(error))


async def _ep_sleep(self, name: str, duration_ms: int):
    """Durable sleep. Suspends the handler for the given duration (ms).

    On resume the handler replays from the beginning; cached steps are skipped.
    """
    state: WorkflowState = self._ep_state
    cache_key = f"__ep_step_{name}"
    if cache_key in state.context:
        return

    result = StepResult(data={cache_key: True}, defer_ms=duration_ms)
    if state._checkpoint_fn:
        idx = state._next_step_index
        state._next_step_index += 1
        await state._checkpoint_fn(idx, name, result)
    raise _DeferSignal(result)


async def _ep_sleep_until(self, name: str, deadline: datetime):
    """Durable sleep until an absolute UTC time."""
    state: WorkflowState = self._ep_state
    cache_key = f"__ep_step_{name}"
    if cache_key in state.context:
        return

    deadline_ms = int(deadline.timestamp() * 1000)
    result = StepResult(data={cache_key: True}, defer_deadline_ms=deadline_ms)
    if state._checkpoint_fn:
        idx = state._next_step_index
        state._next_step_index += 1
        await state._checkpoint_fn(idx, name, result)
    raise _DeferSignal(result)


async def _ep_wait_for_event(
    self,
    name: str,
    *,
    event: str,
    timeout_ms: int = 0,
    correlation_key: str = "",
):
    """Pause until a matching event arrives or timeout expires."""
    state: WorkflowState = self._ep_state
    cache_key = f"__ep_step_{name}"
    if cache_key in state.context:
        cached = state.context[cache_key]
        return cached

    result = StepResult(data={cache_key: True})
    result._wait_for_event = {
        "event": event,
        "timeout_ms": timeout_ms,
        "correlation_key": correlation_key or state.workflow_id,
    }
    if state._checkpoint_fn:
        idx = state._next_step_index
        state._next_step_index += 1
        await state._checkpoint_fn(idx, name, result)
    raise _DeferSignal(result)


async def _ep_wait_for_signal(
    self,
    name: str,
    *,
    signal: str,
    timeout_ms: int = 0,
):
    """Pause until a named signal is sent to this workflow.

    Sugar over ``wait_for_event`` that automatically uses the ``ep.signal.``
    prefix and the workflow ID as the correlation key.

    Args:
        name: Unique step name for memoisation.
        signal: The signal name (without ``ep.signal.`` prefix).
        timeout_ms: Optional timeout in milliseconds (0 = no timeout).
    """
    return await _ep_wait_for_event(
        self,
        name,
        event=f"ep.signal.{signal}",
        timeout_ms=timeout_ms,
        correlation_key=self._ep_state.workflow_id,
    )


# ---------------------------------------------------------------------------
# Signals() API — synchronous inspection of buffered signals. Mirrors Go SDK
# sdk/go/signal.go: SignalAPI{Has, Count, Peek, Consume}.
#
# Buffered signals live in state.context["__ep_signals__"] as a JSON array of
# {"name": str, "payload": Any} entries. The orchestrator hydrates this key
# when signals arrive; Consume removes an entry and checkpoints the updated
# buffer so replays observe the same ordering.
# ---------------------------------------------------------------------------

SIGNAL_BUFFER_CONTEXT_KEY = "__ep_signals__"


class SignalsAPI:
    """Inspect and consume buffered signals for the current workflow.

    Obtained from ``self.signals()`` inside a handler. Reads and consumes
    operate on the in-memory buffer hydrated by the orchestrator on resume —
    they do NOT suspend the workflow.
    """

    def __init__(self, state: "WorkflowState"):
        self._state = state

    def _load_buffer(self) -> List[Dict[str, Any]]:
        raw = self._state.context.get(SIGNAL_BUFFER_CONTEXT_KEY)
        if not raw:
            return []
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except json.JSONDecodeError:
                return []
        if not isinstance(raw, list):
            return []
        return [entry for entry in raw if isinstance(entry, dict)]

    def has(self, name: str) -> bool:
        """Report whether at least one signal with ``name`` is buffered."""
        return any(entry.get("name") == name for entry in self._load_buffer())

    def count(self, name: str) -> int:
        """Return the number of buffered signals with ``name``."""
        return sum(1 for entry in self._load_buffer() if entry.get("name") == name)

    def peek(self, name: str) -> Any:
        """Return the oldest buffered ``name`` payload without removing it.

        Returns ``None`` when no matching signal is buffered. Distinguish a
        buffered ``None`` payload from an empty buffer using ``has(name)``.
        """
        for entry in self._load_buffer():
            if entry.get("name") == name:
                return entry.get("payload")
        return None

    async def consume(self, name: str) -> Any:
        """Pop and return the oldest buffered ``name`` payload.

        Checkpoints the updated buffer so replays observe the same ordering.
        Returns ``None`` when no matching signal is buffered — call
        ``has(name)`` first if you need to disambiguate from a None payload.
        """
        buf = self._load_buffer()
        idx = -1
        for i, entry in enumerate(buf):
            if entry.get("name") == name:
                idx = i
                break
        if idx < 0:
            return None

        payload = buf[idx].get("payload")
        new_buf = buf[:idx] + buf[idx + 1:]
        self._state.context[SIGNAL_BUFFER_CONTEXT_KEY] = new_buf

        if self._state._checkpoint_fn:
            step_idx = self._state._next_step_index
            self._state._next_step_index += 1
            result = StepResult(data={SIGNAL_BUFFER_CONTEXT_KEY: new_buf})
            await self._state._checkpoint_fn(
                step_idx, f"__signal_consume_{name}", result,
            )
        return payload


def _ep_signals(self) -> SignalsAPI:
    """Return the signal inspection API for the current workflow."""
    return SignalsAPI(self._ep_state)


# ---------------------------------------------------------------------------
# Replay-divergence guards — mirrors Go's determinismPanic / guardNonDeterministic.
#
# Python cannot monkey-patch the global clock safely, so we expose the two
# primitives users need to detect drift themselves:
#   - self.is_replaying (property)  → True when the handler is re-running over
#     cached step history (state.context contains __ep_step_* keys).
#   - self.guard_nondeterministic(op)  → raises ReplayNonDeterminismError if we
#     are replaying AND not currently executing inside a step/side_effect.
#
# Step wrappers (next_step, typed_step, side_effect, etc.) increment a
# step-scope depth counter so guarded primitives called *inside* a step remain
# silent. Calls from run()'s top level during replay surface loudly.
# ---------------------------------------------------------------------------


class ReplayNonDeterminismError(Exception):
    """Raised when a non-deterministic op runs at run() top-level during replay."""


class _StepScope:
    """Context manager that increments the step-scope depth for determinism."""

    def __init__(self, state: "WorkflowState"):
        self._state = state

    def __enter__(self):
        self._state._step_depth = getattr(self._state, "_step_depth", 0) + 1
        return self

    def __exit__(self, *exc):
        self._state._step_depth = max(0, getattr(self._state, "_step_depth", 1) - 1)
        return False


def _is_replaying(state: "WorkflowState") -> bool:
    """A workflow is replaying when any __ep_step_ cache key is already in context."""
    return any(k.startswith("__ep_step_") for k in state.context.keys())


def _ep_is_replaying(self) -> bool:
    return _is_replaying(self._ep_state)


def _ep_guard_nondeterministic(self, op: str) -> None:
    """Raise ReplayNonDeterminismError if this call is unsafe on replay.

    Safe inside a @step body / side_effect(); unsafe at run() top level during
    replay. Use this to assert that non-deterministic calls (third-party
    clocks, IDs, random) only happen inside a recorded step.
    """
    state: WorkflowState = self._ep_state
    if not _is_replaying(state):
        return
    if getattr(state, "_step_depth", 0) > 0:
        return
    raise ReplayNonDeterminismError(
        f"non-deterministic call {op!r} at run() top level during replay — "
        f"wrap it in self.side_effect(...) or a @step method"
    )


# ---------------------------------------------------------------------------
# Durable typed state — mirrors Go's State[T] / GetState(). A DurableState is a
# handle whose value is hydrated from workflow context on replay. set() marks
# the handle dirty; the next step checkpoint flushes dirty state into its
# context_updates so future replays observe the new value.
# ---------------------------------------------------------------------------


class DurableState:
    """Per-workflow, per-type durable state handle.

    ``get()``/``set(v)`` operate in-memory. ``set`` marks the handle dirty, and
    the next ``next_step`` / ``typed_step`` checkpoint will include the
    serialised value in its context updates.
    """

    def __init__(self, cache_key: str, cls: Any, state: "WorkflowState"):
        self._cache_key = cache_key
        self._cls = cls
        self._state = state
        self._dirty = False
        raw = state.context.get(cache_key)
        self._value = _from_plain(cls, raw) if raw is not None else self._zero()

    def _zero(self) -> Any:
        cls = self._cls
        if cls is None:
            return None
        try:
            return cls()
        except TypeError:
            return None

    def get(self) -> Any:
        return self._value

    def set(self, value: Any) -> None:
        self._value = value
        self._dirty = True

    def is_dirty(self) -> bool:
        return self._dirty

    def flush_into(self, data: Dict[str, Any]) -> None:
        """Write dirty value into ``data`` and clear the dirty flag."""
        if not self._dirty:
            return
        data[self._cache_key] = _to_plain(self._value)
        self._state.context[self._cache_key] = data[self._cache_key]
        self._dirty = False


def _state_cache_key(cls: Any) -> str:
    name = getattr(cls, "__name__", None) or repr(cls)
    return f"__ep_state_{name}"


def _ep_get_state(self, cls: Any) -> DurableState:
    """Return a typed DurableState handle for ``cls`` within this workflow.

    One handle per type per workflow — the cache key is derived from the type
    name. Handles are rehydrated from workflow context on replay.

    Usage::

        @dataclass
        class OrderState:
            total: float = 0.0
            items_seen: int = 0

        st = self.get_state(OrderState)
        cur = st.get()
        cur.total += 10
        st.set(cur)  # flushed on next checkpoint
    """
    state: WorkflowState = self._ep_state
    key = _state_cache_key(cls)
    existing = state._states.get(key) if state._states is not None else None
    if existing is not None:
        return existing
    handle = DurableState(key, cls, state)
    if state._states is None:
        state._states = {}
    state._states[key] = handle
    return handle


def _flush_dirty_states(state: "WorkflowState", data: Dict[str, Any]) -> None:
    """Merge dirty DurableState values into ``data`` just before checkpointing."""
    if not state._states:
        return
    for handle in state._states.values():
        handle.flush_into(data)


# ---------------------------------------------------------------------------
# Typed step I/O — mirrors Go's sdk.Step[In, Out]. Callers pass a typed input
# object (pydantic BaseModel or dataclass) and receive a typed output. Inputs
# are serialised for checkpointing; outputs are cached and restored on replay.
# ---------------------------------------------------------------------------


def _to_plain(value: Any) -> Any:
    """Convert a pydantic BaseModel or dataclass to a plain dict; pass other values through."""
    if value is None:
        return None
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        return model_dump()
    import dataclasses as _dc
    if _dc.is_dataclass(value) and not isinstance(value, type):
        return _dc.asdict(value)
    return value


def _from_plain(cls: Any, data: Any) -> Any:
    """Rehydrate a plain dict/value into ``cls`` (BaseModel, dataclass, or identity)."""
    if cls is None or cls is type(None):
        return data
    model_validate = getattr(cls, "model_validate", None)
    if callable(model_validate):
        return model_validate(data)
    import dataclasses as _dc
    if isinstance(cls, type) and _dc.is_dataclass(cls):
        if isinstance(data, dict):
            return cls(**data)
        return data
    return data


def _infer_output_type(fn: Callable) -> Any:
    """Pull the return-type annotation off a step method (skip over 'StepResult')."""
    import typing as _typing
    try:
        hints = _typing.get_type_hints(fn)
    except Exception:
        return None
    ret = hints.get("return")
    if ret is None or ret is StepResult:
        return None
    return ret


async def _ep_typed_step(self, fn, input_obj: Any = None, *, name: Optional[str] = None) -> Any:
    """Run a step with a typed input; return a typed output.

    Mirrors Go's ``sdk.Step(ctx, fn, input)``. The step function's return
    annotation (pydantic BaseModel or dataclass) determines how the cached
    result is rehydrated on replay. Falls through to ``next_step``-style
    execution for checkpointing, caching, retries, and defer handling.

    Usage::

        @step("validate_order")
        async def validate_order(self, state, inp: ValidateInput) -> ValidateResult:
            ...

        result = await self.typed_step(self.validate_order, ValidateInput(...))
        # result is a ValidateResult instance
    """
    state: WorkflowState = self._ep_state
    func = getattr(fn, '__func__', fn)
    bound = fn if hasattr(fn, '__self__') else getattr(self, func.__name__)

    step_name = name or getattr(func, '_ep_step_name', func.__name__)
    cache_key = f"__ep_step_{step_name}"
    output_type = getattr(func, '_ep_output_type', None) or _infer_output_type(func)

    # Replay: return rehydrated cached result without executing.
    if cache_key in state.context:
        cached = state.context[cache_key]
        payload = cached.get("__out__") if isinstance(cached, dict) and "__out__" in cached else cached
        return _from_plain(output_type, payload)

    import time as _time
    from .observability import _safe_call, step_span

    recorder = state._metrics_recorder
    handler_name = state.current_handler
    workflow_id = state.workflow_id
    _safe_call(recorder, "record_step_started", handler_name, step_name, workflow_id)

    started = _time.perf_counter()
    try:
        with step_span(handler_name, step_name, workflow_id), _StepScope(state):
            if input_obj is None:
                out = await bound(state)
            else:
                out = await bound(state, input_obj)
    except Defer as d:
        result = StepResult(defer_ms=d.delay_ms)
        if state._checkpoint_fn:
            idx = state._next_step_index
            state._next_step_index += 1
            await state._checkpoint_fn(idx, step_name, result)
        raise _DeferSignal(result)
    except StepError as e:
        _safe_call(
            recorder, "record_step_failed", handler_name, step_name, workflow_id,
            e.code, e.retryable,
        )
        raise _StepFailed(step_name, e) from None
    except Exception as e:
        _safe_call(
            recorder, "record_step_failed", handler_name, step_name, workflow_id, "", True,
        )
        raise _StepFailed(step_name, StepError(str(e), retryable=True)) from None
    else:
        duration_ms = (_time.perf_counter() - started) * 1000.0
        _safe_call(
            recorder, "record_step_completed", handler_name, step_name, workflow_id, duration_ms,
        )

    plain_out = _to_plain(out)
    data = {"__out__": plain_out} if not isinstance(plain_out, dict) else dict(plain_out)
    _flush_dirty_states(state, data)
    result = StepResult(data=data, result=plain_out)

    if state._checkpoint_fn:
        idx = state._next_step_index
        state._next_step_index += 1
        await state._checkpoint_fn(idx, step_name, result)

    state.context.update(data)
    state.context[cache_key] = plain_out if isinstance(plain_out, dict) else {"__out__": plain_out}
    return out


@dataclass
class ChildWorkflowOptions:
    """Options for launching a child workflow."""

    event_name: str = ""
    payload: Any = None
    workflow_id: str = ""
    timeout_ms: int = 0
    timeout_reason: str = ""
    cancel_policy: str = "ABANDON"  # "ABANDON" or "CASCADE"
    idempotency_key: str = ""
    headers: Dict[str, str] = field(default_factory=dict)


@dataclass
class ChildWorkflowResult:
    """Result returned when a child workflow reaches a terminal state."""

    child_workflow_id: str = ""
    status: str = ""  # COMPLETED, FAILED, CANCELLED, TERMINATED
    result: Any = None
    error: str = ""
    error_code: str = ""
    error_type: str = ""


class _ChildWorkflowSignal(Exception):
    """Internal signal raised when a child workflow checkpoint is sent."""

    def __init__(self, step_name: str, child_workflow_data: dict):
        self.step_name = step_name
        self.child_workflow_data = child_workflow_data


async def _ep_child_workflow(
    self,
    name: str,
    *,
    event_name: str,
    payload: Any = None,
    workflow_id: str = "",
    timeout_ms: int = 0,
    timeout_reason: str = "",
    cancel_policy: str = "ABANDON",
    idempotency_key: str = "",
    headers: Optional[Dict[str, str]] = None,
) -> ChildWorkflowResult:
    """Launch a child workflow and wait for its completion.

    The parent suspends until the child reaches a terminal state.
    On resume, returns a ``ChildWorkflowResult`` with the child's status and result.

    Usage::

        result = await self.child_workflow(
            "process_order",
            event_name="orders.process",
            payload=order_data,
            timeout_ms=600000,
        )
        if result.status == "COMPLETED":
            print(result.result)
    """
    state: WorkflowState = self._ep_state
    cache_key = f"__ep_step_{name}"

    # Resume path: child completion event is in context.
    if cache_key in state.context:
        cached = state.context[cache_key]
        if isinstance(cached, dict):
            result = ChildWorkflowResult(
                child_workflow_id=cached.get("child_workflow_id", ""),
                status=cached.get("status", ""),
                result=cached.get("result"),
                error=cached.get("error", ""),
                error_code=cached.get("error_code", ""),
                error_type=cached.get("error_type", ""),
            )
            if result.status == "FAILED":
                raise StepError(result.error or "child workflow failed", retryable=False, code=result.error_code)
            return result
        return ChildWorkflowResult()

    # First execution: build payload bytes and send checkpoint.
    if isinstance(payload, bytes):
        payload_bytes = payload
    elif payload is not None:
        payload_bytes = json.dumps(payload).encode("utf-8")
    else:
        payload_bytes = b""

    cw_data = {
        "event_name": event_name,
        "payload": payload_bytes,
        "workflow_id": workflow_id,
        "wait_for_result": True,
        "timeout_ms": timeout_ms,
        "timeout_reason": timeout_reason,
        "idempotency_key": idempotency_key,
        "headers": headers or {},
        "cancel_on_parent_cancel": cancel_policy == "CASCADE",
    }

    if state._checkpoint_fn:
        idx = state._next_step_index
        state._next_step_index += 1
        await state._checkpoint_fn(idx, name, None, child_workflow=cw_data)

    raise _ChildWorkflowSignal(name, cw_data)


async def _ep_child_workflow_async(
    self,
    name: str,
    *,
    event_name: str,
    payload: Any = None,
    workflow_id: str = "",
    cancel_policy: str = "ABANDON",
    idempotency_key: str = "",
    headers: Optional[Dict[str, str]] = None,
) -> str:
    """Launch a child workflow without waiting for its completion.

    Returns the child workflow ID. The parent continues executing immediately.

    Usage::

        child_id = await self.child_workflow_async(
            "send_notification",
            event_name="notifications.send",
            payload=notif_data,
        )
    """
    state: WorkflowState = self._ep_state
    cache_key = f"__ep_step_{name}"

    # Resume path: child workflow ID is in context.
    if cache_key in state.context:
        cached = state.context[cache_key]
        if isinstance(cached, str):
            return cached
        return str(cached) if cached else ""

    # First execution.
    if isinstance(payload, bytes):
        payload_bytes = payload
    elif payload is not None:
        payload_bytes = json.dumps(payload).encode("utf-8")
    else:
        payload_bytes = b""

    cw_data = {
        "event_name": event_name,
        "payload": payload_bytes,
        "workflow_id": workflow_id,
        "wait_for_result": False,
        "timeout_ms": 0,
        "timeout_reason": "",
        "idempotency_key": idempotency_key,
        "headers": headers or {},
        "cancel_on_parent_cancel": cancel_policy == "CASCADE",
    }

    if state._checkpoint_fn:
        idx = state._next_step_index
        state._next_step_index += 1
        await state._checkpoint_fn(idx, name, None, child_workflow=cw_data)

    raise _ChildWorkflowSignal(name, cw_data)


def handler(
    name: str,
    *,
    version: str = "1.0.0",
    handler_type: str = "task",
    subscribes_to: Optional[List[str]] = None,
    max_retries: int = 5,
    retry_backoff_ms: int = 1000,
    rate_limit_scope: str = "",
    rate_limit_rate: int = 0,
    max_concurrency: int = 0,
    priority: int = 0,
    store_intermediate_steps: bool = False,
    retry_policy: Optional[RetryPolicy] = None,
    step_timeouts: Optional[StepTimeouts] = None,
    run_timeout_ms: int = 0,
    on_timeout: Optional[Callable] = None,
    min_event_version: int = 0,
    max_event_version: int = 0,
    cancel_on: Optional[List[dict]] = None,
):
    """Class decorator that registers a class as an EventPilot handler.

    The class must define an async ``run(self, state)`` method which orchestrates
    step execution via ``self.next_step()``. Each step method should be decorated
    with ``@step(...)``.

    Args:
        handler_type: ``"task"`` for point-to-point dispatch (default) or
            ``"event"`` for pub/sub fan-out.
        subscribes_to: Event names this handler subscribes to (event type only).
            When an event matching any of these names is published, a new
            independent workflow is created for this handler.

    Usage::

        @handler("order-processing", version="1.0.0", max_retries=5)
        class OrderProcessing:

            async def run(self, state: WorkflowState):
                await self.next_step(self.validate_order)
                await self.next_step(self.charge_payment)

            @step("validate-order")
            async def validate_order(self, state: WorkflowState) -> StepResult:
                ...

            @step("charge-payment")
            async def charge_payment(self, state: WorkflowState) -> StepResult:
                ...

        @handler("inventory-sync", handler_type="event",
                 subscribes_to=["order.created", "order.cancelled"])
        class InventorySync:
            async def run(self, state: WorkflowState):
                await self.next_step(self.sync_inventory)

            @step("sync-inventory")
            async def sync_inventory(self, state: WorkflowState) -> StepResult:
                ...
    """
    def decorator(cls):
        if not callable(getattr(cls, 'run', None)):
            raise TypeError(f"{cls.__name__} must define an async `run(self, state)` method")

        # Collect step metadata in class definition order. Compensation is
        # deferred pending orchestrator support; no compensation callback
        # is collected or registered on the wire.
        steps_meta = []
        has_compensation = False
        for attr_name, attr in cls.__dict__.items():
            if getattr(attr, '_ep_is_step', False):
                steps_meta.append(attr)

        cls._ep_handler_name = name
        cls._ep_handler_version = version
        cls._ep_handler_type = handler_type
        cls._ep_handler_subscribes_to = subscribes_to or []
        cls._ep_handler_max_retries = max_retries
        cls._ep_handler_retry_backoff_ms = retry_backoff_ms
        cls._ep_handler_rate_limit_scope = rate_limit_scope
        cls._ep_handler_rate_limit_rate = rate_limit_rate
        cls._ep_handler_max_concurrency = max_concurrency
        cls._ep_handler_priority = priority
        cls._ep_handler_store_intermediate_steps = store_intermediate_steps
        cls._ep_handler_retry_policy = retry_policy
        cls._ep_handler_step_timeouts = step_timeouts
        cls._ep_handler_run_timeout_ms = run_timeout_ms
        cls._ep_handler_on_timeout = on_timeout
        cls._ep_handler_min_event_version = min_event_version
        cls._ep_handler_max_event_version = max_event_version
        cls._ep_handler_cancel_on = cancel_on or []
        cls._ep_handler_has_compensation = has_compensation
        cls._ep_handler_steps_meta = steps_meta
        cls._ep_is_handler = True
        cls.next_step = _ep_next_step
        cls.sleep = _ep_sleep
        cls.sleep_until = _ep_sleep_until
        cls.wait_for_event = _ep_wait_for_event
        cls.wait_for_signal = _ep_wait_for_signal
        cls.signals = _ep_signals
        cls.typed_step = _ep_typed_step
        cls.get_state = _ep_get_state
        cls.is_replaying = property(_ep_is_replaying)
        cls.guard_nondeterministic = _ep_guard_nondeterministic
        cls.child_workflow = _ep_child_workflow
        cls.child_workflow_async = _ep_child_workflow_async
        cls.side_effect = _ep_side_effect
        cls.now = _ep_now
        cls.random = _ep_random
        cls.get_version = _ep_get_version
        cls.heartbeat = _ep_heartbeat

        # Collect @query and @signal handlers into class-level registries.
        queries: Dict[str, Callable] = {}
        signals: Dict[str, Callable] = {}
        schedules: List[Dict[str, Any]] = list(getattr(cls, "_ep_handler_schedules", []))
        for attr_name, attr in cls.__dict__.items():
            if getattr(attr, "_ep_is_query", False):
                queries[attr._ep_query_name] = attr
            if getattr(attr, "_ep_is_signal", False):
                signals[attr._ep_signal_name] = attr
        cls._ep_handler_queries = queries
        cls._ep_handler_signals = signals
        cls._ep_handler_schedules = schedules

        return cls

    return decorator


# ---------------------------------------------------------------------------
# Query handler decorator — forward-compatible scaffolding.
# Backend dispatch for queries is not yet implemented; the decorator records
# metadata so handlers can declare queries today and have them wired up
# transparently when the orchestrator gains query support.
# ---------------------------------------------------------------------------


def query(name: str):
    """Mark an async method as a workflow query handler.

    Queries are read-only introspection calls. They must not mutate state
    and should return JSON-serialisable values. The orchestrator will
    dispatch ``Publisher.query(workflow_id, name)`` to the running handler
    instance once backend support lands.
    """

    def decorator(func):
        func._ep_is_query = True
        func._ep_query_name = name
        return func

    return decorator


# ---------------------------------------------------------------------------
# Signal handler decorator — declarative alternative to wait_for_signal.
# The orchestrator delivers signals today as ``ep.signal.*`` events; a future
# revision may dispatch them directly. The decorator records metadata so both
# modes can coexist without user code changes.
# ---------------------------------------------------------------------------


def signal(name: str, *, model: Optional[type] = None):
    """Mark an async method as a named signal handler.

    ``name`` is the signal identifier (without the ``ep.signal.`` prefix).
    ``model`` is an optional Pydantic BaseModel class used to validate the
    signal payload before the method is invoked.

    Handler methods receive ``(self, state, payload)``. Until the backend
    dispatches signals directly, use ``await self.wait_for_signal(name)``
    inside ``run()`` — the decorator metadata is still captured so future
    orchestrator dispatch will route to the declared method automatically.
    """

    def decorator(func):
        func._ep_is_signal = True
        func._ep_signal_name = name
        func._ep_signal_model = model
        return func

    return decorator


# ---------------------------------------------------------------------------
# @scheduled — declare cron/interval schedules on a handler class.
# On worker startup the schedule is registered via the HTTP API, so the same
# handler code can declare its own firing cadence.
# ---------------------------------------------------------------------------


def scheduled(
    *,
    cron: str = "",
    interval_sec: int = 0,
    name: str = "",
    payload: Optional[Dict[str, Any]] = None,
    timezone: str = "UTC",
    enabled: bool = True,
    jitter_sec: int = 0,
    overlap_policy: str = "allow",
):
    """Class decorator that registers a schedule with the orchestrator.

    Either ``cron`` or ``interval_sec`` must be provided. The schedule
    targets the handler's event name (``_ep_handler_name``). Schedules are
    pushed to the server when ``Worker.start()`` is called.

    Usage::

        @scheduled(cron="0 */6 * * *")
        @handler("nightly-report")
        class NightlyReport:
            async def run(self, state): ...
    """

    if not cron and interval_sec <= 0:
        raise ValueError("@scheduled requires either cron= or interval_sec=")

    def decorator(cls):
        entry = {
            "name": name or cls._ep_handler_name + "-schedule",
            "cron": cron,
            "interval_sec": interval_sec,
            "payload": payload,
            "timezone": timezone,
            "enabled": enabled,
            "jitter_sec": jitter_sec,
            "overlap_policy": overlap_policy,
        }
        existing = list(getattr(cls, "_ep_handler_schedules", []))
        existing.append(entry)
        cls._ep_handler_schedules = existing
        return cls

    return decorator


# ---------------------------------------------------------------------------
# Deterministic helpers — bound onto handler instances as ``self.*``.
#
# Every value these return is memoised into ``state.context`` so replay
# produces the same result byte-for-byte. Use these instead of ``time.time()``
# / ``random.*`` / bare IO calls so retries don't diverge from the original run.
# ---------------------------------------------------------------------------


async def _ep_side_effect(
    self, key: str, fn: Callable[[], Any]
):
    """Execute ``fn`` at most once per workflow, memoising via ``key``.

    The first call in a workflow runs ``fn`` (which may be sync or async),
    JSON-serialises the return value, checkpoints it, and caches under
    ``__ep_side_effect_<key>`` in ``state.context``. Subsequent replays
    return the cached value without invoking ``fn``.
    """
    import asyncio as _asyncio
    state: WorkflowState = self._ep_state
    cache_key = f"__ep_side_effect_{key}"
    if cache_key in state.context:
        return state.context[cache_key]

    with _StepScope(state):
        value = fn()
        if _asyncio.iscoroutine(value):
            value = await value

    result = StepResult(data={cache_key: value}, side_effect_key=key, side_effect_result=value)
    if state._checkpoint_fn:
        idx = state._next_step_index
        state._next_step_index += 1
        await state._checkpoint_fn(idx, f"side_effect:{key}", result)

    state.context[cache_key] = value
    return value


async def _ep_now(self) -> float:
    """Return a deterministic UTC timestamp (seconds since epoch).

    Memoises the first observed value into workflow context so replays
    return the same instant.
    """
    import time as _time
    return await _ep_side_effect(self, "now", _time.time)


async def _ep_random(self) -> float:
    """Return a deterministic random float in [0, 1), memoised per workflow."""
    import random as _random
    return await _ep_side_effect(self, "random", _random.random)


async def _ep_get_version(self, change_id: str, *, default: int = 1) -> int:
    """Temporal-style patched versioning for evolving workflow code safely.

    On first execution the version is recorded into workflow context; on
    replay the recorded version is returned, so workflows that started
    before a code change continue on the old branch while new workflows
    take the new branch.

    Usage::

        if await self.get_version("add-fraud-check", default=1) >= 2:
            await self.next_step(self.fraud_check)
    """
    state: WorkflowState = self._ep_state
    cache_key = f"__ep_version_{change_id}"
    if cache_key in state.context:
        v = state.context[cache_key]
        try:
            return int(v)
        except (TypeError, ValueError):
            return default

    result = StepResult(data={cache_key: int(default)})
    if state._checkpoint_fn:
        idx = state._next_step_index
        state._next_step_index += 1
        await state._checkpoint_fn(idx, f"version:{change_id}", result)
    state.context[cache_key] = int(default)
    return int(default)


async def _ep_heartbeat(self, progress: Any = None) -> None:
    """Emit a ``StepHeartbeat`` for the currently-executing step.

    Sent as a side-channel message (not a checkpoint) to the orchestrator;
    lets long-running steps prove liveness before the heartbeat timeout
    fires and records opaque progress for resumable retries.

    ``progress`` may be any JSON-serialisable value (or bytes). Silently
    no-ops if the worker hasn't wired a heartbeat callback (e.g. in
    TestEnv).
    """
    state: WorkflowState = self._ep_state
    if state._heartbeat_fn is None:
        return
    if isinstance(progress, bytes):
        payload = progress
    elif progress is None:
        payload = b""
    else:
        payload = json.dumps(progress).encode("utf-8")
    step_index = max(0, state._next_step_index)
    await state._heartbeat_fn(step_index, payload)
