"""Info commands for MetaV CLI."""

import click
import json
import os

from ..utils.env import (
    METAV_AUTHKEY_ENV,
    METAV_BASE_URL_ENV,
    get_env_display_value,
    get_metav_base_url,
)
from ..utils.metav_backend import get_backend, MetaVError
from .session import get_session, SESSION_FILE


@click.group(name="info")
def info_group():
    """Information and configuration commands."""
    pass


@info_group.command(name="user")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def info_user(output_json: bool):
    """Get current user information."""
    session = get_session()
    backend = get_backend(base_url=session.base_url, authkey=session.authkey)
    try:
        user = backend.get_current_user()
        if output_json:
            click.echo(json.dumps(user, ensure_ascii=False, indent=2))
        else:
            click.echo(f"User: {user.get('username', 'unknown')}")
            click.echo(f"ID: {user.get('id', '')}")
            if user.get("email"):
                click.echo(f"Email: {user['email']}")
    except MetaVError as e:
        click.echo(f"[ERROR] Error: {e}", err=True)
        raise SystemExit(1)


@info_group.command(name="config")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def info_config(output_json: bool):
    """Show current configuration."""
    session = get_session()
    config = {
        "base_url": session.base_url or get_metav_base_url(),
        "authkey_set": bool(session.authkey),
        "token_set": bool(session.token),
        "session_file": SESSION_FILE,
        "default_app_id": session.default_app_id,
        "default_page_id": session.default_page_id,
    }
    if output_json:
        click.echo(json.dumps(config, ensure_ascii=False, indent=2))
    else:
        click.echo(f"Base URL: {config['base_url']}")
        click.echo(f"Authkey set: {config['authkey_set']}")
        click.echo(f"Token set: {config['token_set']}")
        click.echo(f"Session file: {config['session_file']}")
        if config["default_app_id"]:
            click.echo(f"Default app: {config['default_app_id']}")
        if config["default_page_id"]:
            click.echo(f"Default page: {config['default_page_id']}")


@info_group.command(name="session")
def info_session():
    """Show session file path and contents."""
    click.echo(f"Session file: {SESSION_FILE}")
    if os.path.exists(SESSION_FILE):
        with open(SESSION_FILE, "r", encoding="utf-8") as f:
            content = f.read()
        click.echo("\nContents:")
        click.echo(content)
    else:
        click.echo("No session file found.")


@info_group.command(name="env")
def info_env():
    """Show relevant environment variables."""
    env_vars = [
        (METAV_BASE_URL_ENV, get_env_display_value(METAV_BASE_URL_ENV)),
        (METAV_AUTHKEY_ENV, "***" if get_env_display_value(METAV_AUTHKEY_ENV) else ""),
    ]
    click.echo("Environment variables:")
    for name, value in env_vars:
        if value:
            click.echo(f"  {name}={value}")
        else:
            click.echo(f"  {name}= (not set)")
