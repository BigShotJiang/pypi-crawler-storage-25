from __future__ import annotations

import asyncio
from datetime import datetime, timezone

from ..database import _SessionLocal
from ..models import RunNode, Workflow, WorkflowRun, WorkflowStatus
from ._context import _active_node_slot, _active_run_ctx, _running_tasks
from ._execution import _RunExecState, _execute_fn_task
from ._serialization import (
    _build_children_map,
    _json_safe,
    _run_detail,
    _run_summary,
    _serialize_db_node,
)

_drain_tasks: dict[str, asyncio.Task] = {}
_drain_events: dict[str, asyncio.Event] = {}


def _get_drain_event(name: str) -> asyncio.Event:
    if name not in _drain_events:
        _drain_events[name] = asyncio.Event()
    return _drain_events[name]


def _notify_drain(name: str) -> None:
    event = _drain_events.get(name)
    if event is not None:
        event.set()


def _ensure_drain_task(name: str, fn) -> None:
    task = _drain_tasks.get(name)
    if task is None or task.done():
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        _drain_tasks[name] = loop.create_task(
            _drain_loop(name, fn), name=f"gtm_drain_{name}"
        )


async def _drain_loop(name: str, fn) -> None:
    """Drain pending runs for *name*, respecting the concurrency limit.

    On each wake-up, fires off all newly-available slots in parallel.
    """
    from sqlalchemy import func as _func
    from sqlmodel import select

    event = _get_drain_event(name)
    while True:
        await event.wait()
        event.clear()
        if _SessionLocal is None:
            continue
        async with _SessionLocal() as session:
            cfg = (
                await session.exec(select(Workflow).where(Workflow.name == name))
            ).first()

            if cfg is None:
                continue

            if cfg.max_concurrent_runs is not None and cfg.max_concurrent_runs > 0:
                running_count: int = (
                    await session.execute(
                        select(_func.count(WorkflowRun.id)).where(
                            WorkflowRun.workflow_id == cfg.id,
                            WorkflowRun.status == WorkflowStatus.running,
                            WorkflowRun.parent_id == None,  # noqa: E711
                        )
                    )
                ).scalar_one()
                free_slots = max(0, cfg.max_concurrent_runs - running_count)
            else:
                free_slots = None

            if free_slots == 0:
                continue

            q = (
                select(WorkflowRun)
                .join(Workflow, WorkflowRun.workflow_id == Workflow.id)
                .where(
                    Workflow.name == name, WorkflowRun.status == WorkflowStatus.pending
                )
                .order_by(WorkflowRun.created_at)
            )
            if free_slots is not None:
                q = q.limit(free_slots)

            pending_list = list((await session.exec(q)).all())

        if not pending_list:
            continue

        for run in pending_list:
            asyncio.create_task(
                _execute_existing_run(fn, run.id, name),
                name=f"gtm_run_{name}_{run.id}",
            )


async def _execute_existing_run(fn, run_id: int, workflow_name: str) -> None:
    """Transition a pending run to running and execute it.

    Called by the drain loop. Calls _notify_drain when done so the drain loop
    picks up the next pending run.
    """
    from sqlalchemy import func as _func
    from sqlmodel import select

    from ..broadcast import manager

    if _SessionLocal is None:
        return

    async with _SessionLocal() as session:
        run = await session.get(WorkflowRun, run_id)
        if run is None or run.status != WorkflowStatus.pending:
            _notify_drain(workflow_name)
            return

        cfg = (
            await session.exec(select(Workflow).where(Workflow.id == run.workflow_id))
        ).first()

        if (
            cfg is not None
            and cfg.max_concurrent_runs is not None
            and cfg.max_concurrent_runs > 0
        ):
            running_count: int = (
                await session.execute(
                    select(_func.count(WorkflowRun.id)).where(
                        WorkflowRun.workflow_id == cfg.id,
                        WorkflowRun.status == WorkflowStatus.running,
                        WorkflowRun.parent_id == None,  # noqa: E711
                    )
                )
            ).scalar_one()
            if running_count >= cfg.max_concurrent_runs:
                return

        inputs = (run.data or {}).get("inputs", {})
        run.status = WorkflowStatus.running
        run.started_at = datetime.now(timezone.utc)
        session.add(run)
        await session.commit()
        await session.refresh(run)

        await manager.broadcast(
            "workflow_list",
            {"type": "run_updated", "data": _run_summary(run, workflow_name)},
        )

        ctx: dict = {
            "plan": [],
            "logs": [],
            "run_id": run.id,
            "_executed_names": set(),
            "_row_history": {},
            "_run_meta": {
                "id": run.id,
                "name": workflow_name,
                "triggeredBy": (
                    run.triggered_by.value
                    if hasattr(run.triggered_by, "value")
                    else run.triggered_by
                ),
                "triggerContext": (run.data or {}).get("trigger_context", {}),
                "inputs": inputs,
                "outputs": {},
                "startedAt": run.started_at.isoformat() if run.started_at else None,
                "finishedAt": None,
                "createdAt": run.created_at.isoformat(),
                "parentId": run.parent_id,
                "children": [],
            },
        }
        ctx_token = _active_run_ctx.set(ctx)
        slot_token = _active_node_slot.set(None)
        timeout = cfg.timeout_seconds if cfg else None
        coro = fn(inputs)
        fn_task = asyncio.create_task(
            asyncio.wait_for(coro, timeout=timeout) if timeout else coro
        )
        _running_tasks[run.id] = fn_task
        state = _RunExecState(
            run=run,
            inputs=inputs,
            name=workflow_name,
            ctx=ctx,
            ctx_token=ctx_token,
            slot_token=slot_token,
        )
        _, was_cancelled, failure_exc = await _execute_fn_task(fn_task, state)

        if not was_cancelled:
            run.finished_at = datetime.now(timezone.utc)
            session.add(run)
            # Insert pending nodes for planned-but-not-executed names.
            executed_names = ctx.get("_executed_names", set())
            for name in ctx.get("plan", []):
                if name not in executed_names:
                    node = RunNode(
                        run_id=run.id,
                        parent_node_id=None,
                        name=name,
                        status=WorkflowStatus.pending,
                        duration_ms=0,
                    )
                    session.add(node)
            await session.commit()
            # Reload nodes for the final broadcast.
            from sqlmodel import select as _select

            db_nodes = list(
                (
                    await session.exec(
                        _select(RunNode)
                        .where(RunNode.run_id == run.id)
                        .order_by(RunNode.id)
                    )
                ).all()
            )
            root_nodes = [n for n in db_nodes if n.parent_node_id is None]
            _cm = _build_children_map(db_nodes)
            db_actions = [_serialize_db_node(n, _cm) for n in root_nodes]
            await manager.broadcast(
                "workflow_list",
                {"type": "run_updated", "data": _run_summary(run, workflow_name)},
            )
            await manager.broadcast(
                f"workflow_detail:{run.id}",
                {
                    "type": "run_updated",
                    "data": _run_detail(run, workflow_name, db_actions),
                },
            )

    _notify_drain(workflow_name)


async def _resume_existing_run(
    fn,
    run_id: int,
    workflow_name: str,
    restart_on_failure_check=None,
) -> None:
    """Resume a workflow run that was mid-execution when the server crashed.

    Re-executes the workflow function with resume context so that already-completed
    nodes are skipped (returning stored outputs) and interrupted nodes are either
    validated via *restart_on_failure_check* or re-run from scratch.
    """
    from sqlmodel import select

    if _SessionLocal is None:
        return

    from ..broadcast import manager

    # ── Phase 1: load run + existing nodes, check workflow-level guard ─────────
    async with _SessionLocal() as session:
        run = await session.get(WorkflowRun, run_id)
        if run is None or run.status != WorkflowStatus.running:
            _notify_drain(workflow_name)
            return

        cfg = (
            await session.exec(select(Workflow).where(Workflow.id == run.workflow_id))
        ).first()

        inputs = (run.data or {}).get("inputs", {})

        # Workflow-level restart_on_failure_check: did the workflow actually finish?
        if restart_on_failure_check is not None:
            check_result = await restart_on_failure_check(inputs)
            if check_result is not None:
                run.status = WorkflowStatus.success
                run.finished_at = datetime.now(timezone.utc)
                run.data = {**run.data, "outputs": _json_safe(check_result)}
                session.add(run)
                await session.commit()
                await manager.broadcast(
                    "workflow_list",
                    {"type": "run_updated", "data": _run_summary(run, workflow_name)},
                )
                _notify_drain(workflow_name)
                return

        # Load all nodes without the heavy data JSONB column.
        from sqlalchemy.orm import defer as _defer

        all_nodes = list(
            (
                await session.execute(
                    select(RunNode)
                    .where(RunNode.run_id == run_id)
                    .options(_defer(RunNode.data))
                    .order_by(RunNode.id)
                )
            ).scalars().all()
        )
        # Batch-load data only for completed nodes (outputs needed to replay them).
        success_ids = [n.id for n in all_nodes if n.status == WorkflowStatus.success]
        success_data: dict[int, dict] = {}
        if success_ids:
            success_data = {
                row.id: row.data
                for row in (
                    await session.execute(
                        select(RunNode.id, RunNode.data).where(
                            RunNode.id.in_(success_ids)
                        )
                    )
                ).all()
            }
        # Refresh run so its attributes survive session close without expiry.
        await session.refresh(run)
        # Expunge nodes before close to prevent autoflush of modified attributes.
        for n in all_nodes:
            session.expunge(n)

    # Patch data onto nodes after session close.
    for node in all_nodes:
        node.data = success_data.get(node.id) or {}

    # Build per-parent queues used by the node wrapper to replay history.
    by_parent: dict = {}
    for node in all_nodes:
        by_parent.setdefault(node.parent_node_id, []).append(node)

    # ── Build execution context (preserving original started_at) ──────────────
    trigger_type_val = (
        run.triggered_by.value
        if hasattr(run.triggered_by, "value")
        else run.triggered_by
    )
    ctx: dict = {
        "plan": [],
        "logs": list((run.data or {}).get("logs", [])),
        "run_id": run.id,
        "_executed_names": set(),
        "_row_history": {},
        "_run_meta": {
            "id": run.id,
            "name": workflow_name,
            "triggeredBy": trigger_type_val,
            "triggerContext": (run.data or {}).get("trigger_context", {}),
            "inputs": inputs,
            "outputs": {},
            "startedAt": run.started_at.isoformat() if run.started_at else None,
            "finishedAt": None,
            "createdAt": run.created_at.isoformat(),
            "parentId": run.parent_id,
            "children": [],
        },
        "_is_resume": True,
        "_resumed_by_parent": by_parent,
    }

    await manager.broadcast(
        "workflow_list",
        {"type": "run_updated", "data": _run_summary(run, workflow_name)},
    )

    ctx_token = _active_run_ctx.set(ctx)
    slot_token = _active_node_slot.set(None)
    timeout = cfg.timeout_seconds if cfg else None
    coro = fn(inputs)
    fn_task = asyncio.create_task(
        asyncio.wait_for(coro, timeout=timeout) if timeout else coro
    )
    _running_tasks[run.id] = fn_task
    state = _RunExecState(
        run=run,
        inputs=inputs,
        name=workflow_name,
        ctx=ctx,
        ctx_token=ctx_token,
        slot_token=slot_token,
    )
    _, was_cancelled, _ = await _execute_fn_task(fn_task, state)

    # ── Phase 2: persist final state ──────────────────────────────────────────
    if not was_cancelled:
        run.finished_at = datetime.now(timezone.utc)
        db_nodes: list = []
        async with _SessionLocal() as session:
            await session.merge(run)
            # Add pending nodes for planned-but-not-executed names.
            executed_names = ctx.get("_executed_names", set())
            for name in ctx.get("plan", []):
                if name not in executed_names:
                    node = RunNode(
                        run_id=run.id,
                        parent_node_id=None,
                        name=name,
                        status=WorkflowStatus.pending,
                        duration_ms=0,
                    )
                    session.add(node)
            await session.commit()
            db_nodes = list(
                (
                    await session.exec(
                        select(RunNode)
                        .where(RunNode.run_id == run.id)
                        .order_by(RunNode.id)
                    )
                ).all()
            )
        root_nodes = [n for n in db_nodes if n.parent_node_id is None]
        _cm = _build_children_map(db_nodes)
        db_actions = [_serialize_db_node(n, _cm) for n in root_nodes]
        await manager.broadcast(
            "workflow_list",
            {"type": "run_updated", "data": _run_summary(run, workflow_name)},
        )
        await manager.broadcast(
            f"workflow_detail:{run.id}",
            {
                "type": "run_updated",
                "data": _run_detail(run, workflow_name, db_actions),
            },
        )

    _notify_drain(workflow_name)
