from __future__ import annotations

import asyncio
import dataclasses
import functools
import traceback
from datetime import datetime, timezone
from typing import Callable

from ._context import _active_node_logs, _active_node_slot, _active_run_ctx
from ._persistence import (
    _cancel_running_descendants,
    _reset_node_for_rerun,
    broadcast_run_nodes,
    insert_run_node,
    update_run_node,
)
from ..models import WorkflowStatus
from ..types import NodeFn
from ..db_store import flush_single_row_history


@dataclasses.dataclass
class DbActionRecord:
    inputs: dict
    outputs: dict
    duration_ms: int


def log(message: str, *, type: str = "info", json: bool = False) -> None:
    """Append a structured log entry to the active log buffer.

    When inside a node, writes to the node's log buffer. When inside a workflow
    but outside any node, writes to the run's top-level logs. Silently dropped
    when called outside a workflow.
    """
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "body": str(message),
        "type": type,
        "json": json,
    }
    node_buf = _active_node_logs.get()
    if node_buf is not None:
        node_buf.append(entry)
        return
    run_ctx = _active_run_ctx.get()
    if run_ctx is not None:
        run_ctx["logs"].append(entry)


def plan(*names: str) -> None:
    """Declare the ordered list of nodes this workflow intends to run.

    Any planned-but-not-executed names are recorded as ``status="pending"``
    when the run finishes. Call once at the top of a workflow body.
    """
    ctx = _active_run_ctx.get()
    if ctx is not None:
        ctx["plan"] = list(names)


async def _insert_db_action_node(
    run_id: int,
    parent_db_id: int | None,
    op: str,
    table: str,
    record: "DbActionRecord",
    run_meta: dict,
    started_at: datetime,
) -> None:
    """INSERT a RunNode for a DB operation and broadcast the updated tree."""
    from ._serialization import _json_safe

    await insert_run_node(
        run_id=run_id,
        parent_db_id=parent_db_id,
        name=f"{op}: {table}",
        slug=None,
        inputs=_json_safe(record.inputs),
        started_at=started_at,
        node_status=WorkflowStatus.success,
        duration_ms=record.duration_ms,
        outputs=_json_safe(record.outputs),
    )
    await broadcast_run_nodes(run_id, run_meta)


def record_db_action(op: str, table: str, record: DbActionRecord) -> None:
    """Record a data-table operation as a child action of the current context.

    Called automatically by DbStore methods. No-op outside a workflow run.
    """
    ctx = _active_run_ctx.get()
    if ctx is None:
        return
    parent_slot = _active_node_slot.get()
    parent_db_id: int | None = (
        parent_slot["_db_id"] if parent_slot is not None else None
    )
    run_id = ctx.get("run_id")
    run_meta = ctx.get("_run_meta")
    if run_id is not None and run_meta is not None:
        # Capture started_at NOW (synchronously) so it reflects when the DB
        # operation actually ran, not when the deferred async task executes.
        started_at = datetime.now(timezone.utc)
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(
                _insert_db_action_node(
                    run_id, parent_db_id, op, table, record, run_meta, started_at
                )
            )
        except RuntimeError:
            pass


async def _broadcast_row_status(
    table_id: int,
    row_id: int,
    run_id: int,
    status: str,
) -> None:
    """Broadcast a row-level run status event on the table WebSocket channel."""
    from ..broadcast import manager

    try:
        loop = asyncio.get_running_loop()
        loop.create_task(
            manager.broadcast(
                f"table:{table_id}",
                {
                    "type": "row_run_status",
                    "runId": run_id,
                    "rowId": row_id,
                    "status": status,
                },
            )
        )
    except RuntimeError:
        pass


def make_node_wrapper(
    fn, *, tracks_row: bool = False, restart_on_failure_check=None
) -> NodeFn:
    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, slug: str | None = None):
        ctx = _active_run_ctx.get()
        if ctx is None:
            return await fn(inputs)

        # ── RESUME LOGIC ─────────────────────────────────────────────────────
        # When re-executing a workflow that was interrupted, nodes that already
        # completed must be skipped (returning stored output) and interrupted
        # nodes can be validated via restart_on_failure_check before re-running.
        if ctx.get("_is_resume"):
            resume_parent_slot = _active_node_slot.get()
            resume_parent_db_id: int | None = (
                resume_parent_slot["_db_id"] if resume_parent_slot is not None else None
            )
            resume_queue: list = ctx.get("_resumed_by_parent", {}).get(
                resume_parent_db_id, []
            )

            if resume_queue and resume_queue[0].name == fn.__name__:
                prev_node_row = resume_queue[0]

                if prev_node_row.status == WorkflowStatus.success:
                    # Already completed — skip execution, return stored output.
                    resume_queue.pop(0)
                    ctx.setdefault("_executed_names", set()).add(fn.__name__)
                    skip_slot: dict = {"_db_id": prev_node_row.id, "name": fn.__name__}
                    skip_token = _active_node_slot.set(skip_slot)
                    try:
                        return (prev_node_row.data or {}).get("outputs", {})
                    finally:
                        _active_node_slot.reset(skip_token)

                elif prev_node_row.status == WorkflowStatus.running:
                    # Node was mid-execution when server crashed.
                    if restart_on_failure_check is not None:
                        check_result = await restart_on_failure_check(inputs)
                        if check_result is not None:
                            # Node actually completed — record it and move on.
                            resume_queue.pop(0)
                            ctx.setdefault("_executed_names", set()).add(fn.__name__)
                            await update_run_node(
                                prev_node_row.id,
                                node_status=WorkflowStatus.success,
                                duration_ms=0,
                                inputs=inputs,
                                outputs=check_result,
                                logs=None,
                            )
                            checked_slot: dict = {
                                "_db_id": prev_node_row.id,
                                "name": fn.__name__,
                            }
                            checked_token = _active_node_slot.set(checked_slot)
                            try:
                                run_id_for_broadcast = ctx.get("run_id")
                                run_meta_for_broadcast = ctx.get("_run_meta")
                                if (
                                    run_id_for_broadcast is not None
                                    and run_meta_for_broadcast is not None
                                ):
                                    await broadcast_run_nodes(
                                        run_id_for_broadcast, run_meta_for_broadcast
                                    )
                                return check_result
                            finally:
                                _active_node_slot.reset(checked_token)

                    # No check or check returned None — need to re-run.
                    # Cancel any running children from the previous attempt so
                    # the re-run starts with a clean slate.
                    resume_queue.pop(0)
                    await _cancel_running_descendants(prev_node_row.id)
                    # Signal insert step to reuse the existing DB row id.
                    ctx["_reuse_node_db_id"] = prev_node_row.id
        # ── END RESUME LOGIC ─────────────────────────────────────────────────

        node_start = datetime.now(timezone.utc)
        node_logs: list[dict] = []
        logs_token = _active_node_logs.set(node_logs)

        parent_slot = _active_node_slot.get()
        parent_db_id: int | None = (
            parent_slot["_db_id"] if parent_slot is not None else None
        )

        run_id = ctx.get("run_id")
        run_meta = ctx.get("_run_meta")

        # INSERT a new row or reuse the existing row for a re-run node.
        _reuse_db_id: int | None = ctx.pop("_reuse_node_db_id", None)
        if _reuse_db_id is not None:
            db_id = _reuse_db_id
            await _reset_node_for_rerun(_reuse_db_id, node_start)
        else:
            db_id = await insert_run_node(
                run_id=run_id,
                parent_db_id=parent_db_id,
                name=fn.__name__,
                slug=slug,
                inputs=inputs,
                started_at=node_start,
            )

        # Thin slot: carries DB id so child nodes can reference it as parent.
        slot: dict = {"_db_id": db_id, "name": fn.__name__}
        slot_token = _active_node_slot.set(slot)
        ctx.setdefault("_executed_names", set()).add(fn.__name__)

        if run_id is not None and run_meta is not None:
            await broadcast_run_nodes(run_id, run_meta)

        # Resolve row-tracking context once, before execution starts.
        _row_table_id: int | None = None
        _row_id: int | None = None
        if tracks_row and run_id is not None:
            tac = (
                (ctx.get("_run_meta") or {})
                .get("triggerContext", {})
                .get("table_action_context")
            )
            if tac:
                _row_table_id = tac.get("table_id")
                _row_id = inputs.get("row_id")
                if not isinstance(_row_id, int):
                    try:
                        _row_id = int(_row_id)
                    except (TypeError, ValueError):
                        _row_id = None

        # No "processing" broadcast here — the loading badge is triggered by the
        # workflow_list "run_created" event when the workflow starts, so it appears
        # for all rows as soon as the workflow begins (not when each node runs).

        _exc: Exception | None = None
        _result = None
        final_status: WorkflowStatus = WorkflowStatus.running
        final_outputs: dict = {}
        final_logs: list | None = None

        try:
            _result = await fn(inputs)
            final_status = WorkflowStatus.success
            final_outputs = _result if isinstance(_result, dict) else {}
            final_logs = node_logs if node_logs else None
        except Exception as exc:
            _exc = exc
            final_status = WorkflowStatus.failed
            final_logs = [
                *node_logs,
                {
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "body": traceback.format_exc(),
                    "type": "error",
                    "json": False,
                },
            ]
        finally:
            duration_ms = int(
                (datetime.now(timezone.utc) - node_start).total_seconds() * 1000
            )
            _active_node_logs.reset(logs_token)
            _active_node_slot.reset(slot_token)

            if final_status != WorkflowStatus.running and run_id is not None:
                await update_run_node(
                    db_id,
                    node_status=final_status,
                    duration_ms=duration_ms,
                    inputs=inputs,
                    outputs=final_outputs,
                    logs=final_logs,
                )
                if _row_table_id is not None and _row_id is not None:
                    await flush_single_row_history(
                        ctx,
                        _row_table_id,
                        _row_id,
                        node_slot=slot,
                        failed_exc=_exc,
                    )

            if run_id is not None and run_meta is not None:
                await broadcast_run_nodes(run_id, run_meta)

        if _exc is not None:
            raise _exc
        return _result

    wrapper._gtm_fn = fn
    return wrapper
