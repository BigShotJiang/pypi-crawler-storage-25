Lite-Bootstrap
==
[![Test Coverage](https://codecov.io/gh/modern-python/lite-bootstrap/branch/main/graph/badge.svg)](https://codecov.io/gh/modern-python/lite-bootstrap)
[![Supported versions](https://img.shields.io/pypi/pyversions/lite-bootstrap.svg)](https://pypi.python.org/pypi/lite-bootstrap)
[![downloads](https://img.shields.io/pypi/dm/lite-bootstrap.svg)](https://pypistats.org/packages/lite-bootstrap)
[![GitHub stars](https://img.shields.io/github/stars/modern-python/lite-bootstrap)](https://github.com/modern-python/lite-bootstrap/stargazers)

`lite-bootstrap` assists you in creating applications with all the necessary instruments already set up.

With `lite-bootstrap`, you receive an application with lightweight built-in support for:
- `sentry`
- `prometheus`
- `opentelemetry`
- `pyroscope` - with OpenTelemetry trace-profile linking
- `structlog`
- `cors`
- `swagger` - with additional offline version support
- `health-checks`

Those instruments can be bootstrapped for:

- [LiteStar](https://lite-bootstrap.readthedocs.io/integrations/litestar)
- [FastStream](https://lite-bootstrap.readthedocs.io/integrations/faststream)
- [FastAPI](https://lite-bootstrap.readthedocs.io/integrations/fastapi)
- [services and scripts without frameworks](https://lite-bootstrap.readthedocs.io/integrations/free)
---

Usage examples:

- with LiteStar - [litestar-sqlalchemy-template](https://github.com/modern-python/litestar-sqlalchemy-template)
- with FastAPI - [fastapi-sqlalchemy-template](https://github.com/modern-python/fastapi-sqlalchemy-template)

## 📚 [Documentation](https://lite-bootstrap.readthedocs.io)

## 📦 [PyPi](https://pypi.org/project/lite-bootstrap)

## 📝 [License](LICENSE)
