# CLAUDE.md

Project context for Claude Code. Loaded automatically when working in this directory.

## What this is

**Manus MCP** — a Python 3.11+ MCP server that gives Claude Code full programmatic control over Manus.im through the official Manus API v2 (`https://api.manus.ai`). It implements all 30 documented endpoints, 3 composite tools, and a local webhook receiver with RSA-SHA256 verification.

The full Manus API documentation lives in [`ManusAPIDocs/`](ManusAPIDocs/) — that's the official mirror.

## Running and verifying

```bash
# Install (one-time)
.venv/Scripts/python.exe -m pip install -e ".[dev]"

# All unit + integration tests (no live)
.venv/Scripts/python.exe -m pytest -m "not live"

# All live e2e (requires MANUS_API_KEY in .env or env)
.venv/Scripts/python.exe -m pytest -m live

# Full run + 80% coverage gate
.venv/Scripts/python.exe -m pytest -m "not live" --cov=manus_mcp --cov-fail-under=80

# Types and lint
.venv/Scripts/python.exe -m mypy --strict manus_mcp
.venv/Scripts/python.exe -m ruff check manus_mcp tests scripts

# Smoke probe (4 read-only calls)
.venv/Scripts/python.exe scripts/smoke.py

# Full live probe (writes JSON snapshots)
.venv/Scripts/python.exe scripts/live_e2e_probe.py

# MCP integration probe via mcp.client.stdio
.venv/Scripts/python.exe scripts/mcp_integration_probe.py

# List registered tools without starting the server
.venv/Scripts/python.exe scripts/list_tools.py
```

## Test layers

| Layer | Files | Run | Dependencies |
|------|-------|--------|-------------|
| Unit | `tests/test_client.py`, `test_schemas.py`, `test_storage.py`, `test_webhook_signature.py`, `test_input_schema_stability.py`, `test_main_smoke.py`, `test_registry.py` | `pytest -m "not live"` | respx mock |
| Server (MCP wiring) | `tests/test_server.py` | `pytest -m "not live"` | AsyncMock |
| Webhook ASGI | `tests/test_webhook_app.py` | `pytest -m "not live"` | httpx ASGITransport, in-memory RSA keypair |
| Secret hygiene | `tests/test_secret_logging.py` | `pytest -m "not live"` | respx |
| Composite (mock) | `tests/test_composite.py` | `pytest -m "not live"` | respx |
| Live e2e | `tests/test_live_e2e.py` | `pytest -m live` | MANUS_API_KEY, ~5–10 credits per run |
| Live composite | `tests/test_live_composite.py` | `pytest -m live` | MANUS_API_KEY, ~5 credits per run |
| Live webhook e2e | `tests/test_live_webhook_e2e.py` | `pytest -m live` | cloudflared (Linux/CI), MANUS_API_KEY, ~3 credits |

## Release flow

See [docs/RELEASE.md](docs/RELEASE.md). It includes the checklist, the manual webhook live test via cloudflared, and the `scripts/webhook_e2e_check.py` helper.

## Architecture

```
manus_mcp/
├── __main__.py             stdio entrypoint: python -m manus_mcp
├── server.py               build_server() — assembles the MCP Server from ToolDef + ManusClient
├── config.py               pydantic-settings; accepts MANUS_API_KEY and ManusAPI (alias)
├── logger.py               stderr-only logger (stdout is owned by the MCP transport!)
├── client/
│   ├── manus_client.py     async httpx + retry + envelope parsing → ManusApiError
│   ├── rate_limiter.py     per-endpoint sliding window (exact limits from rate-limits.md)
│   ├── retry.py            exponential backoff + jitter
│   └── errors.py
├── schemas/                pydantic v2 models for all 10 resources
│   └── common.py           UnixSeconds / IntField — coerce strings to int
├── tools/
│   ├── registry.py         @manus_tool decorator + all_tools()
│   ├── tasks.py … website.py   30 direct wrappers (1 file per resource)
│   └── composite.py        manus_file_upload, manus_task_wait, manus_website_publish_and_wait
└── webhook_receiver/
    ├── signature.py        RSA-SHA256 over {ts}.{public_url}.{sha256_hex(body)}
    ├── storage.py          SQLite WAL, thread-safe event store
    ├── server.py           Starlette + uvicorn; public-key cache 1h
    ├── tools.py            manus_webhook_events_{list,get,clear}
    └── __main__.py
```

That's **36 MCP tools** total: 30 direct + 3 composite + 3 webhook.

## Principles

1. **`stdout` is reserved for MCP** — never use `print()` in production code. Logs go to stderr only via [`manus_mcp/logger.py`](manus_mcp/logger.py).
2. **Never log the API key** — the client injects it into headers but never into logs.
3. **Pydantic is the single source of truth for types**. Every endpoint has a `RequestSchema` + `ResponseSchema`. Use `extra="allow"` on response models so new API fields don't break parsing.
4. **The real API returns timestamps as strings!** Don't use bare `int` for dates — use `UnixSeconds` from [`manus_mcp/schemas/common.py`](manus_mcp/schemas/common.py).
5. **Rate limits are strict** — don't try to call `task.create` more than 10/min. The client waits locally; a server-side 429 is the fallback with `Retry-After`.
6. **No hacks or mocks** in production code. Real implementations only — otherwise raise an error with a clear message.

## Adding a new MCP tool

1. Find or add pydantic models in [`manus_mcp/schemas/<resource>.py`](manus_mcp/schemas).
2. Create a handler in [`manus_mcp/tools/<resource>.py`](manus_mcp/tools) using the `@manus_tool(...)` decorator.
3. If the resource is new, add an import to `load_all_tool_modules()` in [`manus_mcp/tools/__init__.py`](manus_mcp/tools/__init__.py).
4. Add the name to the `expected_*` sets in [`tests/test_registry.py`](tests/test_registry.py).
5. Where possible, add a unit test with `respx` (see [`tests/test_client.py`](tests/test_client.py) as a template).

Handler template:

```python
@manus_tool(
    name="manus_resource_action",
    description="What it does (used as a hint for Claude).",
    input_schema=ResourceActionRequest,
    output_schema=ResourceActionResponse,
)
async def resource_action(req: ResourceActionRequest, ctx: ToolCtx) -> ResourceActionResponse:
    return await ctx.client.call(
        "POST", "/v2/resource.action",
        json_body=req,
        response_model=ResourceActionResponse,
        rate_limit_key="resource.action",   # exact name from rate-limits.md
    )
```

## Registering with Claude Code

For project-level use, add a `.claude/settings.json` with the snippet from the README — restart Claude Code and the `manus` server will be detected.

For global registration, add to `~/.claude/settings.json`:

```json
{
  "mcpServers": {
    "manus": {
      "command": "python",
      "args": ["-m", "manus_mcp"],
      "cwd": "path/to/Manus-MCP"
    }
  }
}
```

## Webhook receiver (optional)

Run as a separate process alongside the MCP server:

```bash
# 1. Tunnel
cloudflared tunnel --url http://localhost:8787

# 2. In .env
MANUS_WEBHOOK_PUBLIC_URL=https://your-tunnel.example.com/manus/webhook

# 3. Receiver
.venv/Scripts/python.exe -m manus_mcp.webhook_receiver

# 4. From Claude Code
manus_webhook_create { "url": "https://your-tunnel.example.com/manus/webhook" }
manus_webhook_events_list { "event_type": "task_stopped" }
```

`MANUS_WEBHOOK_PUBLIC_URL` **must exactly match** the URL Manus calls — it's part of the signed payload.

## Conventions

- Python 3.11+, type hints everywhere, `from __future__ import annotations` in every file
- Pydantic v2 (`model_validate`, `model_dump`, `ConfigDict`)
- `httpx.AsyncClient` for all HTTP
- pytest + pytest-asyncio (`asyncio_mode = "auto"`), respx for mocking
- ruff for lint, mypy --strict for types
- 80% test coverage minimum

## Known API ambiguities

- `task.confirmAction.input` — the schema depends on `waiting_for_event_type` (≥19 variants). We accept `dict[str, Any]`; Claude gets the correct shape from the `confirm_input_schema` field on the event.
- IM-agent shortcuts (`agent-default`, `agent-default-main_task`) — documented but not formally confirmed on every endpoint. They flow through all tools as-is.
- Some list endpoints actually omit `data` when empty. All response models default to `data: list[...] = []`.
