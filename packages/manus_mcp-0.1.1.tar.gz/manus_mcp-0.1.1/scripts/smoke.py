"""Smoke test: hit a few safe read-only Manus endpoints with your real API key.

Run:
    python scripts/smoke.py

Requires MANUS_API_KEY in env or .env. Uses 100/min read-only endpoints only.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from manus_mcp.client import ManusClient  # noqa: E402
from manus_mcp.config import load_settings  # noqa: E402
from manus_mcp.schemas.agents import AgentListResponse  # noqa: E402
from manus_mcp.schemas.connectors import ConnectorListResponse  # noqa: E402
from manus_mcp.schemas.skills import SkillListResponse  # noqa: E402
from manus_mcp.schemas.usage import UsageListResponse  # noqa: E402


async def _run() -> int:
    settings = load_settings()
    async with ManusClient(
        api_key=settings.manus_api_key,
        base_url=settings.manus_base_url,
        timeout=settings.manus_http_timeout,
    ) as client:
        agents = await client.call(
            "GET",
            "/v2/agent.list",
            response_model=AgentListResponse,
            rate_limit_key="agent.list",
        )
        skills = await client.call(
            "GET",
            "/v2/skill.list",
            response_model=SkillListResponse,
            rate_limit_key="skill.list",
        )
        connectors = await client.call(
            "GET",
            "/v2/connector.list",
            response_model=ConnectorListResponse,
            rate_limit_key="connector.list",
        )
        usage = await client.call(
            "GET",
            "/v2/usage.list",
            params={"limit": 5},
            response_model=UsageListResponse,
            rate_limit_key="usage.list",
        )

    print(f"agents:     {len(agents.data)} found")
    for a in agents.data[:3]:
        print(f"  - {a.id}: nickname={a.nickname!r} task_id={a.task_id!r}")
    print(f"skills:     {len(skills.data)} found")
    for s in skills.data[:3]:
        print(f"  - {s.id}: {s.name!r} ({s.owner_type})")
    print(f"connectors: {len(connectors.data)} found")
    for c in connectors.data[:3]:
        print(f"  - {c.id}: {c.name!r} type={c.type}")
    print(f"usage:      {len(usage.data)} recent entries")
    for u in usage.data[:3]:
        print(f"  - {u.task_id}: credits={u.credits} type={u.type}")
    return 0


def main() -> None:
    raise SystemExit(asyncio.run(_run()))


if __name__ == "__main__":
    main()
