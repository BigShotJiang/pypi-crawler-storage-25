"""Regenerate tests/fixtures/input_schemas.json from the live tool registry.

Run this after deliberate changes to any tool's input_schema. The accompanying
test (`tests/test_input_schema_stability.py`) compares against this fixture and
fails on any unintended drift, forcing a review on regeneration.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from manus_mcp.server import _input_schema_for  # noqa: E402
from manus_mcp.tools import all_tools, load_all_tool_modules  # noqa: E402

FIXTURE = ROOT / "tests" / "fixtures" / "input_schemas.json"


def _normalise(value: object) -> object:
    """Sort enum lists so the fixture is stable across Python versions."""
    import contextlib

    if isinstance(value, dict):
        out = {k: _normalise(v) for k, v in value.items()}
        if "enum" in out and isinstance(out["enum"], list):
            with contextlib.suppress(TypeError):
                out["enum"] = sorted(out["enum"])
        return out
    if isinstance(value, list):
        return [_normalise(v) for v in value]
    return value


def main() -> None:
    load_all_tool_modules()
    payload = {t.name: _normalise(_input_schema_for(t.input_schema)) for t in all_tools()}
    FIXTURE.parent.mkdir(parents=True, exist_ok=True)
    FIXTURE.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True),
        encoding="utf-8",
    )
    print(f"wrote {len(payload)} schemas to {FIXTURE.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
