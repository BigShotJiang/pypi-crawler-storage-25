"""Live E2E probe of unmocked Manus API endpoints.

Captures real JSON responses to the api-snapshots directory and tracks credit
consumption via usage.list before/after.

Endpoints exercised:
  - usage.list (read, baseline credits)
  - project.create + project.list + (create new project — small, no credit cost)
  - agent.detail (uses agent-default shortcut)
  - browser.onlineList (read)
  - webhook.publicKey (read)
  - file.upload (presign + PUT 1KB / 1MB / 10MB) + file.detail + file.delete
  - task.create (1 credit), task.detail, manus_task_wait, task.delete
  - usage.list (final, compute delta)

Heavier credit-spending operations are guarded behind RUN_HEAVY=1.
"""

from __future__ import annotations

import asyncio
import json
import os
import secrets
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from manus_mcp.client import ManusClient  # noqa: E402
from manus_mcp.client.errors import ManusApiError  # noqa: E402
from manus_mcp.config import load_settings  # noqa: E402
from manus_mcp.schemas.agents import AgentDetailResponse  # noqa: E402
from manus_mcp.schemas.browser import BrowserOnlineListResponse  # noqa: E402
from manus_mcp.schemas.files import (  # noqa: E402
    FileCreateRequest,
    FileCreateResponse,
    FileDeleteRequest,
    FileDeleteResponse,
    FileDetailResponse,
)
from manus_mcp.schemas.projects import (  # noqa: E402
    ProjectCreateRequest,
    ProjectCreateResponse,
    ProjectListResponse,
)
from manus_mcp.schemas.tasks import (  # noqa: E402
    MessageBlock,
    TaskCreateRequest,
    TaskCreateResponse,
    TaskDeleteRequest,
    TaskDeleteResponse,
    TaskDetailResponse,
    TaskListMessagesQuery,
    TaskListMessagesResponse,
    TaskStopRequest,
    TaskStopResponse,
)
from manus_mcp.schemas.usage import UsageListResponse  # noqa: E402
from manus_mcp.schemas.webhooks import WebhookPublicKeyResponse  # noqa: E402

SNAPSHOT_DIR = ROOT / "docs/reports/Claude Code/0.0.2_production-readiness/api-snapshots"
RUN_HEAVY = os.environ.get("RUN_HEAVY", "0") == "1"


def _redact(payload: Any) -> Any:
    """Replace volatile or sensitive substrings before persisting snapshots."""
    if isinstance(payload, dict):
        return {k: _redact(v) for k, v in payload.items()}
    if isinstance(payload, list):
        return [_redact(v) for v in payload]
    return payload


def _save(name: str, obj: Any) -> None:
    SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
    path = SNAPSHOT_DIR / f"{name}.json"
    path.write_text(
        json.dumps(_redact(obj), indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    print(f"  saved {path.relative_to(ROOT)}")


async def _credit_balance(client: ManusClient) -> tuple[int | None, dict[str, Any]]:
    resp = await client.call(
        "GET",
        "/v2/usage.list",
        params={"limit": 1},
        response_model=UsageListResponse,
        rate_limit_key="usage.list",
    )
    payload = resp.model_dump(mode="json", exclude_none=True)
    return None, payload


async def _safe_call(label: str, coro: Any) -> tuple[Any, dict[str, Any]]:
    """Run `coro`, capture either the parsed model or the raised error metadata."""
    started = time.monotonic()
    try:
        result = await coro
        elapsed_ms = int((time.monotonic() - started) * 1000)
        if hasattr(result, "model_dump"):
            return result, {
                "ok": True,
                "elapsed_ms": elapsed_ms,
                "payload": result.model_dump(mode="json", exclude_none=True),
            }
        return result, {"ok": True, "elapsed_ms": elapsed_ms, "payload": result}
    except ManusApiError as e:
        elapsed_ms = int((time.monotonic() - started) * 1000)
        return None, {
            "ok": False,
            "elapsed_ms": elapsed_ms,
            "error": {
                "code": e.code,
                "message": e.message,
                "http_status": e.http_status,
                "request_id": e.request_id,
            },
        }
    except Exception as e:
        elapsed_ms = int((time.monotonic() - started) * 1000)
        return None, {
            "ok": False,
            "elapsed_ms": elapsed_ms,
            "error": {"code": type(e).__name__, "message": str(e)},
        }


async def _run() -> None:
    settings = load_settings()
    print(f"# live e2e probe (RUN_HEAVY={RUN_HEAVY})")
    print(f"  base_url: {settings.manus_base_url}")
    print(f"  snapshots dir: {SNAPSHOT_DIR.relative_to(ROOT)}")
    summary: dict[str, Any] = {"started_at": int(time.time()), "RUN_HEAVY": RUN_HEAVY}

    async with ManusClient(
        api_key=settings.manus_api_key,
        base_url=settings.manus_base_url,
        timeout=settings.manus_http_timeout,
    ) as client:
        # ------- baseline usage.list (also serves as snapshot) ----------------
        print("\n[1/9] usage.list (baseline)")
        _, baseline_meta = await _safe_call(
            "usage.list",
            client.call(
                "GET",
                "/v2/usage.list",
                params={"limit": 5},
                response_model=UsageListResponse,
                rate_limit_key="usage.list",
            ),
        )
        summary["usage_baseline"] = baseline_meta
        _save("usage_list_baseline", baseline_meta)

        # ------- webhook.publicKey -------------------------------------------
        print("\n[2/9] webhook.publicKey")
        _, wpk_meta = await _safe_call(
            "webhook.publicKey",
            client.call(
                "GET",
                "/v2/webhook.publicKey",
                response_model=WebhookPublicKeyResponse,
                rate_limit_key="webhook.publicKey",
            ),
        )
        summary["webhook_public_key"] = wpk_meta
        _save("webhook_public_key", wpk_meta)

        # ------- browser.onlineList ------------------------------------------
        print("\n[3/9] browser.onlineList")
        _, br_meta = await _safe_call(
            "browser.onlineList",
            client.call(
                "GET",
                "/v2/browser.onlineList",
                response_model=BrowserOnlineListResponse,
                rate_limit_key="browser.onlineList",
            ),
        )
        summary["browser_online_list"] = br_meta
        _save("browser_online_list", br_meta)

        # ------- agent.detail with default shortcut --------------------------
        print("\n[4/9] agent.detail (agent-default)")
        _, ag_meta = await _safe_call(
            "agent.detail",
            client.call(
                "GET",
                "/v2/agent.detail",
                params={"agent_id": "agent-default"},
                response_model=AgentDetailResponse,
                rate_limit_key="agent.detail",
            ),
        )
        summary["agent_detail"] = ag_meta
        _save("agent_detail", ag_meta)

        # ------- project.list -----------------------------------------------
        print("\n[5/9] project.list")
        _, pl_meta = await _safe_call(
            "project.list",
            client.call(
                "GET",
                "/v2/project.list",
                response_model=ProjectListResponse,
                rate_limit_key="project.list",
            ),
        )
        summary["project_list"] = pl_meta
        _save("project_list", pl_meta)

        # ------- project.create + repeat list to confirm round-trip ----------
        print("\n[6/9] project.create + project.list (verify round-trip)")
        marker = f"manus-mcp-test-{secrets.token_hex(3)}"
        _, pc_meta = await _safe_call(
            "project.create",
            client.call(
                "POST",
                "/v2/project.create",
                json_body=ProjectCreateRequest(name=marker, instruction="ephemeral test project"),
                response_model=ProjectCreateResponse,
                rate_limit_key="project.create",
            ),
        )
        summary["project_create"] = pc_meta
        _save("project_create", pc_meta)
        if pc_meta.get("ok"):
            created_pid = pc_meta["payload"]["project"]["id"]
            print(f"  created project_id={created_pid}")
        else:
            created_pid = None

        # ------- file.upload presign + PUT for several sizes -----------------
        print("\n[7/9] file.upload presign + PUT (1KB)")
        sizes = {"1KB": 1024}
        if RUN_HEAVY:
            sizes["1MB"] = 1024 * 1024
            sizes["10MB"] = 10 * 1024 * 1024
        upload_results: dict[str, Any] = {}
        last_file_id: str | None = None
        for label, size in sizes.items():
            data = secrets.token_bytes(size)
            filename = f"manus-mcp-probe-{label}-{secrets.token_hex(3)}.bin"
            t_total = time.monotonic()
            _, presign_meta = await _safe_call(
                "file.upload",
                client.call(
                    "POST",
                    "/v2/file.upload",
                    json_body=FileCreateRequest(filename=filename),
                    response_model=FileCreateResponse,
                    rate_limit_key="file.upload",
                ),
            )
            put_meta: dict[str, Any]
            file_id: str | None = None
            detail_after_meta: dict[str, Any] = {}
            if presign_meta.get("ok"):
                file_id = presign_meta["payload"]["file"]["id"]
                upload_url = presign_meta["payload"]["upload_url"]
                t_put = time.monotonic()
                try:
                    await client.put_raw(upload_url, data, "application/octet-stream")
                    put_meta = {
                        "ok": True,
                        "put_elapsed_ms": int((time.monotonic() - t_put) * 1000),
                        "size_bytes": size,
                    }
                except ManusApiError as e:
                    put_meta = {
                        "ok": False,
                        "put_elapsed_ms": int((time.monotonic() - t_put) * 1000),
                        "size_bytes": size,
                        "error": {"code": e.code, "message": e.message},
                    }
                # Poll detail until uploaded (capped at 30s)
                deadline = time.monotonic() + 30.0
                while True:
                    _, detail_after_meta = await _safe_call(
                        "file.detail",
                        client.call(
                            "GET",
                            "/v2/file.detail",
                            params={"file_id": file_id},
                            response_model=FileDetailResponse,
                            rate_limit_key="file.detail",
                        ),
                    )
                    status = (
                        detail_after_meta.get("payload", {}).get("file", {}).get("status")
                        if detail_after_meta.get("ok")
                        else None
                    )
                    if (
                        status == "uploaded"
                        or time.monotonic() >= deadline
                        or not detail_after_meta.get("ok")
                    ):
                        break
                    await asyncio.sleep(1.0)
            else:
                put_meta = {"ok": False, "skipped": "presign failed"}
            upload_results[label] = {
                "presign": presign_meta,
                "put": put_meta,
                "detail_after_put": detail_after_meta,
                "total_elapsed_ms": int((time.monotonic() - t_total) * 1000),
            }
            if file_id and detail_after_meta.get("ok"):
                last_file_id = file_id
        summary["file_upload"] = upload_results
        _save("file_upload", upload_results)

        # ------- file.delete the last one -----------------------------------
        if last_file_id:
            print(f"\n[7b] file.delete file_id={last_file_id}")
            _, del_meta = await _safe_call(
                "file.delete",
                client.call(
                    "POST",
                    "/v2/file.delete",
                    json_body=FileDeleteRequest(file_id=last_file_id),
                    response_model=FileDeleteResponse,
                    rate_limit_key="file.delete",
                ),
            )
            summary["file_delete"] = del_meta
            _save("file_delete", del_meta)

        # ------- task.create + immediate stop + delete (CHEAP cycle) ---------
        # We deliberately stop the task immediately so it consumes minimal credits.
        print("\n[8/9] task.create -> stop -> delete (minimal credit usage)")
        marker_task = f"mcp-probe {secrets.token_hex(3)}"
        _, tc_meta = await _safe_call(
            "task.create",
            client.call(
                "POST",
                "/v2/task.create",
                json_body=TaskCreateRequest(
                    message=MessageBlock(content=f"echo {marker_task}"),
                    hide_in_task_list=True,
                    title=f"MCP probe {marker_task}",
                ),
                response_model=TaskCreateResponse,
                rate_limit_key="task.create",
            ),
        )
        summary["task_create"] = tc_meta
        _save("task_create", tc_meta)
        task_id: str | None = None
        if tc_meta.get("ok"):
            task_id = tc_meta["payload"]["task_id"]
            print(f"  task_id={task_id}")

            # Quick detail snapshot
            await asyncio.sleep(2.0)
            _, td_meta = await _safe_call(
                "task.detail",
                client.call(
                    "GET",
                    "/v2/task.detail",
                    params={"task_id": task_id},
                    response_model=TaskDetailResponse,
                    rate_limit_key="task.detail",
                ),
            )
            summary["task_detail"] = td_meta
            _save("task_detail", td_meta)

            # listMessages (first page) for shape
            _, tlm_meta = await _safe_call(
                "task.listMessages",
                client.call(
                    "GET",
                    "/v2/task.listMessages",
                    params=TaskListMessagesQuery(
                        task_id=task_id,
                        limit=20,
                        order="desc",
                    ).model_dump(exclude_none=True),
                    response_model=TaskListMessagesResponse,
                    rate_limit_key="task.listMessages",
                ),
            )
            summary["task_list_messages"] = tlm_meta
            _save("task_list_messages", tlm_meta)

            # Stop immediately to cap credit cost
            _, ts_meta = await _safe_call(
                "task.stop",
                client.call(
                    "POST",
                    "/v2/task.stop",
                    json_body=TaskStopRequest(task_id=task_id),
                    response_model=TaskStopResponse,
                    rate_limit_key="task.stop",
                ),
            )
            summary["task_stop"] = ts_meta
            _save("task_stop", ts_meta)

            # Delete to cleanup (note: agent main_task can't be deleted, but
            # standalone tasks can)
            _, tdel_meta = await _safe_call(
                "task.delete",
                client.call(
                    "POST",
                    "/v2/task.delete",
                    json_body=TaskDeleteRequest(task_id=task_id),
                    response_model=TaskDeleteResponse,
                    rate_limit_key="task.delete",
                ),
            )
            summary["task_delete"] = tdel_meta
            _save("task_delete", tdel_meta)

        # ------- final usage.list to compute delta --------------------------
        print("\n[9/9] usage.list (final)")
        _, final_meta = await _safe_call(
            "usage.list",
            client.call(
                "GET",
                "/v2/usage.list",
                params={"limit": 5},
                response_model=UsageListResponse,
                rate_limit_key="usage.list",
            ),
        )
        summary["usage_final"] = final_meta
        _save("usage_list_final", final_meta)

    summary["finished_at"] = int(time.time())
    SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
    (SNAPSHOT_DIR / "_summary.json").write_text(
        json.dumps(_redact(summary), indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )
    print(f"\nSummary -> {(SNAPSHOT_DIR / '_summary.json').relative_to(ROOT)}")


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
