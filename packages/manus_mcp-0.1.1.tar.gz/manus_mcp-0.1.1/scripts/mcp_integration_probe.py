"""End-to-end probe of the Manus MCP server through the official mcp.client.stdio API.

Spawns `python -m manus_mcp` as a subprocess, lists tools, validates schemas,
calls a couple of safe read-only tools, and writes the results to a JSON report.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from mcp import ClientSession, StdioServerParameters  # noqa: E402
from mcp.client.stdio import stdio_client  # noqa: E402

REPORT_PATH = (
    ROOT / "docs/reports/Claude Code/0.0.2_production-readiness/api-snapshots/mcp_integration.json"
)


def _python_executable() -> str:
    venv = ROOT / ".venv" / "Scripts" / "python.exe"
    if venv.is_file():
        return str(venv)
    return sys.executable


async def _run() -> dict[str, object]:
    started = time.monotonic()
    params = StdioServerParameters(
        command=_python_executable(),
        args=["-m", "manus_mcp"],
        cwd=str(ROOT),
        env={**os.environ},
    )
    report: dict[str, object] = {
        "started_at": int(time.time()),
        "python": _python_executable(),
        "errors": [],
    }
    try:
        async with (
            stdio_client(params) as (read_stream, write_stream),
            ClientSession(read_stream, write_stream) as session,
        ):
            await session.initialize()

            tools = await session.list_tools()
            report["tools_count"] = len(tools.tools)
            report["tool_names"] = sorted(t.name for t in tools.tools)

            # Snapshot every tool's inputSchema so we can spot anything weird
            # that a strict MCP client (Claude) might choke on.
            report["tools"] = [
                {
                    "name": t.name,
                    "description": t.description,
                    "inputSchema": t.inputSchema,
                }
                for t in sorted(tools.tools, key=lambda x: x.name)
            ]

            # Live read-only call: skill.list (100/min, free)
            t0 = time.monotonic()
            skill_resp = await session.call_tool("manus_skill_list", {})
            report["manus_skill_list"] = {
                "elapsed_ms": int((time.monotonic() - t0) * 1000),
                "is_error": skill_resp.isError,
                "content": [
                    {"type": getattr(c, "type", None), "text": getattr(c, "text", None)}
                    for c in skill_resp.content
                ],
            }

            # Live read-only call: connector.list
            t0 = time.monotonic()
            conn_resp = await session.call_tool("manus_connector_list", {})
            report["manus_connector_list"] = {
                "elapsed_ms": int((time.monotonic() - t0) * 1000),
                "is_error": conn_resp.isError,
                "content_preview": (
                    conn_resp.content[0].text[:400]
                    if conn_resp.content and hasattr(conn_resp.content[0], "text")
                    else None
                ),
            }

            # Validation-error probe: pass invalid input to a tool that
            # requires task_id, expect graceful error not crash.
            t0 = time.monotonic()
            bad_resp = await session.call_tool("manus_task_detail", {})
            report["validation_error_probe"] = {
                "elapsed_ms": int((time.monotonic() - t0) * 1000),
                "is_error": bad_resp.isError,
                "content_preview": (
                    bad_resp.content[0].text[:400]
                    if bad_resp.content and hasattr(bad_resp.content[0], "text")
                    else None
                ),
            }

    except Exception as e:
        report["errors"].append(f"{type(e).__name__}: {e}")

    report["total_elapsed_sec"] = round(time.monotonic() - started, 2)
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report


def main() -> int:
    report = asyncio.run(_run())
    print("# MCP integration probe summary")
    print(f"  python:       {report.get('python')}")
    print(f"  tools_count:  {report.get('tools_count')}")
    print(f"  total_elapsed_sec: {report.get('total_elapsed_sec')}")
    if isinstance(report.get("manus_skill_list"), dict):
        sl = report["manus_skill_list"]
        print(f"  skill.list:   isError={sl.get('is_error')} elapsed_ms={sl.get('elapsed_ms')}")
    if isinstance(report.get("validation_error_probe"), dict):
        v = report["validation_error_probe"]
        print(f"  validation_probe: isError={v.get('is_error')}")
    errs = report.get("errors") or []
    if errs:
        print("  ERRORS:")
        for e in errs:
            print(f"    {e}")
    print(f"\nFull report -> {REPORT_PATH}")
    return 0 if not errs else 2


if __name__ == "__main__":
    raise SystemExit(main())
