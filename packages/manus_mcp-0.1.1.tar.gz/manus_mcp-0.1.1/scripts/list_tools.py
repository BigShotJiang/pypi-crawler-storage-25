"""Print every registered MCP tool with its description. Requires no API key."""

from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault("MANUS_API_KEY", "dummy-for-listing-only")

from manus_mcp.tools import all_tools, load_all_tool_modules  # noqa: E402


def main() -> None:
    load_all_tool_modules()
    tools = all_tools()
    print(f"{len(tools)} tools registered:\n")
    for t in tools:
        print(f"  {t.name}")
        for line in t.description.splitlines():
            print(f"      {line}")
        print()


if __name__ == "__main__":
    main()
