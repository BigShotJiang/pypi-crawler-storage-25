"""End-to-end check that webhook delivery from Manus actually works.

Spawns the local receiver + a cloudflared quick tunnel, registers a temporary
webhook with Manus, fires a short task, and waits for the two expected events
(`task_created`, `task_stopped`). Cleans up when finished.

Requirements:
- `cloudflared` on PATH (https://github.com/cloudflare/cloudflared)
- `MANUS_API_KEY` in env or .env
- ports 8787/tcp free locally

Usage:
    .venv/Scripts/python.exe scripts/webhook_e2e_check.py
"""

from __future__ import annotations

import asyncio
import os
import re
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from manus_mcp.client import ManusApiError, ManusClient  # noqa: E402
from manus_mcp.config import load_settings  # noqa: E402
from manus_mcp.schemas.tasks import (  # noqa: E402
    MessageBlock,
    TaskCreateRequest,
    TaskCreateResponse,
    TaskDeleteRequest,
    TaskDeleteResponse,
)
from manus_mcp.schemas.webhooks import (  # noqa: E402
    WebhookCreateRequest,
    WebhookCreateResponse,
    WebhookDeleteRequest,
    WebhookDeleteResponse,
)
from manus_mcp.webhook_receiver.storage import EventStore  # noqa: E402

TUNNEL_PATTERN = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com", re.IGNORECASE)


def _find_cloudflared() -> str:
    path = shutil.which("cloudflared")
    if not path:
        raise SystemExit(
            "cloudflared not found on PATH. Install from "
            "https://github.com/cloudflare/cloudflared/releases and retry."
        )
    return path


def _spawn_receiver(env: dict[str, str]) -> subprocess.Popen[str]:
    return subprocess.Popen(
        [sys.executable, "-m", "manus_mcp.webhook_receiver"],
        cwd=str(ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )


def _spawn_cloudflared(cf: str) -> subprocess.Popen[str]:
    return subprocess.Popen(
        [cf, "tunnel", "--url", "http://localhost:8787", "--no-autoupdate"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )


def _wait_for_tunnel_url(proc: subprocess.Popen[str], timeout: float = 60.0) -> str:
    deadline = time.monotonic() + timeout
    assert proc.stdout is not None
    buffer: list[str] = []
    while time.monotonic() < deadline:
        line = proc.stdout.readline()
        if not line:
            time.sleep(0.1)
            continue
        buffer.append(line)
        match = TUNNEL_PATTERN.search(line)
        if match:
            return match.group(0)
    raise SystemExit(
        f"cloudflared did not yield a public URL within {timeout}s. Output:\n" + "".join(buffer)
    )


async def _run() -> int:
    settings = load_settings()
    cf = _find_cloudflared()

    print("[1/7] starting cloudflared quick tunnel...")
    cf_proc = _spawn_cloudflared(cf)
    try:
        tunnel_url = _wait_for_tunnel_url(cf_proc)
        public_url = f"{tunnel_url}/manus/webhook"
        print(f"      tunnel: {tunnel_url}")

        print("[2/7] starting webhook receiver bound to public_url...")
        env = {**os.environ, "MANUS_WEBHOOK_PUBLIC_URL": public_url}
        recv_proc = _spawn_receiver(env)
        try:
            time.sleep(2.0)  # give uvicorn a moment to bind

            async with ManusClient(
                api_key=settings.manus_api_key,
                base_url=settings.manus_base_url,
                timeout=settings.manus_http_timeout,
            ) as client:
                print(f"[3/7] registering webhook {public_url}")
                wh = await client.call(
                    "POST",
                    "/v2/webhook.create",
                    json_body=WebhookCreateRequest(url=public_url),
                    response_model=WebhookCreateResponse,
                    rate_limit_key="webhook.create",
                )
                webhook_id = wh.webhook.id
                print(f"      webhook_id={webhook_id}")

                try:
                    print("[4/7] firing test task...")
                    created = await client.call(
                        "POST",
                        "/v2/task.create",
                        json_body=TaskCreateRequest(
                            message=MessageBlock(content="release-check ping"),
                            hide_in_task_list=True,
                            title="webhook-e2e-check",
                        ),
                        response_model=TaskCreateResponse,
                        rate_limit_key="task.create",
                    )
                    task_id = created.task_id
                    print(f"      task_id={task_id}")

                    print("[5/7] watching SQLite store for events (timeout 180s)...")
                    store = EventStore(settings.manus_webhook_db_path)
                    deadline = time.monotonic() + 180.0
                    seen: set[str] = set()
                    while time.monotonic() < deadline:
                        evs = store.list(task_id=task_id, limit=10)
                        for e in evs:
                            if e.event_type not in seen:
                                seen.add(e.event_type)
                                print(f"      received {e.event_type} ({e.event_id})")
                        if {"task_created", "task_stopped"} <= seen:
                            break
                        await asyncio.sleep(2.0)
                    else:
                        print("      ! timed out waiting for task_stopped")

                    print("[6/7] cleanup task...")
                    try:
                        await client.call(
                            "POST",
                            "/v2/task.delete",
                            json_body=TaskDeleteRequest(task_id=task_id),
                            response_model=TaskDeleteResponse,
                            rate_limit_key="task.delete",
                        )
                    except ManusApiError as e:
                        print(f"      task delete: {e}")

                    if {"task_created", "task_stopped"} <= seen:
                        print("[7/7] OK — both events received and verified")
                        return 0
                    print(f"[7/7] FAIL — saw {sorted(seen)} only")
                    return 2
                finally:
                    print("      cleanup webhook...")
                    try:
                        await client.call(
                            "POST",
                            "/v2/webhook.delete",
                            json_body=WebhookDeleteRequest(webhook_id=webhook_id),
                            response_model=WebhookDeleteResponse,
                            rate_limit_key="webhook.delete",
                        )
                    except ManusApiError as e:
                        print(f"      webhook delete: {e}")
        finally:
            recv_proc.send_signal(signal.SIGTERM if os.name != "nt" else signal.SIGINT)
            try:
                recv_proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                recv_proc.kill()
    finally:
        cf_proc.send_signal(signal.SIGTERM if os.name != "nt" else signal.SIGINT)
        try:
            cf_proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            cf_proc.kill()


def main() -> None:
    raise SystemExit(asyncio.run(_run()))


if __name__ == "__main__":
    main()
