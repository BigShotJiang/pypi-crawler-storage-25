"""Manus MCP — an MCP server exposing the full Manus API v2."""

__version__ = "0.1.1"
