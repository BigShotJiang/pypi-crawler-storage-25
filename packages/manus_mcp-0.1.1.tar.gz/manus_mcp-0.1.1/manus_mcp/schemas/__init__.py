"""Pydantic request/response models for every Manus API v2 endpoint."""
