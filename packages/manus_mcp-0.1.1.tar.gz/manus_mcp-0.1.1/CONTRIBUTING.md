# Contributing to Manus MCP

Thanks for your interest in contributing. This document covers the local setup, the checks every change must pass, and the conventions used in the codebase.

## Development setup

```bash
git clone https://github.com/aruxojuyu665/Manus-MCP.git
cd Manus-MCP

python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install -e ".[dev]"
pre-commit install
```

Copy `.env.example` to `.env` and fill in your `MANUS_API_KEY` (only required for live tests and live probes).

## Required checks before opening a PR

```bash
ruff check manus_mcp tests scripts
mypy --strict manus_mcp
pytest -m "not live" --cov=manus_mcp --cov-fail-under=80
```

All three must pass. Coverage is gated at 80% in CI.

If your change touches the live API surface, also run:

```bash
pytest -m live
```

This needs a real `MANUS_API_KEY` and consumes a small amount of credits. Tests skip gracefully when the account lacks the prerequisite (no agents, no website, no team plan).

## Commit and branch conventions

- Branches: `feat/<short-name>`, `fix/<short-name>`, `chore/<short-name>`.
- Commit messages follow [Conventional Commits](https://www.conventionalcommits.org/): `feat:`, `fix:`, `refactor:`, `docs:`, `test:`, `chore:`, `perf:`, `ci:`.
- Keep commits focused; prefer multiple small commits over one large mixed one.

## Code conventions

- Python 3.11+, full type hints, `from __future__ import annotations` in every module.
- Pydantic v2 for all request/response models.
- `httpx.AsyncClient` for HTTP.
- pytest + `pytest-asyncio` (`asyncio_mode = "auto"`) and `respx` for HTTP mocking.
- Never `print()` in runtime code — `stdout` is reserved for the MCP transport. Log via `manus_mcp/logger.py` (stderr only).
- Never log the API key.

See [CLAUDE.md](CLAUDE.md) for a deeper architecture tour and the template for adding a new tool.

## Reporting security issues

Open a private security advisory on <https://github.com/aruxojuyu665/Manus-MCP/security/advisories/new>. Do not file a public issue for vulnerabilities.

## License

By contributing, you agree that your contributions will be licensed under the [MIT License](LICENSE).
