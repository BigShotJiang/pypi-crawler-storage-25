"""Verify that the API key never leaks into logs or repr() output."""

from __future__ import annotations

import logging

import pytest
import respx
from httpx import Response

from manus_mcp.client import ManusClient
from manus_mcp.client.rate_limiter import RateLimiter
from manus_mcp.client.retry import RetryPolicy
from manus_mcp.schemas.skills import SkillListResponse

_SECRET = "sk-PROBE-SECRET-XYZ-ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"


def _client() -> ManusClient:
    return ManusClient(
        api_key=_SECRET,
        base_url="https://api.manus.test",
        timeout=2.0,
        rate_limiter=RateLimiter(limits={"skill.list": 1000}),
        retry_policy=RetryPolicy(max_attempts_429=1, max_attempts_5xx=1, max_attempts_network=1),
    )


@pytest.mark.asyncio
async def test_api_key_not_in_logs_during_normal_call(caplog) -> None:
    caplog.set_level(logging.DEBUG, logger="manus_mcp")
    client = _client()
    with respx.mock(assert_all_called=False) as mock:
        mock.get("https://api.manus.test/v2/skill.list").mock(
            return_value=Response(200, json={"ok": True, "request_id": "r-1", "data": []})
        )
        await client.call(
            "GET",
            "/v2/skill.list",
            response_model=SkillListResponse,
            rate_limit_key="skill.list",
        )
    await client.aclose()

    for record in caplog.records:
        msg = record.getMessage()
        assert _SECRET not in msg, f"API key leaked into log: {record.name}: {msg}"
        # The header name should not appear with the value either.
        assert f"x-manus-api-key: {_SECRET}".lower() not in msg.lower()


@pytest.mark.asyncio
async def test_api_key_not_in_logs_during_error(caplog) -> None:
    caplog.set_level(logging.DEBUG, logger="manus_mcp")
    client = _client()
    with respx.mock(assert_all_called=False) as mock:
        mock.get("https://api.manus.test/v2/skill.list").mock(
            return_value=Response(
                400,
                json={
                    "ok": False,
                    "request_id": "r-2",
                    "error": {"code": "invalid_argument", "message": "bad"},
                },
            )
        )
        from manus_mcp.client.errors import ManusApiError

        with pytest.raises(ManusApiError):
            await client.call(
                "GET",
                "/v2/skill.list",
                response_model=SkillListResponse,
                rate_limit_key="skill.list",
            )
    await client.aclose()

    for record in caplog.records:
        assert _SECRET not in record.getMessage()


def test_api_key_not_in_repr_or_str() -> None:
    client = _client()
    assert _SECRET not in repr(client)
    assert _SECRET not in str(client)


@pytest.mark.asyncio
async def test_api_key_not_in_logs_during_429_retry(caplog) -> None:
    caplog.set_level(logging.DEBUG, logger="manus_mcp")
    client = _client()
    with respx.mock(assert_all_called=False) as mock:
        mock.get("https://api.manus.test/v2/skill.list").mock(
            side_effect=[
                Response(
                    429,
                    json={"ok": False, "error": {"code": "rate_limited", "message": "slow"}},
                ),
                Response(200, json={"ok": True, "request_id": "r", "data": []}),
            ]
        )
        await client.call(
            "GET",
            "/v2/skill.list",
            response_model=SkillListResponse,
            rate_limit_key="skill.list",
        )
    await client.aclose()

    for record in caplog.records:
        assert _SECRET not in record.getMessage()
