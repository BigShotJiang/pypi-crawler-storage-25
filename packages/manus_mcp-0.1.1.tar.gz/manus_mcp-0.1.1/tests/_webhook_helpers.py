"""Shared helpers for spawning cloudflared + the webhook receiver in tests.

Extracted from `scripts/webhook_e2e_check.py` to keep `tests/test_live_webhook_e2e.py`
focused on assertions and to avoid duplicating subprocess plumbing.
"""

from __future__ import annotations

import os
import re
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

TUNNEL_PATTERN = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com", re.IGNORECASE)


def find_cloudflared() -> str | None:
    """Return cloudflared path on PATH, or None if not installed."""
    return shutil.which("cloudflared")


def spawn_cloudflared(cf_path: str) -> subprocess.Popen[str]:
    """Spawn `cloudflared tunnel --url http://localhost:8787` and return the process."""
    return subprocess.Popen(
        [cf_path, "tunnel", "--url", "http://localhost:8787", "--no-autoupdate"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )


def wait_for_tunnel_url(proc: subprocess.Popen[str], timeout: float = 60.0) -> str:
    """Block until cloudflared prints its public URL, or raise TimeoutError."""
    deadline = time.monotonic() + timeout
    assert proc.stdout is not None
    buffer: list[str] = []
    while time.monotonic() < deadline:
        line = proc.stdout.readline()
        if not line:
            time.sleep(0.1)
            continue
        buffer.append(line)
        match = TUNNEL_PATTERN.search(line)
        if match:
            return match.group(0)
    raise TimeoutError(
        f"cloudflared did not yield a public URL within {timeout}s. "
        f"Output:\n{''.join(buffer[-20:])}"
    )


def spawn_receiver(
    public_url: str, extra_env: dict[str, str] | None = None
) -> subprocess.Popen[str]:
    """Spawn `python -m manus_mcp.webhook_receiver` with the given public URL."""
    env = {**os.environ, "MANUS_WEBHOOK_PUBLIC_URL": public_url}
    if extra_env:
        env.update(extra_env)
    return subprocess.Popen(
        [sys.executable, "-m", "manus_mcp.webhook_receiver"],
        cwd=str(ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )


def terminate_quietly(proc: subprocess.Popen[str], timeout: float = 5.0) -> None:
    """Best-effort SIGTERM with fallback to kill. Ignores OSError."""
    import contextlib

    with contextlib.suppress(OSError):
        proc.send_signal(signal.SIGTERM if os.name != "nt" else signal.SIGINT)
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
