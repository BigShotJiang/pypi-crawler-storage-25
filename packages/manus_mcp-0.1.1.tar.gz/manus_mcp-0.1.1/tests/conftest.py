"""Shared pytest fixtures."""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from dotenv import load_dotenv

from manus_mcp.client import ManusClient
from manus_mcp.client.rate_limiter import RateLimiter
from manus_mcp.client.retry import RetryPolicy

# Load .env from project root so live tests can find MANUS_API_KEY / ManusAPI.
# CI sets MANUS_API_KEY directly in env; load_dotenv won't override existing vars.
load_dotenv(Path(__file__).resolve().parent.parent / ".env")
# Normalise legacy alias `ManusAPI` -> `MANUS_API_KEY` so live skip detection works.
if "MANUS_API_KEY" not in os.environ and os.environ.get("ManusAPI"):  # noqa: SIM112
    os.environ["MANUS_API_KEY"] = os.environ["ManusAPI"]  # noqa: SIM112


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers",
        "live: requires real MANUS_API_KEY; calls api.manus.ai and may consume credits",
    )


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """Skip @pytest.mark.live tests if MANUS_API_KEY is missing or set to a dummy."""
    raw = (
        os.environ.get("MANUS_API_KEY")
        or os.environ.get("ManusAPI")  # noqa: SIM112  legacy alias from .env
        or ""
    )
    has_real_key = raw.startswith("sk-") and len(raw) > 30 and raw != "dummy-ci-key"
    if has_real_key:
        return
    skip_live = pytest.mark.skip(reason="MANUS_API_KEY not set (or dummy); skipping live tests")
    for item in items:
        if "live" in item.keywords:
            item.add_marker(skip_live)


@pytest.fixture
def manus_client_factory():
    """Factory that returns a configured ManusClient with relaxed retry for fast tests."""

    def make(**overrides) -> ManusClient:
        kwargs = dict(
            api_key="test-key",
            base_url="https://api.manus.test",
            timeout=5.0,
            rate_limiter=RateLimiter(
                limits={
                    "task.create": 10_000,
                    "task.detail": 10_000,
                    "file.upload": 10_000,
                    "file.detail": 10_000,
                    "website.publish": 10_000,
                    "website.status": 10_000,
                    "task.listMessages": 10_000,
                }
            ),
            retry_policy=RetryPolicy(
                max_attempts_429=2,
                max_attempts_5xx=2,
                max_attempts_network=1,
                base_delay=0.01,
                max_delay=0.05,
            ),
        )
        kwargs.update(overrides)
        return ManusClient(**kwargs)

    return make
