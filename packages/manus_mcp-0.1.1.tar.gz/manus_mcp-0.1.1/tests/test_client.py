"""Unit tests for ManusClient error mapping, retries, header injection."""

from __future__ import annotations

import pytest
import respx
from httpx import Response

from manus_mcp.client import ManusApiError
from manus_mcp.schemas.tasks import (
    MessageBlock,
    TaskCreateRequest,
    TaskCreateResponse,
    TaskDetailResponse,
)


@pytest.mark.asyncio
async def test_injects_auth_header(manus_client_factory) -> None:
    client = manus_client_factory()
    with respx.mock(assert_all_called=False) as mock:
        route = mock.post("https://api.manus.test/v2/task.create").mock(
            return_value=Response(200, json={"ok": True, "request_id": "r1", "task_id": "t1"})
        )
        result = await client.call(
            "POST",
            "/v2/task.create",
            json_body=TaskCreateRequest(message=MessageBlock(content="hi")),
            response_model=TaskCreateResponse,
        )
        assert result.task_id == "t1"
        assert route.called
        sent = route.calls[-1].request
        assert sent.headers["x-manus-api-key"] == "test-key"
        assert sent.headers["user-agent"].startswith("manus-mcp/")
    await client.aclose()


@pytest.mark.asyncio
async def test_maps_ok_false_to_manus_api_error(manus_client_factory) -> None:
    client = manus_client_factory()
    with respx.mock(assert_all_called=False) as mock:
        mock.post("https://api.manus.test/v2/task.create").mock(
            return_value=Response(
                400,
                json={
                    "ok": False,
                    "request_id": "req-xyz",
                    "error": {"code": "invalid_argument", "message": "bad"},
                },
            )
        )
        with pytest.raises(ManusApiError) as ei:
            await client.call(
                "POST",
                "/v2/task.create",
                json_body=TaskCreateRequest(message=MessageBlock(content="hi")),
                response_model=TaskCreateResponse,
            )
    assert ei.value.code == "invalid_argument"
    assert ei.value.request_id == "req-xyz"
    assert ei.value.http_status == 400
    await client.aclose()


@pytest.mark.asyncio
async def test_retries_on_429_then_succeeds(manus_client_factory) -> None:
    client = manus_client_factory()
    with respx.mock(assert_all_called=False) as mock:
        route = mock.post("https://api.manus.test/v2/task.create").mock(
            side_effect=[
                Response(
                    429,
                    json={"ok": False, "error": {"code": "rate_limited", "message": "slow"}},
                ),
                Response(200, json={"ok": True, "request_id": "r", "task_id": "t"}),
            ]
        )
        result = await client.call(
            "POST",
            "/v2/task.create",
            json_body=TaskCreateRequest(message=MessageBlock(content="hi")),
            response_model=TaskCreateResponse,
        )
        assert result.task_id == "t"
        assert route.call_count == 2
    await client.aclose()


@pytest.mark.asyncio
async def test_retries_on_5xx_then_fails(manus_client_factory) -> None:
    client = manus_client_factory()
    with respx.mock(assert_all_called=False) as mock:
        mock.get("https://api.manus.test/v2/task.detail").mock(
            return_value=Response(503, json={"ok": False, "error": {"code": "svc", "message": "x"}})
        )
        with pytest.raises(ManusApiError):
            await client.call(
                "GET",
                "/v2/task.detail",
                params={"task_id": "t"},
                response_model=TaskDetailResponse,
            )
    await client.aclose()


@pytest.mark.asyncio
async def test_rejects_invalid_response(manus_client_factory) -> None:
    client = manus_client_factory()
    with respx.mock(assert_all_called=False) as mock:
        mock.post("https://api.manus.test/v2/task.create").mock(
            return_value=Response(200, json={"ok": True, "request_id": "r"})  # missing task_id
        )
        with pytest.raises(ManusApiError) as ei:
            await client.call(
                "POST",
                "/v2/task.create",
                json_body=TaskCreateRequest(message=MessageBlock(content="hi")),
                response_model=TaskCreateResponse,
            )
    assert ei.value.code == "invalid_response"
    await client.aclose()
