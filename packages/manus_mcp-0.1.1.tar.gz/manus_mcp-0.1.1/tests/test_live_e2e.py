"""Live E2E tests against real Manus API. Skipped without MANUS_API_KEY.

Each test is small and read-only where possible. Mutating tests use
`hide_in_task_list=True` and clean up after themselves to minimise credit cost.
Schema validation alone — if a request returns non-2xx or fails pydantic
validation, the test fails. This catches API drift relative to our schemas.
"""

from __future__ import annotations

import secrets
from collections.abc import AsyncIterator

import pytest
import pytest_asyncio

from manus_mcp.client import ManusApiError, ManusClient
from manus_mcp.config import load_settings
from manus_mcp.schemas.agents import (
    AgentDetailResponse,
    AgentListResponse,
    AgentUpdateRequest,
    AgentUpdateResponse,
)
from manus_mcp.schemas.browser import BrowserOnlineListResponse
from manus_mcp.schemas.connectors import ConnectorListResponse
from manus_mcp.schemas.files import (
    FileCreateRequest,
    FileCreateResponse,
    FileDeleteRequest,
    FileDeleteResponse,
    FileDetailQuery,
    FileDetailResponse,
)
from manus_mcp.schemas.projects import (
    ProjectCreateRequest,
    ProjectCreateResponse,
    ProjectListResponse,
)
from manus_mcp.schemas.skills import SkillListResponse
from manus_mcp.schemas.tasks import (
    MessageBlock,
    TaskConfirmActionRequest,
    TaskConfirmActionResponse,
    TaskCreateRequest,
    TaskCreateResponse,
    TaskDeleteRequest,
    TaskDeleteResponse,
    TaskDetailResponse,
    TaskListMessagesQuery,
    TaskListMessagesResponse,
    TaskListQuery,
    TaskListResponse,
    TaskSendMessageRequest,
    TaskSendMessageResponse,
    TaskStopRequest,
    TaskStopResponse,
    TaskUpdateRequest,
    TaskUpdateResponse,
)
from manus_mcp.schemas.usage import (
    UsageListQuery,
    UsageListResponse,
    UsageTeamLogQuery,
    UsageTeamLogResponse,
    UsageTeamStatisticQuery,
    UsageTeamStatisticResponse,
)
from manus_mcp.schemas.webhooks import WebhookListResponse, WebhookPublicKeyResponse
from manus_mcp.schemas.website import (
    WebsiteListCheckpointsResponse,
    WebsitePublishRequest,
    WebsitePublishResponse,
    WebsiteStatusResponse,
)

pytestmark = pytest.mark.live


@pytest_asyncio.fixture()
async def live_client() -> AsyncIterator[ManusClient]:
    s = load_settings()
    async with ManusClient(
        api_key=s.manus_api_key,
        base_url=s.manus_base_url,
        timeout=s.manus_http_timeout,
    ) as c:
        yield c


# ---------------------------------------------------------------------------
# Read-only / safe (free)
# ---------------------------------------------------------------------------


async def test_skill_list(live_client: ManusClient) -> None:
    resp = await live_client.call(
        "GET",
        "/v2/skill.list",
        response_model=SkillListResponse,
        rate_limit_key="skill.list",
    )
    assert resp.ok is True
    assert isinstance(resp.data, list)


async def test_connector_list(live_client: ManusClient) -> None:
    resp = await live_client.call(
        "GET",
        "/v2/connector.list",
        response_model=ConnectorListResponse,
        rate_limit_key="connector.list",
    )
    assert resp.ok is True


async def test_agent_list(live_client: ManusClient) -> None:
    resp = await live_client.call(
        "GET",
        "/v2/agent.list",
        response_model=AgentListResponse,
        rate_limit_key="agent.list",
    )
    assert resp.ok is True


async def test_browser_online_list(live_client: ManusClient) -> None:
    resp = await live_client.call(
        "GET",
        "/v2/browser.onlineList",
        response_model=BrowserOnlineListResponse,
        rate_limit_key="browser.onlineList",
    )
    assert resp.ok is True


async def test_webhook_public_key(live_client: ManusClient) -> None:
    resp = await live_client.call(
        "GET",
        "/v2/webhook.publicKey",
        response_model=WebhookPublicKeyResponse,
        rate_limit_key="webhook.publicKey",
    )
    assert resp.public_key.startswith("-----BEGIN PUBLIC KEY-----")


async def test_webhook_list(live_client: ManusClient) -> None:
    resp = await live_client.call(
        "GET",
        "/v2/webhook.list",
        response_model=WebhookListResponse,
        rate_limit_key="webhook.list",
    )
    assert resp.ok is True


async def test_usage_list(live_client: ManusClient) -> None:
    resp = await live_client.call(
        "GET",
        "/v2/usage.list",
        params=UsageListQuery(limit=5).model_dump(exclude_none=True),
        response_model=UsageListResponse,
        rate_limit_key="usage.list",
    )
    assert resp.ok is True


async def test_project_list(live_client: ManusClient) -> None:
    resp = await live_client.call(
        "GET",
        "/v2/project.list",
        response_model=ProjectListResponse,
        rate_limit_key="project.list",
    )
    assert resp.ok is True


async def test_task_list(live_client: ManusClient) -> None:
    resp = await live_client.call(
        "GET",
        "/v2/task.list",
        params=TaskListQuery(limit=5).model_dump(exclude_none=True),
        response_model=TaskListResponse,
        rate_limit_key="task.list",
    )
    assert resp.ok is True


# ---------------------------------------------------------------------------
# Conditional / may not be available on all accounts
# ---------------------------------------------------------------------------


async def test_agent_detail_default_shortcut(live_client: ManusClient) -> None:
    """F1: 'agent-default' shortcut may return 404 on accounts without IM agent.
    Test passes either on success OR on documented not_found behaviour."""
    try:
        resp = await live_client.call(
            "GET",
            "/v2/agent.detail",
            params={"agent_id": "agent-default"},
            response_model=AgentDetailResponse,
            rate_limit_key="agent.detail",
        )
        assert resp.ok is True
    except ManusApiError as e:
        if e.code == "not_found":
            pytest.skip("Account has no default IM agent (documented quirk F1)")
        raise


async def test_usage_team_statistic(live_client: ManusClient) -> None:
    try:
        resp = await live_client.call(
            "GET",
            "/v2/usage.teamStatistic",
            params=UsageTeamStatisticQuery().model_dump(exclude_none=True),
            response_model=UsageTeamStatisticResponse,
            rate_limit_key="usage.teamStatistic",
        )
        assert resp.ok is True
    except ManusApiError as e:
        if e.code == "permission_denied":
            pytest.skip("Individual account; team usage requires team plan")
        raise


async def test_usage_team_log(live_client: ManusClient) -> None:
    try:
        resp = await live_client.call(
            "GET",
            "/v2/usage.teamLog",
            params=UsageTeamLogQuery(limit=5).model_dump(exclude_none=True),
            response_model=UsageTeamLogResponse,
            rate_limit_key="usage.teamLog",
        )
        assert resp.ok is True
    except ManusApiError as e:
        if e.code == "permission_denied":
            pytest.skip("Individual account; team usage requires team plan")
        raise


async def test_website_status_optional(live_client: ManusClient) -> None:
    """Try website.status against any task that has a website; skip otherwise."""
    tasks = await live_client.call(
        "GET",
        "/v2/task.list",
        params={"limit": 50},
        response_model=TaskListResponse,
        rate_limit_key="task.list",
    )
    for t in tasks.data:
        try:
            resp = await live_client.call(
                "GET",
                "/v2/website.status",
                params={"task_id": t.id},
                response_model=WebsiteStatusResponse,
                rate_limit_key="website.status",
            )
            assert resp.ok is True
            return
        except ManusApiError as e:
            if e.code == "not_found":
                continue
            raise
    pytest.skip("No task with attached website found in last 50 tasks")


async def test_website_list_checkpoints_optional(live_client: ManusClient) -> None:
    tasks = await live_client.call(
        "GET",
        "/v2/task.list",
        params={"limit": 50},
        response_model=TaskListResponse,
        rate_limit_key="task.list",
    )
    for t in tasks.data:
        try:
            resp = await live_client.call(
                "GET",
                "/v2/website.listCheckpoints",
                params={"task_id": t.id},
                response_model=WebsiteListCheckpointsResponse,
                rate_limit_key="website.listCheckpoints",
            )
            assert resp.ok is True
            return
        except ManusApiError as e:
            if e.code == "not_found":
                continue
            raise
    pytest.skip("No task with website found")


# ---------------------------------------------------------------------------
# Mutating: project create + task lifecycle (cheap)
# ---------------------------------------------------------------------------


async def test_project_create_round_trip(live_client: ManusClient) -> None:
    name = f"manus-mcp-live-test-{secrets.token_hex(3)}"
    resp = await live_client.call(
        "POST",
        "/v2/project.create",
        json_body=ProjectCreateRequest(name=name, instruction="ephemeral live test"),
        response_model=ProjectCreateResponse,
        rate_limit_key="project.create",
    )
    assert resp.project.name == name


async def test_task_lifecycle_minimal(live_client: ManusClient) -> None:
    """Create -> stop -> delete cycle. Should consume <= 5 credits in practice."""
    title = f"mcp-live-{secrets.token_hex(3)}"
    created = await live_client.call(
        "POST",
        "/v2/task.create",
        json_body=TaskCreateRequest(
            message=MessageBlock(content=f"echo {title}"),
            hide_in_task_list=True,
            title=title,
        ),
        response_model=TaskCreateResponse,
        rate_limit_key="task.create",
    )
    task_id = created.task_id
    try:
        # Read-after-write: task.detail can briefly return 404 right after create.
        # Manus has been observed taking up to ~25s before the new task becomes
        # readable via task.detail; mirror the grace used in manus_task_wait.
        import asyncio as _asyncio

        for attempt in range(20):
            try:
                detail = await live_client.call(
                    "GET",
                    "/v2/task.detail",
                    params={"task_id": task_id},
                    response_model=TaskDetailResponse,
                    rate_limit_key="task.detail",
                )
                break
            except ManusApiError as e:
                if e.code == "not_found" and attempt < 19:
                    await _asyncio.sleep(2.0)
                    continue
                raise
        assert detail.task.id == task_id

        msgs = await live_client.call(
            "GET",
            "/v2/task.listMessages",
            params=TaskListMessagesQuery(task_id=task_id, limit=10).model_dump(exclude_none=True),
            response_model=TaskListMessagesResponse,
            rate_limit_key="task.listMessages",
        )
        assert msgs.task_id == task_id

        # task.update — exercise the endpoint without spending extra credits.
        new_title = f"{title}-renamed"
        updated = await live_client.call(
            "POST",
            "/v2/task.update",
            json_body=TaskUpdateRequest(
                task_id=task_id,
                title=new_title,
                share_visibility="private",
            ),
            response_model=TaskUpdateResponse,
            rate_limit_key="task.update",
        )
        assert updated.task_id == task_id
        # Title may be reflected in response or only on subsequent task.detail.
        if updated.task_title is not None:
            assert updated.task_title == new_title

        stop = await live_client.call(
            "POST",
            "/v2/task.stop",
            json_body=TaskStopRequest(task_id=task_id),
            response_model=TaskStopResponse,
            rate_limit_key="task.stop",
        )
        assert stop.ok is True
    finally:
        # Always cleanup, even if intermediate assertions failed.
        import contextlib

        with contextlib.suppress(ManusApiError):
            await live_client.call(
                "POST",
                "/v2/task.delete",
                json_body=TaskDeleteRequest(task_id=task_id),
                response_model=TaskDeleteResponse,
                rate_limit_key="task.delete",
            )


# ---------------------------------------------------------------------------
# File upload: F2 explicit reject + accept paths
# ---------------------------------------------------------------------------


async def test_file_upload_bin_blocked(live_client: ManusClient) -> None:
    """F2: confirm Manus rejects .bin extension (server-side allowlist)."""
    try:
        await live_client.call(
            "POST",
            "/v2/file.upload",
            json_body=FileCreateRequest(filename=f"probe-{secrets.token_hex(3)}.bin"),
            response_model=FileCreateResponse,
            rate_limit_key="file.upload",
        )
    except ManusApiError as e:
        assert e.code == "invalid_argument"
        assert "blocked file type" in e.message.lower()
        return
    pytest.fail("Expected .bin upload to be rejected by Manus API (F2)")


async def test_file_upload_txt_round_trip(live_client: ManusClient) -> None:
    """F2: .txt upload presign succeeds; verify create -> detail -> delete cycle."""
    name = f"probe-{secrets.token_hex(3)}.txt"
    pre = await live_client.call(
        "POST",
        "/v2/file.upload",
        json_body=FileCreateRequest(filename=name),
        response_model=FileCreateResponse,
        rate_limit_key="file.upload",
    )
    try:
        await live_client.put_raw(pre.upload_url, b"manus-mcp-live-probe", "text/plain")
        # poll detail until uploaded
        import asyncio

        for _ in range(20):
            d = await live_client.call(
                "GET",
                "/v2/file.detail",
                params=FileDetailQuery(file_id=pre.file.id).model_dump(exclude_none=True),
                response_model=FileDetailResponse,
                rate_limit_key="file.detail",
            )
            if d.file.status == "uploaded":
                break
            await asyncio.sleep(0.5)
        else:
            pytest.fail(f"file did not reach uploaded status: id={pre.file.id}")
    finally:
        import contextlib

        with contextlib.suppress(ManusApiError):
            await live_client.call(
                "POST",
                "/v2/file.delete",
                json_body=FileDeleteRequest(file_id=pre.file.id),
                response_model=FileDeleteResponse,
                rate_limit_key="file.delete",
            )


# ---------------------------------------------------------------------------
# v0.1.1: closing the gap — task.sendMessage / confirmAction, agent.update,
# website.publish (each was uncovered live in v0.1.0).
# ---------------------------------------------------------------------------


async def _wait_for_task_visible(
    live_client: ManusClient, task_id: str, max_attempts: int = 20, delay_sec: float = 2.0
) -> None:
    """Poll task.detail until task is readable (read-after-write grace)."""
    import asyncio as _asyncio

    for attempt in range(max_attempts):
        try:
            await live_client.call(
                "GET",
                "/v2/task.detail",
                params={"task_id": task_id},
                response_model=TaskDetailResponse,
                rate_limit_key="task.detail",
            )
            return
        except ManusApiError as e:
            if e.code == "not_found" and attempt < max_attempts - 1:
                await _asyncio.sleep(delay_sec)
                continue
            raise


async def test_task_send_message_round_trip(live_client: ManusClient) -> None:
    """task.sendMessage round-trip: create -> send -> verify echoed in listMessages."""
    import asyncio as _asyncio
    import contextlib

    marker = secrets.token_hex(4)
    title = f"mcp-send-{marker}"
    created = await live_client.call(
        "POST",
        "/v2/task.create",
        json_body=TaskCreateRequest(
            message=MessageBlock(content=f"hello {marker}"),
            hide_in_task_list=True,
            title=title,
        ),
        response_model=TaskCreateResponse,
        rate_limit_key="task.create",
    )
    task_id = created.task_id
    try:
        await _wait_for_task_visible(live_client, task_id)

        followup_marker = f"followup-{secrets.token_hex(3)}"
        send_resp = await live_client.call(
            "POST",
            "/v2/task.sendMessage",
            json_body=TaskSendMessageRequest(
                task_id=task_id,
                message=MessageBlock(content=followup_marker),
            ),
            response_model=TaskSendMessageResponse,
            rate_limit_key="task.sendMessage",
        )
        assert send_resp.task_id == task_id

        # Poll listMessages until our follow-up user_message is visible.
        deadline = _asyncio.get_event_loop().time() + 60.0
        found = False
        while _asyncio.get_event_loop().time() < deadline:
            msgs = await live_client.call(
                "GET",
                "/v2/task.listMessages",
                params=TaskListMessagesQuery(
                    task_id=task_id,
                    limit=20,
                    order="desc",
                ).model_dump(exclude_none=True),
                response_model=TaskListMessagesResponse,
                rate_limit_key="task.listMessages",
            )
            for m in msgs.messages:
                if (
                    m.type == "user_message"
                    and m.user_message is not None
                    and m.user_message.content
                    and followup_marker in m.user_message.content
                ):
                    found = True
                    break
            if found:
                break
            await _asyncio.sleep(2.0)
        assert found, f"follow-up marker {followup_marker} not seen in listMessages within 60s"
    finally:
        with contextlib.suppress(ManusApiError):
            await live_client.call(
                "POST",
                "/v2/task.stop",
                json_body=TaskStopRequest(task_id=task_id),
                response_model=TaskStopResponse,
                rate_limit_key="task.stop",
            )
        with contextlib.suppress(ManusApiError):
            await live_client.call(
                "POST",
                "/v2/task.delete",
                json_body=TaskDeleteRequest(task_id=task_id),
                response_model=TaskDeleteResponse,
                rate_limit_key="task.delete",
            )


async def test_task_confirm_action_via_terminal(live_client: ManusClient) -> None:
    """task.confirmAction: trigger waiting state via a terminalExecute prompt.

    The agent should reach `agent_status="waiting"` with `waiting_for_event_type`
    being terminalExecute (or a similar action). We then confirm with
    {accept: false, always_allow: false} which validates the endpoint without
    actually executing the command.

    On flaky agent behaviour (no waiting state in 120s) — skip with reason.
    """
    import asyncio as _asyncio
    import contextlib

    title = f"mcp-confirm-{secrets.token_hex(3)}"
    created = await live_client.call(
        "POST",
        "/v2/task.create",
        json_body=TaskCreateRequest(
            message=MessageBlock(
                content=(
                    "Please execute the command `pwd` in the terminal and "
                    "tell me the printed working directory. Do not write code, "
                    "just run the terminal command directly."
                )
            ),
            hide_in_task_list=True,
            title=title,
        ),
        response_model=TaskCreateResponse,
        rate_limit_key="task.create",
    )
    task_id = created.task_id
    try:
        await _wait_for_task_visible(live_client, task_id)

        # Poll listMessages up to 120s for a status_update that sets
        # waiting_for_event_id. Many event types qualify; we accept any that
        # carries an event_id.
        deadline = _asyncio.get_event_loop().time() + 120.0
        event_id: str | None = None
        event_type: str | None = None
        while _asyncio.get_event_loop().time() < deadline:
            msgs = await live_client.call(
                "GET",
                "/v2/task.listMessages",
                params=TaskListMessagesQuery(
                    task_id=task_id,
                    limit=30,
                    order="desc",
                    verbose=True,
                ).model_dump(exclude_none=True),
                response_model=TaskListMessagesResponse,
                rate_limit_key="task.listMessages",
            )
            for m in msgs.messages:
                if (
                    m.type == "status_update"
                    and m.status_update is not None
                    and m.status_update.status_detail is not None
                    and m.status_update.status_detail.waiting_for_event_id
                ):
                    event_id = m.status_update.status_detail.waiting_for_event_id
                    event_type = m.status_update.status_detail.waiting_for_event_type
                    break
            if event_id:
                break
            await _asyncio.sleep(2.5)

        if not event_id:
            pytest.skip(
                "agent did not trigger a confirmation event in 120s; the "
                "current Manus model may answer in chat instead of invoking "
                "the terminal. Try alternate prompts (deployAction, "
                "videoGenerate) for a deeper smoke."
            )

        # Build a minimal valid input payload. Most events accept {accept: false};
        # for terminalExecute the documented schema includes always_allow.
        payload: dict[str, object] = {"accept": False, "always_allow": False}
        confirm = await live_client.call(
            "POST",
            "/v2/task.confirmAction",
            json_body=TaskConfirmActionRequest(
                task_id=task_id,
                event_id=event_id,
                input=payload,
            ),
            response_model=TaskConfirmActionResponse,
            rate_limit_key="task.confirmAction",
        )
        # confirmed flag may be True on success (the API confirms the call was
        # accepted; the task itself stays in waiting due to accept=false).
        assert confirm.task_id == task_id
        # Surface event_type into pytest output for diagnostics.
        assert event_type is not None
    finally:
        with contextlib.suppress(ManusApiError):
            await live_client.call(
                "POST",
                "/v2/task.stop",
                json_body=TaskStopRequest(task_id=task_id),
                response_model=TaskStopResponse,
                rate_limit_key="task.stop",
            )
        with contextlib.suppress(ManusApiError):
            await live_client.call(
                "POST",
                "/v2/task.delete",
                json_body=TaskDeleteRequest(task_id=task_id),
                response_model=TaskDeleteResponse,
                rate_limit_key="task.delete",
            )


async def test_agent_update_round_trip(live_client: ManusClient) -> None:
    """agent.update: save current state, mutate, verify, revert. Skip when no agents."""
    listing = await live_client.call(
        "GET",
        "/v2/agent.list",
        response_model=AgentListResponse,
        rate_limit_key="agent.list",
    )
    if not listing.data:
        pytest.skip("no agents on account; create one via Manus UI to enable this test")

    target = listing.data[0]
    original_nickname = target.nickname or ""
    original_about = target.about or ""

    new_nickname = f"mcp-probe-{secrets.token_hex(3)}"
    try:
        updated = await live_client.call(
            "POST",
            "/v2/agent.update",
            json_body=AgentUpdateRequest(
                agent_id=target.id,
                nickname=new_nickname,
                about=original_about,
            ),
            response_model=AgentUpdateResponse,
            rate_limit_key="agent.update",
        )
        # Agent record may echo the new nickname or not — Manus may return the
        # request_id and updated record asynchronously.
        if updated.agent.nickname is not None:
            assert updated.agent.nickname == new_nickname
    finally:
        # Always revert, even on assertion failure.
        import contextlib

        with contextlib.suppress(ManusApiError):
            await live_client.call(
                "POST",
                "/v2/agent.update",
                json_body=AgentUpdateRequest(
                    agent_id=target.id,
                    nickname=original_nickname,
                    about=original_about,
                ),
                response_model=AgentUpdateResponse,
                rate_limit_key="agent.update",
            )


async def test_website_publish_idempotent(live_client: ManusClient) -> None:
    """website.publish: re-deploy latest checkpoint of any existing website."""
    tasks = await live_client.call(
        "GET",
        "/v2/task.list",
        params={"limit": 50},
        response_model=TaskListResponse,
        rate_limit_key="task.list",
    )
    target_task_id: str | None = None
    for t in tasks.data:
        try:
            await live_client.call(
                "GET",
                "/v2/website.status",
                params={"task_id": t.id},
                response_model=WebsiteStatusResponse,
                rate_limit_key="website.status",
            )
            target_task_id = t.id
            break
        except ManusApiError as e:
            if e.code == "not_found":
                continue
            raise

    if not target_task_id:
        pytest.skip(
            "no task with attached website found in last 50 tasks; create one "
            "via a website-building task to enable this test"
        )

    publish = await live_client.call(
        "POST",
        "/v2/website.publish",
        json_body=WebsitePublishRequest(task_id=target_task_id),
        response_model=WebsitePublishResponse,
        rate_limit_key="website.publish",
    )
    assert publish.website_id
    assert publish.version_id
