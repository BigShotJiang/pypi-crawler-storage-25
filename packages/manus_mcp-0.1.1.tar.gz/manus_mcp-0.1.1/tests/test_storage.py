"""Tests for the SQLite-backed event store."""

from __future__ import annotations

import time
from pathlib import Path

from manus_mcp.webhook_receiver.storage import EventStore


def test_insert_and_list(tmp_path: Path) -> None:
    store = EventStore(tmp_path / "events.db")
    assert store.insert(
        event_id="e1",
        event_type="task_created",
        task_id="t1",
        body={"event_type": "task_created"},
        headers={"h": "v"},
    )
    # Duplicate is idempotent
    assert not store.insert(
        event_id="e1",
        event_type="task_created",
        task_id="t1",
        body={"event_type": "task_created"},
        headers={"h": "v"},
    )
    items = store.list()
    assert len(items) == 1
    assert items[0].event_id == "e1"


def test_filters_and_clear(tmp_path: Path) -> None:
    store = EventStore(tmp_path / "events.db")
    for i in range(3):
        store.insert(
            event_id=f"e{i}",
            event_type="task_stopped",
            task_id=f"t{i}",
            body={},
            headers={},
        )
    store.insert(
        event_id="other",
        event_type="task_created",
        task_id="t99",
        body={},
        headers={},
    )
    assert len(store.list(event_type="task_stopped")) == 3
    assert len(store.list(task_id="t1")) == 1

    deleted = store.clear(event_type="task_stopped")
    assert deleted == 3
    remaining = store.list()
    assert len(remaining) == 1
    assert remaining[0].event_id == "other"


def test_get_by_id(tmp_path: Path) -> None:
    store = EventStore(tmp_path / "events.db")
    store.insert(event_id="e1", event_type="x", task_id=None, body={"a": 1}, headers={})
    got = store.get("e1")
    assert got is not None and got.body == {"a": 1}
    assert store.get("missing") is None
    _ = time.time()  # keep import used even if test is fast
