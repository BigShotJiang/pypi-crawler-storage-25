"""Snapshot test: every tool's inputSchema is frozen as a fixture.

Any change to a pydantic request model that affects the JSON Schema visible to
MCP clients will break this test, forcing a deliberate regeneration via:
    python scripts/regen_input_schemas.py

Schemas are compared after canonical normalisation: enum value lists are sorted
because pydantic-core has been observed to emit Literal values in different
orderings across Python versions (CPython 3.11 vs 3.14), which is purely
cosmetic and not visible to MCP clients beyond the set of allowed values.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from manus_mcp.server import _input_schema_for
from manus_mcp.tools import all_tools, load_all_tool_modules

FIXTURE = Path(__file__).resolve().parent / "fixtures" / "input_schemas.json"


def _normalise(value: Any) -> Any:
    """Recursively sort enum lists so Python-version differences disappear."""
    import contextlib

    if isinstance(value, dict):
        out = {k: _normalise(v) for k, v in value.items()}
        if "enum" in out and isinstance(out["enum"], list):
            with contextlib.suppress(TypeError):  # mixed types — leave as-is
                out["enum"] = sorted(out["enum"])
        return out
    if isinstance(value, list):
        return [_normalise(v) for v in value]
    return value


def _current_schemas() -> dict[str, dict]:
    load_all_tool_modules()
    return {t.name: _normalise(_input_schema_for(t.input_schema)) for t in all_tools()}


def test_fixture_exists() -> None:
    assert FIXTURE.is_file(), (
        f"Missing {FIXTURE.relative_to(FIXTURE.parents[2])}; run "
        "`python scripts/regen_input_schemas.py` to create it."
    )


def test_no_tool_added_or_removed() -> None:
    fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
    current_names = set(_current_schemas())
    fixture_names = set(fixture)
    added = current_names - fixture_names
    removed = fixture_names - current_names
    assert not added and not removed, (
        f"Tool drift detected. Added: {sorted(added)}, Removed: {sorted(removed)}. "
        "If intentional, run `python scripts/regen_input_schemas.py`."
    )


def test_input_schema_unchanged_per_tool() -> None:
    raw = json.loads(FIXTURE.read_text(encoding="utf-8"))
    fixture = {k: _normalise(v) for k, v in raw.items()}
    current = _current_schemas()
    diffs: list[str] = []
    for name in sorted(fixture):
        if fixture[name] != current.get(name):
            diffs.append(name)
    if diffs:
        details = "\n".join(
            f"  {name}: was=\n    {json.dumps(fixture[name], sort_keys=True)[:200]}\n"
            f"           now=\n    {json.dumps(current[name], sort_keys=True)[:200]}"
            for name in diffs[:5]
        )
        pytest.fail(
            f"inputSchema drift in {len(diffs)} tool(s):\n{details}\n"
            "If intentional, regenerate the fixture via:\n"
            "    python scripts/regen_input_schemas.py"
        )
