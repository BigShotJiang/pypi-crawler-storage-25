"""Smoke imports for `__main__` modules to keep them in coverage and ensure
they import without side-effects beyond stdlib/pydantic-settings."""

from __future__ import annotations

import importlib


def test_import_manus_mcp_main() -> None:
    mod = importlib.import_module("manus_mcp.__main__")
    assert hasattr(mod, "main")


def test_import_webhook_receiver_main() -> None:
    mod = importlib.import_module("manus_mcp.webhook_receiver.__main__")
    assert hasattr(mod, "main")
