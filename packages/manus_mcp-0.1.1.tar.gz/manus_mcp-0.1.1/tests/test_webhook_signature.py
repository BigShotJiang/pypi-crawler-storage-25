"""Tests for RSA-SHA256 signature verification using a freshly generated key pair."""

from __future__ import annotations

import base64
import time

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from manus_mcp.webhook_receiver.signature import (
    build_signed_content,
    load_public_key,
    verify_signature,
)


def _generate_keypair() -> tuple[rsa.RSAPrivateKey, str]:
    priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    pem = (
        priv.public_key()
        .public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        .decode("utf-8")
    )
    return priv, pem


def _sign(priv: rsa.RSAPrivateKey, content: bytes) -> str:
    sig = priv.sign(content, padding.PKCS1v15(), hashes.SHA256())
    return base64.b64encode(sig).decode("ascii")


def test_valid_signature_passes() -> None:
    priv, pem = _generate_keypair()
    pub = load_public_key(pem)
    ts = str(int(time.time()))
    url = "https://hook.example.com/manus/webhook"
    body = b'{"event_id":"e1","event_type":"task_created"}'
    sig = _sign(priv, build_signed_content(ts, url, body))

    result = verify_signature(
        public_key=pub,
        signature_b64=sig,
        timestamp=ts,
        public_url=url,
        body=body,
    )
    assert result.valid


def test_stale_timestamp_rejected() -> None:
    priv, pem = _generate_keypair()
    pub = load_public_key(pem)
    old_ts = str(int(time.time()) - 10_000)
    url = "https://hook.example.com/manus/webhook"
    body = b'{"x":1}'
    sig = _sign(priv, build_signed_content(old_ts, url, body))

    result = verify_signature(
        public_key=pub,
        signature_b64=sig,
        timestamp=old_ts,
        public_url=url,
        body=body,
    )
    assert not result.valid
    assert result.reason and "skew" in result.reason


def test_tampered_body_rejected() -> None:
    priv, pem = _generate_keypair()
    pub = load_public_key(pem)
    ts = str(int(time.time()))
    url = "https://hook.example.com/manus/webhook"
    body = b'{"x":1}'
    sig = _sign(priv, build_signed_content(ts, url, body))

    tampered = b'{"x":2}'
    result = verify_signature(
        public_key=pub,
        signature_b64=sig,
        timestamp=ts,
        public_url=url,
        body=tampered,
    )
    assert not result.valid


def test_wrong_public_url_rejected() -> None:
    priv, pem = _generate_keypair()
    pub = load_public_key(pem)
    ts = str(int(time.time()))
    body = b'{"x":1}'
    sig = _sign(priv, build_signed_content(ts, "https://real.example/wh", body))

    result = verify_signature(
        public_key=pub,
        signature_b64=sig,
        timestamp=ts,
        public_url="https://attacker.example/wh",
        body=body,
    )
    assert not result.valid
