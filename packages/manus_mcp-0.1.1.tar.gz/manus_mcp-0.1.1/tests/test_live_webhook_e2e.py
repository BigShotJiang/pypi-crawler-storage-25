"""Live end-to-end webhook delivery test.

Spawns cloudflared quick tunnel + manus_mcp.webhook_receiver, registers a
webhook with Manus, fires a tiny task, and waits for the `task_created` event
to land in the receiver's SQLite store. Verifies that the full delivery path
(Manus → tunnel → receiver → signature verification → store) works.

Skipped when:
- MANUS_API_KEY not set (live marker)
- cloudflared not on PATH (Windows local dev typically)
- running on Windows (subprocess.SIGTERM semantics differ; CI is always Linux)

CI install of cloudflared is in `.github/workflows/live.yml`.
"""

from __future__ import annotations

import contextlib
import secrets
import sys
import time
from collections.abc import AsyncIterator

import pytest
import pytest_asyncio

from manus_mcp.client import ManusApiError, ManusClient
from manus_mcp.config import load_settings
from manus_mcp.schemas.tasks import (
    MessageBlock,
    TaskCreateRequest,
    TaskCreateResponse,
    TaskDeleteRequest,
    TaskDeleteResponse,
    TaskStopRequest,
    TaskStopResponse,
)
from manus_mcp.schemas.webhooks import (
    WebhookCreateRequest,
    WebhookCreateResponse,
    WebhookDeleteRequest,
    WebhookDeleteResponse,
    WebhookListResponse,
)
from manus_mcp.webhook_receiver.storage import EventStore
from tests._webhook_helpers import (
    find_cloudflared,
    spawn_cloudflared,
    spawn_receiver,
    terminate_quietly,
    wait_for_tunnel_url,
)

pytestmark = pytest.mark.live


def _can_run_webhook_e2e() -> tuple[bool, str]:
    if sys.platform.startswith("win"):
        return False, "subprocess SIGTERM semantics differ on Windows; CI Linux runs this test"
    if find_cloudflared() is None:
        return (
            False,
            "cloudflared binary not found on PATH; install from "
            "https://github.com/cloudflare/cloudflared/releases",
        )
    return True, ""


@pytest_asyncio.fixture(scope="session")
async def webhook_e2e_setup(
    tmp_path_factory: pytest.TempPathFactory,
) -> AsyncIterator[tuple[str, str]]:
    """Yield (public_url, db_path) after both subprocesses are alive."""
    runnable, reason = _can_run_webhook_e2e()
    if not runnable:
        pytest.skip(reason)

    cf_path = find_cloudflared()
    assert cf_path is not None  # narrowed by _can_run_webhook_e2e

    cf_proc = spawn_cloudflared(cf_path)
    receiver_proc = None
    db_dir = tmp_path_factory.mktemp("webhook-e2e-db")
    db_path = db_dir / "events.db"
    try:
        try:
            tunnel_base = wait_for_tunnel_url(cf_proc)
        except TimeoutError as e:
            pytest.skip(f"cloudflared could not establish tunnel: {e}")
        public_url = f"{tunnel_base}/manus/webhook"

        receiver_proc = spawn_receiver(
            public_url, extra_env={"MANUS_WEBHOOK_DB_PATH": str(db_path)}
        )
        # Give uvicorn time to bind.
        time.sleep(2.0)
        if receiver_proc.poll() is not None:
            pytest.skip(f"webhook receiver exited unexpectedly (code={receiver_proc.returncode})")

        yield public_url, str(db_path)
    finally:
        if receiver_proc is not None:
            terminate_quietly(receiver_proc)
        terminate_quietly(cf_proc)


@pytest_asyncio.fixture()
async def live_client() -> AsyncIterator[ManusClient]:
    s = load_settings()
    async with ManusClient(
        api_key=s.manus_api_key,
        base_url=s.manus_base_url,
        timeout=s.manus_http_timeout,
    ) as c:
        yield c


async def test_webhook_create_delete_round_trip(
    webhook_e2e_setup: tuple[str, str],
    live_client: ManusClient,
) -> None:
    """Full live delivery: register webhook -> create task -> wait for event -> cleanup."""
    public_url, db_path = webhook_e2e_setup

    # 1. Register webhook
    create_resp = await live_client.call(
        "POST",
        "/v2/webhook.create",
        json_body=WebhookCreateRequest(url=public_url),
        response_model=WebhookCreateResponse,
        rate_limit_key="webhook.create",
    )
    webhook_id = create_resp.webhook.id

    task_id: str | None = None
    try:
        # 2. Verify webhook appears in list
        listing = await live_client.call(
            "GET",
            "/v2/webhook.list",
            response_model=WebhookListResponse,
            rate_limit_key="webhook.list",
        )
        assert any(w.id == webhook_id for w in listing.data), (
            f"webhook {webhook_id} not found in webhook.list"
        )

        # 3. Create a short task — Manus will fire task_created webhook event
        title = f"mcp-webhook-{secrets.token_hex(3)}"
        task_resp = await live_client.call(
            "POST",
            "/v2/task.create",
            json_body=TaskCreateRequest(
                message=MessageBlock(content=f"echo {title}"),
                hide_in_task_list=True,
                title=title,
            ),
            response_model=TaskCreateResponse,
            rate_limit_key="task.create",
        )
        task_id = task_resp.task_id

        # 4. Poll the receiver's SQLite store for the task_created event
        store = EventStore(db_path)
        deadline = time.monotonic() + 180.0
        seen_event_id: str | None = None
        while time.monotonic() < deadline:
            events = store.list(task_id=task_id, limit=10)
            for e in events:
                if e.event_type == "task_created":
                    seen_event_id = e.event_id
                    break
            if seen_event_id:
                break
            time.sleep(2.0)

        assert seen_event_id, (
            f"task_created event not received within 180s for task_id={task_id}; "
            "check tunnel health, signature verification, and receiver logs"
        )
    finally:
        if task_id:
            with contextlib.suppress(ManusApiError):
                await live_client.call(
                    "POST",
                    "/v2/task.stop",
                    json_body=TaskStopRequest(task_id=task_id),
                    response_model=TaskStopResponse,
                    rate_limit_key="task.stop",
                )
            with contextlib.suppress(ManusApiError):
                await live_client.call(
                    "POST",
                    "/v2/task.delete",
                    json_body=TaskDeleteRequest(task_id=task_id),
                    response_model=TaskDeleteResponse,
                    rate_limit_key="task.delete",
                )
        with contextlib.suppress(ManusApiError):
            await live_client.call(
                "POST",
                "/v2/webhook.delete",
                json_body=WebhookDeleteRequest(webhook_id=webhook_id),
                response_model=WebhookDeleteResponse,
                rate_limit_key="webhook.delete",
            )
