"""Sanity test: all expected tools are registered exactly once."""

from __future__ import annotations


def test_all_tools_registered() -> None:
    from manus_mcp.tools import all_tools, load_all_tool_modules

    load_all_tool_modules()
    names = {t.name for t in all_tools()}

    expected_direct = {
        "manus_task_create",
        "manus_task_detail",
        "manus_task_list",
        "manus_task_update",
        "manus_task_stop",
        "manus_task_delete",
        "manus_task_send_message",
        "manus_task_list_messages",
        "manus_task_confirm_action",
        "manus_project_create",
        "manus_project_list",
        "manus_skill_list",
        "manus_agent_list",
        "manus_agent_detail",
        "manus_agent_update",
        "manus_file_create",
        "manus_file_detail",
        "manus_file_delete",
        "manus_webhook_create",
        "manus_webhook_list",
        "manus_webhook_delete",
        "manus_webhook_public_key",
        "manus_usage_list",
        "manus_usage_team_statistic",
        "manus_usage_team_log",
        "manus_connector_list",
        "manus_browser_online_list",
        "manus_website_status",
        "manus_website_list_checkpoints",
        "manus_website_publish",
    }
    expected_composite = {
        "manus_file_upload",
        "manus_task_wait",
        "manus_website_publish_and_wait",
    }
    expected_webhook = {
        "manus_webhook_events_list",
        "manus_webhook_events_get",
        "manus_webhook_events_clear",
    }
    expected = expected_direct | expected_composite | expected_webhook
    missing = expected - names
    assert not missing, f"Missing tools: {missing}"

    # No duplicates (registry rejects them at import time, but double-check):
    assert len(all_tools()) == len(names)
