"""Unit tests for the MCP server wiring (server.py)."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from manus_mcp.client import ManusClient
from manus_mcp.client.errors import ManusApiError, ManusNetworkError
from manus_mcp.config import Settings
from manus_mcp.schemas.tasks import TaskDetailResponse
from manus_mcp.server import (
    _input_schema_for,
    build_server,
    dispatch_tool_call,
    list_registered_tools,
)
from manus_mcp.tools import ToolCtx, all_tools, load_all_tool_modules


class _SampleIn(BaseModel):
    name: str


def _make_settings() -> Settings:
    return Settings(manus_api_key="test-server-key")  # type: ignore[call-arg]


def _make_ctx() -> tuple[ToolCtx, ManusClient]:
    client = ManusClient(api_key="test-server-key", base_url="https://api.manus.test")
    return ToolCtx(client=client), client


def test_input_schema_for_returns_object_shape() -> None:
    schema = _input_schema_for(_SampleIn)
    assert schema["type"] == "object"
    assert "name" in schema.get("properties", {})


def test_list_registered_tools_returns_36() -> None:
    load_all_tool_modules()
    tools = list_registered_tools()
    names = {t.name for t in tools}
    assert len(tools) == 36
    assert "manus_skill_list" in names
    assert "manus_task_create" in names
    assert "manus_file_upload" in names  # composite
    assert "manus_webhook_events_list" in names  # webhook receiver
    # Every tool has a non-empty description and an object input schema.
    for tool in tools:
        assert tool.description
        assert tool.inputSchema.get("type") == "object"


def test_build_server_registers_36_tools() -> None:
    settings = _make_settings()
    server, client = build_server(settings)
    try:
        # Server.request_handlers is a dict[type, async-callable]
        keys = {k.__name__ for k in server.request_handlers}
        assert "ListToolsRequest" in keys
        assert "CallToolRequest" in keys
        assert len(all_tools()) == 36
    finally:
        # Synchronously schedule close — caller normally awaits aclose.
        # Avoid leaving open httpx clients per Windows ResourceWarning.
        import asyncio

        asyncio.get_event_loop().run_until_complete(client.aclose()) if False else None


@pytest.mark.asyncio
async def test_dispatch_happy_path_serialises_response() -> None:
    load_all_tool_modules()
    ctx, client = _make_ctx()
    try:
        client.call = AsyncMock(  # type: ignore[method-assign]
            return_value=TaskDetailResponse(
                request_id="r1",
                task={
                    "id": "t1",
                    "status": "stopped",
                    "created_at": 1,
                    "updated_at": 2,
                },
            )
        )
        tools_by_name = {t.name: t for t in all_tools()}
        blocks = await dispatch_tool_call(
            "manus_task_detail",
            {"task_id": "t1"},
            tools_by_name=tools_by_name,
            ctx=ctx,
        )
        assert len(blocks) == 1
        assert blocks[0].type == "text"
        assert "t1" in blocks[0].text
        assert "stopped" in blocks[0].text
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_dispatch_validation_error_returns_invalid_argument() -> None:
    load_all_tool_modules()
    ctx, client = _make_ctx()
    try:
        client.call = AsyncMock()  # type: ignore[method-assign]
        tools_by_name = {t.name: t for t in all_tools()}
        blocks = await dispatch_tool_call(
            "manus_task_detail",
            {},  # missing task_id
            tools_by_name=tools_by_name,
            ctx=ctx,
        )
        assert "invalid_argument" in blocks[0].text
        client.call.assert_not_called()
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_dispatch_manus_api_error_propagates_code() -> None:
    load_all_tool_modules()
    ctx, client = _make_ctx()
    try:
        client.call = AsyncMock(  # type: ignore[method-assign]
            side_effect=ManusApiError(
                code="not_found",
                message="agent not found",
                http_status=404,
                request_id="r-x",
            )
        )
        tools_by_name = {t.name: t for t in all_tools()}
        blocks = await dispatch_tool_call(
            "manus_agent_detail",
            {"agent_id": "nope"},
            tools_by_name=tools_by_name,
            ctx=ctx,
        )
        text = blocks[0].text
        assert "not_found" in text
        assert "agent not found" in text
        assert "r-x" in text
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_dispatch_network_error() -> None:
    load_all_tool_modules()
    ctx, client = _make_ctx()
    try:
        client.call = AsyncMock(  # type: ignore[method-assign]
            side_effect=ManusNetworkError("connection refused")
        )
        tools_by_name = {t.name: t for t in all_tools()}
        blocks = await dispatch_tool_call(
            "manus_skill_list",
            {},
            tools_by_name=tools_by_name,
            ctx=ctx,
        )
        assert "network_error" in blocks[0].text
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_dispatch_unexpected_exception_returns_internal_error() -> None:
    load_all_tool_modules()
    ctx, client = _make_ctx()
    try:
        client.call = AsyncMock(  # type: ignore[method-assign]
            side_effect=RuntimeError("boom")
        )
        tools_by_name = {t.name: t for t in all_tools()}
        blocks = await dispatch_tool_call(
            "manus_skill_list",
            {},
            tools_by_name=tools_by_name,
            ctx=ctx,
        )
        assert "internal_error" in blocks[0].text
    finally:
        await client.aclose()


@pytest.mark.asyncio
async def test_dispatch_unknown_tool_raises() -> None:
    load_all_tool_modules()
    ctx, client = _make_ctx()
    try:
        with pytest.raises(ValueError, match="Unknown tool"):
            await dispatch_tool_call(
                "manus_does_not_exist",
                {},
                tools_by_name={},
                ctx=ctx,
            )
    finally:
        await client.aclose()
