"""Tests for composite tools: task_wait, file_upload, website_publish_and_wait."""

from __future__ import annotations

from pathlib import Path

import pytest
import respx
from httpx import Response

from manus_mcp.tools.composite import (
    FileUploadRequest,
    FileUploadSource,
    TaskWaitRequest,
    WebsitePublishAndWaitRequest,
    file_upload,
    task_wait,
    website_publish_and_wait,
)
from manus_mcp.tools.registry import ToolCtx


@pytest.mark.asyncio
async def test_task_wait_stops_on_terminal(manus_client_factory) -> None:
    client = manus_client_factory()
    ctx = ToolCtx(client=client)

    with respx.mock(assert_all_called=False) as mock:
        mock.get("https://api.manus.test/v2/task.detail").mock(
            side_effect=[
                Response(
                    200,
                    json={
                        "ok": True,
                        "request_id": "r",
                        "task": {"id": "t", "status": "running", "created_at": 1, "updated_at": 2},
                    },
                ),
                Response(
                    200,
                    json={
                        "ok": True,
                        "request_id": "r",
                        "task": {"id": "t", "status": "stopped", "created_at": 1, "updated_at": 2},
                    },
                ),
            ]
        )
        mock.get("https://api.manus.test/v2/task.listMessages").mock(
            return_value=Response(
                200,
                json={
                    "ok": True,
                    "request_id": "r",
                    "task_id": "t",
                    "messages": [
                        {
                            "id": "m2",
                            "type": "assistant_message",
                            "timestamp": 10,
                            "assistant_message": {"content": "Done"},
                        },
                        {
                            "id": "m1",
                            "type": "status_update",
                            "timestamp": 5,
                            "status_update": {"agent_status": "stopped"},
                        },
                    ],
                    "has_more": False,
                },
            )
        )
        result = await task_wait(
            TaskWaitRequest(task_id="t", poll_interval_sec=0.5, timeout_sec=10),
            ctx,
        )
    assert result.terminal_state == "stopped"
    assert result.task.id == "t"
    assert result.last_assistant_message and result.last_assistant_message.content == "Done"
    assert [m.id for m in result.new_messages] == ["m1", "m2"]
    await client.aclose()


@pytest.mark.asyncio
async def test_task_wait_surfaces_waiting_details(manus_client_factory) -> None:
    client = manus_client_factory()
    ctx = ToolCtx(client=client)

    with respx.mock(assert_all_called=False) as mock:
        mock.get("https://api.manus.test/v2/task.detail").mock(
            return_value=Response(
                200,
                json={
                    "ok": True,
                    "request_id": "r",
                    "task": {"id": "t", "status": "waiting", "created_at": 1, "updated_at": 2},
                },
            )
        )
        mock.get("https://api.manus.test/v2/task.listMessages").mock(
            return_value=Response(
                200,
                json={
                    "ok": True,
                    "request_id": "r",
                    "task_id": "t",
                    "messages": [
                        {
                            "id": "m1",
                            "type": "status_update",
                            "timestamp": 5,
                            "status_update": {
                                "agent_status": "waiting",
                                "status_detail": {
                                    "waiting_for_event_id": "evt_1",
                                    "waiting_for_event_type": "deployAction",
                                    "waiting_description": "confirm deploy",
                                    "confirm_input_schema": {"type": "object"},
                                },
                            },
                        }
                    ],
                    "has_more": False,
                },
            )
        )
        result = await task_wait(TaskWaitRequest(task_id="t"), ctx)

    assert result.terminal_state == "waiting"
    assert result.waiting_for_event_type == "deployAction"
    assert result.waiting_for_event_id == "evt_1"
    assert result.confirm_input_schema == {"type": "object"}
    await client.aclose()


@pytest.mark.asyncio
async def test_file_upload_happy_path(tmp_path: Path, manus_client_factory) -> None:
    src = tmp_path / "doc.txt"
    src.write_bytes(b"hello manus")
    client = manus_client_factory()
    ctx = ToolCtx(client=client)

    with respx.mock(assert_all_called=False) as mock:
        mock.post("https://api.manus.test/v2/file.upload").mock(
            return_value=Response(
                200,
                json={
                    "ok": True,
                    "request_id": "r",
                    "file": {"id": "f1", "filename": "doc.txt", "status": "pending"},
                    "upload_url": "https://s3.example/put/abc",
                    "upload_expires_at": 1,
                },
            )
        )
        mock.put("https://s3.example/put/abc").mock(return_value=Response(200))
        mock.get("https://api.manus.test/v2/file.detail").mock(
            return_value=Response(
                200,
                json={
                    "ok": True,
                    "request_id": "r",
                    "file": {
                        "id": "f1",
                        "filename": "doc.txt",
                        "status": "uploaded",
                        "bytes": 11,
                    },
                },
            )
        )
        result = await file_upload(
            FileUploadRequest(
                source=FileUploadSource(path=str(src)),
                wait_timeout_sec=5,
                poll_interval_sec=0.1,
            ),
            ctx,
        )
    assert result.uploaded is True
    assert result.file.id == "f1"
    assert result.file.status == "uploaded"
    await client.aclose()


@pytest.mark.asyncio
async def test_file_upload_base64_defaults_to_txt(manus_client_factory) -> None:
    """F2 fix: base64 source without filename now defaults to .txt (was .bin)."""
    client = manus_client_factory()
    ctx = ToolCtx(client=client)

    captured: dict[str, str] = {}

    def _capture_filename(req):
        body = req.read()
        import json as _j

        captured["filename"] = _j.loads(body).get("filename", "")
        return Response(
            200,
            json={
                "ok": True,
                "request_id": "r",
                "file": {"id": "f1", "filename": captured["filename"], "status": "pending"},
                "upload_url": "https://s3.example/put/abc",
                "upload_expires_at": 1,
            },
        )

    with respx.mock(assert_all_called=False) as mock:
        mock.post("https://api.manus.test/v2/file.upload").mock(side_effect=_capture_filename)
        mock.put("https://s3.example/put/abc").mock(return_value=Response(200))
        mock.get("https://api.manus.test/v2/file.detail").mock(
            return_value=Response(
                200,
                json={
                    "ok": True,
                    "request_id": "r",
                    "file": {
                        "id": "f1",
                        "filename": captured.get("filename"),
                        "status": "uploaded",
                    },
                },
            )
        )
        import base64 as _b64

        await file_upload(
            FileUploadRequest(
                source=FileUploadSource(base64=_b64.b64encode(b"hi").decode()),
                wait_timeout_sec=2,
                poll_interval_sec=0.1,
            ),
            ctx,
        )
    assert captured["filename"].endswith(".txt"), (
        f"expected .txt default, got {captured['filename']}"
    )
    await client.aclose()


@pytest.mark.asyncio
async def test_file_upload_blocked_type_error_enriched(manus_client_factory) -> None:
    """F2 fix: when API returns 'blocked file type', error message lists known-good extensions."""
    from manus_mcp.client.errors import ManusApiError

    client = manus_client_factory()
    ctx = ToolCtx(client=client)

    with respx.mock(assert_all_called=False) as mock:
        mock.post("https://api.manus.test/v2/file.upload").mock(
            return_value=Response(
                400,
                json={
                    "ok": False,
                    "request_id": "r",
                    "error": {"code": "invalid_argument", "message": "blocked file type detected"},
                },
            )
        )
        with pytest.raises(ManusApiError) as ei:
            await file_upload(
                FileUploadRequest(
                    source=FileUploadSource(base64="aGVsbG8="),  # 'hello'
                    filename="something.exe",
                    wait_timeout_sec=2,
                    poll_interval_sec=0.1,
                ),
                ctx,
            )
    assert "known-good" in ei.value.message
    assert ".txt" in ei.value.message
    assert ".pdf" in ei.value.message
    assert "something.exe" in ei.value.message
    await client.aclose()


@pytest.mark.asyncio
async def test_website_publish_and_wait_success(manus_client_factory) -> None:
    client = manus_client_factory()
    ctx = ToolCtx(client=client)

    with respx.mock(assert_all_called=False) as mock:
        mock.post("https://api.manus.test/v2/website.publish").mock(
            return_value=Response(
                200,
                json={
                    "ok": True,
                    "request_id": "r",
                    "website_id": "w1",
                    "version_id": "v1",
                },
            )
        )
        mock.get("https://api.manus.test/v2/website.status").mock(
            side_effect=[
                Response(
                    200,
                    json={
                        "ok": True,
                        "request_id": "r",
                        "website_id": "w1",
                        "publish_status": "publishing",
                        "site_urls": [],
                    },
                ),
                Response(
                    200,
                    json={
                        "ok": True,
                        "request_id": "r",
                        "website_id": "w1",
                        "publish_status": "published",
                        "site_urls": ["https://w1.manus.space"],
                        "version_id": "v1",
                    },
                ),
            ]
        )
        result = await website_publish_and_wait(
            WebsitePublishAndWaitRequest(
                task_id="t",
                poll_interval_sec=0.1,
                timeout_sec=10,
            ),
            ctx,
        )
    assert result.final_status == "published"
    assert result.deployed_version_id == "v1"
    assert result.status.site_urls[0].endswith("manus.space")
    await client.aclose()
