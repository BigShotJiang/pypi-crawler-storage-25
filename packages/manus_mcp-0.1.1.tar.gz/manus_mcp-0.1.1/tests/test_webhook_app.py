"""ASGI-level tests for the webhook receiver Starlette application."""

from __future__ import annotations

import asyncio
import base64
import json
import time
from pathlib import Path
from typing import Any

import httpx
import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa

from manus_mcp.config import Settings
from manus_mcp.webhook_receiver import server as wh_server
from manus_mcp.webhook_receiver.signature import build_signed_content
from manus_mcp.webhook_receiver.storage import EventStore

WEBHOOK_PATH = "/manus/webhook"
PUBLIC_URL = "https://hook.example.com/manus/webhook"


def _generate_keypair() -> tuple[rsa.RSAPrivateKey, str]:
    priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    pem = (
        priv.public_key()
        .public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        .decode("utf-8")
    )
    return priv, pem


def _sign(priv: rsa.RSAPrivateKey, ts: str, url: str, body: bytes) -> str:
    sig = priv.sign(build_signed_content(ts, url, body), padding.PKCS1v15(), hashes.SHA256())
    return base64.b64encode(sig).decode("ascii")


@pytest.fixture()
def keypair() -> tuple[rsa.RSAPrivateKey, str]:
    return _generate_keypair()


@pytest.fixture()
def app_with_store(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    keypair: tuple[rsa.RSAPrivateKey, str],
) -> tuple[Any, EventStore]:
    db_path = tmp_path / "events.db"
    settings = Settings(  # type: ignore[call-arg]
        manus_api_key="test-key",
        manus_webhook_public_url=PUBLIC_URL,
        manus_webhook_db_path=db_path,
    )

    # Stub the public-key fetcher to return our test pubkey synchronously.
    _, pub_pem = keypair

    async def fake_get(self: Any) -> str:
        return pub_pem

    monkeypatch.setattr(wh_server.ManusPublicKeyFetcher, "get", fake_get)

    app = wh_server.create_app(settings)
    store = EventStore(db_path)
    return app, store


def _send(app: Any, body: bytes, headers: dict[str, str]) -> httpx.Response:
    """Synchronous helper around httpx.AsyncClient + ASGITransport."""
    transport = httpx.ASGITransport(app=app)

    async def _go() -> httpx.Response:
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
            return await c.post(WEBHOOK_PATH, content=body, headers=headers)

    return asyncio.run(_go())


def test_health(app_with_store: tuple[Any, EventStore]) -> None:
    app, _ = app_with_store
    transport = httpx.ASGITransport(app=app)

    async def _go() -> httpx.Response:
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
            return await c.get("/health")

    resp = asyncio.run(_go())
    assert resp.status_code == 200
    assert resp.json()["service"] == "manus-mcp-webhook"


def test_valid_signature_stores_event(
    app_with_store: tuple[Any, EventStore],
    keypair: tuple[rsa.RSAPrivateKey, str],
) -> None:
    app, store = app_with_store
    priv, _ = keypair
    body = json.dumps(
        {
            "event_id": "evt-1",
            "event_type": "task_created",
            "task_detail": {"task_id": "t-1", "task_title": "demo", "task_url": "u"},
        }
    ).encode("utf-8")
    ts = str(int(time.time()))
    sig = _sign(priv, ts, PUBLIC_URL, body)

    resp = _send(
        app,
        body,
        {
            "x-webhook-signature": sig,
            "x-webhook-timestamp": ts,
            "content-type": "application/json",
        },
    )
    assert resp.status_code == 200
    assert resp.json()["event_id"] == "evt-1"
    stored = store.get("evt-1")
    assert stored is not None
    assert stored.event_type == "task_created"
    assert stored.task_id == "t-1"


def test_invalid_signature_rejected(
    app_with_store: tuple[Any, EventStore],
) -> None:
    app, store = app_with_store
    body = b'{"event_id":"evt-x","event_type":"task_created"}'
    ts = str(int(time.time()))
    resp = _send(
        app,
        body,
        {
            "x-webhook-signature": base64.b64encode(b"garbage" * 64).decode(),
            "x-webhook-timestamp": ts,
            "content-type": "application/json",
        },
    )
    assert resp.status_code == 401
    assert resp.json()["error"] == "invalid_signature"
    assert store.get("evt-x") is None


def test_stale_timestamp_rejected(
    app_with_store: tuple[Any, EventStore],
    keypair: tuple[rsa.RSAPrivateKey, str],
) -> None:
    app, store = app_with_store
    priv, _ = keypair
    body = b'{"event_id":"evt-stale","event_type":"task_created"}'
    old_ts = str(int(time.time()) - 10_000)
    sig = _sign(priv, old_ts, PUBLIC_URL, body)
    resp = _send(
        app,
        body,
        {
            "x-webhook-signature": sig,
            "x-webhook-timestamp": old_ts,
            "content-type": "application/json",
        },
    )
    assert resp.status_code == 401
    assert "skew" in resp.json().get("reason", "")
    assert store.get("evt-stale") is None


def test_tampered_body_rejected(
    app_with_store: tuple[Any, EventStore],
    keypair: tuple[rsa.RSAPrivateKey, str],
) -> None:
    app, store = app_with_store
    priv, _ = keypair
    body = b'{"event_id":"evt-tamper","event_type":"task_created"}'
    ts = str(int(time.time()))
    sig = _sign(priv, ts, PUBLIC_URL, body)
    tampered = b'{"event_id":"evt-tamper","event_type":"task_stopped"}'
    resp = _send(
        app,
        tampered,
        {
            "x-webhook-signature": sig,
            "x-webhook-timestamp": ts,
            "content-type": "application/json",
        },
    )
    assert resp.status_code == 401
    assert store.get("evt-tamper") is None


def test_bad_json_returns_400(
    app_with_store: tuple[Any, EventStore],
    keypair: tuple[rsa.RSAPrivateKey, str],
) -> None:
    app, _ = app_with_store
    priv, _ = keypair
    body = b"not valid json"
    ts = str(int(time.time()))
    sig = _sign(priv, ts, PUBLIC_URL, body)
    resp = _send(
        app,
        body,
        {
            "x-webhook-signature": sig,
            "x-webhook-timestamp": ts,
            "content-type": "application/json",
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "invalid_json"


def test_body_not_object_returns_400(
    app_with_store: tuple[Any, EventStore],
    keypair: tuple[rsa.RSAPrivateKey, str],
) -> None:
    app, _ = app_with_store
    priv, _ = keypair
    body = b'["not", "an", "object"]'
    ts = str(int(time.time()))
    sig = _sign(priv, ts, PUBLIC_URL, body)
    resp = _send(
        app,
        body,
        {
            "x-webhook-signature": sig,
            "x-webhook-timestamp": ts,
            "content-type": "application/json",
        },
    )
    assert resp.status_code == 400
    assert resp.json()["error"] == "body_not_object"


def test_duplicate_event_idempotent(
    app_with_store: tuple[Any, EventStore],
    keypair: tuple[rsa.RSAPrivateKey, str],
) -> None:
    app, store = app_with_store
    priv, _ = keypair
    body = json.dumps(
        {
            "event_id": "evt-dup",
            "event_type": "task_stopped",
            "task_detail": {"task_id": "t-2", "stop_reason": "finish"},
        }
    ).encode("utf-8")
    ts = str(int(time.time()))
    sig = _sign(priv, ts, PUBLIC_URL, body)
    headers = {
        "x-webhook-signature": sig,
        "x-webhook-timestamp": ts,
        "content-type": "application/json",
    }
    r1 = _send(app, body, headers)
    r2 = _send(app, body, headers)
    assert r1.status_code == 200
    assert r2.status_code == 200
    # Single record, despite double POST.
    assert len(store.list(event_type="task_stopped")) == 1


def test_missing_headers_rejected(
    app_with_store: tuple[Any, EventStore],
) -> None:
    app, _ = app_with_store
    body = b"{}"
    resp = _send(app, body, {"content-type": "application/json"})
    assert resp.status_code == 401


def test_create_app_without_public_url_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    settings = Settings(  # type: ignore[call-arg]
        manus_api_key="test",
        manus_webhook_public_url=None,
    )
    with pytest.raises(RuntimeError, match="MANUS_WEBHOOK_PUBLIC_URL"):
        wh_server.create_app(settings)


def test_event_id_synthesized_when_missing(
    app_with_store: tuple[Any, EventStore],
    keypair: tuple[rsa.RSAPrivateKey, str],
) -> None:
    """When Manus omits event_id, we synthesize a stable id and still store the event."""
    app, store = app_with_store
    priv, _ = keypair
    body = json.dumps(
        {
            "event_type": "task_stopped",
            "task_detail": {"task_id": "t-noid"},
        }
    ).encode("utf-8")
    ts = str(int(time.time()))
    sig = _sign(priv, ts, PUBLIC_URL, body)
    resp = _send(
        app,
        body,
        {
            "x-webhook-signature": sig,
            "x-webhook-timestamp": ts,
            "content-type": "application/json",
        },
    )
    assert resp.status_code == 200
    assert "event_id" in resp.json()
    by_task = store.list(task_id="t-noid")
    assert len(by_task) == 1
