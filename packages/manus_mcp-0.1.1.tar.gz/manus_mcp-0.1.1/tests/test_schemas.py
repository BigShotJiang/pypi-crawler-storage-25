"""Round-trip schema tests using sample payloads shaped like the documentation."""

from __future__ import annotations

from manus_mcp.schemas.files import FileCreateResponse, FileRecord
from manus_mcp.schemas.tasks import (
    TaskCreateRequest,
    TaskCreateResponse,
    TaskListMessagesResponse,
    TaskRecord,
)
from manus_mcp.schemas.website import WebsitePublishRequest, WebsiteStatusResponse


def test_task_create_request_mixed_content() -> None:
    req = TaskCreateRequest.model_validate(
        {
            "message": {
                "content": [
                    {"type": "text", "text": "Summarize this file"},
                    {"type": "file", "file_id": "file_abc"},
                ],
                "connectors": ["conn-1"],
                "enable_skills": ["skill-1"],
            },
            "agent_profile": "manus-1.6",
            "share_visibility": "private",
        }
    )
    assert req.message.content and isinstance(req.message.content, list)
    assert req.agent_profile == "manus-1.6"


def test_task_create_response_roundtrip() -> None:
    payload = {
        "ok": True,
        "request_id": "r1",
        "task_id": "t_xyz",
        "task_title": "demo",
        "task_url": "https://manus.im/app/t_xyz",
    }
    resp = TaskCreateResponse.model_validate(payload)
    assert resp.task_id == "t_xyz"
    assert resp.model_dump(exclude_none=True)["task_url"].endswith("t_xyz")


def test_task_record_accepts_extra_fields() -> None:
    record = TaskRecord.model_validate(
        {
            "id": "t1",
            "status": "running",
            "created_at": 1700000000,
            "updated_at": 1700000005,
            "future_field": "ok",
        }
    )
    assert record.status == "running"


def test_task_list_messages_response_with_status_update() -> None:
    payload = {
        "ok": True,
        "request_id": "r",
        "task_id": "t1",
        "messages": [
            {
                "id": "m1",
                "type": "status_update",
                "timestamp": 1,
                "status_update": {
                    "agent_status": "waiting",
                    "status_detail": {
                        "waiting_for_event_id": "evt1",
                        "waiting_for_event_type": "deployAction",
                        "waiting_description": "confirm deploy",
                        "confirm_input_schema": {"type": "object"},
                    },
                    "brief": "waiting",
                },
            }
        ],
        "has_more": False,
    }
    resp = TaskListMessagesResponse.model_validate(payload)
    assert resp.messages[0].status_update is not None
    detail = resp.messages[0].status_update.status_detail
    assert detail and detail.waiting_for_event_type == "deployAction"


def test_file_create_response() -> None:
    resp = FileCreateResponse.model_validate(
        {
            "ok": True,
            "request_id": "r",
            "file": {"id": "f", "filename": "a.pdf", "status": "pending"},
            "upload_url": "https://s3.example/put",
            "upload_expires_at": 1700000000,
        }
    )
    assert resp.file.id == "f"
    assert resp.upload_url.startswith("https://")


def test_file_record_status_enum() -> None:
    r = FileRecord.model_validate({"id": "f", "status": "uploaded"})
    assert r.status == "uploaded"


def test_website_publish_request_requires_exactly_one_id() -> None:
    import pytest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        WebsitePublishRequest.model_validate({})
    with pytest.raises(ValidationError):
        WebsitePublishRequest.model_validate({"task_id": "t", "website_id": "w"})
    WebsitePublishRequest.model_validate({"task_id": "t"})
    WebsitePublishRequest.model_validate({"website_id": "w", "visibility": "public"})


def test_website_status_response() -> None:
    resp = WebsiteStatusResponse.model_validate(
        {
            "ok": True,
            "request_id": "r",
            "website_id": "w1",
            "publish_status": "published",
            "site_urls": ["https://abc.manus.space"],
            "version_id": "v1",
        }
    )
    assert resp.publish_status == "published"
    assert resp.site_urls[0].endswith("manus.space")
