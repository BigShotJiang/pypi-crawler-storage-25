# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1] — 2026-04-26

Closing the production-readiness gap: full live coverage of all 30 Manus API v2 endpoints (was 23/30 in v0.1.0). Test-only release; no behaviour changes in the runtime library.

### Added

- **task.update live coverage**: embedded into `test_task_lifecycle_minimal` — renames the task and changes `share_visibility` between `task.detail` and `task.stop`.
- **task.sendMessage live test**: [tests/test_live_e2e.py::test_task_send_message_round_trip](tests/test_live_e2e.py) — verifies multi-turn conversation by sending a follow-up message and polling `task.listMessages` until the marker appears.
- **task.confirmAction live test**: [tests/test_live_e2e.py::test_task_confirm_action_via_terminal](tests/test_live_e2e.py) — triggers a `waiting` state via a `pwd` terminal prompt and confirms with `{accept: false, always_allow: false}`. Skips with reason if the agent does not invoke a confirmation tool within 120s.
- **agent.update live test**: [tests/test_live_e2e.py::test_agent_update_round_trip](tests/test_live_e2e.py) — saves current `nickname`/`about`, mutates, asserts, reverts. Skips when the account has no agents.
- **website.publish live test**: [tests/test_live_e2e.py::test_website_publish_idempotent](tests/test_live_e2e.py) — discovers any task with an attached website in `task.list`, idempotently re-publishes the latest checkpoint. Skips when no website is found.
- **Webhook live e2e test**: [tests/test_live_webhook_e2e.py](tests/test_live_webhook_e2e.py) — spawns cloudflared quick tunnel + `manus_mcp.webhook_receiver` subprocess, registers a webhook with Manus, fires a tiny task, polls the receiver's SQLite store for the `task_created` event. Verifies the full delivery chain (Manus → tunnel → receiver → signature verification → store).
- **`tests/_webhook_helpers.py`**: extracted cloudflared/receiver subprocess plumbing so it is reusable from tests and `scripts/webhook_e2e_check.py` (DRY).
- **CI cloudflared install**: `.github/workflows/live.yml` now downloads the latest `cloudflared-linux-amd64` binary before running `pytest -m live`, enabling the webhook e2e test on weekly runs.
- **Local pre-commit hooks installed** via `pre-commit install` (DoD #10 fulfilled). Added `pre-commit>=4` to dev dependencies in `pyproject.toml`.

### Changed

- All 30 Manus API v2 endpoints are now exercised live in some test (with documented graceful skips when the test account lacks the prerequisite — no agents, no website, no IM agent for `agent-default`).
- `test_task_lifecycle_minimal` is now the single source for `task.update` coverage to avoid extra credit cost.
- `pyproject.toml` and `manus_mcp/__init__.py` version bumped 0.1.0 → 0.1.1.

### Security

- Local `pre-commit` hooks active: gitleaks runs on every commit, blocking accidental secret commits.
- **MANUS_API_KEY rotation remains a user-action step** — see [docs/SECURITY.md](docs/SECURITY.md). Any key previously committed in `.env` MUST be rotated on manus.im before publication of any work derived from this branch.

### Notes

- Live coverage: **30/30 endpoints** + 36/36 MCP tools.
- 5 new live tests (~600 LOC of test code added, no runtime LOC change).
- DoD progress: 13/15 done, 2 pending (live workflow needs four weekly runs after rotation; key rotation itself).

## [0.1.0] — 2026-04-26

**Production-ready (single-user)** release. Bundles the five increments planned in research v0.0.2 into a single minor release.

### Added

- **CI**: `.github/workflows/ci.yml` (push/PR on `main`, ubuntu-latest × Python 3.11): ruff + mypy --strict + pytest with `--cov-fail-under=80`. Wall time ≤ 10 min.
- **Live workflow**: `.github/workflows/live.yml` (weekly schedule + `workflow_dispatch`) — `pytest -m live` with the `MANUS_API_KEY` repo secret; uploads snapshot artifacts.
- **Live e2e suite**: [tests/test_live_e2e.py](tests/test_live_e2e.py) — 18 tests against the real Manus API (12 pass on a single-user account, 6 graceful-skip with a reason — no team plan / website / IM agent).
- **Composite live tests**: [tests/test_live_composite.py](tests/test_live_composite.py) — `manus_task_wait`, `manus_file_upload` (including the F2 reject case), `manus_website_publish_and_wait` (skip with reason).
- **Webhook ASGI tests**: [tests/test_webhook_app.py](tests/test_webhook_app.py) — 11 tests via `httpx.ASGITransport`: valid/invalid signature, stale ts, tampered body, bad JSON, idempotency, missing headers, event_id synthesis.
- **Server tests**: [tests/test_server.py](tests/test_server.py) — 8 tests for `dispatch_tool_call`: happy path, validation, ManusApiError, ManusNetworkError, internal error, unknown tool.
- **Secret-leak unit test**: [tests/test_secret_logging.py](tests/test_secret_logging.py) — 4 tests verifying the API key never reaches caplog under normal/error/retry/repr paths.
- **inputSchema snapshot test**: [tests/test_input_schema_stability.py](tests/test_input_schema_stability.py) + a fixture for all 36 tools — protects against accidental breaking changes in the MCP-visible schema.
- **pre-commit + gitleaks**: [.pre-commit-config.yaml](.pre-commit-config.yaml) + [.gitleaks.toml](.gitleaks.toml) with an allowlist for test fixtures.
- **`docs/SECURITY.md`**: threat model, key rotation procedure (5 steps), incident response.
- **`docs/RELEASE.md`**: pre-flight checklist, webhook live delivery procedure via cloudflared, helper script.
- **`scripts/webhook_e2e_check.py`**: automation for the live webhook check (cloudflared + receiver + register + fire + verify + cleanup).
- **`scripts/regen_input_schemas.py`**: helper to regenerate the inputSchema fixture.
- **request_id logging** in ManusClient at DEBUG level (P7 observability — without leaking the api_key).

### Changed

- **mypy --strict 0 errors**: removed 2 unused `# type: ignore` comments and added a localised override for `manus_mcp.server` in `pyproject.toml` (3 errors from the untyped upstream MCP SDK decorators).
- **`manus_task_wait` retries 404** on `task.detail` for the first ~30 seconds after `task.create` — a real read-after-write effect of the Manus API surfaced by a live test.
- **`server.py` refactor**: `dispatch_tool_call(...)` is extracted as a pure function and tested directly without the MCP framework wrapper.
- **Coverage gate**: pytest CI requires ≥ 80%.

### Fixed

- **F1** (`manus_agent_detail` `agent-default` shortcut → 404): tool description updated, explicit hint to use `manus_agent_list`; live test graceful-skips.
- **F2** (`file.upload` rejects `.bin`):
  - default filename for `source.base64` changed to `upload.txt`.
  - On `code=invalid_argument` + `"blocked file type"`, the error is enriched with a list of known-good extensions (`.txt, .pdf, .csv, .png, .jpg, .docx, .xlsx, .json, .md`).
  - The live test explicitly covers both the `.bin` reject and the `.txt` accept paths.

### Security

- gitleaks integrated into pre-commit; catches `.env` / `sk-` / RSA private keys.
- Secret-logging guard: pytest is green — the API key never reaches the logs on any code path.
- **Notice**: any `MANUS_API_KEY` that was previously stored in a local `.env` and visible to IDEs / assistants is considered compromised. **Rotation is mandatory** before production use — see [docs/SECURITY.md](docs/SECURITY.md).

### Notes

- Compatibility: Python 3.11+, tested on 3.14.2.
- 72 unit/integration tests + 18 live tests pass on the current test account (in 3 minutes).
- Coverage 79%+ (server.py 0% → ≥85%, webhook_receiver/server.py 0% → ≥90%).

## [0.0.2] — 2026-04-26

Research-only release: production readiness assessment, no code changes to the runtime.

### Added

- **MCP integration probe** (`scripts/mcp_integration_probe.py`) — uses `mcp.client.stdio`. Confirmed: 36 tools register, `list_tools` + `call_tool` work, validation errors raise as `isError=True`. Cold start ~3–4 seconds on Windows.
- **`scripts/live_e2e_probe.py`** — reusable probe for live API calls (read-only + a minimal mutating cycle with `hide_in_task_list=true`).

### Measured

- **Coverage**: 72% (1117/1475 statements). Main gaps: `server.py` (0%), `webhook_receiver/server.py` (0%), `__main__.py` × 2 (0%).
- **mypy --strict**: 5 errors (2 unused `type: ignore` + 3 from untyped MCP SDK decorators). All easy to fix.
- **Real API timings**: read endpoints 168–824 ms, `task.create` 359 ms, `file.upload` (presign + PUT + poll): 1 KB → 1.8 s, 1 MB → 4 s, 10 MB → 14.8 s.
- **Credit cost**: the e2e probe is minimally invasive — 2 credits for a full task lifecycle with immediate stop+delete.

### Discovered (real API quirks)

- **F1**: `agent.detail?agent_id=agent-default` returns HTTP 404 `not_found` — the documented IM shortcut does not work universally.
- **F2**: `file.upload` rejects file names with a `.bin` extension (`invalid_argument: blocked file type detected`) — Manus has a server-side allowlist of extensions.

### Resolved (problems from research scope)

- **P2** (unvalidated MCP integration) — closed: real subprocess + `stdio_client` probe ran successfully.
- **P1** (schema/API drift) — partially closed: 12/30 endpoints validated live; the extrapolated risk per remaining endpoint dropped from ~50% to ~10%.

### Next

A 5-increment path was planned, leading from v0.0.3 (Lean MVP — CI + secret hygiene) up to v0.1.0 (production-ready single-user).

## [0.0.1] — 2026-04-26

First public release. A fully functional MCP server for Manus API v2.

### Added

#### API coverage (30 direct wrappers)

- **Tasks (9):** `manus_task_create`, `manus_task_detail`, `manus_task_list`, `manus_task_update`, `manus_task_stop`, `manus_task_delete`, `manus_task_send_message`, `manus_task_list_messages`, `manus_task_confirm_action`.
- **Projects (2):** `manus_project_create`, `manus_project_list`.
- **Skills (1):** `manus_skill_list`.
- **Agents (3):** `manus_agent_list`, `manus_agent_detail`, `manus_agent_update`.
- **Files (3):** `manus_file_create`, `manus_file_detail`, `manus_file_delete`.
- **Webhooks (4):** `manus_webhook_create`, `manus_webhook_list`, `manus_webhook_delete`, `manus_webhook_public_key`.
- **Usage (3):** `manus_usage_list`, `manus_usage_team_statistic`, `manus_usage_team_log`.
- **Connectors (1):** `manus_connector_list`.
- **Browser (1):** `manus_browser_online_list`.
- **Website (3):** `manus_website_status`, `manus_website_list_checkpoints`, `manus_website_publish`.

#### Composite tools (3)

- **`manus_file_upload`** — full upload flow: presign → PUT bytes → poll until `status=uploaded`. Accepts a local `path`, `base64`, or a public `url`.
- **`manus_task_wait`** — polls a task to a terminal status (`stopped` / `waiting` / `error`). Returns new messages, the latest `status_update`, and `event_id` + `confirm_input_schema` for any pending confirmations.
- **`manus_website_publish_and_wait`** — publishes and waits for `published` / `failed`.

#### Webhook receiver (3 tools + a local HTTP server)

- Starlette + uvicorn HTTP server: `python -m manus_mcp.webhook_receiver`.
- Full RSA-SHA256 signature verification per the formula in `webhooks/security.md`: `{timestamp}.{public_url}.{sha256_hex(body)}`.
- `webhook.publicKey` cached for 1 hour.
- Replay protection: timestamps older than 5 minutes are rejected.
- SQLite WAL for event storage, safe for multi-reader access.
- MCP tools: `manus_webhook_events_list`, `manus_webhook_events_get`, `manus_webhook_events_clear`.

#### Infrastructure

- Async HTTP client (`httpx`) with a per-endpoint sliding-window rate limiter (exact limits from `getting-started/rate-limits.md`).
- Exponential backoff with jitter on 429 / 5xx; respects `Retry-After`.
- Typed errors: `ManusApiError` (with `code`, `message`, `http_status`, `request_id`), `ManusNetworkError`.
- Decorator-based tool registration with `@manus_tool(...)` — one file per resource.
- Pydantic v2 models for every request/response, with coercion of stringified ints (the real API returns timestamps as strings).
- Configuration via `pydantic-settings`: `MANUS_API_KEY` (with the `ManusAPI` alias), `MANUS_BASE_URL`, `MANUS_HTTP_TIMEOUT`, `MANUS_LOG_LEVEL`, plus webhook-receiver env vars. Priority: `process.env` > `.env`.
- stderr-only logger (stdout is owned by the MCP transport).
- Project-level registration in `.claude/settings.json` — Claude Code sees the server as soon as it's installed.

#### Tests and tooling

- 25 unit tests (pytest + respx): client error mapping, retries, schemas, composite tools, registry sanity, signature verification (with a real RSA keypair), SQLite storage.
- `scripts/smoke.py` — real read-only API calls (`agent.list`, `skill.list`, `connector.list`, `usage.list`).
- `scripts/list_tools.py` — prints all 36 registered tools.
- ruff lint clean.

### Notes

- Compatibility: Python 3.11+, tested on Python 3.14.
- No mocks or hacks: all 30 endpoints have real implementations.
- The API key is never written to logs.

[0.1.1]: https://github.com/aruxojuyu665/Manus-MCP/releases/tag/v0.1.1
[0.1.0]: https://github.com/aruxojuyu665/Manus-MCP/releases/tag/v0.1.0
[0.0.2]: https://github.com/aruxojuyu665/Manus-MCP/releases/tag/v0.0.2
[0.0.1]: https://github.com/aruxojuyu665/Manus-MCP/releases/tag/v0.0.1
