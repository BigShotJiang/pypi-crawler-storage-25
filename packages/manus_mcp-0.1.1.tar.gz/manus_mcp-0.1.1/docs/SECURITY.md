# Security

This document describes the security model of Manus MCP and the procedures for handling secrets, key rotation, and incident response.

## Secrets in scope

| Secret | Where used | Storage |
|--------|------------|---------|
| `MANUS_API_KEY` | Manus API authentication via `x-manus-api-key` header | `.env` (local) + GitHub Actions repo secret (CI live workflow) |
| Optional `MANUS_WEBHOOK_PUBLIC_URL` | Webhook receiver: this URL is part of the signed payload | `.env` (local) |
| Webhook RSA public key | Fetched dynamically from Manus via `webhook.publicKey`; cached 1h in-memory | not persisted |

Anything else (RSA private keys for tests, dummy CI key) is generated ephemerally and never committed.

## Threat model

| Threat | Mitigation |
|--------|-----------|
| API key leak via git history | `.gitignore` excludes `.env`; `gitleaks` runs in pre-commit; CI scan via `live` workflow does not echo the key. |
| API key in logs | `tests/test_secret_logging.py` asserts on every normal/error/retry path that the key does not appear in `caplog`. ManusClient logs only method + path + status + duration + request_id. |
| Webhook replay | `webhook_receiver/signature.py` rejects timestamps older than 5 minutes. |
| Webhook impersonation | RSA-SHA256 signature verified against the Manus public key (`webhook.publicKey`, cached 1h). |
| `pull_request_target` exfiltration of secrets via untrusted PR | We do not use `pull_request_target` in workflows. Live workflow runs only on `main` push and manual `workflow_dispatch`. |
| API key copied into chat / IDE screenshots | Documented as a real-world risk; rotation procedure below. |

## Required rotation before v0.1.0 publication

> **The `MANUS_API_KEY` currently in `.env` was opened in the IDE and was visible in assistant chat sessions. It MUST be considered compromised and rotated before v0.1.0 is published or used for production traffic.**

### Rotation procedure

1. **Generate a new key**
   - Go to <https://manus.im/app/settings/api>
   - Click **Create API Key**, give it a descriptive name (e.g. `manus-mcp-prod-2026-04`).
   - Copy the key. It will be shown only once.

2. **Push to GitHub Actions secret**
   ```bash
   echo "<NEW_KEY>" | gh secret set MANUS_API_KEY --repo aruxojuyu665/Manus-MCP
   ```

3. **Update local `.env`**
   - Replace `ManusAPI=...` (or `MANUS_API_KEY=...`) with the new value.
   - Verify: `python scripts/smoke.py` returns data.

4. **Restart Claude Code** (so the MCP server subprocess picks up the new env).

5. **Revoke the old key**
   - Back in <https://manus.im/app/settings/api>, find the old key, click **Revoke**.
   - Confirm the smoke test still passes (using the new key).

### How to detect compromise

- Sudden unexplained credit consumption in `manus_usage_list` (run `python scripts/smoke.py` weekly).
- Unfamiliar tasks in `manus_task_list` that you did not create.
- GitHub secret-scanning alerts on `aruxojuyu665/Manus-MCP`.
- Gitleaks output in pre-commit / CI showing matches.

### Incident response

If compromise is suspected:

1. Immediately revoke the suspect key in <https://manus.im/app/settings/api>.
2. Generate a new one and follow the rotation procedure above.
3. Audit `manus_usage_list` for unexpected spend; contact Manus support if substantial credits were consumed.
4. Audit `manus_task_list` and `manus_webhook_list` for unauthorized resources; delete them.
5. Document the incident date and remediation in this file, in a new "Incidents" section below.

## Secret hygiene checklist (release pre-flight)

- [ ] `gitleaks detect --source . --no-banner` returns 0 findings.
- [ ] `pytest tests/test_secret_logging.py` is green.
- [ ] `git log --all -p | grep -E "sk-[A-Za-z0-9_-]{40,}"` returns nothing (or only the placeholder `sk-PROBE-SECRET-XYZ` from tests).
- [ ] `.env` is not staged.
- [ ] Old API key has been revoked at manus.im.

## Reporting vulnerabilities

Open a private security advisory on <https://github.com/aruxojuyu665/Manus-MCP/security/advisories/new>. Do not file a public issue.
