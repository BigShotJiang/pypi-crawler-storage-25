# Release procedure

Steps for cutting a new tagged release of Manus MCP.

## Pre-flight checklist

- [ ] CI workflow `ci.yml` is green on `main`.
- [ ] `mypy --strict manus_mcp` returns 0 errors.
- [ ] `ruff check manus_mcp tests scripts` returns 0 errors.
- [ ] `pytest -m "not live" --cov=manus_mcp --cov-fail-under=80` passes.
- [ ] `pytest -m live` passes against your production Manus account (or at least all non-skipped tests).
- [ ] CHANGELOG entry for the new version is written.
- [ ] `pyproject.toml` and `manus_mcp/__init__.py` versions match the new tag.
- [ ] Webhook live delivery has been verified end-to-end (see below).
- [ ] `gitleaks detect --source . --no-banner` returns 0 findings.
- [ ] If MANUS_API_KEY was rotated since the last release, GitHub Actions secret has been updated.

## Webhook live delivery check

Required once per release to validate the receiver against real Manus deliveries (the only path that can detect signature-format drift).

### 1. Start the receiver

```bash
.venv/Scripts/python.exe -m manus_mcp.webhook_receiver
```

This binds to `127.0.0.1:8787` by default (override with `MANUS_WEBHOOK_HOST` / `MANUS_WEBHOOK_PORT`).

### 2. Open a public tunnel

In a second terminal:

```bash
cloudflared tunnel --url http://localhost:8787
```

cloudflared prints a `https://<random>.trycloudflare.com` URL.

### 3. Configure the public URL

```bash
# Powershell
$env:MANUS_WEBHOOK_PUBLIC_URL = "https://<random>.trycloudflare.com/manus/webhook"
```

Restart the receiver so the new public URL is included in signature verification.

### 4. Register the webhook

From Claude Code (or via curl):

```text
manus_webhook_create { "url": "https://<random>.trycloudflare.com/manus/webhook" }
```

Capture the returned `webhook.id`.

### 5. Fire a test task

```text
manus_task_create { "message": { "content": "release-check ping" }, "hide_in_task_list": true }
```

### 6. Wait and verify

Poll `manus_webhook_events_list` until at least two events appear:

- `task_created` (immediately)
- `task_stopped` (after the agent finishes or stops)

If neither arrives within 2-3 minutes, check:

- Receiver process is still alive and listening.
- cloudflared tunnel is healthy (`cloudflared tunnel info`).
- `MANUS_WEBHOOK_PUBLIC_URL` matches the URL passed to `manus_webhook_create` exactly.
- `pytest tests/test_webhook_signature.py` is still green (signature math has not regressed).

### 7. Cleanup

```text
manus_webhook_delete { "webhook_id": "<id>" }
manus_webhook_events_clear {}
```

Stop cloudflared and the receiver.

### 8. Use the helper

`scripts/webhook_e2e_check.py` automates steps 1-7 (provided cloudflared is on PATH). Run with `MANUS_API_KEY` set:

```bash
.venv/Scripts/python.exe scripts/webhook_e2e_check.py
```

## Cutting the tag

Once the checklist is fully ticked:

```bash
# Bump version in pyproject.toml and manus_mcp/__init__.py
git add pyproject.toml manus_mcp/__init__.py CHANGELOG.md
git commit -m "release: vX.Y.Z"
git tag -a vX.Y.Z -m "Release vX.Y.Z"
git push origin main --tags
```

## Publishing the GitHub Release

```bash
gh release create vX.Y.Z \
  --title "vX.Y.Z" \
  --notes-from-tag
```

Or, if you want a longer description, write `notes.md` and pass `--notes-file notes.md`. The notes should at minimum link to the corresponding CHANGELOG section.

## Post-release

- Verify <https://github.com/aruxojuyu665/Manus-MCP/releases> shows the new version.
- If this release added new tools, update the `.claude/settings.json` snippet in `README.md` if applicable.
