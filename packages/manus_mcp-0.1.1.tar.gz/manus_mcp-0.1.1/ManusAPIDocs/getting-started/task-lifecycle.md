# Task Lifecycle

After creating a task with `task.create`, the agent runs asynchronously. Use `task.listMessages` to poll for events and track progress, or set up [Webhooks](../webhooks/overview.md) to receive push notifications when task status changes.

```bash
curl 'https://api.manus.ai/v2/task.listMessages?task_id=YOUR_TASK_ID&order=desc&limit=10' \
  -H 'x-manus-api-key: YOUR_API_KEY'
```

## Task Status

Look for `status_update` events in the response. The `agent_status` field tells you what to do next:

| `agent_status` | Meaning | Action |
|---|---|---|
| `running` | Agent is working | Keep polling |
| `stopped` | Task completed | Read `assistant_message` events for results |
| `waiting` | Needs user confirmation or input | Handle based on event type (see below) |
| `error` | Task failed | Read `error_message` for details |

## Handling `waiting` Status

When `agent_status` is `waiting`, the `status_detail` tells you what the agent needs:

```json
{
    "type": "status_update",
    "status_update": {
        "agent_status": "waiting",
        "status_detail": {
            "waiting_for_event_id": "evt_abc123",
            "waiting_for_event_type": "gmailSendAction",
            "waiting_description": "Send email to user@example.com",
            "confirm_input_schema": {
                "type": "object",
                "properties": {
                    "accept": { "type": "boolean" },
                    "save_draft": { "type": "boolean" }
                }
            }
        }
    }
}
```

There are two ways to respond, depending on `waiting_for_event_type`:

- **`messageAskUser`** — The agent is asking a question. Reply with `task.sendMessage`. Do **not** use `task.confirmAction`.
- **All other types** — Confirm or reject via `task.confirmAction`. The `confirm_input_schema` field in the event is a JSON Schema describing the expected input format — use it to validate or dynamically build the confirmation payload.

## Using `task.confirmAction`

```bash
curl -X POST 'https://api.manus.ai/v2/task.confirmAction' \
  -H 'x-manus-api-key: YOUR_API_KEY' \
  -H 'Content-Type: application/json' \
  -d '{
    "task_id": "YOUR_TASK_ID",
    "event_id": "evt_abc123",
    "input": { "accept": true }
  }'
```

The input format varies by `waiting_for_event_type`. The table below lists currently supported event types — new types may be added in the future. Always check the `confirm_input_schema` returned in each event for the definitive schema.

| Event Type | Description | Example Input |
|---|---|---|
| `needConnectMyBrowser` | Select a browser from `browser.onlineList`, or skip | `{ "action": "select", "client_id": "..." }` or `{ "action": "skip" }` |
| `gmailSendAction` | Confirm send, or save as draft | `{ "accept": true }` or `{ "accept": true, "save_draft": true }` |
| `outlookSendMailsAction` | Confirm send, or save as draft | `{ "accept": true }` or `{ "accept": true, "save_draft": true }` |
| `deployAction` | Confirm deploy. Set `global_allow` to skip future confirmations | `{ "accept": true, "global_allow": true }` |
| `terminalExecute` | Confirm command. Set `always_allow` to skip future confirmations | `{ "accept": true, "always_allow": true }` |
| `videoGenerate` | Select video quality: `standard` (default) or `premium` | `{ "choice": "standard" }` |
| `apiHighCreditNotice` | Respond to high-credit notice: `accept`, `reject`, or `do_not_show_again` | `{ "action": "accept" }` |
| `googleCalendarCreate` | Confirm calendar event creation | `{ "accept": true }` |
| `googleCalendarUpdate` | Confirm calendar event update | `{ "accept": true }` |
| `googleCalendarDelete` | Confirm calendar event deletion | `{ "accept": true }` |
| `outlookCalendarCreate` | Confirm calendar event creation | `{ "accept": true }` |
| `outlookCalendarUpdate` | Confirm calendar event update | `{ "accept": true }` |
| `outlookCalendarDelete` | Confirm calendar event deletion | `{ "accept": true }` |
| `metaMarketingAction` | Confirm marketing action. Optionally select ad accounts via `selectedAccountIds` | `{ "accept": true, "selectedAccountIds": ["act_123"] }` |
| `metaMarketingActionResult` | Confirm marketing result. Optionally specify mode | `{ "accept": true }` |
| `webdevRunAction` | Run web app. `mode`: `quality` / `speed` (default) / `max` | `{ "accept": true, "mode": "speed" }` |
| `webdevRunAction` (deploy) | Deploy web app. `visibility`: `owner` (default) / `team` / `public` | `{ "accept": true, "visibility": "owner" }` |
| `webdevRequestSecrets` | Provide secrets as `[{key, value}]` array, or reject with `accept: false` | `{ "accept": true, "secrets": [{"key": "X", "value": "Y"}] }` |
| `connectorOauthExpired` | Re-authorize expired connector | `{ "accept": true }` |
| `mapreduceAction` | Confirm map-reduce operation | `{ "accept": true }` |

> **Note:** For event types that support `accept`, passing `accept: false` will not produce any event — the task remains in `waiting` status. **Exception:** `webdevRequestSecrets` where `accept: false` explicitly rejects the request.

## Using My Browser

You can let the agent use your local browser. When the agent needs a browser during execution, it will trigger a `needConnectMyBrowser` waiting event. Use `browser.onlineList` to get available clients, then select one via `task.confirmAction`:

```bash
# 1. Get online browser clients
curl 'https://api.manus.ai/v2/browser.onlineList' \
  -H 'x-manus-api-key: YOUR_API_KEY'

# 2. When needConnectMyBrowser event is received, select a browser
curl -X POST 'https://api.manus.ai/v2/task.confirmAction' \
  -H 'x-manus-api-key: YOUR_API_KEY' \
  -H 'Content-Type: application/json' \
  -d '{
    "task_id": "YOUR_TASK_ID",
    "event_id": "evt_abc123",
    "input": { "action": "select", "client_id": "0e9ad711-8471-4fcc-a9de-8309f0f12c87" }
  }'
```

If `browser.onlineList` returns an empty list, no browser clients are online. Install and enable the Manus Browser Extension first.

## Complete Flow

```
1. POST /v2/task.create          → Create task
2. GET  /v2/task.listMessages    → Poll for events
   ├─ agent_status=running       → Keep polling
   ├─ agent_status=waiting       → Check waiting_for_event_type
   │   ├─ messageAskUser         → POST /v2/task.sendMessage
   │   ├─ needConnectMyBrowser   → POST /v2/task.confirmAction (select browser)
   │   └─ Other types            → POST /v2/task.confirmAction (confirm/reject)
   ├─ agent_status=stopped       → Task complete, read results
   └─ agent_status=error         → Task failed, read error details
```
