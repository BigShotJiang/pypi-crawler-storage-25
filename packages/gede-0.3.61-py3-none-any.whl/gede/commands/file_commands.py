# coding=utf-8
#
# file_commands.py
# File-related commands
#

import os
import json
import asyncio
import logging
from dataclasses import dataclass
from typing import Optional, Union
from pathlib import Path

from prompt_toolkit.application import Application
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import HSplit, Window
from prompt_toolkit.layout.controls import FormattedTextControl, BufferControl
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.patch_stdout import patch_stdout
from rich.prompt import Prompt

from ..top import gede_dir
from .base import CommandBase
from ..chatcore import (
    ExportChat,
    load_private_chats_files,
    load_public_chats_files,
    ChatModel,
)
from my_llmkit.chat import ContentBlock
from my_llmkit.chat.types import TextContent, ImageContent

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Chat search index
# ---------------------------------------------------------------------------

@dataclass
class ChatIndexEntry:
    filename: str
    title: str
    text: str     # merged text of all messages (for searching)
    preview: str  # first user message snippet (for display)


# Module-level cache — valid for the entire process session
_chat_search_index: Optional[list[ChatIndexEntry]] = None


def _extract_text_from_content(content) -> str:
    """Convert message content (str or list[ContentBlock dict]) to plain text."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    parts.append(block.get("text", ""))
            elif isinstance(block, TextContent):
                parts.append(block.text)
            # skip image blocks
        return " ".join(p for p in parts if p)
    return str(content)


def _build_chat_search_index() -> list[ChatIndexEntry]:
    """Scan all public chat files and build an in-memory search index."""
    chat_dir = os.path.join(gede_dir(), "chats", "public")
    if not os.path.exists(chat_dir):
        os.makedirs(chat_dir)

    entries: list[ChatIndexEntry] = []
    for filename in sorted(os.listdir(chat_dir), reverse=True):
        if not filename.endswith(".json"):
            continue
        filepath = os.path.join(chat_dir, filename)
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            logger.warning("Failed to load %s for search index: %s", filename, e)
            continue

        title = data.get("title", "")
        if not title or title in ("New Chat", "Untitled"):
            title = ""

        text_parts: list[str] = [title]
        preview = ""
        messages = data.get("messages", [])
        for msg in messages:
            role = msg.get("role", "")
            if role == "system":
                continue
            msg_text = _extract_text_from_content(msg.get("content", ""))
            if msg_text:
                text_parts.append(msg_text)
                if not preview and role == "user":
                    preview = msg_text[:80]

        if not title and preview:
            title = preview[:40]

        entries.append(ChatIndexEntry(
            filename=filename,
            title=title,
            text=" ".join(text_parts),
            preview=preview,
        ))

    logger.debug("Built chat search index with %d entries", len(entries))
    return entries


def _get_chat_search_index() -> list[ChatIndexEntry]:
    """Return the cached index, building it on first call."""
    global _chat_search_index
    if _chat_search_index is None:
        _chat_search_index = _build_chat_search_index()
    return _chat_search_index


def _search_chats(query: str, index: list[ChatIndexEntry]) -> list[ChatIndexEntry]:
    """Case-insensitive substring search across title + message text."""
    if not query.strip():
        return list(index)
    q = query.lower()
    return [e for e in index if q in e.title.lower() or q in e.text.lower()]


# ---------------------------------------------------------------------------
# fzf-like interactive UI
# ---------------------------------------------------------------------------

async def _run_search_ui(index: list[ChatIndexEntry]) -> Optional[str]:
    """
    Show an interactive fzf-like full-screen selector.
    Returns the selected filename, or None if cancelled.
    """
    results: list[ChatIndexEntry] = list(index)
    selected_index = [0]
    selected_filename: list[Optional[str]] = [None]
    done = [False]

    def _esc(s: str) -> str:
        """Escape HTML special chars for use inside prompt_toolkit HTML()."""
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def get_results_text() -> HTML:
        count = len(results)
        html_parts = [
            f"<style bg='#1e1e2e' fg='#cdd6f4'>"
            f"  {count} result(s)  "
            f"[↑↓ navigate · Enter select · Esc cancel]"
            f"</style>\n"
        ]
        visible_start = max(0, selected_index[0] - 8)
        visible_end = min(len(results), visible_start + 18)
        for i in range(visible_start, visible_end):
            entry = results[i]
            name_part = _esc(entry.filename.replace(".json", ""))
            title_part = _esc((entry.title or entry.preview or "(no title)")[:50])
            if i == selected_index[0]:
                html_parts.append(
                    f"<style bg='#313244' fg='#89b4fa'>"
                    f" ▶ {name_part}  {title_part}"
                    f"</style>\n"
                )
            else:
                html_parts.append(
                    f"<style fg='#a6adc8'>"
                    f"   {name_part}  {title_part}"
                    f"</style>\n"
                )
        return HTML("".join(html_parts))

    def on_text_changed(buf):
        query = buf.text
        new_results = _search_chats(query, index)
        results.clear()
        results.extend(new_results)
        selected_index[0] = 0
        app.invalidate()

    search_buffer = Buffer(name="search", on_text_changed=on_text_changed)

    kb = KeyBindings()

    @kb.add("up")
    def move_up(event):
        if selected_index[0] > 0:
            selected_index[0] -= 1
        app.invalidate()

    @kb.add("down")
    def move_down(event):
        if selected_index[0] < len(results) - 1:
            selected_index[0] += 1
        app.invalidate()

    @kb.add("enter")
    def confirm(event):
        if results:
            selected_filename[0] = results[selected_index[0]].filename
        done[0] = True
        app.exit()

    @kb.add("escape")
    @kb.add("c-c")
    def cancel(event):
        done[0] = True
        app.exit()

    layout = Layout(
        HSplit([
            Window(
                content=FormattedTextControl(text=get_results_text, focusable=False),
                height=20,
            ),
            Window(height=1, char="─"),
            Window(
                content=BufferControl(buffer=search_buffer, focusable=True),
                height=1,
                get_line_prefix=lambda lineno, wrap_count: HTML(
                    "<style fg='#89b4fa'>  Search: </style>"
                ),
            ),
        ])
    )

    app = Application(layout=layout, key_bindings=kb, full_screen=False, mouse_support=False)
    await app.run_async()
    return selected_filename[0]


def format_message_content(content: Union[str, list]) -> str:
    """将消息内容转换为可安全显示的字符串，图片显示为占位符。"""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, TextContent):
                parts.append(block.text)
            elif isinstance(block, ImageContent):
                parts.append("[🖼 图片]")
            else:
                parts.append(f"[{type(block).__name__}]")
        return "\n".join(parts)
    return str(content)


class PublicChatFileCompleter(Completer):
    def get_completions(self, document, complete_event):
        files = load_public_chats_files()
        text = document.text.lower()
        for one in files:
            if text in one[0].lower():
                yield Completion(
                    text=one[1], start_position=-len(document.text), display=one[0]
                )


class PrivateChatFileCompleter(Completer):
    def get_completions(self, document, complete_event):
        files = load_private_chats_files()
        text = document.text.lower()
        for one in files:
            if text in one.lower():
                yield Completion(one, start_position=-len(document.text))


class SaveCommand(CommandBase):
    async def do_command_async(self) -> bool:
        if self.message == "/save":
            if self.context.current_chat.is_private:
                password = Prompt.ask(
                    "[bold dim]Input password for private chat[/bold dim]",
                    password=True,
                )
                password = password.strip()
                if not password:
                    self.context.notification_display.warning(
                        "Password cannot be empty."
                    )
                    return False
                self.context.current_chat.private_password = password

            await self.context.current_chat.geneate_title()

            # Need to generate filename before saving
            self.context.current_chat.generate_filename()
            filepath = self.context.current_chat.save()
            if filepath:
                self.context.notification_display.success(
                    f"Chat saved successfully in {filepath}. Title: {self.context.current_chat.title}"
                )
            else:
                self.context.notification_display.warning("Not saved")
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/save\nPersist current chat to disk"

    @property
    def doc_description(self) -> str:
        return "Save the current chat to disk. Public chats auto-save with generated titles. Private chats require a password for encryption and must be manually saved. Files are stored in ~/.gede/chats/."

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/save"


class LoadChatCommand(CommandBase):
    async def pick_file(self) -> Optional[str]:
        completion = PublicChatFileCompleter()
        self.context.notification_display.info(
            "Type to search for chat files, use arrow keys to select."
        )
        try:
            with patch_stdout():
                filename: str = await self.context.prompt_session.prompt_async(
                    "Select Chat: ",
                    completer=completion,
                    complete_while_typing=True,
                    complete_in_thread=False,
                )
                # self.console.print("You selected: " + filename, style="info")
                return filename
        except KeyboardInterrupt:
            return None

    async def do_command_async(self) -> bool:
        cmd = "/load-chat"
        if self.message.startswith(cmd):
            # filename = self.message[len(cmd) :].strip()
            filename = await self.pick_file()
            if not filename:
                self.context.notification_display.warning("Filename cannot be empty.")
                return False
            chat = ChatModel.load_from_file(filename)
            if not chat:
                self.context.notification_display.error(f"Load chat failed: {filename}")
            else:
                self.context.current_chat = chat
                self.context.print_rule(f"LOAD CHAT: {chat.filename}")
                self.context.print_instruction()
                for message in chat.messages:
                    role = message.role
                    content = message.content
                    if role and content:
                        if role == "system":
                            continue
                        else:
                            if role == "user":
                                role_label = (
                                    "[bold light_sky_blue1]You: [/bold light_sky_blue1]"
                                )
                            else:
                                role_label = "[bold deep_sky_blue1]Assistant: [/bold deep_sky_blue1]"
                            self.console.print(f"{role_label}{format_message_content(content)}")
                            self.console.print()
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/load-chat \nLoad a public chat from file"

    @property
    def doc_description(self) -> str:
        return """Load a public chat from a specified file. The chat file should be located in the 'chats/public' directory (default: ~/.gede/chats/public). """

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/load-chat"


class LoadPrivateChatCommand(CommandBase):
    async def pick_file(self) -> Optional[str]:
        completion = PrivateChatFileCompleter()
        self.context.notification_display.info(
            "Type to search for chat files, use arrow keys to select."
        )
        try:
            with patch_stdout():
                filename = await self.context.prompt_session.prompt_async(
                    "Select Private Chat: ",
                    completer=completion,
                    complete_while_typing=True,
                    complete_in_thread=False,
                )
                # self.console.print("You selected: " + filename, style="info")
                return filename
        except KeyboardInterrupt:
            return None

    async def do_command_async(self) -> bool:
        cmd = "/load-private-chat"
        if self.message.startswith(cmd):
            # filename = self.message[len(cmd) :].strip()
            filename = await self.pick_file()
            if not filename:
                self.context.notification_display.warning("Filename cannot be empty.")
                return False
            password = Prompt.ask(
                "[bold dim]Input password for private chat[/bold dim]", password=True
            )
            password = password.strip()
            if not password:
                self.context.notification_display.warning("Password cannot be empty.")
            chat = ChatModel.load_from_file(
                filename, is_private=True, private_password=password
            )
            if not chat:
                self.context.notification_display.error(f"Load chat failed: {filename}")
            else:
                self.context.current_chat = chat
                self.context.print_rule(f"LOAD CHAT: {chat.filename}")
                self.context.print_instruction()
                for message in chat.messages:
                    role = message.role
                    content = message.content
                    if role and content:
                        if role == "system":
                            continue
                        else:
                            if role == "user":
                                role_label = (
                                    "[bold yellow3]You (Private): [/bold yellow3]"
                                )
                            else:
                                role_label = "[bold deep_sky_blue1]Assistant: [/bold deep_sky_blue1]"
                            self.console.print(f"{role_label}{format_message_content(content)}\n")
            return False
        return True

    @property
    def doc_title(self) -> str:
        return "/load-private-chat \nLoad a private chat from file"

    @property
    def doc_description(self) -> str:
        return """Load a private chat from a specified file. You will be prompted to enter the password used to encrypt the chat messages. The chat file should be located in the 'chats/private' directory (default: ~/.gede/chats/private). """

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/load-private-chat"


class ExportCommand(CommandBase):
    async def do_command_async(self) -> bool:
        cmd = "/export"
        if self.message.startswith(cmd):
            filepath = self.message[len(cmd) :].strip()
            if not filepath:
                self.context.notification_display.warning(
                    "Please input a valid file path."
                )
                return False
            path = Path(filepath).expanduser()
            if path.is_absolute():
                if not path.parent.exists():
                    self.context.notification_display.warning(
                        "Parent folder not exists."
                    )
                    return False
            else:
                export_dir = Path(gede_dir()) / "chats" / "exports"
                export_dir.mkdir(parents=True, exist_ok=True)
                path = export_dir / path
                path.parent.mkdir(parents=True, exist_ok=True)
            exporter = ExportChat(self.context.current_chat)
            await exporter.export_txt(path)
            self.context.notification_display.success(f"Exported chat to {str(path)}")
            return False
        return True

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/export"

    @property
    def doc_title(self) -> str:
        return "/export <FILEPATH> \nExport the current chat to a specified file"

    @property
    def doc_description(self) -> str:
        return """Export the current chat to a specified file in TXT format. Provide the FILEPATH where you want to save the exported chat. If a relative path is provided, the chat will be saved in the 'chats/exports' directory (default: ~/.gede/chats/exports)."""


class SearchChatsCommand(CommandBase):
    async def do_command_async(self) -> bool:
        if not self.message.startswith("/search-chats"):
            return True

        self.context.notification_display.info("Loading chat index...")
        loop = asyncio.get_event_loop()
        index = await loop.run_in_executor(None, _get_chat_search_index)

        if not index:
            self.context.notification_display.warning(
                "No public chats found in ~/.gede/chats/public/"
            )
            return False

        filename = await _run_search_ui(index)

        if not filename:
            self.context.notification_display.info("Search cancelled.")
            return False

        chat = ChatModel.load_from_file(filename)
        if not chat:
            self.context.notification_display.error(f"Load chat failed: {filename}")
        else:
            self.context.current_chat = chat
            self.context.print_rule(f"LOAD CHAT: {chat.filename}")
            self.context.print_instruction()
            for message in chat.messages:
                role = message.role
                content = message.content
                if role and content:
                    if role == "system":
                        continue
                    if role == "user":
                        role_label = "[bold light_sky_blue1]You: [/bold light_sky_blue1]"
                    else:
                        role_label = "[bold deep_sky_blue1]Assistant: [/bold deep_sky_blue1]"
                    self.console.print(f"{role_label}{format_message_content(content)}")
                    self.console.print()
        return False

    @property
    def doc_title(self) -> str:
        return "/search-chats\nSearch public chat history interactively"

    @property
    def doc_description(self) -> str:
        return (
            "Search through all saved public chats (~/.gede/chats/public/) using an "
            "interactive fzf-like interface. Type a keyword to filter results in real time. "
            "Use ↑↓ to navigate, Enter to load the selected chat, Esc to cancel."
        )

    @property
    def command_hint(self) -> Optional[str | tuple[str, ...]]:
        return "/search-chats"
