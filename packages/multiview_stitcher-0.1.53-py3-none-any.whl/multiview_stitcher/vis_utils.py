import json
import os
import urllib
import webbrowser
from http.server import (
    HTTPServer,
    SimpleHTTPRequestHandler,
    test,
)

import numpy as np
import zarr
from matplotlib import colormaps, colors
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from mpl_toolkits.mplot3d.art3d import Line3DCollection
from xarray import DataTree

from multiview_stitcher import (
    msi_utils,
    mv_graph,
    ngff_utils,
    param_utils,
    spatial_image_utils,
)


def plot_positions(
    sims,
    transform_key,
    edges=None,
    edge_color_vals=None,
    edge_linestyles=None,
    edge_linestyle_labels=None,
    edge_cmap=None,
    edge_clims=None,
    edge_label="edge weight",
    use_positional_colors=True,
    n_colors=2,
    nscoord=None,
    display_view_indices=True,
    view_labels=None,
    view_labels_size=10,
    show_plot=True,
    plot_title=None,
    spacing=None,
    output_filename=None,
):
    """
    Plot tile / view positions in both 2D or 3D.

    Parameters
    ----------
    sims : list of spatial-image (or multiscale-spatial-image), multiview-stitcher flavor
        The views / tiles to plot
    transform_key : str
        Which transform_key to use for visualization
    use_positional_colors : bool, optional
        This colors the views such that neighboring
        views can be distinguished better (warning: can
        be slow for many views), by default True
    n_colors : int, optional
        How many different colors to use when `use_positional_colors` is True,
        by default 2
    nscoord : dict, optional
        non-spatial coordinate to use for visualization (e.g. {'c': 'EGFP', 't': 0}),
        by default {}
    view_labels : list of str, optional
        Custom labels to use for the views, by default None
    view_labels_size : int, optional
        Size of the view labels, by default 10
    show_plot : bool, optional
        Whether to show the plot, by default True
    edge_linestyles : list or str, optional
        Line styles for edges. If a list/array is provided, it must match the
        number of edges. If a single string is provided, it is applied to all
        edges. By default None, which uses dashed lines for all edges.
    edge_linestyle_labels : dict or list of tuples, optional
        Optional legend mapping for edge line styles. Provide either a dict
        of {linestyle: label} or a list of (linestyle, label) pairs.
    spacing : dict, optional
        Overwrite the sims' spacing for plotting. Useful in the case of images with single
        coordinates for which the spacing is not defined in the metadata.
        By default None
    plot_title : str, optional
        Title of the plot, by default no title
    output_filename : str, optional
        Filename where to save the plot if not None, by default None

    Returns
    -------
    fig, ax : matplotlib figure and axis
    """

    if nscoord is None:
        nscoord = {}

    if isinstance(sims[0], DataTree):
        # convert msims to sims for backward compatibility
        sims = [msi_utils.get_sim_from_msim(sim) for sim in sims]
    else:
        # make shallow copy of sim list, which fill be modified further down
        sims = list(sims)

    ndim = spatial_image_utils.get_ndim_from_sim(sims[0])
    sdims = spatial_image_utils.get_spatial_dims_from_sim(sims[0])

    # select a single position for non-spatial dimensions
    for isim, sim in enumerate(sims):
        sdims = spatial_image_utils.get_spatial_dims_from_sim(sim)
        nsdims = [dim for dim in sim.dims if dim not in sdims]
        for nsdim in nsdims:
            # if nsdim in sim.dims and len(sim.coords[nsdim]) > 1:
            if nsdim in sim.dims:
                if nsdim not in nscoord:
                    nscoord[nsdim] = sim.coords[nsdim][0]
                sims[isim] = spatial_image_utils.sim_sel_coords(sim, nscoord)

    if use_positional_colors:
        pos_colors = ["red", "green", "blue", "yellow"]
        greedy_colors = mv_graph.get_greedy_colors(
            sims,
            n_colors=n_colors,
            transform_key=transform_key,
        )
        pos_colors = [
            pos_colors[greedy_colors[iview] % len(pos_colors)]
            for iview in range(len(sims))
        ]

    else:
        pos_colors = ["black"] * len(sims)

    fig = plt.figure()
    ax = fig.add_subplot(projection="3d")
    ax.set_aspect("equal")

    for iview, sim in enumerate(sims):
        sp = spatial_image_utils.get_stack_properties_from_sim(
            sim, transform_key=transform_key
        )

        if spacing is not None:
            sp["spacing"] = spacing

        # if single coordinate, enlargen the domain
        for dim in sdims:
            if sp["shape"][dim] == 1:
                sp["shape"][dim] = 2
                sp["origin"][dim] = sp["origin"][dim] - sp["spacing"][dim] / 2

        plot_stack_props(sp, ax, color=pos_colors[iview])

    if display_view_indices:
        for iview, sim in enumerate(sims):
            center = spatial_image_utils.get_center_of_sim(
                sim, transform_key=transform_key
            )
            if ndim == 2:
                y, x = center
                z = 0
            else:
                z, y, x = center
            if view_labels is not None:
                text = view_labels[iview]
            else:
                text = str(iview)
            ax.text(
                z,
                x,
                y,
                text,
                size=view_labels_size,
                zorder=1,
                color="k",
                horizontalalignment="center",
            )

    if edges is not None:
        node_poss = [
            spatial_image_utils.get_center_of_sim(
                sim, transform_key=transform_key
            )
            for sim in sims
        ]
        if ndim == 2:
            node_poss = [[0, p[0], p[1]] for p in node_poss]

        node_poss_mpl = [[p[0], p[2], p[1]] for p in node_poss]

        if edge_color_vals is not None:
            edge_color_vals = np.array(edge_color_vals).astype(float)

            if edge_clims is None:
                edge_clims = [min(edge_color_vals), max(edge_color_vals)]
            norm = colors.Normalize(vmin=edge_clims[0], vmax=edge_clims[1])

            if edge_cmap is None:
                edge_cmap = colormaps.get_cmap(
                    "Spectral",
                )
            elif isinstance(edge_cmap, str):
                edge_cmap = colormaps.get_cmap(edge_cmap)

            edge_cmap.set_bad(color="gray")

            edge_colors = [edge_cmap(norm(val)) for val in edge_color_vals]
        else:
            edge_colors = ["k" for _ in edges]

        if edge_linestyles is None:
            edge_linestyles = ["--"] * len(edges)
        elif isinstance(edge_linestyles, str):
            edge_linestyles = [edge_linestyles] * len(edges)
        elif len(edge_linestyles) != len(edges):
            raise ValueError(
                "edge_linestyles must be None, a string, or match the length of edges."
            )

        # Plot the edges
        for e, color, linestyle in zip(edges, edge_colors, edge_linestyles):
            ax.plot(
                *np.array([node_poss_mpl[e[0]], node_poss_mpl[e[1]]]).T,
                linestyle=linestyle,
                color=color,
            )

        if edge_color_vals is not None:
            sm = plt.cm.ScalarMappable(cmap=edge_cmap)
            sm.set_array(
                list(edge_color_vals) + [edge_clims[0], edge_clims[1]]
            )
            plt.colorbar(sm, label=edge_label, ax=ax)
        if edge_linestyle_labels is not None:
            if isinstance(edge_linestyle_labels, dict):
                label_items = list(edge_linestyle_labels.items())
            elif isinstance(edge_linestyle_labels, (list, tuple)):
                label_items = list(edge_linestyle_labels)
            else:
                raise ValueError(
                    "edge_linestyle_labels must be a dict or a list of tuples."
                )
            used_linestyles = set(edge_linestyles)
            legend_handles = [
                Line2D(
                    [0],
                    [0],
                    color="k",
                    linestyle=linestyle,
                    label=label,
                )
                for linestyle, label in label_items
                if linestyle in used_linestyles
            ]
            if legend_handles:
                ax.legend(handles=legend_handles, title="Edge usage", loc="best")

    if ndim == 3:
        ax.set_xlabel("z [μm]")
    ax.set_ylabel("x [μm]")
    ax.set_zlabel("y [μm]")

    ax.set_aspect("equal", adjustable="box")

    if ndim == 3:
        ax.view_init(elev=15, azim=-15, roll=0)
    elif ndim == 2:
        ax.view_init(elev=0, azim=0, roll=0)

    # invert y-axis to match imshow and napari view
    ax.invert_zaxis()

    if plot_title is not None:
        plt.title(plot_title)

    plt.tight_layout()
    if output_filename is not None:
        plt.savefig(output_filename)
    if show_plot:
        plt.show()

    return fig, ax


def plot_stack_props(stack_props, ax, color="black", size=10, linewidth=1):
    ndim = mv_graph.get_ndim_from_stack_props(stack_props)
    vertices = mv_graph.get_vertices_from_stack_props(stack_props)

    # Build box edges by topology (index hypercube), then map to transformed
    # vertex coordinates. This is robust for arbitrary affine transforms.
    gv = np.array(list(np.ndindex(tuple([2] * ndim))))
    edge_pairs = [
        (i, j)
        for i in range(len(gv))
        for j in range(i + 1, len(gv))
        if np.sum(np.abs(gv[i] - gv[j])) == 1
    ]
    line_segments = np.array([[vertices[i], vertices[j]] for i, j in edge_pairs])

    if ndim == 2:
        line_segments = np.concatenate(
            [np.zeros((line_segments.shape[0], 2, 1)), line_segments], axis=-1
        )

    line_collection = Line3DCollection(
        line_segments[:, :, [0, 2, 1]], colors=color, linewidths=linewidth
    )

    ax.add_collection3d(line_collection)


def plot_tile_pair_image_metrics(
    msims,
    reg_metrics_result,
    base_transform_key,
    query_transform_keys,
    metric_key=None,
    clims=None,
    show_bboxes=True,
    show_overview_plot=False,
    overview_pair_linewidth=1.0,
    show_plot_positions=True,
):
    """
    Visualise registration quality metrics for each query transform key.

    For every entry in *query_transform_keys* a separate figure is produced.
    Each figure shows the tile layout **in that query transform key's world
    coordinate space** and overlays either the pairwise comparison bounding
    boxes (when *show_bboxes* is ``True``) or a minimalistic graph where edges
    are coloured by the metric value (when *show_bboxes* is ``False``).

    The comparison bboxes, which are originally defined in *base_transform_key*
    world space, are projected into each query key's world space via
    ``T_fixed_q @ inv(T_fixed_base)`` (applied to the fixed tile of each pair)
    before being drawn.

    All figures share the same colorbar limits, derived by default from the
    *base_transform_key* metric values when it is included as a query key,
    so all other query keys are compared against the same reference scale.

    Parameters
    ----------
    msims : list of MultiscaleSpatialImage
        The input views, passed unchanged to :func:`plot_positions`.
    reg_metrics_result : dict
        The dictionary returned by :func:`multiview_stitcher.metrics.tile_pair_image_metrics`.
        Must contain the ``"pairs"`` and ``"bboxes"`` keys.
    base_transform_key : str
        Transform key used to define the original comparison bboxes and to set
        colorbar limits when it appears in *query_transform_keys*.
    query_transform_keys : str or list of str
        Subset of transform keys to visualise.  Each key must appear in
        *reg_metrics_result["pairs"]*.  Tile positions and comparison bboxes
        are shown in each key's own world coordinate space.
    metric_key : str, optional
        Name of the metric to use for colouring the comparison boxes or edges.
        Defaults to the first metric key found in the result.
    clims : tuple of (float, float), optional
        Explicit ``(vmin, vmax)`` for the shared colorbar.  When ``None``
        (default) the limits are computed from *base_transform_key* values
        if that key is present in the result, falling back to all query-key
        values otherwise.
    show_bboxes : bool, optional
        When ``True`` (default) the comparison bounding boxes are drawn and
        coloured by metric value.  When ``False`` a minimalistic
        :func:`plot_positions` plot is produced instead, where edges between
        adjacent tiles are coloured by the (mean of the two directed)
        metric values.
    show_overview_plot : bool, optional
        When ``True``, produce one additional figure showing a paired plot
        with *query_transform_keys* on the x-axis and the metric value on the
        y-axis for each pair.  A mean ± std summary (black diamond + error
        bar) is overlaid for each transform key.  By default ``False``.
    overview_pair_linewidth : float, optional
        Line width for the per-pair lines in the overview plot.  Set to
        ``0`` to suppress the lines entirely and show only the mean ± std
        summary markers.  By default ``1.0``.
    show_plot_positions : bool, optional
        When ``True`` (default) the per-query-key positional plots (tile
        layout with coloured comparison bboxes or coloured edges) are
        produced.  Set to ``False`` to skip them, e.g. when only the
        overview plot is needed.

    Returns
    -------
    dict[str, tuple[matplotlib.figure.Figure, matplotlib.axes.Axes]]
        Maps each query transform key to its ``(fig, ax)`` pair.
    """
    if isinstance(query_transform_keys, str):
        query_transform_keys = [query_transform_keys]

    pairs_dict = reg_metrics_result["pairs"]
    bboxes_dict = reg_metrics_result.get("bboxes", {})

    sims = [msi_utils.get_sim_from_msim(msim) for msim in msims]
    spatial_dims = spatial_image_utils.get_spatial_dims_from_sim(sims[0])

    # Collect all available metric keys from the result
    available_metric_keys = set()
    for q_metrics in pairs_dict.values():
        for m in q_metrics.values():
            available_metric_keys.update(m.keys())

    # Determine which metric to colour by
    if metric_key is None:
        metric_key = sorted(available_metric_keys)[0] if available_metric_keys else None
    elif metric_key not in available_metric_keys:
        raise ValueError(
            f"metric_key {metric_key!r} not found in metrics result. "
            f"Available metric keys: {sorted(available_metric_keys)}"
        )

    # Resolve colorbar limits
    if clims is not None:
        vmin, vmax = float(clims[0]), float(clims[1])
    else:
        ref_keys = (
            [base_transform_key]
            if base_transform_key in query_transform_keys
            else query_transform_keys
        )
        ref_values = []
        for pair_metrics in pairs_dict.values():
            for q in ref_keys:
                val = pair_metrics.get(q, {}).get(metric_key, np.nan)
                try:
                    val_f = float(val)
                except (TypeError, ValueError):
                    val_f = np.nan
                if not np.isnan(val_f):
                    ref_values.append(val_f)

        if len(ref_values) >= 2 and min(ref_values) < max(ref_values):
            vmin, vmax = min(ref_values), max(ref_values)
        elif ref_values:
            vmin = ref_values[0] - 0.5
            vmax = ref_values[0] + 0.5
        else:
            vmin, vmax = 0.0, 1.0

    norm = colors.Normalize(vmin=vmin, vmax=vmax)
    cmap = colormaps.get_cmap("Spectral")

    # Build the list of undirected edges (averaged over both directions) once,
    # used only when show_bboxes=False.
    if not show_bboxes:
        seen = {}
        for (fi, mi) in pairs_dict:
            key = tuple(sorted((fi, mi)))
            if key not in seen:
                seen[key] = []
            seen[key].append((fi, mi))
        undirected_edges = list(seen.keys())

    plots = {}
    for q in query_transform_keys:
        if not show_plot_positions:
            continue
        if show_bboxes:
            fig, ax = plot_positions(
                msims,
                transform_key=q,
                use_positional_colors=False,
                show_plot=False,
                plot_title=f"{metric_key}  |  transform key: {q}",
            )

            for (fi, mi), bbox in bboxes_dict.items():
                if bbox is None:
                    continue

                val = pairs_dict.get((fi, mi), {}).get(q, {}).get(metric_key, np.nan)
                try:
                    val_f = float(val)
                except (TypeError, ValueError):
                    val_f = np.nan

                color = (
                    cmap(norm(val_f)) if not np.isnan(val_f) else (0.5, 0.5, 0.5, 1.0)
                )

                lower = bbox["lower"]
                upper = bbox["upper"]

                # Project the bbox from base_transform_key world space into
                # query key world space using the fixed tile's transforms:
                # T_fixed_q @ inv(T_fixed_base) maps a base-world point to
                # query-world, so bbox corners are visualised at the correct
                # location for each query key.
                T_fixed_base = (
                    spatial_image_utils.get_affine_from_sim(sims[fi], base_transform_key)
                    .squeeze()
                    .data
                )
                T_fixed_q = (
                    spatial_image_utils.get_affine_from_sim(sims[fi], q)
                    .squeeze()
                    .data
                )
                bbox_transform = T_fixed_q# @ np.linalg.inv(T_fixed_base)

                sp = {
                    "origin": {
                        dim: float(lower[idim])
                        for idim, dim in enumerate(spatial_dims)
                    },
                    "spacing": {
                        dim: float(upper[idim] - lower[idim])
                        for idim, dim in enumerate(spatial_dims)
                    },
                    "shape": {dim: 2 for dim in spatial_dims},
                    "transform": param_utils.affine_to_xaffine(bbox_transform),
                }
                plot_stack_props(sp, ax, color=color, linewidth=2)

            sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
            sm.set_array([])
            plt.colorbar(sm, ax=ax, label=metric_key)

        else:
            # Minimalistic mode: colour edges by mean metric value over both
            # directed pairs.
            edge_color_vals = []
            for fi, mi in undirected_edges:
                directed = seen[(fi, mi)]
                vals = [
                    float(pairs_dict.get(d, {}).get(q, {}).get(metric_key, np.nan))
                    for d in directed
                ]
                valid = [v for v in vals if not np.isnan(v)]
                edge_color_vals.append(float(np.mean(valid)) if valid else np.nan)

            fig, ax = plot_positions(
                msims,
                transform_key=q,
                use_positional_colors=False,
                edges=undirected_edges,
                edge_color_vals=edge_color_vals,
                edge_cmap=cmap,
                edge_clims=[vmin, vmax],
                edge_label=metric_key,
                show_plot=False,
                plot_title=f"{metric_key}  |  transform key: {q}",
            )

        plt.show()

        plots[q] = (fig, ax)

    # ------------------------------------------------------------------
    # Overview plots: one figure per metric key
    # ------------------------------------------------------------------
    if show_overview_plot:
        n_keys = len(query_transform_keys)
        x_positions = list(range(n_keys))

        for mk in [metric_key]:
            fig_ov, ax_ov = plt.subplots(figsize=(max(3.5, 1.6 * n_keys + 1.2), 3.8))

            # Collect per-pair values across query keys
            pair_keys = list(pairs_dict.keys())
            all_vals_flat = []
            pair_series = []
            for pair in pair_keys:
                y_vals = []
                for q in query_transform_keys:
                    raw = pairs_dict[pair].get(q, {}).get(mk, np.nan)
                    try:
                        y_vals.append(float(raw))
                    except (TypeError, ValueError):
                        y_vals.append(np.nan)
                pair_series.append(y_vals)
                all_vals_flat.extend([v for v in y_vals if not np.isnan(v)])

            # Per-pair lines
            if overview_pair_linewidth > 0:
                for y_vals in pair_series:
                    if any(not np.isnan(v) for v in y_vals):
                        ax_ov.plot(
                            x_positions,
                            y_vals,
                            color="#9e9e9e",
                            alpha=0.55,
                            linewidth=overview_pair_linewidth,
                            marker="o",
                            markersize=3.5,
                            zorder=2,
                        )

            # Mean ± std summary per transform key
            means, stds = [], []
            for ix, q in enumerate(query_transform_keys):
                vals = [
                    float(pairs_dict[pair].get(q, {}).get(mk, np.nan))
                    for pair in pair_keys
                ]
                vals = [v for v in vals if not np.isnan(v)]
                if vals:
                    mean_v = float(np.mean(vals))
                    std_v = float(np.std(vals))
                    means.append(mean_v)
                    stds.append(std_v)
                    ax_ov.errorbar(
                        ix,
                        mean_v,
                        yerr=std_v,
                        fmt="o",
                        color="#1f77b4",
                        markersize=8,
                        linewidth=2,
                        capsize=5,
                        capthick=2,
                        zorder=4,
                    )

            # Connect the mean points with a line for easy trend reading
            valid_x = [ix for ix, q in enumerate(query_transform_keys)
                       if any(not np.isnan(float(pairs_dict[pair].get(q, {}).get(mk, np.nan)))
                              for pair in pair_keys)]
            if len(valid_x) > 1:
                mean_y = []
                for ix in valid_x:
                    q = query_transform_keys[ix]
                    vals = [float(pairs_dict[pair].get(q, {}).get(mk, np.nan))
                            for pair in pair_keys]
                    vals = [v for v in vals if not np.isnan(v)]
                    mean_y.append(float(np.mean(vals)) if vals else np.nan)
                ax_ov.plot(valid_x, mean_y, color="#1f77b4", linewidth=1.5,
                           zorder=3, alpha=0.8)

            ax_ov.set_xticks(x_positions)
            ax_ov.set_xticklabels(query_transform_keys, rotation=20, ha="right",
                                  fontsize=10)
            ax_ov.set_ylabel(mk, fontsize=11)
            ax_ov.set_xlim(-0.5, n_keys - 0.5)
            ax_ov.spines["top"].set_visible(False)
            ax_ov.spines["right"].set_visible(False)
            ax_ov.tick_params(axis="both", labelsize=9)
            ax_ov.grid(axis="y", color="#e0e0e0", linewidth=0.8, zorder=0)
            plt.tight_layout()

            plt.show()

    return plots


def serve_dir(dir_path, port=8000):
    """
    Serve a directory with a simple HTTP server.

    Parameters
    ----------
    dir_path : str
        Path to the directory to serve
    port : int, optional
        Port to use for the server, by default 8000
    """

    # code taken from ome-zarr-py
    class CORSRequestHandler(SimpleHTTPRequestHandler):
        def end_headers(self) -> None:
            self.send_header("Access-Control-Allow-Origin", "*")
            SimpleHTTPRequestHandler.end_headers(self)

        def translate_path(self, path: str) -> str:
            # Since we don't call the class constructor ourselves,
            # we set the directory here instead
            self.directory = dir_path
            super_path = super().translate_path(path)
            return super_path

    print("Serving images until interrupted...")

    # start serving content
    # suppress console output?
    test(CORSRequestHandler, HTTPServer, port=port)


def serve_dir_https(dir_path, port=8000, host="0.0.0.0", certfile="cert.pem", keyfile="key.pem", quiet=False):
    """
    Serve a directory over HTTPS with a simple HTTP server.

    Before serving, create a self-signed certificate (if not already available):

    ```bash
    # Linux / macOS (needs OpenSSL)
    HOSTNAME="$(hostname -f)"                    # or put your DNS name
    IP="10.0.12.34"                              # your machine's LAN IP

    cat > san.cnf <<EOF
    subjectAltName=DNS:${HOSTNAME},IP:${IP}
    EOF

    openssl req -x509 -newkey rsa:2048 -nodes -days 30 \
    -keyout key.pem -out cert.pem \
    -subj "/CN=${HOSTNAME}" \
    -addext "$(cat san.cnf)"
    ```

    Parameters
    ----------
    dir_path : str
        Path to the directory to serve
    port : int, optional
        Port to use for the server (default 8443)
    host : str, optional
        Host/IP to bind (default "0.0.0.0" = all interfaces)
    certfile : str, optional
        Path to the TLS certificate (PEM)
    keyfile : str, optional
        Path to the TLS private key (PEM)
    quiet : bool, optional
        Suppress request logs if True
    """

    class CORSRequestHandler(SimpleHTTPRequestHandler):
        def end_headers(self) -> None:
            self.send_header("Access-Control-Allow-Origin", "*")
            # (optional) add more CORS if you need:
            # self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
            # self.send_header("Access-Control-Allow-Headers", "*")
            super().end_headers()

        def translate_path(self, path: str) -> str:
            # set directory dynamically (like your original)
            self.directory = dir_path
            return super().translate_path(path)

        if quiet:
            def log_message(self, fmt, *args):  # noqa: N802
                pass

    handler = partial(CORSRequestHandler, directory=dir_path)
    httpd = HTTPServer((host, port), handler)

    # Wrap the socket with TLS
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certfile=certfile, keyfile=keyfile)
    httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)

    print(f"Serving {dir_path} over HTTPS at https://{host}:{port} (Ctrl+C to stop)")
    httpd.serve_forever()


def get_contrast_min_max_from_ome_zarr_omero_metadata(
    ome_zarr_path, channel_label=None
):
    """
    Get contrast limits from the OME-Zarr omero metadata key
    for a specific channel. If channel_label is None, the
    first channel is used.
    """
    root = zarr.open_group(ome_zarr_path, mode="r")

    if "omero" not in root.attrs:
        return None

    omero = root.attrs["omero"]

    if channel_label is None:
        channel_index = 0
    else:
        channel_matches = [
            ic
            for ic, c in enumerate(omero["channels"])
            if str(c["label"]) == str(channel_label)
        ]

        if not len(channel_matches) == 1:
            raise ValueError(
                f"Channel {channel_label} not found in metadata in {ome_zarr_path}"
            )
        else:
            channel_index = channel_matches[0]

    window = omero["channels"][channel_index]["window"]

    return np.array([window["start"], window["end"]])


def _affine_to_neuroglancer_source_transform(
    affine, sdims, output_spacing
):
    """
    Convert a physical-space affine to a Neuroglancer source transform.

    OME-Zarr scale and translation already map pixel coordinates into the
    source coordinate space. Neuroglancer rescales source-transform linear
    coefficients from input to output dimension scales internally, but its
    translation coefficients are expressed directly in output coordinate units.
    """
    affine = np.array(affine, dtype=float, copy=True)
    affine_ndim = affine.shape[-1] - 1
    affine_sdims = sdims[-affine_ndim:]
    output_spacing_array = np.array(
        [output_spacing[dim] for dim in affine_sdims]
    )
    affine[:-1, -1] = affine[:-1, -1] / output_spacing_array
    return affine


def generate_neuroglancer_json(
    ome_zarr_paths: list[str],
    ome_zarr_urls: list[str],
    sims: list = None,
    transform_key: str = None,
    channel_coord: str = None,
    single_layer: bool = False,
    contrast_limits: tuple = None,
    layer_dicts: list[dict] = None,
    global_dict: dict = None,
):
    # read the first multiscales
    sim = ngff_utils.read_sim_from_ome_zarr(ome_zarr_paths[0])
    sdims = spatial_image_utils.get_spatial_dims_from_sim(sim)
    ndim = len(sdims)
    dims = sim.dims
    spacing = spatial_image_utils.get_spacing_from_sim(sim)

    if sims is not None:
        if transform_key is None:
            raise ValueError(
                "transform_key must be provided if sims are given"
            )

        full_affines = [np.eye(len(dims) + 1) for _ in sims]
        spacings_per_sim = []
        for isim, sim in enumerate(sims):

            sim_ome_zarr = ngff_utils.read_sim_from_ome_zarr(ome_zarr_paths[isim])
            spacing_isim = spatial_image_utils.get_spacing_from_sim(sim_ome_zarr)
            spacings_per_sim.append(spacing_isim)

            affine = spatial_image_utils.get_affine_from_sim(
                sim, transform_key=transform_key
            )
            if "t" in affine.dims:
                affine = affine.sel(t=0)
            affine = _affine_to_neuroglancer_source_transform(
                affine,
                sdims=sdims,
                output_spacing=spacing_isim,
            )
            affine_ndim = affine.shape[-1] - 1
            full_affines[isim][-affine_ndim - 1 :, -affine_ndim - 1 :] = affine
    else:
        full_affines = [None for _ in ome_zarr_paths]
        spacings_per_sim = [spacing] * len(ome_zarr_paths)

    if contrast_limits is not None:
        window = {
            "min": contrast_limits[0],
            "max": contrast_limits[1],
            "start": contrast_limits[0],
            "end": contrast_limits[1],
        }
        channel_index = 0
    # get contrast limits from first image
    elif "c" in dims:
        if channel_coord is None:
            channel_index = 0
        else:
            # this currently assumes that channel_coord
            # is present in all sims and at the same index
            channel_coord = str(channel_coord)
            channel_index = [str(c) for c in sim.coords["c"].values].index(
                channel_coord
            )
        limits = np.array(
            [
                sim_lims
                for sim_lims in [
                    get_contrast_min_max_from_ome_zarr_omero_metadata(
                        path, channel_coord
                    )
                    for path in ome_zarr_paths
                ]
                if sim_lims is not None
            ]
        )
        if len(limits) == 0:
            window = None
        else:
            vmin, vmax = (float(v) for v in [np.min(limits), np.max(limits)])
            window = {
                "min": vmin,
                "max": vmax,
                "start": vmin,
                "end": vmax,
            }
    else:
        channel_index = 0
        window = None

    output_dimensions = {
        dim: [spacing[dim] * 1e-6 if dim in sdims else 1e-6, ""] for dim in dims
    }

    ng_config = {
        "dimensions": output_dimensions,
        "displayDimensions": sdims[::-1],
        "layerListPanel": {"visible": True},
        # 'position': [center[idim] for idim, dim in enumerate(sdims)],
        # "concurrentDownloads": 100, # leave at default
        "layout": "xy" if ndim == 2 else "4panel",
    }

    if not single_layer:
        ng_config["layers"] = [
            {
                # "type": "image",
                "source": {
                    "url": f"{url}",
                    "transform": {
                        # neuroglancer drops last row of homogeneous matrix
                        "matrix": [
                            list(row) for row in full_affines[iview][:-1]
                        ],
                        "outputDimensions": {
                            (dim if dim != "c" else "c'"): [
                                spacings_per_sim[iview][dim] * 1e-6 if dim in sdims else 1e-6,
                                "",
                            ]
                            for dim in dims
                        },
                    }
                    if full_affines[iview] is not None
                    else {},
                },
                "localDimensions": {"c'": [1, ""]} if "c" in dims else {},
                "localPosition": [channel_index] if "c" in dims else [],
                # 'localPosition': [0 for nsdim in nsdims] + [centers[iview][idim] for idim, dim in enumerate(sdims)],
                "tab": "rendering",
                "opacity": 0.6,
                # 'volumeRendering': 'on',
                "name": f"View {iview}",
            }
            | (
                {
                    "shaderControls": {
                        "normalized": {
                            "range": [window["min"], window["max"]],
                            "window": [window["start"], window["end"]],
                        },
                    },
                }
                if window is not None
                else {}
            )
            for iview, url in enumerate(ome_zarr_urls)
        ]

    else:
        ng_config["layers"] = [
            {
                # "type": "image",
                "source": [
                    {
                        "url": f"{url}",
                        "transform": {
                            # neuroglancer drops last row of homogeneous matrix
                            "matrix": [
                                list(row) for row in full_affines[iview][:-1]
                            ],
                            "outputDimensions": {
                                (dim if dim != "c" else "c'"): [
                                    spacings_per_sim[iview][dim] * 1e-6 if dim in sdims else 1e-6,
                                    "",
                                ]
                                for dim in dims
                            },
                        },
                    }
                    for iview, url in enumerate(ome_zarr_urls)
                ],
                "localDimensions": {"c'": [1, ""]} if "c" in dims else {},
                "localPosition": [channel_index] if "c" in dims else [],
                "tab": "rendering",
                "opacity": 0.6,
                # 'volumeRendering': 'on',
                "name": "Tiles",
            }
            | (
                {
                    "shaderControls": {
                        "normalized": {
                            "range": [window["min"], window["max"]],
                            "window": [window["start"], window["end"]],
                        },
                    },
                }
                if window is not None
                else {}
            )
        ]

    # allow to overwrite / add settings for each layer
    if layer_dicts is not None:
        for il, layer_dict in enumerate(layer_dicts):
            ng_config["layers"][il] = {
                **ng_config["layers"][il],
                **layer_dict,
            }

    # allow to overwrite / add global settings
    if global_dict is not None:
        ng_config = {**ng_config, **global_dict}

    # import pprint
    # pprint.pprint(ng_config)
    return ng_config


def get_neuroglancer_url(ng_json):
    ng_url = "https://neuroglancer-demo.appspot.com/#!" + urllib.parse.quote(
        json.dumps(ng_json, separators=(",", ":"))
    )
    return ng_url


def view_neuroglancer(
    ome_zarr_paths,
    sims=None,
    transform_key=None,
    port=8000,
    channel_coord=None,
    single_layer=False,
    contrast_limits=None,
    layer_dicts: list[dict] = None,
    global_dict: dict = None,
):
    """
    Visualize a list of OME-zarrs in Neuroglancer
    (browser-based, no installation required).

    If sims and transform_key are provided, the affine transformations saved
    in the sims are used for visualization.

    Confirmed to work with:
    - 2D and 3D
    - With affine transformations

    Parameters
    ----------
    ome_zarr_paths : list of str or Path
        path to OME-Zarrs
    sims : list of spatial_images, optional
    transform_key : str, optional
        transform_key to use for visualization
    port : int, optional
        Port to serve OME-Zarrs. By default 8000
    channel_coord : str, optional
        Which channel to use for initializing contrast limits, by default None
    single_layer : bool, optional
        Whether to show all images in a single layer (True) or in separate layers (False, default).
    contrast_limits : tuple, optional
        Contrast limits (min, max) to use for visualization. If None, contrast limits are read
        from the OME-Zarr omero metadata if available, by default None
    """

    ome_zarr_paths = [str(p) for p in ome_zarr_paths]

    # determine a common root for all local paths so files in different
    # directories can all be served from a single HTTP server
    _MAX_SERVE_DEPTH = 3
    local_paths = [p for p in ome_zarr_paths if not p.startswith("http")]
    if local_paths:
        dir_to_serve = os.path.commonpath(
            [os.path.dirname(os.path.abspath(p)) for p in local_paths]
        )
        # safety check: refuse to serve overly broad directories
        for path in local_paths:
            rel = os.path.relpath(os.path.abspath(path), dir_to_serve)
            depth = len(rel.split(os.sep))
            if dir_to_serve == os.sep or depth > _MAX_SERVE_DEPTH:
                import warnings

                warnings.warn(
                    f"view_neuroglancer: the common ancestor directory "
                    f"'{dir_to_serve}' is too broad (depth {depth} > "
                    f"{_MAX_SERVE_DEPTH}) or is the filesystem root. "
                    f"Local files will not be served. "
                    f"Pass HTTP URLs instead.",
                    UserWarning,
                    stacklevel=2,
                )
                dir_to_serve = None
                break
    else:
        dir_to_serve = None

    # generate urls for the ome zarr files
    # use forward slashes in URLs regardless of OS path separator
    ome_zarr_urls = [
        "http://localhost:{port}/{rel}".format(
            port=port,
            rel=os.path.relpath(os.path.abspath(path), dir_to_serve).replace(
                os.sep, "/"
            ),
        )
        if (not path.startswith("http") and dir_to_serve is not None)
        else path
        for path in ome_zarr_paths
    ]

    ng_json = generate_neuroglancer_json(
        ome_zarr_paths=ome_zarr_paths,
        ome_zarr_urls=ome_zarr_urls,
        sims=sims,
        transform_key=transform_key,
        channel_coord=channel_coord,
        single_layer=single_layer,
        contrast_limits=contrast_limits,
        layer_dicts=layer_dicts,
        global_dict=global_dict,
    )
    ng_url = get_neuroglancer_url(ng_json)

    print("Neuroglancer configuration JSON:")
    print(ng_json)

    print("Opening Neuroglancer in browser...")
    print("URL:", ng_url)
    print("Controls:")
    print("All panels")
    print("\t\tZoom: Ctrl + Mousewheel")
    print("Projection panels:")
    print("\t\tPan: Drag")
    print("\t\tRotate: Shift + Drag")
    print("3D view:")
    print("\t\tPan: Shift + Drag")
    print("\t\tRotate: Drag")

    webbrowser.open(ng_url)

    # serve the local ome-zarr files
    if dir_to_serve is not None:
        serve_dir(dir_to_serve, port=port)
