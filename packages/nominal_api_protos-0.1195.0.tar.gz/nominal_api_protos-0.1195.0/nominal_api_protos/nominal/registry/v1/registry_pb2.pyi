import datetime

from buf.validate import validate_pb2 as _validate_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from nominal_api_protos.nominal.gen.v1 import alias_pb2 as _alias_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ContainerImageStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONTAINER_IMAGE_STATUS_UNSPECIFIED: _ClassVar[ContainerImageStatus]
    CONTAINER_IMAGE_STATUS_PENDING: _ClassVar[ContainerImageStatus]
    CONTAINER_IMAGE_STATUS_READY: _ClassVar[ContainerImageStatus]
    CONTAINER_IMAGE_STATUS_FAILED: _ClassVar[ContainerImageStatus]
CONTAINER_IMAGE_STATUS_UNSPECIFIED: ContainerImageStatus
CONTAINER_IMAGE_STATUS_PENDING: ContainerImageStatus
CONTAINER_IMAGE_STATUS_READY: ContainerImageStatus
CONTAINER_IMAGE_STATUS_FAILED: ContainerImageStatus

class ContainerImage(_message.Message):
    __slots__ = ("rid", "name", "tag", "size_bytes", "status", "created_at")
    RID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    rid: str
    name: str
    tag: str
    size_bytes: int
    status: ContainerImageStatus
    created_at: _timestamp_pb2.Timestamp
    def __init__(self, rid: _Optional[str] = ..., name: _Optional[str] = ..., tag: _Optional[str] = ..., size_bytes: _Optional[int] = ..., status: _Optional[_Union[ContainerImageStatus, str]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class CreateImageRequest(_message.Message):
    __slots__ = ("workspace_rid", "name", "tag", "object_key")
    WORKSPACE_RID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    OBJECT_KEY_FIELD_NUMBER: _ClassVar[int]
    workspace_rid: str
    name: str
    tag: str
    object_key: str
    def __init__(self, workspace_rid: _Optional[str] = ..., name: _Optional[str] = ..., tag: _Optional[str] = ..., object_key: _Optional[str] = ...) -> None: ...

class CreateImageResponse(_message.Message):
    __slots__ = ("image",)
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    image: ContainerImage
    def __init__(self, image: _Optional[_Union[ContainerImage, _Mapping]] = ...) -> None: ...

class GetImageRequest(_message.Message):
    __slots__ = ("rid", "workspace_rid")
    RID_FIELD_NUMBER: _ClassVar[int]
    WORKSPACE_RID_FIELD_NUMBER: _ClassVar[int]
    rid: str
    workspace_rid: str
    def __init__(self, rid: _Optional[str] = ..., workspace_rid: _Optional[str] = ...) -> None: ...

class GetImageResponse(_message.Message):
    __slots__ = ("image",)
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    image: ContainerImage
    def __init__(self, image: _Optional[_Union[ContainerImage, _Mapping]] = ...) -> None: ...

class DeleteImageRequest(_message.Message):
    __slots__ = ("rid", "workspace_rid")
    RID_FIELD_NUMBER: _ClassVar[int]
    WORKSPACE_RID_FIELD_NUMBER: _ClassVar[int]
    rid: str
    workspace_rid: str
    def __init__(self, rid: _Optional[str] = ..., workspace_rid: _Optional[str] = ...) -> None: ...

class DeleteImageResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class NameFilter(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class TagFilter(_message.Message):
    __slots__ = ("tag",)
    TAG_FIELD_NUMBER: _ClassVar[int]
    tag: str
    def __init__(self, tag: _Optional[str] = ...) -> None: ...

class StatusFilter(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: ContainerImageStatus
    def __init__(self, status: _Optional[_Union[ContainerImageStatus, str]] = ...) -> None: ...

class AndFilter(_message.Message):
    __slots__ = ("clauses",)
    CLAUSES_FIELD_NUMBER: _ClassVar[int]
    clauses: _containers.RepeatedCompositeFieldContainer[SearchFilter]
    def __init__(self, clauses: _Optional[_Iterable[_Union[SearchFilter, _Mapping]]] = ...) -> None: ...

class SearchFilter(_message.Message):
    __slots__ = ("name", "tag", "status")
    NAME_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    AND_FIELD_NUMBER: _ClassVar[int]
    name: NameFilter
    tag: TagFilter
    status: StatusFilter
    def __init__(self, name: _Optional[_Union[NameFilter, _Mapping]] = ..., tag: _Optional[_Union[TagFilter, _Mapping]] = ..., status: _Optional[_Union[StatusFilter, _Mapping]] = ..., **kwargs) -> None: ...

class SearchImagesRequest(_message.Message):
    __slots__ = ("workspace_rid", "filter", "page_size", "next_page_token")
    WORKSPACE_RID_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    PAGE_SIZE_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace_rid: str
    filter: SearchFilter
    page_size: int
    next_page_token: str
    def __init__(self, workspace_rid: _Optional[str] = ..., filter: _Optional[_Union[SearchFilter, _Mapping]] = ..., page_size: _Optional[int] = ..., next_page_token: _Optional[str] = ...) -> None: ...

class SearchImagesResponse(_message.Message):
    __slots__ = ("images", "next_page_token")
    IMAGES_FIELD_NUMBER: _ClassVar[int]
    NEXT_PAGE_TOKEN_FIELD_NUMBER: _ClassVar[int]
    images: _containers.RepeatedCompositeFieldContainer[ContainerImage]
    next_page_token: str
    def __init__(self, images: _Optional[_Iterable[_Union[ContainerImage, _Mapping]]] = ..., next_page_token: _Optional[str] = ...) -> None: ...
