# DATO1

Librería en Python para la resolución de sistemas de ecuaciones lineales y no lineales utilizando métodos numéricos.

---

## 📌 Descripción

Esta librería implementa métodos clásicos de análisis numérico para resolver sistemas de ecuaciones y encontrar soluciones aproximadas de funciones no lineales.

---

## ⚙️ Métodos incluidos

### 🔢 Sistemas de ecuaciones lineales

- Eliminación de Gauss
- Gauss-Jordan
- Regla de Cramer
- Descomposición LU
- Método de Jacobi
- Método de Gauss-Seidel

### 📉 Ecuaciones no lineales

- Método de Bisección

---

## 📦 Instalación

```bash
pip install dato1_brayan_2525