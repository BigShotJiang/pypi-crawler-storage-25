def gauss_seidel(A, b, x0=None, tol=1e-6, max_iter=100):
    n = len(A)
    x = x0 if x0 else [0]*n

    for _ in range(max_iter):
        x_old = x[:]

        for i in range(n):
            suma1 = sum(A[i][j]*x[j] for j in range(i))
            suma2 = sum(A[i][j]*x_old[j] for j in range(i+1, n))
            x[i] = (b[i] - suma1 - suma2) / A[i][i]

        if max(abs(x[i] - x_old[i]) for i in range(n)) < tol:
            return x

    return x