def gauss_jordan(A, b):
    n = len(b)

    for i in range(n):
        pivote = A[i][i]
        if pivote == 0:
            raise ValueError("Pivote cero")

        for j in range(n):
            A[i][j] /= pivote
        b[i] /= pivote

        for k in range(n):
            if k != i:
                factor = A[k][i]
                for j in range(n):
                    A[k][j] -= factor * A[i][j]
                b[k] -= factor * b[i]

    return b