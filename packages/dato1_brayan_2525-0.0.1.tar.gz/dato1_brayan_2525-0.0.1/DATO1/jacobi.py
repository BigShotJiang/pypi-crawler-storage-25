def jacobi(A, b, x0=None, tol=1e-6, max_iter=100):
    n = len(A)
    x = x0 if x0 else [0]*n

    for _ in range(max_iter):
        x_new = x[:]

        for i in range(n):
            suma = sum(A[i][j]*x[j] for j in range(n) if j != i)
            x_new[i] = (b[i] - suma) / A[i][i]

        if max(abs(x_new[i] - x[i]) for i in range(n)) < tol:
            return x_new

        x = x_new

    return x