def determinante(M):
    if len(M) == 2:
        return M[0][0]*M[1][1] - M[0][1]*M[1][0]

    det = 0
    for c in range(len(M)):
        menor = [fila[:c] + fila[c+1:] for fila in M[1:]]
        det += ((-1)**c) * M[0][c] * determinante(menor)
    return det


def cramer(A, b):
    n = len(b)
    detA = determinante(A)

    if detA == 0:
        raise ValueError("Sistema sin solución única")

    soluciones = []

    for i in range(n):
        Ai = [fila[:] for fila in A]
        for j in range(n):
            Ai[j][i] = b[j]

        soluciones.append(determinante(Ai) / detA)

    return soluciones