def eliminacion_gauss(A, b):
    n = len(b)

    for i in range(n):
        for j in range(i+1, n):
            if A[i][i] == 0:
                raise ValueError("División por cero")

            factor = A[j][i] / A[i][i]
            for k in range(n):
                A[j][k] -= factor * A[i][k]
            b[j] -= factor * b[i]

    x = [0]*n
    for i in range(n-1, -1, -1):
        suma = sum(A[i][j]*x[j] for j in range(i+1, n))
        x[i] = (b[i] - suma) / A[i][i]

    return x