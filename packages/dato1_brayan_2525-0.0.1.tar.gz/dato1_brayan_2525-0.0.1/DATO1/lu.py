def descomposicion_lu(A):
    n = len(A)
    L = [[0]*n for _ in range(n)]
    U = [[0]*n for _ in range(n)]

    for i in range(n):
        L[i][i] = 1

    for j in range(n):
        for i in range(j+1):
            suma = sum(U[k][j]*L[i][k] for k in range(i))
            U[i][j] = A[i][j] - suma

        for i in range(j, n):
            suma = sum(U[k][j]*L[i][k] for k in range(j))
            if U[j][j] == 0:
                raise ValueError("División por cero")
            L[i][j] = (A[i][j] - suma) / U[j][j]

    return L, U