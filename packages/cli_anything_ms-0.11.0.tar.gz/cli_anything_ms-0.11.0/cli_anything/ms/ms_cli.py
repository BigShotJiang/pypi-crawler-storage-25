"""ms CLI 入口 - 基于 Click 的命令行工具。

支持 REPL 模式和一次性命令，所有业务命令支持 --json 输出。
"""

from __future__ import annotations

import json
import shlex
import sys
from typing import Optional

import click

from . import __version__
from .core.client import ConnectionConfig, MSClient
from .core.cloud_resource import CLOUD_RESOURCE_RANK_RANGE_CHOICES, CLOUD_RESOURCE_RANK_STAT_CHOICES
from .core.cloud_resource import MEDIA_TYPE_CHOICES as CLOUD_RESOURCE_MEDIA_TYPE_CHOICES
from .core.cloud_resource import CloudResourceManager
from .core.download import MEDIA_TYPE_CHOICES as DOWNLOAD_MEDIA_TYPE_CHOICES
from .core.download import DownloadManager
from .core.media import MEDIA_RANK_SOURCE_MAP, MEDIA_RECOMMEND_SOURCE_MAP, MEDIA_SOURCE_MAP, MediaManager
from .core.media_server import MEDIA_TYPE_CHOICES as MEDIA_SERVER_MEDIA_TYPE_CHOICES
from .core.media_server import MediaServerManager
from .core.site import SITE_SWITCH_TYPE_CHOICES, SiteManager
from .core.subscribe import MEDIA_TYPE_CHOICES as SUBSCRIBE_MEDIA_TYPE_CHOICES
from .core.subscribe import SubscribeManager
from .core.system import SystemManager
from .utils.output import (
    output_cloud_resource_download,
    output_cloud_resource_rank,
    output_cloud_resource_search,
    output_connection,
    output_download_history,
    output_download_operation,
    output_downloaders,
    output_downloading,
    output_error,
    output_json,
    output_media_rank_categories,
    output_media_rank_items,
    output_media_rank_sources,
    output_media_rank_subjects,
    output_media_recommend_channels,
    output_media_recommend_items,
    output_media_recommend_options,
    output_media_recommend_sources,
    output_media_search,
    output_media_server_detail,
    output_media_server_libraries,
    output_media_server_list,
    output_media_server_media_items,
    output_media_server_miss_episodes,
    output_media_server_statistics,
    output_media_server_sync_items,
    output_media_server_sync_run,
    output_plugin_call,
    output_site_data_latest,
    output_site_data_total,
    output_site_list,
    output_site_sign_in,
    output_site_sign_in_history,
    output_subscribe_add,
    output_subscribe_page,
    output_system_nas_info,
)


# ---- 全局上下文 ----


class Context:
    """CLI 运行时上下文。"""

    def __init__(self) -> None:
        self.json_mode = False
        self.in_repl = False
        self.conn: Optional[ConnectionConfig] = None
        self.client: Optional[MSClient] = None
        self._media_mgr: Optional[MediaManager] = None
        self._media_server_mgr: Optional[MediaServerManager] = None
        self._site_mgr: Optional[SiteManager] = None
        self._subscribe_mgr: Optional[SubscribeManager] = None
        self._cloud_resource_mgr: Optional[CloudResourceManager] = None
        self._download_mgr: Optional[DownloadManager] = None
        self._system_mgr: Optional[SystemManager] = None

    def setup(self, url: Optional[str], apikey: Optional[str]) -> None:
        self.conn = ConnectionConfig.resolve(url=url, api_key=apikey)
        self.client = MSClient(self.conn)
        self._media_mgr = None
        self._media_server_mgr = None
        self._site_mgr = None
        self._subscribe_mgr = None
        self._cloud_resource_mgr = None
        self._download_mgr = None
        self._system_mgr = None

    @property
    def media_mgr(self) -> MediaManager:
        if self.client is None:
            raise ValueError("Client is not initialized")
        if self._media_mgr is None:
            self._media_mgr = MediaManager(self.client)
        return self._media_mgr

    @property
    def media_server_mgr(self) -> MediaServerManager:
        if self.client is None:
            raise ValueError("Client is not initialized")
        if self._media_server_mgr is None:
            self._media_server_mgr = MediaServerManager(self.client)
        return self._media_server_mgr

    @property
    def site_mgr(self) -> SiteManager:
        if self.client is None:
            raise ValueError("Client is not initialized")
        if self._site_mgr is None:
            self._site_mgr = SiteManager(self.client)
        return self._site_mgr

    @property
    def subscribe_mgr(self) -> SubscribeManager:
        if self.client is None:
            raise ValueError("Client is not initialized")
        if self._subscribe_mgr is None:
            self._subscribe_mgr = SubscribeManager(self.client)
        return self._subscribe_mgr

    @property
    def cloud_resource_mgr(self) -> CloudResourceManager:
        if self.client is None:
            raise ValueError("Client is not initialized")
        if self._cloud_resource_mgr is None:
            self._cloud_resource_mgr = CloudResourceManager(self.client)
        return self._cloud_resource_mgr

    @property
    def download_mgr(self) -> DownloadManager:
        if self.client is None:
            raise ValueError("Client is not initialized")
        if self._download_mgr is None:
            self._download_mgr = DownloadManager(self.client)
        return self._download_mgr

    @property
    def system_mgr(self) -> SystemManager:
        if self.client is None:
            raise ValueError("Client is not initialized")
        if self._system_mgr is None:
            self._system_mgr = SystemManager(self.client)
        return self._system_mgr


pass_ctx = click.make_pass_decorator(Context, ensure=True)


def handle_error(ctx: Context, exc: Exception) -> None:
    if ctx.json_mode:
        output_json({"error": str(exc)})
    else:
        output_error(str(exc))
    raise SystemExit(1)


def _parse_plugin_body(body: str) -> dict:
    try:
        payload = json.loads(body)
    except json.JSONDecodeError as exc:
        raise click.UsageError(f"--body must be valid JSON: {exc.msg}") from exc

    if not isinstance(payload, dict):
        raise click.UsageError("--body must be a JSON object")

    action = payload.get("action")
    if not isinstance(action, str) or not action.strip():
        raise click.UsageError("--body.action must be a non-empty string")

    nested_body = payload.get("body")
    if nested_body is not None and not isinstance(nested_body, dict):
        raise click.UsageError("--body.body must be a JSON object")

    payload["action"] = action.strip()
    return payload


def _parse_json_object_option(raw: str, option_name: str) -> dict:
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise click.UsageError(f"{option_name} must be valid JSON: {exc.msg}") from exc

    if not isinstance(payload, dict):
        raise click.UsageError(f"{option_name} must be a JSON object")

    return payload


def _parse_bool_option(value: Optional[str]) -> Optional[bool]:
    if value is None:
        return None
    return value.lower() == "true"


# ---- 根命令组 ----

@click.group(invoke_without_command=True)
@click.option("--url", "-u", envvar="MS_URL", help="ms base URL")
@click.option("--apikey", "-k", envvar="MS_API_KEY", help="ms API key")
@click.option("--json", "json_mode", is_flag=True, help="Output normalized JSON")
@click.option("--repl", "repl_mode", is_flag=True, help="Enter interactive REPL")
@click.version_option(version=__version__, prog_name="cli-anything-ms")
@click.pass_context
def main(click_ctx: click.Context, url: Optional[str], apikey: Optional[str], json_mode: bool, repl_mode: bool) -> None:
    """ms 命令行工具。

    通过本地 CLI 统一调用 ms 能力，当前聚焦连接配置、媒体搜索、媒体服务检查、插件调用和影视订阅。

    连接参数优先级: --url/--apikey > 环境变量 MS_URL/MS_API_KEY > ~/.ms-cli.yaml
    """
    ctx = click_ctx.ensure_object(Context)
    ctx.json_mode = json_mode
    ctx.setup(url, apikey)

    interactive = sys.stdin.isatty() and sys.stdout.isatty()
    should_repl = repl_mode or (
        click_ctx.invoked_subcommand is None and interactive and not ctx.in_repl
    )

    if should_repl:
        _enter_repl(ctx)
    elif click_ctx.invoked_subcommand is None:
        click.echo(click_ctx.get_help())


def _enter_repl(ctx: Context) -> None:
    """交互式 REPL 模式。"""
    ctx.in_repl = True
    click.echo("ms REPL. 输入 help 查看帮助，exit 退出。")

    while True:
        try:
            line = input("ms> ")
        except (EOFError, KeyboardInterrupt):
            click.echo()
            break

        line = line.strip()
        if not line:
            continue
        if line in {"exit", "quit"}:
            break
        if line == "help":
            click.echo(main.get_help(click.Context(main, obj=ctx)))
            continue

        try:
            args = shlex.split(line)
            main(args, standalone_mode=False, obj=ctx)
        except SystemExit:
            continue
        except Exception as exc:  # pragma: no cover - safety path
            output_error(str(exc))


#
# system 命令组
#

@main.group()
@pass_ctx
def system(ctx: Context) -> None:
    """系统信息命令。"""


@system.command("nas-info")
@pass_ctx
def system_nas_info(ctx: Context) -> None:
    """查看 NAS 系统信息。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.system_mgr.nas_info()

        if ctx.json_mode:
            output_json(result)
        else:
            output_system_nas_info(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


#
# config 命令组
#

@main.group()
@pass_ctx
def config(ctx: Context) -> None:
    """连接配置管理。"""


@config.command("save-connection")
@click.option("--url", "-u", required=True, help="ms base URL")
@click.option("--apikey", "-k", required=True, help="ms API key")
@pass_ctx
def save_connection(ctx: Context, url: str, apikey: str) -> None:
    """保存连接参数到 ~/.ms-cli.yaml。"""
    try:
        config_path = ConnectionConfig.save(url, apikey)
        output_connection(
            {
                "status": "ok",
                "saved_to": str(config_path),
                "base_url": url.rstrip("/"),
                "api_key": ConnectionConfig.resolve(url=url, api_key=apikey).masked_api_key,
            },
            json_mode=ctx.json_mode,
        )
    except Exception as exc:
        handle_error(ctx, exc)


@config.command("show-connection")
@pass_ctx
def show_connection(ctx: Context) -> None:
    """显示当前生效的连接配置。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        output_connection(ctx.conn.as_display_dict(), json_mode=ctx.json_mode)
    except Exception as exc:
        handle_error(ctx, exc)


#
# media 命令组
#

@main.group()
@pass_ctx
def media(ctx: Context) -> None:
    """媒体搜索命令。"""


@media.command("search")
@click.option(
    "--source",
    type=click.Choice(sorted(MEDIA_SOURCE_MAP.keys()), case_sensitive=False),
    required=True,
    help="Media source name",
)
@click.option("--keyword", required=True, help="Search keyword")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True, help="Page number")
@click.option(
    "--page-size",
    type=click.IntRange(min=1),
    default=20,
    show_default=True,
    help="Page size",
)
@pass_ctx
def media_search(ctx: Context, source: str, keyword: str, page: int, page_size: int) -> None:
    """按来源和关键字搜索媒体。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()
        if not keyword.strip():
            raise click.UsageError("--keyword cannot be empty")

        source_key = source.lower()
        result = ctx.media_mgr.search(
            source_code=MEDIA_SOURCE_MAP[source_key],
            keyword=keyword.strip(),
            page=page,
            page_size=page_size,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_search(result, source=source_key, keyword=keyword)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media.group("rank")
@pass_ctx
def media_rank(ctx: Context) -> None:
    """媒体榜单命令。"""


@media_rank.command("sources")
@pass_ctx
def media_rank_sources(ctx: Context) -> None:
    """获取榜单来源。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_mgr.rank_sources()

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_rank_sources(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_rank.command("categories")
@click.option(
    "--source",
    type=click.Choice(sorted(MEDIA_RANK_SOURCE_MAP.keys()), case_sensitive=False),
    required=True,
    help="Media rank source name",
)
@pass_ctx
def media_rank_categories(ctx: Context, source: str) -> None:
    """按榜单来源获取分类。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        source_key = source.lower()
        result = ctx.media_mgr.rank_categories(MEDIA_RANK_SOURCE_MAP[source_key])

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_rank_categories(result, source=source_key)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_rank.command("subjects")
@click.option("--category-code", required=True, help="Media rank category code")
@pass_ctx
def media_rank_subjects(ctx: Context, category_code: str) -> None:
    """按榜单分类获取主题。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        category_code = category_code.strip()
        if not category_code:
            raise click.UsageError("--category-code cannot be empty")

        result = ctx.media_mgr.rank_subjects(category_code)

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_rank_subjects(result, category_code=category_code)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_rank.command("items")
@click.option("--category-code", required=True, help="Media rank category code")
@click.option("--code", required=True, help="Media rank subject code")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True, help="Page number")
@click.option(
    "--page-size",
    type=click.IntRange(min=1),
    default=20,
    show_default=True,
    help="Page size",
)
@pass_ctx
def media_rank_items(ctx: Context, category_code: str, code: str, page: int, page_size: int) -> None:
    """按榜单主题获取条目。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        category_code = category_code.strip()
        code = code.strip()
        if not category_code:
            raise click.UsageError("--category-code cannot be empty")
        if not code:
            raise click.UsageError("--code cannot be empty")

        result = ctx.media_mgr.rank_items(
            category_code=category_code,
            code=code,
            page=page,
            page_size=page_size,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_rank_items(result, category_code=category_code, code=code)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media.group("recommend")
@pass_ctx
def media_recommend(ctx: Context) -> None:
    """媒体推荐命令。"""


@media_recommend.command("sources")
@pass_ctx
def media_recommend_sources(ctx: Context) -> None:
    """获取推荐来源。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_mgr.recommend_sources()

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_recommend_sources(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_recommend.command("channels")
@click.option(
    "--source",
    type=click.Choice(sorted(MEDIA_RECOMMEND_SOURCE_MAP.keys()), case_sensitive=False),
    required=True,
    help="Media recommend source name",
)
@pass_ctx
def media_recommend_channels(ctx: Context, source: str) -> None:
    """按推荐来源获取频道。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        source_key = source.lower()
        result = ctx.media_mgr.recommend_channels(MEDIA_RECOMMEND_SOURCE_MAP[source_key])

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_recommend_channels(result, source=source_key)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_recommend.command("options")
@click.option(
    "--source",
    type=click.Choice(sorted(MEDIA_RECOMMEND_SOURCE_MAP.keys()), case_sensitive=False),
    required=True,
    help="Media recommend source name",
)
@click.option("--channel", required=True, help="Media recommend channel")
@pass_ctx
def media_recommend_options(ctx: Context, source: str, channel: str) -> None:
    """按推荐来源和频道获取动态选项。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        source_key = source.lower()
        channel = channel.strip()
        if not channel:
            raise click.UsageError("--channel cannot be empty")

        result = ctx.media_mgr.recommend_options(
            media_source=MEDIA_RECOMMEND_SOURCE_MAP[source_key],
            channel=channel,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_recommend_options(result, source=source_key, channel=channel)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_recommend.command("items")
@click.option(
    "--source",
    type=click.Choice(sorted(MEDIA_RECOMMEND_SOURCE_MAP.keys()), case_sensitive=False),
    required=True,
    help="Media recommend source name",
)
@click.option("--channel", required=True, help="Media recommend channel")
@click.option("--options", "options_json", help="Media recommend options JSON object")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True, help="Page number")
@click.option(
    "--page-size",
    type=click.IntRange(min=1),
    default=20,
    show_default=True,
    help="Page size",
)
@pass_ctx
def media_recommend_items(
    ctx: Context,
    source: str,
    channel: str,
    options_json: Optional[str],
    page: int,
    page_size: int,
) -> None:
    """按推荐来源、频道和动态选项获取推荐条目。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        source_key = source.lower()
        channel = channel.strip()
        if not channel:
            raise click.UsageError("--channel cannot be empty")

        options = {} if not options_json else _parse_json_object_option(options_json, "--options")
        result = ctx.media_mgr.recommend_items(
            media_source=MEDIA_RECOMMEND_SOURCE_MAP[source_key],
            channel=channel,
            options=options,
            page=page,
            page_size=page_size,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_recommend_items(result, source=source_key, channel=channel)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


#
# media-server 命令组
#

@main.group("media-server")
@pass_ctx
def media_server(ctx: Context) -> None:
    """媒体服务命令。"""


@media_server.command("list")
@pass_ctx
def media_server_list(ctx: Context) -> None:
    """查看媒体服务器列表和同步统计。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_server_mgr.list()

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_list(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_server.command("detail")
@click.option("--id", "server_id", type=click.IntRange(min=1), required=True, help="Media server ID")
@pass_ctx
def media_server_detail(ctx: Context, server_id: int) -> None:
    """查看媒体服务器详情。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_server_mgr.detail(server_id)

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_detail(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_server.command("libraries")
@click.option("--id", "server_id", type=click.IntRange(min=1), required=True, help="Media server ID")
@pass_ctx
def media_server_libraries(ctx: Context, server_id: int) -> None:
    """查看媒体服务器媒体库。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_server_mgr.libraries(server_id)

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_libraries(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_server.command("statistics")
@click.option("--id", "server_id", type=click.IntRange(min=1), required=True, help="Media server ID")
@pass_ctx
def media_server_statistics(ctx: Context, server_id: int) -> None:
    """查看媒体服务器同步统计。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_server_mgr.statistics(server_id)

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_statistics(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_server.command("sync-items")
@click.option("--id", "server_id", type=click.IntRange(min=1), required=True, help="Media server ID")
@click.option("--title", help="Title filter")
@click.option(
    "--type",
    "media_type",
    type=click.Choice(MEDIA_SERVER_MEDIA_TYPE_CHOICES, case_sensitive=False),
    help="Media type",
)
@click.option("--miss-eps", type=click.Choice(("true", "false"), case_sensitive=False), help="Filter missing episodes")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True, help="Page number")
@click.option("--page-size", type=click.IntRange(min=1), default=20, show_default=True, help="Page size")
@pass_ctx
def media_server_sync_items(
    ctx: Context,
    server_id: int,
    title: Optional[str],
    media_type: Optional[str],
    miss_eps: Optional[str],
    page: int,
    page_size: int,
) -> None:
    """查看媒体服务器同步明细。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        miss_eps_value = None if miss_eps is None else miss_eps.lower() == "true"
        result = ctx.media_server_mgr.sync_items(
            server_id,
            title=title,
            media_type=media_type.lower() if media_type else None,
            miss_eps=miss_eps_value,
            page=page,
            page_size=page_size,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_sync_items(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_server.command("playing")
@click.option("--id", "server_id", type=click.IntRange(min=1), required=True, help="Media server ID")
@pass_ctx
def media_server_playing(ctx: Context, server_id: int) -> None:
    """查看正在播放。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_server_mgr.playing(server_id)

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_media_items(result, "Media Server Playing")
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_server.command("latest")
@click.option("--id", "server_id", type=click.IntRange(min=1), required=True, help="Media server ID")
@click.option("--num", type=click.IntRange(min=1), default=12, show_default=True, help="Item count")
@pass_ctx
def media_server_latest(ctx: Context, server_id: int, num: int) -> None:
    """查看最近添加。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_server_mgr.latest(server_id, num=num)

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_media_items(result, "Media Server Latest")
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_server.command("resume")
@click.option("--id", "server_id", type=click.IntRange(min=1), required=True, help="Media server ID")
@click.option("--num", type=click.IntRange(min=1), default=12, show_default=True, help="Item count")
@pass_ctx
def media_server_resume(ctx: Context, server_id: int, num: int) -> None:
    """查看继续观看。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_server_mgr.resume(server_id, num=num)

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_media_items(result, "Media Server Resume")
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_server.command("sync-run")
@click.option("--id", "server_id", type=click.IntRange(min=1), required=True, help="Media server ID")
@pass_ctx
def media_server_sync_run(ctx: Context, server_id: int) -> None:
    """发起媒体服务器同步任务。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_server_mgr.sync_run(server_id)

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_sync_run(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@media_server.command("miss-episodes-check")
@pass_ctx
def media_server_miss_episodes_check(ctx: Context) -> None:
    """检查媒体服务中的电视剧漏集情况。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.media_server_mgr.miss_episodes_check()

        if ctx.json_mode:
            output_json(result)
        else:
            output_media_server_miss_episodes(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


#
# site 命令组
#

@main.group()
@pass_ctx
def site(ctx: Context) -> None:
    """站点状态和签到命令。"""


@site.command("list")
@click.option("--name", help="Site name filter")
@click.option("--enabled", type=click.Choice(("true", "false"), case_sensitive=False), help="Filter enabled sites")
@click.option(
    "--type",
    "switch_type",
    type=click.Choice(tuple(SITE_SWITCH_TYPE_CHOICES.keys()), case_sensitive=False),
    help="Filter by site switch type",
)
@pass_ctx
def site_list(ctx: Context, name: Optional[str], enabled: Optional[str], switch_type: Optional[str]) -> None:
    """查看站点列表。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.site_mgr.list(
            name=name,
            enabled=_parse_bool_option(enabled),
            switch_type=switch_type.lower() if switch_type else None,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_site_list(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@site.group("data")
@pass_ctx
def site_data(ctx: Context) -> None:
    """站点统计数据命令。"""


@site_data.command("total")
@pass_ctx
def site_data_total(ctx: Context) -> None:
    """查看站点总体统计。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.site_mgr.data_total()

        if ctx.json_mode:
            output_json(result)
        else:
            output_site_data_total(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@site_data.command("latest")
@click.option("--site-id", type=click.IntRange(min=1), help="Site ID")
@click.option("--site-name", help="Site name filter")
@click.option("--order-by", help="Backend order field")
@click.option(
    "--order-direction",
    type=click.Choice(("asc", "desc"), case_sensitive=False),
    help="Order direction",
)
@pass_ctx
def site_data_latest(
    ctx: Context,
    site_id: Optional[int],
    site_name: Optional[str],
    order_by: Optional[str],
    order_direction: Optional[str],
) -> None:
    """查看最新站点统计。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.site_mgr.data_latest(
            site_id=site_id,
            site_name=site_name,
            order_by=order_by,
            order_direction=order_direction.lower() if order_direction else None,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_site_data_latest(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@site.group("sign-in")
@pass_ctx
def site_sign_in(ctx: Context) -> None:
    """站点签到命令。"""


@site_sign_in.command("history")
@click.option("--site-name", help="Site name filter")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True, help="Page number")
@click.option("--page-size", type=click.IntRange(min=1), default=20, show_default=True, help="Page size")
@pass_ctx
def site_sign_in_history(ctx: Context, site_name: Optional[str], page: int, page_size: int) -> None:
    """查看站点签到记录。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.site_mgr.sign_in_history(site_name=site_name, page=page, page_size=page_size)

        if ctx.json_mode:
            output_json(result)
        else:
            output_site_sign_in_history(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@site_sign_in.command("go")
@click.option("--id", "site_ids", type=click.IntRange(min=1), multiple=True, help="Site ID. Repeat for multiple sites")
@pass_ctx
def site_sign_in_go(ctx: Context, site_ids: tuple[int, ...]) -> None:
    """提交站点签到任务。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.site_mgr.sign_in(site_ids=list(site_ids) or None)

        if ctx.json_mode:
            output_json(result)
        else:
            output_site_sign_in(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


#
# download 命令组
#

@main.group()
@pass_ctx
def download(ctx: Context) -> None:
    """下载器和下载任务命令。"""


@download.command("downloaders")
@pass_ctx
def download_downloaders(ctx: Context) -> None:
    """查看下载器列表。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.download_mgr.downloaders()

        if ctx.json_mode:
            output_json(result)
        else:
            output_downloaders(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@download.command("downloading")
@click.option("--id", "download_ids", multiple=True, help="Download ID. Repeat for multiple tasks")
@pass_ctx
def download_downloading(ctx: Context, download_ids: tuple[str, ...]) -> None:
    """查看下载中任务。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.download_mgr.downloading(download_ids=list(download_ids) or None)

        if ctx.json_mode:
            output_json(result)
        else:
            output_downloading(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@download.command("history")
@click.option("--title", help="Title filter")
@click.option(
    "--type",
    "media_type",
    type=click.Choice(DOWNLOAD_MEDIA_TYPE_CHOICES, case_sensitive=False),
    help="Media type",
)
@click.option("--site-id", type=click.IntRange(min=1), help="Site ID")
@click.option("--site-name", help="Site name filter")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True, help="Page number")
@click.option("--page-size", type=click.IntRange(min=1), default=20, show_default=True, help="Page size")
@pass_ctx
def download_history(
    ctx: Context,
    title: Optional[str],
    media_type: Optional[str],
    site_id: Optional[int],
    site_name: Optional[str],
    page: int,
    page_size: int,
) -> None:
    """查看下载历史。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.download_mgr.history(
            title=title,
            media_type=media_type.lower() if media_type else None,
            site_id=site_id,
            site_name=site_name,
            page=page,
            page_size=page_size,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_download_history(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@download.command("pause")
@click.option("--id", "download_id", required=True, help="Download ID")
@pass_ctx
def download_pause(ctx: Context, download_id: str) -> None:
    """暂停下载任务。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.download_mgr.pause(download_id)

        if ctx.json_mode:
            output_json(result)
        else:
            output_download_operation(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@download.command("resume")
@click.option("--id", "download_id", required=True, help="Download ID")
@pass_ctx
def download_resume(ctx: Context, download_id: str) -> None:
    """恢复下载任务。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.download_mgr.resume(download_id)

        if ctx.json_mode:
            output_json(result)
        else:
            output_download_operation(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@download.command("delete")
@click.option("--id", "download_id", required=True, help="Download ID")
@click.option("--delete-file", is_flag=True, help="Also delete downloaded files when backend supports it")
@pass_ctx
def download_delete(ctx: Context, download_id: str, delete_file: bool) -> None:
    """删除下载任务。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.download_mgr.delete(download_id, delete_file=delete_file)

        if ctx.json_mode:
            output_json(result)
        else:
            output_download_operation(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


#
# cloud-resource 命令组
#

@main.group("cloud-resource")
@pass_ctx
def cloud_resource(ctx: Context) -> None:
    """云端资源搜索和下载命令。"""


@cloud_resource.command("search")
@click.option("--keyword", help="Keyword filter")
@click.option("--tmdb-id", type=click.IntRange(min=1), help="TMDB ID")
@click.option(
    "--type",
    "media_type",
    type=click.Choice(CLOUD_RESOURCE_MEDIA_TYPE_CHOICES, case_sensitive=False),
    help="Media type for TMDB searches",
)
@click.option("--season", type=click.IntRange(min=1), help="Season number")
@click.option("--episode", type=click.IntRange(min=1), help="Episode number")
@click.option("--begin-episode", type=click.IntRange(min=1), help="Begin episode number")
@click.option("--end-episode", type=click.IntRange(min=1), help="End episode number")
@click.option("--creator-id", type=click.IntRange(min=1), help="Cloud resource creator ID")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True, help="Page number")
@click.option(
    "--page-size",
    type=click.IntRange(min=1),
    default=25,
    show_default=True,
    help="Page size",
)
@pass_ctx
def cloud_resource_search(
    ctx: Context,
    keyword: Optional[str],
    tmdb_id: Optional[int],
    media_type: Optional[str],
    season: Optional[int],
    episode: Optional[int],
    begin_episode: Optional[int],
    end_episode: Optional[int],
    creator_id: Optional[int],
    page: int,
    page_size: int,
) -> None:
    """搜索云端资源。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.cloud_resource_mgr.search(
            keyword=keyword,
            tmdb_id=tmdb_id,
            media_type=media_type.lower() if media_type else None,
            season=season,
            episode=episode,
            begin_episode=begin_episode,
            end_episode=end_episode,
            creator_id=creator_id,
            page=page,
            page_size=page_size,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_cloud_resource_search(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@cloud_resource.command("download")
@click.option("--request", "request_json", required=True, help="Download request JSON from search result")
@click.option("--dir", "dir_path", help="Target cloud storage directory. Empty uses backend default")
@pass_ctx
def cloud_resource_download(ctx: Context, request_json: str, dir_path: Optional[str]) -> None:
    """提交云端资源下载或转存任务。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        request = _parse_json_object_option(request_json, "--request")
        result = ctx.cloud_resource_mgr.submit_download(request, dir_path=(dir_path or "").strip() or None)

        if ctx.json_mode:
            output_json(result)
        else:
            output_cloud_resource_download(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@cloud_resource.command("rank")
@click.option(
    "--range",
    "range_type",
    type=click.Choice(CLOUD_RESOURCE_RANK_RANGE_CHOICES, case_sensitive=False),
    default="today",
    show_default=True,
    help="Rank range",
)
@click.option(
    "--stat",
    "stat_type",
    type=click.Choice(CLOUD_RESOURCE_RANK_STAT_CHOICES, case_sensitive=False),
    default="count",
    show_default=True,
    help="Statistic type",
)
@click.option("--refresh", is_flag=True, help="Refresh backend cache")
@pass_ctx
def cloud_resource_rank(ctx: Context, range_type: str, stat_type: str, refresh: bool) -> None:
    """查看云端资源贡献榜。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        result = ctx.cloud_resource_mgr.rank(
            range_type=range_type.lower(),
            stat_type=stat_type.lower(),
            refresh=refresh,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_cloud_resource_rank(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


#
# plugin 命令组
#

@main.group()
@pass_ctx
def plugin(ctx: Context) -> None:
    """插件调用命令。"""


@plugin.command("call")
@click.option("--code", required=True, help="Plugin code")
@click.option("--body", required=True, help="Plugin request JSON body")
@pass_ctx
def plugin_call(ctx: Context, code: str, body: str) -> None:
    """按插件 code 调用 pluginsInstance/callByCode。"""
    try:
        if ctx.conn is None or ctx.client is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        code = code.strip()
        if not code:
            raise click.UsageError("--code cannot be empty")

        payload = _parse_plugin_body(body)
        response = ctx.client.request(
            "POST",
            f"/api/v1/pluginsInstance/callByCode/{code}",
            json_body=payload,
        )
        if not response.ok:
            message = response.message or f"Plugin call failed with HTTP {response.status_code}"
            raise ValueError(message)

        if ctx.json_mode:
            output_json(response.data)
        else:
            output_plugin_call(response.data)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


#
# subscribe 命令组
#

@main.group()
@pass_ctx
def subscribe(ctx: Context) -> None:
    """影视订阅命令。"""


@subscribe.command("add")
@click.option(
    "--type",
    "media_type",
    type=click.Choice(SUBSCRIBE_MEDIA_TYPE_CHOICES, case_sensitive=False),
    required=True,
    help="Subscribe media type",
)
@click.option("--name", required=True, help="Subscribe title")
@click.option("--year", type=click.IntRange(min=1), required=True, help="Release year")
@click.option("--season", type=click.IntRange(min=1), help="Season number for TV subscriptions")
@pass_ctx
def subscribe_add(
    ctx: Context,
    media_type: str,
    name: str,
    year: int,
    season: Optional[int],
) -> None:
    """使用默认配置新增最小电影或电视剧订阅。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        media_type = media_type.lower()
        name = name.strip()
        if not name:
            raise click.UsageError("--name cannot be empty")
        if media_type == "movie" and season is not None:
            raise click.UsageError("--season is only valid for tv subscriptions")
        if media_type == "tv" and season is None:
            season = 1

        result = ctx.subscribe_mgr.add(
            name=name,
            media_type=media_type,
            year=year,
            season=season,
        )

        if ctx.json_mode:
            output_json(result)
        else:
            output_subscribe_add(result)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)


@subscribe.command("page")
@click.option(
    "--type",
    "media_type",
    type=click.Choice(SUBSCRIBE_MEDIA_TYPE_CHOICES, case_sensitive=False),
    required=True,
    help="Subscribe media type",
)
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True, help="Page number")
@click.option(
    "--page-size",
    type=click.IntRange(min=1),
    default=20,
    show_default=True,
    help="Page size",
)
@pass_ctx
def subscribe_page(ctx: Context, media_type: str, page: int, page_size: int) -> None:
    """按类型分页查询订阅。"""
    try:
        if ctx.conn is None:
            raise ValueError("Connection state is unavailable")
        ctx.conn.require_configured()

        media_type = media_type.lower()
        result = ctx.subscribe_mgr.page(media_type=media_type, page=page, page_size=page_size)

        if ctx.json_mode:
            output_json(result)
        else:
            output_subscribe_page(result, media_type=media_type)
    except SystemExit:
        raise
    except Exception as exc:
        handle_error(ctx, exc)
