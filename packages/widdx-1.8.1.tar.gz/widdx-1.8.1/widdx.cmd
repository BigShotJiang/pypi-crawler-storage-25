@echo off
python -m widdx %*
