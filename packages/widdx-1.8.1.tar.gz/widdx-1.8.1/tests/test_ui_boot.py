"""Tests for UI boot screen and provider display."""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock


# ── Boot screen fallback (no prompt_toolkit) ─────────────────────────

def test_boot_fallback_shows_providers(capsys):
    """Fallback boot screen renders without errors."""
    from widdx.ui.boot import _fallback_boot
    from widdx.ui.theme import get_console

    router = MagicMock()
    providers = [
        {"name": "opencode", "architect_model": "big-pickle", "executor_model": "flash-free", "enabled": True, "model_count": 2},
        {"name": "kilo", "architect_model": "auto", "executor_model": "auto", "enabled": False, "model_count": 3},
    ]
    enabled_map = {"opencode": True, "kilo": False}

    _fallback_boot(get_console(), providers, enabled_map, router)

    captured = capsys.readouterr()
    assert "SELECT PROVIDERS" in captured.out
    assert "opencode" in captured.out
    assert "kilo" in captured.out


# ── Provider list rendering ──────────────────────────────────────────

def test_boot_render_shows_correct_count():
    """The render function shows correct provider count."""
    providers = [
        {"name": "deepseek", "architect_model": "v4", "executor_model": "v4", "enabled": True, "last_used": True, "model_count": 2},
        {"name": "opencode", "architect_model": "big", "executor_model": "free", "enabled": True, "last_used": False, "model_count": 2},
        {"name": "kilo", "architect_model": "auto", "executor_model": "auto", "enabled": False, "last_used": False, "model_count": 3},
    ]
    active = sum(1 for p in providers if p["enabled"])
    assert active == 2
    total = len(providers)
    assert total == 3


# ── list_providers integration ───────────────────────────────────────

def test_list_providers_model_count_accurate():
    """Model count in list_providers matches internal entries."""
    from widdx.router import AIRouter
    config = {"__env__": {"deepseek_key": None}, "models": {}}
    router = AIRouter(config, None)

    providers = router.list_providers()
    for p in providers:
        name = p["name"]
        expected = len([e for e in router._providers if e["name"] == name])
        assert p["model_count"] == expected, f"{name}: expected {expected} models, got {p['model_count']}"
