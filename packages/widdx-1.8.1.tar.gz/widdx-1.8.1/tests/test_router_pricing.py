"""Tests for widdx.router.pricing — cost tracking and token estimation."""
from __future__ import annotations

from unittest.mock import MagicMock

from widdx.router.pricing import (
    PRICING,
    _estimate_tokens,
    _init_cost_tracking,
    _track_usage,
)


class TestPricingDict:
    """PRICING constant contains expected model entries."""

    def test_deepseek_v4_pro(self):
        assert "deepseek-v4-pro" in PRICING
        assert PRICING["deepseek-v4-pro"]["input"] == 0.55
        assert PRICING["deepseek-v4-pro"]["output"] == 2.19

    def test_deepseek_v4_flash(self):
        assert "deepseek-v4-flash" in PRICING
        assert PRICING["deepseek-v4-flash"]["input"] == 0.27
        assert PRICING["deepseek-v4-flash"]["output"] == 1.10

    def test_free_models_have_zero_cost(self):
        for model in ["deepseek-v4-flash-free", "big-pickle", "kilo-auto/free"]:
            assert PRICING[model]["input"] == 0.0
            assert PRICING[model]["output"] == 0.0


class TestInitCostTracking:
    """_init_cost_tracking zeros session counters."""

    def test_zeros_all_counters(self):
        router = MagicMock()
        _init_cost_tracking(router)
        assert router._session_input_tokens == 0
        assert router._session_output_tokens == 0
        assert router._session_cost == 0.0


class TestTrackUsage:
    """_track_usage accumulates tokens and computes cost."""

    def test_accumulates_tokens(self):
        router = MagicMock()
        router._session_input_tokens = 0
        router._session_output_tokens = 0
        router._session_cost = 0.0
        _track_usage(router, "deepseek-v4-pro", 1000, 500)
        assert router._session_input_tokens == 1000
        assert router._session_output_tokens == 500

    def test_computes_cost(self):
        router = MagicMock()
        router._session_input_tokens = 0
        router._session_output_tokens = 0
        router._session_cost = 0.0
        _track_usage(router, "deepseek-v4-pro", 1_000_000, 1_000_000)
        expected = 0.55 + 2.19  # input + output for 1M tokens each
        assert abs(router._session_cost - expected) < 0.001

    def test_accumulates_cost_over_calls(self):
        router = MagicMock()
        router._session_input_tokens = 0
        router._session_output_tokens = 0
        router._session_cost = 0.0
        _track_usage(router, "deepseek-v4-pro", 1_000_000, 0)
        _track_usage(router, "deepseek-v4-pro", 0, 1_000_000)
        expected = 0.55 + 2.19
        assert abs(router._session_cost - expected) < 0.001

    def test_unknown_model_uses_default(self):
        router = MagicMock()
        router._session_input_tokens = 0
        router._session_output_tokens = 0
        router._session_cost = 0.0
        _track_usage(router, "unknown-model", 1_000_000, 1_000_000)
        # Default pricing: input=0.27, output=1.10
        expected = 0.27 + 1.10
        assert abs(router._session_cost - expected) < 0.001

    def test_free_model_no_cost(self):
        router = MagicMock()
        router._session_input_tokens = 0
        router._session_output_tokens = 0
        router._session_cost = 0.0
        _track_usage(router, "deepseek-v4-flash-free", 1_000_000, 1_000_000)
        assert router._session_cost == 0.0


class TestEstimateTokens:
    """_estimate_tokens: rough characters/4 estimation. Takes self (injected method)."""

    dummy = MagicMock()  # Acts as 'self' for the injected router method

    def test_simple_content(self):
        messages = [{"content": "hello world"}]  # 11 chars
        assert _estimate_tokens(self.dummy, messages) == 11 // 4

    def test_multiple_messages(self):
        messages = [
            {"content": "hello"},   # 5
            {"content": " world"},  # 6
        ]
        assert _estimate_tokens(self.dummy, messages) == 11 // 4

    def test_empty_messages(self):
        assert _estimate_tokens(self.dummy, []) == 0

    def test_no_content_key(self):
        assert _estimate_tokens(self.dummy, [{}]) == 0

    def test_non_string_content(self):
        messages = [{"content": ["not", "a", "string"]}]
        assert _estimate_tokens(self.dummy, messages) == 0

    def test_tool_calls_included(self):
        messages = [{
            "content": "use tool",
            "tool_calls": [
                {"function": {"arguments": '{"key":"val"}', "name": "my_tool"}}
            ],
        }]
        # "use tool" = 8, '{"key":"val"}' = 13, "my_tool" = 7 = 28 // 4 = 7
        assert _estimate_tokens(self.dummy, messages) == 7

    def test_tool_calls_without_function_key(self):
        messages = [{
            "content": "hi",
            "tool_calls": [{}],
        }]
        assert _estimate_tokens(self.dummy, messages) == 2 // 4  # only "hi"
