"""Tests for pipeline.py — ExecutionPipeline and helpers."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from widdx.pipeline import (
    ExecutionPipeline,
    PipelineResult,
    _extract_json,
)


# ── Fixtures ────────────────────────────────────────────────────────────

@pytest.fixture
def mock_router():
    r = MagicMock()
    r.infer_task_type.return_value = "general"
    r.call_executor.return_value = {"text": '{"intent": "build a project", "complexity": 3}'}
    r.call_architect.return_value = {"text": "Looks good"}
    return r


@pytest.fixture
def mock_agent_factory():
    return MagicMock()


@pytest.fixture
def mock_memory():
    m = MagicMock()
    m.create_task.return_value = None
    m.complete_task.return_value = None
    m.log_decision.return_value = None
    m.set_knowledge.return_value = None
    m.task_decisions.return_value = []
    return m


@pytest.fixture
def mock_evolution():
    e = MagicMock()
    e.evaluate.return_value = {}
    e.update.return_value = None
    e.is_enabled = True
    return e


@pytest.fixture
def pipeline(mock_router, mock_agent_factory, mock_memory, mock_evolution):
    return ExecutionPipeline(mock_router, mock_agent_factory, mock_memory, mock_evolution, {})


# ── PipelineResult ─────────────────────────────────────────────────────

class TestPipelineResult:
    def test_defaults(self):
        r = PipelineResult(task_id="abc", intent="test", complexity=1, pipeline_depth=2)
        assert r.task_id == "abc"
        assert r.plan is None
        assert r.agents_generated == []
        assert r.execution_output == ""
        assert r.total_latency_ms == 0

    def test_fields(self):
        r = PipelineResult(
            task_id="x", intent="y", complexity=3, pipeline_depth=7,
            plan={"key": "val"}, agents_generated=["a1"],
            execution_output="done", review_feedback="nice",
            evolution_report={"score": 0.8}, total_latency_ms=1200,
        )
        assert r.plan == {"key": "val"}
        assert r.evolution_report == {"score": 0.8}
        assert r.total_latency_ms == 1200


# ── ExecutionPipeline.__init__ ─────────────────────────────────────────

class TestInit:
    def test_default_config(self, mock_router, mock_agent_factory, mock_memory, mock_evolution):
        p = ExecutionPipeline(mock_router, mock_agent_factory, mock_memory, mock_evolution)
        assert p._complex_threshold == 3
        assert p._max_retries == 2
        assert p._scaffold_enabled is True

    def test_custom_config(self, mock_router, mock_agent_factory, mock_memory, mock_evolution):
        cfg = {"pipeline": {"complex_threshold": 5, "scaffold_enabled": False}}
        p = ExecutionPipeline(mock_router, mock_agent_factory, mock_memory, mock_evolution, cfg)
        assert p._complex_threshold == 5
        assert p._scaffold_enabled is False


# ── _analyze_input ─────────────────────────────────────────────────────

class TestAnalyzeInput:
    def test_high_scope_keyword(self, pipeline):
        intent, complexity = pipeline._analyze_input("build a fullstack app")
        assert complexity == 4

    def test_high_scope_keyword_saas(self, pipeline):
        intent, complexity = pipeline._analyze_input("create a saas platform")
        assert complexity == 4

    def test_delegates_to_router(self, pipeline, mock_router):
        mock_router.infer_task_type.return_value = "fix"
        intent, complexity = pipeline._analyze_input("fix the login bug")
        assert complexity == 2

    def test_general_triggers_api_call(self, pipeline, mock_router):
        mock_router.infer_task_type.return_value = "general"
        mock_router.call_executor.return_value = {
            "text": '{"intent": "build a project", "complexity": 4}'
        }
        intent, complexity = pipeline._analyze_input("something unclear")
        assert complexity == 4
        assert intent == "build a project"

    def test_general_api_call_failure_falls_back(self, pipeline, mock_router):
        mock_router.infer_task_type.return_value = "general"
        mock_router.call_executor.return_value = {"error": "API error"}
        intent, complexity = pipeline._analyze_input("something unclear")
        assert complexity == 1
        assert intent == "something unclear"

    def test_general_api_bad_json_falls_back(self, pipeline, mock_router):
        mock_router.infer_task_type.return_value = "general"
        mock_router.call_executor.return_value = {"text": "not json at all"}
        intent, complexity = pipeline._analyze_input("something unclear")
        assert complexity == 1
        assert intent == "something unclear"

    def test_complexity_clamped(self, pipeline, mock_router):
        mock_router.infer_task_type.return_value = "general"
        mock_router.call_executor.return_value = {
            "text": '{"intent": "x", "complexity": 99}'
        }
        _, complexity = pipeline._analyze_input("x")
        assert complexity == 5

    def test_complexity_minimum(self, pipeline, mock_router):
        mock_router.infer_task_type.return_value = "general"
        mock_router.call_executor.return_value = {
            "text": '{"intent": "x", "complexity": -1}'
        }
        _, complexity = pipeline._analyze_input("x")
        assert complexity == 1


# ── _is_error / _is_retryable ──────────────────────────────────────────

class TestIsError:
    def test_error_present(self, pipeline):
        assert pipeline._is_error({"error": "something broke"}) is True

    def test_no_error(self, pipeline):
        assert pipeline._is_error({"text": "all good"}) is False

    def test_empty_dict(self, pipeline):
        assert pipeline._is_error({}) is False


class TestIsRetryable:
    def test_api_key_not_set(self, pipeline):
        assert pipeline._is_retryable({"error": "API_KEY not set"}) is False

    def test_auth_failure(self, pipeline):
        assert pipeline._is_retryable({"error": "Incorrect API key"}) is False

    def test_invalid_api_key(self, pipeline):
        assert pipeline._is_retryable({"error": "invalid api key"}) is False

    def test_rate_limit_is_retryable(self, pipeline):
        assert pipeline._is_retryable({"error": "rate limit exceeded"}) is True

    def test_network_error_is_retryable(self, pipeline):
        assert pipeline._is_retryable({"error": "connection timeout"}) is True

    def test_case_insensitive(self, pipeline):
        assert pipeline._is_retryable({"error": "API_KEY Not Set"}) is False


# ── _get_install_commands ──────────────────────────────────────────────

class TestGetInstallCommands:
    def test_known_tool_returns_commands(self, pipeline):
        cmds = pipeline._get_install_commands(["python"])
        assert len(cmds) == 1
        tool, cmd_list = cmds[0]
        assert tool == "python"
        assert len(cmd_list) == 4

    def test_multiple_tools(self, pipeline):
        cmds = pipeline._get_install_commands(["php", "git"])
        assert len(cmds) == 2
        tools = {t for t, _ in cmds}
        assert tools == {"php", "git"}

    def test_unknown_tool_returns_echo(self, pipeline):
        cmds = pipeline._get_install_commands(["nonexistent_tool"])
        assert len(cmds) == 1
        tool, cmd_list = cmds[0]
        assert tool == "nonexistent_tool"
        assert "No auto-install available" in cmd_list[0]

    def test_tool_map_order(self, pipeline):
        cmds = pipeline._get_install_commands(["python"])
        _, cmd_list = cmds[0]
        assert "winget" in cmd_list[0]
        assert "choco" in cmd_list[1]
        assert "brew" in cmd_list[2]
        assert "apt" in cmd_list[3]


# ── _extract_json ──────────────────────────────────────────────────────

class TestExtractJson:
    def test_simple_object(self):
        assert json.loads(_extract_json('{"a": 1}')) == {"a": 1}

    def test_nested_object(self):
        text = '{"a": {"b": [1, 2, 3]}}'
        assert json.loads(_extract_json(text)) == {"a": {"b": [1, 2, 3]}}

    def test_fenced_code_block(self):
        text = "```json\n{\"key\": \"value\"}\n```"
        assert json.loads(_extract_json(text)) == {"key": "value"}

    def test_fenced_code_block_with_language(self):
        text = "```python\n{\"key\": \"value\"}\n```"
        assert json.loads(_extract_json(text)) == {"key": "value"}

    def test_with_surrounding_text(self):
        text = "Here is the result:\n{\"a\": 1}\nEnd."
        assert json.loads(_extract_json(text)) == {"a": 1}

    def test_array_fallback(self):
        assert json.loads(_extract_json('[1, 2, 3]')) == [1, 2, 3]

    def test_no_json_returns_original(self):
        assert _extract_json("just text") == "just text"

    def test_multiple_json_blocks(self):
        text = "first {\"a\": 1} second {\"b\": 2}"
        assert json.loads(_extract_json(text)) == {"a": 1}

    def test_inline_backtick_fence(self):
        text = "```{\"key\": \"value\"}```"
        assert json.loads(_extract_json(text)) == {"key": "value"}

    def test_brace_in_string(self):
        text = '{"a": "hello {world}"}'
        assert json.loads(_extract_json(text)) == {"a": "hello {world}"}


# ── _validate_extracted_code ───────────────────────────────────────────

class TestValidateExtractedCode:
    def test_valid_python(self, pipeline, caplog):
        pipeline._validate_extracted_code("test.py", "x = 1")
        assert not caplog.records

    def test_invalid_python(self, pipeline, caplog):
        pipeline._validate_extracted_code("test.py", "x = ")
        assert any("Python syntax error" in r.message for r in caplog.records)

    def test_valid_json(self, pipeline, caplog):
        pipeline._validate_extracted_code("config.json", '{"a": 1}')
        assert not caplog.records

    def test_invalid_json(self, pipeline, caplog):
        pipeline._validate_extracted_code("config.json", "{bad}")
        assert any("JSON syntax error" in r.message for r in caplog.records)

    def test_unknown_extension_no_op(self, pipeline, caplog):
        pipeline._validate_extracted_code("file.txt", "some text")
        assert not caplog.records


# ── _simple_system_prompt ──────────────────────────────────────────────

class TestSimpleSystemPrompt:
    def test_base_prompt(self, pipeline):
        prompt = pipeline._simple_system_prompt()
        assert "WIDDX CLI" in prompt
        assert "Write tool" in prompt

    def test_framework_detected(self, pipeline):
        with patch("widdx.tool_loop.system_prompt._detect_framework_from_task") as detect, \
             patch("widdx.tool_loop.system_prompt._framework_prompt_section") as rules:
            detect.return_value = ("laravel", "PHP")
            rules.return_value = "## Laravel Rules\n- Use Artisan"
            prompt = pipeline._simple_system_prompt("create a laravel project")
            assert "## Laravel Rules" in prompt
            assert "- Use Artisan" in prompt
            detect.assert_called_once_with("create a laravel project")

    def test_framework_not_detected(self, pipeline):
        with patch("widdx.tool_loop.system_prompt._detect_framework_from_task") as detect:
            detect.return_value = None
            prompt = pipeline._simple_system_prompt("something random")
            assert "WIDDX CLI" in prompt
            assert "Write tool" in prompt
            detect.assert_called_once_with("something random")

    def test_no_command_uses_base(self, pipeline):
        with patch("widdx.tool_loop.system_prompt._detect_framework_from_task") as detect:
            prompt = pipeline._simple_system_prompt("")
            assert "WIDDX CLI" in prompt
            detect.assert_not_called()


# ── _extract_and_save ──────────────────────────────────────────────────

class TestExtractAndSave:
    def test_extract_basic_code_block(self, pipeline, tmp_path):
        command = "save to output.py"
        output = "\n```python\ndef hello():\n    pass\n```\n"
        with patch.object(Path, "cwd", return_value=tmp_path):
            result = pipeline._extract_and_save(command, output)
        assert "output.py" in result
        assert (tmp_path / "output.py").read_text() == "def hello():\n    pass"

    def test_multiple_blocks(self, pipeline, tmp_path):
        command = "save to main.py"
        output = "\n```\ndef foo():\n    pass\n```\n\n```\ndef bar():\n    pass\n```\n"
        with patch.object(Path, "cwd", return_value=tmp_path):
            result = pipeline._extract_and_save(command, output)
        assert (tmp_path / "main.py").read_text() == "def foo():\n    pass"
        assert (tmp_path / "main_2.py").read_text() == "def bar():\n    pass"

    def test_no_save_command_returns_empty(self, pipeline):
        assert pipeline._extract_and_save("just a question", "some output") == ""

    def test_path_traversal_blocked(self, pipeline, tmp_path, caplog):
        command = "save to ../escaped.py"
        output = "\n```\nx = 1\n```\n"
        with patch.object(Path, "cwd", return_value=tmp_path):
            result = pipeline._extract_and_save(command, output)
        assert result == ""
        assert "Path traversal blocked" in caplog.text

    def test_fallback_raw_output(self, pipeline, tmp_path):
        command = "save to out.txt"
        output = "def hello():\n    pass"
        with patch.object(Path, "cwd", return_value=tmp_path):
            result = pipeline._extract_and_save(command, output)
        assert (tmp_path / "out.txt").read_text() == "def hello():\n    pass"

    def test_short_output_no_save(self, pipeline, tmp_path):
        command = "save to out.txt"
        output = "ab"
        with patch.object(Path, "cwd", return_value=tmp_path):
            result = pipeline._extract_and_save(command, output)
        assert result == ""


# ── _execute_simple (patch lazy import: widdx.tool_loop.ToolLoop) ──────

class TestExecuteSimple:
    def test_successful_execution(self, pipeline):
        with patch("widdx.tool_loop.ToolLoop") as MockLoop:
            instance = MockLoop.return_value
            instance.run.return_value = "Generated files"
            result = pipeline._execute_simple("create a readme", "task_1")
            assert result["text"] == "Generated files"
            instance.set_project_context.assert_called_once()
            instance.run.assert_called_once_with("create a readme")

    def test_retry_on_error(self, pipeline):
        with patch("widdx.tool_loop.ToolLoop") as MockLoop:
            instance = MockLoop.return_value
            instance.run.side_effect = [Exception("timeout"), "success"]
            result = pipeline._execute_simple("create a readme", "task_1")
            assert result["text"] == "success"
            assert instance.run.call_count == 2

    def test_max_retries_exhausted(self, pipeline):
        with patch("widdx.tool_loop.ToolLoop") as MockLoop:
            instance = MockLoop.return_value
            instance.run.side_effect = Exception("persistent failure")
            result = pipeline._execute_simple("create a readme", "task_1")
            assert "error" in result
            assert result["error"] == "persistent failure"

    def test_framework_detection_injected(self, pipeline):
        with patch("widdx.tool_loop.ToolLoop") as MockLoop, \
             patch("widdx.tool_loop.system_prompt._detect_framework_from_task") as detect:
            instance = MockLoop.return_value
            instance.run.return_value = "done"
            detect.return_value = ("react", "JavaScript")
            pipeline._execute_simple("create a react app", "task_1")
            instance.set_framework.assert_called_once_with("react")

    def test_logs_decision_on_success(self, pipeline, mock_memory):
        with patch("widdx.tool_loop.ToolLoop") as MockLoop:
            instance = MockLoop.return_value
            instance.run.return_value = "project created"
            pipeline._execute_simple("create project", "task_1")
            mock_memory.log_decision.assert_called_once()


# ── _run_preflight (patch lazy import: widdx.preflight.check_requirements) ─

class TestRunPreflight:
    def test_skips_without_build_keyword(self, pipeline):
        with patch("widdx.preflight.check_requirements") as check:
            result = pipeline._run_preflight("what time is it")
            assert result is True
            check.assert_not_called()

    def test_checks_required_tools_for_build(self, pipeline):
        with patch("widdx.preflight.check_requirements") as check:
            check.return_value.passed = True
            result = pipeline._run_preflight("build a new project")
            assert result is True
            check.assert_called_once()

    def test_missing_tools_triggers_install(self, pipeline):
        with patch("widdx.preflight.check_requirements") as check, \
             patch.object(pipeline, "_handle_missing_tools") as handle:
            check.return_value.passed = False
            check.return_value.missing = ["git"]
            handle.return_value = True
            result = pipeline._run_preflight("build a project")
            assert result is True
            handle.assert_called_once_with(["git"])

    def test_preflight_failure_returns_false(self, pipeline):
        with patch("widdx.preflight.check_requirements") as check, \
             patch.object(pipeline, "_handle_missing_tools") as handle, \
             patch("widdx.ui.confirm") as confirm:
            check.return_value.passed = False
            check.return_value.missing = []
            confirm.return_value = False
            result = pipeline._run_preflight("build a project")
            assert result is False


# ── _run_scaffolding (patch lazy import: widdx.scaffolder.scaffold) ────

class TestRunScaffolding:
    def test_skips_if_project_has_files(self, pipeline, tmp_path):
        (tmp_path / "existing.py").write_text("x")
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.scaffolder.scaffold") as scaffold:
            pipeline._run_scaffolding("create a laravel app")
            scaffold.assert_not_called()

    def test_scaffolds_empty_project(self, pipeline, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.scaffolder.scaffold") as scaffold:
            scaffold.return_value.error = None
            pipeline._run_scaffolding("create a laravel app")
            scaffold.assert_called_once()

    def test_scaffold_error_printed(self, pipeline, tmp_path):
        with patch.object(Path, "cwd", return_value=tmp_path), \
             patch("widdx.scaffolder.scaffold") as scaffold, \
             patch("widdx.ui.get_console") as console:
            scaffold.return_value.error = "something went wrong"
            pipeline._run_scaffolding("create a laravel app")
            console.return_value.print.assert_called_once()


# ── _get_project_context (patch lazy import: widdx.indexer.ProjectIndexer) ─

class TestGetProjectContext:
    def test_returns_context(self, pipeline):
        with patch("widdx.indexer.ProjectIndexer") as MockIndexer:
            MockIndexer.return_value.context_for_ai.return_value = "project files info"
            assert pipeline._get_project_context() == "project files info"

    def test_returns_empty_on_error(self, pipeline):
        with patch("widdx.indexer.ProjectIndexer") as MockIndexer:
            MockIndexer.return_value.context_for_ai.side_effect = Exception("fail")
            assert pipeline._get_project_context() == ""


# ── _consolidate_memory / _evolution_patch ────────────────────────────

class TestConsolidateMemory:
    def test_completes_task_and_saves(self, pipeline, mock_memory):
        pipeline._consolidate_memory("task_1", "build x", "output text", "review ok")
        mock_memory.complete_task.assert_called_once_with("task_1")
        mock_memory.set_knowledge.assert_called_once()


class TestEvolutionPatch:
    def test_evaluates_and_updates(self, pipeline, mock_memory, mock_evolution):
        mock_memory.task_decisions.return_value = [
            {"output_summary": "success", "latency_ms": 500}
        ]
        mock_evolution.evaluate.return_value = {"score": 0.9}
        result = pipeline._evolution_patch("task_1", "build x", 3)
        assert result == {"score": 0.9}
        mock_evolution.update.assert_called_once()


# ── _review_output ─────────────────────────────────────────────────────

class TestReviewOutput:
    def test_calls_architect(self, pipeline, mock_router):
        mock_router.call_architect.return_value = {"text": "review feedback"}
        result = pipeline._review_output("some command", "some output")
        assert result == "review feedback"

    def test_returns_empty_on_error(self, pipeline, mock_router):
        mock_router.call_architect.return_value = {"error": "fail"}
        result = pipeline._review_output("cmd", "out")
        assert result == ""
