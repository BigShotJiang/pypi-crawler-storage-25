"""tests/test_scheduler.py — Unit tests for TaskScheduler daemon loop (GAP-6).

Covers task 5.4: daemon loop using croniter, _tick() testability,
ImportError handling, last_run updates, and KeyboardInterrupt handling.
"""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from widdx.scheduler import TaskScheduler, _DAEMON_POLL_SECONDS, _utcnow


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_scheduler(tmp_path: Path) -> TaskScheduler:
    """Return a TaskScheduler backed by a temp file."""
    return TaskScheduler(schedules_path=str(tmp_path / "schedules.json"))


# ---------------------------------------------------------------------------
# _DAEMON_POLL_SECONDS constant
# ---------------------------------------------------------------------------

def test_daemon_poll_seconds_is_60():
    """Daemon poll interval must be exactly 60 seconds (REQ-6.3)."""
    assert _DAEMON_POLL_SECONDS == 60


# ---------------------------------------------------------------------------
# _tick() — testable without sleeping
# ---------------------------------------------------------------------------

def test_tick_runs_due_task(tmp_scheduler: TaskScheduler):
    """_tick() calls runner_fn when cron expression matches now."""
    task_id = tmp_scheduler.add("* * * * *", "echo hello")  # every minute

    called_with: list[str] = []

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return True  # always due

    tmp_scheduler._tick(FakeCroniter, lambda task: called_with.append(task) or "ok")

    assert called_with == ["echo hello"]


def test_tick_skips_non_due_task(tmp_scheduler: TaskScheduler):
    """_tick() does NOT call runner_fn when cron expression does not match."""
    tmp_scheduler.add("0 0 1 1 *", "new year task")  # only Jan 1 at midnight

    called: list[str] = []

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return False  # never due

    tmp_scheduler._tick(FakeCroniter, lambda task: called.append(task) or "")

    assert called == []


def test_tick_updates_last_run(tmp_scheduler: TaskScheduler):
    """_tick() updates last_run timestamp after executing a due task."""
    task_id = tmp_scheduler.add("* * * * *", "update me")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return True

    before = datetime.now(timezone.utc)
    tmp_scheduler._tick(FakeCroniter, lambda task: "done")

    schedules = tmp_scheduler.list_schedules()
    assert len(schedules) == 1
    last_run = schedules[0]["last_run"]
    assert last_run is not None
    # last_run should be a valid ISO-8601 timestamp after 'before'
    parsed = datetime.fromisoformat(last_run)
    assert parsed >= before


def test_tick_does_not_update_last_run_when_not_due(tmp_scheduler: TaskScheduler):
    """_tick() leaves last_run as None when task is not due."""
    tmp_scheduler.add("0 0 1 1 *", "not due")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return False

    tmp_scheduler._tick(FakeCroniter, lambda task: "")

    schedules = tmp_scheduler.list_schedules()
    assert schedules[0]["last_run"] is None


def test_tick_handles_runner_exception(tmp_scheduler: TaskScheduler):
    """_tick() catches runner_fn exceptions and records error in last_run."""
    tmp_scheduler.add("* * * * *", "failing task")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return True

    def bad_runner(task: str) -> str:
        raise RuntimeError("boom")

    # Should not raise
    tmp_scheduler._tick(FakeCroniter, bad_runner)

    # last_run should still be updated even on failure
    schedules = tmp_scheduler.list_schedules()
    assert schedules[0]["last_run"] is not None


def test_tick_handles_invalid_cron_expression(tmp_scheduler: TaskScheduler):
    """_tick() skips tasks with invalid cron expressions without crashing."""
    tmp_scheduler.add("not-a-cron", "bad task")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            raise ValueError("invalid cron")

    # Should not raise
    tmp_scheduler._tick(FakeCroniter, lambda task: "")


def test_tick_runs_multiple_due_tasks(tmp_scheduler: TaskScheduler):
    """_tick() runs all due tasks in a single poll cycle."""
    tmp_scheduler.add("* * * * *", "task-a")
    tmp_scheduler.add("* * * * *", "task-b")

    ran: list[str] = []

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return True

    tmp_scheduler._tick(FakeCroniter, lambda task: ran.append(task) or "ok")

    assert sorted(ran) == ["task-a", "task-b"]


# ---------------------------------------------------------------------------
# run_daemon() — ImportError handling
# ---------------------------------------------------------------------------

def test_run_daemon_exits_gracefully_when_croniter_missing(
    tmp_scheduler: TaskScheduler, capsys
):
    """run_daemon() prints a helpful message and returns when croniter is absent."""
    with patch.dict("sys.modules", {"croniter": None}):
        # Simulate ImportError by patching the import inside run_daemon
        import builtins
        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "croniter":
                raise ImportError("No module named 'croniter'")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=mock_import):
            tmp_scheduler.run_daemon()  # must return, not raise

    captured = capsys.readouterr()
    assert "croniter" in captured.out.lower() or "pip install" in captured.out.lower()


# ---------------------------------------------------------------------------
# run_daemon() — KeyboardInterrupt handling
# ---------------------------------------------------------------------------

def test_run_daemon_stops_on_keyboard_interrupt(
    tmp_scheduler: TaskScheduler, capsys
):
    """run_daemon() stops cleanly on KeyboardInterrupt."""
    # Patch time.sleep to raise KeyboardInterrupt immediately
    with patch("widdx.scheduler.time.sleep", side_effect=KeyboardInterrupt):
        # Also patch croniter import to succeed
        mock_croniter = MagicMock()
        mock_croniter.match.return_value = False

        with patch.dict("sys.modules", {"croniter": MagicMock(croniter=mock_croniter)}):
            import builtins
            real_import = builtins.__import__

            def mock_import(name, *args, **kwargs):
                if name == "croniter":
                    mod = MagicMock()
                    mod.croniter = mock_croniter
                    return mod
                return real_import(name, *args, **kwargs)

            with patch("builtins.__import__", side_effect=mock_import):
                tmp_scheduler.run_daemon()  # must not raise

    captured = capsys.readouterr()
    assert "stopped" in captured.out.lower()


# ---------------------------------------------------------------------------
# run_daemon() — default runner_fn
# ---------------------------------------------------------------------------

def test_run_daemon_uses_default_noop_runner(tmp_scheduler: TaskScheduler):
    """run_daemon() works without a runner_fn (uses no-op lambda)."""
    tmp_scheduler.add("* * * * *", "silent task")

    tick_calls: list[None] = []

    original_tick = tmp_scheduler._tick

    def patched_tick(croniter_cls, runner_fn):
        tick_calls.append(None)
        # Call once then raise KeyboardInterrupt to stop the loop
        raise KeyboardInterrupt

    tmp_scheduler._tick = patched_tick  # type: ignore[method-assign]

    with patch("widdx.scheduler.time.sleep"):
        import builtins
        real_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "croniter":
                mod = MagicMock()
                mod.croniter = MagicMock()
                return mod
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=mock_import):
            tmp_scheduler.run_daemon()  # no runner_fn passed

    assert len(tick_calls) == 1


# ---------------------------------------------------------------------------
# Task 5.5 — Memory integration: save scheduled task results in memory
# ---------------------------------------------------------------------------

def test_tick_saves_result_to_memory_when_task_runs(tmp_path: Path):
    """_tick() calls create_task, complete_task, and set_knowledge when memory is provided."""
    from unittest.mock import MagicMock
    from widdx.scheduler import TaskScheduler

    mock_memory = MagicMock()
    scheduler = TaskScheduler(
        schedules_path=str(tmp_path / "schedules.json"),
        memory=mock_memory,
    )
    scheduler.add("* * * * *", "save me to memory")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return True

    scheduler._tick(FakeCroniter, lambda task: "result text")

    mock_memory.create_task.assert_called_once()
    call_args = mock_memory.create_task.call_args
    assert call_args[0][1] == "save me to memory"  # command
    assert call_args[1].get("intent") == "scheduled" or call_args[0][2] == "scheduled"

    mock_memory.complete_task.assert_called_once()

    mock_memory.set_knowledge.assert_called_once()
    key_arg = mock_memory.set_knowledge.call_args[0][0]
    value_arg = mock_memory.set_knowledge.call_args[0][1]
    assert key_arg.startswith("scheduled_result:")
    assert value_arg == "result text"


def test_tick_does_not_call_memory_when_task_not_due(tmp_path: Path):
    """_tick() does NOT call memory methods when the task is not due."""
    from unittest.mock import MagicMock
    from widdx.scheduler import TaskScheduler

    mock_memory = MagicMock()
    scheduler = TaskScheduler(
        schedules_path=str(tmp_path / "schedules.json"),
        memory=mock_memory,
    )
    scheduler.add("0 0 1 1 *", "not due task")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return False

    scheduler._tick(FakeCroniter, lambda task: "")

    mock_memory.create_task.assert_not_called()
    mock_memory.complete_task.assert_not_called()
    mock_memory.set_knowledge.assert_not_called()


def test_tick_does_not_call_memory_when_memory_is_none(tmp_path: Path):
    """_tick() works fine without a memory store (memory=None by default)."""
    from widdx.scheduler import TaskScheduler

    scheduler = TaskScheduler(schedules_path=str(tmp_path / "schedules.json"))
    scheduler.add("* * * * *", "no memory task")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return True

    # Should not raise even without memory
    scheduler._tick(FakeCroniter, lambda task: "ok")

    schedules = scheduler.list_schedules()
    assert schedules[0]["last_run"] is not None


def test_tick_memory_set_knowledge_key_uses_schedule_id(tmp_path: Path):
    """set_knowledge key is 'scheduled_result:<schedule_id>'."""
    from unittest.mock import MagicMock
    from widdx.scheduler import TaskScheduler

    mock_memory = MagicMock()
    scheduler = TaskScheduler(
        schedules_path=str(tmp_path / "schedules.json"),
        memory=mock_memory,
    )
    task_id = scheduler.add("* * * * *", "check key format")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return True

    scheduler._tick(FakeCroniter, lambda task: "output")

    key_arg = mock_memory.set_knowledge.call_args[0][0]
    assert key_arg == f"scheduled_result:{task_id}"


def test_tick_memory_result_truncated_to_500_chars(tmp_path: Path):
    """set_knowledge value is truncated to 500 characters."""
    from unittest.mock import MagicMock
    from widdx.scheduler import TaskScheduler

    mock_memory = MagicMock()
    scheduler = TaskScheduler(
        schedules_path=str(tmp_path / "schedules.json"),
        memory=mock_memory,
    )
    scheduler.add("* * * * *", "long result task")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return True

    long_result = "x" * 1000
    scheduler._tick(FakeCroniter, lambda task: long_result)

    value_arg = mock_memory.set_knowledge.call_args[0][1]
    assert len(value_arg) == 500
    assert value_arg == "x" * 500


def test_tick_memory_empty_result_stored_as_empty_marker(tmp_path: Path):
    """set_knowledge stores '(empty)' when runner returns empty string."""
    from unittest.mock import MagicMock
    from widdx.scheduler import TaskScheduler

    mock_memory = MagicMock()
    scheduler = TaskScheduler(
        schedules_path=str(tmp_path / "schedules.json"),
        memory=mock_memory,
    )
    scheduler.add("* * * * *", "empty result task")

    class FakeCroniter:
        @staticmethod
        def match(expr, dt):
            return True

    scheduler._tick(FakeCroniter, lambda task: "")

    value_arg = mock_memory.set_knowledge.call_args[0][1]
    assert value_arg == "(empty)"


def test_scheduler_init_accepts_memory_parameter(tmp_path: Path):
    """TaskScheduler.__init__ accepts a memory keyword argument."""
    from unittest.mock import MagicMock
    from widdx.scheduler import TaskScheduler

    mock_memory = MagicMock()
    scheduler = TaskScheduler(
        schedules_path=str(tmp_path / "schedules.json"),
        memory=mock_memory,
    )
    assert scheduler._memory is mock_memory


def test_scheduler_init_memory_defaults_to_none(tmp_path: Path):
    """TaskScheduler._memory defaults to None when not provided."""
    from widdx.scheduler import TaskScheduler

    scheduler = TaskScheduler(schedules_path=str(tmp_path / "schedules.json"))
    assert scheduler._memory is None
