"""Tests for JSON Schema tool definitions and _build_tool_properties."""
from __future__ import annotations

import pytest

from widdx.router.tools_api import _build_api_tools, _build_tool_properties
from widdx.tool_loop.tools import TOOL_DEFINITIONS


# ── _build_tool_properties ─────────────────────────────────────────────────

class TestBuildToolProperties:
    def test_string_type_default(self):
        props, required = _build_tool_properties({"path": "string (required) — file path"})
        assert props["path"]["type"] == "string"

    def test_integer_type_detected(self):
        props, _ = _build_tool_properties({"count": "int (optional) — number of items"})
        assert props["count"]["type"] == "integer"

    def test_boolean_type_detected(self):
        props, _ = _build_tool_properties({"enabled": "bool (optional) — enable feature"})
        assert props["enabled"]["type"] == "boolean"

    def test_array_type_detected(self):
        props, _ = _build_tool_properties({"items": "array (optional) — list of values"})
        assert props["items"]["type"] == "array"

    def test_required_when_no_optional_marker(self):
        _, required = _build_tool_properties({
            "file_path": "string (required) — path",
            "limit": "int (optional) — max lines",
        })
        assert "file_path" in required
        assert "limit" not in required

    def test_optional_excluded_from_required(self):
        _, required = _build_tool_properties({
            "timeout": "int (optional, default 60) — seconds",
        })
        assert "timeout" not in required

    def test_default_false_attached(self):
        props, _ = _build_tool_properties({"overwrite": "bool (optional, default false)"})
        assert props["overwrite"].get("default") is False

    def test_default_true_attached(self):
        props, _ = _build_tool_properties({"verbose": "bool (optional, default true)"})
        assert props["verbose"].get("default") is True

    def test_description_preserved(self):
        desc = "string (required) — the exact text to replace"
        props, _ = _build_tool_properties({"old_string": desc})
        assert props["old_string"]["description"] == desc

    def test_empty_params(self):
        props, required = _build_tool_properties({})
        assert props == {}
        assert required == []


# ── TOOL_DEFINITIONS schema completeness ──────────────────────────────────

class TestToolDefinitionsSchema:
    """Every tool in TOOL_DEFINITIONS must carry a complete JSON Schema."""

    @pytest.mark.parametrize("tool", TOOL_DEFINITIONS, ids=lambda t: t["name"])
    def test_has_schema_key(self, tool):
        assert "schema" in tool, f"Tool '{tool['name']}' is missing 'schema' key"

    @pytest.mark.parametrize("tool", TOOL_DEFINITIONS, ids=lambda t: t["name"])
    def test_schema_type_object(self, tool):
        assert tool["schema"]["type"] == "object"

    @pytest.mark.parametrize("tool", TOOL_DEFINITIONS, ids=lambda t: t["name"])
    def test_schema_has_properties(self, tool):
        assert "properties" in tool["schema"]
        assert isinstance(tool["schema"]["properties"], dict)

    @pytest.mark.parametrize("tool", TOOL_DEFINITIONS, ids=lambda t: t["name"])
    def test_schema_has_required_list(self, tool):
        assert "required" in tool["schema"]
        assert isinstance(tool["schema"]["required"], list)

    @pytest.mark.parametrize("tool", TOOL_DEFINITIONS, ids=lambda t: t["name"])
    def test_required_fields_exist_in_properties(self, tool):
        props = tool["schema"]["properties"]
        for field in tool["schema"]["required"]:
            assert field in props, (
                f"Tool '{tool['name']}': required field '{field}' not in properties"
            )

    @pytest.mark.parametrize("tool", TOOL_DEFINITIONS, ids=lambda t: t["name"])
    def test_each_property_has_type_and_description(self, tool):
        for name, prop in tool["schema"]["properties"].items():
            assert "type" in prop, f"Tool '{tool['name']}', param '{name}': missing 'type'"
            assert "description" in prop, (
                f"Tool '{tool['name']}', param '{name}': missing 'description'"
            )

    def test_read_requires_file_path(self):
        read = next(t for t in TOOL_DEFINITIONS if t["name"] == "Read")
        assert "file_path" in read["schema"]["required"]

    def test_write_requires_file_path_and_content(self):
        write = next(t for t in TOOL_DEFINITIONS if t["name"] == "Write")
        assert "file_path" in write["schema"]["required"]
        assert "content" in write["schema"]["required"]

    def test_bash_requires_command(self):
        bash = next(t for t in TOOL_DEFINITIONS if t["name"] == "Bash")
        assert "command" in bash["schema"]["required"]


# ── _build_api_tools ───────────────────────────────────────────────────────

class TestBuildApiTools:
    def test_output_format(self):
        api = _build_api_tools(TOOL_DEFINITIONS)
        for item in api:
            assert item["type"] == "function"
            fn = item["function"]
            assert "name" in fn
            assert "description" in fn
            assert "parameters" in fn
            assert fn["parameters"]["type"] == "object"

    def test_schema_key_used_verbatim(self):
        """When a tool has a 'schema' key, it must be used as-is."""
        tool = {
            "name": "TestTool",
            "description": "A test tool",
            "schema": {
                "type": "object",
                "properties": {"x": {"type": "integer", "description": "x value"}},
                "required": ["x"],
            },
        }
        api = _build_api_tools([tool])
        assert api[0]["function"]["parameters"] == tool["schema"]

    def test_legacy_parameters_fallback(self):
        """Tools without 'schema' fall back to _build_tool_properties."""
        tool = {
            "name": "LegacyTool",
            "description": "Old style",
            "parameters": {
                "query": "string (required) — search query",
            },
        }
        api = _build_api_tools([tool])
        params = api[0]["function"]["parameters"]
        assert params["properties"]["query"]["type"] == "string"
        assert "query" in params["required"]

    def test_all_builtin_tools_produce_valid_api_format(self):
        api = _build_api_tools(TOOL_DEFINITIONS)
        assert len(api) == len(TOOL_DEFINITIONS)
        names = [item["function"]["name"] for item in api]
        expected = [t["name"] for t in TOOL_DEFINITIONS]
        assert names == expected
