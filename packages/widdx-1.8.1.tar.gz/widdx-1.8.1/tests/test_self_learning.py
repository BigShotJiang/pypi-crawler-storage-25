"""Tests for the self-learning ledger and draft asset generation."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

from widdx.self_learning import SelfLearningEngine


class TestSelfLearningEngine:
    def test_records_learning_event(self, memory):
        learner = SelfLearningEngine(memory, {"self_learning": {"enabled": True}})

        learner.record_task(
            task_id="task-1",
            command="build a FastAPI endpoint in Python",
            result_summary="Created API endpoint and tests",
            provider="opencode",
            files_touched=["app/main.py", "tests/test_api.py"],
            tool_calls=4,
            success=True,
            complexity=3,
        )

        events = memory.recent_learning_events()
        assert len(events) == 1
        assert events[0]["task_id"] == "task-1"
        assert events[0]["provider"] == "opencode"
        assert "python" in events[0]["domains"]

    def test_repeated_success_creates_draft_assets(self, memory):
        learner = SelfLearningEngine(memory, {"self_learning": {"enabled": True, "draft_threshold": 3}})

        for idx in range(3):
            learner.record_task(
                task_id=f"task-{idx}",
                command="build a Laravel API with auth",
                result_summary="Built Laravel endpoint",
                provider="kilo",
                files_touched=["routes/api.php", "app/Http/Controllers/AuthController.php"],
                tool_calls=5,
                success=True,
                complexity=4,
            )

        assets = memory.list_learning_assets(limit=10)
        names = {asset["name"] for asset in assets}
        assert "auto-skill-php" in names
        assert "auto-agent-php" in names
        assert "auto-workflow-build-php" in names

    def test_failed_tasks_do_not_promote_assets(self, memory):
        learner = SelfLearningEngine(memory, {"self_learning": {"enabled": True, "draft_threshold": 2}})

        for idx in range(3):
            learner.record_task(
                task_id=f"failed-{idx}",
                command="fix a React component",
                result_summary="API Error: provider failed",
                provider="opencode",
                files_touched=["src/App.tsx"],
                tool_calls=2,
                success=False,
                complexity=2,
            )

        assert memory.list_learning_assets(limit=10) == []

    def test_infer_domains_uses_keywords_and_extensions(self):
        domains = SelfLearningEngine.infer_domains(
            "design a React dashboard with Docker",
            ["src/App.tsx", "Dockerfile"],
        )
        assert "typescript" in domains
        assert "docker" in domains
        assert "frontend" in domains


class TestLearningCommand:
    def test_show_learning_renders_dashboard(self):
        from widdx.repl.commands import _show_learning

        repl = MagicMock()
        repl._self_learning = MagicMock()
        repl._self_learning.is_enabled = True
        repl._self_learning.dashboard.return_value = {
            "events": [{"task_type": "build", "provider": "opencode", "success": 1, "task_text": "build api"}],
            "patterns": [{"scope": "python", "evidence_count": 3, "confidence": 0.8}],
            "assets": [{"asset_type": "skill", "name": "auto-skill-python", "status": "draft"}],
        }
        console = MagicMock()

        with patch("widdx.ui.get_console", return_value=console):
            _show_learning(repl)

        printed = [str(call[0][0]) for call in console.print.call_args_list if call[0]]
        assert any("Learning Ledger" in text for text in printed)
        assert any("Recurring Patterns" in text for text in printed)
