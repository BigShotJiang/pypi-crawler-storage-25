"""Agent registry — maps domain names to built-in agent definitions."""
from __future__ import annotations

from .architect import SOFTWARE_ARCHITECT
from .backend import BACKEND_ARCHITECT
from .code_reviewer import CODE_REVIEWER
from .data_engineer import DATA_ENGINEER
from .database_architect import DATABASE_ARCHITECT
from .devops import DEVOPS_AUTOMATOR
from .frontend import FRONTEND_DEVELOPER
from .fullstack import FULLSTACK_DEVELOPER
from .laravel import LARAVEL_ARCHITECT
from .qa import QA_ENGINEER
from .security import SECURITY_REVIEWER
from .systems_architect import SYSTEMS_ARCHITECT

# All built-in agents indexed by domain
BUILTIN_AGENTS: dict[str, dict] = {
    "backend":    BACKEND_ARCHITECT,
    "frontend":   FRONTEND_DEVELOPER,
    "devops":     DEVOPS_AUTOMATOR,
    "qa":         QA_ENGINEER,
    "architect":  SOFTWARE_ARCHITECT,
    "fullstack":  FULLSTACK_DEVELOPER,
    "security":   SECURITY_REVIEWER,
    "data":       DATA_ENGINEER,
    "reviewer":   CODE_REVIEWER,
    "laravel":    LARAVEL_ARCHITECT,
    "systems":    SYSTEMS_ARCHITECT,
    "database":   DATABASE_ARCHITECT,
}

# Aliases for common names the LLM might generate
_ALIASES: dict[str, str] = {
    "backend engineer":       "backend",
    "backend developer":      "backend",
    "api developer":          "backend",
    "server engineer":        "backend",
    "frontend engineer":      "frontend",
    "frontend developer":     "frontend",
    "ui developer":           "frontend",
    "react developer":        "frontend",
    "vue developer":          "frontend",
    "next.js developer":      "frontend",
    "devops engineer":        "devops",
    "devops automator":       "devops",
    "infrastructure engineer":"devops",
    "platform engineer":      "devops",
    "qa engineer":            "qa",
    "test engineer":          "qa",
    "quality engineer":       "qa",
    "tester":                 "qa",
    "software architect":     "architect",
    "system architect":       "architect",
    "principal engineer":     "architect",
    "tech lead":              "architect",
    "full-stack developer":   "fullstack",
    "fullstack developer":    "fullstack",
    "full stack developer":   "fullstack",
    "generalist":             "fullstack",
    "security engineer":      "security",
    "security reviewer":      "security",
    "penetration tester":     "security",
    "pentester":              "security",
    "data engineer":          "data",
    "database engineer":      "data",
    "sql specialist":         "data",
    "etl developer":          "data",
    "code reviewer":          "reviewer",
    "reviewer":               "reviewer",
    "pr reviewer":            "reviewer",
    "php developer":          "laravel",
    "laravel developer":      "laravel",
    "laravel architect":      "laravel",
    "php architect":          "laravel",
    "systems architect":      "systems",
    "integration architect":  "systems",
    "lead architect":         "systems",
    "solution architect":     "systems",
    "database architect":     "database",
    "dba":                    "database",
    "schema designer":        "database",
    "sql architect":          "database",
}


class AgentRegistry:
    """Looks up built-in agent definitions by domain or role name."""

    @staticmethod
    def get(domain_or_role: str) -> dict | None:
        """Return agent definition for a domain or role name, or None if not found."""
        key = domain_or_role.lower().strip()
        # Direct domain match
        if key in BUILTIN_AGENTS:
            return BUILTIN_AGENTS[key]
        # Alias match
        mapped = _ALIASES.get(key)
        if mapped:
            return BUILTIN_AGENTS[mapped]
        return None

    @staticmethod
    def get_system_prompt(domain_or_role: str, fallback: str = "") -> str:
        """Return the system prompt for an agent, or fallback if not found."""
        agent = AgentRegistry.get(domain_or_role)
        if agent:
            return str(agent["system_prompt"])
        return fallback

    @staticmethod
    def list_agents() -> list[dict]:
        """Return all built-in agents as a list (includes emoji, name, domain, description)."""
        return [
            {
                "name": a["name"],
                "emoji": a.get("emoji", ""),
                "domain": a["domain"],
                "description": a["description"],
            }
            for a in BUILTIN_AGENTS.values()
        ]

    @staticmethod
    def domains() -> list[str]:
        """Return all available domain names."""
        return list(BUILTIN_AGENTS.keys())
