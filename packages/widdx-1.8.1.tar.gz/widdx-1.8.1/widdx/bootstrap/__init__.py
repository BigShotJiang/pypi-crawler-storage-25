"""widdx/bootstrap/__init__.py -- Self-learning bootstrapper for new technologies.

When starting a new project with an unfamiliar framework, the bootstrapper:
1. Synthesizes the LLM's knowledge about the technology into structured reference material
2. Generates a project-specific skill file (.widdx/skills/<tech>.md)
3. Generates a technology-specific agent definition (.widdx/agents/<tech>.md)
4. Generates hooks if the technology has specific safety or automation needs

Note: Research is based on the LLM's training knowledge, not live web search.
For cutting-edge or niche frameworks, results may be incomplete or outdated.
"""

from __future__ import annotations

import json
import re
from pathlib import Path


class BootstrapResult:
    """What the bootstrapper produced."""

    def __init__(self) -> None:
        self.tech: str = ""
        self.skills_created: list[str] = []
        self.agents_created: list[str] = []
        self.hooks_created: list[str] = []
        self.summary: str = ""

    def report(self) -> str:
        lines = [f"## Bootstrap: {self.tech}"]
        if self.skills_created:
            lines.append("\n### Skills")
            for s in self.skills_created:
                lines.append(f"  - {s}")
        if self.agents_created:
            lines.append("\n### Agents")
            for a in self.agents_created:
                lines.append(f"  - {a}")
        if self.hooks_created:
            lines.append("\n### Hooks")
            for h in self.hooks_created:
                lines.append(f"  - {h}")
        if self.summary:
            lines.append(f"\n{self.summary}")
        return "\n".join(lines)


class BootstrapManager:
    """Orchestrates the self-learning bootstrapping process.

    Uses the router to call an LLM that researches a technology and
    generates project-specific skill, agent, and hook files.
    """

    def __init__(self, router) -> None:
        self._router = router

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def bootstrap(self, technology: str, project_dir: str | None = None) -> BootstrapResult:
        """Research a technology and generate project-specific config.

        Args:
            technology: The technology/framework name (e.g. "laravel", "nextjs").
            project_dir: Target project directory. Defaults to cwd.

        Returns:
            BootstrapResult describing what was created.
        """
        result = BootstrapResult()
        result.tech = technology

        cwd = Path(project_dir) if project_dir else Path.cwd()
        widdx_dir = cwd / ".widdx"
        widdx_dir.mkdir(parents=True, exist_ok=True)
        (widdx_dir / "skills").mkdir(exist_ok=True)
        (widdx_dir / "agents").mkdir(exist_ok=True)
        (widdx_dir / "hooks").mkdir(exist_ok=True)

        # Phase 1: Research
        research = self._research(technology)
        if not research or len(research) < 100:
            result.summary = f"Could not find sufficient documentation for {technology}."
            return result

        # Phase 2: Generate skill file
        skill_content = self._generate_skill(technology, research)
        skill_path = widdx_dir / "skills" / f"{technology}.md"
        skill_path.write_text(skill_content, encoding="utf-8")
        result.skills_created.append(str(skill_path))

        # Phase 3: Generate agent file
        agent_content = self._generate_agent(technology, research)
        agent_path = widdx_dir / "agents" / f"{technology}.md"
        agent_path.write_text(agent_content, encoding="utf-8")
        result.agents_created.append(str(agent_path))

        # Phase 4: Generate hooks if applicable
        hooks = self._generate_hooks(technology, research)
        if hooks:
            hooks_path = widdx_dir / "hooks" / "hooks.json"
            existing = {}
            if hooks_path.exists():
                try:
                    existing = json.loads(hooks_path.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, OSError):
                    pass
            merged = self._deep_merge(existing, hooks)
            hooks_path.write_text(
                json.dumps(merged, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            result.hooks_created.append(str(hooks_path))

        result.summary = (
            f"Ready to work with {technology}. "
            f"Reload or restart to activate the new skill and agent."
        )
        return result

    # ------------------------------------------------------------------
    # Phase 1: Research
    # ------------------------------------------------------------------

    def _research(self, technology: str) -> str:
        """Synthesize LLM knowledge about a technology into structured reference material.

        Uses the architect model (higher quality reasoning) to produce a comprehensive
        guide covering project structure, naming conventions, core patterns, security
        rules, CLI commands, testing, and performance best practices.

        Note: This relies entirely on the LLM's training data — no live web search
        is performed. Results may be outdated for rapidly evolving frameworks.
        """
        system = """You are a senior developer researching a technology for a new project.

Research and document the following. Be specific and concrete -- this will become
reference material for an AI coding agent.

## Required sections

### 1. Project Structure
What is the standard directory layout? Where do models, controllers, views, config,
tests, and migrations live? Show the tree.

### 2. Naming Conventions
How are files, classes, methods, variables, database tables, and columns named?
Give the exact conventions (PascalCase, camelCase, snake_case, etc.)

### 3. Core Patterns
What are the 5 most important patterns a developer must know? Include code examples.
- Routing pattern
- Database/ORM pattern
- Validation pattern
- Authentication pattern
- Error handling pattern

### 4. Security Rules
List the top 5 security rules specific to this technology. Include what NOT to do.

### 5. Common Commands
List the essential CLI commands for development (server start, migrations, testing, etc.)

### 6. Testing Conventions
How are tests organized? What testing tools are standard? Show a simple test example.

### 7. Performance Best Practices
Top 5 performance rules for this technology.

### 8. Key Config Files
What are the essential configuration files and what do they control?

Output as clean, well-structured markdown. Every section must have concrete, actionable information."""

        user = (
            f"Technology: {technology}\n\n"
            f"Research this thoroughly. Provide practical, detailed information "
            f"that an AI coding agent can use as reference when working on a "
            f"{technology} project. Include code examples where helpful."
        )

        result = self._router.call_architect(system, user, max_tokens=8192)
        if "error" in result:
            return ""

        return str(result.get("text", ""))

    # ------------------------------------------------------------------
    # Phase 2: Generate skill
    # ------------------------------------------------------------------

    def _generate_skill(self, technology: str, research: str) -> str:
        """Generate a SKILL.md file from research findings."""
        system = """Convert the following research into a SKILL.md file.

Format:
---
name: {technology}
description: {one-line description of what this skill covers}
---

# {Technology} Conventions

Extract and organize the research into these sections:
1. Project Structure
2. Naming Conventions
3. Core Patterns (with code examples)
4. Security Rules
5. Common Commands
6. Testing

Keep it concise. Use code blocks for examples. No fluff, no marketing language.
Target: 150-250 lines of dense, actionable reference material."""

        user = f"Technology: {technology}\n\nResearch:\n{research[:12000]}"

        result = self._router.call_executor(system, user, max_tokens=4096)
        if "error" in result:
            return f"# {technology}\n\n{research[:3000]}"

        return str(result.get("text", ""))

    # ------------------------------------------------------------------
    # Phase 3: Generate agent
    # ------------------------------------------------------------------

    def _generate_agent(self, technology: str, research: str) -> str:
        """Generate an agent definition from research findings."""
        system = """Convert the following research into a Claude Code compatible subagent markdown file.

Format:
---
name: {technology}-developer
description: {one-line role description}
tools: Read, Write, Edit, Bash, Glob, Grep
---

You are a senior {technology} developer.

## Your Role
[2-3 sentences describing the agent's purpose]

## Conventions
[Extract naming conventions, file structure, patterns]

## Rules
[Extract security rules and best practices]

## Workflow
1. [First step]
2. [Second step]
3. [Third step]

Keep it practical and specific. The agent should be usable immediately."""

        user = f"Technology: {technology}\n\nResearch:\n{research[:12000]}"

        result = self._router.call_executor(system, user, max_tokens=4096)
        if "error" in result:
            return (
                f"---\n"
                f"name: {technology}-developer\n"
                f"description: {technology} developer\n"
                f"tools: Read, Write, Edit, Bash, Glob, Grep\n"
                f"---\n\n"
                f"# {technology} Developer\n\n{research[:2000]}"
            )

        return str(result.get("text", ""))

    # ------------------------------------------------------------------
    # Phase 4: Generate hooks
    # ------------------------------------------------------------------

    def _generate_hooks(self, technology: str, research: str) -> dict | None:
        """Generate hook configurations specific to this technology.

        Returns a hooks dict to merge into hooks.json, or None if no hooks needed.
        """
        system = """Based on the research, determine if there are any CLI commands
that should be hooked for safety or automation.

Output a JSON object with hook configurations, or an empty object {{}} if none needed.

Look for:
- Dangerous commands that should be blocked (e.g., `rm -rf`, `DROP TABLE`)
- Commands that should run after file changes (e.g., linters, formatters)
- Technology-specific dangerous patterns

Format (flat structure — type and command at the same level):
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "type": "command",
        "command": "echo 'Security check or deny pattern'"
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "type": "command",
        "command": "echo 'File modified: $WIDDX_FILE_PATH'",
        "async": true
      }
    ]
  }
}

Only include hooks that are SPECIFIC to this technology and not already covered
by the global hooks. Return {{}} if no additional hooks are needed."""

        user = f"Technology: {technology}\n\nResearch:\n{research[:6000]}"

        result = self._router.call_executor(system, user, max_tokens=2048)
        if "error" in result:
            return None

        text = result.get("text", "").strip()
        # Extract JSON
        try:
            start = text.find("{")
            end = text.rfind("}")
            if start != -1 and end != -1:
                data = json.loads(text[start:end + 1])
                hooks = data.get("hooks", {})
                if hooks:
                    return {"hooks": hooks}
        except (json.JSONDecodeError, ValueError):
            pass

        return None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _deep_merge(base: dict, overlay: dict) -> dict:
        """Deep merge overlay into base. overlay values take precedence."""
        result = dict(base)
        for key, value in overlay.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = BootstrapManager._deep_merge(result[key], value)
            elif key in result and isinstance(result[key], list) and isinstance(value, list):
                result[key] = result[key] + value
            else:
                result[key] = value
        return result


__all__ = ["BootstrapManager", "BootstrapResult"]
