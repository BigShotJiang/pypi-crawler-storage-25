"""
widdx/mcp/config.py — MCP configuration loader/saver

Reads and writes ~/.widdx/mcp.json, exposing the parsed server definitions
as an MCPConfig dataclass.  MCPRegistry delegates to this module so that
config I/O is separated from connection management.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

_DEFAULT_PATH = "~/.widdx/mcp.json"

# ---------------------------------------------------------------------------
# MCPConfig
# ---------------------------------------------------------------------------


@dataclass
class MCPConfig:
    """Parsed representation of mcp.json.

    Attributes:
        servers: Mapping of server name → raw server config dict, mirroring
                 the ``mcpServers`` key in mcp.json.
    """

    servers: dict[str, dict] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# load_mcp_config
# ---------------------------------------------------------------------------


def load_mcp_config(path: str | Path = _DEFAULT_PATH) -> MCPConfig:
    """Read and parse mcp.json, returning an MCPConfig.

    Args:
        path: Path to the mcp.json file.  Tilde expansion is applied.

    Returns:
        MCPConfig with the parsed ``mcpServers`` dict, or an empty MCPConfig
        when the file is absent or malformed (REQ-1 criterion 4).
    """
    resolved = Path(path).expanduser()

    if not resolved.exists():
        logger.debug("No mcp.json found at %s — returning empty config", resolved)
        return MCPConfig()

    try:
        data = json.loads(resolved.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("Failed to read mcp.json at %s: %s", resolved, exc)
        return MCPConfig()

    servers_section = data.get("mcpServers", {})
    if not isinstance(servers_section, dict):
        logger.warning(
            "Invalid mcp.json at %s: 'mcpServers' must be an object, got %s",
            resolved,
            type(servers_section).__name__,
        )
        return MCPConfig()

    return MCPConfig(servers=servers_section)


# ---------------------------------------------------------------------------
# save_mcp_config
# ---------------------------------------------------------------------------


def save_mcp_config(config: MCPConfig, path: str | Path = _DEFAULT_PATH) -> None:
    """Write an MCPConfig to mcp.json.

    Creates parent directories if they do not exist.

    Args:
        config: The MCPConfig to persist.
        path:   Destination path.  Tilde expansion is applied.
    """
    resolved = Path(path).expanduser()

    try:
        resolved.parent.mkdir(parents=True, exist_ok=True)
        data = {"mcpServers": config.servers}
        resolved.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except OSError as exc:
        logger.warning("Failed to save mcp.json to %s: %s", resolved, exc)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

__all__ = ["MCPConfig", "load_mcp_config", "save_mcp_config"]
