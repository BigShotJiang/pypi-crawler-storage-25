"""WIDDX REPL — sci-fi autonomous AI engineering terminal."""
from __future__ import annotations

import json
import os
import signal
import sys as _sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

try:
    import winsound
    _has_winsound = True
except ImportError:
    winsound = None  # type: ignore[assignment]
    _has_winsound = False

from .. import ui
from ..config import DEFAULT_MEMORY_DB_PATH
from ..git_ops import GitOps
from ..indexer import ProjectIndexer
from ..memory import MemoryStore
from ..router import AIRouter
from ..self_learning import SelfLearningEngine
from ..tool_loop import ToolLoop
from .commands import (
    _handle_command,
    _resume,
    _run_agents,
    _search,
    _send_to_llm,
    _show_git,
    _show_help,
    _show_learning,
    _show_model_info,
    _show_task_history,
    _undo,
)
from .context import (
    _check_git_status,
    _estimate_complexity,
    _expand_context_shortcuts,
    _index_project,
    _load_project_md,
)


class WIDDXRepl:
    """Autonomous AI Engineering OS — interactive terminal agent."""

    # ── Injected methods ───────────────────────────────────────────
    _handle_command       = _handle_command
    _show_help            = _show_help
    _show_git             = _show_git
    _search               = _search
    _undo                 = _undo
    _show_model_info      = _show_model_info
    _show_task_history    = _show_task_history
    _send_to_llm          = _send_to_llm
    _run_agents           = _run_agents
    _resume               = _resume
    _show_learning        = _show_learning
    _expand_context_shortcuts = _expand_context_shortcuts
    _index_project        = _index_project
    _check_git_status     = _check_git_status
    _estimate_complexity  = _estimate_complexity
    _load_project_md      = _load_project_md

    def __init__(
        self,
        router: AIRouter,
        config: dict[str, Any],
        memory: MemoryStore | None = None,
        initial_task: str | None = None,
    ) -> None:
        self._router = router
        self._config = config
        self._tool_loop = ToolLoop(router)
        self._indexer = ProjectIndexer()
        self._git = GitOps()
        self._memory = memory or MemoryStore(
            config.get("memory", {}).get("db_path", "~/.widdx/memory.db")
        )
        self._streaming = True
        self._messages: list[dict] = []
        self._initial_task = initial_task
        self._task_count = 0
        self._last_result = ""
        self._last_task_info: dict[str, Any] = {}
        self._project_md = ""
        self._interrupt_pending = False
        sessions_dir = Path("~/.widdx/sessions").expanduser()
        sessions_dir.mkdir(parents=True, exist_ok=True)
        self._sessions_dir = sessions_dir
        self._self_learning = SelfLearningEngine(self._memory, config)
        self._toast = ui.ToastNotificationManager(ui.get_console())
        self._dashboard = ui.TaskDashboard(ui.get_console())
        self._status_bar = ui.StatusBar(ui.get_console())

    # ── Lifecycle ──────────────────────────────────────────────────

    def _show_provider_boot(self) -> None:
        """Show interactive provider selector if not yet configured."""
        if self._config.get("disabled_providers") is not None:
            return  # already configured — skip boot screen
        if self._config.get("boot_providers_shown"):
            return  # shown before and skipped

        try:
            from ..ui.boot import show_provider_boot
            show_provider_boot(self._config, self._router)
        except Exception:
            pass
        self._config["boot_providers_shown"] = True

    def run(self) -> None:
        self._setup()
        self._handle_interrupt_signal()
        self._show_provider_boot()
        if self._initial_task:
            self._execute_task(self._initial_task)
        self._main_loop()

    def _setup(self) -> None:
        c = ui.get_console()
        c.print()
        self._load_project_md()
        if self._project_md:
            self._tool_loop.set_project_md(self._project_md)
        self._index_project()
        self._check_git_status()

        # Seed bottom toolbar
        models = self._config.get("models", {})
        exec_model = models.get("executor", {}).get("model", "deepseek")
        ui.update_toolbar(
            model=exec_model,
            cwd=os.path.basename(os.getcwd()),
        )

        # ── Show StatusBar widget at startup ─────────────────────
        try:
            self._status_bar.update(model=exec_model, is_connected=True)
            self._status_bar.print()
        except Exception:
            pass

        c.print("  [dim]Type your task or /help for commands.[/]")
        try:
            providers = self._router.list_providers()
            active = sum(1 for p in providers if p.get("enabled", True))
            total = len(providers)
        except Exception:
            active = total = 0
        c.print(f"  [dim]os:[/] [text]{ui.drawing._os_label()}[/]  [dim]·  {active}/{total} providers[/]  [dim]·  /providers to manage[/]")

        # Show DeepSeek key status
        dsk = self._config.get("__env__", {}).get("deepseek_key")
        if dsk:
            masked = dsk[:8] + "..." + dsk[-4:]
            c.print(f"  [dim]key:[/] [success]✓ {masked}[/]  [dim]·  /key to change[/]")
        else:
            c.print(f"  [dim]key:[/] [warning]not set[/]  [dim]·  /key sk-... to add DeepSeek[/]")
        c.print()

        hook_manager = getattr(self._tool_loop, "_hook_manager", None)
        if hook_manager is not None:
            hook_manager.fire("SessionStart", {})

    def _handle_interrupt_signal(self) -> None:
        signal.signal(signal.SIGINT, self._handle_interrupt)

    # ── Main loop ──────────────────────────────────────────────────

    def _main_loop(self) -> None:
        while True:
            try:
                user_input = ui.prompt("widdx")
            except (EOFError, KeyboardInterrupt):
                self._exit()
                break

            user_input = user_input.strip()
            if not user_input:
                continue

            if user_input.startswith("/"):
                if self._handle_command(user_input):
                    break
            else:
                self._execute_task(user_input)
                ui.get_console().print()

    def _execute_task(self, task: str) -> None:
        self._task_count += 1
        expanded_task = self._expand_context_shortcuts(task)
        task_id = os.urandom(6).hex()
        complexity = self._estimate_complexity(task)
        task_type = self._router.infer_task_type(task)
        self._memory.create_task(task_id, task, task_type, complexity)
        c = ui.get_console()
        start = time.time()

        # ── Task start indicator ─────────────────────────────────
        ui.task_start(task)
        if complexity >= 2:
            stars = "✦" * complexity + "✧" * (5 - complexity)
            c.print(f"  [dim]complexity:[/] [brand]{stars}[/]  [dim]type:[/] [accent]{task_type}[/]")
            c.print()

        # ── Pre-flight check for build/create tasks ──────────────
        if complexity >= 3:
            self._run_preflight_check(task)

        # ── Run scaffolding (skip if pipeline will handle it) ────
        lowered = task.lower()
        is_build_task = any(kw in lowered for kw in
                            ["build", "create", "make", "generate", "new project", "scaffold"])
        if not (complexity >= 3 and is_build_task):
            self._run_repl_scaffolding(task)

        # ── Execute ──────────────────────────────────────────────
        if complexity >= 3 and is_build_task:
            result = self._run_pipeline_task(task, task_id)
        else:
            result = self._tool_loop.run(
                expanded_task, conversation_history=self._messages
            )
            self._messages = self._tool_loop._messages

        self._last_result = result
        elapsed = time.time() - start

        # ── Completion feedback ──────────────────────────────────
        self._show_task_feedback(task, task_id, elapsed, complexity)

        # ── Fire hooks ───────────────────────────────────────────
        hook_manager = getattr(self._tool_loop, "_hook_manager", None)
        if hook_manager is not None:
            hook_manager.fire_async("TaskCompleted", {
                "task": task,
                "result": self._last_result[:200] if self._last_result else "",
            })

        # ── Persist state ────────────────────────────────────────
        files_touched = list(dict.fromkeys(
            self._tool_loop._created_files + self._tool_loop._edited_files
        ))
        result_preview = (self._last_result or "")[:500]
        success = bool(result_preview.strip()) and "api error:" not in result_preview.lower()
        self._memory.complete_task(task_id, "completed" if success else "failed")

        self._persist_state(files_touched)
        self._self_learning.record_task(
            task_id=task_id,
            command=task,
            result_summary=result_preview,
            provider=getattr(self._router, "_last_provider", ""),
            files_touched=files_touched,
            tool_calls=self._tool_loop._tool_calls_count,
            success=success,
            complexity=complexity,
        )

        # ── Update toolbar + prompt context ──────────────────────
        self._refresh_toolbar()
        self._last_task_info = {
            "task": task[:60],
            "elapsed": elapsed,
            "tools": self._tool_loop._tool_calls_count,
            "files": len(files_touched),
            "success": success,
            "complexity": complexity,
        }

        # ── Show file changes ────────────────────────────────────
        had_tool_calls = self._tool_loop._tool_calls_count > 0
        if had_tool_calls or files_touched:
            c.print()
            if files_touched:
                self._show_changes()
        c.print()

    # ── Task feedback ────────────────────────────────────────────────

    def _show_task_feedback(self, task: str, task_id: str, elapsed: float, complexity: int) -> None:
        """Show rich completion feedback: elapsed time, tool stats, toast, bell."""
        c = ui.get_console()
        tool_count = self._tool_loop._tool_calls_count
        files = self._tool_loop._created_files + self._tool_loop._edited_files
        result_preview = (self._last_result or "")[:500]
        success = bool(result_preview.strip()) and "api error:" not in result_preview.lower()

        # ── Update StatusBar widget ───────────────────────────────
        try:
            tokens = self._router.session_tokens
            self._status_bar.update(
                tokens_input=tokens["input"],
                tokens_output=tokens["output"],
                is_connected=success,
            )
            self._status_bar.print()
        except Exception:
            pass

        # ── Elapsed time formatting ──────────────────────────────
        if elapsed < 1:
            elapsed_str = f"{int(elapsed * 1000)}ms"
        elif elapsed < 60:
            elapsed_str = f"{elapsed:.1f}s"
        else:
            elapsed_str = f"{int(elapsed // 60)}m {int(elapsed % 60)}s"

        # ── Results line ─────────────────────────────────────────
        if success:
            icon = "[success]✓[/]"
            status = "[success]completed[/]"
        else:
            icon = "[error]✗[/]"
            status = "[error]failed[/]"

        c.print()
        parts = [f"  {icon} {status}"]
        parts.append(f"[dim]in[/] [brand]{elapsed_str}[/]")
        if tool_count:
            parts.append(f"[dim]·[/] [accent]{tool_count}[/] [dim]tools[/]")
        if files:
            parts.append(f"[dim]·[/] [info]{len(set(files))}[/] [dim]files[/]")
        c.print(" ".join(parts))

        # ── Bell sound for long tasks ───────────────────────────
        if elapsed > 10:
            try:
                if _has_winsound:
                    getattr(winsound, "Beep")(1200, 80)
                    time.sleep(0.06)
                    getattr(winsound, "Beep")(1600, 120)
                else:
                    c.print("\a", end="")
            except Exception:
                pass

        # ── Toast notification for long/complex tasks ────────────
        if elapsed > 5:
            try:
                if success:
                    self._toast.success(
                        f"Done in {elapsed_str}  ·  {tool_count} tools",
                        duration=4.0,
                    )
                else:
                    self._toast.error(
                        f"Failed after {elapsed_str}",
                        duration=6.0,
                    )
            except Exception:
                pass

    def _persist_state(self, files_touched: list[str]) -> None:
        """Save project state and session snapshot."""
        try:
            from ..project_state import load_state, save_state, ProjectState
            existing = load_state()
            if existing is not None:
                existing.phases_completed += 1
                existing.files_created.extend(files_touched)
                save_state(existing)
            else:
                state = ProjectState(
                    project_name=Path.cwd().name,
                    files_created=files_touched,
                )
                save_state(state)
        except Exception:
            pass

        if self._messages:
            try:
                from ..project_state import save_session_snapshot
                save_session_snapshot(self._messages)
            except Exception:
                pass

    def _refresh_toolbar(self) -> None:
        """Update the bottom toolbar with latest session metrics."""
        tokens = self._router.session_tokens
        cost = self._router.session_cost
        total_tok = tokens["input"] + tokens["output"]
        tok_str = f"{total_tok / 1000:.1f}k" if total_tok >= 1000 else str(total_tok)

        last_info = self._last_task_info
        if last_info:
            elapsed = last_info.get("elapsed", 0)
            if elapsed < 60:
                et = f"{elapsed:.0f}s"
            else:
                et = f"{int(elapsed//60)}m{int(elapsed%60)}s"
            lt = last_info.get("task", "")[:30]
            success = last_info.get("success", True)
            icon = "✓" if success else "✗"
            last_hint = f"{icon} {lt} ({et})"
        else:
            last_hint = ""

        ui.update_toolbar(
            tokens=tok_str,
            cost=f"${cost:.4f}" if cost > 0 else "",
            last_task=last_hint,
        )

    # ── Preflight / scaffolding ──────────────────────────────────────

    def _run_preflight_check(self, task: str) -> None:
        """Quick pre-flight — the pipeline does the full check."""
        lowered = task.lower()
        if not any(kw in lowered for kw in ["build", "create", "install", "generate"]):
            return

    def _run_repl_scaffolding(self, task: str) -> None:
        """Automatically scaffold the project if it is empty and a framework is detected."""
        from pathlib import Path

        # Only scaffold for empty directories
        cwd = Path.cwd()
        non_hidden = [f for f in cwd.iterdir() if not f.name.startswith(".")]
        if non_hidden:
            return

        from ..scaffolder import detect_framework, scaffold
        result = scaffold(task, router=self._router)
        if result.installed:
            from widdx import ui
            ui.get_console().print(
                f"  [success]✓[/] {result.framework} scaffolding complete — ready to build"
            )

    def _run_pipeline_task(self, task: str, task_id: str) -> str:
        """Run a complex build task through the full multi-agent pipeline."""
        from ..agent_factory import AgentFactory
        from ..evolution import EvolutionEngine
        from ..pipeline import ExecutionPipeline

        c = ui.get_console()
        start = time.time()

        # ── Engaging startup screen ───────────────────────────────
        c.print()
        c.print(f"  [brand]╔══════════════════════════════════════╗[/]")
        c.print(f"  [brand]║[/]   [bold]⚡ MULTI-AGENT PIPELINE[/]     [brand]║[/]")
        c.print(f"  [brand]╚══════════════════════════════════════╝[/]")
        c.print()
        c.print(f"  [dim]⎿  Assembling team · analyzing requirements...[/]")

        agent_factory = AgentFactory(self._router)
        evolution = EvolutionEngine(self._memory, self._config)
        pipeline = ExecutionPipeline(
            self._router, agent_factory, self._memory, evolution, self._config,
        )

        try:
            result = pipeline.run(task)
            output = result.execution_output or "Pipeline completed."
        except Exception as exc:
            c.print(f"  [error]✗ Pipeline failed: {exc}[/]")
            return f"Pipeline error: {exc}"

        elapsed = time.time() - start
        elapsed_str = f"{int(elapsed//60)}m {int(elapsed%60)}s" if elapsed > 60 else f"{elapsed:.0f}s"

        # ── Pipeline completion feedback ─────────────────────────
        c.print()
        depth = getattr(result, "pipeline_depth", 0)
        agents = getattr(result, "agents_generated", [])
        output = result.execution_output or ""
        has_content = bool(output.strip()) and "Pipeline completed." not in output

        if not has_content:
            c.print(f"  [warning]⚠ Pipeline finished but no project files were created[/]")
            c.print(f"  [dim]Missing required tools. Install them and try again.[/]")
            if output:
                c.print(f"  [dim]{output[:500]}[/]")
        else:
            parts = [f"  [success]✓ Pipeline done[/]"]
            parts.append(f"[dim]in[/] [brand]{elapsed_str}[/]")
            if depth:
                parts.append(f"[dim]· depth[/] [info]{depth}[/]")
            if agents:
                parts.append(f"[dim]·[/] [accent]{len(agents)}[/] [dim]agents[/]")
            c.print(" ".join(parts))

        # Save the plan and design to .widdx/
        if result.plan:
            try:
                from ..project_state import get_widdx_dir
                widdx_dir = get_widdx_dir()
                plan_path = widdx_dir / "plan.json"
                plan_path.write_text(
                    __import__("json").dumps(result.plan, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            except Exception:
                pass

        # ── Summary ───────────────────────────────────────────────
        c.print()
        c.print(f"  [brand]╔══════════════════════════════════╗[/]")
        c.print(f"  [brand]║[/]     [success]✓ PIPELINE COMPLETE[/]     [brand]║[/]")
        c.print(f"  [brand]╚══════════════════════════════════╝[/]")
        c.print(f"  [dim]  ⏱ {elapsed_str}[/]  [dim]·[/]  {output[:100]}")

        return output

    def _show_changes(self) -> None:
        """Display created/edited files with sci-fi diamond indicators."""
        created = self._tool_loop._created_files
        edited  = self._tool_loop._edited_files
        seen: set[str] = set()
        all_files: list[tuple[str, str]] = []
        for f in created:
            if f not in seen:
                all_files.append((f, "created"))
                seen.add(f)
        for f in edited:
            if f not in seen:
                all_files.append((f, "edited"))
                seen.add(f)

        if not all_files:
            return

        c = ui.get_console()
        c.print()
        for f, action in all_files[:15]:
            if action == "created":
                c.print(f"  [success]◆[/] Created  [text]{f}[/]")
            else:
                c.print(f"  [warning]◆[/] Updated  [text]{f}[/]")
        if len(all_files) > 15:
            c.print(f"  [dim]  … and {len(all_files) - 15} more files[/]")

    # ── Session persistence ────────────────────────────────────────

    def _save_session(self, name: str | None = None) -> str:
        ts = datetime.now()
        filename = f"{name}.json" if name else f"session_{ts.strftime('%Y%m%d_%H%M%S')}.json"
        path = self._sessions_dir / filename
        data = {
            "version": 1,
            "saved_at": ts.isoformat(),
            "cwd": str(Path.cwd()),
            "task_count": self._task_count,
            "project_md": self._project_md[:1000] if self._project_md else "",
            "messages": self._messages,
        }
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def _load_session(self, name: str) -> bool:
        if not name.endswith(".json"):
            name = f"{name}.json"
        path = self._sessions_dir / name
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return False
        if data.get("version") != 1:
            return False
        self._messages = data.get("messages", [])
        self._tool_loop._messages = list(self._messages)
        self._task_count = data.get("task_count", 0)
        self._project_md = data.get("project_md", "")
        return True

    def _list_sessions(self) -> list[dict]:
        sessions: list[dict] = []
        for f in sorted(self._sessions_dir.glob("*.json"),
                        key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            sessions.append({
                "name": f.stem,
                "saved_at": data.get("saved_at", ""),
                "task_count": data.get("task_count", 0),
                "msg_count": len(data.get("messages", [])),
                "cwd": data.get("cwd", ""),
            })
        return sessions

    # ── Exit / interrupt ───────────────────────────────────────────

    def _exit(self) -> None:
        if self._messages:
            path = self._save_session()
            ui.get_console().print(f"  [dim]◈ Session saved → {Path(path).name}[/]")
        ui.get_console().print()
        ui.get_console().print("  [dim]Goodbye.[/]")
        ui.get_console().print()

    def _handle_interrupt(self, sig, frame) -> None:
        if getattr(self, "_interrupt_pending", False):
            self._exit()
            import sys
            sys.exit(0)
        self._interrupt_pending = True
        ui.get_console().print("\n\n  [dim]◈ Ctrl+C again to exit.[/]")
        signal.signal(signal.SIGINT, self._handle_interrupt)
