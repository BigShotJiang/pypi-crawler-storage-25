"""REPL command handlers — dispatcher + core handlers, re-exports specialized modules."""
from __future__ import annotations

import os
import uuid
from pathlib import Path

from widdx import ui
from widdx.ui.arabic import _d

from .planning import (
    _resume_plan,
    _plan_project,
    _list_plans,
)
from .providers import (
    _show_providers,
    _interactive_provider_manager,
    _set_active_provider,
    _set_api_key,
    _strip_key_from_history,
)
from .system import (
    _run_agents,
    _show_memory,
    _show_learning,
    _show_skills,
    _show_hooks,
    _show_mcp,
    _bootstrap,
    _list_projects,
    _search_knowledge,
)

__all__ = [
    "_handle_command",
    "_show_help",
    "_show_git",
    "_search",
    "_undo",
    "_show_model_info",
    "_show_task_history",
    "_send_to_llm",
    "_save_session_cmd",
    "_list_sessions_cmd",
    "_resume",
    "_resume_plan",
    "_plan_project",
    "_list_plans",
    "_show_providers",
    "_interactive_provider_manager",
    "_set_active_provider",
    "_set_api_key",
    "_strip_key_from_history",
    "_run_agents",
    "_show_memory",
    "_show_learning",
    "_show_skills",
    "_show_hooks",
    "_show_mcp",
    "_bootstrap",
    "_list_projects",
    "_search_knowledge",
]


def _handle_command(self, cmd: str) -> bool:
    parts = cmd.split(maxsplit=1)
    command = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    if command == "/exit" or command == "/quit" or command == "/q":
        self._exit()
        return True

    if command == "/help" or command == "/h":
        _show_help(self)
    elif command == "/clear" or command == "/c":
        from widdx import ui
        if self._messages and not ui.confirm("Clear all conversation history?"):
            return False
        self._messages.clear()
        self._tool_loop.clear_context()
        ui.get_console().print("  [dim]Conversation cleared.[/]")
    elif command == "/compact":
        result = self._tool_loop.compact()
        self._messages = list(self._tool_loop._messages)
        from widdx import ui
        ui.get_console().print(f"  [success]{result}[/]")
    elif command == "/index":
        self._index_project()
    elif command == "/git":
        _show_git(self)
    elif command == "/search" or command == "/grep":
        _search(self, arg)
    elif command == "/undo":
        _undo(self)
    elif command == "/approve":
        self._tool_loop._permissions.approve_session()
        from widdx import ui
        ui.get_console().print("  [success]\u2713 Permissions approved for this session.[/]")
    elif command == "/deny":
        self._tool_loop._permissions.deny_session()
        from widdx import ui
        ui.get_console().print("  [warning]\u26a0 Shell commands blocked for this session.[/]")
    elif command == "/agents":
        _run_agents(self, arg)
    elif command == "/save":
        _save_session_cmd(self, arg)
    elif command == "/sessions":
        _list_sessions_cmd(self)
    elif command == "/resume":
        _resume(self, arg)
    elif command == "/plan":
        _plan_project(self, arg)
    elif command == "/plans":
        _list_plans(self)
    elif command == "/model":
        _show_model_info(self)
    elif command == "/tasks":
        _show_task_history(self)
    elif command == "/llm":
        _send_to_llm(self, arg)
    elif command == "/memory":
        _show_memory(self)
    elif command == "/learn":
        _show_learning(self)
    elif command == "/skills":
        _show_skills(self)
    elif command == "/hooks":
        _show_hooks(self)
    elif command == "/mcp":
        _show_mcp(self, arg)
    elif command == "/bootstrap":
        _bootstrap(self, arg)
    elif command == "/projects":
        _list_projects(self)
    elif command == "/knowledge":
        _search_knowledge(self, arg)
    elif command == "/providers":
        _show_providers(self, arg)
    elif command == "/provider":
        _set_active_provider(self, arg)
    elif command == "/key":
        _set_api_key(self, arg)
    else:
        from widdx import ui
        skill_name = command[1:]
        skill_manager = getattr(self._tool_loop, '_skill_manager', None)
        if skill_manager:
            skill_content = skill_manager.get_skill(skill_name)
            if skill_content:
                self._execute_task(skill_content)
                return False
        ui.get_console().print(f"  [dim]Unknown command: {command}[/]")
        _show_help(self)

    return False


def _show_help(self) -> None:
    from rich import box as rich_box
    from rich.panel import Panel
    from rich.text import Text

    from widdx import ui

    c = ui.get_console()

    content = Text()

    content.append("\n  SESSION\n", style="bold #00d4ff")
    content.append("  /clear    ", style="#38bdf8"); content.append("clear conversation\n", style="#6c7086")
    content.append("  /compact  ", style="#38bdf8"); content.append("summarize history to save tokens\n", style="#6c7086")
    content.append("  /save     ", style="#38bdf8"); content.append("/save <name>  \u2014 save session to disk\n", style="#6c7086")
    content.append("  /sessions ", style="#38bdf8"); content.append("list saved sessions\n", style="#6c7086")
    content.append("  /resume   ", style="#38bdf8"); content.append("/resume [name]  \u2014 restore session\n", style="#6c7086")
    content.append("  /exit     ", style="#38bdf8"); content.append("exit WIDDX\n", style="#6c7086")

    content.append("\n  PROJECT\n", style="bold #00d4ff")
    content.append("  /index    ", style="#38bdf8"); content.append("re-scan project files\n", style="#6c7086")
    content.append("  /git      ", style="#38bdf8"); content.append("show git status\n", style="#6c7086")
    content.append("  /search   ", style="#38bdf8"); content.append("/search <pattern>  \u2014 regex search\n", style="#6c7086")
    content.append("  /undo     ", style="#38bdf8"); content.append("restore files from this session\n", style="#6c7086")
    content.append("  /memory   ", style="#38bdf8"); content.append("show WIDDX.md content\n", style="#6c7086")
    content.append("  /learn    ", style="#38bdf8"); content.append("show self-learning ledger and draft assets\n", style="#6c7086")

    content.append("\n  AGENTS & AI\n", style="bold #00d4ff")
    content.append("  /agents   ", style="#38bdf8"); content.append("/agents <task>  \u2014 multi-agent team\n", style="#6c7086")
    content.append("  /skills   ", style="#38bdf8"); content.append("list available skills\n", style="#6c7086")
    content.append("  /hooks    ", style="#38bdf8"); content.append("show loaded hooks\n", style="#6c7086")
    content.append("  /mcp      ", style="#38bdf8"); content.append("show MCP servers  \u00b7  /mcp add <n> <cmd>\n", style="#6c7086")
    content.append("  /bootstrap", style="#38bdf8"); content.append(" <tech>  \u2014 generate skills for a technology\n", style="#6c7086")

    content.append("\n  PROJECTS\n", style="bold #00d4ff")
    content.append("  /plan     ", style="#38bdf8"); content.append("/plan <desc>  \u2014 create & run a phased project plan\n", style="#6c7086")
    content.append("  /plans    ", style="#38bdf8"); content.append("list all saved project plans\n", style="#6c7086")
    content.append("  /projects ", style="#38bdf8"); content.append("list all previous projects + phase status\n", style="#6c7086")
    content.append("  /knowledge", style="#38bdf8"); content.append("/knowledge <query>  \u2014 search past project memory\n", style="#6c7086")
    content.append("  /resume   ", style="#38bdf8"); content.append("/resume [name|plan_id]  \u2014 restore session or resume plan\n", style="#6c7086")

    content.append("\n  INFO\n", style="bold #00d4ff")
    content.append("  /model    ", style="#38bdf8"); content.append("model info and session cost\n", style="#6c7086")
    content.append("  /tasks    ", style="#38bdf8"); content.append("task history\n", style="#6c7086")
    content.append("  /providers", style="#38bdf8"); content.append("list providers \u00b7 /providers toggle <name>\n", style="#6c7086")
    content.append("  /provider ", style="#38bdf8"); content.append("/provider <name>  \u2014 use only one provider\n", style="#6c7086")
    content.append("  /key      ", style="#38bdf8"); content.append("/key <sk-...>  \u2014 set DeepSeek API key\n", style="#6c7086")
    content.append("  /approve  ", style="#38bdf8"); content.append("allow all shell commands this session\n", style="#6c7086")
    content.append("  /deny     ", style="#38bdf8"); content.append("block shell commands this session\n", style="#6c7086")
    content.append("  /llm      ", style="#38bdf8"); content.append("/llm <prompt>  \u2014 direct LLM call\n", style="#6c7086")

    content.append("\n  ", style="")
    content.append("@file.py", style="bold #00d4ff")
    content.append("  attaches file context to your task\n", style="#6c7086")

    c.print()
    c.print(Panel(
        content,
        title="[bold #00d4ff]\u25c6  WIDDX  COMMAND REFERENCE[/]",
        border_style="#00d4ff",
        box=rich_box.DOUBLE,
        padding=(0, 1),
    ))
    c.print()


def _show_git(self) -> None:
    if not self._git.is_repo:
        from widdx import ui
        ui.get_console().print("  [dim]Not a git repository.[/]")
        return
    branch = self._git.current_branch()
    status = self._git.status()
    changes = status.get("changed", 0)
    files = status.get("files", [])

    from widdx import ui
    ui.get_console().print(f"\n  [dim]Branch:[/] [text]{_d(branch)}[/]")
    if changes > 0:
        ui.get_console().print(f"  [warning]Changes:[/] [text]{changes} files[/]")
        for f in files[:5]:
            ui.get_console().print(f"    [warning]{_d(f[:60])}[/]")
        if changes > 5:
            ui.get_console().print(f"    [dim]... and {changes - 5} more[/]")
    else:
        ui.get_console().print("  [success]Working tree clean[/]")
    ui.get_console().print()


def _search(self, query: str) -> None:
    if not query:
        from widdx import ui
        ui.get_console().print("  [dim]Usage: /search <pattern>[/]")
        return
    from widdx.tools import search
    result = search.tool_grep(query, directory=".")
    from widdx import ui
    ui.show_search(query, result.get("matches", []), result.get("count", 0))


def _undo(self) -> None:
    import shutil

    backups = self._tool_loop._backups
    created_files = self._tool_loop._created_files

    from widdx import ui
    if not backups and not created_files:
        ui.get_console().print("  [dim]Nothing to undo (no edits or creations found for this session).[/]")
        return

    ui.get_console().print("\n  [brand]Restoring previous state...[/]")

    cwd = Path.cwd().resolve()
    for original, backup in backups.items():
        orig_path = Path(original).resolve()
        backup_path = Path(backup).resolve()

        if not str(orig_path).startswith(str(cwd)):
            ui.get_console().print(f"    [dim]Skipped (outside project): {orig_path.name}[/]")
            continue

        if backup_path.exists():
            try:
                shutil.copy2(backup_path, orig_path)
                ui.get_console().print(f"    [success]\u2713[/] Restored [text]{orig_path.name}[/]")
            except Exception as e:
                ui.get_console().print(f"    [error]\u2717[/] Failed to restore [text]{orig_path.name}[/]: {e}")

    for created in created_files:
        cp = Path(created).resolve()
        if not str(cp).startswith(str(cwd)):
            continue
        if cp.exists():
            try:
                cp.unlink()
                ui.get_console().print(f"    [warning]\u26a0[/] Deleted created file [text]{cp.name}[/]")
            except Exception:
                pass

    self._tool_loop.clear_context()
    ui.get_console().print("  [success]Undo complete.[/]\n")


def _show_model_info(self) -> None:
    from rich import box as rich_box
    from rich.panel import Panel
    from rich.text import Text

    from widdx import ui

    models = self._config.get("models", {})
    arch  = models.get("architect", {}).get("model", "?")
    exec_ = models.get("executor",  {}).get("model", "?")
    tokens = self._router.session_tokens
    cost   = self._router.session_cost
    total  = tokens["input"] + tokens["output"]

    c = ui.get_console()

    t = Text()
    t.append("\n  MODELS\n", style="bold #00d4ff")
    t.append("  architect   ", style="#38bdf8"); t.append(f"{arch}\n", style="#cdd6f4")
    t.append("  executor    ", style="#38bdf8"); t.append(f"{exec_}\n", style="#cdd6f4")

    t.append("\n  SESSION USAGE\n", style="bold #00d4ff")
    t.append("  tokens in   ", style="#38bdf8"); t.append(f"{tokens['input']:,}\n", style="#cdd6f4")
    t.append("  tokens out  ", style="#38bdf8"); t.append(f"{tokens['output']:,}\n", style="#cdd6f4")
    t.append("  total       ", style="#38bdf8"); t.append(f"{total:,}\n", style="#cdd6f4")
    t.append("  cost        ", style="#38bdf8"); t.append(f"${cost:.4f}\n", style="#00ff88")

    c.print()
    c.print(Panel(t, title="[bold #00d4ff]\u25c6  SYSTEM STATUS[/]",
                  border_style="#00d4ff", box=rich_box.DOUBLE, padding=(0, 1)))
    c.print()


def _show_task_history(self) -> None:
    from rich import box as rich_box
    from rich.panel import Panel
    from rich.text import Text

    from widdx import ui

    tasks = self._memory.recent_tasks(10)
    c = ui.get_console()

    if not tasks:
        c.print("  [dim]No tasks yet.[/]")
        return

    t = Text()
    t.append("\n")
    for task in tasks:
        if task["status"] == "completed":
            icon, col = "\u2713", "#00ff88"
        elif task["status"] == "failed":
            icon, col = "\u2717", "#ff3355"
        else:
            icon, col = "\u00b7", "#ffb300"

        ts  = task.get("created_at", "")[:16].replace("T", " ")
        cmd = _d(task["command"][:60])

        t.append(f"  {icon} ", style=f"bold {col}")
        t.append(f"{ts}  ", style="#45475a")
        t.append(f"{cmd}\n", style="#cdd6f4")

    c.print()
    c.print(Panel(t, title="[bold #00d4ff]\u25c6  TASK HISTORY[/]",
                  border_style="#00d4ff", box=rich_box.DOUBLE, padding=(0, 1)))
    c.print()


def _send_to_llm(self, prompt: str) -> None:
    from widdx import ui
    if not prompt:
        ui.get_console().print("  [dim]Usage: /llm <prompt>[/]")
        return
    result = self._tool_loop.run(prompt, conversation_history=self._messages)
    ui.get_console().print()
    ui.get_console().print(f"  {result}")


def _save_session_cmd(self, name: str) -> None:
    """Save the current session to disk."""
    from widdx import ui
    c = ui.get_console()
    if not self._messages:
        c.print("  [dim]Nothing to save \u2014 empty session.[/]")
        return
    path = self._save_session(name if name else None)
    c.print(f"  [success]Session saved:[/] [text]{Path(path).name}[/]")


def _list_sessions_cmd(self) -> None:
    """List all saved sessions."""
    from widdx import ui
    c = ui.get_console()
    sessions = self._list_sessions()
    if not sessions:
        c.print()
        c.print("  [dim]No saved sessions found.[/]")
        c.print(f"  [dim]Sessions directory: {self._sessions_dir}[/]")
        c.print()
        return
    c.print()
    c.print("  [brand]Saved Sessions:[/]")
    sep = "\u2500" * 60
    c.print(f"  [dim]{sep}[/]")
    for s in sessions[:20]:
        saved = s["saved_at"][:19].replace("T", " ") if s["saved_at"] else "?"
        c.print(
            f"  [highlight]{_d(s['name'])}[/]  [dim]{saved}[/]  "
            f"[text]{s['msg_count']} msgs, {s['task_count']} tasks[/]"
        )
    if len(sessions) > 20:
        c.print(f"  [dim]... and {len(sessions) - 20} more[/]")
    c.print()


def _resume(self, name: str = "") -> None:
    """Resume: session file, project plan, or last incomplete task."""
    c = ui.get_console()

    if name:
        import re as _re
        if _re.fullmatch(r"[0-9a-f]{12}", name):
            _resume_plan(self, name)
            return
        if self._load_session(name):
            c.print()
            c.print(f"  [success]\u25c6 Loaded session:[/] [text]{_d(name)}[/]")
            c.print(f"  [dim]  Messages: {len(self._messages)} \u00b7 Tasks: {self._task_count}[/]")
            c.print()
            return
        c.print(f"  [warning]Not found:[/] [dim]'{_d(name)}'[/]")
        c.print("  [dim]Try: /sessions \u00b7 /plans[/]")
        return

    tasks = self._memory.recent_tasks(20)
    incomplete = [t for t in tasks if t.get("status") not in ("completed", "failed")]
    if not incomplete:
        c.print("  [dim]No incomplete tasks found.[/]")
        return

    task    = incomplete[0]
    command = task.get("command", "")
    tid     = task.get("id", "")[:8]
    created = task.get("created_at", "")[:19].replace("T", " ")

    c.print()
    c.print(f"  [brand]\u25c6 Resuming task[/] [dim]{tid}[/]  [muted]{created}[/]")
    c.print(f"  [dim]  {_d(command[:90])}[/]")
    c.print()

    decisions = self._memory.task_decisions(task.get("id", ""))
    if decisions:
        lines = ["Previous progress:"]
        for d in decisions[-5:]:
            s = d.get("output_summary", "")[:120]
            if s:
                lines.append(f"- [{d.get('stage','')}] {s}")
        ctx = "\n".join(lines)
        self._messages = [
            {"role": "user",      "content": command},
            {"role": "assistant", "content": ctx},
        ]
        self._tool_loop._messages = list(self._messages)

    self._execute_task(command)
