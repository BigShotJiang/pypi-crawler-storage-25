"""REPL context helpers — project indexing, git status, file shortcuts."""
from __future__ import annotations

import re
from pathlib import Path

_PROJECT_MD_SIZE_WARN_BYTES = 10 * 1024  # 10 KB


def _load_project_md(self) -> str:
    """Load WIDDX.md (or CLAUDE.md) from project and user home.

    User-level file is loaded first; project-level appended after so it
    takes priority when the LLM reads top-to-bottom.
    """
    from widdx import ui

    parts: list[str] = []
    total_bytes = 0

    # User-level (global)
    user_md = Path("~/.widdx/WIDDX.md").expanduser()
    if user_md.exists():
        text = user_md.read_text(encoding="utf-8")
        parts.append(text)
        total_bytes += len(text.encode("utf-8"))

    # Project-level (overrides user — appended last so it wins)
    for name in ["WIDDX.md", "CLAUDE.md"]:
        project_md = Path.cwd() / name
        if project_md.exists():
            text = project_md.read_text(encoding="utf-8")
            parts.append(text)
            total_bytes += len(text.encode("utf-8"))
            break

    combined = "\n\n---\n\n".join(parts)

    if combined and total_bytes > _PROJECT_MD_SIZE_WARN_BYTES:
        kb = total_bytes / 1024
        ui.get_console().print(
            f"  [warning]⚠ WIDDX.md is {kb:.1f} KB — this consumes many tokens per request.[/]"
        )

    self._project_md = combined
    return combined


def _expand_context_shortcuts(self, task: str) -> str:
    """Expand @path/to/file in the task with the file's content."""
    pattern = re.compile(r'@([A-Za-z0-9_./\\-]+)')
    matches = pattern.findall(task)

    if not matches:
        return task

    expanded_task = task
    added_files = []

    for match in matches:
        p = Path(match)
        if p.is_file():
            try:
                content = p.read_text(encoding="utf-8")
                block = f"\n\n--- Context: {match} ---\n```\n{content}\n```\n"
                expanded_task += block
                added_files.append(match)
            except Exception:
                pass

    if added_files:
        from widdx import ui
        ui.get_console().print(f"  [dim]◈ Attached: {', '.join(added_files)}[/]")

    return expanded_task


def _index_project(self) -> None:
    """Index current project and set tool_loop context."""
    from widdx import ui

    with ui.spinner("indexing project"):
        ctx = self._indexer.context_for_ai()

    self._tool_loop.set_project_context(ctx)
    fw = self._tool_loop._detect_framework()
    self._tool_loop.set_framework(fw)

    total_files = self._indexer.total_files
    total_mb = self._indexer.total_size_mb
    fw_name = fw if fw != "vanilla" else "python"

    ui.get_console().print(
        f"  [brand]◆[/] [text]{fw_name}[/]"
        f"  [dim]·[/]  [text]{total_files} files[/]"
        f"  [dim]·[/]  [text]{total_mb} MB[/]"
    )


def _check_git_status(self) -> None:
    """Display current git branch and status."""
    from widdx import ui
    c = ui.get_console()
    if self._git.is_repo:
        branch = self._git.current_branch()
        status = self._git.status()
        changes = status.get("changed", 0)
        if changes > 0:
            c.print(f"  [dim]◈[/] [text]{branch}[/]  [dim]·[/]  [warning]{changes} uncommitted[/]")
        else:
            c.print(f"  [dim]◈[/] [text]{branch}[/]  [dim]·[/]  [dim]clean[/]")
    c.print()


def _estimate_complexity(self, task: str) -> int:
    """Quick local complexity estimate."""
    lowered = task.lower()

    # Tiny tasks — single file, trivial
    tiny = ["hello world", "simple script", "one file", "single file",
            "add comment", "add docstring", "print hello", "echo",
            "readme", "license file", "gitignore"]
    if any(kw in lowered for kw in tiny):
        return 1

    # File-level tasks — create/edit a few files, simple changes
    file_level = ["create file", "create a .py", "write file", "write a file",
                  "add file", "add a file", "create .py", "write a .py",
                  "fix bug", "fix the bug", "fix error", "debug",
                  "rename", "refactor single", "update file",
                  "fix auth", "fix the auth", "fix a bug"]
    if any(kw in lowered for kw in file_level):
        return 2

    # Project-level — multi-file, frameworks
    if any(kw in lowered for kw in ["fullstack", "complete", "entire", "saas", "platform"]):
        return 5
    if any(kw in lowered for kw in ["frontend", "backend", "api", "database", "auth"]):
        return 4
    if any(kw in lowered for kw in ["build", "create", "implement", "generate"]):
        return 3
    return 2
