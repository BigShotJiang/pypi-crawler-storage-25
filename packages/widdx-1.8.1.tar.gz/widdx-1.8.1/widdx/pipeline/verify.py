"""Post-generation verification — catches common issues before tests run."""
from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import NamedTuple


class Issue(NamedTuple):
    severity: str  # "error" | "warning"
    file: str
    line: int
    message: str


def verify_project(root: Path) -> list[Issue]:
    """Run all verification checks on a generated project.

    Args:
        root: Project root directory.

    Returns:
        List of issues found (empty if project looks good).
    """
    issues: list[Issue] = []
    issues.extend(_check_import_paths(root))
    issues.extend(_check_bcrypt_compatibility(root))
    issues.extend(_check_datetime_usage(root))
    issues.extend(_check_pydantic_models(root))
    return issues


def _check_import_paths(root: Path) -> list[Issue]:
    """Verify that import paths match actual directory structure."""
    issues: list[Issue] = []
    py_files = list(root.rglob("*.py"))

    # Build a map of available module paths
    available_modules: set[str] = set()
    for py_file in py_files:
        rel = py_file.relative_to(root)
        parts = list(rel.parts)
        parts[-1] = parts[-1].replace(".py", "")
        if parts[-1] == "__init__":
            parts = parts[:-1]
        if parts:
            available_modules.add(".".join(parts))

    # Check imports in each file
    for py_file in py_files:
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    _check_module_alias(alias.name, py_file, root, available_modules, issues)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    full_module = node.module
                    _check_module_alias(full_module, py_file, root, available_modules, issues)

    return issues


def _check_module_alias(
    module: str,
    py_file: Path,
    root: Path,
    available: set[str],
    issues: list[Issue],
) -> None:
    """Check if a module import path exists."""
    # Skip stdlib and third-party imports (heuristic: no dot or starts with known prefix)
    if not module.startswith(("app.", "src.", "widdx.")):
        return

    # Check if the module or any parent exists
    parts = module.split(".")
    found = False
    for i in range(len(parts), 0, -1):
        candidate = ".".join(parts[:i])
        if candidate in available:
            found = True
            break

    if not found:
        rel_file = py_file.relative_to(root)
        issues.append(Issue(
            "error",
            str(rel_file),
            _find_import_line(py_file, module),
            f"Import '{module}' does not match any existing module",
        ))


def _find_import_line(py_file: Path, module: str) -> int:
    """Find the line number of an import statement."""
    try:
        text = py_file.read_text(encoding="utf-8")
        for i, line in enumerate(text.splitlines(), 1):
            if module in line and ("import" in line or "from" in line):
                return i
    except OSError:
        pass
    return 0


def _check_bcrypt_compatibility(root: Path) -> list[Issue]:
    """Check for passlib + bcrypt version conflicts."""
    issues: list[Issue] = []
    req_files = list(root.rglob("requirements*.txt"))

    for req_file in req_files:
        content = req_file.read_text(encoding="utf-8").lower()
        has_passlib = "passlib" in content
        has_bcrypt = "bcrypt" in content

        if has_passlib and has_bcrypt:
            # Check if bcrypt is pinned to a compatible version
            bcrypt_match = re.search(r"bcrypt\s*([><=!~]+)\s*([\d.]+)", content)
            if bcrypt_match:
                op, version = bcrypt_match.groups()
                # bcrypt >= 4.1.0 breaks passlib
                try:
                    parts = version.split(".")
                    major = int(parts[0])
                    minor = int(parts[1]) if len(parts) > 1 else 0
                    # Error if: >= 4.1.0, > 4.0, or == 4.1+ 
                    if major > 4 or (major == 4 and minor >= 1):
                        if op in (">=", ">", "=="):
                            issues.append(Issue(
                                "error",
                                str(req_file.relative_to(root)),
                                0,
                                "passlib is incompatible with bcrypt>=4.1.0 — pin bcrypt==4.0.1 or use argon2-cffi",
                            ))
                except ValueError:
                    pass
            elif has_bcrypt and not bcrypt_match:
                # bcrypt mentioned but not pinned
                issues.append(Issue(
                    "warning",
                    str(req_file.relative_to(root)),
                    0,
                    "bcrypt version not pinned — passlib requires bcrypt==4.0.1",
                ))

    return issues


def _check_datetime_usage(root: Path) -> list[Issue]:
    """Check for timezone-naive datetime.now() calls."""
    issues: list[Issue] = []
    py_files = list(root.rglob("*.py"))

    for py_file in py_files:
        try:
            text = py_file.read_text(encoding="utf-8")
        except OSError:
            continue

        for i, line in enumerate(text.splitlines(), 1):
            # Skip comments and strings (heuristic)
            stripped = line.strip()
            if stripped.startswith("#") or stripped.startswith('"""') or stripped.startswith("'''"):
                continue

            # Check for datetime.now() without timezone
            if "datetime.now()" in line and "timezone" not in line:
                rel_file = py_file.relative_to(root)
                issues.append(Issue(
                    "warning",
                    str(rel_file),
                    i,
                    "Use datetime.now(timezone.utc) for timezone-aware datetimes",
                ))

    return issues


def _check_pydantic_models(root: Path) -> list[Issue]:
    """Check for UUID/string type mismatches in Pydantic models."""
    issues: list[Issue] = []
    py_files = list(root.rglob("*.py"))

    for py_file in py_files:
        try:
            tree = ast.parse(py_file.read_text(encoding="utf-8"))
        except SyntaxError:
            continue

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # Check if it's a Pydantic model (inherits from BaseModel)
                is_pydantic = any(
                    base.attr == "BaseModel" if isinstance(base, ast.Attribute)
                    else base.id == "BaseModel" if isinstance(base, ast.Name)
                    else False
                    for base in node.bases
                )
                if not is_pydantic:
                    continue

                # Check for id: str fields (might be UUID)
                for item in node.body:
                    if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                        if item.target.id == "id":
                            # Check if annotation is str
                            if isinstance(item.annotation, ast.Name) and item.annotation.id == "str":
                                rel_file = py_file.relative_to(root)
                                issues.append(Issue(
                                    "warning",
                                    str(rel_file),
                                    item.lineno or 0,
                                    "Model has `id: str` — if using UUID primary keys, use `id: UUID` instead",
                                ))

    return issues
