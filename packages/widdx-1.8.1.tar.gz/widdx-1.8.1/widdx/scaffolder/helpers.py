"""Internal helpers for scaffold setup, git, skills, hooks, MCP."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

from .models import FrameworkConfig


def _setup_env(cfg: FrameworkConfig, target: Path, answers: dict[str, str]) -> bool:
    """Create or update .env with template values."""
    if not cfg.env_template:
        return False

    env_path = target / ".env"
    if not env_path.exists():
        try:
            content = "\n".join(
                f"{k}={v.format(project_name=target.name)}"
                for k, v in cfg.env_template.items()
            )
            env_path.write_text(content + "\n", encoding="utf-8")
            return True
        except OSError:
            return False
    return False


def _init_git(target: Path, framework: str, version: str) -> bool:
    """Initialise a git repository if one does not already exist."""
    if (target / ".git").exists():
        return False
    try:
        subprocess.run(
            ["git", "init"],
            capture_output=True, text=True,
            timeout=30, cwd=str(target),
        )
        gitignore_path = target / ".gitignore"
        if not gitignore_path.exists():
            gitignore_path.write_text(
                "/vendor\n/node_modules\n/.env\n.DS_Store\n", encoding="utf-8"
            )
        subprocess.run(
            ["git", "add", "-A"],
            capture_output=True, text=True,
            timeout=30, cwd=str(target),
        )
        subprocess.run(
            ["git", "commit", "-m", f"Initial scaffold: {framework} {version}"],
            capture_output=True, text=True,
            timeout=30, cwd=str(target),
        )
        return True
    except (subprocess.TimeoutExpired, OSError):
        return False


def _detect_via_llm(task: str, router: object) -> tuple[str, FrameworkConfig] | None:
    """Detect framework using LLM when keyword matching fails."""
    try:
        system = (
            "You are a framework detection expert. Given a project description, "
            "identify the web framework or technology stack. "
            "Return JSON only: {\"framework\": \"laravel\"|\"django\"|\"react\"|etc, "
            "\"install_hint\": \"composer create-project...\" or \"npm create...\" or \"pip install...\", "
            "\"language\": \"php\"|\"python\"|\"javascript\"|\"go\"|\"rust\"|\"ruby\"}. "
            "If unknown, return {\"framework\": \"unknown\"}."
        )
        result = router.call_executor(system, task, max_tokens=256) if hasattr(router, "call_executor") else {"text": ""}
        text = result.get("text", "") if not (isinstance(result, dict) and "error" in result) else ""
        if text:
            import re
            m = re.search(r"\{.*\}", text, re.DOTALL)
            if m:
                data = json.loads(m.group(0))
                fw = data.get("framework", "unknown")
                if fw and fw != "unknown":
                    install_hint = data.get("install_hint", "")
                    lang = data.get("language", "")
                    cfg = FrameworkConfig(
                        label=fw.capitalize(),
                        install_cmd=install_hint or "echo 'Manual install required'",
                        versions=["latest"],
                        required_tools=[lang] if lang else [],
                    )
                    return fw, cfg
    except Exception:
        pass
    return None


def _silent_cmd(cmd: str, cwd: Path) -> None:
    """Run a shell command silently, ignoring errors."""
    import contextlib
    with contextlib.suppress(subprocess.TimeoutExpired, OSError):
        subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=120, cwd=str(cwd))


def _generate_skills(target: Path, framework: str, cfg: FrameworkConfig | None, answers: dict[str, str], router: object = None) -> None:
    """Create skill markdown files in .widdx/skills/ for the detected framework."""
    from widdx import ui
    c = ui.get_console()

    label = cfg.label if cfg else framework
    skill_filename = f"{framework}-best-practices.md"
    skill_name = f"{framework}-best-practices"

    existing = _find_existing_skill(skill_name)
    if existing:
        c.print(f"  [success]\u2713[/] Skill: [text]{skill_name}[/] (already exists)")
        return

    learned = _check_self_learning(framework, router)
    if learned:
        try:
            skills_dir = target / ".widdx" / "skills"
            skills_dir.mkdir(parents=True, exist_ok=True)
            (skills_dir / skill_filename).write_text(learned, encoding="utf-8")
            c.print(f"  [success]\u2713[/] Skill: [text]{skill_name}[/] (from past experience)")
            return
        except OSError:
            pass

    c.print(f"  [dim]Generating new skill: {label}...[/]")
    skills_dir = target / ".widdx" / "skills"
    try:
        skills_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        return

    llm = router if (router is not None and hasattr(router, 'call_executor')) else None
    if llm is None:
        try:
            from widdx.router import AIRouter
            from widdx.config import load_config, DEFAULT_MEMORY_DB_PATH
            from widdx.memory import MemoryStore
            _config = load_config()
            _memory = MemoryStore(_config.get("memory", {}).get("db_path", DEFAULT_MEMORY_DB_PATH))
            llm = AIRouter(_config, _memory)
        except Exception:
            pass

    if llm is not None and getattr(llm, 'is_ready', False):
        try:
            system = (
                f"You are a {label} expert. Write a concise skill file for WIDDX CLI that "
                f"teaches an AI agent the best practices for {label} development. "
                "Include: project structure conventions, key commands, code quality rules, "
                "testing patterns, and common pitfalls to avoid. "
                f"The skill name is '{skill_name}'."
            )
            user_msg = (
                f"Write a comprehensive skill guide for {label} development. "
                f"Focus on practical, actionable advice for an AI coding agent."
            )
            result = llm.call_executor(system, user_msg, max_tokens=2048)
            content = result.get("text", "") if not (isinstance(result, dict) and "error" in result) else ""
            if content and len(content) > 100:
                (skills_dir / skill_filename).write_text(content, encoding="utf-8")
                c.print(f"  [success]\u2713[/] Skill: [text]{skill_name}[/] (generated)")
                return
        except Exception:
            pass

    fallback = (
        f"# {label if cfg else framework} Development Guide\n\n"
        f"## Project Structure\n"
        f"- Follow the standard {label if cfg else framework} project layout\n\n"
        f"## Code Quality\n"
        f"- Follow language-specific style guides\n"
        f"- Write tests for critical paths\n\n"
        f"## Commands\n"
        f"- Use the framework's built-in CLI tools\n"
        f"- Run tests frequently\n"
    )
    try:
        (skills_dir / skill_filename).write_text(fallback, encoding="utf-8")
        c.print(f"  [success]\u2713[/] Skill: [text]{skill_name}[/] (built-in fallback)")
    except OSError:
        pass


def _find_existing_skill(skill_name: str) -> bool:
    """Check if a skill already exists in any of the 3 search directories."""
    search_dirs = [
        Path(__file__).resolve().parent.parent.parent / "skills" / "builtin",
        Path("~/.widdx/skills").expanduser(),
        Path(".widdx/skills"),
    ]

    for directory in search_dirs:
        if not directory.exists() or not directory.is_dir():
            continue
        for md_file in directory.glob("*.md"):
            try:
                text = md_file.read_text(encoding="utf-8")
                if skill_name in text or md_file.stem == skill_name:
                    return True
            except OSError:
                continue
    return False


def _check_self_learning(framework: str, router: object = None) -> str | None:
    """Check if SelfLearning has learned patterns for this framework."""
    if router is None or not hasattr(router, 'memory'):
        return None
    try:
        memory = router.memory
        events = memory.recent_learning_events(limit=20)
        framework_lower = framework.lower()
        relevant = []
        for ev in events:
            task_text = (ev.get("task_text") or "").lower()
            if framework_lower in task_text:
                relevant.append(ev.get("result_summary", ""))

        if len(relevant) >= 3:
            return (
                f"---\nname: {framework}-best-practices\n"
                f"description: Learned from {len(relevant)} successful {framework} tasks\n"
                f"auto_invoke: true\n---\n\n"
                f"## Learned Patterns\n\n"
                + "\n".join(f"- {r[:200]}" for r in relevant[-5:])
            )
    except Exception:
        pass
    return None


def _generate_hooks(target: Path, framework: str, label: str = "") -> None:
    """Create project-specific hooks in .widdx/hooks.json."""
    hooks_file = target / ".widdx" / "hooks.json"
    if hooks_file.exists():
        return

    from widdx import ui
    hooks = {
        "hooks": {
            "PreToolUse": [
                {
                    "matcher": "Bash",
                    "type": "command",
                    "command": f"echo '[WIDDX] Tool: $WIDDX_TOOL'"
                }
            ],
            "PostToolUse": [
                {
                    "matcher": "Write|Edit",
                    "type": "command",
                    "command": f"echo '[WIDDX] File modified: $WIDDX_FILE_PATH'",
                    "async": True,
                }
            ],
            "TaskCompleted": [
                {
                    "type": "command",
                    "command": f"echo '[WIDDX] Task completed' >> .widdx/task.log",
                    "async": True,
                }
            ],
        }
    }
    try:
        hooks_file.parent.mkdir(parents=True, exist_ok=True)
        hooks_file.write_text(
            json.dumps(hooks, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        ui.get_console().print(f"  [success]\u2713[/] Hooks: [text].widdx/hooks.json[/]")
    except OSError:
        pass


def _generate_mcp_config(target: Path) -> None:
    """Create project-specific MCP config in .widdx/mcp.json."""
    mcp_file = target / ".widdx" / "mcp.json"
    if mcp_file.exists():
        return

    from widdx import ui
    mcp_config = {
        "_comment": "MCP servers for this project. Enable by removing _disabled or setting to false.",
        "mcpServers": {
            "filesystem": {
                "command": "npx",
                "args": ["-y", "@anthropic/mcp-server-filesystem", "."],
                "_disabled": True,
                "_note": "Provides filesystem access tools",
            },
            "fetch": {
                "command": "npx",
                "args": ["-y", "@anthropic/mcp-server-fetch"],
                "_disabled": True,
                "_note": "Fetch and process web content",
            }
        }
    }
    try:
        mcp_file.write_text(
            json.dumps(mcp_config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        ui.get_console().print(f"  [success]\u2713[/] MCP: [text].widdx/mcp.json[/]")
    except OSError:
        pass


def _create_widdx_dir(target: Path, framework: str, version: str, answers: dict[str, str]) -> None:
    """Create the .widdx/ project state directory in the target project."""
    widdx_dir = target / ".widdx"
    skills_dir = widdx_dir / "skills"
    try:
        widdx_dir.mkdir(parents=True, exist_ok=True)
        skills_dir.mkdir(exist_ok=True)

        state = {
            "version": 1,
            "framework": framework,
            "framework_version": version,
            "answers": answers,
            "created_at": __import__("datetime").datetime.now().isoformat(),
        }
        (widdx_dir / "project.json").write_text(
            json.dumps(state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except OSError:
        pass
