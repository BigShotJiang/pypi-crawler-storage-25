"""AgentRunner — runs a single agent with its own ToolLoop and real tool access."""
from __future__ import annotations

import time

from ..agents.registry import AgentRegistry
from .spec import AgentSpec

# Maximum characters for the isolated context message passed to the agent.
_MAX_CONTEXT_CHARS = 2000


class AgentRunner:
    """Runs a single agent with its own ToolLoop — agents have real tool access."""

    def __init__(self, spec: AgentSpec, router, project_context: str = "") -> None:
        self._spec = spec
        self._router = router
        self._project_context = project_context

    # ------------------------------------------------------------------
    # Context helpers
    # ------------------------------------------------------------------

    def _build_isolated_context(self, prior_outputs: dict[str, str] | None) -> str:
        """Convert prior_outputs into a single compact context message.

        Handoff blocks (keys starting with ``__handoff__``) are preferred over
        raw outputs because they are already compressed.  The result is capped
        at ``_MAX_CONTEXT_CHARS`` to avoid token waste.

        Returns an empty string when there are no prior outputs.
        """
        if not prior_outputs:
            return ""

        handoff_blocks = {
            k[len("__handoff__"):]: v
            for k, v in prior_outputs.items()
            if k.startswith("__handoff__")
        }
        regular_outputs = {
            k: v for k, v in prior_outputs.items()
            if not k.startswith("__handoff__")
        }

        parts: list[str] = ["## Context from previous agents\n"]

        # Structured handoffs first — they are already compact
        for role, handoff_text in handoff_blocks.items():
            parts.append(f"### Handoff from {role}\n{handoff_text}\n")

        # Raw outputs only for roles not already covered by a handoff
        for role, output in regular_outputs.items():
            if role not in handoff_blocks:
                # Truncate raw output aggressively — it can be very long
                truncated = output[:500] + ("…" if len(output) > 500 else "")
                parts.append(f"### {role}\n{truncated}\n")

        context = "\n".join(parts)

        # Hard cap to avoid token waste
        if len(context) > _MAX_CONTEXT_CHARS:
            context = context[:_MAX_CONTEXT_CHARS] + "\n… (truncated)"

        return context

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def run(self, task: str, prior_outputs: dict[str, str] | None = None) -> dict:
        """Execute the agent. Returns {role, output, created_files, edited_files, error?}.

        Each call creates a **fresh** ToolLoop with ``_messages = []`` so that
        agents running in parallel never share conversation state.

        prior_outputs can contain regular outputs keyed by role name,
        and structured handoffs keyed as ``__handoff__<role>``.
        """
        from ..tool_loop import ToolLoop

        # Fresh isolated loop — _messages starts empty, no shared state
        isolated_loop = ToolLoop(self._router, max_steps=50)

        # Use built-in system prompt if available for this domain, else use spec prompt
        builtin_prompt = AgentRegistry.get_system_prompt(self._spec.domain)
        base_system = builtin_prompt if builtin_prompt else self._spec.to_system_prompt(
            self._project_context, prior_outputs
        )
        isolated_loop.set_project_context(base_system)

        # Build the compact handoff context that seeds this agent's conversation
        isolated_context = self._build_isolated_context(prior_outputs)

        # Compose the user message for this agent
        user_msg_parts = [
            f"Task: {task}",
            "",
            f"Your role: {self._spec.role}",
            f"Your goal: {self._spec.goal}",
        ]
        if prior_outputs:
            user_msg_parts += [
                "",
                "Previous agents completed:",
                *[f"- {role}: completed" for role in prior_outputs],
                "",
                "Now execute your part. Use tools to read existing files first.",
            ]
        else:
            user_msg_parts += [
                "",
                "Execute your part. Use tools to explore the project first.",
            ]
        user_msg_parts += [
            "",
            "When you finish, include these sections at the end of your response:",
            "## Decisions",
            "- Decision: <key architectural or implementation decision>",
            "",
            "## Next Steps",
            "- Next Step: <what the next agent should do>",
        ]
        user_msg = "\n".join(user_msg_parts)

        # Seed conversation_history with the isolated context so the agent
        # receives prior work as a user message — not baked into the system prompt.
        # This keeps _messages clean and isolated per agent.
        conversation_history: list[dict] = []
        if isolated_context:
            conversation_history.append({"role": "user", "content": isolated_context})
            conversation_history.append({
                "role": "assistant",
                "content": "Understood. I'll use this context as my foundation.",
            })

        start = time.perf_counter()
        output = isolated_loop.run(user_msg, conversation_history=conversation_history)
        elapsed_ms = int((time.perf_counter() - start) * 1000)

        return {
            "role": self._spec.role,
            "domain": self._spec.domain,
            "output": output,
            "created_files": list(isolated_loop._created_files),
            "edited_files": list(isolated_loop._edited_files),
            "latency_ms": elapsed_ms,
            "tool_calls": isolated_loop._tool_calls_count,
        }
