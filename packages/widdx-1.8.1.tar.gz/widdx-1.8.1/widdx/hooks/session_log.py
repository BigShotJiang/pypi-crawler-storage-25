"""SessionStart and TaskCompleted hook: log session and task events."""

import json
import os
import sys
from datetime import datetime, timezone

LOG_DIR = os.path.expanduser("~/.widdx/logs")


def ensure_log_dir():
    os.makedirs(LOG_DIR, exist_ok=True)


def log_session_start(data: dict) -> None:
    """Log session start event."""
    ensure_log_dir()
    session_id = data.get("session_id", "unknown")
    cwd = data.get("cwd", "")
    log_file = os.path.join(LOG_DIR, "sessions.log")

    entry = json.dumps({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": "SessionStart",
        "session_id": session_id,
        "cwd": cwd,
    })

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(entry + "\n")


def log_task_completed(data: dict) -> None:
    """Log task completion event."""
    ensure_log_dir()
    log_file = os.path.join(LOG_DIR, "tasks.log")

    entry = json.dumps({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event": "TaskCompleted",
        "session_id": data.get("session_id", "unknown"),
    })

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(entry + "\n")


def main():
    event = os.environ.get("WIDDX_HOOK_EVENT", "")
    if not event:
        # Try parsing from --event flag
        for arg in sys.argv:
            if arg.startswith("--event"):
                event = arg.split("=", 1)[-1]

    try:
        data = json.loads(sys.stdin.read())
    except (json.JSONDecodeError, EOFError):
        data = {}

    if event == "SessionStart":
        log_session_start(data)
    elif event == "TaskCompleted":
        log_task_completed(data)

    sys.exit(0)


if __name__ == "__main__":
    main()
