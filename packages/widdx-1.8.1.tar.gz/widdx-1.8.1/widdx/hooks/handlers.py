"""
widdx/hooks/handlers.py — Dedicated hook handler classes (GAP-2, task 4.3)

Extracts command and prompt hook execution logic from HookManager into
focused, single-responsibility handler classes.
"""

from __future__ import annotations

import json
import logging
import os
import re as _re
import subprocess
from dataclasses import dataclass

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# HookResult — defined here to avoid circular imports with __init__.py
# ---------------------------------------------------------------------------


@dataclass
class HookResult:
    """Result of firing a single hook."""

    event: str
    hook_type: str          # "command" | "prompt"
    success: bool
    output: str = ""
    blocked: bool = False   # True when a prompt hook returns "DENY"


# ---------------------------------------------------------------------------
# CommandHandler
# ---------------------------------------------------------------------------


class CommandHandler:
    """Executes shell command hooks with env-var sanitisation.

    The command string comes from hooks.json (user-controlled config, trusted).
    Untrusted data (file paths, tool names) is injected via environment
    variables and expanded by the shell as ``$WIDDX_FILE_PATH`` etc.

    To prevent shell injection via malicious file names, every context value
    is checked for shell metacharacters before being placed in the environment.
    Values that contain metacharacters are replaced with an empty string and a
    warning is logged — the hook still runs, but without the unsafe datum.
    """

    # Shell metacharacters that could cause command injection when a value
    # is expanded via $VAR inside a shell command string.
    _SHELL_DANGEROUS = _re.compile(r"[;&|`$(){}\[\]<>!*\n\r\x00]")

    def run(self, event: str, hook: dict, context: dict) -> HookResult:
        """Run a command-type hook.

        Args:
            event:   The lifecycle event name (e.g. "PostToolUse").
            hook:    The hook config dict (must contain a ``command`` key).
            context: Arbitrary context dict; values are injected as env vars.

        Returns:
            A ``HookResult`` describing the outcome.
        """
        command = hook.get("command", "")
        if not command:
            return HookResult(
                event=event,
                hook_type="command",
                success=False,
                output="Hook has no 'command' field",
            )

        env = self._build_env(context)

        try:
            proc = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                env=env,
                timeout=30,
            )
            output = (proc.stdout + proc.stderr).strip()
            success = proc.returncode == 0

            if not success:
                logger.warning(
                    "Hook command exited with code %d: %s\n%s",
                    proc.returncode,
                    command,
                    output,
                )

            return HookResult(
                event=event,
                hook_type="command",
                success=success,
                output=output,
            )
        except subprocess.TimeoutExpired:
            return HookResult(
                event=event,
                hook_type="command",
                success=False,
                output=f"Hook command timed out: {command}",
            )
        except OSError as exc:
            return HookResult(
                event=event,
                hook_type="command",
                success=False,
                output=f"Hook command error: {exc}",
            )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_env(self, context: dict) -> dict[str, str]:
        """Build an environment dict for subprocess, injecting context values.

        All context values are exposed as ``WIDDX_<KEY>`` env vars (uppercased).
        Values containing shell metacharacters are rejected (set to ``""``)
        to prevent command injection when the shell expands ``$VAR`` references.
        """
        env = os.environ.copy()

        for key, value in context.items():
            if isinstance(value, str):
                env_key = f"WIDDX_{key.upper()}"
                env[env_key] = self._safe_value(value, env_key)

        # Convenience aliases used in the hooks.json examples
        if "tool" in context:
            env["WIDDX_TOOL"] = self._safe_value(str(context["tool"]), "WIDDX_TOOL")
        if "file_path" in context:
            env["WIDDX_FILE_PATH"] = self._safe_value(str(context["file_path"]), "WIDDX_FILE_PATH")
        if "path" in context:
            env.setdefault("WIDDX_FILE_PATH", self._safe_value(str(context["path"]), "WIDDX_FILE_PATH"))

        return env

    @classmethod
    def _safe_value(cls, value: str, var_name: str) -> str:
        """Return *value* if it is safe for shell expansion, otherwise ``""``.

        Logs a warning when a value is rejected so the user knows a hook
        ran with sanitised input.
        """
        if cls._SHELL_DANGEROUS.search(value):
            logger.warning(
                "Hook env var %s rejected: value contains shell metacharacters (%r)",
                var_name,
                value[:80],
            )
            return ""
        return value


# ---------------------------------------------------------------------------
# PromptHandler
# ---------------------------------------------------------------------------


class PromptHandler:
    """Handles prompt-type hooks.

    Extracted from ``HookManager._run_prompt_hook()`` so the logic lives in
    one place and can be tested independently.

    When a *router* is provided, the handler calls the LLM with the prompt
    text and context, then parses the response for ALLOW / DENY.  Without a
    router the handler falls back to checking ``_prompt_response`` in the
    context dict (used by tests and legacy ToolLoop integration).
    """

    def __init__(self, router=None) -> None:
        self._router = router

    def run(self, event: str, hook: dict, context: dict) -> HookResult:
        """Handle a prompt-type hook.

        Args:
            event:   The lifecycle event name (e.g. "PreToolUse").
            hook:    The hook config dict (must contain a ``prompt`` key).
            context: Arbitrary context dict; values are interpolated into the
                     prompt template before sending to the LLM.

        Returns:
            A ``HookResult`` describing the outcome.
        """
        prompt_template = hook.get("prompt", "")
        if not prompt_template:
            return HookResult(
                event=event,
                hook_type="prompt",
                success=False,
                output="Hook has no 'prompt' field",
            )

        # Interpolate context values into the prompt template
        prompt_text = self._interpolate(prompt_template, context)

        blocked = False
        response_text = ""

        if self._router is not None:
            # Build a brief system message instructing the model how to respond
            system = (
                "You are a safety guard for an autonomous coding agent. "
                "Evaluate the following action and reply with ALLOW or DENY only. "
                "DENY if the action appears destructive, untrusted, or out of scope."
            )
            user = (
                f"Event: {event}\n"
                f"Prompt: {prompt_text}\n"
                f"Context: {json.dumps(context, ensure_ascii=False, default=str)[:4000]}"
            )
            try:
                result = self._router.call_executor(system, user, max_tokens=64)
            except Exception:
                logger.warning("LLM call failed for prompt hook — defaulting to DENY", exc_info=True)
                return HookResult(
                    event=event,
                    hook_type="prompt",
                    success=False,
                    output="LLM call failed",
                    blocked=True,
                )

            if "error" in result:
                logger.warning("Router error for prompt hook: %s — defaulting to DENY", result["error"])
                return HookResult(
                    event=event,
                    hook_type="prompt",
                    success=False,
                    output=result.get("error", "unknown router error"),
                    blocked=True,
                )

            response_text = result.get("text", "").strip().upper()
        else:
            # Fallback: check for a pre-computed model response in context
            # (used by tests and the legacy path)
            response_text = context.get("_prompt_response", "").strip().upper()

        blocked = response_text.startswith("DENY")

        return HookResult(
            event=event,
            hook_type="prompt",
            success=True,
            output=prompt_text,
            blocked=blocked,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _interpolate(template: str, context: dict) -> str:
        """Replace ``$KEY`` and ``${KEY}`` placeholders with context values."""
        result = template
        for key, value in context.items():
            if isinstance(value, str):
                result = result.replace(f"${{{key}}}", value)
                result = result.replace(f"${key}", value)
        return result


__all__ = ["CommandHandler", "HookResult", "PromptHandler"]
