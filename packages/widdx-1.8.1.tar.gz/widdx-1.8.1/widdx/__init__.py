"""WIDDX CLI — Autonomous AI Orchestration System.

Powered by DeepSeek V4.
"""

__version__ = "1.4.0"