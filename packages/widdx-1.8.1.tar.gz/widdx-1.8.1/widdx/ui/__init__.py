"""WIDDX Terminal UI — clean design with Arabic RTL support.

All public symbols are re-exported from sub-modules for backward compatibility.
"""

from .arabic import _cp_is_arabic, _d, _is_arabic, has_arabic, reshape
from .boot import show_provider_boot
from .chat import chat_assistant, chat_streaming_token, chat_user, chat_welcome
from .drawing import (
    BANNER,
    divider,
    done,
    error_box,
    fail,
    info,
    rule,
    section,
    show_banner,
    success_box,
    table,
    task_done,
    task_done_simple,
    task_start,
    tool_call,
    warn,
)
from .professional import (
    LiveStreamRenderer,
    confirm,
    confirm_with_options,
    create_layout,
    file_tree,
    get_file_icon,
    progress_bar,
    render_code,
    render_diff,
    render_markdown,
    spinner,
    status_line,
)
from .prompt import prompt, update_toolbar
from .theme import WIDDX_THEME, get_console
from .views import show_git, show_index, show_search, show_status, show_tools
from .widgets import (
    EnhancedProgressBar,
    MultiProgressBar,
    StatusBar,
    Task,
    TaskDashboard,
    Toast,
    ToastLevel,
    ToastNotificationManager,
)

__all__ = [
    # theme
    "WIDDX_THEME", "get_console",
    # arabic
    "reshape", "has_arabic", "_is_arabic", "_cp_is_arabic", "_d",
    # drawing
    "BANNER", "rule", "section", "divider", "done", "fail", "warn", "info",
    "error_box", "success_box",
    "show_banner", "task_start", "task_done", "task_done_simple", "table",
    "tool_call",
    # chat
    "chat_welcome", "chat_user", "chat_assistant", "chat_streaming_token",
    # prompt
    "prompt", "update_toolbar",
    # views
    "show_status", "show_search", "show_tools", "show_index", "show_git",
    # professional
    "render_markdown", "render_code", "render_diff",
    "spinner", "progress_bar", "file_tree", "confirm", "confirm_with_options",
    "status_line", "create_layout", "get_file_icon",
    "LiveStreamRenderer",
    # widgets
    "StatusBar", "TaskDashboard", "Task",
    "EnhancedProgressBar", "MultiProgressBar",
    "ToastNotificationManager", "Toast", "ToastLevel",
]
