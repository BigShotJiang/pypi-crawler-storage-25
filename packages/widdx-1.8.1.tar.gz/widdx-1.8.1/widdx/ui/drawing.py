"""Drawing helpers — sci-fi terminal visual language."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from datetime import datetime
from typing import Any

from rich import box as rich_box
from rich.panel import Panel
from rich.text import Text

from .arabic import _d
from .theme import get_console


def _os_label() -> str:
    """Return a short OS identifier for the banner."""
    if sys.platform == "win32":
        return "Windows"
    elif sys.platform == "darwin":
        return "macOS"
    return "Linux"


def _check_arabic_terminal(c) -> None:
    """Detect Arabic rendering quality and auto-fix font issues.

    Strategy per terminal type:
    - Windows Terminal: auto-download Kawkab Mono (best Arabic monospace)
      → fallback to Cascadia Code via winget
    - CMD classic: suggest Courier New (only font that works reliably)
    - Other modern terminals: suggest Cascadia Code
    """
    from .arabic import terminal_arabic_quality

    quality = terminal_arabic_quality()
    if quality == "native":
        return  # Windows Terminal already handles Arabic natively, font is bonus

    is_win = sys.platform == "win32"
    is_wt = bool(os.environ.get("WT_SESSION"))  # Windows Terminal detected at runtime

    # ── Try installing Kawkab Mono (best Arabic monospace) ──────
    if is_win:
        _install_kawkab_mono(c, is_wt)

    # ── Fallback: Cascadia Code via winget ─────────────────────
    if is_win:
        has_winget = shutil.which("winget") is not None
        if has_winget:
            try:
                proc = subprocess.run(
                    ["winget", "list", "Microsoft.CascadiaCode", "--accept-source-agreements"],
                    capture_output=True, text=True, timeout=15
                )
                if "Cascadia" not in (proc.stdout or ""):
                    c.print("  [dim]⎿ Installing Cascadia Code (fallback Arabic font)...[/]")
                    subprocess.run(
                        ["winget", "install", "Microsoft.CascadiaCode",
                         "--accept-package-agreements", "--accept-source-agreements"],
                        capture_output=True, text=True, timeout=60
                    )
            except Exception:
                pass

    # ── Show guidance ──────────────────────────────────────────
    lines: list[str]
    if quality == "poor":
        lines = [
            "تنبيه: الطرفية الحالية (CMD) لا تدعم العربية.",
            "استخدم Windows Terminal (wt) لتجربة كاملة.",
            "أو اختر Courier New من خصائص CMD."
        ]
    else:
        lines = [
            "نصيحة: ثبّت خط Kawkab Mono للحصول على أفضل عرض عربي:",
            "  https://github.com/aiaf/kawkab-mono/releases",
            "ثم اختره في إعدادات Windows Terminal."
        ]

    c.print()
    c.print(Panel(
        Text(_d("\n".join(lines)), style="warning"),
        title="[warning]⚠  Arabic Display[/]",
        border_style="warning",
        padding=(0, 1),
    ))
    c.print()


def _install_kawkab_mono(c, is_wt: bool) -> None:
    """Download and install Kawkab Mono from GitHub releases.

    Installs to user font directory (no admin required).
    Windows 10/11 auto-registers fonts placed in this directory.
    """
    import urllib.request
    from pathlib import Path

    font_dir = Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts"
    font_path = font_dir / "KawkabMono-Regular.ttf"

    if font_path.exists():
        return  # Already installed

    font_url = (
        "https://github.com/aiaf/kawkab-mono/releases/download/v0.501/"
        "KawkabMono-Regular.ttf"
    )

    try:
        c.print("  [dim]⎿ Installing Kawkab Mono (Arabic monospace font)...[/]")
        font_dir.mkdir(parents=True, exist_ok=True)
        urllib.request.urlretrieve(font_url, str(font_path))
        c.print("  [success]✓ Kawkab Mono installed[/]")
        if is_wt:
            c.print("  [dim]  Set font to 'Kawkab Mono' in Windows Terminal settings (Ctrl+,)[/]")
    except Exception:
        pass  # Silently continue — winget fallback above handles it


# ══════════════════════════════════════════════════════════════════════
# Banner — full sci-fi boot sequence
# ══════════════════════════════════════════════════════════════════════

# ASCII art lines (no surrounding box — the Panel provides the frame)
_ART_LINES = [
    "  ██╗    ██╗██╗██████╗ ██████╗ ██╗  ██╗",
    "  ██║    ██║██║██╔══██╗██╔══██╗╚██╗██╔╝",
    "  ██║ █╗ ██║██║██║  ██║██║  ██║ ╚███╔╝ ",
    "  ██║███╗██║██║██║  ██║██║  ██║ ██╔██╗ ",
    "  ╚███╔███╔╝██║██████╔╝██████╔╝██╔╝ ██╗",
    "   ╚══╝╚══╝ ╚═╝╚═════╝ ╚═════╝ ╚═╝  ╚═╝",
]

BANNER = "\n".join(_ART_LINES)


def show_banner() -> None:
    """Full sci-fi boot sequence banner."""
    from importlib.metadata import version as pkg_version
    c = get_console()

    try:
        ver = pkg_version("widdx")
    except Exception:
        ver = "1.4.0"

    now = datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
    cwd = os.path.basename(os.getcwd())

    # ── Build banner content ──────────────────────────────────────
    art = Text()
    for line in _ART_LINES:
        art.append(line + "\n", style="bold #00d4ff")

    art.append("\n")
    art.append("  AUTONOMOUS AI ENGINEERING OS", style="bold #00d4ff")
    art.append("  ·  ", style="#45475a")
    art.append(f"v{ver}", style="#6c7086")
    art.append("\n")
    art.append(f"  DeepSeek v4  ·  12 Agents  ·  Arabic/RTL  ·  {_os_label()}", style="#45475a")
    art.append("\n\n")
    art.append(f"  {now}", style="#45475a")
    art.append("   ", style="#45475a")
    art.append(f"cwd: {cwd}", style="#6c7086")

    c.print()
    c.print(Panel(
        art,
        border_style="#00d4ff",
        box=rich_box.DOUBLE,
        padding=(0, 1),
    ))
    c.print()

    # ── Terminal Arabic quality check ─────────────────────────────
    _check_arabic_terminal(c)


# ══════════════════════════════════════════════════════════════════════
# Section / Rule primitives
# ══════════════════════════════════════════════════════════════════════

def rule(title: str = "") -> None:
    """Horizontal divider — dim line with optional glowing title."""
    c = get_console()
    if title:
        c.print(f"\n  [dim]╌╌╌╌╌[/] [brand]{_d(title)}[/] [dim]╌╌╌╌╌[/]")
    else:
        c.print(f"  [dim]{'╌' * 55}[/]")


def section(title: str) -> None:
    """Sci-fi section header — glowing diamond + bold title."""
    c = get_console()
    c.print(f"\n  [brand]◆[/] [bold text]{_d(title)}[/]")


def divider() -> None:
    """Full-width dim separator."""
    c = get_console()
    c.print(f"  [dim]{'─' * 60}[/]")


# ══════════════════════════════════════════════════════════════════════
# Status indicators
# ══════════════════════════════════════════════════════════════════════

def done(msg: str = "") -> None:
    c = get_console()
    c.print(f"  [success]✓[/] [text]{_d(msg) or 'Done'}[/]")


def fail(msg: str) -> None:
    c = get_console()
    c.print(f"  [error]✗[/] [text]{_d(msg)}[/]")


def warn(msg: str) -> None:
    c = get_console()
    c.print(f"  [warning]▲[/] [text]{_d(msg)}[/]")


def info(key: str, value: str) -> None:
    c = get_console()
    c.print(f"  [muted]{_d(key)}:[/] [text]{_d(value)}[/]")


# ══════════════════════════════════════════════════════════════════════
# Panels
# ══════════════════════════════════════════════════════════════════════

def error_box(title: str, message: str) -> None:
    """Error panel with plasma-red border."""
    c = get_console()
    t = Text(_d(message), style="error")
    c.print()
    c.print(Panel(t, title=f"[error]✗  {_d(title)}[/]",
                  border_style="error", padding=(0, 2), box=rich_box.HEAVY))
    c.print()


def success_box(title: str, message: str) -> None:
    """Success panel with matrix-green border."""
    c = get_console()
    t = Text(_d(message), style="text")
    c.print()
    c.print(Panel(t, title=f"[success]✓  {_d(title)}[/]",
                  border_style="success", padding=(0, 2), box=rich_box.HEAVY))
    c.print()


# ══════════════════════════════════════════════════════════════════════
# Task lifecycle
# ══════════════════════════════════════════════════════════════════════

def task_start(task: str) -> None:
    """Display incoming task with sci-fi framing."""
    c = get_console()
    display = _d(task)
    if len(display) > 110:
        display = display[:107] + "…"

    t = Text()
    t.append("  ◆  ", style="bold #00d4ff")
    t.append(display, style="text")

    c.print()
    c.print(Panel(t, border_style="#45475a", box=rich_box.MINIMAL,
                  padding=(0, 0)))
    c.print()


def task_done_simple(result: str, max_lines: int = 50) -> None:
    """Simple result display."""
    c = get_console()
    if not result:
        return
    lines = result.split("\n")
    for line in lines[:max_lines]:
        c.print(f"  {_d(line)}")
    if len(lines) > max_lines:
        c.print(f"  [dim]… {len(lines) - max_lines} more lines[/]")


def task_done(result: Any) -> None:
    """Pipeline task completion panel."""
    c = get_console()
    ms = getattr(result, "total_latency_ms", 0)
    depth = getattr(result, "pipeline_depth", "?")
    complexity = getattr(result, "complexity", "?")

    if ms < 1000:
        t = f"{ms}ms"
    elif ms < 60_000:
        t = f"{ms / 1000:.1f}s"
    else:
        t = f"{ms / 60_000:.1f}m"

    c.print()
    parts = [f"[success]✓ done[/] [dim]·[/] [brand]{t}[/]"]
    if depth != "?":
        parts.append(f"[dim]depth[/] [info]{depth}/7[/]")
    if complexity != "?":
        parts.append(f"[dim]complexity[/] [warning]{complexity}/5[/]")
    c.print(f"  {' [dim]·[/] '.join(parts)}")

    output = getattr(result, "execution_output", "")
    if output:
        rule("Output")
        c.print(f"  {_d(output[:3000])}")
        if len(output) > 3000:
            c.print(f"  [dim]… {len(output) - 3000} more chars[/]")

    review = getattr(result, "review_feedback", "")
    if review:
        c.print()
        c.print(f"  [warning]▲ review:[/] [text]{_d(review[:500])}[/]")

    agents = getattr(result, "agents_generated", [])
    if agents:
        c.print(f"  [brand]◆ agents:[/] [text]{len(agents)} generated[/]")

    c.print()


def tool_call(tool_name: str, summary: str = "") -> None:
    """Legacy tool_call display (used outside tool_loop)."""
    c = get_console()
    name_lower = tool_name.lower()
    if any(x in name_lower for x in ("read", "glob", "list", "grep")):
        style = "tool_read"
    elif any(x in name_lower for x in ("write", "edit")):
        style = "tool_write"
    elif any(x in name_lower for x in ("bash", "shell")):
        style = "tool_shell"
    elif any(x in name_lower for x in ("web", "search")):
        style = "tool_web"
    else:
        style = "dim"

    label = f"[{style}]⏺ {tool_name}[/]"
    if summary:
        c.print(f"  {label} [dim]{_d(summary[:60])}{'…' if len(summary) > 60 else ''}[/]")
    else:
        c.print(f"  {label}")


# ══════════════════════════════════════════════════════════════════════
# Tables
# ══════════════════════════════════════════════════════════════════════

def table(title: str, columns: list[str], rows: list[list[str]],
          col_styles: list[str] | None = None) -> None:
    """Sci-fi styled table with SIMPLE box."""
    from rich.table import Table

    c = get_console()
    t = Table(
        title=f"[brand]{_d(title)}[/]",
        box=rich_box.SIMPLE,
        show_header=True,
        header_style="bold brand",
        border_style="dim",
        pad_edge=True,
        padding=(0, 1),
        title_style="bold brand",
    )
    for i, col in enumerate(columns):
        style = col_styles[i] if col_styles and i < len(col_styles) else "text"
        t.add_column(_d(col), style=style, overflow="ellipsis")
    for row in rows:
        t.add_row(*[_d(cell) for cell in row])
    c.print(t)
