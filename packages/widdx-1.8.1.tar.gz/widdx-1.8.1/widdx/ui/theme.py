"""WIDDX Terminal UI — Cyberpunk / Sci-Fi theme."""
from __future__ import annotations

import subprocess as _sp
import sys

from rich.console import Console
from rich.theme import Theme

# ── Palette: deep-space cyberpunk ────────────────────────────────────
WIDDX_THEME = Theme({
    "brand":      "bold #00d4ff",
    "highlight":  "bold #00d4ff",
    "success":    "bold #00ff88",
    "error":      "bold #ff3355",
    "warning":    "bold #ffb300",
    "info":       "bold #38bdf8",
    "accent":     "bold #ff2d78",
    "text":       "#cdd6f4",
    "muted":      "#6c7086",
    "dim":        "#45475a",
    "code":       "#f9e2af",
    "keyword":    "#89b4fa",
    "string":     "#a6e3a1",
    "tool_read":  "#38bdf8",
    "tool_write": "#00ff88",
    "tool_shell": "#ffb300",
    "tool_web":   "#ff2d78",
})

_console: Console | None = None


def _enable_windows_ansi() -> None:
    """Enable ANSI escape sequence processing on Windows terminals.

    On CMD and older terminals, ANSI codes appear as raw text unless
    ENABLE_VIRTUAL_TERMINAL_PROCESSING is set via the Windows API.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        for handle in (-11, -12):  # STD_OUTPUT_HANDLE, STD_ERROR_HANDLE
            h = kernel32.GetStdHandle(handle)
            mode = ctypes.c_uint32()
            if kernel32.GetConsoleMode(h, ctypes.byref(mode)):
                mode.value |= 0x0004  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
                kernel32.SetConsoleMode(h, mode.value)
    except Exception:
        pass


def get_console() -> Console:
    global _console
    if _console is None:
        if sys.platform == "win32":
            _enable_windows_ansi()
            _sp.run(["cmd", "/c", "chcp 65001"], check=False,
                    stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
            try:
                sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
                sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
            except Exception:
                pass
        _console = Console(
            theme=WIDDX_THEME,
            highlight=False,
            width=120,
            soft_wrap=True,
            force_terminal=True,
            legacy_windows=False,
            color_system="truecolor",
            safe_box=True,
        )
    return _console
