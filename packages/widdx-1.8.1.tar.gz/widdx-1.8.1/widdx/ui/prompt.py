"""Prompt input — autocomplete, history, bottom toolbar, Arabic RTL shaping."""
from __future__ import annotations

import os
import sys
from typing import Any

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.completion import WordCompleter
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.output import Output
    _HAS_PT = True
except ImportError:
    PromptSession: Any = None  # type: ignore[misc,no-redef]
    _HAS_PT = False

from .arabic import _d, has_arabic, reshape
from .theme import get_console

_prompt_session: PromptSession | None = None

# Shared state updated by the REPL so the toolbar can show live info
_toolbar_state: dict[str, str] = {
    "tokens": "",
    "cost": "",
    "model": "",
    "cwd": "",
    "last_task": "",
}


def update_toolbar(*, tokens: str = "", cost: str = "",
                   model: str = "", cwd: str = "",
                   last_task: str = "") -> None:
    """Update the bottom toolbar state from the REPL."""
    if tokens:
        _toolbar_state["tokens"] = tokens
    if cost:
        _toolbar_state["cost"] = cost
    if model:
        _toolbar_state["model"] = model
    if cwd:
        _toolbar_state["cwd"] = cwd
    if last_task:
        _toolbar_state["last_task"] = last_task


def _get_toolbar() -> HTML:
    """Sci-fi bottom toolbar — animated system status bar."""
    sep = '<ansibrightblack>  ║  </ansibrightblack>'
    parts: list[str] = []

    # System identity with glow
    parts.append('<ansicyan><b>◆ WIDDX</b></ansicyan>')

    model = _toolbar_state.get("model")
    if model:
        parts.append(sep + f'<ansimagenta>{model}</ansimagenta>')

    tokens = _toolbar_state.get("tokens")
    if tokens:
        parts.append(sep + f'<ansibrightblack>tok:</ansibrightblack> <ansigreen>{tokens}</ansigreen>')

    cost = _toolbar_state.get("cost")
    if cost:
        parts.append(sep + f'<ansibrightblack>$</ansibrightblack> <ansiyellow>{cost}</ansiyellow>')

    cwd = _toolbar_state.get("cwd") or os.path.basename(os.getcwd())
    if cwd:
        parts.append(sep + f'<ansibrightblack>{cwd}</ansibrightblack>')

    # Last task hint
    last_task = _toolbar_state.get("last_task")
    if last_task:
        parts.append(f'<ansibrightblack>    last: {last_task}</ansibrightblack>')

    # Keybindings hint
    parts.append(
        '<ansibrightblack>    '
        'Tab:complete  ↑↓:history  Esc+↵:newline'
        ' </ansibrightblack>'
    )

    return HTML("".join(parts))


# ── Arabic output wrapper ────────────────────────────────────────────

def _reshape_chunk(data: str) -> str:
    if not has_arabic(data):
        return data
    return reshape(data)


class _ArabicOutput(Output):
    """Wraps a prompt_toolkit Output to reshape Arabic text before display."""

    def __init__(self, real: Output) -> None:
        self._real = real

    def write(self, data: str) -> None:
        self._real.write(_reshape_chunk(data))

    def write_raw(self, data: str) -> None:
        self._real.write_raw(_reshape_chunk(data))

    # ── passthrough ──────────────────────────────────────────────
    def fileno(self) -> int:                          return self._real.fileno()  # type: ignore[no-any-return]
    @property
    def encoding(self) -> str:                        return self._real.encoding  # type: ignore[no-any-return,override,return-value]
    @property
    def stdout(self) -> Any:                          return self._real.stdout  # type: ignore[override]
    def flush(self) -> None:                          self._real.flush()
    @property
    def closed(self) -> bool:                         return self._real.closed  # type: ignore[attr-defined,no-any-return]
    def enable_mouse_support(self) -> None:           self._real.enable_mouse_support()
    def disable_mouse_support(self) -> None:          self._real.disable_mouse_support()
    def erase_screen(self) -> None:                   self._real.erase_screen()
    def enter_alternate_screen(self) -> None:         self._real.enter_alternate_screen()
    def quit_alternate_screen(self) -> None:          self._real.quit_alternate_screen()
    def enable_bracketed_paste(self) -> None:         self._real.enable_bracketed_paste()
    def disable_bracketed_paste(self) -> None:        self._real.disable_bracketed_paste()
    def hide_cursor(self) -> None:                    self._real.hide_cursor()
    def show_cursor(self) -> None:                    self._real.show_cursor()
    def set_title(self, title: str) -> None:          self._real.set_title(title)
    def clear_title(self) -> None:                    self._real.clear_title()
    def ask_for_cpr(self) -> None:                    self._real.ask_for_cpr()
    def bell(self) -> None:                           self._real.bell()
    def enable_autowrap(self) -> None:                self._real.enable_autowrap()
    def disable_autowrap(self) -> None:               self._real.disable_autowrap()
    def get_size(self) -> Any:                        return self._real.get_size()
    def get_char_name(self, char: str) -> str:        return self._real.get_char_name(char)  # type: ignore[attr-defined,no-any-return]
    def reset_attributes(self) -> None:               self._real.reset_attributes()
    def scroll_buffer_to_prompt(self) -> None:        self._real.scroll_buffer_to_prompt()
    def cursor_backward(self, amount: int) -> None:   self._real.cursor_backward(amount)
    def cursor_down(self, amount: int) -> None:       self._real.cursor_down(amount)
    def cursor_forward(self, amount: int) -> None:    self._real.cursor_forward(amount)
    def cursor_goto(self, row: int = 0, column: int = 0) -> None:
        self._real.cursor_goto(row, column)
    def cursor_up(self, amount: int) -> None:         self._real.cursor_up(amount)
    def erase_down(self) -> None:                     self._real.erase_down()
    def erase_end_of_line(self) -> None:              self._real.erase_end_of_line()
    def get_default_color_depth(self):                return self._real.get_default_color_depth()
    def get_rows_below_cursor_position(self) -> int:  return self._real.get_rows_below_cursor_position()  # type: ignore[no-any-return]
    def reset_cursor_key_mode(self) -> None:          self._real.reset_cursor_key_mode()
    def reset_cursor_shape(self) -> None:             self._real.reset_cursor_shape()
    def responds_to_cpr(self) -> bool:                return self._real.responds_to_cpr  # type: ignore[override,no-any-return]
    def set_attributes(self, attrs: object, color_depth: object) -> None:
        self._real.set_attributes(attrs, color_depth)  # type: ignore[arg-type]
    def set_cursor_shape(self, cursor_shape: object) -> None:
        self._real.set_cursor_shape(cursor_shape)  # type: ignore[arg-type]


def _make_arabic_output() -> Output | None:
    try:
        from prompt_toolkit.output.defaults import create_output
        return _ArabicOutput(create_output())
    except Exception:
        return None


# ── Session factory ──────────────────────────────────────────────────

_COMMANDS = [
    "/help", "/h", "/clear", "/c", "/compact", "/index", "/git",
    "/search", "/undo", "/approve", "/deny", "/agents", "/save",
    "/sessions", "/resume", "/model", "/tasks", "/llm", "/memory", "/learn",
    "/skills", "/hooks", "/mcp", "/bootstrap", "/key", "/providers", "/provider",
    "/exit", "/quit", "/q",
]


def _get_session() -> PromptSession | None:
    global _prompt_session
    if _prompt_session is not None:
        return _prompt_session
    if not _HAS_PT or PromptSession is None:
        return None

    history_dir = os.path.expanduser("~/.widdx")
    os.makedirs(history_dir, exist_ok=True)

    kb = KeyBindings()

    @kb.add("escape", "enter")
    def _multiline(event):
        """Esc+Enter inserts a newline for multi-line input."""
        event.current_buffer.insert_text("\n")

    try:
        _prompt_session = PromptSession(
            history=FileHistory(os.path.join(history_dir, "history")),
            completer=WordCompleter(_COMMANDS, ignore_case=True),
            key_bindings=kb,
            complete_while_typing=True,
            output=_make_arabic_output(),
            bottom_toolbar=_get_toolbar,
            refresh_interval=2.0,   # refresh toolbar every 2s
        )
    except Exception:
        _prompt_session = None

    return _prompt_session


# ── Public API ───────────────────────────────────────────────────────

def prompt(label: str = "widdx", rtl: bool | None = None) -> str:
    """Read user input — sci-fi prompt style.

        ◆ widdx  ❯  _
    """
    session = _get_session()
    if session is not None:
        try:
            return str(session.prompt(HTML(
                '<ansibrightblack>  </ansibrightblack>'
                '<b><ansibrightcyan>◆ widdx</ansibrightcyan></b>'
                '<ansibrightblack>  ❯  </ansibrightblack>'
            )))
        except (KeyboardInterrupt, EOFError):
            return "/exit"
        except Exception:
            pass

    # Fallback
    c = get_console()
    c.print(f"  [brand]◆ {_d(label)}[/]  [dim]❯[/]", end="  ")
    sys.stdout.flush()
    try:
        return input()
    except (KeyboardInterrupt, EOFError):
        return "/exit"
