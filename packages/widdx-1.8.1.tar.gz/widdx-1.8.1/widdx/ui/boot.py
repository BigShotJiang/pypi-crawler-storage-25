"""Boot screen — interactive provider selector shown on startup."""
from __future__ import annotations

from typing import Any


def show_provider_boot(config: dict[str, Any], router) -> None:
    """Interactive startup screen: choose which providers to activate.

    Shows all providers with checkboxes (✓/✗), Space to toggle,
    ↑↓ to navigate, Enter to confirm, Esc to skip.
    """
    from .theme import get_console
    from rich.panel import Panel
    from rich.text import Text

    c = get_console()

    providers = router.list_providers()
    if not providers:
        return

    disabled = set(config.get("disabled_providers", []))
    enabled_map: dict[str, bool] = {}
    for p in providers:
        name = p["name"]
        enabled_map[name] = name not in disabled

    try:
        from prompt_toolkit import PromptSession as _Session
        from prompt_toolkit.formatted_text import HTML as _HTML
        from prompt_toolkit.key_binding import KeyBindings as _Bindings
    except ImportError:
        _fallback_boot(c, providers, enabled_map, router)
        return

    names = [p["name"] for p in providers]
    idx = [0]

    kb = _Bindings()

    @kb.add("up")
    def _up(ev):
        idx[0] = (idx[0] - 1) % len(names)

    @kb.add("down")
    def _down(ev):
        idx[0] = (idx[0] + 1) % len(names)

    @kb.add("space")
    def _toggle(ev):
        name = names[idx[0]]
        router.toggle_provider(name)
        enabled_map[name] = not enabled_map[name]

    @kb.add("enter")
    def _confirm(ev):
        ev.app.exit()

    @kb.add("escape")
    def _skip(ev):
        ev.app.exit()

    @kb.add("c-c")
    def _cancel(ev):
        ev.app.exit()

    session: _Session = _Session(key_bindings=kb)

    def _render():
        lines: list[str] = []
        lines.append("\n  <ansicyan><b>SELECT PROVIDERS</b></ansicyan>\n")
        lines.append("  <ansibrightblack>──────────────────────────────────────────</ansibrightblack>\n\n")

        for i, name in enumerate(names):
            p = providers[i]
            selected = i == idx[0]
            enabled = enabled_map[name]
            cursor = "<ansicyan>▸</ansicyan>" if selected else " "
            checkbox = "<ansigreen>✓</ansigreen>" if enabled else "<ansired>✗</ansired>"
            status = "<ansigreen>enabled</ansigreen>" if enabled else "<ansired>disabled</ansired>"
            model_count = p.get("model_count", 1)
            count_hint = f"  <ansibrightblack>({model_count} models)</ansibrightblack>" if model_count > 1 else ""

            lines.append(f"  {cursor} [{checkbox}] <ansicyan>{name:22}</ansicyan> {status}{count_hint}\n")
            lines.append(f"      <ansibrightblack>arch: {p['architect_model']:24} exec: {p['executor_model']}</ansibrightblack>\n")

        active_count = sum(1 for v in enabled_map.values() if v)
        total = len(names)
        lines.append(f"\n  <ansibrightblack>──────────────────────────────────────────</ansibrightblack>\n")
        lines.append(f"  <ansigreen>{active_count}</ansigreen>/<ansicyan>{total}</ansicyan> providers active\n\n")
        lines.append(
            "<ansibrightblack>  ↑↓ navigate  ·  Space toggle  ·  Enter confirm  ·  Esc skip</ansibrightblack>"
        )
        return _HTML("".join(lines))

    session.prompt(_render)

    active_count = sum(1 for v in enabled_map.values() if v)
    c.print()
    c.print(f"  [success]✓[/] [text]{active_count} provider(s) active[/]")


def _fallback_boot(console, providers: list[dict], enabled_map: dict[str, bool], router) -> None:
    """Fallback boot screen when prompt_toolkit is not available."""
    from .professional import confirm_with_options

    console.print()
    console.print("  [brand]◆ SELECT PROVIDERS[/]")
    console.print()

    for p in providers:
        name = p["name"]
        enabled = enabled_map[name]
        icon = "[success]✓[/]" if enabled else "[dim]✗[/]"
        console.print(f"  {icon} [cyan]{name}[/]  [dim]{p['executor_model']}[/]")

    console.print()
    console.print("  [dim]Use /providers to manage providers[/]")
    console.print()
