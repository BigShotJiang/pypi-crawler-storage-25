"""WIDDX CLI memory system — SQLite-backed persistent storage."""
from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path

from widdx.config import DEFAULT_MEMORY_DB_PATH
from .schema import _MIGRATE_SQL, _utcnow

logger = logging.getLogger("widdx.memory")

# ── Inject methods from submodules ────────────────────────────────
from .patterns import (  # noqa: E402
    add_fix_pattern,
    get_fix_pattern,
    find_fix_patterns,
    update_fix_pattern_result,
    evict_lowest_confidence_pattern,
    fix_pattern_count,
    fix_pattern_high_confidence_count,
)
from .learning import (  # noqa: E402
    log_learning_event,
    recent_learning_events,
    upsert_learning_pattern,
    get_learning_pattern,
    list_learning_patterns,
    create_learning_asset,
    get_learning_asset,
    list_learning_assets,
)


class MemoryStore:
    """SQLite-backed memory with task, decision, agent, routing, and knowledge tables."""

    # ── Injected methods ───────────────────────────────────────────
    add_fix_pattern = add_fix_pattern
    get_fix_pattern = get_fix_pattern
    find_fix_patterns = find_fix_patterns
    update_fix_pattern_result = update_fix_pattern_result
    evict_lowest_confidence_pattern = evict_lowest_confidence_pattern
    fix_pattern_count = fix_pattern_count
    fix_pattern_high_confidence_count = fix_pattern_high_confidence_count
    log_learning_event = log_learning_event
    recent_learning_events = recent_learning_events
    upsert_learning_pattern = upsert_learning_pattern
    get_learning_pattern = get_learning_pattern
    list_learning_patterns = list_learning_patterns
    create_learning_asset = create_learning_asset
    get_learning_asset = get_learning_asset
    list_learning_assets = list_learning_assets

    def __init__(self, db_path: str = DEFAULT_MEMORY_DB_PATH) -> None:
        """Initialize the SQLite-backed memory store.

        Creates the database directory if needed, opens a connection, enables
        WAL journal mode and foreign keys, and runs any pending migrations.

        Args:
            db_path: Path to the SQLite database file.

        Raises:
            sqlite3.Error: Logged internally; store continues in disconnected state.
        """
        self._conn: sqlite3.Connection | None = None
        self._db_path: str = db_path
        self._error_count: int = 0
        resolved = Path(db_path).expanduser()
        try:
            resolved.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(resolved))
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._migrate()
            logger.info("MemoryStore initialized: %s", resolved)
        except sqlite3.Error as e:
            logger.error("Failed to initialize memory store at %s: %s", resolved, e)
            self._conn = None
            self._error_count += 1

    # ------------------------------------------------------------------
    # Health & Diagnostics
    # ------------------------------------------------------------------

    @property
    def is_connected(self) -> bool:
        """Return True if the database connection is open and responsive."""
        if self._conn is None:
            return False
        try:
            self._conn.execute("SELECT 1")
            return True
        except sqlite3.Error:
            return False

    @property
    def error_count(self) -> int:
        """Return the total number of SQL errors encountered since initialization."""
        return self._error_count

    def health_check(self) -> dict:
        """Return a diagnostic report of the memory store's status.

        Returns:
            dict with keys: connected, db_path, error_count, db_size_bytes.
        """
        report: dict = {
            "connected": self.is_connected,
            "db_path": str(Path(self._db_path).expanduser()),
            "error_count": self._error_count,
            "db_size_bytes": 0,
        }
        if report["connected"]:
            try:
                path = Path(self._db_path).expanduser()
                if path.exists():
                    report["db_size_bytes"] = path.stat().st_size
            except OSError:
                pass
        return report

    def __enter__(self) -> MemoryStore:
        """Enter context manager, returning self."""
        return self

    def __exit__(self, *args) -> None:
        """Exit context manager, closing the database connection."""
        self.close()

    def _execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor | None:
        """Execute a raw SQL query with optional parameters.

        Args:
            sql: SQL statement to execute.
            params: Tuple of parameter values for placeholders.

        Returns:
            sqlite3.Cursor on success, or None if disconnected or on error.

        Raises:
            sqlite3.Error: Logged internally; error_count is incremented.
        """
        if self._conn is None:
            logger.warning("MemoryStore disconnected \u2014 skipping query: %s", sql[:80])
            return None
        try:
            return self._conn.execute(sql, params)
        except sqlite3.Error as e:
            self._error_count += 1
            logger.error("SQL error [%s]: %s", sql[:80], e)
            return None

    def _commit(self) -> None:
        """Commit the current transaction, if the connection is open."""
        if self._conn:
            try:
                self._conn.commit()
            except sqlite3.Error as e:
                self._error_count += 1
                logger.error("Commit failed: %s", e)

    def _migrate(self) -> None:
        """Run schema migrations using the SQL script from the schema module."""
        if self._conn is None:
            return
        try:
            self._conn.executescript(_MIGRATE_SQL)
            self._conn.commit()
        except sqlite3.Error as e:
            self._error_count += 1
            logger.error("Migration failed: %s", e)

    # ------------------------------------------------------------------
    # Tasks
    # ------------------------------------------------------------------

    def create_task(self, task_id: str, command: str, intent: str = "", complexity: int = 1) -> str:
        """Insert a new task record.

        Args:
            task_id: Unique identifier for the task.
            command: The command or instruction for the task.
            intent: Optional description of the task's intent.
            complexity: Task complexity score (default 1).

        Returns:
            The task_id of the created task.
        """
        now = _utcnow()
        self._execute(
            "INSERT INTO tasks (id, command, intent, complexity, created_at) VALUES (?,?,?,?,?)",
            (task_id, command, intent, complexity, now),
        )
        self._commit()
        return task_id

    def complete_task(self, task_id: str, status: str = "completed") -> None:
        """Mark a task as completed with the given status.

        Args:
            task_id: The task to mark complete.
            status: Completion status (default "completed").
        """
        self._execute(
            "UPDATE tasks SET status=?, completed_at=? WHERE id=?",
            (status, _utcnow(), task_id),
        )
        self._commit()

    def get_task(self, task_id: str) -> dict | None:
        """Retrieve a single task by its ID.

        Args:
            task_id: The task identifier to look up.

        Returns:
            A dict of task fields, or None if not found.
        """
        row = self._execute("SELECT * FROM tasks WHERE id=?", (task_id,))
        if row is None:
            return None
        r = row.fetchone()
        return dict(r) if r else None

    def recent_tasks(self, limit: int = 10) -> list[dict]:
        """Return the most recently created tasks, newest first.

        Args:
            limit: Maximum number of tasks to return (default 10).

        Returns:
            List of task dicts, ordered by created_at descending.
        """
        rows = self._execute(
            "SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,)
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def log_decision(
        self, task_id: str, stage: str, decision_type: str,
        input_summary: str = "", output_summary: str = "",
        model_used: str = "", latency_ms: int = 0, tokens_used: int = 0,
    ) -> None:
        """Record a decision made during task execution.

        Args:
            task_id: The associated task identifier.
            stage: Pipeline stage where the decision was made.
            decision_type: Category or name of the decision.
            input_summary: Truncated input context (max 500 chars).
            output_summary: Truncated output result (max 1000 chars).
            model_used: Model identifier used for the decision.
            latency_ms: Response latency in milliseconds.
            tokens_used: Token count consumed.
        """
        self._execute(
            "INSERT INTO decisions "
            "(task_id, stage, decision_type, input_summary, output_summary, model_used, latency_ms, tokens_used, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (task_id, stage, decision_type, input_summary[:500], output_summary[:1000],
             model_used, latency_ms, tokens_used, _utcnow()),
        )
        self._commit()

    def task_decisions(self, task_id: str) -> list[dict]:
        """Retrieve all decisions logged for a given task.

        Args:
            task_id: The task identifier.

        Returns:
            List of decision dicts ordered by insertion id.
        """
        rows = self._execute(
            "SELECT * FROM decisions WHERE task_id=? ORDER BY id", (task_id,)
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def count_decisions(self) -> int:
        """Return the total number of decisions recorded in the database.

        Returns:
            The decision count, or 0 if the query fails.
        """
        row = self._execute("SELECT COUNT(*) as cnt FROM decisions")
        if row is None:
            return 0
        r = row.fetchone()
        return r["cnt"] if r else 0

    # ------------------------------------------------------------------
    # Knowledge
    # ------------------------------------------------------------------

    def set_knowledge(self, key: str, value: str) -> None:
        """Insert or replace a knowledge entry.

        Args:
            key: The knowledge key.
            value: The knowledge value (string).
        """
        self._execute(
            "INSERT OR REPLACE INTO knowledge (key, value, updated_at) VALUES (?,?,?)",
            (key, value, _utcnow()),
        )
        self._commit()

    def get_knowledge(self, key: str) -> str | None:
        """Retrieve a knowledge entry by its key.

        Args:
            key: The knowledge key to look up.

        Returns:
            The value string, or None if the key does not exist.
        """
        row = self._execute("SELECT value FROM knowledge WHERE key=?", (key,))
        if row is None:
            return None
        r = row.fetchone()
        return r["value"] if r else None

    def list_knowledge(self, limit: int = 20) -> list[dict]:
        """Return the most recently updated knowledge entries.

        Args:
            limit: Maximum number of entries to return (default 20).

        Returns:
            List of knowledge dicts ordered by updated_at descending.
        """
        rows = self._execute(
            "SELECT * FROM knowledge ORDER BY updated_at DESC LIMIT ?", (limit,)
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def search_knowledge(self, query: str, limit: int = 20) -> list[dict]:
        """Search knowledge entries by key or value substring.

        Args:
            query: Substring to search for in key or value fields.
            limit: Maximum number of results to return (default 20).

        Returns:
            List of matching knowledge dicts ordered by updated_at descending.
        """
        pattern = f"%{query}%"
        rows = self._execute(
            "SELECT * FROM knowledge WHERE key LIKE ? OR value LIKE ? ORDER BY updated_at DESC LIMIT ?",
            (pattern, pattern, limit),
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def get_project_plans(self, limit: int = 10) -> list[dict]:
        """Retrieve project plans stored in knowledge, parsed from JSON.

        Args:
            limit: Maximum number of plans to return (default 10).

        Returns:
            List of plan summary dicts with id, task, status, phases, and done counts.
        """
        rows = self._execute(
            "SELECT key, value, updated_at FROM knowledge WHERE key LIKE 'project_plan:%' ORDER BY updated_at DESC LIMIT ?",
            (limit,),
        )
        if rows is None:
            return []
        results = []
        for r in rows.fetchall():
            try:
                val = json.loads(r["value"])
                results.append({
                    "id": val.get("id", r["key"]),
                    "task": val.get("task", "")[:80],
                    "status": val.get("status", "?"),
                    "phases": len(val.get("phases", [])),
                    "done": sum(1 for p in val.get("phases", []) if p["status"] == "done"),
                    "updated_at": r["updated_at"],
                })
            except (json.JSONDecodeError, TypeError):
                continue
        return results

    # ------------------------------------------------------------------
    # Agent runs & routing
    # ------------------------------------------------------------------

    def log_agent_run(
        self, task_id: str, agent_role: str, agent_goal: str = "",
        model_used: str = "", success: bool = False,
        output_summary: str = "", latency_ms: int = 0,
    ) -> None:
        """Record an agent execution run.

        Args:
            task_id: The associated task identifier.
            agent_role: The role or persona of the agent.
            agent_goal: The agent's goal description (truncated at 300 chars).
            model_used: Model identifier used by the agent.
            success: Whether the agent run was successful.
            output_summary: Summary of the agent output (truncated at 500 chars).
            latency_ms: Execution latency in milliseconds.
        """
        self._execute(
            "INSERT INTO agent_runs (task_id, agent_role, agent_goal, model_used, success, output_summary, latency_ms, created_at) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (task_id, agent_role, agent_goal[:300], model_used, int(success), output_summary[:500], latency_ms, _utcnow()),
        )
        self._commit()

    def log_routing(self, task_type: str, model_selected: str, success_score: float = 0.5, latency_ms: int = 0, tokens_used: int = 0) -> None:
        """Record a routing decision (which model was chosen for a task type).

        Args:
            task_type: Category of the routed task.
            model_selected: The model that was chosen.
            success_score: Outcome score (0.0–1.0, default 0.5).
            latency_ms: Routing latency in milliseconds.
            tokens_used: Token count consumed.
        """
        self._execute(
            "INSERT INTO routing_history (task_type, model_selected, success_score, latency_ms, tokens_used, created_at) VALUES (?,?,?,?,?,?)",
            (task_type, model_selected, success_score, latency_ms, tokens_used, _utcnow()),
        )
        self._commit()

    def routing_stats(self, task_type: str) -> list[dict]:
        """Return aggregated routing statistics for a given task type.

        Args:
            task_type: The task type to query.

        Returns:
            List of dicts with model_selected, count, avg_score, and avg_latency.
        """
        rows = self._execute(
            "SELECT model_selected, COUNT(*) as count, AVG(success_score) as avg_score, AVG(latency_ms) as avg_latency "
            "FROM routing_history WHERE task_type=? GROUP BY model_selected",
            (task_type,),
        )
        if rows is None:
            return []
        return [dict(r) for r in rows.fetchall()]

    def close(self) -> None:
        """Close the database connection, if open."""
        if self._conn:
            self._conn.close()
            self._conn = None
