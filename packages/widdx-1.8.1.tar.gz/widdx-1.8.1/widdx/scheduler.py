"""widdx/scheduler.py — Cron-based task scheduler for WIDDX (GAP-6).

Stores schedules in ~/.widdx/schedules.json and optionally runs a blocking
daemon loop that fires tasks when their cron expression matches the current time.
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .memory import MemoryStore

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Schedule dict shape:
#   {
#     "id":         str,          # 8-char hex UUID fragment
#     "cron":       str,          # cron expression, e.g. "0 9 * * 1"
#     "task":       str,          # task description / command
#     "created_at": str,          # ISO-8601 UTC
#     "last_run":   str | None,   # ISO-8601 UTC of last execution, or None
#   }
# ---------------------------------------------------------------------------

_DAEMON_POLL_SECONDS = 60  # check interval for the daemon loop


class TaskScheduler:
    """Cron-based task scheduler for WIDDX.

    Schedules are persisted in a JSON file (default ``~/.widdx/schedules.json``).
    The optional daemon loop uses ``croniter`` to decide when tasks are due.

    Example usage::

        scheduler = TaskScheduler()
        task_id = scheduler.add("0 9 * * 1", "weekly code review")
        scheduler.list_schedules()
        scheduler.remove(task_id)
        scheduler.run_daemon()   # blocking
    """

    def __init__(
        self,
        schedules_path: str = "~/.widdx/schedules.json",
        memory: MemoryStore | None = None,
    ) -> None:
        self._path: Path = Path(schedules_path).expanduser()
        self._memory = memory

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def add(self, cron_expr: str, task: str) -> str:
        """Add a scheduled task and persist it.

        Args:
            cron_expr: Standard 5-field cron expression (e.g. ``"0 9 * * 1"``).
            task:      Task description or command to run when due.

        Returns:
            An 8-character hex task ID.
        """
        task_id = uuid.uuid4().hex[:8]
        schedule: dict = {
            "id": task_id,
            "cron": cron_expr,
            "task": task,
            "created_at": _utcnow(),
            "last_run": None,
        }
        schedules = self._load()
        schedules.append(schedule)
        self._save(schedules)
        logger.info("Schedule added: id=%s cron=%r task=%r", task_id, cron_expr, task)
        return task_id

    def list_schedules(self) -> list[dict[str, Any]]:
        """Return all saved schedules.

        Returns:
            List of schedule dicts (may be empty).
        """
        return self._load()

    def remove(self, task_id: str) -> bool:
        """Remove a schedule by ID.

        Args:
            task_id: The 8-character hex ID returned by :meth:`add`.

        Returns:
            ``True`` if the schedule was found and removed, ``False`` otherwise.
        """
        schedules = self._load()
        filtered = [s for s in schedules if s.get("id") != task_id]
        if len(filtered) == len(schedules):
            logger.debug("Schedule not found for removal: id=%s", task_id)
            return False
        self._save(filtered)
        logger.info("Schedule removed: id=%s", task_id)
        return True

    def run_daemon(self, runner_fn: Callable[[str], str] | None = None) -> None:
        """Start the scheduler daemon (blocking).

        Polls every 60 seconds and runs any task whose cron expression matches
        the current minute.  Results are logged; if *runner_fn* is provided it
        is called with the task string and its return value is logged as output.

        Args:
            runner_fn: Optional callable that receives the task string and
                       returns a result string.  Defaults to a no-op that
                       returns an empty string.

        Raises:
            ImportError: If ``croniter`` is not installed (caught internally;
                         a helpful message is printed and the daemon exits).
        """
        try:
            from croniter import croniter
        except ImportError:
            print(
                "croniter is not installed. "
                "Run: pip install croniter  (or add it to pyproject.toml)"
            )
            return

        if runner_fn is None:
            runner_fn = lambda task: ""  # noqa: E731

        logger.info("Scheduler daemon started — polling every %ds", _DAEMON_POLL_SECONDS)
        print(f"Scheduler daemon running (poll interval: {_DAEMON_POLL_SECONDS}s). Press Ctrl+C to stop.")

        try:
            while True:
                self._tick(croniter, runner_fn)
                time.sleep(_DAEMON_POLL_SECONDS)
        except KeyboardInterrupt:
            logger.info("Scheduler daemon stopped by user")
            print("\nScheduler daemon stopped.")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _tick(self, croniter_cls, runner_fn: Callable[[str], str]) -> None:
        """Check all schedules and run any that are due right now."""
        schedules = self._load()
        changed = False

        for schedule in schedules:
            cron_expr = schedule.get("cron", "")
            task = schedule.get("task", "")
            if not cron_expr or not task:
                continue

            try:
                # croniter.match checks whether the expression fires at the
                # given datetime (truncated to the current minute).
                now = datetime.now(timezone.utc).replace(second=0, microsecond=0)
                if croniter_cls.match(cron_expr, now):
                    logger.info("Running scheduled task id=%s: %r", schedule["id"], task)
                    try:
                        result = runner_fn(task)
                    except Exception as exc:  # noqa: BLE001
                        result = f"error: {exc}"
                        logger.error("Scheduled task id=%s failed: %s", schedule["id"], exc)
                    schedule["last_run"] = _utcnow()
                    changed = True
                    logger.info("Scheduled task id=%s result: %s", schedule["id"], result[:200] if result else "(empty)")
                    if self._memory is not None:
                        task_id_mem = uuid.uuid4().hex[:12]
                        self._memory.create_task(task_id_mem, task, intent="scheduled", complexity=1)
                        self._memory.complete_task(task_id_mem)
                        self._memory.set_knowledge(
                            f"scheduled_result:{schedule['id']}",
                            result[:500] if result else "(empty)",
                        )
            except Exception as exc:  # noqa: BLE001
                logger.warning("Invalid cron expression %r for task id=%s: %s", cron_expr, schedule.get("id"), exc)

        if changed:
            self._save(schedules)

    def _load(self) -> list[dict[str, Any]]:
        """Read schedules from the JSON file.

        Returns an empty list if the file does not exist or is malformed.
        """
        if not self._path.exists():
            return []
        try:
            data = json.loads(self._path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
            logger.warning("schedules.json has unexpected format at %s", self._path)
            return []
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("Failed to read schedules from %s: %s", self._path, exc)
            return []

    def _save(self, schedules: list[dict[str, Any]]) -> None:
        """Write schedules to the JSON file, creating parent dirs as needed."""
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            self._path.write_text(
                json.dumps(schedules, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            logger.error("Failed to save schedules to %s: %s", self._path, exc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


__all__ = ["TaskScheduler"]
