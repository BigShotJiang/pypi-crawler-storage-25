"""
widdx/skills/loader.py — Frontmatter parser and skill file loader (GAP-4)

Provides parse_frontmatter() and load_skill_file() used by SkillManager.
"""

from __future__ import annotations

import re
from pathlib import Path


def parse_frontmatter(text: str) -> tuple[dict, str]:
    """Parse YAML-style frontmatter from a markdown file.

    Returns (metadata_dict, body_content).
    If no frontmatter is found, returns ({}, full_text).
    """
    if not text.startswith("---"):
        return {}, text

    # Find the closing ---
    end = text.find("\n---", 3)
    if end == -1:
        return {}, text

    front = text[3:end].strip()
    body = text[end + 4:].strip()

    meta: dict = {}
    for line in front.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line:
            key, _, value = line.partition(":")
            key = key.strip()
            value = value.strip()
            # Parse booleans
            if value.lower() == "true":
                meta[key] = True
            elif value.lower() == "false":
                meta[key] = False
            else:
                # Strip surrounding quotes if present
                meta[key] = re.sub(r'^["\']|["\']$', "", value)

    return meta, body


def load_skill_file(path: Path) -> dict | None:
    """Read a skill markdown file and return a skill dict.

    Returns a dict with keys: name, description, auto_invoke, content.
    Returns None if the file cannot be read or has no usable content.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return None

    meta, body = parse_frontmatter(text)

    name = meta.get("name", "").strip()
    description = meta.get("description", "").strip()

    if not name:
        # Fall back to filename stem if no name in frontmatter
        name = path.stem

    if not description:
        description = f"Skill: {name}"

    auto_invoke: bool = bool(meta.get("auto_invoke", False))

    return {
        "name": name,
        "description": description,
        "auto_invoke": auto_invoke,
        "content": body,
    }


__all__ = ["parse_frontmatter", "load_skill_file"]
