"""AI Router — intelligent multi-provider routing with sequential review and parallel execution."""
from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import yaml

from .pricing import (
    PRICING,
    _estimate_tokens,
    _init_cost_tracking,
    _track_usage,
)
from .streaming import call_streaming, call_with_tools_streaming
from .tools_api import call_with_tools

logger = logging.getLogger(__name__)

# ── Executor model specialization ──────────────────────────────────
_EXECUTOR_SPECIALIZATION = {
    "deepseek-v4-flash-free": {"type": "coding", "desc": "general coding and edits"},
    "qwen3.6-plus-free": {"type": "review", "desc": "code review and quality check"},
    "minimax-m2.5-free": {"type": "context", "desc": "long context and large files"},
    "nemotron-3-super-free": {"type": "logic", "desc": "logic and complex algorithms"},
}

# Keywords that indicate a heavy task needing parallel execution
_HEAVY_TASK_KEYWORDS = {
    "build", "create", "generate", "implement", "scaffold",
    "full project", "complete system", "entire application",
    "migration", "refactor", "rewrite",
}


class AIRouter:
    """Routes tasks to providers with intelligent load balancing,
    sequential review, and parallel execution for heavy tasks."""

    # ── Injected methods from sub-modules ──────────────────────────
    call_streaming = call_streaming
    call_with_tools_streaming = call_with_tools_streaming
    call_with_tools = call_with_tools
    _estimate_tokens = _estimate_tokens
    _track_usage = _track_usage

    ARCHITECT_KEYWORDS = {
        "architecture", "design", "planning", "review", "validation",
        "architecture design", "system review", "refactoring plan",
        "security audit", "performance analysis", "code review",
    }

    EXECUTOR_KEYWORDS = {
        "code generation", "implementation", "boilerplate", "testing",
        "debugging", "fix", "build", "generate", "scaffold", "refactor",
    }

    ARCHITECT_PREFIX = (
        "You are a Senior Systems Architect and Principal Engineer.\n"
        "Your role is REASONING, PLANNING, and ARCHITECTURE DESIGN.\n"
        "Think step by step. Analyze deeply. Plan thoroughly.\n"
        "Output structured, clear plans — not implementation code.\n"
    )

    EXECUTOR_PREFIX = (
        "You are a Senior Software Engineer and Code Implementation Expert.\n"
        "Your role is IMPLEMENTATION and CODE GENERATION.\n"
        "Write clean, readable, production-ready code.\n"
        "Functions = verbs. Variables = nouns. Use guard clauses. Handle errors first.\n"
        "No trivial comments. No emojis. Focus on correctness and clarity.\n"
    )

    PRICING = PRICING
    FREE_PROVIDERS = (
        {
            "name": "opencode",
            "base_url": "https://opencode.ai/zen/v1",
            "api_key": "public",
            "models": [
                {"role": "architect", "model": "big-pickle"},
                {"role": "executor", "model": "deepseek-v4-flash-free"},
                {"role": "executor", "model": "qwen3.6-plus-free"},
                {"role": "executor", "model": "minimax-m2.5-free"},
                {"role": "executor", "model": "nemotron-3-super-free"},
            ],
        },
    )

    def __init__(self, config: dict[str, Any], memory) -> None:
        self._config = config
        self._memory = memory
        deepseek_key = config.get("__env__", {}).get("deepseek_key")
        models = config.get("models", {})
        self._architect_model = models.get("architect", {}).get("model", "deepseek-v4-pro")
        self._executor_model = models.get("executor", {}).get("model", "deepseek-v4-flash")
        self._architect_thinking = models.get("architect", {}).get("thinking", False)
        self._architect_thinking_mode = models.get("architect", {}).get("thinking_mode", "enabled")
        self._session_input_tokens = 0
        self._session_output_tokens = 0
        self._session_cost = 0.0
        self._last_provider = ""
        self._last_model = ""
        self._provider_usage: dict[str, int] = {}
        self._has_api_key = bool(deepseek_key)
        self._providers = self._build_providers(deepseek_key)
        self._client = self._providers[0]["client"] if self._providers else None
        _init_cost_tracking(self)

    @property
    def memory(self):
        return self._memory

    @property
    def config(self):
        return self._config

    @property
    def executor_model(self):
        return self._executor_model

    @property
    def has_api_key(self) -> bool:
        return self._has_api_key

    # ── Provider building ─────────────────────────────────────────

    def _build_providers(self, deepseek_key: str | None) -> list[dict[str, Any]]:
        from openai import OpenAI

        providers: list[dict[str, Any]] = []

        if deepseek_key:
            providers.append({
                "name": "deepseek",
                "client": OpenAI(api_key=deepseek_key, base_url="https://api.deepseek.com"),
                "architect_model": self._architect_model,
                "executor_model": self._executor_model,
                "supports_thinking": True,
            })

        free_config: dict[str, Any] = self._config.get("free_providers", {})
        for provider_def in self.FREE_PROVIDERS:
            name: str = str(provider_def["name"])
            configured: dict[str, Any] = free_config.get(name, {})
            base_url: str = str(configured.get("base_url", provider_def["base_url"]))
            api_key: str = str(provider_def["api_key"])
            client = OpenAI(api_key=api_key, base_url=base_url)
            model_list: list[dict[str, str]] = list(provider_def["models"])
            first_arch = next((m["model"] for m in model_list if m["role"] == "architect"), model_list[0]["model"])
            first_exec = next((m["model"] for m in model_list if m["role"] == "executor"), model_list[0]["model"])
            seen: set[tuple[str, str]] = set()
            for model_entry in model_list:
                role = model_entry["role"]
                model = model_entry["model"]
                arch_m = model if role == "architect" else first_arch
                exec_m = model if role == "executor" else first_exec
                key = (arch_m, exec_m)
                if key in seen:
                    continue
                seen.add(key)
                providers.append({
                    "name": name,
                    "client": client,
                    "architect_model": arch_m,
                    "executor_model": exec_m,
                    "supports_thinking": False,
                })
        return providers

    # ── Provider management ───────────────────────────────────────

    def list_providers(self) -> list[dict]:
        disabled = set(self._config.get("disabled_providers", []))
        seen: dict[str, dict] = {}
        for p in self._providers:
            name = p["name"]
            if name not in seen:
                seen[name] = {
                    "name": name,
                    "architect_model": p["architect_model"],
                    "executor_model": p["executor_model"],
                    "enabled": name not in disabled,
                    "supports_thinking": p.get("supports_thinking", False),
                    "last_used": self._last_provider == name,
                    "model_count": 1,
                }
            else:
                seen[name]["model_count"] += 1
        return list(seen.values())

    def toggle_provider(self, name: str) -> bool:
        disabled = set(self._config.get("disabled_providers", []))
        if name in disabled:
            disabled.discard(name)
            self._config["disabled_providers"] = list(disabled)
            self._save_provider_config()
            return True
        disabled.add(name)
        self._config["disabled_providers"] = list(disabled)
        self._save_provider_config()
        return False

    def enable_only(self, name: str) -> None:
        all_names = [p["name"] for p in self._providers]
        disabled = [n for n in all_names if n != name]
        self._config["disabled_providers"] = disabled
        self._save_provider_config()

    def enable_all(self) -> None:
        self._config.pop("disabled_providers", None)
        self._save_provider_config()

    def _save_provider_config(self) -> None:
        user_path = Path.home() / ".widdx" / "config.yaml"
        try:
            existing: dict[str, Any] = {}
            if user_path.exists():
                existing = yaml.safe_load(user_path.read_text(encoding="utf-8")) or {}
            disabled = self._config.get("disabled_providers", [])
            if disabled:
                existing["disabled_providers"] = disabled
            else:
                existing.pop("disabled_providers", None)
            user_path.parent.mkdir(parents=True, exist_ok=True)
            user_path.write_text(yaml.dump(existing, allow_unicode=True, default_flow_style=False), encoding="utf-8")
        except Exception:
            pass

    def _providers_for_role(self, role: str) -> list[dict[str, Any]]:
        forced_provider = self._config.get("provider")
        role_cfg = self._config.get("models", {}).get(role, {})
        forced_provider = role_cfg.get("provider", forced_provider)
        if forced_provider and forced_provider != "auto":
            selected = [p for p in self._providers if p["name"] == forced_provider]
            if selected:
                return selected
        disabled = set(self._config.get("disabled_providers", []))
        return [p for p in self._providers if p["name"] not in disabled]

    def _model_for_provider(self, provider: dict[str, Any], role: str) -> str:
        configured = self._config.get("models", {}).get(role, {}).get("model")
        if configured and provider["name"] == "deepseek":
            return str(configured)
        model = provider["architect_model"] if role == "architect" else provider["executor_model"]
        return str(model)

    def _remember_provider(self, provider_name: str, model: str) -> None:
        self._last_provider = provider_name
        self._last_model = model

    def _record_usage(self, provider_name: str, output_tokens: int) -> None:
        self._provider_usage[provider_name] = (
            self._provider_usage.get(provider_name, 0) + output_tokens
        )

    # ── Task classification ───────────────────────────────────────

    def classify(self, task_description: str) -> str:
        if self._providers:
            llm_result = self._classify_with_llm(task_description)
            if llm_result is not None:
                return llm_result
        return self._classify_with_keywords(task_description)

    def _classify_with_llm(self, task_description: str) -> str | None:
        for provider in self._providers_for_role("executor"):
            try:
                resp = provider["client"].chat.completions.create(
                    model=self._model_for_provider(provider, "executor"),
                    max_tokens=5,
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "You are a task classifier. Reply with exactly one word: "
                                "architect or executor.\n"
                                "architect = planning, design, review, analysis, architecture.\n"
                                "executor = coding, implementation, building, fixing, generating."
                            ),
                        },
                        {"role": "user", "content": task_description},
                    ],
                    temperature=0,
                )
                word = (resp.choices[0].message.content or "").strip().lower().split()[0]
                if word in ("architect", "executor"):
                    return word
            except Exception as e:
                logger.debug("LLM classification failed for provider %s: %s", provider['name'], e)
                continue
        return None

    def _classify_with_keywords(self, task_description: str) -> str:
        lowered = task_description.lower()
        arch_score = sum(1 for kw in self.ARCHITECT_KEYWORDS if kw in lowered)
        exec_score = sum(1 for kw in self.EXECUTOR_KEYWORDS if kw in lowered)
        if arch_score > exec_score:
            return "architect"
        if exec_score > arch_score:
            return "executor"
        stats = self._memory.routing_stats(self.infer_task_type(task_description))
        if stats:
            best = max(stats, key=lambda s: s["avg_score"])
            return str(best.get("model_selected", "executor"))
        return "executor"

    def infer_task_type(self, task: str) -> str:
        lowered = task.lower()
        if any(kw in lowered for kw in ["build", "create", "generate", "implement"]):
            return "build"
        if any(kw in lowered for kw in ["fix", "debug", "resolve"]):
            return "fix"
        if any(kw in lowered for kw in ["improve", "optimize", "refactor"]):
            return "improve"
        if any(kw in lowered for kw in ["design", "architecture", "plan"]):
            return "design"
        return "general"

    def _is_heavy_task(self, task: str) -> bool:
        lowered = task.lower()
        return any(kw in lowered for kw in _HEAVY_TASK_KEYWORDS)

    def _classify_executor_task(self, task: str) -> str:
        """Classify executor task type for model specialization (Plan B)."""
        lowered = task.lower()
        if any(kw in lowered for kw in ["algorithm", "logic", "complex", "calculate", "compute", "math"]):
            return "logic"
        if any(kw in lowered for kw in ["large file", "long context", "many files", "entire project", "full codebase"]):
            return "context"
        return "coding"

    # ── Core call with fallback chain ─────────────────────────────

    def _single_call(self, provider: dict, model: str, system_prompt: str,
                     user_message: str, max_tokens: int, role: str) -> dict:
        """Make a single API call. Returns result dict or raises."""
        start = time.perf_counter()
        kwargs: dict = dict(
            model=model,
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ],
        )
        if role == "architect" and self._architect_thinking and provider.get("supports_thinking"):
            thinking_type = (
                self._architect_thinking_mode
                if self._architect_thinking_mode in ("enabled", "thinking_max")
                else "enabled"
            )
            kwargs["extra_body"] = {"thinking": {"type": thinking_type}}

        resp = provider["client"].chat.completions.create(**kwargs)
        elapsed_ms = int((time.perf_counter() - start) * 1000)
        choice = resp.choices[0]

        # For thinking models, content may be in reasoning_content
        text = choice.message.content or ""
        reasoning = getattr(choice.message, "reasoning_content", "") or ""
        if not text and reasoning:
            text = reasoning

        result: dict = {
            "text": text,
            "model": model,
            "provider": provider["name"],
            "role": role,
            "latency_ms": elapsed_ms,
            "usage": {
                "input": resp.usage.prompt_tokens if resp.usage else 0,
                "output": resp.usage.completion_tokens if resp.usage else 0,
            },
        }
        self._remember_provider(provider["name"], model)
        self._record_usage(provider["name"], result["usage"]["output"])
        self._track_usage(model, result["usage"]["input"], result["usage"]["output"])
        if reasoning:
            result["reasoning_content"] = reasoning
        return result

    # ── Sequential call (Plan A: architect review, Plan B: architect chain) ──

    def _call_sequential(self, providers_models: list[tuple[dict, str]],
                         system_prompt: str, user_message: str,
                         max_tokens: int, role: str) -> dict:
        """Call providers sequentially, each reviewing the previous output.

        providers_models: list of (provider, model) tuples in order.
        """
        errors: list[str] = []
        last_result: dict | None = None

        for i, (provider, model) in enumerate(providers_models):
            prompt = system_prompt
            msg = user_message
            if last_result:
                # Add review context
                prev_text = last_result["text"][:4000]
                prompt = (
                    f"{system_prompt}\n\n"
                    f"Review and improve the following output:\n"
                    f"---\n{prev_text}\n---\n"
                    f"Provide your improved version with clear reasoning."
                )
                msg = "Review and improve the previous output."

            try:
                last_result = self._single_call(provider, model, prompt, msg, max_tokens, role)
                last_result["sequential_step"] = i + 1
                last_result["sequential_total"] = len(providers_models)
            except Exception as exc:
                errors.append(f"{provider['name']} ({model}): {exc}")
                # If primary failed, continue to next
                # If reviewer failed, return primary result
                if last_result:
                    last_result["review_skipped"] = True
                    last_result["review_error"] = str(exc)
                    return last_result
                continue

        if last_result:
            return last_result
        return {"error": "All sequential providers failed: " + " | ".join(errors)}

    # ── Parallel call (Plan A: heavy task execution) ──────────────

    def _call_parallel(self, primary: tuple[dict, str],
                       reviewer: tuple[dict, str],
                       system_prompt: str, user_message: str,
                       max_tokens: int, role: str) -> dict:
        """Execute primary and reviewer in parallel, then combine.

        Primary writes code, reviewer checks quality simultaneously.
        """
        results: dict[str, dict | None] = {"primary": None, "reviewer": None}
        errors: list[str] = []

        def _call(label: str, prov: dict, mdl: str) -> dict | None:
            try:
                return self._single_call(prov, mdl, system_prompt, user_message, max_tokens, role)
            except Exception as exc:
                errors.append(f"{label} ({prov['name']} {mdl}): {exc}")
                return None

        with ThreadPoolExecutor(max_workers=2) as pool:
            f_primary = pool.submit(_call, "primary", primary[0], primary[1])
            f_reviewer = pool.submit(_call, "reviewer", reviewer[0], reviewer[1])

            results["primary"] = f_primary.result(timeout=120)
            results["reviewer"] = f_reviewer.result(timeout=120)

        primary_result = results["primary"]
        reviewer_result = results["reviewer"]

        if primary_result:
            if reviewer_result:
                # Combine: primary output + reviewer feedback
                primary_result["review_text"] = reviewer_result.get("text", "")
                primary_result["review_model"] = reviewer_result.get("model", "")
                primary_result["parallel"] = True
            return primary_result

        if reviewer_result:
            reviewer_result["parallel_fallback"] = True
            return reviewer_result

        return {"error": "All parallel providers failed: " + " | ".join(errors)}

    # ── Unified call with intelligent routing ─────────────────────

    def _call_deepseek(self, system_prompt: str, user_message: str,
                       max_tokens: int = 8192, role: str = "executor") -> dict:
        if not self._providers:
            return {"error": "No AI provider available"}

        if role == "architect":
            return self._call_architect_intelligent(system_prompt, user_message, max_tokens)
        else:
            return self._call_executor_intelligent(system_prompt, user_message, max_tokens, user_message)

    def _call_architect_intelligent(self, system_prompt: str, user_message: str,
                                    max_tokens: int) -> dict:
        """PLAN A: deepseek-v4-pro → big-pickle (sequential review)
        PLAN B: big-pickle → qwen3.6-plus-free (sequential chain)
        """
        full_prompt = self.ARCHITECT_PREFIX + "\n" + system_prompt

        if self._has_api_key:
            # Plan A: Primary = deepseek-v4-pro, Fallback reviewer = big-pickle
            providers_models = []
            # Find deepseek provider
            for p in self._providers_for_role("architect"):
                if p["name"] == "deepseek":
                    providers_models.append((p, self._model_for_provider(p, "architect")))
                    break
            # Find big-pickle as reviewer
            for p in self._providers_for_role("architect"):
                if p["name"] != "deepseek" and p.get("architect_model") == "big-pickle":
                    providers_models.append((p, "big-pickle"))
                    break

            if len(providers_models) >= 2:
                return self._call_sequential(providers_models, full_prompt, user_message, max_tokens, "architect")
            elif providers_models:
                p, m = providers_models[0]
                try:
                    return self._single_call(p, m, full_prompt, user_message, max_tokens, "architect")
                except Exception as exc:
                    return {"error": f"Architect failed: {exc}"}
        else:
            # Plan B: big-pickle analyzes → qwen3.6-plus-free plans
            providers_models = []
            for p in self._providers_for_role("architect"):
                if p.get("architect_model") == "big-pickle":
                    providers_models.append((p, "big-pickle"))
                    break
            for p in self._providers_for_role("architect"):
                if p.get("architect_model") == "qwen3.6-plus-free":
                    providers_models.append((p, "qwen3.6-plus-free"))
                    break

            if len(providers_models) >= 2:
                return self._call_sequential(providers_models, full_prompt, user_message, max_tokens, "architect")
            elif providers_models:
                p, m = providers_models[0]
                try:
                    return self._single_call(p, m, full_prompt, user_message, max_tokens, "architect")
                except Exception as exc:
                    return {"error": f"Architect failed: {exc}"}

        return {"error": "No architect provider available"}

    def _call_executor_intelligent(self, system_prompt: str, user_message: str,
                                   max_tokens: int, raw_task: str) -> dict:
        """PLAN A: deepseek-v4-flash primary, parallel review for heavy tasks
        PLAN B: task-type based routing to specialized free models
        """
        full_prompt = self.EXECUTOR_PREFIX + "\n" + system_prompt
        is_heavy = self._is_heavy_task(raw_task)

        if self._has_api_key:
            # Plan A: Primary = deepseek-v4-flash
            primary_provider = None
            for p in self._providers_for_role("executor"):
                if p["name"] == "deepseek":
                    primary_provider = (p, self._model_for_provider(p, "executor"))
                    break

            if not primary_provider:
                return {"error": "No executor provider available"}

            # For heavy tasks: parallel execution with qwen3.6-plus-free review
            if is_heavy:
                reviewer_provider = None
                for p in self._providers_for_role("executor"):
                    if p.get("executor_model") == "qwen3.6-plus-free":
                        reviewer_provider = (p, "qwen3.6-plus-free")
                        break

                if reviewer_provider:
                    return self._call_parallel(primary_provider, reviewer_provider,
                                              full_prompt, user_message, max_tokens, "executor")

            # Normal task: direct call with fallback chain
            fallback_models = [
                "deepseek-v4-flash-free",
                "qwen3.6-plus-free",
                "minimax-m2.5-free",
                "nemotron-3-super-free",
            ]
            return self._call_with_fallback(full_prompt, user_message, max_tokens, "executor",
                                           [primary_provider], fallback_models)
        else:
            # Plan B: task-type based routing
            task_type = self._classify_executor_task(raw_task)
            model_for_type = {
                "coding": "deepseek-v4-flash-free",
                "context": "minimax-m2.5-free",
                "logic": "nemotron-3-super-free",
            }
            target_model = model_for_type.get(task_type, "deepseek-v4-flash-free")

            # Find the provider with this model
            for p in self._providers_for_role("executor"):
                if p.get("executor_model") == target_model:
                    try:
                        return self._single_call(p, target_model, full_prompt, user_message, max_tokens, "executor")
                    except Exception as exc:
                        logger.debug("Executor %s failed: %s", target_model, exc)
                        break

            # Fallback to next model in specialization order
            fallback_order = ["deepseek-v4-flash-free", "qwen3.6-plus-free",
                            "minimax-m2.5-free", "nemotron-3-super-free"]
            if target_model in fallback_order:
                fallback_order.remove(target_model)
                fallback_order.insert(0, target_model)

            for model_name in fallback_order:
                for p in self._providers_for_role("executor"):
                    if p.get("executor_model") == model_name:
                        try:
                            return self._single_call(p, model_name, full_prompt, user_message, max_tokens, "executor")
                        except Exception as exc:
                            logger.debug("Executor fallback %s failed: %s", model_name, exc)
                            break

        return {"error": "All executor providers failed"}

    def _call_with_fallback(self, system_prompt: str, user_message: str,
                            max_tokens: int, role: str,
                            primary_providers: list[tuple[dict, str]],
                            fallback_models: list[str]) -> dict:
        """Try primary providers first, then fallback chain."""
        errors: list[str] = []

        # Try primary providers
        for provider, model in primary_providers:
            try:
                return self._single_call(provider, model, system_prompt, user_message, max_tokens, role)
            except Exception as exc:
                errors.append(f"{provider['name']} ({model}): {exc}")
                logger.debug("Primary %s failed: %s", model, exc)

        # Try fallback models
        for model_name in fallback_models:
            for p in self._providers_for_role(role):
                if p.get("executor_model") == model_name or p.get("architect_model") == model_name:
                    try:
                        return self._single_call(p, model_name, system_prompt, user_message, max_tokens, role)
                    except Exception as exc:
                        errors.append(f"{p['name']} ({model_name}): {exc}")
                        logger.debug("Fallback %s failed: %s", model_name, exc)
                        break

        return {"error": "All providers failed: " + " | ".join(errors)}

    # ── Public API ────────────────────────────────────────────────

    def call_architect(self, system_prompt: str, user_message: str,
                       max_tokens: int = 8192) -> dict:
        return self._call_architect_intelligent(system_prompt, user_message, max_tokens)

    def call_executor(self, system_prompt: str, user_message: str,
                      max_tokens: int = 32768) -> dict:
        return self._call_executor_intelligent(system_prompt, user_message, max_tokens, user_message)

    def route(self, task_description: str, system_prompt: str,
              user_message: str) -> dict:
        classification = self.classify(task_description)
        if classification == "architect":
            result = self.call_architect(system_prompt, user_message)
        else:
            result = self.call_executor(system_prompt, user_message)

        if "error" not in result:
            self._memory.log_routing(
                task_type=self.infer_task_type(task_description),
                model_selected=result.get("role", "executor"),
                success_score=1.0,
                latency_ms=result.get("latency_ms", 0),
                tokens_used=(result.get("usage", {}).get("input", 0)
                             + result.get("usage", {}).get("output", 0)),
            )
        return result

    def _is_error_dict(self, result: dict) -> bool:
        return "error" in result

    # ── Cost tracking ─────────────────────────────────────────────

    @property
    def session_tokens(self) -> dict:
        return {"input": self._session_input_tokens,
                "output": self._session_output_tokens}

    @property
    def session_cost(self) -> float:
        return self._session_cost

    @property
    def is_ready(self) -> bool:
        return bool(self._providers)
