"""Router pricing — cost tracking and token estimation."""
from __future__ import annotations

# DeepSeek pricing per 1M tokens (April 2025)
PRICING = {
    "deepseek-v4-pro":    {"input": 0.55, "output": 2.19},
    "deepseek-v4-flash":  {"input": 0.27, "output": 1.10},
    "deepseek-v4-flash-free": {"input": 0.0, "output": 0.0},
    "big-pickle": {"input": 0.0, "output": 0.0},
    "kilo-auto/free": {"input": 0.0, "output": 0.0},
}


def _init_cost_tracking(self) -> None:
    self._session_input_tokens = 0
    self._session_output_tokens = 0
    self._session_cost = 0.0


def _track_usage(self, model: str, input_tokens: int, output_tokens: int) -> None:
    """Accumulate token usage and calculate cost."""
    self._session_input_tokens += input_tokens
    self._session_output_tokens += output_tokens
    pricing = PRICING.get(model, {"input": 0.27, "output": 1.10})
    cost = (
        (input_tokens / 1_000_000) * pricing["input"]
        + (output_tokens / 1_000_000) * pricing["output"]
    )
    self._session_cost += cost


def _estimate_tokens(self, messages: list[dict]) -> int:
    """Rough token estimate: characters / 4."""
    total_chars = 0
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            total_chars += len(content)
        for tc in msg.get("tool_calls", []):
            fn = tc.get("function", {})
            total_chars += len(fn.get("arguments", ""))
            total_chars += len(fn.get("name", ""))
    return total_chars // 4



