"""Git integration — status, diff, branches, smart commits."""
from __future__ import annotations

import subprocess
from pathlib import Path


class GitOps:
    """Safe git operations with output parsing."""

    def __init__(self, repo_path: str = ".") -> None:
        self._root = self._find_repo_root(Path(repo_path).resolve())

    @staticmethod
    def _find_repo_root(path: Path) -> Path | None:
        for parent in [path, *path.parents]:
            if (parent / ".git").exists():
                return parent
        return None

    @property
    def is_repo(self) -> bool:
        return self._root is not None

    def _run(self, *args: str) -> dict:
        if not self.is_repo:
            return {"error": "Not a git repository"}
        try:
            result = subprocess.run(
                ["git", "-C", str(self._root), *args],
                capture_output=True, text=True, timeout=30,
            )
            return {"ok": result.returncode == 0, "stdout": result.stdout.strip(), "stderr": result.stderr.strip()}
        except subprocess.TimeoutExpired:
            return {"error": "Git command timed out"}
        except FileNotFoundError:
            return {"error": "Git not found on this system"}

    def status(self) -> dict:
        r = self._run("status", "--porcelain")
        if r.get("error"):
            return r
        # split only when stdout is non-empty to avoid [""] from "".split("\n")
        lines = [l for l in r["stdout"].split("\n") if l.strip()] if r["stdout"] else []
        return {"ok": True, "changed": len(lines), "files": lines[:50]}

    def diff(self, staged: bool = False) -> dict:
        args = ["diff"]
        if staged:
            args.append("--staged")
        r = self._run(*args)
        if r.get("error"):
            return r
        return {"ok": True, "diff": r["stdout"][:5000]}

    def current_branch(self) -> str:
        r = self._run("branch", "--show-current")
        return r.get("stdout", "unknown") if r.get("ok") else "unknown"

    def create_branch(self, name: str) -> dict:
        return self._run("checkout", "-b", name)

    def commit(self, message: str, files: list[str] | None = None) -> dict:
        if files:
            self._run("add", *files)
        else:
            return {"error": "Specify files to commit. Never use 'git add .' blindly."}
        return self._run("commit", "-m", message)

    def log(self, count: int = 10) -> dict:
        r = self._run("log", f"-{count}", "--oneline", "--decorate")
        if r.get("error"):
            return r
        return {"ok": True, "log": r["stdout"]}
