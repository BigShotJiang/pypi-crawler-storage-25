# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "casedev"
__version__ = "0.56.0"  # x-release-please-version
