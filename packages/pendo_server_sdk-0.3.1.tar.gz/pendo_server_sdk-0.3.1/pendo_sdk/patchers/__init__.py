"""
Patcher Registry + Built-in Patchers

Extensible monkey-patching system for LLM client libraries. Each patcher
replaces a library's API call method with a wrapped version that opens
a GENERATION span automatically, capturing model name and token usage.

Architecture:
    register_patcher(name, patcher_fn)   — add a patcher to the registry
    patch_all()                          — run all registered patchers
    unpatch_all()                        — restore all originals

Built-in patchers:
    - anthropic: wraps Anthropic().messages.create (sync + async)
    - openai: wraps OpenAI().chat.completions.create (sync + async)

Patchers only activate if their library is importable. Missing libraries
are silently skipped — the SDK never crashes because a customer doesn't
have openai installed.
"""

from .registry import register_patcher, patch_all, unpatch_all, get_registry
from .anthropic import patch_anthropic
from .openai import patch_openai

# Register built-in patchers on import.
register_patcher("anthropic", patch_anthropic)
register_patcher("openai", patch_openai)

__all__ = [
    "register_patcher",
    "patch_all",
    "unpatch_all",
    "get_registry",
]
