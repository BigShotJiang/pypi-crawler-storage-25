from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from typing import Any, Generic

from typing_extensions import TypedDict, TypeVar

from .base import Sensor, SensorCategory, SensorType
from .motion import BoundingBox, Detection, VideoFrameData
from .spec import ModelSpec


class ClipEmbedding(TypedDict):
    """A CLIP embedding result for a detected region."""

    label: str
    box: BoundingBox
    embedding: list[float]


class ClipResult(TypedDict):
    """Return type for ClipDetectorSensor.detectEmbeddings()."""

    embeddings: list[ClipEmbedding]
    embeddingModel: str


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


class ClipDetectorSensor(Sensor[dict[str, Any], TStorage, str], Generic[TStorage]):
    """CLIP detector sensor that receives video frames and generates semantic embeddings.
    Implement detectEmbeddings() for CLIP embedding generation."""

    _requires_frames = True

    def __init__(self, name: str = "CLIP Sensor") -> None:
        super().__init__(name)

    @property
    def type(self) -> SensorType:
        return SensorType.Clip

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    @abstractmethod
    def modelSpec(self) -> ModelSpec:
        """Declares expected input dimensions and trigger labels."""
        ...

    @abstractmethod
    async def detectEmbeddings(self, frames: list[VideoFrameData]) -> list[ClipResult]:
        """Generate CLIP embeddings in batch. Each frame is a pre-cropped, pre-scaled trigger region.
        Must return exactly one ClipResult per input frame. Use frame['label'] for tagging."""
        ...
