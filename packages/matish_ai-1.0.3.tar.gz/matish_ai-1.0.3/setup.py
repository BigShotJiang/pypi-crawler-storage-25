from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="matish-ai",
    version="1.0.3",
    author="Даниил Неструев",
    description="Умный консольный AI помощник с памятью",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.6",
    install_requires=[
        "requests>=2.25.0",
        "keyboard>=0.13.5",
        "pyfiglet>=0.8.post1",
        "rich>=10.0.0",
        "urllib3>=1.26.0",
    ],
    entry_points={
        "console_scripts": [
            "matish=matish_ai.__main__:main",
        ],
    },
)