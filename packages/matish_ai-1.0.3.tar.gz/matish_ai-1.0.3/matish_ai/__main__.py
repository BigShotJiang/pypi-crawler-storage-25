#!/usr/bin/env python3
import json
import os
import requests
import base64
import urllib3
import sys
import keyboard
import pyfiglet
import platform
import time
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.text import Text
from rich.align import Align

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
console = Console(width=80)

# Универсальный путь для всех ОС
if platform.system() == "Windows":
    MASTER_DIR = os.path.join(os.environ.get('APPDATA', os.path.expanduser("~")), "Matish_Clean_v69")
else:
    MASTER_DIR = os.path.join(os.path.expanduser("~"), ".config", "Matish_Clean_v69")

if not os.path.exists(MASTER_DIR):
    os.makedirs(MASTER_DIR)
LOCAL_DB = os.path.join(MASTER_DIR, "brain.dat")

def crypt(t):
    return base64.b64encode(json.dumps(t, ensure_ascii=False).encode('utf-8')).decode('utf-8')

def decrypt(t):
    try:
        return json.loads(base64.b64decode(t.encode('utf-8')).decode('utf-8'))
    except:
        return {}

def save_db(db):
    with open(LOCAL_DB, "w", encoding="utf-8") as f:
        f.write(crypt(db))

def get_db():
    if os.path.exists(LOCAL_DB):
        with open(LOCAL_DB, "r", encoding="utf-8") as f:
            return decrypt(f.read())
    return {}

def clear_screen():
    os.system('cls' if platform.system() == "Windows" else 'clear')

def show_help():
    help_text = """
[bold magenta]ФУНКЦИОНАЛ AI MATISH[/bold magenta]

[bold cyan]LTM (Memory):[/bold cyan] Пиши [yellow]'запомни: [факт]'[/yellow]
[bold cyan]Vault:[/bold cyan] [yellow]'save: [текст]'[/yellow] / [yellow]'vault'[/yellow]
[bold cyan]Panic:[/bold cyan] [red]CTRL+B[/red]
[bold cyan]Help:[/bold cyan] [yellow]/help[/yellow] - показать это меню
[bold cyan]Show Memory:[/bold cyan] [yellow]/show_memory[/yellow] - показать воспоминания с номерами
[bold cyan]Delete Memory:[/bold cyan] [yellow]/del_memory [номер][/yellow] - удалить конкретное воспоминание
[bold cyan]Clear Memory:[/bold cyan] [yellow]/clear_memory[/yellow] - очистить ВСЕ воспоминания
"""
    console.print(Panel(help_text, title="[bold yellow]HELP MENU[/bold yellow]", border_style="cyan"))

def ask_ai(text, profile, history, retry_count=0):
    try:
        url = "https://text.pollinations.ai"
        gender_word = "парень" if profile.get("gender") == "м" else "девушка"
        
        system_msg = f"""Ты AI Matish - дружелюбный и умный виртуальный помощник.
Твой создатель: Даниил Неструев.
Информация о пользователе:
- Имя: {profile['real_name']}
- Возраст: {profile['age']} лет
- Пол: {gender_word}
- Хобби: {profile.get('hobby', 'разное')}

Воспоминания о пользователе: {profile['mem'] if profile['mem'] else 'пока нет'}

Твои особенности:
1. Отвечай кратко и по делу (1-2 предложения максимум)
2. Будь дружелюбным
3. Поддерживай диалог, задавай встречные вопросы
4. Если не знаешь ответа, честно скажи об этом

История разговора:
{chr(10).join(history[-8:]) if history else "Разговор только начинается"}

Сейчас пользователь спрашивает: {text}

Твой ответ:"""

        payload = {
            "messages": [
                {"role": "system", "content": system_msg},
                {"role": "user", "content": text}
            ],
            "model": "openai",
            "temperature": 0.8,
            "max_tokens": 150
        }
        
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Content-Type": "application/json"
        }
        
        res = requests.post(url, json=payload, headers=headers, timeout=15)
        
        if res.status_code == 429:
            if retry_count < 2:
                console.print("[yellow]API перегружен, жду 2 секунды...[/yellow]")
                time.sleep(2)
                return ask_ai(text, profile, history, retry_count + 1)
            else:
                return "Извини, сервер перегружен. Давай попробуем через минутку."
        
        elif res.status_code == 503:
            if retry_count < 2:
                console.print("[yellow]Сервер временно недоступен, жду 3 секунды...[/yellow]")
                time.sleep(3)
                return ask_ai(text, profile, history, retry_count + 1)
            else:
                return "Сервер временно недоступен. Давай позже продолжим."
        
        elif res.status_code != 200:
            return "Упс... Что-то пошло не так. Давай иначе спросим?"
        
        response_text = res.text.strip()
        
        if response_text.startswith('{') and 'error' in response_text:
            return "Служба временно занята, но я помню что ты спросил."
        
        if len(response_text) > 300:
            response_text = response_text[:297] + "..."
        
        return response_text if response_text else "Я слушаю. Продолжай."
        
    except requests.exceptions.Timeout:
        if retry_count < 2:
            console.print("[yellow]Таймаут, пробую еще раз...[/yellow]")
            time.sleep(1)
            return ask_ai(text, profile, history, retry_count + 1)
        return "Немного задержался с ответом. Что ты говорил?"
    
    except requests.exceptions.ConnectionError:
        if retry_count < 2:
            console.print("[yellow]Проблема с интернетом, жду 2 секунды...[/yellow]")
            time.sleep(2)
            return ask_ai(text, profile, history, retry_count + 1)
        return "Интернет барахлит. Проверь соединение."
    
    except Exception as e:
        if retry_count < 1:
            return ask_ai(text, profile, history, retry_count + 1)
        return f"Ошибка: {str(e)[:100]}"

def panic_exit():
    os._exit(0)

def auth():
    clear_screen()
    console.print(Align.center(Text(pyfiglet.Figlet(font='slant').renderText('MATISH AI'), style="bold magenta")))
    db = get_db()
    name = Prompt.ask("[bold magenta]┌──[/bold magenta][bold white] LOGIN[/bold white]").strip() or "DeLtA"
    is_delta = (name.lower() == "delta")
    
    if name in db:
        profile = db[name]
        pwd = Prompt.ask(f"[bold magenta]└──[/bold magenta][bold yellow] PASSWORD[/bold yellow]").strip()
        if str(profile.get("pass")) == str(pwd):
            return profile, is_delta, db
        else:
            sys.exit("Неверный пароль.")
    else:
        console.print(Panel("РЕГИСТРАЦИЯ НОВОГО ЯДРА", border_style="yellow"))
        pwd = Prompt.ask("[bold green]PASS[/bold green]").strip()
        r_name = Prompt.ask("[cyan]Имя[/cyan]").strip() or "Даня"
        age = Prompt.ask("[cyan]Лет[/cyan]").strip() or "12"
        gender = Prompt.ask("[cyan]Пол (м/ж)[/cyan]", choices=["м", "ж"])
        hobby = Prompt.ask("[cyan]Хобби[/cyan]").strip() or "кодинг"
        profile = {
            "name": name,
            "pass": pwd,
            "real_name": r_name,
            "age": age,
            "gender": gender,
            "hobby": hobby,
            "mem": "",
            "vault": []
        }
        db[name] = profile
        save_db(db)
        show_help()
        input("\nНажми Enter для запуска...")
    
    return profile, is_delta, db

def main():
    try:
        profile, is_delta, db = auth()
        clear_screen()
        console.print(Align.center(pyfiglet.Figlet(font='slant').renderText('MATISH AI')))
        status = "[black on white] ROOT: DANIIL NESTRUEV [/black on white]" if is_delta else f"[bold white] USER: {profile['name']} [/bold white]"
        console.print(Align.center(Panel(status, border_style="magenta", expand=False)))
        chat_hist = []
        
        keyboard.add_hotkey('ctrl+b', panic_exit)
        
        console.print(Panel("[cyan]Привет! Я Matish AI\nЗадавай вопросы или используй /help для помощи[/cyan]", 
                          title="[bold green]START[/bold green]", border_style="green"))
        
        while True:
            try:
                cmd = console.input(f"\n[bold white]{profile['name']}@matish[/bold white]:~[bold red]{'#' if is_delta else '$'}[/bold red] ").strip()
                
                if not cmd or cmd.lower() in ['exit', 'q']:
                    break
                
                if cmd.lower() == '/help':
                    show_help()
                    continue
                
                if cmd.lower() == '/show_memory':
                    if profile["mem"]:
                        memories = [m.strip() for m in profile["mem"].split(";") if m.strip()]
                        if memories:
                            mem_text = ""
                            for i, mem in enumerate(memories, 1):
                                mem_text += f"[cyan]{i}.[/cyan] {mem}\n"
                            console.print(Panel(mem_text, title=f"MEMORY ({len(memories)} воспоминаний)", border_style="green"))
                        else:
                            console.print(Panel("[yellow]Воспоминаний пока нет.[/yellow]", title="MEMORY", border_style="yellow"))
                    else:
                        console.print(Panel("[yellow]Воспоминаний пока нет.[/yellow]", title="MEMORY", border_style="yellow"))
                    continue
                
                if cmd.lower().startswith('/del_memory'):
                    try:
                        parts = cmd.split()
                        if len(parts) < 2:
                            console.print("[red]Укажи номер воспоминания. Пример: /del_memory 3[/red]")
                            continue
                        
                        num = int(parts[1]) - 1
                        memories = [m.strip() for m in profile["mem"].split(";") if m.strip()]
                        
                        if num < 0 or num >= len(memories):
                            console.print(f"[red]Воспоминание с номером {num+1} не найдено. Всего воспоминаний: {len(memories)}[/red]")
                            continue
                        
                        deleted = memories[num]
                        console.print(f"[yellow]Удаляем:[/yellow] {deleted}")
                        confirm = Prompt.ask("[bold red]Точно удалить? (да/нет)[/bold red]", choices=["да", "нет"])
                        
                        if confirm == "да":
                            memories.pop(num)
                            profile["mem"] = "; ".join(memories) + (";" if memories else "")
                            save_db(db)
                            console.print(f"[bold green]Воспоминание удалено![/bold green] Осталось воспоминаний: {len(memories)}")
                        else:
                            console.print("[dim]Отмена удаления.[/dim]")
                    except ValueError:
                        console.print("[red]Некорректный номер. Используй число.[/red]")
                    except Exception as e:
                        console.print(f"[red]Ошибка: {e}[/red]")
                    continue
                
                if cmd.lower() == '/clear_memory':
                    console.print(Panel("[yellow]ВНИМАНИЕ! Это удалит ВСЕ воспоминания![/yellow]", border_style="red"))
                    confirm = Prompt.ask("[bold red]Ты уверен? (да/нет)[/bold red]", choices=["да", "нет"])
                    if confirm == "да":
                        profile["mem"] = ""
                        save_db(db)
                        console.print(Panel("[bold green]ВСЕ ВОСПОМИНАНИЯ УДАЛЕНЫ![/bold green]\n[italic]Теперь ты как чистый лист, можно начинать заново![/italic]", border_style="green"))
                    else:
                        console.print("[dim]Отмена очистки.[/dim]")
                    continue
                
                if cmd.lower().startswith("запомни:"):
                    profile["mem"] += f" {cmd[8:].strip()};"
                    save_db(db)
                    console.print("[dim green]Запомнил.[/dim green]")
                    continue
                
                if cmd.lower().startswith("save:"):
                    profile["vault"].append(cmd[5:].strip())
                    save_db(db)
                    console.print("[dim cyan]В сейфе.[/dim cyan]")
                    continue
                
                if cmd.lower() == "vault":
                    if profile["vault"]:
                        vault_text = "\n".join([f"[cyan]{i+1}.[/cyan] {item}" for i, item in enumerate(profile["vault"])])
                        console.print(Panel(vault_text, title="VAULT", border_style="cyan"))
                    else:
                        console.print(Panel("Пусто.", title="VAULT", border_style="cyan"))
                    continue
                
                with console.status("[bold yellow]Матиш думает..."):
                    reply = ask_ai(cmd, profile, chat_hist)
                
                chat_hist.append(f"User: {cmd}")
                chat_hist.append(f"Matish: {reply}")
                console.print(Panel(reply, title="[bold cyan]MATISH[/bold cyan]", border_style="cyan"))
            
            except KeyboardInterrupt:
                console.print("\n[yellow]Нажми CTRL+B для выхода или введи 'exit'[/yellow]")
                continue
    
    except KeyboardInterrupt:
        panic_exit()

if __name__ == "__main__":
    main()