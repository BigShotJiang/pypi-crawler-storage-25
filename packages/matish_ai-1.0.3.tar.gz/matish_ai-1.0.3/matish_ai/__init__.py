__version__ = "1.0.3"
__author__ = "Даниил Неструев"

from .__main__ import main