from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from pydantic import BaseModel, Field


class SendEmailRequest(BaseModel):
    to: Union[str, List[str]]
    subject: str
    html: str
    from_email: Optional[str] = Field(None, alias="from")
    text: Optional[str] = None
    template_id: Optional[str] = None
    variables: Optional[Dict[str, Any]] = None
    stream_id: Optional[str] = None
    tags: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None
    idempotency_key: Optional[str] = None
    analyze_content: Optional[bool] = False


class SendEmailResponse(BaseModel):
    id: str
    status: str
    message_id: Optional[str] = None
    created_at: str


class Server(BaseModel):
    id: str
    name: str
    token: str
    created_at: str
    updated_at: str


class MessageStream(BaseModel):
    id: str
    server_id: str
    name: str
    slug: Optional[str] = None
    description: Optional[str] = None
    type: str
    created_at: str


class Template(BaseModel):
    id: str
    server_id: str
    name: str
    subject: str
    html: str
    variables: List[str]
    created_at: str
    updated_at: str


class Webhook(BaseModel):
    id: str
    stream_id: str
    url: str
    events: List[str]
    active: bool
    secret: Optional[str] = None
    created_at: str
    updated_at: str


class WebhookLog(BaseModel):
    id: str
    webhook_id: str
    event_type: str
    payload: Dict[str, Any]
    status_code: Optional[int] = None
    response: Optional[str] = None
    error: Optional[str] = None
    attempt: int
    next_retry_at: Optional[str] = None
    delivered_at: Optional[str] = None
    created_at: str


class Message(BaseModel):
    id: str
    stream_id: str
    to: str
    from_email: Optional[str] = Field(None, alias="from")
    subject: str
    html: str
    status: str
    external_message_id: Optional[str] = None
    template_id: Optional[str] = None
    identity_id: Optional[str] = None
    route_id: Optional[str] = None
    route_name: Optional[str] = None
    ip_used: Optional[str] = None
    send_attempts: int
    latency_ms: Optional[int] = None
    failure_reason: Optional[str] = None
    routing_reason: Optional[str] = None
    created_at: str
    sent_at: Optional[str] = None


class Event(BaseModel):
    id: str
    message_id: str
    type: str
    metadata: Optional[Dict[str, Any]] = None
    timestamp: str


class ApiKey(BaseModel):
    id: str
    name: str
    active: bool
    key_preview: str
    expires_at: Optional[str] = None
    last_used_at: Optional[str] = None
    created_at: str
    revoked_at: Optional[str] = None


class Issue(BaseModel):
    severity: str
    message: str
    suggestion: str


class ContentAnalysis(BaseModel):
    spam_score: int
    html_score: int
    link_score: int
    overall_score: int
    issues: List[Issue]
    recommendations: List[str]


class AnalyticsOverview(BaseModel):
    total_sent: int
    delivery_rate: float
    bounce_rate: float
    avg_latency: int
