from typing import Optional, Any


class PostjectError(Exception):
    """Base exception for all Postject errors"""

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        code: Optional[str] = None,
        response: Optional[Any] = None,
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code
        self.response = response


class AuthenticationError(PostjectError):
    """Raised when authentication fails (401)"""

    def __init__(self, message: str = "Authentication failed"):
        super().__init__(message, status_code=401, code="AUTHENTICATION_ERROR")


class RateLimitError(PostjectError):
    """Raised when rate limit is exceeded (429)"""

    def __init__(
        self,
        message: str,
        retry_after: Optional[int] = None,
        reset_at: Optional[str] = None,
    ):
        super().__init__(message, status_code=429, code="RATE_LIMIT_ERROR")
        self.retry_after = retry_after
        self.reset_at = reset_at


class ValidationError(PostjectError):
    """Raised when request validation fails (400)"""

    def __init__(self, message: str, response: Optional[Any] = None):
        super().__init__(message, status_code=400, code="VALIDATION_ERROR", response=response)


class NotFoundError(PostjectError):
    """Raised when resource is not found (404)"""

    def __init__(self, message: str):
        super().__init__(message, status_code=404, code="NOT_FOUND")


class ServerError(PostjectError):
    """Raised when server error occurs (5xx)"""

    def __init__(self, message: str, status_code: int = 500):
        super().__init__(message, status_code=status_code, code="SERVER_ERROR")
