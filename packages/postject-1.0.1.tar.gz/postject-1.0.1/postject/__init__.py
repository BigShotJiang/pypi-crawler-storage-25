"""Postject Python SDK"""

__version__ = "1.0.1"

from .client import Postject
from .errors import (
    PostjectError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    NotFoundError,
    ServerError,
)
from .types import (
    SendEmailRequest,
    SendEmailResponse,
    Server,
    MessageStream,
    Template,
    Webhook,
    WebhookLog,
    Message,
    Event,
    ApiKey,
    ContentAnalysis,
)

__all__ = [
    "Postject",
    "PostjectError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "ServerError",
    "SendEmailRequest",
    "SendEmailResponse",
    "Server",
    "MessageStream",
    "Template",
    "Webhook",
    "WebhookLog",
    "Message",
    "Event",
    "ApiKey",
    "ContentAnalysis",
]
