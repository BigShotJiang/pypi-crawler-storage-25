r'''
# Amazon Aurora DSQL Construct Library

<!--BEGIN STABILITY BANNER-->---


![cdk-constructs: Experimental](https://img.shields.io/badge/cdk--constructs-experimental-important.svg?style=for-the-badge)

> The APIs of higher level constructs in this module are experimental and under active development.
> They are subject to non-backward compatible changes or removal in any future version. These are
> not subject to the [Semantic Versioning](https://semver.org/) model and breaking changes will be
> announced in the release notes. This means that while you may use them, you may need to update
> your source code when upgrading to a newer version of this package.

---
<!--END STABILITY BANNER-->

Amazon Aurora DSQL is a serverless, distributed relational database service optimized for transactional workloads. Aurora DSQL offers virtually unlimited scale and doesn't require you to manage infrastructure. The active-active highly available architecture provides 99.99% single-Region and 99.999% multi-Region availability.

The `@aws-cdk/aws-dsql-alpha` package contains primitives for setting up Aurora DSQL clusters.

```python
import aws_cdk.aws_dsql_alpha as dsql
```

## Creating an Aurora DSQL Cluster

To create an Aurora DSQL cluster, define a `Cluster`:

```python
cluster = dsql.Cluster(self, "Cluster",
    cluster_name="my-dsql-cluster",
    deletion_protection=True
)
```

## Granting Connect Access

You can grant IAM principals the ability to connect to the cluster:

```python
role = iam.Role(self, "DBRole", assumed_by=iam.AccountPrincipal(self.account))
cluster = dsql.Cluster(self, "Cluster")

# Use one of the following statements to grant the role the necessary permissions
cluster.grant_connect(role) # Grant the role dsql:DbConnect
cluster.grant_connect_admin(role) # Grant the role dsql:DbConnectAdmin
cluster.grant(role, "dsql:DbConnect")
```
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_iam as _aws_cdk_aws_iam_ceddda9d
import constructs as _constructs_77d1e7e8


@jsii.data_type(
    jsii_type="@aws-cdk/aws-dsql-alpha.ClusterAttributes",
    jsii_struct_bases=[],
    name_mapping={
        "cluster_endpoint": "clusterEndpoint",
        "cluster_identifier": "clusterIdentifier",
        "vpc_endpoint_service_name": "vpcEndpointServiceName",
    },
)
class ClusterAttributes:
    def __init__(
        self,
        *,
        cluster_endpoint: builtins.str,
        cluster_identifier: builtins.str,
        vpc_endpoint_service_name: builtins.str,
    ) -> None:
        '''(experimental) Properties that describe an existing Aurora DSQL cluster.

        :param cluster_endpoint: (experimental) Connection endpoint for the cluster.
        :param cluster_identifier: (experimental) Identifier of the cluster.
        :param vpc_endpoint_service_name: (experimental) VPC endpoint service name for the cluster.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_dsql_alpha as dsql_alpha
            
            cluster_attributes = dsql_alpha.ClusterAttributes(
                cluster_endpoint="clusterEndpoint",
                cluster_identifier="clusterIdentifier",
                vpc_endpoint_service_name="vpcEndpointServiceName"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__16b52dffa0e4253cc4656e38aa29a0b2b7a2543161f2fd4a7216e895400a176a)
            check_type(argname="argument cluster_endpoint", value=cluster_endpoint, expected_type=type_hints["cluster_endpoint"])
            check_type(argname="argument cluster_identifier", value=cluster_identifier, expected_type=type_hints["cluster_identifier"])
            check_type(argname="argument vpc_endpoint_service_name", value=vpc_endpoint_service_name, expected_type=type_hints["vpc_endpoint_service_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "cluster_endpoint": cluster_endpoint,
            "cluster_identifier": cluster_identifier,
            "vpc_endpoint_service_name": vpc_endpoint_service_name,
        }

    @builtins.property
    def cluster_endpoint(self) -> builtins.str:
        '''(experimental) Connection endpoint for the cluster.

        :stability: experimental
        '''
        result = self._values.get("cluster_endpoint")
        assert result is not None, "Required property 'cluster_endpoint' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def cluster_identifier(self) -> builtins.str:
        '''(experimental) Identifier of the cluster.

        :stability: experimental
        '''
        result = self._values.get("cluster_identifier")
        assert result is not None, "Required property 'cluster_identifier' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def vpc_endpoint_service_name(self) -> builtins.str:
        '''(experimental) VPC endpoint service name for the cluster.

        :stability: experimental
        '''
        result = self._values.get("vpc_endpoint_service_name")
        assert result is not None, "Required property 'vpc_endpoint_service_name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ClusterAttributes(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-dsql-alpha.ClusterProps",
    jsii_struct_bases=[],
    name_mapping={
        "cluster_name": "clusterName",
        "deletion_protection": "deletionProtection",
        "removal_policy": "removalPolicy",
    },
)
class ClusterProps:
    def __init__(
        self,
        *,
        cluster_name: typing.Optional[builtins.str] = None,
        deletion_protection: typing.Optional[builtins.bool] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
    ) -> None:
        '''(experimental) Properties for a new Aurora DSQL cluster.

        :param cluster_name: (experimental) The name of the DSQL cluster. This is applied via the ``Name`` tag. Default: - No name specified.
        :param deletion_protection: (experimental) Specifies whether this cluster can be deleted. If deletionProtection is enabled, the cluster cannot be deleted unless it is modified and deletionProtection is disabled. deletionProtection protects clusters from being accidentally deleted. Default: - true if ``removalPolicy`` is RETAIN, undefined otherwise.
        :param removal_policy: (experimental) The removal policy to apply when the cluster is removed or replaced during a stack update, or when the stack is deleted. Default: - Retain cluster.

        :stability: experimental
        :exampleMetadata: infused

        Example::

            cluster = dsql.Cluster(self, "Cluster",
                cluster_name="my-dsql-cluster",
                deletion_protection=True
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2275b4a747a3cd132ad69bb5742f281675224d1c252675205c3c5b02510009a5)
            check_type(argname="argument cluster_name", value=cluster_name, expected_type=type_hints["cluster_name"])
            check_type(argname="argument deletion_protection", value=deletion_protection, expected_type=type_hints["deletion_protection"])
            check_type(argname="argument removal_policy", value=removal_policy, expected_type=type_hints["removal_policy"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if cluster_name is not None:
            self._values["cluster_name"] = cluster_name
        if deletion_protection is not None:
            self._values["deletion_protection"] = deletion_protection
        if removal_policy is not None:
            self._values["removal_policy"] = removal_policy

    @builtins.property
    def cluster_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name of the DSQL cluster.

        This is applied via the ``Name`` tag.

        :default: - No name specified.

        :stability: experimental
        '''
        result = self._values.get("cluster_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def deletion_protection(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Specifies whether this cluster can be deleted.

        If deletionProtection is
        enabled, the cluster cannot be deleted unless it is modified and
        deletionProtection is disabled. deletionProtection protects clusters from
        being accidentally deleted.

        :default: - true if ``removalPolicy`` is RETAIN, undefined otherwise.

        :stability: experimental
        '''
        result = self._values.get("deletion_protection")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def removal_policy(self) -> typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"]:
        '''(experimental) The removal policy to apply when the cluster is removed or replaced during a stack update, or when the stack is deleted.

        :default: - Retain cluster.

        :stability: experimental
        '''
        result = self._values.get("removal_policy")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ClusterProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.interface(jsii_type="@aws-cdk/aws-dsql-alpha.ICluster")
class ICluster(_aws_cdk_ceddda9d.IResource, typing_extensions.Protocol):
    '''(experimental) Represents an Aurora DSQL cluster.

    :stability: experimental
    '''

    @builtins.property
    @jsii.member(jsii_name="clusterArn")
    def cluster_arn(self) -> builtins.str:
        '''(experimental) Arn of the cluster.

        :stability: experimental
        :attribute: ResourceArn
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="clusterEndpoint")
    def cluster_endpoint(self) -> builtins.str:
        '''(experimental) Connection endpoint for the cluster.

        :stability: experimental
        :attribute: Endpoint
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="clusterIdentifier")
    def cluster_identifier(self) -> builtins.str:
        '''(experimental) Identifier of the cluster.

        :stability: experimental
        :attribute: Identifier
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="vpcEndpointServiceName")
    def vpc_endpoint_service_name(self) -> builtins.str:
        '''(experimental) VPC endpoint service name for the cluster.

        :stability: experimental
        :attribute: VpcEndpointServiceName
        '''
        ...

    @jsii.member(jsii_name="grant")
    def grant(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        *actions: builtins.str,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity the specified actions.

        :param grantee: the identity to be granted the actions.
        :param actions: the data-access actions.

        :see:

        https://docs.aws.amazon.com/aurora-dsql/latest/userguide/authentication-authorization.html

        [disable-awslint:no-grants]
        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="grantConnect")
    def grant_connect(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity permission to connect to the database.

        [disable-awslint:no-grants]

        :param grantee: -

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="grantConnectAdmin")
    def grant_connect_admin(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity permission to connect to the database with admin role.

        [disable-awslint:no-grants]

        :param grantee: -

        :stability: experimental
        '''
        ...


class _IClusterProxy(
    jsii.proxy_for(_aws_cdk_ceddda9d.IResource), # type: ignore[misc]
):
    '''(experimental) Represents an Aurora DSQL cluster.

    :stability: experimental
    '''

    __jsii_type__: typing.ClassVar[str] = "@aws-cdk/aws-dsql-alpha.ICluster"

    @builtins.property
    @jsii.member(jsii_name="clusterArn")
    def cluster_arn(self) -> builtins.str:
        '''(experimental) Arn of the cluster.

        :stability: experimental
        :attribute: ResourceArn
        '''
        return typing.cast(builtins.str, jsii.get(self, "clusterArn"))

    @builtins.property
    @jsii.member(jsii_name="clusterEndpoint")
    def cluster_endpoint(self) -> builtins.str:
        '''(experimental) Connection endpoint for the cluster.

        :stability: experimental
        :attribute: Endpoint
        '''
        return typing.cast(builtins.str, jsii.get(self, "clusterEndpoint"))

    @builtins.property
    @jsii.member(jsii_name="clusterIdentifier")
    def cluster_identifier(self) -> builtins.str:
        '''(experimental) Identifier of the cluster.

        :stability: experimental
        :attribute: Identifier
        '''
        return typing.cast(builtins.str, jsii.get(self, "clusterIdentifier"))

    @builtins.property
    @jsii.member(jsii_name="vpcEndpointServiceName")
    def vpc_endpoint_service_name(self) -> builtins.str:
        '''(experimental) VPC endpoint service name for the cluster.

        :stability: experimental
        :attribute: VpcEndpointServiceName
        '''
        return typing.cast(builtins.str, jsii.get(self, "vpcEndpointServiceName"))

    @jsii.member(jsii_name="grant")
    def grant(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        *actions: builtins.str,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity the specified actions.

        :param grantee: the identity to be granted the actions.
        :param actions: the data-access actions.

        :see:

        https://docs.aws.amazon.com/aurora-dsql/latest/userguide/authentication-authorization.html

        [disable-awslint:no-grants]
        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f6804627ace36b9a22565df224d9b0fbf23a5035df3c88021806f41f7a13229)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument actions", value=actions, expected_type=typing.Tuple[type_hints["actions"], ...]) # pyright: ignore [reportGeneralTypeIssues]
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grant", [grantee, *actions]))

    @jsii.member(jsii_name="grantConnect")
    def grant_connect(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity permission to connect to the database.

        [disable-awslint:no-grants]

        :param grantee: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__507214778f3341301676eaa23e2dccf060eee28603f55e79913ef117e233b3d3)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantConnect", [grantee]))

    @jsii.member(jsii_name="grantConnectAdmin")
    def grant_connect_admin(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity permission to connect to the database with admin role.

        [disable-awslint:no-grants]

        :param grantee: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c0e403df31a59a87ffc10921e3de5745221afdee33a0c73d483499f2a21dd4a3)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantConnectAdmin", [grantee]))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, ICluster).__jsii_proxy_class__ = lambda : _IClusterProxy


@jsii.implements(ICluster)
class Cluster(
    _aws_cdk_ceddda9d.Resource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-dsql-alpha.Cluster",
):
    '''(experimental) Create an Aurora DSQL cluster.

    :stability: experimental
    :resource: AWS::DSQL::Cluster
    :exampleMetadata: infused

    Example::

        cluster = dsql.Cluster(self, "Cluster",
            cluster_name="my-dsql-cluster",
            deletion_protection=True
        )
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        cluster_name: typing.Optional[builtins.str] = None,
        deletion_protection: typing.Optional[builtins.bool] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param cluster_name: (experimental) The name of the DSQL cluster. This is applied via the ``Name`` tag. Default: - No name specified.
        :param deletion_protection: (experimental) Specifies whether this cluster can be deleted. If deletionProtection is enabled, the cluster cannot be deleted unless it is modified and deletionProtection is disabled. deletionProtection protects clusters from being accidentally deleted. Default: - true if ``removalPolicy`` is RETAIN, undefined otherwise.
        :param removal_policy: (experimental) The removal policy to apply when the cluster is removed or replaced during a stack update, or when the stack is deleted. Default: - Retain cluster.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee981d227dfd6b2b8df8a7c6df16736f1c2194858952feb0db8fa8cd776a0a49)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = ClusterProps(
            cluster_name=cluster_name,
            deletion_protection=deletion_protection,
            removal_policy=removal_policy,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="fromClusterAttributes")
    @builtins.classmethod
    def from_cluster_attributes(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        cluster_endpoint: builtins.str,
        cluster_identifier: builtins.str,
        vpc_endpoint_service_name: builtins.str,
    ) -> "ICluster":
        '''(experimental) Import an existing Cluster from attributes.

        :param scope: -
        :param id: -
        :param cluster_endpoint: (experimental) Connection endpoint for the cluster.
        :param cluster_identifier: (experimental) Identifier of the cluster.
        :param vpc_endpoint_service_name: (experimental) VPC endpoint service name for the cluster.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a3f17d10666024ef42d79192c98f66876b3514a4695f33d9035957b993576a7)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        attrs = ClusterAttributes(
            cluster_endpoint=cluster_endpoint,
            cluster_identifier=cluster_identifier,
            vpc_endpoint_service_name=vpc_endpoint_service_name,
        )

        return typing.cast("ICluster", jsii.sinvoke(cls, "fromClusterAttributes", [scope, id, attrs]))

    @jsii.member(jsii_name="grant")
    def grant(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        *actions: builtins.str,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity the specified actions.

        :param grantee: -
        :param actions: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b5145b98daff5971b5c01443312cfd2591552ccd229ea54a79cdff06f094d2f)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument actions", value=actions, expected_type=typing.Tuple[type_hints["actions"], ...]) # pyright: ignore [reportGeneralTypeIssues]
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grant", [grantee, *actions]))

    @jsii.member(jsii_name="grantConnect")
    def grant_connect(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity permission to connect to the database.

        [disable-awslint:no-grants]

        :param grantee: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__297bb62aecb8b23116496c32647b99fe4ed53dd95defaf5a87e8a5a282088152)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantConnect", [grantee]))

    @jsii.member(jsii_name="grantConnectAdmin")
    def grant_connect_admin(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity permission to connect to the database with admin role.

        [disable-awslint:no-grants]

        :param grantee: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b4a218934de7487b7c48b5cc1ea787db08c3327ec959098e0f2d5b9f0810f9fd)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "grantConnectAdmin", [grantee]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_INJECTION_ID")
    def PROPERTY_INJECTION_ID(cls) -> builtins.str:
        '''(experimental) Uniquely identifies this class.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_INJECTION_ID"))

    @builtins.property
    @jsii.member(jsii_name="clusterArn")
    def cluster_arn(self) -> builtins.str:
        '''(experimental) Arn of the cluster.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "clusterArn"))

    @builtins.property
    @jsii.member(jsii_name="clusterEndpoint")
    def cluster_endpoint(self) -> builtins.str:
        '''(experimental) Connection endpoint for the cluster.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "clusterEndpoint"))

    @builtins.property
    @jsii.member(jsii_name="clusterIdentifier")
    def cluster_identifier(self) -> builtins.str:
        '''(experimental) Identifier of the cluster.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "clusterIdentifier"))

    @builtins.property
    @jsii.member(jsii_name="vpcEndpointServiceName")
    def vpc_endpoint_service_name(self) -> builtins.str:
        '''(experimental) VPC endpoint service name for the cluster.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "vpcEndpointServiceName"))


__all__ = [
    "Cluster",
    "ClusterAttributes",
    "ClusterProps",
    "ICluster",
]

publication.publish()

def _typecheckingstub__16b52dffa0e4253cc4656e38aa29a0b2b7a2543161f2fd4a7216e895400a176a(
    *,
    cluster_endpoint: builtins.str,
    cluster_identifier: builtins.str,
    vpc_endpoint_service_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2275b4a747a3cd132ad69bb5742f281675224d1c252675205c3c5b02510009a5(
    *,
    cluster_name: typing.Optional[builtins.str] = None,
    deletion_protection: typing.Optional[builtins.bool] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f6804627ace36b9a22565df224d9b0fbf23a5035df3c88021806f41f7a13229(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    *actions: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__507214778f3341301676eaa23e2dccf060eee28603f55e79913ef117e233b3d3(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c0e403df31a59a87ffc10921e3de5745221afdee33a0c73d483499f2a21dd4a3(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee981d227dfd6b2b8df8a7c6df16736f1c2194858952feb0db8fa8cd776a0a49(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    cluster_name: typing.Optional[builtins.str] = None,
    deletion_protection: typing.Optional[builtins.bool] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a3f17d10666024ef42d79192c98f66876b3514a4695f33d9035957b993576a7(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    cluster_endpoint: builtins.str,
    cluster_identifier: builtins.str,
    vpc_endpoint_service_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b5145b98daff5971b5c01443312cfd2591552ccd229ea54a79cdff06f094d2f(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    *actions: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__297bb62aecb8b23116496c32647b99fe4ed53dd95defaf5a87e8a5a282088152(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b4a218934de7487b7c48b5cc1ea787db08c3327ec959098e0f2d5b9f0810f9fd(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
) -> None:
    """Type checking stubs"""
    pass

for cls in [ICluster]:
    typing.cast(typing.Any, cls).__protocol_attrs__ = typing.cast(typing.Any, cls).__protocol_attrs__ - set(['__jsii_proxy_class__', '__jsii_type__'])
