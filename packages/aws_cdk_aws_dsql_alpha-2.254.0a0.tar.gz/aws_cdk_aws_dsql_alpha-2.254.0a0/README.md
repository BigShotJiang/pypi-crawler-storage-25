# Amazon Aurora DSQL Construct Library

<!--BEGIN STABILITY BANNER-->---


![cdk-constructs: Experimental](https://img.shields.io/badge/cdk--constructs-experimental-important.svg?style=for-the-badge)

> The APIs of higher level constructs in this module are experimental and under active development.
> They are subject to non-backward compatible changes or removal in any future version. These are
> not subject to the [Semantic Versioning](https://semver.org/) model and breaking changes will be
> announced in the release notes. This means that while you may use them, you may need to update
> your source code when upgrading to a newer version of this package.

---
<!--END STABILITY BANNER-->

Amazon Aurora DSQL is a serverless, distributed relational database service optimized for transactional workloads. Aurora DSQL offers virtually unlimited scale and doesn't require you to manage infrastructure. The active-active highly available architecture provides 99.99% single-Region and 99.999% multi-Region availability.

The `@aws-cdk/aws-dsql-alpha` package contains primitives for setting up Aurora DSQL clusters.

```python
import aws_cdk.aws_dsql_alpha as dsql
```

## Creating an Aurora DSQL Cluster

To create an Aurora DSQL cluster, define a `Cluster`:

```python
cluster = dsql.Cluster(self, "Cluster",
    cluster_name="my-dsql-cluster",
    deletion_protection=True
)
```

## Granting Connect Access

You can grant IAM principals the ability to connect to the cluster:

```python
role = iam.Role(self, "DBRole", assumed_by=iam.AccountPrincipal(self.account))
cluster = dsql.Cluster(self, "Cluster")

# Use one of the following statements to grant the role the necessary permissions
cluster.grant_connect(role) # Grant the role dsql:DbConnect
cluster.grant_connect_admin(role) # Grant the role dsql:DbConnectAdmin
cluster.grant(role, "dsql:DbConnect")
```
