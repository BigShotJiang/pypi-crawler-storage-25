"""Automated code review via configured agent.

This module provides:
- generate_review_prompt: Assembles a structured review prompt from spec data and git diff
- prepare_mcp_review: Prepares prompt for agent invocation
- parse_review_verdict: Extracts verdict from agent output (text parsing)
- write_review_to_impl: Writes verdict and feedback to the IMPL file

Review path: The caller generates a prompt with prepare_mcp_review(),
invokes ``execute_agent(prompt=...)`` to run the review agent,
parses the verdict from the response, and writes it via
write_review_to_impl().

Verdict parsing supports two formats:
1. P-level findings (P0/P1 → NEEDS_WORK, P2/P3 only → APPROVED)
2. Explicit VERDICT: line (legacy fallback)

When both signals are present and disagree, the parser reconciles them by
letting the P-level severity list win (S393): NEEDS_WORK with only P2/P3
findings is corrected to APPROVED, and APPROVED with any P0/P1 finding is
corrected to NEEDS_WORK. The override is annotated in feedback.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import re
import subprocess
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC
from pathlib import Path

from nspec.mutation import (
    _find_impl_file,
    _get_impl_field,
    _set_impl_field,
    approve_review,
    request_changes,
    request_review,
    start_review,
)
from nspec.paths import NspecPaths, get_paths

logger = logging.getLogger("nspec")


# ---------------------------------------------------------------------------
# Verdict tamper detection (S312)
# ---------------------------------------------------------------------------
#
# To prevent an agent from bypassing the review flow by hand-editing
# ``**Verdict:** PENDING`` to ``**Verdict:** APPROVED`` in an IMPL file,
# write_review_to_impl() computes an HMAC-SHA256 signature over
# ``verdict:reviewer:timestamp`` using a project-level secret and writes it
# as a ``**Verdict-Sig:**`` field. ``complete()`` recomputes the HMAC and
# rejects the spec when the signature does not match.
#
# The secret lives in ``.novabuilt.dev/nspec/secrets/review-key`` which is
# gitignored — agents cannot forge a signature without reading that file,
# and any tampering with the verdict, reviewer, or timestamp invalidates
# the stored signature.


def get_or_create_review_secret(project_root: Path) -> bytes:
    """Return the project-level review HMAC secret, creating it on first use.

    The secret is stored in ``.novabuilt.dev/nspec/secrets/review-key``
    relative to ``project_root``. If the file does not exist it is created
    with 32 bytes from :func:`os.urandom`. The secrets directory is created
    with ``0o700`` permissions and the key file with ``0o600`` so it is
    readable only by the owning user.

    Args:
        project_root: Project root directory (where ``.novabuilt.dev`` lives).

    Returns:
        The raw 32-byte secret used to compute verdict HMACs.
    """
    import contextlib

    secrets_dir = project_root / ".novabuilt.dev" / "nspec" / "secrets"
    key_path = secrets_dir / "review-key"

    if key_path.exists():
        return key_path.read_bytes()

    secrets_dir.mkdir(parents=True, exist_ok=True)
    # Best-effort POSIX permissions — skipped on platforms that don't
    # support chmod (e.g. some Windows file systems).
    with contextlib.suppress(OSError):
        os.chmod(secrets_dir, 0o700)

    secret = os.urandom(32)
    key_path.write_bytes(secret)
    with contextlib.suppress(OSError):
        os.chmod(key_path, 0o600)
    return secret


def compute_verdict_hmac(
    secret: bytes,
    verdict: str,
    reviewer: str,
    timestamp: str,
) -> str:
    """Compute the HMAC-SHA256 signature of a verdict payload.

    The signed payload is the string ``f"{verdict}:{reviewer}:{timestamp}"``.
    Returns the signature as a lowercase hex digest suitable for writing as
    a ``**Verdict-Sig:**`` field in an IMPL file.

    Args:
        secret: Raw secret bytes from :func:`get_or_create_review_secret`.
        verdict: Verdict string (e.g. ``"APPROVED"`` or ``"NEEDS_WORK"``).
        reviewer: Reviewer name recorded on the spec.
        timestamp: ISO-8601 timestamp recorded on the spec.

    Returns:
        Hex-encoded HMAC-SHA256 signature.
    """
    payload = f"{verdict}:{reviewer}:{timestamp}".encode()
    return hmac.new(secret, payload, hashlib.sha256).hexdigest()


def verify_verdict_hmac(
    secret: bytes,
    verdict: str,
    reviewer: str,
    timestamp: str,
    sig: str,
) -> bool:
    """Verify that ``sig`` matches the HMAC of ``(verdict, reviewer, timestamp)``.

    Uses :func:`hmac.compare_digest` for constant-time comparison to avoid
    timing side channels. Returns ``False`` if ``sig`` is empty or not a
    valid hex string.

    Args:
        secret: Raw secret bytes from :func:`get_or_create_review_secret`.
        verdict: Verdict string as written in the IMPL.
        reviewer: Reviewer name as written in the IMPL.
        timestamp: Timestamp as written in the IMPL.
        sig: The signature to verify (hex string).

    Returns:
        ``True`` when the signature matches, ``False`` otherwise.
    """
    if not sig:
        return False
    expected = compute_verdict_hmac(secret, verdict, reviewer, timestamp)
    return hmac.compare_digest(expected, sig.strip())


@dataclass
class ReviewPrompt:
    """Structured review prompt data."""

    spec_id: str
    title: str
    acceptance_criteria: str
    task_list: str
    git_diff: str
    prompt_text: str


@dataclass
class ReviewVerdict:
    """Parsed review verdict from agent output."""

    verdict: str  # "APPROVED" or "NEEDS_WORK"
    feedback: str  # Feedback text (empty for APPROVED with no comments)
    raw_output: str  # Full agent output


@dataclass
class EvidenceResult:
    """Result of validating approval evidence for a spec.

    ``ok`` is True when the spec is safe to approve: all functional ACs
    are checked and all IMPL tasks are checked (or marked obsolete).
    When ``ok`` is False, ``unchecked_acs`` and ``incomplete_tasks``
    list the offending items so the implementing agent knows what to
    fix before retrying.
    """

    ok: bool
    unchecked_acs: list[str]  # Descriptions of unchecked `- [ ]` AC lines
    incomplete_tasks: list[str]  # Descriptions of unchecked `- [ ]` task lines
    test_gate_ran: bool = False
    test_gate_passed: bool = False
    test_gate_output: str = ""

    def format_error(self) -> str:
        """Return a human-readable error message listing the missing evidence."""
        lines: list[str] = ["Approval evidence insufficient:"]
        if self.unchecked_acs:
            lines.append(f"  {len(self.unchecked_acs)} unchecked acceptance criteria:")
            for ac in self.unchecked_acs:
                lines.append(f"    - [ ] {ac}")
        if self.incomplete_tasks:
            lines.append(f"  {len(self.incomplete_tasks)} incomplete tasks:")
            for task in self.incomplete_tasks:
                lines.append(f"    - [ ] {task}")
        if self.test_gate_ran and not self.test_gate_passed:
            lines.append("  test gate failed (`make test-quick`)")
        return "\n".join(lines)


def validate_approval_evidence(
    spec_id: str,
    docs_root: Path,
    *,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    require_test_pass: bool = False,
    test_cwd: Path | None = None,
) -> EvidenceResult:
    """Verify that a spec's work is actually done before recording APPROVED.

    Reads the FR and IMPL files and checks:
    1. All functional acceptance criteria (``- [ ]`` entries under
       ``## Acceptance Criteria``) are marked ``[x]`` or ``[~]``.
    2. All IMPL tasks (``- [ ]`` entries under ``## Tasks`` or
       ``## Definition of Done``) are marked ``[x]`` or ``[~]``.
    3. Optionally, ``make test-quick`` passes when ``require_test_pass``
       is True.

    Args:
        spec_id: Spec ID (e.g. "S310").
        docs_root: Path to the docs/ directory.
        paths_config: Optional custom paths configuration.
        project_root: Project root for config lookup / test cwd fallback.
        require_test_pass: When True, run ``make test-quick`` and require
            exit code 0 before reporting ok=True.
        test_cwd: Working directory for the test gate (defaults to
            project_root, then the FR file's parent).

    Returns:
        EvidenceResult with ok/unchecked_acs/incomplete_tasks populated.

    Raises:
        FileNotFoundError: If FR or IMPL files cannot be located.
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(paths.active_frs_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(paths.completed_frs_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")
    fr_content = fr_files[0].read_text()

    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    impl_content = impl_path.read_text()

    # AC-F1: only *functional* acceptance criteria gate approval. Non-
    # functional subsections such as Quality / Performance / Documentation
    # are explicitly excluded — they often stay `- [ ]` during review
    # because they reference external signals (e.g. "tests pass") that are
    # validated elsewhere.
    unchecked_acs = _collect_unchecked_items(
        fr_content,
        section_names=("Acceptance Criteria", "Success Criteria"),
        exclude_subsections=("Quality", "Performance", "Documentation"),
    )
    # S339: Exclude self-referential DoD items that can only be completed
    # AFTER the review writes APPROVED — requiring them checked before
    # writing creates a chicken-and-egg.
    # - "Agent review verdict is APPROVED": checked by complete(), not review
    # - "Code committed": commit happens after review approval
    incomplete_tasks = _collect_unchecked_items(
        impl_content,
        section_names=("Tasks", "Definition of Done"),
        exclude_task_patterns=(
            "Agent review verdict is APPROVED",
            "Code committed",
        ),
    )

    test_gate_ran = False
    test_gate_passed = False
    test_gate_output = ""
    if require_test_pass:
        cwd = test_cwd or project_root or docs_root.parent
        test_gate_ran = True
        test_gate_passed, test_gate_output = _run_test_gate(cwd)

    ok = not unchecked_acs and not incomplete_tasks and (not require_test_pass or test_gate_passed)

    return EvidenceResult(
        ok=ok,
        unchecked_acs=unchecked_acs,
        incomplete_tasks=incomplete_tasks,
        test_gate_ran=test_gate_ran,
        test_gate_passed=test_gate_passed,
        test_gate_output=test_gate_output,
    )


def _collect_unchecked_items(
    content: str,
    section_names: tuple[str, ...],
    *,
    exclude_subsections: tuple[str, ...] = (),
    exclude_task_patterns: tuple[str, ...] = (),
) -> list[str]:
    """Return descriptions of ``- [ ]`` checkbox lines inside any named section.

    A top-level section begins at ``## <name>`` (case-insensitive) and
    ends at the next ``##`` heading of the same or higher level.
    Subsections (``###``) are traversed as part of the parent section,
    but any subsection whose heading matches ``exclude_subsections`` is
    skipped — useful for ignoring e.g. ``### Quality`` when gating on
    functional acceptance criteria only (S310 AC-F1).

    Items whose description contains any string from
    ``exclude_task_patterns`` are silently omitted — used by
    ``validate_approval_evidence`` to exclude self-referential DoD
    items like "Agent review verdict is APPROVED" (S339).

    Only the literal ``- [ ]`` marker counts as unchecked; ``- [x]``
    and ``- [~]`` are both treated as done.
    """
    unchecked: list[str] = []
    lines = content.split("\n")
    in_section = False
    section_level = 0
    in_excluded_subsection = False

    lowered_names = {name.lower() for name in section_names}
    lowered_exclude = {name.lower() for name in exclude_subsections}
    lowered_patterns = tuple(p.lower() for p in exclude_task_patterns)

    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith("#"):
            level = len(stripped) - len(stripped.lstrip("#"))
            heading_text = stripped.lstrip("#").strip().lower()

            # Entering a top-level matching section resets subsection state.
            if heading_text in lowered_names:
                in_section = True
                section_level = level
                in_excluded_subsection = False
                continue

            if in_section and level <= section_level:
                # A sibling/ancestor heading closes the whole section.
                in_section = False
                in_excluded_subsection = False
                continue

            # Any deeper heading while we're inside the section is a
            # subsection — re-evaluate whether it should be excluded.
            if in_section and level > section_level:
                in_excluded_subsection = heading_text in lowered_exclude
                continue

        if not in_section or in_excluded_subsection:
            continue

        # Match "- [ ] description" (the leading dash may be indented)
        match = re.match(r"^\s*- \[ \] (.+)$", line)
        if match:
            desc = match.group(1).strip()
            # S339: skip items matching exclude_task_patterns
            if lowered_patterns and any(p in desc.lower() for p in lowered_patterns):
                continue
            unchecked.append(desc)

    return unchecked


def _run_test_gate(cwd: Path) -> tuple[bool, str]:
    """Run ``make test-quick`` in *cwd* and return (passed, output)."""
    try:
        result = subprocess.run(
            ["make", "test-quick"],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=600,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
        return False, f"test gate could not run: {exc}"
    combined = (result.stdout or "") + (result.stderr or "")
    # Truncate extreme output so callers can safely include it in errors.
    if len(combined) > 4000:
        combined = combined[-4000:]
    return result.returncode == 0, combined


def _is_pre_implementation(fr_content: str, impl_content: str) -> bool:
    """Detect whether a spec is in a pre-implementation state.

    A spec is pre-implementation when the IMPL status is Planning or
    the FR status is Proposed — meaning no implementation code exists yet.
    In this state, a code review would review unrelated diffs from other
    specs on the branch, producing false findings (S942).

    Args:
        fr_content: FR file content.
        impl_content: IMPL file content.

    Returns:
        True if the spec is pre-implementation (should use spec-quality review).
    """
    # Check IMPL status — Planning means no implementation yet.
    # Status field format: "**Status:** emoji text" (e.g., "**Status:** 🟡 Planning")
    impl_status = _get_impl_field(impl_content, "Status")
    if impl_status and "planning" in impl_status.lower():
        return True

    # Check FR status — Proposed means the spec hasn't been picked up.
    fr_status = _get_impl_field(fr_content, "Status")
    return bool(fr_status and "proposed" in fr_status.lower())


def generate_review_prompt(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    uncommitted: bool = False,
    commit_sha: str | None = None,
    base_branch: str | None = None,
    code_root: Path | None = None,
    test_results: str = "(not provided)",
) -> ReviewPrompt:
    """Generate a structured review prompt from spec data and git diff.

    Reads the FR acceptance criteria, IMPL task list, and generates
    a git diff for the spec's changes.

    Args:
        spec_id: Spec ID (e.g., "S020")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        ReviewPrompt with all assembled data

    Raises:
        FileNotFoundError: If FR or IMPL not found
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find FR file
    fr_dir = paths.active_frs_dir
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(fr_dir.glob(fr_pattern))
    if not fr_files:
        # Check completed
        completed_dir = paths.completed_frs_dir
        fr_files = list(completed_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")

    fr_content = fr_files[0].read_text()

    # Find IMPL file
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    impl_content = impl_path.read_text()

    # Extract title from FR
    title = _extract_title(fr_content)

    # Extract acceptance criteria section
    ac_text = _extract_section(fr_content, "Acceptance Criteria")
    if not ac_text:
        ac_text = _extract_section(fr_content, "Success Criteria")
    if not ac_text:
        ac_text = "(No acceptance criteria found)"

    # Extract task list section
    task_text = _extract_section(impl_content, "Tasks")
    if not task_text:
        task_text = "(No task list found)"

    # S942: Detect pre-implementation specs and use spec-quality review.
    # When the IMPL is still in Planning (or FR is Proposed), there is no
    # implementation code to review — the git diff would contain unrelated
    # changes from other specs on the branch. Use a spec-quality review
    # prompt that reviews the FR/IMPL documents instead.
    is_pre_impl = _is_pre_implementation(fr_content, impl_content)

    if is_pre_impl:
        # Pre-implementation: spec-quality review (no diff needed)
        review_prompt_profile: str | None = "spec-quality"
        logger.debug(
            "S942: spec %s is pre-implementation, using spec-quality review",
            spec_id,
        )
    else:
        # Post-implementation: standard code review — agent runs git diff itself
        effective_base = base_branch or "main"

        # S903/S956: warn (but don't reject) when on the same branch as
        # base. The agent can still review uncommitted changes via
        # `git diff HEAD`. Only log so the caller knows the committed-diff
        # command will be empty.
        effective_cwd = code_root or project_root or docs_root.parent
        current_branch = _get_current_branch(effective_cwd)
        if current_branch is not None and current_branch == effective_base:
            logger.warning(
                "review_spec(%s): on branch '%s' which matches base_branch "
                "'%s' — `git diff %s...HEAD` will be empty. The reviewer "
                "will fall back to `git diff HEAD` for uncommitted changes.",
                spec_id,
                current_branch,
                effective_base,
                effective_base,
            )

        # Detect spec type for type-aware review prompts
        review_prompt_profile = None
        try:
            from nspec.config import NspecConfig as _NspecConfig
            from nspec.domain.spec_types import default_registry

            _pr = project_root or docs_root.parent
            _cfg = _NspecConfig.load(_pr)
            registry = default_registry(_cfg)
            for st in registry.all():
                if st.review_prompt and st.name not in ("fr", "impl", "epic"):
                    if st.directory:
                        type_dir = docs_root / st.directory
                        expected_prefix = st.prefix + "-"
                        for _f in type_dir.glob(f"{expected_prefix}*{spec_id}*"):
                            review_prompt_profile = st.review_prompt
                            break
                    if review_prompt_profile:
                        break
        except Exception:
            pass  # Fall back to default review prompt

    effective_base = base_branch or "main"

    # Assemble the prompt
    prompt_text = _assemble_prompt(
        spec_id,
        title,
        ac_text,
        task_text,
        project_root,
        test_results,
        review_prompt_profile=review_prompt_profile,
        base_branch=effective_base,
    )

    return ReviewPrompt(
        spec_id=spec_id,
        title=title,
        acceptance_criteria=ac_text,
        task_list=task_text,
        git_diff="(agent self-serves via git diff)",
        prompt_text=prompt_text,
    )


def parse_review_verdict(agent_output: str) -> ReviewVerdict | None:
    """Parse review agent output to extract the review verdict.

    Supports two output formats:

    1. **Explicit VERDICT line** (legacy): ``VERDICT: APPROVED`` or
       ``VERDICT: NEEDS_WORK``. Legacy fallback format.
    2. **P-level findings** (codex-cli): Findings tagged ``[P0]``–``[P3]``.
       P0/P1 findings → NEEDS_WORK; only P2/P3 (or no findings) → APPROVED.

    The explicit VERDICT line takes precedence when present.

    When the output contains ANSI-styled ``codex`` markers (from Codex CLI
    terminal output), only the text after the last marker is searched to
    avoid matching VERDICT strings from prompt instructions.

    Args:
        agent_output: Text output from the review agent

    Returns:
        ReviewVerdict if a verdict was found, None if no verdict detected
    """
    # Agent output may contain ANSI-styled "codex" markers from the CLI.
    # Only search after the last marker to avoid matching prompt text.
    codex_marker = re.compile(r"(?:\x1b\[[\d;]*m)*codex(?:\x1b\[[\d;]*m)*\s*$", re.MULTILINE)
    search_text = agent_output

    markers = list(codex_marker.finditer(agent_output))
    if markers:
        search_text = agent_output[markers[-1].end() :]

    # Strategy 1: Look for explicit VERDICT: line (case-insensitive)
    pattern = r"VERDICT:\s*(APPROVED|NEEDS_WORK)"
    match = re.search(pattern, search_text, re.IGNORECASE)

    if match:
        verdict = match.group(1).upper()
        feedback = search_text[match.end() :].strip()
        feedback = _clean_terminal_output(feedback)

        # S393: cross-check explicit verdict against P-level severity. Codex
        # systematically returns NEEDS_WORK for P2-only findings; correct it
        # to APPROVED so the reviewer's stated severity, not their stated
        # verdict word, governs lifecycle. If P-level signal disagrees, the
        # severity list wins and we annotate the override in feedback.
        p_signal = _parse_p_level_findings(search_text)
        if p_signal is not None and p_signal[0] != verdict:
            corrected = p_signal[0]
            note = (
                f"\n\n[S393 verdict-severity reconciliation: reviewer wrote "
                f"VERDICT={verdict} but findings list shows {corrected}. "
                f"Verdict overridden to {corrected} per severity rule.]"
            )
            return ReviewVerdict(
                verdict=corrected, feedback=feedback + note, raw_output=agent_output
            )

        return ReviewVerdict(verdict=verdict, feedback=feedback, raw_output=agent_output)

    # Strategy 2: Parse P-level findings from codex-cli output
    p_level_result = _parse_p_level_findings(search_text)
    if p_level_result is not None:
        return ReviewVerdict(
            verdict=p_level_result[0],
            feedback=p_level_result[1],
            raw_output=agent_output,
        )

    return None


def _parse_p_level_findings(text: str) -> tuple[str, str] | None:
    """Extract verdict from codex-cli P-level findings.

    Looks for ``[P0]``, ``[P1]``, ``[P2]``, ``[P3]`` tagged findings.
    If any P0 or P1 findings exist, returns NEEDS_WORK.
    If only P2/P3 findings exist (or no findings with other review
    indicators), returns APPROVED.

    Returns:
        (verdict, feedback) tuple, or None if no P-level findings detected.
    """
    # Match [P0], [P1], [P2], [P3] at the start of lines or inline
    p_pattern = re.compile(r"\[P([0-3])\]\s*(.*?)(?:\n|$)", re.MULTILINE)
    findings = p_pattern.findall(text)

    if not findings:
        return None

    # Separate by severity
    blocking = []  # P0, P1
    advisory = []  # P2, P3

    for level, description in findings:
        level_int = int(level)
        desc = description.strip()
        if level_int <= 1:
            blocking.append(f"[P{level}] {desc}")
        else:
            advisory.append(f"[P{level}] {desc}")

    if blocking:
        all_findings = blocking + advisory
        feedback = _clean_terminal_output("\n".join(all_findings))
        return ("NEEDS_WORK", feedback)

    # Only P2/P3 findings — approved
    feedback = _clean_terminal_output("\n".join(advisory)) if advisory else ""
    return ("APPROVED", feedback)


class ApprovalEvidenceError(ValueError):
    """Raised when an APPROVED verdict cannot be recorded because the
    spec's work is not actually complete (unchecked ACs/tasks or
    failing test gate).

    The attached ``result`` carries the structured EvidenceResult so
    callers can report precisely which ACs and tasks are missing.
    """

    def __init__(self, result: EvidenceResult) -> None:
        super().__init__(result.format_error())
        self.result = result


def write_review_to_impl(
    spec_id: str,
    verdict: ReviewVerdict,
    reviewer: str,
    implementer: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Write review verdict and feedback to the IMPL file.

    Persists all review fields: Implementer, Reviewer, Verdict, Reviewed
    date, and full feedback text in the Findings section.

    Uses the existing crud.py review workflow functions:
    - request_review (sets implementer, moves to Testing)
    - start_review (sets reviewer)
    - approve_review or request_changes (sets verdict + findings)

    For APPROVED verdicts, this function first validates approval
    evidence via :func:`validate_approval_evidence`. If the spec has
    unchecked acceptance criteria, incomplete tasks, or (when
    ``[review].require_test_pass`` is enabled) a failing test gate, it
    raises :class:`ApprovalEvidenceError` and does NOT write the
    verdict. NEEDS_WORK verdicts skip evidence validation entirely so
    reviewers can request changes before work is finished.

    Args:
        spec_id: Spec ID
        verdict: Parsed review verdict from the review agent
        reviewer: Reviewer name (e.g., "codex")
        implementer: Implementer name (e.g., "claude")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Path to updated IMPL file

    Raises:
        ApprovalEvidenceError: If the verdict is APPROVED but the spec
            has unchecked ACs, incomplete tasks, or a failing test gate.
    """
    from nspec.mutation import _validate_after_write
    from nspec.runtime.atomic import batch_writes, spec_read, spec_write

    _effective_project_root = project_root or docs_root.parent

    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)

    # Evidence-based verdict validation (S310). Only APPROVED verdicts
    # are gated — NEEDS_WORK is always allowed because a reviewer may
    # legitimately request changes before the implementer has finished.
    if verdict.verdict == "APPROVED":
        require_test_pass = False
        try:
            from nspec.config import NspecConfig

            _pr = project_root or docs_root.parent
            _cfg = NspecConfig.load(_pr)
            require_test_pass = bool(_cfg.review.require_test_pass)
        except Exception:
            # Fall back to default (no test gate) if config cannot load.
            require_test_pass = False

        evidence = validate_approval_evidence(
            spec_id,
            docs_root,
            paths_config=paths_config,
            project_root=project_root,
            require_test_pass=require_test_pass,
        )
        if not evidence.ok:
            raise ApprovalEvidenceError(evidence)

    # Batch all writes so the IMPL file is updated atomically — the TUI
    # polls for file changes and would otherwise see intermediate states.
    with batch_writes():
        content = spec_read(impl_path)

        # Check if implementer is already set (spec may already be in review)
        existing_implementer = _get_impl_field(content, "Implementer")
        existing_reviewer = _get_impl_field(content, "Reviewer")

        if (not existing_implementer or existing_implementer == "---") and implementer:
            # Try request_review() first — it sets implementer AND transitions
            # Active → Testing.  For specs already in Testing (or beyond) it
            # raises ValueError; fall back to a direct field write so the
            # implementer is always recorded regardless of current status.
            try:
                request_review(spec_id, implementer, docs_root, paths_config, project_root)
            except ValueError:
                content = _set_impl_field(content, "Implementer", implementer)
                spec_write(impl_path, content)

        if not existing_reviewer:
            start_review(spec_id, reviewer, docs_root, paths_config, project_root)

        # Apply verdict
        if verdict.verdict == "APPROVED":
            notes = verdict.feedback if verdict.feedback else None
            result = approve_review(spec_id, notes, docs_root, paths_config, project_root)

            # S339: Atomically check off the "Agent review verdict is APPROVED"
            # DoD item as part of the same batch_writes() block. This resolves
            # the chicken-and-egg where dod-4 can only be legitimately checked
            # after the review writes APPROVED.
            _check_dod_review_verdict(impl_path, spec_read, spec_write)
        else:
            notes = (
                verdict.feedback if verdict.feedback else "Changes requested by automated review"
            )
            result = request_changes(spec_id, notes, docs_root, paths_config, project_root)

        # S372: Final reconciliation — ensure Implementer/Reviewer fields are
        # set to the correct values regardless of which sub-functions ran or
        # failed above.  The sub-functions (request_review, start_review,
        # approve_review) each do independent read-modify-write cycles, and
        # _set_review_verdict can re-introduce "—" placeholders when it
        # creates a new Review section template.  This belt-and-suspenders
        # step reads the final buffered content and patches any remaining
        # placeholder values.
        reconciled = spec_read(impl_path)
        if implementer and not _get_impl_field(reconciled, "Implementer"):
            reconciled = _set_impl_field(reconciled, "Implementer", implementer)
        if reviewer and not _get_impl_field(reconciled, "Reviewer"):
            reconciled = _set_impl_field(reconciled, "Reviewer", reviewer)
        spec_write(impl_path, reconciled)

        # Sign the verdict with an HMAC so complete() can detect hand-edited
        # verdict fields (S312). The signature covers verdict + reviewer +
        # timestamp so tampering with any of those invalidates the sig.
        # Running inside the batch coalesces this into a single atomic flush
        # alongside the approve_review / request_changes writes.
        try:
            signed_content = spec_read(impl_path)
            signed_verdict = _get_impl_field(signed_content, "Verdict")
            signed_reviewer = _get_impl_field(signed_content, "Reviewer") or ""
            signed_timestamp = _get_impl_field(signed_content, "Reviewed") or ""
            if signed_verdict:
                secret = get_or_create_review_secret(_effective_project_root)
                sig = compute_verdict_hmac(
                    secret,
                    signed_verdict,
                    signed_reviewer,
                    signed_timestamp,
                )
                signed_content = _set_impl_field(signed_content, "Verdict-Sig", sig)
                spec_write(impl_path, signed_content)
        except Exception as exc:
            # HMAC signing is best-effort — log but don't fail the review
            # write (existing callers rely on this function returning a path).
            logger.warning("Could not sign verdict for %s: %s", spec_id, exc)

    # Validate after the batch flush — files are now on disk
    _validate_after_write(spec_id, docs_root, paths_config)
    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _check_dod_review_verdict(
    impl_path: Path,
    spec_read: Callable[[Path], str],
    spec_write: Callable[[Path, str], None],
) -> None:
    """Check off the "Agent review verdict is APPROVED" DoD item in an IMPL file.

    Searches the IMPL content for any ``- [ ]`` checkbox whose description
    contains "Agent review verdict is APPROVED" (case-insensitive) and
    replaces ``[ ]`` with ``[x]``.  Called inside ``batch_writes()`` so the
    change is flushed atomically with the verdict write (S339).
    """
    content = spec_read(impl_path)
    new_lines: list[str] = []
    changed = False
    for line in content.split("\n"):
        if (
            not changed
            and re.match(r"^\s*- \[ \] ", line)
            and "agent review verdict is approved" in line.lower()
        ):
            line = line.replace("- [ ] ", "- [x] ", 1)
            changed = True
        new_lines.append(line)
    if changed:
        spec_write(impl_path, "\n".join(new_lines))


def _extract_title(content: str) -> str:
    """Extract title from first heading line."""
    for line in content.split("\n"):
        if line.startswith("# "):
            return line[2:].strip()
    return "(untitled)"


def _extract_section(content: str, section_name: str) -> str:
    """Extract a markdown section by heading name.

    Returns everything from the heading to the next heading of same or higher level.
    """
    lines = content.split("\n")
    in_section = False
    section_lines: list[str] = []
    section_level = 0

    for line in lines:
        if line.startswith("#"):
            level = len(line) - len(line.lstrip("#"))
            heading_text = line.lstrip("#").strip()

            if heading_text.lower() == section_name.lower():
                in_section = True
                section_level = level
                continue
            elif in_section and level <= section_level:
                break

        if in_section:
            section_lines.append(line)

    return "\n".join(section_lines).strip()


# Default pathspecs when no config is available.
_DEFAULT_DIFF_EXCLUDE: list[str] = [
    ".novabuilt.dev/",
    ".claude/",
    "poetry.lock",
    "work/",
]


def _build_diff_pathspecs(
    include: list[str] | None = None,
    exclude: list[str] | None = None,
) -> list[str]:
    """Build git pathspec list from include/exclude configuration.

    Args:
        include: Paths to include (empty = all paths).
        exclude: Paths to exclude via ``:(exclude)`` prefix.

    Returns:
        List starting with ``--`` separator followed by pathspec entries.
    """
    specs: list[str] = ["--"]
    if include:
        specs.extend(include)
    if exclude is None:
        exclude = _DEFAULT_DIFF_EXCLUDE
    for path in exclude:
        specs.append(f":(exclude){path}")
    return specs


def _get_current_branch(cwd: Path | None = None) -> str | None:
    """Return current git branch name, or None if detached/unavailable."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=str(cwd) if cwd else None,
        )
        if result.returncode == 0:
            name = result.stdout.strip()
            return name if name and name != "HEAD" else None
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def _get_git_diff(
    *,
    uncommitted: bool = False,
    commit_sha: str | None = None,
    base_branch: str | None = None,
    cwd: Path | None = None,
    diff_include: list[str] | None = None,
    diff_exclude: list[str] | None = None,
) -> str:
    """Get git diff for current changes.

    Args:
        uncommitted: Show staged + unstaged changes against HEAD (tracked files only).
            Note: Untracked files are not included in git diff output.
        commit_sha: Show changes from a specific commit
        base_branch: Show changes against a base branch
        cwd: Working directory for git commands (integration mode).
        diff_include: Paths to include in diff (from config). Empty = all.
        diff_exclude: Paths to exclude from diff (from config).

    Falls back to trying main...HEAD, HEAD, then unstaged.
    """
    pathspecs = _build_diff_pathspecs(diff_include, diff_exclude)

    # Build command list based on mode.
    if commit_sha:
        cmds = [["git", "diff", f"{commit_sha}~1..{commit_sha}"] + pathspecs]
    elif base_branch:
        cmds = [["git", "diff", f"{base_branch}...HEAD"] + pathspecs]
    elif uncommitted:
        cmds = [
            ["git", "diff", "HEAD"] + pathspecs,
            ["git", "diff", "--cached"] + pathspecs,
            ["git", "diff"] + pathspecs,
        ]
    else:
        cmds = [
            ["git", "diff", "main...HEAD"] + pathspecs,
            ["git", "diff", "HEAD"] + pathspecs,
            ["git", "diff"] + pathspecs,
        ]

    cwd_str = str(cwd) if cwd else None

    for cmd in cmds:
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
                cwd=cwd_str,
            )
            if result.returncode == 0 and result.stdout.strip():
                diff = result.stdout
                # Truncate very large diffs
                max_chars = 50000
                if len(diff) > max_chars:
                    diff = diff[:max_chars] + "\n\n... (diff truncated at 50k chars)"
                return diff
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    # Final fallback (S903): when nothing else produced a diff — e.g.
    # running on `main` after a commit so `main...HEAD`, `git diff HEAD`,
    # and `git diff` all return empty — surface the *last commit's* diff
    # via `git show HEAD`. Without this, codex receives a degenerate prompt
    # ("(no git diff available)") and rubber-stamps APPROVED.
    try:
        result = subprocess.run(
            ["git", "show", "HEAD"] + pathspecs,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=cwd_str,
        )
        if result.returncode == 0 and result.stdout.strip():
            diff = result.stdout
            max_chars = 50000
            if len(diff) > max_chars:
                diff = diff[:max_chars] + "\n\n... (diff truncated at 50k chars)"
            return diff
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return "(no git diff available)"


def _assemble_prompt(
    spec_id: str,
    title: str,
    ac_text: str,
    task_text: str,
    project_root: Path | None = None,
    test_results: str = "(not provided)",
    review_prompt_profile: str | None = None,
    base_branch: str = "main",
) -> str:
    """Assemble the structured review prompt for the configured review agent.

    Loads the prompt template from the ``review-prompt`` resource handle
    (or ``review-prompt:{profile}`` for type-specific prompts),
    then substitutes variables via ``str.format_map()``.
    """
    from nspec.resources.registry import SafeFormatMap, load_resource

    handle = "review-prompt"
    if review_prompt_profile:
        handle = f"review-prompt:{review_prompt_profile}"
    template = load_resource(handle, project_root)
    return template.format_map(
        SafeFormatMap(
            {
                "spec_id": spec_id,
                "title": title,
                "ac_text": ac_text,
                "task_text": task_text,
                "base_branch": base_branch,
                "test_results": test_results,
            }
        )
    )


def extract_verdict_from_impl(content: str) -> str | None:
    """Extract review verdict from IMPL file content.

    Looks for the **Verdict:** line in the Review section.

    Args:
        content: IMPL file content

    Returns:
        Verdict string (APPROVED, NEEDS_WORK, PENDING, TBD) or None if not found
    """
    # Look for **Verdict:** at start of line (avoid matching inside task descriptions)
    pattern = r"^\*\*Verdict:\*\*\s*(\S+)"
    match = re.search(pattern, content, re.MULTILINE)
    if match:
        verdict = match.group(1).strip()
        # Normalize common values
        verdict_upper = verdict.upper()
        if verdict_upper in ("APPROVED", "NEEDS_WORK", "PENDING", "TBD"):
            return verdict_upper
        # Handle dash/em-dash as "not set"
        if verdict in ("—", "-", "–"):
            return None
        return verdict
    return None


def _clean_terminal_output(text: str) -> str:
    """Remove terminal control sequences and artifacts from output."""
    # Remove ANSI escape codes
    ansi_escape = re.compile(r"\x1b\[[0-9;]*[a-zA-Z]")
    text = ansi_escape.sub("", text)

    # Remove common terminal artifacts
    text = text.replace("\r\n", "\n")
    text = text.replace("\r", "")

    # Remove leading/trailing whitespace and empty lines
    lines = [line.rstrip() for line in text.split("\n")]
    # Remove empty lines at start and end
    while lines and not lines[0]:
        lines.pop(0)
    while lines and not lines[-1]:
        lines.pop()

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Agent-Based Review Integration
# ---------------------------------------------------------------------------


@dataclass
class MCPReviewRequest:
    """Review request prepared for review agent invocation.

    This dataclass contains everything needed to invoke an agent-based review
    via ``execute_agent()``.
    """

    spec_id: str
    prompt: str  # The full review prompt


def prepare_mcp_review(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    uncommitted: bool = False,
    commit_sha: str | None = None,
    base_branch: str | None = None,
    code_root: Path | None = None,
    test_results: str = "(not provided)",
) -> MCPReviewRequest:
    """Prepare a review request for review agent invocation.

    This function generates the review prompt but does NOT invoke the agent.
    The caller (typically Claude via the /review skill) should:
    1. Call this function to get the prompt
    2. Invoke execute_agent(prompt=...) to run the review
    3. Parse the response with parse_review_verdict()
    4. Write the verdict with write_review_to_impl()

    This design allows the MCP server to prepare the prompt while the
    actual agent invocation is a separate step.

    Args:
        spec_id: Spec ID (e.g., "S020")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup
        uncommitted: Include staged/unstaged changes in diff
        commit_sha: Review changes from a specific commit
        base_branch: Review changes against a base branch
        code_root: Working directory for git diff (integration mode).

    Returns:
        MCPReviewRequest with the prompt ready for the review agent
    """
    prompt = generate_review_prompt(
        spec_id,
        docs_root,
        paths_config,
        project_root,
        uncommitted=uncommitted,
        commit_sha=commit_sha,
        base_branch=base_branch,
        code_root=code_root,
        test_results=test_results,
    )

    return MCPReviewRequest(
        spec_id=spec_id,
        prompt=prompt.prompt_text,
    )


# ---------------------------------------------------------------------------
# Review Token (anti-rubber-stamping)
# ---------------------------------------------------------------------------


def _token_dir(project_root: Path) -> Path:
    """Return the directory where review tokens are stored."""
    return project_root / ".novabuilt.dev" / "nspec" / "work" / "review-tokens"


def _token_path(spec_id: str, project_root: Path) -> Path:
    """Return path to the review token file for a spec."""
    return _token_dir(project_root) / f"review-token-{spec_id}.json"


def cleanup_stale_tokens(project_root: Path, ttl_hours: int) -> int:
    """Delete review tokens older than ``ttl_hours``.

    Args:
        project_root: Project root directory.
        ttl_hours: Maximum age in hours. 0 means no expiry (skip cleanup).

    Returns:
        Number of tokens deleted.
    """
    if ttl_hours <= 0:
        return 0

    from datetime import datetime

    token_dir = _token_dir(project_root)
    if not token_dir.exists():
        return 0

    now = datetime.now(UTC)
    deleted = 0
    for path in token_dir.glob("review-token-*.json"):
        try:
            data = json.loads(path.read_text())
            issued_at = datetime.fromisoformat(data["issued_at"])
            # Ensure timezone-aware comparison
            if issued_at.tzinfo is None:
                issued_at = issued_at.replace(tzinfo=UTC)
            age_hours = (now - issued_at).total_seconds() / 3600
            if age_hours > ttl_hours:
                path.unlink(missing_ok=True)
                logger.debug("Deleted stale review token: %s (%.1fh old)", path.name, age_hours)
                deleted += 1
        except (json.JSONDecodeError, OSError, KeyError, ValueError):
            continue
    return deleted


def generate_review_token(
    spec_id: str, project_root: Path, agent: str = "codex", ttl_hours: int = 24
) -> str:
    """Create a single-use review token and persist it to disk.

    Called by ``review_spec()`` to prove the review flow was initiated
    through the proper channel. Runs lazy cleanup of stale tokens before
    generating a new one.

    Args:
        spec_id: Spec ID (e.g., "S042").
        project_root: Project root directory.
        agent: Review agent name (e.g., "codex", "gemini", "claude").
        ttl_hours: Token TTL for cleanup. 0 disables cleanup.

    Returns:
        The generated token string (UUID4).
    """
    from nspec.runtime.timestamps import now_iso

    # Lazy sweep of stale tokens
    cleanup_stale_tokens(project_root, ttl_hours)

    token = uuid.uuid4().hex
    path = _token_path(spec_id, project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"token": token, "spec_id": spec_id, "agent": agent, "issued_at": now_iso()})
        + "\n"
    )
    return token


def validate_review_token(
    spec_id: str, token: str, project_root: Path, agent: str | None = None
) -> bool:
    """Check if a review token is valid without consuming it.

    Same validation logic as ``consume_review_token`` but does NOT delete
    the token file.  Use this when you need to verify the token before
    attempting an operation that might fail — then call
    ``consume_review_token`` only after success.

    Args:
        spec_id: Expected spec ID.
        token: Token string to validate.
        project_root: Project root directory.
        agent: If provided, also validates the token's agent field matches.

    Returns:
        True if the token is valid, False otherwise.
    """
    path = _token_path(spec_id, project_root)
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return False
    if data.get("token") != token or data.get("spec_id") != spec_id:
        return False
    return agent is None or data.get("agent") == agent


def consume_review_token(
    spec_id: str, token: str, project_root: Path, agent: str | None = None
) -> bool:
    """Validate and delete a review token (single-use).

    Returns True if the token was valid, False otherwise.
    The token file is deleted on success to prevent reuse.

    Args:
        spec_id: Expected spec ID.
        token: Token string to validate.
        project_root: Project root directory.
        agent: If provided, also validates the token's agent field matches.
    """
    path = _token_path(spec_id, project_root)
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return False
    if data.get("token") != token or data.get("spec_id") != spec_id:
        return False
    if agent is not None and data.get("agent") != agent:
        return False
    # Valid — consume by deleting
    path.unlink(missing_ok=True)
    return True


def restore_review_token(
    spec_id: str, token: str, project_root: Path, agent: str = "claude"
) -> None:
    """Re-create a previously consumed review token.

    Used by ``write_review_verdict`` when the token was consumed
    atomically inside the lock but the subsequent write failed.
    Restoring the token allows callers to retry without calling
    ``review_spec()`` again.

    Args:
        spec_id: Spec ID.
        token: The original token string.
        project_root: Project root directory.
        agent: Agent name to store in the token file.
    """
    from nspec.runtime.timestamps import now_iso

    path = _token_path(spec_id, project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"token": token, "spec_id": spec_id, "agent": agent, "issued_at": now_iso()})
        + "\n"
    )


# ---------------------------------------------------------------------------
# Verdict Token (delegation integrity proof)
# ---------------------------------------------------------------------------


def _verdict_token_path(spec_id: str, project_root: Path) -> Path:
    """Return path to the verdict token file for a spec."""
    return _token_dir(project_root) / f"verdict-token-{spec_id}.json"


def resolve_spec_from_review_token(review_token: str, project_root: Path) -> str | None:
    """Look up the spec_id bound to a review_token from the token file.

    Scans the token directory for a file containing the given token value
    and returns the spec_id stored in that file. This prevents callers
    from manipulating the spec_id — it is always resolved from the file
    that review_spec() originally wrote.

    Args:
        review_token: The review_token to look up.
        project_root: Project root directory.

    Returns:
        The spec_id if found, or None if no matching token file exists.
    """
    token_dir = _token_dir(project_root)
    if not token_dir.exists():
        return None
    for path in token_dir.glob("review-token-*.json"):
        try:
            data = json.loads(path.read_text())
            if data.get("token") == review_token:
                return data.get("spec_id")
        except (json.JSONDecodeError, OSError):
            continue
    return None


def generate_verdict_token(
    spec_id: str,
    project_root: Path,
    review_token: str,
    agent_output: str,
    agent: str = "codex",
) -> str | None:
    """Create a verdict token proving execute_agent() was called.

    Consumes the review_token (proving review_spec() was called first),
    then generates a verdict_token derived from the review_token and
    agent output hash. The verdict_token is required by
    ``write_review_verdict()`` when the review agent is external.

    Args:
        spec_id: Spec ID (e.g., "S042").
        project_root: Project root directory.
        review_token: The review_token from review_spec().
        agent_output: Raw output text from the agent execution.
        agent: Agent name that performed the review.

    Returns:
        The verdict token string, or None if the review_token was invalid.
    """
    from nspec.runtime.timestamps import now_iso

    # Consume the review_token — proves review_spec() was called
    if not consume_review_token(spec_id, review_token, project_root, agent=agent):
        return None

    # Derive verdict_token from review_token + output hash
    output_hash = hashlib.sha256(agent_output.encode()).hexdigest()[:16]
    verdict_token = uuid.uuid4().hex

    path = _verdict_token_path(spec_id, project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "verdict_token": verdict_token,
                "spec_id": spec_id,
                "agent": agent,
                "review_token_hash": hashlib.sha256(review_token.encode()).hexdigest()[:16],
                "output_hash": output_hash,
                "issued_at": now_iso(),
            }
        )
        + "\n"
    )
    return verdict_token


def validate_verdict_token(spec_id: str, verdict_token: str, project_root: Path) -> bool:
    """Check if a verdict token is valid without consuming it.

    Same validation logic as ``consume_verdict_token`` but does NOT delete
    the token file.  Use this when you need to verify the token before
    attempting an operation that might fail — then call
    ``consume_verdict_token`` only after success.

    Args:
        spec_id: Expected spec ID.
        verdict_token: Verdict token string to validate.
        project_root: Project root directory.

    Returns:
        True if the token is valid, False otherwise.
    """
    path = _verdict_token_path(spec_id, project_root)
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return False
    return data.get("verdict_token") == verdict_token and data.get("spec_id") == spec_id


def consume_verdict_token(spec_id: str, verdict_token: str, project_root: Path) -> bool:
    """Validate and delete a verdict token (single-use).

    Returns True if the token was valid, False otherwise.
    The token file is deleted on success to prevent reuse.

    Args:
        spec_id: Expected spec ID.
        verdict_token: Verdict token string to validate.
        project_root: Project root directory.
    """
    path = _verdict_token_path(spec_id, project_root)
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return False
    if data.get("verdict_token") != verdict_token or data.get("spec_id") != spec_id:
        return False
    # Valid — consume by deleting
    path.unlink(missing_ok=True)
    return True


# ---------------------------------------------------------------------------
# Terse-Approval Detection (S350)
# ---------------------------------------------------------------------------

# Thresholds for detecting suspiciously terse APPROVED verdicts.
TERSE_FEEDBACK_CHAR_LIMIT = 200
TERSE_FINDING_BULLET_LIMIT = 3


def is_terse_approval(verdict: ReviewVerdict) -> bool:
    """Check if a ReviewVerdict is suspiciously terse.

    A verdict is considered terse if it is APPROVED AND:
    - The feedback is shorter than TERSE_FEEDBACK_CHAR_LIMIT characters, AND
    - The feedback contains fewer than TERSE_FINDING_BULLET_LIMIT finding bullets

    Finding bullets are lines starting with ``-``, ``*``, or ``[P#]``.

    Args:
        verdict: The parsed ReviewVerdict to check.

    Returns:
        True if the verdict looks like a rubber-stamp approval.
    """
    if verdict.verdict != "APPROVED":
        return False

    feedback = verdict.feedback.strip()

    # Short feedback check
    if len(feedback) >= TERSE_FEEDBACK_CHAR_LIMIT:
        return False

    # Count finding bullets: lines starting with -, *, or [P#]
    bullet_pattern = re.compile(r"^\s*(?:[-*]|\[P[0-3]\])\s+", re.MULTILINE)
    bullet_count = len(bullet_pattern.findall(feedback))

    return bullet_count < TERSE_FINDING_BULLET_LIMIT


def get_previous_round_verdict(spec_id: str, project_root: Path) -> ReviewVerdict | None:
    """Read the stored raw output from the most recent review round and parse its verdict.

    Looks for review output files in the review-output directory and
    parses the highest-numbered round file.

    Args:
        spec_id: Spec ID (e.g., "S350").
        project_root: Project root directory.

    Returns:
        ReviewVerdict from the previous round, or None if no previous round exists.
    """
    output_dir = _review_output_dir(project_root)
    if not output_dir.exists():
        return None

    # Find all round files for this spec, sorted by numeric round suffix.
    # We must NOT use plain lexicographic sort here — that orders
    # ``S350-10.txt`` before ``S350-2.txt`` and would pick the wrong
    # "latest" round once round count reaches 10+.
    round_re = re.compile(rf"^{re.escape(spec_id)}-(\d+)\.txt$")
    round_files: list[tuple[int, Path]] = []
    for path in output_dir.glob(f"{spec_id}-*.txt"):
        m = round_re.match(path.name)
        if m is not None:
            round_files.append((int(m.group(1)), path))
    if not round_files:
        return None

    round_files.sort(key=lambda item: item[0])

    # Read the last (most recent) round
    raw_output = round_files[-1][1].read_text(encoding="utf-8")
    return parse_review_verdict(raw_output)


def build_confirmation_prompt(
    original_prompt: str, previous_findings: str, review_round: int
) -> str:
    """Build a sharpened confirmation prompt for terse-approval re-review.

    Constructs a prompt that quotes the previous round's findings and
    requires the reviewer to explicitly address each one before confirming
    or changing the verdict.

    Args:
        original_prompt: The original review prompt text.
        previous_findings: Feedback text from the previous NEEDS_WORK round.
        review_round: The round number of the terse approval being challenged.

    Returns:
        The confirmation prompt text.
    """
    return (
        f"## CONFIRMATION REVIEW — Round {review_round} terse approval detected\n\n"
        f"Round {review_round} returned APPROVED with no substantive findings "
        f"immediately after a NEEDS_WORK round. This looks like a review-quality "
        f"failure (rubber stamp). Please re-review carefully.\n\n"
        f"### Previous round findings that must be addressed:\n\n"
        f"{previous_findings}\n\n"
        f"### Instructions:\n\n"
        f"1. Read the diff carefully.\n"
        f"2. For EACH finding from the previous round, confirm whether it was "
        f"fixed, still present, or not applicable. Reference specific file:line.\n"
        f"3. Check for any NEW issues introduced by the fixes.\n"
        f"4. Provide your verdict with substantive reasoning.\n\n"
        f"---\n\n"
        f"{original_prompt}"
    )


# ---------------------------------------------------------------------------
# Atomic Review (S309)
# ---------------------------------------------------------------------------


@dataclass
class AtomicReviewResult:
    """Result from an atomic review cycle.

    The implementing agent receives this structured summary — never the
    raw review output.  Raw output is persisted to disk for auditing.
    """

    spec_id: str
    verdict: str  # "APPROVED" or "NEEDS_WORK"
    findings: str  # Cleaned feedback text (may be empty for APPROVED)
    review_round: int
    reviewer: str
    raw_output_path: str  # Path where raw output was stored


def _review_output_dir(project_root: Path) -> Path:
    """Return the directory for storing raw review output."""
    return project_root / ".novabuilt.dev" / "nspec" / "work" / "review-output"


def _store_raw_output(spec_id: str, review_round: int, raw_output: str, project_root: Path) -> Path:
    """Persist raw review agent output to disk for auditing.

    Args:
        spec_id: Spec ID (e.g., "S309").
        review_round: Review round number (1-based).
        raw_output: Full text output from the review agent.
        project_root: Project root directory.

    Returns:
        Path to the stored output file.
    """
    output_dir = _review_output_dir(project_root)
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / f"{spec_id}-{review_round}.txt"
    output_path.write_text(raw_output)
    return output_path


def _count_review_rounds(spec_id: str, project_root: Path) -> int:
    """Count existing review round files for a spec.

    Returns the number of existing round files, so the next round is N+1.
    """
    output_dir = _review_output_dir(project_root)
    if not output_dir.exists():
        return 0
    return len(list(output_dir.glob(f"{spec_id}-*.txt")))


def atomic_review(
    spec_id: str,
    docs_root: Path,
    project_root: Path | None = None,
    *,
    base_branch: str | None = None,
    uncommitted: bool = False,
    test_results: str = "(not provided)",
    implementer: str = "claude",
) -> AtomicReviewResult:
    """Execute a full review cycle atomically.

    Orchestrates the complete review pipeline server-side:
    1. Generate review prompt from FR/IMPL and git diff.
    2. Resolve the configured review executor.
    3. Run the review agent.
    4. Parse the verdict from agent output.
    5. Store raw output to disk (isolated from implementing agent).
    6. Write verdict and findings to the IMPL file.

    The implementing agent receives only the structured result — never
    the raw review output.  This prevents the agent from controlling
    verdict interpretation or selectively reporting findings.

    Args:
        spec_id: Spec ID to review (e.g., "S309").
        docs_root: Path to docs/ directory.
        project_root: Project root for config lookup.
        base_branch: Review changes against this branch.
        uncommitted: Include staged/unstaged changes in diff.
        test_results: Test output to include as reviewer receipt.
        implementer: Name of the implementing agent.

    Returns:
        AtomicReviewResult with verdict, findings, and output path.

    Raises:
        FileNotFoundError: If FR or IMPL not found.
        RuntimeError: If the review agent fails or returns no parseable verdict.
    """
    from nspec.config import NspecConfig
    from nspec.orchestration.executor import resolve_executor

    if project_root is None:
        project_root = docs_root.parent

    # Load config
    try:
        config = NspecConfig.load(project_root)
    except Exception:
        config = NspecConfig()

    reviewer_name = config.review.agent
    timeout = config.review.timeout

    # Resolve code_root for integration mode
    code_root = config.resolve_code_root()

    # Step 1: Generate review prompt
    review_prompt = generate_review_prompt(
        spec_id,
        docs_root,
        project_root=project_root,
        base_branch=base_branch,
        uncommitted=uncommitted,
        code_root=code_root,
        test_results=test_results,
    )

    # Step 2: Resolve executor
    executor = resolve_executor(reviewer_name, config)

    # Step 3: Run the review agent
    result = executor.execute(review_prompt.prompt_text, timeout=timeout)

    if not result.success or not result.output:
        raise RuntimeError(
            f"Review agent '{reviewer_name}' failed for {spec_id}: "
            f"{result.error or 'no output returned'}"
        )

    # Step 4: Parse verdict
    verdict = parse_review_verdict(result.output)
    if verdict is None:
        raise RuntimeError(
            f"Could not parse review verdict from agent output for {spec_id}. "
            f"Agent: {reviewer_name}"
        )

    # Step 4.5: Terse-approval detection (S350)
    # If the verdict is a suspiciously terse APPROVED and the previous round
    # was NEEDS_WORK, automatically dispatch a confirmation re-review.
    terse_round_already_stored = False
    if is_terse_approval(verdict):
        prev_verdict = get_previous_round_verdict(spec_id, project_root)
        if prev_verdict is not None and prev_verdict.verdict == "NEEDS_WORK":
            current_round = _count_review_rounds(spec_id, project_root) + 1
            logger.warning(
                "S350: Terse APPROVED detected for %s round %d after "
                "NEEDS_WORK — dispatching confirmation re-review",
                spec_id,
                current_round,
            )
            # Store the terse output first (for audit trail)
            _store_raw_output(spec_id, current_round, result.output, project_root)
            terse_round_already_stored = True

            # Build and dispatch confirmation prompt
            confirmation_prompt = build_confirmation_prompt(
                original_prompt=review_prompt.prompt_text,
                previous_findings=prev_verdict.feedback,
                review_round=current_round,
            )
            confirm_result = executor.execute(confirmation_prompt, timeout=timeout)

            # Track whether the confirmation produced a "trustworthy" new
            # round whose output should be persisted at Step 5. We default
            # to False; only the success-with-substantive-verdict branch
            # below sets this to True.
            confirmation_produced_new_round = False

            if confirm_result.success and confirm_result.output:
                confirm_verdict = parse_review_verdict(confirm_result.output)
                if confirm_verdict is None:
                    # Confirmation produced output but failed to parse a verdict.
                    # The terse output was already stored above; do NOT
                    # double-store it at Step 5. We force the verdict to
                    # NEEDS_WORK because the confirmation gave us no
                    # parseable signal that the original code was correct.
                    logger.warning(
                        "S350: Confirmation re-review for %s produced unparseable "
                        "output — discarding terse APPROVED, marking NEEDS_WORK",
                        spec_id,
                    )
                    verdict = ReviewVerdict(
                        verdict="NEEDS_WORK",
                        feedback=(
                            "Confirmation re-review for terse APPROVED produced "
                            "unparseable output. Discarded the terse verdict. "
                            "Re-run /nreview to obtain a substantive verdict."
                        ),
                        raw_output=result.output,
                    )
                elif confirm_verdict.verdict == "NEEDS_WORK":
                    # AC-F3: confirmation NEEDS_WORK overrides terse APPROVED.
                    verdict = confirm_verdict
                    result = confirm_result
                    confirmation_produced_new_round = True
                    logger.info(
                        "S350: Confirmation re-review for %s returned NEEDS_WORK — "
                        "overriding terse APPROVED",
                        spec_id,
                    )
                elif is_terse_approval(confirm_verdict):
                    # AC-F4 amended (S027): confirmation APPROVED but
                    # still terse.  The confirmation prompt required
                    # per-finding analysis — a second APPROVED after
                    # that targeted prompt is legitimate, not a rubber
                    # stamp.  Forcing NEEDS_WORK here created an
                    # infinite loop for correctly-implemented specs.
                    feedback_text = confirm_verdict.feedback.strip()
                    bullet_pattern = re.compile(r"^\s*(?:[-*]|\[P[0-3]\])\s+", re.MULTILINE)
                    logger.warning(
                        "S350: Confirmation re-review for %s returned terse "
                        "APPROVED (double-terse) — accepting per amended "
                        "AC-F4. Audit: confirmation feedback was %d chars, "
                        "%d bullets",
                        spec_id,
                        len(feedback_text),
                        len(bullet_pattern.findall(feedback_text)),
                    )
                    verdict = confirm_verdict
                    result = confirm_result
                    confirmation_produced_new_round = True
                else:
                    # AC-F4 positive: confirmation APPROVED with substantive
                    # findings. Accept the new verdict.
                    verdict = confirm_verdict
                    result = confirm_result
                    confirmation_produced_new_round = True
                    logger.info(
                        "S350: Confirmation re-review for %s returned substantive "
                        "APPROVED — accepting",
                        spec_id,
                    )
            else:
                # Confirmation dispatch failed. The terse output was
                # already stored; do NOT double-store. We discard the
                # terse APPROVED — a single terse APPROVED with no
                # confirmation is exactly the rubber-stamp pattern S350
                # exists to catch.
                logger.warning(
                    "S350: Confirmation re-review for %s failed (%s) — "
                    "discarding terse APPROVED, marking NEEDS_WORK",
                    spec_id,
                    confirm_result.error or "no output",
                )
                verdict = ReviewVerdict(
                    verdict="NEEDS_WORK",
                    feedback=(
                        "Confirmation re-review for terse APPROVED failed to "
                        f"dispatch: {confirm_result.error or 'no output'}. "
                        "Discarded the terse verdict. Re-run /nreview."
                    ),
                    raw_output=result.output,
                )

    # Step 5: Store raw output (isolated from implementing agent).
    # Two possible cases when terse-confirmation ran:
    #   (a) confirmation_produced_new_round=True → persist the confirmation
    #       output as a brand-new round (round N+1).
    #   (b) confirmation_produced_new_round=False → terse output is already
    #       stored at round N; the verdict has been forced to NEEDS_WORK
    #       (with synthetic feedback) and there is no new agent output to
    #       persist. Reuse the terse round's path so the recorded
    #       raw_output_path always points to a real file on disk.
    if terse_round_already_stored:
        if confirmation_produced_new_round:
            review_round = _count_review_rounds(spec_id, project_root) + 1
            output_path = _store_raw_output(spec_id, review_round, result.output, project_root)
        else:
            review_round = _count_review_rounds(spec_id, project_root)
            output_path = _review_output_dir(project_root) / f"{spec_id}-{review_round}.txt"
    else:
        review_round = _count_review_rounds(spec_id, project_root) + 1
        output_path = _store_raw_output(spec_id, review_round, result.output, project_root)

    # Step 6: Write verdict to IMPL
    write_review_to_impl(
        spec_id,
        verdict,
        reviewer_name,
        implementer,
        docs_root,
        project_root=project_root,
    )

    return AtomicReviewResult(
        spec_id=spec_id,
        verdict=verdict.verdict,
        findings=verdict.feedback,
        review_round=review_round,
        reviewer=reviewer_name,
        raw_output_path=str(output_path),
    )
