"""Context budget audit for CLAUDE.md files.

Parses a CLAUDE.md into ``##``-level sections, classifies each as
**behavioral** (conventions, invariants, AI guidance) or **reference**
(tables, command lists, directory trees, dependency inventories), and
reports budget utilization with extraction recommendations.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------

CHARS_PER_TOKEN = 4  # simple heuristic


def estimate_tokens(text: str) -> int:
    """Estimate token count using a 4-chars-per-token heuristic."""
    return max(1, len(text) // CHARS_PER_TOKEN)


# ---------------------------------------------------------------------------
# Section classification heuristics
# ---------------------------------------------------------------------------

# Keywords/patterns that suggest *reference* content (tables, inventories,
# command lists, file trees, dependency lists).
_REFERENCE_SIGNALS: list[tuple[str, float]] = [
    # Markdown table rows (e.g., "| col | col |")
    (r"^\|.*\|.*\|", 0.3),
    # Fenced code blocks with shell commands / file listings
    (r"^```", 0.15),
    # Bullet items that look like file paths
    (r"^\s*[-*]\s+`?[\w/]+\.(py|ts|js|md|toml|yaml|json)`?", 0.2),
    # Lines that are mostly whitespace + a path or command
    (r"^\s{2,}\S+\s", 0.05),
]

# Section *titles* that strongly suggest reference content.
_REFERENCE_TITLE_KEYWORDS: set[str] = {
    "file map",
    "make targets",
    "quick reference",
    "tool quick reference",
    "configuration",
    "troubleshooting",
    "releasing",
    "dependencies",
    "tech stack",
    "endpoints",
    "api reference",
    "changelog",
    "environment variables",
}

# Section titles that strongly suggest behavioral content.
_BEHAVIORAL_TITLE_KEYWORDS: set[str] = {
    "philosophy",
    "core workflow",
    "critical rules",
    "rules",
    "conventions",
    "invariants",
    "commit format",
    "commit message rules",
    "trust model",
    "active work tracking",
    "progress tracking",
    "review process",
}


def _compute_reference_score(title: str, lines: list[str]) -> float:
    """Return 0.0..1.0 indicating how "reference-like" a section is.

    Higher score = more reference material. Lower = more behavioral.
    """
    title_lower = title.lower().strip()

    # Strong title signal
    for kw in _REFERENCE_TITLE_KEYWORDS:
        if kw in title_lower:
            return 0.85

    for kw in _BEHAVIORAL_TITLE_KEYWORDS:
        if kw in title_lower:
            return 0.15

    # Content-based scoring
    if not lines:
        return 0.5

    total = len(lines)
    score = 0.0

    for pattern, weight in _REFERENCE_SIGNALS:
        matches = sum(1 for line in lines if re.search(pattern, line, re.MULTILINE))
        score += weight * (matches / total)

    # Clamp
    return min(1.0, max(0.0, score))


REFERENCE_THRESHOLD = 0.5  # score >= this ⇒ classified as reference


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class SectionInfo:
    """One ``##``-level section from a CLAUDE.md."""

    title: str
    line_start: int  # 1-based
    line_count: int
    content: str
    token_count: int
    classification: str  # "behavioral" | "reference"
    reference_score: float
    suggested_filename: str | None = None


@dataclass
class ContextAuditResult:
    """Full audit result for a CLAUDE.md file."""

    file_path: str
    total_lines: int
    total_tokens: int
    sections: list[SectionInfo] = field(default_factory=list)
    behavioral_lines: int = 0
    reference_lines: int = 0
    behavioral_pct: float = 0.0
    reference_pct: float = 0.0
    threshold: float = 0.5
    recommendations: list[dict[str, str | int]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Section parsing
# ---------------------------------------------------------------------------

_H2_RE = re.compile(r"^##\s+(.+)$")


def _parse_sections(text: str) -> list[tuple[str, int, list[str]]]:
    """Parse text into (title, 1-based-start-line, content-lines) tuples."""
    lines = text.splitlines()
    sections: list[tuple[str, int, list[str]]] = []
    current_title: str | None = None
    current_start = 0
    current_lines: list[str] = []

    # Capture preamble (before first ##)
    preamble_lines: list[str] = []

    for i, line in enumerate(lines):
        m = _H2_RE.match(line)
        if m:
            # Save previous section
            if current_title is not None:
                sections.append((current_title, current_start, current_lines))
            elif preamble_lines:
                # Save preamble as a virtual section
                sections.append(("(preamble)", 1, preamble_lines))

            current_title = m.group(1).strip()
            current_start = i + 1  # 1-based
            current_lines = []
        elif current_title is not None:
            current_lines.append(line)
        else:
            preamble_lines.append(line)

    # Save last section
    if current_title is not None:
        sections.append((current_title, current_start, current_lines))
    elif preamble_lines:
        sections.append(("(preamble)", 1, preamble_lines))

    return sections


def _suggest_filename(title: str) -> str:
    """Convert a section title to a suggested docs/ filename."""
    slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
    return f"docs/{slug}.md"


# ---------------------------------------------------------------------------
# Main audit entry point
# ---------------------------------------------------------------------------


def run_context_audit(
    file_path: str | Path,
    threshold: float = 0.5,
) -> ContextAuditResult:
    """Analyze a CLAUDE.md file for context budget efficiency.

    Args:
        file_path: Path to the CLAUDE.md file.
        threshold: Reference-content percentage above which extractions
            are recommended (0.0-1.0, default 0.5).

    Returns:
        ContextAuditResult with per-section analysis and recommendations.

    Raises:
        FileNotFoundError: If the file does not exist.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    text = path.read_text(encoding="utf-8")
    total_lines = len(text.splitlines())
    total_tokens = estimate_tokens(text)

    raw_sections = _parse_sections(text)

    sections: list[SectionInfo] = []
    behavioral_lines = 0
    reference_lines = 0

    for title, start, lines in raw_sections:
        # Real sections have a ## header line; preamble does not
        has_header = title != "(preamble)"
        line_count = len(lines) + (1 if has_header else 0)
        content = "\n".join(lines)
        tokens = estimate_tokens(content)
        ref_score = _compute_reference_score(title, lines)
        classification = "reference" if ref_score >= REFERENCE_THRESHOLD else "behavioral"

        si = SectionInfo(
            title=title,
            line_start=start,
            line_count=line_count,
            content=content,
            token_count=tokens,
            classification=classification,
            reference_score=ref_score,
            suggested_filename=_suggest_filename(title) if classification == "reference" else None,
        )
        sections.append(si)

        if classification == "reference":
            reference_lines += line_count
        else:
            behavioral_lines += line_count

    # Compute percentages
    if total_lines > 0:
        behavioral_pct = behavioral_lines / total_lines
        reference_pct = reference_lines / total_lines
    else:
        behavioral_pct = 0.0
        reference_pct = 0.0

    # Build recommendations (reference sections sorted by size, descending)
    recommendations: list[dict[str, str | int]] = []
    if reference_pct > threshold:
        ref_sections = sorted(
            [s for s in sections if s.classification == "reference"],
            key=lambda s: s.line_count,
            reverse=True,
        )
        for s in ref_sections:
            recommendations.append(
                {
                    "section": s.title,
                    "lines": s.line_count,
                    "suggested_path": s.suggested_filename or _suggest_filename(s.title),
                }
            )

    return ContextAuditResult(
        file_path=str(path),
        total_lines=total_lines,
        total_tokens=total_tokens,
        sections=sections,
        behavioral_lines=behavioral_lines,
        reference_lines=reference_lines,
        behavioral_pct=behavioral_pct,
        reference_pct=reference_pct,
        threshold=threshold,
        recommendations=recommendations,
    )


# ---------------------------------------------------------------------------
# Text formatting (CLI output)
# ---------------------------------------------------------------------------


def format_audit_report(result: ContextAuditResult) -> str:
    """Format an audit result as human-readable text for CLI output."""
    lines: list[str] = []

    lines.append(
        f"{result.file_path}: {result.total_lines} lines (~{result.total_tokens:,} tokens)"
    )

    # Group sections by classification for summary
    behavioral_names = [s.title for s in result.sections if s.classification == "behavioral"]
    reference_items = [
        f"{s.title} ({s.line_count})" for s in result.sections if s.classification == "reference"
    ]

    beh_summary = ", ".join(behavioral_names[:4])
    if len(behavioral_names) > 4:
        beh_summary += f", +{len(behavioral_names) - 4} more"

    ref_summary = ", ".join(reference_items[:4])
    if len(reference_items) > 4:
        ref_summary += f", +{len(reference_items) - 4} more"

    lines.append(
        f"  Behavioral:  {result.behavioral_lines} lines "
        f"({result.behavioral_pct:.0%}) — {beh_summary}"
    )
    lines.append(
        f"  Reference:   {result.reference_lines} lines "
        f"({result.reference_pct:.0%}) — {ref_summary}"
    )

    if result.recommendations:
        lines.append("")
        lines.append(
            f"  Reference content exceeds {result.threshold:.0%} — consider extracting to docs/:"
        )
        for i, rec in enumerate(result.recommendations, 1):
            lines.append(
                f"    {i}. {rec['section']:<30s} {rec['lines']:>3} lines  → {rec['suggested_path']}"
            )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Structured output (MCP tool)
# ---------------------------------------------------------------------------


def audit_to_dict(result: ContextAuditResult) -> dict:
    """Convert audit result to a plain dict for MCP/JSON consumption."""
    return {
        "file_path": result.file_path,
        "total_lines": result.total_lines,
        "total_tokens": result.total_tokens,
        "behavioral_lines": result.behavioral_lines,
        "reference_lines": result.reference_lines,
        "behavioral_pct": round(result.behavioral_pct, 3),
        "reference_pct": round(result.reference_pct, 3),
        "threshold": result.threshold,
        "sections": [
            {
                "title": s.title,
                "line_start": s.line_start,
                "line_count": s.line_count,
                "token_count": s.token_count,
                "classification": s.classification,
                "reference_score": round(s.reference_score, 3),
                "suggested_filename": s.suggested_filename,
            }
            for s in result.sections
        ],
        "recommendations": result.recommendations,
        "over_threshold": result.reference_pct > result.threshold,
    }
