"""MCP query tools — read-only operations."""

from __future__ import annotations

import subprocess
from typing import Any

from nspec.interfaces.mcp._helpers import (
    _discover_epics_on_disk,
    _exception_error,
    _invalid_id_error,
    _normalize_epic_id,
    _resolve_docs_root,
    _resolve_id,
    _resolve_id_from_disk,
    _resolve_project_root,
    _tool_error,
)
from nspec.interfaces.mcp.server import mcp


@mcp.tool()
def epics(docs_root: str | None = None) -> dict[str, Any]:
    """List all epics with progress tracking.

    Shows epic ID, priority, title, and completion percentages
    for specs grouped under each epic.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.reporting.reports import ReportContext, epic_summary_report

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        ctx = ReportContext.load(root, project_root=project_root)
        return epic_summary_report(ctx)
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def show(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Show full details for a spec (FR + IMPL).

    Returns title, priority, status, acceptance criteria,
    tasks, dependencies, and completion progress.

    Args:
        spec_id: ID (e.g., "S004", "E001", or bare number like "004")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.domain.datasets import DatasetLoader

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        loader = DatasetLoader(root, project_root=project_root)
        datasets = loader.load()
    except Exception as e:
        return _exception_error(e)

    try:
        spec_id = _resolve_id(spec_id, datasets.all_spec_ids())
    except ValueError:
        return _invalid_id_error(spec_id)

    fr = datasets.get_fr(spec_id)
    impl = datasets.get_impl(spec_id)

    if not fr and not impl:
        return {"error": f"Spec {spec_id} not found"}

    result: dict[str, Any] = {"spec_id": spec_id}

    if fr:
        result["fr"] = {
            "title": fr.title,
            "priority": fr.priority,
            "status": fr.status,
            "deps": fr.deps,
            "ac_completion": fr.ac_completion_percent,
        }

    if impl:
        result["impl"] = {
            "status": impl.status,
            "loe": impl.loe,
            "completion": impl.completion_percent,
        }

    result["is_active"] = datasets.is_active(spec_id)
    return result


@mcp.tool()
def next_spec(epic_id: str | None = None, docs_root: str | None = None) -> dict[str, Any]:
    """Find the next spec to work on based on priority and blockers.

    Returns the highest-priority unblocked spec, optionally
    filtered to a specific epic.

    Args:
        epic_id: Optional epic ID to filter by
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.domain.datasets import DatasetLoader
    from nspec.domain.ordering import eligible_next_specs
    from nspec.reporting.reports import ReportContext, blockers_report

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        loader = DatasetLoader(root, project_root=project_root)
        datasets = loader.load()
    except Exception as e:
        return _exception_error(e)

    # Normalize epic_id if provided
    if epic_id:
        normalized, error = _normalize_epic_id(epic_id, root)
        if error:
            return error
        assert normalized is not None
        epic_id = normalized

        epic_fr = datasets.get_fr(epic_id)
        if not epic_fr:
            return _tool_error(f"Epic {epic_id} not found")
        if not epic_fr.is_epic:
            return _tool_error(f"{epic_id} is not an Epic (missing **Type:** Epic)")

    # Get blocked spec IDs
    ctx = ReportContext(datasets=datasets, docs_root=root)
    blockers = blockers_report(ctx)
    blocked_ids: set[str] = set()
    for section in blockers.get("sections", []):
        if section.get("type") == "blockers":
            for b in section.get("data", []):
                blocked_ids.add(b["id"])

    # Exclude checked-out specs
    try:
        from nspec.runtime.session import CheckoutDAO

        co_dao = CheckoutDAO(_resolve_project_root(root))
        co_dao.reap_expired()
        checked_out_ids = set(co_dao.list_active().keys())
        blocked_ids |= checked_out_ids
    except Exception:
        pass  # Best-effort

    candidates = eligible_next_specs(datasets, epic_id=epic_id, blocked_ids=blocked_ids)

    if not candidates:
        return {"message": "No unblocked specs found", "candidates": []}

    return {"next": candidates[0], "alternatives": candidates[1:5]}


@mcp.tool()
def get_epic(docs_root: str | None = None) -> dict[str, Any]:
    """Get the currently active epic from the active session.

    Falls back to disk discovery when no session epic is set,
    so callers always see available epics even without a session.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import SessionDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    dao = SessionDAO(project_root)
    try:
        epic = dao.get_active_epic()
    except Exception as e:
        return {"active_epic": None, "error": str(e)}
    if epic:
        return {"active_epic": epic}

    # Fall back to disk discovery: scan for epic FRs on disk
    available = _discover_epics_on_disk(root)
    result: dict[str, Any] = {"active_epic": None}
    if available:
        result["available_epics"] = available
        result["message"] = (
            "No active epic set in session. "
            f"Found {len(available)} epic(s) on disk. "
            "Use activate(epic_id) to set one."
        )
    else:
        result["message"] = "No active epic set and no epic files found on disk"
    return result


@mcp.tool()
def validate(docs_root: str | None = None) -> dict[str, Any]:
    """Run the 6-layer validation engine on all specs.

    Checks format, existence, dependencies, business logic,
    and ordering across all FR and IMPL documents.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.validation.validator import NspecValidator

    root = _resolve_docs_root(docs_root)

    # Read enforce_epic_grouping from config
    strict_mode = False
    try:
        from nspec.config import NspecConfig

        project_root = _resolve_project_root(root)
        config = NspecConfig.load(project_root)
        strict_mode = config.validation.enforce_epic_grouping
    except Exception:
        pass

    validator = NspecValidator(root, strict_mode=strict_mode)
    try:
        success, errors = validator.validate()
    except Exception as e:
        return {"valid": False, "error_count": 1, "errors": [str(e)], "structured_errors": []}

    structured = [
        {
            "layer": ve.layer,
            "message": ve.message,
            "spec_id": ve.spec_id,
            "severity": ve.severity,
            "code": ve.code,
        }
        for ve in getattr(validator, "structured_errors", [])[:50]
    ]

    return {
        "valid": success,
        "error_count": len(errors),
        "errors": errors[:50],  # Cap at 50 to avoid huge responses
        "structured_errors": structured,
    }


@mcp.tool()
def estimate_loe(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Estimate Level of Effort for a spec.

    Computes a weighted score from task structure, dependency count,
    and complexity signals. Uses historical data for calibration
    when enough completed specs exist.

    Args:
        spec_id: Spec ID to estimate (e.g., "S004")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.config import NspecConfig
    from nspec.domain.datasets import DatasetLoader
    from nspec.domain.ids import normalize_spec_ref
    from nspec.domain.loe import LoeWeights, estimate_spec_loe

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        config = NspecConfig.load(project_root)
    except Exception:
        config = NspecConfig()

    try:
        spec_id = normalize_spec_ref(spec_id)
    except (ValueError, KeyError):
        return {"success": False, "error": f"Invalid spec ID: {spec_id}"}

    loader = DatasetLoader(docs_root=root, project_root=project_root)
    datasets = loader.load()

    fr = datasets.get_fr(spec_id)
    impl = datasets.get_impl(spec_id)
    if fr is None:
        return {"success": False, "error": f"FR not found for {spec_id}"}
    if impl is None:
        return {"success": False, "error": f"IMPL not found for {spec_id}"}

    weights = LoeWeights(
        task_count=config.loe.weight_task_count,
        max_depth=config.loe.weight_max_depth,
        nested_ratio=config.loe.weight_nested_ratio,
        dep_count=config.loe.weight_dep_count,
        complexity_signal=config.loe.weight_complexity_signal,
        min_history_specs=config.loe.min_history_specs,
    )

    try:
        estimate = estimate_spec_loe(
            spec_id=spec_id,
            fr=fr,
            impl=impl,
            weights=weights,
            completed_impls=datasets.completed_impls,
            completed_frs=datasets.completed_frs,
        )
        result = estimate.to_dict()
        result["success"] = True
        return result
    except Exception as e:
        return _exception_error(e)


@mcp.tool()
def preflight(spec_id: str, docs_root: str | None = None) -> dict[str, Any]:
    """Pre-flight state snapshot for a spec before /ngo execution.

    Aggregates spec status, task progress, dependency resolution status,
    current git branch, worktree cleanliness, and detected anomalies into
    a compact summary dict. Designed to be called before Phase 3 (activate)
    and interpretable after Phase 7 (complete) for post-flight verification.

    Args:
        spec_id: Spec ID to inspect (e.g., "S351")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.domain.datasets import DatasetLoader

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        loader = DatasetLoader(root, project_root=project_root)
        datasets = loader.load()
    except Exception as e:
        return _exception_error(e)

    try:
        spec_id = _resolve_id(spec_id, datasets.all_spec_ids())
    except ValueError:
        return _invalid_id_error(spec_id)

    fr = datasets.get_fr(spec_id)
    impl = datasets.get_impl(spec_id)

    if not fr and not impl:
        return {"error": f"Spec {spec_id} not found"}

    result: dict[str, Any] = {"spec_id": spec_id}
    anomalies: list[str] = []

    # --- Spec state ---
    if fr:
        result["title"] = fr.title
        result["priority"] = fr.priority
        result["fr_status"] = fr.status
        result["deps"] = fr.deps
        result["ac_total"] = fr.ac_total
        result["ac_completed"] = fr.ac_completed

    if impl:
        result["impl_status"] = impl.status
        result["tasks_total"] = impl.tasks_total
        result["tasks_completed"] = impl.tasks_completed
        result["completion_pct"] = impl.completion_percent
        result["loe"] = impl.loe

    result["is_active"] = datasets.is_active(spec_id)

    # --- Dependency resolution ---
    dep_statuses: list[dict[str, str]] = []
    if fr and fr.deps:
        for dep_id in fr.deps:
            dep_fr = datasets.get_fr(dep_id)
            if dep_fr is None:
                dep_statuses.append({"dep_id": dep_id, "status": "missing"})
                anomalies.append(f"Dependency {dep_id} not found in any dataset")
            elif datasets.is_active(dep_id):
                dep_statuses.append({"dep_id": dep_id, "status": "active"})
            else:
                dep_statuses.append({"dep_id": dep_id, "status": "completed"})
    result["dep_statuses"] = dep_statuses

    # --- Git state ---
    try:
        branch_result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            cwd=str(project_root),
            timeout=5,
        )
        result["git_branch"] = (
            branch_result.stdout.strip() if branch_result.returncode == 0 else "unknown"
        )
    except Exception:
        result["git_branch"] = "unknown"

    try:
        status_result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True,
            text=True,
            cwd=str(project_root),
            timeout=10,
        )
        if status_result.returncode == 0:
            dirty_lines = [
                line for line in status_result.stdout.strip().split("\n") if line.strip()
            ]
            result["dirty_file_count"] = len(dirty_lines)
            # Flag unrelated dirty files (not matching spec ID)
            spec_num = spec_id.lstrip("SE")
            unrelated = [
                line for line in dirty_lines if spec_num not in line and spec_id not in line
            ]
            result["unrelated_dirty_count"] = len(unrelated)
        else:
            result["dirty_file_count"] = -1
            result["unrelated_dirty_count"] = -1
    except Exception:
        result["dirty_file_count"] = -1
        result["unrelated_dirty_count"] = -1

    # --- Anomaly detection ---
    # Check if spec is already beyond expected pre-activate status
    if impl:
        status_lower = impl.status.lower()
        if "active" in status_lower:
            anomalies.append("Spec already Active (expected Planning/Proposed for pre-flight)")
        elif "testing" in status_lower:
            anomalies.append("Spec already in Testing (expected Planning/Proposed for pre-flight)")
        elif "ready" in status_lower or "completed" in status_lower:
            anomalies.append(f"Spec already at {impl.status} — may have been completed previously")

    if result.get("unrelated_dirty_count", 0) > 10:
        anomalies.append(f"{result['unrelated_dirty_count']} unrelated dirty files in worktree")

    result["anomalies"] = anomalies
    result["anomaly_count"] = len(anomalies)

    return result


@mcp.tool()
def session_start(spec_id: str, docs_root: str | None = None) -> str:
    """Initialize a work session for a spec.

    Shows where work left off, pending tasks, blockers,
    and suggested first action.

    Args:
        spec_id: Spec ID to start working on
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.session import initialize_session

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return f"\u274c Invalid ID: {spec_id!r} (expected E###, S###, or bare number)"
    try:
        result = initialize_session(spec_id, root)
        # Reset error agent session counter at session start
        try:
            from nspec.orchestration.error_agent import reset_session_counter

            reset_session_counter()
        except Exception:
            pass
        return result
    except Exception as e:
        return f"\u274c {e}"
