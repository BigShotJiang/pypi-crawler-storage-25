"""Protocol discovery and evaluation engine."""
from __future__ import annotations

import datetime
import hashlib
import json
import subprocess
import time
from pathlib import Path
from typing import Any

from kanon_core._manifest import _aspect_path, _aspect_protocols, _parse_frontmatter


def discover_protocols(aspects: dict[str, int], target: Path | None = None) -> list[dict[str, Any]]:
    """Discover all active protocols from frontmatter, filtered by depth.

    Returns a unified list: former hard-gates (with shell checks or judgment questions)
    and soft protocols are merged into a single priority-ordered sequence. Each item
    carries a ``condition`` dict with ``mode: "auto" | "agent"``.
    """
    protocols: list[dict[str, Any]] = []
    for aspect, depth in aspects.items():
        if target is not None:
            protocols_dir = target / ".kanon" / "aspects" / aspect / "protocols"
        else:
            protocols_dir = _aspect_path(aspect) / "protocols"
        for proto_file in _aspect_protocols(aspect, depth):
            proto_path = protocols_dir / proto_file
            if not proto_path.exists():
                continue
            fm = _parse_frontmatter(proto_path.read_text(encoding="utf-8"))
            if depth < fm.get("depth-min", 1):
                continue
            is_hard = fm.get("gate") == "hard"
            has_check = fm.get("check") is not None
            # Validate required frontmatter fields.
            warnings: list[str] = []
            if "depth-min" not in fm:
                warnings.append("missing frontmatter field: depth-min")
            if not is_hard and "invoke-when" not in fm:
                warnings.append("missing frontmatter field: invoke-when")
            entry: dict[str, Any] = {
                "id": proto_file.removesuffix(".md"),
                "label": fm.get("label", proto_file.removesuffix(".md").replace("-", " ").title()),
                "aspect": aspect,
                "priority": fm.get("priority", 500),
                "protocol": f".kanon/aspects/{aspect}/protocols/{proto_file}",
                "audit": fm.get("audit", ""),
                "warnings": warnings,
            }
            if is_hard and has_check:
                entry["condition"] = {"mode": "auto", "expr": fm["check"]}
                entry["instructions"] = fm.get("summary", "")
            elif is_hard:
                entry["condition"] = {
                    "mode": "agent",
                    "applies_when": fm.get("question", ""),
                    "skip_when": fm.get("skip-when", ""),
                }
                entry["instructions"] = fm.get("summary", "")
            else:
                entry["condition"] = {
                    "mode": "agent",
                    "applies_when": fm.get("invoke-when", ""),
                    "skip_when": "",
                }
                entry["instructions"] = fm.get("summary", fm.get("invoke-when", ""))
            protocols.append(entry)
    protocols.sort(key=lambda p: p["priority"])
    return protocols


def evaluate_protocols(
    protocols: list[dict[str, Any]], target: Path, *, fail_fast: bool = False
) -> list[dict[str, Any]]:
    """Evaluate protocol conditions. Auto-mode runs shell checks; agent-mode passes through."""
    results: list[dict[str, Any]] = []
    for proto in protocols:
        result: dict[str, Any] = {
            "id": proto["id"],
            "label": proto["label"],
            "aspect": proto["aspect"],
            "priority": proto["priority"],
            "protocol": proto["protocol"],
            "instructions": proto.get("instructions", ""),
            "audit": proto.get("audit", ""),
        }
        condition = proto["condition"]
        if condition["mode"] == "auto":
            start = time.monotonic()
            try:
                proc = subprocess.run(
                    condition["expr"],
                    shell=True,  # noqa: S602 — ADR-0036 trust model
                    cwd=str(target),
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                status = "pass" if proc.returncode == 0 else "fail"
            except subprocess.TimeoutExpired:
                status = "fail"
            duration = round(time.monotonic() - start, 3)
            result["condition"] = {"mode": "auto", "status": status, "duration_s": duration}
        else:
            result["condition"] = {
                "mode": "agent",
                "applies_when": condition.get("applies_when", ""),
                "skip_when": condition.get("skip_when", ""),
            }
        results.append(result)
        if fail_fast and result["condition"].get("status") == "fail":
            break
    return results


def write_trace(target: Path, results: list[dict[str, Any]]) -> str:
    """Append invocation trace to .kanon/traces/protocols.jsonl. Returns the audit token."""
    traces_dir = target / ".kanon" / "traces"
    traces_dir.mkdir(parents=True, exist_ok=True)
    trace_file = traces_dir / "protocols.jsonl"
    ts = datetime.datetime.now(datetime.timezone.utc).isoformat()
    entry = {
        "ts": ts,
        "cwd": str(Path.cwd()),
        "protocols": [
            {"id": r["id"], "status": r["condition"].get("status", "agent")}
            for r in results
        ],
        "passed": all(
            r["condition"].get("status") != "fail" for r in results
        ),
    }
    raw = ts + json.dumps(entry["protocols"], sort_keys=True)
    token = hashlib.sha256(raw.encode()).hexdigest()[:16]
    entry["token"] = token
    with trace_file.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
    return token
