# Testing Method

## Rationale

Agents produce code faster than humans can review it. Without test discipline, this speed creates a growing pool of unverified behavior — code that "looks right" but has never been proven correct. Tests are the only scalable mechanism for maintaining confidence as velocity increases.

The deeper insight: tests written *after* implementation tend to mirror the implementation (testing what was built, not what was intended). Tests written *before* implementation force the agent to articulate intent first — making the test a specification, not a verification.

## Model

Three layers of test discipline, activated by depth:

```
Depth 1: Test accompaniment
  Every code change has a corresponding test. No silent deletions.
         │
Depth 2: AC-first TDD
  Acceptance criteria → failing test → implementation → green
         │
Depth 3: Test quality
  No trivial assertions. Boundary coverage. Mutation-awareness.
```

Each layer builds on the previous. Depth 2 doesn't replace depth 1 — it adds a sequencing constraint (test before code). Depth 3 doesn't replace depth 2 — it adds a quality bar on the tests themselves.

## Workflows

### Standard flow (depth 1)

1. Identify the behavior being added or changed.
2. Write a test that exercises that behavior.
3. Implement until the test passes.
4. Verify no existing tests broke.

### AC-first flow (depth 2)

1. Read the plan's acceptance criteria.
2. For each testable AC, write a failing test assertion.
3. Confirm tests fail for the right reason (behavior absent, not setup error).
4. Implement the feature.
5. Confirm all AC tests pass.
6. Add edge-case tests if the implementation revealed complexity.

### Error diagnosis flow (any depth)

1. Reproduce the failure (exact command, exact output).
2. Isolate: is it the test, the code, or the environment?
3. Identify root cause (not symptom).
4. Fix the cause.
5. Verify the fix (original failure gone, no new failures).

## Worked Examples

| Scenario | Depth 1 action | Depth 2 action |
|----------|---------------|----------------|
| Add a new CLI flag | Write test exercising the flag | Write test from spec's AC first, then implement |
| Fix off-by-one bug | Write regression test proving the fix | Same (no AC exists for bugs) |
| Refactor internal function | Verify existing tests still pass | Same (refactors don't change behavior) |
| New validation rule | Write test with valid + invalid inputs | Write failing test from AC: "rejects X, accepts Y" |

## Glossary

- **Acceptance criterion (AC):** A testable statement from a spec or plan that defines "done" for a specific behavior.
- **AC-first TDD:** Writing the test assertion derived from an AC before writing the implementation that satisfies it.
- **Regression test:** A test added alongside a bug fix that would have caught the bug, preventing recurrence.
- **Test level:** Unit (isolated function), integration (multiple components), E2E (installed artifact as subprocess).
- **Coverage floor:** A configured minimum percentage (advisory) that consumers wire into their CI.
- **Mutation-awareness:** Writing tests specific enough that mutating the implementation (changing operators, removing lines) causes test failure.
