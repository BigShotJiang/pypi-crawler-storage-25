---
status: draft
date: YYYY-MM-DD
implements: docs/specs/<spec>.md
---
# Design: <Title>

> **Use this when:** change introduces new component boundaries or cross-cutting mechanisms.

## Context

<Which spec does this implement? What constraints shape the design?>

## Architecture

<Components, data flow, state model. Diagrams welcome (Mermaid).>

## Interfaces

<Public boundaries: function signatures, module exports, CLI surface, file paths.>

## Failure Modes

*What breaks if this component is unavailable or misbehaves?*

## Operational Concerns

*Monitoring, alerting, capacity signals.*

## Rollback Strategy

*How to revert without data loss.*

## Decisions

<Links to ADRs capturing non-obvious design decisions made here.>
