# Personas

Design-stressing user scenarios. Each persona carries a `stresses:` list pointing at the specs and principles it exercises.

## Index

*(empty — add personas as the project identifies design-stressing users)*
