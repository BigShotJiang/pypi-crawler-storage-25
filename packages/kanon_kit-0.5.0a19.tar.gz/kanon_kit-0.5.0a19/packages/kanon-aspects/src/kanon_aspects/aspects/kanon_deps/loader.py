"""Aspect manifest loader (ADR-0055)."""
from kanon_aspects import load_manifest

MANIFEST = load_manifest(__package__)
