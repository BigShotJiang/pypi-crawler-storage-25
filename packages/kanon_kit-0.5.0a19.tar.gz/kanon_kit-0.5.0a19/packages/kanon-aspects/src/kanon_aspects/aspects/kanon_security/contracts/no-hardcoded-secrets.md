---
contract-id: kanon-security/no-hardcoded-secrets
semantic-version: "1.0"
surface: preflight.push
realization-shape:
  verbs: [scan]
  evidence-kinds: [source-analysis]
  stages: [push]
kanon-dialect: "2026-05-01"
---
# Contract: no-hardcoded-secrets

## Obligation

Source code MUST NOT contain hardcoded secrets (API keys, passwords, tokens, private keys). Secrets must be loaded from environment variables or secure stores at runtime.

## What the resolver must determine

1. **Secret patterns** — scan source for common secret patterns (API keys, tokens, passwords)
2. **Configuration** — verify secrets are referenced by name, not by value
3. **Exclusions** — test fixtures with fake/example values are acceptable

## Staleness

This resolution is stale when:

- New secret-consuming code is added
- The secret management approach changes
