---
contract-id: kanon-fidelity/fidelity-fixtures-pass
semantic-version: "1.0"
surface: preflight.push
realization-shape:
  verbs: [invoke]
  evidence-kinds: [test-output]
  stages: [push]
kanon-dialect: "2026-05-01"
---
# Contract: fidelity-fixtures-pass

## Obligation

All fidelity fixtures MUST pass lexical assertion matching against their paired dogfood captures. Protocol prose changes require fixture recapture.

## What the resolver must determine

1. **Fixture validity** — do all `.yaml` fixtures in `.kanon/fidelity/` parse correctly?
2. **Assertion pass** — do lexical assertions match the paired `.dogfood.md` captures?
3. **Recapture currency** — are dogfood captures newer than their protocol's last prose change?

## Staleness

This resolution is stale when:

- Protocol prose is modified without recapturing the dogfood
- Fixture assertions are weakened
