# Fidelity Method

## Rationale

Structural verification (`kanon verify`) confirms that artifacts exist — files are present, markers balance, hashes match. But it cannot detect whether an agent that *read* a protocol actually *followed* it. An agent can emit "Plan at docs/plans/foo.md has been approved" without ever writing that plan.

Fidelity closes this gap by asserting on agent *transcripts* — the actual text the agent produced during a session. If the protocol says "emit an audit sentence," fidelity proves the sentence appeared. This is behavioral verification: not "did the file get created?" but "did the agent demonstrate the reasoning the protocol requires?"

## Model

```
Protocol prose (defines required behavior)
         │
         ▼
Fidelity fixture (declares patterns that prove compliance)
         │
         ▼
Agent transcript (the actual session output)
         │
         ▼
Lexical assertion engine (matches patterns against transcript)
         │
         ▼
Pass/Fail (deterministic, no LLM involved)
```

The key property: fidelity checking is **deterministic**. It uses regex and substring matching — no LLM judges whether the agent "meant well." Either the pattern appears in the transcript or it doesn't.

## Workflows

### Authoring a new fixture

1. Identify the protocol whose compliance you want to verify.
2. Determine what observable text the agent MUST produce if it followed the protocol (audit sentences, file-creation confirmations, reasoning steps).
3. Write a YAML fixture declaring those patterns as assertions.
4. Pair it with a dogfood capture (a real transcript segment where the protocol was followed correctly).
5. Run the assertion engine against the dogfood to confirm the fixture passes.

### Recapturing after protocol changes

1. Protocol prose is modified (new audit sentence, changed wording).
2. Existing fixtures may now fail against new-style transcripts.
3. Re-run the protocol with the new prose, capture a fresh dogfood.
4. Update fixture assertions if the required patterns changed.
5. Verify: old dogfood fails (expected), new dogfood passes.

### Interpreting failures

- **Fixture fails on a real transcript:** The agent didn't follow the protocol. Fix the agent behavior (or the orchestration that invokes it), not the fixture.
- **Fixture fails on a dogfood after protocol edit:** The fixture is stale. Recapture.
- **Fixture passes on a transcript where the agent clearly didn't comply:** The assertions are too broad. Tighten them.

## Worked Examples

| Scenario | Fixture assertion | Why it works |
|----------|-------------------|--------------|
| Plan-before-build compliance | `"Plan at .+ has been approved"` (regex) | The audit sentence is only emitted after the agent writes and references a plan |
| Worktree isolation | `"Working in worktree"` (substring) | The branch-hygiene protocol requires this exact phrasing |
| Spec review completed | `"Spec .+ promoted to accepted"` (regex) | Only emitted after the review protocol's exit criteria are met |

## Glossary

- **Fidelity fixture:** A YAML file at `.kanon/fidelity/<spec>/<name>.yaml` declaring assertions (regex or substring patterns) that must match in an agent transcript for a protocol to be considered followed.
- **Dogfood capture:** A `.dogfood.md` file containing a real transcript segment where the protocol was correctly followed. Paired 1:1 with its fixture for regression testing.
- **Lexical assertion:** A deterministic pattern match (regex or substring) applied to transcript text. No LLM, no fuzzy matching, no judgment.
- **Behavioral verification:** Proving an agent followed a *process* (not just produced an *artifact*). Complements structural verification.
- **Recapture:** Re-recording a dogfood after protocol prose changes, to keep the fixture aligned with current expected behavior.
