---
contract-id: kanon-sdd/plan-exists
semantic-version: "1.0"
surface: preflight.push
realization-shape:
  verbs: [file-present]
  evidence-kinds: [artifact]
  stages: [push]
kanon-dialect: "2026-05-01"
---
# Contract: plan-exists

## Obligation

Non-trivial source changes MUST have a corresponding plan at `docs/plans/<slug>.md` before implementation begins.

## What the resolver must determine

1. **Change classification** — is the change trivial (≤3 files, no protected paths) or non-trivial?
2. **Plan presence** — does a plan file exist that covers the current change?
3. **Plan approval** — has the user approved the plan (status: in-progress or done)?

## Staleness

This resolution is stale when:

- The plan's scope no longer matches the implemented change
- New files are added that weren't in the original plan
