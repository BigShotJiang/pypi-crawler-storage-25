---
status: accepted
date: 2026-04-28
depth-min: 1
invoke-when: A non-trivial source change is about to begin, or the agent is unsure whether a change is trivial
gate: hard
label: Plan Before Build
summary: non-trivial changes require an approved plan before source edits.
audit: 'Plan at `<path>` has been approved.'
priority: 100
question: 'DEFAULT: Write the plan. Skip ONLY if the change exactly matches skip-when (not "similar to" — exactly matches). Does a plan exist at `docs/plans/<slug>.md`? If not — **stop and write one now.**'
skip-when: 'Change ONLY does one of: fix a typo/spelling error, fix a single failing assertion without changing logic, rename a local variable within one function, or delete code proven unreachable by static analysis. Adding, moving, or modifying any function/class/module NEVER qualifies as trivial.'
---
# Protocol: Plan Before Build

## Purpose

Ensure every non-trivial change has an approved plan before source files are modified. The plan is the contract between the agent and the user.

## Steps

### 1. Classify the change

**Planning is the default. Enumeration is the cost of *skipping*, not of starting.** If you find yourself counting files to avoid planning, you've already spent the effort — write the plan.

A change is **non-trivial** (plan first) if any of these apply:

- touches ≥5 files (full plan required, no exceptions)
- touches 4 files (micro-plan required — see `docs/plans/_template.md` § Micro-plan)
- touches any protected path (`docs/decisions/`, `.kanon/`, `docs/specs/`) regardless of file count
- adds, removes, or pins a dependency
- changes a CLI flag, public schema, JSON/YAML shape, or protocol prose
- warrants a CHANGELOG entry
- multiple agents will collaborate on it
- you are unsure which side of this line it falls on

A change is **trivial** (act directly, no plan needed) only if it touches ≤3 files, none in protected paths, AND:

- typo in a comment or string literal
- fixing a single failing assertion with an unambiguous fix
- renaming a local variable
- deleting code the caller can prove is unreachable

### 2. Re-evaluation gate

**If during implementation you discover the change touches more files than initially enumerated, stop and create a plan before continuing.** This is not optional. Scope creep discovered mid-flight is the primary failure mode of skip-allowed changes. The re-evaluation obligation applies even if the additional files are test files.

### 3. Write the plan

Your **first output** is a plan file under `docs/plans/<slug>.md`, followed by explicit user approval. You may not call Edit, Write, or mutating Bash on source files before the user has approved the plan.

**Template:** Read `docs/plans/README.md` for guidance, then copy `docs/plans/_template.md`. Follow its structure exactly. Do not emit `<!-- kanon:` comments into your artifact.

**Approval flow:** Writing the plan file is not approval. Present the plan to the user and wait for explicit confirmation (e.g., "looks right", "approved", "go ahead and implement"). A general "go" authorizes drafting, not implementation. The user must have seen the plan content before approval counts.

### 4. State the audit sentence

**Before your first source-modifying tool call, state in one sentence:** "Plan at `<path>` has been approved." If you cannot truthfully emit that sentence, stop and plan. This sentence is the audit trail — its absence in a transcript is how violations get caught.

## Anti-patterns

- **Retroactive plans** are evidence of past violation, not a norm. Do not add to that pile.

## Exit criteria

- A plan file exists at `docs/plans/<slug>.md`.
- The user has explicitly approved the plan.
- The audit sentence has been stated before the first source-modifying tool call.
