---
contract-id: kanon-worktrees/worktree-isolation
semantic-version: "1.0"
surface: preflight.push
realization-shape:
  verbs: [branch-check]
  evidence-kinds: [git-state]
  stages: [push]
kanon-dialect: "2026-05-01"
---
# Contract: worktree-isolation

## Obligation

All file modifications MUST occur in a git worktree on a `wt/<slug>` branch. Direct commits to main are not allowed.

## What the resolver must determine

1. **Current branch** — is the active branch prefixed with `wt/`?
2. **Worktree presence** — does a corresponding `.worktrees/<slug>/` directory exist?

## Staleness

This resolution is stale when:

- The worktree has been removed but the branch still exists
- The branch naming convention changes
