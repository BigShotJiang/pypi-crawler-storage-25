<!-- Copy this file and rename to create a new principle. -->
---
id: P-<slug>
kind: technical | pedagogical | product
status: draft | accepted | superseded
date: YYYY-MM-DD
---
# <Title>

## Statement

## Rationale

## Implications

## Exceptions / Tensions

## Source
