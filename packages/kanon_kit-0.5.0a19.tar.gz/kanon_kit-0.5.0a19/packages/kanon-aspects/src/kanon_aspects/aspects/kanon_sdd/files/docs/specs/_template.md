---
status: draft
date: YYYY-MM-DD
# optional frontmatter fields — see ../foundations/README.md § Linkage to the layer stack
# realizes: [P-<slug>, ...]
# serves: [<foundation-slug>, ...]
# stressed_by: [<persona-slug>, ...]
# fixtures: [tests/path/test_name.py]
# fixtures_deferred: <reason>
---
# Spec: <Title>

> **Use this when:** introducing a new user-visible capability that needs invariants.

## Intent

<What problem does this solve? What properties must the output have?>

## Invariants

1. **INV-<spec-slug>-<name>.** <Observable property that must always hold.>

## Rationale

<Why this shape? What tradeoffs were accepted?>

## Out of Scope

- <Deliberate exclusion>

## Decisions

<Links to ADRs that captured decisions about this spec.>

<!-- kanon:backlinks --><!-- /kanon:backlinks -->
