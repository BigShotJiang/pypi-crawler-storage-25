---
contract-id: kanon-release/release-validated
semantic-version: "1.0"
surface: preflight.tag
realization-shape:
  verbs: [invoke]
  evidence-kinds: [build-config]
  stages: [tag]
kanon-dialect: "2026-05-01"
---
# Contract: release-validated

## Obligation

Every release MUST pass the full preflight suite (tests, lint, kanon verify) before tagging. No release may be tagged from a dirty tree or with failing checks.

## What the resolver must determine

1. **Preflight pass** — did all checks (tests, lint, verify) pass?
2. **Clean tree** — is the working tree clean (no uncommitted changes)?
3. **Changelog** — does the changelog have an entry for this version?

## Staleness

This resolution is stale when:

- The preflight suite changes (new checks added)
- The release workflow changes
