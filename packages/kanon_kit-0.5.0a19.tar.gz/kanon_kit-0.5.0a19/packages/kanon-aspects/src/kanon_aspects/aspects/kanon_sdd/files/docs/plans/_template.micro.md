<!-- Copy this file and rename to create a micro-plan (4-file changes, no protected paths). -->
---
feature: <slug>
status: done
date: YYYY-MM-DD
micro: true
---
# Micro-plan: <one-line intent>

- **Files:** <comma-separated list>
- **Constraints:** <what must NOT change, e.g. "public CLI surface must not change">
- **Risk:** low | medium (if medium, explain why not a full plan)
