---
contract-id: kanon-deps/deps-pinned
semantic-version: "1.0"
surface: preflight.push
realization-shape:
  verbs: [file-check]
  evidence-kinds: [build-config]
  stages: [push]
kanon-dialect: "2026-05-01"
---
# Contract: deps-pinned

## Obligation

Application dependencies MUST use exact version pinning. Lock files must be committed and kept in sync with dependency declarations.

## What the resolver must determine

1. **Pinning strategy** — are dependencies declared with exact versions (`==`) not ranges?
2. **Lock file presence** — does a lock file exist and is it committed?
3. **Sync state** — is the lock file consistent with the dependency declaration?

## Staleness

This resolution is stale when:

- Dependencies are added, removed, or updated
- The lock file is regenerated
