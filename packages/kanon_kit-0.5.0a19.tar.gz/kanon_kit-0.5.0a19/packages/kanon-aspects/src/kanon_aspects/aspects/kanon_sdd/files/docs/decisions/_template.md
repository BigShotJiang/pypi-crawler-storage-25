---
status: draft
date: YYYY-MM-DD
constrains:  # optional: docs/specs/<slug>.md (if ADR narrows a spec's design space)
---
# ADR-NNNN: <Title>

> **Use this when:** making a non-obvious technical choice during spec or design work.

## Context

<What problem is being solved? What constraints or forces apply?>

## Decision

<What we are doing. A single clear statement of the choice.>

## Alternatives Considered

1. **<Option>.** <Why rejected.>
2. **<Option>.** <Why rejected.>
3. **<Chosen option>** (chosen). <Why this.>

## Consequences

- <Positive consequence>
- <Negative consequence or tradeoff>

## Config Impact

<Optional. Any config knobs this decision creates.>

## References

- <Links to specs, prior ADRs, design docs, external sources>

<!-- kanon:backlinks --><!-- /kanon:backlinks -->
