# kanon-deps

## Intent

Without dependency hygiene, agents reflexively `pip install` whatever solves the immediate problem. The result: bloated lock files, supply-chain risk from unvetted packages, and version conflicts that surface months later.

This aspect prevents this by making every dependency addition a conscious, justified decision.

**Judgment heuristic:** If you're about to add, remove, or update a package in any manifest file, this aspect applies.

## Core Concepts

- **Deliberate addition** — Check if the functionality already exists in your stack before reaching for a new package.
  *Decision heuristic:* can you implement this in <20 lines without the dependency? If yes, don't add it.

- **Exact pinning** — Lock files and exact versions (`==`) prevent surprise breakage from upstream changes.
  *Quality signal:* no `>=`, `~=`, or `^` operators in application dependency declarations.

- **Supply-chain awareness** — Every transitive dependency is code you trust to run in your environment.
  *Decision heuristic:* review the lock-file diff — if a single addition pulls >10 transitive deps, reconsider.

## Depth Progression

| Depth | Adds | Right for |
|-------|------|-----------|
| 1 | Dependency-hygiene protocol for any add/remove/update | All projects |
| 2 | CI validator scans for unpinned, unused, or suspicious deps | Production deployments |

## Anti-patterns

- Adding a package for one utility function you could write in 10 lines
- Using open version ranges in application code (libraries may use ranges; apps should not)
- Ignoring transitive dependency updates in the lock file
- Treating dev dependencies as exempt from hygiene (they execute in CI)

## See Also

- `protocols/kanon-deps/dependency-hygiene.md` — procedure: read before any dependency change
