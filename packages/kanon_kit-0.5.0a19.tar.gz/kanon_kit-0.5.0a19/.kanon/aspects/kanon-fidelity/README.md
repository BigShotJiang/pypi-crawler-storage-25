# kanon-fidelity

## Intent

Without fidelity checking, you can only verify that agents produced the right *artifacts* (files exist, tests pass) — not that they followed the right *process*. An agent can claim "plan approved" without ever writing a plan, and structural verification won't catch it.

This aspect prevents this by asserting on agent *transcripts* — proving behavioral compliance through deterministic pattern matching.

**Judgment heuristic:** If you're modifying protocol prose or committing fidelity captures, this aspect applies.

## Core Concepts

- **Fidelity fixture** — A YAML file declaring patterns (regex or substring) that MUST appear in an agent transcript for a protocol to be considered followed.
  *Quality signal:* the fixture fails on a transcript where the agent skipped the protocol, and passes on one where it followed it.

- **Dogfood capture** — A recorded transcript segment paired with its fixture for regression testing.
  *Decision heuristic:* after any protocol prose change, recapture the dogfood to confirm the fixture still matches real agent behavior.

- **Lexical assertion** — A deterministic match (regex/substring) on transcript text. No LLM involved in verification.
  *Quality signal:* assertions are specific enough to catch drift but general enough to survive minor phrasing changes.

## Depth Progression

| Depth | Adds | Right for |
|-------|------|-----------|
| 1 | Fidelity fixtures with lexical assertions; dogfood pairing required | Projects that need behavioral compliance proof |

## Artifacts

*Canonical paths in kernel rules; this is a convenience index.*

| Artifact | Path | Format |
|----------|------|--------|
| Fidelity fixture | `.kanon/fidelity/<spec>/<name>.yaml` | YAML with assertions |
| Dogfood capture | `.kanon/fidelity/<spec>/<name>.dogfood.md` | Transcript segment |

## Anti-patterns

- Weakening assertions to make a fixture pass (fix the agent behavior, not the test)
- Skipping fidelity recapture after protocol prose changes
- Writing assertions so broad they match anything (e.g., `.*`)
- Treating fidelity as optional when protocol prose is the enforcement mechanism

## See Also

- `protocols/kanon-fidelity/fidelity-fixture-authoring.md` — procedure: writing and updating fixtures
- `protocols/kanon-fidelity/fidelity-discipline.md` — rules: committing captures, recapture triggers
