# kanon-release

## Intent

Without release discipline, releases happen by accident — someone pushes a tag without running tests, forgets the changelog, or publishes from a dirty tree. Broken releases erode user trust and are expensive to retract.

This aspect prevents this by making every release follow the same validated checklist, so nothing is skipped under pressure.

**Judgment heuristic:** If you're bumping a version, creating a tag, or publishing an artifact, this aspect applies.

## Core Concepts

- **Release checklist** — The canonical sequence: bump → changelog → validate → tag → publish → verify.
  *Quality signal:* every step has a concrete exit condition; no step is "check it looks okay."

- **Preflight** — Automated validation that must pass before tagging (tests, lint, kanon verify).
  *Decision heuristic:* if any preflight check fails, the release is blocked — no exceptions, no overrides.

- **Publishing discipline** — The publish step is mechanical (CI-driven), not manual.
  *Quality signal:* a human triggers the release; a machine executes it.

## Depth Progression

| Depth | Adds | Right for |
|-------|------|-----------|
| 1 | Release checklist protocol; agent-guided manual steps | All published projects |
| 2 | Automated preflight script + CI workflow | Projects with frequent releases |

## Anti-patterns

- Tagging from a branch with uncommitted changes
- Skipping the changelog because "it's obvious what changed"
- Publishing without verifying the artifact installs cleanly in a clean environment
- Manual uploads instead of CI-driven publish

## See Also

- `protocols/kanon-release/release-checklist.md` — procedure: full release lifecycle
- `protocols/kanon-release/publishing-discipline.md` — rules: the publish step specifically
- `protocols/kanon-release/preflight-automation.md` — automation: depth-2 CI preflight
