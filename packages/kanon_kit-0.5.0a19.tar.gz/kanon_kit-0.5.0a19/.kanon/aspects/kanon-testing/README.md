# kanon-testing

## Intent

Without test discipline, agents produce code that looks correct but silently violates requirements — no assertion ever checked. "Done" becomes an opinion rather than a provable fact.

This aspect prevents this by making tests the executable specification of intent. Writing the assertion first forces understanding the requirement before implementing it.

**Judgment heuristic:** If you're about to modify behavior, the test that proves correctness should exist before (or alongside) the implementation.

## Core Concepts

- **AC-first TDD** — Acceptance criteria from the plan become failing test assertions before implementation exists.
  *Quality signal:* tests fail for the right reason (behavior absent) not the wrong one (import error, missing fixture).

- **Error diagnosis** — Systematic root-cause analysis when tests fail: reproduce → isolate → identify → fix → verify.
  *Decision heuristic:* if a fix takes more than one attempt, stop and run the full diagnosis protocol.

- **Test levels** — Unit (one function, no I/O), Integration (multiple components in-process), E2E (installed artifact as subprocess).
  *Decision heuristic:* if you're mocking more than two things, you probably need an integration test instead.

## Depth Progression

| Depth | Adds | Right for |
|-------|------|-----------|
| 1 | Every code change has tests; no deletions without justification | All projects |
| 2 | AC-first TDD: failing tests from plan criteria before implementation | Team projects |
| 3 | Test quality enforcement: no trivial assertions, boundary coverage | Production systems |

## Anti-patterns

- Writing tests after implementation just to reach a coverage number
- Deleting or weakening assertions to make the build pass
- Testing implementation details instead of observable behavior
- Skipping test-first at depth ≥ 2 because "it's a small change"

## See Also

- `protocols/kanon-testing/test-discipline.md` — gate: read before any code modification
- `protocols/kanon-testing/ac-first-tdd.md` — method: translating ACs into failing tests
- `protocols/kanon-testing/error-diagnosis.md` — recovery: read when tests fail unexpectedly
- `protocols/kanon-testing/test-quality.md` — review: read when writing tests at depth 3
