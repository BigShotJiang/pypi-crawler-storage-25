# kanon-security

## Intent

Without security discipline, agents produce code that works but is exploitable — hardcoded secrets, unsanitized inputs, permissive defaults. These flaws ship silently because nothing in a test suite catches "works but is unsafe."

This aspect prevents this by making secure patterns the path of least resistance: agents reach for safe defaults first and flag deviations explicitly.

**Judgment heuristic:** If the code touches user input, secrets, authentication, network boundaries, or file paths, this aspect applies.

## Core Concepts

- **Secure defaults** — Code should be safe without extra configuration; insecurity requires an explicit opt-in.
  *Quality signal:* a new endpoint is safe with zero additional flags — unsafe behavior requires a named override.

- **Input validation** — All external data is untrusted and validated at the boundary before use.
  *Decision heuristic:* if data crosses a trust boundary (user→server, file→parser, env→config), validate at the crossing.

- **Secret hygiene** — Secrets never appear in code, logs, or error messages; loaded from secure stores at runtime.
  *Quality signal:* `grep -r` for the secret's value returns zero hits outside the secret store config.

- **Least privilege** — Every component gets the minimum permissions needed for its function.
  *Decision heuristic:* start with no access and add only what the current feature requires.

## Depth Progression

| Depth | Adds | Right for |
|-------|------|-----------|
| 1 | Secure-defaults protocol active; secrets never in source | All projects |
| 2 | Security review for new endpoints, auth flows, data stores | User-facing networked services |

## Anti-patterns

- Disabling TLS/auth "for development" without a revert mechanism
- Logging full exception objects (leaks secrets in stack traces)
- Validating input on the client but not the server
- Deferring auth hardening to a future sprint that never ships

## See Also

- `protocols/kanon-security/secure-defaults.md` — gate: read before writing code that handles secrets or user input
- `protocols/kanon-security/security-review.md` — review: read when a spec introduces new endpoints or auth
