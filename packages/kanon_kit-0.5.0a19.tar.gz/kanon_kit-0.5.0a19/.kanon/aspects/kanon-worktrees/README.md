# kanon-worktrees

## Intent

Without worktree isolation, agents commit half-finished work to main, parallel tasks create merge conflicts, and a broken commit blocks everyone.

This aspect prevents this by giving every task its own worktree and branch, so main stays deployable and parallel work can't interfere.

**Judgment heuristic:** If you're about to modify any file, you should be inside a `.worktrees/<slug>/` directory on a `wt/<slug>` branch.

## Core Concepts

- **Branch convention** — All worktree branches use the `wt/<slug>` prefix, making them instantly recognizable and separable from feature/release branches.
  *Quality signal:* `git branch | grep wt/` shows only active task branches with meaningful slugs.

- **Worktree lifecycle** — Create before work, commit frequently, rebase on main, push, merge via PR, then remove the worktree and delete the branch.
  *Decision heuristic:* if the worktree's branch is merged, the worktree should be removed immediately.

## Depth Progression

| Depth | Adds | Right for |
|-------|------|-----------|
| 1 | Worktree isolation enforced; branch-hygiene gate active | All projects |
| 2 | Shell helper scripts for consistent lifecycle management | Teams wanting standardized commands |

## Artifacts

*Canonical paths in kernel rules; this is a convenience index.*

| Artifact | Path | Created by |
|----------|------|------------|
| Worktree | `.worktrees/<slug>/` | `git worktree add` |
| Branch | `wt/<slug>` | created with worktree |

## Anti-patterns

- Committing directly to main "because it's a small change"
- Leaving stale worktrees around after the branch is merged
- Starting work without creating a worktree first (verify will catch this)
- Using `git clean -dfx` which destroys `.worktrees/` contents

## See Also

- `protocols/kanon-worktrees/branch-hygiene.md` — hard gate: auto-checked before any file modification
- `protocols/kanon-worktrees/worktree-lifecycle.md` — procedure: creating, managing, tearing down worktrees
- `protocols/kanon-worktrees/worktree-scripts.md` — automation: depth-2 helper scripts
