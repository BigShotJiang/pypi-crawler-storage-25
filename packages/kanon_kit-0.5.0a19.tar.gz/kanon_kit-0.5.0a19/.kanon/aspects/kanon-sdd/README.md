# kanon-sdd

## Intent

Without SDD, agents jump straight to code. The result: features that don't match intent, rework when assumptions surface late, and no reviewable trail of why something was built this way.

SDD prevents this by requiring thought to be captured in writing before implementation — at a level of formality proportional to the change's risk.

**Judgment heuristic:** If you'd explain this change to a teammate before coding it, it needs a plan. If it introduces a capability users will see, it needs a spec.

## Core Concepts

- **Spec** — What a capability does from the user's perspective, with acceptance criteria.
  *Quality signal:* someone unfamiliar with the codebase can verify the feature works by reading only the spec.

- **Plan** — A sequenced breakdown of how to implement, with concrete steps and acceptance criteria.
  *Decision heuristic:* if the change touches >1 file or takes >30 minutes, write a plan.

- **Design doc** — Architectural choices and trade-offs for cross-cutting concerns.
  *Decision heuristic:* if the change introduces a new component boundary or integration point, write one.

- **ADR** — An immutable record of a non-obvious technical decision and its rationale.
  *Decision heuristic:* if you debated two or more viable approaches, capture it.

- **Foundations** — Vision, principles, personas at `docs/foundations/`. Source material that specs cite.
  *Quality signal:* specs reference foundations by name rather than re-deriving project stances.

## Depth Progression

| Depth | Adds | Right for |
|-------|------|-----------|
| 1 | Plans required before implementation | Solo projects, internal tools |
| 2 | Specs for new capabilities; ADRs for decisions | Team projects, user-facing work |
| 3 | Design docs for cross-cutting changes; spec review gates | Production systems, regulated domains |

## Artifacts

*Canonical paths in kernel rules; this is a convenience index.*

| Artifact | Path | Template |
|----------|------|----------|
| Spec | `docs/specs/<slug>.md` | `docs/specs/_template.md` |
| Design doc | `docs/design/<slug>.md` | `docs/design/_template.md` |
| Plan | `docs/plans/<slug>.md` | `docs/plans/_template.md` |
| ADR | `docs/decisions/NNNN-<slug>.md` | `docs/decisions/_template.md` |
| Foundations | `docs/foundations/` | per-document |

## Anti-patterns

- Writing code first and retrofitting a plan to satisfy verification
- Specs that describe implementation instead of user-visible behavior
- Plans with no acceptance criteria (unverifiable completion)
- Skipping ADRs then relitigating the same decision later
- Gold-plating: depth-3 formality on a one-line config change

## See Also

- `protocols/kanon-sdd/plan-before-build.md` — gate: read before any non-trivial implementation
- `protocols/kanon-sdd/spec-before-design.md` — gate: read when adding user-visible capabilities
- `protocols/kanon-sdd/design-before-plan.md` — gate: read when introducing new component boundaries
- `protocols/kanon-sdd/adr-authoring.md` — guidance: read when capturing a technical decision
- `protocols/kanon-sdd/completion-checklist.md` — exit: read before declaring work done
