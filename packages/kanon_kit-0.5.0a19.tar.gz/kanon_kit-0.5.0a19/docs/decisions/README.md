<!-- kanon:agent-guidance
- Naming: NNNN-<slug>.md (chronologically numbered, next number = highest existing + 1)
- Skip when: change follows existing patterns with no genuine alternatives debated
- Quality signal: a future reader understands WHY this choice was made without asking the author
- Anti-pattern: writing an ADR for a decision with no viable alternative (that's documentation, not a decision)
-->
# Architecture Decision Records

Each file records a single architectural decision with its context, choice, alternatives, and consequences.

## Quick Reference

- **When to write one:** making a non-obvious technical choice with genuine alternatives
- **Naming:** `NNNN-<slug>.md` (chronologically numbered)
- **Template:** [`_template.md`](_template.md)
- **Verification rejects:** body changes to accepted ADRs without `Allow-ADR-edit` trailer

## Background

ADRs are the "why" layer — they explain reasoning that might otherwise seem arbitrary to a future reader. ADRs are produced DURING design and implementation, as decisions crystallize. They are NOT the starting point for new work.

ADRs are **immutable** once accepted. To reverse a decision, write a new ADR that supersedes it.

## Weights

- **Full ADR** (~40 lines): new architecture, genuine debate, multiple viable alternatives
- **ADR-lite** (~12 lines): behavior change within an existing model (gate change, default change, boundary change). Uses `weight: lite` frontmatter.

## Immutability Exceptions

1. Frontmatter-only changes (status transitions, `superseded-by:`)
2. Appending a `## Historical Note` section at the end
3. `Allow-ADR-edit: NNNN — <reason>` commit-message trailer

## Status Values

- `accepted` — decision is committed; behavior must match
- `provisional` — accepted on current evidence, flagged for review
- `superseded` — replaced by a later ADR

## See Also

- [`_template.md`](_template.md) — copy to create a new ADR
- Protocol: `adr-authoring` — guidance for capturing decisions
- Protocol: `adr-immutability` — rules for modifying accepted ADRs

## Index

*(empty — add ADRs as you make load-bearing decisions)*
