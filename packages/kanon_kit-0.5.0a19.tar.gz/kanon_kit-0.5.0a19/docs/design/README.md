<!-- kanon:agent-guidance
- Naming: <mechanism-slug>.md (named after the mechanism, not the feature)
- Skip when: feature follows an existing pattern, touches one component, and plan frontmatter declares design: "Follows ADR-NNNN"
- Quality signal: a reader understands component boundaries and data flow without reading the implementation
- Anti-pattern: including step-by-step execution (that belongs in a plan, not a design doc)
-->
# Design Docs

Technical architecture — HOW features are built at a high level.

## Quick Reference

- **When to write one:** change introduces new component boundaries or cross-cutting mechanisms
- **Naming:** `<mechanism-slug>.md`
- **Template:** [`_template.md`](_template.md)
- **Verification rejects:** missing `implements:` frontmatter reference

## Background

A design doc describes HOW a feature is built at a high level. It takes a spec's intent and proposes an architecture: which components interact, how data flows, what state model applies, what trade-offs were accepted.

Design docs are technical but not procedural. If numbered steps appear, the content belongs in a plan, not a design doc.

## When to Skip

A design doc may be skipped when ALL of these hold:

1. The feature follows an architecture already documented in an accepted ADR or design doc
2. The feature touches one component boundary only
3. The plan's frontmatter declares `design: "Follows ADR-NNNN"`

If the feature produces a new ADR during implementation, add a retrospective design doc.

## See Also

- [`_template.md`](_template.md) — copy to create a new design doc
- Protocol: `design-before-plan` — gate that triggers design authoring

## Index

*(empty — add design docs when features introduce novel mechanisms)*
