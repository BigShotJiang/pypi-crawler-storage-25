# Aspect Authoring

> **Stability: experimental.** The aspect authoring surface may change between releases. Pin your kanon-kit version.

This directory documents how to create custom aspects for kanon.

## Documents

| Document | Purpose |
|----------|---------|
| [reference.md](reference.md) | Schema reference — manifest, protocol frontmatter, naming, file layout |
| [quickstart.md](quickstart.md) | Build your first aspect in 20 minutes |

## What is an aspect?

An aspect is a named discipline that kanon enforces. It contains protocols (prose instructions for agents), optional files to scaffold, and optional contracts (obligations consumers must satisfy). Aspects are depth-dialed: higher depths add more rigor.

## Namespace ownership

| Prefix | Owner | Example |
|--------|-------|---------|
| `kanon-*` | kanon kit (reserved) | `kanon-sdd`, `kanon-testing` |
| `project-*` | Consumer repo | `project-linting`, `project-onboarding` |
| `acme-*` | Third-party publisher | `acme-compliance`, `acme-observability` |

<!-- planned: docs/authoring/composition.md — cross-aspect dependencies -->
<!-- planned: docs/authoring/publishing.md — distributing aspects as packages -->
<!-- planned: docs/authoring/testing.md — testing your aspect -->
