<!-- kanon:agent-guidance
- Naming: <feature-slug>.md (matches the feature being implemented)
- Skip when: change touches ≤3 files, none in protected paths, and is a typo/single-assertion fix/local rename
- Quality signal: every task has a target file path and the plan is executable without further clarification
- Anti-pattern: writing code first and retrofitting a plan to satisfy verification
-->
# Plans

Task breakdowns for features. Written BEFORE implementation, kept as permanent records.

## Quick Reference

- **When to write one:** non-trivial change (≥5 files or protected paths)
- **Naming:** `<feature-slug>.md`
- **Template:** [`_template.md`](_template.md) (full) or [`_template.micro.md`](_template.micro.md) (4-file changes)
- **Verification rejects:** `status: done` with unchecked tasks

## Background

A plan is an ordered task breakdown written BEFORE implementation. It tells the implementing agent exactly what to build, in what order, touching which files. Plans are the bridge between "we know HOW to build it" (design) and "we're building it" (implement).

Plans are committed as the first commit on a feature branch and kept as permanent records after the feature ships.

## Checkbox Convention

- `- [x]` — task shipped
- `- [~]` — task deferred (must include `NOTE:` with rationale)
- `status: done` with unchecked items is a verification error

## See Also

- [`_template.md`](_template.md) — copy to create a full plan
- [`_template.micro.md`](_template.micro.md) — copy for 4-file changes
- Protocol: `plan-before-build` — gate that triggers plan authoring
- Protocol: `completion-checklist` — exit checklist before declaring done

## Index

*(empty — add plans as you start features)*
