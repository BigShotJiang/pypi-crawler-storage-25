<!-- kanon:agent-guidance
- Naming: <descriptive-slug>.md (not numbered, not chronological)
- Skip when: change is a refactor, bug fix, or extends an existing capability without new guarantees
- Quality signal: someone unfamiliar with the codebase can verify the feature works by reading only the spec
- Anti-pattern: describing implementation (components, languages, data formats) instead of user-visible behavior
-->
# Specs

Product intent — WHAT the project does from the user's perspective.

## Quick Reference

- **When to write one:** introducing a new user-visible capability
- **Naming:** `<descriptive-slug>.md` (not numbered)
- **Template:** [`_template.md`](_template.md)
- **Verification rejects:** missing invariants section, broken foundation backreferences

## Background

A spec describes WHAT the project does from a product perspective. It is implementation-agnostic — a spec makes sense even if the entire technical architecture changed. Specs capture product intent before any design work begins.

A spec answers: What problem does this solve? What properties must the output have? What invariants must always hold? What is explicitly out of scope?

Specs come BEFORE ADRs. They define the intent that ADRs record decisions about.

## See Also

- [`_template.md`](_template.md) — copy to create a new spec
- Protocol: `spec-before-design` — gate that triggers spec authoring
- Protocol: `spec-review` — review checklist for draft specs

## Index

*(empty — add specs as you define user-visible capabilities)*
