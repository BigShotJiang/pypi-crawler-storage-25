import pytesseract
from PIL import Image
import fitz
from .adaptive import detect_page_complexity
from .preprocessing import preprocess


from .adaptive import detect_page_complexity
from .preprocessing import preprocess


def ocr_page(page, lang: str = "ara", zoom: float = 6) -> str:
    """
    Basic OCR for a single PDF page.
    No adaptation, no logic — only execution.
    """

    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

    return pytesseract.image_to_string(img, lang=lang).strip()


def adaptive_ocr_page(
    page: fitz.Page,
    lang: str = "ara",
    zoom_base: float = 6,
    oem: int = 1,
    preprocess_mode: str = "normal"
) -> str:
    """
    Adaptive OCR engine with preprocessing.

    Pipeline:
    1. Render page
    2. Preprocess image
    3. Detect complexity
    4. Select PSM
    5. OCR
    """

    # 1. Render
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom_base, zoom_base))
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

    # 2. Preprocess FIRST (better signal for detection)
    img = preprocess(img, mode=preprocess_mode)

    # 3. Complexity detection
    complexity = detect_page_complexity(img)

    # 4. Adaptive PSM
    if complexity == "simple":
        psm = 6
    elif complexity == "medium":
        psm = 4
    else:
        psm = 3

    # 5. OCR config
    config = f"--oem {oem} --psm {psm}"

    return pytesseract.image_to_string(
        img,
        lang=lang,
        config=config
    ).strip()
