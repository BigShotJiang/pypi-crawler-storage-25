from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
from typing import Callable, Iterable, Any, Tuple, Dict

def run_parallel(tasks: Iterable[Any],worker: Callable[[Any], Tuple[Any, Any]],max_workers: int = 4,desc: str = "Processing") -> Dict[Any, Any]:
    """
    Run a function in parallel over a list of tasks.

    Parameters
    ----------
    tasks : Iterable[Any]
        List or iterable of inputs to process.
    worker : Callable[[Any], Tuple[Any, Any]]
        Function that takes a task and returns (key, value).
        Example: (page_num, text)
    max_workers : int, optional
        Number of threads to use (default = 4).
    desc : str, optional
        Progress bar description.

    Returns
    -------
    Dict[Any, Any]
        Dictionary of results from all workers.
    """

    results = {}

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(worker, t): t for t in tasks}

        for f in tqdm(as_completed(futures), total=len(futures), desc=desc):
            key, value = f.result()
            results[key] = value

    return results