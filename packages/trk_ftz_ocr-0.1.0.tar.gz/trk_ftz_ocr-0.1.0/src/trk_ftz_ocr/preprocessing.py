from PIL import Image, ImageEnhance, ImageFilter


def enhance_contrast(img: Image.Image, factor: float = 1.5) -> Image.Image:
    """
    enhances the quality of image.

    Parameters
    ----------
    img : PIL.Image
        Input image

    factor default is : 1.5
    """
    enhancer = ImageEnhance.Contrast(img)
    return enhancer.enhance(factor)


def denoise(img: Image.Image, radius: float = 0.8) -> Image.Image:
    """
        removes noise from an image.

        Parameters
        ----------
        img : PIL.Image
            Input image

        radius default is : 0.8
        """
    return img.filter(ImageFilter.GaussianBlur(radius=radius))


def sharpen(img: Image.Image) -> Image.Image:
    return img.filter(ImageFilter.SHARPEN)


def preprocess(
    img: Image.Image,
    mode: str = "normal",
    normal_factor: float = 1.3,
    strong_factor: float = 1.8
) -> Image.Image:
    """
    Preprocessing pipeline before OCR.

    Modes
    -----
    normal : light enhancement (clean documents)
    strong : heavy enhancement (scanned/noisy documents)

    Parameters
    ----------
    img : PIL.Image
        Input image
    mode : str
        "normal" or "strong"
    normal_factor : float
        Contrast factor for normal mode, default is 1.3
    strong_factor : float
        Contrast factor for strong mode, default is 1.8
    """

    if mode == "normal":
        img = enhance_contrast(img, factor=normal_factor)
        img = sharpen(img)

    elif mode == "strong":
        img = enhance_contrast(img, factor=strong_factor)
        img = denoise(img)
        img = sharpen(img)

    return img