from .parallel import run_parallel


def run_pdf_pages_parallel(doc, worker, max_workers=4, desc="OCR PDF"):
    """
    Parallel execution over PDF pages only.
    Safe single-level parallelism.
    """
    pages = list(enumerate(doc, start=1))

    return run_parallel(
        tasks=pages,
        worker=worker,
        max_workers=max_workers,
        desc=desc
    )


def run_directory_parallel(tasks, worker, max_workers=4, desc="OCR Directory"):
    """
    Parallel execution over files only.
    Safe single-level parallelism.
    """
    return run_parallel(
        tasks=tasks,
        worker=worker,
        max_workers=max_workers,
        desc=desc
    )