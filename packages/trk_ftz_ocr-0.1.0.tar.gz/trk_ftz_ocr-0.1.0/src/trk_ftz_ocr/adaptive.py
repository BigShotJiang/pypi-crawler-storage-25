from PIL import Image, ImageStat


def detect_page_complexity(img: Image.Image) -> str:
    """
    Estimate page complexity based on pixel variance.
    """

    gray = img.convert("L")
    stat = ImageStat.Stat(gray)

    variance = stat.var[0]

    if variance < 500:
        return "simple"
    elif variance < 1500:
        return "medium"
    else:
        return "complex"