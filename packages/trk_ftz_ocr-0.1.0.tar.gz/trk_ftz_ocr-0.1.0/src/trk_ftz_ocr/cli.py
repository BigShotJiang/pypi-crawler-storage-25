import argparse
from .pipeline import process


def main():
    parser = argparse.ArgumentParser(
        description="TRK FTZ OCR - PDF OCR Tool"
    )

    parser.add_argument(
        "path",
        type=str,
        help="PDF file or folder path"
    )

    parser.add_argument(
        "--page",
        type=int,
        default=None,
        help="Extract single page (PDF only)"
    )

    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output path (file or folder)"
    )

    parser.add_argument(
        "--lang",
        type=str,
        default="ara",
        help="OCR language"
    )

    parser.add_argument(
        "--zoom",
        type=float,
        default=6,
        help="Render zoom"
    )

    parser.add_argument(
        "--parallel",
        action="store_true",
        help="Enable parallel processing"
    )

    parser.add_argument(
        "--mode",
        type=str,
        default="dict",
        choices=["dict", "file", "folder", "excel"],
        help="Output mode"
    )

    args = parser.parse_args()

    result = process(
        path=args.path,
        page_num=args.page,
        output_path=args.output,
        lang=args.lang,
        zoom=args.zoom,
        parallel=args.parallel,
        output_mode=args.mode
    )

    # print only if dict output
    if args.mode == "dict":
        print(result)