from pathlib import Path
from typing import Dict
import pandas as pd


# =========================================================
# 📄 SINGLE TXT
# =========================================================

def save_single_txt(output_path: str, text: str) -> None:
    """
    Save full text into a single txt file.
    """

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    path.write_text(text, encoding="utf-8")


# =========================================================
# 📊 SINGLE PDF → EXCEL
# =========================================================

def save_single_excel(
    output_path: str,
    pdf_path: str,
    pages: Dict[int, str]
) -> None:
    """
    Save OCR results of ONE PDF to Excel.

    Columns:
    file | path | page | text
    """

    pdf_path_obj = Path(pdf_path)

    rows = [
        {
            "file": pdf_path_obj.name,
            "path": str(pdf_path_obj),
            "page": page_num,
            "text": text
        }
        for page_num, text in pages.items()
    ]

    df = pd.DataFrame(rows)
    df.to_excel(output_path, index=False)


# =========================================================
# 📁 SAVE PAGES AS FOLDER
# =========================================================

def save_page_folder(
    output_dir: str,
    pdf_path: str,
    pages: Dict[int, str]
) -> None:
    """
    Save OCR results as:
    output_dir/pdf_name/pdf_name_page_X.txt
    """

    pdf_name = Path(pdf_path).stem
    folder = Path(output_dir) / pdf_name
    folder.mkdir(parents=True, exist_ok=True)

    for page_num, text in pages.items():
        file_path = folder / f"{pdf_name}_page_{page_num}.txt"
        file_path.write_text(text, encoding="utf-8")


# =========================================================
# 📁 DIRECTORY → FOLDER STRUCTURE
# =========================================================

def save_directory(
    output_dir: str,
    data: Dict[str, Dict[int, str]]
) -> None:
    """
    Save multiple PDFs as folder structure.

    data:
        {
            "full/path/file.pdf": {1: "..."}
        }
    """

    for pdf_path, pages in data.items():
        save_page_folder(output_dir, pdf_path, pages)


# =========================================================
# 📊 DIRECTORY → EXCEL
# =========================================================

def save_directory_excel(
    output_path: str,
    data: Dict[str, Dict[int, str]]
) -> None:
    """
    Save ALL PDFs into ONE Excel file.

    Columns:
    file | path | page | text
    """

    rows = []

    for pdf_path, pages in data.items():
        pdf_path_obj = Path(pdf_path)

        for page_num, text in pages.items():
            rows.append({
                "file": pdf_path_obj.name,
                "path": str(pdf_path_obj),
                "page": page_num,
                "text": text
            })

    df = pd.DataFrame(rows)
    df.to_excel(output_path, index=False)