import fitz
from typing import List, Optional

from .engine import adaptive_ocr_page


def test_page(
    pdf_path: str,
    page_num: int = 1,
    oem_values: Optional[List[int]] = None,
    modes: Optional[List[str]] = None,
):
    """
    Manual OCR tuning tool for comparing settings.
    """

    oem_values = oem_values or [1]
    modes = modes or ["normal", "strong"]

    doc = fitz.open(pdf_path)
    page = doc[page_num - 1]

    results = {}

    for oem in oem_values:
        for mode in modes:
            text = adaptive_ocr_page(
                page,
                oem=oem,
                preprocess_mode=mode
            )

            key = f"oem={oem}_mode={mode}"
            results[key] = text

    return results