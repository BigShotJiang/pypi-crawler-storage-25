import os
import fitz
from typing import Dict

from .parallel import run_parallel
from .engine import ocr_page


# =========================================================
# 📄 PAGE
# =========================================================

def extract_page_text(
    pdf_path: str,
    page_num: int,
    lang: str = "ara",
    zoom: float = 6
) -> str:
    """
    Extract text from a single page of a PDF using OCR.
    """

    doc = fitz.open(pdf_path)
    page = doc[page_num - 1]

    return ocr_page(page, lang=lang, zoom=zoom)


# =========================================================
# 📘 PDF (UNIFIED)
# =========================================================

def extract_pdf_text(
    pdf_path: str,
    lang: str = "ara",
    zoom: float = 6,
    parallel: bool = True,
    max_workers: int = 4
) -> Dict[int, str]:
    """
    Extract text from all pages of a PDF.

    Supports optional parallel processing.
    """

    doc = fitz.open(pdf_path)
    pages = list(enumerate(doc, start=1))

    def worker(item):
        i, page = item
        text = ocr_page(page, lang=lang, zoom=zoom)
        return i, text

    # -------------------------
    # PARALLEL
    # -------------------------
    if parallel:
        return run_parallel(
            tasks=pages,
            worker=worker,
            max_workers=max_workers,
            desc="OCR PDF"
        )

    # -------------------------
    # SEQUENTIAL
    # -------------------------
    results = {}

    for i, page in pages:
        text = ocr_page(page, lang=lang, zoom=zoom)
        if text:
            results[i] = text

    return results


# =========================================================
# 📁 DIRECTORY (UNIFIED)
# =========================================================

def extract_directory(
    folder_path: str,
    lang: str = "ara",
    zoom: float = 6,
    parallel: bool = True,
    max_workers: int = 4
) -> Dict[str, Dict[int, str]]:
    """
    Extract text from all PDF files in a directory.

    Returns:
        {
            "full/path/file.pdf": {
                1: "text page 1",
                2: "text page 2"
            }
        }
    """

    pdf_paths = [
        os.path.join(folder_path, f)
        for f in os.listdir(folder_path)
        if f.lower().endswith(".pdf")
    ]

    def worker(pdf_path):
        result = extract_pdf_text(
            pdf_path,
            lang=lang,
            zoom=zoom,
            parallel=False  # prevent nested parallelism
        )
        return pdf_path, result

    # -------------------------
    # PARALLEL
    # -------------------------
    if parallel:
        return run_parallel(
            tasks=pdf_paths,
            worker=worker,
            max_workers=max_workers,
            desc="OCR Directory"
        )

    # -------------------------
    # SEQUENTIAL
    # -------------------------
    results = {}

    for pdf_path in pdf_paths:
        _, res = worker(pdf_path)
        results[pdf_path] = res

    return results