from pathlib import Path
from typing import Optional

from .extractor import (
    extract_page_text,
    extract_pdf_text,
    extract_directory
)

from .saver import (
    save_single_txt,
    save_page_folder,
    save_single_excel,
    save_directory,
    save_directory_excel
)


# =========================================================
# 🟦 MAIN ROUTER
# =========================================================

def process(
    path: str,
    page_num: Optional[int] = None,
    output_path: Optional[str] = None,
    lang: str = "ara",
    zoom: float = 6,
    parallel: bool = True,
    output_mode: str = "dict"
):
    """
    Unified OCR pipeline router.

    output_mode:
    - dict   → return data
    - file   → single txt (PDF only)
    - folder → per-page txt files
    - excel  → Excel output
    """

    path_obj = Path(path)

    if not path_obj.exists():
        raise ValueError(f"Path does not exist: {path}")

    # =====================================================
    # 📄 SINGLE FILE
    # =====================================================
    if path_obj.is_file():

        # 📄 single page mode
        if page_num is not None:
            return process_page(
                path,
                page_num,
                lang=lang,
                zoom=zoom
            )

        return process_pdf(
            pdf_path=path,
            output_path=output_path,
            lang=lang,
            zoom=zoom,
            parallel=parallel,
            output_mode=output_mode
        )

    # =====================================================
    # 📁 DIRECTORY
    # =====================================================
    if path_obj.is_dir():

        return process_directory(
            folder_path=path,
            output_path=output_path,
            lang=lang,
            zoom=zoom,
            parallel=parallel,
            output_mode=output_mode
        )

    raise ValueError("Unsupported input type")


# =========================================================
# 📄 PAGE
# =========================================================

def process_page(
    pdf_path: str,
    page_num: int,
    lang: str = "ara",
    zoom: float = 6
):
    return extract_page_text(
        pdf_path,
        page_num,
        lang=lang,
        zoom=zoom
    )


# =========================================================
# 📘 PDF
# =========================================================

def process_pdf(
    pdf_path: str,
    output_path: Optional[str],
    lang: str = "ara",
    zoom: float = 6,
    parallel: bool = True,
    output_mode: str = "dict"
):
    """
    Process a single PDF.
    """

    data = extract_pdf_text(
        pdf_path,
        lang=lang,
        zoom=zoom,
        parallel=parallel
    )

    # -------------------------
    # RETURN ONLY
    # -------------------------
    if output_mode == "dict":
        return data

    # -------------------------
    # TXT FILE
    # -------------------------
    if output_mode == "file" and output_path:
        text = "\n\n".join(data.values())
        save_single_txt(output_path, text)
        return None

    # -------------------------
    # FOLDER OUTPUT
    # -------------------------
    if output_mode == "folder" and output_path:
        save_page_folder(output_path, pdf_path, data)
        return None

    # -------------------------
    # EXCEL OUTPUT
    # -------------------------
    if output_mode == "excel" and output_path:
        save_single_excel(output_path, pdf_path, data)
        return None

    return data


# =========================================================
# 📁 DIRECTORY
# =========================================================

def process_directory(
    folder_path: str,
    output_path: Optional[str],
    lang: str = "ara",
    zoom: float = 6,
    parallel: bool = True,
    output_mode: str = "folder"
):
    """
    Process a directory of PDFs.
    """

    data = extract_directory(
        folder_path,
        lang=lang,
        zoom=zoom,
        parallel=parallel
    )

    # -------------------------
    # RETURN ONLY
    # -------------------------
    if output_mode == "dict":
        return data

    # -------------------------
    # SAVE FOLDER STRUCTURE
    # -------------------------
    if output_mode == "folder" and output_path:
        save_directory(output_path, data)
        return None

    # -------------------------
    # SAVE EXCEL
    # -------------------------
    if output_mode == "excel" and output_path:
        save_directory_excel(output_path, data)
        return None

    return data