from .extractor import (
    extract_page_text,
    extract_pdf_text,
    extract_directory,

)

from .saver import (
    save_page_folder,
    save_directory_excel,
    save_directory,
    save_single_txt,
    save_single_excel
)



__all__ = [
    "extract_page_text",
    "extract_pdf_text",
    "extract_directory"
]

from .pipeline import process_directory, process_page, process_pdf

# def save_as_single_txt(output_path, pages_dict):
#     with open(output_path, "w", encoding="utf-8") as f:
#         for page_num, text in pages_dict.items():
#             f.write(f"\n===== PAGE {page_num} =====\n")
#             f.write(text + "\n")
