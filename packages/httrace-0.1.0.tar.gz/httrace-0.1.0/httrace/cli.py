#!/usr/bin/env python3
"""
traceto CLI — generate integration tests from production traffic.

Usage:
    httrace init                         # scaffold httrace.config.yaml
    httrace generate                     # generate test files for configured service
    httrace generate --output ./tests/   # custom output directory
    httrace status                       # show endpoint coverage
"""
import os
import re
import sys
import json
import httpx
import typer
from pathlib import Path
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich import print as rprint

app = typer.Typer(
    name="httrace",
    help="Generate integration tests from real production traffic.",
    add_completion=False,
)
console = Console()

CONFIG_FILE = "httrace.config.yaml"
DEFAULT_BACKEND = "https://api.httrace.com"


def _load_config() -> dict:
    p = Path(CONFIG_FILE)
    if not p.exists():
        console.print(f"[red]✗[/red] {CONFIG_FILE} not found. Run [bold]httrace init[/bold] first.")
        raise typer.Exit(1)
    import yaml
    with open(p, encoding="utf-8") as f:
        return yaml.safe_load(f)


@app.command()
def init():
    """Create a httrace.config.yaml in the current directory."""
    p = Path(CONFIG_FILE)
    if p.exists():
        console.print(f"[yellow]⚠[/yellow]  {CONFIG_FILE} already exists.")
        raise typer.Exit(0)

    api_key = typer.prompt("Your Httrace API key (ht_...)")
    service = typer.prompt("Service name", default=Path.cwd().name)
    backend = typer.prompt("Backend URL", default=DEFAULT_BACKEND)
    output = typer.prompt("Test output directory", default="tests/integration")

    config = f"""\
# Httrace configuration
api_key: {api_key}
service: {service}
backend: {backend}
output: {output}
"""
    p.write_text(config, encoding="utf-8")
    console.print(f"[green]✓[/green]  Created {CONFIG_FILE}")
    console.print(f"[dim]Next: add middleware to your app, then run [bold]httrace generate[/bold][/dim]")


@app.command()
def generate(
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output directory for test files"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Print generated tests without writing files"),
):
    """Generate integration tests from captured production traffic."""
    config = _load_config()
    backend = config.get("backend", DEFAULT_BACKEND)
    service = config["service"]
    out_dir = Path(output or config.get("output", "tests/integration"))

    with console.status(f"[bold blue]Fetching captured traffic for [cyan]{service}[/cyan]..."):
        try:
            resp = httpx.post(
                f"{backend}/v1/generate-tests",
                params={"service": service},
                headers={"X-Api-Key": config["api_key"]},
                timeout=30.0,
            )
            resp.raise_for_status()
        except httpx.ConnectError:
            console.print(f"[red]✗[/red]  Cannot connect to backend at [bold]{backend}[/bold]")
            raise typer.Exit(1)
        except httpx.HTTPStatusError as e:
            console.print(f"[red]✗[/red]  Backend error: {e.response.status_code}")
            raise typer.Exit(1)

    data = resp.json()

    if not data.get("generated"):
        console.print(f"[yellow]⚠[/yellow]  No captures found for service [bold]{service}[/bold].")
        console.print("[dim]Make sure the middleware is installed and receiving traffic.[/dim]")
        raise typer.Exit(0)

    if dry_run:
        for filename, code in data.get("code", {}).items():
            console.rule(filename)
            console.print(code)
        raise typer.Exit(0)

    out_dir.mkdir(parents=True, exist_ok=True)
    conftest = out_dir / "conftest.py"
    if not conftest.exists():
        conftest.write_text(_conftest_template(service), encoding="utf-8")

    _SAFE_FILENAME = re.compile(r'^[\w\-]+\.py$')

    total_tests = 0
    for file_info in data["files"]:
        raw_name = file_info["file"]
        # Strip any directory components and reject non-safe names
        filename = Path(raw_name).name
        if not _SAFE_FILENAME.match(filename):
            console.print(f"  [yellow]⚠[/yellow]  Skipping unsafe filename from server: {raw_name!r}")
            continue
        code = data["code"].get(raw_name, "")
        (out_dir / filename).write_text(code, encoding="utf-8")
        count = file_info["test_count"]
        total_tests += count
        console.print(f"  [green]✓[/green]  {out_dir / filename} [dim]({count} tests)[/dim]")

    console.print()
    console.print(f"[bold green]✓  {total_tests} tests generated across {data['generated']} endpoints[/bold green]")
    console.print(f"[dim]Output: {out_dir}[/dim]")
    console.print()
    console.print("Run them with: [bold]pytest tests/integration/[/bold]")


@app.command()
def status():
    """Show endpoint coverage for your service."""
    config = _load_config()
    backend = config.get("backend", DEFAULT_BACKEND)
    service = config["service"]

    with console.status("[bold blue]Fetching coverage..."):
        try:
            resp = httpx.get(
                f"{backend}/v1/coverage",
                params={"service": service},
                headers={"X-Api-Key": config["api_key"]},
                timeout=10.0,
            )
            resp.raise_for_status()
        except httpx.ConnectError:
            console.print(f"[red]✗[/red]  Cannot connect to backend at {backend}")
            raise typer.Exit(1)

    data = resp.json()
    endpoints = data.get("endpoints", [])

    table = Table(title=f"Coverage — {service}", show_header=True, header_style="bold blue")
    table.add_column("Method", style="cyan", width=8)
    table.add_column("Path", style="white")
    table.add_column("Captures", justify="right", style="green")
    table.add_column("Status codes", style="dim")

    for ep in sorted(endpoints, key=lambda x: x["path"]):
        table.add_row(
            ep["method"],
            ep["path"],
            str(ep["captures"]),
            ", ".join(str(s) for s in sorted(ep["statuses"])),
        )

    console.print(table)
    console.print(f"\n[dim]Total captures: {data['total_captures']}[/dim]")


def _conftest_template(service: str) -> str:
    return f'''\
# Auto-generated by Httrace — conftest.py for {service}
# Customize create_test_* helpers to match your app's data layer.
import pytest
from fastapi.testclient import TestClient

# TODO: import your app here
# from myapp.main import app
# client = TestClient(app)

# Placeholder stubs — replace with real implementations
class _FakeClient:
    def get(self, *a, **kw): raise NotImplementedError("Configure client in conftest.py")
    def post(self, *a, **kw): raise NotImplementedError("Configure client in conftest.py")

client = _FakeClient()


def create_test_user(plan="free"):
    raise NotImplementedError


def create_cart():
    raise NotImplementedError


def create_order():
    raise NotImplementedError


def create_product():
    raise NotImplementedError


def get_auth_token():
    raise NotImplementedError
'''


def main():
    app()


if __name__ == "__main__":
    main()
