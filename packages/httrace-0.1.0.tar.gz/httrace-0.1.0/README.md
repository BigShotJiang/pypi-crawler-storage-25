# httrace

Capture real production HTTP traffic and automatically generate integration tests.

## Install

```bash
pip install httrace
```

## Quick start

```python
from httrace import HttraceCaptureMiddleware

app.add_middleware(
    HttraceCaptureMiddleware,
    api_key="ht_...",
    service="my-api",
)
```

Then generate tests:

```bash
httrace generate
```

Full documentation: [httrace.com/docs](https://httrace.com/docs)
