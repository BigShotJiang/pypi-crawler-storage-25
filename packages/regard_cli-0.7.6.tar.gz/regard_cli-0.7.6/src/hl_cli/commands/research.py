"""Research commands — assets, prices, book, funding, candles."""

import time
from typing import Annotated, List, Optional

import typer

from hl_cli.client import get_all_mids, get_info
from hl_cli.main import hl_app
from hl_cli.output import (
    die,
    format_timestamp,
    interval_to_ms,
    output,
    parse_time,
)
from hl_cli.resolver import get_resolver


@hl_app.command()
def assets(
    ctx: typer.Context,
    query: Annotated[Optional[str], typer.Argument(help="Search by name")] = None,
    deployer: Annotated[Optional[str], typer.Option("--deployer", help="Filter by deployer")] = None,
    sort: Annotated[str, typer.Option("--sort", help="Sort: volume|oi|name")] = "volume",
):
    """List and search all tradeable perps."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    # Default perps with full context (volume, OI, funding, etc.)
    meta_ctxs = info.meta_and_asset_ctxs()
    meta = meta_ctxs[0]
    ctxs = meta_ctxs[1]

    result = []
    for i, (asset_info, asset_ctx) in enumerate(zip(meta["universe"], ctxs)):
        result.append({
            "asset": asset_info["name"],
            "asset_id": i,
            "max_leverage": asset_info.get("maxLeverage", 0),
            "mark_price": asset_ctx.get("markPx", ""),
            "funding_rate": asset_ctx.get("funding", ""),
            "open_interest": asset_ctx.get("openInterest", ""),
            "volume_24h": asset_ctx.get("dayNtlVlm", ""),
        })

    # HIP-3 assets — load dex metadata and try to get contexts
    try:
        dex_list = info.post("/info", {"type": "perpDexs"})
        mids = get_all_mids(info)

        for idx, dex_info in enumerate(dex_list[1:]):
            dex_name = dex_info["name"]
            try:
                # Try metaAndAssetCtxs with dex param for full data
                dex_data = info.post("/info", {"type": "metaAndAssetCtxs", "dex": dex_name})
                dex_meta = dex_data[0]
                dex_ctxs = dex_data[1]
                offset = 110000 + idx * 10000

                for j, (ai, ac) in enumerate(zip(dex_meta["universe"], dex_ctxs)):
                    name = ai["name"]
                    result.append({
                        "asset": name,
                        "asset_id": j + offset,
                        "deployer": dex_name,
                        "max_leverage": ai.get("maxLeverage", 0),
                        "mark_price": ac.get("markPx", mids.get(name, "")),
                        "funding_rate": ac.get("funding", ""),
                        "open_interest": ac.get("openInterest", ""),
                        "volume_24h": ac.get("dayNtlVlm", ""),
                    })
            except Exception:
                # Fallback: use meta only + all_mids for price
                try:
                    dex_meta = info.meta(dex=dex_name)
                    for ai in dex_meta["universe"]:
                        name = ai["name"]
                        result.append({
                            "asset": name,
                            "deployer": dex_name,
                            "max_leverage": ai.get("maxLeverage", 0),
                            "mark_price": mids.get(name, ""),
                            "funding_rate": "",
                            "open_interest": "",
                            "volume_24h": "",
                        })
                except Exception:
                    continue
    except Exception:
        pass  # no HIP-3 data available

    # Filter
    if query:
        q = query.upper()
        result = [a for a in result if q in a["asset"].upper()]
    if deployer:
        result = [a for a in result if a.get("deployer", "") == deployer]

    # Sort
    sort_key = {"volume": "volume_24h", "oi": "open_interest", "name": "asset"}.get(sort, "volume_24h")
    if sort_key == "asset":
        result.sort(key=lambda x: x["asset"])
    else:
        result.sort(key=lambda x: float(x.get(sort_key) or "0"), reverse=True)

    output(result, opts["fields"])


@hl_app.command()
def prices(
    ctx: typer.Context,
    assets: Annotated[Optional[List[str]], typer.Argument(help="Asset names")] = None,
):
    """Current prices."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    if not assets:
        # Lightweight: all mid prices (including HIP-3)
        mids = get_all_mids(info)
        result = [{"asset": k, "mid": v} for k, v in sorted(mids.items()) if not k.startswith("@")]
        output(result, opts["fields"])
        return

    # Detailed: per-asset info
    resolver = get_resolver(info)
    mids = get_all_mids(info)

    # Build context lookup from default perps + HIP-3 dexes
    meta_ctxs = info.meta_and_asset_ctxs()
    ctx_lookup = {}
    for asset_info, asset_ctx in zip(meta_ctxs[0]["universe"], meta_ctxs[1]):
        ctx_lookup[asset_info["name"]] = asset_ctx

    # Load HIP-3 context for any HIP-3 assets requested
    hip3_dexes_needed = set()
    for name in assets:
        resolved = resolver.resolve(name)
        if ":" in resolved and resolved not in ctx_lookup:
            hip3_dexes_needed.add(resolved.split(":")[0])
    for dex in hip3_dexes_needed:
        try:
            dex_data = info.post("/info", {"type": "metaAndAssetCtxs", "dex": dex})
            for ai, ac in zip(dex_data[0]["universe"], dex_data[1]):
                ctx_lookup[ai["name"]] = ac
        except Exception:
            pass

    result = []
    for name in assets:
        resolved = resolver.resolve(name)
        ac = ctx_lookup.get(resolved, {})
        mid = mids.get(resolved, "")
        prev = ac.get("prevDayPx", "")
        change = ""
        if mid and prev:
            try:
                change = f"{(float(mid) / float(prev) - 1) * 100:.2f}"
            except (ValueError, ZeroDivisionError):
                pass
        result.append({
            "asset": resolved,
            "mid": mid,
            "mark": ac.get("markPx", mid),
            "oracle": ac.get("oraclePx", ""),
            "prev_day": prev,
            "change_pct": change,
        })

    output(result, opts["fields"])


@hl_app.command()
def book(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    depth: Annotated[int, typer.Option("--depth", help="Levels per side (max 20)")] = 5,
):
    """Order book depth."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    snapshot = info.l2_snapshot(resolved)
    levels = snapshot.get("levels", [[], []])

    bids = [{"price": lv["px"], "size": lv["sz"], "orders": lv["n"]} for lv in levels[0][:depth]]
    asks = [{"price": lv["px"], "size": lv["sz"], "orders": lv["n"]} for lv in levels[1][:depth]]

    result = {"asset": resolved, "bids": bids, "asks": asks}
    output(result, opts["fields"])


@hl_app.command()
def funding(
    ctx: typer.Context,
    assets: Annotated[Optional[List[str]], typer.Argument(help="Asset names")] = None,
    history: Annotated[bool, typer.Option("--history", help="Show historical rates")] = False,
    limit: Annotated[int, typer.Option("--limit", help="Number of periods")] = 20,
    start: Annotated[Optional[str], typer.Option("--start", help="Start time (ISO 8601)")] = None,
    end: Annotated[Optional[str], typer.Option("--end", help="End time (ISO 8601)")] = None,
):
    """Funding rates (current or historical)."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    if history:
        if not assets:
            die("validation_error", "MISSING_ARGUMENT", "Specify at least one asset for --history", hint="regard hl funding BTC --history")
        resolver = get_resolver(info)
        result = []
        for name in assets:
            resolved = resolver.resolve(name)
            start_ms = parse_time(start) if start else int(time.time() * 1000) - limit * 8 * 3600 * 1000
            end_ms = parse_time(end) if end else None
            data = info.funding_history(resolved, start_ms, end_ms)
            for h in data[-limit:]:
                rate = h.get("fundingRate", "0")
                result.append({
                    "asset": resolved,
                    "rate": rate,
                    "premium": h.get("premium", ""),
                    "annualized": f"{float(rate) * 3 * 365:.2f}",
                    "time": format_timestamp(h.get("time", 0)),
                })
        output(result, opts["fields"])
    else:
        # Current rates from metaAndAssetCtxs
        meta_ctxs = info.meta_and_asset_ctxs()
        asset_filter = {a.upper() for a in assets} if assets else None

        result = []
        for asset_info, asset_ctx in zip(meta_ctxs[0]["universe"], meta_ctxs[1]):
            name = asset_info["name"]
            if asset_filter and name.upper() not in asset_filter:
                continue
            rate = asset_ctx.get("funding", "0")
            result.append({
                "asset": name,
                "rate": rate,
                "premium": asset_ctx.get("premium", ""),
                "annualized": f"{float(rate) * 3 * 365:.2f}",
            })

        output(result, opts["fields"])


@hl_app.command()
def candles(
    ctx: typer.Context,
    asset: Annotated[str, typer.Argument(help="Asset name")],
    interval: Annotated[str, typer.Argument(help="1m 5m 15m 1h 4h 1d etc.")],
    limit: Annotated[int, typer.Option("--limit", help="Number of candles (max 5000)")] = 100,
    start: Annotated[Optional[str], typer.Option("--start", help="Start time (ISO 8601)")] = None,
    end: Annotated[Optional[str], typer.Option("--end", help="End time (ISO 8601)")] = None,
):
    """OHLCV price history."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    resolver = get_resolver(info)
    resolved = resolver.resolve(asset)

    end_ms = parse_time(end) if end else int(time.time() * 1000)
    if start:
        start_ms = parse_time(start)
    else:
        ms_per = interval_to_ms(interval)
        start_ms = end_ms - ms_per * limit

    data = info.candles_snapshot(resolved, interval, start_ms, end_ms)

    result = []
    for c in data[-limit:]:
        result.append({
            "time": format_timestamp(c["t"]),
            "open": c["o"],
            "high": c["h"],
            "low": c["l"],
            "close": c["c"],
            "volume": c["v"],
            "trades": c["n"],
        })

    output(result, opts["fields"])


_CRYPTO_DEPLOYERS = frozenset({"", "hyna"})


def _build_pulse_asset(name: str, asset_ctx: dict, deployer: str = "") -> dict:
    """Build a pulse asset dict from API context data."""
    mid = asset_ctx.get("markPx", "")
    prev = asset_ctx.get("prevDayPx", "")
    change_pct = ""
    if mid and prev:
        try:
            change_pct = f"{(float(mid) / float(prev) - 1) * 100:.2f}"
        except (ValueError, ZeroDivisionError):
            pass
    rate = asset_ctx.get("funding", "0")
    try:
        ann = f"{float(rate) * 3 * 365:.2f}"
    except (ValueError, TypeError):
        ann = ""
    return {
        "asset": name,
        "asset_class": "crypto" if deployer in _CRYPTO_DEPLOYERS else "tradfi",
        "price": mid,
        "change_24h": change_pct,
        "funding_rate": rate,
        "funding_annualized": ann,
        "volume_24h": asset_ctx.get("dayNtlVlm", ""),
        "open_interest": asset_ctx.get("openInterest", ""),
    }


@hl_app.command()
def pulse(
    ctx: typer.Context,
    top: Annotated[int, typer.Option("--top", help="Items per category (0 = all)")] = 10,
):
    """Market pulse — top movers, volume leaders, funding outliers, composite signals. Scans all perps including HIP-3."""
    opts = ctx.obj
    info = get_info(opts["testnet"])

    # Default perps
    meta_ctxs = info.meta_and_asset_ctxs()
    meta = meta_ctxs[0]
    ctxs = meta_ctxs[1]

    assets = []
    for asset_info, asset_ctx in zip(meta["universe"], ctxs):
        assets.append(_build_pulse_asset(asset_info["name"], asset_ctx))

    # HIP-3 deployer assets (stocks, commodities, community tokens)
    try:
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            try:
                dex_name = dex_info["name"]
                dex_data = info.post("/info", {"type": "metaAndAssetCtxs", "dex": dex_name})
                for ai, ac in zip(dex_data[0]["universe"], dex_data[1]):
                    assets.append(_build_pulse_asset(ai["name"], ac, deployer=dex_name))
            except Exception:
                continue
    except Exception:
        pass

    # Sort categories
    movers = sorted(
        [a for a in assets if a["change_24h"]],
        key=lambda x: abs(float(x["change_24h"])),
        reverse=True,
    )

    volume = sorted(
        assets,
        key=lambda x: float(x["volume_24h"] or "0"),
        reverse=True,
    )

    funding = sorted(
        [a for a in assets if a["funding_annualized"]],
        key=lambda x: abs(float(x["funding_annualized"])),
        reverse=True,
    )

    # Composite signals: assets appearing in 2+ of the top-20 lists
    signal_depth = max(top, 20) if top > 0 else len(assets)
    mover_names = {a["asset"] for a in movers[:signal_depth]}
    volume_names = {a["asset"] for a in volume[:signal_depth]}
    funding_names = {a["asset"] for a in funding[:signal_depth]}

    signals = []
    seen = set()
    for a in assets:
        name = a["asset"]
        if name in seen:
            continue
        flags = []
        if name in mover_names:
            flags.append("mover")
        if name in volume_names:
            flags.append("volume")
        if name in funding_names:
            flags.append("funding")
        if len(flags) >= 2:
            signals.append({**a, "flags": flags})
            seen.add(name)

    # Spot markets (no funding, separate lists)
    spot_assets = []
    try:
        spot_data = info.spot_meta_and_asset_ctxs()
        spot_meta = spot_data[0]
        spot_ctxs = spot_data[1]
        tokens = spot_meta["tokens"]

        for pair_info, pair_ctx in zip(spot_meta["universe"], spot_ctxs):
            # Resolve human-readable pair name from token indices
            base_idx, quote_idx = pair_info["tokens"]
            base_name = tokens[base_idx]["name"] if base_idx < len(tokens) else "?"
            quote_name = tokens[quote_idx]["name"] if quote_idx < len(tokens) else "?"
            name = f"{base_name}/{quote_name}"

            mid = pair_ctx.get("markPx", "")
            prev = pair_ctx.get("prevDayPx", "")
            change_pct = ""
            if mid and prev:
                try:
                    change_pct = f"{(float(mid) / float(prev) - 1) * 100:.2f}"
                except (ValueError, ZeroDivisionError):
                    pass
            spot_assets.append({
                "asset": name,
                "price": mid,
                "change_24h": change_pct,
                "volume_24h": pair_ctx.get("dayNtlVlm", ""),
            })
    except Exception:
        pass

    # Filter spot movers to pairs with meaningful volume (>$10k/day)
    spot_with_volume = [a for a in spot_assets if float(a["volume_24h"] or "0") > 10000]

    spot_movers = sorted(
        [a for a in spot_with_volume if a["change_24h"]],
        key=lambda x: abs(float(x["change_24h"])),
        reverse=True,
    )

    spot_volume = sorted(
        spot_assets,
        key=lambda x: float(x["volume_24h"] or "0"),
        reverse=True,
    )

    # Apply top limit
    if top > 0:
        movers = movers[:top]
        volume = volume[:top]
        funding = funding[:top]
        spot_movers = spot_movers[:top]
        spot_volume = spot_volume[:top]

    output({
        "movers": movers,
        "volume": volume,
        "funding": funding,
        "signals": signals,
        "spot_movers": spot_movers,
        "spot_volume": spot_volume,
        "total_assets": len(assets),
        "total_spot_assets": len(spot_assets),
    }, opts["fields"])
