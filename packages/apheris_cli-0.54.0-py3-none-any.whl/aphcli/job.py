import json
from ast import literal_eval
from pathlib import Path
from typing import Callable, Optional
from uuid import UUID
from warnings import warn

import typer
from typing_extensions import Annotated

from aphcli.api import job as job_api
from aphcli.api.compute import COMPUTE_SPEC_ACTIVATION_TIMEOUT, Resources
from aphcli.api.utils import prettytable_helpers
from aphcli.api.utils.comms import RequestError
from aphcli.utils import get_job_id

from .utils import exception_handled_call_404, validate_is_logged_in

app = typer.Typer(no_args_is_help=True)


def _exception_handled_call(func: Callable):
    """
    This is a wrapper for api-request containing functions.
    Behavior:
        - RequestError with 404 --> "Job not found. [...]"
        - other RequestError and JobsException --> print as is
    """

    err_msg = (
        "Job not found. Please check if the `job_id` and `compute_spec_id` are correct."
    )

    return exception_handled_call_404(func, job_api.JobsException, err_msg)


def _load_job_payload(payload: str):
    if len(payload) <= 255 and Path(payload).is_file():
        with open(payload, "rt") as f:
            return json.load(f)
    else:
        try:
            return literal_eval(payload)
        except ValueError:
            print(
                "The `payload` that you provided does not refer to an existing file. We "
                "tried to interpret it as a JSON object but weren't "
                "successful. Please check your `payload` argument."
            )
            raise typer.Exit(2)


def _structure_payload_for_display(payload: dict):
    return json.dumps(payload, indent=4, default=str)


@app.command(help="Submit a job to run it.")
def run(
    payload: Annotated[
        str,
        typer.Option(
            "--payload",
            help=(
                "Arguments to provide to the job. You can either provide the filepath "
                "to a JSON file, or a string that contains a JSON compatible dictionary."
            ),
        ),
    ] = None,
    compute_spec_id: Annotated[
        UUID,
        typer.Option(help=("The ID of the Compute Spec.")),
    ] = None,
    force: Annotated[
        bool, typer.Option("--force", "-f", help="Do not ask if user is certain.")
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Show more detailed information."),
    ] = False,
):
    validate_is_logged_in()

    if payload is None:
        warn("You did not provide a payload. So an empty payload will be submitted.")
        payload = "{}"
    payload = _load_job_payload(payload)

    if not force:
        print("About to submit job with parameters: ")
        print(_structure_payload_for_display(payload))
        if not typer.confirm("\nDo you want to proceed? (y/N)\n:"):
            print("\nCancelling run job.")
            return

    try:
        job_id = job_api.submit(payload, compute_spec_id, verbose)
        print(f"\nThe job was submitted! The job ID is {job_id}")
    except RequestError as err:
        if err.status_code == 404:
            print("Compute Spec not found.")
            raise typer.Exit(1)
        else:
            print("Something went wrong. The job could not be submitted.")
            print(err)
            raise typer.Exit(1)
    except job_api.JobsException as err:
        # JobsException already contain an easy-to-understand message
        print(str(err))
        raise typer.Exit(1)


@app.command(help="Schedule a job with specified datasets, model, and resources.")
def schedule(
    dataset_ids: Annotated[
        str,
        typer.Option(
            "--dataset_ids",
            help="Comma-separated dataset IDs, e.g. `id1,id2,id3`",
        ),
    ],
    model_id: Annotated[
        str,
        typer.Option(
            "--model_id",
            help="A model ID, e.g. statistics",
        ),
    ],
    model_version: Annotated[
        str,
        typer.Option(
            "--model_version",
            help="The version of the model to use, e.g. 0.0.5",
        ),
    ],
    payload: Annotated[
        str,
        typer.Option(
            "--payload",
            help="Arguments to provide to the job. You can either provide the filepath "
            "to a JSON file, or a string that contains a JSON compatible dictionary",
        ),
    ] = None,
    timeout: Annotated[
        Optional[float],
        typer.Option(
            "--timeout",
            help="""Timeout in seconds for waiting for compute spec to be running. Default is 10 minutes (600 seconds).
            This can happen for big models.""",
        ),
    ] = None,
    force: Annotated[
        bool, typer.Option("--force", "-f", help="Do not ask if user is certain.")
    ] = False,
    client_n_cpu: Annotated[
        Optional[float],
        typer.Option("--client_n_cpu", help="number of vCPUs of Compute Clients"),
    ] = None,
    client_n_gpu: Annotated[
        Optional[int],
        typer.Option("--client_n_gpu", help="number of GPUs of Compute Clients"),
    ] = None,
    client_memory: Annotated[
        Optional[int],
        typer.Option("--client_memory", help="memory of Compute Clients [MByte]"),
    ] = None,
    server_n_cpu: Annotated[
        Optional[float],
        typer.Option("--server_n_cpu", help="number of vCPUs of Compute Aggregators"),
    ] = None,
    server_n_gpu: Annotated[
        Optional[int],
        typer.Option("--server_n_gpu", help="number of GPUs of Compute Aggregators"),
    ] = None,
    server_memory: Annotated[
        Optional[int],
        typer.Option("--server_memory", help="memory of Compute Aggregators [MByte]"),
    ] = None,
    num_clients_per_gateway: Annotated[
        Optional[int],
        typer.Option(
            "--num_clients_per_gateway",
            help="Number of compute clients to spawn (optional)",
        ),
    ] = None,
    new_cs: Annotated[
        bool,
        typer.Option(
            "--new_cs",
            help="Create a new compute spec regardless of prior matching compute specs.",
        ),
    ] = False,
    use_v2: Annotated[
        bool,
        typer.Option(
            "--use-v2",
            "--use_v2",
            help=(
                "Use the v2 jobs endpoint, which handles the full lifecycle "
                "(activate, submit, execute, deactivate) server-side. "
                "Ignores --timeout and --new_cs."
            ),
        ),
    ] = False,
    queue_id: Annotated[
        Optional[str],
        typer.Option(
            "--queue-id",
            "--queue_id",
            help="Queue ID for sequential execution (v2 only). Jobs with the same queue ID run one at a time.",
        ),
    ] = None,
    no_auto_cleanup: Annotated[
        bool,
        typer.Option(
            "--no-auto-cleanup",
            "--no_auto_cleanup",
            help="Skip compute spec deactivation after job completion (v2 only).",
        ),
    ] = False,
):
    validate_is_logged_in()

    if payload is None:
        warn("You did not provide a payload. So an empty payload will be submitted.")
        payload = "{}"
    payload = _load_job_payload(payload)

    args = {
        "client_n_cpu": client_n_cpu,
        "client_n_gpu": client_n_gpu,
        "client_memory": client_memory,
        "server_n_cpu": server_n_cpu,
        "server_n_gpu": server_n_gpu,
        "server_memory": server_memory,
    }
    args = {k: v for k, v in args.items() if v is not None}
    resources = Resources(**args)

    if not force:
        msg = (
            "About to schedule job with parameters:\n"
            f"Dataset IDs: {dataset_ids}\n"
            f"Model: {model_id}:{model_version}\n"
            f"Payload: \n{_structure_payload_for_display(payload)}\n"
            "Resources:\n"
            f"Client: {resources.client_n_cpu} CPU, {resources.client_n_gpu} GPU, "
            f"{resources.client_memory} MB memory\n"
            f"Server: {resources.server_n_cpu} CPU, {resources.server_n_gpu} GPU, "
            f"{resources.server_memory} MB memory\n"
        )

        if num_clients_per_gateway is not None:
            msg += f"Number of Clients: {num_clients_per_gateway}\n"

        print(msg)

        if not typer.confirm("\nDo you want to proceed? (y/N)\n:"):
            print("\nCancelling schedule job.")
            return

    if not use_v2:
        ignored = [
            f
            for f, v in [("--queue-id", queue_id), ("--no-auto-cleanup", no_auto_cleanup)]
            if v
        ]
        if ignored:
            verb = "are" if len(ignored) > 1 else "is"
            warn(
                f"{' and '.join(ignored)} {verb} only used with --use-v2 and will be ignored."
            )

    try:
        job = job_api.run(
            dataset_ids.split(","),
            payload,
            model_id,
            model_version,
            resources,
            num_clients_per_gateway,
            timeout,
            new_cs=new_cs,
            use_v2=use_v2,
            queue_id=queue_id,
            no_auto_cleanup=no_auto_cleanup,
        )
        print(f"\nThe job was submitted! The job ID is {job.id}")
    except RequestError as err:
        if err.status_code == 404:
            print("Compute Spec not found.")
        else:
            print(f"Something went wrong. The job could not be submitted.\n{str(err)}")
        raise typer.Exit(1)
    except TimeoutError:
        minutes = COMPUTE_SPEC_ACTIVATION_TIMEOUT // 60
        print(f"""
        Error: The compute specification is not running after {minutes} minutes of waiting.

        Possible reasons:
        - The requested resources may not be available in your environment
        - There might be an issue with the specified model version
        - The system might be experiencing high load or maintenance

        Suggested actions:
        - Try reducing the resource requirements (CPU, memory)
        - Check if the model version is correct
        - Try again later when the system might have more resources available
        - Use the compute spec commands for more detailed status information
        """)
        raise typer.Exit(1)
    except job_api.JobsException as err:
        # JobsException already contain an easy-to-understand message
        print(str(err))
        raise typer.Exit(1)
    except Exception as err:
        if "Multiple running Compute Specs found for" in str(err):
            print(f"Something went wrong. The job could not be submitted.\n{str(err)}")
            raise typer.Exit(1)
        else:
            raise


@app.command(help="List jobs.")
def list(
    compute_spec_id: Annotated[
        UUID,
        typer.Option(help="The ID of the Compute Spec. If `None`, returns all jobs"),
    ] = None,
    use_v2: Annotated[
        bool,
        typer.Option("--use-v2", "--use_v2", help="Use the v2 jobs endpoint."),
    ] = False,
):
    validate_is_logged_in()
    try:
        jobs = job_api.list_jobs(compute_spec_id, use_v2=use_v2)

        if not jobs:
            print("\nNo jobs found.")
            return

        field_names = ["duration", "id", "status", "created_at"]
        if use_v2:
            field_names = [
                "id",
                "status",
                "created_by",
                "updated_at",
                "duration",
                "queue_id",
            ]
        table = prettytable_helpers.table_from_collection_of_base_models(
            jobs,
            index_column="id",
            field_names=field_names,
        )
        table.align.update(
            {
                "id": "l",
                "status": "l",
                "created_by": "l",
                "updated_at": "l",
                "duration": "r",
                "queue_id": "l",
            }
            if use_v2
            else {"duration": "r", "id": "l", "status": "l", "created_at": "l"}
        )
        print(f"\n{table}")
    except job_api.JobsException as err:
        # JobsException already contain an easy-to-understand message
        print(str(err))
        raise typer.Exit(1)

    except RequestError as err:
        if err.status_code == 404:
            print("Compute Spec not found.")
            raise typer.Exit(1)
        else:
            print("Something went wrong. The Compute Spec jobs were not found.")
            print(err)
            raise typer.Exit(1)


@app.command(help="Get the status and details of a job.")
def status(
    job_id: Annotated[
        Optional[str],
        typer.Option(
            "--job-id",
            help="The ID of the job. If `None`, use the most recently used job ID.",
        ),
    ] = None,
    verbose: Annotated[
        bool, typer.Option("--verbose", "-v", help="Show more detailed information.")
    ] = False,
    use_v2: Annotated[
        bool,
        typer.Option("--use-v2", "--use_v2", help="Use the v2 jobs endpoint."),
    ] = False,
):
    validate_is_logged_in()

    if job_id is not None and not use_v2:
        try:
            UUID(job_id)
        except ValueError:
            print(f"Invalid job ID '{job_id}': expected a UUID for v1 mode.")
            raise typer.Exit(1)

    # We do not propagate `verbose` into `job_api.get` to show information on the used
    # `job_id` in case we use a cached one.
    job_data = _exception_handled_call(job_api.get)(job_id, use_v2=use_v2)
    if verbose:
        print(f"\n{job_data}")
    else:
        print(f"\nstatus: {job_data.status}")


@app.command(help="Abort a currently running job.")
def abort(
    job_id: Annotated[
        Optional[str],
        typer.Option(
            "--job-id",
            help="The ID of the job. If `None`, use the most recently used job ID.",
        ),
    ] = None,
    force: Annotated[
        bool, typer.Option("--force", "-f", help="Do not ask if user is certain.")
    ] = False,
    use_v2: Annotated[
        bool,
        typer.Option("--use-v2", "--use_v2", help="Use the v2 jobs endpoint."),
    ] = False,
):
    validate_is_logged_in()

    if not job_id:
        job_id = get_job_id(job_id, verbose=True)
    elif not use_v2:
        try:
            UUID(job_id)
        except ValueError:
            print(f"Invalid job ID '{job_id}': expected a UUID for v1 mode.")
            raise typer.Exit(1)

    if not force:
        if not typer.confirm("\nDo you want to proceed? (y/N)\n:"):
            print("\nCancelling abort job.")
            return

    _exception_handled_call(job_api.abort)(job_id, use_v2=use_v2)
    print("Job aborted.")


@app.command(help="Download the results of a job.")
def download_results(
    download_path: Annotated[
        Path,
        typer.Argument(
            help="Directory to store the downloaded results",
            dir_okay=True,
            resolve_path=True,
        ),
    ] = None,
    job_id: Annotated[
        UUID,
        typer.Option(
            "--job-id",
            help="The ID of the job. If `None`, use the most recently used job ID.",
        ),
    ] = None,
):
    if download_path is None:
        if job_id:
            jstr = f"{job_id}_"
        else:
            jstr = ""
        download_path = Path(f"job_{jstr}results")

    _exception_handled_call(job_api.download_results)(download_path, job_id)
    print(f"\nSuccessfully downloaded job outputs to {download_path.absolute()}")


@app.command(
    help="Download the logs for a job, which can be optionally written to a file."
)
def logs(
    storage_path: Annotated[
        Path,
        typer.Option(
            help="File in which to store logs (plaintext, or JSON with --orchestrator)",
            dir_okay=False,
            resolve_path=True,
        ),
    ] = None,
    job_id: Annotated[
        UUID,
        typer.Option(
            "--job-id",
            help="The ID of the job. If `None`, use the most recently used job ID.",
        ),
    ] = None,
    orchestrator: Annotated[
        bool,
        typer.Option(
            "--orchestrator",
            help="Fetch logs from orchestrator service instead of job service",
        ),
    ] = False,
):
    match (orchestrator, bool(storage_path)):
        case (True, True):
            log_data = _exception_handled_call(job_api.logs_from_orchestrator)(job_id)
            print(f"Writing logs to {storage_path}")
            try:
                storage_path.write_text(
                    json.dumps([e.model_dump() for e in log_data], indent=2)
                )
            except OSError:
                print(
                    f"Could not write the logs to {storage_path}. Is the path writeable?"
                )
                raise typer.Exit(1)
        case (True, False):
            log_data = _exception_handled_call(job_api.logs_from_orchestrator)(job_id)
            for entry in log_data:
                print(
                    f"[{entry.created_at}] [{entry.client_id}] [{entry.container}] {entry.line}"
                )
        case (False, True):
            log_data = _exception_handled_call(job_api.logs)(job_id)
            print(f"Writing logs to {storage_path}")
            try:
                storage_path.write_text(log_data)
            except OSError:
                print(
                    f"Could not write the logs to {storage_path}. Is the path writeable?"
                )
                raise typer.Exit(1)
        case (False, False):
            print(_exception_handled_call(job_api.logs)(job_id))
