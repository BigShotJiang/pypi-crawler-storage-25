import threading

import typer

from aphcli.api.orgs import list_organizations
from aphcli.api.utils.comms import RequestError
from aphcli.api.utils.prettytable_helpers import table_from_collection_of_dicts
from aphcli.utils import validate_is_logged_in

app = typer.Typer(
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)


_ORG_ID_TO_NAME: dict[str, str] | None = None
_ORG_ID_TO_NAME_LOCK = threading.Lock()


def _get_org_id_to_name() -> dict[str, str]:
    global _ORG_ID_TO_NAME

    # Fast path: return the cached mapping if it is already initialized.
    if _ORG_ID_TO_NAME is not None:
        return _ORG_ID_TO_NAME

    # Ensure only a single thread populates the cache at a time.
    with _ORG_ID_TO_NAME_LOCK:
        if _ORG_ID_TO_NAME is not None:
            return _ORG_ID_TO_NAME

        mapping: dict[str, str] = {}
        try:
            organizations = list_organizations()
            for org in organizations:
                if org.get("remoteId"):
                    mapping[str(org.get("remoteId"))] = str(org.get("name", ""))
        except RequestError:
            # If we cannot retrieve organizations for any reason, fall back to an
            # empty mapping and just display raw IDs.
            mapping = {}

        _ORG_ID_TO_NAME = mapping
        return _ORG_ID_TO_NAME


def format_recipient_org_id(recipient_org_id: str | None) -> str | None:
    if not recipient_org_id:
        return recipient_org_id

    org_name = _get_org_id_to_name().get(recipient_org_id)
    if org_name:
        return f"{recipient_org_id} ({org_name})"

    return recipient_org_id


@app.command(name="list", help="List organizations.")
def list_orgs():
    """
    List organizations visible to the current user.

    Uses the backend `/organizations` endpoint. If the request fails, an error is
    shown and the command exits with a non-zero status code.
    """
    validate_is_logged_in()

    try:
        organizations = list_organizations()
    except RequestError as err:
        if err.status_code == 401:
            print("You are not authorized to list organizations.")
            raise typer.Exit(1)
        message = err.message or "Error while listing organizations."
        print(message)
        raise typer.Exit(1)

    if not organizations:
        print("No organizations found.")
        return

    rows = []
    for org in organizations:

        if org.get("remoteId"):
            rows.append({"name": org.get("name", ""), "orgId": org.get("remoteId")})

    if not rows:
        print("No organizations found.")
        return

    table = table_from_collection_of_dicts(
        rows,
        field_names=["name", "orgId"],
        include_index=True,
        left_align=True,
    )
    # Avoid wrapping IDs across multiple lines to make copying easier.
    table._max_table_width = 0
    print(table)
