from typing import Any, Dict, List

from apheris_auth.config import settings

from aphcli.utils import get_oauth_session

from .utils.comms import exception_handled_request


def list_organizations() -> List[Dict[str, Any]]:
    """
    List organizations visible to the current user.

    Maps to:
        GET /organizations
    """
    session = get_oauth_session()
    url = f"{settings.API_ORCHESTRATOR_BASE_URL}/organizations"

    response = exception_handled_request(session, url, "get")
    data = response.json()

    if isinstance(data, list):
        return data

    # Fallback in case the API changes shape unexpectedly.
    return []
