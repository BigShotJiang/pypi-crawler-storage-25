from multiprocessing import cpu_count
import os
import re
import sys
import platform
import subprocess

from setuptools import setup, Extension, find_namespace_packages
from setuptools.command.build_ext import build_ext
from distutils.version import LooseVersion
from distutils import dir_util

setup_path = os.path.abspath(__file__)
os.chdir(os.path.normpath(os.path.join(setup_path, os.pardir)))

dir_util.copy_tree("data", "python/mspasspy/data")


class CMakeExtension(Extension):
    def __init__(self, name, sourcedir="cxx"):
        Extension.__init__(self, name, sources=[])
        self.sourcedir = os.path.abspath(sourcedir)


class CMakeBuild(build_ext):
    def run(self):
        try:
            out = subprocess.check_output(["cmake", "--version"])
        except OSError:
            raise RuntimeError(
                "CMake must be installed to build the following extensions: "
                + ", ".join(e.name for e in self.extensions)
            )

        if platform.system() == "Windows":
            cmake_version = LooseVersion(
                re.search(r"version\s*([\d.]+)", out.decode()).group(1)
            )
            if cmake_version < "3.1.0":
                raise RuntimeError("CMake >= 3.1.0 is required on Windows")

        for ext in self.extensions:
            self.build_extension(ext)

    def build_extension(self, ext):
        extdir = os.path.abspath(os.path.dirname(self.get_ext_fullpath(ext.name)))
        cmake_args = [
            "-DCMAKE_LIBRARY_OUTPUT_DIRECTORY=" + extdir,
            "-DPYTHON_EXECUTABLE=" + sys.executable,
        ]

        requested_cfg = os.environ.get("MSPASS_CMAKE_BUILD_TYPE") or os.environ.get(
            "CMAKE_BUILD_TYPE"
        )
        if requested_cfg:
            cfg = requested_cfg
        else:
            cfg = "Debug" if self.debug else "Release"
        build_args = ["--config", cfg]

        if platform.system() == "Windows":
            cmake_args += [
                "-DCMAKE_LIBRARY_OUTPUT_DIRECTORY_{}={}".format(cfg.upper(), extdir)
            ]
            if sys.maxsize > 2**32:
                cmake_args += ["-A", "x64"]
            build_args += ["--", "/m"]
        else:
            cores = os.cpu_count() or 4
            cmake_args += ["-DCMAKE_BUILD_TYPE=" + cfg]
            build_args += ["--", "-j" + str(cores)]

        env = os.environ.copy()
        env["CXXFLAGS"] = '{} -DVERSION_INFO=\\"{}\\"'.format(
            env.get("CXXFLAGS", ""), self.distribution.get_version()
        )
        if not os.path.exists(self.build_temp):
            os.makedirs(self.build_temp)
        subprocess.check_call(
            ["cmake", ext.sourcedir] + cmake_args, cwd=self.build_temp, env=env
        )
        subprocess.check_call(
            ["cmake", "--build", "."] + build_args, cwd=self.build_temp
        )


setup(
    name="mspasspy",
    ext_modules=[CMakeExtension("mspasspy.ccore")],
    cmdclass=dict(build_ext=CMakeBuild),
    zip_safe=False,
    package_dir={"": "python"},
    packages=find_namespace_packages(
        where="python", include=["mspasspy", "mspasspy.*"]
    ),
    package_data={"": ["*.yaml", "*.pf"]},
    include_package_data=True,
)
