"""
traces.py — KiCad 10 schematic property editor plugin
Lets you select a schematic component, inspect/edit its metadata, and fetch
JLCPCB/LCSC stock and price into schematic properties.
"""

import re
import json
import os
import shutil
import ssl
import subprocess
import tempfile
import time
import urllib.request
import webbrowser
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path
from urllib.error import URLError, HTTPError
from urllib.request import Request, urlopen, build_opener, HTTPSHandler

import pcbnew
import wx

# KiCad's bundled Python on macOS doesn't load system certs automatically.
# Install a global opener that loads them explicitly so HTTPS works.
_ssl_ctx = ssl.create_default_context()
try:
    import certifi
    _ssl_ctx = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    if os.path.exists("/etc/ssl/cert.pem"):
        _ssl_ctx = ssl.create_default_context(cafile="/etc/ssl/cert.pem")
urllib.request.install_opener(build_opener(HTTPSHandler(context=_ssl_ctx)))


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

BACKEND_URL = "https://usetraces.com"


class AuthManager:
    _CONFIG_DIR = Path.home() / ".config" / "traces"
    _TOKEN_FILE = _CONFIG_DIR / "auth.json"

    def __init__(self):
        self.token: str = ""
        self.email: str = ""
        self.plan: str = "free"
        self._load()

    def _load(self) -> None:
        if self._TOKEN_FILE.exists():
            try:
                data = json.loads(self._TOKEN_FILE.read_text())
                self.token = data.get("access_token", "")
                self.email = data.get("email", "")
                self.plan = data.get("plan", "free")
            except Exception:
                pass

    def save(self, access_token: str, email: str, plan: str = "free") -> None:
        self._CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self._TOKEN_FILE.write_text(json.dumps({"access_token": access_token, "email": email, "plan": plan}))
        try:
            os.chmod(self._TOKEN_FILE, 0o600)
        except OSError:
            pass
        self.token = access_token
        self.email = email
        self.plan = plan

    def clear(self) -> None:
        self._TOKEN_FILE.unlink(missing_ok=True)
        self.token = ""
        self.email = ""
        self.plan = "free"

    def is_authenticated(self) -> bool:
        return bool(self.token)

    def auth_headers(self) -> dict:
        return {"Authorization": f"Bearer {self.token}"} if self.token else {}

    def display_name(self) -> str:
        prefix = self.email.split("@")[0] if self.email else "User"
        parts = re.split(r"[._]", prefix)
        return " ".join(p.capitalize() for p in parts if p)

    def plan_label(self) -> str:
        return "Pro plan" if self.plan in ("active", "trialing") else "Free plan"


class LoginDialog(wx.Dialog):
    def __init__(self, auth: AuthManager):
        super().__init__(None, title="traces — Sign In", size=(420, 220),
                         style=wx.DEFAULT_DIALOG_STYLE)
        self.auth = auth
        self._session_id = ""
        self._poll_count = 0
        self._gen = 0  # incremented on each new sign-in attempt; stale polls self-cancel
        self._build_ui()
        self.CentreOnScreen()

    def _build_ui(self) -> None:
        sizer = wx.BoxSizer(wx.VERTICAL)

        msg = wx.StaticText(
            self,
            label="Sign in or create an account to use traces.\n"
                  "A browser window will open — complete the sign-in, then return here.",
        )
        msg.Wrap(380)
        sizer.Add(msg, 0, wx.ALL, 16)

        btn_row = wx.BoxSizer(wx.HORIZONTAL)
        self._btn = wx.Button(self, label="Open sign-in page")
        btn_cancel = wx.Button(self, wx.ID_CANCEL, label="Cancel")
        btn_row.Add(self._btn, 0, wx.RIGHT, 10)
        btn_row.Add(btn_cancel, 0)
        sizer.Add(btn_row, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 16)

        self._status = wx.StaticText(self, label="")
        sizer.Add(self._status, 0, wx.LEFT | wx.BOTTOM, 16)

        self.SetSizer(sizer)
        self._btn.Bind(wx.EVT_BUTTON, self._on_open)
        btn_cancel.Bind(wx.EVT_BUTTON, lambda _: self.EndModal(wx.ID_CANCEL))

    def _on_open(self, _event) -> None:
        try:
            req = Request(
                f"{BACKEND_URL}/auth/init",
                data=b"{}",
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
            self._session_id = data["session_id"]
            login_url = data["login_url"]
        except Exception as exc:
            self._status.SetLabel(f"Could not reach backend: {exc}")
            return

        webbrowser.open(login_url)
        self._gen += 1
        self._poll_count = 0
        self._btn.SetLabel("Open sign-in page again")
        self._status.SetLabel("Browser opened — complete sign-in, then return here...")
        wx.CallLater(2000, self._poll, self._gen)

    def _poll(self, gen: int) -> None:
        if gen != self._gen:
            return  # stale, a newer attempt has started
        self._poll_count += 1
        if self._poll_count > 150:
            self._status.SetLabel("Timed out. Click the button to try again.")
            self._btn.SetLabel("Open sign-in page")
            return
        try:
            with urlopen(f"{BACKEND_URL}/auth/status/{self._session_id}", timeout=5) as resp:
                data = json.loads(resp.read().decode())
            if data.get("status") == "complete":
                token = data["token"]
                req = Request(
                    f"{BACKEND_URL}/auth/me",
                    headers={"Authorization": f"Bearer {token}"},
                )
                with urlopen(req, timeout=5) as resp:
                    me = json.loads(resp.read().decode())
                self.auth.save(token, me.get("email", ""), me.get("subscription_status", "free"))
                self.EndModal(wx.ID_OK)
                return
        except Exception:
            pass
        wx.CallLater(2000, self._poll, gen)


# ---------------------------------------------------------------------------
# Inline schematic parser (kicad_sch.py logic embedded so the plugin is
# self-contained — or you can import from kicad_sch if it lives alongside)
# ---------------------------------------------------------------------------

def _tokenize(text):
    token_re = re.compile(
        r'\(|\)'
        r'|"(?:[^"\\]|\\.)*"'
        r'|[^\s()"]+'
    )
    return token_re.findall(text)


class _Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self):
        return self.tokens[self.pos]

    def consume(self):
        t = self.tokens[self.pos]
        self.pos += 1
        return t

    def parse_node(self):
        if self.peek() == '(':
            return self.parse_list()
        return self.consume()

    def parse_list(self):
        self.consume()  # '('
        items = []
        while self.peek() != ')':
            items.append(self.parse_node())
        self.consume()  # ')'
        return items

    def parse_root(self):
        return self.parse_list()


def _parse(text):
    return _Parser(_tokenize(text)).parse_root()


def _is_flat(node):
    return not any(isinstance(c, list) for c in node)


def _serialize(node, indent=0):
    if isinstance(node, str):
        return node
    tab = '\t' * indent
    if _is_flat(node):
        return '(' + ' '.join(node) + ')'
    head = node[0]
    rest = node[1:]
    inline_scalars = []
    child_nodes = []
    hit_list = False
    for item in rest:
        if not hit_list and isinstance(item, str):
            inline_scalars.append(item)
        else:
            hit_list = True
            child_nodes.append(item)
    first_line = '(' + ' '.join([head] + inline_scalars)
    if not child_nodes:
        return first_line + ')'
    lines = [first_line]
    for child in child_nodes:
        if isinstance(child, list):
            lines.append('\t' * (indent + 1) + _serialize(child, indent + 1))
        else:
            lines.append('\t' * (indent + 1) + child)
    lines.append(tab + ')')
    return '\n'.join(lines)


def _make_property_node(key, value, at=(0, 0, 0), hide=True):
    at_node = ['at', str(at[0]), str(at[1]), str(at[2])]
    show_name_node = ['show_name', 'no']
    dnap_node = ['do_not_autoplace', 'no']
    font_node = ['font', ['size', '1.27', '1.27']]
    effects_node = ['effects', font_node]
    node = ['property', f'"{key}"', f'"{value}"', at_node, show_name_node, dnap_node]
    if hide:
        node.append(['hide', 'yes'])
    node.append(effects_node)
    return node


class KiCadSchematic:
    def __init__(self, path):
        self.path = path
        with open(path, 'r', encoding='utf-8') as f:
            self.raw = f.read()
        self.tree = _parse(self.raw)
        self._index = self._build_index()

    def _build_index(self):
        index = {}
        for node in self.tree:
            if not isinstance(node, list) or node[0] != 'symbol':
                continue
            ref = self._get_prop_value(node, 'Reference')
            if ref:
                index[ref] = node
        return index

    def _rebuild_index(self):
        self._index = self._build_index()

    @staticmethod
    def _get_prop_node(symbol_node, key):
        for child in symbol_node:
            if (isinstance(child, list)
                    and child[0] == 'property'
                    and child[1] == f'"{key}"'):
                return child
        return None

    @staticmethod
    def _get_prop_value(symbol_node, key):
        node = KiCadSchematic._get_prop_node(symbol_node, key)
        return node[2].strip('"') if node else None

    def _require_ref(self, reference):
        if reference not in self._index:
            raise KeyError(f"Reference '{reference}' not found")
        return self._index[reference]

    def get_references(self):
        return sorted(self._index.keys())

    def get_properties(self, reference):
        sym = self._require_ref(reference)
        props = {}
        for child in sym:
            if isinstance(child, list) and child[0] == 'property':
                k = child[1].strip('"')
                v = child[2].strip('"')
                props[k] = v
        return props

    def get_property(self, reference, key):
        return self._get_prop_value(self._require_ref(reference), key)

    def add_property(self, reference, key, value, hide=True, at=(0, 0, 0)):
        sym = self._require_ref(reference)
        if self._get_prop_node(sym, key) is not None:
            raise ValueError(f"Property '{key}' already exists on '{reference}'")
        new_node = _make_property_node(key, value, at=at, hide=hide)
        insert_at = len(sym)
        for i, child in enumerate(sym):
            if isinstance(child, list) and child[0] == 'pin':
                insert_at = i
                break
        sym.insert(insert_at, new_node)

    def update_property(self, reference, key, value):
        sym = self._require_ref(reference)
        node = self._get_prop_node(sym, key)
        if node is None:
            raise KeyError(f"Property '{key}' not found on '{reference}'")
        node[2] = f'"{value}"'
        if key == 'Reference':
            self._rebuild_index()

    def set_property(self, reference, key, value, hide=True, at=(0, 0, 0)):
        sym = self._require_ref(reference)
        node = self._get_prop_node(sym, key)
        if node is not None:
            node[2] = f'"{value}"'
            if key == 'Reference':
                self._rebuild_index()
        else:
            self.add_property(reference, key, value, hide=hide, at=at)

    def delete_property(self, reference, key):
        if key in ('Reference', 'Value'):
            raise ValueError(f"Cannot delete required property '{key}'")
        sym = self._require_ref(reference)
        node = self._get_prop_node(sym, key)
        if node is None:
            raise KeyError(f"Property '{key}' not found on '{reference}'")
        sym.remove(node)

    def write(self, path=None):
        out = path or self.path
        with open(out, 'w', encoding='utf-8') as f:
            f.write(_serialize(self.tree, 0) + '\n')


# ---------------------------------------------------------------------------
# Property CRUD dialog
# ---------------------------------------------------------------------------

PROTECTED = {'Reference', 'Value'}
BACKEND_URL = "https://usetraces.com"
JLCPCB_SOURCE_URL = f"{BACKEND_URL}/jobs/jlcpcb/source"
JLCPCB_SEARCH_URL = f"{BACKEND_URL}/jobs/jlcpcb/search"
DIGIKEY_SOURCE_URL = f"{BACKEND_URL}/jobs/digikey/source"
DIGIKEY_SEARCH_URL = f"{BACKEND_URL}/jobs/digikey/search"
DIGIKEY_DATASHEET_URL = f"{BACKEND_URL}/jobs/digikey/datasheet"
DATASHEET_FETCH_URL = f"{BACKEND_URL}/jobs/datasheet/fetch"
NETLIST_TYPO_URL = f"{BACKEND_URL}/jobs/netlist/typo"
NETLIST_CONSISTENCY_URL = f"{BACKEND_URL}/jobs/netlist/consistency"
NETLIST_ORPHAN_URL = f"{BACKEND_URL}/jobs/netlist/orphan"
NETLIST_NEARDUPLICATE_URL = f"{BACKEND_URL}/jobs/netlist/nearduplicate"
SRC_CHECKS = {
    "Typos": NETLIST_TYPO_URL,
    "Consistency": NETLIST_CONSISTENCY_URL,
    "Orphans": NETLIST_ORPHAN_URL,
    "Near dups": NETLIST_NEARDUPLICATE_URL,
}
JLCPCB_FIELD_NAMES = ("LCSC", "LCSC Part", "JLCPCB Part", "Supplier Part")
DIGIKEY_FIELD_NAMES = ("Digikey Part Number", "Digi-Key Part Number", "DigiKey Part Number")
NA_SUPPLIERS = {"N/A", "NA", "NONE"}
QUANTITY_FIELD = "Quantity Available"
PRICE_FIELD = "Price"
TIMESTAMP_FIELD = "Timestamp"
DATASHEET_URL_FIELD = "Datasheet"
DATASHEET_LOCAL_FIELD = "Datasheet Local"
DATASHEET_FIELD_NAMES = ("Datasheet", "Datasheet URL")


def _first_property(props, names):
    lowered = {key.lower(): value for key, value in props.items()}
    for name in names:
        value = lowered.get(name.lower(), "")
        if value:
            return value
    return ""


class _AccountWidget(wx.Panel):
    _AVATAR = 30
    _GAP = 8

    def __init__(self, parent, auth: "AuthManager", on_click):
        super().__init__(parent, style=wx.NO_BORDER)
        self._auth = auth
        self._on_click = on_click
        self.SetBackgroundStyle(wx.BG_STYLE_PAINT)
        self.SetCursor(wx.Cursor(wx.CURSOR_HAND))
        self.Bind(wx.EVT_PAINT, self._on_paint)
        self.Bind(wx.EVT_LEFT_UP, lambda _: on_click())
        self._recalc_size()

    def _fonts(self):
        base = self.GetFont()
        name_font = base
        name_font = wx.Font(base)
        name_font.SetWeight(wx.FONTWEIGHT_BOLD)
        plan_font = wx.Font(base)
        plan_font.SetPointSize(max(8, base.GetPointSize() - 1))
        return name_font, plan_font

    def _recalc_size(self):
        dc = wx.ClientDC(self)
        name_font, plan_font = self._fonts()
        dc.SetFont(name_font)
        nw, nh = dc.GetTextExtent(self._auth.display_name())
        dc.SetFont(plan_font)
        pw, ph = dc.GetTextExtent(self._auth.plan_label())
        h = max(self._AVATAR, nh + 2 + ph) + 4
        x0 = (h - self._AVATAR) // 2  # left padding = vertical padding
        w = x0 + self._AVATAR + self._GAP + max(nw, pw) + 4
        self.SetMinSize((w, h))

    def _on_paint(self, _event):
        dc = wx.AutoBufferedPaintDC(self)
        bg = self.GetParent().GetBackgroundColour()
        dc.SetBackground(wx.Brush(bg))
        dc.Clear()

        w, h = self.GetSize()
        a = self._AVATAR
        y0 = (h - a) // 2
        x0 = y0  # equal padding on left as top/bottom

        gc = wx.GraphicsContext.Create(dc)
        gc.SetBrush(wx.Brush(wx.Colour(85, 85, 85)))
        gc.SetPen(wx.NullPen)
        gc.DrawRoundedRectangle(x0, y0, a, a, a * 0.28)

        letter = (self._auth.display_name() or "?")[0].upper()
        icon_font = wx.Font(int(a * 0.44), wx.FONTFAMILY_DEFAULT,
                            wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_BOLD)
        gc.SetFont(gc.CreateFont(icon_font, wx.WHITE))
        tw, th = gc.GetTextExtent(letter)
        gc.DrawText(letter, x0 + (a - tw) / 2, y0 + (a - th) / 2)

        name_font, plan_font = self._fonts()
        x = x0 + a + self._GAP
        dc.SetFont(name_font)
        nw, nh = dc.GetTextExtent(self._auth.display_name())
        dc.SetFont(plan_font)
        pw, ph = dc.GetTextExtent(self._auth.plan_label())
        ty = (h - (nh + 2 + ph)) // 2

        dc.SetFont(name_font)
        dc.SetTextForeground(self.GetForegroundColour())
        dc.DrawText(self._auth.display_name(), x, ty)

        dc.SetFont(plan_font)
        dc.SetTextForeground(wx.Colour(150, 150, 150))
        dc.DrawText(self._auth.plan_label(), x, ty + nh + 2)

    def refresh(self):
        self._recalc_size()
        self.Refresh()
        self.GetParent().Layout()


class PartSearchDialog(wx.Dialog):
    """Semantic part search dialog — describe what you need, get a sourced part."""

    SUPPLIERS = ["JLCPCB / LCSC", "DigiKey"]

    def __init__(self, parent, auth: AuthManager, prefill_footprint: str = ""):
        super().__init__(parent, title="Search for Part", size=(480, 520),
                         style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.auth = auth
        self.result = None
        self._job_id = ""
        self._poll_gen = 0
        self._build_ui(prefill_footprint)
        self.CentreOnParent()

    def _build_ui(self, prefill_footprint: str) -> None:
        outer = wx.BoxSizer(wx.VERTICAL)

        # Supplier
        supplier_row = wx.BoxSizer(wx.HORIZONTAL)
        supplier_row.Add(wx.StaticText(self, label="Supplier:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)
        self._supplier = wx.Choice(self, choices=self.SUPPLIERS)
        self._supplier.SetSelection(0)
        supplier_row.Add(self._supplier, 1)
        outer.Add(supplier_row, 0, wx.EXPAND | wx.ALL, 12)

        # Description
        outer.Add(wx.StaticText(self, label="Describe what you need:"), 0, wx.LEFT | wx.RIGHT, 12)
        self._desc = wx.TextCtrl(self, size=(-1, 80), style=wx.TE_MULTILINE | wx.TE_PROCESS_ENTER)
        self._desc.SetHint("e.g. \"3.3V LDO 500mA SOT-23-5 low dropout\" or \"2.2k 0603 resistor\"")
        outer.Add(self._desc, 0, wx.EXPAND | wx.ALL, 12)

        # Constraints
        outer.Add(wx.StaticLine(self), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 12)
        outer.Add(wx.StaticText(self, label="Optional constraints:"), 0, wx.LEFT | wx.TOP, 12)

        grid = wx.FlexGridSizer(3, 2, 6, 8)
        grid.AddGrowableCol(1)

        grid.Add(wx.StaticText(self, label="Package:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self._footprint = wx.TextCtrl(self, value=prefill_footprint)
        self._footprint.SetHint("e.g. 0603, SOT-23-5")
        grid.Add(self._footprint, 1, wx.EXPAND)

        grid.Add(wx.StaticText(self, label="Max price ($/unit):"), 0, wx.ALIGN_CENTER_VERTICAL)
        self._max_price = wx.TextCtrl(self)
        self._max_price.SetHint("e.g. 0.50")
        grid.Add(self._max_price, 1, wx.EXPAND)

        grid.Add(wx.StaticText(self, label="Min stock (units):"), 0, wx.ALIGN_CENTER_VERTICAL)
        self._min_qty = wx.TextCtrl(self)
        self._min_qty.SetHint("e.g. 1000")
        grid.Add(self._min_qty, 1, wx.EXPAND)

        outer.Add(grid, 0, wx.EXPAND | wx.ALL, 12)

        # Search button
        self._btn_search = wx.Button(self, label="Search")
        self._btn_search.Bind(wx.EVT_BUTTON, self._on_search)
        outer.Add(self._btn_search, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 12)

        # Status
        self._status = wx.StaticText(self, label="")
        outer.Add(self._status, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 12)

        # Result panel (hidden until search completes)
        outer.Add(wx.StaticLine(self), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 12)
        self._result_panel = wx.Panel(self)
        result_sizer = wx.BoxSizer(wx.VERTICAL)

        self._result_part = wx.StaticText(self._result_panel, label="")
        font = self._result_part.GetFont()
        font.SetWeight(wx.FONTWEIGHT_BOLD)
        self._result_part.SetFont(font)
        result_sizer.Add(self._result_part, 0, wx.ALL, 8)

        self._result_detail = wx.StaticText(self._result_panel, label="")
        result_sizer.Add(self._result_detail, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        self._result_justification = wx.StaticText(self._result_panel, label="")
        self._result_justification.SetForegroundColour(wx.Colour(120, 120, 120))
        self._result_justification.Wrap(420)
        result_sizer.Add(self._result_justification, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        self._result_panel.SetSizer(result_sizer)
        self._result_panel.Hide()
        outer.Add(self._result_panel, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 12)

        # Bottom buttons
        btn_row = wx.BoxSizer(wx.HORIZONTAL)
        self._btn_apply = wx.Button(self, label="Apply to component")
        self._btn_apply.Bind(wx.EVT_BUTTON, self._on_apply)
        self._btn_apply.Disable()
        btn_row.Add(self._btn_apply, 0, wx.RIGHT, 8)
        btn_row.Add(wx.Button(self, wx.ID_CANCEL, label="Close"), 0)
        outer.Add(btn_row, 0, wx.ALL, 12)

        self.SetSizer(outer)

    def _on_search(self, _event) -> None:
        description = self._desc.GetValue().strip()
        if not description:
            self._set_status("Enter a description first.", error=True)
            return

        footprint = self._footprint.GetValue().strip()
        max_price_str = self._max_price.GetValue().strip()
        min_qty_str = self._min_qty.GetValue().strip()

        max_price = None
        min_qty = None
        try:
            if max_price_str:
                max_price = float(max_price_str)
        except ValueError:
            self._set_status("Max price must be a number.", error=True)
            return
        try:
            if min_qty_str:
                min_qty = int(min_qty_str)
        except ValueError:
            self._set_status("Min stock must be a whole number.", error=True)
            return

        supplier_idx = self._supplier.GetSelection()
        url = JLCPCB_SEARCH_URL if supplier_idx == 0 else DIGIKEY_SEARCH_URL

        payload = {"description": description, "footprint": footprint}
        if max_price is not None:
            payload["max_price"] = max_price
        if min_qty is not None:
            payload["min_qty"] = min_qty

        try:
            body = json.dumps(payload).encode()
            headers = {"Content-Type": "application/json"}
            if self.auth:
                headers.update(self.auth.auth_headers())
            req = Request(url, data=body, headers=headers, method="POST")
            with urlopen(req, timeout=10) as resp:
                self._job_id = json.loads(resp.read().decode())["job_id"]
        except HTTPError as e:
            self._set_status(f"Search failed: {e}", error=True)
            return
        except Exception as exc:
            self._set_status(f"Could not reach backend: {exc}", error=True)
            return

        self._btn_search.Disable()
        self._result_panel.Hide()
        self._btn_apply.Disable()
        self._set_status("Searching...")
        self._poll_gen += 1
        wx.CallLater(1500, self._poll, self._poll_gen)

    def _poll(self, gen: int) -> None:
        if gen != self._poll_gen:
            return
        status_url = f"{BACKEND_URL}/jobs/{self._job_id}"
        try:
            headers = {}
            if self.auth:
                headers.update(self.auth.auth_headers())
            req = Request(status_url, headers=headers)
            with urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read().decode())
        except Exception as exc:
            self._set_status(f"Could not reach backend: {exc}", error=True)
            self._btn_search.Enable()
            return

        status = data.get("status", "")
        if status == "complete":
            self._btn_search.Enable()
            result = data.get("result", {})
            if not result.get("part_number"):
                self._set_status("No match found. Try refining your description or constraints.", error=True)
                return
            self.result = result
            self._show_result(result)
        elif status in ("queued", "in_progress", "deferred"):
            wx.CallLater(1500, self._poll, gen)
        elif status == "failed":
            self._set_status("Search failed on the server. If this keeps happening, report a bug at usetraces.com.", error=True)
            self._btn_search.Enable()
        else:
            self._set_status(f"Unexpected status: {status}. Please report a bug at usetraces.com.", error=True)
            self._btn_search.Enable()

    def _show_result(self, result: dict) -> None:
        supplier_idx = self._supplier.GetSelection()
        supplier_label = "LCSC" if supplier_idx == 0 else "DigiKey"
        part = result.get("part_number", "")
        qty = result.get("qty", 0)
        price = result.get("price")
        justification = result.get("justification", "")

        self._result_part.SetLabel(f"{supplier_label}: {part}")
        detail = f"Stock: {qty:,}"
        if price is not None:
            detail += f"  ·  ${price:.4f}/unit" if price < 0.01 else f"  ·  ${price:.2f}/unit"
        self._result_detail.SetLabel(detail)
        self._result_justification.SetLabel(justification)
        self._result_justification.Wrap(420)

        self._result_panel.Show()
        self._btn_apply.Enable()
        self._set_status("")
        self.Layout()
        self.Fit()

    def _on_apply(self, _event) -> None:
        self.EndModal(wx.ID_OK)

    def _set_status(self, msg: str, error: bool = False) -> None:
        self._status.SetLabel(msg)
        self._status.SetForegroundColour(wx.RED if error else wx.NullColour)
        self.Layout()


class PropEditorDialog(wx.Dialog):
    """
    Main dialog. Component work queue for reconcile and supplier calls.
    """

    def __init__(self, sch: KiCadSchematic, sch_path: str, board=None, auth: AuthManager = None):
        super().__init__(
            None,
            title="traces",
            size=(1280, 660),
            style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER,
        )
        self.sch = sch
        self.sch_path = sch_path
        self.board = board
        self.auth = auth
        self.dirty = False
        self.component_rows = []
        self.sort_column = 0
        self.sort_reverse = False
        self.search_query = ""
        self.filter_mode = "All components"
        self.grouped_view = True
        self.workflow_step = "Source"
        self.row_call_status = {}
        self.src_logs = []

        self._build_ui()
        self._update_step_actions()
        self._populate_components()
        self.CentreOnScreen()
        wx.CallAfter(self._refresh_plan)

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self):
        # ---- top reconcile / SRC status strip --------------------------
        status_strip = wx.BoxSizer(wx.HORIZONTAL)

        title_block = wx.BoxSizer(wx.VERTICAL)
        title = wx.StaticText(self, label="Reconcile")
        title_font = title.GetFont()
        title_font.SetWeight(wx.FONTWEIGHT_BOLD)
        title.SetFont(title_font)
        title_block.Add(title, 0)
        title_block.Add(wx.StaticText(self, label=f"{Path(self.sch_path).name}"), 0, wx.TOP, 2)
        status_strip.Add(title_block, 1, wx.ALIGN_CENTER_VERTICAL | wx.LEFT | wx.RIGHT, 12)

        self.footprint_status = wx.StaticText(self, label="")
        self.supplier_status = wx.StaticText(self, label="")
        self.part_status = wx.StaticText(self, label="")
        for label in (self.footprint_status, self.supplier_status, self.part_status):
            status_strip.Add(label, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT | wx.RIGHT, 18)

        # ---- sidebar workflow -----------------------------------------
        sidebar = wx.BoxSizer(wx.VERTICAL)
        self.step_tabs = wx.RadioBox(
            self,
            label="Step",
            choices=["Footprints", "Supplier", "Source", "Datasheets", "SRC"],
            majorDimension=1,
            style=wx.RA_SPECIFY_ROWS,
        )
        self.step_tabs.SetSelection(2)
        self.step_tabs.Bind(wx.EVT_RADIOBOX, self._on_step_changed)
        sidebar.Add(self.step_tabs, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, 8)

        self.step_summary = wx.StaticText(self, label="")
        sidebar.Add(self.step_summary, 0, wx.EXPAND | wx.ALL, 8)

        self.btn_run_selected = wx.Button(self, label="Run selected")
        self.btn_run_all = wx.Button(self, label="Run all")
        self.btn_clear_sourcing = wx.Button(self, label="Clear sourcing")
        self.btn_search_part = wx.Button(self, label="Search for part...")
        self.btn_run_selected.Bind(wx.EVT_BUTTON, self._on_run_selected)
        self.btn_run_all.Bind(wx.EVT_BUTTON, self._on_run_all)
        self.btn_clear_sourcing.Bind(wx.EVT_BUTTON, self._on_clear_sourcing)
        self.btn_search_part.Bind(wx.EVT_BUTTON, self._on_search_part)
        sidebar.Add(self.btn_run_selected, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)
        sidebar.Add(self.btn_run_all, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)
        sidebar.Add(self.btn_clear_sourcing, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)
        sidebar.Add(self.btn_search_part, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        self.src_button_panel = wx.Panel(self)
        src_buttons = wx.BoxSizer(wx.VERTICAL)
        self.src_buttons = []
        for label in ("Typos", "Consistency", "Orphans", "Near dups"):
            button = wx.Button(self.src_button_panel, label=label)
            button.Bind(wx.EVT_BUTTON, lambda event, category=label: self._on_src_category(event, category))
            src_buttons.Add(button, 0, wx.EXPAND | wx.BOTTOM, 6)
            self.src_buttons.append(button)
        self.src_button_panel.SetSizer(src_buttons)
        sidebar.Add(self.src_button_panel, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        sidebar.Add(wx.StaticLine(self), 0, wx.EXPAND | wx.ALL, 8)

        self.src_log_view = wx.ScrolledWindow(self, style=wx.VSCROLL | wx.BORDER_SIMPLE)
        self.src_log_view.SetScrollRate(0, 12)
        self.src_log_sizer = wx.BoxSizer(wx.VERTICAL)
        self.src_log_view.SetSizer(self.src_log_sizer)
        sidebar.Add(self.src_log_view, 1, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 8)

        component_header = wx.BoxSizer(wx.HORIZONTAL)
        self.search_field = wx.TextCtrl(self, size=(240, -1), style=wx.TE_PROCESS_ENTER)
        self.search_field.SetHint("Search components")
        self.search_field.Bind(wx.EVT_TEXT, self._on_search_changed)
        component_header.Add(self.search_field, 1, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)

        self.filter_choice = wx.Choice(
            self,
            choices=[
                "All components",
                "Issues only",
                "Needs footprint",
                "Missing supplier",
                "Needs sourcing",
                "Ready",
            ],
        )
        self.filter_choice.SetSelection(0)
        self.filter_choice.Bind(wx.EVT_CHOICE, self._on_filter_changed)
        component_header.Add(self.filter_choice, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)

        self.view_mode = wx.RadioBox(
            self,
            choices=["Flat", "Grouped"],
            majorDimension=2,
            style=wx.RA_SPECIFY_COLS,
        )
        self.view_mode.SetSelection(1)
        self.view_mode.Bind(wx.EVT_RADIOBOX, self._on_view_mode_changed)
        component_header.Add(self.view_mode, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 8)

        self.btn_next_issue = wx.Button(self, label="Next issue")
        self.btn_next_issue.Bind(wx.EVT_BUTTON, self._on_next_issue)
        component_header.Add(self.btn_next_issue, 0, wx.ALIGN_CENTER_VERTICAL)

        work_queue = wx.BoxSizer(wx.VERTICAL)
        work_queue.Add(component_header, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, 6)

        self.component_grid = wx.ListCtrl(
            self,
            style=wx.LC_REPORT | wx.BORDER_SUNKEN,
        )
        self.component_grid.InsertColumn(0, "Status", width=80)
        self.component_grid.InsertColumn(1, "Component", width=80)
        self.component_grid.InsertColumn(2, "Refs", width=80)
        self.component_grid.InsertColumn(3, "Detail", width=80)
        self.component_grid.InsertColumn(4, "Call", width=80)
        self.component_grid.Bind(wx.EVT_LIST_ITEM_SELECTED, self._on_ref_select)
        self.component_grid.Bind(wx.EVT_LIST_COL_CLICK, self._on_component_column_click)
        work_queue.Add(self.component_grid, 1, wx.EXPAND | wx.ALL, 4)

        # ---- bottom bar: Account (left) / status / Close (right) ------
        bottom = wx.BoxSizer(wx.HORIZONTAL)
        self._acct_widget = _AccountWidget(self, self.auth, self._on_account_menu)
        bottom.Add(self._acct_widget, 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 8)
        self.status_text = wx.StaticText(self, label="")
        bottom.Add(self.status_text, 1, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 16)
        btn_close = wx.Button(self, wx.ID_CANCEL, "Close")
        bottom.Add(btn_close, 0, wx.RIGHT, 8)

        # ---- outer layout ---------------------------------------------
        content = wx.BoxSizer(wx.HORIZONTAL)
        content.Add(work_queue, 1, wx.EXPAND | wx.ALL, 4)
        content.Add(sidebar, 0, wx.EXPAND | wx.ALL, 4)

        root = wx.BoxSizer(wx.VERTICAL)
        root.Add(status_strip, 0, wx.EXPAND | wx.TOP | wx.BOTTOM, 8)
        root.Add(wx.StaticLine(self), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)
        root.Add(content, 1, wx.EXPAND)
        root.Add(wx.StaticLine(self), 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 8)
        root.Add(bottom, 0, wx.EXPAND | wx.TOP | wx.BOTTOM, 6)
        self.SetSizer(root)
        self._update_reconcile_status()

    # ------------------------------------------------------------------
    # Populate / refresh helpers
    # ------------------------------------------------------------------

    def _component_record(self, ref):
        props = self.sch.get_properties(ref)
        return {
            "refs": [ref],
            "reference": ref,
            "value": props.get("Value", ""),
            "supplier": _first_property(props, ("Supplier",)),
            "footprint": props.get("Footprint", ""),
            "lcsc": _first_property(props, JLCPCB_FIELD_NAMES),
            "digikey": _first_property(props, DIGIKEY_FIELD_NAMES),
            "qty": props.get(QUANTITY_FIELD, ""),
            "price": props.get(PRICE_FIELD, ""),
            "timestamp": props.get(TIMESTAMP_FIELD, ""),
            "datasheet": _first_property(props, DATASHEET_FIELD_NAMES),
        }

    def _format_refs(self, refs):
        if len(refs) <= 3:
            return ", ".join(refs)
        return f"{', '.join(refs[:3])} +{len(refs) - 3}"

    def _same_or_mixed(self, values):
        real_values = [value for value in values if value]
        if not real_values:
            return ""
        first = real_values[0]
        if all(value == first for value in real_values):
            return first
        return "Mixed"

    def _part_number_for_row(self, row):
        supplier = row["supplier"].strip().upper()
        if supplier in NA_SUPPLIERS:
            return "N/A"
        if supplier == "LCSC":
            return row["lcsc"]
        if supplier in {"DIGIKEY", "DIGI-KEY"}:
            return row["digikey"]
        return row["lcsc"] or row["digikey"]

    def _row_issues(self, row):
        issues = []
        footprint = row["footprint"].strip()
        if not footprint:
            issues.append("missing footprint")
        if footprint == "Mixed":
            issues.append("mixed footprints")
        supplier = row["supplier"].strip()
        if not supplier:
            issues.append("missing supplier")
        if supplier == "Mixed":
            issues.append("mixed suppliers")
        if supplier.upper() in NA_SUPPLIERS:
            return issues
        part_number = self._part_number_for_row(row)
        if not part_number:
            issues.append("missing part number")
        if part_number == "Mixed":
            issues.append("mixed part numbers")
        datasheet = row.get("datasheet", "")
        if not datasheet:
            issues.append("missing datasheet")
        if datasheet == "Mixed":
            issues.append("mixed datasheets")
        return issues

    def _row_status(self, row):
        issues = self._row_issues(row)
        if not issues:
            return "Ready"
        if any(issue in issues for issue in ("missing footprint", "missing supplier", "missing part number", "mixed footprints", "mixed suppliers", "mixed part numbers")):
            return "Blocked"
        return "Review"

    def _datasheet_state(self, row):
        if row["supplier"].strip().upper() in NA_SUPPLIERS:
            return "N/A"
        datasheet = row.get("datasheet", "")
        if datasheet == "Mixed":
            return "Mixed"
        return "Ready" if datasheet else "Missing"

    def _row_missing_label(self, row):
        issues = self._row_issues(row)
        if not issues:
            return "None"
        return ", ".join(issue.replace("missing ", "").replace("mixed ", "mixed ") for issue in issues)

    def _populate_missing_fields(self, row):
        missing = []
        part_number = self._part_number_for_row(row)
        if not part_number:
            missing.append("part number")
        if part_number == "Mixed":
            missing.append("mixed part numbers")
        if not row.get("qty", ""):
            missing.append("quantity")
        if not row.get("price", ""):
            missing.append("price")
        if not row.get("timestamp", ""):
            missing.append("timestamp")
        return missing

    def _src_issue(self, severity, category, location, message):
        return {
            "severity": severity,
            "category": category,
            "location": location,
            "message": message,
        }

    def _src_checks(self, refs=None):
        refs = set(refs or [])
        issues = []
        records = [
            record for record in self._ungrouped_component_records()
            if not refs or record["reference"] in refs
        ]
        canonical_keys = {
            "Reference", "Value", "Footprint", "Supplier", "LCSC",
            "Digikey Part Number", QUANTITY_FIELD, PRICE_FIELD,
            TIMESTAMP_FIELD, DATASHEET_URL_FIELD, DATASHEET_LOCAL_FIELD,
        }
        alias_to_canonical = {
            "digikey part number": "Digikey Part Number",
            "digi-key part number": "Digikey Part Number",
            "digikey": "Digikey Part Number",
            "digi-key": "Digikey Part Number",
            "lcsc part": "LCSC",
            "jlcpcb part": "LCSC",
            "supplier part": "LCSC",
            "datasheet url": DATASHEET_URL_FIELD,
            "quantity": QUANTITY_FIELD,
            "qty": QUANTITY_FIELD,
        }

        for record in records:
            props = self.sch.get_properties(record["reference"])
            for key in props:
                stripped = key.strip()
                lowered = stripped.lower()
                if key != stripped:
                    issues.append(self._src_issue("warning", "Typos", record["reference"], f"Property key has leading/trailing whitespace: '{key}'."))
                canonical = alias_to_canonical.get(lowered)
                if canonical and key != canonical:
                    issues.append(self._src_issue("warning", "Typos", record["reference"], f"Property '{key}' should be '{canonical}' for consistency."))
                elif not canonical and key not in canonical_keys:
                    for expected in canonical_keys:
                        if SequenceMatcher(None, lowered, expected.lower()).ratio() >= 0.86:
                            issues.append(self._src_issue("warning", "Typos", record["reference"], f"Property '{key}' looks like '{expected}'."))
                            break

            supplier = record["supplier"].strip()
            if supplier and supplier.upper() not in {"LCSC", "DIGIKEY", "DIGI-KEY"} | NA_SUPPLIERS:
                issues.append(self._src_issue("error", "Consistency", record["reference"], f"Unknown supplier '{supplier}'. Use LCSC, Digi-Key, or N/A."))

        for row in self._build_component_rows():
            if refs and not any(ref in refs for ref in row["refs"]):
                continue
            mixed_fields = [
                label for label, key in (
                    ("supplier", "supplier"),
                    ("LCSC", "lcsc"),
                    ("Digi-Key part", "digikey"),
                    ("quantity", "qty"),
                    ("price", "price"),
                    ("datasheet", "datasheet"),
                )
                if row.get(key) == "Mixed"
            ]
            if mixed_fields:
                issues.append(self._src_issue("warning", "Consistency", row["reference"], f"Grouped parts disagree on {', '.join(mixed_fields)}."))

        board_refs = set(self._board_footprint_map())
        schematic_refs = set(self.sch.get_references()) - {ref for ref in self.sch.get_references() if ref.startswith("#")}
        if board_refs:
            for ref in sorted(board_refs - schematic_refs):
                if not refs or ref in refs:
                    issues.append(self._src_issue("error", "Orphans", ref, "PCB footprint reference has no schematic symbol."))
            for ref in sorted(schematic_refs - board_refs):
                if not refs or ref in refs:
                    issues.append(self._src_issue("warning", "Orphans", ref, "Schematic symbol has no matching PCB footprint reference."))

        near_dups = self._near_duplicate_src_issues(records)
        issues.extend(near_dups)
        return issues

    def _near_duplicate_src_issues(self, records):
        issues = []
        fields = [
            ("Value", "value"),
            ("Footprint", "footprint"),
            ("LCSC", "lcsc"),
            ("Digi-Key part", "digikey"),
        ]
        for label, key in fields:
            values = {}
            for record in records:
                value = record.get(key, "").strip()
                norm = re.sub(r"[^a-z0-9]+", "", value.lower())
                if len(norm) < 4:
                    continue
                values.setdefault(norm, {"value": value, "refs": []})["refs"].extend(record["refs"])
            norms = list(values)
            found = 0
            for i, left in enumerate(norms):
                for right in norms[i + 1:]:
                    if left == right:
                        continue
                    ratio = SequenceMatcher(None, left, right).ratio()
                    if ratio < 0.88:
                        continue
                    left_value = values[left]["value"]
                    right_value = values[right]["value"]
                    if left_value == right_value:
                        continue
                    location = f"{self._format_refs(values[left]['refs'])} / {self._format_refs(values[right]['refs'])}"
                    issues.append(self._src_issue("warning", "Near dups", location, f"{label} values are very similar: '{left_value}' vs '{right_value}'."))
                    found += 1
                    if found >= 8:
                        break
                if found >= 8:
                    break
        return issues

    def _row_key(self, row):
        return "|".join(row["refs"])

    def _row_call_label(self, row):
        return self.row_call_status.get(self._row_key(row), "Idle")

    def _set_row_call_status(self, row, label):
        if row:
            self.row_call_status[self._row_key(row)] = label

    def _mark_row_call(self, row, label):
        self._set_row_call_status(row, label)
        selected = row["refs"][0] if row and row["refs"] else self._current_ref()
        self._populate_components(selected)
        wx.YieldIfNeeded()

    def _row_for_ref(self, ref):
        for row in self._build_component_rows():
            if ref in row["refs"]:
                return row
        return None

    def _component_label(self, row):
        value = row["value"] or "(no value)"
        footprint = row["footprint"] or "(no footprint)"
        return f"{value}  {footprint}"

    def _build_component_rows(self):
        records = self._ungrouped_component_records()

        if not self.grouped_view:
            return records

        groups = {}
        for record in records:
            key = (record["value"], record["footprint"])
            groups.setdefault(key, []).append(record)

        rows = []
        for (value, footprint), group in groups.items():
            refs = []
            for record in group:
                refs.extend(record["refs"])
            rows.append(
                {
                    "refs": refs,
                    "reference": self._format_refs(refs),
                    "value": value,
                    "supplier": self._same_or_mixed([record["supplier"] for record in group]),
                    "footprint": footprint,
                    "lcsc": self._same_or_mixed([record["lcsc"] for record in group]),
                    "digikey": self._same_or_mixed([record["digikey"] for record in group]),
                    "qty": self._same_or_mixed([record["qty"] for record in group]),
                    "price": self._same_or_mixed([record["price"] for record in group]),
                    "timestamp": max((record["timestamp"] for record in group if record["timestamp"]), default=""),
                    "datasheet": self._same_or_mixed([record["datasheet"] for record in group]),
                }
            )
        return rows

    def _row_values(self, row):
        step = self.workflow_step
        issues = self._row_issues(row)
        status = self._step_status(row)
        if step == "Footprints":
            detail = row["footprint"] or "No schematic footprint"
        elif step == "Supplier":
            detail = row["supplier"] or "No supplier selected"
        elif step == "Source":
            if row["supplier"].strip().upper() in NA_SUPPLIERS:
                detail = "Not sourced"
            else:
                part_number = self._part_number_for_row(row)
                missing = self._populate_missing_fields(row)
                if missing:
                    detail = ", ".join(missing)
                else:
                    detail = part_number or "Ready"
        else:
            if step == "Datasheets":
                detail = row.get("datasheet", "") or "No datasheet"
            else:
                issues = self._src_checks(row["refs"])
                detail = f"{len(issues)} SRC issue(s)" if issues else "No SRC issues"
        return [
            status,
            self._component_label(row),
            row["reference"],
            detail,
            self._row_call_label(row),
        ]

    def _step_status(self, row):
        issues = self._row_issues(row)
        if self.workflow_step == "Footprints":
            if any(issue in issues for issue in ("missing footprint", "mixed footprints")):
                return "Needs"
            return "Done"
        if self.workflow_step == "Supplier":
            if any(issue in issues for issue in ("missing footprint", "mixed footprints")):
                return "Blocked"
            if any(issue in issues for issue in ("missing supplier", "mixed suppliers")):
                return "Needs"
            return "Done"
        if self.workflow_step == "Source":
            if any(issue in issues for issue in ("missing footprint", "mixed footprints", "missing supplier", "mixed suppliers")):
                return "Blocked"
            if row["supplier"].strip().upper() in NA_SUPPLIERS:
                return "N/A"
            if self._populate_missing_fields(row):
                return "Needs"
            return "Done"
        if self.workflow_step == "SRC":
            src_issues = self._src_checks(row["refs"])
            if any(issue["severity"] == "error" for issue in src_issues):
                return "Blocked"
            if src_issues:
                return "Needs"
            return "Done"
        if row["supplier"].strip().upper() in NA_SUPPLIERS:
            return "N/A"
        if any(issue in issues for issue in ("missing part number", "mixed part numbers")):
            return "Blocked"
        if any(issue in issues for issue in ("missing datasheet", "mixed datasheets")):
            return "Needs"
        return "Done"

    def _row_matches_search(self, row, query):
        if not query:
            return True
        haystack = " ".join(str(value) for value in [
            row["reference"],
            row["value"],
            row["supplier"],
            row["footprint"],
            row["lcsc"],
            row["digikey"],
            row["qty"],
            row["price"],
            row["timestamp"],
            row["datasheet"],
        ]).lower()
        return query.lower() in haystack

    def _row_matches_filter(self, row):
        mode = self.filter_mode
        issues = self._row_issues(row)
        if mode == "All components":
            return True
        if mode == "Issues only":
            return bool(issues)
        if mode == "Needs footprint":
            return any(issue in issues for issue in ("missing footprint", "mixed footprints"))
        if mode == "Missing supplier":
            return any(issue in issues for issue in ("missing supplier", "mixed suppliers"))
        if mode == "Needs sourcing":
            return bool(self._populate_missing_fields(row))
        if mode == "Ready":
            return not issues
        return True

    def _ungrouped_component_records(self):
        records = []
        for ref in self.sch.get_references():
            if ref.startswith("#"):
                continue
            records.append(self._component_record(ref))
        return records

    def _part_number_for_record(self, record):
        supplier = record["supplier"].strip().upper()
        if supplier in NA_SUPPLIERS:
            return "N/A"
        if supplier == "LCSC":
            return record["lcsc"]
        if supplier in {"DIGIKEY", "DIGI-KEY"}:
            return record["digikey"]
        return record["lcsc"] or record["digikey"]

    def _update_reconcile_status(self):
        records = self._ungrouped_component_records()
        total = len(records)
        footprints = sum(1 for record in records if record["footprint"])
        suppliers = sum(1 for record in records if record["supplier"])
        part_numbers = sum(1 for record in records if self._part_number_for_record(record))
        self.footprint_status.SetLabel(f"Footprints {footprints}/{total}")
        self.supplier_status.SetLabel(f"Suppliers {suppliers}/{total}")
        self.part_status.SetLabel(f"Sourced {part_numbers}/{total}")
        if hasattr(self, "btn_next_issue"):
            issue_count = sum(1 for row in self.component_rows if self._row_issues(row))
            self.btn_next_issue.SetLabel(f"Next issue ({issue_count})")

    def _update_step_summary(self):
        if not hasattr(self, "step_summary"):
            return
        rows = self._build_component_rows()
        total = len(rows)
        done = sum(1 for row in rows if self._step_status(row) in {"Done", "N/A"})
        needs = sum(1 for row in rows if self._step_status(row) == "Needs")
        blocked = sum(1 for row in rows if self._step_status(row) == "Blocked")
        self.step_summary.SetLabel(
            f"{self.workflow_step}\n"
            f"Done {done}/{total}\n"
            f"Needs {needs}\n"
            f"Blocked {blocked}"
        )
        if hasattr(self, "src_log_view"):
            self._render_src_logs()

    def _set_src_logs(self, issues):
        self.src_logs = issues
        self._render_src_logs()

    def _render_src_logs(self):
        if not hasattr(self, "src_log_sizer"):
            return
        self.src_log_sizer.Clear(delete_windows=True)
        if self.workflow_step != "SRC":
            hint = wx.StaticText(self.src_log_view, label="SRC output appears here when the SRC step runs.")
            hint.SetForegroundColour(wx.Colour(150, 150, 150))
            self.src_log_sizer.Add(hint, 0, wx.EXPAND | wx.ALL, 8)
        elif not self.src_logs:
            ok = wx.StaticText(self.src_log_view, label="No SRC output yet. Pick one check above.")
            ok.SetForegroundColour(wx.Colour(150, 150, 150))
            self.src_log_sizer.Add(ok, 0, wx.EXPAND | wx.ALL, 8)
        else:
            for issue in self.src_logs[:40]:
                panel = wx.Panel(self.src_log_view)
                severity = issue.get("severity", "warning")
                if severity == "error":
                    panel.SetBackgroundColour(wx.Colour(58, 34, 34))
                    fg = wx.Colour(235, 120, 120)
                elif severity == "info":
                    panel.SetBackgroundColour(wx.Colour(34, 44, 58))
                    fg = wx.Colour(120, 175, 235)
                else:
                    panel.SetBackgroundColour(wx.Colour(58, 49, 32))
                    fg = wx.Colour(230, 185, 90)
                box = wx.BoxSizer(wx.VERTICAL)
                heading = wx.StaticText(panel, label=f"{issue.get('category', 'SRC')} - {issue.get('location', '')}")
                heading.SetForegroundColour(fg)
                body = wx.StaticText(panel, label=issue.get("message", ""))
                body.Wrap(210)
                body.SetForegroundColour(wx.Colour(220, 220, 220))
                box.Add(heading, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.TOP, 6)
                box.Add(body, 0, wx.EXPAND | wx.ALL, 6)
                panel.SetSizer(box)
                self.src_log_sizer.Add(panel, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 6)
        self.src_log_view.FitInside()
        self.src_log_view.Layout()

    def _populate_components(self, selected_ref=None):
        self.component_grid.DeleteAllItems()
        self.component_rows = [
            row for row in self._build_component_rows()
            if self._row_matches_search(row, self.search_query) and self._row_matches_filter(row)
        ]
        self.component_rows.sort(
            key=lambda row: (str(self._row_values(row)[self.sort_column]).lower(), row["reference"]),
            reverse=self.sort_reverse,
        )
        for row in self.component_rows:
            row_index = self.component_grid.InsertItem(self.component_grid.GetItemCount(), self._row_values(row)[0])
            for column, value in enumerate(self._row_values(row)[1:], start=1):
                self.component_grid.SetItem(row_index, column, value)
            self.component_grid.SetItemData(row_index, row_index)
            self._style_component_row(row_index, row)
            if selected_ref and selected_ref in row["refs"]:
                self.component_grid.Select(row_index)
                self.component_grid.Focus(row_index)
        self._update_reconcile_status()
        self._update_step_summary()
        self._autosize_columns()

    _COL_MAX_WIDTHS = (120, 280, 160, 320, 220)

    def _autosize_columns(self):
        g = self.component_grid
        for col, max_w in enumerate(self._COL_MAX_WIDTHS):
            g.SetColumnWidth(col, wx.LIST_AUTOSIZE_USEHEADER)
            header_w = g.GetColumnWidth(col)
            if g.GetItemCount():
                g.SetColumnWidth(col, wx.LIST_AUTOSIZE)
                content_w = g.GetColumnWidth(col)
            else:
                content_w = 0
            g.SetColumnWidth(col, min(max(header_w, content_w), max_w))

    def _style_component_row(self, row_index, row):
        status = self._step_status(row)
        if status in {"Done", "N/A"}:
            colour = wx.Colour(34, 48, 38)
        elif status == "Needs":
            colour = wx.Colour(58, 49, 32)
        else:
            colour = wx.Colour(58, 34, 34)
        self.component_grid.SetItemBackgroundColour(row_index, colour)

    def _reset_prop_grid(self):
        return

    def _append_prop_row(self, key, value, refs, editable=True):
        return

    def _refresh_current_selection(self, selected_ref=None):
        return

    def _load_group_props(self, row):
        return

    def _on_group_toggle(self, event):
        current_refs = self._current_refs()
        selected_ref = current_refs[0] if current_refs else None
        self._populate_components(selected_ref)

    def _on_search_changed(self, event):
        self.search_query = self.search_field.GetValue().strip()
        selected_refs = self._current_refs()
        self._populate_components(selected_refs[0] if selected_refs else None)

    def _on_filter_changed(self, event):
        self.filter_mode = self.filter_choice.GetStringSelection()
        selected_refs = self._current_refs()
        self._populate_components(selected_refs[0] if selected_refs else None)

    def _on_view_mode_changed(self, event):
        self.grouped_view = self.view_mode.GetStringSelection() == "Grouped"
        self._on_group_toggle(event)

    def _on_step_changed(self, event):
        self.workflow_step = self.step_tabs.GetStringSelection()
        self._update_step_actions()
        selected_refs = self._current_refs()
        self._populate_components(selected_refs[0] if selected_refs else None)

    def _update_step_actions(self):
        if self.workflow_step == "SRC":
            self.btn_run_selected.Hide()
            self.btn_run_all.Hide()
            self.btn_clear_sourcing.Hide()
            self.src_button_panel.Show()
        else:
            labels = {
                "Footprints": ("Edit value/footprint", "Reconcile from PCB"),
                "Supplier":   ("Set supplier",   "Set all suppliers"),
                "Source":     ("Source selected",   "Source all"),
                "Datasheets": ("Fetch datasheet", "Fetch all datasheets"),
            }
            sel_label, all_label = labels.get(self.workflow_step, ("Run selected", "Run all"))
            self.btn_run_selected.SetLabel(sel_label)
            self.btn_run_all.SetLabel(all_label)
            self.btn_run_selected.Show()
            self.btn_run_all.Show()
            self.btn_clear_sourcing.Show() if self.workflow_step == "Source" else self.btn_clear_sourcing.Hide()
            self.src_button_panel.Hide()
        self.Layout()

    def _on_run_selected(self, event):
        rows = self._current_rows()
        if not rows:
            return self._set_status("Select a row first.", wx.RED)
        for row in rows:
            self._run_step(row, event)

    def _on_run_all(self, event):
        return self._run_step(None, event)

    def _run_step(self, row=None, event=None):
        if self.workflow_step == "Footprints":
            return self._run_footprints(row)
        if self.workflow_step == "Supplier":
            return self._run_supplier(row)
        if self.workflow_step == "Source":
            return self._run_populate(row, event)
        return self._run_datasheets(row, event)

    def _run_src(self, category):
        for button in self.src_buttons:
            button.Disable()
        try:
            self._set_src_logs([
                self._src_issue("info", category, "Exporting", "Exporting schematic netlist XML...")
            ])
            self._set_status(f"Exporting netlist for SRC {category}...")
            wx.YieldIfNeeded()
            xml = self._export_kicad_xml_netlist()

            self._set_src_logs([
                self._src_issue("info", category, "Submitted", "Submitted to backend; waiting for result...")
            ])
            self._set_status(f"Running backend SRC {category}...")
            wx.YieldIfNeeded()
            job_id = self._submit_src_job(category, xml)
            result = self._poll_job(job_id, f"SRC {category}")
        except HTTPError as e:
            if self._handle_http_error(e):
                return
            self._set_src_logs([self._src_issue("error", category, "Backend", f"SRC {category} failed: {e}")])
            return self._set_status(f"SRC {category} failed: {e}", wx.RED)
        except (URLError, TimeoutError, RuntimeError, KeyError, json.JSONDecodeError, subprocess.SubprocessError) as e:
            self._set_src_logs([
                self._src_issue("error", category, "Backend", f"SRC {category} failed: {e}")
            ])
            return self._set_status(f"SRC {category} failed: {e}", wx.RED)
        finally:
            for button in self.src_buttons:
                button.Enable()

        issues = result.get("issues", [])
        normalized = []
        for issue in issues:
            normalized.append({
                "severity": issue.get("severity", "warning"),
                "category": category,
                "location": issue.get("location", ""),
                "message": issue.get("message", ""),
            })
        if not normalized:
            normalized.append(self._src_issue("info", category, "Complete", "No issues found."))
        self._set_src_logs(normalized)
        selected = self._current_ref()
        self._populate_components(selected)
        self._set_status(f"SRC {category}: {len(issues)} issue(s) found.")

    def _on_src_category(self, event, category):
        return self._run_src(category)

    def _on_next_issue(self, event):
        if not self.component_rows:
            return self._set_status("No components match the current view.", wx.RED)

        start = self.component_grid.GetFirstSelected()
        for offset in range(1, len(self.component_rows) + 1):
            index = ((start if start != -1 else -1) + offset) % len(self.component_rows)
            row = self.component_rows[index]
            if not self._row_issues(row):
                continue
            self.component_grid.Select(index)
            self.component_grid.Focus(index)
            self.component_grid.EnsureVisible(index)
            self._set_status(f"{row['reference']}: {', '.join(self._row_issues(row))}.")
            return
        self._set_status("No unresolved component metadata issues in this view.")

    def _on_component_column_click(self, event):
        column = event.GetColumn()
        if column == self.sort_column:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_column = column
            self.sort_reverse = False
        selected_refs = self._current_refs()
        self._populate_components(selected_refs[0] if selected_refs else None)

    def _load_props(self, reference):
        return

    def _current_ref(self):
        refs = self._current_refs()
        return refs[0] if refs else None

    def _current_rows(self):
        rows = []
        idx = self.component_grid.GetFirstSelected()
        while idx != -1:
            if idx < len(self.component_rows):
                rows.append(self.component_rows[idx])
            idx = self.component_grid.GetNextSelected(idx)
        return rows

    def _current_refs(self):
        refs = []
        for row in self._current_rows():
            refs.extend(row["refs"])
        return refs

    def _current_row(self):
        rows = self._current_rows()
        return rows[0] if rows else None

    def _set_status(self, msg, colour=None):
        self.status_text.SetLabel(msg)
        if colour:
            self.status_text.SetForegroundColour(colour)
        else:
            self.status_text.SetForegroundColour(wx.NullColour)

    def _show_backend_error(self, summary: str, detail: str = "") -> None:
        body = summary
        if detail:
            body += f"\n\nDetails:\n{detail}"
        body += "\n\nIf this keeps happening, please report a bug at usetraces.com."
        wx.MessageBox(body, "Backend Error", wx.OK | wx.ICON_ERROR, self)
        self._set_status(summary, wx.RED)

    def _autosave(self, success_message=None):
        try:
            self.sch.write(self.sch_path)
            self.dirty = False
            if success_message:
                self._set_status(success_message)
            return True
        except Exception as e:
            self.dirty = True
            self._set_status(f"Autosave failed: {e}", wx.RED)
            return False

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _on_ref_select(self, event):
        rows = self._current_rows()
        if not rows:
            return
        if len(rows) > 1:
            return self._set_status(f"{len(rows)} components selected.")
        row = rows[0]
        issues = self._row_issues(row)
        issue_text = ", ".join(issues) if issues else "ready"
        self._set_status(f"Selected {row['reference']}: {issue_text}.")

    def _on_property_cell_changed(self, event):
        row_index = event.GetRow()
        column = event.GetCol()
        if column != 1 or row_index < 0 or row_index >= len(self.prop_rows):
            return
        row_info = self.prop_rows[row_index]
        if not row_info["editable"]:
            return

        key = row_info["key"]
        value = self.prop_grid.GetCellValue(row_index, 1).strip()
        refs = row_info["refs"]
        try:
            for ref in refs:
                self.sch.set_property(ref, key, value)
            self.dirty = True
            if not self._autosave():
                return
            selected = refs[0] if refs else None
            self._populate_components(selected)
            self._refresh_current_selection(selected)
            self._set_status(f"Updated and saved {key} for {len(refs)} part(s).")
        except Exception as e:
            self._set_status(f"Update failed: {e}", wx.RED)

    def _pcb_footprint_id(self, footprint):
        try:
            fpid = footprint.GetFPID()
        except Exception:
            return ""
        for method_name in ("Format", "AsString"):
            method = getattr(fpid, method_name, None)
            if not method:
                continue
            try:
                value = method()
                if value:
                    return str(value)
            except TypeError:
                try:
                    value = method(True)
                    if value:
                        return str(value)
                except Exception:
                    pass
            except Exception:
                pass
        return str(fpid) if fpid else ""

    def _board_footprint_map(self):
        if not self.board:
            return {}
        try:
            footprints = list(self.board.GetFootprints())
        except Exception:
            return {}
        by_ref = {}
        for footprint in footprints:
            try:
                ref = footprint.GetReference()
            except Exception:
                continue
            fpid = self._pcb_footprint_id(footprint)
            if ref and fpid:
                by_ref[ref] = fpid
        return by_ref

    def _on_reconcile_footprints(self, event):
        return self._run_footprints(self._current_row())

    def _run_footprints(self, row=None):
        if row:
            return self._edit_footprint(row)
        return self._reconcile_footprints_from_pcb()

    def _edit_footprint(self, row):
        current_value = "" if row["value"] == "Mixed" else row["value"]
        current_fp = "" if row["footprint"] == "Mixed" else row["footprint"]

        dlg = wx.Dialog(self, title=f"Edit — {row['reference']}", size=(420, 180),
                        style=wx.DEFAULT_DIALOG_STYLE)
        sizer = wx.BoxSizer(wx.VERTICAL)
        grid = wx.FlexGridSizer(2, 2, 8, 8)
        grid.AddGrowableCol(1)
        grid.Add(wx.StaticText(dlg, label="Value:"), 0, wx.ALIGN_CENTER_VERTICAL)
        val_ctrl = wx.TextCtrl(dlg, value=current_value, size=(300, -1))
        grid.Add(val_ctrl, 1, wx.EXPAND)
        grid.Add(wx.StaticText(dlg, label="Footprint:"), 0, wx.ALIGN_CENTER_VERTICAL)
        fp_ctrl = wx.TextCtrl(dlg, value=current_fp, size=(300, -1))
        grid.Add(fp_ctrl, 1, wx.EXPAND)
        sizer.Add(grid, 0, wx.EXPAND | wx.ALL, 16)
        btn_sizer = dlg.CreateButtonSizer(wx.OK | wx.CANCEL)
        sizer.Add(btn_sizer, 0, wx.ALIGN_RIGHT | wx.RIGHT | wx.BOTTOM, 12)
        dlg.SetSizer(sizer)
        val_ctrl.SetFocus()

        try:
            if dlg.ShowModal() != wx.ID_OK:
                return
            new_value = val_ctrl.GetValue().strip()
            new_fp = fp_ctrl.GetValue().strip()
        finally:
            dlg.Destroy()

        for ref in row["refs"]:
            if new_value:
                self.sch.set_property(ref, "Value", new_value)
            self.sch.set_property(ref, "Footprint", new_fp)
        self.dirty = True
        if not self._autosave():
            return
        self._set_row_call_status(row, "Updated")
        self._populate_components(row["refs"][0])
        self._set_status(f"Updated Value/Footprint on {len(row['refs'])} part(s).")

    def _reconcile_footprints_from_pcb(self):
        updated, missing_on_board = self._reconcile_missing_footprints(None)
        if not updated and not missing_on_board and not self._board_footprint_map():
            return self._set_status("No PCB footprints found to reconcile from.", wx.RED)
        self._populate_components(self._current_ref())
        if updated:
            detail = f"; {len(missing_on_board)} not found on PCB" if missing_on_board else ""
            self._set_status(f"Reconciled {updated} missing footprint(s){detail}.")
        else:
            self._set_status("No missing schematic footprints to reconcile.")

    def _reconcile_missing_footprints(self, refs=None):
        board_footprints = self._board_footprint_map()
        if not board_footprints:
            return 0, []

        refs = set(refs or [])
        updated = 0
        missing_on_board = []
        for record in self._ungrouped_component_records():
            if refs and record["reference"] not in refs:
                continue
            if record["footprint"].strip():
                continue
            ref = record["reference"]
            row = self._row_for_ref(ref)
            footprint = board_footprints.get(ref, "")
            if not footprint:
                missing_on_board.append(ref)
                self._set_row_call_status(row, "No PCB footprint")
                continue
            self.sch.set_property(ref, "Footprint", footprint)
            self._set_row_call_status(row, "Footprint copied from PCB")
            updated += 1

        self.dirty = self.dirty or updated > 0
        if updated:
            self._autosave()
        return updated, missing_on_board

    def _on_reconcile_supplier(self, event):
        return self._run_supplier(self._current_row())

    def _run_supplier(self, row=None):
        selected_refs = row["refs"] if row else []
        if row:
            refs = selected_refs
        else:
            refs = [
                record["reference"]
                for record in self._ungrouped_component_records()
                if not record["supplier"].strip()
            ]
        if not refs:
            return self._set_status("No components need supplier reconciliation.")
        missing_footprints = [
            ref for ref in refs
            if not self.sch.get_property(ref, "Footprint")
        ]
        if missing_footprints:
            return self._set_status(
                f"Reconcile footprints first: {self._format_refs(missing_footprints)}.",
                wx.RED,
            )

        dialog = wx.SingleChoiceDialog(
            self,
            f"Set supplier for {len(refs)} part(s):",
            "Reconcile supplier",
            ["LCSC", "Digi-Key", "N/A"],
        )
        try:
            dialog.SetSelection(0)
            if dialog.ShowModal() != wx.ID_OK:
                return
            supplier = dialog.GetStringSelection()
        finally:
            dialog.Destroy()

        cleared = 0
        for ref in refs:
            old_supplier = self.sch.get_property(ref, "Supplier") or ""
            self.sch.set_property(ref, "Supplier", supplier)
            row_ref = self._row_for_ref(ref)
            if old_supplier.strip() and old_supplier.strip().upper() != supplier.strip().upper():
                if row_ref:
                    self._clear_sourcing_data(row_ref)
                cleared += 1
            self._set_row_call_status(self._row_for_ref(ref), f"Supplier set: {supplier}")
        self.dirty = True
        if not self._autosave():
            return
        selected = refs[0]
        self._populate_components(selected)
        detail = f" (sourcing cleared for {cleared})" if cleared else ""
        self._set_status(f"Set Supplier={supplier} for {len(refs)} part(s){detail}.")

    def _run_populate(self, row=None, event=None):
        if row:
            return self._populate_row(row, event)
        return self._try_populate_rows(None, event)

    def _run_datasheets(self, row=None, event=None):
        if row:
            return self._on_download_datasheet(event, row=row)
        rows = [
            row for row in self._build_component_rows()
            if self._step_status(row) == "Needs"
        ]
        attempted = 0
        for current in rows:
            self._on_download_datasheet(event, row=current)
            attempted += 1
        self._populate_components(self._current_ref())
        self._set_status(f"Datasheets: {attempted} attempt(s).")

    def _populate_row(self, row, event=None):
        if not row:
            return self._set_status("Select a component or group to source.", wx.RED)
        if not row["footprint"].strip() or row["footprint"] == "Mixed":
            self._mark_row_call(row, "Needs footprint")
            return self._set_status("Reconcile the footprint before populating.", wx.RED)
        supplier = row["supplier"].strip().upper()
        if not supplier or supplier == "MIXED":
            self._mark_row_call(row, "Needs supplier")
            return self._set_status("Reconcile the supplier before populating.", wx.RED)
        if supplier in NA_SUPPLIERS:
            self._mark_row_call(row, "Skipped: N/A")
            self._set_status(f"{row['reference']} marked Supplier=N/A; nothing to source.")
            return True
        if supplier == "LCSC":
            self._mark_row_call(row, "Looking up JLC")
            if row["lcsc"] and row["lcsc"] != "Mixed":
                return self._on_fetch_jlc(event, row=row)
            return self._on_find_jlc_from_value(event, row=row)
        if supplier in {"DIGIKEY", "DIGI-KEY"}:
            self._mark_row_call(row, "Looking up Digi-Key")
            return self._on_find_digikey_from_value(event, row=row)
        self._mark_row_call(row, "Unsupported supplier")
        return self._set_status(f"Unsupported supplier for populate: {row['supplier']}", wx.RED)

    def _on_populate_selected(self, event):
        return self._populate_row(self._current_row(), event)

    def _on_try_all(self, event):
        return self._try_populate_rows(self._current_row(), event)

    def _try_populate_rows(self, selected_row=None, event=None):
        target_refs = selected_row["refs"] if selected_row else None
        selected = target_refs[0] if target_refs else self._current_ref()
        self._populate_components(selected)

        pending_supplier = [
            record["reference"]
            for record in self._ungrouped_component_records()
            if (not target_refs or record["reference"] in target_refs)
            and record["footprint"].strip()
            and not record["supplier"].strip()
        ]
        if pending_supplier:
            if selected_row:
                self._set_row_call_status(selected_row, "Needs supplier")
                self._populate_components(selected)
            return self._set_status(
                f"Set suppliers before sourcing: {self._format_refs(pending_supplier)}.",
                wx.RED,
            )

        attempted = 0
        skipped = 0
        rows = [
            row for row in self._build_component_rows()
            if (not target_refs or any(ref in target_refs for ref in row["refs"]))
            and row["footprint"].strip()
            and row["footprint"] != "Mixed"
            and row["supplier"].strip()
            and row["supplier"] != "Mixed"
            and (
                self._populate_missing_fields(row)
                or row["supplier"].strip().upper() in NA_SUPPLIERS
            )
        ]
        for row in rows:
            supplier = row["supplier"].strip().upper()
            if supplier in NA_SUPPLIERS:
                skipped += 1
                continue
            self._populate_components(row["refs"][0])
            self._populate_row(row, event)
            attempted += 1

        self._populate_components(selected)
        scope = "selected" if target_refs else "all"
        self._set_status(
            f"Source {scope}: {attempted} attempt(s), {skipped} N/A skipped."
        )

    def _selected_supplier(self):
        row = self._current_row()
        if not row:
            return ""
        return row["supplier"].strip().upper()

    def _update_supplier_buttons(self):
        return

    def _selected_prop_row(self):
        rows = self.prop_grid.GetSelectedRows()
        if rows:
            row_index = rows[0]
        else:
            row_index = self.prop_grid.GetGridCursorRow()
        if row_index < 0 or row_index >= len(self.prop_rows):
            return None
        return self.prop_rows[row_index]

    def _on_delete(self, event):
        row_info = self._selected_prop_row()
        if not row_info:
            return self._set_status("Select a property row first.", wx.RED)
        key = row_info["key"]
        refs = row_info["refs"]
        if not refs:
            return self._set_status("Select a component first.", wx.RED)
        if key in PROTECTED:
            return self._set_status(f"'{key}' is required and cannot be deleted.", wx.RED)
        confirm = wx.MessageBox(
            f"Delete property '{key}' from {len(refs)} part(s)?",
            "Confirm delete",
            wx.YES_NO | wx.ICON_WARNING,
        )
        if confirm != wx.YES:
            return
        try:
            for ref in refs:
                self.sch.delete_property(ref, key)
            selected = refs[0]
            self.dirty = True
            if not self._autosave():
                return
            self._populate_components(selected)
            self._refresh_current_selection(selected)
            self._update_supplier_buttons()
            self._set_status(f"Deleted and saved '{key}' from {len(refs)} part(s).")
        except (KeyError, ValueError) as e:
            self._set_status(str(e), wx.RED)

    def _on_account_menu(self, event=None) -> None:
        menu = wx.Menu()
        item_usage = menu.Append(wx.ID_ANY, "View usage")
        self.Bind(wx.EVT_MENU, self._on_view_usage, item_usage)
        if self.auth and self.auth.plan in ("active", "trialing"):
            menu.AppendSeparator()
            item_cancel = menu.Append(wx.ID_ANY, "Cancel subscription")
            self.Bind(wx.EVT_MENU, self._on_cancel_subscription, item_cancel)
        menu.AppendSeparator()
        item_logout = menu.Append(wx.ID_ANY, "Log out")
        self.Bind(wx.EVT_MENU, self._on_logout, item_logout)
        self._acct_widget.PopupMenu(menu)
        menu.Destroy()

    def _on_cancel_subscription(self, _event) -> None:
        confirm = wx.MessageBox(
            "Cancel your Pro subscription?\n\nYou'll keep Pro access until the end of the current billing period.",
            "Cancel subscription",
            wx.YES_NO | wx.ICON_WARNING, self,
        )
        if confirm != wx.YES:
            return
        try:
            with urlopen(self._api_request(
                f"{BACKEND_URL}/billing/cancel-subscription", b"{}"
            ), timeout=10) as resp:
                json.loads(resp.read().decode())
        except HTTPError as e:
            self._handle_http_error(e)
            return
        except Exception as exc:
            self._set_status(f"Could not cancel subscription: {exc}", wx.RED)
            return
        wx.MessageBox(
            "Your subscription will cancel at the end of the billing period.",
            "Subscription cancelled", wx.OK | wx.ICON_INFORMATION, self,
        )
        wx.CallAfter(self._refresh_plan)

    def _clear_sourcing_data(self, row) -> None:
        clear_fields = (
            list(JLCPCB_FIELD_NAMES) + list(DIGIKEY_FIELD_NAMES) +
            [QUANTITY_FIELD, PRICE_FIELD, TIMESTAMP_FIELD]
        )
        for ref in row["refs"]:
            props = self.sch.get_properties(ref)
            for field in clear_fields:
                if field in props:
                    self.sch.set_property(ref, field, "")
        self.dirty = True
        self._autosave()
        self._set_row_call_status(row, "Sourcing cleared")
        self._populate_components(row["refs"][0])
        self._set_status(f"Cleared sourcing data for {len(row['refs'])} part(s).")

    def _refresh_plan(self) -> None:
        try:
            with urlopen(self._api_request(f"{BACKEND_URL}/auth/me"), timeout=5) as resp:
                data = json.loads(resp.read().decode())
            if self.auth:
                self.auth.save(self.auth.token, data.get("email", self.auth.email),
                               data.get("subscription_status", "free"))
            self._acct_widget.refresh()
        except Exception:
            pass

    def _on_clear_sourcing(self, _event) -> None:
        row = self._current_row()
        if not row:
            return self._set_status("Select a row first.", wx.RED)
        self._clear_sourcing_data(row)

    def _on_logout(self, _event) -> None:
        if self.auth:
            self.auth.clear()
        self.EndModal(wx.ID_CANCEL)

    def _on_search_part(self, _event) -> None:
        row = self._current_row()
        prefill_fp = row["footprint"].strip() if row and row["footprint"] not in ("", "Mixed") else ""
        dlg = PartSearchDialog(self, self.auth, prefill_footprint=prefill_fp)
        try:
            if dlg.ShowModal() != wx.ID_OK or not dlg.result:
                return
            result = dlg.result
            supplier_idx = dlg._supplier.GetSelection()
            supplier = "LCSC" if supplier_idx == 0 else "DigiKey"
            if not row:
                self._set_status("No component selected to apply result to.", wx.RED)
                return
            refs = row["refs"]
            part = result.get("part_number", "")
            if supplier == "LCSC":
                for ref in refs:
                    self.sch.set_property(ref, "Supplier", "LCSC")
                    self.sch.set_property(ref, "LCSC", part)
            else:
                for ref in refs:
                    self.sch.set_property(ref, "Supplier", "DigiKey")
                    self.sch.set_property(ref, "DigiKey", part)
                    if result.get("datasheet_url"):
                        self.sch.set_property(ref, "Datasheet", result["datasheet_url"])
            self.dirty = True
            if not self._autosave():
                return
            self._populate_components(refs[0])
            self._refresh_current_selection(refs[0])
            self._set_status(f"Applied {supplier} {part} to {len(refs)} part(s).")
        finally:
            dlg.Destroy()

    def _on_view_usage(self, _event) -> None:
        webbrowser.open("https://usetraces.com/dashboard")

    def _api_request(self, url: str, data: bytes = None, method: str = None) -> Request:
        headers = {}
        if data is not None:
            headers["Content-Type"] = "application/json"
        if self.auth:
            headers.update(self.auth.auth_headers())
        return Request(url, data=data, headers=headers,
                       method=method or ("POST" if data is not None else "GET"))

    def _handle_http_error(self, exc: HTTPError) -> bool:
        if exc.code == 401:
            self._set_status("Session expired — please restart KiCad to sign in again.", wx.RED)
            if self.auth:
                self.auth.clear()
            return True
        if exc.code == 402:
            try:
                detail = json.loads(exc.read().decode()).get("detail", {})
            except Exception:
                detail = {}
            reason = detail.get("reason", "")
            spent = detail.get("spent_usd", 0)
            limit = detail.get("limit_usd", 0)
            def fmt_usd(v):
                return f"${v:.4f}" if v < 0.01 else f"${v:.2f}"
            if reason == "free_limit_reached":
                msg = (f"You've spent {fmt_usd(spent)} of your {fmt_usd(limit)} free monthly budget.\n\n"
                       "Subscribe for a higher monthly limit.")
                choice = wx.MessageBox(msg, "Free tier limit reached",
                                       wx.YES_NO | wx.ICON_INFORMATION, self)
                if choice == wx.YES:
                    self._open_checkout()
            else:
                wx.MessageBox(
                    f"You've spent {fmt_usd(spent)} of your {fmt_usd(limit)} monthly budget.\n"
                    "Your usage resets at the start of next month.",
                    "Monthly limit reached", wx.OK | wx.ICON_INFORMATION, self,
                )
            return True
        return False

    def _open_checkout(self) -> None:
        try:
            with urlopen(self._api_request(f"{BACKEND_URL}/billing/checkout", b"{}"), timeout=10) as resp:
                checkout_url = json.loads(resp.read().decode()).get("checkout_url", "")
            if checkout_url:
                webbrowser.open(checkout_url)
        except Exception as exc:
            self._set_status(f"Could not open checkout: {exc}", wx.RED)

    def _submit_jlc_job(self, *, lcsc="", mpn="", footprint=""):
        body = json.dumps({"lcsc": lcsc, "mpn": mpn, "footprint": footprint}).encode("utf-8")
        with urlopen(self._api_request(JLCPCB_SOURCE_URL, body), timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))["job_id"]

    def _submit_digikey_job(self, *, description="", mpn="", footprint=""):
        payload = {"footprint": footprint}
        if description:
            payload["description"] = description
        if mpn:
            payload["mpn"] = mpn
        body = json.dumps(payload).encode("utf-8")
        with urlopen(self._api_request(DIGIKEY_SOURCE_URL, body), timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))["job_id"]

    def _submit_digikey_datasheet_job(self, part_number):
        body = json.dumps({"part_number": part_number}).encode("utf-8")
        with urlopen(self._api_request(DIGIKEY_DATASHEET_URL, body), timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))["job_id"]

    def _poll_job(self, job_id, label):
        status_url = f"{BACKEND_URL}/jobs/{job_id}"
        for _ in range(90):
            wx.YieldIfNeeded()
            time.sleep(1)
            with urlopen(self._api_request(status_url), timeout=10) as response:
                data = json.loads(response.read().decode("utf-8"))
            status = data.get("status")
            if status == "complete":
                return data.get("result") or {}
            if status == "failed":
                self._show_backend_error(f"{label} job failed on the server.", json.dumps(data, indent=2))
                raise RuntimeError(f"{label} job failed")
            if status == "not_found":
                self._show_backend_error(f"{label} job not found.", f"Job ID: {job_id}")
                raise RuntimeError(f"{label} job not found")
            self._set_status(f"{label} lookup running... {status}")
        self._show_backend_error(f"{label} lookup timed out.", f"Job ID: {job_id}")
        raise TimeoutError(f"{label} lookup timed out")

    def _poll_jlc_job(self, job_id):
        return self._poll_job(job_id, "JLC")

    def _poll_digikey_job(self, job_id):
        return self._poll_job(job_id, "Digi-Key")

    def _export_kicad_xml_netlist(self):
        cli = shutil.which("kicad-cli")
        if not cli:
            for candidate in [
                "/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli",
                "/usr/local/bin/kicad-cli",
                "/usr/bin/kicad-cli",
            ]:
                if Path(candidate).exists():
                    cli = candidate
                    break
        if not cli:
            raise RuntimeError("kicad-cli not found. Is KiCad installed and in your PATH?")

        with tempfile.NamedTemporaryFile(suffix=".xml", delete=False) as output:
            out_path = output.name
        try:
            subprocess.run(
                [cli, "sch", "export", "netlist", "--output", out_path, self.sch_path],
                check=True,
                capture_output=True,
                timeout=30,
            )
            return Path(out_path).read_text(encoding="utf-8")
        finally:
            Path(out_path).unlink(missing_ok=True)

    def _submit_src_job(self, category, xml):
        body = json.dumps({"xml": xml}).encode("utf-8")
        with urlopen(self._api_request(SRC_CHECKS[category], body), timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))["job_id"]

    def _set_property_preserving_key(self, ref, preferred_key, value):
        props = self.sch.get_properties(ref)
        key = preferred_key
        for existing_key in props:
            if existing_key.lower() == preferred_key.lower():
                key = existing_key
                break
        self.sch.set_property(ref, key, value)

    def _write_jlc_result(self, ref, result):
        return self._write_jlc_result_to_refs([ref], result)

    def _write_jlc_result_to_refs(self, refs, result, row=None):
        row = row or self._row_for_ref(refs[0])
        qty = result.get("qty", 0)
        price = result.get("price", None)
        part_number = result.get("part_number", "")
        if not part_number:
            self._set_row_call_status(row, "No JLC match")
            return False

        datasheet_url = result.get("datasheet_url", "")
        timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
        for ref in refs:
            self._set_property_preserving_key(ref, "LCSC", part_number)
            self._set_property_preserving_key(ref, QUANTITY_FIELD, str(qty))
            self._set_property_preserving_key(ref, PRICE_FIELD, "" if price is None else str(price))
            if datasheet_url:
                self._set_property_preserving_key(ref, DATASHEET_URL_FIELD, datasheet_url)
            self._set_property_preserving_key(ref, TIMESTAMP_FIELD, timestamp)
        if not self._autosave():
            self._set_row_call_status(row, "Updated, save failed")
            self._populate_components(refs[0])
            return True

        self._set_row_call_status(row, f"Updated JLC {part_number}")
        self._populate_components(refs[0])
        self._set_status(
            f"Updated and saved {len(refs)} part(s): LCSC={part_number}, {QUANTITY_FIELD}={qty}, {PRICE_FIELD}={price}."
        )
        return True

    def _write_digikey_result(self, ref, result):
        return self._write_digikey_result_to_refs([ref], result)

    def _write_digikey_result_to_refs(self, refs, result, row=None):
        row = row or self._row_for_ref(refs[0])
        qty = result.get("qty", 0)
        price = result.get("price", None)
        part_number = result.get("part_number", "")
        if not part_number:
            self._set_row_call_status(row, "No Digi-Key match")
            return False

        timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
        for ref in refs:
            self._set_property_preserving_key(ref, "Digikey Part Number", part_number)
            self._set_property_preserving_key(ref, QUANTITY_FIELD, str(qty))
            self._set_property_preserving_key(ref, PRICE_FIELD, "" if price is None else str(price))
            self._set_property_preserving_key(ref, TIMESTAMP_FIELD, timestamp)
        if not self._autosave():
            self._set_row_call_status(row, "Updated, save failed")
            self._populate_components(refs[0])
            return True

        self._set_row_call_status(row, f"Updated Digi-Key {part_number}")
        self._populate_components(refs[0])
        self._set_status(
            f"Updated and saved {len(refs)} part(s): Digikey Part Number={part_number}, {QUANTITY_FIELD}={qty}, {PRICE_FIELD}={price}."
        )
        return True

    def _download_pdf(self, url, dest, referer=None):
        opener = build_opener(HTTPSHandler(context=_ssl_ctx))
        opener.addheaders = [
            ("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"),
        ]
        headers = {"Accept": "application/pdf,text/html,*/*"}
        if referer:
            headers["Referer"] = referer
        with opener.open(Request(url, headers=headers), timeout=30) as resp:
            response_bytes = resp.read()
        if response_bytes.startswith(b"%PDF"):
            dest.write_bytes(response_bytes)
            return

        html = response_bytes.decode("utf-8", errors="replace")
        pdf_urls = re.findall(
            r"https://(?:datasheet|wmsc)\.lcsc\.com/[^\\\"']+?\.pdf",
            html,
        )
        pdf_urls.extend(re.findall(r"https://[^\\\"']+?\.pdf", html))
        if not pdf_urls:
            raise RuntimeError("Could not find a PDF URL in the datasheet page")

        pdf_url = pdf_urls[0]
        with opener.open(Request(pdf_url, headers={"Referer": url, "Accept": "application/pdf,*/*"}), timeout=30) as resp:
            pdf_bytes = resp.read()
        if not pdf_bytes.startswith(b"%PDF"):
            raise RuntimeError(f"Datasheet server did not return a PDF ({len(pdf_bytes)} bytes, starts: {pdf_bytes[:40]})")
        dest.write_bytes(pdf_bytes)

    def _on_fetch_jlc(self, event, row=None):
        row = row or self._current_row()
        if not row:
            return self._set_status("Select a component first.", wx.RED)

        if row["supplier"].strip().upper() != "LCSC":
            self._mark_row_call(row, "Supplier is not LCSC")
            return self._set_status(f"{row['reference']} supplier is not LCSC.", wx.RED)
        lcsc = row["lcsc"]
        footprint = row["footprint"]
        if not lcsc:
            self._mark_row_call(row, "Missing LCSC")
            return self._set_status(f"{row['reference']} does not have an LCSC field populated.", wx.RED)

        try:
            self._mark_row_call(row, "Submitting JLC")
            self._set_status(f"Submitting JLC lookup for {row['reference']} ({lcsc})...")
            job_id = self._submit_jlc_job(lcsc=lcsc, footprint=footprint)
            self._mark_row_call(row, "JLC running")
            result = self._poll_jlc_job(job_id)
        except HTTPError as e:
            self._mark_row_call(row, "JLC failed")
            if self._handle_http_error(e):
                return
            self._show_backend_error("JLC lookup failed.", str(e))
            return
        except (URLError, TimeoutError, RuntimeError, KeyError, json.JSONDecodeError) as e:
            self._mark_row_call(row, "JLC failed")
            self._show_backend_error("JLC lookup failed.", str(e))
            return

        if not result.get("part_number", ""):
            self._mark_row_call(row, "No JLC match")
            return self._set_status(f"No credible JLC match found for {lcsc}.", wx.RED)
        self._write_jlc_result_to_refs(row["refs"], result, row=row)
        self._set_status(f"Updated {len(row['refs'])} part(s) from JLC: {lcsc}.")

    def _on_find_jlc_from_value(self, event, row=None):
        row = row or self._current_row()
        if not row:
            return self._set_status("Select a component first.", wx.RED)

        if row["supplier"].strip().upper() != "LCSC":
            self._mark_row_call(row, "Supplier is not LCSC")
            return self._set_status(f"{row['reference']} supplier is not LCSC.", wx.RED)
        value = row["value"].strip()
        footprint = row["footprint"].strip()
        if not value:
            self._mark_row_call(row, "Missing Value")
            return self._set_status(f"{row['reference']} does not have a Value populated.", wx.RED)
        if not footprint:
            self._mark_row_call(row, "Missing Footprint")
            return self._set_status(f"{row['reference']} does not have a Footprint populated.", wx.RED)

        try:
            self._mark_row_call(row, "Submitting JLC")
            self._set_status(f"Finding JLC part for {row['reference']} from Value={value}, Footprint={footprint}...")
            job_id = self._submit_jlc_job(mpn=value, footprint=footprint)
            self._mark_row_call(row, "JLC running")
            result = self._poll_jlc_job(job_id)
        except HTTPError as e:
            self._mark_row_call(row, "JLC failed")
            if self._handle_http_error(e):
                return
            self._show_backend_error("JLC lookup failed.", str(e))
            return
        except (URLError, TimeoutError, RuntimeError, KeyError, json.JSONDecodeError) as e:
            self._mark_row_call(row, "JLC failed")
            self._show_backend_error("JLC lookup failed.", str(e))
            return

        if not result.get("part_number", ""):
            self._mark_row_call(row, "No JLC match")
            return self._set_status(f"No credible JLC match found for {value} / {footprint}.", wx.RED)
        self._write_jlc_result_to_refs(row["refs"], result, row=row)
        self._set_status(f"Updated {len(row['refs'])} part(s) from JLC: {result.get('part_number', '')}.")

    def _on_find_digikey_from_value(self, event, row=None):
        row = row or self._current_row()
        if not row:
            return self._set_status("Select a component first.", wx.RED)

        if row["supplier"].strip().upper() not in {"DIGIKEY", "DIGI-KEY"}:
            self._mark_row_call(row, "Supplier is not Digi-Key")
            return self._set_status(f"{row['reference']} supplier is not Digi-Key.", wx.RED)

        value = row["value"].strip()
        footprint = row["footprint"].strip()
        digikey_part = "" if row["digikey"] == "Mixed" else row["digikey"]
        if not value and not digikey_part:
            self._mark_row_call(row, "Missing Value/part")
            return self._set_status(f"{row['reference']} does not have a Value or Digikey Part Number populated.", wx.RED)
        if not footprint:
            self._mark_row_call(row, "Missing Footprint")
            return self._set_status(f"{row['reference']} does not have a Footprint populated.", wx.RED)

        try:
            if digikey_part:
                self._mark_row_call(row, "Submitting Digi-Key")
                self._set_status(f"Updating Digi-Key availability for {row['reference']} ({digikey_part})...")
                job_id = self._submit_digikey_job(mpn=digikey_part, footprint=footprint)
            else:
                self._mark_row_call(row, "Submitting Digi-Key")
                self._set_status(f"Finding Digi-Key part for {row['reference']} from Value={value}, Footprint={footprint}...")
                job_id = self._submit_digikey_job(description=value, footprint=footprint)
            self._mark_row_call(row, "Digi-Key running")
            result = self._poll_digikey_job(job_id)
        except HTTPError as e:
            self._mark_row_call(row, "Digi-Key failed")
            if self._handle_http_error(e):
                return
            self._show_backend_error("Digi-Key lookup failed.", str(e))
            return
        except (URLError, TimeoutError, RuntimeError, KeyError, json.JSONDecodeError) as e:
            self._mark_row_call(row, "Digi-Key failed")
            self._show_backend_error("Digi-Key lookup failed.", str(e))
            return

        search_label = digikey_part or value
        if not result.get("part_number", ""):
            self._mark_row_call(row, "No Digi-Key match")
            return self._set_status(f"No credible Digi-Key match found for {search_label} / {footprint}.", wx.RED)
        self._write_digikey_result_to_refs(row["refs"], result, row=row)
        self._set_status(f"Updated {len(row['refs'])} part(s) from Digi-Key: {result.get('part_number', '')}.")

    def _on_download_datasheet(self, event, row=None):
        row = row or self._current_row()
        if not row:
            return self._set_status("Select a component first.", wx.RED)

        url = row.get("datasheet", "")
        lcsc = row["lcsc"]
        if not url or url == "Mixed":
            supplier = row["supplier"].strip().upper()
            if supplier == "LCSC":
                if not lcsc:
                    return self._set_status(f"{row['reference']} does not have an LCSC field populated.", wx.RED)
                try:
                    self._set_status(f"Fetching datasheet URL for {row['reference']} ({lcsc})...")
                    body = json.dumps({"lcsc": lcsc}).encode("utf-8")
                    with urlopen(self._api_request(DATASHEET_FETCH_URL, body), timeout=10) as response:
                        job_id = json.loads(response.read().decode("utf-8"))["job_id"]
                    result = self._poll_jlc_job(job_id)
                except HTTPError as e:
                    if self._handle_http_error(e):
                        return
                    return self._set_status(f"Datasheet fetch failed: {e}", wx.RED)
                except (URLError, TimeoutError, RuntimeError, KeyError, json.JSONDecodeError) as e:
                    return self._set_status(f"Datasheet fetch failed: {e}", wx.RED)
                url = (result or {}).get("url", "")
            elif supplier in {"DIGIKEY", "DIGI-KEY"}:
                digikey_part = "" if row["digikey"] == "Mixed" else row["digikey"]
                if not digikey_part:
                    return self._set_status(f"{row['reference']} does not have a Digi-Key part number.", wx.RED)
                try:
                    self._set_status(f"Fetching Digi-Key datasheet URL for {row['reference']} ({digikey_part})...")
                    job_id = self._submit_digikey_datasheet_job(digikey_part)
                    result = self._poll_digikey_job(job_id)
                except (URLError, TimeoutError, RuntimeError, KeyError, json.JSONDecodeError) as e:
                    return self._set_status(f"Digi-Key datasheet fetch failed: {e}", wx.RED)
                url = (result or {}).get("url", "")
            else:
                return self._set_status(f"{row['reference']} does not have a usable Datasheet URL.", wx.RED)
        if not url:
            label = lcsc or row["reference"]
            return self._set_status(f"No datasheet URL returned for {label}.", wx.RED)

        for ref in row["refs"]:
            self.sch.set_property(ref, DATASHEET_URL_FIELD, url)
        if len(row["refs"]) == 1:
            self._load_props(row["refs"][0])
        else:
            self._load_group_props(row)
        self._populate_components(row["refs"][0])
        self._update_supplier_buttons()
        self.dirty = True
        if not self._autosave():
            return

        datasheets_dir = Path(self.sch_path).parent / "datasheets"
        datasheets_dir.mkdir(exist_ok=True)
        safe_name = lcsc or row["refs"][0]
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", safe_name)
        dest = datasheets_dir / f"{safe_name}.pdf"

        try:
            self._set_status(f"Downloading datasheet for {row['reference']}...")
            self._download_pdf(url, dest)
        except Exception as e:
            return self._set_status(f"Download failed: {e}", wx.RED)

        for ref in row["refs"]:
            self.sch.set_property(ref, DATASHEET_LOCAL_FIELD, str(dest))
        if len(row["refs"]) == 1:
            self._load_props(row["refs"][0])
        else:
            self._load_group_props(row)
        self._populate_components(row["refs"][0])
        self._update_supplier_buttons()
        self.dirty = True
        if not self._autosave():
            return

        self._set_status(f"Datasheet saved for {len(row['refs'])} part(s): {dest}")

# ---------------------------------------------------------------------------
# Plugin entry point
# ---------------------------------------------------------------------------

class SchematicPropertyEditor(pcbnew.ActionPlugin):
    def defaults(self):
        self.name = "traces"
        self.category = "Schematic"
        self.description = "Reconcile schematic metadata, suppliers, datasheets, and SRC netlists."
        self.show_toolbar_button = True
        self.icon_file_name = str(Path(__file__).with_name("traces.png"))

    def Run(self):
        board = pcbnew.GetBoard()
        if not board or not board.GetFileName():
            wx.MessageBox(
                "Open this from a saved PCB inside a KiCad project.",
                "traces",
            )
            return

        project_folder = Path(board.GetFileName()).parent
        sch_files = list(project_folder.glob("*.kicad_sch"))

        if not sch_files:
            wx.MessageBox(
                f"No .kicad_sch files found in:\n{project_folder}",
                "traces",
            )
            return

        # If multiple schematics, let the user pick
        if len(sch_files) == 1:
            sch_path = str(sch_files[0])
        else:
            choices = [f.name for f in sch_files]
            dlg = wx.SingleChoiceDialog(
                None,
                "Multiple schematic files found. Pick one:",
                "Select schematic",
                choices,
            )
            if dlg.ShowModal() != wx.ID_OK:
                dlg.Destroy()
                return
            sch_path = str(sch_files[dlg.GetSelection()])
            dlg.Destroy()

        auth = AuthManager()
        if not auth.is_authenticated():
            login_dlg = LoginDialog(auth)
            result = login_dlg.ShowModal()
            login_dlg.Destroy()
            if result != wx.ID_OK:
                return

        try:
            sch = KiCadSchematic(sch_path)
        except Exception as e:
            wx.MessageBox(f"Failed to parse schematic:\n\n{e}", "traces")
            return

        if not sch.get_references():
            wx.MessageBox("No placed components found in schematic.", "traces")
            return

        dialog = PropEditorDialog(sch, sch_path, board, auth=auth)
        dialog.ShowModal()
        dialog.Destroy()


SchematicPropertyEditor().register()
