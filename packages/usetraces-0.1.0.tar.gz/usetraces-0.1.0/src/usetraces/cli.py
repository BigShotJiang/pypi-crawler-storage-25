from __future__ import annotations

import argparse
import shutil
from contextlib import ExitStack
from importlib.resources import as_file, files
from pathlib import Path


PLUGIN_FILES = ("traces.py", "traces.png")
OLD_PLUGIN_FILES = (
    "backend_ping.py",
    "part_link_check.py",
    "prop_editor.py",
    "schematic_0402_check.py",
    "schematic_snapshot.py",
)
PROD_BACKEND = 'BACKEND_URL = "https://usetraces.com"'
DEV_BACKEND = 'BACKEND_URL = "http://127.0.0.1:8000"'


def _default_kicad_dir() -> Path:
    return Path.home() / "Documents" / "KiCad" / "10.0" / "scripting" / "plugins"


def install(args: argparse.Namespace) -> int:
    plugin_dir = Path(args.plugin_dir).expanduser() if args.plugin_dir else _default_kicad_dir()
    kicad_root = plugin_dir.parents[1] if len(plugin_dir.parents) >= 2 else None
    if not args.force and kicad_root and not kicad_root.exists():
        print(f"KiCad 10.0 not found at {kicad_root}. Use --plugin-dir to choose a plugin directory.")
        return 1

    plugin_dir.mkdir(parents=True, exist_ok=True)
    resource_dir = files("usetraces").joinpath("kicad_plugin")
    with ExitStack() as stack:
        for plugin_file in PLUGIN_FILES:
            source = stack.enter_context(as_file(resource_dir.joinpath(plugin_file)))
            dest = plugin_dir / plugin_file
            shutil.copy2(source, dest)
            if plugin_file == "traces.py" and args.dev:
                text = dest.read_text(encoding="utf-8")
                dest.write_text(text.replace(PROD_BACKEND, DEV_BACKEND), encoding="utf-8")

    if args.cleanup_old:
        for plugin_file in OLD_PLUGIN_FILES:
            (plugin_dir / plugin_file).unlink(missing_ok=True)
        shutil.rmtree(plugin_dir / "__pycache__", ignore_errors=True)

    mode = "dev -> localhost:8000" if args.dev else "prod -> usetraces.com"
    print(f"Installed traces KiCad plugin to {plugin_dir} ({mode}). Restart KiCad.")
    return 0


def uninstall(args: argparse.Namespace) -> int:
    plugin_dir = Path(args.plugin_dir).expanduser() if args.plugin_dir else _default_kicad_dir()
    if not plugin_dir.exists():
        print(f"KiCad plugin directory not found at {plugin_dir}. Nothing to uninstall.")
        return 0

    for plugin_file in PLUGIN_FILES:
        (plugin_dir / plugin_file).unlink(missing_ok=True)
    shutil.rmtree(plugin_dir / "__pycache__", ignore_errors=True)
    print(f"Uninstalled traces KiCad plugin from {plugin_dir}. Restart KiCad.")
    return 0

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="usetraces")
    subparsers = parser.add_subparsers(dest="command", required=True)

    install_parser = subparsers.add_parser("install", help="Install the traces KiCad plugin.")
    install_parser.add_argument("--dev", action="store_true", help="Point the plugin at localhost:8000.")
    install_parser.add_argument("--force", action="store_true", help="Create the plugin directory even if KiCad is not found.")
    install_parser.add_argument("--cleanup-old", action="store_true", help="Remove legacy traces plugin filenames.")
    install_parser.add_argument("--plugin-dir", help="Override KiCad's scripting plugins directory.")
    install_parser.set_defaults(func=install)

    uninstall_parser = subparsers.add_parser("uninstall", help="Uninstall the traces KiCad plugin.")
    uninstall_parser.add_argument("--plugin-dir", help="Override KiCad's scripting plugins directory.")
    uninstall_parser.set_defaults(func=uninstall)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)
