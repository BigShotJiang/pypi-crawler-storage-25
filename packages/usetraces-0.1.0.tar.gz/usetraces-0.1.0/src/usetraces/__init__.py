"""Installer helpers for the traces KiCad plugin."""

__version__ = "0.1.0"
