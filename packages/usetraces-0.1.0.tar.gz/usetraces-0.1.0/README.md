# usetraces — KiCad Plugin

KiCad 10 plugin for schematic metadata reconciliation, supplier sourcing, datasheets, and AI-powered design checks.

The `usetraces` KiCad plugin is licensed under GPL-3.0-or-later. The hosted traces service is separate proprietary infrastructure.

## Install

```bash
pip install usetraces
usetraces install
```

Restart KiCad, then launch from: **PCB Editor → Tools → External Plugins → traces**

For local backend development:

```bash
usetraces install --dev
```

## Uninstall

```bash
usetraces uninstall
```

## First launch

The plugin will open a sign-in page in your browser. Create an account or sign in, then return to KiCad — the plugin polls automatically and opens once authenticated.

Your session token is saved to `~/.config/traces/auth.json` and reused on future launches.

## Account menu

The bottom bar of the plugin shows your email as a menu button. Click it to:

- **View usage** — shows current month AI spend vs. your tier limit, plus raw token counts
- **Log out** — clears the saved token; the next launch will prompt for sign-in

## Workflow steps

| Step | What it does |
|------|-------------|
| Footprints | Edit Value + Footprint for each part; or reconcile missing footprints from the PCB layout |
| Supplier | Set LCSC, Digi-Key, or N/A per part |
| Source | AI-powered supplier lookup — finds part number, stock, price |
| Datasheets | Fetches and downloads datasheet PDFs |
| SRC | AI schematic review checks: typos, consistency, orphans, near-duplicates |

In the Source step, **Clear sourcing** removes the current part number/qty/price so you can re-source. Switching supplier also clears sourcing data automatically.

## Backend URL

The plugin connects to `https://usetraces.com` by default. Use `usetraces install --dev` to point a local install at `http://127.0.0.1:8000`.
