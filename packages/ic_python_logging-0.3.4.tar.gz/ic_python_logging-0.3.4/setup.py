from setuptools import find_packages, setup
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="ic-python-logging",
    version="0.3.4",
    author="Smart Social Contracts",
    author_email="smartsocialcontracts@gmail.com",
    description="A robust logging system for Internet Computer canisters",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/smart-social-contracts/ic-python-logging",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "kslog=ic_python_logging.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3.10",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Debuggers",
    ],
    python_requires=">=3.7",
    install_requires=[],
)
