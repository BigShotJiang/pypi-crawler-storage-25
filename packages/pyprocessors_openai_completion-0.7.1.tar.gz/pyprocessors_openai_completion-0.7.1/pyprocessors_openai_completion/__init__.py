"""OpenAICompletion processor"""
__version__ = "0.7.1"
