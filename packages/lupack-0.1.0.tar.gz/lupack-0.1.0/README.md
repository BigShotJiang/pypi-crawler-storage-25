# LuPack

Use any Python package directly inside your Lua scripts!

Built on top of [LuaWrap](https://pypi.org/project/LuaWrap/).

## Installation

```bash
pip install LuPack
```

## How to Use

Python packages are injected into your Lua script and available as `py_<packagename>`.

### Quickstart with `lua_with()`

Pass your package names in, get a runner back, then write Lua as normal:

```python
from LuPack import lua_with

lua_with("math")("""
    local result = py_math.sqrt(144)
    print("Square root of 144 is: " .. result)
""")
```

### Multiple packages at once

```python
from LuPack import lua_with

lua_with("math", "os")("""
    print("Pi is: " .. py_math.pi)
    print("Current folder: " .. py_os.getcwd())
""")
```

### Reuse the runner

```python
from LuPack import lua_with

run = lua_with("math")

run("print(py_math.floor(3.9))")
run("print(py_math.sqrt(25))")
```

### Full control with `LuPackRuntime`

```python
from LuPack import LuPackRuntime

rt = LuPackRuntime()
rt.register("math")           # available as py_math in Lua
rt.register("os", "system")  # available as py_system in Lua

rt.run("""
    print(py_math.pi)
    print(py_system.getcwd())
""")
```

## How packages are named in Lua

| Python package | Lua name |
|---|---|
| `math` | `py_math` |
| `os` | `py_os` |
| `requests` | `py_requests` |
| `os` with alias `"system"` | `py_system` |

## API

| Tool | What it does |
|---|---|
| `lua_with("pkg1", "pkg2")` | Returns a runner with those packages injected |
| `LuPackRuntime()` | Full runtime object for more control |
| `rt.register("pkg")` | Inject a package into the runtime |
| `rt.register("pkg", "alias")` | Inject with a custom Lua name |
| `rt.run("...")` | Run Lua code with all registered packages |