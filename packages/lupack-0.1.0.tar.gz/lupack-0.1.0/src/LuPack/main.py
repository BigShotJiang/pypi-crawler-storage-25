"""
LuPack core - use Python packages inside Lua scripts.
Import from the top-level package:
    from LuPack import lua_with, LuPackRuntime
"""

import importlib
from typing import Any, Dict, Optional

try:
    from lupa import LuaRuntime
except ImportError:
    raise ImportError(
        "\n[LuPack] The 'lupa' package is not installed!\n"
        "Fix it by running:\n"
        "    pip install lupa\n"
    )


class LuPackRuntime:
    """
    A Lua runtime that has Python packages injected into it.
    Any package you register becomes callable from inside your Lua code.

    Example:
        rt = LuPackRuntime()
        rt.register("os")
        rt.register("math")
        rt.run('''
            print(py_math.pi)
            print(py_os.getcwd())
        ''')
    """

    def __init__(self):
        self._runtime = LuaRuntime(unpack_returned_tuples=True)
        self._packages: Dict[str, Any] = {}

    def register(self, package_name: str, alias: Optional[str] = None):
        """
        Import a Python package and expose it to Lua.
        In Lua it will be available as py_<name> (or py_<alias> if given).

        Example:
            rt.register("math")          # use as py_math in Lua
            rt.register("os", "system")  # use as py_system in Lua
        """
        try:
            module = importlib.import_module(package_name)
        except ImportError:
            raise ImportError(
                "[LuPack] Could not import '{}'. Make sure it is installed:\n"
                "    pip install {}".format(package_name, package_name)
            )

        lua_name = "py_{}".format(alias if alias else package_name.replace(".", "_"))
        self._packages[lua_name] = module
        self._runtime.globals()[lua_name] = module
        print("[LuPack] Registered '{}' as '{}' in Lua.".format(package_name, lua_name))
        return self

    def run(self, lua_code: str) -> object:
        """
        Run a Lua script with all registered packages available.

        Example:
            rt.run('''
                local result = py_math.sqrt(144)
                print("Square root: " .. result)
            ''')
        """
        return self._runtime.execute(lua_code)


def lua_with(*package_names: str):
    """
    Shorthand to run Lua code with Python packages injected.
    Pass package names, get back a runner function you call with Lua code.

    Example:
        lua_with("math", "os")('''
            print(py_math.pi)
            print(py_os.getcwd())
        ''')

    Or reuse the runner:
        run = lua_with("math")
        run("print(py_math.floor(3.9))")
        run("print(py_math.sqrt(25))")
    """
    rt = LuPackRuntime()
    for name in package_names:
        rt.register(name)

    def runner(lua_code: str):
        return rt.run(lua_code)

    return runner