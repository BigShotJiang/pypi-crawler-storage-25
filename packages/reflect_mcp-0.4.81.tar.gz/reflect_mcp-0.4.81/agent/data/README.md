# agent/data — subscriber store and runtime data

## subscribers.jsonl

Each line is a JSON object. Schema:

```json
{
  "email":          "user@example.com",
  "source":         "landing-page",
  "subscribed_at":  "2026-05-06T20:00:00+00:00",
  "status":         "active"
}
```

**Fields:**
- `email` — normalized to lowercase
- `source` — how they subscribed: `landing-page`, `import`, etc.
- `subscribed_at` — ISO 8601 UTC timestamp
- `status` — `active` | `unsubscribed` | `bounced`

**Invariants:**
- One email per line; append-only
- Unsubscribes are status changes, not deletions (preserve audit trail)
- No PII beyond email stored here

## Buttondown import

When the Buttondown API key lands, run:
```
uv run python agent/lib/buttondown.py import agent/data/subscribers.jsonl
```
(Module to be built in a future wake; key gated on originator.)
