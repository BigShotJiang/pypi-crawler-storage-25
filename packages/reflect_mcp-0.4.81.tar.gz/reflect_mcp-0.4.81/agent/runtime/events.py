"""Wake event stream emitter for the reflect runtime.

Writes structured JSONL events to agent/runtime/events/{YYYY-MM-DD}.jsonl
with agent/runtime/events.jsonl always pointing at today's file.

Design doc: agent/design/events-schema.md

Usage:
    from .events import emit_event

    emit_event("wake.started", track="main", wake_id=wake_id, payload={
        "pid": os.getpid(),
        "kickoff_source": os.environ.get("REFLECT_KICKOFF_SOURCE", "scheduled"),
    })

All callers must treat emit_event() as fire-and-forget: it never raises. Events
must not block or break wakes. On any failure, the error is logged to stderr only.

Schema version policy:
  - Adding new event types or optional payload fields: non-breaking, no version bump.
  - Removing or renaming existing fields: breaking, increment SCHEMA_VERSION.
  - Consumers must ignore unknown fields (forward compatibility).
"""

import json
import os
import secrets
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_VERSION = "1.0"

# Default runtime root — callers can override via emit_event(runtime_root=...)
_DEFAULT_RUNTIME_ROOT: Path | None = None


def _runtime_root() -> Path:
    """Resolve the runtime root directory.

    Uses the override set by set_runtime_root(), or falls back to inferring
    from this file's location (agent/runtime/events.py → agent/runtime/).
    """
    if _DEFAULT_RUNTIME_ROOT is not None:
        return _DEFAULT_RUNTIME_ROOT
    return Path(__file__).parent


def set_runtime_root(path: Path) -> None:
    """Override the default runtime root. Called by wake.py on startup."""
    global _DEFAULT_RUNTIME_ROOT
    _DEFAULT_RUNTIME_ROOT = path


def _events_dir(runtime_root: Path) -> Path:
    return runtime_root / "events"


def _today_path(runtime_root: Path) -> Path:
    """Return the path for today's events file (YYYY-MM-DD.jsonl)."""
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    return _events_dir(runtime_root) / f"{today}.jsonl"


def _symlink_path(runtime_root: Path) -> Path:
    """Return the path for the always-current events.jsonl symlink."""
    return runtime_root / "events.jsonl"


def _ensure_events_file(runtime_root: Path) -> Path:
    """Ensure today's events file and the events.jsonl symlink exist.

    Returns the path to today's events file.
    Creates the events/ directory if needed.
    Updates the events.jsonl symlink to point at today's file if it's stale.
    """
    events_dir = _events_dir(runtime_root)
    events_dir.mkdir(parents=True, exist_ok=True)

    today_path = _today_path(runtime_root)
    # Touch today's file so it exists for tail consumers.
    if not today_path.exists():
        today_path.touch()

    symlink = _symlink_path(runtime_root)
    # Update symlink to point at today's file (relative path so it's portable).
    target = Path("events") / today_path.name
    try:
        if symlink.is_symlink():
            current = Path(os.readlink(str(symlink)))
            if current != target:
                symlink.unlink()
                symlink.symlink_to(target)
        elif not symlink.exists():
            symlink.symlink_to(target)
        # If symlink.exists() but is not a symlink (regular file from old impl),
        # leave it alone — don't stomp data.
    except Exception as exc:
        # Symlink management failure is non-fatal — events still write to today_path.
        print(f"⚠️  events: symlink update failed ({exc})", file=sys.stderr)

    return today_path


def _make_event_id() -> str:
    """Generate a sortable, unique event ID.

    Format: evt_{timestamp_ms}_{random_hex8}
    No external dependency (avoids adding ulid-py to the project).
    Sortable by timestamp; collision-resistant via 32-bit random suffix.
    """
    ts_ms = int(time.time() * 1000)
    rand = secrets.token_hex(4)  # 8 hex chars
    return f"evt_{ts_ms}_{rand}"


def _apply_retention(runtime_root: Path, retention_days: int = 90) -> None:
    """Gzip events files older than retention_days. Non-blocking, best-effort.

    Called at most once per wake (from emit_event on first call of the day).
    Failures are logged but do not interrupt emission.
    """
    import gzip
    import shutil

    events_dir = _events_dir(runtime_root)
    if not events_dir.is_dir():
        return

    cutoff = time.time() - retention_days * 86400
    try:
        for p in events_dir.iterdir():
            if p.suffix != ".jsonl":
                continue
            if p.stat().st_mtime > cutoff:
                continue
            gz_path = p.with_suffix(".jsonl.gz")
            if gz_path.exists():
                continue
            try:
                with p.open("rb") as src, gzip.open(str(gz_path), "wb") as dst:
                    shutil.copyfileobj(src, dst)
                p.unlink()
            except Exception as inner_exc:
                print(f"⚠️  events: retention gzip failed for {p.name}: {inner_exc}", file=sys.stderr)
    except Exception as exc:
        print(f"⚠️  events: retention scan failed: {exc}", file=sys.stderr)


# Track whether we've run retention this process lifetime (once per wake is enough).
_retention_run = False


def emit_event(
    type: str,
    track: str,
    wake_id: str,
    payload: dict,
    *,
    runtime_root: Path | None = None,
) -> str:
    """Append one event to today's events.jsonl.

    Returns the event id (useful for referencing in follow-up events).
    Never raises — all errors are logged to stderr only.

    Args:
        type: Event type string (e.g. "wake.started", "commit.made").
        track: Track name (e.g. "main", "toilet-worker").
        wake_id: Current wake ID (e.g. "2026-05-10T07-34-01Z").
        payload: Dict of event-type-specific fields. See events-schema.md for shape.
        runtime_root: Override for testing. Defaults to agent/runtime/.
    """
    global _retention_run

    event_id = _make_event_id()
    at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + \
         f"{datetime.now(timezone.utc).microsecond // 1000:03d}Z"

    event = {
        "id": event_id,
        "type": type,
        "at": at,
        "track": track,
        "wake_id": wake_id,
        "event_schema_version": SCHEMA_VERSION,
        "payload": payload,
    }

    root = runtime_root or _runtime_root()

    try:
        today_path = _ensure_events_file(root)

        # Run retention on first emit per process (once per wake).
        if not _retention_run:
            _retention_run = True
            try:
                _apply_retention(root)
            except Exception:
                pass  # retention failure never blocks emission

        with today_path.open("a", buffering=1) as fh:
            fh.write(json.dumps(event, default=str) + "\n")

    except Exception as exc:
        print(f"⚠️  events: emit_event({type}) failed: {exc}", file=sys.stderr)
        return event_id

    # Fire webhook delivery (fire-and-forget; never blocks or raises).
    try:
        from .webhooks import deliver_event
        deliver_event(event, runtime_root=root)
    except Exception as exc:
        print(f"⚠️  events: webhook dispatch failed: {exc}", file=sys.stderr)

    return event_id


def emit_inbox_consumed(
    track: str,
    consumed_path: Path,
    wake_id: str | None,
    source: str,
    *,
    runtime_root: Path | None = None,
) -> str:
    """Emit a single inbox.consumed event.

    Single helper used by both dispatcher auto-sweep (source="auto") and
    manual consume (source="manual"). Backward-compatible: legacy consumers
    that ignore unknown fields render absent source as "auto".

    Args:
        track: Track name whose inbox was consumed.
        consumed_path: Absolute path to the file inside .consumed/.
        wake_id: Current wake ID, or None for manual consume.
        source: "auto" (dispatcher) or "manual" (operator action).
        runtime_root: Override for testing.
    """
    return emit_event(
        "inbox.consumed",
        track=track,
        wake_id=wake_id or "",
        payload={
            "track": track,
            "path": str(consumed_path),
            "wake_id": wake_id,
            "source": source,
        },
        runtime_root=runtime_root,
    )
