# @scry.entry
# id: code.cluster-harness~54504339
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:cluster-harness", "cluster-harness",
#        "topic:cluster", "cluster", "topic:S7c", "S7c", "kind:code", "code",
#        "substrate-evolution", "HarnessBackend", "LoopbackHarness", "DropletHarness",
#        "ClusterConfig", "ClusterSnapshot", "NodeStatus", "provision_cluster",
#        "teardown_cluster", "observe_cluster", "SSH-key-lifecycle",
#        "non-quorum", "non-authority", "AR9", "FR51-ordering-invariant",
#        "DigitalOcean", "do-mcp", "_deploy_node", "bootstrap_node",
#        "FR-BOOTSTRAP", "cluster_node_bootstrap"]
# summary: >
#   S7c implementation — cluster-harness Python module. Implements
#   HarnessBackend abstract class (FR46), ClusterConfig, ClusterSnapshot /
#   NodeStatus, LoopbackHarness (N node processes on one host, FR45),
#   and DropletHarness (N DigitalOcean droplets via DO REST API). SSH-key
#   lifecycle for DropletHarness: generate OpenSSH keypair → register with
#   DO REST API (FR48) → create droplets with key_id (FR49, FR51 ordering
#   enforced) → deploy via _deploy_to_droplet() calling bootstrap_node()
#   from cluster_node_bootstrap.py (FR-BOOTSTRAP) → revoke + destroy on
#   teardown (FR50). Non-quorum / non-authority invariant (AR9): no runtime
#   control path post-bootstrap. provision_cluster refuses n < 4 unless
#   allow_non_bft=True (FR52). observe_cluster returns read-only
#   ClusterSnapshot (FR53). Also: cluster-harness, HarnessBackend,
#   LoopbackHarness, DropletHarness, provision_cluster, teardown_cluster,
#   observe_cluster, ClusterSnapshot, NodeStatus, SSH key, DO REST API,
#   S7c, substrate-evolution, cluster_harness.py, FR46-FR53, AR9,
#   _deploy_to_droplet, bootstrap_node, FR-BOOTSTRAP, cluster_node_bootstrap,
#   digitalocean.api_token, _read_do_token, DropletHarness REST API.
# rationale: >
#   Without this, the cluster has no defined provisioner. S5a/S5b/S5c/S5d
#   presuppose N>=4 independently running nodes; without cluster_harness.py
#   there is no path from zero nodes to N running quorum nodes. The FR51
#   ordering guard prevents key-less DO droplets (emailed root credentials,
#   security violation). AR9 ensures harness compromise cannot defeat BFT.
#   _deploy_node wires DropletHarness to bootstrap_node() — without it
#   provisioned droplets remain uninitialized hosts with no reflect runtime.
# applies: >
#   provisioning a cluster (loopback dev or DigitalOcean real), auditing the
#   non-authority boundary (AR9), implementing SSH key lifecycle, reviewing
#   FR51 ordering enforcement, adding observability to the cluster,
#   tearing down a cluster cleanly, reviewing provision_cluster n>=4 gate,
#   wiring DropletHarness deploy step to bootstrap_node
# seeded_questions:
#   - "How do I provision a loopback cluster for testing?"
#   - "What is the SSH key lifecycle for DigitalOcean?"
#   - "Is droplet creation gated on key registration?"
#   - "Can the harness override quorum after bootstrap?"
#   - "What is AR9?"
#   - "What is ClusterSnapshot?"
#   - "cluster_harness.py S7c substrate-evolution"
#   - "provision_cluster teardown_cluster observe_cluster"
#   - "FR51 SSH key ordering guard"
#   - "LoopbackHarness DropletHarness"
#   - "How does DropletHarness deploy bootstrap_node?"
#   - "_deploy_node bootstrap_node wiring DropletHarness"
#   - "FR-BOOTSTRAP cluster_node_bootstrap"
# @scry.entry.end

"""
S7c — Cluster Harness (spec.cluster-harness~2c8ce410)

Provision, deploy, and observe the cluster.

Two backend implementations:
  LoopbackHarness  — N node processes on the harness host (dev/test).
  DropletHarness   — N DigitalOcean droplets via do-mcp (production).

Safety invariant (AR9): after provision_cluster() returns, the harness
has no runtime control path that can alter quorum state.

Requirements satisfied:
- FR46: HarnessBackend abstraction; LoopbackHarness + DropletHarness.
- FR47: Fresh SSH keypair per cluster lifecycle (droplet only).
- FR48: SSH key registered with DO before any droplet creation.
- FR49: key_id referenced in every droplet create call.
- FR50: SSH key revoked + local private key deleted on teardown.
- FR51: HARD ORDERING — droplet create MUST NOT run before ssh_key
        register completes. Enforced by guard; not optimistic.
- FR52: provision_cluster refuses n < 4 unless allow_non_bft=True.
- FR53: observe_cluster() returns a read-only ClusterSnapshot.
- INV-S7c-1: Harness host is not listed as a quorum node.
- INV-S7c-2: SSH key pre-exists every droplet (droplet backend).
- INV-S7c-3: Key cleanup on teardown (droplet backend).
- INV-S7c-4: observe_cluster is read-only.
- INV-S7c-5: Backend fixed at initialization.
- AR9: No runtime control path post-bootstrap.
- NFR-S7c-1: provision_cluster refuses double-provision.
- NFR-S7c-2: teardown_cluster does not return until all resources released.
"""

from __future__ import annotations

import base64
import json
import multiprocessing
import os
import subprocess
import tempfile
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Optional

# `requests` is only needed by DropletHarness (DigitalOcean REST API).
# Loopback-only consumers (LoopbackHarness, tests) must be able to import
# this module without the dependency installed. Guard the import so
# module-load doesn't fail; DropletHarness checks the sentinel and raises
# a clear error at instantiation time.
try:
    import requests  # type: ignore[import-not-found]
except ImportError:  # pragma: no cover — exercised by import-gate test
    requests = None  # type: ignore[assignment]


def _require_requests() -> None:
    """Raise a clear error if the `requests` package isn't installed.

    DropletHarness uses the DigitalOcean REST API and needs `requests`.
    LoopbackHarness does not. Calling this from DropletHarness.__init__
    surfaces the failure at the use-site, not at module-load.
    """
    if requests is None:
        raise RuntimeError(
            "cluster_harness.DropletHarness requires the 'requests' "
            "package. Install with: uv add requests"
        )


from agent.runtime.node_runtime import Node, NodeEndpoint, NodeIdentity, generate_keypair
from agent.runtime.inter_node_transport import (
    LoopbackBackend,
    TransportBackend,
)

# ---------------------------------------------------------------------------
# DigitalOcean REST API config
# ---------------------------------------------------------------------------

DO_API_BASE: str = "https://api.digitalocean.com/v2"

# Defaults for droplet provisioning — all overridable via ClusterConfig.
DEFAULT_DO_REGION: str = "nyc3"
DEFAULT_DROPLET_SIZE: str = "s-1vcpu-1gb"   # $6/mo, 1 vCPU, 1 GB RAM
DEFAULT_DROPLET_IMAGE: str = "ubuntu-22-04-x64"

# How long (seconds) to wait for a DO droplet to reach "active" status.
DROPLET_ACTIVE_TIMEOUT_SECONDS: float = 300.0

# DO API poll interval (seconds).
DROPLET_POLL_INTERVAL_SECONDS: float = 5.0


def _read_do_token() -> str:
    """
    Read the DigitalOcean API token.

    Resolution order:
      1. DIGITALOCEAN_API_TOKEN env var.
      2. agent/secrets/digitalocean.api_token relative to project root.

    Raises RuntimeError if neither source is available.
    """
    token = os.environ.get("DIGITALOCEAN_API_TOKEN")
    if token:
        return token.strip()

    # Walk up from this file to the project root (where agent/ lives).
    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "agent" / "secrets" / "digitalocean.api_token"
        if candidate.exists():
            return candidate.read_text().strip()

    raise RuntimeError(
        "DigitalOcean API token not found. Set DIGITALOCEAN_API_TOKEN env var "
        "or write the token to agent/secrets/digitalocean.api_token."
    )


# ---------------------------------------------------------------------------
# Deployment parameters
# ---------------------------------------------------------------------------

# Maximum time (seconds) to wait for a node to reach ACTIVE state.
NODE_STARTUP_TIMEOUT_SECONDS: float = 30.0

# How often (seconds) to poll for node state transitions.
POLL_INTERVAL_SECONDS: float = 0.5

# Snapshot staleness threshold (seconds): re-fetch if older than this.
SNAPSHOT_STALENESS_SECONDS: float = 5.0

# Minimum node count for BFT operation (S5a/INV-2: n >= 3f+1; f=1 → n=4).
BFT_MINIMUM_NODES: int = 4

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


class NodeState(Enum):
    STARTING = auto()
    ACTIVE = auto()
    DEPARTING = auto()
    UNREACHABLE = auto()


@dataclass(frozen=True)
class NodeStatus:
    """Per-node status entry in ClusterSnapshot (FR53)."""

    node_id: str
    endpoint: NodeEndpoint
    state: NodeState
    last_seen: int  # unix timestamp (ms)


@dataclass(frozen=True)
class ClusterSnapshot:
    """
    Read-only cluster state snapshot (FR53, INV-S7c-4, AR9).

    Carries no mechanism for the reader to issue commands to nodes.
    No setters, no send methods, no quorum-control references.
    """

    nodes: tuple[NodeStatus, ...]  # frozen tuple enforces immutability
    taken_at: int                   # unix timestamp (ms)
    quorum_size: int                # S5a QuorumSize(n).quorum_threshold
    fault_budget: int               # S5a QuorumSize(n).fault_budget

    # AR9: intentionally no control methods here.


@dataclass
class ClusterConfig:
    """
    Harness configuration passed to provision_cluster (FR52).

    backend: "loopback" | "droplet"
    node_count: int — must be >= BFT_MINIMUM_NODES for BFT operation (FR52).
    region, droplet_size, image: droplet backend only.
    """

    backend: str                    # "loopback" | "droplet"
    node_count: int                 # n
    region: Optional[str] = None   # droplet backend
    droplet_size: Optional[str] = None  # droplet backend
    image: Optional[str] = None    # droplet backend
    allow_non_bft: bool = False     # allow n < 4 for explicit test deployments


# ---------------------------------------------------------------------------
# HarnessBackend (abstract)
# ---------------------------------------------------------------------------


class HarnessBackend(ABC):
    """
    Abstract cluster management interface (FR46).

    Consumer code MUST depend only on HarnessBackend — not on any
    backend-specific type (INV-S7b-5 applies at the harness level too).

    AR9 ENFORCEMENT NOTE: This class intentionally exposes no method
    that, after provision_cluster() returns, can alter quorum state.
    Do NOT add inject_vote, force_wind_down, override_quorum, or any
    equivalent API to this class or any subclass.
    """

    @abstractmethod
    def provision_cluster(
        self,
        n: int,
        config: ClusterConfig,
        *,
        allow_non_bft: bool = False,
    ) -> list[NodeEndpoint]:
        """
        Provision a cluster of n nodes (FR52).

        Validates n >= BFT_MINIMUM_NODES unless allow_non_bft=True.
        Executes SSH key lifecycle (droplet backend, FR47-FR51).
        Returns all NodeEndpoints when all nodes report ACTIVE.

        MUST NOT return before all nodes are in ACTIVE state.
        """
        ...

    @abstractmethod
    def teardown_cluster(self) -> None:
        """
        Tear down the cluster (NFR-S7c-2).

        MUST NOT return before all resources are released:
        - loopback: all node processes terminated.
        - droplet: all droplets destroyed + SSH key revoked from DO.
        """
        ...

    @abstractmethod
    def observe_cluster(self) -> ClusterSnapshot:
        """
        Return a current read-only snapshot of cluster state (FR53).

        INV-S7c-4: the returned ClusterSnapshot carries no control paths.
        AR9: the harness MUST NOT alter quorum state as a side effect.
        """
        ...


# ---------------------------------------------------------------------------
# Quorum size helper (mirrors S5a's QuorumSize interface)
# ---------------------------------------------------------------------------


def _quorum_params(n: int) -> tuple[int, int]:
    """
    Compute (quorum_threshold, fault_budget) for n nodes.

    BFT: n >= 3f+1; f = (n-1) // 3.
    quorum_threshold = 2f + 1 (simple majority over fault budget).
    """
    f = (n - 1) // 3
    quorum_threshold = 2 * f + 1
    return quorum_threshold, f


# ---------------------------------------------------------------------------
# LoopbackHarness — N node processes on the harness host
# ---------------------------------------------------------------------------


def _node_worker(
    state_dir: str,
    node_index: int,
    address: str,
    peer_addresses: list[str],
    ready_event_path: str,
) -> None:
    """
    Worker function run in a subprocess for each loopback node (FR45).

    Creates a Node, joins the cluster with the given peers, then signals
    readiness by writing to ready_event_path.
    """
    state_path = Path(state_dir) / f"node_{node_index}.json"
    node = Node(state_path=state_path, address=address)

    # Build peer endpoints from addresses provided by the harness.
    # peer_addresses are "node_id:address" strings.
    peers: list[NodeEndpoint] = []
    for peer_str in peer_addresses:
        parts = peer_str.split(":", 1)
        if len(parts) == 2:
            peers.append(NodeEndpoint(node_id=parts[0], address=parts[1]))

    node.join_cluster(peers)

    # Signal readiness by writing a sentinel file.
    with open(ready_event_path, "w") as f:
        f.write(f"{node.get_identity().node_id}:{address}")

    # Keep the process alive until the state file is removed by teardown.
    while state_path.exists():
        time.sleep(0.5)


class LoopbackHarness(HarnessBackend):
    """
    Loopback cluster harness: N node processes on the harness host (FR46).

    No SSH key lifecycle. Each node binds a local port.
    NodeEndpoint.address = "127.0.0.1:{port}".

    Used for development, integration testing, and single-machine
    simulation. INV-S7c-1: The harness process is NOT a quorum node.
    """

    def __init__(self, state_dir: Optional[Path] = None) -> None:
        self._state_dir: Path = state_dir or Path("/tmp/reflect-loopback-harness")
        self._state_dir.mkdir(parents=True, exist_ok=True)
        self._processes: list[multiprocessing.Process] = []
        self._endpoints: list[NodeEndpoint] = []
        self._node_statuses: dict[str, NodeStatus] = {}
        self._provisioned: bool = False
        self._last_snapshot_at: int = 0

    def provision_cluster(
        self,
        n: int,
        config: ClusterConfig,
        *,
        allow_non_bft: bool = False,
    ) -> list[NodeEndpoint]:
        """
        Provision n loopback node processes (FR52).

        Refuses n < BFT_MINIMUM_NODES unless allow_non_bft=True.
        MUST NOT return until all nodes are in ACTIVE state (FR52d).
        INV-S7c-1: harness host not listed in returned endpoints.
        NFR-S7c-1: refused if already provisioned.
        """
        # NFR-S7c-1: refuse double-provision.
        if self._provisioned:
            if self._endpoints:
                return list(self._endpoints)
            raise RuntimeError(
                "provision_cluster called on an already-provisioned cluster. "
                "Call teardown_cluster() first."
            )

        # FR52: validate n >= BFT_MINIMUM_NODES.
        _effective_allow_non_bft = allow_non_bft or config.allow_non_bft
        if n < BFT_MINIMUM_NODES and not _effective_allow_non_bft:
            raise ValueError(
                f"provision_cluster requires n >= {BFT_MINIMUM_NODES} for BFT "
                f"operation (S5a/INV-2). Got n={n}. Pass allow_non_bft=True "
                f"for explicit non-BFT test deployments (FR52)."
            )

        base_port = 17000
        node_ids: list[str] = []
        addresses: list[str] = []

        # Pre-create node state files to capture node_ids before forking.
        nodes: list[Node] = []
        for i in range(n):
            state_path = self._state_dir / f"node_{i}.json"
            address = f"127.0.0.1:{base_port + i}"
            node = Node(state_path=state_path, address=address)
            node_ids.append(node.get_identity().node_id)
            addresses.append(address)
            nodes.append(node)

        # Build peer address strings: "node_id:address"
        all_peer_strings = [f"{nid}:{addr}" for nid, addr in zip(node_ids, addresses)]

        # Spawn processes (INV-S7c-1: harness host not a node).
        ready_paths: list[str] = []
        for i in range(n):
            ready_path = str(self._state_dir / f"node_{i}.ready")
            # Peers for node i = all nodes except itself.
            peer_strings = [s for j, s in enumerate(all_peer_strings) if j != i]
            proc = multiprocessing.Process(
                target=_node_worker,
                args=(
                    str(self._state_dir),
                    i,
                    addresses[i],
                    peer_strings,
                    ready_path,
                ),
                daemon=True,
            )
            proc.start()
            self._processes.append(proc)
            ready_paths.append(ready_path)

        # FR52d: wait until all nodes signal ACTIVE.
        deadline = time.monotonic() + NODE_STARTUP_TIMEOUT_SECONDS
        endpoints: list[NodeEndpoint] = []
        for i, (node_id, address, ready_path) in enumerate(
            zip(node_ids, addresses, ready_paths)
        ):
            while not Path(ready_path).exists():
                if time.monotonic() > deadline:
                    raise TimeoutError(
                        f"Node {i} (node_id={node_id}) did not become ACTIVE "
                        f"within {NODE_STARTUP_TIMEOUT_SECONDS}s."
                    )
                time.sleep(POLL_INTERVAL_SECONDS)

            endpoint = NodeEndpoint(node_id=node_id, address=address)
            endpoints.append(endpoint)
            self._node_statuses[node_id] = NodeStatus(
                node_id=node_id,
                endpoint=endpoint,
                state=NodeState.ACTIVE,
                last_seen=int(time.time() * 1000),
            )

        self._endpoints = endpoints
        self._provisioned = True
        return list(endpoints)

    def teardown_cluster(self) -> None:
        """
        Terminate all node processes and clean up state (NFR-S7c-2).

        MUST NOT return until all processes are dead and state files removed.
        AR9: No quorum-control commands are issued here; nodes are terminated
        at the OS process level (loopback exception per spec AR9 footnote).
        """
        for proc in self._processes:
            if proc.is_alive():
                proc.terminate()
        for proc in self._processes:
            proc.join(timeout=5.0)
            if proc.is_alive():
                proc.kill()

        # Remove state files — this also signals node_worker loops to exit.
        for i in range(len(self._endpoints)):
            state_path = self._state_dir / f"node_{i}.json"
            ready_path = self._state_dir / f"node_{i}.ready"
            state_path.unlink(missing_ok=True)
            ready_path.unlink(missing_ok=True)

        self._processes = []
        self._endpoints = []
        self._node_statuses = {}
        self._provisioned = False

    def observe_cluster(self) -> ClusterSnapshot:
        """
        Return a read-only snapshot of cluster state (FR53, INV-S7c-4).

        AR9: This method reads state; it issues no commands.
        """
        n = len(self._endpoints)
        quorum_size, fault_budget = _quorum_params(n) if n > 0 else (0, 0)
        now_ms = int(time.time() * 1000)

        # Refresh liveness: check process health.
        for i, proc in enumerate(self._processes):
            if i < len(self._endpoints):
                ep = self._endpoints[i]
                state = NodeState.ACTIVE if proc.is_alive() else NodeState.UNREACHABLE
                self._node_statuses[ep.node_id] = NodeStatus(
                    node_id=ep.node_id,
                    endpoint=ep,
                    state=state,
                    last_seen=now_ms if proc.is_alive() else
                              self._node_statuses.get(ep.node_id, NodeStatus(
                                  ep.node_id, ep, NodeState.UNREACHABLE, 0
                              )).last_seen,
                )

        return ClusterSnapshot(
            nodes=tuple(self._node_statuses.values()),
            taken_at=now_ms,
            quorum_size=quorum_size,
            fault_budget=fault_budget,
        )


# ---------------------------------------------------------------------------
# DropletHarness — N DigitalOcean droplets (stub + SSH key lifecycle)
# ---------------------------------------------------------------------------


class DropletHarness(HarnessBackend):
    """
    DigitalOcean droplet cluster harness (FR46, droplet backend).

    Uses the DO REST API directly (api.digitalocean.com/v2).
    Token is read from DIGITALOCEAN_API_TOKEN env var or from
    agent/secrets/digitalocean.api_token (gitignored).

    SSH-key lifecycle (FR47-FR51):
      1. _generate_ssh_keypair() — Ed25519 in OpenSSH format
      2. _register_ssh_key_with_do() → key_id           [FR48]
      3. _create_droplet(key_id=key_id, ...) × N         [FR49, FR51]
      4. _deploy_to_droplet() — SSH bootstrap_node()     [FR-BOOTSTRAP]
      5. teardown: _destroy_all_droplets() + _revoke_ssh_key() [FR50]

    FR51 HARD ORDERING GUARD: `_ssh_key_id` MUST be set (not None)
    before any droplet create call. `_assert_ssh_key_registered()`
    runs at the start of every `_create_droplet()` call.

    INV-S7c-1: Harness host is NOT a quorum node (never listed in
    returned NodeEndpoint list).
    AR9: No runtime control path post-bootstrap. This class exposes no
    method that can alter quorum state after provision_cluster returns.
    """

    def __init__(
        self,
        ssh_key_state_path: Optional[Path] = None,
        anthropic_api_key: Optional[str] = None,
    ) -> None:
        # DropletHarness needs the `requests` package (DO REST API).
        # LoopbackHarness does not — that's why this check is here and
        # not at module-load time. See module-top `_require_requests`.
        _require_requests()
        self._endpoints: list[NodeEndpoint] = []
        self._provisioned: bool = False
        self._ssh_key_id: Optional[str] = None     # FR48: must be set before FR49
        self._ssh_pub_bytes: Optional[bytes] = None
        self._ssh_priv_bytes: Optional[bytes] = None
        self._ssh_key_state_path = ssh_key_state_path or Path(
            "/tmp/reflect-droplet-harness-ssh.json"
        )
        # Track provisioned droplet IDs for teardown.
        self._droplet_ids: list[int] = []
        # Required for _deploy_to_droplet() — passed to bootstrap_node() on
        # the remote host. Falls back to ANTHROPIC_API_KEY env var at deploy.
        self._anthropic_api_key: Optional[str] = anthropic_api_key

    # ------------------------------------------------------------------
    # SSH key lifecycle (FR47-FR51)
    # ------------------------------------------------------------------

    def _generate_ssh_keypair(self) -> None:
        """
        FR47: Generate a fresh SSH keypair for this cluster lifecycle.

        Distinct from S7a node keypairs (DER format, message signing).
        This key gives the harness shell access to droplets for bootstrap
        deployment — it must be in OpenSSH format for DO registration and
        `ssh -i` usage.
        """
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PrivateKey,
        )
        from cryptography.hazmat.primitives.serialization import (
            Encoding,
            NoEncryption,
            PrivateFormat,
            PublicFormat,
        )

        private_key = Ed25519PrivateKey.generate()
        public_key = private_key.public_key()

        # Build OpenSSH wire-format public key: <type_len><type><key_len><raw>
        pub_raw = public_key.public_bytes(Encoding.Raw, PublicFormat.Raw)
        key_type = b"ssh-ed25519"
        key_blob = (
            len(key_type).to_bytes(4, "big") + key_type
            + len(pub_raw).to_bytes(4, "big") + pub_raw
        )
        self._ssh_pub_bytes = (
            b"ssh-ed25519 "
            + base64.b64encode(key_blob)
            + b" reflect-cluster-harness"
        )

        # OpenSSH PEM private key — required format for `ssh -i` flag.
        self._ssh_priv_bytes = private_key.private_bytes(
            Encoding.PEM, PrivateFormat.OpenSSH, NoEncryption()
        )
        self._ssh_key_id = None  # not yet registered with DO

    def _register_ssh_key_with_do(self) -> str:
        """
        FR48: Register the SSH public key with DigitalOcean REST API.

        Returns key_id (str). MUST complete before any droplet create call
        (FR51 ordering invariant).

        Calls POST /v2/account/keys with the harness SSH public key.
        Idempotent: if a key with the same fingerprint already exists,
        the existing key_id is returned.
        """
        if not self._ssh_pub_bytes:
            raise RuntimeError(
                "_register_ssh_key_with_do: public key not generated. "
                "Call _generate_ssh_keypair() first."
            )

        token = _read_do_token()
        pub_key_str = (
            self._ssh_pub_bytes.decode()
            if isinstance(self._ssh_pub_bytes, bytes)
            else self._ssh_pub_bytes
        )

        resp = requests.post(
            f"{DO_API_BASE}/account/keys",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json={"name": "reflect-cluster-harness", "public_key": pub_key_str},
            timeout=30,
        )

        # 201 = created; 422 with "SSH Key is already in use" = duplicate key.
        if resp.status_code == 422:
            data = resp.json()
            errors = data.get("message", "")
            if "already in use" in errors or "already exists" in errors:
                # Fetch existing key by fingerprint.
                existing = self._find_ssh_key_by_pub(token, pub_key_str)
                if existing:
                    return str(existing)
            resp.raise_for_status()
        else:
            resp.raise_for_status()

        return str(resp.json()["ssh_key"]["id"])

    def _find_ssh_key_by_pub(self, token: str, pub_key_str: str) -> Optional[int]:
        """
        Return the DO key ID for an already-registered public key, or None.
        """
        # Compare by the base64 body of the public key (fingerprint-independent).
        pub_body = pub_key_str.split()[1] if " " in pub_key_str else pub_key_str
        resp = requests.get(
            f"{DO_API_BASE}/account/keys",
            headers={"Authorization": f"Bearer {token}"},
            timeout=30,
        )
        resp.raise_for_status()
        for key in resp.json().get("ssh_keys", []):
            existing_body = key.get("public_key", "").split()
            if len(existing_body) >= 2 and existing_body[1] == pub_body:
                return key["id"]
        return None

    def _assert_ssh_key_registered(self) -> None:
        """
        FR51 ORDERING GUARD: Refuse any droplet create call if
        _ssh_key_id is not set.

        This is the hard ordering invariant. A droplet create call
        issued before ssh_key register completes is non-conformant.
        """
        if not self._ssh_key_id:
            raise RuntimeError(
                "FR51 ORDERING VIOLATION: Cannot create a droplet without a "
                "registered SSH key. Call _register_ssh_key_with_do() first and "
                "ensure it returns a key_id before any droplet create call. "
                "A droplet created without an SSH key falls back to emailed root "
                "credentials — a prohibited insecure path. (FR49, FR51)"
            )

    def _create_droplet(self, index: int, config: ClusterConfig) -> NodeEndpoint:
        """
        FR49: Create one DO droplet, referencing self._ssh_key_id.

        FR51 guard runs first — raises if key not yet registered.
        Polls until the droplet reaches "active" status (DO creation
        is asynchronous). Returns a NodeEndpoint with the public IP and
        the transport port (REFLECT_TRANSPORT_PORT = 9400).
        """
        self._assert_ssh_key_registered()  # FR51 — MUST run before any create

        token = _read_do_token()
        region = config.region or DEFAULT_DO_REGION
        size = config.droplet_size or DEFAULT_DROPLET_SIZE
        image = config.image or DEFAULT_DROPLET_IMAGE
        name = f"reflect-node-{index:02d}"

        resp = requests.post(
            f"{DO_API_BASE}/droplets",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            json={
                "name": name,
                "region": region,
                "size": size,
                "image": image,
                "ssh_keys": [int(self._ssh_key_id)],  # type: ignore[arg-type]
            },
            timeout=30,
        )
        resp.raise_for_status()
        droplet_id: int = resp.json()["droplet"]["id"]
        self._droplet_ids.append(droplet_id)

        # DO droplet creation is async — poll until active + has public IP.
        ip_address = self._wait_for_droplet_active(droplet_id, token)

        # node_id is a harness-assigned placeholder; the reflect runtime
        # assigns its real node_id during bootstrap. The transport port
        # is the REFLECT_TRANSPORT_PORT default (spec S7b FR60).
        node_id = f"droplet-{droplet_id}"
        return NodeEndpoint(node_id=node_id, address=f"{ip_address}:9400")

    def _wait_for_droplet_active(
        self,
        droplet_id: int,
        token: str,
        timeout: float = DROPLET_ACTIVE_TIMEOUT_SECONDS,
    ) -> str:
        """
        Poll GET /v2/droplets/{id} until status == "active" and a public
        IPv4 address is assigned. Returns the public IPv4 address string.
        """
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            resp = requests.get(
                f"{DO_API_BASE}/droplets/{droplet_id}",
                headers={"Authorization": f"Bearer {token}"},
                timeout=30,
            )
            resp.raise_for_status()
            droplet = resp.json()["droplet"]
            if droplet.get("status") == "active":
                for net in droplet.get("networks", {}).get("v4", []):
                    if net.get("type") == "public":
                        return net["ip_address"]
            time.sleep(DROPLET_POLL_INTERVAL_SECONDS)

        raise TimeoutError(
            f"Droplet {droplet_id} did not reach active+IP "
            f"within {timeout}s."
        )

    def _revoke_ssh_key(self) -> None:
        """
        FR50a: Revoke the SSH public key from DigitalOcean REST API.

        Calls DELETE /v2/account/keys/{key_id}. 204 = deleted;
        404 = already gone — both are acceptable.
        No-op if no key_id is set.
        """
        if not self._ssh_key_id:
            return

        token = _read_do_token()
        resp = requests.delete(
            f"{DO_API_BASE}/account/keys/{self._ssh_key_id}",
            headers={"Authorization": f"Bearer {token}"},
            timeout=30,
        )
        if resp.status_code not in (204, 404):
            resp.raise_for_status()

    def _destroy_all_droplets(self) -> None:
        """
        Destroy all provisioned droplets via DELETE /v2/droplets/{id}.

        204 = deleted; 404 = already gone — both are acceptable.
        Clears self._droplet_ids when complete.
        """
        if not self._droplet_ids:
            return

        token = _read_do_token()
        for droplet_id in list(self._droplet_ids):
            resp = requests.delete(
                f"{DO_API_BASE}/droplets/{droplet_id}",
                headers={"Authorization": f"Bearer {token}"},
                timeout=30,
            )
            if resp.status_code not in (204, 404):
                resp.raise_for_status()
        self._droplet_ids = []

    def _delete_local_ssh_key(self) -> None:
        """FR50b: Delete the local SSH private key from harness state."""
        self._ssh_priv_bytes = None
        self._ssh_pub_bytes = None
        self._ssh_key_id = None
        if self._ssh_key_state_path.exists():
            self._ssh_key_state_path.unlink()

    def _deploy_to_droplet(
        self,
        endpoint: NodeEndpoint,
        api_key: Optional[str],
        node_name: str = "reflect-node",
    ) -> None:
        """
        §Bootstrap Procedure deploy step (S7c).

        SSHes to the provisioned droplet and pipes
        cluster_node_bootstrap.py via stdin — the remote-invocation
        path documented in the bootstrap module. This method MUST NOT
        re-derive the bootstrap sequence; cluster_node_bootstrap.py
        (code.cluster-node-bootstrap~954661be) is the authoritative
        implementation of the §Bootstrap Procedure.

        Requires self._ssh_priv_bytes to be set by
        _generate_ssh_keypair() before this is called.

        api_key is passed as ANTHROPIC_API_KEY on the remote command
        line. If None, falls back to the harness host's environment
        variable — cluster_node_bootstrap.py reads the env fallback
        internally.

        Raises RuntimeError on bootstrap failure or missing SSH key.
        """
        if not self._ssh_priv_bytes:
            raise RuntimeError(
                "Cannot deploy: SSH private key not available. "
                "_generate_ssh_keypair() must be called before "
                "_deploy_to_droplet()."
            )

        bootstrap_script = Path(__file__).parent / "cluster_node_bootstrap.py"
        if not bootstrap_script.exists():
            raise RuntimeError(
                f"Bootstrap script not found: {bootstrap_script}. "
                "cluster_node_bootstrap.py must be adjacent to "
                "cluster_harness.py in the same package directory."
            )

        # Extract host; endpoint.address may include a port ("1.2.3.4:22").
        host = endpoint.address.split(":")[0]

        with tempfile.NamedTemporaryFile(
            mode="wb", suffix=".pem", delete=False
        ) as kf:
            kf.write(self._ssh_priv_bytes)
            key_path = kf.name

        try:
            os.chmod(key_path, 0o600)
            env_prefix = (
                f"ANTHROPIC_API_KEY={api_key} " if api_key else ""
            )
            cmd = [
                "ssh",
                "-o", "StrictHostKeyChecking=no",
                "-i", key_path,
                f"root@{host}",
                f"{env_prefix}python3 - {node_name}",
            ]
            with open(bootstrap_script, "rb") as bf:
                result = subprocess.run(
                    cmd,
                    stdin=bf,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
            if result.returncode != 0:
                raise RuntimeError(
                    f"bootstrap_node() failed on {endpoint.node_id} "
                    f"at {host} (exit {result.returncode}): "
                    f"{result.stderr.strip()}"
                )
        finally:
            os.unlink(key_path)

    # ------------------------------------------------------------------
    # HarnessBackend interface
    # ------------------------------------------------------------------

    def provision_cluster(
        self,
        n: int,
        config: ClusterConfig,
        *,
        allow_non_bft: bool = False,
    ) -> list[NodeEndpoint]:
        """
        FR52: Provision N DO droplets.

        SSH key lifecycle (FR47-FR51) runs first, then droplet creates.
        FR51 ordering guard in _create_droplet prevents droplets without keys.
        """
        if self._provisioned:
            if self._endpoints:
                return list(self._endpoints)
            raise RuntimeError("Already provisioned. Call teardown_cluster() first.")

        _effective_allow_non_bft = allow_non_bft or config.allow_non_bft
        if n < BFT_MINIMUM_NODES and not _effective_allow_non_bft:
            raise ValueError(
                f"provision_cluster requires n >= {BFT_MINIMUM_NODES} for BFT. "
                f"Got n={n}. (FR52)"
            )

        # FR47: Generate fresh SSH keypair (one per lifecycle).
        self._generate_ssh_keypair()

        # FR48: Register with DO. MUST complete before any droplet create.
        key_id = self._register_ssh_key_with_do()  # sets self._ssh_key_id
        self._ssh_key_id = key_id

        # FR49 + FR51: Create each droplet (guard runs in _create_droplet).
        # After creation, run the §Bootstrap Procedure via SSH
        # (S7c: _deploy_to_droplet MUST call bootstrap_node() via
        # cluster_node_bootstrap.py, not re-derive the sequence).
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        endpoints: list[NodeEndpoint] = []
        for i in range(n):
            endpoint = self._create_droplet(i, config)  # raises if no key_id
            node_name = f"reflect-node-{i:02d}"
            self._deploy_to_droplet(endpoint, api_key=api_key, node_name=node_name)
            endpoints.append(endpoint)

        self._endpoints = endpoints
        self._provisioned = True
        return list(endpoints)

    def teardown_cluster(self) -> None:
        """
        FR50 + NFR-S7c-2: Destroy droplets, revoke SSH key, delete local copy.

        MUST NOT return until all resources are released.
        Droplets are destroyed before key revocation so no key-less
        droplets are left running.
        """
        # Destroy provisioned droplets first.
        self._destroy_all_droplets()

        # FR50a: revoke DO SSH key.
        self._revoke_ssh_key()

        # FR50b: delete local private key (INV-S7c-3).
        self._delete_local_ssh_key()

        self._endpoints = []
        self._provisioned = False

    def observe_cluster(self) -> ClusterSnapshot:
        """
        FR53: Return a read-only cluster snapshot (INV-S7c-4, AR9).

        Queries DO API for each droplet's current status and maps it to
        NodeState. Falls back to UNREACHABLE for any droplet that cannot
        be reached or is in an unexpected state.
        AR9: This method only reads state — it issues no commands.
        """
        n = len(self._endpoints)
        quorum_size, fault_budget = _quorum_params(n) if n > 0 else (0, 0)
        now_ms = int(time.time() * 1000)

        node_statuses: list[NodeStatus] = []
        if self._droplet_ids and self._endpoints:
            try:
                token = _read_do_token()
            except RuntimeError:
                token = None  # token unavailable — fall back to UNREACHABLE

            for ep, droplet_id in zip(self._endpoints, self._droplet_ids):
                state = NodeState.UNREACHABLE
                if token:
                    try:
                        resp = requests.get(
                            f"{DO_API_BASE}/droplets/{droplet_id}",
                            headers={"Authorization": f"Bearer {token}"},
                            timeout=10,
                        )
                        if resp.ok:
                            do_status = resp.json()["droplet"].get("status")
                            state = (
                                NodeState.ACTIVE
                                if do_status == "active"
                                else NodeState.UNREACHABLE
                            )
                    except Exception:  # noqa: BLE001
                        pass  # network error → UNREACHABLE

                node_statuses.append(NodeStatus(
                    node_id=ep.node_id,
                    endpoint=ep,
                    state=state,
                    last_seen=now_ms,
                ))
        else:
            # No droplets provisioned yet; return empty snapshot.
            pass

        return ClusterSnapshot(
            nodes=tuple(node_statuses),
            taken_at=now_ms,
            quorum_size=quorum_size,
            fault_budget=fault_budget,
        )
