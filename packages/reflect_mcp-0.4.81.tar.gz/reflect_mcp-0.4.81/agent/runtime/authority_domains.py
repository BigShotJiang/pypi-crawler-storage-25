# @scry.entry
# id: code.authority-domains~4a8f1c92
# kind: code
# status: active
# weight: 0.9
# tags: ["scope:substrate", "substrate", "topic:authority", "authority",
#        "topic:hooks", "hooks", "topic:live-key-gate", "live-key-gate",
#        "topic:wake-enable-gate", "wake-enable-gate", "kind:code", "code",
#        "G1", "G4", "authority_domains", "live-stripe-key", "paywall",
#        "SANCTIONED_PAYMENTS_TRACK", "G1-blocked", "G4-blocked",
#        "hooks-companion", "authority.md"]
# summary: >
#   Machine-readable constants for the authority.md constitutional doc.
#   Peer file of authority.md (originator-created). Defines G1 live-key
#   access constants (SANCTIONED_PAYMENTS_TRACK, LIVE_KEY_PATH_PATTERNS,
#   LIVE_KEY_CONTENT_PATTERNS, G1_BLOCKED_DEPLOY_INDICATORS) and G4
#   wake/enable authority constants (G4_BLOCKED_BASH_PATTERNS).
#   Import from hooks.py only; do not hard-code these elsewhere.
#   Also: authority_domains, G1 gate, G4 gate, live Stripe key, sanctioned
#   track, hooks constants, authority.md companion, PAYWALL_ENABLED,
#   wrangler deploy, reflect wake start, reflect track enable.
# rationale: >
#   Without this, hooks.py hard-codes authority constants that should be
#   maintained alongside authority.md. Centralizing constants here means
#   updating authority.md is paired with a single file change, not a grep
#   across hooks.py. P8 paywall incident root cause: no live-key gate.
# applies: >
#   reviewing G1 live-key gate configuration, auditing which track is
#   sanctioned for live Stripe key access, checking G4 wake/enable gate
#   patterns, updating authority constants when authority.md changes
# seeded_questions:
#   - "Which track is sanctioned for live Stripe key access?"
#   - "What paths trigger the G1 gate?"
#   - "What Bash patterns trigger the G4 gate?"
#   - "authority_domains.py G1 G4 hooks constants"
#   - "SANCTIONED_PAYMENTS_TRACK live key gate"
# @scry.entry.end

# authority_domains.py — peer of authority.md
# Edit this file when authority.md changes, and vice versa.
# Originator-maintained: treat changes with same gravity as hooks.py.
#
# This file is imported by hooks.py. Do not hard-code these constants
# anywhere else — a single source of truth for authority domain constants.


# ---------------------------------------------------------------------------
# G1 — Live Payment Credentials
# ---------------------------------------------------------------------------

# The one track permitted to read live Stripe key files.
# Originator confirmed Option A (2026-05-17): rtai-payments is the sole
# sanctioned consumer of agent/secrets/stripe.reflecttech.* key files.
SANCTIONED_PAYMENTS_TRACK: str = "rtai-payments"

# Path patterns that trigger G1 checks (any substring in a Read path).
LIVE_KEY_PATH_PATTERNS: tuple[str, ...] = (
    "agent/secrets/stripe.",
)

# String patterns in file content that indicate live key material.
LIVE_KEY_CONTENT_PATTERNS: tuple[str, ...] = (
    "sk_live_",
    "pk_live_",
)

# G1 — Bash command fragments that indicate deploying live payment/paywall code.
# Blocked for all tracks (including sanctioned) to prevent live-deploy without
# originator authorization.
G1_BLOCKED_DEPLOY_INDICATORS: tuple[str, ...] = (
    "PAYWALL_ENABLED=true",
    "wrangler deploy",  # any wrangler deploy while live keys present
)


# ---------------------------------------------------------------------------
# G4 — Wake and Enable Authority
# ---------------------------------------------------------------------------

# Bash command fragments that trigger the G4 block.
# Wakes may not start or enable other tracks directly.
# Correct pattern: queue work to the target's inbox; originator enables.
G4_BLOCKED_BASH_PATTERNS: tuple[str, ...] = (
    "reflect wake start",
    "reflect track enable",
)
