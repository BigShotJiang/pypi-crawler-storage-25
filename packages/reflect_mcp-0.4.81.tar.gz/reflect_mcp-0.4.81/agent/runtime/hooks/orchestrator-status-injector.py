#!/usr/bin/env python3
"""Orchestrator Status Channel — UserPromptSubmit hook.

Design: agent/design/design.orchestrator-status-channel~edc8302c.md
DRs: DR8–DR14

Fires on every UserPromptSubmit in the Claude Code CLI session. Reads
per-track status.yaml files, diffs against a snapshot, and injects a
concise system block only when there is news (state change, new error,
progress advance, hung track, or inbox count increase).

Silent when all tracks are healthy and unchanged.

Exit codes: always 0 — hook failure must never block the user's prompt.
Output: injected system block on stdout (or nothing if no news).
"""

import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import yaml

# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------

def _resolve_project_root() -> Path:
    """Resolve project root: CLAUDE_PROJECT_DIR env var, else __file__ two levels up."""
    env = os.environ.get("CLAUDE_PROJECT_DIR")
    if env:
        return Path(env)
    # __file__ = agent/runtime/hooks/orchestrator-status-injector.py
    # → agent/runtime/hooks/ → agent/runtime/ → agent/ → project_root/
    return Path(__file__).parent.parent.parent.parent


PROJECT_ROOT = _resolve_project_root()
TRACKS_ROOT = PROJECT_ROOT / "agent" / "runtime" / "tracks"
SNAPSHOT_PATH = PROJECT_ROOT / "agent" / "runtime" / "orchestrator-status.last-snapshot.json"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _read_json(path: Path) -> dict | None:
    """Read and parse a JSON file. Returns None on missing or malformed."""
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def _read_yaml(path: Path) -> dict | None:
    """Read and parse a YAML file. Returns None on missing or malformed."""
    if not path.exists():
        return None
    try:
        loaded = yaml.safe_load(path.read_text())
        return loaded if isinstance(loaded, dict) else None
    except Exception:
        return None


def _write_atomic(path: Path, data: dict) -> None:
    """Atomic write via temp+rename."""
    tmp = path.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(data, indent=2))
        os.replace(str(tmp), str(path))
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def _count_originator_inbox() -> int:
    """Count unread .md files in tracks/originator/inbox/ (P9 layout).

    Returns 0 if the directory doesn't exist (pre-P9 or no originator track).
    """
    inbox = TRACKS_ROOT / "originator" / "inbox"
    if not inbox.is_dir():
        return 0
    consumed = {p.name for p in (inbox / ".consumed").glob("*.md")} if (inbox / ".consumed").is_dir() else set()
    return sum(1 for p in inbox.glob("*.md") if p.is_file() and p.name not in consumed)


def _minutes_since(iso_ts: str) -> float:
    """Minutes elapsed since an ISO 8601 UTC timestamp string."""
    try:
        dt = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        return (now - dt).total_seconds() / 60.0
    except Exception:
        return 0.0


def _is_wake_driven(track_dir: Path) -> bool:
    """True if this track directory has a wake.md (i.e., is a wake-driven track)."""
    return (track_dir / "wake.md").exists()


# ---------------------------------------------------------------------------
# Current state collection
# ---------------------------------------------------------------------------

def _collect_current_state() -> dict:
    """Read all per-track status.yaml files into a dict keyed by track name."""
    state: dict = {}

    if not TRACKS_ROOT.is_dir():
        return state

    for track_dir in sorted(TRACKS_ROOT.iterdir()):
        if not track_dir.is_dir():
            continue
        track_name = track_dir.name
        if track_name == "originator":
            continue  # human track — has no wake lifecycle
        if not _is_wake_driven(track_dir):
            continue  # skip non-wake dirs

        status_file = track_dir / "status.yaml"
        if not status_file.exists():
            state[track_name] = {"_missing": True}
            continue

        parsed = _read_yaml(status_file)
        if parsed is None:
            state[track_name] = {"_unreadable": True}
        else:
            state[track_name] = parsed

    return state


# ---------------------------------------------------------------------------
# Delta detection (DR10)
# ---------------------------------------------------------------------------

def _compute_deltas(current: dict, snapshot: dict, inbox_count: int, snap_inbox: int) -> list[dict]:
    """Return a list of delta dicts describing what changed.

    Each delta has:
        track: str  (or "originator_inbox" for inbox-count news)
        kind: "state_change" | "new_error" | "progress_advance" | "hung" | "missing" |
              "unreadable" | "inbox_increase"
        current_status: dict
        snapshot_status: dict (may be {})
    """
    deltas = []

    all_tracks = set(current.keys()) | set(snapshot.get("tracks", {}).keys())
    for track in sorted(all_tracks):
        cur = current.get(track, {})
        snap = snapshot.get("tracks", {}).get(track, {})

        # Missing or unreadable — surface once (when it first appears or persists)
        if cur.get("_missing"):
            if not snap.get("_missing"):
                deltas.append({"track": track, "kind": "missing", "cur": cur, "snap": snap})
            continue
        if cur.get("_unreadable"):
            if not snap.get("_unreadable"):
                deltas.append({"track": track, "kind": "unreadable", "cur": cur, "snap": snap})
            continue

        cur_state = cur.get("state")
        snap_state = snap.get("state")

        # State change
        if cur_state != snap_state:
            deltas.append({"track": track, "kind": "state_change", "cur": cur, "snap": snap})
            continue  # state change subsumes progress and error deltas

        # New error (state unchanged but error changed)
        cur_err = cur.get("last_error")
        snap_err = snap.get("last_error")
        if cur_err and cur_err != snap_err:
            deltas.append({"track": track, "kind": "new_error", "cur": cur, "snap": snap})

        # Progress advance (running, current increased)
        if cur_state == "running":
            cur_prog = (cur.get("progress") or {}).get("current")
            snap_prog = (snap.get("progress") or {}).get("current")
            if cur_prog is not None and (snap_prog is None or cur_prog > snap_prog):
                deltas.append({"track": track, "kind": "progress_advance", "cur": cur, "snap": snap})

            # Hung detection: running but updated_at > 15 min ago
            updated_at = cur.get("updated_at")
            if updated_at and _minutes_since(updated_at) > 15:
                # Only surface once (when it transitions from not-hung to hung)
                snap_updated = snap.get("updated_at")
                if not snap_updated or _minutes_since(snap_updated) <= 15:
                    deltas.append({"track": track, "kind": "hung", "cur": cur, "snap": snap})

    # Originator inbox count increased
    if inbox_count > snap_inbox:
        deltas.append({
            "track": "originator_inbox",
            "kind": "inbox_increase",
            "count": inbox_count,
            "prev_count": snap_inbox,
        })

    return deltas


# ---------------------------------------------------------------------------
# Output formatting (DR11, DR12)
# ---------------------------------------------------------------------------

_STATE_EMOJI = {
    "running": "🔄",
    "idle": "✅",
    "unhealthy": "⚠️",
    "stopped": "⚠️",
}

_HUNG_EMOJI = "🔕"
_MISSING_EMOJI = "❓"


def _format_track_line(track: str, status: dict) -> str:
    """One-liner for a track given its current status dict."""
    if status.get("_missing"):
        return f"{_MISSING_EMOJI}  {track}: no status reported"
    if status.get("_unreadable"):
        return f"⚠️  {track}: status unreadable"

    state = status.get("state", "unknown")
    emoji = _STATE_EMOJI.get(state, "❓")

    parts = [f"{emoji}  {track}: {state}"]

    if state == "running":
        # Check hung
        updated = status.get("updated_at")
        if updated and _minutes_since(updated) > 15:
            mins = int(_minutes_since(updated))
            return f"{_HUNG_EMOJI}  {track}: possibly hung (no update for {mins}m)"

        prog = status.get("progress")
        if prog:
            cur = prog.get("current")
            total = prog.get("total")
            label = prog.get("label") or ""
            if total:
                parts.append(f"step {cur}/{total}")
            elif cur is not None:
                parts.append(f"step {cur}")
            if label:
                parts.append(f'"{label}"')

        started = status.get("started_at")
        if started:
            try:
                dt = datetime.fromisoformat(started.replace("Z", "+00:00"))
                parts.append(f"started {dt.strftime('%H:%M')}Z")
            except Exception:
                pass

    elif state in ("idle", "unhealthy", "stopped"):
        last_exit = status.get("last_exit")
        if last_exit and state == "unhealthy":
            parts.append(f"last exit: {last_exit}")
        last_err = status.get("last_error")
        if last_err:
            parts.append(f"error: {last_err[:80]}")
        summary = status.get("last_summary")
        if summary and state == "idle":
            parts.append(f'"{summary[:100]}"')

    return " — ".join(parts[:1]) + (" — " + ", ".join(parts[1:])) if len(parts) > 1 else parts[0]


def _format_output(deltas: list[dict], current_state: dict, inbox_count: int) -> str:
    """Format the injected system block. Hard-capped at ~600 tokens."""
    now_str = _now_iso()
    lines = [f"## Track Status — {now_str}", ""]

    # Priority order: unhealthy/hung/missing → running → idle → inbox
    def sort_key(d: dict):
        kind = d["kind"]
        if kind in ("hung", "missing", "unreadable", "new_error"):
            return (0, d.get("track", ""))
        if kind == "state_change":
            state = d["cur"].get("state", "")
            if state in ("unhealthy", "stopped"):
                return (0, d.get("track", ""))
            if state == "running":
                return (1, d.get("track", ""))
            return (2, d.get("track", ""))
        if kind == "progress_advance":
            return (1, d.get("track", ""))
        if kind == "inbox_increase":
            return (3, "")
        return (2, d.get("track", ""))

    deltas_sorted = sorted(deltas, key=sort_key)

    # Render lines (cap at ~400 chars per line; truncate list at token budget)
    rendered = []
    total_chars = 0
    CHAR_CAP = 2400  # ~600 tokens at ~4 chars/token

    for delta in deltas_sorted:
        if delta["kind"] == "inbox_increase":
            line = f"📬  originator inbox: {delta['count']} unread message(s)"
        else:
            track = delta["track"]
            cur = delta.get("cur") or current_state.get(track, {})
            line = _format_track_line(track, cur)

        if total_chars + len(line) + 1 > CHAR_CAP:
            remaining = len(deltas_sorted) - len(rendered)
            rendered.append(f"…{remaining} more track update(s) — run `reflect track status` for full view")
            break

        rendered.append(line)
        total_chars += len(line) + 1

    lines.extend(rendered)

    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Main hook logic (DR9)
# ---------------------------------------------------------------------------

def main() -> None:
    try:
        # 1. Read current state
        current_state = _collect_current_state()

        # 2. Read snapshot (or empty)
        snapshot_raw = _read_json(SNAPSHOT_PATH)
        if snapshot_raw is None:
            snapshot: dict = {"tracks": {}, "originator_inbox_count": 0}
        elif not isinstance(snapshot_raw, dict):
            # Malformed — log and rebuild
            print("[orchestrator-status] snapshot malformed — rebuilding", file=sys.stderr)
            snapshot = {"tracks": {}, "originator_inbox_count": 0}
        else:
            snapshot = snapshot_raw

        # 3. Count unread originator inbox
        inbox_count = _count_originator_inbox()
        snap_inbox = int(snapshot.get("originator_inbox_count", 0))

        # 4. Compute deltas
        deltas = _compute_deltas(current_state, snapshot, inbox_count, snap_inbox)

        # 5. Update snapshot (always — keeps it fresh)
        new_snapshot = {
            "snapshot_at": _now_iso(),
            "tracks": {
                track: {
                    "state": status.get("state"),
                    "last_exit": status.get("last_exit"),
                    "last_error": status.get("last_error"),
                    "progress": status.get("progress"),
                    "updated_at": status.get("updated_at"),
                    "_missing": status.get("_missing"),
                    "_unreadable": status.get("_unreadable"),
                }
                for track, status in current_state.items()
            },
            "originator_inbox_count": inbox_count,
        }
        try:
            SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
            _write_atomic(SNAPSHOT_PATH, new_snapshot)
        except Exception as e:
            print(f"[orchestrator-status] snapshot write failed: {e}", file=sys.stderr)

        # 6. If no deltas → silent exit
        if not deltas:
            return

        # 7-8. Format and emit
        output = _format_output(deltas, current_state, inbox_count)
        sys.stdout.write(f"<system>\n{output}</system>\n")
        sys.stdout.flush()

    except Exception as e:
        # DR14: hook crash → log to stderr, exit 0, never block user prompt
        print(f"[orchestrator-status] uncaught exception: {e}", file=sys.stderr)
        return


if __name__ == "__main__":
    main()
