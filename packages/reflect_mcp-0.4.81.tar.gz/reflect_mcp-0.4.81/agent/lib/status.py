"""Agent-to-Orchestrator Status Channel — shared write helper.

DR7 from agent/design/design.orchestrator-status-channel~edc8302c.md.

Implements:
- spec.track-status-surface~3f9fe56b (FR1-FR7, INV-CLEAR-ON-BOOT,
  INV-CLEAR-ON-EXIT, INV-ATOMIC-WITH-STATE, INV-WRITER-SINGLE-PATH)
- spec.wake-initiating-message-record~f636f2ed FR1 (schema_version=3
  emitted; initiating_messages populated from the wake-loop's BOOT
  sweep return value via mark_running(track, wake_id, initiating_messages=...))

State serialization: YAML (per memory yaml-for-state-not-json). The
on-disk file is ``status.yaml`` per track; the sidecar lock is
``status.yaml.lock``. Substrate ``.jsonl`` event logs stay JSON.

Usage:
    from agent.lib.status import (
        mark_running, mark_idle, mark_unhealthy, mark_paused,
        update_progress, set_focus, set_plan, set_blocked_on,
        clear_focus, clear_plan, clear_blocked_on, clear_track_status,
    )

Called by:
    - agent/runtime/wake.py: mark_running at wake start; mark_idle /
      mark_unhealthy in supervisor finally.
    - Agent wakes (optionally): update_progress, set_focus, set_plan,
      set_blocked_on for mid-wake declarations.
    - reflect track status CLI / mcp__reflect__track(action="status_set"):
      route through set_focus / set_plan / set_blocked_on.

All writes are atomic via temp+rename. Concurrent writers serialize
on a per-track fcntl.flock so read-modify-write never races.
"""
import fcntl
import os
import pathlib
import sys
from datetime import datetime, timezone
from typing import TypedDict

import yaml

from agent.lib.root import resolve_project_root
from agent.lib.yaml_io import safe_dump  # noqa: F401 (registers representer)

TRACKS_ROOT = resolve_project_root() / "agent" / "runtime" / "tracks"

# Spec FR2: writers under this contract emit schema_version 3.
SCHEMA_VERSION = 3

# Spec FR1: 200-codepoint cap on focus/plan/blocked_on.
FIELD_MAX_LEN = 200

# Spec FR1: which fields the cap and validation apply to.
TRACK_DECLARED_FIELDS = ("focus", "plan", "blocked_on")


# spec.reflect-track-status-cli FR1: sentinel distinguishing "argument omitted"
# from "argument passed as None". `None` clears; the empty string `""` also
# clears (normalized); `_UNSET` means leave the field as-is.
class _UnsetType:
    """Sentinel type for set_status omitted-arg semantics."""

    _instance: "_UnsetType | None" = None

    def __new__(cls) -> "_UnsetType":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "_UNSET"

    def __bool__(self) -> bool:
        return False


_UNSET = _UnsetType()


class StatusSnapshot(TypedDict, total=False):
    """spec.reflect-track-status-cli FR1: shape returned by set_status / get_status.

    Mirrors the on-disk status.yaml subset that the CLI/MCP surfaces care
    about. Extra keys present on disk are NOT included; callers wanting the
    full payload should read the file directly.
    """

    track: str
    focus: str | None
    plan: str | None
    blocked_on: str | None
    schema_version: int
    state: str | None
    updated_at: str | None


class TrackNotFoundError(LookupError):
    """spec.reflect-track-status-cli FR7: raised on get_status when the
    track directory exists but status.yaml does not, or on set_status when
    neither exists. Surfaces as CLI exit 3 / MCP error category
    'track_not_found'."""


class InvalidStatusValueError(TypeError):
    """spec.reflect-track-status-cli FR7: caller passed a non-string non-None
    value at the Python boundary. Surfaces as MCP error category
    'validation_error'."""


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _status_path(track: str) -> pathlib.Path:
    return TRACKS_ROOT / track / "status.yaml"


def _lock_path(track: str) -> pathlib.Path:
    return TRACKS_ROOT / track / "status.yaml.lock"


class _FileLock:
    """fcntl.flock-based exclusive lock around a sidecar .lock file.

    Sidecar (not the target file itself) so the temp+rename atomic
    write pattern doesn't disrupt the lock. flock is per-process; the
    same process re-entering serializes (LOCK_EX) but never deadlocks
    because each call opens its own fd.
    """

    def __init__(self, path: pathlib.Path):
        self.path = path
        self._fd: int | None = None

    def __enter__(self) -> "_FileLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._fd = os.open(str(self.path), os.O_CREAT | os.O_RDWR, 0o644)
        fcntl.flock(self._fd, fcntl.LOCK_EX)
        return self

    def __exit__(self, *exc) -> None:
        if self._fd is not None:
            try:
                fcntl.flock(self._fd, fcntl.LOCK_UN)
            finally:
                os.close(self._fd)
                self._fd = None


def _write_atomic(target: pathlib.Path, payload: dict) -> None:
    """Atomic write via temp+rename. Readers never see a partial file."""
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(".yaml.tmp")
    try:
        tmp.write_text(safe_dump(payload))
        os.replace(str(tmp), str(target))
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def _coerce_track_field(name: str, value) -> str | None:
    """Validate and truncate a track-declared status field per FR1.

    Returns the storable value (str or None). Raises
    InvalidStatusValueError on non-string-non-None inputs. Emits a
    stderr warning + truncates on values > FIELD_MAX_LEN codepoints.
    """
    if value is None:
        return None
    if not isinstance(value, str):
        raise InvalidStatusValueError(
            f"track_status: {name} must be str or None, got "
            f"{type(value).__name__}"
        )
    if len(value) > FIELD_MAX_LEN:
        print(
            f"track_status: {name} truncated from {len(value)} to "
            f"{FIELD_MAX_LEN} codepoints",
            file=sys.stderr,
        )
        return value[:FIELD_MAX_LEN]
    return value


def _snapshot_from_payload(track: str, payload: dict) -> StatusSnapshot:
    """Project a status.yaml dict into the StatusSnapshot shape."""
    snap: StatusSnapshot = {
        "track": payload.get("track", track),
        "focus": payload.get("focus"),
        "plan": payload.get("plan"),
        "blocked_on": payload.get("blocked_on"),
        "schema_version": int(payload.get("schema_version", SCHEMA_VERSION)),
        "state": payload.get("state"),
        "updated_at": payload.get("updated_at"),
    }
    return snap


def write_status(track: str, **fields) -> dict:
    """Merge ``fields`` into the track's status.yaml and write atomically.

    Holds the per-track flock for the full read-modify-write cycle
    (spec FR7). Preserves existing fields not mentioned in ``fields``.
    Always stamps ``updated_at`` and ``schema_version``.

    Returns the final payload dict (handy for tests / callers that
    want to see what got written).
    """
    target = _status_path(track)
    lock = _lock_path(track)

    # Validate / truncate any track-declared fields the caller passed.
    for name in TRACK_DECLARED_FIELDS:
        if name in fields:
            fields[name] = _coerce_track_field(name, fields[name])

    with _FileLock(lock):
        existing: dict = {}
        if target.exists():
            try:
                loaded = yaml.safe_load(target.read_text())
                if isinstance(loaded, dict):
                    existing = loaded
            except Exception:
                pass  # malformed → rebuild from scratch

        # Merge: explicit None in `fields` is kept as YAML null (cleared).
        existing.update(fields)
        existing["updated_at"] = _now()
        existing["schema_version"] = SCHEMA_VERSION
        existing.setdefault("track", track)

        _write_atomic(target, existing)
        return existing


# ─── State transition writers (existing public API) ────────────────────────


def mark_running(
    track: str,
    wake_id: str,
    initiating_messages: list[str] | None = None,
) -> None:
    """Write state=running at wake start.

    Spec FR3 / INV-CLEAR-ON-BOOT: clears focus/plan/blocked_on in the
    same atomic write that flips state to running.

    ``initiating_messages``: list of consumed inbox basenames (no .md)
    per spec.wake-initiating-message-record FR1. When None, the prior
    value is preserved (back-compat with the wake-loop call site that
    has not yet been restructured to pass the sweep result).
    """
    fields: dict = {
        "state": "running",
        "wake_id": wake_id,
        "started_at": _now(),
        "progress": None,
        "last_exit": None,
        "last_error": None,
        "last_summary": None,
        # FR3: BOOT clears all three track-declared fields atomically.
        "focus": None,
        "plan": None,
        "blocked_on": None,
    }
    if initiating_messages is not None:
        fields["initiating_messages"] = list(initiating_messages)
    write_status(track, **fields)


def mark_idle(track: str, summary: str) -> None:
    """Write state=idle after a clean sleep.

    Spec FR4 / INV-CLEAR-ON-EXIT: clears focus/plan/blocked_on in the
    same atomic write that flips state to idle.
    """
    write_status(
        track,
        state="idle",
        last_exit="sleep",
        last_summary=(summary or "")[:200],
        wake_id=None,
        progress=None,
        # FR4: exit clears all three track-declared fields atomically.
        focus=None,
        plan=None,
        blocked_on=None,
    )


def mark_paused(track: str, wake_id: str | None = None) -> None:
    """Write state=paused when the wake enters the pause poll-loop.

    Pause is not exit — focus/plan/blocked_on are preserved (the wake
    is still running, just waiting).
    """
    fields: dict = {"state": "paused", "last_exit": None}
    if wake_id is not None:
        fields["wake_id"] = wake_id
    write_status(track, **fields)


def mark_unhealthy(
    track: str,
    exit_reason: str,
    error: str = None,
    wake_id: str | None = None,
) -> None:
    """Write state=unhealthy on budget exhaustion, uncaught error, or signal.

    Treated as an exit per INV-CLEAR-ON-EXIT — clears the three
    track-declared fields atomically. Preserves wake_id so postmortem
    readers can locate the transcript.
    """
    fields: dict = {
        "state": "unhealthy",
        "last_exit": exit_reason,
        "last_error": error,
        # Exit path: clear track-declared fields per INV-CLEAR-ON-EXIT.
        "focus": None,
        "plan": None,
        "blocked_on": None,
    }
    if wake_id is not None:
        fields["wake_id"] = wake_id
    write_status(track, **fields)


def update_progress(
    track: str,
    current: int,
    total: int = None,
    label: str = None,
) -> None:
    """Update progress fields mid-wake (agent-callable). State stays 'running'."""
    write_status(
        track,
        progress={"current": current, "total": total, "label": label},
    )


# ─── Track-declared status fields (FR5 single-path writers) ────────────────


def set_focus(track: str, focus: str) -> None:
    """Set the track's currently-declared focus (spec FR1)."""
    write_status(track, focus=focus)


def clear_focus(track: str) -> None:
    """Clear the track's focus field to null."""
    write_status(track, focus=None)


def set_plan(track: str, plan: str) -> None:
    """Set the track's currently-declared plan (spec FR1)."""
    write_status(track, plan=plan)


def clear_plan(track: str) -> None:
    """Clear the track's plan field to null."""
    write_status(track, plan=None)


def set_blocked_on(track: str, blocked_on: str) -> None:
    """Set the track's currently-declared blocker (spec FR1)."""
    write_status(track, blocked_on=blocked_on)


def clear_blocked_on(track: str) -> None:
    """Clear the track's blocked_on field to null."""
    write_status(track, blocked_on=None)


def set_status(
    track: str,
    focus: str | None | _UnsetType = _UNSET,
    plan: str | None | _UnsetType = _UNSET,
    blocked: str | None | _UnsetType = _UNSET,
) -> StatusSnapshot:
    """Set any combination of focus/plan/blocked in one atomic write.

    spec.reflect-track-status-cli FR1: canonical entry point shared by
    CLI and MCP surfaces. The kwarg name `blocked` matches the CLI flag
    `--blocked`; the on-disk JSON field stays `blocked_on`.

    Argument semantics (FR4):
      - `_UNSET` (default)  → field unchanged
      - `None` (explicit)   → field cleared to null
      - `""` (empty str)    → field cleared to null (normalized to None)
      - non-empty str       → field set to that string (truncated at FIELD_MAX_LEN)

    Returns the post-write StatusSnapshot. Raises TrackNotFoundError if
    no track directory exists. Raises InvalidStatusValueError if a value
    is a non-string non-None type.
    """
    fields: dict = {}
    if not isinstance(focus, _UnsetType):
        fields["focus"] = None if focus == "" else focus
    if not isinstance(plan, _UnsetType):
        fields["plan"] = None if plan == "" else plan
    if not isinstance(blocked, _UnsetType):
        # On-disk field name is `blocked_on`; CLI/Python kwarg is `blocked`.
        fields["blocked_on"] = None if blocked == "" else blocked

    track_dir = TRACKS_ROOT / track
    if not track_dir.is_dir():
        raise TrackNotFoundError(f"track not found: {track}")

    if not fields:
        # No-op set is conformant: read current snapshot and return it.
        return get_status(track)

    payload = write_status(track, **fields)
    return _snapshot_from_payload(track, payload)


def get_status(track: str) -> StatusSnapshot:
    """Read the current StatusSnapshot for a track.

    spec.reflect-track-status-cli FR5: read under the per-track file
    lock (FR6) so a concurrent set_status never delivers a torn view.
    Does NOT mutate updated_at.

    Raises TrackNotFoundError if the track directory or status.yaml
    is missing.
    """
    track_dir = TRACKS_ROOT / track
    if not track_dir.is_dir():
        raise TrackNotFoundError(f"track not found: {track}")
    target = _status_path(track)
    if not target.exists():
        raise TrackNotFoundError(f"track not found: {track}")

    with _FileLock(_lock_path(track)):
        try:
            loaded = yaml.safe_load(target.read_text())
        except (OSError, yaml.YAMLError) as exc:
            # Malformed YAML or read error — surface as write_error-like
            # but at the Python boundary raise OSError-like.
            raise OSError(f"failed to read status.yaml for {track}: {exc}") from exc
        payload = loaded if isinstance(loaded, dict) else {}

    return _snapshot_from_payload(track, payload)


def clear_track_status(track: str) -> None:
    """Clear all three track-declared fields in one atomic write.

    Used by BOOT and exit hooks; equivalent to set_status(track,
    focus=None, plan=None, blocked=None) but explicit at the call site.
    """
    write_status(track, focus=None, plan=None, blocked_on=None)
