# Side-effect import: register the substrate's YAML emitter representer
# (multi-line strings → `|` block scalars) process-wide. Imported here
# so that any code path touching ``agent.lib.*`` benefits automatically,
# including the substrate runtime modules that emit YAML directly.
from agent.lib import yaml_io  # noqa: F401
