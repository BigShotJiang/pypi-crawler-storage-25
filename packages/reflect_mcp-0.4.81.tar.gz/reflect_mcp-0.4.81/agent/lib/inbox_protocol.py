"""Inbox-message protocol v1.0 validator + slug derivation.

Implements ``spec.inbox-protocol~0171a19a`` (the normative reduction of
``design.inbox-frontmatter-schema~c4ac3a4e``). Single shared
implementation for the three validation surfaces named in §7:

- ``validate_strict``  — send-time and cross-node-ingest enforcement.
                          Returns the list of structured violations.
                          Empty list means the frontmatter is OK.
- ``validate_lenient`` — read-time enforcement. Returns the list of
                          structured warnings. Never refuses to surface;
                          a non-empty result is a *warning* set, not a
                          rejection.
- ``slug_from_subject`` — §4 derivation rule. Raises
                          :class:`SubjectSlugError` if the spec mandates
                          producer rejection (CT-L6).

The two validators share their checks via ``_check_frontmatter`` so
strict and lenient cannot drift in independent edits — the only
difference is how each failure class is surfaced (reject vs. warn).

@scry.bind impl.inbox-protocol-validator~587dc62c \
    spec.inbox-protocol~0171a19a#3 \
    impl-of-required-core-schema
@scry.bind impl.inbox-protocol-slug~587dc62c \
    spec.inbox-protocol~0171a19a#4 \
    impl-of-slug-derivation
@scry.bind impl.inbox-protocol-three-points~587dc62c \
    spec.inbox-protocol~0171a19a#7 \
    impl-of-strict-lenient-split
"""
# The @scry.entry block lives below the docstring so __doc__ stays clean.

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping, Optional


# ── scry marker (indexed via comment, kept out of __doc__) ────────────────

# <!-- @scry.entry
# id: code.inbox-protocol-validator~587dc62c
# kind: code
# status: active
# weight: 0.9
# tags:
#   - "scope:substrate"
#   - "topic:inbox-protocol"
#   - "inbox-protocol"
#   - "topic:validator"
#   - "validator"
#   - "scope:lib"
#   - "code:agent.lib.inbox_protocol"
# summary: >
#   Inbox-message v1.0 protocol validator: strict + lenient validators
#   per spec.inbox-protocol~0171a19a §3-§8. Required-field validation
#   (schema_version, id, from, to, at, kind, subject), kind enum closure
#   check, reserved-field rejection, slug derivation from subject (§4),
#   UUID v4 generation/validation, ISO 8601 UTC enforcement, lenient
#   mode for read-time. Also: inbox protocol implementation, frontmatter
#   validator, schema version 1, kind enum, slug derivation kebab-case
#   60-char, UUID v4, reserved field signature payload, CT-S CT-R CT-L
#   conformance.
# rationale: >
#   Without a single shared implementation, strict and lenient
#   validators drift; the spec mandates SHOULD-share (§7.4).
# applies: implementing inbox send-time validation, debugging a rejected message, deriving filename slugs, extending the kind enum
# seeded_questions:
#   - "Where does the v1.0 inbox-message validator live?"
#   - "How is the slug derived from a subject?"
#   - "validate_strict vs validate_lenient"
#   - "How are reserved fields rejected?"
# implements:
#   - "spec.inbox-protocol~0171a19a"
# @scry.entry.end -->


# ─────────────────────────────────────────────────────────────────────────────
# Spec constants — kept here as the single source of truth for downstream
# importers. Changes here are normative changes to v1; bump the version on
# the constants together with a spec amendment.
# ─────────────────────────────────────────────────────────────────────────────

SCHEMA_VERSION: str = "1"
SUPPORTED_SCHEMA_VERSIONS: frozenset[str] = frozenset({SCHEMA_VERSION})

# §3.2 — closed enum at v1.
KIND_ENUM: frozenset[str] = frozenset({
    "report",
    "request",
    "deploy-request",
    "btw",
    "broadcast",
    "followup",
    "decision",
})

# §3.1 — required core fields.
REQUIRED_FIELDS: tuple[str, ...] = (
    "schema_version",
    "id",
    "from",
    "to",
    "at",
    "kind",
    "subject",
)

# §3.3 — optional standard fields (typed when present).
OPTIONAL_STANDARD_FIELDS: tuple[str, ...] = (
    "thread",
    "in_reply_to",
    "node",
    "reply_to",
)

# §3.4 — reserved field names. Strict: reject. Lenient: warn.
RESERVED_FIELDS: frozenset[str] = frozenset({
    "signature",
    "payload",
    "consumed_at",
    "consumed_from",
    "provenance",
})

# §3.1 — subject is bounded at 120 graphemes (we use code-points as a
# practical proxy here — Python str length).
SUBJECT_MAX_CODEPOINTS: int = 120

# §4 — slug truncation cap.
SLUG_MAX_LEN: int = 60
# §4.1 step 4 — cut at last `-` within this window if available.
SLUG_CUT_WINDOW: int = 10


# ── violation / warning shapes ────────────────────────────────────────────


@dataclass(frozen=True)
class Issue:
    """A single structured validation issue.

    ``code`` is a stable machine identifier (e.g. ``"schema_version_missing"``)
    that callers can branch on. ``message`` is the human-readable rendering.
    ``field`` is the offending field name when one is implicated; ``None``
    when the issue is at the document level.
    """

    code: str
    field: Optional[str]
    message: str


# Type aliases for clarity at call sites.
Violation = Issue
Warning_ = Issue  # `Warning` is a builtin; alias kept for symmetry.


# ── public exceptions ─────────────────────────────────────────────────────


class SubjectSlugError(ValueError):
    """Raised when slug derivation cannot produce a non-empty slug.

    Per §4.1 step 5 / CT-L6, the producer MUST reject a subject that
    yields an empty slug (e.g. a subject of only symbols). The empty
    slug is treated as a producer-side hard reject so the file is
    never written.
    """


# ─────────────────────────────────────────────────────────────────────────────
# UUID v4 helpers
# ─────────────────────────────────────────────────────────────────────────────

_UUID_V4_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
    re.IGNORECASE,
)


def mint_uuid_v4() -> str:
    """Mint a fresh UUID v4 string (lower-case canonical form)."""
    return str(uuid.uuid4())


def is_uuid_v4(value: Any) -> bool:
    """Return True iff ``value`` is a canonical UUID v4 string.

    Accepts the hyphenated 36-char form; rejects bare-hex, braces, urn
    prefixes, and any other UUID version. Conservative on purpose — the
    spec says "MUST be a freshly generated UUID v4".
    """
    if not isinstance(value, str):
        return False
    return bool(_UUID_V4_RE.match(value))


# ─────────────────────────────────────────────────────────────────────────────
# ISO 8601 UTC helpers
# ─────────────────────────────────────────────────────────────────────────────

# Two accepted shapes for `at`:
#   • Spec canonical: YYYY-MM-DDTHH:MM:SS[.fff]Z (UTC, trailing Z)
#   • Filename-safe form: YYYY-MM-DDTHH-MM-SSZ (dashes in time portion)
# The filename-safe form is the existing P9 convention and is accepted
# at v1.0 to avoid a parallel breaking change to every producer. Both
# normalize to the same instant.
_ISO_CANONICAL_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$"
)
_ISO_FILENAME_SAFE_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}Z$"
)


def is_iso8601_utc(value: Any) -> bool:
    """Return True iff ``value`` parses as ISO 8601 UTC.

    Accepts both the canonical ``T..:..:..Z`` form and the
    filename-safe ``T..-..-..Z`` form (existing P9 convention). Local
    times (no ``Z``, no offset) and non-UTC offsets are rejected per
    CT-S4.
    """
    if not isinstance(value, str):
        return False
    if _ISO_CANONICAL_RE.match(value):
        try:
            datetime.strptime(value.replace("Z", "+0000"), "%Y-%m-%dT%H:%M:%S%z")
            return True
        except ValueError:
            try:
                # Handle fractional seconds.
                datetime.fromisoformat(value.replace("Z", "+00:00"))
                return True
            except ValueError:
                return False
    if _ISO_FILENAME_SAFE_RE.match(value):
        try:
            datetime.strptime(value, "%Y-%m-%dT%H-%M-%SZ")
            return True
        except ValueError:
            return False
    return False


def at_to_filename_safe(at: str) -> str:
    """Convert a canonical ISO 8601 UTC timestamp to the filename-safe
    form (``:`` → ``-`` in the time portion) per §4.2.

    Idempotent when called on an already-filename-safe value.
    """
    if _ISO_FILENAME_SAFE_RE.match(at):
        return at
    # Replace exactly the two ``:`` in the time portion.
    if "T" in at and at.endswith("Z"):
        date_part, time_part = at.split("T", 1)
        # Strip trailing Z, swap colons, re-add Z.
        time_core = time_part[:-1]
        # Drop fractional-second component when collapsing to filename form.
        time_core = time_core.split(".", 1)[0]
        time_core_dashed = time_core.replace(":", "-")
        return f"{date_part}T{time_core_dashed}Z"
    return at


# ─────────────────────────────────────────────────────────────────────────────
# §4 — slug derivation
# ─────────────────────────────────────────────────────────────────────────────

_SLUG_NON_WORD_RE = re.compile(r"[^a-z0-9]+")


def slug_from_subject(subject: str) -> str:
    """Derive a filename slug from ``subject`` per §4.1.

    Steps:
    1. Lowercase.
    2. Replace runs of non-``[a-z0-9]`` with a single ``-``.
    3. Strip leading/trailing ``-``.
    4. Truncate to ≤60 chars; if the cut lands inside a word, prefer
       cutting at the last ``-`` within the last 10 chars of the
       truncated form, otherwise cut at exactly 60.
    5. Raise :class:`SubjectSlugError` if the result is empty.
    """
    if not isinstance(subject, str):
        raise SubjectSlugError(
            f"subject must be a string, got {type(subject).__name__}"
        )
    s = subject.lower()
    s = _SLUG_NON_WORD_RE.sub("-", s)
    s = s.strip("-")

    if len(s) > SLUG_MAX_LEN:
        # Per §4.1 step 4: prefer cutting at the last `-` within the
        # last SLUG_CUT_WINDOW chars of the truncated form, but only
        # when the cut at SLUG_MAX_LEN would land inside a word
        # (i.e. the char at SLUG_MAX_LEN is itself a word-char, meaning
        # the previous char is also a word-char that would be split).
        # Otherwise cut at exactly 60.
        truncated = s[:SLUG_MAX_LEN]
        next_char = s[SLUG_MAX_LEN] if SLUG_MAX_LEN < len(s) else ""
        # "Inside a word" = the boundary at position 60 splits a run of
        # word-chars. If next_char is '-' the cut already lands at a
        # natural boundary; keep the simple truncate.
        if next_char and next_char != "-":
            window_start = max(0, SLUG_MAX_LEN - SLUG_CUT_WINDOW)
            last_dash = truncated.rfind("-", window_start)
            if last_dash >= 0:
                truncated = truncated[:last_dash]
        s = truncated.rstrip("-")

    if not s:
        raise SubjectSlugError(
            "subject yields empty slug after normalization "
            "(§4.1 step 5 / CT-L6)"
        )
    return s


# ─────────────────────────────────────────────────────────────────────────────
# Internal: shared check pipeline
# ─────────────────────────────────────────────────────────────────────────────


def _check_frontmatter(
    fm: Mapping[str, Any],
    *,
    lenient: bool,
) -> list[Issue]:
    """Return the list of issues for ``fm``.

    Strict and lenient share this pipeline; the lenient mode collapses
    the missing-``schema_version`` case from a violation into a
    deprecation warning per §8.2, and treats kind / reserved-field
    failures as warnings (§7.2).
    """
    issues: list[Issue] = []

    # ── schema_version ───────────────────────────────────────────────────
    sv = fm.get("schema_version")
    if sv is None:
        if lenient:
            issues.append(Issue(
                code="legacy_no_schema_version",
                field="schema_version",
                message=(
                    "frontmatter omits schema_version — treating as legacy "
                    "(pre-v1) and parsing permissively (§8.2)"
                ),
            ))
        else:
            issues.append(Issue(
                code="schema_version_missing",
                field="schema_version",
                message="schema_version is required (§3.1)",
            ))
    elif not isinstance(sv, str):
        issues.append(Issue(
            code="schema_version_type",
            field="schema_version",
            message=(
                f"schema_version must be a string, got "
                f"{type(sv).__name__}"
            ),
        ))
    elif sv not in SUPPORTED_SCHEMA_VERSIONS:
        # CT-S2 / CT-X4 — surface the structured-Ack shape.
        supported = sorted(SUPPORTED_SCHEMA_VERSIONS)
        issues.append(Issue(
            code="schema_unsupported",
            field="schema_version",
            message=(
                f"schema_unsupported(got={sv!r}, supported={supported})"
            ),
        ))

    # ── id (UUID v4) ─────────────────────────────────────────────────────
    if "id" not in fm:
        # Required at v1. Lenient still warns (legacy files often omit).
        code = "id_missing"
        msg = "id (UUID v4) is required (§3.1)"
        issues.append(Issue(code=code, field="id", message=msg))
    elif not is_uuid_v4(fm["id"]):
        issues.append(Issue(
            code="id_not_uuid_v4",
            field="id",
            message=f"id must be a UUID v4 string; got {fm['id']!r}",
        ))

    # ── from / to ────────────────────────────────────────────────────────
    for required in ("from", "to"):
        val = fm.get(required)
        if val is None:
            issues.append(Issue(
                code=f"{required}_missing",
                field=required,
                message=f"{required} is required (§3.1)",
            ))
        elif not isinstance(val, str) or not val.strip():
            issues.append(Issue(
                code=f"{required}_invalid",
                field=required,
                message=(
                    f"{required} must be a non-empty track-name string; "
                    f"got {val!r}"
                ),
            ))

    # ── at (ISO 8601 UTC) ────────────────────────────────────────────────
    at = fm.get("at")
    if at is None:
        issues.append(Issue(
            code="at_missing",
            field="at",
            message="at is required (§3.1)",
        ))
    elif not is_iso8601_utc(at):
        issues.append(Issue(
            code="at_not_iso_utc",
            field="at",
            message=(
                f"at must be ISO 8601 UTC (T..:..:..Z or T..-..-..Z); "
                f"got {at!r}"
            ),
        ))

    # ── kind ─────────────────────────────────────────────────────────────
    kind = fm.get("kind")
    if kind is None:
        issues.append(Issue(
            code="kind_missing",
            field="kind",
            message="kind is required (§3.1)",
        ))
    elif kind not in KIND_ENUM:
        issues.append(Issue(
            code="kind_unknown",
            field="kind",
            message=(
                f"kind {kind!r} is not in v1 enum; valid: "
                f"{sorted(KIND_ENUM)}"
            ),
        ))

    # ── subject ──────────────────────────────────────────────────────────
    subject = fm.get("subject")
    if subject is None:
        issues.append(Issue(
            code="subject_missing",
            field="subject",
            message="subject is required (§3.1)",
        ))
    elif not isinstance(subject, str) or not subject.strip():
        issues.append(Issue(
            code="subject_empty",
            field="subject",
            message="subject must be a non-empty string (§3.1)",
        ))
    elif len(subject) > SUBJECT_MAX_CODEPOINTS:
        issues.append(Issue(
            code="subject_too_long",
            field="subject",
            message=(
                f"subject must be ≤{SUBJECT_MAX_CODEPOINTS} graphemes; "
                f"got {len(subject)}"
            ),
        ))

    # ── reserved fields (§3.4) ───────────────────────────────────────────
    for reserved in sorted(RESERVED_FIELDS & set(fm.keys())):
        issues.append(Issue(
            code="reserved_field_present",
            field=reserved,
            message=(
                f"reserved field {reserved!r} MUST NOT appear in "
                f"v1 frontmatter (§3.4)"
            ),
        ))

    # ── optional standard field type checks ──────────────────────────────
    for opt in ("thread", "in_reply_to"):
        if opt in fm and fm[opt] is not None and not is_uuid_v4(fm[opt]):
            issues.append(Issue(
                code=f"{opt}_not_uuid_v4",
                field=opt,
                message=(
                    f"{opt} must be a UUID v4 string when present; "
                    f"got {fm[opt]!r}"
                ),
            ))
    for opt in ("node", "reply_to"):
        if opt in fm and fm[opt] is not None and (
            not isinstance(fm[opt], str) or not fm[opt].strip()
        ):
            issues.append(Issue(
                code=f"{opt}_invalid",
                field=opt,
                message=(
                    f"{opt} must be a non-empty string when present; "
                    f"got {fm[opt]!r}"
                ),
            ))

    # ── unknown optional fields (§3.5) ───────────────────────────────────
    known = (
        set(REQUIRED_FIELDS)
        | set(OPTIONAL_STANDARD_FIELDS)
        | set(RESERVED_FIELDS)
    )
    unknown = sorted(set(fm.keys()) - known)
    if unknown:
        # §3.5 — accept with a single structured warning naming them.
        issues.append(Issue(
            code="unknown_fields",
            field=None,
            message=(
                f"frontmatter carries unknown fields: {unknown} "
                f"(accepted per §3.5)"
            ),
        ))

    return issues


# ─────────────────────────────────────────────────────────────────────────────
# Public validators
# ─────────────────────────────────────────────────────────────────────────────


def validate_strict(fm: Mapping[str, Any]) -> list[Violation]:
    """Strict (send-time / cross-node-ingest) validator per §7.1 / §7.3.

    Returns the list of violations. An empty list means the
    frontmatter conforms to v1.0. The caller is responsible for
    refusing the write on a non-empty result.

    The :class:`Issue` carrying ``code == "unknown_fields"`` is
    *informational* per §3.5 — strict mode "accepts with a single
    structured warning". Callers that hard-reject on any issue should
    filter on ``code != "unknown_fields"``; the helper
    :func:`strict_blocking_issues` does this filter.
    """
    return _check_frontmatter(fm, lenient=False)


def strict_blocking_issues(issues: Iterable[Issue]) -> list[Issue]:
    """Filter to the issues that block a strict-mode send."""
    return [i for i in issues if i.code != "unknown_fields"]


def validate_lenient(fm: Mapping[str, Any]) -> list[Warning_]:
    """Lenient (read-time) validator per §7.2.

    Returns the list of warnings. Consumers MUST NOT refuse to
    surface the message on a non-empty result; they MUST surface the
    warnings out-of-band (logs, structured output).
    """
    return _check_frontmatter(fm, lenient=True)


# ─────────────────────────────────────────────────────────────────────────────
# Mint helper — produces a v1 frontmatter dict ready to serialize.
# ─────────────────────────────────────────────────────────────────────────────


def mint_frontmatter(
    *,
    from_: str,
    to: str,
    subject: str,
    kind: str = "report",
    at: Optional[str] = None,
    thread: Optional[str] = None,
    in_reply_to: Optional[str] = None,
    node: Optional[str] = None,
    reply_to: Optional[str] = None,
    extra: Optional[Mapping[str, Any]] = None,
) -> dict[str, Any]:
    """Produce a v1-conforming frontmatter dict.

    Mints a fresh UUID v4 ``id`` and defaults ``at`` to ``now`` in
    filename-safe UTC form. The caller is responsible for serializing
    the dict to YAML and writing it; this function does not touch the
    filesystem.

    Pass through unknown optional fields via ``extra`` (they will be
    flagged by §3.5 at validation time but accepted).
    """
    if at is None:
        at = datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    fm: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "id": mint_uuid_v4(),
        "from": from_,
        "to": to,
        "at": at,
        "kind": kind,
        "subject": subject,
    }
    for k, v in (
        ("thread", thread),
        ("in_reply_to", in_reply_to),
        ("node", node),
        ("reply_to", reply_to),
    ):
        if v is not None:
            fm[k] = v
    if extra:
        for k, v in extra.items():
            if k in fm:
                # Don't allow `extra` to override required core.
                continue
            fm[k] = v
    return fm


# ─────────────────────────────────────────────────────────────────────────────
# Serialize / parse
# ─────────────────────────────────────────────────────────────────────────────


# Order required fields first, then optional standard, then anything else.
_FIELD_ORDER: tuple[str, ...] = (
    REQUIRED_FIELDS + OPTIONAL_STANDARD_FIELDS
)


def render_frontmatter(fm: Mapping[str, Any]) -> str:
    """Render a frontmatter dict to the canonical YAML block.

    The output starts with ``---\\n`` and ends with ``---\\n`` and is
    suitable for prepending directly to a message body. Field order is
    stable for diff legibility: required core first (in spec order),
    optional standard fields next, then any extras in insertion order.
    """
    ordered: list[tuple[str, Any]] = []
    seen: set[str] = set()
    for key in _FIELD_ORDER:
        if key in fm:
            ordered.append((key, fm[key]))
            seen.add(key)
    for key, val in fm.items():
        if key not in seen:
            ordered.append((key, val))
    lines = ["---"]
    for k, v in ordered:
        lines.append(f"{k}: {_yaml_scalar(v)}")
    lines.append("---")
    return "\n".join(lines) + "\n"


def _yaml_scalar(v: Any) -> str:
    """Render a scalar as a YAML-safe string.

    Strings are emitted bare when they don't need quoting; otherwise
    double-quoted with backslash-escape. Non-string scalars are str()'d.
    """
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    s = str(v)
    needs_quote = (
        not s
        or s[0] in "!&*[]{}|>%@`#,?:- "
        or s[-1] in " :"
        or any(c in s for c in "\n\t\"'")
        or s.lower() in {"null", "true", "false", "yes", "no", "on", "off"}
    )
    # Special case: ISO timestamps and UUIDs are fine bare.
    if not needs_quote:
        return s
    escaped = s.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


_FRONTMATTER_RE = re.compile(
    r"\A---\s*\n(.*?)\n---\s*(?:\n|$)",
    re.DOTALL,
)


def parse_frontmatter_block(text: str) -> tuple[Optional[dict[str, Any]], str]:
    """Split ``text`` into (frontmatter_dict, body).

    Returns ``(None, text)`` when no frontmatter block is present
    (treated as a legacy/bare file at read-time). On a malformed YAML
    body inside ``---`` fences, returns ``({}, body)`` — the caller
    can pair this with :func:`validate_lenient` to surface the parse
    error without refusing the file (CT-R4).
    """
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return None, text
    raw_block = m.group(1)
    body = text[m.end():]
    fm: dict[str, Any] = {}
    for raw_line in raw_block.splitlines():
        line = raw_line.rstrip()
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            # Malformed line — record as a synthetic key so the
            # validator can flag it as unknown.
            fm.setdefault("_parse_errors", []).append(raw_line)
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        # Strip surrounding quotes if any.
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        # Coerce a few obvious literals.
        if value.lower() == "null" or value == "":
            fm[key] = None
        elif value.lower() == "true":
            fm[key] = True
        elif value.lower() == "false":
            fm[key] = False
        else:
            fm[key] = value
    return fm, body


__all__ = [
    "SCHEMA_VERSION",
    "SUPPORTED_SCHEMA_VERSIONS",
    "KIND_ENUM",
    "REQUIRED_FIELDS",
    "OPTIONAL_STANDARD_FIELDS",
    "RESERVED_FIELDS",
    "SUBJECT_MAX_CODEPOINTS",
    "SLUG_MAX_LEN",
    "Issue",
    "Violation",
    "Warning_",
    "SubjectSlugError",
    "mint_uuid_v4",
    "is_uuid_v4",
    "is_iso8601_utc",
    "at_to_filename_safe",
    "slug_from_subject",
    "validate_strict",
    "strict_blocking_issues",
    "validate_lenient",
    "mint_frontmatter",
    "render_frontmatter",
    "parse_frontmatter_block",
]
