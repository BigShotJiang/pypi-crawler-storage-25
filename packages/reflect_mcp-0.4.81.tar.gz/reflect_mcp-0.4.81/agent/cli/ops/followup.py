"""Pure followup operations — no CLI formatting, no sys.exit, no stdout.

Implements the writer side of the blocked-followup escape hatch
(design.blocked-followup-state~2efaa40e). The reader side requires
zero new code: agent/runtime/wake.py's `followup/` glob is
non-recursive, so files in `blocked-on-trigger/` are already excluded
from `pending_followup`.

All functions return structured dicts. Callers (CLI, MCP) format as
needed.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from agent.cli.ops.root import resolve_project_root


BLOCKED_SUBDIR_NAME = "blocked-on-trigger"


class FollowupArgError(ValueError):
    """Raised on invalid followup argument combinations."""


def _project_root() -> Path:
    return resolve_project_root()


def _tracks_dir(tracks_dir: Optional[Path] = None) -> Path:
    return tracks_dir if tracks_dir is not None else _project_root() / "agent" / "runtime" / "tracks"


def _track_dir(track: str, tracks_dir: Optional[Path] = None) -> Path:
    return _tracks_dir(tracks_dir) / track


def _followup_dir(track: str, tracks_dir: Optional[Path] = None) -> Path:
    return _track_dir(track, tracks_dir) / "followup"


def _blocked_dir(track: str, tracks_dir: Optional[Path] = None) -> Path:
    return _followup_dir(track, tracks_dir) / BLOCKED_SUBDIR_NAME


def _resolve_track(track: Optional[str]) -> str:
    """Resolve target track from explicit arg, then $REFLECT_TRACK env."""
    if track:
        return track
    env_track = os.environ.get("REFLECT_TRACK")
    if env_track:
        return env_track
    raise FollowupArgError(
        "track required (pass --track or set REFLECT_TRACK)"
    )


def _list_md(d: Path) -> list[Path]:
    if not d.exists():
        return []
    return sorted(p for p in d.glob("*.md") if p.is_file())


def block_followup(
    name: str,
    *,
    track: Optional[str] = None,
    tracks_dir: Optional[Path] = None,
) -> dict:
    """Move a followup file from followup/ root into blocked-on-trigger/.

    Idempotent: if the file is already in blocked-on-trigger/, this is
    a no-op success. Refuses on:
      - track not found
      - followup file not found in either location
      - ambiguous (file exists in both root and blocked-on-trigger/)

    Returns {ok, track, name, state, moved} on success or
    {ok: False, error, message} on failure.
    """
    try:
        track = _resolve_track(track)
    except FollowupArgError as exc:
        return {"ok": False, "error": "argument", "message": str(exc)}

    track_dir = _track_dir(track, tracks_dir)
    if not track_dir.exists():
        return {
            "ok": False,
            "error": "track_not_found",
            "message": f"track '{track}' not found",
        }

    followup_dir = _followup_dir(track, tracks_dir)
    blocked_dir = _blocked_dir(track, tracks_dir)
    src = followup_dir / name
    dst = blocked_dir / name

    src_exists = src.is_file()
    dst_exists = dst.is_file()

    if src_exists and dst_exists:
        return {
            "ok": False,
            "error": "ambiguous",
            "message": (
                f"followup '{name}' exists in both followup/ root and "
                f"followup/{BLOCKED_SUBDIR_NAME}/; resolve manually"
            ),
        }

    if dst_exists and not src_exists:
        # Already blocked. Idempotent no-op.
        return {
            "ok": True,
            "track": track,
            "name": name,
            "state": "blocked",
            "moved": False,
        }

    if not src_exists:
        return {
            "ok": False,
            "error": "not_found",
            "message": (
                f"followup '{name}' not found in {track}/followup/ "
                f"(or {BLOCKED_SUBDIR_NAME}/)"
            ),
        }

    blocked_dir.mkdir(parents=True, exist_ok=True)
    try:
        src.rename(dst)
    except OSError as exc:
        return {
            "ok": False,
            "error": "io_error",
            "message": f"mv failed: {exc}",
        }

    return {
        "ok": True,
        "track": track,
        "name": name,
        "state": "blocked",
        "moved": True,
    }


def unblock_followup(
    name: str,
    *,
    track: Optional[str] = None,
    tracks_dir: Optional[Path] = None,
) -> dict:
    """Move a followup file from blocked-on-trigger/ back into followup/.

    Idempotent: if the file is already in the root, this is a no-op
    success. Same refusal modes as block_followup.

    Returns {ok, track, name, state, moved} on success or
    {ok: False, error, message} on failure.
    """
    try:
        track = _resolve_track(track)
    except FollowupArgError as exc:
        return {"ok": False, "error": "argument", "message": str(exc)}

    track_dir = _track_dir(track, tracks_dir)
    if not track_dir.exists():
        return {
            "ok": False,
            "error": "track_not_found",
            "message": f"track '{track}' not found",
        }

    followup_dir = _followup_dir(track, tracks_dir)
    blocked_dir = _blocked_dir(track, tracks_dir)
    src = blocked_dir / name
    dst = followup_dir / name

    src_exists = src.is_file()
    dst_exists = dst.is_file()

    if src_exists and dst_exists:
        return {
            "ok": False,
            "error": "ambiguous",
            "message": (
                f"followup '{name}' exists in both followup/ root and "
                f"followup/{BLOCKED_SUBDIR_NAME}/; resolve manually"
            ),
        }

    if dst_exists and not src_exists:
        # Already in root. Idempotent no-op.
        return {
            "ok": True,
            "track": track,
            "name": name,
            "state": "active",
            "moved": False,
        }

    if not src_exists:
        return {
            "ok": False,
            "error": "not_found",
            "message": (
                f"followup '{name}' not found in "
                f"{track}/followup/{BLOCKED_SUBDIR_NAME}/ "
                f"(or followup/ root)"
            ),
        }

    # followup/ root always exists if the track does — but be defensive.
    followup_dir.mkdir(parents=True, exist_ok=True)
    try:
        src.rename(dst)
    except OSError as exc:
        return {
            "ok": False,
            "error": "io_error",
            "message": f"mv failed: {exc}",
        }

    return {
        "ok": True,
        "track": track,
        "name": name,
        "state": "active",
        "moved": True,
    }


def list_followups(
    *,
    track: Optional[str] = None,
    tracks_dir: Optional[Path] = None,
) -> dict:
    """List active and blocked followups for a track.

    Returns {ok, track, active: [name, ...], blocked: [name, ...]} on
    success or {ok: False, error, message} on failure.
    """
    try:
        track = _resolve_track(track)
    except FollowupArgError as exc:
        return {"ok": False, "error": "argument", "message": str(exc)}

    track_dir = _track_dir(track, tracks_dir)
    if not track_dir.exists():
        return {
            "ok": False,
            "error": "track_not_found",
            "message": f"track '{track}' not found",
        }

    followup_dir = _followup_dir(track, tracks_dir)
    blocked_dir = _blocked_dir(track, tracks_dir)

    active = [p.name for p in _list_md(followup_dir)]
    blocked = [p.name for p in _list_md(blocked_dir)]

    return {
        "ok": True,
        "track": track,
        "active": active,
        "blocked": blocked,
    }
