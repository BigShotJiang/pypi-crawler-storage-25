"""Pure inbox operations — no CLI formatting, no sys.exit, no stdout.

All functions return structured dicts. Callers (CLI, MCP) format as needed.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from agent.cli.ops.root import resolve_project_root
PROJECT_ROOT = resolve_project_root()
TRACKS_DIR = PROJECT_ROOT / "agent" / "runtime" / "tracks"


class ConsumeArgError(ValueError):
    """Raised on invalid consume_inbox argument combinations."""


def _effective_tracks_dir(tracks_dir: Optional[Path] = None) -> Path:
    return tracks_dir if tracks_dir is not None else TRACKS_DIR


def _track_names(tracks_dir: Optional[Path] = None) -> list[str]:
    td = _effective_tracks_dir(tracks_dir)
    if not td.exists():
        return []
    return sorted(d.name for d in td.iterdir() if d.is_dir() and not d.name.startswith("."))


def _inbox_files_for_track(name: str, tracks_dir: Optional[Path] = None) -> list[dict]:
    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / name
    inbox_dir = track_dir / "inbox"
    consumed_dir = inbox_dir / ".consumed"

    if not inbox_dir.exists():
        return []

    consumed_names: set[str] = set()
    if consumed_dir.exists():
        consumed_names = set(p.name for p in consumed_dir.glob("*.md"))

    files = []
    # P9: only .md files directly in inbox/ (not subdirs like from-originator/)
    for p in sorted(inbox_dir.glob("*.md"), reverse=True):
        if p.name in consumed_names:
            continue
        try:
            mtime = p.stat().st_mtime
            mtime_str = datetime.fromtimestamp(mtime, tz=timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
        except OSError:
            mtime_str = "-"
        files.append({
            "track": name,
            "filename": p.name,
            "mtime": mtime_str,
        })
    return files


def list_inbox(track: Optional[str] = None, tracks_dir: Optional[Path] = None) -> list[dict]:
    """Return list of unread inbox messages across all tracks, or for a specific track.

    Each dict: {track, filename, mtime}
    Returns {"error": reason} as first item if track not found.
    """
    td = _effective_tracks_dir(tracks_dir)
    if track:
        if not (td / track).exists():
            return [{"error": f"Track '{track}' not found"}]
        return _inbox_files_for_track(track, tracks_dir)

    all_files: list[dict] = []
    for name in _track_names(tracks_dir):
        all_files.extend(_inbox_files_for_track(name, tracks_dir))
    return all_files


def peek_inbox(track: str, filename: str, tracks_dir: Optional[Path] = None) -> dict:
    """Read the contents of a specific inbox file.

    Returns {"track": str, "filename": str, "content": str} or {"error": reason}
    """
    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / track
    if not track_dir.exists():
        return {"error": f"Track '{track}' not found"}

    # P9: files live directly in inbox/ (not inbox/from-originator/)
    inbox_dir = track_dir / "inbox"
    file_path = inbox_dir / filename
    if not file_path.exists():
        return {"error": f"File '{filename}' not found in {track} inbox"}

    try:
        content = file_path.read_text()
    except OSError as e:
        return {"error": str(e)}

    return {"track": track, "filename": filename, "content": content}


# ── Timeline helpers ──────────────────────────────────────────────────────────

_TS_RE = re.compile(
    r"^(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}Z)"
)


def _parse_ts_from_filename(name: str) -> Optional[str]:
    """Extract ISO timestamp from filename prefix like 2026-05-08T11-02-05Z-*.

    Returns a sortable string like '2026-05-08T11:02:05Z', or None.
    """
    m = _TS_RE.match(name)
    if not m:
        return None
    raw = m.group(1)  # e.g. 2026-05-08T11-02-05Z
    # Convert dashes in time portion back to colons: split at T
    date_part, rest = raw.split("T", 1)
    # rest looks like 11-02-05Z
    time_part = rest.replace("-", ":", 2)  # replace first two dashes only
    return f"{date_part}T{time_part}"


def _extract_title(path: Path) -> str:
    """Pull # Heading title or first non-empty line from a markdown file."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return path.stem
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith("#"):
            return line.lstrip("#").strip()
        return line
    return path.stem


def inbox_timeline(
    track: str,
    pending_only: bool = False,
    limit: int = 50,
    since: Optional[str] = None,
    tracks_dir: Optional[Path] = None,
) -> list[dict] | dict:
    """Return a unified time-ordered list of inbox messages for a track.

    Includes (P9 unified inbox):
    - pending messages directly in inbox/ (direction=←user, status=pending)
    - consumed messages from inbox/.consumed/ (direction=←user, status=consumed) unless pending_only
    - if track=="main": orchestrator-level agent/inbox/ files too (direction=→agent, status=surfaced)

    Each entry: {timestamp, direction, status, title, filename, path}
    Sorted ascending by timestamp. Returns {"error": reason} dict on bad track.

    Args:
        track: track name (required)
        pending_only: if True, omit consumed messages
        limit: max entries to return (applied after sort + since filter)
        since: ISO timestamp string; only include entries at or after this time
        tracks_dir: override for testing
    """
    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / track
    if not track_dir.exists():
        return {"error": f"Track '{track}' not found"}

    entries: list[dict] = []

    # ── P9 unified inbox: pending messages ───────────────────────────────────
    inbox_dir = track_dir / "inbox"
    consumed_dir = inbox_dir / ".consumed"

    consumed_names: set[str] = set()
    if consumed_dir.exists():
        consumed_names = {p.name for p in consumed_dir.glob("*.md")}

    if inbox_dir.exists():
        # Only .md files directly in inbox/ (not subdirs)
        for p in inbox_dir.glob("*.md"):
            if p.name in consumed_names:
                continue
            ts = _parse_ts_from_filename(p.name)
            entries.append({
                "timestamp": ts or "-",
                "direction": "←user",
                "status": "pending",
                "title": _extract_title(p),
                "filename": p.name,
                "path": str(p.relative_to(PROJECT_ROOT)),
            })

    # ── consumed messages ─────────────────────────────────────────────────────
    if not pending_only and consumed_dir.exists():
        for p in consumed_dir.glob("*.md"):
            ts = _parse_ts_from_filename(p.name)
            entries.append({
                "timestamp": ts or "-",
                "direction": "←user",
                "status": "consumed",
                "title": _extract_title(p),
                "filename": p.name,
                "path": str(p.relative_to(PROJECT_ROOT)),
            })

    # ── orchestrator-level project inbox (main track only) ───────────────────
    # P9: agent/inbox/ is the global inbox; also surface legacy from-agent/ dir
    # during the transition period.
    if track == "main":
        orch_inbox = PROJECT_ROOT / "agent" / "inbox"
        if orch_inbox.exists():
            orch_consumed = {p.name for p in (orch_inbox / ".consumed").glob("*.md")} if (orch_inbox / ".consumed").exists() else set()
            for p in orch_inbox.glob("*.md"):
                if p.name in orch_consumed:
                    continue
                ts = _parse_ts_from_filename(p.name)
                entries.append({
                    "timestamp": ts or "-",
                    "direction": "→agent",
                    "status": "surfaced",
                    "title": _extract_title(p),
                    "filename": p.name,
                    "path": str(p.relative_to(PROJECT_ROOT)),
                })

    # ── sort, filter, limit ──────────────────────────────────────────────────
    entries.sort(key=lambda e: e["timestamp"])

    if since:
        entries = [e for e in entries if e["timestamp"] >= since]

    return entries[:limit]


# ── consume ───────────────────────────────────────────────────────────────────

_AT_FRONTMATTER_RE = re.compile(r"^at:\s*([^\s#]+)\s*$", re.MULTILINE)
_FROM_FRONTMATTER_RE = re.compile(r"^from:\s*([^\s#]+)\s*$", re.MULTILINE)


def _read_frontmatter_field(path: Path, field_re: re.Pattern) -> Optional[str]:
    """Read just the YAML frontmatter block and return the captured field."""
    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            head = fh.read(4096)
    except OSError:
        return None
    if not head.startswith("---"):
        return None
    end = head.find("\n---", 3)
    if end < 0:
        return None
    block = head[3:end]
    m = field_re.search(block)
    return m.group(1).strip() if m else None


def _file_at_timestamp(path: Path) -> str:
    """Return a sortable ISO timestamp for a pending inbox file.

    Prefers frontmatter `at:`; falls back to filename prefix; falls back to mtime.
    Empty string is returned only if all three sources fail.
    """
    at = _read_frontmatter_field(path, _AT_FRONTMATTER_RE)
    if at:
        return at
    fn_ts = _parse_ts_from_filename(path.name)
    if fn_ts:
        return fn_ts
    try:
        mt = path.stat().st_mtime
        return datetime.fromtimestamp(mt, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    except OSError:
        return ""


def _file_from_sender(path: Path) -> Optional[str]:
    """Return frontmatter `from:` field, or None if missing/unreadable."""
    return _read_frontmatter_field(path, _FROM_FRONTMATTER_RE)


def consume_inbox(
    track: str,
    *,
    file: Optional[str] = None,
    all: bool = False,
    before: Optional[str] = None,
    from_: Optional[str] = None,
    dry_run: bool = False,
    tracks_dir: Optional[Path] = None,
    wake_id: Optional[str] = None,
    source: str = "manual",
) -> dict:
    """Consume inbox messages for a track.

    Exactly one selector (file/all/before/from_) must be provided.

    Semantics (design.reflect-inbox-consume~594f2b32 §2.3):
      - mkdir -p TRACK/inbox/.consumed/
      - mv each selected file into .consumed/ (atomic on same fs)
      - emit one inbox.consumed event per move with source field
      - NO followup is created (manual consume must not inject phantom WIP)

    Returns the JSON payload shape from design §2.2:
      {
        "track": str,
        "consumed": [filename, ...],
        "skipped": [{"filename": str, "reason": str}, ...],
        "dry_run": bool,
      }
    Errors return {"error": reason} (no consumed/skipped keys).
    """
    selectors = [
        ("file", file is not None),
        ("all", bool(all)),
        ("before", before is not None),
        ("from_", from_ is not None),
    ]
    chosen = [name for name, on in selectors if on]
    if len(chosen) == 0:
        raise ConsumeArgError(
            "consume_inbox requires exactly one of: file, all, before, from_"
        )
    if len(chosen) > 1:
        raise ConsumeArgError(
            f"consume_inbox: selectors are mutually exclusive; got {chosen}"
        )

    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / track
    if not track_dir.exists():
        return {"error": f"Track '{track}' not found"}

    inbox_dir = track_dir / "inbox"
    if not inbox_dir.exists():
        return {
            "track": track,
            "consumed": [],
            "skipped": [],
            "dry_run": bool(dry_run),
        }
    consumed_dir = inbox_dir / ".consumed"

    consumed_names: set[str] = set()
    if consumed_dir.exists():
        consumed_names = {p.name for p in consumed_dir.glob("*.md")}

    # Build candidate set of pending files directly in inbox/.
    pending = [
        p for p in sorted(inbox_dir.glob("*.md"))
        if p.is_file() and p.name not in consumed_names
    ]

    # Apply selector.
    if file is not None:
        candidate = inbox_dir / file
        if not candidate.is_file():
            return {
                "track": track,
                "consumed": [],
                "skipped": [{"filename": file, "reason": "not-found"}],
                "dry_run": bool(dry_run),
            }
        if file in consumed_names:
            return {
                "track": track,
                "consumed": [],
                "skipped": [{"filename": file, "reason": "already-consumed"}],
                "dry_run": bool(dry_run),
            }
        selected = [candidate]
    elif all:
        selected = pending
    elif before is not None:
        selected = [p for p in pending if _file_at_timestamp(p) and _file_at_timestamp(p) < before]
    else:  # from_ is not None
        selected = [p for p in pending if _file_from_sender(p) == from_]

    # Dry-run: report and return without moving.
    if dry_run:
        return {
            "track": track,
            "consumed": [p.name for p in selected],
            "skipped": [],
            "dry_run": True,
        }

    # Live: mkdir consumed_dir, then atomic-move each. Race-tolerant: a
    # concurrent auto-sweep (or another consume call) may have already moved
    # a file; record skipped=not-found rather than crash.
    consumed_dir.mkdir(parents=True, exist_ok=True)
    consumed: list[str] = []
    skipped: list[dict] = []
    for p in selected:
        dest = consumed_dir / p.name
        try:
            p.rename(dest)
        except FileNotFoundError:
            skipped.append({"filename": p.name, "reason": "not-found"})
            continue
        except OSError as e:
            skipped.append({"filename": p.name, "reason": f"os-error: {e}"})
            continue
        consumed.append(p.name)
        # Emit inbox.consumed event (fire-and-forget; never raises).
        try:
            from agent.runtime.events import emit_inbox_consumed
            emit_inbox_consumed(
                track=track,
                consumed_path=dest,
                wake_id=wake_id,
                source=source,
            )
        except Exception:
            pass

    return {
        "track": track,
        "consumed": consumed,
        "skipped": skipped,
        "dry_run": False,
    }
