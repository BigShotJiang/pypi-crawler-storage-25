"""Schedule inspection operations — list, show, next.

Read-only surface over `agent/runtime/tracks/<track>/schedule/<id>.yaml`
files. Mirrors the firing logic in [agent/lib/tick.py](/agent/lib/tick.py)
for next-fire calculation, but does NOT fire or modify any schedule.

Phase 1 ships read-only: a write surface (set/delete) is a separate
future directive once demand emerges. Schedule YAML files stay
hand-edited or maintained by the YAML emitter in
[agent/lib/yaml_io.py](/agent/lib/yaml_io.py).

CLI surface lives in [agent/cli/schedule.py](/agent/cli/schedule.py);
the MCP surface mirrors the same shape in
[agent/mcp/server.py](/agent/mcp/server.py).
"""

from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import yaml

from agent.cli.ops.root import resolve_project_root


# ── Path helpers ──────────────────────────────────────────────────────────────


def _tracks_dir(tracks_dir: Optional[Path] = None) -> Path:
    """Resolve the tracks directory (override-friendly for tests)."""
    if tracks_dir is not None:
        return tracks_dir
    return resolve_project_root() / "agent" / "runtime" / "tracks"


# ── Interval parsing (mirrors tick.py for cross-process consistency) ─────────


def _parse_interval(s: str) -> timedelta:
    """Parse interval strings like '7d', '24h', '15m', '600s'.

    Mirrors `agent.lib.tick._parse_interval` semantics. Local copy keeps
    this module independent of tick.py for use in environments where
    croniter (a tick.py transitive dep) isn't installed.
    """
    s = s.strip().lower()
    if not s:
        raise ValueError("empty interval string")
    unit = s[-1]
    try:
        value = int(s[:-1])
    except ValueError as e:
        raise ValueError(f"invalid interval '{s}'") from e
    if unit == "s":
        return timedelta(seconds=value)
    if unit == "m":
        return timedelta(minutes=value)
    if unit == "h":
        return timedelta(hours=value)
    if unit == "d":
        return timedelta(days=value)
    raise ValueError(f"unknown interval unit '{unit}' in '{s}'")


def _humanize_delta(seconds: int) -> str:
    """Human-friendly delta. Negative = past, positive = future."""
    abs_s = abs(seconds)
    if abs_s < 60:
        body = f"{abs_s}s"
    elif abs_s < 3600:
        body = f"{abs_s // 60}m"
    elif abs_s < 86400:
        h = abs_s // 3600
        m = (abs_s % 3600) // 60
        body = f"{h}h {m}m" if m else f"{h}h"
    else:
        d = abs_s // 86400
        h = (abs_s % 86400) // 3600
        body = f"{d}d {h}h" if h else f"{d}d"
    return f"{body} ago" if seconds < 0 else f"in {body}"


# ── Core: load + enrich one schedule ──────────────────────────────────────────


def _parse_iso(s: str) -> Optional[datetime]:
    """Parse ISO 8601 timestamp; return None on failure."""
    if not s:
        return None
    try:
        return datetime.fromisoformat(str(s).rstrip("Z").replace("+00:00", ""))
    except (ValueError, TypeError):
        return None


def _compute_next_fire(schedule: dict, *, now: Optional[datetime] = None) -> Optional[datetime]:
    """Compute the next scheduled fire time (naive UTC) or None if unknown."""
    if now is None:
        now = datetime.utcnow()

    last_dt = _parse_iso(schedule.get("last_fired_at", ""))

    if "cron" in schedule:
        try:
            from croniter import croniter
        except ImportError:
            return None
        anchor = last_dt or now
        try:
            cron = croniter(str(schedule["cron"]), anchor)
            return cron.get_next(datetime)
        except (ValueError, KeyError):
            return None

    if "interval" in schedule:
        try:
            delta = _parse_interval(str(schedule["interval"]))
        except ValueError:
            return None
        if last_dt is None:
            return now  # never fired → due now
        return last_dt + delta

    return None


def _load_schedule_file(schedule_file: Path) -> Optional[dict]:
    """Load a schedule YAML file, returning None if unparseable."""
    try:
        data = yaml.safe_load(schedule_file.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return None
    if not isinstance(data, dict):
        return None
    return data


def _enrich(track: str, schedule_file: Path, *, now: Optional[datetime] = None) -> Optional[dict]:
    """Build the structured schedule record (raw fields + computed fields).

    Returns None for unparseable or non-dict YAML files. Malformed but
    parseable files are returned with computed fields set to None so the
    caller can surface "broken" rows for operator attention.
    """
    data = _load_schedule_file(schedule_file)
    if data is None:
        return None

    if now is None:
        now = datetime.utcnow()

    last_dt = _parse_iso(data.get("last_fired_at", ""))
    next_dt = _compute_next_fire(data, now=now)

    desc_full = str(data.get("description", "") or "").strip()
    desc_short = desc_full.split("\n")[0]
    if len(desc_short) > 80:
        desc_short = desc_short[:77] + "..."

    record: dict = {
        "track": track,
        "id": data.get("id", schedule_file.stem),
        "path": str(schedule_file),
        "recipient": data.get("recipient", track),
        "enabled": bool(data.get("enabled", True)),
        "cron": data.get("cron"),
        "interval": data.get("interval"),
        "last_fired_at": data.get("last_fired_at"),
        "description": desc_short,
        "description_full": desc_full,
        "next_fire": (
            next_dt.strftime("%Y-%m-%dT%H:%M:%SZ") if next_dt else None
        ),
        "time_since_last_fire": (
            _humanize_delta(int((last_dt - now).total_seconds()))
            if last_dt is not None else None
        ),
        "time_until_next_fire": (
            _humanize_delta(int((next_dt - now).total_seconds()))
            if next_dt is not None else None
        ),
    }
    return record


# ── Public surface ────────────────────────────────────────────────────────────


def list_schedules(
    *,
    track: Optional[str] = None,
    tracks_dir: Optional[Path] = None,
    now: Optional[datetime] = None,
) -> dict:
    """Enumerate all schedules across tracks (or filtered to one track).

    Returns:
      {
        "schedules": [record, ...],
        "tracks_without_schedule": [name, ...],
        "tracks_scanned": int,
      }
    """
    td = _tracks_dir(tracks_dir)
    if not td.exists():
        return {"schedules": [], "tracks_without_schedule": [], "tracks_scanned": 0}

    if track is not None:
        track_dirs = [td / track]
        if not track_dirs[0].exists():
            return {
                "schedules": [],
                "tracks_without_schedule": [],
                "tracks_scanned": 0,
                "error": f"track '{track}' not found",
            }
    else:
        track_dirs = sorted(
            (p for p in td.iterdir() if p.is_dir() and not p.name.startswith(".")),
            key=lambda p: p.name,
        )

    schedules: list[dict] = []
    no_schedule: list[str] = []
    scanned = 0

    for tdir in track_dirs:
        scanned += 1
        sdir = tdir / "schedule"
        if not sdir.is_dir():
            no_schedule.append(tdir.name)
            continue
        files = sorted(sdir.glob("*.yaml"))
        if not files:
            no_schedule.append(tdir.name)
            continue
        for sf in files:
            rec = _enrich(tdir.name, sf, now=now)
            if rec is not None:
                schedules.append(rec)

    return {
        "schedules": schedules,
        "tracks_without_schedule": no_schedule,
        "tracks_scanned": scanned,
    }


def show_schedule(
    track: str,
    schedule_id: Optional[str] = None,
    *,
    tracks_dir: Optional[Path] = None,
    now: Optional[datetime] = None,
) -> dict:
    """Show a single schedule's detail record.

    If schedule_id is omitted and the track has exactly one schedule,
    return that one. If multiple, return an error with the available IDs.

    Returns:
      {"schedule": record}  on success
      {"error": str, ...}   on failure
    """
    td = _tracks_dir(tracks_dir)
    tdir = td / track
    if not tdir.exists():
        return {"error": f"track '{track}' not found"}
    sdir = tdir / "schedule"
    if not sdir.is_dir():
        return {"error": f"track '{track}' has no schedule directory"}

    files = sorted(sdir.glob("*.yaml"))
    if not files:
        return {"error": f"track '{track}' has no schedule files"}

    if schedule_id is None:
        if len(files) == 1:
            sf = files[0]
        else:
            ids = [f.stem for f in files]
            return {
                "error": f"track '{track}' has {len(files)} schedules; specify one of: {', '.join(ids)}",
                "available": ids,
            }
    else:
        sf = sdir / f"{schedule_id}.yaml"
        if not sf.exists():
            ids = [f.stem for f in files]
            return {
                "error": f"schedule '{schedule_id}' not found for track '{track}'",
                "available": ids,
            }

    rec = _enrich(track, sf, now=now)
    if rec is None:
        return {"error": f"schedule file {sf} is unparseable"}

    # Include raw YAML text for --yaml mode callers
    try:
        rec["raw_yaml"] = sf.read_text(encoding="utf-8")
    except OSError:
        rec["raw_yaml"] = None
    return {"schedule": rec}


def next_schedules(
    *,
    track: Optional[str] = None,
    limit: int = 5,
    tracks_dir: Optional[Path] = None,
    now: Optional[datetime] = None,
) -> dict:
    """Return the top-N schedules sorted by next-fire ascending.

    Schedules with no computable next_fire (cron when croniter is missing,
    malformed interval) are excluded from the sort but counted in the
    `skipped` field of the response.

    Returns:
      {
        "schedules": [record, ...],  # at most `limit` entries
        "skipped": int,              # count of un-rankable schedules
      }
    """
    listing = list_schedules(track=track, tracks_dir=tracks_dir, now=now)
    if "error" in listing:
        return listing
    rankable = [s for s in listing["schedules"] if s.get("next_fire")]
    skipped = len(listing["schedules"]) - len(rankable)
    rankable.sort(key=lambda s: s["next_fire"])
    return {
        "schedules": rankable[:limit],
        "skipped": skipped,
        "tracks_scanned": listing.get("tracks_scanned", 0),
    }
