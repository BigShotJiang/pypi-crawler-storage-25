"""Events subcommands for the reflect CLI.

Provides three commands:
  reflect events list   — show recent events (filterable)
  reflect events since  — show events since a timestamp
  reflect events tail   — follow the live event stream
"""
from __future__ import annotations

import json
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Iterator, Optional


# ── Path helpers ──────────────────────────────────────────────────────────────


def _runtime_root() -> Path:
    """Resolve agent/runtime/ from this file's location."""
    return Path(__file__).parent.parent / "runtime"


def _events_dir() -> Path:
    return _runtime_root() / "events"


def _symlink_path() -> Path:
    return _runtime_root() / "events.jsonl"


# ── Timestamp parsing ─────────────────────────────────────────────────────────


def _parse_ts(ts: str) -> datetime:
    """Parse an ISO-8601 timestamp to a UTC-aware datetime.

    Accepts trailing Z or +00:00. Raises ValueError on bad input.
    """
    ts = ts.strip()
    if ts.endswith("Z"):
        ts = ts[:-1] + "+00:00"
    dt = datetime.fromisoformat(ts)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _file_date(path: Path) -> date:
    """Extract date from YYYY-MM-DD.jsonl filename; returns date.min on failure."""
    try:
        return datetime.strptime(path.stem, "%Y-%m-%d").date()
    except ValueError:
        return date.min


# ── Event reading ─────────────────────────────────────────────────────────────


def _daily_files_since(since_dt: Optional[datetime]) -> list[Path]:
    """Return sorted list of daily .jsonl files, filtered by since_dt date."""
    events_dir = _events_dir()
    if not events_dir.is_dir():
        return []
    files = sorted(
        (p for p in events_dir.glob("*.jsonl")),
        key=lambda p: p.name,
    )
    if since_dt is not None:
        cutoff = since_dt.date()
        files = [f for f in files if _file_date(f) >= cutoff]
    return files


def _read_file(
    path: Path,
    since_dt: Optional[datetime] = None,
    track: Optional[str] = None,
    event_type: Optional[str] = None,
) -> Iterator[dict]:
    """Yield parsed event dicts from a JSONL file, with optional filtering."""
    if not path.exists():
        return
    with path.open(errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if since_dt is not None:
                try:
                    event_dt = _parse_ts(event.get("at", ""))
                    if event_dt < since_dt:
                        continue
                except Exception:
                    pass  # malformed at: include anyway
            if track is not None and event.get("track") != track:
                continue
            if event_type is not None and event.get("type") != event_type:
                continue
            yield event


def _current_file() -> Optional[Path]:
    """Resolve the symlink or fall back to today's YYYY-MM-DD.jsonl."""
    sym = _symlink_path()
    if sym.is_symlink():
        target = sym.resolve()
        if target.exists():
            return target
    # Fallback: today's filename
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    p = _events_dir() / f"{today}.jsonl"
    return p if p.exists() else None


# ── Formatting ────────────────────────────────────────────────────────────────

_TYPE_PAD = 25


def _payload_summary(event: dict) -> str:
    etype = event.get("type", "")
    p = event.get("payload", {})
    if etype == "wake.started":
        return f"pid={p.get('pid','?')} src={p.get('kickoff_source','?')}"
    if etype == "wake.completed":
        dur = p.get("duration_seconds", "?")
        cost = p.get("cost_usd", "?")
        turns = p.get("num_turns", "?")
        return f"dur={dur}s cost=${cost} turns={turns}"
    if etype == "wake.failed":
        return f"reason={p.get('early_break_reason','?')} exit={p.get('exit_code','?')}"
    if etype == "wake.scheduled":
        return f"next_in={p.get('next_wake_in_seconds','?')}s"
    if etype == "commit.made":
        sha = str(p.get("sha", "?"))[:8]
        msg = str(p.get("message", "?"))[:40]
        return f"sha={sha} {msg!r}"
    if etype == "inbox.delivered":
        return f"to={p.get('to_track','?')} subj={p.get('subject','?')!r}"
    if etype == "inbox.consumed":
        return f"path={p.get('path','?')}"
    if etype in ("track.idle", "track.running"):
        return f"pid={p.get('pid','?')}" if etype == "track.running" else ""
    if etype == "track.wedged":
        v = p.get("violations", [])
        return f"violations={len(v)}"
    if etype == "originator.requested":
        return f"subj={p.get('subject','?')!r}"
    if etype == "cost.threshold":
        return f"threshold=${p.get('threshold_usd','?')} current=${p.get('current_usd','?')}"
    return ""


def _format_human(event: dict) -> str:
    at = event.get("at", "")[:19].replace("T", " ")
    etype = event.get("type", "?")
    track = event.get("track", "?")
    summary = _payload_summary(event)
    parts = [f"{at}", f"{etype:<{_TYPE_PAD}}", f"[{track}]"]
    if summary:
        parts.append(summary)
    return "  ".join(parts)


# ── Commands ──────────────────────────────────────────────────────────────────


def cmd_events_list(args) -> None:
    """List recent events. Supports --since, --track, --type, --limit."""
    from .output import OutputMode

    mode = OutputMode(args.output)
    since_dt: Optional[datetime] = None
    if getattr(args, "since", None):
        try:
            since_dt = _parse_ts(args.since)
        except ValueError as exc:
            print(f"reflect events: invalid --since value: {exc}", file=sys.stderr)
            sys.exit(1)

    limit: int = getattr(args, "limit", 50)
    track: Optional[str] = getattr(args, "track", None)
    event_type: Optional[str] = getattr(args, "event_type", None)

    all_events: list[dict] = []
    for path in _daily_files_since(since_dt):
        all_events.extend(_read_file(path, since_dt, track, event_type))

    # Sort by timestamp (events across files may not be globally ordered if
    # multiple tracks write simultaneously).
    all_events.sort(key=lambda e: e.get("at", ""))

    # When no since filter, honour limit (most recent N).
    if limit > 0 and since_dt is None:
        all_events = all_events[-limit:]

    if mode == OutputMode.JSON:
        print(json.dumps(all_events, indent=2))
        return

    if not all_events:
        print("(no events)")
        return

    for ev in all_events:
        print(_format_human(ev))


def cmd_events_since(args) -> None:
    """Show all events on or after a timestamp. Positional convenience for list --since."""
    # args.since is already set by the positional argument in main.py.
    args.limit = 0  # no cap — since implies "everything from that point"
    cmd_events_list(args)


def cmd_events_tail(args) -> None:
    """Follow the live event stream (like tail -f on events.jsonl)."""
    from .output import OutputMode

    mode = OutputMode(args.output)
    track: Optional[str] = getattr(args, "track", None)
    event_type: Optional[str] = getattr(args, "event_type", None)
    no_follow: bool = getattr(args, "no_follow", False)
    lines: int = getattr(args, "lines", 20)

    # Reconfigure stdout to line-buffered so each emitted event reaches a
    # non-TTY consumer (pipe, `| cat`, monitor process) the moment it is
    # printed. Without this, Python block-buffers stdout when it is not a
    # TTY and events sit in the buffer until process exit or a multi-KB
    # threshold is hit — which makes follow-mode unusable from a pipe.
    # Safe to call unconditionally; on a TTY stdout is already
    # line-buffered.
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except (AttributeError, ValueError):
        # Some non-TextIOWrapper stdout replacements (test capture, etc.)
        # do not expose reconfigure. Fall back to relying on the
        # per-print flush=True calls below.
        pass

    def matches(event: dict) -> bool:
        if track is not None and event.get("track") != track:
            return False
        if event_type is not None and event.get("type") != event_type:
            return False
        return True

    def emit(event: dict, flush: bool = True) -> None:
        # flush=True by default — every emitted event reaches the
        # consumer immediately, including priming events. See the
        # reconfigure() call above; this flush=True is the belt to that
        # suspenders, so the behavior holds even if reconfigure failed.
        if mode == OutputMode.JSON:
            print(json.dumps(event), flush=flush)
        else:
            print(_format_human(event), flush=flush)

    # --- Print last N events from the current file ---
    cf = _current_file()
    if cf is None:
        if no_follow:
            print("(no events yet)", flush=True)
            return
        # No file yet — jump straight to follow loop
    else:
        recent = list(_read_file(cf, track=track, event_type=event_type))
        for ev in recent[-lines:]:
            emit(ev)

    if no_follow:
        return

    # --- Follow loop ---
    cf = _current_file()
    pos: int = cf.stat().st_size if cf is not None and cf.exists() else 0
    last_date: date = datetime.now(timezone.utc).date()

    try:
        while True:
            # Day-rollover check
            today = datetime.now(timezone.utc).date()
            if today != last_date:
                last_date = today
                cf = _current_file()
                pos = 0

            if cf is None or not cf.exists():
                cf = _current_file()
                time.sleep(0.5)
                continue

            size = cf.stat().st_size
            if size > pos:
                with cf.open(errors="replace") as fh:
                    fh.seek(pos)
                    for line in fh:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            event = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        if matches(event):
                            emit(event)  # emit() defaults to flush=True
                    pos = fh.tell()
            elif size < pos:
                # File was rotated / truncated
                pos = 0

            time.sleep(0.2)
    except KeyboardInterrupt:
        pass
