"""Dashboard subcommand — launches the live multi-track TUI.

Bundled-polish item 2 (originator directive 2026-05-20T08:37Z): `q` in
the inbox surface closes only the inbox view, not the dashboard. The
inbox TUI exits on `q` (its built-in quit action); we loop back to a
fresh dashboard instance instead of returning to the shell.

`q` in the main dashboard still exits to the shell (DashboardApp.exit()
returns None when triggered by `q`; a non-None return value means the
operator pressed `i` and named a track for the inbox surface).
"""
from __future__ import annotations
from pathlib import Path
from .ops.track import TRACKS_DIR


def cmd_dashboard(args) -> None:
    from .tui.dashboard_app import DashboardApp
    from .tui.inbox_app import InboxApp
    while True:
        app = DashboardApp(tracks_dir=TRACKS_DIR)
        result = app.run()
        if not result:
            # `q` in main dashboard — exit to shell.
            return
        # `i` in main dashboard — open inbox TUI for `result` track.
        track_dir = TRACKS_DIR / result
        inbox_dir = track_dir / "inbox"
        if inbox_dir.exists():
            inbox_app = InboxApp(track=result, inbox_dir=inbox_dir)
            inbox_app.run()
        # When the inbox TUI exits (including `q`), loop back to a fresh
        # dashboard. Only `q` in the main dashboard breaks out.
