"""Followup subcommands for the reflect CLI.

Implements M1 of the blocked-followup escape hatch
(design.blocked-followup-state~2efaa40e). Subcommands:

  reflect followup block   <name> [--track NAME]
  reflect followup unblock <name> [--track NAME]
  reflect followup list           [--track NAME]

Default track resolution: --track flag, then $REFLECT_TRACK env. The
move primitive lives in agent.cli.ops.followup; this module is the
CLI surface that formats output for human + JSON modes.
"""
from __future__ import annotations

import json
import sys

from .output import OutputMode
from .ops.followup import (
    block_followup,
    unblock_followup,
    list_followups,
)


_ERROR_EXIT_CODES = {
    "argument": 2,
    "track_not_found": 3,
    "not_found": 4,
    "ambiguous": 5,
    "io_error": 6,
}


def _emit(result: dict, mode: OutputMode) -> int:
    if mode == OutputMode.JSON:
        print(json.dumps(result, indent=2))
    else:
        if result.get("ok"):
            _render_human_success(result)
        else:
            print(
                f"error: {result.get('message', result.get('error', 'unknown'))}",
                file=sys.stderr,
            )

    if result.get("ok"):
        return 0
    return _ERROR_EXIT_CODES.get(result.get("error", ""), 1)


def _render_human_success(result: dict) -> None:
    if "active" in result and "blocked" in result:
        # list output
        track = result["track"]
        active = result["active"]
        blocked = result["blocked"]
        print(f"track: {track}")
        print(f"active ({len(active)}):")
        if active:
            for n in active:
                print(f"  {n}")
        else:
            print("  (none)")
        print(f"blocked ({len(blocked)}):")
        if blocked:
            for n in blocked:
                print(f"  {n}")
        else:
            print("  (none)")
        return

    # block / unblock output
    track = result["track"]
    name = result["name"]
    state = result["state"]
    moved = result.get("moved", False)
    verb = "moved" if moved else "already"
    print(f"{verb}: {track}/followup/{name} → state={state}")


def cmd_followup_block(args) -> None:
    mode = OutputMode(args.output)
    result = block_followup(args.name, track=getattr(args, "track", None))
    sys.exit(_emit(result, mode))


def cmd_followup_unblock(args) -> None:
    mode = OutputMode(args.output)
    result = unblock_followup(args.name, track=getattr(args, "track", None))
    sys.exit(_emit(result, mode))


def cmd_followup_list(args) -> None:
    mode = OutputMode(args.output)
    result = list_followups(track=getattr(args, "track", None))
    sys.exit(_emit(result, mode))
