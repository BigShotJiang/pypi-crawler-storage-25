"""Schedule inspection subcommands for the reflect CLI.

Read-only surface over `agent/runtime/tracks/<track>/schedule/<id>.yaml`.
Phase 1 implements list, show, next — see
[agent/cli/ops/schedule.py](/agent/cli/ops/schedule.py) for the core
logic. A write surface (set/delete) is deferred per the Phase 1
directive.
"""
from __future__ import annotations

import json
import sys
from typing import Optional

from .output import OutputMode
from .ops.schedule import list_schedules, show_schedule, next_schedules


# ── Human-mode rendering ──────────────────────────────────────────────────────


_LIST_HEADER = (
    "TRACK                          SCHEDULE-ID                    "
    "CRON/INTERVAL    LAST FIRED           NEXT FIRE"
)
_LIST_SEP = "─" * 110


def _fmt_short(s: Optional[str], width: int) -> str:
    """Truncate-or-pad a string to exactly `width` chars."""
    if s is None:
        return "—".ljust(width)
    s = str(s)
    if len(s) > width:
        return s[: width - 1] + "…"
    return s.ljust(width)


def _fmt_row(rec: dict) -> str:
    spec = rec.get("cron") or rec.get("interval") or "?"
    last = rec.get("last_fired_at") or "—"
    nxt = rec.get("next_fire") or "—"
    return (
        f"{_fmt_short(rec.get('track'), 30)} "
        f"{_fmt_short(rec.get('id'), 30)} "
        f"{_fmt_short(spec, 16)} "
        f"{_fmt_short(last, 20)} "
        f"{_fmt_short(nxt, 20)}"
    )


def _print_list_table(records: list[dict], no_schedule_count: int) -> None:
    if not records:
        print("(no schedules found)")
    else:
        print(_LIST_HEADER)
        print(_LIST_SEP)
        for rec in records:
            line = _fmt_row(rec)
            if not rec.get("enabled", True):
                line = f"{line}  [disabled]"
            print(line)
    if no_schedule_count:
        print(f"\n({no_schedule_count} tracks have no schedule)")


def _print_show_detail(rec: dict, *, raw_yaml: bool = False) -> None:
    if raw_yaml:
        print(rec.get("raw_yaml", "(no raw YAML available)").rstrip())
        return

    spec = rec.get("cron") or rec.get("interval") or "(missing)"
    spec_kind = "cron" if rec.get("cron") else "interval" if rec.get("interval") else "?"
    print(f"track:          {rec.get('track')}")
    print(f"id:             {rec.get('id')}")
    print(f"recipient:      {rec.get('recipient')}")
    print(f"enabled:        {rec.get('enabled')}")
    print(f"{spec_kind}:           {spec}")
    print(f"last_fired_at:  {rec.get('last_fired_at') or '—'}")
    if rec.get("time_since_last_fire"):
        print(f"  (since:       {rec['time_since_last_fire']})")
    print(f"next_fire:      {rec.get('next_fire') or '—'}")
    if rec.get("time_until_next_fire"):
        print(f"  (in:          {rec['time_until_next_fire']})")
    desc = rec.get("description") or ""
    if desc:
        print(f"description:    {desc}")
    print(f"path:           {rec.get('path')}")


# ── Command handlers ──────────────────────────────────────────────────────────


def _emit_json(payload: dict) -> int:
    print(json.dumps(payload, indent=2, default=str))
    return 0 if "error" not in payload else 4


def cmd_schedule_list(args) -> None:
    mode = OutputMode(args.output)
    result = list_schedules(track=getattr(args, "track", None))
    if mode == OutputMode.JSON:
        sys.exit(_emit_json(result))
    if "error" in result:
        print(f"error: {result['error']}", file=sys.stderr)
        sys.exit(3)
    _print_list_table(
        result["schedules"],
        len(result.get("tracks_without_schedule", [])),
    )
    sys.exit(0)


def cmd_schedule_show(args) -> None:
    mode = OutputMode(args.output)
    track = args.track
    schedule_id = getattr(args, "schedule_id", None)
    yaml_mode = bool(getattr(args, "yaml", False))
    result = show_schedule(track, schedule_id)
    if mode == OutputMode.JSON:
        sys.exit(_emit_json(result))
    if "error" in result:
        print(f"error: {result['error']}", file=sys.stderr)
        if result.get("available"):
            print(
                "available schedules: " + ", ".join(result["available"]),
                file=sys.stderr,
            )
        sys.exit(3)
    _print_show_detail(result["schedule"], raw_yaml=yaml_mode)
    sys.exit(0)


def cmd_schedule_next(args) -> None:
    mode = OutputMode(args.output)
    limit = getattr(args, "limit", 5) or 5
    result = next_schedules(track=getattr(args, "track", None), limit=limit)
    if mode == OutputMode.JSON:
        sys.exit(_emit_json(result))
    if "error" in result:
        print(f"error: {result['error']}", file=sys.stderr)
        sys.exit(3)
    _print_list_table(result["schedules"], 0)
    if result.get("skipped"):
        print(
            f"\n({result['skipped']} schedules excluded — no computable next-fire)"
        )
    sys.exit(0)
