"""Dashboard TUI — live multi-track status for reflect dashboard.

Design notes:
- Polling model: set_interval(1.0, ...) for table refresh, 500ms for tail view.
  No inotify — deliberate choice. Keeps deps minimal and works on NFS/remote
  filesystems without kernel-level FS event support.
- Cost column reads /tmp/reflect-wake-cost-{track}.json for {"usd": float}.
  This file is not yet written by the wake runtime — column always shows '-'
  until wired up. Lazy approach by design: the file is optional.
- Expand/collapse rebuilds table rows (simplest DataTable approach — clear +
  re-add). DataTable doesn't support nested rows natively.
"""
from __future__ import annotations

import asyncio
import json
import os
import subprocess
import time
import zlib
from pathlib import Path
from typing import Optional

import yaml

from rich.text import Text
from textual.app import App, ComposeResult, Screen
from textual.binding import Binding
from textual.events import Key
from textual.widgets import DataTable, Header, Input, Label, Static
from textual.containers import Vertical, VerticalScroll


# ── helpers ────────────────────────────────────────────────────────────────


def _is_pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _read_lock_pid(lock_path: Path) -> Optional[int]:
    try:
        content = lock_path.read_text().strip()
        for line in content.splitlines():
            line = line.strip()
            if line.isdigit():
                return int(line)
    except (OSError, ValueError):
        pass
    return None


def _track_state(track_dir: Path) -> str:
    from agent.cli.ops.track import _resolve_track_state
    return _resolve_track_state(track_dir)


_STATE_ICON = {
    "running": "●",
    "paused": "⏸",
    "idle": "◌",
    "disabled": "⊘",
    "disabled · running": "⊘●",
    "disabled · paused": "⊘⏸",
}


def _fmt_runtime(last_wake_start_path: Path) -> str:
    try:
        epoch = float(last_wake_start_path.read_text().strip())
        elapsed = int(time.time() - epoch)
        if elapsed < 0:
            return "-"
        mins, secs = divmod(elapsed, 60)
        if mins:
            return f"{mins}m{secs:02d}s"
        return f"{secs}s"
    except (OSError, ValueError):
        return "-"


def _fmt_activity(track_name: str) -> str:
    log_path = Path(f"/tmp/reflect-tick-{track_name}.log")
    try:
        lines = log_path.read_text().splitlines()[-20:]
    except OSError:
        return "-"
    emoji_starts = "🔧🧠💭📝🔍✅❌⚡🌐📦🗂️💡🚀📊"
    for line in reversed(lines):
        if line and line[0] in emoji_starts:
            return line[:30]
    return "-"


def _fmt_cost(track_name: str) -> str:
    cost_path = Path(f"/tmp/reflect-wake-cost-{track_name}.json")
    try:
        data = json.loads(cost_path.read_text())
        usd = float(data.get("usd", 0.0))
        return f"${usd:.4f}"
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        return "-"


def _unread_count(track_dir: Path) -> int:
    """Count unread inbox messages. P9: reads from inbox/ (unified), not inbox/from-originator/."""
    inbox_dir = track_dir / "inbox"
    if not inbox_dir.exists():
        return 0
    consumed_dir = inbox_dir / ".consumed"
    # Only count .md files directly in inbox/, not subdirs
    all_md = {p.name for p in inbox_dir.glob("*.md")}
    consumed_md: set[str] = set()
    if consumed_dir.exists():
        consumed_md = {p.name for p in consumed_dir.glob("*.md")}
    return len(all_md - consumed_md)


def _followup_count(track_dir: Path) -> int:
    """Count active (non-completed, non-blocked) followups for a track.

    Per protocol P9: followup/*.md is active work; followup/.completed/ and
    followup/blocked-on-trigger/ are excluded. Other dotfile subdirs are
    excluded by the top-level .md glob.
    """
    followup_dir = track_dir / "followup"
    if not followup_dir.exists():
        return 0
    return sum(1 for _ in followup_dir.glob("*.md"))


def _dispatch_status() -> str:
    log = Path("/tmp/reflect-dispatch.log")
    try:
        mtime = log.stat().st_mtime
        ago = int(time.time() - mtime)
        if ago > 300:
            return f"⚠ stale ({ago}s ago)"
        return f"✓ {ago}s ago"
    except OSError:
        return "⚠ no log"


# v0.4.78 item 29 (originator 2026-05-20T11:36Z): per-track active
# deliverable file. Workers self-declare their current deliverable by
# writing `agent/runtime/tracks/<track>/state/active-deliverable.yaml`
# (schema: {deliverable: <id>, set_at: <ts>}). The dashboard reads it
# read-only and displays the slug portion. Absence ⇒ "ambient" (the
# track is not scoped to a specific deliverable).
_AMBIENT_DELIVERABLE = "ambient"


def _active_deliverable(track_dir: Path) -> str:
    """Read state/active-deliverable.yaml; return the deliverable slug.

    Returns the slug portion of the ID (between the leading kind prefix
    and the trailing ``~hash``). When the file is missing, malformed,
    or the value is null/blank, returns the ``_AMBIENT_DELIVERABLE``
    sentinel so the cell renders as a clear non-scoped indicator.

    Example: ``deliverable.customer-instance-d4~abcd1234`` → ``customer-instance-d4``.
    """
    p = track_dir / "state" / "active-deliverable.yaml"
    try:
        if not p.exists():
            return _AMBIENT_DELIVERABLE
        data = yaml.safe_load(p.read_text())
    except (OSError, yaml.YAMLError):
        return _AMBIENT_DELIVERABLE
    if not isinstance(data, dict):
        return _AMBIENT_DELIVERABLE
    raw = data.get("deliverable")
    if not isinstance(raw, str) or not raw.strip():
        return _AMBIENT_DELIVERABLE
    slug = raw.strip()
    # Strip the canonical ``deliverable.`` prefix when present so the
    # column reads as `customer-instance-d4` rather than
    # `deliverable.customer-instance-d4~hash`.
    if "." in slug:
        # Match the loose kind-prefix convention: kind.slug~hash. We
        # split on the first dot — anything before is the kind tag.
        prefix, _, after = slug.partition(".")
        # Only strip when the prefix looks like a scry kind tag
        # (lowercase letters / dashes only) — leaves arbitrary user
        # strings untouched.
        if prefix and prefix.replace("-", "").isalpha():
            slug = after
    if "~" in slug:
        slug = slug.split("~", 1)[0]
    return slug or _AMBIENT_DELIVERABLE


# v0.4.77 item 23: column-sort sortable column names. The set determines
# which `sort_column` config values are honored on load.
# v0.4.78 item 29: `deliverable` joins the sortable set so the
# active-deliverable column can be hotkey-sorted alongside the others.
_SORTABLE_COLUMNS = frozenset(
    {"name", "activity", "runtime", "inbox", "followup", "cost", "state", "deliverable"}
)

# Triage-rank for state sort (item 23). Lower rank floats to top in `asc`
# direction; running first, disabled last. Matches the default-sort
# grouping in _sort_key.
_STATE_RANK = {
    "running": 0, "disabled · running": 0,
    "paused": 1, "disabled · paused": 1,
    "stale-lock": 2,
    "idle": 3,
    "disabled": 4,
}


def _sort_value(name: str, column: str, state: str, track_dir: Path):
    """Return a comparable value for sort `column` on track `name`.

    Designed for use as a key fn in `sorted()`. All branches return a
    (primary, name) tuple so ties break by track name — deterministic
    across reloads. `column` must be a member of `_SORTABLE_COLUMNS`;
    caller is expected to validate.
    """
    if column == "name":
        return (name.lower(), name)
    if column == "state":
        return (_STATE_RANK.get(state, 99), name.lower())
    if column == "activity":
        lw_path = track_dir / "last-wake.timestamp"
        try:
            ts = int(lw_path.read_text().strip())
        except (OSError, ValueError):
            ts = 0
        # Larger ts → more recent; we want recent first in `asc` direction,
        # so negate. Direction-flip in _refresh_table then puts oldest first
        # on `desc`. This matches the originator's mental model "sort by
        # last activity — newest first by default".
        return (-ts, name.lower())
    if column == "runtime":
        lw_start = track_dir / "last-wake-start.timestamp"
        try:
            epoch = float(lw_start.read_text().strip())
            elapsed = max(0, int(time.time() - epoch))
        except (OSError, ValueError):
            elapsed = -1  # tracks without runtime sort to the bottom in asc
        return (elapsed, name.lower())
    if column == "inbox":
        return (_unread_count(track_dir), name.lower())
    if column == "followup":
        return (_followup_count(track_dir), name.lower())
    if column == "cost":
        cost_path = Path(f"/tmp/reflect-wake-cost-{name}.json")
        try:
            data = json.loads(cost_path.read_text())
            usd = float(data.get("usd", 0.0))
        except (OSError, ValueError, KeyError, json.JSONDecodeError):
            usd = -1.0
        return (usd, name.lower())
    if column == "deliverable":
        # Sort lexically by slug. The `_AMBIENT_DELIVERABLE` sentinel
        # ("ambient") sorts among its alphabetical neighbors — operators
        # who want scoped tracks first can toggle `desc`.
        return (_active_deliverable(track_dir).lower(), name.lower())
    # Fallback — should never reach because caller validates.
    return (name.lower(),)


def _sort_key(name: str, state: str, track_dir: Path) -> tuple:
    # disabled·running/paused sort alongside their enabled counterparts so live
    # wakes always float to the top regardless of dispatcher state.
    order = {
        "running": 0, "disabled · running": 0,
        "paused": 1, "disabled · paused": 1,
        "stale-lock": 2,
        "idle": 3,
        "disabled": 4,
    }
    rank = order.get(state, 3)
    lw_path = track_dir / "last-wake.timestamp"
    try:
        ts = int(lw_path.read_text().strip())
    except (OSError, ValueError):
        ts = 0
    return (rank, -ts)


# Curated palette for the per-track status-bar color. Buckets only into
# vibrant, medium, and pastel hues — no browns, olives, mustardy yellows,
# or muddy mid-tones. Indexed by a stable crc32 hash of the track name so
# a given track always renders with the same color across runs.
_TRACK_PALETTE: list[str] = [
    # Vibrant
    "#FF1744", "#FF4081", "#E91E63", "#9C27B0", "#673AB7",
    "#3F51B5", "#2196F3", "#00BCD4", "#009688", "#4CAF50",
    "#8BC34A", "#FF5722", "#FF9800",
    # Medium
    "#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A", "#98D8C8",
    "#7FB3D5", "#F1948A",
    # Pastel
    "#FFB6C1", "#B5EAD7", "#C7CEEA", "#C2F0FC", "#E0BBE4",
    "#FEC8D8", "#FFDFD3", "#B3E5FC", "#80DEEA",
]


def _track_color(name: str) -> tuple[str, str]:
    """Return (background_hex, foreground_hex) for a track's status bar.

    Stable across runs: same name → same color. Foreground is black or
    white depending on background luminance for legibility.
    """
    bucket = zlib.crc32(name.encode("utf-8")) % len(_TRACK_PALETTE)
    bg = _TRACK_PALETTE[bucket]
    r = int(bg[1:3], 16)
    g = int(bg[3:5], 16)
    b = int(bg[5:7], 16)
    luminance = 0.299 * r + 0.587 * g + 0.114 * b
    fg = "#000000" if luminance > 140 else "#FFFFFF"
    return bg, fg


# Semantic ANSI color for the canonical state strings produced by
# _resolve_track_state. Read at-a-glance health: green = alive,
# magenta = paused, dim = idle/disabled, yellow = needs attention.
def _state_color(state: str) -> str:
    if "running" in state:
        return "green"
    if "paused" in state:
        return "magenta"
    if state == "stale-lock":
        return "yellow"
    if state == "disabled":
        return "bright_black"
    # idle (and any unknown/composite state) gets cyan
    return "cyan"


# ── status-cell helper (spec.dashboard-column-layout-v2~3370f397) ──────────


_EM_DASH = "—"  # U+2014 — non-current sentinel per FR3
_ELLIPSIS = "…"  # U+2026 right-side truncation marker per FR5


# ── responsive-column layout (item 22, originator 2026-05-20T10:31Z) ──────
#
# Background: the dashboard table has eleven columns. Seven are fixed-min
# (never grow regardless of terminal width); four are content-bearing
# flex columns that benefit from extra room when the terminal is wide.
#
# At narrow widths (≤ ~143 cols) the flex columns hold their declared
# minima — exactly the widths the dashboard has shipped with since
# spec.dashboard-column-layout-v2~3370f397 FR4. At wider terminals the
# extra space is distributed to the flex columns proportionally to their
# weights (activity has the most content on average, blocked has the
# least), giving the operator a luxurious view at 200+ cols without
# wasting screen real-estate on fixed columns whose content does not
# benefit from extra width (state words are short, cost is a number).

_FIXED_COLUMN_WIDTHS: dict[str, int] = {
    "expand": 3,    # ▸/▾
    "state": 20,
    "name": 24,
    "runtime": 10,
    "inbox": 4,     # 📨
    "followup": 4,  # ✅
    "cost": 10,
}

# Flex columns: minima are the widths shipped through v0.4.75.
# v0.4.78 item 29: `deliverable` joins the flex set — slugs vary in
# length (8-30 chars typical) so a fixed width either clips most names
# or wastes space; the responsive layout absorbs the variance.
_FLEX_COLUMN_MIN: dict[str, int] = {
    "activity": 20,
    "deliverable": 18,
    "focus": 18,
    "plan": 16,
    "blocked": 14,
}

# Relative weights for distributing extra width across flex columns.
# activity > deliverable = focus = plan > blocked because activity is
# the densest content (wake-report tail), deliverable + focus + plan
# are deliberate writer signals, blocked is occasional + short.
_FLEX_COLUMN_WEIGHTS: dict[str, int] = {
    "activity": 3,
    "deliverable": 2,
    "focus": 2,
    "plan": 2,
    "blocked": 1,
}

# Baseline + cushion derivation:
#   sum(fixed) = 75
#   sum(flex_min) = 86  (was 68; +18 for deliverable in v0.4.78)
#   baseline = 75 + 86 = 161
# Plus a small cushion for the DataTable's per-column gutter / inter-cell
# padding + the right-edge scrollbar reservation Textual draws when the
# table is taller than the viewport.
_LAYOUT_BASELINE: int = 161
_LAYOUT_CUSHION: int = 6


def _compute_flex_widths(term_width: int) -> dict[str, int]:
    """Distribute extra width above baseline across flex columns.

    Args:
        term_width: terminal width in cells (typically ``App.size.width``
            or ``shutil.get_terminal_size().columns``).

    Returns:
        Mapping ``{"activity", "focus", "plan", "blocked"} → int``.
        Each width ≥ the column's declared minimum. At ``term_width`` <=
        ``_LAYOUT_BASELINE + _LAYOUT_CUSHION`` returns exactly the
        minima — preserving the pre-item-22 layout for narrow terminals.

    Item 22 (originator 2026-05-20T10:31Z): the spec
    ``spec.dashboard-column-layout-v2~3370f397`` FR4 currently declares
    fixed per-column widths; this responsive behavior is a substantive
    amendment in which those widths become *minima* + *weights*. The
    spec update is a separate trail with spec-writer; this
    implementation ships against the existing spec's understanding of
    the minima.
    """
    extra = term_width - _LAYOUT_BASELINE - _LAYOUT_CUSHION
    if extra <= 0:
        return dict(_FLEX_COLUMN_MIN)
    total_weight = sum(_FLEX_COLUMN_WEIGHTS.values())  # 8
    # Two-pass largest-remainder (Hamilton) distribution: floor each
    # column's quota first, then assign the leftover cells to the
    # columns with the largest fractional remainders. Ties broken by
    # weight, then by the declared column order — both of which favor
    # activity over blocked. This is strictly monotonic on this fixed
    # weight set (verified by test_item22_monotonic_growth) — naive
    # "last column takes the remainder" was not, because at low extras
    # the remainder consistently landed on the lowest-weight column
    # and then got stolen back as the higher-weight floors caught up.
    keys = list(_FLEX_COLUMN_MIN.keys())
    floors: dict[str, int] = {}
    remainders: list[tuple[float, int, int, str]] = []
    for idx, name in enumerate(keys):
        weight = _FLEX_COLUMN_WEIGHTS[name]
        quota = (extra * weight) / total_weight
        floor = int(quota)
        floors[name] = floor
        # Sort key (desc by remainder, desc by weight, asc by index) —
        # negate to match Python's ascending sort.
        remainders.append((-(quota - floor), -weight, idx, name))
    leftover = extra - sum(floors.values())
    remainders.sort()
    for i in range(leftover):
        _, _, _, name = remainders[i]
        floors[name] += 1
    return {name: _FLEX_COLUMN_MIN[name] + floors[name] for name in keys}


def _fmt_status_cell(field_value, max_width: int, state: str) -> str:
    """Render a focus / plan / blocked cell value per FR2 + FR3 + FR5.

    spec.dashboard-column-layout-v2~3370f397.

    Single site for the em-dash, newline-collapse, and ellipsis-
    truncation rules. INV-NO-MARKUP-EXEC is enforced by callers
    wrapping the result in ``Text(..., markup=False)``.

    Args:
        field_value: the raw value from status.yaml (str or None or missing
            — missing is signalled by passing the result of ``dict.get(key)``).
        max_width: declared bounded width per FR4 (18 for focus, 16 for
            plan, 14 for blocked).
        state: the resolved track state (the same value the dashboard
            renders in the ``state`` column). Anything not containing
            ``"running"`` triggers the FR3 em-dash branch.

    Returns:
        The display string — either the em-dash (FR3) or the truncated
        value (FR2 + FR5). Always a ``str``; never ``None``.
    """
    # FR3 em-dash branch: non-running OR null/missing OR empty
    if "running" not in (state or ""):
        return _EM_DASH
    if field_value is None:
        return _EM_DASH
    if not isinstance(field_value, str):
        # Defensive — at the Python boundary set_status enforces str|None.
        return _EM_DASH
    if field_value == "":
        return _EM_DASH

    # FR2 newline collapse — one space per newline
    collapsed = field_value.replace("\n", " ")

    # FR5 right-side ellipsis truncation
    if len(collapsed) > max_width:
        if max_width <= 0:
            return _ELLIPSIS[:max_width] if max_width >= 0 else ""
        return collapsed[: max_width - 1] + _ELLIPSIS
    return collapsed


def _render_status_block(status_payload: dict) -> Text:
    """Render the FOCUS / PLAN / BLOCKED ON section block for the
    dashboard expanded-row view and the session view.

    Always returns a Rich ``Text`` with all three labeled sections —
    populated fields render their value, null/missing/empty fields
    render ``(not set)`` in dim italic. v0.4.81: changed from
    hide-when-empty (v0.4.75) to always-visible per third-complaint
    escalation 2026-05-20T11:49Z — the operator needs visible
    confirmation that the feature renders, not silent hiding that
    looks identical to "broken."

    Each section's label is rendered in bold dim cyan as a subtle
    accent; the value renders as plain text and may span multiple
    lines (plans are typically multi-step). The block does not
    truncate — the expanded view has the room the column display
    lacks.

    Originator directive 2026-05-20T10:27Z (item 21):
        > reflect dashboard inview should show full focus, plan and
        > blocked above the tail, same with session

    Originator escalation 2026-05-20T11:49Z (3rd complaint):
        > reflect dashboard inview still doesnt show focus/plan/
        > blocked for the currently expanded item
    """
    sections: list[tuple[str, str | None]] = []
    for key, label in (("focus", "FOCUS"),
                       ("plan", "PLAN"),
                       ("blocked_on", "BLOCKED ON")):
        val = status_payload.get(key)
        if val is None or not isinstance(val, str) or not val.strip():
            sections.append((label, None))
        else:
            sections.append((label, val))

    block = Text(no_wrap=False)
    for i, (label, val) in enumerate(sections):
        if i > 0:
            block.append("\n")
        block.append(f"{label}:", style="bold dim cyan")
        if val is None:
            block.append("\n  ")
            block.append("(not set)", style="dim italic")
            continue
        # Indent every line of the value by two spaces so labels and
        # content visually separate. Trailing newlines are stripped to
        # keep section spacing predictable.
        for line in val.rstrip("\n").splitlines() or [""]:
            block.append("\n  ")
            block.append(line)
    return block


def _read_track_status_safe(track_name: str) -> dict:
    """Read status.yaml for a track without raising.

    Returns a dict (possibly empty) — callers index defensively with
    ``.get(...)`` to handle v1/v2/v3 schema_version variants
    (spec.track-status-surface~3f9fe56b FR6).

    The dashboard MUST tolerate missing keys, missing files, and
    malformed YAML — none of these are operator-correctable from the
    dashboard surface, so any failure renders as an empty payload
    (which collapses to em-dashes per FR3 absent-key branch).
    """
    # Resolve via the canonical writer module so the dashboard reads
    # exactly the file the writer writes.
    try:
        from agent.lib.status import _status_path
        path = _status_path(track_name)
    except Exception:
        return {}
    try:
        loaded = yaml.safe_load(path.read_text())
        return loaded if isinstance(loaded, dict) else {}
    except (OSError, yaml.YAMLError):
        return {}


def _dashboard_config_path() -> Path:
    """Filesystem path to the dashboard YAML config.

    Honors XDG_CONFIG_HOME when set, else `~/.config`. Per the project
    YAML-for-state convention (feedback_yaml_for_state_not_json) — never
    JSON for a human-touched config file.
    """
    base = os.environ.get("XDG_CONFIG_HOME")
    if base:
        root = Path(base)
    else:
        root = Path.home() / ".config"
    return root / "reflect" / "dashboard.yaml"


def _load_dashboard_config() -> dict:
    """Read the dashboard config file. Returns {} on any error (best-effort)."""
    path = _dashboard_config_path()
    if not path.exists():
        return {}
    try:
        loaded = yaml.safe_load(path.read_text())
        return loaded if isinstance(loaded, dict) else {}
    except (OSError, yaml.YAMLError):
        return {}


def _save_dashboard_config(cfg: dict) -> None:
    """Atomically persist the dashboard config. Never raises."""
    path = _dashboard_config_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".yaml.tmp")
        tmp.write_text(yaml.safe_dump(cfg, sort_keys=False))
        tmp.replace(path)
    except (OSError, yaml.YAMLError):
        pass


# v0.4.73 item 18 bounds — keeps `+`/`-` resize hotkeys from producing
# pathological tail sizes via held-down keypresses or weird terminals.
_TAIL_LINES_MIN = 10
_TAIL_LINES_MAX = 1000
# v0.4.77 item 25 (originator directive 2026-05-20T10:52Z): bumped
# default from 100 → 150. Env var override (REFLECT_DASHBOARD_EXPANDED_LINES)
# and ~/.config/reflect/dashboard.yaml `expanded_tail_lines` key still win.
_TAIL_LINES_DEFAULT = 150
_TAIL_LINES_STEP = 20


def _expanded_lines() -> int:
    """Number of tail lines to show under an expanded track row.

    Loading priority (v0.4.73 item 18):
        REFLECT_DASHBOARD_EXPANDED_LINES env var
        ~/.config/reflect/dashboard.yaml `expanded_tail_lines:` key
        default 100

    Values are clamped to [_TAIL_LINES_MIN, _TAIL_LINES_MAX]. v0.4.71 item 12
    bumped the default from 20 → 100 — 100 gives meaningful scrollback for
    active tracks when paired with the scrollable VerticalScroll wrapper.
    v0.4.73 item 18 makes the value configurable at runtime via `+`/`-`
    hotkeys, persisting the operator's choice to the YAML config file so
    it survives dashboard restart.
    """
    env = os.environ.get("REFLECT_DASHBOARD_EXPANDED_LINES")
    if env is not None:
        try:
            return max(_TAIL_LINES_MIN, min(_TAIL_LINES_MAX, int(env)))
        except ValueError:
            pass
    cfg = _load_dashboard_config()
    val = cfg.get("expanded_tail_lines")
    if isinstance(val, int) and val > 0:
        return max(_TAIL_LINES_MIN, min(_TAIL_LINES_MAX, val))
    return _TAIL_LINES_DEFAULT


# v0.4.71 item 10: tick logs at /tmp/reflect-tick-*.log contain NO ANSI
# escape sequences (verified by xxd grep '1b 5b' = 0). `Text.from_ansi`
# was correctly producing plain text — there was nothing to color.
# Apply heuristic colorization at render time so the tail panel actually
# displays color.
def _colorize_tail_line(line: str) -> Text:
    """Heuristic-colorize a single tail line into a Rich Text object.

    Rules (first-match wins):
    - `🔧 Read:` / `🔧 Glob:` / `🔧 Grep:`  → cyan (read tools)
    - `🔧 Bash:`                            → green (shell)
    - `🔧 Write:` / `🔧 Edit:`              → magenta (write tools)
    - `🔧 ` (other tool calls)              → blue
    - Lines containing ERROR / Failed / FAIL / Traceback → red
    - Lines containing WARN / Warning       → yellow
    - Default                               → plain text

    Lines with embedded ANSI escapes are still parsed via Text.from_ansi
    first; the heuristic only fires when the parsed text has no styling.
    """
    parsed = Text.from_ansi(line)
    # If the line already carried styled spans from ANSI escapes, keep them.
    if parsed.spans:
        return parsed
    stripped = line.lstrip()
    style = None
    if stripped.startswith("🔧 Read:") or stripped.startswith("🔧 Glob:") or stripped.startswith("🔧 Grep:"):
        style = "cyan"
    elif stripped.startswith("🔧 Bash:"):
        style = "green"
    elif stripped.startswith("🔧 Write:") or stripped.startswith("🔧 Edit:"):
        style = "magenta"
    elif stripped.startswith("🔧 "):
        style = "blue"
    else:
        # Lower-priority content scan
        lc = line.lower()
        if "error" in lc or "failed" in lc or "fail" in lc or "traceback" in lc:
            style = "red"
        elif "warn" in lc or "warning" in lc:
            style = "yellow"
    if style is None:
        return parsed
    return Text(line, style=style, no_wrap=False)


def _tail_lines(track_name: str, n: int = 8) -> list[str]:
    log_path = Path(f"/tmp/reflect-tick-{track_name}.log")
    try:
        lines = log_path.read_text().splitlines()
        return lines[-n:]
    except OSError:
        return []


# ── tail screen ────────────────────────────────────────────────────────────


class TailScreen(Screen):
    """Full-screen transcript tail for a single track.

    Auto-transitions when a new wake fires — no need to restart.

    Detection: polls the latest-wake-for-track helper every second.
    When a new wake_id appears, a separator line is printed and the
    transcript reader resets to the new file.

    Content: AssistantMessage events rendered as thinking / text / tool-use
    lines.  UserMessage (tool results) and SystemMessage are omitted.

    Status bar: track color + wake_id (last 14 chars) + turn count + cost.
    Between wakes: idle state with "waiting for next wake".
    """

    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back", show=True),
        Binding("l", "open_in_pager", "Less", show=True),
    ]

    DEFAULT_CSS = """
    #track-bar {
        dock: bottom;
        height: 1;
        padding: 0 2;
        text-style: bold;
    }
    #tail-content {
        padding: 1 2;
    }
    """

    def __init__(self, track_name: str) -> None:
        super().__init__()
        self.track_name = track_name
        self._current_wake_id: Optional[str] = None
        self._transcript_path: Optional[Path] = None
        self._transcript_line: int = 0
        self._display_lines: list[str] = []
        # Synthesizer state
        self._latest_status: Optional[str] = None
        self._synth_in_flight: bool = False
        self._synth_task: Optional[asyncio.Task] = None
        self._synthesizer = None  # lazy — import StatusSynthesizer on mount

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Static(id="tail-content")
        yield Static(id="track-bar")

    def on_mount(self) -> None:
        self.title = f"reflect tail  ·  {self.track_name}"
        bg, fg = _track_color(self.track_name)
        bar = self.query_one("#track-bar", Static)
        bar.styles.background = bg
        bar.styles.color = fg
        self._set_bar_idle()
        # Seed with any current or most-recent wake
        self._check_for_new_wake()
        self.set_interval(0.5, self._poll_transcript)
        self.set_interval(1.0, self._check_for_new_wake)
        # Synthesizer: try to import; silently disable if anthropic not available
        try:
            from .status_synthesizer import StatusSynthesizer
            self._synthesizer = StatusSynthesizer()
        except Exception:
            self._synthesizer = None
        # Fire synthesizer every 15s
        self.set_interval(15.0, self._trigger_synthesis)

    def on_unmount(self) -> None:
        """Cancel in-flight synthesizer task on screen exit."""
        if self._synth_task is not None and not self._synth_task.done():
            self._synth_task.cancel()

    # ── status bar ──────────────────────────────────────────────────────────

    def _set_bar_idle(self) -> None:
        self.query_one("#track-bar", Static).update(
            f" {self.track_name}  ·  idle — waiting for next wake "
        )

    def _set_bar_wake(
        self,
        wake_id: str,
        turns: int,
        cost_usd: Optional[float],
        is_running: bool,
    ) -> None:
        short_id = wake_id[-14:] if len(wake_id) > 14 else wake_id
        state = "●" if is_running else "◌"
        cost_str = f"  ${cost_usd:.4f}" if cost_usd is not None else ""
        # Build core slots (fixed-width, high information density)
        core = f" {state} {self.track_name}  ·  {short_id}  ·  {turns} turns{cost_str}"
        # Live status slot (right side, truncated to fit terminal)
        if self._latest_status:
            status_slot = f'  ·  "{self._latest_status}"'
            # Respect terminal width: truncate status slot from the end
            try:
                term_width = os.get_terminal_size().columns
            except OSError:
                term_width = 200
            available = term_width - len(core) - 1  # 1 for trailing space
            if available < 6:
                status_slot = ""
            elif len(status_slot) > available:
                # Truncate with ellipsis, keep the opening quote
                status_slot = status_slot[: available - 1] + "…"
        else:
            status_slot = ""
        self.query_one("#track-bar", Static).update(f"{core}{status_slot} ")

    # ── pager ────────────────────────────────────────────────────────────────

    def action_open_in_pager(self) -> None:
        """Suspend the TUI and open current content in `less` for selection/copy."""
        import re
        import tempfile

        # Strip Rich markup to plain text for pager display
        plain = re.sub(r"\[/?[^\]]*\]", "", "\n".join(self._display_lines))
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, prefix=f"reflect-tail-{self.track_name}-"
        ) as f:
            f.write(plain)
            tmp_path = f.name

        with self.app.suspend():
            subprocess.run(["less", "-R", tmp_path], check=False)

        import os as _os
        try:
            _os.unlink(tmp_path)
        except OSError:
            pass

    # ── synthesizer ─────────────────────────────────────────────────────────

    def _trigger_synthesis(self) -> None:
        """Fire a Haiku synthesis if track is running and no call in flight."""
        if self._synthesizer is None:
            return
        if not self._is_track_running():
            return
        if not self._display_lines:
            return
        if self._synth_in_flight:
            return  # drop — previous call hasn't returned

        self._synth_in_flight = True
        lines_snapshot = list(self._display_lines)

        async def _run():
            try:
                result = await self._synthesizer.synthesize(lines_snapshot)
                if result:
                    self._latest_status = result
                    # Re-render the bar immediately on update
                    self._set_bar_wake(
                        self._current_wake_id or "",
                        self._count_tool_turns(),
                        None,
                        self._is_track_running(),
                    )
            except Exception as exc:
                # Silent fallback — log to stderr only
                import sys
                print(f"[synthesizer error] {exc}", file=sys.stderr)
            finally:
                self._synth_in_flight = False

        self._synth_task = asyncio.create_task(_run())

    # ── wake detection ───────────────────────────────────────────────────────

    def _check_for_new_wake(self) -> None:
        """Detect a new or finished wake; transition display accordingly."""
        from ..ops.wake import latest_wake_for_track

        info = latest_wake_for_track(self.track_name)
        if info is None:
            if self._current_wake_id is not None:
                self._current_wake_id = None
                self._transcript_path = None
                self._latest_status = None
                self._set_bar_idle()
            return

        new_id = info["wake_id"]

        if new_id == self._current_wake_id:
            # Same wake — update bar when it finishes with final cost
            if not info["is_running"] and info["cost_usd"] is not None:
                self._set_bar_wake(
                    new_id, self._count_tool_turns(), info["cost_usd"], False
                )
            return

        # ── new wake! ────────────────────────────────────────────────────────
        if self._current_wake_id is not None:
            # Print transition separator
            self._display_lines.append("")
            self._display_lines.append(
                "─" * 40 + f"  {new_id}  " + "─" * 40
            )
            self._display_lines.append("")

        self._current_wake_id = new_id
        self._transcript_path = info["transcript_path"]
        self._transcript_line = 0
        # Clear live status on wake transition; synthesizer repopulates within 15s
        self._latest_status = None
        self._set_bar_wake(new_id, 0, info["cost_usd"], info["is_running"])
        # Drain whatever is already in the transcript
        self._poll_transcript()

    # ── transcript polling ───────────────────────────────────────────────────

    def _poll_transcript(self) -> None:
        """Append any new transcript events to the display."""
        if self._transcript_path is None:
            return
        from ..ops.wake import parse_transcript_tail

        new_lines, new_pos = parse_transcript_tail(
            self._transcript_path, self._transcript_line
        )
        if new_pos == self._transcript_line:
            return  # nothing new

        self._transcript_line = new_pos
        self._display_lines.extend(new_lines)

        # Render — cap at last 150 display lines to avoid unbounded growth
        content = "\n".join(self._display_lines[-150:])
        self.query_one("#tail-content", Static).update(content)

        # Refresh bar (cost unknown while running; will update on wake complete)
        turns = self._count_tool_turns()
        self._set_bar_wake(
            self._current_wake_id or "",
            turns,
            None,
            self._is_track_running(),
        )

    def _count_tool_turns(self) -> int:
        """Proxy for turn count: number of tool-call lines in the display buffer."""
        return sum(1 for line in self._display_lines if line.startswith("  🔧"))

    def _is_track_running(self) -> bool:
        # Same detection as latest_wake_for_track: start_ts > end_ts.
        track_dir = (
            Path(__file__).resolve().parents[3]
            / "agent" / "runtime" / "tracks" / self.track_name
        )
        lws = track_dir / "last-wake-start.timestamp"
        lwe = track_dir / "last-wake.timestamp"
        try:
            start_ts = int(lws.read_text().strip())
        except (OSError, ValueError):
            return False
        try:
            end_ts = int(lwe.read_text().strip())
        except (OSError, ValueError):
            end_ts = 0
        return start_ts > end_ts


# ── dashboard app ─────────────────────────────────────────────────────────


class DashboardApp(App[Optional[str]]):
    """Live multi-track dashboard.

    Returns track name if user pressed 'i' (caller opens inbox TUI).
    """

    CSS = """
    #status-bar {
        height: 1;
        background: $primary-darken-2;
        color: $text;
        padding: 0 2;
    }
    #filter-input {
        height: 3;
        display: none;
    }
    #filter-input.visible {
        display: block;
    }
    DataTable {
        height: 1fr;
    }
    /* v0.4.73 item 19 / v0.4.77 item 24: focus indicator. Tab cycles
       focus between the DataTable (table rows) and the expand-tail
       scroll. The focused widget gets a thick light-blue border so
       the operator can tell which keys do what.

       v0.4.77 item 24 (originator directive 2026-05-20T10:55Z):
       switched from `$accent` (resolved to orange in the originator's
       Textual theme — "hideous" per the directive) to a literal hex
       light-blue (#7dd3fc, Tailwind sky-300). Literal hex bypasses
       theme-token resolution so the color reads consistently across
       terminal themes. */
    DataTable.has-focus {
        border: heavy #7dd3fc;
    }
    /* v0.4.71 item 12: the tail panel is now a VerticalScroll
       containing a Static. The scroll wrapper handles PgUp/PgDn
       natively when focused. max-height is set at runtime from
       self._tail_lines (v0.4.73 item 18) — tail panel size is
       user-configurable via +/-  hotkeys with a persisted YAML
       config at ~/.config/reflect/dashboard.yaml. */
    #expand-tail-scroll {
        height: auto;
        max-height: 40;
        background: $surface;
        padding: 0 1;
        display: none;
        border-top: heavy $primary;
    }
    #expand-tail-scroll.visible {
        display: block;
    }
    #expand-tail-scroll.has-focus {
        border: heavy #7dd3fc;
    }
    #expand-tail {
        height: auto;
        color: $text;
    }
    /* v0.4.73 item 17 + v0.4.77 escalation: shortcuts-bar STILL not
       visible was the originator's 5th complaint on this surface
       (2026-05-20T10:58Z). Prior attempts:
         - v0.4.70: hotkey footer claim — not visible
         - v0.4.71 item 11: "contrast bumped" via $accent 35% — not visible
         - v0.4.73 item 17: dock:bottom + $primary bg — STILL not visible

       The escalation diagnostic supplement (2026-05-20T10:57Z):
       Textual theme tokens `$primary` and `$text` were resolving to
       similar colors in the originator's terminal theme — fg == bg,
       so the bar rendered but was invisible. The fix is literal hex
       colors that bypass theme-token resolution entirely.

       Color choice: deep navy (#1e3a8a) on near-white (#f1f5f9) +
       bold + dock:bottom. Pinned to bottom regardless of expand-tail
       state. Hex bypasses any theme token mismatch. */
    #shortcuts-bar {
        dock: bottom;
        height: 1;
        background: #1e3a8a;
        color: #f1f5f9;
        padding: 0 1;
        text-style: bold;
        overflow-x: hidden;
    }
    """

    BINDINGS = [
        Binding("j", "cursor_down", "Down", show=False, priority=True),
        Binding("k", "cursor_up", "Up", show=False, priority=True),
        Binding("down", "cursor_down", "Down", show=False, priority=True),
        Binding("up", "cursor_up", "Up", show=False, priority=True),
        Binding("space", "toggle_expand", "Expand", show=True, priority=True),
        Binding("enter", "open_session", "Session", show=True, priority=True),
        Binding("e", "toggle_enable", "Enable/Disable", show=True, priority=True),
        Binding("i", "open_inbox", "Inbox", show=True, priority=True),
        # v0.4.77 item 26 (originator directive 2026-05-20T10:54Z):
        # Shift+I jumps straight to the originator's inbox regardless
        # of which track row is currently selected. The originator
        # inbox is where callbacks accumulate and gets checked most
        # often, so this shortcut bypasses the row-cursor step.
        Binding("I", "open_originator_inbox", "Orig.Inbox", show=True, priority=True),
        Binding("s", "wake_start", "Start", show=True, priority=True),
        Binding("x", "wake_stop", "Stop", show=True, priority=True),
        # v0.4.73 item 19: Tab cycles focus between table rows and the
        # tail panel (when expanded). When tail has focus, j/k scroll
        # the tail content instead of moving the table cursor.
        Binding("tab", "toggle_focus", "Focus", show=True, priority=True),
        # v0.4.73 item 18: `+`/`-` grow/shrink the tail panel by 20 lines
        # at a time, persisting the choice to ~/.config/reflect/dashboard.yaml.
        Binding("plus", "tail_grow", "Grow", show=True, priority=True),
        Binding("equals_sign", "tail_grow", "Grow", show=False, priority=True),
        Binding("minus", "tail_shrink", "Shrink", show=True, priority=True),
        # v0.4.77 item 23 (originator directive 2026-05-20T10:50Z):
        # Direct uppercase-letter hotkeys sort the table by their column.
        # Pressing the same key twice toggles direction. Active sort is
        # surfaced as `↑`/`↓` on the column header, and the spec
        # (sort_column, sort_direction) is persisted to
        # ~/.config/reflect/dashboard.yaml so it survives restart.
        #   N — name (alphabetic)
        #   A — activity (last-activity timestamp; recent first by default)
        #   R — runtime (numeric)
        #   B — inbox count (📨)
        #   F — followup count (✅)
        #   C — cost (numeric USD)
        #   T — state (categorical, running > paused > idle > disabled)
        # `I` is reserved for "originator inbox" (item 26); `S` is paired
        # with lowercase `s` (wake_start) — using `T` (Triage state) avoids
        # the cognitive overlap.
        Binding("N", "sort_name", "Sort name", show=False, priority=True),
        Binding("A", "sort_activity", "Sort activity", show=False, priority=True),
        Binding("R", "sort_runtime", "Sort runtime", show=False, priority=True),
        Binding("B", "sort_inbox", "Sort inbox", show=False, priority=True),
        Binding("F", "sort_followup", "Sort followup", show=False, priority=True),
        Binding("C", "sort_cost", "Sort cost", show=False, priority=True),
        Binding("T", "sort_state", "Sort state", show=False, priority=True),
        # v0.4.78 item 29: `D` sorts the new deliverable column. `D` is
        # free (no current binding) and mnemonic for Deliverable.
        Binding("D", "sort_deliverable", "Sort deliverable", show=False, priority=True),
        Binding("O", "sort_clear", "Default sort", show=False, priority=True),
        Binding("/", "focus_filter", "Filter", show=True, priority=True),
        Binding("escape", "clear_filter", "Clear filter", show=False, priority=True),
        Binding("q", "quit", "Quit", show=True, priority=True),
    ]

    def __init__(self, tracks_dir: Path) -> None:
        super().__init__()
        self.tracks_dir = tracks_dir
        # Single-track expansion: tail rendered in a full-width bottom panel
        # rather than DataTable sub-rows (which couldn't render ANSI colors
        # at full width — the sub-row went into column 0, width=3).
        self._expanded_track: Optional[str] = None
        self._filter: str = ""
        self._track_rows: list[str] = []  # ordered track names in current table
        self._filtering = False
        # v0.4.73 item 18: tail-panel line count is now per-instance and
        # mutable at runtime via `+`/`-` hotkeys. Initial value comes from
        # _expanded_lines() which resolves env > config-file > default.
        self._tail_lines: int = _expanded_lines()
        # v0.4.73 item 19: which widget currently has keyboard focus —
        # "table" (DataTable, cursor + row actions) or "tail"
        # (VerticalScroll, j/k scrolls the tail content). Tab toggles.
        self._focus_target: str = "table"
        # v0.4.76 item 22: per-flex-column widths recomputed on resize.
        # Initial values are the declared minima; _apply_responsive_widths
        # (called from on_mount + on_resize) replaces them with values
        # scaled to the actual terminal width.
        self._flex_widths: dict[str, int] = dict(_FLEX_COLUMN_MIN)
        # ColumnKey handles returned by DataTable.add_column, indexed by
        # the column's stable string name so on_resize can mutate
        # `.width` on the four flex columns without touching the fixed
        # set. Populated by on_mount.
        self._col_keys: dict[str, object] = {}
        # v0.4.77 item 23: user-driven column sort. Persisted via
        # ~/.config/reflect/dashboard.yaml. When set, _refresh_table sorts
        # by _sort_value(name, column, ...) in the given direction.
        # v0.4.78 item 28 (originator 2026-05-20T11:32Z): default sort
        # column is now `state` (asc) when the operator has not
        # configured anything. _STATE_RANK encodes triage priority with
        # running=0 (highest), so `state` + `asc` places running tracks
        # at the top — matching the originator's enumerated directive
        # "running first, unhealthy next, idle middle, paused, disabled
        # last". The directive wrote `sort_direction: desc` semantically
        # ("desc by triage priority"); the rank encoding already inverts
        # for us, so the literal direction stored on disk is `asc`.
        # Operators with an explicit prior sort_column/sort_direction in
        # their config still get their persisted choice.
        cfg = _load_dashboard_config()
        sc = cfg.get("sort_column")
        sd = cfg.get("sort_direction")
        self._sort_column: Optional[str] = sc if sc in _SORTABLE_COLUMNS else "state"
        self._sort_direction: str = sd if sd in ("asc", "desc") else "asc"

    # ── lifecycle ──────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Static(id="status-bar")
        yield Input(placeholder="filter tracks…", id="filter-input")
        yield DataTable(id="dashboard-table")
        # Bundled-polish item 4: full-width ANSI-rendered tail panel below
        # the DataTable. Renders the currently-expanded track's tail with
        # ANSI escape sequences parsed as Rich styling (Text.from_ansi).
        # Replaces the prior column-0 sub-row approach which clipped the
        # tail content to 3 chars (the ▸/▾ column width).
        # v0.4.71 item 12: wrap the tail Static in a VerticalScroll so
        # PgUp/PgDn/arrow keys scroll within the panel when it has focus.
        # The Static is shrunk to height:auto and grows as content grows;
        # the VerticalScroll caps visible area via max-height in CSS.
        with VerticalScroll(id="expand-tail-scroll"):
            yield Static(id="expand-tail", markup=False)
        # v0.4.73 item 17: this bar is `dock: bottom` (see CSS); guaranteed
        # to render at the bottom edge regardless of how other widgets
        # size themselves. Text trimmed to fit ~120 columns.
        # v0.4.78 escalation (6th complaint): ASCII `[ ]` brackets were
        # being consumed by Rich's markup parser as `[i]` / `[s]` /
        # `[tab]` tags despite `markup=False` on the Static — italics
        # rendered across the bar and bracket characters were dropped
        # from the visible output. Root-cause diagnosis from originator
        # 2026-05-20T11:18Z. Replaced ASCII brackets with Unicode
        # mathematical angle brackets U+27E8 / U+27E9 (⟨ ⟩) which
        # render similarly in monospace fonts but carry no Rich-markup
        # semantics, so the bar text passes through untouched.
        yield Static(
            " ⟨j/k⟩ Move  ⟨spc⟩ Expand  ⟨enter⟩ Session  ⟨tab⟩ Focus  ⟨+/-⟩ Resize  ⟨e⟩ En/Dis  ⟨i⟩ Inbox  ⟨I⟩ Orig.Inbox  ⟨O⟩ Sort  ⟨s⟩ Start  ⟨x⟩ Stop  ⟨/⟩ Filter  ⟨q⟩ Quit ",
            id="shortcuts-bar",
            markup=False,
        )

    def on_mount(self) -> None:
        self.title = "reflect dashboard"
        table: DataTable = self.query_one("#dashboard-table", DataTable)
        table.cursor_type = "row"
        # spec.dashboard-column-layout-v2~3370f397 FR1 — ten columns,
        # fixed order. Widths per FR4: fixed `width=N` for state/runtime/
        # cost/expand/inbox; bounded columns (name/activity/focus/plan/
        # blocked) auto-size up to their declared max because the cell
        # renderer pre-truncates per FR5 via _fmt_status_cell + _truncate.
        # Headers are plain lowercase ASCII per FR7.
        # v0.4.72 item 13: `runtime` moved between `activity` and 📨 to
        # keep temporal columns adjacent. v0.4.72 item 14: followup
        # column header swapped from U+2611 (☑, monochrome ballot-box,
        # rendered as ASCII-style in many terminal fonts) to U+2705 (✅,
        # white heavy check mark, colored-emoji in most modern terminals)
        # per originator directive 2026-05-20T09:29Z. Inbox column glyph
        # remains 📨. Final column order:
        #   ▸/▾ | state | name | activity | runtime | 📨 | ✅ | focus | plan | blocked | cost
        # v0.4.76 item 22: per-flex-column widths come from
        # _compute_flex_widths(term_width). Fixed columns keep their
        # declared widths (state/name/runtime/inbox/followup/cost/expand
        # do not benefit from extra room). on_resize re-runs the
        # computation and mutates `.width` on the four flex columns.
        initial_term_width = max(80, int(self.size.width or 0))
        self._flex_widths = _compute_flex_widths(initial_term_width)
        self._col_keys["expand"]      = table.add_column("▸/▾", width=_FIXED_COLUMN_WIDTHS["expand"])
        self._col_keys["state"]       = table.add_column("state", width=_FIXED_COLUMN_WIDTHS["state"])
        self._col_keys["name"]        = table.add_column("name", width=_FIXED_COLUMN_WIDTHS["name"])
        self._col_keys["activity"]    = table.add_column("activity", width=self._flex_widths["activity"])
        self._col_keys["runtime"]     = table.add_column("runtime", width=_FIXED_COLUMN_WIDTHS["runtime"])
        self._col_keys["inbox"]       = table.add_column("📨", width=_FIXED_COLUMN_WIDTHS["inbox"])
        self._col_keys["followup"]    = table.add_column("✅", width=_FIXED_COLUMN_WIDTHS["followup"])
        # v0.4.78 item 29: active-deliverable column groups with the
        # other writer-signal columns (focus/plan/blocked). Slot is
        # immediately before `focus` because deliverable is the
        # "what scope is this track in right now" declaration, and
        # focus/plan/blocked are the "what is the track doing within
        # that scope" declarations.
        self._col_keys["deliverable"] = table.add_column("deliverable", width=self._flex_widths["deliverable"])
        self._col_keys["focus"]       = table.add_column("focus", width=self._flex_widths["focus"])
        self._col_keys["plan"]        = table.add_column("plan", width=self._flex_widths["plan"])
        self._col_keys["blocked"]     = table.add_column("blocked", width=self._flex_widths["blocked"])
        self._col_keys["cost"]        = table.add_column("cost", width=_FIXED_COLUMN_WIDTHS["cost"])
        # Bundled-polish item 5: zebra-striping for row tracking across
        # the full terminal width. Track-colored name cells (via
        # _track_color) keep their hue; zebra background only renders
        # against cells without their own background.
        table.zebra_stripes = True
        self._refresh_status_bar()
        self._refresh_table()
        self.set_interval(1.0, self._refresh_table)
        self.set_interval(5.0, self._refresh_status_bar)
        # DataTable is the primary interactive widget; ensure it has focus on startup
        # so keyboard bindings (j/k/e/s/x/space/enter) work immediately without
        # the operator having to click or tab into it.
        table.focus()
        # v0.4.73 item 19: visible focus indicator. Add the has-focus class
        # to the initially-focused DataTable; Tab toggles this between
        # table and tail.
        table.add_class("has-focus")
        # v0.4.73 item 18: apply the persisted tail-line count to the
        # scroll wrapper's max-height. Static CSS can't reference instance
        # state, so we set the style imperatively here at mount time.
        self._apply_tail_max_height()
        # v0.4.77 item 23: surface persisted sort with arrow indicator on
        # the active column's header. on_mount happens after column adds
        # so the ColumnKeys in self._col_keys resolve cleanly.
        if self._sort_column is not None:
            self._apply_sort_indicators()

    # ── responsive layout (v0.4.76 item 22) ────────────────────────────────

    def on_resize(self, event) -> None:  # type: ignore[no-untyped-def]
        """Re-run flex-column distribution when the terminal resizes.

        Item 22 (originator 2026-05-20T10:31Z): on terminal resize
        re-distribute the available width across the four flex
        columns (activity / focus / plan / blocked) and re-truncate
        cell content so the new widths take effect. Fixed columns
        (state / name / runtime / cost / inbox / followup / expand)
        are left untouched — they don't benefit from extra room.

        Textual fires ``Resize`` against any widget whose size
        changes; the top-level app resize (terminal-window resize)
        is what we actually care about, but Textual's per-widget
        event firing means this handler may run more frequently
        than once per real-terminal-resize. Recomputing is cheap
        (one int op per flex column) so we run it every fire and
        early-return when nothing changed.
        """
        try:
            term_width = max(80, int(self.size.width or 0))
        except Exception:
            return
        new_widths = _compute_flex_widths(term_width)
        if new_widths == self._flex_widths:
            return  # No-op — early return avoids spurious refreshes
        self._flex_widths = new_widths
        # Push the new widths into the live DataTable columns. Textual's
        # DataTable exposes mutable Column objects keyed by ColumnKey;
        # changing `.width` causes the next render pass to lay them out
        # at the new size. We refresh the table afterwards so the cell
        # contents (which we pre-truncate against _flex_widths) are
        # regenerated at the new column boundaries.
        try:
            table: DataTable = self.query_one("#dashboard-table", DataTable)
        except Exception:
            return
        for name in ("activity", "focus", "plan", "blocked"):
            key = self._col_keys.get(name)
            if key is None:
                continue
            col = table.columns.get(key)
            if col is None:
                continue
            try:
                col.width = self._flex_widths[name]
                # Some Textual versions cache the rendered content_width
                # alongside the declared width; reset auto_width to force
                # the layout engine to honor the new width.
                if hasattr(col, "auto_width"):
                    col.auto_width = False
            except Exception:
                pass
        # Re-render rows with the new max_widths. _refresh_table is
        # already idempotent (clear + re-add) so this is safe to call.
        try:
            self._refresh_table()
        except Exception:
            pass

    # ── helpers ────────────────────────────────────────────────────────────

    def _all_tracks(self) -> list[str]:
        if not self.tracks_dir.exists():
            return []
        return sorted(
            d.name
            for d in self.tracks_dir.iterdir()
            if d.is_dir() and not d.name.startswith(".")
        )

    def _selected_track(self) -> Optional[str]:
        table: DataTable = self.query_one("#dashboard-table", DataTable)
        if not self._track_rows:
            return None
        row_idx = table.cursor_row
        # _track_rows includes only track rows (not expand sub-rows)
        # We need to figure out which track row the cursor is on
        # by iterating through the rendered rows
        if row_idx < 0 or row_idx >= table.row_count:
            return None
        # Walk through the row keys to find the track at cursor_row
        row_keys = list(table.rows.keys())
        if row_idx >= len(row_keys):
            return None
        key = row_keys[row_idx].value
        # key is either "track:{name}" or "expand:{name}:{lineno}"
        if key and key.startswith("track:"):
            return key[6:]
        # if on an expand sub-row, find the parent track
        if key and key.startswith("expand:"):
            parts = key.split(":", 2)
            return parts[1] if len(parts) >= 2 else None
        return None

    # ── refresh ────────────────────────────────────────────────────────────

    def _contract_health_badge(self) -> str:
        """Protocol validator removed — always clean."""
        return "✅ contract"

    def _refresh_status_bar(self) -> None:
        # Skip refresh when a sub-screen is active — the #status-bar widget
        # lives in the default screen's DOM; querying it from a pushed screen
        # raises NoMatches.
        if len(self.screen_stack) > 1:
            return
        import datetime
        today = datetime.date.today().isoformat()
        disp = _dispatch_status()
        badge = self._contract_health_badge()
        self.query_one("#status-bar", Static).update(
            f"reflection  ·  {today}  ·  dispatcher: {disp}  ·  {badge}"
        )

    def _refresh_table(self) -> None:
        # Skip refresh when a sub-screen is active — the #dashboard-table
        # widget lives in the default screen's DOM; querying it from a pushed
        # screen raises NoMatches.
        if len(self.screen_stack) > 1:
            return
        table: DataTable = self.query_one("#dashboard-table", DataTable)
        old_cursor = table.cursor_row

        # Bundled-polish item 3: capture scroll state before rebuild and
        # restore after layout settles. Without this, table.clear() + re-add
        # snaps scroll_y back to 0 on every paint, yanking the operator off
        # whatever row they were looking at.
        old_scroll_y = float(table.scroll_y)
        old_max_scroll = float(table.max_scroll_y)
        was_at_bottom = (
            old_max_scroll > 0 and old_scroll_y >= old_max_scroll - 0.5
        )

        all_names = self._all_tracks()

        # Filter
        if self._filter:
            names = [n for n in all_names if self._filter.lower() in n.lower()]
        else:
            names = all_names

        # Build state map and sort
        states = {}
        for name in names:
            track_dir = self.tracks_dir / name
            states[name] = _track_state(track_dir)

        # v0.4.77 item 23: user-driven sort takes priority. When unset,
        # fall back to the default _sort_key (running > paused > idle ...
        # grouping, then last-activity recency).
        if self._sort_column is not None:
            names.sort(
                key=lambda n: _sort_value(
                    n, self._sort_column, states[n], self.tracks_dir / n
                ),
                reverse=(self._sort_direction == "desc"),
            )
        else:
            names.sort(key=lambda n: _sort_key(n, states[n], self.tracks_dir / n))

        # Rebuild table
        table.clear()
        self._track_rows = []
        new_row_count = 0

        for name in names:
            state = states[name]
            icon = _STATE_ICON.get(state, "?")
            track_dir = self.tracks_dir / name

            if "running" in state or "paused" in state:
                activity = _fmt_activity(name)
                runtime = _fmt_runtime(track_dir / "last-wake-start.timestamp")
                cost = _fmt_cost(name)
            else:
                activity = "-"
                runtime = "-"
                cost = "-"

            unread = _unread_count(track_dir)
            followups = _followup_count(track_dir)
            expand_marker = "▾" if name == self._expanded_track else "▸"

            # spec.dashboard-column-layout-v2~3370f397 FR2/FR3/FR5 —
            # read focus/plan/blocked_on from status.yaml and pre-truncate
            # in _fmt_status_cell. INV-NO-MARKUP-EXEC: every user-data
            # cell wrapped in Text(..., markup=False).
            status_payload = _read_track_status_safe(name)
            # v0.4.76 item 22: max_width comes from the live responsive
            # layout instead of hardcoded constants. Widths grow when
            # the terminal is wider than the 161-col baseline (was 143
            # pre-v0.4.78 item 29); the truncation rule per FR5 is
            # unchanged.
            focus_str = _fmt_status_cell(
                status_payload.get("focus"), self._flex_widths["focus"], state
            )
            plan_str = _fmt_status_cell(
                status_payload.get("plan"), self._flex_widths["plan"], state
            )
            blocked_str = _fmt_status_cell(
                status_payload.get("blocked_on"), self._flex_widths["blocked"], state
            )

            # v0.4.78 item 29: active-deliverable cell. Read-only;
            # truncated with the standard ellipsis at the flex max.
            # The cell is populated whether the track is running or
            # not — "ambient" / a scoped deliverable is meaningful at
            # rest, unlike focus/plan/blocked which are wake-scoped.
            deliverable_raw = _active_deliverable(track_dir)
            deliv_max = self._flex_widths["deliverable"]
            if len(deliverable_raw) > deliv_max:
                deliverable_str = deliverable_raw[: deliv_max - 1] + _ELLIPSIS
            else:
                deliverable_str = deliverable_raw

            # FR5 also clamps name + activity. Name stays fixed (24);
            # activity participates in the responsive layout and grows
            # with terminal width.
            name_max = _FIXED_COLUMN_WIDTHS["name"]
            name_trunc = name if len(name) <= name_max else name[: name_max - 1] + _ELLIPSIS
            activity_max = self._flex_widths["activity"]
            activity_trunc = (
                activity if len(activity) <= activity_max
                else activity[: activity_max - 1] + _ELLIPSIS
            )

            # Semantic color for state word + stable color for track title.
            # Shares _track_color with `reflect track session` so a given
            # track renders the same hue across both views.
            state_text = Text(f"{icon} {state}", style=_state_color(state))
            track_bg, _ = _track_color(name)
            # INV-NO-MARKUP-EXEC: rich.text.Text(plain_str, ...) stores the
            # literal string — markup is only parsed by Text.from_markup
            # (which we never call). Passing user-data through this ctor
            # is safe by construction.
            name_text = Text(name_trunc, style=track_bg, no_wrap=True)
            activity_text = Text(activity_trunc, no_wrap=True)
            focus_text = Text(focus_str, no_wrap=True)
            plan_text = Text(plan_str, no_wrap=True)
            blocked_text = Text(blocked_str, no_wrap=True)
            # Ambient deliverable cells dim slightly so the scoped tracks
            # visually float to the foreground — operator at-a-glance
            # signal for "where is real product work happening".
            if deliverable_str == _AMBIENT_DELIVERABLE:
                deliverable_text = Text(deliverable_str, style="dim", no_wrap=True)
            else:
                deliverable_text = Text(deliverable_str, no_wrap=True)

            # v0.4.72 items 13+14: runtime relocated between activity
            # and 📨; followup glyph swapped ☑ → ✅. v0.4.78 item 29:
            # deliverable column inserted before focus. Column order:
            #   ▸/▾ | state | name | activity | runtime | 📨 | ✅ | deliverable | focus | plan | blocked | cost
            table.add_row(
                expand_marker,
                state_text,
                name_text,
                activity_text,
                runtime,
                str(unread) if unread else "-",
                str(followups) if followups else "-",
                deliverable_text,
                focus_text,
                plan_text,
                blocked_text,
                cost,
                key=f"track:{name}",
            )
            self._track_rows.append(name)
            new_row_count += 1

        # Restore cursor position
        if new_row_count > 0:
            table.move_cursor(row=min(old_cursor, new_row_count - 1))

        # Bundled-polish item 3 — restore scroll. Deferred via
        # call_after_refresh so max_scroll_y reflects the new row count.
        def _restore_scroll() -> None:
            try:
                if was_at_bottom:
                    table.scroll_end(animate=False)
                else:
                    table.scroll_y = old_scroll_y
            except Exception:
                pass
        self.call_after_refresh(_restore_scroll)

        # Bundled-polish item 4 — render the expanded-track tail panel
        # below the DataTable with ANSI escape sequences parsed as styled
        # Rich text.
        self._refresh_expand_tail()

    # ── actions ────────────────────────────────────────────────────────────

    def on_key(self, event: Key) -> None:
        """Explicit key routing — belt-and-suspenders over BINDINGS priority=True.

        Textual 0.89.x DataTable swallows keypresses before App-level BINDINGS
        fire even with priority=True. Route explicitly here to guarantee all
        shortcuts invoke their handlers.
        """
        if self._filtering:
            return  # Input widget handles keys while filter is active
        # v0.4.73 item 19: when focus is on the tail panel, route the
        # navigation keys (j/k/down/up) to scroll the tail content
        # instead of moving the table cursor. PgUp/PgDn/Home/End fall
        # through to the existing block below (works in both focus modes).
        if (
            self._focus_target == "tail"
            and self._expanded_track is not None
            and event.key in ("j", "k", "down", "up")
        ):
            try:
                scroll = self.query_one("#expand-tail-scroll", VerticalScroll)
            except Exception:
                scroll = None
            if scroll is not None:
                event.prevent_default()
                event.stop()
                if event.key in ("j", "down"):
                    scroll.scroll_down(animate=False)
                else:
                    scroll.scroll_up(animate=False)
                return
        # v0.4.71 item 12: PgUp/PgDn/Home/End scroll the tail panel when
        # a track is expanded. When nothing is expanded, these keys fall
        # through to default DataTable scrolling.
        if self._expanded_track is not None and event.key in (
            "pageup", "pagedown", "home", "end",
        ):
            try:
                scroll = self.query_one("#expand-tail-scroll", VerticalScroll)
            except Exception:
                scroll = None
            if scroll is not None:
                event.prevent_default()
                event.stop()
                if event.key == "pageup":
                    scroll.scroll_page_up(animate=False)
                elif event.key == "pagedown":
                    scroll.scroll_page_down(animate=False)
                elif event.key == "home":
                    scroll.scroll_home(animate=False)
                elif event.key == "end":
                    scroll.scroll_end(animate=False)
                return
        key_to_action: dict[str, str] = {
            "j": "cursor_down",
            "k": "cursor_up",
            "down": "cursor_down",
            "up": "cursor_up",
            "space": "toggle_expand",
            "enter": "open_session",
            "e": "toggle_enable",
            "i": "open_inbox",
            "s": "wake_start",
            "x": "wake_stop",
            "tab": "toggle_focus",
            "plus": "tail_grow",
            "equals_sign": "tail_grow",
            "minus": "tail_shrink",
            "slash": "focus_filter",
            "escape": "clear_filter",
            "q": "quit",
        }
        action_name = key_to_action.get(event.key)
        if action_name is not None:
            event.prevent_default()
            event.stop()
            self.call_later(self.run_action, action_name)

    def _move_cursor_skip_expand(self, direction: int) -> None:
        """Advance cursor by `direction` (±1), skipping expand: sub-rows.

        The selection set is "top-level track rows only" — expand-row
        keys (prefix `expand:`) are display-only and never selectable.
        Wraps top↔bottom.
        """
        table: DataTable = self.query_one("#dashboard-table", DataTable)
        row_keys = list(table.rows.keys())
        n = len(row_keys)
        if n == 0:
            return
        current = table.cursor_row
        for step in range(1, n + 1):
            idx = (current + direction * step) % n
            key = row_keys[idx].value
            if key and key.startswith("track:"):
                table.move_cursor(row=idx)
                return

    def action_cursor_down(self) -> None:
        self._move_cursor_skip_expand(1)

    def action_cursor_up(self) -> None:
        self._move_cursor_skip_expand(-1)

    def action_toggle_expand(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        # Single-track expansion (item 4): toggling the currently-expanded
        # track collapses it; toggling any other track replaces the
        # expansion. The tail is rendered in the full-width bottom panel.
        if self._expanded_track == track:
            self._expanded_track = None
            # v0.4.73 item 19: collapsing the tail panel restores focus
            # to the table — otherwise the operator could end up with
            # focus on a now-invisible widget.
            if self._focus_target != "table":
                try:
                    tbl = self.query_one("#dashboard-table", DataTable)
                    scr = self.query_one("#expand-tail-scroll", VerticalScroll)
                    tbl.focus()
                    tbl.add_class("has-focus")
                    scr.remove_class("has-focus")
                    self._focus_target = "table"
                except Exception:
                    pass
        else:
            self._expanded_track = track
        self._refresh_table()

    # ── v0.4.73 item 18: tail-panel resize ─────────────────────────────────

    def _apply_tail_max_height(self) -> None:
        """Set the VerticalScroll max-height from self._tail_lines.

        Static CSS can't reference instance state, so we set the style
        imperatively at mount time and after every resize. Bounded by
        the current terminal height so the panel can't push the
        DataTable below visibility.
        """
        try:
            scroll = self.query_one("#expand-tail-scroll", VerticalScroll)
        except Exception:
            return
        # Cap at terminal_height - 5 so the table stays visible. Fall back
        # to self._tail_lines when self.size isn't populated yet (boot).
        try:
            term_h = int(self.size.height) if self.size.height else 0
        except Exception:
            term_h = 0
        if term_h > 0:
            ceiling = max(_TAIL_LINES_MIN, term_h - 5)
            applied = min(self._tail_lines, ceiling)
        else:
            applied = self._tail_lines
        scroll.styles.max_height = applied

    def _resize_tail(self, delta: int) -> None:
        """Adjust the tail-panel line count and persist the new value.

        Clamps to [_TAIL_LINES_MIN, terminal_height - 5]. Writes to
        ~/.config/reflect/dashboard.yaml so the choice survives restart.
        No-ops when the new value equals the current.
        """
        try:
            term_h = int(self.size.height) if self.size.height else 0
        except Exception:
            term_h = 0
        if term_h > 0:
            hard_max = max(_TAIL_LINES_MIN, term_h - 5)
        else:
            hard_max = _TAIL_LINES_MAX
        new_val = max(_TAIL_LINES_MIN, min(hard_max, self._tail_lines + delta))
        if new_val == self._tail_lines:
            return
        self._tail_lines = new_val
        # Persist (best-effort; never raises). Loading priority puts env
        # var above the config file, so a user with the env var set will
        # see runtime changes apply to the live session but not persist —
        # documented behavior.
        cfg = _load_dashboard_config()
        cfg["expanded_tail_lines"] = new_val
        _save_dashboard_config(cfg)
        # Re-render the tail panel with the new line count and update
        # the visible max-height immediately.
        self._apply_tail_max_height()
        self._refresh_expand_tail()

    # ── v0.4.77 item 23: column-sort actions ───────────────────────────────

    def _set_sort(self, column: str) -> None:
        """Apply or toggle a user-driven sort by `column`.

        Pressing the same column key twice flips ascending ↔ descending.
        Pressing a new column key sets ascending. Persists the new
        (column, direction) to ~/.config/reflect/dashboard.yaml so the
        operator's choice survives a dashboard restart.
        """
        if column not in _SORTABLE_COLUMNS:
            return
        if self._sort_column == column:
            self._sort_direction = "desc" if self._sort_direction == "asc" else "asc"
        else:
            self._sort_column = column
            self._sort_direction = "asc"
        self._persist_sort()
        self._apply_sort_indicators()
        self._refresh_table()

    def _clear_sort(self) -> None:
        """Drop the user-driven sort and return to the default ordering."""
        if self._sort_column is None:
            return
        self._sort_column = None
        self._sort_direction = "asc"
        self._persist_sort()
        self._apply_sort_indicators()
        self._refresh_table()

    def _persist_sort(self) -> None:
        cfg = _load_dashboard_config()
        if self._sort_column is None:
            cfg.pop("sort_column", None)
            cfg.pop("sort_direction", None)
        else:
            cfg["sort_column"] = self._sort_column
            cfg["sort_direction"] = self._sort_direction
        _save_dashboard_config(cfg)

    # Display labels per column key — match the headers added in on_mount.
    # When the active sort points at one of these columns, the label gets
    # an `↑` or `↓` suffix so the operator can see what they sorted by.
    _SORT_HEADER_BASE = {
        "expand": "▸/▾",
        "state": "state",
        "name": "name",
        "activity": "activity",
        "runtime": "runtime",
        "inbox": "📨",
        "followup": "✅",
        "deliverable": "deliverable",
        "focus": "focus",
        "plan": "plan",
        "blocked": "blocked",
        "cost": "cost",
    }

    def _apply_sort_indicators(self) -> None:
        """Refresh DataTable column header labels with sort arrows.

        Mutates the `.label` of each `Column` via the ColumnKey handles
        stored in `self._col_keys`. Best-effort — silently swallows any
        Textual-internal access errors so a sort-key press never crashes
        the app.
        """
        try:
            table: DataTable = self.query_one("#dashboard-table", DataTable)
        except Exception:
            return
        arrow = " ↑" if self._sort_direction == "asc" else " ↓"
        for col_name, base in self._SORT_HEADER_BASE.items():
            key = self._col_keys.get(col_name)
            if key is None:
                continue
            col = table.columns.get(key)
            if col is None:
                continue
            if self._sort_column == col_name:
                new_label = Text(f"{base}{arrow}", style="bold yellow")
            else:
                new_label = base
            try:
                col.label = new_label
            except Exception:
                pass
        # Force a header repaint by toggling DataTable refresh.
        try:
            table.refresh()
        except Exception:
            pass

    def action_sort_name(self) -> None:
        self._set_sort("name")

    def action_sort_activity(self) -> None:
        self._set_sort("activity")

    def action_sort_runtime(self) -> None:
        self._set_sort("runtime")

    def action_sort_inbox(self) -> None:
        self._set_sort("inbox")

    def action_sort_followup(self) -> None:
        self._set_sort("followup")

    def action_sort_cost(self) -> None:
        self._set_sort("cost")

    def action_sort_state(self) -> None:
        self._set_sort("state")

    def action_sort_deliverable(self) -> None:
        # v0.4.78 item 29: lexical sort by deliverable slug.
        self._set_sort("deliverable")

    def action_sort_clear(self) -> None:
        self._clear_sort()

    def action_tail_grow(self) -> None:
        self._resize_tail(+_TAIL_LINES_STEP)

    def action_tail_shrink(self) -> None:
        self._resize_tail(-_TAIL_LINES_STEP)

    # ── v0.4.73 item 19: focus toggle ──────────────────────────────────────

    def action_toggle_focus(self) -> None:
        """Switch keyboard focus between the table and the tail panel.

        No-op when no track is expanded (tail panel not visible).
        Updates the has-focus class for visual indication and flips
        self._focus_target so on_key routes j/k correctly.
        """
        if self._expanded_track is None:
            return  # Tail panel not visible — nothing to switch to.
        try:
            table = self.query_one("#dashboard-table", DataTable)
            scroll = self.query_one("#expand-tail-scroll", VerticalScroll)
        except Exception:
            return
        if self._focus_target == "table":
            scroll.focus()
            table.remove_class("has-focus")
            scroll.add_class("has-focus")
            self._focus_target = "tail"
        else:
            table.focus()
            scroll.remove_class("has-focus")
            table.add_class("has-focus")
            self._focus_target = "table"

    def _refresh_expand_tail(self) -> None:
        """Render the currently-expanded track's tail log into the
        bottom panel with ANSI escape sequences parsed as styled Rich text.

        Bundled-polish item 4 (originator directive 2026-05-20T08:39Z).
        Replaces the prior DataTable column-0 sub-row approach which
        clipped tail content to the 3-char ▸/▾ column width and rendered
        ANSI escapes as literal `\\x1b[...m` text.
        """
        try:
            panel = self.query_one("#expand-tail", Static)
            scroll = self.query_one("#expand-tail-scroll", VerticalScroll)
        except Exception:
            return
        track = self._expanded_track
        if track is None:
            scroll.remove_class("visible")
            panel.update("")
            return
        # v0.4.73 item 18: line count is per-instance (self._tail_lines)
        # and mutable via the +/- hotkeys. _expanded_lines() seeds the
        # initial value at __init__.
        lines = _tail_lines(track, self._tail_lines)
        if not lines:
            body = Text("(no log)", style="dim italic")
            line_count = 0
        else:
            body = Text(no_wrap=False)
            for i, line in enumerate(lines):
                if i > 0:
                    body.append("\n")
                # v0.4.71 item 10: _colorize_tail_line applies heuristic
                # styling (cyan for Read/Glob/Grep, green for Bash, magenta
                # for Write/Edit, red for errors, yellow for warnings).
                # Embedded ANSI escapes — if present — pass through via
                # Text.from_ansi inside the helper.
                body.append_text(_colorize_tail_line(line))
            line_count = len(lines)
        # Header: track-colored bar identifying which track this is.
        bg, fg = _track_color(track)
        header = Text(
            f" {track}  ·  tail ({line_count} lines) ",
            style=f"bold {fg} on {bg}",
            no_wrap=True,
        )
        # v0.4.75 item 21: render full focus / plan / blocked_on sections
        # above the tail when the corresponding track status.yaml fields
        # are populated. Each section is omitted entirely when its field
        # is null / missing / empty (no "(none)" placeholders per the
        # originator directive 2026-05-20T10:27Z).
        # v0.4.81: _render_status_block always returns Text now (with
        # "(not set)" placeholders for empty fields). No conditional —
        # the block always sits between header and tail body so the
        # operator gets visible confirmation that the feature renders
        # regardless of whether the track has populated focus/plan/
        # blocked_on. Per third-complaint escalation 2026-05-20T11:49Z.
        status_payload = _read_track_status_safe(track)
        status_block = _render_status_block(status_payload)
        full = Text.assemble(header, "\n", status_block, "\n", body)
        scroll.add_class("visible")
        panel.update(full)
        # Auto-scroll to bottom so newest tail lines are visible by default.
        # User can PgUp to review earlier content.
        try:
            scroll.scroll_end(animate=False)
        except Exception:
            pass

    def action_open_session(self) -> None:
        """Open the interactive session view for the selected track.

        Suspends the dashboard, runs SessionApp via the reflect CLI as a
        subprocess, then resumes the dashboard when the user exits.  This
        preserves the dashboard's full state (cursor, filter, expanded set)
        across the round-trip, and avoids asyncio event-loop nesting that
        would result from calling SessionApp.run() inside the dashboard's
        own loop.
        """
        track = self._selected_track()
        if track is None:
            return
        with self.suspend():
            subprocess.run(["reflect", "track", "session", track])

    def action_toggle_enable(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        from agent.runtime.track_flags import is_manual, set_manual, clear_manual
        track_dir = self.tracks_dir / track
        if is_manual(track_dir):
            clear_manual(track_dir)
        else:
            set_manual(track_dir)
        self._refresh_table()

    def action_open_inbox(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        self.exit(track)

    def action_open_originator_inbox(self) -> None:
        """v0.4.77 item 26: jump straight to the originator's inbox.

        The caller (cmd_dashboard in agent/cli/dashboard.py) opens an
        InboxApp on whatever string we return from .exit(). Passing
        the literal "originator" routes the operator there regardless
        of the cursor's current row. The selected-track shortcut `i`
        is unchanged.
        """
        self.exit("originator")

    def action_wake_start(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        subprocess.Popen(
            ["reflect", "wake", "start", track],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    def action_wake_stop(self) -> None:
        track = self._selected_track()
        if track is None:
            return
        subprocess.Popen(
            ["reflect", "wake", "stop", track],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    def action_focus_filter(self) -> None:
        inp: Input = self.query_one("#filter-input", Input)
        inp.add_class("visible")
        inp.focus()
        self._filtering = True

    def action_clear_filter(self) -> None:
        if self._filtering:
            inp: Input = self.query_one("#filter-input", Input)
            inp.remove_class("visible")
            inp.value = ""
            self._filter = ""
            self._filtering = False
            self.query_one("#dashboard-table", DataTable).focus()
            self._refresh_table()

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "filter-input":
            self._filter = event.value
            self._refresh_table()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "filter-input":
            self.action_clear_filter()
