"""Inbox TUI — interactive viewer for reflect inbox <track> -i.

Polling model: uses set_interval(2.0, ...) to check for new files every 2s.
No inotify — deliberate choice to keep deps minimal and behaviour predictable
across platforms (including NFS-mounted project dirs).
"""
from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.events import Key
from textual.widgets import Footer, Header, ListItem, ListView, Markdown, Static
from textual.containers import Horizontal, VerticalScroll


# v0.4.77 item 27 (originator directive 2026-05-20T10:58Z): restore the
# "cute mail app" feel that v0.4.71 item 7 stripped when it swapped
# Markdown → Static to fix paragraph-spacing inflation.
#
# Fix path (a) from the directive: re-introduce Markdown rendering for
# the preview pane, but tighten the per-paragraph margin so the doubled-
# spacing regression doesn't return. Textual's `Markdown` widget renders
# each markdown block (paragraph, heading, code-fence, blockquote) as a
# distinct DOM widget; we target those widget classes via CSS and zero
# their margins. The result: rendered headers + bold + code-fences, but
# without the paragraph-level padding that caused doubled newlines to
# render as quadrupled.
#
# List-item shape: two visual lines per item — glyph + timestamp + sender
# on line 1, subject on line 2. Glyph dispatches by `kind` field from the
# message's YAML frontmatter (📬 report, 📨 request, ✅ followup, …);
# missing frontmatter falls back to the filename verbatim, so messages
# without our standard schema are still listed.

# Match the YAML frontmatter envelope on an inbox message. Lazy DOTALL
# capture between two `---\n` lines.
_FRONTMATTER_RX = re.compile(
    r"\A---\n(.*?)\n---\n", re.DOTALL
)

# Map `kind:` enum (per protocol.md P9) to a single-glyph icon. Anything
# unmapped falls through to 📄 so the list item still has a visual anchor.
_KIND_ICON = {
    "report": "📬",
    "request": "📨",
    "deploy-request": "🚀",
    "btw": "💬",
    "broadcast": "📢",
    "followup": "✅",
    "decision": "🔖",
}


def _parse_frontmatter(text: str) -> dict[str, str]:
    """Tiny YAML-frontmatter parser — strings + scalars only.

    Avoids pulling pyyaml just for the inbox list-item rendering. We only
    need `from`, `at`, `kind`, and `subject` to shape the list item;
    everything else can fall back to filename heuristics. Returns an
    empty dict on no-frontmatter, parse error, or unknown shape.
    """
    m = _FRONTMATTER_RX.match(text)
    if not m:
        return {}
    out: dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" not in line:
            continue
        k, _, v = line.partition(":")
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and v:
            out[k] = v
    return out


def _list_item_label(path: Path, *, selected: bool = False) -> Text:
    """Two-line Rich Text label for a file in the inbox ListView.

    Line 1: gutter glyph + kind icon + short timestamp + sender
    Line 2: gutter + subject (from frontmatter or first heading)

    v0.4.81 (originator directive 2026-05-20T12:00Z, third inbox-
    polish item): the selected row gets a leading ``▶`` indicator in
    a fixed-width gutter; unselected rows get two spaces. Combined
    with the stronger CSS highlight (background + bold) the selected
    row is unambiguously distinct at a glance.

    Falls back to the bare filename on parse failure so the list never
    renders blank rows.
    """
    try:
        text = path.read_text()
    except OSError:
        text = ""
    fm = _parse_frontmatter(text)
    kind = fm.get("kind", "")
    icon = _KIND_ICON.get(kind, "📄")
    sender = fm.get("from", "")
    at_raw = fm.get("at", "")
    # Compress 2026-05-20T10-50-27Z → 05-20 10:50 for terminal-narrow display.
    short_at = ""
    if at_raw and len(at_raw) >= 16:
        try:
            short_at = at_raw[5:10].replace("-", "/") + " " + at_raw[11:16].replace("-", ":")
        except IndexError:
            short_at = at_raw[:16]
    subject = fm.get("subject", "")
    if not subject:
        # Fall back to first non-empty markdown heading inside the body.
        body = text[(text.index("\n---\n") + 5) :] if "\n---\n" in text else text
        for line in body.splitlines():
            s = line.strip()
            if s.startswith("# "):
                subject = s[2:].strip()
                break
        if not subject:
            subject = path.stem

    # Two-column gutter: ▶ on selected, two spaces on unselected.
    gutter_glyph = "▶ " if selected else "  "

    line1 = Text()
    line1.append(gutter_glyph, style="bold #fbbf24" if selected else "")
    line1.append(f"{icon} ", style="")
    if short_at:
        line1.append(f"{short_at}  ", style="bold cyan")
    if sender:
        line1.append(f"{sender}", style="bold magenta")
    line2 = Text("    ", style="")  # 2 gutter cols + 2 indent to align under timestamp
    # Truncate subject so it never wraps inside a row.
    if len(subject) > 80:
        subject = subject[:79] + "…"
    line2.append(subject, style="dim")
    out = Text()
    out.append_text(line1)
    out.append("\n")
    out.append_text(line2)
    return out


# v0.4.81 (originator directive 2026-05-20T11:59Z): when the inbox
# preview pane renders a message, the YAML frontmatter block at the
# top must preserve its line structure. Textual's Markdown widget
# treats `---` as <hr> and folds inner newlines into spaces — the
# frontmatter rendered as one smooshed line. Pre-process the file
# content so the frontmatter becomes a fenced ```yaml code block.
# Renders distinctly + preserves all line breaks.
_PREVIEW_FRONTMATTER_RX = re.compile(
    r"\A---\n(.*?)\n---\n", re.DOTALL
)


def _preprocess_preview(text: str) -> str:
    """Wrap leading YAML frontmatter in a ```yaml code fence so the
    Markdown preview widget preserves its line structure instead of
    collapsing it into one line via the markdown soft-newline rule.

    Idempotent on input without frontmatter (returns unchanged).
    """
    m = _PREVIEW_FRONTMATTER_RX.match(text)
    if not m:
        return text
    yaml_body = m.group(1)
    rest = text[m.end():]
    return f"```yaml\n{yaml_body}\n```\n\n{rest}"


class InboxApp(App[None]):
    """Interactive inbox viewer for a single track."""

    # v0.4.77 item 27 — "cute mail app" restoration:
    #
    # 1. Preview pane uses Textual's `Markdown` widget again (headers, bold,
    #    code-fences render). Tight CSS overrides on its child block widgets
    #    keep the doubled-paragraph-padding regression from returning.
    # 2. ListView styled with a track-accent border, padding, and a
    #    distinct highlight bar on the focused row (cyan-on-navy bar).
    # 3. Preview pane has a subtle indented padding for the mail-app feel.
    CSS = """
    Horizontal {
        height: 1fr;
    }
    ListView {
        width: 1fr;
        border: round #7dd3fc;
        background: #0f172a;
        padding: 0 1;
    }
    ListView > ListItem {
        padding: 0 1;
        background: transparent;
    }
    /* v0.4.81 (originator directive 2026-05-20T12:00Z): selected row
       gets three layers of emphasis — accent background, white text,
       bold weight. Paired with the leading ▶ glyph rebuilt into the
       row label on highlight change (see on_list_view_highlighted),
       the selected row pops at a glance even on dim terminals. */
    ListView > ListItem.--highlight {
        background: #7dd3fc;
        color: #0f172a;
        text-style: bold;
    }
    #preview-scroll {
        width: 2fr;
        border: round #a78bfa;
        background: #0f172a;
        padding: 0 1;
    }
    #preview {
        height: auto;
        padding: 0 1;
    }
    /* v0.4.77 item 27 / fix path (a): tighten Markdown block spacing so
       paragraphs render once-paragraph not double. Each MarkdownBlock
       subclass is a distinct widget in Textual; CSS-target them by class
       and zero their margins. */
    Markdown {
        background: transparent;
        margin: 0;
        padding: 0;
    }
    Markdown > MarkdownParagraph,
    Markdown > MarkdownBlockQuote,
    Markdown > MarkdownBulletList,
    Markdown > MarkdownOrderedList,
    Markdown > MarkdownList,
    Markdown > MarkdownFence,
    Markdown > MarkdownTable,
    Markdown > MarkdownHorizontalRule {
        margin: 0;
        padding: 0;
    }
    Markdown > MarkdownH1,
    Markdown > MarkdownH2,
    Markdown > MarkdownH3 {
        margin: 1 0 0 0;
        padding: 0;
        text-style: bold;
        color: #7dd3fc;
    }
    Markdown > MarkdownH4,
    Markdown > MarkdownH5,
    Markdown > MarkdownH6 {
        margin: 1 0 0 0;
        padding: 0;
        color: #a78bfa;
    }
    Markdown MarkdownFence {
        background: #1e293b;
        color: #e2e8f0;
    }
    """

    BINDINGS = [
        Binding("j", "cursor_down", "Down", show=True),
        Binding("k", "cursor_up", "Up", show=True),
        Binding("pageup", "scroll_preview_up", "Page-up preview", show=True),
        Binding("pagedown", "scroll_preview_down", "Page-down preview", show=True),
        Binding("home", "scroll_preview_home", "Top preview", show=False),
        Binding("end", "scroll_preview_end", "Bottom preview", show=False),
        Binding("enter", "open_editor", "Open in $EDITOR", show=True),
        Binding("c", "mark_consumed", "Consume", show=True),
        Binding("q", "quit", "Quit", show=True),
    ]

    def __init__(self, track: str, inbox_dir: Path) -> None:
        super().__init__()
        self.track = track
        self.inbox_dir = inbox_dir
        self.consumed_dir = inbox_dir / ".consumed"
        self._files: list[Path] = []
        # v0.4.81: parallel array of Static widgets backing each
        # ListItem's two-line label, so on_list_view_highlighted can
        # re-render the previously-highlighted and newly-highlighted
        # rows to flip the ▶ gutter glyph without rebuilding the list.
        self._label_widgets: list[Static] = []
        self._last_highlighted_idx: int | None = None

    # ── lifecycle ──────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Horizontal():
            yield ListView(id="file-list")
            with VerticalScroll(id="preview-scroll"):
                # v0.4.77 item 27: restored Markdown widget. Tight CSS
                # on the block-level children keeps paragraph padding
                # from inflating doubled-newlines into quads (the bug
                # that justified the v0.4.71 swap to Static). markdown
                # initial value is a hint; first highlight fires
                # _update_preview which re-populates with real content.
                yield Markdown(
                    "*Select a message to preview.*",
                    id="preview",
                )
        yield Footer()

    def on_mount(self) -> None:
        self.title = f"reflect inbox  ·  {self.track}"
        self._load_files()
        self.set_interval(2.0, self._refresh_files)

    # ── internal helpers ───────────────────────────────────────────────────

    def _unread_files(self) -> list[Path]:
        if not self.inbox_dir.exists():
            return []
        consumed_names: set[str] = set()
        if self.consumed_dir.exists():
            consumed_names = {p.name for p in self.consumed_dir.glob("*.md")}
        return sorted(
            [p for p in self.inbox_dir.glob("*.md") if p.name not in consumed_names],
            reverse=True,
        )

    def _load_files(self) -> None:
        self._files = self._unread_files()
        lv: ListView = self.query_one("#file-list", ListView)
        lv.clear()
        self._label_widgets = []
        # First file gets the ▶ gutter; the rest get two spaces.
        for i, f in enumerate(self._files):
            # v0.4.77 item 27: render each list item as a Rich Text
            # mail-row (glyph + timestamp + sender on line 1, subject
            # preview on line 2). `_list_item_label` parses the YAML
            # frontmatter; missing fields fall back to filename.
            # v0.4.81: pass selected= so the leading ▶ gutter is
            # rendered for the initially-highlighted row.
            label_widget = Static(
                _list_item_label(f, selected=(i == 0)), markup=False
            )
            self._label_widgets.append(label_widget)
            lv.append(ListItem(label_widget))
        if self._files:
            lv.index = 0
            self._last_highlighted_idx = 0
            self._update_preview(self._files[0])
        else:
            self._last_highlighted_idx = None
            self._set_preview("*No unread messages.*")

    def _set_preview(self, markdown_text: str) -> None:
        """Helper — `Markdown.update` is async-only on some Textual
        versions; call it through a tiny wrapper so callers don't have
        to know the API shape. Best-effort; never raises."""
        try:
            md: Markdown = self.query_one("#preview", Markdown)
        except Exception:
            return
        try:
            # Markdown.update is a coroutine in modern Textual; schedule
            # it as a task so callers stay synchronous.
            import inspect
            res = md.update(markdown_text)
            if inspect.iscoroutine(res):
                self.run_worker(res, exclusive=False)
        except Exception:
            pass

    def _update_preview(self, path: Path, *, preserve_scroll: bool = False) -> None:
        try:
            content = path.read_text()
        except OSError:
            content = f"Could not read {path.name}"
        # v0.4.81 (originator directive 2026-05-20T11:59Z): wrap YAML
        # frontmatter in a fenced ```yaml block so the Markdown widget
        # preserves its line structure instead of folding it onto one
        # line via the markdown soft-newline rule.
        content = _preprocess_preview(content)
        # v0.4.74 item 20: when polling-refresh re-paints the same file, the
        # preview must NOT jump back to the top. Capture scroll state before
        # update and restore it after Textual settles the new layout when
        # caller asks for preservation. File-change keystrokes still reset
        # to top (default preserve_scroll=False).
        old_y = 0.0
        was_at_bottom = False
        scroll: VerticalScroll | None = None
        if preserve_scroll:
            try:
                scroll = self.query_one("#preview-scroll", VerticalScroll)
                old_y = float(scroll.scroll_y)
                old_max = float(scroll.max_scroll_y)
                was_at_bottom = old_max > 0 and old_y >= old_max - 0.5
            except Exception:
                scroll = None
        self._set_preview(content)
        if preserve_scroll and scroll is not None:
            captured_scroll = scroll
            captured_y = old_y
            captured_bottom = was_at_bottom

            def _restore_preview() -> None:
                try:
                    if captured_bottom:
                        captured_scroll.scroll_end(animate=False)
                    else:
                        captured_scroll.scroll_to(y=captured_y, animate=False)
                except Exception:
                    pass

            # Two-stage restore (same reason as ListView): post-update
            # Static needs a layout pass before max_scroll_y reflects content.
            self.call_after_refresh(_restore_preview)
            self.set_timer(0.05, _restore_preview)
        else:
            # File-change: reset to top.
            try:
                self.query_one("#preview-scroll", VerticalScroll).scroll_home(animate=False)
            except Exception:
                pass

    def _selected_path(self) -> Path | None:
        lv: ListView = self.query_one("#file-list", ListView)
        idx = lv.index
        if idx is None or idx >= len(self._files):
            return None
        return self._files[idx]

    # ── polling refresh ────────────────────────────────────────────────────

    def _refresh_files(self) -> None:
        new_files = self._unread_files()
        if new_files != self._files:
            lv: ListView = self.query_one("#file-list", ListView)
            # v0.4.74 item 20: mirror dashboard v0.4.71 item 3 — capture
            # ListView scroll state and the previously-selected file BEFORE
            # clear(). After clear+rebuild the listview's scroll_y snaps to
            # 0, yanking the operator off whatever message they were
            # scrolled to. Restore via call_after_refresh once max_scroll_y
            # reflects the new row count. Also tell _update_preview to
            # preserve preview scroll when the same file is still selected
            # (its content didn't change — only the file list did).
            old_idx = lv.index or 0
            old_path = self._files[old_idx] if (old_idx < len(self._files)) else None
            old_scroll_y = float(lv.scroll_y)
            old_max_scroll = float(lv.max_scroll_y)
            was_at_bottom = (
                old_max_scroll > 0 and old_scroll_y >= old_max_scroll - 0.5
            )

            self._files = new_files
            lv.clear()
            self._label_widgets = []
            # Pre-compute the new highlight target so the initial label
            # render gets the ▶ gutter on the correct row.
            if self._files:
                if old_path is not None and old_path in self._files:
                    new_idx = self._files.index(old_path)
                    same_file = True
                else:
                    new_idx = min(old_idx, len(self._files) - 1)
                    same_file = False
            else:
                new_idx = None
                same_file = False
            for i, f in enumerate(self._files):
                label_widget = Static(
                    _list_item_label(f, selected=(i == new_idx)), markup=False
                )
                self._label_widgets.append(label_widget)
                lv.append(ListItem(label_widget))
            if self._files and new_idx is not None:
                lv.index = new_idx
                self._last_highlighted_idx = new_idx
                self._update_preview(self._files[new_idx], preserve_scroll=same_file)
            else:
                self._last_highlighted_idx = None
                self._set_preview("*No unread messages.*")

            def _restore_list_scroll() -> None:
                try:
                    if was_at_bottom:
                        lv.scroll_end(animate=False)
                    else:
                        # Some Textual versions cap scroll_y to max at write
                        # time; scroll_to handles bounds correctly once
                        # layout has settled.
                        lv.scroll_to(y=old_scroll_y, animate=False)
                except Exception:
                    pass

            # Two-stage restore: layout settles across one refresh cycle,
            # then a short timer catches the post-layout geometry. The
            # listview's max_scroll_y is recomputed from ItemHeight*N — that
            # arithmetic isn't valid until items have been measured.
            self.call_after_refresh(_restore_list_scroll)
            self.set_timer(0.05, _restore_list_scroll)

    # ── reactive ───────────────────────────────────────────────────────────

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        lv: ListView = self.query_one("#file-list", ListView)
        idx = lv.index
        if idx is not None and idx < len(self._files):
            # v0.4.81 (item 31): flip the ▶ gutter glyph on the
            # newly- and previously-highlighted rows so the selected
            # row is unambiguous at a glance. Combined with the CSS
            # `--highlight` rule (accent bg + bold), the selected row
            # pops visually without relying on terminal-theme defaults.
            prev = self._last_highlighted_idx
            if prev is not None and 0 <= prev < len(self._label_widgets) and prev != idx:
                try:
                    self._label_widgets[prev].update(
                        _list_item_label(self._files[prev], selected=False)
                    )
                except Exception:
                    pass
            if 0 <= idx < len(self._label_widgets):
                try:
                    self._label_widgets[idx].update(
                        _list_item_label(self._files[idx], selected=True)
                    )
                except Exception:
                    pass
            self._last_highlighted_idx = idx
            self._update_preview(self._files[idx])

    # ── actions ────────────────────────────────────────────────────────────

    def action_cursor_down(self) -> None:
        self.query_one("#file-list", ListView).action_cursor_down()

    def action_cursor_up(self) -> None:
        self.query_one("#file-list", ListView).action_cursor_up()

    # v0.4.71 item 8: scroll the preview pane via PgUp/PgDn/Home/End
    # bindings. ListView keeps its own j/k for file selection.
    def action_scroll_preview_up(self) -> None:
        try:
            self.query_one("#preview-scroll", VerticalScroll).scroll_page_up(animate=False)
        except Exception:
            pass

    def action_scroll_preview_down(self) -> None:
        try:
            self.query_one("#preview-scroll", VerticalScroll).scroll_page_down(animate=False)
        except Exception:
            pass

    def action_scroll_preview_home(self) -> None:
        try:
            self.query_one("#preview-scroll", VerticalScroll).scroll_home(animate=False)
        except Exception:
            pass

    def action_scroll_preview_end(self) -> None:
        try:
            self.query_one("#preview-scroll", VerticalScroll).scroll_end(animate=False)
        except Exception:
            pass

    def action_open_editor(self) -> None:
        path = self._selected_path()
        if path is None:
            return
        editor = os.environ.get("EDITOR", "nano")
        with self.suspend():
            subprocess.run([editor, str(path)])

    def action_mark_consumed(self) -> None:
        path = self._selected_path()
        if path is None:
            return
        self.consumed_dir.mkdir(parents=True, exist_ok=True)
        dest = self.consumed_dir / path.name
        path.rename(dest)
        self._load_files()
