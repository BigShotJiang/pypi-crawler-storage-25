"""Inbox subcommands for the reflect CLI."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from .output import OutputMode, print_list
from .ops.track import TRACKS_DIR, list_tracks as _track_names


def _inbox_files_for_track(name: str) -> list[dict]:
    track_dir = TRACKS_DIR / name
    inbox_dir = track_dir / "inbox"
    consumed_dir = inbox_dir / ".consumed"

    if not inbox_dir.exists():
        return []

    consumed_names: set[str] = set()
    if consumed_dir.exists():
        consumed_names = set(p.name for p in consumed_dir.glob("*.md"))

    files = []
    # P9: only .md files directly in inbox/ (not subdirs)
    for p in sorted(inbox_dir.glob("*.md"), reverse=True):
        if p.is_dir():
            continue
        if p.name in consumed_names:
            continue
        try:
            mtime = p.stat().st_mtime
            mtime_str = datetime.fromtimestamp(mtime, tz=timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
        except OSError:
            mtime_str = "-"
        files.append({
            "track": name,
            "filename": p.name,
            "mtime": mtime_str,
        })
    return files


def _render_timeline_human(entries: list[dict]) -> None:
    """Print a time-ordered interleaved inbox view to stdout."""
    if not entries:
        print("No messages found.")
        return

    # Compute column widths
    ts_w = max(len(e["timestamp"]) for e in entries)
    ts_w = max(ts_w, len("timestamp"))
    dir_w = 9   # "←user" / "→agent" padded
    status_w = 8  # "consumed" is longest

    header = (
        f"{'timestamp':<{ts_w}}  {'dir':<{dir_w}}  {'status':<{status_w}}  title"
    )
    print(header)
    print("-" * min(len(header) + 40, 120))

    for e in entries:
        ts = e["timestamp"]
        direction = e["direction"]
        status = e["status"]
        title = e["title"]
        # Truncate title to avoid very long lines
        if len(title) > 60:
            title = title[:57] + "..."
        print(f"{ts:<{ts_w}}  {direction:<{dir_w}}  {status:<{status_w}}  {title}")


def cmd_inbox(args) -> None:
    mode = OutputMode(args.output)
    track_filter = getattr(args, "track", None)
    interleave = getattr(args, "interleave", False)
    pending_only = getattr(args, "pending_only", False)
    limit = getattr(args, "limit", 50)
    since = getattr(args, "since", None)

    # ── interleaved timeline mode ────────────────────────────────────────────
    if interleave:
        if not track_filter:
            print(
                "inbox -i requires a track name; pass it via --track / -t, "
                "e.g.: reflect inbox -t main -i",
                file=sys.stderr,
            )
            sys.exit(1)
        from .ops.inbox import inbox_timeline
        result = inbox_timeline(
            track=track_filter,
            pending_only=pending_only,
            limit=limit,
            since=since,
        )
        if isinstance(result, dict) and "error" in result:
            print(result["error"], file=sys.stderr)
            sys.exit(1)
        if mode == OutputMode.JSON:
            print(json.dumps(result, indent=2))
        else:
            _render_timeline_human(result)
        return

    # ── standard pending-only list mode ─────────────────────────────────────
    if track_filter:
        track_dir = TRACKS_DIR / track_filter
        if not track_dir.exists():
            print(f"Track '{track_filter}' not found.", file=sys.stderr)
            sys.exit(1)
        names = [track_filter]
    else:
        names = _track_names()

    all_files: list[dict] = []
    for name in names:
        all_files.extend(_inbox_files_for_track(name))

    if not all_files:
        if mode == OutputMode.HUMAN:
            print("No unread inbox messages found.")
        else:
            print(json.dumps([], indent=2))
        return

    print_list(all_files, mode)


def cmd_inbox_consume(args) -> None:
    """Handle `reflect inbox consume TRACK [...]`.

    Validates mutually-exclusive selectors, runs interactive confirmation
    for bulk modes when stdin is a tty (or fails closed when it isn't),
    delegates to ops.consume_inbox, and renders human/json output.
    """
    from .ops.inbox import consume_inbox, ConsumeArgError

    mode = OutputMode(args.output)
    track = args.track
    file = getattr(args, "file", None)
    all_ = getattr(args, "all", False)
    before = getattr(args, "before", None)
    from_ = getattr(args, "from_", None)
    dry_run = getattr(args, "dry_run", False)
    yes = getattr(args, "yes", False)

    bulk = all_ or (before is not None) or (from_ is not None)

    # Bulk + not dry-run + not --yes → require interactive confirmation, or fail closed.
    if bulk and not dry_run and not yes:
        if not sys.stdin.isatty() or not sys.stderr.isatty():
            print(
                "error: bulk consume (--all / --before / --from) requires --yes "
                "when stdin/stderr is not a tty",
                file=sys.stderr,
            )
            sys.exit(1)
        # Compute preview first via dry_run.
        try:
            preview = consume_inbox(
                track=track,
                file=file,
                all=all_,
                before=before,
                from_=from_,
                dry_run=True,
            )
        except ConsumeArgError as e:
            print(f"error: {e}", file=sys.stderr)
            sys.exit(2)
        if isinstance(preview, dict) and "error" in preview:
            print(preview["error"], file=sys.stderr)
            sys.exit(1)
        names = preview.get("consumed", [])
        n = len(names)
        if n == 0:
            if mode == OutputMode.HUMAN:
                print(f"No matching messages in {track} inbox.")
            else:
                print(json.dumps({
                    "track": track, "consumed": [], "skipped": [], "dry_run": False,
                }, indent=2))
            return
        first = names[0]
        last = names[-1]
        print(
            f"Would consume {n} message(s) from {track} inbox "
            f"(first: {first}, last: {last}).",
            file=sys.stderr,
        )
        try:
            reply = input("Proceed? [y/N] ").strip().lower()
        except EOFError:
            reply = ""
        if reply not in ("y", "yes"):
            print("Aborted.", file=sys.stderr)
            sys.exit(1)

    try:
        result = consume_inbox(
            track=track,
            file=file,
            all=all_,
            before=before,
            from_=from_,
            dry_run=dry_run,
        )
    except ConsumeArgError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(2)

    if isinstance(result, dict) and "error" in result and "consumed" not in result:
        print(result["error"], file=sys.stderr)
        sys.exit(1)

    if mode == OutputMode.JSON:
        print(json.dumps(result, indent=2))
        return

    track_name = result["track"]
    consumed = result.get("consumed", [])
    skipped = result.get("skipped", [])
    dry = result.get("dry_run", False)
    verb = "would consume" if dry else "consumed"
    for name in consumed:
        marker = "·" if dry else "✓"
        print(f"{marker} {verb} {track_name}/inbox/{name}")
    if skipped:
        for s in skipped:
            print(f"⊘ skipped {track_name}/inbox/{s['filename']} ({s['reason']})")
    if dry:
        print(f"(dry-run) {len(consumed)} file(s) would be consumed from {track_name}")
    else:
        print(f"consumed {len(consumed)} file(s) from {track_name}")
