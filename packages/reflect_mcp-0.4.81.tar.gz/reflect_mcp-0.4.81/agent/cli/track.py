"""Track subcommands for the reflect CLI.

Thin adapter — all business logic lives in agent.cli.ops.track.
"""
from __future__ import annotations

import subprocess
import sys
import os
from pathlib import Path

from .output import OutputMode, print_list, print_record, print_table
from .ops.track import (
    list_tracks,
    get_track_state,
    enable_track,
    disable_track,
    create_track,
    create_from_template,
    create_from_family,
    send_to_track,
    interrupt_track,
    _template_uses_project,
    TEMPLATES,
)
# create_from_template and create_from_family are used by cmd_track_create routing.
# They are not exposed as separate CLI subcommands.


def cmd_track_list(args) -> None:
    mode = OutputMode(args.output)
    names = list_tracks()
    if not names:
        print("No tracks found.")
        return

    rows = []
    for name in names:
        s = get_track_state(name)
        if "error" in s:
            continue
        rows.append([
            s["name"],
            s["state"],
            s["last_wake_fmt"],
            s["unread_count"],
            s.get("backlog", "-"),
            s.get("next_wake_by_delta", "-"),
        ])

    print_table(["name", "state", "last_wake", "unread", "backlog", "next_wake"], rows, mode)


def cmd_track_status(args) -> None:
    mode = OutputMode(args.output)
    s = get_track_state(args.name)

    if "error" in s:
        print(s["error"], file=sys.stderr)
        sys.exit(1)

    record = {
        "name": s["name"],
        "state": s["state"],
        "last_wake": s["last_wake_fmt"],
        "last_wake_start": s["last_wake_start_fmt"],
        "unread_count": s["unread_count"],
        "lock_pid": s["lock_pid"] if s["lock_pid"] else "-",
        "pending_originator": s.get("pending_originator", "-"),
        "pending_followup": s.get("pending_followup", "-"),
        "backlog": s.get("backlog", "-"),
        "next_wake_by": (
            f"{s['next_wake_by_fmt']} - {s['next_wake_by_delta']}"
            if s.get('next_wake_by_fmt') not in (None, '-')
            else s.get('next_wake_by_delta', '-')
        ),
    }
    print_record(record, mode)

    # Recent inbox files (up to 5)
    from agent.cli.ops.root import resolve_project_root
    PROJECT_ROOT = resolve_project_root()
    TRACKS_DIR = PROJECT_ROOT / "agent" / "runtime" / "tracks"
    track_dir = TRACKS_DIR / args.name
    inbox_dir = track_dir / "inbox"
    consumed_dir = inbox_dir / ".consumed"
    if inbox_dir.exists():
        unread = sorted([p for p in inbox_dir.glob("*.md") if p.is_file()], reverse=True)
        consumed_names: set[str] = set()
        if consumed_dir.exists():
            consumed_names = set(p.name for p in consumed_dir.glob("*.md"))
        unread = [p for p in unread if p.name not in consumed_names][:5]

        if unread:
            if mode == OutputMode.HUMAN:
                print("\nRecent inbox (unread):")
                for p in unread:
                    print(f"  {p.name}")
            else:
                import json
                print(json.dumps({"recent_inbox": [p.name for p in unread]}, indent=2))

    # Last 3 wake IDs from wakes.tsv
    wakes_tsv = PROJECT_ROOT / "agent" / "runtime" / "wakes.tsv"
    if wakes_tsv.exists():
        try:
            lines = wakes_tsv.read_text().splitlines()
            wake_ids = [line.split("\t")[0] for line in lines[1:] if line]
            wake_ids = wake_ids[-3:]
            if wake_ids:
                if mode == OutputMode.HUMAN:
                    print("\nRecent wake IDs (global):")
                    for wid in wake_ids:
                        print(f"  {wid}")
                else:
                    import json
                    print(json.dumps({"recent_wake_ids": wake_ids}, indent=2))
        except OSError:
            pass


def _resolve_active_track(arg_track: str | None) -> str | None:
    """Resolve --track flag → active track → None.

    Active-track resolution rule (matches the wake runtime):
      1. Explicit --track wins.
      2. $REFLECT_TRACK env var if set.
      3. Return None → caller emits the FR2 "no track context" error.
    """
    if arg_track:
        return arg_track
    env = os.environ.get("REFLECT_TRACK", "").strip()
    if env:
        return env
    return None


def _format_status_value(v: str | None) -> str:
    return "null" if v is None else v


def cmd_track_status_set(args) -> None:
    """spec.reflect-track-status-cli FR2: set focus/plan/blocked.

    Routes through agent.runtime.track_status.set_status in-process.
    No subprocess (FR8). Exit codes per FR2: 0 ok, 2 argument, 3
    track_not_found, 4 write_error.
    """
    from agent.runtime.track_status import (
        set_status,
        _UNSET,
        TrackNotFoundError,
        InvalidStatusValueError,
    )

    track = _resolve_active_track(args.track)
    if not track:
        print("error: no track context; pass --track NAME", file=sys.stderr)
        sys.exit(2)

    # Only mark a field "present" when the flag actually appeared on argv.
    focus_present = getattr(args, "focus_present", False)
    plan_present = getattr(args, "plan_present", False)
    blocked_present = getattr(args, "blocked_present", False)

    if not (focus_present or plan_present or blocked_present):
        print(
            "error: at least one of --focus, --plan, --blocked must be "
            "provided (try `reflect track status get` to inspect)",
            file=sys.stderr,
        )
        sys.exit(2)

    kwargs: dict = {}
    if focus_present:
        kwargs["focus"] = args.focus if args.focus is not None else ""
    if plan_present:
        kwargs["plan"] = args.plan if args.plan is not None else ""
    if blocked_present:
        kwargs["blocked"] = args.blocked if args.blocked is not None else ""

    try:
        snap = set_status(track, **kwargs)
    except TrackNotFoundError as exc:
        print(f"error: track not found: {track}", file=sys.stderr)
        sys.exit(3)
    except InvalidStatusValueError as exc:
        print(f"error: validation: {exc}", file=sys.stderr)
        sys.exit(2)
    except OSError as exc:
        print(f"error: write failed: {exc}", file=sys.stderr)
        sys.exit(4)

    summary = (
        f"focus={_format_status_value(snap.get('focus'))} "
        f"plan={_format_status_value(snap.get('plan'))} "
        f"blocked={_format_status_value(snap.get('blocked_on'))}"
    )
    print(summary)


def cmd_track_status_get(args) -> None:
    """spec.reflect-track-status-cli FR5: read focus/plan/blocked_on.

    Prints a 6-line human-readable block. Exit codes: 0 ok, 3 not found,
    4 read error.
    """
    from agent.runtime.track_status import get_status, TrackNotFoundError

    track = _resolve_active_track(args.track)
    if not track:
        print("error: no track context; pass --track NAME", file=sys.stderr)
        sys.exit(2)

    try:
        snap = get_status(track)
    except TrackNotFoundError:
        print(f"error: track not found: {track}", file=sys.stderr)
        sys.exit(3)
    except OSError as exc:
        print(f"error: read failed: {exc}", file=sys.stderr)
        sys.exit(4)

    print(f"track:           {snap.get('track', track)}")
    print(f"schema_version:  {snap.get('schema_version', 3)}")
    print(f"state:           {_format_status_value(snap.get('state'))}")
    print(f"focus:           {_format_status_value(snap.get('focus'))}")
    print(f"plan:            {_format_status_value(snap.get('plan'))}")
    print(f"blocked_on:      {_format_status_value(snap.get('blocked_on'))}")


def cmd_track_tail(args) -> None:
    name = args.name
    log_path = f"/tmp/reflect-tick-{name}.log"
    follow = not getattr(args, "no_follow", False)

    # When following on an interactive TTY, prefer the TUI TailScreen — it
    # shows a hashed-color status bar identifying the track. Fall back to
    # bare `tail` when stdout isn't a TTY (pipes, redirects, --no-follow)
    # so existing scripts keep working.
    if follow and sys.stdout.isatty():
        if not os.path.exists(log_path):
            print(f"No log yet at {log_path}; waiting... (ctrl-c to exit)")
            import time
            while not os.path.exists(log_path):
                time.sleep(1)
        from textual.app import App, ComposeResult
        from textual.binding import Binding
        from .tui.dashboard_app import TailScreen

        class _SoloTailApp(App):
            BINDINGS = [Binding("q", "quit", "Quit", show=True)]

            def __init__(self, track: str) -> None:
                super().__init__()
                self._track = track

            def on_mount(self) -> None:
                self.push_screen(TailScreen(self._track))

        try:
            _SoloTailApp(name).run()
        except KeyboardInterrupt:
            pass
        return

    if not os.path.exists(log_path):
        print(f"No log found at {log_path}")
        return

    cmd = ["tail", "-n", "20", log_path]
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        pass


def cmd_track_logs(args) -> None:
    name = args.name
    log_path = f"/tmp/reflect-tick-{name}.log"

    if not os.path.exists(log_path):
        print(f"No log found at {log_path}")
        return

    try:
        with open(log_path) as f:
            print(f.read(), end="")
    except OSError as e:
        print(f"Error reading log: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_track_enable(args) -> None:
    result = enable_track(args.name)
    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)
    print(result["message"])


def cmd_track_disable(args) -> None:
    result = disable_track(args.name)
    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)
    print(result["message"])


def cmd_track_create(args) -> None:
    """Unified track create handler — routes to appropriate ops based on flags.

    Modes:
    - --from-template-family               → bulk create (scope determines project/global)
    - --template + --project               → single auditor track (create_from_template)
    - --template only                      → generic track (create_track)
    """
    from_template_family = getattr(args, "from_template_family", None)
    projects_str = getattr(args, "projects", None)
    project = getattr(args, "project", None)
    cadence_seconds = getattr(args, "cadence_seconds", None)
    filter_val = getattr(args, "filter", None)
    template_key = getattr(args, "template", None) or "blank"

    # Mutual exclusion: --template and --from-template-family are incompatible
    if from_template_family and template_key != "blank":
        print("Error: --template and --from-template-family are mutually exclusive.", file=sys.stderr)
        sys.exit(1)

    if from_template_family:
        # Bulk mode: let create_from_family enforce scope requirements
        project_list = [p.strip() for p in projects_str.split(",") if p.strip()] if projects_str else None
        result = create_from_family(
            family=from_template_family,
            projects=project_list,
            cadence_seconds=cadence_seconds,
            filter_override=filter_val,
        )
        if result["created"]:
            for entry in result["created"]:
                print(f"  Created: {entry['track_name']} → {entry['track_dir']}")
        if result["failed"]:
            for entry in result["failed"]:
                project_id = entry.get("project", "?")
                template_id = entry.get("template", "?")
                print(f"  Failed ({project_id}/{template_id}): {entry['message']}", file=sys.stderr)
        if not result["ok"]:
            sys.exit(1)

    elif project:
        # --project provided: validate that template actually uses {project}
        tmpl_str = TEMPLATES.get(template_key, "")
        if not _template_uses_project(tmpl_str):
            print(
                f"Error: --project='{project}' passed but template '{template_key}' does not use {{project}}. "
                f"Use a project-scoped template (e.g. smoke-test-auditor) or omit --project.",
                file=sys.stderr,
            )
            sys.exit(1)
        # Single auditor template mode: --template + --project
        result = create_from_template(
            template=template_key,
            project=project,
            cadence_seconds=cadence_seconds,
            filter_override=filter_val,
            name=args.name,
        )
        if not result["ok"]:
            print(result["message"], file=sys.stderr)
            sys.exit(1)
        print(result["message"])
        print(f"  Track dir: {result['track_dir']}")

    else:
        # Basic mode: generic template (blank, security-audit, etc.)
        extra_vars: dict = {}
        if cadence_seconds is not None:
            extra_vars["cadence_seconds"] = cadence_seconds
        if filter_val is not None:
            extra_vars["filter"] = filter_val
        result = create_track(args.name, template=template_key, **extra_vars)
        if not result["ok"]:
            print(result["message"], file=sys.stderr)
            sys.exit(1)
        print(result["message"])
        print(f"  Edit {result['track_dir']}/wake.md to define this track's identity.")


def cmd_track_send(args) -> None:
    """Drop a message into a track's inbox (soft delivery — next-wake)."""
    mode = OutputMode(args.output)
    result = send_to_track(
        args.name,
        args.message,
        sender=getattr(args, "sender", None) or "originator",
        kind=getattr(args, "kind", None) or "report",
        subject=getattr(args, "subject", None),
    )

    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        # Render structured violations when present (spec §7.1).
        for v in (result.get("violations") or []):
            field = f" [{v['field']}]" if v.get("field") else ""
            print(f"  ✗ {v['code']}{field}: {v['message']}", file=sys.stderr)
        sys.exit(1)

    if mode == OutputMode.HUMAN:
        print(result["message"])
        if result.get("inbox_path"):
            print(f"  → {result['inbox_path']}")
        for w in (result.get("warnings") or []):
            field = f" [{w['field']}]" if w.get("field") else ""
            print(f"  ⚠ {w['code']}{field}: {w['message']}")
    else:
        import json
        print(json.dumps(result, indent=2))


def cmd_track_interrupt(args) -> None:
    """Inject a message into a running track's wake via interrupt socket.

    If the track is sleeping (no socket), degrades gracefully to inbox-drop.
    """
    mode = OutputMode(args.output)
    result = interrupt_track(args.name, args.message)

    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)

    if mode == OutputMode.HUMAN:
        print(result["message"])
        if result.get("inbox_path"):
            print(f"  → {result['inbox_path']}")
    else:
        import json
        print(json.dumps(result, indent=2))


def cmd_track_session(args) -> None:
    """Launch the interactive session TUI for a track."""
    from .tui.session_view import SessionApp

    replay = getattr(args, "replay", 20)
    try:
        SessionApp(track_name=args.name, replay_last=replay).run(mouse=False)
    except KeyboardInterrupt:
        pass
