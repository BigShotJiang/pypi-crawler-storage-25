"""Reflect management MCP server.

Exposes reflect's management surface as MCP tools so any top-level Claude
session can drive reflect operations without CLI knowledge.

Entity-action pattern: 7 tools, ~20 actions total. Well within agent tool
budget limits.

Tools:
  track        — list, status, send, logs
  track_admin  — create, enable, disable, interrupt
  project      — list, link, unlink
  wake         — status, history, start, stop
  inbox        — list, peek, timeline
  doctor       — (no action; runs all checks)
  cost         — summary (flat or by-track, optional since filter)

Usage:
  uv run reflect-manage          # starts stdio MCP server
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

# ── Project-root bootstrap (must run before ops module imports) ──────────────
# Ops modules call resolve_project_root() at *module level*, which locks in
# TRACKS_DIR at import time based on the cwd when the MCP server started.
# If Claude Code is open in a different project, cwd walk-up finds that
# project's root, not reflection's — so all tool calls resolve to the wrong
# tree and return empty output.
#
# Fix: derive the project root from this file's installed location and set
# REFLECT_PROJECT before ops modules are imported. resolve_project_root()
# checks REFLECT_PROJECT first (step 1), so the cwd walk-up (step 2) is
# bypassed. Only overrides if REFLECT_PROJECT isn't already set explicitly.
if not os.environ.get("REFLECT_PROJECT"):
    _derived = Path(__file__).resolve().parents[2]
    if (_derived / "agent" / "runtime" / "tracks").is_dir() or (
        (_derived / "agent").is_dir() and (_derived / "AGENT.md").is_file()
    ):
        os.environ["REFLECT_PROJECT"] = str(_derived)

from agent.cli.ops.track import (
    list_tracks,
    get_track_state,
    send_to_track,
    interrupt_track,
    create_track,
    enable_track,
    disable_track,
    get_track_logs,
)
from agent.cli.ops.project import list_projects, link_project, unlink_project
from agent.cli.ops.followup import (
    block_followup,
    unblock_followup,
    list_followups,
)
from agent.cli.ops.inbox import (
    list_inbox,
    peek_inbox,
    inbox_timeline,
    consume_inbox,
    ConsumeArgError,
)
from agent.cli.ops.wake import list_running_wakes, get_wake_history, start_wake, stop_wake, pause_wake, resume_wake, await_wake, start_wake_await
from agent.cli.ops.doctor import run_checks, run_doctor_structured
from agent.cli.ops.cost import get_cost_summary
from agent.cli.ops.docs import list_docs, read_doc
from agent.cli.ops.report import gather_report, parse_kinds
from agent.cli.ops.schedule import list_schedules, show_schedule, next_schedules

# ── Server instance ─────────────────────────────────────────────────────────

server = Server("reflect")


# ── Tool definitions ─────────────────────────────────────────────────────────


TOOLS: list[Tool] = [
    Tool(
        name="track",
        description=(
            "Inspect or message a reflection track. "
            "action=list: list all tracks and their state. "
            "action=status: get OR set the focus/plan/blocked_on fields for a track "
            "(requires track). With no focus/plan/blocked args present → get (returns "
            "snapshot). With any of focus/plan/blocked present → set (spec FR3). "
            "Empty string clears a field; null clears; omit leaves unchanged (FR4). "
            "Response shape uses on-disk field name 'blocked_on' even though the input "
            "arg is 'blocked'. action=send: drop a message into a track's inbox "
            "(requires track + message; optional subject + sender + kind). The send-time "
            "strict validator (spec.inbox-protocol~0171a19a §7.1) runs before write; on any "
            "blocking violation the file is NOT written and the response carries a "
            "violations list. kind defaults to 'report'; valid v1 enum: report | request | "
            "deploy-request | btw | broadcast | followup | decision. If subject is omitted, "
            "it is derived from the first heading or non-empty line of message. "
            "action=logs: read the dispatcher tick log for a track "
            "from /tmp/reflect-tick-{name}.log (requires track). "
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["list", "status", "send", "logs"]},
                "track": {"type": "string", "description": "Track name (required for status, send, logs)"},
                "message": {"type": "string", "description": "Message text (required for send)"},
                "subject": {
                    "type": "string",
                    "description": "send action: required v1-spec subject field (≤120 graphemes). If omitted the producer derives one from the first heading or non-empty line of message.",
                },
                "sender": {
                    "type": "string",
                    "description": "send action: 'from' field in frontmatter (default 'originator').",
                },
                "kind": {
                    "type": "string",
                    "enum": ["report", "request", "deploy-request", "btw", "broadcast", "followup", "decision"],
                    "description": "send action: v1 inbox-protocol kind enum (default 'report').",
                },
                "focus": {
                    "type": ["string", "null"],
                    "description": "status action: set focus field (string sets, '' or null clears, omit leaves unchanged)",
                },
                "plan": {
                    "type": ["string", "null"],
                    "description": "status action: set plan field (string sets, '' or null clears, omit leaves unchanged)",
                },
                "blocked": {
                    "type": ["string", "null"],
                    "description": "status action: set blocked_on field (string sets, '' or null clears, omit leaves unchanged); on-disk field is 'blocked_on'",
                },
            },
        },
    ),
    Tool(
        name="track_admin",
        description=(
            "Manage track lifecycle and control-plane operations. "
            "action=create: create a new track (requires track; optional template=blank|security-audit|code-review). "
            "action=enable: enable a disabled track (requires track). "
            "action=disable: disable a running/idle track (requires track). "
            "action=interrupt: inject a message into a running track (requires track + message). "
            "State-aware: running→socket delivery; idle→inbox-drop + immediate wake fired; "
            "wedged→inbox-drop, wake NOT fired; disabled→inbox-drop, wake NOT fired. "
            "Response includes: delivered ('socket'|'inbox'), track_state, wake_fired (bool), wake_pid. "
            "Privileged ops are split here for permission granularity."
        ),
        inputSchema={
            "type": "object",
            "required": ["action", "track"],
            "properties": {
                "action": {"type": "string", "enum": ["create", "enable", "disable", "interrupt"]},
                "track": {"type": "string", "description": "Track name"},
                "message": {"type": "string", "description": "Message text (required for interrupt)"},
                "template": {
                    "type": "string",
                    "enum": ["blank", "security-audit", "code-review"],
                    "description": "Track template (create only, default=blank)",
                },
            },
        },
    ),
    Tool(
        name="project",
        description=(
            "Manage linked projects for multi-project orchestration. "
            "action=list: list all linked projects. "
            "action=link: link a project directory (requires path). "
            "action=unlink: unlink a project by name (requires name)."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["list", "link", "unlink"]},
                "path": {"type": "string", "description": "Absolute path to project dir (link only)"},
                "name": {"type": "string", "description": "Project name (unlink only)"},
            },
        },
    ),
    Tool(
        name="wake",
        description=(
            "Inspect or control wake activity. "
            "action=status: list currently running wakes across all tracks. "
            "action=history: recent wake history (optional: track filter, limit). "
            "action=start: fire a wake for a track (requires track; returns {ok, pid, message}). "
            "action=stop: request graceful stop of a running wake (requires track; touches stop.requested flag). "
            "action=pause: pause a running wake cooperatively (requires track; wake enters a 1s poll-loop at the "
            "next checkpoint; LLM context is preserved; process stays alive). "
            "action=resume: resume a paused wake (requires track; clears pause.requested; wake continues within 1s). "
            "Paused wakes show state='paused' in track status and can be resumed cheaply without re-reading context. "
            "action=await: BLOCKING — block until the current wake for a track completes (requires track). "
            "Returns {state, track, wake_id, report_path, duration_secs} where state is "
            "'idle'|'wedged'|'crashed'|'no-wake-running'. "
            "If no wake is running, returns immediately with state='no-wake-running'. "
            "Set next=true to await the *next* wake instead of the current one. "
            "Use timeout_secs to cap the wait (returns state='wedged' on expiry). "
            "WARNING: this call blocks the MCP connection for the full wait duration — "
            "only use for short waits (<30s). For longer waits, use the CLI form with "
            "Bash(run_in_background=True, command='reflect wake await <track> --timeout N')."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["status", "history", "start", "stop", "pause", "resume", "await"]},
                "track": {"type": "string", "description": "Track name (required for start, stop, pause, resume, await; filter for history)"},
                "limit": {"type": "integer", "description": "Max rows to return (history only, default=20)"},
                "timeout_secs": {"type": "integer", "description": "await only: max seconds to block; returns state=wedged on expiry"},
                "next": {"type": "boolean", "description": "await only: wait for the NEXT wake to start and finish (not the current one)"},
            },
        },
    ),
    Tool(
        name="cost",
        description=(
            "Show spend summary across wakes. "
            "Returns aggregate total, wake count, and average api_equivalent_usd. "
            "Optional by_track=true to break down per track. "
            "Optional since=ISO timestamp or unix float to restrict to wakes after that time."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "by_track": {"type": "boolean", "description": "Group results by track (default false)"},
                "since": {"type": "string", "description": "ISO timestamp or unix float; filter to wakes started after this time"},
            },
        },
    ),
    Tool(
        name="inbox",
        description=(
            "Inspect and drain track inboxes. "
            "action=list: list unread messages (optional: track filter). "
            "action=peek: read contents of a specific inbox file (requires track + filename). "
            "action=timeline: unified time-ordered view of pending + consumed + agent surfaces for a track (requires track). "
            "  Optional: pending_only=true to omit consumed, limit=N (default 50), since=ISO timestamp. "
            "action=consume: move pending messages into TRACK/inbox/.consumed/ and emit inbox.consumed events with source='manual'. "
            "  Requires track + exactly one selector: file=FILENAME | all=true | before=ISO | from_=SENDER. "
            "  Optional: dry_run=true to preview without moving. MCP has no confirmation channel — bulk is implicit-yes."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["list", "peek", "timeline", "consume"]},
                "track": {"type": "string", "description": "Track name (filter for list; required for peek, timeline, consume)"},
                "filename": {"type": "string", "description": "Filename to read (peek only)"},
                "pending_only": {"type": "boolean", "description": "timeline only: omit consumed messages (default false)"},
                "limit": {"type": "integer", "description": "timeline only: max entries to return (default 50)"},
                "since": {"type": "string", "description": "timeline only: ISO timestamp; only include entries at or after this time"},
                "file": {"type": "string", "description": "consume only: name of one .md file in TRACK/inbox/ to consume"},
                "all": {"type": "boolean", "description": "consume only: consume every pending .md in TRACK/inbox/"},
                "before": {"type": "string", "description": "consume only: consume every pending .md whose at: < ISO timestamp"},
                "from_": {"type": "string", "description": "consume only: consume every pending .md whose from: equals SENDER"},
                "dry_run": {"type": "boolean", "description": "consume only: preview without moving (default false)"},
            },
        },
    ),
    Tool(
        name="followup",
        description=(
            "Manage followup state — block, unblock, or list. "
            "Implements the writer side of the blocked-followup escape "
            "hatch (design.blocked-followup-state~2efaa40e). "
            "action=block: mv TRACK/followup/NAME → TRACK/followup/"
            "blocked-on-trigger/NAME. Idempotent (no-op if already "
            "blocked). "
            "action=unblock: mv TRACK/followup/blocked-on-trigger/NAME "
            "→ TRACK/followup/NAME. Idempotent (no-op if already "
            "active). "
            "action=list: enumerate active and blocked followups for a "
            "track. "
            "Default track resolution: 'track' arg, then $REFLECT_TRACK "
            "env. block/unblock require 'name'."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["block", "unblock", "list"]},
                "track": {"type": "string", "description": "Target track (default: $REFLECT_TRACK)"},
                "name": {"type": "string", "description": "Followup filename (required for block/unblock)"},
            },
        },
    ),
    Tool(
        name="schedule",
        description=(
            "Inspect scheduled-task definitions across tracks. Read-only "
            "Phase 1 surface over agent/runtime/tracks/<track>/schedule/"
            "<id>.yaml files. "
            "action=list: enumerate all schedules (optionally filter to one "
            "track via 'track'). Returns {schedules, "
            "tracks_without_schedule, tracks_scanned}. "
            "action=show: detail a single schedule. Requires 'track'; 'id' "
            "is optional when the track has exactly one schedule. Returns "
            "{schedule: {...}}. "
            "action=next: top-N schedules sorted by next-fire ascending. "
            "Optional 'track' and 'limit' (default 5). "
            "Computed fields per record: cron / interval, last_fired_at, "
            "next_fire, time_since_last_fire, time_until_next_fire, "
            "recipient, description, enabled."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["list", "show", "next"]},
                "track": {"type": "string", "description": "Filter to a single track (optional for list/next; required for show)"},
                "id": {"type": "string", "description": "Schedule id (optional for show when track has one schedule)"},
                "limit": {"type": "integer", "description": "next only: number of upcoming fires (default 5)"},
            },
        },
    ),
    Tool(
        name="docs",
        description=(
            "Read reflect documentation. "
            "action=list: list all available doc topics. "
            "action=read: read a specific doc by topic (requires topic). "
            "Topics are relative paths without .md extension (e.g. 'state', 'tracks', 'primitives/state')."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["read", "list"]},
                "topic": {"type": "string", "description": "Doc topic (required for action=read; e.g. 'state', 'tracks', 'primitives/state')"},
            },
        },
    ),
    Tool(
        name="report",
        description=(
            "Context concatenator for agents. Aggregates track artifacts and state into a "
            "single concatenated output. Replaces multi-step Bash loops with a one-shot call.\n"
            "action=read: gather and return the concatenated report.\n"
            "tracks: list[str] | str | None — track name(s) or glob patterns (None = all). "
            "Accepts list or comma-separated string.\n"
            "kinds: dict[str, int] | None — {kind: per_kind_limit} (None = all kinds). "
            "Recognised kinds: inbox, reports, followup, completed. Value 0 skips a kind.\n"
            "limit: default per-kind limit when not overridden per-kind (default 3).\n"
            "offset: skip N most recent before applying limit (default 0).\n"
            "since / until: ISO8601 or keyword (today, yesterday, now) — date-range filter.\n"
            "include_state: 'core' (default) | 'all' | 'none' — state file inclusion per track."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["read"], "description": "Operation (currently only 'read')"},
                "tracks": {
                    "description": "Track name(s) or glob patterns. list[str] or comma-separated str. None = all.",
                    "oneOf": [
                        {"type": "array", "items": {"type": "string"}},
                        {"type": "string"},
                        {"type": "null"},
                    ],
                },
                "kinds": {
                    "type": "object",
                    "description": "Per-kind limits: {kind: N}. N=0 skips the kind. null = all kinds.",
                    "additionalProperties": {"type": "integer"},
                    "nullable": True,
                },
                "limit": {"type": "integer", "description": "Default per-kind limit (default 3)"},
                "offset": {"type": "integer", "description": "Skip N most recent (default 0)"},
                "since": {"type": "string", "description": "ISO8601 or keyword (today, yesterday, now)"},
                "until": {"type": "string", "description": "ISO8601 or keyword (today, yesterday, now)"},
                "include_state": {
                    "type": "string",
                    "enum": ["core", "all", "none"],
                    "description": "State file inclusion (default: core)",
                },
            },
        },
    ),
    Tool(
        name="doctor",
        description=(
            "Run health checks against the reflect runtime. "
            "Returns a list of check results with status=PASS|WARN|ERROR and a message. "
            "No parameters required."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="reflect_doctor",
        description=(
            "Run health checks and return a structured JSON payload (FR19/DR20). "
            "Returns: {status, contract_version, per_track_health[], wedge_file_path, suggested_actions[]}. "
            "status is 'clean' | 'warnings' | 'wedged'. "
            "per_track_health is a list of {track, status, violations}. "
            "No parameters required."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
]


# ── Tool handlers ─────────────────────────────────────────────────────────────


def _text(data: Any) -> list[TextContent]:
    """Serialize data to a single TextContent JSON block."""
    return [TextContent(type="text", text=json.dumps(data, indent=2))]


@server.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    action = arguments.get("action", "")

    # ── track ────────────────────────────────────────────────────────
    if name == "track":
        if action == "list":
            names = list_tracks()
            rows = []
            for n in names:
                s = get_track_state(n)
                if "error" not in s:
                    rows.append({
                        "name": s["name"],
                        "state": s["state"],
                        "last_wake": s["last_wake_fmt"],
                        "unread_count": s["unread_count"],
                    })
            return _text(rows)

        elif action == "status":
            # spec.reflect-track-status-cli FR3/FR5/FR8: in-process delegation
            # to agent.runtime.track_status. With no field args → get;
            # with at least one of focus/plan/blocked present → set.
            track = arguments.get("track")
            if not track:
                return _text({
                    "ok": False,
                    "error": "argument",
                    "message": "track required for status",
                })
            from agent.runtime.track_status import (
                set_status,
                get_status,
                _UNSET,
                TrackNotFoundError,
                InvalidStatusValueError,
            )

            focus_present = "focus" in arguments
            plan_present = "plan" in arguments
            blocked_present = "blocked" in arguments
            any_set = focus_present or plan_present or blocked_present

            try:
                if any_set:
                    kwargs: dict = {}
                    if focus_present:
                        kwargs["focus"] = arguments["focus"]
                    if plan_present:
                        kwargs["plan"] = arguments["plan"]
                    if blocked_present:
                        kwargs["blocked"] = arguments["blocked"]
                    snap = set_status(track, **kwargs)
                else:
                    snap = get_status(track)
            except TrackNotFoundError as exc:
                return _text({
                    "ok": False,
                    "error": "track_not_found",
                    "message": str(exc),
                })
            except InvalidStatusValueError as exc:
                return _text({
                    "ok": False,
                    "error": "validation_error",
                    "message": str(exc),
                })
            except OSError as exc:
                return _text({
                    "ok": False,
                    "error": "write_error",
                    "message": str(exc),
                })

            return _text({
                "ok": True,
                "track": snap.get("track", track),
                "focus": snap.get("focus"),
                "plan": snap.get("plan"),
                "blocked_on": snap.get("blocked_on"),
                "schema_version": snap.get("schema_version", 3),
            })

        elif action == "send":
            track = arguments.get("track")
            message = arguments.get("message")
            if not track or not message:
                return _text({"error": "track and message required for send"})
            subject = arguments.get("subject")
            sender = arguments.get("sender", "originator")
            kind = arguments.get("kind", "report")
            return _text(send_to_track(
                track,
                message,
                sender=sender,
                kind=kind,
                subject=subject,
            ))

        elif action == "logs":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for logs"})
            return _text(get_track_logs(track))

        return _text({"error": f"unknown action: {action}"})

    # ── track_admin ──────────────────────────────────────────────────
    elif name == "track_admin":
        track = arguments.get("track")
        if not track:
            return _text({"error": "track required"})

        if action == "create":
            template = arguments.get("template", "blank")
            return _text(create_track(track, template=template))

        elif action == "enable":
            return _text(enable_track(track))

        elif action == "disable":
            return _text(disable_track(track))

        elif action == "interrupt":
            message = arguments.get("message")
            if not message:
                return _text({"error": "message required for interrupt"})
            return _text(interrupt_track(track, message))

        return _text({"error": f"unknown action: {action}"})

    # ── project ──────────────────────────────────────────────────────
    elif name == "project":
        if action == "list":
            return _text(list_projects())

        elif action == "link":
            path = arguments.get("path")
            if not path:
                return _text({"error": "path required for link"})
            return _text(link_project(path))

        elif action == "unlink":
            proj_name = arguments.get("name")
            if not proj_name:
                return _text({"error": "name required for unlink"})
            return _text(unlink_project(proj_name))

        return _text({"error": f"unknown action: {action}"})

    # ── wake ─────────────────────────────────────────────────────────
    elif name == "wake":
        if action == "status":
            return _text(list_running_wakes())

        elif action == "history":
            track = arguments.get("track")
            limit = int(arguments.get("limit", 20))
            return _text(get_wake_history(track=track, limit=limit))

        elif action == "start":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for start"})
            return _text(start_wake(track))

        elif action == "stop":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for stop"})
            return _text(stop_wake(track))

        elif action == "pause":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for pause"})
            return _text(pause_wake(track))

        elif action == "resume":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for resume"})
            return _text(resume_wake(track))

        elif action == "await":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for await"})
            timeout_secs = arguments.get("timeout_secs")
            if timeout_secs is not None:
                timeout_secs = int(timeout_secs)
            next_wake = bool(arguments.get("next", False))
            return _text(await_wake(track, timeout_secs=timeout_secs, next_wake=next_wake))

        return _text({"error": f"unknown action: {action}"})

    # ── inbox ────────────────────────────────────────────────────────
    elif name == "inbox":
        if action == "list":
            track = arguments.get("track")
            return _text(list_inbox(track=track))

        elif action == "peek":
            track = arguments.get("track")
            filename = arguments.get("filename")
            if not track or not filename:
                return _text({"error": "track and filename required for peek"})
            return _text(peek_inbox(track, filename))

        elif action == "timeline":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for timeline"})
            pending_only = bool(arguments.get("pending_only", False))
            limit = int(arguments.get("limit", 50))
            since = arguments.get("since")
            return _text(inbox_timeline(track=track, pending_only=pending_only, limit=limit, since=since))

        elif action == "consume":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for consume"})
            try:
                return _text(consume_inbox(
                    track=track,
                    file=arguments.get("file"),
                    all=bool(arguments.get("all", False)),
                    before=arguments.get("before"),
                    from_=arguments.get("from_"),
                    dry_run=bool(arguments.get("dry_run", False)),
                ))
            except ConsumeArgError as e:
                return _text({"error": str(e)})

        return _text({"error": f"unknown action: {action}"})

    # ── followup ─────────────────────────────────────────────────────
    elif name == "followup":
        track = arguments.get("track")
        if action == "block":
            fname = arguments.get("name")
            if not fname:
                return _text({"ok": False, "error": "argument", "message": "name required for block"})
            return _text(block_followup(fname, track=track))

        elif action == "unblock":
            fname = arguments.get("name")
            if not fname:
                return _text({"ok": False, "error": "argument", "message": "name required for unblock"})
            return _text(unblock_followup(fname, track=track))

        elif action == "list":
            return _text(list_followups(track=track))

        return _text({"ok": False, "error": "argument", "message": f"unknown action: {action}"})

    # ── schedule ─────────────────────────────────────────────────────
    elif name == "schedule":
        track = arguments.get("track")
        if action == "list":
            return _text(list_schedules(track=track))
        elif action == "show":
            if not track:
                return _text({"error": "track required for action=show"})
            return _text(show_schedule(track, arguments.get("id")))
        elif action == "next":
            limit = int(arguments.get("limit", 5) or 5)
            return _text(next_schedules(track=track, limit=limit))
        return _text({"error": f"unknown action: {action}"})

    # ── docs ─────────────────────────────────────────────────────────
    elif name == "docs":
        if action == "list":
            return _text({"available": list_docs()})

        elif action == "read":
            topic = arguments.get("topic")
            if not topic:
                return _text({"error": "topic required for action=read", "available": list_docs()})
            return _text(read_doc(topic))

        return _text({"error": f"unknown action: {action}"})

    # ── report ───────────────────────────────────────────────────────
    elif name == "report":
        if action != "read":
            return _text({"error": f"unknown action: {action}"})

        # Parse tracks — accept list, comma-separated str, or None.
        raw_tracks = arguments.get("tracks")
        if raw_tracks is None:
            tracks_list = None
        elif isinstance(raw_tracks, list):
            tracks_list = raw_tracks
        else:
            tracks_list = [t.strip() for t in str(raw_tracks).split(",") if t.strip()]

        # kinds comes in as dict or None.
        kinds_raw = arguments.get("kinds")
        if kinds_raw is not None:
            kinds_dict = {k: int(v) for k, v in kinds_raw.items()}
        else:
            kinds_dict = None

        limit = int(arguments.get("limit", 3))
        offset = int(arguments.get("offset", 0))
        since = arguments.get("since")
        until = arguments.get("until")
        include_state = arguments.get("include_state", "core") or "core"

        result = gather_report(
            tracks=tracks_list,
            kinds=kinds_dict,
            limit=limit,
            offset=offset,
            since=since,
            until=until,
            include_state=include_state,
        )
        return [TextContent(type="text", text=result)]

    # ── doctor ───────────────────────────────────────────────────────
    elif name == "doctor":
        return _text(run_checks())

    # ── reflect_doctor (structured payload, FR19/DR20) ───────────────
    elif name == "reflect_doctor":
        return _text(run_doctor_structured())

    # ── cost ─────────────────────────────────────────────────────────
    elif name == "cost":
        by_track = bool(arguments.get("by_track", False))
        since = arguments.get("since")
        try:
            return _text(get_cost_summary(by_track=by_track, since=since))
        except ValueError as exc:
            return _text({"error": str(exc)})

    return _text({"error": f"unknown tool: {name}"})


# ── Entry point ───────────────────────────────────────────────────────────────


def main() -> None:
    """Run the reflect management MCP server over stdio."""
    async def _run():
        async with stdio_server() as (read_stream, write_stream):
            init_options = server.create_initialization_options()
            await server.run(read_stream, write_stream, init_options)

    asyncio.run(_run())


if __name__ == "__main__":
    main()
