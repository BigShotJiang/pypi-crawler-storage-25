from __future__ import annotations

from typing import Any

import httpx


class BreezeBlueError(Exception):
    """Base class for Breeze Blue SDK errors."""


class APIError(BreezeBlueError):
    def __init__(
        self,
        *,
        message: str,
        status_code: int | None = None,
        code: str | None = None,
        detail: str | None = None,
        meta: dict[str, Any] | None = None,
        response: httpx.Response | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.detail = detail
        self.meta = meta
        self.response = response


class BadRequestError(APIError):
    pass


class ValidationError(APIError):
    pass


class RateLimitError(APIError):
    @property
    def retry_after(self) -> int | None:
        if self.response is None:
            return None
        raw_value = self.response.headers.get("retry-after")
        if raw_value is None:
            return None
        try:
            return int(raw_value)
        except ValueError:
            return None


class GenerationNotReadyError(APIError):
    @property
    def retry_after(self) -> int | None:
        if self.response is None:
            return None
        raw_value = self.response.headers.get("retry-after")
        if raw_value is None:
            return None
        try:
            return int(raw_value)
        except ValueError:
            return None


class AuthenticationError(APIError):
    pass


class ForbiddenError(APIError):
    pass


class NotFoundError(APIError):
    pass


class ConflictError(APIError):
    pass


class BillingInsufficientCreditsError(APIError):
    pass


class UpstreamError(APIError):
    pass


class ServiceUnavailableError(APIError):
    pass


_CODE_ERROR_MAP: dict[str, type[APIError]] = {
    "BAD_REQUEST": BadRequestError,
    "VALIDATION_ERROR": ValidationError,
    "AUTH_REQUIRED": AuthenticationError,
    "AUTH_INVALID_SESSION": AuthenticationError,
    "AUTH_SESSION_EXPIRED": AuthenticationError,
    "AUTH_USER_UNAVAILABLE": AuthenticationError,
    "AUTH_CONFIG_MISSING": AuthenticationError,
    "FORBIDDEN": ForbiddenError,
    "RESOURCE_NOT_FOUND": NotFoundError,
    "CONFLICT": ConflictError,
    "RATE_LIMITED": RateLimitError,
    "GENERATION_CONCURRENCY_EXCEEDED": RateLimitError,
    "GENERATION_NOT_READY": GenerationNotReadyError,
    "BILLING_INSUFFICIENT_CREDITS": BillingInsufficientCreditsError,
    "UPSTREAM_BILLING_ERROR": UpstreamError,
    "UPSTREAM_GENERATION_ERROR": UpstreamError,
    "UPSTREAM_TIMEOUT": UpstreamError,
    "UPSTREAM_GENERATION_SERVICE_ERROR": UpstreamError,
    "UPSTREAM_ASSET_STORAGE_ERROR": UpstreamError,
    "GENERATION_INVALID_RESPONSE": UpstreamError,
    "GENERATION_FAILED": UpstreamError,
    "VOICE_DESIGN_FAILED": UpstreamError,
    "VOICE_CLONE_FAILED": UpstreamError,
    "GENERATION_CAPACITY_EXCEEDED": ServiceUnavailableError,
    "LLM_CONFIG_NOT_FOUND": ServiceUnavailableError,
}

_STATUS_ERROR_MAP: dict[int, type[APIError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    402: BillingInsufficientCreditsError,
    403: ForbiddenError,
    404: NotFoundError,
    409: ConflictError,
    425: GenerationNotReadyError,
    422: ValidationError,
    429: RateLimitError,
    502: UpstreamError,
    503: ServiceUnavailableError,
    504: UpstreamError,
}


def raise_for_response(response: httpx.Response) -> None:
    if response.status_code < 400:
        return

    payload: dict[str, Any] = {}
    try:
        raw_payload = response.json()
    except ValueError:
        raw_payload = None
    if isinstance(raw_payload, dict):
        payload = raw_payload

    code = payload.get("code")
    detail = payload.get("detail") or payload.get("error")
    meta = payload.get("meta") if isinstance(payload.get("meta"), dict) else None
    message = str(detail or response.text or f"HTTP {response.status_code}")
    error_type = _CODE_ERROR_MAP.get(str(code), _STATUS_ERROR_MAP.get(response.status_code, APIError))
    raise error_type(
        message=message,
        status_code=response.status_code,
        code=str(code) if code else None,
        detail=str(detail) if detail else None,
        meta=meta,
        response=response,
    )
