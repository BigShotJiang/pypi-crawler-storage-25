from __future__ import annotations

import os
from importlib.metadata import PackageNotFoundError, version
from typing import Any

import httpx

from ._audio import AudioResponse
from ._errors import raise_for_response
from ._resources import AccountResource, GenerationJobsResource, HistoryResource, ModelsResource, TextToSpeechResource, VoicesResource


DEFAULT_BASE_URL = "https://api.breeze.blue"
try:
    SDK_VERSION = version("breeze-blue")
except PackageNotFoundError:
    SDK_VERSION = "0.0.0"


class BreezeBlue:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | httpx.Timeout = 60.0,
        http_client: httpx.Client | None = None,
    ) -> None:
        self.api_key = api_key if api_key is not None else os.getenv("BREEZE_API_KEY")
        resolved_base_url = base_url or os.getenv("BREEZE_BASE_URL") or DEFAULT_BASE_URL
        self.base_url = resolved_base_url.rstrip("/")
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(timeout=timeout)

        self.text_to_speech = TextToSpeechResource(self)
        self.generation_jobs = GenerationJobsResource(self)
        self.voices = VoicesResource(self)
        self.history = HistoryResource(self)
        self.models = ModelsResource(self)
        self.account = AccountResource(self)

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> BreezeBlue:
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | list[tuple[str, Any]] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> httpx.Response:
        request_kwargs: dict[str, Any] = {
            "params": _drop_none(params),
            "json": json,
            "data": _drop_none(data),
            "files": files,
            "headers": self._headers(),
        }
        if timeout is not None:
            request_kwargs["timeout"] = timeout
        response = self._client.request(method, self._url(path), **request_kwargs)
        raise_for_response(response)
        return response

    def json_request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | list[tuple[str, Any]] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Any:
        response = self.request(method, path, params=params, json=json, data=data, files=files, timeout=timeout)
        if not response.content:
            return None
        return response.json()

    def audio_request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AudioResponse:
        response = self.request(method, path, params=params, json=json, timeout=timeout)
        return AudioResponse(
            content=response.content,
            content_type=response.headers.get("content-type"),
            history_item_id=response.headers.get("history-item-id"),
        )

    def _url(self, path: str) -> str:
        normalized = path if path.startswith("/") else f"/{path}"
        return f"{self.base_url}{normalized}"

    def _headers(self) -> dict[str, str]:
        headers = {
            "user-agent": f"breeze-blue-python/{SDK_VERSION}",
            "x-breeze-sdk": f"breeze-blue-python/{SDK_VERSION}",
        }
        if self.api_key:
            headers["xi-api-key"] = self.api_key
        return headers


def _drop_none(payload: dict[str, Any] | None) -> dict[str, Any] | None:
    if payload is None:
        return None
    return {key: value for key, value in payload.items() if value is not None}
