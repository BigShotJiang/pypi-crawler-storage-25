from __future__ import annotations

import json
from pathlib import Path
from typing import Any, BinaryIO

import httpx

from ._audio import AudioResponse
from .types import (
    AsyncTtsJob,
    Balance,
    GenericStatus,
    GenerationJob,
    HistoryItem,
    HistoryList,
    Model,
    Usage,
    Voice,
    VoiceClonePreview,
    VoiceDesignResponse,
    VoiceList,
    VoiceSettings,
)


class TextToSpeechResource:
    def __init__(self, client: Any) -> None:
        self._client = client

    def convert(
        self,
        voice_id: str,
        *,
        text: str,
        output_format: str | None = None,
        model_id: str | None = None,
        language_code: str | None = None,
        instructions: str | None = None,
        voice_settings: dict[str, Any] | None = None,
        timeout: float | httpx.Timeout | None = None,
        **compatibility_fields: Any,
    ) -> AudioResponse:
        return self._client.audio_request(
            "POST",
            f"/v1/text-to-speech/{voice_id}",
            params={"output_format": output_format},
            json=_tts_payload(
                text=text,
                model_id=model_id,
                language_code=language_code,
                instructions=instructions,
                voice_settings=voice_settings,
                extra=compatibility_fields,
            ),
            timeout=timeout,
        )

    def create_job(
        self,
        voice_id: str,
        *,
        text: str,
        output_format: str | None = None,
        model_id: str | None = None,
        language_code: str | None = None,
        instructions: str | None = None,
        voice_settings: dict[str, Any] | None = None,
        timeout: float | httpx.Timeout | None = None,
        **compatibility_fields: Any,
    ) -> AsyncTtsJob:
        return self._client.json_request(
            "POST",
            f"/v1/text-to-speech/{voice_id}",
            params={"output_format": output_format, "delivery": "async"},
            json=_tts_payload(
                text=text,
                model_id=model_id,
                language_code=language_code,
                instructions=instructions,
                voice_settings=voice_settings,
                extra=compatibility_fields,
            ),
            timeout=timeout,
        )

    def stream(
        self,
        voice_id: str,
        *,
        text: str,
        output_format: str | None = None,
        optimize_streaming_latency: int | None = None,
        enable_logging: bool | None = None,
        model_id: str | None = None,
        language_code: str | None = None,
        instructions: str | None = None,
        voice_settings: dict[str, Any] | None = None,
        timeout: float | httpx.Timeout | None = None,
        **compatibility_fields: Any,
    ) -> AudioResponse:
        return self._client.audio_request(
            "POST",
            f"/v1/text-to-speech/{voice_id}/stream",
            params={
                "output_format": output_format,
                "optimize_streaming_latency": optimize_streaming_latency,
                "enable_logging": enable_logging,
            },
            json=_tts_payload(
                text=text,
                model_id=model_id,
                language_code=language_code,
                instructions=instructions,
                voice_settings=voice_settings,
                extra=compatibility_fields,
            ),
            timeout=timeout,
        )


class VoicesResource:
    """Voice CRUD plus the two-step preview → save flow for Breeze voices.

    Breeze's voice creation is always two steps: produce a preview
    (`create_clone_preview` from an audio sample, or `create_design_preview`
    from a text description), then persist it with `save_preview`. Preview
    generation never creates a saved voice until `save_preview` is called.
    """

    def __init__(self, client: Any) -> None:
        self._client = client

    # -- listing / single voice CRUD --------------------------------------

    def search(
        self,
        *,
        search: str | None = None,
        category: str | None = None,
        voice_type: str = "all",
        sort: str = "created_at_unix",
        sort_direction: str = "desc",
        next_page_token: str | None = None,
        page: int = 1,
        page_size: int = 50,
        timeout: float | httpx.Timeout | None = None,
    ) -> VoiceList:
        return self._client.json_request(
            "GET",
            "/v1/voices",
            params={
                "search": search,
                "category": category,
                "voice_type": voice_type,
                "sort": sort,
                "sort_direction": sort_direction,
                "next_page_token": next_page_token,
                "page": page,
                "page_size": page_size,
            },
            timeout=timeout,
        )

    def get(self, voice_id: str, *, timeout: float | httpx.Timeout | None = None) -> Voice:
        return self._client.json_request("GET", f"/v1/voices/{voice_id}", timeout=timeout)

    def edit(
        self,
        voice_id: str,
        *,
        name: str,
        description: str | None = None,
        labels: dict[str, str] | str | None = None,
        file: str | Path | bytes | BinaryIO | None = None,
        filename: str | None = None,
        content_type: str = "audio/wav",
        timeout: float | httpx.Timeout | None = None,
    ) -> GenericStatus:
        files = None
        if file is not None:
            files = [("files", _file_tuple(file, filename=filename, content_type=content_type))]
        return self._client.json_request(
            "PATCH",
            f"/v1/voices/{voice_id}",
            data={"name": name, "description": description, "labels": _labels_payload(labels)},
            files=files,
            timeout=timeout,
        )

    def delete(self, voice_id: str, *, timeout: float | httpx.Timeout | None = None) -> GenericStatus:
        return self._client.json_request("DELETE", f"/v1/voices/{voice_id}", timeout=timeout)

    # -- voice settings ---------------------------------------------------

    def get_settings(self, voice_id: str, *, timeout: float | httpx.Timeout | None = None) -> VoiceSettings:
        return self._client.json_request("GET", f"/v1/voices/{voice_id}/settings", timeout=timeout)

    def edit_settings(self, voice_id: str, *, timeout: float | httpx.Timeout | None = None, **settings: Any) -> VoiceSettings:
        if not settings:
            raise TypeError("edit_settings requires at least one voice setting keyword argument.")
        return self._client.json_request(
            "PATCH",
            f"/v1/voices/{voice_id}/settings",
            json=settings,
            timeout=timeout,
        )

    # -- two-step preview → save flow -------------------------------------

    def create_clone_preview(
        self,
        *,
        name: str,
        file: str | Path | bytes | BinaryIO,
        filename: str | None = None,
        content_type: str = "audio/wav",
        description: str | None = None,
        labels: dict[str, str] | str | None = None,
        remove_background_noise: bool = False,
        text: str | None = None,
        instructions: str | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> VoiceClonePreview:
        """Generate a clone preview from a single audio sample.

        Returns a ``generated_voice_id`` referring to the preview. Call
        :meth:`save_preview` after the user accepts the preview to persist
        it as a real voice.
        """

        if remove_background_noise:
            raise ValueError("remove_background_noise is not supported by the Breeze Developer API.")
        return self._client.json_request(
            "POST",
            "/v1/voice-previews/clone",
            data={
                "name": name,
                "description": description,
                "labels": _labels_payload(labels),
                "text": text,
                "instructions": instructions,
            },
            files=[("files", _file_tuple(file, filename=filename, content_type=content_type))],
            timeout=timeout,
        )

    def create_design_preview(
        self,
        *,
        voice_description: str,
        text: str | None = None,
        output_format: str | None = None,
        model_id: str | None = None,
        language_code: str | None = None,
        guidance_scale: float | None = None,
        preview_count: int | None = None,
        timeout: float | httpx.Timeout | None = None,
        **compatibility_fields: Any,
    ) -> VoiceDesignResponse:
        """Design preview voices from a text prompt (no audio sample).

        Returns one or more previews. Each preview has a
        ``generated_voice_id``; pass the chosen one to :meth:`save_preview`.
        """

        return self._client.json_request(
            "POST",
            "/v1/voice-previews/design",
            params={"output_format": output_format},
            json=_drop_none(
                {
                    "voice_description": voice_description,
                    "text": text,
                    "model_id": model_id,
                    "language_code": language_code,
                    "guidance_scale": guidance_scale,
                    "preview_count": preview_count,
                    **compatibility_fields,
                }
            ),
            timeout=timeout,
        )

    def stream_preview(
        self,
        generated_voice_id: str,
        *,
        output_format: str | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AudioResponse:
        """Stream the audio of a clone or design preview before saving."""

        return self._client.audio_request(
            "GET",
            f"/v1/voice-previews/{generated_voice_id}/stream",
            params={"output_format": output_format},
            timeout=timeout,
        )

    def save_preview(
        self,
        *,
        generated_voice_id: str,
        voice_name: str,
        voice_description: str | None = None,
        labels: dict[str, str] | None = None,
        played_not_selected_voice_ids: list[str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Voice:
        """Persist a clone or design preview as a real voice asset."""

        return self._client.json_request(
            "POST",
            f"/v1/voice-previews/{generated_voice_id}/save",
            json=_drop_none(
                {
                    "voice_name": voice_name,
                    "voice_description": voice_description,
                    "labels": labels,
                    "played_not_selected_voice_ids": played_not_selected_voice_ids,
                }
            ),
            timeout=timeout,
        )


class HistoryResource:
    def __init__(self, client: Any) -> None:
        self._client = client

    def list(
        self,
        *,
        voice_id: str | None = None,
        model_id: str | None = None,
        search: str | None = None,
        source: str | None = None,
        sort_direction: str = "desc",
        start_after_history_item_id: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        status_class: str | None = None,
        page: int = 1,
        page_size: int = 50,
        timeout: float | httpx.Timeout | None = None,
    ) -> HistoryList:
        return self._client.json_request(
            "GET",
            "/v1/history",
            params={
                "voice_id": voice_id,
                "model_id": model_id,
                "search": search,
                "source": source,
                "sort_direction": sort_direction,
                "start_after_history_item_id": start_after_history_item_id,
                "from": from_date,
                "to": to_date,
                "status_class": status_class,
                "page": page,
                "page_size": page_size,
            },
            timeout=timeout,
        )

    def get(self, history_item_id: str, *, timeout: float | httpx.Timeout | None = None) -> HistoryItem:
        return self._client.json_request("GET", f"/v1/history/{history_item_id}", timeout=timeout)

    def download_audio(self, history_item_id: str, *, timeout: float | httpx.Timeout | None = None) -> AudioResponse:
        return self._client.audio_request("GET", f"/v1/history/{history_item_id}/audio", timeout=timeout)

    def delete(self, history_item_id: str, *, timeout: float | httpx.Timeout | None = None) -> GenericStatus:
        return self._client.json_request("DELETE", f"/v1/history/{history_item_id}", timeout=timeout)


class GenerationJobsResource:
    def __init__(self, client: Any) -> None:
        self._client = client

    def get(self, generation_job_id: str, *, timeout: float | httpx.Timeout | None = None) -> GenerationJob:
        return self._client.json_request("GET", f"/v1/generation-jobs/{generation_job_id}", timeout=timeout)

    def download_audio(self, generation_job_id: str, *, timeout: float | httpx.Timeout | None = None) -> AudioResponse:
        return self._client.audio_request("GET", f"/v1/generation-jobs/{generation_job_id}/audio", timeout=timeout)


class ModelsResource:
    def __init__(self, client: Any) -> None:
        self._client = client

    def list(self, *, timeout: float | httpx.Timeout | None = None) -> list[Model]:
        return self._client.json_request("GET", "/v1/models", timeout=timeout)


class AccountResource:
    def __init__(self, client: Any) -> None:
        self._client = client

    def balance(self, *, timeout: float | httpx.Timeout | None = None) -> Balance:
        return self._client.json_request("GET", "/v1/balance", timeout=timeout)

    def usage(
        self,
        *,
        days: int = 30,
        search: str | None = None,
        method: str | None = None,
        page: int = 1,
        page_size: int = 20,
        timeout: float | httpx.Timeout | None = None,
    ) -> Usage:
        return self._client.json_request(
            "GET",
            "/v1/usage",
            params={
                "days": days,
                "search": search,
                "method": method,
                "page": page,
                "page_size": page_size,
            },
            timeout=timeout,
        )


def _tts_payload(
    *,
    text: str,
    model_id: str | None,
    language_code: str | None,
    instructions: str | None,
    voice_settings: dict[str, Any] | None,
    extra: dict[str, Any],
) -> dict[str, Any]:
    reserved = {"text", "model_id", "language_code", "instructions", "voice_settings"}
    conflicts = sorted(reserved.intersection(extra))
    if conflicts:
        raise TypeError(f"Compatibility fields cannot override first-class fields: {', '.join(conflicts)}")
    return _drop_none(
        {
            **extra,
            "text": text,
            "model_id": model_id,
            "language_code": language_code,
            "instructions": instructions,
            "voice_settings": voice_settings,
        }
    )


def _drop_none(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


def _labels_payload(labels: dict[str, str] | str | None) -> str | None:
    if labels is None or isinstance(labels, str):
        return labels
    return json.dumps(labels)


def _file_tuple(file: str | Path | bytes | BinaryIO, *, filename: str | None, content_type: str) -> tuple[str, bytes | BinaryIO, str]:
    if isinstance(file, str | Path):
        path = Path(file)
        return (filename or path.name, path.read_bytes(), content_type)
    if isinstance(file, bytes):
        return (filename or "sample.wav", file, content_type)
    return (filename or getattr(file, "name", "sample.wav"), file, content_type)
