from __future__ import annotations

from typing import Any, TypedDict


JsonObject = dict[str, Any]


class GenericStatus(TypedDict):
    status: str


class VoiceSettings(TypedDict, total=False):
    stability: float
    similarity_boost: float
    style: float
    use_speaker_boost: bool
    speed: float
    guidance_scale: float | None


class PronunciationDictionaryLocator(TypedDict, total=False):
    pronunciation_dictionary_id: str
    version_id: str


class ModelLanguage(TypedDict, total=False):
    language_id: str
    name: str


class Model(TypedDict):
    model_id: str
    name: str
    can_do_text_to_speech: bool
    can_do_voice_conversion: bool
    can_use_style: bool
    can_use_speaker_boost: bool
    serves_pro_voices: bool
    languages: list[ModelLanguage]
    description: str


class VoiceOptional(TypedDict, total=False):
    category: str
    voice_type: str
    labels: dict[str, str]
    preview_url: str | None
    settings: VoiceSettings
    description: str | None
    created_at_unix: int | None


class Voice(VoiceOptional):
    voice_id: str
    name: str


class VoiceListOptional(TypedDict, total=False):
    next_page_token: str | None


class VoiceList(VoiceListOptional):
    voices: list[Voice]
    has_more: bool
    total: int
    page: int
    page_size: int


class VoiceClonePreview(TypedDict):
    generated_voice_id: str
    requires_verification: bool


class VoiceDesignPreviewOptional(TypedDict, total=False):
    duration_secs: float | None


class VoiceDesignPreview(VoiceDesignPreviewOptional):
    generated_voice_id: str
    audio_base_64: str
    media_type: str


class VoiceDesignResponse(TypedDict):
    previews: list[VoiceDesignPreview]
    text: str


class AsyncTtsJob(TypedDict):
    generation_job_id: str
    history_item_id: str
    status: str


AsyncTextToSpeechJob = AsyncTtsJob


class GenerationJobError(TypedDict):
    code: str
    detail: str


class GenerationJobOptional(TypedDict, total=False):
    voice_id: str | None
    voice_name: str | None
    voice_category: str | None
    model_id: str | None
    text: str | None
    content_type: str | None
    download_url: str | None
    created_at: str | None
    completed_at: str | None
    date_unix: int | None
    error: GenerationJobError | None


class GenerationJob(GenerationJobOptional):
    generation_job_id: str
    history_item_id: str
    status: str
    state: str
    source: str


class HistoryItemOptional(TypedDict, total=False):
    voice_id: str | None
    voice_name: str | None
    voice_category: str | None
    model_id: str | None
    text: str | None
    state: str | None
    content_type: str | None
    date_unix: int | None
    request_id: str | None
    latency_ms: int | None
    http_status: int | None


class HistoryItem(HistoryItemOptional):
    history_item_id: str
    source: str


class HistoryListOptional(TypedDict, total=False):
    last_history_item_id: str | None


class HistoryList(HistoryListOptional):
    history: list[HistoryItem]
    has_more: bool
    total: int
    page: int
    page_size: int


class BalanceTopup(TypedDict, total=False):
    topup_id: str | None
    amount: float | None
    status: str | None
    created_at: str | None


class BalanceOptional(TypedDict, total=False):
    balance_millicredits: int | None


class Balance(BalanceOptional):
    balance: float
    topups: list[BalanceTopup]


class UsageSummary(TypedDict, total=False):
    request_count: int
    total_text_characters: int
    total_billable_units: float
    total_cost: float
    total_cost_millicredits: int


class UsageDailyBucket(TypedDict, total=False):
    date: str
    request_count: int


class UsageItem(TypedDict, total=False):
    id: str
    endpoint: str
    method: str
    status: int
    model: str | None
    billable_units: float | None
    cost: float | None
    cost_millicredits: int | None
    latency_ms: int | None
    trace_id: str | None
    request_id: str | None
    text_characters: int | None
    action_code: str | None
    created_at: str | None


class UsageOptional(TypedDict, total=False):
    window_days: int | None


class Usage(UsageOptional):
    summary: UsageSummary
    total: int
    page: int
    page_size: int
    daily: list[UsageDailyBucket]
    items: list[UsageItem]
