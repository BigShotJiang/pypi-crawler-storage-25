from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from ._audio import AudioResponse, play, save, start_play, start_stream, stream
from ._client import BreezeBlue
from ._errors import (
    APIError,
    AuthenticationError,
    BadRequestError,
    BillingInsufficientCreditsError,
    BreezeBlueError,
    ConflictError,
    ForbiddenError,
    GenerationNotReadyError,
    NotFoundError,
    RateLimitError,
    ServiceUnavailableError,
    UpstreamError,
    ValidationError,
)
from .types import (
    AsyncTtsJob,
    AsyncTextToSpeechJob,
    Balance,
    GenericStatus,
    GenerationJob,
    HistoryItem,
    HistoryList,
    Model,
    Usage,
    Voice,
    VoiceClonePreview,
    VoiceDesignResponse,
    VoiceList,
    VoiceSettings,
)

try:
    __version__ = version("breeze-blue")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "APIError",
    "AudioResponse",
    "AuthenticationError",
    "BadRequestError",
    "BillingInsufficientCreditsError",
    "BreezeBlue",
    "BreezeBlueError",
    "ConflictError",
    "ForbiddenError",
    "GenerationNotReadyError",
    "NotFoundError",
    "RateLimitError",
    "ServiceUnavailableError",
    "UpstreamError",
    "ValidationError",
    "AsyncTtsJob",
    "AsyncTextToSpeechJob",
    "Balance",
    "GenericStatus",
    "GenerationJob",
    "HistoryItem",
    "HistoryList",
    "Model",
    "Usage",
    "Voice",
    "VoiceClonePreview",
    "VoiceDesignResponse",
    "VoiceList",
    "VoiceSettings",
    "__version__",
    "play",
    "save",
    "start_play",
    "start_stream",
    "stream",
]
