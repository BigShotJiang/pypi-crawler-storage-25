from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
import platform
import shutil
import subprocess


class PlayerNotFoundError(RuntimeError):
    pass


@dataclass(frozen=True)
class AudioResponse:
    content: bytes
    content_type: str | None = None
    history_item_id: str | None = None

    def save(self, path: str | Path) -> Path:
        target = Path(path)
        target.write_bytes(self.content)
        return target

    def play(self) -> None:
        ffplay = shutil.which("ffplay")
        if ffplay:
            _pipe_to_player([ffplay, "-autoexit", "-nodisp", "-"], self.content)
            return

        if platform.system() == "Darwin":
            afplay = shutil.which("afplay")
            if afplay:
                _pipe_to_player([afplay, "-"], self.content)
                return

        raise PlayerNotFoundError("Install ffplay, or afplay on macOS, to play audio.")

    def stream(self) -> None:
        mpv = shutil.which("mpv")
        if not mpv:
            raise PlayerNotFoundError("Install mpv to stream audio.")
        _pipe_to_player([mpv, "--no-terminal", "-"], self.content)


def save(audio: AudioResponse | bytes | bytearray, path: str | Path) -> Path:
    return _coerce_audio_response(audio).save(path)


def play(audio: AudioResponse | bytes | bytearray) -> None:
    return _coerce_audio_response(audio).play()


def stream(audio: AudioResponse | bytes | bytearray | Iterable[bytes]) -> None:
    mpv = shutil.which("mpv")
    if not mpv:
        raise PlayerNotFoundError("Install mpv to stream audio.")
    _pipe_chunks_to_player([mpv, "--no-terminal", "-"], _iter_audio_chunks(audio))


def start_play(audio: AudioResponse | bytes | bytearray) -> subprocess.Popen[bytes]:
    response = _coerce_audio_response(audio)
    ffplay = shutil.which("ffplay")
    if ffplay:
        return _start_player([ffplay, "-autoexit", "-nodisp", "-"], response.content)
    if platform.system() == "Darwin":
        afplay = shutil.which("afplay")
        if afplay:
            return _start_player([afplay, "-"], response.content)
    raise PlayerNotFoundError("Install ffplay, or afplay on macOS, to play audio.")


def start_stream(audio: AudioResponse | bytes | bytearray | Iterable[bytes]) -> subprocess.Popen[bytes]:
    mpv = shutil.which("mpv")
    if not mpv:
        raise PlayerNotFoundError("Install mpv to stream audio.")
    return _start_player_with_chunks([mpv, "--no-terminal", "-"], _iter_audio_chunks(audio))


def _coerce_audio_response(audio: AudioResponse | bytes | bytearray) -> AudioResponse:
    if isinstance(audio, AudioResponse):
        return audio
    return AudioResponse(content=bytes(audio))


def _iter_audio_chunks(audio: AudioResponse | bytes | bytearray | Iterable[bytes]) -> Iterable[bytes]:
    if isinstance(audio, AudioResponse):
        yield audio.content
        return
    if isinstance(audio, bytes | bytearray):
        yield bytes(audio)
        return
    yield from audio


def _pipe_to_player(command: list[str], audio: bytes) -> None:
    process = _start_player(command, audio)
    process.wait()


def _pipe_chunks_to_player(command: list[str], chunks: Iterable[bytes]) -> None:
    process = _start_player_with_chunks(command, chunks)
    process.wait()


def _start_player(command: list[str], audio: bytes) -> subprocess.Popen[bytes]:
    return _start_player_with_chunks(command, [audio])


def _start_player_with_chunks(command: list[str], chunks: Iterable[bytes]) -> subprocess.Popen[bytes]:
    process = subprocess.Popen(command, stdin=subprocess.PIPE)
    if process.stdin is not None:
        for chunk in chunks:
            if chunk:
                process.stdin.write(chunk)
        process.stdin.close()
    return process
