# Changelog

## 0.3.0

- Added async text-to-speech helpers: `client.text_to_speech.create_job(...)`,
  `client.generation_jobs.get(...)`, and
  `client.generation_jobs.download_audio(...)` for long text, reference-heavy
  voices, and batch production workflows.
- Added `GenerationNotReadyError` for active async job audio downloads, with
  `retry_after` parsed from the `Retry-After` response header.
- Added `AsyncTextToSpeechJob` as a clearer alias for `AsyncTtsJob`.

## 0.2.1

- Fixed README text-to-speech examples to omit the optional model selector unless using a value returned by `models.list()`.

## 0.2.0

- Updated voice preview helpers to use the clearer `/v1/voice-previews/...` API paths by default while keeping the same `client.voices.*` method names.
- Updated voice edit and settings helpers to use REST-style `PATCH /v1/voices/{voice_id}` and `PATCH /v1/voices/{voice_id}/settings` paths by default.

## 0.1.3

- Breaking: collapsed `client.voices.ivc.*` and `client.text_to_voice.*` into `client.voices.*` and renamed methods around Breeze's actual two-step preview → save flow. Replacements:
  - `voices.ivc.create_preview` → `voices.create_clone_preview`
  - `voices.ivc.edit` → `voices.edit`
  - `voices.ivc.get_settings` / `settings` → `voices.get_settings`
  - `voices.ivc.update_settings` / `edit_settings` → `voices.edit_settings`
  - `voices.ivc.delete` → `voices.delete`
  - `text_to_voice.design` → `voices.create_design_preview`
  - `text_to_voice.create` → `voices.save_preview`
  - `text_to_voice.stream_preview` → `voices.stream_preview`
- Removed the `InstantVoiceCloneResource` and `TextToVoiceResource` classes and the `client.text_to_voice` attribute. The previous `voices.settings` / `voices.update_settings` aliases are gone; use `voices.get_settings` / `voices.edit_settings`.

## 0.1.2

- Removed ElevenLabs-positioning copy from the README and PyPI keywords; quickstart and reference examples use the published `breeze-blue` package only.
- Clarified that the SDK silently accepts ElevenLabs-style compatibility values such as `mp3_44100_128` while documentation only shows the codec values Breeze actually supports today.

## 0.1.1

- Rewrote the PyPI project description for external developers.
- Removed internal monorepo release workflow notes from the packaged README.
- Clarified setup, TTS, voice, history, account, audio helper, and error handling examples.

## 0.1.0

Initial release.

- ElevenLabs-compatible client surface for text-to-speech, voices, text-to-voice, history, models, and account APIs.
- Typed errors for authentication, rate limiting, validation, billing, upstream, and service-unavailable failures.
- Audio playback helpers using ffplay, afplay on macOS, and mpv for streaming-style playback.
- `xi-api-key` auth header and `x-breeze-sdk` telemetry header.
