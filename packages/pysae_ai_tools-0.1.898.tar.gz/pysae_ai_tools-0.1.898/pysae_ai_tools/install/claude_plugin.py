"""Install the Pysae Claude Code plugin (skills + marketplace) as a Tool.

Exposes the standard module-level ``get_state`` and ``do_install`` so the
meta-installer (`pysae-ai-tools tools install claude-plugin`) can manage
the plugin alongside CLI binaries and MCP servers.

Editable mode (skills symlinked from the source instead of deep-copied)
is auto-detected from the running package: when ``pysae_ai_tools`` is
installed via ``uv tool install -e <repo>``, the importlib resource path
for ``pysae_ai_tools.claude_plugin`` resolves to the actual repo on disk
and the parent directory contains ``pyproject.toml``. In that case we
symlink the skills/ directory; otherwise we deep-copy.

On Windows, ``os.symlink`` requires admin or developer-mode privileges;
a failure falls back to a deep copy with a warning so the install does
not abort.
"""

import os
import shutil
import subprocess
import sys
from importlib.resources import files
from pathlib import Path

from pysae_ai_tools.config import DATA_DIR

from .common.base import InstallReport, ToolState

MARKETPLACE_NAME = "pysae-marketplace"
PLUGIN_NAME = "pysae"
PLUGIN_VERSION = "1.0.0"


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def _claude_plugins_dir() -> Path:
    """Direct fallback location under ``~/.claude/plugins/`` (used when
    ``claude plugin marketplace add`` isn't available)."""
    return Path.home() / ".claude" / "plugins" / "cache" / MARKETPLACE_NAME / PLUGIN_NAME / PLUGIN_VERSION


def _marketplace_install_dir() -> Path:
    """Permanent directory holding the marketplace structure for ``marketplace add``.

    Why permanent: ``claude plugin marketplace add <path>`` stores ``<path>``
    in ``known_marketplaces.json`` and re-reads it on every Claude Code startup.
    A ``tempfile.TemporaryDirectory()`` here would be deleted on process exit,
    leaving a dangling reference and silently breaking skill loading.
    Cross-platform via platformdirs (Linux/macOS/Windows).
    """
    return DATA_DIR / "claude-marketplace"


def _resource_path(subpath: str) -> Path:
    """Resolve a resource path from the bundled ``claude_plugin`` package."""
    ref = files("pysae_ai_tools.claude_plugin") / subpath
    # importlib.resources may return a MultiplexedPath or a PosixPath.
    return Path(str(ref))


def _is_editable() -> bool:
    """True when the running ``pysae_ai_tools`` is installed editable.

    Detection: the package's directory has a sibling ``pyproject.toml``
    (which is the case in a git checkout, but never under ``site-packages``).
    """
    import pysae_ai_tools

    pkg_root = Path(pysae_ai_tools.__file__).resolve().parent
    return (pkg_root.parent / "pyproject.toml").exists()


# ---------------------------------------------------------------------------
# Tree helpers
# ---------------------------------------------------------------------------


def _clear_path(dst: Path) -> None:
    """Remove ``dst`` whether it's a file, dir, or symlink."""
    if dst.is_symlink() or dst.is_file():
        try:
            dst.unlink()
        except OSError:
            pass
    elif dst.is_dir():
        shutil.rmtree(dst, ignore_errors=True)


def _copy_tree(src: Path, dst: Path) -> int:
    """Deep-copy ``src`` → ``dst``. Returns the file count."""
    if dst.exists():
        shutil.rmtree(dst)
    if not (src.is_symlink() or src.is_dir()):
        return 0
    real_src = src.resolve()
    shutil.copytree(real_src, dst, dirs_exist_ok=True)
    return sum(1 for _ in dst.rglob("*") if _.is_file())


def _materialize_tree(src: Path, dst: Path, *, editable: bool) -> int:
    """Symlink (editable) or deep-copy ``src`` → ``dst``.

    Editable mode requires the package itself to be installed editable
    (``uv tool install -e``); ``importlib.resources`` then resolves bundled
    paths to the actual source on disk, so the symlink at ``dst``
    transparently picks up edits to the repo without reinstalling.

    On Windows ``os.symlink`` requires admin or developer-mode privileges;
    a failure falls back to a deep copy with a warning so the install does
    not abort.
    """
    if editable:
        try:
            real_src = src.resolve()
            dst.parent.mkdir(parents=True, exist_ok=True)
            _clear_path(dst)
            os.symlink(real_src, dst, target_is_directory=real_src.is_dir())
            return sum(1 for _ in dst.rglob("*") if _.is_file())
        except OSError as exc:
            print(
                f"  ⚠ Symlink {dst} → {src} a échoué ({exc}); fallback en copie.",
                file=sys.stderr,
            )
    return _copy_tree(src, dst)


# ---------------------------------------------------------------------------
# Claude Code marketplace integration
# ---------------------------------------------------------------------------


def _try_marketplace_add(src: Path) -> bool:
    """Best-effort registration via ``claude plugin marketplace add``."""
    try:
        result = subprocess.run(
            ["claude", "plugin", "marketplace", "add", str(src)],
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=30,
        )
        if result.returncode == 0:
            subprocess.run(
                ["claude", "plugin", "install", f"{PLUGIN_NAME}@{MARKETPLACE_NAME}"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=30,
            )
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return False


def _try_marketplace_remove() -> None:
    """Best-effort removal of the marketplace registration in Claude Code."""
    try:
        subprocess.run(
            ["claude", "plugin", "marketplace", "remove", MARKETPLACE_NAME],
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=30,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass


# ---------------------------------------------------------------------------
# Tool API — get_state / do_install (consumed by ``tools install``)
# ---------------------------------------------------------------------------


def get_state() -> ToolState:
    """Report install status of the plugin.

    Considered installed when:
    - the marketplace directory exists with a ``marketplace.json`` AND
    - the plugin's skills directory exists.

    Otherwise ``needs_install=True``. We do not currently surface a
    ``needs_update`` signal — re-running ``do_install`` always realigns
    the on-disk tree with what the package ships.
    """
    marketplace_dir = _marketplace_install_dir()
    plugin_skills = marketplace_dir / "plugins" / PLUGIN_NAME / "skills"
    marketplace_json = marketplace_dir / ".claude-plugin" / "marketplace.json"
    installed = marketplace_json.exists() and plugin_skills.exists()
    return ToolState(
        needs_install=not installed,
        extra={
            "marketplace_dir": str(marketplace_dir),
            "skills": str(plugin_skills) if plugin_skills.exists() else "",
            "editable": _is_editable(),
        },
    )


def do_install() -> InstallReport:
    """Install or update the plugin tree.

    Auto-detects editable mode from the running package; symlinks the
    skills/ directory in editable mode, deep-copies otherwise.
    """
    editable = _is_editable()

    skills_src = _resource_path("skills")
    marketplace_src = _resource_path("marketplace")
    plugin_src = _resource_path("plugin")

    if not skills_src.exists():
        return InstallReport(error=f"resources missing ({skills_src})")

    # Strategy 1 — register via ``claude plugin marketplace add``.
    marketplace_json = marketplace_src / "marketplace.json"
    if marketplace_json.exists():
        marketplace_install = _marketplace_install_dir()
        if marketplace_install.exists():
            shutil.rmtree(marketplace_install)
        (marketplace_install / ".claude-plugin").mkdir(parents=True)
        shutil.copy2(marketplace_json, marketplace_install / ".claude-plugin" / "marketplace.json")

        plugin_dir = marketplace_install / "plugins" / PLUGIN_NAME / ".claude-plugin"
        plugin_dir.mkdir(parents=True)
        plugin_json = plugin_src / "plugin.json"
        if plugin_json.exists():
            shutil.copy2(plugin_json, plugin_dir / "plugin.json")

        _materialize_tree(
            skills_src,
            marketplace_install / "plugins" / PLUGIN_NAME / "skills",
            editable=editable,
        )

        if _try_marketplace_add(marketplace_install):
            return InstallReport(
                method="marketplace add",
                path=str(marketplace_install),
                extra={"editable": editable},
            )

    # Strategy 2 — direct copy into the plugin cache.
    dest = _claude_plugins_dir()
    dest.mkdir(parents=True, exist_ok=True)

    n = _materialize_tree(skills_src, dest / "skills", editable=editable)

    plugin_json_src = plugin_src / "plugin.json"
    if plugin_json_src.exists():
        plugin_meta_dir = dest / ".claude-plugin"
        plugin_meta_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(plugin_json_src, plugin_meta_dir / "plugin.json")

    return InstallReport(
        method="direct copy",
        path=str(dest),
        extra={"skills_count": n, "editable": editable},
    )


def do_uninstall(*, dry_run: bool = False) -> InstallReport:
    """Tear down the plugin: unregister the marketplace, delete its files.

    Removes:
    - the marketplace registration in Claude Code (``claude plugin
      marketplace remove pysae-marketplace``);
    - the persistent marketplace tree under ``~/.local/share/pysae-ai-tools/``;
    - the direct-copy fallback under ``~/.claude/plugins/cache/``.
    """
    removed: list[str] = []
    marketplace_dir = _marketplace_install_dir()
    plugin_cache = _claude_plugins_dir()

    if dry_run:
        return InstallReport(
            action="uninstall",
            extra={
                "dry_run": True,
                "marketplace_remove_cmd": (f"claude plugin marketplace remove {MARKETPLACE_NAME}"),
                "marketplace_dir": str(marketplace_dir),
                "plugin_cache": str(plugin_cache),
            },
        )

    _try_marketplace_remove()
    if marketplace_dir.exists():
        shutil.rmtree(marketplace_dir, ignore_errors=True)
        removed.append(str(marketplace_dir))
    if plugin_cache.exists():
        shutil.rmtree(plugin_cache, ignore_errors=True)
        removed.append(str(plugin_cache))

    return InstallReport(action="uninstall", extra={"removed": removed})
