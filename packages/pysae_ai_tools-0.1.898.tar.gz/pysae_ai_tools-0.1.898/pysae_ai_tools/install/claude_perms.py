"""Bootstrap default Claude Code permissions in ``~/.claude/settings.json``.

Adds a curated allow-list to ``permissions.allow`` so common Pysae tools
and MCP servers don't trigger a permission prompt on first use. Idempotent
— only appends entries that aren't already present, never removes anything.
"""

import json
from pathlib import Path

from .common.base import InstallReport, ToolState

CLAUDE_SETTINGS_PATH = Path.home() / ".claude" / "settings.json"

DEFAULT_PERMISSIONS: tuple[str, ...] = (
    "Bash",
    "Read",
    "Edit",
    "Write",
    "Glob",
    "Grep",
    "WebFetch",
    "WebSearch",
    "Agent",
    "Skill",
    "AskUserQuestion",
    "TaskCreate",
    "TaskUpdate",
    "TaskList",
    "TaskGet",
    "TaskOutput",
    "TaskStop",
    "mcp__mongodb-dev",
    "mcp__mongodb-prod",
    "mcp__kubernetes",
    "mcp__datadog",
    "mcp__postman",
    "mcp__chrome-devtools",
    "mcp__context7",
    "mcp__claude_ai_Context7",
    "mcp__claude_ai_Slack",
    "mcp__claude_ai_Notion",
    "mcp__claude_ai_Rube",
    "mcp__claude_ai_Airtable",
    "mcp__claude_ai_Intercom",
    "mcp__claude_ai_Sentry",
    "mcp__ide",
    "mcp__mongodb-atlas-mcp-dev",
    "mcp__mongodb-atlas-mcp-prod",
    "mcp__plugin_slack_slack",
    "mcp__gitlab",
)


def _read_settings() -> dict[str, object]:
    if not CLAUDE_SETTINGS_PATH.exists():
        return {}
    try:
        data = json.loads(CLAUDE_SETTINGS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _current_allow() -> list[str]:
    data = _read_settings()
    perms = data.get("permissions", {})
    if not isinstance(perms, dict):
        return []
    allow = perms.get("allow", [])
    if not isinstance(allow, list):
        return []
    return [str(x) for x in allow]


def _missing_permissions() -> list[str]:
    current = set(_current_allow())
    return [p for p in DEFAULT_PERMISSIONS if p not in current]


def get_state() -> ToolState:
    missing = _missing_permissions()
    return ToolState(
        needs_install=bool(missing),
        needs_update=False,
        extra={
            "settings_path": str(CLAUDE_SETTINGS_PATH),
            "missing_count": len(missing),
            "missing": missing,
            "total": len(DEFAULT_PERMISSIONS),
        },
    )


def do_install() -> InstallReport:
    missing = _missing_permissions()
    if not missing:
        return InstallReport(
            action="noop",
            path=str(CLAUDE_SETTINGS_PATH),
            method="all default permissions already present",
        )

    data = _read_settings()
    perms = data.setdefault("permissions", {})
    if not isinstance(perms, dict):
        return InstallReport(error="permissions key in settings.json is not an object")
    allow_raw = perms.setdefault("allow", [])
    if not isinstance(allow_raw, list):
        return InstallReport(error="permissions.allow in settings.json is not a list")

    allow_raw.extend(missing)

    try:
        CLAUDE_SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        CLAUDE_SETTINGS_PATH.write_text(
            json.dumps(data, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    except OSError as exc:
        return InstallReport(error=f"could not write {CLAUDE_SETTINGS_PATH}: {exc}")

    return InstallReport(
        action="install",
        path=str(CLAUDE_SETTINGS_PATH),
        method="permissions.allow merge",
        extra={"added": missing, "added_count": len(missing)},
    )
