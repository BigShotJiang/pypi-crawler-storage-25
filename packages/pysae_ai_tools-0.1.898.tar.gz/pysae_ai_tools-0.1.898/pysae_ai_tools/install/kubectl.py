"""Install or update kubectl from dl.k8s.io."""

import subprocess
from typing import Any

import httpx
import typer

from .common import binary, platform
from .common.base import BinaryTool, InstallReport


class KubectlTool(BinaryTool):
    name = "kubectl"
    binary_name = "kubectl"
    version_arg = "version --client=true"
    cli_help = "Install/update kubectl and configure EKS contexts (dev/prod)"
    winget_package = "Kubernetes.kubectl"
    brew_package = "kubectl"

    def fetch_latest_version(self) -> str:
        r = httpx.get("https://dl.k8s.io/release/stable.txt", timeout=5.0, follow_redirects=True)
        r.raise_for_status()
        return r.text.strip()

    def _install_from_dlk8s(self, plat: platform.Platform) -> InstallReport:
        try:
            version = self.fetch_latest_version()
        except Exception as exc:  # noqa: BLE001
            return InstallReport(error=f"could not fetch stable version: {exc}")

        ver = version if version.startswith("v") else f"v{version}"
        arch = "amd64" if plat.arch.value == "x86_64" else plat.arch.value
        suffix = ".exe" if plat.is_windows else ""
        url = f"https://dl.k8s.io/release/{ver}/bin/{plat.os.value}/{arch}/kubectl{suffix}"

        from .common.download import download_and_install_binary

        try:
            path = download_and_install_binary(url, self.binary_name)
        except Exception as exc:  # noqa: BLE001
            return InstallReport(error=f"download/install failed: {exc}")
        installed_v = binary.get_version(self.binary_name, version_arg=self.version_arg)
        return InstallReport(version=installed_v or version.lstrip("v"), path=str(path))

    def install_linux(self, plat: platform.Platform) -> InstallReport:
        return self._install_from_dlk8s(plat)

    def install_macos(self, plat: platform.Platform) -> InstallReport:
        return self._install_from_dlk8s(plat)

    def install_windows(self, plat: platform.Platform) -> InstallReport:
        return self._install_from_dlk8s(plat)

    def check_contexts(self) -> dict[str, Any] | None:
        if not binary.which(self.binary_name):
            return {"contexts": [], "cluster_ok": False}
        try:
            r = subprocess.run(
                [self.binary_name, "config", "get-contexts", "-o", "name"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                check=False,
                timeout=5,
            )
        except (OSError, subprocess.TimeoutExpired):
            return {"contexts": [], "cluster_ok": False}
        contexts = [line.strip() for line in r.stdout.splitlines() if line.strip()]
        try:
            cluster = subprocess.run(
                [self.binary_name, "cluster-info"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                check=False,
                timeout=5,
            )
        except (OSError, subprocess.TimeoutExpired):
            return {"contexts": contexts, "cluster_ok": False}
        return {"contexts": contexts, "cluster_ok": cluster.returncode == 0}

    def extract_identity(self, state: dict[str, Any]) -> list[tuple[str, str | None]]:
        contexts = state.get("contexts", [])
        cluster_ok = state.get("cluster_ok", False)
        lines: list[tuple[str, str | None]] = []
        for ctx in contexts:
            icon = "✓" if cluster_ok else "✗"
            lines.append((f"{icon} {ctx}", typer.colors.GREEN if cluster_ok else typer.colors.RED))
        return lines


_tool = KubectlTool()
get_state = _tool.get_state
do_install = _tool.do_install
cli = _tool.make_cli()

if __name__ == "__main__":
    cli()
