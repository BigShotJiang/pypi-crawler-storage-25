"""Classifiers and generators that may call external services (Claude, glab API)."""

import re
import subprocess

from ...common.glab.models import GitLabIssue
from ...common.references.gitlab_labels import (
    PROJECT_TO_DOMAIN,
    DomainLabel,
    TypeLabel,
)

# ---------------------------------------------------------------------------
# Type classification
# ---------------------------------------------------------------------------

TYPE_KEYWORDS: dict[str, list[str]] = {
    "type::bug": [
        r"\bbug\b",
        r"\bfix\b",
        r"\bbroken\b",
        r"\bregression\b",
        r"\bcrash",
        r"\berror\b",
        r"\bfail",
        r"\b500\b",
        r"\b404\b",
        r"\bcorrect",
        r"\bincorrect\b",
        r"\bwrong\b",
        r"\bissue\b",
        r"\bproblem\b",
    ],
    "type::feature": [
        r"\badd\b",
        r"\bimplement",
        r"\bnew\b",
        r"\bfeature\b",
        r"\buser story\b",
        r"\benable\b",
        r"\bintroduce\b",
        r"\bsupport\b",
        r"\ballow\b",
        r"\bajouter\b",
        r"\bnouveau\b",
        r"\bnouvelle\b",
    ],
    "type::technical": [
        r"\btech\b",
        r"\bdebt\b",
        r"\bmigrat",
        r"\btooling\b",
        r"\bscript\b",
        r"\bci\b",
        r"\bcd\b",
        r"\binfra\b",
        r"\bdeploy",
        r"\bpipeline\b",
        r"\bdevops\b",
        r"\bdocker\b",
        r"\bhelm\b",
        r"\bterraform\b",
        r"\bupgrade\b",
        r"\bbump\b",
        r"\bdep",
        r"\bcve\b",
        r"\bsecurity\b",
        r"\baws\b",
        r"\beks\b",
        r"\bs3\b",
        r"\becr\b",
        r"\bnat\b",
        r"\bvpc\b",
        r"\bgateway\b",
        r"\belastic\b",
        r"\bargo",
        r"\bkubernetes\b",
        r"\bk8s\b",
    ],
    "type::refactoring": [
        r"\brefactor",
        r"\brename\b",
        r"\bcleanup\b",
        r"\brestructure\b",
        r"\breorganiz",
        r"\bsimplif",
        r"\bextract\b",
        r"\bsplit\b",
    ],
}

VALID_TYPE_LABELS = {str(t) for t in TypeLabel}


# ---------------------------------------------------------------------------
# Claude subprocess call
# ---------------------------------------------------------------------------


def _call_claude(prompt: str) -> str | None:
    """Call claude CLI and return stripped output, or None on failure."""
    try:
        result = subprocess.run(
            ["claude", "--print", "--model", "haiku", "-p", prompt],
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=30,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().strip('"').strip("'")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


# ---------------------------------------------------------------------------
# Type classification
# ---------------------------------------------------------------------------


def classify_type_with_claude(title: str, description: str, labels: list[str]) -> str | None:
    """Use Claude to classify an issue into a type label."""
    prompt = (
        "You are classifying a GitLab issue into exactly one type. Rules:\n"
        "- Output ONLY the type label, nothing else (no quotes, no explanation)\n"
        "- Choose from: type::bug, type::feature, type::technical, type::refactoring\n\n"
        "Definitions:\n"
        "- type::bug — Defect, regression, incorrect behavior, crash, error\n"
        "- type::feature — New user-facing functionality, user story\n"
        "- type::technical — Tech debt, tooling, scripts, CLI, migrations, infra, CI/CD, dependencies, security\n"
        "- type::refactoring — Code restructuring without behavior change\n\n"
        f"Title: {title}\n"
        f"Labels: {', '.join(labels)}\n"
        f"Description (first 500 chars):\n{description[:500]}\n"
    )
    answer = _call_claude(prompt)
    if answer and answer in VALID_TYPE_LABELS:
        return answer
    return None


def guess_type_label(issue: GitLabIssue) -> tuple[str | None, str]:
    """Guess the type label from project path, keywords, then Claude as fallback.

    Returns (label, method) where method is one of "project", "keywords", "claude", "none".
    """
    web_url = issue.web_url

    # 1. Strong signal: infra/tooling projects are always technical
    if any(
        p in web_url
        for p in (
            "pysae/infra",
            "pysae/deploy-tools",
            "pysae/platform-tools",
            "pysae/prefect",
            "pysae/gitlab-analytics",
        )
    ):
        return TypeLabel.TECHNICAL, "project"

    title = issue.title
    description = (issue.description or "")[:1000]
    text = f"{title} {description}".lower()

    # 2. Keyword scoring
    scores: dict[str, int] = {}
    for type_label, patterns in TYPE_KEYWORDS.items():
        score = sum(1 for p in patterns if re.search(p, text, re.IGNORECASE))
        if score > 0:
            scores[type_label] = score

    if scores:
        best = max(scores, key=lambda k: scores[k])
        second = sorted(scores.values(), reverse=True)
        if scores[best] >= 2 and (len(second) < 2 or second[0] > second[1]):
            return best, "keywords"

    # 3. Claude fallback
    labels = issue.labels
    result = classify_type_with_claude(title, description, labels)
    if result:
        return result, "claude"
    return None, "none"


def guess_domain_label(issue: GitLabIssue) -> DomainLabel | None:
    """Guess the domain label from the project path."""
    web_url = issue.web_url
    for project_path, domain in PROJECT_TO_DOMAIN.items():
        if project_path in web_url:
            return domain
    if "pysae/infra" in web_url:
        return DomainLabel.INFRA
    return None


# ---------------------------------------------------------------------------
# Title generation
# ---------------------------------------------------------------------------


def generate_title_with_claude(title: str, description: str, labels: list[str]) -> str | None:
    """Use claude CLI to generate a proper English title."""
    prompt = (
        "You are rewriting a GitLab issue title. Rules:\n"
        "- Output ONLY the new title, nothing else (no quotes, no explanation)\n"
        "- English only\n"
        "- Action-oriented (start with a verb: Add, Fix, Implement, Update, Remove, etc.)\n"
        "- No prefix like [API], tech:, scope:, feat:, fix:, etc. (labels handle scoping)\n"
        "- Concise: under 80 characters\n"
        "- Summarize the issue well based on the description\n\n"
        f"Current title: {title}\n"
        f"Labels: {', '.join(labels)}\n"
        f"Description (first 500 chars):\n{description[:500]}\n"
    )
    new_title = _call_claude(prompt)
    if new_title and len(new_title) < 120:
        return new_title
    return None
