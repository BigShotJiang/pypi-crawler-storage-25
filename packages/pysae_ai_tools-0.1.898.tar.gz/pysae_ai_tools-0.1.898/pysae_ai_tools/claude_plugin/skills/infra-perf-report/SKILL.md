---
name: infra-perf-report
description: >
  Set up scheduled API health reports on Slack. Creates 4 RemoteTriggers
  (6h, 7h, 8h, 9h weekdays) that run /infra-perf and post results to
  #alerts-api-perf. Use when the user says /infra-perf-report, /perf-report,
  'schedule health reports', 'rapports slack', 'setup morning reports',
  'active les rapports', or needs to configure scheduled API performance reports.
allowed-tools:
  - Bash
  - AskUserQuestion
  - RemoteTrigger
  - mcp__plugin_slack_slack__slack_send_message
  - mcp__plugin_slack_slack__slack_read_channel
---

Set up scheduled morning health reports for the API on Slack.

## Required tools

- `datadog-mcp`

Run `pysae-ai-tools tools require <tools>` before starting; if it exits non-zero, abort and report the install command from stderr to the user.

## Reference files

- **[../infra-perf/references/services.md](../infra-perf/references/services.md)** — service alias mapping
- **[../infra-perf/references/thresholds.md](../infra-perf/references/thresholds.md)** — alert thresholds

## What this skill does

Creates 4 `RemoteTrigger` cron jobs that:
1. Run `/infra-perf` (global, 1h window, compare yesterday)
2. Format the output as Slack mrkdwn
3. Post to `#alerts-api-perf`

## Execution flow

### Step 1: Confirm with user

Show the user what will be scheduled:

```
Je vais créer 4 triggers schedulés (lundi-vendredi) :
  - 6h00 (cron: 57 4 * * 1-5 UTC)
  - 7h00 (cron: 57 5 * * 1-5 UTC)
  - 8h00 (cron: 57 6 * * 1-5 UTC)
  - 9h00 (cron: 57 7 * * 1-5 UTC)

Chaque trigger exécute /infra-perf (global, 1h, compare yesterday)
et poste le résultat sur #alerts-api-perf.

On y va ?
```

Wait for confirmation.

### Step 2: Create RemoteTriggers

Create 4 triggers using the RemoteTrigger tool:

**Trigger 1 — 6h report:**
```
Action: create
Body:
  cron: "57 4 * * 1-5"
  prompt: |
    Run the /infra-perf skill with no arguments (all services, 1h window, compare yesterday).

    Then format the result as Slack mrkdwn using this template:

    *API Health Check — 6h* (vs hier)

    For each service, one line:
    *<service>*     P99 <val>  |  Err <val>  |  <pods> pods  |  CPU <val>

    Add ! after values exceeding warning thresholds.

    At the bottom, if any warnings:
    ! <count> alertes — <service>: <detail>

    Post the formatted message to Slack channel #alerts-api-perf
    using mcp__plugin_slack_slack__slack_send_message.
```

**Trigger 2 — 7h report:**
Same prompt, replace `6h` with `7h` in the header, cron: `"57 5 * * 1-5"`

**Trigger 3 — 8h report:**
Same prompt, replace with `8h`, cron: `"57 6 * * 1-5"`

**Trigger 4 — 9h report:**
Same prompt, replace with `9h`, cron: `"57 7 * * 1-5"`

### Step 3: Verify triggers are active

Use RemoteTrigger with action `list` to confirm all 4 triggers are registered.

Output:
```
Triggers schedulés actifs :

ID          Cron             Prochaine exécution
------------------------------------------------
<id1>       57 4 * * 1-5     <next_run>  (6h)
<id2>       57 5 * * 1-5     <next_run>  (7h)
<id3>       57 6 * * 1-5     <next_run>  (8h)
<id4>       57 7 * * 1-5     <next_run>  (9h)
```

### Step 4: Test one trigger manually

Ask the user if they want to test one trigger immediately:

```
Veux-tu que je lance un test maintenant ?
Ça va exécuter /infra-perf et poster le résultat sur #alerts-api-perf.
```

If yes, use RemoteTrigger with action `run` on one of the trigger IDs.

## Slack message format

```
*API Health Check — <hour>h* (vs hier)

*api-fast*     P99 340ms  |  Err 0.2%  |  3 pods  |  CPU 42%
*api-ndp*      P99 1.2s !  (+340%)  |  Err 1.8% !  |  4/5 pods  |  CPU 78%
*api-gtfsrt*   P99 55ms   |  Err 0.0%  |  2 pods  |  CPU 15%
*api-stats*    P99 180ms  |  Err 0.1%  |  2 pods  |  CPU 22%

! 2 alertes — api-ndp: latence P99 +340%, error rate +200%
```

Use `*bold*` for service names and section headers (Slack mrkdwn).

## Managing triggers

To list active triggers: user can ask "liste les triggers perf"
To cancel all triggers: user can ask "annule les rapports perf"

For cancellation, use RemoteTrigger action `list` to find IDs, then delete each.

## Critical rules

- **User confirmation** before creating triggers.
- **UTC cron** — the cron expressions are in UTC. Paris is UTC+1 (winter) or UTC+2 (summer). Adjust if needed.
- **Language**: French for Slack messages (headers), English for metric labels.
