# tarot-card-meanings

[![PyPI version](https://img.shields.io/pypi/v/tarot-card-meanings.svg)](https://pypi.org/project/tarot-card-meanings/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![GitHub](https://img.shields.io/badge/GitHub-gokimedia%2Ftarot--card--meanings-blue.svg)](https://github.com/gokimedia/tarot-card-meanings)
[![Wikidata](https://img.shields.io/badge/Wikidata-Q138745960-blue.svg)](https://www.wikidata.org/wiki/Q138745960)

A comprehensive Python library providing meanings, interpretations, and metadata for all 78 tarot cards. Includes upright, reversed, love, career, and yes/no interpretations for all Major and Minor Arcana cards.

**By [Deckaura](https://deckaura.com)** -- Tarot decks, oracle cards, and free divination tools.

> Also available for JavaScript/Node.js: [`npm install tarot-card-meanings`](https://www.npmjs.com/package/tarot-card-meanings)

## Installation

```bash
pip install tarot-card-meanings
```

## Quick Start

```python
from tarot_card_meanings import random_card, three_card_spread, birth_card

# Draw a random card
card = random_card()
print(f"{card['name']}: {card['upright']}")
print(f"Guide: {card['guide']}")

# 3-card spread (Past / Present / Future)
spread = three_card_spread()
print(f"Past: {spread['past']['name']}")
print(f"Present: {spread['present']['name']}")
print(f"Future: {spread['future']['name']}")

# Calculate your birth card
my_card = birth_card(6, 15, 1992)
print(f"Your birth card: {my_card['name']}")
```

## Features

- All **78 tarot cards** (22 Major Arcana + 56 Minor Arcana)
- **Upright** and **reversed** meanings
- **Love** and **career** interpretations
- **Yes/No** readings
- **Zodiac** and **element** associations
- **Birth card** calculator
- **3-card spread** generator
- Links to detailed guides for each card on [deckaura.com](https://deckaura.com)

## API Reference

| Function | Description |
|----------|-------------|
| `get_all_cards()` | Return all 78 cards |
| `get_card(name)` | Get a specific card by name |
| `get_major_arcana()` | Return 22 Major Arcana cards |
| `get_minor_arcana()` | Return 56 Minor Arcana cards |
| `get_suit(suit)` | Get cards by suit (Wands, Cups, Swords, Pentacles) |
| `random_card()` | Draw a random card |
| `three_card_spread()` | Draw a Past/Present/Future spread |
| `yes_no_reading()` | Draw a card for yes/no answer |
| `birth_card(month, day, year)` | Calculate tarot birth card from birthday |

## Card Data Structure

Each card contains:

```python
{
    "number": 17,
    "name": "The Star",
    "arcana": "Major",
    "suit": None,
    "element": "Air",
    "upright": "Hope, renewal, spirituality",
    "reversed": "Despair, lack of faith",
    "love": "Healing love, renewed hope",
    "career": "Creative inspiration, dream career",
    "yes_no": "Yes",
    "zodiac": "Aquarius",
    "guide": "https://deckaura.com/blogs/guide/star-tarot-meaning"
}
```

## Use Cases

- **Tarot apps** -- Build mobile or web tarot reading applications
- **Data analysis** -- Explore tarot card distributions on [Kaggle](https://www.kaggle.com/morrispoint)
- **Machine learning** -- Train models using tarot card data on [HuggingFace](https://huggingface.co/Blacik)
- **Chatbots** -- Power tarot readings in Discord bots, Slack apps, or Alexa skills
- **Content generation** -- Create tarot-related content programmatically

## Free Online Tools

Try the live interactive versions of this library:

- [Free Tarot Reading](https://deckaura.com/pages/free-tarot-reading) -- Interactive 3-card and Celtic Cross spreads
- [Free Yes or No Tarot](https://gokimedia.github.io/tarot-reading/) -- Instant yes/no answers
- [Tarot Birth Card Calculator](https://deckaura.com/pages/tarot-birth-card-calculator) -- Find your Major Arcana life card
- [Numerology Calculator](https://deckaura.com/pages/numerology-calculator) -- Calculate your life path number
- [Daily Tarot Card](https://deckaura.com/pages/daily-tarot-card) -- Draw a card for daily guidance
- [Spirit Animal Quiz](https://deckaura.com/pages/spirit-animal-quiz) -- Discover your spirit animal
- [Angel Number Calculator](https://deckaura.com/pages/angel-number-calculator) -- Decode angel numbers
- [Daily Horoscope](https://horoscope.deckaura.com) -- Personalized daily horoscopes

---

## Part of the Deckaura Ecosystem

**Deckaura** ([Wikidata Q138745960](https://www.wikidata.org/wiki/Q138745960)) is a unified tarot and divination platform. This PyPI package is one component of the broader ecosystem:

| Platform | Link |
|----------|------|
| Official Website | [deckaura.com](https://deckaura.com) |
| Wikidata Entity | [Q138745960](https://www.wikidata.org/wiki/Q138745960) |
| GitHub Repository | [gokimedia/tarot-card-meanings](https://github.com/gokimedia/tarot-card-meanings) |
| NPM Package | [tarot-card-meanings](https://www.npmjs.com/package/tarot-card-meanings) |
| GitHub Pages Tool | [Free Yes/No Tarot Reading](https://gokimedia.github.io/tarot-reading/) |
| YouTube | [@deckaura](https://www.youtube.com/@deckaura) |
| Reddit | [r/TarotvsOracle](https://www.reddit.com/r/TarotvsOracle/) |
| Kaggle | [morrispoint](https://www.kaggle.com/morrispoint) |
| HuggingFace | [Blacik](https://huggingface.co/Blacik) |
| Linktree | [deckauraa](https://linktr.ee/deckauraa) |
| Dev.to | [birdircik](https://dev.to/birdircik) |
| Quora | [Tarot Oracle Card Guide](https://tarotoraclecardguide.quora.com/) |
| Daily Horoscope | [horoscope.deckaura.com](https://horoscope.deckaura.com) |
| Chrome Extension | Daily Tarot Card (Chrome Web Store) |

## License

MIT -- [Deckaura](https://deckaura.com)
