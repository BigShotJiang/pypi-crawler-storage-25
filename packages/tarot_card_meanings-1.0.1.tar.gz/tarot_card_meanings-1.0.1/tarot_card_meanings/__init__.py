"""
tarot-card-meanings - Complete 78 tarot card meanings database.

Part of the Deckaura Ecosystem: https://deckaura.com
Wikidata Entity: https://www.wikidata.org/wiki/Q138745960
"""

__version__ = "1.0.1"
__author__ = "Deckaura"
__url__ = "https://deckaura.com"

MAJOR_ARCANA = {
    0: {"name": "The Fool", "keywords": ["new beginnings", "innocence", "spontaneity"], "element": "Air", "yes_or_no": "Yes"},
    1: {"name": "The Magician", "keywords": ["manifestation", "willpower", "skill"], "element": "Air", "yes_or_no": "Yes"},
    2: {"name": "The High Priestess", "keywords": ["intuition", "mystery", "inner wisdom"], "element": "Water", "yes_or_no": "Maybe"},
    3: {"name": "The Empress", "keywords": ["abundance", "nurturing", "fertility"], "element": "Earth", "yes_or_no": "Yes"},
    4: {"name": "The Emperor", "keywords": ["authority", "structure", "stability"], "element": "Fire", "yes_or_no": "Yes"},
    5: {"name": "The Hierophant", "keywords": ["tradition", "conformity", "spirituality"], "element": "Earth", "yes_or_no": "Maybe"},
    6: {"name": "The Lovers", "keywords": ["love", "harmony", "relationships"], "element": "Air", "yes_or_no": "Yes"},
    7: {"name": "The Chariot", "keywords": ["determination", "willpower", "victory"], "element": "Water", "yes_or_no": "Yes"},
    8: {"name": "Strength", "keywords": ["courage", "patience", "inner strength"], "element": "Fire", "yes_or_no": "Yes"},
    9: {"name": "The Hermit", "keywords": ["introspection", "solitude", "guidance"], "element": "Earth", "yes_or_no": "Maybe"},
    10: {"name": "Wheel of Fortune", "keywords": ["destiny", "cycles", "turning points"], "element": "Fire", "yes_or_no": "Yes"},
    11: {"name": "Justice", "keywords": ["fairness", "truth", "accountability"], "element": "Air", "yes_or_no": "Yes"},
    12: {"name": "The Hanged Man", "keywords": ["surrender", "new perspectives", "pause"], "element": "Water", "yes_or_no": "Maybe"},
    13: {"name": "Death", "keywords": ["transformation", "endings", "renewal"], "element": "Water", "yes_or_no": "No"},
    14: {"name": "Temperance", "keywords": ["balance", "patience", "moderation"], "element": "Fire", "yes_or_no": "Yes"},
    15: {"name": "The Devil", "keywords": ["bondage", "materialism", "shadow self"], "element": "Earth", "yes_or_no": "No"},
    16: {"name": "The Tower", "keywords": ["sudden change", "upheaval", "revelation"], "element": "Fire", "yes_or_no": "No"},
    17: {"name": "The Star", "keywords": ["hope", "inspiration", "renewed faith"], "element": "Air", "yes_or_no": "Yes"},
    18: {"name": "The Moon", "keywords": ["illusion", "intuition", "subconscious"], "element": "Water", "yes_or_no": "Maybe"},
    19: {"name": "The Sun", "keywords": ["joy", "success", "vitality"], "element": "Fire", "yes_or_no": "Yes"},
    20: {"name": "Judgement", "keywords": ["rebirth", "reflection", "reckoning"], "element": "Fire", "yes_or_no": "Yes"},
    21: {"name": "The World", "keywords": ["completion", "achievement", "wholeness"], "element": "Earth", "yes_or_no": "Yes"},
}

SUITS = {
    "wands": {"element": "Fire", "domain": "Action, creativity, career"},
    "cups": {"element": "Water", "domain": "Emotions, relationships, love"},
    "swords": {"element": "Air", "domain": "Intellect, conflict, truth"},
    "pentacles": {"element": "Earth", "domain": "Material world, finances"},
}

def get_card(name):
    """Get card data by name."""
    name_lower = name.lower()
    for num, card in MAJOR_ARCANA.items():
        if card["name"].lower() == name_lower:
            return card
    return None

def get_all_cards():
    """Get all 22 Major Arcana cards."""
    return MAJOR_ARCANA

def get_suit(suit_name):
    """Get suit information."""
    return SUITS.get(suit_name.lower())
