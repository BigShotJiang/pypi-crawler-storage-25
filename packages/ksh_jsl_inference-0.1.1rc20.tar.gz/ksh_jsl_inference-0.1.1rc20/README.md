# endpoints


## Development

### Pre-requisites

- Python 3.8 or higher
- Docker
- A valid JSL License

### Setup
 
```bash
make dev
```

### CLI

The `jsl_inference` CLI provides commands to deploy John Snow Labs healthcare NLP models to AWS SageMaker and Snowflake platforms.

**Get started with the CLI:**

```bash
# View all available commands
jsl_inference --help

# View SageMaker-specific commands
jsl_inference sagemaker --help

# View Snowflake-specific commands  
jsl_inference snowflake --help
```

**Example usage:**

```bash
# Deploy a clinical deidentification model to SageMaker
jsl_inference sagemaker deploy clinical_deidentification_docwise_wip \
  --endpoint-name my-clinical-model \
  --instance-type ml.m5.large

# Run a model locally for testing
jsl_inference serve clinical_deidentification_docwise_wip --port 8080

# Deploy to Snowflake with container services
jsl_inference snowflake deploy clinical_deidentification_docwise_wip \
  --service-name prediction_service \
  --compute-pool-name my_compute_pool
```


## Docs

Documentation is served using MkDocs. To view the documentation, run:

```bash
make docs
```
This will start a local development server and serve the documentation at `http://127.0.0.1:8000/`. The server will automatically reload when documentation files are modified.

## Testing

Tests are run via the Makefile which handles virtual environment setup and dependency installation automatically.

To run the tests, use one of the following commands:

```bash
# Run tests (installs dependencies automatically)
make test

# Run tests with verbose output
make test-verbose

# Run tests with coverage report
make test-coverage
```

Alternatively, if you prefer to manage dependencies manually:
```bash
pip install -e .[dev]
pytest
```

## Publishing

### Prerequisites
Before publishing to PyPI, ensure you have:
- `TWINE_PASSWORD` environment variable set with your PyPI API token
- Appropriate permissions to publish the package

### Version Management
To update the package version, modify the `__version__` variable in `endpoints/__about__.py`:

```python
__version__ = "x.y.z"
```

### Publishing to PyPI
Once the version is updated and prerequisites are met, publish the package:

```bash
make publish
```

This command will build the package and upload it to PyPI using twine.

### Toolkit

To get some information on the available models and its details, use this helper command

<small>Please make sure to install dependencies before. See tools/requirements.txt </small>
```bash
 python tools/models_info.py
```
You can also refer the help for this toolkit

```bash
 python tools/models_info.py --help
```




## Databricks Development (Needs to fixed)

see `databricks_tests.py` 
1. Start up a Databricks Cluster producer. Once Started you must **manually enable it to Unity Catalog**
2. Submit publisher job
3. Once completed, need to go to provider UI and publish the model to either private or public exchange
4. Once published, **you must manually import the listing on consumer end form the UI and accept the Terms of usage**. Then model can be tested via consumer jobs

