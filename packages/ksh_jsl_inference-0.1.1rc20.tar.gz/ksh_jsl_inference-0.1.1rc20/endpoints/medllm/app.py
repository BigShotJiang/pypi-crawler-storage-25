import os
import sys
from vllm.utils.argparse_utils import FlexibleArgumentParser
from vllm.entrypoints.openai.cli_args import make_arg_parser, validate_parsed_serve_args
from custom_logging import logger
from utils import get_spark_nlp_license, is_marketplace
from server_manager import ServerManager


def main():
    description = "vLLM OpenAI-Compatible RESTful API server."
    parser = FlexibleArgumentParser(description=description)
    parser = make_arg_parser(parser)

    parser.add_argument(
        "--model-version",
        type=str,
        default="latest",
        help="Version of the model to use (default: latest). Available versions depend on the model. Use 'latest' for the most recent version.",
    )

    args = parser.parse_args()
    validate_parsed_serve_args(args)
    cloud_product = is_marketplace()

    license_key = os.getenv("SPARK_NLP_LICENSE", "")
    if cloud_product:
        server_manager = ServerManager(args, license_key, cloud_product)
    else:
        if not license_key:
            license_key = get_spark_nlp_license()
            if license_key:
                os.environ["SPARK_NLP_LICENSE"] = license_key
            else:
                message = "No license found"
                logger.error(message)
                sys.exit(1)

        server_manager = ServerManager(args, license_key, cloud_product)
    try:
        server_manager.start_vllm()
    except KeyboardInterrupt:
        pass
    finally:
        server_manager.shutdown()
