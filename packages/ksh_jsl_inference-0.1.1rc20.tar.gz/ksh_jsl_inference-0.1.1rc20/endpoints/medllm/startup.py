from jsl_i import start

start()

import app

if __name__ == "__main__":
    app.main()
