import os
import time
from license_validator import LicenseValidator
from license_validator.utils.errors import LicenseKeyNotFound, LicenseKeyNotValid
from custom_logging import logger
from typing import List


class LicenseHandler:
    REPORTER_CHECK_TIMEOUT = 60

    def __init__(self, license_key: str = None, is_marketplace: bool = False):
        """
        Initializes the LicenseHandler.
        """
        self.license_key = license_key
        self.lv = None
        self.is_license_already_in_use = False
        self.is_license_missing = False
        self.is_invalid_license = False
        self.is_scope_missing = False
        self.retry_count = 0
        self.metadata = {}
        self._scopes = None
        self._reporter_status_checked = False
        self.is_marketplace = is_marketplace

    def start(self, license_key=None):
        """
        Starts the license validation.
        """
        if license_key:
            self.license_key = license_key
        message = "LicenseHandler: Starting license validation..."
        logger.info(message)
        if self.is_marketplace:
            self._initialize_is_marketplace_validator()
        else:
            self._initialize_validator()

    def stop(self):
        """
        Stops the LicenseValidator's reporter and resets internal flags.
        """
        message = "LicenseHandler: Stopping LicenseValidator..."
        logger.info(message)
        if self.lv:
            self.lv.stop()
        self.lv = None
        self.license_key = None
        self.is_license_already_in_use = False
        self.is_license_missing = False
        self.is_invalid_license = False
        self.retry_count = 0
        self._reporter_status_checked = False

    def set_scope(self, scopes: List[str]) -> None:
        """
        Sets and validates license scopes.

        Args:
            scopes: List of scope strings to validate
        """
        if not scopes:
            message = "LicenseHandler: No scopes provided for validation."
            logger.error(message)
            self.is_scope_missing = True
            return

        if not self.lv.validate_scopes(scopes):
            message = "LicenseHandler: Invalid scopes"
            logger.error(message)
            self.is_scope_missing = True

        self._scopes = scopes

    def _initialize_validator(self):
        """
        Core logic that initializes the LicenseValidator and handles both initial validation
        and reporter thread setup.
        """
        if not self.license_key:
            message = "LicenseHandler: No license key provided."
            logger.error(message)
            self.is_license_missing = True
            return

        try:
            os.environ["SPARK_NLP_LICENSE"] = self.license_key
            self.lv = LicenseValidator(app_name="JSL_MedLLM")
            self.lv.update_metadata(self.metadata)

            message = (
                "LicenseHandler: Initial validation successful, starting reporter..."
            )
            logger.info(message)
            self.lv.trigger_license_check(fetch_credentials=True)
            start_time = time.time()

            while time.time() - start_time < self.REPORTER_CHECK_TIMEOUT:
                if hasattr(self.lv, "_shared_state"):
                    if self.lv._shared_state.status is False:
                        message = "LicenseHandler: License is already in use."
                        logger.error(message)
                        self.is_license_already_in_use = True
                        return
                    elif self.lv._shared_state.status is True:
                        message = "LicenseHandler: License validation and reporter setup successful."
                        logger.info(message)
                        return
                time.sleep(2)

            seconds_msg = f"LicenseHandler: License reporter failed to initialize after {self.REPORTER_CHECK_TIMEOUT} seconds."
            logger.error(seconds_msg)
            self.is_license_already_in_use = True

        except LicenseKeyNotFound:
            message = "LicenseHandler: License key not found!"
            logger.error(message)
            self.is_license_missing = True
        except LicenseKeyNotValid as e:
            if "already in use" in str(e).lower():
                message = "LicenseHandler: License is already in use!"
                logger.error(message)
                self.is_license_already_in_use = True
            else:
                message = f"LicenseHandler: License key not valid! Error: {e}"
                logger.error(message)
                self.is_invalid_license = True
        except Exception as ex:
            if "license already in use" in str(ex).lower():
                message = "LicenseHandler: License is already in use!"
                logger.error(message)
                self.is_license_already_in_use = True
            else:
                message = f"LicenseHandler: Validation error: {ex}"
                logger.error(message)
                self.is_invalid_license = True


    def _initialize_is_marketplace_validator(self):
        """
        Initialize LicenseValidation for marketplace.
        """
        try:
            self.lv = LicenseValidator(app_name="JSL_MedLLM")
            self.lv.update_metadata(self.metadata)
            self.lv.trigger_license_check()
            if not self.lv.is_license_valid():
                message = "LicenseHandler: Marketplace license validation failed"
                logger.error(message)
                self.is_invalid_license = True
                return
            logger.info("LicenseHandler: Marketplace license validation successful")
            return
        except Exception as ex:
            message = f"LicenseHandler: Validation error: {ex}"
            logger.error(message)
            self.is_invalid_license = True