import logging
import os
import sys
from typing import Optional

_logger: Optional[logging.Logger] = None


def setup_logger() -> logging.Logger:
    """
    Configure and return a singleton logger instance with proper formatting and handling.
    """
    global _logger
    if _logger is not None:
        return _logger

    logger = logging.getLogger("llm-service")

    logger.propagate = False

    log_level = os.environ.get("LOG_LEVEL", "INFO").upper()
    logger.setLevel(log_level)

    logger.handlers.clear()

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(log_level)
    formatter_string = "%(name)s [%(asctime)s] [%(levelname)s] %(message)s"

    formatter = logging.Formatter(
        fmt=formatter_string,
        datefmt="%Y-%m-%d %H:%M:%S,%03d",
    )
    handler.setFormatter(formatter)

    logger.addHandler(handler)

    _logger = logger
    return logger


logger = setup_logger()

logging.getLogger().setLevel(logging.WARNING)
