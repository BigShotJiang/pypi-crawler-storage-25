import shutil
import os
import threading
import time
import gc
import signal
import torch
import uvloop
from vllm.entrypoints.openai.api_server import run_server
from custom_logging import logger
from utils import get_tensorizer_uri, ensure_model
from license_handler import LicenseHandler


class ServerManager:
    def __init__(self, args, license_key=None, is_marketplace=False):
        """
        Manages server startup, shutdown, license validation, and signal handling.
        """
        self.args = args
        self.license_key = license_key
        self.handler = LicenseHandler(license_key, is_marketplace=is_marketplace)
        self.monitor_thread = None
        self._shutting_down = False
        self.is_marketplace = is_marketplace

    def setup(self):
        """
        Initialize the license handler, start the license monitor thread and download model from S3.
        """
        try:
            self.handler.metadata.update({"model": self.args.model})

            self.handler.start()
            start_time = time.time()
            max_wait_time = 60

            while time.time() - start_time < max_wait_time:
                if (
                        self.handler.is_scope_missing
                        or self.handler.is_invalid_license
                        or self.handler.is_license_missing
                        or self.handler.is_license_already_in_use
                ):
                    self.shutdown()
                    return

                if (
                        self.handler.lv
                        and hasattr(self.handler.lv, "_shared_state")
                        and self.handler.lv._shared_state.status
                ):
                    break

                time.sleep(1)
            else:
                timeout_msg = f"License validation timed out after {max_wait_time} seconds. Shutting down."
                logger.error(timeout_msg)
                self.shutdown()
                return

            if not self.is_marketplace:
                self.monitor_thread = threading.Thread(
                    target=self.monitor_license_thread,
                    daemon=True,
                    name="license-monitor",
                )
                self.monitor_thread.start()

            signal.signal(signal.SIGTERM, self.handle_sigterm)
            signal.signal(signal.SIGINT, self.handle_sigint)

            tensor_parallel_size = int(getattr(self.args, "tensor_parallel_size", 1))
            model_version = getattr(self.args, "model_version", "latest")

            self._scopes, s3_model_folder = ensure_model(
                self.args.model, self.handler, tensor_parallel_size, model_version
            )

            aws_creds = self.handler.lv.get_aws_credentials()

            self.args.load_format = "tensorizer"
            self.args.model_loader_extra_config = {
                "tensorizer_uri": get_tensorizer_uri(
                    s3_model_folder, tensor_parallel_size
                ),
                "encryption_keyfile": "/tmp/encryption.key",
                "s3_endpoint": "https://s3.amazonaws.com",
                "s3_access_key_id": aws_creds["accessKeyId"],
                "s3_secret_access_key": aws_creds["secretAccessKey"],
                "s3_session_token": aws_creds["sessionToken"],
            }
            
            # Remove model_version from args since vLLM doesn't need it
            # It's only used for our download logic above
            if hasattr(self.args, 'model_version'):
                delattr(self.args, 'model_version')

        except Exception as e:
            error_msg = f"Error during setup: {str(e)}"
            logger.error(error_msg)
            self.shutdown()

    def monitor_license_thread(self):
        while not self._shutting_down:
            if (
                self.handler.is_invalid_license
                or self.handler.is_license_missing
                or self.handler.is_license_already_in_use
                or self.handler.is_scope_missing
            ):
                message = "License issue detected. Shutting down."
                logger.error(message)
                self.shutdown()
                break
            if self.handler.lv and hasattr(self.handler.lv, "_shared_state"):
                if not self.handler.lv._shared_state.status:
                    message = "License validation failed. Shutting down."
                    logger.error(message)
                    self.shutdown()
                    break
            time.sleep(10)

    def monitor_health_thread(self):
        """
        Monitor server health continuously and shutdown if health check fails.
        """
        try:
            import requests
            from requests.exceptions import RequestException

            port = getattr(self.args, "port", 8000)
            base_url = f"http://localhost:{port}"
            max_wait_time = 3600

            start_time = time.time()
            while not self._shutting_down:
                try:
                    if time.time() - start_time > max_wait_time:
                        error_msg = f"Server health check timed out after {max_wait_time} seconds"
                        logger.error(error_msg)
                        self.shutdown()
                        break

                    health_response = requests.get(f"{base_url}/health")
                    if health_response.status_code == 200:
                        models_response = requests.get(f"{base_url}/v1/models")
                        if models_response.status_code == 200:
                            message = "Server is healthy and model is loaded"
                            logger.info(message)
                            if not self.is_marketplace:
                                self.handler.set_scope(self._scopes)
                            try:
                                if os.path.exists("/tmp/encryption.key"):
                                    os.remove("/tmp/encryption.key")

                                for key in [
                                    "AWS_ACCESS_KEY_ID",
                                    "AWS_SECRET_ACCESS_KEY",
                                    "AWS_SESSION_TOKEN",
                                ]:
                                    os.environ.pop(key, None)
                            except Exception as e:
                                error_msg = f"Error during cleanup: {e}"
                                logger.warning(error_msg)
                            break

                except RequestException:
                    pass

                if not self._shutting_down:
                    time.sleep(10)

        except Exception as e:
            if not self._shutting_down:
                error_msg = f"Error in health check thread: {e}"
                logger.error(error_msg)
                self.shutdown()

    def start_vllm(self):
        """
        Run the vLLM server on main thread with health checks in background.
        """
        self.setup()
        try:
            health_thread = threading.Thread(
                target=self.monitor_health_thread, daemon=True, name="health-check"
            )
            health_thread.start()

            message = "Starting vLLM server"
            logger.info(message)
            uvloop.run(run_server(self.args))

        except KeyboardInterrupt:
            message = "KeyboardInterrupt received. Shutting down."
            logger.info(message)
            self.shutdown()
        except Exception as e:
            error_msg = f"Exception during server run: {e}"
            logger.error(error_msg)
            self.shutdown()

    def shutdown(self):
        """
        Perform a clean shutdown of all components.
        """
        if self._shutting_down:
            return
        self._shutting_down = True
        message = "Shutting down server..."
        logger.info(message)

        try:
            self.handler.stop()
        except Exception as e:
            error_msg = f"Error stopping license handler: {e}"
            logger.error(error_msg)

        try:
            if os.path.exists(self.args.model):
                shutil.rmtree(self.args.model)
            if os.path.exists("/tmp/encryption.key"):
                os.remove("/tmp/encryption.key")

            for key in [
                "AWS_ACCESS_KEY_ID",
                "AWS_SECRET_ACCESS_KEY",
                "AWS_SESSION_TOKEN",
            ]:
                os.environ.pop(key, None)
        except Exception as e:
            error_msg = f"Error during cleanup: {e}"
            logger.warning(error_msg)

        try:
            for thread in threading.enumerate():
                if thread is not threading.current_thread():
                    try:
                        if thread.is_alive():
                            message = f"Stopping thread: {thread.name}"
                            logger.info(message)
                            thread._stop()
                    except Exception:
                        pass
        except Exception as e:
            error_msg = f"Error stopping threads: {e}"
            logger.error(error_msg)

        try:
            gc.collect()
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
        except Exception as e:
            error_msg = f"Error cleaning GPU memory: {e}"
            logger.error(error_msg)

        message = "Shutdown complete, exiting..."
        logger.info(message)
        time.sleep(0.1)
        os._exit(0)

    def handle_sigterm(self, signum, frame):
        message = "Received SIGTERM signal. Shutting down."
        logger.info(message)
        self.shutdown()

    def handle_sigint(self, signum, frame):
        message = "Received Ctrl+C. Shutting down."
        logger.info(message)
        self.shutdown()
