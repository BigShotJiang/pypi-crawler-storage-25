import click

from endpoints import Platform
from endpoints.sagemaker.cli import sagemaker
from endpoints.snowflake.cli import snowflake

from . import internals


@click.group()
def cli():
    """
    John Snow Labs Endpoints CLI - Deploy and manage JSL models across platforms.

    This command-line interface provides tools for deploying John Snow Labs models
    to various cloud platforms and running local inference servers. It supports
    multiple deployment targets including SageMaker, Snowflake, and local development.

    Use the subcommands to deploy to specific platforms or start a local server
    for development and testing purposes.

    Examples:

        # Start a local inference server
        endpoints serve my-model-name

        # Deploy to SageMaker
        endpoints sagemaker deploy my-model-name

        # Deploy to Snowflake
        endpoints snowflake deploy my-model-name
    """
    pass


@cli.command()
@click.argument("model_id")
@click.option(
    "--language", required=False, default="en", help="The language of the model"
)
@click.option("--port", required=False, default=8080)
def serve(model_id: str, language: str, port: int):
    """
    Start a local JSL Inference Server for development and testing.

    This command launches a local inference server that can be used for development,
    testing, and prototyping with John Snow Labs models. The server provides REST
    API endpoints for model inference and can be accessed via HTTP requests.

    Args:
        MODEL_ID: The identifier of the JSL model to serve. This should be a valid
                 model name from the John Snow Labs model repository.

    Options:
        --language: The language variant of the model (default: "en")
        --port: The port number for the local server (default: 8080)

    Examples:
        # Start server with default settings
        endpoints serve ner_dl_bert

        # Start server on custom port with Spanish model
        endpoints serve ner_dl_bert --language es --port 9000

        # Start multilingual model
        endpoints serve multilingual_ner --language xx
    """
    internals.run_local(
        model_id=model_id, language=language, platform=Platform.LOCAL, port=port
    )


cli.add_command(sagemaker)
cli.add_command(snowflake)

if __name__ == "__main__":
    from endpoints.cli import *

    cli()
