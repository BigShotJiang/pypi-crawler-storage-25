from endpoints.logging import init_logging

from .internals import run_local

init_logging()

from .cli import cli

__all__ = ["cli", "run_local"]
