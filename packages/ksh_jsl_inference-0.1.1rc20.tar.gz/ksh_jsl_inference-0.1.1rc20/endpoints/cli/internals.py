from endpoints import Platform


def run_local(
    model_id: str,
    language: str,
    platform: Platform,
    port=8080,
):
    """Helper to run the model locally."""
    from endpoints.core import ModelRegistry
    from endpoints.server import setup_env_and_start_server

    model = ModelRegistry.find(model_id, language)

    setup_env_and_start_server(
        model=model, platform=platform, port=port, save_model=True
    )
