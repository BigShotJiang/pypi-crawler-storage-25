from typing import Optional

import uvicorn

from endpoints import Platform
from endpoints.core import ModelInfo

from .serve import create_fast_api_app, install_python_requirements


def serve(
    model: ModelInfo,
    platform: Platform,
    port: int = 8080,
):
    """
    Serve the model for inferencing

    :param model: The model to serve on the container.
    :param str platform: The platform for which the container is being served.
    :param int port: The port on which the container should be served.
    """

    app = create_fast_api_app(
        model,
        include_sagemaker_route=(platform in {Platform.SAGEMAKER, Platform.LOCAL}),
        include_snowflake_route=(platform in {Platform.SNOWFLAKE, Platform.LOCAL}),
    )

    uvicorn.run(app, host="0.0.0.0", port=port)


def setup_env(
    model: ModelInfo,
    platform: Platform,
    johnsnowlabs_version: Optional[str] = None,
    store_model: bool = False,
):
    """
    Install the required packages and download the model and setup the environment

    :param str model: The model to download. If None, no model is downloaded.
    :param str platform: The platform for which the container is being served.
    :param BaseInferenceModel inference_model: The inferencing logic to use.
    :param str language: The language of the model to download. Default: 'en'.
    :param ModelType model_type: The model_type to use for the model. Default: ModelType.HEALTHCARE_NLP.
    :param str johnsnowlabs_version: The version of the John Snow Labs library.
    """
    install_python_requirements(platform, model.model, johnsnowlabs_version)
    if store_model:
        from endpoints.core import download_model

        download_model(model=model)


def setup_env_and_start_server(
    model: ModelInfo, platform: Platform, port: int = 8080, save_model=False
):
    """
    Setup the environment and start the inferencing server

    :param ModelInfo model: The model to download. If None, no model is downloaded.
    :param platform Platform: The Platform to target.
    :param int port: The port on which the container should be served. Default: 8080.
    """
    setup_env(model=model, platform=platform, store_model=save_model)
    serve(model=model, platform=platform, port=port)


__all__ = ["serve", "setup_env", "setup_env_and_start_server"]
