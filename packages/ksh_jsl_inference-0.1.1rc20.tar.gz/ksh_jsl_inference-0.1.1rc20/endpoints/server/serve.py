from typing import List, Optional

from fastapi import FastAPI

from endpoints import Platform
from endpoints.core import ModelInfo
from endpoints.core.models import BaseModel
from endpoints.logging import init_logging, logger
from endpoints.pip_utils import install
from endpoints.settings import JSL_DOWNLOAD_PACKAGES

from .routers import healthcheck


def create_fast_api_app(
    model: ModelInfo,
    include_sagemaker_route=False,
    include_snowflake_route=False,
):
    """Creates a FastAPI application with model lifecycle management.

    Creates and configures a FastAPI application with automatic model initialization,
    prediction warmup, and proper disposal during application lifecycle. Optionally
    includes platform-specific routes for SageMaker and Snowflake.

    Args:
        model: The model information containing the model instance and metadata.
        include_sagemaker_route: Whether to include SageMaker-specific routes.
            Defaults to False.
        include_snowflake_route: Whether to include Snowflake-specific routes.
            Defaults to False.

    Returns:
        FastAPI: A configured FastAPI application instance with the specified model
            and routes.
    """
    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        model.model.predict({model.model._input._field: "Sample request"})

        yield {"model": model.model}

        model.model.dispose()

    app = FastAPI(lifespan=lifespan)
    init_logging()

    app.include_router(healthcheck.router)
    if include_sagemaker_route:
        from .routers import sagemaker

        app.include_router(sagemaker.router)
    if include_snowflake_route:
        from .routers import snowflake

        app.include_router(snowflake.router)
    return app


def get_requirements(
    platform: Platform,
    johnsnowlabs_version: Optional[str] = None,
    inference: Optional[BaseModel] = None,
) -> List[str]:
    """Generates a list of Python package requirements for the specified platform and model.

    Combines John Snow Labs library requirements with platform-specific and model-specific
    dependencies. Filters out duplicate johnsnowlabs packages to avoid conflicts.

    Args:
        platform: The platform for which the requirements are being generated.
        johnsnowlabs_version: The specific version of the John Snow Labs library
            to include. If None, no johnsnowlabs version constraint is added.
        inference: The inference model to include requirements for. If provided,
            model-specific requirements are added to the list.

    Returns:
        List[str]: A list of package requirement strings in pip format.

    Todo:
        Add checks for requirements conflicts between packages.
    """
    requirements = []
    if johnsnowlabs_version:
        requirements = [f"johnsnowlabs=={johnsnowlabs_version}"]

    additional_packages = platform.get_python_requirements()
    if inference:
        additional_packages.extend(inference.get_python_requirements())
    additional_packages = [
        package
        for package in additional_packages
        if not package.startswith("johnsnowlabs")
    ]
    ##TODO: Add checks for requirements conflicts
    requirements.extend(additional_packages)

    return requirements


def install_python_requirements(
    platform: Platform,
    inference_model: BaseModel,
    johnsnowlabs_version: Optional[str] = None,
):
    """Installs Python package requirements for the specified platform and model.

    Generates and installs the required Python packages for the given platform and
    inference model. Installation can be skipped based on the JSL_DOWNLOAD_PACKAGES
    environment setting.

    Args:
        platform: The platform for which to install requirements.
        inference_model: The inference model requiring specific packages.
        johnsnowlabs_version: The specific version of John Snow Labs library
            to install. If None, uses default version handling.

    Note:
        Installation is skipped if JSL_DOWNLOAD_PACKAGES environment variable
        is set to False.
    """
    if not JSL_DOWNLOAD_PACKAGES:
        logger.info("Skipping installation of python requirements")
    else:
        requirements = get_requirements(
            platform=platform,
            inference=inference_model,
            johnsnowlabs_version=johnsnowlabs_version,
        )
        install(requirements)
