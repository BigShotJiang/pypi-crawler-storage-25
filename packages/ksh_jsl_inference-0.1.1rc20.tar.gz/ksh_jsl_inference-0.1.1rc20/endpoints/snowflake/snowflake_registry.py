import json
import os
import subprocess

from snowflake.connector import connect


def get_snowflake_env():
    return {
        "account": os.getenv("SNOWFLAKE_ACCOUNT"),
        "user": os.getenv("SNOWFLAKE_USER"),
        "host": os.getenv("SNOWFLAKE_HOST"),
        "database": os.getenv("SNOWFLAKE_DATABASE"),
        "warehouse": os.getenv("SNOWFLAKE_WAREHOUSE"),
        "schema": os.getenv("SNOWFLAKE_SCHEMA"),
        "role": os.getenv("SNOWFLAKE_ROLE"),
        "authenticator": "SNOWFLAKE_JWT",
        "private_key_file": os.getenv("SNOWFLAKE_PRIVATE_KEY"),
    }


def get_token():
    # https://github.com/snowflakedb/snowflake-cli/blob/main/src/snowflake/cli/_plugins/spcs/image_registry/manager.py#L35

    connection = connect(**get_snowflake_env())
    result = connection.execute_string(
        "alter session set PYTHON_CONNECTOR_QUERY_RESULT_FORMAT = 'json'"
    )
    # disable session deletion
    connection._all_async_queries_finished = lambda: False

    token_data = connection._rest._token_request("ISSUE")
    return {
        "token": token_data["data"]["sessionToken"],
        "expires_in": token_data["data"]["validityInSecondsST"],
    }


def login():
    token_info = get_token()

    commands = [
        "docker",
        "login",
        "-u",
        "0sessiontoken",
        "--password-stdin",
        os.environ["DOCKER_REGISTRY"],
    ]

    result = subprocess.check_output(
        commands, input=json.dumps(token_info), text=True, stderr=subprocess.PIPE
    )
    print(result)


if __name__ == "__main__":
    login()
