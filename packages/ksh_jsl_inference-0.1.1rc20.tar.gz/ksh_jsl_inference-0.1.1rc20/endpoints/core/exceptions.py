class ModelRegistryException(Exception):
    pass
