"""Schema validation module for input and output data.

This module provides schema validation functionality for data structures,
including field type checking, required field validation, and value constraints.
"""

from typing import Any, Dict, List, Type

MODEL_LOCATION = "/opt/ml/model"
DEFAULT_INPUT_KEYS = ["text", "input_text", "texts", "input_texts"]


class SchemaValidationError(Exception):
    """Exception raised when schema validation fails.

    This exception is raised when data does not conform to the expected schema,
    including missing required fields, incorrect types, or invalid values.
    """

    pass


class Schema:
    """Schema definition for validating individual data fields.

    This class defines the validation rules for a single field, including
    its type, default value, required status, and allowed values.

    Attributes:
        _field (str): The name of the field.
        _required (bool): Whether the field is required.
        _typing (Type): The expected type of the field.
        _dtypes (List[str]): List of valid values for the field.
        _default (Any): The default value if field is missing.
    """

    def __init__(
        self,
        field: str,
        typing: Type,
        default: Any = None,
        required: bool = False,
        dtypes: List[str] = [],
    ):
        """Initialize a new Schema instance.

        Args:
            field (str): The name of the field to validate.
            typing (Type): The expected type of the field value.
            default (Any, optional): Default value if field is missing. Defaults to None.
            required (bool, optional): Whether the field is required. Defaults to False.
            dtypes (List[str], optional): List of valid values for the field. Defaults to [].
        """
        self._field = field
        self._required = required
        self._typing = typing
        self._dtypes = dtypes
        self._default = default

    def validate(self, data: Dict):
        """Validate data against this schema.

        Checks if the field exists when required, validates the type of the value,
        and ensures the value is in the allowed list if dtypes is specified.

        Args:
            data (Dict): The data dictionary to validate.

        Returns:
            Any: The validated field value.

        Raises:
            SchemaValidationError: If the field is required but missing, has wrong type,
                or has a value not in the allowed dtypes list.
        """
        if self._required and self._field not in data:
            raise SchemaValidationError(
                f"Required field '{self._field}' is missing from data. "
                f"Expected type: {self._typing.__name__} or List{self._typing.__name__}"
            )

        # If field is not required and not present, return default without validation
        if not self._required and self._field not in data:
            return self._default

        value = data.get(self._field, self._default)

        # Only validate if we have a non-None value or if the field was explicitly provided
        if value is not None:
            if self._dtypes:
                if value not in self._dtypes:
                    raise SchemaValidationError(
                        f"Field '{self._field}' must be one of {self._dtypes}, got '{value}'"
                    )
            if isinstance(value, list):
                for item in value:
                    if not isinstance(item, self._typing):
                        raise SchemaValidationError(
                            f"Field '{self._field}' must be of type {self._typing}, got '{item}'"
                        )
            elif not isinstance(value, self._typing):
                raise SchemaValidationError(
                    f"Field '{self._field}' must be of type {self._typing}, got '{value}'"
                )
        return value


class SchemaCollection:
    """A collection of schemas for validating multiple fields.

    This class manages multiple Schema instances and validates data
    against all of them, returning a dictionary of validated values.

    Attributes:
        _schemas (List[Schema]): List of Schema instances to validate against.
    """

    def __init__(self, schemas: List[Schema]):
        """Initialize a new SchemaCollection instance.

        Args:
            schemas (List[Schema]): A list of Schema instances for validation.
        """
        self._schemas = schemas

    def validate(self, data: Dict):
        """Validate data against all schemas in the collection.

        Validates the provided data against each schema in the collection
        and returns a dictionary mapping field names to their validated values.

        Args:
            data (Dict): The data dictionary to validate.

        Returns:
            Dict: Dictionary mapping field names to validated values.

        Raises:
            SchemaValidationError: If any schema validation fails.
        """
        return {schema._field: schema.validate(data) for schema in self._schemas}
