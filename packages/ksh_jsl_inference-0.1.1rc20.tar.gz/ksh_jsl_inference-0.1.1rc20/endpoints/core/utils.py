import os

from endpoints import ModelType
from endpoints.settings import MODEL_LOCATION
from endpoints.utils import copy_from_source_to_target

from .model_registry import ModelInfo


def download_local_model(model_info: ModelInfo):
    """Downloads a model saved on disk"""
    if model_info.model_type != ModelType.LOCAL:
        raise Exception(f"Model Type should be ModelType.LOCAL")
    if model_info.artifacts_path is None:
        raise Exception("Model artifacts path is missing")

    if (
        model_info.model_type == ModelType.LOCAL
        and model_info.artifacts_path is not None
    ):
        try:
            copy_from_source_to_target(model_info.artifacts_path, MODEL_LOCATION)
        except FileNotFoundError:
            # Extract filename from artifacts_path and try to find on current directory

            filename = os.path.basename(model_info.artifacts_path)
            current_dir_path = os.path.join(os.getcwd(), filename)
            if os.path.exists(current_dir_path):
                copy_from_source_to_target(current_dir_path, MODEL_LOCATION)
            else:
                raise FileNotFoundError(
                    f"Model artifacts not found at {model_info.artifacts_path} "
                    f"or in current directory as {filename}"
                )

        return MODEL_LOCATION


def download_model(model: ModelInfo):
    """Downloads a model based on its info"""
    from endpoints.johnsnowlabs.utils import (
        download_chromadb_resolver_model,
        download_healthcare_model,
    )

    if model.model_type == ModelType.PRETRAINED_HEALTHCARE:
        return download_healthcare_model(model_ref=model.id, language=model.language)

    elif model.model_type == ModelType.CHROMADB_RESOLVER:
        return download_chromadb_resolver_model(concept=model.id)
    elif model.model_type == ModelType.LOCAL:
        return download_local_model(model)
    else:
        raise NotImplementedError("Only healthcare_nlp is supported at the moment")
