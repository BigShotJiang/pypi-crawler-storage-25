"""SageMaker deployment utilities for John Snow Labs models.

This module provides functionality for deploying machine learning models to Amazon SageMaker
platform. It includes utilities for generating Docker files and building Docker images
specifically configured for SageMaker's deployment requirements.

The module handles:
- Generation of SageMaker-compatible Docker configurations
- Building Docker images optimized for SageMaker deployment
- Managing default file locations for deployment artifacts

Examples:
    # Example
    ```python
    from endpoints.sagemaker import generate_docker_files, build_docker_image

    # Generate Docker files for a model
    docker_files_path = generate_docker_files("my-model-id")

    # Build Docker image for SageMaker deployment
    build_docker_image("my-model-id")
    ```
"""

import os
import uuid
from typing import Optional

from endpoints import Platform, container
from endpoints.container import build_docker_image as _build_docker_image
from endpoints.settings import DEFAULT_JOHNSNOWLABS_VERSION, HOME_DIR


def get_default_docker_file_location() -> str:
    """Get the default location for Docker files in SageMaker platform.

    Generates a unique directory path within the JSL inference home directory
    specifically for SageMaker Docker files.

    Returns:
        str: The default directory path for storing Docker files.
    """
    return os.path.join(
        HOME_DIR, ".jsl_inference", Platform.SAGEMAKER, str(uuid.uuid4())
    )


def generate_docker_files(
    model_id: str,
    johnsnowlabs_version: str = DEFAULT_JOHNSNOWLABS_VERSION,
    no_license: bool = False,
    language: str = "en",
    output_dir: Optional[str] = None,
    **kwargs,
):
    """Generate Docker files for the specified model for SageMaker deployment.

    Creates the necessary Docker configuration files required to deploy a model
    on Amazon SageMaker platform. This includes Dockerfile and other deployment
    artifacts specific to SageMaker's requirements.

    Args:
        model_id (str): The identifier of the model to generate Docker files for.
        johnsnowlabs_version (str, optional): Version of johnsnowlabs library to use.
            Defaults to DEFAULT_JOHNSNOWLABS_VERSION.
        no_license (bool, optional): Whether to skip license validation.
            Defaults to False.
        language (str, optional): Language setting for the model.
            Defaults to "en".
        output_dir (Optional[str], optional): Directory where Docker files will be stored.
            If None, uses the default location from get_default_docker_file_location().
            Defaults to None.

    Returns:
        The result from container.generate_docker_files function, typically the
        output directory path where files were generated.
    """

    return container.generate_docker_files(
        model_id=model_id,
        johnsnowlabs_version=johnsnowlabs_version,
        no_license=no_license,
        language=language,
        platform=Platform.SAGEMAKER,
        store_model=False,
        output_dir=output_dir or get_default_docker_file_location(),
    )


def build_docker_image(model_id: str, **kwargs):
    """Build Docker image for SageMaker platform deployment.

    Generates the necessary Docker files for the specified model and then builds
    a Docker image suitable for deployment on Amazon SageMaker platform.

    Args:
        model_id (str): The identifier of the model to build Docker image for.
        johnsnowlabs_version (str, optional): Version of johnsnowlabs library to use.
            Defaults to DEFAULT_JOHNSNOWLABS_VERSION.
        no_license (bool, optional): Whether to skip license validation.
            Defaults to False.
        language (str, optional): Language setting for the model.
            Defaults to "en".
        output_dir (Optional[str], optional): Directory where Docker files will be stored.
            If None, uses the default location from get_default_docker_file_location().
            Defaults to None.
        image_name (str): Name for the Docker image to be built.
        license_path (Optional[str]): Path to the license file. If None or invalid,
            will attempt to find license from JSL_HOME.
        build_context_dir (str): Directory containing the Dockerfile and build context.
        no_cache (bool, optional): Whether to build without using Docker cache.
            Defaults to False.
        image_tag (str, optional): Tag for the Docker image. Defaults to "latest".

    Note:
        This function combines the Docker file generation and image building
        steps into a single operation for convenience.
    """
    docker_files_location = generate_docker_files(model_id, **kwargs)
    _build_docker_image(build_context_dir=docker_files_location, **kwargs)


__all__ = ["generate_docker_files", "build_docker_image"]
