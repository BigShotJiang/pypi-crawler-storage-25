"""Container module for serving inference models in Docker environments.

This module provides functionality for containerizing and serving machine learning
models using Docker. It includes utilities for building Docker images, generating
Docker files, and setting up container environments for model inference.

The module supports various deployment platforms and provides a standardized way
to package and deploy models in containerized environments.
"""

from endpoints.core import ModelRegistry
from endpoints.server import serve
from endpoints.settings import TARGET_PLATFORM

from .setup import setup_container_env
from .utils import (
    build_docker_image,
    format_docker_image_name,
    format_image_tag,
    generate_docker_files,
    validate_docker_image_name,
    validate_image_tag,
)


# Default entrypoint for the Docker containers
def _init(command, model_id: str, language: str):
    """Initialize and execute commands for containerized model serving.

    This function serves as the main entrypoint for Docker containers, handling
    different commands for model operations. Currently supports serving models
    for inference.

    Args:
        command: The command to execute ('serve' for model serving).
        model_id (str): Unique identifier for the model to be loaded.
        language (str): Programming language or model language specification.

    Raises:
        NotImplementedError: If the provided command is not implemented.

    Example:
        >>> _init('serve', 'bert-base-uncased', 'en')
        # Starts serving the specified model
    """
    # For Sagemaker, serve and train are the possible commands
    if command == "serve":
        model = ModelRegistry.find(model_id, language)
        serve(
            model=model,
            platform=TARGET_PLATFORM,
        )
    else:
        raise NotImplementedError("Command not implemented")


__all__ = [
    "build_docker_image",
    "generate_docker_files",
    "setup_container_env",
    "format_image_tag",
    "format_docker_image_name",
    "validate_docker_image_name",
    "validate_image_tag",
]
