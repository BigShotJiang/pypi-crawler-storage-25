"""Logging configuration and utilities for the endpoints package.

This module provides a centralized logging configuration for the endpoints package,
including a pre-configured logger instance and initialization functionality.
"""

import logging
import os

logger = logging.getLogger(__name__.split(".")[0])
logger.addHandler(logging.NullHandler())


def init_logging():
    """Initialize logging configuration for the endpoints package.

    Sets up basic logging configuration based on the LOG_LEVEL environment variable.
    The package logger will inherit the configured level from the root logger.

    Environment Variables:
        LOG_LEVEL (str): Desired log level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
                        Defaults to "INFO" if not set.
    """
    log_level = os.environ.get("LOG_LEVEL", "INFO").upper()
    logging.basicConfig(level=getattr(logging, log_level))


__all__ = ["logger", "init_logging"]
