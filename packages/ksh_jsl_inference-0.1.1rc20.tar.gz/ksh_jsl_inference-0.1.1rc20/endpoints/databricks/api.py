import requests
import json
import time
import base64
from enum import Enum
from typing import Optional, Dict, Any, List
import logging

logger = logging.getLogger(__name__)


class CloudProvider(Enum):
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    
    @staticmethod
    def detect(origin: str):
        """Detect cloud provider from instance URL"""
        if origin.endswith(".cloud.databricks.com"):
            return CloudProvider.AWS
        elif (
            origin.endswith(".azuredatabricks.net")
            or origin.endswith(".dev.databricks.com")
            or origin.endswith(".databricks.azure.us")
        ):
            return CloudProvider.AZURE
        elif origin.endswith(".gcp.databricks.com"):
            return CloudProvider.GCP
        else:
            return None
    
    @staticmethod
    def is_community(origin: str) -> bool:
        """Check if this is a community cloud instance"""
        return origin == "https://community.cloud.databricks.com"


class DatabricksAPI:
    """Core Databricks API client"""
    
    def __init__(self, instance_url: str, access_token: str):
        """
        Initialize Databricks API client
        
        Args:
            instance_url: Databricks workspace URL (e.g., https://xxxxx.cloud.databricks.com)
            access_token: Personal access token for authentication
        """
        self.instance_url = instance_url.rstrip('/')
        self.access_token = access_token
        self.headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
    
    def _make_request(self, method: str, endpoint: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        """Make HTTP request to Databricks API"""
        url = f"{self.instance_url}{endpoint}"
        
        try:
            if method == "GET":
                response = requests.get(url, headers=self.headers)
            elif method == "POST":
                response = requests.post(url, headers=self.headers, json=data)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code in [401, 403]:
                raise Exception(f"Authentication error: {response.text}")
            elif 400 <= response.status_code < 500:
                raise Exception(f"Client error: {response.text}")
            else:
                raise Exception(f"Server error: {response.text}")
        
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request failed: {str(e)}")
    
    def detect_cloud_provider(self) -> CloudProvider:
        """Detect cloud provider from instance URL"""
        provider = CloudProvider.detect(self.instance_url)
        if provider is None:
            raise Exception("Could not detect cloud provider from URL")
        return provider
    
    # Cluster operations
    def list_clusters(self) -> list:
        """List all active clusters"""
        response = self._make_request("GET", "/api/2.1/clusters/list")
        return response.get("clusters", [])
    
    def get_cluster(self, cluster_id: str) -> Dict[str, Any]:
        """Get cluster details"""
        return self._make_request("GET", f"/api/2.1/clusters/get?cluster_id={cluster_id}")
    
    def create_cluster(self, cluster_config: Dict[str, Any]) -> str:
        """Create a new cluster"""
        response = self._make_request("POST", "/api/2.1/clusters/create", cluster_config)
        cluster_id = response.get("cluster_id")
        logger.info(f"Cluster created: {cluster_id}")
        return cluster_id
    
    def start_cluster(self, cluster_id: str) -> None:
        """Start a stopped cluster"""
        try:
            self._make_request("POST", "/api/2.1/clusters/start", {"cluster_id": cluster_id})
            logger.info(f"Cluster started: {cluster_id}")
        except Exception as e:
            if "Cannot transition from Running to Running" in str(e):
                logger.info(f"Cluster already running: {cluster_id}")
            else:
                raise
    
    def restart_cluster(self, cluster_id: str) -> None:
        """Restart a running cluster"""
        self._make_request("POST", "/api/2.1/clusters/restart", {"cluster_id": cluster_id})
        logger.info(f"Cluster restarted: {cluster_id}")
    
    def edit_cluster(self, cluster_config: Dict[str, Any]) -> None:
        """Edit cluster configuration"""
        self._make_request("POST", "/api/2.1/clusters/edit", cluster_config)
        logger.info(f"Cluster configuration updated: {cluster_config.get('cluster_id')}")
    
    # Library operations
    def install_libraries(self, cluster_id: str, libraries: List[Dict]) -> None:
        """Install libraries to cluster"""
        if not libraries:
            logger.info("No libraries to install")
            return
        
        self._make_request("POST", "/api/2.0/libraries/install", {
            "cluster_id": cluster_id,
            "libraries": libraries
        })
        logger.info(f"Libraries installation initiated for cluster: {cluster_id}")
    
    def get_library_statuses(self, cluster_id: str) -> List[Dict[str, Any]]:
        """Get library installation statuses for a cluster"""
        response = self._make_request("GET", f"/api/2.0/libraries/cluster-status?cluster_id={cluster_id}")
        return response.get("library_statuses", [])
    
    def get_all_cluster_library_statuses(self) -> List[Dict[str, Any]]:
        """Get the status of all libraries on all clusters"""
        response = self._make_request("GET", "/api/2.0/libraries/all-cluster-statuses")
        return response.get("statuses", [])
    
    def uninstall_libraries(self, cluster_id: str, libraries: List[Dict]) -> None:
        """Uninstall libraries from cluster (requires cluster restart)"""
        if not libraries:
            logger.info("No libraries to uninstall")
            return
        
        self._make_request("POST", "/api/2.0/libraries/uninstall", {
            "cluster_id": cluster_id,
            "libraries": libraries
        })
        logger.info(f"Libraries uninstall initiated for cluster: {cluster_id}")
    
    # DBFS operations
    def create_file(self, source: str, target: str) -> None:
        """Upload a file from URL to DBFS"""
        try:
            # Create file handle
            handle = self._make_request("POST", "/api/2.0/dbfs/create", {
                "path": target,
                "overwrite": True
            })["handle"]
            
            # Download and upload in chunks
            response = requests.get(source, stream=True)
            if response.status_code != 200:
                raise Exception(f"Unable to download from {source}")
            
            for chunk in response.iter_content(chunk_size=1 << 20):  # 1MB chunks
                data = base64.b64encode(chunk).decode("ascii")
                self._make_request("POST", "/api/2.0/dbfs/add-block", {
                    "handle": handle,
                    "data": data
                })
            
            # Close file handle
            self._make_request("POST", "/api/2.0/dbfs/close", {"handle": handle})
            logger.info(f"Uploaded {source.rsplit('/', 1)[-1]} to {target}")
            
        except Exception as e:
            raise Exception(f"Failed to upload file: {str(e)}")
    
    # Workspace operations
    def create_workspace_directory(self, path: str) -> None:
        """Create workspace directory"""
        try:
            self._make_request("POST", "/api/2.0/workspace/mkdirs", {"path": path})
            logger.debug(f"Workspace directory created: {path}")
        except Exception as e:
            if "RESOURCE_ALREADY_EXISTS" in str(e):
                logger.debug(f"Workspace directory already exists: {path}")
            else:
                raise
    
    def create_notebook(self, path: str, content: str, language: str = "PYTHON", format: str = "JUPYTER") -> Dict[str, Any]:
        """Create a notebook in Databricks workspace"""
        self._make_request("POST", "/api/2.0/workspace/import", {
            "path": path,
            "format": format,
            "content": content,
            "language": language,
            "overwrite": True,
        })
        
        notebook_info = self._make_request("GET", f"/api/2.0/workspace/get-status?path={path}")
        result = {
            "id": notebook_info.get("object_id"),
            "path": path,
            "url": f"{self.instance_url}/#notebook/{notebook_info.get('object_id')}"
        }
        logger.info(f"Notebook created: {path}")
        return result
    
    # Job operations
    def create_job(self, job_params: Dict) -> str:
        """Create a job in Databricks"""
        response = self._make_request("POST", "/api/2.1/jobs/create", job_params)
        job_id = response.get("job_id")
        logger.info(f"Job created: {job_id}")
        return job_id
    
    def run_job(self, job_id: int, idempotency_token: str = None) -> int:
        """Run a Databricks job"""
        import uuid
        if not idempotency_token:
            idempotency_token = str(uuid.uuid4())
        
        response = self._make_request("POST", "/api/2.1/jobs/run-now", {
            "job_id": job_id,
            "idempotency_token": idempotency_token
        })
        run_id = response.get("run_id")
        logger.info(f"Job started with run ID: {run_id}")
        return run_id
    
    def get_job_run(self, run_id: int) -> Dict[str, Any]:
        """Get job run status"""
        return self._make_request("GET", f"/api/2.1/jobs/runs/get?run_id={run_id}")
    
    def delete_job(self, job_id: int) -> None:
        """Delete a job"""
        self._make_request("POST", "/api/2.1/jobs/delete", {"job_id": job_id})
        logger.info(f"Job deleted: {job_id}")
    
    # Cleanup operations
    def delete_workspace_object(self, path: str, recursive: bool = False) -> None:
        """Delete a workspace object (file/directory)"""
        try:
            self._make_request("POST", "/api/2.0/workspace/delete", {
                "path": path,
                "recursive": recursive
            })
            logger.info(f"Deleted workspace object: {path}")
        except Exception as e:
            if "RESOURCE_DOES_NOT_EXIST" in str(e):
                logger.debug(f"Workspace object already deleted or doesn't exist: {path}")
            else:
                logger.warning(f"Failed to delete workspace object {path}: {e}")
    
    def delete_dbfs_file(self, path: str, recursive: bool = False) -> None:
        """Delete a DBFS file or directory"""
        try:
            self._make_request("POST", "/api/2.0/dbfs/delete", {
                "path": path,
                "recursive": recursive
            })
            logger.info(f"Deleted DBFS file/directory: {path}")
        except Exception as e:
            if "NOT_FOUND" in str(e):
                logger.debug(f"DBFS file already deleted or doesn't exist: {path}")
            else:
                logger.warning(f"Failed to delete DBFS file {path}: {e}")
    
    def delete_cluster(self, cluster_id: str) -> None:
        """Permanently delete a cluster"""
        try:
            self._make_request("POST", "/api/2.1/clusters/permanent-delete", {
                "cluster_id": cluster_id
            })
            logger.info(f"Deleted cluster: {cluster_id}")
        except Exception as e:
            if "does not exist" in str(e).lower() or "INVALID_STATE" in str(e):
                logger.debug(f"Cluster already deleted or in invalid state: {cluster_id}")
            else:
                logger.warning(f"Failed to delete cluster {cluster_id}: {e}")