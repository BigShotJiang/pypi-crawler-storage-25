import requests
import base64
import time
import os
import argparse
import sys
import yaml

sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from databricks.api import DatabricksAPI
from databricks.tasks import NotebookExecutionManager


def parse_arguments():
    parser = argparse.ArgumentParser("Marketplace Notebook Sync")
    parser.add_argument("--databricks-host", default=os.environ.get("DATABRICKS_HOST"))
    parser.add_argument("--databricks-token", default=os.environ.get("DATABRICKS_TOKEN"))
    parser.add_argument("--model-name", required=True)
    parser.add_argument("--marketplace-notebook-path", required=True)
    parser.add_argument("--metadata-path", required=True, help="Path to metadata.yaml file")
    return parser.parse_args()


def extract_listing_id_from_metadata(metadata_path):
    """
    Extract the Databricks listing ID from the metadata.yaml file.
    
    Args:
        metadata_path: Path to the metadata.yaml file
        
    Returns:
        The listing ID as a string
        
    Raises:
        FileNotFoundError: If metadata file doesn't exist
        KeyError: If listing_url is not found in metadata
        ValueError: If listing ID cannot be extracted from URL
    """
    if not os.path.exists(metadata_path):
        raise FileNotFoundError(f"Metadata file not found: {metadata_path}")
    
    with open(metadata_path, 'r') as f:
        metadata = yaml.safe_load(f)
    
    # Navigate to databricks.listing_url
    if 'platforms' not in metadata:
        raise KeyError("'platforms' key not found in metadata.yaml")
    
    if 'databricks' not in metadata['platforms']:
        raise KeyError("'databricks' key not found under 'platforms' in metadata.yaml")
    
    listing_url = metadata['platforms']['databricks'].get('listing_url')
    
    if not listing_url:
        raise KeyError("'listing_url' not found under 'platforms.databricks' in metadata.yaml")
    
    # Extract listing ID from URL
    # Expected format: https://marketplace.databricks.com/details/cad4df89-187f-47eb-8a37-0ad256068b38/...
    try:
        url_parts = listing_url.split('/details/')
        if len(url_parts) < 2:
            raise ValueError(f"Invalid listing URL format: {listing_url}")
        
        # Get the ID part (between '/details/' and the next '/')
        id_part = url_parts[1].split('/')[0]
        
        if not id_part:
            raise ValueError(f"Could not extract listing ID from URL: {listing_url}")
        
        return id_part
    except Exception as e:
        raise ValueError(f"Failed to extract listing ID from URL '{listing_url}': {str(e)}")


def wait_for_publish(host, headers, file_id, timeout=600):
    status_url = f"{host}/api/2.0/marketplace-provider/files/{file_id}"
    start = time.time()

    while time.time() - start < timeout:
        resp = requests.get(status_url, headers=headers)
        resp.raise_for_status()

        info = resp.json()["file_info"]
        status = info["status"]
        print("Marketplace file status:", status)

        if status == "FILE_STATUS_PUBLISHED":
            return

        if status == "FILE_STATUS_SANITIZATION_FAILED":
            raise RuntimeError(info.get("status_message"))

        time.sleep(10)

    raise TimeoutError("Timed out waiting for marketplace publish")


def export_workspace_notebook(host, headers, workspace_path):
    export_url = f"{host}/api/2.0/workspace/export"

    resp = requests.get(
        export_url,
        headers=headers,
        params={
            "path": workspace_path,
            "format": "HTML"
        }
    )
    resp.raise_for_status()

    return base64.b64decode(resp.json()["content"])


def main():
    args = parse_arguments()

    DATABRICKS_HOST = args.databricks_host
    TOKEN = args.databricks_token
    MODEL_NAME = args.model_name
    LOCAL_NOTEBOOK_PATH = args.marketplace_notebook_path
    METADATA_PATH = args.metadata_path

    if not DATABRICKS_HOST or not TOKEN:
        raise RuntimeError("Databricks host and token are required")

    if not os.path.exists(LOCAL_NOTEBOOK_PATH):
        raise FileNotFoundError(f"Marketplace notebook not found: {LOCAL_NOTEBOOK_PATH}")

    # Extract listing ID from metadata.yaml
    print(f"Reading metadata from: {METADATA_PATH}")
    try:
        LISTING_ID = extract_listing_id_from_metadata(METADATA_PATH)
        print(f"Extracted Listing ID: {LISTING_ID}")
    except Exception as e:
        raise RuntimeError(f"Failed to extract listing ID: {str(e)}")

    # Init API + manager
    api = DatabricksAPI(DATABRICKS_HOST, TOKEN)
    notebook_manager = NotebookExecutionManager(api)

    HEADERS = {
        "Authorization": f"Bearer {TOKEN}"
    }

    # 1. Upload marketplace notebook to workspace
    notebook_manager.upload_marketplace_notebook(
        notebook_path=LOCAL_NOTEBOOK_PATH,
        model_name=MODEL_NAME
    )

    workspace_notebook_path = f"/Shared/marketplace-notebooks/{MODEL_NAME}"
    print("Marketplace notebook uploaded to:", workspace_notebook_path)

    # 2. Export workspace notebook to HTML
    html_content = export_workspace_notebook(
        DATABRICKS_HOST,
        HEADERS,
        workspace_notebook_path
    )
    print("Workspace notebook exported to HTML")

    # 3. Create marketplace embedded notebook
    create_file_url = f"{DATABRICKS_HOST}/api/2.0/marketplace-provider/files"

    payload = {
        "display_name": MODEL_NAME,
        "file_parent": {
            "file_parent_type": "LISTING",
            "parent_id": LISTING_ID
        },
        "marketplace_file_type": "EMBEDDED_NOTEBOOK",
        "mime_type": "text/html"
    }

    resp = requests.post(create_file_url, headers=HEADERS, json=payload)
    resp.raise_for_status()

    create_resp = resp.json()
    file_id = create_resp["file_info"]["id"]
    upload_url = create_resp["upload_url"]

    # 4. Upload HTML to marketplace storage
    upload_headers = {
        "X-Amz-Server-Side-Encryption": "AES256",
        "Content-Type": "text/html"
    }

    requests.put(upload_url, headers=upload_headers, data=html_content).raise_for_status()
    print("HTML uploaded to marketplace storage")

    # 5. Wait for publish
    wait_for_publish(DATABRICKS_HOST, HEADERS, file_id)

    # 6. Update listing
    get_listing_url = f"{DATABRICKS_HOST}/api/2.0/marketplace-provider/listings/{LISTING_ID}"
    listing_payload = requests.get(get_listing_url, headers=HEADERS).json()["listing"]

    listing_payload["detail"]["embedded_notebook_file_infos"] = [{"id": file_id}]
    listing_payload.pop("id", None)

    update_listing_url = f"{DATABRICKS_HOST}/api/2.0/marketplace-provider/listings/{LISTING_ID}"
    requests.put(
        update_listing_url,
        headers=HEADERS,
        json={"listing": listing_payload}
    ).raise_for_status()

    print("Marketplace listing updated successfully")


if __name__ == "__main__":
    main()
