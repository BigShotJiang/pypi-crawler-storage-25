import json
import logging
import sys
import os
import argparse

# Add the endpoints directory to the path so we can import from it
sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from databricks.api import DatabricksAPI
from databricks.tasks import (
    DatabricksClusterManager, 
    JSLLibraryManager, 
    NotebookExecutionManager,
    ResourceTracker,
    CleanupManager
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('databricks_model_deployment.log', encoding='utf-8')
    ]
)

logger = logging.getLogger(__name__)


def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='Databricks Model Deployment and Creation')
    
    parser.add_argument('--databricks-url', default='', help='Databricks workspace URL (can also use DATABRICKS_HOST env var)')
    parser.add_argument('--databricks-token', default='', help='Databricks access token (can also use DATABRICKS_TOKEN env var)')
    parser.add_argument('--license-file', required=True, help='Path to the license JSON file')
    parser.add_argument('--notebook-path', required=True, help='Path to the create notebook file to execute')
    parser.add_argument('--model-name', required=True, help='Model name (e.g., nlu_ref parameter)')
    parser.add_argument('--healthcare-secret', nargs='?', default='', help='Healthcare NLP secret (optional)')
    parser.add_argument('--visual-secret', nargs='?', default='', help='Visual NLP secret (optional)')
    parser.add_argument('--jsl-version', nargs='?', default='6.1.0', help='John Snow Labs version')
    parser.add_argument('--spark-nlp-version', nargs='?', default='6.1.1', help='Spark NLP version')
    parser.add_argument('--cluster-name', default='jsl-cluster', help='Cluster name to create/use')
    parser.add_argument('--visual-version', nargs='?', default='6.1.0', help='Visual NLP version (optional)')
    
    return parser.parse_args()


def main():
    """Main function for Databricks model deployment"""
    # Parse command line arguments
    args = parse_arguments()
    
    # Load license file
    with open(args.license_file) as f:
        license = json.load(f)
    
    # Configuration from arguments or environment variables
    DATABRICKS_URL = args.databricks_url or os.environ.get('DATABRICKS_HOST')
    DATABRICKS_TOKEN = args.databricks_token or os.environ.get('DATABRICKS_TOKEN')
    
    # Validate required parameters
    if not DATABRICKS_URL:
        logger.error("Databricks URL is required. Provide --databricks-url or set DATABRICKS_HOST environment variable.")
        return False
    
    if not DATABRICKS_TOKEN:
        logger.error("Databricks token is required. Provide --databricks-token or set DATABRICKS_TOKEN environment variable.")
        return False
    
    JSL_VERSION = args.jsl_version
    SPARK_NLP_VERSION = args.spark_nlp_version
    NOTEBOOK_PATH = args.notebook_path
    MODEL_NAME = args.model_name
    LICENSE_FILE_PATH = args.license_file
    CLUSTER_NAME = args.cluster_name
    
    # Derive model name from notebook path if not provided
    if args.model_name:
        MODEL_NAME = args.model_name
    else:
        # Extract model name from notebook path (e.g., "create_en.explain_doc.clinical_radiology.pipeline.ipynb" -> "en.explain_doc.clinical_radiology.pipeline")
        notebook_filename = os.path.basename(NOTEBOOK_PATH)
        if notebook_filename.startswith('create_') and notebook_filename.endswith('.ipynb'):
            MODEL_NAME = notebook_filename[7:-6]  # Remove "create_" prefix and ".ipynb" suffix
        else:
            MODEL_NAME = notebook_filename.replace('.ipynb', '')
    
    # License and secrets
    SPARK_NLP_LICENSE = license["SPARK_NLP_LICENSE"]
    HEALTHCARE_SECRET = args.healthcare_secret.strip() if args.healthcare_secret.strip() else None
    VISUAL_SECRET = args.visual_secret.strip() if args.visual_secret.strip() else None
    VISUAL_VERSION = args.visual_version
    
    # Initialize resource tracking and managers
    resource_tracker = ResourceTracker()
    api = DatabricksAPI(DATABRICKS_URL, DATABRICKS_TOKEN)
    cluster_manager = DatabricksClusterManager(DATABRICKS_URL, DATABRICKS_TOKEN, resource_tracker)
    library_manager = JSLLibraryManager(api, resource_tracker)
    notebook_manager = NotebookExecutionManager(api, resource_tracker)
    cleanup_manager = CleanupManager(api, resource_tracker)
    
    # Validate required parameters
    if not DATABRICKS_TOKEN:
        logger.error("DATABRICKS_TOKEN is empty or None!")
        return False
    
    # Log configuration
    logger.info("=== Databricks Model Deployment Configuration ===")
    logger.info(f"Databricks URL: {DATABRICKS_URL}")
    logger.info(f"Model Name: {MODEL_NAME}")
    logger.info(f"Cluster Name: {CLUSTER_NAME}")
    logger.info(f"Create Model Notebook Path: {NOTEBOOK_PATH}")
    logger.info(f"Spark NLP Version: {SPARK_NLP_VERSION}")
    logger.info(f"JSL Version: {JSL_VERSION}")
    logger.info(f"Visual Version: {VISUAL_VERSION}")
    logger.info(f"Healthcare Secret: {'Set' if HEALTHCARE_SECRET else 'Not provided'}")
    logger.info(f"Visual Secret: {'Set' if VISUAL_SECRET else 'Not provided'}")
    logger.info("================================================")
    
    try:
        # Step 1: Get or create cluster
        logger.info("Setting up cluster...")
        cluster_id, cluster_was_created = cluster_manager.get_or_create_cluster(CLUSTER_NAME)
        logger.info(f"Using cluster: {cluster_id} ({'created' if cluster_was_created else 'existing'})")
        logger.info("Cluster will be reused and auto-terminate after inactivity")
        
        # Step 2: Wait for cluster to be ready
        logger.info("Waiting for cluster to be ready...")
        if not cluster_manager.wait_for_cluster_ready(cluster_id):
            logger.error("Failed to start cluster")
            return False
        
        # Step 3: Modify cluster configuration
        logger.info("Modifying cluster configuration...")
        if not cluster_manager.modify_cluster_config(
            cluster_id=cluster_id,
            spark_nlp_license=SPARK_NLP_LICENSE,
            healthcare_secret=HEALTHCARE_SECRET,
            visual_secret=VISUAL_SECRET
        ):
            logger.error("Failed to modify cluster configuration")
            return False
        
        # Step 4: Install John Snow Labs libraries
        logger.info("Installing John Snow Labs libraries...")
        success = library_manager.install_libraries(
            cluster_id=cluster_id,
            spark_nlp_version=SPARK_NLP_VERSION,
            jsl_version=JSL_VERSION,
            visual_version=VISUAL_VERSION,
            healthcare_secret=HEALTHCARE_SECRET,
            visual_secret=VISUAL_SECRET,
            is_gpu=False
        )
        if success:
            logger.info("SUCCESS: Cluster is ready with John Snow Labs libraries installed.")
            logger.info(f"Cluster ID: {cluster_id}")
            logger.info("Cluster Configuration:")
            logger.info("  - Spark Serializer: KryoSerializer")
            logger.info("  - Kryo Buffer Max: 2000M")
            logger.info("  - ML Runtime: Enabled")
            logger.info("  - Auto-terminate: 120 minutes")
            
            # Step 5: Execute model notebook
            logger.info(f"Executing notebook: {NOTEBOOK_PATH}")
            notebook_success = notebook_manager.execute_notebook_from_path(
                cluster_id=cluster_id,
                notebook_path=NOTEBOOK_PATH,
                model_name=MODEL_NAME,
                license_file_path=LICENSE_FILE_PATH
            )
            
            if notebook_success:
                logger.info(f"SUCCESS: Model {MODEL_NAME} created successfully!")
                return True
            else:
                logger.error(f"Model notebook execution failed for {MODEL_NAME}")
                return False
        else:
            logger.error("Installation failed. Check the logs for details.")
            return False
    
    except Exception as e:
        logger.error(f"Error: {e}")
        return False
    
    finally:
        # Cleanup resources - preserve cluster for reuse
        try:
            logger.info("Starting cleanup process...")
            cleanup_manager.cleanup_all(delete_clusters=False)
            logger.info("Cleanup completed (cluster preserved for reuse)")
        except Exception as cleanup_error:
            logger.error(f"Error during cleanup: {cleanup_error}")


if __name__ == "__main__":
    try:
        success = main()
        exit(0 if success else 1)
    except KeyboardInterrupt:
        logger.info("Script interrupted by user")
        exit(1)
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        exit(1)