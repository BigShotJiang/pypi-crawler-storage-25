import time
import logging
import os
import base64
from typing import Optional, Dict, Any, List
from .api import DatabricksAPI, CloudProvider

logger = logging.getLogger(__name__)


class ResourceTracker:
    """Track created resources for cleanup"""
    
    def __init__(self):
        self.workspace_files = []
        self.dbfs_files = []
        self.clusters = []
        self.workspace_dirs = []
    
    def add_workspace_file(self, path: str):
        """Track a workspace file for cleanup"""
        self.workspace_files.append(path)
        logger.debug(f"Tracking workspace file: {path}")
    
    def add_dbfs_file(self, path: str):
        """Track a DBFS file for cleanup"""
        self.dbfs_files.append(path)
        logger.debug(f"Tracking DBFS file: {path}")
    
    def add_cluster(self, cluster_id: str):
        """Track a cluster for cleanup"""
        self.clusters.append(cluster_id)
        logger.debug(f"Tracking cluster: {cluster_id}")
    
    def add_workspace_dir(self, path: str):
        """Track a workspace directory for cleanup"""
        self.workspace_dirs.append(path)
        logger.debug(f"Tracking workspace directory: {path}")


class CleanupManager:
    """Manage cleanup of Databricks resources"""
    
    def __init__(self, api: DatabricksAPI, resource_tracker: ResourceTracker):
        self.api = api
        self.tracker = resource_tracker
    
    def cleanup_all(self, delete_clusters: bool = True):
        """Clean up all tracked resources"""
        logger.info("Starting resource cleanup...")
        
        # Clean up workspace directories (tmp folders)
        for workspace_dir in self.tracker.workspace_dirs:
            try:
                logger.info(f"Deleting workspace directory: {workspace_dir}")
                self.api.delete_workspace_object(workspace_dir, recursive=True)
            except Exception as e:
                logger.warning(f"Failed to cleanup workspace directory {workspace_dir}: {e}")
        
        # Clean up workspace files (individual files if any)
        for workspace_file in self.tracker.workspace_files:
            try:
                self.api.delete_workspace_object(workspace_file)
            except Exception as e:
                logger.warning(f"Failed to cleanup workspace file {workspace_file}: {e}")
        
        # Clean up DBFS files (JAR/WHL files)
        for dbfs_file in self.tracker.dbfs_files:
            try:
                self.api.delete_dbfs_file(dbfs_file)
            except Exception as e:
                logger.warning(f"Failed to cleanup DBFS file {dbfs_file}: {e}")
        
        # Clean up clusters - preserve for reuse (they will auto-terminate)
        if delete_clusters:
            for cluster_id in self.tracker.clusters:
                try:
                    logger.info(f"Deleting cluster: {cluster_id}")
                    self.api.delete_cluster(cluster_id)
                except Exception as e:
                    logger.warning(f"Failed to delete cluster {cluster_id}: {e}")
        else:
            logger.info(f"Preserving {len(self.tracker.clusters)} cluster(s) for reuse (will auto-terminate after inactivity)")
        
        logger.info("Resource cleanup completed")


class DatabricksClusterManager:
    """High-level Databricks cluster management operations"""
    
    def __init__(self, instance_url: str, access_token: str, resource_tracker: ResourceTracker = None):
        """Initialize cluster manager with API client"""
        self.api = DatabricksAPI(instance_url, access_token)
        self.resource_tracker = resource_tracker
    
    def create_single_node_cluster(self, cluster_name: str, spark_version: str = "14.3.x-scala2.12") -> str:
        """Create a single-node cluster with ML runtime"""
        cloud_provider = self.api.detect_cloud_provider()
        
        cluster_config = {
            "cluster_name": cluster_name,
            "spark_version": spark_version,
            "num_workers": 0,
            "autotermination_minutes": 60,
            "kind": "CLASSIC_PREVIEW",
            "use_ml_runtime": True,
            "custom_tags": {
                "ResourceClass": "SingleNode"
            },
            "spark_conf": {
                "spark.databricks.cluster.profile": "singleNode",
                "spark.master": "local[*, 4]"
            }
        }
        
        # Add cloud-specific attributes
        if cloud_provider == CloudProvider.AWS:
            cluster_config.update({
                "node_type_id": "i3.xlarge",
                "data_security_mode": "SINGLE_USER",
                "aws_attributes": {
                    "availability": "ON_DEMAND",
                    "zone_id": "auto"
                }
            })
        elif cloud_provider == CloudProvider.AZURE:
            cluster_config.update({
                "node_type_id": "Standard_DS13_v2",
                "data_security_mode": "SINGLE_USER",
                "azure_attributes": {
                    "availability": "ON_DEMAND_AZURE"
                }
            })
        elif cloud_provider == CloudProvider.GCP:
            cluster_config.update({
                "node_type_id": "n1-highmem-8",
                "data_security_mode": "SINGLE_USER",
                "gcp_attributes": {
                    "availability": "ON_DEMAND_GCP"
                }
            })
        
        return self.api.create_cluster(cluster_config)
    
    def wait_for_cluster_ready(self, cluster_id: str, timeout: int = 600, poll_interval: int = 10) -> bool:
        """Wait for cluster to reach RUNNING state"""
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                cluster_info = self.api.get_cluster(cluster_id)
                state = cluster_info.get("state")
                logger.debug(f"Cluster {cluster_id} state: {state}")
                
                if state == "RUNNING":
                    logger.info(f"Cluster is ready: {cluster_id}")
                    return True
                elif state in ["TERMINATING", "TERMINATED"]:
                    logger.error(f"Cluster is in {state} state")
                    return False
                
                time.sleep(poll_interval)
            except Exception as e:
                logger.warning(f"Error checking cluster status: {e}")
                time.sleep(poll_interval)
        
        logger.error(f"Timeout waiting for cluster to be ready")
        return False
    
    def get_or_create_cluster(self, cluster_name: str) -> tuple[str, bool]:
        """
        Get existing cluster or create new single-node cluster
        
        Returns:
            tuple: (cluster_id, was_created)
        """
        # List existing clusters
        clusters = self.api.list_clusters()
        
        for cluster in clusters:
            if cluster.get("cluster_name") == cluster_name:
                cluster_id = cluster.get("cluster_id")
                state = cluster.get("state")
                logger.info(f"Found existing cluster: {cluster_id} (state: {state})")
                
                # Start if stopped
                if state not in ["RUNNING", "PENDING"]:
                    self.api.start_cluster(cluster_id)
                
                # Track cluster for cleanup
                if self.resource_tracker:
                    self.resource_tracker.add_cluster(cluster_id)
                
                return cluster_id, False  # Found existing, not created
        
        # Create new cluster if not found
        logger.info(f"Cluster '{cluster_name}' not found. Creating new cluster...")
        cluster_id = self.create_single_node_cluster(cluster_name)
        
        # Track cluster for cleanup
        if self.resource_tracker:
            self.resource_tracker.add_cluster(cluster_id)
        
        return cluster_id, True  # Created new cluster
    
    def modify_cluster_config(
        self,
        cluster_id: str,
        spark_nlp_license: Optional[str] = None,
        healthcare_secret: Optional[str] = None,
        visual_secret: Optional[str] = None
    ) -> bool:
        """Modify cluster configuration with Spark config and environment variables (only if needed)"""
        try:
            logger.info("Checking cluster configuration...")
            
            # Get current cluster info
            cluster_info = self.api.get_cluster(cluster_id)
            
            # Track if any changes are needed
            needs_update = False
            
            # Check Spark configuration
            required_spark_conf = {
                "spark.serializer": "org.apache.spark.serializer.KryoSerializer",
                "spark.kryoserializer.buffer.max": "2000M",
            }
            
            current_spark_conf = cluster_info.get("spark_conf", {})
            spark_conf_changes = {}
            
            for key, value in required_spark_conf.items():
                if current_spark_conf.get(key) != value:
                    spark_conf_changes[key] = value
                    needs_update = True
            
            if spark_conf_changes:
                logger.info(f"Spark config changes needed: {list(spark_conf_changes.keys())}")
                if "spark_conf" in cluster_info:
                    cluster_info["spark_conf"].update(spark_conf_changes)
                else:
                    cluster_info["spark_conf"] = spark_conf_changes
            else:
                logger.info("✓ Spark config already up to date")
            
            # Check environment variables
            current_env_vars = cluster_info.get("spark_env_vars", {})
            env_vars_to_add = {}
            
            if spark_nlp_license and current_env_vars.get("SPARK_NLP_LICENSE") != spark_nlp_license:
                env_vars_to_add["SPARK_NLP_LICENSE"] = spark_nlp_license
                needs_update = True
            
            if healthcare_secret and current_env_vars.get("HEALTHCARE_SECRET") != healthcare_secret:
                env_vars_to_add["HEALTHCARE_SECRET"] = healthcare_secret
                needs_update = True
            
            if visual_secret and current_env_vars.get("VISUAL_SECRET") != visual_secret:
                env_vars_to_add["VISUAL_SECRET"] = visual_secret
                needs_update = True
            
            if env_vars_to_add:
                logger.info(f"Environment variable changes needed: {list(env_vars_to_add.keys())}")
                current_env_vars.update(env_vars_to_add)
                cluster_info["spark_env_vars"] = current_env_vars
            else:
                logger.info("✓ Environment variables already up to date")
            
            # If no changes needed, return early
            if not needs_update:
                logger.info("✓ All cluster configuration already up to date - no modification needed!")
                return True
            
            # Changes are needed, proceed with modification
            logger.info("Applying cluster configuration changes...")
            
            # Clean up deprecated AWS attributes
            if "aws_attributes" in cluster_info:
                aws_attrs = cluster_info["aws_attributes"]
                deprecated_keys = [key for key in aws_attrs.keys() if key.startswith("ebs_")]
                for key in deprecated_keys:
                    aws_attrs.pop(key)
                if deprecated_keys:
                    logger.debug(f"Removed deprecated EBS attributes: {deprecated_keys}")
            
            # Handle instance pool configuration
            if "instance_pool_id" in cluster_info:
                for key in ["node_type_id", "driver_node_type_id", "enable_elastic_disk", "disk_spec", "aws_attributes"]:
                    cluster_info.pop(key, None)
                logger.debug("Removed node-specific attributes for instance pool")
            
            # Apply modifications
            self.api.edit_cluster(cluster_info)
            logger.info("✓ Cluster configuration updated successfully")
            
            return True
        
        except Exception as e:
            logger.error(f"Error during cluster configuration check/modification: {e}")
            return False

class JSLLibraryManager:
    """John Snow Labs library management operations"""
    
    def __init__(self, api: DatabricksAPI, resource_tracker: ResourceTracker = None):
        """Initialize with API client"""
        self.api = api
        self.resource_tracker = resource_tracker
    
    def library_sources(
        self,
        spark_nlp_version: str,
        jsl_version: Optional[str] = None,
        visual_version: Optional[str] = None,
        healthcare_secret: Optional[str] = None,
        visual_secret: Optional[str] = None,
        is_gpu: bool = False,
        format: str = "install"
    ) -> List[Dict[str, Any]]:
        """Generate library sources for installation"""
        LIBRARY_ROOT = "/FileStore/johnsnowlabs-marketplace/libs"
        use_s3 = CloudProvider.is_community(self.api.instance_url)
        
        def to_create_file(source: str):
            filename = source.rsplit("/", 1)[-1]
            return (source, f"{LIBRARY_ROOT}/{filename}")
        
        def to_install(source: str):
            ext = source.rsplit(".", 1)[-1]
            if use_s3:
                return {ext: source.replace("https://", "s3://")}
            else:
                filename = source.rsplit("/", 1)[-1]
                return {ext: f"dbfs:{LIBRARY_ROOT}/{filename}"}
        
        results = []
        
        if format == "install":
            # Base packages
            results.append({"pypi": {"package": f"johnsnowlabs-for-databricks=={jsl_version}" if jsl_version else "johnsnowlabs-for-databricks"}})
        
        # Healthcare NLP
        if jsl_version and healthcare_secret:
            jar = f"https://pypi.johnsnowlabs.com/{healthcare_secret}/spark-nlp-jsl-{jsl_version}.jar"
            whl = f"https://pypi.johnsnowlabs.com/{healthcare_secret}/spark-nlp-jsl/spark_nlp_jsl-{jsl_version}-py3-none-any.whl"
            if format == "install":
                results.append(to_install(jar))
                results.append(to_install(whl))
            elif format == "create_file" and not use_s3:
                results.append(to_create_file(jar))
                results.append(to_create_file(whl))
        
        # Visual NLP
        if visual_version and visual_secret:
            jar = f"https://pypi.johnsnowlabs.com/{visual_secret}/jars/spark-ocr-assembly-{visual_version}.jar"
            whl = f"https://pypi.johnsnowlabs.com/{visual_secret}/spark-ocr/spark_ocr-{visual_version}-py3-none-any.whl"
            if format == "install":
                results.append(to_install(jar))
                results.append(to_install(whl))
            elif format == "create_file" and not use_s3:
                results.append(to_create_file(jar))
                results.append(to_create_file(whl))
        
        # Spark NLP (always at the end)
        if format == "install":
            results.append({"pypi": {"package": f"spark-nlp=={spark_nlp_version}"}})
            package_name = "spark-nlp-gpu" if is_gpu else "spark-nlp"
            scala_version = "2.12"
            results.append({
                "maven": {
                    "coordinates": f"com.johnsnowlabs.nlp:{package_name}_{scala_version}:{spark_nlp_version}"
                }
            })

            results.append({"pypi": {"package": "numpy==1.24.3"}})
            results.append({"pypi": {"package": "lxml==4.9.1"}})
            results.append({"pypi": {"package": "pandas==1.5.3"}})
            results.append({"pypi": {"package": "tensorflow==2.12.0"}})
            results.append({"pypi": {"package": "tensorflow-addons==0.20.0"}})

        
        return results
    
    def check_library_status(
        self,
        cluster_id: str,
        libraries: List[Dict[str, Any]],
        timeout: int = 1800,
        poll_interval: int = 30
    ) -> bool:
        """Check library installation status"""
        start_time = time.time()
        
        def get_lib_key(lib: Dict[str, Any]) -> str:
            """Generate a unique key for a library"""
            if "pypi" in lib:
                return f"pypi:{lib['pypi']['package']}"
            elif "maven" in lib:
                return f"maven:{lib['maven']['coordinates']}"
            elif "jar" in lib:
                return f"jar:{lib['jar']}"
            elif "whl" in lib:
                return f"whl:{lib['whl']}"
            else:
                return str(lib)
        
        expected_libs = {get_lib_key(lib) for lib in libraries}
        installed_libs = set()
        failed_libs = set()
        
        while time.time() - start_time < timeout:
            try:
                statuses = self.api.get_library_statuses(cluster_id)
                
                if not statuses:
                    logger.debug(f"Waiting for library status... ({int(time.time() - start_time)}s)")
                    time.sleep(poll_interval)
                    continue
                
                any_pending = False
                any_failed = False
                
                for status in statuses:
                    lib_status = status.get("status", "UNKNOWN")
                    library = status.get("library", {})
                    
                    # Generate key for this library
                    lib_key = None
                    if "pypi" in library:
                        lib_key = f"pypi:{library['pypi'].get('package', '')}"
                    elif "maven" in library:
                        lib_key = f"maven:{library['maven'].get('coordinates', '')}"
                    elif "jar" in library:
                        lib_key = f"jar:{library['jar']}"
                    elif "whl" in library:
                        lib_key = f"whl:{library['whl']}"
                    
                    if lib_key and lib_key in expected_libs:
                        if lib_status == "INSTALLED":
                            if lib_key not in installed_libs:
                                logger.info(f"Library installed: {lib_key}")
                                installed_libs.add(lib_key)
                        elif lib_status == "INSTALLING":
                            any_pending = True
                        elif lib_status == "FAILED":
                            if lib_key not in failed_libs:
                                logger.error(f"Library failed: {lib_key}")
                                failed_libs.add(lib_key)
                            any_failed = True
                        elif lib_status in ["PENDING", "RESOLVING"]:
                            any_pending = True
                
                # Check if all expected libraries are installed
                if installed_libs == expected_libs:
                    logger.info("All libraries installed successfully!")
                    return True
                
                if any_failed and failed_libs:
                    logger.error(f"Some libraries failed to install: {failed_libs}")
                    return False
                
                if any_pending:
                    remaining = expected_libs - installed_libs - failed_libs
                    logger.debug(f"Waiting for libraries to install... ({int(time.time() - start_time)}s, {len(remaining)} remaining)")
                    time.sleep(poll_interval)
                else:
                    # No pending libraries but not all installed - might be in transition
                    remaining = expected_libs - installed_libs - failed_libs
                    if remaining:
                        logger.debug(f"Waiting for library status update... ({int(time.time() - start_time)}s, {len(remaining)} remaining)")
                    time.sleep(poll_interval)
                    
            except Exception as e:
                logger.warning(f"Error checking library status: {e}")
                time.sleep(poll_interval)
        
        logger.error("Timeout waiting for libraries to install")
        return False
    
    def get_installed_libraries(self, cluster_id: str) -> Dict[str, Any]:
        """Get all currently installed libraries on the cluster"""
        try:
            statuses = self.api.get_library_statuses(cluster_id)
            installed = {}
            
            for status in statuses:
                lib_status = status.get("status", "")
                library = status.get("library", {})
                
                # Only consider successfully installed libraries
                if lib_status == "INSTALLED":
                    if "pypi" in library:
                        package = library["pypi"].get("package", "")
                        installed[f"pypi:{package}"] = library
                    elif "maven" in library:
                        coords = library["maven"].get("coordinates", "")
                        installed[f"maven:{coords}"] = library
                    elif "jar" in library:
                        jar_path = library["jar"]
                        installed[f"jar:{jar_path}"] = library
                    elif "whl" in library:
                        whl_path = library["whl"]
                        installed[f"whl:{whl_path}"] = library
            
            return installed
        except Exception as e:
            logger.warning(f"Could not get installed libraries: {e}")
            return {}
    
    def filter_missing_libraries(
        self, 
        required_libraries: List[Dict[str, Any]], 
        installed_libraries: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Filter out libraries that are already installed"""
        missing = []
        
        for lib in required_libraries:
            lib_key = None
            
            if "pypi" in lib:
                package = lib["pypi"]["package"]
                lib_key = f"pypi:{package}"
            elif "maven" in lib:
                coords = lib["maven"]["coordinates"]
                lib_key = f"maven:{coords}"
            elif "jar" in lib:
                jar_path = lib["jar"]
                lib_key = f"jar:{jar_path}"
            elif "whl" in lib:
                whl_path = lib["whl"]
                lib_key = f"whl:{whl_path}"
            
            if lib_key:
                if lib_key not in installed_libraries:
                    missing.append(lib)
                    logger.debug(f"Missing library: {lib_key}")
                else:
                    logger.debug(f"Already installed: {lib_key}")
        
        return missing
    
    def install_libraries(
        self,
        cluster_id: str,
        spark_nlp_version: str,
        jsl_version: Optional[str] = None,
        visual_version: Optional[str] = None,
        healthcare_secret: Optional[str] = None,
        visual_secret: Optional[str] = None,
        is_gpu: bool = False
    ) -> bool:
        """Install John Snow Labs libraries (only missing ones)"""
        try:
            logger.info("Checking John Snow Labs library installation status...")
            
            # Generate library configurations
            required_libraries = self.library_sources(
                spark_nlp_version=spark_nlp_version,
                jsl_version=jsl_version,
                visual_version=visual_version,
                healthcare_secret=healthcare_secret,
                visual_secret=visual_secret,
                is_gpu=is_gpu,
                format="install"
            )
            
            logger.info(f"Total required libraries: {len(required_libraries)}")
            
            # Check what's already installed
            installed_libraries = self.get_installed_libraries(cluster_id)
            logger.info(f"Currently installed libraries: {len(installed_libraries)}")
            
            # Filter out already installed libraries
            missing_libraries = self.filter_missing_libraries(required_libraries, installed_libraries)
            
            if not missing_libraries:
                logger.info("✓ All required libraries are already installed!")
                return True
            
            logger.info(f"Missing libraries to install: {len(missing_libraries)}")
            
            # Upload library files to DBFS (if not community cloud)
            if not CloudProvider.is_community(self.api.instance_url):
                files_to_upload = self.library_sources(
                    spark_nlp_version=spark_nlp_version,
                    jsl_version=jsl_version,
                    visual_version=visual_version,
                    healthcare_secret=healthcare_secret,
                    visual_secret=visual_secret,
                    is_gpu=is_gpu,
                    format="create_file"
                )
                
                if files_to_upload:
                    logger.info("Uploading library files to DBFS...")
                    for source, target in files_to_upload:
                        self.api.create_file(source, target)
                        # Track uploaded files for cleanup
                        if self.resource_tracker:
                            self.resource_tracker.add_dbfs_file(target)
                    logger.info(f"Uploaded {len(files_to_upload)} files to DBFS")
            
            # Install only missing libraries
            logger.info(f"Installing {len(missing_libraries)} missing libraries to cluster...")
            self.api.install_libraries(cluster_id, missing_libraries)
            
            # Wait for library installation to complete
            logger.info("Waiting for library installation to complete...")
            success = self.check_library_status(cluster_id, missing_libraries)
            
            if success:
                logger.info("✓ John Snow Labs library installation completed successfully!")
            else:
                logger.error("Library installation failed or timed out")
            
            return success
            
        except Exception as e:
            logger.error(f"Error during library installation: {e}")
            return False


class NotebookExecutionManager:
    """Notebook execution and job management operations"""
    
    def __init__(self, api: DatabricksAPI, resource_tracker: ResourceTracker = None):
        """Initialize with API client"""
        self.api = api
        self.resource_tracker = resource_tracker
    
    def find_model_notebook(self, model_name: str, base_path: str = "endpoints/models") -> Optional[str]:
        """Find the create notebook for a given model"""
        model_path = os.path.join(base_path, model_name, "databricks", f"create_{model_name}.ipynb")
        if os.path.exists(model_path):
            logger.info(f"Found notebook for model {model_name}: {model_path}")
            return model_path
        else:
            logger.error(f"Notebook not found for model {model_name} at {model_path}")
            return None
    
    def upload_notebook_from_file(self, local_path: str, workspace_path: str) -> Dict[str, Any]:
        """Upload a notebook file to Databricks workspace"""
        try:
            # Read the notebook file
            with open(local_path, 'r', encoding='utf-8') as f:
                notebook_content = f.read()
            
            # Encode as base64
            content_b64 = base64.b64encode(notebook_content.encode('utf-8')).decode('utf-8')
            
            # Upload to workspace
            result = self.api.create_notebook(workspace_path, content_b64)
            logger.info(f"Uploaded notebook from {local_path} to {workspace_path}")
            return result
            
        except Exception as e:
            logger.error(f"Failed to upload notebook: {e}")
            raise
    
    def upload_license_file(self, local_path: str, workspace_path: str) -> None:
        """Upload a license file to Databricks workspace"""
        try:
            # Read the license file
            with open(local_path, 'r', encoding='utf-8') as f:
                license_content = f.read()
            
            # Encode as base64
            content_b64 = base64.b64encode(license_content.encode('utf-8')).decode('utf-8')
            
            # Upload to workspace as a file
            self.api._make_request("POST", "/api/2.0/workspace/import", {
                "path": workspace_path,
                "format": "AUTO",
                "content": content_b64,
                "overwrite": True,
            })
            
            logger.info(f"Uploaded license file from {local_path} to {workspace_path}")
            
        except Exception as e:
            logger.error(f"Failed to upload license file: {e}")
            raise
    
    def create_notebook_job(self, cluster_id: str, notebook_path: str, job_name: str) -> str:
        """Create a job to run a notebook"""
        job_params = {
            "name": job_name,
            "existing_cluster_id": cluster_id,
            "notebook_task": {
                "notebook_path": notebook_path
            },
            "timeout_seconds": 3600,  # 1 hour timeout
        }
        
        return self.api.create_job(job_params)
    
    def wait_for_job_completion(self, run_id: int, timeout: int = 3600, poll_interval: int = 30) -> bool:
        """Wait for job to complete"""
        start_time = time.time()
        final_states = ["TERMINATED", "SKIPPED", "INTERNAL_ERROR"]
        
        while time.time() - start_time < timeout:
            try:
                run_status = self.api.get_job_run(run_id)
                state_info = run_status.get("state", {})
                life_cycle_state = state_info.get("life_cycle_state")
                result_state = state_info.get("result_state")
                
                logger.debug(f"Job run {run_id} state: {life_cycle_state}")
                
                if life_cycle_state in final_states:
                    if result_state == "SUCCESS":
                        logger.info(f"Job completed successfully: {run_id}")
                        return True
                    elif result_state == "FAILED":
                        state_message = state_info.get("state_message", "")
                        logger.error(f"Job failed: {state_message}")
                        logger.error(f"Run URL: {run_status.get('run_page_url')}")
                        return False
                    else:
                        logger.error(f"Job ended with state: {result_state}")
                        return False
                
                time.sleep(poll_interval)
            except Exception as e:
                logger.warning(f"Error checking job status: {e}")
                time.sleep(poll_interval)
        
        logger.error("Timeout waiting for job to complete")
        return False
    
    def execute_model_notebook(self, cluster_id: str, model_name: str, license_file_path: str, base_path: str = "endpoints/models") -> bool:
        """Execute the create notebook for a given model"""
        try:
            logger.info(f"Starting notebook execution for model: {model_name}")
            
            # Find the notebook
            local_notebook_path = self.find_model_notebook(model_name, base_path)
            if not local_notebook_path:
                return False
            
            return self.execute_notebook_from_path(cluster_id, local_notebook_path, model_name, license_file_path)
            
        except Exception as e:
            logger.error(f"Error during notebook execution: {e}")
            return False
    
    def upload_marketplace_notebook(self, notebook_path: str, model_name: str) -> Optional[Dict[str, Any]]:
        """Upload a marketplace notebook to Databricks workspace (without executing)"""
        try:
            if not os.path.exists(notebook_path):
                logger.warning(f"Marketplace notebook not found at {notebook_path}, skipping upload")
                return None
            
            logger.info(f"Uploading marketplace notebook from path: {notebook_path}")
            
            # Create marketplace directory (not in tmp)
            self.api.create_workspace_directory("/Shared/marketplace-notebooks")
            
            # Upload marketplace notebook (permanent location)
            marketplace_workspace_path = f"/Shared/marketplace-notebooks/{model_name}"
            notebook_info = self.upload_notebook_from_file(notebook_path, marketplace_workspace_path)
            
            logger.info(f"Marketplace notebook uploaded successfully to {marketplace_workspace_path}")
            logger.info(f"Marketplace Notebook URL: {notebook_info.get('url', 'N/A')}")
            
            return notebook_info
            
        except Exception as e:
            logger.error(f"Error uploading marketplace notebook: {e}")
            return None
    
    def execute_notebook_from_path(
        self, 
        cluster_id: str, 
        notebook_path: str, 
        model_name: str, 
        license_file_path: str,
    ) -> bool:
        """Execute a notebook from a given file path"""
        try:
            logger.info(f"Executing notebook from path: {notebook_path}")
            
            # Create tmp directory structure for this model
            tmp_base_path = "/Shared/marketplace-notebooks/tmp"
            model_tmp_path = f"{tmp_base_path}/{model_name}"
            
            # Create directories
            self.api.create_workspace_directory(tmp_base_path)
            self.api.create_workspace_directory(model_tmp_path)
            
            # Track the model's tmp directory for cleanup
            if self.resource_tracker:
                self.resource_tracker.add_workspace_dir(model_tmp_path)
            
            # Upload notebook to tmp directory
            workspace_path = f"{model_tmp_path}/create_{model_name}"
            notebook_info = self.upload_notebook_from_file(notebook_path, workspace_path)
            logger.info(f"Uploaded execution notebook to: {workspace_path}")
            
            # Upload license file to the tmp directory
            license_workspace_path = f"{model_tmp_path}/license.json"
            self.upload_license_file(license_file_path, license_workspace_path)
            logger.info(f"Uploaded license file to: {license_workspace_path}")
                        
            # Create and run job
            job_name = f"Create Model - {model_name}"
            job_id = self.create_notebook_job(cluster_id, workspace_path, job_name)
            
            # Run the job
            run_id = self.api.run_job(job_id)
            
            # Wait for completion
            logger.info("Waiting for notebook execution to complete...")
            success = self.wait_for_job_completion(run_id)
            
            if success:
                logger.info(f"Model notebook execution completed successfully for {model_name}")
                logger.info(f"Execution Notebook URL: {notebook_info['url']}")
            else:
                logger.error(f"Model notebook execution failed for {model_name}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error during notebook execution: {e}")
            return False