# Single source of truth for the IXX version.
# Import this from __main__.py and shell/repl.py — never hardcode VERSION elsewhere.
VERSION      = "0.6.3.0"
RELEASE_DATE = "2026-04-24"
