#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <x264.h>

typedef struct spiral_x264_encoder_t {
    x264_t *encoder;
    x264_picture_t picture_in;
    FILE *output;
    uint8_t *header_bytes;
    int header_len;
    int width;
    int height;
    int frame_size;
    x264_spiral_frame_props_t **frame_props;
    size_t frame_props_len;
    size_t frame_props_cap;
} spiral_x264_encoder_t;

static char SPIRAL_X264_LAST_ERROR[1024];

static void spiral_x264_set_error(const char *format, ...) {
    va_list args;
    va_start(args, format);
    vsnprintf(SPIRAL_X264_LAST_ERROR, sizeof(SPIRAL_X264_LAST_ERROR), format, args);
    va_end(args);
}

const char *spiral_x264_last_error(void) { return SPIRAL_X264_LAST_ERROR; }

static int spiral_x264_parse_param(x264_param_t *param, const char *name, const char *value) {
    if (!value || !value[0]) {
        return 0;
    }
    int rc = x264_param_parse(param, name, value);
    if (rc < 0) {
        spiral_x264_set_error("x264 rejected parameter %s=%s", name, value);
        return -1;
    }
    return 0;
}

static int spiral_x264_parse_param_int(x264_param_t *param, const char *name, int value) {
    char buffer[64];
    snprintf(buffer, sizeof(buffer), "%d", value);
    return spiral_x264_parse_param(param, name, buffer);
}

static int spiral_x264_parse_extra_params(x264_param_t *param, const char *extra_params) {
    if (!extra_params || !extra_params[0]) {
        return 0;
    }

    char *owned = strdup(extra_params);
    if (!owned) {
        spiral_x264_set_error("failed to copy extra x264 params");
        return -1;
    }

    char *saveptr = NULL;
    for (char *token = strtok_r(owned, ":", &saveptr); token;
         token = strtok_r(NULL, ":", &saveptr)) {
        char *equals = strchr(token, '=');
        if (!equals) {
            spiral_x264_set_error("expected x264 extra param in name=value form, got %s", token);
            free(owned);
            return -1;
        }

        *equals = '\0';
        if (spiral_x264_parse_param(param, token, equals + 1) < 0) {
            free(owned);
            return -1;
        }
    }

    free(owned);
    return 0;
}

static int spiral_x264_write_nals(FILE *output, x264_nal_t *nals, int nal_count) {
    for (int i = 0; i < nal_count; ++i) {
        if (nals[i].i_payload <= 0) {
            continue;
        }
        size_t written = fwrite(nals[i].p_payload, 1, (size_t)nals[i].i_payload, output);
        if (written != (size_t)nals[i].i_payload) {
            spiral_x264_set_error("failed to write x264 NAL payload");
            return -1;
        }
    }
    return 0;
}

static int spiral_x264_copy_nals(uint8_t *dst, x264_nal_t *nals, int nal_count) {
    int offset = 0;
    for (int i = 0; i < nal_count; ++i) {
        if (nals[i].i_payload <= 0) {
            continue;
        }
        memcpy(dst + offset, nals[i].p_payload, (size_t)nals[i].i_payload);
        offset += nals[i].i_payload;
    }
    return offset;
}

static x264_spiral_frame_props_t *spiral_x264_alloc_frame_props(
    spiral_x264_encoder_t *state,
    int frame_id,
    int decode_order,
    int layer,
    int max_ref_layer,
    const int *ref_frames,
    int ref_count) {
    if (!state) {
        spiral_x264_set_error("x264 encoder state was null");
        return NULL;
    }
    if (ref_count > X264_SPIRAL_MAX_FRAME_REFS) {
        spiral_x264_set_error(
            "x264 frame props carried %d refs, max is %d",
            ref_count,
            X264_SPIRAL_MAX_FRAME_REFS);
        return NULL;
    }
    if (ref_count < -1) {
        spiral_x264_set_error("invalid x264 frame props ref count %d", ref_count);
        return NULL;
    }
    if (ref_count > 0 && !ref_frames) {
        spiral_x264_set_error("x264 frame props references were null");
        return NULL;
    }

    if (state->frame_props_len == state->frame_props_cap) {
        size_t next_cap = state->frame_props_cap ? state->frame_props_cap * 2 : 64;
        x264_spiral_frame_props_t **next =
            (x264_spiral_frame_props_t **)realloc(
                state->frame_props, next_cap * sizeof(*state->frame_props));
        if (!next) {
            spiral_x264_set_error("failed to grow x264 frame props array");
            return NULL;
        }
        state->frame_props = next;
        state->frame_props_cap = next_cap;
    }

    x264_spiral_frame_props_t *props =
        (x264_spiral_frame_props_t *)calloc(1, sizeof(*props));
    if (!props) {
        spiral_x264_set_error("failed to allocate x264 frame props");
        return NULL;
    }

    props->i_magic = X264_SPIRAL_FRAME_PROPS_MAGIC;
    props->i_frame_id = frame_id;
    props->i_decode_order = decode_order;
    props->i_layer = layer;
    props->i_max_ref_layer = max_ref_layer;
    props->i_ref_count = ref_count;
    for (int i = 0; i < ref_count; ++i) {
        props->i_ref_frames[i] = ref_frames[i];
    }
    state->frame_props[state->frame_props_len++] = props;
    return props;
}

static int spiral_x264_total_nal_bytes(x264_nal_t *nals, int nal_count) {
    int total = 0;
    for (int i = 0; i < nal_count; ++i) {
        if (nals[i].i_payload > 0) {
            total += nals[i].i_payload;
        }
    }
    return total;
}

spiral_x264_encoder_t *spiral_x264_encoder_open(
    const char *output_path,
    int width,
    int height,
    int fps_num,
    int fps_den,
    const char *preset,
    int crf,
    int keyint,
    int keyint_min,
    int bframes,
    int scenecut,
    int b_adapt,
    const char *b_pyramid,
    int open_gop,
    int rc_lookahead,
    int threads,
    const char *extra_params) {
    SPIRAL_X264_LAST_ERROR[0] = '\0';

    x264_param_t param;
    if (x264_param_default_preset(&param, preset, NULL) < 0) {
        spiral_x264_set_error("x264 rejected preset %s", preset);
        return NULL;
    }

    param.i_width = width;
    param.i_height = height;
    param.i_csp = X264_CSP_I420;
    param.i_fps_num = fps_num;
    param.i_fps_den = fps_den;
    param.i_timebase_num = fps_den;
    param.i_timebase_den = fps_num;
    param.b_vfr_input = 0;
    param.b_repeat_headers = 1;
    param.b_annexb = 1;

    if (spiral_x264_parse_param_int(&param, "crf", crf) < 0 ||
        spiral_x264_parse_param_int(&param, "keyint", keyint) < 0 ||
        spiral_x264_parse_param_int(&param, "min-keyint", keyint_min) < 0 ||
        spiral_x264_parse_param_int(&param, "bframes", bframes) < 0 ||
        spiral_x264_parse_param_int(&param, "scenecut", scenecut) < 0 ||
        spiral_x264_parse_param_int(&param, "b-adapt", b_adapt) < 0 ||
        spiral_x264_parse_param_int(&param, "open-gop", open_gop) < 0 ||
        spiral_x264_parse_param(&param, "b-pyramid", b_pyramid) < 0) {
        return NULL;
    }

    if (rc_lookahead >= 0 &&
        spiral_x264_parse_param_int(&param, "rc-lookahead", rc_lookahead) < 0) {
        return NULL;
    }
    if (threads >= 0 && spiral_x264_parse_param_int(&param, "threads", threads) < 0) {
        return NULL;
    }
    if (spiral_x264_parse_extra_params(&param, extra_params) < 0) {
        return NULL;
    }

    if (x264_param_apply_profile(&param, "high") < 0) {
        spiral_x264_set_error("x264 rejected profile high");
        return NULL;
    }

    spiral_x264_encoder_t *state =
        (spiral_x264_encoder_t *)calloc(1, sizeof(spiral_x264_encoder_t));
    if (!state) {
        spiral_x264_set_error("failed to allocate spiral x264 encoder state");
        return NULL;
    }

    state->output = fopen(output_path, "wb");
    if (!state->output) {
        spiral_x264_set_error("failed to open x264 output path %s", output_path);
        free(state);
        return NULL;
    }

    state->width = width;
    state->height = height;
    state->frame_size = width * height + 2 * ((width / 2) * (height / 2));

    if (x264_picture_alloc(&state->picture_in, X264_CSP_I420, width, height) < 0) {
        spiral_x264_set_error("x264_picture_alloc failed");
        fclose(state->output);
        free(state);
        return NULL;
    }

    state->encoder = x264_encoder_open(&param);
    if (!state->encoder) {
        spiral_x264_set_error("x264_encoder_open failed");
        x264_picture_clean(&state->picture_in);
        fclose(state->output);
        free(state);
        return NULL;
    }

    x264_nal_t *headers = NULL;
    int header_count = 0;
    if (x264_encoder_headers(state->encoder, &headers, &header_count) < 0) {
        spiral_x264_set_error("x264_encoder_headers failed");
        x264_encoder_close(state->encoder);
        x264_picture_clean(&state->picture_in);
        fclose(state->output);
        free(state);
        return NULL;
    }

    state->header_len = spiral_x264_total_nal_bytes(headers, header_count);
    if (state->header_len > 0) {
        state->header_bytes = (uint8_t *)malloc((size_t)state->header_len);
        if (!state->header_bytes) {
            spiral_x264_set_error("failed to allocate x264 header buffer");
            x264_encoder_close(state->encoder);
            x264_picture_clean(&state->picture_in);
            fclose(state->output);
            free(state);
            return NULL;
        }
        spiral_x264_copy_nals(state->header_bytes, headers, header_count);
        if (spiral_x264_write_nals(state->output, headers, header_count) < 0) {
            free(state->header_bytes);
            x264_encoder_close(state->encoder);
            x264_picture_clean(&state->picture_in);
            fclose(state->output);
            free(state);
            return NULL;
        }
    }

    return state;
}

int spiral_x264_encoder_header_len(spiral_x264_encoder_t *state) {
    if (!state) {
        return -1;
    }
    return state->header_len;
}

int spiral_x264_encoder_copy_headers(
    spiral_x264_encoder_t *state,
    uint8_t *dst,
    int dst_len) {
    if (!state || !dst) {
        spiral_x264_set_error("x264 encoder state or destination buffer were null");
        return -1;
    }
    if (dst_len < state->header_len) {
        spiral_x264_set_error(
            "header buffer too small: need %d bytes, got %d",
            state->header_len,
            dst_len);
        return -1;
    }
    if (state->header_len > 0) {
        memcpy(dst, state->header_bytes, (size_t)state->header_len);
    }
    return state->header_len;
}

static int spiral_x264_encode_internal(
    spiral_x264_encoder_t *state,
    x264_picture_t *picture_in,
    int *out_sample_size,
    int64_t *out_pts,
    int64_t *out_dts,
    int *out_is_keyframe,
    int *out_picture_type) {
    x264_nal_t *nals = NULL;
    int nal_count = 0;
    x264_picture_t picture_out;
    int rc = x264_encoder_encode(
        state->encoder, &nals, &nal_count, picture_in, &picture_out);
    if (rc < 0) {
        spiral_x264_set_error("x264_encoder_encode failed");
        return -1;
    }

    if (out_sample_size) {
        *out_sample_size = rc;
    }
    if (rc <= 0) {
        return 0;
    }

    if (spiral_x264_write_nals(state->output, nals, nal_count) < 0) {
        return -1;
    }
    if (out_pts) {
        *out_pts = picture_out.i_pts;
    }
    if (out_dts) {
        *out_dts = picture_out.i_dts;
    }
    if (out_is_keyframe) {
        *out_is_keyframe = picture_out.b_keyframe;
    }
    if (out_picture_type) {
        *out_picture_type = picture_out.i_type;
    }
    return 0;
}

int spiral_x264_encoder_encode_i420(
    spiral_x264_encoder_t *state,
    const uint8_t *frame_bytes,
    size_t frame_len,
    int64_t pts,
    int picture_type,
    int temporal_layer,
    int max_ref_layer) {
    if (!state || !frame_bytes) {
        spiral_x264_set_error("x264 encoder state or frame bytes were null");
        return -1;
    }
    if ((int)frame_len != state->frame_size) {
        spiral_x264_set_error(
            "expected frame size %d bytes, got %zu", state->frame_size, frame_len);
        return -1;
    }

    int luma_stride = state->picture_in.img.i_stride[0];
    int chroma_stride = state->picture_in.img.i_stride[1];
    int luma_plane_size = state->width * state->height;
    int chroma_width = state->width / 2;
    int chroma_height = state->height / 2;
    int chroma_plane_size = chroma_width * chroma_height;

    const uint8_t *src_y = frame_bytes;
    const uint8_t *src_u = frame_bytes + luma_plane_size;
    const uint8_t *src_v = src_u + chroma_plane_size;

    for (int row = 0; row < state->height; ++row) {
        memcpy(state->picture_in.img.plane[0] + row * luma_stride,
               src_y + row * state->width, (size_t)state->width);
    }
    for (int row = 0; row < chroma_height; ++row) {
        memcpy(state->picture_in.img.plane[1] + row * chroma_stride,
               src_u + row * chroma_width, (size_t)chroma_width);
        memcpy(state->picture_in.img.plane[2] + row * chroma_stride,
               src_v + row * chroma_width, (size_t)chroma_width);
    }

    state->picture_in.i_pts = pts;
    state->picture_in.i_type = picture_type;
    state->picture_in.i_qpplus1 = X264_QP_AUTO;
    state->picture_in.b_keyframe =
        picture_type == X264_TYPE_IDR || picture_type == X264_TYPE_I ||
        picture_type == X264_TYPE_KEYFRAME;
    state->picture_in.opaque = NULL;
    if (temporal_layer >= 0) {
        x264_spiral_frame_props_t *props =
            spiral_x264_alloc_frame_props(
                state, (int)pts, -1, temporal_layer, max_ref_layer, NULL, -1);
        if (!props) {
            return -1;
        }
        state->picture_in.opaque = props;
    }

    return spiral_x264_encode_internal(
        state, &state->picture_in, NULL, NULL, NULL, NULL, NULL);
}

int spiral_x264_encoder_encode_i420_with_info(
    spiral_x264_encoder_t *state,
    const uint8_t *frame_bytes,
    size_t frame_len,
    int64_t pts,
    int picture_type,
    int temporal_layer,
    int max_ref_layer,
    int qp,
    int frame_id,
    int decode_order,
    const int *ref_frames,
    int ref_count,
    int *out_sample_size,
    int64_t *out_pts,
    int64_t *out_dts,
    int *out_is_keyframe,
    int *out_picture_type) {
    if (!state || !frame_bytes) {
        spiral_x264_set_error("x264 encoder state or frame bytes were null");
        return -1;
    }
    if ((int)frame_len != state->frame_size) {
        spiral_x264_set_error(
            "expected frame size %d bytes, got %zu", state->frame_size, frame_len);
        return -1;
    }

    int luma_stride = state->picture_in.img.i_stride[0];
    int chroma_stride = state->picture_in.img.i_stride[1];
    int luma_plane_size = state->width * state->height;
    int chroma_width = state->width / 2;
    int chroma_height = state->height / 2;
    int chroma_plane_size = chroma_width * chroma_height;

    const uint8_t *src_y = frame_bytes;
    const uint8_t *src_u = frame_bytes + luma_plane_size;
    const uint8_t *src_v = src_u + chroma_plane_size;

    for (int row = 0; row < state->height; ++row) {
        memcpy(state->picture_in.img.plane[0] + row * luma_stride,
               src_y + row * state->width, (size_t)state->width);
    }
    for (int row = 0; row < chroma_height; ++row) {
        memcpy(state->picture_in.img.plane[1] + row * chroma_stride,
               src_u + row * chroma_width, (size_t)chroma_width);
        memcpy(state->picture_in.img.plane[2] + row * chroma_stride,
               src_v + row * chroma_width, (size_t)chroma_width);
    }

    state->picture_in.i_pts = pts;
    state->picture_in.i_type = picture_type;
    if (qp < -1 || qp > 51) {
        spiral_x264_set_error("invalid x264 frame QP %d", qp);
        return -1;
    }
    state->picture_in.i_qpplus1 = qp >= 0 ? qp + 1 : X264_QP_AUTO;
    state->picture_in.b_keyframe =
        picture_type == X264_TYPE_IDR || picture_type == X264_TYPE_I ||
        picture_type == X264_TYPE_KEYFRAME;
    state->picture_in.opaque = NULL;
    if (temporal_layer >= 0 || decode_order >= 0 || ref_count >= 0) {
        x264_spiral_frame_props_t *props =
            spiral_x264_alloc_frame_props(
                state,
                frame_id,
                decode_order,
                temporal_layer,
                max_ref_layer,
                ref_frames,
                ref_count);
        if (!props) {
            return -1;
        }
        state->picture_in.opaque = props;
    }

    return spiral_x264_encode_internal(
        state,
        &state->picture_in,
        out_sample_size,
        out_pts,
        out_dts,
        out_is_keyframe,
        out_picture_type);
}

int spiral_x264_encoder_delayed_frames(spiral_x264_encoder_t *state) {
    if (!state) {
        spiral_x264_set_error("x264 encoder state was null");
        return -1;
    }
    return x264_encoder_delayed_frames(state->encoder);
}

int spiral_x264_encoder_flush_one_with_info(
    spiral_x264_encoder_t *state,
    int *out_sample_size,
    int64_t *out_pts,
    int64_t *out_dts,
    int *out_is_keyframe,
    int *out_picture_type) {
    if (!state) {
        spiral_x264_set_error("x264 encoder state was null");
        return -1;
    }
    return spiral_x264_encode_internal(
        state, NULL, out_sample_size, out_pts, out_dts, out_is_keyframe, out_picture_type);
}

int spiral_x264_encoder_flush_all(spiral_x264_encoder_t *state) {
    if (!state) {
        spiral_x264_set_error("x264 encoder state was null");
        return -1;
    }

    while (x264_encoder_delayed_frames(state->encoder) > 0) {
        x264_nal_t *nals = NULL;
        int nal_count = 0;
        x264_picture_t picture_out;
        int rc = x264_encoder_encode(state->encoder, &nals, &nal_count, NULL, &picture_out);
        if (rc < 0) {
            spiral_x264_set_error("x264 flush encode failed");
            return -1;
        }
        if (spiral_x264_write_nals(state->output, nals, nal_count) < 0) {
            return -1;
        }
    }

    if (fflush(state->output) != 0) {
        spiral_x264_set_error("failed to flush x264 output file");
        return -1;
    }

    return 0;
}

void spiral_x264_encoder_close(spiral_x264_encoder_t *state) {
    if (!state) {
        return;
    }
    if (state->encoder) {
        x264_encoder_close(state->encoder);
    }
    x264_picture_clean(&state->picture_in);
    if (state->output) {
        fclose(state->output);
    }
    for (size_t i = 0; i < state->frame_props_len; ++i) {
        free(state->frame_props[i]);
    }
    free(state->frame_props);
    free(state->header_bytes);
    free(state);
}
