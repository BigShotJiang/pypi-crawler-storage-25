use std::collections::{BTreeMap, BTreeSet};
use std::ffi::{CStr, CString};
use std::fs::{self, File};
use std::io::{BufRead, Write};
use std::os::raw::{c_char, c_int};
use std::path::{Path, PathBuf};

use anyhow::{Context, Result, anyhow, bail};
use serde::{Deserialize, Serialize};

const X264_TYPE_AUTO: i32 = 0x0000;
const X264_TYPE_IDR: i32 = 0x0001;
const X264_TYPE_I: i32 = 0x0002;
const X264_TYPE_P: i32 = 0x0003;
const X264_TYPE_BREF: i32 = 0x0004;
const X264_TYPE_B: i32 = 0x0005;
const X264_TYPE_KEYFRAME: i32 = 0x0006;

#[derive(Debug, Clone, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct EncodeConfig {
    pub exact_output_fps: Option<u32>,
    pub exact_ladder: Option<Vec<u32>>,
    pub frame_ir: Option<PathBuf>,
    pub keyint: u32,
    pub keyint_min: Option<u32>,
    pub bframes: u32,
    pub crf: u32,
    pub preset: String,
    pub scenecut: i32,
    pub sc_threshold: Option<i32>,
    pub b_adapt: u32,
    pub b_pyramid: String,
    pub open_gop: bool,
    pub rc_lookahead: Option<u32>,
    pub threads: Option<u32>,
    pub x264_extra_params: Option<String>,
    pub x264_layer_qps: Option<String>,
}

impl Default for EncodeConfig {
    fn default() -> Self {
        Self {
            exact_output_fps: None,
            exact_ladder: None,
            frame_ir: None,
            keyint: 120,
            keyint_min: None,
            bframes: 3,
            crf: 25,
            preset: "medium".to_string(),
            scenecut: 40,
            sc_threshold: None,
            b_adapt: 1,
            b_pyramid: "normal".to_string(),
            open_gop: false,
            rc_lookahead: None,
            threads: None,
            x264_extra_params: None,
            x264_layer_qps: None,
        }
    }
}

#[derive(Debug, Serialize)]
struct StreamMetadata {
    #[serde(rename = "type")]
    kind: &'static str,
    width: u32,
    height: u32,
    fps_num: u32,
    fps_den: u32,
}

#[derive(Debug, Serialize)]
struct SampleMetadata {
    #[serde(rename = "type")]
    kind: &'static str,
    sample_index: u32,
    byte_offset: u64,
    byte_len: usize,
    pts: i64,
    dts: i64,
    duration: u32,
    is_keyframe: bool,
    picture_type: i32,
    display_frame: u32,
    decode_order: i64,
    temporal_layer: i32,
    max_ref_layer: i32,
    frame_id: i32,
}

pub fn encode_y4m<R: BufRead>(
    reader: R,
    output_annex_b: &Path,
    metadata_jsonl: &Path,
    config: &EncodeConfig,
) -> Result<()> {
    let mut reader = Y4mReader::new(reader)?;
    let fps_num = i32::try_from(reader.fps_num).context("fps numerator does not fit in i32")?;
    let fps_den = i32::try_from(reader.fps_den).context("fps denominator does not fit in i32")?;
    let width = i32::try_from(reader.width).context("width does not fit in i32")?;
    let height = i32::try_from(reader.height).context("height does not fit in i32")?;
    let frame_schedule = X264FrameScheduleSource::validate(reader.fps_num, reader.fps_den, config)?;
    let keyint_min = config.keyint_min.unwrap_or(config.keyint);
    let mut scene_threshold = config.sc_threshold.unwrap_or(config.scenecut);
    let mut bframes = i32::try_from(config.bframes).context("bframes does not fit in i32")?;
    let mut b_adapt = i32::try_from(config.b_adapt).context("b_adapt does not fit in i32")?;
    let mut b_pyramid = config.b_pyramid.clone();
    let mut extra_params = config.x264_extra_params.clone();
    if let Some(ref schedule) = frame_schedule {
        scene_threshold = 0;
        let required_bframes =
            i32::try_from(schedule.required_bframes()).context("frame schedule bframe overflow")?;
        bframes = match schedule {
            X264FrameScheduleSource::Exact(_) => required_bframes,
            X264FrameScheduleSource::FrameIr(_) => bframes.max(required_bframes),
        };
        b_adapt = 0;
        let required_ref = format!("ref={}", schedule.required_reference_frames());
        if schedule.uses_brefs() {
            b_pyramid = "normal".to_string();
        } else if matches!(schedule, X264FrameScheduleSource::Exact(_)) {
            b_pyramid = "none".to_string();
        }
        let mut required_params = vec![required_ref.as_str(), "weightp=0"];
        if matches!(schedule, X264FrameScheduleSource::FrameIr(_)) {
            required_params.push("mbtree=0");
        }
        extra_params = Some(merge_x264_extra_params(
            extra_params.as_deref(),
            &required_params,
        ));
    }

    let mut encoder = X264Encoder::open(
        output_annex_b,
        width,
        height,
        fps_num,
        fps_den,
        &config.preset,
        i32::try_from(config.crf).context("crf does not fit in i32")?,
        i32::try_from(config.keyint).context("keyint does not fit in i32")?,
        i32::try_from(keyint_min).context("keyint_min does not fit in i32")?,
        bframes,
        scene_threshold,
        b_adapt,
        &b_pyramid,
        config.open_gop,
        config
            .rc_lookahead
            .map(i32::try_from)
            .transpose()
            .context("rc_lookahead does not fit in i32")?,
        config
            .threads
            .map(i32::try_from)
            .transpose()
            .context("threads does not fit in i32")?,
        extra_params.as_deref(),
    )?;

    let header_len = u64::try_from(encoder.header_annex_b_bytes()?.len())
        .context("x264 header length does not fit in u64")?;
    let mut next_byte_offset = header_len;
    let mut metadata = File::create(metadata_jsonl)
        .with_context(|| format!("failed to create metadata {}", metadata_jsonl.display()))?;
    writeln!(
        metadata,
        "{}",
        serde_json::to_string(&StreamMetadata {
            kind: "stream",
            width: reader.width as u32,
            height: reader.height as u32,
            fps_num: reader.fps_num,
            fps_den: reader.fps_den,
        })?
    )
    .context("failed writing stream metadata")?;

    let mut encoded_sample_count = 0u32;
    let mut frame_index = 0i64;
    while let Some(frame) = reader.read_frame()? {
        let scheduled_frame = frame_schedule
            .as_ref()
            .map(|schedule| schedule.frame_schedule(frame_index as u32))
            .transpose()?;
        let picture_type = scheduled_frame
            .as_ref()
            .map(|schedule| schedule.picture_type)
            .unwrap_or(X264_TYPE_AUTO);
        let temporal_layer = scheduled_frame
            .as_ref()
            .map(|schedule| schedule.temporal_layer)
            .unwrap_or(-1);
        let max_ref_layer = scheduled_frame
            .as_ref()
            .map(|schedule| schedule.max_ref_layer)
            .unwrap_or(-1);
        let decode_order = scheduled_frame
            .as_ref()
            .and_then(|schedule| schedule.decode_order)
            .unwrap_or(-1);
        let ref_frames = scheduled_frame
            .as_ref()
            .and_then(|schedule| schedule.ref_frames.as_deref());
        let qp = scheduled_frame
            .as_ref()
            .and_then(|schedule| schedule.qp)
            .unwrap_or(-1);
        if let Some(mut sample) = encoder.encode_i420_with_info(
            &frame,
            frame_index,
            picture_type,
            temporal_layer,
            max_ref_layer,
            qp,
            i32::try_from(frame_index).context("frame index does not fit in i32")?,
            decode_order,
            ref_frames,
        )? {
            if matches!(
                frame_schedule.as_ref(),
                Some(X264FrameScheduleSource::FrameIr(_))
            ) {
                sample.dts = i64::from(encoded_sample_count);
            }
            write_sample_metadata(
                &mut metadata,
                &frame_schedule,
                sample,
                encoded_sample_count,
                &mut next_byte_offset,
            )?;
            encoded_sample_count += 1;
        }
        frame_index += 1;
    }
    while encoder.delayed_frames()? > 0 {
        if let Some(mut sample) = encoder.flush_one_with_info()? {
            if matches!(
                frame_schedule.as_ref(),
                Some(X264FrameScheduleSource::FrameIr(_))
            ) {
                sample.dts = i64::from(encoded_sample_count);
            }
            write_sample_metadata(
                &mut metadata,
                &frame_schedule,
                sample,
                encoded_sample_count,
                &mut next_byte_offset,
            )?;
            encoded_sample_count += 1;
        }
    }

    drop(encoder);
    metadata
        .flush()
        .context("failed flushing sample metadata")?;
    if encoded_sample_count == 0 {
        bail!("x264 produced no output samples");
    }
    Ok(())
}

fn write_sample_metadata(
    metadata: &mut File,
    frame_schedule: &Option<X264FrameScheduleSource>,
    sample: EncodedSample,
    sample_index: u32,
    next_byte_offset: &mut u64,
) -> Result<()> {
    let display_frame =
        u32::try_from(sample.pts).context("x264 emitted a negative or overflowing PTS")?;
    let scheduled_frame = frame_schedule
        .as_ref()
        .map(|schedule| schedule.frame_schedule(display_frame))
        .transpose()?;
    let temporal_layer = scheduled_frame
        .as_ref()
        .map(|schedule| schedule.temporal_layer)
        .unwrap_or(-1);
    let max_ref_layer = scheduled_frame
        .as_ref()
        .map(|schedule| schedule.max_ref_layer)
        .unwrap_or(-1);
    let decode_order = scheduled_frame
        .as_ref()
        .and_then(|schedule| schedule.decode_order)
        .map(i64::from)
        .unwrap_or(sample.dts);
    let frame_id = i32::try_from(display_frame).context("display frame does not fit in i32")?;
    let metadata_line = SampleMetadata {
        kind: "sample",
        sample_index,
        byte_offset: *next_byte_offset,
        byte_len: sample.byte_len,
        pts: sample.pts,
        dts: sample.dts,
        duration: 1,
        is_keyframe: sample.is_keyframe,
        picture_type: sample.picture_type,
        display_frame,
        decode_order,
        temporal_layer,
        max_ref_layer,
        frame_id,
    };
    writeln!(metadata, "{}", serde_json::to_string(&metadata_line)?)
        .context("failed writing sample metadata")?;
    *next_byte_offset = next_byte_offset
        .checked_add(u64::try_from(sample.byte_len).context("sample size does not fit in u64")?)
        .ok_or_else(|| anyhow!("sample byte offset overflow"))?;
    Ok(())
}

struct Y4mReader<R> {
    reader: R,
    width: usize,
    height: usize,
    fps_num: u32,
    fps_den: u32,
    frame_size: usize,
    line: Vec<u8>,
}

impl<R: BufRead> Y4mReader<R> {
    fn new(mut reader: R) -> Result<Self> {
        let mut line = Vec::new();
        reader
            .read_until(b'\n', &mut line)
            .context("failed reading y4m header")?;
        if line.is_empty() {
            bail!("ffmpeg emitted an empty y4m stream");
        }
        let header = std::str::from_utf8(&line).context("y4m header was not utf-8")?;
        if !header.starts_with("YUV4MPEG2 ") {
            bail!("unexpected y4m header: {}", header.trim());
        }

        let mut width = None;
        let mut height = None;
        let mut fps_num = None;
        let mut fps_den = None;
        let mut chroma = None;

        for token in header.trim_end().split_whitespace().skip(1) {
            if let Some(value) = token.strip_prefix('W') {
                width = Some(value.parse::<usize>().context("invalid y4m width")?);
            } else if let Some(value) = token.strip_prefix('H') {
                height = Some(value.parse::<usize>().context("invalid y4m height")?);
            } else if let Some(value) = token.strip_prefix('F') {
                let (num, den) = value
                    .split_once(':')
                    .ok_or_else(|| anyhow!("invalid y4m fps token {value}"))?;
                fps_num = Some(num.parse::<u32>().context("invalid y4m fps numerator")?);
                fps_den = Some(den.parse::<u32>().context("invalid y4m fps denominator")?);
            } else if let Some(value) = token.strip_prefix('C') {
                chroma = Some(value.to_string());
            }
        }

        let width = width.ok_or_else(|| anyhow!("y4m header omitted width"))?;
        let height = height.ok_or_else(|| anyhow!("y4m header omitted height"))?;
        let fps_num = fps_num.ok_or_else(|| anyhow!("y4m header omitted fps"))?;
        let fps_den = fps_den.ok_or_else(|| anyhow!("y4m header omitted fps denominator"))?;
        if fps_num == 0 || fps_den == 0 {
            bail!("y4m fps must be positive, got {fps_num}:{fps_den}");
        }
        if let Some(chroma) = chroma.as_deref() {
            if !chroma.starts_with("420") {
                bail!("only 4:2:0 y4m output is supported, found {chroma}");
            }
        }

        let frame_size = width
            .checked_mul(height)
            .and_then(|luma| luma.checked_add(luma / 2))
            .ok_or_else(|| anyhow!("y4m frame size overflow"))?;

        Ok(Self {
            reader,
            width,
            height,
            fps_num,
            fps_den,
            frame_size,
            line: Vec::new(),
        })
    }

    fn read_frame(&mut self) -> Result<Option<Vec<u8>>> {
        self.line.clear();
        let read = self
            .reader
            .read_until(b'\n', &mut self.line)
            .context("failed reading y4m frame header")?;
        if read == 0 {
            return Ok(None);
        }
        let header = std::str::from_utf8(&self.line).context("y4m frame header was not utf-8")?;
        if !header.starts_with("FRAME") {
            bail!("unexpected y4m frame marker: {}", header.trim_end());
        }

        let mut frame = vec![0u8; self.frame_size];
        self.reader
            .read_exact(&mut frame)
            .context("failed reading y4m frame payload")?;
        Ok(Some(frame))
    }
}

struct X264Encoder {
    inner: *mut SpiralX264Encoder,
}

#[derive(Debug, Clone, Copy)]
struct EncodedSample {
    byte_len: usize,
    pts: i64,
    dts: i64,
    is_keyframe: bool,
    picture_type: i32,
}

#[derive(Debug, Clone)]
struct SpiralFrameSchedule {
    picture_type: i32,
    temporal_layer: i32,
    max_ref_layer: i32,
    qp: Option<i32>,
    decode_order: Option<i32>,
    ref_frames: Option<Vec<i32>>,
}

impl X264Encoder {
    #[allow(clippy::too_many_arguments)]
    fn open(
        output_path: &Path,
        width: i32,
        height: i32,
        fps_num: i32,
        fps_den: i32,
        preset: &str,
        crf: i32,
        keyint: i32,
        keyint_min: i32,
        bframes: i32,
        scenecut: i32,
        b_adapt: i32,
        b_pyramid: &str,
        open_gop: bool,
        rc_lookahead: Option<i32>,
        threads: Option<i32>,
        extra_params: Option<&str>,
    ) -> Result<Self> {
        let output_path = cstring_lossy(output_path)?;
        let preset = CString::new(preset).context("preset contained an interior NUL byte")?;
        let b_pyramid =
            CString::new(b_pyramid).context("b_pyramid contained an interior NUL byte")?;
        let extra_params = extra_params
            .map(|value| {
                CString::new(value).context("x264_extra_params contained an interior NUL byte")
            })
            .transpose()?;

        let inner = unsafe {
            spiral_x264_encoder_open(
                output_path.as_ptr(),
                width,
                height,
                fps_num,
                fps_den,
                preset.as_ptr(),
                crf,
                keyint,
                keyint_min,
                bframes,
                scenecut,
                b_adapt,
                b_pyramid.as_ptr(),
                i32::from(open_gop),
                rc_lookahead.unwrap_or(-1),
                threads.unwrap_or(-1),
                extra_params
                    .as_ref()
                    .map_or(std::ptr::null(), |value| value.as_ptr()),
            )
        };
        if inner.is_null() {
            bail!(last_x264_error());
        }
        Ok(Self { inner })
    }

    fn header_annex_b_bytes(&self) -> Result<Vec<u8>> {
        let header_len = unsafe { spiral_x264_encoder_header_len(self.inner) };
        if header_len < 0 {
            bail!(last_x264_error());
        }
        let mut bytes = vec![0u8; header_len as usize];
        let copied =
            unsafe { spiral_x264_encoder_copy_headers(self.inner, bytes.as_mut_ptr(), header_len) };
        if copied < 0 {
            bail!(last_x264_error());
        }
        Ok(bytes)
    }

    fn encode_i420_with_info(
        &mut self,
        frame: &[u8],
        pts: i64,
        picture_type: i32,
        temporal_layer: i32,
        max_ref_layer: i32,
        qp: i32,
        frame_id: i32,
        decode_order: i32,
        ref_frames: Option<&[i32]>,
    ) -> Result<Option<EncodedSample>> {
        let mut sample_size = 0i32;
        let mut out_pts = 0i64;
        let mut out_dts = 0i64;
        let mut out_is_keyframe = 0i32;
        let mut out_picture_type = 0i32;
        let ref_count = ref_frames
            .map(|references| {
                i32::try_from(references.len()).context("reference count does not fit in i32")
            })
            .transpose()?
            .unwrap_or(-1);
        let rc = unsafe {
            spiral_x264_encoder_encode_i420_with_info(
                self.inner,
                frame.as_ptr(),
                frame.len(),
                pts,
                picture_type,
                temporal_layer,
                max_ref_layer,
                qp,
                frame_id,
                decode_order,
                ref_frames.map_or(std::ptr::null(), |references| references.as_ptr()),
                ref_count,
                &mut sample_size,
                &mut out_pts,
                &mut out_dts,
                &mut out_is_keyframe,
                &mut out_picture_type,
            )
        };
        if rc < 0 {
            bail!(last_x264_error());
        }
        Ok((sample_size > 0).then_some(EncodedSample {
            byte_len: sample_size as usize,
            pts: out_pts,
            dts: out_dts,
            is_keyframe: out_is_keyframe != 0,
            picture_type: out_picture_type,
        }))
    }

    fn delayed_frames(&self) -> Result<i32> {
        let delayed = unsafe { spiral_x264_encoder_delayed_frames(self.inner) };
        if delayed < 0 {
            bail!(last_x264_error());
        }
        Ok(delayed)
    }

    fn flush_one_with_info(&mut self) -> Result<Option<EncodedSample>> {
        let mut sample_size = 0i32;
        let mut out_pts = 0i64;
        let mut out_dts = 0i64;
        let mut out_is_keyframe = 0i32;
        let mut out_picture_type = 0i32;
        let rc = unsafe {
            spiral_x264_encoder_flush_one_with_info(
                self.inner,
                &mut sample_size,
                &mut out_pts,
                &mut out_dts,
                &mut out_is_keyframe,
                &mut out_picture_type,
            )
        };
        if rc < 0 {
            bail!(last_x264_error());
        }
        Ok((sample_size > 0).then_some(EncodedSample {
            byte_len: sample_size as usize,
            pts: out_pts,
            dts: out_dts,
            is_keyframe: out_is_keyframe != 0,
            picture_type: out_picture_type,
        }))
    }
}

impl Drop for X264Encoder {
    fn drop(&mut self) {
        unsafe {
            spiral_x264_encoder_close(self.inner);
        }
    }
}

fn cstring_lossy(path: &Path) -> Result<CString> {
    CString::new(path.as_os_str().to_string_lossy().as_bytes())
        .context("path contained an interior NUL byte")
}

fn last_x264_error() -> String {
    unsafe { CStr::from_ptr(spiral_x264_last_error()) }
        .to_string_lossy()
        .into_owned()
}

enum SpiralX264Encoder {}

unsafe extern "C" {
    fn spiral_x264_last_error() -> *const c_char;
    fn spiral_x264_encoder_header_len(encoder: *mut SpiralX264Encoder) -> c_int;
    fn spiral_x264_encoder_copy_headers(
        encoder: *mut SpiralX264Encoder,
        dst: *mut u8,
        dst_len: c_int,
    ) -> c_int;
    fn spiral_x264_encoder_open(
        output_path: *const c_char,
        width: c_int,
        height: c_int,
        fps_num: c_int,
        fps_den: c_int,
        preset: *const c_char,
        crf: c_int,
        keyint: c_int,
        keyint_min: c_int,
        bframes: c_int,
        scenecut: c_int,
        b_adapt: c_int,
        b_pyramid: *const c_char,
        open_gop: c_int,
        rc_lookahead: c_int,
        threads: c_int,
        extra_params: *const c_char,
    ) -> *mut SpiralX264Encoder;
    fn spiral_x264_encoder_encode_i420_with_info(
        encoder: *mut SpiralX264Encoder,
        frame_bytes: *const u8,
        frame_len: usize,
        pts: i64,
        picture_type: c_int,
        temporal_layer: c_int,
        max_ref_layer: c_int,
        qp: c_int,
        frame_id: c_int,
        decode_order: c_int,
        ref_frames: *const c_int,
        ref_count: c_int,
        out_sample_size: *mut c_int,
        out_pts: *mut i64,
        out_dts: *mut i64,
        out_is_keyframe: *mut c_int,
        out_picture_type: *mut c_int,
    ) -> c_int;
    fn spiral_x264_encoder_delayed_frames(encoder: *mut SpiralX264Encoder) -> c_int;
    fn spiral_x264_encoder_flush_one_with_info(
        encoder: *mut SpiralX264Encoder,
        out_sample_size: *mut c_int,
        out_pts: *mut i64,
        out_dts: *mut i64,
        out_is_keyframe: *mut c_int,
        out_picture_type: *mut c_int,
    ) -> c_int;
    fn spiral_x264_encoder_close(encoder: *mut SpiralX264Encoder);
}

#[derive(Debug, Clone)]
enum X264FrameScheduleSource {
    Exact(ExactCadenceSchedule),
    FrameIr(FrameIrSchedule),
}

impl X264FrameScheduleSource {
    fn validate(fps_num: u32, fps_den: u32, config: &EncodeConfig) -> Result<Option<Self>> {
        if let Some(path) = &config.frame_ir {
            if config.exact_output_fps.is_some() || config.exact_ladder.is_some() {
                bail!("--x264-frame-ir is mutually exclusive with exact cadence options");
            }
            let layer_qps = LayerQpMap::parse(config.x264_layer_qps.as_deref())?;
            return Ok(Some(Self::FrameIr(FrameIrSchedule::load(
                path, fps_num, fps_den, layer_qps,
            )?)));
        }
        if config.x264_layer_qps.is_some() {
            bail!("--x264-layer-qps currently requires --x264-frame-ir");
        }

        Ok(ExactCadenceSchedule::validate(fps_num, fps_den, config)?.map(Self::Exact))
    }

    fn required_bframes(&self) -> u32 {
        match self {
            Self::Exact(schedule) => schedule.required_bframes(),
            Self::FrameIr(schedule) => schedule.required_bframes,
        }
    }

    fn required_reference_frames(&self) -> u32 {
        match self {
            Self::Exact(schedule) => schedule.required_reference_frames(),
            Self::FrameIr(schedule) => schedule.required_reference_frames,
        }
    }

    fn uses_brefs(&self) -> bool {
        match self {
            Self::Exact(_) => false,
            Self::FrameIr(schedule) => schedule.uses_brefs,
        }
    }

    fn frame_schedule(&self, frame_index: u32) -> Result<SpiralFrameSchedule> {
        match self {
            Self::Exact(schedule) => Ok(schedule.frame_schedule(u64::from(frame_index))),
            Self::FrameIr(schedule) => schedule.frame_schedule(frame_index),
        }
    }
}

#[derive(Debug, Clone)]
struct FrameIrSchedule {
    frames_by_display: BTreeMap<u32, FrameIrFrame>,
    required_bframes: u32,
    required_reference_frames: u32,
    uses_brefs: bool,
}

#[derive(Debug, Clone)]
struct FrameIrFrame {
    display_index: u32,
    decode_index: u32,
    picture_type: i32,
    temporal_layer: i32,
    max_ref_layer: i32,
    qp: Option<i32>,
    references: Vec<u32>,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct FrameIrDocument {
    frames: Vec<FrameIrFrameDocument>,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct FrameIrFrameDocument {
    display_index: Option<u32>,
    display_pos: Option<u32>,
    video_frame_pos: Option<u32>,
    frame: Option<u32>,
    decode_index: u32,
    picture_type: FrameIrPictureType,
    temporal_layer: Option<i32>,
    max_ref_layer: Option<i32>,
    qp: Option<i32>,
    #[serde(default, alias = "refs", alias = "ref_frames")]
    references: Vec<u32>,
}

#[derive(Debug, Deserialize)]
#[serde(untagged)]
enum FrameIrPictureType {
    Name(String),
    Code(i32),
}

#[derive(Debug, Clone, Default)]
struct LayerQpMap {
    qp_by_layer: BTreeMap<i32, i32>,
}

impl LayerQpMap {
    fn parse(value: Option<&str>) -> Result<Self> {
        let Some(value) = value.filter(|value| !value.trim().is_empty()) else {
            return Ok(Self::default());
        };

        let mut qp_by_layer = BTreeMap::new();
        for entry in value.split(',') {
            let (layer, qp) = entry
                .split_once('=')
                .ok_or_else(|| anyhow!("expected layer QP entry in layer=qp form, got {entry}"))?;
            let layer = layer
                .trim()
                .parse::<i32>()
                .with_context(|| format!("invalid temporal layer in {entry}"))?;
            if layer < 0 {
                bail!("temporal layer QP entry {entry} used a negative layer");
            }
            let qp = qp
                .trim()
                .parse::<i32>()
                .with_context(|| format!("invalid QP in {entry}"))?;
            validate_qp(qp)?;
            if qp_by_layer.insert(layer, qp).is_some() {
                bail!("duplicate QP assignment for temporal layer {layer}");
            }
        }

        Ok(Self { qp_by_layer })
    }

    fn qp_for_layer(&self, layer: i32) -> Option<i32> {
        self.qp_by_layer.get(&layer).copied()
    }
}

fn validate_qp(qp: i32) -> Result<()> {
    if !(0..=51).contains(&qp) {
        bail!("QP must be in 0..=51, got {qp}");
    }
    Ok(())
}

impl FrameIrPictureType {
    fn to_x264_type(&self) -> Result<i32> {
        match self {
            Self::Code(code @ X264_TYPE_AUTO..=X264_TYPE_KEYFRAME) => Ok(*code),
            Self::Code(code) => bail!("unsupported x264 picture type code {code}"),
            Self::Name(name) => match name.to_ascii_lowercase().as_str() {
                "auto" => Ok(X264_TYPE_AUTO),
                "idr" => Ok(X264_TYPE_IDR),
                "i" => Ok(X264_TYPE_I),
                "p" => Ok(X264_TYPE_P),
                "bref" | "b_ref" | "b-ref" => Ok(X264_TYPE_BREF),
                "b" => Ok(X264_TYPE_B),
                "keyframe" | "key" => Ok(X264_TYPE_KEYFRAME),
                other => bail!("unsupported x264 picture type {other}"),
            },
        }
    }
}

impl FrameIrSchedule {
    fn load(path: &Path, fps_num: u32, fps_den: u32, layer_qps: LayerQpMap) -> Result<Self> {
        let json = fs::read_to_string(path)
            .with_context(|| format!("failed reading x264 Frame IR {}", path.display()))?;
        Self::from_json_str(&json, fps_num, fps_den, layer_qps)
            .with_context(|| format!("invalid x264 Frame IR {}", path.display()))
    }

    fn from_json_str(
        json: &str,
        fps_num: u32,
        fps_den: u32,
        layer_qps: LayerQpMap,
    ) -> Result<Self> {
        if fps_den != 1 {
            bail!("x264 Frame IR currently requires integer-CFR input, found {fps_num}/{fps_den}");
        }

        let document: FrameIrDocument =
            serde_json::from_str(json).context("failed to parse x264 Frame IR JSON")?;
        if document.frames.is_empty() {
            bail!("x264 Frame IR must contain at least one frame");
        }

        let mut frames_by_display = BTreeMap::new();
        let mut decode_indices = BTreeSet::new();
        for frame in document.frames {
            let display_index = frame.display_index()?;
            let picture_type = frame.picture_type.to_x264_type()?;
            let temporal_layer = frame.temporal_layer.unwrap_or(-1);
            let max_ref_layer = frame.max_ref_layer.unwrap_or(temporal_layer);
            let qp = frame.qp.or_else(|| layer_qps.qp_for_layer(temporal_layer));
            if let Some(qp) = qp {
                validate_qp(qp).with_context(|| {
                    format!("invalid x264 Frame IR QP for frame {display_index}")
                })?;
            }
            if frames_by_display
                .insert(
                    display_index,
                    FrameIrFrame {
                        display_index,
                        decode_index: frame.decode_index,
                        picture_type,
                        temporal_layer,
                        max_ref_layer,
                        qp,
                        references: frame.references,
                    },
                )
                .is_some()
            {
                bail!("x264 Frame IR contains duplicate display frame {display_index}");
            }
            if !decode_indices.insert(frame.decode_index) {
                bail!(
                    "x264 Frame IR contains duplicate decode index {}",
                    frame.decode_index
                );
            }
        }

        for expected in 0..u32::try_from(frames_by_display.len()).unwrap_or(u32::MAX) {
            if !decode_indices.contains(&expected) {
                bail!("x264 Frame IR decode indices must be dense from 0; missing {expected}");
            }
        }

        let first_display = frames_by_display
            .values()
            .find(|frame| frame.decode_index == 0)
            .map(|frame| frame.display_index)
            .ok_or_else(|| anyhow!("x264 Frame IR is missing decode index 0"))?;
        let first_type = frames_by_display[&first_display].picture_type;
        if first_type != X264_TYPE_IDR {
            bail!("x264 Frame IR decode index 0 must be an IDR frame");
        }

        let decode_by_display = frames_by_display
            .iter()
            .map(|(display, frame)| (*display, frame.decode_index))
            .collect::<BTreeMap<_, _>>();
        for frame in frames_by_display.values() {
            validate_frame_ir_references(frame, &frames_by_display, &decode_by_display)?;
        }

        let required_bframes = required_frame_ir_bframes(&frames_by_display)?;
        let required_reference_frames =
            required_frame_ir_reference_frames(&frames_by_display, &decode_by_display)?;
        let uses_brefs = frames_by_display
            .values()
            .any(|frame| frame.picture_type == X264_TYPE_BREF);

        Ok(Self {
            frames_by_display,
            required_bframes,
            required_reference_frames,
            uses_brefs,
        })
    }

    fn frame_schedule(&self, frame_index: u32) -> Result<SpiralFrameSchedule> {
        let frame = self
            .frames_by_display
            .get(&frame_index)
            .ok_or_else(|| anyhow!("x264 Frame IR did not define display frame {frame_index}"))?;
        Ok(SpiralFrameSchedule {
            picture_type: frame.picture_type,
            temporal_layer: frame.temporal_layer,
            max_ref_layer: frame.max_ref_layer,
            qp: frame.qp,
            decode_order: Some(
                i32::try_from(frame.decode_index).context("decode index does not fit in i32")?,
            ),
            ref_frames: Some(
                frame
                    .references
                    .iter()
                    .copied()
                    .map(|reference| {
                        i32::try_from(reference).context("reference frame does not fit in i32")
                    })
                    .collect::<Result<Vec<_>>>()?,
            ),
        })
    }
}

impl FrameIrFrameDocument {
    fn display_index(&self) -> Result<u32> {
        let candidates = [
            self.display_index,
            self.display_pos,
            self.video_frame_pos,
            self.frame,
        ]
        .into_iter()
        .flatten()
        .collect::<Vec<_>>();
        match candidates.as_slice() {
            [display_index] => Ok(*display_index),
            [] => bail!("x264 Frame IR frame is missing display_index"),
            _ => bail!("x264 Frame IR frame used multiple display index fields"),
        }
    }
}

fn validate_frame_ir_references(
    frame: &FrameIrFrame,
    frames_by_display: &BTreeMap<u32, FrameIrFrame>,
    decode_by_display: &BTreeMap<u32, u32>,
) -> Result<()> {
    if frame.picture_type == X264_TYPE_IDR && !frame.references.is_empty() {
        bail!(
            "x264 Frame IR IDR frame {} cannot declare references",
            frame.display_index
        );
    }
    if matches!(
        frame.picture_type,
        X264_TYPE_P | X264_TYPE_B | X264_TYPE_BREF
    ) && frame.references.is_empty()
    {
        bail!(
            "x264 Frame IR inter frame {} must declare at least one reference",
            frame.display_index
        );
    }
    if frame.references.len() > 16 {
        bail!(
            "x264 Frame IR frame {} declares {} references, but x264 supports at most 16",
            frame.display_index,
            frame.references.len()
        );
    }

    let mut unique_refs = BTreeSet::new();
    for reference in &frame.references {
        if *reference == frame.display_index {
            bail!(
                "x264 Frame IR frame {} references itself",
                frame.display_index
            );
        }
        if !unique_refs.insert(*reference) {
            bail!(
                "x264 Frame IR frame {} repeats reference {}",
                frame.display_index,
                reference
            );
        }
        let ref_frame = frames_by_display.get(reference).ok_or_else(|| {
            anyhow!(
                "x264 Frame IR frame {} references unknown frame {}",
                frame.display_index,
                reference
            )
        })?;
        if ref_frame.picture_type == X264_TYPE_B {
            bail!(
                "x264 Frame IR frame {} references disposable B frame {}",
                frame.display_index,
                reference
            );
        }
        let ref_decode_index = decode_by_display[reference];
        if ref_decode_index >= frame.decode_index {
            bail!(
                "x264 Frame IR frame {} references frame {} before it is decoded",
                frame.display_index,
                reference
            );
        }
    }

    Ok(())
}

fn required_frame_ir_bframes(frames_by_display: &BTreeMap<u32, FrameIrFrame>) -> Result<u32> {
    let mut required = 0u32;
    let mut b_run = 0u32;
    for frame in frames_by_display.values() {
        required = required.max(frame.display_index.saturating_sub(frame.decode_index));
        if matches!(frame.picture_type, X264_TYPE_B | X264_TYPE_BREF) {
            b_run += 1;
            required = required.max(b_run);
        } else {
            b_run = 0;
        }
    }
    if required > 16 {
        bail!("x264 Frame IR requires bframes={required}, but x264 supports at most 16");
    }

    Ok(required)
}

fn required_frame_ir_reference_frames(
    frames_by_display: &BTreeMap<u32, FrameIrFrame>,
    decode_by_display: &BTreeMap<u32, u32>,
) -> Result<u32> {
    let mut last_use_by_display = BTreeMap::<u32, u32>::new();
    for frame in frames_by_display.values() {
        for reference in &frame.references {
            last_use_by_display
                .entry(*reference)
                .and_modify(|last_use| *last_use = (*last_use).max(frame.decode_index))
                .or_insert(frame.decode_index);
        }
    }

    let mut frames_by_decode = frames_by_display.values().collect::<Vec<_>>();
    frames_by_decode.sort_unstable_by_key(|frame| frame.decode_index);

    let mut required = frames_by_display
        .values()
        .map(|frame| frame.references.len() as u32)
        .max()
        .unwrap_or(1)
        .max(1);
    for frame in &frames_by_decode {
        let active_refs = frames_by_decode
            .iter()
            .copied()
            .filter(|candidate| {
                candidate.decode_index < frame.decode_index
                    && is_frame_ir_reference_type(candidate.picture_type)
                    && last_use_by_display
                        .get(&candidate.display_index)
                        .copied()
                        .unwrap_or(0)
                        >= frame.decode_index
            })
            .collect::<Vec<_>>();
        required = required.max(active_refs.len() as u32);

        if let Some(oldest_active_ref) = active_refs
            .iter()
            .map(|candidate| candidate.decode_index)
            .min()
        {
            let fifo_retained_refs = frames_by_decode
                .iter()
                .filter(|candidate| {
                    oldest_active_ref <= candidate.decode_index
                        && candidate.decode_index < frame.decode_index
                        && is_frame_ir_reference_type(candidate.picture_type)
                })
                .count();
            required = required.max(fifo_retained_refs as u32);
        }
    }

    for reference in last_use_by_display.keys() {
        if !decode_by_display.contains_key(reference) {
            bail!("internal error: missing decode index for reference {reference}");
        }
    }
    if required > 16 {
        bail!("x264 Frame IR requires ref={required}, but x264 supports at most 16");
    }

    Ok(required)
}

fn is_frame_ir_reference_type(picture_type: i32) -> bool {
    matches!(
        picture_type,
        X264_TYPE_IDR | X264_TYPE_I | X264_TYPE_P | X264_TYPE_BREF | X264_TYPE_KEYFRAME
    )
}

#[derive(Debug, Clone, Copy)]
struct ExactCadenceLayer {
    stride: u32,
}

#[derive(Debug, Clone)]
struct ExactCadenceSchedule {
    keyint: u32,
    layers: Vec<ExactCadenceLayer>,
}

impl ExactCadenceSchedule {
    fn validate(fps_num: u32, fps_den: u32, config: &EncodeConfig) -> Result<Option<Self>> {
        let mut requested = match (config.exact_output_fps, config.exact_ladder.as_ref()) {
            (Some(_), Some(_)) => {
                bail!("use either --exact-output-fps or --exact-ladder, not both")
            }
            (Some(target_fps), None) => vec![target_fps],
            (None, Some(ladder)) => ladder.clone(),
            (None, None) => return Ok(None),
        };

        if requested.iter().any(|fps| *fps == 0) {
            bail!("exact ladder fps values must be positive");
        }
        if fps_den != 1 {
            bail!("exact ladders currently require integer-CFR input, found {fps_num}/{fps_den}");
        }
        if config.open_gop {
            bail!("exact ladders require --open-gop false");
        }
        if config.scenecut != 0 || config.sc_threshold.unwrap_or(0) != 0 {
            bail!("exact ladders require scenecut to stay disabled");
        }
        if config.b_adapt != 0 {
            bail!("exact ladders require --b-adapt 0");
        }
        if config.keyint_min.unwrap_or(config.keyint) != config.keyint {
            bail!("exact ladders require fixed GOPs: --keyint-min must equal --keyint");
        }
        if requested.iter().any(|fps| *fps > fps_num) {
            bail!(
                "exact ladder cannot exceed source fps {}; got {:?}",
                fps_num,
                requested
            );
        }

        if !requested.contains(&fps_num) {
            requested.push(fps_num);
        }
        requested.sort_unstable_by(|lhs, rhs| rhs.cmp(lhs));
        requested.dedup();
        if requested.len() < 2 {
            bail!(
                "exact ladder must include at least one lower cadence than source fps {}",
                fps_num
            );
        }
        for output_fps in &requested {
            if fps_num % *output_fps != 0 {
                bail!(
                    "exact output fps {} is not possible from source fps {} without resampling",
                    output_fps,
                    fps_num
                );
            }
        }
        for window in requested.windows(2) {
            let higher = window[0];
            let lower = window[1];
            if higher % lower != 0 {
                bail!(
                    "exact ladder must stay nested, but {} is not divisible by {}",
                    higher,
                    lower
                );
            }
        }

        let max_stride = fps_num
            / *requested
                .last()
                .ok_or_else(|| anyhow!("missing lowest exact ladder fps"))?;
        if max_stride < 2 {
            bail!(
                "exact ladder {:?} matches the source cadence; no lower-rate schedule to enforce",
                requested
            );
        }
        if config.keyint % max_stride != 0 {
            bail!(
                "exact ladders require keyint {} to be divisible by coarsest cadence stride {}",
                config.keyint,
                max_stride
            );
        }

        let mut requested_low_to_high = requested;
        requested_low_to_high.reverse();
        let layers = requested_low_to_high
            .iter()
            .map(|output_fps| ExactCadenceLayer {
                stride: fps_num / *output_fps,
            })
            .collect::<Vec<_>>();

        Ok(Some(Self {
            keyint: config.keyint,
            layers,
        }))
    }

    fn required_bframes(&self) -> u32 {
        self.layers
            .get(self.layers.len().saturating_sub(2))
            .map(|layer| layer.stride.saturating_sub(1))
            .unwrap_or(0)
    }

    fn required_reference_frames(&self) -> u32 {
        let max_layer = self.layers.len().saturating_sub(1);
        let coarsest_stride = self.layers.first().map(|layer| layer.stride).unwrap_or(1);
        (0..coarsest_stride)
            .filter(|frame| self.layer_for_frame(u64::from(*frame)) < max_layer)
            .count() as u32
    }

    fn layer_for_frame(&self, frame_index: u64) -> usize {
        self.layers
            .iter()
            .enumerate()
            .find_map(|(layer_idx, layer)| {
                (frame_index % u64::from(layer.stride) == 0).then_some(layer_idx)
            })
            .unwrap_or(self.layers.len().saturating_sub(1))
    }

    fn frame_schedule(&self, frame_index: u64) -> SpiralFrameSchedule {
        let layer = self.layer_for_frame(frame_index) as i32;
        let max_layer = self.layers.len().saturating_sub(1) as i32;
        if frame_index == 0 || frame_index % u64::from(self.keyint) == 0 {
            SpiralFrameSchedule {
                picture_type: X264_TYPE_IDR,
                temporal_layer: layer,
                max_ref_layer: layer,
                qp: None,
                decode_order: None,
                ref_frames: None,
            }
        } else if layer < max_layer {
            SpiralFrameSchedule {
                picture_type: X264_TYPE_P,
                temporal_layer: layer,
                max_ref_layer: layer,
                qp: None,
                decode_order: None,
                ref_frames: None,
            }
        } else {
            SpiralFrameSchedule {
                picture_type: X264_TYPE_B,
                temporal_layer: layer,
                max_ref_layer: max_layer,
                qp: None,
                decode_order: None,
                ref_frames: None,
            }
        }
    }
}

fn merge_x264_extra_params(existing: Option<&str>, required: &[&str]) -> String {
    let mut merged = existing
        .filter(|value| !value.is_empty())
        .map(str::to_owned)
        .unwrap_or_default();
    for param in required {
        let name = param.split_once('=').map(|(name, _)| name).unwrap_or(param);
        let already_present = merged
            .split(':')
            .filter(|token| !token.is_empty())
            .any(|token| token.split_once('=').map(|(lhs, _)| lhs).unwrap_or(token) == name);
        if already_present {
            continue;
        }
        if !merged.is_empty() {
            merged.push(':');
        }
        merged.push_str(param);
    }
    merged
}

#[cfg(test)]
mod tests {
    use super::{
        EncodeConfig, ExactCadenceSchedule, FrameIrSchedule, LayerQpMap, X264_TYPE_B,
        X264_TYPE_BREF, X264_TYPE_IDR, X264_TYPE_P, merge_x264_extra_params,
    };

    fn base_config() -> EncodeConfig {
        EncodeConfig {
            exact_output_fps: Some(10),
            exact_ladder: None,
            frame_ir: None,
            keyint: 120,
            keyint_min: Some(120),
            bframes: 2,
            crf: 25,
            preset: "medium".to_string(),
            scenecut: 0,
            sc_threshold: Some(0),
            b_adapt: 0,
            b_pyramid: "strict".to_string(),
            open_gop: false,
            rc_lookahead: Some(40),
            threads: Some(4),
            x264_extra_params: None,
            x264_layer_qps: None,
        }
    }

    #[test]
    fn exact_schedule_uses_idr_p_b_pattern() {
        let schedule = ExactCadenceSchedule::validate(30, 1, &base_config())
            .unwrap()
            .expect("exact schedule");
        let types = (0..7)
            .map(|idx| schedule.frame_schedule(idx).picture_type)
            .collect::<Vec<_>>();
        assert_eq!(
            types,
            vec![0x0001, 0x0005, 0x0005, 0x0003, 0x0005, 0x0005, 0x0003]
        );
    }

    #[test]
    fn exact_schedule_rejects_non_divisible_fps() {
        let err = ExactCadenceSchedule::validate(24, 1, &base_config()).unwrap_err();
        assert!(
            err.to_string()
                .contains("not possible from source fps 24 without resampling")
        );
    }

    #[test]
    fn exact_schedule_uses_p_chains_for_intermediate_layers() {
        let mut config = base_config();
        config.exact_output_fps = None;
        config.exact_ladder = Some(vec![10, 5, 1]);
        let schedule = ExactCadenceSchedule::validate(30, 1, &config)
            .unwrap()
            .expect("exact ladder");
        let types = (0..13)
            .map(|idx| schedule.frame_schedule(idx).picture_type)
            .collect::<Vec<_>>();
        assert_eq!(
            types,
            vec![
                0x0001, 0x0005, 0x0005, 0x0003, 0x0005, 0x0005, 0x0003, 0x0005, 0x0005, 0x0003,
                0x0005, 0x0005, 0x0003
            ]
        );
        assert_eq!(schedule.frame_schedule(30).picture_type, 0x0003);
        assert_eq!(schedule.frame_schedule(6).max_ref_layer, 1);
        assert_eq!(schedule.frame_schedule(9).max_ref_layer, 2);
    }

    #[test]
    fn merge_extra_params_adds_missing_requirements_once() {
        let merged = merge_x264_extra_params(Some("qpmin=0:ref=1"), &["ref=1", "weightp=0"]);
        assert_eq!(merged, "qpmin=0:ref=1:weightp=0");
    }

    #[test]
    fn frame_ir_parses_explicit_refs_and_decode_order() {
        let schedule = FrameIrSchedule::from_json_str(
            r#"{
              "frames": [
                {"display_index": 0, "decode_index": 0, "picture_type": "idr", "temporal_layer": 0},
                {"display_index": 4, "decode_index": 1, "picture_type": "p", "temporal_layer": 1, "references": [0]},
                {"display_index": 2, "decode_index": 2, "picture_type": "bref", "temporal_layer": 2, "references": [0, 4]},
                {"display_index": 1, "decode_index": 3, "picture_type": "b", "temporal_layer": 3, "references": [0, 2]},
                {"display_index": 3, "decode_index": 4, "picture_type": "b", "temporal_layer": 3, "references": [2, 4]}
              ]
            }"#,
            30,
            1,
            LayerQpMap::default(),
        )
        .unwrap();

        assert_eq!(schedule.required_bframes, 3);
        assert_eq!(schedule.required_reference_frames, 3);
        assert!(schedule.uses_brefs);
        let frame = schedule.frame_schedule(2).unwrap();
        assert_eq!(frame.picture_type, X264_TYPE_BREF);
        assert_eq!(frame.decode_order, Some(2));
        assert_eq!(frame.ref_frames.as_deref(), Some(&[0, 4][..]));
        assert_eq!(frame.qp, None);
    }

    #[test]
    fn frame_ir_reference_count_covers_x264_fifo_retention() {
        let schedule = FrameIrSchedule::from_json_str(
            r#"{
              "frames": [
                {"display_index": 0, "decode_index": 0, "picture_type": "idr", "temporal_layer": 0},
                {"display_index": 12, "decode_index": 1, "picture_type": "p", "temporal_layer": 0, "references": [0]},
                {"display_index": 6, "decode_index": 2, "picture_type": "bref", "temporal_layer": 1, "references": [0, 12]},
                {"display_index": 3, "decode_index": 3, "picture_type": "bref", "temporal_layer": 2, "references": [0, 6]},
                {"display_index": 9, "decode_index": 4, "picture_type": "bref", "temporal_layer": 2, "references": [6, 12]},
                {"display_index": 1, "decode_index": 5, "picture_type": "bref", "temporal_layer": 3, "references": [0, 3]},
                {"display_index": 4, "decode_index": 6, "picture_type": "bref", "temporal_layer": 3, "references": [3, 6]},
                {"display_index": 7, "decode_index": 7, "picture_type": "bref", "temporal_layer": 3, "references": [6, 9]},
                {"display_index": 10, "decode_index": 8, "picture_type": "bref", "temporal_layer": 3, "references": [9, 12]},
                {"display_index": 2, "decode_index": 9, "picture_type": "b", "temporal_layer": 4, "references": [1, 3]},
                {"display_index": 5, "decode_index": 10, "picture_type": "b", "temporal_layer": 4, "references": [4, 6]},
                {"display_index": 8, "decode_index": 11, "picture_type": "b", "temporal_layer": 4, "references": [7, 9]},
                {"display_index": 11, "decode_index": 12, "picture_type": "b", "temporal_layer": 4, "references": [10, 12]},
                {"display_index": 24, "decode_index": 13, "picture_type": "p", "temporal_layer": 0, "references": [12]},
                {"display_index": 18, "decode_index": 14, "picture_type": "bref", "temporal_layer": 1, "references": [12, 24]},
                {"display_index": 15, "decode_index": 15, "picture_type": "bref", "temporal_layer": 2, "references": [12, 18]},
                {"display_index": 21, "decode_index": 16, "picture_type": "bref", "temporal_layer": 2, "references": [18, 24]},
                {"display_index": 13, "decode_index": 17, "picture_type": "bref", "temporal_layer": 3, "references": [12, 15]},
                {"display_index": 16, "decode_index": 18, "picture_type": "bref", "temporal_layer": 3, "references": [15, 18]},
                {"display_index": 19, "decode_index": 19, "picture_type": "bref", "temporal_layer": 3, "references": [18, 21]},
                {"display_index": 22, "decode_index": 20, "picture_type": "bref", "temporal_layer": 3, "references": [21, 24]},
                {"display_index": 14, "decode_index": 21, "picture_type": "b", "temporal_layer": 4, "references": [13, 15]},
                {"display_index": 17, "decode_index": 22, "picture_type": "b", "temporal_layer": 4, "references": [16, 18]},
                {"display_index": 20, "decode_index": 23, "picture_type": "b", "temporal_layer": 4, "references": [19, 21]},
                {"display_index": 23, "decode_index": 24, "picture_type": "b", "temporal_layer": 4, "references": [22, 24]}
              ]
            }"#,
            30,
            1,
            LayerQpMap::default(),
        )
        .unwrap();

        assert_eq!(schedule.required_reference_frames, 12);
    }

    #[test]
    fn frame_ir_rejects_refs_to_disposable_b_frames() {
        let err = FrameIrSchedule::from_json_str(
            r#"{
              "frames": [
                {"display_index": 0, "decode_index": 0, "picture_type": "idr"},
                {"display_index": 1, "decode_index": 1, "picture_type": "b", "references": [0]},
                {"display_index": 2, "decode_index": 2, "picture_type": "p", "references": [1]}
              ]
            }"#,
            30,
            1,
            LayerQpMap::default(),
        )
        .unwrap_err();

        assert!(err.to_string().contains("references disposable B frame 1"));
    }

    #[test]
    fn frame_ir_accepts_numeric_picture_types() {
        let schedule = FrameIrSchedule::from_json_str(
            r#"{
              "frames": [
                {"frame": 0, "decode_index": 0, "picture_type": 1},
                {"frame": 1, "decode_index": 1, "picture_type": 3, "refs": [0]}
              ]
            }"#,
            24,
            1,
            LayerQpMap::default(),
        )
        .unwrap();

        assert_eq!(
            schedule.frame_schedule(0).unwrap().picture_type,
            X264_TYPE_IDR
        );
        assert_eq!(
            schedule.frame_schedule(1).unwrap().picture_type,
            X264_TYPE_P
        );
        assert!(!schedule.uses_brefs);
        assert_eq!(X264_TYPE_B, 0x0005);
    }

    #[test]
    fn frame_ir_applies_layer_qps() {
        let schedule = FrameIrSchedule::from_json_str(
            r#"{
              "frames": [
                {"display_index": 0, "decode_index": 0, "picture_type": "idr", "temporal_layer": 0},
                {"display_index": 2, "decode_index": 1, "picture_type": "p", "temporal_layer": 1, "references": [0], "qp": 21},
                {"display_index": 1, "decode_index": 2, "picture_type": "b", "temporal_layer": 2, "references": [0, 2]}
              ]
            }"#,
            30,
            1,
            LayerQpMap::parse(Some("0=22,1=24,2=32")).unwrap(),
        )
        .unwrap();

        assert_eq!(schedule.frame_schedule(0).unwrap().qp, Some(22));
        assert_eq!(schedule.frame_schedule(2).unwrap().qp, Some(21));
        assert_eq!(schedule.frame_schedule(1).unwrap().qp, Some(32));
    }
}
