mod encoder;

use std::fs::File;
use std::io::{self, BufReader};
use std::path::PathBuf;

use anyhow::{Context, Result};
use clap::{Args, Parser, Subcommand};
#[cfg(feature = "python")]
use pyo3::exceptions::PyRuntimeError;
#[cfg(feature = "python")]
use pyo3::prelude::*;
#[cfg(feature = "python")]
use pyo3::{pyfunction, pymodule, wrap_pyfunction};

use crate::encoder::{EncodeConfig, encode_y4m};

#[derive(Debug, Parser)]
#[command(name = "spiral-h264")]
#[command(about = "GPL H.264 encoder worker for Spiral video transcoding")]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Debug, Subcommand)]
enum Command {
    EncodeY4m(EncodeY4mArgs),
}

#[derive(Debug, Args)]
struct EncodeY4mArgs {
    #[arg(long)]
    config: PathBuf,
    #[arg(long, alias = "output")]
    annex_b: PathBuf,
    #[arg(long)]
    metadata: PathBuf,
    #[arg(long)]
    input_y4m: Option<PathBuf>,
}

pub fn run_cli<I, T>(args: I) -> Result<()>
where
    I: IntoIterator<Item = T>,
    T: Into<std::ffi::OsString> + Clone,
{
    match Cli::parse_from(args).command {
        Command::EncodeY4m(args) => run_encode_y4m(args),
    }
}

fn run_encode_y4m(args: EncodeY4mArgs) -> Result<()> {
    let config_file = File::open(&args.config)
        .with_context(|| format!("failed to open config {}", args.config.display()))?;
    let config: EncodeConfig = serde_json::from_reader(config_file)
        .with_context(|| format!("failed to parse config {}", args.config.display()))?;

    if let Some(input_y4m) = args.input_y4m {
        let input = File::open(&input_y4m)
            .with_context(|| format!("failed to open y4m input {}", input_y4m.display()))?;
        encode_y4m(
            BufReader::new(input),
            &args.annex_b,
            &args.metadata,
            &config,
        )
    } else {
        let stdin = io::stdin();
        encode_y4m(
            BufReader::new(stdin.lock()),
            &args.annex_b,
            &args.metadata,
            &config,
        )
    }
}

#[cfg(feature = "python")]
#[pyfunction]
fn run_cli_py(args: Vec<String>) -> PyResult<i32> {
    let argv = std::iter::once("spiral-h264".to_string()).chain(args);
    run_cli(argv)
        .map(|()| 0)
        .map_err(|error| PyRuntimeError::new_err(format!("{error:#}")))
}

#[cfg(feature = "python")]
#[pymodule]
fn _native(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(run_cli_py, m)?)?;
    Ok(())
}
