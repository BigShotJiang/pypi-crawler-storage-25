fn main() {
    if let Err(error) = spiral_h264::run_cli(std::env::args_os()) {
        eprintln!("spiral-h264: {error:#}");
        std::process::exit(1);
    }
}
