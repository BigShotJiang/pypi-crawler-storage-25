"""Python package wrapper for the GPL spiral-h264 encoder CLI."""

from importlib import metadata

try:
    __version__ = metadata.version("spiral-h264")
except metadata.PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["__version__"]

