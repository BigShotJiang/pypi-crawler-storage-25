from __future__ import annotations

import sys

from ._native import run_cli_py


def main() -> None:
    try:
        code = run_cli_py(sys.argv[1:])
    except Exception as error:
        print(f"spiral-h264: {error}", file=sys.stderr)
        raise SystemExit(1) from error
    raise SystemExit(code)


if __name__ == "__main__":
    main()

