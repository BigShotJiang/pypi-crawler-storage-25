use std::env;
use std::path::PathBuf;
use std::process::Command;

fn main() {
    println!("cargo:rerun-if-changed=src/x264_shim.c");
    println!("cargo:rerun-if-changed=third_party/x264/configure");
    println!("cargo:rerun-if-changed=third_party/x264/x264.h");
    println!("cargo:rerun-if-changed=third_party/x264/encoder/encoder.c");
    println!("cargo:rerun-if-changed=third_party/x264/encoder/lookahead.c");
    println!("cargo:rerun-if-changed=third_party/x264/encoder/slicetype.c");

    let manifest_dir =
        PathBuf::from(env::var("CARGO_MANIFEST_DIR").expect("CARGO_MANIFEST_DIR missing"));
    let x264_source = manifest_dir.join("third_party/x264");
    let out_dir = PathBuf::from(env::var("OUT_DIR").expect("OUT_DIR missing"));
    let x264_build = out_dir.join("x264-build");

    std::fs::create_dir_all(&x264_build).expect("failed to create vendored x264 build dir");

    run(
        Command::new(x264_source.join("configure"))
            .current_dir(&x264_build)
            .arg("--disable-cli")
            .arg("--enable-static")
            .arg("--enable-pic")
            .arg("--disable-opencl")
            .arg("--disable-asm")
            .arg("--bit-depth=8")
            .arg("--chroma-format=420"),
        "configure vendored x264",
    );
    run(
        Command::new("make")
            .current_dir(&x264_build)
            .arg("-j4")
            .arg("libx264.a"),
        "build vendored x264",
    );

    println!("cargo:rustc-link-search=native={}", x264_build.display());
    println!("cargo:rustc-link-lib=static=x264");

    let mut build = cc::Build::new();
    build.file("src/x264_shim.c");
    build.include(&x264_build);
    build.include(&x264_source);
    build.compile("spiral_h264_x264_shim");
}

fn run(command: &mut Command, description: &str) {
    let status = command
        .status()
        .unwrap_or_else(|error| panic!("failed to {description}: {error}"));
    assert!(
        status.success(),
        "{description} failed with status {status}"
    );
}
