#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys


ALLOWED_LICENSES = {
    "Apache-2.0",
    "BSD-2-Clause",
    "BSD-3-Clause",
    "ISC",
    "MIT",
    "Unlicense",
    "Unicode-3.0",
    "Zlib",
}


def split_expression(expr: str) -> set[str]:
    normalized = expr.replace("(", " ").replace(")", " ")
    for token in [" OR ", " AND ", " WITH ", "/", ","]:
        normalized = normalized.replace(token, " ")
    return {part.strip() for part in normalized.split() if part.strip()}


def main() -> int:
    if not Path("third_party/x264/COPYING").exists():
        print("missing vendored x264 GPL license file", file=sys.stderr)
        return 1

    metadata = json.loads(
        subprocess.check_output(
            ["cargo", "metadata", "--format-version", "1"], text=True
        )
    )
    failed = []
    for package in metadata["packages"]:
        source = package.get("source")
        if source is None:
            continue
        license_expr = package.get("license")
        if not license_expr:
            failed.append(f"{package['name']} {package['version']}: missing license")
            continue
        unknown = split_expression(license_expr) - ALLOWED_LICENSES
        if unknown:
            failed.append(
                f"{package['name']} {package['version']}: {license_expr}"
            )

    if failed:
        print("Disallowed Cargo dependency licenses:", file=sys.stderr)
        for entry in failed:
            print(f"  - {entry}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
