"""ast-outline — AST-based structural outline for source files."""
__version__ = "1.0.0"
