# scientific-ml-modules v0.1.7

This version keeps the working module logic from the earlier package, while reorganizing the project into a clearer package layout.


## v0.1.7 updates

- `shap` and `lime` are now part of the required installation dependencies.
- Pair PDP was fixed to use feature indices when calling scikit-learn partial dependence on pandas DataFrames.
- No extra install step is needed for SHAP and LIME support.

## What changed

- File locations were moved into a package structure.
- File names were normalized around responsibility.
- Imports were made clearer inside the package.
- Old flat import names still work through compatibility shim modules.
- The modeling module was replaced with the provided implementation while preserving external inputs and outputs.
- Examples were patched so the explainability helper accepts `out_dir` and `full_run`.

## Current layout

```text
src/
├─ scientific_ml_modules/
│  ├─ core/
│  │  ├─ eda.py
│  │  ├─ processing.py
│  │  ├─ processing_core.py
│  │  ├─ feature_selection.py
│  │  ├─ modeling.py
│  │  ├─ reporting.py
│  │  └─ xai.py
│  ├─ config/
│  │  ├─ eda_builder.py
│  │  ├─ processing_builder.py
│  │  ├─ feature_selection_builder.py
│  │  └─ builders.py
│  ├─ workflow/
│  │  ├─ unified.py
│  │  ├─ deployment.py
│  │  └─ module_suite.py
│  ├─ utils/
│  │  └─ plot_style.py
│  └─ archive/
└─ compatibility shims for old flat imports
```

## Main relationships

- `core` contains the working implementation modules.
- `config` contains builder entry points.
- `workflow` contains orchestration and scoring artifacts.
- `utils` contains shared styling helpers.
- `archive` is reserved for transitional material.
- Root-level shim files preserve imports like `from modeling_only_module import ...`.

## Public package usage

```python
from scientific_ml_modules import UnifiedWorkflow
from scientific_ml_modules.core.modeling import ModelingOnly, ModelingConfigBuilder
from scientific_ml_modules.config.processing_builder import DataProcessingConfigBuilder
```

## Compatibility usage

These still work:

```python
from modeling_only_module import ModelingOnly, ModelingConfigBuilder
from results_reporting_module import ModelResultsReporter
from explainable_ai_module import ExplainableAIModule
```

## Notes

This package version is a structure and naming cleanup. The EDA, processing, feature-selection, reporting, XAI, and workflow logic was kept in place. Only imports, locations, wrappers, and the modeling implementation were updated.


## Detailed logging

Logging is enabled by default across the package. The logging layer is additive and does not change the core modeling, EDA, processing, reporting, or explainability logic. It records stage-level start/end messages and elapsed times for key operations such as EDA refreshes, processing steps, feature-selection runs, cross-validation, bootstrap summaries, graph generation, workflow orchestration, and model/artifact saving.

Typical logger entry points:
- `scientific_ml_modules.configure_root_logger()`
- builder-level `.logging(True)` where supported
- config objects with `logging_enabled=True` by default

The logs are intended to make long runs easier to audit without changing inputs or outputs.
