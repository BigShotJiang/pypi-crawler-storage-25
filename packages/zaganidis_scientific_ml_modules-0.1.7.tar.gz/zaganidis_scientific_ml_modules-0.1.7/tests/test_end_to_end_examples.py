from pathlib import Path

from end_to_end_classification import main as run_classification
from end_to_end_regression import main as run_regression
from unified_workflow_module import UnifiedWorkflowBuilder, UnifiedWorkflowModule
from deployment_scoring_module import EndToEndScoringArtifact, ScoringArtifactConfigBuilder
from modeling_only_module import ModelingConfigBuilder
from examples._workflow_shared import make_classification_workflow_dataset


def test_end_to_end_examples(tmp_path: Path):
    cls_out = run_classification(tmp_path / "classification", n_samples=120, seed=42, full_run=False)
    reg_out = run_regression(tmp_path / "regression", n_samples=120, seed=123, full_run=False)
    assert len(cls_out["selected_columns"]) > 0 and len(reg_out["selected_columns"]) > 0
    assert set(cls_out["trained_models"]) == {"Logistic regression", "Random forest"}
    assert set(reg_out["trained_models"]) == {"Linear regression", "Random forest"}


def test_unified_workflow_and_scoring_artifact(tmp_path: Path):
    df = make_classification_workflow_dataset(n_samples=180, random_state=42)
    workflow_config = UnifiedWorkflowBuilder().target_col("target").task_type("Classification").modeling_builder(ModelingConfigBuilder().task_type("Classification").algorithms(["Logistic regression", "Random forest"]).primary_metric("Balanced accuracy").imbalance_method("class_weight").cv(method="Stratified K-Fold", n_splits=3, shuffle=True, random_state=42).tuning(enabled=False).bootstrap(enabled=False).n_jobs_models(1).n_jobs_models(1)).run_explainability(False).build()
    outputs = UnifiedWorkflowModule(df=df, config=workflow_config).run()
    assert not outputs["modeling"]["model_selection_summary_df"].empty
    artifact = EndToEndScoringArtifact.from_unified_workflow_outputs(outputs, ScoringArtifactConfigBuilder().model_name("Random forest").artifact_name("custom_scoring_artifact").save_directory(str(tmp_path / "artifacts")).build())
    saved_path = artifact.save(); assert saved_path.endswith("custom_scoring_artifact.joblib")
    loaded = EndToEndScoringArtifact.load(saved_path); scored = loaded.score_dataset(df)
    assert scored["metric_map"] is not None and scored["metric_comparison_df"] is not None
    assert "future_value" in scored["metric_comparison_df"].columns
