import numpy as np
import pandas as pd

from data_processing_builder import DataProcessingConfigBuilder
from feature_selector_builder import FeatureSelectorBuilder
from modeling_only import ModelingOnly, ModelingConfigBuilder
from results_reporting import ModelResultsReporter, ResultsReportingConfigBuilder
from explainable_ai import ExplainableAIModule, ExplainabilityConfigBuilder
from examples._workflow_shared import make_classification_workflow_dataset, make_regression_workflow_dataset


def _prep(df, task_type):
    config = DataProcessingConfigBuilder().force_types(date_cols=["event_date"], categorical_cols=["country", "segment", "note"], numerical_cols=[c for c in df.columns if c.startswith("num_")] + ["target"]).set_default_numeric_missing("median").set_default_categorical_missing("mode").set_missing_for_column("note", strategy="constant", fill_value="UNKNOWN").drop_rows_if_na(enabled=True, subset=["target"]).encode_label("country").encode_onehot("segment").encode_onehot("note").random_split(test_size=0.25, random_state=42).build()
    processor = DataProcessingConfigBuilder().build_processor(df=df, target_col="target", task_type=task_type)
    processor.config = config
    return processor.process()


def _clean_model_matrices(X_train_sel: pd.DataFrame, X_test_sel: pd.DataFrame):
    X_train = X_train_sel.copy().apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    X_test = X_test_sel.copy().apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    cols = [c for c in X_train.columns if not X_train[c].isna().all() and c in X_test.columns]
    X_train = X_train[cols].copy(); X_test = X_test[cols].copy()
    med = X_train.median(numeric_only=True)
    X_train = X_train.fillna(med).fillna(0.0); X_test = X_test.fillna(med).fillna(0.0)
    mu = X_train.mean(); sd = X_train.std(ddof=0).replace(0.0, 1.0)
    return ((X_train - mu) / sd).astype(float), ((X_test - mu) / sd).astype(float)


def test_classification_pipeline_smoke():
    result = _prep(make_classification_workflow_dataset(n_samples=200), "Classification")
    X_train_numeric = result.X_train.select_dtypes(include=["number", "bool"]).copy(); X_test_numeric = result.X_test.select_dtypes(include=["number", "bool"]).copy()
    selector = FeatureSelectorBuilder(X_train_numeric, result.y_train).task("classification").na_strategy("median").use_light_methods().combine(mode="vote", min_votes=1).build_fit()
    X_train_sel = selector.get_filtered_data().reset_index(drop=True); X_test_sel = selector.transform(X_test_numeric).reset_index(drop=True)
    X_train_sel, X_test_sel = _clean_model_matrices(X_train_sel, X_test_sel)
    runner = ModelingOnly(ModelingConfigBuilder().task_type("Classification").algorithms(["Logistic regression", "Random forest"]).primary_metric("Balanced accuracy").tuning(enabled=False).bootstrap(enabled=False).n_jobs_models(1).cv(method="Stratified K-Fold", n_splits=3, shuffle=True, random_state=42).n_jobs_models(1).build())
    runner.fit(X_train_sel, result.y_train.reset_index(drop=True), X_test=X_test_sel, y_test=result.y_test.reset_index(drop=True))
    assert len(runner.trained_models_) == 2 and not runner.summary_df_.empty
    reporter = ModelResultsReporter.from_runner(runner, ResultsReportingConfigBuilder().dataset("test").models(["Logistic regression", "Random forest"]).build())
    rep = reporter.run_from_config(); assert rep["confusion_matrices"] is not None
    xai = ExplainableAIModule.from_runner(runner=runner, model_name="Logistic regression", X_train=X_train_sel, y_train=result.y_train.reset_index(drop=True), X_test=X_test_sel, y_test=result.y_test.reset_index(drop=True), config=ExplainabilityConfigBuilder().dataset("test").permutation(enabled=False).shap(enabled=False).lime(enabled=False).pdp(enabled=False).build())
    coef = xai.coefficients(); assert not coef["table"].empty


def test_regression_pipeline_smoke():
    result = _prep(make_regression_workflow_dataset(n_samples=200), "Regression")
    X_train_numeric = result.X_train.select_dtypes(include=["number", "bool"]).copy(); X_test_numeric = result.X_test.select_dtypes(include=["number", "bool"]).copy()
    selector = FeatureSelectorBuilder(X_train_numeric, result.y_train).task("regression").na_strategy("median").use_light_methods().combine(mode="vote", min_votes=1).build_fit()
    X_train_sel = selector.get_filtered_data().reset_index(drop=True); X_test_sel = selector.transform(X_test_numeric).reset_index(drop=True)
    X_train_sel, X_test_sel = _clean_model_matrices(X_train_sel, X_test_sel)
    runner = ModelingOnly(ModelingConfigBuilder().task_type("Regression").algorithms(["Linear regression", "Random forest"]).primary_metric("Mean absolute error (MAE)").tuning(enabled=False).bootstrap(enabled=False).n_jobs_models(1).cv(method="K-Fold", n_splits=3, shuffle=True, random_state=42).n_jobs_models(1).build())
    runner.fit(X_train_sel, result.y_train.reset_index(drop=True), X_test=X_test_sel, y_test=result.y_test.reset_index(drop=True))
    assert len(runner.trained_models_) == 2 and not runner.summary_df_.empty
    reporter = ModelResultsReporter.from_runner(runner, ResultsReportingConfigBuilder().dataset("test").models(["Linear regression", "Random forest"]).build())
    rep = reporter.run_from_config(); assert rep["actual_vs_predicted"] is not None


def test_feature_selector_correlation_filter_regression_runs_without_readonly_error():
    from sklearn.datasets import make_regression
    X, y = make_regression(n_samples=220, n_features=8, n_informative=5, noise=5.0, random_state=42)
    X = pd.DataFrame(X, columns=[f"x{i}" for i in range(X.shape[1])])
    X["x_dup"] = X["x0"] * 0.999 + np.random.default_rng(42).normal(0, 1e-4, len(X))
    selector = FeatureSelectorBuilder(X, pd.Series(y)).task("regression").methods(["correlation"]).correlation(threshold=0.90).combine(mode="union").build_fit()
    selected = selector.get_selected_columns(); assert isinstance(selected, list) and len(selected) >= 1
