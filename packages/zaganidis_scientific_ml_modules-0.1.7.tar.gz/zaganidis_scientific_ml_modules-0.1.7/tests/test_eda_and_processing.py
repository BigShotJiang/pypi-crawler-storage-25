from explanatory_builder import ExplanatoryAnalyzerBuilder
from data_processing_builder import DataProcessingConfigBuilder
from examples._workflow_shared import make_classification_workflow_dataset


def test_eda_and_processing_smoke_classification():
    df = make_classification_workflow_dataset(n_samples=180)
    eda = ExplanatoryAnalyzerBuilder().with_dataframe(df).with_groupby_cols(["country", "segment"]).build()
    assert not eda.numeric_description.empty
    assert not eda.categorical_description.empty
    assert not eda.missing_summary.empty
    config = DataProcessingConfigBuilder().force_types(date_cols=["event_date"], categorical_cols=["country", "segment", "note"], numerical_cols=[c for c in df.columns if c.startswith("num_")] + ["target"]).set_default_numeric_missing("median").set_default_categorical_missing("mode").set_missing_for_column("note", strategy="constant", fill_value="UNKNOWN").drop_rows_if_na(enabled=True, subset=["target"]).encode_label("country").encode_onehot("segment").encode_onehot("note").random_split(test_size=0.25, random_state=42).build()
    processor = DataProcessingConfigBuilder().build_processor(df=df, target_col="target", task_type="Classification"); processor.config = config
    result = processor.process()
    assert result.X_train.shape[0] > 0 and result.X_test.shape[0] > 0
    assert result.X_train.shape[1] == result.X_test.shape[1]
    assert result.y_train.notna().all() and result.y_test.notna().all()
