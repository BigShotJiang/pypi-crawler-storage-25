from all_builders import (
    ExplanatoryAnalyzerBuilder, DataProcessingConfigBuilder, FeatureSelectorBuilder,
    ModelingConfigBuilder, ResultsReportingConfigBuilder, ExplainabilityConfigBuilder,
    UnifiedWorkflowBuilder, UnifiedWorkflowConfig, UnifiedWorkflowModule,
    ScoringArtifactConfigBuilder, ScoringArtifactConfig, EndToEndScoringArtifact,
    ModuleSuiteBuilder,
)


def test_builder_exports_exist():
    assert ExplanatoryAnalyzerBuilder is not None
    assert DataProcessingConfigBuilder is not None
    assert FeatureSelectorBuilder is not None
    assert ModelingConfigBuilder is not None
    assert ResultsReportingConfigBuilder is not None
    assert ExplainabilityConfigBuilder is not None
    assert UnifiedWorkflowBuilder is not None
    assert UnifiedWorkflowConfig is not None
    assert UnifiedWorkflowModule is not None
    assert ScoringArtifactConfigBuilder is not None
    assert ScoringArtifactConfig is not None
    assert EndToEndScoringArtifact is not None


def test_module_suite_builder_uses_defaults_when_missing_builders():
    suite = ModuleSuiteBuilder().build()
    assert suite.config.processing_config is not None
    assert suite.config.feature_selector_init_params is not None
    assert suite.config.feature_selector_fit_params is not None
    assert suite.config.modeling_config is not None
    assert suite.config.results_config is not None
    assert suite.config.explainability_config is not None


def test_scoring_artifact_builder_accepts_custom_name_and_directory():
    cfg = ScoringArtifactConfigBuilder().model_name("Random forest").artifact_name("my_custom_artifact").save_directory("custom_dir").build()
    assert cfg.model_name == "Random forest"
    assert cfg.artifact_name == "my_custom_artifact"
    assert cfg.save_directory == "custom_dir"
