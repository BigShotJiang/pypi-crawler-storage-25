from scientific_ml_modules import UnifiedWorkflow, ModelingOnly, ModelingConfigBuilder
from scientific_ml_modules.core.modeling import ModelingOnly as CoreModelingOnly
from scientific_ml_modules.workflow.unified import UnifiedWorkflowModule


def test_new_package_exports_work():
    assert UnifiedWorkflow is UnifiedWorkflowModule
    assert ModelingOnly is CoreModelingOnly
    assert ModelingConfigBuilder is not None
