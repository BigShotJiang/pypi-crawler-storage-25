from scientific_ml_modules.workflow.module_suite import *
