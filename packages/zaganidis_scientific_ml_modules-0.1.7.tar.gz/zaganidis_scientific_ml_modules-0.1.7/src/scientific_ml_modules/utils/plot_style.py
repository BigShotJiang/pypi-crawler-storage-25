
from __future__ import annotations

import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

COLOR_BLACK = "#111111"
COLOR_BLUE = "#1F4E79"
COLOR_GREY = "#6E7B8B"
COLOR_RED = "#B22222"
COLOR_LIGHT_GREY = "#D9DEE5"
COLOR_GRID = "#D0D7DE"

SCIENTIFIC_COLOR_CYCLE = [COLOR_BLUE, COLOR_RED, COLOR_GREY, COLOR_BLACK]


def set_scientific_plot_style() -> None:
    plt.rcParams.update(
        {
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "axes.edgecolor": COLOR_BLACK,
            "axes.labelcolor": COLOR_BLACK,
            "axes.titlecolor": COLOR_BLACK,
            "axes.linewidth": 0.9,
            "axes.grid": True,
            "grid.color": COLOR_GRID,
            "grid.linewidth": 0.8,
            "grid.alpha": 0.8,
            "grid.linestyle": "--",
            "xtick.color": COLOR_BLACK,
            "ytick.color": COLOR_BLACK,
            "xtick.major.width": 0.8,
            "ytick.major.width": 0.8,
            "legend.frameon": False,
            "legend.facecolor": "white",
            "legend.edgecolor": COLOR_LIGHT_GREY,
            "font.size": 10,
            "axes.titlesize": 11,
            "axes.labelsize": 10,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
        }
    )


def get_model_color(idx: int) -> str:
    return SCIENTIFIC_COLOR_CYCLE[idx % len(SCIENTIFIC_COLOR_CYCLE)]


def style_axes(
    ax,
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str | None = None,
    title_weight: str = "bold",
) -> None:
    if title is not None:
        ax.set_title(title, fontweight=title_weight, pad=10)
    if xlabel is not None:
        ax.set_xlabel(xlabel)
    if ylabel is not None:
        ax.set_ylabel(ylabel)

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(COLOR_BLACK)
    ax.spines["bottom"].set_color(COLOR_BLACK)
    ax.tick_params(axis="both", colors=COLOR_BLACK)
    ax.grid(True, color=COLOR_GRID, linestyle="--", linewidth=0.8, alpha=0.8)


def scientific_barh(
    df,
    value_col: str,
    label_col: str,
    title: str,
    positive_negative: bool = False,
):
    plot_df = df.copy().sort_values(value_col, ascending=True)

    if positive_negative:
        bar_colors = [COLOR_BLUE if v >= 0 else COLOR_RED for v in plot_df[value_col]]
    else:
        bar_colors = [COLOR_BLUE] * len(plot_df)

    fig, ax = plt.subplots(figsize=(8, max(4, min(12, len(plot_df) * 0.35))))
    ax.barh(
        plot_df[label_col].astype(str),
        plot_df[value_col],
        color=bar_colors,
        edgecolor=COLOR_BLACK,
        linewidth=0.5,
    )
    ax.axvline(0.0, color=COLOR_RED if positive_negative else COLOR_BLACK, linewidth=1.0)
    style_axes(ax, title=title, xlabel=value_col, ylabel=label_col)
    plt.tight_layout()
    return fig


def get_blue_cmap():
    return LinearSegmentedColormap.from_list(
        "scientific_blue_cmap",
        ["#FFFFFF", COLOR_LIGHT_GREY, COLOR_BLUE],
    )


def get_red_cmap():
    return LinearSegmentedColormap.from_list(
        "scientific_red_cmap",
        ["#FFFFFF", COLOR_LIGHT_GREY, COLOR_RED],
    )
