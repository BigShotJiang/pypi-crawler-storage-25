from __future__ import annotations

import functools
import logging
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import pandas as pd
import numpy as np

_DEFAULT_FORMAT = "%(asctime)s | %(levelname)s | %(name)s | %(message)s"


def configure_root_logger(level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger("scientific_ml_modules")
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(_DEFAULT_FORMAT))
        logger.addHandler(handler)
    logger.setLevel(level)
    logger.propagate = False
    return logger


def get_logger(name: str) -> logging.Logger:
    configure_root_logger()
    return logging.getLogger(name)


def _extract_config(obj: Any):
    for attr in ("config", "config_", "_config"):
        if hasattr(obj, attr):
            return getattr(obj, attr)
    return None


def is_logging_enabled(obj: Any = None, fallback: bool = True) -> bool:
    if obj is None:
        return fallback
    for attr in ("logging_enabled", "logging_enabled_"):
        if hasattr(obj, attr):
            try:
                return bool(getattr(obj, attr))
            except Exception:
                pass
    cfg = _extract_config(obj)
    if cfg is not None:
        if isinstance(cfg, dict):
            log_cfg = cfg.get("logging", {})
            if isinstance(log_cfg, dict) and "enabled" in log_cfg:
                return bool(log_cfg.get("enabled", fallback))
        for attr in ("logging_enabled",):
            if hasattr(cfg, attr):
                try:
                    return bool(getattr(cfg, attr))
                except Exception:
                    pass
    return fallback


def ensure_instance_logger(obj: Any, name: str | None = None) -> logging.Logger:
    logger = getattr(obj, "logger_", None)
    if logger is None:
        logger_name = name or f"scientific_ml_modules.{obj.__class__.__module__}.{obj.__class__.__name__}"
        logger = get_logger(logger_name)
        try:
            setattr(obj, "logger_", logger)
        except Exception:
            pass
    return logger


def summarize_value(value: Any) -> str:
    try:
        if isinstance(value, pd.DataFrame):
            return f"DataFrame(shape={value.shape}, columns={list(value.columns[:8])}{'...' if value.shape[1] > 8 else ''})"
        if isinstance(value, pd.Series):
            return f"Series(shape={value.shape}, name={value.name})"
        if isinstance(value, np.ndarray):
            return f"ndarray(shape={value.shape}, dtype={value.dtype})"
        if isinstance(value, (list, tuple, set)):
            return f"{type(value).__name__}(len={len(value)})"
        if isinstance(value, dict):
            return f"dict(keys={list(value.keys())[:8]}{'...' if len(value) > 8 else ''})"
        if isinstance(value, Path):
            return str(value)
    except Exception:
        pass
    text = repr(value)
    return text if len(text) <= 160 else text[:157] + "..."


def log_event(logger: logging.Logger, level: int, message: str, **kwargs: Any) -> None:
    if kwargs:
        payload = ", ".join(f"{k}={summarize_value(v)}" for k, v in kwargs.items())
        logger.log(level, "%s | %s", message, payload)
    else:
        logger.log(level, "%s", message)


@contextmanager
def timed_block(logger: logging.Logger, label: str, **kwargs: Any):
    start = time.perf_counter()
    log_event(logger, logging.INFO, f"START {label}", **kwargs)
    try:
        yield
    except Exception as exc:
        elapsed = time.perf_counter() - start
        log_event(logger, logging.ERROR, f"FAIL {label}", elapsed_seconds=round(elapsed, 6), error=exc)
        raise
    else:
        elapsed = time.perf_counter() - start
        log_event(logger, logging.INFO, f"END {label}", elapsed_seconds=round(elapsed, 6))


def instrument_method(cls: type, method_name: str, label: str | None = None, level: int = logging.INFO):
    if not hasattr(cls, method_name):
        return
    original = getattr(cls, method_name)
    if getattr(original, "_smlog_wrapped", False):
        return

    @functools.wraps(original)
    def wrapper(self, *args, **kwargs):
        logger = ensure_instance_logger(self)
        if not is_logging_enabled(self, True):
            return original(self, *args, **kwargs)
        call_label = label or f"{cls.__name__}.{method_name}"
        start = time.perf_counter()
        log_event(logger, level, f"START {call_label}", args=args, kwargs=kwargs)
        try:
            result = original(self, *args, **kwargs)
        except Exception as exc:
            elapsed = time.perf_counter() - start
            log_event(logger, logging.ERROR, f"FAIL {call_label}", elapsed_seconds=round(elapsed, 6), error=exc)
            raise
        elapsed = time.perf_counter() - start
        log_event(logger, level, f"END {call_label}", elapsed_seconds=round(elapsed, 6), result=result)
        return result

    wrapper._smlog_wrapped = True
    setattr(cls, method_name, wrapper)


def instrument_function(module, function_name: str, logger_name: str, label: str | None = None, level: int = logging.INFO):
    if not hasattr(module, function_name):
        return
    original = getattr(module, function_name)
    if getattr(original, "_smlog_wrapped", False):
        return
    logger = get_logger(logger_name)

    @functools.wraps(original)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        log_event(logger, level, f"START {label or function_name}", args=args, kwargs=kwargs)
        try:
            result = original(*args, **kwargs)
        except Exception as exc:
            elapsed = time.perf_counter() - start
            log_event(logger, logging.ERROR, f"FAIL {label or function_name}", elapsed_seconds=round(elapsed, 6), error=exc)
            raise
        elapsed = time.perf_counter() - start
        log_event(logger, level, f"END {label or function_name}", elapsed_seconds=round(elapsed, 6), result=result)
        return result

    wrapper._smlog_wrapped = True
    setattr(module, function_name, wrapper)
