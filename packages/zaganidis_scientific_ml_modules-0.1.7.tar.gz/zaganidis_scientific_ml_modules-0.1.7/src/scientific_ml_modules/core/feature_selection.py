from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Sequence, Union

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.feature_selection import (
    SequentialFeatureSelector,
    VarianceThreshold,
    mutual_info_classif,
    mutual_info_regression,
)
from sklearn.inspection import permutation_importance
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.utils.multiclass import type_of_target


COLOR_BLACK = "#111111"
COLOR_BLUE = "#1F4E79"
COLOR_GREY = "#6E7B8B"
COLOR_RED = "#B22222"
COLOR_LIGHT_GREY = "#D9DEE5"
COLOR_GRID = "#D0D7DE"


class FeatureSelector:
    """
    Reusable feature selection class for numeric pandas DataFrames.

    Supported methods
    -----------------
    - mutual_info
    - variance
    - correlation
    - permutation
    - forward
    - backward

    Combination modes
    -----------------
    - union
    - intersection
    - vote

    Main outputs
    ------------
    - selected columns
    - filtered X_train
    - feature summary table
    - method selection matrix
    - overlap tables
    - plotting methods

    Notes
    -----
    - X_train must already be numeric.
    - Variance threshold removes near-constant columns.
    - Correlation filtering is the part that handles multicollinearity.
    - Permutation importance and sequential selection are estimator-based.
    """

    VALID_METHODS = {
        "mutual_info",
        "variance",
        "correlation",
        "permutation",
        "forward",
        "backward",
    }

    def __init__(
        self,
        X_train: pd.DataFrame,
        y_train: Union[pd.Series, pd.DataFrame, np.ndarray, list],
        task: str = "auto",
        estimator: Optional[Any] = None,
        scoring: Optional[str] = None,
        cv: int = 5,
        random_state: int = 42,
        n_jobs: int = -1,
        na_strategy: str = "error",
    ) -> None:
        self.X_train = X_train.copy()

        if isinstance(y_train, pd.DataFrame):
            if y_train.shape[1] != 1:
                raise ValueError("y_train must be a Series or a single-column DataFrame.")
            y_train = y_train.iloc[:, 0]

        self.y_train = pd.Series(y_train).copy()

        if len(self.X_train) != len(self.y_train):
            raise ValueError("X_train and y_train must have the same number of rows.")

        self.X_train = self.X_train.reset_index(drop=True)
        self.y_train = self.y_train.reset_index(drop=True)

        self.task = task
        self.estimator = estimator
        self.scoring = scoring
        self.cv = cv
        self.random_state = random_state
        self.n_jobs = n_jobs
        self.na_strategy = na_strategy

        self.X_: Optional[pd.DataFrame] = None
        self.y_: Optional[pd.Series] = None
        self.task_: Optional[str] = None
        self.estimator_: Optional[Any] = None
        self.scoring_: Optional[str] = None

        self.selected_columns_: List[str] = []
        self.X_filtered_: Optional[pd.DataFrame] = None
        self.feature_summary_: Optional[pd.DataFrame] = None
        self.method_results_: Dict[str, Dict[str, Any]] = {}
        self.combine_mode_: Optional[str] = None
        self.min_votes_: Optional[int] = None
        self.fitted_: bool = False

    # =========================================================
    # Internal utilities
    # =========================================================
    def _prepare_data(self) -> None:
        if not isinstance(self.X_train, pd.DataFrame):
            raise TypeError("X_train must be a pandas DataFrame.")

        if self.X_train.columns.duplicated().any():
            dupes = self.X_train.columns[self.X_train.columns.duplicated()].tolist()
            raise ValueError(f"Duplicate columns found in X_train: {dupes}")

        non_numeric_cols = self.X_train.select_dtypes(exclude=[np.number, "bool"]).columns.tolist()
        if non_numeric_cols:
            raise ValueError(
                "All columns in X_train must be numeric before feature selection. "
                f"Non-numeric columns found: {non_numeric_cols}"
            )

        X = self.X_train.copy()
        y = self.y_train.copy()

        if self.na_strategy == "error":
            if X.isna().any().any():
                bad_cols = X.columns[X.isna().any()].tolist()
                raise ValueError(
                    "X_train contains missing values. "
                    f"Columns with NA: {bad_cols}. "
                    "Handle missing values first or set na_strategy='median'."
                )
            if y.isna().any():
                raise ValueError("y_train contains missing values.")
        elif self.na_strategy == "median":
            X = X.fillna(X.median(numeric_only=True))
            if y.isna().any():
                raise ValueError("y_train contains missing values.")
        else:
            raise ValueError("na_strategy must be either 'error' or 'median'.")

        self.X_ = X
        self.y_ = y
        self.task_ = self._infer_task()
        self.estimator_ = clone(self.estimator) if self.estimator is not None else self._default_estimator()
        self.scoring_ = self.scoring if self.scoring is not None else self._default_scoring()

    def _infer_task(self) -> str:
        if self.task in {"classification", "regression"}:
            return self.task

        target_type = type_of_target(self.y_train)

        if target_type in {"binary", "multiclass"}:
            return "classification"
        if target_type in {"continuous", "continuous-multioutput"}:
            return "regression"

        raise ValueError(
            f"Could not infer task from y_train (detected type: {target_type}). "
            "Please set task='classification' or task='regression'."
        )

    def _default_estimator(self) -> Any:
        if self.task_ == "classification":
            return RandomForestClassifier(
                n_estimators=300,
                random_state=self.random_state,
                n_jobs=self.n_jobs,
                class_weight="balanced_subsample",
            )
        return RandomForestRegressor(
            n_estimators=300,
            random_state=self.random_state,
            n_jobs=self.n_jobs,
        )

    def _default_scoring(self) -> str:
        if self.task_ == "classification":
            return "roc_auc" if self.y_.nunique() == 2 else "accuracy"
        return "neg_mean_squared_error"

    def _get_cv_splitter(self, cv: Optional[int] = None):
        cv = cv or self.cv

        if self.task_ == "classification":
            counts = pd.Series(self.y_).value_counts()
            min_class_count = counts.min()

            if min_class_count >= 2:
                n_splits = min(cv, int(min_class_count))
                n_splits = max(2, n_splits)
                return StratifiedKFold(
                    n_splits=n_splits,
                    shuffle=True,
                    random_state=self.random_state,
                )

        n_splits = min(cv, len(self.X_))
        n_splits = max(2, n_splits)
        return KFold(
            n_splits=n_splits,
            shuffle=True,
            random_state=self.random_state,
        )

    def _check_fitted(self) -> None:
        if not self.fitted_:
            raise ValueError("The selector is not fitted yet. Call fit() first.")

    def _resolve_columns_input(self, columns: Union[str, Sequence[str]]) -> List[str]:
        self._check_fitted()

        if isinstance(columns, str):
            if columns == "selected":
                return self.selected_columns_
            if columns == "all":
                return self.X_.columns.tolist()
            if columns in self.method_results_:
                return self.method_results_[columns]["selected_columns"]
            raise ValueError(
                "If columns is a string, it must be 'selected', 'all', "
                "or one of the fitted methods."
            )

        columns = list(columns)
        missing = [c for c in columns if c not in self.X_.columns]
        if missing:
            raise ValueError(f"Columns not found in X_train: {missing}")
        return columns

    # =========================================================
    # Scientific plot helpers
    # =========================================================
    def _scientific_style_axes(
        self,
        ax,
        title: str,
        xlabel: str,
        ylabel: str,
        add_grid_y: bool = True,
        add_grid_x: bool = False,
    ) -> None:
        ax.set_title(title, fontsize=13, fontweight="bold", color=COLOR_BLACK, pad=12)
        ax.set_xlabel(xlabel, fontsize=11, color=COLOR_BLACK)
        ax.set_ylabel(ylabel, fontsize=11, color=COLOR_BLACK)

        ax.tick_params(axis="both", labelsize=10, colors=COLOR_BLACK)
        ax.set_axisbelow(True)

        if add_grid_y:
            ax.yaxis.grid(True, color=COLOR_GRID, linestyle="--", linewidth=0.8, alpha=0.9)
        if add_grid_x:
            ax.xaxis.grid(True, color=COLOR_GRID, linestyle="--", linewidth=0.8, alpha=0.9)

        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_color(COLOR_GREY)
        ax.spines["bottom"].set_color(COLOR_GREY)
        ax.spines["left"].set_linewidth(0.9)
        ax.spines["bottom"].set_linewidth(0.9)

        ax.set_facecolor("white")

    def _get_blue_cmap(self):
        return LinearSegmentedColormap.from_list(
            "scientific_blue_map",
            [COLOR_LIGHT_GREY, COLOR_BLUE],
        )

    def _get_diverging_cmap(self):
        return LinearSegmentedColormap.from_list(
            "scientific_diverging_map",
            [COLOR_BLUE, "white", COLOR_RED],
        )

    def _prepare_ranked_plot_df(
        self,
        df: pd.DataFrame,
        feature_col: str,
        value_col: str,
        top_n: int,
        ascending: bool = False,
    ) -> pd.DataFrame:
        plot_df = (
            df[[feature_col, value_col]]
            .dropna()
            .sort_values(value_col, ascending=ascending)
            .head(top_n)
            .copy()
        )
        return plot_df.iloc[::-1].reset_index(drop=True)

    # =========================================================
    # Individual selection methods
    # =========================================================
    def _run_mutual_info(self, top_k: int) -> Dict[str, Any]:
        if self.task_ == "classification":
            scores = mutual_info_classif(self.X_, self.y_, random_state=self.random_state)
        else:
            scores = mutual_info_regression(self.X_, self.y_, random_state=self.random_state)

        score_series = pd.Series(
            scores,
            index=self.X_.columns,
            name="mutual_info_score",
        ).sort_values(ascending=False)

        selected = score_series.head(min(top_k, len(score_series))).index.tolist()

        return {
            "selected_columns": selected,
            "score_series": score_series,
        }

    def _run_variance(self, threshold: float) -> Dict[str, Any]:
        selector = VarianceThreshold(threshold=threshold)
        selector.fit(self.X_)

        selected = self.X_.columns[selector.get_support()].tolist()
        variance_series = self.X_.var(ddof=0).rename("variance_score").sort_values(ascending=False)

        return {
            "selected_columns": selected,
            "score_series": variance_series,
        }

    def _run_correlation_filter(self, threshold: float) -> Dict[str, Any]:
        remaining = list(self.X_.columns)
        dropped: List[str] = []

        while True:
            corr = self.X_[remaining].corr().abs()
            corr_values = corr.to_numpy(copy=True)
            np.fill_diagonal(corr_values, 0.0)

            max_corr = corr_values.max()
            if np.isnan(max_corr) or max_corr <= threshold:
                break

            pair_idx = np.argwhere(corr_values == max_corr)[0]
            col_a = corr.index[pair_idx[0]]
            col_b = corr.columns[pair_idx[1]]

            mean_corr = pd.DataFrame(
                corr_values,
                index=corr.index,
                columns=corr.columns,
            ).mean()
            drop_col = col_a if mean_corr[col_a] >= mean_corr[col_b] else col_b

            remaining.remove(drop_col)
            dropped.append(drop_col)

        avg_abs_corr = self.X_.corr().abs().mean().rename("avg_abs_corr_score").sort_values(ascending=False)

        return {
            "selected_columns": remaining,
            "dropped_columns": dropped,
            "score_series": avg_abs_corr,
        }

    def _run_permutation(self, top_k: int, n_repeats: int) -> Dict[str, Any]:
        splitter = self._get_cv_splitter()
        importances = pd.Series(0.0, index=self.X_.columns)

        n_folds = 0
        split_arg = self.y_ if self.task_ == "classification" else None

        for train_idx, valid_idx in splitter.split(self.X_, split_arg):
            X_tr = self.X_.iloc[train_idx]
            X_va = self.X_.iloc[valid_idx]
            y_tr = self.y_.iloc[train_idx]
            y_va = self.y_.iloc[valid_idx]

            est = clone(self.estimator_)
            est.fit(X_tr, y_tr)

            perm = permutation_importance(
                est,
                X_va,
                y_va,
                n_repeats=n_repeats,
                random_state=self.random_state,
                scoring=self.scoring_,
                n_jobs=self.n_jobs,
            )

            importances += pd.Series(perm.importances_mean, index=self.X_.columns)
            n_folds += 1

        score_series = (importances / n_folds).rename(
            "permutation_importance_score"
        ).sort_values(ascending=False)

        selected = score_series.head(min(top_k, len(score_series))).index.tolist()

        return {
            "selected_columns": selected,
            "score_series": score_series,
        }

    def _run_sequential(
        self,
        direction: str,
        n_features_to_select: Union[int, float, str],
    ) -> Dict[str, Any]:
        splitter = self._get_cv_splitter()

        sfs = SequentialFeatureSelector(
            estimator=clone(self.estimator_),
            n_features_to_select=n_features_to_select,
            direction=direction,
            scoring=self.scoring_,
            cv=splitter,
            n_jobs=self.n_jobs,
        )
        sfs.fit(self.X_, self.y_)

        selected = self.X_.columns[sfs.get_support()].tolist()

        return {
            "selected_columns": selected,
            "score_series": pd.Series(
                [1 if col in selected else 0 for col in self.X_.columns],
                index=self.X_.columns,
                name=f"{direction}_selected_score",
            ),
        }

    # =========================================================
    # Fit / transform
    # =========================================================
    def fit(
        self,
        methods: Sequence[str] = (
            "mutual_info",
            "variance",
            "correlation",
            "permutation",
            "forward",
            "backward",
        ),
        mi_top_k: int = 20,
        variance_threshold: float = 0.0,
        corr_threshold: float = 0.95,
        perm_top_k: int = 20,
        perm_n_repeats: int = 10,
        sfs_n_features_to_select: Union[int, float, str] = "auto",
        combine_mode: str = "vote",
        min_votes: Optional[int] = None,
    ) -> "FeatureSelector":
        self._prepare_data()

        methods = [m.lower() for m in methods]
        invalid_methods = sorted(set(methods) - self.VALID_METHODS)
        if invalid_methods:
            raise ValueError(f"Invalid methods: {invalid_methods}. Valid methods: {sorted(self.VALID_METHODS)}")

        if combine_mode not in {"union", "intersection", "vote"}:
            raise ValueError("combine_mode must be one of: 'union', 'intersection', or 'vote'.")

        self.combine_mode_ = combine_mode
        self.min_votes_ = min_votes
        self.method_results_ = {}

        feature_summary = pd.DataFrame(index=self.X_.columns)
        feature_summary["variance_score"] = self.X_.var(ddof=0)

        for method in methods:
            feature_summary[f"selected_by_{method}"] = False

        if "mutual_info" in methods:
            res = self._run_mutual_info(top_k=mi_top_k)
            self.method_results_["mutual_info"] = res
            feature_summary.loc[res["score_series"].index, "mutual_info_score"] = res["score_series"]
            feature_summary.loc[res["selected_columns"], "selected_by_mutual_info"] = True

        if "variance" in methods:
            res = self._run_variance(threshold=variance_threshold)
            self.method_results_["variance"] = res
            feature_summary.loc[res["selected_columns"], "selected_by_variance"] = True

        if "correlation" in methods:
            res = self._run_correlation_filter(threshold=corr_threshold)
            self.method_results_["correlation"] = res
            feature_summary.loc[res["score_series"].index, "avg_abs_corr_score"] = res["score_series"]
            feature_summary.loc[res["selected_columns"], "selected_by_correlation"] = True

        if "permutation" in methods:
            res = self._run_permutation(top_k=perm_top_k, n_repeats=perm_n_repeats)
            self.method_results_["permutation"] = res
            feature_summary.loc[res["score_series"].index, "permutation_importance_score"] = res["score_series"]
            feature_summary.loc[res["selected_columns"], "selected_by_permutation"] = True

        if "forward" in methods:
            res = self._run_sequential(
                direction="forward",
                n_features_to_select=sfs_n_features_to_select,
            )
            self.method_results_["forward"] = res
            feature_summary.loc[res["selected_columns"], "selected_by_forward"] = True

        if "backward" in methods:
            res = self._run_sequential(
                direction="backward",
                n_features_to_select=sfs_n_features_to_select,
            )
            self.method_results_["backward"] = res
            feature_summary.loc[res["selected_columns"], "selected_by_backward"] = True

        vote_cols = [f"selected_by_{m}" for m in methods]
        feature_summary["votes"] = feature_summary[vote_cols].sum(axis=1).astype(int)

        if combine_mode == "union":
            selected = feature_summary.index[feature_summary["votes"] >= 1].tolist()
        elif combine_mode == "intersection":
            selected = feature_summary.index[feature_summary["votes"] == len(methods)].tolist()
        else:
            if min_votes is None:
                min_votes = max(1, math.ceil(len(methods) / 2))
            selected = feature_summary.index[feature_summary["votes"] >= min_votes].tolist()

        if len(selected) == 0:
            selected = feature_summary.index[feature_summary["votes"] >= 1].tolist()

        sort_cols = [
            c
            for c in ["votes", "mutual_info_score", "permutation_importance_score", "variance_score"]
            if c in feature_summary.columns
        ]

        self.selected_columns_ = selected
        self.X_filtered_ = self.X_[self.selected_columns_].copy()
        self.feature_summary_ = (
            feature_summary
            .reset_index()
            .rename(columns={"index": "feature"})
            .sort_values(by=sort_cols, ascending=False, na_position="last")
            .reset_index(drop=True)
        )
        self.fitted_ = True
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        self._check_fitted()

        if not isinstance(X, pd.DataFrame):
            raise TypeError("X must be a pandas DataFrame.")

        missing_cols = [c for c in self.selected_columns_ if c not in X.columns]
        if missing_cols:
            raise ValueError(f"The following selected columns are missing in the new data: {missing_cols}")

        return X[self.selected_columns_].copy()

    def fit_transform(self, **fit_kwargs) -> pd.DataFrame:
        self.fit(**fit_kwargs)
        return self.get_filtered_data()

    # =========================================================
    # Core outputs
    # =========================================================
    def get_selected_columns(self) -> List[str]:
        self._check_fitted()
        return self.selected_columns_.copy()

    def get_filtered_data(self) -> pd.DataFrame:
        self._check_fitted()
        return self.X_filtered_.copy()

    def get_feature_summary(self) -> pd.DataFrame:
        self._check_fitted()
        return self.feature_summary_.copy()

    def get_method_results(self) -> Dict[str, Dict[str, Any]]:
        self._check_fitted()
        return self.method_results_

    def get_results(self) -> Dict[str, Any]:
        self._check_fitted()
        return {
            "selected_columns": self.get_selected_columns(),
            "filtered_X_train": self.get_filtered_data(),
            "feature_summary": self.get_feature_summary(),
            "method_results": self.get_method_results(),
            "task": self.task_,
            "scoring": self.scoring_,
            "combine_mode": self.combine_mode_,
            "min_votes": self.min_votes_,
        }

    # =========================================================
    # Summary tables
    # =========================================================
    def get_selection_overview(self) -> pd.DataFrame:
        self._check_fitted()

        rows = []
        total_features = self.X_.shape[1]

        for method, res in self.method_results_.items():
            selected_n = len(res["selected_columns"])
            dropped_n = total_features - selected_n

            rows.append({
                "method": method,
                "selected_n": selected_n,
                "dropped_n": dropped_n,
                "selected_pct": selected_n / total_features,
                "dropped_pct": dropped_n / total_features,
            })

        final_selected_n = len(self.selected_columns_)
        final_dropped_n = total_features - final_selected_n

        rows.append({
            "method": "final_combined",
            "selected_n": final_selected_n,
            "dropped_n": final_dropped_n,
            "selected_pct": final_selected_n / total_features,
            "dropped_pct": final_dropped_n / total_features,
        })

        return (
            pd.DataFrame(rows)
            .sort_values("selected_n", ascending=False)
            .reset_index(drop=True)
        )

    def get_method_selection_matrix(self) -> pd.DataFrame:
        self._check_fitted()

        df = self.feature_summary_.copy()
        keep_cols = ["feature"] + [c for c in df.columns if c.startswith("selected_by_")] + ["votes"]
        return df[keep_cols].copy()

    def get_rank_table(self, sort_by: str = "votes", ascending: bool = False) -> pd.DataFrame:
        self._check_fitted()

        valid = set(self.feature_summary_.columns)
        if sort_by not in valid:
            raise ValueError(f"sort_by='{sort_by}' is not a valid column. Valid columns: {sorted(valid)}")

        return self.feature_summary_.sort_values(sort_by, ascending=ascending, na_position="last").reset_index(drop=True)

    def get_method_overlap_table(self, metric: str = "jaccard") -> pd.DataFrame:
        self._check_fitted()

        methods = list(self.method_results_.keys()) + ["final_combined"]
        selected_map = {
            m: set(self.selected_columns_) if m == "final_combined" else set(self.method_results_[m]["selected_columns"])
            for m in methods
        }

        mat = pd.DataFrame(index=methods, columns=methods, dtype=float)

        for m1 in methods:
            for m2 in methods:
                s1 = selected_map[m1]
                s2 = selected_map[m2]

                if metric == "count":
                    val = len(s1.intersection(s2))
                elif metric == "jaccard":
                    union = len(s1.union(s2))
                    val = len(s1.intersection(s2)) / union if union > 0 else np.nan
                else:
                    raise ValueError("metric must be 'count' or 'jaccard'.")

                mat.loc[m1, m2] = val

        return mat

    def get_correlation_pairs_table(self, threshold: float = 0.8) -> pd.DataFrame:
        self._check_fitted()

        corr = self.X_.corr().abs()
        pairs = []

        cols = corr.columns.tolist()
        for i in range(len(cols)):
            for j in range(i + 1, len(cols)):
                value = corr.iloc[i, j]
                if value >= threshold:
                    pairs.append({
                        "feature_1": cols[i],
                        "feature_2": cols[j],
                        "abs_correlation": value,
                    })

        if not pairs:
            return pd.DataFrame(columns=["feature_1", "feature_2", "abs_correlation"])

        return pd.DataFrame(pairs).sort_values("abs_correlation", ascending=False).reset_index(drop=True)

    # =========================================================
    # Plot methods
    # =========================================================
    def plot_votes(self, top_n: int = 30, figsize: tuple = (10, 7)) -> None:
        self._check_fitted()

        plot_df = self._prepare_ranked_plot_df(
            df=self.get_rank_table(sort_by="votes", ascending=False),
            feature_col="feature",
            value_col="votes",
            top_n=top_n,
            ascending=False,
        )

        fig, ax = plt.subplots(figsize=figsize)
        ax.barh(plot_df["feature"], plot_df["votes"], color=COLOR_BLUE, edgecolor=COLOR_BLACK, linewidth=0.4)

        self._scientific_style_axes(
            ax=ax,
            title="Feature Selection Vote Count",
            xlabel="Number of Methods Selecting Feature",
            ylabel="Feature",
            add_grid_x=True,
            add_grid_y=False,
        )

        plt.tight_layout()

    def plot_mutual_info(self, top_n: int = 30, figsize: tuple = (10, 7)) -> None:
        self._check_fitted()

        if "mutual_info" not in self.method_results_:
            raise ValueError("Mutual information was not fitted. Include 'mutual_info' in methods.")

        s = self.method_results_["mutual_info"]["score_series"].dropna().sort_values(ascending=False).head(top_n)
        plot_df = pd.DataFrame({"feature": s.index, "mutual_info_score": s.values}).iloc[::-1]

        fig, ax = plt.subplots(figsize=figsize)
        ax.barh(
            plot_df["feature"],
            plot_df["mutual_info_score"],
            color=COLOR_BLUE,
            edgecolor=COLOR_BLACK,
            linewidth=0.4,
        )

        self._scientific_style_axes(
            ax=ax,
            title="Top Features by Mutual Information",
            xlabel="Mutual Information Score",
            ylabel="Feature",
            add_grid_x=True,
            add_grid_y=False,
        )

        plt.tight_layout()

    def plot_permutation_importance(self, top_n: int = 30, figsize: tuple = (10, 7)) -> None:
        self._check_fitted()

        if "permutation" not in self.method_results_:
            raise ValueError("Permutation importance was not fitted. Include 'permutation' in methods.")

        s = self.method_results_["permutation"]["score_series"].dropna().sort_values(ascending=False).head(top_n)
        plot_df = pd.DataFrame({"feature": s.index, "permutation_importance_score": s.values}).iloc[::-1]

        fig, ax = plt.subplots(figsize=figsize)
        ax.barh(
            plot_df["feature"],
            plot_df["permutation_importance_score"],
            color=COLOR_BLUE,
            edgecolor=COLOR_BLACK,
            linewidth=0.4,
        )

        self._scientific_style_axes(
            ax=ax,
            title="Top Features by Permutation Importance",
            xlabel="Mean Permutation Importance",
            ylabel="Feature",
            add_grid_x=True,
            add_grid_y=False,
        )

        ax.axvline(0, color=COLOR_RED, linewidth=1.0, linestyle="--", alpha=0.9)

        plt.tight_layout()

    def plot_variance(self, top_n: int = 30, figsize: tuple = (10, 7)) -> None:
        self._check_fitted()

        plot_df = (
            self.feature_summary_[["feature", "variance_score"]]
            .dropna()
            .sort_values("variance_score", ascending=False)
            .head(top_n)
            .iloc[::-1]
        )

        fig, ax = plt.subplots(figsize=figsize)
        ax.barh(
            plot_df["feature"],
            plot_df["variance_score"],
            color=COLOR_BLUE,
            edgecolor=COLOR_BLACK,
            linewidth=0.4,
        )

        self._scientific_style_axes(
            ax=ax,
            title="Top Features by Variance",
            xlabel="Variance",
            ylabel="Feature",
            add_grid_x=True,
            add_grid_y=False,
        )

        plt.tight_layout()

    def plot_selection_counts(self, figsize: tuple = (9, 5)) -> None:
        self._check_fitted()

        overview = self.get_selection_overview().copy()
        overview = overview.sort_values("selected_n", ascending=False)

        fig, ax = plt.subplots(figsize=figsize)
        ax.bar(
            overview["method"],
            overview["selected_n"],
            color=COLOR_BLUE,
            edgecolor=COLOR_BLACK,
            linewidth=0.5,
        )

        self._scientific_style_axes(
            ax=ax,
            title="Number of Features Selected per Method",
            xlabel="Method",
            ylabel="Selected Features",
            add_grid_y=True,
            add_grid_x=False,
        )

        ax.tick_params(axis="x", rotation=35)

        plt.tight_layout()

    def plot_correlation_matrix(
        self,
        columns: Union[str, Sequence[str]] = "selected",
        max_features: int = 25,
        figsize: tuple = (10, 8),
        annotate: bool = True,
    ) -> None:
        self._check_fitted()

        cols = self._resolve_columns_input(columns)
        cols = cols[:max_features]

        if len(cols) == 0:
            raise ValueError("No columns available to plot.")

        corr = self.X_[cols].corr()

        fig, ax = plt.subplots(figsize=figsize)
        im = ax.imshow(corr.values, cmap=self._get_diverging_cmap(), vmin=-1, vmax=1, aspect="auto")

        ax.set_title("Correlation Matrix", fontsize=13, fontweight="bold", color=COLOR_BLACK, pad=12)
        ax.set_xticks(range(len(cols)))
        ax.set_xticklabels(cols, rotation=90, fontsize=9, color=COLOR_BLACK)
        ax.set_yticks(range(len(cols)))
        ax.set_yticklabels(cols, fontsize=9, color=COLOR_BLACK)

        for spine in ax.spines.values():
            spine.set_color(COLOR_GREY)
            spine.set_linewidth(0.8)

        if annotate:
            for i in range(corr.shape[0]):
                for j in range(corr.shape[1]):
                    value = corr.iloc[i, j]
                    ax.text(
                        j,
                        i,
                        f"{value:.2f}",
                        ha="center",
                        va="center",
                        fontsize=7,
                        color=COLOR_BLACK,
                    )

        cbar = fig.colorbar(im, ax=ax)
        cbar.ax.tick_params(labelsize=9, colors=COLOR_BLACK)
        cbar.outline.set_edgecolor(COLOR_GREY)
        cbar.outline.set_linewidth(0.8)

        plt.tight_layout()

    def plot_overlap_heatmap(
        self,
        metric: str = "jaccard",
        figsize: tuple = (8, 6),
        annotate: bool = True,
    ) -> None:
        self._check_fitted()

        mat = self.get_method_overlap_table(metric=metric)

        fig, ax = plt.subplots(figsize=figsize)
        im = ax.imshow(mat.values, cmap=self._get_blue_cmap(), aspect="auto")

        ax.set_title(
            f"Method Overlap Heatmap ({metric.capitalize()})",
            fontsize=13,
            fontweight="bold",
            color=COLOR_BLACK,
            pad=12,
        )
        ax.set_xticks(range(len(mat.columns)))
        ax.set_xticklabels(mat.columns, rotation=45, ha="right", fontsize=9, color=COLOR_BLACK)
        ax.set_yticks(range(len(mat.index)))
        ax.set_yticklabels(mat.index, fontsize=9, color=COLOR_BLACK)

        for spine in ax.spines.values():
            spine.set_color(COLOR_GREY)
            spine.set_linewidth(0.8)

        if annotate:
            for i in range(mat.shape[0]):
                for j in range(mat.shape[1]):
                    val = mat.iloc[i, j]
                    txt = f"{val:.2f}" if metric == "jaccard" else f"{int(val)}"
                    ax.text(
                        j,
                        i,
                        txt,
                        ha="center",
                        va="center",
                        fontsize=9,
                        color=COLOR_BLACK,
                    )

        cbar = fig.colorbar(im, ax=ax)
        cbar.ax.tick_params(labelsize=9, colors=COLOR_BLACK)
        cbar.outline.set_edgecolor(COLOR_GREY)
        cbar.outline.set_linewidth(0.8)

        plt.tight_layout()

    def plot_correlation_pairs(
        self,
        threshold: float = 0.8,
        top_n: int = 20,
        figsize: tuple = (10, 7),
    ) -> None:
        self._check_fitted()

        pairs = self.get_correlation_pairs_table(threshold=threshold)
        if pairs.empty:
            raise ValueError(f"No correlation pairs found at threshold >= {threshold}.")

        pairs = pairs.head(top_n).copy()
        pairs["pair"] = pairs["feature_1"] + " vs " + pairs["feature_2"]
        pairs = pairs.iloc[::-1]

        fig, ax = plt.subplots(figsize=figsize)
        ax.barh(
            pairs["pair"],
            pairs["abs_correlation"],
            color=COLOR_BLUE,
            edgecolor=COLOR_BLACK,
            linewidth=0.4,
        )

        self._scientific_style_axes(
            ax=ax,
            title=f"Highly Correlated Feature Pairs (|r| ≥ {threshold:.2f})",
            xlabel="Absolute Correlation",
            ylabel="Feature Pair",
            add_grid_x=True,
            add_grid_y=False,
        )

        ax.axvline(threshold, color=COLOR_RED, linestyle="--", linewidth=1.2, alpha=0.9)

        plt.tight_layout()


# _SML_FS_LOGGING_PATCH
from scientific_ml_modules.utils.logging_utils import instrument_method
for _name in [
    "fit", "transform", "fit_transform", "get_selected_columns", "get_filtered_data",
    "get_feature_summary", "get_selection_overview", "get_method_selection_matrix",
    "get_rank_table", "get_method_overlap_table", "get_correlation_pairs_table",
    "plot_votes", "plot_mutual_info", "plot_permutation_importance", "plot_variance",
    "plot_selection_counts", "plot_correlation_matrix", "plot_overlap_heatmap", "plot_correlation_pairs",
    "_run_mutual_info", "_run_variance", "_run_correlation_filter", "_run_permutation", "_run_sequential"
]:
    instrument_method(FeatureSelector, _name, label=f"FEATURE_SELECTION:{_name}")

