from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.ticker import PercentFormatter
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures, PowerTransformer, QuantileTransformer


COLOR_BLACK = "#111111"
COLOR_BLUE = "#1F4E79"
COLOR_GREY = "#6E7B8B"
COLOR_RED = "#B22222"
COLOR_LIGHT_GREY = "#D9DEE5"
COLOR_GRID = "#D0D7DE"


def split_column_types(df: pd.DataFrame) -> Dict[str, List[str]]:
    return {
        "numerical": df.select_dtypes(include="number").columns.tolist(),
        "categorical_text": df.select_dtypes(include=["object", "category", "string"]).columns.tolist(),
        "date": df.select_dtypes(include=["datetime", "datetimetz"]).columns.tolist(),
    }


def find_overlaps(type_map: Dict[str, List[str]]) -> Dict[str, List[str]]:
    overlaps: Dict[str, List[str]] = {}
    keys = list(type_map.keys())

    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            left_key, right_key = keys[i], keys[j]
            common_cols = sorted(set(type_map[left_key]).intersection(type_map[right_key]))
            if common_cols:
                overlaps[f"{left_key} ∩ {right_key}"] = common_cols

    return overlaps


def force_column_types(
    df: pd.DataFrame,
    date_cols: List[str],
    categorical_cols: List[str],
    numerical_cols: List[str],
) -> pd.DataFrame:
    out = df.copy()

    for col in date_cols:
        if col in out.columns:
            out[col] = pd.to_datetime(out[col], errors="coerce")

    for col in categorical_cols:
        if col in out.columns:
            out[col] = out[col].astype("string")

    for col in numerical_cols:
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")

    return out


def apply_index_columns(df: pd.DataFrame, index_cols: List[str]) -> pd.DataFrame:
    out = df.copy()
    valid_index_cols = [col for col in index_cols if col in out.columns]

    if valid_index_cols:
        out = out.set_index(valid_index_cols, drop=False)

    return out


def drop_missing_target_rows(df: pd.DataFrame, target_col: str) -> Tuple[pd.DataFrame, int]:
    before = len(df)
    out = df.dropna(subset=[target_col]).copy()
    dropped = before - len(out)
    return out, dropped


def get_safe_stratify_vector(y: pd.Series, task_type: str):
    if task_type != "Classification":
        return None

    counts = y.value_counts(dropna=False)

    if y.nunique(dropna=False) < 2:
        return None

    if counts.min() < 2:
        return None

    return y


def split_random_train_test(
    df: pd.DataFrame,
    target_col: str,
    task_type: str,
    test_size: float,
    random_state: int = 42,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    y = df[target_col]
    stratify_vector = get_safe_stratify_vector(y, task_type)

    train_df, test_df = train_test_split(
        df,
        test_size=test_size,
        random_state=random_state,
        shuffle=True,
        stratify=stratify_vector,
    )

    return train_df.copy(), test_df.copy()


def split_date_train_test(
    df: pd.DataFrame,
    split_date_col: str,
    split_date_value: Any,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    out = df.copy()

    if split_date_col not in out.columns:
        raise ValueError(f"Date column '{split_date_col}' was not found.")

    out[split_date_col] = pd.to_datetime(out[split_date_col], errors="coerce")
    out = out.dropna(subset=[split_date_col]).sort_values(split_date_col)

    cutoff = pd.to_datetime(split_date_value)

    train_df = out[out[split_date_col] <= cutoff].copy()
    test_df = out[out[split_date_col] > cutoff].copy()

    if train_df.empty:
        raise ValueError("Train set is empty. Choose a later split date.")

    if test_df.empty:
        raise ValueError("Test set is empty. Choose an earlier split date.")

    return train_df, test_df


@dataclass
class ProcessedOutput:
    original_df: pd.DataFrame
    original_train_df: pd.DataFrame
    original_test_df: pd.DataFrame
    processed_train_df: pd.DataFrame
    processed_test_df: pd.DataFrame
    X_train: pd.DataFrame
    X_test: pd.DataFrame
    y_train: Optional[pd.Series]
    y_test: Optional[pd.Series]
    combined_audit_df: pd.DataFrame
    missing_report_before: pd.DataFrame
    missing_report_after_train: pd.DataFrame
    missing_report_after_test: pd.DataFrame
    strategies_applied: Dict[str, Any]


class DataProcessingModule:
    """
    Train-aware data processing module.

    Main principles
    ---------------
    1. Statistics are fitted on train only.
    2. The learned rules are applied to test.
    3. An audit table is preserved with:
       - original columns suffixed with `_original`
       - processed columns
       - split flag
       - keep/remove row flag
       - remove reason
    """

    ROW_ID = "__row_id__"
    SPLIT_COL = "__dataset_split__"
    KEEP_COL = "__keep_row__"
    REMOVE_REASON_COL = "__remove_reason__"

    COLOR_BLACK = COLOR_BLACK
    COLOR_BLUE = COLOR_BLUE
    COLOR_GREY = COLOR_GREY
    COLOR_RED = COLOR_RED
    COLOR_LIGHT_GREY = COLOR_LIGHT_GREY
    COLOR_GRID = COLOR_GRID

    def __init__(
        self,
        df: pd.DataFrame,
        target_col: Optional[str] = None,
        task_type: str = "Classification",
        config: Optional[Dict[str, Any]] = None,
    ):
        self.original_df = df.copy()
        self.target_col = target_col
        self.task_type = task_type
        self.config = config or {}

        self.fitted_strategy_: Dict[str, Any] = {
            "config_used": self.config,
            "type_map_before": {},
            "type_map_after_force": {},
            "overlaps_before": {},
            "overlaps_after_force": {},
            "missing": {},
            "drop_rows_if_na": {},
            "encoding": {},
            "log_transform": {},
            "binning": {},
            "polynomial_features": {},
            "scalers": {},
            "transforms": {},
            "duplicate_removal": {},
            "row_actions": {},
        }

        self._label_maps: Dict[str, Dict[Any, int]] = {}
        self._onehot_columns_: List[str] = []
        self._poly_model_: Optional[PolynomialFeatures] = None
        self._poly_input_columns_: List[str] = []
        self._poly_output_columns_: List[str] = []

    @staticmethod
    def split_column_types(df: pd.DataFrame) -> Dict[str, List[str]]:
        return split_column_types(df)

    @staticmethod
    def find_overlaps(type_map: Dict[str, List[str]]) -> Dict[str, List[str]]:
        return find_overlaps(type_map)

    @staticmethod
    def force_column_types(
        df: pd.DataFrame,
        date_cols: List[str],
        categorical_cols: List[str],
        numerical_cols: List[str],
    ) -> pd.DataFrame:
        return force_column_types(df, date_cols, categorical_cols, numerical_cols)

    @staticmethod
    def apply_index_columns(df: pd.DataFrame, index_cols: List[str]) -> pd.DataFrame:
        return apply_index_columns(df, index_cols)

    @staticmethod
    def drop_missing_target_rows(df: pd.DataFrame, target_col: str) -> Tuple[pd.DataFrame, int]:
        return drop_missing_target_rows(df, target_col)

    @staticmethod
    def get_safe_stratify_vector(y: pd.Series, task_type: str):
        return get_safe_stratify_vector(y, task_type)

    @staticmethod
    def split_random_train_test(
        df: pd.DataFrame,
        target_col: str,
        task_type: str,
        test_size: float,
        random_state: int = 42,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        return split_random_train_test(df, target_col, task_type, test_size, random_state)

    @staticmethod
    def split_date_train_test(
        df: pd.DataFrame,
        split_date_col: str,
        split_date_value: Any,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        return split_date_train_test(df, split_date_col, split_date_value)

    @staticmethod
    def _apply_scientific_plot_style(ax: plt.Axes) -> plt.Axes:
        ax.set_facecolor("white")
        ax.grid(True, axis="y", color=COLOR_GRID, linewidth=0.8, alpha=0.9)
        ax.set_axisbelow(True)

        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_color(COLOR_LIGHT_GREY)
        ax.spines["bottom"].set_color(COLOR_LIGHT_GREY)
        ax.spines["left"].set_linewidth(0.8)
        ax.spines["bottom"].set_linewidth(0.8)

        ax.tick_params(axis="x", colors=COLOR_BLACK, labelsize=10)
        ax.tick_params(axis="y", colors=COLOR_BLACK, labelsize=10)
        ax.title.set_color(COLOR_BLACK)
        ax.xaxis.label.set_color(COLOR_BLACK)
        ax.yaxis.label.set_color(COLOR_BLACK)
        return ax

    @classmethod
    def _set_global_plot_params(cls) -> None:
        plt.rcParams.update(
            {
                "figure.facecolor": "white",
                "axes.facecolor": "white",
                "savefig.facecolor": "white",
                "axes.edgecolor": COLOR_LIGHT_GREY,
                "axes.labelcolor": COLOR_BLACK,
                "axes.titlecolor": COLOR_BLACK,
                "xtick.color": COLOR_BLACK,
                "ytick.color": COLOR_BLACK,
                "grid.color": COLOR_GRID,
                "grid.linestyle": "-",
                "grid.linewidth": 0.8,
                "axes.grid": False,
                "font.size": 10,
                "axes.titlesize": 13,
                "axes.labelsize": 11,
                "legend.fontsize": 10,
                "figure.titlesize": 14,
            }
        )

    @classmethod
    def scientific_palette(cls) -> Dict[str, str]:
        return {
            "black": COLOR_BLACK,
            "blue": COLOR_BLUE,
            "grey": COLOR_GREY,
            "red": COLOR_RED,
            "light_grey": COLOR_LIGHT_GREY,
            "grid": COLOR_GRID,
        }

    @staticmethod
    def missing_report(df: pd.DataFrame) -> pd.DataFrame:
        report = pd.DataFrame(
            {
                "column": df.columns,
                "missing_n": df.isna().sum().values,
                "missing_pct": (df.isna().mean().values * 100.0),
                "dtype": df.dtypes.astype(str).values,
            }
        )
        return report.sort_values(
            ["missing_pct", "missing_n", "column"],
            ascending=[False, False, True],
        ).reset_index(drop=True)

    @staticmethod
    def _as_list(value: Optional[Any]) -> List[Any]:
        if value is None:
            return []
        if isinstance(value, list):
            return value
        return [value]

    def _ensure_row_id(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        if self.ROW_ID not in out.columns:
            out[self.ROW_ID] = np.arange(len(out))
        return out

    def _init_audit(self, df: pd.DataFrame) -> pd.DataFrame:
        return pd.DataFrame(
            {
                self.ROW_ID: df[self.ROW_ID].values,
                self.SPLIT_COL: "unassigned",
                self.KEEP_COL: True,
                self.REMOVE_REASON_COL: "",
            }
        )

    def _update_audit_for_removed_rows(
        self,
        audit: pd.DataFrame,
        row_ids: List[Any],
        reason: str,
    ) -> pd.DataFrame:
        if not row_ids:
            return audit

        mask = audit[self.ROW_ID].isin(row_ids)
        audit.loc[mask, self.KEEP_COL] = False
        existing = audit.loc[mask, self.REMOVE_REASON_COL].astype(str)
        audit.loc[mask, self.REMOVE_REASON_COL] = np.where(
            existing.eq("") | existing.isna(),
            reason,
            existing + " | " + reason,
        )
        return audit

    def _apply_force_types(self, df: pd.DataFrame) -> pd.DataFrame:
        cfg = self.config.get("force_types", {})
        if not cfg:
            return df.copy()

        return force_column_types(
            df=df,
            date_cols=cfg.get("date_cols", []),
            categorical_cols=cfg.get("categorical_cols", []),
            numerical_cols=cfg.get("numerical_cols", []),
        )

    def _apply_index_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        index_cols = self.config.get("index_columns", [])
        if not index_cols:
            return df.copy()
        return apply_index_columns(df, index_cols=index_cols)

    def _remove_duplicates_before_split(
        self,
        df: pd.DataFrame,
        audit: pd.DataFrame,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        cfg = self.config.get("remove_duplicates", {})
        if not cfg or not cfg.get("enabled", False):
            return df.copy(), audit

        subset = cfg.get("subset")
        keep = cfg.get("keep", "first")

        dup_mask = df.duplicated(subset=subset, keep=keep)
        removed_row_ids = df.loc[dup_mask, self.ROW_ID].tolist()

        self.fitted_strategy_["duplicate_removal"] = {
            "enabled": True,
            "subset": subset,
            "keep": keep,
            "removed_n": int(dup_mask.sum()),
        }

        audit = self._update_audit_for_removed_rows(audit, removed_row_ids, "removed_duplicate")
        out = df.loc[~dup_mask].copy()
        return out, audit

    def _drop_missing_target_before_split(
        self,
        df: pd.DataFrame,
        audit: pd.DataFrame,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        if not self.target_col:
            return df.copy(), audit

        if self.target_col not in df.columns:
            raise ValueError(f"target_col='{self.target_col}' was not found in the dataframe.")

        miss_mask = df[self.target_col].isna()
        removed_row_ids = df.loc[miss_mask, self.ROW_ID].tolist()

        audit = self._update_audit_for_removed_rows(audit, removed_row_ids, "missing_target")
        out = df.loc[~miss_mask].copy()

        self.fitted_strategy_["row_actions"]["drop_missing_target_rows"] = {
            "target_col": self.target_col,
            "removed_n": int(miss_mask.sum()),
        }
        return out, audit

    def _split(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        split_cfg = self.config.get(
            "split",
            {"method": "random", "test_size": 0.2, "random_state": 42},
        )
        method = split_cfg.get("method", "random")

        if method == "random":
            if self.target_col is None:
                raise ValueError("target_col is required for random train/test split.")
            return split_random_train_test(
                df=df,
                target_col=self.target_col,
                task_type=self.task_type,
                test_size=split_cfg.get("test_size", 0.2),
                random_state=split_cfg.get("random_state", 42),
            )

        if method == "date":
            return split_date_train_test(
                df=df,
                split_date_col=split_cfg["split_date_col"],
                split_date_value=split_cfg["split_date_value"],
            )

        raise ValueError(f"Unsupported split method: {method}")

    def _set_split_flag(
        self,
        audit: pd.DataFrame,
        train_df: pd.DataFrame,
        test_df: pd.DataFrame,
    ) -> pd.DataFrame:
        audit.loc[audit[self.ROW_ID].isin(train_df[self.ROW_ID]), self.SPLIT_COL] = "train"
        audit.loc[audit[self.ROW_ID].isin(test_df[self.ROW_ID]), self.SPLIT_COL] = "test"
        return audit

    def _get_columns_by_type(self, df: pd.DataFrame) -> Dict[str, List[str]]:
        type_map = split_column_types(df)
        excluded = {self.target_col, self.ROW_ID}
        for key in ["numerical", "categorical_text", "date"]:
            type_map[key] = [c for c in type_map[key] if c not in excluded]
        return type_map

    def _resolve_missing_config_for_col(self, col: str, df: pd.DataFrame) -> Dict[str, Any]:
        missing_cfg = self.config.get("missing", {})
        per_col = missing_cfg.get("per_column", {})
        if col in per_col:
            return per_col[col]

        type_map = self._get_columns_by_type(df)
        if col in type_map["numerical"]:
            return missing_cfg.get("default_numeric", {"strategy": "none"})
        if col in type_map["categorical_text"] or col in type_map["date"]:
            return missing_cfg.get("default_categorical", {"strategy": "none"})
        return {"strategy": "none"}

    def _fit_fill_value(self, train_df: pd.DataFrame, col: str, cfg: Dict[str, Any]) -> Dict[str, Any]:
        strategy = cfg.get("strategy", "none")
        groupby = cfg.get("groupby")
        fill_value = cfg.get("fill_value")

        result: Dict[str, Any] = {
            "strategy": strategy,
            "groupby": groupby,
            "fill_value": fill_value,
            "sort_by": cfg.get("sort_by"),
        }

        if strategy == "none":
            return result

        if strategy == "constant":
            result["global_fill"] = fill_value
            return result

        if strategy in {"mean", "average"}:
            result["global_fill"] = pd.to_numeric(train_df[col], errors="coerce").mean()
            return result

        if strategy == "median":
            result["global_fill"] = pd.to_numeric(train_df[col], errors="coerce").median()
            return result

        if strategy == "mode":
            mode = train_df[col].mode(dropna=True)
            result["global_fill"] = None if mode.empty else mode.iloc[0]
            return result

        if strategy in {"group_mean", "group_average", "group_median", "group_mode"}:
            if not groupby:
                raise ValueError(f"{strategy} for column '{col}' requires `groupby`.")
            valid_groupby = [g for g in groupby if g in train_df.columns]
            if not valid_groupby:
                raise ValueError(f"groupby columns not found for column '{col}'.")

            if strategy in {"group_mean", "group_average"}:
                stats = train_df.groupby(valid_groupby, dropna=False)[col].mean()
                global_fill = pd.to_numeric(train_df[col], errors="coerce").mean()
            elif strategy == "group_median":
                stats = train_df.groupby(valid_groupby, dropna=False)[col].median()
                global_fill = pd.to_numeric(train_df[col], errors="coerce").median()
            else:
                stats = train_df.groupby(valid_groupby, dropna=False)[col].agg(
                    lambda s: s.mode(dropna=True).iloc[0] if not s.mode(dropna=True).empty else np.nan
                )
                mode = train_df[col].mode(dropna=True)
                global_fill = None if mode.empty else mode.iloc[0]

            result["group_fill_map"] = {
                key if isinstance(key, tuple) else (key,): value
                for key, value in stats.to_dict().items()
            }
            result["global_fill"] = global_fill
            result["groupby"] = valid_groupby
            return result

        if strategy in {"ffill", "group_ffill", "drop_rows"}:
            return result

        raise ValueError(f"Unsupported missing strategy '{strategy}' for column '{col}'.")

    def _apply_fill_value(self, df: pd.DataFrame, col: str, fit_info: Dict[str, Any]) -> pd.DataFrame:
        out = df.copy()
        strategy = fit_info.get("strategy", "none")

        if strategy == "none":
            return out

        if strategy in {"constant", "mean", "average", "median", "mode"}:
            out[col] = out[col].fillna(fit_info.get("global_fill"))
            return out

        if strategy in {"group_mean", "group_average", "group_median", "group_mode"}:
            groupby = fit_info.get("groupby", [])
            fill_map = fit_info.get("group_fill_map", {})
            global_fill = fit_info.get("global_fill")

            keys = out[groupby].apply(lambda row: tuple(row.tolist()), axis=1)
            group_fill_values = keys.map(fill_map)
            out[col] = out[col].fillna(group_fill_values).fillna(global_fill)
            return out

        if strategy == "ffill":
            sort_by = [c for c in self._as_list(fit_info.get("sort_by")) if c in out.columns]
            if sort_by:
                out = out.sort_values(sort_by).copy()
            out[col] = out[col].ffill()
            return out

        if strategy == "group_ffill":
            groupby = [g for g in self._as_list(fit_info.get("groupby")) if g in out.columns]
            sort_by = [c for c in self._as_list(fit_info.get("sort_by")) if c in out.columns]

            if groupby or sort_by:
                out = out.sort_values(groupby + sort_by).copy()

            if groupby:
                out[col] = out.groupby(groupby, dropna=False)[col].ffill()
            else:
                out[col] = out[col].ffill()
            return out

        return out

    def _fit_missing(self, train_df: pd.DataFrame) -> None:
        missing_fit: Dict[str, Dict[str, Any]] = {}
        for col in train_df.columns:
            if col in {self.ROW_ID, self.target_col}:
                continue
            cfg = self._resolve_missing_config_for_col(col, train_df)
            fit_info = self._fit_fill_value(train_df, col, cfg)
            missing_fit[col] = fit_info

        self.fitted_strategy_["missing"] = missing_fit

    def _apply_missing(
        self,
        df: pd.DataFrame,
        audit: pd.DataFrame,
        dataset_name: str,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        out = df.copy()

        for col, fit_info in self.fitted_strategy_["missing"].items():
            if col in out.columns:
                out = self._apply_fill_value(out, col, fit_info)

        drop_cfg = self.config.get("drop_rows_if_na", {})
        if drop_cfg.get("enabled", False):
            subset = drop_cfg.get("subset") or [c for c in out.columns if c != self.ROW_ID]
            subset = [c for c in subset if c in out.columns]
            if subset:
                miss_mask = out[subset].isna().any(axis=1)
                removed_row_ids = out.loc[miss_mask, self.ROW_ID].tolist()
                audit = self._update_audit_for_removed_rows(
                    audit,
                    removed_row_ids,
                    f"drop_rows_if_na_{dataset_name}",
                )
                out = out.loc[~miss_mask].copy()

        for col, fit_info in self.fitted_strategy_["missing"].items():
            if col in out.columns and fit_info.get("strategy") == "drop_rows":
                miss_mask = out[col].isna()
                removed_row_ids = out.loc[miss_mask, self.ROW_ID].tolist()
                audit = self._update_audit_for_removed_rows(
                    audit,
                    removed_row_ids,
                    f"missing_drop_rows:{col}:{dataset_name}",
                )
                out = out.loc[~miss_mask].copy()

        return out, audit

    def _fit_label_encoding(self, train_df: pd.DataFrame) -> None:
        enc_cfg = self.config.get("encoding", {})
        per_col = enc_cfg.get("per_column", {})
        encoding_info: Dict[str, Dict[str, Any]] = {}

        for col, cfg in per_col.items():
            if col not in train_df.columns:
                continue

            strategy = cfg.get("strategy", "none")
            if strategy == "label":
                series = train_df[col].astype("string").fillna("__nan__")
                categories = pd.Index(series.unique()).tolist()
                mapping = {cat: i for i, cat in enumerate(categories)}
                self._label_maps[col] = mapping
                encoding_info[col] = {
                    "strategy": "label",
                    "mapping": mapping,
                    "unknown_value": cfg.get("unknown_value", -1),
                }
            elif strategy == "onehot":
                encoding_info[col] = {
                    "strategy": "onehot",
                    "drop_first": cfg.get("drop_first", False),
                    "dummy_na": cfg.get("dummy_na", False),
                }

        self.fitted_strategy_["encoding"] = encoding_info

    def _apply_encoding(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        onehot_cols: List[str] = []

        for col, info in self.fitted_strategy_["encoding"].items():
            if col not in out.columns:
                continue

            if info["strategy"] == "label":
                mapping = info["mapping"]
                unknown_value = info.get("unknown_value", -1)
                out[col] = (
                    out[col]
                    .astype("string")
                    .fillna("__nan__")
                    .map(mapping)
                    .fillna(unknown_value)
                    .astype(int)
                )
            elif info["strategy"] == "onehot":
                onehot_cols.append(col)

        if onehot_cols:
            onehot_parts = []
            for col in onehot_cols:
                info = self.fitted_strategy_["encoding"][col]
                dummies = pd.get_dummies(
                    out[col].astype("string"),
                    prefix=col,
                    drop_first=info.get("drop_first", False),
                    dummy_na=info.get("dummy_na", False),
                )
                onehot_parts.append(dummies)

            onehot_df = pd.concat(onehot_parts, axis=1) if onehot_parts else pd.DataFrame(index=out.index)

            if not self._onehot_columns_:
                self._onehot_columns_ = onehot_df.columns.tolist()

            onehot_df = onehot_df.reindex(columns=self._onehot_columns_, fill_value=0)
            out = pd.concat([out.drop(columns=onehot_cols), onehot_df], axis=1)

        return out

    def _fit_polynomial_features(self, train_df: pd.DataFrame) -> None:
        cfg = self.config.get("polynomial_features", {})
        if not cfg or not cfg.get("enabled", False):
            return

        columns = [c for c in cfg.get("columns", []) if c in train_df.columns]
        if not columns:
            return

        model = PolynomialFeatures(
            degree=cfg.get("degree", 2),
            include_bias=cfg.get("include_bias", False),
            interaction_only=cfg.get("interaction_only", False),
        )
        model.fit(train_df[columns])

        self._poly_model_ = model
        self._poly_input_columns_ = columns
        self._poly_output_columns_ = model.get_feature_names_out(columns).tolist()

        self.fitted_strategy_["polynomial_features"] = {
            "enabled": True,
            "columns": columns,
            "degree": cfg.get("degree", 2),
            "include_bias": cfg.get("include_bias", False),
            "interaction_only": cfg.get("interaction_only", False),
            "output_columns": self._poly_output_columns_,
        }

    def _apply_polynomial_features(self, df: pd.DataFrame) -> pd.DataFrame:
        if self._poly_model_ is None or not self._poly_input_columns_:
            return df.copy()

        out = df.copy()
        poly_values = self._poly_model_.transform(out[self._poly_input_columns_])
        poly_df = pd.DataFrame(poly_values, columns=self._poly_output_columns_, index=out.index)

        out = out.drop(columns=[c for c in self._poly_input_columns_ if c in out.columns])
        out = pd.concat([out, poly_df], axis=1)
        return out

    def _fit_log_transform(self, train_df: pd.DataFrame) -> None:
        cfg = self.config.get("log_transform", {})
        per_col = cfg.get("per_column", {})
        fitted: Dict[str, Dict[str, Any]] = {}

        for col, col_cfg in per_col.items():
            if col not in train_df.columns:
                continue

            mode = col_cfg.get("mode", "shift_log1p")
            groupby = col_cfg.get("groupby")
            info: Dict[str, Any] = {"mode": mode, "groupby": groupby}

            s = pd.to_numeric(train_df[col], errors="coerce")

            if mode == "signed_log1p":
                fitted[col] = info
                continue

            if groupby:
                valid_groupby = [g for g in groupby if g in train_df.columns]
                mins = train_df.groupby(valid_groupby, dropna=False)[col].min()
                shift_map: Dict[Tuple[Any, ...], float] = {}
                for key, value in mins.to_dict().items():
                    key_tuple = key if isinstance(key, tuple) else (key,)
                    shift_map[key_tuple] = 0.0 if pd.isna(value) or value > -1 else float(-value + 1.0)

                global_min = s.min()
                global_shift = 0.0 if pd.isna(global_min) or global_min > -1 else float(-global_min + 1.0)

                info["groupby"] = valid_groupby
                info["shift_map"] = shift_map
                info["global_shift"] = global_shift
            else:
                min_val = s.min()
                shift = 0.0 if pd.isna(min_val) or min_val > -1 else float(-min_val + 1.0)
                info["global_shift"] = shift

            fitted[col] = info

        self.fitted_strategy_["log_transform"] = fitted

    def _apply_log_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()

        for col, info in self.fitted_strategy_["log_transform"].items():
            if col not in out.columns:
                continue

            s = pd.to_numeric(out[col], errors="coerce")
            mode = info["mode"]

            if mode == "signed_log1p":
                out[col] = np.sign(s) * np.log1p(np.abs(s))
                continue

            if info.get("groupby"):
                groupby = info["groupby"]
                keys = out[groupby].apply(lambda row: tuple(row.tolist()), axis=1)
                shifts = keys.map(info["shift_map"]).fillna(info["global_shift"]).astype(float)
                out[col] = np.log1p(s + shifts)
            else:
                out[col] = np.log1p(s + float(info.get("global_shift", 0.0)))

        return out

    def _fit_binning(self, train_df: pd.DataFrame) -> None:
        cfg = self.config.get("binning", {})
        per_col = cfg.get("per_column", {})
        fitted: Dict[str, Dict[str, Any]] = {}

        for col, col_cfg in per_col.items():
            if col not in train_df.columns:
                continue

            n_bins = int(col_cfg.get("n_bins", 5))
            mode = col_cfg.get("mode", "cut")
            labels = col_cfg.get("labels", False)
            groupby = col_cfg.get("groupby")
            info: Dict[str, Any] = {
                "n_bins": n_bins,
                "mode": mode,
                "labels": labels,
                "groupby": groupby,
            }

            def _get_bins(series: pd.Series) -> List[float]:
                series = pd.to_numeric(series, errors="coerce").dropna()
                if series.empty:
                    return []
                if mode == "qcut":
                    q = min(n_bins, max(1, series.nunique()))
                    _, bins = pd.qcut(series, q=q, retbins=True, duplicates="drop")
                else:
                    _, bins = pd.cut(series, bins=n_bins, retbins=True, duplicates="drop")
                return np.unique(bins).tolist()

            if groupby:
                valid_groupby = [g for g in groupby if g in train_df.columns]
                group_edges: Dict[Tuple[Any, ...], List[float]] = {}
                for key, grp in train_df.groupby(valid_groupby, dropna=False):
                    bins = _get_bins(grp[col])
                    if bins:
                        group_edges[key if isinstance(key, tuple) else (key,)] = bins

                info["groupby"] = valid_groupby
                info["group_edges"] = group_edges
                info["global_edges"] = _get_bins(train_df[col])
            else:
                info["global_edges"] = _get_bins(train_df[col])

            fitted[col] = info

        self.fitted_strategy_["binning"] = fitted

    def _apply_binning(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()

        def _cut_with_edges(series: pd.Series, edges: List[float], labels: Any) -> pd.Series:
            if len(edges) < 2:
                return pd.Series(np.nan, index=series.index)

            if labels is False:
                numeric_bins = pd.cut(
                    series,
                    bins=np.unique(edges),
                    include_lowest=True,
                    labels=False,
                    duplicates="drop",
                )
                return pd.Series(numeric_bins, index=series.index, dtype="Float64")

            binned = pd.cut(
                series,
                bins=np.unique(edges),
                include_lowest=True,
                labels=labels,
                duplicates="drop",
            )
            return binned.astype("string")

        for col, info in self.fitted_strategy_["binning"].items():
            if col not in out.columns:
                continue

            labels = info.get("labels", False)
            s = pd.to_numeric(out[col], errors="coerce")

            if info.get("groupby"):
                result = pd.Series(index=out.index, dtype=object)
                keys = out[info["groupby"]].apply(lambda row: tuple(row.tolist()), axis=1)

                for key in keys.drop_duplicates():
                    idx = keys[keys == key].index
                    edges = info.get("group_edges", {}).get(key, info.get("global_edges", []))
                    result.loc[idx] = _cut_with_edges(s.loc[idx], edges, labels)

                if labels is False:
                    out[col] = pd.to_numeric(result, errors="coerce").astype("Float64")
                else:
                    out[col] = result.astype("string")
            else:
                out[col] = _cut_with_edges(s, info.get("global_edges", []), labels)

        return out

    def _fit_group_scaler(
        self,
        train_df: pd.DataFrame,
        col: str,
        groupby: Optional[List[str]],
        scaler_name: str,
    ) -> Dict[str, Any]:
        s = pd.to_numeric(train_df[col], errors="coerce")
        info: Dict[str, Any] = {"groupby": groupby, "scaler_name": scaler_name}

        if scaler_name == "standard":
            std = float(s.std(ddof=0))
            global_stats = {
                "mean": float(s.mean()),
                "std": 1.0 if std == 0 or np.isnan(std) else std,
            }
        elif scaler_name == "minmax":
            global_stats = {"min": float(s.min()), "max": float(s.max())}
        else:
            raise ValueError("Unsupported scaler_name.")

        info["global_stats"] = global_stats

        if groupby:
            valid_groupby = [g for g in groupby if g in train_df.columns]
            stats_map: Dict[Tuple[Any, ...], Dict[str, float]] = {}

            for key, grp in train_df.groupby(valid_groupby, dropna=False):
                gs = pd.to_numeric(grp[col], errors="coerce")
                if scaler_name == "standard":
                    std = float(gs.std(ddof=0))
                    stats_map[key if isinstance(key, tuple) else (key,)] = {
                        "mean": float(gs.mean()),
                        "std": 1.0 if std == 0 or np.isnan(std) else std,
                    }
                else:
                    stats_map[key if isinstance(key, tuple) else (key,)] = {
                        "min": float(gs.min()),
                        "max": float(gs.max()),
                    }

            info["groupby"] = valid_groupby
            info["group_stats"] = stats_map

        return info

    def _apply_group_scaler(self, df: pd.DataFrame, col: str, info: Dict[str, Any]) -> pd.Series:
        s = pd.to_numeric(df[col], errors="coerce")

        def _scale(series: pd.Series, stats: Dict[str, float], scaler_name: str) -> pd.Series:
            if scaler_name == "standard":
                denom = stats["std"]
                denom = 1.0 if denom == 0 or np.isnan(denom) else denom
                return (series - stats["mean"]) / denom

            denom = stats["max"] - stats["min"]
            denom = 1.0 if denom == 0 or np.isnan(denom) else denom
            return (series - stats["min"]) / denom

        if info.get("groupby"):
            keys = df[info["groupby"]].apply(lambda row: tuple(row.tolist()), axis=1)
            result = pd.Series(index=df.index, dtype=float)

            for key in keys.drop_duplicates():
                idx = keys[keys == key].index
                stats = info.get("group_stats", {}).get(key, info["global_stats"])
                result.loc[idx] = _scale(s.loc[idx], stats, info["scaler_name"])

            return result

        return _scale(s, info["global_stats"], info["scaler_name"])

    def _fit_per_group_sklearn_transformer(
        self,
        train_df: pd.DataFrame,
        col: str,
        groupby: Optional[List[str]],
        transformer_name: str,
        kwargs: Dict[str, Any],
    ) -> Dict[str, Any]:
        s = pd.to_numeric(train_df[col], errors="coerce")
        valid = s.notna()

        if valid.sum() == 0:
            return {
                "groupby": groupby,
                "transformer_name": transformer_name,
                "kwargs": kwargs,
                "global_transformer": None,
                "group_transformers": {},
            }

        global_transformer = (
            QuantileTransformer(**kwargs) if transformer_name == "quantile" else PowerTransformer(**kwargs)
        )
        global_transformer.fit(s.loc[valid].to_frame())

        info: Dict[str, Any] = {
            "groupby": groupby,
            "transformer_name": transformer_name,
            "kwargs": kwargs,
            "global_transformer": global_transformer,
            "group_transformers": {},
        }

        if groupby:
            valid_groupby = [g for g in groupby if g in train_df.columns]
            info["groupby"] = valid_groupby

            for key, grp in train_df.groupby(valid_groupby, dropna=False):
                gs = pd.to_numeric(grp[col], errors="coerce")
                valid_idx = gs.notna()
                if valid_idx.sum() < 3:
                    continue

                transformer = (
                    QuantileTransformer(**kwargs)
                    if transformer_name == "quantile"
                    else PowerTransformer(**kwargs)
                )
                transformer.fit(gs.loc[valid_idx].to_frame())
                info["group_transformers"][key if isinstance(key, tuple) else (key,)] = transformer

        return info

    def _apply_per_group_sklearn_transformer(self, df: pd.DataFrame, col: str, info: Dict[str, Any]) -> pd.Series:
        s = pd.to_numeric(df[col], errors="coerce")
        result = pd.Series(np.nan, index=df.index, dtype=float)

        def _apply_transform(idx: pd.Index, transformer: Any) -> None:
            if transformer is None:
                return
            vals = s.loc[idx]
            valid = vals.notna()
            if valid.sum() == 0:
                return
            transformed = transformer.transform(vals.loc[valid].to_frame()).ravel()
            result.loc[vals.loc[valid].index] = transformed

        if info.get("groupby"):
            keys = df[info["groupby"]].apply(lambda row: tuple(row.tolist()), axis=1)
            for key in keys.drop_duplicates():
                idx = keys[keys == key].index
                transformer = info.get("group_transformers", {}).get(key, info.get("global_transformer"))
                _apply_transform(idx, transformer)
            return result

        _apply_transform(df.index, info.get("global_transformer"))
        return result

    def _fit_scalers_and_transforms(self, train_df: pd.DataFrame) -> None:
        standard_cfg = self.config.get("standardize", {}).get("per_column", {})
        minmax_cfg = self.config.get("minmax_scale", {}).get("per_column", {})
        quantile_cfg = self.config.get("quantile_transform", {}).get("per_column", {})
        power_cfg = self.config.get("power_transform", {}).get("per_column", {})

        fitted_scalers: Dict[str, Dict[str, Any]] = {}
        fitted_transformers: Dict[str, Dict[str, Any]] = {}

        for col, cfg in standard_cfg.items():
            if col in train_df.columns:
                fitted_scalers[f"standard::{col}"] = self._fit_group_scaler(
                    train_df=train_df,
                    col=col,
                    groupby=cfg.get("groupby"),
                    scaler_name="standard",
                )

        for col, cfg in minmax_cfg.items():
            if col in train_df.columns:
                fitted_scalers[f"minmax::{col}"] = self._fit_group_scaler(
                    train_df=train_df,
                    col=col,
                    groupby=cfg.get("groupby"),
                    scaler_name="minmax",
                )

        for col, cfg in quantile_cfg.items():
            if col in train_df.columns:
                n_non_missing = int(train_df[col].notna().sum())
                default_n_quantiles = min(1000, max(10, n_non_missing)) if n_non_missing > 0 else 10
                kwargs = {
                    "n_quantiles": max(10, min(cfg.get("n_quantiles", default_n_quantiles), max(10, n_non_missing)))
                    if n_non_missing > 0
                    else 10,
                    "output_distribution": cfg.get("output_distribution", "normal"),
                    "random_state": cfg.get("random_state", 42),
                }
                fitted_transformers[f"quantile::{col}"] = self._fit_per_group_sklearn_transformer(
                    train_df=train_df,
                    col=col,
                    groupby=cfg.get("groupby"),
                    transformer_name="quantile",
                    kwargs=kwargs,
                )

        for col, cfg in power_cfg.items():
            if col in train_df.columns:
                kwargs = {
                    "method": cfg.get("method", "yeo-johnson"),
                    "standardize": cfg.get("standardize", True),
                }
                fitted_transformers[f"power::{col}"] = self._fit_per_group_sklearn_transformer(
                    train_df=train_df,
                    col=col,
                    groupby=cfg.get("groupby"),
                    transformer_name="power",
                    kwargs=kwargs,
                )

        self.fitted_strategy_["scalers"] = fitted_scalers
        self.fitted_strategy_["transforms"] = fitted_transformers

    def _apply_scalers_and_transforms(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()

        for key, info in self.fitted_strategy_.get("scalers", {}).items():
            _, col = key.split("::", 1)
            if col in out.columns:
                out[col] = self._apply_group_scaler(out, col, info)

        for key, info in self.fitted_strategy_.get("transforms", {}).items():
            _, col = key.split("::", 1)
            if col in out.columns:
                out[col] = self._apply_per_group_sklearn_transformer(out, col, info)

        return out

    def _fit_all_train_only_steps(self, train_df: pd.DataFrame) -> None:
        self._fit_missing(train_df)
        self._fit_log_transform(train_df)
        self._fit_binning(train_df)

        temp_train = train_df.copy()
        temp_train, _ = self._apply_missing(temp_train, self._init_audit(temp_train), dataset_name="train_fit")
        temp_train = self._apply_log_transform(temp_train)
        temp_train = self._apply_binning(temp_train)

        self._fit_label_encoding(temp_train)
        temp_train = self._apply_encoding(temp_train)

        self._fit_polynomial_features(temp_train)
        temp_train = self._apply_polynomial_features(temp_train)

        self._fit_scalers_and_transforms(temp_train)

    def _transform_dataset(
        self,
        df: pd.DataFrame,
        audit: pd.DataFrame,
        dataset_name: str,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        out = df.copy()

        out, audit = self._apply_missing(out, audit, dataset_name=dataset_name)
        out = self._apply_log_transform(out)
        out = self._apply_binning(out)
        out = self._apply_encoding(out)
        out = self._apply_polynomial_features(out)
        out = self._apply_scalers_and_transforms(out)

        return out, audit

    def _make_xy(
        self,
        train_df: pd.DataFrame,
        test_df: pd.DataFrame,
    ) -> Tuple[pd.DataFrame, pd.DataFrame, Optional[pd.Series], Optional[pd.Series]]:
        if self.target_col and self.target_col in train_df.columns:
            y_train = train_df[self.target_col].copy()
            X_train = train_df.drop(columns=[self.target_col]).copy()
        else:
            y_train = None
            X_train = train_df.copy()

        if self.target_col and self.target_col in test_df.columns:
            y_test = test_df[self.target_col].copy()
            X_test = test_df.drop(columns=[self.target_col]).copy()
        else:
            y_test = None
            X_test = test_df.copy()

        for special_col in [self.ROW_ID]:
            if special_col in X_train.columns:
                X_train = X_train.drop(columns=[special_col])
            if special_col in X_test.columns:
                X_test = X_test.drop(columns=[special_col])

        return X_train, X_test, y_train, y_test

    def plot_missing_report(
        self,
        report: Optional[pd.DataFrame] = None,
        top_n: Optional[int] = 30,
        min_missing_pct: float = 0.0,
        sort_by: str = "missing_pct",
        title: str = "Missing Data Profile",
        figsize: Tuple[float, float] = (12, 6),
    ) -> Figure:
        self._set_global_plot_params()

        required_cols = {"column", "missing_n", "missing_pct", "dtype"}
        if report is None:
            data = self.missing_report(self.original_df)
        elif isinstance(report, pd.DataFrame) and required_cols.issubset(report.columns):
            data = report.copy()
        else:
            data = self.missing_report(report)

        data = data.loc[data["missing_pct"] >= float(min_missing_pct)].copy()
        ascending = False if sort_by in {"missing_pct", "missing_n"} else True
        data = data.sort_values(sort_by, ascending=ascending)

        if top_n is not None:
            data = data.head(top_n)

        fig, ax = plt.subplots(figsize=figsize)

        if data.empty:
            ax.text(
                0.5,
                0.5,
                "No missing values for the selected filter.",
                ha="center",
                va="center",
                fontsize=12,
                color=COLOR_GREY,
                transform=ax.transAxes,
            )
            ax.set_xticks([])
            ax.set_yticks([])
            self._apply_scientific_plot_style(ax)
            fig.tight_layout()
            return fig

        y_pos = np.arange(len(data))
        bars = ax.barh(
            y_pos,
            data["missing_pct"].values,
            color=COLOR_BLUE,
            edgecolor=COLOR_BLACK,
            linewidth=0.5,
        )

        ax.set_yticks(y_pos)
        ax.set_yticklabels(data["column"].tolist())
        ax.invert_yaxis()
        ax.set_xlabel("Missing percentage")
        ax.set_ylabel("Column")
        ax.set_title(title, loc="left", pad=12, fontweight="bold")
        ax.xaxis.set_major_formatter(PercentFormatter(xmax=100))

        x_offset = max(float(data["missing_pct"].max()) * 0.01, 0.25)
        for bar, pct, n in zip(bars, data["missing_pct"].values, data["missing_n"].values):
            ax.text(
                float(bar.get_width()) + x_offset,
                bar.get_y() + bar.get_height() / 2,
                f"{pct:.1f}% | n={int(n)}",
                va="center",
                ha="left",
                fontsize=9,
                color=COLOR_BLACK,
            )

        self._apply_scientific_plot_style(ax)
        fig.tight_layout()
        return fig

    def plot_missing_comparison(
        self,
        missing_before: pd.DataFrame,
        missing_after_train: pd.DataFrame,
        missing_after_test: pd.DataFrame,
        top_n: int = 20,
        figsize: Tuple[float, float] = (14, 7),
    ) -> Figure:
        self._set_global_plot_params()

        merged = (
            missing_before[["column", "missing_pct"]]
            .rename(columns={"missing_pct": "before"})
            .merge(
                missing_after_train[["column", "missing_pct"]].rename(columns={"missing_pct": "train_after"}),
                on="column",
                how="outer",
            )
            .merge(
                missing_after_test[["column", "missing_pct"]].rename(columns={"missing_pct": "test_after"}),
                on="column",
                how="outer",
            )
            .fillna(0.0)
        )

        merged["max_missing"] = merged[["before", "train_after", "test_after"]].max(axis=1)
        merged = merged.sort_values(["max_missing", "column"], ascending=[False, True]).head(top_n)

        fig, ax = plt.subplots(figsize=figsize)
        x = np.arange(len(merged))
        width = 0.26

        ax.bar(
            x - width,
            merged["before"],
            width=width,
            color=COLOR_GREY,
            edgecolor=COLOR_BLACK,
            linewidth=0.4,
            label="Before",
        )
        ax.bar(
            x,
            merged["train_after"],
            width=width,
            color=COLOR_BLUE,
            edgecolor=COLOR_BLACK,
            linewidth=0.4,
            label="Train after",
        )
        ax.bar(
            x + width,
            merged["test_after"],
            width=width,
            color=COLOR_RED,
            edgecolor=COLOR_BLACK,
            linewidth=0.4,
            label="Test after",
        )

        ax.set_xticks(x)
        ax.set_xticklabels(merged["column"].tolist(), rotation=45, ha="right")
        ax.set_ylabel("Missing percentage")
        ax.set_xlabel("Column")
        ax.set_title("Missingness Before and After Processing", loc="left", pad=12, fontweight="bold")
        ax.yaxis.set_major_formatter(PercentFormatter(xmax=100))
        ax.legend(frameon=False)

        self._apply_scientific_plot_style(ax)
        fig.tight_layout()
        return fig

    def plot_split_summary(
        self,
        combined_audit_df: pd.DataFrame,
        figsize: Tuple[float, float] = (10, 5),
    ) -> Figure:
        self._set_global_plot_params()

        summary = (
            combined_audit_df.groupby([self.SPLIT_COL, self.KEEP_COL], dropna=False)
            .size()
            .unstack(fill_value=0)
            .rename(columns={True: "Kept", False: "Removed"})
        )

        ordered_index = [idx for idx in ["train", "test", "unassigned"] if idx in summary.index]
        summary = summary.reindex(ordered_index)

        fig, ax = plt.subplots(figsize=figsize)
        x = np.arange(len(summary.index))
        kept = summary.get("Kept", pd.Series(0, index=summary.index)).values
        removed = summary.get("Removed", pd.Series(0, index=summary.index)).values

        bars_kept = ax.bar(
            x,
            kept,
            color=COLOR_BLUE,
            edgecolor=COLOR_BLACK,
            linewidth=0.5,
            label="Kept",
        )
        bars_removed = ax.bar(
            x,
            removed,
            bottom=kept,
            color=COLOR_RED,
            edgecolor=COLOR_BLACK,
            linewidth=0.5,
            label="Removed",
        )

        ax.set_xticks(x)
        ax.set_xticklabels([str(v).title() for v in summary.index])
        ax.set_ylabel("Number of rows")
        ax.set_xlabel("Dataset segment")
        ax.set_title("Row Retention by Dataset Segment", loc="left", pad=12, fontweight="bold")
        ax.legend(frameon=False)

        for bars in [bars_kept, bars_removed]:
            for bar in bars:
                height = bar.get_height()
                if height > 0:
                    ax.text(
                        bar.get_x() + bar.get_width() / 2,
                        bar.get_y() + height / 2,
                        f"{int(height)}",
                        ha="center",
                        va="center",
                        color="white",
                        fontsize=10,
                        fontweight="bold",
                    )

        self._apply_scientific_plot_style(ax)
        fig.tight_layout()
        return fig

    def _build_combined_audit(
        self,
        original_df: pd.DataFrame,
        audit: pd.DataFrame,
        processed_train_df: pd.DataFrame,
        processed_test_df: pd.DataFrame,
    ) -> pd.DataFrame:
        original_part = original_df.copy()
        original_cols = [c for c in original_part.columns if c != self.ROW_ID]
        original_part = original_part.rename(columns={c: f"{c}_original" for c in original_cols})

        processed_all = pd.concat([processed_train_df, processed_test_df], axis=0, ignore_index=False).copy()
        processed_all = processed_all.drop_duplicates(subset=[self.ROW_ID], keep="last")

        combined = original_part.merge(audit, on=self.ROW_ID, how="left")
        combined = combined.merge(processed_all, on=self.ROW_ID, how="left", suffixes=("", "_processed"))
        return combined

    def process(self) -> ProcessedOutput:
        df = self._ensure_row_id(self.original_df)
        audit = self._init_audit(df)

        self.fitted_strategy_["type_map_before"] = split_column_types(df)
        self.fitted_strategy_["overlaps_before"] = find_overlaps(self.fitted_strategy_["type_map_before"])

        df = self._apply_force_types(df)
        self.fitted_strategy_["type_map_after_force"] = split_column_types(df)
        self.fitted_strategy_["overlaps_after_force"] = find_overlaps(self.fitted_strategy_["type_map_after_force"])

        df = self._apply_index_columns(df)
        missing_before = self.missing_report(df)

        base_df, audit = self._remove_duplicates_before_split(df, audit)
        base_df, audit = self._drop_missing_target_before_split(base_df, audit)

        original_train_df, original_test_df = self._split(base_df)
        audit = self._set_split_flag(audit, original_train_df, original_test_df)

        self._fit_all_train_only_steps(original_train_df)

        processed_train_df, audit = self._transform_dataset(original_train_df, audit, dataset_name="train")
        processed_test_df, audit = self._transform_dataset(original_test_df, audit, dataset_name="test")

        all_cols = sorted(set(processed_train_df.columns).union(processed_test_df.columns))
        processed_train_df = processed_train_df.reindex(columns=all_cols)
        processed_test_df = processed_test_df.reindex(columns=all_cols)

        X_train, X_test, y_train, y_test = self._make_xy(processed_train_df, processed_test_df)

        combined_audit_df = self._build_combined_audit(
            original_df=df,
            audit=audit,
            processed_train_df=processed_train_df,
            processed_test_df=processed_test_df,
        )

        missing_after_train = self.missing_report(processed_train_df)
        missing_after_test = self.missing_report(processed_test_df)

        return ProcessedOutput(
            original_df=df,
            original_train_df=original_train_df,
            original_test_df=original_test_df,
            processed_train_df=processed_train_df,
            processed_test_df=processed_test_df,
            X_train=X_train,
            X_test=X_test,
            y_train=y_train,
            y_test=y_test,
            combined_audit_df=combined_audit_df,
            missing_report_before=missing_before,
            missing_report_after_train=missing_after_train,
            missing_report_after_test=missing_after_test,
            strategies_applied=self.fitted_strategy_,
        )


# _SML_PROCESSING_LOGGING_PATCH
from scientific_ml_modules.utils.logging_utils import instrument_method
for _name in [
    "plot_missing_report", "plot_missing_comparison",
    "plot_split_summary", "process", "_fit_all_train_only_steps", "_transform_dataset",
    "_fit_missing", "_apply_missing", "_fit_encoding", "_apply_encoding" if False else "_apply_encoding",
    "_fit_scalers_and_transforms", "_apply_scalers_and_transforms"
]:
    if hasattr(DataProcessingModule, _name):
        instrument_method(DataProcessingModule, _name, label=f"PROCESSING:{_name}")

