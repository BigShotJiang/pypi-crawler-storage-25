
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.inspection import permutation_importance, partial_dependence

try:
    import shap
except Exception:
    shap = None

try:
    from lime.lime_tabular import LimeTabularExplainer
except Exception:
    LimeTabularExplainer = None

from scientific_ml_modules.utils.plot_style import (
    COLOR_BLUE,
    COLOR_GREY,
    scientific_barh,
    get_blue_cmap,
    set_scientific_plot_style,
    style_axes,
)

set_scientific_plot_style()


@dataclass
class TrainedModelBundle:
    model_name: str
    fitted_pipeline: Any
    config: Any
    task_type: str
    feature_names: list[str]
    target_name: str | None = None
    cv_metric_name: str | None = None
    cv_score_mean: float | None = None
    cv_score_std: float | None = None
    model_selection_row: dict[str, Any] | None = None
    full_metric_table: pd.DataFrame | None = None


@dataclass
class PermutationConfig:
    enabled: bool = True
    n_repeats: int = 10
    scoring: str | None = None
    max_samples: int | None = None


@dataclass
class SHAPConfig:
    enabled: bool = True
    sample_size: int = 300
    background_size: int = 100
    class_index: int | None = None
    max_display: int = 20
    check_additivity: bool = False


@dataclass
class LIMEConfig:
    enabled: bool = True
    sample_index: int = 0
    num_features: int = 10
    num_samples: int = 5000
    class_index: int | None = None


@dataclass
class PDPConfig:
    enabled: bool = True
    grid_resolution: int = 20
    percentiles: tuple[float, float] = (0.05, 0.95)
    kind: Literal["average", "individual", "both"] = "average"
    single_features: list[str] = field(default_factory=list)
    pair_features: list[tuple[str, str]] = field(default_factory=list)


@dataclass
class ExplainabilityConfig:
    dataset: Literal["train", "test"] = "train"
    top_n: int = 20
    random_state: int = 42
    n_jobs: int = 1
    logging_enabled: bool = True
    permutation: PermutationConfig = field(default_factory=PermutationConfig)
    shap: SHAPConfig = field(default_factory=SHAPConfig)
    lime: LIMEConfig = field(default_factory=LIMEConfig)
    pdp: PDPConfig = field(default_factory=PDPConfig)


class ExplainabilityConfigBuilder:
    def __init__(self):
        self._config = ExplainabilityConfig()

    def dataset(self, value: Literal["train", "test"]):
        self._config.dataset = value
        return self

    def top_n(self, value: int):
        self._config.top_n = int(value)
        return self

    def random_state(self, value: int):
        self._config.random_state = int(value)
        return self

    def n_jobs(self, value: int):
        self._config.n_jobs = int(value)
        return self

    def permutation(self, enabled: bool = True, n_repeats: int = 10, scoring: str | None = None, max_samples: int | None = None):
        self._config.permutation = PermutationConfig(enabled=enabled, n_repeats=n_repeats, scoring=scoring, max_samples=max_samples)
        return self

    def shap(
        self,
        enabled: bool = True,
        sample_size: int = 300,
        background_size: int = 100,
        class_index: int | None = None,
        max_display: int = 20,
        check_additivity: bool = False,
    ):
        self._config.shap = SHAPConfig(
            enabled=enabled,
            sample_size=sample_size,
            background_size=background_size,
            class_index=class_index,
            max_display=max_display,
            check_additivity=check_additivity,
        )
        return self

    def lime(self, enabled: bool = True, sample_index: int = 0, num_features: int = 10, num_samples: int = 5000, class_index: int | None = None):
        self._config.lime = LIMEConfig(enabled=enabled, sample_index=sample_index, num_features=num_features, num_samples=num_samples, class_index=class_index)
        return self

    def pdp(
        self,
        enabled: bool = True,
        grid_resolution: int = 20,
        percentiles: tuple[float, float] = (0.05, 0.95),
        kind: Literal["average", "individual", "both"] = "average",
        single_features: list[str] | None = None,
        pair_features: list[tuple[str, str]] | None = None,
    ):
        self._config.pdp = PDPConfig(
            enabled=enabled,
            grid_resolution=grid_resolution,
            percentiles=percentiles,
            kind=kind,
            single_features=[] if single_features is None else list(single_features),
            pair_features=[] if pair_features is None else list(pair_features),
        )
        return self

    def logging(self, enabled: bool = True):
        self._config.logging_enabled = bool(enabled)
        return self

    def build(self) -> ExplainabilityConfig:
        return deepcopy(self._config)


class ExplainableAIModule:
    def __init__(
        self,
        trained_bundle: TrainedModelBundle,
        X_train: pd.DataFrame,
        y_train=None,
        X_test: pd.DataFrame | None = None,
        y_test=None,
        config: ExplainabilityConfig | None = None,
    ):
        self.bundle = trained_bundle
        self.pipeline = trained_bundle.fitted_pipeline
        self.task_type = trained_bundle.task_type
        self.model_name = trained_bundle.model_name
        self.feature_names = list(X_train.columns)

        self.X_train = X_train.copy()
        self.y_train = pd.Series(y_train).copy() if y_train is not None else None
        self.X_test = X_test.copy() if X_test is not None else None
        self.y_test = pd.Series(y_test).copy() if y_test is not None else None

        self.config = deepcopy(config) if config is not None else ExplainabilityConfig()

        self.feature_importance_result_: dict[str, Any] | None = None
        self.coefficients_result_: dict[str, Any] | None = None
        self.permutation_result_: dict[str, Any] | None = None
        self.shap_result_: dict[str, Any] | None = None
        self.lime_result_: dict[str, Any] | None = None
        self.pdp_single_results_: dict[str, dict[str, Any]] = {}
        self.pdp_pair_results_: dict[str, dict[str, Any]] = {}

    @classmethod
    def from_runner(cls, runner, model_name: str, X_train: pd.DataFrame, y_train=None, X_test: pd.DataFrame | None = None, y_test=None, config: ExplainabilityConfig | None = None):
        if model_name not in runner.trained_models_:
            raise ValueError(f"Model '{model_name}' not found in runner.trained_models_.")
        return cls(
            trained_bundle=runner.trained_models_[model_name],
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            config=config,
        )

    def _get_dataset(self):
        if self.config.dataset == "train":
            return self.X_train, self.y_train
        if self.X_test is None:
            raise ValueError("config.dataset='test' but X_test was not provided.")
        return self.X_test, self.y_test

    def _get_estimator(self):
        if hasattr(self.pipeline, "named_steps") and "model" in self.pipeline.named_steps:
            return self.pipeline.named_steps["model"]
        return self.pipeline

    def _safe_sample(self, X: pd.DataFrame, n: int | None):
        if n is None or n >= len(X):
            return X.copy()
        return X.sample(n=n, random_state=self.config.random_state).copy()

    def _safe_target_sample(self, X: pd.DataFrame, y: pd.Series | None, n: int | None):
        if y is None:
            return self._safe_sample(X, n), None
        if n is None or n >= len(X):
            return X.copy(), y.copy()
        idx = X.sample(n=n, random_state=self.config.random_state).index
        return X.loc[idx].copy(), y.loc[idx].copy()

    def _create_bar_figure(self, df: pd.DataFrame, value_col: str, label_col: str, title: str, positive_negative: bool = False):
        return scientific_barh(df=df, value_col=value_col, label_col=label_col, title=title, positive_negative=positive_negative)

    def _resolve_shap_class_index(self, values: np.ndarray):
        if self.config.shap.class_index is not None:
            return self.config.shap.class_index
        if self.task_type == "Classification" and values.ndim == 3 and values.shape[2] >= 2:
            return 1
        return 0

    def _ensure_frame(self, X_like):
        if isinstance(X_like, pd.DataFrame):
            return X_like.copy()
        arr = np.asarray(X_like)
        if arr.ndim == 1:
            arr = arr.reshape(1, -1)
        return pd.DataFrame(arr, columns=self.feature_names)

    def _predict_df(self, X_like):
        X_df = self._ensure_frame(X_like)
        return self.pipeline.predict(X_df)

    def _predict_proba_df(self, X_like):
        X_df = self._ensure_frame(X_like)
        return self.pipeline.predict_proba(X_df)

    def _prepare_pdp_frame(self, X: pd.DataFrame) -> pd.DataFrame:
        X_use = X.copy()
        int_like_cols = X_use.select_dtypes(
            include=["int8", "int16", "int32", "int64", "uint8", "uint16", "uint32", "uint64", "bool"]
        ).columns.tolist()
        if int_like_cols:
            X_use[int_like_cols] = X_use[int_like_cols].astype(float)
        return X_use

    def feature_importance(self) -> dict[str, Any]:
        estimator = self._get_estimator()
        if not hasattr(estimator, "feature_importances_"):
            raise ValueError("This model does not expose feature_importances_.")
        values = np.asarray(estimator.feature_importances_, dtype=float)
        df = pd.DataFrame({"feature": self.feature_names, "importance": values, "abs_importance": np.abs(values)}).sort_values("abs_importance", ascending=False)
        df_top = df.head(self.config.top_n).reset_index(drop=True)
        fig = self._create_bar_figure(df=df_top, value_col="importance", label_col="feature", title=f"{self.model_name} - Feature importance", positive_negative=False)
        result = {"table": df, "table_top": df_top, "figure": fig}
        self.feature_importance_result_ = result
        return result

    def coefficients(self) -> dict[str, Any]:
        estimator = self._get_estimator()
        if not hasattr(estimator, "coef_"):
            raise ValueError("This model does not expose coef_.")
        coef = np.asarray(estimator.coef_)
        if coef.ndim == 1:
            df = pd.DataFrame({"feature": self.feature_names, "coefficient": coef, "abs_coefficient": np.abs(coef)}).sort_values("abs_coefficient", ascending=False)
            df_top = df.head(self.config.top_n).reset_index(drop=True)
            fig = self._create_bar_figure(df=df_top, value_col="coefficient", label_col="feature", title=f"{self.model_name} - Coefficients", positive_negative=True)
            result = {"table": df, "table_top": df_top, "figure": fig}
        else:
            rows = []
            for class_idx in range(coef.shape[0]):
                for feat, val in zip(self.feature_names, coef[class_idx]):
                    rows.append({"class_index": class_idx, "feature": feat, "coefficient": float(val), "abs_coefficient": float(abs(val))})
            df = pd.DataFrame(rows)
            agg_df = (
                df.groupby("feature", as_index=False)["abs_coefficient"]
                .mean()
                .rename(columns={"abs_coefficient": "mean_abs_coefficient"})
                .sort_values("mean_abs_coefficient", ascending=False)
            )
            df_top = agg_df.head(self.config.top_n).reset_index(drop=True)
            fig = self._create_bar_figure(df=df_top, value_col="mean_abs_coefficient", label_col="feature", title=f"{self.model_name} - Mean absolute coefficients", positive_negative=False)
            result = {"table": df, "table_summary": agg_df, "table_top": df_top, "figure": fig}
        self.coefficients_result_ = result
        return result

    def permutation_importance(self) -> dict[str, Any]:
        if not self.config.permutation.enabled:
            raise ValueError("Permutation importance is disabled in the config.")

        X_use, y_use = self._get_dataset()
        if y_use is None:
            raise ValueError("Permutation importance requires y for the selected dataset.")

        X_use, y_use = self._safe_target_sample(X_use, y_use, self.config.permutation.max_samples)

        pi = permutation_importance(
            self.pipeline,
            X_use,
            y_use,
            n_repeats=self.config.permutation.n_repeats,
            random_state=self.config.random_state,
            scoring=self.config.permutation.scoring,
            n_jobs=self.config.n_jobs,
        )

        df = pd.DataFrame(
            {
                "feature": self.feature_names,
                "importance_mean": pi.importances_mean,
                "importance_std": pi.importances_std,
                "abs_importance_mean": np.abs(pi.importances_mean),
            }
        ).sort_values("abs_importance_mean", ascending=False)

        df_top = df.head(self.config.top_n).reset_index(drop=True)
        fig = self._create_bar_figure(
            df=df_top,
            value_col="importance_mean",
            label_col="feature",
            title=f"{self.model_name} - Permutation importance ({self.config.dataset})",
            positive_negative=True,
        )

        result = {"table": df, "table_top": df_top, "figure": fig}
        self.permutation_result_ = result
        return result

    def shap_explain(self) -> dict[str, Any]:
        if not self.config.shap.enabled:
            raise ValueError("SHAP is disabled in the config.")
        if shap is None:
            raise ImportError("shap is not installed.")

        estimator = self._get_estimator()
        X_use, _ = self._get_dataset()
        X_sample = self._safe_sample(X_use, self.config.shap.sample_size)
        X_background = self._safe_sample(self.X_train, self.config.shap.background_size)

        explainer = None
        shap_values_array = None
        raw_shap_object = None

        tree_classes = (
            "RandomForestClassifier",
            "RandomForestRegressor",
            "ExtraTreesClassifier",
            "ExtraTreesRegressor",
            "GradientBoostingClassifier",
            "GradientBoostingRegressor",
            "HistGradientBoostingClassifier",
            "HistGradientBoostingRegressor",
            "XGBClassifier",
            "XGBRegressor",
        )
        linear_classes = ("LogisticRegression", "LinearRegression", "Ridge", "Lasso", "ElasticNet")

        model_class_name = estimator.__class__.__name__

        try:
            if model_class_name in tree_classes:
                explainer = shap.TreeExplainer(estimator)
                raw_shap_object = explainer.shap_values(X_sample, check_additivity=self.config.shap.check_additivity)
            elif model_class_name in linear_classes:
                explainer = shap.LinearExplainer(estimator, X_background)
                raw_shap_object = explainer.shap_values(X_sample)
            else:
                masker = shap.maskers.Independent(X_background)
                if self.task_type == "Classification" and hasattr(self.pipeline, "predict_proba"):
                    explainer = shap.Explainer(self._predict_proba_df, masker)
                else:
                    explainer = shap.Explainer(self._predict_df, masker)
                raw_shap_object = explainer(X_sample)
        except Exception:
            masker = shap.maskers.Independent(X_background)
            if self.task_type == "Classification" and hasattr(self.pipeline, "predict_proba"):
                explainer = shap.Explainer(self._predict_proba_df, masker)
            else:
                explainer = shap.Explainer(self._predict_df, masker)
            raw_shap_object = explainer(X_sample)

        if isinstance(raw_shap_object, list):
            class_index = self.config.shap.class_index if self.config.shap.class_index is not None else min(1, len(raw_shap_object) - 1)
            shap_values_array = np.asarray(raw_shap_object[class_index])
        elif hasattr(raw_shap_object, "values"):
            shap_values_array = np.asarray(raw_shap_object.values)
            if shap_values_array.ndim == 3:
                class_index = self._resolve_shap_class_index(shap_values_array)
                shap_values_array = shap_values_array[:, :, class_index]
        else:
            shap_values_array = np.asarray(raw_shap_object)

        if shap_values_array.ndim != 2:
            raise ValueError("Could not resolve SHAP values into a 2D array.")

        mean_abs = np.abs(shap_values_array).mean(axis=0)
        summary_df = pd.DataFrame({"feature": self.feature_names, "mean_abs_shap": mean_abs}).sort_values("mean_abs_shap", ascending=False)
        summary_top = summary_df.head(self.config.shap.max_display).reset_index(drop=True)
        values_df = pd.DataFrame(shap_values_array, columns=self.feature_names, index=X_sample.index)

        bar_fig = None
        try:
            plt.figure(figsize=(9, 6), constrained_layout=True)
            shap.summary_plot(shap_values_array, X_sample, plot_type="bar", show=False, max_display=self.config.shap.max_display)
            bar_fig = plt.gcf()
        except Exception:
            bar_fig = None

        dot_fig = None
        try:
            plt.figure(figsize=(9, 6), constrained_layout=True)
            shap.summary_plot(shap_values_array, X_sample, show=False, max_display=self.config.shap.max_display)
            dot_fig = plt.gcf()
        except Exception:
            dot_fig = None

        result = {"summary_table": summary_df, "summary_top": summary_top, "values_table": values_df, "sample_X": X_sample, "bar_figure": bar_fig, "summary_figure": dot_fig}
        self.shap_result_ = result
        return result

    def lime_explain(self) -> dict[str, Any]:
        if not self.config.lime.enabled:
            raise ValueError("LIME is disabled in the config.")
        if LimeTabularExplainer is None:
            raise ImportError("lime is not installed.")

        X_use, _ = self._get_dataset()
        if len(X_use) == 0:
            raise ValueError("Selected dataset is empty.")

        sample_index = int(self.config.lime.sample_index)
        if sample_index < 0 or sample_index >= len(X_use):
            raise ValueError("lime.sample_index is out of range.")

        row = X_use.iloc[sample_index]
        row_values = row.to_numpy(dtype=float)
        train_array = self.X_train.to_numpy(dtype=float)
        class_names = None
        if self.task_type == "Classification" and self.y_train is not None:
            class_names = [str(v) for v in sorted(pd.Series(self.y_train).dropna().unique().tolist())]

        explainer = LimeTabularExplainer(
            training_data=train_array,
            feature_names=self.feature_names,
            class_names=class_names,
            mode="classification" if self.task_type == "Classification" else "regression",
            random_state=self.config.random_state,
        )

        if self.task_type == "Classification" and hasattr(self.pipeline, "predict_proba"):
            exp = explainer.explain_instance(data_row=row_values, predict_fn=self._predict_proba_df, num_features=self.config.lime.num_features, num_samples=self.config.lime.num_samples)
            available_labels = list(exp.available_labels())
            if self.config.lime.class_index is not None and self.config.lime.class_index in available_labels:
                label_to_use = self.config.lime.class_index
            else:
                label_to_use = available_labels[0]
            exp_list = exp.as_list(label=label_to_use)
        else:
            exp = explainer.explain_instance(data_row=row_values, predict_fn=self._predict_df, num_features=self.config.lime.num_features, num_samples=self.config.lime.num_samples)
            exp_list = exp.as_list()

        df = pd.DataFrame(exp_list, columns=["feature_rule", "weight"])
        df["abs_weight"] = df["weight"].abs()
        df = df.sort_values("abs_weight", ascending=False).reset_index(drop=True)

        fig = self._create_bar_figure(df=df, value_col="weight", label_col="feature_rule", title=f"{self.model_name} - LIME explanation (row {sample_index})", positive_negative=True)

        result = {"table": df, "instance_X": row.to_frame().T, "figure": fig}
        self.lime_result_ = result
        return result

    def pdp_single(self, feature: str) -> dict[str, Any]:
        if not self.config.pdp.enabled:
            raise ValueError("PDP is disabled in the config.")
        if feature not in self.feature_names:
            raise ValueError(f"Feature '{feature}' not found.")

        X_use, _ = self._get_dataset()
        X_use = self._prepare_pdp_frame(X_use)

        pd_result = partial_dependence(
            self.pipeline,
            X_use,
            features=[feature],
            kind=self.config.pdp.kind,
            grid_resolution=self.config.pdp.grid_resolution,
            percentiles=self.config.pdp.percentiles,
        )

        grid = np.asarray(pd_result["grid_values"][0])

        if "average" in pd_result and pd_result["average"] is not None:
            average = np.asarray(pd_result["average"])
            avg_vals = average[0] if average.ndim == 2 else average.ravel()
        else:
            avg_vals = np.full(shape=len(grid), fill_value=np.nan)

        table_avg = pd.DataFrame({"feature": feature, "grid_value": grid, "pdp_average": avg_vals})

        individual_table = None
        if "individual" in pd_result and pd_result["individual"] is not None:
            ind = np.asarray(pd_result["individual"])
            if ind.ndim == 3:
                rows = []
                for sample_i in range(ind.shape[1]):
                    for grid_i, grid_val in enumerate(grid):
                        rows.append({"feature": feature, "sample_index": sample_i, "grid_value": grid_val, "ice_value": ind[0, sample_i, grid_i]})
                individual_table = pd.DataFrame(rows)

        fig, ax = plt.subplots(figsize=(8, 5), constrained_layout=True)
        if individual_table is not None and self.config.pdp.kind in {"individual", "both"}:
            for _, grp in individual_table.groupby("sample_index"):
                ax.plot(grp["grid_value"], grp["ice_value"], alpha=0.10, linewidth=0.8, color=COLOR_GREY)

        ax.plot(table_avg["grid_value"], table_avg["pdp_average"], linewidth=2.2, color=COLOR_BLUE)

        style_axes(ax, title=f"{self.model_name} - PDP single: {feature}", xlabel=feature, ylabel="Partial dependence")

        result = {"table_average": table_avg, "table_individual": individual_table, "figure": fig}
        self.pdp_single_results_[feature] = result
        return result

    def pdp_pair(self, feature_1: str, feature_2: str) -> dict[str, Any]:
        if not self.config.pdp.enabled:
            raise ValueError("PDP is disabled in the config.")
        if feature_1 not in self.feature_names or feature_2 not in self.feature_names:
            raise ValueError("One or both pair-PDP features are not in X columns.")

        X_use, _ = self._get_dataset()
        X_use = self._prepare_pdp_frame(X_use)

        idx_1 = self.feature_names.index(feature_1)
        idx_2 = self.feature_names.index(feature_2)

        pd_result = partial_dependence(
            self.pipeline,
            X_use,
            features=[(idx_1, idx_2)],
            kind="average",
            grid_resolution=self.config.pdp.grid_resolution,
            percentiles=self.config.pdp.percentiles,
        )

        grid_1 = np.asarray(pd_result["grid_values"][0])
        grid_2 = np.asarray(pd_result["grid_values"][1])
        avg = np.asarray(pd_result["average"])[0]

        rows = []
        for i, v1 in enumerate(grid_1):
            for j, v2 in enumerate(grid_2):
                rows.append({"feature_1": feature_1, "feature_2": feature_2, feature_1: v1, feature_2: v2, "pdp_value": avg[i, j]})
        table = pd.DataFrame(rows)

        fig, ax = plt.subplots(figsize=(7, 6), constrained_layout=True)
        mesh = ax.contourf(grid_1, grid_2, avg.T, levels=20, cmap=get_blue_cmap())
        style_axes(ax, title=f"{self.model_name} - PDP pair: {feature_1} vs {feature_2}", xlabel=feature_1, ylabel=feature_2)
        fig.colorbar(mesh, ax=ax)

        key = f"{feature_1}__{feature_2}"
        result = {"table": table, "figure": fig}
        self.pdp_pair_results_[key] = result
        return result

    def run_from_config(self) -> dict[str, Any]:
        outputs = {}

        try:
            outputs["feature_importance"] = self.feature_importance()
        except Exception:
            outputs["feature_importance"] = None

        try:
            outputs["coefficients"] = self.coefficients()
        except Exception:
            outputs["coefficients"] = None

        try:
            outputs["permutation_importance"] = self.permutation_importance()
        except Exception:
            outputs["permutation_importance"] = None

        try:
            outputs["shap"] = self.shap_explain()
        except Exception:
            outputs["shap"] = None

        try:
            outputs["lime"] = self.lime_explain()
        except Exception:
            outputs["lime"] = None

        single_outputs = {}
        for feature in self.config.pdp.single_features:
            try:
                single_outputs[feature] = self.pdp_single(feature)
            except Exception:
                single_outputs[feature] = None

        pair_outputs = {}
        for feature_1, feature_2 in self.config.pdp.pair_features:
            key = f"{feature_1}__{feature_2}"
            try:
                pair_outputs[key] = self.pdp_pair(feature_1, feature_2)
            except Exception:
                pair_outputs[key] = None

        outputs["pdp_single"] = single_outputs
        outputs["pdp_pair"] = pair_outputs
        return outputs


# _SML_XAI_LOGGING_PATCH
from scientific_ml_modules.utils.logging_utils import instrument_method
for _name in [
    "feature_importance", "coefficients", "permutation_importance", "shap_explain",
    "lime_explain", "pdp_single", "pdp_pair", "run_from_config"
]:
    instrument_method(ExplainableAIModule, _name, label=f"XAI:{_name}")

