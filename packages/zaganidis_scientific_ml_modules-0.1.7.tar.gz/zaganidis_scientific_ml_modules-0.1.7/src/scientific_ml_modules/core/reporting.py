
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from math import ceil
from typing import Any, Literal

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from sklearn.metrics import auc, confusion_matrix, precision_recall_curve, roc_curve

from scientific_ml_modules.utils.plot_style import (
    COLOR_BLACK,
    COLOR_BLUE,
    COLOR_RED,
    get_blue_cmap,
    get_model_color,
    get_red_cmap,
    set_scientific_plot_style,
    style_axes,
)

set_scientific_plot_style()


@dataclass
class ConfusionMatrixConfig:
    enabled: bool = True
    include_absolute: bool = True
    include_percentage: bool = True
    label_order: list[Any] | None = None
    include_reversed_binary_order: bool = True
    normalize: Literal["true", "all"] = "true"


@dataclass
class CurveConfig:
    enabled: bool = True
    positive_label: Any | None = None


@dataclass
class RegressionPlotConfig:
    enabled: bool = True
    bins: int = 30
    alpha: float = 0.35
    marker_size: int = 18


@dataclass
class ResultsReportingConfig:
    dataset: Literal["train", "test"] = "test"
    models: list[str] = field(default_factory=list)
    view_mode: Literal["single", "combined", "both"] = "both"
    random_state: int = 42
    logging_enabled: bool = True
    confusion: ConfusionMatrixConfig = field(default_factory=ConfusionMatrixConfig)
    roc: CurveConfig = field(default_factory=CurveConfig)
    precision_recall: CurveConfig = field(default_factory=CurveConfig)
    regression: RegressionPlotConfig = field(default_factory=RegressionPlotConfig)


class ResultsReportingConfigBuilder:
    def __init__(self):
        self._config = ResultsReportingConfig()

    def dataset(self, value: Literal["train", "test"]):
        self._config.dataset = value
        return self

    def models(self, values: list[str]):
        self._config.models = list(values)
        return self

    def view_mode(self, value: Literal["single", "combined", "both"]):
        self._config.view_mode = value
        return self

    def random_state(self, value: int):
        self._config.random_state = int(value)
        return self

    def confusion(
        self,
        enabled: bool = True,
        include_absolute: bool = True,
        include_percentage: bool = True,
        label_order: list[Any] | None = None,
        include_reversed_binary_order: bool = True,
        normalize: Literal["true", "all"] = "true",
    ):
        self._config.confusion = ConfusionMatrixConfig(
            enabled=enabled,
            include_absolute=include_absolute,
            include_percentage=include_percentage,
            label_order=None if label_order is None else list(label_order),
            include_reversed_binary_order=include_reversed_binary_order,
            normalize=normalize,
        )
        return self

    def roc(self, enabled: bool = True, positive_label: Any | None = None):
        self._config.roc = CurveConfig(enabled=enabled, positive_label=positive_label)
        return self

    def precision_recall(self, enabled: bool = True, positive_label: Any | None = None):
        self._config.precision_recall = CurveConfig(enabled=enabled, positive_label=positive_label)
        return self

    def regression(self, enabled: bool = True, bins: int = 30, alpha: float = 0.35, marker_size: int = 18):
        self._config.regression = RegressionPlotConfig(enabled=enabled, bins=bins, alpha=alpha, marker_size=marker_size)
        return self

    def logging(self, enabled: bool = True):
        self._config.logging_enabled = bool(enabled)
        return self

    def build(self) -> ResultsReportingConfig:
        return deepcopy(self._config)


class ModelResultsReporter:
    def __init__(self, runner, config: ResultsReportingConfig | None = None):
        self.runner = runner
        self.config = deepcopy(config) if config is not None else ResultsReportingConfig()
        self.task_type_ = self._infer_task_type()
        self.selected_models_ = self._resolve_selected_models()

        self.confusion_result_: dict[str, Any] | None = None
        self.roc_result_: dict[str, Any] | None = None
        self.precision_recall_result_: dict[str, Any] | None = None
        self.actual_vs_predicted_result_: dict[str, Any] | None = None
        self.residuals_vs_predicted_result_: dict[str, Any] | None = None

    @classmethod
    def from_runner(cls, runner, config: ResultsReportingConfig | None = None):
        return cls(runner=runner, config=config)

    def _infer_task_type(self) -> str:
        if not getattr(self.runner, "trained_models_", None):
            raise ValueError("runner.trained_models_ is empty or missing.")
        first_bundle = next(iter(self.runner.trained_models_.values()))
        return first_bundle.task_type

    def _get_prediction_map(self) -> dict[str, pd.DataFrame]:
        if self.config.dataset == "train":
            pred_map = getattr(self.runner, "predictions_train_", {})
        else:
            pred_map = getattr(self.runner, "predictions_test_", {})
        return pred_map or {}

    def _resolve_selected_models(self) -> list[str]:
        pred_map = self._get_prediction_map()
        available = list(pred_map.keys())
        selected = [m for m in self.config.models if m in available] if self.config.models else available
        if not selected:
            raise ValueError(f"No prediction payloads found for dataset='{self.config.dataset}'.")
        return selected

    def _get_bundle(self, model_name: str):
        if model_name not in self.runner.trained_models_:
            raise ValueError(f"Model '{model_name}' not found in runner.trained_models_.")
        return self.runner.trained_models_[model_name]

    def _get_payload(self, model_name: str) -> pd.DataFrame:
        pred_map = self._get_prediction_map()
        if model_name not in pred_map:
            raise ValueError(f"Prediction payload for '{model_name}' not found.")
        payload = pred_map[model_name]
        return payload.copy() if isinstance(payload, pd.DataFrame) else pd.DataFrame(payload)

    def _extract_actual_prediction(self, model_name: str) -> tuple[pd.Series, pd.Series, pd.DataFrame]:
        payload = self._get_payload(model_name)
        if "y_true" not in payload.columns or "prediction" not in payload.columns:
            raise ValueError(f"Payload for '{model_name}' must contain 'y_true' and 'prediction'.")
        mask = payload["y_true"].notna() & payload["prediction"].notna()
        payload = payload.loc[mask].copy()
        return payload["y_true"], payload["prediction"], payload

    def _get_classes_for_model(self, model_name: str) -> list[Any] | None:
        bundle = self._get_bundle(model_name)
        pipeline = bundle.fitted_pipeline
        estimator = pipeline.named_steps["model"] if hasattr(pipeline, "named_steps") and "model" in pipeline.named_steps else pipeline
        return list(estimator.classes_) if hasattr(estimator, "classes_") else None

    def _resolve_label_order(self, model_name: str, y_true: pd.Series) -> list[Any]:
        if self.config.confusion.label_order is not None:
            return list(self.config.confusion.label_order)
        classes_ = self._get_classes_for_model(model_name)
        return list(classes_) if classes_ is not None else sorted(pd.Series(y_true).dropna().unique().tolist())

    def _get_probability_df(self, payload: pd.DataFrame) -> pd.DataFrame | None:
        cols = [c for c in payload.columns if str(c).startswith("probability_")]
        return payload[cols].copy() if cols else None

    def _resolve_positive_label_and_score(self, model_name: str, payload: pd.DataFrame, configured_positive_label: Any | None):
        proba_df = self._get_probability_df(payload)
        if proba_df is None:
            return None, None

        classes_ = self._get_classes_for_model(model_name)
        if classes_ is None or len(classes_) != 2:
            return None, None

        positive_label = configured_positive_label if configured_positive_label is not None else classes_[1]
        if positive_label not in classes_:
            raise ValueError(f"Configured positive_label={positive_label} not in model classes {classes_} for '{model_name}'.")

        pos_index = classes_.index(positive_label)
        col_name = f"probability_{pos_index}"
        if col_name not in proba_df.columns:
            return positive_label, None

        return positive_label, pd.to_numeric(proba_df[col_name], errors="coerce")

    def _normalize_confusion(self, cm: np.ndarray) -> np.ndarray:
        cm = np.asarray(cm, dtype=float)
        if self.config.confusion.normalize == "all":
            denom = cm.sum()
            return cm / (1.0 if denom == 0 else denom) * 100.0
        row_sums = cm.sum(axis=1, keepdims=True)
        row_sums = np.where(row_sums == 0, 1.0, row_sums)
        return cm / row_sums * 100.0

    def _cm_to_df(self, cm: np.ndarray, labels: list[Any], as_percent: bool = False) -> pd.DataFrame:
        index = [f"actual_{x}" for x in labels]
        cols = [f"pred_{x}" for x in labels]
        return pd.DataFrame(cm, index=index, columns=cols).round(2) if as_percent else pd.DataFrame(cm.astype(int), index=index, columns=cols)

    def _plot_confusion_matrix(self, cm_df: pd.DataFrame, title: str, fmt: str = "int"):
        fig, ax = plt.subplots(figsize=(5.2, 4.2), constrained_layout=True)
        mat = cm_df.to_numpy(dtype=float)

        cmap = get_blue_cmap() if fmt == "int" else get_red_cmap()
        im = ax.imshow(mat, aspect="auto", cmap=cmap)

        ax.set_xticks(np.arange(cm_df.shape[1]))
        ax.set_yticks(np.arange(cm_df.shape[0]))
        ax.set_xticklabels(cm_df.columns, rotation=45, ha="right")
        ax.set_yticklabels(cm_df.index)
        style_axes(ax, title=title, xlabel="Predicted class", ylabel="Actual class")

        for i in range(mat.shape[0]):
            for j in range(mat.shape[1]):
                txt = f"{int(mat[i, j])}" if fmt == "int" else f"{mat[i, j]:.2f}%"
                ax.text(j, i, txt, ha="center", va="center", color=COLOR_BLACK, fontsize=9)

        fig.colorbar(im, ax=ax)
        return fig

    def _plot_confusion_grid(self, per_model_tables: dict[str, pd.DataFrame], title_prefix: str, fmt: str = "int"):
        if not per_model_tables:
            return None

        n_models = len(per_model_tables)
        ncols = 2 if n_models > 1 else 1
        nrows = ceil(n_models / ncols)

        fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(6 * ncols, 4.8 * nrows), constrained_layout=True)
        if not isinstance(axes, np.ndarray):
            axes = np.array([axes])
        axes = axes.ravel()

        for ax in axes[n_models:]:
            ax.axis("off")

        cmap = get_blue_cmap() if fmt == "int" else get_red_cmap()

        for ax, (model_name, df) in zip(axes, per_model_tables.items()):
            mat = df.to_numpy(dtype=float)
            im = ax.imshow(mat, aspect="auto", cmap=cmap)

            ax.set_xticks(np.arange(df.shape[1]))
            ax.set_yticks(np.arange(df.shape[0]))
            ax.set_xticklabels(df.columns, rotation=45, ha="right")
            ax.set_yticklabels(df.index)
            style_axes(ax, title=f"{title_prefix}: {model_name}", xlabel="Predicted class", ylabel="Actual class")

            for i in range(mat.shape[0]):
                for j in range(mat.shape[1]):
                    txt = f"{int(mat[i, j])}" if fmt == "int" else f"{mat[i, j]:.2f}%"
                    ax.text(j, i, txt, ha="center", va="center", color=COLOR_BLACK, fontsize=9)

            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

        return fig

    def _plot_curve_single(self, curve_df: pd.DataFrame, x_col: str, y_col: str, title: str, auc_label: str | None = None):
        fig, ax = plt.subplots(figsize=(6, 4.5), constrained_layout=True)
        ax.plot(curve_df[x_col], curve_df[y_col], linewidth=2.2, color=COLOR_BLUE)

        if x_col == "fpr" and y_col == "tpr":
            ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1.2, color=COLOR_RED)
            style_axes(ax, title=f"{title} | {auc_label}" if auc_label else title, xlabel="False positive rate", ylabel="True positive rate")
        else:
            style_axes(ax, title=f"{title} | {auc_label}" if auc_label else title, xlabel="Recall", ylabel="Precision")

        return fig

    def _plot_curve_combined(self, curve_tables: dict[str, pd.DataFrame], x_col: str, y_col: str, title: str, auc_map: dict[str, float] | None = None):
        if not curve_tables:
            return None

        fig, ax = plt.subplots(figsize=(7, 5), constrained_layout=True)
        for idx, (model_name, df) in enumerate(curve_tables.items()):
            label = model_name
            if auc_map is not None and model_name in auc_map and not pd.isna(auc_map[model_name]):
                label = f"{model_name} ({auc_map[model_name]:.4f})"
            ax.plot(df[x_col], df[y_col], linewidth=2.0, color=get_model_color(idx), label=label)

        if x_col == "fpr" and y_col == "tpr":
            ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1.2, color=COLOR_BLACK)
            style_axes(ax, title=title, xlabel="False positive rate", ylabel="True positive rate")
        else:
            style_axes(ax, title=title, xlabel="Recall", ylabel="Precision")

        ax.legend()
        return fig

    def _plot_actual_vs_predicted_single(self, df: pd.DataFrame, model_name: str):
        fig, ax = plt.subplots(figsize=(6.2, 5.2), constrained_layout=True)
        ax.scatter(
            pd.to_numeric(df["y_true"], errors="coerce"),
            pd.to_numeric(df["prediction"], errors="coerce"),
            alpha=self.config.regression.alpha,
            s=self.config.regression.marker_size,
            color=COLOR_BLUE,
            edgecolors="none",
        )

        vals = pd.concat([pd.to_numeric(df["y_true"], errors="coerce"), pd.to_numeric(df["prediction"], errors="coerce")], axis=0).dropna()
        if not vals.empty:
            lo, hi = vals.min(), vals.max()
            ax.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1.4, color=COLOR_RED)

        style_axes(ax, title=f"{model_name} - Actual vs predicted ({self.config.dataset})", xlabel="Actual", ylabel="Predicted")
        return fig

    def _plot_actual_vs_predicted_combined(self, combined_df: pd.DataFrame):
        fig, ax = plt.subplots(figsize=(7.0, 5.5), constrained_layout=True)
        for idx, (model_name, grp) in enumerate(combined_df.groupby("model")):
            ax.scatter(
                pd.to_numeric(grp["y_true"], errors="coerce"),
                pd.to_numeric(grp["prediction"], errors="coerce"),
                alpha=self.config.regression.alpha,
                s=self.config.regression.marker_size,
                color=get_model_color(idx),
                edgecolors="none",
                label=model_name,
            )

        vals = pd.concat([pd.to_numeric(combined_df["y_true"], errors="coerce"), pd.to_numeric(combined_df["prediction"], errors="coerce")], axis=0).dropna()
        if not vals.empty:
            lo, hi = vals.min(), vals.max()
            ax.plot([lo, hi], [lo, hi], linestyle="--", linewidth=1.4, color=COLOR_BLACK)

        style_axes(ax, title=f"All selected models - Actual vs predicted ({self.config.dataset})", xlabel="Actual", ylabel="Predicted")
        ax.legend()
        return fig

    def _plot_residuals_vs_predicted_single(self, df: pd.DataFrame, model_name: str):
        fig = plt.figure(figsize=(8.2, 5.8), constrained_layout=True)
        gs = fig.add_gridspec(1, 2, width_ratios=[4, 1], wspace=0.08)
        ax_scatter = fig.add_subplot(gs[0, 0])
        ax_hist = fig.add_subplot(gs[0, 1], sharey=ax_scatter)

        pred = pd.to_numeric(df["prediction"], errors="coerce")
        resid = pd.to_numeric(df["y_true"], errors="coerce") - pred
        plot_df = pd.DataFrame({"prediction": pred, "residual": resid}).dropna()

        ax_scatter.scatter(plot_df["prediction"], plot_df["residual"], alpha=self.config.regression.alpha, s=self.config.regression.marker_size, color=COLOR_BLUE, edgecolors="none")
        ax_scatter.axhline(0.0, linestyle="--", linewidth=1.4, color=COLOR_RED)

        style_axes(ax_scatter, title=f"{model_name} - Residuals vs predicted ({self.config.dataset})", xlabel="Predicted", ylabel="Residual")

        ax_hist.hist(plot_df["residual"], bins=self.config.regression.bins, orientation="horizontal", color=get_model_color(2), edgecolor=COLOR_BLACK, alpha=0.8)
        style_axes(ax_hist, xlabel="Count", ylabel=None)
        plt.setp(ax_hist.get_yticklabels(), visible=False)

        return fig

    def _plot_residuals_vs_predicted_combined(self, combined_df: pd.DataFrame):
        fig = plt.figure(figsize=(8.8, 6.0), constrained_layout=True)
        gs = fig.add_gridspec(1, 2, width_ratios=[4, 1], wspace=0.08)
        ax_scatter = fig.add_subplot(gs[0, 0])
        ax_hist = fig.add_subplot(gs[0, 1], sharey=ax_scatter)

        for idx, (model_name, grp) in enumerate(combined_df.groupby("model")):
            pred = pd.to_numeric(grp["prediction"], errors="coerce")
            resid = pd.to_numeric(grp["y_true"], errors="coerce") - pred
            plot_df = pd.DataFrame({"prediction": pred, "residual": resid}).dropna()
            color = get_model_color(idx)

            ax_scatter.scatter(plot_df["prediction"], plot_df["residual"], alpha=self.config.regression.alpha, s=self.config.regression.marker_size, color=color, edgecolors="none", label=model_name)
            ax_hist.hist(plot_df["residual"], bins=self.config.regression.bins, orientation="horizontal", color=color, alpha=0.30)

        ax_scatter.axhline(0.0, linestyle="--", linewidth=1.4, color=COLOR_BLACK)
        style_axes(ax_scatter, title=f"All selected models - Residuals vs predicted ({self.config.dataset})", xlabel="Predicted", ylabel="Residual")
        ax_scatter.legend()

        style_axes(ax_hist, xlabel="Count", ylabel=None)
        plt.setp(ax_hist.get_yticklabels(), visible=False)

        return fig

    def confusion_matrices(self) -> dict[str, Any]:
        if self.task_type_ != "Classification":
            raise ValueError("confusion_matrices() is only available for Classification.")
        if not self.config.confusion.enabled:
            raise ValueError("Confusion matrices are disabled in the config.")

        per_model = {}
        abs_tables_standard = {}
        pct_tables_standard = {}
        abs_tables_reversed = {}
        pct_tables_reversed = {}

        for model_name in self.selected_models_:
            y_true, y_pred, _ = self._extract_actual_prediction(model_name)
            labels_standard = self._resolve_label_order(model_name, y_true)

            cm_standard = confusion_matrix(y_true, y_pred, labels=labels_standard)
            cm_standard_pct = self._normalize_confusion(cm_standard)

            result_entry = {"label_order_standard": labels_standard}

            if self.config.confusion.include_absolute:
                df_abs = self._cm_to_df(cm_standard, labels_standard, as_percent=False)
                abs_tables_standard[model_name] = df_abs
                result_entry["table_absolute_standard"] = df_abs
                result_entry["figure_absolute_standard"] = self._plot_confusion_matrix(df_abs, title=f"{model_name} - Confusion matrix (counts)", fmt="int")

            if self.config.confusion.include_percentage:
                df_pct = self._cm_to_df(cm_standard_pct, labels_standard, as_percent=True)
                pct_tables_standard[model_name] = df_pct
                result_entry["table_percentage_standard"] = df_pct
                result_entry["figure_percentage_standard"] = self._plot_confusion_matrix(df_pct, title=f"{model_name} - Confusion matrix (%)", fmt="pct")

            if len(labels_standard) == 2 and self.config.confusion.include_reversed_binary_order:
                labels_reversed = list(reversed(labels_standard))
                cm_reversed = confusion_matrix(y_true, y_pred, labels=labels_reversed)
                cm_reversed_pct = self._normalize_confusion(cm_reversed)

                result_entry["label_order_reversed"] = labels_reversed

                if self.config.confusion.include_absolute:
                    df_abs_rev = self._cm_to_df(cm_reversed, labels_reversed, as_percent=False)
                    abs_tables_reversed[model_name] = df_abs_rev
                    result_entry["table_absolute_reversed"] = df_abs_rev
                    result_entry["figure_absolute_reversed"] = self._plot_confusion_matrix(df_abs_rev, title=f"{model_name} - Confusion matrix reversed (counts)", fmt="int")

                if self.config.confusion.include_percentage:
                    df_pct_rev = self._cm_to_df(cm_reversed_pct, labels_reversed, as_percent=True)
                    pct_tables_reversed[model_name] = df_pct_rev
                    result_entry["table_percentage_reversed"] = df_pct_rev
                    result_entry["figure_percentage_reversed"] = self._plot_confusion_matrix(df_pct_rev, title=f"{model_name} - Confusion matrix reversed (%)", fmt="pct")

            per_model[model_name] = result_entry

        result = {
            "per_model": per_model,
            "combined_figure_absolute_standard": self._plot_confusion_grid(abs_tables_standard, title_prefix="Confusion counts", fmt="int") if abs_tables_standard else None,
            "combined_figure_percentage_standard": self._plot_confusion_grid(pct_tables_standard, title_prefix="Confusion %", fmt="pct") if pct_tables_standard else None,
            "combined_figure_absolute_reversed": self._plot_confusion_grid(abs_tables_reversed, title_prefix="Confusion counts reversed", fmt="int") if abs_tables_reversed else None,
            "combined_figure_percentage_reversed": self._plot_confusion_grid(pct_tables_reversed, title_prefix="Confusion % reversed", fmt="pct") if pct_tables_reversed else None,
        }

        self.confusion_result_ = result
        return result

    def roc_curves(self) -> dict[str, Any]:
        if self.task_type_ != "Classification":
            raise ValueError("roc_curves() is only available for Classification.")
        if not self.config.roc.enabled:
            raise ValueError("ROC curves are disabled in the config.")

        curve_tables = {}
        auc_map = {}
        single_figures = {}

        for model_name in self.selected_models_:
            y_true, _, payload = self._extract_actual_prediction(model_name)
            positive_label, y_score = self._resolve_positive_label_and_score(model_name=model_name, payload=payload, configured_positive_label=self.config.roc.positive_label)
            if y_score is None:
                continue

            mask = y_true.notna() & y_score.notna()
            y_true_use = y_true.loc[mask]
            y_score_use = y_score.loc[mask]

            if pd.Series(y_true_use).nunique(dropna=True) != 2:
                continue

            y_bin = (pd.Series(y_true_use) == positive_label).astype(int)
            fpr, tpr, thresholds = roc_curve(y_bin, y_score_use)
            roc_auc = auc(fpr, tpr)

            table = pd.DataFrame(
                {
                    "model": model_name,
                    "positive_label": positive_label,
                    "fpr": fpr,
                    "tpr": tpr,
                    "threshold": np.append(thresholds, np.nan)[: len(fpr)],
                    "auc": roc_auc,
                }
            )
            curve_tables[model_name] = table
            auc_map[model_name] = roc_auc

            if self.config.view_mode in {"single", "both"}:
                single_figures[model_name] = self._plot_curve_single(table, "fpr", "tpr", f"{model_name} - ROC curve ({self.config.dataset})", f"AUC={roc_auc:.4f}")

        combined_figure = self._plot_curve_combined(curve_tables, "fpr", "tpr", f"All selected models - ROC curves ({self.config.dataset})", auc_map) if self.config.view_mode in {"combined", "both"} and curve_tables else None

        result = {"tables_by_model": curve_tables, "auc_by_model": auc_map, "single_figures": single_figures, "combined_figure": combined_figure}
        self.roc_result_ = result
        return result

    def precision_recall_curves(self) -> dict[str, Any]:
        if self.task_type_ != "Classification":
            raise ValueError("precision_recall_curves() is only available for Classification.")
        if not self.config.precision_recall.enabled:
            raise ValueError("Precision-Recall curves are disabled in the config.")

        curve_tables = {}
        auc_map = {}
        single_figures = {}

        for model_name in self.selected_models_:
            y_true, _, payload = self._extract_actual_prediction(model_name)
            positive_label, y_score = self._resolve_positive_label_and_score(model_name=model_name, payload=payload, configured_positive_label=self.config.precision_recall.positive_label)
            if y_score is None:
                continue

            mask = y_true.notna() & y_score.notna()
            y_true_use = y_true.loc[mask]
            y_score_use = y_score.loc[mask]

            if pd.Series(y_true_use).nunique(dropna=True) != 2:
                continue

            y_bin = (pd.Series(y_true_use) == positive_label).astype(int)
            precision, recall, thresholds = precision_recall_curve(y_bin, y_score_use)
            pr_auc = auc(recall, precision)

            table = pd.DataFrame(
                {
                    "model": model_name,
                    "positive_label": positive_label,
                    "recall": recall,
                    "precision": precision,
                    "threshold": np.append(thresholds, np.nan)[: len(recall)],
                    "auc_pr": pr_auc,
                }
            )
            curve_tables[model_name] = table
            auc_map[model_name] = pr_auc

            if self.config.view_mode in {"single", "both"}:
                single_figures[model_name] = self._plot_curve_single(table, "recall", "precision", f"{model_name} - Precision-Recall curve ({self.config.dataset})", f"PR AUC={pr_auc:.4f}")

        combined_figure = self._plot_curve_combined(curve_tables, "recall", "precision", f"All selected models - Precision-Recall curves ({self.config.dataset})", auc_map) if self.config.view_mode in {"combined", "both"} and curve_tables else None

        result = {"tables_by_model": curve_tables, "auc_by_model": auc_map, "single_figures": single_figures, "combined_figure": combined_figure}
        self.precision_recall_result_ = result
        return result

    def actual_vs_predicted(self) -> dict[str, Any]:
        if self.task_type_ != "Regression":
            raise ValueError("actual_vs_predicted() is only available for Regression.")
        if not self.config.regression.enabled:
            raise ValueError("Regression plotting is disabled in the config.")

        tables_by_model = {}
        single_figures = {}
        combined_rows = []

        for model_name in self.selected_models_:
            y_true, y_pred, _ = self._extract_actual_prediction(model_name)
            df = pd.DataFrame({"model": model_name, "y_true": pd.to_numeric(y_true, errors="coerce"), "prediction": pd.to_numeric(y_pred, errors="coerce")}).dropna()
            if df.empty:
                continue

            tables_by_model[model_name] = df
            if self.config.view_mode in {"single", "both"}:
                single_figures[model_name] = self._plot_actual_vs_predicted_single(df, model_name)
            combined_rows.append(df)

        combined_table = pd.concat(combined_rows, axis=0, ignore_index=True) if combined_rows else pd.DataFrame()
        combined_figure = self._plot_actual_vs_predicted_combined(combined_table) if self.config.view_mode in {"combined", "both"} and not combined_table.empty else None

        result = {"tables_by_model": tables_by_model, "combined_table": combined_table, "single_figures": single_figures, "combined_figure": combined_figure}
        self.actual_vs_predicted_result_ = result
        return result

    def residuals_vs_predicted(self) -> dict[str, Any]:
        if self.task_type_ != "Regression":
            raise ValueError("residuals_vs_predicted() is only available for Regression.")
        if not self.config.regression.enabled:
            raise ValueError("Regression plotting is disabled in the config.")

        tables_by_model = {}
        single_figures = {}
        combined_rows = []

        for model_name in self.selected_models_:
            y_true, y_pred, _ = self._extract_actual_prediction(model_name)
            pred = pd.to_numeric(y_pred, errors="coerce")
            actual = pd.to_numeric(y_true, errors="coerce")
            residual = actual - pred
            df = pd.DataFrame({"model": model_name, "y_true": actual, "prediction": pred, "residual": residual}).dropna()
            if df.empty:
                continue

            tables_by_model[model_name] = df
            if self.config.view_mode in {"single", "both"}:
                single_figures[model_name] = self._plot_residuals_vs_predicted_single(df, model_name)
            combined_rows.append(df)

        combined_table = pd.concat(combined_rows, axis=0, ignore_index=True) if combined_rows else pd.DataFrame()
        combined_figure = self._plot_residuals_vs_predicted_combined(combined_table) if self.config.view_mode in {"combined", "both"} and not combined_table.empty else None

        result = {"tables_by_model": tables_by_model, "combined_table": combined_table, "single_figures": single_figures, "combined_figure": combined_figure}
        self.residuals_vs_predicted_result_ = result
        return result

    def run_from_config(self) -> dict[str, Any]:
        outputs = {}
        if self.task_type_ == "Classification":
            try:
                outputs["confusion_matrices"] = self.confusion_matrices()
            except Exception:
                outputs["confusion_matrices"] = None
            try:
                outputs["roc_curves"] = self.roc_curves()
            except Exception:
                outputs["roc_curves"] = None
            try:
                outputs["precision_recall_curves"] = self.precision_recall_curves()
            except Exception:
                outputs["precision_recall_curves"] = None
        else:
            try:
                outputs["actual_vs_predicted"] = self.actual_vs_predicted()
            except Exception:
                outputs["actual_vs_predicted"] = None
            try:
                outputs["residuals_vs_predicted"] = self.residuals_vs_predicted()
            except Exception:
                outputs["residuals_vs_predicted"] = None
        return outputs


# _SML_REPORTING_LOGGING_PATCH
from scientific_ml_modules.utils.logging_utils import instrument_method
for _name in [
    "confusion_matrices", "roc_curves", "precision_recall_curves", "actual_vs_predicted",
    "residuals_vs_predicted", "run_from_config", "_plot_confusion_matrix", "_plot_confusion_grid",
    "_plot_curve_single", "_plot_curve_combined", "_plot_actual_vs_predicted_single",
    "_plot_actual_vs_predicted_combined", "_plot_residuals_vs_predicted_single",
    "_plot_residuals_vs_predicted_combined"
]:
    instrument_method(ModelResultsReporter, _name, label=f"REPORTING:{_name}")

