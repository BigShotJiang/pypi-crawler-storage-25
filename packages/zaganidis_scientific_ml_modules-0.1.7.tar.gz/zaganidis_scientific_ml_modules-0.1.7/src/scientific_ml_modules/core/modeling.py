from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import joblib
import numpy as np
import pandas as pd

from sklearn.base import clone
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import (
    ExtraTreesClassifier,
    ExtraTreesRegressor,
    GradientBoostingClassifier,
    GradientBoostingRegressor,
    HistGradientBoostingClassifier,
    HistGradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
    StackingClassifier,
    StackingRegressor,
)
from sklearn.linear_model import ElasticNet, Lasso, LinearRegression, LogisticRegression, Ridge
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    brier_score_loss,
    confusion_matrix,
    explained_variance_score,
    f1_score,
    get_scorer,
    get_scorer_names,
    jaccard_score,
    log_loss,
    make_scorer,
    matthews_corrcoef,
    max_error,
    mean_absolute_error,
    mean_absolute_percentage_error,
    mean_gamma_deviance,
    mean_poisson_deviance,
    mean_squared_error,
    mean_squared_log_error,
    median_absolute_error,
    precision_score,
    r2_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import (
    KFold,
    RepeatedKFold,
    RepeatedStratifiedKFold,
    StratifiedKFold,
    TimeSeriesSplit,
    cross_val_predict,
    cross_validate,
)
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC, SVR

try:
    from sklearn.metrics import d2_absolute_error_score, d2_pinball_score, d2_tweedie_score
except Exception:
    d2_absolute_error_score = None
    d2_pinball_score = None
    d2_tweedie_score = None

try:
    from imblearn.over_sampling import SMOTE
    from imblearn.pipeline import Pipeline as ImbPipeline
except Exception:
    SMOTE = None
    ImbPipeline = None

try:
    import optuna
except Exception:
    optuna = None

try:
    from xgboost import XGBClassifier, XGBRegressor
except Exception:
    XGBClassifier = None
    XGBRegressor = None


# =============================================================================
# Config dataclasses
# =============================================================================
@dataclass
class CVConfig:
    method: str = "auto"
    n_splits: int = 5
    n_repeats: int = 3
    shuffle: bool = True
    random_state: int = 42


@dataclass
class TuningConfig:
    enabled: bool = True
    profile: Literal["Light", "Medium", "Heavy"] = "Medium"
    n_trials_override: int | None = None


@dataclass
class BootstrapConfig:
    enabled: bool = True
    n_rounds: int = 100
    random_state: int = 42


@dataclass
class SavingConfig:
    enabled: bool = False
    save_directory: str = "saved_models"
    models_to_save: list[str] = field(default_factory=list)
    custom_model_paths: dict[str, str] = field(default_factory=dict)


@dataclass
class StackingConfig:
    enabled: bool = False
    base_models: list[str] = field(default_factory=list)
    final_estimator: str | None = None
    passthrough: bool = False


@dataclass
class ModelRunConfig:
    task_type: Literal["auto", "Classification", "Regression"] = "auto"
    algorithms: list[str] = field(default_factory=list)
    primary_metric: str | None = None
    imbalance_method: Literal["none", "class_weight", "smote"] = "none"
    cv: CVConfig = field(default_factory=CVConfig)
    tuning: TuningConfig = field(default_factory=TuningConfig)
    bootstrap: BootstrapConfig = field(default_factory=BootstrapConfig)
    saving: SavingConfig = field(default_factory=SavingConfig)
    stacking: StackingConfig = field(default_factory=StackingConfig)
    random_state: int = 42
    n_jobs_models: int = -1
    logging_enabled: bool = True


@dataclass
class TrainedModelBundle:
    model_name: str
    fitted_pipeline: Any
    config: ModelRunConfig
    task_type: str
    feature_names: list[str]
    target_name: str | None = None
    cv_metric_name: str | None = None
    cv_score_mean: float | None = None
    cv_score_std: float | None = None
    model_selection_row: dict[str, Any] | None = None
    full_metric_table: pd.DataFrame | None = None


# =============================================================================
# Builder
# =============================================================================
class ModelingConfigBuilder:
    def __init__(self):
        self._config = ModelRunConfig()

    def task_type(self, value: Literal["auto", "Classification", "Regression"]):
        self._config.task_type = value
        return self

    def algorithms(self, values: list[str]):
        self._config.algorithms = list(values)
        return self

    def primary_metric(self, value: str):
        self._config.primary_metric = value
        return self

    def imbalance_method(self, value: Literal["none", "class_weight", "smote"]):
        self._config.imbalance_method = value
        return self

    def cv(
        self,
        method: str = "auto",
        n_splits: int = 5,
        n_repeats: int = 3,
        shuffle: bool = True,
        random_state: int = 42,
    ):
        self._config.cv = CVConfig(
            method=method,
            n_splits=n_splits,
            n_repeats=n_repeats,
            shuffle=shuffle,
            random_state=random_state,
        )
        return self

    def tuning(
        self,
        enabled: bool = True,
        profile: Literal["Light", "Medium", "Heavy"] = "Medium",
        n_trials_override: int | None = None,
    ):
        self._config.tuning = TuningConfig(
            enabled=enabled,
            profile=profile,
            n_trials_override=n_trials_override,
        )
        return self

    def bootstrap(
        self,
        enabled: bool = True,
        n_rounds: int = 100,
        random_state: int = 42,
    ):
        self._config.bootstrap = BootstrapConfig(
            enabled=enabled,
            n_rounds=n_rounds,
            random_state=random_state,
        )
        return self

    def saving(
        self,
        enabled: bool = False,
        save_directory: str = "saved_models",
        models_to_save: list[str] | None = None,
        custom_model_paths: dict[str, str] | None = None,
    ):
        self._config.saving = SavingConfig(
            enabled=enabled,
            save_directory=save_directory,
            models_to_save=[] if models_to_save is None else list(models_to_save),
            custom_model_paths={} if custom_model_paths is None else dict(custom_model_paths),
        )
        return self

    def stacking(
        self,
        enabled: bool = False,
        base_models: list[str] | None = None,
        final_estimator: str | None = None,
        passthrough: bool = False,
    ):
        self._config.stacking = StackingConfig(
            enabled=enabled,
            base_models=[] if base_models is None else list(base_models),
            final_estimator=final_estimator,
            passthrough=passthrough,
        )
        return self

    def random_state(self, value: int):
        self._config.random_state = int(value)
        return self

    def n_jobs_models(self, value: int):
        self._config.n_jobs_models = int(value)
        return self

    def logging(self, enabled: bool = True):
        self._config.logging_enabled = bool(enabled)
        return self

    def build(self) -> ModelRunConfig:
        return deepcopy(self._config)


# =============================================================================
# General helpers
# =============================================================================
def smape(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    denom = np.abs(y_true) + np.abs(y_pred)
    denom = np.where(denom == 0, 1e-12, denom)
    return np.mean(2.0 * np.abs(y_pred - y_true) / denom)


def _coerce_target(y) -> pd.Series:
    if isinstance(y, pd.Series):
        return y.copy()
    if isinstance(y, pd.DataFrame):
        if y.shape[1] != 1:
            raise ValueError("y must be a Series or a single-column DataFrame.")
        return y.iloc[:, 0].copy()
    return pd.Series(y)


def _infer_task_type(y: pd.Series) -> str:
    if pd.api.types.is_numeric_dtype(y):
        unique_vals = set(pd.Series(y).dropna().unique().tolist())
        if unique_vals.issubset({0, 1}) and len(unique_vals) <= 2:
            return "Classification"
        return "Regression"
    return "Classification"


def _default_primary_metric(task_type: str) -> str:
    return "Balanced accuracy" if task_type == "Classification" else "Mean absolute error (MAE)"


def _safe_cv_n_splits_for_classification(y: pd.Series, requested_splits: int) -> int:
    counts = y.value_counts(dropna=False)
    min_class = int(counts.min())
    return max(2, min(requested_splits, min_class))


def _to_series_safe(y):
    if isinstance(y, pd.Series):
        return y.copy()
    if isinstance(y, pd.DataFrame):
        if y.shape[1] != 1:
            raise ValueError("y must be a Series or single-column DataFrame.")
        return y.iloc[:, 0].copy()
    return pd.Series(y)


def profile_to_trial_count(profile: str, X_train=None, model_name: str | None = None) -> int:
    if profile == "Light":
        base = 15
    elif profile == "Medium":
        base = 35
    else:
        base = 75

    if X_train is not None:
        n_rows = int(X_train.shape[0])
        expensive_models = {
            "SVM (RBF)",
            "SVM (Poly)",
            "SVR (RBF)",
            "SVR (Poly)",
            "Neural net (MLP)",
            "K-nearest neighbors",
        }
        if model_name in expensive_models and n_rows >= 20_000:
            base = max(10, int(base * 0.70))
        elif n_rows < 1_000:
            base = int(base * 1.15)

    return int(base)


# =============================================================================
# Adaptive tuning helpers
# =============================================================================
def _dataset_tuning_profile(X_train=None, y_train=None, task_type: str | None = None) -> dict[str, Any]:
    n_rows = int(X_train.shape[0]) if X_train is not None else 1000
    n_features = int(X_train.shape[1]) if X_train is not None else 20
    p_over_n = float(n_features / max(n_rows, 1))

    size_bucket = "small" if n_rows < 1_000 else "medium" if n_rows < 20_000 else "large"
    width_bucket = "narrow" if n_features < 30 else "moderate" if n_features < 100 else "wide" if n_features < 300 else "very_wide"

    imbalance_ratio = None
    minority_count = None
    n_classes = None

    if task_type == "Classification" and y_train is not None:
        y = _to_series_safe(y_train)
        vc = y.value_counts(dropna=False)
        if len(vc) > 0:
            minority_count = int(vc.min())
            majority_count = int(vc.max())
            imbalance_ratio = float(majority_count / max(minority_count, 1))
            n_classes = int(len(vc))

    return {
        "n_rows": n_rows,
        "n_features": n_features,
        "p_over_n": p_over_n,
        "size_bucket": size_bucket,
        "width_bucket": width_bucket,
        "imbalance_ratio": imbalance_ratio,
        "minority_count": minority_count,
        "n_classes": n_classes,
    }


def _log_grid(start_exp: float, end_exp: float, n: int) -> list[float]:
    vals = np.logspace(start_exp, end_exp, n)
    return [float(np.round(v, 12)) for v in vals]


def _adaptive_k_values(n_rows: int, profile: str) -> list[int]:
    max_k = max(3, min(int(np.sqrt(max(n_rows, 1))), max(15, int(0.05 * n_rows))))
    raw = [3, 5, 7, 11, 15, 21, 31, 41, 61, 81, 101]
    vals = [k for k in raw if k <= max_k]
    if not vals:
        vals = [3, 5]
    if profile == "Light":
        return vals[:3]
    if profile == "Medium":
        return vals[:6]
    return vals


def _adaptive_tree_depths(n_rows: int, n_features: int, profile: str) -> list[Any]:
    vals: list[Any] = [None]

    if n_rows < 1_000:
        vals += [3, 5, 8, 12]
    elif n_rows < 20_000:
        vals += [4, 6, 10, 16, 24]
    else:
        vals += [4, 6, 10, 16]

    if n_features >= 100:
        vals = [d for d in vals if d is None or d <= 16]

    if profile == "Light":
        return vals[:3]
    if profile == "Medium":
        return vals[:5]
    return vals


def _adaptive_n_estimators(profile: str, n_rows: int) -> list[int]:
    large = n_rows >= 20_000
    if profile == "Light":
        return [200, 300] if large else [200, 400]
    if profile == "Medium":
        return [200, 400, 600] if large else [200, 400, 800]
    return [300, 600, 900] if large else [200, 400, 800, 1200]


def _adaptive_min_leaf(n_rows: int, profile: str) -> list[int]:
    if n_rows < 1_000:
        vals = [1, 2, 5]
    elif n_rows < 20_000:
        vals = [1, 2, 5, 10]
    else:
        vals = [1, 2, 5, 10, 20]

    if profile == "Light":
        return vals[:2]
    if profile == "Medium":
        return vals[:4]
    return vals


def _adaptive_learning_rates(profile: str) -> list[float]:
    if profile == "Light":
        return [0.03, 0.1]
    if profile == "Medium":
        return [0.01, 0.03, 0.1]
    return [0.005, 0.01, 0.03, 0.1]


def _adaptive_gamma_values(n_features: int, profile: str) -> list[Any]:
    p = max(int(n_features), 1)
    numeric = sorted({
        float(np.round(1.0 / p, 12)),
        float(np.round(1.0 / np.sqrt(p), 12)),
        float(np.round(10.0 / p, 12)),
    })
    vals: list[Any] = ["scale", "auto"] + numeric
    if profile == "Light":
        return vals[:3]
    if profile == "Medium":
        return vals[:4]
    return vals


def _adaptive_hidden_layers(n_rows: int, n_features: int, profile: str) -> list[tuple]:
    base = min(max(16, n_features), 256)
    half = max(8, base // 2)
    quarter = max(8, base // 4)

    vals = [
        (half,),
        (base,),
        (base, half),
        (base, half, quarter),
    ]

    if n_rows >= 10_000 and n_features <= 100:
        vals.append((min(512, base * 2), base))

    if profile == "Light":
        return vals[:2]
    if profile == "Medium":
        return vals[:4]
    return vals


def _adaptive_regularization(profile: str, stronger: bool = False) -> list[float]:
    if profile == "Light":
        vals = _log_grid(-2, 2, 5)
    elif profile == "Medium":
        vals = _log_grid(-4, 3, 8)
    else:
        vals = _log_grid(-6, 4, 11)

    if stronger:
        vals = sorted(set(vals + _log_grid(-1, 4, 7)))
    return vals


def _adaptive_max_features(n_features: int, profile: str) -> list[Any]:
    vals: list[Any] = ["sqrt", "log2"]
    if n_features < 30:
        vals += [None]
    elif n_features < 100:
        vals += [0.5, 0.8]
    else:
        vals += [0.2, 0.5]

    if profile == "Light":
        return vals[:2]
    if profile == "Medium":
        return vals[:3]
    return vals


# =============================================================================
# Metrics / CV
# =============================================================================
def _cv_predictions_and_metric_summary(
    pipeline,
    X_train,
    y_train,
    cv_splitter,
    task_type: str,
    metric_names: list[str],
    labels: list[Any] | None = None,
):
    X_train = X_train.copy()
    y_train = pd.Series(y_train).copy()

    pred_df = pd.DataFrame(index=X_train.index)
    pred_df["y_true"] = y_train
    pred_df["prediction"] = np.nan
    pred_df["cv_fold"] = np.nan

    fold_rows = []
    global_label_to_idx = {}

    if task_type == "Classification" and labels is not None:
        global_label_to_idx = {label: idx for idx, label in enumerate(labels)}
        for idx in range(len(labels)):
            pred_df[f"probability_{idx}"] = np.nan

    for fold_idx, (train_idx, valid_idx) in enumerate(cv_splitter.split(X_train, y_train), start=1):
        X_tr = X_train.iloc[train_idx].copy()
        y_tr = y_train.iloc[train_idx].copy()
        X_va = X_train.iloc[valid_idx].copy()
        y_va = y_train.iloc[valid_idx].copy()

        model = clone(pipeline)
        model.fit(X_tr, y_tr)

        y_va_pred = model.predict(X_va)
        pred_df.loc[X_va.index, "prediction"] = pd.Series(y_va_pred, index=X_va.index)
        pred_df.loc[X_va.index, "cv_fold"] = fold_idx

        proba = None
        if hasattr(model, "predict_proba"):
            try:
                proba = model.predict_proba(X_va)
            except Exception:
                proba = None

        if proba is not None and task_type == "Classification":
            local_classes = None
            if hasattr(model, "classes_"):
                try:
                    local_classes = list(model.classes_)
                except Exception:
                    local_classes = None
            if local_classes is None and hasattr(model, "named_steps") and "model" in model.named_steps:
                final_model = model.named_steps["model"]
                if hasattr(final_model, "classes_"):
                    try:
                        local_classes = list(final_model.classes_)
                    except Exception:
                        local_classes = None

            if local_classes is not None and global_label_to_idx:
                for local_j, cls in enumerate(local_classes):
                    if cls in global_label_to_idx and local_j < proba.shape[1]:
                        global_j = global_label_to_idx[cls]
                        pred_df.loc[X_va.index, f"probability_{global_j}"] = proba[:, local_j]
            else:
                for j in range(proba.shape[1]):
                    col = f"probability_{j}"
                    if col not in pred_df.columns:
                        pred_df[col] = np.nan
                    pred_df.loc[X_va.index, col] = proba[:, j]

        metric_map = _all_metrics_from_predictions(
            task_type=task_type,
            y_true=y_va,
            y_pred=y_va_pred,
            proba=proba,
            labels=labels,
        )

        row = {"cv_fold": int(fold_idx), "validation_size": int(len(valid_idx))}
        for metric_name in metric_names:
            row[metric_name] = metric_map.get(metric_name, np.nan)
        fold_rows.append(row)

    try:
        if pd.api.types.is_numeric_dtype(y_train):
            pred_df["prediction"] = pd.to_numeric(pred_df["prediction"], errors="coerce")
            if not pred_df["prediction"].isna().any():
                pred_df["prediction"] = pred_df["prediction"].astype(y_train.dtype)
        else:
            pred_df["prediction"] = pred_df["prediction"].astype(y_train.dtype)
    except Exception:
        pred_df["prediction"] = pred_df["prediction"].astype("object")

    fold_table = pd.DataFrame(fold_rows)
    validation_summary = {}
    for metric_name in metric_names:
        if metric_name in fold_table.columns:
            vals = pd.to_numeric(fold_table[metric_name], errors="coerce")
            valid_vals = vals.dropna()
            validation_summary[metric_name] = {
                "mean": float(valid_vals.mean()) if not valid_vals.empty else np.nan,
                "std": float(valid_vals.std(ddof=0)) if not valid_vals.empty else np.nan,
            }
        else:
            validation_summary[metric_name] = {"mean": np.nan, "std": np.nan}

    return pred_df.sort_index(), validation_summary, fold_table


def build_cv_splitter(config: ModelRunConfig, y_train: pd.Series, task_type: str):
    method = config.cv.method
    n_splits = int(config.cv.n_splits)
    n_repeats = int(config.cv.n_repeats)
    shuffle = bool(config.cv.shuffle)
    random_state = int(config.cv.random_state)

    if method == "auto":
        method = "Stratified K-Fold" if task_type == "Classification" else "K-Fold"

    if task_type == "Classification" and method in {"Stratified K-Fold", "Repeated Stratified K-Fold"}:
        n_splits = _safe_cv_n_splits_for_classification(y_train, n_splits)

    if method == "Stratified K-Fold":
        return StratifiedKFold(n_splits=n_splits, shuffle=shuffle, random_state=random_state)
    if method == "Repeated Stratified K-Fold":
        return RepeatedStratifiedKFold(n_splits=n_splits, n_repeats=n_repeats, random_state=random_state)
    if method == "Repeated K-Fold":
        return RepeatedKFold(n_splits=n_splits, n_repeats=n_repeats, random_state=random_state)
    if method == "Time series split":
        return TimeSeriesSplit(n_splits=n_splits)
    return KFold(n_splits=n_splits, shuffle=shuffle, random_state=random_state)


def build_metric_catalog(task_type: str, labels: list[Any] | None = None) -> dict[str, dict[str, Any]]:
    labels = [] if labels is None else list(labels)

    if task_type == "Classification":
        catalog = {
            "Accuracy": {"scorer_name": "accuracy", "flip_sign": False},
            "Balanced accuracy": {"scorer_name": "balanced_accuracy", "flip_sign": False},
            "Precision": {"scorer_name": "precision", "flip_sign": False},
            "Recall": {"scorer_name": "recall", "flip_sign": False},
            "F1 score": {"scorer_name": "f1", "flip_sign": False},
            "Precision macro": {"scorer_name": "precision_macro", "flip_sign": False},
            "Precision micro": {"scorer_name": "precision_micro", "flip_sign": False},
            "Precision weighted": {"scorer_name": "precision_weighted", "flip_sign": False},
            "Recall macro": {"scorer_name": "recall_macro", "flip_sign": False},
            "Recall micro": {"scorer_name": "recall_micro", "flip_sign": False},
            "Recall weighted": {"scorer_name": "recall_weighted", "flip_sign": False},
            "F1 score macro": {"scorer_name": "f1_macro", "flip_sign": False},
            "F1 score micro": {"scorer_name": "f1_micro", "flip_sign": False},
            "F1 score weighted": {"scorer_name": "f1_weighted", "flip_sign": False},
            "Jaccard index": {"scorer_name": "jaccard", "flip_sign": False},
            "Jaccard index macro": {"scorer_name": "jaccard_macro", "flip_sign": False},
            "Jaccard index micro": {"scorer_name": "jaccard_micro", "flip_sign": False},
            "Jaccard index weighted": {"scorer_name": "jaccard_weighted", "flip_sign": False},
            "Matthews correlation coefficient": {"scorer_name": "matthews_corrcoef", "flip_sign": False},
            "ROC AUC": {"scorer_name": "roc_auc", "flip_sign": False},
            "ROC AUC one-vs-rest": {"scorer_name": "roc_auc_ovr", "flip_sign": False},
            "ROC AUC one-vs-rest weighted": {"scorer_name": "roc_auc_ovr_weighted", "flip_sign": False},
            "ROC AUC one-vs-one": {"scorer_name": "roc_auc_ovo", "flip_sign": False},
            "ROC AUC one-vs-one weighted": {"scorer_name": "roc_auc_ovo_weighted", "flip_sign": False},
            "Average precision": {"scorer_name": "average_precision", "flip_sign": False},
            "Log loss": {"scorer_name": "neg_log_loss", "flip_sign": True},
            "Brier score loss": {"scorer_name": "neg_brier_score", "flip_sign": True},
        }

        if len(labels) == 2:
            for label in labels:
                label_name = str(label)
                catalog[f"Precision (label {label_name})"] = {
                    "scorer_name": "custom_label_precision",
                    "flip_sign": False,
                    "label": label,
                }
                catalog[f"Recall (label {label_name})"] = {
                    "scorer_name": "custom_label_recall",
                    "flip_sign": False,
                    "label": label,
                }
                catalog[f"F1 score (label {label_name})"] = {
                    "scorer_name": "custom_label_f1",
                    "flip_sign": False,
                    "label": label,
                }
                catalog[f"Jaccard index (label {label_name})"] = {
                    "scorer_name": "custom_label_jaccard",
                    "flip_sign": False,
                    "label": label,
                }
        return catalog

    catalog = {
        "Explained variance": {"scorer_name": "explained_variance", "flip_sign": False},
        "R-squared": {"scorer_name": "r2", "flip_sign": False},
        "Mean absolute error (MAE)": {"scorer_name": "neg_mean_absolute_error", "flip_sign": True},
        "Mean squared error (MSE)": {"scorer_name": "neg_mean_squared_error", "flip_sign": True},
        "Root mean squared error (RMSE)": {"scorer_name": "neg_root_mean_squared_error", "flip_sign": True},
        "Mean squared log error (MSLE)": {"scorer_name": "neg_mean_squared_log_error", "flip_sign": True},
        "Median absolute error": {"scorer_name": "neg_median_absolute_error", "flip_sign": True},
        "Mean absolute percentage error (MAPE)": {"scorer_name": "neg_mean_absolute_percentage_error", "flip_sign": True},
        "Symmetric mean absolute percentage error (SMAPE)": {"scorer_name": "smape", "flip_sign": True},
        "Maximum error": {"scorer_name": "neg_max_error", "flip_sign": True},
        "Mean Poisson deviance": {"scorer_name": "neg_mean_poisson_deviance", "flip_sign": True},
        "Mean Gamma deviance": {"scorer_name": "neg_mean_gamma_deviance", "flip_sign": True},
        "D² absolute error score": {"scorer_name": "d2_absolute_error_score", "flip_sign": False},
        "D² pinball score": {"scorer_name": "d2_pinball_score", "flip_sign": False},
        "D² Tweedie score": {"scorer_name": "d2_tweedie_score", "flip_sign": False},
    }

    supported = {}
    scorer_names = set(get_scorer_names())
    for metric_name, cfg in catalog.items():
        scorer_name = cfg["scorer_name"]
        if scorer_name == "smape":
            supported[metric_name] = cfg
        elif scorer_name == "d2_absolute_error_score" and d2_absolute_error_score is not None:
            supported[metric_name] = cfg
        elif scorer_name == "d2_pinball_score" and d2_pinball_score is not None:
            supported[metric_name] = cfg
        elif scorer_name == "d2_tweedie_score" and d2_tweedie_score is not None:
            supported[metric_name] = cfg
        elif scorer_name in scorer_names:
            supported[metric_name] = cfg
    return supported


def get_metric_scorer(metric_display_name: str, task_type: str, labels: list[Any] | None = None):
    cfg = build_metric_catalog(task_type, labels=labels)[metric_display_name]
    scorer_name = cfg["scorer_name"]

    if scorer_name == "smape":
        return make_scorer(smape, greater_is_better=False)
    if scorer_name == "d2_absolute_error_score":
        return make_scorer(d2_absolute_error_score, greater_is_better=True)
    if scorer_name == "d2_pinball_score":
        return make_scorer(d2_pinball_score, greater_is_better=True)
    if scorer_name == "d2_tweedie_score":
        return make_scorer(d2_tweedie_score, greater_is_better=True)
    if scorer_name == "custom_label_precision":
        return make_scorer(precision_score, labels=[cfg["label"]], average=None, zero_division=0)
    if scorer_name == "custom_label_recall":
        return make_scorer(recall_score, labels=[cfg["label"]], average=None, zero_division=0)
    if scorer_name == "custom_label_f1":
        return make_scorer(f1_score, labels=[cfg["label"]], average=None, zero_division=0)
    if scorer_name == "custom_label_jaccard":
        return make_scorer(jaccard_score, labels=[cfg["label"]], average=None, zero_division=0)
    return get_scorer(scorer_name)


def display_metric_value(raw_value: float, metric_display_name: str, task_type: str, labels: list[Any] | None = None) -> float:
    if pd.isna(raw_value):
        return np.nan
    if isinstance(raw_value, (list, tuple, np.ndarray)):
        arr = np.asarray(raw_value, dtype=float).ravel()
        raw_value = arr[0] if arr.size else np.nan
        if pd.isna(raw_value):
            return np.nan
    cfg = build_metric_catalog(task_type, labels=labels)[metric_display_name]
    return -float(raw_value) if cfg["flip_sign"] else float(raw_value)


def _get_metric_names(task_type: str, labels: list[Any] | None = None) -> list[str]:
    return list(build_metric_catalog(task_type, labels=labels).keys())


# =============================================================================
# Model docs
# =============================================================================
def classification_algorithm_docs() -> dict[str, str]:
    return {
        "Logistic regression": "Linear classifier; strong baseline with probabilities.",
        "Random forest": "Bagged decision trees; robust non-linear model.",
        "Extra trees": "Highly randomized trees; often strong and fast.",
        "Gradient boosting": "Sequential trees that improve residual errors.",
        "Histogram gradient boosting": "Efficient gradient boosting for tabular data.",
        "XGBoost": "Optimized boosted trees; often very strong on tabular data.",
        "SVM (RBF)": "Non-linear margin classifier with RBF kernel.",
        "SVM (Linear)": "Linear support vector classifier.",
        "SVM (Poly)": "Polynomial-kernel support vector classifier.",
        "K-nearest neighbors": "Distance-based classifier.",
        "Neural net (MLP)": "Feed-forward neural network classifier.",
    }


def regression_algorithm_docs() -> dict[str, str]:
    return {
        "Dummy (mean)": "Predicts the mean target value.",
        "Linear regression": "Classic linear baseline.",
        "Ridge regression": "Linear regression with L2 regularization.",
        "Lasso regression": "Linear regression with L1 regularization.",
        "Elastic net": "Linear regression with mixed L1 and L2 regularization.",
        "Random forest": "Bagged regression trees.",
        "Extra trees": "Highly randomized regression trees.",
        "Gradient boosting": "Boosted regression trees.",
        "Histogram gradient boosting": "Efficient boosted trees for regression.",
        "XGBoost": "Optimized boosted trees for regression.",
        "SVR (RBF)": "Non-linear support vector regression.",
        "SVR (Linear)": "Linear support vector regression.",
        "SVR (Poly)": "Polynomial support vector regression.",
        "K-nearest neighbors": "Distance-based regression.",
        "Neural net (MLP)": "Feed-forward neural network regressor.",
    }


# =============================================================================
# Adaptive param grids
# =============================================================================
def param_grids(task_type: str, model_name: str, X_train=None, y_train=None):
    """
    Output shape kept the same:
        {
            "Light": {...},
            "Medium": {...},
            "Heavy": {...}
        }

    The grids adapt to dataset characteristics when X_train / y_train are given.
    """
    prof = _dataset_tuning_profile(X_train=X_train, y_train=y_train, task_type=task_type)

    n_rows = prof["n_rows"]
    n_features = prof["n_features"]
    p_over_n = prof["p_over_n"]
    imbalance_ratio = prof["imbalance_ratio"]

    wide_data = n_features >= 100
    large_data = n_rows >= 20_000
    stronger_reg = (p_over_n > 0.2) or wide_data

    def build_for_profile(profile: str):
        if task_type == "Classification":
            grids = {
                "Logistic regression": {
                    "model__C": _adaptive_regularization(profile, stronger=stronger_reg),
                    **(
                        {"model__solver": ["lbfgs"]}
                        if profile == "Light"
                        else {"model__solver": ["lbfgs", "liblinear"]}
                        if profile == "Medium"
                        else {"model__solver": ["lbfgs", "liblinear", "saga"]}
                    ),
                },
                "Random forest": {
                    "model__n_estimators": _adaptive_n_estimators(profile, n_rows),
                    "model__max_depth": _adaptive_tree_depths(n_rows, n_features, profile),
                    "model__min_samples_leaf": _adaptive_min_leaf(n_rows, profile),
                    **({} if profile == "Light" else {"model__min_samples_split": [2, 5, 10]}),
                    **({} if profile != "Heavy" else {"model__bootstrap": [True, False]}),
                    **({} if profile == "Light" else {"model__max_features": _adaptive_max_features(n_features, profile)}),
                },
                "Extra trees": {
                    "model__n_estimators": _adaptive_n_estimators(profile, n_rows),
                    "model__max_depth": _adaptive_tree_depths(n_rows, n_features, profile),
                    "model__min_samples_leaf": _adaptive_min_leaf(n_rows, profile),
                    **({} if profile == "Light" else {"model__min_samples_split": [2, 5, 10]}),
                    **({} if profile != "Heavy" else {"model__bootstrap": [True, False]}),
                    **({} if profile == "Light" else {"model__max_features": _adaptive_max_features(n_features, profile)}),
                },
                "Gradient boosting": {
                    "model__n_estimators": [100, 200] if profile == "Light" else [100, 200, 300] if profile == "Medium" else [100, 200, 300, 500],
                    "model__learning_rate": _adaptive_learning_rates(profile),
                    "model__max_depth": [2, 3] if profile == "Light" else [2, 3, 4] if profile == "Medium" else [2, 3, 4, 5],
                    **({} if profile == "Light" else {"model__subsample": [0.8, 1.0]}),
                    **({} if profile != "Heavy" else {"model__min_samples_leaf": _adaptive_min_leaf(n_rows, profile)}),
                },
                "Histogram gradient boosting": {
                    "model__max_depth": _adaptive_tree_depths(n_rows, n_features, profile),
                    "model__learning_rate": _adaptive_learning_rates(profile),
                    "model__max_iter": [100, 200] if profile == "Light" else [100, 200, 300] if profile == "Medium" else [100, 200, 300, 500],
                    "model__min_samples_leaf": _adaptive_min_leaf(n_rows, profile),
                    **({} if profile == "Light" else {"model__l2_regularization": [0.0, 1e-4, 1e-2]}),
                    **({} if profile != "Heavy" else {"model__max_bins": [255, 128] if not large_data else [255, 128, 64]}),
                },
                "XGBoost": {
                    "model__n_estimators": _adaptive_n_estimators(profile, n_rows),
                    "model__max_depth": (
                        [3, 5]
                        if wide_data and profile == "Light"
                        else [3, 5, 7]
                        if profile != "Heavy"
                        else ([3, 5, 7] if wide_data else [3, 5, 7, 9])
                    ),
                    "model__learning_rate": _adaptive_learning_rates(profile),
                    "model__subsample": [0.8, 1.0] if profile == "Light" else [0.7, 0.85, 1.0] if profile == "Medium" else [0.6, 0.75, 0.9, 1.0],
                    **({} if profile == "Light" else {"model__colsample_bytree": [0.7, 0.85, 1.0]}),
                    **({} if profile == "Light" else {"model__min_child_weight": [1, 3, 5]}),
                    **({} if profile != "Heavy" else {
                        "model__gamma": [0, 0.1, 0.3, 1.0],
                        "model__reg_alpha": [0, 0.01, 0.1, 1.0],
                        "model__reg_lambda": [1, 5, 10, 20],
                    }),
                },
                "SVM (RBF)": {
                    "model__C": _adaptive_regularization(profile, stronger=False),
                    "model__gamma": _adaptive_gamma_values(n_features, profile),
                },
                "SVM (Linear)": {
                    "model__C": _adaptive_regularization(profile, stronger=stronger_reg),
                },
                "SVM (Poly)": {
                    "model__C": _adaptive_regularization(profile, stronger=False),
                    "model__degree": [2, 3] if profile != "Heavy" else [2, 3, 4],
                    "model__gamma": _adaptive_gamma_values(n_features, profile),
                },
                "Neural net (MLP)": {
                    "model__hidden_layer_sizes": _adaptive_hidden_layers(n_rows, n_features, profile),
                    **({} if profile == "Light" else {"model__alpha": [1e-4, 1e-3]} if profile == "Medium" else {"model__alpha": [1e-5, 1e-4, 1e-3]}),
                    **({} if profile == "Light" else {"model__learning_rate_init": [1e-4, 1e-3]}),
                    **({} if profile != "Heavy" else {"model__activation": ["relu", "tanh"]}),
                },
                "K-nearest neighbors": {
                    "model__n_neighbors": _adaptive_k_values(n_rows, profile),
                    **({} if profile == "Light" else {"model__weights": ["uniform", "distance"]}),
                    **({} if profile != "Heavy" else {"model__p": [1, 2]}),
                },
            }

            if imbalance_ratio is not None and imbalance_ratio >= 3:
                if model_name in {"Logistic regression", "SVM (RBF)", "SVM (Linear)", "SVM (Poly)"}:
                    grids[model_name]["model__class_weight"] = [None, "balanced"]

            return grids

        grids = {
            "Dummy (mean)": {},
            "Linear regression": {},
            "Ridge regression": {
                "model__alpha": _adaptive_regularization(profile, stronger=stronger_reg),
            },
            "Lasso regression": {
                "model__alpha": _adaptive_regularization(profile, stronger=stronger_reg),
            },
            "Elastic net": {
                "model__alpha": _adaptive_regularization(profile, stronger=stronger_reg),
                "model__l1_ratio": [0.2, 0.5, 0.8] if profile == "Light" else [0.1, 0.3, 0.5, 0.7, 0.9],
            },
            "Random forest": {
                "model__n_estimators": _adaptive_n_estimators(profile, n_rows),
                "model__max_depth": _adaptive_tree_depths(n_rows, n_features, profile),
                "model__min_samples_leaf": _adaptive_min_leaf(n_rows, profile),
                **({} if profile == "Light" else {"model__min_samples_split": [2, 5, 10]}),
                **({} if profile != "Heavy" else {"model__bootstrap": [True, False]}),
                **({} if profile == "Light" else {"model__max_features": _adaptive_max_features(n_features, profile)}),
            },
            "Extra trees": {
                "model__n_estimators": _adaptive_n_estimators(profile, n_rows),
                "model__max_depth": _adaptive_tree_depths(n_rows, n_features, profile),
                "model__min_samples_leaf": _adaptive_min_leaf(n_rows, profile),
                **({} if profile == "Light" else {"model__min_samples_split": [2, 5, 10]}),
                **({} if profile != "Heavy" else {"model__bootstrap": [True, False]}),
                **({} if profile == "Light" else {"model__max_features": _adaptive_max_features(n_features, profile)}),
            },
            "Gradient boosting": {
                "model__n_estimators": [100, 200] if profile == "Light" else [100, 200, 300] if profile == "Medium" else [100, 200, 300, 500],
                "model__learning_rate": _adaptive_learning_rates(profile),
                "model__max_depth": [2, 3] if profile == "Light" else [2, 3, 4] if profile == "Medium" else [2, 3, 4, 5],
                **({} if profile == "Light" else {"model__subsample": [0.8, 1.0]}),
                **({} if profile != "Heavy" else {"model__min_samples_leaf": _adaptive_min_leaf(n_rows, profile)}),
            },
            "Histogram gradient boosting": {
                "model__max_depth": _adaptive_tree_depths(n_rows, n_features, profile),
                "model__learning_rate": _adaptive_learning_rates(profile),
                "model__max_iter": [100, 200] if profile == "Light" else [100, 200, 300] if profile == "Medium" else [100, 200, 300, 500],
                "model__min_samples_leaf": _adaptive_min_leaf(n_rows, profile),
                **({} if profile == "Light" else {"model__l2_regularization": [0.0, 1e-4, 1e-2]}),
                **({} if profile != "Heavy" else {"model__max_bins": [255, 128] if not large_data else [255, 128, 64]}),
            },
            "XGBoost": {
                "model__n_estimators": _adaptive_n_estimators(profile, n_rows),
                "model__max_depth": (
                    [3, 5]
                    if wide_data and profile == "Light"
                    else [3, 5, 7]
                    if profile != "Heavy"
                    else ([3, 5, 7] if wide_data else [3, 5, 7, 9])
                ),
                "model__learning_rate": _adaptive_learning_rates(profile),
                "model__subsample": [0.8, 1.0] if profile == "Light" else [0.7, 0.85, 1.0] if profile == "Medium" else [0.6, 0.75, 0.9, 1.0],
                **({} if profile == "Light" else {"model__colsample_bytree": [0.7, 0.85, 1.0]}),
                **({} if profile == "Light" else {"model__min_child_weight": [1, 3, 5]}),
                **({} if profile != "Heavy" else {
                    "model__gamma": [0, 0.1, 0.3, 1.0],
                    "model__reg_alpha": [0, 0.01, 0.1, 1.0],
                    "model__reg_lambda": [1, 5, 10, 20],
                }),
            },
            "SVR (RBF)": {
                "model__C": _adaptive_regularization(profile, stronger=False),
                "model__gamma": _adaptive_gamma_values(n_features, profile),
            },
            "SVR (Linear)": {
                "model__C": _adaptive_regularization(profile, stronger=stronger_reg),
            },
            "SVR (Poly)": {
                "model__C": _adaptive_regularization(profile, stronger=False),
                "model__degree": [2, 3] if profile != "Heavy" else [2, 3, 4],
                "model__gamma": _adaptive_gamma_values(n_features, profile),
            },
            "Neural net (MLP)": {
                "model__hidden_layer_sizes": _adaptive_hidden_layers(n_rows, n_features, profile),
                **({} if profile == "Light" else {"model__alpha": [1e-4, 1e-3]} if profile == "Medium" else {"model__alpha": [1e-5, 1e-4, 1e-3]}),
                **({} if profile == "Light" else {"model__learning_rate_init": [1e-4, 1e-3]}),
                **({} if profile != "Heavy" else {"model__activation": ["relu", "tanh"]}),
            },
            "K-nearest neighbors": {
                "model__n_neighbors": _adaptive_k_values(n_rows, profile),
                **({} if profile == "Light" else {"model__weights": ["uniform", "distance"]}),
                **({} if profile != "Heavy" else {"model__p": [1, 2]}),
            },
        }
        return grids

    return {
        "Light": build_for_profile("Light").get(model_name, {}),
        "Medium": build_for_profile("Medium").get(model_name, {}),
        "Heavy": build_for_profile("Heavy").get(model_name, {}),
    }


# =============================================================================
# Estimators / pipelines
# =============================================================================
def build_estimator(task_type: str, model_name: str, imbalance_method: str = "none", random_state: int = 42, n_jobs: int = -1):
    class_weight = "balanced" if task_type == "Classification" and imbalance_method == "class_weight" else None

    classification_mapping = {
        "Logistic regression": LogisticRegression(max_iter=3000, class_weight=class_weight, random_state=random_state),
        "Random forest": RandomForestClassifier(n_estimators=400, random_state=random_state, n_jobs=n_jobs, class_weight=class_weight),
        "Extra trees": ExtraTreesClassifier(n_estimators=500, random_state=random_state, n_jobs=n_jobs, class_weight=class_weight),
        "Gradient boosting": GradientBoostingClassifier(random_state=random_state),
        "Histogram gradient boosting": HistGradientBoostingClassifier(random_state=random_state),
        "SVM (RBF)": SVC(kernel="rbf", probability=True, class_weight=class_weight, random_state=random_state),
        "SVM (Linear)": SVC(kernel="linear", probability=True, class_weight=class_weight, random_state=random_state),
        "SVM (Poly)": SVC(kernel="poly", probability=True, class_weight=class_weight, random_state=random_state),
        "K-nearest neighbors": KNeighborsClassifier(),
        "Neural net (MLP)": MLPClassifier(max_iter=400, random_state=random_state),
    }

    regression_mapping = {
        "Dummy (mean)": DummyRegressor(strategy="mean"),
        "Linear regression": LinearRegression(),
        "Ridge regression": Ridge(random_state=random_state),
        "Lasso regression": Lasso(max_iter=5000, random_state=random_state),
        "Elastic net": ElasticNet(max_iter=5000, random_state=random_state),
        "Random forest": RandomForestRegressor(n_estimators=400, random_state=random_state, n_jobs=n_jobs),
        "Extra trees": ExtraTreesRegressor(n_estimators=500, random_state=random_state, n_jobs=n_jobs),
        "Gradient boosting": GradientBoostingRegressor(random_state=random_state),
        "Histogram gradient boosting": HistGradientBoostingRegressor(random_state=random_state),
        "SVR (RBF)": SVR(kernel="rbf"),
        "SVR (Linear)": SVR(kernel="linear"),
        "SVR (Poly)": SVR(kernel="poly"),
        "K-nearest neighbors": KNeighborsRegressor(),
        "Neural net (MLP)": MLPRegressor(max_iter=500, random_state=random_state),
    }

    if task_type == "Classification":
        if model_name == "XGBoost":
            if XGBClassifier is None:
                raise ImportError("xgboost is not installed.")
            return XGBClassifier(
                n_estimators=400,
                random_state=random_state,
                n_jobs=n_jobs,
                eval_metric="logloss",
            )
        if model_name not in classification_mapping:
            raise ValueError(f"Unsupported classification estimator: {model_name}")
        return classification_mapping[model_name]

    if model_name == "XGBoost":
        if XGBRegressor is None:
            raise ImportError("xgboost is not installed.")
        return XGBRegressor(
            n_estimators=400,
            random_state=random_state,
            n_jobs=n_jobs,
            eval_metric="rmse",
        )
    if model_name not in regression_mapping:
        raise ValueError(f"Unsupported regression estimator: {model_name}")
    return regression_mapping[model_name]


def _build_single_model_pipeline(task_type: str, model_name: str, config: ModelRunConfig):
    estimator = build_estimator(
        task_type=task_type,
        model_name=model_name,
        imbalance_method=config.imbalance_method,
        random_state=config.random_state,
        n_jobs=config.n_jobs_models,
    )
    if task_type == "Classification" and config.imbalance_method == "smote":
        if SMOTE is None or ImbPipeline is None:
            raise ImportError("imbalanced-learn is not installed.")
        return ImbPipeline([
            ("smote", SMOTE(random_state=config.random_state)),
            ("model", estimator),
        ])
    return Pipeline([("model", estimator)])


def _build_stacking_pipeline(task_type: str, config: ModelRunConfig):
    if not config.stacking.base_models:
        raise ValueError("stacking.base_models cannot be empty when stacking is enabled.")

    estimators = []
    for name in config.stacking.base_models:
        short_name = name.lower().replace(" ", "_").replace("(", "").replace(")", "")
        estimators.append((
            short_name,
            build_estimator(
                task_type=task_type,
                model_name=name,
                imbalance_method=config.imbalance_method,
                random_state=config.random_state,
                n_jobs=config.n_jobs_models,
            ),
        ))

    if task_type == "Classification":
        final_name = config.stacking.final_estimator or "Logistic regression"
        final_est = build_estimator(task_type, final_name, "none", config.random_state, config.n_jobs_models)
        model = StackingClassifier(
            estimators=estimators,
            final_estimator=final_est,
            passthrough=config.stacking.passthrough,
            n_jobs=config.n_jobs_models,
        )
    else:
        final_name = config.stacking.final_estimator or "Ridge regression"
        final_est = build_estimator(task_type, final_name, "none", config.random_state, config.n_jobs_models)
        model = StackingRegressor(
            estimators=estimators,
            final_estimator=final_est,
            passthrough=config.stacking.passthrough,
            n_jobs=config.n_jobs_models,
        )

    if task_type == "Classification" and config.imbalance_method == "smote":
        if SMOTE is None or ImbPipeline is None:
            raise ImportError("imbalanced-learn is not installed.")
        return ImbPipeline([
            ("smote", SMOTE(random_state=config.random_state)),
            ("model", model),
        ])

    return Pipeline([("model", model)])


# =============================================================================
# Prediction / metric helpers
# =============================================================================
def _binary_positive_proba(proba: np.ndarray | None):
    if proba is None:
        return None
    arr = np.asarray(proba)
    if arr.ndim != 2 or arr.shape[1] < 2:
        return None
    return arr[:, 1]


def _compute_metric_from_predictions(metric_name: str, cfg: dict[str, Any], task_type: str, y_true, y_pred, proba: np.ndarray | None = None, labels: list[Any] | None = None) -> float:
    y_true = pd.Series(y_true)
    y_pred = pd.Series(y_pred)
    labels = [] if labels is None else list(labels)

    if task_type == "Classification":
        scorer_name = cfg["scorer_name"]
        binary = len(labels) == 2
        pos_label = labels[1] if binary else None
        pos_proba = _binary_positive_proba(proba)

        try:
            if scorer_name == "accuracy":
                return accuracy_score(y_true, y_pred)
            if scorer_name == "balanced_accuracy":
                return balanced_accuracy_score(y_true, y_pred)
            if scorer_name == "precision":
                return precision_score(y_true, y_pred, pos_label=pos_label, zero_division=0) if binary else np.nan
            if scorer_name == "recall":
                return recall_score(y_true, y_pred, pos_label=pos_label, zero_division=0) if binary else np.nan
            if scorer_name == "f1":
                return f1_score(y_true, y_pred, pos_label=pos_label, zero_division=0) if binary else np.nan
            if scorer_name == "precision_macro":
                return precision_score(y_true, y_pred, average="macro", zero_division=0)
            if scorer_name == "precision_micro":
                return precision_score(y_true, y_pred, average="micro", zero_division=0)
            if scorer_name == "precision_weighted":
                return precision_score(y_true, y_pred, average="weighted", zero_division=0)
            if scorer_name == "recall_macro":
                return recall_score(y_true, y_pred, average="macro", zero_division=0)
            if scorer_name == "recall_micro":
                return recall_score(y_true, y_pred, average="micro", zero_division=0)
            if scorer_name == "recall_weighted":
                return recall_score(y_true, y_pred, average="weighted", zero_division=0)
            if scorer_name == "f1_macro":
                return f1_score(y_true, y_pred, average="macro", zero_division=0)
            if scorer_name == "f1_micro":
                return f1_score(y_true, y_pred, average="micro", zero_division=0)
            if scorer_name == "f1_weighted":
                return f1_score(y_true, y_pred, average="weighted", zero_division=0)
            if scorer_name == "jaccard":
                return jaccard_score(y_true, y_pred, pos_label=pos_label, zero_division=0) if binary else np.nan
            if scorer_name == "jaccard_macro":
                return jaccard_score(y_true, y_pred, average="macro", zero_division=0)
            if scorer_name == "jaccard_micro":
                return jaccard_score(y_true, y_pred, average="micro", zero_division=0)
            if scorer_name == "jaccard_weighted":
                return jaccard_score(y_true, y_pred, average="weighted", zero_division=0)
            if scorer_name == "matthews_corrcoef":
                return matthews_corrcoef(y_true, y_pred)
            if scorer_name == "roc_auc":
                return roc_auc_score(y_true, pos_proba) if binary and pos_proba is not None else np.nan
            if scorer_name == "roc_auc_ovr":
                return roc_auc_score(y_true, proba, multi_class="ovr", average="macro") if proba is not None else np.nan
            if scorer_name == "roc_auc_ovr_weighted":
                return roc_auc_score(y_true, proba, multi_class="ovr", average="weighted") if proba is not None else np.nan
            if scorer_name == "roc_auc_ovo":
                return roc_auc_score(y_true, proba, multi_class="ovo", average="macro") if proba is not None else np.nan
            if scorer_name == "roc_auc_ovo_weighted":
                return roc_auc_score(y_true, proba, multi_class="ovo", average="weighted") if proba is not None else np.nan
            if scorer_name == "average_precision":
                return average_precision_score(y_true, pos_proba) if binary and pos_proba is not None else np.nan
            if scorer_name == "neg_log_loss":
                return log_loss(y_true, proba, labels=labels) if proba is not None else np.nan
            if scorer_name == "neg_brier_score":
                return brier_score_loss(y_true, pos_proba, pos_label=pos_label) if binary and pos_proba is not None else np.nan
            if scorer_name == "custom_label_precision":
                return precision_score(y_true, y_pred, labels=[cfg["label"]], average=None, zero_division=0)[0]
            if scorer_name == "custom_label_recall":
                return recall_score(y_true, y_pred, labels=[cfg["label"]], average=None, zero_division=0)[0]
            if scorer_name == "custom_label_f1":
                return f1_score(y_true, y_pred, labels=[cfg["label"]], average=None, zero_division=0)[0]
            if scorer_name == "custom_label_jaccard":
                return jaccard_score(y_true, y_pred, labels=[cfg["label"]], average=None, zero_division=0)[0]
        except Exception:
            return np.nan
        return np.nan

    scorer_name = cfg["scorer_name"]
    y_true_arr = np.asarray(y_true, dtype=float)
    y_pred_arr = np.asarray(y_pred, dtype=float)

    try:
        if scorer_name == "explained_variance":
            return explained_variance_score(y_true_arr, y_pred_arr)
        if scorer_name == "r2":
            return r2_score(y_true_arr, y_pred_arr)
        if scorer_name == "neg_mean_absolute_error":
            return mean_absolute_error(y_true_arr, y_pred_arr)
        if scorer_name == "neg_mean_squared_error":
            return mean_squared_error(y_true_arr, y_pred_arr)
        if scorer_name == "neg_root_mean_squared_error":
            return np.sqrt(mean_squared_error(y_true_arr, y_pred_arr))
        if scorer_name == "neg_mean_squared_log_error":
            if np.any(y_true_arr < 0) or np.any(y_pred_arr < 0):
                return np.nan
            return mean_squared_log_error(y_true_arr, y_pred_arr)
        if scorer_name == "neg_median_absolute_error":
            return median_absolute_error(y_true_arr, y_pred_arr)
        if scorer_name == "neg_mean_absolute_percentage_error":
            return mean_absolute_percentage_error(y_true_arr, y_pred_arr)
        if scorer_name == "smape":
            return smape(y_true_arr, y_pred_arr)
        if scorer_name == "neg_max_error":
            return max_error(y_true_arr, y_pred_arr)
        if scorer_name == "neg_mean_poisson_deviance":
            if np.any(y_true_arr <= 0) or np.any(y_pred_arr <= 0):
                return np.nan
            return mean_poisson_deviance(y_true_arr, y_pred_arr)
        if scorer_name == "neg_mean_gamma_deviance":
            if np.any(y_true_arr <= 0) or np.any(y_pred_arr <= 0):
                return np.nan
            return mean_gamma_deviance(y_true_arr, y_pred_arr)
        if scorer_name == "d2_absolute_error_score":
            return d2_absolute_error_score(y_true_arr, y_pred_arr) if d2_absolute_error_score is not None else np.nan
        if scorer_name == "d2_pinball_score":
            return d2_pinball_score(y_true_arr, y_pred_arr) if d2_pinball_score is not None else np.nan
        if scorer_name == "d2_tweedie_score":
            return d2_tweedie_score(y_true_arr, y_pred_arr) if d2_tweedie_score is not None else np.nan
    except Exception:
        return np.nan
    return np.nan


def _all_metrics_from_predictions(task_type: str, y_true, y_pred, proba: np.ndarray | None = None, labels: list[Any] | None = None) -> dict[str, float]:
    catalog = build_metric_catalog(task_type, labels=labels)
    out = {}
    for metric_name, cfg in catalog.items():
        out[metric_name] = _compute_metric_from_predictions(
            metric_name,
            cfg,
            task_type,
            y_true,
            y_pred,
            proba=proba,
            labels=labels,
        )
    return out


def _prediction_frame_train_oof(fitted, pipeline, X_train, y_train, cv_splitter) -> pd.DataFrame:
    pred_df = pd.DataFrame(index=X_train.index)
    pred_df["y_true"] = pd.Series(y_train, index=X_train.index)

    try:
        pred_df["prediction"] = cross_val_predict(
            clone(pipeline),
            X_train,
            y_train,
            cv=cv_splitter,
            method="predict",
            n_jobs=1,
        )
    except Exception:
        pred_df["prediction"] = fitted.predict(X_train)

    if hasattr(fitted, "predict_proba"):
        try:
            proba = cross_val_predict(
                clone(pipeline),
                X_train,
                y_train,
                cv=cv_splitter,
                method="predict_proba",
                n_jobs=1,
            )
            if proba.ndim == 2:
                for j in range(proba.shape[1]):
                    pred_df[f"probability_{j}"] = proba[:, j]
        except Exception:
            pass

    return pred_df


def _prediction_frame_holdout(fitted, X_test, y_test=None) -> pd.DataFrame:
    pred_df = pd.DataFrame(index=X_test.index)
    if y_test is not None:
        pred_df["y_true"] = pd.Series(y_test, index=X_test.index)
    pred_df["prediction"] = fitted.predict(X_test)

    if hasattr(fitted, "predict_proba"):
        try:
            proba = fitted.predict_proba(X_test)
            if proba.ndim == 2:
                for j in range(proba.shape[1]):
                    pred_df[f"probability_{j}"] = proba[:, j]
        except Exception:
            pass

    return pred_df


def _extract_proba_from_prediction_df(pred_df: pd.DataFrame) -> np.ndarray | None:
    proba_cols = [c for c in pred_df.columns if c.startswith("probability_")]
    if not proba_cols:
        return None
    return pred_df[proba_cols].to_numpy()


def _combine_prediction_tables(pred_map: dict[str, pd.DataFrame], y_true=None) -> pd.DataFrame:
    combined = None

    for model_name, df in pred_map.items():
        if not isinstance(df, pd.DataFrame) or df.empty:
            continue

        block = df.copy().reset_index(drop=True)
        rename = {c: f"{model_name} | {c}" for c in block.columns if c != "y_true"}
        block = block.rename(columns=rename)

        if combined is None:
            combined = block
        else:
            if "y_true" in block.columns and "y_true" in combined.columns:
                block = block.drop(columns=["y_true"])
            combined = pd.concat([combined.reset_index(drop=True), block.reset_index(drop=True)], axis=1)

    if combined is None:
        combined = pd.DataFrame()

    if y_true is not None and "y_true" not in combined.columns:
        combined.insert(0, "y_true", pd.Series(y_true).reset_index(drop=True))

    return combined


def _confusion_details(y_true, y_pred, labels: list[Any]) -> dict[str, Any]:
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()

    work = pd.DataFrame({"y_true": y_true, "y_pred": y_pred}).dropna().copy()

    try:
        if pd.api.types.is_numeric_dtype(work["y_true"]):
            work["y_true"] = pd.to_numeric(work["y_true"], errors="coerce")
            work["y_pred"] = pd.to_numeric(work["y_pred"], errors="coerce")
            work = work.dropna().copy()
            if not work.empty:
                work["y_true"] = work["y_true"].astype(y_true.dtype)
                work["y_pred"] = work["y_pred"].astype(y_true.dtype)
        else:
            work["y_true"] = work["y_true"].astype(str)
            work["y_pred"] = work["y_pred"].astype(str)
            labels = [str(x) for x in labels]
    except Exception:
        work["y_true"] = work["y_true"].astype(str)
        work["y_pred"] = work["y_pred"].astype(str)
        labels = [str(x) for x in labels]

    cm_array = confusion_matrix(work["y_true"], work["y_pred"], labels=labels)
    cm = pd.DataFrame(
        np.asarray(cm_array, dtype=int),
        index=[f"actual_{x}" for x in labels],
        columns=[f"pred_{x}" for x in labels],
    )

    row_sums = cm.sum(axis=1).replace(0, 1)
    cm_pct = cm.div(row_sums, axis=0)

    out = {
        "labels": labels,
        "matrix": cm.to_numpy().tolist(),
        "matrix_df": cm,
        "matrix_pct": cm_pct.to_numpy().tolist(),
        "matrix_pct_df": cm_pct,
    }

    if len(labels) == 2:
        tn, fp, fn, tp = cm.to_numpy().ravel()
        total = max(int(cm.to_numpy().sum()), 1)
        out["binary_summary"] = {
            "TN": int(tn),
            "FP": int(fp),
            "FN": int(fn),
            "TP": int(tp),
            "TN_pct": float(tn / total),
            "FP_pct": float(fp / total),
            "FN_pct": float(fn / total),
            "TP_pct": float(tp / total),
        }

    return out


def _clean_param_value(value):
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple, set, np.ndarray, dict)):
        return str(value)
    return repr(value)


def _extract_model_params_for_table(fitted_pipeline):
    try:
        model = fitted_pipeline.named_steps.get("model")
    except Exception:
        model = None
    if model is None:
        return {}
    try:
        params = model.get_params(deep=False)
    except Exception:
        return {}
    return {k: _clean_param_value(v) for k, v in params.items()}


def _bootstrap_all_metrics(
    pipeline,
    X_train,
    y_train,
    task_type: str,
    metric_names: list[str],
    n_rounds: int,
    random_state: int,
    labels: list[Any] | None = None,
):
    rng = np.random.default_rng(random_state)
    X_train = X_train.reset_index(drop=True)
    y_train = pd.Series(y_train).reset_index(drop=True)
    n = len(X_train)

    if n == 0:
        summary = {m: {"mean": np.nan, "std": np.nan} for m in metric_names}
        return summary, pd.DataFrame()

    round_rows = []
    metric_store = {m: [] for m in metric_names}

    for round_idx in range(n_rounds):
        sample_idx = rng.integers(0, n, size=n)
        oob_mask = np.ones(n, dtype=bool)
        oob_mask[np.unique(sample_idx)] = False

        if oob_mask.sum() == 0:
            continue

        X_boot = X_train.iloc[sample_idx].copy()
        y_boot = y_train.iloc[sample_idx].copy()
        X_oob = X_train.iloc[oob_mask].copy()
        y_oob = y_train.iloc[oob_mask].copy()

        model = clone(pipeline)
        try:
            model.fit(X_boot, y_boot)
            y_oob_pred = model.predict(X_oob)
            proba = model.predict_proba(X_oob) if hasattr(model, "predict_proba") else None

            metric_map = _all_metrics_from_predictions(
                task_type=task_type,
                y_true=y_oob,
                y_pred=y_oob_pred,
                proba=proba,
                labels=labels,
            )

            row = {"bootstrap_round": int(round_idx + 1), "oob_size": int(len(X_oob))}
            for metric_name in metric_names:
                value = metric_map.get(metric_name, np.nan)
                row[metric_name] = value
                if not pd.isna(value):
                    metric_store[metric_name].append(value)
            round_rows.append(row)
        except Exception:
            continue

    summary = {
        metric_name: {
            "mean": float(np.nanmean(values)) if values else np.nan,
            "std": float(np.nanstd(values)) if values else np.nan,
        }
        for metric_name, values in metric_store.items()
    }
    return summary, pd.DataFrame(round_rows)


# =============================================================================
# Main class
# =============================================================================
class ModelingOnly:
    def __init__(self, config: ModelRunConfig):
        self.config = deepcopy(config)
        self.task_type_: str | None = None
        self.primary_metric_: str | None = None
        self.labels_: list[Any] | None = None
        self.feature_names_: list[str] | None = None

        self.trained_models_: dict[str, TrainedModelBundle] = {}
        self.model_selection_summary_df_: pd.DataFrame = pd.DataFrame()
        self.summary_df_: pd.DataFrame = pd.DataFrame()
        self.cv_hyperparameter_tables_: dict[str, pd.DataFrame] = {}
        self.bootstrap_tables_: dict[str, pd.DataFrame] = {}
        self.predictions_train_: dict[str, pd.DataFrame] = {}
        self.predictions_test_: dict[str, pd.DataFrame] = {}
        self.predictions_train_wide_: pd.DataFrame = pd.DataFrame()
        self.predictions_test_wide_: pd.DataFrame = pd.DataFrame()
        self.confusion_matrices_: dict[str, Any] = {}

    @staticmethod
    def classification_algorithm_docs() -> dict[str, str]:
        return classification_algorithm_docs()

    @staticmethod
    def regression_algorithm_docs() -> dict[str, str]:
        return regression_algorithm_docs()

    def _validate_inputs(self, X_train, y_train, X_test=None, y_test=None):
        if not isinstance(X_train, pd.DataFrame):
            raise TypeError("X_train must be a pandas DataFrame.")
        if X_test is not None and not isinstance(X_test, pd.DataFrame):
            raise TypeError("X_test must be a pandas DataFrame.")
        if not self.config.algorithms and not self.config.stacking.enabled:
            raise ValueError("config.algorithms cannot be empty.")
        if len(X_train) != len(y_train):
            raise ValueError("X_train and y_train must have the same number of rows.")
        if X_test is not None and y_test is not None and len(X_test) != len(y_test):
            raise ValueError("X_test and y_test must have the same number of rows.")
        if X_test is not None and list(X_train.columns) != list(X_test.columns):
            raise ValueError("X_test must have the same columns and the same order as X_train.")

    def _run_optuna_if_needed(self, pipeline, model_name, X_train, y_train, cv_splitter):
        if not self.config.tuning.enabled or optuna is None or model_name == "Stacking":
            return pipeline, pd.DataFrame()

        grid = param_grids(
            self.task_type_,
            model_name,
            X_train=X_train,
            y_train=y_train,
        ).get(self.config.tuning.profile, {})

        if not grid:
            return pipeline, pd.DataFrame()

        scorer = get_metric_scorer(self.primary_metric_, self.task_type_, labels=self.labels_)
        trial_rows = []

        def objective(trial):
            params = {
                param_name: trial.suggest_categorical(param_name, values)
                for param_name, values in grid.items()
            }
            candidate = clone(pipeline)
            candidate.set_params(**params)

            cv_res = cross_validate(
                candidate,
                X_train,
                y_train,
                cv=cv_splitter,
                scoring=scorer,
                n_jobs=1,
                error_score=np.nan,
            )

            vals = cv_res.get("test_score", np.array([np.nan]))
            display_vals = [
                display_metric_value(v, self.primary_metric_, self.task_type_, labels=self.labels_)
                for v in vals
            ]

            row = {
                "trial": int(trial.number + 1),
                "model": model_name,
                "metric": self.primary_metric_,
                "validation_mean": float(np.nanmean(display_vals)) if len(display_vals) else np.nan,
                "validation_std": float(np.nanstd(display_vals)) if len(display_vals) else np.nan,
            }
            for i, v in enumerate(display_vals, start=1):
                row[f"validation_fold_{i}"] = v
            for k, v in params.items():
                row[k] = _clean_param_value(v)
            trial_rows.append(row)

            return float(np.nanmean(vals))

        n_trials = self.config.tuning.n_trials_override or profile_to_trial_count(
            self.config.tuning.profile,
            X_train=X_train,
            model_name=model_name,
        )

        study = optuna.create_study(direction="maximize")
        study.optimize(objective, n_trials=n_trials, show_progress_bar=False)

        tuned_pipeline = clone(pipeline)
        tuned_pipeline.set_params(**study.best_params)
        return tuned_pipeline, pd.DataFrame(trial_rows)

    def fit(self, X_train: pd.DataFrame, y_train, X_test: pd.DataFrame | None = None, y_test=None):
        y_train = _coerce_target(y_train)
        y_test = _coerce_target(y_test) if y_test is not None else None

        self._validate_inputs(X_train, y_train, X_test, y_test)

        self.task_type_ = _infer_task_type(y_train) if self.config.task_type == "auto" else self.config.task_type
        self.primary_metric_ = self.config.primary_metric or _default_primary_metric(self.task_type_)
        self.labels_ = sorted(y_train.dropna().unique().tolist()) if self.task_type_ == "Classification" else None
        self.feature_names_ = X_train.columns.tolist()

        cv_splitter = build_cv_splitter(self.config, y_train, self.task_type_)
        metric_names = _get_metric_names(self.task_type_, self.labels_)

        models_to_run = list(self.config.algorithms)
        if self.config.stacking.enabled:
            models_to_run.append("Stacking")

        trained_models = {}
        model_selection_rows = []
        summary_rows = []
        cv_hyper_tables = {}
        bootstrap_tables = {}
        predictions_train = {}
        predictions_test = {}
        confusion_tables = {}

        for model_name in models_to_run:
            pipeline = (
                _build_stacking_pipeline(self.task_type_, self.config)
                if model_name == "Stacking"
                else _build_single_model_pipeline(self.task_type_, model_name, self.config)
            )

            pipeline, tuning_table = self._run_optuna_if_needed(
                pipeline=pipeline,
                model_name=model_name,
                X_train=X_train,
                y_train=y_train,
                cv_splitter=cv_splitter,
            )

            pred_train, validation_summary, validation_fold_table = _cv_predictions_and_metric_summary(
                pipeline=pipeline,
                X_train=X_train,
                y_train=y_train,
                cv_splitter=cv_splitter,
                task_type=self.task_type_,
                metric_names=metric_names,
                labels=self.labels_,
            )

            cv_vals_display = validation_fold_table[self.primary_metric_].tolist() if self.primary_metric_ in validation_fold_table.columns else []
            cv_mean = validation_summary[self.primary_metric_]["mean"]
            cv_std = validation_summary[self.primary_metric_]["std"]

            if tuning_table.empty:
                row = {
                    "trial": 1,
                    "model": model_name,
                    "metric": self.primary_metric_,
                    "validation_mean": cv_mean,
                    "validation_std": cv_std,
                }
                for i, v in enumerate(cv_vals_display, start=1):
                    row[f"validation_fold_{i}"] = v
                row.update(_extract_model_params_for_table(pipeline))
                tuning_table = pd.DataFrame([row])

            fitted = clone(pipeline).fit(X_train, y_train)

            if self.config.bootstrap.enabled:
                bootstrap_summary, bootstrap_table = _bootstrap_all_metrics(
                    pipeline=fitted,
                    X_train=X_train,
                    y_train=y_train,
                    task_type=self.task_type_,
                    metric_names=metric_names,
                    n_rounds=self.config.bootstrap.n_rounds,
                    random_state=self.config.bootstrap.random_state,
                    labels=self.labels_,
                )
            else:
                bootstrap_summary = {m: {"mean": np.nan, "std": np.nan} for m in metric_names}
                bootstrap_table = pd.DataFrame()

            predictions_train[model_name] = pred_train
            train_proba = _extract_proba_from_prediction_df(pred_train)

            train_metric_map = _all_metrics_from_predictions(
                task_type=self.task_type_,
                y_true=pred_train["y_true"],
                y_pred=pred_train["prediction"],
                proba=train_proba,
                labels=self.labels_,
            )

            pred_test = pd.DataFrame()
            test_metric_map = {m: np.nan for m in metric_names}

            if X_test is not None:
                pred_test = _prediction_frame_holdout(fitted, X_test, y_test)
                predictions_test[model_name] = pred_test

                if y_test is not None:
                    test_proba = _extract_proba_from_prediction_df(pred_test)
                    test_metric_map = _all_metrics_from_predictions(
                        task_type=self.task_type_,
                        y_true=pred_test["y_true"],
                        y_pred=pred_test["prediction"],
                        proba=test_proba,
                        labels=self.labels_,
                    )

            if self.task_type_ == "Classification":
                train_conf = _confusion_details(pred_train["y_true"], pred_train["prediction"], labels=self.labels_)
                test_conf = None
                if X_test is not None and y_test is not None:
                    test_conf = _confusion_details(pred_test["y_true"], pred_test["prediction"], labels=self.labels_)
                confusion_tables[model_name] = {"train": train_conf, "test": test_conf}

            model_selection_row = {
                "model": model_name,
                "primary_metric": self.primary_metric_,
                "validation_mean": cv_mean,
                "validation_std": cv_std,
                "bootstrap_mean": bootstrap_summary[self.primary_metric_]["mean"],
                "bootstrap_std": bootstrap_summary[self.primary_metric_]["std"],
                "train_oof": train_metric_map.get(self.primary_metric_, np.nan),
                "test": test_metric_map.get(self.primary_metric_, np.nan),
            }
            model_selection_rows.append(model_selection_row)

            full_metric_rows = []
            for metric_name in metric_names:
                row = {
                    "model": model_name,
                    "metric": metric_name,
                    "validation_mean": validation_summary[metric_name]["mean"],
                    "validation_std": validation_summary[metric_name]["std"],
                    "bootstrap_mean": bootstrap_summary[metric_name]["mean"],
                    "bootstrap_std": bootstrap_summary[metric_name]["std"],
                    "train_oof": train_metric_map.get(metric_name, np.nan),
                    "test": test_metric_map.get(metric_name, np.nan),
                }
                full_metric_rows.append(row)
                summary_rows.append(row)

            full_metric_table = pd.DataFrame(full_metric_rows)

            trained_models[model_name] = TrainedModelBundle(
                model_name=model_name,
                fitted_pipeline=fitted,
                config=deepcopy(self.config),
                task_type=self.task_type_,
                feature_names=self.feature_names_,
                target_name=getattr(y_train, "name", None),
                cv_metric_name=self.primary_metric_,
                cv_score_mean=cv_mean,
                cv_score_std=cv_std,
                model_selection_row=model_selection_row,
                full_metric_table=full_metric_table,
            )

            cv_hyper_tables[model_name] = tuning_table
            bootstrap_tables[model_name] = bootstrap_table

        self.trained_models_ = trained_models
        self.model_selection_summary_df_ = pd.DataFrame(model_selection_rows)
        self.summary_df_ = pd.DataFrame(summary_rows)
        self.cv_hyperparameter_tables_ = cv_hyper_tables
        self.bootstrap_tables_ = bootstrap_tables
        self.predictions_train_ = predictions_train
        self.predictions_test_ = predictions_test
        self.predictions_train_wide_ = _combine_prediction_tables(predictions_train, y_true=y_train)
        self.predictions_test_wide_ = _combine_prediction_tables(predictions_test, y_true=y_test) if X_test is not None else pd.DataFrame()
        self.confusion_matrices_ = confusion_tables

        return self

    def get_artifacts(self) -> dict[str, Any]:
        return {
            "trained_models": self.trained_models_,
            "model_selection_summary_df": self.model_selection_summary_df_,
            "summary_df": self.summary_df_,
            "cv_hyperparameter_tables": self.cv_hyperparameter_tables_,
            "bootstrap_tables": self.bootstrap_tables_,
            "predictions_train": self.predictions_train_,
            "predictions_test": self.predictions_test_,
            "predictions_train_wide": self.predictions_train_wide_,
            "predictions_test_wide": self.predictions_test_wide_,
            "confusion_matrices": self.confusion_matrices_,
        }

    def save_selected_models(self) -> list[str]:
        if not self.config.saving.enabled:
            return []
        if not self.trained_models_:
            raise ValueError("No trained models available. Run fit() first.")

        selected = self.config.saving.models_to_save or list(self.trained_models_.keys())
        saved_paths = []

        default_dir = Path(self.config.saving.save_directory)
        default_dir.mkdir(parents=True, exist_ok=True)

        for model_name in selected:
            if model_name not in self.trained_models_:
                continue

            custom_path = self.config.saving.custom_model_paths.get(model_name)
            if custom_path:
                save_path = Path(custom_path)
                save_path.parent.mkdir(parents=True, exist_ok=True)
            else:
                safe_name = model_name.lower().replace(" ", "_")
                save_path = default_dir / f"{safe_name}_bundle.joblib"

            joblib.dump(self.trained_models_[model_name], save_path)
            saved_paths.append(str(save_path))

        return saved_paths

    def save_model(self, model_name: str, full_path: str) -> str:
        if model_name not in self.trained_models_:
            raise ValueError(f"Model '{model_name}' not found.")
        save_path = Path(full_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self.trained_models_[model_name], save_path)
        return str(save_path)


# _SML_MODELING_LOGGING_PATCH
from scientific_ml_modules.utils.logging_utils import instrument_method, instrument_function
import scientific_ml_modules.core.modeling as _sml_modeling_module
for _name in ["fit", "get_artifacts", "save_selected_models", "save_model", "_run_optuna_if_needed", "_validate_inputs"]:
    instrument_method(ModelingOnly, _name, label=f"MODELING:{_name}")
for _fname in ["_cv_predictions_and_metric_summary", "_bootstrap_all_metrics", "build_cv_splitter", "build_estimator", "param_grids"]:
    instrument_function(_sml_modeling_module, _fname, logger_name="scientific_ml_modules.modeling", label=f"MODELING:{_fname}")
