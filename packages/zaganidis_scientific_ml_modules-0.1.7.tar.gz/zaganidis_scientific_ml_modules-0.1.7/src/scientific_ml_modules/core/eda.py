from __future__ import annotations

from typing import Callable, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from matplotlib.figure import Figure
from matplotlib.gridspec import GridSpec
from matplotlib.colors import LinearSegmentedColormap
from scipy import stats as sp_stats


class ExplanatoryAnalyzer:
    """
    Reusable explanatory / exploratory analysis class.

    Mandatory input
    ---------------
    df : pd.DataFrame

    Main outputs stored separately
    ------------------------------
    numeric_description : pd.DataFrame
    categorical_description : pd.DataFrame
    datetime_description : pd.DataFrame
    missing_summary : pd.DataFrame

    Optional grouped outputs
    ------------------------
    numeric_description_grouped : pd.DataFrame
    categorical_description_grouped : pd.DataFrame
    datetime_description_grouped : pd.DataFrame
    missing_summary_grouped : pd.DataFrame
    """

    COLOR_BLACK = "#111111"
    COLOR_BLUE = "#1F4E79"
    COLOR_GREY = "#6E7B8B"
    COLOR_RED = "#B22222"
    COLOR_LIGHT_GREY = "#D9DEE5"
    COLOR_GRID = "#D0D7DE"

    def __init__(
        self,
        df: pd.DataFrame,
        infer_datetime_strings: bool = False,
        datetime_inference_threshold: float = 0.8,
    ):
        if not isinstance(df, pd.DataFrame):
            raise TypeError("df must be a pandas DataFrame.")
        if not isinstance(infer_datetime_strings, bool):
            raise TypeError("infer_datetime_strings must be a bool.")
        if not isinstance(datetime_inference_threshold, (int, float)):
            raise TypeError("datetime_inference_threshold must be numeric.")

        datetime_inference_threshold = float(datetime_inference_threshold)
        if not (0 <= datetime_inference_threshold <= 1):
            raise ValueError("datetime_inference_threshold must be between 0 and 1.")

        self.df = df.copy()
        self.infer_datetime_strings = infer_datetime_strings
        self.datetime_inference_threshold = datetime_inference_threshold

        self.numeric_cols: list[str] = []
        self.categorical_cols: list[str] = []
        self.datetime_cols: list[str] = []

        self.numeric_description: pd.DataFrame = pd.DataFrame()
        self.categorical_description: pd.DataFrame = pd.DataFrame()
        self.datetime_description: pd.DataFrame = pd.DataFrame()
        self.missing_summary: pd.DataFrame = pd.DataFrame()

        self.numeric_description_grouped: pd.DataFrame = pd.DataFrame()
        self.categorical_description_grouped: pd.DataFrame = pd.DataFrame()
        self.datetime_description_grouped: pd.DataFrame = pd.DataFrame()
        self.missing_summary_grouped: pd.DataFrame = pd.DataFrame()

        if self.infer_datetime_strings:
            self._infer_and_convert_datetime_columns()

        self.refresh()

    @classmethod
    def builder(cls):
        from scientific_ml_modules.config.eda_builder import ExplanatoryAnalyzerBuilder

        return ExplanatoryAnalyzerBuilder()

    def refresh(self, groupby_cols: Optional[list[str]] = None) -> "ExplanatoryAnalyzer":
        self._refresh_column_buckets()

        self.missing_summary = self._build_missing_summary(self.df)
        self.numeric_description = self._describe_numeric(self.df)
        self.categorical_description = self._describe_categorical(self.df)
        self.datetime_description = self._describe_datetime(self.df)

        if groupby_cols:
            self._validate_groupby_cols(groupby_cols)

            self.missing_summary_grouped = self._grouped_description(
                builder=self._build_missing_summary,
                groupby_cols=groupby_cols,
            )
            self.numeric_description_grouped = self._grouped_description(
                builder=self._describe_numeric,
                groupby_cols=groupby_cols,
            )
            self.categorical_description_grouped = self._grouped_description(
                builder=self._describe_categorical,
                groupby_cols=groupby_cols,
            )
            self.datetime_description_grouped = self._grouped_description(
                builder=self._describe_datetime,
                groupby_cols=groupby_cols,
            )
        else:
            self.missing_summary_grouped = pd.DataFrame()
            self.numeric_description_grouped = pd.DataFrame()
            self.categorical_description_grouped = pd.DataFrame()
            self.datetime_description_grouped = pd.DataFrame()

        return self

    def get_numeric_columns(self) -> list[str]:
        return self.numeric_cols.copy()

    def get_categorical_columns(self) -> list[str]:
        return self.categorical_cols.copy()

    def get_datetime_columns(self) -> list[str]:
        return self.datetime_cols.copy()

    def plot_single_column_distribution(
        self,
        column: str,
        bins: Optional[int] = None,
        top_n_categories: int = 20,
        kde: bool = True,
    ) -> tuple[Optional[Figure], pd.DataFrame, pd.DataFrame, str]:
        if column not in self.df.columns:
            raise KeyError(f"Column '{column}' not found in DataFrame.")

        series = self.df[column]
        total_rows = len(series)
        missing_count = int(series.isna().sum())
        missing_pct = float(series.isna().mean() * 100) if total_rows > 0 else np.nan

        if column in self.numeric_cols:
            values = pd.to_numeric(series, errors="coerce").dropna()

            if values.empty:
                stats_df = pd.DataFrame(
                    {
                        "metric": ["column", "dtype", "count", "missing_count", "missing_pct"],
                        "value": [column, str(series.dtype), 0, missing_count, round(missing_pct, 4)],
                    }
                )
                return None, stats_df, pd.DataFrame(), "No non-missing numeric values available."

            if bins is None:
                bins = min(30, max(10, int(np.sqrt(len(values)))))

            mean_val = self._safe_float(values.mean())
            median_val = self._safe_float(values.median())
            std_val = self._safe_float(values.std())
            min_val = self._safe_float(values.min())
            max_val = self._safe_float(values.max())
            q1_val = self._safe_float(values.quantile(0.25))
            q3_val = self._safe_float(values.quantile(0.75))
            iqr_val = self._safe_float(q3_val - q1_val)
            skew_val = self._safe_float(values.skew())
            kurt_val = self._safe_float(values.kurt())

            peak_count = self._count_histogram_peaks(values.to_numpy(), bins=bins)
            shape_guess = self._guess_distribution(skew_val, kurt_val, peak_count)

            fig, ax = plt.subplots(figsize=(9.5, 4.8))
            sns.histplot(
                values,
                bins=bins,
                kde=False,
                ax=ax,
                color=self.COLOR_LIGHT_GREY,
                edgecolor=self.COLOR_BLACK,
                linewidth=0.8,
            )
            if kde and len(values) > 1:
                sns.kdeplot(values, ax=ax, color=self.COLOR_BLUE, linewidth=2.0)

            ax.axvline(
                mean_val,
                linestyle="--",
                linewidth=2.0,
                color=self.COLOR_RED,
                label=f"Mean = {self._format_num(mean_val, 2)}",
            )
            ax.axvline(
                median_val,
                linestyle="-.",
                linewidth=2.0,
                color=self.COLOR_BLACK,
                label=f"Median = {self._format_num(median_val, 2)}",
            )

            ax.set_title(f"Distribution of {column}", fontsize=13, color=self.COLOR_BLACK, pad=10)
            ax.set_xlabel(column, color=self.COLOR_BLACK)
            ax.set_ylabel("Frequency", color=self.COLOR_BLACK)
            ax.legend(frameon=False)
            self._apply_scientific_axis_style(ax, grid_axis="y")
            fig.tight_layout()

            stats_df = pd.DataFrame(
                {
                    "metric": [
                        "count",
                        "missing_%",
                        "mean",
                        "median",
                        "std",
                        "min",
                        "25%",
                        "75%",
                        "IQR",
                        "max",
                        "skewness",
                        "kurtosis",
                        "estimated_peaks",
                    ],
                    "value": [
                        len(values),
                        round(missing_pct, 4),
                        mean_val,
                        median_val,
                        std_val,
                        min_val,
                        q1_val,
                        q3_val,
                        iqr_val,
                        max_val,
                        skew_val,
                        kurt_val,
                        peak_count,
                    ],
                }
            )

            interpretation_parts = []
            if pd.notna(skew_val):
                if skew_val > 1:
                    interpretation_parts.append("strong right skew")
                elif skew_val > 0.35:
                    interpretation_parts.append("moderate right skew")
                elif skew_val < -1:
                    interpretation_parts.append("strong left skew")
                elif skew_val < -0.35:
                    interpretation_parts.append("moderate left skew")
                else:
                    interpretation_parts.append("roughly symmetric")

            if pd.notna(kurt_val):
                if kurt_val > 2:
                    interpretation_parts.append("heavy tails / more extreme values")
                elif kurt_val < -1:
                    interpretation_parts.append("flatter than normal")
                else:
                    interpretation_parts.append("tail behavior not far from normal")

            if peak_count >= 2:
                interpretation_parts.append("possible multiple modes")

            interpretation = (
                f"Closest shape: {shape_guess}. "
                f"Interpretation: {', '.join(interpretation_parts)}. "
                f"Mean vs median: "
                f"{'mean > median' if mean_val > median_val else 'mean < median' if mean_val < median_val else 'mean ≈ median'}."
            )

            return fig, stats_df, pd.DataFrame(), interpretation

        if column in self.datetime_cols:
            values = pd.to_datetime(series, errors="coerce").dropna()

            if values.empty:
                stats_df = pd.DataFrame(
                    {
                        "metric": ["count", "missing_%", "min_date", "max_date", "range_days"],
                        "value": [0, round(missing_pct, 4), None, None, np.nan],
                    }
                )
                return None, stats_df, pd.DataFrame(), "No non-missing datetime values available."

            fig, ax = plt.subplots(figsize=(10, 4.8))
            sns.histplot(
                values,
                kde=False,
                ax=ax,
                color=self.COLOR_LIGHT_GREY,
                edgecolor=self.COLOR_BLUE,
                linewidth=0.8,
            )
            ax.set_title(f"Temporal Distribution of {column}", fontsize=13, color=self.COLOR_BLACK, pad=10)
            ax.set_xlabel(column, color=self.COLOR_BLACK)
            ax.set_ylabel("Frequency", color=self.COLOR_BLACK)
            self._apply_scientific_axis_style(ax, grid_axis="y", rotate_xticks=30)
            fig.tight_layout()

            min_date = values.min()
            max_date = values.max()
            span_days = (max_date - min_date).days if pd.notna(min_date) and pd.notna(max_date) else np.nan

            stats_df = pd.DataFrame(
                {
                    "metric": ["count", "missing_%", "min_date", "max_date", "range_days", "unique_dates"],
                    "value": [len(values), round(missing_pct, 4), str(min_date), str(max_date), span_days, int(values.nunique())],
                }
            )

            interpretation = f"Date range from {min_date} to {max_date} ({span_days} days)."
            return fig, stats_df, pd.DataFrame(), interpretation

        cat_series = series.astype("string").fillna("Missing")
        counts = cat_series.value_counts(dropna=False)
        top_counts = counts.head(top_n_categories).rename_axis("category").reset_index(name="count")

        mode_value = counts.index[0] if len(counts) > 0 else "N/A"
        mode_count = int(counts.iloc[0]) if len(counts) > 0 else 0
        mode_share = (mode_count / len(cat_series) * 100) if len(cat_series) > 0 else np.nan

        fig, ax = plt.subplots(figsize=(9.5, max(4.5, 0.35 * len(top_counts))))
        ax.barh(
            top_counts["category"],
            top_counts["count"],
            color=self.COLOR_BLUE,
            edgecolor=self.COLOR_BLACK,
            linewidth=0.8,
        )
        ax.set_title(f"Category Frequencies: {column}", fontsize=13, color=self.COLOR_BLACK, pad=10)
        ax.set_xlabel("Count", color=self.COLOR_BLACK)
        ax.set_ylabel(column, color=self.COLOR_BLACK)
        ax.invert_yaxis()
        self._apply_scientific_axis_style(ax, grid_axis="x")
        fig.tight_layout()

        stats_df = pd.DataFrame(
            {
                "metric": ["count", "missing_%", "unique_values", "top_category", "top_category_count", "top_category_%"],
                "value": [
                    len(cat_series),
                    round(missing_pct, 4),
                    int(cat_series.nunique(dropna=False)),
                    str(mode_value),
                    mode_count,
                    round(mode_share, 4) if pd.notna(mode_share) else np.nan,
                ],
            }
        )

        interpretation = (
            f"Most frequent category: {mode_value} "
            f"({mode_count} rows, {round(mode_share, 2) if pd.notna(mode_share) else np.nan}%). "
            f"Showing top {min(top_n_categories, len(top_counts))} categories."
        )

        return fig, stats_df, top_counts, interpretation

    def plot_missing_columns(
        self,
        sort_by: str = "missing_pct",
        top_n: Optional[int] = None,
    ) -> tuple[pd.DataFrame, Optional[Figure], Optional[Figure]]:
        if self.missing_summary.empty:
            self.missing_summary = self._build_missing_summary(self.df)

        missing_df = self.missing_summary.copy()
        missing_df = missing_df[missing_df["missing_pct"] > 0].copy()

        if missing_df.empty:
            return pd.DataFrame(), None, None

        valid_sort_cols = ["missing_count", "missing_pct", "column"]
        if sort_by not in valid_sort_cols:
            raise ValueError(f"sort_by must be one of {valid_sort_cols}")

        ascending = sort_by == "column"
        missing_df = missing_df.sort_values(sort_by, ascending=ascending).reset_index(drop=True)

        if top_n is not None:
            missing_df = missing_df.head(top_n).copy()

        fig_count, ax1 = plt.subplots(figsize=(10, max(4.5, 0.35 * len(missing_df))))
        ax1.barh(
            missing_df["column"],
            missing_df["missing_count"],
            color=self.COLOR_RED,
            edgecolor=self.COLOR_BLACK,
            linewidth=0.8,
        )
        ax1.set_title("Missing Values by Column (Absolute Count)", fontsize=13, color=self.COLOR_BLACK, pad=10)
        ax1.set_xlabel("Missing Count", color=self.COLOR_BLACK)
        ax1.set_ylabel("Column", color=self.COLOR_BLACK)
        ax1.invert_yaxis()
        self._apply_scientific_axis_style(ax1, grid_axis="x")
        fig_count.tight_layout()

        fig_pct, ax2 = plt.subplots(figsize=(10, max(4.5, 0.35 * len(missing_df))))
        ax2.barh(
            missing_df["column"],
            missing_df["missing_pct"],
            color=self.COLOR_BLUE,
            edgecolor=self.COLOR_BLACK,
            linewidth=0.8,
        )
        ax2.set_title("Missing Values by Column (Percentage)", fontsize=13, color=self.COLOR_BLACK, pad=10)
        ax2.set_xlabel("Missing Percentage (%)", color=self.COLOR_BLACK)
        ax2.set_ylabel("Column", color=self.COLOR_BLACK)
        ax2.invert_yaxis()
        self._apply_scientific_axis_style(ax2, grid_axis="x")
        fig_pct.tight_layout()

        return missing_df, fig_count, fig_pct

    def plot_scatter_with_marginals(
        self,
        x_col: str,
        y_col: str,
        sample_size: Optional[int] = None,
        bins: int = 30,
        alpha: float = 0.65,
        add_regression_line: bool = True,
    ) -> tuple[pd.DataFrame, pd.DataFrame, Optional[Figure]]:
        if x_col not in self.df.columns:
            raise KeyError(f"Column '{x_col}' not found.")
        if y_col not in self.df.columns:
            raise KeyError(f"Column '{y_col}' not found.")

        if x_col not in self.numeric_cols:
            raise ValueError(f"Column '{x_col}' is not numeric.")
        if y_col not in self.numeric_cols:
            raise ValueError(f"Column '{y_col}' is not numeric.")

        plot_df = self.df[[x_col, y_col]].copy()
        plot_df[x_col] = pd.to_numeric(plot_df[x_col], errors="coerce")
        plot_df[y_col] = pd.to_numeric(plot_df[y_col], errors="coerce")

        x_missing = int(plot_df[x_col].isna().sum())
        y_missing = int(plot_df[y_col].isna().sum())

        plot_df = plot_df.dropna().copy()

        if plot_df.empty:
            stats_df = pd.DataFrame(
                {
                    "metric": ["x_col", "y_col", "usable_rows", "x_missing_count", "y_missing_count", "correlation"],
                    "value": [x_col, y_col, 0, x_missing, y_missing, np.nan],
                }
            )
            return pd.DataFrame(), stats_df, None

        if sample_size is not None and len(plot_df) > sample_size:
            plot_df = plot_df.sample(sample_size, random_state=42)

        corr_val = plot_df[x_col].corr(plot_df[y_col])

        stats_df = pd.DataFrame(
            {
                "metric": [
                    "x_col",
                    "y_col",
                    "usable_rows",
                    "x_missing_count",
                    "y_missing_count",
                    "correlation",
                    "x_mean",
                    "y_mean",
                    "x_std",
                    "y_std",
                ],
                "value": [
                    x_col,
                    y_col,
                    int(len(plot_df)),
                    x_missing,
                    y_missing,
                    float(corr_val) if pd.notna(corr_val) else np.nan,
                    float(plot_df[x_col].mean()),
                    float(plot_df[y_col].mean()),
                    float(plot_df[x_col].std()),
                    float(plot_df[y_col].std()),
                ],
            }
        )

        fig = plt.figure(figsize=(10.5, 10))
        gs = GridSpec(4, 4, figure=fig, hspace=0.06, wspace=0.06)

        ax_top = fig.add_subplot(gs[0, 0:3])
        ax_scatter = fig.add_subplot(gs[1:4, 0:3])
        ax_right = fig.add_subplot(gs[1:4, 3])

        ax_scatter.scatter(
            plot_df[x_col],
            plot_df[y_col],
            alpha=alpha,
            color=self.COLOR_BLUE,
            edgecolor=self.COLOR_BLACK,
            linewidth=0.3,
        )

        if add_regression_line and len(plot_df) >= 2:
            x_vals = plot_df[x_col].to_numpy()
            y_vals = plot_df[y_col].to_numpy()
            coeffs = np.polyfit(x_vals, y_vals, deg=1)
            x_line = np.linspace(x_vals.min(), x_vals.max(), 200)
            y_line = coeffs[0] * x_line + coeffs[1]
            ax_scatter.plot(x_line, y_line, color=self.COLOR_RED, linestyle="--", linewidth=2.0)

        title = f"Scatter Plot: {x_col} vs {y_col}"
        if pd.notna(corr_val):
            title += f"\nPearson correlation = {corr_val:.4f}"
        ax_scatter.set_title(title, fontsize=13, color=self.COLOR_BLACK, pad=10)
        ax_scatter.set_xlabel(x_col, color=self.COLOR_BLACK)
        ax_scatter.set_ylabel(y_col, color=self.COLOR_BLACK)
        self._apply_scientific_axis_style(ax_scatter, grid_axis="both")

        sns.histplot(
            plot_df[x_col],
            bins=bins,
            kde=False,
            ax=ax_top,
            color=self.COLOR_LIGHT_GREY,
            edgecolor=self.COLOR_BLACK,
            linewidth=0.6,
        )
        if len(plot_df) > 1:
            sns.kdeplot(plot_df[x_col], ax=ax_top, color=self.COLOR_BLUE, linewidth=1.8)
        ax_top.set_xlabel("")
        ax_top.set_ylabel("Count", color=self.COLOR_BLACK)
        self._apply_scientific_axis_style(ax_top, grid_axis="y")
        ax_top.tick_params(axis="x", labelbottom=False)

        sns.histplot(
            y=plot_df[y_col],
            bins=bins,
            kde=False,
            ax=ax_right,
            color=self.COLOR_LIGHT_GREY,
            edgecolor=self.COLOR_BLACK,
            linewidth=0.6,
        )
        if len(plot_df) > 1:
            sns.kdeplot(y=plot_df[y_col], ax=ax_right, color=self.COLOR_BLUE, linewidth=1.8)
        ax_right.set_xlabel("Count", color=self.COLOR_BLACK)
        ax_right.set_ylabel("")
        self._apply_scientific_axis_style(ax_right, grid_axis="x")
        ax_right.tick_params(axis="y", labelleft=False)

        fig.tight_layout()
        return plot_df, stats_df, fig

    def compute_target_correlations(
        self,
        target_col: str,
        task_type: str,
        top_n: Optional[int] = None,
    ) -> tuple[pd.DataFrame, Optional[Figure]]:
        if target_col not in self.df.columns:
            return pd.DataFrame(), None

        task_type_norm = str(task_type).strip().lower()
        numeric_cols = [c for c in self.numeric_cols if c != target_col]

        if not numeric_cols:
            return pd.DataFrame(), None

        work = self.df.copy()

        if task_type_norm == "classification" and target_col not in self.numeric_cols:
            encoded_target = pd.Series(
                pd.factorize(work[target_col].astype("string").fillna("Missing"))[0],
                index=work.index,
                name=target_col,
            )
            corr_frame = work[numeric_cols].copy()
            corr_frame[target_col] = encoded_target
        else:
            corr_frame = work[numeric_cols].copy()
            corr_frame[target_col] = pd.to_numeric(work[target_col], errors="coerce")

        corr_matrix = corr_frame.corr(numeric_only=True)

        if target_col not in corr_matrix.columns:
            return pd.DataFrame(), None

        corr_series = corr_matrix[target_col].drop(labels=[target_col], errors="ignore").dropna()

        if corr_series.empty:
            return pd.DataFrame(), None

        corr_df = corr_series.rename("correlation_with_target").to_frame()
        corr_df["abs_correlation"] = corr_df["correlation_with_target"].abs()
        corr_df = (
            corr_df.sort_values("abs_correlation", ascending=False)
            .reset_index()
            .rename(columns={"index": "feature"})
        )

        plot_df = corr_df.copy()
        if top_n is not None:
            plot_df = plot_df.head(top_n)

        bar_colors = [
            self.COLOR_BLUE if val >= 0 else self.COLOR_RED
            for val in plot_df["correlation_with_target"]
        ]

        fig, ax = plt.subplots(figsize=(9.5, max(4.5, 0.38 * len(plot_df))))
        ax.barh(
            plot_df["feature"],
            plot_df["correlation_with_target"],
            color=bar_colors,
            edgecolor=self.COLOR_BLACK,
            linewidth=0.7,
        )
        ax.axvline(0, linestyle="--", linewidth=1.2, color=self.COLOR_BLACK)
        ax.set_title(f"Feature Correlation with Target: {target_col}", fontsize=13, color=self.COLOR_BLACK, pad=10)
        ax.set_xlabel("Correlation", color=self.COLOR_BLACK)
        ax.set_ylabel("Feature", color=self.COLOR_BLACK)
        ax.invert_yaxis()
        self._apply_scientific_axis_style(ax, grid_axis="x")
        fig.tight_layout()

        return corr_df, fig

    def plot_pairplot(
        self,
        selected_numeric_cols: list[str],
        target_col: Optional[str] = None,
        task_type: str = "Regression",
        max_rows: int = 1000,
    ) -> tuple[pd.DataFrame, Optional[Figure]]:
        if not isinstance(selected_numeric_cols, list):
            raise TypeError("selected_numeric_cols must be a list of column names.")

        if len(selected_numeric_cols) < 2:
            return pd.DataFrame(), None

        missing_cols = [c for c in selected_numeric_cols if c not in self.df.columns]
        if missing_cols:
            raise KeyError(f"Columns not found: {missing_cols}")

        non_numeric = [c for c in selected_numeric_cols if c not in self.numeric_cols]
        if non_numeric:
            raise ValueError(f"These columns are not numeric: {non_numeric}")

        work = self.df.copy()
        pairplot_cols = selected_numeric_cols.copy()

        hue_col = None
        if (
            str(task_type).strip().lower() == "classification"
            and target_col is not None
            and target_col in work.columns
            and work[target_col].nunique(dropna=True) <= 10
        ):
            hue_col = target_col
            pairplot_cols = pairplot_cols + [target_col]

        pair_df = work[pairplot_cols].dropna().copy()

        if pair_df.empty:
            return pd.DataFrame(), None

        if len(pair_df) > max_rows:
            pair_df = pair_df.sample(max_rows, random_state=42)

        palette = [self.COLOR_BLUE, self.COLOR_RED, self.COLOR_GREY, self.COLOR_BLACK]

        grid = sns.pairplot(
            pair_df,
            vars=selected_numeric_cols,
            hue=hue_col,
            corner=True,
            diag_kind="hist",
            palette=palette if hue_col is not None else None,
            plot_kws={
                "alpha": 0.65,
                "edgecolor": self.COLOR_BLACK,
                "linewidth": 0.25,
                "s": 30,
                "color": self.COLOR_BLUE if hue_col is None else None,
            },
            diag_kws={
                "edgecolor": self.COLOR_BLACK,
                "linewidth": 0.6,
                "color": self.COLOR_LIGHT_GREY if hue_col is None else None,
            },
        )

        for ax in grid.axes.flatten():
            if ax is not None:
                self._apply_scientific_axis_style(ax, grid_axis="both")

        grid.figure.suptitle("Pairwise Distribution and Relationship Analysis", y=1.02, color=self.COLOR_BLACK)
        grid.figure.tight_layout()
        return pair_df, grid.figure

    def plot_correlation_matrix(
        self,
        columns: Optional[list[str]] = None,
        method: str = "pearson",
        annot: bool = True,
    ) -> tuple[pd.DataFrame, list[str], Optional[Figure]]:
        valid_methods = ["pearson", "spearman", "kendall"]
        if method not in valid_methods:
            raise ValueError(f"method must be one of {valid_methods}")

        if columns is None:
            used_columns = self.numeric_cols[:5]
        else:
            missing_cols = [c for c in columns if c not in self.df.columns]
            if missing_cols:
                raise KeyError(f"Columns not found: {missing_cols}")

            non_numeric_cols = [c for c in columns if c not in self.numeric_cols]
            if non_numeric_cols:
                raise ValueError(f"These columns are not numeric: {non_numeric_cols}")

            used_columns = columns.copy()

        if len(used_columns) < 2:
            return pd.DataFrame(), used_columns, None

        corr_df = self.df[used_columns].corr(method=method, numeric_only=True)
        cmap = self._build_correlation_cmap()

        fig_height = max(5.5, 0.85 * len(used_columns))
        fig_width = max(6.5, 0.95 * len(used_columns))

        fig, ax = plt.subplots(figsize=(fig_width, fig_height))
        sns.heatmap(
            corr_df,
            annot=annot,
            fmt=".2f",
            cmap=cmap,
            center=0,
            vmin=-1,
            vmax=1,
            square=True,
            linewidths=0.7,
            linecolor=self.COLOR_GRID,
            cbar=True,
            ax=ax,
            annot_kws={"fontsize": 10, "color": self.COLOR_BLACK},
        )
        ax.set_title(f"Correlation Matrix ({method.title()})", fontsize=13, color=self.COLOR_BLACK, pad=12)
        ax.tick_params(colors=self.COLOR_BLACK)
        for spine in ax.spines.values():
            spine.set_visible(False)
        fig.tight_layout()

        return corr_df, used_columns, fig

    def plot_qq(
        self,
        column: str,
        dist: str = "norm",
    ) -> tuple[pd.DataFrame, pd.DataFrame, Optional[Figure]]:
        if column not in self.df.columns:
            raise KeyError(f"Column '{column}' not found.")

        if column not in self.numeric_cols:
            raise ValueError(f"Column '{column}' is not numeric.")

        values = pd.to_numeric(self.df[column], errors="coerce").dropna()

        missing_count = int(self.df[column].isna().sum())
        missing_pct = float(self.df[column].isna().mean() * 100)

        if len(values) < 3:
            stats_df = pd.DataFrame(
                {
                    "metric": ["column", "count", "missing_count", "missing_pct"],
                    "value": [column, int(len(values)), missing_count, round(missing_pct, 4)],
                }
            )
            return pd.DataFrame(), stats_df, None

        (theoretical_q, ordered_values), (slope, intercept, r_val) = sp_stats.probplot(
            values,
            dist=dist,
            fit=True,
        )

        qq_df = pd.DataFrame(
            {
                "theoretical_quantile": theoretical_q,
                "ordered_value": ordered_values,
                "reference_line": slope * np.asarray(theoretical_q) + intercept,
            }
        )

        stats_df = pd.DataFrame(
            {
                "metric": [
                    "column",
                    "distribution",
                    "count",
                    "missing_count",
                    "missing_pct",
                    "mean",
                    "std",
                    "skewness",
                    "kurtosis",
                    "qq_r",
                    "qq_r_squared",
                    "qq_slope",
                    "qq_intercept",
                ],
                "value": [
                    column,
                    dist,
                    int(len(values)),
                    missing_count,
                    round(missing_pct, 4),
                    float(values.mean()),
                    float(values.std()),
                    float(values.skew()),
                    float(values.kurt()),
                    float(r_val),
                    float(r_val ** 2),
                    float(slope),
                    float(intercept),
                ],
            }
        )

        fig, ax = plt.subplots(figsize=(7.8, 6.2))
        ax.scatter(
            qq_df["theoretical_quantile"],
            qq_df["ordered_value"],
            color=self.COLOR_BLUE,
            edgecolor=self.COLOR_BLACK,
            linewidth=0.4,
            alpha=0.75,
            s=28,
        )
        ax.plot(
            qq_df["theoretical_quantile"],
            qq_df["reference_line"],
            color=self.COLOR_RED,
            linestyle="--",
            linewidth=2.0,
        )

        ax.set_title(
            f"Q-Q Plot: {column} vs {dist}",
            fontsize=13,
            color=self.COLOR_BLACK,
            pad=10,
        )
        ax.set_xlabel("Theoretical Quantiles", color=self.COLOR_BLACK)
        ax.set_ylabel("Observed Quantiles", color=self.COLOR_BLACK)
        self._apply_scientific_axis_style(ax, grid_axis="both")
        fig.tight_layout()

        return qq_df, stats_df, fig

    def plot_grouped_numeric_distribution(
        self,
        value_col: str,
        group_col: str,
        kind: str = "box",
        top_n_groups: Optional[int] = 15,
        order_by: str = "median",
        show_points: bool = False,
    ) -> tuple[pd.DataFrame, pd.DataFrame, Optional[Figure]]:
        if value_col not in self.df.columns:
            raise KeyError(f"Column '{value_col}' not found.")
        if group_col not in self.df.columns:
            raise KeyError(f"Column '{group_col}' not found.")

        if value_col not in self.numeric_cols:
            raise ValueError(f"Column '{value_col}' is not numeric.")

        valid_kinds = ["box", "violin"]
        if kind not in valid_kinds:
            raise ValueError(f"kind must be one of {valid_kinds}")

        valid_orders = ["median", "mean", "count", "alphabetical"]
        if order_by not in valid_orders:
            raise ValueError(f"order_by must be one of {valid_orders}")

        group_series = self.df[group_col].copy()
        if group_col in self.datetime_cols:
            group_series = pd.to_datetime(group_series, errors="coerce").dt.strftime("%Y-%m-%d")

        plot_df = pd.DataFrame(
            {
                group_col: group_series.astype("string").fillna("Missing"),
                value_col: pd.to_numeric(self.df[value_col], errors="coerce"),
            }
        ).dropna()

        if plot_df.empty:
            return pd.DataFrame(), pd.DataFrame(), None

        grouped = plot_df.groupby(group_col)[value_col]

        summary_df = grouped.agg(["count", "mean", "median", "std", "min", "max"]).reset_index()
        q1 = grouped.quantile(0.25).rename("q1").reset_index(drop=True)
        q3 = grouped.quantile(0.75).rename("q3").reset_index(drop=True)
        summary_df["q1"] = q1
        summary_df["q3"] = q3
        summary_df["iqr"] = summary_df["q3"] - summary_df["q1"]

        if top_n_groups is not None and len(summary_df) > top_n_groups:
            keep_groups = (
                summary_df.sort_values("count", ascending=False)[group_col]
                .head(top_n_groups)
                .tolist()
            )
            plot_df = plot_df[plot_df[group_col].isin(keep_groups)].copy()
            summary_df = summary_df[summary_df[group_col].isin(keep_groups)].copy()

        if order_by == "alphabetical":
            summary_df = summary_df.sort_values(group_col, ascending=True)
        else:
            summary_df = summary_df.sort_values(order_by, ascending=False)

        group_order = summary_df[group_col].tolist()

        fig_width = max(9, 0.7 * len(group_order))
        fig, ax = plt.subplots(figsize=(fig_width, 6.2))

        if kind == "box":
            sns.boxplot(
                data=plot_df,
                x=group_col,
                y=value_col,
                order=group_order,
                ax=ax,
                color=self.COLOR_LIGHT_GREY,
                width=0.6,
                boxprops=dict(edgecolor=self.COLOR_BLACK, linewidth=1.0),
                whiskerprops=dict(color=self.COLOR_BLACK, linewidth=1.0),
                capprops=dict(color=self.COLOR_BLACK, linewidth=1.0),
                medianprops=dict(color=self.COLOR_RED, linewidth=1.8),
                flierprops=dict(
                    marker="o",
                    markerfacecolor=self.COLOR_GREY,
                    markeredgecolor=self.COLOR_BLACK,
                    markersize=4,
                    alpha=0.7,
                ),
            )
        else:
            sns.violinplot(
                data=plot_df,
                x=group_col,
                y=value_col,
                order=group_order,
                ax=ax,
                color=self.COLOR_LIGHT_GREY,
                inner="box",
                linewidth=1.0,
                cut=0,
            )

        if show_points:
            sns.stripplot(
                data=plot_df,
                x=group_col,
                y=value_col,
                order=group_order,
                ax=ax,
                color=self.COLOR_BLUE,
                alpha=0.35,
                size=3,
                jitter=0.20,
            )

        ax.set_title(
            f"{kind.title()} Plot of {value_col} by {group_col}",
            fontsize=13,
            color=self.COLOR_BLACK,
            pad=10,
        )
        ax.set_xlabel(group_col, color=self.COLOR_BLACK)
        ax.set_ylabel(value_col, color=self.COLOR_BLACK)
        self._apply_scientific_axis_style(ax, grid_axis="y", rotate_xticks=35)
        fig.tight_layout()

        return plot_df, summary_df.reset_index(drop=True), fig

    def plot_datetime_rolling_density(
        self,
        datetime_col: str,
        freq: str = "D",
        rolling_window: int = 30,
    ) -> tuple[pd.DataFrame, pd.DataFrame, Optional[Figure]]:
        if datetime_col not in self.df.columns:
            raise KeyError(f"Column '{datetime_col}' not found.")

        dt_series = pd.to_datetime(self.df[datetime_col], errors="coerce").dropna()

        missing_count = int(self.df[datetime_col].isna().sum())
        missing_pct = float(self.df[datetime_col].isna().mean() * 100)

        if dt_series.empty:
            stats_df = pd.DataFrame(
                {
                    "metric": ["column", "count", "missing_count", "missing_pct"],
                    "value": [datetime_col, 0, missing_count, round(missing_pct, 4)],
                }
            )
            return pd.DataFrame(), stats_df, None

        counts = pd.Series(1, index=dt_series).sort_index().resample(freq).sum().fillna(0)

        try:
            counts = counts.asfreq(freq, fill_value=0)
        except Exception:
            pass

        density = counts / counts.sum() if counts.sum() > 0 else counts.astype(float)
        rolling_count = counts.rolling(window=rolling_window, min_periods=1).mean()
        rolling_density = density.rolling(window=rolling_window, min_periods=1).mean()
        cumulative_density = density.cumsum()

        time_df = pd.DataFrame(
            {
                "period": counts.index,
                "count": counts.values,
                "density": density.values,
                "rolling_count": rolling_count.values,
                "rolling_density": rolling_density.values,
                "cumulative_density": cumulative_density.values,
            }
        )

        stats_df = pd.DataFrame(
            {
                "metric": [
                    "column",
                    "count",
                    "missing_count",
                    "missing_pct",
                    "min_date",
                    "max_date",
                    "range_days",
                    "resample_frequency",
                    "rolling_window",
                    "active_periods",
                    "mean_count_per_period",
                    "max_count_per_period",
                    "mean_density",
                    "max_density",
                ],
                "value": [
                    datetime_col,
                    int(len(dt_series)),
                    missing_count,
                    round(missing_pct, 4),
                    str(dt_series.min()),
                    str(dt_series.max()),
                    int((dt_series.max() - dt_series.min()).days),
                    freq,
                    rolling_window,
                    int((counts > 0).sum()),
                    float(counts.mean()),
                    float(counts.max()),
                    float(density.mean()),
                    float(density.max()),
                ],
            }
        )

        fig, axes = plt.subplots(
            nrows=2,
            ncols=1,
            figsize=(12, 8),
            sharex=True,
            gridspec_kw={"height_ratios": [2.0, 1.4]},
        )

        ax1, ax2 = axes

        ax1.bar(
            time_df["period"],
            time_df["count"],
            color=self.COLOR_LIGHT_GREY,
            edgecolor=self.COLOR_BLACK,
            linewidth=0.5,
        )
        ax1.plot(
            time_df["period"],
            time_df["rolling_count"],
            color=self.COLOR_RED,
            linewidth=2.0,
            label=f"Rolling mean count ({rolling_window} periods)",
        )
        ax1.set_title(
            f"Temporal Event Frequency: {datetime_col}",
            fontsize=13,
            color=self.COLOR_BLACK,
            pad=10,
        )
        ax1.set_ylabel("Count", color=self.COLOR_BLACK)
        ax1.legend(frameon=False)
        self._apply_scientific_axis_style(ax1, grid_axis="y")

        ax2.fill_between(
            time_df["period"],
            time_df["rolling_density"],
            color=self.COLOR_BLUE,
            alpha=0.20,
        )
        ax2.plot(
            time_df["period"],
            time_df["rolling_density"],
            color=self.COLOR_BLUE,
            linewidth=2.0,
            label="Rolling density",
        )
        ax2.set_ylabel("Density", color=self.COLOR_BLACK)
        ax2.set_xlabel(datetime_col, color=self.COLOR_BLACK)
        self._apply_scientific_axis_style(ax2, grid_axis="y")

        ax2b = ax2.twinx()
        ax2b.plot(
            time_df["period"],
            time_df["cumulative_density"],
            color=self.COLOR_GREY,
            linestyle="--",
            linewidth=1.8,
            label="Cumulative density",
        )
        ax2b.set_ylabel("Cumulative density", color=self.COLOR_GREY)
        ax2b.tick_params(axis="y", colors=self.COLOR_GREY)
        ax2b.spines["top"].set_visible(False)
        ax2b.spines["left"].set_visible(False)
        ax2b.spines["right"].set_color(self.COLOR_GRID)

        lines_left, labels_left = ax2.get_legend_handles_labels()
        lines_right, labels_right = ax2b.get_legend_handles_labels()
        ax2.legend(lines_left + lines_right, labels_left + labels_right, frameon=False, loc="upper left")

        fig.tight_layout()
        return time_df, stats_df, fig

    def plot_correlation_matrix_with_pvalues(
        self,
        columns: Optional[list[str]] = None,
        method: str = "pearson",
        annot: bool = True,
        pvalue_annot: bool = True,
        pvalue_vmax: float = 0.10,
    ) -> tuple[pd.DataFrame, pd.DataFrame, list[str], Optional[Figure]]:
        valid_methods = ["pearson", "spearman", "kendall"]
        if method not in valid_methods:
            raise ValueError(f"method must be one of {valid_methods}")

        if columns is None:
            used_columns = self.numeric_cols[:5]
        else:
            missing_cols = [c for c in columns if c not in self.df.columns]
            if missing_cols:
                raise KeyError(f"Columns not found: {missing_cols}")

            non_numeric_cols = [c for c in columns if c not in self.numeric_cols]
            if non_numeric_cols:
                raise ValueError(f"These columns are not numeric: {non_numeric_cols}")

            used_columns = columns.copy()

        if len(used_columns) < 2:
            return pd.DataFrame(), pd.DataFrame(), used_columns, None

        n = len(used_columns)
        corr_df = pd.DataFrame(np.nan, index=used_columns, columns=used_columns, dtype=float)
        pval_df = pd.DataFrame(np.nan, index=used_columns, columns=used_columns, dtype=float)

        for i, col_i in enumerate(used_columns):
            corr_df.loc[col_i, col_i] = 1.0
            pval_df.loc[col_i, col_i] = 0.0

            for j in range(i + 1, n):
                col_j = used_columns[j]

                corr_val, p_val = self._compute_pairwise_correlation_and_pvalue(
                    self.df[col_i],
                    self.df[col_j],
                    method=method,
                )

                corr_df.loc[col_i, col_j] = corr_val
                corr_df.loc[col_j, col_i] = corr_val

                pval_df.loc[col_i, col_j] = p_val
                pval_df.loc[col_j, col_i] = p_val

        corr_cmap = self._build_correlation_cmap()
        pval_cmap = self._build_pvalue_cmap()

        fig_width = max(12, 1.35 * len(used_columns) * 2)
        fig_height = max(5.5, 0.95 * len(used_columns))

        fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(fig_width, fig_height))

        sns.heatmap(
            corr_df,
            annot=annot,
            fmt=".2f",
            cmap=corr_cmap,
            center=0,
            vmin=-1,
            vmax=1,
            square=True,
            linewidths=0.7,
            linecolor=self.COLOR_GRID,
            cbar=True,
            ax=axes[0],
            annot_kws={"fontsize": 10, "color": self.COLOR_BLACK},
        )
        axes[0].set_title(
            f"Correlation Matrix ({method.title()})",
            fontsize=13,
            color=self.COLOR_BLACK,
            pad=12,
        )
        axes[0].tick_params(colors=self.COLOR_BLACK)
        for spine in axes[0].spines.values():
            spine.set_visible(False)

        if pvalue_annot:
            pval_annot_df = pval_df.applymap(lambda x: "" if pd.isna(x) else f"{x:.3g}")
        else:
            pval_annot_df = False

        sns.heatmap(
            pval_df,
            annot=pval_annot_df,
            fmt="",
            cmap=pval_cmap,
            vmin=0,
            vmax=pvalue_vmax,
            square=True,
            linewidths=0.7,
            linecolor=self.COLOR_GRID,
            cbar=True,
            ax=axes[1],
            annot_kws={"fontsize": 10, "color": self.COLOR_BLACK},
        )
        axes[1].set_title(
            "P-value Matrix",
            fontsize=13,
            color=self.COLOR_BLACK,
            pad=12,
        )
        axes[1].tick_params(colors=self.COLOR_BLACK)
        for spine in axes[1].spines.values():
            spine.set_visible(False)

        fig.tight_layout()
        return corr_df, pval_df, used_columns, fig

    def _build_missing_summary(self, df: pd.DataFrame) -> pd.DataFrame:
        rows = []
        total_rows = len(df)

        for col in df.columns:
            series = df[col]
            missing_count = int(series.isna().sum())
            non_missing_count = int(series.notna().sum())

            missing_pct = (missing_count / total_rows * 100) if total_rows > 0 else np.nan
            non_missing_pct = (non_missing_count / total_rows * 100) if total_rows > 0 else np.nan

            rows.append(
                {
                    "column": col,
                    "dtype": str(series.dtype),
                    "total_rows": total_rows,
                    "non_missing_count": non_missing_count,
                    "non_missing_pct": round(non_missing_pct, 4) if pd.notna(non_missing_pct) else np.nan,
                    "missing_count": missing_count,
                    "missing_pct": round(missing_pct, 4) if pd.notna(missing_pct) else np.nan,
                }
            )

        out = pd.DataFrame(rows)
        if out.empty:
            return out

        return out.sort_values(
            ["missing_count", "missing_pct", "column"],
            ascending=[False, False, True],
        ).reset_index(drop=True)

    def _describe_numeric(self, df: pd.DataFrame) -> pd.DataFrame:
        rows = []

        for col in [c for c in self.numeric_cols if c in df.columns]:
            series = pd.to_numeric(df[col], errors="coerce")
            non_missing = series.dropna()

            total_rows = len(series)
            missing_count = int(series.isna().sum())
            missing_pct = (missing_count / total_rows * 100) if total_rows > 0 else np.nan

            rows.append(
                {
                    "column": col,
                    "dtype": str(df[col].dtype),
                    "count": int(non_missing.shape[0]),
                    "missing_count": missing_count,
                    "missing_pct": round(missing_pct, 4) if pd.notna(missing_pct) else np.nan,
                    "unique_values": int(non_missing.nunique()) if not non_missing.empty else 0,
                    "mean": self._safe_float(non_missing.mean()) if not non_missing.empty else np.nan,
                    "std": self._safe_float(non_missing.std()) if not non_missing.empty else np.nan,
                    "min": self._safe_float(non_missing.min()) if not non_missing.empty else np.nan,
                    "25%": self._safe_float(non_missing.quantile(0.25)) if not non_missing.empty else np.nan,
                    "50%": self._safe_float(non_missing.quantile(0.50)) if not non_missing.empty else np.nan,
                    "75%": self._safe_float(non_missing.quantile(0.75)) if not non_missing.empty else np.nan,
                    "max": self._safe_float(non_missing.max()) if not non_missing.empty else np.nan,
                    "skewness": self._safe_float(non_missing.skew()) if not non_missing.empty else np.nan,
                    "kurtosis": self._safe_float(non_missing.kurt()) if not non_missing.empty else np.nan,
                }
            )

        return pd.DataFrame(rows)

    def _describe_categorical(self, df: pd.DataFrame) -> pd.DataFrame:
        rows = []

        for col in [c for c in self.categorical_cols if c in df.columns]:
            original_series = df[col]
            series = original_series.astype("string")
            filled = series.fillna("Missing")
            counts = filled.value_counts(dropna=False)

            total_rows = len(series)
            missing_count = int(series.isna().sum())
            missing_pct = (missing_count / total_rows * 100) if total_rows > 0 else np.nan

            top_category = counts.index[0] if len(counts) > 0 else np.nan
            top_count = int(counts.iloc[0]) if len(counts) > 0 else 0
            top_pct = (top_count / total_rows * 100) if total_rows > 0 else np.nan

            rows.append(
                {
                    "column": col,
                    "dtype": str(original_series.dtype),
                    "count": total_rows,
                    "missing_count": missing_count,
                    "missing_pct": round(missing_pct, 4) if pd.notna(missing_pct) else np.nan,
                    "unique_values": int(filled.nunique(dropna=False)),
                    "top_category": str(top_category) if pd.notna(top_category) else np.nan,
                    "top_category_count": top_count,
                    "top_category_pct": round(top_pct, 4) if pd.notna(top_pct) else np.nan,
                }
            )

        return pd.DataFrame(rows)

    def _describe_datetime(self, df: pd.DataFrame) -> pd.DataFrame:
        rows = []

        for col in [c for c in self.datetime_cols if c in df.columns]:
            series = pd.to_datetime(df[col], errors="coerce")
            non_missing = series.dropna()

            total_rows = len(series)
            missing_count = int(series.isna().sum())
            missing_pct = (missing_count / total_rows * 100) if total_rows > 0 else np.nan

            min_date = non_missing.min() if not non_missing.empty else pd.NaT
            max_date = non_missing.max() if not non_missing.empty else pd.NaT
            range_days = (max_date - min_date).days if pd.notna(min_date) and pd.notna(max_date) else np.nan

            rows.append(
                {
                    "column": col,
                    "dtype": str(df[col].dtype),
                    "count": int(non_missing.shape[0]),
                    "missing_count": missing_count,
                    "missing_pct": round(missing_pct, 4) if pd.notna(missing_pct) else np.nan,
                    "unique_dates": int(non_missing.nunique()) if not non_missing.empty else 0,
                    "min_date": min_date,
                    "max_date": max_date,
                    "range_days": range_days,
                }
            )

        return pd.DataFrame(rows)

    def _grouped_description(
        self,
        builder: Callable[[pd.DataFrame], pd.DataFrame],
        groupby_cols: list[str],
    ) -> pd.DataFrame:
        pieces = []
        grouped = self.df.groupby(groupby_cols, dropna=False, observed=False)

        for group_key, group_df in grouped:
            keys = group_key if isinstance(group_key, tuple) else (group_key,)
            result = builder(group_df)

            if result.empty:
                continue

            result = result.copy()
            for col_name, value in zip(groupby_cols, keys):
                result[col_name] = value

            ordered_cols = groupby_cols + [c for c in result.columns if c not in groupby_cols]
            result = result[ordered_cols]
            pieces.append(result)

        if not pieces:
            return pd.DataFrame()

        return pd.concat(pieces, ignore_index=True)

    def _refresh_column_buckets(self) -> None:
        self.numeric_cols = [
            col
            for col in self.df.columns
            if pd.api.types.is_numeric_dtype(self.df[col]) and not pd.api.types.is_bool_dtype(self.df[col])
        ]

        self.datetime_cols = [
            col
            for col in self.df.columns
            if pd.api.types.is_datetime64_any_dtype(self.df[col])
        ]

        self.categorical_cols = [
            col
            for col in self.df.columns
            if col not in self.numeric_cols and col not in self.datetime_cols
        ]

    def _infer_and_convert_datetime_columns(self) -> None:
        for col in self.df.columns:
            series = self.df[col]

            if pd.api.types.is_datetime64_any_dtype(series):
                continue
            if pd.api.types.is_numeric_dtype(series) or pd.api.types.is_bool_dtype(series):
                continue
            if not (pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series)):
                continue

            non_missing = series.dropna()
            if non_missing.empty:
                continue

            sample_strings = non_missing.astype(str).str.strip()
            parsed = None

            common_formats = [
                "%Y-%m-%d",
                "%Y/%m/%d",
                "%d-%m-%Y",
                "%d/%m/%Y",
                "%m-%d-%Y",
                "%m/%d/%Y",
                "%Y-%m-%d %H:%M:%S",
                "%Y/%m/%d %H:%M:%S",
            ]

            for fmt in common_formats:
                try:
                    candidate = pd.to_datetime(sample_strings, format=fmt, errors="coerce")
                    if candidate.notna().mean() >= self.datetime_inference_threshold:
                        parsed = candidate
                        break
                except Exception:
                    continue

            if parsed is None:
                try:
                    parsed = pd.to_datetime(sample_strings, format="mixed", errors="coerce")
                except Exception:
                    parsed = pd.to_datetime(sample_strings, errors="coerce")

            success_rate = parsed.notna().mean()

            if success_rate >= self.datetime_inference_threshold:
                try:
                    self.df[col] = pd.to_datetime(self.df[col], format="mixed", errors="coerce")
                except Exception:
                    self.df[col] = pd.to_datetime(self.df[col], errors="coerce")

    def _validate_groupby_cols(self, groupby_cols: list[str]) -> None:
        if not isinstance(groupby_cols, list):
            raise TypeError("groupby_cols must be a list of column names.")

        missing = [col for col in groupby_cols if col not in self.df.columns]
        if missing:
            raise KeyError(f"groupby columns not found: {missing}")

    def _compute_pairwise_correlation_and_pvalue(
        self,
        x: pd.Series,
        y: pd.Series,
        method: str = "pearson",
    ) -> tuple[float, float]:
        pair = pd.DataFrame(
            {
                "x": pd.to_numeric(x, errors="coerce"),
                "y": pd.to_numeric(y, errors="coerce"),
            }
        ).dropna()

        if len(pair) < 3:
            return np.nan, np.nan

        if pair["x"].nunique() < 2 or pair["y"].nunique() < 2:
            return np.nan, np.nan

        try:
            if method == "pearson":
                corr_val, p_val = sp_stats.pearsonr(pair["x"], pair["y"])
            elif method == "spearman":
                corr_val, p_val = sp_stats.spearmanr(pair["x"], pair["y"])
            elif method == "kendall":
                corr_val, p_val = sp_stats.kendalltau(pair["x"], pair["y"])
            else:
                raise ValueError(f"Unsupported method: {method}")
        except Exception:
            return np.nan, np.nan

        return float(corr_val), float(p_val)

    def _apply_scientific_axis_style(
        self,
        ax,
        grid_axis: str = "y",
        rotate_xticks: int = 0,
    ) -> None:
        ax.set_facecolor("white")
        ax.tick_params(axis="both", colors=self.COLOR_BLACK, labelsize=10)

        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)

        for spine in ["left", "bottom"]:
            ax.spines[spine].set_color(self.COLOR_GRID)
            ax.spines[spine].set_linewidth(0.8)

        ax.grid(True, axis=grid_axis, color=self.COLOR_GRID, linestyle="--", linewidth=0.7, alpha=0.8)
        ax.set_axisbelow(True)

        if rotate_xticks != 0:
            for tick in ax.get_xticklabels():
                tick.set_rotation(rotate_xticks)
                tick.set_horizontalalignment("right")

    def _build_correlation_cmap(self):
        return LinearSegmentedColormap.from_list(
            "scientific_red_grey_blue",
            [self.COLOR_RED, self.COLOR_LIGHT_GREY, self.COLOR_BLUE],
            N=256,
        )

    def _build_pvalue_cmap(self):
        return LinearSegmentedColormap.from_list(
            "scientific_blue_grey_red",
            [self.COLOR_BLUE, self.COLOR_LIGHT_GREY, self.COLOR_RED],
            N=256,
        )

    @staticmethod
    def _safe_float(x):
        try:
            if pd.isna(x):
                return np.nan
            return float(x)
        except Exception:
            return np.nan

    @staticmethod
    def _format_num(x, digits: int = 4) -> str:
        if pd.isna(x):
            return "NaN"
        return f"{float(x):,.{digits}f}"

    @staticmethod
    def _count_histogram_peaks(values: np.ndarray, bins: int = 20) -> int:
        if len(values) < 20:
            return 1

        counts, _ = np.histogram(values, bins=bins)
        peaks = 0
        for i in range(1, len(counts) - 1):
            if counts[i] > counts[i - 1] and counts[i] > counts[i + 1]:
                peaks += 1
        return max(peaks, 1)

    @staticmethod
    def _guess_distribution(skew_val: float, kurt_val: float, peak_count: int) -> str:
        if pd.isna(skew_val) or pd.isna(kurt_val):
            return "Not enough information"
        if peak_count >= 2:
            return "Possibly multimodal"
        if abs(skew_val) < 0.35 and abs(kurt_val) < 1.0:
            return "Close to normal-like"
        if abs(skew_val) < 0.35 and kurt_val < -1.0:
            return "Closer to uniform-like / flat"
        if skew_val > 1.0:
            if kurt_val > 1.5:
                return "Right-skewed, lognormal/exponential-like"
            return "Moderately right-skewed"
        if skew_val < -1.0:
            if kurt_val > 1.5:
                return "Left-skewed with heavy tail"
            return "Moderately left-skewed"
        if kurt_val > 2.0:
            return "Heavy-tailed"
        return "Roughly symmetric but not clearly normal"


# _SML_EDA_LOGGING_PATCH
from scientific_ml_modules.utils.logging_utils import instrument_method
for _name in [
    "refresh", "plot_single_column_distribution", "plot_missing_columns",
    "plot_scatter_with_marginals", "compute_target_correlations", "plot_pairplot",
    "plot_correlation_matrix", "plot_qq", "plot_grouped_numeric_distribution",
    "plot_datetime_rolling_density", "plot_correlation_matrix_with_pvalues"
]:
    instrument_method(ExplanatoryAnalyzer, _name, label=f"EDA:{_name}")

