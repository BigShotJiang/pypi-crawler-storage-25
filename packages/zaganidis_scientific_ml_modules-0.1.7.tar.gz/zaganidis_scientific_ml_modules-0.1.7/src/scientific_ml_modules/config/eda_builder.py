from __future__ import annotations

from typing import Optional

import pandas as pd

from scientific_ml_modules.core.eda import ExplanatoryAnalyzer


class ExplanatoryAnalyzerBuilder:
    """
    Fluent builder for ExplanatoryAnalyzer.

    Example
    -------
    eda = (
        ExplanatoryAnalyzerBuilder()
        .with_dataframe(df)
        .with_infer_datetime_strings(True)
        .with_datetime_inference_threshold(0.85)
        .with_groupby_cols(["country", "segment"])
        .build()
    )
    """

    def __init__(self):
        self._df: Optional[pd.DataFrame] = None
        self._infer_datetime_strings: bool = False
        self._datetime_inference_threshold: float = 0.8
        self._groupby_cols: Optional[list[str]] = None
        self._logging_enabled: bool = True

    def with_dataframe(self, df: pd.DataFrame) -> "ExplanatoryAnalyzerBuilder":
        if not isinstance(df, pd.DataFrame):
            raise TypeError("df must be a pandas DataFrame.")
        self._df = df.copy()
        return self

    def with_infer_datetime_strings(self, value: bool) -> "ExplanatoryAnalyzerBuilder":
        if not isinstance(value, bool):
            raise TypeError("infer_datetime_strings must be a bool.")
        self._infer_datetime_strings = value
        return self

    def with_datetime_inference_threshold(self, value: float) -> "ExplanatoryAnalyzerBuilder":
        if not isinstance(value, (int, float)):
            raise TypeError("datetime_inference_threshold must be numeric.")

        value = float(value)
        if not (0 <= value <= 1):
            raise ValueError("datetime_inference_threshold must be between 0 and 1.")

        self._datetime_inference_threshold = value
        return self

    def with_groupby_cols(self, groupby_cols: Optional[list[str]]) -> "ExplanatoryAnalyzerBuilder":
        if groupby_cols is None:
            self._groupby_cols = None
            return self

        if not isinstance(groupby_cols, list):
            raise TypeError("groupby_cols must be a list of strings or None.")
        if not all(isinstance(col, str) for col in groupby_cols):
            raise TypeError("All groupby_cols must be strings.")

        self._groupby_cols = groupby_cols.copy()
        return self

    def logging(self, enabled: bool = True) -> "ExplanatoryAnalyzerBuilder":
        self._logging_enabled = bool(enabled)
        return self

    def reset(self) -> "ExplanatoryAnalyzerBuilder":
        self._df = None
        self._infer_datetime_strings = False
        self._datetime_inference_threshold = 0.8
        self._groupby_cols = None
        self._logging_enabled = True
        return self

    def validate(self) -> "ExplanatoryAnalyzerBuilder":
        if self._df is None:
            raise ValueError("DataFrame is mandatory. Use .with_dataframe(df).")

        if self._groupby_cols is not None:
            missing_cols = [col for col in self._groupby_cols if col not in self._df.columns]
            if missing_cols:
                raise KeyError(f"groupby columns not found in df: {missing_cols}")

        return self

    def build(self) -> ExplanatoryAnalyzer:
        self.validate()

        analyzer = ExplanatoryAnalyzer(
            df=self._df,
            infer_datetime_strings=self._infer_datetime_strings,
            datetime_inference_threshold=self._datetime_inference_threshold,
        )

        analyzer.logging_enabled_ = self._logging_enabled

        if self._groupby_cols:
            analyzer.refresh(groupby_cols=self._groupby_cols)

        return analyzer
