from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Union

import pandas as pd

from scientific_ml_modules.core.feature_selection import FeatureSelector


class FeatureSelectorBuilder:
    """
    Fluent builder for FeatureSelector.

    It stores:
    - constructor inputs for FeatureSelector(...)
    - fit inputs for selector.fit(...)

    Then it can:
    - build_selector()      -> returns an unfitted FeatureSelector
    - build_fit()           -> returns a fitted FeatureSelector
    - get_init_params()     -> returns constructor params
    - get_fit_params()      -> returns fit params
    - to_config_frame()     -> returns config as a pandas DataFrame
    """

    def __init__(
        self,
        X_train: pd.DataFrame,
        y_train,
    ) -> None:
        self._init_params: Dict[str, Any] = {
            "X_train": X_train,
            "y_train": y_train,
            "task": "auto",
            "estimator": None,
            "scoring": None,
            "cv": 5,
            "random_state": 42,
            "n_jobs": 1,
            "na_strategy": "error",
        }

        self._logging_enabled: bool = True

        self._fit_params: Dict[str, Any] = {
            "methods": [
                "mutual_info",
                "variance",
                "correlation",
                "permutation",
                "forward",
                "backward",
            ],
            "mi_top_k": 20,
            "variance_threshold": 0.0,
            "corr_threshold": 0.95,
            "perm_top_k": 20,
            "perm_n_repeats": 10,
            "sfs_n_features_to_select": "auto",
            "combine_mode": "vote",
            "min_votes": None,
        }

    # =========================================================
    # Internal helper
    # =========================================================
    def _add_method_once(self, method_name: str) -> None:
        methods = list(self._fit_params["methods"])
        if method_name not in methods:
            methods.append(method_name)
        self._fit_params["methods"] = methods

    # =========================================================
    # Constructor inputs
    # =========================================================
    def task(self, task: str) -> "FeatureSelectorBuilder":
        self._init_params["task"] = task
        return self

    def estimator(self, estimator: Any) -> "FeatureSelectorBuilder":
        self._init_params["estimator"] = estimator
        return self

    def scoring(self, scoring: Optional[str]) -> "FeatureSelectorBuilder":
        self._init_params["scoring"] = scoring
        return self

    def cv(self, cv: int) -> "FeatureSelectorBuilder":
        self._init_params["cv"] = cv
        return self

    def random_state(self, random_state: int) -> "FeatureSelectorBuilder":
        self._init_params["random_state"] = random_state
        return self

    def n_jobs(self, n_jobs: int) -> "FeatureSelectorBuilder":
        self._init_params["n_jobs"] = n_jobs
        return self

    def na_strategy(self, na_strategy: str) -> "FeatureSelectorBuilder":
        self._init_params["na_strategy"] = na_strategy
        return self

    # =========================================================
    # Fit inputs
    # =========================================================
    def logging(self, enabled: bool = True) -> "FeatureSelectorBuilder":
        self._logging_enabled = bool(enabled)
        return self

    def methods(self, methods: Sequence[str]) -> "FeatureSelectorBuilder":
        self._fit_params["methods"] = list(methods)
        return self

    def use_all_methods(self) -> "FeatureSelectorBuilder":
        self._fit_params["methods"] = [
            "mutual_info",
            "variance",
            "correlation",
            "permutation",
            "forward",
            "backward",
        ]
        return self

    def use_fast_methods(self) -> "FeatureSelectorBuilder":
        self._fit_params["methods"] = [
            "mutual_info",
            "variance",
            "correlation",
            "permutation",
        ]
        return self

    def use_light_methods(self) -> "FeatureSelectorBuilder":
        self._fit_params["methods"] = [
            "mutual_info",
            "variance",
            "correlation",
        ]
        return self

    def mutual_info(self, top_k: int = 20) -> "FeatureSelectorBuilder":
        self._add_method_once("mutual_info")
        self._fit_params["mi_top_k"] = top_k
        return self

    def variance(self, threshold: float = 0.0) -> "FeatureSelectorBuilder":
        self._add_method_once("variance")
        self._fit_params["variance_threshold"] = threshold
        return self

    def correlation(self, threshold: float = 0.95) -> "FeatureSelectorBuilder":
        self._add_method_once("correlation")
        self._fit_params["corr_threshold"] = threshold
        return self

    def permutation(
        self,
        top_k: int = 20,
        n_repeats: int = 10,
    ) -> "FeatureSelectorBuilder":
        self._add_method_once("permutation")
        self._fit_params["perm_top_k"] = top_k
        self._fit_params["perm_n_repeats"] = n_repeats
        return self

    def forward(
        self,
        n_features_to_select: Union[int, float, str] = "auto",
    ) -> "FeatureSelectorBuilder":
        self._add_method_once("forward")
        self._fit_params["sfs_n_features_to_select"] = n_features_to_select
        return self

    def backward(
        self,
        n_features_to_select: Union[int, float, str] = "auto",
    ) -> "FeatureSelectorBuilder":
        self._add_method_once("backward")
        self._fit_params["sfs_n_features_to_select"] = n_features_to_select
        return self

    def combine(
        self,
        mode: str = "vote",
        min_votes: Optional[int] = None,
    ) -> "FeatureSelectorBuilder":
        self._fit_params["combine_mode"] = mode
        self._fit_params["min_votes"] = min_votes
        return self

    # =========================================================
    # Presets
    # =========================================================
    def preset_balanced(self) -> "FeatureSelectorBuilder":
        self._fit_params.update({
            "methods": [
                "mutual_info",
                "correlation",
                "permutation",
                "forward",
                "backward",
            ],
            "mi_top_k": 25,
            "variance_threshold": 0.0,
            "corr_threshold": 0.90,
            "perm_top_k": 25,
            "perm_n_repeats": 10,
            "sfs_n_features_to_select": 15,
            "combine_mode": "vote",
            "min_votes": 2,
        })
        return self

    def preset_fast(self) -> "FeatureSelectorBuilder":
        self._fit_params.update({
            "methods": [
                "mutual_info",
                "variance",
                "correlation",
                "permutation",
            ],
            "mi_top_k": 30,
            "variance_threshold": 0.0,
            "corr_threshold": 0.90,
            "perm_top_k": 20,
            "perm_n_repeats": 5,
            "sfs_n_features_to_select": "auto",
            "combine_mode": "vote",
            "min_votes": 2,
        })
        return self

    def preset_light(self) -> "FeatureSelectorBuilder":
        self._fit_params.update({
            "methods": [
                "mutual_info",
                "variance",
                "correlation",
            ],
            "mi_top_k": 20,
            "variance_threshold": 0.0,
            "corr_threshold": 0.90,
            "perm_top_k": 20,
            "perm_n_repeats": 10,
            "sfs_n_features_to_select": "auto",
            "combine_mode": "union",
            "min_votes": None,
        })
        return self

    # =========================================================
    # Read current config
    # =========================================================
    def get_init_params(self) -> Dict[str, Any]:
        return dict(self._init_params)

    def get_fit_params(self) -> Dict[str, Any]:
        return dict(self._fit_params)

    def to_config_frame(self) -> pd.DataFrame:
        rows: List[Dict[str, str]] = []

        for k, v in self._init_params.items():
            if k not in {"X_train", "y_train"}:
                rows.append({
                    "section": "init",
                    "parameter": k,
                    "value": str(v),
                })

        for k, v in self._fit_params.items():
            rows.append({
                "section": "fit",
                "parameter": k,
                "value": str(v),
            })

        return pd.DataFrame(rows)

    # =========================================================
    # Build
    # =========================================================
    def build_selector(self) -> FeatureSelector:
        selector = FeatureSelector(**self._init_params)
        selector.logging_enabled_ = self._logging_enabled
        return selector

    def build_fit(self) -> FeatureSelector:
        selector = self.build_selector()
        selector.fit(**self._fit_params)
        return selector
