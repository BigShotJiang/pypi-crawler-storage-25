from __future__ import annotations

from typing import Any, Dict, List, Optional

import pandas as pd

from scientific_ml_modules.core.processing_core import DataProcessingModule


class DataProcessingConfigBuilder:
    """
    Chainable builder for the `config` input expected by `DataProcessingModule`.
    """

    def __init__(self):
        self._config: Dict[str, Any] = {
            "force_types": {
                "date_cols": [],
                "categorical_cols": [],
                "numerical_cols": [],
            },
            "index_columns": [],
            "remove_duplicates": {
                "enabled": False,
                "subset": None,
                "keep": "first",
            },
            "split": {
                "method": "random",
                "test_size": 0.2,
                "random_state": 42,
            },
            "missing": {
                "default_numeric": {"strategy": "none"},
                "default_categorical": {"strategy": "none"},
                "per_column": {},
            },
            "drop_rows_if_na": {
                "enabled": False,
                "subset": None,
            },
            "encoding": {"per_column": {}},
            "log_transform": {"per_column": {}},
            "binning": {"per_column": {}},
            "polynomial_features": {
                "enabled": False,
                "columns": [],
                "degree": 2,
                "include_bias": False,
                "interaction_only": False,
            },
            "standardize": {"per_column": {}},
            "quantile_transform": {"per_column": {}},
            "power_transform": {"per_column": {}},
            "minmax_scale": {"per_column": {}},
            "logging": {"enabled": True},
        }

    def logging(self, enabled: bool = True) -> "DataProcessingConfigBuilder":
        self._config["logging"] = {"enabled": bool(enabled)}
        return self

    def force_types(
        self,
        date_cols: Optional[List[str]] = None,
        categorical_cols: Optional[List[str]] = None,
        numerical_cols: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["force_types"] = {
            "date_cols": date_cols or [],
            "categorical_cols": categorical_cols or [],
            "numerical_cols": numerical_cols or [],
        }
        return self

    def index_columns(self, columns: List[str]) -> "DataProcessingConfigBuilder":
        self._config["index_columns"] = columns or []
        return self

    def remove_duplicates(
        self,
        enabled: bool = True,
        subset: Optional[List[str]] = None,
        keep: str = "first",
    ) -> "DataProcessingConfigBuilder":
        self._config["remove_duplicates"] = {
            "enabled": enabled,
            "subset": subset,
            "keep": keep,
        }
        return self

    def random_split(
        self,
        test_size: float = 0.2,
        random_state: int = 42,
    ) -> "DataProcessingConfigBuilder":
        self._config["split"] = {
            "method": "random",
            "test_size": test_size,
            "random_state": random_state,
        }
        return self

    def date_split(
        self,
        split_date_col: str,
        split_date_value: Any,
    ) -> "DataProcessingConfigBuilder":
        self._config["split"] = {
            "method": "date",
            "split_date_col": split_date_col,
            "split_date_value": split_date_value,
        }
        return self

    def set_default_numeric_missing(
        self,
        strategy: str,
        fill_value: Any = None,
        groupby: Optional[List[str]] = None,
        sort_by: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["missing"]["default_numeric"] = {
            "strategy": strategy,
            "fill_value": fill_value,
            "groupby": groupby,
            "sort_by": sort_by,
        }
        return self

    def set_default_categorical_missing(
        self,
        strategy: str,
        fill_value: Any = None,
        groupby: Optional[List[str]] = None,
        sort_by: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["missing"]["default_categorical"] = {
            "strategy": strategy,
            "fill_value": fill_value,
            "groupby": groupby,
            "sort_by": sort_by,
        }
        return self

    def set_missing_for_column(
        self,
        column: str,
        strategy: str,
        fill_value: Any = None,
        groupby: Optional[List[str]] = None,
        sort_by: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["missing"]["per_column"][column] = {
            "strategy": strategy,
            "fill_value": fill_value,
            "groupby": groupby,
            "sort_by": sort_by,
        }
        return self

    def drop_rows_if_na(
        self,
        enabled: bool = True,
        subset: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["drop_rows_if_na"] = {
            "enabled": enabled,
            "subset": subset,
        }
        return self

    def encode_label(
        self,
        column: str,
        unknown_value: int = -1,
    ) -> "DataProcessingConfigBuilder":
        self._config["encoding"]["per_column"][column] = {
            "strategy": "label",
            "unknown_value": unknown_value,
        }
        return self

    def encode_onehot(
        self,
        column: str,
        drop_first: bool = False,
        dummy_na: bool = False,
    ) -> "DataProcessingConfigBuilder":
        self._config["encoding"]["per_column"][column] = {
            "strategy": "onehot",
            "drop_first": drop_first,
            "dummy_na": dummy_na,
        }
        return self

    def add_log_transform(
        self,
        column: str,
        mode: str = "shift_log1p",
        groupby: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["log_transform"]["per_column"][column] = {
            "mode": mode,
            "groupby": groupby,
        }
        return self

    def add_binning(
        self,
        column: str,
        n_bins: int = 5,
        mode: str = "cut",
        labels: Any = False,
        groupby: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["binning"]["per_column"][column] = {
            "n_bins": n_bins,
            "mode": mode,
            "labels": labels,
            "groupby": groupby,
        }
        return self

    def set_polynomial_features(
        self,
        columns: List[str],
        degree: int = 2,
        include_bias: bool = False,
        interaction_only: bool = False,
    ) -> "DataProcessingConfigBuilder":
        self._config["polynomial_features"] = {
            "enabled": True,
            "columns": columns,
            "degree": degree,
            "include_bias": include_bias,
            "interaction_only": interaction_only,
        }
        return self

    def standardize(
        self,
        column: str,
        groupby: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["standardize"]["per_column"][column] = {
            "groupby": groupby,
        }
        return self

    def minmax_scale(
        self,
        column: str,
        groupby: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["minmax_scale"]["per_column"][column] = {
            "groupby": groupby,
        }
        return self

    def quantile_transform(
        self,
        column: str,
        output_distribution: str = "normal",
        n_quantiles: Optional[int] = None,
        random_state: int = 42,
        groupby: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        cfg: Dict[str, Any] = {
            "output_distribution": output_distribution,
            "random_state": random_state,
            "groupby": groupby,
        }
        if n_quantiles is not None:
            cfg["n_quantiles"] = n_quantiles
        self._config["quantile_transform"]["per_column"][column] = cfg
        return self

    def power_transform(
        self,
        column: str,
        method: str = "yeo-johnson",
        standardize: bool = True,
        groupby: Optional[List[str]] = None,
    ) -> "DataProcessingConfigBuilder":
        self._config["power_transform"]["per_column"][column] = {
            "method": method,
            "standardize": standardize,
            "groupby": groupby,
        }
        return self

    def build(self) -> Dict[str, Any]:
        return {
            "force_types": dict(self._config["force_types"]),
            "index_columns": list(self._config["index_columns"]),
            "remove_duplicates": dict(self._config["remove_duplicates"]),
            "split": dict(self._config["split"]),
            "missing": {
                "default_numeric": dict(self._config["missing"]["default_numeric"]),
                "default_categorical": dict(self._config["missing"]["default_categorical"]),
                "per_column": {
                    col: dict(cfg) for col, cfg in self._config["missing"]["per_column"].items()
                },
            },
            "drop_rows_if_na": dict(self._config["drop_rows_if_na"]),
            "encoding": {
                "per_column": {
                    col: dict(cfg) for col, cfg in self._config["encoding"]["per_column"].items()
                }
            },
            "log_transform": {
                "per_column": {
                    col: dict(cfg) for col, cfg in self._config["log_transform"]["per_column"].items()
                }
            },
            "binning": {
                "per_column": {
                    col: dict(cfg) for col, cfg in self._config["binning"]["per_column"].items()
                }
            },
            "polynomial_features": dict(self._config["polynomial_features"]),
            "standardize": {
                "per_column": {
                    col: dict(cfg) for col, cfg in self._config["standardize"]["per_column"].items()
                }
            },
            "quantile_transform": {
                "per_column": {
                    col: dict(cfg) for col, cfg in self._config["quantile_transform"]["per_column"].items()
                }
            },
            "power_transform": {
                "per_column": {
                    col: dict(cfg) for col, cfg in self._config["power_transform"]["per_column"].items()
                }
            },
            "minmax_scale": {
                "per_column": {
                    col: dict(cfg) for col, cfg in self._config["minmax_scale"]["per_column"].items()
                }
            },
        }

    def build_processor(
        self,
        df: pd.DataFrame,
        target_col: Optional[str] = None,
        task_type: str = "Classification",
    ) -> "DataProcessingModule":
        return DataProcessingModule(
            df=df,
            target_col=target_col,
            task_type=task_type,
            config=self.build(),
        )

