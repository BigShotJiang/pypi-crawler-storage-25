from scientific_ml_modules.utils.logging_utils import configure_root_logger, get_logger
from scientific_ml_modules.core.eda import ExplanatoryAnalyzer
from scientific_ml_modules.core.processing import DataProcessingModule
from scientific_ml_modules.core.feature_selection import FeatureSelector
from scientific_ml_modules.core.modeling import (
    ModelingOnly,
    ModelingConfigBuilder,
    ModelRunConfig,
    CVConfig,
    TuningConfig,
    BootstrapConfig,
    SavingConfig,
    StackingConfig,
    TrainedModelBundle,
)
from scientific_ml_modules.core.reporting import ModelResultsReporter, ResultsReportingConfigBuilder, ResultsReportingConfig
from scientific_ml_modules.core.xai import ExplainableAIModule, ExplainabilityConfigBuilder, ExplainabilityConfig
from scientific_ml_modules.workflow.unified import UnifiedWorkflowModule, UnifiedWorkflowBuilder, UnifiedWorkflowConfig
from scientific_ml_modules.workflow.deployment import EndToEndScoringArtifact, ScoringArtifactConfigBuilder, ScoringArtifactConfig
from scientific_ml_modules.workflow.module_suite import ModuleSuiteBuilder, ModuleSuiteConfig, ModuleSuiteFactory

UnifiedWorkflow = UnifiedWorkflowModule

configure_root_logger()

__all__ = [
    "ExplanatoryAnalyzer",
    "DataProcessingModule",
    "FeatureSelector",
    "ModelingOnly",
    "ModelingConfigBuilder",
    "ModelRunConfig",
    "CVConfig",
    "TuningConfig",
    "BootstrapConfig",
    "SavingConfig",
    "StackingConfig",
    "TrainedModelBundle",
    "ModelResultsReporter",
    "ResultsReportingConfigBuilder",
    "ResultsReportingConfig",
    "ExplainableAIModule",
    "ExplainabilityConfigBuilder",
    "ExplainabilityConfig",
    "UnifiedWorkflowModule",
    "UnifiedWorkflowBuilder",
    "UnifiedWorkflowConfig",
    "UnifiedWorkflow",
    "EndToEndScoringArtifact",
    "ScoringArtifactConfigBuilder",
    "ScoringArtifactConfig",
    "ModuleSuiteBuilder",
    "ModuleSuiteConfig",
    "ModuleSuiteFactory",
    "configure_root_logger",
    "get_logger",
]

__version__ = "0.1.7"
