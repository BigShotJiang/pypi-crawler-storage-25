from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Literal
from uuid import uuid4

import joblib
import numpy as np
import pandas as pd

from scientific_ml_modules.core.modeling import _all_metrics_from_predictions


@dataclass
class ScoringArtifactConfig:
    model_name: str | None = None
    target_col: str = "target"
    reference_metric_source: Literal["test", "train_oof", "validation_mean", "bootstrap_mean"] = "test"
    save_directory: str = "saved_scoring_artifacts"
    artifact_name: str | None = None
    scale_selected_features: bool = True


class ScoringArtifactConfigBuilder:
    def __init__(self): self._config = ScoringArtifactConfig()
    def model_name(self, value): self._config.model_name = value; return self
    def target_col(self, value): self._config.target_col = str(value); return self
    def reference_metric_source(self, value): self._config.reference_metric_source = value; return self
    def save_directory(self, value): self._config.save_directory = str(value); return self
    def artifact_name(self, value): self._config.artifact_name = None if value is None else str(value); return self
    def scale_selected_features(self, value: bool = True): self._config.scale_selected_features = bool(value); return self
    def build(self): return deepcopy(self._config)


class EndToEndScoringArtifact:
    def __init__(self, config, task_type, processing_module, feature_selector, trained_bundle, raw_input_columns, pre_selection_feature_columns, selected_feature_columns, model_ready_columns, model_ready_fill_values, model_ready_means, model_ready_stds, reference_metric_table, training_model_selection_row=None):
        self.config = deepcopy(config); self.task_type = task_type; self.processing_module = processing_module; self.feature_selector = feature_selector; self.trained_bundle = trained_bundle
        self.raw_input_columns = list(raw_input_columns); self.pre_selection_feature_columns = list(pre_selection_feature_columns); self.selected_feature_columns = list(selected_feature_columns); self.model_ready_columns = list(model_ready_columns)
        self.model_ready_fill_values = model_ready_fill_values.copy(); self.model_ready_means = model_ready_means.copy(); self.model_ready_stds = model_ready_stds.copy(); self.reference_metric_table = reference_metric_table.copy(); self.training_model_selection_row = training_model_selection_row
        self.model_name = trained_bundle.model_name; self.fitted_pipeline = trained_bundle.fitted_pipeline

    @staticmethod
    def builder(): return ScoringArtifactConfigBuilder()
    @staticmethod
    def _default_artifact_name(model_name: str) -> str:
        safe_model = model_name.lower().replace(" ", "_").replace("(", "").replace(")", "")
        return f"{safe_model}_feature_selection_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid4().hex[:8]}"

    @classmethod
    def from_unified_workflow_outputs(cls, outputs: dict[str, Any], config: ScoringArtifactConfig | None = None):
        if config is None: config = ScoringArtifactConfig()
        task_type = outputs["task_type"]; processing_module = outputs["processing"]["module"]; trained_models = outputs["modeling"]["trained_models"]
        model_name = config.model_name or next(iter(trained_models.keys()))
        trained_bundle = trained_models[model_name]
        if "feature_selection" in outputs:
            feature_selector = outputs["feature_selection"]["selector"]
            pre_selection_feature_columns = outputs["feature_selection"]["X_train_input"].columns.tolist()
            selected_feature_columns = outputs["feature_selection"]["X_train_selected"].columns.tolist()
            X_train_model_ready = outputs["feature_selection"]["X_train_selected"].copy()
        else:
            feature_selector = None
            X_train_model_ready = outputs["processing"]["X_train"].copy()
            pre_selection_feature_columns = X_train_model_ready.columns.tolist(); selected_feature_columns = X_train_model_ready.columns.tolist()
        X_train_model_ready = X_train_model_ready.apply(pd.to_numeric, errors='coerce').replace([np.inf,-np.inf], np.nan)
        keep_cols = [c for c in X_train_model_ready.columns if not X_train_model_ready[c].isna().all()]
        X_train_model_ready = X_train_model_ready[keep_cols].copy()
        fill_values = X_train_model_ready.median(numeric_only=True)
        X_train_model_ready = X_train_model_ready.fillna(fill_values).fillna(0.0)
        means = X_train_model_ready.mean(); stds = X_train_model_ready.std(ddof=0).replace(0.0,1.0)
        model_ready_columns = X_train_model_ready.columns.tolist()
        full_metric_table = getattr(trained_bundle, 'full_metric_table', pd.DataFrame())
        training_model_selection_row = getattr(trained_bundle, 'model_selection_row', None)
        return cls(config, task_type, processing_module, feature_selector, trained_bundle, outputs['input_df'].columns.tolist(), pre_selection_feature_columns, selected_feature_columns, model_ready_columns, fill_values, means, stds, full_metric_table, training_model_selection_row)

    def _apply_processing_to_new_data(self, df: pd.DataFrame):
        processor = self.processing_module; work_df = df.copy()
        for col in self.raw_input_columns:
            if col not in work_df.columns: work_df[col] = np.nan
        work_df = work_df[self.raw_input_columns].copy()
        work_df = processor._ensure_row_id(work_df); audit = processor._init_audit(work_df); work_df = processor._apply_force_types(work_df); work_df = processor._apply_index_columns(work_df)
        if hasattr(processor, '_remove_duplicates_before_split'): work_df, audit = processor._remove_duplicates_before_split(work_df, audit)
        y_true = work_df[self.config.target_col].copy() if self.config.target_col in work_df.columns else None
        processed_df, audit = processor._transform_dataset(work_df, audit, dataset_name='future')
        if self.config.target_col in processed_df.columns:
            y_true = processed_df[self.config.target_col].copy(); X_processed = processed_df.drop(columns=[self.config.target_col]).copy()
        else: X_processed = processed_df.copy()
        row_id = getattr(processor, 'ROW_ID', '__row_id__')
        if row_id in X_processed.columns: X_processed = X_processed.drop(columns=[row_id])
        return X_processed, y_true, audit

    def _apply_preselection_alignment(self, X_processed):
        X = X_processed.copy()
        for col in self.pre_selection_feature_columns:
            if col not in X.columns: X[col] = 0.0
        return X[self.pre_selection_feature_columns].copy()

    def _apply_feature_selection(self, X):
        return X.copy() if self.feature_selector is None else self.feature_selector.transform(X)

    def _apply_model_ready_prep(self, X):
        X_model = X.copy()
        for col in self.model_ready_columns:
            if col not in X_model.columns: X_model[col] = np.nan
        X_model = X_model[self.model_ready_columns].copy().apply(pd.to_numeric, errors='coerce').replace([np.inf,-np.inf], np.nan)
        X_model = X_model.fillna(self.model_ready_fill_values).fillna(0.0)
        if self.config.scale_selected_features: X_model = (X_model - self.model_ready_means) / self.model_ready_stds.replace(0.0,1.0)
        return X_model.astype(float)

    def _predict_dataframe(self, X_model_ready, y_true=None):
        pred_df = pd.DataFrame(index=X_model_ready.index)
        if y_true is not None: pred_df['y_true'] = pd.Series(y_true, index=X_model_ready.index)
        pred_df['prediction'] = self.fitted_pipeline.predict(X_model_ready)
        if hasattr(self.fitted_pipeline, 'predict_proba'):
            try:
                proba = self.fitted_pipeline.predict_proba(X_model_ready)
                if proba.ndim == 2:
                    for j in range(proba.shape[1]): pred_df[f'probability_{j}'] = proba[:,j]
            except Exception: pass
        return pred_df

    @staticmethod
    def _extract_proba_from_prediction_df(pred_df):
        proba_cols = [c for c in pred_df.columns if str(c).startswith('probability_')]
        return None if not proba_cols else pred_df[proba_cols].to_numpy()

    def _build_metric_comparison_table(self, future_metric_map):
        if future_metric_map is None: return pd.DataFrame(columns=['metric','reference_source','reference_value','future_value','abs_diff','pct_diff'])
        ref_source = self.config.reference_metric_source; ref_df = self.reference_metric_table.copy()
        if ref_df.empty or 'metric' not in ref_df.columns or ref_source not in ref_df.columns:
            return pd.DataFrame({'metric': list(future_metric_map.keys()), 'reference_source': ref_source, 'reference_value': np.nan, 'future_value': list(future_metric_map.values()), 'abs_diff': np.nan, 'pct_diff': np.nan})
        ref_df = ref_df[['metric', ref_source]].copy().rename(columns={ref_source:'reference_value'})
        fut_df = pd.DataFrame({'metric': list(future_metric_map.keys()), 'future_value': list(future_metric_map.values())})
        out = ref_df.merge(fut_df, on='metric', how='outer'); out['reference_source'] = ref_source
        out['abs_diff'] = (pd.to_numeric(out['future_value'], errors='coerce') - pd.to_numeric(out['reference_value'], errors='coerce')).abs()
        denom = pd.to_numeric(out['reference_value'], errors='coerce').abs().replace(0.0,np.nan)
        out['pct_diff'] = out['abs_diff'] / denom
        return out[['metric','reference_source','reference_value','future_value','abs_diff','pct_diff']].sort_values('metric').reset_index(drop=True)

    def score_dataset(self, df: pd.DataFrame):
        X_processed, y_true, audit = self._apply_processing_to_new_data(df)
        X_preselected = self._apply_preselection_alignment(X_processed)
        X_selected = self._apply_feature_selection(X_preselected)
        X_model_ready = self._apply_model_ready_prep(X_selected)
        prediction_df = self._predict_dataframe(X_model_ready, y_true=y_true)
        metric_map = None; comparison_df = None
        if y_true is not None and 'y_true' in prediction_df.columns:
            proba = self._extract_proba_from_prediction_df(prediction_df)
            labels = None
            estimator = self.fitted_pipeline.named_steps['model'] if hasattr(self.fitted_pipeline,'named_steps') and 'model' in self.fitted_pipeline.named_steps else self.fitted_pipeline
            if hasattr(estimator,'classes_'): labels = list(estimator.classes_)
            metric_map = _all_metrics_from_predictions(task_type=self.task_type, y_true=prediction_df['y_true'], y_pred=prediction_df['prediction'], proba=proba, labels=labels)
            comparison_df = self._build_metric_comparison_table(metric_map)
        summary = {'input_rows': int(len(df)), 'processed_rows': int(len(X_processed)), 'selected_rows': int(len(X_selected)), 'model_ready_rows': int(len(X_model_ready)), 'raw_columns_missing_from_input': [c for c in self.raw_input_columns if c not in df.columns], 'unexpected_input_columns': [c for c in df.columns if c not in self.raw_input_columns], 'model_name': self.model_name, 'task_type': self.task_type}
        return {'summary': summary, 'audit_df': audit, 'X_processed': X_processed, 'X_preselected': X_preselected, 'X_selected': X_selected, 'X_model_ready': X_model_ready, 'prediction_df': prediction_df, 'metric_map': metric_map, 'metric_comparison_df': comparison_df, 'reference_metric_table': self.reference_metric_table.copy(), 'training_model_selection_row': self.training_model_selection_row}

    def save(self, save_directory: str | None = None, artifact_name: str | None = None) -> str:
        final_dir = Path(save_directory or self.config.save_directory); final_dir.mkdir(parents=True, exist_ok=True)
        final_name = artifact_name or self.config.artifact_name or self._default_artifact_name(self.model_name)
        save_path = final_dir / f'{final_name}.joblib'; joblib.dump(self, save_path); return str(save_path)

    @classmethod
    def load(cls, path): return joblib.load(path)


# _SML_DEPLOYMENT_LOGGING_PATCH
from scientific_ml_modules.utils.logging_utils import instrument_method
for _name in ["fit", "save", "load", "predict", "predict_proba", "score_dataframe"]:
    if hasattr(EndToEndScoringArtifact, _name):
        instrument_method(EndToEndScoringArtifact, _name, label=f"DEPLOYMENT:{_name}")

