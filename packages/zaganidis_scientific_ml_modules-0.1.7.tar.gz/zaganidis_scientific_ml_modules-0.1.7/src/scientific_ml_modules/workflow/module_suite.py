from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

import pandas as pd

from scientific_ml_modules.config.eda_builder import ExplanatoryAnalyzerBuilder
from scientific_ml_modules.config.processing_builder import DataProcessingConfigBuilder
from scientific_ml_modules.config.feature_selection_builder import FeatureSelectorBuilder
from scientific_ml_modules.core.modeling import ModelingConfigBuilder, ModelingOnly, ModelRunConfig
from scientific_ml_modules.core.reporting import ResultsReportingConfigBuilder, ModelResultsReporter, ResultsReportingConfig
from scientific_ml_modules.core.xai import ExplainabilityConfigBuilder, ExplainableAIModule, ExplainabilityConfig
from scientific_ml_modules.core.processing import DataProcessingModule
from scientific_ml_modules.core.eda import ExplanatoryAnalyzer
from scientific_ml_modules.core.feature_selection import FeatureSelector


@dataclass
class ModuleSuiteConfig:
    eda_infer_datetime_strings: bool = False
    eda_datetime_inference_threshold: float = 0.8
    eda_groupby_cols: Optional[list[str]] = None
    processing_config: dict[str, Any] | None = None
    feature_selector_init_params: dict[str, Any] | None = None
    feature_selector_fit_params: dict[str, Any] | None = None
    modeling_config: ModelRunConfig | None = None
    results_config: ResultsReportingConfig | None = None
    explainability_config: ExplainabilityConfig | None = None


class ModuleSuiteFactory:
    """Factory that creates module instances using either provided builders or safe defaults."""

    def __init__(self, config: ModuleSuiteConfig):
        self.config = config
        if self.config.processing_config is None:
            self.config.processing_config = DataProcessingConfigBuilder().build()
        if self.config.feature_selector_init_params is None:
            self.config.feature_selector_init_params = {
                "task": "auto",
                "estimator": None,
                "scoring": None,
                "cv": 5,
                "random_state": 42,
                "n_jobs": 1,
                "na_strategy": "error",
            }
        if self.config.feature_selector_fit_params is None:
            self.config.feature_selector_fit_params = {
                "methods": ["mutual_info", "variance", "correlation"],
                "mi_top_k": 20,
                "variance_threshold": 0.0,
                "corr_threshold": 0.95,
                "perm_top_k": 20,
                "perm_n_repeats": 10,
                "sfs_n_features_to_select": "auto",
                "combine_mode": "vote",
                "min_votes": None,
            }
        if self.config.modeling_config is None:
            self.config.modeling_config = ModelingConfigBuilder().build()
        if self.config.results_config is None:
            self.config.results_config = ResultsReportingConfigBuilder().build()
        if self.config.explainability_config is None:
            self.config.explainability_config = ExplainabilityConfigBuilder().build()

    def build_eda(self, df: pd.DataFrame) -> ExplanatoryAnalyzer:
        builder = (
            ExplanatoryAnalyzerBuilder()
            .with_dataframe(df)
            .with_infer_datetime_strings(self.config.eda_infer_datetime_strings)
            .with_datetime_inference_threshold(self.config.eda_datetime_inference_threshold)
        )
        if self.config.eda_groupby_cols is not None:
            builder = builder.with_groupby_cols(self.config.eda_groupby_cols)
        return builder.build()

    def build_processor(
        self,
        df: pd.DataFrame,
        target_col: str | None = None,
        task_type: str = "Classification",
    ) -> DataProcessingModule:
        return DataProcessingModule(
            df=df,
            target_col=target_col,
            task_type=task_type,
            config=self.config.processing_config,
        )

    def build_feature_selector(self, X_train: pd.DataFrame, y_train) -> FeatureSelector:
        init_params = dict(self.config.feature_selector_init_params or {})
        selector = FeatureSelector(
            X_train=X_train,
            y_train=y_train,
            task=init_params.get("task", "auto"),
            estimator=init_params.get("estimator"),
            scoring=init_params.get("scoring"),
            cv=init_params.get("cv", 5),
            random_state=init_params.get("random_state", 42),
            n_jobs=init_params.get("n_jobs", 1),
            na_strategy=init_params.get("na_strategy", "error"),
        )
        return selector

    def fit_feature_selector(self, X_train: pd.DataFrame, y_train) -> FeatureSelector:
        selector = self.build_feature_selector(X_train, y_train)
        selector.fit(**dict(self.config.feature_selector_fit_params or {}))
        return selector

    def build_model_runner(self) -> ModelingOnly:
        return ModelingOnly(config=self.config.modeling_config)

    def build_results_reporter(self, runner: ModelingOnly) -> ModelResultsReporter:
        return ModelResultsReporter.from_runner(runner, config=self.config.results_config)

    def build_explainable_ai(
        self,
        runner: ModelingOnly,
        model_name: str,
        X_train: pd.DataFrame,
        y_train=None,
        X_test: pd.DataFrame | None = None,
        y_test=None,
    ) -> ExplainableAIModule:
        return ExplainableAIModule.from_runner(
            runner=runner,
            model_name=model_name,
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
            y_test=y_test,
            config=self.config.explainability_config,
        )


class ModuleSuiteBuilder:
    def __init__(self):
        self._config = ModuleSuiteConfig(
            processing_config=DataProcessingConfigBuilder().build(),
            modeling_config=ModelingConfigBuilder().build(),
            results_config=ResultsReportingConfigBuilder().build(),
            explainability_config=ExplainabilityConfigBuilder().build(),
        )

    def with_explanatory_builder(self, builder: ExplanatoryAnalyzerBuilder | None):
        if builder is None:
            return self
        self._config.eda_infer_datetime_strings = builder._infer_datetime_strings
        self._config.eda_datetime_inference_threshold = builder._datetime_inference_threshold
        self._config.eda_groupby_cols = None if builder._groupby_cols is None else list(builder._groupby_cols)
        return self

    def with_processing_builder(self, builder: DataProcessingConfigBuilder | None):
        if builder is None:
            return self
        self._config.processing_config = builder.build()
        return self

    def with_feature_selector_builder(self, builder: FeatureSelectorBuilder | None):
        if builder is None:
            return self
        init_params = builder.get_init_params()
        init_params.pop("X_train", None)
        init_params.pop("y_train", None)
        self._config.feature_selector_init_params = init_params
        self._config.feature_selector_fit_params = builder.get_fit_params()
        return self

    def with_modeling_builder(self, builder: ModelingConfigBuilder | None):
        if builder is None:
            return self
        self._config.modeling_config = builder.build()
        return self

    def with_results_builder(self, builder: ResultsReportingConfigBuilder | None):
        if builder is None:
            return self
        self._config.results_config = builder.build()
        return self

    def with_explainability_builder(self, builder: ExplainabilityConfigBuilder | None):
        if builder is None:
            return self
        self._config.explainability_config = builder.build()
        return self

    def build(self) -> ModuleSuiteFactory:
        return ModuleSuiteFactory(config=self._config)
