from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Callable, Literal

import numpy as np
import pandas as pd

from scientific_ml_modules.config.eda_builder import ExplanatoryAnalyzerBuilder
from scientific_ml_modules.config.processing_builder import DataProcessingConfigBuilder
from scientific_ml_modules.core.processing import DataProcessingModule
from scientific_ml_modules.config.feature_selection_builder import FeatureSelectorBuilder
from scientific_ml_modules.core.modeling import ModelingOnly, ModelingConfigBuilder
from scientific_ml_modules.core.reporting import ModelResultsReporter, ResultsReportingConfigBuilder
from scientific_ml_modules.core.xai import ExplainableAIModule, ExplainabilityConfigBuilder


@dataclass
class UnifiedWorkflowConfig:
    target_col: str
    task_type: Literal["auto", "Classification", "Regression"] = "auto"
    eda_builder: Any | None = None
    processing_builder: Any | None = None
    modeling_builder: Any | None = None
    results_builder: Any | None = None
    feature_selector_builder_factory: Callable[[pd.DataFrame, pd.Series, str], Any] | None = None
    explainability_builder_factory: Callable[[str, str, pd.DataFrame], Any] | None = None
    explainability_models: list[str] | None = None
    run_eda: bool = True
    run_processing: bool = True
    run_feature_selection: bool = True
    run_modeling: bool = True
    run_results_reporting: bool = True
    run_explainability: bool = True
    numeric_only_for_feature_selection: bool = True
    cast_selected_features_to_float_for_modeling: bool = True
    logging_enabled: bool = True


class UnifiedWorkflowBuilder:
    def __init__(self):
        self._config = UnifiedWorkflowConfig(target_col="target")

    def target_col(self, value: str): self._config.target_col = str(value); return self
    def task_type(self, value: Literal["auto", "Classification", "Regression"]): self._config.task_type = value; return self
    def eda_builder(self, builder: Any): self._config.eda_builder = builder; return self
    def processing_builder(self, builder: Any): self._config.processing_builder = builder; return self
    def feature_selector_builder_factory(self, factory): self._config.feature_selector_builder_factory = factory; return self
    def modeling_builder(self, builder: Any): self._config.modeling_builder = builder; return self
    def results_builder(self, builder: Any): self._config.results_builder = builder; return self
    def explainability_builder_factory(self, factory): self._config.explainability_builder_factory = factory; return self
    def explainability_models(self, values): self._config.explainability_models = None if values is None else list(values); return self
    def run_eda(self, value: bool = True): self._config.run_eda = bool(value); return self
    def run_processing(self, value: bool = True): self._config.run_processing = bool(value); return self
    def run_feature_selection(self, value: bool = True): self._config.run_feature_selection = bool(value); return self
    def run_modeling(self, value: bool = True): self._config.run_modeling = bool(value); return self
    def run_results_reporting(self, value: bool = True): self._config.run_results_reporting = bool(value); return self
    def run_explainability(self, value: bool = True): self._config.run_explainability = bool(value); return self
    def numeric_only_for_feature_selection(self, value: bool = True): self._config.numeric_only_for_feature_selection = bool(value); return self
    def cast_selected_features_to_float_for_modeling(self, value: bool = True): self._config.cast_selected_features_to_float_for_modeling = bool(value); return self
    def build(self) -> UnifiedWorkflowConfig: return deepcopy(self._config)


class UnifiedWorkflowModule:
    def __init__(self, df: pd.DataFrame, config: UnifiedWorkflowConfig):
        if not isinstance(df, pd.DataFrame):
            raise TypeError("df must be a pandas DataFrame.")
        self.df = df.copy()
        self.config = deepcopy(config)

    @staticmethod
    def builder() -> UnifiedWorkflowBuilder:
        return UnifiedWorkflowBuilder()

    @staticmethod
    def _clone(obj: Any):
        try: return deepcopy(obj)
        except Exception: return obj

    @staticmethod
    def _infer_task_type_from_target(y: pd.Series) -> str:
        y = pd.Series(y).dropna()
        if y.empty: return "Classification"
        if pd.api.types.is_numeric_dtype(y):
            unique_vals = set(pd.Series(y).dropna().unique().tolist())
            if unique_vals.issubset({0, 1}) and len(unique_vals) <= 2:
                return "Classification"
            return "Regression"
        return "Classification"

    def _resolve_task_type(self) -> str:
        if self.config.task_type != "auto": return self.config.task_type
        if self.config.target_col not in self.df.columns:
            raise ValueError(f"target_col='{self.config.target_col}' not found in df.")
        return self._infer_task_type_from_target(self.df[self.config.target_col])

    def _default_eda_builder(self):
        return ExplanatoryAnalyzerBuilder().with_infer_datetime_strings(True).with_datetime_inference_threshold(0.80)

    def _default_processing_builder(self, task_type: str):
        date_cols = [c for c in self.df.columns if c != self.config.target_col and ("date" in c.lower() or "time" in c.lower())]
        categorical_cols = [c for c in self.df.select_dtypes(include=["object", "category", "string"]).columns.tolist() if c != self.config.target_col and c not in date_cols]
        numerical_cols = [c for c in self.df.columns if c not in categorical_cols and c not in date_cols]
        return DataProcessingConfigBuilder().force_types(date_cols=date_cols, categorical_cols=categorical_cols, numerical_cols=numerical_cols).random_split(test_size=0.25, random_state=42).set_default_numeric_missing("median").set_default_categorical_missing("mode")

    def _default_feature_selector_builder_factory(self):
        def factory(X_train: pd.DataFrame, y_train: pd.Series, task_type: str):
            return FeatureSelectorBuilder(X_train, y_train).task(task_type.lower()).na_strategy("median").methods(["mutual_info", "variance", "correlation", "permutation"]).mutual_info(top_k=min(20, X_train.shape[1])).variance(threshold=0.0).correlation(threshold=0.90).permutation(top_k=min(20, X_train.shape[1]), n_repeats=4).combine(mode="vote", min_votes=2)
        return factory

    def _default_modeling_builder(self, task_type: str):
        if task_type == "Classification":
            return ModelingConfigBuilder().task_type("Classification").algorithms(["Logistic regression", "Random forest"]).primary_metric("Balanced accuracy").imbalance_method("class_weight").cv(method="Stratified K-Fold", n_splits=5, shuffle=True, random_state=42).tuning(enabled=True, profile="Light").bootstrap(enabled=True, n_rounds=30, random_state=42).n_jobs_models(1)
        return ModelingConfigBuilder().task_type("Regression").algorithms(["Linear regression", "Random forest"]).primary_metric("Mean absolute error (MAE)").cv(method="K-Fold", n_splits=5, shuffle=True, random_state=42).tuning(enabled=True, profile="Light").bootstrap(enabled=True, n_rounds=30, random_state=42).n_jobs_models(1)

    def _default_results_builder(self, task_type: str):
        if task_type == "Classification":
            return ResultsReportingConfigBuilder().dataset("test").view_mode("both").confusion(enabled=True, include_absolute=True, include_percentage=True, label_order=None, include_reversed_binary_order=True, normalize="true").roc(enabled=True, positive_label=1).precision_recall(enabled=True, positive_label=1)
        return ResultsReportingConfigBuilder().dataset("test").view_mode("both").regression(enabled=True, bins=30, alpha=0.35, marker_size=18)

    def _default_explainability_builder_factory(self, task_type: str):
        linear_like = {"Logistic regression", "Linear regression", "Ridge regression", "Lasso regression", "Elastic net"}
        def factory(model_name: str, resolved_task_type: str, X_train_selected: pd.DataFrame):
            features = X_train_selected.columns.tolist(); singles = features[:min(3, len(features))]; pairs = [(features[0], features[1])] if len(features) >= 2 else []
            if model_name in linear_like:
                return ExplainabilityConfigBuilder().dataset("test").top_n(20).permutation(enabled=False).shap(enabled=False).lime(enabled=False).pdp(enabled=False)
            if resolved_task_type == "Classification":
                return ExplainabilityConfigBuilder().dataset("test").top_n(20).permutation(enabled=True, n_repeats=8, max_samples=200).shap(enabled=True, sample_size=120, background_size=60, class_index=1, max_display=20).lime(enabled=True, sample_index=0, num_features=min(15, X_train_selected.shape[1]), num_samples=2000, class_index=1).pdp(enabled=True, grid_resolution=20, percentiles=(0.05, 0.95), kind="both", single_features=singles, pair_features=pairs)
            return ExplainabilityConfigBuilder().dataset("test").top_n(20).permutation(enabled=True, n_repeats=8, max_samples=200).shap(enabled=True, sample_size=120, background_size=60, max_display=20).lime(enabled=True, sample_index=0, num_features=min(15, X_train_selected.shape[1]), num_samples=2000).pdp(enabled=True, grid_resolution=20, percentiles=(0.05, 0.95), kind="both", single_features=singles, pair_features=pairs)
        return factory

    def _materialize_eda(self):
        builder = self._clone(self.config.eda_builder) if self.config.eda_builder is not None else self._default_eda_builder()
        return builder, builder.with_dataframe(self.df).build()

    def _materialize_processing(self, task_type: str):
        builder = self._clone(self.config.processing_builder) if self.config.processing_builder is not None else self._default_processing_builder(task_type)
        config_obj = builder.build() if hasattr(builder, 'build') else builder
        processor = DataProcessingModule(df=self.df, target_col=self.config.target_col, task_type=task_type, config=config_obj)
        result = processor.process()
        return builder, config_obj, processor, result

    def _materialize_feature_selection(self, X_train, y_train, X_test, task_type: str):
        factory = self.config.feature_selector_builder_factory if self.config.feature_selector_builder_factory is not None else self._default_feature_selector_builder_factory()
        fs_builder = factory(X_train, y_train, task_type)
        selector = fs_builder.build_fit()
        X_train_selected = selector.get_filtered_data().reset_index(drop=True)
        X_test_selected = selector.transform(X_test).reset_index(drop=True)
        if self.config.cast_selected_features_to_float_for_modeling:
            X_train_selected = X_train_selected.astype(float); X_test_selected = X_test_selected.astype(float)
        return fs_builder, selector, X_train_selected, X_test_selected

    def _materialize_modeling(self, X_train_selected, y_train, X_test_selected, y_test, task_type: str):
        builder = self._clone(self.config.modeling_builder) if self.config.modeling_builder is not None else self._default_modeling_builder(task_type)
        model_config = builder.build() if hasattr(builder, 'build') else builder
        runner = ModelingOnly(model_config)
        runner.fit(X_train_selected, y_train.reset_index(drop=True), X_test=X_test_selected, y_test=y_test.reset_index(drop=True))
        return builder, model_config, runner

    def _materialize_results_reporting(self, runner: ModelingOnly, task_type: str):
        builder = self._clone(self.config.results_builder) if self.config.results_builder is not None else self._default_results_builder(task_type)
        report_config = builder.build() if hasattr(builder, 'build') else builder
        reporter = ModelResultsReporter.from_runner(runner, config=report_config)
        outputs = reporter.run_from_config()
        return builder, report_config, reporter, outputs

    def _materialize_explainability(self, runner: ModelingOnly, X_train_selected, y_train, X_test_selected, y_test, task_type: str):
        factory = self.config.explainability_builder_factory if self.config.explainability_builder_factory is not None else self._default_explainability_builder_factory(task_type)
        model_names = self.config.explainability_models if self.config.explainability_models is not None else list(runner.trained_models_.keys())
        out = {}
        for model_name in model_names:
            builder = factory(model_name, task_type, X_train_selected)
            xai_config = builder.build() if hasattr(builder, 'build') else builder
            xai_module = ExplainableAIModule.from_runner(runner=runner, model_name=model_name, X_train=X_train_selected.astype(float), y_train=y_train, X_test=X_test_selected.astype(float), y_test=y_test, config=xai_config)
            out[model_name] = {"builder": builder, "config": xai_config, "module": xai_module, "outputs": xai_module.run_from_config()}
        return out

    def run(self) -> dict[str, Any]:
        outputs = {"input_df": self.df.copy(), "workflow_config": deepcopy(self.config)}
        task_type = self._resolve_task_type(); outputs["task_type"] = task_type
        processing_result = None; X_train_selected = None; X_test_selected = None; runner = None
        if self.config.run_eda:
            b, a = self._materialize_eda(); outputs["eda"] = {"builder": b, "analyzer": a, "numeric_description": a.numeric_description, "categorical_description": a.categorical_description, "datetime_description": a.datetime_description, "missing_summary": a.missing_summary, "numeric_description_grouped": a.numeric_description_grouped, "categorical_description_grouped": a.categorical_description_grouped, "datetime_description_grouped": a.datetime_description_grouped, "missing_summary_grouped": a.missing_summary_grouped}
        if self.config.run_processing:
            pb, pc, pm, processing_result = self._materialize_processing(task_type)
            outputs["processing"] = {"builder": pb, "config": pc, "module": pm, "result": processing_result, "original_df": processing_result.original_df, "original_train_df": processing_result.original_train_df, "original_test_df": processing_result.original_test_df, "processed_train_df": processing_result.processed_train_df, "processed_test_df": processing_result.processed_test_df, "X_train": processing_result.X_train, "X_test": processing_result.X_test, "y_train": processing_result.y_train, "y_test": processing_result.y_test, "combined_audit_df": processing_result.combined_audit_df, "missing_report_before": processing_result.missing_report_before, "missing_report_after_train": processing_result.missing_report_after_train, "missing_report_after_test": processing_result.missing_report_after_test, "strategies_applied": processing_result.strategies_applied}
        if self.config.run_feature_selection:
            X_train_fs = processing_result.X_train.copy(); X_test_fs = processing_result.X_test.copy()
            if self.config.numeric_only_for_feature_selection:
                X_train_fs = X_train_fs.select_dtypes(include=[np.number]).copy(); X_test_fs = X_test_fs[X_train_fs.columns].select_dtypes(include=[np.number]).copy()
            fsb, sel, X_train_selected, X_test_selected = self._materialize_feature_selection(X_train_fs, processing_result.y_train, X_test_fs, task_type)
            outputs["feature_selection"] = {"builder": fsb, "selector": sel, "X_train_input": X_train_fs, "X_test_input": X_test_fs, "X_train_selected": X_train_selected, "X_test_selected": X_test_selected, "selected_columns": sel.get_selected_columns(), "feature_summary": sel.get_feature_summary(), "selection_overview": sel.get_selection_overview(), "selection_matrix": sel.get_method_selection_matrix(), "overlap_jaccard": sel.get_method_overlap_table(metric='jaccard'), "overlap_count": sel.get_method_overlap_table(metric='count'), "correlation_pairs": sel.get_correlation_pairs_table(threshold=0.80), "rank_table_votes": sel.get_rank_table(sort_by='votes')}
        if self.config.run_modeling:
            mb, mc, runner = self._materialize_modeling(X_train_selected, processing_result.y_train, X_test_selected, processing_result.y_test, task_type)
            outputs["modeling"] = {"builder": mb, "config": mc, "runner": runner, "artifacts": runner.get_artifacts(), "trained_models": runner.trained_models_, "model_selection_summary_df": runner.model_selection_summary_df_, "summary_df": runner.summary_df_, "cv_hyperparameter_tables": runner.cv_hyperparameter_tables_, "bootstrap_tables": runner.bootstrap_tables_, "predictions_train": runner.predictions_train_, "predictions_test": runner.predictions_test_, "predictions_train_wide": runner.predictions_train_wide_, "predictions_test_wide": runner.predictions_test_wide_, "confusion_matrices": runner.confusion_matrices_}
        if self.config.run_results_reporting:
            rb, rc, rr, ro = self._materialize_results_reporting(runner, task_type); outputs["results_reporting"] = {"builder": rb, "config": rc, "reporter": rr, "outputs": ro}
        if self.config.run_explainability:
            outputs["explainability"] = self._materialize_explainability(runner, X_train_selected, processing_result.y_train, X_test_selected, processing_result.y_test, task_type)
        return outputs


# _SML_WORKFLOW_LOGGING_PATCH
from scientific_ml_modules.utils.logging_utils import instrument_method
for _name in [
    "_materialize_eda", "_materialize_processing", "_materialize_feature_selection",
    "_materialize_modeling", "_materialize_results_reporting", "_materialize_explainability", "run"
]:
    instrument_method(UnifiedWorkflowModule, _name, label=f"WORKFLOW:{_name}")

