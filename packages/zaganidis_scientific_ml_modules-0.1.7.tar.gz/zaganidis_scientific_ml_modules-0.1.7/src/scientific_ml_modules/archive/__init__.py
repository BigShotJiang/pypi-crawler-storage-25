"""Archived compatibility and transitional material."""
