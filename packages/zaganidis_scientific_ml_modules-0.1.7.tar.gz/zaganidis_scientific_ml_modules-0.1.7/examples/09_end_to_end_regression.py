from __future__ import annotations

import sys
from pathlib import Path
import pandas as pd
import numpy as np
CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
SRC_DIR = PROJECT_ROOT / "src"

for _p in [str(PROJECT_ROOT), str(SRC_DIR), str(CURRENT_DIR)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

from _workflow_shared import make_regression_workflow_dataset, save_fig
from explanatory_builder import ExplanatoryAnalyzerBuilder
from data_processing_builder import DataProcessingConfigBuilder
from feature_selector_builder import FeatureSelectorBuilder
from modeling_only_module import ModelingOnly, ModelingConfigBuilder
from results_reporting_module import ModelResultsReporter, ResultsReportingConfigBuilder
from explainable_ai_module import ExplainableAIModule, ExplainabilityConfigBuilder

DEFAULT_OUTPUT_DIR = Path("workflow_outputs/regression")
XAI_DIR = DEFAULT_OUTPUT_DIR / "explainability"
def _dirs(root: Path) -> dict[str, Path]:
    root = Path(root)
    dirs = {"root": root, "eda": root / "eda", "processing": root / "processing", "feature_selection": root / "feature_selection", "modeling": root / "modeling", "results": root / "results", "xai": root / "xai"}
    for d in dirs.values(): d.mkdir(parents=True, exist_ok=True)
    return dirs


def prepare_selected_features_for_modeling(X_train_sel: pd.DataFrame, X_test_sel: pd.DataFrame, scale: bool = True):
    X_train_model = X_train_sel.copy(); X_test_model = X_test_sel.copy()
    shared_cols = [c for c in X_train_model.columns if c in X_test_model.columns]
    X_train_model = X_train_model[shared_cols].copy().apply(pd.to_numeric, errors="coerce")
    X_test_model = X_test_model[shared_cols].copy().apply(pd.to_numeric, errors="coerce")
    X_train_model = X_train_model.replace([np.inf, -np.inf], np.nan); X_test_model = X_test_model.replace([np.inf, -np.inf], np.nan)
    keep_cols = [c for c in X_train_model.columns if not X_train_model[c].isna().all()]
    X_train_model = X_train_model[keep_cols].copy(); X_test_model = X_test_model[keep_cols].copy()
    med = X_train_model.median(numeric_only=True)
    X_train_model = X_train_model.fillna(med).fillna(0.0); X_test_model = X_test_model.fillna(med).fillna(0.0)
    if scale:
        mu = X_train_model.mean(); sd = X_train_model.std(ddof=0).replace(0.0, 1.0)
        X_train_model = (X_train_model - mu) / sd; X_test_model = (X_test_model - mu) / sd
    return X_train_model.astype(float), X_test_model.astype(float)


def build_processing_config(df: pd.DataFrame):
    return DataProcessingConfigBuilder().force_types(date_cols=["event_date"], categorical_cols=["country", "segment", "note"], numerical_cols=[c for c in df.columns if c.startswith("num_")] + ["target"]).set_default_numeric_missing("median").set_default_categorical_missing("mode").set_missing_for_column("note", strategy="constant", fill_value="UNKNOWN").drop_rows_if_na(enabled=True, subset=["target"]).encode_label("country").encode_onehot("segment").encode_onehot("note").random_split(test_size=0.25, random_state=42).build()


def run_eda(df: pd.DataFrame, out_dir: Path, full_run: bool = True):
    eda = ExplanatoryAnalyzerBuilder().with_dataframe(df).with_groupby_cols(["country", "segment"]).with_infer_datetime_strings(True).build()
    eda.numeric_description.to_csv(out_dir / "numeric_description.csv", index=False); eda.categorical_description.to_csv(out_dir / "categorical_description.csv", index=False); eda.datetime_description.to_csv(out_dir / "datetime_description.csv", index=False); eda.missing_summary.to_csv(out_dir / "missing_summary.csv", index=False)
    miss_df, fig_count, fig_pct = eda.plot_missing_columns(); miss_df.to_csv(out_dir / "missing_positive_columns.csv", index=False); save_fig(fig_count, out_dir / "missing_count.png"); save_fig(fig_pct, out_dir / "missing_pct.png")
    if full_run:
        corr_df, corr_fig = eda.compute_target_correlations(target_col="target", task_type="Regression", top_n=10)
        corr_df.to_csv(out_dir / "target_correlations.csv", index=False); save_fig(corr_fig, out_dir / "target_correlations.png")
    return eda


def run_processing(df: pd.DataFrame, out_dir: Path):
    processor = DataProcessingConfigBuilder().build_processor(df=df, target_col="target", task_type="Regression")
    processor.config = build_processing_config(df)
    result = processor.process()
    result.X_train.to_csv(out_dir / "X_train_processed.csv", index=False); result.X_test.to_csv(out_dir / "X_test_processed.csv", index=False)
    result.y_train.to_frame("target").to_csv(out_dir / "y_train.csv", index=False); result.y_test.to_frame("target").to_csv(out_dir / "y_test.csv", index=False)
    return result


def run_feature_selection(processed_result, out_dir: Path, full_run: bool = True):
    X_train_numeric = processed_result.X_train.select_dtypes(include=["number", "bool"]).copy(); X_test_numeric = processed_result.X_test.select_dtypes(include=["number", "bool"]).copy()
    selector_builder = FeatureSelectorBuilder(X_train_numeric, processed_result.y_train).task("regression").na_strategy("median")
    if full_run:
        selector_builder = selector_builder.methods(["mutual_info", "variance", "correlation", "permutation", "forward", "backward"]).mutual_info(top_k=min(12, X_train_numeric.shape[1])).variance(threshold=0.0).correlation(threshold=0.90).permutation(top_k=min(12, X_train_numeric.shape[1]), n_repeats=3).forward(n_features_to_select=min(8, X_train_numeric.shape[1])).backward(n_features_to_select=min(8, X_train_numeric.shape[1])).combine(mode="vote", min_votes=2)
    else:
        selector_builder = selector_builder.use_light_methods().combine(mode="vote", min_votes=1)
    selector = selector_builder.build_fit()
    selector.get_feature_summary().to_csv(out_dir / "feature_summary.csv", index=False); selector.get_selection_overview().to_csv(out_dir / "selection_overview.csv", index=False)
    save_fig(selector.plot_votes(top_n=20), out_dir / "votes.png"); save_fig(selector.plot_mutual_info(top_n=20), out_dir / "mutual_info.png")
    X_train_sel = selector.get_filtered_data().reset_index(drop=True); X_test_sel = selector.transform(X_test_numeric).reset_index(drop=True)
    X_train_model, X_test_model = prepare_selected_features_for_modeling(X_train_sel, X_test_sel, scale=True)
    X_train_model.to_csv(out_dir / "X_train_selected_model_ready.csv", index=False); X_test_model.to_csv(out_dir / "X_test_selected_model_ready.csv", index=False)
    return selector, X_train_model, X_test_model


def run_modeling(X_train_sel, y_train, X_test_sel, y_test, out_dir: Path, full_run: bool = True):
    runner = ModelingOnly(ModelingConfigBuilder().task_type("Regression").algorithms(["Linear regression", "Random forest"]).primary_metric("Mean absolute error (MAE)").cv(method="K-Fold", n_splits=5 if full_run else 3, shuffle=True, random_state=42).tuning(enabled=full_run, profile="Light").bootstrap(enabled=full_run, n_rounds=30, random_state=42).n_jobs_models(1).build())
    runner.fit(X_train_sel, y_train.reset_index(drop=True), X_test=X_test_sel, y_test=y_test.reset_index(drop=True))
    runner.model_selection_summary_df_.to_csv(out_dir / "model_selection_summary.csv", index=False); runner.summary_df_.to_csv(out_dir / "model_full_summary.csv", index=False)
    runner.predictions_train_wide_.to_csv(out_dir / "predictions_train_wide.csv", index=False); runner.predictions_test_wide_.to_csv(out_dir / "predictions_test_wide.csv", index=False)
    for model_name, df in runner.bootstrap_tables_.items(): df.to_csv(out_dir / f"bootstrap_table_{model_name.lower().replace(' ','_')}.csv", index=False)
    return runner


def run_results_reporting(runner: ModelingOnly, out_dir: Path):
    reporter = ModelResultsReporter.from_runner(runner, ResultsReportingConfigBuilder().dataset("test").models(["Linear regression", "Random forest"]).view_mode("both").regression(enabled=True, bins=30, alpha=0.35, marker_size=18).build())
    rep_out = {}
    avp = reporter.actual_vs_predicted(); rep_out["actual_vs_predicted"] = avp
    rvp = reporter.residuals_vs_predicted(); rep_out["residuals_vs_predicted"] = rvp
    if avp is not None:
        avp["combined_table"].to_csv(out_dir / "actual_vs_predicted_combined_table.csv", index=False)
        save_fig(avp.get("combined_figure"), out_dir / "actual_vs_predicted_combined.png")
        for model_name, df in avp.get("tables_by_model", {}).items():
            df.to_csv(out_dir / f"actual_vs_predicted_{model_name.lower().replace(' ','_')}.csv", index=False)
        for model_name, fig in avp.get("single_figures", {}).items():
            save_fig(fig, out_dir / f"actual_vs_predicted_{model_name.lower().replace(' ','_')}.png")
    if rvp is not None:
        rvp["combined_table"].to_csv(out_dir / "residuals_vs_predicted_combined_table.csv", index=False)
        save_fig(rvp.get("combined_figure"), out_dir / "residuals_vs_predicted_combined.png")
        for model_name, df in rvp.get("tables_by_model", {}).items():
            df.to_csv(out_dir / f"residuals_vs_predicted_{model_name.lower().replace(' ','_')}.csv", index=False)
        for model_name, fig in rvp.get("single_figures", {}).items():
            save_fig(fig, out_dir / f"residuals_vs_predicted_{model_name.lower().replace(' ','_')}.png")
    return rep_out

def run_explainability(
    runner: ModelingOnly,
    X_train_sel: pd.DataFrame,
    y_train: pd.Series,
    X_test_sel: pd.DataFrame,
    y_test: pd.Series,
    out_dir: Path,
    full_run: bool = True,
):
    available_models = list(runner.trained_models_.keys())
    task_type = getattr(runner, "task_type_", None)

    linear_candidates = [
        "Logistic regression",
        "Linear regression",
        "Ridge regression",
        "Lasso regression",
        "Elastic net",
    ]
    tree_candidates = [
        "Random forest",
        "Extra trees",
        "Gradient boosting",
        "Histogram gradient boosting",
        "XGBoost",
    ]

    linear_model_name = next((m for m in linear_candidates if m in available_models), None)
    tree_model_name = next((m for m in tree_candidates if m in available_models), None)

    # ---------------------------------------------------------------------
    # Linear model: coefficients only
    # ---------------------------------------------------------------------
    if linear_model_name is not None:
        coef_config = (
            ExplainabilityConfigBuilder()
            .dataset("test")
            .top_n(20)
            .permutation(enabled=False)
            .shap(enabled=False)
            .lime(enabled=False)
            .pdp(enabled=False)
            .build()
        )

        xai_linear = ExplainableAIModule.from_runner(
            runner=runner,
            model_name=linear_model_name,
            X_train=X_train_sel.astype(float),
            y_train=y_train,
            X_test=X_test_sel.astype(float),
            y_test=y_test,
            config=coef_config,
        )

        try:
            coef_out = xai_linear.coefficients()
            if "table" in coef_out and coef_out["table"] is not None:
                coef_out["table"].to_csv(
                    out_dir / f"{linear_model_name.lower().replace(' ', '_')}_coefficients_table.csv",
                    index=False,
                )
            if "table_top" in coef_out and coef_out["table_top"] is not None:
                coef_out["table_top"].to_csv(
                    out_dir / f"{linear_model_name.lower().replace(' ', '_')}_coefficients_top.csv",
                    index=False,
                )
            if "table_summary" in coef_out and coef_out["table_summary"] is not None:
                coef_out["table_summary"].to_csv(
                    out_dir / f"{linear_model_name.lower().replace(' ', '_')}_coefficients_summary.csv",
                    index=False,
                )
            save_fig(
                coef_out.get("figure"),
                out_dir / f"{linear_model_name.lower().replace(' ', '_')}_coefficients.png",
            )
        except Exception as exc:
            pd.Series({"error": str(exc)}).to_csv(
                out_dir / f"{linear_model_name.lower().replace(' ', '_')}_coefficients_error.csv",
                index=False,
            )

    # ---------------------------------------------------------------------
    # Tree model: full explainability suite
    # ---------------------------------------------------------------------
    if tree_model_name is None:
        return

    tree_features = X_train_sel.columns.tolist()
    pdp_single_features = tree_features[: min(3, len(tree_features))]
    pdp_pair_features = []
    if len(tree_features) >= 2:
        pdp_pair_features.append((tree_features[0], tree_features[1]))

    if task_type == "Classification":
        tree_config = (
            ExplainabilityConfigBuilder()
            .dataset("test")
            .top_n(20)
            .permutation(enabled=True, n_repeats=8, max_samples=200)
            .shap(
                enabled=True,
                sample_size=120,
                background_size=60,
                class_index=1,
                max_display=20,
            )
            .lime(
                enabled=True,
                sample_index=0,
                num_features=min(15, X_train_sel.shape[1]),
                num_samples=2000,
                class_index=1,
            )
            .pdp(
                enabled=True,
                grid_resolution=20,
                percentiles=(0.05, 0.95),
                kind="both",
                single_features=pdp_single_features,
                pair_features=pdp_pair_features,
            )
            .build()
        )
    else:
        tree_config = (
            ExplainabilityConfigBuilder()
            .dataset("test")
            .top_n(20)
            .permutation(enabled=True, n_repeats=8, max_samples=200)
            .shap(
                enabled=True,
                sample_size=120,
                background_size=60,
                max_display=20,
            )
            .lime(
                enabled=True,
                sample_index=0,
                num_features=min(15, X_train_sel.shape[1]),
                num_samples=2000,
            )
            .pdp(
                enabled=True,
                grid_resolution=20,
                percentiles=(0.05, 0.95),
                kind="both",
                single_features=pdp_single_features,
                pair_features=pdp_pair_features,
            )
            .build()
        )

    xai_tree = ExplainableAIModule.from_runner(
        runner=runner,
        model_name=tree_model_name,
        X_train=X_train_sel.astype(float),
        y_train=y_train,
        X_test=X_test_sel.astype(float),
        y_test=y_test,
        config=tree_config,
    )

    safe_tree = tree_model_name.lower().replace(" ", "_")

    # Feature importance
    try:
        fi_out = xai_tree.feature_importance()
        fi_out["table"].to_csv(out_dir / f"{safe_tree}_feature_importance_table.csv", index=False)
        if fi_out.get("table_top") is not None:
            fi_out["table_top"].to_csv(out_dir / f"{safe_tree}_feature_importance_top.csv", index=False)
        save_fig(fi_out.get("figure"), out_dir / f"{safe_tree}_feature_importance.png")
    except Exception as exc:
        pd.Series({"error": str(exc)}).to_csv(
            out_dir / f"{safe_tree}_feature_importance_error.csv",
            index=False,
        )

    # Permutation importance
    try:
        perm_out = xai_tree.permutation_importance()
        perm_out["table"].to_csv(out_dir / f"{safe_tree}_permutation_importance_table.csv", index=False)
        if perm_out.get("table_top") is not None:
            perm_out["table_top"].to_csv(out_dir / f"{safe_tree}_permutation_importance_top.csv", index=False)
        save_fig(perm_out.get("figure"), out_dir / f"{safe_tree}_permutation_importance.png")
    except Exception as exc:
        pd.Series({"error": str(exc)}).to_csv(
            out_dir / f"{safe_tree}_permutation_importance_error.csv",
            index=False,
        )

    # SHAP
    try:
        shap_out = xai_tree.shap_explain()
        shap_out["summary_table"].to_csv(out_dir / f"{safe_tree}_shap_summary_table.csv", index=False)
        if shap_out.get("summary_top") is not None:
            shap_out["summary_top"].to_csv(out_dir / f"{safe_tree}_shap_summary_top.csv", index=False)
        shap_out["values_table"].to_csv(out_dir / f"{safe_tree}_shap_values_table.csv", index=False)
        if shap_out.get("sample_X") is not None:
            shap_out["sample_X"].to_csv(out_dir / f"{safe_tree}_shap_sample_X.csv", index=False)
        save_fig(shap_out.get("bar_figure"), out_dir / f"{safe_tree}_shap_bar.png")
        save_fig(shap_out.get("summary_figure"), out_dir / f"{safe_tree}_shap_summary.png")
    except Exception as exc:
        pd.Series({"error": str(exc)}).to_csv(
            out_dir / f"{safe_tree}_shap_error.csv",
            index=False,
        )

    # LIME
    try:
        lime_out = xai_tree.lime_explain()
        lime_out["table"].to_csv(out_dir / f"{safe_tree}_lime_table.csv", index=False)
        if lime_out.get("instance_X") is not None:
            lime_out["instance_X"].to_csv(out_dir / f"{safe_tree}_lime_instance_X.csv", index=False)
        save_fig(lime_out.get("figure"), out_dir / f"{safe_tree}_lime.png")
    except Exception as exc:
        pd.Series({"error": str(exc)}).to_csv(
            out_dir / f"{safe_tree}_lime_error.csv",
            index=False,
        )

    # PDP single
    for feat in pdp_single_features:
        try:
            pdp_out = xai_tree.pdp_single(feat)
            pdp_out["table_average"].to_csv(
                out_dir / f"{safe_tree}_pdp_single_average_{feat}.csv",
                index=False,
            )
            if pdp_out.get("table_individual") is not None:
                pdp_out["table_individual"].to_csv(
                    out_dir / f"{safe_tree}_pdp_single_individual_{feat}.csv",
                    index=False,
                )
            save_fig(
                pdp_out.get("figure"),
                out_dir / f"{safe_tree}_pdp_single_{feat}.png",
            )
        except Exception as exc:
            pd.Series({"error": str(exc)}).to_csv(
                out_dir / f"{safe_tree}_pdp_single_error_{feat}.csv",
                index=False,
            )

    # PDP pair
    for feat1, feat2 in pdp_pair_features:
        key = f"{feat1}__{feat2}"
        try:
            pdp_pair_out = xai_tree.pdp_pair(feat1, feat2)
            pdp_pair_out["table"].to_csv(
                out_dir / f"{safe_tree}_pdp_pair_{key}.csv",
                index=False,
            )
            save_fig(
                pdp_pair_out.get("figure"),
                out_dir / f"{safe_tree}_pdp_pair_{key}.png",
            )
        except Exception as exc:
            pd.Series({"error": str(exc)}).to_csv(
                out_dir / f"{safe_tree}_pdp_pair_error_{key}.csv",
                index=False,
            )

def main(output_dir: str | Path | None = None, n_samples: int = 600, seed: int = 123, full_run: bool = True):
    dirs = _dirs(Path(output_dir) if output_dir is not None else DEFAULT_OUTPUT_DIR)
    df = make_regression_workflow_dataset(n_samples=n_samples, random_state=seed)
    df.to_csv(dirs["root"] / "raw_dataset.csv", index=False)
    run_eda(df, dirs["eda"], full_run=full_run)
    processed = run_processing(df, dirs["processing"])
    selector, X_train_sel, X_test_sel = run_feature_selection(processed, dirs["feature_selection"], full_run=full_run)
    runner = run_modeling(X_train_sel, processed.y_train, X_test_sel, processed.y_test, dirs["modeling"], full_run=full_run)
    run_results_reporting(runner, dirs["results"])
    run_explainability(runner, X_train_sel, processed.y_train, X_test_sel, processed.y_test, dirs["xai"], full_run=full_run)
    summary = {"raw_shape": df.shape, "processed_train_shape": processed.X_train.shape, "processed_test_shape": processed.X_test.shape, "selected_train_shape": X_train_sel.shape, "selected_test_shape": X_test_sel.shape, "selected_columns": selector.get_selected_columns(), "trained_models": list(runner.trained_models_.keys()), "output_dir": str(dirs["root"].resolve())}
    pd.Series(summary).to_json(dirs["root"] / "run_summary.json", indent=2)
    return summary


if __name__ == "__main__":
    summary = main(); print("Regression workflow completed.")
    for key, value in summary.items(): print(f"{key}: {value}")
