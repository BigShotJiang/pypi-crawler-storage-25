from __future__ import annotations

from pathlib import Path
import sys

CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

import matplotlib
matplotlib.use("Agg")

import numpy as np
import pandas as pd

from data_processing_builder import DataProcessingConfigBuilder
from data_processing_module_core import DataProcessingModule


def make_example_dataset(n_entities: int = 40, n_periods: int = 12, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    rows = []
    countries = np.array(["PL", "DE", "GR", "FR"])
    sectors = np.array(["Tech", "Finance", "Retail", "Energy"])

    date_index = pd.date_range("2022-01-31", periods=n_periods, freq="ME")

    for entity_id in range(1, n_entities + 1):
        country = rng.choice(countries)
        sector = rng.choice(sectors)
        base_sales = rng.normal(150, 40)
        base_assets = rng.normal(220, 60)
        base_price = abs(rng.normal(18, 6)) + 1.0
        target_class = int(rng.random() < 0.32)

        for dt in date_index:
            sales = base_sales + rng.normal(0, 20)
            assets = base_assets + rng.normal(0, 25)
            price = base_price + rng.normal(0, 2.5)
            exposure = rng.gamma(shape=3.0, scale=15.0)
            cashflow = rng.normal(0, 20)
            inventory = rng.normal(60, 15)
            score = rng.normal(650, 80)
            demand = rng.normal(100, 22)
            age = rng.integers(18, 70)
            critical_metric = rng.normal(10, 2)
            drop_me_if_missing = rng.normal(5, 1)
            comment = rng.choice(["good", "review", "watch", "stable", None], p=[0.22, 0.2, 0.18, 0.25, 0.15])

            rows.append(
                {
                    "entity_id": entity_id,
                    "date_col": dt.strftime("%Y-%m-%d"),
                    "country": country,
                    "sector": sector,
                    "sales": sales,
                    "assets": assets,
                    "price": price,
                    "exposure": exposure,
                    "cashflow": cashflow,
                    "inventory": inventory,
                    "score": score,
                    "demand": demand,
                    "age": age,
                    "critical_metric": critical_metric,
                    "drop_me_if_missing": drop_me_if_missing,
                    "comment": comment,
                    "target": target_class,
                }
            )

    df = pd.DataFrame(rows)
    df.insert(0, "record_id", np.arange(1, len(df) + 1))

    # Add controlled missingness for numeric columns.
    for col, frac in {
        "sales": 0.12,
        "assets": 0.08,
        "price": 0.10,
        "exposure": 0.06,
        "cashflow": 0.09,
        "score": 0.05,
    }.items():
        idx = rng.choice(df.index, size=int(len(df) * frac), replace=False)
        df.loc[idx, col] = np.nan

    # Group forward-fill example.
    inv_idx = rng.choice(df.index, size=int(len(df) * 0.18), replace=False)
    df.loc[inv_idx, "inventory"] = np.nan

    # Group-based categorical fill example.
    sec_idx = rng.choice(df.index, size=int(len(df) * 0.10), replace=False)
    df.loc[sec_idx, "sector"] = None

    # Constant fill example.
    cmt_idx = rng.choice(df.index, size=int(len(df) * 0.12), replace=False)
    df.loc[cmt_idx, "comment"] = None

    # Global row-drop example.
    crit_idx = rng.choice(df.index, size=int(len(df) * 0.04), replace=False)
    df.loc[crit_idx, "critical_metric"] = np.nan

    # Per-column row-drop example.
    drop_idx = rng.choice(df.index, size=int(len(df) * 0.05), replace=False)
    df.loc[drop_idx, "drop_me_if_missing"] = np.nan

    # Missing target rows are removed before the split.
    target_missing_idx = rng.choice(df.index, size=max(5, int(len(df) * 0.02)), replace=False)
    df.loc[target_missing_idx, "target"] = np.nan

    # Force some negatives for log transforms.
    neg_sales_idx = rng.choice(df.index, size=int(len(df) * 0.06), replace=False)
    df.loc[neg_sales_idx, "sales"] = df.loc[neg_sales_idx, "sales"].fillna(0) - rng.uniform(2, 10, size=len(neg_sales_idx))
    neg_cf_idx = rng.choice(df.index, size=int(len(df) * 0.25), replace=False)
    df.loc[neg_cf_idx, "cashflow"] = -abs(df.loc[neg_cf_idx, "cashflow"].fillna(0))

    # Duplicate rows for duplicate-removal testing.
    duplicated = df.sample(18, random_state=seed).copy()
    df = pd.concat([df, duplicated], ignore_index=True)

    return df


def build_example_config() -> dict:
    builder = (
        DataProcessingConfigBuilder()
        .force_types(
            date_cols=["date_col"],
            categorical_cols=["country", "sector", "comment"],
            numerical_cols=[
                "record_id",
                "entity_id",
                "sales",
                "assets",
                "price",
                "exposure",
                "cashflow",
                "inventory",
                "score",
                "demand",
                "age",
                "critical_metric",
                "drop_me_if_missing",
                "target",
            ],
        )
        .index_columns(["record_id"])
        .remove_duplicates(enabled=True, subset=["entity_id", "date_col"], keep="first")
        .random_split(test_size=0.25, random_state=42)
        .set_default_numeric_missing("median")
        .set_default_categorical_missing("mode")
        .set_missing_for_column("sales", strategy="group_median", groupby=["country"])
        .set_missing_for_column("assets", strategy="group_mean", groupby=["country"])
        .set_missing_for_column("price", strategy="constant", fill_value=0.0)
        .set_missing_for_column("sector", strategy="group_mode", groupby=["country"])
        .set_missing_for_column("comment", strategy="constant", fill_value="UNKNOWN")
        .set_missing_for_column(
            "inventory",
            strategy="group_ffill",
            groupby=["entity_id"],
            sort_by=["date_col"],
        )
        .set_missing_for_column("drop_me_if_missing", strategy="drop_rows")
        .drop_rows_if_na(enabled=True, subset=["critical_metric"])
        .encode_onehot("sector")
        .encode_label("country")
        .add_log_transform("sales", mode="shift_log1p")
        .add_log_transform("cashflow", mode="signed_log1p")
        .add_binning("age", n_bins=6, mode="cut", labels=False)
        .add_binning("exposure", n_bins=5, mode="qcut", labels=False, groupby=["country"])
        .set_polynomial_features(columns=["score", "demand"], degree=2)
        .standardize("score", groupby=["country"])
        .minmax_scale("price")
        .quantile_transform("exposure", output_distribution="normal", n_quantiles=50)
        .power_transform("assets", method="yeo-johnson", standardize=True)
    )
    return builder.build()


def run_example(output_dir: str | Path = "example_outputs") -> None:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    df = make_example_dataset()
    config = build_example_config()

    processor = DataProcessingModule(
        df=df,
        target_col="target",
        task_type="Classification",
        config=config,
    )
    result = processor.process()

    result.original_df.to_csv(output_dir / "original_df.csv", index=False)
    result.original_train_df.to_csv(output_dir / "original_train_df.csv", index=False)
    result.original_test_df.to_csv(output_dir / "original_test_df.csv", index=False)
    result.processed_train_df.to_csv(output_dir / "processed_train_df.csv", index=False)
    result.processed_test_df.to_csv(output_dir / "processed_test_df.csv", index=False)
    result.X_train.to_csv(output_dir / "X_train.csv", index=False)
    result.X_test.to_csv(output_dir / "X_test.csv", index=False)

    if result.y_train is not None:
        result.y_train.to_frame("target").to_csv(output_dir / "y_train.csv", index=False)
    if result.y_test is not None:
        result.y_test.to_frame("target").to_csv(output_dir / "y_test.csv", index=False)

    result.combined_audit_df.to_csv(output_dir / "combined_audit_df.csv", index=False)
    result.missing_report_before.to_csv(output_dir / "missing_report_before.csv", index=False)
    result.missing_report_after_train.to_csv(output_dir / "missing_report_after_train.csv", index=False)
    result.missing_report_after_test.to_csv(output_dir / "missing_report_after_test.csv", index=False)
    pd.Series(result.strategies_applied, dtype="object").to_json(output_dir / "strategies_applied.json", indent=2)

    fig1 = processor.plot_missing_report(result.missing_report_before, title="Missing Data Before Processing")
    fig2 = processor.plot_missing_comparison(
        result.missing_report_before,
        result.missing_report_after_train,
        result.missing_report_after_test,
    )
    fig3 = processor.plot_split_summary(result.combined_audit_df)

    fig1.savefig(output_dir / "missing_before.png", dpi=200, bbox_inches="tight")
    fig2.savefig(output_dir / "missing_comparison.png", dpi=200, bbox_inches="tight")
    fig3.savefig(output_dir / "split_summary.png", dpi=200, bbox_inches="tight")

    summary = {
        "original_rows": int(len(result.original_df)),
        "original_train_rows": int(len(result.original_train_df)),
        "original_test_rows": int(len(result.original_test_df)),
        "processed_train_rows": int(len(result.processed_train_df)),
        "processed_test_rows": int(len(result.processed_test_df)),
        "x_train_shape": tuple(result.X_train.shape),
        "x_test_shape": tuple(result.X_test.shape),
        "kept_rows": int(result.combined_audit_df[processor.KEEP_COL].fillna(False).sum()),
        "removed_rows": int((~result.combined_audit_df[processor.KEEP_COL].fillna(True)).sum()),
    }
    pd.Series(summary, dtype="object").to_json(output_dir / "run_summary.json", indent=2)

    print("Example run completed.")
    print(f"Outputs saved to: {output_dir.resolve()}")
    for key, value in summary.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    run_example()
