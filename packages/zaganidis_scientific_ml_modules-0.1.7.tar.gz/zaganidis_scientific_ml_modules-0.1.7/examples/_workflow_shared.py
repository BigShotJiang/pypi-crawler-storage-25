from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.datasets import make_classification, make_regression


def save_fig(fig, path: Path) -> None:
    if fig is None:
        return
    fig.savefig(path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    plt.close("all")


def make_classification_workflow_dataset(n_samples: int = 420, random_state: int = 42) -> pd.DataFrame:
    X, y = make_classification(
        n_samples=n_samples,
        n_features=8,
        n_informative=5,
        n_redundant=1,
        weights=[0.62, 0.38],
        class_sep=1.1,
        random_state=random_state,
    )
    rng = np.random.default_rng(random_state)
    df = pd.DataFrame(X, columns=[f"num_{i}" for i in range(X.shape[1])])
    df["country"] = rng.choice(["PL", "DE", "GR"], size=n_samples, p=[0.50, 0.30, 0.20])
    df["segment"] = rng.choice(["Retail", "SME", "Corporate"], size=n_samples, p=[0.5, 0.3, 0.2])
    df["event_date"] = pd.Timestamp("2023-01-01") + pd.to_timedelta(rng.integers(0, 365, size=n_samples), unit="D")
    df["note"] = rng.choice(["ok", "watch", "good", None], size=n_samples, p=[0.35, 0.25, 0.25, 0.15])
    df["target"] = y

    # controlled missingness
    for col, frac in {"num_0": 0.06, "num_2": 0.08, "country": 0.03, "note": 0.10}.items():
        idx = rng.choice(df.index, size=max(1, int(frac * len(df))), replace=False)
        df.loc[idx, col] = np.nan
    return df


def make_regression_workflow_dataset(n_samples: int = 420, random_state: int = 123) -> pd.DataFrame:
    X, y = make_regression(
        n_samples=n_samples,
        n_features=8,
        n_informative=6,
        noise=18.0,
        random_state=random_state,
    )
    rng = np.random.default_rng(random_state)
    df = pd.DataFrame(X, columns=[f"num_{i}" for i in range(X.shape[1])])
    df["country"] = rng.choice(["PL", "DE", "FR"], size=n_samples, p=[0.45, 0.35, 0.20])
    df["segment"] = rng.choice(["Retail", "SME", "Corporate"], size=n_samples, p=[0.45, 0.35, 0.20])
    df["event_date"] = pd.Timestamp("2023-01-01") + pd.to_timedelta(rng.integers(0, 365, size=n_samples), unit="D")
    df["note"] = rng.choice(["ok", "watch", "good", None], size=n_samples, p=[0.35, 0.25, 0.25, 0.15])
    df["target"] = y

    for col, frac in {"num_1": 0.05, "num_3": 0.07, "segment": 0.03, "note": 0.10}.items():
        idx = rng.choice(df.index, size=max(1, int(frac * len(df))), replace=False)
        df.loc[idx, col] = np.nan
    return df
