from __future__ import annotations

from pathlib import Path
import sys

CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

import numpy as np
import pandas as pd
from sklearn.datasets import make_classification, make_regression
from sklearn.model_selection import train_test_split

from feature_selector_builder import FeatureSelectorBuilder
from feature_selector_module import FeatureSelector


OUTPUT_DIR = Path("feature_selector_example_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def build_classification_dataset(random_state: int = 42) -> tuple[pd.DataFrame, pd.Series]:
    X, y = make_classification(
        n_samples=500,
        n_features=10,
        n_informative=5,
        n_redundant=2,
        n_repeated=0,
        n_classes=2,
        weights=[0.65, 0.35],
        class_sep=1.1,
        random_state=random_state,
    )

    df = pd.DataFrame(X, columns=[f"clf_feature_{i}" for i in range(X.shape[1])])

    # engineered columns to create multiple realistic edge cases
    df["clf_corr_1"] = df["clf_feature_0"] * 0.98 + np.random.default_rng(random_state).normal(0, 0.02, size=len(df))
    df["clf_corr_2"] = df["clf_feature_1"] * -0.97 + np.random.default_rng(random_state + 1).normal(0, 0.03, size=len(df))
    df["clf_low_variance"] = 1.0
    df["clf_near_constant"] = np.random.default_rng(random_state + 2).choice([0.0, 1.0], size=len(df), p=[0.98, 0.02])
    df["clf_noise_1"] = np.random.default_rng(random_state + 3).normal(size=len(df))
    df["clf_noise_2"] = np.random.default_rng(random_state + 4).normal(size=len(df))
    df["clf_missing_demo"] = df["clf_feature_2"]
    missing_idx = np.random.default_rng(random_state + 5).choice(len(df), size=25, replace=False)
    df.loc[missing_idx, "clf_missing_demo"] = np.nan

    target = pd.Series(y, name="target")
    return df, target


def build_regression_dataset(random_state: int = 42) -> tuple[pd.DataFrame, pd.Series]:
    X, y = make_regression(
        n_samples=450,
        n_features=10,
        n_informative=6,
        noise=15.0,
        random_state=random_state,
    )

    df = pd.DataFrame(X, columns=[f"reg_feature_{i}" for i in range(X.shape[1])])

    df["reg_corr_1"] = df["reg_feature_0"] * 1.01 + np.random.default_rng(random_state).normal(0, 0.01, size=len(df))
    df["reg_corr_2"] = df["reg_feature_3"] * -0.96 + np.random.default_rng(random_state + 1).normal(0, 0.02, size=len(df))
    df["reg_low_variance"] = 5.0
    df["reg_near_constant"] = np.random.default_rng(random_state + 2).choice([0.0, 1.0], size=len(df), p=[0.985, 0.015])
    df["reg_noise_1"] = np.random.default_rng(random_state + 3).normal(size=len(df))
    df["reg_noise_2"] = np.random.default_rng(random_state + 4).normal(size=len(df))
    df["reg_missing_demo"] = df["reg_feature_4"]
    missing_idx = np.random.default_rng(random_state + 5).choice(len(df), size=20, replace=False)
    df.loc[missing_idx, "reg_missing_demo"] = np.nan

    target = pd.Series(y, name="target")
    return df, target


def save_tables(prefix: str, selector: FeatureSelector) -> None:
    selector.get_feature_summary().to_csv(OUTPUT_DIR / f"{prefix}_feature_summary.csv", index=False)
    selector.get_selection_overview().to_csv(OUTPUT_DIR / f"{prefix}_selection_overview.csv", index=False)
    selector.get_method_selection_matrix().to_csv(OUTPUT_DIR / f"{prefix}_selection_matrix.csv", index=False)
    selector.get_method_overlap_table(metric="jaccard").to_csv(OUTPUT_DIR / f"{prefix}_overlap_jaccard.csv")
    selector.get_method_overlap_table(metric="count").to_csv(OUTPUT_DIR / f"{prefix}_overlap_count.csv")
    selector.get_correlation_pairs_table(threshold=0.80).to_csv(OUTPUT_DIR / f"{prefix}_correlation_pairs.csv", index=False)


def run_classification_examples() -> None:
    print("\n" + "=" * 80)
    print("CLASSIFICATION EXAMPLES")
    print("=" * 80)

    X, y = build_classification_dataset(random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.25,
        stratify=y,
        random_state=42,
    )

    print(f"Classification train shape: {X_train.shape}")
    print(f"Classification test shape : {X_test.shape}")

    # Case 1: builder + fast preset
    builder_fast = (
        FeatureSelectorBuilder(X_train, y_train)
        .task("classification")
        .na_strategy("median")
        .preset_fast()
    )

    selector_fast = builder_fast.build_fit()
    X_test_fast = selector_fast.transform(X_test)

    print("\n[Classification | Builder | Fast preset]")
    print("Selected columns:", selector_fast.get_selected_columns())
    print("Filtered train shape:", selector_fast.get_filtered_data().shape)
    print("Filtered test shape :", X_test_fast.shape)
    print(builder_fast.to_config_frame())
    print(selector_fast.get_selection_overview())

    save_tables("classification_fast", selector_fast)

    # Case 2: direct module + all methods + vote combination
    selector_all = FeatureSelector(
        X_train=X_train,
        y_train=y_train,
        task="classification",
        cv=4,
        random_state=42,
        n_jobs=-1,
        na_strategy="median",
    )
    selector_all.fit(
        methods=["mutual_info", "variance", "correlation", "permutation", "forward", "backward"],
        mi_top_k=12,
        variance_threshold=0.0001,
        corr_threshold=0.90,
        perm_top_k=12,
        perm_n_repeats=3,
        sfs_n_features_to_select=8,
        combine_mode="vote",
        min_votes=2,
    )

    print("\n[Classification | Direct module | All methods + vote]")
    print(selector_all.get_rank_table(sort_by="votes").head(15))
    save_tables("classification_all_methods", selector_all)

    # Case 3: direct module + intersection to show strict combination
    selector_intersection = FeatureSelector(
        X_train=X_train,
        y_train=y_train,
        task="classification",
        cv=4,
        random_state=42,
        n_jobs=-1,
        na_strategy="median",
    )
    selector_intersection.fit(
        methods=["mutual_info", "correlation", "permutation"],
        mi_top_k=10,
        corr_threshold=0.88,
        perm_top_k=10,
        perm_n_repeats=3,
        combine_mode="intersection",
    )

    print("\n[Classification | Intersection combination]")
    print("Selected columns:", selector_intersection.get_selected_columns())
    save_tables("classification_intersection", selector_intersection)

    # Plot examples from the all-method selector
    selector_all.plot_votes(top_n=15)
    selector_all.plot_mutual_info(top_n=15)
    selector_all.plot_permutation_importance(top_n=15)
    selector_all.plot_variance(top_n=15)
    selector_all.plot_selection_counts()
    selector_all.plot_correlation_matrix(columns="selected", max_features=12, annotate=True)
    selector_all.plot_overlap_heatmap(metric="jaccard", annotate=True)
    selector_all.plot_correlation_pairs(threshold=0.80, top_n=15)



def run_regression_examples() -> None:
    print("\n" + "=" * 80)
    print("REGRESSION EXAMPLES")
    print("=" * 80)

    X, y = build_regression_dataset(random_state=123)
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.25,
        random_state=123,
    )

    print(f"Regression train shape: {X_train.shape}")
    print(f"Regression test shape : {X_test.shape}")

    # Case 1: builder + balanced preset
    builder_balanced = (
        FeatureSelectorBuilder(X_train, y_train)
        .task("regression")
        .na_strategy("median")
        .preset_balanced()
    )

    selector_balanced = builder_balanced.build_fit()
    X_test_balanced = selector_balanced.transform(X_test)

    print("\n[Regression | Builder | Balanced preset]")
    print("Selected columns:", selector_balanced.get_selected_columns())
    print("Filtered train shape:", selector_balanced.get_filtered_data().shape)
    print("Filtered test shape :", X_test_balanced.shape)
    print(builder_balanced.to_config_frame())
    print(selector_balanced.get_selection_overview())

    save_tables("regression_balanced", selector_balanced)

    # Case 2: direct module + union to show more permissive combination
    selector_union = FeatureSelector(
        X_train=X_train,
        y_train=y_train,
        task="regression",
        cv=4,
        random_state=123,
        n_jobs=-1,
        na_strategy="median",
    )
    selector_union.fit(
        methods=["mutual_info", "variance", "correlation", "permutation"],
        mi_top_k=12,
        variance_threshold=0.0001,
        corr_threshold=0.90,
        perm_top_k=12,
        perm_n_repeats=3,
        combine_mode="union",
    )

    print("\n[Regression | Direct module | Union combination]")
    print(selector_union.get_rank_table(sort_by="votes").head(15))
    save_tables("regression_union", selector_union)

    # Case 3: custom builder configuration
    custom_builder = (
        FeatureSelectorBuilder(X_train, y_train)
        .task("regression")
        .na_strategy("median")
        .methods(["mutual_info", "correlation", "permutation"])
        .mutual_info(top_k=10)
        .correlation(threshold=0.85)
        .permutation(top_k=10, n_repeats=3)
        .combine(mode="vote", min_votes=2)
    )
    selector_custom = custom_builder.build_fit()

    print("\n[Regression | Custom builder configuration]")
    print(selector_custom.get_selected_columns())
    save_tables("regression_custom_builder", selector_custom)

    # Plot examples from the balanced selector
    selector_balanced.plot_votes(top_n=15)
    selector_balanced.plot_mutual_info(top_n=15)
    selector_balanced.plot_permutation_importance(top_n=15)
    selector_balanced.plot_variance(top_n=15)
    selector_balanced.plot_selection_counts()
    selector_balanced.plot_correlation_matrix(columns="selected", max_features=12, annotate=True)
    selector_balanced.plot_overlap_heatmap(metric="jaccard", annotate=True)
    selector_balanced.plot_correlation_pairs(threshold=0.80, top_n=15)


if __name__ == "__main__":
    print("Running full generated-dataset examples for FeatureSelector...")
    print(f"Tables will be saved under: {OUTPUT_DIR.resolve()}")

    run_classification_examples()
    run_regression_examples()

    print("\nCompleted all example cases.")
