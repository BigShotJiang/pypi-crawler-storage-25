from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
SRC_DIR = PROJECT_ROOT / "src"

for _p in [str(PROJECT_ROOT), str(SRC_DIR), str(CURRENT_DIR)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

from _workflow_shared import make_classification_workflow_dataset, make_regression_workflow_dataset, save_fig
from unified_workflow_module import UnifiedWorkflowBuilder, UnifiedWorkflowModule
from modeling_only_module import ModelingConfigBuilder
from results_reporting_module import ResultsReportingConfigBuilder
from deployment_scoring_module import EndToEndScoringArtifact, ScoringArtifactConfigBuilder

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "unified_workflow_outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def _save_reporting_outputs(outputs: dict, outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    report = outputs.get("results_reporting", {}).get("outputs", {})
    if not report:
        return

    for section_name, section_obj in report.items():
        if not isinstance(section_obj, dict):
            continue
        if "combined_figure" in section_obj:
            save_fig(section_obj.get("combined_figure"), outdir / f"{section_name}_combined.png")
        if "combined_figure_absolute_standard" in section_obj:
            save_fig(section_obj.get("combined_figure_absolute_standard"), outdir / f"{section_name}_combined_abs_standard.png")
        if "combined_figure_percentage_standard" in section_obj:
            save_fig(section_obj.get("combined_figure_percentage_standard"), outdir / f"{section_name}_combined_pct_standard.png")
        if "combined_figure_absolute_reversed" in section_obj:
            save_fig(section_obj.get("combined_figure_absolute_reversed"), outdir / f"{section_name}_combined_abs_reversed.png")
        if "combined_figure_percentage_reversed" in section_obj:
            save_fig(section_obj.get("combined_figure_percentage_reversed"), outdir / f"{section_name}_combined_pct_reversed.png")

        if "tables_by_model" in section_obj:
            for model_name, df in section_obj["tables_by_model"].items():
                if isinstance(df, pd.DataFrame):
                    safe = model_name.lower().replace(" ", "_")
                    df.to_csv(outdir / f"{section_name}_{safe}.csv", index=False)
        if "single_figures" in section_obj:
            for model_name, fig in section_obj["single_figures"].items():
                safe = model_name.lower().replace(" ", "_")
                save_fig(fig, outdir / f"{section_name}_{safe}.png")

        if section_name == "confusion_matrices" and "per_model" in section_obj:
            for model_name, model_obj in section_obj["per_model"].items():
                safe = model_name.lower().replace(" ", "_")
                for key, value in model_obj.items():
                    if isinstance(value, pd.DataFrame):
                        value.to_csv(outdir / f"{section_name}_{safe}_{key}.csv")
                    elif hasattr(value, "savefig"):
                        save_fig(value, outdir / f"{section_name}_{safe}_{key}.png")


def _save_xai_outputs(outputs: dict, outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    explainability = outputs.get("explainability", {})
    for model_name, model_block in explainability.items():
        safe_model = model_name.lower().replace(" ", "_")
        model_dir = outdir / safe_model
        model_dir.mkdir(parents=True, exist_ok=True)
        model_outputs = model_block.get("outputs", {})

        for key in ["feature_importance", "coefficients", "permutation_importance", "shap", "lime"]:
            obj = model_outputs.get(key)
            if not isinstance(obj, dict):
                continue
            for subkey, value in obj.items():
                if isinstance(value, pd.DataFrame):
                    value.to_csv(model_dir / f"{key}_{subkey}.csv", index=False)
                elif hasattr(value, "savefig"):
                    save_fig(value, model_dir / f"{key}_{subkey}.png")

        for block_name in ["pdp_single", "pdp_pair"]:
            block = model_outputs.get(block_name, {})
            if not isinstance(block, dict):
                continue
            for item_name, item_obj in block.items():
                if not isinstance(item_obj, dict):
                    continue
                safe_item = item_name.replace("/", "_").replace(chr(92), "_")
                for subkey, value in item_obj.items():
                    if isinstance(value, pd.DataFrame):
                        value.to_csv(model_dir / f"{block_name}_{safe_item}_{subkey}.csv", index=False)
                    elif hasattr(value, "savefig"):
                        save_fig(value, model_dir / f"{block_name}_{safe_item}_{subkey}.png")


def run_classification_example() -> dict:
    df = make_classification_workflow_dataset(n_samples=240, random_state=42)
    config = (
        UnifiedWorkflowBuilder()
        .target_col("target")
        .task_type("Classification")
        .modeling_builder(
            ModelingConfigBuilder()
            .task_type("Classification")
            .algorithms(["Logistic regression", "Random forest"])
            .primary_metric("Balanced accuracy")
            .imbalance_method("class_weight")
            .cv(method="Stratified K-Fold", n_splits=3, shuffle=True, random_state=42)
            .tuning(enabled=False)
            .bootstrap(enabled=False).n_jobs_models(1)
        )
        .results_builder(
            ResultsReportingConfigBuilder()
            .dataset("test")
            .models(["Logistic regression", "Random forest"])
            .view_mode("combined")
            .confusion(enabled=True, include_absolute=True, include_percentage=True, label_order=[0, 1], include_reversed_binary_order=True, normalize="true")
            .roc(enabled=True, positive_label=1)
            .precision_recall(enabled=True, positive_label=1)
        )
        .run_explainability(True)
        .build()
    )
    outputs = UnifiedWorkflowModule(df=df, config=config).run()
    _save_reporting_outputs(outputs, OUTPUT_DIR / "classification_reporting")
    _save_xai_outputs(outputs, OUTPUT_DIR / "classification_xai")
    artifact = EndToEndScoringArtifact.from_unified_workflow_outputs(
        outputs,
        ScoringArtifactConfigBuilder()
        .model_name("Random forest")
        .target_col("target")
        .reference_metric_source("test")
        .save_directory(str(OUTPUT_DIR / "artifacts"))
        .artifact_name("classification_random_forest_demo")
        .build(),
    )
    artifact_path = artifact.save()
    future_report = artifact.score_dataset(df)
    if future_report.get("metric_comparison_df") is not None:
        future_report["metric_comparison_df"].to_csv(OUTPUT_DIR / "classification_future_metric_comparison.csv", index=False)
    return {"workflow_outputs": outputs, "artifact_path": artifact_path, "future_report": future_report}


def run_regression_example() -> dict:
    df = make_regression_workflow_dataset(n_samples=240, random_state=123)
    config = (
        UnifiedWorkflowBuilder()
        .target_col("target")
        .task_type("Regression")
        .modeling_builder(
            ModelingConfigBuilder()
            .task_type("Regression")
            .algorithms(["Linear regression", "Random forest"])
            .primary_metric("Mean absolute error (MAE)")
            .cv(method="K-Fold", n_splits=3, shuffle=True, random_state=42)
            .tuning(enabled=False)
            .bootstrap(enabled=False).n_jobs_models(1)
        )
        .results_builder(
            ResultsReportingConfigBuilder()
            .dataset("test")
            .models(["Linear regression", "Random forest"])
            .view_mode("combined")
            .regression(enabled=True, bins=20, alpha=0.35, marker_size=16)
        )
        .run_explainability(True)
        .build()
    )
    outputs = UnifiedWorkflowModule(df=df, config=config).run()
    _save_reporting_outputs(outputs, OUTPUT_DIR / "regression_reporting")
    _save_xai_outputs(outputs, OUTPUT_DIR / "regression_xai")
    artifact = EndToEndScoringArtifact.from_unified_workflow_outputs(
        outputs,
        ScoringArtifactConfigBuilder()
        .model_name("Random forest")
        .target_col("target")
        .reference_metric_source("test")
        .save_directory(str(OUTPUT_DIR / "artifacts"))
        .artifact_name("regression_random_forest_demo")
        .build(),
    )
    artifact_path = artifact.save()
    future_report = artifact.score_dataset(df)
    if future_report.get("metric_comparison_df") is not None:
        future_report["metric_comparison_df"].to_csv(OUTPUT_DIR / "regression_future_metric_comparison.csv", index=False)
    return {"workflow_outputs": outputs, "artifact_path": artifact_path, "future_report": future_report}


if __name__ == "__main__":
    cls = run_classification_example()
    reg = run_regression_example()
    print("Unified workflow classification keys:", cls["workflow_outputs"].keys())
    print("Artifact:", cls["artifact_path"])
    print("Unified workflow regression keys:", reg["workflow_outputs"].keys())
    print("Artifact:", reg["artifact_path"])
