
from __future__ import annotations

from pathlib import Path
import sys

CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.datasets import make_classification, make_regression
from sklearn.model_selection import train_test_split

from modeling_only import ModelingOnly, ModelingConfigBuilder
from explainable_ai import ExplainableAIModule, ExplainabilityConfigBuilder
from results_reporting import ModelResultsReporter, ResultsReportingConfigBuilder


OUTPUT_DIR = Path("example_outputs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def save_fig(fig, path: Path):
    if fig is None:
        return
    fig.savefig(path, dpi=160, bbox_inches="tight")
    plt.close(fig)


def run_classification_example():
    X, y = make_classification(
        n_samples=800,
        n_features=8,
        n_informative=5,
        n_redundant=1,
        n_clusters_per_class=2,
        weights=[0.62, 0.38],
        class_sep=1.2,
        random_state=42,
    )
    feature_names = [f"feature_{i}" for i in range(X.shape[1])]
    X = pd.DataFrame(X, columns=feature_names)
    y = pd.Series(y, name="target")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, stratify=y, random_state=42
    )

    config = (
        ModelingConfigBuilder()
        .task_type("Classification")
        .algorithms(["Logistic regression", "Random forest"])
        .primary_metric("Balanced accuracy")
        .imbalance_method("class_weight")
        .cv(method="Stratified K-Fold", n_splits=5, shuffle=True, random_state=42)
        .tuning(enabled=True, profile="Light")
        .bootstrap(enabled=True, n_rounds=30, random_state=42).n_jobs_models(1)
        .build()
    )

    runner = ModelingOnly(config)
    runner.fit(X_train, y_train, X_test=X_test, y_test=y_test)

    print("\n=== CLASSIFICATION MODEL SELECTION SUMMARY ===")
    print(runner.model_selection_summary_df_)
    print("\n=== CLASSIFICATION FULL SUMMARY ===")
    print(runner.summary_df_.head(15))

    # Explainability: coefficients with logistic regression
    coef_config = (
        ExplainabilityConfigBuilder()
        .dataset("test")
        .top_n(8)
        .permutation(enabled=False)
        .shap(enabled=False)
        .lime(enabled=False)
        .pdp(enabled=False)
        .build()
    )
    xai_logit = ExplainableAIModule.from_runner(
        runner=runner,
        model_name="Logistic regression",
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        config=coef_config,
    )
    coef_out = xai_logit.coefficients()
    save_fig(coef_out["figure"], OUTPUT_DIR / "classification_logit_coefficients.png")

    # Explainability: random forest full xai
    rf_xai_config = (
        ExplainabilityConfigBuilder()
        .dataset("test")
        .top_n(8)
        .permutation(enabled=True, n_repeats=8, max_samples=200)
        .shap(enabled=True, sample_size=120, background_size=60, class_index=1, max_display=8)
        .lime(enabled=True, sample_index=0, num_features=8, num_samples=2000, class_index=1)
        .pdp(
            enabled=True,
            grid_resolution=20,
            percentiles=(0.05, 0.95),
            kind="average",
            single_features=["feature_0", "feature_1"],
            pair_features=[("feature_0", "feature_1")],
        )
        .build()
    )
    xai_rf = ExplainableAIModule.from_runner(
        runner=runner,
        model_name="Random forest",
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        config=rf_xai_config,
    )

    fi_out = xai_rf.feature_importance()
    save_fig(fi_out["figure"], OUTPUT_DIR / "classification_rf_feature_importance.png")

    perm_out = xai_rf.permutation_importance()
    save_fig(perm_out["figure"], OUTPUT_DIR / "classification_rf_permutation_importance.png")

    try:
        shap_out = xai_rf.shap_explain()
        save_fig(shap_out["bar_figure"], OUTPUT_DIR / "classification_rf_shap_bar.png")
        save_fig(shap_out["summary_figure"], OUTPUT_DIR / "classification_rf_shap_summary.png")
    except Exception as exc:
        print(f"SHAP classification skipped: {exc}")

    try:
        lime_out = xai_rf.lime_explain()
        save_fig(lime_out["figure"], OUTPUT_DIR / "classification_rf_lime.png")
    except Exception as exc:
        print(f"LIME classification skipped: {exc}")

    pdp_single_out = xai_rf.pdp_single("feature_0")
    save_fig(pdp_single_out["figure"], OUTPUT_DIR / "classification_rf_pdp_single_feature_0.png")

    pdp_pair_out = xai_rf.pdp_pair("feature_0", "feature_1")
    save_fig(pdp_pair_out["figure"], OUTPUT_DIR / "classification_rf_pdp_pair_feature_0_feature_1.png")

    # Reporting
    report_config = (
        ResultsReportingConfigBuilder()
        .dataset("test")
        .models(["Logistic regression", "Random forest"])
        .view_mode("both")
        .confusion(
            enabled=True,
            include_absolute=True,
            include_percentage=True,
            label_order=[0, 1],
            include_reversed_binary_order=True,
            normalize="true",
        )
        .roc(enabled=True, positive_label=1)
        .precision_recall(enabled=True, positive_label=1)
        .build()
    )
    reporter = ModelResultsReporter.from_runner(runner, config=report_config)
    rep_out = reporter.run_from_config()

    cm_out = rep_out["confusion_matrices"]
    if cm_out is not None:
        save_fig(cm_out["combined_figure_absolute_standard"], OUTPUT_DIR / "classification_confusion_counts_combined.png")
        save_fig(cm_out["combined_figure_percentage_standard"], OUTPUT_DIR / "classification_confusion_pct_combined.png")
        save_fig(cm_out["combined_figure_absolute_reversed"], OUTPUT_DIR / "classification_confusion_counts_reversed_combined.png")
        save_fig(cm_out["combined_figure_percentage_reversed"], OUTPUT_DIR / "classification_confusion_pct_reversed_combined.png")

    roc_out = rep_out["roc_curves"]
    if roc_out is not None:
        save_fig(roc_out["combined_figure"], OUTPUT_DIR / "classification_roc_combined.png")
        for model_name, fig in roc_out["single_figures"].items():
            safe = model_name.lower().replace(" ", "_")
            save_fig(fig, OUTPUT_DIR / f"classification_roc_{safe}.png")

    pr_out = rep_out["precision_recall_curves"]
    if pr_out is not None:
        save_fig(pr_out["combined_figure"], OUTPUT_DIR / "classification_pr_combined.png")
        for model_name, fig in pr_out["single_figures"].items():
            safe = model_name.lower().replace(" ", "_")
            save_fig(fig, OUTPUT_DIR / f"classification_pr_{safe}.png")

    print("\nClassification example finished. Outputs saved to:", OUTPUT_DIR.resolve())


def run_regression_example():
    X, y = make_regression(
        n_samples=800,
        n_features=8,
        n_informative=6,
        noise=20.0,
        random_state=42,
    )
    feature_names = [f"feature_{i}" for i in range(X.shape[1])]
    X = pd.DataFrame(X, columns=feature_names)
    y = pd.Series(y, name="target")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42
    )

    config = (
        ModelingConfigBuilder()
        .task_type("Regression")
        .algorithms(["Linear regression", "Random forest"])
        .primary_metric("Mean absolute error (MAE)")
        .cv(method="K-Fold", n_splits=5, shuffle=True, random_state=42)
        .tuning(enabled=True, profile="Light")
        .bootstrap(enabled=True, n_rounds=30, random_state=42).n_jobs_models(1)
        .build()
    )

    runner = ModelingOnly(config)
    runner.fit(X_train, y_train, X_test=X_test, y_test=y_test)

    print("\n=== REGRESSION MODEL SELECTION SUMMARY ===")
    print(runner.model_selection_summary_df_)
    print("\n=== REGRESSION FULL SUMMARY ===")
    print(runner.summary_df_.head(15))

    # Explainability: coefficients with linear regression
    coef_config = (
        ExplainabilityConfigBuilder()
        .dataset("test")
        .top_n(8)
        .permutation(enabled=False)
        .shap(enabled=False)
        .lime(enabled=False)
        .pdp(enabled=False)
        .build()
    )
    xai_linear = ExplainableAIModule.from_runner(
        runner=runner,
        model_name="Linear regression",
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        config=coef_config,
    )
    coef_out = xai_linear.coefficients()
    save_fig(coef_out["figure"], OUTPUT_DIR / "regression_linear_coefficients.png")

    # Explainability: random forest full xai
    rf_xai_config = (
        ExplainabilityConfigBuilder()
        .dataset("test")
        .top_n(8)
        .permutation(enabled=True, n_repeats=8, max_samples=200)
        .shap(enabled=True, sample_size=120, background_size=60, max_display=8)
        .lime(enabled=True, sample_index=0, num_features=8, num_samples=2000)
        .pdp(
            enabled=True,
            grid_resolution=20,
            percentiles=(0.05, 0.95),
            kind="average",
            single_features=["feature_0", "feature_1"],
            pair_features=[("feature_0", "feature_1")],
        )
        .build()
    )
    xai_rf = ExplainableAIModule.from_runner(
        runner=runner,
        model_name="Random forest",
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        config=rf_xai_config,
    )

    fi_out = xai_rf.feature_importance()
    save_fig(fi_out["figure"], OUTPUT_DIR / "regression_rf_feature_importance.png")

    perm_out = xai_rf.permutation_importance()
    save_fig(perm_out["figure"], OUTPUT_DIR / "regression_rf_permutation_importance.png")

    try:
        shap_out = xai_rf.shap_explain()
        save_fig(shap_out["bar_figure"], OUTPUT_DIR / "regression_rf_shap_bar.png")
        save_fig(shap_out["summary_figure"], OUTPUT_DIR / "regression_rf_shap_summary.png")
    except Exception as exc:
        print(f"SHAP regression skipped: {exc}")

    try:
        lime_out = xai_rf.lime_explain()
        save_fig(lime_out["figure"], OUTPUT_DIR / "regression_rf_lime.png")
    except Exception as exc:
        print(f"LIME regression skipped: {exc}")

    pdp_single_out = xai_rf.pdp_single("feature_0")
    save_fig(pdp_single_out["figure"], OUTPUT_DIR / "regression_rf_pdp_single_feature_0.png")

    pdp_pair_out = xai_rf.pdp_pair("feature_0", "feature_1")
    save_fig(pdp_pair_out["figure"], OUTPUT_DIR / "regression_rf_pdp_pair_feature_0_feature_1.png")

    # Reporting
    report_config = (
        ResultsReportingConfigBuilder()
        .dataset("test")
        .models(["Linear regression", "Random forest"])
        .view_mode("both")
        .regression(enabled=True, bins=30, alpha=0.35, marker_size=18)
        .build()
    )
    reporter = ModelResultsReporter.from_runner(runner, config=report_config)
    rep_out = reporter.run_from_config()

    avp_out = rep_out["actual_vs_predicted"]
    if avp_out is not None:
        save_fig(avp_out["combined_figure"], OUTPUT_DIR / "regression_actual_vs_predicted_combined.png")
        for model_name, fig in avp_out["single_figures"].items():
            safe = model_name.lower().replace(" ", "_")
            save_fig(fig, OUTPUT_DIR / f"regression_actual_vs_predicted_{safe}.png")

    rvp_out = rep_out["residuals_vs_predicted"]
    if rvp_out is not None:
        save_fig(rvp_out["combined_figure"], OUTPUT_DIR / "regression_residuals_vs_predicted_combined.png")
        for model_name, fig in rvp_out["single_figures"].items():
            safe = model_name.lower().replace(" ", "_")
            save_fig(fig, OUTPUT_DIR / f"regression_residuals_vs_predicted_{safe}.png")

    print("\nRegression example finished. Outputs saved to:", OUTPUT_DIR.resolve())


if __name__ == "__main__":
    run_classification_example()
    run_regression_example()
