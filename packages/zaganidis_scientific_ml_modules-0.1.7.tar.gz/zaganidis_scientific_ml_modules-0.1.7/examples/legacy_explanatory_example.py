from __future__ import annotations

from pathlib import Path
import sys

CURRENT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = CURRENT_DIR.parent
SRC_DIR = PROJECT_ROOT / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))
if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))

import matplotlib
matplotlib.use("Agg")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from explanatory_builder import ExplanatoryAnalyzerBuilder


def generate_demo_dataset(n: int = 1200, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    segment = rng.choice(["Retail", "SME", "Corporate", "Private"], size=n, p=[0.42, 0.28, 0.20, 0.10])
    country = rng.choice(["PL", "DE", "FR", "GR", "NL"], size=n, p=[0.40, 0.20, 0.15, 0.15, 0.10])
    channel = rng.choice(["Branch", "Online", "Broker", "Mobile"], size=n, p=[0.22, 0.38, 0.16, 0.24])

    segment_effect_age = {"Retail": -1.0, "SME": 2.0, "Corporate": 4.0, "Private": 6.0}
    segment_effect_income = {"Retail": -8000, "SME": 6000, "Corporate": 18000, "Private": 32000}
    country_effect_balance = {"PL": -3000, "DE": 8000, "FR": 5000, "GR": -5000, "NL": 10000}

    age = rng.normal(42, 10, n) + np.vectorize(segment_effect_age.get)(segment)
    age = np.clip(age, 21, 78)

    income = rng.lognormal(mean=10.7, sigma=0.42, size=n) + np.vectorize(segment_effect_income.get)(segment)
    balance = rng.normal(25000, 14000, n) + np.vectorize(country_effect_balance.get)(country)
    balance = np.clip(balance, -5000, None)

    exposure = rng.gamma(shape=3.6, scale=4500, size=n)
    volatility = rng.beta(2.2, 5.2, size=n) * 0.65
    leverage = np.clip((exposure / (income + 1)) * 18 + rng.normal(0, 0.6, n), 0.2, 12)

    risk_score = (
        580
        + 0.0023 * balance
        + 0.00025 * income
        - 18 * leverage
        - 110 * volatility
        + rng.normal(0, 24, n)
    )
    risk_score = np.clip(risk_score, 250, 850)

    open_date = pd.Timestamp("2021-01-01") + pd.to_timedelta(rng.integers(0, 1200, size=n), unit="D")
    trade_date = open_date + pd.to_timedelta(rng.integers(0, 180, size=n), unit="D")
    trade_date_str = trade_date.strftime("%Y-%m-%d")

    logit = (
        -3.9
        + 0.42 * leverage
        + 3.0 * volatility
        - 0.0044 * (risk_score - 600)
        - 0.000018 * balance
        + 0.000008 * exposure
        + (segment == "Retail").astype(float) * 0.5
        + (country == "GR").astype(float) * 0.3
        + rng.normal(0, 0.30, n)
    )
    prob_default = 1 / (1 + np.exp(-logit))
    target = np.where(rng.random(n) < prob_default, "Default", "Performing")

    df = pd.DataFrame(
        {
            "age": age.round(2),
            "income": income.round(2),
            "balance": balance.round(2),
            "exposure": exposure.round(2),
            "volatility": volatility.round(4),
            "leverage": leverage.round(4),
            "risk_score": risk_score.round(2),
            "segment": segment,
            "country": country,
            "channel": channel,
            "open_date": open_date,
            "trade_date_str": trade_date_str,
            "target": target,
        }
    )

    # Inject missingness in several columns.
    missing_map = {
        "income": 0.07,
        "balance": 0.10,
        "volatility": 0.05,
        "segment": 0.03,
        "trade_date_str": 0.04,
    }
    for col, pct in missing_map.items():
        idx = rng.choice(df.index, size=int(n * pct), replace=False)
        df.loc[idx, col] = np.nan

    return df


def save_figure(fig, path: Path) -> None:
    if fig is not None:
        fig.savefig(path, dpi=160, bbox_inches="tight")
        plt.close(fig)


def main() -> None:
    base_dir = Path(__file__).resolve().parent
    output_dir = base_dir / "example_outputs"
    plot_dir = output_dir / "plots"
    table_dir = output_dir / "tables"

    plot_dir.mkdir(parents=True, exist_ok=True)
    table_dir.mkdir(parents=True, exist_ok=True)

    df = generate_demo_dataset(n=1200, seed=42)
    df.to_csv(table_dir / "generated_dataset.csv", index=False)

    eda = (
        ExplanatoryAnalyzerBuilder()
        .with_dataframe(df)
        .with_infer_datetime_strings(True)
        .with_datetime_inference_threshold(0.80)
        .with_groupby_cols(["country", "segment"])
        .build()
    )

    # Core tables
    eda.numeric_description.to_csv(table_dir / "numeric_description.csv", index=False)
    eda.categorical_description.to_csv(table_dir / "categorical_description.csv", index=False)
    eda.datetime_description.to_csv(table_dir / "datetime_description.csv", index=False)
    eda.missing_summary.to_csv(table_dir / "missing_summary.csv", index=False)

    # Grouped tables
    eda.numeric_description_grouped.to_csv(table_dir / "numeric_description_grouped.csv", index=False)
    eda.categorical_description_grouped.to_csv(table_dir / "categorical_description_grouped.csv", index=False)
    eda.datetime_description_grouped.to_csv(table_dir / "datetime_description_grouped.csv", index=False)
    eda.missing_summary_grouped.to_csv(table_dir / "missing_summary_grouped.csv", index=False)

    # Single column distributions: numeric / categorical / datetime
    fig, stats_df, extra_df, _ = eda.plot_single_column_distribution("income")
    stats_df.to_csv(table_dir / "dist_income_stats.csv", index=False)
    extra_df.to_csv(table_dir / "dist_income_extra.csv", index=False)
    save_figure(fig, plot_dir / "dist_income.png")

    fig, stats_df, extra_df, _ = eda.plot_single_column_distribution("segment")
    stats_df.to_csv(table_dir / "dist_segment_stats.csv", index=False)
    extra_df.to_csv(table_dir / "dist_segment_extra.csv", index=False)
    save_figure(fig, plot_dir / "dist_segment.png")

    fig, stats_df, extra_df, _ = eda.plot_single_column_distribution("trade_date_str")
    stats_df.to_csv(table_dir / "dist_trade_date_stats.csv", index=False)
    extra_df.to_csv(table_dir / "dist_trade_date_extra.csv", index=False)
    save_figure(fig, plot_dir / "dist_trade_date.png")

    # Missing value charts
    missing_plot_df, fig_missing_count, fig_missing_pct = eda.plot_missing_columns()
    missing_plot_df.to_csv(table_dir / "missing_columns_positive_only.csv", index=False)
    save_figure(fig_missing_count, plot_dir / "missing_count.png")
    save_figure(fig_missing_pct, plot_dir / "missing_pct.png")

    # Scatter with marginals
    scatter_df, scatter_stats, scatter_fig = eda.plot_scatter_with_marginals(
        x_col="income",
        y_col="balance",
        sample_size=900,
        bins=25,
    )
    scatter_df.to_csv(table_dir / "scatter_income_balance_data.csv", index=False)
    scatter_stats.to_csv(table_dir / "scatter_income_balance_stats.csv", index=False)
    save_figure(scatter_fig, plot_dir / "scatter_income_balance.png")

    # Target correlations
    corr_target_df, corr_target_fig = eda.compute_target_correlations(
        target_col="target",
        task_type="Classification",
        top_n=10,
    )
    corr_target_df.to_csv(table_dir / "target_correlations.csv", index=False)
    save_figure(corr_target_fig, plot_dir / "target_correlations.png")

    # Pairplot
    pair_df, pair_fig = eda.plot_pairplot(
        selected_numeric_cols=["income", "balance", "risk_score", "leverage"],
        target_col="target",
        task_type="Classification",
        max_rows=600,
    )
    pair_df.to_csv(table_dir / "pairplot_data.csv", index=False)
    save_figure(pair_fig, plot_dir / "pairplot.png")

    # Correlation matrix
    corr_matrix_df, used_cols, corr_matrix_fig = eda.plot_correlation_matrix(
        columns=["income", "balance", "risk_score", "leverage", "volatility"],
        method="pearson",
        annot=True,
    )
    corr_matrix_df.to_csv(table_dir / "correlation_matrix.csv")
    pd.DataFrame({"used_columns": used_cols}).to_csv(table_dir / "correlation_matrix_used_columns.csv", index=False)
    save_figure(corr_matrix_fig, plot_dir / "correlation_matrix.png")

    # QQ plot
    qq_df, qq_stats, qq_fig = eda.plot_qq("income")
    qq_df.to_csv(table_dir / "qq_income_data.csv", index=False)
    qq_stats.to_csv(table_dir / "qq_income_stats.csv", index=False)
    save_figure(qq_fig, plot_dir / "qq_income.png")

    # Grouped numeric distributions: box and violin
    group_df, group_stats, group_fig = eda.plot_grouped_numeric_distribution(
        value_col="income",
        group_col="segment",
        kind="box",
        top_n_groups=10,
        order_by="median",
        show_points=False,
    )
    group_df.to_csv(table_dir / "grouped_box_income_segment_data.csv", index=False)
    group_stats.to_csv(table_dir / "grouped_box_income_segment_stats.csv", index=False)
    save_figure(group_fig, plot_dir / "grouped_box_income_segment.png")

    group_df2, group_stats2, group_fig2 = eda.plot_grouped_numeric_distribution(
        value_col="balance",
        group_col="country",
        kind="violin",
        top_n_groups=10,
        order_by="median",
        show_points=True,
    )
    group_df2.to_csv(table_dir / "grouped_violin_balance_country_data.csv", index=False)
    group_stats2.to_csv(table_dir / "grouped_violin_balance_country_stats.csv", index=False)
    save_figure(group_fig2, plot_dir / "grouped_violin_balance_country.png")

    # Datetime rolling density
    time_df, time_stats, time_fig = eda.plot_datetime_rolling_density(
        datetime_col="trade_date_str",
        freq="W",
        rolling_window=8,
    )
    time_df.to_csv(table_dir / "datetime_rolling_density.csv", index=False)
    time_stats.to_csv(table_dir / "datetime_rolling_density_stats.csv", index=False)
    save_figure(time_fig, plot_dir / "datetime_rolling_density.png")

    # Correlation matrix with p-values
    corr_df, pval_df, used_cols2, corr_pval_fig = eda.plot_correlation_matrix_with_pvalues(
        columns=["income", "balance", "risk_score", "leverage", "volatility"],
        method="pearson",
        annot=True,
        pvalue_annot=True,
        pvalue_vmax=0.10,
    )
    corr_df.to_csv(table_dir / "correlation_matrix_with_pvalues_corr.csv")
    pval_df.to_csv(table_dir / "correlation_matrix_with_pvalues_pval.csv")
    pd.DataFrame({"used_columns": used_cols2}).to_csv(table_dir / "correlation_matrix_with_pvalues_used_columns.csv", index=False)
    save_figure(corr_pval_fig, plot_dir / "correlation_matrix_with_pvalues.png")

    manifest = pd.DataFrame(
        {
            "artifact_type": ["table_dir", "plot_dir", "dataset_rows", "dataset_cols"],
            "value": [str(table_dir), str(plot_dir), len(df), df.shape[1]],
        }
    )
    manifest.to_csv(output_dir / "manifest.csv", index=False)

    print("Example completed successfully.")
    print(f"Outputs saved under: {output_dir}")


if __name__ == "__main__":
    main()
