from __future__ import annotations

import sys
from pathlib import Path


def bootstrap_example_paths(current_file: str) -> None:
    current_dir = Path(current_file).resolve().parent
    project_root = current_dir.parent
    src_dir = project_root / "src"

    for p in [str(project_root), str(src_dir), str(current_dir)]:
        if p not in sys.path:
            sys.path.insert(0, p)
