"""Chat REST endpoints."""

from __future__ import annotations

import base64
import logging

from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(tags=["chat"])

# 25 MB hard cap on uploaded audio — roughly 20 minutes of Opus at 64 kbps,
# far beyond any reasonable push-to-talk session.
_MAX_AUDIO_BYTES = 25 * 1024 * 1024


class ChatRequest(BaseModel):
    message: str
    conversation_id: str | None = None


class ChatResponse(BaseModel):
    conversation_id: str
    message: str


class MessageOut(BaseModel):
    id: str = ""
    role: str
    content: str
    # Incremental-persist flag (2026-04-19). When True, the content is a
    # draft being written by an in-flight chat turn; the UI should render
    # a streaming cursor. Flipped to False once the turn finalizes OR on
    # the next turn start (a stale draft from a crashed previous turn).
    streaming: bool = False
    created_at: str = ""


@router.post("/chat", response_model=ChatResponse)
async def chat(request: Request, body: ChatRequest) -> ChatResponse:
    """Send a message and get a non-streaming response."""
    agent = request.app.state.agent
    memory = request.app.state.memory

    conv_id = body.conversation_id
    if not conv_id or not await memory.conversation_exists(conv_id):
        conv_id = await memory.create_conversation()

    try:
        _provenance = {
            "kind": "chat",
            "source_channel": "rest",
        }
        response = await agent.chat(conv_id, body.message, provenance=_provenance)
    except Exception as exc:
        from agntspace.llm.base import LLMError

        if isinstance(exc, LLMError):
            log.error("LLM error in chat: %s", exc.user_message)
            response = f"⚠ {exc.user_message}"
        else:
            log.exception("Chat error")
            response = f"⚠ Error: {exc!s}"
    return ChatResponse(conversation_id=conv_id, message=response)


@router.get("/conversations")
async def list_conversations(request: Request, include_archived: bool = False) -> list[dict]:
    """List recent conversations. Pass include_archived=true to see archived chats."""
    memory = request.app.state.memory
    return await memory.list_conversations(include_archived=include_archived)


@router.get("/conversations/{conversation_id}/messages")
async def get_messages(
    request: Request, conversation_id: str
) -> list[MessageOut]:
    """Get messages for a conversation, including the streaming flag so
    the UI can render an in-flight cursor on draft assistant rows."""
    memory = request.app.state.memory
    rows = await memory.get_messages_detailed(conversation_id, limit=100)
    return [
        MessageOut(
            id=r["id"],
            role=r["role"],
            content=r["content"],
            streaming=r["streaming"],
            created_at=r["created_at"],
        )
        for r in rows
    ]


@router.get("/conversations/{conversation_id}/status")
async def conversation_status(request: Request, conversation_id: str) -> dict:
    """Return the live in-flight turn state for a conversation, or
    ``{"phase": "idle"}`` when no turn is running.

    The UI polls this every ~2 seconds while a conversation is open so
    it can render a "still working" indicator with the current phase
    (thinking / tool / streaming), the last tool name, and the number
    of tool calls attempted. When the phase flips to ``done``, the UI
    refreshes the messages list to pick up the finalized assistant
    reply. When it flips to ``error``, the UI surfaces the error text.
    """
    registry = getattr(request.app.state, "turn_registry", None)
    if registry is None:
        return {"phase": "idle", "conversation_id": conversation_id}
    state = registry.get_status(conversation_id)
    if state is None:
        return {"phase": "idle", "conversation_id": conversation_id}
    return state.to_dict()


@router.patch("/conversations/{conversation_id}/archive")
async def archive_conversation(request: Request, conversation_id: str) -> dict:
    """Archive a conversation (hides from default list)."""
    memory = request.app.state.memory
    await memory.archive_conversation(conversation_id)
    return {"archived": True}


@router.patch("/conversations/{conversation_id}/unarchive")
async def unarchive_conversation(request: Request, conversation_id: str) -> dict:
    """Restore an archived conversation."""
    memory = request.app.state.memory
    await memory.unarchive_conversation(conversation_id)
    return {"archived": False}


@router.delete("/conversations/{conversation_id}")
async def delete_conversation(request: Request, conversation_id: str) -> dict:
    """Permanently delete a conversation and all its messages."""
    memory = request.app.state.memory
    await memory.delete_conversation(conversation_id)
    return {"deleted": True}


class TranscribeResponse(BaseModel):
    text: str


@router.post("/transcribe", response_model=TranscribeResponse)
async def transcribe(request: Request, audio: UploadFile = File(...)) -> TranscribeResponse:
    """Transcribe a short audio blob recorded by the chat UI.

    Uses the same pipeline as WhatsApp voice notes
    (`agntspace.llm.transcribe.transcribe_audio`) — OpenAI Whisper API when
    a cloud key is available, local `whisper` as a fallback. The UI records
    with MediaRecorder (typically ``audio/webm`` in Chromium-based browsers,
    ``audio/mp4`` in Safari) and sends the blob as multipart form-data.
    """
    audio_bytes = await audio.read()
    if not audio_bytes:
        raise HTTPException(status_code=400, detail="Empty audio upload")
    if len(audio_bytes) > _MAX_AUDIO_BYTES:
        raise HTTPException(status_code=413, detail="Audio file too large (max 25 MB)")

    mimetype = audio.content_type or "audio/webm"

    from agntspace.infra.config import get_settings
    from agntspace.llm.transcribe import NO_BACKEND_AVAILABLE, transcribe_audio

    settings = get_settings()
    api_key = settings.openai_api_key or None

    try:
        audio_b64 = base64.b64encode(audio_bytes).decode("ascii")
        text = await transcribe_audio(audio_b64, mimetype, api_key=api_key)
    except Exception as exc:
        log.exception("Chat transcription failed")
        raise HTTPException(status_code=500, detail=f"Transcription failed: {exc!s}") from exc

    if text == NO_BACKEND_AVAILABLE:
        raise HTTPException(
            status_code=503,
            detail=(
                "No transcription backend available. Install a local backend "
                "with `pip install faster-whisper` (recommended, ~100MB) or "
                "configure an OpenAI API key for cloud transcription."
            ),
        )

    # Backend ran but produced nothing — silent or non-speech audio.
    # Return 200 with empty text so the UI can show a gentle "no speech
    # detected" hint instead of treating it as a backend failure.
    return TranscribeResponse(text=(text or "").strip())
