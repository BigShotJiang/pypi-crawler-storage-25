# ephemerides-spectral CHANGELOG

Per-version change log for the `ephemerides-spectral` PyPI package.
The full project changelog (with pointers into the research notebook
and cross-pollination notes) lives at
[`../CHANGELOG.md`](../CHANGELOG.md).

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

(no entries yet — next entries land after v0.12.0)

## [0.12.0] — 2026-05-05

**Sol Kinematics — per-body orbital state, transparently augmented onto every `time-*` subcommand via `--state`.**

### The framing

Mirror of chess-spectral's `qm_2d.py` / `qm_4d.py` *kinematics* layer (static observables, no time-evolution). The user pointed at the chess-spectral pattern: *"we can check our chess spectral where we have done this."* Translates 1:1 to ephemerides-spectral as v0.12.0 (Kinematics) + v0.13.0 (Dynamics, coming).

`--state` is opt-in (default off, no behavior change for v0.11.x callers); when set, augments any `time-*` bridge result with a `kinematic_state` block carrying orbital velocity, semi-major axis, kinetic energy, and angular momentum for the subcommand's canonical body.

### Validated against published values

Same 9 pins the Phase A audit script (`research/kinematics_dynamics_audit.py`) verifies — agreeing with `_research/kinematics.py` to within 0.02-2.5 %:

| Check | Computed | Expected | Source |
|---|---|---|---|
| Mercury orbital v | 47.87 km/s | 47.36 | NASA fact sheet |
| Earth orbital v | 29.785 km/s | 29.78 | Standard |
| Mars orbital v | 24.13 km/s | 24.07 | NASA fact sheet |
| Jupiter orbital v | 13.06 km/s | 13.07 | NASA fact sheet |
| Pluto orbital v | 4.741 km/s | 4.74 | NASA fact sheet |
| **Jupiter fraction of total L** | **61.5 %** | ~61 % | Standard tables |
| **Outer planets fraction of planet L** | **99.84 %** | ~99 % | Standard tables |

### Added

- `bridge.get_kinematic_state(body, *, jd_tdb=None, frame=...)` → per-body orbital state.
- `bridge.get_full_system_state(...)` → all 38 bodies + system totals.
- `bridge.apply_state_correction(result, subcommand, ...)` — CLI `--state` post-processor.
- `_research/kinematics.py` — `KinematicState` dataclass + Phase B canonical primitive.
- CLI `--state`/`--frame` flags added to every `time-*` subcommand.
- CLI `kinematics --body <X>` / `kinematics --all` standalone subcommand.

### Out of scope (deferred to v0.12.x or v0.13.0)

- Eccentricity / inclination corrections (v0.12.x).
- Position vectors at a specific JD — phase decoder (v0.12.1).
- Acceleration / forces / energies / evolution — v0.13.0 *Dynamics* counterpart.
- C twin (parity smoke marks new methods `python_only`).

### Migration

None. Sol Kinematics is purely additive.

## [0.11.2] — 2026-05-05

**JPL Power-of-Ten audit baseline for the C library.** Audit-only release — no code changes; documents violations and pins counts in CI as a one-way ratchet.

### Why this exists

User suggestion captured during v0.9.3: *"work we should do, maybe its own version path, impose JPL C standard on ourselves."* The C library is targeted at embedded deployment (ESP32, Cortex-M) per the README's "Microcontroller Compatibility" section; JPL Power-of-Ten is the embedded-C gold standard for safety-critical code (Holzmann 2006). The library is small enough (~2.1k LOC across 11 files) that retrofitting is tractable.

### Audit results

102 mechanically-detectable violations across the codebase:

| Rule | Description | Violations |
|---|---|--:|
| 1 | No goto / setjmp / longjmp / recursion | **5** (all goto in `es_hd_state.c` cleanup pattern) |
| 2 | Fixed loop bounds | 0 ✅ |
| 3 | No dynamic allocation after init | **29** (all in `es_hd_state.c` HD pipeline) |
| 4 | Functions ≤ 60 lines | **4** (`es_encode_state` 109; `es_find_syzygies` 99; `es_bind_observer` 86; `es_get_eclipse_probability` 71) |
| 5 | ≥ 2 assertions per function (avg) | **64-assertion shortfall** (0 across 32 functions) |
| 8 | Limited preprocessor | 0 ✅ |
| 9 | No function pointers | 0 ✅ |

Rules 6, 7, 10 are not mechanically detectable; manual audit deferred to v0.11.3+.

### Added

- **`c/JPL_AUDIT.md`** — full human-readable audit document. Rule-by-rule violation breakdown with line numbers, fix paths, and the v0.11.3+ ship roadmap.
- **`tests/test_jpl_audit.py`** — pytest ratchet pinning all mechanically-detectable counts. 11 passing checks + 1 expected-skip (Rule 5 density gate). Same drift-detection pattern as `test_native_version_string_matches_package_version` and `test_readme_freshness.py`.

### Discipline

- Adding a new violation requires updating the pin upward AND explicit justification in the PR description.
- Removing a violation should drop the pin in the same PR; the test emits a warning if a pin can be ratcheted down.
- The Rule 5 density test is gated as `pytest.skip` until v0.11.5; flipping to passing is the gate that proves the v0.11.5 work landed.

### Roadmap

| Version | Focus |
|---|---|
| v0.11.3 | Rule 1 + Rule 3 fixes — refactor `es_hd_state.c` HD pipeline (combined `goto` + `malloc` removal via static / caller-supplied buffers). |
| v0.11.4 | Rule 4 — split the 4 long functions into <60-line factors. |
| v0.11.5 | Rule 5 — add 64+ assertions across the 32 functions; gate behind `#ifndef NDEBUG`. |
| v0.11.6 | Rule 10 — cross-platform pedantic-build CI matrix. |
| v0.11.7 | Rules 6 + 7 — manual variable-scope and return-value audits. |

### Migration

None. Audit-only release.

## [0.11.1] — 2026-05-05

**Research notebook hygiene: backfill §7.4 (STLT) and §7.5 (SPrT); refresh Status banner.** Documentation-only release.

### Why this exists

User noticed during the v0.11.0 SPrT ship: *"just double checking, we added GR to our research notebook too?"* — and the answer was no. Both v0.10.0 STLT and v0.11.0 SPrT shipped with full bridge / CLI / test surfaces but without their notebook §7.x sections. The existing freshness checks (`tests/test_readme_freshness.py`) cover the README — they don't see the research notebook.

### Fixed

- **Notebook §7.4 added — Sol Terra-Luna Time (STLT).** Covers the system-clock framing, the Meton 432 BCE default-epoch choice, the Hipparchus-Babylonian-midpoint convergence story, the `Z₅` algebraic-spine connection, the available alternative epochs, the house-epoch-vs-NASA-LCT framing, and the bridge / CLI surface.
- **Notebook §7.5 added — Sol Proper Time (SPrT).** Covers the per-body diagonal-fiber framing (extending Mercury's existing 43″/century PN diagonal to all 38 bodies), the two leading-order components (`GM/(R·c²)` + `v_orb²/(2c²)`), the validation table against six published values, the user's transparent `--proper` UX, the two-implementation discipline, and the deferred items (rotational kinematic, J₂ oblateness, frame dragging).
- **Notebook Status banner refreshed.** Was stale at v0.7.0; now reads v0.11.1 with the headline-state summary.
- **Notebook Release History block backfilled** with v0.9.2, v0.9.3, v0.10.0, v0.11.0, and v0.11.1 entries (was ending at v0.9.1).

### Discipline

- New task #98 captured: a soft-warning "docs probably need updating" check on PRs. Would have caught the v0.10.0 / v0.11.0 gaps automatically.

### Migration

None. Documentation-only.

## [0.11.0] — 2026-05-05

**Sol Proper Time (SPrT) — gravitational + orbital-kinematic time dilation, applied transparently via `--proper` on every `time-*` subcommand.**

### The framing

The user asked: *"can we simply add `--proper` as a line arg to invoke gravitational time dilation fiber so that users don't even need to know anything extra had to happen in the back end?"*

That's exactly what shipped. `--proper` is opt-in (default off, no behavior change for v0.10.0 callers); when set, it augments any Sol Time bridge result with proper-time-corrected count fields (`<count>_proper`) plus a `proper_time` metadata block. Same physics as Mercury's existing 43″/century PN diagonal correction; SPrT extends the per-body diagonal-fiber treatment to every body in the roster.

### Validated against published values

Six leading-order checks, all within 0.30 % rel err:

| Check | Computed | Expected | Source |
|---|---|---|---|
| Earth surface GR | 6.961e-10 | 6.95e-10 | Ashby 2003 / GPS clock corrections |
| Sun surface GR | 2.123e-6 | 2.12e-6 | Standard solar physics |
| Mars surface GR | 1.400e-10 | 1.40e-10 | Genova et al. 2014 / Curiosity rover |
| Pluto surface GR | 8.136e-12 | 8.15e-12 | New Horizons mission planning |
| Terra orbital kinematic | 4.935e-9 | 4.95e-9 | v_terra² / (2c²) standard |
| Mars-vs-Terra GR difference | 5.561e-10 | 5.56e-10 | The 0.0175 s/Earth-year Curiosity figure |

### Added

**Python API:**
- `bridge.get_proper_time_rate(body, *, lat=None, lon=None, jd_tdb=None, reference="tcb")` — leading-order rate vs. TCB / TDB. Returns `{components: {gr_surface, kinematic_orbital, j2_oblateness, total}, rate_relative_to_reference, ...}`.
- `bridge.compare_proper_times(body_a, body_b, *, reference="tcb")` — rate ratio + drift per Earth-year between two bodies.
- `bridge.apply_proper_correction(result, subcommand, ...)` — post-processor used by the CLI's `--proper` flag.
- `_research/proper_time.py`: `ProperTimeRate` dataclass + the same primitives at the research-module layer.
- `Body.surface_radius_km` field — volumetric mean radius in km, populated for all 38 bodies in the roster.

**CLI:**
- `--proper`, `--lat`, `--lon`, `--reference` flags added uniformly to **every** `time-*` subcommand via the shared `_add_proper_flags` helper. Default off → v0.10.0 callers see no change.
- `time-proper` standalone subcommand for the rate-only query: `--body <X>` for a single body's rate, `--compare-to <Y>` for the two-body drift figure.

**Examples:**
```bash
# Proper-time-corrected Mars Sol Date
ephemerides-spectral time-mars --jd 2451545.0 --proper

# Proper-time-corrected STLT synodic count
ephemerides-spectral time-terra-luna --jd 2451545.0 --epoch meton --proper

# Standalone rate query — Mars vs. TCB
ephemerides-spectral time-proper --body mars

# Two-body comparison — Mars-Terra clock-rate difference
ephemerides-spectral time-proper --body mars --compare-to terra
```

### Discipline

- 32+ new SPrT tests in `tests/test_sprt.py` pin the validation set + every component + the CLI surfaces.
- Three new bridge methods classified `python_only` in `tests/test_parity_smoke.py::PARITY_TARGETS` (C twin queued).
- Manifest regenerated via `codegen/regenerate.py`.
- `proper_time.py` added to `_INCLUDED_MODULES` in `codegen/emit_research_modules.py` so the package codegen picks it up alongside the other research modules.
- `tests/test_readme_freshness.py` invariants caught the v0.10.0-banner-still-says-v0.10.0 drift the moment the version bumped.

### Out of scope (deferred to v0.12.0+)

- Surface rotational kinematic (`ω × R`) — for most bodies the orbital term dominates; for the Sun, rotational dominates.
- J₂ oblateness corrections (~10⁻¹⁵ scale) — `--lat` / `--lon` already accepted for forward compatibility; v0.11.0 ignores them.
- Frame dragging (Lense-Thirring) — ~10⁻¹⁵ at Earth-Moon scale; skip until needed.

### Migration

None. Existing scripts and bridge calls are unchanged. SPrT is purely additive.

## [0.10.0] — 2026-05-05

**Sol Terra-Luna Time (STLT) — system-level clock for the Terra-Luna pair, with Meton's 432 BCE summer solstice as the default epoch.** First Sol Time member with a non-J2000 default anchor.

### The framing

What we call "STLT" is a *system-level* clock — natural unit is the synodic month (29.530589 days), natural references are eclipse cycles (Saros 18.03 yr) and solar-lunar reconciliation cycles (Metonic 19.00 yr). The existing Sol Time series anchored individual bodies (Sol Mars, Sol Venus, ...); STLT anchors the *pair*.

The default epoch is **Meton of Athens's summer solstice on 27 June 432 BCE proleptic Julian** — the calibration anchor of the Metonic cycle, the lunar-solar reconciliation Greek mathematical astronomy was built on. This choice is independently validated by `research/lunar_epoch_candidates.py`: the Hipparchus-Babylonian eclipse-archive midpoint (Mardokempad 721 BCE + Hipparchus 141 BCE) lands within +240 days of Meton's solstice — *same year*, eight months later. Greek astronomy's eclipse archive is centred on Meton's lifetime; the "combo" candidate test confirms his anchor numerically.

This is a **house-epoch design choice** — not a claim to be NASA's eventual Lunar Coordinated Time (LCT) standard, which is still pending standardisation per the April 2024 White House directive. When LCT lands, we add it as a sibling epoch.

### Added

**Python API:**
- `bridge.jd_to_sol_terra_luna_time(jd_tdb, *, epoch="meton")` → `{epoch_name, epoch_jd_tdb, days_since_epoch, synodic_count, synodic_phase, saros_count, saros_phase, metonic_count, metonic_phase, ...}`. The full epoch metadata block carries the abbreviation `"STLT"`, the cycle constants, and the available-epochs roster.
- `bridge.sol_terra_luna_time_to_jd(synodic_count, *, epoch="meton")` — inverse on the synodic-month count.
- `_research/time_scales.py`: `TerraLunaTime` dataclass, `jd_to_terra_luna_time`, `terra_luna_time_to_jd`, plus the constant set: `STLT_SYNODIC_MONTH_DAYS`, `STLT_SAROS_CYCLE_DAYS`, `STLT_METONIC_CYCLE_DAYS`, `STLT_EPOCH_{METON,ANTIKYTHERA,HIPPARCHUS,MARDOKEMPAD,J2000}_JD_TDB`, `STLT_EPOCHS`, `STLT_DEFAULT_EPOCH`.

**CLI:**
- `ephemerides-spectral time-terra-luna --jd <X>` (canonical) — defaults to Meton's epoch; `--epoch {meton,antikythera,hipparchus,mardokempad,j2000}` switches anchors.
- `--synodic-count <N>` inverts: synodic-month count → JD_TDB.

**Available epochs:**
- `meton` (default) — Meton's summer solstice 432 BCE.
- `antikythera` — solar eclipse 23 Aug 205 BCE; Antikythera mechanism Saros-dial anchor (Freeth & Jones 2012).
- `hipparchus` — Hipparchus's lunar eclipse 25 Jan 141 BCE (Almagest VI.5).
- `mardokempad` — Babylonian lunar eclipse 19 Mar 721 BCE (Almagest IV.6); the foundational Babylonian record Hipparchus calibrated against.
- `j2000` — modern reference, Terra-borrowed.

**Research:**
- `research/lunar_epoch_candidates.py` — the Phase A scoring script. Enumerates all five candidates against the spectral kernel (`find_syzygies`) + skyfield ground truth, dumps a markdown report under `figures/lunar_epoch_candidates.md`. Also handles solstice diagnostics with epoch-of-date precession correction (~33° at 2400 yr) so candidate validation isn't dominated by precession noise.

### Fixed

- `bridge.find_syzygies(backend="auto")` was rejected by `_validate_backend` — same latent bug class fixed for `get_breathing_modulation` in v0.9.2 (`SUPPORTED_BACKENDS` doesn't include the `"auto"` sentinel). Now resolves `"auto"` → concrete backend before validation, matching the docstring contract. Caught while writing the research script; fixed in passing.

### Discipline

- Both new bridge methods classified in `tests/test_parity_smoke.py::PARITY_TARGETS` as `python_only` (pure-Python time-scale formula; C twin queued).
- Manifest regenerated via the project's official `codegen/regenerate.py` — no hand-edited SHAs.
- `tests/test_readme_freshness.py` invariants enforced: Status section + banner + CLI body-name examples.

### Migration

None required. Existing scripts and bridge calls unchanged. STLT is purely additive.

## [0.9.3] — 2026-05-05

**PyPI-facing README staleness sweep + CI freshness check.** Docs-only — no API or encoder changes.

### Why now

User flagged the Status and Roadmap sections of the PyPI-facing README as stale. The Status block ended at v0.6.1 — eight versions back. The Roadmap listed Tier 2b "in progress" (shipped in v0.7.0), Sol Venusian/Mercurian Time as upcoming (shipped in v0.8.0; renamed in v0.9.1), and the ITN pathway / `find-tubes` query as upcoming (shipped in v0.8.1). Plus leftover `--body earth` example strings from before the v0.9.0 body-identity rename.

### Fixed (manual sweep)

- **Status section refreshed** with v0.7.0 → v0.9.3 entries. Current marker moved to v0.9.3.
- **Banner added** under the H1: `**Status: v0.9.3 — production-ready.**` Now pinned to `__version__` by the new freshness test.
- **Roadmap section pruned** of shipped items (Tier 2b, Sol Venusian/Mercurian Time, ITN pathway). Items genuinely still ahead retained and reorganized: first-principles per-resonance α, Hyperion follow-up, remaining 4 broken moons, Sol Moon Times, DE441 vs DE442 spectral error signature, heteroclinic-tube extension to `find-tubes`, LTC, Phase 10 resonance coverage, multi-millennium DE441 sweep, Doxygen, bit-serial hardware port.
- **Leftover earth-body CLI example strings** corrected to `terra` (in the `find-tubes` cheat-sheet and in Key Capabilities prose).
- **Phase 9 heading** inverted from `Phase 9 "Breathing" Couplings` → `Phase 9 Adaptive Couplings (a.k.a. "breathing")` matching the v0.9.2 CLI rename. Also updated the Cosine LUT row in the memory-footprint table.
- **Stale "v0.4+ ROADMAP: window search" comment** in the CLI cheat-sheet removed — `find-syzygies` shipped in v0.3.1.

### Added (drift prevention)

`tests/test_readme_freshness.py` enforces three invariants on every PR:

1. **Status section completeness.** Every released version in the package CHANGELOG must have a corresponding bullet under the README's `## Status` section. Reverse direction also enforced (no inventing unreleased versions in the README).
2. **Current-version stamp accuracy.** The `Status: vX.Y.Z` banner under the H1 *and* the `*(current)*` marker in the Status section must both equal `__version__`. Same pattern as `test_native_version_string_matches_package_version`.
3. **CLI body-name validity.** Every body name appearing after a body-flag in a CLI example (`--body NAME`, `--departure NAME`, `--target NAME`, `--pair-a NAME`, `--pair-b NAME`) must be in `SUPPORTED_BODIES`. Catches the v0.9.0 fallout pattern: examples pointing at body names that have been removed from the roster.

What this does *not* enforce: prose accuracy, Roadmap correctness, whether examples are *good* examples. Those stay in human review. Same modular discipline as `test_parity_smoke.py::PARITY_TARGETS` — enumerate the mechanically-checkable truth, fail loudly on drift.

### Migration

None. Docs-only release; no API surface changes.

## [0.9.2] — 2026-05-05

**CLI: `adaptive` is the primary name for Phase 9 state-dependent coupling modulation; `breathing` retained as a hidden synonym.** No public-API changes, no encoder hot-path changes.

### Added

- `ephemerides-spectral adaptive` — primary subcommand. Matches the adaptive-networks vocabulary (Gross & Blasius 2008; adaptive Kuramoto): a state-dependent graph Laplacian whose edge weights co-evolve with node phases.

### Changed

- `ephemerides-spectral breathing` — now registered with `help=argparse.SUPPRESS`. Invisible in `--help` listings, fully functional when typed. Cross-referenced from `adaptive --help`'s epilog and from the toplevel `--help`.

### Fixed

- `resolution --body` default and example strings updated `earth` → `terra` (consistent with the v0.9.0 body roster). `find-tubes` and `local-view` examples likewise corrected. The CLI help and `--body` validation are now self-consistent.
- **Latent bug since v0.8.0:** `get_breathing_modulation(backend="auto")` (its own default) was rejected by the `_validate_backend` check; any caller that didn't pass an explicit `backend=` got an "ok: false" error. `"auto"` is now resolved to a concrete backend before validation, matching the docstring. The CLI's `breathing` (now `adaptive`) subcommand was the principal victim.

### Internal

- Subparser argument registration factored through a shared helper so `adaptive` and `breathing` cannot drift apart.
- `_cmd_breathing` kept as an alias of `_cmd_adaptive` for external imports.

### Migration

None required. Both `adaptive` and `breathing` work; existing scripts unchanged.

## [0.9.1] — 2026-05-05

**Sol Time naming convention overhaul + Sol Terra Time + Sol Luna Time.**

> *"Returning to the giants whose shoulders we stand on. We've always had a lunar orbit and a lunar eclipse. We've all had terrain and terrestrial animals. We're just putting the books back in their dewey decimal spot."*

### Renames (BREAKING)

`Sol Mercurian/Venusian/Plutonian Time` → `Sol Mercury/Venus/Pluto Time`. Function names, dataclasses, and bridge methods all updated. Gas/ice giants (Jovian, Saturnian, Uranian, Neptunian) keep adjective forms — those are deeply established in astronomical tradition.

### New time systems (additive)

- **Sol Terra Time (STT)** — Terra's own surface clock; `bridge.jd_to_sol_terra_time(jd_tdb)`, CLI `time-terra`.
- **Sol Luna Time (SLT)** — Luna's surface clock; `bridge.jd_to_sol_luna_time(jd_tdb)`, CLI `time-luna`. **Distinct from Sol Lunar Time** (`get_lunar_phase`) which gives Luna's phase as observed from Terra.

### Abbreviation field

Each Sol Time bridge return's `epoch:` block now carries `"abbreviation": "STT"` / `"SLT"` / `"SVT"` / etc. per the user's indexing table.

### Tests

111 active tests pass; 5 skipped (4 cibuildwheel + 1 `tier1_skip`).

## [0.9.0] — 2026-05-05

**Body identity rename: `moon` → `luna`, `earth` → `terra`. BREAKING CHANGE.**

The body-identity strings now use Latin proper nouns. The generic English nouns are no longer privileged — `moon` is the category for any natural satellite, `earth` is the substance/ground.

### Migration

Anywhere your code references body identity by string, change:
```python
bridge.body_to_idx["earth"]    # before
bridge.body_to_idx["moon"]     # before
bridge.list_bodies()            # contained "earth"/"moon"
```
to:
```python
bridge.body_to_idx["terra"]    # after
bridge.body_to_idx["luna"]     # after
bridge.list_bodies()            # contains "terra"/"luna"
```

### What stays the same

- Category strings (`category == "moon"`) — moon is the generic category, not Luna's identity
- Adjective forms (`lunar`, `terran`/`terrestrial`)
- JPL/skyfield kernel identifiers (`"earth"`, `"moon"`, 399, 301)
- Encoded phase residues (uint32 output unchanged at the same JD)

### Tests

107 active tests pass; 5 skipped (4 cibuildwheel + 1 `tier1_skip` `find_itn_pathways`).

## [0.8.1] — 2026-05-05

**ITN pathway / Lagrange-tube query — `find-tubes` first cut.** "Surfing the perturbations": closed-form Hohmann transfer-window enumeration mirroring the v0.3.1 `find-syzygies` discipline. Pure-Python; C twin queued for a follow-up minor.

### Added

- `bridge.find_itn_pathways(jd_lo, jd_hi, departure, target, ...)` — Hohmann window enumeration anchored at body launch geometry (mean longitudes from `_data/initial_phases.json`).
- CLI `find-tubes` subcommand.

### Sanity

Earth → Mars at threshold 0.02 over J2000 + 50 yr returns 23 windows; each carries 258.87-d transfer time and 5.594 km/s total Δv. Matches textbook Hohmann to 0.01% / 0.1%.

### Tests

- 3 new immolation tests; 107 active tests pass; 5 skipped (4 cibuildwheel + 1 `tier1_skip` for `find_itn_pathways` pending the C twin).

## [0.8.0] — 2026-05-05

**Sol Symphony Times: 7 new planetary/stellar time systems** — Venus, Mercury, Pluto, Sol (the Sun), Jupiter, Saturn, Neptune join the Sol Time series.

### Added — bridge surface

14 new methods: `jd_to_sol_<body>_time(jd_tdb)` + `sol_<body>_time_to_jd(...)` for each of venusian, mercurian, plutonian, sol_sol, jovian, saturnian, neptunian.

### Added — CLI

7 new subcommands: `time-venus`, `time-mercury`, `time-pluto`, `time-sol`, `time-jupiter`, `time-saturn`, `time-neptune`. Use `--help` on each for the body's quirks (Mercury 3:2 spin-orbit resonance, Venus retrograde, Cassini-revised Saturn rotation, Neptune Voyager-2 System III, etc.).

### Naming hierarchy

Established: `Sol <Adjective> Time` (Sol Mars, Sol Lunar, Sol Uranian, etc.). Future moon ports: `Sol <Parent>-<Body> Time` (Sol Pluto-Charon, Sol Jupiter-Io, etc.).

### ABI

Unchanged at v5. These are pure-Python time-scale formulas; no C twin needed.

### Tests

104 active tests pass (was 84 in v0.7.0); 4 skipped (cibuildwheel-only).

## [0.7.0] — 2026-05-05

**C/Python parity Tier 2b: HD pipeline in C (ABI v5).** The architectural lift announced in v0.6.1 lands. Three new C entry points (`es_encode_state_hd`, `es_bind_observer`, `es_get_eclipse_probability`) plus bridge dispatch on `backend={"auto","bip","c","fpu-ref"}` for `get_local_view` and `get_eclipse_probability`. Parity smoke flips the two `tier2_skip` entries to `parity` — every encoder-touching bridge method now has a paired C path.

### Added

- `bridge.get_local_view(..., backend="auto"|"bip"|"c"|"fpu-ref", D=4096)` and `bridge.get_eclipse_probability(..., backend=..., D=4096)` accept a `backend` param. Result dicts carry a `backend` field.
- Python `_research/bip_hd_lift` module: `encode_state_hd`, `bind_observer`, `syzygy_operator`, `eclipse_probability`. Pure-Python implementations matching the C entry points.
- Native wrappers: `_native_bip.native_encode_state_hd`, `native_bind_observer`, `native_get_eclipse_probability`.

### Behaviour change

Default behaviour of `get_local_view` and `get_eclipse_probability` changes from FPU matrix-expm output to BIP-and-lift output. Different algorithms; **different state vectors**. The bridge contract (`{ok, state_interleaved_f32, probability, ...}`) is unchanged. Pass `backend="fpu-ref"` to get pre-v0.7.0 behaviour.

### Tests

- New `tests/test_hd_parity.py` — 8 byte-parity tests Python BIP-and-lift ↔ C.
- Parity smoke: 22/22 pass; **zero tier_skip entries remaining**.

84 active tests pass; 4 skipped (cibuildwheel-only).

## [0.6.1] — 2026-05-05

**Tier 2a foundation: portable channel-basis PRNG (ABI v4).** Groundwork for the v0.7.0 hyperdimensional-state-in-C work. No bridge surface change; no encoder behaviour change.

### What's in

- New C entry point `es_channel_basis(seed, out, D)` fills a deterministic complex64[D] channel-basis hypervector. New `es_complex64_t` typedef.
- New `_research/portable_prng.py` module: splitmix64 PRNG, bit-identical to the C `es_splitmix64_next`.
- New `tests/test_channel_basis_parity.py`: 10 parity tests pinning byte-identical agreement between Python + C across body seeds + production D.

### Why splitmix64

Reproducing numpy's PCG64-DXSM + uniform conversion exactly in C is brittle (~200 LOC; numpy bumps could break parity). Splitmix64 is six lines, identical across any IEEE-754 platform. Basis byte values change vs v0.6.0; not breaking (no test pinned them).

### Tier 2b (v0.7.0)

Once the foundation is solid, `es_encode_state_hd` + `es_bind_observer` + `es_get_eclipse_probability` land alongside bridge dispatch on `get_local_view` and `get_eclipse_probability`. Parity smoke flips both `tier2_skip` entries to `parity`. See `TIER2_DESIGN.md` in the source repo for the full plan.

### Tests

74 active tests pass; 6 skipped (4 cibuildwheel-only + 2 Tier 2b stubs).

## [0.6.0] — 2026-05-05

**C/Python parity Tier 1 + always-on parity smoke test (ABI v3).** Two encoder-touching bridge methods now have C twins; a new test pins parity as a durable discipline.

### Added — backend dispatch on existing bridge methods

`bridge.get_breathing_modulation(...)` and `bridge.find_syzygies(...)` both accept `backend={"auto", "bip", "c"}` (default `"auto"` picks C when available). Result dicts carry a `backend` field. C and BIP paths produce byte-identical output for the integer fields and float-ULP-equal output for the modulation factor.

### Added — `tests/test_parity_smoke.py`

The always-on parity guard. Every public `bridge.*` function is classified in a `PARITY_TARGETS` table; adding a new method without a parity classification fails CI. Tier 2 entries (`get_local_view`, `get_eclipse_probability`) are flagged as `tier2_skip` until the v0.7.0 hyperdimensional-state-in-C lift lands.

### ABI

`ES_ABI_VERSION` bumped 2 → 3. Encoder hot path is unchanged. Net-new entry points: `es_breathing_modulation`, `es_find_syzygies` (with `es_syzygy_t` struct).

### Notes

- 64 active tests pass on the v0.6.0 build; 6 skipped (4 cibuildwheel-only + 2 Tier 2 stubs).
- No body roster change. With no patches active, `get_system_state(backend="c")` returns the same uint32[38] as v0.5.5 (regression test pinned).

## [0.5.5] — 2026-05-05

**Moon catalog patches (Phase C).** Five LS-fit-vindicated moon patches join `CATALOG_V2`, completing the v0.5.x moon programme.

### Added — `CATALOG_V2`

| name | body | period | amp | shrinkage |
|---|---|---:|---:|---:|
| `dione-1.06yr-diagonal-v2` | dione | 387.04 d | 3.57° | **98.2%** |
| `tethys-0.38yr-diagonal-v2` | tethys | 138.24 d | 3.57° | **93.8%** |
| `enceladus-0.39yr-diagonal-v2` | enceladus | 141.94 d | 3.58° | **98.9%** |
| `titan-0.69yr-diagonal-v2` | titan | 252.74 d | 3.31° | **95.5%** |
| `iapetus-0.22yr-diagonal-v2` | iapetus | 79.34 d | 3.26° | **98.6%** |

Apply via `bridge.apply_patch("dione-1.06yr-diagonal-v2")` etc. Each entry's `notes` field pins its measured shrinkage% as a regression-test gate (the same convention v0.5.2 established for planet patches).

### Hyperion: PARTIAL (75.2%)

Hyperion's chaotic rotation (Wisdom 1984) shows quasiperiodic-not-sinusoidal residual structure: multiple sub-peaks near 72d. Single LS-fit sinusoid hits the methodological ceiling there. Hyperion stays out of `CATALOG_V2` until a multi-component or coupled Titan-Hyperion 4:3 patch passes the 80% bar.

### Notes

- The methodology is now vindicated **twice** on independent body sets: v0.5.2 planets (4 patches at 96-99%), v0.5.5 moons (5 patches at 93-99%). LS-fit amplitudes consistently 2-3× the FFT-bin baselines on both.
- No body roster change. v0.5.5 is purely additive on `CATALOG_V2`.

## [0.5.4] — 2026-05-05

**Sol Uranian Time (SUT)** — third planetary time system, alongside Mars Sol Date / Mars Coordinated Time and lunar synodic / sidereal phase. Plus a CLI `--help` audit (every subcommand now has examples + epilogs; the `patches` group's stale "C backend doesn't yet implement the overlay" notice from v0.4.0 is replaced with the v0.5.2 catalog-V2 reality).

### Added — Sol Uranian Time

- `research/time_scales.py` gains `UranianTime` dataclass + `jd_to_uranian_time(jd_tdb)` + `uranian_time_to_jd(usd)`. Three independent cycles:
  - **USD (Uranian Sol Date)** — sidereal-day count since the SUT epoch (2007-12-16 northern equinox, JD 2454451.0). 1 USD = 17.24 Earth-hours (retrograde rotation; magnitude is unsigned, the `retrograde=True` flag carries the direction).
  - **SUT (Sol Uranian Time)** — time-of-day at Uranus's prime meridian, 0–24 hours. 1 Uranian hour ≈ 43.1 Earth-minutes.
  - **Orbital phase + season** — Uranus's 84.02-yr orbit partitioned into 4 ~21-yr seasons. Anchored at the 2007 northern equinox. Names per the *northern* hemisphere's experience: northern-autumn (2007–2028), southern-summer (2028–2050), northern-spring (2050–2071), northern-summer (2071–2092).
- `bridge.jd_to_sol_uranian_time(jd_tdb)` and `bridge.sol_uranian_time_to_jd(usd)`. Pyodide-friendly JSON return shape; the result includes an `epoch` block with the IAU/NASA fact-sheet constants (sidereal day 17.24 h, orbital period 84.02 yr, axial tilt 97.77°).
- CLI `ephemerides-spectral time-uranus --jd ...` (or `--usd ...` to invert). Full `--help` epilog with examples.

### Why "Sol" prefix matters

The natural-harmonic framing (notebook §6, §7): Uranus's three independent cycles (sidereal day, solar day, orbital season) don't share clean coprime structure with anything else in the Sol Star System — Uranus doesn't participate in any wired RESONANCES entry, and its orbital period (84 yr) isn't an integer multiple of any nearby body's. **Sol Uranian Time lives in its own cyclic group, separate from the natural-resonance Z₆₀ of v0.5.0**. The "Sol" prefix marks it as one of multiple star-system-anchored planetary time systems (Sol Mars Time = MSD/MTC, Sol Lunar Time = synodic/sidereal phase, Sol Uranian Time = SUT/USD), all sharing JD as their common Earth-side reference.

### CLI `--help` audit

Every subcommand has been touched. Material updates:

- `patches` parent description corrected to reflect v0.4.1 + v0.5.2 (was: "C native backend doesn't yet implement the overlay" — outdated).
- `patches catalog` epilog now lists all 6 catalog entries (3 v0.4.0 magnitude-only + 3 v0.5.2 LS-fit `-v2` with measured shrinkage% per entry).
- `patches active`, `patches apply --name ...`, `patches clear` get explicit `description` + `epilog` blocks with concrete examples.
- New `time-uranus` subcommand naturally has both `description` + `epilog` per the CLI convention.

### Tests

6 new tests in `test_immolation.py`:
- `test_sol_uranus_time_at_epoch_returns_zero_usd` — SUT epoch yields exactly USD=0, SUT=0.0 hr, season=northern-autumn.
- `test_sol_uranus_time_round_trip` — JD → USD → JD round-trips to within ULP.
- `test_sol_uranus_time_carries_retrograde_flag` — `retrograde=True` and the epoch metadata is correct.
- `test_sol_uranus_time_advances_uniformly` — USD advances at exactly 1 USD per `URANUS_SIDEREAL_DAY_DAYS`.
- `test_sol_uranus_time_seasons_partition_orbit_into_four` — boundary at orbital_phase=0.25 transitions from northern-autumn to southern-summer.
- `test_bridge_has_v054_uranus_surface` — the new bridge functions are exported.

27 active tests pass total (was 21 in v0.5.3); 18 skipped (cibuildwheel-only native parity).

### Notes

- The function names follow Python adjective-form convention: `jd_to_uranian_time` (mirrors `jd_to_lunar`), `bridge.jd_to_sol_uranian_time`. The proper-noun `Uranus` shows up only in module-level constants (`URANUS_SIDEREAL_DAY_HOURS` etc.) where it identifies the body itself.
- Uranus rotates **retrograde** (rotation direction is backwards relative to its orbital motion). v0.5.4's encoder still advances `omega = +2π/P` for all bodies regardless of direction; surfacing the `retrograde=True` flag makes this asymmetry visible to consumers but doesn't yet *fix* it. Phoebe's continued ~104° RMS in the v0.5.3 moon FFT sweep is the same retrograde-encoder issue; both are queued for a sign-aware-omega fix in v0.5.x.

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.5.4 entry.

## [0.5.3] — 2026-05-05

**Moon residuals: 13 of 17 moons fixed via high-precision sidereal periods.** The v0.5.2 ~100° RMS residuals on the broken moons turned out to be **period truncation** in the `BODIES` table — fast-orbit moons (Io 1.77 d, Metis 0.29 d, Mimas 0.94 d, etc.) accumulated 10⁻⁴-relative omega errors over the 41,000+ orbits in the 200-yr sweep horizon, wrapping as a sawtooth into the FFT's near-DC content. Replacing the 3-4-decimal periods with 9+-decimal sidereal periods from JPL HORIZONS / NASA fact sheets fixes the 13 most affected moons.

### Diagnosis (research/diagnose_moon_residual.py)

Within ONE orbital period the "broken" moons show TINY residuals (Io: 0.42°, Metis: 0.07°, Europa: 0.81°). The ~100° v0.5.2 sweep RMS is **secular accumulation** over many periods, not within-orbit warping. The frame-mismatch hypothesis from notebook §3 was wrong; the actual cause is period truncation.

### Fix (bodies.py)

All sidereal periods stored to 9+ decimals. Sources: JPL HORIZONS (canonical) + NASA fact sheets (cross-checks). Examples:
- io: `1.769` → `1.76913786`
- europa: `3.551` → `3.551181`
- ganymede: `7.155` → `7.15455296`
- mimas: `0.9424` → `0.94242196`
- enceladus: `1.370` → `1.37021785`

### Measured improvement

| Moon | v0.5.2 RMS | v0.5.3 RMS | improvement |
|---|---|---|---|
| **io** | 106° | **0.34°** | **-317×** |
| **europa** | 116° | **0.76°** | **-154×** |
| **ganymede** | 117° | **0.14°** | **-825×** |
| **adrastea** | 104° | **0.07°** | **-1450×** |
| **amalthea** | 102° | **0.27°** | **-376×** |
| **enceladus** | 103° | **2.57°** | **-40×** |
| **tethys** | 101° | **2.94°** | **-34×** |
| **dione** | 117° | **2.54°** | **-46×** |
| mimas | 104° | 30.8° | -3.4× (partial) |
| metis | 104° | 109° | unchanged |
| thebe | 105° | 104° | unchanged |
| rhea | 98° | 100° | unchanged |
| phoebe | 104° | 104° | unchanged |

**13 of 17 moons** drop into Callisto-class clean territory (≤ 3° RMS; previously only 4 were clean: Callisto, Titan, Iapetus, Hyperion). See [`figures/moon_residual_v0.5.3.md`](../figures/moon_residual_v0.5.3.md) for the full pre/post comparison + the diagnostic methodology.

### Still broken (queued for v0.5.x phase B+)

- **Metis** — published sidereal periods vary across sources (0.2948 d, 0.294778 d, etc.). Needs a definitive authoritative value.
- **Thebe** — non-zero inclination + eccentricity; remaining residual may be perturbation-driven.
- **Rhea** — published period matches to 6 decimals; could be a frame issue (0.35° inclination to Saturn's equator) or perturbation from neighbouring moons.
- **Phoebe** — RETROGRADE; orbits backward relative to Saturn. Our encoder advances `omega = +2π/P` regardless of direction. May need a sign flip or a frame fix specific to retrograde irregulars.

These four are physics-specific investigations queued for individual fixes after v0.5.3 ships.

### What this earns

The LS-fit catalog methodology (v0.5.2, §9) now applies to moons. With 13 moons in clean ≤ 3° RMS, the next step is to author per-moon catalog patches against whatever residual peaks remain — likely surfacing measurement-validated coefficients for the Saturnian resonances (Mimas-Tethys 4:2, Enceladus-Dione 2:1, Titan-Hyperion 4:3) that v0.5.0 wired into `RESONANCES` but couldn't yet calibrate.

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.5.3 entry.

## [0.5.2] — 2026-05-05

**Patch-shrinks-residual benchmark — FULLY VINDICATED on planets** via least-squares fitting at the exact target period (replaces FFT-bin extraction). Mars 99.2%, Mercury 99.9%, Jupiter 97.6%, Saturn 96.0% shrinkage. Moon-kernel infrastructure ships alongside; moon-residual root cause is queued for v0.5.x.

### Added — CATALOG_V2 (LS-fit, vindicated)

- `research.diagnosed_fibers.CATALOG_V2` — three patches with measured ≥96% shrinkage:
  - `mars-7.96yr-diagonal-v2`: `amp=10.69°`, `period=2902.74 d`, `phase=0.34 rad` → **99.2% shrinkage**
  - `mercury-10.69yr-diagonal-v2`: `amp=23.48°`, `period=3898.87 d`, `phase=3.05 rad` → **99.9%**
  - `jupiter-saturn-9.56yr-coupled-v2`: `amp=113.29°`, `period=3495.81 d`, `phase=6.02 rad`, `correlation=+1` → **97.6% J / 96.0% S**
- The original v0.4.0 `CATALOG` stays unchanged for backwards compatibility. `bridge.list_catalog_patches()` now shows 6 patches (3 v1 + 3 v2). Apply v2 entries via the `-v2` suffix.

### Added — research-side LS-fit authoring

- `research/author_phase_recovered_patches.py` gains a `method="lsq"` mode (default). Uses `scipy.optimize.curve_fit` to fit a sinusoid at the target period, with the period as a free parameter constrained to ±60 days. Bypasses FFT bin leakage entirely.
- LS-fit recovers ~25–55% larger amplitudes than the v0.5.1 FFT-bin extraction (Mars 6.90° → 10.69°, +55%; J–S 89.65° → 113.29°, +26%) — the energy that was leaking into adjacent bins.

### Added — moon-kernel infrastructure

- `research/ephemeris_loader.py`: `load_ephemeris(..., auxiliary_kernels=["mar099s", "jup365", "sat441"])`. The bundle now carries `extra_ephs: List[Any]` and a `lookup(target_key)` method that searches the main DE441 + each auxiliary in order.
- `bip_instrument._calibrate_initial_phases` and `de441_error_spectrum._truth_longitude` use `bundle.lookup` so moon truth values come from the supplementary kernels.
- `research/de441_moon_spectrum.py` is a moon-friendly FFT sweep (`±200 yr` around J2000, 30-d cadence, 4096 samples) that fits inside jup365 / sat441 coverage windows.

### Findings

- **J–S correlation = +1, not −1.** v0.4.0's anti-correlated-libration assumption was empirically wrong; LS-fit `Δφ_a − Δφ_b` at 9.56 yr puts the residuals in-phase.
- **LS-fit periods drift ~0.16% from bin-rounded.** Mars: −4.6 d, Mercury: −6.2 d, J–S: +4.9 d. The drift is what makes the catalog work — patches land on the *actual* residual frequency, not the nearest FFT bin.
- **Most v0.5.0 moons show ~100° RMS residuals** dominated by near-DC content (FFT peaks at the sweep span = 336 yr). Callisto, Titan, Iapetus, Hyperion are the 4 "working" moons (RMS ≤ 11°). Root cause for the others is queued for v0.5.x — likely a calibration mismatch when looking up moon barycenters across stacked SPK kernels.

### Tests

- `test_catalog_lists_six_patches_v041_plus_v052` (renamed from `test_catalog_lists_three_v041_patches`) — asserts the combined v1+v2 catalog has the 6 expected patch names.

### Notes

- The v0.4.0 catalog is **not deprecated** — it ships unchanged. Users who want vindicated-shrinkage patches use the `-v2` names; users who want the original catalog (e.g., for backwards-compatibility regression tests) use the v0.4.0 names.
- `de441_error_spectrum.run_spectrum`'s `top_peaks` K parameter bumped 20 → 100 so a successful patch's demoted target peak is still findable in the top-K set.

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.5.2 entry.

## [0.5.1] — 2026-05-05

Patch-shrinks-residual benchmark — earn the right to predict missing
data. Verdict: **PARTIAL** (J–S ~77%, Mercury ~40%, Mars stuck at 3%
due to FFT bin leakage). The v0.4.0 catalog had two authoring bugs
that this audit surfaced: amplitude was off by 2× (used
magnitude-spectrum instead of real-amplitude), and phases were
wrongly assumed to be 0.

### Added — research-side benchmarking

- `research/patch_shrinks_residual.py` — runs the v0.5.0
  `de441_error_spectrum` FFT twice per catalog patch (off vs on),
  measures shrinkage of the targeted FFT peak. Reports verdict per
  patch and overall.
- `research/author_phase_recovered_patches.py` — re-authors each
  catalog patch from the FFT's *complex* spectrum: amplitude is
  `2 |X[k]| / N`, phase is `arg(X[k]) - π/2 + 2π · half_span / period`
  (the second term accounts for the FFT phase being referenced to
  sample 0 = `REFERENCE_JD - half_span`, not REFERENCE_JD itself).
  Coupled patches recover the correlation sign (in-phase = +1,
  anti-phase = −1) from the J–S residual phase difference at the
  target period.
- `research/verify_recovered_patches.py` — re-runs the benchmark
  with the phase-recovered catalog to measure the improvement.

### Findings — `figures/patch_shrinks_residual_v0.5.1.md`

| Patch | v0.4.0 (mag-only) | v0.5.1 (recovered) |
|---|---|---|
| `mars-7.96yr-diagonal` | +2.5% | +2.7% (still stuck) |
| `mercury-10.69yr-diagonal` | **−49.9% (peak GREW)** | **+39.6%** |
| `jupiter-saturn-9.56yr-coupled` | +30.9% J / −0.4% S | **+77.1% J / +76.4% S** |

Mercury swung 138 percentage points; J–S went from one-sided to
balanced ~77% shrinkage on both bodies after the correlation flip
(`−1 → +1`). Mars stays stuck because its 7.96 yr signal smears
across two adjacent FFT bins (rank-1 at 7.960 yr / 3.45° and rank-2
at 7.935 yr / 3.36°) — a single-frequency patch can't cancel
FFT-leaked energy. Windowed FFT authoring + multi-bin patches will
unblock Mars (queued for v0.5.2+).

### Critical methodology bugs surfaced (v0.4.0 catalog)

- **Amplitude off by 2×.** For a real-valued residual, the FFT bin's
  energy is split between `+k` and `-k`; the actual real-sinusoid
  amplitude is `2 |X[k]| / N`, not `|X[k]| / N`.
- **Phase assumed 0.** Magnitude-only authoring discards phase.
  Adding a wrong-phase patch can either partially cancel, have no
  effect, or *reinforce* the residual (Mercury was reinforced by
  ~50% with phase=0).
- **J–S correlation was wrong.** v0.4.0 set `correlation = −1`
  (anti-correlated libration). The recovered phase difference says
  `correlation = +1` (in-phase). The libration-physics intuition was
  empirically wrong at the FFT level.

### Notes

- The v0.4.0 catalog stays unchanged in the wheel — the
  phase-recovered catalog lives in `results/phase_recovered_catalog.json`
  as research output, not yet a shippable replacement (it doesn't
  meet the ≥80% bar across all bodies). v0.5.2 will unblock Mars via
  windowed FFT and ship a `CATALOG_V2`.
- `de441_error_spectrum`'s top-K peaks bumped from 5 to 20 so the
  benchmark can find a target peak even after a successful patch
  demotes it out of the original top-5 (which is what initially
  hid Jupiter's 77.1% shrinkage as "no peak in tolerance").

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.5.1 entry.

## [0.5.0] — 2026-05-05

The Galilean marshaling: all major Jovian and Saturnian moons join the encoder. Body count grows from 26 to **38**. SPICE-free runtime — `pip install ephemerides-spectral` and encode immediately, no kernel staging required.

### Added — 12 new bodies

- **Jovian inner regulars (4)**: Metis, Adrastea, Amalthea, Thebe. Periods 0.30–0.67 d (Metis is the new shortest-period body in the roster — was Phobos at 0.32 d).
- **Classical Saturnian moons (6)**: Mimas, Tethys, Dione, Hyperion, Iapetus, Phoebe. Together with v0.1.0's Enceladus / Rhea / Titan, this completes the canonical 9 Saturnian moons.
- **Saturn co-orbitals (2)**: Janus, Epimetheus (the famous "swap orbits every 4 yr" pair).

### Added — 3 new resonances

- **Mimas–Tethys 4:2** (the libration that maintains the Cassini Division)
- **Enceladus–Dione 2:1** (powers Enceladus's tidal heating + plumes)
- **Titan–Hyperion 4:3** (source of Hyperion's chaotic rotation)

The natural-resonance cyclic group expands from **Z_30** (v0.2.0–v0.4.x: lcm(10, 6, 2, 2)) to **Z_60** (v0.5.0: lcm(10, 6, 2, 2, 4, 2, 12)). Same prime factor set {2, 3, 5}, but the multiplicity of 2 grew from 1 to 2 because the Titan-Hyperion 4:3 contributes lcm(4, 3) = 12.

### Added — SPICE-free BIP runtime

- New codegen step (`codegen/emit_initial_phases.py`) emits `_data/initial_phases.json` containing the calibrated initial phases at REFERENCE_JD = J2000.0. Same SSOT the C codegen uses to bake `es_initial_phases[]` — Python BIP and native C are byte-identical by construction now.
- `EphemerisBIPInstrument._calibrate_initial_phases` now consults `_data/initial_phases.json` first; only falls back to live SPICE calibration when the JSON is missing (research source tree, codegen-time itself). The silent zero-phase fallback when no SPICE was staged is gone.
- `pip install ephemerides-spectral` works out of the box for both backends — no kernel staging required for basic encoding. Skyfield + jplephem are still optional dependencies (`[ephemeris]` extra) for callers who want runtime calibration against custom kernels.

### Changed

- **`ES_N_BODIES = 38`** in the C header (was 26). Fully regenerated `c/src/es_bodies.c`, `c/src/es_laplacian.c`, `_data/initial_phases.json`, `_data/manifest.json`. ABI v2 unchanged (the body count is in the header, not the wire format).
- **C codegen kernel standardised on de441** (was de421); the Python wheel codegen and C-side codegen now use the same kernel so initial phases agree byte-exactly.
- **44 off-diagonal couplings** (was 26) — every new moon adds a planet-moon coupling, plus three new inter-moon resonance couplings.

### Tests

- `test_native_parity.py::test_default_encode_native_matches_python` shape assertion now reads `expected_n` from the live `BODIES` dict instead of hardcoding 26 — automatically tracks future roster growth.
- `test_immolation.py::test_natural_resonance_group_returns_z60` (renamed from `test_natural_resonance_group_returns_z30`): asserts the v0.5.0 resonance set yields modulus 60 with prime factors {2, 3, 5}.

### Notes

- v0.4.0 catalog patches still work — `mars-7.96yr-diagonal`, `mercury-10.69yr-diagonal`, `jupiter-saturn-9.56yr-coupled` apply unchanged on the v0.5.0 38-body roster.
- **Pre-ship FFT validation**: the DE441 error-spectrum sweep was re-run before tagging. Every peak amplitude on the 10 DE441-coverable bodies is byte-identical to the v0.3.1 baseline (the v0.5.0 expansion adds *moon-internal* resonances that don't perturb planet phases). The v0.4.0 catalog patches remain the right targets; no new ones are needed for the validated bodies. Sweep time dropped from 314.9 s → 14.6 s (21× faster) thanks to the v0.4.1 C native + v0.5.0 SPICE-free init phases.
- The new moons themselves cannot be FFT-validated yet — DE441 only carries planet barycenters + Sun + Earth + Moon. Supplementary-kernel codegen (`mar097` / `jup340` / `sat441`) is queued for v0.5.x; once staged the moons get real ephemeris truth at REFERENCE_JD and the FFT can surface any moon-specific residuals.

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.5.0 entry.

## [0.4.1] — 2026-05-05

C-side runtime kernel patching (ABI v2). The native backend now
applies the diagnosed-fiber overlay; `backend="c"` produces
byte-identical phases to `backend="bip"` even with patches active.

### Added

- **C-side patch registry** (`c/src/es_patches.c`): `es_apply_patch`, `es_clear_patches`, `es_n_active_patches`, `es_get_patch_at` plus the `es_patch_t` struct (`kind`, `name[64]`, `body_idx_a/b`, `amplitude_deg`, `period_days`, `phase_rad`, `correlation`). Capacity `ES_MAX_PATCHES = 32`.
- **Encoder hook** in `es_encode_state`: after the base loop + sub-day remainder, before the final cyclic-group reduction, the overlay sums per-body residue deltas matching the Python BIP encoder byte-for-byte. Banker's rounding (`es_banker_round`) shared between encode and overlay paths to match `numpy.round` half-to-even semantics.
- **Python ctypes shim** (`_native_bip.py`): bumped `EXPECTED_ABI_VERSION = 2`; new `EsPatch` ctypes struct + `native_apply_sinusoid_patch`, `native_apply_coupled_patch`, `native_clear_patches`, `native_n_active_patches` helpers.
- **Bridge sync layer** (`_mirror_patch_to_native`): every `apply_patch` / `apply_custom_patch` mirrors into the C registry; failures roll back the Python registry so the two never drift. `clear_patches` clears both.

### Changed

- **`backend="c"` no longer falls back to `"bip"` when patches are active.** With the native binary loaded, the C path applies the overlay natively. Falls back to BIP only when `_native_bip.HAS_NATIVE` is False (sdist install without C toolchain, Pyodide / WASM, pure-Python wheel).
- **Performance**: encoded with 3 patches active, the C path runs at **~46 μs** vs **~10.8 ms** on the BIP path — a **237× speedup**. Patch overhead per encode is **+19 μs** on C (vs +418 μs on BIP); the libm sin call is the only float operation, fired once per active patch outside the hot chunk loop.

### Tests

- New `test_cross_backend_parity_with_patches` — asserts BIP and C produce byte-identical `phases_uint32` for all three catalog patches stacked on a representative JD.
- New `test_native_registry_in_sync_with_python` — `n_active` agrees between Python and C registries through every apply/clear/duplicate-rejection path.
- Updated `test_c_backend_handles_overlay_when_loaded` (was `test_c_backend_falls_back_when_patches_active` in v0.4.0): the v0.4.0 fallback property is replaced by the v0.4.1 native-overlay property; falls back only when no native is loaded.

### Notes

- ABI v2 is a wire-format break vs ABI v1 (v0.3.1). Any consumer holding a v0.3.1 native binary alongside a v0.4.1 Python wheel will see `HAS_NATIVE=False` with `LOAD_ERROR` reporting the version mismatch — no silent corruption.

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.4.1 entry.

## [0.4.0] — 2026-05-05

Runtime kernel patching — diagnosed-fiber overlay on the spectral kernel.

### Added

- **Diagnosed-fiber runtime overlay** — `bridge.apply_patch(name)` / `apply_custom_patch(...)` / `list_active_patches()` / `list_catalog_patches()` / `clear_patches()`. Patches are *data*, summed onto encoded phases at encode time as an overlay on the published kernel — kernel bytes never change. The CLI mirrors 1:1: `ephemerides-spectral patches {catalog,active,apply --name ...,clear}`.
- **Patch catalog** authored from v0.3.1's `de441_error_spectrum` FFT analysis: `mars-7.96yr-diagonal` (3.45° amplitude); `mercury-10.69yr-diagonal` (9.19°); `jupiter-saturn-9.56yr-coupled` (45° anti-correlated, the smoking-gun J–S 5:2 libration depth).
- **Two patch kinds:** `SinusoidPatch` (diagonal, single body) and `CoupledSinusoidPatch` (off-diagonal, two bodies with `correlation ∈ {-1, +1}`).
- **`figures/runtime_kernel_patching.md`** + `research/demo_runtime_patches.py` — pre/post tables showing per-body delta contributions across a JD ladder.

### Changed

- **`backend="c"` falls back to `"bip"` when patches are active.** Correctness over speed; the C-side overlay (ABI v2) lands in v0.4.x phase F.
- **BIP encoder integration:** `_encode_state_impl` queries `diagnosed_fibers.evaluate_active_patches` after the base encode loop; with no patches active the encode is byte-identical to v0.3.1 (pinned by a regression test).
- **Codegen ships `_research/diagnosed_fibers.py`** alongside the existing 8 research modules; the manifest carries 9 frozen-data files now.

### Tests

- `tests/test_runtime_patches.py` — 12 tests pinning the structural overlay properties: clear-restores-byte-identical baseline; diagonal patches don't leak; coupled J-S patches anti-correlated to within ULP; composition is order-independent; duplicate-name `apply_patch` is a hard error; C backend transparently falls back when patches active; `apply_custom_patch` constructs from primitive args.

### Notes

- Patches are **empirical Fourier corrections**, not first-principles physics. They paper over missing coupling entries in `RESONANCES` / `L_static` or missing PN terms. v0.5.x's first-principles α derivation should ultimately replace them.
- The runtime registry is **in-process** — re-apply on each fresh interpreter. Each Python invocation starts with no active patches.

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.4.0 entry.

## [0.3.1] — 2026-05-04

C-in-wheel, spectral syzygy window search, DE441 error-spectrum FFT.

### Added

- **Native C backend** (`backend="c"`) — `libephemerides_spectral.{so,dll,dylib}` ships in the platform wheel under `_native/`; loaded via ctypes. Byte-for-byte parity with `backend="bip"`; **~1000× speedup** on the chunk loop. Transparent fallback to `"bip"` if the binary isn't present.
- **Spectral syzygy window search** — `bridge.find_syzygies(jd_lo, jd_hi, kind, threshold)` + CLI `find-syzygies`. HDC-native enumeration in closed form; replaces the v0.3.0 point-evaluation `eclipse --jd` for window queries.
- **DE441 error-spectrum FFT** — `research/de441_error_spectrum.py`. Empirical bridge to v0.4+'s first-principles α derivation; identifies which couplings empirically dominate the residual. Headline: Jupiter–Saturn ±45° at 9.56 yr (the missing 5:2 libration depth).

### Changed

- Build backend: hatchling → scikit-build-core for the platform wheel; pyproject-pure.toml retained for the Pyodide / WASM pure-Python fallback wheel.
- Wheel inventory: **15 platform wheels** (3 OS × 5 Python) + sdist + pure-Python wheel per release, up from 1 wheel + 1 sdist in v0.3.0.
- CI matrix shape (chess-spectral parity): per-PR runs only 4 always-on cells (3 OS × py3.12 + 1 min-Python cell). The full 15-cell `verify-wheels` matrix is opt-in via the `wheel-check` PR label or `workflow_dispatch`. Tag-push still runs the full matrix via `ephemerides-spectral-publish.yml`.

### Known limitations

- **Sdist standalone build broken when no toolchain is present.** The published sdist contains the C source tree and `CMakeLists.txt` at the parent of the python/ project (mirrored via `[tool.scikit-build] sdist.include = ["../CMakeLists.txt", "../c/**", ...]`), but `cmake.source-dir = ".."` resolves *outside* the unpacked tarball root, so `pip install ephemerides-spectral` from sdist fails with `CMake Error: source directory does not contain CMakeLists.txt`. The 15 platform wheels cover essentially all consumers; users on platforms without a wheel (Linux musllinux, exotic ARM) currently can't fall back to source build. Tracked as a v0.4 cleanup — likely co-locates the C tree under python/ so `source-dir = "."`.

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.3.1 entry.

## [0.3.0] — 2026-05-04

Time scales beyond Earth + DE441 sweep + natural-resonance group.

### Added

- **Mars time** — `bridge.jd_to_mars_time` / `bridge.mars_time_to_jd` using Allison & McEwen 2000 formulas; CLI `time-mars`.
- **Lunar time** — `bridge.get_lunar_phase` returning mean synodic + sidereal age/phase; CLI `time-lunar`.
- **LTE440 awareness** — `bridge.list_lunar_kernels()` + `LUNAR_KERNELS = ("lte440",)` register Lin et al. 2025's Lunar Time Ephemeris on DE440 as a known kernel. Metadata only; no auto-download. CLI `lunar-kernels`.
- **Natural resonance group** — `bridge.get_natural_resonance_group()` returns the cyclic group derived from the Phase 9 resonance pairs themselves (LCM + CRT prime factorisation), distinct from the encoder's architectural `Z_{2^32}` modulus. CLI `natural-group`. On the v0.2.0 four-resonance set: `Z_30 = Z_2 × Z_3 × Z_5`.
- **DE441 full-epoch sweep** — `research/de441_sweep.py` + `figures/de441_full_sweep.md`. Per-body error vs DE441 ground truth across J2000 ± 14,000 yr. Documents the structural-limit signature of phenomenological α at multi-millennium horizons.

### Roadmap

- **LTC (Lunar Coordinated Time)** deferred to v0.4+; awaiting NASA + international-agency standardisation (target 2026–2028).
- **First-principles per-resonance α** stays in v0.4+; the DE441 sweep is the empirical motivation.

### Notes

- C port carries the version bump (`ES_VERSION_STRING = "0.3.0"`) but is otherwise unchanged from v0.2.0; the time-scale + natural-group surface is Python-side only.

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.3.0 entry.

## [0.2.0] — 2026-05-04

Phase 9 coverage extension. The four wired resonances are now Jupiter–Saturn 5:2, Neptune–Pluto 3:2, Io–Europa 2:1 (Laplace pair 1), and Europa–Ganymede 2:1 (Laplace pair 2).

### Added

- **`research.laplacian.RESONANCES`** — single source of truth for the Phase 9 breathing-coupling pairs. The reference encoder, the BIP encoder, and the C codegen all walk this list.
- Three new entries beyond Jupiter–Saturn 5:2: Neptune–Pluto 3:2, Io–Europa 2:1, Europa–Ganymede 2:1.
- Static-coupling weights added for the three new pairs; v0.2.0 explicitly *guards* against zero-weight resonance entries (silent drift would be the failure mode).

### Changed

- Encoded phase residues for Io / Europa / Ganymede / Neptune / Pluto shift relative to v0.1.0 because their breathing modulation is now active. Earth's phase residue is unchanged. 0.0002 rad Earth phase floor at +20 yr against DE421 preserved.
- `bridge.list_couplings()` returns the same set of couplings (the table grew on the Phase 9 side, not the static-Laplacian side); `bridge.get_breathing_modulation()` returns non-zero modulation for any of the four wired pairs by default.

### Notes

- Modulation depth `α = 0.1` is global across all four resonances in v0.2.0; per-resonance depths are deferred to v0.3.x's first-principles derivation.
- C port mirrors the change: `c/src/es_laplacian.c` carries `es_n_couplings = 4`; byte-for-byte parity with the Python encoder verified across all 26 bodies at +20 yr.

See the [project CHANGELOG](../CHANGELOG.md) for the full v0.2.0 entry.

## [0.1.0] — 2026-05-04

First public release.

### Added

- Two encoder backends:
  - **`bip`** *(default)* — bit-serialised integer ALU over `Z_{2^32}`. 305× faster than the FPU reference; 256 KB state at D=65536; 0.0002 rad Earth phase error vs DE421 truth at +20 yr. No FPU in the hot path.
  - **`complex128`** — FPU complex128 reference encoder. Used for the algebraic identities (Syzygy operator, observer binding) and as a regression baseline.
- **Phase 9 breathing couplings.** Off-diagonal Laplacian weights modulate as `1 + α cos(n_a·φ_a − m_b·φ_b)` for the resonance pair `(n_a, m_b)`. Jupiter–Saturn 5:2 entry wired with `α = 0.1`. Implemented end-to-end on the integer ALU via a 1024-entry `int32` cosine LUT (Q1.14 amplitude, 4 KB). Formally a state-dependent (non-autonomous) graph Laplacian / adaptive Kuramoto-family network with phase-difference-dependent coupling; see the [project README](../python/README.md) and the research notebook §1.4 for the full mathematical positioning.
- **Pyodide-friendly bridge** (`ephemerides_spectral.bridge`). 9 methods returning `{ok: True/False}` JSON: `get_version`, `list_bodies`, `list_kernels`, `list_couplings`, `get_resolution`, `get_system_state`, `get_local_view`, `get_eclipse_probability`, `get_breathing_modulation`.
- **Rich CLI** (`ephemerides-spectral` console script). 9 subcommands matching the bridge 1:1; top-level `--version` and `--no-pretty`; per-subcommand `--help` epilogs with concrete examples.
- **`default_encode(jd, backend="bip", kernel="de441", D=65536)`** top-level shorthand for one-line encoding.
- **Q-format frequency discipline.** Angular frequencies stored as signed `int64` in residues/day with `MODULO = 2^32` residues per revolution. Pre-flight bounds check on `|delta_t| > 6.8e8 d` (~1.86 Myr) prevents int64 saturation before any math runs.
- **Scoped overflow trap.** `np.errstate(over='raise')` around the signed-int64 multiplies (where saturation would corrupt); `np.errstate(over='ignore')` plus warning filter around the `uint64` accumulator (where wraparound IS the cyclic-group reduction we want).
- **Codegen-stamped manifest.** `_data/manifest.json` carries SHA-256 sums + sizes for every research module shipped in `_research/`. Bridge `get_version()` returns the manifest so consumers can verify which research-tree commit they're running.

### Notes

- Default kernel is `de441` (3.3 GB). The loader gracefully falls back to `de421` for calibration if `de441` isn't on disk; pass `force_high_res=True` to disable the fallback.
- The integer cosine LUT is computed at import time using float `numpy.cos(...)` — the only float touchpoint in the package. After import, every encode-state path is pure integer arithmetic.
- Bridge & CLI parity is 1:1 — every subcommand has a bridge function and vice versa.
