class TransactionException(Exception):
    pass
