#
# ProjectManager API for Python
#
# (c) ProjectManager.com, Inc.
#
# For the full copyright and license information, please view the LICENSE
# file that was distributed with this source code.
#
# @author     ProjectManager.com <support@projectmanager.com>
# @copyright  ProjectManager.com, Inc.
# @link       https://github.com/projectmgr/projectmanager-sdk-python
#


from typing import List
import dataclasses

@dataclasses.dataclass
class FileDataDto:
    """
    File Data
    """

    count: int | None = None
    """
    Task files count
    """

    lastUpdatedDate: str | None = None
    """
    Last update data
    """

    lastReadDate: str | None = None
    """
    Last read date
    """


