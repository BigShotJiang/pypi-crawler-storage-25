"""Tiny plain-English explanations for ML metrics."""

from .explain import explain

__all__ = ["explain"]
