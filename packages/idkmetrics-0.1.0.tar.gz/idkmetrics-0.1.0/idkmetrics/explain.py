from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable


TaskName = str


@dataclass(frozen=True)
class MetricSpec:
    canonical_name: str
    label: str
    task: TaskName
    direction: str
    plain_english: str
    interpretation: tuple[tuple[float, str], ...] | None = None
    scale_dependent: bool = False
    notes: tuple[str, ...] = ()


_METRIC_SPECS: dict[str, MetricSpec] = {
    "mae": MetricSpec(
        canonical_name="mae",
        label="MAE",
        task="regression",
        direction="lower",
        plain_english="average absolute error between predictions and the real value",
        scale_dependent=True,
        notes=("MAE uses the same units as the target.",),
    ),
    "mse": MetricSpec(
        canonical_name="mse",
        label="MSE",
        task="regression",
        direction="lower",
        plain_english="average squared error, which punishes big misses extra hard",
        scale_dependent=True,
        notes=("MSE is in squared target units, so it is harder to interpret directly.",),
    ),
    "rmse": MetricSpec(
        canonical_name="rmse",
        label="RMSE",
        task="regression",
        direction="lower",
        plain_english="typical prediction error, with extra punishment for big misses",
        scale_dependent=True,
        notes=("RMSE uses the same units as the target.",),
    ),
    "r2": MetricSpec(
        canonical_name="r2",
        label="R^2",
        task="regression",
        direction="higher",
        plain_english="how much of the target variation the model explains",
        interpretation=(
            (0.0, "below 0 means the model is worse than a dumb baseline that predicts the mean"),
            (0.3, "near 0 means the model is explaining very little"),
            (0.6, "mid-range values mean the model is catching some real signal"),
            (0.85, "higher values mean the model explains most of the variation"),
        ),
        notes=("R^2 can look low on noisy real-world problems and still be useful.",),
    ),
    "mape": MetricSpec(
        canonical_name="mape",
        label="MAPE",
        task="forecasting",
        direction="lower",
        plain_english="average percentage error",
        interpretation=(
            (0.1, "under 10% is often strong"),
            (0.2, "10% to 20% is often usable"),
            (0.5, "20% to 50% can be rough depending on the use case"),
        ),
        notes=("MAPE becomes unstable when true values are near zero.",),
    ),
    "medae": MetricSpec(
        canonical_name="medae",
        label="Median Absolute Error",
        task="regression",
        direction="lower",
        plain_english="the middle-sized absolute prediction error, so wild outliers matter less than in MAE",
        scale_dependent=True,
        notes=("Median absolute error is robust when a few predictions are wildly wrong.",),
    ),
    "smape": MetricSpec(
        canonical_name="smape",
        label="sMAPE",
        task="forecasting",
        direction="lower",
        plain_english="symmetric percentage error that is less weird around scale changes than MAPE",
        interpretation=(
            (0.1, "under 10% is usually strong"),
            (0.2, "10% to 20% is often workable"),
            (0.4, "above 20% may need attention"),
        ),
    ),
    "wape": MetricSpec(
        canonical_name="wape",
        label="WAPE",
        task="forecasting",
        direction="lower",
        plain_english="total absolute error compared with the total actual volume",
        interpretation=(
            (0.1, "under 10% is often strong"),
            (0.2, "10% to 20% is often acceptable"),
            (0.4, "above 20% can be a warning sign"),
        ),
    ),
    "mase": MetricSpec(
        canonical_name="mase",
        label="MASE",
        task="forecasting",
        direction="lower",
        plain_english="error scaled against a naive forecast baseline",
        interpretation=(
            (1.0, "below 1 usually means you beat the naive baseline"),
            (1.5, "around 1 means you are roughly baseline-level"),
        ),
    ),
    "accuracy": MetricSpec(
        canonical_name="accuracy",
        label="Accuracy",
        task="classification",
        direction="higher",
        plain_english="share of predictions that were correct",
        interpretation=(
            (0.5, "near coin-flip territory on balanced binary problems"),
            (0.7, "usable but not amazing in many settings"),
            (0.85, "pretty solid in many practical settings"),
            (0.95, "very high, but double-check for data leakage or class imbalance tricks"),
        ),
        notes=("Accuracy can be misleading on imbalanced classes.",),
    ),
    "balanced_accuracy": MetricSpec(
        canonical_name="balanced_accuracy",
        label="Balanced Accuracy",
        task="classification",
        direction="higher",
        plain_english="average recall across classes, so imbalance hurts less",
        interpretation=(
            (0.5, "near random on many binary setups"),
            (0.7, "decent"),
            (0.85, "strong"),
        ),
    ),
    "precision": MetricSpec(
        canonical_name="precision",
        label="Precision",
        task="classification",
        direction="higher",
        plain_english="when the model says positive, how often it is right",
        interpretation=(
            (0.5, "lots of false positives"),
            (0.75, "reasonable precision"),
            (0.9, "very few false positives"),
        ),
    ),
    "recall": MetricSpec(
        canonical_name="recall",
        label="Recall",
        task="classification",
        direction="higher",
        plain_english="how many real positives the model successfully catches",
        interpretation=(
            (0.5, "missing a lot of positives"),
            (0.75, "catching most positives"),
            (0.9, "catching nearly all positives"),
        ),
    ),
    "specificity": MetricSpec(
        canonical_name="specificity",
        label="Specificity",
        task="classification",
        direction="higher",
        plain_english="how well the model avoids false alarms on the negative class",
        interpretation=(
            (0.5, "many false positives"),
            (0.75, "fairly controlled false positives"),
            (0.9, "strong negative-class filtering"),
        ),
    ),
    "f1": MetricSpec(
        canonical_name="f1",
        label="F1",
        task="classification",
        direction="higher",
        plain_english="balance between precision and recall",
        interpretation=(
            (0.5, "still rough"),
            (0.7, "decent balance"),
            (0.85, "strong balance"),
        ),
    ),
    "roc_auc": MetricSpec(
        canonical_name="roc_auc",
        label="ROC AUC",
        task="classification",
        direction="higher",
        plain_english="how well the model ranks positives above negatives across thresholds",
        interpretation=(
            (0.5, "random ranking"),
            (0.7, "useful separation"),
            (0.85, "strong ranking"),
            (0.95, "excellent ranking"),
        ),
    ),
    "pr_auc": MetricSpec(
        canonical_name="pr_auc",
        label="PR AUC",
        task="classification",
        direction="higher",
        plain_english="precision-recall quality across thresholds, especially useful for rare positives",
        interpretation=(
            (0.2, "often weak unless the base rate is tiny"),
            (0.5, "promising on many imbalanced problems"),
            (0.8, "strong rare-class performance"),
        ),
    ),
    "log_loss": MetricSpec(
        canonical_name="log_loss",
        label="Log Loss",
        task="classification",
        direction="lower",
        plain_english="how wrong and overconfident the predicted probabilities are",
        interpretation=(
            (0.2, "very strong probability quality in many setups"),
            (0.5, "decent probability quality"),
            (1.0, "rough or overconfident"),
        ),
        notes=("Log loss cares about calibrated probabilities, not just the winning class.",),
    ),
    "silhouette": MetricSpec(
        canonical_name="silhouette",
        label="Silhouette Score",
        task="clustering",
        direction="higher",
        plain_english="how separated and internally tight the clusters are",
        interpretation=(
            (0.0, "near 0 means overlapping or fuzzy clusters"),
            (0.25, "weak cluster structure"),
            (0.5, "noticeable cluster structure"),
            (0.7, "very clean separation"),
        ),
    ),
    "davies_bouldin": MetricSpec(
        canonical_name="davies_bouldin",
        label="Davies-Bouldin Index",
        task="clustering",
        direction="lower",
        plain_english="how much clusters blur into each other",
        interpretation=(
            (0.5, "very compact and separated clusters"),
            (1.0, "fairly decent clustering"),
            (2.0, "messy overlap"),
        ),
    ),
    "calinski_harabasz": MetricSpec(
        canonical_name="calinski_harabasz",
        label="Calinski-Harabasz Score",
        task="clustering",
        direction="higher",
        plain_english="how strong the between-cluster separation is versus within-cluster spread",
        notes=("This score is usually most useful for comparing runs, not for absolute judgments.",),
    ),
    "inertia": MetricSpec(
        canonical_name="inertia",
        label="Inertia",
        task="clustering",
        direction="lower",
        plain_english="how far points are from their assigned cluster centers",
        scale_dependent=True,
        notes=("Inertia is mainly useful for comparing different values of k on the same dataset.",),
    ),
    "ndcg": MetricSpec(
        canonical_name="ndcg",
        label="NDCG",
        task="ranking",
        direction="higher",
        plain_english="how well the ranking puts the most relevant items near the top",
        interpretation=(
            (0.4, "weak ranking quality"),
            (0.7, "decent ranking quality"),
            (0.9, "strong top-of-list relevance"),
        ),
    ),
    "map": MetricSpec(
        canonical_name="map",
        label="MAP",
        task="ranking",
        direction="higher",
        plain_english="average precision across queries or ranking tasks",
        interpretation=(
            (0.4, "still pretty rough"),
            (0.7, "useful retrieval quality"),
            (0.9, "very strong retrieval quality"),
        ),
    ),
    "mrr": MetricSpec(
        canonical_name="mrr",
        label="MRR",
        task="ranking",
        direction="higher",
        plain_english="how quickly the first relevant result shows up",
        interpretation=(
            (0.3, "relevant answers often show up late"),
            (0.6, "relevant answers often show up fairly early"),
            (0.85, "relevant answers usually appear near the top"),
        ),
    ),
    "bleu": MetricSpec(
        canonical_name="bleu",
        label="BLEU",
        task="generative",
        direction="higher",
        plain_english="how much generated text overlaps with a reference text",
        interpretation=(
            (0.15, "weak overlap"),
            (0.3, "moderate overlap"),
            (0.5, "strong overlap"),
        ),
        notes=("BLEU rewards wording overlap, not necessarily usefulness or factuality.",),
    ),
    "rouge": MetricSpec(
        canonical_name="rouge",
        label="ROUGE",
        task="generative",
        direction="higher",
        plain_english="how much generated text covers the same content as a reference",
        interpretation=(
            (0.2, "weak content overlap"),
            (0.4, "moderate content overlap"),
            (0.6, "strong content overlap"),
        ),
    ),
    "rouge_l": MetricSpec(
        canonical_name="rouge_l",
        label="ROUGE-L",
        task="generative",
        direction="higher",
        plain_english="sequence-level overlap with the reference text",
        interpretation=(
            (0.2, "weak overlap"),
            (0.4, "moderate overlap"),
            (0.6, "strong overlap"),
        ),
    ),
    "bertscore": MetricSpec(
        canonical_name="bertscore",
        label="BERTScore",
        task="generative",
        direction="higher",
        plain_english="semantic similarity to the reference, even when wording differs",
        interpretation=(
            (0.8, "weak semantic match for this metric"),
            (0.9, "decent semantic match"),
            (0.95, "very strong semantic match"),
        ),
    ),
    "perplexity": MetricSpec(
        canonical_name="perplexity",
        label="Perplexity",
        task="generative",
        direction="lower",
        plain_english="how surprised the language model is by the text",
        notes=("Perplexity is mainly useful for comparing models on the same dataset and tokenization.",),
    ),
}


_ALIASES = {
    "r_squared": "r2",
    "r-squared": "r2",
    "rsquared": "r2",
    "r2_score": "r2",
    "mean_absolute_error": "mae",
    "mean_squared_error": "mse",
    "root_mean_squared_error": "rmse",
    "median_absolute_error": "medae",
    "mean_absolute_percentage_error": "mape",
    "symmetric_mean_absolute_percentage_error": "smape",
    "weighted_absolute_percentage_error": "wape",
    "mean_absolute_scaled_error": "mase",
    "f1_score": "f1",
    "auc": "roc_auc",
    "auc_roc": "roc_auc",
    "roc-auc": "roc_auc",
    "roc auc": "roc_auc",
    "pr-auc": "pr_auc",
    "pr auc": "pr_auc",
    "average_precision": "pr_auc",
    "balanced-accuracy": "balanced_accuracy",
    "balanced accuracy": "balanced_accuracy",
    "dbi": "davies_bouldin",
    "davies-bouldin": "davies_bouldin",
    "davies bouldin": "davies_bouldin",
    "calinski-harabasz": "calinski_harabasz",
    "calinski harabasz": "calinski_harabasz",
    "rouge-l": "rouge_l",
    "bert_score": "bertscore",
}


def explain(
    metrics: Any = None,
    /,
    *,
    task: str | None = None,
    metric: str | None = None,
    value: float | int | None = None,
    audience: str = "beginner",
    tone: str = "casual",
    detail: str = "standard",
    include_scale_tips: bool = True,
    include_warnings: bool = True,
    include_next_steps: bool = False,
    thresholds: dict[str, Iterable[tuple[float, str]]] | None = None,
    aliases: dict[str, str] | None = None,
    strict: bool = False,
    sort_metrics: bool = True,
    return_format: str = "text",
) -> str | dict[str, Any] | list[dict[str, Any]]:
    """
    Explain one or more ML metrics in plain English.

    Parameters
    ----------
    metrics:
        A metric dictionary, an iterable of ``(name, value)`` pairs, or ``None``.
    task:
        Optional task hint such as ``regression``, ``classification``, or ``clustering``.
    metric, value:
        Convenience inputs for a single metric call, e.g. ``explain(metric="rmse", value=12.4)``.
    audience:
        One of ``beginner``, ``product``, ``data_science``, or ``exec``.
    tone:
        One of ``casual``, ``neutral``, ``hype``, or ``blunt``.
    detail:
        One of ``short``, ``standard``, or ``detailed``.
    include_scale_tips:
        Whether to mention when a metric depends on target scale or problem setup.
    include_warnings:
        Whether to add caveats and footguns.
    include_next_steps:
        Whether to add practical next-step suggestions.
    thresholds:
        Optional per-metric custom interpretation bands.
    aliases:
        Optional metric name aliases to merge with the built-in alias map.
    strict:
        If ``True``, unknown metrics raise ``ValueError``.
    sort_metrics:
        If ``True``, output is sorted by task then metric label.
    return_format:
        ``text``, ``dict``, or ``list``.
    """
    audience = _validate_choice("audience", audience, {"beginner", "product", "data_science", "exec"})
    tone = _validate_choice("tone", tone, {"casual", "neutral", "hype", "blunt"})
    detail = _validate_choice("detail", detail, {"short", "standard", "detailed"})
    return_format = _validate_choice("return_format", return_format, {"text", "dict", "list"})

    normalized_metrics = _coerce_metrics(metrics, metric=metric, value=value)
    if not normalized_metrics:
        raise ValueError("No metrics provided. Pass a metric dict or metric/value pair.")

    merged_aliases = {**_ALIASES, **(aliases or {})}
    custom_thresholds = {(_normalize_name(k)): tuple(v) for k, v in (thresholds or {}).items()}

    items: list[dict[str, Any]] = []
    for raw_name, raw_value in normalized_metrics.items():
        canonical_name = _canonicalize_metric_name(raw_name, merged_aliases)
        spec = _METRIC_SPECS.get(canonical_name)

        if spec is None:
            if strict:
                raise ValueError(f"Unknown metric: {raw_name!r}")
            items.append(_build_unknown_metric_payload(raw_name, raw_value, task))
            continue

        item_task = task or spec.task
        item_thresholds = custom_thresholds.get(canonical_name, spec.interpretation)
        items.append(
            _build_metric_payload(
                spec=spec,
                value=float(raw_value),
                task=item_task,
                audience=audience,
                tone=tone,
                detail=detail,
                include_scale_tips=include_scale_tips,
                include_warnings=include_warnings,
                include_next_steps=include_next_steps,
                thresholds=item_thresholds,
            )
        )

    if sort_metrics:
        items.sort(key=lambda item: (item["task"], item["metric"]))

    if return_format == "list":
        return items

    grouped = _group_items(items)
    if return_format == "dict":
        return grouped
    return _render_text(grouped, audience=audience, tone=tone, detail=detail)


def _coerce_metrics(
    metrics: Any,
    *,
    metric: str | None,
    value: float | int | None,
) -> dict[str, float | int]:
    if metric is not None:
        if value is None:
            raise ValueError("If 'metric' is provided, 'value' is required too.")
        return {metric: value}

    if metrics is None:
        return {}

    if isinstance(metrics, dict):
        return metrics

    if isinstance(metrics, (list, tuple)):
        if all(isinstance(item, tuple) and len(item) == 2 for item in metrics):
            return dict(metrics)

    raise TypeError(
        "metrics must be a dict, an iterable of (name, value) pairs, or use metric/value keywords."
    )


def _normalize_name(name: str) -> str:
    return (
        name.strip()
        .lower()
        .replace("%", "pct")
        .replace("-", "_")
        .replace(" ", "_")
        .replace("/", "_")
    )


def _validate_choice(name: str, value: str, allowed: set[str]) -> str:
    normalized = _normalize_name(value)
    if normalized not in allowed:
        options = ", ".join(sorted(allowed))
        raise ValueError(f"{name} must be one of: {options}")
    return normalized


def _canonicalize_metric_name(name: str, aliases: dict[str, str]) -> str:
    normalized = _normalize_name(name)
    return aliases.get(normalized, normalized)


def _build_metric_payload(
    *,
    spec: MetricSpec,
    value: float,
    task: str,
    audience: str,
    tone: str,
    detail: str,
    include_scale_tips: bool,
    include_warnings: bool,
    include_next_steps: bool,
    thresholds: tuple[tuple[float, str], ...] | None,
) -> dict[str, Any]:
    vibe = _rating_for_metric(value, spec.direction, thresholds)
    summary = _make_summary(spec, value, vibe, audience, tone)
    explanation = _make_explanation(spec, value, vibe, detail, include_scale_tips)
    warnings = _make_warnings(spec, include_warnings)
    next_steps = _make_next_steps(spec, vibe, include_next_steps)

    return {
        "metric": spec.label,
        "canonical_name": spec.canonical_name,
        "task": task,
        "value": value,
        "direction": spec.direction,
        "rating": vibe["label"],
        "summary": summary,
        "explanation": explanation,
        "warnings": warnings,
        "next_steps": next_steps,
    }


def _build_unknown_metric_payload(name: str, value: Any, task: str | None) -> dict[str, Any]:
    return {
        "metric": name,
        "canonical_name": _normalize_name(name),
        "task": task or "unknown",
        "value": value,
        "direction": "unknown",
        "rating": "unknown",
        "summary": f"{name} = {value}. I do not have a built-in explainer for this metric yet.",
        "explanation": "If you know whether higher or lower is better, pass that context alongside this result.",
        "warnings": ["Unknown metrics are returned without a quality judgment."],
        "next_steps": [],
    }


def _rating_for_metric(
    value: float,
    direction: str,
    thresholds: tuple[tuple[float, str], ...] | None,
) -> dict[str, str]:
    if not thresholds:
        return {"label": "context-dependent", "sentence": "This one is mostly useful for relative comparison."}

    if direction == "higher":
        total = len(thresholds)
        for index, (cutoff, text) in enumerate(thresholds):
            if value < cutoff:
                if index == 0:
                    label = "weak"
                elif index == total - 1:
                    label = "strong"
                else:
                    label = "okay"
                return {"label": label, "sentence": text}
        return {"label": "excellent", "sentence": thresholds[-1][1]}

    ordered = sorted(thresholds, key=lambda item: item[0])
    total = len(ordered)
    for index, (cutoff, text) in enumerate(ordered):
        if value <= cutoff:
            if index == 0:
                label = "excellent"
            elif index == total - 1:
                label = "okay"
            else:
                label = "strong"
            return {"label": label, "sentence": text}
    return {"label": "weak", "sentence": ordered[-1][1]}


def _make_summary(spec: MetricSpec, value: float, vibe: dict[str, str], audience: str, tone: str) -> str:
    label = spec.label
    intro = {
        "casual": "Quick read",
        "neutral": "Interpretation",
        "hype": "Score check",
        "blunt": "Reality check",
    }.get(tone, "Interpretation")

    audience_tail = {
        "beginner": "in plain English",
        "product": "for product decisions",
        "data_science": "for model evaluation",
        "exec": "for a high-level readout",
    }.get(audience, "in plain English")

    sentence = vibe["sentence"].rstrip(".")
    return f"{intro}: {label} = {_format_value(value)}. This is {audience_tail}; {sentence}."


def _make_explanation(
    spec: MetricSpec,
    value: float,
    vibe: dict[str, str],
    detail: str,
    include_scale_tips: bool,
) -> str:
    base = f"{spec.label} tells you {spec.plain_english}."
    value_line = f" For this run, {_metric_direction_text(spec.direction)} value of {_format_value(value)} looks {vibe['label']}."

    extra = ""
    if include_scale_tips and spec.scale_dependent:
        extra = " Its meaning depends a lot on the scale of your target, so compare it with typical real-world error."

    if detail == "short":
        return base + value_line
    if detail == "detailed" and spec.notes:
        return base + value_line + extra + " " + " ".join(spec.notes)
    return base + value_line + extra


def _make_warnings(spec: MetricSpec, include_warnings: bool) -> list[str]:
    if not include_warnings:
        return []
    return list(spec.notes)


def _make_next_steps(spec: MetricSpec, vibe: dict[str, str], include_next_steps: bool) -> list[str]:
    if not include_next_steps:
        return []

    generic_steps = {
        "regression": [
            "Compare against a baseline like predicting the mean or last known value.",
            "Plot prediction error so you can see whether the misses are concentrated on certain ranges.",
        ],
        "classification": [
            "Check the confusion matrix before trusting a single summary score.",
            "Tune the decision threshold if precision and recall trade-offs matter.",
        ],
        "clustering": [
            "Compare multiple values of k instead of trusting one run.",
            "Inspect actual cluster examples to see whether the groups are meaningful.",
        ],
        "forecasting": [
            "Compare against a naive forecast baseline.",
            "Review errors by seasonality, time window, and sudden spikes.",
        ],
        "ranking": [
            "Inspect the top results manually for a few representative queries.",
            "Break metrics out by query segment or user cohort.",
        ],
        "generative": [
            "Pair automatic scores with human review for quality, usefulness, and correctness.",
            "Test on examples where wording differs but meaning stays the same.",
        ],
    }
    return generic_steps.get(spec.task, [])


def _metric_direction_text(direction: str) -> str:
    if direction == "higher":
        return "a higher"
    if direction == "lower":
        return "a lower"
    return "this"


def _format_value(value: float) -> str:
    if abs(value) >= 1000:
        return f"{value:,.2f}"
    if abs(value) >= 1:
        return f"{value:.3f}".rstrip("0").rstrip(".")
    return f"{value:.4f}".rstrip("0").rstrip(".")


def _group_items(items: list[dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[str, list[dict[str, Any]]] = {}
    for item in items:
        grouped.setdefault(item["task"], []).append(item)
    return {"tasks": grouped, "items": items}


def _render_text(grouped: dict[str, Any], *, audience: str, tone: str, detail: str) -> str:
    lines: list[str] = []
    opener = _pick_opener(audience=audience, tone=tone, count=len(grouped["items"]))
    if opener:
        lines.append(opener)

    for task_name, task_items in grouped["tasks"].items():
        if len(grouped["tasks"]) > 1:
            lines.append("")
            lines.append(f"[{task_name}]")
        for item in task_items:
            lines.append(f"- {item['summary']}")
            if detail != "short":
                lines.append(f"  {item['explanation']}")
            for warning in item["warnings"]:
                lines.append(f"  Watch out: {warning}")
            for step in item["next_steps"]:
                lines.append(f"  Next: {step}")

    return "\n".join(lines).strip()


def _pick_opener(*, audience: str, tone: str, count: int) -> str:
    if count == 1:
        return {
            "casual": "Metric vibes:",
            "neutral": "Metric summary:",
            "hype": "Model score energy:",
            "blunt": "Here is the honest read:",
        }.get(tone, "Metric summary:")
    return {
        "casual": "Metric vibes, one by one:",
        "neutral": "Metric summary by score:",
        "hype": "Scoreboard time:",
        "blunt": "Here is the honest readout:",
    }.get(tone, "Metric summary by score:")
