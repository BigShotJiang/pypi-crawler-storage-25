from __future__ import annotations


import argparse
import json

from .core import *

def main(argv=None):


    parser_cli = argparse.ArgumentParser(prog="mooncal", description="Moontime CLI: temporal time and lunar date")
    sub = parser_cli.add_subparsers(dest="cmd")

    p_now = sub.add_parser("now", help="Show current moontime")
    p_now.add_argument("--zone", help="Timezone name (e.g., Europe/Athens)")
    p_now.add_argument("--coords", help="Lat,Lng (e.g., 37.24,25.1603)")
    p_now.add_argument("--json", action="store_true", help="Output JSON")
    p_now.add_argument("--moon-only", action="store_true", help="Print only compact moon string: '<illum%> <angle>° <wx|wn>'")
    p_now.add_argument("--lunar-only", action="store_true", help="Print only lunar temporal time: 'L↑ HH:MM:SS' or 'L↓ HH:MM:SS'")
    p_now.add_argument("--sun-time", action="store_true", help="Show legacy solar/temporal display instead of moon-first output")
    p_now.add_argument("--planet-time", choices=["sun","moon","mercury","venus","mars","jupiter","saturn"], help="Print only temporal time for the given body")
    # Convenience flags for first seven
    p_now.add_argument("--mercury-time", action="store_true")
    p_now.add_argument("--venus-time", action="store_true")
    p_now.add_argument("--mars-time", action="store_true")
    p_now.add_argument("--jupiter-time", action="store_true")
    p_now.add_argument("--saturn-time", action="store_true")
    p_now.add_argument("--sun-provider", choices=["auto","aether","twilight"], help="Sunrise/sunset provider for temporal hours")

    p_at = sub.add_parser("at", help="Show moontime at a given timestamp")
    p_at.add_argument("timestamp", help="Datetime (ISO/RFC), e.g., 2025-04-01T12:34:56")
    p_at.add_argument("--zone", help="Timezone name for interpretation if naive")
    p_at.add_argument("--coords", help="Lat,Lng (e.g., 37.24,25.1603)")
    p_at.add_argument("--json", action="store_true", help="Output JSON")
    p_at.add_argument("--moon-only", action="store_true", help="Print only compact moon string: '<illum%> <angle>° <wx|wn>'")
    p_at.add_argument("--lunar-only", action="store_true", help="Print only lunar temporal time: 'L↑ HH:MM:SS' or 'L↓ HH:MM:SS'")
    p_at.add_argument("--sun-time", action="store_true", help="Show legacy solar/temporal display instead of moon-first output")
    p_at.add_argument("--planet-time", choices=["sun","moon","mercury","venus","mars","jupiter","saturn"], help="Print only temporal time for the given body")
    p_at.add_argument("--mercury-time", action="store_true")
    p_at.add_argument("--venus-time", action="store_true")
    p_at.add_argument("--mars-time", action="store_true")
    p_at.add_argument("--jupiter-time", action="store_true")
    p_at.add_argument("--saturn-time", action="store_true")
    p_at.add_argument("--sun-provider", choices=["auto","aether","twilight"], help="Sunrise/sunset provider for temporal hours")

    args = parser_cli.parse_args(argv)
    if not args.cmd:
        parser_cli.print_help()
        return 2

    # Allow explicit provider selection via CLI
    sp = getattr(args, "sun_provider", None)
    if sp:
        os.environ["MOONTIME_SUN_PROVIDER"] = sp

    try:

        z = get_pytz_timezone(args.zone) if getattr(args, "zone", None) else None
        c = args.coords if getattr(args, "coords", None) else None
    except Exception:
        z, c = None, None
    if args.cmd == "now":
        if not z or c:
            mt = MoonTime.now()
        else:
            mt = MoonTime.now(zone=z, coords=c)
        if args.json:
            print(json.dumps({k:(v.isoformat() if hasattr(v, 'isoformat') else v) for k,v in mt.as_dict().items()}, indent=2))
        else:
            # Planet time overrides
            body = None
            if getattr(args, 'planet_time', None):
                body = args.planet_time
            elif getattr(args, 'mercury_time', False):
                body = 'mercury'
            elif getattr(args, 'venus_time', False):
                body = 'venus'
            elif getattr(args, 'mars_time', False):
                body = 'mars'
            elif getattr(args, 'jupiter_time', False):
                body = 'jupiter'
            elif getattr(args, 'saturn_time', False):
                body = 'saturn'
            if body:
                print(mt.planetary_temporal_hms(body))
                return 0
            if getattr(args, 'moon_only', False):
                print(mt.moon_summary)
                return 0
            if getattr(args, 'lunar_only', False):
                print(mt.lunar_temporal_hms())
                return 0
            if getattr(args, 'sun_time', False):
                print(mt.display_str)
                try:
                    print(mt.seasonal_summary)
                except Exception:
                    pass
            else:
                # Default moon-first output: "wx|wn {illum%} {angle}° {lunar_temp}"
                phase = (getattr(mt, 'moon_phase', '') or '').strip().lower()
                code = 'wx' if (phase.startswith('wax') or 'first quarter' in phase or phase.startswith('new')) else (
                       'wn' if (phase.startswith('wan') or 'last quarter' in phase or phase.startswith('full')) else '?')
                illum_raw = getattr(mt, 'moon_illum', 0) or 0
                illum = (illum_raw / 1000.0) if illum_raw > 100 else (illum_raw / 100.0)
                try:
                    illum = float(illum)
                except Exception:
                    illum = 0.0
                illum = 0.0 if illum < 0 else (1.0 if illum > 1 else illum)
                illum_pct = int(round(illum * 100))
                ang = getattr(mt, 'moon_angle', 0.0) or 0.0
                try:
                    ang_i = int(round(float(ang)))
                except Exception:
                    ang_i = 0
                print(f"{code} {illum_pct}% {ang_i}° {mt.lunar_temporal_hms()}")
        return 0

    if args.cmd == "at":
        dt = parser.parse(args.timestamp)
        mt = MoonTime.from_datetime(dt, zone=z, coords=c)
        if args.json:
            print(json.dumps({k:(v.isoformat() if hasattr(v, 'isoformat') else v) for k,v in mt.as_dict().items()}, indent=2))
        else:
            body = None
            if getattr(args, 'planet_time', None):
                body = args.planet_time
            elif getattr(args, 'mercury_time', False):
                body = 'mercury'
            elif getattr(args, 'venus_time', False):
                body = 'venus'
            elif getattr(args, 'mars_time', False):
                body = 'mars'
            elif getattr(args, 'jupiter_time', False):
                body = 'jupiter'
            elif getattr(args, 'saturn_time', False):
                body = 'saturn'
            if body:
                print(_planet_temporal_hms(mt, body))
                return 0
            if getattr(args, 'moon_only', False):
                print(mt.moon_summary)
                return 0
            if getattr(args, 'lunar_only', False):
                print(mt.lunar_temporal_hms())
                return 0
            if getattr(args, 'sun_time', False):
                print(mt.display_str)
                try:
                    print(mt.seasonal_summary)
                except Exception:
                    pass
            else:
                phase = (getattr(mt, 'moon_phase', '') or '').strip().lower()
                code = 'wx' if (phase.startswith('wax') or 'first quarter' in phase or phase.startswith('new')) else (
                       'wn' if (phase.startswith('wan') or 'last quarter' in phase or phase.startswith('full')) else '?')
                illum_raw = getattr(mt, 'moon_illum', 0) or 0
                illum = (illum_raw / 1000.0) if illum_raw > 100 else (illum_raw / 100.0)
                try:
                    illum = float(illum)
                except Exception:
                    illum = 0.0
                illum = 0.0 if illum < 0 else (1.0 if illum > 1 else illum)
                illum_pct = int(round(illum * 100))
                ang = getattr(mt, 'moon_angle', 0.0) or 0.0
                try:
                    ang_i = int(round(float(ang)))
                except Exception:
                    ang_i = 0
                print(f"{code} {illum_pct}% {ang_i}° {mt.lunar_temporal_hms()}")
        return 0

    return 1

if __name__ == '__main__':
    raise SystemExit(main())
