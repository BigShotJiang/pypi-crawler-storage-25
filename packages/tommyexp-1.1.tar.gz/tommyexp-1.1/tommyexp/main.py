import re


def phone(number):

    pattern = r"^[6-9]\d{9}$"

    return bool(re.match(pattern, str(number)))


def gmail(email):

    pattern = r"^[a-zA-Z0-9._%+-]+@gmail\.com$"

    return bool(re.match(pattern, email))


def ifsc(code):

    pattern = r"^SBIN0\d{6}$"

    return bool(re.match(pattern, code))