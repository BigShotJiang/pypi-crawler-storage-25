from setuptools import setup, find_packages

with open("Readme.md", "r") as f:
    long_description = f.read()

setup(
    name="tommyexp",
    version="1.1",
    author="Sandeep Nallamothu",
    description="validation package for Indian phone numbers, gmail and SBI IFSC codes",
    packages=find_packages(),
    install_requires=[
    
    ],
    entry_points={
        "console_scripts": [
            "tommy-exp = tommyexp.cli:main"
        ],
    },
    long_description=long_description,
    long_description_content_type="text/markdown",
)

#pypi-AgEIcHlwaS5vcmcCJDA4MzY4ZDViLWIwZTAtNDI1NC1hODgwLWM5MWE5N2QzNGJkMwACKlszLCIyOTZjMmQwYS1jYWRmLTRlNzEtOWY2Mi01NGNmNGU5YzA0ZDMiXQAABiCTWH8e9e-M-rclFvTdyzpwrTQav3LjfzvexsOAcWGNvg