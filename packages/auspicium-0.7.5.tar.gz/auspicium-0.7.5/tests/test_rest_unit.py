"""Unit tests for auspicium.connectors.rest — respx-mocked, no network.

Integration tests (tests/test_rest.py) exercise the real Kong + FastAPI stack.
These tests cover the new v0.7.1 additions: ``RestConnector.account`` and
``include_meta`` on ``RestConnector.ohlcv``.
"""
from __future__ import annotations

import httpx
import pytest
import respx


@pytest.fixture(autouse=True)
def _set_config(monkeypatch):
    """Stub a test gateway + API key so get_config() succeeds."""
    monkeypatch.setenv("AUSP_API_KEY", "unit-test-key")
    monkeypatch.setenv("AUSP_GATEWAY_URL", "https://test.example")
    from auspicium.config import reset_config
    reset_config()
    yield
    reset_config()


@respx.mock
def test_account_returns_nested_shape():
    from auspicium.connectors.rest import RestConnector

    RestConnector.close()  # rebuild client against the mock transport

    expected = {
        "tier": "starter",
        "limits": {
            "rest": {
                "max_bars_per_request": 100,
                "max_requests_per_minute": 10,
                "max_history_days": 7,
                "allowed_intervals": ["1m", "5m", "1h", "1d"],
                "allowed_exchanges": ["binance"],
                "allowed_symbols": ["BTC-USDT", "ETH-USDT"],
            },
            "websocket": {
                "max_connections": 1,
                "max_subscriptions_per_connection": 2,
                "allowed_intervals": ["1h"],
            },
            "backtest": {"max_window_days": 7, "max_concurrent": 1},
            "production": {"max_bots": 0, "allowed_exchanges": []},
        },
        "usage": {
            "rest_requests_this_minute": 3,
            "websocket_connections": 1,
            "active_bots": 0,
        },
    }
    respx.get("https://test.example/v1/account").mock(
        return_value=httpx.Response(200, json=expected)
    )

    result = RestConnector.account()
    assert result == expected
    assert result["limits"]["rest"]["allowed_intervals"] == ["1m", "5m", "1h", "1d"]
    assert result["usage"]["rest_requests_this_minute"] == 3


@respx.mock
def test_ohlcv_include_meta_populates_last_meta():
    from auspicium.connectors.rest import RestConnector

    RestConnector.close()
    RestConnector.last_meta = None

    respx.get("https://test.example/v1/ohlcv/binance/BTC-USDT").mock(
        return_value=httpx.Response(200, json={
            "source": "binance", "symbol": "BTC-USDT", "interval": "1m",
            "count": 100,
            "data": [],
            "meta": {
                "tier": "starter",
                "bars_returned": 100,
                "bars_requested": 500,
                "bars_available": 2016,
                "limit_applied": True,
                "max_bars_per_request": 100,
                "oldest_available": "2026-04-11T00:00:00+00:00",
                "upgrade_hint": "Upgrade to Pro tier for up to 1,000 bars per request",
            },
        })
    )

    df = RestConnector.ohlcv("binance", "BTC-USDT", include_meta=True, limit=500)
    assert df.empty  # data list was empty in the mock
    assert RestConnector.last_meta is not None
    assert RestConnector.last_meta["bars_requested"] == 500
    assert RestConnector.last_meta["bars_returned"] == 100
    assert RestConnector.last_meta["limit_applied"] is True
    assert RestConnector.last_meta["upgrade_hint"].startswith("Upgrade to Pro")


@respx.mock
def test_ohlcv_does_not_surface_meta_without_flag():
    """v0.7.2: the first call always asks for meta (to drive pagination),
    but ``last_meta`` only surfaces it when the caller opted in."""
    from auspicium.connectors.rest import RestConnector

    RestConnector.close()
    RestConnector.last_meta = "sentinel"

    respx.get("https://test.example/v1/ohlcv/binance/BTC-USDT").mock(
        return_value=httpx.Response(200, json={
            "source": "binance", "symbol": "BTC-USDT", "interval": "1m",
            "count": 0, "data": [],
            "meta": {"tier": "starter", "bars_returned": 0,
                     "bars_requested": 500, "bars_available": 0,
                     "limit_applied": False, "max_bars_per_request": 100,
                     "oldest_available": None, "upgrade_hint": None},
        })
    )
    RestConnector.ohlcv("binance", "BTC-USDT")
    # Without include_meta, the block is not exposed to the caller.
    assert RestConnector.last_meta is None


@respx.mock
def test_ohlcv_auto_paginates_when_tier_caps():
    """When limit_applied=True and bars_available>page, fetch additional pages."""
    from auspicium.connectors.rest import RestConnector

    RestConnector.close()
    RestConnector.last_meta = None

    # Three mock pages returning DESC-ordered rows — newest first. The next
    # page's `to=<oldest_time_of_previous_page>` skips back in time.
    def _bar(t: str, close: float) -> dict:
        return {
            "time": t, "symbol": "BTC-USDT", "exchange": "binance",
            "open": close, "high": close, "low": close, "close": close, "volume": 1.0,
        }

    page_1 = {
        "data": [_bar("2026-04-18T10:00:00+00:00", 100.0),
                 _bar("2026-04-18T09:00:00+00:00", 99.0)],
        "meta": {"tier": "starter", "bars_returned": 2, "bars_requested": 5,
                 "bars_available": 5, "limit_applied": True,
                 "max_bars_per_request": 2, "oldest_available": "2026-04-11T00:00:00+00:00",
                 "upgrade_hint": "Upgrade for more"},
    }
    page_2 = {
        "data": [_bar("2026-04-18T08:00:00+00:00", 98.0),
                 _bar("2026-04-18T07:00:00+00:00", 97.0)],
    }
    page_3 = {
        "data": [_bar("2026-04-18T06:00:00+00:00", 96.0)],
    }
    responses = [page_1, page_2, page_3]

    def _respond(request):
        return httpx.Response(200, json=responses.pop(0))

    respx.get("https://test.example/v1/ohlcv/binance/BTC-USDT").mock(side_effect=_respond)

    with pytest.warns(UserWarning, match="Auto-paginated"):
        # patch time.sleep so the test isn't slow
        import auspicium.connectors.rest as rest_mod
        orig_sleep = rest_mod.time.sleep
        rest_mod.time.sleep = lambda _s: None
        try:
            df = RestConnector.ohlcv("binance", "BTC-USDT", limit=5)
        finally:
            rest_mod.time.sleep = orig_sleep

    # Across the 3 pages we got 2 + 2 + 1 = 5 bars.
    assert len(df) == 5


@respx.mock
def test_cross_market_accepts_from_to_window():
    """v0.7.5: cross_market() forwards from_ts/to_ts and drops `hours`."""
    from auspicium.connectors.rest import RestConnector
    from datetime import datetime, timezone
    RestConnector.close()

    route = respx.get("https://test.example/v1/cross-market").mock(
        return_value=httpx.Response(200, json={
            "granularity": "5m", "count": 0, "data": [],
            "meta": {"tier": "pro", "bars_returned": 0, "bars_requested": 500,
                     "bars_available": 0, "limit_applied": False,
                     "max_bars_per_request": 1000, "oldest_available": None,
                     "upgrade_hint": None},
        })
    )
    frm = datetime(2026, 4, 10, tzinfo=timezone.utc)
    to  = datetime(2026, 4, 17, tzinfo=timezone.utc)
    RestConnector.cross_market(
        granularity="5m", base_asset="BTC", from_ts=frm, to_ts=to, limit=500,
    )
    params = route.calls[-1].request.url.params
    assert params["from"] == frm.isoformat()
    assert params["to"] == to.isoformat()
    assert "hours" not in params   # dropped when explicit window is set


@respx.mock
def test_cross_market_falls_back_to_hours():
    """Without from/to, cross_market() keeps the v0.7.4 `hours` behaviour."""
    from auspicium.connectors.rest import RestConnector
    RestConnector.close()

    route = respx.get("https://test.example/v1/cross-market").mock(
        return_value=httpx.Response(200, json={
            "granularity": "5m", "count": 0, "data": [],
            "meta": {"tier": "pro", "bars_returned": 0, "bars_requested": 500,
                     "bars_available": 0, "limit_applied": False,
                     "max_bars_per_request": 1000, "oldest_available": None,
                     "upgrade_hint": None},
        })
    )
    RestConnector.cross_market(granularity="5m", base_asset="BTC", hours=4)
    params = route.calls[-1].request.url.params
    assert params["hours"] == "4"
    assert "from" not in params and "to" not in params


@respx.mock
def test_cross_market_auto_paginates():
    """Same pagination semantics as ohlcv(): walk older pages on tier cap."""
    from auspicium.connectors.rest import RestConnector
    RestConnector.close()

    def _bar(t: str, close: float) -> dict:
        return {
            "time": t, "granularity": "5m", "base_asset": "BTC",
            "condition_id": "0xabc", "binance_open": close, "binance_high": close,
            "binance_low": close, "binance_close": close, "binance_volume": 1.0,
            "polymarket_up_open": 0.5, "polymarket_up_high": 0.5,
            "polymarket_up_low": 0.5, "polymarket_up_close": 0.5,
            "polymarket_up_volume": 0.0, "poly_price_ticks": 0,
            "poly_trade_count": 0, "is_provisional": False,
        }

    page_1 = {
        "granularity": "5m", "count": 2,
        "data": [_bar("2026-04-24T10:00:00+00:00", 100.0),
                 _bar("2026-04-24T09:55:00+00:00", 99.0)],
        "meta": {"tier": "pro", "bars_returned": 2, "bars_requested": 5,
                 "bars_available": 5, "limit_applied": True,
                 "max_bars_per_request": 2, "oldest_available": None,
                 "upgrade_hint": "Upgrade"},
    }
    page_2 = {"granularity": "5m", "count": 2,
              "data": [_bar("2026-04-24T09:50:00+00:00", 98.0),
                       _bar("2026-04-24T09:45:00+00:00", 97.0)]}
    page_3 = {"granularity": "5m", "count": 1,
              "data": [_bar("2026-04-24T09:40:00+00:00", 96.0)]}
    responses = [page_1, page_2, page_3]
    respx.get("https://test.example/v1/cross-market").mock(
        side_effect=lambda r: httpx.Response(200, json=responses.pop(0))
    )

    import auspicium.connectors.rest as rest_mod
    orig_sleep = rest_mod.time.sleep
    rest_mod.time.sleep = lambda _s: None
    try:
        with pytest.warns(UserWarning, match="Auto-paginated"):
            df = RestConnector.cross_market(
                granularity="5m", base_asset="BTC", limit=5,
            )
    finally:
        rest_mod.time.sleep = orig_sleep

    assert len(df) == 5


@respx.mock
def test_cross_market_include_meta_surfaces_last_meta():
    from auspicium.connectors.rest import RestConnector
    RestConnector.close()
    RestConnector.last_meta = None

    respx.get("https://test.example/v1/cross-market").mock(
        return_value=httpx.Response(200, json={
            "granularity": "5m", "count": 0, "data": [],
            "meta": {"tier": "pro", "bars_returned": 0, "bars_requested": 500,
                     "bars_available": 0, "limit_applied": False,
                     "max_bars_per_request": 1000, "oldest_available": None,
                     "upgrade_hint": None},
        })
    )
    RestConnector.cross_market(granularity="5m", base_asset="BTC", include_meta=True)
    assert RestConnector.last_meta is not None
    assert RestConnector.last_meta["tier"] == "pro"


@respx.mock
def test_ohlcv_paginate_false_restores_single_request_behaviour():
    """paginate=False keeps the v0.7.1 one-shot behaviour even when capped."""
    from auspicium.connectors.rest import RestConnector
    RestConnector.close()

    route = respx.get("https://test.example/v1/ohlcv/binance/BTC-USDT").mock(
        return_value=httpx.Response(200, json={
            "data": [{"time": "2026-04-18T10:00:00+00:00", "symbol": "BTC-USDT",
                      "exchange": "binance", "open": 1.0, "high": 1.0,
                      "low": 1.0, "close": 1.0, "volume": 0.0}],
            "meta": {"tier": "starter", "bars_returned": 1, "bars_requested": 5,
                     "bars_available": 5, "limit_applied": True,
                     "max_bars_per_request": 1, "oldest_available": None,
                     "upgrade_hint": None},
        })
    )
    df = RestConnector.ohlcv("binance", "BTC-USDT", limit=5, paginate=False)
    assert len(df) == 1
    assert len(route.calls) == 1   # no follow-up page request
