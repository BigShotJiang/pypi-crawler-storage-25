"""REST connector — httpx against Kong → FastAPI (/v1/*).

All requests carry:
  X-API-Key: <key>
  User-Agent: auspicium-sdk/<version>

On HTTP 429 the connector waits Retry-After seconds and retries up to 3 times.
Kong rate-limit headers are parsed and exposed via RestConnector.last_rate_limit.
"""
from __future__ import annotations

import time
import warnings
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
import pandas as pd

from auspicium._version import __version__
from auspicium.config import get_config
from auspicium.errors import (
    AuthError,
    ConnectionError,
    QueryTimeoutError,
    RateLimitError,
    TierRestrictionError,
)

_MAX_RETRIES = 3


def _to_df(rows: list[dict], time_col: str = "time") -> pd.DataFrame:
    """Convert a list of row dicts to a DataFrame with a UTC DatetimeIndex."""
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)
    if time_col in df.columns:
        df[time_col] = pd.to_datetime(df[time_col], utc=True)
        df = df.set_index(time_col).sort_index()
    return df


class RestConnector:
    """Synchronous REST connector.  Use as a module-level singleton via ``auspicium.rest``.

    Example::

        from auspicium import rest
        df = rest.ohlcv("binance", "BTC-USDT", interval="5m", days=1)
    """

    _client: httpx.Client | None = None

    # Parsed from the last response — useful for quota monitoring
    last_rate_limit: dict = {}

    # Populated when a method is called with ``include_meta=True`` and the
    # server returned a ``meta`` block (see :meth:`ohlcv`).  Reset to ``None``
    # on any subsequent call that does not include a ``meta`` block.
    last_meta: dict | None = None

    # ------------------------------------------------------------------ #
    # Internal                                                             #
    # ------------------------------------------------------------------ #

    @classmethod
    def _get_client(cls) -> httpx.Client:
        if cls._client is None or cls._client.is_closed:
            cfg = get_config()
            cls._client = httpx.Client(
                base_url=cfg.gateway_url,
                headers={
                    "X-API-Key": cfg.api_key,
                    "User-Agent": f"auspicium-sdk/{__version__}",
                },
                timeout=60.0,
            )
        return cls._client

    @classmethod
    def _request(cls, method: str, path: str, **kwargs) -> Any:
        client = cls._get_client()
        for attempt in range(_MAX_RETRIES):
            try:
                resp = client.request(method, path, **kwargs)
            except httpx.ConnectError as exc:
                raise ConnectionError(f"Could not reach {path}: {exc}") from exc
            except httpx.TimeoutException as exc:
                raise QueryTimeoutError(
                    f"Request to {path} timed out. Try narrowing your time range."
                ) from exc

            # Parse rate-limit headers regardless of status (Kong 3.x uses -Minute suffix)
            cls.last_rate_limit = {
                k: resp.headers.get(k)
                for k in (
                    "x-ratelimit-limit-minute", "x-ratelimit-remaining-minute",
                    "ratelimit-limit", "ratelimit-remaining", "ratelimit-reset",
                )
                if resp.headers.get(k)
            }

            if resp.status_code == 401:
                raise AuthError("Invalid or missing API key (HTTP 401). Check AUSP_API_KEY.")
            if resp.status_code == 403:
                raise TierRestrictionError(
                    f"{resp.json().get('detail', 'Forbidden')} — upgrade your tier to access this."
                )
            if resp.status_code == 429:
                retry_after = int(resp.headers.get("retry-after", 60))
                if attempt == 0:
                    warnings.warn(
                        f"Rate limited. Retrying in {retry_after}s "
                        f"({_MAX_RETRIES - 1 - attempt} attempt(s) left).",
                        stacklevel=3,
                    )
                if attempt < _MAX_RETRIES - 1:
                    time.sleep(retry_after)
                    continue
                raise RateLimitError(
                    f"Rate limit exceeded after {_MAX_RETRIES} attempts. "
                    "Wait or upgrade your tier."
                )
            if resp.status_code == 504:
                raise QueryTimeoutError(
                    "Gateway timeout — query likely exceeded statement_timeout for your tier. "
                    "Narrow your time range or upgrade."
                )
            resp.raise_for_status()
            return resp.json()

        raise RateLimitError("Exhausted retries.")  # unreachable but satisfies type checkers

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    @classmethod
    def ohlcv(
        cls,
        source: str,
        symbol: str,
        interval: str = "1m",
        days: int = 1,
        from_ts: datetime | None = None,
        to_ts: datetime | None = None,
        limit: int = 500,
        include_meta: bool = False,
        paginate: bool = True,
    ) -> pd.DataFrame:
        """OHLCV candlestick data.

        When the tier caps a single response below ``limit`` and more bars are
        available within the allowed window, this method auto-paginates to
        fulfil the request (up to ``bars_available`` for the clamped window).
        Each additional request is gated by a 500 ms courtesy sleep and the
        final result is accompanied by a ``UserWarning`` so callers notice
        their tier is costing them round-trips.

        Args:
            source:       ``"binance"``
            symbol:       e.g. ``"BTC-USDT"``
            interval:     ``"1m"`` | ``"5m"`` | ``"1h"`` | ``"1d"``
            days:         lookback in days (ignored when ``from_ts`` is set)
            from_ts:      explicit start (UTC-aware datetime)
            to_ts:        explicit end   (UTC-aware datetime, defaults to now)
            limit:        max rows to materialise (across all pages if paginating)
            include_meta: when True, the first response's ``meta`` block is
                          stored on :attr:`RestConnector.last_meta` so callers
                          can inspect clamp state + upgrade hints after the call.
            paginate:     when True (default) and the tier caps a single
                          response, keep requesting older pages until ``limit``
                          or ``bars_available`` is reached. Set False to
                          restore the v0.7.1 single-request behaviour.

        Returns:
            DataFrame with DatetimeIndex (UTC), columns: symbol, exchange, open, high, low, close, volume
        """
        base_params: dict = {"interval": interval, "limit": limit}
        if from_ts:
            base_params["from"] = from_ts.isoformat()
        else:
            base_params["from"] = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        if to_ts:
            base_params["to"] = to_ts.isoformat()

        # Always ask the server for meta on the first call — we need it to
        # decide whether to paginate. We only surface it on ``last_meta``
        # when the caller opted in, to preserve the v0.7.1 contract.
        first_params = {**base_params, "include_meta": "true"}
        url = f"/v1/ohlcv/{source}/{symbol.upper()}"
        data = cls._request("GET", url, params=first_params)
        meta = data.get("meta") or {}
        bars: list[dict] = data.get("data", []) or []
        cls.last_meta = meta if include_meta else None

        # Auto-pagination — only kicks in when the server tells us we were
        # capped AND more bars exist within the tier's allowed window.
        if paginate and meta.get("limit_applied") and len(bars) < limit:
            bars_available = int(meta.get("bars_available") or len(bars))
            target = min(limit, bars_available)
            while len(bars) < target and bars:
                # Server returns DESC (newest first); oldest is bars[-1].
                oldest_time = bars[-1].get("time")
                if not oldest_time:
                    break
                if hasattr(oldest_time, "isoformat"):
                    oldest_iso = oldest_time.isoformat()
                else:
                    oldest_iso = str(oldest_time)
                page_params = {**base_params, "to": oldest_iso}
                page_data = cls._request("GET", url, params=page_params)
                page_bars = page_data.get("data") or []
                if not page_bars:
                    break
                # Both pages are DESC — older bars append to the tail.
                bars.extend(page_bars)
                time.sleep(0.5)
            if len(bars) > int(meta.get("bars_returned") or 0):
                max_per_page = int(meta.get("max_bars_per_request") or 0)
                warnings.warn(
                    f"Tier '{meta.get('tier')}' caps at {max_per_page} bars/request. "
                    f"Auto-paginated to {len(bars)} bars across multiple requests. "
                    f"Upgrade for higher per-request limits.",
                    UserWarning,
                    stacklevel=2,
                )

        return _to_df(bars)

    @classmethod
    def trades(
        cls,
        source: str,
        symbol: str,
        hours: int = 1,
        limit: int = 500,
    ) -> pd.DataFrame:
        """Recent trades.

        Args:
            source: ``"binance"`` | ``"polymarket"``
            symbol: trading pair (e.g. ``"BTC-USDT"``) or Polymarket symbol
            hours:  lookback window
            limit:  max rows (capped by tier)

        Returns:
            DataFrame with DatetimeIndex (UTC).
        """
        params: dict = {
            "limit": limit,
            "from": (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(),
        }
        data = cls._request("GET", f"/v1/trades/{source}/{symbol.upper()}", params=params)
        return _to_df(data.get("data", []))

    @classmethod
    def orderbook(
        cls,
        source: str,
        symbol: str,
        depth: int = 20,
    ) -> dict:
        """Current order book snapshot.

        Returns:
            Dict with keys: time, symbol, exchange, bids, asks, spread, mid_price.
        """
        data = cls._request(
            "GET", f"/v1/orderbook/{source}/{symbol.upper()}",
            params={"depth": depth},
        )
        return data

    @classmethod
    def markets(
        cls,
        status: str = "active",
        base_asset: str | None = None,
    ) -> pd.DataFrame:
        """Polymarket prediction markets.

        Args:
            status:     ``"active"`` | ``"closed"`` | ``"all"``
            base_asset: filter by ``"BTC"`` | ``"ETH"`` | ``"SOL"``

        Returns:
            DataFrame with one row per market.
        """
        params: dict = {"status": status}
        if base_asset:
            params["base_asset"] = base_asset.upper()
        data = cls._request("GET", "/v1/markets", params=params)
        return _to_df(data.get("data", []), time_col="candle_open")

    @classmethod
    def cross_market(
        cls,
        granularity: str = "5m",
        base_asset: str | None = None,
        hours: int = 2,
        from_ts: datetime | None = None,
        to_ts: datetime | None = None,
        confirmed_only: bool = True,
        limit: int = 500,
        include_meta: bool = False,
        paginate: bool = True,
    ) -> pd.DataFrame:
        """Joined Binance OHLCV × Polymarket implied-probability OHLCV.

        Window selection (v0.7.5+):
          * If both ``from_ts`` and ``to_ts`` are supplied, they drive the query.
          * Otherwise ``hours`` is used as a lookback from now.
          * Either way the server clamps the window to the caller's tier
            ``rest_history_days`` (pro=180d, enterprise=5y).

        Pagination (v0.7.5+): when ``paginate=True`` and the tier caps a
        single response below the requested ``limit``, older pages are
        fetched automatically using the oldest row's timestamp as the next
        ``to``. A ``UserWarning`` is emitted after auto-pagination so callers
        notice their tier is costing them round-trips.

        Args:
            granularity:    ``"1m"`` | ``"5m"``
            base_asset:     filter by ``"BTC"`` | ``"ETH"`` | ``"SOL"``
            hours:          lookback window — ignored when ``from_ts``+``to_ts`` set
            from_ts:        explicit start (UTC-aware datetime)
            to_ts:          explicit end (UTC-aware datetime, defaults to now)
            confirmed_only: exclude ``is_provisional=True`` buckets
            limit:          rows to materialise (across pages if paginating)
            include_meta:   when True, the server's ``meta`` block is stored on
                            :attr:`RestConnector.last_meta` after the call.
            paginate:       auto-walk older pages when capped by tier.

        Returns:
            DataFrame with DatetimeIndex (UTC) and all cross-OHLCV columns.
        """
        base_params: dict = {"granularity": granularity, "limit": limit}
        if base_asset:
            base_params["base_asset"] = base_asset.upper()
        if confirmed_only:
            base_params["confirmed_only"] = "true"
        # Prefer explicit window; only fall through to `hours` if the caller
        # didn't supply it. Keeps backward compat for callers still passing hours.
        if from_ts is not None or to_ts is not None:
            if from_ts is not None:
                base_params["from"] = from_ts.isoformat()
            if to_ts is not None:
                base_params["to"] = to_ts.isoformat()
        else:
            base_params["hours"] = hours

        # Always ask for meta internally so we can drive pagination; we only
        # surface it on last_meta when include_meta=True.
        first_params = {**base_params, "include_meta": "true"}
        data = cls._request("GET", "/v1/cross-market", params=first_params)
        meta = data.get("meta") or {}
        bars: list[dict] = data.get("data", []) or []
        cls.last_meta = meta if include_meta else None

        if paginate and meta.get("limit_applied") and len(bars) < limit:
            bars_available = int(meta.get("bars_available") or len(bars))
            target = min(limit, bars_available)
            while len(bars) < target and bars:
                oldest_time = bars[-1].get("time")
                if not oldest_time:
                    break
                if hasattr(oldest_time, "isoformat"):
                    oldest_iso = oldest_time.isoformat()
                else:
                    oldest_iso = str(oldest_time)
                # Page backwards — next request ends where this one started.
                page_params = {**base_params, "to": oldest_iso}
                page_params.pop("hours", None)  # hours becomes meaningless once `to` is set
                page_data = cls._request("GET", "/v1/cross-market", params=page_params)
                page_bars = page_data.get("data") or []
                if not page_bars:
                    break
                bars.extend(page_bars)
                time.sleep(0.5)
            if len(bars) > int(meta.get("bars_returned") or 0):
                max_per_page = int(meta.get("max_bars_per_request") or 0)
                warnings.warn(
                    f"Tier '{meta.get('tier')}' caps at {max_per_page} bars/request. "
                    f"Auto-paginated to {len(bars)} bars across multiple requests. "
                    f"Upgrade for higher per-request limits.",
                    UserWarning,
                    stacklevel=2,
                )

        return _to_df(bars)

    @classmethod
    def me(cls) -> dict:
        """Return current user info: tier, limits, 30-day usage.

        Legacy endpoint — still supported. For new code prefer :meth:`account`,
        which returns a nested ``limits`` shape and live usage counters.
        """
        return cls._request("GET", "/v1/user/me")

    @classmethod
    def account(cls) -> dict:
        """Return tier, nested limits, and live usage counters.

        Response shape::

            {
              "tier": "starter",
              "limits": {
                "rest":       {"max_bars_per_request", "max_requests_per_minute",
                               "max_history_days", "allowed_intervals",
                               "allowed_exchanges", "allowed_symbols"},
                "websocket":  {"max_connections", "max_subscriptions_per_connection",
                               "allowed_intervals"},
                "backtest":   {"max_window_days", "max_concurrent"},
                "production": {"max_bots", "allowed_exchanges"},
              },
              "usage": {"rest_requests_this_minute",
                        "websocket_connections",
                        "active_bots"},
            }

        Fields where the tier is unrestricted return ``None`` (e.g.
        ``limits.rest.allowed_symbols = None`` for enterprise means "all").
        """
        return cls._request("GET", "/v1/account")

    @classmethod
    def pairs(cls, source: str = "binance") -> list[str]:
        """List available trading pairs for a source."""
        data = cls._request("GET", "/v1/pairs", params={"source": source})
        return data.get("pairs", [])

    @classmethod
    def close(cls) -> None:
        """Close the underlying HTTP client (call when done in scripts)."""
        if cls._client and not cls._client.is_closed:
            cls._client.close()
            cls._client = None