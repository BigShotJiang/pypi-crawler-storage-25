"""Core backtest engine — replays historical data through Strategy.on_data().

Backtest-live parity guarantee:
  The engine wraps each OHLCV row into a StreamMessage identical to what the
  WebSocket sends in live trading. The strategy's on_data() receives exactly the
  same tick format whether running live or in backtest.

Key differences from live trading:
  - Data is loaded from DaaS REST API upfront (not streamed)
  - Fills execute at bar close price (not live orderbook)
  - SQLite state is in-memory (":memory:"), not persisted to disk
  - No SIGTERM / Prometheus / port binding

Usage::

    from auspicium.backtest import run, run_sync
    from my_strategy import BTCMomentum

    # Async (recommended)
    result = await run(BTCMomentum, symbol="BTC-USDT", start="2024-01-01", end="2024-06-30")

    # Sync (Jupyter notebooks)
    result = run_sync(BTCMomentum, symbol="BTC-USDT", start="2024-01-01")

    result.stats()
    result.plot()
"""
from __future__ import annotations

import asyncio
import logging
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

import numpy as np
import pandas as pd

from auspicium.errors import TierLimitError
from auspicium.models import StreamMessage
from auspicium.strategy.models import (
    ORDER_TYPE_MARKET,
    ORDER_TYPE_TRAILING_STOP,
    Fill,
    Order,
    Portfolio,
    Position,
)
from auspicium.strategy.risk import RiskGuardian
from auspicium.strategy.state import StateManager
from auspicium.strategy.stop_engine import check_trigger, update_trail_mark

if TYPE_CHECKING:
    from auspicium.strategy.base import Strategy

log = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# BacktestPaperExchange                                                #
# ------------------------------------------------------------------ #

class BacktestPaperExchange:
    """Paper exchange for backtesting — fills at the current bar's close price.

    Unlike PaperExchange (which calls RestConnector for live prices), this
    exchange fills MARKET orders immediately at ``current_bar_close``, set
    by the engine before each on_data() call. This avoids live REST calls
    and ensures deterministic fills from historical data.

    LIMIT orders queue and fill when the bar price crosses the limit.
    """

    def __init__(
        self,
        initial_cash: float = 10_000.0,
        fill_callback: Any = None,
    ) -> None:
        self._cash = initial_cash
        self._positions: dict[str, Position] = {}
        self._fills: list[Fill] = []
        self._open_orders: dict[str, Order] = {}
        self._stop_orders: dict[str, Order] = {}
        self._trail_marks: dict[str, float] = {}
        self._fill_callback = fill_callback
        self.current_bar_close: float = 0.0   # set by engine before each tick
        # Bar high/low for intra-bar stop checks (backtest-only).
        # Engine populates these before each tick.
        self.current_bar_high: float = 0.0
        self.current_bar_low: float = 0.0

    async def submit(self, order: Order) -> None:
        """Fill MARKET orders at current_bar_close; queue LIMIT orders;
        hold conditional orders (stop / TP / trailing / OCO) until triggered."""
        if order.is_conditional:
            self._stop_orders[order.id] = order
            return
        if order.order_type == ORDER_TYPE_MARKET:
            fill_price = self.current_bar_close if self.current_bar_close > 0 else order.price
            await self._execute_fill(order, fill_price)
        else:
            # LIMIT — queue for later check
            self._open_orders[order.id] = order

    async def cancel(self, order_id: str) -> bool:
        """Cancel a queued limit or conditional order."""
        if order_id in self._open_orders:
            del self._open_orders[order_id]
            return True
        if order_id in self._stop_orders:
            del self._stop_orders[order_id]
            self._trail_marks.pop(order_id, None)
            return True
        return False

    async def check_pending_orders(self, current_prices: dict[str, float]) -> None:
        """Fill pending limit orders and evaluate conditional orders against
        the current bar's OHLC."""
        price = self.current_bar_close
        high = self.current_bar_high or price
        low = self.current_bar_low or price

        # Regular LIMIT orders
        filled_ids = []
        for order_id, order in list(self._open_orders.items()):
            if order.side == "BUY" and price <= order.price:
                await self._execute_fill(order, fill_price=order.price)
                filled_ids.append(order_id)
            elif order.side == "SELL" and price >= order.price:
                await self._execute_fill(order, fill_price=order.price)
                filled_ids.append(order_id)
        for oid in filled_ids:
            self._open_orders.pop(oid, None)

        # Conditional orders — use bar OHLC (backtest convention: any trade
        # through the stop level fills at the stop price).
        triggered_ids: list[str] = []
        for order_id, order in list(self._stop_orders.items()):
            if order.order_type == ORDER_TYPE_TRAILING_STOP:
                self._trail_marks[order_id] = update_trail_mark(
                    order, price, self._trail_marks.get(order_id),
                )
            result = check_trigger(
                order, price, high=high, low=low,
                trail_mark=self._trail_marks.get(order_id),
            )
            if result.triggered:
                await self._execute_fill(order, fill_price=result.fill_price)
                triggered_ids.append(order_id)
        for oid in triggered_ids:
            self._stop_orders.pop(oid, None)
            self._trail_marks.pop(oid, None)

    async def _execute_fill(self, order: Order, fill_price: float) -> None:
        """Record a fill and call the fill_callback."""
        # Backtest uses same fee structure as paper trading
        from auspicium.strategy.paper import _is_binance
        if _is_binance(order.market):
            fee = order.size * fill_price * 0.001
        else:
            fee = order.size * 0.02 * fill_price * (1.0 - fill_price)

        fill = Fill(
            order_id=order.id,
            market=order.market,
            side=order.side,
            outcome=order.outcome,
            price=fill_price,
            size=order.size,
            fee=fee,
            timestamp=datetime.now(timezone.utc),
            status="CONFIRMED",
        )
        self._fills.append(fill)

        cost = order.size * fill_price + fee
        if order.side == "BUY":
            self._cash -= cost
        else:
            self._cash += order.size * fill_price - fee

        self._update_position(order, fill_price)

        if self._fill_callback is not None:
            if asyncio.iscoroutinefunction(self._fill_callback):
                await self._fill_callback(fill)
            else:
                self._fill_callback(fill)

    def _update_position(self, order: Order, fill_price: float) -> None:
        market = order.market
        existing = self._positions.get(market)
        if order.side == "BUY":
            if existing is None:
                self._positions[market] = Position(
                    market=market, side="LONG", outcome=order.outcome,
                    size=order.size, entry_price=fill_price,
                )
            else:
                total = existing.size + order.size
                existing.entry_price = (
                    existing.entry_price * existing.size + fill_price * order.size
                ) / total
                existing.size = total
        else:
            if existing is None:
                self._positions[market] = Position(
                    market=market, side="SHORT", outcome=order.outcome,
                    size=order.size, entry_price=fill_price,
                )
            else:
                remaining = existing.size - order.size
                if remaining <= 1e-9:
                    del self._positions[market]
                else:
                    existing.size = remaining

    @property
    def cash(self) -> float:
        return self._cash

    @property
    def positions(self) -> dict[str, Position]:
        return self._positions

    @property
    def open_orders(self) -> dict[str, Order]:
        return self._open_orders


# ------------------------------------------------------------------ #
# BacktestResult                                                       #
# ------------------------------------------------------------------ #

@dataclass
class BacktestResult:
    """Rich result object with plotting, stats, and trade log.

    Attributes:
        equity_curve:    pd.Series — indexed by time, values = portfolio total value
        trades:          pd.DataFrame — columns: time, market, side, outcome, price, size, fee, pnl
        returns:         pd.Series — bar-by-bar returns from equity curve
        ohlcv:           pd.DataFrame — the price data used (for plotting)
        initial_capital: float
        stats_dict:      dict — pre-computed performance metrics
    """

    equity_curve: pd.Series
    trades: pd.DataFrame
    returns: pd.Series
    ohlcv: pd.DataFrame
    initial_capital: float
    stats_dict: dict = field(default_factory=dict)
    indicators: dict = field(default_factory=dict)
    source: str = ""
    symbol: str = ""
    interval: str = ""

    def stats(self) -> pd.Series:
        """Key performance metrics as a pandas Series."""
        return pd.Series(self.stats_dict)

    def plot(self, show: bool = True):
        """Interactive plotly tearsheet — equity, drawdown, trade markers.

        Returns:
            plotly Figure (also calls fig.show() if show=True).

        Raises:
            ImportError: if plotly is not installed (pip install auspicium[backtest])
        """
        from auspicium.backtest.report import create_tearsheet
        fig = create_tearsheet(self)
        if show:
            fig.show()
        return fig

    def tearsheet(self) -> None:
        """Print text tearsheet to console using rich tables."""
        from auspicium.backtest.report import print_tearsheet
        print_tearsheet(self)

    def to_dict(self) -> dict:
        """Serialize to JSON-safe dict (no numpy scalars, no Timestamps).

        Used by the workspace-api to return backtest results to the frontend.
        """
        return result_to_dict(self)


# ------------------------------------------------------------------ #
# Stats computation                                                    #
# ------------------------------------------------------------------ #

def _compute_stats(
    equity: pd.Series,
    trades: pd.DataFrame,
    initial_capital: float,
) -> dict:
    """Compute performance metrics from equity curve and trade log."""
    if len(equity) < 2:
        return {
            "total_return": 0.0,
            "annualized_return": 0.0,
            "sharpe_ratio": 0.0,
            "sortino_ratio": 0.0,
            "max_drawdown": 0.0,
            "total_trades": 0,
            "win_rate": 0.0,
            "profit_factor": 0.0,
            "avg_win": 0.0,
            "avg_loss": 0.0,
            "best_trade": 0.0,
            "worst_trade": 0.0,
            "commission_paid": 0.0,
            "initial_capital": initial_capital,
            "final_value": float(equity.iloc[-1]) if len(equity) > 0 else initial_capital,
        }

    returns = equity.pct_change().dropna()
    total_return = float((equity.iloc[-1] / initial_capital) - 1)
    days = (equity.index[-1] - equity.index[0]).total_seconds() / 86400
    ann_factor = 365.25 / max(days, 1)

    ret_std = float(returns.std())
    sharpe = float(returns.mean() / ret_std * np.sqrt(365)) if ret_std > 0 else 0.0
    neg = returns[returns < 0]
    neg_std = float(neg.std())
    sortino = float(returns.mean() / neg_std * np.sqrt(365)) if len(neg) > 0 and neg_std > 0 else 0.0

    cum_max = equity.cummax()
    drawdown = (equity - cum_max) / cum_max
    max_dd = float(drawdown.min())

    if len(trades) > 0 and "pnl" in trades.columns:
        wins = trades[trades["pnl"] > 0]
        losses = trades[trades["pnl"] < 0]
        total = len(trades)
        win_rate = float(len(wins) / total) if total > 0 else 0.0
        avg_win = float(wins["pnl"].mean()) if len(wins) > 0 else 0.0
        avg_loss = float(losses["pnl"].mean()) if len(losses) > 0 else 0.0
        loss_sum = abs(float(losses["pnl"].sum()))
        profit_factor = float(wins["pnl"].sum() / loss_sum) if loss_sum > 0 else float("inf")
        best_trade = float(trades["pnl"].max())
        worst_trade = float(trades["pnl"].min())
        commission = float(trades["fee"].sum())
    else:
        win_rate = avg_win = avg_loss = best_trade = worst_trade = commission = 0.0
        profit_factor = 0.0

    return {
        "total_return": total_return,
        "annualized_return": float(total_return * ann_factor),
        "sharpe_ratio": sharpe,
        "sortino_ratio": sortino,
        "max_drawdown": max_dd,
        "total_trades": len(trades),
        "win_rate": win_rate,
        "profit_factor": profit_factor,
        "avg_win": avg_win,
        "avg_loss": avg_loss,
        "best_trade": best_trade,
        "worst_trade": worst_trade,
        "commission_paid": commission,
        "initial_capital": float(initial_capital),
        "final_value": float(equity.iloc[-1]),
    }


def _compute_trade_pnl(fills: list[Fill]) -> pd.DataFrame:
    """Match BUY fills with SELL fills (FIFO) to compute per-trade PnL.

    Returns DataFrame with columns:
        time, market, side, outcome, price, size, fee, pnl
    """
    if not fills:
        return pd.DataFrame(
            columns=["time", "market", "side", "outcome", "price", "size", "fee", "pnl"]
        )

    # Group by market
    by_market: dict[str, list[Fill]] = {}
    for f in fills:
        by_market.setdefault(f.market, []).append(f)

    records = []
    for market, mfills in by_market.items():
        buy_queue: deque[Fill] = deque()
        for f in mfills:
            if f.side == "BUY":
                buy_queue.append(f)
                records.append({
                    "time": f.timestamp,
                    "market": f.market,
                    "side": f.side,
                    "outcome": f.outcome,
                    "price": f.price,
                    "size": f.size,
                    "fee": f.fee,
                    "pnl": 0.0,  # filled in when matched with sell
                })
            else:  # SELL — match against open buys (FIFO)
                remaining_sell = f.size
                realized = 0.0
                total_fee = f.fee
                while buy_queue and remaining_sell > 1e-9:
                    buy = buy_queue[0]
                    matched = min(buy.size, remaining_sell)
                    realized += matched * (f.price - buy.price)
                    remaining_sell -= matched
                    if matched >= buy.size - 1e-9:
                        buy_queue.popleft()
                    else:
                        # Partial match — reduce buy size
                        object.__setattr__(buy, "size", buy.size - matched)
                records.append({
                    "time": f.timestamp,
                    "market": f.market,
                    "side": f.side,
                    "outcome": f.outcome,
                    "price": f.price,
                    "size": f.size,
                    "fee": total_fee,
                    "pnl": realized - total_fee,
                })

    if not records:
        return pd.DataFrame(
            columns=["time", "market", "side", "outcome", "price", "size", "fee", "pnl"]
        )

    df = pd.DataFrame(records)
    df["time"] = pd.to_datetime(df["time"], utc=True)
    return df.sort_values("time").reset_index(drop=True)


# ------------------------------------------------------------------ #
# JSON serialization                                                   #
# ------------------------------------------------------------------ #

def result_to_dict(result: BacktestResult) -> dict:
    """Serialize BacktestResult to JSON-safe dict (full chart data contract).

    Time series use Unix seconds (int) for Lightweight Charts compatibility.

    Returns dict with:
        stats:        dict of performance metrics (floats)
        equity_curve: list of {"time": int (Unix s), "value": float}
        drawdown:     list of {"time": int (Unix s), "value": float}
        ohlcv:        list of {"time": int, "open": float, "high": float,
                               "low": float, "close": float, "volume": float}
        trades:       list of trade dicts (time as ISO string for readability)
        indicators:   dict of {name: {"name", "type", "pane", "color",
                               "line_width", "levels", "data": [{"time": int, "value": float}]}}
        source:       str — data source ("binance" | "polymarket")
        symbol:       str — trading pair or condition_id
        interval:     str — bar interval ("1m", "5m", "1h", "1d")
    """
    equity = result.equity_curve
    cum_max = equity.cummax()
    drawdown = ((equity - cum_max) / cum_max).fillna(0.0)

    def _ts(idx) -> int:
        """Convert index entry to Unix seconds."""
        try:
            return int(idx.timestamp())
        except Exception:
            return 0

    equity_list = [
        {"time": _ts(idx), "value": round(float(v), 2)}
        for idx, v in equity.items()
    ]
    drawdown_list = [
        {"time": _ts(idx), "value": round(float(v), 6)}
        for idx, v in drawdown.items()
    ]

    # OHLCV
    ohlcv_list = []
    for idx, row in result.ohlcv.iterrows():
        ohlcv_list.append({
            "time": _ts(idx),
            "open": round(float(row.get("open", 0.0)), 6),
            "high": round(float(row.get("high", 0.0)), 6),
            "low": round(float(row.get("low", 0.0)), 6),
            "close": round(float(row.get("close", 0.0)), 6),
            "volume": round(float(row.get("volume", 0.0)), 2),
        })

    # Trades
    trades_list = []
    for _, row in result.trades.iterrows():
        record = {}
        for k, v in row.items():
            if hasattr(v, "isoformat"):
                record[k] = v.isoformat()
            elif hasattr(v, "item"):  # numpy scalar
                record[k] = v.item()
            else:
                record[k] = v
        trades_list.append(record)

    return {
        "stats": result.stats_dict,
        "equity_curve": equity_list,
        "drawdown": drawdown_list,
        "ohlcv": ohlcv_list,
        "trades": trades_list,
        "indicators": result.indicators,
        "source": result.source,
        "symbol": result.symbol,
        "interval": result.interval,
    }


# ------------------------------------------------------------------ #
# Fill callback (mirrors runner.py _on_fill logic)                    #
# ------------------------------------------------------------------ #

def _make_fill_callback(strategy, open_orders_ref: dict):
    """Create a fill callback that updates the strategy portfolio in-place."""
    from auspicium.strategy.runner import _apply_fill_to_portfolio

    async def _on_fill(fill: Fill) -> None:
        open_orders_ref.pop(fill.order_id, None)
        _apply_fill_to_portfolio(strategy._portfolio, fill)
        try:
            await strategy.on_fill(fill)
        except Exception as exc:
            log.error("on_fill raised: %s", exc, exc_info=True)

    return _on_fill


# ------------------------------------------------------------------ #
# Main run() function                                                  #
# ------------------------------------------------------------------ #

async def run(
    strategy_cls: type,
    source: str = "binance",
    symbol: str = "BTC-USDT",
    start: str = "2024-01-01",
    end: str = "2024-12-31",
    interval: str = "1h",
    initial_capital: float = 10_000.0,
    config: dict | None = None,
    risk_limits: dict | None = None,
) -> BacktestResult:
    """Run a backtest with automatic data loading from DaaS.

    Steps:
        1. Load historical OHLCV data from DaaS REST API
        2. Create BacktestPaperExchange (fills at bar close)
        3. Create RiskGuardian with risk_limits (or defaults)
        4. Create StateManager with in-memory SQLite
        5. Instantiate strategy, call configure()
        6. Replay each OHLCV bar as StreamMessage through on_data()
        7. After each bar: update equity, check pending orders
        8. Compute stats from equity curve and trade log
        9. Return BacktestResult

    Args:
        strategy_cls:    Strategy subclass to backtest.
        source:          Data source: "binance" or "polymarket".
        symbol:          Trading pair (e.g. "BTC-USDT") or condition_id.
        start:           ISO date string, start of backtest window.
        end:             ISO date string, end of backtest window.
        interval:        OHLCV bar interval: "1m", "5m", "1h", "1d".
        initial_capital: Starting cash in USD.
        config:          Strategy config dict (overrides config.yaml).
        risk_limits:     Risk limits dict (overrides manifest.yaml defaults).

    Returns:
        BacktestResult with equity curve, trades, stats, and plot method.
    """
    import warnings
    from auspicium.connectors.rest import RestConnector
    from datetime import datetime

    log.info(
        "Backtest starting: %s %s/%s %s→%s interval=%s capital=%.0f",
        strategy_cls.__name__, source, symbol, start, end, interval, initial_capital,
    )

    # --- Load historical data ---
    start_dt = datetime.fromisoformat(start).replace(tzinfo=timezone.utc)
    end_dt = datetime.fromisoformat(end).replace(tzinfo=timezone.utc)
    days = max(1, (end_dt - start_dt).days + 1)

    # --- Tier validation: fail fast before spending DaaS quota ---
    # get_tier() hits the account endpoint; if it's unreachable we skip the
    # client-side check and let the server enforce limits.
    try:
        from auspicium.account import get_tier
        tier = get_tier()
    except Exception as exc:
        log.warning("Could not fetch tier info (%s) — skipping client-side validation", exc)
        tier = None

    if tier is not None:
        window_days = (end_dt - start_dt).days
        if window_days > tier.max_history_days:
            raise TierLimitError(
                f"Backtest window ({window_days} days) exceeds your "
                f"'{tier.tier}' tier limit ({tier.max_history_days} days). "
                f"Reduce the window or upgrade your plan."
            )
        if interval not in tier.allowed_intervals:
            raise TierLimitError(
                f"Interval {interval!r} is not available on the {tier.tier!r} "
                f"tier. Allowed: {tier.allowed_intervals}"
            )

    # Pagination cap — allow up to 10 pages of the tier's max-bars so that a
    # backtest over the tier's max_history_days can still materialise.
    fetch_limit = (tier.max_bars * 10) if tier is not None else 50_000
    ohlcv_df = RestConnector.ohlcv(
        source, symbol, interval=interval, days=days,
        from_ts=start_dt, to_ts=end_dt,
        limit=fetch_limit,
    )

    if ohlcv_df.empty:
        raise ValueError(
            f"No OHLCV data returned for {source}/{symbol} "
            f"between {start} and {end}"
        )

    # Warn when the fetched series is much shorter than the theoretical bar
    # count for the window — typically means either tier-clamp or sparse data.
    _BAR_SECONDS = {"1m": 60, "5m": 300, "15m": 900, "1h": 3_600, "4h": 14_400, "1d": 86_400}
    bar_seconds = _BAR_SECONDS.get(interval)
    if bar_seconds:
        expected_bars = int((end_dt - start_dt).total_seconds() / bar_seconds)
        if expected_bars > 0 and len(ohlcv_df) < expected_bars * 0.9:
            warnings.warn(
                f"Backtest loaded {len(ohlcv_df)} bars (expected ~{expected_bars}). "
                "Results may be unreliable. Check that the window fits your "
                "tier's history limit and that the symbol has dense coverage.",
                UserWarning,
                stacklevel=2,
            )

    log.info("Loaded %d OHLCV bars", len(ohlcv_df))

    # --- Strategy config ---
    strategy_config: dict = {"initial_cash": initial_capital}
    if config:
        strategy_config.update(config)

    # --- Create components ---
    exchange = BacktestPaperExchange(initial_cash=initial_capital)
    state = StateManager(":memory:")
    risk = RiskGuardian(risk_limits or {})

    # --- Instantiate strategy ---
    strategy = strategy_cls(
        config=strategy_config,
        exchange=exchange,
        state=state,
        risk=risk,
    )

    # --- Register fill callback (updates strategy._portfolio and calls on_fill) ---
    exchange._fill_callback = _make_fill_callback(strategy, strategy._open_orders)

    # --- Configure ---
    strategy.configure()

    # --- Event loop ---
    equity_index: list = []
    equity_values: list[float] = []

    for idx, row in ohlcv_df.iterrows():
        close_price = float(row.get("close", 0.0))
        exchange.current_bar_close = close_price
        exchange.current_bar_high = float(row.get("high", close_price))
        exchange.current_bar_low = float(row.get("low", close_price))

        # Set tick timestamp so emit_indicator() records correct time
        strategy._last_tick_ts = int(idx.timestamp()) if hasattr(idx, "timestamp") else 0

        tick = StreamMessage(
            channel="ohlcv",
            source=source,
            symbol=symbol,
            interval=interval,
            payload={
                "time": idx.isoformat() if hasattr(idx, "isoformat") else str(idx),
                "open": float(row.get("open", close_price)),
                "high": float(row.get("high", close_price)),
                "low": float(row.get("low", close_price)),
                "close": close_price,
                "volume": float(row.get("volume", 0.0)),
            },
            timestamp_ms=int(idx.timestamp() * 1000) if hasattr(idx, "timestamp") else 0,
        )

        try:
            await strategy.on_data(tick)
        except Exception as exc:
            log.error("on_data raised at %s: %s", idx, exc, exc_info=True)

        # Check pending limit orders against current close
        await exchange.check_pending_orders({symbol: close_price})

        # Snapshot portfolio value
        pos_value = sum(p.size * close_price for p in exchange._positions.values())
        equity_index.append(idx)
        equity_values.append(exchange._cash + pos_value)

    # --- Close all positions at final bar ---
    await strategy.on_shutdown()
    state.close()

    # --- Build results ---
    equity_curve = pd.Series(equity_values, index=equity_index, name="equity")
    returns = equity_curve.pct_change().dropna()
    trades_df = _compute_trade_pnl(exchange._fills)
    stats = _compute_stats(equity_curve, trades_df, initial_capital)

    log.info(
        "Backtest complete: %d bars, %d fills, total_return=%.2f%%",
        len(ohlcv_df), len(exchange._fills), stats["total_return"] * 100,
    )

    return BacktestResult(
        equity_curve=equity_curve,
        trades=trades_df,
        returns=returns,
        ohlcv=ohlcv_df,
        initial_capital=initial_capital,
        stats_dict=stats,
        indicators=strategy.indicators,
        source=source,
        symbol=symbol,
        interval=interval,
    )


def run_sync(
    strategy_cls: type,
    **kwargs,
) -> BacktestResult:
    """Synchronous wrapper for run(). Use in Jupyter notebooks.

    Usage::

        from auspicium.backtest import run_sync
        result = run_sync(BTCMomentum, symbol="BTC-USDT", start="2024-01-01")
        result.tearsheet()
        result.plot()
    """
    return asyncio.run(run(strategy_cls, **kwargs))
