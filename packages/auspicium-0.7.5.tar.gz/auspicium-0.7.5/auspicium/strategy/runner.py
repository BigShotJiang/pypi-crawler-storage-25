"""StrategyRunner — async event loop that drives a Strategy subclass.

Responsibilities:
  - Load config.yaml and manifest.yaml from the strategy directory
  - Validate the environment (raises if AUSPICIUM_ENV=design)
  - Wire up PaperExchange / StateManager / RiskGuardian / StrategyMonitor
  - Run the WebSocket event loop, dispatch ticks, handle fills
  - Respond to SIGTERM with a clean shutdown

CLI usage::

    python -m auspicium.strategy.runner \\
        --strategy-dir ./strategies/my_strategy \\
        --strategy-class MyStrategy \\
        --log-level INFO

Or from Python::

    from auspicium.strategy.runner import StrategyRunner
    from my_strategy import MyStrategy

    runner = StrategyRunner(MyStrategy, strategy_dir="./strategies/my_strategy")
    asyncio.run(runner.run())
"""
from __future__ import annotations

import argparse
import asyncio
import importlib
import logging
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Type

import yaml
from websockets.exceptions import ConnectionClosed

from auspicium.config import get_config
from auspicium.connectors.stream import StreamConnector
from auspicium.errors import AuspiciumError, AuthError, TierLimitError
from auspicium.errors import ConnectionError as AuspConnectionError
from auspicium.strategy.base import Strategy
from auspicium.strategy.models import Fill, Portfolio
from auspicium.strategy.monitor import StrategyMonitor
from auspicium.strategy.paper import PaperExchange
from auspicium.strategy.risk import RiskGuardian
from auspicium.strategy.state import StateManager

log = logging.getLogger(__name__)


class StrategyRunner:
    """Drives a Strategy subclass through its full lifecycle.

    Args:
        strategy_cls:   The Strategy subclass to instantiate and run.
        config:         Optional dict of strategy params (overrides config.yaml).
        strategy_dir:   Path to the strategy directory (contains config.yaml,
                        manifest.yaml, and state.db will be created here).
                        Defaults to the current working directory.
    """

    def __init__(
        self,
        strategy_cls: Type[Strategy],
        config: dict | None = None,
        strategy_dir: str | Path | None = None,
    ) -> None:
        self._strategy_cls = strategy_cls
        self._strategy_dir = Path(strategy_dir) if strategy_dir else Path.cwd()
        self._shutdown_requested = False
        self._tick_count: int = 0

        # --- WebSocket reconnection state (exposed via the state API) -------
        # "running"      — connected and consuming ticks
        # "reconnecting" — between attempts, sleeping on backoff
        # "stopped"      — runner has exited (clean or after max retries)
        self._ws_status: str = "stopped"
        self._ws_connected: bool = False
        self._ws_last_disconnect: str | None = None      # ISO-8601 UTC
        self._ws_reconnect_attempts: int = 0

        # --- Reconnect tunables (exposed for testing) -----------------------
        # Override these on the instance in tests; production uses the defaults.
        self._reconnect_initial_delay: float = 2.0
        self._reconnect_max_delay: float = 60.0
        self._reconnect_backoff_factor: float = 1.5
        self._reconnect_max_attempts: int = 10
        # If a connection stays up longer than this, the backoff counter resets.
        self._reconnect_healthy_threshold_s: float = 60.0

        # --- Load config.yaml and manifest.yaml ---
        strategy_config = self._load_yaml("config.yaml")
        if config:
            strategy_config.update(config)

        manifest = self._load_yaml("manifest.yaml")
        risk_limits = manifest.get("risk", {})

        # --- Validate environment ---
        cfg = get_config()
        if cfg.env == "design":
            raise AuspiciumError(
                "Set AUSPICIUM_ENV=quality to run live, "
                "or use auspicium.backtest for design mode"
            )

        # --- Create exchange adapter ---
        if cfg.env == "quality":
            self._exchange = PaperExchange(
                initial_cash=strategy_config.get("initial_cash", 10_000.0),
                fill_callback=None,  # registered below after strategy is created
            )
        elif cfg.env == "production":
            from auspicium.exchange.production import ProductionExchange
            self._exchange = ProductionExchange(fill_callback=None)
            log.info("Production mode: using ProductionExchange router")
        else:
            raise AuspiciumError(f"Unknown AUSPICIUM_ENV: {cfg.env!r}")

        # --- Create supporting components ---
        db_path = self._strategy_dir / "state.db"
        self._state = StateManager(db_path)
        self._risk = RiskGuardian(risk_limits)

        # --- Instantiate strategy ---
        self._strategy = strategy_cls(
            config=strategy_config,
            exchange=self._exchange,
            state=self._state,
            risk=self._risk,
        )

        # --- Register fill callback AFTER strategy is created ---
        # Registering here (not in the adapter __init__) ensures the callback
        # can close over self._strategy, which didn't exist at exchange creation time.
        # set_fill_callback() lets ProductionExchange propagate to sub-adapters.
        self._exchange.set_fill_callback(self._on_fill)

        # --- Call configure() so the strategy declares its subscriptions ---
        self._strategy.configure()

        # --- Create monitor (after configure so class name is final) ---
        self._monitor = StrategyMonitor(strategy_cls.__name__)

        log.info(
            "StrategyRunner initialised: strategy=%s env=%s dir=%s",
            strategy_cls.__name__, cfg.env, self._strategy_dir,
        )

    # ------------------------------------------------------------------ #
    # Lifecycle                                                             #
    # ------------------------------------------------------------------ #

    async def run(self) -> None:
        """Enter the WebSocket event loop and drive the strategy until shutdown."""
        # Validate subscriptions against the caller's tier BEFORE opening the
        # WebSocket. Fail fast so the quant sees a clear error at startup
        # instead of a per-subscribe TIER_LIMIT cascade from the server.
        self._validate_subscriptions_against_tier()

        # Install SIGTERM handler for graceful shutdown
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGTERM, self._request_shutdown)

        # Crash recovery: restore positions from SQLite
        saved_positions = self._state.load_positions()
        if saved_positions:
            self._strategy._portfolio.positions.update(saved_positions)
            log.info("Recovered %d positions from state DB", len(saved_positions))

        log.info("Starting event loop…")

        # --- Start the read-only state API (:9091) as an asyncio task ---
        # Runs in the same event loop as the tick loop — no thread safety
        # concerns. Lazy import so the SDK works without auspicium[api].
        state_api_task: asyncio.Task | None = None
        state_server = None
        try:
            from auspicium.strategy.state_api import create_state_app
            import uvicorn

            state_app = create_state_app(
                state_manager=self._state,
                strategy=self._strategy,
                exchange=self._exchange,
                start_time=datetime.now(timezone.utc),
                runner=self,
            )
            state_server = uvicorn.Server(
                uvicorn.Config(
                    app=state_app,
                    host="0.0.0.0",
                    port=9091,
                    log_level="warning",
                )
            )
            state_api_task = asyncio.create_task(state_server.serve())
            log.info("State API started on :9091")
        except ImportError as exc:
            log.warning(
                "State API unavailable (install auspicium[api] to enable): %s",
                exc,
            )
        except Exception as exc:
            log.error("State API failed to start: %s", exc, exc_info=True)

        # --- Reconnection loop ----------------------------------------------
        # Every iteration is a fresh WS connection; the strategy instance and
        # its in-memory state survive across reconnects. Backoff escalates on
        # consecutive failures and resets once a connection has been healthy.
        delay = self._reconnect_initial_delay
        last_connect_time: float | None = None

        try:
            while not self._shutdown_requested:
                try:
                    async with StreamConnector.connect() as ws:
                        last_connect_time = time.monotonic()
                        self._ws_status = "running"
                        self._ws_connected = True
                        self._ws_reconnect_attempts = 0
                        delay = self._reconnect_initial_delay

                        # Re-subscribe to every channel declared in configure().
                        # Idempotent: the server keys subscriptions by
                        # (channel, source, symbol, interval) tuple.
                        for sub in self._strategy._subscriptions:
                            channel = sub.get("channel", "")
                            source = sub.get("source", "")
                            symbol = sub.get("symbol", "")
                            interval = sub.get("interval", "1m")
                            await ws.subscribe(
                                channel, source=source, symbol=symbol, interval=interval,
                            )
                            log.debug(
                                "Subscribed: channel=%s source=%s symbol=%s interval=%s",
                                channel, source, symbol, interval,
                            )

                        await self._run_tick_loop(ws)

                        # Iterator exhausted without an exception — treat as
                        # a clean-close disconnect. If shutdown was requested,
                        # the outer while check will terminate the loop.
                        if not self._shutdown_requested:
                            log.warning("WebSocket iterator exhausted (clean close); reconnecting")
                            raise AuspConnectionError(
                                "WebSocket iterator exhausted without disconnect signal"
                            )

                except AuthError:
                    # Auth failures are never recoverable — propagate.
                    raise

                except (AuspConnectionError, ConnectionClosed, OSError,
                        asyncio.TimeoutError) as exc:
                    if self._shutdown_requested:
                        break

                    self._ws_connected = False
                    self._ws_last_disconnect = datetime.now(timezone.utc).isoformat()
                    self._ws_reconnect_attempts += 1
                    self._ws_status = "reconnecting"

                    # Reset backoff if the prior connection was healthy for
                    # longer than the threshold — prevents penalising a bot
                    # that has been up for days after a single transient blip.
                    if (
                        last_connect_time is not None
                        and (time.monotonic() - last_connect_time) >= self._reconnect_healthy_threshold_s
                    ):
                        delay = self._reconnect_initial_delay

                    if self._ws_reconnect_attempts > self._reconnect_max_attempts:
                        log.error(
                            "Max reconnect attempts (%d) exceeded — shutting down",
                            self._reconnect_max_attempts,
                        )
                        break

                    log.info(
                        "WebSocket disconnected: %s. Reconnecting in %.1fs (attempt %d/%d)",
                        exc, delay, self._ws_reconnect_attempts, self._reconnect_max_attempts,
                    )
                    await self._sleep_honoring_shutdown(delay)
                    delay = min(delay * self._reconnect_backoff_factor, self._reconnect_max_delay)
                    # Loop continues — the next iteration opens a fresh connection.

                except Exception as exc:
                    # Non-connection errors (e.g. programming bugs in the
                    # strategy or runner): log and bail. No auto-retry.
                    log.error("Unhandled event loop error: %s", exc, exc_info=True)
                    break

        except Exception as exc:
            log.error("Event loop error: %s", exc, exc_info=True)
        finally:
            self._ws_status = "stopped"
            self._ws_connected = False
            try:
                await self._strategy.on_shutdown()
            except Exception as exc:
                log.error("Strategy on_shutdown raised: %s", exc, exc_info=True)
            # Best-effort emergency close: cancel orders, close positions.
            # Safe because every BaseExchange.emergency_close_all() is
            # idempotent and never raises.
            try:
                if hasattr(self._exchange, "emergency_close_all"):
                    emergency_fills = await self._exchange.emergency_close_all()
                    if emergency_fills:
                        log.warning(
                            "Emergency closed %d positions on shutdown",
                            len(emergency_fills),
                        )
            except Exception as exc:
                log.error("emergency_close_all raised: %s", exc, exc_info=True)
            # Gracefully stop the state API server if it was started.
            if state_api_task is not None:
                try:
                    if state_server is not None:
                        state_server.should_exit = True
                    await asyncio.wait_for(state_api_task, timeout=5.0)
                except asyncio.TimeoutError:
                    log.warning("State API did not stop within 5s — cancelling")
                    state_api_task.cancel()
                except asyncio.CancelledError:
                    pass
                except Exception as exc:
                    log.error("State API shutdown error: %s", exc, exc_info=True)
            self._state.snapshot_portfolio(self._strategy._portfolio)
            self._state.close()
            log.info("StrategyRunner shut down cleanly.")

    async def _run_tick_loop(self, ws) -> None:
        """Consume ticks from ``ws`` until shutdown or auto-kill.

        Extracted from :meth:`run` so the reconnect loop stays legible. Any
        connection drop surfaces as an exception from the underlying ``async
        for`` — that exception escapes this method and is caught by the
        reconnect loop in :meth:`run`.
        """
        async for tick in ws:
            if self._shutdown_requested:
                break

            # Set current tick time so emit_indicator() uses correct timestamp
            self._strategy._last_tick_ts = tick.timestamp_ms // 1000

            # Dispatch to strategy
            try:
                await self._strategy.on_data(tick)
            except Exception as exc:
                log.error("on_data raised an unhandled exception: %s", exc, exc_info=True)

            # Check pending limit orders against current tick price
            current_prices: dict[str, float] = {}
            if tick.symbol and isinstance(tick.payload, dict):
                price = (
                    tick.payload.get("close")
                    or tick.payload.get("price")
                    or tick.payload.get("yes_price")
                )
                if price is not None:
                    current_prices[tick.symbol] = float(price)
            await self._exchange.check_pending_orders(current_prices)

            # Refresh derived portfolio values (total_value, unrealized_pnl)
            # so the state API and Prometheus monitor see fresh mark-to-market.
            self._strategy._portfolio.recompute()

            # Update Prometheus metrics
            self._monitor.update(
                self._strategy._portfolio,
                open_order_count=len(self._strategy._open_orders),
            )

            self._tick_count += 1

            # Snapshot portfolio every ~60 ticks (cheap heuristic)
            if self._tick_count % 60 == 0:
                self._state.snapshot_portfolio(self._strategy._portfolio)

            # Persist indicator values every 10 ticks
            if self._tick_count % 10 == 0 and self._strategy._indicator_log:
                self._state.record_indicators(self._strategy.indicators)

            # Auto-kill if risk limits breached
            if self._risk.should_auto_kill(self._strategy._portfolio):
                log.error("Auto-kill triggered — shutting down")
                self._shutdown_requested = True
                break

    async def _sleep_honoring_shutdown(self, total_seconds: float) -> None:
        """Sleep up to ``total_seconds`` but bail early if shutdown is requested.

        Keeps the bot responsive to SIGTERM during the reconnect backoff sleep
        — without this, a 60s backoff would block shutdown for up to 60s.
        """
        slept = 0.0
        step = 0.25
        while slept < total_seconds and not self._shutdown_requested:
            await asyncio.sleep(min(step, total_seconds - slept))
            slept += step

    def _request_shutdown(self) -> None:
        """Signal handler — request a clean shutdown after the next tick."""
        log.info("SIGTERM received — requesting shutdown after next tick")
        self._shutdown_requested = True

    def _validate_subscriptions_against_tier(self) -> None:
        """Check the strategy's declared subscriptions against account limits.

        Raises :class:`auspicium.errors.TierLimitError` when an ohlcv
        subscription's interval is not in the tier's WS allowlist or when the
        total subscription count exceeds the per-connection cap.

        If ``/v1/account`` can't be reached the check is skipped — the server
        will still reject any violation with a structured ``TIER_LIMIT`` error.
        """
        try:
            from auspicium.account import get_tier
            tier = get_tier()
        except Exception as exc:
            log.warning(
                "Could not fetch tier info (%s) — skipping client-side WS validation",
                exc,
            )
            return

        subs = self._strategy._subscriptions
        for sub in subs:
            if sub.get("channel") != "ohlcv":
                continue  # ws_intervals only constrains ohlcv channels
            interval = sub.get("interval", "1m")
            if interval not in tier.ws_allowed_intervals:
                raise TierLimitError(
                    f"WebSocket interval {interval!r} is not available on the "
                    f"{tier.tier!r} tier. Allowed: {tier.ws_allowed_intervals}"
                )

        if len(subs) > tier.ws_max_subscriptions:
            raise TierLimitError(
                f"Strategy declared {len(subs)} subscriptions but the "
                f"{tier.tier!r} tier allows at most {tier.ws_max_subscriptions} "
                "per WebSocket connection."
            )

    # ------------------------------------------------------------------ #
    # Fill callback                                                         #
    # ------------------------------------------------------------------ #

    async def _on_fill(self, fill: Fill) -> None:
        """Called by PaperExchange after every simulated fill.

        Updates the strategy portfolio, persists the fill, notifies the
        strategy, and records the fill in Prometheus.
        """
        strategy = self._strategy
        portfolio = strategy._portfolio

        # Remove from open orders
        strategy._open_orders.pop(fill.order_id, None)

        # Update portfolio cash and positions from fill
        _apply_fill_to_portfolio(portfolio, fill)

        # Persist fill and updated positions
        self._state.record_fill(fill)
        for pos in portfolio.positions.values():
            self._state.update_position(pos)

        # Remove closed positions from DB
        # (a position is closed if it was removed from portfolio.positions by _apply_fill)
        # We detect this by comparing before/after — simpler: StateManager.remove_position
        # is called explicitly when we detect the position is gone.

        # Notify strategy
        try:
            await strategy.on_fill(fill)
        except Exception as exc:
            log.error("on_fill raised an unhandled exception: %s", exc, exc_info=True)

        # Record in Prometheus
        self._monitor.record_fill(fill)

    # ------------------------------------------------------------------ #
    # Helpers                                                               #
    # ------------------------------------------------------------------ #

    def _load_yaml(self, filename: str) -> dict:
        """Load a YAML file from the strategy directory. Returns {} if missing."""
        path = self._strategy_dir / filename
        if not path.exists():
            log.debug("%s not found in %s — using defaults", filename, self._strategy_dir)
            return {}
        try:
            return yaml.safe_load(path.read_text()) or {}
        except yaml.YAMLError as exc:
            log.warning("Failed to parse %s: %s", filename, exc)
            return {}


# ------------------------------------------------------------------ #
# Portfolio fill application                                           #
# ------------------------------------------------------------------ #

def _apply_fill_to_portfolio(portfolio: Portfolio, fill: Fill) -> None:
    """Apply a fill to a Portfolio in-place.

    Updates cash and positions. Called by the runner's fill callback.

    For BUY: deduct cost from cash, add/average into position.
    For SELL: add proceeds to cash, reduce/close position.
    Realized PnL and daily PnL are updated on close.
    """
    from auspicium.strategy.models import Position

    cost = fill.size * fill.price + fill.fee
    if fill.side == "BUY":
        portfolio.cash -= cost
        pos = portfolio.positions.get(fill.market)
        if pos is None:
            portfolio.positions[fill.market] = Position(
                market=fill.market,
                side="LONG",
                outcome=fill.outcome,
                size=fill.size,
                entry_price=fill.price,
            )
        else:
            total = pos.size + fill.size
            pos.entry_price = (pos.entry_price * pos.size + fill.price * fill.size) / total
            pos.size = total
    else:  # SELL
        proceeds = fill.size * fill.price - fill.fee
        portfolio.cash += proceeds
        pos = portfolio.positions.get(fill.market)
        if pos is not None:
            realized = (fill.price - pos.entry_price) * fill.size
            portfolio.realized_pnl += realized
            portfolio.daily_pnl += realized
            remaining = pos.size - fill.size
            if remaining <= 1e-9:
                del portfolio.positions[fill.market]
            else:
                pos.size = remaining
        else:
            # Short open
            portfolio.positions[fill.market] = Position(
                market=fill.market,
                side="SHORT",
                outcome=fill.outcome,
                size=fill.size,
                entry_price=fill.price,
            )


# ------------------------------------------------------------------ #
# CLI entry point                                                       #
# ------------------------------------------------------------------ #

def main() -> None:
    """CLI entry point for ``python -m auspicium.strategy.runner``."""
    parser = argparse.ArgumentParser(
        prog="auspicium.strategy.runner",
        description="Run an Auspicium trading strategy",
    )
    parser.add_argument(
        "--strategy-dir",
        default=".",
        help="Path to the strategy directory (contains config.yaml and manifest.yaml)",
    )
    parser.add_argument(
        "--strategy-class",
        required=True,
        help="Dotted import path to the Strategy subclass, e.g. my_strategy.MyStrategy",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging verbosity (default: INFO)",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)-8s %(name)s — %(message)s",
    )

    # Dynamically import the strategy class
    module_path, class_name = args.strategy_class.rsplit(".", 1)
    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        print(f"ERROR: Could not import module '{module_path}': {exc}", file=sys.stderr)
        sys.exit(1)

    strategy_cls = getattr(module, class_name, None)
    if strategy_cls is None:
        print(f"ERROR: Class '{class_name}' not found in module '{module_path}'", file=sys.stderr)
        sys.exit(1)

    if not issubclass(strategy_cls, Strategy):
        print(f"ERROR: '{class_name}' is not a subclass of Strategy", file=sys.stderr)
        sys.exit(1)

    runner = StrategyRunner(strategy_cls, strategy_dir=args.strategy_dir)
    asyncio.run(runner.run())


if __name__ == "__main__":
    main()
