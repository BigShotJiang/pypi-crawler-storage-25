# ----------------------------------------------------------------------------------------
#   client.py
#   ---------
#
#   HTTP client for cal-docs-server API. Uses only Python stdlib (urllib.request).
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   -------
#   bena (via Claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

# ----------------------------------------------------------------------------------------
#   Exceptions
# ----------------------------------------------------------------------------------------


class ClientError(Exception):
    """Error from the API client."""


# ----------------------------------------------------------------------------------------
#   Client
# ----------------------------------------------------------------------------------------


class DocsClient:
    """HTTP client for cal-docs-server API."""

    def __init__(self, server_url: str, token: str | None = None) -> None:
        """Initialize the client.

        Args:
            server_url: Base URL of the cal-docs-server (e.g., "http://localhost:8080")
            token: Optional API token for authenticated endpoints (upload)
        """
        self.server_url = server_url.rstrip("/")
        self.token = token
        self._verified = False
        self._server_version: str | None = None
        self._api_version: str | None = None
        self._last_content_disposition: str = ""

    # ------------------------------------------------------------------------------------
    #   HTTP Methods
    # ------------------------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        data: bytes | None = None,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> bytes:
        """Make an HTTP request.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: URL path (e.g., "/api/version")
            data: Optional request body
            headers: Optional headers
            timeout: Request timeout in seconds

        Returns:
            Response body as bytes

        Raises:
            ClientError: On HTTP or connection error
        """
        url = f"{self.server_url}{path}"
        req_headers = headers.copy() if headers else {}

        if self.token:
            req_headers["X-Token"] = self.token

        request = urllib.request.Request(
            url,
            data=data,
            headers=req_headers,
            method=method,
        )

        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                self._last_content_disposition = response.headers.get(
                    "Content-Disposition", ""
                )
                return response.read()
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            try:
                error_data = json.loads(body)
                message = error_data.get("message", body)
            except json.JSONDecodeError:
                message = body
            raise ClientError(f"HTTP {e.code}: {message}") from e
        except urllib.error.URLError as e:
            raise ClientError(f"Connection failed: {e.reason}") from e
        except TimeoutError as e:
            raise ClientError(f"Request timed out after {timeout}s") from e

    def _get(self, path: str) -> bytes:
        """Make a GET request."""
        return self._request("GET", path)

    def _get_json(self, path: str) -> Any:
        """Make a GET request and parse JSON response."""
        data = self._get(path)
        try:
            return json.loads(data)
        except json.JSONDecodeError as e:
            raise ClientError(f"Invalid JSON response: {e}") from e

    def _post(
        self,
        path: str,
        data: bytes,
        content_type: str,
        filename: str | None = None,
    ) -> bytes:
        """Make a POST request."""
        headers = {"Content-Type": content_type}
        if filename:
            headers["X-Filename"] = filename
        return self._request("POST", path, data, headers)

    def _delete(self, path: str) -> bytes:
        """Make a DELETE request."""
        return self._request("DELETE", path)

    # ------------------------------------------------------------------------------------
    #   Server Verification
    # ------------------------------------------------------------------------------------

    def verify_server(self) -> None:
        """Verify the server is cal-docs-server with a compatible API version.

        Accepts API version 1.x, rejects 2.x and above.

        Raises:
            ClientError: If server is not cal-docs-server or API version is incompatible
        """
        if self._verified:
            return

        data = self._get_json("/api/version")

        product = data.get("product", "")
        if product != "cal-docs-server":
            raise ClientError(
                f"Server is not cal-docs-server (product: {product or 'unknown'})"
            )

        api_version = data.get("apiVersion", "")
        if not api_version:
            raise ClientError("Server did not report an API version")

        # Parse major version
        try:
            major = int(api_version.split(".")[0])
        except (ValueError, IndexError):
            raise ClientError(f"Invalid API version format: {api_version}") from None

        if major != 1:
            raise ClientError(
                f"Incompatible API version: {api_version} (this client requires 1.x)"
            )

        self._verified = True
        self._server_version = data.get("version", "unknown")
        self._api_version = api_version

    @property
    def server_version(self) -> str:
        """Get the server version (requires verify_server to be called first)."""
        return self._server_version or "unknown"

    @property
    def api_version(self) -> str:
        """Get the API version (requires verify_server to be called first)."""
        return self._api_version or "unknown"

    # ------------------------------------------------------------------------------------
    #   API Methods
    # ------------------------------------------------------------------------------------

    def get_version(self) -> dict[str, str]:
        """Get server version information.

        Returns:
            Dict with 'product', 'version', and 'apiVersion' keys
        """
        return self._get_json("/api/version")

    def get_help(self) -> str:
        """Get the server's API help text.

        Returns:
            Plain text API documentation
        """
        return self._get("/api/help").decode("utf-8")

    def get_spec(self) -> dict[str, Any]:
        """Get the OpenAPI specification.

        Returns:
            OpenAPI spec as a dict
        """
        return self._get_json("/api/spec")

    def get_projects(self, search: str | None = None) -> dict[str, Any]:
        """List documentation projects.

        Args:
            search: Optional search term to filter projects

        Returns:
            Dict with 'projects' list and 'count' key
        """
        path = "/api/projects"
        if search:
            path = f"{path}?search={urllib.parse.quote(search)}"
        return self._get_json(path)

    def download(self, project: str, version: str = "latest") -> tuple[bytes, str]:
        """Download a documentation package.

        Args:
            project: Project name
            version: Version to download (default: "latest")

        Returns:
            Tuple of (zip file contents, filename from server)
        """
        path = (
            f"/api/download/{urllib.parse.quote(project)}/{urllib.parse.quote(version)}"
        )
        data = self._get(path)

        # Extract filename from Content-Disposition header
        filename = f"{project}-{version}-docs.zip"
        match = re.search(r'filename="?([^";]+)"?', self._last_content_disposition)
        if match:
            filename = match.group(1).strip()

        return data, filename

    def upload(self, filename: str, data: bytes) -> dict[str, Any]:
        """Upload a documentation package.

        Args:
            filename: Name of the zip file (e.g., "myproject-1.0.0-docs.zip")
            data: Zip file contents

        Returns:
            Server response with upload details

        Raises:
            ClientError: If upload fails (auth error, invalid file, etc.)
        """
        response = self._post("/api/upload", data, "application/zip", filename)
        try:
            return json.loads(response)
        except json.JSONDecodeError as e:
            raise ClientError(f"Invalid JSON response: {e}") from e

    def delete(self, project: str, version: str) -> dict[str, Any]:
        """Delete a documentation package version.

        Args:
            project: Project name
            version: Version to delete

        Returns:
            Server response with deletion details

        Raises:
            ClientError: If deletion fails (auth error, not found, etc.)
        """
        path = (
            f"/api/delete/{urllib.parse.quote(project)}/{urllib.parse.quote(version)}"
        )
        response = self._delete(path)
        try:
            return json.loads(response)
        except json.JSONDecodeError as e:
            raise ClientError(f"Invalid JSON response: {e}") from e
