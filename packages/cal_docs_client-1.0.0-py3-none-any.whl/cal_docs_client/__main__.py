# ----------------------------------------------------------------------------------------
#   __main__.py
#   -----------
#
#   Entry point for running the package as a module: python -m cal_docs_client
#
#   (c) 2026 Cyber Assessment Labs — MIT License; see LICENSE in the project root.
#
#   Authors
#   -------
#   bena (via Claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created
# ----------------------------------------------------------------------------------------

import sys

MIN_PYTHON = (3, 12)
if sys.version_info < MIN_PYTHON:
    print(f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]}+ is required.", file=sys.stderr)
    sys.exit(1)

from .cli import main  # noqa: E402

sys.exit(main())
