from __future__ import annotations

from typing import Any, Dict, List, Optional

import requests

from .exceptions import HumanizedTextAPIError


class HumanizedTextClient:
    def __init__(self, api_key: str, base_url: str = "https://api.humanizedtext.pro/api/v1", timeout: int = 60):
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _request(self, method: str, path: str, json_body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = {
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
        }

        response = requests.request(
            method=method,
            url=url,
            json=json_body,
            headers=headers,
            timeout=self.timeout,
        )

        try:
            payload = response.json()
        except Exception:
            payload = {"detail": response.text}

        if response.status_code >= 400:
            message = payload.get("detail", "Request failed") if isinstance(payload, dict) else "Request failed"
            raise HumanizedTextAPIError(str(message), status_code=response.status_code, payload=payload)

        return payload

    def humanize(
        self,
        text: str,
        tone: Optional[str] = None,
        ultra_humanize: bool = False,
        keywords: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {
            "text": text,
            "ultra_humanize": ultra_humanize,
        }
        if tone is not None:
            body["tone"] = tone
        if keywords is not None:
            body["keywords"] = keywords
        return self._request("POST", "/sdk/humanize", json_body=body)

    def grammar_fixer(self, text: str) -> Dict[str, Any]:
        return self._request("POST", "/sdk/grammar-fixer", json_body={"text": text})

    def content_rewriter(self, text: str) -> Dict[str, Any]:
        return self._request("POST", "/sdk/content-rewriter", json_body={"text": text})

    def seo_blog_writer(self, topic: str) -> Dict[str, Any]:
        return self._request("POST", "/sdk/seo-blog-writer", json_body={"topic": topic})
