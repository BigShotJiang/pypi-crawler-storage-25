class HumanizedTextAPIError(Exception):
    def __init__(self, message: str, status_code: int | None = None, payload=None):
        self.message = message
        self.status_code = status_code
        self.payload = payload
        super().__init__(message)
