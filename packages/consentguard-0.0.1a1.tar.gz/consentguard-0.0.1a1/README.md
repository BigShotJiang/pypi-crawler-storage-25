# ConsentGuard Python SDK

`consentguard` is the Python package for ConsentGuard, a governance layer for AI tool execution.

This first public release is an **early alpha scaffold** published to establish the package name and
the basic package identity on PyPI. It is intentionally minimal and does **not** yet expose the full
SDK surface that the main ConsentGuard repository is developing.

## What this alpha includes

- an installable `consentguard` package
- package metadata and project links
- a tiny `ConsentGuardClient` object for holding local configuration
- a small `about()` helper that describes the current alpha release

## What this alpha does not include yet

- the full `wrap()` execution flow
- network evaluation against the hosted ConsentGuard backend
- consent polling, audit metadata, or production-ready policy enforcement

If you are looking for the full SDK, follow the repository for upcoming releases:

- Homepage: https://getconsentguard.com
- Repository: https://github.com/SyyedAjwad/consentguard-sdk
