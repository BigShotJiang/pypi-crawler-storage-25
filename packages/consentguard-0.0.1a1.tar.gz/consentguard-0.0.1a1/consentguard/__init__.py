from .client import ConsentGuardClient, about

__all__ = [
    "ConsentGuardClient",
    "about",
]

__version__ = "0.0.1a1"
