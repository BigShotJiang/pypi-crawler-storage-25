from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ConsentGuardClient:
    """Tiny alpha scaffold for local ConsentGuard client configuration.

    This class is intentionally minimal for the first PyPI claim release and does not
    yet implement the full hosted ConsentGuard SDK behavior.
    """

    api_key: str
    base_url: str = "https://getconsentguard.com"

    def describe(self) -> dict[str, str]:
        masked = f"{self.api_key[:4]}..." if self.api_key else ""
        return {
            "package": "consentguard",
            "stage": "alpha",
            "base_url": self.base_url,
            "api_key_preview": masked,
        }


def about() -> dict[str, str]:
    return {
        "package": "consentguard",
        "version": "0.0.1a1",
        "stage": "alpha",
        "repository": "https://github.com/SyyedAjwad/consentguard-sdk",
    }
