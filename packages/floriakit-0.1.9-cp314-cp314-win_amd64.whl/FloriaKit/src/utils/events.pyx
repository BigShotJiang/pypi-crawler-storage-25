import typing as t
import weakref
import asyncio

from . import function


cdef class EventHandlerInfo:
    cdef public object weak_func # weakref.ReferenceType | callable
    cdef public bint once, wait

    def __init__(self, object weak_func, bint once = False, bint wait = True) -> None:
        self.weak_func = weak_func
        self.once = once
        self.wait = wait

    cpdef get_func(self):
        return func() if isinstance((func := self.weak_func), weakref.ReferenceType) else func

cdef class BaseEvent:
    cdef object __weakref__
    cdef dict[str, EventHandlerInfo] _handlers
    cdef bint _async_support, _is_invoked

    def __init__(self, async_support: bool):
        self._handlers = {}
        self._async_support = async_support
        self._is_invoked = False

    cpdef list _invoke(self, tuple args, dict kw):
        cdef set[str] to_remove = set()
        cdef list tasks = list()

        cdef str key
        cdef EventHandlerInfo handler
        cdef object func, result, task

        self._is_invoked = True

        for key, handler in self._handlers.items():
            if (func := handler.get_func()) is None or handler.once:
                to_remove.add(key)
                if func is None:
                    continue

            if asyncio.iscoroutine(result := func(*args, **kw)):
                if not self.async_support:
                    raise RuntimeError("Async handler triggered in sync-only event")
                task = asyncio.create_task(result)
                if handler.wait:
                    tasks.append(task)
                else:
                    task.add_done_callback(self._task_done_callback)

        self._is_invoked = False

        if to_remove:
            for key in to_remove:
                self._handlers.pop(key, None)

        return tasks

    @staticmethod
    def _task_done_callback(task):
        try:
            task.result()
        except asyncio.CancelledError:
            pass

    def register(self, func=None, *, once: bool = False, wait: bool = True):
        def decorator(func):
            if (key := function.get_key(func)) not in self._handlers:
                if self.is_invoking:
                    raise RuntimeError("Cannot register handler while event is being invoked")
                self._handlers[key] = EventHandlerInfo(
                    weak_func=(
                        weakref.WeakMethod(func) if hasattr(func, '__self__') else func
                    ),
                    once=once,
                    wait=wait,
                )
            return func

        if func is None:
            return decorator
        return decorator(func)

    def unregister(self, func=None):
        if func is not None:
            key = function.get_key(func)
            if key in self._handlers:
                if self.is_invoking:
                    raise RuntimeError("Cannot unregister handler while event is being invoked")
                self._handlers.pop(key)
        return func

    def __call__(self, func):
        return self.register(func)

    cpdef bool has_key(self, key: str | None):
        return key is not None and key in self._handlers

    cpdef bool has(self, object func):
        return False if func is None else self.has_key(function.get_key(func))

    def clear(self):
        self._handlers.clear()

    @property
    def async_support(self):
        return self._async_support

    @property
    def is_invoking(self):
        return self._is_invoked


class Event(BaseEvent):
    def __init__(self):
        super().__init__(False)

    def invoke(self, *args, **kwargs):
        if self._invoke(args, kwargs):
            raise RuntimeError(
                'Event has async handlers, use EventAsync or handle tasks manually'
            )


class EventAsync(BaseEvent):
    def __init__(self):
        super().__init__(True)

    async def invoke(self, *args, **kwargs):
        if (tasks := self._invoke(args, kwargs)):
            await asyncio.gather(*tasks, return_exceptions=True)


class EventAny(BaseEvent):
    def __init__(self):
        super().__init__(True)

    async def invoke_async(self, *args, **kwargs):
        if (tasks := self._invoke(args, kwargs)):
            await asyncio.gather(*tasks)

    def invoke_sync(self, *args, **kwargs):
        self._invoke(args, kwargs)
