import typing as t

from .. import protocols as proto

class BaseEvent[**P = [], R = t.Any]:
    def __init__(self, async_support: bool) -> None: ...
    @t.overload
    def register(
        self,
        func: proto.functions.AnyFunction[P, R],
        /,
    ) -> proto.functions.AnyFunction[P, R]: ...
    @t.overload
    def register(
        self,
        *,
        once: bool = False,
        wait: bool = True,
    ) -> t.Callable[
        [proto.functions.AnyFunction[P, R]],
        proto.functions.AnyFunction[P, R],
    ]: ...
    def unregister[T: proto.functions.AnyFunction[..., t.Any]](
        self,
        func: T | None = None,
    ) -> T | None: ...
    def __call__(
        self,
        func: proto.functions.AnyFunction[P, R],
    ) -> proto.functions.AnyFunction[P, R]: ...
    def has(
        self,
        func: proto.functions.AnyFunction[P, R] | None,
    ) -> bool: ...
    def has_key(self, key: str | None) -> bool: ...
    def clear(self) -> None: ...
    @property
    def async_support(self) -> bool: ...
    @property
    def is_invoking(self) -> bool: ...

class Event[**P = [], R = t.Any](BaseEvent[P, R]):
    def __init__(self) -> None: ...
    def invoke(self, *args: P.args, **kwargs: P.kwargs) -> t.Self: ...

class EventAsync[**P = [], R = t.Any](BaseEvent[P, R]):
    def __init__(self) -> None: ...
    async def invoke(self, *args: P.args, **kwargs: P.kwargs) -> t.Self: ...

class EventAny[**P = [], R = t.Any](BaseEvent[P, R]):
    async def invoke_async(self, *args: P.args, **kwargs: P.kwargs) -> t.Self: ...
    def invoke_sync(self, *args: P.args, **kwargs: P.kwargs) -> t.Self: ...

__all__ = [
    'Event',
    'EventAsync',
    'EventAny',
]
