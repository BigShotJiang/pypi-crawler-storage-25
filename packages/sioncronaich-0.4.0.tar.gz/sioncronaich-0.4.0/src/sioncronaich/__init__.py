"""sioncronaich — cron job output capture and monitoring."""

__version__ = "0.4.0"
