"""MinJoin: 基于哈希划分的近似字符串匹配。

找出编辑距离低于阈值的字符串对，使用 MinHash 风格的划分
来避免 O(n^2) 的暴力比较。
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Dict, List, Set, Tuple

import Levenshtein
import mmh3


class Partitioner:
    """基于哈希的字符串划分器，用于近似匹配。

    使用多个哈希函数将字符串划分为带锚点的片段，
    超过计算阈值的片段将被提取为相似度比较的候选。

    Attributes:
        segment_count: 字符串划分的片段数。
        ngram: 哈希使用的 n-gram 大小。
        hash_functions: 使用的哈希函数列表。
        partition_ratio: 用于计算最大片段长度的比例。
    """

    def __init__(
        self,
        segment_count: int,
        ngram: int,
        hash_functions: List[Callable[[str], int]],
        partition_ratio: float = 0.5,
    ):
        """初始化 Partitioner。

        Args:
            segment_count: 字符串划分的片段数。
            ngram: 哈希使用的 n-gram 大小。
            hash_functions: 使用的哈希函数列表。
            partition_ratio: 用于计算最大片段长度的比例。
        """
        self.segment_count = segment_count
        self.ngram = ngram
        self.hash_functions = hash_functions
        self.partition_ratio = partition_ratio

    def _find_anchors(self, s: str) -> List[List[int]]:
        """在字符串的每个片段中寻找局部最小值锚点。

        对每个哈希函数，滑动窗口标记在半径内为局部最小值的位置。

        Args:
            s: 输入的字符串。

        Returns:
            每个哈希函数对应的锚点位置列表。
        """
        all_anchors: List[List[int]] = []
        segment_length = int(len(s) / self.segment_count)
        radius = max(1, int(segment_length / 2))

        for hash_fn in self.hash_functions:
            anchors = [0]
            hashes = [hash_fn(s[i : i + self.ngram]) for i in range(len(s) - self.ngram + 1)]

            i = 0
            while i < len(hashes):
                offset = 1
                while offset <= radius:
                    if (i + offset >= len(hashes) or hashes[i] < hashes[i + offset]) and (
                        i - offset < 0 or hashes[i] < hashes[i - offset]
                    ):
                        offset += 1
                    else:
                        break

                if offset == radius + 1:
                    anchors.append(i)
                i += offset

            anchors.append(len(s))
            all_anchors.append(anchors)

        return all_anchors

    def _find_parts(self, s: str, anchors_list: List[List[int]]) -> List[Tuple[str, int]]:
        """从锚点位置提取超过阈值的片段。

        Args:
            s: 输入的字符串。
            anchors_list: 锚点位置列表。

        Returns:
            超过阈值的 (子串, 起始位置) 元组列表。
        """
        max_part_length = int(len(s) * self.partition_ratio / self.segment_count)
        result: Set[Tuple[str, int]] = set()

        for anchors in anchors_list:
            for i in range(1, len(anchors)):
                length = anchors[i] - anchors[i - 1]
                if length > max_part_length:
                    result.add((s[anchors[i - 1] : anchors[i]], anchors[i - 1]))

        return list(result)

    def partition(self, s: str) -> List[Tuple[str, int]]:
        """将字符串划分为候选片段。

        Returns:
            (子串, 起始位置) 元组列表。
        """
        anchors = self._find_anchors(s)
        return self._find_parts(s, anchors)


class MinJoin:
    """基于 MinJoin 划分的近似字符串匹配。

    将每个字符串划分为片段，按相同内容分组后，
    仅对共享片段且通过长度剪枝的字符串对计算编辑距离。

    Attributes:
        seeds: mmh3 哈希种子列表。
        sim: 相似度阈值（0.0 到 1.0）。
        ngram: 哈希使用的 n-gram 大小。
        segment_count: 计算出的片段数。
        partitioner: 已配置的 Partitioner 实例。

    Example::

        >>> min_join = MinJoin(seeds=[100, 200], max_length=35, sim=0.8, ngram=1)
        >>> texts = [
        ...     "福建琯溪蜜柚新鲜现摘水果2-3斤/个 微甜",
        ...     "福建琯溪蜜柚新鲜现摘水果2-3斤/个",
        ...     "补气益血 特级新疆灰枣1000g+50g包装随机",
        ...     "补气特级新疆灰枣1000g+50g包装随机",
        ... ]
        >>> result = min_join.process(texts)
    """

    def __init__(self, seeds: List[int], max_length: int, sim: float, ngram: int):
        """初始化 MinJoin。

        Args:
            seeds: mmh3 哈希种子列表。
            max_length: 用于计算片段数的最大字符串长度。
            sim: 相似度阈值（0.0 到 1.0）。
            ngram: 哈希使用的 n-gram 大小。
        """
        self.seeds = seeds
        self.sim = sim
        self.ngram = ngram
        self.segment_count = max(int(max_length * (1 - sim)), 2)
        self.partitioner = Partitioner(
            self.segment_count,
            self.ngram,
            [lambda s, seed=seed: mmh3.hash(s, seed) for seed in self.seeds],
        )

    def process(self, contents: List[str]) -> Dict[str, List[str]]:
        """找出相似度超过阈值的字符串对。

        Args:
            contents: 待比较的输入字符串列表。

        Returns:
            将每个字符串映射到与其相似的字符串列表的字典。

        Example::

            >>> min_join = MinJoin(seeds=[100, 200], max_length=35, sim=0.8, ngram=1)
            >>> min_join.process(["apple pie", "apple"])
            {'apple pie': ['apple'], 'apple': ['apple pie']}
        """
        substring_table: Dict[str, List[Tuple[str, int]]] = {}
        for s in contents:
            for sub, index in self.partitioner.partition(s):
                substring_table.setdefault(sub, []).append((s, index))

        result: Dict[str, List[str]] = {}
        for _, entries in substring_table.items():
            entries.sort(key=lambda x: len(x[0]))

            for i in range(len(entries)):
                left, left_index = entries[i]
                left_len = len(left)
                for j in range(i + 1, len(entries)):
                    right, right_index = entries[j]
                    if right == left or right in result.get(left, []):
                        continue
                    right_len = len(right)
                    threshold = (1 - self.sim) * right_len

                    if right_len - left_len > threshold:
                        break
                    if (
                        abs(left_index - right_index)
                        + abs(left_len - left_index - right_len + right_index)
                        > threshold
                    ):
                        continue
                    if Levenshtein.distance(left, right) > threshold:
                        continue

                    result.setdefault(left, []).append(right)
                    result.setdefault(right, []).append(left)

        return result


def generate_edges(
    text_ids_mapping: Dict[str, Set[str]],
    min_join: MinJoin,
) -> Set[Tuple[str, str]]:
    """为相似文本对构建边，用于去重聚类。

    典型场景：同一产品通过多个渠道录入，文本存在细微差异。
    该函数构建一个图，其中 ID 为节点，边连接指向同一产品的记录，
    然后可以将连通分量合并为单个实体。

    Args:
        text_ids_mapping: 从文本内容到关联 ID 集合的映射。
        min_join: 已配置的 MinJoin 实例，用于相似度检测。

    Returns:
        (id_a, id_b) 元组集合，其中 id_a < id_b。

    Example::

        >>> min_join = MinJoin(seeds=[100, 200], max_length=35, sim=0.8, ngram=1)
        >>> text_ids = {
        ...     "福建琯溪蜜柚2-3斤": {"id_001", "id_002"},  # 相同文本，两条记录
        ...     "福建琯溪蜜柚新鲜2-3斤": {"id_003"},         # 相似文本
        ...     "新疆灰枣1000g": {"id_004", "id_005"},      # 相同文本，两条记录
        ... }
        >>> edges = generate_edges(text_ids, min_join)
        >>> ("id_001", "id_002") in edges  # 相同文本 -> 连通
        True
        >>> ("id_001", "id_003") in edges  # 相似文本 -> 连通
        True
        >>> ("id_004", "id_005") in edges  # 相同文本 -> 连通
        True

    获取边之后，可使用并查集或图遍历找到连通分量并聚类 ID。
    """
    similar = min_join.process(list(text_ids_mapping.keys()))
    edges: Set[Tuple[str, str]] = set()

    for key, similar_values in similar.items():
        for left_id in text_ids_mapping.get(key, []):
            for value in similar_values:
                for right_id in text_ids_mapping.get(value, []):
                    if left_id < right_id:
                        edges.add((left_id, right_id))

    # 将映射到相同文本的所有 ID 互相连接
    for ids in text_ids_mapping.values():
        sorted_ids = sorted(ids)
        for i in range(len(sorted_ids)):
            for j in range(i + 1, len(sorted_ids)):
                edges.add((sorted_ids[i], sorted_ids[j]))

    return edges
