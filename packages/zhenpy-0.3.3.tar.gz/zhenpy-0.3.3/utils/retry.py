from functools import wraps
import random
import logging
import time

import requests

logger = logging.getLogger(__name__)


def retry(max_retries=3, base_delay=1, exceptions=(requests.exceptions.RequestException,)):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exc = e
                    jitter = random.uniform(0, base_delay * (2 ** attempt))
                    logger.warning(
                        "Attempt %d/%d failed for %s: %s, retrying in %.2fs",
                        attempt + 1, max_retries, func.__qualname__, e, jitter,
                    )
                    if attempt < max_retries - 1:
                        time.sleep(jitter)
            raise last_exc
        return wrapper
    return decorator
