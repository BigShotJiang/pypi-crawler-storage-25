"""日志模块

用法:
    from utils.logger import get_logger

    logger = get_logger("my_module")
    logger.info("hello")

环境变量:
    LOG_DIR       日志目录，默认 ./logs
    LOG_LEVEL     日志级别，默认 DEBUG
    MAX_LOG_SIZE  单个日志文件最大字节数，默认 100MB
    BACKUP_COUNT  日志保留份数，默认 7
"""

import logging
import os
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler

_LOG_DIR = os.getenv("LOG_DIR", "./logs")
_MAX_LOG_SIZE = int(os.getenv("MAX_LOG_SIZE", 100 * 1024 * 1024))
_BACKUP_COUNT = int(os.getenv("BACKUP_COUNT", 7))
_LOG_LEVEL = os.getenv("LOG_LEVEL", "DEBUG").upper()

_FMT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


def get_logger(
    name: str,
    level: str | None = None,
    log_dir: str | None = None,
    max_bytes: int | None = None,
    backup_count: int | None = None,
    encoding: str = "utf-8",
    use_timed: bool = False,
) -> logging.Logger:
    """获取或创建日志器。同名日志器只会初始化一次 handler。

    Args:
        name: 日志器名称
        level: 日志级别，覆盖全局默认
        log_dir: 日志目录，覆盖默认
        max_bytes: 单文件最大字节数，覆盖默认
        backup_count: 保留份数，覆盖默认
        encoding: 日志文件编码
        use_timed: 是否按天切割日志（True 用 TimedRotatingFileHandler，否则用 RotatingFileHandler）
    """
    logger = logging.getLogger(name)

    # 已经初始化过，直接返回（避免重复添加 handler）
    if logger.handlers:
        return logger

    lvl = getattr(logging, (level or _LOG_LEVEL).upper(), logging.DEBUG)
    logger.setLevel(lvl)

    directory = log_dir or _LOG_DIR
    os.makedirs(directory, exist_ok=True)

    formatter = logging.Formatter(_FMT)
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    logger.addHandler(console)

    file_path = os.path.join(directory, f"{name}.log")

    if use_timed:
        file_handler = TimedRotatingFileHandler(
            filename=file_path,
            when="midnight",
            interval=1,
            backupCount=backup_count or _BACKUP_COUNT,
            encoding=encoding,
        )
    else:
        file_handler = RotatingFileHandler(
            filename=file_path,
            maxBytes=max_bytes or _MAX_LOG_SIZE,
            backupCount=backup_count or _BACKUP_COUNT,
            encoding=encoding,
        )

    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger
