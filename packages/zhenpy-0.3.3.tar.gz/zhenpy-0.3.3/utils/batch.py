from typing import Iterator, Tuple, TypeVar

import pandas as pd

T = TypeVar("T")


def batch_dataframe(df: pd.DataFrame, batch_size: int) -> Iterator[Tuple[int, pd.DataFrame]]:
    """按批次切分 DataFrame 的生成器。

    参数:
        df: 要切分的 DataFrame
        batch_size: 每个批次的大小

    返回:
        生成器，每次返回 (起始索引, 批次DataFrame)
    """
    for i in range(0, len(df), batch_size):
        yield i, df.iloc[i : i + batch_size]


def batch_numpy(data, batch_size: int) -> Iterator:
    """按批次切分可切片对象的生成器。

    参数:
        data: 要切分的对象（numpy 数组、列表等）
        batch_size: 每个批次的大小

    返回:
        生成器，每次返回一个批次的数据
    """
    for i in range(0, len(data), batch_size):
        yield data[i : i + batch_size]
