#!/usr/bin/env python
# coding=utf-8

"""
SumTree 实现优先经验回放（Prioritized Experience Replay）。

用于强化学习中按 TD-error 优先级采样：误差越大的经验被采到的概率越高，
从而加速模型收敛。
"""

import numpy


class SumTree:
    """二叉树结构，叶子存储样本优先级，内部节点存储子节点之和，支持 O(log N) 加权采样。

    工作原理：
        将 [0, 总优先级) 区间按每个样本的优先级分割成连续子区间，
        区间宽度等于该样本的优先级。在该区间内均匀随机取一个值，
        值落在哪个样本的区间就选中哪个样本。优先级越大的样本区间越宽，
        被选中的概率越高。二叉树结构使采样过程从朴素遍历的 O(N) 降为 O(log N)。
        样本按写入顺序依次放入叶子节点，无需预先排序。

    Example::

        # 添加优先级分别为 1, 2, 7 的三个样本
        tree = SumTree(capacity=3)
        tree.add(1.0, "A")
        tree.add(2.0, "B")
        tree.add(7.0, "C")
        # 区间划分: [0, 1) -> A, [1, 3) -> B, [3, 10) -> C
        # 随机数 s = 5.0，大于左子树和(3)，走右子树，命中 C
        s = random.uniform(0, tree.total())
        _, priority, data = tree.get(s)  # 大概率采样到 C (70% 概率)

    Attributes:
        capacity: 经验回放缓冲区容量（叶子节点数）。
        tree: 大小为 2*capacity-1 的数组，存储树的节点值。
        data: 大小为 capacity 的数组，存储实际样本数据。
        write: 下一个写入位置（环形指针）。
    """

    write = 0

    def __init__(self, capacity):
        """初始化 SumTree。

        Args:
            capacity: 缓冲区最大容量。
        """
        self.capacity = capacity
        self.tree = numpy.zeros(2 * capacity - 1)
        self.data = numpy.zeros(capacity, dtype=object)

    def _propagate(self, idx, change):
        """自底向上传播优先级变化。

        Args:
            idx: 发生变化的节点索引。
            change: 变化量（新值 - 旧值）。
        """
        parent = (idx - 1) // 2
        self.tree[parent] += change
        if parent != 0:
            self._propagate(parent, change)

    def _retrieve(self, idx, s):
        """从指定节点向下查找，定位累积和为 s 的叶子节点。

        Args:
            idx: 当前节点索引。
            s: 目标累积和。

        Returns:
            目标叶子节点的索引。
        """
        left = 2 * idx + 1
        right = left + 1
        if left >= len(self.tree):
            return idx
        if s <= self.tree[left]:
            return self._retrieve(left, s)
        else:
            return self._retrieve(right, s - self.tree[left])

    def total(self):
        """返回所有优先级之和（即根节点的值）。

        Returns:
            float: 优先级总和。
        """
        return self.tree[0]

    def add(self, p, data):
        """添加新样本及其优先级。写满后从头部循环覆盖。

        Args:
            p: 样本优先级（通常为正数，如 TD-error 的平方）。
            data: 样本数据（任意类型）。
        """
        idx = self.write + self.capacity - 1
        self.data[self.write] = data
        self.update(idx, p)
        self.write += 1
        if self.write >= self.capacity:
            self.write = 0

    def update(self, idx, p):
        """更新指定叶子节点的优先级并传播到根。

        Args:
            idx: 树中节点索引（叶子节点范围为 capacity-1 ~ 2*capacity-2）。
            p: 新的优先级值。
        """
        change = p - self.tree[idx]
        self.tree[idx] = p
        self._propagate(idx, change)

    def get(self, s):
        """根据累积和 s 采样一个样本。

        Args:
            s: 范围在 [0, total()] 内的值，通常通过 random.uniform(0, total()) 生成。

        Returns:
            tuple: (树中节点索引, 优先级值, 样本数据)。
        """
        idx = self._retrieve(0, s)
        dataIdx = idx - self.capacity + 1
        return (idx, self.tree[idx], self.data[dataIdx])


if __name__ == "__main__":
    # 示例：创建容量为 10 的 SumTree
    tree = SumTree(capacity=10)

    # 添加样本：(优先级, 数据)
    experiences = [
        (1.0, "experience_0"),
        (3.0, "experience_1"),
        (5.0, "experience_2"),
        (2.0, "experience_3"),
        (8.0, "experience_4"),
    ]
    for priority, data in experiences:
        tree.add(priority, data)

    print(f"优先级总和: {tree.total():.1f}")  # 1 + 3 + 5 + 2 + 8 = 19.0

    # 按优先级采样：优先级越高的样本被采到的概率越大
    import random
    print("\n采样 10 次（观察高优先级样本出现更频繁）:")
    for _ in range(10):
        s = random.uniform(0, tree.total())
        idx, priority, data = tree.get(s)
        print(f"  采样到: {data} (优先级={priority:.1f})")

    # 更新某个样本的优先级（模拟 TD-error 变化后的重新采样）
    print("\n更新 experience_2 的优先级为 20.0:")
    tree.update(idx=tree.capacity - 1 + 2, p=20.0)  # 叶子索引 = capacity - 1 + 样本位置
    print(f"更新后优先级总和: {tree.total():.1f}")

    # 再次采样，experience_2 出现频率显著提升
    print("\n采样 10 次（experience_2 应更频繁出现）:")
    for _ in range(10):
        s = random.uniform(0, tree.total())
        idx, priority, data = tree.get(s)
        print(f"  采样到: {data} (优先级={priority:.1f})")


