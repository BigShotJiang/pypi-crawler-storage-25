
"""文本字符串相似度计算工具。

参考 python-string-similarity 项目，提供多种字符串距离和相似度算法，
包括 Levenshtein、Jaro-Winkler、Cosine、Jaccard、SIFT4 等。
"""

import math
import re
from abc import ABC, abstractmethod
from typing import Callable, Dict, Optional, Tuple

_SPACE_PATTERN = re.compile(r"\s+")


# ---------------------------------------------------------------------------
# 协议基类
# ---------------------------------------------------------------------------

class StringDistance(ABC):
    """字符串距离协议。"""

    @abstractmethod
    def distance(self, s0: str, s1: str) -> float:
        ...


class StringSimilarity(ABC):
    """字符串相似度协议。"""

    @abstractmethod
    def similarity(self, s0: str, s1: str) -> float:
        ...


# ---------------------------------------------------------------------------
# N-gram / Shingle 工具
# ---------------------------------------------------------------------------

def _get_ngram_profile(text: str, ngram: int) -> Dict[str, int]:
    """生成文本的 n-gram 频率字典。"""
    normalized = _SPACE_PATTERN.sub(" ", text)
    profile: Dict[str, int] = {}
    for i in range(len(normalized) - ngram + 1):
        shingle = normalized[i:i + ngram]
        profile[shingle] = profile.get(shingle, 0) + 1
    return profile


def _profile_union_keys(*profiles: Dict[str, int]) -> set:
    """合并多个 profile 的所有键。"""
    keys = set()
    for p in profiles:
        keys.update(p)
    return keys


def _dot_product(p0: Dict[str, int], p1: Dict[str, int]) -> float:
    """两个频率向量的点积，小字典优先遍历。"""
    small, large = (p0, p1) if len(p0) < len(p1) else (p1, p0)
    return sum(v * large.get(k, 0) for k, v in small.items())


def _norm(profile: Dict[str, int]) -> float:
    """频率向量的 L2 范数。"""
    return math.sqrt(sum(v * v for v in profile.values()))


# ---------------------------------------------------------------------------
# Levenshtein 系列
# ---------------------------------------------------------------------------

class Levenshtein(StringDistance):
    """标准 Levenshtein 编辑距离。

    示例:
        >>> lev = Levenshtein()
        >>> lev.distance("hello", "hallo")
        1.0
    """

    def distance(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 0.0
        if not s0:
            return float(len(s1))
        if not s1:
            return float(len(s0))

        v0 = list(range(len(s1) + 1))
        v1 = [0] * (len(s1) + 1)

        for i, c0 in enumerate(s0):
            v1[0] = i + 1
            for j, c1 in enumerate(s1):
                cost = 0 if c0 == c1 else 1
                v1[j + 1] = min(v1[j] + 1, v0[j + 1] + 1, v0[j] + cost)
            v0, v1 = v1, v0

        return v0[len(s1)]


class NormalizedLevenshtein(StringDistance, StringSimilarity):
    """归一化 Levenshtein 距离 [0,1] 与相似度 [0,1]。

    示例:
        >>> nlev = NormalizedLevenshtein()
        >>> nlev.distance("hello", "hallo")
        0.2
        >>> nlev.similarity("hello", "hallo")
        0.8
    """

    def __init__(self):
        self._levenshtein = Levenshtein()

    def distance(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 0.0
        max_len = max(len(s0), len(s1))
        if max_len == 0:
            return 0.0
        return self._levenshtein.distance(s0, s1) / max_len

    def similarity(self, s0: str, s1: str) -> float:
        return 1.0 - self.distance(s0, s1)


class WeightedLevenshtein(StringDistance):
    """支持自定义插入/删除/替换代价的 Levenshtein 距离。

    示例:
        >>> # 默认代价
        >>> wl = WeightedLevenshtein()
        >>> wl.distance("hello", "hallo")
        1.0
        >>> # 自定义替换代价：元音替换代价更低
        >>> def vowel_sub(a, b):
        ...     vowels = "aeiou"
        ...     if a in vowels and b in vowels:
        ...         return 0.5
        ...     return 1.0
        >>> wl2 = WeightedLevenshtein(substitution_cost_fn=vowel_sub)
    """

    def __init__(
        self,
        substitution_cost_fn: Optional[Callable] = None,
        insertion_cost_fn: Optional[Callable] = None,
        deletion_cost_fn: Optional[Callable] = None,
    ):
        self.sub_cost = substitution_cost_fn or self._default_sub_cost
        self.ins_cost = insertion_cost_fn or self._default_ins_cost
        self.del_cost = deletion_cost_fn or self._default_del_cost

    @staticmethod
    def _default_sub_cost(*_):
        return 1.0

    @staticmethod
    def _default_ins_cost(*_):
        return 1.0

    @staticmethod
    def _default_del_cost(*_):
        return 1.0

    def distance(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 0.0
        if not s0:
            return sum(self.ins_cost(c) for c in s1)
        if not s1:
            return sum(self.del_cost(c) for c in s0)

        v0 = [0.0] * (len(s1) + 1)
        v1 = [0.0] * (len(s1) + 1)
        for i in range(1, len(v0)):
            v0[i] = v0[i - 1] + self.ins_cost(s1[i - 1])

        for c0 in s0:
            v1[0] = v0[0] + self.del_cost(c0)
            for j, c1 in enumerate(s1):
                cost = 0 if c0 == c1 else self.sub_cost(c0, c1)
                v1[j + 1] = min(
                    v1[j] + self.ins_cost(c1),
                    v0[j + 1] + self.del_cost(c0),
                    v0[j] + cost,
                )
            v0, v1 = v1, v0

        return v0[len(s1)]


# ---------------------------------------------------------------------------
# Cosine / Jaccard / QGram / Overlap / Dice （基于 N-gram profile）
# ---------------------------------------------------------------------------

class CosineSimilarity(StringDistance, StringSimilarity):
    """基于 N-gram 的余弦相似度。

    示例:
        >>> cos = CosineSimilarity(ngram=3)
        >>> round(cos.similarity("Shanghai", "ShangHai"), 4)
        0.5
        >>> round(cos.distance("Shanghai", "ShangHai"), 4)
        0.5
    """

    def __init__(self, ngram: int = 3):
        self.ngram = ngram

    def distance(self, s0: str, s1: str) -> float:
        return 1.0 - self.similarity(s0, s1)

    def similarity(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 1.0
        if len(s0) < self.ngram or len(s1) < self.ngram:
            return 0.0
        p0, p1 = _get_ngram_profile(s0, self.ngram), _get_ngram_profile(s1, self.ngram)
        denom = _norm(p0) * _norm(p1)
        return 0.0 if denom == 0 else _dot_product(p0, p1) / denom


class Jaccard(StringDistance, StringSimilarity):
    """基于 N-gram 的 Jaccard 相似度与距离。

    示例:
        >>> jac = Jaccard(ngram=3)
        >>> round(jac.similarity("Shanghai", "ShangHai"), 4)
        0.3333
    """

    def __init__(self, ngram: int = 3):
        self.ngram = ngram

    def distance(self, s0: str, s1: str) -> float:
        return 1.0 - self.similarity(s0, s1)

    def similarity(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 1.0
        if len(s0) < self.ngram or len(s1) < self.ngram:
            return 0.0
        p0, p1 = _get_ngram_profile(s0, self.ngram), _get_ngram_profile(s1, self.ngram)
        union = _profile_union_keys(p0, p1)
        intersection = len(p0) + len(p1) - len(union)
        return intersection / len(union) if union else 0.0


class QGram(StringDistance):
    """Q-Gram 距离（N-gram 频率向量的 L1 差）。

    示例:
        >>> qg = QGram(k=3)
        >>> qg.distance("hello", "hallo")
        4
    """

    def __init__(self, k: int = 3):
        self.k = k

    def distance(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 0.0
        p0, p1 = _get_ngram_profile(s0, self.k), _get_ngram_profile(s1, self.k)
        return sum(abs(p0.get(k, 0) - p1.get(k, 0)) for k in _profile_union_keys(p0, p1))


class OverlapCoefficient(StringDistance, StringSimilarity):
    """Overlap 重叠系数。

    示例:
        >>> ov = OverlapCoefficient(ngram=3)
        >>> round(ov.similarity("Shanghai", "ShangHai"), 4)
        0.5
    """

    def __init__(self, ngram: int = 3):
        self.ngram = ngram

    def distance(self, s0: str, s1: str) -> float:
        return 1.0 - self.similarity(s0, s1)

    def similarity(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 1.0
        p0, p1 = _get_ngram_profile(s0, self.ngram), _get_ngram_profile(s1, self.ngram)
        union = _profile_union_keys(p0, p1)
        intersection = len(p0) + len(p1) - len(union)
        return intersection / min(len(p0), len(p1)) if min(len(p0), len(p1)) > 0 else 0.0


class SorensenDice(StringDistance, StringSimilarity):
    """Sorensen-Dice 系数。

    示例:
        >>> sd = SorensenDice(ngram=3)
        >>> round(sd.similarity("Shanghai", "ShangHai"), 4)
        0.5
    """

    def __init__(self, ngram: int = 3):
        self.ngram = ngram

    def distance(self, s0: str, s1: str) -> float:
        return 1.0 - self.similarity(s0, s1)

    def similarity(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 1.0
        p0, p1 = _get_ngram_profile(s0, self.ngram), _get_ngram_profile(s1, self.ngram)
        union = _profile_union_keys(p0, p1)
        intersection = len(p0) + len(p1) - len(union)
        return 2.0 * intersection / (len(p0) + len(p1))


# ---------------------------------------------------------------------------
# LCS / MetricLCS
# ---------------------------------------------------------------------------

class LongestCommonSubsequence(StringDistance):
    """最长公共子序列距离。

    示例:
        >>> lcs = LongestCommonSubsequence()
        >>> lcs.distance("hello", "hallo")
        2
    """

    def distance(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 0.0
        return len(s0) + len(s1) - 2 * self._length(s0, s1)

    @staticmethod
    def _length(s0: str, s1: str) -> int:
        m, n = len(s0), len(s1)
        dp = [0] * (n + 1)
        for i in range(1, m + 1):
            prev = 0
            for j in range(1, n + 1):
                temp = dp[j]
                if s0[i - 1] == s1[j - 1]:
                    dp[j] = prev + 1
                else:
                    dp[j] = max(dp[j], dp[j - 1])
                prev = temp
        return dp[n]


class MetricLCS(StringDistance):
    """归一化 LCS 距离。

    示例:
        >>> mlcs = MetricLCS()
        >>> round(mlcs.distance("hello", "hallo"), 4)
        0.2
    """

    def __init__(self):
        self._lcs = LongestCommonSubsequence()

    def distance(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 0.0
        max_len = max(len(s0), len(s1))
        if max_len == 0:
            return 0.0
        return 1.0 - self._lcs._length(s0, s1) / max_len


# ---------------------------------------------------------------------------
# N-Gram 距离
# ---------------------------------------------------------------------------

class NGram(StringDistance):
    """基于 N-Gram 的编辑距离变体。

    示例:
        >>> ng = NGram(n=2)
        >>> round(ng.distance("hello", "hallo"), 4)
        0.2
    """

    def __init__(self, n: int = 2):
        self.n = n

    def distance(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 0.0
        sl, tl = len(s0), len(s1)
        if sl == 0 or tl == 0:
            return 1.0
        if sl < self.n or tl < self.n:
            matches = sum(1 for a, b in zip(s0, s1) if a == b)
            return 1.0 - matches / max(sl, tl)

        pad = '\n'
        sa = [pad] * (self.n - 1) + list(s0)
        p = list(range(sl + 1))
        d = [0.0] * (sl + 1)

        for j in range(1, tl + 1):
            tj = [pad] * max(0, self.n - j)
            if j >= self.n:
                tj += list(s1[j - self.n:j])
            else:
                tj += list(s1[:j])

            d[0] = float(j)
            for i in range(1, sl + 1):
                cost = sum(1 for ni in range(self.n) if sa[i - 1 + ni] != tj[ni])
                tn = self.n - sum(1 for ni in range(self.n) if sa[i - 1 + ni] == pad)
                ec = cost / tn if tn else 1.0
                d[i] = min(d[i - 1] + 1, p[i] + 1, p[i - 1] + ec)
            p, d = d, p

        return p[sl] / max(tl, sl)


# ---------------------------------------------------------------------------
# Optimal String Alignment (受限 Damerau-Levenshtein)
# ---------------------------------------------------------------------------

class OptimalStringAlignment(StringDistance):
    """最优字符串对齐距离（受限 Damerau-Levenshtein）。

    示例:
        >>> osa = OptimalStringAlignment()
        >>> osa.distance("ab", "ba")
        1.0
    """

    def distance(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 0.0
        n, m = len(s0), len(s1)
        if n == 0:
            return float(m)
        if m == 0:
            return float(n)

        d = [[0] * (m + 1) for _ in range(n + 1)]
        for i in range(n + 1):
            d[i][0] = i
        for j in range(m + 1):
            d[0][j] = j

        for i in range(1, n + 1):
            for j in range(1, m + 1):
                cost = 0 if s0[i - 1] == s1[j - 1] else 1
                d[i][j] = min(d[i - 1][j - 1] + cost, d[i][j - 1] + 1, d[i - 1][j] + 1)
                if i > 1 and j > 1 and s0[i - 1] == s1[j - 2] and s0[i - 2] == s1[j - 1]:
                    d[i][j] = min(d[i][j], d[i - 2][j - 2] + cost)

        return float(d[n][m])


# ---------------------------------------------------------------------------
# Jaro-Winkler
# ---------------------------------------------------------------------------

class JaroWinkler(StringDistance, StringSimilarity):
    """Jaro-Winkler 相似度与距离。

    对前缀匹配敏感，适合姓名、地名等短字符串比较。

    参数:
        threshold: Jaro 分数阈值，超过此值才应用前缀加权

    示例:
        >>> jw = JaroWinkler()
        >>> round(jw.similarity("hello", "hallo"), 4)
        0.88
        >>> round(jw.distance("hello", "hallo"), 4)
        0.12
    """

    def __init__(self, threshold: float = 0.7):
        self.threshold = threshold

    def similarity(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 1.0
        matches, transpositions, prefix, _ = self._matches(s0, s1)
        if matches == 0:
            return 0.0
        jaro = (matches / len(s0) + matches / len(s1) + (matches - transpositions) / matches) / 3
        if jaro > self.threshold:
            return jaro + min(0.1, 1.0 / matches) * prefix * (1 - jaro)
        return jaro

    def distance(self, s0: str, s1: str) -> float:
        return 1.0 - self.similarity(s0, s1)

    @staticmethod
    def _matches(s0: str, s1: str) -> Tuple[int, int, int, int]:
        if len(s0) > len(s1):
            max_str, min_str = s1, s0
        else:
            max_str, min_str = s0, s1

        match_range = max(len(max_str) // 2 - 1, 0)
        match_flags = [False] * len(max_str)
        matches = 0

        for i, c in enumerate(min_str):
            start = max(i - match_range, 0)
            end = min(i + match_range + 1, len(max_str))
            for j in range(start, end):
                if not match_flags[j] and c == max_str[j]:
                    match_flags[j] = True
                    matches += 1
                    break

        ms0, ms1 = [], []
        si = 0
        for i in range(len(min_str)):
            if match_flags[i]:
                ms0.append(min_str[i])
                si += 1
        si = 0
        for j in range(len(max_str)):
            if match_flags[j]:
                ms1.append(max_str[j])
                si += 1

        transpositions = sum(1 for a, b in zip(ms0, ms1) if a != b) // 2

        prefix = 0
        for a, b in zip(s0, s1):
            if a == b:
                prefix += 1
            else:
                break

        return matches, transpositions, prefix, len(max_str)


# ---------------------------------------------------------------------------
# Damerau-Levenshtein (完整)
# ---------------------------------------------------------------------------

class Damerau(StringDistance):
    """完整 Damerau-Levenshtein 距离（允许相邻字符转置）。

    示例:
        >>> dam = Damerau()
        >>> dam.distance("ab", "ba")
        1.0
    """

    def distance(self, s0: str, s1: str) -> float:
        if s0 == s1:
            return 0.0
        inf = len(s0) + len(s1)
        da = {c: 0 for c in set(s0) | set(s1)}
        h = [[0] * (len(s1) + 2) for _ in range(len(s0) + 2)]

        for i in range(len(s0) + 1):
            h[i + 1][0] = inf
            h[i + 1][1] = i
        for j in range(len(s1) + 1):
            h[0][j + 1] = inf
            h[1][j + 1] = j

        for i in range(1, len(s0) + 1):
            db = 0
            for j in range(1, len(s1) + 1):
                i1 = da[s1[j - 1]]
                j1 = db
                cost = 0 if s0[i - 1] == s1[j - 1] else 1
                if cost == 0:
                    db = j
                h[i + 1][j + 1] = min(
                    h[i][j] + cost,
                    h[i + 1][j] + 1,
                    h[i][j + 1] + 1,
                    h[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
                )
            da[s0[i - 1]] = i

        return h[len(s0) + 1][len(s1) + 1]


# ---------------------------------------------------------------------------
# SIFT4
# ---------------------------------------------------------------------------

class SIFT4Options:
    """SIFT4 算法的配置选项。

    参数:
        options: 配置字典，支持以下键：
            - maxdistance: 最大距离阈值（int）
            - tokenizer: 分词函数或预定义名称（"ngram"/"wordsplit"/"characterfrequency"）
            - tokenmatcher: token 匹配函数
            - matchingevaluator: 匹配评分函数
            - locallengthevaluator: 局部长度评估函数
            - transpositioncostevaluator: 转置代价评估函数
            - transpositionsevaluator: 转置评估函数

    示例:
        >>> # 默认配置
        >>> opts = SIFT4Options()
        >>> # 使用 wordsplit 分词器
        >>> opts2 = SIFT4Options({"tokenizer": "wordsplit"})
        >>> # 设置最大距离阈值
        >>> opts3 = SIFT4Options({"maxdistance": 10})
    """

    _DEFAULTS = {
        'maxdistance': 0,
        'tokenizer': lambda x: list(x),
        'tokenmatcher': lambda t1, t2: t1 == t2,
        'matchingevaluator': lambda *_: 1,
        'locallengthevaluator': lambda x: x,
        'transpositioncostevaluator': lambda *_: 1,
        'transpositionsevaluator': lambda lcss, trans: lcss - trans,
    }

    _PRESETS = {
        'tokenizer': {
            'ngram': lambda s, n=3: [s[i:i + n] for i in range(len(s) - n + 1)],
            'wordsplit': lambda s: s.split(),
            'characterfrequency': lambda s: [s.lower().count(c) for c in 'abcdefghijklmnopqrstuvwxyz'],
        },
        'tokenmatcher': {
            'sift4tokenmatcher': lambda t1, t2: (
                1 - SIFT4().distance(t1, t2, 5) / max(len(t1), len(t2))
            ) > 0.7,
        },
        'matchingevaluator': {
            'sift4matchingevaluator': lambda t1, t2: (
                1 - SIFT4().distance(t1, t2, 5) / max(len(t1), len(t2))
            ),
        },
        'locallengthevaluator': {
            'rewardlengthevaluator': lambda l: l if l < 1 else l - 1 / (l + 1),
            'rewardlengthevaluator2': lambda l: l ** 1.5,
        },
        'transpositioncostevaluator': {
            'longertranspositionsaremorecostly': lambda c1, c2: abs(c2 - c1) / 9 + 1,
        },
    }

    def __init__(self, options: Optional[dict] = None):
        self._opts = dict(self._DEFAULTS)
        if isinstance(options, dict):
            for k, v in options.items():
                if k not in self._opts:
                    raise ValueError(f"Option {k} not recognized.")
                if k == 'maxdistance':
                    if not isinstance(v, int):
                        raise ValueError("Option maxdistance should be int")
                    self._opts[k] = v
                elif callable(v):
                    self._opts[k] = v
                elif v in self._PRESETS.get(k, {}):
                    self._opts[k] = self._PRESETS[k][v]
                else:
                    presets = ', '.join(self._PRESETS.get(k, {}).keys())
                    raise ValueError(f"Option {k} should be callable or one of [{presets}]")
        elif options is not None:
            raise ValueError("options should be a dictionary")

        self.maxdistance = self._opts['maxdistance']
        self.tokenizer = self._opts['tokenizer']
        self.tokenmatcher = self._opts['tokenmatcher']
        self.matchingevaluator = self._opts['matchingevaluator']
        self.locallengthevaluator = self._opts['locallengthevaluator']
        self.transpositioncostevaluator = self._opts['transpositioncostevaluator']
        self.transpositionsevaluator = self._opts['transpositionsevaluator']


class SIFT4:
    """SIFT4 字符串距离算法。

    参考: https://siderite.dev/blog/super-fast-and-accurate-string-distance.html

    示例:
        >>> sift = SIFT4()
        >>> sift.distance("hello", "hallo")
        1
        >>> # 使用 wordsplit 分词
        >>> sift2 = SIFT4()
        >>> sift2.distance("hello world", "hello there", maxoffset=5)
        5
    """

    def distance(self, s1: str, s2: str, maxoffset: int = 5, options: Optional[dict] = None) -> int:
        opts = SIFT4Options(options)
        t1, t2 = opts.tokenizer(s1), opts.tokenizer(s2)
        l1, l2 = len(t1), len(t2)
        if l1 == 0:
            return l2
        if l2 == 0:
            return l1

        c1 = c2 = lcss = local_cs = trans = 0
        offsets = []

        while c1 < l1 and c2 < l2:
            if opts.tokenmatcher(t1[c1], t2[c2]):
                local_cs += opts.matchingevaluator(t1[c1], t2[c2])
                is_trans = False
                i = 0
                while i < len(offsets):
                    ofs = offsets[i]
                    if c1 <= ofs['c1'] or c2 <= ofs['c2']:
                        is_trans = abs(c2 - c1) >= abs(ofs['c2'] - ofs['c1'])
                        if is_trans:
                            trans += opts.transpositioncostevaluator(c1, c2)
                        elif not ofs['trans']:
                            ofs['trans'] = True
                            trans += opts.transpositioncostevaluator(ofs['c1'], ofs['c2'])
                        break
                    elif c1 > ofs['c2'] and c2 > ofs['c1']:
                        offsets.pop(i)
                    else:
                        i += 1
                offsets.append({'c1': c1, 'c2': c2, 'trans': is_trans})
            else:
                lcss += opts.locallengthevaluator(local_cs)
                local_cs = 0
                if c1 != c2:
                    c1 = c2 = min(c1, c2)
                for i in range(maxoffset):
                    if c1 + i < l1 and opts.tokenmatcher(t1[c1 + i], t2[c2]):
                        c1 += i - 1
                        c2 -= 1
                        break
                    if c2 + i < l2 and opts.tokenmatcher(t1[c1], t2[c2 + i]):
                        c1 -= 1
                        c2 += i - 1
                        break
            c1 += 1
            c2 += 1
            if opts.maxdistance:
                temp_dist = opts.locallengthevaluator(max(c1, c2)) - opts.transpositionsevaluator(lcss, trans)
                if temp_dist >= opts.maxdistance:
                    return round(temp_dist)
            if c1 >= l1 or c2 >= l2:
                lcss += opts.locallengthevaluator(local_cs)
                local_cs = 0
                c1 = c2 = min(c1, c2)

        lcss += opts.locallengthevaluator(local_cs)
        return round(opts.locallengthevaluator(max(l1, l2)) - opts.transpositionsevaluator(lcss, trans))
