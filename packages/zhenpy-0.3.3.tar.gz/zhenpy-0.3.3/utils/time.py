import datetime


def _ms_to_datetime_obj(ms_timestamp):
    """将毫秒时间戳转为 datetime 对象。

    Args:
        ms_timestamp: 整数或浮点数，毫秒级时间戳。

    Returns:
        datetime.datetime: 转换后的 datetime 对象。

    Raises:
        ValueError: 时间戳无效时抛出。
        TypeError: 输入类型不支持时抛出。
    """
    sec_timestamp = float(ms_timestamp) / 1000
    return datetime.datetime.fromtimestamp(sec_timestamp)


def ms_to_date(ms_timestamp):
    """将毫秒时间戳转换为 yyyymmdd 格式的日期字符串。

    Args:
        ms_timestamp: 整数或浮点数，毫秒级时间戳。

    Returns:
        str: yyyymmdd 格式的日期字符串。

    Raises:
        ValueError: 时间戳无效时抛出。
        TypeError: 输入类型不支持时抛出。
    """
    return _ms_to_datetime_obj(ms_timestamp).strftime("%Y%m%d")


def ms_to_datetime(ms_timestamp):
    """将毫秒时间戳转换为 yyyymmdd hh:mm:ss 格式的日期时间字符串。

    Args:
        ms_timestamp: 整数或浮点数，毫秒级时间戳。

    Returns:
        str: yyyymmdd hh:mm:ss 格式的字符串。

    Raises:
        ValueError: 时间戳无效时抛出。
        TypeError: 输入类型不支持时抛出。
    """
def date_to_ms(date_str):
    """将 yyyymmdd 格式的日期字符串转为毫秒时间戳。

    Args:
        date_str: yyyymmdd 格式的日期字符串，如 "20260422"。

    Returns:
        int: 毫秒级时间戳，当日午夜零点起算。

    Raises:
        ValueError: 日期格式无效时抛出。
        TypeError: 输入类型不支持时抛出。
    """
    dt = datetime.datetime.strptime(str(date_str), "%Y%m%d")
    return int(dt.timestamp() * 1000)


def datetime_to_ms(datetime_str):
    """将 yyyymmdd hh:mm:ss 格式的日期时间字符串转为毫秒时间戳。

    Args:
        datetime_str: yyyymmdd hh:mm:ss 格式的字符串，如 "20260422 14:30:00"。

    Returns:
        int: 毫秒级时间戳。

    Raises:
        ValueError: 日期时间格式无效时抛出。
        TypeError: 输入类型不支持时抛出。
    """
    dt = datetime.datetime.strptime(str(datetime_str), "%Y%m%d %H:%M:%S")
    return int(dt.timestamp() * 1000)
