"""带路径压缩的加权快速并查集数据结构。

维护不相交集合（连通分量），支持高效的合并与连通性查询操作。

Example::

    >>> uf = UnionFind(["a", "b", "c", "d"])
    >>> uf.union("a", "b")
    >>> uf.union("c", "d")
    >>> uf.connected("a", "b")
    True
    >>> uf.connected("a", "c")
    False
    >>> uf.union("b", "c")
    >>> uf.connected("a", "c")
    True
    >>> uf.components()
    [{"a", "b", "c", "d"}]
"""

from __future__ import annotations

from typing import Dict, List, Optional, Set


class UnionFind:
    """带路径压缩的加权快速并查集。

    维护不相交集合，支持高效的 union 和 find 操作，
    摊还时间复杂度接近 O(1)。

    Attributes:
        num_elements: 追踪的元素总数。
        num_components: 当前不相交分量的数量。
    """

    def __init__(self, elements: Optional[List] = None):
        """初始化 UnionFind，可选初始元素列表。

        Args:
            elements: 可选的初始元素列表。
        """
        self.num_elements = 0
        self.num_components = 0
        self._next = 0
        self._elements: List = []
        self._indx: Dict = {}
        self._parent: List[int] = []
        self._size: List[int] = []

        if elements:
            for elem in elements:
                self.add(elem)

    def __repr__(self):
        """返回 UnionFind 结构的字符串表示。"""
        return (
            f"<UnionFind: elements={self._elements!r}, size={self._size!r}, "
            f"parent={self._parent!r}, num_elements={self.num_elements}, "
            f"num_components={self.num_components}>"
        )

    def __len__(self):
        """返回元素数量。"""
        return self.num_elements

    def __contains__(self, x):
        """返回 x 是否被该结构追踪。"""
        return x in self._indx

    def __getitem__(self, index: int):
        """返回指定索引处的元素。

        Args:
            index: 元素索引。

        Raises:
            IndexError: 如果索引越界。
        """
        if index < 0 or index >= self._next:
            raise IndexError(f"index {index} is out of bound")
        return self._elements[index]

    def __setitem__(self, index: int, x):
        """设置指定索引处的元素。

        Args:
            index: 要更新的索引。
            x: 新值。

        Raises:
            IndexError: 如果索引越界。
        """
        if index < 0 or index >= self._next:
            raise IndexError(f"index {index} is out of bound")
        self._elements[index] = x

    def add(self, elem) -> None:
        """添加单个不相连元素作为新分量。

        Args:
            elem: 要添加的元素。
        """
        if elem in self:
            return
        self._elements.append(elem)
        self._indx[elem] = self._next
        self._parent.append(self._next)
        self._size.append(1)
        self._next += 1
        self.num_elements += 1
        self.num_components += 1

    def find(self, elem) -> int:
        """查找 elem 所在分量的根节点。

        Args:
            elem: 要查找的元素。

        Returns:
            分量的根节点索引。

        Raises:
            ValueError: 如果 elem 不在结构中。
        """
        if elem not in self._indx:
            raise ValueError(f"{elem!r} is not an element")

        p = self._indx[elem]
        while p != self._parent[p]:
            q = self._parent[p]
            self._parent[p] = self._parent[q]
            p = q
        return p

    def connected(self, x, y) -> bool:
        """返回 x 和 y 是否属于同一个分量。

        Args:
            x: 第一个元素。
            y: 第二个元素。

        Returns:
            如果 x 和 y 共享同一个根节点则返回 True，否则返回 False。
        """
        return self.find(x) == self.find(y)

    def union(self, x, y) -> None:
        """将包含 x 和 y 的分量合并为一个。

        Args:
            x: 第一个元素。
            y: 第二个元素。

        Note:
            尚未加入结构的元素会自动添加。
        """
        for elt in (x, y):
            if elt not in self:
                self.add(elt)

        xroot = self.find(x)
        yroot = self.find(y)
        if xroot == yroot:
            return
        if self._size[xroot] < self._size[yroot]:
            self._parent[xroot] = yroot
            self._size[yroot] += self._size[xroot]
        else:
            self._parent[yroot] = xroot
            self._size[xroot] += self._size[yroot]
        self.num_components -= 1

    def _roots(self) -> List[int]:
        """返回所有唯一根节点索引列表。

        Returns:
            代表各分量代表的根节点索引列表。
        """
        return [i for i in range(self._next) if self._parent[i] == i]

    def component(self, x) -> Set:
        """返回包含 x 的连通分量。

        Args:
            x: 要查找的元素。

        Returns:
            与 x 在同一分量中的所有元素集合。

        Raises:
            ValueError: 如果 x 不在结构中。
        """
        if x not in self:
            raise ValueError(f"{x!r} is not an element")
        target = self.find(x)
        return {elt for elt in self._elements if self.find(elt) == target}

    def components(self) -> List[Set]:
        """返回所有连通分量的列表。

        Returns:
            集合列表，每个集合代表一个连通分量。
        """
        mapping: Dict[int, Set] = {}
        for elt in self._elements:
            root = self.find(elt)
            mapping.setdefault(root, set()).add(elt)
        return list(mapping.values())

    def component_mapping(self) -> Dict:
        """返回每个元素到其连通分量集合的映射。

        Returns:
            将每个元素映射到其分量中所有元素集合的字典。
            同一分量的元素共享同一个集合对象。

        Example::

            >>> uf = UnionFind(["a", "b", "c"])
            >>> uf.union("a", "b")
            >>> m = uf.component_mapping()
            >>> m["a"] is m["b"]  # 同一个集合对象
            True
        """
        mapping: Dict[int, Set] = {}
        result: Dict = {}
        for elt in self._elements:
            root = self.find(elt)
            component = mapping.setdefault(root, set())
            component.add(elt)
            result[elt] = component
        return result
