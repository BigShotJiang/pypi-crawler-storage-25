import numpy as np
import pandas as pd


def _ensure_single_column_frame(quote_datas):
    """将单列 Series 转为 DataFrame，保持输入一致性。

    Args:
        quote_datas: 行情数据，可以是 Series 或 DataFrame。

    Returns:
        pd.DataFrame: 单列 DataFrame。
    """
    if isinstance(quote_datas, pd.Series):
        return quote_datas.to_frame()
    return quote_datas


def _calc_forward_params(divid_datas):
    """计算前复权的仿射变换参数 (a, b)。

    前复权公式: adjusted = a * original + b

    Args:
        divid_datas: 分红数据 DataFrame，需包含 allotNum、stockBonus、
            stockGift、interest、allotPrice 列。

    Returns:
        tuple: (a, b) 两个 numpy 数组。
    """
    allot_num = divid_datas["allotNum"].to_numpy(dtype=float)
    stock_bonus = divid_datas["stockBonus"].to_numpy(dtype=float)
    stock_gift = divid_datas["stockGift"].to_numpy(dtype=float)
    interest = divid_datas["interest"].to_numpy(dtype=float)
    allot_price = divid_datas["allotPrice"].to_numpy(dtype=float)

    denom = 1.0 + allot_num + stock_bonus + stock_gift
    a = 1.0 / denom
    b = (-interest + allot_price * allot_num) / denom
    return a, b


def _calc_backward_params(divid_datas):
    """计算后复权的仿射变换参数 (a, b)。

    后复权公式: adjusted = a * original + b

    Args:
        divid_datas: 分红数据 DataFrame，字段同 _calc_forward_params。

    Returns:
        tuple: (a, b) 两个 numpy 数组。
    """
    allot_num = divid_datas["allotNum"].to_numpy(dtype=float)
    stock_bonus = divid_datas["stockBonus"].to_numpy(dtype=float)
    stock_gift = divid_datas["stockGift"].to_numpy(dtype=float)
    interest = divid_datas["interest"].to_numpy(dtype=float)
    allot_price = divid_datas["allotPrice"].to_numpy(dtype=float)

    a = 1.0 + stock_gift + stock_bonus + allot_num
    b = interest - allot_num * allot_price
    return a, b


def _build_forward_suffix_transform(divid_datas):
    """构建前复权的后缀仿射变换（从后往前累计）。

    前复权需要应用"严格晚于当前行情日"的所有分红事件，
    因此从最后一条分红记录向前合成仿射变换链。

    Args:
        divid_datas: 分红数据 DataFrame。

    Returns:
        tuple: (suffix_a, suffix_b) 长度为 n+1 的数组，
            suffix_a[i] 和 suffix_b[i] 表示从第 i 条分红事件到末尾的累计变换。
    """
    a, b = _calc_forward_params(divid_datas)
    n = len(divid_datas)
    suffix_a = np.ones(n + 1, dtype=float)
    suffix_b = np.zeros(n + 1, dtype=float)
    for i in range(n - 1, -1, -1):
        suffix_a[i] = a[i] * suffix_a[i + 1]
        suffix_b[i] = suffix_a[i + 1] * b[i] + suffix_b[i + 1]
    return suffix_a, suffix_b


def _build_backward_prefix_transform(divid_datas):
    """构建后复权的前缀仿射变换（从前往后累计）。

    后复权需要应用"早于或等于当前行情日"的所有分红事件，
    因此从第一条分红记录向后合成仿射变换链。

    Args:
        divid_datas: 分红数据 DataFrame。

    Returns:
        tuple: (prefix_a, prefix_b) 长度为 n 的数组，
            prefix_a[i] 和 prefix_b[i] 表示从开头到第 i 条分红事件的累计变换。
    """
    a, b = _calc_backward_params(divid_datas)
    n = len(divid_datas)
    prefix_a = np.ones(n, dtype=float)
    prefix_b = np.zeros(n, dtype=float)
    acc_a = 1.0
    acc_b = 0.0
    for i in range(n):
        prefix_a[i] = acc_a * a[i]
        prefix_b[i] = acc_a * b[i] + acc_b
        acc_a = prefix_a[i]
        acc_b = prefix_b[i]
    return prefix_a, prefix_b


def gen_divid_ratio_fast(quote_datas, divid_datas):
    """生成每日复权因子矩阵。

    Args:
        quote_datas: 行情数据 DataFrame，index 为日期，columns 为字段。
        divid_datas: 分红数据 DataFrame，index 为分红日，需包含 "dr" 列。

    Returns:
        pd.DataFrame: 复权因子矩阵，shape 与 quote_datas 相同。
            若分红数据为空，返回全 1 矩阵。
    """
    if quote_datas.empty:
        return quote_datas.copy()
    if divid_datas.empty:
        return pd.DataFrame(
            np.ones((len(quote_datas), len(quote_datas.columns)), dtype=float),
            index=quote_datas.index,
            columns=quote_datas.columns,
        )

    event_dates = divid_datas.index.to_numpy()
    quote_dates = quote_datas.index.to_numpy()
    cumulative_ratio = divid_datas["dr"].to_numpy(dtype=float).cumprod()

    # 与原始循环保持相同的日期边界行为：
    # 当行情日与分红日相同、以及分红日重复时，也按旧逻辑累计复权因子。
    left_idx = np.searchsorted(event_dates, quote_dates, side="left")
    has_same_day = np.zeros(len(quote_datas), dtype=bool)
    in_range = left_idx < len(event_dates)
    has_same_day[in_range] = event_dates[left_idx[in_range]] == quote_dates[in_range]
    applied_count = left_idx + has_same_day.astype(np.int64)

    ratio_by_quote = np.ones(len(quote_datas), dtype=float)
    valid = applied_count > 0
    ratio_by_quote[valid] = cumulative_ratio[applied_count[valid] - 1]
    ratio_values = np.repeat(
        ratio_by_quote[:, None],
        len(quote_datas.columns),
        axis=1,
    )
    return pd.DataFrame(ratio_values, index=quote_datas.index, columns=quote_datas.columns)


def process_forward_ratio_fast(quote_datas, divid_datas):
    """前复权：基于复权因子比例调整行情数据。

    Args:
        quote_datas: 行情数据 DataFrame。
        divid_datas: 分红数据 DataFrame。

    Returns:
        pd.DataFrame: 前复权后的行情数据，保留 3 位小数。
    """
    drl = gen_divid_ratio_fast(quote_datas, divid_datas)
    drlf = drl / drl.iloc[-1]
    return (quote_datas * drlf).round(3)


def process_backward_ratio_fast(quote_datas, divid_datas):
    """后复权：基于复权因子直接调整行情数据。

    Args:
        quote_datas: 行情数据 DataFrame。
        divid_datas: 分红数据 DataFrame。

    Returns:
        pd.DataFrame: 后复权后的行情数据，保留 3 位小数。
    """
    drl = gen_divid_ratio_fast(quote_datas, divid_datas)
    return (quote_datas * drl).round(3)


def process_forward_fast(quote_datas1, divid_datas):
    """前复权：使用后缀仿射变换批量计算。

    适用于单列行情数据，通过一次定位 + 批量套用后缀仿射变换完成前复权。

    Args:
        quote_datas1: 行情数据，可以是 Series 或单列 DataFrame。
        divid_datas: 分红数据 DataFrame。

    Returns:
        pd.DataFrame: 前复权后的行情数据，保留 3 位小数。
    """
    quote_datas = _ensure_single_column_frame(quote_datas1).copy()
    if quote_datas.empty or divid_datas.empty:
        return quote_datas

    suffix_a, suffix_b = _build_forward_suffix_transform(divid_datas)
    event_dates = divid_datas.index.to_numpy()
    quote_dates = quote_datas.index.to_numpy()
    start_idx = np.searchsorted(event_dates, quote_dates, side="right")

    values = quote_datas.iloc[:, 0].to_numpy(dtype=float)
    quote_datas.iloc[:, 0] = values * suffix_a[start_idx] + suffix_b[start_idx]
    return quote_datas.round(3)


def process_backward_fast(quote_datas1, divid_datas):
    """后复权：使用前缀仿射变换批量计算。

    适用于单列行情数据，通过一次定位 + 批量套用前缀仿射变换完成后复权。

    Args:
        quote_datas1: 行情数据，可以是 Series 或单列 DataFrame。
        divid_datas: 分红数据 DataFrame。

    Returns:
        pd.DataFrame: 后复权后的行情数据，保留 3 位小数。
    """
    quote_datas = _ensure_single_column_frame(quote_datas1).copy()
    if quote_datas.empty or divid_datas.empty:
        return quote_datas

    prefix_a, prefix_b = _build_backward_prefix_transform(divid_datas)
    event_dates = divid_datas.index.to_numpy()
    quote_dates = quote_datas.index.to_numpy()
    end_idx = np.searchsorted(event_dates, quote_dates, side="right") - 1

    values = quote_datas.iloc[:, 0].to_numpy(dtype=float)
    result = values.copy()
    valid = end_idx >= 0
    result[valid] = values[valid] * prefix_a[end_idx[valid]] + prefix_b[end_idx[valid]]
    quote_datas.iloc[:, 0] = result
    return quote_datas.round(3)
