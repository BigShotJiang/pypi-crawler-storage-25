from __future__ import annotations

from pathlib import Path

import pandas as pd


def save_dataframe_file(df: pd.DataFrame, output_file: str) -> None:
    """根据文件扩展名将 pandas DataFrame 保存到文件。

    支持的格式：csv、tsv、jsonl、json、xlsx。

    Args:
        df: 要保存的 pandas DataFrame。
        output_file: 输出文件路径，扩展名决定文件格式。

    Raises:
        ValueError: 如果文件扩展名不受支持。
    """
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    suffix = Path(output_file).suffix.lower()
    handlers = {
        ".csv": lambda: df.to_csv(output_file, index=False),
        ".tsv": lambda: df.to_csv(output_file, sep="\t", index=False),
        ".jsonl": lambda: df.to_json(output_file, orient="records", lines=True, force_ascii=False),
        ".json": lambda: df.to_json(output_file, orient="records", force_ascii=False),
        ".xlsx": lambda: df.to_excel(output_file, index=False),
    }

    handler = handlers.get(suffix)
    if handler is None:
        raise ValueError(
            f"不支持的文件扩展名 '{suffix}'（'{output_file}'）。"
            f"支持的扩展名：{', '.join(handlers.keys())}"
        )
    handler()
