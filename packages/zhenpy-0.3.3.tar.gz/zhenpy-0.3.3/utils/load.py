from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import pandas as pd


def load_file_dataframe(input_file: str, names: Optional[List[str]] = None) -> Optional[pd.DataFrame]:
    """根据文件扩展名将文件加载为 pandas DataFrame。

    支持的格式：csv、tsv、xlsx、jsonl、json。

    Args:
        input_file: 输入文件路径。
        names: CSV/TSV 文件的可选列名列表。

    Returns:
        如果文件格式受支持则返回 pandas DataFrame，否则返回 None。
    """
    suffix = Path(input_file).suffix.lower()
    loaders = {
        ".csv": lambda: pd.read_csv(input_file, names=names),
        ".tsv": lambda: pd.read_csv(input_file, sep="\t", names=names),
        ".xlsx": lambda: pd.read_excel(input_file),
        ".jsonl": lambda: pd.read_json(input_file, lines=True),
        ".json": lambda: pd.read_json(input_file),
    }
    loader = loaders.get(suffix)
    if loader:
        return loader()
    print(f"文件: {input_file}，不包含受支持的扩展名 [csv, tsv, jsonl, json, xlsx]")
    return None
