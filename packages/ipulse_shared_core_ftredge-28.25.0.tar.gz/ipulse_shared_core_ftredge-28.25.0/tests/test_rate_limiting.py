import asyncio
import json
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from ipulse_shared_core_ftredge.rate_limiting import (
    InMemorySlidingWindowRateLimiter,
    RateLimitPolicy,
    WindowLimit,
    enforce_authenticated_rate_limit,
    get_client_ip,
    merge_rate_limit_policies,
    parse_limits,
    parse_rate_limit_policies,
    rate_limit_request_by_ip,
    reset_rate_limiter_for_tests,
)


class FakeHeaders(dict):
    def get(self, key, default=None):
        return super().get(key.lower(), default)


class FakeRequest:
    def __init__(self, path="/api/v1/test", method="GET", headers=None, client_host="10.0.0.1", app_state=None):
        self.method = method
        self.headers = FakeHeaders({k.lower(): v for k, v in (headers or {}).items()})
        self.client = SimpleNamespace(host=client_host)
        self.url = SimpleNamespace(path=path)
        self.app = SimpleNamespace(
            state=app_state
            or SimpleNamespace(
                rate_limit_ip_policies=(),
                rate_limiter_service_name="test_service",
            )
        )


class TestInMemorySlidingWindowRateLimiter:
    def test_allows_until_window_limit_then_denies(self):
        limiter = InMemorySlidingWindowRateLimiter()
        limit = WindowLimit(request_count=2, window_seconds=60)

        first = asyncio.run(limiter.check(bucket_key="test:uid:user-1", limits=(limit,), now=1000.0))
        second = asyncio.run(limiter.check(bucket_key="test:uid:user-1", limits=(limit,), now=1001.0))
        third = asyncio.run(limiter.check(bucket_key="test:uid:user-1", limits=(limit,), now=1002.0))

        assert first is None
        assert second is None
        assert third is not None
        assert third.policy_name == "test"
        assert third.scope == "uid"
        assert third.identifier == "user-1"
        assert third.retry_after_seconds == 58

    def test_window_expires_and_allows_again(self):
        limiter = InMemorySlidingWindowRateLimiter()
        limit = WindowLimit(request_count=1, window_seconds=60)

        first = asyncio.run(limiter.check(bucket_key="test:ip:1.2.3.4", limits=(limit,), now=1000.0))
        second = asyncio.run(limiter.check(bucket_key="test:ip:1.2.3.4", limits=(limit,), now=1061.0))

        assert first is None
        assert second is None


def test_parse_limits_accepts_minute_hour_and_day_formats():
    parsed = parse_limits("100/minute, 1000/hour, 2000/day", ())
    assert parsed == (
        WindowLimit(request_count=100, window_seconds=60),
        WindowLimit(request_count=1000, window_seconds=3600),
        WindowLimit(request_count=2000, window_seconds=86400),
    )


def test_parse_limits_uses_default_for_blank_value():
    default = (WindowLimit(request_count=5, window_seconds=60),)
    assert parse_limits("", default) == default


def test_parse_limits_rejects_invalid_format():
    with pytest.raises(ValueError):
        parse_limits("100 per minute", ())


def test_get_client_ip_prefers_first_forwarded_for_value():
    request = FakeRequest(headers={"x-forwarded-for": "203.0.113.10, 10.0.0.2"})
    assert get_client_ip(request) == "203.0.113.10"


def test_rate_limit_policy_is_hashable_config_data():
    policy = RateLimitPolicy(
        name="example",
        scope="uid",
        limits=(WindowLimit(1, 60),),
        path_prefixes=("/api/v1",),
    )
    assert policy.name == "example"
    assert policy.scope == "uid"


def test_parse_rate_limit_policies_accepts_env_json():
    parsed = parse_rate_limit_policies(
        '[{"name":"extra","limits":"5/minute,50/hour,100/day","path_prefixes":["/api/v1/extra"],"methods":["GET"],"scope":"ip"}]',
        scope="ip",
    )

    assert parsed == (
        RateLimitPolicy(
            name="extra",
            scope="ip",
            limits=(WindowLimit(5, 60), WindowLimit(50, 3600), WindowLimit(100, 86400)),
            path_prefixes=("/api/v1/extra",),
            methods=("GET",),
        ),
    )


def test_merge_rate_limit_policies_overrides_same_name_and_appends_new_policy():
    base = RateLimitPolicy(
        name="default",
        scope="ip",
        limits=(WindowLimit(1, 60),),
        path_prefixes=("/api/v1/default",),
    )
    override = RateLimitPolicy(
        name="default",
        scope="ip",
        limits=(WindowLimit(2, 60),),
        path_prefixes=("/api/v1/default-v2",),
    )
    extra = RateLimitPolicy(
        name="extra",
        scope="ip",
        limits=(WindowLimit(3, 60),),
        path_prefixes=("/api/v1/extra",),
    )

    assert merge_rate_limit_policies((base,), (override, extra)) == (override, extra)


def test_ip_rate_limit_response_does_not_expose_retry_or_policy_cues():
    reset_rate_limiter_for_tests()
    policy = RateLimitPolicy(
        name="sensitive_policy_name",
        scope="ip",
        limits=(WindowLimit(1, 60),),
        path_prefixes=("/api/v1/limited",),
        methods=("GET",),
    )
    request = FakeRequest(
        path="/api/v1/limited",
        app_state=SimpleNamespace(
            rate_limit_ip_policies=(policy,),
            rate_limiter_service_name="historic_service",
        ),
    )

    first = asyncio.run(rate_limit_request_by_ip(request))
    second = asyncio.run(rate_limit_request_by_ip(request))

    assert first is None
    assert second is not None
    assert second.status_code == 429
    assert "retry-after" not in {key.lower() for key in second.headers.keys()}

    payload = json.loads(second.body.decode("utf-8"))
    serialized_payload = json.dumps(payload).lower()
    assert payload["message"] == (
        "You hit an IP limit for this network. There may be too many people sharing the same connection. "
        "Please try again in 1 minute. If possible, switch from Wi-Fi to mobile data."
    )
    assert payload["metadata"]["rate_limited_by_service"] == "historic_service"
    assert second.headers.get("x-rate-limited-by-service") == "historic_service"
    assert "sensitive_policy_name" not in serialized_payload
    assert "retry" not in serialized_payload
    assert "scope" not in serialized_payload


def test_uid_rate_limit_can_scope_by_subscription_plan_name():
    reset_rate_limiter_for_tests()
    free_policy = RateLimitPolicy(
        name="free_policy",
        scope="uid",
        limits=(WindowLimit(1, 60),),
        path_prefixes=("/api/v1/limited",),
        methods=("GET",),
        subscription_plan_names=("free_subscription",),
    )
    base_policy = RateLimitPolicy(
        name="base_policy",
        scope="uid",
        limits=(WindowLimit(2, 60),),
        path_prefixes=("/api/v1/limited",),
        methods=("GET",),
        subscription_plan_names=("base_subscription",),
    )

    request = FakeRequest(
        path="/api/v1/limited",
        app_state=SimpleNamespace(
            rate_limit_uid_policies=(free_policy, base_policy),
            rate_limiter_service_name="prediction_service",
        ),
    )

    # Base plan should use the base-scoped policy and allow 2 requests.
    asyncio.run(
        enforce_authenticated_rate_limit(
            request,
            user_uid="user_base",
            subscription_plan_name="base_subscription",
            scope_mode="scoped_only",
        )
    )
    asyncio.run(
        enforce_authenticated_rate_limit(
            request,
            user_uid="user_base",
            subscription_plan_name="base_subscription",
            scope_mode="scoped_only",
        )
    )

    # Free plan should be denied on the second request with the 1-minute message.
    asyncio.run(
        enforce_authenticated_rate_limit(
            request,
            user_uid="user_free",
            subscription_plan_name="free_subscription",
            scope_mode="scoped_only",
        )
    )
    with pytest.raises(HTTPException) as exc_info:
        asyncio.run(
            enforce_authenticated_rate_limit(
                request,
                user_uid="user_free",
                subscription_plan_name="free_subscription",
                scope_mode="scoped_only",
            )
        )

    assert exc_info.value.status_code == 429
    assert exc_info.value.detail == "You are going too fast try again in 1min"
