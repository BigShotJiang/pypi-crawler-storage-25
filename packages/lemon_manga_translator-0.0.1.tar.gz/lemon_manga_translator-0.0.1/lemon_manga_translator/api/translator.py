from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
from PIL import Image

from ..detection import ComicTextDetector
from ..inpainting.aot import AotInpainter
from ..pipeline import run_pipeline
from ..renderer import default_font_stack
from ..renderer.fonts import FontStack
from ..translation import VisionLlmClient
from .result import TranslationResult
from .sources import DEFAULT_HF_REPO, resolve_model_paths


class MangaTranslator:
    def __init__(
        self,
        openrouter_api_key: str,
        openrouter_model: str,
        *,
        model_source: str | Path = DEFAULT_HF_REPO,
        cache_dir: str | Path | None = None,
        hf_token: str | None = None,
        openrouter_base_url: str = "https://openrouter.ai/api/v1",
        vision_max_long_edge: int = 1024,
    ):
        self._openrouter_api_key = openrouter_api_key
        self._openrouter_model = openrouter_model
        self._model_source = model_source
        self._cache_dir = cache_dir
        self._hf_token = hf_token
        self._openrouter_base_url = openrouter_base_url
        self._vision_max_long_edge = vision_max_long_edge

        self._ctd: ComicTextDetector | None = None
        self._aot: AotInpainter | None = None
        self._client: VisionLlmClient | None = None
        self._stack: FontStack | None = None
        self._prepared = False

    def prepare(self) -> None:
        paths = resolve_model_paths(
            model_source=self._model_source,
            cache_dir=self._cache_dir,
            hf_token=self._hf_token,
        )

        self._ctd = ComicTextDetector.load(paths["ctd_onnx"], device="cpu")
        self._aot = AotInpainter.load(paths["aot_onnx"], paths["aot_config"], device="cpu")
        self._client = VisionLlmClient(
            api_key=self._openrouter_api_key,
            model=self._openrouter_model,
            base_url=self._openrouter_base_url,
            max_long_edge=self._vision_max_long_edge,
        )
        self._stack = default_font_stack()
        self._prepared = True

    def translate(self, image: Image.Image) -> TranslationResult:
        if not self._prepared:
            raise RuntimeError(
                "MangaTranslator.prepare()를 먼저 호출하세요."
            )

        rgb = image.convert("RGB")
        result = run_pipeline(
            image=rgb,
            ctd=self._ctd,
            aot=self._aot,
            client=self._client,
            stack=self._stack,
        )
        return TranslationResult(image=result.final)
