"""Webhook signature verification.

The platform sends three headers with each delivery:

    X-Webhook-Timestamp: 1714573200            (Unix seconds, as text)
    X-Webhook-Signature: v1=<hex hmac_sha256>  (over "{ts}.{body}")
    X-Webhook-Id: 42                            (stable per delivery)

`verify_webhook` performs the recommended check:

  1. Reject if `abs(now - ts) > tolerance` (default 300 s).
  2. Extract the ``v1=`` segment from the signature header.
  3. Recompute ``HMAC-SHA256(secret, f"{ts}.{body}")`` and constant-time compare.

The legacy ``X-Signature`` header (hex hmac over body only, no timestamp) is
still sent for older receivers — prefer ``v1``.
"""
from __future__ import annotations

import hashlib
import hmac
import time
from typing import Union


def verify_webhook(
    raw_body: Union[bytes, str],
    secret: str,
    signature_header: str,
    timestamp_header: str,
    *,
    tolerance_seconds: int = 300,
) -> bool:
    """Return True if the signature is valid and the timestamp is fresh."""
    try:
        ts = int(timestamp_header)
    except (TypeError, ValueError):
        return False
    if abs(int(time.time()) - ts) > tolerance_seconds:
        return False

    sig = None
    for part in (signature_header or "").split(","):
        part = part.strip()
        if part.startswith("v1="):
            sig = part[3:]
            break
    if not sig:
        return False

    body_bytes = raw_body.encode() if isinstance(raw_body, str) else raw_body
    signed = f"{ts}.".encode() + body_bytes
    expected = hmac.new(secret.encode(), signed, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, sig)
