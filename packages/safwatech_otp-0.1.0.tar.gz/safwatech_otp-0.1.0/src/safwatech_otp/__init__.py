"""Official Python SDK for the Safwatech OTP / verification platform.

>>> from safwatech_otp import OTPClient
>>> client = OTPClient(api_key="sk_test_…", base_url="https://otp.example.com")
>>> client.send_otp("+218911234567", channel="sms")

See https://github.com/safwatech/otp-python (or the project README) for the
full method list, sandbox semantics, and webhook signature verification helper.
"""

from .client import OTPClient, OTPClientError
from .webhooks import verify_webhook

__all__ = ["OTPClient", "OTPClientError", "verify_webhook", "__version__"]

__version__ = "0.1.0"  # x-release-please-version
