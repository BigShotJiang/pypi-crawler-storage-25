"""Python client for the Safwatech OTP / verification HTTP API.

Usage:
    from safwatech_otp import OTPClient

    client = OTPClient(api_key="sk_test_…", base_url="https://otp.example.com")
    resp = client.send_otp("+218911234567", channel="sms")
    client.verify_otp("+218911234567", resp["result"]["otp_code"])
"""
from __future__ import annotations

import time
from typing import Any, Optional

import requests


class OTPClientError(Exception):
    """Raised for any non-2xx response from the platform.

    Attributes:
        status: HTTP status code.
        payload: Decoded JSON body (or ``{"raw": "..."}`` if the body is
            not JSON).
        retry_after: The ``Retry-After`` response header on 429s, in
            seconds, when present and parseable.
    """

    def __init__(self, status: int, payload: Any, retry_after: Optional[int] = None):
        super().__init__(f"OTP API error {status}: {payload}")
        self.status = status
        self.payload = payload
        self.retry_after = retry_after


class OTPClient:
    def __init__(self, api_key: str, base_url: str, timeout: int = 15) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        if not base_url:
            raise ValueError("base_url is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._user_agent = f"safwatech-otp-python/0.1.0 requests/{requests.__version__}"

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": self._user_agent,
        }

    def _request(self, method: str, path: str, **kwargs: Any) -> dict:
        url = f"{self.base_url}{path}"
        response = requests.request(
            method, url, headers=self._headers(), timeout=self.timeout, **kwargs
        )
        try:
            payload = response.json()
        except ValueError:
            payload = {"raw": response.text}
        if not response.ok:
            retry_after: Optional[int] = None
            ra = response.headers.get("Retry-After")
            if ra is not None:
                try:
                    retry_after = int(ra)
                except ValueError:
                    retry_after = None
            raise OTPClientError(response.status_code, payload, retry_after)
        return payload

    def send_otp(
        self,
        phone: str,
        *,
        channel: str = "push",
        language: str = "en",
        reference_id: Optional[str] = None,
        otp_code: Optional[str] = None,
        message: Optional[str] = None,
        email: Optional[str] = None,
        expires_in: Optional[int] = None,
    ) -> dict:
        body = {
            "phone_number": phone,
            "delivery_channel": channel,
            "language": language,
        }
        if reference_id is not None:
            body["reference_id"] = reference_id
        if otp_code is not None:
            body["otp_code"] = otp_code
        if message is not None:
            body["message"] = message
        if email is not None:
            body["email"] = email
        if expires_in is not None:
            body["expires_in"] = expires_in
        return self._request("POST", "/api/v1/otp/send", json=body)

    def verify_otp(
        self,
        phone: str,
        code: str,
        *,
        reference_id: Optional[str] = None,
    ) -> dict:
        body = {"phone_number": phone, "otp_code": code}
        if reference_id is not None:
            body["reference_id"] = reference_id
        return self._request("POST", "/api/v1/otp/verify", json=body)

    def get_status(self, reference_id: str) -> dict:
        return self._request("GET", f"/api/v1/otp/status/{reference_id}")

    def schedule_otp(
        self,
        phone: str,
        scheduled_at_iso: str,
        *,
        channel: str = "push",
        language: str = "en",
        reference_id: Optional[str] = None,
    ) -> dict:
        body = {
            "phone_number": phone,
            "scheduled_at": scheduled_at_iso,
            "delivery_channel": channel,
            "language": language,
        }
        if reference_id is not None:
            body["reference_id"] = reference_id
        return self._request("POST", "/api/v1/otp/schedule", json=body)

    def cancel_scheduled(self, entry_id: int) -> dict:
        return self._request("DELETE", f"/api/v1/otp/schedule/{entry_id}")

    def list_scheduled(
        self,
        *,
        status: Optional[str] = None,
        page: int = 1,
        page_size: int = 25,
    ) -> dict:
        """List scheduled OTPs for this API key.

        Response: ``{status, result: {items, total, page, page_size}}``.
        """
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if status is not None:
            params["status"] = status
        return self._request("GET", "/api/v1/otp/schedule", params=params)

    def usage(self) -> dict:
        return self._request("GET", "/api/v1/usage")

    # --- TOTP (authenticator-as-alternative-to-SMS) ---

    def enroll_totp(self, phone: str) -> dict:
        """Enroll a user for TOTP. The returned `secret` is shown only once.

        Response: {status, result: {secret, provisioning_uri, account_id, ...}}
        """
        return self._request("POST", "/api/v1/totp/enroll", json={"phone_number": phone})

    def verify_totp(self, phone: str, code: str) -> dict:
        """Verify a TOTP code.

        Response: {status, result: {valid: bool, ...}}
        """
        return self._request(
            "POST",
            "/api/v1/totp/verify",
            json={"phone_number": phone, "code": code},
        )

    def totp_status(self, phone: str) -> dict:
        """Is this phone enrolled for my service?

        Response: {status, result: {enrolled: bool, ...}}
        """
        return self._request("GET", f"/api/v1/totp/status/{phone}")

    def unenroll_totp(self, phone: str) -> dict:
        """Force-remove a user's TOTP enrollment."""
        return self._request("DELETE", f"/api/v1/totp/enrollment/{phone}")

    # --- Magic links ---

    def send_magic_link(
        self,
        email: str,
        *,
        redirect_url: Optional[str] = None,
        context: Optional[dict] = None,
        ttl_seconds: Optional[int] = None,
    ) -> dict:
        """Email the user a one-click sign-in link.

        Response: {status, result: {request_id, expires_at, email_sent}}
        """
        body: dict[str, Any] = {"email": email}
        if redirect_url is not None:
            body["redirect_url"] = redirect_url
        if context is not None:
            body["context"] = context
        if ttl_seconds is not None:
            body["ttl_seconds"] = ttl_seconds
        return self._request("POST", "/api/v1/magic-link/send", json=body)

    def get_magic_link(self, request_id: str) -> dict:
        """Poll a magic-link request.

        Response: {status, result: {request_id, email, status, expires_at, consumed_at}}
        Terminal statuses: consumed, expired, cancelled.
        """
        return self._request("GET", f"/api/v1/magic-link/{request_id}")

    def cancel_magic_link(self, request_id: str) -> dict:
        """Cancel a pending magic link."""
        return self._request("DELETE", f"/api/v1/magic-link/{request_id}")

    def wait_for_magic_link(
        self,
        request_id: str,
        *,
        timeout: int = 900,
        poll_interval: float = 3.0,
    ) -> dict:
        """Poll `get_magic_link` until the request reaches a terminal state or timeout."""
        terminal = {"consumed", "expired", "cancelled"}
        deadline = time.monotonic() + timeout
        last = self.get_magic_link(request_id)
        while last.get("result", {}).get("status") not in terminal:
            if time.monotonic() >= deadline:
                return last
            time.sleep(poll_interval)
            last = self.get_magic_link(request_id)
        return last

    # --- WebAuthn / passkeys ---

    def webauthn_register(
        self,
        subject_value: str,
        *,
        subject_type: str = "email",
        redirect_url: Optional[str] = None,
    ) -> dict:
        """Start a passkey registration ceremony. Returns a URL the user must
        open in their browser to complete the FIDO2 ceremony.

        Response: {status, result: {request_id, ceremony_url, ceremony_type, expires_at}}
        """
        return self._request(
            "POST",
            "/api/v1/webauthn/register",
            json={"subject_type": subject_type, "subject_value": subject_value, "redirect_url": redirect_url},
        )

    def webauthn_authenticate(
        self,
        subject_value: str,
        *,
        subject_type: str = "email",
        redirect_url: Optional[str] = None,
    ) -> dict:
        """Start a passkey authentication ceremony."""
        return self._request(
            "POST",
            "/api/v1/webauthn/authenticate",
            json={"subject_type": subject_type, "subject_value": subject_value, "redirect_url": redirect_url},
        )

    def get_webauthn(self, request_id: str) -> dict:
        return self._request("GET", f"/api/v1/webauthn/{request_id}")

    def cancel_webauthn(self, request_id: str) -> dict:
        return self._request("DELETE", f"/api/v1/webauthn/{request_id}")

    def wait_for_webauthn(
        self,
        request_id: str,
        *,
        timeout: int = 300,
        poll_interval: float = 2.0,
    ) -> dict:
        """Poll `get_webauthn` until terminal (completed | failed | expired) or timeout."""
        terminal = {"completed", "failed", "expired"}
        deadline = time.monotonic() + timeout
        last = self.get_webauthn(request_id)
        while last.get("result", {}).get("status") not in terminal:
            if time.monotonic() >= deadline:
                return last
            time.sleep(poll_interval)
            last = self.get_webauthn(request_id)
        return last

    def generate_backup_codes(self, phone: str) -> dict:
        """Issue a fresh set of 10 single-use backup codes for a user.

        Replaces any prior codes. The plain codes are returned once — show
        them to the user and discard. Each accepted by `verify_totp` as a
        one-shot alternative to the rotating code.

        Response: {status, result: {codes: [..10..], count: 10, account_id}}
        """
        return self._request(
            "POST",
            "/api/v1/totp/backup-codes",
            json={"phone_number": phone},
        )

    # --- Silent / push-approval auth ---

    def request_auth(
        self,
        phone: str,
        *,
        context: Optional[dict] = None,
        allow_silent: bool = False,
    ) -> dict:
        """Start a silent or push-approval verification.

        Response: {status, result: {request_id, status, expires_at}}
        """
        body: dict[str, Any] = {"phone_number": phone, "allow_silent": allow_silent}
        if context is not None:
            body["context"] = context
        return self._request("POST", "/api/v1/auth/request", json=body)

    def get_auth_request(self, request_id: str) -> dict:
        """Poll an auth request.

        Response: {status, result: {request_id, status, resolution_method, resolved_at, ...}}
        """
        return self._request("GET", f"/api/v1/auth/request/{request_id}")

    def cancel_auth_request(self, request_id: str) -> dict:
        """Cancel a pending auth request."""
        return self._request("DELETE", f"/api/v1/auth/request/{request_id}")

    def wait_for_auth(
        self,
        request_id: str,
        *,
        timeout: int = 120,
        poll_interval: float = 2.0,
    ) -> dict:
        """Poll `get_auth_request` until the request reaches a terminal state
        (approved / denied / expired / cancelled) or `timeout` elapses.

        Returns the final poll response. If the timeout elapses before the
        request resolves, the last polled response is returned (status will
        still be "pending").
        """
        terminal = {"approved", "denied", "expired", "cancelled"}
        deadline = time.monotonic() + timeout
        last = self.get_auth_request(request_id)
        while last.get("result", {}).get("status") not in terminal:
            if time.monotonic() >= deadline:
                return last
            time.sleep(poll_interval)
            last = self.get_auth_request(request_id)
        return last
