# Changelog

All notable changes to `safwatech-otp` are documented here. This project
follows [Semantic Versioning](https://semver.org/).

## [0.1.0] — 2026-05-11

Initial public release.

- `OTPClient` — full coverage of `/api/v1/*`:
  - OTP: `send_otp`, `verify_otp`, `get_status`, `usage`
  - Scheduled OTP: `schedule_otp`, `cancel_scheduled`, `list_scheduled`
  - TOTP: `enroll_totp`, `verify_totp`, `totp_status`, `unenroll_totp`, `generate_backup_codes`
  - Magic links: `send_magic_link`, `get_magic_link`, `cancel_magic_link`, `wait_for_magic_link`
  - Silent push auth: `request_auth`, `get_auth_request`, `cancel_auth_request`, `wait_for_auth`
  - WebAuthn / passkeys: `webauthn_register`, `webauthn_authenticate`, `get_webauthn`,
    `cancel_webauthn`, `wait_for_webauthn`
- `OTPClientError` carries HTTP status and decoded payload.
- `verify_webhook(raw_body, secret, sig_header, ts_header, tolerance_seconds=300)`
  helper for the `X-Webhook-Signature: v1=…` HMAC-SHA256 scheme.
