"""Initialize examples module."""
