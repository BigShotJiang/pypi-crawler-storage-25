"""Initialize tests module."""
