#include "graph_model.h"
#include "core/gguf_loader.h"

#include <nlohmann/json.hpp>

#include <ggml-backend.h>
#include <ggml-cpu.h>
#include <ggml.h>

#include <algorithm>
#include <cmath>
#include <cstring>
#include <sstream>
#include <stdexcept>
#include <tuple>
#include <vector>

using json = nlohmann::json;

namespace mlipcpp::runtime {

namespace {

// Bump cutoff function
float cutoff_func_bump(float distance, float cutoff, float width) {
  float x = (distance - (cutoff - width)) / width;
  if (x <= 0.0f) return 1.0f;
  if (x >= 1.0f) return 0.0f;
  float tan_val = std::tan(static_cast<float>(M_PI) * x);
  return 0.5f * (1.0f + std::tanh(1.0f / tan_val));
}

// Cosine cutoff function
float cutoff_func_cosine(float distance, float cutoff, float width) {
  float x = (distance - (cutoff - width)) / width;
  if (x <= 0.0f) return 1.0f;
  if (x >= 1.0f) return 0.0f;
  return 0.5f * (1.0f + std::cos(static_cast<float>(M_PI) * x));
}

// Internal state from compute_adaptive_cutoffs that the chain-rule stress
// correction reuses (avoids re-deriving it for every edge perturbation).
struct AdaptiveCutoffCache {
  std::vector<float> probes;            // [n_probes]
  std::vector<double> diff;             // [n_atoms * n_probes]
  std::vector<double> width;            // [n_atoms * n_probes]
  std::vector<double> weights;          // [n_atoms * n_probes]   softmax over probes
  std::vector<float> atomic_cutoffs;    // [n_atoms]
  // X[k * n_probes + p] = ∂atomic_cutoffs[k] / ∂diff[k, p].
  // Populated by compute_adaptive_cutoffs_with_jacobian.
  std::vector<double> diff_jacobian;
  float effective_width = 0.0f;
  int n_probes = 0;
};

// Compute per-atom adaptive cutoffs. Mirrors metatrain.pet.modules
// .adaptive_cutoff.get_adaptive_cutoffs: probe-grid + Gaussian weighting,
// width per probe taken from the numerical gradient of (effective_nn -
// target + baseline) along the probe axis.
//
// Inputs:
//   centers, distances : edge index/value arrays of length n_edges
//   target             : num_neighbors_adaptive (e.g. 8.0)
//   n_atoms, max_cutoff: as passed by the caller
// Returns: vector of length n_atoms with per-atom adapted cutoff radii.
std::vector<float> compute_adaptive_cutoffs(
    const std::vector<int32_t> &centers,
    const std::vector<float> &distances,
    float target,
    int n_atoms,
    float max_cutoff,
    float min_cutoff = 0.5f,
    float effective_width = 1.0f) {
  const float probe_spacing = effective_width / 4.0f;
  std::vector<float> probe_cutoffs;
  for (float pc = min_cutoff; pc < max_cutoff; pc += probe_spacing) {
    probe_cutoffs.push_back(pc);
  }
  const int n_probes = static_cast<int>(probe_cutoffs.size());
  if (n_probes == 0 || n_atoms == 0) {
    return std::vector<float>(n_atoms, max_cutoff);
  }

  // diff[atom * n_probes + p] starts as effective_num_neighbors at probe p,
  // then we subtract `target` and add the baseline = target * (p/(n-1))^3.
  std::vector<double> diff(static_cast<size_t>(n_atoms) * n_probes, 0.0);

  // Accumulate effective neighbor count: f(d, probe, effective_width).
  const size_t n_edges = distances.size();
  for (int p = 0; p < n_probes; p++) {
    const float pc = probe_cutoffs[p];
    for (size_t e = 0; e < n_edges; e++) {
      const int a = centers[e];
      const float w = cutoff_func_bump(distances[e], pc, effective_width);
      diff[static_cast<size_t>(a) * n_probes + p] += static_cast<double>(w);
    }
  }

  // Subtract target, add baseline.
  for (int a = 0; a < n_atoms; a++) {
    for (int p = 0; p < n_probes; p++) {
      double x = (n_probes > 1)
                     ? static_cast<double>(p) / static_cast<double>(n_probes - 1)
                     : 0.0;
      double baseline = target * x * x * x;
      diff[static_cast<size_t>(a) * n_probes + p] += baseline - target;
    }
  }

  // Numerical gradient along probe axis (matches torch.gradient with default
  // edge_order=1: central differences interior, one-sided at boundaries).
  std::vector<double> grad(diff.size(), 0.0);
  for (int a = 0; a < n_atoms; a++) {
    const double *d = &diff[static_cast<size_t>(a) * n_probes];
    double *g = &grad[static_cast<size_t>(a) * n_probes];
    if (n_probes == 1) {
      g[0] = std::abs(d[0]) * 0.5;
    } else {
      g[0] = d[1] - d[0];
      g[n_probes - 1] = d[n_probes - 1] - d[n_probes - 2];
      for (int p = 1; p < n_probes - 1; p++) {
        g[p] = 0.5 * (d[p + 1] - d[p - 1]);
      }
    }
  }
  // width = max(|grad|, eps)
  const double eps = 1e-12;
  for (size_t i = 0; i < grad.size(); i++) {
    grad[i] = std::max(std::abs(grad[i]), eps);
  }

  // Gaussian weights: log = -0.5 * (diff/width)^2 ; subtract max per row;
  // exponentiate; normalize.
  std::vector<float> result(n_atoms, 0.0f);
  for (int a = 0; a < n_atoms; a++) {
    const double *d = &diff[static_cast<size_t>(a) * n_probes];
    const double *w = &grad[static_cast<size_t>(a) * n_probes];

    // First pass: compute logw and find max
    std::vector<double> logw(n_probes);
    double logw_max = -std::numeric_limits<double>::infinity();
    for (int p = 0; p < n_probes; p++) {
      double r = d[p] / w[p];
      logw[p] = -0.5 * r * r;
      if (logw[p] > logw_max) logw_max = logw[p];
    }
    // Second pass: exp(logw - max) and accumulate
    double sum_w = 0.0;
    double weighted_cutoff = 0.0;
    for (int p = 0; p < n_probes; p++) {
      double weight = std::exp(logw[p] - logw_max);
      sum_w += weight;
      weighted_cutoff += weight * probe_cutoffs[p];
    }
    result[a] = (sum_w > 0.0)
                    ? static_cast<float>(weighted_cutoff / sum_w)
                    : max_cutoff;
  }
  return result;
}

// Bump function value AND derivative w.r.t. distance.
//   f(d, rc, w) = 0.5 * (1 + tanh(1/tan(pi*x))), x = (d-(rc-w))/w
//   f'(d) = 0.5 * sech^2(...) * d/dx[1/tan(pi*x)] / w
//         = 0.5 * sech^2 * (-pi/sin^2(pi*x)) / w
// Returns 0 outside the active region (since the bump is 0 or 1 there).
double bump_derivative(float distance, float cutoff, float width) {
  double x = (static_cast<double>(distance) -
              (static_cast<double>(cutoff) - static_cast<double>(width))) /
             static_cast<double>(width);
  if (x <= 0.0 || x >= 1.0) return 0.0;
  double pi_x = M_PI * x;
  double s = std::sin(pi_x);
  double c = std::cos(pi_x);
  double t = c / s;                  // 1/tan(pi*x)
  double sech2 = 1.0 - std::tanh(t) * std::tanh(t);
  // dt/dx = -pi/sin^2(pi*x) ; dx/d(distance) = 1/width
  double dt_dx = -M_PI / (s * s);
  return 0.5 * sech2 * dt_dx / static_cast<double>(width);
}

// Same as compute_adaptive_cutoffs but stashes the intermediate state
// (eff_nn, diff, width, softmax weights, the diff-Jacobian X) needed by the
// stress chain-rule correction.
void compute_adaptive_cutoffs_with_state(
    const std::vector<int32_t> &centers,
    const std::vector<float> &distances,
    float target,
    int n_atoms,
    float max_cutoff,
    AdaptiveCutoffCache &out,
    float min_cutoff = 0.5f,
    float effective_width = 1.0f) {
  out = {};
  const float probe_spacing = effective_width / 4.0f;
  for (float pc = min_cutoff; pc < max_cutoff; pc += probe_spacing) {
    out.probes.push_back(pc);
  }
  const int n_probes = static_cast<int>(out.probes.size());
  out.n_probes = n_probes;
  out.effective_width = effective_width;
  out.atomic_cutoffs.assign(n_atoms, max_cutoff);
  if (n_probes == 0 || n_atoms == 0) return;

  // diff[a*n_probes + p] starts as effective_num_neighbors, then we subtract
  // target and add baseline (kept as in compute_adaptive_cutoffs).
  out.diff.assign(static_cast<size_t>(n_atoms) * n_probes, 0.0);
  const size_t n_edges = distances.size();
  for (int p = 0; p < n_probes; p++) {
    const float pc = out.probes[p];
    for (size_t e = 0; e < n_edges; e++) {
      const int a = centers[e];
      out.diff[static_cast<size_t>(a) * n_probes + p] +=
          static_cast<double>(cutoff_func_bump(distances[e], pc, effective_width));
    }
  }
  for (int a = 0; a < n_atoms; a++) {
    for (int p = 0; p < n_probes; p++) {
      double x = (n_probes > 1)
                     ? static_cast<double>(p) / static_cast<double>(n_probes - 1)
                     : 0.0;
      out.diff[static_cast<size_t>(a) * n_probes + p] +=
          static_cast<double>(target) * x * x * x -
          static_cast<double>(target);
    }
  }

  // grad along probe axis (centred for interior, one-sided at ends), then
  // width = max(|grad|, eps). We also remember sign(grad) per row so the
  // Jacobian can use it without a redundant sign step.
  out.width.assign(out.diff.size(), 0.0);
  std::vector<double> grad(out.diff.size(), 0.0);
  std::vector<double> grad_sign(out.diff.size(), 0.0);
  const double eps = 1e-12;
  for (int a = 0; a < n_atoms; a++) {
    const double *d = &out.diff[static_cast<size_t>(a) * n_probes];
    double *g = &grad[static_cast<size_t>(a) * n_probes];
    if (n_probes == 1) {
      g[0] = std::abs(d[0]) * 0.5;
    } else {
      g[0] = d[1] - d[0];
      g[n_probes - 1] = d[n_probes - 1] - d[n_probes - 2];
      for (int p = 1; p < n_probes - 1; p++) {
        g[p] = 0.5 * (d[p + 1] - d[p - 1]);
      }
    }
    for (int p = 0; p < n_probes; p++) {
      double abs_g = std::abs(g[p]);
      out.width[static_cast<size_t>(a) * n_probes + p] = std::max(abs_g, eps);
      grad_sign[static_cast<size_t>(a) * n_probes + p] = (g[p] >= 0.0) ? 1.0 : -1.0;
    }
  }

  // Softmax weights and atomic_cutoffs.
  out.weights.assign(out.diff.size(), 0.0);
  for (int a = 0; a < n_atoms; a++) {
    const double *d = &out.diff[static_cast<size_t>(a) * n_probes];
    const double *w = &out.width[static_cast<size_t>(a) * n_probes];
    double *we = &out.weights[static_cast<size_t>(a) * n_probes];

    std::vector<double> logw(n_probes);
    double logw_max = -std::numeric_limits<double>::infinity();
    for (int p = 0; p < n_probes; p++) {
      double r = d[p] / w[p];
      logw[p] = -0.5 * r * r;
      if (logw[p] > logw_max) logw_max = logw[p];
    }
    double sum_w = 0.0;
    double weighted_cutoff = 0.0;
    for (int p = 0; p < n_probes; p++) {
      we[p] = std::exp(logw[p] - logw_max);
      sum_w += we[p];
      weighted_cutoff += we[p] * out.probes[p];
    }
    if (sum_w > 0.0) {
      for (int p = 0; p < n_probes; p++) we[p] /= sum_w;
      out.atomic_cutoffs[a] = static_cast<float>(weighted_cutoff / sum_w);
    } else {
      // Degenerate: keep uniform so downstream divisions are safe.
      double uniform = 1.0 / std::max(1, n_probes);
      for (int p = 0; p < n_probes; p++) we[p] = uniform;
    }
  }

  // Diff-Jacobian X[a, p_target] = d(atomic_cutoffs[a])/d(diff[a, p_target]).
  // Only logits[a, r] depends on diff[a, *]; chain through w via
  //   d(a)/d(logits_r) = w_r * (probes_r - atomic_cutoffs[a]).
  // logits_r = -0.5 * (diff_r / width_r)^2; width_r is a numerical gradient
  // of diff and so depends on diff_{r-1}, diff_{r+1} (or endpoints).
  out.diff_jacobian.assign(out.diff.size(), 0.0);
  for (int a = 0; a < n_atoms; a++) {
    const double *d = &out.diff[static_cast<size_t>(a) * n_probes];
    const double *w_arr = &out.width[static_cast<size_t>(a) * n_probes];
    const double *we = &out.weights[static_cast<size_t>(a) * n_probes];
    const double *gs = &grad_sign[static_cast<size_t>(a) * n_probes];
    const double a_val = static_cast<double>(out.atomic_cutoffs[a]);
    double *X = &out.diff_jacobian[static_cast<size_t>(a) * n_probes];

    for (int r = 0; r < n_probes; r++) {
      double coef = we[r] * (static_cast<double>(out.probes[r]) - a_val);
      double w_r = w_arr[r];
      if (w_r <= eps) continue;
      double inv_w2 = 1.0 / (w_r * w_r);
      double d_over_w3 = (d[r] * d[r]) / (w_r * w_r * w_r);

      // direct contribution: d(logits_r)/d(diff_r) = -d_r / w_r^2
      X[r] += coef * (-d[r] * inv_w2);

      // width contribution: d(logits_r)/d(diff_target) =
      //     (d_r^2 / w_r^3) * d(width_r)/d(diff_target)
      // d(width_r)/d(diff_target) = sign(grad_r) * d(grad_r)/d(diff_target).
      double sgn = gs[r];
      if (n_probes == 1) {
        // only r=0 case, with d(grad_0)/d(diff_0) ~ 0.5*sign already baked in
        // Skip — degenerate.
      } else if (r == 0) {
        // grad_0 = diff_1 - diff_0
        double t = coef * d_over_w3;
        X[0] += t * sgn * (-1.0);
        X[1] += t * sgn * (+1.0);
      } else if (r == n_probes - 1) {
        // grad_{n-1} = diff_{n-1} - diff_{n-2}
        double t = coef * d_over_w3;
        X[n_probes - 1] += t * sgn * (+1.0);
        X[n_probes - 2] += t * sgn * (-1.0);
      } else {
        // grad_r = 0.5 * (diff_{r+1} - diff_{r-1})
        double t = coef * d_over_w3;
        X[r - 1] += t * sgn * (-0.5);
        X[r + 1] += t * sgn * (+0.5);
      }
    }
  }
}

} // namespace

// Context sizes
static constexpr size_t INPUT_CTX_SIZE = 16 * 1024 * 1024;   // 16 MB
static constexpr size_t COMPUTE_CTX_SIZE = 512 * 1024 * 1024; // 512 MB

GraphModel::GraphModel()
    : neighbor_builder_(NeighborListOptions{cutoff_, true, false}) {}

GraphModel::~GraphModel() {
  if (weight_buffer_) {
    ggml_backend_buffer_free(weight_buffer_);
  }
  if (ctx_weights_) {
    ggml_free(ctx_weights_);
  }
  // compute_backend_ is owned by backend_provider_; do not free here.
}

bool GraphModel::load_from_gguf(const std::string &path) {
  constexpr size_t TEMP_CTX_SIZE = 512 * 1024 * 1024;

  // Create temporary context with data allocation
  ggml_context *temp_ctx = ggml_init({TEMP_CTX_SIZE, nullptr, false});
  if (!temp_ctx) {
    throw std::runtime_error("Failed to create temporary context for loading");
  }

  GGUFLoader loader(path, temp_ctx);
  int n_tensors = static_cast<int>(loader.get_tensor_names().size());

  // Read model hyperparameters
  cutoff_ = loader.get_float32("pet.cutoff", 4.5f);
  cutoff_width_ = loader.get_float32("pet.cutoff_width", 0.2f);
  energy_scale_ = loader.get_float32("pet.energy_scale", 1.0f);
  cutoff_function_ = loader.get_string("pet.cutoff_function", "cosine");
  forces_mode_ = (loader.get_int32("pet.forces_mode", 0) != 0);
  num_neighbors_adaptive_ = loader.get_float32("pet.num_neighbors_adaptive", 0.0f);

  // Update neighbor list builder with loaded cutoff
  neighbor_builder_ = NeighborListBuilder(NeighborListOptions{cutoff_, true, false});

  // Load graph JSON
  std::string graph_json = loader.get_string("graph.json", "");
  if (graph_json.empty()) {
    ggml_free(temp_ctx);
    throw std::runtime_error("No graph.json found in GGUF file");
  }
  interp_.load_graph(graph_json);

  // Load species mapping
  auto species_map = loader.get_array_int32("pet.species_map");
  for (size_t i = 0; i + 1 < species_map.size(); i += 2) {
    species_to_index_[species_map[i]] = species_map[i + 1];
  }

  // Load composition energies
  auto comp_keys = loader.get_array_int32("pet.composition_keys");
  auto comp_vals = loader.get_array_float32("pet.composition_values");
  if (comp_keys.size() != comp_vals.size()) {
    ggml_free(temp_ctx);
    throw std::runtime_error(
        "GraphModel: composition_keys and composition_values mismatch");
  }
  for (size_t i = 0; i < comp_keys.size(); i++) {
    composition_energies_[comp_keys[i]] = comp_vals[i];
  }

  // Create backend
  backend_provider_ = BackendProvider::create(backend_preference_);

  // Load weight shapes from metadata (PyTorch shapes, need reversal for GGML)
  std::string shapes_json = loader.get_string("graph.weight_shapes", "");
  json weight_shapes;
  if (!shapes_json.empty()) {
    weight_shapes = json::parse(shapes_json);
  }

  // Create weight context (metadata only, no data allocation)
  size_t ctx_size = ggml_tensor_overhead() * static_cast<size_t>(n_tensors);
  ctx_weights_ = ggml_init({ctx_size, nullptr, true});
  if (!ctx_weights_) {
    ggml_free(temp_ctx);
    throw std::runtime_error("Failed to create weight context");
  }

  // Create weight tensors with correct GGML shapes (reversed PyTorch dims)
  for (const auto &name : loader.get_tensor_names()) {
    ggml_tensor *temp = loader.get_tensor(name);
    if (!temp) continue;

    ggml_tensor *t = nullptr;
    if (weight_shapes.contains(name)) {
      // Use PyTorch shape from metadata, reversed for GGML convention
      auto py_shape = weight_shapes[name].get<std::vector<int64_t>>();
      std::vector<int64_t> ggml_shape(py_shape.rbegin(), py_shape.rend());
      switch (ggml_shape.size()) {
      case 0:
        t = ggml_new_tensor_1d(ctx_weights_, GGML_TYPE_F32, 1);
        break;
      case 1:
        t = ggml_new_tensor_1d(ctx_weights_, GGML_TYPE_F32, ggml_shape[0]);
        break;
      case 2:
        t = ggml_new_tensor_2d(ctx_weights_, GGML_TYPE_F32, ggml_shape[0],
                               ggml_shape[1]);
        break;
      case 3:
        t = ggml_new_tensor_3d(ctx_weights_, GGML_TYPE_F32, ggml_shape[0],
                               ggml_shape[1], ggml_shape[2]);
        break;
      default:
        continue;
      }
    } else {
      // Fallback: use GGUF stored shape directly
      t = ggml_new_tensor(
          ctx_weights_, temp->type, ggml_n_dims(temp), temp->ne);
    }

    ggml_set_name(t, name.c_str());
  }

  // Allocate backend buffer for weights
  ggml_backend_buffer_type_t buft = backend_provider_->buffer_type();
  weight_buffer_ = ggml_backend_alloc_ctx_tensors_from_buft(ctx_weights_, buft);
  if (!weight_buffer_) {
    ggml_free(temp_ctx);
    throw std::runtime_error("Failed to allocate weight buffer");
  }
  ggml_backend_buffer_set_usage(weight_buffer_, GGML_BACKEND_BUFFER_USAGE_WEIGHTS);

  // Copy weight data and register with interpreter
  for (const auto &name : loader.get_tensor_names()) {
    ggml_tensor *temp = loader.get_tensor(name);
    ggml_tensor *weight = ggml_get_tensor(ctx_weights_, name.c_str());
    if (temp && weight) {
      ggml_backend_tensor_set(weight, temp->data, 0, ggml_nbytes(weight));
      interp_.set_weight(name, weight);
    }
  }

  ggml_free(temp_ctx);

  // Use primary backend (may be GPU) for compute; owned by BackendProvider.
  compute_backend_ = backend_provider_->primary();
  if (!compute_backend_) {
    throw std::runtime_error("Failed to get compute backend");
  }

  return true;
}

void GraphModel::load_graph_file(const std::string &path) {
  interp_.load_graph_file(path);
}

void GraphModel::set_weight(const std::string &name, ggml_tensor *tensor) {
  interp_.set_weight(name, tensor);
}

ModelResult GraphModel::predict(const AtomicSystem &system) {
  return predict_single(system, false);
}

ModelResult GraphModel::predict(const AtomicSystem &system,
                                bool compute_forces) {
  return predict_single(system, compute_forces);
}

ModelResult GraphModel::predict_single(const AtomicSystem &system,
                                       bool compute_forces) {
  if (compute_forces && !forces_mode_) {
    throw std::runtime_error(
        "GraphModel: forces requested but model was exported with "
        "--no-forces. Re-export without --no-forces to enable forces.");
  }

  const int n_atoms = static_cast<int>(system.num_atoms());
  const int32_t *atomic_numbers = system.atomic_numbers();

  // Build neighbor list at the global model cutoff (the search radius).
  NeighborList nlist = neighbor_builder_.build(system);

  // Per-pair cutoffs: default to global cutoff. When the graph itself does
  // adaptive cutoff (adaptive_cutoff_in_graph_), C++ leaves pair_cutoffs at
  // the global cutoff and skips filtering — the graph computes per-pair
  // cutoffs from edge_distances and applies them via cutoff_factors.
  // Otherwise, when num_neighbors_adaptive_ > 0, C++ does the legacy
  // filtering and passes per-pair cutoffs as a constant input.
  std::vector<float> pair_cutoffs(nlist.num_pairs(), cutoff_);

  // Pre-filter (full) neighbor list and adaptive-cutoff state are kept here
  // so the stress chain-rule correction can use them after the backward pass
  // (the model only sees the post-filter list, but atomic_cutoffs is computed
  // on the full list).
  NeighborList full_nlist;
  AdaptiveCutoffCache adapt_cache;
  bool have_adaptive = false;

  if (num_neighbors_adaptive_ > 0.0f) {
    full_nlist = nlist;  // copy of pre-filter list
    compute_adaptive_cutoffs_with_state(
        nlist.centers, nlist.distances,
        num_neighbors_adaptive_, n_atoms, cutoff_, adapt_cache,
        /*min_cutoff=*/0.5f,
        /*effective_width=*/cutoff_width_);
    have_adaptive = true;
    const auto &atomic_cutoffs = adapt_cache.atomic_cutoffs;

    // Compact nlist in place: keep edge e iff distances[e] <= pair_cutoff
    const int n_in = nlist.num_pairs();
    std::vector<float> kept_pair_cutoffs;
    kept_pair_cutoffs.reserve(n_in);
    int n_out = 0;
    for (int e = 0; e < n_in; e++) {
      const int i = nlist.centers[e];
      const int j = nlist.neighbors[e];
      const float pc = 0.5f * (atomic_cutoffs[i] + atomic_cutoffs[j]);
      if (nlist.distances[e] > pc) continue;
      if (n_out != e) {
        nlist.centers[n_out] = nlist.centers[e];
        nlist.neighbors[n_out] = nlist.neighbors[e];
        nlist.edge_vectors[n_out] = nlist.edge_vectors[e];
        nlist.distances[n_out] = nlist.distances[e];
        if (!nlist.cell_shifts.empty()) {
          nlist.cell_shifts[n_out] = nlist.cell_shifts[e];
        }
      }
      kept_pair_cutoffs.push_back(pc);
      ++n_out;
    }
    nlist.centers.resize(n_out);
    nlist.neighbors.resize(n_out);
    nlist.edge_vectors.resize(n_out);
    nlist.distances.resize(n_out);
    if (!nlist.cell_shifts.empty()) nlist.cell_shifts.resize(n_out);
    pair_cutoffs = std::move(kept_pair_cutoffs);
  }

  // Count max neighbors after any adaptive filtering
  std::vector<int> neighbor_counts(n_atoms, 0);
  for (int e = 0; e < nlist.num_pairs(); e++) {
    neighbor_counts[nlist.centers[e]]++;
  }
  int max_neighbors = 0;
  for (int i = 0; i < n_atoms; i++) {
    max_neighbors = std::max(max_neighbors, neighbor_counts[i]);
  }
  if (max_neighbors == 0) {
    max_neighbors = 1;
  }

  // Set symbolic dimensions for this system
  interp_.set_dimension("n_atoms", n_atoms);
  interp_.set_dimension("max_neighbors", max_neighbors);
  interp_.set_dimension("n_edges", n_atoms * max_neighbors);
  interp_.set_dimension("max_neighbors_plus_one", max_neighbors + 1);

  const int total_slots = n_atoms * max_neighbors;

  // --- Create input context ---
  ggml_context *input_ctx = ggml_init({INPUT_CTX_SIZE, nullptr, true});
  if (!input_ctx) {
    throw std::runtime_error("Failed to create input context");
  }

  // Create input tensors
  ggml_tensor *species_t = ggml_new_tensor_1d(input_ctx, GGML_TYPE_I32, n_atoms);
  ggml_set_name(species_t, "species");

  ggml_tensor *neighbor_species_t =
      ggml_new_tensor_2d(input_ctx, GGML_TYPE_I32, max_neighbors, n_atoms);
  ggml_set_name(neighbor_species_t, "neighbor_species");

  ggml_tensor *edge_vectors_t =
      ggml_new_tensor_3d(input_ctx, GGML_TYPE_F32, 3, max_neighbors, n_atoms);
  ggml_set_name(edge_vectors_t, "edge_vectors");

  ggml_tensor *padding_mask_t =
      ggml_new_tensor_2d(input_ctx, GGML_TYPE_F32, max_neighbors, n_atoms);
  ggml_set_name(padding_mask_t, "padding_mask");

  ggml_tensor *reverse_neighbor_index_t =
      ggml_new_tensor_1d(input_ctx, GGML_TYPE_I32, total_slots);
  ggml_set_name(reverse_neighbor_index_t, "reverse_neighbor_index");

  // Mode-specific inputs
  ggml_tensor *edge_distances_t = nullptr;
  ggml_tensor *cutoff_factors_t = nullptr;
  ggml_tensor *cutoff_values_t = nullptr;

  if (!forces_mode_) {
    edge_distances_t =
        ggml_new_tensor_2d(input_ctx, GGML_TYPE_F32, max_neighbors, n_atoms);
    ggml_set_name(edge_distances_t, "edge_distances");

    cutoff_factors_t =
        ggml_new_tensor_2d(input_ctx, GGML_TYPE_F32, max_neighbors, n_atoms);
    ggml_set_name(cutoff_factors_t, "cutoff_factors");
  } else {
    cutoff_values_t =
        ggml_new_tensor_2d(input_ctx, GGML_TYPE_F32, max_neighbors, n_atoms);
    ggml_set_name(cutoff_values_t, "cutoff_values");
  }

  // Mark edge_vectors as parameter for gradient computation
  if (compute_forces) {
    ggml_set_param(edge_vectors_t);
    // Adaptive cutoff models also need ∂E/∂cutoff_values to recover the
    // missing chain in the virial stress (correction added in C++).
    if (cutoff_values_t && num_neighbors_adaptive_ > 0.0f) {
      ggml_set_param(cutoff_values_t);
    }
  }

  // Allocate input buffer
  ggml_backend_buffer_t input_buffer =
      ggml_backend_alloc_ctx_tensors(input_ctx, compute_backend_);
  if (!input_buffer) {
    ggml_free(input_ctx);
    throw std::runtime_error("Failed to allocate input buffer");
  }

  // --- Pack neighbor list data ---
  std::vector<int32_t> species_data(n_atoms);
  for (int i = 0; i < n_atoms; i++) {
    auto it = species_to_index_.find(atomic_numbers[i]);
    if (it == species_to_index_.end()) {
      ggml_backend_buffer_free(input_buffer);
      ggml_free(input_ctx);
      throw std::runtime_error(
          "Atomic number " + std::to_string(atomic_numbers[i]) +
          " not in species map");
    }
    species_data[i] = it->second;
  }

  std::vector<int32_t> ns_data(total_slots, 0);
  std::vector<float> ev_data(total_slots * 3, 0.0f);
  std::vector<float> ed_data(total_slots, 0.0f);
  std::vector<float> pm_data(total_slots, 1.0f);  // 1.0 = padded
  std::vector<float> cf_data(total_slots, 0.0f);
  std::vector<float> cv_data(total_slots, cutoff_);
  std::vector<int32_t> rni_data(total_slots, 0);
  std::vector<int> neighbor_atoms_vec(total_slots, -1);

  // Build edge mapping
  using EdgeKey = std::tuple<int, int, int, int, int>;
  std::map<EdgeKey, int> edge_to_flat_idx;
  std::vector<int> slot_indices(n_atoms, 0);
  bool has_cell_shifts = !nlist.cell_shifts.empty();

  for (int e = 0; e < nlist.num_pairs(); e++) {
    int i = nlist.centers[e];
    int j = nlist.neighbors[e];
    int slot = slot_indices[i]++;
    if (slot >= max_neighbors) continue;

    int flat_idx = i * max_neighbors + slot;

    int sa = 0, sb = 0, sc = 0;
    if (has_cell_shifts) {
      sa = nlist.cell_shifts[e][0];
      sb = nlist.cell_shifts[e][1];
      sc = nlist.cell_shifts[e][2];
    }
    edge_to_flat_idx[{i, j, sa, sb, sc}] = flat_idx;

    auto it = species_to_index_.find(atomic_numbers[j]);
    if (it == species_to_index_.end()) {
      ggml_backend_buffer_free(input_buffer);
      ggml_free(input_ctx);
      throw std::runtime_error(
          "Atomic number " + std::to_string(atomic_numbers[j]) +
          " not in species map");
    }
    ns_data[flat_idx] = it->second;

    const auto &ev = nlist.edge_vectors[e];
    int ev_idx = i * (max_neighbors * 3) + slot * 3;
    ev_data[ev_idx + 0] = ev[0];
    ev_data[ev_idx + 1] = ev[1];
    ev_data[ev_idx + 2] = ev[2];

    ed_data[flat_idx] = nlist.distances[e];
    pm_data[flat_idx] = 0.0f;  // valid edge
    neighbor_atoms_vec[flat_idx] = j;

    float r = nlist.distances[e];
    float pc = pair_cutoffs[e];
    cv_data[flat_idx] = pc;
    if (cutoff_function_ == "bump") {
      cf_data[flat_idx] = cutoff_func_bump(r, pc, cutoff_width_);
    } else {
      cf_data[flat_idx] = cutoff_func_cosine(r, pc, cutoff_width_);
    }
  }

  // Build reverse neighbor index
  for (int e = 0; e < nlist.num_pairs(); e++) {
    int i = nlist.centers[e];
    int j = nlist.neighbors[e];
    int sa = 0, sb = 0, sc = 0;
    if (has_cell_shifts) {
      sa = nlist.cell_shifts[e][0];
      sb = nlist.cell_shifts[e][1];
      sc = nlist.cell_shifts[e][2];
    }
    auto it_ij = edge_to_flat_idx.find({i, j, sa, sb, sc});
    if (it_ij == edge_to_flat_idx.end()) continue;
    auto it_ji = edge_to_flat_idx.find({j, i, -sa, -sb, -sc});
    if (it_ji != edge_to_flat_idx.end()) {
      rni_data[it_ij->second] = it_ji->second;
    }
  }

  // Copy data to tensors
  ggml_backend_tensor_set(species_t, species_data.data(), 0,
                          species_data.size() * sizeof(int32_t));
  ggml_backend_tensor_set(neighbor_species_t, ns_data.data(), 0,
                          ns_data.size() * sizeof(int32_t));
  ggml_backend_tensor_set(edge_vectors_t, ev_data.data(), 0,
                          ev_data.size() * sizeof(float));
  ggml_backend_tensor_set(padding_mask_t, pm_data.data(), 0,
                          pm_data.size() * sizeof(float));
  ggml_backend_tensor_set(reverse_neighbor_index_t, rni_data.data(), 0,
                          rni_data.size() * sizeof(int32_t));

  // Register common inputs
  interp_.set_input("species", species_t);
  interp_.set_input("neighbor_species", neighbor_species_t);
  interp_.set_input("edge_vectors", edge_vectors_t);
  interp_.set_input("padding_mask", padding_mask_t);
  interp_.set_input("reverse_neighbor_index", reverse_neighbor_index_t);

  // Register mode-specific inputs
  if (!forces_mode_) {
    ggml_backend_tensor_set(edge_distances_t, ed_data.data(), 0,
                            ed_data.size() * sizeof(float));
    ggml_backend_tensor_set(cutoff_factors_t, cf_data.data(), 0,
                            cf_data.size() * sizeof(float));
    interp_.set_input("edge_distances", edge_distances_t);
    interp_.set_input("cutoff_factors", cutoff_factors_t);
  } else {
    ggml_backend_tensor_set(cutoff_values_t, cv_data.data(), 0,
                            cv_data.size() * sizeof(float));
    interp_.set_input("cutoff_values", cutoff_values_t);
  }

  // --- Build and compute ---
  ggml_context *compute_ctx = ggml_init({COMPUTE_CTX_SIZE, nullptr, true});
  if (!compute_ctx) {
    ggml_backend_buffer_free(input_buffer);
    ggml_free(input_ctx);
    throw std::runtime_error("Failed to create compute context");
  }

  ggml_tensor *output = interp_.build(compute_ctx);
  if (!output) {
    ggml_free(compute_ctx);
    ggml_backend_buffer_free(input_buffer);
    ggml_free(input_ctx);
    throw std::runtime_error("Failed to build computation graph");
  }
  ggml_set_output(output);

  ggml_cgraph *cgraph = nullptr;

  if (compute_forces) {
    // Build forward + backward graph
    ggml_tensor *total_energy = ggml_sum(compute_ctx, output);
    ggml_set_loss(total_energy);
    ggml_set_output(total_energy);

    cgraph = ggml_new_graph_custom(compute_ctx, 32768, true);
    ggml_build_forward_expand(cgraph, output);
    ggml_build_forward_expand(cgraph, total_energy);
    ggml_build_backward_expand(compute_ctx, cgraph, nullptr);

    ggml_tensor *grad = ggml_graph_get_grad(cgraph, edge_vectors_t);
    if (grad) {
      ggml_set_output(grad);
    } else {
      compute_forces = false;
    }
  } else {
    cgraph = ggml_new_graph(compute_ctx);
    ggml_build_forward_expand(cgraph, output);
  }

  ggml_backend_buffer_t compute_buffer =
      ggml_backend_alloc_ctx_tensors(compute_ctx, compute_backend_);
  if (!compute_buffer) {
    ggml_free(compute_ctx);
    ggml_backend_buffer_free(input_buffer);
    ggml_free(input_ctx);
    throw std::runtime_error("Failed to allocate compute buffer");
  }

  interp_.init_constants();

  if (compute_forces) {
    ggml_graph_reset(cgraph);
  }

  ggml_status status = ggml_backend_graph_compute(compute_backend_, cgraph);
  if (status != GGML_STATUS_SUCCESS) {
    ggml_backend_buffer_free(compute_buffer);
    ggml_free(compute_ctx);
    ggml_backend_buffer_free(input_buffer);
    ggml_free(input_ctx);
    throw std::runtime_error("Graph computation failed");
  }

  // --- Extract results ---
  ModelResult result;

  // Get atomic energies
  std::vector<float> atomic_energies(n_atoms);
  ggml_backend_tensor_get(output, atomic_energies.data(), 0,
                          n_atoms * sizeof(float));

  // Sum and scale
  float model_energy = 0.0f;
  for (int i = 0; i < n_atoms; i++) {
    model_energy += atomic_energies[i];
  }
  float scaled_energy = model_energy * energy_scale_;

  // Add composition energies
  float composition_energy = 0.0f;
  for (int i = 0; i < n_atoms; i++) {
    auto it = composition_energies_.find(atomic_numbers[i]);
    if (it != composition_energies_.end()) {
      composition_energy += it->second;
    }
  }

  result.energy = scaled_energy + composition_energy;

  // Extract forces
  if (compute_forces) {
    ggml_tensor *grad_tensor = ggml_graph_get_grad(cgraph, edge_vectors_t);
    if (grad_tensor && grad_tensor->data) {
      std::vector<float> grad_data(ggml_nelements(grad_tensor));
      ggml_backend_tensor_get(grad_tensor, grad_data.data(), 0,
                              ggml_nbytes(grad_tensor));

      // Scatter edge gradients to per-atom forces
      result.forces.resize(n_atoms * 3, 0.0f);
      const int stride_slot = 3;
      const int stride_atom = 3 * max_neighbors;

      for (int ca = 0; ca < n_atoms; ca++) {
        for (int slot = 0; slot < max_neighbors; slot++) {
          int flat_idx = ca * max_neighbors + slot;
          if (pm_data[flat_idx] > 0.5f) continue;

          int na = neighbor_atoms_vec[flat_idx];
          if (na < 0) continue;

          int base = slot * stride_slot + ca * stride_atom;
          float gx = grad_data[0 + base];
          float gy = grad_data[1 + base];
          float gz = grad_data[2 + base];

          result.forces[ca * 3 + 0] += gx;
          result.forces[ca * 3 + 1] += gy;
          result.forces[ca * 3 + 2] += gz;

          result.forces[na * 3 + 0] -= gx;
          result.forces[na * 3 + 1] -= gy;
          result.forces[na * 3 + 2] -= gz;
        }
      }

      // Apply energy scale
      for (int i = 0; i < n_atoms * 3; i++) {
        result.forces[i] *= energy_scale_;
      }

      result.has_forces = true;

      // Virial stress for periodic systems: σ_ab = (1/V) Σ_edges r_a ⊗ ∂E/∂r_b.
      // Off-diagonal Voigt components are symmetrized.
      const Cell *cell = system.cell();
      if (cell &&
          (cell->periodic[0] || cell->periodic[1] || cell->periodic[2])) {
        const auto &m = cell->matrix;
        float vol = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
                    m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
                    m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
        vol = std::abs(vol);

        if (vol > 1e-10f) {
          result.stress.assign(6, 0.0f);
          for (int ca = 0; ca < n_atoms; ca++) {
            for (int slot = 0; slot < max_neighbors; slot++) {
              int flat_idx = ca * max_neighbors + slot;
              if (pm_data[flat_idx] > 0.5f) continue;

              int base = slot * stride_slot + ca * stride_atom;
              float ex = ev_data[base + 0];
              float ey = ev_data[base + 1];
              float ez = ev_data[base + 2];
              float gx = grad_data[base + 0];
              float gy = grad_data[base + 1];
              float gz = grad_data[base + 2];

              result.stress[0] += ex * gx;                    // xx
              result.stress[1] += ey * gy;                    // yy
              result.stress[2] += ez * gz;                    // zz
              result.stress[3] += 0.5f * (ey * gz + ez * gy); // yz
              result.stress[4] += 0.5f * (ex * gz + ez * gx); // xz
              result.stress[5] += 0.5f * (ex * gy + ey * gx); // xy
            }
          }
          // Chain-rule correction: the model's autograd doesn't see the
          // implicit dependence of pair_cutoffs on edge_distances (the C++
          // adaptive cutoff math). When cutoff_values_t was marked as a
          // ggml param, its gradient C[e] = ∂E/∂cutoff_values[e] is also
          // available; combined with the analytic Jacobian J[e'] =
          // ∂atomic_cutoffs[i_{e'}]/∂d_{e'} we recover the missing virial
          // term. Skipped when adaptive cutoff isn't active.
          if (have_adaptive && cutoff_values_t) {
            ggml_tensor *cv_grad = ggml_graph_get_grad(cgraph, cutoff_values_t);
            if (cv_grad && cv_grad->data) {
              std::vector<float> cv_grad_data(ggml_nelements(cv_grad));
              ggml_backend_tensor_get(cv_grad, cv_grad_data.data(), 0,
                                      ggml_nbytes(cv_grad));

              // S[k] = Σ_e (in filtered list, edge e touches atom k) C_e
              std::vector<double> S(n_atoms, 0.0);
              for (int ca = 0; ca < n_atoms; ca++) {
                for (int slot = 0; slot < max_neighbors; slot++) {
                  int flat_idx = ca * max_neighbors + slot;
                  if (pm_data[flat_idx] > 0.5f) continue;
                  int na = neighbor_atoms_vec[flat_idx];
                  if (na < 0) continue;
                  double c = static_cast<double>(cv_grad_data[flat_idx]);
                  S[ca] += c;
                  S[na] += c;
              }
              }
              // S[k] is symmetric in i↔j averaging since cv[e] = 0.5*(a[i]+a[j])
              // and we summed C over both endpoints for each edge.

              const int n_probes = adapt_cache.n_probes;
              const auto &probes = adapt_cache.probes;
              const auto &X = adapt_cache.diff_jacobian;
              const float ew = adapt_cache.effective_width;

              double corr[6] = {0, 0, 0, 0, 0, 0};
              for (int e = 0; e < full_nlist.num_pairs(); e++) {
                int k = full_nlist.centers[e];
                double d = static_cast<double>(full_nlist.distances[e]);
                if (d <= 0.0) continue;
                // J[e] = Σ_p X[k, p] * bump_derivative(d, probes[p], ew)
                double J = 0.0;
                const double *Xk = &X[static_cast<size_t>(k) * n_probes];
                for (int p = 0; p < n_probes; p++) {
                  J += Xk[p] * bump_derivative(static_cast<float>(d),
                                               probes[p], ew);
                }
                if (J == 0.0) continue;
                double coef = 0.5 * J * S[k] / d;
                const auto &r = full_nlist.edge_vectors[e];
                double ex = r[0], ey = r[1], ez = r[2];
                corr[0] += coef * ex * ex;
                corr[1] += coef * ey * ey;
                corr[2] += coef * ez * ez;
                corr[3] += 0.5 * coef * (ey * ez + ez * ey);
                corr[4] += 0.5 * coef * (ex * ez + ez * ex);
                corr[5] += 0.5 * coef * (ex * ey + ey * ex);
              }
              for (int i = 0; i < 6; i++) {
                result.stress[i] += static_cast<float>(corr[i]);
              }
            }
          }

          for (int i = 0; i < 6; i++) {
            result.stress[i] *= energy_scale_ / vol;
          }
          result.has_stress = true;
        }
      }
    }
  }

  // Cleanup
  ggml_backend_buffer_free(compute_buffer);
  ggml_free(compute_ctx);
  ggml_backend_buffer_free(input_buffer);
  ggml_free(input_ctx);

  return result;
}

} // namespace mlipcpp::runtime
