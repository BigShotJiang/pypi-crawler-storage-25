from typing import List, Optional

from pydantic import BaseModel, Field

from aiomax.enums.permissions import ChatAdminPermission
from aiomax.models.command import BotCommand

class User(BaseModel):
    user_id: int
    first_name: str
    last_name: Optional[str] = None
    username: Optional[str] = None
    is_bot: bool
    last_activity_time: Optional[int] = None
    name:str # устареет скоро, следить

class UserWithPhoto(User):
    description: Optional[str] = None
    avatar_url: Optional[str] = None
    full_avatar_url: Optional[str] = None

class BotInfo(UserWithPhoto):
    commands: Optional[List[BotCommand]] = None

class ChatMember(User):
    last_access_time: int
    is_owner: bool
    is_admin: bool
    join_time: int
    permissions: List[ChatAdminPermission | str] = Field(default_factory=list)
    alias: Optional[str] = None


class ChatAdmin(BaseModel):
    user_id: int
    permissions: List[ChatAdminPermission | str] = Field(default_factory=list)
    alias: Optional[str] = None