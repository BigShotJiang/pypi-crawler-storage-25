from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel, Field, StrictStr


class NodeSshKey(BaseModel):
    id: StrictStr = Field(..., description="The ID of the SSH key")
    name: StrictStr = Field(..., description="The name of the SSH key")
    scope: StrictStr = Field(
        default="private", description="The visibility scope of the SSH key"
    )


class SshKeyProvider(ABC):
    @abstractmethod
    def list_keys(self) -> List[NodeSshKey]: ...

    @abstractmethod
    def get_key(self, id: str) -> Optional[NodeSshKey]: ...

    @abstractmethod
    def import_key(self, name: str, key_path: Path) -> NodeSshKey: ...
