from pathlib import Path
from typing import Optional, Union

from pydantic import BaseModel, Field, NonNegativeFloat, PositiveInt, StrictStr

from exls.nodes.core.domain import NodeStatus


class NodesFilterCriteria(BaseModel):
    """Domain object representing query parameters for nodes."""

    node_type: Optional[StrictStr] = Field(
        default=None, description="The type of the node"
    )
    provider: Optional[StrictStr] = Field(
        default=None, description="The provider of the node"
    )
    status: Optional[NodeStatus] = Field(
        default=None, description="The status of the node"
    )
    sort_field: Optional[StrictStr] = Field(
        default=None, description="The field to sort by (e.g. CREATED_AT, HOSTNAME)"
    )
    order_by: Optional[StrictStr] = Field(
        default=None, description="The sort order (ASC or DESC)"
    )


class NodesSshKeySpecification(BaseModel):
    """Domain object representing parameters for an SSH key."""

    name: StrictStr = Field(..., description="The name of the SSH key")
    key_path: Path = Field(..., description="The path to the SSH key file")


class ImportSelfmanagedNodeRequest(BaseModel):
    """Domain object representing parameters for importing a self-managed node."""

    hostname: StrictStr = Field(..., description="The hostname of the node")
    endpoint: StrictStr = Field(..., description="The endpoint of the node")
    username: StrictStr = Field(..., description="The username of the node")
    price_per_hour: NonNegativeFloat = Field(
        ..., description="The price per hour to use"
    )
    ssh_key: Union[StrictStr, NodesSshKeySpecification] = Field(
        ..., description="The SSH key to use"
    )


class ImportCloudNodeRequest(BaseModel):
    """Domain object representing parameters for importing a cloud node."""

    hostname: StrictStr = Field(..., description="The hostname of the node")
    offer_id: StrictStr = Field(..., description="The ID of the offer to use")
    amount: PositiveInt = Field(..., description="The amount of nodes to import")
