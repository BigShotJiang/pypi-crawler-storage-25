from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Optional

from pydantic import BaseModel, Field, NonNegativeFloat, StrictInt, StrictStr


class NodeStatus(StrEnum):
    DISCOVERING = "DISCOVERING"
    AVAILABLE = "AVAILABLE"
    ADDED = "ADDED"
    DEPLOYED = "DEPLOYED"
    FAILED = "FAILED"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_str(cls, value: str) -> NodeStatus:
        try:
            return cls(value.upper())
        except ValueError:
            return cls.UNKNOWN


class NodeResources(BaseModel):
    gpu_type: StrictStr = Field(..., description="The type of the GPU")
    gpu_vendor: StrictStr = Field(..., description="The vendor of the GPU")
    gpu_count: StrictInt = Field(..., description="The count of the GPU")
    cpu_cores: StrictInt = Field(..., description="The count of the CPU cores")
    memory_gb: StrictInt = Field(..., description="The amount of memory in GB")
    storage_gb: StrictInt = Field(..., description="The amount of storage in GB")


class BaseNode(BaseModel):
    """Domain object representing a node."""

    id: StrictStr = Field(..., description="The ID of the node")
    hostname: StrictStr = Field(..., description="The hostname of the node")
    import_time: Optional[datetime] = Field(
        ..., description="The time the node was imported"
    )
    status: NodeStatus = Field(..., description="The status of the node")
    resources: NodeResources = Field(..., description="The resources of the node")
    price_per_hour: NonNegativeFloat = Field(
        ..., description="The price per hour of the node"
    )
    warning_message: Optional[StrictStr] = Field(
        default=None, description="Warning message if node is in WARNING status"
    )

    @property
    def name(self) -> str:
        """Alias for hostname to support name-or-id resolution."""
        return self.hostname


class CloudNode(BaseNode):
    """Domain object representing a cloud node."""

    provider: StrictStr = Field(..., description="The provider of the node")
    instance_type: StrictStr = Field(..., description="The instance type of the node")


class SelfManagedNode(BaseNode):
    """Domain object representing a self-managed node."""

    ssh_key_id: StrictStr = Field(..., description="The ID of the SSH key")
    ssh_key_name: Optional[StrictStr] = Field(
        default="", description="The name of the SSH key"
    )
    username: StrictStr = Field(..., description="The username of the node")
    endpoint: Optional[StrictStr] = Field(
        default=None, description="The endpoint of the node"
    )
