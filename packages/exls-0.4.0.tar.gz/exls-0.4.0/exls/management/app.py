from pathlib import Path
from typing import List, Optional

import typer

from exls.management.adapters.bundle import ManagementBundle
from exls.management.adapters.ui.flows.import_ssh_key import (
    FlowImportSshKeyRequestDTO,
    ImportSshKeyFlow,
)
from exls.management.core.domain import (
    SshKey,
    SshKeyScope,
    WorkspaceTemplate,
)
from exls.management.core.service import ManagementService
from exls.shared.adapters.decorators import handle_application_layer_errors
from exls.shared.adapters.ui.facade.facade import IOBaseModelFacade
from exls.shared.adapters.ui.flow.flow import FlowContext
from exls.shared.adapters.ui.utils import (
    called_with_any_user_input,
    get_app_state_from_ctx,
    get_config_from_ctx,
    help_if_no_subcommand,
    open_url_in_browser,
)
from exls.shared.core.resolver import (
    AmbiguousResourceError,
    ResourceNotFoundError,
    resolve_resource_id,
)
from exls.shared.core.utils import generate_random_name

management_app = typer.Typer()


def _get_bundle(ctx: typer.Context) -> ManagementBundle:
    """Helper to instantiate the ManagementBundle from the context."""
    return ManagementBundle(get_config_from_ctx(ctx), get_app_state_from_ctx(ctx))


def _resolve_ssh_key_id_callback(ctx: typer.Context, value: str) -> str:
    """
    Callback to resolve an SSH key name or ID to an SSH key ID.
    Fetches all SSH keys and matches the name/ID.
    """
    try:
        bundle: ManagementBundle = _get_bundle(ctx)
        service: ManagementService = bundle.get_management_service()
        ssh_keys: List[SshKey] = service.list_ssh_keys()
        return resolve_resource_id(ssh_keys, value, "ssh-key")
    except (ResourceNotFoundError, AmbiguousResourceError) as e:
        raise typer.BadParameter(str(e))


workspace_templates_app = typer.Typer()
ssh_keys_app = typer.Typer()

management_app.add_typer(workspace_templates_app, name="workspace-templates")
management_app.add_typer(ssh_keys_app, name="ssh-keys")


@management_app.callback(invoke_without_command=True)
def _root(  # pyright: ignore[reportUnusedFunction]
    ctx: typer.Context,
):
    """
    Manage the management resources.
    """
    help_if_no_subcommand(ctx)


@management_app.command("get-dashboard-url", help="Get Grafana dashboard URL")
@handle_application_layer_errors(ManagementBundle)
def get_dashboard_url(
    ctx: typer.Context,
    open_browser: bool = typer.Option(
        False,
        "--open",
        help="Open the dashboard URL in the default browser",
    ),
):
    """Get the Grafana dashboard URL."""
    bundle: ManagementBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ManagementService = bundle.get_management_service()

    dashboard_url_str: str = service.get_dashboard_url()

    if open_browser:
        if open_url_in_browser(dashboard_url_str):
            io_facade.display_success_message(
                "Opening Grafana Dashboard URL in browser...",
                bundle.message_output_format,
            )
        else:
            io_facade.display_error_message(
                "Failed to open browser. Please open the URL manually.",
                bundle.message_output_format,
            )

    io_facade.display_success_message(
        f"Grafana Dashboard URL: {dashboard_url_str}",
        bundle.message_output_format,
    )


@workspace_templates_app.command("list", help="List workspace templates")
@handle_application_layer_errors(ManagementBundle)
def list_workspace_templates(
    ctx: typer.Context,
):
    """List all available workspace templates."""
    bundle: ManagementBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ManagementService = bundle.get_management_service()

    domain_workspace_templates: List[WorkspaceTemplate] = (
        service.list_workspace_templates()
    )

    io_facade.display_data(
        domain_workspace_templates, output_format=bundle.object_output_format
    )


@ssh_keys_app.command("list", help="List SSH keys")
@handle_application_layer_errors(ManagementBundle)
def list_ssh_keys(
    ctx: typer.Context,
):
    """List all available SSH keys."""
    bundle: ManagementBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ManagementService = bundle.get_management_service()

    domain_ssh_keys: List[SshKey] = service.list_ssh_keys()

    io_facade.display_data(domain_ssh_keys, output_format=bundle.object_output_format)


@ssh_keys_app.command("import", help="Import an SSH key")
@handle_application_layer_errors(ManagementBundle)
def import_ssh_key(
    ctx: typer.Context,
    name: Optional[str] = typer.Option(
        generate_random_name(prefix="exls-key"),
        "--name",
        "-n",
        help="Name for the SSH key",
    ),
    key_path: Optional[Path] = typer.Option(
        None, "--key-path", "-k", help="Path to the SSH private key file"
    ),
    scope: str = typer.Option(
        "private",
        "--scope",
        "-s",
        help="Visibility scope of the SSH key ('private' or 'org')",
    ),
):
    """Import a new SSH key to the management cluster."""
    bundle: ManagementBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ManagementService = bundle.get_management_service()

    add_ssh_key_request: FlowImportSshKeyRequestDTO = FlowImportSshKeyRequestDTO()
    if not called_with_any_user_input(ctx):
        add_ssh_key_flow: ImportSshKeyFlow = bundle.get_import_ssh_key_flow()
        add_ssh_key_flow.execute(add_ssh_key_request, FlowContext(), io_facade)
    else:
        if not name or not key_path:
            io_facade.display_error_message(
                message="Name and key path are required",
                output_format=bundle.message_output_format,
            )
            raise typer.Exit(1)

        add_ssh_key_request.name = name
        add_ssh_key_request.key_path = key_path
        add_ssh_key_request.scope = SshKeyScope(scope)

    domain_ssh_key: SshKey = service.import_ssh_key(
        name=add_ssh_key_request.name,
        key_path=add_ssh_key_request.key_path,
        scope=add_ssh_key_request.scope.value,
    )

    io_facade.display_data(domain_ssh_key, output_format=bundle.object_output_format)


@ssh_keys_app.command("delete", help="Delete an SSH key")
@handle_application_layer_errors(ManagementBundle)
def delete_ssh_key(
    ctx: typer.Context,
    ssh_key_id: str = typer.Argument(
        ...,
        help="The name or ID of the SSH key to delete",
        metavar="SSH_KEY_NAME_OR_ID",
        callback=_resolve_ssh_key_id_callback,
    ),
):
    """Delete an SSH key from the management cluster."""
    bundle: ManagementBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ManagementService = bundle.get_management_service()

    deleted_ssh_key_id: str = service.delete_ssh_key(ssh_key_id)

    io_facade.display_success_message(
        f"SSH key {deleted_ssh_key_id} deleted successfully",
        output_format=bundle.message_output_format,
    )
