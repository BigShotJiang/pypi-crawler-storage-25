from __future__ import annotations

import logging
from typing import (
    Any,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    Sequence,
    TypeVar,
)

from pydantic import BaseModel, ConfigDict, Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from rich import box
from rich.console import JustifyMethod
from rich.style import Style, StyleType
from rich.table import Table
from rich.text import Text

from exls.defaults import CONFIG_ENV_NESTED_DELIMITER, CONFIG_ENV_PREFIX
from exls.shared.adapters.ui.output.interfaces import (
    IListRenderer,
    ISingleItemRenderer,
)
from exls.shared.adapters.ui.shared.render.entities import BaseRenderContext

T = TypeVar("T", bound=BaseModel)


def _get_nested_attribute(obj: Any, attr: str, default: Any = "") -> Any:
    """
    Safely retrieves a nested attribute from an object using dot notation.
    For example for an attribute `a.b.c`, it will try to get `obj.a.b.c`.
    If any attribute in the chain does not exist, it returns the default value.
    """
    try:
        current = obj
        for part in attr.split("."):
            if isinstance(current, list):
                current = [getattr(item, part) for item in current]  # type: ignore
            else:
                current = getattr(current, part)
        return current
    except (AttributeError, TypeError) as e:
        logging.debug(
            f"Error getting nested attribute {attr} from {obj} - Returning default value: {default} - Error: {e}"
        )
        return default


class DefaultColumnRenderingConfig(BaseSettings):
    """
    Default column configuration.
    """

    color: str = Field(description="The color of the column", default="white")
    bgcolor: Optional[str] = Field(
        description="The background color of the column", default=None
    )
    bold: bool = Field(description="Whether to bold the column", default=False)
    dim: bool = Field(description="Whether to dim the column", default=False)
    italic: bool = Field(description="Whether to italic the column", default=False)
    underline: bool = Field(
        description="Whether to underline the column", default=False
    )
    blink: bool = Field(description="Whether to blink the column", default=False)
    no_wrap: bool = Field(description="Whether to wrap the column", default=False)
    justify: JustifyMethod = Field(
        description="The justification of the column", default="left"
    )

    model_config = SettingsConfigDict(
        env_prefix=CONFIG_ENV_PREFIX + "DEFAULT_COLUMN_RENDERING_CONFIG_",
        env_nested_delimiter=CONFIG_ENV_NESTED_DELIMITER,
        extra="ignore",
    )


class Column(BaseModel):
    """
    Represents the structure of a table column.
    """

    header: str = Field(..., description="The header of the column")
    no_wrap: bool = Field(..., description="Whether to wrap the column")
    justify: JustifyMethod = Field(..., description="The justification of the column")
    style: StyleType = Field(
        ...,
        description="The style of the column. See rich.style.Style for more details.",
    )
    value_formatter: Callable[[Any], Any] = Field(
        ...,
        description="A function to format the value of the column. May return a string or a Rich renderable (e.g. Text).",
    )
    hide_if_empty: bool = Field(
        default=False,
        description="If True, hide this row in single-item views when the value is None or empty",
    )

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
    )


class TableRenderContext(BaseRenderContext):
    """Render context for table output."""

    header_style: str = Field(..., description="The header style of the table")
    border_style: str = Field(..., description="The border style of the table")

    default_no_wrap: bool = Field(..., description="Whether to wrap the column")
    default_justify: JustifyMethod = Field(
        ..., description="The justification of the column"
    )
    default_style: StyleType = Field(..., description="The style of the column")

    columns: Dict[str, Column] = Field(..., description="The columns to display")

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @staticmethod
    def get_column(
        header: str,
        no_wrap: Optional[bool] = None,
        justify: Optional[JustifyMethod] = None,
        style: Optional[StyleType] = None,
        value_formatter: Callable[[Any], Any] = lambda x: (
            str(x) if x is not None else ""
        ),
        hide_if_empty: bool = False,
    ) -> Column:
        """
        Get a column with default styling based on the header.
        """
        style_config = DefaultColumnRenderingConfig()

        final_no_wrap = no_wrap or style_config.no_wrap
        final_justify = justify or style_config.justify

        final_style = style or Style(
            color=style_config.color,
            bgcolor=style_config.bgcolor,
            bold=style_config.bold,
            dim=style_config.dim,
            italic=style_config.italic,
            underline=style_config.underline,
            blink=style_config.blink,
        )

        return Column(
            header=header,
            no_wrap=final_no_wrap,
            justify=final_justify,
            style=final_style,
            value_formatter=value_formatter,
            hide_if_empty=hide_if_empty,
        )

    @classmethod
    def columns_from_model_dump(cls, data: Dict[str, Any]) -> Dict[str, Column]:
        """
        Get the columns from a model dump.
        """
        return {key: cls.get_column(header=key) for key in data.keys()}

    @classmethod
    def get_table_render_context(
        cls,
        columns: Dict[str, Column],
        header_style: Optional[str] = None,
        border_style: Optional[str] = None,
        default_no_wrap: Optional[bool] = None,
        default_justify: Optional[JustifyMethod] = None,
        default_style: Optional[StyleType] = None,
    ) -> TableRenderContext:
        style_config = DefaultTableRenderingConfig()
        return cls(
            header_style=header_style or style_config.header_style,
            border_style=border_style or style_config.border_style,
            default_no_wrap=default_no_wrap or style_config.default_no_wrap,
            default_justify=default_justify or style_config.default_justify,
            default_style=default_style or style_config.default_style,
            columns=columns,
        )


class DefaultTableRenderingConfig(BaseSettings):
    """
    Table configuration.
    """

    header_style: str = Field(
        description="The header style of the table", default="bold dim #f46907"
    )
    border_style: str = Field(
        description="The border style of the table", default="dim #f46907"
    )

    default_no_wrap: bool = Field(
        description="Whether to wrap the column", default=False
    )
    default_justify: JustifyMethod = Field(
        description="The justification of the column", default="left"
    )
    default_style: StyleType = Field(
        description="The style of the column", default=Style()
    )

    model_config = SettingsConfigDict(
        env_prefix=CONFIG_ENV_PREFIX + "TABLE_RENDERING_CONFIG_",
        env_nested_delimiter=CONFIG_ENV_NESTED_DELIMITER,
        extra="ignore",
        arbitrary_types_allowed=True,
    )

    def to_table_render_context(self, columns: Dict[str, Column]) -> TableRenderContext:
        """Convert the rendering config to a table render context."""
        return TableRenderContext(
            header_style=self.header_style,
            border_style=self.border_style,
            default_no_wrap=self.default_no_wrap,
            default_justify=self.default_justify,
            default_style=self.default_style,
            columns=columns,
        )


class _BaseTableRenderer:
    """Base class for Table renderers."""

    def __init__(self):
        self.default_render_config = DefaultTableRenderingConfig()

    def resolve_context(
        self,
        render_context: Optional[BaseRenderContext],
        columns: Optional[Dict[str, Column]] = None,
    ) -> TableRenderContext:
        """Resolve the render context."""
        if render_context:
            assert isinstance(
                render_context, TableRenderContext
            ), "Render context must be a TableRenderContext"
            return render_context

        assert columns, "If no render context is provided, columns must be set"

        return self.default_render_config.to_table_render_context(columns)

    def _create_table(self, render_context: TableRenderContext) -> Table:
        """Create a configured Table instance."""
        table = Table(
            show_header=True,
            header_style=render_context.header_style,
            border_style=render_context.border_style,
            box=box.ROUNDED,
        )
        for column in render_context.columns.values():
            table.add_column(
                column.header,
                justify=column.justify,
                no_wrap=column.no_wrap,
                style=column.style,
            )
        return table


class TableListRenderer(IListRenderer[T, Table], Generic[T], _BaseTableRenderer):
    """Renders a list of items as a table."""

    def __init__(self):
        super().__init__()

    def render(
        self,
        data: Sequence[T],
        render_context: Optional[BaseRenderContext] = None,
    ) -> Table:
        """Render a list of items to a table."""
        if not data:
            return Table()

        columns = None
        if not render_context:
            # We fallback to the first item in the list to get the columns
            model_dump: Dict[str, Any] = data[0].model_dump()
            columns = TableRenderContext.columns_from_model_dump(model_dump)

        validated_render_context: TableRenderContext = self.resolve_context(
            render_context, columns
        )
        table: Table = self._create_table(validated_render_context)

        for item_data in data:
            row_values: List[Any] = []
            for key, column in validated_render_context.columns.items():
                value: Any = _get_nested_attribute(item_data, key)
                value = column.value_formatter(value)
                row_values.append(value)
            table.add_row(*row_values)

        return table


class TableSingleItemRenderer(
    ISingleItemRenderer[T, Table], Generic[T], _BaseTableRenderer
):
    """Renders a single item as a table."""

    def __init__(self):
        super().__init__()

    def render(
        self,
        data: T,
        render_context: Optional[BaseRenderContext] = None,
    ) -> Table:
        """Render the attributes of a single item as a two-column table (Property, Value)."""
        # Always use columns "Property" and "Value"
        columns = {
            "Property": TableRenderContext.get_column(
                header="Property", style=Style(color="blue", bold=True)
            ),
            "Value": TableRenderContext.get_column(header="Value"),
        }

        # If context is provided, we can use it to filter/order the properties shown
        validated_render_context: Optional[TableRenderContext] = None
        if render_context:
            validated_render_context = self.resolve_context(render_context)

        single_item_table_render_context = TableRenderContext.get_table_render_context(
            columns=columns
        )
        table = self._create_table(single_item_table_render_context)

        attrs: Dict[str, Any] = data.model_dump()

        # Include @property attributes as well
        property_names = [
            name
            for name in dir(data.__class__)
            if isinstance(getattr(data.__class__, name, None), property)
            and not name.startswith("_")
        ]
        property_values = {name: getattr(data, name) for name in property_names}

        # Merge regular attributes and property attributes (property values take precedence if same key)
        all_attrs = {**attrs, **property_values}

        # Determine which keys to show and in what order
        keys_to_show: Any = all_attrs.keys()
        if validated_render_context:
            # Use the columns from the context to determine order and visibility
            # Support dot-notation keys (e.g. "resources.gpu_type") by checking
            # both flat dict keys and nested attribute access on the original object
            keys_to_show = [
                k
                for k in validated_render_context.columns.keys()
                if k in all_attrs
                or ("." in k and _get_nested_attribute(data, k, None) is not None)
            ]

        for key in keys_to_show:
            # For dot-notation keys, resolve from the original object
            if key in all_attrs:
                value = all_attrs[key]
            else:
                value = _get_nested_attribute(data, key)

            # Skip empty values for columns marked with hide_if_empty
            if (
                validated_render_context
                and validated_render_context.columns[key].hide_if_empty
                and not value
            ):
                continue

            key_display = key
            if validated_render_context:
                key_display = validated_render_context.columns[key].header
                value = validated_render_context.columns[key].value_formatter(value)

            # Format property name
            prop_col = single_item_table_render_context.columns["Property"]
            prop_str = prop_col.value_formatter(key_display)

            # Format value — preserve Rich renderables (e.g. styled Text)
            if isinstance(value, Text):
                val_display = value
            else:
                val_col = single_item_table_render_context.columns["Value"]
                val_display = val_col.value_formatter(value)

            table.add_row(prop_str, val_display)

        return table
