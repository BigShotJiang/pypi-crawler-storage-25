from typing import Dict

from exls.shared.adapters.ui.output.render.service import (
    format_datetime,
    format_datetime_humanized,
    format_list,
    format_short_id,
    format_status,
)
from exls.shared.adapters.ui.output.render.table import Column, TableRenderContext
from exls.shared.adapters.ui.output.view import ViewContext

# -----------------------------------------------------------------------------
# WORKSPACE LIST VIEWS (humanized timestamps)
# -----------------------------------------------------------------------------


_WORKSPACE_LIST_COLUMNS: Dict[str, Column] = {
    "id": TableRenderContext.get_column(
        "ID", no_wrap=True, value_formatter=format_short_id
    ),
    "name": TableRenderContext.get_column("Name"),
    "template_name": TableRenderContext.get_column("Template"),
    "status": TableRenderContext.get_column("Status", value_formatter=format_status),
    "created_at": TableRenderContext.get_column(
        "Created At", value_formatter=format_datetime_humanized
    ),
    "cluster_id": TableRenderContext.get_column(
        "Cluster ID", value_formatter=format_short_id
    ),
    "owner_username": TableRenderContext.get_column("Creator"),
    "access_information.formatted_access_information": TableRenderContext.get_column(
        "Access", value_formatter=format_list
    ),
}

WORKSPACE_LIST_VIEW = ViewContext.from_table_columns(_WORKSPACE_LIST_COLUMNS)


# -----------------------------------------------------------------------------
# WORKSPACE DETAIL VIEWS (ISO timestamps for single resource get)
# -----------------------------------------------------------------------------

_WORKSPACE_DETAIL_COLUMNS: Dict[str, Column] = {
    "id": TableRenderContext.get_column("ID", no_wrap=True),
    "name": TableRenderContext.get_column("Name"),
    "template_name": TableRenderContext.get_column("Template"),
    "status": TableRenderContext.get_column("Status", value_formatter=format_status),
    "created_at": TableRenderContext.get_column(
        "Created At", value_formatter=format_datetime
    ),
    "cluster_id": TableRenderContext.get_column("Cluster ID"),
    "owner_username": TableRenderContext.get_column("Creator"),
    "owner_org_name": TableRenderContext.get_column("Organization"),
    "owner_org_id": TableRenderContext.get_column("Org ID"),
    "owner_teams": TableRenderContext.get_column(
        "Teams", value_formatter=lambda teams: ", ".join(teams) if teams else ""
    ),
    "access_information.formatted_access_information": TableRenderContext.get_column(
        "Access", value_formatter=format_list
    ),
}

WORKSPACE_DETAIL_VIEW = ViewContext.from_table_columns(_WORKSPACE_DETAIL_COLUMNS)

# -----------------------------------------------------------------------------
# DEPLOY REQUEST VIEWS
# -----------------------------------------------------------------------------

_DEPLOY_WORKSPACE_REQUEST_COLUMNS: Dict[str, Column] = {
    "cluster_id": TableRenderContext.get_column("Cluster ID"),
    "workspace_name": TableRenderContext.get_column("Name"),
    "template_id": TableRenderContext.get_column("Template"),
    "resources.gpu_count": TableRenderContext.get_column("GPUs"),
    "resources.cpu_cores": TableRenderContext.get_column("CPUs"),
    "resources.memory_gb": TableRenderContext.get_column("Memory (GB)"),
}

DEPLOY_WORKSPACE_REQUEST_VIEW = ViewContext.from_table_columns(
    _DEPLOY_WORKSPACE_REQUEST_COLUMNS
)
