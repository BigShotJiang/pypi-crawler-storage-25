import datetime
from abc import ABC, abstractmethod
from enum import StrEnum
from typing import Dict, Iterator, List, Optional

from pydantic import BaseModel, Field, StrictInt, StrictStr

from exls.clusters.core.domain import (
    ClusterEvent,
    ClusterStatus,
    ClusterType,
)

# It's a leaky abstraction between the domain and the gateway layer.
# Strong abstraction is not needed here for now.
from exls.clusters.core.ports.repository import ClusterCreateParameters


class ClusterData(BaseModel):
    id: StrictStr = Field(..., description="The ID of the cluster")
    name: StrictStr = Field(..., description="The name of the cluster")
    status: ClusterStatus = Field(..., description="The status of the cluster")
    type: ClusterType = Field(..., description="The type of the cluster")
    created_at: datetime.datetime = Field(
        ..., description="The creation date of the cluster"
    )
    updated_at: Optional[datetime.datetime] = Field(
        default=None, description="The last update date of the cluster"
    )
    owner_username: Optional[StrictStr] = Field(
        None, description="The username of the cluster creator"
    )
    owner_org_id: Optional[StrictStr] = Field(
        None, description="The organization ID of the cluster creator"
    )
    owner_org_name: Optional[StrictStr] = Field(
        None, description="The organization name of the cluster creator"
    )
    owner_teams: Optional[List[StrictStr]] = Field(
        None, description="The teams of the cluster creator"
    )
    worker_node_ids: List[StrictStr] = Field(
        default_factory=list, description="The IDs of the worker nodes"
    )
    control_plane_node_ids: List[StrictStr] = Field(
        default_factory=list, description="The IDs of the control plane nodes"
    )


class ClusterNodeRefData(BaseModel):
    id: StrictStr = Field(..., description="The ID of the node")
    role: StrictStr = Field(..., description="The role of the node")


class ResourcesData(BaseModel):
    gpu_type: StrictStr = Field(..., description="The type of the GPU")
    gpu_vendor: StrictStr = Field(..., description="The vendor of the GPU")
    gpu_count: StrictInt = Field(..., description="The count of the GPU")
    cpu_cores: StrictInt = Field(..., description="The number of CPU cores")
    memory_gb: StrictInt = Field(..., description="The amount of memory in GB")
    storage_gb: StrictInt = Field(..., description="The amount of storage in GB")


class ClusterNodeRefResourcesData(BaseModel):
    node_id: StrictStr = Field(..., description="The ID of the node")
    node_name: StrictStr = Field(..., description="The name of the node")
    free_resources: ResourcesData = Field(
        ..., description="The free resources of the node"
    )
    occupied_resources: ResourcesData = Field(
        ..., description="The occupied resources of the node"
    )


class _ClusterLabels(StrEnum):
    VOLCANO_WORKOAD = "cluster.exalsius.ai/volcano-workload"
    LLM_D_WORKLOAD = "cluster.exalsius.ai/llm-d-workload"


def get_cluster_labels(
    parameters: ClusterCreateParameters,
) -> Dict[StrictStr, StrictStr]:
    labels: Dict[StrictStr, StrictStr] = {}
    if parameters.enable_multinode_training:
        labels[_ClusterLabels.VOLCANO_WORKOAD] = "true"
    if parameters.prepare_llm_inference_environment:
        labels[_ClusterLabels.LLM_D_WORKLOAD] = "true"
    return labels


class ClustersGateway(ABC):
    @abstractmethod
    def list(self, status: Optional[ClusterStatus]) -> List[ClusterData]:
        raise NotImplementedError

    @abstractmethod
    def get(self, cluster_id: str) -> ClusterData:
        raise NotImplementedError

    @abstractmethod
    def delete(self, cluster_id: str) -> str:
        raise NotImplementedError

    @abstractmethod
    def create(self, parameters: ClusterCreateParameters) -> str:
        raise NotImplementedError

    @abstractmethod
    def deploy(self, cluster_id: str) -> str:
        raise NotImplementedError

    @abstractmethod
    def get_cluster_nodes(self, cluster_id: str) -> List[ClusterNodeRefData]:
        raise NotImplementedError

    @abstractmethod
    def get_cluster_resources(
        self, cluster_id: str
    ) -> List[ClusterNodeRefResourcesData]:
        raise NotImplementedError

    @abstractmethod
    def add_nodes_to_cluster(
        self, cluster_id: str, nodes_to_add: List[ClusterNodeRefData]
    ) -> List[ClusterNodeRefData]:
        raise NotImplementedError

    @abstractmethod
    def remove_node_from_cluster(self, cluster_id: str, node_id: str) -> str:
        raise NotImplementedError

    @abstractmethod
    def load_kubeconfig(self, cluster_id: str) -> str:
        raise NotImplementedError

    @abstractmethod
    def stream_logs(self, cluster_id: str) -> Iterator[ClusterEvent]:
        raise NotImplementedError
