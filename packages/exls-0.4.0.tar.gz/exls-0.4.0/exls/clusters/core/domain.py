from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import List, Optional

from pydantic import BaseModel, Field, StrictInt, StrictStr

########################################################
# Cluster Domain Object
########################################################


class ClusterNodeResources(BaseModel):
    gpu_type: StrictStr = Field(..., description="The type of the GPU")
    gpu_vendor: StrictStr = Field(..., description="The vendor of the GPU")
    gpu_count: StrictInt = Field(..., description="The count of the GPU")
    cpu_cores: StrictInt = Field(..., description="The count of the CPU cores")
    memory_gb: StrictInt = Field(..., description="The amount of memory in GB")
    storage_gb: StrictInt = Field(..., description="The amount of storage in GB")


class ClusterNodeStatus(StrEnum):
    DISCOVERING = "DISCOVERING"
    AVAILABLE = "AVAILABLE"
    ADDED = "ADDED"
    DEPLOYED = "DEPLOYED"
    FAILED = "FAILED"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_str(cls, value: str) -> ClusterNodeStatus:
        try:
            return cls(value.upper())
        except ValueError:
            return cls.UNKNOWN


class ClusterNodeRole(StrEnum):
    WORKER = "WORKER"
    CONTROL_PLANE = "CONTROL_PLANE"
    UNASSIGNED = "UNASSIGNED"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_str(cls, value: str) -> ClusterNodeRole:
        try:
            return cls(value.upper())
        except ValueError:
            return cls.UNKNOWN


class ClusterNode(BaseModel):
    id: StrictStr = Field(..., description="The ID of the node")
    role: ClusterNodeRole = Field(..., description="The role of the node")
    hostname: StrictStr = Field(..., description="The hostname of the node")
    username: StrictStr = Field(..., description="The username of the node")
    ssh_key_id: StrictStr = Field(..., description="The SSH key of the node")
    status: ClusterNodeStatus = Field(..., description="The status of the node")
    endpoint: StrictStr = Field(..., description="The endpoint of the node")
    free_resources: ClusterNodeResources = Field(
        ..., description="The free resources of the node"
    )
    occupied_resources: ClusterNodeResources = Field(
        ..., description="The occupied resources of the node"
    )

    @property
    def name(self) -> str:
        """Alias for hostname to support name-or-id resolution."""
        return self.hostname


class ClusterType(StrEnum):
    REMOTE = "REMOTE"
    ADOPTED = "ADOPTED"
    CLOUD = "CLOUD"
    DOCKER = "DOCKER"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_str(cls, value: str) -> ClusterType:
        try:
            return cls(value.upper())
        except ValueError:
            return cls.UNKNOWN


class ClusterStatus(StrEnum):
    PENDING = "PENDING"
    DEPLOYING = "DEPLOYING"
    READY = "READY"
    DELETING = "DELETING"
    FAILED = "FAILED"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_str(cls, value: str) -> ClusterStatus:
        try:
            return cls(value)
        except ValueError:
            return cls.UNKNOWN


class ClusterSummary(BaseModel):
    id: StrictStr = Field(..., description="The ID of the cluster")
    name: StrictStr = Field(..., description="The name of the cluster")
    status: ClusterStatus = Field(..., description="The status of the cluster")
    type: ClusterType = Field(..., description="The type of the cluster")
    created_at: datetime = Field(..., description="The creation date of the cluster")
    updated_at: Optional[datetime] = Field(
        ..., description="The last update date of the cluster"
    )
    owner_username: Optional[StrictStr] = Field(
        default=None, description="The username of the cluster creator"
    )
    owner_org_id: Optional[StrictStr] = Field(
        default=None, description="The organization ID of the cluster creator"
    )
    owner_org_name: Optional[StrictStr] = Field(
        default=None, description="The organization name of the cluster creator"
    )
    owner_teams: Optional[List[StrictStr]] = Field(
        default=None, description="The teams of the cluster creator"
    )
    worker_node_ids: List[StrictStr] = Field(
        default_factory=list, description="The IDs of the worker nodes"
    )
    control_plane_node_ids: List[StrictStr] = Field(
        default_factory=list, description="The IDs of the control plane nodes"
    )

    @property
    def node_count(self) -> int:
        """Total number of nodes (workers + control plane)."""
        return len(self.worker_node_ids) + len(self.control_plane_node_ids)


class Cluster(ClusterSummary):
    nodes: List[ClusterNode] = Field(..., description="The nodes of the cluster")


########################################################
# Cluster Event Domain Objects (Logs Streaming)
########################################################


class ClusterEventInvolvedObject(BaseModel):
    kind: StrictStr = Field(..., description="The kind of the involved object")
    name: StrictStr = Field(..., description="The name of the involved object")
    namespace: StrictStr = Field(
        ..., description="The namespace of the involved object"
    )


class ClusterEvent(BaseModel):
    watch_event_type: StrictStr = Field(
        ..., description="The type of the watch event (e.g. ADDED, MODIFIED)"
    )
    namespace: StrictStr = Field(..., description="The namespace of the cluster event")
    involved_object: ClusterEventInvolvedObject = Field(
        ..., description="The involved Kubernetes object"
    )
    type: Optional[StrictStr] = Field(
        default=None, description="The event type (e.g. Normal, Warning)"
    )
    reason: Optional[StrictStr] = Field(
        default=None, description="The reason for the event"
    )
    message: Optional[StrictStr] = Field(default=None, description="The event message")
    timestamp: Optional[datetime] = Field(
        default=None, description="The timestamp of the event"
    )
