from pathlib import Path
from typing import Iterator, List, Optional

import typer

from exls.clusters.adapters.bundle import ClustersBundle
from exls.clusters.adapters.ui.display.render import (
    CLUSTER_DETAIL_VIEW,
    CLUSTER_LIST_VIEW,
    CLUSTER_LOG_TEXT_VIEW,
    CLUSTER_NODE_ISSUE_VIEW,
    CLUSTER_NODE_LIST_VIEW,
    CLUSTER_NODE_RESOURCES_VIEW,
    CLUSTER_WITH_NODES_VIEW,
)
from exls.clusters.adapters.ui.flows.add_nodes import (
    AddNodesFlow,
    FlowAddNodesRequestDTO,
)
from exls.clusters.adapters.ui.flows.cluster_deploy import (
    DeployClusterFlow,
    FlowDeployClusterRequestDTO,
)
from exls.clusters.adapters.ui.flows.remove_nodes import (
    FlowRemoveNodesRequestDTO,
    RemoveNodesFlow,
)
from exls.clusters.core.domain import (
    Cluster,
    ClusterEvent,
    ClusterNode,
    ClusterStatus,
    ClusterSummary,
    ClusterType,
)
from exls.clusters.core.requests import ClusterDeployRequest
from exls.clusters.core.results import ClusterScaleResult, DeployClusterResult
from exls.clusters.core.service import ClustersService
from exls.shared.adapters.decorators import handle_application_layer_errors
from exls.shared.adapters.ui.facade.facade import IOBaseModelFacade
from exls.shared.adapters.ui.flow.flow import FlowContext
from exls.shared.adapters.ui.output.values import OutputFormat
from exls.shared.adapters.ui.utils import (
    called_with_any_user_input,
    get_app_state_from_ctx,
    get_config_from_ctx,
    help_if_no_subcommand,
)
from exls.shared.core.resolver import (
    AmbiguousResourceError,
    ResourceNotFoundError,
    resolve_resource_id,
)
from exls.shared.core.utils import (
    generate_random_name,
    validate_kubernetes_name,
)

clusters_app = typer.Typer()


def _get_bundle(ctx: typer.Context) -> ClustersBundle:
    """Helper to instantiate the ClustersBundle from the context."""
    return ClustersBundle(get_config_from_ctx(ctx), get_app_state_from_ctx(ctx))


def _resolve_cluster_id_callback(ctx: typer.Context, value: str) -> str:
    """
    Callback to resolve a cluster name or ID to a cluster ID.
    Fetches all clusters and matches the name/ID.
    """
    try:
        bundle: ClustersBundle = _get_bundle(ctx)
        service: ClustersService = bundle.get_clusters_service()
        clusters: List[ClusterSummary] = service.list_clusters()
        return resolve_resource_id(clusters, value, "cluster")
    except (ResourceNotFoundError, AmbiguousResourceError) as e:
        raise typer.BadParameter(str(e))


@clusters_app.callback(invoke_without_command=True)
def _root(  # pyright: ignore[reportUnusedFunction]
    ctx: typer.Context,
):
    """
    Manage clusters.
    """
    help_if_no_subcommand(ctx)


@clusters_app.command("list", help="List clusters")
@handle_application_layer_errors(ClustersBundle)
def list_clusters(
    ctx: typer.Context,
    status: Optional[ClusterStatus] = typer.Option(
        None,
        "--status",
        help="Filter clusters by status",
    ),
):
    """
    List all clusters.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    clusters_domain: List[ClusterSummary] = service.list_clusters(status=status)

    if len(clusters_domain) == 0:
        io_facade.display_info_message(
            "No clusters found. Run 'exls clusters deploy' to deploy a cluster.",
            bundle.message_output_format,
        )
    else:
        io_facade.display_data(
            clusters_domain,
            bundle.object_output_format,
            view_context=CLUSTER_LIST_VIEW,
        )


@clusters_app.command("get", help="Get cluster details")
@handle_application_layer_errors(ClustersBundle)
def get_cluster(
    ctx: typer.Context,
    cluster_id: str = typer.Argument(
        ...,
        help="The name or ID of the cluster to get",
        metavar="CLUSTER_NAME_OR_ID",
        callback=_resolve_cluster_id_callback,
    ),
):
    """
    Get a cluster.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    cluster_domain: Cluster = service.get_cluster(cluster_id)

    io_facade.display_data(
        cluster_domain,
        bundle.object_output_format,
        view_context=CLUSTER_DETAIL_VIEW,
    )


@clusters_app.command("delete", help="Delete a cluster")
@handle_application_layer_errors(ClustersBundle)
def delete_cluster(
    ctx: typer.Context,
    cluster_id: str = typer.Argument(
        ...,
        help="The name or ID of the cluster to delete",
        metavar="CLUSTER_NAME_OR_ID",
        callback=_resolve_cluster_id_callback,
    ),
    confirmation: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Confirm the deletion of the cluster. If not provided, you will be asked for confirmation.",
    ),
):
    """
    Delete a cluster.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    cluster_domain: Cluster = service.get_cluster(cluster_id)

    if not confirmation:
        io_facade.display_data(
            cluster_domain,
            bundle.object_output_format,
            view_context=CLUSTER_LIST_VIEW,
        )
        user_confirmation: bool = io_facade.ask_confirm(
            message="Are you sure you want to delete this cluster?"
        )
        if not user_confirmation:
            raise typer.Exit()

    service.delete_cluster(cluster_id)

    io_facade.display_success_message(
        f"Cluster '{cluster_domain.name}' deleted successfully.",
        bundle.message_output_format,
    )


def _validate_worker_node_ids(value: Optional[List[str]]) -> Optional[List[str]]:
    if value is None:
        return None
    if len(value) == 0:
        raise typer.BadParameter("At least one worker node ID must be specified")
    return value


@clusters_app.command("deploy", help="Deploy a cluster")
@handle_application_layer_errors(ClustersBundle)
def deploy_cluster(
    ctx: typer.Context,
    name: str = typer.Option(
        generate_random_name(prefix="exls-cluster"),
        "--name",
        "-n",
        help="The name of the cluster. If not provided, a random name will be generated.",
        show_default=False,
        callback=validate_kubernetes_name,
    ),
    worker_node_ids: Optional[List[str]] = typer.Option(
        None,
        "--worker-nodes",
        help="The IDs of the worker nodes to add to the cluster.",
        show_default=False,
        callback=_validate_worker_node_ids,
    ),
    enable_multinode_training: bool = typer.Option(
        False,
        "--enable-multinode-training",
        help="Enable multinode AI model training for the cluster",
    ),
    prepare_llm_inference_environment: bool = typer.Option(
        False,
        "--prepare-llm-inference-environment",
        help="Prepare LLM inference environment for the cluster",
    ),
    enable_telemetry: bool = typer.Option(
        False,
        "--enable-telemetry",
        help="Enable telemetry for the cluster",
    ),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        help="Enable interactive mode to create the cluster",
    ),
    follow: bool = typer.Option(
        False,
        "--follow",
        "-f",
        help="Stream cluster logs after deployment starts",
    ),
):
    """
    Create a cluster.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    deploy_cluster_request: ClusterDeployRequest
    if interactive or not called_with_any_user_input(ctx):
        cluster_deploy_request_dto: FlowDeployClusterRequestDTO = (
            FlowDeployClusterRequestDTO()
        )
        deploy_cluster_flow: DeployClusterFlow = bundle.get_deploy_cluster_flow()
        deploy_cluster_flow.execute(
            cluster_deploy_request_dto, FlowContext(), io_facade
        )
        deploy_cluster_request = ClusterDeployRequest(
            name=cluster_deploy_request_dto.name,
            type=ClusterType.from_str(cluster_deploy_request_dto.cluster_type.value),
            worker_nodes=[
                node.id for node in cluster_deploy_request_dto.worker_node_ids
            ],
            control_plane_nodes=[],
            enable_multinode_training=cluster_deploy_request_dto.enable_multinode_training,
            prepare_llm_inference_environment=cluster_deploy_request_dto.prepare_llm_inference_environment,
            enable_telemetry=cluster_deploy_request_dto.enable_telemetry,
            enable_vpn=False,
        )
    else:
        deploy_cluster_request = ClusterDeployRequest(
            name=name,
            type=ClusterType.REMOTE,
            worker_nodes=[node for node in worker_node_ids or []],
            enable_multinode_training=enable_multinode_training,
            prepare_llm_inference_environment=prepare_llm_inference_environment,
            enable_telemetry=enable_telemetry,
            enable_vpn=False,
        )
    result: DeployClusterResult = service.deploy_cluster(deploy_cluster_request)

    # Handle success and error cases
    # Case success: all nodes were added to the cluster, cluster deployment started
    if result.is_success:
        assert result.deployed_cluster is not None
        io_facade.display_success_message(
            message=f"Started deploying cluster {result.deployed_cluster.name}.",
            output_format=bundle.message_output_format,
        )
        io_facade.display_data(
            data=result.deployed_cluster,
            output_format=bundle.object_output_format,
            view_context=CLUSTER_WITH_NODES_VIEW,
        )
    # Case partially successful: not all nodes were added to the cluster
    # cluster deployment started with nodes that were successfully added
    elif result.is_partially_successful:
        assert result.deployed_cluster is not None
        io_facade.display_info_message(
            message=f"Started deploying cluster {result.deployed_cluster.name} with some issues.",
            output_format=bundle.message_output_format,
        )
        io_facade.display_data(
            data=result.deployed_cluster,
            output_format=bundle.object_output_format,
            view_context=CLUSTER_LIST_VIEW,
        )
        io_facade.display_error_message(
            message="Following nodes could not be added to the cluster:",
            output_format=bundle.message_output_format,
        )
        io_facade.display_data(
            data=result.issues,
            output_format=bundle.object_output_format,
            view_context=CLUSTER_NODE_ISSUE_VIEW,
        )
    # Case error: no nodes were added to the cluster
    # cluster deployment cannot be started
    else:
        io_facade.display_error_message(
            message="Failed to deploy cluster. The selected nodes cannot be added to the cluster:",
            output_format=bundle.message_output_format,
        )
        io_facade.display_data(
            data=result.issues,
            output_format=bundle.object_output_format,
            view_context=CLUSTER_NODE_ISSUE_VIEW,
        )

    if follow and result.is_success:
        assert result.deployed_cluster is not None
        events: Iterator[ClusterEvent] = service.stream_cluster_logs(
            cluster_id=result.deployed_cluster.id
        )
        io_facade.display_stream(
            stream=events,
            output_format=bundle.object_output_format,
            view_context=CLUSTER_LOG_TEXT_VIEW,
            header=f"Streaming logs for cluster {result.deployed_cluster.name}...",
        )


@clusters_app.command("list-nodes", help="List nodes of a cluster")
@handle_application_layer_errors(ClustersBundle)
def list_nodes(
    ctx: typer.Context,
    cluster_id: str = typer.Argument(
        "",
        help="The name or ID of the cluster to list nodes of",
        metavar="CLUSTER_NAME_OR_ID",
        callback=_resolve_cluster_id_callback,
    ),
):
    """
    List all nodes of a cluster.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    cluster: Cluster = service.get_cluster(cluster_id)

    io_facade.display_info_message(
        message=f"Nodes of cluster '{cluster.name}':",
        output_format=bundle.message_output_format,
    )
    io_facade.display_data(
        data=cluster.nodes,
        output_format=bundle.object_output_format,
        view_context=CLUSTER_NODE_LIST_VIEW,
    )


@clusters_app.command("add-nodes", help="Add nodes to a cluster")
@handle_application_layer_errors(ClustersBundle)
def add_nodes(
    ctx: typer.Context,
    cluster_id: str = typer.Argument(
        ...,
        help="The name or ID of the cluster to add nodes to",
        metavar="CLUSTER_NAME_OR_ID",
        callback=_resolve_cluster_id_callback,
    ),
    node_names_or_ids: List[str] = typer.Option(
        [],
        "--nodes",
        help="The names or IDs of the worker nodes to add to the cluster.",
        show_default=False,
    ),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        help="Enable interactive mode to add nodes to the cluster",
    ),
):
    """
    Add nodes to a cluster.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    if interactive or not node_names_or_ids:
        flow_model: FlowAddNodesRequestDTO = FlowAddNodesRequestDTO()
        flow: AddNodesFlow = AddNodesFlow(service=service, cluster_id=cluster_id)
        flow.execute(flow_model, FlowContext(), io_facade)
        node_names_or_ids = [node.id for node in flow_model.worker_node_ids]

    available_nodes: List[ClusterNode] = service.list_available_nodes()
    resolved_node_ids: List[str] = [
        resolve_resource_id(available_nodes, name_or_id, "node")
        for name_or_id in node_names_or_ids
    ]

    cluster: Cluster = service.get_cluster(cluster_id)

    resolved_nodes: List[ClusterNode] = [
        node for node in available_nodes if node.id in resolved_node_ids
    ]
    io_facade.display_data(
        data=resolved_nodes,
        output_format=bundle.object_output_format,
        view_context=CLUSTER_NODE_LIST_VIEW,
    )
    if not io_facade.ask_confirm(
        message=f"Add {len(resolved_node_ids)} node(s) to cluster '{cluster.name}'?"
    ):
        raise typer.Exit()

    scale_result: ClusterScaleResult = service.scale_up_cluster(
        cluster_id=cluster_id,
        node_ids=resolved_node_ids,
    )

    if scale_result.issues:
        io_facade.display_error_message(
            message="Some nodes could not be added:",
            output_format=bundle.message_output_format,
        )
        io_facade.display_data(
            data=scale_result.issues,
            output_format=bundle.object_output_format,
            view_context=CLUSTER_NODE_ISSUE_VIEW,
        )

    if scale_result.nodes:
        added_node_names: str = ", ".join(node.hostname for node in scale_result.nodes)
        io_facade.display_success_message(
            message=f"Following nodes added to cluster '{cluster.name}' successfully: {added_node_names}.",
            output_format=bundle.message_output_format,
        )


@clusters_app.command("remove-nodes", help="Remove nodes from a cluster")
@handle_application_layer_errors(ClustersBundle)
def remove_nodes(
    ctx: typer.Context,
    cluster_id: str = typer.Argument(
        ...,
        help="The name or ID of the cluster to remove nodes from",
        metavar="CLUSTER_NAME_OR_ID",
        callback=_resolve_cluster_id_callback,
    ),
    node_names_or_ids: List[str] = typer.Option(
        [],
        "--nodes",
        help="The names or IDs of the nodes to remove from the cluster.",
        show_default=False,
    ),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        help="Enable interactive mode to remove nodes from the cluster",
    ),
):
    """
    Remove nodes from a cluster.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    if interactive or not node_names_or_ids:
        flow_model: FlowRemoveNodesRequestDTO = FlowRemoveNodesRequestDTO()
        flow: RemoveNodesFlow = RemoveNodesFlow(service=service, cluster_id=cluster_id)
        flow.execute(flow_model, FlowContext(), io_facade)
        node_names_or_ids = [node.id for node in flow_model.nodes_to_remove]

    cluster: Cluster = service.get_cluster(cluster_id)

    # Resolve node names/IDs within this cluster
    resolved_node_ids: List[str] = [
        resolve_resource_id(cluster.nodes, node_name_or_id, "node")
        for node_name_or_id in node_names_or_ids
    ]

    resolved_nodes: List[ClusterNode] = [
        node for node in cluster.nodes if node.id in resolved_node_ids
    ]
    io_facade.display_data(
        data=resolved_nodes,
        output_format=bundle.object_output_format,
        view_context=CLUSTER_NODE_LIST_VIEW,
    )
    if not io_facade.ask_confirm(
        message=f"Remove {len(resolved_node_ids)} node(s) from cluster '{cluster.name}'?"
    ):
        raise typer.Exit()

    scale_result: ClusterScaleResult = service.remove_nodes_from_cluster(
        cluster_id=cluster_id,
        node_ids=resolved_node_ids,
    )

    if scale_result.issues:
        io_facade.display_error_message(
            message="Some nodes could not be removed:",
            output_format=bundle.message_output_format,
        )
        io_facade.display_data(
            data=scale_result.issues,
            output_format=bundle.object_output_format,
            view_context=CLUSTER_NODE_ISSUE_VIEW,
        )

    if scale_result.nodes:
        removed_node_names: str = ", ".join(
            node.hostname for node in scale_result.nodes
        )
        io_facade.display_success_message(
            message=f"Following nodes removed from cluster '{cluster.name}' successfully: {removed_node_names}.",
            output_format=bundle.message_output_format,
        )


@clusters_app.command(
    "show-available-resources", help="Show available resources of a cluster"
)
@handle_application_layer_errors(ClustersBundle)
def get_cluster_resources(
    ctx: typer.Context,
    cluster_id: str = typer.Argument(
        ...,
        help="The name or ID of the cluster to get resources of",
        metavar="CLUSTER_NAME_OR_ID",
        callback=_resolve_cluster_id_callback,
    ),
):
    """
    Get the resources of a cluster.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    cluster: Cluster = service.get_cluster(cluster_id=cluster_id)

    io_facade.display_info_message(
        message=f"Available resources of cluster '{cluster.name}':",
        output_format=bundle.message_output_format,
    )
    io_facade.display_data(
        data=cluster.nodes,
        output_format=bundle.object_output_format,
        view_context=CLUSTER_NODE_RESOURCES_VIEW,
    )


@clusters_app.command("import-kubeconfig", help="Import kubeconfig for a cluster")
@handle_application_layer_errors(ClustersBundle)
def import_kubeconfig(
    ctx: typer.Context,
    cluster_id: str = typer.Argument(
        ...,
        help="The name or ID of the cluster to import the kubeconfig to",
        metavar="CLUSTER_NAME_OR_ID",
        callback=_resolve_cluster_id_callback,
    ),
    kubeconfig_path: str = typer.Option(
        Path.home().joinpath(".kube", "config").as_posix(),
        "--kubeconfig-path",
        help="The path to the kubeconfig file to import",
    ),
):
    """
    Import a kubeconfig file into a cluster.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    cluster: Cluster = service.get_cluster(cluster_id)

    service.import_kubeconfig(cluster_id, kubeconfig_path)

    io_facade.display_success_message(
        message=f"Kubeconfig from cluster '{cluster.name}' successfully imported to {kubeconfig_path}.",
        output_format=bundle.message_output_format,
    )


@clusters_app.command("logs", help="Stream cluster logs")
@handle_application_layer_errors(ClustersBundle)
def cluster_logs(
    ctx: typer.Context,
    cluster_id: str = typer.Argument(
        ...,
        help="The name or ID of the cluster to stream logs for",
        metavar="CLUSTER_NAME_OR_ID",
        callback=_resolve_cluster_id_callback,
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw NDJSON instead of formatted display",
    ),
):
    """
    Stream real-time Kubernetes events for a cluster.
    """
    bundle: ClustersBundle = _get_bundle(ctx)
    io_facade: IOBaseModelFacade = bundle.get_io_facade()
    service: ClustersService = bundle.get_clusters_service()

    cluster: Cluster = service.get_cluster(cluster_id)
    events: Iterator[ClusterEvent] = service.stream_cluster_logs(cluster_id)

    io_facade.display_stream(
        stream=events,
        output_format=OutputFormat.JSON if json_output else OutputFormat.TEXT,
        view_context=CLUSTER_LOG_TEXT_VIEW,
        header=f"Streaming logs for cluster {cluster.name}...",
    )
