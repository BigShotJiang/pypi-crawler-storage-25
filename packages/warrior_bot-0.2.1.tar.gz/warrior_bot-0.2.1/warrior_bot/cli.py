"""CLI entry point using Click."""

import click
from colorama import Fore, Style

from warrior_bot.commands import book, go, help, where

BANNER = (
    Fore.GREEN
    + r"""
██╗    ██╗ █████╗ ██████╗ ██████╗ ██╗ ██████╗ ██████╗      ██████╗  ██████╗ ████████╗
██║    ██║██╔══██╗██╔══██╗██╔══██╗██║██╔═══██╗██╔══██╗     ██╔══██╗██╔═══██╗╚══██╔══╝
██║ █╗ ██║███████║██████╔╝██████╔╝██║██║   ██║██████╔╝     ██████╔╝██║   ██║   ██║
██║███╗██║██╔══██║██╔══██╗██╔══██╗██║██║   ██║██╔══██╗     ██╔══██╗██║   ██║   ██║
╚███╔███╔╝██║  ██║██║  ██║██║  ██║██║╚██████╔╝██║  ██║     ██████╔╝╚██████╔╝   ██║
 ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝ ╚═════╝ ╚═╝  ╚═╝     ╚═════╝  ╚═════╝    ╚═╝
"""
    + Style.RESET_ALL
)


class BannerGroup(click.Group):
    def format_help(self, ctx, formatter):
        click.echo(BANNER)
        super().format_help(ctx, formatter)


@click.group(cls=BannerGroup)
def cli():
    """Your campus companion for navigating Warrior life."""
    pass


# Register commands
cli.add_command(go.go)
cli.add_command(where.where)
cli.add_command(book.book)
cli.add_command(help.help)
