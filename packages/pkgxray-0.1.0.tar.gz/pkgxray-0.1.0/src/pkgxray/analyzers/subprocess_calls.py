"""Analizador de patrones de ejecución de comandos del sistema operativo."""

import ast
from typing import List

from pkgxray.analyzers.base import BaseAnalyzer, Finding, Severity

_SUBPROCESS_ATTRS = {
    "run": Severity.HIGH,
    "call": Severity.HIGH,
    "Popen": Severity.CRITICAL,
    "check_output": Severity.HIGH,
    "check_call": Severity.HIGH,
}

_OS_ATTRS = {
    "system": Severity.CRITICAL,
    "popen": Severity.CRITICAL,
    "execvp": Severity.CRITICAL,
    "execv": Severity.CRITICAL,
}


class SubprocessAnalyzer(BaseAnalyzer):
    name = "subprocess"
    description = "Detecta ejecución de comandos del sistema operativo"

    def analyze(self, source_code: str, filename: str) -> List[Finding]:
        """Analiza el código fuente en busca de patrones de ejecución de subprocess y os."""
        tree = self._parse_ast(source_code)
        if tree is None:
            return []

        lines = source_code.splitlines()
        findings = []

        for node in ast.walk(tree):
            # import subprocess
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == "subprocess":
                        snippet = lines[node.lineno - 1].strip()[:200] if node.lineno <= len(lines) else ""
                        findings.append(Finding(
                            severity=Severity.MEDIUM,
                            description="Se detectó importación del módulo 'subprocess'",
                            filename=filename,
                            line_number=node.lineno,
                            code_snippet=snippet,
                            analyzer_name=self.name,
                        ))

            elif isinstance(node, ast.ImportFrom):
                if node.module == "subprocess":
                    snippet = lines[node.lineno - 1].strip()[:200] if node.lineno <= len(lines) else ""
                    findings.append(Finding(
                        severity=Severity.MEDIUM,
                        description="Se detectó importación desde el módulo 'subprocess'",
                        filename=filename,
                        line_number=node.lineno,
                        code_snippet=snippet,
                        analyzer_name=self.name,
                    ))

            elif isinstance(node, ast.Call):
                func = node.func
                if not isinstance(func, ast.Attribute):
                    continue

                line_num = node.lineno
                snippet = lines[line_num - 1].strip()[:200] if line_num <= len(lines) else ""

                # subprocess.run/call/Popen/etc.
                if isinstance(func.value, ast.Name) and func.value.id == "subprocess":
                    if func.attr in _SUBPROCESS_ATTRS:
                        findings.append(Finding(
                            severity=_SUBPROCESS_ATTRS[func.attr],
                            description=f"Se detectó llamada a subprocess.{func.attr}() — ejecuta comandos del sistema",
                            filename=filename,
                            line_number=line_num,
                            code_snippet=snippet,
                            analyzer_name=self.name,
                        ))

                # os.system/popen/execvp/execv
                elif isinstance(func.value, ast.Name) and func.value.id == "os":
                    if func.attr in _OS_ATTRS:
                        findings.append(Finding(
                            severity=_OS_ATTRS[func.attr],
                            description=f"Se detectó llamada a os.{func.attr}() — ejecuta comandos del sistema",
                            filename=filename,
                            line_number=line_num,
                            code_snippet=snippet,
                            analyzer_name=self.name,
                        ))

        return findings
