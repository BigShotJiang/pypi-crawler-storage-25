"""Modelos de datos base y analizador abstracto para pkgxray."""

import ast
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Severity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Finding:
    severity: Severity
    description: str
    filename: str
    line_number: int
    code_snippet: str
    analyzer_name: str


class BaseAnalyzer(ABC):
    name: str = ""
    description: str = ""

    @abstractmethod
    def analyze(self, source_code: str, filename: str) -> list:
        """Analiza el código fuente y retorna una lista de objetos Finding."""
        ...

    def _parse_ast(self, source_code: str):
        """Parsea el código fuente a un AST; retorna None si falla."""
        try:
            return ast.parse(source_code)
        except SyntaxError:
            return None
        except Exception:
            return None


@dataclass
class ExtractedFile:
    filename: str
    content: str
    is_setup: bool = False


@dataclass
class ScanResult:
    package_name: str
    version: str
    scan_date: str
    findings: list
    risk_score: int
    risk_level: str
    files_analyzed: int
    summary: dict
