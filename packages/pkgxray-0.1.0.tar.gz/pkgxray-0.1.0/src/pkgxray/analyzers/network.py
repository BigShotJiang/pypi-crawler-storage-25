"""Analizador de patrones de conexiones de red y solicitudes HTTP."""

import ast
from typing import List

from pkgxray.analyzers.base import BaseAnalyzer, Finding, Severity

_SUSPICIOUS_IMPORT_MODULES = {
    "socket", "urllib", "urllib.request", "http.client",
    "requests", "httpx", "aiohttp",
}

_HIGH_CALL_ATTRS = {
    "connect", "create_connection",  # socket
    "urlopen",                        # urllib.request
    "get", "post", "put", "delete",  # requests / httpx
}


class NetworkAnalyzer(BaseAnalyzer):
    name = "network"
    description = "Detecta conexiones de red y solicitudes HTTP"

    def analyze(self, source_code: str, filename: str) -> List[Finding]:
        """Analiza el código fuente en busca de patrones de red."""
        tree = self._parse_ast(source_code)
        if tree is None:
            return []

        lines = source_code.splitlines()
        findings = []

        for node in ast.walk(tree):
            # A) Importaciones sospechosas de módulos de red
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name in _SUSPICIOUS_IMPORT_MODULES or alias.name.split(".")[0] in _SUSPICIOUS_IMPORT_MODULES:
                        snippet = lines[node.lineno - 1].strip()[:200] if node.lineno <= len(lines) else ""
                        findings.append(Finding(
                            severity=Severity.MEDIUM,
                            description=f"Se detectó importación del módulo de red '{alias.name}'",
                            filename=filename,
                            line_number=node.lineno,
                            code_snippet=snippet,
                            analyzer_name=self.name,
                        ))

            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                if module in _SUSPICIOUS_IMPORT_MODULES or module.split(".")[0] in _SUSPICIOUS_IMPORT_MODULES:
                    snippet = lines[node.lineno - 1].strip()[:200] if node.lineno <= len(lines) else ""
                    findings.append(Finding(
                        severity=Severity.MEDIUM,
                        description=f"Se detectó importación desde el módulo de red '{module}'",
                        filename=filename,
                        line_number=node.lineno,
                        code_snippet=snippet,
                        analyzer_name=self.name,
                    ))

            # B) Llamadas directas a funciones de red
            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Attribute) and func.attr in _HIGH_CALL_ATTRS:
                    snippet = lines[node.lineno - 1].strip()[:200] if node.lineno <= len(lines) else ""
                    findings.append(Finding(
                        severity=Severity.HIGH,
                        description=f"Se detectó llamada de red '{func.attr}()'",
                        filename=filename,
                        line_number=node.lineno,
                        code_snippet=snippet,
                        analyzer_name=self.name,
                    ))

        return findings
