"""Sistema de puntuación de riesgo para los resultados de escaneo de pkgxray."""

from typing import List, Tuple

from pkgxray.analyzers.base import Finding, Severity

SEVERITY_WEIGHTS = {
    Severity.LOW: 1,
    Severity.MEDIUM: 3,
    Severity.HIGH: 7,
    Severity.CRITICAL: 15,
}


def calculate_risk_score(findings: List[Finding]) -> Tuple[int, str]:
    """Calcula un puntaje de riesgo de 0 a 100 a partir de una lista de hallazgos.

    Args:
        findings: Lista de objetos Finding producidos por los analizadores.

    Returns:
        Tupla (puntaje, nivel) donde nivel es uno de:
        "LOW", "MODERATE", "HIGH", "CRITICAL".
    """
    if not findings:
        return 0, "LOW"

    total_weight = sum(SEVERITY_WEIGHTS.get(f.severity, 0) for f in findings)
    score = min(100, total_weight)

    if score <= 20:
        level = "LOW"
    elif score <= 40:
        level = "MODERATE"
    elif score <= 70:
        level = "HIGH"
    else:
        level = "CRITICAL"

    return score, level


def get_summary(findings: List[Finding]) -> dict:
    """Cuenta los hallazgos por nivel de severidad.

    Args:
        findings: Lista de objetos Finding.

    Returns:
        Diccionario con conteos por severidad y un total, p. ej.:
        {"low": 2, "medium": 5, "high": 1, "critical": 0, "total": 8}
    """
    summary = {"low": 0, "medium": 0, "high": 0, "critical": 0, "total": 0}
    for f in findings:
        key = f.severity.value
        if key in summary:
            summary[key] += 1
    summary["total"] = len(findings)
    return summary
