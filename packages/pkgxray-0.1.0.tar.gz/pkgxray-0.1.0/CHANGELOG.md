# Registro de cambios

Todos los cambios notables de este proyecto se documentan en este archivo.

## [0.1.0] - 2025-04-14

### Agregado
- Primera versión de pkgxray
- 8 analizadores de seguridad basados en AST:
  - `code_exec`: Detecta ejecución dinámica de código (eval, exec, compile)
  - `network`: Detecta conexiones de red y solicitudes HTTP
  - `filesystem`: Detecta accesos sospechosos al sistema de archivos
  - `env_access`: Detecta accesos a variables de entorno
  - `subprocess`: Detecta ejecución de comandos del sistema operativo
  - `obfuscation`: Detecta técnicas de ofuscación de código
  - `setup_scripts`: Detecta patrones peligrosos en archivos setup.py
  - `dynamic_imports`: Detecta importaciones dinámicas de módulos
- Descargador de paquetes PyPI (sin instalación)
- Extractor de archivos para formatos .tar.gz y .whl
- Sistema de puntuación de riesgo (escala 0-100)
- Reportes en formato terminal, JSON y HTML
- Interfaz de línea de comandos basada en Click
- Soporte para Docker
