"""Tests for SubprocessAnalyzer."""

from pkgxray.analyzers.subprocess_calls import SubprocessAnalyzer
from pkgxray.analyzers.base import Severity


def test_detects_subprocess_run():
    analyzer = SubprocessAnalyzer()
    findings = analyzer.analyze('import subprocess\nsubprocess.run(["ls"])', 'test.py')
    high = [f for f in findings if f.severity == Severity.HIGH and "run" in f.description]
    assert len(high) >= 1


def test_detects_subprocess_popen():
    analyzer = SubprocessAnalyzer()
    findings = analyzer.analyze('import subprocess\nsubprocess.Popen(["bash"])', 'test.py')
    critical = [f for f in findings if f.severity == Severity.CRITICAL]
    assert len(critical) >= 1


def test_detects_os_system():
    analyzer = SubprocessAnalyzer()
    findings = analyzer.analyze('import os\nos.system("rm -rf /")', 'test.py')
    critical = [f for f in findings if f.severity == Severity.CRITICAL and "system" in f.description]
    assert len(critical) >= 1


def test_detects_import_subprocess():
    analyzer = SubprocessAnalyzer()
    findings = analyzer.analyze('import subprocess', 'test.py')
    medium = [f for f in findings if f.severity == Severity.MEDIUM]
    assert len(medium) >= 1


def test_safe_code_no_subprocess():
    analyzer = SubprocessAnalyzer()
    findings = analyzer.analyze('x = 1 + 2\nprint(x)', 'test.py')
    assert len(findings) == 0


def test_syntax_error_no_crash():
    analyzer = SubprocessAnalyzer()
    findings = analyzer.analyze('def broken(:\n  pass', 'test.py')
    assert isinstance(findings, list)


def test_analyzer_name():
    analyzer = SubprocessAnalyzer()
    findings = analyzer.analyze('import subprocess', 'test.py')
    assert all(f.analyzer_name == "subprocess" for f in findings)
