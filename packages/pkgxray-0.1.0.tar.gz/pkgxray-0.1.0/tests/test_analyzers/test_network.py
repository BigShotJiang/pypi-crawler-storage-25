"""Tests for NetworkAnalyzer."""

from pkgxray.analyzers.network import NetworkAnalyzer
from pkgxray.analyzers.base import Severity


def test_detects_import_socket():
    analyzer = NetworkAnalyzer()
    findings = analyzer.analyze('import socket', 'test.py')
    assert len(findings) >= 1
    assert any(f.severity == Severity.MEDIUM for f in findings)


def test_detects_requests_get():
    analyzer = NetworkAnalyzer()
    findings = analyzer.analyze('import requests\nrequests.get("http://example.com")', 'test.py')
    high_findings = [f for f in findings if f.severity == Severity.HIGH]
    assert len(high_findings) >= 1


def test_detects_import_requests():
    analyzer = NetworkAnalyzer()
    findings = analyzer.analyze('import requests', 'test.py')
    assert len(findings) >= 1


def test_detects_urllib():
    analyzer = NetworkAnalyzer()
    findings = analyzer.analyze('import urllib.request', 'test.py')
    assert len(findings) >= 1


def test_safe_code_no_findings():
    analyzer = NetworkAnalyzer()
    findings = analyzer.analyze('x = 1 + 2\nprint(x)', 'test.py')
    assert len(findings) == 0


def test_syntax_error_no_crash():
    analyzer = NetworkAnalyzer()
    findings = analyzer.analyze('def broken(:\n  pass', 'test.py')
    assert isinstance(findings, list)


def test_analyzer_name():
    analyzer = NetworkAnalyzer()
    findings = analyzer.analyze('import socket', 'test.py')
    assert findings[0].analyzer_name == "network"
