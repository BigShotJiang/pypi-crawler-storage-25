# viso-sdk-python

**viso-sdk-python** is a Python SDK providing shared utilities for [viso.ai](https://viso.ai) edge containers. It covers logging, Redis/MQTT communication, model fetching, ROI handling, detection structures, and more.

Licensed under [LGPLv3](https://www.gnu.org/licenses/lgpl-3.0.html).

---

## Requirements

- **Python** >= 3.6
- **System library**: `libmagic1` (required by the `model` module)

```shell
apt-get install libmagic1
```

---

## Installation

```shell
pip install viso-sdk-python
```

---

## Modules

| Module | Description |
|---|---|
| `viso_sdk.constants` | Shared constants and environment-driven configuration |
| `viso_sdk.model` | Model fetching, extraction, and type detection |
| `viso_sdk.logging` | Centralised logger factory |
| `viso_sdk.redis` | Redis stream wrapper and cleanup utilities |
| `viso_sdk.mqtt` | MQTT client wrapper |
| `viso_sdk.roi` | Region-of-interest helpers |
| `viso_sdk.detection` | Detection result structures |
| `viso_sdk.edge` | Edge device utilities |
| `viso_sdk.status` | Container status reporting |
| `viso_sdk.nodered` | Node-RED integration helpers |

---

## Usage Examples

### Redis Communication

```python
from viso_sdk.redis import RedisWrapper, VisoData

# Initialize Redis wrapper
redis = RedisWrapper(host="localhost", port=6379)

# Write data
redis.write_data("my_key", {"status": "active"})

# Read data
data = redis.read_viso_data("my_key")
```

### MQTT Messaging

```python
from viso_sdk.mqtt import MqttWrapper

# Initialize MQTT client
mqtt = MqttWrapper()

# Publish message
mqtt.publish(topic="device/status", message='{"state": "online"}')
```

### Logging

```python
from viso_sdk.logging import get_logger

logger = get_logger("MyModule")
logger.info("Application started")
logger.error("An error occurred")
```

---

## Contributing

Contributions are welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup, testing guidelines, and CI pipeline information.

---

## License

Licensed under [LGPLv3](https://www.gnu.org/licenses/lgpl-3.0.html).