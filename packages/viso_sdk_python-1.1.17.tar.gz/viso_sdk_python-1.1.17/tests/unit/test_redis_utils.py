# -*- coding: utf-8 -*-
"""Tests for viso_sdk.redis.utils"""
import numpy as np
import pytest

from viso_sdk.redis.utils import (
    Encoder,
    base64_to_img,
    gen_redis_key_local,
    gen_redis_key_status,
    img_to_str,
    resize,
    str_to_img,
)


@pytest.fixture
def sample_image():
    img = np.zeros((100, 200, 3), dtype=np.uint8)
    img[10:20, 10:20] = 128
    return img


class TestKeyGeneration:
    def test_gen_redis_key_local_contains_node_and_port(self):
        key = gen_redis_key_local(node_id="abc123", port=2)
        assert "abc123" in key
        assert "2" in key

    def test_gen_redis_key_local_different_ports_differ(self):
        k0 = gen_redis_key_local(node_id="n1", port=0)
        k1 = gen_redis_key_local(node_id="n1", port=1)
        assert k0 != k1

    def test_gen_redis_key_status_contains_node(self):
        key = gen_redis_key_status(node_id="abc123")
        assert "abc123" in key


class TestImgToStrAndBack:
    def test_jpg_roundtrip(self, sample_image):
        encoded = img_to_str(sample_image, encoder=Encoder.JPG, with_base64=False)
        assert encoded is not None
        decoded = str_to_img(encoded, encoder=Encoder.JPG, with_base64=False)
        assert decoded is not None
        assert decoded.shape == sample_image.shape

    def test_jpg_base64_roundtrip(self, sample_image):
        encoded = img_to_str(sample_image, encoder=Encoder.JPG, with_base64=True)
        assert encoded is not None
        decoded = str_to_img(encoded, encoder=Encoder.JPG, with_base64=True)
        assert decoded is not None
        assert decoded.shape == sample_image.shape

    def test_bmp_roundtrip(self, sample_image):
        encoded = img_to_str(sample_image, encoder=Encoder.BMP, with_base64=False)
        assert encoded is not None
        decoded = str_to_img(encoded, encoder=Encoder.BMP, with_base64=False)
        assert decoded is not None
        assert decoded.shape == sample_image.shape

    def test_encoder_none_roundtrip_no_crash(self, sample_image):
        # Regression: encoder=None previously raised UnicodeDecodeError
        encoded = img_to_str(sample_image, encoder=None, with_base64=False)
        assert encoded is not None
        decoded = str_to_img(encoded, encoder=None, with_base64=False)
        assert decoded is not None

    def test_encoder_none_base64_roundtrip_no_crash(self, sample_image):
        # Regression: encoder=None + with_base64=True previously raised
        encoded = img_to_str(sample_image, encoder=None, with_base64=True)
        assert encoded is not None
        decoded = str_to_img(encoded, encoder=None, with_base64=True)
        assert decoded is not None

    def test_invalid_encoder_returns_none(self, sample_image):
        result = img_to_str(sample_image, encoder=".gif")
        assert result is None

    def test_none_raw_bytes_preserved(self, sample_image):
        # encoder=None should preserve the raw byte content
        encoded = img_to_str(sample_image, encoder=None, with_base64=False)
        decoded = str_to_img(encoded, encoder=None, with_base64=False)
        assert np.array_equal(decoded, sample_image.flatten())


class TestBase64ToImg:
    def test_roundtrip_via_base64(self, sample_image):
        import base64
        import cv2
        _, buf = cv2.imencode(Encoder.JPG, sample_image)
        b64 = base64.b64encode(buf.tobytes())
        result = base64_to_img(b64)
        assert result is not None
        assert result.shape == sample_image.shape

    def test_invalid_input_returns_none(self):
        result = base64_to_img(b"not-valid-base64!!!")
        assert result is None


class TestResize:
    def test_zoom_halves_dimensions(self, sample_image):
        result = resize(sample_image, zoom=0.5)
        assert result.shape[0] == 50
        assert result.shape[1] == 100

    def test_resize_to_target_size(self, sample_image):
        # size=(width, height)
        result = resize(sample_image, size=(50, 25))
        assert result.shape[1] == 50
        assert result.shape[0] == 25

    def test_no_resize_when_already_correct_size(self, sample_image):
        # Regression: (h, w) == [h, w] was always False (tuple vs list)
        # sample_image is (100, 200, 3) → size=(200, 100)
        original_id = id(sample_image)
        result = resize(sample_image, size=(200, 100))
        assert result is not None
        assert result.shape[:2] == (100, 200)

    def test_none_image_returns_none(self):
        assert resize(None) is None

    def test_no_op_returns_original(self, sample_image):
        result = resize(sample_image, zoom=1.0)
        assert result.shape == sample_image.shape
