# -*- coding: utf-8 -*-
"""Tests for viso_sdk.redis.stream_cleanup"""
from unittest.mock import MagicMock, patch

import pytest

from viso_sdk.redis.stream_cleanup import StreamCleanupManager, clear_stream_redis_keys


def _make_flow(nodes: dict):
    """Build a minimal mock VisoFlow with a _nodes dict."""
    flow = MagicMock()
    flow._nodes = nodes
    return flow


def _make_redis(scan_results=None):
    """Build a mock RedisWrapper."""
    rw = MagicMock()
    rw.scan_keys.return_value = scan_results or []
    rw.delete_many.return_value = 0
    return rw


NODE_A = {"id": "node-a", "wires": [["node-b"]]}
NODE_B = {"id": "node-b", "wires": [["node-c"]]}
NODE_C = {"id": "node-c", "wires": []}


class TestDiscoverDownstreamNodes:
    def test_single_downstream(self):
        flow = _make_flow({"node-b": NODE_B, "node-c": NODE_C})
        manager = StreamCleanupManager(
            redis_wrapper=_make_redis(),
            nodered_flow=flow,
            node_config=NODE_A,
            redis_out_key="redis_node-a_1",
        )
        result = manager._discover_downstream_nodes(NODE_A, set())
        node_ids = [n["node_id"] for n in result]
        assert "node-b" in node_ids

    def test_chain_discovers_all(self):
        flow = _make_flow({"node-b": NODE_B, "node-c": NODE_C})
        manager = StreamCleanupManager(
            redis_wrapper=_make_redis(),
            nodered_flow=flow,
            node_config=NODE_A,
            redis_out_key="redis_node-a_1",
        )
        result = manager._discover_downstream_nodes(NODE_A, set())
        node_ids = [n["node_id"] for n in result]
        assert "node-b" in node_ids
        assert "node-c" in node_ids

    def test_cycle_does_not_loop_forever(self):
        node_x = {"id": "x", "wires": [["y"]]}
        node_y = {"id": "y", "wires": [["x"]]}
        flow = _make_flow({"x": node_x, "y": node_y})
        manager = StreamCleanupManager(
            redis_wrapper=_make_redis(),
            nodered_flow=flow,
            node_config=node_x,
            redis_out_key="redis_x_1",
        )
        result = manager._discover_downstream_nodes(node_x, set())
        assert len(result) >= 1

    def test_leaf_node_returns_empty(self):
        flow = _make_flow({})
        manager = StreamCleanupManager(
            redis_wrapper=_make_redis(),
            nodered_flow=flow,
            node_config=NODE_C,
            redis_out_key="redis_node-c_1",
        )
        result = manager._discover_downstream_nodes(NODE_C, set())
        assert result == []


class TestCollectStreamRedisKeys:
    def test_always_includes_redis_out_key(self):
        rw = _make_redis(scan_results=[])
        manager = StreamCleanupManager(
            redis_wrapper=rw,
            nodered_flow=_make_flow({}),
            node_config=NODE_C,
            redis_out_key="redis_node-c_1",
        )
        keys = manager._collect_stream_redis_keys()
        assert "redis_node-c_1" in keys

    def test_scan_called_for_current_and_downstream_nodes(self):
        rw = _make_redis(scan_results=["redis_node-a_1"])
        flow = _make_flow({"node-b": NODE_B, "node-c": NODE_C})
        manager = StreamCleanupManager(
            redis_wrapper=rw,
            nodered_flow=flow,
            node_config=NODE_A,
            redis_out_key="redis_node-a_1",
        )
        manager._collect_stream_redis_keys()
        patterns_called = [call[0][0] if call[0] else call[1].get('pattern', '') 
                          for call in rw.scan_keys.call_args_list]
        assert any("node-a" in p for p in patterns_called)
        assert any("node-b" in p for p in patterns_called)

    def test_no_duplicate_keys(self):
        rw = _make_redis(scan_results=["redis_node-a_1", "redis_node-a_1"])
        manager = StreamCleanupManager(
            redis_wrapper=rw,
            nodered_flow=_make_flow({}),
            node_config=NODE_A,
            redis_out_key="redis_node-a_1",
        )
        keys = manager._collect_stream_redis_keys()
        assert len(keys) == len(set(keys))


class TestClearStreamKeys:
    def test_calls_delete_many(self):
        rw = _make_redis(scan_results=["redis_node-a_1"])
        rw.delete_many.return_value = 1
        manager = StreamCleanupManager(
            redis_wrapper=rw,
            nodered_flow=_make_flow({}),
            node_config=NODE_A,
            redis_out_key="redis_node-a_1",
        )
        result = manager.clear_stream_keys()
        assert result is True
        rw.delete_many.assert_called_once()

    def test_idempotent_second_call_skips(self):
        rw = _make_redis()
        manager = StreamCleanupManager(
            redis_wrapper=rw,
            nodered_flow=_make_flow({}),
            node_config=NODE_A,
            redis_out_key="redis_node-a_1",
        )
        manager.clear_stream_keys()
        manager.clear_stream_keys()
        assert rw.delete_many.call_count == 1

    def test_reset_flag_allows_re_run(self):
        rw = _make_redis()
        manager = StreamCleanupManager(
            redis_wrapper=rw,
            nodered_flow=_make_flow({}),
            node_config=NODE_A,
            redis_out_key="redis_node-a_1",
        )
        manager.clear_stream_keys()
        manager.reset_cleanup_flag()
        manager.clear_stream_keys()
        assert rw.delete_many.call_count == 2

    def test_exception_returns_false(self):
        rw = _make_redis()
        rw.scan_keys.side_effect = RuntimeError("redis down")
        manager = StreamCleanupManager(
            redis_wrapper=rw,
            nodered_flow=_make_flow({}),
            node_config=NODE_A,
            redis_out_key="redis_node-a_1",
        )
        result = manager.clear_stream_keys()
        assert result is False


class TestClearStreamRedisKeysConvenienceFunction:
    def test_delegates_to_manager(self):
        rw = _make_redis(scan_results=["redis_node-a_1"])
        rw.delete_many.return_value = 1
        result = clear_stream_redis_keys(
            redis_wrapper=rw,
            nodered_flow=_make_flow({}),
            node_config=NODE_A,
            redis_out_key="redis_node-a_1",
        )
        assert result is True
        rw.delete_many.assert_called_once()
