# -*- coding: utf-8 -*-
"""Tests for viso_sdk.redis.redis_wrapper"""
import json
from unittest.mock import MagicMock, patch

import pytest

from viso_sdk.redis.redis_wrapper import RedisWrapper


@pytest.fixture
def mock_client():
    return MagicMock()


@pytest.fixture
def wrapper(mock_client):
    with patch("viso_sdk.redis.redis_wrapper.redis.StrictRedis", return_value=mock_client):
        rw = RedisWrapper(thread=False)
    return rw, mock_client


class TestWriteData:
    def test_write_string(self, wrapper):
        rw, client = wrapper
        client.set.return_value = True
        result = rw.write_data("my_key", "hello")
        assert result is True
        client.set.assert_called_once_with("my_key", "hello", ex=None)

    def test_write_dict_serialised_as_json(self, wrapper):
        rw, client = wrapper
        client.set.return_value = True
        rw.write_data("my_key", {"a": 1, "b": 2})
        call_args = client.set.call_args[0]
        assert json.loads(call_args[1]) == {"a": 1, "b": 2}

    def test_write_with_ttl(self, wrapper):
        rw, client = wrapper
        client.set.return_value = True
        rw.write_data("my_key", "val", ttl=60)
        client.set.assert_called_once_with("my_key", "val", ex=60)


class TestReadData:
    def test_returns_raw_bytes(self, wrapper):
        rw, client = wrapper
        client.get.return_value = b"raw"
        assert rw.read_data("key") == b"raw"
        client.get.assert_called_once_with("key")

    def test_returns_none_when_key_missing(self, wrapper):
        rw, client = wrapper
        client.get.return_value = None
        assert rw.read_data("missing") is None


class TestReadVisoData:
    def test_decodes_json_bytes(self, wrapper):
        rw, client = wrapper
        client.get.return_value = b'{"result": [1, 2]}'
        result = rw.read_viso_data("key")
        assert result == {"result": [1, 2]}

    def test_returns_none_on_redis_error(self, wrapper):
        rw, client = wrapper
        client.get.side_effect = Exception("connection refused")
        result = rw.read_viso_data("key")
        assert result is None


class TestDeleteData:
    def test_delete_returns_true_on_success(self, wrapper):
        rw, client = wrapper
        client.delete.return_value = 1
        assert rw.delete_data("key") is True
        client.delete.assert_called_once_with("key")

    def test_delete_returns_false_when_key_not_found(self, wrapper):
        rw, client = wrapper
        client.delete.return_value = 0
        assert rw.delete_data("missing") is False


class TestWriteVisoData:
    def test_sync_write_when_thread_disabled(self, wrapper):
        rw, client = wrapper
        client.set.return_value = True
        result = rw.write_viso_data({"frame": None}, "key")
        assert result is True

    def test_write_none_deletes_key(self, wrapper):
        rw, client = wrapper
        client.delete.return_value = 1
        rw.write_viso_data(None, "key")
        client.delete.assert_called_once_with("key")
