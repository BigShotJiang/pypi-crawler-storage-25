# -*- coding: utf-8 -*-
"""Tests for viso_sdk.redis.viso_data"""
import time

import pytest

from viso_sdk.redis.viso_data import Meta, MetaFrameFormat, MetaModule, MetaSource, VisoData

NODE = {"id": "node-1", "type": "object-detection", "name": "OD Node"}


class TestMetaSource:
    def test_init_with_node_sets_fields(self):
        src = MetaSource(src_node=NODE, src_output_port=0)
        assert src.id == "node-1"
        assert src.type == "object-detection"
        assert src.name == "OD Node"
        assert src.source_key == "node-1_0"
        assert src.output_port_idx == 0

    def test_init_without_node_leaves_none(self):
        src = MetaSource()
        assert src.id is None
        assert src.type is None

    def test_to_dict_returns_dict_with_id(self):
        src = MetaSource(src_node=NODE, src_output_port=1)
        d = src.to_dict()
        assert isinstance(d, dict)
        assert d["id"] == "node-1"
        assert d["source_key"] == "node-1_1"

    def test_update_sets_new_values(self):
        src = MetaSource(src_node=NODE, src_output_port=0)
        src.update({"frame_id": 42})
        assert src.frame_id == 42

    def test_update_ignores_none_values(self):
        src = MetaSource(src_node=NODE, src_output_port=0)
        original_id = src.id
        src.update({"id": None})
        assert src.id == original_id


class TestMetaModule:
    def test_init_with_node(self):
        mod = MetaModule(cur_node=NODE, feed_port_idx=2)
        assert mod.id == "node-1"
        assert mod.type == "object-detection"
        assert mod.feed_port_idx == 2

    def test_init_without_node(self):
        mod = MetaModule()
        assert mod.id is None

    def test_to_dict(self):
        mod = MetaModule(cur_node=NODE, feed_port_idx=0)
        d = mod.to_dict()
        assert d["id"] == "node-1"


class TestMeta:
    def test_to_dict_uses_stored_ts_not_fresh_time(self):
        # Regression: to_dict() was calling time.time() instead of using self.ts
        meta = Meta(cur_node=NODE, feed_idx=0, src_node=NODE, src_port=0, src_name=None)
        stored_ts = meta.ts
        d = meta.to_dict()
        assert d["ts"] == stored_ts

    def test_to_dict_has_required_keys(self):
        meta = Meta(cur_node=NODE, feed_idx=0, src_node=NODE, src_port=0, src_name=None)
        d = meta.to_dict()
        for key in ("ts", "source", "module", "frame_format"):
            assert key in d

    def test_ts_is_set_at_construction_time(self):
        t_before = time.time()
        meta = Meta(cur_node=NODE, feed_idx=0, src_node=NODE, src_port=0, src_name=None)
        t_after = time.time()
        assert t_before <= meta.ts <= t_after


class TestVisoData:
    def test_create_without_frame_returns_none_frame(self):
        vd = VisoData(feed_idx=0, cur_node=NODE, src_node=NODE, src_port=0)
        payload = vd.create_viso_data(result=[{"label": "car"}])
        assert payload["frame"] is None
        assert payload["result"] == [{"label": "car"}]
        assert "meta" in payload

    def test_create_empty_result_defaults_to_list(self):
        vd = VisoData(feed_idx=0, cur_node=NODE, src_node=NODE, src_port=0)
        payload = vd.create_viso_data()
        assert payload["result"] == []

    def test_parse_bytes_payload(self):
        import json
        vd = VisoData(feed_idx=0, cur_node=NODE, src_node=NODE, src_port=0)
        raw = json.dumps({
            "meta": {"source": {"id": "node-1"}, "frame_format": {"encoder": None, "with_base64": False}},
            "frame": None,
            "result": [1, 2, 3],
        }).encode()
        result = vd.parse_viso_data(raw, version=1)
        assert result["frame"] is None
        assert result["result"] == [1, 2, 3]
