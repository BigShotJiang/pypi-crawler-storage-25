"""Unit tests for TraceMallocManager."""
import pytest
from viso_sdk.debug import TraceMallocManager


class TestTraceMallocManagerDisabled:
    """Tests for TraceMallocManager with debug=False (production mode)."""

    def test_init_debug_false(self):
        """Test initialization with debug=False."""
        tm = TraceMallocManager(debug=False)
        assert tm.debug is False
        assert tm._first_tm_snapshot is None
        assert tm._last_tm_snapshot is None

    def test_tracemalloc_check_returns_true(self):
        """Test that tracemalloc_check returns True in production mode."""
        tm = TraceMallocManager(debug=False)
        result = tm.tracemalloc_check()
        assert result is True

    def test_stop_is_safe(self):
        """Test that stop() is safe to call when debug=False."""
        tm = TraceMallocManager(debug=False)
        tm.stop()  # Should not raise


class TestTraceMallocManagerEnabled:
    """Tests for TraceMallocManager with debug=True."""

    def test_init_debug_true(self):
        """Test initialization with debug=True starts tracing."""
        tm = TraceMallocManager(debug=True)
        try:
            assert tm.debug is True
            assert tm._first_tm_snapshot is not None
            assert tm._last_tm_snapshot is None
        finally:
            tm.stop()

    def test_tracemalloc_check_updates_snapshot(self):
        """Test that tracemalloc_check updates last snapshot."""
        tm = TraceMallocManager(debug=True)
        try:
            assert tm._last_tm_snapshot is None
            
            tm.tracemalloc_check()
            
            assert tm._last_tm_snapshot is not None
        finally:
            tm.stop()

    def test_multiple_checks_compare_snapshots(self):
        """Test that multiple checks create comparisons."""
        tm = TraceMallocManager(limit=5, debug=True)
        try:
            # First check
            tm.tracemalloc_check()
            first_snapshot = tm._last_tm_snapshot
            
            # Allocate memory
            _data = bytearray(1024 * 1024)  # 1MB
            
            # Second check
            tm.tracemalloc_check()
            second_snapshot = tm._last_tm_snapshot
            
            # Snapshots should be different
            assert first_snapshot is not second_snapshot
            
            del _data
        finally:
            tm.stop()

    def test_custom_limit(self):
        """Test that custom limit is respected."""
        tm = TraceMallocManager(limit=3, debug=True)
        try:
            assert tm._limit == 3
        finally:
            tm.stop()

    def test_stop_ends_tracing(self):
        """Test that stop() properly ends tracing."""
        tm = TraceMallocManager(debug=True)
        tm.stop()
        # After stop, taking another snapshot should not interfere
        # (though we can't directly test this without internal tracemalloc state)


class TestTraceMallocManagerMethods:
    """Tests for individual TraceMallocManager methods."""

    def test_display_top_trace_scripts(self):
        """Test display_top_trace_scripts doesn't crash."""
        tm = TraceMallocManager(limit=5, debug=True)
        try:
            tm.tracemalloc_check()  # Take a snapshot
            # Method logs output, just verify it doesn't crash
            import tracemalloc
            snapshot = tracemalloc.take_snapshot()
            tm.display_top_trace_scripts(snapshot)
        finally:
            tm.stop()

    def test_compare_snapshots_with_no_baseline(self):
        """Test compare_snapshots when no prior snapshots exist."""
        tm = TraceMallocManager(debug=False)
        import tracemalloc
        
        # Create a dummy snapshot (won't be used since debug=False)
        # This tests that compare_snapshots handles missing baselines
        try:
            tracemalloc.start()
            snapshot = tracemalloc.take_snapshot()
            
            # Should not crash with None snapshots
            tm.compare_snapshots(snapshot)
        finally:
            tracemalloc.stop()

    def test_compare_snapshots_with_baselines(self):
        """Test compare_snapshots with actual baselines."""
        tm = TraceMallocManager(debug=True)
        try:
            # First check creates baseline
            tm.tracemalloc_check()
            
            # Allocate memory
            _data = bytearray(512 * 1024)  # 512KB
            
            # Second check compares
            import tracemalloc
            cur_snapshot = tracemalloc.take_snapshot()
            tm.compare_snapshots(cur_snapshot)
            
            del _data
        finally:
            tm.stop()


class TestTraceMallocManagerWithCustomLogger:
    """Tests for TraceMallocManager with custom logger."""

    def test_custom_logger(self):
        """Test initialization with custom logger."""
        import logging
        custom_logger = logging.getLogger("custom_test")
        
        tm = TraceMallocManager(logger=custom_logger, debug=False)
        assert tm.logger is custom_logger

    def test_default_logger(self):
        """Test that default logger is created correctly."""
        tm = TraceMallocManager(debug=False)
        assert tm.logger is not None
        assert tm.logger.name == "tracemalloc"
