# -*- coding: utf-8 -*-
"""Tests for viso_sdk.model.fetch"""
import io
import tarfile
import tempfile
from unittest.mock import patch

import pytest
import responses as resp_lib

from viso_sdk.model.fetch import (
    _safe_extract,
    download_file,
    get_device_token,
    get_model_url,
)


class TestGetDeviceToken:
    def test_returns_token_from_file(self, tmp_path):
        token_file = tmp_path / ".token"
        token_file.write_text("my-secret-token\n", encoding="utf-8")
        with patch("viso_sdk.model.fetch.TOKEN_FILE", str(token_file)):
            assert get_device_token() == "my-secret-token"

    def test_strips_newline(self, tmp_path):
        token_file = tmp_path / ".token"
        token_file.write_text("tok\n", encoding="utf-8")
        with patch("viso_sdk.model.fetch.TOKEN_FILE", str(token_file)):
            assert get_device_token() == "tok"

    def test_returns_none_when_file_missing(self, tmp_path):
        with patch("viso_sdk.model.fetch.TOKEN_FILE", str(tmp_path / ".missing")):
            assert get_device_token() is None


class TestGetModelUrl:
    def test_http_url_returned_directly(self):
        url = "https://example.com/model.tar.xz"
        assert get_model_url(url) == url

    def test_https_url_returned_directly(self):
        url = "https://storage.example.com/model.tar.xz?token=abc"
        assert get_model_url(url) == url

    def test_returns_none_when_no_token(self, tmp_path):
        with patch("viso_sdk.model.fetch.TOKEN_FILE", str(tmp_path / ".missing")):
            result = get_model_url("some-model-key")
        assert result is None

    @resp_lib.activate
    def test_resolves_model_key_to_url(self, tmp_path):
        token_file = tmp_path / ".token"
        token_file.write_text("mytoken", encoding="utf-8")
        expected = "https://storage.example.com/model.tar.xz"
        with patch("viso_sdk.model.fetch.TOKEN_FILE", str(token_file)):
            with patch("viso_sdk.model.fetch.MODEL_URL",
                       "http://api.example.com/model-url?key=<MODEL_KEY>"):
                resp_lib.add(
                    resp_lib.GET,
                    "http://api.example.com/model-url?key=test-key",
                    json={"url": expected},
                    status=200,
                )
                result = get_model_url("test-key")
        assert result == expected

    @resp_lib.activate
    def test_returns_none_on_non_200(self, tmp_path):
        token_file = tmp_path / ".token"
        token_file.write_text("mytoken", encoding="utf-8")
        with patch("viso_sdk.model.fetch.TOKEN_FILE", str(token_file)):
            with patch("viso_sdk.model.fetch.MODEL_URL",
                       "http://api.example.com/model-url?key=<MODEL_KEY>"):
                resp_lib.add(
                    resp_lib.GET,
                    "http://api.example.com/model-url?key=bad",
                    status=403,
                )
                result = get_model_url("bad")
        assert result is None


class TestDownloadFile:
    @resp_lib.activate
    def test_writes_content_to_file(self, tmp_path):
        content = b"fake tar content"
        resp_lib.add(resp_lib.GET, "http://example.com/model.tar.xz",
                     body=content, status=200)
        local_file = tmp_path / "model.tar.xz"
        result = download_file("http://example.com/model.tar.xz", str(local_file))
        assert result is True
        assert local_file.read_bytes() == content

    @resp_lib.activate
    def test_returns_false_on_non_200(self, tmp_path):
        resp_lib.add(resp_lib.GET, "http://example.com/model.tar.xz", status=404)
        local_file = tmp_path / "model.tar.xz"
        result = download_file("http://example.com/model.tar.xz", str(local_file))
        assert result is False
        # Regression: file must NOT be written with error body on failure
        assert not local_file.exists()


class TestSafeExtract:
    def test_extracts_normal_archive(self, tmp_path):
        src = tmp_path / "data.txt"
        src.write_text("hello")
        tar_path = tmp_path / "archive.tar"
        with tarfile.open(str(tar_path), "w") as tf:
            tf.add(str(src), arcname="data.txt")

        extract_dir = tmp_path / "out"
        extract_dir.mkdir()
        with tarfile.open(str(tar_path)) as tf:
            _safe_extract(tf, str(extract_dir))

        assert (extract_dir / "data.txt").read_text() == "hello"

    def test_raises_on_path_traversal(self, tmp_path):
        tar_path = tmp_path / "evil.tar"
        with tarfile.open(str(tar_path), "w") as tf:
            info = tarfile.TarInfo(name="../../evil.txt")
            info.size = 5
            tf.addfile(info, io.BytesIO(b"pwned"))

        extract_dir = tmp_path / "out"
        extract_dir.mkdir()
        with tarfile.open(str(tar_path)) as tf:
            with pytest.raises(Exception, match="path traversal"):
                _safe_extract(tf, str(extract_dir))

    def test_extracts_nested_directories(self, tmp_path):
        src = tmp_path / "subdir" / "nested.txt"
        src.parent.mkdir()
        src.write_text("nested content")
        tar_path = tmp_path / "archive.tar"
        with tarfile.open(str(tar_path), "w") as tf:
            tf.add(str(src), arcname="subdir/nested.txt")

        extract_dir = tmp_path / "out"
        extract_dir.mkdir()
        with tarfile.open(str(tar_path)) as tf:
            _safe_extract(tf, str(extract_dir))

        assert (extract_dir / "subdir" / "nested.txt").read_text() == "nested content"
