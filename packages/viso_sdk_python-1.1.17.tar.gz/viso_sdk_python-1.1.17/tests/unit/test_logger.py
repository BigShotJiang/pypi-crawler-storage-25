# -*- coding: utf-8 -*-
"""Tests for viso_sdk.logging.logger"""
import logging

import pytest

from viso_sdk.logging import get_logger, set_log_level, exception_traceback


class TestGetLogger:
    def test_returns_logger_instance(self):
        logger = get_logger("TEST_A")
        assert isinstance(logger, logging.Logger)

    def test_same_name_returns_same_object(self):
        l1 = get_logger("TEST_B")
        l2 = get_logger("TEST_B")
        assert l1 is l2

    def test_no_duplicate_handlers_on_repeated_calls(self):
        # Regression: init_logger used to clear and re-add handlers every call
        logger = get_logger("TEST_C")
        initial_count = len(logger.handlers)
        get_logger("TEST_C")
        get_logger("TEST_C")
        assert len(logger.handlers) == initial_count

    def test_different_names_are_independent(self):
        l1 = get_logger("TEST_D1")
        l2 = get_logger("TEST_D2")
        assert l1 is not l2
        assert l1.name != l2.name


class TestSetLogLevel:
    def test_all_valid_levels_accepted(self):
        for level in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
            set_log_level(level)

    def test_case_insensitive(self):
        set_log_level("info")
        set_log_level("Warning")

    def test_invalid_level_raises_value_error(self):
        with pytest.raises(ValueError, match="Invalid log level"):
            set_log_level("VERBOSE")

    def test_info_adds_console_handler(self):
        logger = get_logger("TEST_LEVEL")
        set_log_level("INFO")
        handler_types = [type(h) for h in logger.handlers]
        assert logging.StreamHandler in handler_types

    def test_warning_removes_console_handler(self):
        logger = get_logger("TEST_LEVEL")
        set_log_level("INFO")   # ensure console handler exists first
        set_log_level("WARNING")
        for h in logger.handlers:
            from logging.handlers import RotatingFileHandler
            assert isinstance(h, RotatingFileHandler)


class TestExceptionTraceback:
    def test_does_not_raise(self):
        logger = get_logger("TEST_TRACEBACK")
        try:
            raise ValueError("test error")
        except ValueError as e:
            exception_traceback(logger, e)

    def test_logs_exception_type_and_message(self, caplog):
        logger = get_logger("TEST_TRACEBACK_MSG")
        with caplog.at_level(logging.ERROR, logger="TEST_TRACEBACK_MSG"):
            try:
                raise RuntimeError("something went wrong")
            except RuntimeError as e:
                exception_traceback(logger, e)
        assert "RuntimeError" in caplog.text
        assert "something went wrong" in caplog.text
