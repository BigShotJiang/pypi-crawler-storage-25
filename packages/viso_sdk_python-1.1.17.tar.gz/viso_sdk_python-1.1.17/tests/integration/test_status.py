# -*- coding: utf-8 -*-
#
# Copyright (C) 2020-2023 viso.ai AG <info@viso.ai>
"""
Integration tests for the status logger (requires Redis + MQTT services).
Run via: docker-compose -f docker/docker-compose.test.yml run --rm test
"""
import json
import time

import pytest

from viso_sdk.constants import PREFIX
from viso_sdk.mqtt.mqtt_wrapper import MqttWrapper as VisoMqtt
from viso_sdk.redis.redis_wrapper import RedisWrapper as VisoRedis
from viso_sdk.status import get_status_logger

NODE_ID = "638acaf9.bf6014"
mqtt_received = False
test_error_msg = "test_error_msg"


@pytest.fixture
def status_logger():
    from viso_sdk.status.status_logger import StatusCaching
    # Use short log_interval (1 second) for faster testing instead of default 60 seconds
    sl = StatusCaching(node_id=NODE_ID, node_name="", node_type="object-detection", log_interval=1)
    sl.start()
    yield sl
    sl.stop()
    sl.join(timeout=1)


@pytest.fixture
def viso_redis():
    return VisoRedis()


def on_mqtt_error_message(topic, msg):
    global mqtt_received
    mqtt_received = True
    parsed = json.loads(msg)
    assert parsed["id"] == NODE_ID
    assert parsed["type"] == "object-detection"
    assert parsed["message"] == test_error_msg


@pytest.mark.integration
def test_status_logger_writes_redis(status_logger, viso_redis: VisoRedis):
    status_logger.update_status_info(info={"fps": 5}, source_idx=3)
    time.sleep(2)

    b_status = viso_redis.read_data(redis_key=f"{PREFIX.REDIS.STATUS}_{NODE_ID}")
    assert b_status is not None
    status = json.loads(b_status.decode())

    assert status["id"] == NODE_ID
    assert len(status["fps"]) == 4
    assert status["fps"][3] == 5


@pytest.mark.integration
def test_status_logger_publishes_error_via_mqtt(status_logger):
    global mqtt_received
    mqtt_received = False

    mqtt = VisoMqtt(subscribe_topics=[f"{PREFIX.MQTT.CLOUD}_{NODE_ID}"])
    mqtt.callbacks[f"{PREFIX.MQTT.CLOUD}_{NODE_ID}"] = on_mqtt_error_message

    deadline = time.time() + 10
    while not mqtt_received and time.time() < deadline:
        status_logger.error(test_error_msg)
        time.sleep(1)

    mqtt.stop()
    mqtt.join(timeout=1)
    assert mqtt_received, "MQTT error message was never received"
