import socket

import pytest


def _is_port_open(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def pytest_collection_modifyitems(config, items):
    """Skip integration tests when Redis/MQTT are not reachable."""
    import os
    redis_host = os.environ.get("REDIS_HOST", "localhost")
    mqtt_host = os.environ.get("MQTT_HOST", "localhost")
    redis_up = _is_port_open(redis_host, 6379)
    mqtt_up = _is_port_open(mqtt_host, 1883)
    services_available = redis_up and mqtt_up

    skip_integration = pytest.mark.skip(
        reason="Integration services (Redis/MQTT) not available. "
               "Run: docker-compose -f docker/docker-compose.test.yml up -d && "
               "pytest tests/integration/"
    )
    for item in items:
        # Auto-mark tests in tests/integration/ directory
        if "/integration/" in str(item.fspath):
            item.add_marker(pytest.mark.integration)
        if "integration" in item.keywords and not services_available:
            item.add_marker(skip_integration)


@pytest.fixture(scope="session")
def fixture_dir(test_dir):
    return test_dir / "fixtures"


@pytest.fixture(scope="session")
def test_dir(pytestconfig):
    return pytestconfig.rootdir / "tests"
