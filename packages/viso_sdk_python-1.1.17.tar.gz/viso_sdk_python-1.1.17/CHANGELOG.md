# Changelog

<!--next-version-placeholder-->

## v1.1.17

### Performance Optimizations

- **`requirements.txt` / `setup.py`**: Add `orjson>=3.9.0` dependency for 30-50% faster JSON serialization
- **`status/status_logger.py`**: Replace `json` with `orjson` and eliminate duplicate serialization (serialize once per loop iteration, reuse for MQTT/Redis/logging) — reduces CPU usage by 40-60%
- **`redis/redis_wrapper.py`**: Implement Redis connection pooling with `max_connections` based on worker count for 20-40% better throughput
- **`redis/redis_wrapper.py`**: Replace `json` with `orjson` for 30-50% faster serialization/deserialization
- **`redis/utils.py`**: Optimize `img_to_str()` to return bytes directly instead of unnecessary latin-1 encode/decode cycles
- **`redis/utils.py`**: Refactor `resize()` to calculate target dimensions once and perform single resize operation (avoid double resize)

### Enhancements

- **`CONTRIBUTING.md`** (new): Add comprehensive developer documentation including setup, testing workflows (unit/integration/all), CI pipeline details, build instructions, code quality guidelines, and release checklist
- **`README.md`**: Simplify for public/production use - moved developer-specific content to CONTRIBUTING.md, added usage examples, kept only essential project information
- **`mqtt/mqtt_wrapper.py`**: Update to MQTT callback API VERSION2 (paho-mqtt 2.x) to fix deprecation warning
- **`mqtt/mqtt_wrapper.py`**: Update callback signatures for `_on_connect()` and `_on_publish()` to handle `reason_code` and `properties` parameters
- **`model/fetch.py`**: Add `filter='data'` parameter to `tar.extractall()` for Python 3.12+ compatibility with fallback for older versions
- **`tests/unit/test_trace_malloc.py`** (new): Add comprehensive unit tests for `TraceMallocManager` (13 tests covering debug on/off, snapshot management, comparison logic, custom logger support)
- **`scripts/test_tracemalloc.py`** (new): Add standalone test script for validating memory profiling functionality with 4 test scenarios

### Fix

- `logging/logger.py`: Fix ANSI escape code typo in `bold_red` (`\x1b[31a;1m` → `\x1b[31;1m`) that caused CRITICAL log
  lines to render incorrectly
- `logging/logger.py`: Fix `get_logger()` clearing and re-adding handlers on every call for the same name; now returns
  the existing logger immediately if handlers are already attached
- `redis/utils.py`: Fix `resize()` always resizing even when target size matched — tuple vs list comparison (
  `== [h, w]` → `== (h, w)`)
- `redis/utils.py`: Fix `img_to_str(encoder=None)` raising `UnicodeDecodeError` on arbitrary image bytes; raw bytes are
  now encoded/decoded with `latin-1` for a lossless round-trip
- `redis/utils.py`: Replace deprecated `np.fromstring` with `np.frombuffer` in `str_to_img`
- `redis/viso_data.py`: Fix `Meta.to_dict()` generating a fresh `time.time()` timestamp instead of returning the stored
  `self.ts`
- `redis/stream_cleanup.py`: Replace direct `_redis_client.delete()` access with the public
  `redis_wrapper.delete_data()` API

### Enhancements

- `redis/redis_wrapper.py`: Remove orphaned local variable `_img_arr = None` in `RedisWrapper.__init__`
- `setup.py` / `requirements.txt`: Add missing `python-magic` dependency to `install_requires`
- `constants/variables.py`: Centralise `TOKEN_FILE` path constant (moved from `model/fetch.py`)
- `model/fetch.py`: Add full type annotations (`Optional[str]`, `bool`, `None`) and Google-style docstrings to all
  public functions; add module-level docstring documenting consumed environment variables
- `debug/trace_malloc.py` (new): Add `viso_sdk.debug` package with `TraceMallocManager` — a `threading.Thread` subclass
  wrapping `tracemalloc` and `gc` for memory-leak diagnostics in long-running containers; fixes mutable default logger
  argument and uninitialised snapshot attributes when `debug=False`
- `logging/log_id.py` (new): Add `LogIDGenerator`, `ErrorType`, and `EventType` to `viso_sdk.logging` for structured,
  thread-safe correlation IDs across events, errors, and sessions; exported via `viso_sdk.logging` public API

## v1.1.16

### Features

- Add `StreamCleanupManager` class and `clear_stream_redis_keys()` helper to `viso_sdk.redis` for discovering and
  clearing Redis KV stores across Node-RED flow graphs
- Add `model_utils` module to `viso_sdk.detection` with `ModelArchitecture`, `YoloModelFilesInfo`, `FasterRcnnBackbone`,
  `detect_model_architecture()`, and `check_model_architecture()` utilities

### Enhancements

- `Detection.__init__`: support list-typed `roi_id`/`roi_name`, auto-normalize pixel-space bounding boxes using
  `frame_sz` parameter
- `Detection`: add `to_tlbr()` and `to_xyah()` bounding box conversion methods
- Export `StreamCleanupManager` and `clear_stream_redis_keys` in `viso_sdk.redis` public API
- Export detection utilities (`BaseDetect`, `Detection`, `filter_iou_threshold`, `filter_labels`, `ModelArchitecture`,
  etc.) in `viso_sdk.detection` public API

## v1.1.15

### fix

- Add ROI overlap detection feature to identify objects present in multiple ROIs simultaneously

## v1.1.14

### Fix

- Fix ROI assignment bug where objects retained first ROI info when moving between ROIs
- Fix staticmethod decorator conflict in `_assign_roi_info` helper method

### Enhancements

- Refactor duplicated ROI assignment code into `_assign_roi_info` static method
- Remove console handler to prevent duplicate logging to syslog/journal
- Add dynamic log level control with `set_log_level()` function
- Add `set_minimal_logging()` convenience function for boolean-based log control
- Console output now dynamically enabled only in verbose mode (INFO/DEBUG levels)
- Export `LOG_LEVEL_MAP` and `set_minimal_logging` in logging module public API
- Add comprehensive docstring to `exception_traceback` function

### Breaking Changes

- Default log level changed to WARNING (minimal logs) - use `set_minimal_logging(False)` for INFO logs
- Console/stdout logging disabled by default - only enabled when log level is INFO or DEBUG
- Logs now only written to disk files by default (not visible in `podman logs` unless verbose mode enabled)

## v1.1.13

### Enhancements

- `FlowAPIWrapper`: read `NODE_RED_HOST` env var for k8s compatibility; falls back to `127.0.0.1` when not set
- `RedisWrapper`: read `REDIS_HOST` env var for k8s compatibility; falls back to `localhost` when not set
- `MqttWrapper`: read `MQTT_HOST` env var for k8s compatibility; falls back to `127.0.0.1` when not set

## v1.1.12

### Fix

- Fix metadata update methods to handle falsy values (0, False) correctly in MetaSource, MetaModule, and MetaFrameFormat
  classes. Previously, output_port_idx=0 was being filtered out during metadata propagation.

## v1.1.11

### Enhancements

- Increase log file size to 50MB

## v1.1.10

### Enhancements

- remove visualization scripts and font
- remove pillow package

## v1.1.8

### Enhancements

- Add thread pool executors to handle redis requests
- Add redis frame TTL

## v1.1.7

### Fix

- Revert deletion of redis frames which caused issue with multiple consumers

## v1.1.6

### Fix

- Fix bug with importing nonexisted data structures

## v1.1.5

### Enhancements

- Redis frames are deleted once pulled to avoid processing twice
- New data structures have been added (RQueue) to improve performance
- Add new constant variables

## v1.1.4

### Enhancements

- add available devices in the AARCH64 architecture

## v1.1.3

### Enhancements

- remove opencv-contrib-python and update opencv-python-headless to 4.10.0

## v1.1.2

### Enhancements

- upgrade opencv version to 4.10.0

### Features

- add new modules in constants.modules
- add publish key values in the constants.constants

## v1.0.8

### Fix

- fix issue - cannot find video-feed when using video-feed-ip(usb, videofile) source

### Enhancements

- updated documents

### Features

- add new modules in constants.modules

## v1.0.7

### Fix

- inherit viso_data.meta object

## v1.0.6

### Fix

- standard TensorRT spell as lowercase() -> tensorrt

## v1.0.5

### Fix

- indicate numpy version for fixing - ImportError: numpy.core.multiarray failed to import

## v1.0.4

### Fix

- viso_data.meta.source.update() - Fix attribute error when new attribute comes

## v1.0.2

### Enhancements

- viso_data() - split into sub dataclasses MetaSource(), MetaModule(), MetaFrameFormat()

## v1.0.1

### Enhancements

- viso_data(), default version is set 1

### Features

- integrate viso_data into redis_utils

### Fix

- status_logger using new redis_utils
- redis_wrapper decoding bytes to str

## v1.0.0 = v0.2.15

## v0.2.15

### Features

- soft merge redis_meta with redis_encoding

## v0.2.14

### Enhancements

- add instance object for detection result

### Fix

- indicate proper paho-mqtt version

## v0.2.12/v0.2.13

### Enhancements

- add member functions into __init__.py (redis and mqtt)

### Fix

- remove func redis_wrapper.gen_redis_key_status()

## v0.2.11

### Enhancements

- remove pillow version

## v0.2.10

### Enhancements

- update to python3.10

## v0.2.9

### Enhancements

- more detailed visualization parameters

## v0.2.7(v0.2.8)

### Enhancements

- constants - add common keys for object tracking/recognition
- visualization:
    - add draw_tracking_objects
    - ignore empty object lists on visualization function

## v0.2.6

### Fix

- update other viz functions (vis_obj, vis_roi) using updated utils.put_text()

## v0.2.5

### Fix

- update function to calculate padding in the case of multi-line text
- add new framework TensorRT
- update utils.put_text() parameter names

## v0.2.4

### Features

- sphinx autodoc

## v0.2.3

### Features

- added drawer function for (line-type) roi objects

### Fix

- visualize.utils.put_text() - correct padding calculation
- visualize.utils.put_text() - treat multi-line text too
- visualize.utils.put_text() - added option for center align

## v0.2.2

### Features

- new declaration of modules

### Fix

- VizObj, VizRoi - missed arguments (text_color)
- update default shadow_color with pillow RGBA format(255, 0, 0, 255) = RED

## v0.2.1

### Fix

- update default shadow_color with pillow RGBA format(255, 0, 0, 255) = RED

## v0.2.0

### Features

- new declaration of modules
- added CHANGELOG.md

### Fix

- VizObj, VizRoi - missed arguments (text_color)
- alpha channel value type, float to integer

## v0.1.3

### Enhancements

- Update visualization for dynamic fonts

### Fix

- init_font() - the case of not existing font_name

## v0.1.2

### Enhancements

- upgrade opencv version to 4.6.0

### Fix

- fix font_path

## v0.1.0

### Fix

- fix color order from BGR to RGB
