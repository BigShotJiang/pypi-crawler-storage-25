import numpy as np

from .utils.nms import non_max_suppression_cv
from viso_sdk.constants import KEY


class Detection:
    """Unified detection class for object detection results.
    
    Supports initialization from direct parameters or from a dictionary.
    Handles both normalized (0-1) and pixel coordinates based on frame_sz.
    
    Args:
        class_id: Class ID of the detected object (default: -1).
        label: Label/class name of the detected object (default: '').
        score: Confidence score of the detection (default: 0.0).
        tlwh: Bounding box in [x, y, width, height] format.
        roi_id: ROI ID(s) associated with this detection (default: None).
        roi_name: ROI name(s) associated with this detection (default: None).
        det: Dictionary containing detection data (alternative to direct params).
        frame_sz: Frame size as (width, height) for coordinate conversion.
    """

    def __init__(self,
                 class_id=-1, label='', score=0.0, tlwh=None, roi_id=None, roi_name=None,
                 det=None,
                 frame_sz=None):
        if det and isinstance(det, dict):
            self.class_id = int(det.get(KEY.CLASS_ID, -1))
            self.label = str(det.get(KEY.LABEL, ''))
            self.score = float(det.get(KEY.SCORE, 0.0))
            self.roi_id = det.get(KEY.ROI_ID, [])
            self.roi_name = det.get(KEY.ROI_NAME, [])
            self.tlwh = self._get_tlwh(det.get(KEY.TLWH), frame_sz)
        else:
            self.class_id = int(class_id)
            self.label = str(label)
            self.score = float(score)
            self.roi_id = roi_id if isinstance(roi_id, list) else ([] if roi_id is None else [roi_id])
            self.roi_name = roi_name if isinstance(roi_name, list) else ([] if roi_name is None else [roi_name])
            self.tlwh = self._get_tlwh(tlwh, frame_sz)

    @staticmethod
    def _get_tlwh(tlwh, frame_sz):
        """Convert and normalize bounding box coordinates.
        
        Args:
            tlwh: Bounding box in [x, y, width, height] format.
            frame_sz: Frame size as (width, height) tuple.
        
        Returns:
            Normalized bounding box as numpy array.
        """
        if frame_sz is not None:
            frame_w, frame_h = frame_sz
        else:
            frame_w, frame_h = 1.0, 1.0

        x, y, w, h = tlwh if isinstance(tlwh, np.ndarray) else np.asarray(tlwh)

        if w < 1.0:
            xmin = max(x, 0)
            ymin = max(y, 0)
            xmax = min((x + w), 1.0)
            ymax = min((y + h), 1.0)
        else:
            xmin = max(x, 0) / frame_w
            ymin = max(y, 0) / frame_h
            xmax = min((x + w), frame_w) / frame_w
            ymax = min((y + h), frame_h) / frame_h

        return np.asarray([xmin, ymin, xmax - xmin, ymax - ymin], dtype=float)

    def to_tlbr(self):
        """Convert bounding box to format (min x, min y, max x, max y).
        
        Returns:
            Bounding box in top-left, bottom-right format.
        """
        ret = self.tlwh.copy()
        ret[2:] += ret[:2]
        return ret

    def to_xyah(self):
        """Convert bounding box to format (center x, center y, aspect ratio, height).
        
        Returns:
            Bounding box in center x, center y, aspect ratio, height format.
        """
        ret = self.tlwh.copy()
        ret[:2] += ret[2:] / 2
        ret[2] /= ret[3]
        return ret

    def to_dict(self):
        """Convert detection to dictionary format.
        
        Returns:
            Dictionary with detection information.
        """
        return {
            KEY.CLASS_ID: int(self.class_id),
            KEY.LABEL: str(self.label),
            KEY.SCORE: round(float(self.score), 2),
            KEY.TLWH: self.tlwh if isinstance(self.tlwh, list) else np.array(self.tlwh).round(3).tolist(),
            KEY.ROI_ID: self.roi_id,
            KEY.ROI_NAME: self.roi_name,
        }


def filter_iou_threshold(detections, score_threshold, iou_threshold, img_sz):
    img_w, img_h = img_sz
    scores = []
    boxes = []
    for detection in detections:
        scores.append(detection.score)
        boxes.append(np.array(detection.tlwh) * np.array([img_w, img_h, img_w, img_h]))
    indices = non_max_suppression_cv(scores=scores, boxes=boxes,
                                     score_threshold=score_threshold,
                                     iou_threshold=iou_threshold)

    # size filtering
    filtered_detections = []
    for ind in indices:
        filtered_detections.append(detections[ind])

    return filtered_detections


def filter_labels(detections, labels_to_detect):
    if labels_to_detect is not None and len(labels_to_detect) > 0:
        filtered_detections = []
        for detection in detections:
            label = detection.label
            if label in labels_to_detect:
                filtered_detections.append(detection)
        return filtered_detections
    else:
        return detections
