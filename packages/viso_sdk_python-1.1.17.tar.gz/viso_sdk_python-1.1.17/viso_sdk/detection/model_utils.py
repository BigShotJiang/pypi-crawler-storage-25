"""Model architecture detection and utility functions for object detection models.

This module provides utilities for identifying model architectures from model names
and directories, supporting various YOLO versions, DETR models, and other architectures.
"""

from typing import Optional
from viso_sdk.logging import get_logger

logger = get_logger("MODEL_UTILS")


class ModelArchitecture:
    """Constants for supported model architectures."""
    YOLOv3 = "yolov3"
    YOLOv3_TINY = "yolov3_tiny"
    YOLOv4 = "yolov4"
    YOLOv4_TINY = "yolov4_tiny"
    YOLOv5 = "yolov5"
    YOLOv6 = "yolov6"
    YOLOv7 = "yolov7"
    YOLOv8 = "yolov8"
    YOLOv9 = "yolo_v9"
    YOLOR = "yolor"
    YOLOX = "yolox"
    YOLOX_NANO = "yolox_nano"
    YOLOX_TINY = "yolox_tiny"
    YOLOX_S = "yolox_s"
    YOLOX_M = "yolox_m"
    YOLOX_L = "yolox_l"
    YOLOX_X = "yolox_x"
    VISO_PERSON_DETECTION = "viso_person_detection"
    YOLOX_MIX = "person_detection"
    FasterRCNN = "faster_rcnn"
    RT_DETR = "rtdetr"
    RF_DETR = "rfdetr"
    SSD = "ssd"
    OTHER = "other"


AVAILABLE_YOLOX_ARCHITECTURES = [
    'yolox_nano', 'yolox_tiny', 'yolox_l', 'yolox_m', 'yolox_x', 'yolox_s'
]


class YoloModelFilesInfo:
    """File extensions for YOLO model files."""
    MODEL_FILE_EXTS = [".pth", ".pt", ".weights", ".tar", ".onnx"]
    LABEL_FILE_EXTS = [".txt", ".names"]
    EXTRA_INFO_FILE_EXTS = [".json"]


class FasterRcnnBackbone:
    """Faster R-CNN backbone architectures."""
    RESNET50_FPN = "faster_rcnn_resnet50"
    RESNET101_FPN = "faster_rcnn_resnet101"


def detect_model_architecture(
        model_name: str,
        base_model: Optional[str] = None
) -> str:
    """Detect model architecture from model name and optional base model hint.
    
    Args:
        model_name: Name of the model file or directory.
        base_model: Optional hint for the base model architecture.
    
    Returns:
        Detected model architecture string.
    
    Example:
        >>> detect_model_architecture("yolov5s.pt")
        'yolov5'
        >>> detect_model_architecture("rtdetr_r50vd.pth")
        'rtdetr'
    """
    model_name_lower = model_name.lower()

    if base_model and base_model != "other":
        if base_model in [getattr(ModelArchitecture, attr) for attr in dir(ModelArchitecture)
                          if not attr.startswith('_')]:
            if base_model not in model_name_lower:
                logger.warning(
                    f"Base model '{base_model}' not found in model name '{model_name}'"
                )
            return base_model

    if 'yolor' in model_name_lower:
        return ModelArchitecture.YOLOR
    elif 'yolox' in model_name_lower:
        return ModelArchitecture.YOLOX
    elif 'yolo' in model_name_lower:
        if 'v3' in model_name_lower:
            return (ModelArchitecture.YOLOv3 if "tiny" not in model_name_lower
                    else ModelArchitecture.YOLOv3_TINY)
        elif 'v4' in model_name_lower:
            return (ModelArchitecture.YOLOv4 if "tiny" not in model_name_lower
                    else ModelArchitecture.YOLOv4_TINY)
        elif 'v5' in model_name_lower:
            return ModelArchitecture.YOLOv5
        elif 'v6' in model_name_lower:
            return ModelArchitecture.YOLOv6
        elif 'v7' in model_name_lower:
            return ModelArchitecture.YOLOv7
        elif 'v8' in model_name_lower:
            return ModelArchitecture.YOLOv8
        elif 'v9' in model_name_lower:
            return ModelArchitecture.YOLOv9
        else:
            return ModelArchitecture.OTHER
    elif 'ssd' in model_name_lower:
        return ModelArchitecture.SSD
    elif ModelArchitecture.RT_DETR in model_name_lower:
        return ModelArchitecture.RT_DETR
    elif ModelArchitecture.RF_DETR in model_name_lower:
        return ModelArchitecture.RF_DETR
    elif 'faster' in model_name_lower and 'rcnn' in model_name_lower:
        return ModelArchitecture.FasterRCNN
    else:
        logger.info(
            f"Could not detect architecture from model name '{model_name}', "
            f"defaulting to '{ModelArchitecture.OTHER}'"
        )
        return ModelArchitecture.OTHER


def check_model_architecture(
        config: dict,
        model_name: str
) -> str:
    """Check and validate model architecture from config and model name.
    
    This function validates the architecture specified in config against the
    model name and attempts to auto-detect if not specified or invalid.
    
    Args:
        config: Configuration dictionary with optional 'base_model' key.
        model_name: Name of the model file or directory.
    
    Returns:
        Validated or detected model architecture string.
    
    Example:
        >>> config = {'base_model': 'yolov5'}
        >>> check_model_architecture(config, 'yolov5s.pt')
        'yolov5'
    """
    architecture = config.get("base_model", "other")

    if not architecture:
        architecture = "other"

    if architecture not in model_name.lower():
        logger.warning(
            f"Architecture '{architecture}' not matched to model name '{model_name}'"
        )

    valid_architectures = [
        getattr(ModelArchitecture, attr)
        for attr in dir(ModelArchitecture)
        if not attr.startswith('_')
    ]

    if architecture != "other" and architecture in valid_architectures:
        return architecture
    else:
        if architecture == "other":
            logger.info(
                f"Model architecture ({architecture}) was not defined, "
                f"will try to detect from model name ({model_name})"
            )
        elif architecture not in valid_architectures:
            logger.info(
                f"Undefined model architecture '{architecture}', "
                f"will try to detect from model name ({model_name})"
            )

        return detect_model_architecture(model_name, architecture)
