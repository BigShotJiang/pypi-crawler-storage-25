"""
Viso Logging Module
"""

import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from typing import Optional
import traceback2
import inspect

from viso_sdk.constants import NODE_TYPE, LOG_DIR, LOG_SIZE

# Log level mapping
LOG_LEVEL_MAP = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING,
    'ERROR': logging.ERROR,
    'CRITICAL': logging.CRITICAL
}
FILE_LOG_LEVEL = logging.INFO


class CustomFormatter(logging.Formatter):
    """Logging Formatter to add colors and count warning / errors"""

    def __init__(self) -> None:
        super().__init__()

        grey = "\x1b[38;21m"
        yellow = "\x1b[33;21m"
        red = "\x1b[31;21m"
        bold_red = "\x1b[31;1m"
        reset = "\x1b[0m"
        _format = "%(asctime)s:: %(name)-15s :: %(levelname)-4s :: %(message)s [%(filename)s:%(lineno)d]"

        self.formats = {
            logging.DEBUG: grey + _format + reset,
            logging.INFO: grey + _format + reset,
            logging.WARNING: yellow + _format + reset,
            logging.ERROR: red + _format + reset,
            logging.CRITICAL: bold_red + _format + reset,
        }

    def format(self, record):  # type: ignore
        log_fmt = self.formats.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


class VisoLogger:
    """Viso Logger Class

    Args:
        info_file: File name of info level logs.
            Using `/viso/<NODE_TYPE>_<NODE_ID>/logs/<NODE_TYPE>.log` if not defined.
        error_file: File name of error level logs.
    """

    def __init__(
            self, info_file: Optional[str] = None, error_file: Optional[str] = None
    ) -> None:
        self._info_file = info_file or os.path.join(LOG_DIR, f"{NODE_TYPE}.log")
        self._error_file = error_file

    def init_logger(self, name: str) -> logging.Logger:
        """Initialize a logger instance.

        Args:
            name(str): Logger name
        """
        # Note: Loggers are never instantiated directly, but always through the module-level function
        # logging.getLogger(name). Multiple calls to getLogger() with the same name will always
        # return a reference to the same Logger object.
        logger = logging.getLogger(name)
        if logger.handlers:
            return logger
        logger.setLevel(logging.DEBUG)  # better to have too much log than not enough
        formatter = CustomFormatter()

        # Add file handlers
        f_info_handler = RotatingFileHandler(
            self._info_file, maxBytes=LOG_SIZE, backupCount=4
        )
        f_info_handler.setLevel(logging.WARNING)
        f_info_handler.setFormatter(formatter)
        logger.addHandler(f_info_handler)

        if self._error_file is not None:
            f_err_handler = RotatingFileHandler(
                self._error_file, maxBytes=LOG_SIZE, backupCount=4
            )
            f_err_handler.setLevel(logging.ERROR)
            f_err_handler.setFormatter(formatter)
            logger.addHandler(f_err_handler)

        return logger


def get_logger(
        name: str = "main",
        info_file: Optional[str] = None,
        error_file: Optional[str] = None,
) -> logging.Logger:
    """Generate a Viso logger instance

    Args:
        name(str): Name of the target logger
        info_file(str): Info file path(optional)
        error_file(str): Error file path(optional)
    """
    return VisoLogger(info_file, error_file).init_logger(name)


def set_log_level(level: str) -> None:
    """Dynamically set the log level for all file handlers and manage console output.
    
    Args:
        level(str): Log level - one of 'DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'
    
    Behavior:
        - INFO/DEBUG: Enables console output (visible in podman logs) + file logging
        - WARNING/ERROR/CRITICAL: Disables console output (no journal spam) + file logging only
    
    Example:
        >>> from viso_sdk.logging import set_log_level
        >>> set_log_level('INFO')  # Enable INFO logs + console output
        >>> set_log_level('WARNING')  # Back to WARNING only, no console
    """
    global FILE_LOG_LEVEL

    level_upper = level.upper()
    if level_upper not in LOG_LEVEL_MAP:
        raise ValueError(
            f"Invalid log level '{level}'. Must be one of: {', '.join(LOG_LEVEL_MAP.keys())}"
        )

    FILE_LOG_LEVEL = LOG_LEVEL_MAP[level_upper]

    # Determine if console handler should be enabled (verbose mode)
    enable_console = level_upper in ['DEBUG', 'INFO']

    # Update all existing loggers
    for logger_name in logging.Logger.manager.loggerDict:
        logger = logging.getLogger(logger_name)

        # Update file handlers
        has_console = False
        console_handler = None

        for handler in logger.handlers:
            if isinstance(handler, RotatingFileHandler):
                # Don't change ERROR-only handlers
                if handler.level != logging.ERROR:
                    handler.setLevel(FILE_LOG_LEVEL)
            elif isinstance(handler, logging.StreamHandler) and not isinstance(handler, RotatingFileHandler):
                has_console = True
                console_handler = handler

        # Add or remove console handler based on log level
        if enable_console and not has_console:
            # Add console handler for verbose mode
            formatter = CustomFormatter()
            new_console_handler = logging.StreamHandler(sys.stdout)
            new_console_handler.setFormatter(formatter)
            new_console_handler.setLevel(FILE_LOG_LEVEL)
            logger.addHandler(new_console_handler)
        elif not enable_console and has_console:
            # Remove console handler for minimal mode
            logger.removeHandler(console_handler)


def set_minimal_logging(enabled: bool) -> None:
    """Enable or disable minimal logging mode.
    
    Args:
        enabled(bool): If True, set log level to WARNING (minimal logs).
                      If False, set log level to INFO (verbose logs).
    
    Example:
        >>> from viso_sdk.logging import set_minimal_logging
        >>> set_minimal_logging(True)   # Only WARNING and above
        >>> set_minimal_logging(False)  # INFO and above
    """
    if enabled:
        set_log_level('WARNING')
    else:
        set_log_level('INFO')


def exception_traceback(logger, exception):
    """Log detailed exception information including traceback and calling method arguments.
    
    This function logs comprehensive exception details to help with debugging:
    - Exception type and message
    - Full traceback
    - Calling method name and location
    - All arguments passed to the calling method
    
    Args:
        logger: Logger instance to write error messages to
        exception: The exception object to log
    
    Example:
        >>> try:
        ...     risky_operation()
        ... except Exception as e:
        ...     exception_traceback(logger, e)
    
    Note:
        This function inspects the calling frame to extract method arguments.
        Large argument values are truncated to keep logs readable.
    """
    caller_frame = inspect.currentframe().f_back
    try:
        args, _, _, values = inspect.getargvalues(caller_frame)

        def _safe_repr(obj, limit=500):
            """Safely represent an object, truncating if too large."""
            try:
                r = repr(obj)
            except Exception:
                r = f"<unrepr-able {type(obj).__name__}>"
            return r if len(r) <= limit else r[:limit] + "... [truncated]"

        logger.error("=" * 80)
        logger.error(
            f"EXCEPTION OCCURRED IN METHOD: {caller_frame.f_code.co_name} "
            f"({caller_frame.f_code.co_filename}:{caller_frame.f_lineno})"
        )
        logger.error("-" * 40)
        logger.error("METHOD ARGUMENTS:")
        for arg in args:
            val = values.get(arg, "<missing>")
            logger.error(f"  • {arg}: {_safe_repr(val)}")
        logger.error("-" * 40)
        logger.error(f"EXCEPTION: {type(exception).__name__}: {exception}")
        logger.error("-" * 40)
        logger.error("FULL TRACEBACK:")
        tb_lines = traceback2.format_exception(type(exception), exception, exception.__traceback__)
        logger.error("".join(tb_lines))
        logger.error("=" * 80)
    finally:
        del caller_frame
