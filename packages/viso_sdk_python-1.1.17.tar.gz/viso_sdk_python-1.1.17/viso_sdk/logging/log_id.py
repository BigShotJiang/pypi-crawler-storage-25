"""
Log ID Generator Utility

Generates unique identifiers for tracking events, errors, and sessions across the logging system.
Helps with correlation, debugging, and user support.
"""

import threading
import uuid
from typing import Optional


class ErrorType:
    """Common error type tokens for consistent error ID generation."""
    FRAME_CAPTURE = "FRAME"
    REDIS_READ = "REDIS_READ"
    REDIS_WRITE = "REDIS_WRITE"
    INITIALIZATION = "INIT"
    HEALTH_CHECK = "HEALTH"
    CONNECTION = "CONN"
    CONFIGURATION = "CONFIG"
    PROCESSING = "PROC"
    DETECTION = "DETECT"
    FILTERING = "FILTER"
    QUEUE_FULL = "QUEUE_FULL"
    QUEUE_EMPTY = "QUEUE_EMPTY"
    MQTT = "MQTT"
    GENERAL = "GEN"


class EventType:
    """Common event type tokens for consistent event ID generation."""
    START = "START"
    STOP = "STOP"
    RESTART = "RESTART"
    TRIGGER = "TRIGGER"
    HEALTH_OK = "HEALTH_OK"
    METADATA_INIT = "META_INIT"
    FRAME_RECEIVED = "FRAME_RX"
    FRAME_DUPLICATE = "FRAME_DUP"
    DETECTION_COMPLETE = "DETECT_OK"
    GENERAL = "EVT"


class LogIDGenerator:
    """Generates unique log IDs for events, errors, and sessions.

    Counters are protected by a reentrant lock so this class is safe to use
    from multiple threads sharing the same instance.

    Args:
        node_id: Node/container ID string.
        source_idx: Source/stream index.
    """

    def __init__(self, node_id: str, source_idx: int):
        self.node_id = node_id
        self.source_idx = source_idx
        self._session_id: Optional[str] = None
        self._error_counter: int = 0
        self._event_counter: int = 0
        self._lock = threading.Lock()

    def generate_session_id(self, force: bool = False) -> str:
        """Generate a unique session ID for the stream lifecycle.

        The ID is cached after the first call.  Subsequent calls return the
        existing session ID unless ``force=True`` is passed.

        Format: ``SES-<node_id[:8]>-<source_idx>-<short_uuid>``

        Args:
            force: Regenerate even if a session ID already exists.

        Returns:
            Session ID string.
        """
        with self._lock:
            if self._session_id is None or force:
                short_uuid = str(uuid.uuid4())[:8]
                self._session_id = f"SES-{self.node_id[:8]}-{self.source_idx}-{short_uuid}"
            return self._session_id

    def generate_error_id(self, error_type: str = ErrorType.GENERAL) -> str:
        """Generate a unique error ID for tracking a specific error occurrence.

        Format: ``ERR-<error_type>-<node_id[:8]>-<source_idx>-<counter>``

        Args:
            error_type: Error type token, e.g. :attr:`ErrorType.FRAME_CAPTURE`.

        Returns:
            Error ID string.
        """
        with self._lock:
            self._error_counter += 1
            counter = self._error_counter
        return f"ERR-{error_type}-{self.node_id[:8]}-{self.source_idx}-{counter}"

    def generate_event_id(self, event_type: str = EventType.GENERAL) -> str:
        """Generate a unique event ID for tracking a specific event.

        Format: ``EVT-<event_type>-<node_id[:8]>-<source_idx>-<counter>``

        Args:
            event_type: Event type token, e.g. :attr:`EventType.START`.

        Returns:
            Event ID string.
        """
        with self._lock:
            self._event_counter += 1
            counter = self._event_counter
        return f"EVT-{event_type}-{self.node_id[:8]}-{self.source_idx}-{counter}"

    def get_session_id(self) -> Optional[str]:
        """Return the current session ID, or ``None`` if not yet generated."""
        return self._session_id

    @staticmethod
    def format_log_with_id(message: str, log_id: str) -> str:
        """Prepend a log ID tag to a message.

        Args:
            message: Original log message.
            log_id: Log ID string to prepend.

        Returns:
            Formatted message string.
        """
        return f"[{log_id}] {message}"

    def format_log_with_session(self, message: str) -> str:
        """Prepend the current session ID tag to a message.

        Returns the original message unchanged if no session has been started yet.

        Args:
            message: Original log message.

        Returns:
            Formatted message string.
        """
        if self._session_id:
            return f"[{self._session_id}] {message}"
        return message
