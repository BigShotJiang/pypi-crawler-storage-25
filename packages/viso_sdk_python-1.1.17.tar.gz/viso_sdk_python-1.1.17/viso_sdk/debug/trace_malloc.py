"""
Memory profiling and GC diagnostics for viso.ai containers.
"""
import copy
import gc
import linecache
import threading
import tracemalloc
from typing import Optional
import logging

from viso_sdk.logging import get_logger


class TraceMallocManager(threading.Thread):
    """Memory leak detector and GC diagnostic helper for long-running container processes.

    Wraps Python's :mod:`tracemalloc` and :mod:`gc` modules to take periodic
    memory snapshots, log the top allocation sites, and compare growth against
    both the initial and the previous snapshot.

    When ``debug=False`` (the default) the class is a no-op except for running
    ``gc.collect()`` on each :meth:`tracemalloc_check` call, so it is safe to
    leave instantiated in production.

    Args:
        limit: Number of top allocation lines to report per snapshot (default: 10).
        logger: Logger instance to use. Defaults to a new ``'tracemalloc'`` logger.
        debug: Enable full tracemalloc profiling. When ``False``, only GC collection
            is performed and no snapshots are taken (default: False).

    Example:
        >>> tm = TraceMallocManager(limit=5, debug=True)
        >>> # call periodically inside your processing loop:
        >>> tm.tracemalloc_check()
        >>> # on shutdown:
        >>> tm.stop()
    """

    def __init__(
        self,
        limit: int = 10,
        logger: Optional[logging.Logger] = None,
        debug: bool = False,
    ):
        super().__init__()

        self.logger = logger if logger is not None else get_logger('tracemalloc')
        self.debug = debug
        self._limit = limit

        self._first_tm_snapshot: Optional[tracemalloc.Snapshot] = None
        self._last_tm_snapshot: Optional[tracemalloc.Snapshot] = None

        if self.debug:
            tracemalloc.start()
            self._first_tm_snapshot = tracemalloc.take_snapshot()

    def display_top_trace_scripts(
        self,
        snapshot: tracemalloc.Snapshot,
        key_type: str = 'lineno',
    ) -> None:
        """Log the top memory-allocating lines from a tracemalloc snapshot.

        Filters out internal CPython bootstrap frames and unknown sources before
        reporting.

        Args:
            snapshot: A :class:`tracemalloc.Snapshot` to analyse.
            key_type: Grouping key passed to
                :meth:`tracemalloc.Snapshot.statistics` (default: ``'lineno'``).
        """
        snapshot = snapshot.filter_traces((
            tracemalloc.Filter(False, "<frozen importlib._bootstrap>"),
            tracemalloc.Filter(False, "<unknown>"),
        ))
        top_stats = snapshot.statistics(key_type)

        self.logger.info(f"leak.tm - Top {self._limit} lines")
        for index, stat in enumerate(top_stats[:self._limit], 1):
            frame = stat.traceback[0]
            self.logger.info(f"leak.tm -  #{index}: {frame.filename}:{frame.lineno}: {stat.size / 1024:.2f}KiB")
            line = linecache.getline(frame.filename, frame.lineno).strip()
            if line:
                self.logger.info(f'leak.tm - \t{line}')

        other = top_stats[self._limit:]
        if other:
            size = sum(stat.size for stat in other)
            self.logger.info(f"leak.tm -  {len(other)} other: {(size / 1024):.1f} KiB")
        total = sum(stat.size for stat in top_stats)
        self.logger.info(f"leak.tm -  Total allocated size: {(total / 1024):.1f} KiB")

    def compare_snapshots(self, cur_tm_snapshot: tracemalloc.Snapshot) -> None:
        """Compare a snapshot against the first and the most recent previous one.

        Logs the top 10 allocation differences for each available baseline.
        This method is a no-op if no prior snapshots exist.

        Args:
            cur_tm_snapshot: The current snapshot to diff against stored baselines.
        """
        if self._first_tm_snapshot is not None:
            self.logger.info("leak.tm - compare with first: =======================")
            top_stats = cur_tm_snapshot.compare_to(self._first_tm_snapshot, 'lineno')
            for stat in top_stats[:10]:
                self.logger.info(f"leak.tm - compare with first: {stat}")

        if self._last_tm_snapshot is not None:
            self.logger.info("leak.tm - compare with last: =======================")
            top_stats = cur_tm_snapshot.compare_to(self._last_tm_snapshot, 'lineno')
            for stat in top_stats[:10]:
                self.logger.info(f"leak.tm - compare with last: {stat}")

    def tracemalloc_check(self) -> bool:
        """Run a memory and GC diagnostic pass.

        When ``debug=True``: takes a snapshot, logs the top allocation sites,
        reports traced-memory totals, compares against stored baselines, and
        runs a full GC collection with before/after object counts.

        When ``debug=False``: runs ``gc.collect()`` only (minimal overhead).

        Returns:
            Always ``True``.
        """
        if self.debug:
            cur_tm_snapshot = tracemalloc.take_snapshot()
            self.display_top_trace_scripts(snapshot=cur_tm_snapshot)

            # tracemalloc.reset_peak()  newly released from 3.9
            tm_size, tm_peak = tracemalloc.get_traced_memory()

            self.logger.info(f"leak.tm - get_traced_memory: {tm_size}, {tm_peak}")

            self.compare_snapshots(cur_tm_snapshot=cur_tm_snapshot)
            self._last_tm_snapshot = copy.copy(cur_tm_snapshot)

            self.logger.info(f"leak.gc - get_count (before): {gc.get_count()}")
            self.logger.info(f"leak.gc - collect: {gc.collect()}")
            self.logger.info(f"leak.gc - get_count (after): {gc.get_count()}")
        else:
            # gc.get_count()
            gc.collect()

        return True

    def stop(self) -> None:
        """Stop tracemalloc tracing.

        Safe to call even when ``debug=False``; has no effect in that case.
        """
        if self.debug:
            tracemalloc.stop()
