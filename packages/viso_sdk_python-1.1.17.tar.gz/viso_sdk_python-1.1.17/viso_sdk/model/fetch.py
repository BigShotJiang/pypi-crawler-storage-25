"""Model download and extraction utilities for viso.ai containers.

Handles the full lifecycle of fetching a detection model: resolving the signed
download link from the viso.ai backend (or accepting a direct URL), streaming
the archive to disk, safe tar extraction, and basic model-type detection.

Environment variables consumed (via :mod:`viso_sdk.constants`):
    - ``SERVER_HOST``: Backend API host (default: ``https://dev.viso.ai``).
    - ``MODEL_EXIST_OK``: Skip re-download when the model directory already
      exists on disk (default: ``False``).
"""
import os
import time
import shutil
import requests
import tarfile
import json
import magic
from typing import Optional
from urllib.parse import urlparse

from viso_sdk.logging import get_logger
from viso_sdk.constants import MODEL_TYPE

from viso_sdk.constants.variables import TOKEN_FILE
from viso_sdk.constants import BASE_MODEL_DIR, MODEL_EXIST_OK, MODEL_URL

logger = get_logger("MODEL")

fm = magic.Magic(mime=False, uncompress=False)

DOWNLOAD_MODEL_TIMEOUT = 5 * 60  # sec


def get_device_token() -> Optional[str]:
    """Read the device authentication token from disk.

    The token is stored at the path defined by :data:`TOKEN_FILE` and is sent
    as a Bearer credential when calling the model-URL API.

    Returns:
        str | None: Token string with trailing newlines stripped, or ``None``
            if the file is missing or cannot be read.
    """
    try:
        with open(TOKEN_FILE, encoding="utf-8") as file_pointer:
            device_token = file_pointer.read().replace("\n", "")
        return device_token
    except FileNotFoundError:
        logger.warning(f"Token file not found at {TOKEN_FILE}")
        return None
    except Exception as e:
        logger.warning(f"Failed to read device token: {e}")
        return None


def get_model_url(model_id: str) -> Optional[str]:
    """Resolve a model identifier to a downloadable URL.

    If ``model_id`` starts with ``http``, it is returned unchanged (direct
    URL). Otherwise the viso.ai model-URL API is called using the device token.

    Args:
        model_id (str): A full HTTP/HTTPS URL, or a viso.ai model key string.

    Returns:
        str | None: The resolved download URL, or ``None`` on failure.
    """
    try:
        logger.info(f"Get the download url from model_id:{model_id}")
        if model_id.startswith("http"):
            model_url = model_id
        else:
            device_token = get_device_token()
            if device_token is None:
                logger.warning("No device token available, cannot fetch model URL")
                return None
            request_url = MODEL_URL.replace("<MODEL_KEY>", model_id)
            headers = {'x-device-token': f"Bearer {device_token}"}

            r = requests.get(request_url, headers=headers, timeout=30)
            if r.status_code != 200:
                logger.warning(f"failed to get the model url with status. {r.status_code}")
                model_url = None
            else:
                model_url = json.loads(r.content.decode('UTF-8'))["url"]

        return model_url

    except Exception as e:
        logger.warning(f"failed to get the model url {e}")
        return None


def download_detection_model(model_id: str) -> Optional[str]:
    """Download and extract a detection model, retrying until timeout.

    Resolves the model URL via :func:`get_model_url`, then downloads and
    extracts it via :func:`download_url`. Retries on any failure until
    ``DOWNLOAD_MODEL_TIMEOUT`` seconds have elapsed.

    If ``model_id`` equals :attr:`MODEL_TYPE.INTERNAL`, no network call is
    made and the value is returned as-is.

    Args:
        model_id (str): A viso.ai model key, a direct HTTP/HTTPS URL, or
            ``MODEL_TYPE.INTERNAL``.

    Returns:
        str | None: Absolute path to the extracted model directory, or
            ``None`` if the download did not succeed within the timeout.
    """
    if model_id == MODEL_TYPE.INTERNAL:
        return model_id

    s_time = time.time()

    model_dir = None
    logger.info("Download model")

    while (time.time() - s_time) < DOWNLOAD_MODEL_TIMEOUT:
        model_url = get_model_url(model_id)
        try:
            if model_url:
                model_dir = download_url(cloud_url=model_url)
            else:
                time.sleep(1)
                continue
        except Exception as e:
            logger.warning(f"Failed download viso model: {e}")
            model_dir = None

        if model_dir is not None:
            break
        else:
            time.sleep(1)

    return model_dir


def check_model_type(model_dir: str) -> Optional[str]:
    """Infer the ML framework type from the contents of a model directory.

    Inspects file extensions and sub-directory names to classify the model.
    Detection order:
    TF_YOLO → OpenVINO → TFLite → TensorRT → TF_YOLO (YOLO + pb) →
    TF_V2 (saved_model) → TF_V1 (pb only) → TF_V2 (weights) → Torch.

    Args:
        model_dir (str): Absolute path to the extracted model directory.

    Returns:
        str | None: A :class:`~viso_sdk.constants.MODEL_TYPE` constant, or
            ``None`` if the type cannot be determined.
    """

    def get_extensions(dir_path):
        return list(set([os.path.splitext(fn)[1].lower() for fn in os.listdir(dir_path) if
                         os.path.isfile(os.path.join(dir_path, fn))]))

    def get_sub_dirs(dir_path):
        return [sub_dir_name for sub_dir_name in os.listdir(dir_path) if
                os.path.isdir(os.path.join(dir_path, sub_dir_name))]

    def b_include_ext(search_exts, dir_path):
        extensions = get_extensions(dir_path=dir_path)
        check = all(ext in extensions for ext in search_exts)
        return check

    def b_include_dir(search_dirname, dir_path):
        sub_dirs = get_sub_dirs(dir_path=dir_path)
        return search_dirname in sub_dirs

    if b_include_ext(search_exts=[".weights"], dir_path=model_dir) and ('yolov' in model_dir or 'yolo_' in model_dir):
        return MODEL_TYPE.TF_YOLO

    if b_include_ext(search_exts=[".xml", ".bin"], dir_path=model_dir):
        return MODEL_TYPE.OPENVINO

    if b_include_ext(search_exts=[".tflite"], dir_path=model_dir):
        return MODEL_TYPE.TF_LITE

    if b_include_ext(search_exts=[".trt"], dir_path=model_dir):
        return MODEL_TYPE.TensorRT

    if "yolo" in model_dir.lower() and (
            b_include_ext(search_exts=['.pb'], dir_path=model_dir) or b_include_dir(search_dirname="saved_model",
                                                                                    dir_path=model_dir)):
        return MODEL_TYPE.TF_YOLO

    if b_include_dir(search_dirname="saved_model", dir_path=model_dir):
        if b_include_ext(search_exts=['.pb'], dir_path=os.path.join(model_dir, "saved_model")):
            return MODEL_TYPE.TF_V2
    else:
        if b_include_ext(search_exts=['.pb'], dir_path=model_dir):
            return MODEL_TYPE.TF_V1

    if b_include_ext(search_exts=[".weights"], dir_path=model_dir):
        return MODEL_TYPE.TF_V2

    if b_include_ext(search_exts=[".cfg", ".pt"], dir_path=model_dir):
        return MODEL_TYPE.TORCH

    logger.warning(f"Could not determine model type for: {model_dir}")
    return None


def _safe_extract(tar: tarfile.TarFile, path: str) -> None:
    """Extract a tar archive while rejecting path-traversal members.

    Validates every archive member before extraction to ensure its resolved
    destination stays within ``path``. Raises rather than silently skipping
    malicious entries.

    Args:
        tar (tarfile.TarFile): An open tar archive instance.
        path (str): Destination directory for extraction.

    Raises:
        Exception: If any member would extract outside ``path``.
    """
    abs_path = os.path.abspath(path)
    for member in tar.getmembers():
        member_path = os.path.abspath(os.path.join(path, member.name))
        if not member_path.startswith(abs_path + os.sep):
            raise Exception(f"Attempted path traversal in tar archive: {member.name}")
    
    # Python 3.12+ requires filter parameter to avoid deprecation warning
    # Use 'data' filter for safe extraction (recommended for data archives)
    try:
        tar.extractall(path=path, filter='data')
    except TypeError:
        # Python < 3.12 doesn't support filter parameter
        tar.extractall(path=path)


def download_file(cloud_url: str, local_file: str) -> bool:
    """Stream a remote file to a local path.

    Downloads in 8 KiB chunks to avoid buffering the entire archive in memory.
    The destination file is only opened for writing after the server returns
    HTTP 200.

    Args:
        cloud_url (str): Source URL of the file to download.
        local_file (str): Destination path (including filename) on disk.

    Returns:
        bool: ``True`` on success, ``False`` if the server returned a non-200
            status or the request raised an exception.
    """
    logger.info("Downloading...")
    logger.info(f"\tcloud url: {cloud_url}")
    logger.info(f"\ttar.xz file: {local_file}")
    r = requests.get(cloud_url, stream=True, timeout=DOWNLOAD_MODEL_TIMEOUT)
    if r.status_code != 200:
        logger.warning(f"failed downloading status code: {r.status_code}")
        return False
    with open(local_file, "wb") as fp:
        for chunk in r.iter_content(chunk_size=8192):
            fp.write(chunk)
    return True


def download_url(cloud_url: str) -> Optional[str]:
    """Download and extract a model archive from a signed URL.

    Derives the model name and local paths from the URL, removes any stale
    directory or archive, downloads the ``.tar.xz`` via :func:`download_file`,
    and extracts it with :func:`_safe_extract`.

    Re-download behaviour is governed by ``MODEL_EXIST_OK``:
        - ``True``: reuse an existing valid archive or directory.
        - ``False`` (default): always re-download.

    Args:
        cloud_url (str): Signed HTTPS URL pointing to a ``.tar.xz`` archive.

    Returns:
        str | None: Absolute path to the extracted model directory, or
            ``None`` on any failure.
    """
    try:
        a = urlparse(cloud_url)

        save_dir = BASE_MODEL_DIR
        model_name = os.path.basename(a.path).split(".")[0]
        tar_xz_file = os.path.join(save_dir, os.path.basename(a.path))
        model_dir = os.path.join(save_dir, model_name)

        if os.path.isdir(model_dir) and MODEL_EXIST_OK:
            logger.info(f"model dir already exists - {model_dir}")
            return model_dir
        elif os.path.exists(model_dir):
            if os.path.isdir(model_dir):
                logger.info(f"remove model dir - {model_dir}")
                shutil.rmtree(model_dir)
            else:  # not os.path.isdir(model_dir):
                logger.info(f"remove model file - {model_dir}")
                os.remove(model_dir)

        if os.path.exists(tar_xz_file):
            logger.info(f"tar.xz file already exists - {tar_xz_file}")
            ret = fm.from_file(tar_xz_file)
            is_valid_tar = ret is not None and ret.find("empty") == -1
            if not is_valid_tar or not MODEL_EXIST_OK:
                logger.info(f"remove existing tar.xz, re-downloading - {tar_xz_file}")
                os.remove(tar_xz_file)
                if not download_file(cloud_url=cloud_url, local_file=tar_xz_file):
                    return None
        else:
            if not download_file(cloud_url=cloud_url, local_file=tar_xz_file):
                return None

        logger.info(f"Extracting model file - {tar_xz_file} to {save_dir}")
        try:
            with tarfile.open(tar_xz_file) as f:
                _safe_extract(f, save_dir)
                os.remove(tar_xz_file)
        except Exception as e:
            os.remove(tar_xz_file)
            logger.warning(f"Failed to extracting tarxz {tar_xz_file} - {e}")
            return None

        logger.info("Finished the downloading")
        return model_dir
    except Exception as e:
        logger.warning(f"Failed to download from {cloud_url} - {e}")
        return None
