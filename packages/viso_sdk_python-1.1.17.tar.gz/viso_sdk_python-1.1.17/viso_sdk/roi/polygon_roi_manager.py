"""
v 0.1.0-performance: precompute exclusion intersections, use shapely only, avoid deepcopy
v 0.0.9-roi_id and roi_name are now arrays listing all matched ROIs per item
v 0.0.8-fix the shared reference bug
v 0.0.7-add exception when the point is not in the polygon
v 0.0.6-ROI add polygons parameter for the constructor
v 0.0.5-ROI is implemented by shapely
v 0.0.4-ROI points exception
v 0.0.2-customize for MOD container
v 0.0.1-multiple polygon exclude/include roi logic
"""
import copy
import numpy as np
from shapely.geometry import Polygon, Point

from viso_sdk.constants import KEY
from viso_sdk.logging import exception_traceback
from viso_sdk.logging import get_logger

logger = get_logger("PolygonROIManager")


class RoiData:
    POLYGON_INFO = "polygon_roi"
    ROI_ID_KEY = "roi_id"
    ROI_LABEL_KEY = "label"
    INCLUDE_KEY = "include"
    POINTS_KEY = "points"
    POLYGON_EDGE = 1


class PolygonROIManager:

    def __init__(self, polygons=None, frame_sz=None):
        """
        check the point in polygon area
        :param polygons: polygon information in the previous roi node
        :param frame_sz: size of the frame
        """

        self.polygons = None
        # copy instantiates a new object with the same value as the original object
        if polygons:
            self.polygons = copy.deepcopy(polygons)

        self.rois = polygons

        if not frame_sz:
            self.frame_sz = [1.0, 1.0]
        else:
            self.frame_sz = [float(frame_sz[0]), float(frame_sz[1])]

        self._included_rois = []
        self._empty_polygon = None
        # Maps included polygon id → list of precomputed exclusion intersection geometries
        self._exclusion_intersections = {}

        if self.rois:
            # Convert points to numpy arrays and create shapely polygons
            for polygon in self.rois:
                polygon[RoiData.POINTS_KEY] = np.array(polygon[RoiData.POINTS_KEY], dtype=np.float32)
                polygon['shapely_polygon'] = Polygon(polygon[RoiData.POINTS_KEY])

            # Separate empty / included / excluded polygons and precompute intersections
            excluded_rois = [p for p in self.rois if not p[RoiData.INCLUDE_KEY]]
            for polygon in self.rois:
                if len(polygon[RoiData.POINTS_KEY]) == 0:
                    self._empty_polygon = polygon
                elif polygon[RoiData.INCLUDE_KEY]:
                    self._included_rois.append(polygon)
                    # Precompute intersection geometry with every excluded polygon
                    intersections = []
                    for excl in excluded_rois:
                        inter = polygon['shapely_polygon'].intersection(excl['shapely_polygon'])
                        if not inter.is_empty:
                            intersections.append(inter)
                    self._exclusion_intersections[id(polygon)] = intersections

    def _is_point_excluded_for_polygon(self, point_shapely, polygon):
        for inter in self._exclusion_intersections.get(id(polygon), []):
            if inter.contains(point_shapely):
                return True
        return False

    def filter_in_roi(self, det_or_trk, frame_sz=None, anchor_pt=(0.5, 0.5)):
        """
        :param det_or_trk: this param is detection result or tracking result
        :param frame_sz: frame size of the image frame
        :param anchor_pt: anchored position of tracking result or detection result
        :return:
        """
        try:
            if not frame_sz:
                frame_sz = self.frame_sz

            if not self.rois:
                return det_or_trk

            fx, fy = frame_sz[0], frame_sz[1]
            ax, ay = anchor_pt
            included_rois = self._included_rois
            empty_polygon = self._empty_polygon

            stracks_in_roi = []
            for item in det_or_trk:
                has_info_attr = hasattr(item, 'info')
                # if det_or_trk is track, it has info attribute
                if has_info_attr:
                    (x, y, width, height) = item.info.get('rect', item.tlwh)
                else:
                    # customize for MOD
                    (x, y, width, height) = item.tlwh

                rx = x + width * ax
                ry = y + height * ay
                if width > 1.0 and height > 1.0:
                    rx /= fx
                    ry /= fy

                point_shapely = Point(rx, ry)

                # Collect all included polygons that contain the ref_pt
                matched_polygons = []
                for polygon in included_rois:
                    if (self._is_point_in_polygon(point_shapely, polygon) and
                            not self._is_point_excluded_for_polygon(point_shapely, polygon)):
                        matched_polygons.append(polygon)

                if empty_polygon and not matched_polygons:
                    item_copy = copy.copy(item)
                    self._assign_roi_info(item_copy, [empty_polygon], has_info_attr)
                    stracks_in_roi.append(item_copy)
                elif matched_polygons:
                    item_copy = copy.copy(item)
                    self._assign_roi_info(item_copy, matched_polygons, has_info_attr)
                    stracks_in_roi.append(item_copy)

            return stracks_in_roi
        except Exception as e:
            exception_traceback(logger, e)
            return []

    @staticmethod
    def _is_point_in_polygon(point_shapely, polygon):
        return polygon['shapely_polygon'].contains(point_shapely)

    @staticmethod
    def _assign_roi_info(item_copy, matched_polygons, has_info_attr):
        roi_ids = [p.get(RoiData.ROI_ID_KEY, '') for p in matched_polygons]
        roi_names = [p.get(RoiData.ROI_LABEL_KEY, '') for p in matched_polygons]
        if has_info_attr:
            item_copy.info[KEY.ROI_ID] = roi_ids
            item_copy.info[KEY.ROI_NAME] = roi_names
        else:
            item_copy.roi_id = roi_ids
            item_copy.roi_name = roi_names
