"""Redis stream cleanup utilities for clearing KV stores across Node-RED flows.

This module provides utilities to discover and clear Redis keys associated with
Node-RED streams, including downstream nodes in the flow graph.
"""

from typing import Any, Dict, Set, List
from viso_sdk.logging import get_logger
from viso_sdk.redis.utils import gen_redis_key_local

logger = get_logger("REDIS_STREAM_CLEANUP")


class StreamCleanupManager:
    """Manages Redis key cleanup for Node-RED streams.
    
    This class provides functionality to discover all downstream nodes in a Node-RED
    flow and clear their associated Redis keys.
    
    Args:
        redis_wrapper: RedisWrapper instance (redis_client is extracted internally).
        nodered_flow: VisoFlow instance containing the Node-RED flow graph.
        node_config: Current node configuration dictionary.
        redis_out_key: Primary Redis output key for the current node.
    """

    def __init__(
            self,
            redis_wrapper: Any,
            nodered_flow: Any,
            node_config: Dict[str, Any],
            redis_out_key: str
    ):
        """Initialize the StreamCleanupManager.
        
        Args:
            redis_wrapper: RedisWrapper instance.
            nodered_flow: VisoFlow instance with _nodes attribute.
            node_config: Node configuration dictionary with 'id' and 'wires'.
            redis_out_key: Primary Redis output key to clear.
        """
        self.redis_wrapper = redis_wrapper
        self.nodered_flow = nodered_flow
        self.node_config = node_config
        self.redis_out_key = redis_out_key
        self._keys_cleared = False

    def _discover_downstream_nodes(
            self,
            node: Dict[str, Any],
            visited: Set[str]
    ) -> List[Dict[str, Any]]:
        """Recursively discover all downstream nodes from a given node.
        
        Args:
            node: Current node to explore.
            visited: Set of already visited node IDs to avoid cycles.
        
        Returns:
            List of downstream node dictionaries with keys:
                - 'node': Node configuration dictionary
                - 'port': Port index connecting to this node
                - 'node_id': Node ID string
        """
        downstream = []
        node_id = node.get('id')

        if node_id in visited:
            return downstream

        visited.add(node_id)

        for port_idx, next_node_ids in enumerate(node.get('wires', [])):
            for next_node_id in next_node_ids:
                if next_node_id in self.nodered_flow._nodes:
                    next_node = self.nodered_flow._nodes[next_node_id]
                    downstream.append({
                        'node': next_node,
                        'port': port_idx,
                        'node_id': next_node_id
                    })
                    downstream.extend(
                        self._discover_downstream_nodes(next_node, visited)
                    )

        return downstream

    def _collect_stream_redis_keys(self) -> List[str]:
        """Collect all existing Redis keys related to this stream.

        Uses Redis SCAN per node ID (``redis_{node_id}_*``) so only keys that
        actually exist are returned, regardless of port count.

        Returns:
            Deduplicated list of existing Redis keys to delete.
        """
        redis_keys: Set[str] = set()

        # Gather all relevant node IDs: current node + every downstream node
        node_ids: Set[str] = set()

        current_node_id = self.node_config.get('id')
        logger.info(f"[stream_cleanup] current_node_id={current_node_id!r}")
        if current_node_id:
            node_ids.add(current_node_id)
        else:
            logger.warning("[stream_cleanup] node_config has no 'id' — current node keys will not be collected")

        downstream_nodes = self._discover_downstream_nodes(self.node_config, set())
        logger.info(f"[stream_cleanup] downstream nodes found: {[n['node_id'] for n in downstream_nodes]}")
        for node_info in downstream_nodes:
            node_ids.add(node_info['node_id'])

        # Always include the explicitly provided key as a fallback
        redis_keys.add(self.redis_out_key)

        # SCAN Redis for keys that actually exist for each node ID.
        # Pattern redis_{node_id}_* matches all output ports without guessing.
        for node_id in node_ids:
            matched = self.redis_wrapper.scan_keys(pattern=f"redis_{node_id}_*")
            redis_keys.update(matched)

        logger.info(f"[stream_cleanup] found {len(redis_keys)} existing keys: {sorted(redis_keys)}")
        return list(redis_keys)

    def clear_stream_keys(self, max_ports: int = 10) -> bool:
        """Clear all Redis KV stores related to this stream.
        
        Args:
            max_ports: Maximum number of ports to check per node (default: 10).
        
        Returns:
            True if cleanup was successful, False otherwise.
        """
        if self._keys_cleared:
            logger.debug("Redis keys already cleared, skipping")
            return True

        logger.info("Clearing all Redis KV stores for this stream")

        try:
            redis_keys = self._collect_stream_redis_keys()

            deleted = self.redis_wrapper.delete_many(redis_keys)
            logger.info(f"Stream cleanup complete: {deleted}/{len(redis_keys)} keys deleted")
            self._keys_cleared = True
            return True

        except Exception as e:
            logger.error(f"Failed to clear Redis keys: {e}")
            return False

    def reset_cleanup_flag(self) -> None:
        """Reset the cleanup flag to allow re-running cleanup."""
        self._keys_cleared = False


def clear_stream_redis_keys(
        redis_wrapper: Any,
        nodered_flow: Any,
        node_config: Dict[str, Any],
        redis_out_key: str,
        max_ports: int = 10
) -> bool:
    """Convenience function to clear Redis keys for a Node-RED stream.
    
    This is a simplified interface for one-time cleanup operations.
    
    Args:
        redis_wrapper: RedisWrapper instance with _redis_client attribute.
        nodered_flow: VisoFlow instance with _nodes attribute.
        node_config: Node configuration dictionary with 'id' and 'wires'.
        redis_out_key: Primary Redis output key to clear.
        max_ports: Maximum number of ports to check per node (default: 10).
    
    Returns:
        True if cleanup was successful, False otherwise.
    
    Example:
        >>> from viso_sdk.redis import VisoRedis, clear_stream_redis_keys
        >>> from viso_sdk.nodered import VisoFlow
        >>> 
        >>> redis = VisoRedis()
        >>> nodered = VisoFlow()
        >>> flow_info = nodered.parse_flow()
        >>> 
        >>> success = clear_stream_redis_keys(
        ...     redis_wrapper=redis,
        ...     nodered_flow=nodered,
        ...     node_config=flow_info['cur_node'],
        ...     redis_out_key=my_redis_key
        ... )
    """
    manager = StreamCleanupManager(
        redis_wrapper=redis_wrapper,
        nodered_flow=nodered_flow,
        node_config=node_config,
        redis_out_key=redis_out_key
    )
    return manager.clear_stream_keys(max_ports=max_ports)
