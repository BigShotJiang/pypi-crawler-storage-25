from viso_sdk.constants.constants import *
from viso_sdk.constants.variables import *
from viso_sdk.constants.modules import *

NODE_TYPE = variables.get_node_type()
NODE_ID = variables.get_node_id()

ROOT_DIR = variables.get_container_dir()
LOG_DIR = variables.get_log_dir()
BASE_MODEL_DIR = os.path.abspath(os.path.join(ROOT_DIR, 'models'))
MODEL_EXIST_OK = os.getenv("MODEL_EXIST_OK", "False") == "True"
SERVER_HOST = os.environ.get('SERVER_HOST', 'https://dev.viso.ai')
MODEL_URL = f"{SERVER_HOST}/api/device/api/v1/device/model-url?key=<MODEL_KEY>"
# 50MB
LOG_SIZE = 50 * 1024 * 1024
