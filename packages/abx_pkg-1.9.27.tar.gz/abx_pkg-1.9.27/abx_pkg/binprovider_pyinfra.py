#!/usr/bin/env python
__package__ = "abx_pkg"

import os
import sys
import shutil
import importlib
import inspect
import logging as py_logging
import subprocess
import tempfile
from pathlib import Path

from typing import Any

from .base_types import BinProviderName, PATHStr, BinName, InstallArgs
from .semver import SemVer
from .binprovider import BinProvider, OPERATING_SYSTEM, DEFAULT_PATH, remap_kwargs
from .logging import format_subprocess_output, get_logger, log_subprocess_output

logger = get_logger(__name__)

PYINFRA_INSTALLED = shutil.which("pyinfra") is not None
SYSTEM_TEMP_DIR = tempfile.gettempdir()


def pyinfra_package_install(
    pkg_names: InstallArgs,
    installer_module: str = "auto",
    installer_extra_kwargs: dict[str, Any] | None = None,
    timeout: int | None = None,
) -> str:
    if not PYINFRA_INSTALLED:
        raise RuntimeError(
            "Pyinfra is not installed! To fix:\n    pip install pyinfra",
        )

    if isinstance(pkg_names, str):
        pkg_names = pkg_names.split(" ")
    else:
        pkg_names = list(pkg_names)

    _sudo_user = None
    if installer_module == "auto":
        is_macos = OPERATING_SYSTEM == "darwin"
        if is_macos:
            installer_module = "operations.brew.packages"
            try:
                brew_abspath = shutil.which("brew")
                if brew_abspath:
                    _sudo_user = Path(brew_abspath).stat().st_uid
            except Exception:
                pass
        else:
            installer_module = "operations.server.packages"
    else:
        # TODO: non-stock pyinfra modules from other libraries?
        assert installer_module.startswith("operations.")

    try:
        module_name, operation_name = installer_module.rsplit(".", 1)
        installer_module_obj = importlib.import_module(f"pyinfra.{module_name}")
        installer_module_op = getattr(installer_module_obj, operation_name)
        operation_signature = inspect.signature(installer_module_op)
        operation_arg_name = next(iter(operation_signature.parameters))
    except Exception as err:
        raise RuntimeError(
            f"Failed to import pyinfra installer_module {installer_module}: {err.__class__.__name__}",
        ) from err

    accepted_kwargs = {
        name
        for name, parameter in operation_signature.parameters.items()
        if parameter.kind
        in (
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            inspect.Parameter.KEYWORD_ONLY,
        )
    }
    operation_kwargs = {
        operation_arg_name: pkg_names,
        **({"_sudo_user": _sudo_user} if _sudo_user is not None else {}),
        **{
            key: value
            for key, value in (installer_extra_kwargs or {}).items()
            if key in accepted_kwargs
        },
    }

    temp_dir = Path(tempfile.mkdtemp(dir=SYSTEM_TEMP_DIR))
    sudo_bin = None
    try:
        deploy_path = temp_dir / "deploy.py"
        deploy_path.write_text(
            "\n".join(
                [
                    f"from pyinfra.{module_name} import {operation_name}",
                    "",
                    f"{operation_name}(",
                    f"    name={f'Install system packages: {pkg_names}'!r},",
                    *(
                        f"    {key}={value!r},"
                        for key, value in operation_kwargs.items()
                    ),
                    ")",
                    "",
                ],
            ),
            encoding="utf-8",
        )
        pyinfra_bin = (
            shutil.which("pyinfra", path=os.environ.get("PATH", DEFAULT_PATH))
            or "pyinfra"
        )
        cmd = [pyinfra_bin, "--yes", "@local", str(deploy_path)]
        env = os.environ.copy()
        env["TMPDIR"] = SYSTEM_TEMP_DIR
        proc = None
        sudo_failure_output = None
        if (
            OPERATING_SYSTEM != "darwin"
            and installer_module != "operations.brew.packages"
        ):
            sudo_bin = shutil.which("sudo", path=os.environ.get("PATH", DEFAULT_PATH))
            if os.geteuid() != 0 and sudo_bin:
                sudo_proc = subprocess.run(
                    [sudo_bin, "-n", "--", *cmd],
                    capture_output=True,
                    text=True,
                    cwd=temp_dir,
                    env=env,
                    timeout=timeout,
                )
                if sudo_proc.returncode == 0:
                    proc = sudo_proc
                else:
                    log_subprocess_output(
                        logger,
                        "pyinfra sudo exec",
                        sudo_proc.stdout,
                        sudo_proc.stderr,
                        level=py_logging.DEBUG,
                    )
                    sudo_failure_output = format_subprocess_output(
                        sudo_proc.stdout,
                        sudo_proc.stderr,
                    )
        if proc is None:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=temp_dir,
                env=env,
                timeout=timeout,
            )
    finally:
        if os.geteuid() != 0 and sudo_bin:
            chown_proc = subprocess.run(
                [
                    sudo_bin,
                    "-n",
                    "chown",
                    "-R",
                    f"{os.geteuid()}:{os.getegid()}",
                    str(temp_dir),
                ],
                capture_output=True,
                text=True,
            )
            if chown_proc.returncode != 0:
                log_subprocess_output(
                    logger,
                    "pyinfra sudo chown",
                    chown_proc.stdout,
                    chown_proc.stderr,
                    level=py_logging.DEBUG,
                )
        shutil.rmtree(temp_dir, ignore_errors=True)

    succeeded = proc.returncode == 0
    result_text = f"Installing {pkg_names} on {OPERATING_SYSTEM} using Pyinfra {installer_module} {['failed', 'succeeded'][succeeded]}\n{proc.stdout}\n{proc.stderr}".strip()
    if sudo_failure_output and not succeeded:
        result_text = (
            f"{result_text}\n\nPrevious sudo attempt failed:\n{sudo_failure_output}"
        )

    if succeeded:
        return result_text

    if "Permission denied" in result_text:
        raise PermissionError(
            f"Installing {pkg_names} failed! Need to be root to use package manager (retry with sudo, or install manually)",
        )
    raise Exception(
        f"Installing {pkg_names} failed! (retry with sudo, or install manually)\n{result_text}",
    )


class PyinfraProvider(BinProvider):
    name: BinProviderName = "pyinfra"
    INSTALLER_BIN: BinName = "pyinfra"
    PATH: PATHStr = os.environ.get("PATH", DEFAULT_PATH)

    pyinfra_installer_module: str = (
        "auto"  # e.g. operations.apt.packages, operations.server.packages, etc.
    )
    pyinfra_installer_kwargs: dict[str, Any] = {}

    @remap_kwargs({"packages": "install_args"})
    def default_install_handler(
        self,
        bin_name: str,
        install_args: InstallArgs | None = None,
        postinstall_scripts: bool | None = None,
        min_release_age: float | None = None,
        min_version: SemVer | None = None,
        timeout: int | None = None,
    ) -> str:
        install_args = install_args or self.get_install_args(bin_name)

        return pyinfra_package_install(
            pkg_names=install_args,
            installer_module=self.pyinfra_installer_module,
            installer_extra_kwargs=self.pyinfra_installer_kwargs,
            timeout=timeout,
        )

    @remap_kwargs({"packages": "install_args"})
    def default_update_handler(
        self,
        bin_name: str,
        install_args: InstallArgs | None = None,
        postinstall_scripts: bool | None = None,
        min_release_age: float | None = None,
        min_version: SemVer | None = None,
        timeout: int | None = None,
    ) -> str:
        install_args = install_args or self.get_install_args(bin_name)

        return pyinfra_package_install(
            pkg_names=install_args,
            installer_module=self.pyinfra_installer_module,
            installer_extra_kwargs={
                **self.pyinfra_installer_kwargs,
                "latest": True,
            },
            timeout=timeout,
        )

    @remap_kwargs({"packages": "install_args"})
    def default_uninstall_handler(
        self,
        bin_name: str,
        install_args: InstallArgs | None = None,
        postinstall_scripts: bool | None = None,
        min_release_age: float | None = None,
        min_version: SemVer | None = None,
        timeout: int | None = None,
    ) -> bool:
        install_args = install_args or self.get_install_args(bin_name)

        pyinfra_package_install(
            pkg_names=install_args,
            installer_module=self.pyinfra_installer_module,
            installer_extra_kwargs={
                **self.pyinfra_installer_kwargs,
                "present": False,
            },
            timeout=timeout,
        )
        return True


if __name__ == "__main__":
    result = pyinfra = PyinfraProvider()
    func = None

    if len(sys.argv) > 1:
        result = func = getattr(pyinfra, sys.argv[1])  # e.g. install

    if len(sys.argv) > 2 and callable(func):
        result = func(sys.argv[2])  # e.g. install ffmpeg

    print(result)
