"""Multiple entry points: WebSocket for real-time chat, REST for dispatch.

- WebSocket /ws         — real-time chat via handler
- POST /api/summarize   — dispatch a summarization handler on an existing thread
- POST /api/notify      — inject a system notification into a thread via dispatch
"""

from fastapi import FastAPI, Request, WebSocket
from fastapi.responses import JSONResponse

from x64acp import AssistantServer, AssistantServerConfig, UserIdentity

app = FastAPI()
assistant_server = AssistantServer(
    AssistantServerConfig(
        database_type="postgres",
        database_name="assistant",
        assistant_name="Multi Bot",
    )
)

ASSISTANT_ID = "multi-assistant"


async def chat_handler(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()
    yield send.text(f"You said: {incoming.message}")
    yield send.update_thread(title=incoming.message[:60])
    yield send.run_end()


async def summarize_handler(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()

    history = await memory.get_history(limit=50)
    message_count = len(history)

    summary = f"Thread summary: {message_count} messages. Latest: {incoming.message[:80]}"

    yield send.text(summary)
    yield send.update_thread(title="Summary")
    yield send.run_end()


async def notify_handler(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()
    yield send.text(incoming.message)
    yield send.run_end()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await assistant_server.handle(websocket, chat_handler)


@app.post("/api/summarize")
async def summarize(request: Request):
    body = await request.json()
    thread_id = body.get("thread_id")
    if not thread_id:
        return JSONResponse({"error": "thread_id required"}, status_code=400)

    stream = await assistant_server.dispatch(
        handler=summarize_handler,
        assistant_id=ASSISTANT_ID,
        message="Summarize this conversation",
        user=UserIdentity(id="api"),
        thread_id=thread_id,
    )

    texts = []
    async for event in stream:
        if event.send_type == "text":
            texts.append(event.data["text"])

    return {"thread_id": stream.thread_id, "summary": " ".join(texts)}


@app.post("/api/notify")
async def notify(request: Request):
    body = await request.json()
    thread_id = body.get("thread_id")
    message = body.get("message", "")
    if not thread_id or not message:
        return JSONResponse({"error": "thread_id and message required"}, status_code=400)

    stream = await assistant_server.dispatch(
        handler=notify_handler,
        assistant_id=ASSISTANT_ID,
        message=message,
        user=UserIdentity(id="system"),
        thread_id=thread_id,
    )

    await stream.collect()

    return {"status": "ok", "thread_id": stream.thread_id}


@app.on_event("startup")
async def startup():
    await assistant_server.ensure_initialized()


@app.on_event("shutdown")
async def shutdown():
    await assistant_server.close()
