"""WhatsApp webhook using dispatch().

External webhook flow:
- Phone -> customer lookup -> resolve tenant context
- Find or create thread per phone/assistant
- Dispatch handler with explicit context
- Stream events back, forward text replies to WhatsApp
"""

import logging

from fastapi import FastAPI, Request, WebSocket

from x64acp import AssistantServer, AssistantServerConfig, TenantScope, UserIdentity

logger = logging.getLogger(__name__)

app = FastAPI()
assistant_server = AssistantServer(
    AssistantServerConfig(
        database_type="postgres",
        database_name="assistant",
        assistant_name="WhatsApp Bot",
    )
)

CUSTOMER_DB: dict[str, dict] = {
    "+5511999990001": {
        "organization_id": "org_acme",
        "workspace_id": "ws_support",
        "name": "Alice",
    },
    "+5511999990002": {
        "organization_id": "org_acme",
        "workspace_id": "ws_support",
        "name": "Bob",
    },
}


def get_customer(phone: str) -> dict | None:
    return CUSTOMER_DB.get(phone)


async def send_whatsapp_message(phone: str, text: str) -> None:
    logger.info("[whatsapp] -> %s: %s", phone, text[:80])


async def whatsapp_handler(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()
    yield send.text(f"Echo: {incoming.message}")
    yield send.update_thread(title=incoming.message[:60])
    yield send.run_end()


@app.post("/webhook/{assistant_id}")
async def webhook(assistant_id: str, request: Request):
    body = await request.json()
    phone = body.get("phone", "")
    text = body.get("text", "")

    if not phone or not text:
        return {"status": "ignored"}

    customer = get_customer(phone)
    if not customer:
        return {"status": "unknown_customer"}

    customer_name = customer.get("name", phone)

    repo = await assistant_server.repository()
    threads = await repo.list_threads(
        filter={
            "assistant_id": assistant_id,
            "user_id": phone,
        },
        limit=1,
    )
    thread_id = threads[0].id if threads else None

    stream = await assistant_server.dispatch(
        handler=whatsapp_handler,
        assistant_id=assistant_id,
        message=text,
        user=UserIdentity(id=phone, name=customer_name),
        tenant=TenantScope(
            organization_id=customer["organization_id"],
            workspace_id=customer["workspace_id"],
        ),
        thread_id=thread_id,
        thread_title=f"WhatsApp: {customer_name}" if not thread_id else None,
    )

    async for event in stream:
        if event.send_type == "text":
            await send_whatsapp_message(phone, event.data["text"])

    return {"status": "ok", "thread_id": stream.thread_id, "is_new": stream.is_new_thread}


@app.websocket("/ws")
async def ws(websocket: WebSocket):
    await websocket.accept()
    await assistant_server.handle(websocket, whatsapp_handler)


@app.on_event("startup")
async def startup():
    await assistant_server.ensure_initialized()


@app.on_event("shutdown")
async def shutdown():
    await assistant_server.close()
