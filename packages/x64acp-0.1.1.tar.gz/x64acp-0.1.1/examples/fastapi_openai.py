import os

from fastapi import FastAPI, WebSocket
from openai import AsyncOpenAI

from x64acp import (
    AssistantServer,
    AssistantServerConfig,
    SettingsField,
    SettingsFieldType,
    SettingsSchema,
    SettingsScope,
    SettingsSelectOption,
)

app = FastAPI()

settings_schema = SettingsSchema(
    scopes=[
        SettingsScope(
            name="admin_assistant",
            visibility="admin",
            fields=[
                SettingsField(
                    id="model",
                    type=SettingsFieldType.SELECT,
                    label="Model",
                    required=True,
                    default="gpt-4o-mini",
                    options=[
                        SettingsSelectOption(value="gpt-4o-mini", label="GPT-4o Mini"),
                        SettingsSelectOption(value="gpt-4o", label="GPT-4o"),
                        SettingsSelectOption(value="gpt-4-turbo", label="GPT-4 Turbo"),
                    ],
                ),
                SettingsField(
                    id="temperature",
                    type=SettingsFieldType.NUMBER,
                    label="Temperature",
                    required=True,
                    default=0.7,
                    min=0,
                    max=2,
                ),
            ],
        ),
        SettingsScope(
            name="user_thread",
            visibility="user",
            fields=[
                SettingsField(
                    id="system_prompt",
                    type=SettingsFieldType.TEXTAREA,
                    label="System Prompt",
                    required=True,
                    default="You are a helpful assistant.",
                    rows=4,
                ),
            ],
        ),
    ]
)

assistant_server = AssistantServer(
    AssistantServerConfig(
        database_type="postgres",
        database_name="assistant",
        settings_schema=settings_schema,
    )
)
client = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))


async def openai_assistant(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()

    model = await settings.get("model", scope="admin_assistant")
    temperature = await settings.get("temperature", scope="admin_assistant")
    system_prompt = await settings.resolve(
        "system_prompt",
        scopes=[("user_thread", incoming.context.thread_id), ("admin_assistant", "")],
    )

    await analytics.track("llm.request", data={"model": model})

    history = await memory.get_history(limit=20)

    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(history)
    messages.append({"role": "user", "content": incoming.message})

    completion = await client.chat.completions.create(
        model=model,
        temperature=temperature,
        messages=messages,
    )

    await analytics.track(
        "llm.response",
        data={
            "model": model,
            "tokens": completion.usage.total_tokens if completion.usage else None,
        },
    )

    yield send.text(completion.choices[0].message.content)
    yield send.update_thread(title=incoming.message[:60])
    yield send.run_end()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await assistant_server.handle(websocket, openai_assistant)


@app.on_event("shutdown")
async def shutdown():
    await assistant_server.close()
