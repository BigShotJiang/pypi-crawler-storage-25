import os

from fastapi import FastAPI, WebSocket
from google import genai
from google.genai import types

from x64acp import AssistantServer, AssistantServerConfig

app = FastAPI()
assistant_server = AssistantServer(
    AssistantServerConfig(
        database_type="postgres",
        database_name="assistant",
    )
)
client = genai.Client(
    vertexai=True,
    project=os.getenv("GOOGLE_CLOUD_PROJECT"),
    location=os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1"),
)


async def vertex_assistant(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()

    history = await memory.get_history(limit=20, format="google")

    contents = []
    for msg in history:
        contents.append(types.Content(role=msg["role"], parts=[types.Part.from_text(msg["parts"][0]["text"])]))

    contents.append(types.Content(role="user", parts=[types.Part.from_text(incoming.message)]))

    result = await client.aio.models.generate_content(
        model="gemini-2.5-flash",
        contents=contents,
        config=types.GenerateContentConfig(
            system_instruction="You are a helpful assistant.",
        ),
    )

    yield send.text(result.text)
    yield send.update_thread(title=incoming.message[:60])
    yield send.run_end()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await assistant_server.handle(websocket, vertex_assistant)


@app.on_event("shutdown")
async def shutdown():
    await assistant_server.close()
