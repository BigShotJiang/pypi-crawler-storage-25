import os

from fastapi import FastAPI, WebSocket
from langchain_core.messages import AssistantMessage, SystemMessage, UserMessage
from langchain_core.tools import tool
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_assistant

from x64acp import AssistantServer, AssistantServerConfig

app = FastAPI()
assistant_server = AssistantServer(
    AssistantServerConfig(
        database_type="postgres",
        database_name="assistant",
    )
)

llm = ChatOpenAI(
    model="gpt-4o-mini",
    api_key=os.getenv("OPENAI_API_KEY"),
)


@tool
def multiply(a: int, b: int) -> int:
    return a * b


@tool
def add(a: int, b: int) -> int:
    return a + b


assistant = create_react_assistant(llm, tools=[multiply, add])


async def langgraph_assistant(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()

    events = await memory.get_history_raw(limit=20, order="asc")

    messages = [SystemMessage(content="You are a helpful assistant with math tools.")]
    for event in events:
        if event.type == "message" and event.content:
            text = " ".join(part.text for part in event.content if hasattr(part, "text"))
            if text:
                if event.actor == "user":
                    messages.append(UserMessage(content=text))
                else:
                    messages.append(AssistantMessage(content=text))

    messages.append(UserMessage(content=incoming.message))

    result = await assistant.ainvoke({"messages": messages})

    for msg in result["messages"]:
        if hasattr(msg, "tool_calls") and msg.tool_calls:
            for tc in msg.tool_calls:
                yield send.tool_call(tc["name"], tc["args"])
        if msg.type == "tool":
            yield send.tool_result(msg.name, {"result": msg.content})

    final = result["messages"][-1]
    if final.content:
        yield send.text(final.content)

    yield send.update_thread(title=incoming.message[:60])
    yield send.run_end()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await assistant_server.handle(websocket, langgraph_assistant)


@app.on_event("shutdown")
async def shutdown():
    await assistant_server.close()
