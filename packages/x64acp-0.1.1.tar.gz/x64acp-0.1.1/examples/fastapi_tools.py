import uuid

import httpx
from fastapi import FastAPI, WebSocket

from x64acp import AssistantServer, AssistantServerConfig

app = FastAPI()
assistant_server = AssistantServer(
    AssistantServerConfig(
        database_type="postgres",
        database_name="assistant",
        assistant_name="Search Assistant",
    )
)


async def search_web(query: str) -> dict:
    async with httpx.AsyncClient() as client:
        resp = await client.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json"},
        )
        return resp.json()


async def assistant(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()

    if incoming.message.lower().startswith("search "):
        query = incoming.message[7:]
        args = {"query": query}
        call_id = str(uuid.uuid4())

        yield send.tool_call(
            "web_search",
            args,
            display_name="Searching the web...",
            id=call_id,
        )

        results = await search_web(query)

        yield send.tool_result(
            "web_search",
            {"results": results},
            args=args,
            id=call_id,
        )

        if results.get("Abstract"):
            yield send.text(results["Abstract"])
        else:
            yield send.text(f"No results found for: {query}")
    else:
        yield send.text("Try: search <query>")

    yield send.update_thread(title=incoming.message[:60])
    yield send.run_end()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await assistant_server.handle(websocket, assistant)


@app.on_event("shutdown")
async def shutdown():
    await assistant_server.close()
