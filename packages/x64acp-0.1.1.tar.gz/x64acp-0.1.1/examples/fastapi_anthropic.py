import os

from anthropic import AsyncAnthropic
from fastapi import FastAPI, WebSocket

from x64acp import (
    AssistantServer,
    AssistantServerConfig,
    SettingsField,
    SettingsFieldType,
    SettingsSchema,
    SettingsScope,
    SettingsSelectOption,
)

app = FastAPI()

settings_schema = SettingsSchema(
    scopes=[
        SettingsScope(
            name="admin_assistant",
            visibility="admin",
            fields=[
                SettingsField(
                    id="model",
                    type=SettingsFieldType.SELECT,
                    label="Model",
                    required=True,
                    default="claude-sonnet-4-20250514",
                    options=[
                        SettingsSelectOption(value="claude-sonnet-4-20250514", label="Claude Sonnet 4"),
                        SettingsSelectOption(value="claude-opus-4-20250514", label="Claude Opus 4"),
                        SettingsSelectOption(value="claude-haiku-4-20250514", label="Claude Haiku 4"),
                    ],
                ),
                SettingsField(
                    id="max_tokens",
                    type=SettingsFieldType.NUMBER,
                    label="Max Tokens",
                    required=True,
                    default=1024,
                    min=1,
                    max=4096,
                ),
            ],
        ),
        SettingsScope(
            name="user_thread",
            visibility="user",
            fields=[
                SettingsField(
                    id="system_prompt",
                    type=SettingsFieldType.TEXTAREA,
                    label="System Prompt",
                    required=True,
                    default="You are a helpful assistant.",
                    rows=4,
                ),
            ],
        ),
    ]
)

assistant_server = AssistantServer(
    AssistantServerConfig(
        database_type="postgres",
        database_name="assistant",
        settings_schema=settings_schema,
    )
)
client = AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))


async def anthropic_assistant(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()

    model = await settings.get("model", scope="admin_assistant")
    max_tokens = await settings.get("max_tokens", scope="admin_assistant")
    system_prompt = await settings.resolve(
        "system_prompt",
        scopes=[("user_thread", incoming.context.thread_id), ("admin_assistant", "")],
    )

    await analytics.track("llm.request", data={"model": model})

    history = await memory.get_history(limit=20, format="anthropic")

    messages = list(history)
    messages.append({"role": "user", "content": incoming.message})

    result = await client.messages.create(
        model=model,
        max_tokens=int(max_tokens),
        system=system_prompt,
        messages=messages,
    )

    await analytics.track(
        "llm.response",
        data={
            "model": model,
            "input_tokens": result.usage.input_tokens,
            "output_tokens": result.usage.output_tokens,
        },
    )

    yield send.text(result.content[0].text)
    yield send.update_thread(title=incoming.message[:60])
    yield send.run_end()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await assistant_server.handle(websocket, anthropic_assistant)


@app.on_event("shutdown")
async def shutdown():
    await assistant_server.close()
