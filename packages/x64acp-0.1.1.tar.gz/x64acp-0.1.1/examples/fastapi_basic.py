from fastapi import FastAPI, WebSocket

from x64acp import AssistantServer, AssistantServerConfig

app = FastAPI()
assistant_server = AssistantServer(
    AssistantServerConfig(
        database_type="postgres",
        database_name="assistant",
        assistant_name="Echo Bot",
    )
)


async def echo_assistant(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()
    yield send.text(f"You said: {incoming.message}")
    yield send.update_thread(title=incoming.message[:60])
    yield send.run_end()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await assistant_server.handle(websocket, echo_assistant)


@app.on_event("shutdown")
async def shutdown():
    await assistant_server.close()
