import os

from fastapi import FastAPI, WebSocket
from langchain_core.messages import AssistantMessage, SystemMessage, UserMessage
from langchain_openai import ChatOpenAI

from x64acp import AssistantServer, AssistantServerConfig

app = FastAPI()
assistant_server = AssistantServer(
    AssistantServerConfig(
        database_type="postgres",
        database_name="assistant",
    )
)
llm = ChatOpenAI(
    model="gpt-4o-mini",
    api_key=os.getenv("OPENAI_API_KEY"),
)


async def langchain_assistant(incoming, send, memory, analytics, settings, knowledge):
    yield send.run_start()

    events = await memory.get_history_raw(limit=20, order="asc")

    messages = [SystemMessage(content="You are a helpful assistant.")]
    for event in events:
        if event.type == "message" and event.content:
            text = " ".join(part.text for part in event.content if hasattr(part, "text"))
            if text:
                if event.actor == "user":
                    messages.append(UserMessage(content=text))
                else:
                    messages.append(AssistantMessage(content=text))

    messages.append(UserMessage(content=incoming.message))

    result = await llm.ainvoke(messages)

    yield send.text(result.content)
    yield send.update_thread(title=incoming.message[:60])
    yield send.run_end()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await assistant_server.handle(websocket, langchain_assistant)


@app.on_event("shutdown")
async def shutdown():
    await assistant_server.close()
