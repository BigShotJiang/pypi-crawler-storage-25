import logging
import uuid
from datetime import UTC, datetime
from typing import Any

from x64acp.analytics.models import AnalyticsEventPayload
from x64acp.protocol.models import (
    Run,
    TenantScope,
    Thread,
    ThreadEvent,
    UserIdentity,
    deserialize_s2c_part,
)

logger = logging.getLogger(__name__)

try:
    from azure.cosmos import PartitionKey  # type: ignore[import-not-found]
    from azure.cosmos.aio import CosmosClient  # type: ignore[import-not-found]
    from azure.cosmos.exceptions import CosmosResourceNotFoundError  # type: ignore[import-not-found]

    COSMOS_AVAILABLE = True
except ImportError:
    COSMOS_AVAILABLE = False
    CosmosClient = None
    PartitionKey = None
    CosmosResourceNotFoundError = Exception


class CosmosPersistence:
    def __init__(
        self,
        *,
        endpoint: str,
        key: str,
        database: str,
        table_prefix: str = "assistant_",
    ):
        if not COSMOS_AVAILABLE:
            raise ImportError("Azure Cosmos DB SDK not installed. Install with: pip install assistants[cosmos]")

        if not endpoint or not key or not database:
            raise ValueError(
                "Cosmos DB requires endpoint, key, and database configuration. "
                "Set assistant_DATABASE_HOST (endpoint), assistant_DATABASE_KEY, and assistant_DATABASE_NAME "
                "environment variables or pass them to AssistantServerConfig."
            )

        self._endpoint = endpoint
        self._key = key
        self._database_name = database
        self._prefix = table_prefix
        self._client: CosmosClient | None = None
        self._database = None
        self._containers: dict[str, Any] = {}
        self._thread_assistant_cache: dict[str, str] = {}

    async def connect(self) -> None:
        logger.info(
            "[assistant] connecting to cosmos db at %s (database=%s)",
            self._endpoint,
            self._database_name,
        )
        self._client = CosmosClient(self._endpoint, credential=self._key)
        self._database = self._client.get_database_client(self._database_name)
        logger.info("[assistant] successfully connected to cosmos db")

    async def disconnect(self) -> None:
        if self._client:
            await self._client.close()
            self._client = None

    async def migrate(self) -> None:
        """Create containers if they don't exist."""
        if not self._database:
            raise RuntimeError("Not connected")

        container_names = [
            f"{self._prefix}threads",
            f"{self._prefix}events",
            f"{self._prefix}runs",
            f"{self._prefix}settings",
            f"{self._prefix}analytics",
        ]

        for container_name in container_names:
            try:
                container = await self._database.create_container_if_not_exists(
                    id=container_name,
                    partition_key=PartitionKey(path="/assistant_id"),
                )
                self._containers[container_name] = container
                logger.info("[assistant] cosmos container ready: %s", container_name)
            except Exception as e:
                logger.error(
                    "[assistant] failed to create cosmos container %s: %s",
                    container_name,
                    e,
                )
                raise

    def _get_container(self, name: str):
        container_name = f"{self._prefix}{name}"
        if container_name not in self._containers:
            if not self._database:
                raise RuntimeError("Not connected")
            self._containers[container_name] = self._database.get_container_client(container_name)
        return self._containers[container_name]

    async def create_thread(self, thread: Thread) -> None:
        container = self._get_container("threads")
        doc = {
            "id": thread.id,
            "assistant_id": thread.assistant_id,
            "owner_user": thread.owner_user.model_dump() if thread.owner_user else None,
            "owner_tenant": thread.owner_tenant.model_dump() if thread.owner_tenant else None,
            "participants": thread.participants,
            "title": thread.title,
            "external": thread.external,
            "metadata": thread.metadata,
            "created_at": thread.created_at.isoformat(),
            "updated_at": thread.updated_at.isoformat(),
            "last_event_at": thread.last_event_at.isoformat(),
        }
        await container.create_item(doc)
        self._thread_assistant_cache[thread.id] = thread.assistant_id

    async def get_thread(self, thread_id: str, assistant_id: str) -> Thread | None:
        container = self._get_container("threads")
        try:
            row = await container.read_item(thread_id, partition_key=assistant_id)
            self._thread_assistant_cache[thread_id] = assistant_id
            return self._row_to_thread(row)
        except CosmosResourceNotFoundError:
            self._thread_assistant_cache.pop(thread_id, None)
            return None

    async def update_thread(self, thread: Thread, assistant_id: str) -> None:
        container = self._get_container("threads")
        doc = {
            "id": thread.id,
            "assistant_id": thread.assistant_id,
            "owner_user": thread.owner_user.model_dump() if thread.owner_user else None,
            "owner_tenant": thread.owner_tenant.model_dump() if thread.owner_tenant else None,
            "participants": thread.participants,
            "title": thread.title,
            "external": thread.external,
            "metadata": thread.metadata,
            "created_at": thread.created_at.isoformat(),
            "updated_at": thread.updated_at.isoformat(),
            "last_event_at": thread.last_event_at.isoformat(),
        }
        await container.upsert_item(doc)

    async def delete_thread(self, thread_id: str, assistant_id: str) -> None:
        thread = await self.get_thread(thread_id, assistant_id)
        if not thread:
            return

        events_container = self._get_container("events")
        query = "SELECT c.id FROM c WHERE c.thread_id = @thread_id AND c.assistant_id = @assistant_id"
        params = [
            {"name": "@thread_id", "value": thread_id},
            {"name": "@assistant_id", "value": assistant_id},
        ]
        async for item in events_container.query_items(query, parameters=params):
            await events_container.delete_item(item["id"], partition_key=assistant_id)

        runs_container = self._get_container("runs")
        query = "SELECT c.id FROM c WHERE c.thread_id = @thread_id AND c.assistant_id = @assistant_id"
        async for item in runs_container.query_items(query, parameters=params):
            await runs_container.delete_item(item["id"], partition_key=assistant_id)

        threads_container = self._get_container("threads")
        await threads_container.delete_item(thread_id, partition_key=assistant_id)

        self._thread_assistant_cache.pop(thread_id, None)

    def _build_scope_conditions(
        self,
        scope: str,
        user_id: str | None,
        user_email: str | None,
        identity_ids: list[str] | None,
        conditions: list[str],
        params: list[dict[str, Any]],
        tenant_filter: dict[str, Any] | None = None,
        user_filter: dict[str, Any] | None = None,
    ) -> None:
        if tenant_filter:
            for key, value in tenant_filter.items():
                param_name = f"@tenant_filter_{key}"
                conditions.append(f"c.owner_tenant.{key} = {param_name}")
                params.append({"name": param_name, "value": value})
        if user_filter:
            for key, value in user_filter.items():
                param_name = f"@user_filter_{key}"
                conditions.append(f"c.owner_user.{key} = {param_name}")
                params.append({"name": param_name, "value": value})
        if scope == "member":
            if identity_ids:
                or_parts: list[str] = []
                for i, uid in enumerate(identity_ids):
                    param_name = f"@identity_id_{i}"
                    or_parts.append(f"EXISTS(SELECT VALUE u FROM u IN c.participants WHERE u.user.id = {param_name})")
                    params.append({"name": param_name, "value": uid})
                conditions.append(f"({' OR '.join(or_parts)})")
            elif user_id:
                conditions.append("EXISTS(SELECT VALUE u FROM u IN c.participants WHERE u.user.id = @author_id)")
                params.append({"name": "@author_id", "value": user_id})
            elif user_email:
                conditions.append("EXISTS(SELECT VALUE u FROM u IN c.participants WHERE u.user.email = @author_email)")
                params.append({"name": "@author_email", "value": user_email})

    async def count_threads(
        self,
        assistant_id: str,
        user_id: str | None,
        scope: str = "member",
        user_email: str | None = None,
        identity_ids: list[str] | None = None,
        tenant_filter: dict[str, Any] | None = None,
        user_filter: dict[str, Any] | None = None,
    ) -> int:
        container = self._get_container("threads")

        conditions = ["c.assistant_id = @assistant_id"]
        params: list[dict[str, Any]] = [{"name": "@assistant_id", "value": assistant_id}]

        self._build_scope_conditions(
            scope,
            user_id,
            user_email,
            identity_ids,
            conditions,
            params,
            tenant_filter=tenant_filter,
            user_filter=user_filter,
        )

        where = " AND ".join(conditions)
        query = f"SELECT VALUE COUNT(1) FROM c WHERE {where}"

        items = [
            item
            async for item in container.query_items(
                query,
                parameters=params,
                partition_key=assistant_id,
            )
        ]
        return items[0] if items else 0

    async def list_threads(
        self,
        assistant_id: str,
        user_id: str | None,
        cursor: str | None,
        limit: int,
        scope: str = "member",
        user_email: str | None = None,
        identity_ids: list[str] | None = None,
        tenant_filter: dict[str, Any] | None = None,
        user_filter: dict[str, Any] | None = None,
    ) -> list[Thread]:
        container = self._get_container("threads")

        conditions = ["c.assistant_id = @assistant_id"]
        params: list[dict[str, Any]] = [{"name": "@assistant_id", "value": assistant_id}]

        self._build_scope_conditions(
            scope,
            user_id,
            user_email,
            identity_ids,
            conditions,
            params,
            tenant_filter=tenant_filter,
            user_filter=user_filter,
        )

        if cursor:
            if "|" in cursor:
                cursor_ts, cursor_id = cursor.rsplit("|", 1)
                conditions.append(
                    "(c.last_event_at < @cursor_ts OR (c.last_event_at = @cursor_ts AND c.id < @cursor_id))"
                )
                params.append({"name": "@cursor_ts", "value": cursor_ts})
                params.append({"name": "@cursor_id", "value": cursor_id})
            else:
                conditions.append("c.last_event_at < @cursor")
                params.append({"name": "@cursor", "value": cursor})

        params.append({"name": "@limit", "value": limit})
        where = " AND ".join(conditions)

        query = f"""
            SELECT * FROM c
            WHERE {where}
            ORDER BY c.last_event_at DESC
            OFFSET 0 LIMIT @limit
        """

        items = [
            item
            async for item in container.query_items(
                query,
                parameters=params,
                partition_key=assistant_id,
            )
        ]

        return [self._row_to_thread(row) for row in items]

    async def create_event(self, event: ThreadEvent) -> None:
        assistant_id = self._thread_assistant_cache.get(event.thread_id)
        if not assistant_id:
            raise ValueError(f"Thread {event.thread_id} not found in cache — thread must be loaded first")

        container = self._get_container("events")
        content_json = None
        if event.content:
            content_json = [self._serialize_content_part(p) for p in event.content]

        doc = {
            "id": event.id,
            "assistant_id": assistant_id,
            "thread_id": event.thread_id,
            "run_id": event.run_id,
            "type": event.type,
            "role": event.role,
            "actor": event.actor,
            "display_name": event.display_name,
            "user": event.user.model_dump() if event.user else None,
            "tenant": event.tenant.model_dump() if event.tenant else None,
            "client_event_id": event.client_event_id,
            "content": content_json,
            "data": event.data,
            "event_assistant_id": event.assistant_id,
            "command": event.command,
            "created_at": event.created_at.isoformat(),
        }
        await container.create_item(doc)

    async def get_events(
        self,
        thread_id: str,
        assistant_id: str,
        *,
        after_event_id: str | None = None,
        before_event_id: str | None = None,
        limit: int = 50,
        order: str = "asc",
        filters: dict[str, str] | None = None,
    ) -> list[ThreadEvent]:

        from x64acp.variables import variables

        container = self._get_container("events")
        conditions = ["c.thread_id = @thread_id"]
        params: list[dict[str, Any]] = [{"name": "@thread_id", "value": thread_id}]

        if after_event_id:
            ref_query = "SELECT c.created_at, c.id FROM c WHERE c.id = @id"
            ref_params = [{"name": "@id", "value": after_event_id}]
            ref_items = [item async for item in container.query_items(ref_query, parameters=ref_params)]
            if ref_items:
                ref = ref_items[0]
                if order == "desc":
                    conditions.append(
                        "(c.created_at < @after_time OR (c.created_at = @after_time AND c.id < @after_id))"
                    )
                else:
                    conditions.append(
                        "(c.created_at > @after_time OR (c.created_at = @after_time AND c.id > @after_id))"
                    )
                params.append({"name": "@after_time", "value": ref["created_at"]})
                params.append({"name": "@after_id", "value": ref["id"]})

        if before_event_id:
            ref_query = "SELECT c.created_at, c.id FROM c WHERE c.id = @id"
            ref_params = [{"name": "@id", "value": before_event_id}]
            ref_items = [item async for item in container.query_items(ref_query, parameters=ref_params)]
            if ref_items:
                ref = ref_items[0]
                conditions.append(
                    "(c.created_at < @before_time OR (c.created_at = @before_time AND c.id < @before_id))"
                )
                params.append({"name": "@before_time", "value": ref["created_at"]})
                params.append({"name": "@before_id", "value": ref["id"]})

        if filters:
            for key, value in filters.items():
                if key in variables.filterable_fields:
                    param_name = f"@filter_{key}"
                    conditions.append(f"c.{key} = {param_name}")
                    params.append({"name": param_name, "value": value})

        direction = "DESC" if order == "desc" else "ASC"
        where = " AND ".join(conditions)

        query = f"""
            SELECT * FROM c
            WHERE {where}
            ORDER BY c.created_at {direction}, c.id {direction}
            OFFSET 0 LIMIT @limit
        """
        params.append({"name": "@limit", "value": limit})

        items = [
            item
            async for item in container.query_items(
                query,
                parameters=params,
                partition_key=assistant_id,
            )
        ]

        return [self._row_to_event(row) for row in items]

    def _row_to_event(self, row: dict) -> ThreadEvent:
        content = None
        if row.get("content"):
            content = [self._deserialize_content_part(p) for p in row["content"]]

        user_raw = row.get("user") or {}
        user = UserIdentity(**user_raw) if user_raw else None

        tenant_raw = row.get("tenant") or {}
        tenant = TenantScope(**tenant_raw) if tenant_raw else None

        return ThreadEvent(
            id=row["id"],
            thread_id=row["thread_id"],
            run_id=row.get("run_id"),
            type=row["type"],
            role=row.get("role", "system"),
            actor=row.get("actor", "system"),
            display_name=row.get("display_name"),
            user=user,
            tenant=tenant,
            client_event_id=row.get("client_event_id"),
            content=content,
            data=row.get("data"),
            assistant_id=row.get("event_assistant_id"),
            command=row.get("command"),
            created_at=datetime.fromisoformat(row["created_at"]),
        )

    def _row_to_thread(self, row: dict) -> Thread:
        owner_user_raw = row.get("owner_user") or {}
        owner_user = UserIdentity(**owner_user_raw) if owner_user_raw else None

        owner_tenant_raw = row.get("owner_tenant") or {}
        owner_tenant = TenantScope(**owner_tenant_raw) if owner_tenant_raw else None

        participants = row.get("participants") or []

        return Thread(
            id=row["id"],
            assistant_id=row["assistant_id"],
            owner_user=owner_user,
            owner_tenant=owner_tenant,
            participants=participants,
            title=row.get("title"),
            external=row.get("external", False),
            metadata=row.get("metadata"),
            created_at=datetime.fromisoformat(row["created_at"]),
            updated_at=datetime.fromisoformat(row["updated_at"]),
            last_event_at=datetime.fromisoformat(row["last_event_at"]),
        )

    async def upsert_thread_participant(self, thread_id: str, assistant_id: str, participant: dict) -> None:
        """Add or update a participant in the thread's participants array (Cosmos DB).

        participant is a dict with {"user": {...}, "tenant": {...}} sub-keys.
        Matching is by user.id.
        """
        thread = await self.get_thread(thread_id, assistant_id)
        if not thread:
            return

        user_id = (participant.get("user") or {}).get("id")
        if not user_id:
            return

        def match(p: dict) -> bool:
            return (p.get("user") or {}).get("id") == user_id

        existing = next((p for p in thread.participants if match(p)), None)
        if existing:
            thread.participants = [participant if match(p) else p for p in thread.participants]
        else:
            thread.participants.append(participant)

        thread.updated_at = datetime.now(UTC)
        await self.update_thread(thread, assistant_id)

    async def create_run(self, run: Run, assistant_id: str) -> None:

        container = self._get_container("runs")
        doc = {
            "id": run.id,
            "assistant_id": assistant_id,
            "thread_id": run.thread_id,
            "blueprint_id": run.blueprint_id,
            "status": run.status,
            "started_at": run.started_at.isoformat(),
            "ended_at": run.ended_at.isoformat() if run.ended_at else None,
            "error": run.error,
        }
        await container.create_item(doc)

    async def update_run(self, run: Run, assistant_id: str) -> None:

        container = self._get_container("runs")
        doc = {
            "id": run.id,
            "assistant_id": assistant_id,
            "thread_id": run.thread_id,
            "blueprint_id": run.blueprint_id,
            "status": run.status,
            "started_at": run.started_at.isoformat(),
            "ended_at": run.ended_at.isoformat() if run.ended_at else None,
            "error": run.error,
        }
        await container.upsert_item(doc)

    async def get_run(self, run_id: str, assistant_id: str) -> Run | None:
        container = self._get_container("runs")
        query = "SELECT * FROM c WHERE c.id = @id"
        params = [{"name": "@id", "value": run_id}]

        items = [
            item
            async for item in container.query_items(
                query,
                parameters=params,
                partition_key=assistant_id,
            )
        ]
        if not items:
            return None
        row = items[0]
        return Run(
            id=row["id"],
            thread_id=row["thread_id"],
            blueprint_id=row.get("blueprint_id"),
            status=row["status"],
            started_at=datetime.fromisoformat(row["started_at"]),
            ended_at=datetime.fromisoformat(row["ended_at"]) if row.get("ended_at") else None,
            error=row.get("error"),
        )

    async def list_runs(
        self,
        assistant_id: str,
        thread_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[Run]:
        container = self._get_container("runs")
        conditions: list[str] = []
        params: list[dict[str, Any]] = []

        if thread_id:
            conditions.append("c.thread_id = @thread_id")
            params.append({"name": "@thread_id", "value": thread_id})
        if status:
            conditions.append("c.status = @status")
            params.append({"name": "@status", "value": status})

        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        params.append({"name": "@limit", "value": limit})

        query = f"""
            SELECT * FROM c
            {where}
            ORDER BY c.started_at DESC
            OFFSET 0 LIMIT @limit
        """

        items = [
            item
            async for item in container.query_items(
                query,
                parameters=params,
                partition_key=assistant_id,
            )
        ]

        return [
            Run(
                id=row["id"],
                thread_id=row["thread_id"],
                blueprint_id=row.get("blueprint_id"),
                status=row["status"],
                started_at=datetime.fromisoformat(row["started_at"]),
                ended_at=datetime.fromisoformat(row["ended_at"]) if row.get("ended_at") else None,
                error=row.get("error"),
            )
            for row in items
        ]

    async def get_event(self, event_id: str, assistant_id: str) -> ThreadEvent | None:
        container = self._get_container("events")
        query = "SELECT * FROM c WHERE c.id = @id"
        params = [{"name": "@id", "value": event_id}]

        items = [
            item
            async for item in container.query_items(
                query,
                parameters=params,
                partition_key=assistant_id,
            )
        ]
        if not items:
            return None
        return self._row_to_event(items[0])

    async def update_event(self, event: ThreadEvent, assistant_id: str) -> None:
        container = self._get_container("events")

        try:
            doc = await container.read_item(event.id, partition_key=assistant_id)
        except CosmosResourceNotFoundError:
            return

        content_json = None
        if event.content:
            content_json = [self._serialize_content_part(p) for p in event.content]
        doc["content"] = content_json

        await container.upsert_item(doc)

    async def delete_event(self, event_id: str, assistant_id: str) -> None:
        container = self._get_container("events")
        try:
            await container.delete_item(event_id, partition_key=assistant_id)
        except CosmosResourceNotFoundError:
            pass

    def _serialize_content_part(self, part) -> dict:
        if hasattr(part, "model_dump"):
            return part.model_dump()
        return dict(part)

    def _deserialize_content_part(self, data: dict):
        return deserialize_s2c_part(data)

    def _settings_doc_id(self, assistant_id: str, scope: str = "", scope_id: str = "") -> str:
        return f"{assistant_id}:{scope}:{scope_id}"

    async def get_settings(self, assistant_id: str, scope: str = "", scope_id: str = "") -> dict[str, Any]:
        container = self._get_container("settings")
        doc_id = self._settings_doc_id(assistant_id, scope, scope_id)

        try:
            item = await container.read_item(doc_id, partition_key=assistant_id)
            return item.get("values", {})
        except CosmosResourceNotFoundError:
            return {}

    async def update_setting(
        self, assistant_id: str, field_id: str, value: Any, scope: str = "", scope_id: str = ""
    ) -> datetime:
        container = self._get_container("settings")
        now = datetime.now(UTC)
        doc_id = self._settings_doc_id(assistant_id, scope, scope_id)

        current_values = await self.get_settings(assistant_id, scope=scope, scope_id=scope_id)
        current_values[field_id] = value

        doc = {
            "id": doc_id,
            "assistant_id": assistant_id,
            "scope": scope,
            "scope_id": scope_id,
            "values": current_values,
            "updated_at": now.isoformat(),
        }

        await container.upsert_item(doc)
        return now

    async def set_settings(
        self, assistant_id: str, values: dict[str, Any], scope: str = "", scope_id: str = ""
    ) -> datetime:
        container = self._get_container("settings")
        now = datetime.now(UTC)
        doc_id = self._settings_doc_id(assistant_id, scope, scope_id)

        doc = {
            "id": doc_id,
            "assistant_id": assistant_id,
            "scope": scope,
            "scope_id": scope_id,
            "values": values,
            "updated_at": now.isoformat(),
        }

        await container.upsert_item(doc)
        return now

    async def insert_analytics(self, events: list[AnalyticsEventPayload]) -> None:
        if not events:
            return

        container = self._get_container("analytics")
        for ev in events:
            doc = {
                "id": str(uuid.uuid4()),
                "assistant_id": ev.assistant_id,
                "event": ev.event,
                "timestamp": ev.timestamp.isoformat(),
                "thread_id": ev.thread_id,
                "user_id": ev.user_id,
                "run_id": ev.run_id,
                "event_id": ev.event_id,
                "data": ev.data,
                "created_at": ev.created_at.isoformat(),
            }
            await container.create_item(doc)
