from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Literal, Protocol

from x64acp.protocol.models import Run, Thread, ThreadEvent

if TYPE_CHECKING:
    from x64acp.analytics.models import AnalyticsEventPayload

__all__ = ["Persistence", "EventOrder"]

EventOrder = Literal["asc", "desc"]


class Persistence(Protocol):
    async def connect(self) -> None: ...
    async def disconnect(self) -> None: ...
    async def migrate(self) -> None: ...
    async def create_thread(self, thread: Thread) -> None: ...
    async def get_thread(self, thread_id: str, assistant_id: str) -> Thread | None: ...
    async def update_thread(self, thread: Thread, assistant_id: str) -> None: ...
    async def list_threads(
        self,
        assistant_id: str,
        user_id: str | None,
        cursor: str | None,
        limit: int,
        scope: str = "member",
        user_email: str | None = None,
        identity_ids: list[str] | None = None,
        tenant_filter: dict[str, Any] | None = None,
        user_filter: dict[str, Any] | None = None,
    ) -> list[Thread]: ...
    async def count_threads(
        self,
        assistant_id: str,
        user_id: str | None,
        scope: str = "member",
        user_email: str | None = None,
        identity_ids: list[str] | None = None,
        tenant_filter: dict[str, Any] | None = None,
        user_filter: dict[str, Any] | None = None,
    ) -> int: ...
    async def delete_thread(self, thread_id: str, assistant_id: str) -> None: ...
    async def create_event(self, event: ThreadEvent) -> None: ...
    async def get_events(
        self,
        thread_id: str,
        assistant_id: str,
        *,
        after_event_id: str | None = None,
        before_event_id: str | None = None,
        limit: int = 50,
        order: EventOrder = "asc",
        filters: dict[str, str] | None = None,
    ) -> list[ThreadEvent]: ...
    async def create_run(self, run: Run, assistant_id: str) -> None: ...
    async def update_run(self, run: Run, assistant_id: str) -> None: ...
    async def get_event(self, event_id: str, assistant_id: str) -> ThreadEvent | None: ...
    async def update_event(self, event: ThreadEvent, assistant_id: str) -> None: ...
    async def delete_event(self, event_id: str, assistant_id: str) -> None: ...
    async def get_run(self, run_id: str, assistant_id: str) -> Run | None: ...
    async def list_runs(
        self,
        assistant_id: str,
        thread_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[Run]: ...
    async def upsert_thread_participant(self, thread_id: str, assistant_id: str, participant: dict) -> None: ...

    async def get_settings(self, assistant_id: str, scope: str = "", scope_id: str = "") -> dict[str, Any]: ...
    async def update_setting(
        self, assistant_id: str, field_id: str, value: Any, scope: str = "", scope_id: str = ""
    ) -> datetime: ...
    async def set_settings(
        self, assistant_id: str, values: dict[str, Any], scope: str = "", scope_id: str = ""
    ) -> datetime: ...

    async def insert_analytics(self, events: list[AnalyticsEventPayload]) -> None: ...
