import json
import logging
import ssl as ssl_module
import uuid
from datetime import UTC, datetime
from typing import Any

import asyncpg  # type: ignore[import-untyped]

from x64acp.analytics.models import AnalyticsEventPayload
from x64acp.protocol.models import (
    Run,
    TenantScope,
    Thread,
    ThreadEvent,
    UserIdentity,
    deserialize_s2c_part,
)

__all__ = ["PostgresPersistence"]

logger = logging.getLogger(__name__)


def _build_ssl_context(ssl_config: bool | str) -> ssl_module.SSLContext | str | None:

    if isinstance(ssl_config, str):
        lower = ssl_config.lower().strip()
        if lower in ("false", "0", "no", "off", "", "disable"):
            return None
        if lower in ("true", "1", "yes", "on", "require"):
            ctx = ssl_module.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl_module.CERT_NONE
            return ctx
        return ssl_config

    if ssl_config is True:
        ctx = ssl_module.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl_module.CERT_NONE
        return ctx

    return None


class PostgresPersistence:
    def __init__(
        self,
        *,
        host: str,
        port: int,
        user: str,
        database: str,
        password: str,
        ssl: bool | str = False,
        table_prefix: str = "assistant_",
    ):
        self._host = host
        self._port = port
        self._user = user
        self._database = database
        self._password = password
        self._ssl = ssl
        self._prefix = table_prefix
        self._pool: asyncpg.Pool | None = None

    async def connect(self) -> None:
        ssl_param = _build_ssl_context(self._ssl)
        ssl_display = self._ssl if isinstance(self._ssl, str) else ("require" if self._ssl else "disabled")
        logger.info(
            "[assistant] connecting to postgresql at %s:%s/%s (user=%s, ssl=%s)",
            self._host,
            self._port,
            self._database,
            self._user,
            ssl_display,
        )
        try:
            self._pool = await asyncpg.create_pool(
                host=self._host,
                port=self._port,
                user=self._user,
                database=self._database,
                password=self._password,
                ssl=ssl_param,
                min_size=1,
                max_size=10,
                timeout=30,
                command_timeout=30,
            )
            logger.info("[assistant] successfully connected to postgresql")
        except TimeoutError:
            logger.error(
                "[assistant] connection to postgresql timed out. host=%s, port=%s, db=%s, ssl=%s. ",
                self._host,
                self._port,
                self._database,
                ssl_display,
            )
            raise
        except OSError as e:
            logger.error(
                "[assistant] cannot reach postgresql at %s:%s - %s. ",
                self._host,
                self._port,
                e,
            )
            raise
        except asyncpg.InvalidPasswordError:
            logger.error(
                "[assistant] authentication failed for user '%s' on database '%s'. ",
                self._user,
                self._database,
            )
            raise
        except Exception as e:
            logger.error(
                "[assistant] failed to connect to postgresql at %s:%s/%s - %s: %s",
                self._host,
                self._port,
                self._database,
                type(e).__name__,
                e,
            )
            raise

    async def disconnect(self) -> None:
        if self._pool:
            await self._pool.close()

    async def migrate(self) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        from x64acp.migrations.schemas import get_migration_sql

        migration_sql = get_migration_sql(self._prefix)

        async with self._pool.acquire() as conn:
            await conn.execute(migration_sql)

    async def create_thread(self, thread: Thread) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}threads"
        owner_user_json = json.dumps(thread.owner_user.model_dump()) if thread.owner_user else None
        owner_tenant_json = json.dumps(thread.owner_tenant.model_dump()) if thread.owner_tenant else None
        participants_json = json.dumps(thread.participants)
        metadata_json = json.dumps(thread.metadata) if thread.metadata is not None else None

        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                INSERT INTO {table}
                    (id, assistant_id, owner_user, owner_tenant,
                     participants, title, metadata, external,
                     created_at, updated_at, last_event_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
                """,
                thread.id,
                thread.assistant_id,
                owner_user_json,
                owner_tenant_json,
                participants_json,
                thread.title,
                metadata_json,
                thread.external,
                thread.created_at,
                thread.updated_at,
                thread.last_event_at,
            )

    async def get_thread(self, thread_id: str, assistant_id: str) -> Thread | None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}threads"
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                f"SELECT * FROM {table} WHERE id = $1 AND assistant_id = $2",
                thread_id,
                assistant_id,
            )

        if not row:
            return None

        return self._row_to_thread(row)

    def _row_to_thread(self, row: asyncpg.Record) -> Thread:
        owner_user_raw = row.get("owner_user") or {}
        if isinstance(owner_user_raw, str):
            owner_user_raw = json.loads(owner_user_raw)
        owner_user = UserIdentity(**owner_user_raw) if owner_user_raw else None

        owner_tenant_raw = row.get("owner_tenant") or {}
        if isinstance(owner_tenant_raw, str):
            owner_tenant_raw = json.loads(owner_tenant_raw)
        owner_tenant = TenantScope(**owner_tenant_raw) if owner_tenant_raw else None

        participants_data = row.get("participants") or []
        if isinstance(participants_data, str):
            participants_data = json.loads(participants_data)

        metadata_raw = row.get("metadata")
        metadata = None
        if metadata_raw is not None:
            metadata = json.loads(metadata_raw) if isinstance(metadata_raw, str) else metadata_raw

        return Thread(
            id=row["id"],
            assistant_id=row["assistant_id"],
            owner_user=owner_user,
            owner_tenant=owner_tenant,
            participants=participants_data,
            title=row.get("title"),
            external=row.get("external", False),
            metadata=metadata,
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            last_event_at=row["last_event_at"],
        )

    async def update_thread(self, thread: Thread, assistant_id: str) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}threads"
        owner_user_json = json.dumps(thread.owner_user.model_dump()) if thread.owner_user else None
        owner_tenant_json = json.dumps(thread.owner_tenant.model_dump()) if thread.owner_tenant else None
        participants_json = json.dumps(thread.participants)
        metadata_json = json.dumps(thread.metadata) if thread.metadata is not None else None

        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                UPDATE {table}
                SET owner_user = $1, owner_tenant = $2, participants = $3,
                    title = $4, metadata = $5, updated_at = $6, last_event_at = $7
                WHERE id = $8 AND assistant_id = $9
                """,
                owner_user_json,
                owner_tenant_json,
                participants_json,
                thread.title,
                metadata_json,
                thread.updated_at,
                thread.last_event_at,
                thread.id,
                assistant_id,
            )

    async def delete_thread(self, thread_id: str, assistant_id: str) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        events_table = f"{self._prefix}events"
        runs_table = f"{self._prefix}runs"
        threads_table = f"{self._prefix}threads"

        async with self._pool.acquire() as conn:
            scope_q = f"SELECT id FROM {threads_table} WHERE id = $1 AND assistant_id = $2"
            await conn.execute(
                f"DELETE FROM {events_table} WHERE thread_id = $1 AND thread_id IN ({scope_q})",
                thread_id,
                assistant_id,
            )
            await conn.execute(
                f"DELETE FROM {runs_table} WHERE thread_id = $1 AND thread_id IN ({scope_q})",
                thread_id,
                assistant_id,
            )
            await conn.execute(
                f"DELETE FROM {threads_table} WHERE id = $1 AND assistant_id = $2",
                thread_id,
                assistant_id,
            )

    def _build_scope_conditions(
        self,
        scope: str,
        user_id: str | None,
        user_email: str | None,
        identity_ids: list[str] | None,
        conditions: list[str],
        params: list,
        idx: int,
        tenant_filter: dict[str, Any] | None = None,
        user_filter: dict[str, Any] | None = None,
    ) -> int:
        if tenant_filter:
            conditions.append(f"owner_tenant @> ${idx}::jsonb")
            params.append(json.dumps(tenant_filter))
            idx += 1
        if user_filter:
            conditions.append(f"owner_user @> ${idx}::jsonb")
            params.append(json.dumps(user_filter))
            idx += 1
        if scope == "member":
            if identity_ids:
                or_parts: list[str] = []
                for uid in identity_ids:
                    or_parts.append(f"participants @> ${idx}::jsonb")
                    params.append(json.dumps([{"user": {"id": uid}}]))
                    idx += 1
                or_parts.append(f"""EXISTS (
                    SELECT 1 FROM jsonb_array_elements(participants) AS p,
                    jsonb_array_elements_text(COALESCE(p->'user'->'identity_ids', '[]'::jsonb)) AS iid
                    WHERE iid = ANY(${idx}::text[])
                )""")
                params.append(identity_ids)
                idx += 1
                conditions.append(f"({' OR '.join(or_parts)})")
            elif user_id:
                conditions.append(f"participants @> ${idx}::jsonb")
                params.append(json.dumps([{"user": {"id": user_id}}]))
                idx += 1
            elif user_email:
                conditions.append(f"participants @> ${idx}::jsonb")
                params.append(json.dumps([{"user": {"email": user_email}}]))
                idx += 1
        return idx

    async def count_threads(
        self,
        assistant_id: str,
        user_id: str | None,
        scope: str = "member",
        user_email: str | None = None,
        identity_ids: list[str] | None = None,
        tenant_filter: dict[str, Any] | None = None,
        user_filter: dict[str, Any] | None = None,
    ) -> int:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}threads"
        conditions: list[str] = ["assistant_id = $1"]
        params: list[Any] = [assistant_id]
        idx = 2

        idx = self._build_scope_conditions(
            scope,
            user_id,
            user_email,
            identity_ids,
            conditions,
            params,
            idx,
            tenant_filter=tenant_filter,
            user_filter=user_filter,
        )

        where = " AND ".join(conditions)
        query = f"SELECT COUNT(*) FROM {table} WHERE {where}"

        async with self._pool.acquire() as conn:
            return await conn.fetchval(query, *params)

    async def list_threads(
        self,
        assistant_id: str,
        user_id: str | None,
        cursor: str | None,
        limit: int,
        scope: str = "member",
        user_email: str | None = None,
        identity_ids: list[str] | None = None,
        tenant_filter: dict[str, Any] | None = None,
        user_filter: dict[str, Any] | None = None,
    ) -> list[Thread]:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}threads"
        conditions: list[str] = ["assistant_id = $1"]
        params: list[Any] = [assistant_id]
        idx = 2

        idx = self._build_scope_conditions(
            scope,
            user_id,
            user_email,
            identity_ids,
            conditions,
            params,
            idx,
            tenant_filter=tenant_filter,
            user_filter=user_filter,
        )

        if cursor:
            if "|" in cursor:
                cursor_ts, cursor_id = cursor.rsplit("|", 1)
                conditions.append(f"(last_event_at < ${idx} OR (last_event_at = ${idx} AND id < ${idx + 1}))")
                params.append(datetime.fromisoformat(cursor_ts))
                params.append(cursor_id)
                idx += 2
            else:
                conditions.append(f"last_event_at < ${idx}")
                params.append(datetime.fromisoformat(cursor))
                idx += 1

        params.append(limit)
        where = " AND ".join(conditions)

        query = f"""
            SELECT * FROM {table}
            WHERE {where}
            ORDER BY last_event_at DESC, id DESC
            LIMIT ${idx}
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, *params)

        return [self._row_to_thread(row) for row in rows]

    async def create_event(self, event: ThreadEvent) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}events"
        content_json = None
        if event.content:
            content_json = json.dumps([self._serialize_content_part(p) for p in event.content])

        data_json = json.dumps(event.data) if event.data else None
        actor_val = event.actor if event.actor else "system"
        role_val = event.role or "system"
        user_json = json.dumps(event.user.model_dump()) if event.user else None
        tenant_json = json.dumps(event.tenant.model_dump()) if event.tenant else None

        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                INSERT INTO {table}
                    (id, thread_id, run_id, type, role, actor, display_name,
                     "user", tenant, content, data, assistant_id, command,
                     client_event_id, created_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
                ON CONFLICT (id) DO NOTHING
                """,
                event.id,
                event.thread_id,
                event.run_id,
                event.type,
                role_val,
                actor_val,
                event.display_name,
                user_json,
                tenant_json,
                content_json,
                data_json,
                event.assistant_id,
                event.command,
                event.client_event_id,
                event.created_at,
            )

    async def get_events(
        self,
        thread_id: str,
        assistant_id: str,
        *,
        after_event_id: str | None = None,
        before_event_id: str | None = None,
        limit: int = 50,
        order: str = "asc",
        filters: dict[str, str] | None = None,
    ) -> list[ThreadEvent]:
        if not self._pool:
            raise RuntimeError("Not connected")

        from x64acp.variables import variables

        table = f"{self._prefix}events"
        threads_table = f"{self._prefix}threads"
        conditions = [
            "thread_id = $1",
            f"thread_id IN (SELECT id FROM {threads_table} WHERE id = $1 AND assistant_id = $2)",
        ]
        params: list[Any] = [thread_id, assistant_id]
        idx = 3

        if after_event_id:
            async with self._pool.acquire() as conn:
                ref_row = await conn.fetchrow(f"SELECT created_at, id FROM {table} WHERE id = $1", after_event_id)
            if ref_row:
                if order == "desc":
                    conditions.append(f"(created_at < ${idx} OR (created_at = ${idx} AND id < ${idx + 1}))")
                else:
                    conditions.append(f"(created_at > ${idx} OR (created_at = ${idx} AND id > ${idx + 1}))")
                params.append(ref_row["created_at"])
                params.append(ref_row["id"])
                idx += 2

        if before_event_id:
            async with self._pool.acquire() as conn:
                ref_row = await conn.fetchrow(f"SELECT created_at, id FROM {table} WHERE id = $1", before_event_id)
            if ref_row:
                conditions.append(f"(created_at < ${idx} OR (created_at = ${idx} AND id < ${idx + 1}))")
                params.append(ref_row["created_at"])
                params.append(ref_row["id"])
                idx += 2

        if filters:
            for key, value in filters.items():
                if key in variables.filterable_fields:
                    conditions.append(f"{key} = ${idx}")
                    params.append(value)
                    idx += 1

        direction = "DESC" if order == "desc" else "ASC"
        where = " AND ".join(conditions)
        params.append(limit)

        query = f"SELECT * FROM {table} WHERE {where} ORDER BY created_at {direction}, id {direction} LIMIT ${idx}"

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, *params)

        return [self._row_to_event(row) for row in rows]

    def _row_to_event(self, row) -> ThreadEvent:
        content = None
        if row["content"]:
            content_raw = row["content"]
            content_data = json.loads(content_raw) if isinstance(content_raw, str) else content_raw
            content = [self._deserialize_content_part(p) for p in content_data]

        data_raw = row.get("data")
        data = None
        if data_raw:
            data = json.loads(data_raw) if isinstance(data_raw, str) else data_raw

        user_raw = row.get("user") or {}
        if isinstance(user_raw, str):
            user_raw = json.loads(user_raw)
        user = UserIdentity(**user_raw) if user_raw else None

        tenant_raw = row.get("tenant") or {}
        if isinstance(tenant_raw, str):
            tenant_raw = json.loads(tenant_raw)
        tenant = TenantScope(**tenant_raw) if tenant_raw else None

        return ThreadEvent(
            id=row["id"],
            thread_id=row["thread_id"],
            run_id=row.get("run_id"),
            type=row["type"],
            role=row.get("role", "system"),
            actor=row["actor"],
            display_name=row.get("display_name"),
            user=user,
            tenant=tenant,
            content=content,
            data=data,
            assistant_id=row.get("assistant_id"),
            command=row.get("command"),
            client_event_id=row.get("client_event_id"),
            created_at=row["created_at"],
        )

    async def upsert_thread_participant(self, thread_id: str, assistant_id: str, participant: dict) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        user_data = participant.get("user") or {}
        user_id = user_data.get("id")
        if not user_id:
            return

        table = f"{self._prefix}threads"
        participant_json = json.dumps(participant)
        containment_check = json.dumps([{"user": {"id": user_id}}])

        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                UPDATE {table}
                SET participants = (
                    CASE
                        WHEN NOT participants @> $2::jsonb
                        THEN participants || $3::jsonb
                        ELSE (
                            SELECT jsonb_agg(
                                CASE
                                    WHEN elem->'user'->>'id' = $4 THEN $3::jsonb
                                    ELSE elem
                                END
                            )
                            FROM jsonb_array_elements(participants) elem
                        )
                    END
                ),
                updated_at = NOW()
                WHERE id = $1 AND assistant_id = $5
                """,
                thread_id,
                containment_check,
                participant_json,
                user_id,
                assistant_id,
            )

    async def create_run(self, run: Run, assistant_id: str) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}runs"
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                INSERT INTO {table} (id, thread_id, assistant_id, blueprint_id, status, started_at, ended_at, error)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                """,
                run.id,
                run.thread_id,
                assistant_id,
                run.blueprint_id,
                run.status,
                run.started_at,
                run.ended_at,
                run.error,
            )

    async def update_run(self, run: Run, assistant_id: str) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}runs"
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                UPDATE {table}
                SET blueprint_id = $1, status = $2, ended_at = $3, error = $4
                WHERE id = $5 AND assistant_id = $6
                """,
                run.blueprint_id,
                run.status,
                run.ended_at,
                run.error,
                run.id,
                assistant_id,
            )

    async def get_event(self, event_id: str, assistant_id: str) -> ThreadEvent | None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}events"
        threads_table = f"{self._prefix}threads"
        query = (
            f"SELECT e.* FROM {table} e"
            f" JOIN {threads_table} t ON e.thread_id = t.id"
            f" WHERE e.id = $1 AND t.assistant_id = $2"
        )
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(query, event_id, assistant_id)
        if not row:
            return None
        return self._row_to_event(row)

    async def update_event(self, event: ThreadEvent, assistant_id: str) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}events"
        threads_table = f"{self._prefix}threads"
        content_json = None
        if event.content:
            content_json = json.dumps([self._serialize_content_part(p) for p in event.content])

        scope_q = f"SELECT id FROM {threads_table} WHERE assistant_id = $3"
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"UPDATE {table} SET content = $1 WHERE id = $2 AND thread_id IN ({scope_q})",
                content_json,
                event.id,
                assistant_id,
            )

    async def delete_event(self, event_id: str, assistant_id: str) -> None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}events"
        threads_table = f"{self._prefix}threads"
        scope_q = f"SELECT id FROM {threads_table} WHERE assistant_id = $2"
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"DELETE FROM {table} WHERE id = $1 AND thread_id IN ({scope_q})",
                event_id,
                assistant_id,
            )

    async def get_run(self, run_id: str, assistant_id: str) -> Run | None:
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}runs"
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                f"SELECT * FROM {table} WHERE id = $1 AND assistant_id = $2",
                run_id,
                assistant_id,
            )
        if not row:
            return None
        return Run(
            id=row["id"],
            thread_id=row["thread_id"],
            blueprint_id=row.get("blueprint_id"),
            status=row["status"],
            started_at=row["started_at"],
            ended_at=row["ended_at"],
            error=row["error"],
        )

    async def list_runs(
        self,
        assistant_id: str,
        thread_id: str | None = None,
        status: str | None = None,
        limit: int = 50,
    ) -> list[Run]:
        if not self._pool:
            raise RuntimeError("Not connected")

        runs_table = f"{self._prefix}runs"
        conditions: list[str] = [f"assistant_id = ${1}"]
        params: list[Any] = [assistant_id]
        idx = 2

        if thread_id:
            conditions.append(f"thread_id = ${idx}")
            params.append(thread_id)
            idx += 1
        if status:
            conditions.append(f"status = ${idx}")
            params.append(status)
            idx += 1

        where = f"WHERE {' AND '.join(conditions)}"
        params.append(limit)

        query = f"""
            SELECT * FROM {runs_table}
            {where}
            ORDER BY started_at DESC
            LIMIT ${idx}
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, *params)

        return [
            Run(
                id=row["id"],
                thread_id=row["thread_id"],
                blueprint_id=row.get("blueprint_id"),
                status=row["status"],
                started_at=row["started_at"],
                ended_at=row["ended_at"],
                error=row["error"],
            )
            for row in rows
        ]

    def _serialize_content_part(self, part) -> dict:
        if hasattr(part, "model_dump"):
            return part.model_dump()
        return dict(part)

    def _deserialize_content_part(self, data: dict):
        return deserialize_s2c_part(data)

    async def get_settings(self, assistant_id: str, scope: str = "", scope_id: str = "") -> dict[str, Any]:
        """Get all stored values for an assistant. Returns empty dict if none."""
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}settings"
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                f"SELECT values FROM {table} WHERE assistant_id = $1 AND scope = $2 AND scope_id = $3",
                assistant_id,
                scope,
                scope_id,
            )

        if not row:
            return {}

        values = row["values"]
        if isinstance(values, str):
            return json.loads(values)
        return values

    async def update_setting(
        self, assistant_id: str, field_id: str, value: Any, scope: str = "", scope_id: str = ""
    ) -> datetime:
        """Update a single field value. Returns updated_at timestamp."""
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}settings"
        now = datetime.now(UTC)

        current_values = await self.get_settings(assistant_id, scope=scope, scope_id=scope_id)
        current_values[field_id] = value
        values_json = json.dumps(current_values)

        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                INSERT INTO {table} (assistant_id, scope, scope_id, values, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6)
                ON CONFLICT(assistant_id, scope, scope_id) DO UPDATE SET
                    values = EXCLUDED.values,
                    updated_at = EXCLUDED.updated_at
                """,
                assistant_id,
                scope,
                scope_id,
                values_json,
                now,
                now,
            )
        return now

    async def set_settings(
        self, assistant_id: str, values: dict[str, Any], scope: str = "", scope_id: str = ""
    ) -> datetime:
        """Replace all settings values. Returns updated_at timestamp."""
        if not self._pool:
            raise RuntimeError("Not connected")

        table = f"{self._prefix}settings"
        now = datetime.now(UTC)
        values_json = json.dumps(values)

        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                INSERT INTO {table} (assistant_id, scope, scope_id, values, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6)
                ON CONFLICT(assistant_id, scope, scope_id) DO UPDATE SET
                    values = EXCLUDED.values,
                    updated_at = EXCLUDED.updated_at
                """,
                assistant_id,
                scope,
                scope_id,
                values_json,
                now,
                now,
            )
        return now

    async def insert_analytics(self, events: list[AnalyticsEventPayload]) -> None:
        if not self._pool or not events:
            return

        table = f"{self._prefix}analytics"
        data_json: str | None
        async with self._pool.acquire() as conn:
            for ev in events:
                data_json = json.dumps(ev.data) if ev.data else None
                await conn.execute(
                    f"""
                    INSERT INTO {table}
                        (id, event, timestamp, assistant_id, thread_id, user_id, run_id, event_id,
                         data, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                    """,
                    str(uuid.uuid4()),
                    ev.event,
                    ev.timestamp,
                    ev.assistant_id,
                    ev.thread_id,
                    ev.user_id,
                    ev.run_id,
                    ev.event_id,
                    data_json,
                    ev.created_at,
                )
