from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from x64acp.protocol.frames import (
    EventAppendPayload,
    S2C_EventAppend,
    S2C_ThreadUpsert,
    ThreadUpsertPayload,
)
from x64acp.protocol.models import TenantScope, Thread, ThreadEvent, UserIdentity, WireS2C_ContentPart
from x64acp.protocol.parser import serialize_frame

__all__ = ["BroadcastManager"]

if TYPE_CHECKING:
    from x64acp.persistence.base import Persistence
    from x64acp.registry import ConnectionRegistry


def _generate_id() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(UTC)


class BroadcastManager:
    def __init__(
        self,
        registry: ConnectionRegistry,
        persistence: Persistence,
        subscriptions: dict[str, set[str]],
    ) -> None:
        self._registry = registry
        self._persistence = persistence
        self._subscriptions = subscriptions

    async def send_event(
        self,
        assistant_id: str,
        thread_id: str,
        content: list[WireS2C_ContentPart],
        actor: str = "system",
        user: UserIdentity | None = None,
        tenant: TenantScope | None = None,
        role: str = "system",
    ) -> tuple[ThreadEvent, int]:
        thread = await self._persistence.get_thread(thread_id, assistant_id)
        if not thread:
            raise ValueError(f"Thread {thread_id} not found")

        now = _now()

        event = ThreadEvent(
            id=_generate_id(),
            thread_id=thread_id,
            run_id=None,
            type="message",
            role=role,
            actor=actor,
            user=user,
            tenant=tenant,
            content=content,
            data=None,
            created_at=now,
        )

        await self._persistence.create_event(event)

        thread.last_event_at = now
        thread.updated_at = now
        await self._persistence.update_thread(thread, assistant_id)

        frame = S2C_EventAppend(
            id=_generate_id(),
            payload=EventAppendPayload(thread_id=thread_id, events=[event]),
        )
        message = serialize_frame(frame)
        count = await self._registry.broadcast(assistant_id, message)

        return event, count

    async def send_thread_update(
        self,
        assistant_id: str,
        thread: Thread,
    ) -> int:
        frame = S2C_ThreadUpsert(
            id=_generate_id(),
            payload=ThreadUpsertPayload(thread=thread),
        )
        message = serialize_frame(frame)
        return await self._registry.broadcast(assistant_id, message)

    async def create_thread_and_broadcast(
        self,
        assistant_id: str,
        user: UserIdentity | None = None,
        tenant: TenantScope | None = None,
        title: str | None = None,
    ) -> tuple[Thread, int]:
        now = _now()
        participant: dict = {}
        if user:
            participant["user"] = user.model_dump()
        if tenant:
            participant["tenant"] = tenant.model_dump()
        thread = Thread(
            id=_generate_id(),
            assistant_id=assistant_id,
            owner_user=user,
            owner_tenant=tenant,
            participants=[participant] if participant else [],
            title=title,
            created_at=now,
            updated_at=now,
            last_event_at=now,
        )

        await self._persistence.create_thread(thread)

        frame = S2C_ThreadUpsert(
            id=_generate_id(),
            payload=ThreadUpsertPayload(thread=thread),
        )
        message = serialize_frame(frame)
        count = await self._registry.broadcast(assistant_id, message)

        return thread, count
