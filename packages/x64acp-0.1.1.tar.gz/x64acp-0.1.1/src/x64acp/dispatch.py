from __future__ import annotations

from collections.abc import AsyncGenerator
from typing import TYPE_CHECKING

from x64acp.handlers.send import AssistantEvent

__all__ = ["DispatchStream"]

if TYPE_CHECKING:
    from x64acp.handlers.pipeline import AssistantHandlerContext, AssistantHandlerPipeline, PipelineResult


class DispatchStream:
    """Async-iterable stream of handler events from a programmatic dispatch.

    Properties ``thread_id``, ``event_id``, and ``is_new_thread`` are
    available immediately (before iteration), because the pipeline setup
    phase runs before this object is returned.
    """

    def __init__(
        self,
        pipeline: AssistantHandlerPipeline,
        context: AssistantHandlerContext,
        result: PipelineResult,
    ) -> None:
        self._pipeline = pipeline
        self._context = context
        self._result = result

    @property
    def thread_id(self) -> str:
        return self._result.thread.id

    @property
    def event_id(self) -> str:
        return self._result.user_event.id

    @property
    def is_new_thread(self) -> bool:
        return self._result.is_new_thread

    def __aiter__(self) -> AsyncGenerator[AssistantEvent, None]:
        return self._pipeline.execute(self._context, self._result)

    async def collect(self) -> list[AssistantEvent]:
        events: list[AssistantEvent] = []
        async for event in self:
            events.append(event)
        return events
