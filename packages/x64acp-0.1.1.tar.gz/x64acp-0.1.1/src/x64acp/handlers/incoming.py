from dataclasses import dataclass
from typing import Literal

from x64acp.handlers.context import AssistantContext
from x64acp.protocol.models import AssistantIdentity, ContentPart, UserIdentity

__all__ = ["AssistantIncoming"]


@dataclass
class AssistantIncoming:
    message: str
    content: list[ContentPart]
    context: AssistantContext

    event_type: str = "message"
    target_assistant_id: str | None = None
    command: str | None = None
    audience: Literal["user", "assistant"] | None = None
    data: dict | None = None

    role: str = "user"
    actor: str = "user"
    user: UserIdentity | None = None
    assistant: AssistantIdentity | None = None

    form_data: dict | None = None
    form_cancelled: bool = False
    form_event_id: str | None = None
