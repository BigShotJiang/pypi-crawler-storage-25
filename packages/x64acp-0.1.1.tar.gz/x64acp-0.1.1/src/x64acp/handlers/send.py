import uuid
from dataclasses import dataclass
from typing import Literal

from x64acp.protocol.models import (
    FormCheckboxInput,
    FormFileInput,
    FormOption,
    FormPart,
    FormRadioInput,
    FormSelectInput,
    FormTextareaInput,
    FormTextInput,
)

__all__ = ["AssistantSend", "AssistantEvent"]


@dataclass
class AssistantEvent:
    send_type: str
    data: dict


class AssistantSend:
    def text(self, text: str, data: dict | None = None) -> AssistantEvent:
        payload: dict = {"text": text}
        if data:
            payload["meta"] = data
        return AssistantEvent(
            send_type="text",
            data=payload,
        )

    def image(
        self,
        url: str,
        mime_type: str | None = None,
        alt: str | None = None,
    ) -> AssistantEvent:
        return AssistantEvent(
            send_type="image",
            data={"url": url, "mime_type": mime_type, "alt": alt},
        )

    def document(
        self,
        url: str,
        filename: str,
        mime_type: str,
    ) -> AssistantEvent:
        return AssistantEvent(
            send_type="document",
            data={"url": url, "filename": filename, "mime_type": mime_type},
        )

    def audio(
        self,
        url: str,
        mime_type: str,
        duration: float | None = None,
    ) -> AssistantEvent:
        return AssistantEvent(
            send_type="audio",
            data={"url": url, "mime_type": mime_type, "duration": duration},
        )

    def tool_call(
        self,
        name: str,
        args: dict,
        display_name: str | None = None,
        id: str | None = None,
    ) -> AssistantEvent:
        return AssistantEvent(
            send_type="tool_call",
            data={
                "id": id or str(uuid.uuid4()),
                "name": name,
                "display_name": display_name,
                "args": args,
            },
        )

    def tool_result(
        self,
        name: str,
        result: dict,
        args: dict | None = None,
        display_name: str | None = None,
        id: str | None = None,
    ) -> AssistantEvent:
        return AssistantEvent(
            send_type="tool_result",
            data={
                "id": id or str(uuid.uuid4()),
                "name": name,
                "display_name": display_name,
                "args": args,
                "result": result,
            },
        )

    def tool_transaction(
        self,
        name: str,
        args: dict,
        result: dict,
        display_name: str | None = None,
        id: str | None = None,
    ) -> AssistantEvent:
        return AssistantEvent(
            send_type="tool_transaction",
            data={
                "id": id or str(uuid.uuid4()),
                "name": name,
                "display_name": display_name,
                "args": args,
                "result": result,
            },
        )

    def run_start(self, blueprint_id: str | None = None) -> AssistantEvent:
        return AssistantEvent(
            send_type="run_start",
            data={"blueprint_id": blueprint_id},
        )

    def run_end(
        self,
        status: Literal["succeeded", "failed"] = "succeeded",
        error: str | None = None,
    ) -> AssistantEvent:
        return AssistantEvent(
            send_type="run_end",
            data={"status": status, "error": error},
        )

    def update_user_event(self, event_id: str, content: list[dict]) -> AssistantEvent:
        return AssistantEvent(
            send_type="event_update",
            data={"event_id": event_id, "content": content},
        )

    def update_thread(self, *, title: str | None = None, metadata: dict | None = None) -> AssistantEvent:
        return AssistantEvent(
            send_type="thread_update",
            data={"title": title, "metadata": metadata},
        )

    def confirmation(
        self,
        confirmation_id: str,
        action_type: str,
        blocking: bool,
        summary: str,
        details: dict | None = None,
    ) -> AssistantEvent:
        return AssistantEvent(
            send_type="confirmation",
            data={
                "confirmation_id": confirmation_id,
                "action_type": action_type,
                "blocking": blocking,
                "summary": summary,
                "details": details or {},
            },
        )

    def analysis(
        self,
        kind: str,
        metadata: dict,
        *,
        text: str | None = None,
    ) -> AssistantEvent:
        """Send a structured analysis event.

        Args:
            kind: Application-defined type (e.g. "intake", "compliance", "sentiment").
            metadata: Opaque payload — the consuming frontend decides how to render this.
            text: Optional user-readable summary shown as fallback content.
        """
        return AssistantEvent(
            send_type="analysis",
            data={"kind": kind, "metadata": metadata, "text": text},
        )

    def mention(self, assistant_id: str, text: str) -> AssistantEvent:
        return AssistantEvent(
            send_type="mention",
            data={"assistant_id": assistant_id, "text": text},
        )

    def skill_invoke(self, assistant_id: str, command: str, args: str | None = None) -> AssistantEvent:
        return AssistantEvent(
            send_type="skill_invoke",
            data={"assistant_id": assistant_id, "command": command, "args": args},
        )

    # -- Form builders -------------------------------------------------------

    def form_text(
        self,
        name: str,
        label: str,
        *,
        order: int = 0,
        required: bool = False,
        disabled: bool = False,
        placeholder: str | None = None,
        default: str | None = None,
        input_type: Literal["text", "password", "email", "number"] = "text",
    ) -> FormTextInput:
        return FormTextInput(
            name=name,
            label=label,
            order=order,
            required=required,
            disabled=disabled,
            placeholder=placeholder,
            default=default,
            input_type=input_type,
        )

    def form_textarea(
        self,
        name: str,
        label: str,
        *,
        order: int = 0,
        required: bool = False,
        disabled: bool = False,
        placeholder: str | None = None,
        default: str | None = None,
        rows: int | None = None,
    ) -> FormTextareaInput:
        return FormTextareaInput(
            name=name,
            label=label,
            order=order,
            required=required,
            disabled=disabled,
            placeholder=placeholder,
            default=default,
            rows=rows,
        )

    def form_select(
        self,
        name: str,
        label: str,
        options: list[FormOption],
        *,
        order: int = 0,
        required: bool = False,
        disabled: bool = False,
        placeholder: str | None = None,
        default: str | None = None,
    ) -> FormSelectInput:
        return FormSelectInput(
            name=name,
            label=label,
            options=options,
            order=order,
            required=required,
            disabled=disabled,
            placeholder=placeholder,
            default=default,
        )

    def form_radio(
        self,
        name: str,
        label: str,
        options: list[FormOption],
        *,
        order: int = 0,
        required: bool = False,
        disabled: bool = False,
        default: str | None = None,
        variant: Literal["native", "button"] = "native",
    ) -> FormRadioInput:
        return FormRadioInput(
            name=name,
            label=label,
            options=options,
            order=order,
            required=required,
            disabled=disabled,
            default=default,
            variant=variant,
        )

    def form_checkbox(
        self,
        name: str,
        label: str,
        options: list[FormOption],
        *,
        order: int = 0,
        required: bool = False,
        disabled: bool = False,
        default: list[str] | None = None,
        variant: Literal["native", "button"] = "native",
    ) -> FormCheckboxInput:
        return FormCheckboxInput(
            name=name,
            label=label,
            options=options,
            order=order,
            required=required,
            disabled=disabled,
            default=default,
            variant=variant,
        )

    def form_file(
        self,
        name: str,
        label: str,
        *,
        upload_url: str | None = None,
        order: int = 0,
        required: bool = False,
        disabled: bool = False,
        accept: str | None = None,
        multiple: bool = False,
    ) -> FormFileInput:
        return FormFileInput(
            name=name,
            label=label,
            upload_url=upload_url,
            order=order,
            required=required,
            disabled=disabled,
            accept=accept,
            multiple=multiple,
        )

    def form(
        self,
        message: str,
        elements: list[FormPart],
        submit_label: str = "Send",
        cancel_label: str = "Cancel",
        size: Literal["small", "medium", "large"] = "medium",
    ) -> AssistantEvent:
        return AssistantEvent(
            send_type="form",
            data={
                "message": message,
                "elements": [e.model_dump(exclude_none=True) for e in elements],
                "submit_label": submit_label,
                "cancel_label": cancel_label,
                "size": size,
            },
        )
