from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Protocol, cast

from x64acp.config import Knowledge
from x64acp.exceptions import AssistantHandlerError
from x64acp.handlers.knowledge import AssistantKnowledge
from x64acp.handlers.pipeline import (
    AssistantHandler,
    AssistantHandlerContext,
    AssistantHandlerPipeline,
    PipelineResult,
    UploadReferenceError,
)
from x64acp.persistence.base import Persistence
from x64acp.protocol.frames import (
    AckPayload,
    C2S_AnalyticsSubscribe,
    C2S_AnalyticsUnsubscribe,
    C2S_Connect,
    C2S_EventCreate,
    C2S_EventList,
    C2S_ExternalEvent,
    C2S_Feedback,
    C2S_KnowledgeSelect,
    C2S_ParticipantsAdd,
    C2S_ParticipantsRemove,
    C2S_SettingsPatch,
    C2S_SettingsSubscribe,
    C2S_SettingsUnsubscribe,
    C2S_ThreadCreate,
    C2S_ThreadDelete,
    C2S_ThreadJoin,
    C2S_ThreadList,
    C2S_ThreadPatch,
    C2S_ThreadSubscribe,
    C2S_ThreadUnsubscribe,
    ClientToServer,
    EventAppendPayload,
    EventListResultPayload,
    FeedbackAckPayload,
    KnowledgePayload,
    KnowledgeSelectedPayload,
    RunUpsertPayload,
    S2C_Ack,
    S2C_EventAppend,
    S2C_EventListResult,
    S2C_FeedbackAck,
    S2C_KnowledgeSelected,
    S2C_RunUpsert,
    S2C_ThreadDeleted,
    S2C_ThreadListResult,
    S2C_ThreadSnapshot,
    S2C_ThreadUpsert,
    ServerFeaturesPayload,
    ServerToClient,
    SkillPayload,
    ThreadDeletedPayload,
    ThreadListResultPayload,
    ThreadSnapshotPayload,
    ThreadUpsertPayload,
)
from x64acp.protocol.models import (
    AssistantIdentity,
    EventType,
    TenantScope,
    Thread,
    ThreadEvent,
    UserIdentity,
    WireC2S_ContentPart,
    WireS2C_ContentPart,
    deserialize_s2c_part,
)
from x64acp.protocol.parser import serialize_frame
from x64acp.registry import ConnectionRegistry

if TYPE_CHECKING:
    from x64acp.analytics.collector import AnalyticsCollector
    from x64acp.auth import Authentication, Authorization, AuthorizationResult
    from x64acp.persistence.upload import UploadStore
    from x64acp.settings.broadcaster import SettingsBroadcaster
    from x64acp.settings.models import SettingsSchema

logger = logging.getLogger("assistants")

__all__ = ["Router"]


class WebSocketProtocol(Protocol):
    async def receive_text(self) -> str: ...
    async def send_text(self, data: str) -> None: ...
    async def close(self, code: int = 1000) -> None: ...


def resolve_scope(tenant: TenantScope | None) -> str:
    if tenant is None:
        return "member"
    system_role = getattr(tenant, "system_role", "user")
    organization_role = getattr(tenant, "organization_role", "member")
    team_role = getattr(tenant, "team_role", "member")
    if system_role == "admin":
        return "admin"
    if organization_role in ("owner", "manager"):
        return "organization"
    if team_role == "manager":
        return "team"
    return "member"


def _generate_id() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(UTC)


class Router:
    def __init__(
        self,
        persistence: Persistence,
        handler: AssistantHandler,
        registry: ConnectionRegistry,
        subscriptions: dict[str, set[str]],
        analytics_collector: AnalyticsCollector | None = None,
        settings_broadcaster: SettingsBroadcaster | None = None,
        settings_schema: SettingsSchema | None = None,
        assistant_name: str = "Assistant",
        analytics_subscriptions: dict[str, set[str]] | None = None,
        settings_subscriptions: dict[str, set[str]] | None = None,
        upload_store: UploadStore | None = None,
        skills: list[dict] | None = None,
        knowledge: list[Knowledge] | None = None,
        authentication: Authentication | None = None,
        authorization: Authorization | None = None,
    ):
        self._persistence = persistence
        self._handler = handler
        self._registry = registry
        self._subscriptions = subscriptions

        self._analytics_collector = analytics_collector
        self._settings_broadcaster = settings_broadcaster
        self._settings_schema = settings_schema
        self._assistant_name = assistant_name
        self._skills = skills
        self._authentication = authentication
        self._authorization = authorization
        self._upload_enabled = upload_store is not None
        self._knowledge_sources = knowledge or []
        self._analytics_subscriptions = analytics_subscriptions if analytics_subscriptions is not None else {}
        self._settings_subscriptions = settings_subscriptions if settings_subscriptions is not None else {}

        self._ws: WebSocketProtocol | None = None
        self._ws_id: str = _generate_id()
        self._assistant_id: str | None = None
        self._user: UserIdentity | None = None
        self._assistant: AssistantIdentity | None = None
        self._tenant: TenantScope | None = None
        self._subscribed_threads: set[str] = set()
        self._settings_sub_keys: set[str] = set()

        self._knowledge = AssistantKnowledge(
            _sources=self._knowledge_sources,
        )

        self._pipeline = AssistantHandlerPipeline(
            persistence=persistence,
            broadcast_callback=self._broadcast_to_assistant_dict,
            analytics_collector=analytics_collector,
            settings_broadcaster=settings_broadcaster,
            settings_schema=settings_schema,
            assistant_name=assistant_name,
            upload_store=upload_store,
        )

    def _build_participant(self) -> dict:
        """Build a participant dict from the connection's user/tenant."""
        result: dict[str, Any] = {}
        if self._user:
            result["user"] = self._user.model_dump()
        if self._tenant:
            result["tenant"] = self._tenant.model_dump()
        return result

    async def _check_authorization(
        self,
        action: str,
        resource: dict | None = None,
    ) -> AuthorizationResult | None:
        """Call the authorization handler if configured. Returns None if no handler or no opinion."""
        if not self._authorization:
            return None
        return await self._authorization.authorize(
            self._user,
            self._tenant or TenantScope(),
            action,
            resource,
        )

    async def _send(self, ws: WebSocketProtocol, frame: ServerToClient) -> None:
        await ws.send_text(serialize_frame(frame))

    async def _send_ack(
        self,
        ws: WebSocketProtocol,
        ack_id: str,
        ok: bool = True,
        error: dict[str, str] | None = None,
        server_features: ServerFeaturesPayload | None = None,
        thread: Thread | None = None,
    ) -> None:
        frame = S2C_Ack(
            id=_generate_id(),
            payload=AckPayload(ack_id=ack_id, ok=ok, error=error, server_features=server_features, thread=thread),
        )
        await self._send(ws, frame)

    async def _broadcast_to_assistant(self, frame: ServerToClient) -> None:
        """Broadcast a frame to all connections for the current assistant."""
        if not self._assistant_id:
            return
        message = serialize_frame(frame)
        await self._registry.broadcast(self._assistant_id, message)

    async def _broadcast_to_assistant_except_self(self, ws: WebSocketProtocol, frame: ServerToClient) -> None:
        """Broadcast a frame to all connections for the current assistant except this one."""
        if not self._assistant_id:
            return
        message = serialize_frame(frame)
        await self._registry.broadcast_except(self._assistant_id, ws, message)

    async def _broadcast_to_assistant_dict(self, assistant_id: str, payload: dict[str, Any]) -> None:
        """Convert a dict payload from the pipeline into S2C frames and broadcast."""
        payload_type = payload.get("type")

        if payload_type == "thread.upsert":
            frame: ServerToClient = S2C_ThreadUpsert(
                id=_generate_id(),
                payload=ThreadUpsertPayload(thread=payload["thread"]),
            )
        elif payload_type == "event.append":
            frame = S2C_EventAppend(
                id=_generate_id(),
                payload=EventAppendPayload(
                    thread_id=payload["thread_id"],
                    events=payload["events"],
                ),
            )
        elif payload_type == "run.upsert":
            frame = S2C_RunUpsert(
                id=_generate_id(),
                payload=RunUpsertPayload(run=payload["run"]),
            )
        else:
            return

        message = serialize_frame(frame)
        await self._registry.broadcast(assistant_id, message)

    async def route(self, ws: WebSocketProtocol, frame: ClientToServer) -> None:
        self._ws = ws
        match frame:
            case C2S_Connect():
                await self._handle_connect(ws, frame)
            case C2S_ThreadList():
                await self._handle_thread_list(ws, frame)
            case C2S_ThreadSubscribe():
                await self._handle_thread_subscribe(ws, frame)
            case C2S_ThreadUnsubscribe():
                await self._handle_thread_unsubscribe(ws, frame)
            case C2S_ThreadCreate():
                await self._handle_thread_create(ws, frame)
            case C2S_ThreadPatch():
                await self._handle_thread_patch(ws, frame)
            case C2S_ThreadDelete():
                await self._handle_thread_delete(ws, frame)
            case C2S_ThreadJoin():
                await self._handle_thread_join(ws, frame)
            case C2S_ExternalEvent():
                await self._handle_event_external(ws, frame)
            case C2S_EventCreate():
                await self._handle_event_create(ws, frame)
            case C2S_EventList():
                await self._handle_event_list(ws, frame)

            case C2S_AnalyticsSubscribe():
                await self._handle_analytics_subscribe(ws, frame)
            case C2S_AnalyticsUnsubscribe():
                await self._handle_analytics_unsubscribe(ws, frame)
            case C2S_Feedback():
                await self._handle_feedback(ws, frame)

            case C2S_SettingsSubscribe():
                await self._handle_settings_subscribe(ws, frame)
            case C2S_SettingsUnsubscribe():
                await self._handle_settings_unsubscribe(ws, frame)
            case C2S_SettingsPatch():
                await self._handle_settings_patch(ws, frame)

            case C2S_KnowledgeSelect():
                await self._handle_knowledge_select(ws, frame)

            case C2S_ParticipantsAdd():
                await self._handle_participants_add(ws, frame)
            case C2S_ParticipantsRemove():
                await self._handle_participants_remove(ws, frame)

    async def _handle_knowledge_select(self, ws: WebSocketProtocol, frame: C2S_KnowledgeSelect) -> None:
        self._knowledge.set_selected(frame.payload.source_ids)
        response = S2C_KnowledgeSelected(
            id=_generate_id(),
            payload=KnowledgeSelectedPayload(source_ids=self._knowledge.selected_sources),
        )
        await self._send(ws, response)

    async def _handle_participants_add(self, ws: WebSocketProtocol, frame: C2S_ParticipantsAdd) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws, frame.id, ok=False, error={"code": "NOT_CONNECTED", "message": "Must connect first"}
            )
            return

        thread_id = frame.payload.thread_id
        thread = await self._persistence.get_thread(thread_id, self._assistant_id)
        if not thread:
            await self._send_ack(ws, frame.id, ok=False, error={"code": "NOT_FOUND", "message": "Thread not found"})
            return

        for participant in frame.payload.participants:
            await self._persistence.upsert_thread_participant(thread_id, self._assistant_id, participant)

        updated = await self._persistence.get_thread(thread_id, self._assistant_id)
        if updated:
            await self._broadcast_to_assistant(
                S2C_ThreadUpsert(id=_generate_id(), payload=ThreadUpsertPayload(thread=updated))
            )

        await self._send_ack(ws, frame.id)

    async def _handle_participants_remove(self, ws: WebSocketProtocol, frame: C2S_ParticipantsRemove) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws, frame.id, ok=False, error={"code": "NOT_CONNECTED", "message": "Must connect first"}
            )
            return

        thread_id = frame.payload.thread_id
        thread = await self._persistence.get_thread(thread_id, self._assistant_id)
        if not thread:
            await self._send_ack(ws, frame.id, ok=False, error={"code": "NOT_FOUND", "message": "Thread not found"})
            return

        remove_set = set(frame.payload.participant_ids)
        thread.participants = [p for p in thread.participants if (p.get("user") or {}).get("id") not in remove_set]
        thread.updated_at = _now()
        await self._persistence.update_thread(thread, self._assistant_id)

        await self._broadcast_to_assistant(
            S2C_ThreadUpsert(id=_generate_id(), payload=ThreadUpsertPayload(thread=thread))
        )

        await self._send_ack(ws, frame.id)

    async def cleanup(self) -> None:
        logger.info(
            "[assistant] router cleanup: ws=%s, assistant=%s, had_analytics_sub=%s",
            self._ws_id,
            self._assistant_id,
            self._ws_id in self._analytics_subscriptions.get(self._assistant_id or "", set()),
        )
        if self._assistant_id:
            if self._ws:
                await self._registry.unregister(self._assistant_id, self._ws)

            if self._assistant_id in self._analytics_subscriptions:
                self._analytics_subscriptions[self._assistant_id].discard(self._ws_id)
                if not self._analytics_subscriptions[self._assistant_id]:
                    logger.info(
                        "[assistant] analytics subscriptions emptied for assistant %s — deleting key",
                        self._assistant_id,
                    )
                    del self._analytics_subscriptions[self._assistant_id]

            for sub_key in self._settings_sub_keys:
                if sub_key in self._settings_subscriptions:
                    self._settings_subscriptions[sub_key].discard(self._ws_id)
                    if not self._settings_subscriptions[sub_key]:
                        del self._settings_subscriptions[sub_key]

        if self._ws_id in self._subscriptions:
            del self._subscriptions[self._ws_id]

    async def _handle_connect(self, ws: WebSocketProtocol, frame: C2S_Connect) -> None:
        logger.debug(
            "[assistant] connect: assistant_id=%s, user=%s",
            frame.payload.assistant_id,
            frame.payload.user.id if frame.payload.user else "none",
        )
        self._assistant_id = frame.payload.assistant_id
        self._user = frame.payload.user
        self._assistant = frame.payload.assistant
        self._tenant = frame.payload.tenant
        self._ws = ws

        # If authentication is configured, validate the token
        if self._authentication:
            validated_user = await self._authentication.authenticate(
                frame.payload.auth_token or "",
                frame.payload.user,
            )
            if validated_user is None:
                await self._send_ack(
                    ws,
                    frame.id,
                    ok=False,
                    error={"code": "UNAUTHORIZED", "message": "Authentication failed"},
                )
                return
            # Override client-sent user with validated identity
            self._user = validated_user

        await self._registry.register(self._assistant_id, ws)

        self._subscriptions[self._ws_id] = set()

        skill_payloads = (
            [SkillPayload(command=s["command"], description=s["description"]) for s in self._skills]
            if self._skills
            else None
        )

        knowledge_payloads = (
            [
                KnowledgePayload(id=s.id, name=s.name, scope=s.scope, description=s.description)
                for s in self._knowledge_sources
            ]
            if self._knowledge_sources
            else None
        )

        server_features = ServerFeaturesPayload(
            assistant_name=self._assistant_name,
            analytics_enabled=self._analytics_collector is not None,
            settings_enabled=self._settings_schema is not None,
            skills_enabled=bool(self._skills),
            upload_enabled=self._upload_enabled,
            knowledge_enabled=bool(self._knowledge_sources),
            skills=skill_payloads,
            knowledge=knowledge_payloads,
        )

        await self._send_ack(ws, frame.id, server_features=server_features)

    async def _handle_thread_list(self, ws: WebSocketProtocol, frame: C2S_ThreadList) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        # Authorization
        auth_result = await self._check_authorization("thread.list")
        if auth_result is not None and not auth_result.allowed:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": auth_result.reason or "Access denied"},
            )
            return

        user = self._user
        user_id = user.id if user else ""
        user_email = getattr(user, "email", None) if user else None
        scope = resolve_scope(self._tenant)
        limit = frame.payload.limit or 30
        tenant_filter = self._tenant.model_dump() if self._tenant else {}
        if frame.payload.tenant_filter:
            tenant_filter.update(frame.payload.tenant_filter)
        user_filter = {"id": user_id} if user_id else {}
        if frame.payload.user_filter:
            user_filter.update(frame.payload.user_filter)

        # Apply authorization context as additional filters
        auth_context = auth_result.context if auth_result else None
        if auth_context:
            if "participant_user_id" in auth_context:
                user_filter["id"] = auth_context["participant_user_id"]
            if "owner_user_id" in auth_context:
                user_filter["id"] = auth_context["owner_user_id"]
            if "owner_tenant_match" in auth_context:
                tenant_filter.update(auth_context["owner_tenant_match"])

        threads = await self._persistence.list_threads(
            assistant_id=self._assistant_id,
            user_id=user_id,
            cursor=frame.payload.cursor,
            limit=limit + 1,
            scope=scope,
            user_email=user_email,
            tenant_filter=tenant_filter,
            user_filter=user_filter,
        )
        has_more = len(threads) > limit
        if has_more:
            threads = threads[:limit]

        if frame.payload.cursor:
            total_count = 0
        else:
            total_count = await self._persistence.count_threads(
                assistant_id=self._assistant_id,
                user_id=user_id,
                scope=scope,
                user_email=user_email,
                tenant_filter=tenant_filter,
                user_filter=user_filter,
            )

        last = threads[-1] if has_more else None
        cursor = f"{last.last_event_at.isoformat()}|{last.id}" if last else None
        result = S2C_ThreadListResult(
            id=_generate_id(),
            payload=ThreadListResultPayload(
                threads=threads,
                cursor=cursor,
                total_count=total_count,
            ),
        )
        await self._send(ws, result)

    async def _handle_thread_subscribe(
        self,
        ws: WebSocketProtocol,
        frame: C2S_ThreadSubscribe,
    ) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        thread_id = frame.payload.thread_id

        auth_result = await self._check_authorization("thread.subscribe", {"thread_id": thread_id})
        if auth_result is not None and not auth_result.allowed:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": auth_result.reason or "Access denied"},
            )
            return

        logger.debug("[assistant] thread.subscribe: thread_id=%s, instance=%s", thread_id, self._assistant_id)
        thread = await self._persistence.get_thread(thread_id, self._assistant_id)

        if not thread:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_FOUND", "message": "Thread not found"},
            )
            return

        events = await self._persistence.get_events(
            thread_id,
            self._assistant_id,
            after_event_id=frame.payload.after_event_id,
            limit=100,
        )

        self._subscribed_threads.add(thread_id)
        self._subscriptions[self._ws_id].add(thread_id)

        snapshot = S2C_ThreadSnapshot(
            id=_generate_id(),
            payload=ThreadSnapshotPayload(thread=thread, events=events),
        )
        await self._send(ws, snapshot)

    async def _handle_thread_unsubscribe(
        self,
        ws: WebSocketProtocol,
        frame: C2S_ThreadUnsubscribe,
    ) -> None:
        thread_id = frame.payload.thread_id
        self._subscribed_threads.discard(thread_id)
        if self._ws_id in self._subscriptions:
            self._subscriptions[self._ws_id].discard(thread_id)
        await self._send_ack(ws, frame.id)

    async def _handle_thread_delete(self, ws: WebSocketProtocol, frame: C2S_ThreadDelete) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        auth_result = await self._check_authorization("thread.delete", {"thread_id": frame.payload.thread_id})
        if auth_result is not None and not auth_result.allowed:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": auth_result.reason or "Access denied"},
            )
            return

        thread_id = frame.payload.thread_id
        thread = await self._persistence.get_thread(thread_id, self._assistant_id)

        if not thread:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_FOUND", "message": "Thread not found"},
            )
            return

        await self._persistence.delete_thread(thread_id, self._assistant_id)

        self._subscribed_threads.discard(thread_id)
        if self._ws_id in self._subscriptions:
            self._subscriptions[self._ws_id].discard(thread_id)

        deleted_frame = S2C_ThreadDeleted(
            id=_generate_id(),
            payload=ThreadDeletedPayload(thread_id=thread_id),
        )
        await self._broadcast_to_assistant(deleted_frame)

        await self._send_ack(ws, frame.id)

    async def _handle_thread_join(self, ws: WebSocketProtocol, frame: C2S_ThreadJoin) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        thread_id = frame.payload.thread_id
        thread = await self._persistence.get_thread(thread_id, self._assistant_id)

        if thread and not thread.external:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "PERMISSION_DENIED", "message": "Thread belongs to different assistant"},
            )
            return

        if not thread:
            now = _now()
            participant = self._build_participant()
            thread = Thread(
                id=thread_id,
                assistant_id=self._assistant_id,
                owner_user=self._user,
                owner_tenant=self._tenant,
                participants=[participant] if participant else [],
                external=True,
                created_at=now,
                updated_at=now,
                last_event_at=now,
            )
            await self._persistence.create_thread(thread)

            await self._broadcast_to_assistant(
                S2C_ThreadUpsert(
                    id=_generate_id(),
                    payload=ThreadUpsertPayload(thread=thread),
                )
            )

        self._subscribed_threads.add(thread_id)
        self._subscriptions[self._ws_id].add(thread_id)

        events, runs = await asyncio.gather(
            self._persistence.get_events(thread_id, self._assistant_id, limit=100),
            self._persistence.list_runs(self._assistant_id, thread_id=thread_id),
        )

        snapshot = S2C_ThreadSnapshot(
            id=_generate_id(),
            payload=ThreadSnapshotPayload(thread=thread, events=events, runs=runs),
        )
        await self._send(ws, snapshot)
        await self._send_ack(ws, frame.id)

    async def _handle_thread_create(self, ws: WebSocketProtocol, frame: C2S_ThreadCreate) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws, frame.id, ok=False, error={"code": "NOT_CONNECTED", "message": "Must connect first"}
            )
            return

        auth_result = await self._check_authorization("thread.create")
        if auth_result is not None and not auth_result.allowed:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": auth_result.reason or "Access denied"},
            )
            return

        now = _now()
        payload = frame.payload
        thread = Thread(
            id=_generate_id(),
            assistant_id=payload.assistant_id,
            participants=payload.participants or [],
            title=payload.title,
            metadata=payload.metadata,
            created_at=now,
            updated_at=now,
            last_event_at=now,
        )
        await self._persistence.create_thread(thread)

        self._subscribed_threads.add(thread.id)
        self._subscriptions[self._ws_id].add(thread.id)

        await self._broadcast_to_assistant_except_self(
            ws, S2C_ThreadUpsert(id=_generate_id(), payload=ThreadUpsertPayload(thread=thread))
        )

        await self._send_ack(ws, frame.id, thread=thread)

    async def _handle_thread_patch(self, ws: WebSocketProtocol, frame: C2S_ThreadPatch) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws, frame.id, ok=False, error={"code": "NOT_CONNECTED", "message": "Must connect first"}
            )
            return

        thread_id = frame.payload.thread_id
        thread = await self._persistence.get_thread(thread_id, self._assistant_id)

        if not thread:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_FOUND", "message": "Thread not found"},
            )
            return

        existing_metadata = thread.metadata or {}
        merged_metadata = {**existing_metadata, **frame.payload.metadata}
        thread.metadata = merged_metadata
        thread.updated_at = _now()

        await self._persistence.update_thread(thread, self._assistant_id)

        await self._broadcast_to_assistant(
            S2C_ThreadUpsert(id=_generate_id(), payload=ThreadUpsertPayload(thread=thread))
        )

        await self._send_ack(ws, frame.id)

    async def _handle_event_external(self, ws: WebSocketProtocol, frame: C2S_ExternalEvent) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        thread_id = frame.payload.thread_id
        thread = await self._persistence.get_thread(thread_id, self._assistant_id)

        if not thread:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_FOUND", "message": "Thread not found"},
            )
            return

        ext = frame.payload.event

        if ext.created_at:
            try:
                created_at = datetime.fromisoformat(ext.created_at)
            except (ValueError, TypeError):
                created_at = _now()
        else:
            created_at = _now()

        wire_content: list[WireS2C_ContentPart] | None = None
        if ext.content is not None:
            wire_content = [deserialize_s2c_part(part) for part in ext.content]

        thread_event = ThreadEvent(
            id=ext.id,
            thread_id=thread_id,
            run_id=None,
            type=cast(EventType, ext.type),
            role=ext.role,
            actor=ext.actor,
            display_name=ext.display_name,
            content=wire_content,
            data=ext.data,
            assistant_id=ext.assistant_id,
            created_at=created_at,
        )
        await self._persistence.create_event(thread_event)

        now = _now()
        thread.last_event_at = now
        thread.updated_at = now
        await self._persistence.update_thread(thread, self._assistant_id)

        append_frame = S2C_EventAppend(
            id=_generate_id(),
            payload=EventAppendPayload(
                thread_id=thread_id,
                events=[thread_event],
            ),
        )
        await self._broadcast_to_assistant(append_frame)

        await self._send_ack(ws, frame.id)

        if frame.payload.trigger_handler:
            context = AssistantHandlerContext(
                handler=self._handler,
                assistant_id=self._assistant_id,
                message="",
                user=self._user,
                assistant=self._assistant,
                tenant=self._tenant,
                thread_id=thread_id,
                content=cast(list[WireC2S_ContentPart | dict[str, Any]] | None, ext.content),
                data=ext.data,
                event_type=cast(EventType, ext.type),
                role=ext.role,
                target_assistant_id=ext.assistant_id,
                command=ext.command if hasattr(ext, "command") else None,
            )

            result = PipelineResult(
                thread=thread,
                user_event=thread_event,
                is_new_thread=False,
            )

            try:
                async for _event in self._pipeline.execute(context, result, knowledge=self._knowledge):
                    pass
            except AssistantHandlerError:
                pass

    async def _handle_event_create(self, ws: WebSocketProtocol, frame: C2S_EventCreate) -> None:
        logger.debug(
            "[assistant] event.create: thread_id=%s, instance=%s, client_event_id=%s",
            frame.payload.thread_id,
            self._assistant_id,
            frame.payload.client_event_id,
        )
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        auth_result = await self._check_authorization("event.create", {"thread_id": frame.payload.thread_id})
        if auth_result is not None and not auth_result.allowed:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": auth_result.reason or "Access denied"},
            )
            return

        content_parts: list[WireC2S_ContentPart | dict[str, Any]] = list(frame.payload.event.content)

        context = AssistantHandlerContext(
            handler=self._handler,
            assistant_id=self._assistant_id,
            message="",
            user=self._user,
            assistant=self._assistant,
            tenant=self._tenant,
            thread_id=frame.payload.thread_id,
            content=content_parts,
            data=frame.payload.event.data,
            client_event_id=frame.payload.client_event_id,
            event_id=frame.payload.event_id,
            event_type=frame.payload.event.type,
            role=frame.payload.event.role,
            actor=frame.payload.event.actor,
            target_assistant_id=frame.payload.event.assistant_id
            if hasattr(frame.payload.event, "assistant_id")
            else None,
            command=frame.payload.event.command if hasattr(frame.payload.event, "command") else None,
            audience=frame.payload.event.audience if hasattr(frame.payload.event, "audience") else None,
        )

        try:
            result = await self._pipeline.setup(context)
        except UploadReferenceError as e:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "UPLOAD_NOT_FOUND", "message": str(e)},
            )
            return
        except ValueError:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_FOUND", "message": "Thread not found"},
            )
            return
        except PermissionError:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": "Thread belongs to different assistant"},
            )
            return

        if result.is_new_thread:
            self._subscribed_threads.add(result.thread.id)
            self._subscriptions[self._ws_id].add(result.thread.id)

        user = self._user
        if user and (user.id or getattr(user, "email", None)):
            participant = self._build_participant()
            await self._persistence.upsert_thread_participant(result.thread.id, self._assistant_id, participant)

        await self._send_ack(ws, frame.id)

        try:
            async for _event in self._pipeline.execute(context, result, knowledge=self._knowledge):
                pass
        except AssistantHandlerError:
            pass

    async def _handle_event_list(self, ws: WebSocketProtocol, frame: C2S_EventList) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        payload = frame.payload
        limit = payload.limit
        events = await self._persistence.get_events(
            payload.thread_id,
            self._assistant_id,
            before_event_id=payload.before_event_id,
            limit=limit + 1,
            order="desc",
        )

        has_more = len(events) > limit
        if has_more:
            events = events[:limit]

        events.reverse()

        cursor = events[0].id if events and has_more else None
        result = S2C_EventListResult(
            id=_generate_id(),
            payload=EventListResultPayload(
                thread_id=payload.thread_id,
                events=events,
                cursor=cursor,
                has_more=has_more,
            ),
        )
        await self._send(ws, result)

    async def _handle_analytics_subscribe(
        self,
        ws: WebSocketProtocol,
        frame: C2S_AnalyticsSubscribe,
    ) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        assistant_id = frame.payload.assistant_id
        if assistant_id != self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": "Cannot subscribe to other assistant's analytics"},
            )
            return

        if assistant_id not in self._analytics_subscriptions:
            self._analytics_subscriptions[assistant_id] = set()
        self._analytics_subscriptions[assistant_id].add(self._ws_id)

        logger.info(
            "[assistant] analytics subscribed: ws=%s, assistant=%s, total_subscribers=%d",
            self._ws_id,
            assistant_id,
            len(self._analytics_subscriptions[assistant_id]),
        )

        await self._send_ack(ws, frame.id)

    async def _handle_analytics_unsubscribe(
        self,
        ws: WebSocketProtocol,
        frame: C2S_AnalyticsUnsubscribe,
    ) -> None:
        assistant_id = frame.payload.assistant_id
        logger.info(
            "[assistant] analytics unsubscribed: ws=%s, assistant=%s",
            self._ws_id,
            assistant_id,
        )
        if assistant_id in self._analytics_subscriptions:
            self._analytics_subscriptions[assistant_id].discard(self._ws_id)
            if not self._analytics_subscriptions[assistant_id]:
                del self._analytics_subscriptions[assistant_id]

        await self._send_ack(ws, frame.id)

    async def _handle_feedback(
        self,
        ws: WebSocketProtocol,
        frame: C2S_Feedback,
    ) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        if self._analytics_collector:
            user_id = self._user.id if self._user else ""
            thread_id = frame.payload.target_id if frame.payload.target_type == "thread" else None
            await self._analytics_collector.feedback(
                feedback_type=frame.payload.feedback,
                target_type=frame.payload.target_type,
                target_id=frame.payload.target_id,
                assistant_id=self._assistant_id,
                user_id=user_id,
                reason=frame.payload.reason,
                classification=frame.payload.classification,
                thread_id=thread_id,
            )

        ack = S2C_FeedbackAck(
            id=_generate_id(),
            payload=FeedbackAckPayload(
                target_type=frame.payload.target_type,
                target_id=frame.payload.target_id,
                feedback=frame.payload.feedback,
                ok=True,
            ),
        )
        await self._send(ws, ack)

    async def _handle_settings_subscribe(
        self,
        ws: WebSocketProtocol,
        frame: C2S_SettingsSubscribe,
    ) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        assistant_id = frame.payload.assistant_id
        scope = frame.payload.scope
        scope_id = frame.payload.scope_id

        auth_result = await self._check_authorization("settings.subscribe", {"scope": scope, "scope_id": scope_id})
        if auth_result is not None and not auth_result.allowed:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": auth_result.reason or "Access denied"},
            )
            return

        if assistant_id != self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": "Cannot subscribe to other assistant's settings"},
            )
            return

        if not self._settings_schema:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONFIGURED", "message": "No settings schema configured"},
            )
            return

        # Check visibility
        scope_def = self._settings_schema.get_scope(scope)
        if scope_def and scope_def.visibility == "admin":
            user_role = getattr(self._user, "role", None) if self._user else None
            if user_role != "admin":
                await self._send_ack(
                    ws,
                    frame.id,
                    ok=False,
                    error={"code": "FORBIDDEN", "message": "Admin access required"},
                )
                return

        sub_key = f"{assistant_id}:{scope}:{scope_id}"
        if sub_key not in self._settings_subscriptions:
            self._settings_subscriptions[sub_key] = set()
        self._settings_subscriptions[sub_key].add(self._ws_id)
        self._settings_sub_keys.add(sub_key)

        if self._settings_broadcaster:
            values = await self._persistence.get_settings(assistant_id, scope=scope, scope_id=scope_id)
            await self._settings_broadcaster.broadcast_snapshot_to_ws(
                assistant_id=assistant_id,
                ws=ws,
                schema=self._settings_schema,
                values=values,
                scope=scope,
                scope_id=scope_id,
            )

        await self._send_ack(ws, frame.id)

    async def _handle_settings_unsubscribe(
        self,
        ws: WebSocketProtocol,
        frame: C2S_SettingsUnsubscribe,
    ) -> None:
        assistant_id = frame.payload.assistant_id
        scope = frame.payload.scope
        scope_id = frame.payload.scope_id
        sub_key = f"{assistant_id}:{scope}:{scope_id}"
        if sub_key in self._settings_subscriptions:
            self._settings_subscriptions[sub_key].discard(self._ws_id)
            if not self._settings_subscriptions[sub_key]:
                del self._settings_subscriptions[sub_key]
        self._settings_sub_keys.discard(sub_key)

        await self._send_ack(ws, frame.id)

    async def _handle_settings_patch(
        self,
        ws: WebSocketProtocol,
        frame: C2S_SettingsPatch,
    ) -> None:
        if not self._assistant_id:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONNECTED", "message": "Must connect first"},
            )
            return

        if not self._settings_schema:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_CONFIGURED", "message": "No settings schema configured"},
            )
            return

        field_id = frame.payload.field_id
        value = frame.payload.value
        scope = frame.payload.scope
        scope_id = frame.payload.scope_id

        auth_result = await self._check_authorization(
            "settings.patch",
            {"field_id": field_id, "scope": scope, "scope_id": scope_id},
        )
        if auth_result is not None and not auth_result.allowed:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "FORBIDDEN", "message": auth_result.reason or "Access denied"},
            )
            return

        # Check visibility
        if scope:
            scope_def = self._settings_schema.get_scope(scope)
            if scope_def and scope_def.visibility == "admin":
                user_role = getattr(self._user, "role", None) if self._user else None
                if user_role != "admin":
                    await self._send_ack(
                        ws,
                        frame.id,
                        ok=False,
                        error={"code": "FORBIDDEN", "message": "Admin access required"},
                    )
                    return

        field = self._settings_schema.get_field(field_id, scope_name=scope if scope else None)
        if not field:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "NOT_FOUND", "message": f"Unknown field: {field_id}"},
            )
            return

        if field.visibility == "internal":
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={
                    "code": "FORBIDDEN",
                    "message": f"Field '{field_id}' is internal and cannot be patched via WebSocket",
                },
            )
            return

        if field.readonly:
            await self._send_ack(
                ws,
                frame.id,
                ok=False,
                error={"code": "READONLY", "message": f"Field '{field_id}' is readonly"},
            )
            return

        await self._persistence.update_setting(self._assistant_id, field_id, value, scope=scope, scope_id=scope_id)

        if self._settings_broadcaster:
            await self._settings_broadcaster.broadcast_patch(
                assistant_id=self._assistant_id,
                field_id=field_id,
                value=value,
                scope=scope,
                scope_id=scope_id,
            )

        await self._send_ack(ws, frame.id)
