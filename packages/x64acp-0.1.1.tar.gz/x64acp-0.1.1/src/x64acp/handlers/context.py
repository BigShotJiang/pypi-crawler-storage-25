from dataclasses import dataclass, field
from datetime import datetime

from x64acp.protocol.models import AssistantIdentity, TenantScope, UserIdentity

__all__ = ["AssistantContext"]


@dataclass
class AssistantContext:
    """Contextual metadata for the incoming message."""

    thread_id: str
    event_id: str
    user: UserIdentity | None = field(default=None)
    assistant: AssistantIdentity | None = field(default=None)
    tenant: TenantScope | None = field(default=None)
    thread_title: str | None = field(default=None)
    thread_created_at: datetime | None = field(default=None)
    metadata: dict | None = field(default=None)
