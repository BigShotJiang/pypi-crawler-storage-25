from __future__ import annotations

import logging
import uuid
from collections.abc import AsyncGenerator, Awaitable, Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Literal, cast

from x64acp.analytics.agent_analytics import AssistantAnalytics
from x64acp.analytics.models import AnalyticsEvent
from x64acp.exceptions import AssistantHandlerError
from x64acp.handlers.context import AssistantContext
from x64acp.handlers.incoming import AssistantIncoming
from x64acp.handlers.knowledge import AssistantKnowledge
from x64acp.handlers.memory import AssistantMemory
from x64acp.handlers.send import AssistantEvent, AssistantSend
from x64acp.persistence.base import Persistence
from x64acp.protocol.models import (
    AssistantIdentity,
    AudioPart,
    ContentPart,
    DocumentPart,
    EventType,
    ImagePart,
    Run,
    SystemContext,
    TenantScope,
    TextPart,
    Thread,
    ThreadEvent,
    UserIdentity,
    WireC2S_ContentPart,
    WireS2C_AudioPart,
    WireS2C_ContentPart,
    WireS2C_DocumentPart,
    WireS2C_ImagePart,
    WireS2C_TextPart,
    deserialize_s2c_part,
)
from x64acp.settings.agent_settings import AssistantSettings

if TYPE_CHECKING:
    from x64acp.analytics.collector import AnalyticsCollector
    from x64acp.persistence.upload import UploadStore
    from x64acp.settings.broadcaster import SettingsBroadcaster
    from x64acp.settings.models import SettingsSchema

logger = logging.getLogger("assistants")

__all__ = [
    "AssistantHandler",
    "AssistantHandlerContext",
    "AssistantHandlerPipeline",
    "PipelineResult",
    "UploadReferenceError",
]


class UploadReferenceError(ValueError):
    """Raised when a ref_id cannot be resolved from the upload store."""


def _generate_id() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(UTC)


AssistantHandler = Callable[
    [AssistantIncoming, AssistantSend, AssistantMemory, AssistantAnalytics, AssistantSettings, "AssistantKnowledge"],
    AsyncGenerator[AssistantEvent, None],
]


@dataclass
class AssistantHandlerContext:
    handler: AssistantHandler
    assistant_id: str
    message: str
    user: UserIdentity | None = None
    assistant: AssistantIdentity | None = None
    tenant: TenantScope | None = None
    thread_id: str | None = None
    thread_title: str | None = None
    content: list[WireC2S_ContentPart | dict[str, Any]] | None = None
    data: dict[str, Any] | None = None
    client_event_id: str | None = None
    event_id: str | None = None
    event_type: EventType = "message"
    role: str = "user"
    actor: str = "user"
    target_assistant_id: str | None = None
    command: str | None = None
    audience: str | None = None


@dataclass
class PipelineResult:
    thread: Thread
    user_event: ThreadEvent
    is_new_thread: bool
    handler_content: list[ContentPart] | None = None


class AssistantHandlerPipeline:
    def __init__(
        self,
        persistence: Persistence,
        broadcast_callback: Callable[[str, dict[str, Any]], Awaitable[None]] | None = None,
        analytics_collector: AnalyticsCollector | None = None,
        settings_broadcaster: SettingsBroadcaster | None = None,
        settings_schema: SettingsSchema | None = None,
        assistant_name: str = "Assistant",
        upload_store: UploadStore | None = None,
        system: SystemContext | None = None,
    ):
        self._persistence = persistence
        self._broadcast_callback = broadcast_callback
        self._analytics_collector = analytics_collector
        self._settings_broadcaster = settings_broadcaster
        self._settings_schema = settings_schema
        self._assistant_name = assistant_name
        self._upload_store = upload_store
        self._system = system

    @staticmethod
    def _build_participant(user: UserIdentity | None, tenant: TenantScope | None) -> dict:
        """Build a participant dict from user/tenant for thread participants list."""
        result: dict[str, Any] = {}
        if user:
            result["user"] = user.model_dump()
        if tenant:
            result["tenant"] = tenant.model_dump()
        return result

    def _enrich_event(self, event: ThreadEvent, context: AssistantHandlerContext) -> ThreadEvent:
        """Auto-attach identity fields from context to an event."""
        if event.role == "assistant" and context.assistant:
            event.assistant = context.assistant
        if event.role == "user" and context.user:
            event.user = context.user
        if context.tenant:
            event.tenant = context.tenant
        if self._system:
            event.system = self._system
        return event

    async def setup(self, context: AssistantHandlerContext) -> PipelineResult:
        now = _now()
        thread_id = context.thread_id
        is_new_thread = False

        author_id = context.user.id if context.user else ""
        participant = self._build_participant(context.user, context.tenant)

        if not thread_id:
            thread_id = _generate_id()
            thread = Thread(
                id=thread_id,
                assistant_id=context.assistant_id,
                owner_user=context.user,
                owner_tenant=context.tenant,
                participants=[participant] if participant else [],
                title=context.thread_title,
                created_at=now,
                updated_at=now,
                last_event_at=now,
            )
            await self._persistence.create_thread(thread)
            is_new_thread = True

            await self._broadcast(
                context.assistant_id,
                {
                    "type": "thread.upsert",
                    "thread": thread,
                },
            )

            await self._track_event(
                context.assistant_id,
                AnalyticsEvent.THREAD_CREATED.value,
                thread_id=thread_id,
                user_id=author_id,
            )
        else:
            existing_thread = await self._persistence.get_thread(thread_id, context.assistant_id)
            if existing_thread:
                thread = existing_thread
            else:
                thread = Thread(
                    id=thread_id,
                    assistant_id=context.assistant_id,
                    owner_user=context.user,
                    owner_tenant=context.tenant,
                    participants=[participant] if participant else [],
                    title=context.thread_title,
                    created_at=now,
                    updated_at=now,
                    last_event_at=now,
                )
                await self._persistence.create_thread(thread)
                is_new_thread = True

                await self._broadcast(
                    context.assistant_id,
                    {
                        "type": "thread.upsert",
                        "thread": thread,
                    },
                )

                await self._track_event(
                    context.assistant_id,
                    AnalyticsEvent.THREAD_CREATED.value,
                    thread_id=thread_id,
                    user_id=author_id,
                )

        if context.event_type == "form.response":
            handler_parts: list[ContentPart] = []
            storage_parts = None
        elif context.content:
            handler_parts, storage_parts = self._resolve_content_parts(context.content)
        else:
            text = context.message or ""
            handler_parts = [TextPart(text=text)]
            storage_parts = [WireS2C_TextPart(text=text)]

        user_event_id = context.event_id or _generate_id()
        stored_audience: Literal["user", "assistant"] | None = None
        if context.audience in ("user", "assistant"):
            stored_audience = cast(Literal["user", "assistant"], context.audience)
        user_event = ThreadEvent(
            id=user_event_id,
            thread_id=thread_id,
            run_id=None,
            type=context.event_type,
            role=context.role,
            actor=context.actor,
            user=context.user,
            tenant=context.tenant,
            content=storage_parts,
            data=context.data,
            assistant_id=context.target_assistant_id,
            command=context.command,
            audience=stored_audience,
            created_at=now,
            client_event_id=context.client_event_id,
        )
        self._enrich_event(user_event, context)
        await self._persistence.create_event(user_event)

        await self._broadcast(
            context.assistant_id,
            {
                "type": "event.append",
                "thread_id": thread_id,
                "events": [user_event],
            },
        )

        c2s_content_type = storage_parts[0].type if storage_parts else "text"
        await self._track_event(
            context.assistant_id,
            AnalyticsEvent.MESSAGE_C2S.value,
            thread_id=thread_id,
            user_id=author_id,
            event_id=user_event_id,
            data={"type": c2s_content_type},
        )

        return PipelineResult(
            thread=thread,
            user_event=user_event,
            is_new_thread=is_new_thread,
            handler_content=handler_parts,
        )

    async def execute(
        self,
        context: AssistantHandlerContext,
        result: PipelineResult,
        knowledge: AssistantKnowledge | None = None,
    ) -> AsyncGenerator[AssistantEvent, None]:
        thread_id = result.thread.id
        thread = result.thread

        author_id = context.user.id if context.user else ""

        handler_content = result.handler_content or []
        message = self._extract_message(handler_content)
        assistant_context = AssistantContext(
            thread_id=thread_id,
            event_id=result.user_event.id,
            user=context.user,
            assistant=context.assistant,
            tenant=context.tenant,
            thread_title=thread.title,
            thread_created_at=thread.created_at,
            metadata=thread.metadata,
        )
        audience_value: Literal["user", "assistant"] | None = None
        if context.audience in ("user", "assistant"):
            audience_value = cast(Literal["user", "assistant"], context.audience)
        incoming = AssistantIncoming(
            message=message,
            content=handler_content,
            context=assistant_context,
            event_type=context.event_type,
            target_assistant_id=context.target_assistant_id,
            command=context.command,
            audience=audience_value,
            data=context.data,
            role=context.role,
            actor=context.actor,
            user=context.user,
            assistant=context.assistant,
        )
        # Populate form response fields
        if context.event_type == "form.response" and context.data:
            incoming.form_data = context.data.get("values")
            incoming.form_cancelled = context.data.get("cancelled", False)
            incoming.form_event_id = context.data.get("form_event_id")

        send = AssistantSend()
        memory = AssistantMemory(thread_id=thread_id, assistant_id=context.assistant_id, persistence=self._persistence)

        analytics = self._create_analytics(
            assistant_id=context.assistant_id,
            thread_id=thread_id,
            user_id=author_id,
        )

        settings = self._create_settings(assistant_id=context.assistant_id)

        handler_knowledge = knowledge if knowledge is not None else AssistantKnowledge()

        current_run_id: str | None = None
        current_blueprint_id: str | None = None

        try:
            async for event in context.handler(incoming, send, memory, analytics, settings, handler_knowledge):
                event_now = _now()

                if event.send_type == "run_start":
                    current_run_id = _generate_id()
                    current_blueprint_id = event.data.get("blueprint_id")
                    run = Run(
                        id=current_run_id,
                        thread_id=thread_id,
                        blueprint_id=current_blueprint_id,
                        status="running",
                        started_at=event_now,
                    )
                    await self._persistence.create_run(run, context.assistant_id)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "run.upsert",
                            "run": run,
                        },
                    )

                elif event.send_type == "run_end":
                    if current_run_id:
                        run = Run(
                            id=current_run_id,
                            thread_id=thread_id,
                            blueprint_id=current_blueprint_id,
                            status=event.data.get("status", "succeeded"),
                            started_at=event_now,
                            ended_at=event_now,
                            error=event.data.get("error"),
                        )
                        await self._persistence.update_run(run, context.assistant_id)
                        await self._broadcast(
                            context.assistant_id,
                            {
                                "type": "run.upsert",
                                "run": run,
                            },
                        )
                        current_run_id = None
                        current_blueprint_id = None

                elif event.send_type == "text":
                    event_id = _generate_id()
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="message",
                        role="assistant",
                        actor="assistant",
                        display_name=self._assistant_name,
                        content=[WireS2C_TextPart(text=event.data["text"])],
                        data=event.data.get("meta"),
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )
                    await self._track_event(
                        context.assistant_id,
                        AnalyticsEvent.MESSAGE_S2C.value,
                        thread_id=thread_id,
                        user_id=author_id,
                        run_id=current_run_id,
                        event_id=event_id,
                        data={"type": "text"},
                    )

                elif event.send_type == "audio":
                    event_id = _generate_id()
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="message",
                        role="assistant",
                        actor="assistant",
                        display_name=self._assistant_name,
                        content=[
                            WireS2C_AudioPart(
                                url=event.data["url"],
                                mime_type=event.data.get("mime_type"),
                                duration=event.data.get("duration"),
                            )
                        ],
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )
                    await self._track_event(
                        context.assistant_id,
                        AnalyticsEvent.MESSAGE_S2C.value,
                        thread_id=thread_id,
                        user_id=author_id,
                        run_id=current_run_id,
                        event_id=event_id,
                        data={"type": "audio"},
                    )

                elif event.send_type == "image":
                    event_id = _generate_id()
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="message",
                        role="assistant",
                        actor="assistant",
                        display_name=self._assistant_name,
                        content=[
                            WireS2C_ImagePart(
                                url=event.data["url"],
                                mime_type=event.data.get("mime_type"),
                                alt=event.data.get("alt"),
                            )
                        ],
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )
                    await self._track_event(
                        context.assistant_id,
                        AnalyticsEvent.MESSAGE_S2C.value,
                        thread_id=thread_id,
                        user_id=author_id,
                        run_id=current_run_id,
                        event_id=event_id,
                        data={"type": "image"},
                    )

                elif event.send_type == "document":
                    event_id = _generate_id()
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="message",
                        role="assistant",
                        actor="assistant",
                        display_name=self._assistant_name,
                        content=[
                            WireS2C_DocumentPart(
                                url=event.data["url"],
                                filename=event.data["filename"],
                                mime_type=event.data["mime_type"],
                            )
                        ],
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )
                    await self._track_event(
                        context.assistant_id,
                        AnalyticsEvent.MESSAGE_S2C.value,
                        thread_id=thread_id,
                        user_id=author_id,
                        run_id=current_run_id,
                        event_id=event_id,
                        data={"type": "document"},
                    )

                elif event.send_type == "tool_call":
                    event_id = _generate_id()
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="tool.call",
                        role="assistant",
                        actor="assistant",
                        data={
                            "id": event.data["id"],
                            "name": event.data["name"],
                            "display_name": event.data.get("display_name"),
                            "args": event.data["args"],
                        },
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )
                    await self._track_event(
                        context.assistant_id,
                        AnalyticsEvent.TOOL_CALLED.value,
                        thread_id=thread_id,
                        user_id=author_id,
                        run_id=current_run_id,
                        event_id=event_id,
                        data={"name": event.data["name"]},
                    )

                elif event.send_type == "tool_result":
                    thread_event = ThreadEvent(
                        id=_generate_id(),
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="tool.result",
                        role="assistant",
                        actor="tool",
                        data={
                            "id": event.data.get("id"),
                            "name": event.data["name"],
                            "display_name": event.data.get("display_name"),
                            "args": event.data.get("args"),
                            "result": event.data["result"],
                        },
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )

                elif event.send_type == "tool_transaction":
                    event_id = _generate_id()
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="tool.transaction",
                        role="assistant",
                        actor="assistant",
                        data={
                            "id": event.data["id"],
                            "name": event.data["name"],
                            "display_name": event.data.get("display_name"),
                            "args": event.data["args"],
                            "result": event.data["result"],
                        },
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )
                    await self._track_event(
                        context.assistant_id,
                        AnalyticsEvent.TOOL_CALLED.value,
                        thread_id=thread_id,
                        user_id=author_id,
                        run_id=current_run_id,
                        event_id=event_id,
                        data={"name": event.data["name"]},
                    )

                elif event.send_type == "confirmation":
                    event_id = _generate_id()
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="confirmation.request",
                        role="assistant",
                        actor="assistant",
                        display_name=self._assistant_name,
                        data={
                            "confirmation_id": event.data["confirmation_id"],
                            "action_type": event.data["action_type"],
                            "blocking": event.data["blocking"],
                            "summary": event.data["summary"],
                            "details": event.data.get("details", {}),
                        },
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )

                elif event.send_type == "analysis":
                    event_id = _generate_id()
                    report_content: list[WireS2C_ContentPart] | None = (
                        [WireS2C_TextPart(text=event.data["text"])] if event.data.get("text") else None
                    )
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="analysis.report",
                        role="assistant",
                        actor="assistant",
                        display_name=self._assistant_name,
                        content=report_content,
                        data={
                            "kind": event.data["kind"],
                            "metadata": event.data["metadata"],
                        },
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )

                elif event.send_type == "mention":
                    event_id = _generate_id()
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="message.mention",
                        role="assistant",
                        actor="assistant",
                        display_name=self._assistant_name,
                        content=[WireS2C_TextPart(text=event.data["text"])],
                        assistant_id=event.data["assistant_id"],
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )
                    await self._track_event(
                        context.assistant_id,
                        AnalyticsEvent.MESSAGE_S2C.value,
                        thread_id=thread_id,
                        user_id=author_id,
                        run_id=current_run_id,
                        event_id=event_id,
                        data={"type": "mention", "target_assistant_id": event.data["assistant_id"]},
                    )

                elif event.send_type == "skill_invoke":
                    event_id = _generate_id()
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="skill.invoke",
                        role="assistant",
                        actor="assistant",
                        display_name=self._assistant_name,
                        content=[WireS2C_TextPart(text=event.data.get("args", ""))],
                        assistant_id=event.data["assistant_id"],
                        command=event.data["command"],
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )
                    await self._track_event(
                        context.assistant_id,
                        AnalyticsEvent.MESSAGE_S2C.value,
                        thread_id=thread_id,
                        user_id=author_id,
                        run_id=current_run_id,
                        event_id=event_id,
                        data={
                            "type": "skill_invoke",
                            "command": event.data["command"],
                            "target_assistant_id": event.data["assistant_id"],
                        },
                    )

                elif event.send_type == "form":
                    event_id = _generate_id()
                    elements = event.data["elements"]
                    thread_event = ThreadEvent(
                        id=event_id,
                        thread_id=thread_id,
                        run_id=current_run_id,
                        type="form",
                        role="assistant",
                        actor="assistant",
                        display_name=self._assistant_name,
                        content=None,
                        data={
                            "message": event.data["message"],
                            "elements": elements,
                            "submit_label": event.data["submit_label"],
                            "cancel_label": event.data["cancel_label"],
                            "size": event.data["size"],
                        },
                        created_at=event_now,
                    )
                    self._enrich_event(thread_event, context)
                    await self._persistence.create_event(thread_event)
                    await self._broadcast(
                        context.assistant_id,
                        {
                            "type": "event.append",
                            "thread_id": thread_id,
                            "events": [thread_event],
                        },
                    )
                    await self._track_event(
                        context.assistant_id,
                        AnalyticsEvent.MESSAGE_S2C.value,
                        thread_id=thread_id,
                        user_id=author_id,
                        run_id=current_run_id,
                        event_id=event_id,
                        data={"type": "form"},
                    )

                elif event.send_type == "event_update":
                    target_event_id = event.data["event_id"]
                    existing_event = await self._persistence.get_event(target_event_id, context.assistant_id)
                    if not existing_event:
                        logger.warning("[assistant] event_update: event %s not found", target_event_id)
                    else:
                        existing_event.content = [deserialize_s2c_part(p) for p in event.data["content"]]
                        await self._persistence.update_event(existing_event, context.assistant_id)
                        await self._broadcast(
                            context.assistant_id,
                            {
                                "type": "event.append",
                                "thread_id": existing_event.thread_id,
                                "events": [existing_event],
                            },
                        )

                elif event.send_type == "thread_update":
                    updated_thread = await self._persistence.get_thread(thread_id, context.assistant_id)
                    if updated_thread:
                        if event.data.get("title") is not None:
                            updated_thread.title = event.data["title"]
                        if event.data.get("metadata") is not None:
                            existing_metadata = updated_thread.metadata or {}
                            updated_thread.metadata = {**existing_metadata, **event.data["metadata"]}
                        updated_thread.updated_at = event_now
                        await self._persistence.update_thread(updated_thread, context.assistant_id)
                        await self._broadcast(
                            context.assistant_id,
                            {
                                "type": "thread.upsert",
                                "thread": updated_thread,
                            },
                        )

                if event.send_type != "thread_update":
                    await self._update_thread_last_event(thread_id, context.assistant_id, event_now)

                yield event

        except Exception as e:
            logger.error("[assistant] handler error: %s", e, exc_info=True)

            await self._track_event(
                context.assistant_id,
                AnalyticsEvent.ERROR_OCCURRED.value,
                thread_id=thread_id,
                user_id=author_id,
                run_id=current_run_id,
                data={"error": str(e), "type": type(e).__name__},
            )

            error_now = _now()

            if current_run_id:
                run = Run(
                    id=current_run_id,
                    thread_id=thread_id,
                    blueprint_id=current_blueprint_id,
                    status="failed",
                    started_at=error_now,
                    ended_at=error_now,
                    error=str(e),
                )
                await self._persistence.update_run(run, context.assistant_id)
                await self._broadcast(
                    context.assistant_id,
                    {
                        "type": "run.upsert",
                        "run": run,
                    },
                )

            error_event = ThreadEvent(
                id=_generate_id(),
                thread_id=thread_id,
                run_id=current_run_id,
                type="message",
                role="system",
                actor="system",
                content=[WireS2C_TextPart(text=str(e))],
                created_at=error_now,
            )
            self._enrich_event(error_event, context)
            await self._persistence.create_event(error_event)
            await self._broadcast(
                context.assistant_id,
                {
                    "type": "event.append",
                    "thread_id": thread_id,
                    "events": [error_event],
                },
            )
            await self._update_thread_last_event(thread_id, context.assistant_id, error_now)

            raise AssistantHandlerError(str(e), original=e) from e

    async def _broadcast(self, assistant_id: str, payload: dict[str, Any]) -> None:
        if self._broadcast_callback:
            await self._broadcast_callback(assistant_id, payload)

    async def _track_event(
        self,
        assistant_id: str,
        event: str,
        *,
        thread_id: str | None = None,
        user_id: str | None = None,
        run_id: str | None = None,
        event_id: str | None = None,
        data: dict[str, Any] | None = None,
    ) -> None:
        if self._analytics_collector:
            await self._analytics_collector.track(
                event=event,
                assistant_id=assistant_id,
                thread_id=thread_id,
                user_id=user_id,
                run_id=run_id,
                event_id=event_id,
                data=data,
            )

    async def _update_thread_last_event(self, thread_id: str, assistant_id: str, timestamp: datetime) -> None:
        thread = await self._persistence.get_thread(thread_id, assistant_id)
        if thread:
            thread.last_event_at = timestamp
            thread.updated_at = timestamp
            await self._persistence.update_thread(thread, assistant_id)

    def _create_analytics(
        self,
        assistant_id: str,
        thread_id: str,
        user_id: str | None,
    ) -> AssistantAnalytics:
        if self._analytics_collector:
            return AssistantAnalytics(
                assistant_id=assistant_id,
                thread_id=thread_id,
                user_id=user_id,
                run_id=None,
                collector=self._analytics_collector,
            )

        class NoopCollector:
            async def track(self, **kwargs) -> None:
                pass

            async def feedback(self, **kwargs) -> None:
                pass

        return AssistantAnalytics(
            assistant_id=assistant_id,
            thread_id=thread_id,
            user_id=user_id,
            run_id=None,
            collector=NoopCollector(),  # type: ignore
        )

    def _create_settings(self, assistant_id: str) -> AssistantSettings:
        if self._settings_schema and self._settings_broadcaster:
            return AssistantSettings(
                assistant_id=assistant_id,
                schema=self._settings_schema,
                persistence=self._persistence,
                broadcaster=self._settings_broadcaster,
            )

        from x64acp.settings.models import SettingsSchema

        class NoopBroadcaster:
            async def broadcast_snapshot(self, **kwargs) -> None:
                pass

            async def broadcast_patch(self, **kwargs) -> None:
                pass

        class NoopPersistence:
            async def get_settings(self, assistant_id: str) -> dict:
                return {}

            async def update_setting(self, assistant_id: str, field_id: str, value) -> None:
                pass

            async def set_settings(self, assistant_id: str, values: dict) -> None:
                pass

        return AssistantSettings(
            assistant_id=assistant_id,
            schema=SettingsSchema(fields=[]),
            persistence=NoopPersistence(),  # type: ignore
            broadcaster=NoopBroadcaster(),  # type: ignore
        )

    def _resolve_content_parts(
        self, parts: list[WireC2S_ContentPart | dict[str, Any]]
    ) -> tuple[list[ContentPart], list[WireS2C_ContentPart]]:
        """Resolve C2S wire content parts into handler format (with bytes) and
        storage format (metadata only, no bytes).

        Returns (handler_parts, storage_parts).
        """
        handler_parts: list[ContentPart] = []
        storage_parts: list[WireS2C_ContentPart] = []

        for part in parts:
            if hasattr(part, "model_dump"):
                data = part.model_dump()
            elif isinstance(part, dict):
                data = part
            else:
                raise ValueError(f"Unsupported content part: {type(part)}")

            part_type = data.get("type")

            if part_type == "text":
                handler_parts.append(TextPart(text=data["text"]))
                storage_parts.append(WireS2C_TextPart(text=data["text"]))

            elif part_type in ("audio", "image", "document") and "ref_id" in data:
                ref_id = data["ref_id"]
                entry = self._upload_store.consume(ref_id) if self._upload_store else None
                if entry is None:
                    raise UploadReferenceError(f"Upload reference '{ref_id}' not found or expired")

                if part_type == "audio":
                    handler_parts.append(
                        AudioPart(
                            data=entry.data,
                            mime_type=entry.mime_type,
                            duration=data.get("duration"),
                            filename=entry.filename,
                        )
                    )
                    storage_parts.append(
                        WireS2C_AudioPart(
                            mime_type=entry.mime_type,
                            duration=data.get("duration"),
                            filename=entry.filename,
                        )
                    )
                elif part_type == "image":
                    handler_parts.append(
                        ImagePart(
                            data=entry.data,
                            mime_type=entry.mime_type,
                            filename=entry.filename,
                        )
                    )
                    storage_parts.append(
                        WireS2C_ImagePart(
                            mime_type=entry.mime_type,
                            filename=entry.filename,
                        )
                    )
                elif part_type == "document":
                    handler_parts.append(
                        DocumentPart(
                            data=entry.data,
                            mime_type=entry.mime_type,
                            filename=entry.filename,
                            size_bytes=entry.size_bytes,
                        )
                    )
                    storage_parts.append(
                        WireS2C_DocumentPart(
                            mime_type=entry.mime_type,
                            filename=entry.filename,
                            size_bytes=entry.size_bytes,
                        )
                    )

            elif part_type == "audio" and "data" in data:
                handler_parts.append(
                    AudioPart(
                        data=data["data"],
                        mime_type=data.get("mime_type", ""),
                        duration=data.get("duration"),
                        filename=data.get("filename"),
                    )
                )
                storage_parts.append(
                    WireS2C_AudioPart(
                        mime_type=data.get("mime_type"),
                        duration=data.get("duration"),
                        filename=data.get("filename"),
                    )
                )

            elif part_type == "image" and "data" in data:
                handler_parts.append(
                    ImagePart(
                        data=data["data"],
                        mime_type=data.get("mime_type", ""),
                        filename=data.get("filename"),
                    )
                )
                storage_parts.append(
                    WireS2C_ImagePart(
                        mime_type=data.get("mime_type"),
                        filename=data.get("filename"),
                    )
                )

            elif part_type == "document" and "data" in data:
                handler_parts.append(
                    DocumentPart(
                        data=data["data"],
                        mime_type=data.get("mime_type", ""),
                        filename=data.get("filename", ""),
                        size_bytes=data.get("size_bytes", 0),
                    )
                )
                storage_parts.append(
                    WireS2C_DocumentPart(
                        mime_type=data.get("mime_type"),
                        filename=data.get("filename"),
                        size_bytes=data.get("size_bytes"),
                    )
                )

            else:
                raise ValueError(f"Unsupported content part type: {part_type!r}")

        return handler_parts, storage_parts

    def _extract_message(self, content: list[ContentPart]) -> str:
        texts = []
        for part in content:
            if isinstance(part, TextPart):
                texts.append(part.text)
        return " ".join(texts)
