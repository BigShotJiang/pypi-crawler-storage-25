from __future__ import annotations

from dataclasses import dataclass, field

from x64acp.config import Knowledge

__all__ = ["AssistantKnowledge"]


@dataclass
class AssistantKnowledge:
    """Service object providing knowledge source selection state to handlers."""

    _sources: list[Knowledge] = field(default_factory=list)
    _selected_source_ids: list[str] = field(default_factory=list)

    @property
    def selected_sources(self) -> list[str]:
        """Source IDs the client selected for this connection."""
        return list(self._selected_source_ids)

    def get_sources(self) -> list[Knowledge]:
        """All registered knowledge sources for this assistant."""
        return list(self._sources)

    def set_selected(self, source_ids: list[str]) -> None:
        """Update the active knowledge selection, filtering to valid source IDs."""
        valid_ids = {s.id for s in self._sources}
        self._selected_source_ids = [sid for sid in source_ids if sid in valid_ids]
