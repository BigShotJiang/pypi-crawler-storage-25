from typing import TYPE_CHECKING, Any, Literal

from x64acp.protocol.models import ThreadEvent

if TYPE_CHECKING:
    from x64acp.persistence.base import EventOrder, Persistence

__all__ = ["AssistantMemory"]

HistoryFormat = Literal["openai", "anthropic", "google", "cohere", "voyage"]


class AssistantMemory:
    def __init__(
        self,
        thread_id: str,
        assistant_id: str,
        persistence: "Persistence",
    ):
        self._thread_id = thread_id
        self._assistant_id = assistant_id
        self._persistence = persistence

    async def get_history_raw(
        self,
        limit: int = 50,
        order: "EventOrder" = "asc",
        filters: dict[str, str] | None = None,
    ) -> list[ThreadEvent]:
        return await self._persistence.get_events(
            self._thread_id,
            self._assistant_id,
            limit=limit,
            order=order,
            filters=filters,
        )

    async def get_history(
        self,
        limit: int = 50,
        format: HistoryFormat = "openai",
        order: "EventOrder" = "desc",
        filters: dict[str, str] | None = None,
    ) -> list[dict[str, Any]]:
        raw_limit = limit * 3
        events = await self.get_history_raw(raw_limit, order=order, filters=filters)

        if order == "desc":
            events.reverse()

        messages: list[dict[str, Any]] = []
        for event in events:
            if event.type != "message" or not event.content:
                continue

            text = self._extract_text_with_media(event.content)
            if not text:
                continue

            is_user = event.role != "assistant"
            role: Literal["user", "assistant"] = "user" if is_user else "assistant"
            messages.append(self._format_message(text, role, format))

        if order == "desc":
            return messages[-limit:]
        return messages[:limit]

    @staticmethod
    def _extract_text_with_media(content: list) -> str:
        """Extract text from content parts, adding indicators for media parts."""
        segments: list[str] = []
        for part in content:
            if isinstance(part, dict):
                p_type = part.get("type")
                if p_type == "text" and part.get("text"):
                    segments.append(part["text"])
                elif p_type == "audio":
                    fname = part.get("filename") or "audio"
                    mime = part.get("mime_type") or ""
                    dur = part.get("duration")
                    dur_str = f", {dur}s" if dur else ""
                    segments.append(f"[audio: {fname}{', ' + mime if mime else ''}{dur_str}]")
                elif p_type == "image":
                    fname = part.get("filename") or "image"
                    segments.append(f"[image: {fname}]")
                elif p_type == "document":
                    fname = part.get("filename") or "document"
                    segments.append(f"[document: {fname}]")
            else:
                if hasattr(part, "text") and part.text:
                    segments.append(part.text)
                elif hasattr(part, "type"):
                    if part.type == "audio":
                        fname = getattr(part, "filename", None) or "audio"
                        mime = getattr(part, "mime_type", None) or ""
                        dur = getattr(part, "duration", None)
                        dur_str = f", {dur}s" if dur else ""
                        segments.append(f"[audio: {fname}{', ' + mime if mime else ''}{dur_str}]")
                    elif part.type == "image":
                        fname = getattr(part, "filename", None) or "image"
                        segments.append(f"[image: {fname}]")
                    elif part.type == "document":
                        fname = getattr(part, "filename", None) or "document"
                        segments.append(f"[document: {fname}]")
        return " ".join(segments)

    @staticmethod
    def _format_message(
        text: str,
        role: Literal["user", "assistant"],
        format: HistoryFormat,
    ) -> dict[str, Any]:
        match format:
            case "openai" | "anthropic" | "voyage":
                return {"role": role, "content": text}
            case "google":
                google_role = "model" if role == "assistant" else "user"
                return {"role": google_role, "parts": [{"text": text}]}
            case "cohere":
                cohere_role = "CHATBOT" if role == "assistant" else "USER"
                return {"role": cohere_role, "message": text}
            case _:
                return {"role": role, "content": text}
