from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("x64acp")

from x64acp.a2a import (
    A2AArtifact,
    A2AAssistantCapabilities,
    A2AAssistantCard,
    A2AClient,
    A2AMessageHandler,
    A2AServer,
    A2ASkill,
    A2ATask,
)
from x64acp.analytics import (
    AnalyticsBatch,
    AnalyticsCollector,
    AnalyticsEvent,
    AnalyticsEventPayload,
    AssistantAnalytics,
)
from x64acp.auth import Authentication, Authorization, AuthorizationResult
from x64acp.broadcast import BroadcastManager
from x64acp.config import AssistantServerConfig, Knowledge, KnowledgeScope, Skill
from x64acp.dispatch import DispatchStream
from x64acp.exceptions import AssistantHandlerError, DispatchError
from x64acp.handlers.context import AssistantContext
from x64acp.handlers.incoming import AssistantIncoming
from x64acp.handlers.knowledge import AssistantKnowledge
from x64acp.handlers.memory import AssistantMemory
from x64acp.handlers.pipeline import AssistantHandler, UploadReferenceError
from x64acp.handlers.send import AssistantSend
from x64acp.mcp import MCPClient
from x64acp.persistence.base import Persistence
from x64acp.persistence.upload import UploadEntry
from x64acp.protocol.models import (
    AssistantIdentity,
    AudioPart,
    ContentPart,
    DocumentPart,
    EventType,
    FormCheckboxInput,
    FormElementBase,
    FormFileInput,
    FormOption,
    FormPart,
    FormRadioInput,
    FormSelectInput,
    FormTextareaInput,
    FormTextInput,
    ImagePart,
    Run,
    RunStatus,
    SystemContext,
    TenantScope,
    TextPart,
    Thread,
    ThreadEvent,
    UserIdentity,
    WireC2S_AudioPart,
    WireC2S_ContentPart,
    WireC2S_DocumentPart,
    WireC2S_ImagePart,
    WireC2S_TextPart,
    WireS2C_AudioPart,
    WireS2C_ContentPart,
    WireS2C_DocumentPart,
    WireS2C_ImagePart,
    WireS2C_TextPart,
)
from x64acp.registry import ConnectionRegistry
from x64acp.repository import Repository
from x64acp.server import AssistantServer
from x64acp.settings import (
    AssistantSettings,
    SettingsBroadcaster,
    SettingsField,
    SettingsFieldGroup,
    SettingsFieldType,
    SettingsSchema,
    SettingsScope,
    SettingsSelectOption,
)

__all__ = [
    "Authentication",
    "Authorization",
    "AuthorizationResult",
    "AssistantServerConfig",
    "KnowledgeScope",
    "Knowledge",
    "Skill",
    "AssistantServer",
    "AssistantContext",
    "AssistantIncoming",
    "AssistantSend",
    "AssistantMemory",
    "AssistantKnowledge",
    "ConnectionRegistry",
    "BroadcastManager",
    "Persistence",
    "UploadEntry",
    "DispatchStream",
    "DispatchError",
    "AssistantHandlerError",
    "UploadReferenceError",
    "AssistantHandler",
    "Repository",
    "UserIdentity",
    "AssistantIdentity",
    "SystemContext",
    "TenantScope",
    "ContentPart",
    "TextPart",
    "AudioPart",
    "ImagePart",
    "DocumentPart",
    "WireC2S_ContentPart",
    "WireC2S_TextPart",
    "WireC2S_AudioPart",
    "WireC2S_ImagePart",
    "WireC2S_DocumentPart",
    "WireS2C_ContentPart",
    "WireS2C_TextPart",
    "WireS2C_AudioPart",
    "WireS2C_ImagePart",
    "WireS2C_DocumentPart",
    "Thread",
    "ThreadEvent",
    "Run",
    "RunStatus",
    "EventType",
    "FormOption",
    "FormElementBase",
    "FormTextInput",
    "FormTextareaInput",
    "FormSelectInput",
    "FormRadioInput",
    "FormCheckboxInput",
    "FormFileInput",
    "FormPart",
    "AnalyticsEvent",
    "AnalyticsEventPayload",
    "AnalyticsBatch",
    "AnalyticsCollector",
    "AssistantAnalytics",
    "SettingsFieldType",
    "SettingsField",
    "SettingsFieldGroup",
    "SettingsSelectOption",
    "SettingsScope",
    "SettingsSchema",
    "SettingsBroadcaster",
    "AssistantSettings",
    "A2AServer",
    "A2AClient",
    "A2AAssistantCapabilities",
    "A2AAssistantCard",
    "A2AMessageHandler",
    "A2ASkill",
    "A2ATask",
    "A2AArtifact",
    "MCPClient",
]
