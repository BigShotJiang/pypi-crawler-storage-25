from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from x64acp.protocol.models import TenantScope, UserIdentity

__all__ = ["Authentication", "Authorization", "AuthorizationResult"]


@runtime_checkable
class Authentication(Protocol):
    async def authenticate(self, token: str, user: UserIdentity | None) -> UserIdentity | None: ...


@runtime_checkable
class Authorization(Protocol):
    async def authorize(
        self,
        user: UserIdentity | None,
        tenant: TenantScope,
        action: str,
        resource: dict | None,
    ) -> AuthorizationResult | None: ...


@dataclass
class AuthorizationResult:
    allowed: bool = True
    reason: str | None = None
    context: dict | None = None
