import json
from typing import TypeVar

from pydantic import TypeAdapter

from x64acp.protocol.frames import ClientToServer, ServerToClient

__all__ = ["parse_frame", "serialize_frame"]

T = TypeVar("T")

_client_adapter: TypeAdapter[ClientToServer] = TypeAdapter(ClientToServer)


def parse_frame(data: str) -> ClientToServer:
    raw = json.loads(data)
    return _client_adapter.validate_python(raw)


def serialize_frame(frame: ServerToClient) -> str:
    return frame.model_dump_json(exclude_none=True)
