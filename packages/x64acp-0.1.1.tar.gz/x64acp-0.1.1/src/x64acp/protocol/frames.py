from datetime import datetime
from typing import Annotated, Any, Generic, Literal, TypeVar

from pydantic import BaseModel, Field

from x64acp.analytics.models import AnalyticsEventPayload
from x64acp.protocol.models import (
    AssistantIdentity,
    Run,
    SystemContext,
    TenantScope,
    Thread,
    ThreadEvent,
    UserIdentity,
    WireC2S_ContentPart,
)
from x64acp.settings.models import SettingsField, SettingsFieldGroup

__all__ = [
    "ClientToServer",
    "ServerToClient",
    "C2S_Connect",
    "C2S_ThreadList",
    "C2S_ThreadSubscribe",
    "C2S_ThreadUnsubscribe",
    "C2S_ThreadCreate",
    "C2S_ThreadPatch",
    "C2S_ThreadDelete",
    "C2S_ThreadJoin",
    "C2S_ExternalEvent",
    "C2S_EventCreate",
    "C2S_EventList",
    "C2S_AnalyticsSubscribe",
    "C2S_AnalyticsUnsubscribe",
    "C2S_Feedback",
    "C2S_SettingsSubscribe",
    "C2S_SettingsUnsubscribe",
    "C2S_SettingsPatch",
    "C2S_KnowledgeSelect",
    "C2S_ParticipantsAdd",
    "C2S_ParticipantsRemove",
    "S2C_Ack",
    "S2C_ThreadListResult",
    "S2C_ThreadSnapshot",
    "S2C_EventAppend",
    "S2C_EventListResult",
    "S2C_ThreadUpsert",
    "S2C_ThreadDeleted",
    "S2C_RunUpsert",
    "S2C_AnalyticsEvent",
    "S2C_FeedbackAck",
    "S2C_SettingsSnapshot",
    "S2C_SettingsPatch",
    "S2C_KnowledgeSelected",
]

T = TypeVar("T")


class WSFrame(BaseModel, Generic[T]):
    id: str
    type: str
    payload: T


class ConnectPayload(BaseModel):
    assistant_id: str
    user: UserIdentity | None = None
    assistant: AssistantIdentity | None = None
    tenant: TenantScope = Field(default_factory=TenantScope)
    auth_token: str | None = None
    client: dict | None = None


class ThreadListPayload(BaseModel):
    cursor: str | None = None
    limit: int | None = None
    tenant_filter: dict | None = None
    user_filter: dict | None = None


class ThreadSubscribePayload(BaseModel):
    thread_id: str
    after_event_id: str | None = None


class ThreadUnsubscribePayload(BaseModel):
    thread_id: str


class EventCreateEventPayload(BaseModel):
    type: Literal["message", "message.mention", "skill.invoke", "confirmation.response", "form.response"]
    role: str = "user"
    actor: str = "user"
    content: list[WireC2S_ContentPart]
    data: dict | None = None
    assistant_id: str | None = None
    command: str | None = None
    audience: Literal["user", "assistant"] | None = None


class EventCreatePayload(BaseModel):
    thread_id: str | None = None
    client_event_id: str | None = None
    event_id: str | None = None
    event: EventCreateEventPayload


class C2S_Connect(BaseModel):
    id: str
    type: Literal["connect"]
    payload: ConnectPayload


class C2S_ThreadList(BaseModel):
    id: str
    type: Literal["thread.list"]
    payload: ThreadListPayload


class C2S_ThreadSubscribe(BaseModel):
    id: str
    type: Literal["thread.subscribe"]
    payload: ThreadSubscribePayload


class C2S_ThreadUnsubscribe(BaseModel):
    id: str
    type: Literal["thread.unsubscribe"]
    payload: ThreadUnsubscribePayload


class ThreadDeletePayload(BaseModel):
    thread_id: str


class C2S_ThreadDelete(BaseModel):
    id: str
    type: Literal["thread.delete"]
    payload: ThreadDeletePayload


class C2S_EventCreate(BaseModel):
    id: str
    type: Literal["event.create"]
    payload: EventCreatePayload


class ThreadCreatePayload(BaseModel):
    assistant_id: str
    title: str | None = None
    participants: list[dict] | None = None
    metadata: dict | None = None


class C2S_ThreadCreate(BaseModel):
    id: str
    type: Literal["thread.create"]
    payload: ThreadCreatePayload


class ThreadPatchPayload(BaseModel):
    thread_id: str
    metadata: dict


class C2S_ThreadPatch(BaseModel):
    id: str
    type: Literal["thread.patch"] = "thread.patch"
    payload: ThreadPatchPayload


class AnalyticsSubscribePayload(BaseModel):
    assistant_id: str


class AnalyticsUnsubscribePayload(BaseModel):
    assistant_id: str


class FeedbackPayload(BaseModel):
    target_type: Literal["event", "run", "thread"]
    target_id: str
    feedback: Literal["like", "dislike"]
    reason: str | None = None
    classification: str | None = None


class C2S_AnalyticsSubscribe(BaseModel):
    id: str
    type: Literal["analytics.subscribe"]
    payload: AnalyticsSubscribePayload


class C2S_AnalyticsUnsubscribe(BaseModel):
    id: str
    type: Literal["analytics.unsubscribe"]
    payload: AnalyticsUnsubscribePayload


class C2S_Feedback(BaseModel):
    id: str
    type: Literal["feedback"]
    payload: FeedbackPayload


class EventListPayload(BaseModel):
    thread_id: str
    before_event_id: str | None = None
    limit: int = 50


class C2S_EventList(BaseModel):
    id: str
    type: Literal["event.list"] = "event.list"
    payload: EventListPayload


class SettingsSubscribePayload(BaseModel):
    assistant_id: str
    scope: str = ""
    scope_id: str = ""


class SettingsUnsubscribePayload(BaseModel):
    assistant_id: str
    scope: str = ""
    scope_id: str = ""


class SettingsPatchPayload(BaseModel):
    field_id: str
    value: Any
    scope: str = ""
    scope_id: str = ""


class C2S_SettingsSubscribe(BaseModel):
    id: str
    type: Literal["settings.subscribe"]
    payload: SettingsSubscribePayload


class C2S_SettingsUnsubscribe(BaseModel):
    id: str
    type: Literal["settings.unsubscribe"]
    payload: SettingsUnsubscribePayload


class C2S_SettingsPatch(BaseModel):
    id: str
    type: Literal["settings.patch"]
    payload: SettingsPatchPayload


class ThreadJoinPayload(BaseModel):
    thread_id: str


class C2S_ThreadJoin(BaseModel):
    id: str
    type: Literal["thread.join"]
    payload: ThreadJoinPayload


class ExternalEventData(BaseModel):
    id: str
    type: str
    role: str = "user"
    actor: str = "user"
    display_name: str | None = None
    user: UserIdentity | None = None
    assistant: AssistantIdentity | None = None
    system: SystemContext | None = None
    tenant: TenantScope | None = None
    content: list[dict[str, Any]] | None = None
    data: dict[str, Any] | None = None
    created_at: str | None = None
    assistant_id: str | None = None


class ExternalEventPayload(BaseModel):
    thread_id: str
    event: ExternalEventData
    trigger_handler: bool = False


class C2S_ExternalEvent(BaseModel):
    id: str
    type: Literal["event.external"]
    payload: ExternalEventPayload


class KnowledgeSelectPayload(BaseModel):
    source_ids: list[str]


class C2S_KnowledgeSelect(BaseModel):
    id: str
    type: Literal["knowledge.select"]
    payload: KnowledgeSelectPayload


class ParticipantsAddPayload(BaseModel):
    thread_id: str
    participants: list[dict]


class C2S_ParticipantsAdd(BaseModel):
    id: str
    type: Literal["participants.add"]
    payload: ParticipantsAddPayload


class ParticipantsRemovePayload(BaseModel):
    thread_id: str
    participant_ids: list[str]


class C2S_ParticipantsRemove(BaseModel):
    id: str
    type: Literal["participants.remove"]
    payload: ParticipantsRemovePayload


ClientToServer = Annotated[
    C2S_Connect
    | C2S_ThreadList
    | C2S_ThreadSubscribe
    | C2S_ThreadUnsubscribe
    | C2S_ThreadCreate
    | C2S_ThreadPatch
    | C2S_ThreadDelete
    | C2S_ThreadJoin
    | C2S_ExternalEvent
    | C2S_EventCreate
    | C2S_EventList
    | C2S_AnalyticsSubscribe
    | C2S_AnalyticsUnsubscribe
    | C2S_Feedback
    | C2S_SettingsSubscribe
    | C2S_SettingsUnsubscribe
    | C2S_SettingsPatch
    | C2S_KnowledgeSelect
    | C2S_ParticipantsAdd
    | C2S_ParticipantsRemove,
    Field(discriminator="type"),
]


class SkillPayload(BaseModel):
    command: str
    description: str


class KnowledgePayload(BaseModel):
    id: str
    name: str
    scope: str
    description: str


class ServerFeaturesPayload(BaseModel):
    assistant_name: str = "Assistant"
    analytics_enabled: bool = False
    settings_enabled: bool = False
    skills_enabled: bool = False
    upload_enabled: bool = False
    knowledge_enabled: bool = False
    skills: list[SkillPayload] | None = None
    knowledge: list[KnowledgePayload] | None = None


class AckPayload(BaseModel):
    ack_id: str
    ok: bool
    error: dict | None = None
    server_features: ServerFeaturesPayload | None = None
    thread: Thread | None = None


class ThreadListResultPayload(BaseModel):
    threads: list[Thread]
    cursor: str | None = None
    total_count: int = 0


class ThreadSnapshotPayload(BaseModel):
    thread: Thread
    events: list[ThreadEvent]
    runs: list[Run] | None = None


class EventAppendPayload(BaseModel):
    thread_id: str
    events: list[ThreadEvent]


class ThreadUpsertPayload(BaseModel):
    thread: Thread


class RunUpsertPayload(BaseModel):
    run: Run


class S2C_Ack(BaseModel):
    id: str
    type: Literal["ack"] = "ack"
    payload: AckPayload


class S2C_ThreadListResult(BaseModel):
    id: str
    type: Literal["thread.list.result"] = "thread.list.result"
    payload: ThreadListResultPayload


class S2C_ThreadSnapshot(BaseModel):
    id: str
    type: Literal["thread.snapshot"] = "thread.snapshot"
    payload: ThreadSnapshotPayload


class S2C_EventAppend(BaseModel):
    id: str
    type: Literal["event.append"] = "event.append"
    payload: EventAppendPayload


class S2C_ThreadUpsert(BaseModel):
    id: str
    type: Literal["thread.upsert"] = "thread.upsert"
    payload: ThreadUpsertPayload


class EventListResultPayload(BaseModel):
    thread_id: str
    events: list[ThreadEvent]
    cursor: str | None = None
    has_more: bool = False


class S2C_EventListResult(BaseModel):
    id: str
    type: Literal["event.list.result"] = "event.list.result"
    payload: EventListResultPayload


class ThreadDeletedPayload(BaseModel):
    thread_id: str


class S2C_ThreadDeleted(BaseModel):
    id: str
    type: Literal["thread.deleted"] = "thread.deleted"
    payload: ThreadDeletedPayload


class S2C_RunUpsert(BaseModel):
    id: str
    type: Literal["run.upsert"] = "run.upsert"
    payload: RunUpsertPayload


class S2C_AnalyticsEvent(BaseModel):
    id: str
    type: Literal["analytics.event"] = "analytics.event"
    payload: AnalyticsEventPayload


class FeedbackAckPayload(BaseModel):
    target_type: str
    target_id: str
    feedback: str
    ok: bool


class S2C_FeedbackAck(BaseModel):
    id: str
    type: Literal["feedback.ack"] = "feedback.ack"
    payload: FeedbackAckPayload


class SettingsSnapshotPayload(BaseModel):
    assistant_id: str
    fields: list[SettingsField | SettingsFieldGroup]
    updated_at: datetime
    scope: str = ""
    scope_id: str = ""


class S2C_SettingsSnapshot(BaseModel):
    id: str
    type: Literal["settings.snapshot"] = "settings.snapshot"
    payload: SettingsSnapshotPayload


class SettingsPatchBroadcastPayload(BaseModel):
    assistant_id: str
    field_id: str
    value: Any
    updated_at: datetime
    scope: str = ""
    scope_id: str = ""


class S2C_SettingsPatch(BaseModel):
    id: str
    type: Literal["settings.patch"] = "settings.patch"
    payload: SettingsPatchBroadcastPayload


class KnowledgeSelectedPayload(BaseModel):
    source_ids: list[str]


class S2C_KnowledgeSelected(BaseModel):
    id: str
    type: Literal["knowledge.selected"] = "knowledge.selected"
    payload: KnowledgeSelectedPayload


ServerToClient = (
    S2C_Ack
    | S2C_ThreadListResult
    | S2C_ThreadSnapshot
    | S2C_EventAppend
    | S2C_EventListResult
    | S2C_ThreadUpsert
    | S2C_ThreadDeleted
    | S2C_RunUpsert
    | S2C_AnalyticsEvent
    | S2C_FeedbackAck
    | S2C_SettingsSnapshot
    | S2C_SettingsPatch
    | S2C_KnowledgeSelected
)
