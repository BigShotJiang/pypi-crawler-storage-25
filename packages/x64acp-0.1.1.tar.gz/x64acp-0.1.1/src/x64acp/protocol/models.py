from datetime import datetime
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "EventType",
    "RunStatus",
    "TextPart",
    "AudioPart",
    "ImagePart",
    "DocumentPart",
    "ContentPart",
    "WireC2S_TextPart",
    "WireC2S_AudioPart",
    "WireC2S_ImagePart",
    "WireC2S_DocumentPart",
    "WireC2S_ContentPart",
    "WireS2C_TextPart",
    "WireS2C_AudioPart",
    "WireS2C_ImagePart",
    "WireS2C_DocumentPart",
    "WireS2C_ContentPart",
    "FormOption",
    "FormElementBase",
    "FormTextInput",
    "FormTextareaInput",
    "FormSelectInput",
    "FormRadioInput",
    "FormCheckboxInput",
    "FormFileInput",
    "FormPart",
    "UserIdentity",
    "AssistantIdentity",
    "SystemContext",
    "TenantScope",
    "Thread",
    "ThreadEvent",
    "Run",
]

EventType = Literal[
    "message",
    "message.mention",
    "analysis.report",
    "skill.invoke",
    "run.started",
    "run.finished",
    "tool.call",
    "tool.result",
    "tool.transaction",
    "confirmation.request",
    "confirmation.response",
    "form",
    "form.response",
]
RunStatus = Literal["running", "succeeded", "failed", "canceled"]


class TextPart(BaseModel):
    type: Literal["text"] = "text"
    text: str


class AudioPart(BaseModel):
    type: Literal["audio"] = "audio"
    data: bytes
    mime_type: str
    duration: float | None = None
    filename: str | None = None


class ImagePart(BaseModel):
    type: Literal["image"] = "image"
    data: bytes
    mime_type: str
    width: int | None = None
    height: int | None = None
    filename: str | None = None


class DocumentPart(BaseModel):
    type: Literal["document"] = "document"
    data: bytes
    mime_type: str
    filename: str
    size_bytes: int


ContentPart = Annotated[
    TextPart | AudioPart | ImagePart | DocumentPart,
    Field(discriminator="type"),
]


# ---------------------------------------------------------------------------
# Form element models
# ---------------------------------------------------------------------------


class FormOption(BaseModel):
    value: str
    label: str


class FormElementBase(BaseModel):
    name: str
    label: str
    order: int = 0
    required: bool = False
    disabled: bool = False
    placeholder: str | None = None


class FormTextInput(FormElementBase):
    type: Literal["text_input"] = "text_input"
    default: str | None = None
    input_type: Literal["text", "password", "email", "number"] = "text"


class FormTextareaInput(FormElementBase):
    type: Literal["textarea_input"] = "textarea_input"
    default: str | None = None
    rows: int | None = None


class FormSelectInput(FormElementBase):
    type: Literal["select_input"] = "select_input"
    options: list[FormOption]
    default: str | None = None


class FormRadioInput(FormElementBase):
    type: Literal["radio_input"] = "radio_input"
    options: list[FormOption]
    default: str | None = None
    variant: Literal["native", "button"] = "native"


class FormCheckboxInput(FormElementBase):
    type: Literal["checkbox_input"] = "checkbox_input"
    options: list[FormOption]
    default: list[str] | None = None
    variant: Literal["native", "button"] = "native"


class FormFileInput(FormElementBase):
    type: Literal["file_input"] = "file_input"
    upload_url: str | None = None
    accept: str | None = None
    multiple: bool = False


FormPart = Annotated[
    FormTextInput | FormTextareaInput | FormSelectInput | FormRadioInput | FormCheckboxInput | FormFileInput,
    Field(discriminator="type"),
]


class WireC2S_TextPart(BaseModel):
    type: Literal["text"] = "text"
    text: str


class WireC2S_AudioPart(BaseModel):
    type: Literal["audio"] = "audio"
    ref_id: str
    duration: float | None = None


class WireC2S_ImagePart(BaseModel):
    type: Literal["image"] = "image"
    ref_id: str


class WireC2S_DocumentPart(BaseModel):
    type: Literal["document"] = "document"
    ref_id: str


WireC2S_ContentPart = Annotated[
    WireC2S_TextPart | WireC2S_AudioPart | WireC2S_ImagePart | WireC2S_DocumentPart,
    Field(discriminator="type"),
]


class WireS2C_TextPart(BaseModel):
    type: Literal["text"] = "text"
    text: str


class WireS2C_AudioPart(BaseModel):
    type: Literal["audio"] = "audio"
    url: str | None = None
    mime_type: str | None = None
    duration: float | None = None
    filename: str | None = None


class WireS2C_ImagePart(BaseModel):
    type: Literal["image"] = "image"
    url: str | None = None
    mime_type: str | None = None
    width: int | None = None
    height: int | None = None
    alt: str | None = None
    filename: str | None = None


class WireS2C_DocumentPart(BaseModel):
    type: Literal["document"] = "document"
    url: str | None = None
    filename: str | None = None
    mime_type: str | None = None
    size_bytes: int | None = None


WireS2C_ContentPart = Annotated[
    WireS2C_TextPart | WireS2C_AudioPart | WireS2C_ImagePart | WireS2C_DocumentPart,
    Field(discriminator="type"),
]

_S2C_TYPE_MAP: dict[str, type] = {
    "text": WireS2C_TextPart,
    "audio": WireS2C_AudioPart,
    "image": WireS2C_ImagePart,
    "document": WireS2C_DocumentPart,
}


def deserialize_s2c_part(data: dict) -> WireS2C_ContentPart:
    """Deserialize a dict into a typed WireS2C content part."""
    cls = _S2C_TYPE_MAP.get(data.get("type", ""))
    if cls is None:
        raise ValueError(f"Unknown content part type: {data.get('type')!r}")
    return cls(**data)


class UserIdentity(BaseModel):
    model_config = ConfigDict(extra="allow")
    id: str = ""
    role: str = ""


class AssistantIdentity(BaseModel):
    model_config = ConfigDict(extra="allow")
    id: str = ""
    name: str = ""
    role: str = ""


class SystemContext(BaseModel):
    model_config = ConfigDict(extra="allow")
    id: str = ""
    role: str = ""


class TenantScope(BaseModel):
    model_config = ConfigDict(extra="allow")


class ThreadEvent(BaseModel):
    id: str
    thread_id: str
    run_id: str | None = None
    type: EventType
    role: str = "user"
    actor: str
    display_name: str | None = None
    user: UserIdentity | None = None
    assistant: AssistantIdentity | None = None
    system: SystemContext | None = None
    tenant: TenantScope | None = None
    content: list[WireS2C_ContentPart] | None = None
    data: dict | None = None
    assistant_id: str | None = None
    command: str | None = None
    audience: Literal["user", "assistant"] | None = None
    created_at: datetime
    streaming: bool | None = None
    finalized: bool | None = None
    client_event_id: str | None = None


class Thread(BaseModel):
    id: str
    assistant_id: str
    owner_user: UserIdentity | None = None
    owner_tenant: TenantScope | None = None
    participants: list[dict] = []
    title: str | None = None
    external: bool = False
    metadata: dict | None = None
    created_at: datetime
    updated_at: datetime
    last_event_at: datetime


class Run(BaseModel):
    id: str
    thread_id: str
    blueprint_id: str | None = None
    status: RunStatus
    started_at: datetime
    ended_at: datetime | None = None
    error: str | None = None
