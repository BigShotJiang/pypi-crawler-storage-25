from __future__ import annotations

import asyncio
import logging

from x64acp import __version__
from x64acp.jsonrpc import BaseJsonRpcClient
from x64acp.mcp.models import MCPContentPart, MCPResource, MCPResourceContent, MCPTextContent, MCPTool, MCPToolResult

__all__ = ["MCPClient", "MCPClientError"]

logger = logging.getLogger(__name__)

MCP_PROTOCOL_VERSION = "2025-03-26"


class MCPClient(BaseJsonRpcClient):
    """Client for connecting to MCP-compliant tool servers over Streamable HTTP."""

    def __init__(self, servers: dict[str, str], timeout: float = 30.0):
        """Initialize with pre-configured named MCP servers.

        Args:
            servers: Mapping of server name to URL.
                     Example: {"rag": "http://rag-server:8000/mcp"}
            timeout: HTTP request timeout in seconds.
        """
        super().__init__(endpoints=servers, timeout=timeout)
        self._tools: dict[str, list[MCPTool]] = {}
        self._resources: dict[str, list[MCPResource]] = {}
        self._session_ids: dict[str, str] = {}

    def _mcp_headers(self, server_name: str) -> dict[str, str]:
        headers = {"Accept": "application/json, text/event-stream"}
        session_id = self._session_ids.get(server_name)
        if session_id:
            headers["Mcp-Session-Id"] = session_id
        return headers

    async def connect(self) -> None:
        """Initialize sessions with all configured servers and discover capabilities."""
        await asyncio.gather(*(self._connect_server(name) for name in self._endpoints))

    async def _connect_server(self, server_name: str) -> None:
        """Initialize a single server and discover its capabilities."""
        await self._initialize_server(server_name)
        tools, resources = await asyncio.gather(
            self._fetch_tools(server_name),
            self._fetch_resources(server_name),
        )
        self._tools[server_name] = tools
        self._resources[server_name] = resources

    async def _initialize_server(self, server_name: str) -> None:
        """MCP initialize handshake."""
        body = await self._rpc(
            server_name,
            "initialize",
            {
                "protocolVersion": MCP_PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "x64acp-mcp-client", "version": __version__},
            },
            headers=self._mcp_headers(server_name),
        )
        self._capture_session_id(server_name, body)
        logger.info("MCP initialized %s: %s", server_name, body.get("result", {}).get("serverInfo", {}))

        await self._notify(server_name, "notifications/initialized", headers=self._mcp_headers(server_name))

    def _capture_session_id(self, server_name: str, body: dict) -> None:
        """Store session ID if present in response (checked via raw body)."""
        pass

    async def _fetch_tools(self, server_name: str) -> list[MCPTool]:
        body = await self._rpc(server_name, "tools/list", headers=self._mcp_headers(server_name))
        raw_tools = body.get("result", {}).get("tools", [])
        return [MCPTool.model_validate(t) for t in raw_tools]

    async def _fetch_resources(self, server_name: str) -> list[MCPResource]:
        body = await self._rpc(server_name, "resources/list", headers=self._mcp_headers(server_name))
        raw_resources = body.get("result", {}).get("resources", [])
        return [MCPResource.model_validate(r) for r in raw_resources]

    def get_tools(self, server_name: str) -> list[MCPTool]:
        """Return discovered tools for a server."""
        return self._tools.get(server_name, [])

    def get_resources(self, server_name: str) -> list[MCPResource]:
        """Return discovered resources for a server."""
        return self._resources.get(server_name, [])

    async def call_tool(
        self,
        server_name: str,
        tool_name: str,
        arguments: dict | None = None,
    ) -> MCPToolResult:
        """Call a tool on a specific MCP server."""
        body = await self._rpc(
            server_name,
            "tools/call",
            {"name": tool_name, "arguments": arguments or {}},
            headers=self._mcp_headers(server_name),
        )
        return MCPToolResult.model_validate(body.get("result", {}))

    async def read_resource(
        self,
        server_name: str,
        uri: str,
    ) -> MCPResourceContent:
        """Read a resource from a specific MCP server."""
        body = await self._rpc(
            server_name,
            "resources/read",
            {"uri": uri},
            headers=self._mcp_headers(server_name),
        )
        contents = body.get("result", {}).get("contents", [])
        parts: list[MCPContentPart] = []
        for c in contents:
            if "text" in c:
                parts.append(MCPTextContent(text=c["text"]))
        return MCPResourceContent(uri=uri, content=parts)


class MCPClientError(Exception):
    pass
