from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

__all__ = [
    "MCPTool",
    "MCPResource",
    "MCPTextContent",
    "MCPImageContent",
    "MCPContentPart",
    "MCPToolResult",
    "MCPResourceContent",
]


class _MCPBase(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class MCPTool(_MCPBase):
    name: str
    description: str = ""
    input_schema: dict = Field(default_factory=dict, alias="inputSchema")


class MCPResource(_MCPBase):
    uri: str
    name: str
    description: str | None = None
    mime_type: str | None = Field(default=None, alias="mimeType")


class MCPTextContent(BaseModel):
    type: Literal["text"] = "text"
    text: str


class MCPImageContent(BaseModel):
    type: Literal["image"] = "image"
    data: str
    mime_type: str = Field(alias="mimeType")

    model_config = ConfigDict(populate_by_name=True)


MCPContentPart = Annotated[MCPTextContent | MCPImageContent, Field(discriminator="type")]


class MCPToolResult(BaseModel):
    content: list[MCPContentPart] = []
    is_error: bool = Field(default=False, alias="isError")

    model_config = ConfigDict(populate_by_name=True)


class MCPResourceContent(BaseModel):
    uri: str
    content: list[MCPContentPart] = []
