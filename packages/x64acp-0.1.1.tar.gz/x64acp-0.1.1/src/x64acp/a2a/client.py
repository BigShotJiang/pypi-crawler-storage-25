from __future__ import annotations

import json
import logging
import uuid
from collections.abc import AsyncGenerator

from x64acp.a2a.models import (
    A2AAssistantCard,
    A2AEvent,
    A2ATask,
    A2ATaskArtifactUpdateEvent,
    A2ATaskStatusUpdateEvent,
)
from x64acp.jsonrpc import BaseJsonRpcClient, JsonRpcRequest

__all__ = ["A2AClient", "A2AClientError"]

logger = logging.getLogger(__name__)


class A2AClient(BaseJsonRpcClient):
    """Client for communicating with A2A-compliant assistant servers."""

    def __init__(self, assistants: dict[str, str], timeout: float = 30.0):
        """Initialize with pre-configured named assistants.

        Args:
            assistants: Mapping of assistant name to base URL.
                    Example: {"amazon": "http://localhost:8003/amazon"}
            timeout: HTTP request timeout in seconds.
        """
        super().__init__(endpoints=assistants, timeout=timeout)
        self._cards: dict[str, A2AAssistantCard] = {}

    async def discover(self, assistant_name: str) -> A2AAssistantCard:
        """Fetch assistant card from /.well-known/assistant-card.json."""
        url = self._get_url(assistant_name)
        response = await self._http.get(f"{url}/.well-known/assistant-card.json")
        response.raise_for_status()
        card = A2AAssistantCard.model_validate(response.json())
        self._cards[assistant_name] = card
        return card

    def get_card(self, assistant_name: str) -> A2AAssistantCard | None:
        """Return a previously discovered assistant card, or None."""
        return self._cards.get(assistant_name)

    async def send(
        self,
        assistant_name: str,
        message: str,
        context_id: str | None = None,
    ) -> A2ATask:
        """Send a message via message/send (synchronous, returns completed A2ATask)."""
        url = self._get_url(assistant_name)
        rpc_request = self._build_a2a_request("message/send", message, context_id)

        response = await self._http.post(
            f"{url}/a2a",
            json=rpc_request.model_dump(by_alias=True, exclude_none=True),
        )
        response.raise_for_status()

        body = response.json()
        if "error" in body and body["error"]:
            raise A2AClientError(f"A2A error from {assistant_name}: {body['error']}")

        return A2ATask.model_validate(body["result"])

    async def stream(
        self,
        assistant_name: str,
        message: str,
        context_id: str | None = None,
    ) -> AsyncGenerator[A2AEvent, None]:
        """Send a message via message/stream (SSE, yields events)."""
        url = self._get_url(assistant_name)
        rpc_request = self._build_a2a_request("message/stream", message, context_id)

        async with self._http.stream(
            "POST",
            f"{url}/a2a",
            json=rpc_request.model_dump(by_alias=True, exclude_none=True),
        ) as response:
            response.raise_for_status()
            async for event in self._parse_sse(response):
                yield event

    async def _parse_sse(self, response) -> AsyncGenerator[A2AEvent, None]:
        """Parse SSE lines from a streaming response."""
        buffer = ""
        async for chunk in response.aiter_text():
            buffer += chunk
            while "\n\n" in buffer:
                event_text, buffer = buffer.split("\n\n", 1)
                for line in event_text.strip().split("\n"):
                    if line.startswith("data: "):
                        data = json.loads(line[6:])
                        result = data.get("result", {})
                        event = self._parse_event(result)
                        if event:
                            yield event

    def _parse_event(self, result: dict) -> A2AEvent | None:
        """Parse a JSON-RPC result into an A2AEvent."""
        kind = result.get("kind")
        if kind == "status-update":
            return A2ATaskStatusUpdateEvent.model_validate(result)
        elif kind == "artifact-update":
            return A2ATaskArtifactUpdateEvent.model_validate(result)
        return None

    def _build_a2a_request(
        self,
        method: str,
        message: str,
        context_id: str | None,
    ) -> JsonRpcRequest:
        params: dict = {
            "message": {
                "role": "user",
                "parts": [{"kind": "text", "text": message}],
                "messageId": str(uuid.uuid4()),
            },
        }
        if context_id:
            params["configuration"] = {"contextId": context_id}

        return JsonRpcRequest(
            id=str(uuid.uuid4()),
            method=method,
            params=params,
        )


class A2AClientError(Exception):
    pass
