from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from importlib.metadata import version as _pkg_version
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

_SDK_VERSION = _pkg_version("x64acp")

__all__ = [
    "A2ATaskState",
    "A2ATextPart",
    "A2AFileContent",
    "A2AFilePart",
    "A2APart",
    "A2AMessage",
    "A2ATaskStatus",
    "A2AArtifact",
    "A2ATask",
    "A2ASkill",
    "A2AAssistantCapabilities",
    "A2AProvider",
    "A2AAssistantCard",
    "A2ATaskStatusUpdateEvent",
    "A2ATaskArtifactUpdateEvent",
    "A2AEvent",
]


class _A2ABase(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class A2ATaskState(StrEnum):
    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input-required"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"
    REJECTED = "rejected"
    AUTH_REQUIRED = "auth-required"


class A2ATextPart(_A2ABase):
    kind: Literal["text"] = "text"
    text: str


class A2AFileContent(_A2ABase):
    mime_type: str
    data: str | None = None
    uri: str | None = None


class A2AFilePart(_A2ABase):
    kind: Literal["file"] = "file"
    file: A2AFileContent


A2APart = Annotated[A2ATextPart | A2AFilePart, Field(discriminator="kind")]


class A2AMessage(_A2ABase):
    role: Literal["user", "assistant"]
    parts: list[A2APart]
    message_id: str
    task_id: str | None = None
    context_id: str | None = None


class A2ATaskStatus(_A2ABase):
    state: A2ATaskState
    timestamp: datetime | None = None
    message: A2AMessage | None = None


class A2AArtifact(_A2ABase):
    artifact_id: str
    name: str | None = None
    parts: list[A2APart]


class A2ATask(_A2ABase):
    id: str
    context_id: str
    status: A2ATaskStatus
    artifacts: list[A2AArtifact] = []
    history: list[A2AMessage] = []
    kind: Literal["task"] = "task"
    metadata: dict | None = None


class A2ASkill(_A2ABase):
    id: str
    name: str
    description: str
    tags: list[str] = []
    examples: list[str] = []
    input_modes: list[str] = ["text/plain"]
    output_modes: list[str] = ["text/plain"]


class A2AAssistantCapabilities(_A2ABase):
    streaming: bool = False
    push_notifications: bool = False
    state_transition_history: bool = False


class A2AProvider(_A2ABase):
    organization: str
    url: str | None = None


class A2AAssistantCard(_A2ABase):
    name: str
    description: str
    url: str
    version: str = _SDK_VERSION
    protocol_version: str = "0.3.0"
    capabilities: A2AAssistantCapabilities = A2AAssistantCapabilities()
    skills: list[A2ASkill] = []
    default_input_modes: list[str] = ["text/plain"]
    default_output_modes: list[str] = ["text/plain"]
    provider: A2AProvider | None = None
    security_schemes: dict | None = None
    security: list | None = None


class A2ATaskStatusUpdateEvent(_A2ABase):
    task_id: str
    context_id: str
    status: A2ATaskStatus
    final: bool = False
    kind: Literal["status-update"] = "status-update"


class A2ATaskArtifactUpdateEvent(_A2ABase):
    task_id: str
    context_id: str
    artifact: A2AArtifact
    append: bool = False
    last_chunk: bool = False
    kind: Literal["artifact-update"] = "artifact-update"


A2AEvent = A2ATaskStatusUpdateEvent | A2ATaskArtifactUpdateEvent
