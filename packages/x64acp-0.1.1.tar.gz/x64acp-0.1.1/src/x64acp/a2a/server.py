from __future__ import annotations

import json
import logging
import uuid
from collections.abc import AsyncGenerator, Callable
from datetime import UTC, datetime

from x64acp.a2a.models import (
    A2AArtifact,
    A2AAssistantCard,
    A2AEvent,
    A2AMessage,
    A2ATask,
    A2ATaskArtifactUpdateEvent,
    A2ATaskState,
    A2ATaskStatus,
    A2ATaskStatusUpdateEvent,
    A2ATextPart,
)
from x64acp.jsonrpc import JsonRpcRequest

__all__ = ["A2AServer", "A2AMessageHandler"]

logger = logging.getLogger(__name__)

try:
    from fastapi import APIRouter, Request  # type: ignore[import-not-found]
    from fastapi.responses import JSONResponse, StreamingResponse  # type: ignore[import-not-found]

    _HAS_FASTAPI = True
except ImportError:
    _HAS_FASTAPI = False

A2AMessageHandler = Callable[
    [A2AMessage, str | None],
    AsyncGenerator[A2AEvent, None],
]


class A2AServer:
    def __init__(self, assistant_card: A2AAssistantCard):
        if not _HAS_FASTAPI:
            raise ImportError("A2AServer requires fastapi. Install it with: pip install fastapi")

        self._assistant_card = assistant_card
        self._assistant_card_json = assistant_card.model_dump(by_alias=True, exclude_none=True)
        self._handler: A2AMessageHandler | None = None
        self.router = APIRouter()
        self._register_routes()

    @property
    def assistant_card(self) -> A2AAssistantCard:
        return self._assistant_card

    def on_message(self, fn: A2AMessageHandler) -> A2AMessageHandler:
        """Decorator to register the message handler callback.

        The callback receives an A2A Message + context_id and must return
        an AsyncGenerator yielding A2AEvent objects.
        """
        self._handler = fn
        return fn

    def _register_routes(self) -> None:
        @self.router.get("/.well-known/assistant-card.json")
        async def get_assistant_card() -> JSONResponse:
            return JSONResponse(content=self._assistant_card_json)

        @self.router.post("/a2a", response_model=None)
        async def handle_jsonrpc(request: Request):
            body = await request.json()

            try:
                rpc_request = JsonRpcRequest.model_validate(body)
            except Exception as e:
                return JSONResponse(
                    content=_error_response(body.get("id", 0), -32600, f"Invalid request: {e}"),
                    status_code=400,
                )

            if rpc_request.method == "message/send":
                return await self._handle_send(rpc_request)
            elif rpc_request.method == "message/stream":
                return await self._handle_stream(rpc_request)
            else:
                return JSONResponse(
                    content=_error_response(rpc_request.id, -32601, f"Method not found: {rpc_request.method}"),
                    status_code=400,
                )

    def _extract_message(self, rpc_request: JsonRpcRequest) -> tuple[A2AMessage, str]:
        """Extract A2AMessage and context_id from JSON-RPC params."""
        params = rpc_request.params or {}
        message_data = params.get("message", {})

        if not message_data.get("messageId"):
            message_data["messageId"] = str(uuid.uuid4())

        message = A2AMessage.model_validate(message_data)

        config = params.get("configuration", {})
        context_id = config.get("contextId") or message.context_id or str(uuid.uuid4())

        return message, context_id

    async def _handle_send(self, rpc_request: JsonRpcRequest) -> JSONResponse:
        """Synchronous message/send — collect all events, return final Task."""
        if not self._handler:
            return JSONResponse(
                content=_error_response(rpc_request.id, -32603, "No handler registered"),
                status_code=500,
            )

        message, context_id = self._extract_message(rpc_request)
        task_id = str(uuid.uuid4())

        artifacts: list[A2AArtifact] = []
        last_status = A2ATaskStatus(state=A2ATaskState.WORKING, timestamp=datetime.now(UTC))

        try:
            async for event in self._handler(message, context_id):
                if isinstance(event, A2ATaskArtifactUpdateEvent):
                    artifacts.append(event.artifact)
                elif isinstance(event, A2ATaskStatusUpdateEvent):
                    last_status = event.status
        except Exception as e:
            logger.exception("A2A handler error")
            last_status = A2ATaskStatus(
                state=A2ATaskState.FAILED,
                timestamp=datetime.now(UTC),
                message=A2AMessage(
                    role="assistant",
                    parts=[A2ATextPart(text=str(e))],
                    message_id=str(uuid.uuid4()),
                ),
            )

        if last_status.state == A2ATaskState.WORKING:
            last_status = A2ATaskStatus(state=A2ATaskState.COMPLETED, timestamp=datetime.now(UTC))

        task = A2ATask(
            id=task_id,
            context_id=context_id,
            status=last_status,
            artifacts=artifacts,
            history=[message],
        )

        return JSONResponse(
            content={
                "jsonrpc": "2.0",
                "id": rpc_request.id,
                "result": task.model_dump(by_alias=True, exclude_none=True),
            },
        )

    async def _handle_stream(self, rpc_request: JsonRpcRequest):
        """Streaming message/stream — yield SSE events."""
        if not self._handler:
            return JSONResponse(
                content=_error_response(rpc_request.id, -32603, "No handler registered"),
                status_code=500,
            )

        message, context_id = self._extract_message(rpc_request)
        task_id = str(uuid.uuid4())
        handler = self._handler

        async def event_stream() -> AsyncGenerator[str, None]:
            submitted = A2ATaskStatusUpdateEvent(
                task_id=task_id,
                context_id=context_id,
                status=A2ATaskStatus(state=A2ATaskState.SUBMITTED, timestamp=datetime.now(UTC)),
            )
            yield _sse_line(rpc_request.id, submitted)

            handler_sent_final = False
            try:
                async for event in handler(message, context_id):
                    event.task_id = task_id
                    event.context_id = context_id
                    if isinstance(event, A2ATaskStatusUpdateEvent) and event.final:
                        handler_sent_final = True
                    yield _sse_line(rpc_request.id, event)
            except Exception:
                logger.exception("A2A stream handler error")
                error_event = A2ATaskStatusUpdateEvent(
                    task_id=task_id,
                    context_id=context_id,
                    status=A2ATaskStatus(state=A2ATaskState.FAILED, timestamp=datetime.now(UTC)),
                    final=True,
                )
                yield _sse_line(rpc_request.id, error_event)
                return

            if not handler_sent_final:
                final_event = A2ATaskStatusUpdateEvent(
                    task_id=task_id,
                    context_id=context_id,
                    status=A2ATaskStatus(state=A2ATaskState.COMPLETED, timestamp=datetime.now(UTC)),
                    final=True,
                )
                yield _sse_line(rpc_request.id, final_event)

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
        )


def _sse_line(rpc_id: str | int, event: A2AEvent) -> str:
    """Format an A2A event as an SSE data line."""
    payload = {
        "jsonrpc": "2.0",
        "id": rpc_id,
        "result": event.model_dump(by_alias=True, exclude_none=True),
    }
    return f"data: {json.dumps(payload)}\n\n"


def _error_response(rpc_id: str | int, code: int, message: str) -> dict:
    """Build a JSON-RPC error response dict."""
    return {
        "jsonrpc": "2.0",
        "id": rpc_id,
        "error": {"code": code, "message": message},
    }
