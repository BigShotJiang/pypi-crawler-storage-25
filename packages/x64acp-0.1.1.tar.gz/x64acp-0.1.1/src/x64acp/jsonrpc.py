from __future__ import annotations

import uuid
from typing import Any, Literal

import httpx
from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel


class _JsonRpcBase(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )


class JsonRpcRequest(_JsonRpcBase):
    jsonrpc: Literal["2.0"] = "2.0"
    id: str | int
    method: str
    params: dict | None = None


class JsonRpcResponse(_JsonRpcBase):
    jsonrpc: Literal["2.0"] = "2.0"
    id: str | int
    result: dict | None = None
    error: dict | None = None


class JsonRpcError(_JsonRpcBase):
    code: int
    message: str
    data: dict | None = None


class BaseJsonRpcClient:
    """Shared base for JSON-RPC 2.0 HTTP clients."""

    def __init__(self, endpoints: dict[str, str], timeout: float = 30.0):
        self._endpoints = endpoints
        self._http = httpx.AsyncClient(timeout=timeout)

    def _get_url(self, name: str) -> str:
        url = self._endpoints.get(name)
        if not url:
            raise ValueError(f"Unknown endpoint: {name!r}. Available: {list(self._endpoints.keys())}")
        return url

    async def _rpc(self, name: str, method: str, params: dict | None = None, headers: dict | None = None) -> dict:
        """Send a JSON-RPC request and return the result dict."""
        url = self._get_url(name)
        request_id = str(uuid.uuid4())

        payload: dict[str, Any] = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
        }
        if params is not None:
            payload["params"] = params

        request_headers = {"Content-Type": "application/json"}
        if headers:
            request_headers.update(headers)

        response = await self._http.post(url, json=payload, headers=request_headers)
        response.raise_for_status()

        body = response.json()

        if "error" in body and body["error"]:
            raise JsonRpcClientError(f"JSON-RPC error from {name}: {body['error']}")

        return body

    async def _notify(self, name: str, method: str, params: dict | None = None, headers: dict | None = None) -> None:
        """Send a JSON-RPC notification (no id, no response expected)."""
        url = self._get_url(name)

        payload: dict[str, Any] = {
            "jsonrpc": "2.0",
            "method": method,
        }
        if params is not None:
            payload["params"] = params

        request_headers = {"Content-Type": "application/json"}
        if headers:
            request_headers.update(headers)

        await self._http.post(url, json=payload, headers=request_headers)

    async def close(self) -> None:
        await self._http.aclose()


class JsonRpcClientError(Exception):
    pass
