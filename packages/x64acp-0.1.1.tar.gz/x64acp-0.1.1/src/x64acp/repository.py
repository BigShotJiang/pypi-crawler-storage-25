from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from x64acp.protocol.models import (
    EventType,
    Run,
    TenantScope,
    Thread,
    ThreadEvent,
    UserIdentity,
    WireS2C_ContentPart,
)

__all__ = ["Repository"]

if TYPE_CHECKING:
    from x64acp.persistence.base import EventOrder, Persistence


def _generate_id() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.now(UTC)


class Repository:
    """Unified CRUD interface for threads, events, runs, and settings."""

    def __init__(self, persistence: Persistence) -> None:
        self._persistence = persistence

    async def list_threads(
        self,
        filter: dict[str, str] | None = None,
        order: dict[str, str] | None = None,
        limit: int = 50,
    ) -> list[Thread]:
        f = filter or {}
        return await self._persistence.list_threads(
            assistant_id=f.get("assistant_id", ""),
            user_id=f.get("user_id"),
            cursor=None,
            limit=limit,
            scope=f.get("scope", "member"),
        )

    async def get_thread(self, thread_id: str, assistant_id: str) -> Thread | None:
        return await self._persistence.get_thread(thread_id, assistant_id)

    async def create_thread(
        self,
        assistant_id: str,
        user: UserIdentity | None = None,
        tenant: TenantScope | None = None,
        title: str | None = None,
    ) -> Thread:
        now = _now()
        participant: dict = {}
        if user:
            participant["user"] = user.model_dump()
        if tenant:
            participant["tenant"] = tenant.model_dump()
        thread = Thread(
            id=_generate_id(),
            assistant_id=assistant_id,
            owner_user=user,
            owner_tenant=tenant,
            participants=[participant] if participant else [],
            title=title,
            created_at=now,
            updated_at=now,
            last_event_at=now,
        )
        await self._persistence.create_thread(thread)
        return thread

    async def update_thread(self, thread_id: str, assistant_id: str, **updates: Any) -> Thread | None:
        thread = await self._persistence.get_thread(thread_id, assistant_id)
        if not thread:
            return None
        if "title" in updates:
            thread.title = updates["title"]
        thread.updated_at = _now()
        await self._persistence.update_thread(thread, assistant_id)
        return thread

    async def remove_thread(self, thread_id: str, assistant_id: str) -> None:
        await self._persistence.delete_thread(thread_id, assistant_id)

    async def list_events(
        self,
        assistant_id: str,
        filter: dict[str, str] | None = None,
        order: dict[str, str] | None = None,
        limit: int = 50,
    ) -> list[ThreadEvent]:
        f = filter or {}
        thread_id = f.get("thread_id", "")
        if not thread_id:
            raise ValueError("filter['thread_id'] is required for list_events")

        event_order: EventOrder = "desc"
        if order and order.get("direction") == "asc":
            event_order = "asc"

        event_filters: dict[str, str] = {}
        for key in ("type", "actor", "run_id"):
            if key in f:
                event_filters[key] = f[key]

        return await self._persistence.get_events(
            thread_id,
            assistant_id,
            limit=limit,
            order=event_order,
            filters=event_filters or None,
        )

    async def get_event(self, event_id: str, assistant_id: str) -> ThreadEvent | None:
        return await self._persistence.get_event(event_id, assistant_id)

    async def create_event(
        self,
        thread_id: str,
        type: EventType,
        actor: str,
        content: list[WireS2C_ContentPart] | None = None,
        data: dict | None = None,
        user: UserIdentity | None = None,
        tenant: TenantScope | None = None,
        display_name: str | None = None,
        run_id: str | None = None,
        role: str = "user",
    ) -> ThreadEvent:
        event = ThreadEvent(
            id=_generate_id(),
            thread_id=thread_id,
            run_id=run_id,
            type=type,
            role=role,
            actor=actor,
            display_name=display_name,
            user=user,
            tenant=tenant,
            content=content,
            data=data,
            created_at=_now(),
        )
        await self._persistence.create_event(event)
        return event

    async def remove_event(self, event_id: str, assistant_id: str) -> None:
        await self._persistence.delete_event(event_id, assistant_id)

    async def list_runs(
        self,
        assistant_id: str,
        filter: dict[str, str] | None = None,
        limit: int = 50,
    ) -> list[Run]:
        f = filter or {}
        return await self._persistence.list_runs(
            assistant_id=assistant_id,
            thread_id=f.get("thread_id"),
            status=f.get("status"),
            limit=limit,
        )

    async def get_run(self, run_id: str, assistant_id: str) -> Run | None:
        return await self._persistence.get_run(run_id, assistant_id)

    async def get_settings(self, assistant_id: str) -> dict:
        return await self._persistence.get_settings(assistant_id)

    async def update_settings(self, assistant_id: str, values: dict) -> None:
        await self._persistence.set_settings(assistant_id, values)
