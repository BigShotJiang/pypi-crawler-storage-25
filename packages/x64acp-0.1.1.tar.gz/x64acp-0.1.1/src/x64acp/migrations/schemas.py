__all__ = ["get_migration_sql"]


def get_migration_sql(table_prefix: str = "assistant_") -> str:
    threads_table = f"{table_prefix}threads"
    events_table = f"{table_prefix}events"
    runs_table = f"{table_prefix}runs"
    settings_table = f"{table_prefix}settings"
    analytics_table = f"{table_prefix}analytics"

    return f"""
        CREATE TABLE IF NOT EXISTS {threads_table} (
            id TEXT PRIMARY KEY,
            assistant_id TEXT NOT NULL,
            owner_user JSONB,
            owner_tenant JSONB,
            participants JSONB NOT NULL DEFAULT '[]',
            title TEXT,
            metadata JSONB DEFAULT NULL,
            external BOOLEAN NOT NULL DEFAULT FALSE,
            created_at TIMESTAMPTZ NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL,
            last_event_at TIMESTAMPTZ NOT NULL
        );

        CREATE TABLE IF NOT EXISTS {events_table} (
            id TEXT PRIMARY KEY,
            thread_id TEXT NOT NULL REFERENCES {threads_table}(id),
            run_id TEXT,
            type TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'system',
            actor TEXT NOT NULL DEFAULT 'system',
            display_name TEXT,
            "user" JSONB,
            assistant JSONB,
            system JSONB,
            tenant JSONB,
            content JSONB,
            data JSONB,
            assistant_id TEXT,
            command TEXT,
            client_event_id TEXT,
            created_at TIMESTAMPTZ NOT NULL
        );

        CREATE TABLE IF NOT EXISTS {runs_table} (
            id TEXT PRIMARY KEY,
            thread_id TEXT NOT NULL REFERENCES {threads_table}(id),
            assistant_id TEXT NOT NULL,
            blueprint_id TEXT,
            status TEXT NOT NULL,
            started_at TIMESTAMPTZ NOT NULL,
            ended_at TIMESTAMPTZ,
            error TEXT
        );

        CREATE TABLE IF NOT EXISTS {settings_table} (
            assistant_id TEXT NOT NULL,
            scope TEXT NOT NULL DEFAULT '',
            scope_id TEXT NOT NULL DEFAULT '',
            values JSONB NOT NULL DEFAULT '{{}}',
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW(),
            PRIMARY KEY (assistant_id, scope, scope_id)
        );

        -- Idempotent migration: add scope columns for existing DBs
        DO $$ BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_name = '{settings_table}' AND column_name = 'scope'
            ) THEN
                ALTER TABLE {settings_table} ADD COLUMN scope TEXT NOT NULL DEFAULT '';
                ALTER TABLE {settings_table} ADD COLUMN scope_id TEXT NOT NULL DEFAULT '';
                ALTER TABLE {settings_table} DROP CONSTRAINT IF EXISTS {settings_table}_pkey;
                ALTER TABLE {settings_table} ADD PRIMARY KEY (assistant_id, scope, scope_id);
            END IF;
        END $$;

        -- Add assistant_id to runs if not exists (idempotent)
        DO $$ BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_name = '{runs_table}' AND column_name = 'assistant_id'
            ) THEN
                ALTER TABLE {runs_table} ADD COLUMN assistant_id TEXT;
            END IF;
        END $$;

        CREATE INDEX IF NOT EXISTS idx_{table_prefix}threads_assistant_id
            ON {threads_table}(assistant_id);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}threads_owner_tenant
            ON {threads_table} USING GIN (owner_tenant jsonb_path_ops);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}threads_owner_user
            ON {threads_table} USING GIN (owner_user jsonb_path_ops);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}threads_participants
            ON {threads_table} USING GIN (participants jsonb_path_ops);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}events_thread_id
            ON {events_table}(thread_id);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}events_user
            ON {events_table} USING GIN ("user" jsonb_path_ops);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}threads_assistant_last_event
            ON {threads_table}(assistant_id, last_event_at DESC);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}events_thread_created
            ON {events_table}(thread_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}runs_thread_id
            ON {runs_table}(thread_id);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}runs_assistant_id
            ON {runs_table}(assistant_id);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}settings_assistant
            ON {settings_table}(assistant_id);

        CREATE TABLE IF NOT EXISTS {analytics_table} (
            id TEXT PRIMARY KEY,
            event TEXT NOT NULL,
            timestamp TIMESTAMPTZ NOT NULL,
            assistant_id TEXT NOT NULL,
            thread_id TEXT,
            user_id TEXT,
            run_id TEXT,
            event_id TEXT,
            data JSONB,
            created_at TIMESTAMPTZ NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}analytics_assistant_id
            ON {analytics_table}(assistant_id);
        CREATE INDEX IF NOT EXISTS idx_{table_prefix}analytics_timestamp
            ON {analytics_table}(timestamp);
    """
