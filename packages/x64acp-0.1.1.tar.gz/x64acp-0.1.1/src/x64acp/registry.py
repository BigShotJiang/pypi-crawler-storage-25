from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Protocol

__all__ = ["ConnectionRegistry"]

if TYPE_CHECKING:
    pass


class WebSocketProtocol(Protocol):
    async def send_text(self, data: str) -> None: ...
    async def receive_text(self) -> str: ...


class ConnectionRegistry:
    def __init__(self) -> None:
        self._connections: dict[str, set[WebSocketProtocol]] = {}
        self._lock = asyncio.Lock()

    async def register(self, assistant_id: str, ws: WebSocketProtocol) -> None:
        async with self._lock:
            if assistant_id not in self._connections:
                self._connections[assistant_id] = set()
            self._connections[assistant_id].add(ws)

    async def unregister(self, assistant_id: str, ws: WebSocketProtocol) -> None:
        async with self._lock:
            if assistant_id in self._connections:
                self._connections[assistant_id].discard(ws)
                if not self._connections[assistant_id]:
                    del self._connections[assistant_id]

    def get_connections(self, assistant_id: str) -> set[WebSocketProtocol]:
        return self._connections.get(assistant_id, set()).copy()

    def get_connection_count(self, assistant_id: str) -> int:
        return len(self._connections.get(assistant_id, set()))

    async def broadcast(
        self,
        assistant_id: str,
        message: str,
    ) -> int:
        connections = self.get_connections(assistant_id)
        if not connections:
            return 0

        results = await asyncio.gather(
            *[self._safe_send(ws, message) for ws in connections],
            return_exceptions=True,
        )
        return sum(1 for r in results if r is True)

    async def broadcast_except(
        self,
        assistant_id: str,
        exclude: WebSocketProtocol,
        message: str,
    ) -> int:

        connections = self.get_connections(assistant_id)
        connections.discard(exclude)
        if not connections:
            return 0

        results = await asyncio.gather(
            *[self._safe_send(ws, message) for ws in connections],
            return_exceptions=True,
        )
        return sum(1 for r in results if r is True)

    async def _safe_send(self, ws: WebSocketProtocol, message: str) -> bool:
        try:
            await ws.send_text(message)
            return True
        except Exception:
            return False
