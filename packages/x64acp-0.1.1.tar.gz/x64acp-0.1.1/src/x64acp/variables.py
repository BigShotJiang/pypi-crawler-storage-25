from __future__ import annotations

import os
from dataclasses import dataclass, field

__all__ = ["Variables"]


def _env(key: str, default: str | None = None, required: bool = False) -> str:
    value = os.environ.get(key, default)
    if required and value is None:
        raise RuntimeError(f"Missing required environment variable: {key}. Set it in your environment or .env file.")
    return value  # type: ignore[return-value]


@dataclass(frozen=True)
class Variables:
    analytics_webhook_url: str = field(
        default_factory=lambda: _env("X64ACP_ANALYTICS_WEBHOOK_URL", "https://api.x64acp.ai/api/webhooks/analytics")
    )
    analytics_batch_size: int = field(default_factory=lambda: int(_env("X64ACP_ANALYTICS_BATCH_SIZE", "10")))
    analytics_flush_interval: float = field(
        default_factory=lambda: float(_env("X64ACP_ANALYTICS_FLUSH_INTERVAL", "5.0"))
    )

    upload_max_size: int = 25 * 1024 * 1024
    upload_ttl: int = 300
    upload_prune_interval: int = 60

    filterable_fields: frozenset[str] = field(default_factory=lambda: frozenset({"type", "role", "actor", "run_id"}))


variables = Variables()
