from __future__ import annotations

import logging
import uuid
from typing import Any

from x64acp.analytics.agent_analytics import AssistantAnalytics
from x64acp.analytics.collector import AnalyticsCollector
from x64acp.broadcast import BroadcastManager
from x64acp.config import AssistantServerConfig
from x64acp.dispatch import DispatchStream
from x64acp.handlers.memory import AssistantMemory
from x64acp.handlers.pipeline import AssistantHandlerContext, AssistantHandlerPipeline
from x64acp.handlers.router import AssistantHandler, Router, WebSocketProtocol
from x64acp.persistence.base import Persistence
from x64acp.persistence.postgres import PostgresPersistence
from x64acp.persistence.upload import UploadEntry, UploadStore
from x64acp.protocol.frames import (
    EventAppendPayload,
    RunUpsertPayload,
    S2C_EventAppend,
    S2C_RunUpsert,
    S2C_ThreadUpsert,
    ServerToClient,
    ThreadUpsertPayload,
)
from x64acp.protocol.models import TenantScope, UserIdentity, WireC2S_ContentPart
from x64acp.protocol.parser import parse_frame, serialize_frame
from x64acp.registry import ConnectionRegistry
from x64acp.repository import Repository
from x64acp.settings.agent_settings import AssistantSettings
from x64acp.settings.broadcaster import SettingsBroadcaster
from x64acp.variables import variables as sdk_variables

__all__ = ["AssistantServer"]

logger = logging.getLogger(__name__)


class AssistantServer:
    def __init__(self, config: AssistantServerConfig):
        self._config = config
        self._persistence: Persistence | None = None
        self._initialized = False

        self._registry = ConnectionRegistry()
        self._subscriptions: dict[str, set[str]] = {}

        self._analytics_subscriptions: dict[str, set[str]] = {}
        self._settings_subscriptions: dict[str, set[str]] = {}

        self._broadcast: BroadcastManager | None = None

        self._upload_store: UploadStore | None = None
        self._analytics_collector: AnalyticsCollector | None = None
        self._settings_broadcaster: SettingsBroadcaster | None = None

    @property
    def registry(self) -> ConnectionRegistry:
        return self._registry

    @property
    def persistence(self) -> Persistence:
        if not self._persistence:
            raise RuntimeError("Server not initialized. Call handle() first or ensure_initialized().")
        return self._persistence

    @property
    def broadcast(self) -> BroadcastManager:
        if not self._broadcast:
            raise RuntimeError("Server not initialized. Call handle() first or ensure_initialized().")
        return self._broadcast

    @property
    def upload_store(self) -> UploadStore | None:
        return self._upload_store

    async def upload(self, data: bytes, filename: str, mime_type: str) -> str:
        """Stage a file for a future WebSocket event.create. Returns a reference ID."""
        await self._ensure_initialized()
        assert self._upload_store is not None
        return self._upload_store.store(data, filename, mime_type)

    async def consume_upload(self, ref_id: str) -> UploadEntry | None:
        """Retrieve and remove a staged upload by ref_id. Returns None if unknown."""
        await self._ensure_initialized()
        assert self._upload_store is not None
        return self._upload_store.consume(ref_id)

    async def _ensure_initialized(self) -> Persistence:
        if self._persistence and self._initialized:
            return self._persistence

        persistence: Persistence
        if self._config.database_type == "cosmos":
            from x64acp.persistence.cosmos import CosmosPersistence

            persistence = CosmosPersistence(  # type: ignore[assignment]
                endpoint=self._config.database_host,
                key=self._config.database_key,
                database=self._config.database_name,
                table_prefix=self._config.database_table_prefix,
            )
        else:
            persistence = PostgresPersistence(
                host=self._config.database_host,
                port=self._config.database_port,
                user=self._config.database_user,
                database=self._config.database_name,
                password=self._config.database_password,
                ssl=self._config.database_ssl,
                table_prefix=self._config.database_table_prefix,
            )

        self._persistence = persistence

        await persistence.connect()

        if self._config.database_auto_migrate:
            await persistence.migrate()

        self._broadcast = BroadcastManager(
            registry=self._registry,
            persistence=persistence,
            subscriptions=self._subscriptions,
        )

        if self._config.analytics_enabled:
            batch_size = self._config.analytics_batch_size or sdk_variables.analytics_batch_size
            flush_interval = self._config.analytics_flush_interval or sdk_variables.analytics_flush_interval

            webhook_url = self._config.analytics_webhook_url or sdk_variables.analytics_webhook_url
            self._analytics_collector = AnalyticsCollector(
                webhook_url=webhook_url,
                registry=self._registry,
                subscriptions=self._analytics_subscriptions,
                batch_size=batch_size,
                flush_interval=flush_interval,
                persistence=persistence,
            )
            await self._analytics_collector.start()

        self._settings_broadcaster = SettingsBroadcaster(
            registry=self._registry,
            subscriptions=self._settings_subscriptions,
        )

        self._upload_store = UploadStore(
            max_size=self._config.upload_max_size_bytes,
            ttl=self._config.upload_ttl_seconds,
        )
        await self._upload_store.start()

        self._initialized = True
        return persistence

    async def ensure_initialized(self) -> None:
        await self._ensure_initialized()

    async def migrate(self) -> None:
        persistence = await self._ensure_initialized()
        await persistence.migrate()

    async def handle(self, websocket: WebSocketProtocol, handler: AssistantHandler) -> None:
        persistence = await self._ensure_initialized()
        router = Router(
            persistence=persistence,
            handler=handler,
            registry=self._registry,
            subscriptions=self._subscriptions,
            analytics_collector=self._analytics_collector,
            settings_broadcaster=self._settings_broadcaster,
            settings_schema=self._config.settings_schema,
            assistant_name=self._config.assistant_name,
            analytics_subscriptions=self._analytics_subscriptions,
            settings_subscriptions=self._settings_subscriptions,
            upload_store=self._upload_store,
            skills=[
                {"command": s.command, "description": s.description}
                for s in self._config.skills
                if not s.assistant_only
            ]
            if self._config.skills
            else None,
            knowledge=self._config.knowledge,
            authentication=self._config.authentication,
            authorization=self._config.authorization,
        )

        try:
            while True:
                data = await websocket.receive_text()
                logger.debug("[assistant] C2S raw: %s", data[:500])
                frame = parse_frame(data)
                logger.debug("[assistant] C2S parsed: type=%s", type(frame).__name__)
                await router.route(websocket, frame)
        except Exception as e:
            error_name = type(e).__name__
            if error_name not in ("WebSocketDisconnect", "ConnectionClosedOK", "ConnectionClosedError"):
                logger.warning("[assistant] websocket connection error: %s: %s", error_name, e)
        finally:
            await router.cleanup()

    async def dispatch(
        self,
        handler: AssistantHandler,
        assistant_id: str,
        message: str,
        user: UserIdentity | None = None,
        tenant: TenantScope | None = None,
        thread_id: str | None = None,
        thread_title: str | None = None,
        content: list[WireC2S_ContentPart | dict[str, Any]] | None = None,
    ) -> DispatchStream:
        persistence = await self._ensure_initialized()

        pipeline = AssistantHandlerPipeline(
            persistence=persistence,
            broadcast_callback=self._broadcast_dict_to_assistant,
            analytics_collector=self._analytics_collector,
            settings_broadcaster=self._settings_broadcaster,
            settings_schema=self._config.settings_schema,
            assistant_name=self._config.assistant_name,
            upload_store=self._upload_store,
        )

        context = AssistantHandlerContext(
            handler=handler,
            assistant_id=assistant_id,
            message=message,
            user=user,
            tenant=tenant,
            thread_id=thread_id,
            thread_title=thread_title,
            content=content,
        )

        result = await pipeline.setup(context)

        if not result.is_new_thread and user and (user.id or getattr(user, "email", None)):
            participant = pipeline._build_participant(user, tenant)
            await persistence.upsert_thread_participant(result.thread.id, assistant_id, participant)

        return DispatchStream(pipeline=pipeline, context=context, result=result)

    async def repository(self) -> Repository:
        persistence = await self._ensure_initialized()
        return Repository(persistence)

    async def memory(self, thread_id: str, assistant_id: str) -> AssistantMemory:
        persistence = await self._ensure_initialized()
        return AssistantMemory(thread_id=thread_id, assistant_id=assistant_id, persistence=persistence)

    async def settings(self, assistant_id: str) -> AssistantSettings:
        persistence = await self._ensure_initialized()
        if self._config.settings_schema and self._settings_broadcaster:
            return AssistantSettings(
                assistant_id=assistant_id,
                schema=self._config.settings_schema,
                persistence=persistence,
                broadcaster=self._settings_broadcaster,
            )

        from x64acp.settings.models import SettingsSchema

        class _NoopBroadcaster:
            async def broadcast_snapshot(self, **kwargs) -> None:
                pass

            async def broadcast_patch(self, **kwargs) -> None:
                pass

        class _NoopPersistence:
            async def get_settings(self, assistant_id: str, scope: str = "", scope_id: str = "") -> dict:
                return {}

            async def update_setting(
                self, assistant_id: str, field_id: str, value: Any, scope: str = "", scope_id: str = ""
            ) -> None:
                pass

            async def set_settings(self, assistant_id: str, values: dict, scope: str = "", scope_id: str = "") -> None:
                pass

        return AssistantSettings(
            assistant_id=assistant_id,
            schema=SettingsSchema(fields=[]),
            persistence=_NoopPersistence(),  # type: ignore
            broadcaster=_NoopBroadcaster(),  # type: ignore
        )

    async def analytics(
        self,
        assistant_id: str,
        thread_id: str | None = None,
        user_id: str | None = None,
        run_id: str | None = None,
    ) -> AssistantAnalytics:
        await self._ensure_initialized()
        if self._analytics_collector:
            return AssistantAnalytics(
                assistant_id=assistant_id,
                thread_id=thread_id or "",
                user_id=user_id,
                run_id=run_id,
                collector=self._analytics_collector,
            )

        class _NoopCollector:
            async def track(self, **kwargs) -> None:
                pass

            async def feedback(self, **kwargs) -> None:
                pass

        return AssistantAnalytics(
            assistant_id=assistant_id,
            thread_id=thread_id or "",
            user_id=user_id,
            run_id=run_id,
            collector=_NoopCollector(),  # type: ignore
        )

    async def _broadcast_dict_to_assistant(self, assistant_id: str, payload: dict[str, Any]) -> None:
        """Convert dict payload to S2C frame and broadcast via registry."""
        payload_type = payload.get("type")

        if payload_type == "thread.upsert":
            frame: ServerToClient = S2C_ThreadUpsert(
                id=str(uuid.uuid4()),
                payload=ThreadUpsertPayload(thread=payload["thread"]),
            )
        elif payload_type == "event.append":
            frame = S2C_EventAppend(
                id=str(uuid.uuid4()),
                payload=EventAppendPayload(
                    thread_id=payload["thread_id"],
                    events=payload["events"],
                ),
            )
        elif payload_type == "run.upsert":
            frame = S2C_RunUpsert(
                id=str(uuid.uuid4()),
                payload=RunUpsertPayload(run=payload["run"]),
            )
        else:
            return

        message = serialize_frame(frame)
        await self._registry.broadcast(assistant_id, message)

    async def close(self) -> None:
        if self._upload_store:
            await self._upload_store.stop()
            self._upload_store = None

        if self._analytics_collector:
            await self._analytics_collector.stop()
            self._analytics_collector = None

        if self._persistence:
            await self._persistence.disconnect()
            self._persistence = None

        self._initialized = False
