from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel

__all__ = ["AnalyticsEvent", "AnalyticsEventPayload", "AnalyticsBatch"]


class AnalyticsEvent(StrEnum):
    """Built-in analytics event types."""

    THREAD_CREATED = "thread.created"
    MESSAGE_C2S = "message.c2s"
    MESSAGE_S2C = "message.s2c"
    TOOL_CALLED = "tool.called"
    ERROR_OCCURRED = "error.occurred"

    FEEDBACK_LIKE = "feedback.like"
    FEEDBACK_DISLIKE = "feedback.dislike"


class AnalyticsEventPayload(BaseModel):
    """Payload for an analytics event."""

    event: str
    timestamp: datetime
    assistant_id: str
    thread_id: str | None = None
    user_id: str | None = None
    run_id: str | None = None
    event_id: str | None = None
    data: dict[str, Any] | None = None
    created_at: datetime


class AnalyticsBatch(BaseModel):
    """Batch of analytics events for webhook delivery."""

    batch_id: str
    assistant_id: str
    events: list[AnalyticsEventPayload]
    sent_at: datetime
