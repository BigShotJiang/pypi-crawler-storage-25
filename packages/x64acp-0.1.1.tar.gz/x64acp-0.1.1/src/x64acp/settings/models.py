from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, model_validator

__all__ = [
    "SettingsFieldType",
    "SettingsField",
    "SettingsFieldGroup",
    "SettingsSelectOption",
    "SettingsScope",
    "SettingsSchema",
]


class SettingsFieldType(StrEnum):
    TEXT = "text"
    NUMBER = "number"
    SELECT = "select"
    CHECKBOX = "checkbox"
    TEXTAREA = "textarea"
    PASSWORD = "password"
    EMAIL = "email"
    DATE = "date"
    IMAGE = "image"
    FILE = "file"
    FILE_MULTI = "file_multi"


class SettingsSelectOption(BaseModel):
    value: str
    label: str


class SettingsField(BaseModel):
    id: str
    type: SettingsFieldType
    label: str
    required: bool = False
    readonly: bool = False
    visibility: Literal["internal", "admin", "user"] = "user"
    default: Any = None
    value: Any = None

    placeholder: str | None = None
    options: list[SettingsSelectOption] | None = None
    min: int | float | None = None
    max: int | float | None = None
    rows: int | None = None
    src: str | None = None
    width: int | None = None
    height: int | None = None
    upload_url: str | None = None
    accept: str | None = None

    @model_validator(mode="after")
    def _validate_defaults(self) -> "SettingsField":
        if self.required and self.default is None:
            raise ValueError(f"Required field '{self.id}' must have a default value")
        if self.value is None and self.default is not None:
            self.value = self.default
        return self


class SettingsFieldGroup(BaseModel):
    id: str
    label: str
    fields: list[SettingsField]
    collapsible: Literal["open", "closed"] | None = None
    visibility: Literal["internal", "admin", "user"] = "user"


class SettingsScope(BaseModel):
    name: str
    visibility: str = "admin"
    fields: list[SettingsField | SettingsFieldGroup]


def _collect_all_fields(items: list["SettingsField | SettingsFieldGroup"]) -> list[SettingsField]:
    result: list[SettingsField] = []
    for item in items:
        if isinstance(item, SettingsFieldGroup):
            result.extend(item.fields)
        else:
            result.append(item)
    return result


def _find_field_in_items(items: list["SettingsField | SettingsFieldGroup"], field_id: str) -> SettingsField | None:
    for item in items:
        if isinstance(item, SettingsFieldGroup):
            for field in item.fields:
                if field.id == field_id:
                    return field
        elif item.id == field_id:
            return item
    return None


class SettingsSchema(BaseModel):
    version: str = "1.0"
    fields: list[SettingsField | SettingsFieldGroup] = []
    scopes: list[SettingsScope] = []

    @model_validator(mode="after")
    def _synthesize_scopes(self) -> "SettingsSchema":
        if self.fields and not self.scopes:
            self.scopes = [SettingsScope(name="assistant", visibility="admin", fields=self.fields)]
        return self

    @model_validator(mode="after")
    def validate_unique_ids(self) -> "SettingsSchema":
        # Validate per-scope uniqueness
        for scope in self.scopes:
            all_fields = _collect_all_fields(scope.fields)
            ids = [f.id for f in all_fields]
            if len(ids) != len(set(ids)):
                raise ValueError(f"Field IDs must be unique within scope '{scope.name}'")
        # Also validate top-level fields if present
        if self.fields:
            all_fields = _collect_all_fields(self.fields)
            ids = [f.id for f in all_fields]
            if len(ids) != len(set(ids)):
                raise ValueError("Field IDs must be unique")
        return self

    def get_scope(self, name: str) -> SettingsScope | None:
        for scope in self.scopes:
            if scope.name == name:
                return scope
        return None

    def get_field(self, field_id: str, scope_name: str | None = None) -> SettingsField | None:
        if scope_name is not None:
            scope = self.get_scope(scope_name)
            if scope is None:
                return None
            return _find_field_in_items(scope.fields, field_id)
        # Search top-level fields first, then all scopes
        result = _find_field_in_items(self.fields, field_id)
        if result is not None:
            return result
        for scope in self.scopes:
            result = _find_field_in_items(scope.fields, field_id)
            if result is not None:
                return result
        return None

    def get_visible_fields(self, audience: str) -> list[SettingsField]:
        """Return all fields visible to the given audience level.
        Visibility hierarchy: internal > admin > user.
        - "user" sees only visibility="user" fields
        - "admin" sees "user" + "admin" fields
        - "internal" sees all fields
        """
        visibility_levels = {"user": 0, "admin": 1, "internal": 2}
        audience_level = visibility_levels.get(audience, 0)
        all_fields = _collect_all_fields(self.fields)
        return [f for f in all_fields if visibility_levels.get(f.visibility, 0) <= audience_level]

    def get_defaults(self, scope_name: str | None = None) -> dict[str, Any]:
        if scope_name is not None:
            scope = self.get_scope(scope_name)
            if scope is None:
                return {}
            return {f.id: f.default for f in _collect_all_fields(scope.fields)}
        return {f.id: f.default for f in _collect_all_fields(self.fields)}
