from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..persistence.base import Persistence
    from .broadcaster import SettingsBroadcaster
    from .models import SettingsSchema

__all__ = ["AssistantSettings"]


class AssistantSettings:
    def __init__(
        self,
        assistant_id: str,
        schema: SettingsSchema,
        persistence: Persistence,
        broadcaster: SettingsBroadcaster,
    ) -> None:
        self._assistant_id = assistant_id
        self._schema = schema
        self._persistence = persistence
        self._broadcaster = broadcaster

    async def get(self, field_id: str, scope: str = "", scope_id: str = "") -> Any:
        field = self._schema.get_field(field_id, scope_name=scope if scope else None)
        if not field:
            raise KeyError(f"Unknown field: {field_id}")

        values = await self._persistence.get_settings(self._assistant_id, scope=scope, scope_id=scope_id)
        return values.get(field_id, field.value)

    async def get_all(self, *, exclude: list[str] | None = None, scope: str = "", scope_id: str = "") -> dict[str, Any]:
        defaults = self._schema.get_defaults(scope_name=scope if scope else None)
        stored = await self._persistence.get_settings(self._assistant_id, scope=scope, scope_id=scope_id)
        merged = {**defaults, **stored}
        if exclude:
            for key in exclude:
                merged.pop(key, None)
        return merged

    async def set(self, field_id: str, value: Any, scope: str = "", scope_id: str = "") -> None:
        self._validate_field(field_id, value, scope=scope)
        await self._persistence.update_setting(self._assistant_id, field_id, value, scope=scope, scope_id=scope_id)
        await self._broadcaster.broadcast_patch(self._assistant_id, field_id, value, scope=scope, scope_id=scope_id)

    def _validate_field(self, field_id: str, value: Any, scope: str = "") -> None:
        field = self._schema.get_field(field_id, scope_name=scope if scope else None)
        if not field:
            raise KeyError(f"Unknown field: {field_id}")
        if field.readonly:
            raise ValueError(f"Field '{field_id}' is readonly")
        if field.options and value is not None:
            allowed = {opt.value for opt in field.options}
            if str(value) not in allowed:
                raise ValueError(f"Field '{field_id}' value must be one of: {', '.join(sorted(allowed))}")

    async def resolve(self, field_id: str, scopes: list[tuple[str, str]] | None = None) -> Any:
        """Iterate scopes list, return first non-None stored value, fall back to schema default."""
        if scopes:
            for scope_name, sid in scopes:
                values = await self._persistence.get_settings(self._assistant_id, scope=scope_name, scope_id=sid)
                if field_id in values and values[field_id] is not None:
                    return values[field_id]
        # Fall back to schema default
        field = self._schema.get_field(field_id)
        return field.value if field else None
