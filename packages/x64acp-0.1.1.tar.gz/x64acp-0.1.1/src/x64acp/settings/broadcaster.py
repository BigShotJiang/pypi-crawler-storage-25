from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from uuid import uuid4

if TYPE_CHECKING:
    from x64acp.registry import ConnectionRegistry, WebSocketProtocol

    from .models import SettingsSchema

__all__ = ["SettingsBroadcaster"]

logger = logging.getLogger(__name__)


class SettingsBroadcaster:
    def __init__(
        self,
        registry: ConnectionRegistry,
        subscriptions: dict[str, set[str]],
    ) -> None:
        self._registry = registry
        self._subscriptions = subscriptions

    async def broadcast_snapshot_to_ws(
        self,
        assistant_id: str,
        ws: WebSocketProtocol,
        schema: SettingsSchema,
        values: dict[str, Any],
        scope: str = "",
        scope_id: str = "",
    ) -> None:
        from x64acp.protocol.frames import S2C_SettingsSnapshot, SettingsSnapshotPayload

        from .models import SettingsField, SettingsFieldGroup

        scope_obj = schema.get_scope(scope) if scope else None
        scope_items: list[SettingsField | SettingsFieldGroup] = scope_obj.fields if scope_obj else schema.fields

        def _inject_values(field: SettingsField) -> SettingsField:
            if field.id in values:
                return field.model_copy(update={"value": values[field.id]})
            return field

        items_with_values: list[SettingsField | SettingsFieldGroup] = []
        for item in scope_items:
            if isinstance(item, SettingsFieldGroup):
                updated_fields = [_inject_values(f) for f in item.fields]
                items_with_values.append(item.model_copy(update={"fields": updated_fields}))
            else:
                items_with_values.append(_inject_values(item))

        # Filter out internal fields
        def _filter_visible(
            items: list[SettingsField | SettingsFieldGroup],
        ) -> list[SettingsField | SettingsFieldGroup]:
            filtered: list[SettingsField | SettingsFieldGroup] = []
            for item in items:
                if isinstance(item, SettingsFieldGroup):
                    if item.visibility == "internal":
                        continue
                    visible_fields = [f for f in item.fields if f.visibility != "internal"]
                    if visible_fields:
                        filtered.append(item.model_copy(update={"fields": visible_fields}))
                elif item.visibility != "internal":
                    filtered.append(item)
            return filtered

        items_with_values = _filter_visible(items_with_values)

        message = S2C_SettingsSnapshot(
            id=str(uuid4()),
            payload=SettingsSnapshotPayload(
                assistant_id=assistant_id,
                fields=items_with_values,
                updated_at=datetime.now(UTC),
                scope=scope,
                scope_id=scope_id,
            ),
        )

        try:
            await ws.send_text(message.model_dump_json())
        except Exception:
            logger.warning("[assistant] failed to send settings snapshot")

    async def broadcast_patch(
        self,
        assistant_id: str,
        field_id: str,
        value: Any,
        exclude_ws: WebSocketProtocol | None = None,
        scope: str = "",
        scope_id: str = "",
    ) -> None:
        from x64acp.protocol.frames import S2C_SettingsPatch, SettingsPatchBroadcastPayload

        sub_key = f"{assistant_id}:{scope}:{scope_id}"
        subscriber_ws_ids = self._subscriptions.get(sub_key, set())
        if not subscriber_ws_ids:
            # Fall back to legacy key for backward compatibility
            subscriber_ws_ids = self._subscriptions.get(assistant_id, set())
        if not subscriber_ws_ids:
            return

        message = S2C_SettingsPatch(
            id=str(uuid4()),
            payload=SettingsPatchBroadcastPayload(
                assistant_id=assistant_id,
                field_id=field_id,
                value=value,
                updated_at=datetime.now(UTC),
                scope=scope,
                scope_id=scope_id,
            ),
        )
        message_json = message.model_dump_json()

        connections = self._registry.get_connections(assistant_id)
        for ws in connections:
            if ws is not exclude_ws:
                try:
                    await ws.send_text(message_json)
                except Exception:
                    logger.warning("Failed to send settings patch to subscriber")
