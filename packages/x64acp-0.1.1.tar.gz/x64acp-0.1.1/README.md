<img width="200" alt="x64acp-ember" src="https://github.com/user-attachments/assets/da0940dc-7270-4a52-b969-9d5b6d5fa0ea" />

Agent Communication Protocol (ACP) Python SDK

[Documentation](docs/) · [Examples](examples/)

```python
from x64acp import AssistantServer, AssistantServerConfig, AssistantSend, AssistantIncoming

server = AssistantServer(config=AssistantServerConfig(
    database_type="postgres",
    database_host="localhost",
    database_name="myapp",
))

async def my_handler(incoming: AssistantIncoming, send: AssistantSend, memory, analytics, settings, knowledge):
    history = await memory.get_history(limit=20, format="openai")
    yield send.run_start()
    yield send.text("Hello! How can I help?")
    yield send.run_end()

# FastAPI
@app.websocket("/ws")
async def ws(websocket: WebSocket):
    await websocket.accept()
    await server.handle(websocket, my_handler)

# Programmatic (HTTP, jobs, webhooks)
stream = await server.dispatch(my_handler, assistant_id="my-assistant", message="Hi")
async for event in stream:
    print(event)
```

## Installation

```bash
uv add x64acp                    # add to your project

uv sync --all-extras                    # setup with all optional
uv run poe check                        # ruff lint
uv run poe check:fix                    # ruff lint + auto-fix
uv run poe format                       # ruff format
uv run poe format:imports               # sort imports
uv run poe typecheck                    # mypy type checking
uv run poe test                         # pytest
```

Private package — installed as editable dependency:

```toml
# In consumer pyproject.toml:
x64acp = { path = "../packages/x64acp", editable = true }
```

## Persistence

| Backend | Config | Requires |
|---------|--------|----------|
| PostgreSQL | `database_type="postgres"` | `asyncpg` |
| Azure Cosmos DB | `database_type="cosmos"` | `azure-cosmos` |

Auto-migrates on startup (`database_auto_migrate=True`). Both backends implement the same `Persistence` protocol.

## Authentication & Authorization

```python
class MyAuth:
    async def authenticate(self, token: str, user: UserIdentity | None) -> UserIdentity | None:
        ...  # validate JWT, return user or None to reject

class MyAuthz:
    async def authorize(self, user, tenant, action, resource) -> AuthorizationResult | None:
        ...  # check permissions

server = AssistantServer(config=AssistantServerConfig(
    authentication=MyAuth(),
    authorization=MyAuthz(),
    ...
))
```

- `Authentication` — called once per WebSocket connection, validated identity overrides client-sent fields
- `Authorization` — called per-action for fine-grained access control
- Both optional — when `None`, all connections and actions are accepted

## Identity & Scoping

All identity models use `extra="allow"` — attach any fields your application needs.

| Model | Base Fields | Purpose |
|-------|-------------|---------|
| `UserIdentity` | `id` | Who sent the message |
| `AssistantIdentity` | `id`, `name` | Which assistant responded |
| `SystemContext` | `id` | System-level metadata (environment, version) |
| `TenantScope` | *(none)* | Organization/workspace scoping |

Thread scoping uses JSONB containment on `owner_tenant` and `owner_user` — the consumer controls scope granularity by what they put in `tenant` and `user` at connection time.

## Handler API

```python
async def handler(
    incoming: AssistantIncoming,    # message, content, context
    send: AssistantSend,            # yield events back to client
    memory: AssistantMemory,        # conversation history
    analytics: AssistantAnalytics,  # track custom events
    settings: AssistantSettings,    # runtime settings
    knowledge: AssistantKnowledge,  # knowledge source selection
) -> AsyncGenerator[AssistantEvent, None]:
    yield send.text("response")
    yield send.tool_transaction("search", {"q": "test"}, {"results": [...]})
    yield send.analysis("sentiment", {"score": 0.8}, text="Positive sentiment")
```

### Send Methods

| Method | Description |
|--------|-------------|
| `text(text)` | Text message |
| `image(url, mime_type?, alt?)` | Image |
| `document(url, filename, mime_type)` | Document |
| `audio(url, mime_type, duration?)` | Audio |
| `tool_call(name, args, display_name?, id?)` | Tool invocation |
| `tool_result(name, result, args?, display_name?, id?)` | Tool output |
| `tool_transaction(name, args, result, display_name?, id?)` | Combined call + result |
| `run_start(blueprint_id?)` | Start a run |
| `run_end(status?, error?)` | End a run |
| `confirmation(confirmation_id, action_type, blocking, summary, details?)` | Request user confirmation |
| `analysis(kind, metadata, *, text?)` | Structured analysis event |
| `mention(assistant_id, text)` | Cross-assistant mention |
| `skill_invoke(assistant_id, command, args?)` | Invoke skill on another assistant |
| `update_thread(*, title?, metadata?)` | Update thread title/metadata |
| `update_user_event(event_id, content)` | Update existing event content |

### Memory

```python
history = await memory.get_history(limit=20, format="openai")
# Formats: "openai", "anthropic", "google", "cohere", "voyage"

raw_events = await memory.get_history_raw(limit=50, order="asc")
```

### Settings

```python
from x64acp.settings import SettingsSchema, SettingsScope, SettingsField, SettingsFieldType

schema = SettingsSchema(scopes=[
    SettingsScope(name="admin_assistant", visibility="admin", fields=[...]),
    SettingsScope(name="user_thread", visibility="user", fields=[...]),
])

# In handler:
value = await settings.resolve("mode", scopes=[("user_thread", thread_id), ("admin_assistant", "")])
```

Settings stored per `(assistant_id, scope, scope_id)`. Field types: `text`, `number`, `select`, `checkbox`, `textarea`, `password`, `email`, `date`, `image`.

## Server API

| Method | Returns | Description |
|--------|---------|-------------|
| `handle(ws, handler)` | `None` | WebSocket loop (blocks until disconnect) |
| `dispatch(handler, assistant_id, message, **kwargs)` | `DispatchStream` | Programmatic handler execution |
| `repository()` | `Repository` | CRUD for threads/events/runs |
| `broadcast` | `BroadcastManager` | Real-time event broadcasting |
| `memory(thread_id, assistant_id)` | `AssistantMemory` | Conversation history |
| `settings(assistant_id)` | `AssistantSettings` | Runtime settings |
| `analytics(assistant_id, **kwargs)` | `AssistantAnalytics` | Analytics tracking |
| `upload(data, filename, mime_type)` | `str` | Stage file upload (returns `ref_id`) |
| `close()` | `None` | Shutdown and release resources |

## Env Variables

```bash
assistant_DATABASE_HOST=localhost
assistant_DATABASE_PORT=5432
assistant_DATABASE_USER=postgres
assistant_DATABASE_NAME=
assistant_DATABASE_PASSWORD=
assistant_DATABASE_KEY=                 # Cosmos DB only
assistant_DATABASE_SSL=false            # false, true, require, verify-ca, verify-full
```
