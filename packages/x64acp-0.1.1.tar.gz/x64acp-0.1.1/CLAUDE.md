# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

x64acp is a Python SDK for building AI assistant servers. It provides WebSocket-based real-time communication, persistence (PostgreSQL/Cosmos DB), analytics, settings management, A2A (Agent-to-Agent) protocol support, and MCP client integration.

## Commands

```bash
uv sync --all-extras        # Install all dependencies
uv run poe test              # Run tests
uv run poe test:cov          # Tests with coverage
uv run poe check             # Lint (ruff)
uv run poe check:fix         # Auto-fix lint issues
uv run poe format            # Format code
uv run poe format:imports    # Sort imports
uv run poe typecheck         # Type check with mypy
uv run poe pcu               # Check package updates
uv run poe pcu:upgrade       # Upgrade packages
```

Run a single test: `uv run pytest tests/path/to/test.py::test_name -v`

## Architecture

### Core Flow

`AssistantServer` is the entry point. It has two modes of operation:

1. **WebSocket mode** (`server.handle(websocket, handler)`) — Long-lived connection. The `Router` parses incoming frames (`ClientToServer`) and dispatches them. When a user sends a message (`C2S_EventCreate`), the `AssistantHandlerPipeline` orchestrates thread/event/run creation, invokes the user-provided `AssistantHandler`, persists results, and broadcasts `ServerToClient` frames back.

2. **Dispatch mode** (`server.dispatch(handler, ...)`) — Programmatic invocation without WebSocket. Returns a `DispatchStream` (async iterable of `AssistantEvent`) with `thread_id`, `event_id`, and `is_new_thread` available immediately before iteration.

### Assistant Handler Contract

AssistantHandlers are async generators with signature:
```python
async def handler(incoming, send, memory, analytics, settings) -> AsyncGenerator[AssistantEvent, None]:
    yield send.text("response")
```

The five injected parameters (`AssistantIncoming`, `AssistantSend`, `AssistantMemory`, `AssistantAnalytics`, `AssistantSettings`) are constructed by `AssistantHandlerPipeline` per request.

### Protocol Layer (`protocol/`)

- `frames.py` — Pydantic models for all WebSocket frame types (C2S_* and S2C_*), discriminated by `type` field
- `models.py` — Domain models: `Thread`, `ThreadEvent`, `Run`, content parts (internal vs wire C2S/S2C variants)
- `parser.py` — JSON frame parsing/serialization using Pydantic `TypeAdapter`

### Persistence (`persistence/`)

`Persistence` is a Protocol (structural typing) with two implementations: `PostgresPersistence` (asyncpg + SQLAlchemy) and `CosmosPersistence`. Both handle threads, events, runs, settings, and analytics storage. Cosmos is lazily imported only when `database_type="cosmos"`.

### Subsystems

- **`broadcast.py`** — `BroadcastManager` pushes events/thread updates to subscribed WebSocket connections via `ConnectionRegistry`
- **`registry.py`** — `ConnectionRegistry` maps WebSocket connections to assistant instance IDs
- **`analytics/`** — `AnalyticsCollector` batches events and flushes to persistence + optional webhook; `AssistantAnalytics` is the handler-facing API
- **`settings/`** — Schema-driven settings with `SettingsBroadcaster` for real-time sync to subscribed clients
- **`a2a/`** — Agent-to-Agent protocol: `A2AServer` (FastAPI router for JSON-RPC) and `A2AClient`
- **`mcp/`** — `MCPClient` connects to MCP-compliant tool servers over Streamable HTTP
- **`handlers/knowledge.py`** — `AssistantKnowledge` for knowledge source selection by clients

## Code Style

- Python 3.11+, ruff for linting/formatting, line length 120
- Quote style: double quotes
- Ruff rules: E, F, I (isort), UP (pyupgrade)
- `pytest-asyncio` with `asyncio_mode = "auto"` (no need for `@pytest.mark.asyncio`)
- Pydantic v2 for all models; dataclasses for config objects
