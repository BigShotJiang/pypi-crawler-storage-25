"""TruthVouch LlamaIndex node postprocessor.

Verifies each retrieved node's content via the Trust API and filters
nodes below the trust threshold before they reach the LLM synthesizer.
"""

import logging
from typing import List, Optional

from llama_index.core.postprocessor.types import BaseNodePostprocessor
from llama_index.core.schema import NodeWithScore, QueryBundle
from pydantic import ConfigDict

from truthvouch_llamaindex.client import TrustApiClient

logger = logging.getLogger(__name__)


class TruthVouchNodePostprocessor(BaseNodePostprocessor):
    """LlamaIndex node postprocessor that verifies nodes via the Trust API.

    Attaches trust metadata to each node and optionally filters nodes
    below the configured threshold before they are passed to the LLM.

    Args:
        api_key: Trust API key. Defaults to TRUTHVOUCH_API_KEY env var.
        base_url: Trust API base URL.
        threshold: Minimum trust score to keep a node (0.0–1.0).
        mode: Verification mode — "spot_check", "standard", or "full".
        filter_below_threshold: If True, low-trust nodes are removed.

    Example:
        postprocessor = TruthVouchNodePostprocessor(threshold=0.75)
        engine = index.as_query_engine(node_postprocessors=[postprocessor])
    """

    api_key: Optional[str] = None
    base_url: str = "http://localhost:5004/api/v1/trust"
    threshold: float = 0.8
    mode: str = "spot_check"
    filter_below_threshold: bool = True

    # Internal client — not part of Pydantic schema
    _client: Optional[TrustApiClient] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def _get_client(self) -> TrustApiClient:
        if self._client is None:
            self._client = TrustApiClient(api_key=self.api_key, base_url=self.base_url)
        return self._client

    def _verify_node(self, node_with_score: NodeWithScore) -> NodeWithScore:
        """Call Trust API for a single node and attach metadata.

        Args:
            node_with_score: The node to verify.

        Returns:
            The same node with trust metadata added to node.metadata.
        """
        client = self._get_client()
        text = node_with_score.node.get_content()

        try:
            result = client.verify_sync(text, mode=self.mode)
            node_with_score.node.metadata["trust_score"] = result.trust_score
            node_with_score.node.metadata["trust_mode"] = result.mode
            node_with_score.node.metadata["trust_cache_hit"] = result.cache_hit
            node_with_score.node.metadata["trust_verification_id"] = result.id
            node_with_score.node.metadata["trust_claims"] = [
                {
                    "text": c.claim_text,
                    "status": c.status,
                    "confidence": c.confidence_score,
                }
                for c in result.claims
            ]
            logger.debug(
                "TruthVouch postprocessor: node trust_score=%.3f threshold=%.2f",
                result.trust_score,
                self.threshold,
            )
        except Exception as exc:
            logger.warning("TruthVouch postprocessor: verification failed — %s", exc)
            node_with_score.node.metadata["trust_score"] = 0.0
            node_with_score.node.metadata["trust_error"] = str(exc)

        return node_with_score

    def _postprocess_nodes(
        self,
        nodes: List[NodeWithScore],
        query_bundle: Optional[QueryBundle] = None,
    ) -> List[NodeWithScore]:
        """Verify all nodes and filter those below the trust threshold.

        Args:
            nodes: Retrieved nodes to postprocess.
            query_bundle: Optional query context (not used for verification).

        Returns:
            Verified nodes, filtered if filter_below_threshold=True.
        """
        result: List[NodeWithScore] = []
        for node_with_score in nodes:
            verified = self._verify_node(node_with_score)
            score = verified.node.metadata.get("trust_score", 0.0)
            if self.filter_below_threshold and score < self.threshold:
                logger.info(
                    "TruthVouch postprocessor: filtered node (score=%.3f < %.2f)",
                    score,
                    self.threshold,
                )
                continue
            result.append(verified)
        return result
