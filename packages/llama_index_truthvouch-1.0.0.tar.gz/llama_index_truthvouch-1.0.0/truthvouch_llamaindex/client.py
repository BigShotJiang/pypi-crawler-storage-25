"""TruthVouch Trust API client for LlamaIndex integration.

Same interface as the LangChain client — httpx async and sync,
API key from constructor or TRUTHVOUCH_API_KEY env var.
"""

import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import httpx

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "http://localhost:5004/api/v1/trust"
_DEFAULT_TIMEOUT = 30.0


@dataclass
class ClaimResult:
    """Verification result for a single extracted claim."""

    claim_text: str
    status: str  # "verified" | "failed" | "unverifiable"
    confidence_score: float
    source_reference: str
    suggested_correction: str


@dataclass
class TrustVerifyResult:
    """Full response from the Trust API verify endpoint."""

    id: str
    trust_score: float
    claims: List[ClaimResult]
    processing_time_ms: int
    tokens_used: int
    cache_hit: bool
    mode: str
    created_at: str
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TrustVerifyResult":
        """Parse a Trust API JSON response.

        Args:
            data: Raw JSON dict from the Trust API.

        Returns:
            Parsed TrustVerifyResult instance.
        """
        claims = [
            ClaimResult(
                claim_text=c.get("claimText", ""),
                status=c.get("status", "unverifiable"),
                confidence_score=float(c.get("confidenceScore", 0.0)),
                source_reference=c.get("sourceReference", ""),
                suggested_correction=c.get("suggestedCorrection", ""),
            )
            for c in data.get("claims", [])
        ]
        return cls(
            id=data.get("requestId", ""),
            trust_score=float(data.get("trustScore", 0.0)),
            claims=claims,
            processing_time_ms=int(data.get("latencyMs", 0)),
            tokens_used=int(data.get("tokensUsed", 0)),
            cache_hit=int(data.get("cacheHits", 0)) > 0,
            mode=data.get("verificationMode", "spot_check"),
            created_at=data.get("createdAt", ""),
            raw=data,
        )


class TrustApiClient:
    """httpx-based client for the TruthVouch Trust API.

    Supports async and sync usage. The API key is resolved from the
    constructor argument or the TRUTHVOUCH_API_KEY environment variable.

    Args:
        api_key: Trust API key. Defaults to TRUTHVOUCH_API_KEY env var.
        base_url: Base URL for the Trust API.
        timeout: HTTP timeout in seconds.

    Raises:
        ValueError: If no API key is provided or found in environment.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        resolved_key = api_key or os.environ.get("TRUTHVOUCH_API_KEY")
        if not resolved_key:
            raise ValueError(
                "TruthVouch API key is required. Pass api_key= or set the "
                "TRUTHVOUCH_API_KEY environment variable."
            )
        self._api_key = resolved_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    def _build_payload(self, content: str, mode: str) -> Dict[str, Any]:
        return {"content": content, "verificationMode": mode}

    async def verify(self, content: str, mode: str = "spot_check") -> TrustVerifyResult:
        """Verify content asynchronously.

        Args:
            content: Text to verify.
            mode: Verification mode.

        Returns:
            TrustVerifyResult.

        Raises:
            httpx.HTTPError: On network or HTTP-level errors.
        """
        url = f"{self._base_url}/verify"
        payload = self._build_payload(content, mode)
        logger.debug("TruthVouch: POST %s mode=%s", url, mode)

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(url, json=payload, headers=self._headers)
            response.raise_for_status()
            data = response.json()

        result = TrustVerifyResult.from_dict(data)
        logger.info(
            "TruthVouch: trust_score=%.3f mode=%s cache_hit=%s",
            result.trust_score,
            result.mode,
            result.cache_hit,
        )
        return result

    def verify_sync(self, content: str, mode: str = "spot_check") -> TrustVerifyResult:
        """Verify content synchronously.

        Args:
            content: Text to verify.
            mode: Verification mode.

        Returns:
            TrustVerifyResult.

        Raises:
            httpx.HTTPError: On network or HTTP-level errors.
        """
        url = f"{self._base_url}/verify"
        payload = self._build_payload(content, mode)
        logger.debug("TruthVouch: POST %s mode=%s", url, mode)

        with httpx.Client(timeout=self._timeout) as client:
            response = client.post(url, json=payload, headers=self._headers)
            response.raise_for_status()
            data = response.json()

        result = TrustVerifyResult.from_dict(data)
        logger.info(
            "TruthVouch: trust_score=%.3f mode=%s cache_hit=%s",
            result.trust_score,
            result.mode,
            result.cache_hit,
        )
        return result
