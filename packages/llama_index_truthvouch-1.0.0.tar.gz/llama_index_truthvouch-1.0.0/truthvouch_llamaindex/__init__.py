"""TruthVouch LlamaIndex integration package.

Provides LlamaIndex-compatible components for hallucination detection and
content verification via the TruthVouch Trust API.
"""

from truthvouch_llamaindex.client import TrustApiClient, TrustVerifyResult
from truthvouch_llamaindex.postprocessor import TruthVouchNodePostprocessor
from truthvouch_llamaindex.evaluator import TruthVouchResponseEvaluator
from truthvouch_llamaindex.query_engine import TruthVouchQueryEngine

__all__ = [
    "TrustApiClient",
    "TrustVerifyResult",
    "TruthVouchNodePostprocessor",
    "TruthVouchResponseEvaluator",
    "TruthVouchQueryEngine",
    "__version__",
]

__version__ = "1.0.0"
