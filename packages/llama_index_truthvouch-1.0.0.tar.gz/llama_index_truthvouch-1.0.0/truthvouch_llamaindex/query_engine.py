"""TruthVouch LlamaIndex query engine wrapper.

Wraps any existing LlamaIndex query engine and auto-verifies the response
via the Trust API. Trust metadata is attached to the response object.
"""

import logging
from typing import Any, Dict, Optional

from llama_index.core.base.base_query_engine import BaseQueryEngine
from llama_index.core.base.response.schema import RESPONSE_TYPE, Response
from llama_index.core.schema import QueryBundle

from truthvouch_llamaindex.client import TrustApiClient

logger = logging.getLogger(__name__)


class TruthVouchQueryEngine(BaseQueryEngine):
    """LlamaIndex query engine that verifies responses via the Trust API.

    Wraps any BaseQueryEngine. After the inner engine generates a response,
    the response text is sent to the Trust API. Trust metadata is stored in
    response.metadata under the "truthvouch" key.

    If the trust score is below the threshold, a warning is logged. Responses
    are always returned (verification is non-blocking by design).

    Args:
        inner_query_engine: The underlying query engine to wrap.
        api_key: Trust API key. Defaults to TRUTHVOUCH_API_KEY env var.
        base_url: Trust API base URL.
        threshold: Trust score threshold (for metadata/logging only).
        mode: Verification mode — "spot_check", "standard", or "full".

    Example:
        base_engine = index.as_query_engine()
        engine = TruthVouchQueryEngine(inner_query_engine=base_engine, threshold=0.8)
        response = engine.query("What is the capital of France?")
        print(response.metadata["truthvouch"]["trust_score"])
    """

    def __init__(
        self,
        inner_query_engine: BaseQueryEngine,
        api_key: Optional[str] = None,
        base_url: str = "http://localhost:5004/api/v1/trust",
        threshold: float = 0.8,
        mode: str = "spot_check",
    ) -> None:
        self._inner = inner_query_engine
        self._client = TrustApiClient(api_key=api_key, base_url=base_url)
        self._threshold = threshold
        self._mode = mode
        super().__init__(callback_manager=inner_query_engine.callback_manager)

    def _get_prompt_modules(self) -> Dict[str, Any]:
        """Return empty prompt modules dict — delegates to inner engine."""
        return {}

    def _attach_trust_metadata(self, response: Response, text: str) -> Response:
        """Call Trust API and attach results to response.metadata["truthvouch"].

        Args:
            response: The LlamaIndex Response to annotate.
            text: The response text to verify.

        Returns:
            The same Response object with trust metadata added.
        """
        if response.metadata is None:
            response.metadata = {}

        try:
            result = self._client.verify_sync(text, mode=self._mode)
            passed = result.trust_score >= self._threshold

            if not passed:
                logger.warning(
                    "TruthVouch query engine: trust_score=%.3f below threshold=%.2f",
                    result.trust_score,
                    self._threshold,
                )
            else:
                logger.info(
                    "TruthVouch query engine: trust_score=%.3f passed",
                    result.trust_score,
                )

            response.metadata["truthvouch"] = {
                "trust_score": result.trust_score,
                "passed": passed,
                "threshold": self._threshold,
                "mode": result.mode,
                "cache_hit": result.cache_hit,
                "processing_time_ms": result.processing_time_ms,
                "verification_id": result.id,
                "claims": [
                    {
                        "text": c.claim_text,
                        "status": c.status,
                        "confidence": c.confidence_score,
                    }
                    for c in result.claims
                ],
            }

        except Exception as exc:
            logger.error("TruthVouch query engine: verification failed — %s", exc)
            response.metadata["truthvouch"] = {
                "trust_score": None,
                "passed": None,
                "error": str(exc),
            }

        return response

    def _query(self, query_bundle: QueryBundle) -> RESPONSE_TYPE:
        """Execute the inner engine and verify the response.

        Args:
            query_bundle: LlamaIndex query bundle.

        Returns:
            Response with trust metadata attached.
        """
        response = self._inner._query(query_bundle)

        if isinstance(response, Response) and response.response:
            response = self._attach_trust_metadata(response, response.response)

        return response

    async def _aquery(self, query_bundle: QueryBundle) -> RESPONSE_TYPE:
        """Async execute the inner engine and verify the response.

        Args:
            query_bundle: LlamaIndex query bundle.

        Returns:
            Response with trust metadata attached.
        """
        response = await self._inner._aquery(query_bundle)

        if isinstance(response, Response) and response.response:
            text = response.response
            if response.metadata is None:
                response.metadata = {}
            try:
                result = await self._client.verify(text, mode=self._mode)
                passed = result.trust_score >= self._threshold

                if not passed:
                    logger.warning(
                        "TruthVouch query engine: trust_score=%.3f below threshold=%.2f",
                        result.trust_score,
                        self._threshold,
                    )

                response.metadata["truthvouch"] = {
                    "trust_score": result.trust_score,
                    "passed": passed,
                    "threshold": self._threshold,
                    "mode": result.mode,
                    "cache_hit": result.cache_hit,
                    "processing_time_ms": result.processing_time_ms,
                    "verification_id": result.id,
                    "claims": [
                        {
                            "text": c.claim_text,
                            "status": c.status,
                            "confidence": c.confidence_score,
                        }
                        for c in result.claims
                    ],
                }
            except Exception as exc:
                logger.error(
                    "TruthVouch query engine: async verification failed — %s", exc
                )
                response.metadata["truthvouch"] = {
                    "trust_score": None,
                    "passed": None,
                    "error": str(exc),
                }

        return response

    def retrieve(self, query_bundle: QueryBundle) -> Any:
        """Delegate retrieval to the inner engine."""
        return self._inner.retrieve(query_bundle)

    def synthesize(self, query_bundle: QueryBundle, nodes: Any, **kwargs: Any) -> Any:
        """Delegate synthesis to the inner engine."""
        return self._inner.synthesize(query_bundle, nodes, **kwargs)
