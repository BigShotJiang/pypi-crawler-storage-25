"""TruthVouch LlamaIndex response evaluator.

Evaluates a RAG response string for factual accuracy via the Trust API.
Returns a standard LlamaIndex EvaluationResult.
"""

import logging
from typing import Any, Dict, Optional, Sequence

from llama_index.core.evaluation import BaseEvaluator, EvaluationResult

from truthvouch_llamaindex.client import TrustApiClient, TrustVerifyResult

logger = logging.getLogger(__name__)


class TruthVouchResponseEvaluator(BaseEvaluator):
    """LlamaIndex evaluator that scores responses via the TruthVouch Trust API.

    Implements the BaseEvaluator interface. The evaluate() method sends the
    response text to the Trust API and wraps the result in an EvaluationResult
    with passing=True if trust_score >= threshold.

    Args:
        api_key: Trust API key. Defaults to TRUTHVOUCH_API_KEY env var.
        base_url: Trust API base URL.
        threshold: Minimum trust score to pass evaluation.
        mode: Verification mode — "spot_check", "standard", or "full".

    Example:
        evaluator = TruthVouchResponseEvaluator(threshold=0.8)
        result = await evaluator.evaluate("The Eiffel Tower is in Paris.")
        print(result.passing, result.score)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "http://localhost:5004/api/v1/trust",
        threshold: float = 0.8,
        mode: str = "spot_check",
    ) -> None:
        self._client = TrustApiClient(api_key=api_key, base_url=base_url)
        self._threshold = threshold
        self._mode = mode

    def _get_prompts(self) -> Dict[str, Any]:
        """Return empty prompts dict — this evaluator uses the Trust API, not prompts."""
        return {}

    def _update_prompts(self, prompts: Dict[str, Any]) -> None:
        """No-op — this evaluator uses the Trust API, not prompts."""

    def _build_feedback(self, result: TrustVerifyResult) -> str:
        """Build a human-readable feedback string from the Trust API result.

        Args:
            result: TrustVerifyResult from the Trust API.

        Returns:
            Feedback string summarising the verification outcome.
        """
        if not result.claims:
            return f"Trust score: {result.trust_score:.3f}. No claims extracted."

        verified = sum(1 for c in result.claims if c.status == "verified")
        failed = sum(1 for c in result.claims if c.status == "failed")
        unverifiable = sum(1 for c in result.claims if c.status == "unverifiable")

        parts = [
            f"Trust score: {result.trust_score:.3f}.",
            f"Claims — verified: {verified}, failed: {failed}, unverifiable: {unverifiable}.",
        ]

        failed_claims = [c for c in result.claims if c.status == "failed"]
        if failed_claims:
            corrections = "; ".join(
                f'"{c.claim_text}" → "{c.suggested_correction}"'
                for c in failed_claims[:3]
                if c.suggested_correction
            )
            if corrections:
                parts.append(f"Suggested corrections: {corrections}.")

        return " ".join(parts)

    async def aevaluate(
        self,
        query: Optional[str] = None,
        response: Optional[str] = None,
        contexts: Optional[Sequence[str]] = None,
        **kwargs: Any,
    ) -> EvaluationResult:
        """Evaluate a response asynchronously.

        Args:
            query: Optional query string (not used for verification).
            response: The response text to verify.
            contexts: Optional retrieved context strings (not used).
            **kwargs: Additional kwargs.

        Returns:
            EvaluationResult with passing, score, and feedback fields.
        """
        text_to_verify = response or ""
        if not text_to_verify.strip():
            logger.warning("TruthVouch evaluator: empty response, returning failed")
            return EvaluationResult(
                query=query,
                response=response,
                passing=False,
                score=0.0,
                feedback="Empty response — cannot verify.",
            )

        try:
            result = await self._client.verify(text_to_verify, mode=self._mode)
            passing = result.trust_score >= self._threshold
            feedback = self._build_feedback(result)

            logger.info(
                "TruthVouch evaluator: trust_score=%.3f passing=%s",
                result.trust_score,
                passing,
            )

            return EvaluationResult(
                query=query,
                response=response,
                passing=passing,
                score=result.trust_score,
                feedback=feedback,
            )

        except Exception as exc:
            logger.error("TruthVouch evaluator: verification error — %s", exc)
            return EvaluationResult(
                query=query,
                response=response,
                passing=False,
                score=0.0,
                feedback=f"Verification error: {exc}",
            )

    def evaluate(
        self,
        query: Optional[str] = None,
        response: Optional[str] = None,
        contexts: Optional[Sequence[str]] = None,
        **kwargs: Any,
    ) -> EvaluationResult:
        """Evaluate a response synchronously.

        Args:
            query: Optional query string.
            response: The response text to verify.
            contexts: Optional retrieved context strings.
            **kwargs: Additional kwargs.

        Returns:
            EvaluationResult with passing, score, and feedback fields.
        """
        text_to_verify = response or ""
        if not text_to_verify.strip():
            logger.warning("TruthVouch evaluator: empty response, returning failed")
            return EvaluationResult(
                query=query,
                response=response,
                passing=False,
                score=0.0,
                feedback="Empty response — cannot verify.",
            )

        try:
            result = self._client.verify_sync(text_to_verify, mode=self._mode)
            passing = result.trust_score >= self._threshold
            feedback = self._build_feedback(result)

            logger.info(
                "TruthVouch evaluator: trust_score=%.3f passing=%s",
                result.trust_score,
                passing,
            )

            return EvaluationResult(
                query=query,
                response=response,
                passing=passing,
                score=result.trust_score,
                feedback=feedback,
            )

        except Exception as exc:
            logger.error("TruthVouch evaluator: verification error — %s", exc)
            return EvaluationResult(
                query=query,
                response=response,
                passing=False,
                score=0.0,
                feedback=f"Verification error: {exc}",
            )
