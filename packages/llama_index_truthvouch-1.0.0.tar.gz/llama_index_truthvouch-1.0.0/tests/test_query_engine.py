"""Tests for TruthVouchQueryEngine with mocked httpx transport and inner engine."""

import pytest
import httpx
import respx
from unittest.mock import MagicMock, AsyncMock

from llama_index.core.base.response.schema import Response
from llama_index.core.schema import QueryBundle

from truthvouch_llamaindex.query_engine import TruthVouchQueryEngine

_VERIFY_URL = "http://localhost:5004/api/v1/trust/verify"


def _make_response(trust_score: float, status: str = "verified") -> dict:
    return {
        "requestId": "qe-test",
        "trustScore": trust_score,
        "claims": [
            {
                "claimText": "test claim",
                "status": status,
                "confidenceScore": 0.9,
                "sourceReference": "",
                "suggestedCorrection": "",
            }
        ],
        "latencyMs": 55,
        "tokensUsed": 18,
        "cacheHits": 0,
        "verificationMode": "spot_check",
        "createdAt": "2026-03-06T10:00:00Z",
    }


def _make_inner_engine(response_text: str) -> MagicMock:
    """Create a mock inner query engine returning a Response with given text."""
    inner = MagicMock()
    inner.callback_manager = MagicMock()
    llama_response = Response(response=response_text, metadata={})
    inner._query = MagicMock(return_value=llama_response)
    inner._aquery = AsyncMock(return_value=llama_response)
    return inner


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("TRUTHVOUCH_API_KEY", "test-key")
    return "test-key"


@respx.mock
def test_query_attaches_trust_metadata(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.93)))

    inner = _make_inner_engine("Paris is the capital of France.")
    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8)

    response = engine._query(QueryBundle(query_str="What is the capital?"))

    assert isinstance(response, Response)
    assert "truthvouch" in response.metadata
    vt = response.metadata["truthvouch"]
    assert vt["trust_score"] == pytest.approx(0.93)
    assert vt["passed"] is True
    assert vt["threshold"] == pytest.approx(0.8)
    assert vt["verification_id"] == "qe-test"


@respx.mock
def test_query_marks_low_trust_as_failed(api_key):
    respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.2, "failed"))
    )

    inner = _make_inner_engine("The Eiffel Tower is in Berlin.")
    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8)

    response = engine._query(QueryBundle(query_str="Where is the Eiffel Tower?"))

    vt = response.metadata["truthvouch"]
    assert vt["trust_score"] == pytest.approx(0.2)
    assert vt["passed"] is False


@respx.mock
def test_query_attaches_claims(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.9)))

    inner = _make_inner_engine("factual response")
    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8)

    response = engine._query(QueryBundle(query_str="query"))

    claims = response.metadata["truthvouch"]["claims"]
    assert isinstance(claims, list)
    assert len(claims) == 1
    assert claims[0]["status"] == "verified"


@respx.mock
def test_query_api_error_attaches_error_metadata(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(500))

    inner = _make_inner_engine("some response")
    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8)

    # Should NOT raise — error is attached to metadata
    response = engine._query(QueryBundle(query_str="query"))

    vt = response.metadata["truthvouch"]
    assert vt["trust_score"] is None
    assert vt["passed"] is None
    assert "error" in vt


@respx.mock
@pytest.mark.asyncio
async def test_aquery_attaches_trust_metadata(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.88)))

    inner = _make_inner_engine("async response text")
    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8)

    response = await engine._aquery(QueryBundle(query_str="async query"))

    assert "truthvouch" in response.metadata
    vt = response.metadata["truthvouch"]
    assert vt["trust_score"] == pytest.approx(0.88)
    assert vt["passed"] is True


@respx.mock
@pytest.mark.asyncio
async def test_aquery_low_trust_marks_failed(api_key):
    respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.15, "failed"))
    )

    inner = _make_inner_engine("incorrect async response")
    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8)

    response = await engine._aquery(QueryBundle(query_str="query"))

    vt = response.metadata["truthvouch"]
    assert vt["passed"] is False


@respx.mock
@pytest.mark.asyncio
async def test_aquery_api_error_attaches_error_metadata(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(503))

    inner = _make_inner_engine("response that causes error")
    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8)

    # Should NOT raise
    response = await engine._aquery(QueryBundle(query_str="query"))

    vt = response.metadata["truthvouch"]
    assert "error" in vt


@respx.mock
def test_query_uses_configured_mode(api_key):
    import json

    route = respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.9))
    )

    inner = _make_inner_engine("test response")
    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8, mode="standard")

    engine._query(QueryBundle(query_str="query"))

    payload = json.loads(route.calls.last.request.content)
    assert payload["verificationMode"] == "standard"


def test_query_none_response_does_not_verify(api_key):
    """When inner engine returns empty response, skip Trust API call."""
    inner = MagicMock()
    inner.callback_manager = MagicMock()
    inner._query = MagicMock(return_value=Response(response=None, metadata={}))

    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8)

    # Should not call Trust API (no respx mock needed)
    response = engine._query(QueryBundle(query_str="query"))
    assert response is not None
    assert "truthvouch" not in (response.metadata or {})


@respx.mock
def test_engine_delegates_retrieve_to_inner(api_key):
    inner = _make_inner_engine("text")
    inner.retrieve = MagicMock(return_value=["node1"])

    engine = TruthVouchQueryEngine(inner_query_engine=inner, threshold=0.8)
    result = engine.retrieve(QueryBundle(query_str="q"))

    inner.retrieve.assert_called_once()
    assert result == ["node1"]
