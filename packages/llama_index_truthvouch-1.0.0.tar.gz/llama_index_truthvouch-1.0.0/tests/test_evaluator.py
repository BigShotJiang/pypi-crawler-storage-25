"""Tests for TruthVouchResponseEvaluator with mocked httpx transport."""

import pytest
import httpx
import respx
from llama_index.core.evaluation import EvaluationResult

from truthvouch_llamaindex.evaluator import TruthVouchResponseEvaluator

_VERIFY_URL = "http://localhost:5004/api/v1/trust/verify"


def _make_response(trust_score: float, claims_statuses: list = None) -> dict:
    if claims_statuses is None:
        claims_statuses = ["verified"]
    claims = [
        {
            "claimText": f"claim {i}",
            "status": s,
            "confidenceScore": 0.9,
            "sourceReference": "source",
            "suggestedCorrection": "correction" if s == "failed" else "",
        }
        for i, s in enumerate(claims_statuses)
    ]
    return {
        "requestId": "eval-test",
        "trustScore": trust_score,
        "claims": claims,
        "latencyMs": 90,
        "tokensUsed": 25,
        "cacheHits": 0,
        "verificationMode": "spot_check",
        "createdAt": "2026-03-06T10:00:00Z",
    }


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("TRUTHVOUCH_API_KEY", "test-key")
    return "test-key"


@respx.mock
@pytest.mark.asyncio
async def test_aevaluate_passing_response(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.95)))

    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = await evaluator.aevaluate(response="Paris is the capital of France.")

    assert isinstance(result, EvaluationResult)
    assert result.passing is True
    assert result.score == pytest.approx(0.95)
    assert "Trust score" in result.feedback


@respx.mock
@pytest.mark.asyncio
async def test_aevaluate_failing_response(api_key):
    respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.15, ["failed"]))
    )

    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = await evaluator.aevaluate(response="The Eiffel Tower is in Berlin.")

    assert result.passing is False
    assert result.score == pytest.approx(0.15)
    assert "failed: 1" in result.feedback


@respx.mock
@pytest.mark.asyncio
async def test_aevaluate_exactly_at_threshold_passes(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.8)))

    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = await evaluator.aevaluate(response="borderline content")

    assert result.passing is True


@pytest.mark.asyncio
async def test_aevaluate_empty_response_fails(api_key):
    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = await evaluator.aevaluate(response="")

    assert result.passing is False
    assert result.score == 0.0
    assert "Empty" in result.feedback


@pytest.mark.asyncio
async def test_aevaluate_whitespace_response_fails(api_key):
    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = await evaluator.aevaluate(response="   \n  ")

    assert result.passing is False


@respx.mock
@pytest.mark.asyncio
async def test_aevaluate_attaches_metadata(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.9)))

    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = await evaluator.aevaluate(response="some content")

    # Verify that the response was processed and contains a trust score in feedback
    assert result.passing is True
    assert result.score == pytest.approx(0.9)
    assert "Trust score" in result.feedback


@respx.mock
@pytest.mark.asyncio
async def test_aevaluate_api_error_returns_failed(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(500))

    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = await evaluator.aevaluate(response="content that errors")

    assert result.passing is False
    assert result.score == 0.0
    assert "error" in result.feedback.lower()


@respx.mock
@pytest.mark.asyncio
async def test_aevaluate_mixed_claims_feedback(api_key):
    response_data = _make_response(0.5, ["verified", "failed", "unverifiable"])
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=response_data))

    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = await evaluator.aevaluate(response="mixed claims content")

    assert "verified: 1" in result.feedback
    assert "failed: 1" in result.feedback
    assert "unverifiable: 1" in result.feedback


@respx.mock
def test_evaluate_sync_passing(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.91)))

    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = evaluator.evaluate(response="factual content")

    assert result.passing is True
    assert result.score == pytest.approx(0.91)


@respx.mock
def test_evaluate_sync_failing(api_key):
    respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.1, ["failed"]))
    )

    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = evaluator.evaluate(response="false content")

    assert result.passing is False


def test_evaluate_sync_empty_fails(api_key):
    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = evaluator.evaluate(response="")
    assert result.passing is False
    assert result.score == 0.0


@respx.mock
def test_evaluate_passes_query_to_result(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.9)))

    evaluator = TruthVouchResponseEvaluator(threshold=0.8)
    result = evaluator.evaluate(query="What is the capital?", response="Paris.")

    assert result.query == "What is the capital?"
    assert result.response == "Paris."


@respx.mock
def test_evaluate_sync_uses_mode(api_key):
    import json

    route = respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.9))
    )

    evaluator = TruthVouchResponseEvaluator(mode="full")
    evaluator.evaluate(response="test response")

    payload = json.loads(route.calls.last.request.content)
    assert payload["verificationMode"] == "full"
