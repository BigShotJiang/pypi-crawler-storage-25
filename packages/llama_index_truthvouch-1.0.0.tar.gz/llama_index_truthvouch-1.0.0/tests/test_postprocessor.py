"""Tests for TruthVouchNodePostprocessor with mocked httpx transport."""

import pytest
import httpx
import respx
from unittest.mock import MagicMock

from llama_index.core.schema import NodeWithScore, TextNode

from truthvouch_llamaindex.postprocessor import TruthVouchNodePostprocessor

_VERIFY_URL = "http://localhost:5004/api/v1/trust/verify"


def _make_response(trust_score: float, status: str = "verified") -> dict:
    return {
        "requestId": "pp-test",
        "trustScore": trust_score,
        "claims": [
            {
                "claimText": "test claim",
                "status": status,
                "confidenceScore": 0.88,
                "sourceReference": "wiki",
                "suggestedCorrection": "",
            }
        ],
        "latencyMs": 70,
        "tokensUsed": 12,
        "cacheHits": 0,
        "verificationMode": "spot_check",
        "createdAt": "2026-03-06T10:00:00Z",
    }


def _make_node(text: str) -> NodeWithScore:
    return NodeWithScore(node=TextNode(text=text, metadata={}), score=1.0)


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("TRUTHVOUCH_API_KEY", "test-key")
    return "test-key"


@respx.mock
def test_postprocess_passes_high_trust_node(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.95)))

    pp = TruthVouchNodePostprocessor(threshold=0.8)
    nodes = [_make_node("Paris is the capital of France.")]
    result = pp._postprocess_nodes(nodes)

    assert len(result) == 1
    assert result[0].node.metadata["trust_score"] == pytest.approx(0.95)


@respx.mock
def test_postprocess_filters_low_trust_node(api_key):
    respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.2, "failed"))
    )

    pp = TruthVouchNodePostprocessor(threshold=0.8)
    nodes = [_make_node("The Eiffel Tower is in Berlin.")]
    result = pp._postprocess_nodes(nodes)

    assert len(result) == 0


@respx.mock
def test_postprocess_no_filter_keeps_all_nodes(api_key):
    respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.2, "failed"))
    )

    pp = TruthVouchNodePostprocessor(threshold=0.8, filter_below_threshold=False)
    nodes = [_make_node("Low trust content")]
    result = pp._postprocess_nodes(nodes)

    assert len(result) == 1
    assert result[0].node.metadata["trust_score"] == pytest.approx(0.2)


@respx.mock
def test_postprocess_multiple_nodes_partial_filter(api_key):
    call_count = 0

    def side_effect(request):
        nonlocal call_count
        call_count += 1
        score = 0.1 if call_count == 1 else 0.9
        return httpx.Response(200, json=_make_response(score))

    respx.post(_VERIFY_URL).mock(side_effect=side_effect)

    pp = TruthVouchNodePostprocessor(threshold=0.8)
    nodes = [_make_node("false claim"), _make_node("true claim")]
    result = pp._postprocess_nodes(nodes)

    assert len(result) == 1
    assert result[0].node.metadata["trust_score"] == pytest.approx(0.9)


@respx.mock
def test_postprocess_attaches_claims_metadata(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.9)))

    pp = TruthVouchNodePostprocessor(threshold=0.5)
    nodes = [_make_node("factual content")]
    result = pp._postprocess_nodes(nodes)

    meta = result[0].node.metadata
    assert "trust_claims" in meta
    assert len(meta["trust_claims"]) == 1
    assert meta["trust_claims"][0]["status"] == "verified"
    assert "trust_verification_id" in meta
    assert meta["trust_cache_hit"] is False


@respx.mock
def test_postprocess_api_error_sets_score_zero(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(500))

    pp = TruthVouchNodePostprocessor(threshold=0.8, filter_below_threshold=False)
    nodes = [_make_node("error content")]
    result = pp._postprocess_nodes(nodes)

    assert len(result) == 1
    assert result[0].node.metadata["trust_score"] == 0.0
    assert "trust_error" in result[0].node.metadata


@respx.mock
def test_postprocess_api_error_filters_node_when_filtering_enabled(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(500))

    pp = TruthVouchNodePostprocessor(threshold=0.8, filter_below_threshold=True)
    nodes = [_make_node("error content")]
    result = pp._postprocess_nodes(nodes)

    # score=0.0 < threshold=0.8, so filtered
    assert len(result) == 0


def test_postprocess_empty_nodes(api_key):
    pp = TruthVouchNodePostprocessor(threshold=0.8)
    result = pp._postprocess_nodes([])
    assert result == []


@respx.mock
def test_postprocess_uses_configured_mode(api_key):
    import json

    route = respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.9))
    )

    pp = TruthVouchNodePostprocessor(threshold=0.5, mode="full")
    pp._postprocess_nodes([_make_node("test node")])

    payload = json.loads(route.calls.last.request.content)
    assert payload["verificationMode"] == "full"


@respx.mock
def test_postprocess_exactly_at_threshold_keeps_node(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.8)))

    pp = TruthVouchNodePostprocessor(threshold=0.8)
    nodes = [_make_node("borderline content")]
    result = pp._postprocess_nodes(nodes)

    # 0.8 >= 0.8, should keep
    assert len(result) == 1
