# llama-index-truthvouch

LlamaIndex integration for the [TruthVouch](https://truthvouch.com) Trust API. Add hallucination
detection and content verification to any LlamaIndex RAG pipeline in minutes.

## Installation

```bash
pip install llama-index-truthvouch
```

## Quickstart

```python
import os
os.environ["TRUTHVOUCH_API_KEY"] = "your-api-key"

from truthvouch_llamaindex import TruthVouchResponseEvaluator

evaluator = TruthVouchResponseEvaluator(threshold=0.8)
result = await evaluator.evaluate("The Eiffel Tower is in Paris, France.")
print(result.passing)       # True
print(result.score)         # e.g. 0.96
print(result.feedback)      # human-readable explanation
```

## Components

### TrustApiClient

Low-level async/sync client for the Trust API verify endpoint.

```python
from truthvouch_llamaindex import TrustApiClient

client = TrustApiClient(api_key="your-api-key")
result = client.verify_sync("The Eiffel Tower is in Paris.", mode="standard")
print(result.trust_score)  # 0.97
```

### TruthVouchNodePostprocessor

Filters retrieved nodes by trust score before they reach the LLM.

```python
from llama_index.core import VectorStoreIndex
from truthvouch_llamaindex import TruthVouchNodePostprocessor

postprocessor = TruthVouchNodePostprocessor(threshold=0.75)
query_engine = index.as_query_engine(node_postprocessors=[postprocessor])
response = query_engine.query("What is the capital of France?")
```

### TruthVouchResponseEvaluator

Evaluate a RAG response string for factual accuracy.

```python
from truthvouch_llamaindex import TruthVouchResponseEvaluator

evaluator = TruthVouchResponseEvaluator(threshold=0.8)
result = await evaluator.evaluate("Some response text")
if not result.passing:
    print("Hallucination risk:", result.feedback)
```

### TruthVouchQueryEngine

Wrapper query engine that auto-verifies every response.

```python
from truthvouch_llamaindex import TruthVouchQueryEngine

engine = TruthVouchQueryEngine(inner_query_engine=base_engine, threshold=0.8)
response = engine.query("Tell me about the Eiffel Tower.")
print(response.metadata["trust_score"])
```

## Configuration

| Parameter | Env var | Default |
|---|---|---|
| `api_key` | `TRUTHVOUCH_API_KEY` | (required) |
| `base_url` | — | `http://localhost:5004/api/v1/trust` |
| `threshold` | — | `0.8` |
| `mode` | — | `spot_check` |

## License

Apache-2.0
