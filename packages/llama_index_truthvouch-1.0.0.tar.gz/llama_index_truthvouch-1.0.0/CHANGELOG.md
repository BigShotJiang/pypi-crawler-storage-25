# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-04-03

### Added
- Initial public release
- TrustApiClient — async/sync client for TruthVouch Trust API verify endpoint
- TruthVouchNodePostprocessor — node postprocessor with trust score filtering
- TruthVouchResponseEvaluator — response evaluator for factual accuracy
- TruthVouchQueryEngine — wrapper query engine with automatic verification
- PEP 561 py.typed marker for type checker support
