"""
Learn-By-Wire Guard Pro module (Python implementation).

This module exposes the advanced reflex engine used by Learn-By-Wire Guard in `mode="pro"`.
"""

from __future__ import annotations

import hashlib
import time
from typing import Any, Dict, Tuple

from .lic import looks_like_signed_license_token, verify_signed_license_token


class ProReflexEngine:
    """
    Advanced reflex engine with stateful pattern memory.

    Configurable parameters:
    - history_window: size of spike/ratio history
    - oscillation_threshold: spikes needed to trigger oscillation mode
    - instability_threshold: consecutive spikes for instability
    - variance_threshold: ratio variance threshold for instability
    - nuclear_scale: scale multiplier in nuclear mode
    - persistent_scale: scale multiplier in persistent mode
    - reactive_spike_scale: scale multiplier for single spike
    - reactive_stress_scale: scale multiplier for stress
    - recovery_boost_confident: recovery multiplier after confident calm streak
    - recovery_boost_cautious: recovery multiplier after cautious calm streak
    - calm_threshold_confident: calm steps needed for confident recovery
    - calm_threshold_cautious: calm steps needed for cautious recovery
    - max_scale_change: maximum scale change per step (non-nuclear path)
    - variance_window: minimum history for variance calculation
    """

    def __init__(
        self,
        license_key,
        history_window=50,
        oscillation_threshold=3,
        instability_threshold=2,
        variance_threshold=0.5,
        nuclear_scale=0.5,
        persistent_scale=0.8,
        reactive_spike_scale=0.65,
        reactive_stress_scale=0.80,
        recovery_boost_confident=4.0,
        recovery_boost_cautious=2.0,
        calm_threshold_confident=10,
        calm_threshold_cautious=5,
        max_scale_change=0.3,
        variance_window=20,
    ):
        self._is_licensed, self._license_expiry = self._verify_key(license_key)
        if not self._is_licensed:
            print("[Learn-By-Wire Guard Pro] WARNING: Invalid license key. Pro features disabled.")

        self.history_window = max(1, int(history_window))
        self.oscillation_threshold = int(oscillation_threshold)
        self.instability_threshold = int(instability_threshold)
        self.variance_threshold = float(variance_threshold)
        self.nuclear_scale = float(nuclear_scale)
        self.persistent_scale_mult = float(persistent_scale)
        self.reactive_spike_scale = float(reactive_spike_scale)
        self.reactive_stress_scale = float(reactive_stress_scale)
        self.recovery_boost_confident = float(recovery_boost_confident)
        self.recovery_boost_cautious = float(recovery_boost_cautious)
        self.calm_threshold_confident = int(calm_threshold_confident)
        self.calm_threshold_cautious = int(calm_threshold_cautious)
        self.max_scale_change = float(max_scale_change)
        self.variance_window = int(variance_window)

        # Stateful memory
        self._spike_history = [0] * self.history_window
        self._ratio_history = [0.0] * self.history_window
        self._hist_head = 0
        self._hist_count = 0
        self._rolling_spike_sum = 0
        self._rolling_ratio_sum = 0.0
        self._rolling_ratio_sumsq = 0.0
        self._calm_streak = 0
        self._spike_streak = 0
        self._persistent_scale = 1.0

        self._license_check_every = 64
        self._license_check_counter = 0

    def _verify_key(self, key) -> Tuple[bool, int]:
        if key is None:
            return False, 0

        try:
            raw_key = str(key).strip()

            # Signed V2 licenses are the preferred production path.
            if looks_like_signed_license_token(raw_key):
                payload = verify_signed_license_token(raw_key, expected_edition="lbw_guard_pro")
                expiry = int(str(payload.get("expiry", "0")).strip() or "0")
                return True, expiry

            # Expected format: LBW-GUARD-PRO-V1-{hash}-{expiry}
            parts = raw_key.split("-")
            if (
                len(parts) != 6
                or parts[0] != "LBW"
                or parts[1] != "GUARD"
                or parts[2] != "PRO"
                or parts[3] != "V1"
            ):
                return False, 0

            provided_hash = parts[4]
            expiry_str = parts[5]
            expected_hash = hashlib.sha256(f"LBW-GUARD-PRO-V1-{expiry_str}".encode()).hexdigest()[:16]
            if provided_hash != expected_hash:
                return False, 0

            expiry = int(expiry_str)
            if time.time() > expiry:
                print("[Learn-By-Wire Guard Pro] License expired.")
                return False, 0

            return True, expiry
        except Exception as exc:
            print(f"[Learn-By-Wire Guard Pro] License validation error: {exc}")
            return False, 0

    def calculate_scale(
        self,
        ratio: float,
        sign_flip: bool,
        current_scale: float,
        min_scale: float,
        spike_thresh: float,
        stress_thresh: float,
        recovery_rate: float,
    ) -> float:
        if not self._is_licensed:
            return self._fallback_logic(
                ratio,
                sign_flip,
                current_scale,
                min_scale,
                spike_thresh,
                stress_thresh,
                recovery_rate,
            )

        self._license_check_counter += 1
        if self._license_check_counter >= self._license_check_every:
            self._license_check_counter = 0
            if time.time() > self._license_expiry:
                print("[Learn-By-Wire Guard Pro] License expired. Reverting to eval mode.")
                self._is_licensed = False
                return self._fallback_logic(
                    ratio,
                    sign_flip,
                    current_scale,
                    min_scale,
                    spike_thresh,
                    stress_thresh,
                    recovery_rate,
                )

        is_spike = 1 if ratio > spike_thresh else 0
        is_stress = 1 if (ratio > stress_thresh or sign_flip) else 0

        # O(1) ring-buffer update + rolling stats
        hist_len = self.history_window
        idx = self._hist_head

        if self._hist_count == hist_len:
            old_spike = int(self._spike_history[idx])
            old_ratio = float(self._ratio_history[idx])
            self._rolling_spike_sum -= old_spike
            self._rolling_ratio_sum -= old_ratio
            self._rolling_ratio_sumsq -= old_ratio * old_ratio
        else:
            self._hist_count += 1

        self._spike_history[idx] = is_spike
        self._ratio_history[idx] = float(ratio)
        self._rolling_spike_sum += is_spike
        self._rolling_ratio_sum += float(ratio)
        self._rolling_ratio_sumsq += float(ratio) * float(ratio)

        self._hist_head = idx + 1
        if self._hist_head >= hist_len:
            self._hist_head = 0

        if is_spike:
            self._spike_streak += 1
            self._calm_streak = 0
        elif not is_stress:
            self._calm_streak += 1
            self._spike_streak = 0
        else:
            self._spike_streak = 0
            self._calm_streak = 0

        spike_count = self._rolling_spike_sum
        avg_ratio = 0.0
        ratio_variance = 0.0
        if self._hist_count > 0:
            denom = float(self._hist_count)
            avg_ratio = self._rolling_ratio_sum / denom
            ratio_variance = (self._rolling_ratio_sumsq / denom) - (avg_ratio * avg_ratio)
            if ratio_variance < 0.0:
                ratio_variance = 0.0

        is_oscillating = spike_count >= self.oscillation_threshold
        is_unstable = False

        if ratio_variance > self.variance_threshold and self._hist_count >= self.variance_window:
            is_unstable = True
        if self._spike_streak >= self.instability_threshold:
            is_unstable = True

        new_scale = float(current_scale)

        if is_oscillating or is_unstable:
            new_scale = float(min_scale) * self.nuclear_scale
            self._persistent_scale = new_scale
        elif spike_count >= 2:
            new_scale = max(float(min_scale), float(min_scale) * self.persistent_scale_mult)
            self._persistent_scale = new_scale
        elif is_spike:
            new_scale = max(float(min_scale), float(current_scale) * self.reactive_spike_scale)
        elif is_stress:
            new_scale = max(float(min_scale), float(current_scale) * self.reactive_stress_scale)
        elif self._calm_streak >= self.calm_threshold_confident:
            recovery_boost = float(recovery_rate) * self.recovery_boost_confident
            new_scale = min(1.0, float(current_scale) + recovery_boost)
        elif self._calm_streak >= self.calm_threshold_cautious:
            recovery_boost = float(recovery_rate) * self.recovery_boost_cautious
            new_scale = min(1.0, float(current_scale) + recovery_boost)
        else:
            new_scale = min(1.0, float(current_scale) + float(recovery_rate))

        if not (is_oscillating or is_unstable):
            max_change = float(self.max_scale_change)
            if abs(new_scale - float(current_scale)) > max_change:
                if new_scale > current_scale:
                    new_scale = float(current_scale) + max_change
                else:
                    new_scale = float(current_scale) - max_change

        new_scale = max(float(min_scale) * 0.5, min(1.0, float(new_scale)))
        return float(new_scale)

    def _fallback_logic(
        self,
        ratio: float,
        sign_flip: bool,
        current_scale: float,
        min_scale: float,
        spike_thresh: float,
        stress_thresh: float,
        recovery_rate: float,
    ) -> float:
        if ratio > spike_thresh:
            return max(min_scale, current_scale * 0.7)
        if ratio > stress_thresh or sign_flip:
            return max(min_scale, current_scale * 0.85)
        return min(1.0, current_scale + recovery_rate)

    def get_diagnostics(self) -> Dict[str, Any]:
        if not self._is_licensed:
            return {"licensed": False}

        avg_ratio = 0.0
        if self._hist_count > 0:
            avg_ratio = self._rolling_ratio_sum / float(self._hist_count)

        return {
            "licensed": True,
            "spike_count_50": self._rolling_spike_sum,
            "calm_streak": self._calm_streak,
            "spike_streak": self._spike_streak,
            "avg_ratio": avg_ratio,
            "persistent_scale": self._persistent_scale,
            "history_length": self._hist_count,
            "license_expires": self._license_expiry,
            "config": {
                "history_window": self.history_window,
                "oscillation_threshold": self.oscillation_threshold,
                "instability_threshold": self.instability_threshold,
                "variance_threshold": self.variance_threshold,
                "nuclear_scale": self.nuclear_scale,
                "persistent_scale": self.persistent_scale_mult,
                "reactive_spike_scale": self.reactive_spike_scale,
                "reactive_stress_scale": self.reactive_stress_scale,
                "recovery_boost_confident": self.recovery_boost_confident,
                "recovery_boost_cautious": self.recovery_boost_cautious,
            },
        }

    def update_config(self, **kwargs):
        if not self._is_licensed:
            print("[Learn-By-Wire Guard Pro] Cannot update config: Invalid license.")
            return {}

        updated = {}

        if "history_window" in kwargs:
            self.history_window = max(1, int(kwargs["history_window"]))
            self._spike_history = [0] * self.history_window
            self._ratio_history = [0.0] * self.history_window
            self._hist_head = 0
            self._hist_count = 0
            self._rolling_spike_sum = 0
            self._rolling_ratio_sum = 0.0
            self._rolling_ratio_sumsq = 0.0
            updated["history_window"] = self.history_window

        key_map = {
            "oscillation_threshold": "oscillation_threshold",
            "instability_threshold": "instability_threshold",
            "variance_threshold": "variance_threshold",
            "nuclear_scale": "nuclear_scale",
            "persistent_scale": "persistent_scale_mult",
            "reactive_spike_scale": "reactive_spike_scale",
            "reactive_stress_scale": "reactive_stress_scale",
            "recovery_boost_confident": "recovery_boost_confident",
            "recovery_boost_cautious": "recovery_boost_cautious",
            "calm_threshold_confident": "calm_threshold_confident",
            "calm_threshold_cautious": "calm_threshold_cautious",
            "max_scale_change": "max_scale_change",
            "variance_window": "variance_window",
        }

        for public_key, attr_name in key_map.items():
            if public_key in kwargs:
                setattr(self, attr_name, kwargs[public_key])
                updated[public_key] = getattr(self, attr_name)

        return updated


__all__ = ["ProReflexEngine"]
