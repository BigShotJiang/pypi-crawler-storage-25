"""
Generated public-key registry for packaged Learn-By-Wire Guard builds.

This placeholder keeps imports stable before production keys are embedded.
`lbw/build_product.py` will overwrite this file when
`LBW_PRODUCT_PUBLIC_KEY_FILE` or `LBW_PRODUCT_PUBLIC_KEY_JSON` is provided.
"""

EMBEDDED_PUBLIC_KEYS = {}
