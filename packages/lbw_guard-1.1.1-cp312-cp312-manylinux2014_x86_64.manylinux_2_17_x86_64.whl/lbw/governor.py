# governor.py
"""
Learn-By-Wire Guard Governor v1.1.0 (Eval Interface - FIXED)
=============================================================

This file contains the governor core + runtime bridge logic.
License/edition gating is delegated to `lbw_lic`, so product builds can
compile core (`lbw`) and license gate (`lbw_lic`) as separate binaries.

License: Business Source License 1.1.0
- Change Date: 2028-02-13

Edition model:
- lbw_guard_eval (Guard Eval): free, max 1 visible GPU
- lbw_guard_std (Guard Std): license required, GPU cap from license
- lbw_guard_pro (Guard Pro): license forwarded to Guard Pro bridge

Important:
- Guard Std entitlement parsing/enforcement is in `lbw_lic`.
- Guard Pro key generation/verification is implemented in the `lbw.pro` bridge.
"""

from __future__ import annotations
import math
import torch
from torch.optim import Optimizer

from .lic import (
    build_license_context,
    build_se_license_key as _build_se_license_key,
    coerce_positive_int as _coerce_positive_int,
    enforce_ce_gpu_limit as _enforce_ce_gpu_limit,
    enforce_se_gpu_limit as _enforce_se_gpu_limit,
    get_visible_gpu_count as _get_visible_gpu_count,
    parse_se_license as _parse_se_license,
    resolve_mode as _resolve_mode_alias,
    se_expiry_from_now as _se_expiry_from_now,
)

class LearnByWire(Optimizer):
    """
    Learn-By-Wire Guard Governor with Adaptive Learning Rate Scaling.
    
    Features:
    - Automatic spike detection and dampening
    - Oscillation detection via gradient sign tracking
    - Stateless (Eval) or Stateful (Guard Pro) reflex control
    - Fused operations for memory efficiency
    
    Args:
        params: Iterable of parameters to optimize
        lr: Learning rate (default: 1e-3)
        betas: Coefficients for gradient and squared gradient averaging (default: (0.9, 0.999))
        eps: Term added to denominator for numerical stability (default: 1e-8)
        weight_decay: Weight decay coefficient (default: 0.01)
        auto_enabled: Enable adaptive scaling (default: True)
        stress_threshold: Ratio threshold for stress detection (default: 1.1)
        spike_threshold: Ratio threshold for spike detection (default: 1.5)
        min_scale: Minimum allowed learning rate scale (default: 0.1)
        recovery_fast: Recovery rate when conditions are calm (default: 0.01)
        use_max_rms: Use max RMS across layers vs mean (default: True)
        stats_freq: Steps between metric collection (default: 10)
        ema_decay: Exponential moving average decay rate (default: 0.95)
        mode:
            - "lbw_guard_eval" (or alias "eval"): free edition, max 1 visible GPU
            - "lbw_guard_std": licensed Guard Std, GPU count capped by license
            - "lbw_guard_pro" (or alias "pro"): Guard Pro edition
        license_key:
            - required for "lbw_guard_std"
            - passed through to "lbw_guard_pro" bridge unchanged
    """
    def __init__(
        self,
        params,
        lr=1e-3,
        betas=(0.9, 0.999),
        eps=1e-8,
        weight_decay=0.01,
        *,
        auto_enabled=True,
        stress_threshold=1.1,
        spike_threshold=1.5,
        min_scale=0.1,      #Best 0.1
        recovery_fast=0.01,
        use_max_rms=True,
        stats_freq=10,      #Best 5
        ema_decay=0.85,   #Best 0.85
        mode="eval",
        license_key=None,
        # =========================================================================
        # Guard Pro MODE PARAMETERS (only used if mode="pro")
        # =========================================================================
        pro_history_window=50,
        pro_oscillation_threshold=3,
        pro_instability_threshold=2,
        pro_variance_threshold=0.5,
        pro_nuclear_scale=0.5,
        pro_persistent_scale=0.8,
        pro_reactive_spike_scale=0.65,
        pro_reactive_stress_scale=0.80,
        pro_recovery_boost_confident=4.0,
        pro_recovery_boost_cautious=2.0,
        pro_calm_threshold_confident=10,
        pro_calm_threshold_cautious=5,
        pro_max_scale_change=0.3,
        pro_variance_window=20,
    ):
        
        

        if not 0.0 <= lr:
            raise ValueError(f"Invalid learning rate: {lr}")
        if not 0.0 <= eps:
            raise ValueError(f"Invalid epsilon value: {eps}")
        if not 0.0 <= betas[0] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 0: {betas[0]}")
        if not 0.0 <= betas[1] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 1: {betas[1]}")
        if not 0.0 <= weight_decay:
            raise ValueError(f"Invalid weight_decay value: {weight_decay}")
        if not 0.0 < ema_decay < 1.0:
            raise ValueError(f"Invalid ema_decay value: {ema_decay}")
            
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        super().__init__(params, defaults)

        # Store public knobs
        self.auto_enabled = auto_enabled
        self.stress_threshold = stress_threshold
        self.spike_threshold = spike_threshold
        self.min_scale = min_scale
        self.recovery_fast = recovery_fast
        self.use_max_rms = use_max_rms
        self.stats_freq = stats_freq
        self.ema_decay = ema_decay
        
        # Centralized edition/license enforcement is handled by lbw_lic.
        # Keeping this as a single call makes it easy to swap in compiled
        # entitlement logic (`lbw_lic.so` / `lbw_lic.pyd`) for product builds.
        license_ctx = build_license_context(mode=mode, license_key=license_key)
        self.edition = license_ctx.edition
        self.mode = license_ctx.runtime_mode
        self._pro_reflex = None  # Runtime handle for Guard Pro binary bridge
        self._license_meta = dict(license_ctx.license_meta)
        self._visible_gpu_count = int(license_ctx.visible_gpu_count)

        # Store Pro parameters
        self.pro_params = {
            "history_window": pro_history_window,
            "oscillation_threshold": pro_oscillation_threshold,
            "instability_threshold": pro_instability_threshold,
            "variance_threshold": pro_variance_threshold,
            "nuclear_scale": pro_nuclear_scale,
            "persistent_scale": pro_persistent_scale,
            "reactive_spike_scale": pro_reactive_spike_scale,
            "reactive_stress_scale": pro_reactive_stress_scale,
            "recovery_boost_confident": pro_recovery_boost_confident,
            "recovery_boost_cautious": pro_recovery_boost_cautious,
            "calm_threshold_confident": pro_calm_threshold_confident,
            "calm_threshold_cautious": pro_calm_threshold_cautious,
            "max_scale_change": pro_max_scale_change,
            "variance_window": pro_variance_window,
        }

        # =========================================================================
        # THE BRIDGE: Try to load the Commercial Binary
        # =========================================================================
        if self.mode == "pro":
            try:
                from .pro import ProReflexEngine
                
                # Initialize with custom parameters
                self._pro_reflex = ProReflexEngine(license_key, **self.pro_params)
                print("[Learn-By-Wire Guard] Pro Module Loaded. Advanced Reflex ACTIVE.")
            except ImportError:
                print("[WARNING] lbw_guard_pro bridge not found. Reverting to Eval Mode.")
                self.edition = "lbw_guard_eval"
                self.mode = "eval"
                self._enforce_ce_gpu_limit()
            except Exception as e:
                print(f"[WARNING] Pro Module Error: {e}. Reverting to Eval Mode.")
                self.edition = "lbw_guard_eval"
                self.mode = "eval"
                self._enforce_ce_gpu_limit()

        # Internal State
        self._step = 0
        self._scale = 1.0
        self._ema_grad_rms = None
        self._prev_weighted_sign = None
        self._stress_mode = "calm"
        self._last_grad_rms = 0.0
        self._last_ratio = 1.0

    # =========================================================================
    # EDITION + LICENSE HELPERS
    # =========================================================================
    @staticmethod
    def se_expiry_from_now(days: int) -> int:
        """Compatibility wrapper around `lbw_lic.se_expiry_from_now`."""
        return _se_expiry_from_now(days)

    @staticmethod
    def build_se_license_key(max_gpus: int, expiry: int | None = None, *, as_json: bool = False) -> str:
        """Compatibility wrapper around `lbw_lic.build_se_license_key`."""
        return _build_se_license_key(max_gpus=max_gpus, expiry=expiry, as_json=as_json)

    @staticmethod
    def _resolve_mode(mode):
        """Compatibility wrapper around `lbw_lic.resolve_mode`."""
        return _resolve_mode_alias(mode)

    @staticmethod
    def _get_visible_gpu_count():
        """Compatibility wrapper around `lbw_lic.get_visible_gpu_count`."""
        return _get_visible_gpu_count()

    def _enforce_ce_gpu_limit(self):
        """Compatibility wrapper around `lbw_lic.enforce_ce_gpu_limit`."""
        _enforce_ce_gpu_limit(self._visible_gpu_count)

    def _enforce_se_gpu_limit(self, max_gpus):
        """Compatibility wrapper around `lbw_lic.enforce_se_gpu_limit`."""
        _enforce_se_gpu_limit(self._visible_gpu_count, max_gpus)

    @staticmethod
    def _coerce_positive_int(value, field_name):
        """Compatibility wrapper around `lbw_lic.coerce_positive_int`."""
        return _coerce_positive_int(value, field_name)

    def _parse_se_license(self, license_key):
        """Compatibility wrapper around `lbw_lic.parse_se_license`."""
        return _parse_se_license(license_key)

    @torch.no_grad()
    def step(self, closure=None):
        """
        Performs a single optimization step.
        
        Args:
            closure: A closure that reevaluates the model and returns the loss (optional)
            
        Returns:
            The loss value if closure is provided, None otherwise
        """
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        self._step += 1

        # --- SENSOR ---
        should_collect_stats = (self._step == 1 or self._step % self.stats_freq == 0)
        grad_rms, weighted_sign_avg = 0.0, 0.0
        if self.auto_enabled and should_collect_stats:
            grad_rms, weighted_sign_avg = self._sensor_collect_telemetry()

        # --- ANALYZER ---
        ratio, sign_flip = self._analyzer_interpret_stress(grad_rms, weighted_sign_avg, should_collect_stats)

        # --- CONTROLLER ---
        if self.auto_enabled and should_collect_stats:
            # DELEGATE TO THE APPROPRIATE LOGIC
            if self.mode == "pro" and self._pro_reflex is not None:
                # === THE HOOK ===
                # Ask the HIDDEN BINARY to calculate the scale.
                # The user cannot see the logic inside `calculate_scale`.
                self._scale = self._pro_reflex.calculate_scale(
                    ratio, 
                    sign_flip, 
                    self._scale, 
                    self.min_scale,
                    self.spike_threshold,
                    self.stress_threshold,
                    self.recovery_fast
                )
                # Update mode string for telemetry based on hidden state
                self._stress_mode = "pro_managed" 
            else:
                # === COMMUNITY LOGIC (Visible) ===
                self._eval_decide_scale(ratio, sign_flip)
        
        update_scale = self._scale

        # --- ACTUATOR ---
        self._actuator_execute_update(update_scale)

        # --- TELEMETRY ---
        if should_collect_stats:
            self._last_grad_rms = float(grad_rms)
            self._last_ratio = float(ratio)
        
        # Store telemetry in state dict for user inspection
        telemetry = {
            "step": int(self._step),
            "mode": self.mode,
            "edition": self.edition,
            "stress_mode": self._stress_mode,
            "scale": float(self._scale),
            "grad_rms": float(self._last_grad_rms),
            "ratio": float(self._last_ratio),
            "visible_gpu_count": int(self._visible_gpu_count),
        }
        if self.edition == "lbw_guard_std":
            telemetry["licensed_max_gpus"] = int(self._license_meta.get("max_gpus", 0))
        self.state["lbw"] = telemetry

        return loss

    # =========================================================================
    # VISIBLE CONTROLLER (Eval Logic)
    # =========================================================================
    def _eval_decide_scale(self, ratio, sign_flip):
        """
        Standard Stateless Reflex.
        Visible to everyone in the BSL code.
        
        Decision tree:
        1. If ratio > spike_threshold: Aggressive dampening (0.7x)
        2. If ratio > stress_threshold OR sign_flip: Moderate dampening (0.85x)
        3. Otherwise: Gradual recovery (+recovery_fast)
        
        Args:
            ratio: Current gradient RMS / EMA gradient RMS
            sign_flip: Whether gradient direction reversed
        """
        is_spike = (ratio > self.spike_threshold)
        is_stress = (ratio > self.stress_threshold or sign_flip)

        if is_spike:
            self._stress_mode = "spike"
            self._scale = max(self.min_scale, self._scale * 0.7)
        elif is_stress:
            self._stress_mode = "oscillation"
            self._scale = max(self.min_scale, self._scale * 0.85)
        else:
            self._stress_mode = "calm"
            self._scale = min(1.0, self._scale + self.recovery_fast)

    # =========================================================================
    # SENSOR, ANALYZER, ACTUATOR (Standard Implementations)
    # =========================================================================
    def _sensor_collect_telemetry(self):
        """
        Collect gradient statistics across all parameters.
        
        Measures:
        - grad_rms: Root mean square of gradients (max or mean across layers)
        - weighted_sign_avg: Average signed gradient (for direction tracking)
        
        Returns:
            (grad_rms, weighted_sign_avg): Tuple of float values
        """
        layer_count = 0
        layer_rms_sum_t = None
        layer_rms_max_t = None
        weighted_sign_sum_t = None
        total_params = 0
        
        for group in self.param_groups:
            for p in group["params"]:
                if p.grad is None:
                    continue
                    
                g = p.grad
                
                # Calculate RMS per layer
                layer_rms = g.pow(2).mean()
                if layer_rms_sum_t is None:
                    layer_rms_sum_t = layer_rms
                    layer_rms_max_t = layer_rms
                else:
                    if layer_rms.device != layer_rms_sum_t.device:
                        layer_rms = layer_rms.to(layer_rms_sum_t.device, non_blocking=True)
                    layer_rms_sum_t = layer_rms_sum_t + layer_rms
                    layer_rms_max_t = torch.maximum(layer_rms_max_t, layer_rms)
                layer_count += 1
                
                # Calculate signed sum (FIXED: removed .abs())
                gsum = g.sum()
                if weighted_sign_sum_t is None:
                    weighted_sign_sum_t = gsum
                else:
                    if gsum.device != weighted_sign_sum_t.device:
                        gsum = gsum.to(weighted_sign_sum_t.device, non_blocking=True)
                    weighted_sign_sum_t = weighted_sign_sum_t + gsum
                total_params += p.numel()
        
        # Aggregate RMS across layers
        if layer_count > 0:
            if self.use_max_rms:
                grad_rms = float(layer_rms_max_t.item())
            else:
                grad_rms = float((layer_rms_sum_t / float(layer_count)).item())
        else:
            grad_rms = 0.0
        
        # Calculate average signed gradient
        if total_params > 0 and weighted_sign_sum_t is not None:
            weighted_sign_avg = float((weighted_sign_sum_t / float(total_params)).item())
        else:
            weighted_sign_avg = 0.0
        
        return grad_rms, weighted_sign_avg

    def _analyzer_interpret_stress(self, grad_rms, weighted_sign_avg, did_collect):
        """
        Interpret gradient statistics to detect stress conditions.
        
        Calculates:
        - ratio: Current gradient RMS relative to exponential moving average
        - sign_flip: Whether gradient direction has reversed
        
        Args:
            grad_rms: Current gradient RMS
            weighted_sign_avg: Current signed gradient average
            did_collect: Whether stats were collected this step
            
        Returns:
            (ratio, sign_flip): Tuple of (float, bool)
        """
        if not did_collect:
            return self._last_ratio, False
        
        # Update EMA of gradient RMS
        if self._ema_grad_rms is None:
            self._ema_grad_rms = grad_rms
        else:
            self._ema_grad_rms = (self.ema_decay * self._ema_grad_rms + 
                                  (1 - self.ema_decay) * grad_rms)
        
        # Calculate ratio (instability metric)
        ratio = grad_rms / (self._ema_grad_rms + 1e-12)
        
        # Detect sign flip (oscillation metric)
        sign_flip = False
        if self._prev_weighted_sign is not None:
            # Check if sign changed from positive to negative or vice versa
            if ((self._prev_weighted_sign > 0 and weighted_sign_avg < 0) or
                (self._prev_weighted_sign < 0 and weighted_sign_avg > 0)):
                sign_flip = True
        
        # Update sign history
        self._prev_weighted_sign = weighted_sign_avg
        
        return ratio, sign_flip

    def _actuator_execute_update(self, update_scale):
        """
        Execute parameter updates using fused AdamW algorithm.
        
        Applies:
        1. Weight decay
        2. First moment (momentum) update
        3. Second moment (variance) update
        4. Bias-corrected parameter update with scaled learning rate
        
        Args:
            update_scale: Multiplier for learning rate (from controller)
        """
        for group in self.param_groups:
            # Filter parameters with gradients
            params_with_grad = [p for p in group["params"] if p.grad is not None]
            if not params_with_grad:
                continue
            
            # ===================================================================
            # STEP 1: Initialize ALL param states FIRST (single pass)
            # ===================================================================
            for p in params_with_grad:
                state = self.state[p]
                if len(state) == 0:
                    state["step"] = 0  # Everyone starts at 0
                    state["exp_avg"] = torch.zeros_like(p)
                    state["exp_avg_sq"] = torch.zeros_like(p)
            
            # ===================================================================
            # STEP 2: Increment step counter (synchronized across all params)
            # ===================================================================
            for p in params_with_grad:
                self.state[p]["step"] += 1
            
            # ===================================================================
            # STEP 3: Get current step (all params now have same step)
            # ===================================================================
            current_step = self.state[params_with_grad[0]]["step"]
            
            # ===================================================================
            # STEP 4: Collect states (now guaranteed to exist)
            # ===================================================================
            grads = [p.grad for p in params_with_grad]
            exp_avgs = [self.state[p]["exp_avg"] for p in params_with_grad]
            exp_avg_sqs = [self.state[p]["exp_avg_sq"] for p in params_with_grad]
            
            # ===================================================================
            # STEP 5: Extract hyperparameters
            # ===================================================================
            beta1, beta2 = group["betas"]
            eps = group["eps"]
            wd = group["weight_decay"]
            lr = float(group["lr"]) * update_scale  # Apply adaptive scale

            # ===================================================================
            # STEP 6: Apply weight decay (decoupled)
            # ===================================================================
            if wd != 0:
                torch._foreach_mul_(params_with_grad, 1.0 - lr * wd)
            
            # ===================================================================
            # STEP 7: Update first moment (momentum)
            # ===================================================================
            torch._foreach_mul_(exp_avgs, beta1)
            torch._foreach_add_(exp_avgs, grads, alpha=1.0 - beta1)
            
            # ===================================================================
            # STEP 8: Update second moment (variance)
            # ===================================================================
            torch._foreach_mul_(exp_avg_sqs, beta2)
            torch._foreach_addcmul_(exp_avg_sqs, grads, grads, value=1.0 - beta2)

            # ===================================================================
            # STEP 9: Compute bias correction
            # ===================================================================
            bias_correction1 = 1.0 - beta1 ** current_step
            bias_correction2 = 1.0 - beta2 ** current_step
            step_size = lr * math.sqrt(bias_correction2) / bias_correction1

            # ===================================================================
            # STEP 10: Update parameters
            # ===================================================================
            # denom = sqrt(exp_avg_sq) + eps
            denom = torch._foreach_sqrt(exp_avg_sqs)
            torch._foreach_add_(denom, eps)
            
            # Convert to step_size for division
            torch._foreach_div_(denom, step_size)
            
            # params = params - step_size * exp_avg / denom
            torch._foreach_addcdiv_(params_with_grad, exp_avgs, denom, value=-1.0)
    
    def __repr__(self):
        return (f"LearnByWire(lr={self.defaults['lr']}, "
                f"betas={self.defaults['betas']}, "
                f"eps={self.defaults['eps']}, "
                f"weight_decay={self.defaults['weight_decay']}, "
                f"edition={self.edition}, "
                f"mode={self.mode}, "
                f"auto_enabled={self.auto_enabled})")
