"""
License gate primitives for Learn-By-Wire Guard editions.

This module is intentionally isolated from optimizer math so you can compile it
as a separate binary (`lbw_lic.so` / `lbw_lic.pyd`) and keep entitlement logic
centralized for Guard Eval, Guard Std, and Guard Pro flows.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import time
from dataclasses import dataclass
from typing import Any

import torch

_ALIAS_TO_EDITION = {
    "eval": "lbw_guard_eval",
    "evaluation": "lbw_guard_eval",
    "guard_eval": "lbw_guard_eval",
    "lbw_guard_eval": "lbw_guard_eval",
    "std": "lbw_guard_std",
    "standard": "lbw_guard_std",
    "guard_std": "lbw_guard_std",
    "lbw_guard_std": "lbw_guard_std",
    "pro": "lbw_guard_pro",
    "professional": "lbw_guard_pro",
    "guard_pro": "lbw_guard_pro",
    "lbw_guard_pro": "lbw_guard_pro",
}

_MAX_GPU_KEYS = ("max_gpus", "max_gpu", "gpu_limit", "gpus", "gpu")
_EXPIRY_KEYS = ("expiry", "expires", "exp", "valid_until", "until")
_SIGNED_TOKEN_PREFIX = "LBW-LIC-V1"
_LICENSE_ISSUER = "Learn-By-Wire Guard"
_RSA_SHA256_DIGESTINFO_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")

# Preferred production path: compile a generated `lbw_public_keys` module into
# the product package. This keeps public-key material outside the hand-edited
# runtime source and makes key rotation a build concern instead of a code edit.
try:
    from .public_keys import EMBEDDED_PUBLIC_KEYS as _GENERATED_PUBLIC_KEYS
except Exception:
    try:
        # Fallback for standalone module builds (non-package import path).
        from lbw_public_keys import EMBEDDED_PUBLIC_KEYS as _GENERATED_PUBLIC_KEYS
    except Exception:
        _GENERATED_PUBLIC_KEYS: dict[str, dict[str, Any]] = {}

# Static fallback registry. Leave this empty in normal workflows and let the
# build pipeline generate `lbw_public_keys` instead.
_EMBEDDED_PUBLIC_KEYS: dict[str, dict[str, Any]] = {}


@dataclass(frozen=True)
class LicenseContext:
    """Resolved runtime/license context used by the governor front-end."""

    edition: str
    runtime_mode: str
    visible_gpu_count: int
    license_meta: dict[str, Any]


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(text: str) -> bytes:
    raw = str(text).encode("ascii")
    remainder = len(raw) % 4
    if remainder != 0:
        raw = raw + (b"=" * (4 - remainder))
    return base64.urlsafe_b64decode(raw)


def _canonical_json(obj: dict[str, Any]) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _looks_like_signed_token(text: str) -> bool:
    return str(text).strip().startswith(f"{_SIGNED_TOKEN_PREFIX}.")


def looks_like_signed_license_token(license_key: Any) -> bool:
    """Return True when the input matches the signed LBW token envelope."""
    return _looks_like_signed_token(str(license_key).strip())


def _normalize_rsa_public_key(record: dict[str, Any]) -> dict[str, Any]:
    try:
        kid = str(record["kid"]).strip()
        n_raw = record["n"]
        e_raw = record.get("e", 65537)
    except KeyError as exc:
        raise ValueError(f"Invalid public key record: missing {exc.args[0]}") from exc

    n = int(str(n_raw), 0)
    e = int(str(e_raw), 0)
    if n < 3 or e < 3:
        raise ValueError("Invalid RSA public key values.")
    return {"kid": kid, "n": n, "e": e}


def _dev_public_keys_enabled() -> bool:
    return os.getenv("LBW_LICENSE_DEV_MODE", "").strip().lower() in {"1", "true", "yes", "on"}


def _load_dev_public_keys() -> dict[str, dict[str, Any]]:
    if not _dev_public_keys_enabled():
        return {}

    raw_json = os.getenv("LBW_LICENSE_PUBLIC_KEY_JSON", "").strip()
    key_file = os.getenv("LBW_LICENSE_PUBLIC_KEY_FILE", "").strip()

    if raw_json:
        obj = json.loads(raw_json)
    elif key_file:
        with open(key_file, "r", encoding="utf-8") as handle:
            obj = json.load(handle)
    else:
        return {}

    items = obj if isinstance(obj, list) else [obj]
    out: dict[str, dict[str, Any]] = {}
    for item in items:
        key = _normalize_rsa_public_key(dict(item))
        out[key["kid"]] = key
    return out


def _get_public_key_registry() -> dict[str, dict[str, Any]]:
    registry: dict[str, dict[str, Any]] = {}
    for key in _GENERATED_PUBLIC_KEYS.values():
        norm = _normalize_rsa_public_key(dict(key))
        registry[norm["kid"]] = norm
    for key in _EMBEDDED_PUBLIC_KEYS.values():
        norm = _normalize_rsa_public_key(dict(key))
        registry[norm["kid"]] = norm
    for key in _load_dev_public_keys().values():
        registry[key["kid"]] = key
    return registry


def _rsa_pkcs1v15_sha256_verify(n: int, e: int, message: bytes, signature: bytes) -> bool:
    if not signature:
        return False

    mod_len = (int(n).bit_length() + 7) // 8
    if len(signature) != mod_len:
        return False

    sig_int = int.from_bytes(signature, "big")
    if sig_int <= 0 or sig_int >= int(n):
        return False

    em = pow(sig_int, int(e), int(n)).to_bytes(mod_len, "big")
    digest = hashlib.sha256(message).digest()
    digest_info = _RSA_SHA256_DIGESTINFO_PREFIX + digest
    padding_len = mod_len - len(digest_info) - 3
    if padding_len < 8:
        return False
    expected = b"\x00\x01" + (b"\xff" * padding_len) + b"\x00" + digest_info
    return em == expected


def verify_signed_license_token(license_key: Any, *, expected_edition: str | None = None) -> dict[str, Any]:
    """
    Verify a signed license token and return its payload.

    Token format:
    `LBW-LIC-V1.<payload_b64url>.<signature_b64url>`
    """
    raw = str(license_key).strip()
    if not _looks_like_signed_token(raw):
        raise ValueError("Not a signed LBW license token.")

    try:
        prefix, payload_b64, sig_b64 = raw.split(".", 2)
    except ValueError as exc:
        raise ValueError("Malformed signed LBW license token.") from exc

    if prefix != _SIGNED_TOKEN_PREFIX:
        raise ValueError("Unsupported signed LBW token prefix.")

    payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Signed license payload must be a JSON object.")

    issuer = str(payload.get("iss", "")).strip()
    if issuer and issuer != _LICENSE_ISSUER:
        raise ValueError(f"Invalid license issuer: {issuer}")

    edition = str(payload.get("edition", "")).strip().lower()
    if not edition:
        raise ValueError("Signed license payload missing edition.")
    if expected_edition is not None and edition != str(expected_edition).strip().lower():
        raise ValueError(f"License edition mismatch: expected {expected_edition}, got {edition}.")

    kid = str(payload.get("kid", "")).strip()
    if not kid:
        raise ValueError("Signed license payload missing kid.")

    registry = _get_public_key_registry()
    if kid not in registry:
        raise ValueError(
            f"Unknown license key id: {kid}. "
            "Embed the matching public key or enable LBW_LICENSE_DEV_MODE for dev testing."
        )

    signature = _b64url_decode(sig_b64)
    signed_message = f"{prefix}.{payload_b64}".encode("ascii")
    key = registry[kid]
    if not _rsa_pkcs1v15_sha256_verify(int(key["n"]), int(key["e"]), signed_message, signature):
        raise ValueError("Signed license verification failed.")

    if "expiry" in payload and str(payload["expiry"]).strip():
        expiry = int(str(payload["expiry"]).strip())
        if int(time.time()) > expiry:
            raise ValueError(f"Signed license expired at unix timestamp {expiry}.")

    if "nbf" in payload and str(payload["nbf"]).strip():
        not_before = int(str(payload["nbf"]).strip())
        if int(time.time()) < not_before:
            raise ValueError(f"Signed license not active before unix timestamp {not_before}.")

    return payload


def resolve_mode(mode: str | None) -> tuple[str, str]:
    """Resolve user-facing mode aliases to canonical edition + runtime mode."""
    raw = str(mode or "eval").strip().lower()
    if raw not in _ALIAS_TO_EDITION:
        raise ValueError(
            f"Invalid mode: {mode}. Use one of: lbw_guard_eval, lbw_guard_std, "
            "lbw_guard_pro (aliases: eval, std, pro)."
        )
    edition = _ALIAS_TO_EDITION[raw]
    if edition == "lbw_guard_pro":
        runtime_mode = "pro"
    elif edition == "lbw_guard_std":
        runtime_mode = "std"
    else:
        runtime_mode = "eval"
    return edition, runtime_mode


def get_visible_gpu_count() -> int:
    """Return visible CUDA device count after environment masking."""
    try:
        if torch.cuda.is_available():
            return int(torch.cuda.device_count())
    except Exception:
        pass
    return 0


def coerce_positive_int(value: Any, field_name: str) -> int:
    """Parse/validate integer entitlement fields."""
    try:
        iv = int(value)
    except Exception as exc:
        raise ValueError(f"Invalid {field_name}: {value}") from exc
    if iv < 1:
        raise ValueError(f"{field_name} must be >= 1, got {iv}.")
    return iv


def enforce_ce_gpu_limit(visible_gpu_count: int) -> None:
    """Guard Eval edition gate: at most one visible GPU."""
    if int(visible_gpu_count) > 1:
        raise ValueError(
            f"lbw_guard_eval supports at most 1 visible GPU; detected {int(visible_gpu_count)}. "
            "Use lbw_guard_std/lbw_guard_pro or restrict CUDA_VISIBLE_DEVICES to one GPU."
        )


def enforce_se_gpu_limit(visible_gpu_count: int, max_gpus: int) -> None:
    """Guard Std edition gate: visible GPUs must not exceed entitlement."""
    if int(visible_gpu_count) > int(max_gpus):
        raise ValueError(
            f"lbw_guard_std license allows up to {int(max_gpus)} visible GPU(s), "
            f"but detected {int(visible_gpu_count)}."
        )


def parse_se_license(license_key: Any) -> dict[str, int | None]:
    """
    Parse Guard Std license payload and return normalized entitlement metadata.

    Accepted inputs:
    - dict: {"max_gpus": 4, "expiry": 1893456000}
    - key/value string: "max_gpus=4;expiry=1893456000"
    - compact token: "LBW-GUARD-STD-V1-4-1893456000"
    """
    if license_key is None:
        raise ValueError("lbw_guard_std requires a license_key that includes GPU entitlement.")

    raw_key = str(license_key).strip()
    if _looks_like_signed_token(raw_key):
        payload = verify_signed_license_token(raw_key, expected_edition="lbw_guard_std")
        max_gpus = coerce_positive_int(payload.get("max_gpus"), "license max_gpus")
        expiry = payload.get("expiry")
        if expiry is not None:
            expiry = int(str(expiry).strip())
        return {
            "max_gpus": int(max_gpus),
            "expiry": expiry,
            "customer": payload.get("customer"),
            "features": payload.get("features", []),
            "kid": payload.get("kid"),
            "signed": True,
        }

    payload: dict[str, Any] = {}
    raw_text = ""

    if isinstance(license_key, dict):
        payload = {str(k).strip().lower(): v for k, v in license_key.items()}
    else:
        raw_text = str(license_key).strip()
        if not raw_text:
            raise ValueError("lbw_guard_std license_key is empty.")

        if raw_text.startswith("{") and raw_text.endswith("}"):
            try:
                obj = json.loads(raw_text)
                if isinstance(obj, dict):
                    payload = {str(k).strip().lower(): v for k, v in obj.items()}
            except Exception:
                payload = {}

        if not payload:
            for part in re.split(r"[;,\|]", raw_text):
                token = part.strip()
                if not token:
                    continue
                sep = "=" if "=" in token else (":" if ":" in token else None)
                if sep is None:
                    continue
                k, v = token.split(sep, 1)
                payload[k.strip().lower()] = v.strip()

        if not payload:
            match = re.search(
                r"lbw[-_ ]?guard[-_ ]?std[-_ ]?v\d+[-_: ]+(\d+)(?:[-_: ]+(\d+))?",
                raw_text,
                flags=re.I,
            )
            if match:
                payload["max_gpus"] = match.group(1)
                if match.group(2) is not None:
                    payload["expiry"] = match.group(2)

    max_gpus = None
    for key in _MAX_GPU_KEYS:
        if key in payload:
            max_gpus = coerce_positive_int(payload[key], "license max_gpus")
            break

    if max_gpus is None and raw_text:
        match = re.search(
            r"(?:max[_-]?gpu(?:s)?|gpu[_-]?limit|gpus?)\s*[:=]\s*(\d+)",
            raw_text,
            flags=re.I,
        )
        if match:
            max_gpus = coerce_positive_int(match.group(1), "license max_gpus")

    if max_gpus is None:
        raise ValueError(
            "Invalid lbw_guard_std license_key: missing GPU entitlement. "
            "Provide max_gpus (e.g. 'max_gpus=4;expiry=1893456000')."
        )

    expiry = None
    for key in _EXPIRY_KEYS:
        if key in payload and str(payload[key]).strip():
            try:
                expiry = int(str(payload[key]).strip())
            except Exception as exc:
                raise ValueError(f"Invalid license expiry value: {payload[key]}") from exc
            break

    if expiry is not None and int(time.time()) > expiry:
        raise ValueError(f"lbw_guard_std license expired at unix timestamp {expiry}.")

    return {"max_gpus": int(max_gpus), "expiry": expiry, "signed": False}


def build_license_context(mode: str | None, license_key: Any) -> LicenseContext:
    """Resolve mode and enforce edition entitlements in one place."""
    edition, runtime_mode = resolve_mode(mode)
    visible_gpu_count = get_visible_gpu_count()
    license_meta: dict[str, Any] = {}

    if edition == "lbw_guard_eval":
        enforce_ce_gpu_limit(visible_gpu_count)
    elif edition == "lbw_guard_std":
        license_meta = parse_se_license(license_key)
        enforce_se_gpu_limit(visible_gpu_count, int(license_meta["max_gpus"]))

    return LicenseContext(
        edition=edition,
        runtime_mode=runtime_mode,
        visible_gpu_count=int(visible_gpu_count),
        license_meta=license_meta,
    )


def se_expiry_from_now(days: int) -> int:
    """Return UNIX timestamp for `days` from now."""
    try:
        d = int(days)
    except Exception as exc:
        raise ValueError(f"Invalid days value: {days}") from exc
    if d < 1:
        raise ValueError(f"days must be >= 1, got {d}.")
    return int(time.time()) + d * 24 * 60 * 60


def build_se_license_key(max_gpus: int, expiry: int | None = None, *, as_json: bool = False) -> str:
    """
    Build a simple Guard Std payload string compatible with `parse_se_license`.

    This helper is for local/dev usage. Production deployments should issue
    signed licenses server-side and verify signatures in binary code.
    """
    mg = int(max_gpus)
    if mg < 1:
        raise ValueError(f"max_gpus must be >= 1, got {mg}.")

    if expiry is not None:
        expiry = int(expiry)
        if expiry < 1:
            raise ValueError(f"expiry must be a positive UNIX timestamp, got {expiry}.")

    if as_json:
        payload: dict[str, Any] = {"max_gpus": mg}
        if expiry is not None:
            payload["expiry"] = expiry
        return json.dumps(payload, separators=(",", ":"))

    if expiry is None:
        return f"max_gpus={mg}"
    return f"max_gpus={mg};expiry={expiry}"


__all__ = [
    "LicenseContext",
    "build_license_context",
    "build_se_license_key",
    "coerce_positive_int",
    "enforce_ce_gpu_limit",
    "enforce_se_gpu_limit",
    "get_visible_gpu_count",
    "looks_like_signed_license_token",
    "verify_signed_license_token",
    "parse_se_license",
    "resolve_mode",
    "se_expiry_from_now",
]
