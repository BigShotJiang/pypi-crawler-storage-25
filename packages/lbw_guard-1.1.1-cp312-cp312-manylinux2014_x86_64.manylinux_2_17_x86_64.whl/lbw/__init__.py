"""
Packaged Learn-By-Wire Guard runtime.
"""

from .governor import LearnByWire

Guard = LearnByWire

__all__ = ["Guard", "LearnByWire"]
