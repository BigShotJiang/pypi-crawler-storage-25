from __future__ import annotations

GROQ_BASE_URL = "https://api.groq.com/openai/v1"
TRANSCRIPTION_MODEL = "whisper-large-v3"
CLEANUP_MODEL = "openai/gpt-oss-20b"
CLEANUP_FALLBACK_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"
TRANSCRIPTION_LANGUAGE = ""
CLEANUP_ENABLED = True
