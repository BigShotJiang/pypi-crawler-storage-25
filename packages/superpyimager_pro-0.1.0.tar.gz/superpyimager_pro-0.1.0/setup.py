"""
===========================================================
               SUPERPYIMAGER - SETUP CONFIGURATION
===========================================================
Author: Hamit Furkan (Hfd)
Description: Complete setup configuration for compiling and
             distributing the SuperPyImager package.
===========================================================
"""

from setuptools import setup, find_packages

setup(
    name="superpyimager-pro",
    version="0.1.0",
    author="Hamit Furkan (Hfd)",
    description="An advanced image processing engine and ready-to-use GUI framework.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.8",
    install_requires=[
        "customtkinter",
        "opencv-python",
        "numpy",
        "matplotlib",
        "pillow"
    ],
    keywords=[
        "image processing",
        "opencv",
        "customtkinter",
        "gui framework",
        "computer vision",
        "histogram",
        "data analytics"
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Multimedia :: Graphics",
        "Topic :: Software Development :: User Interfaces",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)