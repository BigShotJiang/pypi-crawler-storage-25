"""
Defines the grayscale conversion utility for SuperPyImager.
"""

import cv2

def convert_to_grayscale(image_rgb):
    """
    Converts an RGB image array into a single-channel grayscale image.
    """
    if image_rgb is None:
        return None
    return cv2.cvtColor(image_rgb, cv2.COLOR_RGB2GRAY)