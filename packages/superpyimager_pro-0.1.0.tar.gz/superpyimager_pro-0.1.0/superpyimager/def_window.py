"""
Defines the main application window creation utility using CustomTkinter.
"""

import customtkinter as ctk


def create_main_window(title, geometry):
    """
    Initializes and returns a customized CustomTkinter root window with dark mode enabled.
    """
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")

    root = ctk.CTk()
    root.title(title)
    root.geometry(geometry)
    return root