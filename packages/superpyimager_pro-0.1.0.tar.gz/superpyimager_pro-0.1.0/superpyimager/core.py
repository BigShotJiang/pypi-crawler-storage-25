"""
===========================================================
               SUPERPYIMAGER - CORE ENGINE & GUI
===========================================================
Author: Hamit Furkan (Hfd)
Description: The central engine containing both the image
             processing core and the GUI framework classes.
===========================================================
"""

import cv2
import customtkinter as ctk

# Importing processing functions
from superpyimager.def_grayscale import convert_to_grayscale
from superpyimager.def_histogram import generate_histogram

# Importing GUI functions
from superpyimager.def_window import create_main_window
from superpyimager.def_widgets import create_action_button, create_image_display_area


class SuperPyImagerCore:
    """Handles all heavy lifting for image manipulation and data analytics."""

    def __init__(self, image_path):
        self.original = cv2.imread(image_path)
        self.image = cv2.cvtColor(self.original, cv2.COLOR_BGR2RGB)

    def to_grayscale(self):
        return convert_to_grayscale(self.image)

    def get_histogram(self):
        return generate_histogram(self.image)


class SuperPyImagerGUI:
    """The interface framework that users can spin up instantly."""

    def __init__(self, title="SuperPyImager App", size="1000x600"):
        self.root = create_main_window(title, size)

        # Setup view zone (left) and control panel (right)
        self.view_frame, self.img_label, self.graph_frame = create_image_display_area(self.root)
        self.view_frame.pack(side="left", fill="both", expand=True, padx=15, pady=15)

        self.control_frame = ctk.CTkFrame(self.root, width=220)
        self.control_frame.pack(side="right", fill="y", padx=15, pady=15)

        self.menu_title = ctk.CTkLabel(self.control_frame, text="CONTROL PANEL", font=("Helvetica", 14, "bold"))
        self.menu_title.pack(pady=15)

    def add_button(self, text, command):
        """Allows developers to inject a button with a single line of code."""
        btn = create_action_button(self.control_frame, text, command)
        btn.pack(pady=8, padx=15, fill="x")
        return btn

    def run(self):
        """Starts the window's main loop execution."""
        self.root.mainloop()