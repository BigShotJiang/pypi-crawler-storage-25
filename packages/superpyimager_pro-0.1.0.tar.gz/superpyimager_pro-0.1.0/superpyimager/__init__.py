"""
===========================================================
                SUPERPYIMAGER LIBRARY
===========================================================
Author: Hamit Furkan
Project: SuperPyImager Ecosystem
Version: 0.1.0
All Rights Reserved (C)
===========================================================
"""

# Pulling both systems directly out of core.py
from superpyimager.core import SuperPyImagerCore, SuperPyImagerGUI

# Convenient aliases for the end-user
Core = SuperPyImagerCore
App = SuperPyImagerGUI