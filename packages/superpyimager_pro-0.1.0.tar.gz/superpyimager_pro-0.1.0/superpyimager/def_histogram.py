"""
Defines the color histogram generation utility using Matplotlib with GUI theme matching.
"""

import cv2
import matplotlib.pyplot as plt


def generate_histogram(image_rgb):
    """
    Generates an RGB color distribution histogram as a Matplotlib figure.
    The background is set to match the CustomTkinter dark theme frame color.
    """
    if image_rgb is None:
        return None

    # CustomTkinter frame'lerinin koyu gri rengi tam olarak #2B2B2B veya #212121 civarıdır.
    # Şeffaf yapmak yerine arka plan rengini el ile vererek beyaz kalmasını engelliyoruz.
    gui_dark_color = "#2B2B2B"

    fig, ax = plt.subplots(figsize=(4, 3), facecolor=gui_dark_color)
    ax.set_facecolor(gui_dark_color)

    colors = ('r', 'g', 'b')
    for i, col in enumerate(colors):
        hist = cv2.calcHist([image_rgb], [i], None, [256], [0, 256])
        ax.plot(hist, color=col, linewidth=2)

    # Yazıları ve çizgileri görünür kılmak için beyaz yapıyoruz
    ax.set_title("Color Distribution", color="white", fontsize=10, pad=10)
    ax.tick_params(colors='white', labelsize=8)

    # Grafik kenarlıklarını beyaz (veya hafif gri) yapalım
    for spine in ax.spines.values():
        spine.set_color('#555555')

    # Izgara (Grid) ekleyelim, daha teknik ve şık dursun
    ax.grid(True, color="#444444", linestyle="--", linewidth=0.5)

    plt.tight_layout()
    return fig