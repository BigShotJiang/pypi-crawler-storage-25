"""
Defines reusable GUI widget building components for SuperPyImager.
"""

import customtkinter as ctk


def create_action_button(master, text, command):
    """
    Creates and returns a stylized CustomTkinter button with rounded corners.
    """
    return ctk.CTkButton(
        master=master,
        text=text,
        command=command,
        corner_radius=8,
        font=("Helvetica", 12, "bold")
    )


def create_image_display_area(master):
    """
    Constructs the layout frames for both the image preview area and the histogram container.
    """
    main_frame = ctk.CTkFrame(master=master, corner_radius=10)

    # Image display preview label
    img_label = ctk.CTkLabel(main_frame, text="Click button to load an image", font=("Helvetica", 13))
    img_label.pack(side="left", expand=True, fill="both", padx=10, pady=10)

    # Placeholder frame dedicated to mounting the Matplotlib canvas
    graph_frame = ctk.CTkFrame(main_frame, width=300, fg_color="transparent")
    graph_frame.pack(side="right", fill="both", padx=10, pady=10)

    return main_frame, img_label, graph_frame