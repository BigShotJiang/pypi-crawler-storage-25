# SuperPyImager Pro

An advanced, high-performance image processing engine combined with an instant, ready-to-use modern GUI framework. Built entirely on top of OpenCV, NumPy, Matplotlib, and CustomTkinter.

## Features
- **Consolidated Core:** Single-entry core architecture (`core.py`) managing both image processing and interface systems.
- **Image Analytics:** Instant RGB color distribution histograms integrated via Matplotlib.
- **Modern UI Framework:** Fully-customizable dark-mode GUI components powered by CustomTkinter.

## Installation
pip install superpyimager-pro
## Quick Start
Python
import superpyimager as spi

# Launch the built-in GUI framework instantly
app = spi.App(title="SuperPyImager Studio", size="1000x600")

# Inject a custom action button into the control panel
app.add_button("Process Image", command=lambda: print("Processing..."))

# Run the application
app.run()