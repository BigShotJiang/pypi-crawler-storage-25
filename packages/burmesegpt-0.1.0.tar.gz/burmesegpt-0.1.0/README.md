# burmesegpt

`burmesegpt` is a Burmese-first local runtime for Padauk GGUF models with OpenAI-compatible `/v1` API workflows.
It helps you download verified model artifacts, serve them locally, and run quick CLI chat sessions.

## Install

```bash
# Core package (download + info workflows)
pip install burmesegpt

# Include local server runtime for `serve` and local `run`
pip install "burmesegpt[server]"
```

> `download` and `info` work with core install. `serve` and `run` (without `--base-url`) require `burmesegpt[server]`.

## Quickstart

### Fast smoke test (no model download)

```bash
pip install "burmesegpt[server]"
burmesegpt serve --test-mode --port 8000
```

```bash
curl http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"model":"padauk-agent","messages":[{"role":"user","content":"hello"}]}'
```

### Real model run

```bash
burmesegpt download --quant q8_0
burmesegpt serve --quant q8_0 --host 127.0.0.1 --port 8000
```

## OpenAI-compatible Python example

```python
from openai import OpenAI

client = OpenAI(base_url="http://127.0.0.1:8000/v1", api_key="sk-no-key-required")
response = client.chat.completions.create(
    model="padauk-agent",
    messages=[{"role": "user", "content": "Give me a short Burmese greeting."}],
)
print(response.choices[0].message.content)
```

## CLI commands

- `burmesegpt download` — download and checksum-verify a quantized GGUF artifact.
- `burmesegpt serve` — start a local OpenAI-compatible API server.
- `burmesegpt run` — interactive chat (boots local server or uses `--base-url`).
- `burmesegpt info` — print package/model configuration as JSON.

Useful options:
- `--quant`: `q4_k_m` (default), `q5_k_m`, `q8_0`
- `--repo-id`, `--revision`, `--cache-dir`, `--hf-token` (or `HF_TOKEN`)

## Docs

- Documentation index: [docs/README.md](https://github.com/WaiYanNyeinNaing/burmese-gpt-pypi-api/blob/main/docs/README.md)
- HF to GGUF quantization guide: [docs/guides/hf-to-gguf-quantization-guide.md](https://github.com/WaiYanNyeinNaing/burmese-gpt-pypi-api/blob/main/docs/guides/hf-to-gguf-quantization-guide.md)
- PyPI release guide: [docs/guides/pypi-release-guide.md](https://github.com/WaiYanNyeinNaing/burmese-gpt-pypi-api/blob/main/docs/guides/pypi-release-guide.md)

## Release notes

- Published release history: [https://pypi.org/project/burmesegpt/#history](https://pypi.org/project/burmesegpt/#history)
- Current package version source: `pyproject.toml` (`[project].version`)
