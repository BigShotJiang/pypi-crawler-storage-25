from __future__ import annotations

import argparse
import json
import sys

from .agent import chat_completion, padauk_agent, wait_for_server
from .manifest import DEFAULT_QUANT, DEFAULT_REPO_ID, QUANT_FILENAMES


EXIT_COMMANDS = {"/exit", "/quit", "exit", "quit"}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="burmesegpt",
        description="Run Padauk Burmese GGUF models with easy local OpenAI-compatible workflows.",
    )

    parser.add_argument("--repo-id", default=DEFAULT_REPO_ID, help="Hugging Face model repo id")
    parser.add_argument("--revision", default=None, help="Optional HF revision/tag/commit")
    parser.add_argument("--cache-dir", default=None, help="Model cache root (default ~/.cache/burmesegpt/models)")
    parser.add_argument("--hf-token", default=None, help="HF token (takes precedence over HF_TOKEN)")

    subparsers = parser.add_subparsers(dest="command", required=True)

    quant_choices = sorted(QUANT_FILENAMES)

    download_parser = subparsers.add_parser("download", help="Download and verify model files")
    download_parser.add_argument("--quant", choices=quant_choices, default=DEFAULT_QUANT)
    download_parser.set_defaults(func=cmd_download)

    serve_parser = subparsers.add_parser("serve", help="Start OpenAI-compatible local API server")
    serve_parser.add_argument("--quant", choices=quant_choices, default=DEFAULT_QUANT)
    serve_parser.add_argument("--host", default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=8000)
    serve_parser.add_argument("--model-alias", default="padauk-agent")
    serve_parser.add_argument("--n-ctx", type=int, default=8192)
    serve_parser.add_argument("--n-gpu-layers", type=int, default=-1)
    serve_parser.add_argument("--api-key", default="sk-no-key-required")
    serve_parser.add_argument("--test-mode", action="store_true", help=argparse.SUPPRESS)
    serve_parser.set_defaults(func=cmd_serve)

    run_parser = subparsers.add_parser("run", help="Interactive quick chat")
    run_parser.add_argument("--quant", choices=quant_choices, default=DEFAULT_QUANT)
    run_parser.add_argument("--host", default="127.0.0.1")
    run_parser.add_argument("--port", type=int, default=8000)
    run_parser.add_argument("--model-alias", default="padauk-agent")
    run_parser.add_argument("--n-ctx", type=int, default=8192)
    run_parser.add_argument("--n-gpu-layers", type=int, default=-1)
    run_parser.add_argument("--api-key", default="sk-no-key-required")
    run_parser.add_argument("--startup-timeout", type=float, default=30.0)
    run_parser.add_argument(
        "--base-url",
        default=None,
        help="Use an already running OpenAI-compatible endpoint (e.g. http://127.0.0.1:8000/v1)",
    )
    run_parser.add_argument("--test-mode", action="store_true", help=argparse.SUPPRESS)
    run_parser.set_defaults(func=cmd_run)

    info_parser = subparsers.add_parser("info", help="Show package/model configuration")
    info_parser.add_argument("--quant", choices=quant_choices, default=DEFAULT_QUANT)
    info_parser.set_defaults(func=cmd_info)

    return parser


def _make_agent(args: argparse.Namespace):
    return padauk_agent(
        quant=getattr(args, "quant", DEFAULT_QUANT),
        repo_id=args.repo_id,
        revision=args.revision,
        cache_dir=args.cache_dir,
        hf_token=args.hf_token,
    )


def cmd_download(args: argparse.Namespace) -> int:
    agent = _make_agent(args)
    model_path = agent.ensure_model()
    print(f"Model ready: {model_path}")
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    agent = _make_agent(args)
    print(
        f"Starting server for quant={args.quant} at http://{args.host}:{args.port}/v1 "
        f"(model_alias={args.model_alias})"
    )
    agent.serve(
        host=args.host,
        port=args.port,
        model_alias=args.model_alias,
        n_ctx=args.n_ctx,
        n_gpu_layers=args.n_gpu_layers,
        api_key=args.api_key,
        wait=True,
        test_mode=args.test_mode,
    )
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    agent = _make_agent(args)
    process = None

    if args.base_url:
        base_url = args.base_url.rstrip("/")
    else:
        process = agent.serve(
            host=args.host,
            port=args.port,
            model_alias=args.model_alias,
            n_ctx=args.n_ctx,
            n_gpu_layers=args.n_gpu_layers,
            api_key=args.api_key,
            wait=False,
            test_mode=args.test_mode,
        )
        base_url = agent.openai_base_url
        wait_for_server(base_url, timeout=args.startup_timeout)

    print("Interactive chat ready. Type '/exit' to stop.")
    messages: list[dict[str, str]] = []

    try:
        while True:
            user_text = input("you> ").strip()
            if not user_text:
                continue
            if user_text.lower() in EXIT_COMMANDS:
                break

            messages.append({"role": "user", "content": user_text})
            reply = chat_completion(
                base_url=base_url,
                model=args.model_alias,
                messages=messages,
                api_key=args.api_key,
            )
            print(f"padauk> {reply}")
            messages.append({"role": "assistant", "content": reply})
    finally:
        if process is not None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except Exception:
                process.kill()

    return 0


def cmd_info(args: argparse.Namespace) -> int:
    agent = _make_agent(args)
    payload = {
        "repo_id": agent.repo_id,
        "revision": agent.revision,
        "quant": agent.quant,
        "filename": agent.model_filename,
        "cache_dir": str(agent.cache_dir),
        "model_path": str(agent.model_path),
        "openai_base_url": agent.openai_base_url,
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
