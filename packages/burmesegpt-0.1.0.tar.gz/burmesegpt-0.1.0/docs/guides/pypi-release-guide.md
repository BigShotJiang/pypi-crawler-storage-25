# PyPI Release Guide (Manual)

Compact release checklist for `burmesegpt` maintainers.

## 1) Prerequisites

- Python packaging tools:

```bash
python -m pip install --upgrade build twine
```

- PyPI account (and TestPyPI account if using staging first).
- Bump `version` in `pyproject.toml` before building.

## 2) Clean and Build

```bash
rm -rf dist build *.egg-info
python -m build
```

Expected output: both `dist/*.tar.gz` (sdist) and `dist/*.whl` (wheel).

## 3) Validate Package Metadata

```bash
twine check dist/*
```

Fix any rendering or metadata errors before upload.

## 4) Token Setup (Twine)

Create API tokens in:
- TestPyPI: <https://test.pypi.org/manage/account/token/>
- PyPI: <https://pypi.org/manage/account/token/>

Set credentials in shell:

```bash
export TWINE_USERNAME="__token__"
export TWINE_PASSWORD="pypi-<your-token>"
```

For TestPyPI, replace `TWINE_PASSWORD` with your `pypi-...` TestPyPI token.

## 5) Optional: TestPyPI First

Upload:

```bash
twine upload --repository-url https://test.pypi.org/legacy/ dist/*
```

Install smoke test:

```bash
python -m pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple burmesegpt
python -m pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple "burmesegpt[server]"
burmesegpt info
```

## 6) Upload to PyPI

```bash
twine upload dist/*
```

Then verify:
- <https://pypi.org/project/burmesegpt/>
- install works for `burmesegpt` and `burmesegpt[server]`
- key CLI paths (`download`, `serve`, `run`, `info`) still work

## 7) Trusted Publishing (Recommended)

Manual `twine` uploads rely on long-lived API tokens.  
Trusted Publishing lets CI (for example, GitHub Actions) publish via short-lived OIDC credentials without storing PyPI tokens.

If you automate releases later, configure a trusted publisher in PyPI and keep `twine` as a local fallback.

### GitHub Trusted Publisher fields (PyPI Pending Publisher)

For this repo/workflow (`.github/workflows/publish-pypi.yml`), use:

- Owner: `WaiYanNyeinNaing`
- Repository name: `burmese-gpt-pypi-api`
- Workflow name: `publish-pypi.yml`
- Environment name: `pypi`

These values must match the GitHub workflow exactly, including the `environment.name` in the `publish` job.
