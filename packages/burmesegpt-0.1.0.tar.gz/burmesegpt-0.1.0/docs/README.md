# Documentation

This folder collects practical guides for users and maintainers of `burmesegpt`.

## Start Here

- Package overview and quickstart: `../README.md`

## Guides

- `guides/hf-to-gguf-quantization-guide.md` — Convert/export/quantize the Padauk model to GGUF.
- `guides/pypi-release-guide.md` — Manual PyPI/TestPyPI release workflow and token setup.

## CLI Entry Points

- `burmesegpt download`
- `burmesegpt serve`
- `burmesegpt run`
- `burmesegpt info`

## Model Metadata

Release validation and runtime checksum files live in:

- `../model/Modelfile`
- `../model/SHA256SUMS.txt`
