from __future__ import annotations

from pathlib import Path

import pytest

from burmesegpt.manifest import DEFAULT_QUANT, cache_dir_for, normalize_quant, quant_filename


def test_quant_selector_default_and_mapping() -> None:
    assert normalize_quant(None) == DEFAULT_QUANT
    assert quant_filename(None) == "padauk-gemma-q4_k_m.gguf"
    assert quant_filename("q8_0") == "padauk-gemma-q8_0.gguf"


def test_quant_selector_rejects_invalid() -> None:
    with pytest.raises(ValueError):
        normalize_quant("q2_x")


def test_cache_dir_is_deterministic() -> None:
    cache_dir = cache_dir_for(
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_root=Path("/tmp/cache-root"),
    )
    assert str(cache_dir) == "/tmp/cache-root/WYNN747/padauk-burmese-agentic-llm/main"
