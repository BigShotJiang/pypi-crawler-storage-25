from __future__ import annotations

from argparse import Namespace

from burmesegpt.agent import resolve_hf_token
from burmesegpt.cli import _make_agent, build_parser


def test_hf_token_precedence(monkeypatch) -> None:
    monkeypatch.setenv("HF_TOKEN", "env-token")
    assert resolve_hf_token("arg-token") == "arg-token"
    assert resolve_hf_token(None) == "env-token"

    monkeypatch.delenv("HF_TOKEN", raising=False)
    assert resolve_hf_token(None) is None


def test_cli_parser_sets_defaults() -> None:
    parser = build_parser()
    args = parser.parse_args(["download"])
    assert args.command == "download"
    assert args.quant == "q4_k_m"


def test_cli_args_flow_into_agent() -> None:
    args = Namespace(
        quant="q5_k_m",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir="/tmp/burmesegpt-cache",
        hf_token="abc",
    )
    agent = _make_agent(args)
    assert agent.quant == "q5_k_m"
    assert str(agent.cache_dir).endswith("/WYNN747/padauk-burmese-agentic-llm/main")
    assert agent.hf_token == "abc"
