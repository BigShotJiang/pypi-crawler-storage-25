from __future__ import annotations

from pathlib import Path

import pytest

from burmesegpt import padauk_agent
from burmesegpt.agent import HashMismatchError, file_sha256


def test_file_sha256_changes_when_content_changes(tmp_path: Path) -> None:
    model_file = tmp_path / "model.gguf"
    model_file.write_bytes(b"padauk")
    first_hash = file_sha256(model_file)

    model_file.write_bytes(b"padauk-tampered")
    second_hash = file_sha256(model_file)

    assert first_hash != second_hash


def test_ensure_model_rejects_tampered_checksum(monkeypatch, tmp_path: Path) -> None:
    model_filename = "padauk-gemma-q4_k_m.gguf"

    def fake_hf_hub_download(*, filename: str, local_dir: str, **_kwargs):
        path = Path(local_dir) / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        if filename == model_filename:
            path.write_bytes(b"tampered")
            return str(path)
        if filename == "SHA256SUMS.txt":
            path.write_text(
                "0000000000000000000000000000000000000000000000000000000000000000  "
                f"{model_filename}\n",
                encoding="utf-8",
            )
            return str(path)
        raise AssertionError(f"unexpected file requested: {filename}")

    monkeypatch.setattr("burmesegpt.agent.hf_hub_download", fake_hf_hub_download)

    agent = padauk_agent(
        quant="q4_k_m",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    with pytest.raises(HashMismatchError):
        agent.ensure_model()
