from typing import Optional, Union
from langchain_core.language_models.llms import LLM
from langgraph.graph import StateGraph

from ..langchain.identify_concept_chain import IdentifyTimbrConceptChain
from .. import config


class IdentifyConceptNode:
    def __init__(
        self,
        llm: Optional[LLM] = None,
        url: Optional[str] = None,
        token: Optional[str] = None,
        ontology: Optional[str] = None,
        concepts_list: Optional[Union[list[str], str]] = None,
        views_list: Optional[Union[list[str], str]] = None,
        include_logic_concepts: Optional[bool] = False,
        include_tags: Optional[Union[list[str], str]] = None,
        should_validate: Optional[bool] = False,
        retries: Optional[int] = 3,
        note: Optional[str] = None,
        agent: Optional[str] = None,
        verify_ssl: Optional[bool] = True,
        is_jwt: Optional[bool] = False,
        jwt_tenant_id: Optional[str] = None,
        conn_params: Optional[dict] = None,
        debug: Optional[bool] = False,
        enable_trace: Optional[bool] = config.enable_trace,
        conversation_id: Optional[str] = None,
        enable_memory: Optional[bool] = config.enable_memory,
        memory_window_size: Optional[int] = config.memory_window_size,
        **kwargs,
    ):
        """
        :param llm: An LLM instance or a function that takes a prompt string and returns the LLM's response (optional, will use LlmWrapper with env variables if not provided)
        :param url: Timbr server url (optional, defaults to TIMBR_URL environment variable)
        :param token: Timbr password or token value (optional, defaults to TIMBR_TOKEN environment variable)
        :param ontology: The name of the ontology/knowledge graph (optional, defaults to ONTOLOGY/TIMBR_ONTOLOGY environment variable)
        :param concepts_list: Optional specific concept options to query
        :param views_list: Optional specific view options to query
        :param include_logic_concepts: Optional boolean to include logic concepts (concepts without unique properties which only inherits from an upper level concept with filter logic) in the query.
        :param include_tags: Optional specific concepts & properties tag options to use in the query (Disabled by default. Use '*' to enable all tags or a string represents a list of tags divided by commas (e.g. 'tag1,tag2')
        :param should_validate: Whether to validate the identified concept before returning it
        :param retries: Number of retry attempts if the identified concept is invalid
        :param note: Optional additional note to extend our llm prompt
        :param agent: Optional Timbr agent name for options setup.
        :param verify_ssl: Whether to verify SSL certificates
        :param is_jwt: Whether to use JWT authentication (default: False)
        :param jwt_tenant_id: Tenant ID for JWT authentication when using multi-tenant setup
        :param conn_params: Extra Timbr connection parameters sent with every request (e.g., 'x-api-impersonate-user').
        :param enable_trace: Whether to enable trace logging for this node's operations.
        :param conversation_id: Optional conversation ID for tracking across multi-turn conversations.
        :param enable_memory: Whether to enable conversation memory (default from TIMBR_ENABLE_MEMORY env var).
        :param memory_window_size: Number of past conversation turns to consider (default from TIMBR_MEMORY_WINDOW_SIZE env var).
        """
        self.chain = IdentifyTimbrConceptChain(
            llm=llm,
            url=url,
            token=token,
            ontology=ontology,
            concepts_list=concepts_list,
            views_list=views_list,
            include_logic_concepts=include_logic_concepts,
            include_tags=include_tags,
            should_validate=should_validate,
            retries=retries,
            note=note,
            agent=agent,
            verify_ssl=verify_ssl,
            is_jwt=is_jwt,
            jwt_tenant_id=jwt_tenant_id,
            conn_params=conn_params,
            debug=debug,
            enable_trace=enable_trace,
            conversation_id=conversation_id,
            enable_memory=enable_memory,
            memory_window_size=memory_window_size,
            **kwargs,
        )


    def run(self, state: StateGraph) -> dict:
        try:
          prompt = state.messages[-1].get('content') if state.messages[-1] and 'content' in state.messages[-1] else None
        except Exception:
          prompt = state.get('prompt', None)

        conversation_id = state.get('conversation_id', None)
        chain_context = state.get('chain_context', None)
        return self.chain.invoke({"prompt": prompt, "conversation_id": conversation_id, "chain_context": chain_context})


    def __call__(self, state: dict) -> dict:
        return self.run(state)

