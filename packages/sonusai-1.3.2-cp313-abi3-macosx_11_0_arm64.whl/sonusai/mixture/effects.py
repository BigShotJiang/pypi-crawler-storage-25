"""Utilities for applying and parsing mixture effects."""

from __future__ import annotations

import re
from copy import deepcopy
from random import choice
from random import randint
from typing import TYPE_CHECKING

import numpy as np

from sonusai import rs
from sonusai.datatypes import Effects
from sonusai.parse.expand import expand
from sonusai.parse.rand import rand
from sonusai.utils.dataclass_from_dict import list_dataclass_from_dict

from . import effects_help
from .helpers import generic_ids_to_list
from .ir_effects import apply_ir
from .ir_effects import read_ir
from .pad_audio import get_padded_length
from .sox_effects import apply_sox_effects
from .sox_effects import validate_sox_effects

if TYPE_CHECKING:
    from sonusai.datatypes import AudioT
    from sonusai.datatypes import EffectList

    from .mixdb import MixtureDatabase


def get_effect_rules(location: str, config: dict, test: bool = False) -> dict[str, list[Effects]]:
    """Get effect rules from the configuration.

    Args:
        location: The configuration directory.
        config: The configuration dictionary.
        test: Whether to use test data.

    Returns:
        A dictionary of effect rules.

    """
    from .mixdb import MixtureDatabase  # noqa: PLC0415 (Circular dependency)

    mixdb = MixtureDatabase(location, test)

    rules: dict[str, list[Effects]] = {}
    for category, source in config["sources"].items():
        processed_rules: list[dict] = []
        for rule in source["effects"]:
            rule = _parse_ir_rule(rule, mixdb.num_ir_files)
            processed_rules = _expand_effect_rules(processed_rules, rule)
        rules[category] = list_dataclass_from_dict(list[Effects], processed_rules)

    validate_rules(mixdb, rules)
    return rules


def _expand_effect_rules(expanded_rules: list[dict], rule: dict) -> list[dict]:
    for key in ("pre", "post"):
        if key in rule:
            value = rule[key]
            for idx in range(len(value)):
                new_rules = expand(value[idx])
                if len(new_rules) > 1:
                    for new_rule in new_rules:
                        expanded_effect = deepcopy(rule)
                        new_value = deepcopy(value)
                        new_value[idx] = new_rule
                        expanded_effect[key] = new_value
                        _expand_effect_rules(expanded_rules, expanded_effect)
                    return expanded_rules

    expanded_rules.append(rule)
    return expanded_rules


def _resolve_ir_parameters(parameters: str, num_ir: int) -> str:
    if parameters.startswith(("rand", "choose", "expand")):
        return f"ir {parameters}"

    irs = generic_ids_to_list(num_ir, parameters)
    if not all(ro in range(num_ir) for ro in irs):
        msg = f"Invalid ir of {parameters}"
        raise ValueError(msg)
    if len(irs) == 1:
        return f"ir {irs[0]}"
    return f"ir expand({', '.join(map(str, irs))})"


def _parse_ir_effect(rule_in: str, num_ir: int) -> str | None:
    parts = rule_in.split(maxsplit=1)
    if parts[0] != "ir":
        return rule_in
    if len(parts) == 1:
        return None
    parameters = parts[1]
    if parameters.isnumeric():
        ir = int(parameters)
        if ir not in range(num_ir):
            msg = f"Invalid ir of {parameters}"
            raise ValueError(msg)
        return rule_in
    return _resolve_ir_parameters(parameters, num_ir)


def _process_ir_rules(rules_in: EffectList, num_ir: int) -> EffectList:
    rules_out: EffectList = []
    for rule_in in rules_in:
        parsed = _parse_ir_effect(rule_in, num_ir)
        if parsed is not None:
            rules_out.append(parsed)
    return rules_out


def _parse_ir_rule(rule: dict, num_ir: int) -> dict:
    for key in ("pre", "post"):
        if key in rule:
            rule[key] = _process_ir_rules(rule[key], num_ir)
    return rule


def apply_mixture_effects(
    mixdb: MixtureDatabase,
    audio: AudioT,
    effects: Effects,
    pre: bool = True,
    post: bool = True,
) -> AudioT:
    """Apply effects to audio data.

    Args:
        mixdb: Mixture database.
        audio: Input audio.
        effects: Effects to apply.
        pre: Apply pre-truth effects.
        post: Apply post-truth effects.

    Returns:
        Output audio after applying effects.

    """

    def _process(audio_in: AudioT, effects_in: EffectList) -> AudioT:
        _effects: EffectList = []
        for effect in effects_in:
            if effect.startswith("ir "):
                # Apply effects gathered so far
                audio_in = apply_effects(audio_in, _effects)

                # Then empty the list of effects
                _effects = []

                # Apply IR
                index = int(effect.split()[1])
                audio_in = apply_ir(
                    audio=audio_in,
                    ir=read_ir(
                        name=mixdb.ir_file(index),
                        delay=mixdb.ir_delay(index),
                        use_cache=mixdb.use_cache,
                    ),
                )
            else:
                _effects.append(effect)

        return apply_effects(audio_in, _effects)

    audio_out = audio.copy()

    if pre:
        audio_out = _process(audio_out, effects.pre)

    if post:
        audio_out = _process(audio_out, effects.post)

    return audio_out


def _update_speed(s: int, e: str) -> int:
    # speed factor[c]
    speed_pattern = re.compile(r"^speed\s+(-?\d+(\.\d+)*)(c?)$")
    result = re.search(speed_pattern, e)
    if result:
        value = float(result.group(1))
        if result.group(3):
            value = float(2 ** (value / 1200))
        return int(s / value + 0.5)
    return s


def _update_tempo(s: int, e: str) -> int:
    # tempo [-q] [-m|-s|-l] factor [segment [search [overlap]]]
    tempo_pattern = re.compile(r"^tempo\s+(-q\s+)?(((-m)|(-s)|(-l))\s+)?(\d+(\.\d+)*)")
    result = re.search(tempo_pattern, e)
    if result:
        value = float(result.group(7))
        return int(s / value + 0.5)
    return s


def _update_echo(s: int, e: str) -> int:
    s = _update_echo_single(s, e)
    s = _update_echos_single(s, e)
    return _update_chorus_single(s, e)


def _update_echo_single(s: int, e: str) -> int:
    # echo gain-in gain-out delay decay [delay decay ...]
    if e.startswith("echo "):
        parts = e.split()
        if len(parts) >= 5:
            delays = [float(parts[i]) for i in range(3, len(parts), 2)]
            max_delay_ms = max(delays)
            return s + int(max_delay_ms * 16000 / 1000 + 0.5)
    return s


def _update_echos_single(s: int, e: str) -> int:
    # echos gain-in gain-out delay decay [delay decay ...]
    if e.startswith("echos "):
        parts = e.split()
        if len(parts) >= 5:
            delays = [float(parts[i]) for i in range(3, len(parts), 2)]
            sum_delay_ms = sum(delays)
            return s + int(sum_delay_ms * 16000 / 1000 + 0.5)
    return s


def _update_chorus_single(s: int, e: str) -> int:
    # chorus gain-in gain-out <delay decay speed depth -s|-t>
    if e.startswith("chorus "):
        parts = e.split()
        if len(parts) >= 7:
            # Multi-voice pairs start at index 2, length 5
            max_delay_ms = 0.0
            for i in range(2, len(parts), 5):
                delay = float(parts[i])
                depth = float(parts[i + 3])
                max_delay_ms = max(max_delay_ms, delay + depth)
            return s + int(max_delay_ms * 16000 / 1000 + 0.5)
    return s


def _parse_sox_samples(val_str: str) -> int:
    """Parse a SoX duration string into samples.

    Args:
        val_str: The SoX duration string (e.g., "0.1" or "1600s").

    Returns:
        The duration in samples.

    """
    if val_str.endswith("s"):
        return int(val_str[:-1])
    return int(float(val_str) * 16000 + 0.5)


def _update_fade(s: int, e: str) -> int:
    """Update sample count based on 'fade' effect.

    Args:
        s: Current sample count.
        e: Effect string.

    Returns:
        Updated sample count.

    """
    # fade [type] fade-in-length [stop-position [fade-out-length]]
    if e.startswith("fade "):
        parts = e.split()
        if len(parts) >= 2:
            arg_idx = 1
            if arg_idx < len(parts) and parts[arg_idx] in ("q", "h", "l", "t", "p"):
                arg_idx += 1
            # skip fade-in
            fade_in_str = parts[arg_idx] if arg_idx < len(parts) else "0"
            arg_idx += 1

            if arg_idx < len(parts):
                pos_str = parts[arg_idx]
                anchor = "="
                if pos_str.startswith(("+", "-", "=")):
                    anchor = pos_str[0]
                    pos_str = pos_str[1:]

                try:
                    val = _parse_sox_samples(pos_str)

                    if anchor == "=":
                        return val if val > 0 else s
                    if anchor == "+":
                        # Relative to fade-in
                        fi = _parse_sox_samples(fade_in_str)
                        return fi + val
                    if anchor == "-":
                        return max(0, s - val)
                except ValueError:
                    pass
    return s


def _update_stretch(s: int, e: str) -> int:
    """Update sample count based on 'stretch' effect.

    Args:
        s: Current sample count.
        e: Effect string.

    Returns:
        Updated sample count.

    """
    # stretch factor [window [fade [shift [fading]]]]
    if e.startswith("stretch "):
        parts = e.split()
        if len(parts) >= 2:
            try:
                factor = float(parts[1])
                if factor > 0:
                    return int(s / factor + 0.5)
            except ValueError:
                pass
    return s


def _update_samples(s: int, e: str) -> int:
    """Update sample count based on various effects.

    Args:
        s: Current sample count.
        e: Effect string.

    Returns:
        Updated sample count.

    """
    s = _update_speed(s, e)
    s = _update_tempo(s, e)
    s = _update_fade(s, e)
    s = _update_stretch(s, e)
    return _update_echo(s, e)


def estimate_effected_length(
    samples: int,
    effects: Effects,
    frame_length: int = 1,
    pre: bool = True,
    post: bool = True,
) -> int:
    """Estimate the effected audio length.

    Args:
        samples: Original length in samples.
        effects: Effects that may change the length.
        frame_length: Resulting length will be a multiple of this.
        pre: Consider pre-truth effects.
        post: Consider post-truth effects.

    Returns:
        Estimated length in samples.

    """
    length = samples

    if pre:
        for effect in effects.pre:
            length = _update_samples(length, effect)

    if post:
        for effect in effects.post:
            length = _update_samples(length, effect)

    return get_padded_length(length, frame_length)


def effects_from_rules(mixdb: MixtureDatabase, rules: Effects) -> Effects:
    """Create concrete effects from rules.

    Args:
        mixdb: The mixture database.
        rules: The effect rules.

    Returns:
        The concrete effects.

    """
    effects = deepcopy(rules)
    for key in ("pre", "post"):
        entries = getattr(effects, key)
        for idx, entry in enumerate(entries):
            if entry.find("rand") != -1:
                entries[idx] = rand(entry)
            if entry.startswith("ir choose"):
                entries[idx] = _choose_ir(mixdb, entry)
        setattr(effects, key, entries)

    return effects


def conform_audio_to_length(audio: AudioT, length: int, loop: bool, start: int) -> AudioT:
    """Conform audio to the given length.

    :param audio: Audio to conform
    :param length: Length of output
    :param loop: Loop samples or pad
    :param start: Starting sample offset
    :return: Conformed audio
    """
    if loop:
        return np.take(audio, range(start, start + length), mode="wrap")

    # Non-loop mode
    audio_slice = audio[start : start + length]

    if len(audio_slice) >= length:
        # We have enough samples, truncate
        return audio_slice[:length]
    # We need padding
    padding_needed = length - len(audio_slice)
    return np.pad(audio_slice, (0, padding_needed))


def validate_rules(mixdb: MixtureDatabase, rules: dict[str, list[Effects]]) -> None:
    """Validate effect rules.

    Args:
        mixdb: The mixture database.
        rules: The effect rules to validate.

    """
    for rule_list in rules.values():
        for rule in rule_list:
            effects = effects_from_rules(mixdb, rule)
            sox_effects: list[str] = [effect for effect in effects.pre if not effect.startswith("ir")]

            for effect in effects.post:
                for check in ("speed", "tempo"):
                    if check in effect:
                        msg = f"'{check}' effect is not allowed in post-truth effect chain."
                        raise ValueError(msg)

                if not effect.startswith("ir"):
                    sox_effects.append(effect)

            validate_sox_effects(sox_effects)


def _choose_ir(mixdb: MixtureDatabase, directive: str) -> str:
    """Evaluate the 'choose' directive for an ir.

    The directive is used to choose a random ir file from the database
    and may take one of the following forms:

    # choose a random ir file
    ir choose()

    # choose a random ir file between a and b, inclusive
    ir choose(a, b)

    # choose a random ir file with the specified tag
    ir choose(tag)

    :param mixdb: Mixture database
    :param directive: Directive to evaluate
    :return: Resolved value
    """
    choose_pattern = re.compile(r"^ir choose\(\)$")
    choose_range_pattern = re.compile(r"^ir choose\((\d+),\s*(\d+)\)$")
    choose_tag_pattern = re.compile(r"^ir choose\((\w+)\)$")

    def choose_range_repl(m: re.Match) -> str:
        lower = int(m.group(1))
        upper = int(m.group(2))
        if (
            lower < 0
            or lower >= mixdb.num_ir_files
            or upper < 0
            or upper >= mixdb.num_ir_files
            or lower >= upper
            or str(lower) != m.group(1)
            or str(upper) != m.group(2)
        ):
            msg = f"Invalid rule: '{directive}'. Values must be integers between 0 and {mixdb.num_ir_files - 1}."
            raise ValueError(msg)
        return f"ir {randint(lower, upper)}"  # noqa: S311

    def choose_tag_repl(m: re.Match) -> str:
        return m.group(1)

    if re.match(choose_pattern, directive):
        return f"ir {randint(0, mixdb.num_ir_files - 1)}"  # noqa: S311

    if re.match(choose_range_pattern, directive):
        try:
            return f"ir {eval(re.sub(choose_range_pattern, choose_range_repl, directive))}"  # noqa: S307
        except Exception as e:
            msg = f"Invalid rule: '{directive}'. Values must be integers between 0 and {mixdb.num_ir_files - 1}."
            raise ValueError(msg) from e

    if re.match(choose_tag_pattern, directive):
        tag = re.sub(choose_tag_pattern, choose_tag_repl, directive)
        if tag in mixdb.ir_tags:
            return f"ir {choice(mixdb.ir_file_ids_for_tag(tag))}"  # noqa: S311

        msg = f"Invalid rule: '{directive}'. Tag, '{tag}', not found in database."
        raise ValueError(msg)

    msg = f"Invalid rule: '{directive}'."
    raise ValueError(msg)


def apply_rust_effects(audio: AudioT, effects: list[str]) -> AudioT:
    """Apply effects to audio data using Rust.

    Args:
        audio: Input audio data.
        effects: List of effect strings to apply.

    Returns:
        Audio data after applying the effects.

    Raises:
        TypeError: If audio is not an AudioT.
        ValueError: If audio is not float32 or not 1-D (mono).
        RuntimeError: If applying effects causes an error or if an unexpected length change occurs.

    """
    if not isinstance(audio, np.ndarray):
        raise TypeError("buffer must be an AudioT")
    if audio.dtype != np.float32:
        raise ValueError("buffer must be float32")
    if audio.ndim != 1:
        raise ValueError("buffer must be 1-D (mono)")

    return rs.audio.apply_effects(audio, effects)


def apply_rust_effects_i32(audio: np.ndarray, effects: list[str]) -> np.ndarray:
    """Apply effects to int32 audio data using Rust.

    Args:
        audio: Input audio data (int32).
        effects: List of effect strings to apply.

    Returns:
        Audio data after applying the effects (int32).

    Raises:
        TypeError: If audio is not an ndarray.
        ValueError: If audio is not int32 or not 1-D (mono).

    """
    if not isinstance(audio, np.ndarray):
        raise TypeError("buffer must be an ndarray")
    if audio.dtype != np.int32:
        raise ValueError("buffer must be int32")
    if audio.ndim != 1:
        raise ValueError("buffer must be 1-D (mono)")

    return rs.audio.apply_effects_i32(audio, effects)


def apply_effects(audio: AudioT, effects: list[str]) -> AudioT:
    """Apply a chain of SoX-compatible effects to an audio buffer.

    If the effect chain is supported in Rust, it uses the Rust acceleration
    function. Otherwise, it falls back to the `sox` subprocess implementation.

    Args:
        audio: Input audio data.
        effects: List of effect strings to apply.

    Returns:
        Audio data after applying the effects.

    Raises:
        TypeError: If audio is not an AudioT.
        ValueError: If audio is not float32 or not 1-D (mono).
        RuntimeError: If applying effects causes an error or if an unexpected length change occurs.

    """
    # Check if the effect chain is supported in Rust
    validation_results = validate_effects_chain(effects)
    if all(result[0] for result in validation_results):
        if audio.dtype == np.int32:
            return apply_rust_effects_i32(audio, effects)
        return apply_rust_effects(audio, effects)

    # Fall back to apply_sox_effects if not all effects are supported in Rust
    return apply_sox_effects(audio, effects)


def effect_help(effect: str) -> str:
    """Get help text for a specific audio effect.

    Args:
        effect: Name of the effect.

    Returns:
        Help string sourced from sonusai.mixture.effects_help.
    """
    help_func = getattr(effects_help, effect.replace("-", "_"), None)
    if help_func and callable(help_func):
        return help_func()
    raise ValueError(f"Unknown effect: {effect}")


def list_effects() -> list[str]:
    """List supported effects.

    Returns:
        List of effect names.
    """
    return [
        "gain",
        "norm",
        "equalizer",
        "highpass",
        "pitch",
        "tempo",
        "lowpass",
        "bandpass",
        "bandreject",
        "allpass",
        "band",
        "bass",
        "treble",
        "rate",
        "vol",
        "dcshift",
        "contrast",
        "overdrive",
        "compand",
        "mcompand",
        "echo",
        "echos",
        "chorus",
        "flanger",
        "phaser",
        "reverb",
        "fade",
        "reverse",
        "sinc",
        "hilbert",
        "loudness",
        "tremolo",
        "speed",
        "stretch",
    ]


def validate_effects_chain(chain: list[str]) -> list[tuple[bool, str, str]]:
    """Validate a chain of effects without applying them.

    Args:
        chain: List of effect strings.

    Returns:
        List of (is_valid, message, normalized_command) tuples.
    """
    return rs.audio.validate_effects_chain(chain)
