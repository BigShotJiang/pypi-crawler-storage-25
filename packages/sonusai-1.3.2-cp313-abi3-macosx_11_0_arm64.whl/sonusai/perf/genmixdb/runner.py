"""Execution runner for GenMixDB benchmark and profiling invocations."""

import json
import platform
import resource
import shlex
import subprocess
import sys
import uuid
from datetime import UTC
from datetime import datetime
from pathlib import Path
from typing import Any

from sonusai.perf.genmixdb.metrics_collector import collect_resources
from sonusai.perf.genmixdb.metrics_collector import probe_db
from sonusai.perf.genmixdb.profiler import run_with_cprofile
from sonusai.perf.genmixdb.profiler import run_with_pyspy
from sonusai.perf.genmixdb.profiler import run_with_scalene
from sonusai.perf.genmixdb.schemas import RunManifest
from sonusai.perf.timer import PhaseTimer


def _extract_genmixdb_location(command: str) -> str | None:
    """Return `genmixdb` location for supported command patterns, else None."""
    parts = shlex.split(command)
    if not parts:
        return None

    # Handle 'sonusai genmixdb ...'
    if len(parts) >= 2 and parts[0] == "sonusai" and parts[1] == "genmixdb":
        if len(parts) == 3:
            return parts[2]
        if len(parts) == 4 and parts[2] == "-n":
            return parts[3]

    # Handle 'python -m sonusai.main genmixdb ...'
    if (
        len(parts) >= 4
        and parts[0] == "python"
        and parts[1] == "-m"
        and parts[2] == "sonusai.main"
        and parts[3] == "genmixdb"
    ):
        if len(parts) == 5:
            return parts[4]
        if len(parts) == 6 and parts[4] == "-n":
            return parts[5]

    return None


def _run_with_profile_mode(
    command: str,
    artifact_path: Path,
    run_id: str,
    profile_mode: str,
    quiet: bool,
) -> tuple[int, bool, object, str | None]:
    """Execute profiled run and return `(exit_code, success, profile_manifest)` tuple."""
    if profile_mode == "pyspy":
        try:
            profile_manifest = run_with_pyspy(command, str(artifact_path), run_id, quiet=quiet)
        except subprocess.CalledProcessError as err:
            warning = f"py-spy profiling failed and fell back to cProfile for run {run_id}: {err.stderr or err}"
            profile_manifest = run_with_cprofile(command, str(artifact_path), run_id, quiet=quiet)
            return 0, True, profile_manifest, warning
        return 0, True, profile_manifest, None

    if profile_mode == "cprofile":
        profile_manifest = run_with_cprofile(command, str(artifact_path), run_id, quiet=quiet)
        return 0, True, profile_manifest, None

    if profile_mode == "scalene":
        try:
            profile_manifest = run_with_scalene(command, str(artifact_path), run_id, quiet=quiet)
        except subprocess.CalledProcessError as err:
            warning = f"scalene profiling failed and fell back to cProfile for run {run_id}: {err.stderr or err}"
            profile_manifest = run_with_cprofile(command, str(artifact_path), run_id, quiet=quiet)
            return 0, True, profile_manifest, warning
        return 0, True, profile_manifest, None

    msg = f"Unsupported profile mode: {profile_mode}"
    raise ValueError(msg)


def _run_in_process(location: str, quiet: bool) -> tuple[dict[str, object], dict[str, object]]:
    """Run `genmixdb` in-process and return `(metrics, db_metrics)` payloads."""
    from sonusai.genmixdb import GenMixDbOptions
    from sonusai.genmixdb import genmixdb

    timer = PhaseTimer()
    wall_start = datetime.now(tz=UTC)
    usage_before_self = resource.getrusage(resource.RUSAGE_SELF)
    usage_before_children = resource.getrusage(resource.RUSAGE_CHILDREN)
    with timer.measure("total_run"):
        genmixdb(
            location=location,
            options=GenMixDbOptions(show_progress=not quiet, logging=False, no_par=True),
            timer=timer,
        )
    wall_end = datetime.now(tz=UTC)
    usage_after_self = resource.getrusage(resource.RUSAGE_SELF)
    usage_after_children = resource.getrusage(resource.RUSAGE_CHILDREN)

    cpu_user = (usage_after_self.ru_utime - usage_before_self.ru_utime) + (
        usage_after_children.ru_utime - usage_before_children.ru_utime
    )
    cpu_system = (usage_after_self.ru_stime - usage_before_self.ru_stime) + (
        usage_after_children.ru_stime - usage_before_children.ru_stime
    )
    peak_rss = max(usage_after_self.ru_maxrss, usage_after_children.ru_maxrss)
    rss_divisor = 1024 if platform.system() == "Darwin" else 1
    peak_rss_kb = int(peak_rss // rss_divisor)

    metrics: dict[str, object] = {
        "wall_clock_seconds": max((wall_end - wall_start).total_seconds(), 0.0),
        "cpu_user_seconds": cpu_user,
        "cpu_system_seconds": cpu_system,
        "peak_rss_kb": peak_rss_kb,
        "io_ops_read": None,
        "io_ops_write": None,
        "phase_timings": [timer.get_phase_summary(name) for name in timer.phases],
    }
    db_metrics = probe_db(location)
    return metrics, db_metrics


def _run_subprocess(command: str, quiet: bool) -> tuple[int, bool, dict[str, object], dict[str, object]]:
    """Run command via subprocess and return `(exit_code, success, metrics, db_metrics)` tuple."""
    full_command = f"/usr/bin/time -l {command}"
    run_kwargs = {}
    if quiet:
        run_kwargs.update({"capture_output": True, "text": True})
    result = subprocess.run(full_command.split(), **run_kwargs)

    exit_code = result.returncode
    success = exit_code == 0
    metrics = collect_resources(result.stderr)

    parts = command.split()
    fallback_location = parts[-1] if len(parts) > 1 else "."
    db_metrics = probe_db(fallback_location)
    return exit_code, success, metrics, db_metrics


def execute_run(
    command: str,
    artifact_dir: str,
    repeat_index: int,
    profile_mode: str | None = None,
    quiet: bool = False,
) -> RunManifest:
    """Execute a single benchmark command and persist run manifest artifacts."""
    run_id = f"{datetime.now(tz=UTC).strftime('%Y%m%d_%H%M%S')}_{repeat_index}_{uuid.uuid4().hex[:6]}"
    artifact_path = Path(artifact_dir)
    artifact_path.mkdir(parents=True, exist_ok=True)

    start_time = datetime.now(tz=UTC)

    metrics = None
    db_metrics = None
    profile_manifest = None
    profile_warning = None

    if profile_mode in {"pyspy", "cprofile", "scalene"}:
        exit_code, success, profile_manifest, profile_warning = _run_with_profile_mode(
            command,
            artifact_path,
            run_id,
            profile_mode,
            quiet,
        )
        # Profiling adds overhead and is for hotspot analysis, metrics might be unreliable
    else:
        location = _extract_genmixdb_location(command)
        if location:
            metrics, db_metrics = _run_in_process(location, quiet=quiet)
            exit_code = 0
            success = True
        else:
            exit_code, success, metrics, db_metrics = _run_subprocess(command, quiet=quiet)

    end_time = datetime.now(tz=UTC)

    manifest = RunManifest(
        run_id=run_id,
        command=command,
        start_time=start_time.isoformat(),
        end_time=end_time.isoformat(),
        exit_code=exit_code,
        success=success,
    )

    with (artifact_path / f"{run_id}.json").open("w") as f:
        # Save metrics + manifest
        output = manifest.to_dict()
        if metrics:
            output["metrics"] = metrics
        if db_metrics:
            output["db"] = db_metrics
        if profile_manifest:
            output["profile"] = profile_manifest.to_dict()
        if profile_warning:
            output["warnings"] = [profile_warning]
        json.dump(output, f, indent=4)

    return manifest


def run_batch(
    entries: list[dict[str, Any]],
    artifact_base_dir: str,
    profile_mode: str | None = None,
    quiet: bool = False,
) -> list[RunManifest]:
    """Execute a batch of matrix entries and return their manifests."""
    label = profile_mode or "baseline"
    total = len(entries)
    manifests: list[RunManifest] = []
    for index, entry in enumerate(entries, start=1):
        config = entry.get("config_path", _extract_genmixdb_location(entry["command"]) or "unknown")
        _emit_progress(
            f"[genmixdb-perf] {label}: run {index}/{total} (repeat={entry['repeat_index']}, config={config})"
        )
        manifests.append(
            execute_run(
                entry["command"],
                artifact_base_dir,
                entry["repeat_index"],
                profile_mode=profile_mode,
                quiet=quiet,
            )
        )
    return manifests


def _emit_progress(message: str) -> None:
    """Write progress updates to stdout."""
    sys.stdout.write(f"{message}\n")
