"""Benchmark matrix construction for GenMixDB performance runs."""

import json

from sonusai.perf.genmixdb.env import capture_env


def generate_matrix_json(configs: list[str], repeats: int) -> str:
    """Build matrix payload JSON for configured benchmark repetitions."""
    metadata = capture_env()
    entries: list[dict[str, str | int]] = []
    for config in configs:
        entries.extend(
            {"command": f"sonusai genmixdb -n {config}", "config_path": config, "repeat_index": i}
            for i in range(repeats)
        )

    payload = {"metadata": metadata.to_dict(), "entries": entries}
    return json.dumps(payload, indent=2)
