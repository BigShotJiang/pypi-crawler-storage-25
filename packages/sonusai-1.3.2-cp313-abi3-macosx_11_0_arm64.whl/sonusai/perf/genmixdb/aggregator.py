"""Aggregation utilities for GenMixDB performance runs."""

import math
import statistics
from dataclasses import dataclass

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class AggregatedStats:
    """Distribution statistics computed from repeated benchmark runs."""

    p50: float
    p95: float
    p99: float
    min: float
    max: float
    stddev: float
    cov: float


@dataclass_json
@dataclass
class BaselineSummary:
    """Summary report for one benchmark configuration."""

    config_name: str
    run_count: int
    stats: AggregatedStats
    quality_gate_passed: bool
    missing_artifacts: list[str]


def aggregate_run_metrics(metrics: list[float], config_name: str, threshold_cov: float = 0.08) -> BaselineSummary:
    """Aggregate run-level timings into summary statistics and quality gates."""
    n = len(metrics)
    if n < 2:
        # Cannot calculate stddev with fewer than 2 data points
        return BaselineSummary(
            config_name=config_name,
            run_count=n,
            stats=AggregatedStats(
                p50=metrics[0] if n > 0 else 0.0,
                p95=metrics[0] if n > 0 else 0.0,
                p99=metrics[0] if n > 0 else 0.0,
                min=metrics[0] if n > 0 else 0.0,
                max=metrics[0] if n > 0 else 0.0,
                stddev=0.0,
                cov=0.0,
            ),
            quality_gate_passed=False,
            missing_artifacts=[],
        )

    sorted_metrics = sorted(metrics)

    def percentile(data: list[float], p: float) -> float:
        k = (len(data) - 1) * p
        f = math.floor(k)
        c = math.ceil(k)
        if f == c:
            return data[int(k)]
        return data[int(f)] * (c - k) + data[int(c)] * (k - f)

    p50 = percentile(sorted_metrics, 0.50)
    p95 = percentile(sorted_metrics, 0.95)
    p99 = percentile(sorted_metrics, 0.99)
    min_val = min(metrics)
    max_val = max(metrics)
    mean_val = statistics.mean(metrics)
    stddev = statistics.stdev(metrics)
    cov = stddev / mean_val if mean_val != 0 else 0.0

    return BaselineSummary(
        config_name=config_name,
        run_count=n,
        stats=AggregatedStats(p50=p50, p95=p95, p99=p99, min=min_val, max=max_val, stddev=stddev, cov=cov),
        quality_gate_passed=cov <= threshold_cov,
        missing_artifacts=[],
    )


def generate_markdown_summary(summaries: list[BaselineSummary]) -> str:
    """Render a markdown table with baseline summary metrics."""
    lines = [
        "# Baseline Performance Summary",
        "",
        "| Config | Runs | p50 | p95 | stddev | CoV | Gate |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    for s in summaries:
        gate = "PASS" if s.quality_gate_passed else "FAIL"
        lines.append(
            f"| {s.config_name} | {s.run_count} | {s.stats.p50:.2f} | {s.stats.p95:.2f} | {s.stats.stddev:.2f} | {s.stats.cov:.2%} | {gate} |"
        )
    return "\n".join(lines)
