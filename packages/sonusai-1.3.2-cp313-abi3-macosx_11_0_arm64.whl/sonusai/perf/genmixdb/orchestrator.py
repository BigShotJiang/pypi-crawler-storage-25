"""Orchestration for the GenMixDB performance pipeline."""

import json
import sys
from pathlib import Path

from sonusai.perf.genmixdb.aggregator import aggregate_run_metrics
from sonusai.perf.genmixdb.aggregator import generate_markdown_summary
from sonusai.perf.genmixdb.analysis import generate_backlog_artifact
from sonusai.perf.genmixdb.analysis import parse_speedscope
from sonusai.perf.genmixdb.analysis import synthesize_hotspots
from sonusai.perf.genmixdb.matrix import generate_matrix_json
from sonusai.perf.genmixdb.runner import run_batch


def _extract_config_from_command(command: str) -> str | None:
    """Extract config path from `python -m sonusai.main genmixdb <config>` command."""
    parts = command.split()
    if len(parts) >= 6 and parts[0] == "python" and parts[1] == "-m" and parts[2] == "sonusai.main":
        return parts[-1]
    return parts[-1] if parts else None


def _extract_phase_timings(run_artifact: dict[str, object]) -> list[dict[str, object]]:
    phase_payload = run_artifact.get("phase_timings")
    if isinstance(phase_payload, list):
        return [entry for entry in phase_payload if isinstance(entry, dict)]

    metrics_payload = run_artifact.get("metrics")
    if isinstance(metrics_payload, dict):
        nested = metrics_payload.get("phase_timings")
        if isinstance(nested, list):
            return [entry for entry in nested if isinstance(entry, dict)]

    return []


def _extract_profile_payload(run_artifact: dict[str, object]) -> dict[str, object]:
    profile_payload: dict[str, object] = {}

    profile = run_artifact.get("profile")
    if isinstance(profile, dict):
        for key in ("top_functions", "functions", "top_stacks", "stacks"):
            value = profile.get(key)
            if isinstance(value, list):
                profile_payload[key] = [entry for entry in value if isinstance(entry, dict)]

    summary = run_artifact.get("profile_summary")
    if isinstance(summary, dict):
        for key in ("top_functions", "functions", "top_stacks", "stacks"):
            value = summary.get(key)
            if isinstance(value, list):
                profile_payload[key] = [entry for entry in value if isinstance(entry, dict)]

    return profile_payload


def _classify_artifacts(artifact_path: Path, files: list[Path]) -> tuple[dict[str, object], dict[str, object]]:
    run_manifests: list[str] = []
    profile_manifests: list[str] = []
    phase_timing_manifests: list[str] = []

    for file in sorted(files, key=lambda candidate: candidate.name):
        with file.open() as f:
            payload = json.load(f)

        if isinstance(payload.get("command"), str):
            run_manifests.append(file.name)

        if _extract_phase_timings(payload):
            phase_timing_manifests.append(file.name)

        if _extract_profile_payload(payload):
            profile_manifests.append(file.name)

    artifact_index = {
        "artifact_dir": str(artifact_path),
        "matrix": "matrix.json",
        "summary": "summary.md",
        "backlog": "backlog.md",
        "run_manifests": run_manifests,
        "phase_timing_manifests": phase_timing_manifests,
        "profile_manifests": profile_manifests,
    }

    expected_classes = {
        "matrix": True,
        "run_manifests": bool(run_manifests),
        "phase_timing_manifests": bool(phase_timing_manifests),
        "profile_manifests": bool(profile_manifests),
        "summary": True,
        "backlog": True,
    }
    artifact_checklist = {
        "expected_classes": expected_classes,
        "all_present": all(expected_classes.values()),
        "missing_classes": [name for name, present in expected_classes.items() if not present],
    }
    return artifact_index, artifact_checklist


def _build_representative_entries(entries: list[dict[str, object]]) -> list[dict[str, object]]:
    representative_entries: list[dict[str, object]] = []
    seen_configs: set[str] = set()
    for entry in entries:
        config_path = entry.get("config_path")
        if isinstance(config_path, str) and config_path not in seen_configs:
            representative_entries.append({**entry, "repeat_index": 99})
            seen_configs.add(config_path)
    return representative_entries


def _append_profile_payload(profile_data: dict[str, object], extracted_profile: dict[str, object]) -> None:
    for key, values in extracted_profile.items():
        existing = profile_data.get(key)
        if isinstance(existing, list):
            existing.extend(values)
        else:
            profile_data[key] = list(values)


def _append_speedscope_entries(profile_data: dict[str, object], data: dict[str, object]) -> bool:
    profile_manifest = data.get("profile")
    if not isinstance(profile_manifest, dict):
        return False

    speedscope_path = profile_manifest.get("speedscope_path")
    if not isinstance(speedscope_path, str) or not speedscope_path:
        return False

    parsed_entries = parse_speedscope(speedscope_path)
    if not parsed_entries:
        return False

    existing = profile_data.get("top_functions")
    if isinstance(existing, list):
        existing.extend(parsed_entries)
    else:
        profile_data["top_functions"] = list(parsed_entries)
    return True


def _collect_run_data(
    files: list[Path],
    configs: list[str],
) -> tuple[
    dict[str, list[float]],
    dict[str, list[int]],
    list[dict[str, object]],
    dict[str, object],
    list[str],
    list[str],
]:
    run_times_by_config: dict[str, list[float]] = {config: [] for config in configs}
    db_sizes_by_config: dict[str, list[int]] = {config: [] for config in configs}
    phase_timings: list[dict[str, object]] = []
    profile_data: dict[str, object] = {}
    phase_sources: list[str] = []
    profile_sources: list[str] = []

    for file in files:
        with file.open() as f:
            data = json.load(f)

        command = data.get("command", "")
        config = _extract_config_from_command(command)
        if not config or config not in run_times_by_config:
            continue

        metrics = data.get("metrics", {})
        wall_clock = metrics.get("wall_clock_seconds")
        if wall_clock is not None:
            run_times_by_config[config].append(float(wall_clock))

        db_size = data.get("db", {}).get("file_size_bytes")
        if db_size is not None:
            db_sizes_by_config[config].append(int(db_size))

        extracted_phases = _extract_phase_timings(data)
        if extracted_phases:
            phase_timings.extend(extracted_phases)
            phase_sources.append(file.name)

        extracted_profile = _extract_profile_payload(data)
        if extracted_profile:
            _append_profile_payload(profile_data, extracted_profile)
            profile_sources.append(file.name)

        if _append_speedscope_entries(profile_data, data) and file.name not in profile_sources:
            profile_sources.append(file.name)

    return (
        run_times_by_config,
        db_sizes_by_config,
        phase_timings,
        profile_data,
        phase_sources,
        profile_sources,
    )


def _write_summary_and_backlog(
    artifact_path: Path,
    collected_data: tuple[
        dict[str, list[float]],
        dict[str, list[int]],
        list[dict[str, object]],
        dict[str, object],
        list[str],
        list[str],
    ],
) -> None:
    (
        run_times_by_config,
        db_sizes_by_config,
        phase_timings,
        profile_data,
        phase_sources,
        profile_sources,
    ) = collected_data
    summaries = [
        aggregate_run_metrics(run_times, config) for config, run_times in run_times_by_config.items() if run_times
    ]

    markdown_summary = generate_markdown_summary(summaries)
    with (artifact_path / "summary.md").open("w") as f:
        f.write(markdown_summary)

    candidates = synthesize_hotspots(phase_timings, profile_data)
    evidence = {
        "summary_path": str(artifact_path / "summary.md"),
        "matrix_path": str(artifact_path / "matrix.json"),
        "run_count": str(sum(len(v) for v in run_times_by_config.values())),
        "db_sizes": ", ".join(f"{config}: {max(sizes)} bytes" for config, sizes in db_sizes_by_config.items() if sizes),
        "phase_sources": ", ".join(sorted(set(phase_sources))) if phase_sources else "none",
        "profile_sources": ", ".join(sorted(set(profile_sources))) if profile_sources else "none",
    }
    backlog = generate_backlog_artifact(candidates, evidence)
    with (artifact_path / "backlog.md").open("w") as f:
        f.write(backlog)


def run_performance_pipeline(configs: list[str], repeats: int, artifact_dir: str, quiet: bool = False) -> None:
    """Run matrix generation, execution, aggregation, and ranking artifacts."""
    _emit_progress(
        f"[genmixdb-perf] starting pipeline (configs={len(configs)}, repeats={repeats}, artifact_dir={artifact_dir})"
    )
    _emit_progress("[genmixdb-perf] stage 1/5: generating matrix")
    matrix_json = generate_matrix_json(configs, repeats)
    matrix = json.loads(matrix_json)

    artifact_path = Path(artifact_dir)
    artifact_path.mkdir(parents=True, exist_ok=True)
    with (artifact_path / "matrix.json").open("w") as f:
        f.write(matrix_json)

    _emit_progress(f"[genmixdb-perf] stage 2/5: baseline execution ({len(matrix['entries'])} runs)")
    run_batch(matrix["entries"], artifact_dir, quiet=quiet)

    representative_entries = _build_representative_entries(matrix["entries"])

    _emit_progress(f"[genmixdb-perf] stage 3/5: profiling representative runs ({len(representative_entries)} configs)")
    _emit_progress("[genmixdb-perf]   profile mode: cprofile")
    run_batch(representative_entries, artifact_dir, profile_mode="cprofile", quiet=quiet)
    _emit_progress("[genmixdb-perf]   profile mode: pyspy")
    run_batch(representative_entries, artifact_dir, profile_mode="pyspy", quiet=quiet)
    _emit_progress("[genmixdb-perf]   profile mode: scalene")
    run_batch(representative_entries, artifact_dir, profile_mode="scalene", quiet=quiet)

    _emit_progress("[genmixdb-perf] stage 4/5: aggregating results")
    files = [file for file in artifact_path.glob("*.json") if file.name != "matrix.json"]
    collected_data = _collect_run_data(files, configs)
    _write_summary_and_backlog(artifact_path, collected_data)

    _emit_progress("[genmixdb-perf] stage 5/5: writing artifact index and checklist")
    artifact_index, artifact_checklist = _classify_artifacts(artifact_path, files)
    with (artifact_path / "artifact_index.json").open("w") as f:
        json.dump(artifact_index, f, indent=2)

    with (artifact_path / "artifact_checklist.json").open("w") as f:
        json.dump(artifact_checklist, f, indent=2)

    _emit_progress("[genmixdb-perf] pipeline complete")


def _emit_progress(message: str) -> None:
    """Write progress updates to stdout."""
    sys.stdout.write(f"{message}\n")
