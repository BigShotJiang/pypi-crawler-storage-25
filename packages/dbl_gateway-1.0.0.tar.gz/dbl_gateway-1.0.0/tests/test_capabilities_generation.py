from __future__ import annotations

import json
from pathlib import Path
import sys

from dbl_gateway.capabilities import CAPABILITIES_SCHEMA_VERSION
from dbl_gateway.wire_contract import INTERFACE_VERSION


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _import_generator_module():
    repo_root = _repo_root()
    scripts_dir = repo_root / "scripts"
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))
    import generate_capabilities

    return generate_capabilities


def test_generator_writes_versioned_file(tmp_path: Path) -> None:
    generator = _import_generator_module()
    out = tmp_path / f"capabilities.gateway.v{INTERFACE_VERSION}.json"
    written = generator.generate(out)
    assert written == out
    assert out.exists()

    data = json.loads(out.read_text(encoding="utf-8"))
    assert data["interface_version"] == INTERFACE_VERSION
    assert data["schema_version"] == CAPABILITIES_SCHEMA_VERSION
    assert "gateway_version" in data
    assert "generated_at" in data


def test_repo_capabilities_file_matches_wire_contract() -> None:
    docs_path = _repo_root() / "docs" / f"capabilities.gateway.v{INTERFACE_VERSION}.json"
    assert docs_path.exists()

    data = json.loads(docs_path.read_text(encoding="utf-8"))
    assert data["interface_version"] == INTERFACE_VERSION
    assert data["schema_version"] == CAPABILITIES_SCHEMA_VERSION


def test_generated_snapshot_has_contract_fields(tmp_path: Path) -> None:
    generator = _import_generator_module()
    out = tmp_path / "caps.json"
    generator.generate(out)

    data = json.loads(out.read_text(encoding="utf-8"))
    # Contract fields present
    assert "intents" in data
    assert "tool_surface" in data
    assert "budget" in data
    assert "surfaces" in data
    assert "surface_catalog" in data
    # Runtime-dynamic fields stripped
    assert "providers" not in data
    # Contract structure
    assert data["auth"]["mode"] == "dev"
    assert "current_trust_class" in data["auth"]
    assert "trust_classes" in data["auth"]
    assert "identity_sources" in data["auth"]
    assert "issuers_allowed" in data["auth"]
    assert "audiences_allowed" in data["auth"]
    assert data["auth"]["claim_mapping"] == {
        "actor_id": ["oid", "sub"],
        "issuer": "iss",
        "roles": ["roles", "groups"],
    }
    assert data["auth"]["tenant_mapping"] == {
        "source": "claim:tid",
        "fallback": "dev-tenant",
        "allow_all": True,
        "allowlist_count": 0,
    }
    assert data["auth"]["role_mapping_summary"] == {
        "mapped_sources": 2,
        "operator_sources": 1,
        "internal_sources": 1,
        "user_fallback": True,
    }
    assert isinstance(data["intents"]["supported"], list)
    assert isinstance(data["tool_surface"]["declared_tools"]["max_items"], int)
    assert "semantic_families" in data["tool_surface"]
    assert "trust_class_current" in data["tool_surface"]
    assert "allowed_families_current" in data["tool_surface"]
    assert "allowed_families_by_exposure" in data["tool_surface"]
    assert "no_mix_rules" in data["tool_surface"]
    assert isinstance(data["budget"]["fields"]["max_tokens"]["min"], int)
    assert "request_classes" in data["budget"]
    assert "visible_request_classes_current" in data["budget"]
    assert "light_budget_classification" in data["budget"]
    assert "current_request_policy" in data["budget"]
    assert "request_policy_by_exposure" in data["budget"]
    assert "economic" in data
    assert "current_policy" in data["economic"]
    assert "policy_by_exposure" in data["economic"]
    assert isinstance(data["surface_catalog"], list)
