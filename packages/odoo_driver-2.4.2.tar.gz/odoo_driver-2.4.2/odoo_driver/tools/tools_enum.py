from enum import Enum


class UomWeight(Enum):
    UOM_KILOGRAM = 1
    UOM_POUND = 2


class WeightType(Enum):
    NET = 1
    GROSS = 2
