import curses.ascii

NUL = chr(curses.ascii.NUL)  # \x00
STX = chr(curses.ascii.STX)  # \x02
CR = chr(curses.ascii.CR)  # \r

FF = chr(curses.ascii.FF)  # \x0c
US = chr(curses.ascii.US)  # \x1f
