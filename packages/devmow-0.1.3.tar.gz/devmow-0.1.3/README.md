# devmow

**devmow** is a CLI tool that instantly exposes your local development server to the internet and generates a QR code in your terminal — so you can test your web project on any mobile device without any setup, accounts, or paid services.

---

## Features

- Automatically detects active dev servers on common ports (3000, 5000, 5173, 8000, 8080)
- Creates a secure public tunnel using SSH — no tokens, no accounts, completely free
- Tries `localhost.run` first (no time limit), falls back to `Pinggy` automatically if unavailable
- Prints a scannable QR code directly in your terminal
- Copies the public URL to your clipboard
- Built-in static file server — useful if you're working with plain HTML files
- Checks for updates on every run and lets you update with a single keypress

---

## Installation

### Linux

```bash
pip install devmow
```

If `pip` is not found, try:

```bash
pip3 install devmow
```

### Windows

Open Command Prompt or PowerShell and run:

```powershell
pip install devmow
```

If you get a "pip not recognized" error:

```powershell
python -m pip install devmow
```

### macOS

```bash
pip3 install devmow
```

---

## Usage

### Auto-detect your running server

```bash
devmow
```

Just run this while your local dev server is active. devmow will find the port and create a tunnel automatically.

### Specify a port manually

```bash
devmow -p 3000
```

### Serve static HTML files

If you're working with plain `.html` files and don't have a dev server running, use:

```bash
devmow --serve
```

This starts a local static server in the current directory and tunnels it immediately. On Windows, open your terminal inside the folder that contains your HTML files before running this.

### Hide the QR code

```bash
devmow --no-qr
```

---

## Options

| Flag | Description |
|---|---|
| `-p`, `--port <port>` | Manually specify the port to expose |
| `--serve` | Start a built-in static file server in the current directory |
| `--no-qr` | Skip the QR code and only show the URL |

---

## How the tunnel works

devmow uses SSH reverse tunneling under the hood — the same technology used by tools like ngrok, but without any account or install required on the server side.

It tries providers in this order:

1. **localhost.run** — free, no account, no time limit
2. **Pinggy** — free fallback, sessions last up to 60 minutes
3. **serveo.net** — second fallback, free and no account needed

If a provider fails or is unreachable, devmow switches to the next one automatically.

---

## Auto-update

Every time you run devmow, it quietly checks PyPI for a newer version. If one is available, you'll see a prompt like this before the tool starts:

```
╔══════════════════════════════════════════╗
║  Update Available!                       ║
║  Current : v0.1.2                        ║
║  Latest  : v0.1.3                        ║
╚══════════════════════════════════════════╝
Update now? [y/n]:
```

Press `y` to update automatically, or `n` to skip and continue with the current version.

---

## Requirements

- Python 3.6 or higher
- OpenSSH installed on your system

### Installing OpenSSH

#### Arch / Manjaro

```bash
sudo pacman -S openssh
```

#### Ubuntu / Debian / Linux Mint

```bash
sudo apt install openssh-client
```

#### Fedora / RHEL / CentOS

```bash
sudo dnf install openssh
```

#### openSUSE

```bash
sudo zypper install openssh
```

#### Windows 10 / 11

Go to **Settings → Apps → Optional Features**, click **Add a feature**, search for **OpenSSH Client**, and install it. Then restart your terminal.

Alternatively, run this in PowerShell as Administrator:

```powershell
Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0
```

#### macOS

macOS comes with OpenSSH pre-installed. If it's missing for some reason:

```bash
brew install openssh
```

### Check if SSH is already installed

Run this in your terminal:

```bash
ssh -V
```

You should see something like `OpenSSH_9.x, OpenSSL ...`. If you see that, you're good to go.

---

## Author

Created by **Pankaj**

---

## License

MIT
