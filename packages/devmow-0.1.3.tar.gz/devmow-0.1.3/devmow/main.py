import argparse
import os
import psutil
import subprocess
import time
import re
import qrcode
import sys
import threading
import queue
import shutil
import http.server
import socketserver
import pyperclip
import urllib.request
import json
from colorama import init, Fore, Style

__version__ = "0.1.3"

init(autoreset=True)

COMMON_PORTS = [3000, 5000, 5173, 8000, 8080]


def check_for_update():
    try:
        with urllib.request.urlopen("https://pypi.org/pypi/devmow/json", timeout=3) as resp:
            data = json.loads(resp.read().decode())
        latest = data["info"]["version"]
    except Exception:
        return

    def parse_ver(v):
        return tuple(int(x) for x in v.strip().split("."))

    if parse_ver(latest) <= parse_ver(__version__):
        return

    print(f"\n{Fore.YELLOW}{Style.BRIGHT}╔══════════════════════════════════════════╗")
    print(f"║  Update Available!                       ║")
    print(f"║  Current : {Fore.RED}v{__version__:<31}{Fore.YELLOW}║")
    print(f"║  Latest  : {Fore.GREEN}v{latest:<31}{Fore.YELLOW}║")
    print(f"╚══════════════════════════════════════════╝{Style.RESET_ALL}")

    try:
        choice = input(f"{Fore.CYAN}Update now? [y/n]{Style.RESET_ALL}: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return

    if choice == "y":
        print(f"{Fore.GREEN}Updating...{Style.RESET_ALL}")
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "devmow"],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            print(f"{Fore.GREEN}Updated to v{latest}. Please re-run devmow.{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}Update failed. Try: pip install --upgrade devmow{Style.RESET_ALL}")
        sys.exit(0)
    else:
        print()


def detect_port():
    print(f"{Fore.CYAN}Scanning for active servers...{Style.RESET_ALL}")
    found = []

    try:
        for conn in psutil.net_connections(kind='inet'):
            if conn.status == 'LISTEN':
                if conn.laddr.port in COMMON_PORTS:
                    found.append(conn.laddr.port)

        if not found:
            for conn in psutil.net_connections(kind='inet'):
                if conn.status == 'LISTEN' and 1024 < conn.laddr.port < 10000:
                    found.append(conn.laddr.port)

        found = list(set(found))

        if not found:
            return None

        for p in COMMON_PORTS:
            if p in found:
                return p

        return found[0]

    except Exception as e:
        print(f"{Fore.YELLOW}Could not scan ports: {e}{Style.RESET_ALL}")
        return None


def ensure_ssh_key():
    """Generate an SSH key silently if the user doesn't have one."""
    ssh_dir = os.path.expanduser("~/.ssh")
    key_path = os.path.join(ssh_dir, "id_ed25519")

    if os.path.exists(key_path):
        return  # already have a key

    try:
        os.makedirs(ssh_dir, mode=0o700, exist_ok=True)
        subprocess.run(
            ["ssh-keygen", "-t", "ed25519", "-f", key_path, "-N", "", "-q"],
            check=True, capture_output=True
        )
    except Exception:
        pass  # not critical, tunnel may still work


def check_ssh():
    if not shutil.which("ssh"):
        print(f"\n{Fore.RED}ssh not found. devmow needs OpenSSH to create tunnels.{Style.RESET_ALL}")
        print(f"\n{Fore.YELLOW}Windows:{Style.RESET_ALL}")
        print("  Settings > Apps > Optional Features > Add > OpenSSH Client")
        print(f"\n{Fore.YELLOW}Linux:{Style.RESET_ALL}")
        print("  Ubuntu/Debian : sudo apt install openssh-client")
        print("  Arch          : sudo pacman -S openssh")
        print()
        sys.exit(1)

    ensure_ssh_key()


def start_local_server(port):
    class QuietHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            pass

    try:
        with socketserver.TCPServer(("", port), QuietHandler) as httpd:
            httpd.serve_forever()
    except Exception as e:
        print(f"{Fore.RED}Could not start local server: {e}{Style.RESET_ALL}")
        sys.exit(1)


def generate_qr(url, skip_qr=False):
    if not skip_qr:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=2,
        )
        qr.add_data(url)
        qr.make(fit=True)
        print(f"\n{Fore.GREEN}Scan with your phone:{Style.RESET_ALL}\n")
        qr.print_ascii(invert=True)

    print(f"\n{Fore.YELLOW}URL: {Style.BRIGHT}{url}{Style.RESET_ALL}\n")


def read_output(out, q):
    for line in iter(out.readline, ''):
        q.put(line)
    out.close()


SSH_COMMON_OPTS = [
    "-o", "StrictHostKeyChecking=no",
    "-o", "ServerAliveInterval=30",
    "-o", "BatchMode=yes",
    "-o", "PasswordAuthentication=no",
    "-o", "ConnectTimeout=10",
]

TUNNEL_PROVIDERS = [
    {
        "name": "localhost.run (443)",
        "cmd": lambda port: [
            "ssh", "-p", "443",
            f"-R80:localhost:{port}",
            "nokey@localhost.run",
        ] + SSH_COMMON_OPTS,
        "pattern": re.compile(r'(https://[a-zA-Z0-9-]+\.lhr\.life)'),
    },
    {
        "name": "localhost.run (80)",
        "cmd": lambda port: [
            "ssh", "-p", "80",
            f"-R80:localhost:{port}",
            "nokey@localhost.run",
        ] + SSH_COMMON_OPTS,
        "pattern": re.compile(r'(https://[a-zA-Z0-9-]+\.lhr\.life)'),
    },
    {
        "name": "Pinggy",
        "cmd": lambda port: [
            "ssh", "-p", "443",
            f"-R0:localhost:{port}",
            "a.pinggy.io",
        ] + SSH_COMMON_OPTS,
        "pattern": re.compile(r'(https://[a-zA-Z0-9.-]+\.pinggy[a-zA-Z0-9.-]*\.link)'),
    },
    {
        "name": "serveo.net",
        "cmd": lambda port: [
            "ssh", "-p", "443",
            f"-R80:localhost:{port}",
            "serveo.net",
        ] + SSH_COMMON_OPTS,
        "pattern": re.compile(r'(https://[a-zA-Z0-9-]+\.serveo\.net)'),
    },
]


def try_provider(port, provider):
    cmd = provider["cmd"](port)
    pattern = provider["pattern"]

    try:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1
        )

        q = queue.Queue()
        for stream in (proc.stdout, proc.stderr):
            t = threading.Thread(target=read_output, args=(stream, q))
            t.daemon = True
            t.start()

        url = None
        start = time.time()

        while True:
            if proc.poll() is not None:
                return None, None

            try:
                line = q.get(timeout=0.1)
                m = pattern.search(line)
                if m:
                    url = m.group(1)
                    if url.startswith("https://"):
                        break
                if not url:
                    m2 = re.search(r'(https://[^\s]+)', line)
                    if m2:
                        candidate = m2.group(1)
                        # skip known false positives from SSH warnings
                        if 'openssh.com' not in candidate and 'pinggy.io' not in candidate:
                            url = candidate
                            break
            except queue.Empty:
                pass

            if time.time() - start > 15:
                proc.terminate()
                return None, None

        if url:
            return proc, url

        proc.terminate()
        return None, None

    except Exception:
        return None, None


def start_tunnel(port, skip_qr=False):
    proc = None
    url = None

    for provider in TUNNEL_PROVIDERS:
        print(f"{Fore.CYAN}Connecting via {provider['name']}...{Style.RESET_ALL}")
        proc, url = try_provider(port, provider)
        if url:
            break
        print(f"{Fore.YELLOW}{provider['name']} failed, trying next...{Style.RESET_ALL}")

    if not url:
        print(f"{Fore.RED}Could not establish a tunnel. Check your internet connection.{Style.RESET_ALL}")
        sys.exit(1)

    try:
        pyperclip.copy(url)
        clipboard_note = f" {Fore.GREEN}(copied){Style.RESET_ALL}"
    except Exception:
        clipboard_note = ""

    generate_qr(url, skip_qr)
    print(f"{Fore.CYAN}Tunnel active. Press Ctrl+C to stop.{clipboard_note}{Style.RESET_ALL}")

    try:
        while proc.poll() is None:
            time.sleep(1)
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Stopped.{Style.RESET_ALL}")
        proc.terminate()
        sys.exit(0)


def main():
    parser = argparse.ArgumentParser(description="Expose your local dev server and get a QR code for mobile testing.")
    parser.add_argument("-p", "--port", type=int, help="Port to tunnel.")
    parser.add_argument("--serve", action="store_true", help="Start a static file server in the current directory.")
    parser.add_argument("--no-qr", action="store_true", help="Skip the QR code.")
    args = parser.parse_args()

    check_ssh()
    check_for_update()

    banner = f"""{Fore.CYAN}{Style.BRIGHT}
██████╗ ███████╗██╗   ██╗███╗   ███╗ ██████╗ ██╗    ██╗
██╔══██╗██╔════╝██║   ██║████╗ ████║██╔═══██╗██║    ██║
██║  ██║█████╗  ██║   ██║██╔████╔██║██║   ██║██║ █╗ ██║
██║  ██║██╔══╝  ╚██╗ ██╔╝██║╚██╔╝██║██║   ██║██║███╗██║
██████╔╝███████╗ ╚████╔╝ ██║ ╚═╝ ██║╚██████╔╝╚███╔███╔╝
╚═════╝ ╚══════╝  ╚═══╝  ╚═╝     ╚═╝ ╚═════╝  ╚══╝╚══╝
                                            by pankaj
{Style.RESET_ALL}"""
    print(banner)

    if args.serve:
        port = args.port if args.port else 8000
        print(f"{Fore.GREEN}Starting static server on port {port}...{Style.RESET_ALL}")
        t = threading.Thread(target=start_local_server, args=(port,))
        t.daemon = True
        t.start()
        time.sleep(0.5)
    else:
        port = args.port
        if not port:
            port = detect_port()
            if not port:
                print(f"{Fore.RED}No server found. Use -p to specify a port or --serve for static files.{Style.RESET_ALL}")
                sys.exit(1)
            print(f"{Fore.GREEN}Found server on port {port}{Style.RESET_ALL}")
        else:
            print(f"{Fore.GREEN}Using port {port}{Style.RESET_ALL}")

    start_tunnel(port, args.no_qr)


if __name__ == "__main__":
    main()
