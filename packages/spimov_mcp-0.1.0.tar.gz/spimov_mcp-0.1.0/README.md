# spimov-mcp

MCP server for Spimov — dub videos via Claude Desktop / Claude Code / any MCP client.

Two transports:
- **stdio** — runs locally, spawned by your MCP client, authenticated with `SPIMOV_API_KEY` env var.
- **HTTP/SSE** — long-lived server (we host at `mcp.spimov.com`), authenticated per-request with `Authorization: Bearer spk_live_...`.

Both transports are thin wrappers over the public REST API at `https://spimov.com/api/v1`. The same API key, the same daily request quota.

---

## 1. Get an API key

Sign in at https://spimov.com → **Settings → API keys → Create new key**. Copy the `spk_live_...` token shown once.

## 2a. Use via stdio (Claude Desktop)

Install:

```bash
pipx install git+https://github.com/erdememinaga/spimov.git#subdirectory=services/mcp
```

Add to `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "spimov": {
      "command": "spimov-mcp",
      "env": {
        "SPIMOV_API_KEY": "spk_live_xxxxxxxxxxxxxxxxxxxxxxxx"
      }
    }
  }
}
```

Restart Claude Desktop. The "spimov" MCP server should appear; ask Claude to "dub /Users/me/Movies/clip.mp4 into Turkish using Spimov".

## 2b. Use via HTTP/SSE (Claude Code / web clients)

Hosted endpoint: `https://mcp.spimov.com/sse`. Self-hosted: `MCP_PORT=8001 spimov-mcp-http`.

```json
{
  "mcpServers": {
    "spimov": {
      "url": "https://mcp.spimov.com/sse",
      "headers": {
        "Authorization": "Bearer spk_live_xxxxxxxxxxxxxxxxxxxxxxxx"
      }
    }
  }
}
```

## 3. Tools

| Tool | Purpose |
|---|---|
| `create_dub` | Upload a local file and queue a dubbing job. |
| `get_job_status` | Poll a job (queued / processing / review / completed / failed). |
| `list_jobs` | Recent jobs for the account. |
| `download_video` | Save the finished MP4 locally. |
| `get_subtitles` | Fetch SRT/VTT (any embedded language). |
| `cancel_job` | Cancel/delete. |
| `list_languages` | Source + target language list. |
| `get_quota` | Current minute & request usage vs. plan limits. |

## 4. Override the API base (dev)

```bash
SPIMOV_API_BASE=http://localhost:8000/api/v1 spimov-mcp
```
