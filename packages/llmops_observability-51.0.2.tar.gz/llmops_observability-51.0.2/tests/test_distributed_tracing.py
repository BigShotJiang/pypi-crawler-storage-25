import asyncio
import base64
import gzip
import json
from types import SimpleNamespace

import pytest

import llmops_observability.distributed_tracing as dt
import llmops_observability.sqs as sqs_mod
import llmops_observability.trace_manager as trace_manager_mod


class DummyRequest:
    def __init__(self, headers=None):
        self.headers = headers or {}


def test_get_injected_headers_default_empty():
    assert dt.get_injected_headers() == {}


def test_traceparent_helpers_and_parse_invalid():
    tp = dt._make_traceparent("a" * 32, "b" * 16)
    parsed = dt._parse_traceparent(tp)

    assert parsed == {"trace_id": "a" * 32, "parent_span_id": "b" * 16}
    assert dt._parse_traceparent("invalid") is None


def test_parse_traceparent_handles_exception_in_strip():
    class BadTraceparent(str):
        def strip(self, chars=None):
            raise RuntimeError("bad")

    assert dt._parse_traceparent(BadTraceparent("x")) is None


def test_sdk_version_fallback_on_unexpected_error(monkeypatch):
    import importlib.metadata

    monkeypatch.setattr(importlib.metadata, "version", lambda _name: (_ for _ in ()).throw(RuntimeError("x")))
    assert dt._sdk_version() == "0.0.0"


def test_build_span_dict_duration_and_default_fields():
    span = dt._build_span_dict(
        span_id="s1",
        span_name="name",
        span_type="tool",
        parent_span_id="p1",
        start_time=100.0,
        end_time=100.25,
        input_data={"k": "v"},
        output_data={"ok": True},
        metadata={"m": 1},
        status="success",
        error=None,
    )
    assert span["duration_ms"] == pytest.approx(250.0)
    assert span["span_id"] == "s1"
    assert span["metadata"] == {"m": 1}
    assert span["level"] == "DEFAULT"


def test_normalize_child_span_from_object_and_dict():
    obj = SimpleNamespace(
        span_id="1",
        span_name="child",
        span_type="span",
        parent_span_id="0",
        start_time=1.0,
        end_time=2.0,
        duration_ms=1000,
        input_data={"a": 1},
        output_data={"b": 2},
        error=None,
        model_id=None,
        metadata={"x": 1},
        tags=["t"],
        usage=None,
        prompt=None,
        response=None,
        status="success",
        status_message=None,
        level="DEFAULT",
    )
    out_obj = dt._normalize_child_span(obj)
    out_dict = dt._normalize_child_span({"span_id": "d"})

    assert out_obj["span_name"] == "child"
    assert out_obj["metadata"] == {"x": 1}
    assert out_dict == {"span_id": "d"}


def test_safe_input_and_output_helpers():
    def fn(request, user_id, flag=False):
        return user_id, flag

    request_obj = DummyRequest(headers={"x": "1"})
    safe_in = dt._safe_input((request_obj, "u1"), {"flag": True}, fn)

    class NonSerializable:
        def __str__(self):
            return "non-serializable"

    safe_out = dt._safe_output(NonSerializable())

    assert safe_in == {"user_id": "u1", "flag": "True"}
    assert safe_out == "non-serializable"


def test_send_child_segment_sqs_disabled(monkeypatch):
    sent = []
    monkeypatch.setattr(sqs_mod, "is_sqs_enabled", lambda: False)
    monkeypatch.setattr(sqs_mod, "send_to_sqs_immediate", lambda msg: sent.append(msg))

    dt._send_child_segment(
        trace_id="t" * 32,
        segment_id="seg1",
        service_name="svc",
        entry_span_id="e1",
        parent_span_id="p1",
        spans=[],
        project_id="p",
        environment="test",
        start_time=1.0,
        end_time=2.0,
    )

    assert sent == []


def test_send_child_segment_sqs_enabled(monkeypatch):
    sent = []
    monkeypatch.setattr(sqs_mod, "is_sqs_enabled", lambda: True)
    monkeypatch.setattr(sqs_mod, "send_to_sqs_immediate", lambda msg: sent.append(msg))

    dt._send_child_segment(
        trace_id="a" * 32,
        segment_id="seg2",
        service_name="svc",
        entry_span_id="e2",
        parent_span_id="p2",
        spans=[{"span_id": "x", "span_name": "child", "span_type": "span"}],
        project_id="proj",
        environment="uat",
        start_time=3.0,
        end_time=4.0,
    )

    assert len(sent) == 1
    [sent_message] = sent
    msg = json.loads(sent_message)
    assert msg["compressed"] is True
    raw = gzip.decompress(base64.b64decode(msg["data"]))
    payload = json.loads(raw.decode("utf-8"))
    assert payload["is_child_segment"] is True
    assert payload["trace_id"] == "a" * 32
    assert payload["project_id"] == "proj"
    assert payload["total_spans"] == 1


def test_track_external_service_sync_success_marks_external(monkeypatch):
    calls = {"marked": 0, "spans": []}

    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_current_parent_span_id", lambda: "p123")
    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_trace_id", lambda: "f" * 32)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "mark_has_external_segments",
        lambda: calls.__setitem__("marked", calls["marked"] + 1),
    )
    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "add_span",
        lambda span: calls["spans"].append(span),
    )

    @dt.track_external_service(service_name="user_service", transport="http")
    def fetch(user_id):
        headers = dt.get_injected_headers()
        assert headers["x-llmops-service"] == "user_service"
        assert headers["x-llmops-parent-span-id"] == "p123"
        assert "traceparent" in headers
        return {"ok": True}

    out = fetch("u1")

    assert out == {"ok": True}
    assert calls["marked"] == 1
    assert len(calls["spans"]) == 1
    assert calls["spans"][0].status == "success"
    assert calls["spans"][0].metadata["service_name"] == "user_service"
    assert dt.get_injected_headers() == {}


def test_track_external_service_error_and_failure_status_do_not_mark(monkeypatch):
    calls = {"marked": 0, "spans": []}

    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_current_parent_span_id", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_trace_id", lambda: "1" * 32)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "mark_has_external_segments",
        lambda: calls.__setitem__("marked", calls["marked"] + 1),
    )
    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "add_span",
        lambda span: calls["spans"].append(span),
    )

    @dt.track_external_service()
    def failed_result(payload):
        return {"status": "failed"}

    @dt.track_external_service(service_name="svc")
    def throws(payload):
        raise RuntimeError("boom")

    assert failed_result({"x": 1}) == {"status": "failed"}
    with pytest.raises(RuntimeError, match="boom"):
        throws({"x": 2})

    assert calls["marked"] == 0
    assert len(calls["spans"]) == 2
    assert calls["spans"][0].metadata["transport"] == "http"
    assert calls["spans"][1].status == "error"
    assert calls["spans"][1].error == "boom"


def test_track_external_service_infers_name_and_event_transport(monkeypatch):
    captured = []

    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_current_parent_span_id", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_trace_id", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "mark_has_external_segments", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "add_span", lambda span: captured.append(span))

    @dt.track_external_service()
    def emit_order_event(message):
        return {"ok": True}

    out = emit_order_event({"trace_context": {"a": 1}})

    assert out == {"ok": True}
    assert captured[0].metadata["transport"] == "event"
    assert captured[0].metadata["service_name"] == "emit_service"


def test_track_external_service_name_inference_service_token_and_fallback(monkeypatch):
    captured = []

    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_current_parent_span_id", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_trace_id", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "mark_has_external_segments", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "add_span", lambda span: captured.append(span))

    @dt.track_external_service()
    def call_user_service_profile(payload):
        return payload

    @dt.track_external_service()
    def get(payload):
        return payload

    call_user_service_profile({"ok": True})
    get({"ok": True})

    assert captured[0].metadata["service_name"] == "user_service"
    assert captured[1].metadata["service_name"] == "external_service"


def test_track_external_service_event_inference_from_kwargs_and_records(monkeypatch):
    captured = []

    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_current_parent_span_id", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "get_trace_id", lambda: "9" * 32)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "mark_has_external_segments", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "add_span", lambda span: captured.append(span))

    @dt.track_external_service()
    def call_service(payload=None, event=None):
        return {"ok": True}

    call_service(event={"x": 1})
    call_service({"Records": [{"id": 1}]})

    assert captured[0].metadata["transport"] == "event"
    assert captured[1].metadata["transport"] == "event"


@pytest.mark.asyncio
async def test_resume_external_service_headers_async_success(monkeypatch):
    calls = {"start": [], "push": [], "pop": 0, "end": 0, "send": []}

    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "start_child_trace",
        lambda trace_id, entry_span_id, service_name: calls["start"].append(
            (trace_id, entry_span_id, service_name)
        ),
    )
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda sid: calls["push"].append(sid))
    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "collect_child_spans",
        lambda: [{"span_id": "child1", "span_name": "s", "span_type": "span"}],
    )
    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "pop_span_context",
        lambda: calls.__setitem__("pop", calls["pop"] + 1),
    )
    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "end_child_trace",
        lambda: calls.__setitem__("end", calls["end"] + 1),
    )
    monkeypatch.setattr(dt, "_send_child_segment", lambda **kwargs: calls["send"].append(kwargs))

    tp = dt._make_traceparent("a" * 32, "b" * 16)
    req = DummyRequest(headers={"traceparent": tp, "x-llmops-service": "user_service"})

    @dt.resume_external_service(source="headers")
    async def get_profile(request, user_id):
        return {"user_id": user_id}

    result = await get_profile(req, "u-1")

    assert result == {"user_id": "u-1"}
    assert calls["start"][0][0] == "a" * 32
    assert calls["start"][0][2] == "user_service"
    assert len(calls["push"][0]) == 16
    assert calls["pop"] == 1
    assert calls["end"] == 1
    assert calls["send"][0]["trace_id"] == "a" * 32
    assert calls["send"][0]["parent_span_id"] == "b" * 16
    assert len(calls["send"][0]["spans"]) == 2
    assert calls["send"][0]["spans"][0]["span_type"] == "external_entry"


def test_resume_external_service_payload_sync_success(monkeypatch):
    calls = {"start": [], "send": []}

    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "start_child_trace",
        lambda trace_id, entry_span_id, service_name: calls["start"].append(
            (trace_id, entry_span_id, service_name)
        ),
    )
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "collect_child_spans", lambda: [])
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "end_child_trace", lambda: None)
    monkeypatch.setattr(dt, "_send_child_segment", lambda **kwargs: calls["send"].append(kwargs))

    @dt.resume_external_service(source="payload")
    def handle_event(event):
        return {"ok": True}

    payload = {
        "trace_context": {
            "x-llmops-trace-id": "c" * 32,
            "x-llmops-span-id": "d" * 16,
        }
    }
    out = handle_event(payload)

    assert out == {"ok": True}
    assert calls["start"][0][0] == "c" * 32
    assert calls["send"][0]["trace_id"] == "c" * 32
    assert calls["send"][0]["parent_span_id"] == "d" * 16
    assert calls["send"][0]["spans"][0]["metadata"]["source"] == "payload"


def test_resume_external_service_manual_and_no_trace_path(monkeypatch):
    calls = {"start": 0, "send": 0}
    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "start_child_trace",
        lambda trace_id, entry_span_id, service_name: calls.__setitem__("start", calls["start"] + 1),
    )
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "collect_child_spans", lambda: [])
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "end_child_trace", lambda: None)
    monkeypatch.setattr(
        dt,
        "_send_child_segment",
        lambda **kwargs: calls.__setitem__("send", calls["send"] + 1),
    )

    @dt.resume_external_service(source="manual", trace_id_override="e" * 32, parent_span_id_override="f" * 16)
    def manual_handler(x):
        return {"x": x}

    @dt.resume_external_service(source="headers")
    def no_trace(request):
        return {"ok": True}

    assert manual_handler(1) == {"x": 1}
    assert no_trace(DummyRequest(headers={})) == {"ok": True}
    assert calls["start"] == 1
    assert calls["send"] == 1


def test_resume_external_service_sync_error_path(monkeypatch):
    calls = {"send": []}

    monkeypatch.setattr(trace_manager_mod.TraceManager, "start_child_trace", lambda *args, **kwargs: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "collect_child_spans", lambda: [])
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "end_child_trace", lambda: None)
    monkeypatch.setattr(dt, "_send_child_segment", lambda **kwargs: calls["send"].append(kwargs))

    @dt.resume_external_service(source="manual", trace_id_override="7" * 32, parent_span_id_override="8" * 16)
    def boom(_x):
        raise ValueError("sync boom")

    with pytest.raises(ValueError, match="sync boom"):
        boom(1)

    assert calls["send"]
    assert calls["send"][0]["spans"][0]["status"] == "error"
    assert calls["send"][0]["spans"][0]["error"] == "sync boom"


@pytest.mark.asyncio
async def test_resume_external_service_async_error_and_no_trace(monkeypatch):
    calls = {"send": [], "start": 0}

    monkeypatch.setattr(
        trace_manager_mod.TraceManager,
        "start_child_trace",
        lambda *args, **kwargs: calls.__setitem__("start", calls["start"] + 1),
    )
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "collect_child_spans", lambda: [])
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "end_child_trace", lambda: None)
    monkeypatch.setattr(dt, "_send_child_segment", lambda **kwargs: calls["send"].append(kwargs))

    @dt.resume_external_service(source="headers")
    async def no_trace(request):
        return "ok"

    @dt.resume_external_service(source="manual", trace_id_override="9" * 32, parent_span_id_override="a" * 16)
    async def raise_async(_request):
        raise RuntimeError("async boom")

    out = await no_trace(DummyRequest(headers={}))
    assert out == "ok"
    assert calls["start"] == 0

    with pytest.raises(RuntimeError, match="async boom"):
        await raise_async(DummyRequest(headers={}))

    assert calls["send"]
    assert calls["send"][0]["spans"][0]["status"] == "error"


def test_resume_external_service_auto_infer_from_kwargs_and_payload_traceparent(monkeypatch):
    calls = {"send": []}

    monkeypatch.setattr(trace_manager_mod.TraceManager, "start_child_trace", lambda *args, **kwargs: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "collect_child_spans", lambda: [])
    monkeypatch.setattr(trace_manager_mod.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(trace_manager_mod.TraceManager, "end_child_trace", lambda: None)
    monkeypatch.setattr(dt, "_send_child_segment", lambda **kwargs: calls["send"].append(kwargs))

    @dt.resume_external_service()
    def by_request_kwarg(*, request):
        return {"ok": True}

    @dt.resume_external_service()
    def by_payload(payload):
        return {"ok": True}

    req_tp = dt._make_traceparent("1" * 32, "2" * 16)
    by_request_kwarg(request=DummyRequest(headers={"traceparent": req_tp}))

    payload_tp = dt._make_traceparent("3" * 32, "4" * 16)
    by_payload({"trace_context": {"traceparent": payload_tp}})

    assert len(calls["send"]) == 2
    assert calls["send"][0]["trace_id"] == "1" * 32
    assert calls["send"][1]["trace_id"] == "3" * 32


def test_safe_input_exception_and_safe_output_primitive_and_exception():
    assert dt._safe_input((1,), {}, object()) is None
    assert dt._safe_output(True) is True
    recursive = []
    recursive.append(recursive)
    out = dt._safe_output(recursive)
    assert out == str(recursive)


def test_resume_external_service_decorator_sync_wrapper_type():
    @dt.resume_external_service()
    def sync_fn():
        return "ok"

    assert callable(sync_fn)
    assert not asyncio.iscoroutinefunction(sync_fn)
