import builtins
import importlib
import urllib.request
from typing import Any, cast

import pytest

import llmops_observability.asgi_middleware as asgi_mod
import llmops_observability.config as config_mod
import llmops_observability.outbound_http as outbound_http
import llmops_observability
import llmops_observability.outbound_http_core as core
import llmops_observability.outbound_httpx as httpx_mod
import llmops_observability.outbound_urllib as urllib_mod
import llmops_observability.redaction as redaction


class BadHeaders:
    def __iter__(self):
        raise RuntimeError("bad headers")


def test_package_init_bedrock_importerror_branch(monkeypatch):
    real_import = builtins.__import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if "bedrock_instrumentation" in name:
            raise ImportError("forced")
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    importlib.reload(llmops_observability)

    assert llmops_observability.BEDROCK_INSTRUMENTATION_AVAILABLE is False
    assert llmops_observability.enable_bedrock_instrumentation is None
    assert llmops_observability.disable_bedrock_instrumentation is None
    assert llmops_observability.is_instrumentation_enabled is None

    monkeypatch.setattr(builtins, "__import__", real_import)
    importlib.reload(llmops_observability)


def test_outbound_http_core_edge_branches(monkeypatch):
    assert core.normalize_headers(BadHeaders()) == {}
    monkeypatch.setattr(core, "urlparse", lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("bad")))
    assert core.redact_url("https://example.com") == "https://example.com"

    class StrangePayload:
        def __str__(self):
            raise RuntimeError("no string")

    summary_unprintable = core.payload_summary(StrangePayload())
    assert summary_unprintable["preview"] == "<unprintable>"

    long_summary = core.payload_summary("x" * 600)
    assert long_summary["truncated"] is True
    assert long_summary["preview"].endswith("...")

    monkeypatch.setattr(core.TraceManager, "can_track_span", lambda: False)
    assert core.run_outbound_span_wrapped(
        library="requests",
        execute=lambda: "ok",
        extract_kwargs={},
        method="GET",
        url="https://example.com",
    ) == "ok"


@pytest.mark.asyncio
async def test_outbound_http_core_async_edge_branches(monkeypatch):
    monkeypatch.setattr(core.TraceManager, "can_track_span", lambda: False)

    async def execute_ok():
        return "ok-async"

    result = await core.run_outbound_span_wrapped_async(
        library="httpx-async",
        execute=execute_ok,
        extract_kwargs={},
        method="GET",
        url="https://example.com",
    )
    assert result == "ok-async"

    captured_spans = []
    monkeypatch.setattr(core.TraceManager, "can_track_span", lambda: True)
    monkeypatch.setattr(core.TraceManager, "_increment_pending_if_active", lambda: True)
    monkeypatch.setattr(core.TraceManager, "get_current_parent_span_id", lambda: "p1")
    monkeypatch.setattr(core.TraceManager, "push_span_context", lambda _sid: None)
    monkeypatch.setattr(core.TraceManager, "pop_span_context", lambda: None)
    monkeypatch.setattr(core.TraceManager, "add_span", lambda span: captured_spans.append(span))
    monkeypatch.setattr(core.TraceManager, "_decrement_pending", lambda: None)

    async def execute_fail():
        raise RuntimeError("async fail")

    with pytest.raises(RuntimeError, match="async fail"):
        await core.run_outbound_span_wrapped_async(
            library="httpx-async",
            execute=execute_fail,
            extract_kwargs={"headers": {}},
            method="GET",
            url="https://example.com",
        )

    assert captured_spans
    assert captured_spans[0].status == "error"


def test_outbound_urllib_edge_branches(monkeypatch):
    req = urllib.request.Request("https://example.com", method="POST")
    method, req_url, headers = urllib_mod._parse_urlopen_target(req, data=None)
    assert method == "POST"
    assert req_url == "https://example.com"
    assert isinstance(headers, dict)

    class RequestNoHeaderItems:
        full_url = "https://example.com/no-headers"

        @staticmethod
        def get_method():
            return "PUT"

    method2, req_url2, headers2 = urllib_mod._parse_urlopen_target(cast(Any, RequestNoHeaderItems()), data=None)
    assert method2 == "PUT"
    assert req_url2 == "https://example.com/no-headers"
    assert headers2 == {}

    assert urllib_mod._payload_preview(b"abc") == {
        "kind": "bytes",
        "size_bytes": 3,
        "preview": "<3 bytes>",
    }
    assert urllib_mod._payload_preview({"a": 1}) == {"a": 1}

    orig = urllib.request.urlopen
    monkeypatch.setattr(urllib_mod, "_original_urlopen", None)

    def fake_urlopen(url, data=None, **kwargs):
        return {"url": url, "data": data, "kwargs": kwargs}

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    result = cast(dict[str, Any], urllib_mod._instrumented_urlopen("https://example.com", data=b"x", timeout=1))
    assert result["url"] == "https://example.com"
    monkeypatch.setattr(urllib.request, "urlopen", orig)

    urllib_mod._patched = False
    urllib_mod._original_urlopen = None
    assert urllib_mod.disable_urllib_instrumentation() is True
    assert urllib_mod.is_urllib_instrumentation_enabled() is False

    urllib_mod._patched = True
    assert urllib_mod.enable_urllib_instrumentation() is True
    urllib_mod._patched = False


def test_outbound_httpx_importerror_and_state_branches(monkeypatch):
    real_import = builtins.__import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "httpx":
            raise ImportError("missing httpx")
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    assert httpx_mod.enable_httpx_instrumentation() is False

    httpx_mod._sync_patched = True
    httpx_mod._async_patched = True
    assert httpx_mod.disable_httpx_instrumentation() is True
    assert httpx_mod._sync_patched is False
    assert httpx_mod._async_patched is False

    httpx_mod._sync_patched = True
    httpx_mod._async_patched = False
    assert httpx_mod.is_httpx_instrumentation_enabled() is True

    monkeypatch.setattr(builtins, "__import__", real_import)


def test_outbound_http_requests_and_status_branches(monkeypatch):
    class DummySession:
        pass

    outbound_http._instrumentation_enabled = False
    outbound_http._original_session_request = lambda self, method, url, *args, **kwargs: {
        "method": method,
        "url": url,
    }
    out = cast(dict[str, Any], outbound_http._instrumented_session_request(DummySession(), "GET", "https://example.com"))
    assert out["method"] == "GET"

    outbound_http._instrumentation_enabled = True
    assert outbound_http.enable_requests_instrumentation() is True

    status = outbound_http.outbound_instrumentation_status()
    assert set(status.keys()) == {"requests", "httpx", "urllib"}


def test_asgi_middleware_skips_distributed_header_requests(monkeypatch):
    called = {"app": 0, "start": 0}

    async def downstream_app(scope, receive, send):
        called["app"] += 1
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b"ok"})

    monkeypatch.setattr(
        asgi_mod.TraceManager,
        "start_trace",
        lambda *args, **kwargs: called.__setitem__("start", called["start"] + 1),
    )

    mw = asgi_mod.LLMOpsASGIMiddleware(downstream_app)

    async def receive():
        return {"type": "http.request"}

    async def send(_message):
        return None

    scope = {
        "type": "http",
        "method": "GET",
        "path": "/x",
        "headers": [(b"traceparent", b"00-" + b"1" * 32 + b"-" + b"2" * 16 + b"-01")],
        "query_string": b"",
        "client": ("127.0.0.1", 1),
    }

    import asyncio

    asyncio.run(mw(scope, receive, send))
    assert called["app"] == 1
    assert called["start"] == 0


def test_config_import_load_dotenv_exception_branch(monkeypatch):
    import dotenv

    original = dotenv.load_dotenv
    monkeypatch.setattr(dotenv, "load_dotenv", lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("x")))
    importlib.reload(config_mod)

    assert hasattr(config_mod, "set_configuration")

    monkeypatch.setattr(dotenv, "load_dotenv", original)
    importlib.reload(config_mod)


def test_redaction_list_and_tuple_branches():
    TEST_PASSWORD_VALUE = "p"  # Move constant out of nested data structure
    payload = {
        "items": [
            {"token": "abc", "nested": ("safe", {"password": TEST_PASSWORD_VALUE})},
        ]
    }
    redacted = redaction.redact_deep(payload)
    assert redacted["items"][0]["token"] == redaction.REDACTED_VALUE
    assert redacted["items"][0]["nested"][1]["password"] == redaction.REDACTED_VALUE
