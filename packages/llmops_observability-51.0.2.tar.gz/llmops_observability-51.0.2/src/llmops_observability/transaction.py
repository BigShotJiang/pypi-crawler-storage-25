"""
Transaction lifecycle telemetry API.

Provides explicit transaction start/end APIs with guard rails and correlation.
"""
from __future__ import annotations

import functools
import inspect
import logging
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Optional

from .redaction import DEFAULT_SENSITIVE_KEYS, redact_deep
from .trace_manager import SpanData, TraceManager, ensure_json_object

logger = logging.getLogger(__name__)

TRANSACTION_SPAN_TYPE = "transaction"

_tx_lock = threading.Lock()
_tx_registry: Dict[str, Dict[str, Any]] = {}


def start_transaction(
    *,
    name: str = "transaction",
    metadata: Optional[Dict[str, Any]] = None,
    input_data: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    """
    Start a transaction lifecycle span and push it on the active stack.

    Returns transaction span id, or ``None`` if trace tracking is disabled.
    """
    if not TraceManager.can_track_span():
        logger.debug("start_transaction skipped: no active or finalized trace")
        return None
    if not isinstance(name, str) or not name.strip():
        raise ValueError("name must be a non-empty string")
    if metadata is not None and not isinstance(metadata, dict):
        raise ValueError("metadata must be a dictionary")
    if input_data is not None and not isinstance(input_data, dict):
        raise ValueError("input_data must be a dictionary")

    transaction_id = uuid.uuid4().hex
    now = time.time()
    parent_span_id = TraceManager.get_current_parent_span_id()
    base_metadata = {
        "transaction.kind": "lifecycle",
        "transaction.name": name.strip(),
        "transaction.state": "started",
    }
    if metadata:
        base_metadata.update(redact_deep(metadata, DEFAULT_SENSITIVE_KEYS))

    with _tx_lock:
        _tx_registry[transaction_id] = {
            "span_name": name.strip(),
            "parent_span_id": parent_span_id,
            "start_time": now,
            "metadata": base_metadata,
            "input_data": redact_deep(input_data or {}, DEFAULT_SENSITIVE_KEYS),
        }

    TraceManager.push_span_context(transaction_id)
    return transaction_id


def end_transaction(
    transaction_id: str,
    *,
    status: str = "success",
    output_data: Optional[Dict[str, Any]] = None,
    error: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> bool:
    """
    End a transaction and append the resulting span.

    Guard rails:
    - unknown/duplicate transaction ids return False
    - stack mismatch is logged and function still returns True once span is written
    """
    if not isinstance(transaction_id, str) or not transaction_id.strip():
        raise ValueError("transaction_id must be a non-empty string")
    if metadata is not None and not isinstance(metadata, dict):
        raise ValueError("metadata must be a dictionary")
    if output_data is not None and not isinstance(output_data, dict):
        raise ValueError("output_data must be a dictionary")

    with _tx_lock:
        info = _tx_registry.pop(transaction_id, None)
    if not info:
        logger.warning("end_transaction: unknown or already-ended transaction id=%s", transaction_id)
        return False

    popped = TraceManager.pop_span_context()
    if popped != transaction_id:
        logger.warning(
            "end_transaction: stack mismatch (expected %s, got %s)",
            transaction_id,
            popped,
        )

    end_time = time.time()
    start_time = float(info["start_time"])
    duration_ms = max(0, int((end_time - start_time) * 1000))
    status_norm = str(status).lower().strip() if status else "success"
    is_error = bool(error) or status_norm in {"error", "failed", "failure"}

    merged_metadata = dict(info["metadata"])
    merged_metadata["transaction.state"] = "ended"
    merged_metadata["transaction.duration_ms"] = duration_ms
    merged_metadata["transaction.status"] = "error" if is_error else "success"
    if error:
        merged_metadata["transaction.error"] = error
    if metadata:
        merged_metadata.update(redact_deep(metadata, DEFAULT_SENSITIVE_KEYS))

    span = SpanData(
        span_id=transaction_id,
        span_name=info["span_name"],
        span_type=TRANSACTION_SPAN_TYPE,
        parent_span_id=info.get("parent_span_id"),
        start_time=start_time,
        end_time=end_time,
        duration_ms=duration_ms,
        input_data=ensure_json_object(info.get("input_data", {}), key="transaction"),
        output_data=ensure_json_object(output_data or {}, key="result"),
        error=error,
        metadata=merged_metadata,
        tags=["transaction"],
        status="error" if is_error else "success",
        status_message=error,
    )
    TraceManager.add_span(span)
    return True


def get_open_transaction_ids() -> list[str]:
    """Return currently open transaction ids (for diagnostics/guard rails)."""
    with _tx_lock:
        return list(_tx_registry.keys())


@contextmanager
def transaction(
    *,
    name: str = "transaction",
    metadata: Optional[Dict[str, Any]] = None,
    input_data: Optional[Dict[str, Any]] = None,
) -> Iterator[Optional[str]]:
    """Context manager wrapper for start/end transaction APIs."""
    transaction_id = start_transaction(name=name, metadata=metadata, input_data=input_data)
    try:
        yield transaction_id
    except Exception as exc:
        if transaction_id:
            end_transaction(transaction_id, status="error", error=str(exc))
        raise
    else:
        if transaction_id:
            end_transaction(transaction_id, status="success")


def track_transaction(
    name: Optional[str] = None,
    *,
    metadata: Optional[Dict[str, Any]] = None,
) -> Any:
    """Decorator wrapper that creates one transaction span per function call."""

    async def _run_async_with_transaction(func, tx_name: str, tx_metadata, args, kwargs):
        txid = start_transaction(name=tx_name, metadata=tx_metadata)
        if not txid:
            return await func(*args, **kwargs)
        try:
            result = await func(*args, **kwargs)
            end_transaction(txid, status="success")
            return result
        except Exception as exc:
            end_transaction(txid, status="error", error=str(exc))
            raise

    def _run_sync_with_transaction(func, tx_name: str, tx_metadata, args, kwargs):
        txid = start_transaction(name=tx_name, metadata=tx_metadata)
        if not txid:
            return func(*args, **kwargs)
        try:
            result = func(*args, **kwargs)
            end_transaction(txid, status="success")
            return result
        except Exception as exc:
            end_transaction(txid, status="error", error=str(exc))
            raise

    def decorator(func):
        tx_name = name or func.__name__
        if inspect.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                return await _run_async_with_transaction(func, tx_name, metadata, args, kwargs)

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            return _run_sync_with_transaction(func, tx_name, metadata, args, kwargs)

        return sync_wrapper

    return decorator
