"""
Cross-cutting export hardening utilities.

- Deterministic idempotency keys
- Default payload redaction
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict

from .redaction import DEFAULT_SENSITIVE_KEYS, redact_deep


def canonical_json(value: Any) -> str:
    """Stable JSON representation for deterministic hashing."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def deterministic_idempotency_key(*parts: Any) -> str:
    """Build a deterministic idempotency key from stable parts."""
    seed = "||".join(str(p) for p in parts)
    return hashlib.sha256(seed.encode("utf-8")).hexdigest()


def ensure_idempotency_key(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ensure top-level event payload has deterministic idempotency key.

    If key is already present, payload is returned unchanged.
    """
    if "idempotency_key" in payload:
        return payload
    trace_id = payload.get("trace_id") or payload.get("original_trace_id") or "unknown_trace"
    event_type = payload.get("type") or payload.get("event_type") or "trace_data"
    payload["idempotency_key"] = deterministic_idempotency_key(trace_id, event_type, canonical_json(payload))
    return payload


def harden_trace_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Apply default redaction and deterministic idempotency keys to trace payload.
    """
    hardened = redact_deep(payload, DEFAULT_SENSITIVE_KEYS)
    trace_id = hardened.get("trace_id") or "unknown_trace"
    spans = hardened.get("spans", [])

    if isinstance(spans, list):
        for span in spans:
            if not isinstance(span, dict):
                continue
            span_id = span.get("span_id") or "unknown_span"
            span_type = span.get("span_type") or "span"
            span_key = deterministic_idempotency_key(trace_id, span_id, span_type)
            span["idempotency_key"] = span_key
            metadata = span.get("metadata") if isinstance(span.get("metadata"), dict) else {}
            metadata["idempotency_key"] = span_key
            span["metadata"] = metadata

    hardened["idempotency_key"] = deterministic_idempotency_key(
        trace_id,
        hardened.get("trace_name"),
        len(spans) if isinstance(spans, list) else 0,
    )
    return hardened

