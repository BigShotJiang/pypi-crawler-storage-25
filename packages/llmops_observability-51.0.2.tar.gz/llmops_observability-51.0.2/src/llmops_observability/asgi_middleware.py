"""
ASGI Middleware for FastAPI/Starlette Applications
Automatically traces all HTTP requests with full observability.
"""
import asyncio
import time
import os
import socket
import json
from contextvars import copy_context
from urllib.parse import parse_qs
from typing import Optional, Dict, Any, Tuple

from .trace_manager import TraceManager

HTTP_METHOD_KEY = "http.method"
HTTP_PATH_KEY = "http.path"
HTTP_QUERY_STRING_KEY = "http.query_string"
HTTP_QUERY_PARAMS_KEY = "http.query_params"
HTTP_REQUEST_BODY_KEY = "http.request_body"
HTTP_REQUEST_CONTENT_TYPE_KEY = "http.request_content_type"


class LLMOpsASGIMiddleware:
    """
    ASGI middleware for automatic HTTP request tracing.
    
    Captures:
    - Request method, path, headers
    - User and session identifiers
    - Response body and status
    - Request latency
    - Automatic trace lifecycle management
    
    Usage:
        from fastapi import FastAPI
        from llmops_observability import LLMOpsASGIMiddleware
        
        app = FastAPI()
        app.add_middleware(LLMOpsASGIMiddleware, service_name="my_api")
    """

    def __init__(self, app, service_name: Optional[str] = None):
        """
        Initialize ASGI middleware.
        
        Args:
            app: ASGI application instance
            service_name: Custom service name for traces. 
                         If None, uses "{project}_{hostname}" format.
        """
        self.app = app
        self.service_name = service_name

    def get_trace_name(self, path: Optional[str] = None) -> str:
        """
        Generate trace name from request path.

        The path (stripped of its leading ``/``) is used as the trace name so
        that, for example, ``POST /generate`` produces ``"generate"`` and
        ``POST /generate/v2`` produces ``"generate/v2"``.

        When no path is provided (legacy / non-HTTP usage) the name falls back
        to the configured ``service_name`` or ``"{project}_{hostname}"``.

        Returns:
            Trace name derived from the request path, or a fallback name.
        """
        if path and path != "/":
            return path.lstrip("/")

        if self.service_name:
            return self.service_name

        project = os.path.basename(os.getcwd())
        hostname = socket.gethostname()
        return f"{project}_{hostname}"

    @staticmethod
    def _normalize_query_params(query_string: str) -> Dict[str, Any]:
        parsed = parse_qs(query_string, keep_blank_values=True)
        normalized: Dict[str, Any] = {}
        for key, values in parsed.items():
            normalized[key] = values[0] if len(values) == 1 else values
        return normalized

    @staticmethod
    def _decode_body(body: bytes) -> Any:
        if not body:
            return None
        try:
            return body.decode("utf-8")
        except UnicodeDecodeError:
            return f"<binary data: {len(body)} bytes>"

    def _normalize_request_body(self, content_type: str, request_body: bytes) -> Any:
        if not request_body:
            return None

        decoded_body = self._decode_body(request_body)
        normalized_content_type = content_type.split(";", 1)[0].strip().lower()

        if normalized_content_type == "application/json" and isinstance(decoded_body, str):
            try:
                return json.loads(decoded_body)
            except json.JSONDecodeError:
                return decoded_body

        if normalized_content_type == "application/x-www-form-urlencoded" and isinstance(decoded_body, str):
            return self._normalize_query_params(decoded_body)

        return decoded_body

    def _build_trace_input(
        self,
        method: str,
        path: str,
        query_string: str,
        headers: Dict[str, str],
        request_body: bytes,
    ) -> Dict[str, Any]:
        trace_input: Dict[str, Any] = {
            HTTP_METHOD_KEY: method,
            HTTP_PATH_KEY: path,
            HTTP_QUERY_STRING_KEY: query_string,
        }

        query_params = self._normalize_query_params(query_string)
        if query_params:
            trace_input[HTTP_QUERY_PARAMS_KEY] = query_params

        content_type = headers.get("content-type", "")
        normalized_request_body = self._normalize_request_body(content_type, request_body)
        if normalized_request_body is not None:
            trace_input[HTTP_REQUEST_BODY_KEY] = normalized_request_body
            if content_type:
                trace_input[HTTP_REQUEST_CONTENT_TYPE_KEY] = content_type

        return trace_input

    @staticmethod
    def _decode_response_body(body: Any) -> Optional[str]:
        decoded = LLMOpsASGIMiddleware._decode_body(body)
        if decoded is None:
            return None
        return decoded if isinstance(decoded, str) else str(decoded)

    @staticmethod
    def _extract_sse_json(line: str) -> Optional[Dict[str, Any]]:
        if not line.startswith("data:"):
            return None

        payload = line[5:].strip()
        if not payload:
            return None

        try:
            obj = json.loads(payload)
        except json.JSONDecodeError:
            return None

        return obj if isinstance(obj, dict) else None

    @staticmethod
    def _extract_message_text(message: Dict[str, Any]) -> Optional[str]:
        content = message.get("content")
        if not isinstance(content, list):
            return None

        text_parts: list[str] = []
        for item in content:
            if isinstance(item, dict):
                text_val = item.get("text")
                if isinstance(text_val, str):
                    text_parts.append(text_val)

        combined = "".join(text_parts).strip()
        return combined or None

    @staticmethod
    def _extract_delta_text(obj: Dict[str, Any]) -> Optional[str]:
        event = obj.get("event")
        if not isinstance(event, dict):
            return None

        cbd = event.get("contentBlockDelta")
        if not isinstance(cbd, dict):
            return None

        delta = cbd.get("delta")
        if not isinstance(delta, dict):
            return None

        txt = delta.get("text")
        return txt if isinstance(txt, str) else None

    @staticmethod
    def _update_sse_message_candidates(
        obj: Dict[str, Any],
        final_result_text: Optional[str],
        final_assistant_text: Optional[str],
        delta_parts: list[str],
    ) -> Tuple[Optional[str], Optional[str]]:
        result_val = obj.get("result")
        if isinstance(result_val, str) and result_val.strip():
            final_result_text = result_val.strip()

        message = obj.get("message")
        if isinstance(message, dict):
            msg_text = LLMOpsASGIMiddleware._extract_message_text(message)
            if msg_text:
                final_assistant_text = msg_text

        delta_text = LLMOpsASGIMiddleware._extract_delta_text(obj)
        if delta_text:
            delta_parts.append(delta_text)

        return final_result_text, final_assistant_text

    @staticmethod
    def _extract_final_sse_message(raw_sse_body: Optional[str]) -> Optional[str]:
        """Extract a clean final assistant message from SSE `data:` frames."""
        if not raw_sse_body:
            return None

        final_result_text: Optional[str] = None
        final_assistant_text: Optional[str] = None
        delta_parts: list[str] = []

        for line in raw_sse_body.splitlines():
            obj = LLMOpsASGIMiddleware._extract_sse_json(line)
            if not obj:
                continue

            final_result_text, final_assistant_text = (
                LLMOpsASGIMiddleware._update_sse_message_candidates(
                    obj,
                    final_result_text,
                    final_assistant_text,
                    delta_parts,
                )
            )

        if final_result_text:
            return final_result_text
        if final_assistant_text:
            return final_assistant_text
        if delta_parts:
            return "".join(delta_parts).strip() or None
        return None

    @staticmethod
    async def _capture_request_messages(receive) -> Tuple[list[Dict[str, Any]], bytes]:
        buffered_messages: list[Dict[str, Any]] = []
        request_body_chunks: list[bytes] = []

        while True:
            message = await receive()
            buffered_messages.append(message)

            if message.get("type") != "http.request":
                break

            body = message.get("body", b"")
            if body:
                request_body_chunks.append(body)

            if not message.get("more_body", False):
                break

        return buffered_messages, b"".join(request_body_chunks)

    def _finalize_error(
        self,
        *,
        trace_input: Dict[str, Any],
        start_time: float,
        exc: Exception,
    ) -> None:
        latency_ms = int((time.time() - start_time) * 1000)
        TraceManager.finalize_and_send(
            trace_input=trace_input,
            trace_output={
                "error": str(exc),
                "error_type": type(exc).__name__,
                "http.status_code": 500,
                "http.latency_ms": latency_ms,
            },
        )

    def _update_spans_with_trace_data(self) -> None:
        """Post-process spans to inject traced model_id and accumulated usage after streaming completes."""
        model_id = TraceManager.get_trace_model_id()
        usage = TraceManager.get_trace_usage()
        
        if not model_id and not usage:
            return  # No trace-level data to inject
        
        with TraceManager._lock:
            spans = TraceManager._active.get("spans", [])
            for span in spans:
                # Only update agent/generation spans with model_id (not tools)
                if span.span_type in ("agent", "generation"):
                    if model_id and not span.model_id:
                        span.model_id = model_id
                    # Only update usage if not already set (generation likely set it)
                    if usage and not span.usage:
                        span.usage = usage

    def _update_response_spans_with_body(self, response_body: Optional[str]) -> None:
        """Post-process spans to replace placeholder response objects with actual response body."""
        if not response_body:
            return

        def _is_placeholder_response(value: Any) -> bool:
            if not isinstance(value, str) or "<" not in value:
                return False
            return any(
                marker in value
                for marker in (
                    "StreamingResponse",
                    "Response",
                    "async_generator object",
                    "generator object",
                    "coroutine object",
                )
            )
        
        # Get active spans from TraceManager and update them
        with TraceManager._lock:
            spans = TraceManager._active.get("spans", [])
            for span in spans:
                # Update output_data.output field
                if span.output_data and isinstance(span.output_data, dict):
                    output = span.output_data.get("output")
                    # Replace captured placeholder objects with the actual response body.
                    if _is_placeholder_response(output):
                        # Replace with extracted response body
                        span.output_data["output"] = response_body
                
                # Also update span.response field if it contains object reference
                if _is_placeholder_response(span.response):
                    span.response = response_body

    def _finalize_success(
        self,
        *,
        trace_input: Dict[str, Any],
        start_time: float,
        response_status: Optional[int],
        response_body: Optional[str],
        response_is_streaming: bool,
    ) -> None:
        latency_ms = int((time.time() - start_time) * 1000)

        trace_output = {
            "http.status_code": response_status or 200,
            "http.latency_ms": latency_ms,
            "response_body": response_body,
        }

        if response_is_streaming:
            trace_output["response_type"] = "streaming"
            trace_output["notes"] = "Streaming/SSE response detected"

        TraceManager.finalize_and_send(
            trace_input=trace_input,
            trace_output=trace_output,
        )

    def _extract_request_context(self, scope: Dict[str, Any]) -> Tuple[str, str, str]:
        method = scope.get("method", "UNKNOWN")
        path = scope.get("path", "UNKNOWN")
        query_string = scope.get("query_string", b"").decode()

        headers = {k.decode(): v.decode() for k, v in scope.get("headers", [])}

        # Accept both header naming styles; TraceManager.update can override later.
        user_id = (
            headers.get("x-user_id")
            or headers.get("x-user-id")
            or "anonymous"
        )
        session_id = (
            headers.get("x-session_id")
            or headers.get("x-session-id")
            or "anonymous"
        )
        user_agent = headers.get("user-agent", "unknown")
        client = scope.get("client")
        client_ip = client[0] if client else "unknown"

        trace_name = self.get_trace_name(path)
        TraceManager.start_trace(
            trace_name,
            user_id=user_id,
            session_id=session_id,
            metadata={
                HTTP_METHOD_KEY: method,
                HTTP_PATH_KEY: path,
                HTTP_QUERY_STRING_KEY: query_string,
                "http.user_agent": user_agent,
                "http.client_ip": client_ip,
                "service.name": self.service_name or trace_name,
            },
        )
        return method, path, query_string

    @staticmethod
    def _should_skip_tracing(scope: Dict[str, Any]) -> bool:
        if scope.get("type") != "http":
            return True

        headers = {k.decode(): v.decode() for k, v in scope.get("headers", [])}
        return bool(headers.get("traceparent") or headers.get("x-llmops-trace-id"))

    @staticmethod
    def _create_send_wrapper(send, state: Dict[str, Any]):
        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                state["response_status"] = message.get("status", 500)

            if message["type"] == "http.response.body":
                body_chunk = message.get("body", b"")
                if body_chunk:
                    state["response_body_chunks"].append(body_chunk)

                if message.get("more_body", False):
                    state["response_is_streaming"] = True

            await send(message)

        return send_wrapper

    async def __call__(self, scope, receive, send):
        """
        ASGI middleware entry point.
        
        Args:
            scope: ASGI connection scope
            receive: ASGI receive channel
            send: ASGI send channel
        """
        if self._should_skip_tracing(scope):
            await self.app(scope, receive, send)
            return

        headers = {k.decode(): v.decode() for k, v in scope.get("headers", [])}

        method, path, query_string = self._extract_request_context(scope)
        buffered_messages, request_body = await self._capture_request_messages(receive)

        start_time = time.time()
        state = {
            "response_status": None,
            "response_body_chunks": [],
            "response_is_streaming": False,
        }

        async def receive_wrapper():
            if buffered_messages:
                return buffered_messages.pop(0)
            return await receive()
        
        send_wrapper = self._create_send_wrapper(send, state)

        try:
            # Execute the application
            await self.app(scope, receive_wrapper, send_wrapper)
            
        except Exception as exc:
            # Capture exception and finalize trace with error
            trace_input = self._build_trace_input(
                method,
                path,
                query_string,
                headers,
                request_body,
            )
            self._finalize_error(
                trace_input=trace_input,
                start_time=start_time,
                exc=exc,
            )
            raise

        trace_input = self._build_trace_input(
            method,
            path,
            query_string,
            headers,
            request_body,
        )

        full_response_bytes = b"".join(state["response_body_chunks"])
        response_body = self._decode_response_body(full_response_bytes)

        if state["response_is_streaming"]:
            extracted_message = self._extract_final_sse_message(response_body)
            if extracted_message:
                response_body = extracted_message

        # Capture values needed by the finalizer before handing off to the thread.
        _trace_input = trace_input
        _response_body = response_body
        _response_status = state["response_status"]
        _response_is_streaming = state["response_is_streaming"]
        _start_time = start_time

        def _finalize_in_thread():
            # Update spans with trace-level data captured during streaming (model_id, usage)
            self._update_spans_with_trace_data()
            # Update any spans that have Response objects with the actual response body
            self._update_response_spans_with_body(_response_body)
            # Normal completion - finalize trace with response data
            # _wait_for_pending() inside finalize_and_send blocks until all @track_function
            # spans complete; running this in a thread keeps the event loop free.
            self._finalize_success(
                trace_input=_trace_input,
                start_time=_start_time,
                response_status=_response_status,
                response_body=_response_body,
                response_is_streaming=_response_is_streaming,
            )

        loop = asyncio.get_event_loop()
        context = copy_context()
        await loop.run_in_executor(None, context.run, _finalize_in_thread)
