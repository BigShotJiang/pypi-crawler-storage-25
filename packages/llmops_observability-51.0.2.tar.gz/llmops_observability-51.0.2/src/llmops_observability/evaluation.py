"""
Response evaluation telemetry — record score, label, and rationale.
"""
from __future__ import annotations

import logging
import math
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Union

from .redaction import DEFAULT_SENSITIVE_KEYS, redact_deep
from .trace_manager import SpanData, TraceManager, ensure_json_object

logger = logging.getLogger(__name__)

EVALUATION_SPAN_TYPE = "evaluation"


@dataclass(frozen=True)
class EvaluationResult:
    """Normalized evaluation result for a single criterion."""

    criterion: str
    score: float
    label: str
    rationale: str


JudgeCallable = Callable[[str, str, str, Dict[str, Any]], EvaluationResult]


def _default_judge(
    criterion: str,
    prompt: str,
    response: str,
    context: Dict[str, Any],
) -> EvaluationResult:
    """
    Default internal judge.

    This is a safe built-in fallback so evaluation remains zero-config and
    non-blocking. It uses lightweight heuristics and can be replaced later by
    a provider-backed LLM-as-a-judge adapter without changing decorator UX.
    """
    _ = prompt
    _ = context
    cleaned = (response or "").strip()
    if not cleaned:
        return EvaluationResult(
            criterion=criterion,
            score=0.0,
            label="fail",
            rationale="Response was empty.",
        )
    if len(cleaned) < 20:
        return EvaluationResult(
            criterion=criterion,
            score=0.45,
            label="review",
            rationale="Response is very short and may be incomplete.",
        )
    return EvaluationResult(
        criterion=criterion,
        score=0.8,
        label="pass",
        rationale="Response is non-empty and contains substantive content.",
    )


def evaluate_response(
    *,
    evals: List[str],
    prompt: str,
    response: str,
    judge: Optional[JudgeCallable] = None,
    context: Optional[Dict[str, Any]] = None,
) -> List[EvaluationResult]:
    """
    Evaluate a response against the requested criteria.

    The engine is intentionally decoupled from tracing. Decorators call this
    and then publish results via `record_evaluation`.
    """
    judge_fn = judge or _default_judge
    eval_context = context or {}
    results: List[EvaluationResult] = []
    for criterion in evals:
        normalized = criterion.strip().lower()
        if not normalized:
            continue
        results.append(judge_fn(normalized, prompt, response, eval_context))
    return results


def _validate_non_empty_string(value: Optional[str], field: str) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{field} must be a string")
    trimmed = value.strip()
    if not trimmed:
        raise ValueError(f"{field} must not be empty")
    return trimmed


def _validate_score(score: Optional[Union[float, int]]) -> Optional[float]:
    if score is None:
        return None
    if isinstance(score, bool) or not isinstance(score, (int, float)):
        raise ValueError("score must be a number")
    score_value = float(score)
    if not math.isfinite(score_value):
        raise ValueError("score must be a finite number")
    return score_value


def _validate_evaluator_metadata(
    evaluator_metadata: Optional[Dict[str, Any]],
    metadata: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    if evaluator_metadata is not None and not isinstance(evaluator_metadata, dict):
        raise ValueError("evaluator_metadata must be a dictionary")
    if metadata is not None and not isinstance(metadata, dict):
        raise ValueError("metadata must be a dictionary")

    merged: Dict[str, Any] = {}
    if metadata:
        merged.update(metadata)
    if evaluator_metadata:
        merged["evaluator"] = evaluator_metadata
    return merged


def _resolve_trace_id(explicit_trace_id: Optional[str]) -> Optional[str]:
    active_trace_id = TraceManager._active.get("trace_id")
    finalized_trace_id = TraceManager._active.get("finalized_trace_id")

    if explicit_trace_id is not None:
        trace_id = _validate_non_empty_string(explicit_trace_id, "trace_id")
        if trace_id is None:
            return None
        if active_trace_id and trace_id != active_trace_id:
            raise ValueError(
                f"trace_id '{trace_id}' does not match active trace '{active_trace_id}'"
            )
        if not active_trace_id and finalized_trace_id and trace_id != finalized_trace_id:
            raise ValueError(
                f"trace_id '{trace_id}' does not match finalized trace '{finalized_trace_id}'"
            )
        if not active_trace_id and not finalized_trace_id:
            logger.debug("record_evaluation skipped: no active or finalized trace")
            return None
        return trace_id

    return active_trace_id or finalized_trace_id


def record_evaluation(
    *,
    score: Optional[Union[float, int]] = None,
    label: Optional[str] = None,
    rationale: Optional[str] = None,
    name: str = "evaluation",
    trace_id: Optional[str] = None,
    evaluated_span_id: Optional[str] = None,
    parent_span_id: Optional[str] = None,
    evaluator_metadata: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    """
    Record a response evaluation as a child span on the current trace.

    Uses the span context stack: the evaluation's parent defaults to
    ``TraceManager.get_current_parent_span_id()`` so it nests under the
    innermost active span (e.g. a generation). Pass ``parent_span_id`` to
    override, or set ``evaluated_span_id`` to reference which span was scored
    (correlation only; does not change parent linkage).

    The SDK can correlate using active context or explicit identifiers:
    - ``trace_id``: must match current active/finalized trace when provided
    - ``parent_span_id``: explicit parent override for nesting
    - ``evaluated_span_id``: downstream response span being evaluated

    Returns the new evaluation span id, or ``None`` if there is no trace to
    attach to (and nothing was recorded).
    """
    if score is None and label is None and rationale is None:
        raise ValueError("at least one of score, label, or rationale must be provided")

    span_name = _validate_non_empty_string(name, "name")
    if span_name is None:
        raise ValueError("name must not be empty")
    score_value = _validate_score(score)
    label_value = _validate_non_empty_string(label, "label")
    rationale_value = _validate_non_empty_string(rationale, "rationale")
    evaluated_span_id_value = _validate_non_empty_string(evaluated_span_id, "evaluated_span_id")
    parent_span_override = _validate_non_empty_string(parent_span_id, "parent_span_id")

    resolved_trace_id = _resolve_trace_id(trace_id)
    if resolved_trace_id is None:
        logger.debug("record_evaluation skipped: no active or finalized trace")
        return None

    span_id = uuid.uuid4().hex
    parent = (
        parent_span_override
        if parent_span_override is not None
        else TraceManager.get_current_parent_span_id()
    )
    now = time.time()

    merged_meta: Dict[str, Any] = {
        "evaluation.kind": "response",
        "evaluation.trace_id": resolved_trace_id,
    }
    merged_meta.update(
        redact_deep(
            _validate_evaluator_metadata(evaluator_metadata, metadata),
            DEFAULT_SENSITIVE_KEYS,
        )
    )

    payload: Dict[str, Any] = {
        "score": score_value,
        "label": label_value,
        "rationale": rationale_value,
        "trace_id": resolved_trace_id,
        "evaluated_span_id": evaluated_span_id_value,
        "parent_span_id": parent,
    }
    payload = {k: v for k, v in payload.items() if v is not None}

    span = SpanData(
        span_id=span_id,
        span_name=span_name,
        span_type=EVALUATION_SPAN_TYPE,
        parent_span_id=parent,
        start_time=now,
        end_time=now,
        duration_ms=0,
        input_data=ensure_json_object({"evaluation": payload}),
        output_data=ensure_json_object({}),
        error=None,
        metadata=merged_meta,
        tags=["evaluation"],
        status="success",
        status_message=None,
    )
    TraceManager.add_span(span)
    return span_id
