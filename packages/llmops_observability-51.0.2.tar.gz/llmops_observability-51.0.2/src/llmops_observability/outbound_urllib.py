"""
``urllib.request.urlopen`` instrumentation (stdlib, synchronous).

Covers simple HTTP/HTTPS calls that use the standard library instead of ``requests``/``httpx``.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional, Tuple, Union

import urllib.request

from .outbound_http_core import run_outbound_span_wrapped

logger = logging.getLogger(__name__)

_original_urlopen: Optional[Any] = None
_patched = False


def _parse_urlopen_target(
    url: Union[str, urllib.request.Request],
    data: Any,
) -> Tuple[str, str, Dict[str, Any]]:
    if hasattr(url, "full_url"):
        req_url = url.full_url
        method = url.get_method() if hasattr(url, "get_method") else "GET"
        if hasattr(url, "header_items"):
            headers = dict(url.header_items())
        else:
            headers = {}
    else:
        req_url = str(url)
        method = "POST" if data is not None else "GET"
        headers = {}
    return method.upper(), req_url, headers


def _payload_preview(data: Any) -> Any:
    if data is None:
        return None
    if isinstance(data, (bytes, bytearray)):
        n = len(data)
        return {"kind": "bytes", "size_bytes": n, "preview": f"<{n} bytes>"}
    return data


def _instrumented_urlopen(url, data=None, **kwargs):
    if _original_urlopen is None:
        return urllib.request.urlopen(url, data=data, **kwargs)

    method, req_url, headers = _parse_urlopen_target(url, data)

    def execute():
        return _original_urlopen(url, data=data, **kwargs)

    extract_kwargs: Dict[str, Any] = {
        "headers": headers,
        "data": _payload_preview(data),
        "json": None,
        "timeout": kwargs.get("timeout"),
    }

    return run_outbound_span_wrapped(
        library="urllib",
        execute=execute,
        extract_kwargs=extract_kwargs,
        method=method,
        url=req_url,
    )


def enable_urllib_instrumentation() -> bool:
    """Patch ``urllib.request.urlopen``."""
    global _original_urlopen, _patched
    if _patched:
        return True
    try:
        _original_urlopen = urllib.request.urlopen
        urllib.request.urlopen = _instrumented_urlopen
        _patched = True
        logger.info("[HTTP Instrumentation] urllib.request.urlopen patched")
        return True
    except Exception as exc:
        _patched = False
        logger.warning("[HTTP Instrumentation] failed to enable urllib instrumentation: %s", exc)
        return False


def disable_urllib_instrumentation() -> bool:
    """Restore original ``urlopen``."""
    global _patched
    if not _patched or _original_urlopen is None:
        return True
    try:
        urllib.request.urlopen = _original_urlopen
        _patched = False
        logger.info("[HTTP Instrumentation] urllib.request.urlopen restored")
        return True
    except Exception as exc:
        logger.warning("[HTTP Instrumentation] failed to disable urllib instrumentation: %s", exc)
        return False


def is_urllib_instrumentation_enabled() -> bool:
    return _patched
