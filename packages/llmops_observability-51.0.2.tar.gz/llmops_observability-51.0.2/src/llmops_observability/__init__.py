"""
LLMOps Observability SDK - Public API
Minimal SDK focused on:
- Trace collection via decorators (@track_function, @track_llm_call)
- Single-message SQS dispatch with compression
- ASGI middleware for FastAPI/Starlette auto-tracing
- Automatic Bedrock model_id capture (optional)
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("llmops-observability")
except PackageNotFoundError:
    __version__ = "0.0.0"

# Core components
from .trace_manager import TraceManager, track_function
from .llm import track_llm_call, track_llm_agent, track_llm_tool
from .config import (
    get_default_model,
    get_environment,
    get_project_id,
    get_sqs_config,
    get_trace_context,
    set_configuration,
)
from .distributed_tracing import track_external_service, resume_external_service, get_injected_headers
from .s3_extended_client import get_s3_extended_client
from .sqs import send_to_sqs, send_to_sqs_immediate, flush_sqs, is_sqs_enabled
from .asgi_middleware import LLMOpsASGIMiddleware
from .outbound_http import (
    disable_outbound_http_instrumentation,
    enable_outbound_http_instrumentation,
    enable_requests_instrumentation,
    disable_requests_instrumentation,
    is_requests_instrumentation_enabled,
    outbound_instrumentation_status,
)
from .outbound_httpx import (
    disable_httpx_instrumentation,
    enable_httpx_instrumentation,
    is_httpx_instrumentation_enabled,
)
from .outbound_urllib import (
    disable_urllib_instrumentation,
    enable_urllib_instrumentation,
    is_urllib_instrumentation_enabled,
)
from .evaluation import EVALUATION_SPAN_TYPE, record_evaluation
from .transaction import (
    TRANSACTION_SPAN_TYPE,
    end_transaction,
    get_open_transaction_ids,
    start_transaction,
    track_transaction,
    transaction,
)
from .crawl import (
    CRAWL_EVENT_SPAN_TYPE,
    CRAWL_PAGE_SPAN_TYPE,
    CRAWL_SESSION_SPAN_TYPE,
    crawl_session,
    end_crawl_session,
    record_crawl_event,
    record_crawl_page,
    start_crawl_session,
)

# Bedrock auto-instrumentation (optional - requires boto3)
try:
    from .bedrock_instrumentation import (
        enable_bedrock_instrumentation,
        disable_bedrock_instrumentation,
        is_instrumentation_enabled,
    )
    BEDROCK_INSTRUMENTATION_AVAILABLE = True
except ImportError:
    BEDROCK_INSTRUMENTATION_AVAILABLE = False
    enable_bedrock_instrumentation = None
    disable_bedrock_instrumentation = None
    is_instrumentation_enabled = None

__all__ = [
    "TraceManager",
    "track_function",
    "track_llm_call",
    "track_llm_agent",
    "track_llm_tool",
    "set_configuration",
    "get_sqs_config",
    "get_project_id",
    "get_environment",
    "get_trace_context",
    "get_default_model",
    "get_s3_extended_client",
    "track_external_service",
    "resume_external_service",
    "get_injected_headers",
    "send_to_sqs",
    "send_to_sqs_immediate",
    "flush_sqs",
    "is_sqs_enabled",
    "LLMOpsASGIMiddleware",
    "enable_outbound_http_instrumentation",
    "disable_outbound_http_instrumentation",
    "outbound_instrumentation_status",
    "enable_requests_instrumentation",
    "disable_requests_instrumentation",
    "is_requests_instrumentation_enabled",
    "enable_httpx_instrumentation",
    "disable_httpx_instrumentation",
    "is_httpx_instrumentation_enabled",
    "enable_urllib_instrumentation",
    "disable_urllib_instrumentation",
    "is_urllib_instrumentation_enabled",
    "EVALUATION_SPAN_TYPE",
    "record_evaluation",
    "TRANSACTION_SPAN_TYPE",
    "start_transaction",
    "end_transaction",
    "transaction",
    "track_transaction",
    "get_open_transaction_ids",
    "CRAWL_SESSION_SPAN_TYPE",
    "CRAWL_PAGE_SPAN_TYPE",
    "CRAWL_EVENT_SPAN_TYPE",
    "crawl_session",
    "start_crawl_session",
    "record_crawl_event",
    "record_crawl_page",
    "end_crawl_session",
    "enable_bedrock_instrumentation",
    "disable_bedrock_instrumentation",
    "is_instrumentation_enabled",
    "__version__",
]
