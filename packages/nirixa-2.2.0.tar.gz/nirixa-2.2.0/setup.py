from setuptools import setup, find_packages

setup(
    name="nirixa",
    version="2.2.0",
    description="AI Observability & Cost Intelligence — track token costs, latency, and hallucination risk",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Nirixa",
    author_email="nirixaai@gmail.com",
    url="https://nirixa.in",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    extras_require={
        "openai":    ["openai>=1.0.0"],
        "anthropic": ["anthropic>=0.20.0"],
        "groq":      ["groq>=0.4.0"],
        "gemini":    ["google-generativeai>=0.5.0"],
        "mistral":   ["mistralai>=1.0.0"],
        "together":  ["together>=1.0.0"],
        "ollama":    ["ollama>=0.1.0"],
        "all":       [
            "openai>=1.0.0",
            "anthropic>=0.20.0",
            "groq>=0.4.0",
            "google-generativeai>=0.5.0",
            "mistralai>=1.0.0",
            "together>=1.0.0",
            "ollama>=0.1.0",
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
    keywords="llm observability openai anthropic groq gemini mistral ollama cost monitoring hallucination",
)