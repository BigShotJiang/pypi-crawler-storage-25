# nirixa/client.py

import asyncio
import functools
import time
import uuid
import threading
import requests
from typing import Callable, Optional, Any
from . import scorer as halluc_scorer
from .agent import get_trace_context as _get_trace_context


def _safe_json(obj) -> Optional[dict]:
    """Return obj if it is JSON-serialisable, else None."""
    if obj is None:
        return None
    import json as _json
    try:
        _json.dumps(obj)
        return obj
    except Exception:
        return None


def _extract_prompt_from_kwargs(kwargs: dict) -> Optional[str]:
    """Extract the last user message from standard provider call kwargs."""
    # OpenAI / Anthropic / Groq: messages=[{"role": ..., "content": ...}]
    messages = kwargs.get("messages", [])
    if messages:
        user_msgs = [m for m in messages if m.get("role") == "user"]
        if user_msgs:
            content = user_msgs[-1].get("content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                # Anthropic content blocks: [{"type": "text", "text": "..."}]
                return "\n".join(b.get("text", "") for b in content if b.get("type") == "text")

    # Google Gemini: contents=[{"role": ..., "parts": [...]}] or plain string
    contents = kwargs.get("contents", [])
    if contents:
        if isinstance(contents, str):
            return contents
        user_parts = [c for c in contents if not c.get("role") or c.get("role") == "user"]
        if user_parts:
            parts = user_parts[-1].get("parts", [])
            return "\n".join(p.get("text", "") for p in parts if p.get("text"))

    # Direct prompt string (some APIs)
    if isinstance(kwargs.get("prompt"), str):
        return kwargs["prompt"]

    return None


class _ClientProxy:
    """
    Transparent proxy around any provider client (OpenAI, Anthropic, Groq, ...).
    Every method call is automatically tracked via NirixaClient.track().
    model, provider, and prompt are extracted from the call kwargs.
    """

    __slots__ = ("_target", "_nirixa", "_feature", "_user")

    def __init__(self, target: Any, nirixa: "NirixaClient", feature: str, user: Optional[str]):
        object.__setattr__(self, "_target",  target)
        object.__setattr__(self, "_nirixa",  nirixa)
        object.__setattr__(self, "_feature", feature)
        object.__setattr__(self, "_user",    user)

    def __getattr__(self, name: str):
        target  = object.__getattribute__(self, "_target")
        nirixa  = object.__getattribute__(self, "_nirixa")
        feature = object.__getattribute__(self, "_feature")
        user    = object.__getattribute__(self, "_user")

        val = getattr(target, name)

        if callable(val):
            def _tracked(*args, **kwargs):
                model  = kwargs.get("model")
                prompt = _extract_prompt_from_kwargs(kwargs)
                return nirixa.track(
                    feature=feature,
                    fn=lambda: val(*args, **kwargs),
                    model=model,
                    prompt=prompt,
                    user=user,
                    request_params={**kwargs} if kwargs else None,
                )
            return _tracked

        # Sub-object (e.g. openai.chat → openai.chat.completions) — proxy it too
        if hasattr(val, "__dict__") and not isinstance(val, type):
            return _ClientProxy(val, nirixa, feature, user)

        return val


class NirixaClient:
    """
    Main Nirixa client. Track any LLM call with one line.

    Supported providers:
        - OpenAI       (gpt-4o, gpt-4o-mini, gpt-3.5-turbo, ...)
        - Anthropic    (claude-3-5-sonnet, claude-3-opus, ...)
        - Google       (gemini-1.5-pro, gemini-2.0-flash, ...)
        - Groq         (llama-3.1, mixtral, gemma, ...)
        - Mistral      (mistral-large, mistral-small, ...)
        - Together AI  (llama, qwen, deepseek, ...)
        - Ollama       (llama3, mistral, phi3, local models)
        - AWS Bedrock  (claude, llama, titan, ...)

    Usage:
        client = NirixaClient(api_key="nirixa-xxx")
        result = client.track(
            feature="/api/chat",
            fn=lambda: openai.chat.completions.create(...)
        )
    """

    def __init__(
        self,
        api_key:              str,
        host:                 str  = "https://api.nirixa.in",
        score_hallucinations: bool = True,
        async_ingest:         bool = True,
        capture_response:     bool = False,
        judge_enabled:        bool = False,
        debug:                bool = False,
    ):
        self.api_key              = api_key
        self.host                 = host.rstrip("/")
        self.score_hallucinations = score_hallucinations
        self.async_ingest         = async_ingest
        self.capture_response     = capture_response
        self.judge_enabled        = judge_enabled
        self.debug                = debug
        self._session             = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
            "User-Agent":    "nirixa-python/2.1.0",
        })
        self._threads = []

    # ── Public API ────────────────────────────────────────

    def track(
        self,
        feature:        str,
        fn:             Callable,
        model:          Optional[str]  = None,
        provider:       Optional[str]  = None,
        prompt:         Optional[str]  = None,
        user:           Optional[str]  = None,
        prompt_version: Optional[str]  = None,
        request_params: Optional[dict] = None,
    ) -> Any:
        """
        Wrap any LLM call and track cost, latency, and hallucination risk.

        Args:
            feature:        Your feature/endpoint name e.g. "/api/summarize"
            fn:             Lambda or callable that makes the LLM call
            model:          Model name override (auto-detected for most providers)
            provider:       Provider override ("openai", "anthropic", "google", etc.)
            prompt:         Optional prompt text for better hallucination scoring
            user:           Optional end-user identifier (e.g. user ID or email)
            prompt_version: Optional version tag for prompt A/B tracking e.g. "v2-concise"
            request_params: Original provider call kwargs, stored for replay

        Returns:
            The original LLM response unchanged
        """
        start     = time.time()
        error_msg = None
        response  = None

        try:
            response = fn()
        except Exception as e:
            error_msg = str(e)
            raise
        finally:
            latency_ms = int((time.time() - start) * 1000)
            self._build_and_ingest(response, feature, model, provider, prompt, user, latency_ms, error_msg, prompt_version, request_params)

        return response

    def observe(
        self,
        feature:    str,
        prompt_arg: Optional[str] = None,
        model_arg:  Optional[str] = None,
        user:       Optional[str] = None,
    ):
        """
        Decorator factory — wraps a function so every call is auto-tracked.

        Args:
            feature:    Your feature/endpoint name e.g. "/api/chat"
            prompt_arg: kwarg name to extract prompt from (e.g. "messages")
            model_arg:  kwarg name to extract model from (e.g. "model")
            user:       Optional end-user identifier

        Example::

            @nirixa.observe(feature="/api/chat")
            def call_llm(messages, model="gpt-4o"):
                return openai.chat.completions.create(model=model, messages=messages)

            @nirixa.observe(feature="/api/chat", prompt_arg="messages")
            async def call_llm_async(messages, model="gpt-4o"):
                return await openai.chat.completions.create(model=model, messages=messages)
        """
        def decorator(fn):
            if asyncio.iscoroutinefunction(fn):
                @functools.wraps(fn)
                async def async_wrapper(*args, **kwargs):
                    prompt    = kwargs.get(prompt_arg) if prompt_arg else None
                    model     = kwargs.get(model_arg)  if model_arg  else None
                    start     = time.time()
                    response  = None
                    error_msg = None
                    try:
                        response = await fn(*args, **kwargs)
                        return response
                    except Exception as e:
                        error_msg = str(e)
                        raise
                    finally:
                        latency_ms = int((time.time() - start) * 1000)
                        self._build_and_ingest(response, feature, model, None, prompt, user, latency_ms, error_msg)
                return async_wrapper
            else:
                @functools.wraps(fn)
                def sync_wrapper(*args, **kwargs):
                    prompt = kwargs.get(prompt_arg) if prompt_arg else None
                    model  = kwargs.get(model_arg)  if model_arg  else None
                    return self.track(
                        feature=feature,
                        fn=lambda: fn(*args, **kwargs),
                        model=model,
                        prompt=prompt,
                        user=user,
                    )
                return sync_wrapper
        return decorator

    def wrap(self, client: Any, feature: str, user: Optional[str] = None) -> Any:
        """
        Wrap a provider client so every call is tracked automatically.
        model, provider, and prompt are extracted from the call kwargs.

        Args:
            client:  The provider client instance (OpenAI, Anthropic, Groq, ...)
            feature: Your feature/endpoint name e.g. "/api/summarize"
            user:    Optional end-user identifier

        Returns:
            A transparent proxy — use it exactly like the original client.

        Example::

            ai = nirixa.wrap(openai_client, feature="/chat/answer", user=user_id)
            response = ai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": "Hello"}],
            )
        """
        return _ClientProxy(client, self, feature, user)

    def flush(self, timeout: float = 5.0):
        """Wait for all pending ingest threads. Call before script exits."""
        for t in self._threads:
            t.join(timeout=timeout)
        self._threads.clear()

    def health(self) -> bool:
        """Check if Nirixa backend is reachable."""
        try:
            r = self._session.get(f"{self.host}/health", timeout=3)
            return r.status_code == 200
        except Exception:
            return False

    def replay(self, call_id: str, model_override: Optional[str] = None) -> dict:
        """
        Re-run a previously logged call locally using your existing env API key.
        No keys are stored or sent to Nirixa — execution happens entirely on your machine.

        Args:
            call_id:        The call_id from a previous logged call.
            model_override: Swap in a different model, e.g. "gpt-4o-mini".

        Returns:
            dict with keys: response_text, original_cost, replay_cost, cost_delta, replay_call_id

        Example::

            result = client.replay("abc-123", model_override="gpt-4o-mini")
            print(f"Cost delta: ${result['cost_delta']:.6f}")
        """
        # 1. Fetch the original call log
        try:
            r = self._session.get(f"{self.host}/logs/{call_id}", timeout=10)
            r.raise_for_status()
            log = r.json()
        except Exception as e:
            raise RuntimeError(f"[nirixa] Could not fetch call log '{call_id}': {e}")

        request_json = log.get("request_json")
        if not request_json:
            raise ValueError(
                f"[nirixa] Call '{call_id}' has no stored request_json. "
                "Enable request capture by upgrading your SDK and re-running the call."
            )

        provider      = log.get("provider", "unknown")
        original_cost = log.get("cost_usd", 0.0)

        # 2. Merge model override
        params = dict(request_json)
        if model_override:
            params["model"] = model_override

        # 3. Re-execute locally
        response, error_msg = self._call_provider(provider, params)

        # 4. Track replay as a new call log
        replay_call_id = None
        replay_cost    = 0.0
        response_text  = None
        if response is not None:
            response_text = self._extract_text(response)
            self._build_and_ingest(
                response,
                feature="nirixa/replay",
                model=params.get("model"),
                provider=provider,
                prompt=None,
                user=None,
                latency_ms=0,
                error_msg=error_msg,
                request_params=params,
            )
            meta        = self._extract_meta(response, params.get("model"), provider)
            replay_cost = meta["cost_usd"]

        replay_call_id = str(uuid.uuid4())
        cost_delta     = replay_cost - original_cost

        # 5. Ship replay run record to backend
        try:
            self._session.post(f"{self.host}/replay-runs", json={
                "original_call_id": call_id,
                "replay_call_id":   replay_call_id,
                "model_override":   model_override,
                "original_cost":    original_cost,
                "replay_cost":      replay_cost,
                "cost_delta":       cost_delta,
                "response_text":    response_text,
                "error":            error_msg,
            }, timeout=5)
        except Exception:
            pass  # best-effort — don't fail replay if record storage fails

        return {
            "replay_call_id": replay_call_id,
            "response_text":  response_text,
            "original_cost":  original_cost,
            "replay_cost":    replay_cost,
            "cost_delta":     cost_delta,
            "error":          error_msg,
        }

    def _call_provider(self, provider: str, params: dict):
        """Execute a provider call locally using the user's env API key."""
        import os
        response  = None
        error_msg = None
        try:
            if provider == "openai":
                import openai
                client   = openai.OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
                response = client.chat.completions.create(**params)

            elif provider == "anthropic":
                import anthropic
                client   = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))
                response = client.messages.create(**params)

            elif provider == "google":
                import google.generativeai as genai
                genai.configure(api_key=os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY"))
                model_name = params.pop("model", "gemini-1.5-pro")
                model      = genai.GenerativeModel(model_name)
                response   = model.generate_content(**params)

            elif provider == "groq":
                import groq
                client   = groq.Groq(api_key=os.environ.get("GROQ_API_KEY"))
                response = client.chat.completions.create(**params)

            else:
                raise ValueError(f"Replay not supported for provider '{provider}'. Supported: openai, anthropic, google, groq.")

        except Exception as e:
            error_msg = str(e)

        return response, error_msg

    # ── Ingest ────────────────────────────────────────────

    def _build_and_ingest(
        self,
        response,
        feature:        str,
        model:          Optional[str],
        provider:       Optional[str],
        prompt:         Optional[str],
        user:           Optional[str],
        latency_ms:     int,
        error_msg:      Optional[str],
        prompt_version: Optional[str]  = None,
        request_params: Optional[dict] = None,
    ):
        meta = self._extract_meta(response, model, provider)

        halluc = {"score": None, "risk": None}
        output_text = None
        if response is not None and (self.score_hallucinations or self.capture_response):
            output_text = self._extract_text(response)
            if self.score_hallucinations and output_text:
                halluc = halluc_scorer.score(
                    output=output_text,
                    prompt=prompt,
                    model=meta["model"],
                )

        trace_ctx = _get_trace_context()

        payload = {
            "call_id":           str(uuid.uuid4()),
            "provider":          meta["provider"],
            "model":             meta["model"] or "unknown",
            "feature":           feature,
            "prompt_tokens":     meta["prompt_tokens"],
            "completion_tokens": meta["completion_tokens"],
            "total_tokens":      meta["total_tokens"],
            "cost_usd":          meta["cost_usd"],
            "latency_ms":        latency_ms,
            "halluc_score":      halluc["score"],
            "halluc_risk":       halluc["risk"],
            "error":             error_msg,
            "end_user_id":       user,
            "prompt_text":       prompt,
            "response_text":     output_text if self.capture_response else None,
            "judge_enabled":     self.judge_enabled if self.capture_response else None,
            "prompt_version":    prompt_version,
            "trace_id":          trace_ctx.trace_id       if trace_ctx else None,
            "parent_call_id":    trace_ctx.parent_call_id  if trace_ctx else None,
            "span_type":         "llm",
            "agent_name":        trace_ctx.agent_name      if trace_ctx else None,
            "step_index":        trace_ctx.step_index      if trace_ctx else None,
            "tool_name":         None,
            "tool_input_text":   None,
            "tool_output_text":  None,
            "request_json":      _safe_json(request_params),
        }

        if trace_ctx:
            trace_ctx._total_cost    += meta["cost_usd"]
            trace_ctx._total_tokens  += meta["total_tokens"]
            trace_ctx._total_latency += latency_ms

        if self.async_ingest:
            t = threading.Thread(target=self._ingest, args=(payload,), daemon=True)
            t.start()
            self._threads.append(t)
        else:
            self._ingest(payload)

    def _ingest(self, payload: dict):
        try:
            r = self._session.post(f"{self.host}/ingest", json=payload, timeout=5)
            if self.debug:
                print(f"[nirixa] {payload['feature']} → {r.status_code} ({payload['total_tokens']} tokens, ${payload['cost_usd']})")
        except Exception as e:
            if self.debug:
                print(f"[nirixa] ingest failed: {e}")

    # ── Meta Extraction (per provider) ───────────────────

    def _extract_meta(self, response, model_override, provider_override) -> dict:
        meta = {
            "model":             model_override,
            "provider":          provider_override,
            "prompt_tokens":     0,
            "completion_tokens": 0,
            "total_tokens":      0,
            "cost_usd":          0.0,
        }
        if response is None:
            return meta

        # ── OpenAI & Groq & Together AI & Mistral ──────────
        # All use OpenAI-compatible response format
        if hasattr(response, "usage") and hasattr(response, "choices"):
            usage            = response.usage
            raw_model        = getattr(response, "model", "") or ""
            meta["model"]    = model_override or raw_model
            meta["provider"] = provider_override or self._detect_provider(raw_model)

            if usage:
                meta["prompt_tokens"]     = getattr(usage, "prompt_tokens", 0) or 0
                meta["completion_tokens"] = getattr(usage, "completion_tokens", 0) or 0
                meta["total_tokens"]      = getattr(usage, "total_tokens", 0) or (meta["prompt_tokens"] + meta["completion_tokens"])
                meta["cost_usd"]          = self._calc_cost(meta["model"], meta["prompt_tokens"], meta["completion_tokens"])
            return meta

        # ── Anthropic ──────────────────────────────────────
        if hasattr(response, "usage") and hasattr(response, "content") and not hasattr(response, "choices"):
            usage            = response.usage
            raw_model        = getattr(response, "model", "") or ""
            meta["model"]    = model_override or raw_model
            meta["provider"] = provider_override or "anthropic"

            if usage:
                meta["prompt_tokens"]     = getattr(usage, "input_tokens", 0) or 0
                meta["completion_tokens"] = getattr(usage, "output_tokens", 0) or 0
                meta["total_tokens"]      = meta["prompt_tokens"] + meta["completion_tokens"]
                meta["cost_usd"]          = self._calc_cost(meta["model"], meta["prompt_tokens"], meta["completion_tokens"])
            return meta

        # ── Google Gemini (native SDK) ─────────────────────
        # response.usage_metadata.prompt_token_count
        if hasattr(response, "usage_metadata"):
            um               = response.usage_metadata
            meta["model"]    = model_override or getattr(response, "model", "gemini")
            meta["provider"] = provider_override or "google"
            meta["prompt_tokens"]     = getattr(um, "prompt_token_count", 0) or 0
            meta["completion_tokens"] = getattr(um, "candidates_token_count", 0) or 0
            meta["total_tokens"]      = getattr(um, "total_token_count", 0) or (meta["prompt_tokens"] + meta["completion_tokens"])
            meta["cost_usd"]          = self._calc_cost(meta["model"], meta["prompt_tokens"], meta["completion_tokens"])
            return meta

        # ── Ollama ─────────────────────────────────────────
        # response is a dict: {"model": ..., "prompt_eval_count": ..., "eval_count": ...}
        if isinstance(response, dict) and "prompt_eval_count" in response:
            meta["model"]             = model_override or response.get("model", "ollama")
            meta["provider"]          = provider_override or "ollama"
            meta["prompt_tokens"]     = response.get("prompt_eval_count", 0) or 0
            meta["completion_tokens"] = response.get("eval_count", 0) or 0
            meta["total_tokens"]      = meta["prompt_tokens"] + meta["completion_tokens"]
            meta["cost_usd"]          = 0.0  # local models = free
            return meta

        # ── AWS Bedrock ────────────────────────────────────
        # response["ResponseMetadata"] or response.get("usage")
        if isinstance(response, dict) and "ResponseMetadata" in response:
            meta["provider"] = provider_override or "bedrock"
            body             = response.get("body", {})
            if isinstance(body, dict):
                usage                     = body.get("usage", {})
                meta["model"]             = model_override or response.get("model", "bedrock")
                meta["prompt_tokens"]     = usage.get("input_tokens", 0) or 0
                meta["completion_tokens"] = usage.get("output_tokens", 0) or 0
                meta["total_tokens"]      = meta["prompt_tokens"] + meta["completion_tokens"]
                meta["cost_usd"]          = self._calc_cost(meta["model"], meta["prompt_tokens"], meta["completion_tokens"])
            return meta

        return meta

    def _detect_provider(self, model: str) -> str:
        """Auto-detect provider from model name."""
        m = model.lower()
        if any(x in m for x in ["gpt", "o1", "o3", "text-davinci"]):
            return "openai"
        if any(x in m for x in ["claude"]):
            return "anthropic"
        if any(x in m for x in ["gemini"]):
            return "google"
        if any(x in m for x in ["llama", "mixtral", "gemma", "whisper"]):
            # Could be Groq, Together, or Ollama — default groq for API calls
            return "groq"
        if any(x in m for x in ["mistral", "codestral"]):
            return "mistral"
        if any(x in m for x in ["qwen", "deepseek", "falcon"]):
            return "together"
        return "unknown"

    def _extract_text(self, response) -> Optional[str]:
        """Extract text output for hallucination scoring."""
        try:
            # OpenAI / Groq / Together / Mistral
            if hasattr(response, "choices"):
                return response.choices[0].message.content or ""
            # Anthropic
            if hasattr(response, "content") and isinstance(response.content, list):
                return getattr(response.content[0], "text", "") or ""
            # Gemini
            if hasattr(response, "candidates"):
                return response.candidates[0].content.parts[0].text or ""
            # Ollama
            if isinstance(response, dict) and "response" in response:
                return response["response"] or ""
            # Bedrock (Claude via Bedrock)
            if isinstance(response, dict) and "content" in response:
                content = response["content"]
                if isinstance(content, list) and content:
                    return content[0].get("text", "") or ""
        except Exception:
            pass
        return None

    def _calc_cost(self, model: str, prompt_tokens: int, completion_tokens: int) -> float:
        """Estimate USD cost. Prices per 1M tokens [input, output]."""
        if not model:
            return 0.0

        m = model.lower()

        PRICES = {
            # ── OPENAI (prices per 1M tokens, USD) ───────────────────
            # Current — specific keys before general ones
            "gpt-5-mini":                    (0.25,   1.00),
            "gpt-5-nano":                    (0.05,   0.40),
            "gpt-5":                         (1.25,  10.00),
            "gpt-4.1-nano":                  (0.10,   0.40),
            "gpt-4.1-mini":                  (0.40,   1.60),
            "gpt-4.1":                       (2.00,   8.00),
            "o4-mini":                       (1.10,   4.40),
            "o3-mini":                       (1.10,   4.40),
            "o3":                            (2.00,   8.00),
            "o1":                            (15.00, 60.00),
            # Legacy
            "gpt-4o-mini":                   (0.15,   0.60),
            "gpt-4o":                        (2.50,  10.00),
            "gpt-4-turbo":                   (10.00, 30.00),
            "gpt-4":                         (30.00, 60.00),
            "gpt-3.5-turbo":                 (0.50,   1.50),

            # ── ANTHROPIC ────────────────────────────────────────────
            # Claude 4.x — more specific first
            "claude-opus-4-5":               (15.00, 75.00),
            "claude-opus-4":                 (5.00,  25.00),
            "claude-sonnet-4":               (3.00,  15.00),
            "claude-haiku-4-5":              (0.80,   4.00),
            "claude-haiku-4":                (0.80,   4.00),
            # Claude 3.x
            "claude-3-7-sonnet":             (3.00,  15.00),
            "claude-3-5-sonnet":             (3.00,  15.00),
            "claude-3-5-haiku":              (0.80,   4.00),
            "claude-3-opus":                 (15.00, 75.00),
            "claude-3-sonnet":               (3.00,  15.00),
            "claude-3-haiku":                (0.25,   1.25),

            # ── GOOGLE GEMINI ─────────────────────────────────────────
            # Current (3.x)
            "gemini-3-1-pro":                (1.25,  10.00),
            "gemini-3-flash":                (0.20,   3.00),
            # 2.5 — lite before flash before pro
            "gemini-2.5-flash-lite":         (0.10,   0.40),
            "gemini-2.5-flash":              (0.15,   2.50),
            "gemini-2.5-pro":                (1.25,  10.00),
            "gemini-2-5-flash-lite":         (0.10,   0.40),
            "gemini-2-5-flash":              (0.15,   2.50),
            "gemini-2-5-pro":                (1.25,  10.00),
            # 2.0
            "gemini-2.0-flash":              (0.10,   0.40),
            "gemini-2-0-flash":              (0.10,   0.40),
            # 1.5
            "gemini-1.5-flash-8b":           (0.04,   0.15),
            "gemini-1.5-flash":              (0.075,  0.30),
            "gemini-1.5-pro":                (1.25,   5.00),
            "gemini-1-5-flash-8b":           (0.04,   0.15),
            "gemini-1-5-flash":              (0.075,  0.30),
            "gemini-1-5-pro":                (1.25,   5.00),
            "gemini-1.0-pro":                (0.125,  0.375),
            "gemini-1-0-pro":                (0.125,  0.375),

            # ── META LLAMA (via Groq unless noted) ───────────────────
            "llama-4-maverick":              (0.20,   0.60),
            "llama-4-scout":                 (0.11,   0.34),
            "llama-3.3-70b":                 (0.45,   3.50),
            "llama-3.1-70b":                 (0.59,   0.79),
            "llama-3.1-8b":                  (0.05,   0.08),
            "llama-3-70b":                   (0.88,   0.88),
            "llama-3-8b":                    (0.18,   0.18),

            # ── DEEPSEEK ─────────────────────────────────────────────
            "deepseek-r1-distill-llama-70b": (0.70,   0.88),
            "deepseek-r1-distill-qwen-32b":  (0.29,   0.43),
            "deepseek-r1-0520":              (0.55,   2.19),
            "deepseek-r1-together":          (3.00,   7.00),
            "deepseek-r1":                   (0.55,   2.19),
            "deepseek-v3":                   (0.01,   0.03),

            # ── GROQ (fast LPU inference) ─────────────────────────────
            "groq-gpt-oss-120b":             (0.15,   0.60),
            "groq-gpt-oss-28b":              (0.075,  0.075),
            "groq-kimi-k2":                  (1.00,   3.00),
            "groq-qwen3-32b":                (0.29,   0.59),
            "groq-llama-4-maverick":         (0.20,   0.60),
            "groq-llama-4-scout":            (0.11,   0.34),
            "groq-llama-3.1-70b":            (0.59,   0.79),
            "groq-llama-3.1-8b":             (0.05,   0.08),
            "groq-gemma2-9b":                (0.20,   0.30),
            "mixtral-8x7b":                  (0.24,   0.24),
            "gemma2-9b":                     (0.20,   0.20),

            # ── MISTRAL AI ────────────────────────────────────────────
            # Current — specific before general
            "mistral-large-3":               (0.50,   1.50),
            "mistral-large-2":               (2.00,   6.00),
            "mistral-large":                 (2.00,   6.00),
            "mistral-medium-3":              (0.10,   0.38),
            "mistral-small-3":               (0.10,   0.30),
            "mistral-small":                 (0.20,   0.60),
            "codestral-2508":                (0.15,   0.60),
            "codestral":                     (0.20,   0.60),
            "devstral-2":                    (0.40,   0.88),
            "magistral-medium":              (2.00,   5.00),
            "ministral-3b":                  (0.10,   0.10),
            "ministral-8b":                  (0.15,   0.15),
            "ministral-140":                 (0.20,   0.20),
            "mistral-nemo":                  (0.15,   0.15),
            "mistral-7b":                    (0.10,   0.30),

            # ── TOGETHER AI ───────────────────────────────────────────
            "together-llama-3-1-405b":       (3.50,   3.50),
            "together-llama-3-70b":          (0.88,   0.88),
            "together-llama-3-8b":           (0.18,   0.18),
            "together-deepseek-r1":          (1.00,   7.00),
            "together-deepseek-v3":          (0.50,   0.50),
            "together-qwen2-5-72b":          (1.20,   1.20),
            "together-qwen3-32b":            (0.20,   0.59),
            "together-mixtral-8x7b":         (0.60,   0.60),

            # ── QWEN (Alibaba / via providers) ────────────────────────
            "qwen3-32b":                     (0.29,   0.59),
            "qwen2.5-72b":                   (1.20,   1.20),
            "qwen2.5-7b":                    (0.28,   0.28),
            "qwen2-5-72b":                   (1.20,   1.20),
            "qwen2-5-7b":                    (0.28,   0.28),

            # ── OLLAMA (local, free) ──────────────────────────────────
            "ollama":                        (0.00,   0.00),
        }

        for key, (input_price, output_price) in PRICES.items():
            if key in m:
                cost = (prompt_tokens * input_price + completion_tokens * output_price) / 1_000_000
                return round(cost, 8)

        # Fallback
        return round((prompt_tokens * 0.50 + completion_tokens * 1.50) / 1_000_000, 8)