# nirixa/agent.py
# Distributed tracing support — ContextVar-based trace propagation.

from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Optional, Any, Callable
import uuid
import time
import functools
import threading


@dataclass
class TraceContext:
    trace_id:       str
    agent_name:     str
    parent_call_id: Optional[str] = None
    step_index:     int           = 0
    _total_cost:    float         = 0.0
    _total_tokens:  int           = 0
    _total_latency: int           = 0
    _start_time:    float         = field(default_factory=time.time)


_current_trace: ContextVar[Optional[TraceContext]] = ContextVar('_current_trace', default=None)


def get_trace_context() -> Optional[TraceContext]:
    """Called by client._build_and_ingest to read active trace, if any."""
    return _current_trace.get()


class StepContext:
    """Increments step_index on enter. Use as `with agent.step():` or just `with nirixa.step():`."""
    def __enter__(self):
        ctx = _current_trace.get()
        if ctx:
            ctx.step_index += 1
        return self

    def __exit__(self, *_):
        return False


class AgentContext:
    """
    Supports:
        with nirixa.agent("name") as a:   # sync context manager
        async with nirixa.agent("name"):  # async context manager
        @nirixa.agent("name")             # function decorator

    Fires a root span_type="agent" row to /ingest on exit with aggregated totals.
    """

    def __init__(self, name: str, client: Any = None):
        self._name   = name
        self._client = client

    # ── sync context manager ──────────────────────────────

    def __enter__(self) -> "AgentContext":
        self._ctx   = TraceContext(trace_id=str(uuid.uuid4()), agent_name=self._name)
        self._token = _current_trace.set(self._ctx)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        ctx = getattr(self, '_ctx', None)
        if ctx and self._client:
            self._ship_root_span(ctx, error=str(exc_val) if exc_val else None)
        token = getattr(self, '_token', None)
        if token is not None:
            _current_trace.reset(token)
        return False

    # ── async context manager ─────────────────────────────

    async def __aenter__(self) -> "AgentContext":
        return self.__enter__()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        return self.__exit__(exc_type, exc_val, exc_tb)

    # ── decorator ─────────────────────────────────────────

    def __call__(self, fn: Callable) -> Callable:
        name   = self._name
        client = self._client

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            fresh = AgentContext(name, client)
            with fresh:
                return fn(*args, **kwargs)

        @functools.wraps(fn)
        async def async_wrapper(*args, **kwargs):
            fresh = AgentContext(name, client)
            async with fresh:
                return await fn(*args, **kwargs)

        import asyncio
        return async_wrapper if asyncio.iscoroutinefunction(fn) else wrapper

    # ── step helper ───────────────────────────────────────

    def step(self, name: str = "") -> StepContext:
        return StepContext()

    # ── internal ──────────────────────────────────────────

    def _ship_root_span(self, ctx: TraceContext, error: Optional[str] = None):
        total_latency = int((time.time() - ctx._start_time) * 1000)
        payload = {
            "call_id":           str(uuid.uuid4()),
            "provider":          "nirixa",
            "model":             "agent",
            "feature":           ctx.agent_name,
            "prompt_tokens":     0,
            "completion_tokens": 0,
            "total_tokens":      ctx._total_tokens,
            "cost_usd":          round(ctx._total_cost, 8),
            "latency_ms":        total_latency,
            "halluc_score":      None,
            "halluc_risk":       None,
            "error":             error,
            "trace_id":          ctx.trace_id,
            "parent_call_id":    None,
            "span_type":         "agent",
            "agent_name":        ctx.agent_name,
            "step_index":        ctx.step_index,
            "tool_name":         None,
            "tool_input_text":   None,
            "tool_output_text":  None,
        }
        t = threading.Thread(target=self._client._ingest, args=(payload,), daemon=True)
        t.start()
        self._client._threads.append(t)


def tool_span(
    client:  Any,
    name:    str,
    fn:      Callable,
    inputs:  Any = None,
    feature: str = "tool",
) -> Any:
    """
    Track a non-LLM tool call (database lookup, API call, etc.).

    Usage:
        result = nirixa.tool("search_db", lambda: db.query(...), inputs={"q": "..."})
    """
    ctx   = _current_trace.get()
    start = time.time()
    error_msg = None
    result    = None

    try:
        result = fn()
        return result
    except Exception as e:
        error_msg = str(e)
        raise
    finally:
        latency_ms  = int((time.time() - start) * 1000)
        tool_input  = str(inputs)[:2000]  if inputs is not None else None
        tool_output = str(result)[:2000]  if result is not None else None

        payload = {
            "call_id":           str(uuid.uuid4()),
            "provider":          "nirixa",
            "model":             "tool",
            "feature":           feature,
            "prompt_tokens":     0,
            "completion_tokens": 0,
            "total_tokens":      0,
            "cost_usd":          0.0,
            "latency_ms":        latency_ms,
            "halluc_score":      None,
            "halluc_risk":       None,
            "error":             error_msg,
            "trace_id":          ctx.trace_id       if ctx else None,
            "parent_call_id":    ctx.parent_call_id  if ctx else None,
            "span_type":         "tool",
            "agent_name":        ctx.agent_name      if ctx else None,
            "step_index":        ctx.step_index      if ctx else None,
            "tool_name":         name,
            "tool_input_text":   tool_input,
            "tool_output_text":  tool_output,
        }

        if client:
            t = threading.Thread(target=client._ingest, args=(payload,), daemon=True)
            t.start()
            client._threads.append(t)
