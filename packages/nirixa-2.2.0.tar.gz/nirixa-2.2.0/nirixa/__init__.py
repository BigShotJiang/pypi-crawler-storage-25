# nirixa/__init__.py
#
# IMPORTANT: the submodule `nirixa.agent` (agent.py) is imported with private
# aliases BEFORE the `def agent(...)` function is defined, so the function
# definition wins in the package namespace and `nirixa.agent` stays callable.
# Changing this import order will break the public API.

from .client import NirixaClient
from .agent import (
    AgentContext  as _AgentContext,
    StepContext   as _StepContext,
    tool_span     as _tool_span,
    get_trace_context as get_trace_context,   # re-export for power users
)

__version__ = "2.2.0"
__all__ = ["NirixaClient", "track", "wrap", "observe", "agent", "tool", "step", "flush", "replay"]

# Module-level singleton — optional convenience API
_client: NirixaClient | None = None


def init(api_key: str, host: str = "https://api.nirixa.in", **kwargs):
    """
    Initialize module-level client for simple usage.

    Usage:
        import nirixa
        nirixa.init(api_key="nirixa-xxx")
        nirixa.track(feature="/api/chat", fn=lambda: openai.chat.completions.create(...))
    """
    global _client
    _client = NirixaClient(api_key=api_key, host=host, **kwargs)
    return _client


def track(feature: str, fn, **kwargs):
    """
    Track an LLM call using the module-level client.
    Call nirixa.init() first.
    """
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') before using nirixa.track()")
    return _client.track(feature=feature, fn=fn, **kwargs)


def observe(feature: str, prompt_arg: str = None, model_arg: str = None, user: str = None):
    """
    Decorator factory using the module-level client.
    Call nirixa.init() first.

    Example::

        import nirixa
        nirixa.init(api_key="nirixa-xxx")

        @nirixa.observe(feature="/api/chat")
        def call_llm(messages, model="gpt-4o"):
            return openai.chat.completions.create(model=model, messages=messages)
    """
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') before using nirixa.observe()")
    return _client.observe(feature=feature, prompt_arg=prompt_arg, model_arg=model_arg, user=user)


def wrap(client, feature: str, user: str = None):
    """
    Wrap a provider client using the module-level client.
    Call nirixa.init() first.

    Example::

        import nirixa
        from openai import OpenAI

        nirixa.init(api_key="nirixa-xxx")
        ai = nirixa.wrap(OpenAI(), feature="/chat/answer", user=user_id)
        response = ai.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": "Hello"}],
        )
    """
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') before using nirixa.wrap()")
    return _client.wrap(client, feature=feature, user=user)


def get_client() -> NirixaClient:
    """Get the module-level client."""
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') first")
    return _client


def agent(name: str):
    """
    Start an agent trace context. Supports context manager, async context manager,
    and decorator usage.

    Usage::

        # Context manager
        with nirixa.agent("my-agent") as a:
            with a.step():
                result = nirixa.track(...)
            nirixa.tool("db_query", lambda: db.find(...))

        # Async
        async with nirixa.agent("my-agent"):
            ...

        # Decorator
        @nirixa.agent("my-agent")
        def run():
            ...
    """
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') before using nirixa.agent()")
    return _AgentContext(name, _client)


def tool(name: str, fn, inputs=None, feature: str = "tool"):
    """
    Track a non-LLM tool call inside an agent trace.

    Args:
        name:    Tool name, e.g. "search_db" or "send_email"
        fn:      Callable that performs the tool action
        inputs:  Optional inputs dict/object for logging
        feature: Feature label (default "tool")

    Returns:
        The return value of fn()
    """
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') before using nirixa.tool()")
    return _tool_span(_client, name, fn, inputs, feature)


def step():
    """
    Increment the step counter inside the current agent trace.

    Usage::

        with nirixa.step():
            result = nirixa.track(...)
    """
    return _StepContext()


def flush(timeout: float = 5.0):
    """Wait for all pending ingest threads. Call before script exits."""
    if _client is None:
        return
    _client.flush(timeout=timeout)


def replay(call_id: str, model_override: str = None) -> dict:
    """
    Re-run a previously logged call locally using your existing env API key.

    Args:
        call_id:        The call_id from a previous logged call.
        model_override: Swap in a different model, e.g. "gpt-4o-mini".

    Returns:
        dict with keys: response_text, original_cost, replay_cost, cost_delta

    Example::

        import nirixa
        nirixa.init(api_key="nirixa-xxx")
        result = nirixa.replay("abc-123", model_override="gpt-4o-mini")
        print(f"Saved ${-result['cost_delta']:.6f} vs original")
    """
    if _client is None:
        raise RuntimeError("Call nirixa.init(api_key='...') before using nirixa.replay()")
    return _client.replay(call_id, model_override)