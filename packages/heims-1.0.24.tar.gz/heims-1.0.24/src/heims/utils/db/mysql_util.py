import datetime
import os

import MySQLdb
import threading

from dbutils.pooled_db import PooledDB
from sshtunnel import SSHTunnelForwarder
from typing import Optional, List, Dict, Union
from contextlib import contextmanager
import logging
import traceback

from typing_extensions import LiteralString

from .db_util import DBClient
from ..cache.redis_util import RedisClient
from ...common.log_util import LogUtil
from ...common import config
from ...common.functions import read_yaml_file, write_yaml_file, copy_dict


class MySQLWithSSH(DBClient):
    """
    MySQL操作类（使用mysqlclient），支持SSH隧道和连接池

    功能特性：
    1. SSH隧道连接远程MySQL
    2. 数据库连接池管理
    3. 自动重连机制
    4. 事务支持
    5. 批量操作
    6. 上下文管理器
    """
    table_structure = {}

    def __init__(self, *,
                 logger: logging.Logger = None,
                 ssh_host: str = None,
                 ssh_port: int = 22,
                 ssh_username: str = None,
                 ssh_password: str = None,
                 ssh_private_key: str = None,
                 ssh_private_key_password: str = None,

                 mysql_host: str = "localhost",
                 mysql_port: int = 3306,
                 mysql_user: str = None,
                 mysql_password: str = None,
                 mysql_database: str = None,

                 redis_client: RedisClient = None,

                 pool_size: int = 5,
                 max_overflow: int = 10,
                 pool_recycle: int = 3600,
                 charset: str = "utf8mb4",
                 use_unicode: bool = True):
        """
        初始化MySQL连接

        Args:
            ssh_host: SSH服务器地址
            ssh_port: SSH端口，默认22
            ssh_username: SSH用户名
            ssh_password: SSH密码
            ssh_private_key: SSH私钥路径
            ssh_private_key_password: SSH私钥密码

            mysql_host: MySQL服务器地址（在SSH服务器上）
            mysql_port: MySQL端口，默认3306
            mysql_user: MySQL用户名
            mysql_password: MySQL密码
            mysql_database: 数据库名

            pool_size: 连接池大小，默认5
            max_overflow: 最大溢出连接数，默认10
            pool_recycle: 连接回收时间（秒），默认3600
            charset: 字符集，默认utf8mb4
            use_unicode: 是否使用unicode，默认True
        """
        if logger is None:
            logger = LogUtil(name="mysql")

        self.logger = logger
        self._lock = threading.RLock()
        self._ssh_tunnel = None
        self._connection_pool = None
        self.redis = redis_client

        self.ssh_config = {
            'host': ssh_host,
            'port': ssh_port,
            'username': ssh_username,
            'password': ssh_password,
            'private_key': ssh_private_key,
            'private_key_password': ssh_private_key_password
        }

        self.mysql_config = {
            'host': mysql_host,
            'port': mysql_port,
            'user': mysql_user,
            'password': mysql_password,
            'database': mysql_database or 'mysql',
            'charset': charset,
            'use_unicode': use_unicode
        }

        self.pool_config = {
            'pool_size': pool_size,
            'max_overflow': max_overflow,
            'pool_recycle': pool_recycle
        }

        # 是否使用SSH隧道
        self.use_ssh = all([ssh_host, ssh_username])
        self.table_structure = {}

        # 初始化连接
        self._initialize_connection()
        self.init_table_structure()

    def _initialize_connection(self):
        """初始化连接（SSH隧道 + 连接池）"""
        try:
            local_port = None

            # 1. 建立SSH隧道（如果需要）
            if self.use_ssh:
                self.logger.info(f"正在建立SSH隧道连接到 {self.ssh_config['host']}:{self.ssh_config['port']}")

                ssh_params = {
                    'ssh_address_or_host': (self.ssh_config['host'], self.ssh_config['port']),
                    'ssh_username': self.ssh_config['username'],
                    'remote_bind_address': (self.mysql_config['host'], self.mysql_config['port'])
                }

                # 使用密码认证
                if self.ssh_config.get('password'):
                    ssh_params['ssh_password'] = self.ssh_config['password']

                # 使用私钥认证（支持带密码的私钥）
                elif self.ssh_config.get('private_key'):
                    ssh_params['ssh_pkey'] = self.ssh_config['private_key']
                    if self.ssh_config.get('private_key_password'):
                        ssh_params['ssh_pkey_password'] = self.ssh_config['private_key_password']

                self._ssh_tunnel = SSHTunnelForwarder(**ssh_params)
                self._ssh_tunnel.start()

                local_port = self._ssh_tunnel.local_bind_port
                self.logger.info(f"SSH隧道已建立，本地端口: {local_port}")

            # 2. 创建数据库连接池
            self.logger.info("正在创建数据库连接池...")

            # 更新MySQL配置（如果使用SSH隧道，则连接到本地端口）
            if self.use_ssh and self.mysql_config['port'] <= 0:
                db_host = '127.0.0.1'
                db_port = local_port
            else:
                db_host = self.mysql_config['host']
                db_port = self.mysql_config['port']

            pool_params = {
                'creator': MySQLdb,
                'host': db_host,
                'port': db_port,
                'user': self.mysql_config['user'],
                'passwd': self.mysql_config['password'],  # mysqlclient使用passwd
                'db': self.mysql_config['database'],
                'charset': self.mysql_config['charset'],
                'use_unicode': self.mysql_config['use_unicode'],

                # 连接池配置
                'maxconnections': self.pool_config['pool_size'] + self.pool_config['max_overflow'],
                'mincached': self.pool_config['pool_size'],
                'maxcached': self.pool_config['pool_size'],
                'blocking': True,  # 连接池满时等待
                'ping': 1,  # 每次连接时ping检查
                'setsession': [],  # 可选的会话命令
                #                'reset_on_return': True  # 返回连接时重置
            }

            self._connection_pool = PooledDB(**pool_params)
            self.logger.info(f"连接池创建成功，大小: {self.pool_config['pool_size']}")

        except Exception:
            self.logger.error(f"初始化连接失败:")
            self.logger.error(traceback.format_exc())
            self.close()

    def get_table_structure(self, table_name: str, db_name: str = "") -> dict:
        """
        给定db_name和table_name，获得表结构
        """
        if not db_name:
            db_name = self.get_db_name()

        if (not MySQLWithSSH.table_structure) or db_name not in MySQLWithSSH.table_structure:
            self.init_table_structure(db_name)

        if MySQLWithSSH.table_structure and MySQLWithSSH.table_structure.get(db_name, {}):
            if table_name not in MySQLWithSSH.table_structure[db_name]:
                self.set_table_structure(table_name, db_name)
            return MySQLWithSSH.table_structure[db_name].get(table_name, {})

        return {}

    def set_table_structure(self, table_name: str, db_name: str = ""):
        """
        给定db_name和table_name，设定表结构
        """
        if not db_name:
            db_name = self.get_db_name()

        if MySQLWithSSH.table_structure and db_name in MySQLWithSSH.table_structure:
            table_structure = None
            if self.redis:
                table_structure = self.redis.hget(f"table_structure_{db_name}", table_name)
            if not table_structure:
                table_structure = self._get_table_structure_from_schema(table_name, db_name)
            if not table_structure:
                table_structure = self._get_table_structure_from_file(table_name, db_name)
            if table_structure is not None:
                MySQLWithSSH.table_structure[db_name].update({table_name: table_structure})
                if self.redis:
                    self.redis.hset(f"table_structure_{db_name}", table_name, table_structure)
                else:
                    self._save_table_structure_to_file(table_structure, table_name, db_name)

    def _get_table_structure_from_file(self, table_name: str, db_name="") -> dict:
        """从数据文件中获取表结构"""
        if not db_name:
            db_name = self.get_db_name()

        file = os.path.join(config.BASE_INFO['base_dir'], "config", "db", db_name, f"{table_name}.ini")
        return read_yaml_file(file)

    def _save_table_structure_to_file(self, table_structure: dict, table_name: str, db_name="") -> dict:
        """向数据文件中写入表结构"""
        if not db_name:
            db_name = self.get_db_name()

        file = os.path.join(config.BASE_INFO['base_dir'], "config", "db", db_name, f"{table_name}.ini")
        return write_yaml_file(table_structure, str(file))

    def _get_table_structure_from_schema(self, table_name: str, db_name="") -> dict:
        """从mysql数据库中获取表结构信息"""
        sql = f"""
            SELECT
                COLUMN_NAME, DATA_TYPE as type, COLUMN_TYPE as column_type, IS_NULLABLE as nullable, COLUMN_DEFAULT as default_value
            FROM information_schema.COLUMNS 
            WHERE TABLE_SCHEMA = {'DATABASE()' if not db_name else "'" + db_name + "'"} AND TABLE_NAME = %s 
            ORDER BY ORDINAL_POSITION
        """
        return {row['COLUMN_NAME']: copy_dict(row, {}, filter_keys=['COLUMN_NAME']) for row in
                self.query(sql, (table_name,))}

    def init_table_structure(self, db_name: str = ""):
        if not db_name:
            db_name = self.get_db_name()

        if not MySQLWithSSH.table_structure:
            self._init_table_structure(db_name)

    def _init_table_structure(self, db_name: str = ""):
        if not db_name:
            db_name = self.get_db_name()
        table_structure = {}
        if self.redis:
            table_structure = self.redis.h_get_all(f"table_structure_{db_name}")

        if not table_structure:
            table_structure = self._get_all_table_structure_from_schema(db_name)

        if not table_structure:
            table_structure = self._get_all_table_structure_from_file(db_name)

        if table_structure and self.redis:
            self.redis.hm_set(f"table_structure_{db_name}", table_structure)
        if MySQLWithSSH.table_structure is None:
            MySQLWithSSH.table_structure = {db_name: table_structure}
        else:
            MySQLWithSSH.table_structure.update({db_name: table_structure})

    def reset_table_structure(self, table_name: str = "", db_name: str = ""):
        """
        重置表结构
        """
        if not db_name:
            db_name = self.get_db_name()

        if isinstance(MySQLWithSSH.table_structure, dict) and db_name in MySQLWithSSH.table_structure:
            if table_name:
                if isinstance(MySQLWithSSH.table_structure[db_name], dict) and table_name in \
                        MySQLWithSSH.table_structure[db_name]:
                    del (MySQLWithSSH.table_structure[db_name][table_name])
            else:
                MySQLWithSSH.table_structure[db_name] = None

    def _get_all_table_structure_from_file(self, db_name: str = "") -> dict:
        """
        从数据文件中获取所有表结构
        """
        if not db_name:
            db_name = self.get_db_name()

        table_structure = {}
        folder = os.path.join(config.BASE_INFO['base_dir'], "config", "db", db_name)
        if os.path.exists(folder) and os.path.isdir(folder):
            for file in os.listdir(folder):
                buffer = file.split('.')
                if len(buffer) == 2 and buffer[1].strip() == 'ini':
                    table_structure[buffer[0].strip()] = read_yaml_file(os.path.join(folder, file))
        return table_structure

    def _get_all_table_structure_from_schema(self, db_name: str = "") -> dict:
        """从mysql数据库中获取所有表结构信息"""
        sql = f"""
                SELECT
                    TABLE_NAME, COLUMN_NAME, DATA_TYPE as type, COLUMN_TYPE as column_type, IS_NULLABLE as nullable, COLUMN_DEFAULT as default_value
                FROM information_schema.COLUMNS 
                WHERE TABLE_SCHEMA = {'DATABASE()' if not db_name else "'" + db_name + "'"} 
                ORDER BY ORDINAL_POSITION
            """
        result = self.query(sql)
        return_data = {}
        if result:
            for row in result:
                if row['TABLE_NAME'] not in return_data:
                    return_data[row['TABLE_NAME']] = {}
                return_data[row['TABLE_NAME']][row['COLUMN_NAME']] = copy_dict(row, {}, filter_keys=["TABLE_NAME",
                                                                                                     "COLUMN_NAME"])
        return return_data

    def filter_columns(self, table: str, columns: List[str], db_name: str = "") -> List[str]:
        """
        使用表结构过滤columns
        特别的，当columns为空时，返回所有columns
        """
        table_structure = self.get_table_structure(table, db_name)
        if columns:
            if table_structure:
                return list(set(table_structure.keys()).intersection(columns))
            else:
                return columns
        else:
            return list(table_structure.keys())

    def check_columns(self, table: str, columns: List[str], db_name: str = "") -> bool:
        """
        判断columns是否超过了表格字段列表
        """
        if columns:
            table_structure = self.get_table_structure(table, db_name)
            if table_structure:
                for column in columns:
                    if column not in table_structure:
                        return False
        return True

    def get_db_name(self):
        """
        获取当前所在数据库名称
        """
        return self.query_one("SELECT DATABASE() as db_name").get('db_name', '')

    def get_connection(self):
        """修复的获取连接方法"""
        conn = self._connection_pool.connection()

        # 创建一个简单的上下文管理器类
        class ConnectionWrapper:
            def __init__(self, _conn):
                self.conn = _conn

            def __enter__(self):
                return self.conn

            def __exit__(self, exc_type, exc_val, exc_tb):
                if self.conn:
                    self.conn.close()

        return ConnectionWrapper(conn)

    # @contextmanager
    # def get_connection(self, autocommit: bool = False):
    #     """
    #     获取数据库连接（上下文管理器）
    #
    #     Args:
    #         autocommit: 是否自动提交，默认False
    #
    #     用法：
    #         with db.get_connection() as conn:
    #             with conn.cursor() as cursor:
    #                 cursor.execute("SELECT * FROM users")
    #     """
    #     conn = None
    #     try:
    #         conn = self._connection_pool.connection()
    #         conn.autocommit(autocommit)
    #         yield conn
    #     except MySQLdb.OperationalError:
    #         self.logger.warning(f"连接异常，尝试重新连接:")
    #         self.logger.error(traceback.format_exc())
    #         self._reconnect()
    #     except Exception:
    #         self.logger.error(f"获取连接失败:")
    #         self.logger.error(traceback.format_exc())
    #     finally:
    #         if conn:
    #             try:
    #                 conn.close()
    #             except:
    #                 pass

    def _reconnect(self):
        """重新连接数据库"""
        with self._lock:
            self.logger.info("正在重新连接数据库...")
            self.close()
            try:
                self._initialize_connection()
                self.logger.info("重新连接成功")
            except Exception:
                self.logger.error(f"重新连接失败:")
                self.logger.error(traceback.format_exc())

    def execute(self, sql: str, params: Union[tuple, list, dict] = None,
                conn: MySQLdb.Connection = None) -> int:
        """
        执行SQL语句（INSERT/UPDATE/DELETE）

        Args:
            sql: SQL语句
            params: 参数
            conn: 外部连接（用于事务）

        Returns:
            影响的行数
        """
        action_type = sql.lower()[:6]

        if conn:
            # 使用外部连接
            with conn.cursor() as cursor:
                return self._execute(sql, params, conn, cursor, action_type)
        else:
            with self.get_connection() as conn:
                with conn.cursor() as cursor:
                    return self._execute(sql, params, conn, cursor, action_type)

    def executemany(self, sql: LiteralString, params_list: List[Union[tuple, dict, list]],
                    conn: MySQLdb.Connection = None) -> int:
        """
        批量执行SQL

        Args:
            sql: SQL语句
            params_list: 参数列表
            conn: 外部连接（用于事务）

        Returns:
            影响的总行数
        """
        if conn:
            # 使用外部连接
            with conn.cursor() as cursor:
                return self._execute_many(sql, params_list, conn, cursor)
        else:
            # 从连接池获取连接
            with self.get_connection() as conn:
                with conn.cursor() as cursor:
                    return self._execute_many(sql, params_list, conn, cursor)

    def _execute(self, sql: str, params: Union[tuple, list, dict] = None, conn: MySQLdb.Connection = None, cursor= None, action_type:str="insert") -> int:
        try:
            affected_rows = cursor.execute(sql, params)
            self.logger.info(f"执行SQL成功: {sql}  参数 {params}")
            conn.commit()
            if action_type == 'insert':
                return cursor.lastrowid
            else:
                return affected_rows
        except Exception:
            self.logger.error(f"执行SQL失败: {sql}  参数 {params}")
            self.logger.error(traceback.format_exc())
            return 0


    def _execute_many(self, sql: LiteralString, params_list: List[Union[tuple, dict, list]], conn: MySQLdb.Connection = None, cursor= None):
        try:
            affected_rows = cursor.executemany(sql, params_list)
            self.logger.info(f"执行SQL成功: {sql}  参数 {params_list}")
            conn.commit()
            return affected_rows
        except Exception:
            self.logger.error(f"执行SQL失败: {sql}  参数 {params_list}")
            self.logger.error(traceback.format_exc())
            return 0


    def query(self, sql: str, params: Union[tuple, list, dict] = None,
              conn: MySQLdb.Connection = None) ->List[Dict]:
        """
        查询数据

        Args:
            sql: SQL查询语句
            params: 参数
            conn: 外部连接（用于事务）

        Returns:
            查询结果列表
        """
        if conn:
            # 使用外部连接
            with conn.cursor(MySQLdb.cursors.DictCursor) as cursor:
                return self._query(sql, params, cursor)
        else:
            # 从连接池获取连接
            with self.get_connection() as conn:
                with conn.cursor(MySQLdb.cursors.DictCursor) as cursor:
                    return self._query(sql, params, cursor)

    def _query(self, sql: str, params: Union[tuple, list, dict] = None, cursor= None):

        try:
            cursor.execute(sql, params)
            self.logger.info(f"执行SQL: {sql}  参数： {params}")
            return cursor.fetchall()

        except Exception:
            self.logger.error(f"执行SQL失败: {sql}  参数： {params}")
            self.logger.error(traceback.format_exc())
        return []

    def query_one(self, sql: str, params: Union[tuple, list, dict] = None,
                  conn: MySQLdb.Connection = None) -> Optional[Dict]:
        """
        查询单条数据

        Args:
            sql: SQL查询语句
            params: 参数
            conn: 外部连接（用于事务）

        Returns:
            单条记录或None
        """
        if conn:
            # 使用外部连接
            with conn.cursor(MySQLdb.cursors.DictCursor) as cursor:
                return self._query_one(sql, params, cursor)
        else:
            # 从连接池获取连接
            with self.get_connection() as conn:
                with conn.cursor(MySQLdb.cursors.DictCursor) as cursor:
                    return self._query_one(sql, params, cursor)

    def _query_one(self, sql: str, params: Union[tuple, list, dict] = None, cursor= None):
        try:
            cursor.execute(sql, params)
            self.logger.info(f"执行SQL: {sql}  参数： {params}")
            return cursor.fetchone()

        except Exception:
            self.logger.error(f"执行SQL失败: {sql}  参数： {params}")
        return {}



    def query_value(self, sql: str, params: Union[tuple, list, dict] = None,
                    default=None, conn: MySQLdb.Connection = None):
        """
        查询单个值

        Args:
            sql: SQL查询语句
            params: 参数
            default: 默认值
            conn: 外部连接

        Returns:
            单个值
        """
        result = self.query_one(sql, params, conn)
        if result:
            return list(result.values())[0]
        return default

    @contextmanager
    def transaction(self, isolation_level: str = None):
        """
        事务上下文管理器

        Args:
            isolation_level: 事务隔离级别（可选）

        用法：
            with db.transaction() as conn:
                # 在这里执行多个操作
                db.execute("INSERT INTO table1 ...", conn=conn)
                db.execute("UPDATE table2 ...", conn=conn)
        """
        conn = None
        try:
            conn = self._connection_pool.connection()

            # 设置事务隔离级别
            if isolation_level:
                conn.query(f"SET SESSION TRANSACTION ISOLATION LEVEL {isolation_level}")

            # 开始事务
            conn.autocommit(False)

            yield conn

            # 提交事务
            conn.commit()

        except Exception:
            if conn:
                try:
                    conn.rollback()
                except:
                    pass
            self.logger.error(f"事务执行失败:")
            self.logger.error(traceback.format_exc())

        finally:
            if conn:
                try:
                    conn.close()
                except:
                    pass

    def call_procedure(self, proc_name: str, args: tuple = None):
        """
        调用存储过程

        Args:
            proc_name: 存储过程名称
            args: 参数

        Returns:
            存储过程结果
        """
        with self.get_connection() as conn:
            with conn.cursor(MySQLdb.cursors.DictCursor) as cursor:
                cursor.callproc(proc_name, args)
                results = cursor.fetchall()

                # 获取输出参数
                cursor.execute("SELECT @_%s_%d" % (proc_name, i) for i in range(len(args or [])))
                out_params = cursor.fetchone()

                return results, out_params

    def table_exists(self, table_name: str, db_name: str = "") -> bool:
        """检查表是否存在"""

        if not db_name:
            db_name = self.get_db_name()

        table_structure = self.get_table_structure(table_name, db_name)
        return bool(table_structure)

    def batch_insert(self, table: str, columns: List[str], data: Union[List[List], List[Dict]], batch_size: int = 1000,
                     *, ignore_duplicates: bool = False, update_fields: List[str] = None, db_name:str="") -> int:
        """
        批量插入数据

        Args:
            table: 表名
            columns: 要插入的字段列表
            data: 数据列表
            batch_size: 每批大小
            ignore_duplicates: 是否忽略重复记录
            update_fields: 冲突时更新哪些字段，这项为真时，则忽略重复记录那一项必为假
        Returns:
            插入的总行数
        """
        if not data:
            return 0

        if not db_name:
            db_name = self.get_db_name()

        table_structure = self.get_table_structure(table, db_name)
        all_columns = set(table_structure.keys())

        if not columns:
            columns = set()
            for row in data:
                if isinstance(row, dict):
                    columns.update(all_columns.intersection(row.keys()))
            columns = list(columns)
            if columns:
                new_data = []
                for row in data:
                    if isinstance(row, dict):
                        new_data.append([row.get(col,table_structure[col].get('default_value', '')) for col in columns])
                data = new_data
            else:
                self.logger.error(f"{columns}字段列表为空")
                return 0

        elif not self.check_columns(table, columns):
            self.logger.error(f"{columns}字段列表超过表格定义")
            return -1


        update_fields = list(set(update_fields or []).intersection(columns))

        if update_fields:
            ignore_duplicates = False

        self.set_data_time(table, data, 'edit', columns=columns)


        # 构建SQL
        placeholders = ', '.join(['%s'] * len(columns))
        column_names = ', '.join([f'`{col}`' for col in columns])

        insert_cmd = "INSERT IGNORE INTO" if ignore_duplicates else "INSERT INTO"
        sql_head = f"{insert_cmd} `{table}` ({column_names}) VALUES "
        if update_fields:
            sql_tail = " ON DUPLICATE KEY UPDATE " + ','.join([f"{column}=VALUE({column})" for column in update_fields])
        else:
            sql_tail = ""

        # 分批插入
        total_rows = 0
        for i in range(0, len(data), batch_size):
            params = data[i:i + batch_size]
            all_placeholder = ','.join([f"({placeholders})"] * len(params))
            sql = f"{sql_head} {all_placeholder} {sql_tail}"
            total_rows += self.execute(sql, [value for row in params for value in row])

        self.logger.info(f"批量插入完成，表: {table}, 行数: {total_rows}")
        return total_rows

    def set_data_time(self, table: str, data: Union[Dict, list, tuple], action_type: str = 'add', db_name: str = "", *,
                      columns: List[str] = None):
        if not db_name:
            db_name = self.get_db_name()

        table_structure = self.get_table_structure(table, db_name)
        keys = [key.lower() for key in table_structure.keys()]
        now_time = datetime.datetime.now()
        if isinstance(data, dict):
            data_keys = [key.lower() for key in data.keys()]
            if "update_time" in keys and "update_time" not in data_keys:
                data['update_time'] = now_time
            if action_type.lower() == 'add':
                if "add_time" in keys and "add_time" not in data_keys:
                    data['add_time'] = now_time
        elif isinstance(data, (list, tuple)):
            data_keys = [key.lower() for key in columns]
            if "update_time" in keys and "update_time" not in data_keys:
                columns.append("update_time")
                for _d in data:
                    if isinstance(_d, list):
                        _d.append(now_time)
            if action_type.lower() == 'add':
                if "add_time" in keys and "add_time" not in data_keys:
                    columns.append("add_time")
                    for _d in data:
                        if isinstance(_d, list):
                            _d.append(now_time)

    def upsert(self, table: str, data: Dict, *, conflict_columns: Union[List[str], str] = None,
               ignore_duplicate: bool = False, update_columns: List[str] = None, search_columns: List[str] = None)->int:
        """
        UPSERT操作（存在则更新，不存在则插入）

        Args:
            table: 表名
            data: 数据
            ignore_duplicate: 是否忽略
            conflict_columns: 冲突检查的列
            update_columns: 需要更新的列（None表示更新所有非冲突列）
            search_columns: 检索条件（插入时，要返回新id）
        """
        if not conflict_columns:
            conflict_columns = ["id"]
        else:
            if type(conflict_columns) == str:
                conflict_columns = [conflict_columns]
        self.set_data_time(table, data)
        columns = self.filter_columns(table, list(data.keys()))

        values = [data[col] for col in columns]
        placeholders = ', '.join(['%s'] * len(columns))
        column_names = ', '.join([f'`{col}`' for col in columns])

        # 构建ON DUPLICATE KEY UPDATE部分

        sql = "INSERT IGNORE INTO" if ignore_duplicate else "INSERT INTO"
        sql += f"`{table}` ({column_names}) VALUES ({placeholders})"
        if not ignore_duplicate:
            if not update_columns:
                update_columns = set(columns).difference(conflict_columns)

            update_set = ', '.join([f'`{col}` = VALUES(`{col}`)' for col in update_columns])
            sql += f" ON DUPLICATE KEY UPDATE {update_set}"

        return self.execute(sql, tuple(values))

    def update(self, table_name: str, *, data: dict = None, where_condition: str = "", args: list = None,
               search_dict: dict = None, db_name="", set_str: str = "", _id: int = 0) -> int:
        sql_part, args = self.build_update(table_name, data=data, where_condition=where_condition, args=args,
                                           search_dict=search_dict, db_name=db_name, set_str=set_str, _id=_id)
        if sql_part:
            return self.execute(' '.join(sql_part), args)

    def delete(self, table_name: str, *, data: Union[dict, List[dict]] = None, where_condition: str = "",
               args: list = None, search_dict: dict = None, db_name="", _id: Union[int, List[int]] = 0):
        if not db_name:
            db_name = self.get_db_name()

        table_structure = self.get_table_structure(table_name, db_name)

        if not _id:
            if isinstance(data, dict):
                _id = data.get('id', 0)
            else:
                _id = [item.get('id', 0) for item in data if isinstance(item, dict)]

        sql_part, args = self.build_update(table_name, where_condition=where_condition, args=args,
                                           search_dict=search_dict,
                                           db_name=db_name, _id=_id, table_structure=table_structure,
                                           set_str="is_del=1")

        if sql_part:
            # _keys = [key.lower() for key in table_structure.keys()]
            # if "is_del" in _keys:
            #     return self.execute(' '.join(sql_part), args)
            # else:
            return self.execute(f"DELETE FROM {table_name} {sql_part[-1]}", args)
        else:
            return 0

    def get_info(self, table: str, columns_str: str = "", *, columns: List[str] = None, where_condition: str = "",
                 args: list = None, _id: int = 0, search_dict: dict = None, db_name: str = "", filter_delete: bool = True,
                 order_by: str = None) -> dict:
        """
        根据查询条件返回符合条件的单条记录
        """
        if _id:
            if isinstance(search_dict, dict):
                search_dict['id'] = _id
            else:
                search_dict = {"id": _id}

        sql_part, args = self.build_select(table, columns_str, all_columns=columns, where_condition=where_condition,
                                           args=args, search_dict=search_dict, db_name=db_name, offset=0, size=1,
                                           order_by=order_by, filter_delete=filter_delete)
        return self.query_one(' '.join(sql_part), args)

    def get_list(self, table: str, columns_str: str = "", *, columns: List[str] = None, where_condition: str = "",
                 args: list = None, search_dict: dict = None, db_name: str = "", offset: int = 0, size: int = 10,
                 group_by: str = "", having: str = "", order_by: str = None, filter_delete:bool = True) -> (int, List[dict]):
        """
        根据查询条件查询满足条件的记录，返回总数量和分页记录
        """
        sql_part, args = self.build_select(table, columns_str, all_columns=columns, where_condition=where_condition,
                                           args=args, search_dict=search_dict, db_name=db_name, offset=offset,
                                           size=size, group_by=group_by, having=having, order_by=order_by, filter_delete=filter_delete)

        column_str = sql_part[1]
        sql_part[1] = "count(0) as total_count"
        count_info = self.query_one(' '.join(sql_part), args)
        if count_info:
            count = count_info.get('total_count', 0)
        else:
            count = 0
        if count:
            sql_part[1] = column_str
            results = self.query(' '.join(sql_part), args)
        else:
            results = []
        return count, results

    def build_select(self, table: str, columns_str: str = "", *, all_columns: List[str] = None, where_condition: str = "",
                     args: list = None, search_dict: dict = None, db_name: str = "", order_by: str = "",
                     offset: int = 0, size: int = 0, group_by: str = "", having: str = "", filter_delete: bool = True) -> (
            List[str], Union[list, tuple]):
        """
        生成SELECT语句
        """
        if not db_name:
            db_name = self.get_db_name()

        all_columns = self.filter_columns(table, all_columns, db_name)
        if not columns_str:
            columns_str = ','.join(all_columns)

        if not where_condition:
            if filter_delete:
                if not isinstance(search_dict, dict):
                    search_dict = {}
                if 'is_del' not in search_dict:
                    search_dict['is_del'] = 0

            if search_dict:
                where_condition, args = self.create_where(search_dict, table, db_name)
        if not order_by:
            order_by = f"{all_columns[0]} DESC"
        sql_part = [
            "SELECT",
            columns_str,
            "FROM",
            table,
            f"WHERE {where_condition}" if where_condition else "",
            f"ORDER BY {order_by}" if order_by else "",
            f"LIMIT {offset}, {size}" if size >= 0 else ""
                                                        f"GROUP BY {group_by}" if group_by else "",
            f"HAVING {having}" if having else ""
        ]

        return sql_part, args

    def build_update(self, table_name: str, *, data: dict = None, where_condition: str = "", args: list = None,
                     search_dict: dict = None, db_name="", set_str: str = "", _id: Union[int, List[int]] = 0,
                     table_structure: dict = None) -> (
            List[str], List):
        """
        生成update语句
        """
        if not db_name:
            db_name = self.get_db_name()

        if not args:
            args = []
        if not set_str:
            if isinstance(data, dict):
                if not table_structure:
                    table_structure = self.get_table_structure(table_name, db_name)
                set_part = []
                table_keys = {key.lower(): key for key in table_structure.keys()}
                for key, value in data.items():
                    if key != "id":
                        _key = key.lower()
                        if _key in table_keys:
                            set_part.append(f"`{table_keys[_key]}`=%s")
                            args.append(value)

                if set_part:
                    set_str = ",".join(set_part)
                else:
                    return None, None

        if not where_condition:
            if (not _id) and isinstance(data, (list, dict)):
                _id = data.get('id', 0)

            if _id:
                if isinstance(_id, int):
                    _id = [_id]
                if isinstance(search_dict, dict):
                    search_dict["id"] = {"IN": _id}
                else:
                    search_dict = {"id": {"IN": _id}}
            if not table_structure:
                table_structure = self.get_table_structure(table_name, db_name)
            where_condition, _args = self.create_where(search_dict, table_name, db_name,
                                                       table_structure=table_structure)
            if where_condition and _args:
                args.extend(_args)

        if not where_condition:
            self.logger.error("empty where condition")
            return None, None

        return [
            f"UPDATE {table_name} SET",
            set_str,
            f"WHERE {where_condition}"
        ], args

    def create_where(self, search_dict: dict, table: str, db_name: str = "", table_structure: dict = None) -> (
            str, list):
        """
        将字典形式的查询条件转写为查询语句中的where子句
        """
        where_part = []
        args = []

        if not table_structure:
            table_structure = self.get_table_structure(table, db_name)

        keys_map = {key.lower(): key for key in table_structure.keys()}
        for key, value in search_dict.items():
            _key = key.lower()
            if _key in keys_map:
                column = keys_map[_key]
                _where, arg = self.set_condition(column, value)
                if _where:
                    where_part.append(_where)
                    args.extend(arg)

        return ' AND '.join(where_part), args

    def close(self):
        """关闭连接和SSH隧道"""
        with self._lock:
            # 关闭连接池
            if self._connection_pool:
                try:
                    self._connection_pool = None
                    self.logger.info("数据库连接池已关闭")
                except Exception:
                    self.logger.error(f"关闭连接池失败:")
                    self.logger.error(traceback.format_exc())

            # 关闭SSH隧道
            if self._ssh_tunnel:
                try:
                    self._ssh_tunnel.stop()
                    self._ssh_tunnel = None
                    self.logger.info("SSH隧道已关闭")
                except Exception:
                    self.logger.error(f"关闭SSH隧道失败:")
                    self.logger.error(traceback.format_exc())

    @staticmethod
    def set_condition(key: str, condition_value: Union[dict, str, list, tuple]) -> (str, list):
        if isinstance(condition_value, (list, tuple)):
            where_part = []
            args = []
            for item in condition_value:
                _where, _args = MySQLWithSSH.set_condition(key, item)
                if _where:
                    where_part.append(f"({_where})")
                    args.extend(_args)
            return f"({' AND '.join(where_part)})", args
        elif isinstance(condition_value, dict):
            args = []
            where_part = []
            for k, v in condition_value.items():
                _k = k.lower()
                if _k in ('and', 'or') and isinstance(v, (list, tuple)):
                    inner_where = []
                    inner_args = []
                    for item in v:
                        _where, _args = MySQLWithSSH.set_condition(key, item)
                        if _where:
                            inner_where.append(f"({_where})")
                            inner_args.extend(_args)

                    if inner_where:
                        where_part.append(f" {_k.upper()} ".join(inner_where))
                        args.extend(inner_args)
                elif _k in ('gt', 'ge', 'lt', 'le', 'ne', '>', '>=', '<', '<=', '!='):
                    calculator = {
                        'gt': '>', 'ge': '>=', 'lt': '<', 'le': '<=', 'ne': '!=',
                    }.get(_k, _k)
                    where_part.append(f"`{key}`{calculator}%s")
                    args.append(v)
                elif _k in ('like', 'not like', 'llike', 'rlike', 'not llike', 'not rlike') and isinstance(v, str):
                    calculator = {
                        "like": lambda: "LIKE",
                        "not like": lambda: "NOT LIKE",
                        "llike": lambda: "LIKE",
                        "not llike": lambda: "NOT LIKE",
                        "rlike": lambda: "LIKE",
                        "not rlike": lambda: "NOT LIKE",
                    }.get(_k, lambda: "LIKE")()
                    value = {
                        "like": lambda: "CONCAT('%%', %s, '%%')",
                        "not like": lambda: "CONCAT('%%', %s, '%%')",
                        "llike": lambda: "CONCAT('%%', %s)",
                        "not llike": lambda: "CONCAT('%%', %s)",
                        "rlike": lambda: "CONCAT(%s, '%%')",
                        "not rlike": lambda: "CONCAT(%s, '%%')",
                    }.get(_k, )()
                    where_part.append(f"`{key}` {calculator} {value}")
                    args.append(v)

                elif _k == 'between' and isinstance(v, (list, tuple)) and len(v) == 2:
                    where_part.append(f"`{key}` BETWEEN %s AND %s")
                    args.extend(v)
                elif _k == 'in' and v:
                    where_part.append(f"`{key}` IN ({','.join(['%s'] * len(v))})")
                    args.extend(v)
                elif _k in ('_in', 'str', '_str') and isinstance(v, (list, tuple)) and len(v) > 0:
                    if _k == '_in':
                        where_part.append(f"`{key}` IN ({v[0]})")
                    elif _k == 'str':
                        where_part.append(f"`{key}`{v[0]}")
                    elif _k == '_str':
                        where_part.append(v[0])

                    if len(v) > 1 and v[1]:
                        args.extend(v[1])

            if where_part:
                return ' AND '.join([f"({item})" for item in where_part]), args
            else:
                return "", None
        else:
            return f"`{key}`=%s", [condition_value]

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            self.logger.error(traceback.format_exc())


class MySQLUtil:
    @staticmethod
    def new_db(**kwargs):
        return MySQLWithSSH(**kwargs)
