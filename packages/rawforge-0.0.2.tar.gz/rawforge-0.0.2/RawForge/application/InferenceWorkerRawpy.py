import torch
from blended_tiling import TilingModule
from RawForge.application.postprocessing import match_colors_linear
from tqdm import tqdm
import rawpy

class InferenceWorkerRawpy():
    def __init__(self, model, model_params, device, rh, conditioning, dims, tile_size=512, tile_overlap=0.25, batch_size=2, disable_tqdm=False):
        super().__init__()
        self.model = model
        self.model_params = model_params
        self.device = device
        self.rh = rh
        self.conditioning = conditioning
        self.dims = dims
        self.tile_size = tile_size
        if 'tile_size' in model_params:
            self.tile_size =  model_params['tile_size']
        self.tile_overlap = tile_overlap
        self.batch_size = batch_size
        if 'batch_size' in model_params:
            self.batch_size = model_params['batch_size']
        self._is_cancelled = False
        self.disable_tqdm = disable_tqdm

    def cancel(self):
        self._is_cancelled = True

    def _tile_process(self):
        # Prepare Data
        image_RGB = self.rh.rawpy_object.postprocess(
                    user_wb=[1, 1, 1, 1],
                    output_color=rawpy.ColorSpace.raw,
                    demosaic_algorithm= rawpy.DemosaicAlgorithm(3),
                    no_auto_bright=True,
                    use_camera_wb=False,
                    use_auto_wb=False,
                    gamma=(1, 1),
                    user_flip=0,
                    output_bps=16,
                    no_auto_scale=True,
                ) / self.rh.rawpy_object.white_level

        image_RGB = image_RGB.transpose(2, 0, 1)

        tensor_RGB = torch.from_numpy(image_RGB).unsqueeze(0).contiguous()

        full_size = [image_RGB.shape[1], image_RGB.shape[2]]
        tile_size = [self.tile_size, self.tile_size]
        overlap = [self.tile_overlap, self.tile_overlap]

        # Tiling Setup
        tiling_module_rgb = TilingModule(tile_size=[s for s in tile_size], tile_overlap=overlap, base_size=[s for s in full_size])

        tiles_rgb = tiling_module_rgb.split_into_tiles(tensor_RGB).float().to(self.device)
        
        batches_rgb = torch.split(tiles_rgb, self.batch_size)

        # Conditioning Setup
        cond_tensor = torch.as_tensor(self.conditioning, device=self.device).float().unsqueeze(0)
        cond_tensor[:, 0] /= 6400
        cond_tensor[:, 1] = 0
        cond_tensor = cond_tensor[:, 0:1]

        processed_batches = []
        
        # Determine Dtype
        dtype_map = {'mps': torch.float16, 'cuda': torch.float16, 'cpu': torch.bfloat16}
        autocast_dtype = dtype_map.get(self.device.type, torch.float32)

        total_batches = len(batches_rgb)
        
        # Inference Loop
        with torch.no_grad():
            with torch.autocast(device_type=self.device.type, dtype=autocast_dtype):
                for i, (batch_rgb) in tqdm(enumerate(batches_rgb), disable=self.disable_tqdm):
                    if self._is_cancelled: return None, None
                    
                    B = batch_rgb.shape[0]
                    # Expand conditioning to match batch size
                    curr_cond = cond_tensor.expand(B, -1)
                    output = self.model(batch_rgb, curr_cond*0)
                    processed_batches.append(output.cpu())
                    
        # Rebuild
        tiles_out = torch.cat(processed_batches, dim=0)
        stitched = tiling_module_rgb.rebuild_with_masks(tiles_out).detach().cpu()

        if "affine" in self.model_params:
            stitched, _, _ = match_colors_linear(stitched, tensor_RGB)

        stitched = stitched.numpy()[0]
        torch.cuda.empty_cache()

        return image_RGB.transpose(1, 2, 0), stitched.transpose(1, 2, 0)
    
    def run(self):
        try:
            img, denoised_img = self._tile_process()

            # Post-process blending
            blend_alpha = self.conditioning[1] / 100
            final_denoised = (denoised_img * (1 - blend_alpha)) + (img * blend_alpha)
            
            return img, final_denoised
            
        except Exception as e:
            print(str(e))