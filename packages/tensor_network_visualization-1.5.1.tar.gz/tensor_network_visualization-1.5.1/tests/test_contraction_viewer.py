"""Tests for contraction playback UI and plot pipeline integration."""

from __future__ import annotations

from typing import Any

import matplotlib

matplotlib.use("Agg")

import numpy as np
import pytest
from matplotlib.backend_bases import MouseButton, MouseEvent
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.widgets import Button, CheckButtons, Slider

from tensor_network_viz import ContractionViewer2D, PlotConfig, pair_tensor
from tensor_network_viz._core.graph import (
    _EdgeEndpoint,
    _GraphData,
    _make_contraction_edge,
    _make_node,
)
from tensor_network_viz._core.renderer import _plot_graph
from tensor_network_viz.contraction_viewer import attach_playback_to_tensor_network_figure
from tensor_network_viz.einsum_module.graph import _build_graph


def _widget_center_event(fig: matplotlib.figure.Figure, artist: object) -> MouseEvent:
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bbox = artist.get_window_extent(renderer)  # type: ignore[attr-defined]
    x = int(round((bbox.x0 + bbox.x1) / 2.0))
    y = int(round((bbox.y0 + bbox.y1) / 2.0))
    return MouseEvent("button_press_event", fig.canvas, x, y, button=MouseButton.LEFT)


def _click_checkbutton(checkbuttons: CheckButtons, index: int) -> None:
    event = _widget_center_event(checkbuttons.ax.figure, checkbuttons.labels[index])
    checkbuttons._clicked(event)


def _click_button(button: Button) -> None:
    fig = button.ax.figure
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bbox = button.ax.get_window_extent(renderer)
    x = int(round((bbox.x0 + bbox.x1) / 2.0))
    y = int(round((bbox.y0 + bbox.y1) / 2.0))
    press = MouseEvent("button_press_event", fig.canvas, x, y, button=MouseButton.LEFT)
    release = MouseEvent("button_release_event", fig.canvas, x, y, button=MouseButton.LEFT)
    button._click(press)
    button._release(release)


def test_contraction_viewer_set_step_clamps_and_updates_visibility() -> None:
    fig, ax = matplotlib.pyplot.subplots()
    rects = [
        Rectangle((0, 0), 1, 1),
        Rectangle((2, 0), 1, 1),
    ]
    for r in rects:
        ax.add_patch(r)
    v = ContractionViewer2D(
        rects,
        fig=fig,
        ax=ax,
        enable_playback=False,
        mode="cumulative",
    )
    v.set_step(0)
    assert not rects[0].get_visible()
    v.set_step(1)
    assert rects[0].get_visible()
    assert not rects[1].get_visible()
    v.set_step(99)
    assert v.current_step == 2
    for r in rects:
        assert r.get_visible()


def test_enable_playback_false_build_ui_is_noop() -> None:
    fig, ax = matplotlib.pyplot.subplots()
    r = Rectangle((0, 0), 1, 1)
    ax.add_patch(r)
    v = ContractionViewer2D([r], fig=fig, ax=ax, enable_playback=False)
    n_axes_before = len(fig.axes)
    v.build_ui()
    assert len(fig.axes) == n_axes_before
    assert v.slider is None


def test_enable_playback_true_creates_slider_and_buttons() -> None:
    fig, ax = matplotlib.pyplot.subplots()
    r = Rectangle((0, 0), 1, 1)
    ax.add_patch(r)
    v = ContractionViewer2D([r], fig=fig, ax=ax, enable_playback=True)
    v.build_ui()
    assert v.slider is not None
    assert isinstance(v.slider, Slider)
    widgets = [axw for axw in fig.axes if axw is not ax]
    assert len(widgets) >= 3
    slider_bounds = v.slider.ax.get_position().bounds
    main_bounds = ax.get_position().bounds
    assert slider_bounds[2] <= 0.48
    assert main_bounds[1] >= 0.22


def test_plot_graph_contraction_playback_adds_widgets() -> None:
    trace = [
        pair_tensor("A0", "x0", "r0", "pa,p->a"),
        pair_tensor("r0", "A1", "r1", "a,apb->pb"),
    ]
    graph = _build_graph(trace)
    fig, ax = _plot_graph(
        graph,
        dimensions=2,
        config=PlotConfig(
            figsize=(4, 3),
            show_contraction_scheme=True,
            contraction_playback=True,
        ),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_playback",
    )
    viewer = getattr(fig, "_tensor_network_viz_contraction_viewer", None)
    assert viewer is not None
    assert viewer.slider is not None
    assert len(fig.axes) >= 2


def test_plot_graph_scheme_without_playback_keeps_controls_but_hides_playback_widgets() -> None:
    trace = [pair_tensor("A0", "x0", "r0", "pa,p->a")]
    graph = _build_graph(trace)
    fig, ax = _plot_graph(
        graph,
        dimensions=2,
        config=PlotConfig(figsize=(4, 3), show_contraction_scheme=True),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_no_playback",
    )
    controls = getattr(fig, "_tensor_network_viz_contraction_controls", None)
    assert controls is not None
    viewer = getattr(fig, "_tensor_network_viz_contraction_viewer", None)
    assert viewer is not None
    assert viewer.slider is not None
    assert not viewer.slider.ax.get_visible()
    assert len(fig.axes) >= 2


def test_contraction_playback_without_scheme_raises() -> None:
    trace = [pair_tensor("A0", "x0", "r0", "pa,p->a")]
    graph = _build_graph(trace)
    with pytest.raises(ValueError, match="show_contraction_scheme=True"):
        _plot_graph(
            graph,
            dimensions=2,
            config=PlotConfig(
                figsize=(4, 3),
                show_contraction_scheme=False,
                contraction_playback=True,
            ),
            show_tensor_labels=False,
            show_index_labels=False,
            renderer_name="test_playback_bad",
        )


def test_attach_playback_requires_drawable_artists() -> None:
    fig, ax = matplotlib.pyplot.subplots()
    r = Rectangle((0, 0), 1, 1)
    ax.add_patch(r)
    cfg = PlotConfig()
    attach_playback_to_tensor_network_figure(
        artists_by_step=[r],
        fig=fig,
        ax=ax,
        config=cfg,
    )
    assert fig.axes  # main + widget axes


def test_highlight_current_2d_scheme_patch_faint_fill_opaque_edge() -> None:
    """FancyBboxPatch + scheme gid uses tint+edge in playback (not gray-filled past)."""
    fig, ax = matplotlib.pyplot.subplots()
    p0 = FancyBboxPatch(
        (0, 0),
        1,
        1,
        boxstyle="round,pad=0.02",
        facecolor=(0.2, 0.4, 0.9, 0.5),
        edgecolor=(0.1, 0.1, 0.2, 1.0),
        gid="tnv_contraction_scheme",
    )
    p1 = FancyBboxPatch(
        (2, 0),
        1,
        1,
        boxstyle="round,pad=0.02",
        facecolor=(0.9, 0.2, 0.2, 0.5),
        edgecolor=(0.2, 0.1, 0.1, 1.0),
        gid="tnv_contraction_scheme",
    )
    ax.add_patch(p0)
    ax.add_patch(p1)
    v = ContractionViewer2D(
        [p0, p1],
        fig=fig,
        ax=ax,
        enable_playback=False,
        mode="highlight_current",
        current_color="tab:red",
        scheme_2d_highlight_fill_alpha=0.08,
    )
    v.set_step(2)
    past_fc = p0.get_facecolor()
    assert float(np.ravel(past_fc)[-1]) == pytest.approx(0.0)
    cur_fc = p1.get_facecolor()
    assert float(np.ravel(cur_fc)[-1]) == pytest.approx(0.08)
    cur_ec = p1.get_edgecolor()
    assert float(np.ravel(cur_ec)[-1]) == pytest.approx(1.0)


def test_pause_stops_play_without_timer_crash() -> None:
    fig, ax = matplotlib.pyplot.subplots()
    r = Rectangle((0, 0), 1, 1)
    ax.add_patch(r)
    v = ContractionViewer2D([r], fig=fig, ax=ax, enable_playback=True)
    v.build_ui()
    v.play()
    v.pause()
    assert not v._is_playing


def test_plot_graph_contraction_playback_3d_hides_past_scheme_steps() -> None:
    trace = [
        pair_tensor("A0", "x0", "r0", "pa,p->a"),
        pair_tensor("r0", "A1", "r1", "a,apb->pb"),
        pair_tensor("r1", "x1", "r2", "pb,p->b"),
        pair_tensor("r2", "A2", "r3", "b,bqc->qc"),
        pair_tensor("r3", "x2", "r4", "qc,q->c"),
        pair_tensor("r4", "A3", "r5", "c,crd->rd"),
        pair_tensor("r5", "x3", "r6", "rd,r->d"),
        pair_tensor("r6", "A4", "r7", "d,dse->se"),
    ]
    graph = _build_graph(trace)
    fig, ax = _plot_graph(
        graph,
        dimensions=3,
        config=PlotConfig(
            figsize=(5, 4),
            show_contraction_scheme=True,
            contraction_playback=True,
        ),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_playback_3d_scheme_visibility",
    )
    viewer = getattr(fig, "_tensor_network_viz_contraction_viewer", None)
    assert viewer is not None

    viewer.set_step(6)

    visible_steps = [artist.get_visible() for artist in viewer._artists if artist is not None]
    assert len(visible_steps) >= 6
    assert sum(1 for visible in visible_steps if visible) == 1
    assert viewer._artists[5] is not None
    assert viewer._artists[5].get_visible()


def test_plot_graph_lazy_scheme_controls_render_without_initial_bundle(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import tensor_network_viz._core.draw.graph_pipeline as graph_pipeline

    trace = [
        pair_tensor("A0", "x0", "r0", "pa,p->a"),
        pair_tensor("r0", "A1", "r1", "a,apb->pb"),
    ]
    graph = _build_graph(trace)
    calls: list[str] = []

    original_steps = graph_pipeline._effective_contraction_steps
    original_draw = graph_pipeline._draw_contraction_scheme
    original_metrics = graph_pipeline._contraction_step_metrics_for_draw

    def counting_steps(*args: Any, **kwargs: Any) -> Any:
        calls.append("steps")
        return original_steps(*args, **kwargs)

    def counting_draw(*args: Any, **kwargs: Any) -> Any:
        calls.append("draw")
        return original_draw(*args, **kwargs)

    def counting_metrics(*args: Any, **kwargs: Any) -> Any:
        calls.append("metrics")
        return original_metrics(*args, **kwargs)

    monkeypatch.setattr(graph_pipeline, "_effective_contraction_steps", counting_steps)
    monkeypatch.setattr(graph_pipeline, "_draw_contraction_scheme", counting_draw)
    monkeypatch.setattr(graph_pipeline, "_contraction_step_metrics_for_draw", counting_metrics)

    fig, _ax = _plot_graph(
        graph,
        dimensions=2,
        config=PlotConfig(
            figsize=(4, 3),
            show_contraction_scheme=False,
            contraction_playback=False,
            contraction_scheme_cost_hover=False,
        ),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_lazy_scheme_controls",
    )

    controls = getattr(fig, "_tensor_network_viz_contraction_controls", None)
    assert controls is not None
    assert calls == []
    assert controls._checkbuttons is not None
    assert tuple(bool(v) for v in controls._checkbuttons.get_status()) == (False, False, False)


def test_lazy_scheme_click_builds_bundle_once_and_playback_reuses_it(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import tensor_network_viz._core.draw.graph_pipeline as graph_pipeline

    trace = [
        pair_tensor("A0", "x0", "r0", "pa,p->a"),
        pair_tensor("r0", "A1", "r1", "a,apb->pb"),
    ]
    graph = _build_graph(trace)
    counts = {"steps": 0, "draw": 0, "metrics": 0}

    original_steps = graph_pipeline._effective_contraction_steps
    original_draw = graph_pipeline._draw_contraction_scheme
    original_metrics = graph_pipeline._contraction_step_metrics_for_draw

    def counting_steps(*args: Any, **kwargs: Any) -> Any:
        counts["steps"] += 1
        return original_steps(*args, **kwargs)

    def counting_draw(*args: Any, **kwargs: Any) -> Any:
        counts["draw"] += 1
        return original_draw(*args, **kwargs)

    def counting_metrics(*args: Any, **kwargs: Any) -> Any:
        counts["metrics"] += 1
        return original_metrics(*args, **kwargs)

    monkeypatch.setattr(graph_pipeline, "_effective_contraction_steps", counting_steps)
    monkeypatch.setattr(graph_pipeline, "_draw_contraction_scheme", counting_draw)
    monkeypatch.setattr(graph_pipeline, "_contraction_step_metrics_for_draw", counting_metrics)

    fig, ax = _plot_graph(
        graph,
        dimensions=2,
        config=PlotConfig(
            figsize=(4, 3),
            show_contraction_scheme=False,
            contraction_playback=False,
            contraction_scheme_cost_hover=False,
        ),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_lazy_scheme_click",
    )

    controls = getattr(fig, "_tensor_network_viz_contraction_controls", None)
    assert controls is not None
    assert controls._checkbuttons is not None

    _click_checkbutton(controls._checkbuttons, 0)

    assert counts == {"steps": 1, "draw": 1, "metrics": 1}
    assert getattr(fig, "_tensor_network_viz_contraction_viewer", None) is not None

    _click_checkbutton(controls._checkbuttons, 1)

    assert counts == {"steps": 1, "draw": 1, "metrics": 1}
    assert controls._viewer is not None
    assert controls._viewer.slider is not None
    assert ax.get_position().bounds[1] >= 0.22


def test_playback_button_click_and_scheme_toggle_pause_and_hide_controls() -> None:
    trace = [
        pair_tensor("A0", "x0", "r0", "pa,p->a"),
        pair_tensor("r0", "A1", "r1", "a,apb->pb"),
    ]
    graph = _build_graph(trace)
    fig, _ax = _plot_graph(
        graph,
        dimensions=2,
        config=PlotConfig(
            figsize=(4, 3),
            show_contraction_scheme=False,
            contraction_playback=False,
            contraction_scheme_cost_hover=False,
        ),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_lazy_playback_pause",
    )

    controls = getattr(fig, "_tensor_network_viz_contraction_controls", None)
    assert controls is not None
    assert controls._checkbuttons is not None

    _click_checkbutton(controls._checkbuttons, 1)

    assert controls._viewer is not None
    assert controls._viewer._btn_play is not None
    _click_button(controls._viewer._btn_play)
    assert controls._viewer._is_playing

    _click_checkbutton(controls._checkbuttons, 0)

    assert not controls._viewer._is_playing
    assert controls._viewer.slider is not None
    assert not controls._viewer.slider.ax.get_visible()
    assert controls._viewer._btn_play is not None
    assert not controls._viewer._btn_play.ax.get_visible()


def test_cost_hover_click_auto_enables_scheme_and_registers_hover() -> None:
    trace = [
        pair_tensor("A0", "x0", "r0", "pa,p->a"),
        pair_tensor("r0", "A1", "r1", "a,apb->pb"),
    ]
    graph = _build_graph(trace)
    fig, _ax = _plot_graph(
        graph,
        dimensions=2,
        config=PlotConfig(
            figsize=(4, 3),
            show_contraction_scheme=False,
            contraction_playback=False,
            contraction_scheme_cost_hover=False,
        ),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_lazy_cost_hover",
    )

    controls = getattr(fig, "_tensor_network_viz_contraction_controls", None)
    assert controls is not None
    assert controls._checkbuttons is not None

    _click_checkbutton(controls._checkbuttons, 2)

    assert controls.scheme_on
    assert controls.cost_hover_on
    assert getattr(fig, "_tensor_network_viz_hover_cid", None) is not None


def test_cost_hover_with_manual_scheme_and_no_metrics_does_not_crash() -> None:
    graph = _GraphData(
        nodes={
            0: _make_node("A", ("left",)),
            1: _make_node("B", ("right",)),
        },
        edges=(
            _make_contraction_edge(
                _EdgeEndpoint(0, 0, "left"),
                _EdgeEndpoint(1, 0, "right"),
                name="bond",
            ),
        ),
    )

    fig, _ax = _plot_graph(
        graph,
        dimensions=2,
        config=PlotConfig(
            figsize=(4, 3),
            show_contraction_scheme=False,
            contraction_playback=False,
            contraction_scheme_cost_hover=False,
            contraction_scheme_by_name=(("A", "B"),),
        ),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_manual_scheme_cost_hover",
    )

    controls = getattr(fig, "_tensor_network_viz_contraction_controls", None)
    assert controls is not None
    assert controls._checkbuttons is not None

    _click_checkbutton(controls._checkbuttons, 2)

    assert controls.scheme_on
    assert controls.cost_hover_on
    assert getattr(fig, "_tensor_network_viz_hover_cid", None) is not None


def test_scheme_reenable_restores_recorded_playback_without_recompute(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    import tensor_network_viz._core.draw.graph_pipeline as graph_pipeline

    trace = [
        pair_tensor("A0", "x0", "r0", "pa,p->a"),
        pair_tensor("r0", "A1", "r1", "a,apb->pb"),
    ]
    graph = _build_graph(trace)
    calls = {"steps": 0}
    original_steps = graph_pipeline._effective_contraction_steps

    def counting_steps(*args: Any, **kwargs: Any) -> Any:
        calls["steps"] += 1
        return original_steps(*args, **kwargs)

    monkeypatch.setattr(graph_pipeline, "_effective_contraction_steps", counting_steps)

    fig, _ax = _plot_graph(
        graph,
        dimensions=2,
        config=PlotConfig(
            figsize=(4, 3),
            show_contraction_scheme=False,
            contraction_playback=False,
            contraction_scheme_cost_hover=False,
        ),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_scheme_restore_playback",
    )

    controls = getattr(fig, "_tensor_network_viz_contraction_controls", None)
    assert controls is not None
    assert controls._checkbuttons is not None

    _click_checkbutton(controls._checkbuttons, 1)
    assert calls["steps"] == 1
    assert controls._viewer is not None
    assert controls._viewer.slider is not None
    assert controls._viewer.slider.ax.get_visible()

    _click_checkbutton(controls._checkbuttons, 0)
    assert not controls._viewer.slider.ax.get_visible()

    _click_checkbutton(controls._checkbuttons, 0)
    assert calls["steps"] == 1
    assert controls._viewer.slider.ax.get_visible()


def test_plot_graph_without_scheme_source_does_not_create_lazy_controls() -> None:
    graph = _GraphData(
        nodes={0: _make_node("A", ("i",))},
        edges=(),
    )

    fig, _ax = _plot_graph(
        graph,
        dimensions=2,
        config=PlotConfig(figsize=(4, 3)),
        show_tensor_labels=False,
        show_index_labels=False,
        renderer_name="test_no_scheme_source_controls",
    )

    assert getattr(fig, "_tensor_network_viz_contraction_controls", None) is None
