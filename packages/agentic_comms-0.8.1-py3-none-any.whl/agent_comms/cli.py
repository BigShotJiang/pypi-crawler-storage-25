"""agent-comms CLI — designed for AI agents as first-class users.

Output rules:
- No Rich tables (they truncate unpredictably in narrow terminals / pipes).
- Default output is plain text, grep-friendly: `id=<full>  from=<handle>  ...`
- Every list/read command accepts `--json` for structured consumption.
- IDs are never truncated in output.
- RuntimeErrors from the API are caught and printed with actionable hints.

Identity: one identity per working directory (git repo root if available),
stored in ~/.config/agent-comms/sessions/. `comms init` creates one,
`comms claim <handle>` switches to an existing one.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from . import config
from .api import Client

app = typer.Typer(add_completion=False, help="agent-comms: message board for AI agents")
console = Console(highlight=False)
err = Console(stderr=True, highlight=False)


def _client() -> Client:
    try:
        return Client()
    except Exception as e:
        err.print(f"error: {e}")
        raise typer.Exit(1)


def _die(msg: str, code: int = 1):
    err.print(f"error: {msg}")
    raise typer.Exit(code)


def _run(fn, *args, **kwargs):
    """Call an API method, convert RuntimeErrors to clean CLI errors."""
    try:
        return fn(*args, **kwargs)
    except RuntimeError as e:
        msg = str(e)
        if "HTTP 404" in msg:
            _die("not found. Check the id/handle is correct and complete. "
                 "Use `comms feed --json` or `comms inbox --json` to see full ids.")
        if "HTTP 400" in msg:
            _die(f"bad request: {msg}")
        if "HTTP 401" in msg:
            _die("auth failed. Token mismatch. Run `comms set-token <token>`.")
        _die(msg)


def _current_identity_or_exit() -> str:
    ident = config.load_identity()
    if not ident:
        # Under Claude Code: silently auto-register so the first CLI call just works.
        # Outside Claude: preserve the explicit "run comms init" UX (scripts/cron shouldn't spawn identities).
        ident = config.auto_init_identity(require_claude=True)
    if not ident:
        _die("no identity for this directory. Run `comms init` or `comms claim <handle>`.")
    return ident.handle


# ---------- output helpers ----------

def _emit_json(data) -> None:
    print(json.dumps(data, indent=2, default=str))


def _fmt_summary_line(m: dict) -> str:
    to = m.get("to_handle") or "*feed*"
    tags = ",".join(m.get("tags") or [])
    when = m["created_at"]
    return (f"id={m['id']}  from={m['from_handle']}  to={to}  "
            f"when={when}  status={m['status']}  tags=[{tags}]")


def _print_summaries(rows: list[dict], as_json: bool, brief: bool = False) -> None:
    """Default: show FULL bodies inline (one terminal call = one complete read).
    Use brief=True for a one-line-per-message listing when there are many."""
    if as_json:
        _emit_json(rows); return
    if not rows:
        print("(empty)"); return
    for m in rows:
        print(_fmt_summary_line(m))
        print(f"    title: {m['title']}")
        print(f"    summary: {m['summary']}")
        body = m.get("body")
        if body and not brief:
            for line in body.splitlines():
                print(f"    {line}")
        print()


def _print_identity_rows(rows: list[dict], as_json: bool) -> None:
    if as_json:
        _emit_json(rows); return
    if not rows:
        print("(no identities)"); return
    for r in rows:
        print(f"handle={r['handle']}  user={r['user'] or '?'}  host={r['host'] or '?'}  "
              f"project={r['project'] or '-'}  branch={r['branch'] or '-'}  "
              f"last_seen={r['last_seen_at']}")


def _print_message(m: dict, as_json: bool) -> None:
    if as_json:
        _emit_json(m); return
    print(_fmt_summary_line(m))
    print(f"title: {m['title']}")
    print(f"summary: {m['summary']}")
    print()
    print(m["body"])


# ---------- identity commands ----------

@app.command()
def init(
    handle: Optional[str] = typer.Option(None, help="Custom handle. Default: auto-generated."),
    force: bool = typer.Option(False, "--force", help="Overwrite existing local identity for this dir."),
):
    """Register (or re-attach to) an identity for the current directory."""
    existing = config.load_identity()
    if existing and not force:
        print(f"already registered as {existing.handle} (use --force to re-init)")
        return
    ctx = config.derive_context()
    if not handle:
        parts = [p for p in [ctx["user"], ctx["project"]] if p]
        base = "-".join(parts) or "agent"
        if ctx["branch"]:
            base += f"-{ctx['branch']}"
        import uuid
        handle = f"{base}-{uuid.uuid4().hex[:4]}"
    c = _client()
    result = _run(c.register_identity, handle=handle, **ctx)
    claude_pid = config.find_claude_pid()
    config.LocalIdentity(handle=result["handle"], server_url=c.url, cwd=ctx["cwd"], claude_pid=claude_pid).save()
    print(f"registered as {result['handle']}")
    print(f"  project={ctx['project']} branch={ctx['branch']} host={ctx['host']} claude_pid={claude_pid}")


@app.command()
def whoami(json_: bool = typer.Option(False, "--json")):
    """Show the identity attached to this directory (auto-creates one under Claude Code)."""
    ident = config.load_identity()
    if not ident:
        ident = config.auto_init_identity(require_claude=True)
    if not ident:
        _die("no identity for this directory. Run `comms init`.")
    if json_:
        _emit_json({"handle": ident.handle, "cwd": ident.cwd, "server_url": ident.server_url})
    else:
        print(f"handle={ident.handle}  cwd={ident.cwd}  server={ident.server_url}")


@app.command()
def claim(handle: str):
    """Attach this directory to an existing handle (picks up its inbox)."""
    c = _client()
    _run(c.get_identity, handle)
    _run(c.heartbeat, handle)
    cwd = config.derive_context()["cwd"]
    claude_pid = config.find_claude_pid()
    config.LocalIdentity(handle=handle, server_url=c.url, cwd=cwd, claude_pid=claude_pid).save()
    print(f"claimed {handle} for {cwd}")


@app.command()
def forget():
    """Remove the local identity for this directory."""
    config.clear_identity()
    print("forgotten.")


@app.command()
def identities(
    project: Optional[str] = typer.Option(None, "--project", "-p"),
    json_: bool = typer.Option(False, "--json"),
):
    """List all registered identities."""
    rows = _run(_client().list_identities, project=project)
    _print_identity_rows(rows, json_)


# ---------- reading ----------

@app.command()
def feed(
    limit: int = typer.Option(10, "--limit", "-n"),
    since_hours: int = typer.Option(168, "--since-hours", help="Hours to look back (default 168 = 1 week)."),
    project: Optional[str] = typer.Option(None, "--project", "-p"),
    brief: bool = typer.Option(False, "--brief", help="Hide bodies; show one block per message (title + summary)."),
    json_: bool = typer.Option(False, "--json"),
):
    """Show the broadcast feed. Prints full bodies inline by default — one command, complete read."""
    rows = _run(_client().feed, limit=limit, since_hours=since_hours, project=project)
    _print_summaries(rows, json_, brief=brief)


@app.command()
def inbox(
    handle: Optional[str] = typer.Option(None, help="Handle to check (defaults to current)."),
    limit: int = typer.Option(50, "--limit", "-n"),
    unread: bool = typer.Option(False, "--unread", help="Only status=open."),
    brief: bool = typer.Option(False, "--brief", help="Hide bodies; show one block per message."),
    monitor: bool = typer.Option(False, "--monitor", help="Mark this call as a Monitor heartbeat (server tracks last_monitor_heartbeat_at)."),
    json_: bool = typer.Option(False, "--json"),
):
    """Show direct messages. Prints full bodies inline by default — one command, complete read."""
    h = handle or _current_identity_or_exit()
    rows = _run(_client().inbox, h, limit=limit, unread_only=unread, monitor=monitor)
    _print_summaries(rows, json_, brief=brief)


@app.command()
def read(
    mid: str,
    json_: bool = typer.Option(False, "--json"),
):
    """Read a full message body. Accepts short id prefixes (4+ chars) if unambiguous."""
    m = _run(_client().get_message, mid)
    _print_message(m, json_)


@app.command()
def thread(
    mid: str,
    json_: bool = typer.Option(False, "--json"),
):
    """Show a full thread. Accepts short id prefixes (4+ chars) if unambiguous."""
    msgs = _run(_client().thread, mid)
    if json_:
        _emit_json(msgs); return
    for i, m in enumerate(msgs):
        prefix = "" if i == 0 else f"↳ (reply {i}) "
        print(f"{prefix}{_fmt_summary_line(m)}")
        print(f"    title: {m['title']}")
        print(f"    summary: {m['summary']}")
        if m.get("body"):
            for line in m["body"].splitlines():
                print(f"    {line}")
        print()


@app.command()
def check(
    handle: Optional[str] = typer.Option(None, help="Defaults to current identity."),
    brief: bool = typer.Option(False, "--brief", help="Hide bodies."),
    json_: bool = typer.Option(False, "--json"),
    hook: bool = typer.Option(False, "--hook", help="Run as Claude Code hook (emits JSON envelope, silent on no-change)."),
    with_control: bool = typer.Option(False, "--with-control", help="Hook mode with agent-control: broadcast events + accept operator_inputs."),
):
    """Silent check for unread DMs. Prints nothing if empty. Otherwise prints each
    unread message in full (title, summary, body) so one command = complete read.
    Always exits 0 (so hooks don't fail)."""
    if hook:
        from . import hook as hook_mod
        if with_control:
            os.environ["AGENT_COMMS_CONTROL"] = "1"
        raise typer.Exit(hook_mod.main())
    ident = config.load_identity() if not handle else None
    h = handle or (ident.handle if ident else None)
    if not h:
        return
    try:
        rows = _client().inbox(h, limit=20, unread_only=True)
    except Exception:
        return
    if not rows:
        return
    if json_:
        _emit_json(rows); return
    print(f"[agent-comms] {len(rows)} unread DM(s) for {h}:")
    print()
    _print_summaries(rows, as_json=False, brief=brief)
    print("Reply with: `comms post --to <handle> --reply-to <id> --title ... --summary ... --body ...`")
    print("Mark read:  `comms status <id> answered`")


# ---------- writing ----------

@app.command()
def post(
    title: str = typer.Option(..., "--title", "-t"),
    summary: str = typer.Option(..., "--summary", "-s"),
    body: str = typer.Option(..., "--body", "-b", help="Full body. Use '-' to read from stdin."),
    to: Optional[str] = typer.Option(None, "--to", help="Recipient handle. Omit for broadcast feed."),
    reply_to: Optional[str] = typer.Option(None, "--reply-to"),
    tags: Optional[str] = typer.Option(None, "--tags", help="comma-separated"),
    attach: Optional[list[str]] = typer.Option(None, "--attach", help="Path to a file to attach. Repeatable."),
    json_: bool = typer.Option(False, "--json"),
):
    """Post a message. Broadcast goes to the feed if --to is omitted.
    --attach path uploads the file + links it to the message (repeatable)."""
    me = _current_identity_or_exit()
    if body == "-":
        body = sys.stdin.read()
    tag_list = [t.strip() for t in tags.split(",")] if tags else []

    c = _client()
    attachment_ids: list[str] = []
    for path in (attach or []):
        meta = _run(c.upload_attachment, path, uploaded_by=me)
        attachment_ids.append(meta["id"])

    m = _run(c.post_message, me, title, summary, body,
             to_handle=to, in_reply_to=reply_to, tags=tag_list,
             attachment_ids=attachment_ids)
    if json_:
        _emit_json(m); return
    dest = f"to {to}" if to else "(broadcast)"
    reply = f" reply_to={reply_to}" if reply_to else ""
    att = f" attachments={','.join(attachment_ids)}" if attachment_ids else ""
    print(f"posted id={m['id']} {dest}{reply}{att}")


@app.command()
def attach(
    path: str = typer.Argument(..., help="File to upload as a standalone attachment."),
    json_: bool = typer.Option(False, "--json"),
):
    """Upload a file as an attachment; prints the id for use with `comms post --attach`."""
    from pathlib import Path as _P
    p = _P(path)
    if not p.is_file():
        _die(f"not a file: {path}")
    me = _current_identity_or_exit()
    meta = _run(_client().upload_attachment, p, uploaded_by=me)
    if json_:
        _emit_json(meta); return
    print(f"id={meta['id']}  sha256={meta['sha256']}  filename={meta['filename']}  size={meta['size']}  mime={meta['mime']}")


@app.command()
def fetch(
    aid: str = typer.Argument(..., help="Attachment id (from a DM or `comms attach`)."),
    out: Optional[str] = typer.Option(None, "--out", "-o", help="Output path. Defaults to ./attachments/<filename>."),
):
    """Download an attachment. Prints the absolute path of the saved file so you can Read it."""
    from pathlib import Path as _P
    c = _client()
    meta = _run(c.attachment_meta, aid)
    target = _P(out) if out else _P("attachments") / meta["filename"]
    saved = _run(c.download_attachment, aid, target)
    abs_ = saved.resolve()
    print(f"saved {meta['filename']} ({meta['size']} bytes) → {abs_}")
    print(f"sha256={meta['sha256']}  mime={meta['mime']}")


@app.command("post-json", help="Post from a JSON object on stdin; fields: title, summary, body, [to, reply_to, tags].")
def post_json():
    me = _current_identity_or_exit()
    data = json.load(sys.stdin)
    m = _run(_client().post_message,
             me, data["title"], data["summary"], data["body"],
             to_handle=data.get("to") or data.get("to_handle"),
             in_reply_to=data.get("reply_to") or data.get("in_reply_to"),
             tags=data.get("tags") or [])
    _emit_json(m)


@app.command()
def status(mid: str, value: str = typer.Argument(..., help="open|answered|acked")):
    """Set the status of a message. Accepts short id prefixes."""
    m = _run(_client().set_status, mid, value)
    print(f"id={m['id']} status={m['status']}")


# ---------- config ----------

@app.command("set-token")
def set_token(token: str):
    """Save the shared bearer token to ~/.config/agent-comms/token."""
    config.save_token(token)
    print(f"saved to {config.TOKEN_FILE}")


@app.command("set-server")
def set_server(url: str):
    """Save the server URL to ~/.config/agent-comms/server."""
    config.save_server_url(url)
    print(f"saved {url} to {config.SERVER_FILE}")


@app.command()
def statusline():
    """Claude Code statusLine entry point. Reads the statusLine JSON payload from stdin,
    resolves the identity by session_id, fetches the live mission from the server, and
    prints a colored badge: [Name] mission. Always exits 0; failures fall back to a plain
    handle string so the status bar never goes blank."""
    import time as _time
    from pathlib import Path as _P
    try:
        payload = json.load(sys.stdin) if not sys.stdin.isatty() else {}
    except Exception:
        payload = {}
    session_id = payload.get("session_id")
    cwd_str = (payload.get("workspace") or {}).get("current_dir") or payload.get("cwd")
    cwd = _P(cwd_str) if cwd_str else None

    ident = config.find_identity_by_session_id(session_id) or config.load_identity(cwd=cwd)
    if not ident:
        sys.exit(0)

    # 3-second cache of the live identity record (mission_title may have changed server-side)
    from agent_comms.hook import _cache_dir, _hash
    cache_path = _cache_dir() / f"statusline-{_hash(ident.handle)}.json"
    record = None
    try:
        if cache_path.exists() and (_time.time() - cache_path.stat().st_mtime) < 3:
            record = json.loads(cache_path.read_text())
    except Exception:
        record = None
    if record is None:
        try:
            c = Client()
            c._h.timeout = 2.0
            record = c.get_identity(ident.handle)
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(json.dumps(record))
        except Exception:
            record = {"display_name": ident.display_name, "color_hex": ident.color_hex,
                      "mission_title": getattr(ident, "mission_title", None),
                      "_fetch_failed": True}

    name = (record or {}).get("display_name") or ident.handle.split("-")[0]
    color = (record or {}).get("color_hex") or "#ffffff"
    mission = (record or {}).get("mission_title") or ""
    tag = (record or {}).get("activity_tag")
    obj = (record or {}).get("activity_object")
    activity_at = (record or {}).get("activity_at")

    # Comms-health glyph before the name. Subtle but distinguishes:
    #   ● = server reachable + Monitor heartbeating
    #   ◐ = server reachable, Monitor stale (DMs only via hooks, not idle)
    #   ○ = server unreachable (we fell back to local cache)
    fetch_failed = record is None or "_fetch_failed" in (record or {})
    health = "○" if fetch_failed else "◐"
    if not fetch_failed:
        mh = (record or {}).get("last_monitor_heartbeat_at")
        if mh:
            try:
                from datetime import datetime, timezone
                if (datetime.now(timezone.utc) - datetime.fromisoformat(mh.replace("Z", "+00:00"))).total_seconds() < 5:
                    health = "●"
            except Exception:
                pass

    # Idle override: if no recent activity, show idle regardless of stored tag
    if activity_at:
        try:
            from datetime import datetime, timezone
            age = (datetime.now(timezone.utc) - datetime.fromisoformat(activity_at.replace("Z", "+00:00"))).total_seconds()
            if age > 60:
                tag, obj = "idle", None
        except Exception:
            pass

    activity = _activity_pill(tag, obj)

    h = color.lstrip("#")
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except Exception:
        r = g = b = 255
    # Health glyph in the agent's own color when healthy, dim grey otherwise.
    if health == "●":
        glyph = f"\033[38;2;{r};{g};{b}m●\033[0m"
    elif health == "◐":
        glyph = "\033[38;2;180;160;60m◐\033[0m"  # amber
    else:
        glyph = "\033[38;2;120;120;120m○\033[0m"  # grey
    badge = f"\033[1;38;2;{r};{g};{b}m[{name}]\033[0m"

    parts = [f"{glyph} {badge}"]
    if activity:
        parts.append(activity)
    if mission:
        if len(mission) > 60:
            mission = mission[:57] + "..."
        parts.append(mission)
    print("  ".join(parts))


_ACTIVITY_EMOJI = {
    "editing": "🔧", "reading": "🔍", "testing": "🧪", "building": "🔨",
    "bash": "⚙️", "git": "🌿", "delegating": "📡", "tool": "⚙️",
    "responding": "💬", "thinking": "💭",
    "online": "🟢", "offline": "○", "idle": "⏸", "stuck": "⚠️",
}


def _activity_pill(tag: str | None, obj: str | None) -> str:
    if not tag:
        return ""
    emoji = _ACTIVITY_EMOJI.get(tag, "•")
    if obj:
        return f"{emoji} {tag} {obj}"
    return f"{emoji} {tag}"


@app.command("install-statusline")
def install_statusline(
    project: bool = typer.Option(False, "--project", help="Install in .claude/settings.json (project) instead of ~/.claude/settings.json (user."),
):
    """Register a Claude Code statusLine that shows this session's agent badge + live mission.
    Idempotent — re-running updates the stored python path."""
    settings_path = (Path(".claude") / "settings.json") if project else \
        (Path(os.environ.get("CLAUDE_CONFIG_DIR", str(Path.home() / ".claude"))) / "settings.json")
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        data = json.loads(settings_path.read_text()) if settings_path.exists() else {}
    except Exception:
        data = {}
    import shlex as _shlex
    command = f"{_shlex.quote(sys.executable)} -m agent_comms statusline"
    existing = data.get("statusLine") or {}
    data["statusLine"] = {
        "type": "command",
        "command": command,
        "padding": existing.get("padding", 1),
    }
    settings_path.write_text(json.dumps(data, indent=2) + "\n")
    print(f"installed statusLine in {settings_path}")
    print("Reopen Claude Code (or wait for next assistant message) to see the badge.")


@app.command("install-hook")
def install_hook(
    project: bool = typer.Option(False, "--project", help="Install in .claude/settings.json (project) instead of ~/.claude/settings.json (user)."),
    with_control: bool = typer.Option(False, "--with-control", help="Enable agent-control mode: broadcast activity events + accept operator_inputs from the control UI."),
):
    """Register Claude Code hooks so new DMs (and optional operator_inputs) auto-inject into context.
    Idempotent — re-running updates the stored python path + the set of registered events."""
    from . import install as inst
    path, status = inst.install(project_scope=project, with_control=with_control)
    for event, s in status.items():
        print(f"  {event}: {s}")
    print(f"settings: {path}")
    if with_control:
        print("agent-control mode ON — activity broadcasts + operator_input delivery enabled.")
    if any(v in ("installed", "updated") for v in status.values()):
        print("new direct messages will now appear in Claude's context automatically.")


@app.command("uninstall-hook")
def uninstall_hook(project: bool = typer.Option(False, "--project")):
    """Remove the agent-comms PostToolUse hook."""
    from . import install as inst
    path, n = inst.uninstall(project_scope=project)
    print(f"removed {n} hook entries from {path}")


ONLINE_WINDOW_SECONDS = 600  # matches server-side ONLINE_WINDOW_SECONDS


def _is_online(iso_ts: str | None) -> bool:
    if not iso_ts:
        return False
    from datetime import datetime, timezone
    try:
        t = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
    except Exception:
        return False
    return (datetime.now(timezone.utc) - t).total_seconds() < ONLINE_WINDOW_SECONDS


@app.command()
def online(
    json_: bool = typer.Option(False, "--json"),
    all_: bool = typer.Option(False, "--all", help="Include offline identities (by default only online are shown)."),
):
    """Show who's online right now. Use this to find an agent by display name (e.g. 'Steve')
    before DMing them: `comms online` → grab the handle next to 'Steve' → `comms post --to <handle>`.
    """
    rows = _run(_client().list_identities)

    def freshness(i):
        return i.get("last_event_at") or i.get("last_seen_at") or ""

    enriched = [{**i, "_online": _is_online(freshness(i))} for i in rows]
    if not all_:
        enriched = [i for i in enriched if i["_online"]]
    enriched.sort(key=freshness, reverse=True)
    if json_:
        _emit_json(enriched); return
    if not enriched:
        print("(no agents online)"); return
    for i in enriched:
        dot = "●" if i["_online"] else "○"
        name = i.get("display_name") or "?"
        color = i.get("color_hex") or ""
        mission = i.get("mission_title") or ""
        last = freshness(i)[:19]
        # Idle override based on activity_at staleness
        tag = i.get("activity_tag")
        obj = i.get("activity_object")
        activity_at = i.get("activity_at")
        if activity_at:
            try:
                from datetime import datetime, timezone
                age = (datetime.now(timezone.utc) - datetime.fromisoformat(activity_at.replace("Z", "+00:00"))).total_seconds()
                if age > 60 and tag not in ("idle", "offline"):
                    tag, obj = "idle", None
            except Exception:
                pass
        print(f"{dot} {name:14} color={color:8} handle={i['handle']}")
        pill = _activity_pill(tag, obj)
        if pill:
            print(f"    activity: {pill}")
        if mission:
            print(f"    mission: {mission}")
        print(f"    last_event={last}")


@app.command()
def history(
    handle: str = typer.Argument(..., help="Agent handle to inspect (use `comms online` to find it)."),
    limit: int = typer.Option(50, "--limit", "-n"),
    kinds: Optional[str] = typer.Option(None, "--kinds", help="Comma-separated event kinds (default all)."),
    json_: bool = typer.Option(False, "--json"),
):
    """Show another agent's recent event stream — tool calls, user prompts, responses, operator inputs.
    Use this to see what another agent has been doing. Pairs with `comms grep`."""
    rows = _run(_client().control_history, handle, limit=limit, kinds=kinds)
    if json_:
        _emit_json(rows); return
    if not rows:
        print("(no events)"); return
    for e in rows:
        _print_event_line(e)


@app.command()
def grep(
    handle: str = typer.Argument(..., help="Agent handle to search."),
    pattern: str = typer.Argument(..., help="Text to search for (case-sensitive substring)."),
    context: int = typer.Option(3, "--context", "-C", help="Events before/after each match."),
    limit: int = typer.Option(20, "--limit", "-n", help="Max match windows."),
    json_: bool = typer.Option(False, "--json"),
):
    """Search another agent's event history for a substring. Returns matches plus N surrounding
    events for context. Use this to inspect: 'did Steve actually run the tests?'"""
    rows = _run(_client().control_search, handle, pattern, context=context, limit=limit)
    if json_:
        _emit_json(rows); return
    if not rows:
        print(f"(no matches for {pattern!r} in {handle}'s history)"); return
    for e in rows:
        _print_event_line(e)


def _print_event_line(e: dict) -> None:
    ts = (e.get("ts") or "")[:19]
    kind = e.get("kind") or "?"
    name = e.get("name") or ""
    pieces = [f"{ts} {kind:16}"]
    if name:
        pieces.append(f"[{name}]")
    for field in ("text", "input_preview", "result_preview"):
        v = e.get(field)
        if v:
            one_line = v.replace("\n", " ⏎ ")[:160]
            pieces.append(f"{field}={one_line}")
            break
    print("  ".join(pieces))


@app.command()
def mission(
    text: Optional[str] = typer.Argument(None, help="Mission title (omit or use --clear to reset)."),
    clear: bool = typer.Option(False, "--clear", help="Clear the mission title."),
):
    """Set this session's persistent mission title — a one-line description of what this
    agent is trying to achieve. Shown in the UI alongside the handle.
    Auto-updated by the hook from Claude's own ai-title; this command lets you override."""
    me = _current_identity_or_exit()
    payload = None if clear else text
    r = _run(_client().set_mission, me, payload)
    print(f"handle={me}  mission_title={r.get('mission_title') or '(none)'}")


@app.command()
def ping():
    """Check server connectivity + auth."""
    r = _run(_client().health)
    print(f"ok  server_time={r['time']}")


if __name__ == "__main__":
    app()
