"""Local config and identity persistence.

Identity is keyed by the current working directory (resolved to repo root if git).
Lets an agent in the same project pick up where a previous session left off,
but also allows `comms claim <handle>` to override.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path

CONFIG_DIR = Path(os.environ.get("AGENT_COMMS_CONFIG_DIR", str(Path.home() / ".config" / "agent-comms")))
SESSIONS_DIR = CONFIG_DIR / "sessions"
TOKEN_FILE = CONFIG_DIR / "token"

# Baked-in defaults. Shared-token trust model — this is a tool for the author's
# own agents. Override via AGENT_COMMS_TOKEN / AGENT_COMMS_SERVER env vars or
# `comms set-token` / `comms set-server`.
BAKED_TOKEN = "f8890435b3bfb3641ef94c7bccf775b7d213c1c3e442fe3b"
BAKED_SERVER = "https://jimmyspianotuning.com.au/comms"


def _key_for_cwd(cwd: Path, claude_pid: int | None = None) -> str:
    """Scope identity by cwd, and also by Claude Code's PID when detectable.
    Two Claude sessions in the same cwd get distinct PIDs -> distinct identity files.
    /clear and /compact keep the same PID, so identity persists across them."""
    seed = str(cwd.resolve())
    if claude_pid is not None:
        seed += f":{claude_pid}"
    return hashlib.sha256(seed.encode()).hexdigest()[:16]


def find_claude_pid() -> int | None:
    """Walk the parent-process chain looking for a `claude` process (Claude Code).
    Returns its PID, or None if we're not running inside a Claude session.
    Linux/Mac only — returns None elsewhere."""
    try:
        pid = os.getppid()
        for _ in range(20):  # bounded walk
            if pid <= 1:
                return None
            name = _proc_name(pid)
            if name and name.strip().lower() in ("claude", "claude-code"):
                return pid
            parent = _proc_ppid(pid)
            if parent is None or parent == pid:
                return None
            pid = parent
    except Exception:
        return None
    return None


def _proc_name(pid: int) -> str | None:
    try:
        p = Path(f"/proc/{pid}/comm")
        if p.exists():
            return p.read_text().strip()
        out = subprocess.run(["ps", "-o", "comm=", "-p", str(pid)], capture_output=True, text=True, timeout=1)
        return out.stdout.strip() or None
    except Exception:
        return None


def _proc_ppid(pid: int) -> int | None:
    try:
        p = Path(f"/proc/{pid}/status")
        if p.exists():
            for line in p.read_text().splitlines():
                if line.startswith("PPid:"):
                    return int(line.split()[1])
        out = subprocess.run(["ps", "-o", "ppid=", "-p", str(pid)], capture_output=True, text=True, timeout=1)
        return int(out.stdout.strip()) if out.stdout.strip() else None
    except Exception:
        return None


def repo_root(start: Path | None = None) -> Path:
    start = (start or Path.cwd()).resolve()
    try:
        out = subprocess.run(
            ["git", "-C", str(start), "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, check=True,
        ).stdout.strip()
        if out:
            return Path(out)
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass
    return start


def git_branch(cwd: Path) -> str | None:
    try:
        out = subprocess.run(
            ["git", "-C", str(cwd), "branch", "--show-current"],
            capture_output=True, text=True, check=True,
        ).stdout.strip()
        return out or None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


@dataclass
class LocalIdentity:
    handle: str
    server_url: str
    cwd: str
    claude_pid: int | None = None
    session_id: str | None = None

    def save(self) -> None:
        """Dual-write: pid-keyed for the current session + cwd-only-keyed as the
        'latest identity for this cwd' pointer used on session revive."""
        SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(self.__dict__, indent=2)
        # pid-scoped (per-session)
        (SESSIONS_DIR / f"{_key_for_cwd(Path(self.cwd), self.claude_pid)}.json").write_text(payload)
        # cwd-only pointer (for revive lookup when PID has changed)
        (SESSIONS_DIR / f"{_key_for_cwd(Path(self.cwd))}.json").write_text(payload)


def load_identity(cwd: Path | None = None, claude_pid: int | None = None) -> LocalIdentity | None:
    """Resolve the identity for the current context.

    Lookup order:
    1. session-scoped (cwd + Claude PID) — isolates multiple Claudes in same cwd
    2. cwd-only (legacy/single-agent-per-dir) — backward compat + non-Claude invocations
    """
    cwd = (cwd or repo_root()).resolve()
    if claude_pid is None:
        claude_pid = find_claude_pid()

    if claude_pid is not None:
        p = SESSIONS_DIR / f"{_key_for_cwd(cwd, claude_pid)}.json"
        if p.exists():
            return LocalIdentity(**json.loads(p.read_text()))

    p = SESSIONS_DIR / f"{_key_for_cwd(cwd)}.json"
    if p.exists():
        data = json.loads(p.read_text())
        data.setdefault("claude_pid", None)
        return LocalIdentity(**data)
    return None


def find_identity_by_session_id(session_id: str | None) -> "LocalIdentity | None":
    """Scan all stored identity files for one whose stored session_id matches.
    Used by the statusline subcommand to resolve which agent the current Claude
    session belongs to, regardless of cwd."""
    if not session_id:
        return None
    if not SESSIONS_DIR.exists():
        return None
    for p in SESSIONS_DIR.glob("*.json"):
        try:
            data = json.loads(p.read_text())
        except Exception:
            continue
        if data.get("session_id") == session_id:
            data.setdefault("claude_pid", None)
            return LocalIdentity(**data)
    return None


def clear_identity(cwd: Path | None = None, claude_pid: int | None = None) -> None:
    cwd = (cwd or repo_root()).resolve()
    if claude_pid is None:
        claude_pid = find_claude_pid()
    for key in [_key_for_cwd(cwd, claude_pid), _key_for_cwd(cwd)]:
        p = SESSIONS_DIR / f"{key}.json"
        if p.exists():
            p.unlink()


SERVER_FILE = CONFIG_DIR / "server"


def get_token() -> str:
    tok = os.environ.get("AGENT_COMMS_TOKEN")
    if tok:
        return tok
    if TOKEN_FILE.exists():
        return TOKEN_FILE.read_text().strip()
    return BAKED_TOKEN


def save_token(tok: str) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(tok.strip() + "\n")
    TOKEN_FILE.chmod(0o600)


def get_server_url() -> str:
    url = os.environ.get("AGENT_COMMS_SERVER")
    if url:
        return url
    if SERVER_FILE.exists():
        return SERVER_FILE.read_text().strip()
    return BAKED_SERVER


def save_server_url(url: str) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    SERVER_FILE.write_text(url.strip() + "\n")


def auto_init_identity(claude_pid: int | None = None, require_claude: bool = True) -> "LocalIdentity | None":
    """Silently create and register a new identity for the current cwd.
    require_claude=True (default) means we only auto-create under Claude Code —
    otherwise random CLI calls from cron/scripts would spam identities."""
    if claude_pid is None:
        claude_pid = find_claude_pid()
    if require_claude and claude_pid is None:
        return None
    try:
        import uuid as _uuid
        from .api import Client  # local import to avoid circulars at module load
        ctx = derive_context()
        parts = [p for p in [ctx["user"], ctx["project"]] if p]
        base = "-".join(parts) or "agent"
        if ctx["branch"]:
            base += f"-{ctx['branch']}"
        handle = f"{base}-{_uuid.uuid4().hex[:4]}"
        c = Client()
        result = c.register_identity(handle=handle, **ctx)
        ident = LocalIdentity(
            handle=result["handle"], server_url=c.url, cwd=ctx["cwd"], claude_pid=claude_pid,
        )
        ident.save()
        return ident
    except Exception:
        return None


def derive_context() -> dict:
    cwd = repo_root()
    return {
        "user": os.environ.get("USER") or os.environ.get("USERNAME"),
        "host": os.uname().nodename if hasattr(os, "uname") else None,
        "project": cwd.name,
        "branch": git_branch(cwd),
        "cwd": str(cwd),
    }
