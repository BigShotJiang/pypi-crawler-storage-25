# TODO

Estado actual del repo:

* fases históricas cerradas;
* capítulo `mongomock` cerrado y sin backlog operativo abierto;
* runtime local de `search` cerrado en su perímetro actual;
* backlog restante ya no es de cierre de fases, sino de evolución del producto.
* ya no se mantiene un `FOLLOWUPS.md` separado: los huecos de producto viven en
  `MISSING_FEATURES.md` y el backlog amplio/roadmap vive aquí.

La deuda arquitectónica activa y las fronteras que se vigilan ya no se
describen aquí. Su referencia canónica vive ya repartida en
`docs/architecture/`, especialmente en `api-surfaces.md`,
`storage-engines.md` y `testing-and-compatibility.md`.

## 1. Search: siguiente nivel

Objetivo: ampliar el runtime local de búsqueda más allá del perímetro actual sin degradar la honestidad del contrato.

Pendientes:

* decidir si merece la pena ampliar `$search` más allá del subset actual:
  * `text`
  * `phrase`
  * `autocomplete`
  * `wildcard`
  * `regex`
  * `exists`
  * `in`
  * `equals`
  * `range`
  * `near`
  * `compound`
* ampliar mappings locales más allá de:
  * `string`
  * `token`
  * `autocomplete`
  * `number`
  * `date`
* decidir si el backend ANN local actual de `vectorSearch`, ya con
  ampliacion adaptativa de candidatos antes del fallback exacto, es suficiente
  o si necesita una siguiente fase mas ambiciosa;
* mejorar `explain()` de search si aparecen nuevos backends u operadores.

## 2. Rendimiento y planificación

Objetivo: mejorar throughput y coste operativo sin reabrir arquitectura base.

Pendientes:

* seguir mejorando pushdown/planning en SQLite;
* revisar si compensa otra vuelta sobre fallback/materialización en agregación;
* estudiar mejoras adicionales de concurrencia/throughput en SQLite si el objetivo pasa de paridad funcional a ambición más cercana a producción;
* optimizar `vectorSearch` si deja de ser suficiente el backend ANN local
  actual o si los filtros post-candidato pasan a exigir una politica mas rica;
* seguir endureciendo el planner físico si aparecen consultas mixtas donde el pushdown parcial actual no baste.

## 3. Consolidación selectiva

Objetivo: subir señal y confianza en las zonas todavía más débiles.

Pendientes:

* subir cobertura selectiva en:
  * `src/mongoeco/core/search.py`
  * `src/mongoeco/engines/virtual_indexes.py`
  * `src/mongoeco/driver/transports.py`
  * `src/mongoeco/engines/sqlite.py`
* seguir apurando fidelidad BSON rara y semántica fina de comparación solo cuando haya casos reales o diferenciales que lo justifiquen;
* reforzar contraste diferencial con MongoDB real si se quiere aumentar confianza observable más allá de la paridad práctica actual.

## 4. Publicación y producto

Objetivo: dejar el proyecto preparado para una primera release pública, si se decide publicar.

Pendientes:

* revisar packaging y metadatos de distribución;
* seguir endureciendo documentación pública de uso, alcance y posicionamiento;
* decidir política de compatibilidad y de versiones;
* decidir qué hacer con:
  * `benchmarks/`
  * `mongoeco-rs/`
  * `MEMORIES.md`
* seguir ampliando ejemplos públicos reales si aparecen nuevos flujos
  representativos del producto.

## Anotaciones de estado

Ya no forman parte del backlog pendiente básico:

* pipeline-style updates en su subset documentado;
* `$merge` como stage terminal local de agregación;
* `$densify` y `$fill` en su subset local documentado;
* `currentOp` / `killOp` locales;
* `vectorSearch` local con backend ANN `usearch`, fallback exacto, `filter` y
  similitudes `cosine`, `dotProduct` y `euclidean`.
* projection avanzada de `find` en el subconjunto diario (`$slice`,
  `$elemMatch`, proyección posicional, `$meta: "textScore"`);
* `$collStats` como stage inicial de agregación local;
* índices `hidden` como metadata administrativa local.

## 5. Backends y extensibilidad

Objetivo: abrir líneas nuevas de producto, ya fuera del backlog histórico.

Pendientes:

* valorar si tiene sentido un SDK o contrato más explícito para backends terceros;
* estudiar si un backend SQL adicional (`DuckDB`, `PostgreSQL`) compensa ahora que el contrato interno está más limpio;
* evaluar si el runtime de driver debe seguir creciendo como producto propio o quedarse como soporte local suficiente.

## 6. Referencia futura: Rust

Esto queda explícitamente fuera del alcance actual, pero sí debe seguir visible como dirección futura.

Pendientes futuros:

* evaluar un backend Rust a grano grueso, nunca documento a documento;
* priorizar, si se aborda, fronteras como:
  * `scan/filter/sort` completos
  * comparación BSON por lotes
  * ejecución de runtime intensivo sobre colecciones grandes
* evitar una integración Python/Rust con llamadas por documento, porque el coste de cruce puede anular la mejora;
* decidir si `mongoeco-rs/` será:
  * backend opcional
  * librería separada
  * o núcleo futuro del motor embebido

## 7. Criterio de prioridad

Orden recomendado a partir de aquí:

1. ampliar `search` solo si abre valor real de producto;
2. subir cobertura selectiva en `search` / `virtual_indexes` / `sqlite` / `transports`;
3. preparar publicación si el objetivo es sacar versión;
4. dejar Rust como línea futura, no como trabajo inmediato.
