from prometheus_client import Counter, Histogram, Gauge

# Frames processed per camera
frames_processed = Counter(
    "frames_processed_total",
    "Total frames processed",
    ["camera_id"]
)

# Processing time per frame
frame_processing_time = Histogram(
    "frame_processing_seconds",
    "Time spent processing a frame",
    ["camera_id"]
)

# Simulated latency
frame_latency = Histogram(
    "frame_latency_seconds",
    "Simulated latency per frame",
    ["camera_id"]
)

# Queue size
queue_size = Gauge(
    "collector_queue_size",
    "Number of items in queue"
)