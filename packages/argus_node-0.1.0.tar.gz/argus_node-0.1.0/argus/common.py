from dataclasses import dataclass
from typing import Any
from enum import Enum

import numpy as np
from cv2 import Mat

Frame = Mat | np.ndarray[Any, np.dtype[np.integer[Any] | np.floating[Any]]]

@dataclass
class Metadata:
    camera_id: str




class NodeState(Enum):
    STARTING = "starting"
    INITIALISING = "initialising"
    READY = "ready"
    RUNNING = "running"
    FINISHED = "finished"