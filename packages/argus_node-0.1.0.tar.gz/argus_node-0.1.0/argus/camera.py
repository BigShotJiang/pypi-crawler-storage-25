import asyncio
import logging
from asyncio import Event
from datetime import datetime, UTC
from typing import Callable, Any

import cv2
from argus.common import Frame, Metadata
from argus.metrics import frame_latency, frame_processing_time, frames_processed

logger = logging.getLogger(__name__)


class Camera:
    def __init__(self, video_path, camera_id, node_id,
                 latency_fn: Callable[..., float] = lambda: 0,
                 process_fn: Callable[[Frame, Metadata], Any] = lambda frame, metadata: 0):
        self._cap = None
        self._fps = None
        self._frame_time = None
        self._video_filename = video_path

        self.camera_id = camera_id
        self.node_id = node_id

        self.latency_fn = latency_fn
        self.process_fn = process_fn

        logger.info(
            "camera initialised",
            extra={
                "event": "camera.initialised",
                "node_id": self.node_id,
                "camera_id": self.camera_id,
                "video_uri": video_path,
            },
        )

    def load_video(self):
        self._cap = cv2.VideoCapture(self._video_filename)

        self._fps = self._cap.get(cv2.CAP_PROP_FPS)
        if self._fps <= 0:
            logger.warning(
                "camera reported invalid fps, defaulting to 1",
                extra={
                    "event": "camera.invalid_fps",
                    "camera_id": self.camera_id,
                    "fps": self._fps,
                },
            )
            fps = 1.0

        self._frame_time = 1.0 / self._fps
        self._frames_seen = 0

    async def run(self, start_event: Event, output_queue):

        await start_event.wait()
        logger.info(
            "camera stream started",
            extra={
                "event": "camera.stream.started",
                "camera_id": self.camera_id,
                "fps": self._fps,
            },
        )
        while True:
            start = datetime.now(UTC).timestamp()

            ret, frame = self._cap.read()
            if not ret:
                break

            # Simulate latency
            latency = self.latency_fn()
            await asyncio.sleep(latency)
            frame_latency.labels(self.camera_id).observe(latency)

            # Process frame
            metadata = Metadata(camera_id=self.camera_id)
            proc_start = datetime.now(UTC).timestamp()
            try:
                result = self.process_fn(frame, metadata)
            except Exception:
                logger.exception(
                    "camera frame processing failed",
                    extra={
                        "event": "camera.frame.failed",
                        "camera_id": self.camera_id,
                    },
                )
                raise
            proc_time = datetime.now(UTC).timestamp() - proc_start

            frame_processing_time.labels(self.camera_id).observe(proc_time)
            frames_processed.labels(self.camera_id).inc()
            self._frames_seen += 1

            # Send processed output to the node-level consumer.
            await output_queue.put((result, metadata))

            # Enforce FPS
            elapsed = datetime.now(UTC).timestamp() - start
            await asyncio.sleep(max(0, self._frame_time - elapsed))

        logger.info(
            "camera stream ended",
            extra={
                "event": "camera.stream.ended",
                "camera_id": self.camera_id,
                "frames_processed": self._frames_seen,
            },
        )
