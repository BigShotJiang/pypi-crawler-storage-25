# Argus Node

`argus-node` is the camera node runtime for the distributed camera system. It is responsible for
loading camera configuration, running the node loop, collecting frames, processing them through
user-provided logic, and reporting back to the coordinator.

## Requirements

- Python `3.13+`
- `uv` for local development

## Installation

Install from PyPI:

```bash
pip install argus-node
```

For local development:

```bash
uv sync --dev
```

## Package Layout

- `argus/camera.py` - camera capture and frame timing
- `argus/coordinator.py` - coordinator communication
- `argus/node_runtime.py` - node execution lifecycle
- `argus/config.py` - runtime configuration
- `argus/logging_config.py` - logging setup
- `argus/metrics.py` - Prometheus metrics

## Development

Install dependencies and run the test suite from `src/argus`:

```bash
uv sync --locked --dev
uv run pytest
```

Build a wheel locally:

```bash
uv build
```

The build artifacts are written to `src/argus/dist/`.

