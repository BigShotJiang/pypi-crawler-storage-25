
class Singleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        else:
            instance = cls._instances[cls]
            validator = getattr(instance, '_validate_singleton_call', None)
            if validator is not None:
                validator(*args, **kwargs)
        return cls._instances[cls]
