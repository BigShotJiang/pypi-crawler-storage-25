from typing import Final
from unittest import TestCase
from unittest.mock import patch, Mock

import requests

from incognia.base_request import BaseRequest, USER_AGENT_HEADER
from incognia.exceptions import IncogniaHTTPError
from incognia.json_util import encode


class TestBaseRequest(TestCase):
    URL: Final[str] = 'https://some-valid-link.com'
    JSON_RESPONSE: Final[dict] = {
        'first-key': 'first-value',
        'second-key': 'second-value'
    }
    OK_STATUS_CODE: Final[int] = 200
    CLIENT_ERROR_CODE: Final[int] = 400

    @patch('requests.post')
    def test_post_when_parameters_are_valid_should_return_a_valid_dict(
            self, mock_requests_post: Mock):
        def get_mocked_response() -> requests.Response:
            response = requests.Response()
            response._content, response.status_code = encode(
                self.JSON_RESPONSE), self.OK_STATUS_CODE
            return response

        mock_requests_post.configure_mock(return_value=get_mocked_response())

        base_request = BaseRequest(keep_alive=False)
        result = base_request.post(url=self.URL)
        mock_requests_post.assert_called_with(url=self.URL, headers=USER_AGENT_HEADER, data=None,
                                              params=None,
                                              timeout=base_request.timeout(), auth=None)
        self.assertEqual(result, self.JSON_RESPONSE)

    @patch('requests.post')
    def test_post_when_parameters_are_invalid_should_raise_an_IncogniaHTTPError(
            self, mock_requests_post: Mock):
        def get_mocked_response() -> requests.Response:
            response = requests.Response()
            response._content, response.status_code = encode(
                self.JSON_RESPONSE), self.CLIENT_ERROR_CODE
            return response

        mock_requests_post.configure_mock(return_value=get_mocked_response())

        base_request = BaseRequest(keep_alive=False)
        self.assertRaises(IncogniaHTTPError, base_request.post, url=self.URL)
        mock_requests_post.assert_called_with(url=self.URL, headers=USER_AGENT_HEADER, data=None,
                                              params=None,
                                              timeout=base_request.timeout(), auth=None)

    @patch('requests.Session')
    def test_keep_alive_should_be_enabled_by_default(
            self, mock_session_class: Mock):
        BaseRequest()
        mock_session_class.assert_called_once_with()

    @patch('requests.Session')
    def test_post_with_keep_alive_should_use_session(
            self, mock_session_class: Mock):
        mock_session = Mock()
        mock_session_class.return_value = mock_session

        mock_response = requests.Response()
        mock_response._content = encode(self.JSON_RESPONSE)
        mock_response.status_code = self.OK_STATUS_CODE
        mock_session.post.return_value = mock_response

        base_request = BaseRequest(keep_alive=True, max_connections=5)
        result = base_request.post(url=self.URL)

        mock_session.post.assert_called_with(
            url=self.URL, headers=USER_AGENT_HEADER, data=None,
            params=None, timeout=base_request.timeout(), auth=None)
        self.assertEqual(result, self.JSON_RESPONSE)

    @patch('incognia.base_request.HTTPAdapter')
    @patch('requests.Session')
    def test_keep_alive_should_mount_adapter_with_max_connections(
            self, mock_session_class: Mock, mock_http_adapter_class: Mock):
        mock_session = Mock()
        mock_session_class.return_value = mock_session
        mock_adapter = Mock()
        mock_http_adapter_class.return_value = mock_adapter

        BaseRequest(keep_alive=True, max_connections=20)

        mock_http_adapter_class.assert_called_once_with(
            pool_connections=20, pool_maxsize=20)
        self.assertEqual(mock_session.mount.call_count, 2)
        https_call = mock_session.mount.call_args_list[0]
        http_call = mock_session.mount.call_args_list[1]
        self.assertEqual(https_call[0][0], 'https://')
        self.assertEqual(https_call[0][1], mock_adapter)
        self.assertEqual(http_call[0][0], 'http://')
        self.assertEqual(http_call[0][1], mock_adapter)

    def test_keep_alive_false_should_not_create_session(self):
        base_request = BaseRequest(keep_alive=False)
        self.assertIsNone(base_request._BaseRequest__session)
