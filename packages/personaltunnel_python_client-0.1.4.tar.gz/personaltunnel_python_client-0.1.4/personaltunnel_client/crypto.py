"""
Nostr mutual-auth handshake and ChaCha20-Poly1305 encrypted connection.

Wire protocol (client side):
  Step 1 receive: nonce_s (32) + server_pub_x_only (32)
  Step 1 send:    nonce_c (32) + client_pub_x_only (32)
  Step 2 send:    schnorr_sig(SHA256(nonce_s)) (64 bytes)
  Step 2 receive: schnorr_sig(SHA256(nonce_c)) (64 bytes)
  Step 3 receive: status byte (0x00 = OK, 0x01 = rejected)
  Step 4:         ECDH + HKDF → 32-byte ChaCha20-Poly1305 key

Crypto dependencies:
  - coincurve (via bip-utils): secp256k1 Schnorr BIP340 sign/verify, ECDH
  - cryptography: ChaCha20-Poly1305 AEAD, HKDF-SHA256
"""

from __future__ import annotations

import asyncio
import hashlib
import os
import struct

import coincurve
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

_MAX_MESSAGE_SIZE = 1 << 20  # 1 MiB, matches Go's maxMessageSize
_HKDF_INFO = b"personaltunnel-v1"
_STATUS_OK = 0x00


class HandshakeError(Exception):
    """Raised when the Nostr mutual-auth handshake fails."""


class EncConn:
    """
    Async ChaCha20-Poly1305 encrypted connection.

    Wire format per message:
        4 bytes  big-endian uint32: length of ciphertext (incl. 16-byte AEAD tag)
        N bytes  ChaCha20-Poly1305 ciphertext

    Nonces are 12-byte little-endian encodings of a uint64 counter (separate
    send/recv sequences starting at 0), matching Go's encconn.go seqNonce().
    """

    def __init__(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        key: bytes,
    ) -> None:
        self._reader = reader
        self._writer = writer
        self._aead = ChaCha20Poly1305(key)
        self._send_lock = asyncio.Lock()
        self._send_seq: int = 0
        self._recv_seq: int = 0
        self._recv_buf = bytearray()

    @staticmethod
    def _seq_nonce(seq: int) -> bytes:
        """12-byte little-endian nonce from a uint64 counter (4 zero pad bytes)."""
        return struct.pack("<Q", seq) + b"\x00\x00\x00\x00"

    async def send_msg(self, plaintext: bytes) -> None:
        """Encrypt plaintext and write as a single length-prefixed message."""
        async with self._send_lock:
            nonce = self._seq_nonce(self._send_seq)
            self._send_seq += 1
            ciphertext = self._aead.encrypt(nonce, plaintext, None)
            if len(ciphertext) > _MAX_MESSAGE_SIZE:
                raise ValueError(f"message too large: {len(ciphertext)} bytes")
            self._writer.write(struct.pack(">I", len(ciphertext)) + ciphertext)
            await self._writer.drain()

    async def recv_msg(self) -> bytes:
        """Read and decrypt the next length-prefixed message."""
        length_bytes = await self._reader.readexactly(4)
        msg_len = struct.unpack(">I", length_bytes)[0]
        if msg_len == 0 or msg_len > _MAX_MESSAGE_SIZE:
            raise ValueError(f"invalid message length: {msg_len}")
        ciphertext = await self._reader.readexactly(msg_len)
        nonce = self._seq_nonce(self._recv_seq)
        self._recv_seq += 1
        try:
            return self._aead.decrypt(nonce, ciphertext, None)
        except Exception as exc:
            raise ValueError(f"decryption failed: {exc}") from exc

    async def read(self, n: int) -> bytes:
        """
        Read exactly n bytes, decrypting new messages as needed.
        Excess plaintext from a decrypted message is retained in an internal
        buffer for subsequent reads, matching Go's encConn.Read() behaviour.
        """
        while len(self._recv_buf) < n:
            chunk = await self.recv_msg()
            self._recv_buf.extend(chunk)
        data = bytes(self._recv_buf[:n])
        del self._recv_buf[:n]
        return data

    async def write(self, data: bytes) -> None:
        """Encrypt and send data (one encrypted message per call)."""
        await self.send_msg(data)

    def close(self) -> None:
        """Close the underlying transport."""
        self._writer.close()


async def client_handshake(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    client_priv_bytes: bytes,
    expected_server_pub_x: bytes,
) -> EncConn:
    """
    Perform the Nostr mutual-auth handshake as the client side.

    Args:
        reader: asyncio StreamReader connected to the server control port.
        writer: asyncio StreamWriter connected to the server control port.
        client_priv_bytes: 32-byte raw secp256k1 private key.
        expected_server_pub_x: 32-byte x-only Nostr pubkey of the server.

    Returns:
        An EncConn ready to be used as a yamux transport.

    Raises:
        HandshakeError: On pubkey mismatch, invalid signature, or server rejection.
    """
    # ── Step 1 receive: nonce_s + server_pub_x_only ──────────────────────────
    data = await reader.readexactly(64)
    nonce_s: bytes = data[:32]
    server_pub_x_only: bytes = data[32:]

    if server_pub_x_only != expected_server_pub_x:
        raise HandshakeError(
            f"server pubkey mismatch: got {server_pub_x_only.hex()}, "
            f"expected {expected_server_pub_x.hex()}"
        )

    # ── Step 1 send: nonce_c + client_pub_x_only ─────────────────────────────
    nonce_c: bytes = os.urandom(32)
    client_priv = coincurve.PrivateKey(secret=client_priv_bytes)
    # x-only pubkey: 32-byte x-coordinate (BIP340 even-Y key)
    client_pub_x_only: bytes = client_priv.public_key_xonly.format()
    writer.write(nonce_c + client_pub_x_only)
    await writer.drain()

    # ── Step 2 send: schnorr_sig(SHA256(nonce_s)) ────────────────────────────
    nonce_s_hash = hashlib.sha256(nonce_s).digest()
    sig_c: bytes = client_priv.sign_schnorr(nonce_s_hash)
    writer.write(sig_c)
    await writer.drain()

    # ── Step 2 receive: server signature over nonce_c ────────────────────────
    sig_s = await reader.readexactly(64)
    nonce_c_hash = hashlib.sha256(nonce_c).digest()
    server_xonly_pub = coincurve.PublicKeyXOnly(server_pub_x_only)
    if not server_xonly_pub.verify(sig_s, nonce_c_hash):
        raise HandshakeError("server signature verification failed")

    # ── Step 3 receive: status byte ──────────────────────────────────────────
    status = await reader.readexactly(1)
    if status[0] != _STATUS_OK:
        raise HandshakeError(
            f"server rejected connection (status {status[0]:#04x})"
        )

    # ── Step 4: ECDH + HKDF → encryption key ─────────────────────────────────
    shared_x = _ecdh_x(client_priv_bytes, server_pub_x_only)
    key = _derive_key(shared_x, salt=nonce_s + nonce_c)

    return EncConn(reader, writer, key)


def _ecdh_x(priv_bytes: bytes, peer_pub_x_only: bytes) -> bytes:
    """
    Compute the x-coordinate of the ECDH shared point.

    Peer's x-only key is converted to a compressed secp256k1 point using the
    BIP340 even-Y convention (0x02 prefix) before scalar multiplication.

    Equivalent to Go:
        btcec.ScalarMultNonConst(&privKeyScalar, peerPoint, peerPoint)
        sharedX := peerPoint.X.Bytes()
    """
    # BIP340 x-only → even-Y compressed point (0x02 prefix)
    peer_compressed = b"\x02" + peer_pub_x_only
    peer_pub = coincurve.PublicKey(peer_compressed)
    # multiply returns a new PublicKey; extract x-coordinate from compressed form
    shared_pub = peer_pub.multiply(priv_bytes)
    return shared_pub.format(compressed=True)[1:]  # 32-byte x-coordinate


def _derive_key(ikm: bytes, salt: bytes) -> bytes:
    """
    HKDF-SHA256 with info="personaltunnel-v1", output 32 bytes.

    Equivalent to Go:
        hkdf.New(sha256.New, sharedX, salt, []byte("personaltunnel-v1"))
    """
    hkdf = HKDF(
        algorithm=SHA256(),
        length=32,
        salt=salt,
        info=_HKDF_INFO,
    )
    return hkdf.derive(ikm)


def generate_keypair() -> tuple[str, str]:
    """
    Generate a new secp256k1 keypair suitable for use with personaltunnel.

    Returns:
        (privkey_hex, pubkey_hex) where pubkey_hex is the 32-byte x-only
        (Nostr/BIP340) public key, both hex-encoded.
    """
    priv = coincurve.PrivateKey()
    priv_hex = priv.secret.hex()
    pub_hex = priv.public_key_xonly.format().hex()
    return priv_hex, pub_hex
