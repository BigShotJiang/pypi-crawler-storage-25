"""
personaltunnel_client — asyncio Python client library for the personaltunnel Go server.

Quick start::

    import asyncio
    from personaltunnel_client import PersonalTunnelClient, generate_keypair

    # Generate a keypair (one-time setup — share your public key with the server operator)
    priv_hex, pub_hex = generate_keypair()

    async def main():
        async with PersonalTunnelClient(
            server_addr="vps.example.com",
            control_port=7000,
            local_addr="localhost:8000",
            client_priv_key=priv_hex,
            server_pub_key="<server_pub_hex>",
        ):
            print("Tunnel active. Press Ctrl+C to stop.")
            await asyncio.Event().wait()  # run forever

    asyncio.run(main())
"""

from .client import PersonalTunnelClient
from .crypto import generate_keypair

__all__ = ["PersonalTunnelClient", "generate_keypair"]
