"""
PersonalTunnelClient — asyncio client that connects to the personaltunnel
Go server, authenticates via the Nostr handshake, and forwards public HTTP
requests to a local service via yamux streams.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from typing import Awaitable, Callable, Optional

from .crypto import EncConn, HandshakeError, client_handshake
from .forward import handle_stream
from .yamux import YamuxSession

logger = logging.getLogger(__name__)


class PersonalTunnelClient:
    """
    Asyncio client library for the personaltunnel Go server.

    Connects to the server's control port, performs Nostr mutual-auth,
    multiplexes incoming HTTP requests over a yamux session, and forwards
    each request to a local service. Reconnects automatically with
    exponential backoff on connection loss.

    Usage::

        # Async context manager (tunnel runs as a background task)
        async with PersonalTunnelClient(
            server_addr="vps.example.com",
            control_port=7000,
            local_addr="localhost:8000",
            client_priv_key="<hex>",
            server_pub_key="<hex>",
        ) as client:
            await asyncio.sleep(3600)

        # Explicit background task
        client = PersonalTunnelClient(...)
        task = await client.start()
        await asyncio.sleep(3600)
        await client.stop()

        # Blocking run (never returns until stop() is called elsewhere)
        await client.run()
    """

    def __init__(
        self,
        server_addr: str,
        control_port: int,
        local_addr: str,
        client_priv_key: str,
        server_pub_key: str,
        reconnect_interval: float = 2.0,
        on_connect: Optional[Callable[[], Awaitable[None] | None]] = None,
        on_disconnect: Optional[
            Callable[[Optional[Exception]], Awaitable[None] | None]
        ] = None,
    ) -> None:
        """
        Args:
            server_addr:         Hostname or IP of the VPS running the Go server.
            control_port:        Control port of the Go server (typically 7000).
            local_addr:          Local service to forward traffic to
                                 (e.g. "localhost:8000").
            client_priv_key:     Hex-encoded 32-byte secp256k1 private key.
            server_pub_key:      Hex-encoded 32-byte x-only secp256k1 public key
                                 of the server (from ``generate_keypair()``).
            reconnect_interval:  Base reconnect delay in seconds (doubles on
                                 each failure, capped at 60 s).
            on_connect:          Optional async or sync callback invoked each
                                 time the tunnel connects successfully.
            on_disconnect:       Optional async or sync callback invoked when
                                 the tunnel disconnects. Receives the exception
                                 that caused the disconnect (or None on clean close).
        """
        self.server_addr = server_addr
        self.control_port = control_port
        self.local_addr = local_addr
        self.reconnect_interval = reconnect_interval
        self.on_connect = on_connect
        self.on_disconnect = on_disconnect

        # Pre-decode keys so errors surface at construction time.
        self._client_priv_bytes: bytes = bytes.fromhex(client_priv_key)
        self._server_pub_x: bytes = bytes.fromhex(server_pub_key)

        if len(self._client_priv_bytes) != 32:
            raise ValueError("client_priv_key must be a 32-byte (64 hex char) key")
        if len(self._server_pub_x) != 32:
            raise ValueError("server_pub_key must be a 32-byte (64 hex char) x-only key")

        self._stop_event: asyncio.Event | None = None
        self._task: asyncio.Task | None = None
        self._active_session: YamuxSession | None = None

    # ── Public API ───────────────────────────────────────────────────────────

    async def start(self) -> asyncio.Task:
        """
        Start the tunnel in a background asyncio Task.

        Returns the running Task so callers can await it or cancel it if needed.
        """
        self._stop_event = asyncio.Event()
        self._task = asyncio.create_task(
            self._run_loop(), name="personaltunnel-client"
        )
        return self._task

    async def stop(self) -> None:
        """Signal the client to stop and wait for the background task to finish."""
        if self._stop_event:
            self._stop_event.set()
        if self._active_session:
            await self._active_session.close()
        if self._task and not self._task.done():
            try:
                await asyncio.wait_for(self._task, timeout=5.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._task.cancel()

    async def run(self) -> None:
        """
        Run the tunnel reconnect loop until stop() is called.

        Useful as a top-level coroutine::

            client = PersonalTunnelClient(...)
            await client.run()
        """
        self._stop_event = asyncio.Event()
        await self._run_loop()

    async def __aenter__(self) -> "PersonalTunnelClient":
        await self.start()
        return self

    async def __aexit__(self, *_args: object) -> None:
        await self.stop()

    # ── Internal ─────────────────────────────────────────────────────────────

    async def _run_loop(self) -> None:
        """Reconnect loop with exponential backoff."""
        assert self._stop_event is not None

        backoff = self.reconnect_interval

        while not self._stop_event.is_set():
            exc: Exception | None = None
            try:
                await self._connect_once()
                backoff = self.reconnect_interval
            except asyncio.CancelledError:
                return
            except (HandshakeError, ValueError) as e:
                logger.error("tunnel: auth error: %s", e)
                exc = e
            except Exception as e:
                logger.warning("tunnel: disconnected (%r), retry in %.1fs", e, backoff)
                exc = e
            else:
                logger.info("tunnel: session closed cleanly")

            if self.on_disconnect:
                await _maybe_await(self.on_disconnect(exc))

            # Wait for backoff duration (wake immediately if stop() is called).
            try:
                await asyncio.wait_for(
                    asyncio.shield(self._stop_event.wait()),
                    timeout=backoff,
                )
                return  # stop was requested
            except asyncio.TimeoutError:
                pass

            if exc is not None:
                backoff = min(backoff * 2, 60.0)

    async def _connect_once(self) -> None:
        """Open one connection to the server and serve streams until closed."""
        addr = f"{self.server_addr}:{self.control_port}"
        logger.info("tunnel: connecting to %s", addr)

        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(self.server_addr, self.control_port),
            timeout=10.0,
        )

        try:
            enc_conn: EncConn = await client_handshake(
                reader,
                writer,
                self._client_priv_bytes,
                self._server_pub_x,
            )

            session = YamuxSession(enc_conn)
            self._active_session = session
            await session.start()

            logger.info("tunnel: connected and authenticated to %s", addr)
            if self.on_connect:
                await _maybe_await(self.on_connect())

            while not session.closed:
                stream = await session.accept()
                if stream is None:
                    break
                asyncio.create_task(
                    handle_stream(stream, self.local_addr),
                    name=f"stream-{stream._stream_id}",
                )

        finally:
            self._active_session = None
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass


async def _maybe_await(result: object) -> None:
    """Await *result* if it is a coroutine, otherwise discard it."""
    if inspect.isawaitable(result):
        await result  # type: ignore[arg-type]
