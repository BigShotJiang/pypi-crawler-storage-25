SPDX-License-Identifier: AGPL-3.0-or-later | Commercial license available
© Concepts 1996–2026 Miroslav Šotek. All rights reserved.
© Code 2020–2026 Miroslav Šotek. All rights reserved.
ORCID: 0009-0009-3560-0851
Contact: www.anulum.li | protoscience@anulum.li

# Contributors

## Maintainer

- **Miroslav Šotek** — Creator, maintainer ([ORCID: 0009-0009-3560-0851](https://orcid.org/0009-0009-3560-0851))

## AI Collaborator

- **Arcane Sapience** — Architecture, implementation, testing, documentation
