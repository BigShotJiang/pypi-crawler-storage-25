use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::thread;
use std::time::Duration;
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::Value;
use tempfile::{tempdir, TempDir};

const RG_SENTINEL: &str = "TG_RG_ROUTING_SENTINEL";

fn normalize_newlines(text: &str) -> String {
    text.replace("\r\n", "\n")
}

fn combined_output(output: &Output) -> String {
    format!(
        "{}{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    )
}

fn tg() -> Command {
    Command::new(env!("CARGO_BIN_EXE_tg"))
}

fn tg_fast() -> Command {
    Command::new(env!("CARGO_BIN_EXE_tg-search-fast"))
}

fn repo_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .unwrap()
        .to_path_buf()
}

fn repo_python() -> PathBuf {
    let windows = repo_root().join(".venv").join("Scripts").join("python.exe");
    if windows.exists() {
        return windows;
    }

    repo_root().join(".venv").join("bin").join("python")
}

fn write_text_corpus(dir: &Path) {
    fs::write(
        dir.join("a.txt"),
        "hello world\nfoo bar baz\ngoodbye world\n",
    )
    .unwrap();
    fs::write(dir.join("b.txt"), "nothing here\nhello again friend\nend\n").unwrap();
    fs::write(dir.join("notes.md"), "hello from markdown\n").unwrap();
}

fn write_sized_routing_corpus(dir: &Path, target_bytes: usize) -> PathBuf {
    let corpus = dir.join(format!("corpus-{target_bytes}"));
    fs::create_dir(&corpus).unwrap();

    let chunk = b"INFO steady state\nERROR gpu auto route\nWARN retry later\n";
    let mut bytes = Vec::new();
    while bytes.len() < target_bytes {
        bytes.extend_from_slice(chunk);
    }

    let file_count = 4usize;
    let chunk_size = bytes.len().div_ceil(file_count);
    for index in 0..file_count {
        let start = index * chunk_size;
        if start >= bytes.len() {
            break;
        }
        let end = ((index + 1) * chunk_size).min(bytes.len());
        fs::write(
            corpus.join(format!("chunk-{index}.log")),
            &bytes[start..end],
        )
        .unwrap();
    }

    corpus
}

fn unix_timestamp_now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_secs()
}

fn write_crossover_config(
    path: &Path,
    breakpoint_bytes: u64,
    cpu_median_ms: f64,
    gpu_median_ms: f64,
    recommendation: &str,
    calibration_timestamp: u64,
) {
    let payload = serde_json::json!({
        "version": 1,
        "routing_backend": "Calibration",
        "routing_reason": "manual-calibrate",
        "sidecar_used": false,
        "corpus_size_breakpoint_bytes": breakpoint_bytes,
        "cpu_median_ms": cpu_median_ms,
        "gpu_median_ms": gpu_median_ms,
        "recommendation": recommendation,
        "calibration_timestamp": calibration_timestamp,
        "device_name": "Mock RTX 4070",
        "measurements": [
            {
                "size_bytes": breakpoint_bytes,
                "cpu_median_ms": cpu_median_ms,
                "gpu_median_ms": gpu_median_ms,
                "cpu_samples_ms": [cpu_median_ms],
                "gpu_samples_ms": [gpu_median_ms]
            }
        ]
    });

    fs::create_dir_all(path.parent().unwrap()).unwrap();
    fs::write(path, serde_json::to_vec_pretty(&payload).unwrap()).unwrap();
}

fn write_python_source() -> (TempDir, PathBuf) {
    let dir = tempdir().unwrap();
    let file_path = dir.path().join("fixture.py");
    fs::write(&file_path, "def add(a, b):\n    return a + b\n").unwrap();
    (dir, file_path)
}

fn write_python_wrapper(dir: &Path) -> PathBuf {
    if cfg!(windows) {
        let script = dir.join("python-wrapper.cmd");
        fs::write(&script, "@echo off\r\necho %*\r\n").unwrap();
        script
    } else {
        let script = dir.join("python-wrapper.sh");
        fs::write(&script, "#!/bin/sh\nprintf '%s\\n' \"$*\"\n").unwrap();
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;

            let mut permissions = fs::metadata(&script).unwrap().permissions();
            permissions.set_mode(0o755);
            fs::set_permissions(&script, permissions).unwrap();
        }
        script
    }
}

fn build_index(dir: &Path) {
    let output = tg()
        .arg("search")
        .arg("--index")
        .arg("--fixed-strings")
        .arg("--count")
        .arg("hello")
        .arg(dir)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
}

fn write_rg_wrapper(dir: &Path) -> PathBuf {
    if cfg!(windows) {
        let script = dir.join("rg-wrapper.cmd");
        fs::write(&script, format!("@echo off\r\necho {RG_SENTINEL}\r\n")).unwrap();
        script
    } else {
        let script = dir.join("rg-wrapper.sh");
        fs::write(&script, format!("#!/bin/sh\nprintf '{RG_SENTINEL}\\n'\n")).unwrap();
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;

            let mut permissions = fs::metadata(&script).unwrap().permissions();
            permissions.set_mode(0o755);
            fs::set_permissions(&script, permissions).unwrap();
        }
        script
    }
}

fn write_rg_required_args_wrapper(dir: &Path, required_args: &[&str]) -> PathBuf {
    if cfg!(windows) {
        let script = dir.join("rg-required-wrapper.cmd");
        let mut body = String::from("@echo off\r\n");
        for (index, required) in required_args.iter().enumerate() {
            body.push_str(&format!("set FOUND_{index}=\r\n"));
            body.push_str("for %%A in (%*) do (\r\n");
            body.push_str(&format!(
                "  if \"%%~A\"==\"{required}\" set FOUND_{index}=1\r\n"
            ));
            body.push_str(")\r\n");
            body.push_str(&format!(
                "if not \"%FOUND_{index}%\"==\"1\" echo missing {required} 1>&2 & exit /b 9\r\n"
            ));
        }
        body.push_str(&format!("echo {RG_SENTINEL}\r\n"));
        fs::write(&script, body).unwrap();
        script
    } else {
        let script = dir.join("rg-required-wrapper.sh");
        let mut body = String::from("#!/bin/sh\n");
        for required in required_args {
            body.push_str("found=0\n");
            body.push_str("for arg in \"$@\"; do\n");
            body.push_str(&format!(
                "  if [ \"$arg\" = '{}' ]; then found=1; fi\n",
                required.replace('\'', "'\\''")
            ));
            body.push_str("done\n");
            body.push_str(&format!(
                "if [ \"$found\" != 1 ]; then echo 'missing {}' >&2; exit 9; fi\n",
                required.replace('\'', "'\\''")
            ));
        }
        body.push_str(&format!("printf '{RG_SENTINEL}\\n'\n"));
        fs::write(&script, body).unwrap();
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;

            let mut permissions = fs::metadata(&script).unwrap().permissions();
            permissions.set_mode(0o755);
            fs::set_permissions(&script, permissions).unwrap();
        }
        script
    }
}

fn write_mock_gpu_sidecar_script(dir: &Path, matched_file: &Path, marker: &Path) -> PathBuf {
    let script = dir.join("mock_gpu_sidecar.py");
    fs::write(
        &script,
        format!(
            "import json\nimport os\nimport pathlib\nimport sys\nrequest = json.loads(sys.stdin.buffer.read())\npathlib.Path(r\"{}\").write_text('invoked', encoding='utf-8')\nresponse = {{\"stdout\": json.dumps({{\"total_matches\": 1, \"total_files\": 1, \"matches\": [{{\"file\": {:?}, \"line_number\": 1, \"text\": \"hello world\"}}]}}) + '\\n', \"stderr\": \"\", \"exit_code\": 0, \"pid\": os.getpid()}}\nsys.stdout.write(json.dumps(response))\n",
            marker.display(),
            matched_file.display().to_string(),
        ),
    )
    .unwrap();
    script
}

fn assert_verbose_routing(stderr: &str, backend: &str, reason: &str, sidecar_used: bool) {
    assert!(
        stderr.contains(&format!("routing_backend={backend}")),
        "stderr={stderr}"
    );
    assert!(
        stderr.contains(&format!("routing_reason={reason}")),
        "stderr={stderr}"
    );
    assert!(
        stderr.contains(&format!("sidecar_used={sidecar_used}")),
        "stderr={stderr}"
    );
}

fn assert_json_routing(output: &Output, backend: &str, reason: &str, sidecar_used: bool) -> Value {
    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let payload: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(payload["routing_backend"], backend);
    assert_eq!(payload["routing_reason"], reason);
    assert_eq!(payload["sidecar_used"], sidecar_used);
    payload
}

fn assert_ndjson_routing(
    output: &Output,
    backend: &str,
    reason: &str,
    sidecar_used: bool,
) -> Vec<Value> {
    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    let payloads = stdout
        .lines()
        .filter(|line| !line.trim().is_empty())
        .map(|line| serde_json::from_str::<Value>(line).unwrap())
        .collect::<Vec<_>>();

    assert!(!payloads.is_empty(), "stdout={stdout}");

    for payload in &payloads {
        assert_eq!(payload["routing_backend"], backend);
        assert_eq!(payload["routing_reason"], reason);
        assert_eq!(payload["sidecar_used"], sidecar_used);
    }

    payloads
}

#[test]
fn test_calibrate_writes_valid_crossover_config_from_mock_results() {
    let dir = tempdir().unwrap();
    let config_path = dir.path().join("crossover.json");
    let mock_results = serde_json::json!({
        "device_name": "Mock RTX 4070",
        "measurements": [
            {
                "size_bytes": 1024_u64 * 1024,
                "cpu_samples_ms": [5.0, 6.0, 5.5],
                "gpu_samples_ms": [20.0, 21.0, 19.0]
            },
            {
                "size_bytes": 10_u64 * 1024 * 1024,
                "cpu_samples_ms": [12.0, 11.5, 12.5],
                "gpu_samples_ms": [14.0, 13.5, 14.5]
            },
            {
                "size_bytes": 100_u64 * 1024 * 1024,
                "cpu_samples_ms": [50.0, 49.0, 51.0],
                "gpu_samples_ms": [39.0, 40.0, 41.0]
            },
            {
                "size_bytes": 500_u64 * 1024 * 1024,
                "cpu_samples_ms": [240.0, 245.0, 250.0],
                "gpu_samples_ms": [145.0, 150.0, 155.0]
            },
            {
                "size_bytes": 1024_u64 * 1024 * 1024,
                "cpu_samples_ms": [500.0, 510.0, 520.0],
                "gpu_samples_ms": [250.0, 255.0, 260.0]
            }
        ]
    });

    let output = tg()
        .arg("calibrate")
        .env("TG_CROSSOVER_CONFIG_PATH", &config_path)
        .env("TG_TEST_CALIBRATION_RESULTS", mock_results.to_string())
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout_payload: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(stdout_payload["version"], Value::from(1));
    assert_eq!(
        stdout_payload["routing_backend"],
        Value::from("Calibration")
    );
    assert_eq!(
        stdout_payload["routing_reason"],
        Value::from("manual-calibrate")
    );
    assert_eq!(stdout_payload["sidecar_used"], Value::from(false));
    assert_eq!(
        stdout_payload["corpus_size_breakpoint_bytes"],
        Value::from(100_u64 * 1024 * 1024)
    );
    assert_eq!(
        stdout_payload["recommendation"],
        Value::from("gpu_above_100mb")
    );
    assert_eq!(stdout_payload["device_name"], Value::from("Mock RTX 4070"));
    assert_eq!(stdout_payload["measurements"].as_array().unwrap().len(), 5);

    let config_payload: Value = serde_json::from_slice(&fs::read(&config_path).unwrap()).unwrap();
    assert_eq!(config_payload, stdout_payload);
}

#[test]
fn test_repeated_calibrate_overwrites_config_and_keeps_output_contract_stable() {
    let dir = tempdir().unwrap();
    let config_path = dir.path().join("crossover.json");

    let gpu_positive = serde_json::json!({
        "device_name": "Mock RTX 4070",
        "measurements": [
            {
                "size_bytes": 100_u64 * 1024 * 1024,
                "cpu_samples_ms": [50.0, 49.0, 51.0],
                "gpu_samples_ms": [39.0, 40.0, 41.0]
            }
        ]
    });
    let cpu_always = serde_json::json!({
        "device_name": "Mock RTX 4070",
        "measurements": [
            {
                "size_bytes": 100_u64 * 1024 * 1024,
                "cpu_samples_ms": [10.0, 11.0, 12.0],
                "gpu_samples_ms": [20.0, 21.0, 22.0]
            }
        ]
    });

    for (mock_results, expected_recommendation) in [
        (gpu_positive, Value::from("gpu_above_100mb")),
        (cpu_always, Value::from("cpu_always")),
    ] {
        let output = tg()
            .arg("calibrate")
            .env("TG_CROSSOVER_CONFIG_PATH", &config_path)
            .env("TG_TEST_CALIBRATION_RESULTS", mock_results.to_string())
            .output()
            .unwrap();

        assert!(
            output.status.success(),
            "status={:?}\nstdout={}\nstderr={}",
            output.status.code(),
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );

        let stdout_payload: Value = serde_json::from_slice(&output.stdout).unwrap();
        assert_eq!(stdout_payload["version"], Value::from(1));
        assert_eq!(
            stdout_payload["routing_backend"],
            Value::from("Calibration")
        );
        assert_eq!(
            stdout_payload["routing_reason"],
            Value::from("manual-calibrate")
        );
        assert_eq!(stdout_payload["sidecar_used"], Value::from(false));
        assert_eq!(stdout_payload["recommendation"], expected_recommendation);

        let config_payload: Value =
            serde_json::from_slice(&fs::read(&config_path).unwrap()).unwrap();
        assert_eq!(config_payload, stdout_payload);
    }
}

#[test]
fn test_routing_default_search_prefers_ripgrep_cold_path() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path().join("a.txt"))
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[test]
fn test_routing_directory_search_promotes_to_native_cpu() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path())
        .output()
        .unwrap();

    assert!(output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);

    if stderr.contains("routing_backend=RipgrepBackend") {
        assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
    } else if stderr.contains("routing_reason=rg_unavailable") {
        assert_verbose_routing(&stderr, "NativeCpuBackend", "rg_unavailable", false);
    } else {
        assert_verbose_routing(
            &stderr,
            "NativeCpuBackend",
            "cpu-auto-size-threshold",
            false,
        );
    }
}

#[test]
fn test_routing_early_rg_env_preserves_plain_search_contract() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .env("TG_RUST_EARLY_RG", "1")
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_top_level_format_rg_fixed_string_routes_before_positional_parser() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("--format")
        .arg("rg")
        .arg("--color")
        .arg("never")
        .arg("--sort")
        .arg("path")
        .arg("-n")
        .arg("-F")
        .arg("Actionable Context")
        .arg(dir.path().join("notes.md"))
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_search_format_rg_json_routes_to_ripgrep_passthrough() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--format")
        .arg("rg")
        .arg("--json")
        .arg("-F")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .env(
            "TG_TEST_NATIVE_SEARCH_FORCE_ERROR",
            "native search should not handle explicit rg json",
        )
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_top_level_format_rg_json_routes_before_positional_parser() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("--format")
        .arg("rg")
        .arg("--json")
        .arg("-F")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .env(
            "TG_TEST_NATIVE_SEARCH_FORCE_ERROR",
            "native search should not handle explicit root rg json",
        )
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_top_level_type_flag_rewrites_to_search_subcommand() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_required_args_wrapper(dir.path(), &["-t", "js"]);

    let output = tg()
        .arg("-t")
        .arg("js")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_top_level_count_matches_rewrites_to_search_subcommand() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_required_args_wrapper(dir.path(), &["--count-matches"]);

    let output = tg()
        .arg("--count-matches")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_routing_early_positional_rg_env_preserves_plain_search_contract() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .env("TG_RUST_EARLY_POSITIONAL_RG", "1")
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_routing_early_positional_rg_env_preserves_max_count_contract() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("-m")
        .arg("1")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RUST_EARLY_POSITIONAL_RG", "1")
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_routing_early_positional_rg_env_preserves_word_regexp_contract() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("-w")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RUST_EARLY_POSITIONAL_RG", "1")
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_routing_early_positional_rg_env_falls_back_for_unsupported_shapes() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("--help")
        .env("TG_RG_PATH", &rg_wrapper)
        .env("TG_RUST_EARLY_POSITIONAL_RG", "1")
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(!String::from_utf8_lossy(&output.stdout).contains(RG_SENTINEL));
}

#[test]
fn test_fast_search_binary_preserves_plain_search_contract() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg_fast()
        .arg("--no-ignore")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        format!("{RG_SENTINEL}\n")
    );
}

#[test]
fn test_routing_small_corpus_prefers_ripgrep_without_calibration() {
    let dir = tempdir().unwrap();
    let corpus = write_sized_routing_corpus(dir.path(), 10 * 1024 * 1024);
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--count")
        .arg("--verbose")
        .arg("ERROR gpu auto route")
        .arg(&corpus)
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[cfg(feature = "cuda")]
#[test]
fn test_routing_large_corpus_auto_routes_to_gpu_native() {
    let devices = tensor_grep_rs::gpu_native::enumerate_cuda_devices();
    if devices.as_ref().map_or(true, |devices| devices.is_empty()) {
        return;
    }

    let dir = tempdir().unwrap();
    let corpus = write_sized_routing_corpus(dir.path(), 100 * 1024 * 1024);
    let config_path = dir.path().join("fresh-crossover.json");
    write_crossover_config(
        &config_path,
        10 * 1024 * 1024,
        90.0,
        40.0,
        "gpu_above_10mb",
        unix_timestamp_now(),
    );

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--count")
        .arg("--verbose")
        .arg("ERROR gpu auto route")
        .arg(&corpus)
        .env("TG_CROSSOVER_CONFIG_PATH", &config_path)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(
        &stderr,
        "NativeGpuBackend",
        "gpu-auto-size-threshold",
        false,
    );
}

#[test]
fn test_routing_large_corpus_without_calibration_prefers_ripgrep() {
    let dir = tempdir().unwrap();
    let corpus = write_sized_routing_corpus(dir.path(), 60 * 1024 * 1024);
    let config_path = dir.path().join("missing-crossover.json");
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--count")
        .arg("--verbose")
        .arg("ERROR gpu auto route")
        .arg(&corpus)
        .env("TG_CROSSOVER_CONFIG_PATH", &config_path)
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[test]
fn test_routing_stale_crossover_config_falls_back_to_ripgrep() {
    let dir = tempdir().unwrap();
    let corpus = write_sized_routing_corpus(dir.path(), 60 * 1024 * 1024);
    let config_path = dir.path().join("stale-crossover.json");
    let rg_wrapper = write_rg_wrapper(dir.path());
    write_crossover_config(
        &config_path,
        10 * 1024 * 1024,
        80.0,
        40.0,
        "gpu_above_10mb",
        unix_timestamp_now() - (8 * 24 * 60 * 60),
    );

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--count")
        .arg("--verbose")
        .arg("ERROR gpu auto route")
        .arg(&corpus)
        .env("TG_CROSSOVER_CONFIG_PATH", &config_path)
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[test]
fn test_routing_cpu_always_crossover_config_prefers_ripgrep() {
    let dir = tempdir().unwrap();
    let corpus = write_sized_routing_corpus(dir.path(), 60 * 1024 * 1024);
    let config_path = dir.path().join("cpu-always-crossover.json");
    let rg_wrapper = write_rg_wrapper(dir.path());
    write_crossover_config(
        &config_path,
        1024 * 1024 * 1024,
        500.0,
        650.0,
        "cpu_always",
        unix_timestamp_now(),
    );

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--count")
        .arg("--verbose")
        .arg("ERROR gpu auto route")
        .arg(&corpus)
        .env("TG_CROSSOVER_CONFIG_PATH", &config_path)
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[cfg(feature = "cuda")]
#[test]
fn test_routing_fresh_crossover_config_uses_calibrated_gpu_breakpoint() {
    let devices = tensor_grep_rs::gpu_native::enumerate_cuda_devices();
    if devices.as_ref().map_or(true, |devices| devices.is_empty()) {
        return;
    }

    let dir = tempdir().unwrap();
    let corpus = write_sized_routing_corpus(dir.path(), 20 * 1024 * 1024);
    let config_path = dir.path().join("fresh-crossover.json");
    write_crossover_config(
        &config_path,
        10 * 1024 * 1024,
        90.0,
        40.0,
        "gpu_above_10mb",
        unix_timestamp_now(),
    );

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--count")
        .arg("--verbose")
        .arg("ERROR gpu auto route")
        .arg(&corpus)
        .env("TG_CROSSOVER_CONFIG_PATH", &config_path)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(
        &stderr,
        "NativeGpuBackend",
        "gpu-auto-size-threshold",
        false,
    );
}

#[cfg(feature = "cuda")]
#[test]
fn test_routing_large_corpus_falls_back_to_cpu_when_cuda_is_unavailable() {
    let dir = tempdir().unwrap();
    let corpus = write_sized_routing_corpus(dir.path(), 100 * 1024 * 1024);
    let config_path = dir.path().join("fresh-crossover.json");
    write_crossover_config(
        &config_path,
        10 * 1024 * 1024,
        90.0,
        40.0,
        "gpu_above_10mb",
        unix_timestamp_now(),
    );

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--json")
        .arg("ERROR gpu auto route")
        .arg(&corpus)
        .env("TG_CROSSOVER_CONFIG_PATH", &config_path)
        .env("TG_TEST_CUDA_BEHAVIOR", "no-devices")
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );

    let payload: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(payload["routing_backend"], "NativeCpuBackend");
    assert_eq!(payload["routing_reason"], "gpu-auto-fallback-cpu");
    assert_eq!(payload["sidecar_used"], false);

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("warning:"), "stderr={stderr}");
    assert!(stderr.contains("CUDA is unavailable"), "stderr={stderr}");
    assert!(!stderr.contains("CUDA_ERROR"), "stderr={stderr}");
}

#[cfg(feature = "cuda")]
#[test]
fn test_routing_large_corpus_gpu_init_failure_is_user_facing() {
    let dir = tempdir().unwrap();
    let corpus = write_sized_routing_corpus(dir.path(), 100 * 1024 * 1024);
    let config_path = dir.path().join("fresh-crossover.json");
    write_crossover_config(
        &config_path,
        10 * 1024 * 1024,
        90.0,
        40.0,
        "gpu_above_10mb",
        unix_timestamp_now(),
    );

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--count")
        .arg("ERROR gpu auto route")
        .arg(&corpus)
        .env("TG_CROSSOVER_CONFIG_PATH", &config_path)
        .env(
            "TG_TEST_CUDA_BEHAVIOR",
            "init-failure:driver version is too old",
        )
        .output()
        .unwrap();

    assert_eq!(
        output.status.code(),
        Some(2),
        "stdout={} stderr={}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("CUDA initialization failed"),
        "stderr={stderr}"
    );
    assert!(
        stderr.contains("driver version is too old"),
        "stderr={stderr}"
    );
    assert!(!stderr.contains("CUDA_ERROR"), "stderr={stderr}");
    assert!(!stderr.contains("DriverError"), "stderr={stderr}");
}

#[test]
fn test_search_ndjson_emits_one_parseable_json_object_per_match() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--ndjson")
        .arg("hello")
        .arg(dir.path())
        .output()
        .unwrap();

    let payloads = assert_ndjson_routing(&output, "NativeCpuBackend", "json_output", false);
    assert_eq!(payloads.len(), 3);

    let mut actual = payloads
        .iter()
        .map(|payload| {
            let object = payload.as_object().unwrap();
            assert!(object.contains_key("query"));
            assert!(object.contains_key("path"));
            assert!(object.contains_key("file"));
            assert!(object.contains_key("line"));
            assert!(object.contains_key("text"));
            assert!(!object.contains_key("matches"));
            assert!(!object.contains_key("total_matches"));
            (
                payload["file"].as_str().unwrap().to_owned(),
                payload["line"].as_u64().unwrap(),
                payload["text"].as_str().unwrap().to_owned(),
            )
        })
        .collect::<Vec<_>>();
    actual.sort();

    let mut expected = vec![
        (
            dir.path().join("a.txt").display().to_string(),
            1,
            "hello world".to_string(),
        ),
        (
            dir.path().join("b.txt").display().to_string(),
            2,
            "hello again friend".to_string(),
        ),
        (
            dir.path().join("notes.md").display().to_string(),
            1,
            "hello from markdown".to_string(),
        ),
    ];
    expected.sort();

    assert_eq!(actual, expected);
}

#[test]
fn test_search_ndjson_suppresses_binary_warning_for_agent_contract() {
    let dir = tempdir().unwrap();
    let text_path = dir.path().join("text.log");
    let binary_path = dir.path().join("binary.bin");
    fs::write(&text_path, "ERROR visible\n").unwrap();
    fs::write(&binary_path, b"\0ERROR hidden\0").unwrap();

    let output = tg()
        .arg("search")
        .arg("--cpu")
        .arg("--fixed-strings")
        .arg("--ndjson")
        .arg("ERROR")
        .arg(dir.path())
        .output()
        .unwrap();

    let payloads = assert_ndjson_routing(&output, "NativeCpuBackend", "force_cpu", false);
    assert_eq!(
        payloads.len(),
        1,
        "stdout={}",
        String::from_utf8_lossy(&output.stdout)
    );
    assert_eq!(payloads[0]["file"], text_path.display().to_string());

    assert_eq!("", String::from_utf8_lossy(&output.stderr));
}

#[test]
fn test_search_single_binary_file_emits_stderr_warning_and_exit_zero() {
    let dir = tempdir().unwrap();
    let binary_path = dir.path().join("binary.bin");
    fs::write(&binary_path, b"\0ERROR hidden\0").unwrap();

    let output = tg()
        .arg("search")
        .arg("--cpu")
        .arg("--fixed-strings")
        .arg("ERROR")
        .arg(&binary_path)
        .env("TG_DISABLE_RG", "1")
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        String::from_utf8_lossy(&output.stdout).trim()
            == "binary file matches (found \"/0\" byte around offset 0)",
        "stdout={}",
        String::from_utf8_lossy(&output.stdout)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.trim().is_empty(), "stderr={stderr}");
}

#[test]
fn test_routing_force_cpu_routes_to_native_search_even_when_rg_is_available() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--cpu")
        .arg("--fixed-strings")
        .arg("--json")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "NativeCpuBackend", "force_cpu", false);
    assert_eq!(payload["total_matches"], 3);
    assert_ne!(String::from_utf8_lossy(&output.stdout).trim(), RG_SENTINEL);
}

#[test]
fn test_routing_json_hidden_flag_reaches_native_search() {
    let dir = tempdir().unwrap();
    fs::write(dir.path().join(".hidden.log"), "SECRET hidden match\n").unwrap();

    let output = tg()
        .arg("search")
        .arg("--cpu")
        .arg("--json")
        .arg("--hidden")
        .arg("--fixed-strings")
        .arg("SECRET")
        .arg(dir.path())
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "NativeCpuBackend", "force_cpu", false);
    assert_eq!(payload["total_matches"], 1);
    assert_eq!(payload["matches"][0]["text"], "SECRET hidden match");
}

#[test]
fn test_routing_json_max_depth_reaches_native_search() {
    let dir = tempdir().unwrap();
    fs::write(dir.path().join("root.log"), "SECRET root match\n").unwrap();
    let nested = dir.path().join("nested");
    fs::create_dir(&nested).unwrap();
    fs::write(nested.join("deep.log"), "SECRET nested match\n").unwrap();

    let output = tg()
        .arg("search")
        .arg("--cpu")
        .arg("--json")
        .arg("--max-depth")
        .arg("1")
        .arg("--fixed-strings")
        .arg("SECRET")
        .arg(dir.path())
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "NativeCpuBackend", "force_cpu", false);
    assert_eq!(payload["total_matches"], 1);
    assert_eq!(payload["matches"][0]["text"], "SECRET root match");
}

#[test]
fn test_routing_json_text_flag_reaches_native_search() {
    let dir = tempdir().unwrap();
    fs::write(dir.path().join("binary.dat"), b"SECRET\0binary match\n").unwrap();

    let output = tg()
        .arg("search")
        .arg("--cpu")
        .arg("--json")
        .arg("--text")
        .arg("--fixed-strings")
        .arg("SECRET")
        .arg(dir.path())
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "NativeCpuBackend", "force_cpu", false);
    assert_eq!(payload["total_matches"], 1);
    assert_eq!(payload["matches"][0]["text"], "SECRET\u{0}binary match");
}

#[test]
fn test_routing_force_cpu_alias_is_accepted() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--force-cpu")
        .arg("--fixed-strings")
        .arg("--json")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "NativeCpuBackend", "force_cpu", false);
    assert_eq!(payload["total_matches"], 3);
}

#[test]
fn test_routing_falls_back_to_native_when_ripgrep_is_unavailable() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path())
        .env("PATH", "")
        .env("TG_DISABLE_RG", "1")
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "NativeCpuBackend", "rg_unavailable", false);
    assert!(stdout.contains("hello world"), "stdout={stdout}");
    assert!(!stdout.contains(RG_SENTINEL), "stdout={stdout}");
}

#[test]
fn test_default_frontdoor_falls_back_to_native_when_ripgrep_is_unavailable() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("hello")
        .arg(dir.path())
        .env("PATH", "")
        .env("TG_DISABLE_RG", "1")
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello world"), "stdout={stdout}");
}

#[test]
fn test_search_json_and_ndjson_are_mutually_exclusive() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--json")
        .arg("--ndjson")
        .arg("hello")
        .arg(dir.path())
        .output()
        .unwrap();

    assert!(
        !output.status.success(),
        "stdout={}",
        String::from_utf8_lossy(&output.stdout)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("--json"), "stderr={stderr}");
    assert!(stderr.contains("--ndjson"), "stderr={stderr}");
}

#[test]
fn test_search_json_reports_empty_pattern_error() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--json")
        .arg("")
        .arg(dir.path())
        .output()
        .unwrap();

    assert!(
        !output.status.success(),
        "output={}",
        combined_output(&output)
    );
    assert_eq!(output.status.code(), Some(2));
    let payload: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(payload["ok"], false);
    assert_eq!(payload["error"], "empty_pattern");
    assert!(payload["detail"]
        .as_str()
        .unwrap()
        .contains("PATTERN must not be empty"));
}

#[test]
fn test_root_json_reports_empty_pattern_error() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg().arg("--json").arg("").arg(dir.path()).output().unwrap();

    assert!(
        !output.status.success(),
        "output={}",
        combined_output(&output)
    );
    assert_eq!(output.status.code(), Some(2));
    let payload: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(payload["ok"], false);
    assert_eq!(payload["error"], "empty_pattern");
}

#[test]
fn test_search_json_reports_missing_path_error() {
    let dir = tempdir().unwrap();
    let missing = dir.path().join("missing.txt");

    let output = tg()
        .arg("search")
        .arg("--json")
        .arg("hello")
        .arg(&missing)
        .output()
        .unwrap();

    assert!(
        !output.status.success(),
        "output={}",
        combined_output(&output)
    );
    assert_eq!(output.status.code(), Some(2));
    let payload: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(payload["ok"], false);
    assert_eq!(payload["error"], "path_not_found");
    assert!(payload["detail"]
        .as_str()
        .unwrap()
        .contains(&missing.to_string_lossy().to_string()));
}

#[test]
fn test_search_json_reports_invalid_regex_error() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--json")
        .arg("(")
        .arg(dir.path())
        .output()
        .unwrap();

    assert!(
        !output.status.success(),
        "output={}",
        combined_output(&output)
    );
    assert_eq!(output.status.code(), Some(2));
    let payload: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(payload["ok"], false);
    assert_eq!(payload["error"], "invalid_regex");
    assert!(payload["detail"]
        .as_str()
        .unwrap()
        .to_lowercase()
        .contains("invalid regex"));
}

#[test]
fn test_routing_explicit_index_uses_trigram_index_json() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--index")
        .arg("--fixed-strings")
        .arg("--json")
        .arg("hello")
        .arg(dir.path())
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "TrigramIndex", "index-accelerated", false);
    assert_eq!(payload["total_matches"], 3);
}

#[test]
fn test_routing_json_prefers_warm_index_even_when_json_is_requested() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    build_index(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--json")
        .arg("hello")
        .arg(dir.path())
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "TrigramIndex", "index-accelerated", false);
    assert_eq!(payload["total_matches"], 3);
}

#[test]
fn test_routing_warm_index_is_bypassed_by_invert_match() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    build_index(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("-v")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[test]
fn test_routing_warm_index_is_bypassed_by_context_lines() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    build_index(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("-C")
        .arg("1")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[test]
fn test_routing_explicit_gpu_device_ids_use_gpu_sidecar() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let marker = dir.path().join("gpu-sidecar-marker.txt");
    let matched_file = dir.path().join("a.txt");
    let sidecar_script = write_mock_gpu_sidecar_script(dir.path(), &matched_file, &marker);

    let output = tg()
        .current_dir(repo_root())
        .arg("search")
        .arg("--gpu-device-ids")
        .arg("0")
        .arg("--json")
        .arg("hello")
        .arg(dir.path())
        .env("TG_SIDECAR_PYTHON", repo_python())
        .env("TG_SIDECAR_SCRIPT", &sidecar_script)
        .output()
        .unwrap();

    if cfg!(feature = "cuda") {
        let payload = assert_json_routing(
            &output,
            "NativeGpuBackend",
            "gpu-device-ids-explicit-native",
            false,
        );
        assert_eq!(payload["total_matches"], 4);
        assert!(
            !marker.exists(),
            "native GPU routing should not invoke the Python sidecar"
        );
    } else {
        let payload = assert_json_routing(&output, "GpuSidecar", "gpu-device-ids-explicit", true);
        assert_eq!(payload["total_matches"], 1);
        assert!(marker.exists(), "expected mock GPU sidecar invocation");
    }
}

#[test]
fn test_routing_tg_run_uses_ast_backend() {
    let (_dir, file_path) = write_python_source();

    let output = tg()
        .arg("run")
        .arg("--lang")
        .arg("python")
        .arg("--json")
        .arg("def $F($$$ARGS): $$$BODY")
        .arg(&file_path)
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "AstBackend", "ast-native", false);
    assert_eq!(payload["total_matches"], 1);
}

#[test]
fn test_tg_run_rewrite_rejects_ndjson_without_python() {
    let bogus_python_home = tempdir().unwrap();
    let (_dir, file_path) = write_python_source();

    let output = tg()
        .arg("run")
        .arg("--lang")
        .arg("python")
        .arg("--rewrite")
        .arg("lambda $$$ARGS: $EXPR")
        .arg("--ndjson")
        .arg("def $F($$$ARGS): return $EXPR")
        .arg(&file_path)
        .env("PYTHONHOME", bogus_python_home.path())
        .output()
        .unwrap();

    assert!(
        !output.status.success(),
        "stdout={}",
        String::from_utf8_lossy(&output.stdout)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("--ndjson"), "stderr={stderr}");
    assert!(
        stderr.contains("unexpected")
            || stderr.contains("unknown")
            || stderr.contains("found argument"),
        "stderr={stderr}"
    );
}

#[test]
fn test_routing_warm_index_is_bypassed_by_short_pattern() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    build_index(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--verbose")
        .arg("he")
        .arg(dir.path().join("a.txt"))
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[test]
fn test_routing_warm_index_is_bypassed_by_word_regexp() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    build_index(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("-w")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[test]
fn test_routing_warm_index_is_bypassed_by_glob_filter() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    build_index(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("-g")
        .arg("*.txt")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[test]
fn test_routing_warm_index_is_bypassed_by_max_count() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    build_index(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--max-count")
        .arg("1")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
}

#[test]
fn test_routing_stale_index_with_explicit_index_rebuilds() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    build_index(dir.path());

    let index_path = dir.path().join(".tg_index");
    let before = index_path.metadata().unwrap().modified().unwrap();

    thread::sleep(Duration::from_millis(50));
    fs::write(dir.path().join("fresh.txt"), "hello from rebuilt index\n").unwrap();

    let output = tg()
        .arg("search")
        .arg("--index")
        .arg("--fixed-strings")
        .arg("--json")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path())
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "TrigramIndex", "index-accelerated", false);
    assert_eq!(payload["total_matches"], 4);

    let after = index_path.metadata().unwrap().modified().unwrap();
    assert!(
        after > before,
        "expected stale index rebuild to update mtime"
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("stale") || stderr.contains("rebuilding"),
        "stderr={stderr}"
    );
}

#[test]
fn test_routing_explicit_index_rebuilds_corrupt_index() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    fs::write(dir.path().join(".tg_index"), b"corrupt-index").unwrap();

    let output = tg()
        .arg("search")
        .arg("--index")
        .arg("--fixed-strings")
        .arg("--json")
        .arg("--verbose")
        .arg("hello")
        .arg(dir.path())
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "TrigramIndex", "index-accelerated", false);
    assert_eq!(payload["total_matches"], 3);

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("failed to load index") || stderr.contains("rebuilding"),
        "stderr={stderr}"
    );
}

#[test]
fn test_routing_directory_count_search_uses_native_cpu_without_fallback() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--verbose")
        .arg("-c")
        .arg("hello")
        .arg(dir.path())
        .output()
        .unwrap();

    assert!(output.status.success());
    let stderr = String::from_utf8_lossy(&output.stderr);

    if stderr.contains("routing_backend=RipgrepBackend") {
        assert_verbose_routing(&stderr, "RipgrepBackend", "rg_passthrough", false);
    } else if stderr.contains("routing_reason=rg_unavailable") {
        assert_verbose_routing(&stderr, "NativeCpuBackend", "rg_unavailable", false);
    } else {
        assert_verbose_routing(
            &stderr,
            "NativeCpuBackend",
            "cpu-auto-size-threshold",
            false,
        );
    }

    // Should NOT contain the fallback warning
    assert!(
        !stderr.contains("warning: native CPU search failed, falling back to ripgrep"),
        "Detected unexpected native CPU fallback in stderr: {}",
        stderr
    );

    // Verify output matches
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains(":1\n") || stdout.contains(":1\r\n"),
        "stdout={}",
        stdout
    );
}

#[test]
fn test_routing_external_editor_plane_commands_are_forwarded() {
    let scenarios = vec!["map", "session", "doctor", "dogfood"];
    let dir = tempdir().unwrap();
    let python_wrapper = write_python_wrapper(dir.path());

    for command in scenarios {
        let output = tg()
            .current_dir(repo_root())
            .arg(command)
            .arg("--help")
            .env("TG_SIDECAR_PYTHON", &python_wrapper)
            .output()
            .unwrap();

        let stdout = combined_output(&output);
        assert!(
            stdout.contains(&format!("-m tensor_grep {}", command)),
            "External command '{}' was not forwarded properly. stdout={}",
            command,
            stdout
        );
    }
}

#[test]
fn test_routing_native_editor_plane_commands() {
    let dir = tempdir().unwrap();
    let python_wrapper = write_python_wrapper(dir.path());

    for command in ["defs", "refs", "context"] {
        let output = tg()
            .current_dir(repo_root())
            .arg(command)
            .arg("--help")
            .env("TG_SIDECAR_PYTHON", &python_wrapper)
            .output()
            .unwrap();

        let stdout = combined_output(&output);
        assert!(
            stdout.contains(&format!("-m tensor_grep {}", command)),
            "Native editor-plane command '{}' was not forwarded properly. output={}",
            command,
            stdout
        );
        assert!(
            stdout.contains("--help"),
            "Native editor-plane command '{}' did not forward the help flag. output={}",
            command,
            stdout
        );
    }
}

#[test]
fn test_routing_ast_workflow_commands_are_native() {
    for command in ["scan", "test", "new"] {
        let output = tg().arg(command).arg("--help").output().unwrap();

        let stdout = String::from_utf8_lossy(&output.stdout);
        assert!(stdout.to_lowercase().contains("usage:"));
        assert!(stdout.contains(command));
    }
}

#[test]
fn test_routing_explicit_gpu_device_ids_override_warm_index() {
    let dir = tempdir().unwrap();
    let corpus_dir = dir.path().join("corpus");
    fs::create_dir(&corpus_dir).unwrap();
    write_text_corpus(&corpus_dir);
    build_index(&corpus_dir);

    let marker = dir.path().join("gpu-sidecar-priority-marker.txt");
    let matched_file = corpus_dir.join("a.txt");
    let sidecar_script = write_mock_gpu_sidecar_script(dir.path(), &matched_file, &marker);

    let output = tg()
        .current_dir(repo_root())
        .arg("search")
        .arg("--fixed-strings")
        .arg("--gpu-device-ids")
        .arg("0")
        .arg("--json")
        .arg("hello")
        .arg(&corpus_dir)
        .env("TG_SIDECAR_PYTHON", repo_python())
        .env("TG_SIDECAR_SCRIPT", &sidecar_script)
        .output()
        .unwrap();

    if cfg!(feature = "cuda") {
        let payload = assert_json_routing(
            &output,
            "NativeGpuBackend",
            "gpu-device-ids-explicit-native",
            false,
        );
        assert_eq!(payload["total_matches"], 3);
        assert!(
            !marker.exists(),
            "native GPU routing should bypass the Python sidecar"
        );
    } else {
        let payload = assert_json_routing(&output, "GpuSidecar", "gpu-device-ids-explicit", true);
        assert_eq!(payload["total_matches"], 1);
        assert!(marker.exists(), "expected mock GPU sidecar invocation");
    }
}

#[cfg(not(feature = "cuda"))]
#[test]
fn test_public_gpu_request_without_explicit_sidecar_falls_back_to_native_cpu() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--gpu-device-ids")
        .arg("0")
        .arg("--json")
        .arg("hello")
        .arg(dir.path())
        .env("TG_DISABLE_RG", "1")
        .env("PATH", "")
        .env("TG_SIDECAR_PYTHON", "definitely-missing-python")
        .output()
        .unwrap();

    let payload = assert_json_routing(&output, "NativeCpuBackend", "gpu-auto-fallback-cpu", false);
    assert_eq!(payload["total_matches"], 3);
    assert_eq!(payload["requested_gpu_device_ids"], serde_json::json!([0]));
    assert_eq!(payload["routing_gpu_device_ids"], serde_json::json!([]));
    assert_eq!(payload["gpu_evidence_status"], "unsupported");
    assert_eq!(payload["gpu_proof"], false);
    assert_eq!(payload["native_gpu_unavailable"], true);
    assert!(
        payload["not_gpu_proof_reason"]
            .as_str()
            .unwrap_or_default()
            .contains("not GPU acceleration proof"),
        "payload={payload}"
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(stderr.contains("native GPU unavailable"), "stderr={stderr}");
    assert!(
        stderr.contains("falling back to native CPU search"),
        "stderr={stderr}"
    );
    assert!(
        !stderr.contains("routing_backend=NativeGpuBackend"),
        "stderr={stderr}"
    );
}

#[cfg(not(feature = "cuda"))]
#[test]
fn test_public_gpu_ndjson_fallback_reports_no_routed_gpu_devices() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--gpu-device-ids")
        .arg("0")
        .arg("--ndjson")
        .arg("hello")
        .arg(dir.path())
        .env("TG_DISABLE_RG", "1")
        .env("PATH", "")
        .env("TG_SIDECAR_PYTHON", "definitely-missing-python")
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let stdout = String::from_utf8_lossy(&output.stdout);
    let mut rows = 0usize;
    for line in stdout.lines() {
        let payload: Value = serde_json::from_str(line).unwrap();
        assert_eq!(payload["routing_backend"], "NativeCpuBackend");
        assert_eq!(payload["routing_reason"], "gpu-auto-fallback-cpu");
        assert_eq!(payload["sidecar_used"], false);
        assert_eq!(payload["requested_gpu_device_ids"], serde_json::json!([0]));
        assert_eq!(payload["routing_gpu_device_ids"], serde_json::json!([]));
        assert_eq!(payload["gpu_evidence_status"], "unsupported");
        assert_eq!(payload["gpu_proof"], false);
        assert_eq!(payload["native_gpu_unavailable"], true);
        assert!(
            payload["not_gpu_proof_reason"]
                .as_str()
                .unwrap_or_default()
                .contains("not GPU acceleration proof"),
            "payload={payload}"
        );
        rows += 1;
    }
    assert_eq!(rows, 3);
}

#[test]
fn test_rust_control_plane_plain_explicit() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    // Should use the Rust control plane and dispatch to rg
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_plain_positional() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_positional_word_regexp_uses_word_boundaries() {
    let dir = tempdir().unwrap();
    let file = dir.path().join("words.txt");
    fs::write(&file, "word\nwordplay\nsword\nword\n").unwrap();

    let output = tg()
        .arg("--cpu")
        .arg("-w")
        .arg("word")
        .arg(&file)
        .env("TG_DISABLE_RG", "1")
        .env("PATH", "")
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        "word\nword\n"
    );
}

#[test]
fn test_native_cpu_fixed_multi_pattern_uses_single_pass_fast_path() {
    let dir = tempdir().unwrap();
    let file = dir.path().join("multi.txt");
    fs::write(
        &file,
        "alpha and beta\n\nbeta after blank\nalpha after beta\n",
    )
    .unwrap();

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--json")
        .arg("-e")
        .arg("alpha")
        .arg("-e")
        .arg("beta")
        .arg(&file)
        .env("TG_DISABLE_RG", "1")
        .env("PATH", "")
        .env(
            "TG_TEST_NATIVE_SEARCH_FORCE_ERROR",
            "sequential native search path used",
        )
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stdout={}\nstderr={}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    let payload: Value = serde_json::from_slice(&output.stdout).unwrap();
    let matches = payload["matches"].as_array().unwrap();
    let tuples = matches
        .iter()
        .map(|entry| {
            (
                entry["line"].as_u64().unwrap(),
                entry["text"].as_str().unwrap().to_string(),
                entry["pattern_id"].as_u64().unwrap(),
                entry["pattern_text"].as_str().unwrap().to_string(),
            )
        })
        .collect::<Vec<_>>();

    assert_eq!(
        tuples,
        vec![
            (1, "alpha and beta".to_string(), 0, "alpha".to_string()),
            (1, "alpha and beta".to_string(), 1, "beta".to_string()),
            (3, "beta after blank".to_string(), 1, "beta".to_string()),
            (4, "alpha after beta".to_string(), 0, "alpha".to_string()),
            (4, "alpha after beta".to_string(), 1, "beta".to_string()),
        ]
    );
}

#[test]
fn test_native_cpu_fixed_multi_pattern_plain_output_omits_line_numbers_by_default() {
    let dir = tempdir().unwrap();
    let file = dir.path().join("multi.txt");
    fs::write(
        &file,
        "alpha and beta\n\nbeta after blank\nalpha after beta\n",
    )
    .unwrap();

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("-e")
        .arg("alpha")
        .arg("-e")
        .arg("beta")
        .arg(&file)
        .env("TG_DISABLE_RG", "1")
        .env("PATH", "")
        .env(
            "TG_TEST_NATIVE_SEARCH_FORCE_ERROR",
            "sequential native search path used",
        )
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stdout={}\nstderr={}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        "alpha and beta\nbeta after blank\nalpha after beta\n"
    );
}

#[test]
fn test_native_cpu_fixed_multi_pattern_plain_output_honors_line_number_flag() {
    let dir = tempdir().unwrap();
    let file = dir.path().join("multi.txt");
    fs::write(
        &file,
        "alpha and beta\n\nbeta after blank\nalpha after beta\n",
    )
    .unwrap();

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--line-number")
        .arg("-e")
        .arg("alpha")
        .arg("-e")
        .arg("beta")
        .arg(&file)
        .env("TG_DISABLE_RG", "1")
        .env("PATH", "")
        .env(
            "TG_TEST_NATIVE_SEARCH_FORCE_ERROR",
            "sequential native search path used",
        )
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stdout={}\nstderr={}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        "1:alpha and beta\n3:beta after blank\n4:alpha after beta\n"
    );
}

#[test]
fn test_native_cpu_fixed_multi_pattern_count_counts_matching_lines_once() {
    let dir = tempdir().unwrap();
    let file = dir.path().join("multi.txt");
    fs::write(
        &file,
        "alpha and beta\n\nbeta after blank\nalpha after beta\n",
    )
    .unwrap();

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("--count")
        .arg("-e")
        .arg("alpha")
        .arg("-e")
        .arg("beta")
        .arg(&file)
        .env("TG_DISABLE_RG", "1")
        .env("PATH", "")
        .env(
            "TG_TEST_NATIVE_SEARCH_FORCE_ERROR",
            "sequential native search path used",
        )
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "stdout={}\nstderr={}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(
        normalize_newlines(&String::from_utf8_lossy(&output.stdout)),
        "3\n"
    );
}

#[test]
fn test_rust_control_plane_rejection() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    // -F should fall through to full stack.
    // Full stack with --verbose will show a reason.
    let output_f = tg()
        .arg("--verbose")
        .arg("-F")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    let stderr = String::from_utf8_lossy(&output_f.stderr);
    // If it fell through to Clap, it will process --verbose and print routing info.
    // The fast path would have silently dispatched without printing [routing]...
    assert!(stderr.contains("[routing]"));
    assert!(stderr.contains("routing_backend=RipgrepBackend"));

    // --help should fall through
    let output_help = tg().arg("--help").output().unwrap();
    assert!(String::from_utf8_lossy(&output_help.stdout).contains("Usage:"));

    // scan should fall through
    let output_scan = tg().arg("scan").arg("--help").output().unwrap();
    let stdout_scan = String::from_utf8_lossy(&output_scan.stdout);
    assert!(stdout_scan.to_lowercase().contains("usage:"));
    assert!(stdout_scan.contains("scan"));
}

#[test]
fn test_rust_control_plane_native_fallback() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("hello")
        .arg(dir.path())
        .env("TG_DISABLE_RG", "1")
        .env("PATH", "") // Ensure rg is not in path
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("hello world"));
    assert!(!stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_no_match_exit_code() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());

    let output = tg()
        .arg("non_existent_pattern")
        .arg(dir.path())
        .output()
        .unwrap();

    assert_eq!(output.status.code(), Some(1));
}

#[test]
fn test_rust_control_plane_combined_flags() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("-iv")
        .arg("non_existent")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_no_ignore() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--no-ignore")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_search_accepts_rg_sort_files_and_maxdepth_aliases() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--format")
        .arg("rg")
        .arg("--sort-files")
        .arg("--maxdepth")
        .arg("1")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_root_rg_style_forwarding_accepts_sort_files_and_maxdepth_aliases() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("--format")
        .arg("rg")
        .arg("--sort-files")
        .arg("--maxdepth")
        .arg("1")
        .arg("hello")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_case_insensitive_search_dispatches_to_ripgrep() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("-i")
        .arg("warning")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_max_count_search_dispatches_to_ripgrep() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("-m")
        .arg("5")
        .arg("ERROR")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_count_search_dispatches_to_ripgrep() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--count")
        .arg("ERROR")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_glob_search_dispatches_to_ripgrep() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--glob")
        .arg("*.txt")
        .arg("ERROR")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_many_fixed_patterns_dispatch_to_ripgrep_by_default() {
    let dir = tempdir().unwrap();
    write_text_corpus(dir.path());
    let rg_wrapper = write_rg_wrapper(dir.path());

    let output = tg()
        .arg("search")
        .arg("--fixed-strings")
        .arg("-e")
        .arg("ERROR")
        .arg("-e")
        .arg("WARN")
        .arg(dir.path())
        .env("TG_RG_PATH", &rg_wrapper)
        .output()
        .unwrap();

    assert!(output.status.success());
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains(RG_SENTINEL));
}

#[test]
fn test_rust_control_plane_version() {
    let expected = format!("tg {}", env!("CARGO_PKG_VERSION"));

    let output_v_long = tg().arg("--version").output().unwrap();
    assert!(String::from_utf8_lossy(&output_v_long.stdout).contains(&expected));

    let output_v_short = tg().arg("-V").output().unwrap();
    assert!(String::from_utf8_lossy(&output_v_short.stdout).contains(&expected));
}
