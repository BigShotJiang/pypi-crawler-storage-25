from __future__ import annotations

import json
import os
import queue
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, cast

from tensor_grep.cli.lsp_provider_setup import (
    canonical_language,
    managed_provider_env,
    resolved_provider_command,
)
from tensor_grep.cli.lsp_provider_setup import (
    managed_provider_root as _managed_provider_root,
)


class LSPTransportError(RuntimeError):
    pass


_DEFAULT_LSP_REQUEST_TIMEOUT_SECONDS = 3.0
_DEFAULT_LSP_INITIALIZE_TIMEOUT_SECONDS = 15.0
_DEFAULT_LSP_STOP_TIMEOUT_SECONDS = 1.0
_LSP_REQUEST_TIMEOUT_ENV_VAR = "TENSOR_GREP_LSP_REQUEST_TIMEOUT_SECONDS"
_LSP_INITIALIZE_TIMEOUT_ENV_VAR = "TENSOR_GREP_LSP_INITIALIZE_TIMEOUT_SECONDS"
_GENERATED_CACHE_EXCLUDES = [
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "__pycache__",
    "artifacts",
    "build",
    "coverage",
    "dist",
    "node_modules",
    "target",
    "venv",
]


def _configured_timeout_seconds(env_var: str, default: float) -> float:
    raw_value = os.environ.get(env_var)
    if raw_value is None:
        return default
    try:
        return max(float(raw_value), 0.0)
    except (TypeError, ValueError):
        return default


def _read_message(stream: Any) -> dict[str, Any] | None:
    headers: dict[str, str] = {}
    while True:
        line = stream.readline()
        if line == "":
            return None
        if line in ("\r\n", "\n"):
            break
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        headers[key.strip().lower()] = value.strip()
    content_length = int(headers.get("content-length", "0"))
    if content_length <= 0:
        return None
    body = stream.read(content_length)
    if not body:
        return None
    parsed = json.loads(body)
    if not isinstance(parsed, dict):
        return None
    return cast(dict[str, Any], parsed)


def _write_message(stream: Any, payload: dict[str, Any]) -> None:
    body = json.dumps(payload, separators=(",", ":"))
    encoded = body.encode("utf-8")
    stream.write(f"Content-Length: {len(encoded)}\r\n\r\n")
    stream.write(body)
    stream.flush()


def _provider_command(language: str) -> list[str]:
    normalized = canonical_language(language)
    command = resolved_provider_command(normalized, managed_root=_managed_provider_root())
    if command is not None:
        return command
    missing_binary_by_language = {
        "python": "pyright-langserver",
        "javascript": "typescript-language-server",
        "typescript": "typescript-language-server",
        "go": "gopls",
        "rust": "rust-analyzer",
        "java": "jdtls",
        "c": "clangd",
        "cpp": "clangd",
        "csharp": "csharp-ls",
        "php": "intelephense",
        "kotlin": "kotlin-lsp",
        "swift": "sourcekit-lsp",
        "lua": "lua-language-server",
    }
    if normalized in missing_binary_by_language:
        raise FileNotFoundError(f"{missing_binary_by_language[normalized]} binary not found")
    raise ValueError(f"Unsupported LSP language: {language}")


def _configuration_settings(language: str) -> dict[str, Any]:
    if canonical_language(language) != "python":
        return {"settings": {}}
    return {
        "settings": {
            "python": {
                "analysis": {
                    "diagnosticMode": "openFilesOnly",
                    "exclude": list(_GENERATED_CACHE_EXCLUDES),
                }
            }
        }
    }


def _health_probe_document(language: str, workspace_root: Path) -> dict[str, str]:
    normalized = canonical_language(language)
    probes = {
        "python": (
            "__tg_lsp_health_probe.py",
            "python",
            "def tg_lsp_health_probe():\n    return 1\n",
            "tg_lsp_health_probe",
        ),
        "javascript": (
            "__tg_lsp_health_probe.js",
            "javascript",
            "function tgLspHealthProbe() { return 1; }\n",
            "tgLspHealthProbe",
        ),
        "typescript": (
            "__tg_lsp_health_probe.ts",
            "typescript",
            "function tgLspHealthProbe(): number { return 1; }\n",
            "tgLspHealthProbe",
        ),
        "go": (
            "__tg_lsp_health_probe.go",
            "go",
            "package main\n\nfunc tgLspHealthProbe() int { return 1 }\n",
            "tgLspHealthProbe",
        ),
        "rust": (
            "__tg_lsp_health_probe.rs",
            "rust",
            "fn tg_lsp_health_probe() -> i32 { 1 }\n",
            "tg_lsp_health_probe",
        ),
        "java": (
            "__TgLspHealthProbe.java",
            "java",
            "class TgLspHealthProbe { int tgLspHealthProbe() { return 1; } }\n",
            "TgLspHealthProbe",
        ),
        "c": (
            "__tg_lsp_health_probe.c",
            "c",
            "int tg_lsp_health_probe(void) { return 1; }\n",
            "tg_lsp_health_probe",
        ),
        "cpp": (
            "__tg_lsp_health_probe.cpp",
            "cpp",
            "int tg_lsp_health_probe() { return 1; }\n",
            "tg_lsp_health_probe",
        ),
        "csharp": (
            "__TgLspHealthProbe.cs",
            "csharp",
            "class TgLspHealthProbe { int Probe() { return 1; } }\n",
            "TgLspHealthProbe",
        ),
        "php": (
            "__tg_lsp_health_probe.php",
            "php",
            "<?php function tg_lsp_health_probe() { return 1; }\n",
            "tg_lsp_health_probe",
        ),
        "kotlin": (
            "__TgLspHealthProbe.kt",
            "kotlin",
            "fun tgLspHealthProbe(): Int = 1\n",
            "tgLspHealthProbe",
        ),
        "swift": (
            "__TgLspHealthProbe.swift",
            "swift",
            "func tgLspHealthProbe() -> Int { return 1 }\n",
            "tgLspHealthProbe",
        ),
        "lua": (
            "__tg_lsp_health_probe.lua",
            "lua",
            "function tg_lsp_health_probe()\n  return 1\nend\n",
            "tg_lsp_health_probe",
        ),
    }
    filename, language_id, text, symbol = probes.get(
        normalized,
        (
            "__tg_lsp_health_probe.txt",
            normalized,
            "tg_lsp_health_probe\n",
            "tg_lsp_health_probe",
        ),
    )
    return {
        "uri": (workspace_root.resolve() / filename).as_uri(),
        "language_id": language_id,
        "text": text,
        "symbol": symbol,
    }


def _document_symbol_names(result: object) -> list[str]:
    names: list[str] = []
    if not isinstance(result, list):
        return names
    for item in result:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        if isinstance(name, str):
            names.append(name)
        names.extend(_document_symbol_names(item.get("children")))
    return names


def _document_symbol_result_contains(result: object, expected_symbol: str) -> bool:
    return expected_symbol in _document_symbol_names(result)


def _lookup_configuration_section(settings: dict[str, Any], section: object) -> Any:
    if not isinstance(section, str) or not section:
        return settings
    current: Any = settings
    for part in section.split("."):
        if not isinstance(current, dict) or part not in current:
            return None
        current = current[part]
    return current


class ExternalLSPClient:
    def __init__(
        self,
        *,
        language: str,
        workspace_root: Path,
        request_timeout_seconds: float | None = None,
        initialize_timeout_seconds: float | None = None,
        retry_cooldown_seconds: float = 30.0,
    ) -> None:
        self.language = language
        self.workspace_root = workspace_root.resolve()
        self.command = _provider_command(language)
        self.process: subprocess.Popen[str] | None = None
        self._request_id = 0
        self._lock = threading.Lock()
        self._opened_documents: set[str] = set()
        self._message_queue: queue.Queue[dict[str, Any] | None] = queue.Queue()
        self._reader_thread: threading.Thread | None = None
        self.request_timeout_seconds = (
            _configured_timeout_seconds(
                _LSP_REQUEST_TIMEOUT_ENV_VAR, _DEFAULT_LSP_REQUEST_TIMEOUT_SECONDS
            )
            if request_timeout_seconds is None
            else max(float(request_timeout_seconds), 0.0)
        )
        self.initialize_timeout_seconds = (
            _configured_timeout_seconds(
                _LSP_INITIALIZE_TIMEOUT_ENV_VAR, _DEFAULT_LSP_INITIALIZE_TIMEOUT_SECONDS
            )
            if initialize_timeout_seconds is None
            else max(float(initialize_timeout_seconds), 0.0)
        )
        self.retry_cooldown_seconds = retry_cooldown_seconds
        self.capabilities: dict[str, Any] = {}
        self.last_error: str | None = None
        self.disabled_until_monotonic = 0.0
        self.initialized = False
        self.lsp_provider_response = False

    def start(self) -> None:
        if self.process is not None and self.process.poll() is None:
            return
        if self.disabled_until_monotonic > time.monotonic():
            raise LSPTransportError(self.last_error or "LSP provider temporarily unavailable")
        if self.process is not None:
            self.stop()
        self.process = subprocess.Popen(
            self.command,
            cwd=str(self.workspace_root),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=managed_provider_env(self.command, managed_root=_managed_provider_root()),
        )
        self._message_queue = queue.Queue()
        self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True)
        self._reader_thread.start()
        try:
            result = self.request(
                "initialize",
                {
                    "processId": None,
                    "rootUri": self.workspace_root.as_uri(),
                    "capabilities": {
                        "workspace": {
                            "configuration": True,
                            "workspaceFolders": True,
                        }
                    },
                    "initializationOptions": _configuration_settings(self.language).get(
                        "settings", {}
                    ),
                    "workspaceFolders": [
                        {
                            "uri": self.workspace_root.as_uri(),
                            "name": self.workspace_root.name,
                        }
                    ],
                },
            )
        except LSPTransportError as exc:
            self.last_error = str(exc)
            self.disabled_until_monotonic = time.monotonic() + self.retry_cooldown_seconds
            self.stop()
            raise
        if isinstance(result, dict):
            self.capabilities = dict(result.get("capabilities", {}))
        self.notify("initialized", {})
        self.initialized = True
        try:
            self.notify("workspace/didChangeConfiguration", _configuration_settings(self.language))
        except Exception:
            pass

    def stop(self) -> None:
        process = self.process
        if process is None:
            return
        reader_thread = self._reader_thread
        stop_timeout_seconds = min(
            max(float(self.request_timeout_seconds), 0.0),
            _DEFAULT_LSP_STOP_TIMEOUT_SECONDS,
        )
        self._request_shutdown_for_stop()
        with self._lock:
            try:
                self._write_notification("exit", None)
            except Exception:
                pass
            try:
                if process.stdin is not None:
                    process.stdin.close()
            except Exception:
                pass
            try:
                process.terminate()
            except Exception:
                pass
        try:
            process.wait(timeout=stop_timeout_seconds)
        except subprocess.TimeoutExpired:
            try:
                process.kill()
            except Exception:
                pass
            try:
                process.wait(timeout=stop_timeout_seconds)
            except Exception:
                pass
        finally:
            for stream in (process.stdout, process.stderr):
                try:
                    if stream is not None:
                        stream.close()
                except Exception:
                    pass
        if reader_thread is not None and reader_thread.is_alive():
            reader_thread.join(timeout=stop_timeout_seconds)
        with self._lock:
            if self.process is process:
                self.process = None
            self._opened_documents.clear()
            self.capabilities = {}
            self.initialized = False
            self.lsp_provider_response = False
            if self._reader_thread is reader_thread:
                self._reader_thread = None
            self._message_queue = queue.Queue()

    def _request_shutdown_for_stop(self) -> None:
        process = self.process
        if process is None or process.stdin is None:
            return
        try:
            with self._lock:
                self._request_id += 1
                request_id = self._request_id
                self._write_request(request_id, "shutdown", None)
        except Exception:
            return

        timeout_seconds = min(
            max(float(self.request_timeout_seconds), 0.0),
            _DEFAULT_LSP_STOP_TIMEOUT_SECONDS,
        )
        deadline = time.monotonic() + timeout_seconds
        while True:
            remaining = max(0.0, deadline - time.monotonic())
            try:
                message = self._message_queue.get(timeout=remaining)
            except queue.Empty:
                return
            if message is None:
                return
            if "id" not in message:
                if remaining <= 0:
                    return
                continue
            try:
                message_id = int(message["id"])
            except (TypeError, ValueError):
                continue
            if message_id == request_id:
                return
            if remaining <= 0:
                return

    def request(self, method: str, params: dict[str, Any]) -> Any:
        self.start()
        if self.process is None or self.process.stdin is None or self.process.stdout is None:
            raise LSPTransportError("LSP process is not available")
        timeout_seconds = (
            self.initialize_timeout_seconds
            if method == "initialize"
            else self.request_timeout_seconds
        )
        with self._lock:
            self._request_id += 1
            request_id = self._request_id
            self._write_request(request_id, method, params)
        deadline = time.monotonic() + timeout_seconds
        while True:
            remaining = max(0.0, deadline - time.monotonic())
            try:
                message = self._message_queue.get(timeout=remaining)
            except queue.Empty as exc:
                self.last_error = f"timeout waiting for LSP response: {method}"
                raise LSPTransportError(self.last_error) from exc
            if message is None:
                self.last_error = f"LSP process closed during request: {method}"
                raise LSPTransportError(f"LSP process closed during request: {method}")
            if "id" not in message:
                continue
            if int(message["id"]) != request_id:
                continue
            if "error" in message:
                self.last_error = str(message["error"])
                raise LSPTransportError(self.last_error)
            self.last_error = None
            return message.get("result")

    def notify(self, method: str, params: dict[str, Any]) -> None:
        self.start()
        if self.process is None or self.process.stdin is None:
            raise LSPTransportError("LSP process is not available")
        with self._lock:
            self._write_notification(method, params)

    def ensure_document(self, *, uri: str, text: str, language_id: str) -> None:
        if uri in self._opened_documents:
            return
        self.notify(
            "textDocument/didOpen",
            {
                "textDocument": {
                    "uri": uri,
                    "languageId": language_id,
                    "version": 1,
                    "text": text,
                }
            },
        )
        self._opened_documents.add(uri)

    def did_change(self, *, uri: str, text: str, version: int = 1) -> None:
        if uri not in self._opened_documents:
            return
        self.notify(
            "textDocument/didChange",
            {
                "textDocument": {"uri": uri, "version": version},
                "contentChanges": [{"text": text}],
            },
        )

    def did_save(self, *, uri: str) -> None:
        if uri not in self._opened_documents:
            return
        self.notify("textDocument/didSave", {"textDocument": {"uri": uri}})

    def status(self) -> dict[str, Any]:
        return {
            "language": self.language,
            "workspace_root": str(self.workspace_root),
            "command": list(self.command),
            "command_source": _command_source(self.command),
            "managed_provider_root": str(_managed_provider_root()),
            "running": self.process is not None and self.process.poll() is None,
            "initialized": self.initialized,
            "capabilities": dict(self.capabilities),
            "lsp_provider_response": self.lsp_provider_response,
            "last_error": self.last_error,
            "opened_documents": len(self._opened_documents),
            "request_timeout_seconds": self.request_timeout_seconds,
            "initialize_timeout_seconds": self.initialize_timeout_seconds,
            "cooldown_remaining_s": max(0.0, self.disabled_until_monotonic - time.monotonic()),
        }

    def _write_request(self, request_id: int, method: str, params: dict[str, Any] | None) -> None:
        if self.process is None or self.process.stdin is None:
            raise LSPTransportError("LSP process is not available")
        payload: dict[str, Any] = {"jsonrpc": "2.0", "id": request_id, "method": method}
        if params is not None:
            payload["params"] = params
        _write_message(self.process.stdin, payload)

    def _write_notification(self, method: str, params: dict[str, Any] | None) -> None:
        if self.process is None or self.process.stdin is None:
            raise LSPTransportError("LSP process is not available")
        payload: dict[str, Any] = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            payload["params"] = params
        _write_message(
            self.process.stdin,
            payload,
        )

    def _write_response(self, request_id: object, result: Any) -> None:
        if self.process is None or self.process.stdin is None:
            raise LSPTransportError("LSP process is not available")
        payload = {"jsonrpc": "2.0", "id": request_id, "result": result}
        _write_message(self.process.stdin, payload)

    def _write_error_response(self, request_id: object, *, code: int, message: str) -> None:
        if self.process is None or self.process.stdin is None:
            raise LSPTransportError("LSP process is not available")
        payload = {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": code, "message": message},
        }
        _write_message(self.process.stdin, payload)

    def _configuration_response(self, params: object) -> list[Any]:
        settings = _configuration_settings(self.language).get("settings", {})
        if not isinstance(params, dict):
            return [settings]
        items = params.get("items")
        if not isinstance(items, list):
            return [settings]
        return [
            _lookup_configuration_section(
                settings,
                item.get("section") if isinstance(item, dict) else None,
            )
            for item in items
        ]

    def _handle_server_request(self, message: dict[str, Any]) -> bool:
        if "id" not in message or "method" not in message:
            return False
        method = str(message.get("method"))
        request_id = message.get("id")
        try:
            if method == "workspace/configuration":
                result = self._configuration_response(message.get("params"))
            elif method == "workspace/workspaceFolders":
                result = [{"uri": self.workspace_root.as_uri(), "name": self.workspace_root.name}]
            elif method in {
                "client/registerCapability",
                "client/unregisterCapability",
                "window/workDoneProgress/create",
            }:
                result = None
            else:
                with self._lock:
                    self._write_error_response(
                        request_id,
                        code=-32601,
                        message=f"Unsupported LSP server request: {method}",
                    )
                return True
            with self._lock:
                self._write_response(request_id, result)
            return True
        except Exception as exc:
            try:
                with self._lock:
                    self._write_error_response(request_id, code=-32603, message=str(exc))
            except Exception:
                pass
            return True

    def _reader_loop(self) -> None:
        process = self.process
        if process is None or process.stdout is None:
            self._message_queue.put(None)
            return
        try:
            while True:
                message = _read_message(process.stdout)
                if message is None:
                    self._message_queue.put(None)
                    return
                if self._handle_server_request(message):
                    continue
                self._message_queue.put(message)
        except Exception as exc:
            self.last_error = str(exc)
            self._message_queue.put(None)


class ExternalLSPProviderManager:
    def __init__(self) -> None:
        self._clients: dict[tuple[str, str], ExternalLSPClient] = {}

    def get_client(self, *, language: str, workspace_root: Path) -> ExternalLSPClient:
        key = (language.lower(), str(workspace_root.resolve()))
        current = self._clients.get(key)
        if current is None:
            current = ExternalLSPClient(language=language, workspace_root=workspace_root)
            self._clients[key] = current
        return current

    def provider_status(
        self,
        *,
        language: str,
        workspace_root: Path,
        verify_health: bool = False,
        probe_timeout_seconds: float | None = None,
    ) -> dict[str, Any]:
        key = (language.lower(), str(workspace_root.resolve()))
        current = self._clients.get(key)
        if current is not None:
            if verify_health:
                return self._verified_provider_status(
                    client=current,
                    language=language,
                    workspace_root=workspace_root,
                    probe_timeout_seconds=probe_timeout_seconds,
                )
            status = current.status()
            status["available"] = True
            status["health_status"] = _provider_health_status(status)
            status["health_check"] = "cached-client"
            return _attach_lsp_proof_fields(status)
        try:
            command = _provider_command(language)
        except (FileNotFoundError, ValueError) as exc:
            return _attach_lsp_proof_fields({
                "language": language.lower(),
                "workspace_root": str(workspace_root.resolve()),
                "available": False,
                "health_status": "missing",
                "health_check": "not_run",
                "running": False,
                "command": [],
                "command_source": "missing",
                "managed_provider_root": str(_managed_provider_root()),
                "initialized": False,
                "capabilities": {},
                "last_error": str(exc),
                "opened_documents": 0,
                "request_timeout_seconds": _configured_timeout_seconds(
                    _LSP_REQUEST_TIMEOUT_ENV_VAR,
                    _DEFAULT_LSP_REQUEST_TIMEOUT_SECONDS,
                ),
                "initialize_timeout_seconds": _configured_timeout_seconds(
                    _LSP_INITIALIZE_TIMEOUT_ENV_VAR,
                    _DEFAULT_LSP_INITIALIZE_TIMEOUT_SECONDS,
                ),
                "cooldown_remaining_s": 0.0,
            })
        request_timeout_seconds = _configured_timeout_seconds(
            _LSP_REQUEST_TIMEOUT_ENV_VAR,
            _DEFAULT_LSP_REQUEST_TIMEOUT_SECONDS,
        )
        initialize_timeout_seconds = _configured_timeout_seconds(
            _LSP_INITIALIZE_TIMEOUT_ENV_VAR,
            _DEFAULT_LSP_INITIALIZE_TIMEOUT_SECONDS,
        )
        if verify_health:
            timeout = (
                max(float(probe_timeout_seconds), 0.0)
                if probe_timeout_seconds is not None
                else min(request_timeout_seconds, initialize_timeout_seconds)
            )
            client = ExternalLSPClient(
                language=language,
                workspace_root=workspace_root,
                request_timeout_seconds=timeout,
                initialize_timeout_seconds=timeout,
            )
            return self._verified_provider_status(
                client=client,
                language=language,
                workspace_root=workspace_root,
                probe_timeout_seconds=timeout,
                stop_after_probe=True,
            )
        return _attach_lsp_proof_fields({
            "language": language.lower(),
            "workspace_root": str(workspace_root.resolve()),
            "available": True,
            "health_status": "available_unverified",
            "health_check": "not_run",
            "running": False,
            "command": command,
            "command_source": _command_source(command),
            "managed_provider_root": str(_managed_provider_root()),
            "initialized": False,
            "capabilities": {},
            "last_error": None,
            "opened_documents": 0,
            "request_timeout_seconds": request_timeout_seconds,
            "initialize_timeout_seconds": initialize_timeout_seconds,
            "cooldown_remaining_s": 0.0,
        })

    def _verified_provider_status(
        self,
        *,
        client: ExternalLSPClient,
        language: str,
        workspace_root: Path,
        probe_timeout_seconds: float | None,
        stop_after_probe: bool = False,
    ) -> dict[str, Any]:
        timeout = (
            max(float(probe_timeout_seconds), 0.0)
            if probe_timeout_seconds is not None
            else min(client.request_timeout_seconds, client.initialize_timeout_seconds)
        )
        probe = _health_probe_document(language, workspace_root)
        phase = "initialize"
        original_request_timeout = client.request_timeout_seconds
        original_initialize_timeout = client.initialize_timeout_seconds
        probe_succeeded = False
        probe_error: Exception | None = None
        client.request_timeout_seconds = timeout
        client.initialize_timeout_seconds = timeout
        try:
            client.start()
            phase = "did_open"
            client.ensure_document(
                uri=probe["uri"],
                text=probe["text"],
                language_id=probe["language_id"],
            )
            phase = "document_symbol"
            result = client.request(
                "textDocument/documentSymbol",
                {"textDocument": {"uri": probe["uri"]}},
            )
            if not _document_symbol_result_contains(result, probe["symbol"]):
                raise LSPTransportError("semantic documentSymbol probe returned no matching symbol")
            probe_succeeded = True
            client.lsp_provider_response = True
        except (FileNotFoundError, LSPTransportError, OSError, ValueError) as exc:
            probe_error = exc
            client.lsp_provider_response = False
        finally:
            client.request_timeout_seconds = original_request_timeout
            client.initialize_timeout_seconds = original_initialize_timeout
        status = client.status()
        status["available"] = True
        status["health_check"] = "semantic-document-symbol"
        status["health_phase"] = phase
        status["probe_timeout_seconds"] = timeout
        status["probe_document_uri"] = probe["uri"]
        status["probe_symbol"] = probe["symbol"]
        if probe_succeeded:
            status["health_status"] = "ready"
        else:
            status["health_status"] = "unhealthy"
            status["lsp_provider_response"] = False
            if probe_error is not None:
                status["last_error"] = status.get("last_error") or str(probe_error)
        try:
            return _attach_lsp_proof_fields(status)
        finally:
            if stop_after_probe:
                client.stop()

    def stop_all(self) -> None:
        clients = list(self._clients.values())
        self._clients.clear()
        for client in clients:
            client.stop()

    def close_all(self) -> None:
        for current in self._clients.values():
            current.stop()
        self._clients.clear()


def _command_source(command: list[str]) -> str:
    if not command:
        return "missing"
    try:
        command_path = Path(command[0]).resolve()
        command_path.relative_to(_managed_provider_root())
    except ValueError:
        return "path"
    except OSError:
        return "path"
    return "managed"


def _provider_health_status(status: dict[str, Any]) -> str:
    if not status.get("available"):
        return "missing"
    if status.get("last_error"):
        return "unhealthy"
    if status.get("running") and (status.get("initialized") or status.get("capabilities")):
        return "ready"
    if status.get("running"):
        return "running_unverified"
    return "available_unverified"


def _attach_lsp_proof_fields(status: dict[str, Any]) -> dict[str, Any]:
    health_status = str(status.get("health_status", _provider_health_status(status)))
    health_check = str(status.get("health_check", "not_run"))
    status.setdefault("lsp_provider_response", False)
    lsp_proof = (
        bool(status.get("available"))
        and health_status == "ready"
        and status.get("lsp_provider_response") is True
    )
    status["health_status"] = health_status
    status["health_check"] = health_check
    status["lsp_proof"] = lsp_proof
    if lsp_proof:
        status.pop("not_lsp_proof_reason", None)
        return status
    if not status.get("available"):
        reason = "Provider binary is unavailable."
    elif health_status == "available_unverified" and health_check == "not_run":
        reason = "Provider binary is available but health was not verified."
    elif health_status == "unhealthy":
        reason = "Provider semantic health probe failed or timed out."
    elif health_status == "ready" and status.get("lsp_provider_response") is not True:
        reason = "Provider initialized, but semantic health has not been verified in this session."
    else:
        reason = "Provider has not completed a successful initialization probe."
    status["not_lsp_proof_reason"] = reason
    return status
