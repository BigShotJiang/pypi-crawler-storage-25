"""Annotator based on Presidio pattern recognizer"""

__version__ = "1.8.37"
