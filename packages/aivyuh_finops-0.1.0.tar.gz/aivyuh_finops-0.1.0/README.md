# aivyuh-finops

Transparent cost telemetry for Anthropic and OpenAI Python clients. Part of the [V7 AI FinOps](https://finops-api.aivyuh.com) platform.

Wrap your existing AI SDK client in one line — `aivyuh-finops` captures model, tokens, cost, and latency metadata and sends it to the V7 backend. **It never reads or stores prompt or response content.**

## Install

```bash
pip install aivyuh-finops
```

With provider extras:

```bash
pip install aivyuh-finops[anthropic]   # includes anthropic SDK
pip install aivyuh-finops[openai]      # includes openai SDK
pip install aivyuh-finops[all]         # both
```

## Quickstart

### Anthropic

```python
from anthropic import Anthropic
from aivyuh_finops import wrap_anthropic

client = wrap_anthropic(Anthropic(), {
    "telemetry_endpoint": "https://finops-api.aivyuh.com/telemetry",
    "customer_id": "cust-123",
    "project": "my-app",
    "tags": {"feature": "chat", "team": "product"},
})

# Use the client exactly as before — all types are preserved
message = client.messages.create(
    model="claude-sonnet-4-6-20260320",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello, Claude!"}],
)
```

### OpenAI

```python
from openai import OpenAI
from aivyuh_finops import wrap_openai

client = wrap_openai(OpenAI(), {
    "telemetry_endpoint": "https://finops-api.aivyuh.com/telemetry",
    "customer_id": "cust-123",
    "project": "my-app",
    "tags": {"feature": "search", "team": "platform"},
})

# Use the client exactly as before
completion = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello, GPT!"}],
)
```

## Configuration

| Option | Type | Required | Description |
|--------|------|----------|-------------|
| `telemetry_endpoint` | `str` | Yes | V7 telemetry ingest URL (`https://finops-api.aivyuh.com/telemetry`) |
| `customer_id` | `str` | Yes | Your customer ID for cost attribution |
| `project` | `str` | No | Project name for grouping costs |
| `tags` | `dict[str, str]` | No | Custom key-value tags attached to every request |
| `disable_telemetry` | `bool` | No | Set `True` to disable (useful in tests) |

## Production API Endpoint

```
https://finops-api.aivyuh.com/telemetry
```

POST telemetry payloads are accepted with a `202 Accepted` response. The endpoint is fire-and-forget — if unreachable, your application is unaffected.

## How It Works

1. `wrap_anthropic()` / `wrap_openai()` monkey-patches `messages.create()` or `chat.completions.create()`.
2. After each successful call, it extracts usage metadata (model, tokens, latency) and estimates cost.
3. A background thread sends the telemetry payload via HTTP POST — errors are silently swallowed.
4. Your original response is returned untouched. Zero external dependencies (uses `urllib` + `threading`).

## Requirements

- Python >= 3.10
- `anthropic` >= 0.40.0 and/or `openai` >= 1.50.0 (optional peer dependencies)

## License

MIT
