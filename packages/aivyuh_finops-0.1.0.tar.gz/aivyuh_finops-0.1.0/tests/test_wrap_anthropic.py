"""Tests for wrap_anthropic — mirrors the TypeScript test suite."""

from __future__ import annotations

import json
import threading
from dataclasses import dataclass
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from aivyuh_finops import wrap_anthropic
from aivyuh_finops.types import WrapOptions


# ---------------------------------------------------------------------------
# Fake Anthropic types for testing (no real SDK dependency needed)
# ---------------------------------------------------------------------------
@dataclass
class FakeUsage:
    input_tokens: int
    output_tokens: int
    cache_read_input_tokens: int = 0


@dataclass
class FakeMessage:
    id: str
    model: str
    usage: FakeUsage
    content: list[dict[str, str]]


class FakeMessages:
    def __init__(self) -> None:
        self.create = MagicMock()


class FakeAnthropic:
    def __init__(self) -> None:
        self.messages = FakeMessages()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------
class TestWrapAnthropic:
    def setup_method(self) -> None:
        self.telemetry_calls: list[dict[str, Any]] = []
        self.client = FakeAnthropic()
        self.options: WrapOptions = {
            "telemetry_endpoint": "https://api.example.com/telemetry",
            "customer_id": "cust-test",
            "project": "test-app",
            "tags": {"team": "product"},
        }

    def _capture_telemetry(self, endpoint: str, payload: dict) -> None:
        """Mock send_telemetry to capture calls synchronously."""
        self.telemetry_calls.append(payload)

    def test_proxy_messages_create_and_capture_telemetry(self) -> None:
        mock_response = FakeMessage(
            id="msg_test",
            model="claude-sonnet-4-6-20260320",
            usage=FakeUsage(input_tokens=1000, output_tokens=500),
            content=[{"type": "text", "text": "Hello!"}],
        )
        self.client.messages.create.return_value = mock_response

        with patch("aivyuh_finops.wrap_anthropic.send_telemetry", side_effect=self._capture_telemetry):
            wrapped = wrap_anthropic(self.client, self.options)
            result = wrapped.messages.create(
                model="claude-sonnet-4-6-20260320",
                max_tokens=1024,
                messages=[{"role": "user", "content": "Hi"}],
            )

        # Original response returned unchanged
        assert result.id == "msg_test"
        assert result.content[0] == {"type": "text", "text": "Hello!"}

        # Telemetry was sent
        assert len(self.telemetry_calls) == 1
        t = self.telemetry_calls[0]
        assert t["customer_id"] == "cust-test"
        assert t["provider"] == "anthropic"
        assert t["model"] == "claude-sonnet-4-6-20260320"
        assert t["tokens_input"] == 1000
        assert t["tokens_output"] == 500
        assert t["cost_usd"] > 0
        assert t["latency_ms"] >= 0
        assert t["tags"]["project"] == "test-app"
        assert t["tags"]["team"] == "product"

    def test_no_throw_if_telemetry_fails(self) -> None:
        mock_response = FakeMessage(
            id="msg_test2",
            model="claude-sonnet-4-6-20260320",
            usage=FakeUsage(input_tokens=100, output_tokens=50),
            content=[{"type": "text", "text": "OK"}],
        )
        self.client.messages.create.return_value = mock_response

        def failing_telemetry(endpoint: str, payload: dict) -> None:
            raise ConnectionError("network down")

        with patch("aivyuh_finops.wrap_anthropic.send_telemetry", side_effect=failing_telemetry):
            wrapped = wrap_anthropic(self.client, self.options)
            # Should not throw — telemetry failure is silently swallowed
            result = wrapped.messages.create(
                model="claude-sonnet-4-6-20260320",
                max_tokens=256,
                messages=[{"role": "user", "content": "test"}],
            )

        assert result.id == "msg_test2"

    def test_no_telemetry_when_disabled(self) -> None:
        mock_response = FakeMessage(
            id="msg_test3",
            model="claude-sonnet-4-6-20260320",
            usage=FakeUsage(input_tokens=100, output_tokens=50),
            content=[{"type": "text", "text": "silent"}],
        )
        self.client.messages.create.return_value = mock_response

        silent_options: WrapOptions = {
            "telemetry_endpoint": "https://api.example.com/telemetry",
            "customer_id": "cust-silent",
            "disable_telemetry": True,
        }

        with patch("aivyuh_finops.wrap_anthropic.send_telemetry", side_effect=self._capture_telemetry):
            wrapped = wrap_anthropic(self.client, silent_options)
            wrapped.messages.create(
                model="claude-sonnet-4-6-20260320",
                max_tokens=256,
                messages=[{"role": "user", "content": "test"}],
            )

        assert len(self.telemetry_calls) == 0

    def test_cache_hit_detection(self) -> None:
        mock_response = FakeMessage(
            id="msg_cached",
            model="claude-sonnet-4-6-20260320",
            usage=FakeUsage(input_tokens=500, output_tokens=200, cache_read_input_tokens=400),
            content=[{"type": "text", "text": "cached"}],
        )
        self.client.messages.create.return_value = mock_response

        with patch("aivyuh_finops.wrap_anthropic.send_telemetry", side_effect=self._capture_telemetry):
            wrapped = wrap_anthropic(self.client, self.options)
            wrapped.messages.create(
                model="claude-sonnet-4-6-20260320",
                max_tokens=256,
                messages=[{"role": "user", "content": "test"}],
            )

        assert self.telemetry_calls[0]["cache_hit"] is True

    def test_cost_calculation(self) -> None:
        # claude-sonnet-4-6: $3/1M input, $15/1M output
        mock_response = FakeMessage(
            id="msg_cost",
            model="claude-sonnet-4-6-20260320",
            usage=FakeUsage(input_tokens=1_000_000, output_tokens=1_000_000),
            content=[{"type": "text", "text": "cost test"}],
        )
        self.client.messages.create.return_value = mock_response

        with patch("aivyuh_finops.wrap_anthropic.send_telemetry", side_effect=self._capture_telemetry):
            wrapped = wrap_anthropic(self.client, self.options)
            wrapped.messages.create(
                model="claude-sonnet-4-6-20260320",
                max_tokens=4096,
                messages=[{"role": "user", "content": "test"}],
            )

        # 1M input * $3/1M + 1M output * $15/1M = $18.00
        assert self.telemetry_calls[0]["cost_usd"] == 18.0
