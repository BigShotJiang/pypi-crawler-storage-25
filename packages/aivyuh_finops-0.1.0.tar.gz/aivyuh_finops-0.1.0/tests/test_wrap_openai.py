"""Tests for wrap_openai."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from aivyuh_finops import wrap_openai
from aivyuh_finops.types import WrapOptions


# ---------------------------------------------------------------------------
# Fake OpenAI types for testing
# ---------------------------------------------------------------------------
@dataclass
class FakeCompletionUsage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int = 0


@dataclass
class FakeChatCompletion:
    id: str
    model: str
    usage: FakeCompletionUsage | None
    choices: list[dict[str, Any]]


class FakeCompletions:
    def __init__(self) -> None:
        self.create = MagicMock()


class FakeChat:
    def __init__(self) -> None:
        self.completions = FakeCompletions()


class FakeOpenAI:
    def __init__(self) -> None:
        self.chat = FakeChat()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------
class TestWrapOpenAI:
    def setup_method(self) -> None:
        self.telemetry_calls: list[dict[str, Any]] = []
        self.client = FakeOpenAI()
        self.options: WrapOptions = {
            "telemetry_endpoint": "https://api.example.com/telemetry",
            "customer_id": "cust-test",
            "project": "test-app",
        }

    def _capture_telemetry(self, endpoint: str, payload: dict) -> None:
        self.telemetry_calls.append(payload)

    def test_proxy_completions_create_and_capture_telemetry(self) -> None:
        mock_response = FakeChatCompletion(
            id="chatcmpl-test",
            model="gpt-4o",
            usage=FakeCompletionUsage(prompt_tokens=800, completion_tokens=400),
            choices=[{"message": {"role": "assistant", "content": "Hello!"}}],
        )
        self.client.chat.completions.create.return_value = mock_response

        with patch("aivyuh_finops.wrap_openai.send_telemetry", side_effect=self._capture_telemetry):
            wrapped = wrap_openai(self.client, self.options)
            result = wrapped.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": "Hi"}],
            )

        assert result.id == "chatcmpl-test"

        assert len(self.telemetry_calls) == 1
        t = self.telemetry_calls[0]
        assert t["customer_id"] == "cust-test"
        assert t["provider"] == "openai"
        assert t["model"] == "gpt-4o"
        assert t["tokens_input"] == 800
        assert t["tokens_output"] == 400
        assert t["cost_usd"] > 0
        assert t["tags"]["project"] == "test-app"

    def test_no_telemetry_when_disabled(self) -> None:
        mock_response = FakeChatCompletion(
            id="chatcmpl-test2",
            model="gpt-4o",
            usage=FakeCompletionUsage(prompt_tokens=100, completion_tokens=50),
            choices=[],
        )
        self.client.chat.completions.create.return_value = mock_response

        silent_options: WrapOptions = {
            "telemetry_endpoint": "https://api.example.com/telemetry",
            "customer_id": "cust-silent",
            "disable_telemetry": True,
        }

        with patch("aivyuh_finops.wrap_openai.send_telemetry", side_effect=self._capture_telemetry):
            wrapped = wrap_openai(self.client, silent_options)
            wrapped.chat.completions.create(model="gpt-4o", messages=[])

        assert len(self.telemetry_calls) == 0

    def test_cost_calculation_gpt4o(self) -> None:
        # gpt-4o: $2.5/1M input, $10/1M output
        mock_response = FakeChatCompletion(
            id="chatcmpl-cost",
            model="gpt-4o",
            usage=FakeCompletionUsage(prompt_tokens=1_000_000, completion_tokens=1_000_000),
            choices=[],
        )
        self.client.chat.completions.create.return_value = mock_response

        with patch("aivyuh_finops.wrap_openai.send_telemetry", side_effect=self._capture_telemetry):
            wrapped = wrap_openai(self.client, self.options)
            wrapped.chat.completions.create(model="gpt-4o", messages=[])

        # 1M * $2.5 + 1M * $10 = $12.50
        assert self.telemetry_calls[0]["cost_usd"] == 12.5

    def test_no_usage_skips_telemetry(self) -> None:
        """Streaming responses may not have usage — telemetry should be skipped."""
        mock_response = FakeChatCompletion(
            id="chatcmpl-stream",
            model="gpt-4o",
            usage=None,
            choices=[],
        )
        self.client.chat.completions.create.return_value = mock_response

        with patch("aivyuh_finops.wrap_openai.send_telemetry", side_effect=self._capture_telemetry):
            wrapped = wrap_openai(self.client, self.options)
            wrapped.chat.completions.create(model="gpt-4o", messages=[])

        assert len(self.telemetry_calls) == 0
