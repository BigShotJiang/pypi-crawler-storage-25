"""Tests for the fire-and-forget telemetry sender."""

from __future__ import annotations

import threading
from unittest.mock import MagicMock, patch

from aivyuh_finops.telemetry import send_telemetry
from aivyuh_finops.types import TelemetryPayload


class TestSendTelemetry:
    def test_sends_json_post(self) -> None:
        payload: TelemetryPayload = {
            "customer_id": "cust-1",
            "provider": "anthropic",
            "model": "claude-sonnet-4-6-20260320",
            "tokens_input": 100,
            "tokens_output": 50,
            "cost_usd": 0.001,
            "latency_ms": 200,
            "timestamp": "2026-03-31T10:00:00Z",
            "cache_hit": False,
            "streaming": False,
            "tags": {},
        }

        with patch("aivyuh_finops.telemetry.urlopen") as mock_urlopen:
            mock_urlopen.return_value = MagicMock()
            send_telemetry("https://example.com/telemetry", payload)

            # Wait for background thread
            for t in threading.enumerate():
                if t.daemon and t.is_alive():
                    t.join(timeout=2)

            mock_urlopen.assert_called_once()
            req = mock_urlopen.call_args[0][0]
            assert req.full_url == "https://example.com/telemetry"
            assert req.get_header("Content-type") == "application/json"

    def test_swallows_errors_silently(self) -> None:
        """Telemetry must never impact the caller."""
        with patch("aivyuh_finops.telemetry.urlopen", side_effect=ConnectionError("down")):
            # Should not raise
            send_telemetry("https://example.com/telemetry", {})

            for t in threading.enumerate():
                if t.daemon and t.is_alive():
                    t.join(timeout=2)
