"""
wrap_anthropic() — transparent telemetry for the Anthropic Python SDK.

Returns the same Anthropic client instance with messages.create() monkey-patched
to capture telemetry. The caller's code works identically — all types, overloads,
and streaming behavior are preserved.

Usage:
    from anthropic import Anthropic
    from aivyuh_finops import wrap_anthropic

    client = wrap_anthropic(Anthropic(), {
        "telemetry_endpoint": "https://api.example.com/telemetry",
        "customer_id": "cust-123",
        "project": "my-app",
        "tags": {"team": "product"},
    })

    # Use client normally — V7 captures metadata automatically
    response = client.messages.create(model="claude-sonnet-4-6-20260320", ...)
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, TypeVar

from .telemetry import send_telemetry
from .types import TelemetryPayload, WrapOptions

if TYPE_CHECKING:
    import anthropic

# Anthropic model pricing per 1M tokens (March 2026)
PRICING: dict[str, dict[str, float]] = {
    "claude-opus-4-6-20260320": {"input": 15.0, "output": 75.0},
    "claude-sonnet-4-6-20260320": {"input": 3.0, "output": 15.0},
    "claude-haiku-4-5-20251001": {"input": 0.8, "output": 4.0},
    "claude-sonnet-4-5-20250514": {"input": 3.0, "output": 15.0},
}
DEFAULT_PRICE = {"input": 3.0, "output": 15.0}

T = TypeVar("T")


def _estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    p = PRICING.get(model, DEFAULT_PRICE)
    cost = (input_tokens / 1_000_000) * p["input"] + (output_tokens / 1_000_000) * p["output"]
    return round(cost * 1_000_000) / 1_000_000


def wrap_anthropic(client: T, options: WrapOptions) -> T:
    """Wrap an existing Anthropic client to capture telemetry on messages.create().

    Returns the same client reference — existing code works unchanged.
    """
    if options.get("disable_telemetry"):
        return client

    original_create = client.messages.create  # type: ignore[union-attr]
    merged_tags: dict[str, str | None] = {}
    if options.get("project"):
        merged_tags["project"] = options["project"]
    merged_tags.update(options.get("tags") or {})

    endpoint = options["telemetry_endpoint"]
    customer_id = options["customer_id"]

    def patched_create(*args: Any, **kwargs: Any) -> Any:
        start = time.perf_counter()

        # Call the original — let errors propagate to the caller untouched
        response = original_create(*args, **kwargs)

        # For non-streaming responses, capture telemetry
        if hasattr(response, "usage"):
            latency_ms = round((time.perf_counter() - start) * 1000)
            usage = response.usage
            model = response.model
            input_tokens = usage.input_tokens
            output_tokens = usage.output_tokens
            cache_hit = getattr(usage, "cache_read_input_tokens", 0) > 0

            payload: TelemetryPayload = {
                "customer_id": customer_id,
                "provider": "anthropic",
                "model": model,
                "tokens_input": input_tokens,
                "tokens_output": output_tokens,
                "cost_usd": _estimate_cost(model, input_tokens, output_tokens),
                "latency_ms": latency_ms,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "cache_hit": cache_hit,
                "streaming": False,
                "tags": {**merged_tags},
            }

            try:
                send_telemetry(endpoint, payload)
            except Exception:
                pass  # Telemetry must never impact the caller

        return response

    client.messages.create = patched_create  # type: ignore[union-attr]
    return client
