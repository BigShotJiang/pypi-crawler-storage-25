"""
wrap_openai() — transparent telemetry for the OpenAI Python SDK.

Returns the same OpenAI client instance with chat.completions.create()
monkey-patched to capture telemetry. The caller's code works identically.

Usage:
    from openai import OpenAI
    from aivyuh_finops import wrap_openai

    client = wrap_openai(OpenAI(), {
        "telemetry_endpoint": "https://api.example.com/telemetry",
        "customer_id": "cust-123",
        "project": "my-app",
    })

    # Use client normally — V7 captures metadata automatically
    response = client.chat.completions.create(model="gpt-4o", ...)
"""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, TypeVar

from .telemetry import send_telemetry
from .types import TelemetryPayload, WrapOptions

if TYPE_CHECKING:
    import openai

# OpenAI model pricing per 1M tokens (March 2026)
PRICING: dict[str, dict[str, float]] = {
    "gpt-4o": {"input": 2.5, "output": 10.0},
    "gpt-4o-2024-08-06": {"input": 2.5, "output": 10.0},
    "gpt-4o-mini": {"input": 0.15, "output": 0.6},
    "gpt-4o-mini-2024-07-18": {"input": 0.15, "output": 0.6},
    "gpt-4-turbo": {"input": 10.0, "output": 30.0},
    "gpt-4-turbo-2024-04-09": {"input": 10.0, "output": 30.0},
    "o3-mini": {"input": 1.1, "output": 4.4},
    "o3-mini-2025-01-31": {"input": 1.1, "output": 4.4},
}
DEFAULT_PRICE = {"input": 2.5, "output": 10.0}

T = TypeVar("T")


def _estimate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    p = PRICING.get(model, DEFAULT_PRICE)
    cost = (input_tokens / 1_000_000) * p["input"] + (output_tokens / 1_000_000) * p["output"]
    return round(cost * 1_000_000) / 1_000_000


def wrap_openai(client: T, options: WrapOptions) -> T:
    """Wrap an existing OpenAI client to capture telemetry on chat.completions.create().

    Returns the same client reference — existing code works unchanged.
    """
    if options.get("disable_telemetry"):
        return client

    original_create = client.chat.completions.create  # type: ignore[union-attr]
    merged_tags: dict[str, str | None] = {}
    if options.get("project"):
        merged_tags["project"] = options["project"]
    merged_tags.update(options.get("tags") or {})

    endpoint = options["telemetry_endpoint"]
    customer_id = options["customer_id"]

    def patched_create(*args: Any, **kwargs: Any) -> Any:
        start = time.perf_counter()

        # Call the original — let errors propagate to the caller untouched
        response = original_create(*args, **kwargs)

        # For non-streaming responses with usage data
        if hasattr(response, "usage") and response.usage is not None:
            latency_ms = round((time.perf_counter() - start) * 1000)
            usage = response.usage
            model = response.model

            payload: TelemetryPayload = {
                "customer_id": customer_id,
                "provider": "openai",
                "model": model,
                "tokens_input": usage.prompt_tokens,
                "tokens_output": usage.completion_tokens,
                "cost_usd": _estimate_cost(model, usage.prompt_tokens, usage.completion_tokens),
                "latency_ms": latency_ms,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "cache_hit": False,
                "streaming": False,
                "tags": {**merged_tags},
            }

            try:
                send_telemetry(endpoint, payload)
            except Exception:
                pass  # Telemetry must never impact the caller

        return response

    client.chat.completions.create = patched_create  # type: ignore[union-attr]
    return client
