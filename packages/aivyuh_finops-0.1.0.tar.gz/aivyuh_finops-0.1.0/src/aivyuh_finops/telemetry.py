"""
Fire-and-forget telemetry sender.

Zero-overhead when V7 is unreachable: HTTP POST runs in a background thread
and errors are silently swallowed. Telemetry must NEVER impact the caller.
"""

from __future__ import annotations

import json
import threading
from typing import TYPE_CHECKING
from urllib.request import Request, urlopen

if TYPE_CHECKING:
    from .types import TelemetryPayload


def send_telemetry(endpoint: str, payload: TelemetryPayload) -> None:
    """Fire-and-forget POST to the V7 telemetry endpoint."""

    def _post() -> None:
        try:
            data = json.dumps(payload).encode()
            req = Request(
                endpoint,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urlopen(req, timeout=5)  # noqa: S310 — trusted internal endpoint
        except Exception:
            # Silently swallow — telemetry must never impact the caller
            pass

    thread = threading.Thread(target=_post, daemon=True)
    thread.start()
