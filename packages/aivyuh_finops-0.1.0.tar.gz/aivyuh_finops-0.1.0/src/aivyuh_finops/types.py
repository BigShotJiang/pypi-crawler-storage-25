"""Shared types for V7 SDK Wrapper."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TypedDict


class WrapOptions(TypedDict, total=False):
    """Options passed to wrap_client()."""

    telemetry_endpoint: str  # required
    customer_id: str  # required
    project: str
    tags: dict[str, str]
    disable_telemetry: bool


class TelemetryPayload(TypedDict, total=False):
    """Payload sent to the V7 telemetry endpoint."""

    customer_id: str
    provider: str  # "anthropic" | "openai"
    model: str
    tokens_input: int
    tokens_output: int
    cost_usd: float
    latency_ms: int
    timestamp: str
    cache_hit: bool
    streaming: bool
    tags: dict[str, str | None]
