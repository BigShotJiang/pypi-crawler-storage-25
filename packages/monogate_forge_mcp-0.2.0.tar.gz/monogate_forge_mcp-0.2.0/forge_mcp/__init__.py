"""Forge MCP server -- wraps the Monogate Forge compiler as MCP tools."""

__version__ = "0.2.0"
