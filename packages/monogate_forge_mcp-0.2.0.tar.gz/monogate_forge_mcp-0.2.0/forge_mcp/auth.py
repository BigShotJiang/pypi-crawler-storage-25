"""License verification for the MCP server.

Free-tier tools call nothing here (they're auth-less). Pro-tier
operations -- compilation to a Pro target, theorem-emit when the
source uses Pro-gated features -- pass the caller-supplied token
through `verify_license_for_target()`.

License token resolution order, per call:
  1. ``license_token`` argument passed to the tool.
  2. ``MONOGATE_LICENSE`` environment variable (matches the forge
     CLI's behaviour).
  3. None -- treated as Free tier; Pro targets refused.

Verification key:
  * If the env var ``MONOGATE_FORGE_SIGNING_KEY`` is set, that
    base64 ed25519 public key overrides forge's embedded key.
    This is the rotation hook -- a key roll updates the deployment
    config without re-shipping forge.
  * Otherwise the embedded key from
    ``forge.tools.license.verifier.PUBLIC_KEY_B64`` is used.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

# These imports rely on `monogate-forge` being installed as a
# package (per pyproject.toml). The Dockerfile installs forge from
# the local source tree so the verifier's embedded public key
# matches the deployed version.
from tools.license.verifier import (
    FREE_TARGETS,
    PRO_TARGETS,
    License,
    LicenseError,
    target_allowed,
    verify_token as _forge_verify_token,
)


_LICENSE_ENV = "MONOGATE_LICENSE"
_KEY_OVERRIDE_ENV = "MONOGATE_FORGE_SIGNING_KEY"


@dataclass(frozen=True)
class AuthDecision:
    """Outcome of a per-tool authorization check."""
    allowed: bool
    tier: str   # "Free" | "Pro"
    reason: str = ""
    license: License | None = None


def _override_public_key_if_set() -> None:
    """Replace forge's embedded ed25519 public key with the env one.

    Idempotent: a no-op if the env var is unset, or already applied.
    Uses module-level mutation of the verifier so verify_token sees
    the new key on its next call.
    """
    override = os.environ.get(_KEY_OVERRIDE_ENV, "").strip()
    if not override:
        return
    import tools.license.verifier as v
    if getattr(v, "PUBLIC_KEY_B64", "") != override:
        v.PUBLIC_KEY_B64 = override


def _resolve_token(explicit_token: str | None) -> str | None:
    if explicit_token:
        return explicit_token.strip() or None
    env = os.environ.get(_LICENSE_ENV, "").strip()
    return env or None


def verify_license(token: str | None) -> AuthDecision:
    """Verify a token (or env-loaded equivalent) and return tier.

    No license at all -> Free tier (allowed for free tools and free
    targets). A bad token -> not allowed; the reason is surfaced so
    callers can return a useful error in the tool payload.
    """
    _override_public_key_if_set()
    raw = _resolve_token(token)
    if raw is None:
        return AuthDecision(allowed=True, tier="Free")
    try:
        lic = _forge_verify_token(raw)
    except LicenseError as e:
        return AuthDecision(
            allowed=False, tier="Free",
            reason=f"license invalid: {e}",
        )
    return AuthDecision(
        allowed=True, tier=("Pro" if lic.tier == "pro" else "Free"),
        license=lic,
    )


def verify_license_for_target(
    target: str, token: str | None,
) -> AuthDecision:
    """Combine `verify_license` + per-target Free/Pro gate.

    Returns a decision that's specifically about whether the named
    target is permitted under the resolved license. Free targets are
    permitted unconditionally; Pro targets need a non-None,
    Pro-tier license.
    """
    decision = verify_license(token)
    if not decision.allowed:
        return decision
    if target_allowed(target, decision.license):
        return decision
    return AuthDecision(
        allowed=False, tier=decision.tier,
        reason=(f"target {target!r} requires Pro license "
                f"(current tier: {decision.tier})"),
        license=decision.license,
    )


def free_targets() -> tuple[str, ...]:
    return tuple(sorted(FREE_TARGETS))


def pro_targets() -> tuple[str, ...]:
    return tuple(sorted(PRO_TARGETS))


def all_targets() -> tuple[str, ...]:
    return tuple(sorted(set(FREE_TARGETS) | set(PRO_TARGETS)))
