"""Forge MCP server entrypoint.

Exposes 9 tools over MCP via either stdio (for local Claude
desktop / IDE attach) or SSE (for the hosted Fly.io deployment).

Default transport is SSE on 0.0.0.0:8080 -- Fly.io expects the
container to listen on $PORT and bind to 0.0.0.0. The MCP
endpoint clients paste into Claude is `<base>/sse`.

Run locally:

    forge-mcp --transport stdio                      # for IDE
    forge-mcp --transport sse --host 0.0.0.0 --port 8080
"""
from __future__ import annotations

import argparse
import os
import sys
from typing import Any

from mcp.server.fastmcp import FastMCP

from forge_mcp import __version__
from forge_mcp.tools import (
    compile_tool,
    decompile_tool,
    explain_function_tool,
    genome_tool,
    list_targets_tool,
    list_verticals_tool,
    profile_tool,
    search_corpus_tool,
    verify_tool,
)


_INSTRUCTIONS = """\
Monogate Forge MCP server. Wraps the EML compiler and corpus.

Free tools (no license needed): profile, verify, search_corpus,
genome, explain_function, list_targets, list_verticals, decompile.

License-gated tools: compile (Free targets work without a token,
Pro targets need a license from monogateforge.com).

`verify` emits Lean theorem scaffolding -- it does NOT prove
anything. Run Lean yourself on the returned source to check.

`decompile` wraps eFrog (forge spelled backwards): take Python /
C / Rust / JavaScript / MATLAB source and lift it back to EML.
"""


def build_server() -> FastMCP:
    """Construct and configure the FastMCP server with all 8 tools."""
    host = os.environ.get("FORGE_MCP_HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", os.environ.get("FORGE_MCP_PORT", "8080")))

    mcp = FastMCP(
        name="forge-mcp",
        instructions=_INSTRUCTIONS,
        host=host,
        port=port,
    )

    # ── Free-tier tools ──────────────────────────────────────────

    @mcp.tool(
        name="profile",
        title="Profile EML source",
        description=(
            "Per-function chain order, cost class, fp16 drift risk, "
            "node count, and (when @target(fpga) is present) FPGA "
            "estimates: LUTs, DSPs, BRAM, clock, throughput. Free."
        ),
    )
    def profile(source: str) -> dict[str, Any]:
        return profile_tool(source)

    @mcp.tool(
        name="verify",
        title="Emit Lean theorem scaffolding (does NOT prove)",
        description=(
            "For any `@verify(lean, theorem = \"...\")` annotation, "
            "emit Lean 4 theorem scaffolding with `sorry` proofs. "
            "Returns theorem count and sorries-pending. The MCP server "
            "does NOT run Lean; users verify by running `lake build` "
            "on the returned source themselves. Free."
        ),
    )
    def verify(source: str) -> dict[str, Any]:
        return verify_tool(source)

    @mcp.tool(
        name="search_corpus",
        title="Search the SuperBEST corpus (576 records)",
        description=(
            "Query the eml-cost SuperBEST corpus by substring match "
            "against name + expression, by exact domain tag, and/or "
            "by max chain order. Returns up to `limit` matches with "
            "name, domain, expression, cost class, chain order. Free."
        ),
    )
    def search_corpus(
        query: str | None = None,
        domain: str | None = None,
        max_chain_order: int | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        return search_corpus_tool(
            query=query, domain=domain,
            max_chain_order=max_chain_order, limit=limit,
        )

    @mcp.tool(
        name="genome",
        title="Find functions with similar EML tree structure",
        description=(
            "Find structural neighbours in the SuperBEST corpus via "
            "cost-class fingerprint distance. Pass either "
            "`expression` (sympy string like `\"sin(x)*exp(-t)\"`) or "
            "`source` (an EML module) plus optional `function_name`. "
            "v1 wraps eml_cost.find_siblings; same-fingerprint "
            "matches are 'related shapes' not 'drop-in replacements'. "
            "Free."
        ),
    )
    def genome(
        expression: str | None = None,
        source: str | None = None,
        function_name: str | None = None,
        k: int = 5,
    ) -> dict[str, Any]:
        return genome_tool(
            expression=expression, source=source,
            function_name=function_name, k=k,
        )

    @mcp.tool(
        name="explain_function",
        title="Explain one function's optimizer trace",
        description=(
            "Human-readable breakdown of one EML function: optimizer "
            "passes that fired, before/after node counts, SuperBEST "
            "family + digits saved, CSE bindings introduced. Pass "
            "the source plus optional function_name (defaults to the "
            "first function). Free."
        ),
    )
    def explain_function(
        source: str,
        function_name: str | None = None,
    ) -> dict[str, Any]:
        return explain_function_tool(source, function_name=function_name)

    @mcp.tool(
        name="list_targets",
        title="List all 32 backends with Free/Pro tier",
        description=(
            "Enumerate every Forge backend split by tier. Free targets "
            "compile without a license. Pro targets need a Pro token. "
            "No args. Free."
        ),
    )
    def list_targets() -> dict[str, Any]:
        return list_targets_tool()

    @mcp.tool(
        name="list_verticals",
        title="List industry verticals with kernel counts",
        description=(
            "Enumerate the Pro kernel library verticals (aerospace, "
            "automotive, crypto, medical, ...) with .eml file counts "
            "per vertical. Sample kernel basenames included. The "
            "kernel sources themselves are NOT exposed by this tool. "
            "No args. Free."
        ),
    )
    def list_verticals() -> dict[str, Any]:
        return list_verticals_tool()

    # ── License-gated tool ──────────────────────────────────────

    @mcp.tool(
        name="compile",
        title="Compile EML source to one of 32 targets",
        description=(
            "Compile EML source to one target. Free targets (12) work "
            "without a token. Pro targets (20: FPGA / GPU shaders / "
            "safety-critical / Coq+Isabelle / Solidity / Apple Swift / "
            "gaming) require `license_token`. Get a Pro license at "
            "https://monogateforge.com/get-started"
        ),
    )
    def compile(
        source: str,
        target: str,
        license_token: str | None = None,
    ) -> dict[str, Any]:
        return compile_tool(source, target, license_token=license_token)

    # ── Decompile (eFrog) ────────────────────────────────────────

    @mcp.tool(
        name="decompile",
        title="Lift source code back to EML (eFrog)",
        description=(
            "Take Python / C / Rust / JavaScript / MATLAB source and "
            "lift it back to an EML module via eFrog (forge spelled "
            "backwards). Returns the EML source text plus chain order "
            "per function. Pass `language` as one of: python, c, rust, "
            "javascript, matlab. Free."
        ),
    )
    def decompile(source: str, language: str) -> dict[str, Any]:
        return decompile_tool(source, language)

    # ── Health endpoint (Fly.io readiness/liveness) ─────────────

    @mcp.custom_route("/health", methods=["GET"])
    async def health(request):  # noqa: ARG001
        from starlette.responses import JSONResponse
        return JSONResponse({
            "ok": True,
            "service": "forge-mcp",
            "version": __version__,
            "tools": 9,
        })

    return mcp


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        prog="forge-mcp",
        description=(
            "MCP server exposing Forge as 8 tools. SSE transport for "
            "Fly.io / hosted; stdio for local IDE attach."
        ),
    )
    p.add_argument(
        "--transport", choices=["stdio", "sse", "streamable-http"],
        default=os.environ.get("FORGE_MCP_TRANSPORT", "sse"),
        help="MCP transport. Default: env FORGE_MCP_TRANSPORT or sse.",
    )
    p.add_argument("--version", action="version",
                   version=f"forge-mcp {__version__}")
    args = p.parse_args(argv)

    mcp = build_server()
    print(
        f"forge-mcp {__version__}: starting transport={args.transport} "
        f"host={mcp.settings.host} port={mcp.settings.port}",
        file=sys.stderr,
    )
    mcp.run(transport=args.transport)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
