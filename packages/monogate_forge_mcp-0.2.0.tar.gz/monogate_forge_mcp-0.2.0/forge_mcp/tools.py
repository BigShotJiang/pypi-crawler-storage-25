"""8 MCP tools wrapping the Forge compiler.

  * Free-tier (no auth needed): ``profile``, ``verify``,
    ``search_corpus``, ``genome``, ``explain_function``,
    ``list_targets``, ``list_verticals``.
  * License-gated: ``compile`` (Free targets work without a token,
    Pro targets require a Pro license).

Every tool returns a JSON-serialisable dict and never raises out
to the MCP transport -- failures are surfaced as ``{ok: false,
error: ...}`` so MCP clients (Claude included) get a structured
error instead of a transport-level fault.
"""
from __future__ import annotations

import io
import os
import re
import tempfile
import textwrap
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from typing import Any

from forge_mcp.auth import (
    all_targets,
    free_targets,
    pro_targets,
    verify_license,
    verify_license_for_target,
)


# ────────────────────────── Constants ──────────────────────────

# Corpus size honest as of forge_mcp 0.1.0; verified live via
# `eml_cost.corpus_size()` in tests so this constant cannot drift
# silently.
_CORPUS_SIZE_DECLARED = 576

# Industries directory of the editable-installed forge package.
# Discovery is at request time so a forge upgrade with new verticals
# is picked up automatically.
def _forge_root() -> Path:
    """Resolve the forge package root from the importable module."""
    import tools.cli.main as _m
    # tools/ is one level above the forge root in the editable install
    return Path(_m.__file__).resolve().parents[2]


def _industries_dir() -> Path:
    return _forge_root() / "industries"


# ────────────────────────── Compile ────────────────────────────


def compile_tool(
    source: str,
    target: str,
    license_token: str | None = None,
) -> dict[str, Any]:
    """compile -- EML source + target -> compiled output for that target.

    License-gated: Free targets (c, cpp, rust, go, java, kotlin,
    csharp, python, javascript, wasm, matlab, lean) work without a
    token. Pro targets require a Pro license verified via the
    embedded Ed25519 key.
    """
    decision = verify_license_for_target(target, license_token)
    if not decision.allowed:
        return {
            "ok": False,
            "tier": decision.tier,
            "target": target,
            "error": decision.reason or "license check failed",
        }

    if target not in all_targets():
        return {
            "ok": False, "tier": decision.tier, "target": target,
            "error": (f"unknown target {target!r}; "
                       f"valid: {', '.join(all_targets())}"),
        }

    try:
        compiled = _compile_target(source, target)
    except Exception as e:  # noqa: BLE001
        return {
            "ok": False, "tier": decision.tier, "target": target,
            "error": f"compile failed: {type(e).__name__}: {e}",
        }
    return {
        "ok": True, "tier": decision.tier, "target": target,
        "output": compiled,
        "bytes": len(compiled),
        "lines": compiled.count("\n") + (0 if compiled.endswith("\n") else 1),
    }


def _compile_target(source: str, target: str) -> str:
    """Dispatch to the correct backend. Imports are lazy so cold-
    start of the MCP server doesn't pay the cost of every backend."""
    from lang.parser import parse_source
    from lang.profiler import Profiler

    mod = parse_source(source, "<mcp>")
    Profiler().profile_module(mod)

    if target == "python":
        from software.backends.python_backend import PythonBackend
        return PythonBackend().compile(mod)
    if target == "rust":
        from software.backends.rust_backend import RustBackend
        return RustBackend().compile(mod)
    if target == "c":
        from software.backends.c_backend import CBackend
        return CBackend().compile(mod)
    if target == "cpp":
        from software.backends.cpp_backend import CppBackend
        return CppBackend().compile(mod)
    if target == "go":
        from software.backends.go_backend import GoBackend
        return GoBackend().compile(mod)
    if target == "java":
        from software.backends.java_backend import JavaBackend
        return JavaBackend().compile(mod)
    if target == "kotlin":
        from software.backends.kotlin_backend import KotlinBackend
        return KotlinBackend().compile(mod)
    if target == "csharp":
        from software.backends.csharp_backend import CSharpBackend
        return CSharpBackend().compile(mod)
    if target == "javascript":
        from software.backends.javascript_backend import JavaScriptBackend
        return JavaScriptBackend().compile(mod)
    if target == "matlab":
        from software.backends.matlab_backend import MatlabBackend
        return MatlabBackend().compile(mod)
    if target == "wasm":
        from software.backends.wasm_backend import WasmBackend
        return WasmBackend().compile(mod)
    if target == "lean":
        from software.verification.lean.LeanBackend import LeanBackend
        return LeanBackend().compile_module(mod)
    # Pro targets follow the same call shape; we route to the CLI
    # internals via subprocess to inherit its dispatch table without
    # re-listing every Pro backend here.
    return _compile_via_cli(source, target)


def _compile_via_cli(source: str, target: str) -> str:
    """Fallback: invoke the eml-compile CLI for any target not
    inlined above. Writes source to a tempfile, calls main.main()
    with --output captured, returns the file contents."""
    import tools.cli.main as cli
    with tempfile.TemporaryDirectory(prefix="forge-mcp-") as tmp:
        src_path = Path(tmp) / "src.eml"
        src_path.write_text(source, encoding="utf-8")
        out_path = Path(tmp) / f"out.{target}"
        # Suppress CLI chatter into in-memory buffers so MCP clients
        # don't see stderr on the wire.
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            rc = cli.main([
                str(src_path), "--target", target, "-o", str(out_path),
            ])
        if rc != 0 or not out_path.exists():
            raise RuntimeError(
                f"eml-compile returned {rc} for target {target!r}; "
                f"no output file produced"
            )
        return out_path.read_text(encoding="utf-8")


# ────────────────────────── Profile ────────────────────────────


def profile_tool(source: str) -> dict[str, Any]:
    """profile -- EML source -> per-fn chain order, cost class,
    drift risk, and (for @target(fpga) functions) FPGA estimates."""
    from lang.parser import parse_source
    from lang.profiler import Profiler

    try:
        mod = parse_source(source, "<mcp>")
        Profiler().profile_module(mod)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    fpga_plan = _maybe_allocate_fpga(mod)

    fns: list[dict[str, Any]] = []
    for fn in mod.functions:
        prof = getattr(fn, "profile", {}) or {}
        fns.append({
            "name": fn.name,
            "params": [
                {"name": p.name, "type": p.type_name} for p in fn.params
            ],
            "return_type": fn.return_type,
            "chain_order": prof.get("chain_order"),
            "cost_class": prof.get("cost_class"),
            "eml_depth": prof.get("eml_depth"),
            "fp16_drift_risk": prof.get("fp16_drift_risk"),
            "node_count": prof.get("node_count"),
        })

    payload: dict[str, Any] = {
        "ok": True,
        "module": mod.name or "",
        "n_functions": len(fns),
        "functions": fns,
    }
    if fpga_plan is not None:
        payload["fpga_estimate"] = fpga_plan
    return payload


def _maybe_allocate_fpga(mod) -> dict[str, Any] | None:
    """Run FPGAAllocator if the module has any @target(fpga) function."""
    has_fpga = any(
        any(
            a.kind == "target" and (
                a.args.get(0) == "fpga" or a.args.get("0") == "fpga"
            )
            for a in fn.annotations
        )
        for fn in mod.functions
    )
    if not has_fpga:
        return None
    try:
        from hardware.allocator import FPGAAllocator
        plan = FPGAAllocator().allocate(mod)
    except Exception as e:  # noqa: BLE001
        return {"error": f"{type(e).__name__}: {e}"}
    return {
        "target_device": plan.target_device,
        "estimated_luts": plan.estimated_luts,
        "estimated_dsps": plan.estimated_dsps,
        "estimated_bram_kb": plan.estimated_bram_kb,
        "clock_mhz": plan.clock_mhz,
        "throughput_msps": plan.throughput_msps,
        "pipeline_depth": plan.pipeline_depth,
        "mac_units": plan.mac_units,
    }


# ────────────────────────── Verify (Lean-emit, honest) ─────────


_THEOREM_RE = re.compile(r"^\s*theorem\s+\w+", re.MULTILINE)


def verify_tool(source: str) -> dict[str, Any]:
    """verify -- emit Lean theorem scaffolding for any @verify(lean)
    blocks. **Does NOT prove anything.** Output is always the
    sorries-to-be-filled scaffolding; users run Lean themselves to
    check the proofs."""
    from lang.parser import parse_source
    from lang.profiler import Profiler

    try:
        mod = parse_source(source, "<mcp>")
        Profiler().profile_module(mod)
        from software.verification.lean.LeanBackend import LeanBackend
        lean_src = LeanBackend().compile_module(mod)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    if not lean_src:
        return {
            "ok": True,
            "theorems_emitted": 0,
            "sorries": 0,
            "ready_for_lean_check": False,
            "lean_source": None,
            "note": (
                "No `@verify(lean, ...)` blocks found in the source; "
                "nothing to emit. Add `@verify(lean, theorem = \"<name>\")` "
                "above any function to generate a theorem statement."
            ),
        }

    theorems = len(_THEOREM_RE.findall(lean_src))
    sorries = lean_src.count("sorry")
    return {
        "ok": True,
        "theorems_emitted": theorems,
        "sorries": sorries,
        "ready_for_lean_check": True,
        "lean_source": lean_src,
        "note": (
            "This is theorem scaffolding only. The MCP server does NOT "
            "run Lean. Save the lean_source to a .lean file inside a "
            "MachLib lake project and run `lake build` to verify."
        ),
    }


# ────────────────────────── search_corpus ──────────────────────


def _chain_order_from_cost_class(cc: str) -> int | None:
    m = re.match(r"^p(\d+)", cc or "")
    return int(m.group(1)) if m else None


def search_corpus_tool(
    query: str | None = None,
    domain: str | None = None,
    max_chain_order: int | None = None,
    limit: int = 10,
) -> dict[str, Any]:
    """search_corpus -- query the 576-record eml-cost corpus.

    Filters: substring `query` (matches name OR expression),
    `domain` (exact match against the corpus tag), and
    `max_chain_order` (numeric ceiling on the Pfaffian r). Returns
    up to `limit` matches.
    """
    from eml_cost import corpus_size, corpus_domains
    from eml_cost.siblings import _corpus_rows

    n_total = corpus_size()
    rows = _corpus_rows()

    q = (query or "").strip().lower()
    dom = (domain or "").strip().lower()

    matches: list[dict[str, Any]] = []
    for row in rows:
        name = str(row.get("name", ""))
        expr = str(row.get("expr", ""))
        rdom = str(row.get("domain", ""))
        cc = str(row.get("cost_class", ""))

        if q and q not in name.lower() and q not in expr.lower():
            continue
        if dom and dom != rdom.lower():
            continue
        if max_chain_order is not None:
            r = _chain_order_from_cost_class(cc)
            if r is None or r > max_chain_order:
                continue
        matches.append({
            "name": name, "domain": rdom,
            "expression": expr, "cost_class": cc,
            "chain_order": _chain_order_from_cost_class(cc),
        })

    truncated = len(matches) > limit
    return {
        "ok": True,
        "n_total_corpus": n_total,
        "n_total_match": len(matches),
        "n_returned": min(limit, len(matches)),
        "truncated": truncated,
        "available_domains": sorted(corpus_domains()),
        "results": matches[:max(0, limit)],
    }


# ────────────────────────── genome ─────────────────────────────


def genome_tool(
    expression: str | None = None,
    source: str | None = None,
    function_name: str | None = None,
    k: int = 5,
) -> dict[str, Any]:
    """genome -- find functions with similar EML tree structure.

    v1 implementation wraps `eml_cost.find_siblings` over the 576-row
    SuperBEST corpus. Pass either:

      * `expression` (a SymPy-parseable string, e.g. `"sin(x) * exp(-t)"`), OR
      * `source` (an EML module) plus optional `function_name` (defaults
        to first function in the module).

    Returns up to `k` corpus neighbours sorted by cost-class distance.
    """
    if not expression and not source:
        return {
            "ok": False,
            "error": ("provide either `expression` (sympy string) "
                       "or `source` (EML module)."),
        }

    if expression and source:
        return {
            "ok": False,
            "error": "provide exactly one of `expression` or `source`.",
        }

    try:
        if expression:
            query_expr = expression
            query_origin = "expression"
        else:
            query_expr = _eml_function_to_sympy(source, function_name)
            query_origin = function_name or "<first>"
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    try:
        from eml_cost import find_siblings
        sibs = find_siblings(query_expr, k=k)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"find_siblings: "
                                       f"{type(e).__name__}: {e}"}

    out = []
    for s in sibs:
        prof = s.profile
        out.append({
            "name": s.name,
            "domain": s.domain,
            "expression": str(s.expression),
            "cost_class": s.cost_class,
            "distance": float(s.distance),
            "chain_order": int(getattr(prof, "r",
                                         getattr(prof, "pfaffian_r", -1))),
            "eml_depth": int(getattr(prof, "degree",
                                       getattr(prof, "eml_depth", -1))),
        })
    return {
        "ok": True,
        "query": str(query_expr),
        "query_origin": query_origin,
        "k_requested": k,
        "n_returned": len(out),
        "neighbours": out,
        "note": (
            "v1 finds structural neighbours via cost-class fingerprint. "
            "Same-fingerprint matches will surface even when the algebra "
            "is unrelated -- treat results as 'related shapes', not "
            "'drop-in replacements'."
        ),
    }


def _eml_function_to_sympy(source: str, function_name: str | None):
    from lang.parser import parse_source
    from lang.profiler.ast_to_sympy import convert_function_body

    mod = parse_source(source, "<mcp>")
    if not mod.functions:
        raise ValueError("source has no functions")
    if function_name:
        for fn in mod.functions:
            if fn.name == function_name:
                target_fn = fn
                break
        else:
            names = ", ".join(f.name for f in mod.functions)
            raise ValueError(
                f"function {function_name!r} not in module "
                f"(have: {names})"
            )
    else:
        target_fn = mod.functions[0]
    conv = convert_function_body(target_fn)
    expr = getattr(conv, "expression", None)
    if expr is None:
        raise ValueError(
            f"function {target_fn.name!r} body did not convert to a "
            f"single SymPy expression (status={conv.status!r}; "
            f"note={conv.note!r})"
        )
    return expr


# ────────────────────────── explain_function ───────────────────


def explain_function_tool(
    source: str,
    function_name: str | None = None,
) -> dict[str, Any]:
    """explain_function -- human-readable breakdown of one function:
    optimizer passes that fired, before/after node counts, SuperBEST
    family + digits saved, CSE bindings."""
    from lang.parser import parse_source
    from lang.profiler import Profiler

    try:
        mod = parse_source(source, "<mcp>")
        Profiler().profile_module(mod)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    target_name = function_name or (
        mod.functions[0].name if mod.functions else None
    )
    if target_name is None:
        return {"ok": False, "error": "source has no functions"}

    try:
        from tools.cli.explain import build_explain_report
        report = build_explain_report(mod)
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"build_explain_report: "
                                       f"{type(e).__name__}: {e}"}

    fn_report = None
    if isinstance(report, dict):
        fns = report.get("functions") or []
        for f in fns:
            if f.get("name") == target_name:
                fn_report = f
                break

    if fn_report is None:
        # Fall back to a textual rendering via print_explain_report so
        # at least something is returned for older forge versions.
        from tools.cli.explain import print_explain_report
        buf = io.StringIO()
        with redirect_stdout(buf):
            try:
                print_explain_report(
                    mod, function_name=target_name, json_output=False,
                    backend_stats=False,
                )
            except TypeError:
                print_explain_report(mod)
        return {
            "ok": True, "function": target_name,
            "structured": False,
            "text_report": buf.getvalue(),
        }

    return {
        "ok": True, "function": target_name,
        "structured": True,
        "report": fn_report,
    }


# ────────────────────────── list_targets ───────────────────────


def list_targets_tool() -> dict[str, Any]:
    """list_targets -- enumerate every backend with Free/Pro tier."""
    free = list(free_targets())
    pro = list(pro_targets())
    return {
        "ok": True,
        "n_free": len(free),
        "n_pro": len(pro),
        "n_total": len(free) + len(pro),
        "free": free,
        "pro": pro,
        "note": (
            "Pro targets require a Pro license token. Pass "
            "`license_token` to the `compile` tool, or set "
            "MONOGATE_LICENSE in the server's env. Get one at "
            "https://monogateforge.com/get-started"
        ),
    }


# ────────────────────────── list_verticals ─────────────────────


def list_verticals_tool() -> dict[str, Any]:
    """list_verticals -- enumerate the proprietary kernel library
    verticals with kernel counts. Counts files only; the proprietary
    contents themselves are not exposed."""
    industries = _industries_dir()
    if not industries.is_dir():
        return {
            "ok": True,
            "n_verticals": 0,
            "verticals": [],
            "note": (
                "industries/ not present in this deployment "
                "(open-source build). The Pro kernel library "
                "ships separately."
            ),
        }
    rows: list[dict[str, Any]] = []
    for d in sorted(industries.iterdir()):
        if not d.is_dir():
            continue
        emls = list(d.rglob("*.eml"))
        if not emls:
            continue
        rows.append({
            "name": d.name,
            "kernel_count": len(emls),
            # Sample 3 kernel basenames as concrete examples.
            "sample_kernels": sorted(
                p.stem for p in emls[:8]
            )[:3],
        })
    rows.sort(key=lambda r: -r["kernel_count"])
    total = sum(r["kernel_count"] for r in rows)
    return {
        "ok": True,
        "n_verticals": len(rows),
        "n_total_kernels": total,
        "verticals": rows,
    }


# ────────────────────────── decompile (eFrog) ──────────────────


# Languages eFrog can lift back into EML. Order is the public-facing
# order surfaced in the tool's docstring + error message.
_DECOMPILE_LANGUAGES: tuple[str, ...] = (
    "python", "c", "rust", "javascript", "matlab",
)


def decompile_tool(
    source: str,
    language: str,
) -> dict[str, Any]:
    """decompile -- source code in `language` -> EML module.

    Wraps the eFrog universal decompiler (forge spelled backwards).
    Supported languages: python, c, rust, javascript, matlab. The
    EML output names a chain order per function so callers can see
    immediately where the lifted code sits in the EML cost lattice.

    Failure modes (each returned as `{ok: False, error: ...}`):
      * unknown language
      * eFrog parse / lift errors (unsupported constructs)
      * efrog package missing from the deployment image
    """
    lang = (language or "").strip().lower()
    if lang not in _DECOMPILE_LANGUAGES:
        return {
            "ok": False,
            "language": lang,
            "error": (f"unsupported language {language!r}; "
                       f"valid: {', '.join(_DECOMPILE_LANGUAGES)}"),
        }

    try:
        import efrog
    except ImportError as e:
        return {
            "ok": False,
            "language": lang,
            "error": (f"efrog not installed in this deployment: {e}. "
                       f"The MCP image needs the eFrog package; "
                       f"redeploy after `pip install efrog`."),
        }

    dispatch = {
        "python":     efrog.decompile_python_source,
        "c":          efrog.decompile_c_source,
        "rust":       efrog.decompile_rust_source,
        "javascript": efrog.decompile_javascript_source,
        "matlab":     efrog.decompile_matlab_source,
    }
    decompile_fn = dispatch[lang]

    try:
        mod = decompile_fn(source)
    except Exception as e:  # noqa: BLE001 -- surface every failure as JSON
        # eFrog raises EFrogError for unsupported constructs; pass the
        # message through verbatim so the user can see which line
        # tripped the lifter.
        return {
            "ok": False,
            "language": lang,
            "error": f"{type(e).__name__}: {e}",
        }

    eml_source = mod.to_eml()
    fns = [
        {
            "name": fn.name,
            "chain_order": fn.chain_order,
            "return_type": fn.return_type,
            "n_args": len(fn.args),
        }
        for fn in mod.functions
    ]

    payload: dict[str, Any] = {
        "ok": True,
        "language": lang,
        "module": mod.name,
        "n_functions": len(fns),
        "functions": fns,
        "eml": eml_source,
        "bytes": len(eml_source),
        "lines": eml_source.count("\n") + (
            0 if eml_source.endswith("\n") else 1
        ),
    }
    if mod.needs_step01:
        payload["note"] = (
            "Output includes a `step01` preamble fn — eFrog flattened "
            "an if/else into a branch-free `lerp(else, then, step01(cond))`."
        )
    return payload
