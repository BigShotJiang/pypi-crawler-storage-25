"""End-to-end test of the MCP server through its real transport.

Spins up the FastMCP server with stdio transport in a subprocess,
talks JSON-RPC over its stdin/stdout via the official MCP client
SDK, and exercises every tool. This is the closest in-process
equivalent to "what Claude sees on the wire" before deployment.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.anyio


@pytest.fixture
def anyio_backend():
    return "asyncio"


_FORGE_MCP_ROOT = Path(__file__).resolve().parent.parent


_DAMPED = """\
module damped;
fn damped(zeta: Real, omega: Real, t: Real) -> Real {
    exp(-zeta * t) * sin(omega * t)
}
"""

_VERIFY = """\
module v;
@verify(lean, theorem = "f_nonneg")
fn f(x: Real) -> Real
    requires x >= 0.0
    ensures result >= 0.0
{ x + 1.0 }
"""


async def _open_session():
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "forge_mcp.server", "--transport", "stdio"],
    )
    return stdio_client(params)


async def test_e2e_lists_9_tools():
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            resp = await session.list_tools()
            names = sorted(t.name for t in resp.tools)
            assert names == sorted([
                "compile", "decompile", "explain_function", "genome",
                "list_targets", "list_verticals", "profile",
                "search_corpus", "verify",
            ])


async def test_e2e_list_targets():
    import json
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            res = await session.call_tool("list_targets", {})
            payload = json.loads(res.content[0].text)
            assert payload["ok"] is True
            assert payload["n_free"] == 12
            assert "verilog" in payload["pro"]


async def test_e2e_compile_python():
    import json
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            res = await session.call_tool("compile", {
                "source": _DAMPED, "target": "python",
            })
            payload = json.loads(res.content[0].text)
            assert payload["ok"] is True
            assert "def damped" in payload["output"]


async def test_e2e_compile_pro_target_refused():
    import json
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            res = await session.call_tool("compile", {
                "source": _DAMPED, "target": "verilog",
            })
            payload = json.loads(res.content[0].text)
            assert payload["ok"] is False
            assert "Pro license" in payload["error"]


async def test_e2e_profile():
    import json
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            res = await session.call_tool("profile", {"source": _DAMPED})
            payload = json.loads(res.content[0].text)
            assert payload["ok"] is True
            assert payload["functions"][0]["name"] == "damped"


async def test_e2e_verify():
    import json
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            res = await session.call_tool("verify", {"source": _VERIFY})
            payload = json.loads(res.content[0].text)
            assert payload["ok"] is True
            assert payload["theorems_emitted"] >= 1
            assert payload["sorries"] >= 1


async def test_e2e_search_corpus():
    import json
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            res = await session.call_tool("search_corpus", {
                "query": "cos", "limit": 5,
            })
            payload = json.loads(res.content[0].text)
            assert payload["ok"] is True
            assert payload["n_total_corpus"] == 576


async def test_e2e_genome():
    import json
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            res = await session.call_tool("genome", {
                "expression": "exp(-z*t) * sin(omega*t)", "k": 3,
            })
            payload = json.loads(res.content[0].text)
            assert payload["ok"] is True
            assert payload["n_returned"] <= 3


async def test_e2e_explain_function():
    import json
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            res = await session.call_tool("explain_function", {
                "source": _DAMPED, "function_name": "damped",
            })
            payload = json.loads(res.content[0].text)
            assert payload["ok"] is True
            assert payload["function"] == "damped"


async def test_e2e_list_verticals():
    import json
    from mcp import ClientSession
    cm = await _open_session()
    async with cm as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            res = await session.call_tool("list_verticals", {})
            payload = json.loads(res.content[0].text)
            assert payload["ok"] is True
            assert payload["n_verticals"] >= 5
