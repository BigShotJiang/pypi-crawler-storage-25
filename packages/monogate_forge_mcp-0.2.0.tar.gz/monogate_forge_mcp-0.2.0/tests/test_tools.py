"""Tests for the 8 MCP tool implementations.

Real forge calls + real eml-cost. The tools are pure functions so we
exercise them directly instead of through the MCP transport (that's
covered by `test_server.py`).
"""
from __future__ import annotations

import pytest

from forge_mcp.tools import (
    compile_tool,
    decompile_tool,
    explain_function_tool,
    genome_tool,
    list_targets_tool,
    list_verticals_tool,
    profile_tool,
    search_corpus_tool,
    verify_tool,
)


_SAMPLE = """\
module sample;

@verify(lean, theorem = "f_nonneg")
fn f(x: Real) -> Real
    requires x >= 0.0
    ensures result >= 0.0
{
    x + 1.0
}
"""


_DAMPED = """\
module damped;
fn damped(zeta: Real, omega: Real, t: Real) -> Real {
    exp(-zeta * t) * sin(omega * t)
}
"""


_FPGA = """\
module fpga_demo;

@target(fpga)
fn add_pipe(a: Real, b: Real) -> Real { a + b }
"""


# ──────── compile ────────

def test_compile_python_free_no_token():
    r = compile_tool(_DAMPED, "python")
    assert r["ok"] is True
    assert r["tier"] == "Free"
    assert r["target"] == "python"
    assert "def damped" in r["output"]
    assert r["bytes"] > 0


def test_compile_pro_target_refused_without_license():
    r = compile_tool(_FPGA, "verilog")
    assert r["ok"] is False
    assert "Pro license" in r["error"]


def test_compile_unknown_target():
    r = compile_tool(_DAMPED, "klingon")
    assert r["ok"] is False
    assert "unknown target" in r["error"]


def test_compile_invalid_source():
    r = compile_tool("not a module at all", "python")
    assert r["ok"] is False
    assert "compile failed" in r["error"]


def test_compile_lean_emits_when_verify_block_present():
    r = compile_tool(_SAMPLE, "lean")
    assert r["ok"] is True
    assert "theorem" in r["output"].lower()


# ──────── profile ────────

def test_profile_basic():
    r = profile_tool(_DAMPED)
    assert r["ok"] is True
    assert r["n_functions"] == 1
    fn = r["functions"][0]
    assert fn["name"] == "damped"
    assert fn["chain_order"] is not None
    assert fn["cost_class"] is not None
    assert "fpga_estimate" not in r  # no @target(fpga)


def test_profile_with_fpga_estimate():
    r = profile_tool(_FPGA)
    assert r["ok"] is True
    assert "fpga_estimate" in r
    fpga = r["fpga_estimate"]
    assert "estimated_luts" in fpga
    assert "throughput_msps" in fpga
    assert fpga["estimated_luts"] > 0


def test_profile_invalid_source():
    r = profile_tool("module x; broken")
    assert r["ok"] is False


# ──────── verify ────────

def test_verify_with_lean_block():
    r = verify_tool(_SAMPLE)
    assert r["ok"] is True
    assert r["theorems_emitted"] >= 1
    assert r["sorries"] >= 1
    assert r["ready_for_lean_check"] is True
    assert r["lean_source"]
    assert "does NOT" in r["note"]


def test_verify_no_lean_block():
    r = verify_tool(_DAMPED)
    assert r["ok"] is True
    assert r["theorems_emitted"] == 0
    assert r["ready_for_lean_check"] is False
    assert r["lean_source"] is None


def test_verify_never_claims_proven():
    r = verify_tool(_SAMPLE)
    blob = (r.get("note", "") + " " + str(r)).lower()
    # The honest contract: nowhere do we say something is proven.
    assert "proven" not in blob
    assert "verified" not in blob or "ready_for_lean_check" in blob


# ──────── search_corpus ────────

def test_search_corpus_no_filters_returns_truncated():
    r = search_corpus_tool(limit=3)
    assert r["ok"] is True
    assert r["n_total_corpus"] == 576
    assert r["n_total_match"] == 576
    assert r["n_returned"] == 3
    assert r["truncated"] is True
    assert len(r["results"]) == 3


def test_search_corpus_query_matches_expression():
    r = search_corpus_tool(query="cos", limit=20)
    assert r["ok"] is True
    assert r["n_total_match"] >= 1
    for row in r["results"]:
        assert ("cos" in row["expression"].lower()
                or "cos" in row["name"].lower())


def test_search_corpus_max_chain_order_filters():
    r = search_corpus_tool(max_chain_order=1, limit=50)
    assert r["ok"] is True
    for row in r["results"]:
        assert row["chain_order"] is not None
        assert row["chain_order"] <= 1


def test_search_corpus_includes_domains():
    r = search_corpus_tool(limit=1)
    assert "available_domains" in r
    assert len(r["available_domains"]) > 0


# ──────── genome ────────

def test_genome_via_expression():
    r = genome_tool(expression="exp(-z*t) * sin(omega*t)", k=3)
    assert r["ok"] is True
    assert r["n_returned"] <= 3
    assert all("name" in n for n in r["neighbours"])


def test_genome_via_source():
    r = genome_tool(source=_DAMPED, function_name="damped", k=2)
    assert r["ok"] is True
    assert r["n_returned"] <= 2


def test_genome_requires_one_input():
    r = genome_tool()
    assert r["ok"] is False
    r2 = genome_tool(expression="x", source=_DAMPED)
    assert r2["ok"] is False


def test_genome_unknown_function_name():
    r = genome_tool(source=_DAMPED, function_name="nonexistent")
    assert r["ok"] is False
    assert "nonexistent" in r["error"]


# ──────── explain_function ────────

def test_explain_function_default_uses_first():
    r = explain_function_tool(_DAMPED)
    assert r["ok"] is True
    assert r["function"] == "damped"


def test_explain_function_named():
    src = """module m;
fn alpha(x: Real) -> Real { x }
fn beta(x: Real) -> Real { x * x }
"""
    r = explain_function_tool(src, function_name="beta")
    assert r["ok"] is True
    assert r["function"] == "beta"


def test_explain_function_no_functions():
    r = explain_function_tool("module empty;")
    assert r["ok"] is False
    assert "no functions" in r["error"]


# ──────── list_targets ────────

def test_list_targets_counts():
    r = list_targets_tool()
    assert r["ok"] is True
    assert r["n_free"] == 12
    assert r["n_pro"] >= 19
    assert r["n_total"] == r["n_free"] + r["n_pro"]
    assert "verilog" in r["pro"]
    assert "python" in r["free"]


# ──────── list_verticals ────────

def test_list_verticals_returns_data():
    r = list_verticals_tool()
    assert r["ok"] is True
    # We expect at least a handful from a normal forge checkout.
    assert r["n_verticals"] >= 5
    # Each entry has the right shape.
    for v in r["verticals"]:
        assert "name" in v
        assert "kernel_count" in v
        assert v["kernel_count"] > 0
        assert "sample_kernels" in v


def test_list_verticals_total_matches_sum():
    r = list_verticals_tool()
    if r["n_verticals"] == 0:
        pytest.skip("no industries dir present")
    total = sum(v["kernel_count"] for v in r["verticals"])
    assert total == r["n_total_kernels"]


# ──────── decompile (eFrog) ────────


_PY_GAUSS = '''\
import math

def gauss(x: float, mu: float, sigma: float) -> float:
    a = (x - mu) / sigma
    return math.exp(-0.5 * a * a)
'''


_C_CIRCLE = '''\
double area(double r) {
    return 3.141592653589793 * r * r;
}
'''


def test_decompile_python_returns_eml_with_chain_order():
    pytest.importorskip("efrog")
    r = decompile_tool(_PY_GAUSS, "python")
    assert r["ok"] is True
    assert r["language"] == "python"
    assert r["n_functions"] == 1
    fn = r["functions"][0]
    assert fn["name"] == "gauss"
    # gauss has one exp() — chain order 1.
    assert fn["chain_order"] == 1
    assert fn["n_args"] == 3
    assert "fn gauss" in r["eml"]
    assert "where chain_order <= 1" in r["eml"]
    assert r["bytes"] > 0


def test_decompile_c_returns_eml():
    pytest.importorskip("efrog")
    r = decompile_tool(_C_CIRCLE, "c")
    assert r["ok"] is True
    assert r["language"] == "c"
    assert r["n_functions"] == 1
    fn = r["functions"][0]
    assert fn["name"] == "area"
    # Pure arithmetic -> chain 0.
    assert fn["chain_order"] == 0
    assert "fn area" in r["eml"]


def test_decompile_unknown_language_returns_structured_error():
    r = decompile_tool(_PY_GAUSS, "haskell")
    assert r["ok"] is False
    assert r["language"] == "haskell"
    assert "unsupported language" in r["error"]
    # Error must enumerate the valid choices so callers can self-correct.
    for valid in ("python", "c", "rust", "javascript", "matlab"):
        assert valid in r["error"]


def test_decompile_case_insensitive_language():
    pytest.importorskip("efrog")
    r = decompile_tool(_PY_GAUSS, "PYTHON")
    assert r["ok"] is True
    assert r["language"] == "python"


def test_decompile_python_syntax_error_returns_structured_error():
    pytest.importorskip("efrog")
    r = decompile_tool("def broken(:", "python")
    assert r["ok"] is False
    assert r["language"] == "python"
    assert "error" in r and r["error"]


def test_decompile_unsupported_python_construct_surfaces_efrog_error():
    pytest.importorskip("efrog")
    # Class bodies are explicitly out of scope per efrog/decompilers/python.py
    src = "class Foo:\n    pass\n"
    r = decompile_tool(src, "python")
    assert r["ok"] is False
    assert "EFrogError" in r["error"] or "not supported" in r["error"]
