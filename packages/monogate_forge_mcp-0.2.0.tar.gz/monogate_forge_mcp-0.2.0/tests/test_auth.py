"""Tests for forge_mcp/auth.py."""
from __future__ import annotations

import pytest

from forge_mcp.auth import (
    all_targets,
    free_targets,
    pro_targets,
    verify_license,
    verify_license_for_target,
)


def test_no_token_means_free_tier():
    d = verify_license(None)
    assert d.allowed is True
    assert d.tier == "Free"
    assert d.license is None


def test_empty_token_means_free_tier():
    d = verify_license("")
    assert d.allowed is True
    assert d.tier == "Free"


def test_invalid_token_fails_with_reason():
    d = verify_license("v1.garbage.junk")
    assert d.allowed is False
    assert "license invalid" in d.reason


def test_free_target_allowed_without_token():
    d = verify_license_for_target("python", None)
    assert d.allowed is True
    assert d.tier == "Free"


def test_free_target_allowed_with_invalid_token_short_circuits():
    d = verify_license_for_target("python", "v1.garbage.junk")
    assert d.allowed is False  # token failure trumps target tier
    assert "license invalid" in d.reason


def test_pro_target_refused_without_token():
    d = verify_license_for_target("verilog", None)
    assert d.allowed is False
    assert "Pro license" in d.reason
    assert "verilog" in d.reason


def test_free_targets_include_canonical_set():
    free = set(free_targets())
    expected = {"c", "cpp", "rust", "python", "javascript", "lean"}
    assert expected <= free, f"missing: {expected - free}"


def test_pro_targets_include_canonical_set():
    pro = set(pro_targets())
    expected = {"verilog", "vhdl", "hlsl", "metal", "swift", "solidity"}
    assert expected <= pro, f"missing: {expected - pro}"


def test_target_sets_disjoint():
    assert set(free_targets()) & set(pro_targets()) == set()


def test_all_targets_is_union_sorted():
    assert all_targets() == tuple(sorted(set(free_targets())
                                          | set(pro_targets())))
