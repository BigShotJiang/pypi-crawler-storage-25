from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    app_id: str,
    org_id: str,
    *,
    code: str,
    state: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["code"] = code

    params["state"] = state

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/apps/{app_id}/orgs/{org_id}/connections/facebook/callback".format(
            app_id=quote(str(app_id), safe=""),
            org_id=quote(str(org_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    org_id: str,
    *,
    client: AuthenticatedClient | Client,
    code: str,
    state: str,
) -> Response[HTTPValidationError | str]:
    """Org Connection Facebook Callback

     Handle Facebook org connection OAuth callback.

    Args:
        app_id (str):
        org_id (str):
        code (str): Authorization code from Facebook
        state (str): OAuth state parameter

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | str]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        org_id=org_id,
        code=code,
        state=state,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    org_id: str,
    *,
    client: AuthenticatedClient | Client,
    code: str,
    state: str,
) -> HTTPValidationError | str | None:
    """Org Connection Facebook Callback

     Handle Facebook org connection OAuth callback.

    Args:
        app_id (str):
        org_id (str):
        code (str): Authorization code from Facebook
        state (str): OAuth state parameter

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | str
    """

    return sync_detailed(
        app_id=app_id,
        org_id=org_id,
        client=client,
        code=code,
        state=state,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    org_id: str,
    *,
    client: AuthenticatedClient | Client,
    code: str,
    state: str,
) -> Response[HTTPValidationError | str]:
    """Org Connection Facebook Callback

     Handle Facebook org connection OAuth callback.

    Args:
        app_id (str):
        org_id (str):
        code (str): Authorization code from Facebook
        state (str): OAuth state parameter

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | str]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        org_id=org_id,
        code=code,
        state=state,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    org_id: str,
    *,
    client: AuthenticatedClient | Client,
    code: str,
    state: str,
) -> HTTPValidationError | str | None:
    """Org Connection Facebook Callback

     Handle Facebook org connection OAuth callback.

    Args:
        app_id (str):
        org_id (str):
        code (str): Authorization code from Facebook
        state (str): OAuth state parameter

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | str
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            org_id=org_id,
            client=client,
            code=code,
            state=state,
        )
    ).parsed
