from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    app_id: str,
    org_id: str,
    *,
    redirect_uri: str,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    params: dict[str, Any] = {}

    params["redirect_uri"] = redirect_uri

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/apps/{app_id}/orgs/{org_id}/connections/facebook/authorize".format(
            app_id=quote(str(app_id), safe=""),
            org_id=quote(str(org_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    org_id: str,
    *,
    client: AuthenticatedClient | Client,
    redirect_uri: str,
    authorization: str,
) -> Response[Any | HTTPValidationError]:
    """Org Connection Facebook Authorize

     Start Facebook OAuth flow to connect on behalf of an org.

    Args:
        app_id (str):
        org_id (str):
        redirect_uri (str): Final redirect URI after connection
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        org_id=org_id,
        redirect_uri=redirect_uri,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    org_id: str,
    *,
    client: AuthenticatedClient | Client,
    redirect_uri: str,
    authorization: str,
) -> Any | HTTPValidationError | None:
    """Org Connection Facebook Authorize

     Start Facebook OAuth flow to connect on behalf of an org.

    Args:
        app_id (str):
        org_id (str):
        redirect_uri (str): Final redirect URI after connection
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        app_id=app_id,
        org_id=org_id,
        client=client,
        redirect_uri=redirect_uri,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    org_id: str,
    *,
    client: AuthenticatedClient | Client,
    redirect_uri: str,
    authorization: str,
) -> Response[Any | HTTPValidationError]:
    """Org Connection Facebook Authorize

     Start Facebook OAuth flow to connect on behalf of an org.

    Args:
        app_id (str):
        org_id (str):
        redirect_uri (str): Final redirect URI after connection
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        org_id=org_id,
        redirect_uri=redirect_uri,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    org_id: str,
    *,
    client: AuthenticatedClient | Client,
    redirect_uri: str,
    authorization: str,
) -> Any | HTTPValidationError | None:
    """Org Connection Facebook Authorize

     Start Facebook OAuth flow to connect on behalf of an org.

    Args:
        app_id (str):
        org_id (str):
        redirect_uri (str): Final redirect URI after connection
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            org_id=org_id,
            client=client,
            redirect_uri=redirect_uri,
            authorization=authorization,
        )
    ).parsed
