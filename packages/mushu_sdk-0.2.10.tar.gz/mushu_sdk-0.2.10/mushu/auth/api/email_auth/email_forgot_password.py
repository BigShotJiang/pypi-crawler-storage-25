from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.email_forgot_password_request import EmailForgotPasswordRequest
from ...models.email_forgot_password_response_email_forgot_password import (
    EmailForgotPasswordResponseEmailForgotPassword,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: EmailForgotPasswordRequest,
    app_id: str | Unset = "app_platform",
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["app_id"] = app_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/auth/email/forgot-password",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EmailForgotPasswordResponseEmailForgotPassword.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: EmailForgotPasswordRequest,
    app_id: str | Unset = "app_platform",
) -> Response[EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError]:
    """Email Forgot Password

     Request a password reset email.

    Always returns 200 regardless of whether the email exists,
    to avoid leaking email existence.

    Args:
        app_id (str | Unset): App ID Default: 'app_platform'.
        body (EmailForgotPasswordRequest): Request to initiate password reset.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        app_id=app_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: EmailForgotPasswordRequest,
    app_id: str | Unset = "app_platform",
) -> EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError | None:
    """Email Forgot Password

     Request a password reset email.

    Always returns 200 regardless of whether the email exists,
    to avoid leaking email existence.

    Args:
        app_id (str | Unset): App ID Default: 'app_platform'.
        body (EmailForgotPasswordRequest): Request to initiate password reset.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
        app_id=app_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: EmailForgotPasswordRequest,
    app_id: str | Unset = "app_platform",
) -> Response[EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError]:
    """Email Forgot Password

     Request a password reset email.

    Always returns 200 regardless of whether the email exists,
    to avoid leaking email existence.

    Args:
        app_id (str | Unset): App ID Default: 'app_platform'.
        body (EmailForgotPasswordRequest): Request to initiate password reset.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        app_id=app_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: EmailForgotPasswordRequest,
    app_id: str | Unset = "app_platform",
) -> EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError | None:
    """Email Forgot Password

     Request a password reset email.

    Always returns 200 regardless of whether the email exists,
    to avoid leaking email existence.

    Args:
        app_id (str | Unset): App ID Default: 'app_platform'.
        body (EmailForgotPasswordRequest): Request to initiate password reset.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EmailForgotPasswordResponseEmailForgotPassword | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            app_id=app_id,
        )
    ).parsed
