from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.connection_service import ConnectionService
from ...models.http_validation_error import HTTPValidationError
from ...models.user_connection_response import UserConnectionResponse
from ...types import Response


def _get_kwargs(
    service: ConnectionService,
    *,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/connections/me/{service}".format(
            service=quote(str(service), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | UserConnectionResponse | None:
    if response.status_code == 200:
        response_200 = UserConnectionResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | UserConnectionResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> Response[HTTPValidationError | UserConnectionResponse]:
    """Get My Connection

     Get a specific connection for the current user.

    Args:
        service (ConnectionService): Supported connection service types.
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UserConnectionResponse]
    """

    kwargs = _get_kwargs(
        service=service,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> HTTPValidationError | UserConnectionResponse | None:
    """Get My Connection

     Get a specific connection for the current user.

    Args:
        service (ConnectionService): Supported connection service types.
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UserConnectionResponse
    """

    return sync_detailed(
        service=service,
        client=client,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> Response[HTTPValidationError | UserConnectionResponse]:
    """Get My Connection

     Get a specific connection for the current user.

    Args:
        service (ConnectionService): Supported connection service types.
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UserConnectionResponse]
    """

    kwargs = _get_kwargs(
        service=service,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    authorization: str,
) -> HTTPValidationError | UserConnectionResponse | None:
    """Get My Connection

     Get a specific connection for the current user.

    Args:
        service (ConnectionService): Supported connection service types.
        authorization (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UserConnectionResponse
    """

    return (
        await asyncio_detailed(
            service=service,
            client=client,
            authorization=authorization,
        )
    ).parsed
