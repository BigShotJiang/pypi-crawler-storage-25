from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.connection_config_response import ConnectionConfigResponse
from ...models.connection_service import ConnectionService
from ...models.http_validation_error import HTTPValidationError
from ...models.update_connection_config_request import UpdateConnectionConfigRequest
from ...types import Response


def _get_kwargs(
    app_id: str,
    service: ConnectionService,
    *,
    body: UpdateConnectionConfigRequest,
    authorization: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["authorization"] = authorization

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/apps/{app_id}/connections/{service}".format(
            app_id=quote(str(app_id), safe=""),
            service=quote(str(service), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ConnectionConfigResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ConnectionConfigResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ConnectionConfigResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConnectionConfigRequest,
    authorization: str,
) -> Response[ConnectionConfigResponse | HTTPValidationError]:
    """Update Connection Config

     Update a connection config.

    Args:
        app_id (str):
        service (ConnectionService): Supported connection service types.
        authorization (str):
        body (UpdateConnectionConfigRequest): Request to update a connection config.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConnectionConfigResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        service=service,
        body=body,
        authorization=authorization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConnectionConfigRequest,
    authorization: str,
) -> ConnectionConfigResponse | HTTPValidationError | None:
    """Update Connection Config

     Update a connection config.

    Args:
        app_id (str):
        service (ConnectionService): Supported connection service types.
        authorization (str):
        body (UpdateConnectionConfigRequest): Request to update a connection config.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConnectionConfigResponse | HTTPValidationError
    """

    return sync_detailed(
        app_id=app_id,
        service=service,
        client=client,
        body=body,
        authorization=authorization,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConnectionConfigRequest,
    authorization: str,
) -> Response[ConnectionConfigResponse | HTTPValidationError]:
    """Update Connection Config

     Update a connection config.

    Args:
        app_id (str):
        service (ConnectionService): Supported connection service types.
        authorization (str):
        body (UpdateConnectionConfigRequest): Request to update a connection config.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConnectionConfigResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        service=service,
        body=body,
        authorization=authorization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    service: ConnectionService,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConnectionConfigRequest,
    authorization: str,
) -> ConnectionConfigResponse | HTTPValidationError | None:
    """Update Connection Config

     Update a connection config.

    Args:
        app_id (str):
        service (ConnectionService): Supported connection service types.
        authorization (str):
        body (UpdateConnectionConfigRequest): Request to update a connection config.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConnectionConfigResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            service=service,
            client=client,
            body=body,
            authorization=authorization,
        )
    ).parsed
