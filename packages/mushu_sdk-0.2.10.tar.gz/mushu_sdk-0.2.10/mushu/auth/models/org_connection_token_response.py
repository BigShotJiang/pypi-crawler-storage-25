from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.connection_service import ConnectionService
from ..types import UNSET, Unset

T = TypeVar("T", bound="OrgConnectionTokenResponse")


@_attrs_define
class OrgConnectionTokenResponse:
    """Response containing an org connection's access token.

    Attributes:
        connection_id (str): Connection ID
        service (ConnectionService): Supported connection service types.
        access_token (str): Access token for API calls
        status (str): Connection status
        token_expires_at (None | str | Unset): ISO timestamp of token expiry
    """

    connection_id: str
    service: ConnectionService
    access_token: str
    status: str
    token_expires_at: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        connection_id = self.connection_id

        service = self.service.value

        access_token = self.access_token

        status = self.status

        token_expires_at: None | str | Unset
        if isinstance(self.token_expires_at, Unset):
            token_expires_at = UNSET
        else:
            token_expires_at = self.token_expires_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "connection_id": connection_id,
                "service": service,
                "access_token": access_token,
                "status": status,
            }
        )
        if token_expires_at is not UNSET:
            field_dict["token_expires_at"] = token_expires_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        connection_id = d.pop("connection_id")

        service = ConnectionService(d.pop("service"))

        access_token = d.pop("access_token")

        status = d.pop("status")

        def _parse_token_expires_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        token_expires_at = _parse_token_expires_at(d.pop("token_expires_at", UNSET))

        org_connection_token_response = cls(
            connection_id=connection_id,
            service=service,
            access_token=access_token,
            status=status,
            token_expires_at=token_expires_at,
        )

        org_connection_token_response.additional_properties = d
        return org_connection_token_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
