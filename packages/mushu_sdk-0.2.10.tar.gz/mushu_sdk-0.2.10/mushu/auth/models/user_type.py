from enum import Enum


class UserType(str, Enum):
    APPLE = "apple"
    EMAIL = "email"
    FACEBOOK = "facebook"
    GOOGLE = "google"

    def __str__(self) -> str:
        return str(self.value)
