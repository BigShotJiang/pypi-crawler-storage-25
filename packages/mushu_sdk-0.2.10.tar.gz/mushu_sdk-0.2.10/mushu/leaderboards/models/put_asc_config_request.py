from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="PutASCConfigRequest")


@_attrs_define
class PutASCConfigRequest:
    """Request to store ASC credentials.

    Attributes:
        issuer_id (str):
        key_id (str):
        private_key (str): ES256 private key (PEM)
    """

    issuer_id: str
    key_id: str
    private_key: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        issuer_id = self.issuer_id

        key_id = self.key_id

        private_key = self.private_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "issuer_id": issuer_id,
                "key_id": key_id,
                "private_key": private_key,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        issuer_id = d.pop("issuer_id")

        key_id = d.pop("key_id")

        private_key = d.pop("private_key")

        put_asc_config_request = cls(
            issuer_id=issuer_id,
            key_id=key_id,
            private_key=private_key,
        )

        put_asc_config_request.additional_properties = d
        return put_asc_config_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
