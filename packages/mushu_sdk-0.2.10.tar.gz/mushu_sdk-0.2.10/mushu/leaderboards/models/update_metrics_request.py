from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.update_metrics_request_metrics import UpdateMetricsRequestMetrics


T = TypeVar("T", bound="UpdateMetricsRequest")


@_attrs_define
class UpdateMetricsRequest:
    """Request to update user metrics.

    Attributes:
        metrics (UpdateMetricsRequestMetrics): Metric name → value
        mode (str | Unset): set: replace values, increment: add to existing Default: 'increment'.
    """

    metrics: UpdateMetricsRequestMetrics
    mode: str | Unset = "increment"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        metrics = self.metrics.to_dict()

        mode = self.mode

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "metrics": metrics,
            }
        )
        if mode is not UNSET:
            field_dict["mode"] = mode

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.update_metrics_request_metrics import UpdateMetricsRequestMetrics

        d = dict(src_dict)
        metrics = UpdateMetricsRequestMetrics.from_dict(d.pop("metrics"))

        mode = d.pop("mode", UNSET)

        update_metrics_request = cls(
            metrics=metrics,
            mode=mode,
        )

        update_metrics_request.additional_properties = d
        return update_metrics_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
