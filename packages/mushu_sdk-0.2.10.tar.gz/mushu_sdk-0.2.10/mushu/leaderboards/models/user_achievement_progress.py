from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="UserAchievementProgress")


@_attrs_define
class UserAchievementProgress:
    """User's progress toward an achievement.

    Attributes:
        achievement_id (str):
        user_id (str):
        unlocked (bool):
        unlocked_at (datetime.datetime | None | Unset):
        current_tier (None | str | Unset):
    """

    achievement_id: str
    user_id: str
    unlocked: bool
    unlocked_at: datetime.datetime | None | Unset = UNSET
    current_tier: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        achievement_id = self.achievement_id

        user_id = self.user_id

        unlocked = self.unlocked

        unlocked_at: None | str | Unset
        if isinstance(self.unlocked_at, Unset):
            unlocked_at = UNSET
        elif isinstance(self.unlocked_at, datetime.datetime):
            unlocked_at = self.unlocked_at.isoformat()
        else:
            unlocked_at = self.unlocked_at

        current_tier: None | str | Unset
        if isinstance(self.current_tier, Unset):
            current_tier = UNSET
        else:
            current_tier = self.current_tier

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "achievement_id": achievement_id,
                "user_id": user_id,
                "unlocked": unlocked,
            }
        )
        if unlocked_at is not UNSET:
            field_dict["unlocked_at"] = unlocked_at
        if current_tier is not UNSET:
            field_dict["current_tier"] = current_tier

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        achievement_id = d.pop("achievement_id")

        user_id = d.pop("user_id")

        unlocked = d.pop("unlocked")

        def _parse_unlocked_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                unlocked_at_type_0 = isoparse(data)

                return unlocked_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        unlocked_at = _parse_unlocked_at(d.pop("unlocked_at", UNSET))

        def _parse_current_tier(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        current_tier = _parse_current_tier(d.pop("current_tier", UNSET))

        user_achievement_progress = cls(
            achievement_id=achievement_id,
            user_id=user_id,
            unlocked=unlocked,
            unlocked_at=unlocked_at,
            current_tier=current_tier,
        )

        user_achievement_progress.additional_properties = d
        return user_achievement_progress

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
