from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.achievement_tier import AchievementTier
    from ..models.unlock_condition import UnlockCondition


T = TypeVar("T", bound="CreateAchievementRequest")


@_attrs_define
class CreateAchievementRequest:
    """Request to create an achievement definition.

    Attributes:
        achievement_id (str): Achievement ID
        name (str):
        conditions (list[UnlockCondition]): All conditions must be met for unlock
        description (str | Unset):  Default: ''.
        icon_url (None | str | Unset):
        categories (list[str] | Unset):
        tiers (list[AchievementTier] | None | Unset):
    """

    achievement_id: str
    name: str
    conditions: list[UnlockCondition]
    description: str | Unset = ""
    icon_url: None | str | Unset = UNSET
    categories: list[str] | Unset = UNSET
    tiers: list[AchievementTier] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        achievement_id = self.achievement_id

        name = self.name

        conditions = []
        for conditions_item_data in self.conditions:
            conditions_item = conditions_item_data.to_dict()
            conditions.append(conditions_item)

        description = self.description

        icon_url: None | str | Unset
        if isinstance(self.icon_url, Unset):
            icon_url = UNSET
        else:
            icon_url = self.icon_url

        categories: list[str] | Unset = UNSET
        if not isinstance(self.categories, Unset):
            categories = self.categories

        tiers: list[dict[str, Any]] | None | Unset
        if isinstance(self.tiers, Unset):
            tiers = UNSET
        elif isinstance(self.tiers, list):
            tiers = []
            for tiers_type_0_item_data in self.tiers:
                tiers_type_0_item = tiers_type_0_item_data.to_dict()
                tiers.append(tiers_type_0_item)

        else:
            tiers = self.tiers

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "achievement_id": achievement_id,
                "name": name,
                "conditions": conditions,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if icon_url is not UNSET:
            field_dict["icon_url"] = icon_url
        if categories is not UNSET:
            field_dict["categories"] = categories
        if tiers is not UNSET:
            field_dict["tiers"] = tiers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.achievement_tier import AchievementTier
        from ..models.unlock_condition import UnlockCondition

        d = dict(src_dict)
        achievement_id = d.pop("achievement_id")

        name = d.pop("name")

        conditions = []
        _conditions = d.pop("conditions")
        for conditions_item_data in _conditions:
            conditions_item = UnlockCondition.from_dict(conditions_item_data)

            conditions.append(conditions_item)

        description = d.pop("description", UNSET)

        def _parse_icon_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        icon_url = _parse_icon_url(d.pop("icon_url", UNSET))

        categories = cast(list[str], d.pop("categories", UNSET))

        def _parse_tiers(data: object) -> list[AchievementTier] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tiers_type_0 = []
                _tiers_type_0 = data
                for tiers_type_0_item_data in _tiers_type_0:
                    tiers_type_0_item = AchievementTier.from_dict(tiers_type_0_item_data)

                    tiers_type_0.append(tiers_type_0_item)

                return tiers_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[AchievementTier] | None | Unset, data)

        tiers = _parse_tiers(d.pop("tiers", UNSET))

        create_achievement_request = cls(
            achievement_id=achievement_id,
            name=name,
            conditions=conditions,
            description=description,
            icon_url=icon_url,
            categories=categories,
            tiers=tiers,
        )

        create_achievement_request.additional_properties = d
        return create_achievement_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
