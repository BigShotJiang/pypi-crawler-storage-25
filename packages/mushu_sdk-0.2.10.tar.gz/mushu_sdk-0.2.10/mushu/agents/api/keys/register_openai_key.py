from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.register_key_request import RegisterKeyRequest
from ...models.register_key_response import RegisterKeyResponse
from ...types import Response


def _get_kwargs(
    *,
    body: RegisterKeyRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/keys/openai",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | RegisterKeyResponse | None:
    if response.status_code == 200:
        response_200 = RegisterKeyResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | RegisterKeyResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterKeyRequest,
) -> Response[HTTPValidationError | RegisterKeyResponse]:
    """Register Openai Key

     Register or update the tenant's OpenAI API key.

    Stores the key as an SSM SecureString (free tier, encrypted at rest).
    The worker Lambda fetches it at cold start via the path stored in DynamoDB.
    The key value is never stored in DynamoDB — only the SSM path pointer.

    Args:
        body (RegisterKeyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RegisterKeyResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterKeyRequest,
) -> HTTPValidationError | RegisterKeyResponse | None:
    """Register Openai Key

     Register or update the tenant's OpenAI API key.

    Stores the key as an SSM SecureString (free tier, encrypted at rest).
    The worker Lambda fetches it at cold start via the path stored in DynamoDB.
    The key value is never stored in DynamoDB — only the SSM path pointer.

    Args:
        body (RegisterKeyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RegisterKeyResponse
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterKeyRequest,
) -> Response[HTTPValidationError | RegisterKeyResponse]:
    """Register Openai Key

     Register or update the tenant's OpenAI API key.

    Stores the key as an SSM SecureString (free tier, encrypted at rest).
    The worker Lambda fetches it at cold start via the path stored in DynamoDB.
    The key value is never stored in DynamoDB — only the SSM path pointer.

    Args:
        body (RegisterKeyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RegisterKeyResponse]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: RegisterKeyRequest,
) -> HTTPValidationError | RegisterKeyResponse | None:
    """Register Openai Key

     Register or update the tenant's OpenAI API key.

    Stores the key as an SSM SecureString (free tier, encrypted at rest).
    The worker Lambda fetches it at cold start via the path stored in DynamoDB.
    The key value is never stored in DynamoDB — only the SSM path pointer.

    Args:
        body (RegisterKeyRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RegisterKeyResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
