from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="RunCreateRequest")


@_attrs_define
class RunCreateRequest:
    """
    Attributes:
        user_id (str):
        workflow (Literal['food-log']):
        media_url (str):
    """

    user_id: str
    workflow: Literal["food-log"]
    media_url: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        workflow = self.workflow

        media_url = self.media_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "user_id": user_id,
                "workflow": workflow,
                "media_url": media_url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("user_id")

        workflow = cast(Literal["food-log"], d.pop("workflow"))
        if workflow != "food-log":
            raise ValueError(f"workflow must match const 'food-log', got '{workflow}'")

        media_url = d.pop("media_url")

        run_create_request = cls(
            user_id=user_id,
            workflow=workflow,
            media_url=media_url,
        )

        run_create_request.additional_properties = d
        return run_create_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
