from enum import Enum


class RunStatusResponseStatus(str, Enum):
    COMPLETE = "complete"
    FAILED = "failed"
    PENDING = "pending"
    RUNNING = "running"

    def __str__(self) -> str:
        return str(self.value)
