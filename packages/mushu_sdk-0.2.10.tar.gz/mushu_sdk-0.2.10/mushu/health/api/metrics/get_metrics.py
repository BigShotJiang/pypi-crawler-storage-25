from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_metrics_response import GetMetricsResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_id: str,
    user_id: str,
    *,
    metrics: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    days: int | None | Unset = UNSET,
    x_api_key: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    headers["x-api-key"] = x_api_key

    params: dict[str, Any] = {}

    json_metrics: None | str | Unset
    if isinstance(metrics, Unset):
        json_metrics = UNSET
    else:
        json_metrics = metrics
    params["metrics"] = json_metrics

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_days: int | None | Unset
    if isinstance(days, Unset):
        json_days = UNSET
    else:
        json_days = days
    params["days"] = json_days

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/apps/{app_id}/metrics/{user_id}".format(
            app_id=quote(str(app_id), safe=""),
            user_id=quote(str(user_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetMetricsResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = GetMetricsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetMetricsResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    metrics: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    days: int | None | Unset = UNSET,
    x_api_key: str,
) -> Response[GetMetricsResponse | HTTPValidationError]:
    """Get Metrics

     Query health metrics for a user within a date range.

    Args:
        app_id (str):
        user_id (str):
        metrics (None | str | Unset): Comma-separated metric names
        start_date (None | str | Unset): Start date (YYYY-MM-DD)
        end_date (None | str | Unset): End date (YYYY-MM-DD)
        days (int | None | Unset): Number of days back from today
        x_api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetMetricsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        metrics=metrics,
        start_date=start_date,
        end_date=end_date,
        days=days,
        x_api_key=x_api_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    metrics: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    days: int | None | Unset = UNSET,
    x_api_key: str,
) -> GetMetricsResponse | HTTPValidationError | None:
    """Get Metrics

     Query health metrics for a user within a date range.

    Args:
        app_id (str):
        user_id (str):
        metrics (None | str | Unset): Comma-separated metric names
        start_date (None | str | Unset): Start date (YYYY-MM-DD)
        end_date (None | str | Unset): End date (YYYY-MM-DD)
        days (int | None | Unset): Number of days back from today
        x_api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetMetricsResponse | HTTPValidationError
    """

    return sync_detailed(
        app_id=app_id,
        user_id=user_id,
        client=client,
        metrics=metrics,
        start_date=start_date,
        end_date=end_date,
        days=days,
        x_api_key=x_api_key,
    ).parsed


async def asyncio_detailed(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    metrics: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    days: int | None | Unset = UNSET,
    x_api_key: str,
) -> Response[GetMetricsResponse | HTTPValidationError]:
    """Get Metrics

     Query health metrics for a user within a date range.

    Args:
        app_id (str):
        user_id (str):
        metrics (None | str | Unset): Comma-separated metric names
        start_date (None | str | Unset): Start date (YYYY-MM-DD)
        end_date (None | str | Unset): End date (YYYY-MM-DD)
        days (int | None | Unset): Number of days back from today
        x_api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetMetricsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app_id=app_id,
        user_id=user_id,
        metrics=metrics,
        start_date=start_date,
        end_date=end_date,
        days=days,
        x_api_key=x_api_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_id: str,
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    metrics: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    days: int | None | Unset = UNSET,
    x_api_key: str,
) -> GetMetricsResponse | HTTPValidationError | None:
    """Get Metrics

     Query health metrics for a user within a date range.

    Args:
        app_id (str):
        user_id (str):
        metrics (None | str | Unset): Comma-separated metric names
        start_date (None | str | Unset): Start date (YYYY-MM-DD)
        end_date (None | str | Unset): End date (YYYY-MM-DD)
        days (int | None | Unset): Number of days back from today
        x_api_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetMetricsResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            app_id=app_id,
            user_id=user_id,
            client=client,
            metrics=metrics,
            start_date=start_date,
            end_date=end_date,
            days=days,
            x_api_key=x_api_key,
        )
    ).parsed
