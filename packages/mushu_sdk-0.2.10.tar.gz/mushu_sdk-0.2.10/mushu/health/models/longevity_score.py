from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.longevity_score_sub_scores import LongevityScoreSubScores
    from ..models.longevity_score_targets import LongevityScoreTargets


T = TypeVar("T", bound="LongevityScore")


@_attrs_define
class LongevityScore:
    """
    Attributes:
        composite (float):
        sub_scores (LongevityScoreSubScores):
        age (int | None | Unset):
        sex (None | str | Unset):
        targets (LongevityScoreTargets | Unset):
    """

    composite: float
    sub_scores: LongevityScoreSubScores
    age: int | None | Unset = UNSET
    sex: None | str | Unset = UNSET
    targets: LongevityScoreTargets | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        composite = self.composite

        sub_scores = self.sub_scores.to_dict()

        age: int | None | Unset
        if isinstance(self.age, Unset):
            age = UNSET
        else:
            age = self.age

        sex: None | str | Unset
        if isinstance(self.sex, Unset):
            sex = UNSET
        else:
            sex = self.sex

        targets: dict[str, Any] | Unset = UNSET
        if not isinstance(self.targets, Unset):
            targets = self.targets.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "composite": composite,
                "sub_scores": sub_scores,
            }
        )
        if age is not UNSET:
            field_dict["age"] = age
        if sex is not UNSET:
            field_dict["sex"] = sex
        if targets is not UNSET:
            field_dict["targets"] = targets

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.longevity_score_sub_scores import LongevityScoreSubScores
        from ..models.longevity_score_targets import LongevityScoreTargets

        d = dict(src_dict)
        composite = d.pop("composite")

        sub_scores = LongevityScoreSubScores.from_dict(d.pop("sub_scores"))

        def _parse_age(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        age = _parse_age(d.pop("age", UNSET))

        def _parse_sex(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sex = _parse_sex(d.pop("sex", UNSET))

        _targets = d.pop("targets", UNSET)
        targets: LongevityScoreTargets | Unset
        if isinstance(_targets, Unset):
            targets = UNSET
        else:
            targets = LongevityScoreTargets.from_dict(_targets)

        longevity_score = cls(
            composite=composite,
            sub_scores=sub_scores,
            age=age,
            sex=sex,
            targets=targets,
        )

        longevity_score.additional_properties = d
        return longevity_score

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
