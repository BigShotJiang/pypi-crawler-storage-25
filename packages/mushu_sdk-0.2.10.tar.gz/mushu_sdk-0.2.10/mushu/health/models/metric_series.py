from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="MetricSeries")


@_attrs_define
class MetricSeries:
    """
    Attributes:
        metric (str):
        points (list[list[float | str]]):
        unit (None | str | Unset):
    """

    metric: str
    points: list[list[float | str]]
    unit: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        metric = self.metric

        points = []
        for points_item_data in self.points:
            points_item = []
            for points_item_item_data in points_item_data:
                points_item_item: float | str
                points_item_item = points_item_item_data
                points_item.append(points_item_item)

            points.append(points_item)

        unit: None | str | Unset
        if isinstance(self.unit, Unset):
            unit = UNSET
        else:
            unit = self.unit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "metric": metric,
                "points": points,
            }
        )
        if unit is not UNSET:
            field_dict["unit"] = unit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        metric = d.pop("metric")

        points = []
        _points = d.pop("points")
        for points_item_data in _points:
            points_item = []
            _points_item = points_item_data
            for points_item_item_data in _points_item:

                def _parse_points_item_item(data: object) -> float | str:
                    return cast(float | str, data)

                points_item_item = _parse_points_item_item(points_item_item_data)

                points_item.append(points_item_item)

            points.append(points_item)

        def _parse_unit(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        unit = _parse_unit(d.pop("unit", UNSET))

        metric_series = cls(
            metric=metric,
            points=points,
            unit=unit,
        )

        metric_series.additional_properties = d
        return metric_series

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
