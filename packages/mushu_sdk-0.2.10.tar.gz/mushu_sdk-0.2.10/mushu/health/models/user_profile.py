from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UserProfile")


@_attrs_define
class UserProfile:
    """
    Attributes:
        date_of_birth (None | str | Unset):
        biological_sex (None | str | Unset):
        height_m (float | None | Unset):
    """

    date_of_birth: None | str | Unset = UNSET
    biological_sex: None | str | Unset = UNSET
    height_m: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date_of_birth: None | str | Unset
        if isinstance(self.date_of_birth, Unset):
            date_of_birth = UNSET
        else:
            date_of_birth = self.date_of_birth

        biological_sex: None | str | Unset
        if isinstance(self.biological_sex, Unset):
            biological_sex = UNSET
        else:
            biological_sex = self.biological_sex

        height_m: float | None | Unset
        if isinstance(self.height_m, Unset):
            height_m = UNSET
        else:
            height_m = self.height_m

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if date_of_birth is not UNSET:
            field_dict["date_of_birth"] = date_of_birth
        if biological_sex is not UNSET:
            field_dict["biological_sex"] = biological_sex
        if height_m is not UNSET:
            field_dict["height_m"] = height_m

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_date_of_birth(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        date_of_birth = _parse_date_of_birth(d.pop("date_of_birth", UNSET))

        def _parse_biological_sex(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        biological_sex = _parse_biological_sex(d.pop("biological_sex", UNSET))

        def _parse_height_m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        height_m = _parse_height_m(d.pop("height_m", UNSET))

        user_profile = cls(
            date_of_birth=date_of_birth,
            biological_sex=biological_sex,
            height_m=height_m,
        )

        user_profile.additional_properties = d
        return user_profile

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
