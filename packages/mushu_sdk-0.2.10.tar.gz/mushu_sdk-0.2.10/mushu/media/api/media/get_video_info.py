from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.video_variants_response import VideoVariantsResponse
from ...types import Response


def _get_kwargs(
    media_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/media/{media_id}/video".format(
            media_id=quote(str(media_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | VideoVariantsResponse | None:
    if response.status_code == 200:
        response_200 = VideoVariantsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | VideoVariantsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    media_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | VideoVariantsResponse]:
    """Get Video Info

     Get video processing status and variant URLs.

    Returns URLs for all available video variants once processing is complete.
    Videos are served as static MP4/WebM files for direct download/playback.

    Args:
        media_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VideoVariantsResponse]
    """

    kwargs = _get_kwargs(
        media_id=media_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    media_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | VideoVariantsResponse | None:
    """Get Video Info

     Get video processing status and variant URLs.

    Returns URLs for all available video variants once processing is complete.
    Videos are served as static MP4/WebM files for direct download/playback.

    Args:
        media_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VideoVariantsResponse
    """

    return sync_detailed(
        media_id=media_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    media_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[HTTPValidationError | VideoVariantsResponse]:
    """Get Video Info

     Get video processing status and variant URLs.

    Returns URLs for all available video variants once processing is complete.
    Videos are served as static MP4/WebM files for direct download/playback.

    Args:
        media_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VideoVariantsResponse]
    """

    kwargs = _get_kwargs(
        media_id=media_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    media_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> HTTPValidationError | VideoVariantsResponse | None:
    """Get Video Info

     Get video processing status and variant URLs.

    Returns URLs for all available video variants once processing is complete.
    Videos are served as static MP4/WebM files for direct download/playback.

    Args:
        media_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VideoVariantsResponse
    """

    return (
        await asyncio_detailed(
            media_id=media_id,
            client=client,
        )
    ).parsed
