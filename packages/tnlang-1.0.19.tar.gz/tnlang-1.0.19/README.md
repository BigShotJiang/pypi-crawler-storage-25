# TNLang

A simple programming language that runs via Python.

## Installation

```bash
pip install TNLang
```

## Quick Start

Create a `.tnlang` file:

```tnlang
echo("Hello World!")
```

Then run it with Python:

```python
import TNLang

TNLang.launch("program.tnlang")
```

## Functions

| Function | Description |
|----------|-------------|
| `echo("text")` | Print text to console |
| `wait(1)` | Wait X seconds |
| `loop.10(echo("text"))` | Repeat an action 1-100 times |

## Packages

### colors
```tnlang
importPackage colors
echo.red("Red text!")
echo.green("Green text!")
echo.blue("Blue text!")
echo.yellow("Yellow text!")
echo.cyan("Cyan text!")
echo.magenta("Magenta text!")
echo.white("White text!")
```

### DiscordWebHook
```tnlang
importPackage DiscordWebHook
discord.webhook("webhook-url", "Message with\nnew line")
```

### DiscordBot
```tnlang
importPackage DiscordBot
discordBot.config("intents=ALL", "command_prefix=!")
discordBot.run("your-bot-token")
```

## Examples

### Hello World
```tnlang
echo("Hello World!")
```

### Countdown
```tnlang
echo("3")
wait(1)
echo("2")
wait(1)
echo("1")
wait(1)
echo("Done.")
```

### Loop with colors
```tnlang
importPackage colors
loop.5(echo.red("Loop!"))
echo.green("Done!")
```

## License

MIT