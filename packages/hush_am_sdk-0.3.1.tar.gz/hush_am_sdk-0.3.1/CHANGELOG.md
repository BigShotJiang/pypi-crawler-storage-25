# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.1] - 2026-05-24

### Fixed

- `HushClient` no longer fails on the second TCP connection after an SVID rotation. ALPN is now baked into the SPIFFE SSL context at build time, and `set_alpn_protocols` is a no-op so httpcore's repeated calls don't mutate an already-used pyOpenSSL context.

## [0.3.0] - 2026-05-11

### Changed

- Renamed the Python module from `hush` to `husham`.

### Added

- CI checks for Linear PR history and issue links.

## [0.2.0] - 2026-05-07

### Added

- `workflow_dispatch` trigger on the PyPI publish workflow.

### Changed

- README trimmed to user-facing information only.

## [0.1.0] - 2026-05-06

### Added

- Initial Python SDK for the Hush Access Management service.
- `husham.HushClient` for fetching short-lived secrets via SPIFFE workload identity.
- Process-wide singleton accessor (`husham.get_client`) and module-level helpers (`husham.get_secret`, `husham.get_secret_field`).
- GitHub Actions for CI and PyPI publish.
