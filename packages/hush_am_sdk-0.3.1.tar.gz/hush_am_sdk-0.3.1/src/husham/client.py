from __future__ import annotations
import logging
import os
import ssl
import urllib.parse
import weakref
import httpx
from spiffe import SpiffeId
from spiffe.workloadapi.x509_source import X509Source
from husham._spiffe_tls import _AuthorizingSpiffeSSLContext
from husham.exceptions import (
    HushAuthError,
    HushBadRequestError,
    HushConfigError,
    HushFieldNotFoundError,
    HushNetworkError,
    HushSecretNotFoundError,
    HushServerError,
    HushSpiffeError,
)

LOG = logging.getLogger(__name__)


class _SuppressSpiffeCancelledFilter(logging.Filter):
    """Drop pyspiffe's "X509 Source Error: ... CANCELLED" log emitted when
    the Workload API stream is cancelled during normal source shutdown."""

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        return not ("X509 Source Error" in msg and "CANCELLED" in msg)


logging.getLogger("spiffe.workloadapi.x509_source").addFilter(
    _SuppressSpiffeCancelledFilter()
)

# Path component of the simba server's SPIFFE ID, mirroring the Go SDK
# (mufasa/internal/simba/options.go:ServerSpiffeID).
SERVER_SPIFFE_PATH = "/hush/simba/server"

HEADER_POLICY_SNAPSHOT = "X-Hush-Policy-Snapshot"


def _required_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise HushConfigError(f"{name} env var is required")
    return value


def _server_spiffe_id(trust_domain: str) -> SpiffeId:
    return SpiffeId(f"spiffe://{trust_domain}{SERVER_SPIFFE_PATH}")


def _server_url(address: str) -> str:
    if address.startswith("http://") or address.startswith("https://"):
        return address.rstrip("/")
    return f"https://{address}".rstrip("/")


def _close_resources(http_client: httpx.Client, x509_source: X509Source) -> None:
    http_client.close()
    x509_source.close()


def _is_tls_error(exc: BaseException) -> bool:
    cur: BaseException | None = exc
    while cur is not None:
        if isinstance(cur, ssl.SSLError):
            return True
        cur = cur.__cause__ or cur.__context__
    return False


class HushClient:
    """Hush SDK client using SPIFFE mTLS for workload authentication.

    All configuration is read from environment variables populated by the
    mufasa injector; there are no constructor knobs.
    """

    def __init__(self) -> None:
        self.server = _server_url(_required_env("_HUSH_INJECTOR_SERVER_ADDRESS"))
        self.spiffe_socket = _required_env("_HUSH_INJECTOR_SPIRE_AGENT_SOCKET_PATH")
        self.policy_snapshot = _required_env("_HUSH_INJECTOR_POLICY_SNAPSHOT")
        self.trust_domain = _required_env("_HUSH_INJECTOR_TRUST_DOMAIN")
        self.server_spiffe_id = _server_spiffe_id(self.trust_domain)

        LOG.debug("Connecting to SPIFFE Workload API at %s", self.spiffe_socket)
        try:
            self._x509_source = X509Source(socket_path=self.spiffe_socket)
        except Exception as exc:
            raise HushSpiffeError(
                f"failed to obtain SVID from SPIRE Workload API at "
                f"{self.spiffe_socket}: {exc}"
            ) from exc
        try:
            self._ssl_ctx = _AuthorizingSpiffeSSLContext(
                self._x509_source, self.server_spiffe_id
            )
            self._http_client = httpx.Client(verify=self._ssl_ctx, timeout=30.0)
        except Exception as exc:
            self._x509_source.close()
            raise HushSpiffeError(
                f"failed to build SPIFFE SSL context for {self.server_spiffe_id}: {exc}"
            ) from exc
        except BaseException:
            self._x509_source.close()
            raise

        # Backstop: if the caller forgets `with`, this releases the SPIRE
        # connection + watcher thread on GC or interpreter shutdown.
        self._finalizer = weakref.finalize(
            self, _close_resources, self._http_client, self._x509_source
        )

    def _common_headers(self, token: str = "") -> dict:
        headers = {
            "Content-Type": "application/json",
            HEADER_POLICY_SNAPSHOT: self.policy_snapshot,
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _validate_secret_request(self, secret_name: str) -> None:
        if not secret_name:
            raise ValueError("secret_name is required")

    def _get(self, url: str, headers: dict) -> httpx.Response:
        try:
            return self._http_client.get(url, headers=headers)
        except httpx.RequestError as exc:
            if _is_tls_error(exc):
                raise HushAuthError(
                    f"mTLS handshake failed contacting {self.server}: {exc}"
                ) from exc
            raise HushNetworkError(
                f"network error contacting {self.server}: {exc}"
            ) from exc

    def _check_status(
        self, resp: httpx.Response, secret_name: str, field: str | None = None
    ) -> None:
        if resp.is_success:
            return
        sc = resp.status_code
        try:
            body = resp.json()
        except ValueError:
            body = None
        if isinstance(body, dict):
            message = str(body.get("Message") or body.get("message") or "")[:500]
        else:
            message = resp.text[:500]
        if sc == 400:
            raise HushBadRequestError(message or "bad request")
        if sc == 404:
            if field is not None and "secret key not found" in message:
                raise HushFieldNotFoundError(secret_name, field)
            raise HushSecretNotFoundError(secret_name)
        raise HushServerError(sc, message)

    def get_secret(self, secret_name: str, token: str = "") -> dict:
        """Fetch a secret's full key-value map from /getsecret/:secret_name."""
        self._validate_secret_request(secret_name)
        url = f"{self.server}/getsecret/{urllib.parse.quote(secret_name, safe='')}"
        response = self._get(url, self._common_headers(token))
        self._check_status(response, secret_name)
        return response.json()

    def get_secret_field(self, secret_name: str, field: str, token: str = "") -> str:
        """Fetch a single field from /getsecret/:secret_name/:field."""
        self._validate_secret_request(secret_name)
        if not field:
            raise ValueError("field is required")

        url = (
            f"{self.server}/getsecret/"
            f"{urllib.parse.quote(secret_name, safe='')}/"
            f"{urllib.parse.quote(field, safe='')}"
        )
        response = self._get(url, self._common_headers(token))
        self._check_status(response, secret_name, field=field)
        return response.text

    def cleanup(self) -> None:
        self._finalizer()

    def __enter__(self) -> HushClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.cleanup()
