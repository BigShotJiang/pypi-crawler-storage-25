"""Addon request and transport orchestration helpers."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from manicure import breakpoint as bp
from manicure.adapters import get_adapter
from manicure.codex.exchange import (
    _delete_codex_provisional_exchange,
    _finalize_codex_provisional_exchange,
    _persist_codex_handshake_failure,
    _persist_codex_provisional_exchange,
)
from manicure.codex.transport import (
    close_codex_transport,
    ensure_codex_transport_state,
    is_codex_turn_terminal_message,
    is_codex_websocket_flow,
    record_codex_websocket_message,
)
from manicure.config import get_settings
from manicure.counting import TokenCounter, _relevant_auth_headers, set_recent_auth
from manicure.exchange_recorder import _persist_http_exchange
from manicure.flow_state import (
    capture_request_flow_state,
    clear_request_flow_state,
    get_request_flow_state,
    update_request_flow_state,
)
from manicure.pause_session import handle_breakpoint, handle_websocket_breakpoint
from manicure.request_pipeline import (
    capture_codex_initial_request_ir,
    parse_request_ir,
    run_pipeline,
)

if TYPE_CHECKING:
    from mitmproxy import http

logger = logging.getLogger(__name__)


def _should_skip_breakpoint(model: str) -> bool:
    settings = get_settings()
    return any(s in model for s in settings.breakpoint_skip_models)


async def handle_http_request(
    flow: http.HTTPFlow,
    token_counter: TokenCounter | None,
) -> None:
    if not flow.request.path.startswith("/v1/messages"):
        return
    try:
        adapter = get_adapter(flow)
    except Exception:
        logger.debug("No adapter matches flow %s, passing through", flow.id)
        return

    set_recent_auth(_relevant_auth_headers(flow.request.headers))
    result = await parse_request_ir(flow, adapter)
    if result is None:
        return
    raw, ir = result

    logger.info(
        "REQ %s model=%s system=%d tools=%d msgs=%d",
        flow.id,
        ir.model,
        len(ir.system),
        len(ir.tools),
        len(ir.messages),
    )

    curated_ir, audit = await run_pipeline(ir, flow.id)
    capture_request_flow_state(
        flow,
        adapter=adapter,
        request_ir=ir,
        raw_request=raw,
        curated_request_ir=curated_ir,
        audit=audit,
    )

    if _should_skip_breakpoint(ir.model):
        logger.info(
            "Breakpoint skip: %s matches breakpoint_skip_models filter",
            flow.id,
        )
    if not _should_skip_breakpoint(ir.model) and bp.is_armed():
        logger.info("BREAKPOINT %s armed, pausing", flow.id)
        await handle_breakpoint(flow, adapter, ir, curated_ir, audit, token_counter)
        return

    logger.debug(
        "Skipping breakpoint for %s (another flow paused or not armed)",
        flow.id,
    )
    flow.request.set_text(adapter.outbound_request(curated_ir).decode())


def log_websocket_start(flow: http.HTTPFlow) -> None:
    state = ensure_codex_transport_state(flow)
    if state is None:
        return
    logger.info(
        "CODEX WS START %s host=%s path=%s status=%s",
        flow.id,
        state.upgrade.host,
        state.upgrade.path,
        state.upgrade.response_status_code,
    )


async def handle_codex_websocket_message(flow: http.HTTPFlow) -> None:
    update = record_codex_websocket_message(flow)
    if update is None:
        return
    state, message, captured_initial = update
    if state.provisional_exchange_id is not None and is_codex_turn_terminal_message(
        message
    ):
        finalized = await _finalize_codex_provisional_exchange(flow, None)
        if not finalized:
            logger.warning(
                "Failed to finalize provisional Codex exchange on terminal server frame for %s",
                flow.id,
            )
        return
    if not captured_initial:
        return
    websocket = getattr(flow, "websocket", None)
    if websocket is None:
        return
    turn_start_index = len(websocket.messages) - 1
    if state.provisional_exchange_id is not None:
        finalized = await _finalize_codex_provisional_exchange(
            flow,
            None,
            message_end=turn_start_index,
        )
        if not finalized:
            logger.warning(
                "Failed to finalize prior provisional Codex exchange before rotating turn for %s",
                flow.id,
            )
    state.finalized_exchange_id = None
    state.turn_start_message_index = turn_start_index
    state.turn_client_messages_before = max(0, state.client_message_count - 1)
    state.turn_server_messages_before = state.server_message_count
    ir = capture_codex_initial_request_ir(
        flow,
        state.initial_client_frame or b"",
    )
    if ir is None:
        clear_request_flow_state(flow)
        return
    request_state = get_request_flow_state(flow)
    if request_state is None:
        return
    state.provisional_exchange_id = None
    adapter = request_state.adapter
    curated_ir, audit = await run_pipeline(ir, flow.id)
    update_request_flow_state(
        flow,
        curated_request_ir=curated_ir,
        audit=audit,
    )
    await _persist_codex_provisional_exchange(flow)
    level = logging.INFO if message.is_text else logging.WARNING
    kind = "text" if message.is_text else "binary"
    logger.log(
        level,
        "CODEX WS INIT %s captured initial client %s frame bytes=%d model=%s msgs=%d tools=%d",
        flow.id,
        kind,
        len(state.initial_client_frame or b""),
        ir.model,
        len(ir.messages),
        len(ir.tools),
    )
    if _should_skip_breakpoint(ir.model):
        logger.info(
            "Codex breakpoint skip: %s matches breakpoint_skip_models filter",
            flow.id,
        )
    if not _should_skip_breakpoint(ir.model) and bp.is_armed():
        logger.info("CODEX BREAKPOINT %s armed, pausing", flow.id)
        await handle_websocket_breakpoint(flow, message, adapter, ir, curated_ir, audit)
        return
    message.content = adapter.outbound_request(curated_ir)


async def handle_codex_websocket_end(flow: http.HTTPFlow) -> None:
    summary = close_codex_transport(flow)
    if summary is None:
        return
    closer = (
        "client"
        if summary.closed_by_client is True
        else "server"
        if summary.closed_by_client is False
        else "unknown"
    )
    if not summary.initial_client_frame_captured:
        logger.warning(
            "CODEX WS END %s close_code=%s closer=%s initial client frame missing",
            flow.id,
            summary.close_code,
            closer,
        )
        return
    if summary.initial_client_frame_dropped:
        await _delete_codex_provisional_exchange(flow)
        logger.info(
            "CODEX WS END %s close_code=%s closer=%s initial client frame dropped; skipping exchange persistence",
            flow.id,
            summary.close_code,
            closer,
        )
        return
    log = logger.info if summary.is_normal else logger.warning
    log(
        "CODEX WS END %s close_code=%s closer=%s client_msgs=%d server_msgs=%d reason=%s",
        flow.id,
        summary.close_code,
        closer,
        summary.client_message_count,
        summary.server_message_count,
        summary.close_reason or "",
    )
    await _finalize_codex_provisional_exchange(flow, summary)


async def handle_response(
    flow: http.HTTPFlow,
    token_counter: TokenCounter | None,
) -> None:
    if is_codex_websocket_flow(flow) and getattr(flow, "websocket", None) is None:
        await _persist_codex_handshake_failure(flow)
        return

    request_state = get_request_flow_state(flow)
    if request_state is None:
        return
    await _persist_http_exchange(flow, request_state, token_counter)
