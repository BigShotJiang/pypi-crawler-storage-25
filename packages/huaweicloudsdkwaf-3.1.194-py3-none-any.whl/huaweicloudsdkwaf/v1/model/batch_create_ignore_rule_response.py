# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BatchCreateIgnoreRuleResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'policyid': 'str',
        'timestamp': 'int',
        'description': 'str',
        'status': 'int',
        'rule': 'str',
        'mode': 'int',
        'conditions': 'list[Condition]',
        'multi_condition': 'bool',
        'producer': 'int',
        'advanced': 'IgnoreAdvanced',
        'domain': 'list[str]'
    }

    attribute_map = {
        'id': 'id',
        'policyid': 'policyid',
        'timestamp': 'timestamp',
        'description': 'description',
        'status': 'status',
        'rule': 'rule',
        'mode': 'mode',
        'conditions': 'conditions',
        'multi_condition': 'multiCondition',
        'producer': 'producer',
        'advanced': 'advanced',
        'domain': 'domain'
    }

    def __init__(self, id=None, policyid=None, timestamp=None, description=None, status=None, rule=None, mode=None, conditions=None, multi_condition=None, producer=None, advanced=None, domain=None):
        r"""BatchCreateIgnoreRuleResponse

        The model defined in huaweicloud sdk

        :param id: 规则id
        :type id: str
        :param policyid: 策略id
        :type policyid: str
        :param timestamp: 创建规则的时间戳
        :type timestamp: int
        :param description: 规则描述
        :type description: str
        :param status: **参数解释：** 规则状态标识，用于指定规则的启用或关闭状态 **约束限制：** 不涉及 **取值范围：**  - 0：关闭  - 1：开启 **默认取值：** 不涉及
        :type status: int
        :param rule: 被屏蔽检测的规则类型或规则ID
        :type rule: str
        :param mode: 版本号固定值为1,代表v2版本误报屏蔽规则，v1版本仅支持兼容旧版本，不支持创建
        :type mode: int
        :param conditions: 条件列表
        :type conditions: list[:class:`huaweicloudsdkwaf.v1.Condition`]
        :param multi_condition: 附加条件
        :type multi_condition: bool
        :param producer: 引用表来源，1代表用户创建，其它值代表modulleX自动生成
        :type producer: int
        :param advanced: 
        :type advanced: :class:`huaweicloudsdkwaf.v1.IgnoreAdvanced`
        :param domain: 防护域名或防护网站
        :type domain: list[str]
        """
        
        super().__init__()

        self._id = None
        self._policyid = None
        self._timestamp = None
        self._description = None
        self._status = None
        self._rule = None
        self._mode = None
        self._conditions = None
        self._multi_condition = None
        self._producer = None
        self._advanced = None
        self._domain = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if policyid is not None:
            self.policyid = policyid
        if timestamp is not None:
            self.timestamp = timestamp
        if description is not None:
            self.description = description
        if status is not None:
            self.status = status
        if rule is not None:
            self.rule = rule
        if mode is not None:
            self.mode = mode
        if conditions is not None:
            self.conditions = conditions
        if multi_condition is not None:
            self.multi_condition = multi_condition
        if producer is not None:
            self.producer = producer
        if advanced is not None:
            self.advanced = advanced
        if domain is not None:
            self.domain = domain

    @property
    def id(self):
        r"""Gets the id of this BatchCreateIgnoreRuleResponse.

        规则id

        :return: The id of this BatchCreateIgnoreRuleResponse.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this BatchCreateIgnoreRuleResponse.

        规则id

        :param id: The id of this BatchCreateIgnoreRuleResponse.
        :type id: str
        """
        self._id = id

    @property
    def policyid(self):
        r"""Gets the policyid of this BatchCreateIgnoreRuleResponse.

        策略id

        :return: The policyid of this BatchCreateIgnoreRuleResponse.
        :rtype: str
        """
        return self._policyid

    @policyid.setter
    def policyid(self, policyid):
        r"""Sets the policyid of this BatchCreateIgnoreRuleResponse.

        策略id

        :param policyid: The policyid of this BatchCreateIgnoreRuleResponse.
        :type policyid: str
        """
        self._policyid = policyid

    @property
    def timestamp(self):
        r"""Gets the timestamp of this BatchCreateIgnoreRuleResponse.

        创建规则的时间戳

        :return: The timestamp of this BatchCreateIgnoreRuleResponse.
        :rtype: int
        """
        return self._timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        r"""Sets the timestamp of this BatchCreateIgnoreRuleResponse.

        创建规则的时间戳

        :param timestamp: The timestamp of this BatchCreateIgnoreRuleResponse.
        :type timestamp: int
        """
        self._timestamp = timestamp

    @property
    def description(self):
        r"""Gets the description of this BatchCreateIgnoreRuleResponse.

        规则描述

        :return: The description of this BatchCreateIgnoreRuleResponse.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this BatchCreateIgnoreRuleResponse.

        规则描述

        :param description: The description of this BatchCreateIgnoreRuleResponse.
        :type description: str
        """
        self._description = description

    @property
    def status(self):
        r"""Gets the status of this BatchCreateIgnoreRuleResponse.

        **参数解释：** 规则状态标识，用于指定规则的启用或关闭状态 **约束限制：** 不涉及 **取值范围：**  - 0：关闭  - 1：开启 **默认取值：** 不涉及

        :return: The status of this BatchCreateIgnoreRuleResponse.
        :rtype: int
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this BatchCreateIgnoreRuleResponse.

        **参数解释：** 规则状态标识，用于指定规则的启用或关闭状态 **约束限制：** 不涉及 **取值范围：**  - 0：关闭  - 1：开启 **默认取值：** 不涉及

        :param status: The status of this BatchCreateIgnoreRuleResponse.
        :type status: int
        """
        self._status = status

    @property
    def rule(self):
        r"""Gets the rule of this BatchCreateIgnoreRuleResponse.

        被屏蔽检测的规则类型或规则ID

        :return: The rule of this BatchCreateIgnoreRuleResponse.
        :rtype: str
        """
        return self._rule

    @rule.setter
    def rule(self, rule):
        r"""Sets the rule of this BatchCreateIgnoreRuleResponse.

        被屏蔽检测的规则类型或规则ID

        :param rule: The rule of this BatchCreateIgnoreRuleResponse.
        :type rule: str
        """
        self._rule = rule

    @property
    def mode(self):
        r"""Gets the mode of this BatchCreateIgnoreRuleResponse.

        版本号固定值为1,代表v2版本误报屏蔽规则，v1版本仅支持兼容旧版本，不支持创建

        :return: The mode of this BatchCreateIgnoreRuleResponse.
        :rtype: int
        """
        return self._mode

    @mode.setter
    def mode(self, mode):
        r"""Sets the mode of this BatchCreateIgnoreRuleResponse.

        版本号固定值为1,代表v2版本误报屏蔽规则，v1版本仅支持兼容旧版本，不支持创建

        :param mode: The mode of this BatchCreateIgnoreRuleResponse.
        :type mode: int
        """
        self._mode = mode

    @property
    def conditions(self):
        r"""Gets the conditions of this BatchCreateIgnoreRuleResponse.

        条件列表

        :return: The conditions of this BatchCreateIgnoreRuleResponse.
        :rtype: list[:class:`huaweicloudsdkwaf.v1.Condition`]
        """
        return self._conditions

    @conditions.setter
    def conditions(self, conditions):
        r"""Sets the conditions of this BatchCreateIgnoreRuleResponse.

        条件列表

        :param conditions: The conditions of this BatchCreateIgnoreRuleResponse.
        :type conditions: list[:class:`huaweicloudsdkwaf.v1.Condition`]
        """
        self._conditions = conditions

    @property
    def multi_condition(self):
        r"""Gets the multi_condition of this BatchCreateIgnoreRuleResponse.

        附加条件

        :return: The multi_condition of this BatchCreateIgnoreRuleResponse.
        :rtype: bool
        """
        return self._multi_condition

    @multi_condition.setter
    def multi_condition(self, multi_condition):
        r"""Sets the multi_condition of this BatchCreateIgnoreRuleResponse.

        附加条件

        :param multi_condition: The multi_condition of this BatchCreateIgnoreRuleResponse.
        :type multi_condition: bool
        """
        self._multi_condition = multi_condition

    @property
    def producer(self):
        r"""Gets the producer of this BatchCreateIgnoreRuleResponse.

        引用表来源，1代表用户创建，其它值代表modulleX自动生成

        :return: The producer of this BatchCreateIgnoreRuleResponse.
        :rtype: int
        """
        return self._producer

    @producer.setter
    def producer(self, producer):
        r"""Sets the producer of this BatchCreateIgnoreRuleResponse.

        引用表来源，1代表用户创建，其它值代表modulleX自动生成

        :param producer: The producer of this BatchCreateIgnoreRuleResponse.
        :type producer: int
        """
        self._producer = producer

    @property
    def advanced(self):
        r"""Gets the advanced of this BatchCreateIgnoreRuleResponse.

        :return: The advanced of this BatchCreateIgnoreRuleResponse.
        :rtype: :class:`huaweicloudsdkwaf.v1.IgnoreAdvanced`
        """
        return self._advanced

    @advanced.setter
    def advanced(self, advanced):
        r"""Sets the advanced of this BatchCreateIgnoreRuleResponse.

        :param advanced: The advanced of this BatchCreateIgnoreRuleResponse.
        :type advanced: :class:`huaweicloudsdkwaf.v1.IgnoreAdvanced`
        """
        self._advanced = advanced

    @property
    def domain(self):
        r"""Gets the domain of this BatchCreateIgnoreRuleResponse.

        防护域名或防护网站

        :return: The domain of this BatchCreateIgnoreRuleResponse.
        :rtype: list[str]
        """
        return self._domain

    @domain.setter
    def domain(self, domain):
        r"""Sets the domain of this BatchCreateIgnoreRuleResponse.

        防护域名或防护网站

        :param domain: The domain of this BatchCreateIgnoreRuleResponse.
        :type domain: list[str]
        """
        self._domain = domain

    def to_dict(self):
        import warnings
        warnings.warn("BatchCreateIgnoreRuleResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BatchCreateIgnoreRuleResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
