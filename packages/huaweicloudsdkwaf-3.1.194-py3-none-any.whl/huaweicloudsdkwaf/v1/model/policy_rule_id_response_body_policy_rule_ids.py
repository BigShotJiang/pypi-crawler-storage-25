# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class PolicyRuleIdResponseBodyPolicyRuleIds:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'policy_id': 'str',
        'rule_ids': 'list[str]'
    }

    attribute_map = {
        'policy_id': 'policy_id',
        'rule_ids': 'rule_ids'
    }

    def __init__(self, policy_id=None, rule_ids=None):
        r"""PolicyRuleIdResponseBodyPolicyRuleIds

        The model defined in huaweicloud sdk

        :param policy_id: **参数解释：** 策略id，唯一标识一条防护策略 **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及
        :type policy_id: str
        :param rule_ids: **参数解释：** 规则id数组，返回当前防护策略下的多条规则ID **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及
        :type rule_ids: list[str]
        """
        
        

        self._policy_id = None
        self._rule_ids = None
        self.discriminator = None

        if policy_id is not None:
            self.policy_id = policy_id
        if rule_ids is not None:
            self.rule_ids = rule_ids

    @property
    def policy_id(self):
        r"""Gets the policy_id of this PolicyRuleIdResponseBodyPolicyRuleIds.

        **参数解释：** 策略id，唯一标识一条防护策略 **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及

        :return: The policy_id of this PolicyRuleIdResponseBodyPolicyRuleIds.
        :rtype: str
        """
        return self._policy_id

    @policy_id.setter
    def policy_id(self, policy_id):
        r"""Sets the policy_id of this PolicyRuleIdResponseBodyPolicyRuleIds.

        **参数解释：** 策略id，唯一标识一条防护策略 **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及

        :param policy_id: The policy_id of this PolicyRuleIdResponseBodyPolicyRuleIds.
        :type policy_id: str
        """
        self._policy_id = policy_id

    @property
    def rule_ids(self):
        r"""Gets the rule_ids of this PolicyRuleIdResponseBodyPolicyRuleIds.

        **参数解释：** 规则id数组，返回当前防护策略下的多条规则ID **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及

        :return: The rule_ids of this PolicyRuleIdResponseBodyPolicyRuleIds.
        :rtype: list[str]
        """
        return self._rule_ids

    @rule_ids.setter
    def rule_ids(self, rule_ids):
        r"""Sets the rule_ids of this PolicyRuleIdResponseBodyPolicyRuleIds.

        **参数解释：** 规则id数组，返回当前防护策略下的多条规则ID **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及

        :param rule_ids: The rule_ids of this PolicyRuleIdResponseBodyPolicyRuleIds.
        :type rule_ids: list[str]
        """
        self._rule_ids = rule_ids

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PolicyRuleIdResponseBodyPolicyRuleIds):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
