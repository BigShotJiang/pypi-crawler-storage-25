"""Momentum indicators."""
from ._core import _a, _macd, _rsi

def macd(data, fast=12, slow=26, signal=9): return _macd(_a(data), fast, slow, signal)
def rsi(data, period=14): return _rsi(_a(data), period)
