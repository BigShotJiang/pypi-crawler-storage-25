"""Overlay indicators (moving averages, price transforms)."""
from ._core import _a
from ._core import (
    _sma, _ema, _wma, _hma, _alma, _kama,
    _rma, _trima, _dema, _tema, _t3,
    _fwma, _swma, _sinwma, _pwma,
    _vidya, _zlma, _mcgd, _hwma, _ssf,
    _mama, _jma, _linreg, _linregangle,
    _linregintercept, _linregslope,
    _ma, _rainbow, _supertrend, _mmar,
    _vwap, _vwma, _tsf, _mavp, _ichimoku,
    _ht_trendline,
    _hl2, _hlc3, _ohlc4, _typprice, _wcp,
    _avgprice, _medprice, _midprice, _midpoint, _hilo,
)


def sma(data, period): return _sma(_a(data), period)
def ema(data, period): return _ema(_a(data), period)
def wma(data, period): return _wma(_a(data), period)
def hma(data, period): return _hma(_a(data), period)
def alma(data, period, offset=0.85, sigma=6.0): return _alma(_a(data), period, offset, sigma)
def kama(data, period, fast=2, slow=30): return _kama(_a(data), period, fast, slow)
def rma(data, period): return _rma(_a(data), period)
def trima(data, period): return _trima(_a(data), period)
def dema(data, period): return _dema(_a(data), period)
def tema(data, period): return _tema(_a(data), period)
def t3(data, period, vf=0.7): return _t3(_a(data), period, vf)
def fwma(data, period): return _fwma(_a(data), period)
def swma(data, period): return _swma(_a(data), period)
def sinwma(data, period): return _sinwma(_a(data), period)
def pwma(data, period): return _pwma(_a(data), period)
def vidya(data, period): return _vidya(_a(data), period)
def zlma(data, period): return _zlma(_a(data), period)
def mcgd(data, period): return _mcgd(_a(data), period)
def hwma(data, period): return _hwma(_a(data), period)
def ssf(data, period): return _ssf(_a(data), period)
def jma(data, period, phase=0.0): return _jma(_a(data), period, phase)
def linreg(data, period): return _linreg(_a(data), period)
def linregangle(data, period): return _linregangle(_a(data), period)
def linregintercept(data, period): return _linregintercept(_a(data), period)
def linregslope(data, period): return _linregslope(_a(data), period)
def ma(data, period, ma_type="sma"): return _ma(_a(data), period, ma_type)
def rainbow(data, period): return _rainbow(_a(data), period)
def mmar(data, period): return _mmar(_a(data), period)
def tsf(data, period): return _tsf(_a(data), period)
def ht_trendline(data): return _ht_trendline(_a(data))
def mama(data, fast_limit=0.5, slow_limit=0.05): return _mama(_a(data), fast_limit, slow_limit)
def mavp(data, periods, min_period, max_period): return _mavp(_a(data), _a(periods), min_period, max_period)
def vwap(high, low, close, volume, period): return _vwap(_a(high), _a(low), _a(close), _a(volume), period)
def vwma(data, volume, period): return _vwma(_a(data), _a(volume), period)
def supertrend(high, low, close, period=10, multiplier=3.0): return _supertrend(_a(high), _a(low), _a(close), period, multiplier)
def ichimoku(high, low, tenkan=9, kijun=26): return _ichimoku(_a(high), _a(low), tenkan, kijun)
def hl2(high, low): return _hl2(_a(high), _a(low))
def hlc3(high, low, close): return _hlc3(_a(high), _a(low), _a(close))
def ohlc4(open_, high, low, close): return _ohlc4(_a(open_), _a(high), _a(low), _a(close))
def typprice(high, low, close): return _typprice(_a(high), _a(low), _a(close))
def wcp(high, low, close): return _wcp(_a(high), _a(low), _a(close))
def avgprice(open_, high, low, close): return _avgprice(_a(open_), _a(high), _a(low), _a(close))
def medprice(high, low): return _medprice(_a(high), _a(low), _a(high))
def midprice(high, low): return _midprice(_a(high), _a(low), _a(high))
def midpoint(high, low): return _midpoint(_a(high), _a(low), _a(high))
def hilo(high, low): return _hilo(_a(high), _a(low), _a(high))
