"""Internal: direct bindings to the compiled Rust module."""
import numpy as np

from .rusta import (
    sma as _sma, ema as _ema, wma as _wma,
    hma as _hma, alma as _alma, kama as _kama,
    macd as _macd, rsi as _rsi,
    rma as _rma, trima as _trima, dema as _dema,
    tema as _tema, t3 as _t3, fwma as _fwma,
    swma as _swma, sinwma as _sinwma, pwma as _pwma,
    vidya as _vidya, zlma as _zlma, mcgd as _mcgd,
    hwma as _hwma, ssf as _ssf, mama as _mama,
    jma as _jma, linreg as _linreg,
    linregangle as _linregangle,
    linregintercept as _linregintercept,
    linregslope as _linregslope,
    ma as _ma, rainbow as _rainbow,
    supertrend as _supertrend, mmar as _mmar,
    vwap as _vwap, vwma as _vwma, tsf as _tsf,
    mavp as _mavp, ichimoku as _ichimoku,
    ht_trendline as _ht_trendline,
    hl2 as _hl2, hlc3 as _hlc3, ohlc4 as _ohlc4,
    typprice as _typprice, wcp as _wcp,
    avgprice as _avgprice, medprice as _medprice,
    midprice as _midprice, midpoint as _midpoint,
    hilo as _hilo,
    drawdown as _drawdown,
    log_return as _log_return,
    percent_return as _percent_return,
    volatility as _volatility,
    value_at_risk as _value_at_risk,
    sharpe_ratio as _sharpe_ratio,
    sortino_ratio as _sortino_ratio,
    calmar_ratio as _calmar_ratio,
    profit_factor as _profit_factor,
    expectancy as _expectancy,
)


def _a(d):
    return np.asarray(d, dtype=np.float64)
