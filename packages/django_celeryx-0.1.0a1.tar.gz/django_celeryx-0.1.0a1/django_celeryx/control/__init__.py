"""Celery control actions."""
