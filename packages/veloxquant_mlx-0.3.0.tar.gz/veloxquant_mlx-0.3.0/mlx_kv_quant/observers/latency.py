from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List

from mlx_kv_quant.core.abstractions import QuantizationObserver
from mlx_kv_quant.observers.base import QuantizationEvent


class LatencyObserver(QuantizationObserver):
    """Records per-stage timing histograms.

    Tracks all latency samples per stage in milliseconds.
    Call report() to get a summary dict.

    Args:
        None.
    """

    def __init__(self) -> None:
        self._samples: Dict[str, List[float]] = defaultdict(list)

    def on_event(self, event: QuantizationEvent) -> None:
        """Record the elapsed time for the given stage.

        Args:
            event: Pipeline event with stage name and elapsed_ms.
        """
        self._samples[event.stage].append(event.elapsed_ms)

    def report(self) -> Dict[str, Dict[str, float]]:
        """Return summary statistics per stage.

        Returns:
            Dict mapping stage name to {mean_ms, min_ms, max_ms, count}.
        """
        import statistics

        result = {}
        for stage, samples in self._samples.items():
            result[stage] = {
                "mean_ms": statistics.mean(samples),
                "min_ms": min(samples),
                "max_ms": max(samples),
                "count": len(samples),
            }
        return result

    def reset(self) -> None:
        """Clear all accumulated samples."""
        self._samples.clear()

    def __repr__(self) -> str:
        stages = list(self._samples.keys())
        return f"LatencyObserver(stages={stages})"
