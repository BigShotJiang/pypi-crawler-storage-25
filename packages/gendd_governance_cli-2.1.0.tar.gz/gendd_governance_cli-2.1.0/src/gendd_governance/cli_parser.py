from __future__ import annotations

import argparse
from pathlib import Path

from gendd_governance.commands import GOVERNANCE_COMMANDS


def _add_run_options(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--scope",
        choices=("unstaged", "staged", "range", "commit"),
        default=None,
        help=(
            "Which changes to review: unstaged working tree (incl. untracked, non-ignored), "
            "staged index, a branch range (--base/--head), or one commit (--commit). "
            "When omitted in an interactive terminal, you are prompted next."
        ),
    )
    p.add_argument(
        "--commit",
        default=None,
        metavar="SHA",
        help="With --scope=commit, the commit to show (patch + metadata)",
    )
    p.add_argument(
        "--base",
        default="origin/main",
        help="With --scope=range, git base ref for the diff (default: origin/main)",
    )
    p.add_argument(
        "--head",
        default="HEAD",
        help="With --scope=range, git head ref for the diff (default: HEAD)",
    )
    p.add_argument(
        "--format",
        default="console,json",
        help=(
            "Comma-separated: console, json, sarif. Default pairs console+json but "
            "suppresses JSON on stdout (use -v); `--format json` prints JSON only."
        ),
    )
    p.add_argument("--json-out", type=Path, default=None, help="Write JSON report path")
    p.add_argument("--sarif-out", type=Path, default=None, help="Write SARIF path")
    p.add_argument(
        "--post-pr",
        action="store_true",
        help="Post summary to GitHub PR when GITHUB_REF is a PR",
    )
    p.add_argument(
        "--offline",
        action="store_true",
        help=(
            "Use offline stub LLM (no cloud model); still loads .cursor/rules "
            "and repo skills from disk"
        ),
    )
    p.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help=(
            "When using default console+json format, also print the JSON report "
            "to stdout (JSON-only --format json always prints)"
        ),
    )


def build_arg_parser(prog: str) -> argparse.ArgumentParser:
    """Construct the CLI parser (shared by main and shell tab-completion hooks)."""
    run_options = argparse.ArgumentParser(add_help=False)
    _add_run_options(run_options)

    parser = argparse.ArgumentParser(
        prog=prog,
        description="GenDD Agentic Governance",
    )
    sub = parser.add_subparsers(dest="action", required=True)

    p_init = sub.add_parser("init", help="Create local config under .gendd-agentic-governance/")
    p_init.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing .gendd-agentic-governance/.env",
    )
    p_init.add_argument(
        "--defaults",
        action="store_true",
        help="Write a commented template without interactive prompts",
    )

    p_run = sub.add_parser(
        "run",
        parents=[run_options],
        help="Run governance locally (see also each ai-* command for shorthand)",
    )
    p_run.add_argument(
        "command",
        choices=GOVERNANCE_COMMANDS,
        help="Which agents to run",
    )

    sub.add_parser(
        "repeat",
        parents=[run_options],
        help=(
            "Re-run with the same diff scope and command as the last run "
            "(see .gendd-agentic-governance/last-run.json v2+)"
        ),
    )

    # Subcommand only picks which existing specialists run; no separate LLM/system prompt for
    # "select" (see orchestrator.graph.AI_SELECT_COMMAND).
    p_select = sub.add_parser(
        "select",
        parents=[run_options],
        help=(
            "Choose one or more specialist agents (interactive checkbox, or --agents); "
            "then run governance on a git diff"
        ),
    )
    p_select.add_argument(
        "--agents",
        default=None,
        metavar="LABELS",
        help=(
            "Comma-separated specialist labels (e.g. reviewer,security,documentation). "
            "Required when stdin is not a TTY."
        ),
    )

    p_suggest = sub.add_parser(
        "suggest",
        parents=[run_options],
        help=(
            "Recommend specialist agents from path and diff metadata (TTY: checklist + run; "
            "use --print-only or --json for label output only)"
        ),
    )
    p_suggest.add_argument(
        "--json",
        action="store_true",
        help=(
            'Print JSON ({"agents": [...]}) instead of a comma-separated line (skips checklist).'
        ),
    )
    p_suggest.add_argument(
        "--print-only",
        action="store_true",
        help=(
            "Only print suggested agent labels (comma-separated or --json); do not open the "
            "checklist or run. Implied when stdin is not a terminal or when using --json."
        ),
    )

    for cmd in GOVERNANCE_COMMANDS:
        p_cmd = sub.add_parser(
            cmd,
            parents=[run_options],
            help=f'Same as "{prog} run {cmd}"',
        )
        p_cmd.set_defaults(command=cmd)

    sub.add_parser(
        "help",
        help="Show full CLI reference (commands, flags, env vars, exit codes)",
    )

    return parser
