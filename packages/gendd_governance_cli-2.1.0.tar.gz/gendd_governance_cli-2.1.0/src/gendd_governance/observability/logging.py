from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from gendd_governance.config import Settings

GENDD_SCHEMA_VERSION = 1

_run_ctx: ContextVar[GenddRunContext | None] = ContextVar("gendd_run", default=None)
_service_name: str = "gendd-governance-cli"
_service_version: str = "0.0.0"

_SUPPRESS_FOR_TEXT_CONSOLE_EVENTS = frozenset({"agent.started", "agent.completed", "heartbeat"})

_progress_use_stdout = True


def _env_wants_agent_lifecycle_logs() -> bool:
    v = (os.environ.get("GENDD_LOG_AGENT_LIFECYCLE") or "").strip().lower()
    return v in ("1", "true", "yes", "all", "on")


class _TextConsoleNoiseFilter(logging.Filter):
    """With text log format, hide high-volume per-agent INFO lines on the console handler.

    Integrated terminals (e.g. Cursor) often **pipe** stderr, so ``isatty()`` is false and
    TTY-only logic would never suppress—yet the same display glitches still occur. We
    therefore suppress these events for the **text** StreamHandler unless
    ``GENDD_LOG_AGENT_LIFECYCLE=1``. JSON log format is unchanged (full structured lines).
    caplog / other loggers without this filter still see every record in tests.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        extra = getattr(record, "gendd", None)
        if not isinstance(extra, dict):
            return True
        if extra.get("event") not in _SUPPRESS_FOR_TEXT_CONSOLE_EVENTS:
            return True
        return _env_wants_agent_lifecycle_logs()


@dataclass
class GenddRunContext:
    job_id: str | None = None
    correlation_id: str | None = None
    tenant_id: str | None = None
    command: str | None = None

    def as_merge_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        if self.job_id is not None:
            out["job_id"] = self.job_id
        if self.correlation_id is not None:
            out["correlation_id"] = self.correlation_id
        if self.tenant_id is not None:
            out["tenant_id"] = self.tenant_id
        if self.command is not None:
            out["command"] = self.command
        return out


def get_run_context() -> GenddRunContext | None:
    return _run_ctx.get()


@contextmanager
def gendd_run_context(
    *,
    job_id: str | None = None,
    correlation_id: str | None = None,
    tenant_id: str | None = None,
    command: str | None = None,
) -> Iterator[None]:
    ctx = GenddRunContext(
        job_id=job_id,
        correlation_id=correlation_id,
        tenant_id=tenant_id,
        command=command,
    )
    token = _run_ctx.set(ctx)
    try:
        yield
    finally:
        _run_ctx.reset(token)


def emit_gendd(
    logger: logging.Logger,
    event: str,
    message: str,
    *,
    level: int = logging.INFO,
    **fields: Any,
) -> None:
    """Emit a structured log line; merges current run context with event fields."""
    run = get_run_context()
    gendd: dict[str, Any] = {
        "schema_version": GENDD_SCHEMA_VERSION,
        "event": event,
    }
    if run:
        gendd.update(run.as_merge_dict())
    for k, v in fields.items():
        if v is not None:
            gendd[k] = v
    logger.log(level, message, extra={"gendd": gendd})


class GenddContextFilter(logging.Filter):
    """Attach gendd_context from ContextVar for JsonFormatter to merge."""

    def filter(self, record: logging.LogRecord) -> bool:
        run = get_run_context()
        if run:
            record.gendd_context = run.as_merge_dict()
        return True


class JsonFormatter(logging.Formatter):
    """Emit one JSON object per stderr line (CI, containers, generic log pipelines)."""

    def format(self, record: logging.LogRecord) -> str:
        ts = datetime.fromtimestamp(record.created, tz=UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        payload: dict[str, Any] = {
            "timestamp": ts,
            "severity": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
            "service": {"name": _service_name, "version": _service_version},
        }
        gendd: dict[str, Any] = {}
        ctx = getattr(record, "gendd_context", None)
        if isinstance(ctx, dict):
            gendd.update(ctx)
        extra = getattr(record, "gendd", None)
        if isinstance(extra, dict):
            gendd.update(extra)
        if gendd:
            if "schema_version" not in gendd:
                gendd["schema_version"] = GENDD_SCHEMA_VERSION
            payload["gendd"] = gendd
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info).strip()
        return json.dumps(payload, default=str, ensure_ascii=False)


def _resolve_log_level(name: str) -> int:
    level = getattr(logging, str(name).upper(), None)
    return level if isinstance(level, int) else logging.INFO


_stderr_lock_installed = False


class _LockedStderrTextIO:
    """Serialize writes to ``sys.stderr`` (logging, Rich, libraries) on flaky hosts."""

    __slots__ = ("_stream", "_lock")

    def __init__(self, stream: Any) -> None:
        self._stream = stream
        self._lock = threading.RLock()

    def write(self, s: str) -> int:
        with self._lock:
            return self._stream.write(s)

    def write_atomic(self, s: str) -> None:
        """Write ``s`` and flush under one lock (avoids interleaved ``print`` writes)."""

        with self._lock:
            self._stream.write(s)
            self._stream.flush()

    def flush(self) -> None:
        with self._lock:
            self._stream.flush()

    def isatty(self) -> bool:
        return self._stream.isatty()

    def fileno(self) -> int:
        return self._stream.fileno()

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


class _GenddStderrStreamHandler(logging.StreamHandler):
    """Emit one locked write per log record when using :class:`_LockedStderrTextIO`.

    The standard :class:`logging.StreamHandler` calls ``write(msg)`` and ``write(terminator)``
    as two operations. Another thread (or the asyncio main thread writing ``gendd:`` lines)
    can interleave between them — the same failure mode as :func:`print` split writes.
    """

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            stream = self.stream
            line = msg + self.terminator
            if isinstance(stream, _LockedStderrTextIO):
                stream.write_atomic(line)
            else:
                stream.write(line)
                stream.flush()
        except RecursionError:
            raise
        except Exception:
            self.handleError(record)


def set_progress_stdout_preferred(enabled: bool) -> None:
    """When True (default), ``gendd:`` progress lines go to stdout so stderr stays logs+report.

    Set False for ``--format json`` (stdout is machine JSON only).
    """

    global _progress_use_stdout
    _progress_use_stdout = enabled


def write_stderr_atomic(s: str) -> None:
    """Write ``s`` to stderr under one lock when wrapped.

    ``print()`` issues multiple ``write()`` calls; worker threads (e.g. HTTP) can interleave
    between them. A single locked write+flush keeps each progress line intact on Git Bash / MSYS.
    """

    stderr = sys.stderr
    if isinstance(stderr, _LockedStderrTextIO):
        stderr.write_atomic(s)
    else:
        stderr.write(s)
        stderr.flush()


def print_agent_progress(message: str) -> None:
    """Human-readable progress line (stdout when console is enabled, else stderr).

    Text-format logging hides structured ``agent.started`` / ``agent.completed`` on the console
    handler to reduce noise; this helper prints a short ``gendd:`` line so parallel runs show
    per-agent start, duration, and outcome interactively.

    Progress uses **stdout** by default so Git Bash / MSYS does not splice shell prompt fragments
    into the same stream as INFO logs and the Rich report (stderr).
    """

    line = f"gendd: {message}\n"
    if _progress_use_stdout:
        try:
            sys.stdout.write(line)
            sys.stdout.flush()
        except Exception:
            write_stderr_atomic(line)
    else:
        write_stderr_atomic(line)


def _install_locked_stderr() -> None:
    """Wrap ``sys.stderr`` once so every writer shares one lock."""
    global _stderr_lock_installed
    if _stderr_lock_installed:
        return
    sys.stderr = _LockedStderrTextIO(sys.stderr)
    _stderr_lock_installed = True


def configure_logging(settings: Settings) -> None:
    """Configure root logging: JSON or plain text; attaches GenddContextFilter for JSON."""
    global _service_name, _service_version
    if settings.log_service_version:
        _service_version = settings.log_service_version
    else:
        try:
            from importlib.metadata import version as pkg_version

            _service_version = pkg_version("gendd-governance-cli")
        except Exception:
            _service_version = "0.0.0"
    _service_name = settings.log_service_name

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(_resolve_log_level(settings.log_level))

    _install_locked_stderr()
    handler = _GenddStderrStreamHandler(sys.stderr)
    fmt = (settings.log_format or "text").lower()
    if fmt == "json":
        handler.setFormatter(JsonFormatter())
        handler.addFilter(GenddContextFilter())
    else:
        handler.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
        handler.addFilter(_TextConsoleNoiseFilter())

    root.addHandler(handler)

    for noisy in ("httpx", "httpcore", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


async def heartbeat_loop(
    *,
    interval_seconds: float,
    active_agents: set[str],
    logger: logging.Logger,
) -> None:
    """Periodic heartbeat while pipeline agents run (cancel task to stop)."""
    try:
        while True:
            await asyncio.sleep(interval_seconds)
            agents = sorted(active_agents)
            emit_gendd(
                logger,
                "heartbeat",
                f"governance pipeline heartbeat active_agents={agents}",
                active_agents=agents,
            )
    except asyncio.CancelledError:
        raise
