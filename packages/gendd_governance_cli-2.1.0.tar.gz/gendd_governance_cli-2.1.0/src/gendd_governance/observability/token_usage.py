from __future__ import annotations

import math
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any, Literal

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import BaseMessage

from gendd_governance.aggregation.findings import LlmCallTokenUsage, RunSummary
from gendd_governance.run_identity import RunIdentity

TokenMethod = Literal["api", "model_count", "estimated"]

# Known context windows for default / common model ids (exact string match on resolved model_name).
MODEL_CONTEXT_WINDOWS: dict[str, int] = {
    "gemini-2.0-flash-001": 1_048_576,
    "gemini-2.0-flash": 1_048_576,
    "gpt-4o-mini": 128_000,
    "gpt-4o": 128_000,
    "claude-3-5-sonnet-20241022": 200_000,
    "claude-3-5-sonnet-20240620": 200_000,
    "anthropic.claude-3-5-sonnet-20240620-v1:0": 200_000,
}


def lookup_context_window_tokens(model_name: str) -> int | None:
    if not model_name or model_name in ("offline-stub", "(unset)", "(unknown)"):
        return None
    return MODEL_CONTEXT_WINDOWS.get(model_name)


def _message_text_len(messages: list[BaseMessage]) -> int:
    n = 0
    for m in messages:
        c = getattr(m, "content", "") or ""
        if isinstance(c, str):
            n += len(c.encode("utf-8"))
        else:
            n += len(str(c).encode("utf-8"))
    return n


def _estimate_tokens_from_messages(messages: list[BaseMessage]) -> int:
    """Rough heuristic when no API or tokenizer is available (~4 chars per token)."""
    return max(1, math.ceil(_message_text_len(messages) / 4))


def _estimate_output_tokens(text: str) -> int:
    return max(0, math.ceil(len(text.encode("utf-8")) / 4))


def _coerce_int(v: Any) -> int | None:
    if v is None:
        return None
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, float) and not math.isnan(v):
        return int(v)
    return None


def _extract_from_usage_metadata(meta: Any) -> tuple[int | None, int | None, int | None]:
    if not isinstance(meta, dict):
        return None, None, None
    inp = _coerce_int(
        meta.get("input_tokens") or meta.get("prompt_tokens") or meta.get("input_token_count")
    )
    out = _coerce_int(
        meta.get("output_tokens") or meta.get("completion_tokens") or meta.get("output_token_count")
    )
    tot = _coerce_int(meta.get("total_tokens") or meta.get("total_token_count"))
    if tot is None and inp is not None and out is not None:
        tot = inp + out
    return inp, out, tot


def _extract_from_response_metadata(meta: Any) -> tuple[int | None, int | None, int | None]:
    if not isinstance(meta, dict):
        return None, None, None
    tu = meta.get("token_usage")
    if isinstance(tu, dict):
        return _extract_from_usage_metadata(tu)
    usage = meta.get("usage")
    if isinstance(usage, dict):
        return _extract_from_usage_metadata(usage)
    return None, None, None


def normalize_usage_from_ai_message(
    response: BaseMessage,
) -> tuple[int | None, int | None, int | None]:
    um = getattr(response, "usage_metadata", None)
    inp, out, tot = _extract_from_usage_metadata(um)
    if inp is not None or out is not None or tot is not None:
        return inp, out, tot
    rm = getattr(response, "response_metadata", None)
    return _extract_from_response_metadata(rm)


def _model_count_input(model: BaseChatModel, messages: list[BaseMessage]) -> int | None:
    fn = getattr(model, "get_num_tokens_from_messages", None)
    if not callable(fn):
        return None
    try:
        n = fn(messages)
        return int(n) if n is not None else None
    except Exception:
        return None


_records: ContextVar[list[LlmCallTokenUsage] | None] = ContextVar(
    "gendd_llm_token_records",
    default=None,
)


@contextmanager
def token_usage_collector_scope() -> Iterator[None]:
    tok = _records.set([])
    try:
        yield
    finally:
        _records.reset(tok)


def record_chat_usage(
    model: BaseChatModel,
    call_id: str,
    messages: list[BaseMessage],
    response: BaseMessage,
) -> None:
    bucket = _records.get()
    if bucket is None:
        return

    inp, out, tot = normalize_usage_from_ai_message(response)
    method: TokenMethod = "api"
    if inp is None and out is None and tot is None:
        mc = _model_count_input(model, messages)
        if mc is not None:
            inp = mc
            method = "model_count"
            content = getattr(response, "content", "") or ""
            if isinstance(content, list):
                text = "".join(
                    str(x.get("text", x)) if isinstance(x, dict) else str(x) for x in content
                )
            else:
                text = str(content)
            out = _estimate_output_tokens(text)
            tot = (inp or 0) + (out or 0)
        else:
            method = "estimated"
            inp = _estimate_tokens_from_messages(messages)
            content = getattr(response, "content", "") or ""
            if isinstance(content, list):
                text = "".join(
                    str(x.get("text", x)) if isinstance(x, dict) else str(x) for x in content
                )
            else:
                text = str(content)
            out = _estimate_output_tokens(text)
            tot = inp + out

    bucket.append(
        LlmCallTokenUsage(
            call_id=call_id,
            input_tokens=inp,
            output_tokens=out,
            total_tokens=tot,
            method=method,
        )
    )


def build_run_summary(identity: RunIdentity, calls: list[LlmCallTokenUsage] | None) -> RunSummary:
    c = list(calls or [])
    tin: int | None = None
    tout: int | None = None
    ttot: int | None = None
    max_in: int | None = None
    max_tot: int | None = None
    for row in c:
        row_tot = row.total_tokens
        if row_tot is None and row.input_tokens is not None and row.output_tokens is not None:
            row_tot = row.input_tokens + row.output_tokens
        if row.input_tokens is not None:
            tin = (tin or 0) + row.input_tokens
            max_in = row.input_tokens if max_in is None else max(max_in, row.input_tokens)
        if row.output_tokens is not None:
            tout = (tout or 0) + row.output_tokens
        if row_tot is not None:
            ttot = (ttot or 0) + row_tot
            max_tot = row_tot if max_tot is None else max(max_tot, row_tot)

    ctx_lim = lookup_context_window_tokens(identity.model_name)
    pct: float | None = None
    if ctx_lim and ctx_lim > 0 and max_in is not None:
        pct = round(100.0 * max_in / ctx_lim, 2)

    notes: list[str] = []
    if any(x.method == "estimated" for x in c):
        notes.append("Some calls used heuristic token estimates (no API usage metadata).")
    if ctx_lim is None and identity.model_name not in ("offline-stub", "(unset)", "(unknown)"):
        notes.append("Context window size unknown for this model id; percentage omitted.")

    return RunSummary(
        cli_version=identity.cli_version,
        model_provider=identity.model_provider,
        model_name=identity.model_name,
        context_window_tokens=ctx_lim,
        max_prompt_tokens=max_in,
        max_total_tokens=max_tot,
        max_prompt_vs_context_pct=pct,
        total_input_tokens=tin,
        total_output_tokens=tout,
        total_tokens=ttot,
        llm_calls=c,
        notes=" ".join(notes).strip(),
    )


def snapshot_calls() -> list[LlmCallTokenUsage]:
    bucket = _records.get()
    return list(bucket) if bucket else []
