"""Canonical governance CLI command names (ai-*). Keep in sync with orchestrator maps."""

from __future__ import annotations

# Order: one specialist per command; use `gendd select` to run several in parallel.
GOVERNANCE_COMMANDS: tuple[str, ...] = (
    "ai-review",
    "ai-security",
    "ai-dependency",
    "ai-test",
    "ai-maintainability",
    "ai-architecture",
    "ai-documentation",
    "ai-api-contract",
    "ai-migration",
    "ai-performance",
    "ai-telemetry",
    "ai-accessibility",
    "ai-infra",
    "ai-changelog",
    "ai-changes-summary",
    "ai-build-hygiene",
    "ai-compliance",
)
