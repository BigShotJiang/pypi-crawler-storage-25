from __future__ import annotations

import json
import logging
import time

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.aggregation.findings import Finding, Severity
from gendd_governance.config import SuperPhaseLimits
from gendd_governance.observability.logging import emit_gendd, print_agent_progress
from gendd_governance.prompts.loader import build_super_phase_system_prompt

_log = logging.getLogger(__name__)


def _findings_json_for_prompt(findings: list[Finding], max_chars: int) -> str:
    """Serialize findings to JSON, truncating the list if needed to stay under max_chars."""
    chunks: list[dict] = []
    for f in findings:
        chunks.append(f.model_dump())
        payload = json.dumps({"findings": chunks}, default=str)
        if len(payload) > max_chars:
            chunks.pop()
            break
    payload = json.dumps({"findings": chunks}, default=str)
    if len(findings) > len(chunks):
        payload += (
            f"\n\n(Truncated: included {len(chunks)} of {len(findings)} specialist findings "
            "due to size limits.)"
        )
    return payload


async def run_super_synthesis(
    ctx: AgentContext,
    specialist_findings: list[Finding],
    *,
    limits: SuperPhaseLimits,
) -> list[Finding]:
    label = "super_synthesis"
    t0 = time.perf_counter()
    emit_gendd(_log, "agent.started", f"agent {label} started", agent=label)
    print_agent_progress(f"agent {label} starting…")
    try:
        system = build_super_phase_system_prompt("super_synthesis_system")
        findings_block = _findings_json_for_prompt(
            specialist_findings,
            limits.max_findings_json_chars,
        )
        user = f"""## Specialist findings (JSON)
{findings_block}

## Organizational rules (standards + prompts)
{ctx.rules_block[: limits.max_rules_synthesis]}

## Git diff
{ctx.diff_text[: limits.max_diff_synthesis]}
"""
        out = await invoke_findings(ctx, label, system, user)
        duration_ms = int((time.perf_counter() - t0) * 1000)
        emit_gendd(
            _log,
            "agent.completed",
            f"agent {label} completed in {duration_ms}ms",
            agent=label,
            duration_ms=duration_ms,
        )
        print_agent_progress(f"agent {label} finished in {duration_ms} ms ({len(out)} findings)")
        return out
    except Exception as exc:
        duration_ms = int((time.perf_counter() - t0) * 1000)
        emit_gendd(
            _log,
            "agent.failed",
            f"agent {label} failed: {exc}",
            agent=label,
            duration_ms=duration_ms,
            error_type=type(exc).__name__,
            level=logging.ERROR,
        )
        print_agent_progress(f"agent {label} failed after {duration_ms} ms: {exc}")
        return [
            Finding(
                agent="orchestrator",
                severity=Severity.HIGH,
                title="Super synthesis failed",
                description=str(exc),
            )
        ]


def _serialize_synthesized_for_calibration(findings: list[Finding]) -> str:
    return json.dumps({"findings": [f.model_dump() for f in findings]}, default=str)


async def run_super_calibration(
    ctx: AgentContext,
    synthesized: list[Finding],
    *,
    limits: SuperPhaseLimits,
) -> list[Finding]:
    label = "super_calibration"
    t0 = time.perf_counter()
    emit_gendd(_log, "agent.started", f"agent {label} started", agent=label)
    print_agent_progress(f"agent {label} starting…")
    try:
        system = build_super_phase_system_prompt("super_calibration_system")
        synth_block = _serialize_synthesized_for_calibration(synthesized)
        user = f"""## Synthesized findings (JSON)
{synth_block}

## Organizational rules (standards + prompts)
{ctx.rules_block[: limits.max_rules_calibration]}

## Git diff
{ctx.diff_text[: limits.max_diff_calibration]}
"""
        out = await invoke_findings(ctx, label, system, user)
        duration_ms = int((time.perf_counter() - t0) * 1000)
        emit_gendd(
            _log,
            "agent.completed",
            f"agent {label} completed in {duration_ms}ms",
            agent=label,
            duration_ms=duration_ms,
        )
        print_agent_progress(f"agent {label} finished in {duration_ms} ms ({len(out)} findings)")
        return out
    except Exception as exc:
        duration_ms = int((time.perf_counter() - t0) * 1000)
        emit_gendd(
            _log,
            "agent.failed",
            f"agent {label} failed: {exc}",
            agent=label,
            duration_ms=duration_ms,
            error_type=type(exc).__name__,
            level=logging.ERROR,
        )
        print_agent_progress(f"agent {label} failed after {duration_ms} ms: {exc}")
        return [
            Finding(
                agent="orchestrator",
                severity=Severity.HIGH,
                title="Super calibration failed",
                description=str(exc),
            )
        ]


async def run_super_phases(
    ctx: AgentContext,
    specialist_findings: list[Finding],
    *,
    limits: SuperPhaseLimits,
) -> list[Finding]:
    synthesized = await run_super_synthesis(ctx, specialist_findings, limits=limits)
    if not synthesized:
        return []
    out = await run_super_calibration(ctx, synthesized, limits=limits)
    emit_gendd(
        _log,
        "super.phases.done",
        "super synthesis and calibration phase finished",
        findings_count=len(out),
    )
    return out
