"""LangGraph pipeline (`graph`: build_graph, run_pipeline) — import submodules as needed.

Avoid importing `gendd_governance.orchestrator.graph` from this package to keep CLI
startup fast: use ``from gendd_governance.orchestrator import graph as graph_mod`` or
``from gendd_governance.orchestrator.graph import run_pipeline`` directly.
"""
