"""Lightweight command ↔ specialist label mapping for CLI help and validation.

Heavier orchestration (LangGraph, agent callables) lives in graph.py and loads on demand.
"""

from __future__ import annotations

from gendd_governance.commands import GOVERNANCE_COMMANDS

# Order matches specialist execution order in the orchestrator (canonical AI_ALL order).
SPECIALIST_LABELS_ORDERED: tuple[str, ...] = (
    "reviewer",
    "security",
    "dependency",
    "test_validator",
    "maintainability",
    "architecture",
    "documentation",
    "api_contract",
    "migration_rollout",
    "performance",
    "telemetry",
    "accessibility",
    "infra",
    "changelog",
    "change_narrative",
    "build_hygiene",
    "compliance",
)

# Internal pipeline id for `gendd select` (not a governance command).
AI_SELECT_COMMAND = "ai-select"

# For each governance command, which specialist labels run (string ids only).
COMMAND_TO_AGENT_LABELS: dict[str, tuple[str, ...]] = {
    "ai-review": ("reviewer",),
    "ai-security": ("security",),
    "ai-dependency": ("dependency",),
    "ai-test": ("test_validator",),
    "ai-maintainability": ("maintainability",),
    "ai-architecture": ("architecture",),
    "ai-documentation": ("documentation",),
    "ai-api-contract": ("api_contract",),
    "ai-migration": ("migration_rollout",),
    "ai-performance": ("performance",),
    "ai-telemetry": ("telemetry",),
    "ai-accessibility": ("accessibility",),
    "ai-infra": ("infra",),
    "ai-changelog": ("changelog",),
    "ai-changes-summary": ("change_narrative",),
    "ai-build-hygiene": ("build_hygiene",),
    "ai-compliance": ("compliance",),
}


def _validate_metadata() -> None:
    if set(COMMAND_TO_AGENT_LABELS) != set(GOVERNANCE_COMMANDS):
        raise RuntimeError("COMMAND_TO_AGENT_LABELS keys must match GOVERNANCE_COMMANDS")
    allowed = set(SPECIALIST_LABELS_ORDERED)
    for cmd, labels in COMMAND_TO_AGENT_LABELS.items():
        for lb in labels:
            if lb not in allowed:
                raise RuntimeError(f"Command {cmd!r} references unknown specialist label: {lb!r}")


_validate_metadata()


def parse_specialist_label_csv(csv: str) -> list[str]:
    """Parse comma-separated labels into a list in :data:`SPECIALIST_LABELS_ORDERED` order."""
    parts = [p.strip() for p in csv.split(",") if p.strip()]
    if not parts:
        raise ValueError("no specialist labels given")
    unknown = [p for p in parts if p not in SPECIALIST_LABELS_ORDERED]
    if unknown:
        raise ValueError(
            f"unknown specialist label(s): {', '.join(repr(x) for x in unknown)}; "
            f"expected one of: {', '.join(SPECIALIST_LABELS_ORDERED)}"
        )
    seen: set[str] = set()
    pick: set[str] = set()
    for p in parts:
        if p not in seen:
            seen.add(p)
            pick.add(p)
    return [lb for lb in SPECIALIST_LABELS_ORDERED if lb in pick]
