from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Awaitable, Callable
from typing import Any

from gendd_governance.agents.accessibility import run_accessibility_agent
from gendd_governance.agents.api_contract import run_api_contract_agent
from gendd_governance.agents.architecture import run_architecture_agent
from gendd_governance.agents.build_hygiene import run_build_hygiene_agent
from gendd_governance.agents.change_narrative import run_change_narrative_agent
from gendd_governance.agents.changelog import run_changelog_agent
from gendd_governance.agents.compliance import run_compliance_agent
from gendd_governance.agents.dependency import run_dependency_agent
from gendd_governance.agents.documentation import run_documentation_agent
from gendd_governance.agents.infra import run_infra_agent
from gendd_governance.agents.maintainability import run_maintainability_agent
from gendd_governance.agents.migration_rollout import run_migration_rollout_agent
from gendd_governance.agents.performance import run_performance_agent
from gendd_governance.agents.reviewer import run_reviewer_agent
from gendd_governance.agents.security import run_security_agent
from gendd_governance.agents.telemetry import run_telemetry_agent
from gendd_governance.agents.test_validator import run_test_validator_agent
from gendd_governance.aggregation.findings import Finding, Severity
from gendd_governance.commands import GOVERNANCE_COMMANDS
from gendd_governance.observability.logging import (
    emit_gendd,
    heartbeat_loop,
    print_agent_progress,
    write_stderr_atomic,
)
from gendd_governance.orchestrator.command_metadata import (
    AI_SELECT_COMMAND,
    COMMAND_TO_AGENT_LABELS,
    SPECIALIST_LABELS_ORDERED,
    parse_specialist_label_csv,
)

AgentFn = Callable[..., Awaitable[list[Finding]]]

_log = logging.getLogger(__name__)

_LABEL_TO_FN: dict[str, AgentFn] = {
    "reviewer": run_reviewer_agent,
    "security": run_security_agent,
    "dependency": run_dependency_agent,
    "test_validator": run_test_validator_agent,
    "maintainability": run_maintainability_agent,
    "architecture": run_architecture_agent,
    "documentation": run_documentation_agent,
    "api_contract": run_api_contract_agent,
    "migration_rollout": run_migration_rollout_agent,
    "performance": run_performance_agent,
    "telemetry": run_telemetry_agent,
    "accessibility": run_accessibility_agent,
    "infra": run_infra_agent,
    "changelog": run_changelog_agent,
    "change_narrative": run_change_narrative_agent,
    "build_hygiene": run_build_hygiene_agent,
    "compliance": run_compliance_agent,
}

if set(_LABEL_TO_FN) != set(SPECIALIST_LABELS_ORDERED):
    msg = "specialist label map out of sync with SPECIALIST_LABELS_ORDERED"
    raise RuntimeError(msg)

_AI_ALL_FNS: list[AgentFn] = [_LABEL_TO_FN[lb] for lb in SPECIALIST_LABELS_ORDERED]

COMMAND_AGENT_MAP: dict[str, list[AgentFn]] = {
    k: [_LABEL_TO_FN[lb] for lb in v] for k, v in COMMAND_TO_AGENT_LABELS.items()
}
if set(COMMAND_AGENT_MAP) != set(GOVERNANCE_COMMANDS):
    raise RuntimeError("COMMAND_AGENT_MAP keys must match GOVERNANCE_COMMANDS")

AGENT_LABELS: dict[AgentFn, str] = {fn: name for name, fn in _LABEL_TO_FN.items()}
SPECIALIST_FNS_ORDERED: tuple[AgentFn, ...] = tuple(_AI_ALL_FNS)

# Same specialists as SPECIALIST_FNS_ORDERED; order is A–Z by label for interactive pickers.
SPECIALIST_FNS_ALPHABETICAL: tuple[AgentFn, ...] = tuple(
    sorted(SPECIALIST_FNS_ORDERED, key=lambda f: AGENT_LABELS[f].casefold())
)


def parse_specialist_labels(csv: str) -> list[AgentFn]:
    """Parse comma-separated specialist labels into AgentFn list, canonical order."""
    ordered_labels = parse_specialist_label_csv(csv)
    return [_LABEL_TO_FN[lb] for lb in ordered_labels]


def agents_for_command(command: str) -> list[AgentFn]:
    return COMMAND_AGENT_MAP[command]


async def _run_parallel_specialists(
    ctx: Any,
    fns: list[AgentFn],
    *,
    heartbeat_interval_seconds: float | None = 30.0,
    burst_parallel_progress: bool = False,
) -> list[Finding]:
    active: set[str] = set()

    async def run_wrapped(fn: AgentFn) -> list[Finding] | Exception:
        label = AGENT_LABELS[fn]
        t0 = time.perf_counter()
        active.add(label)
        emit_gendd(_log, "agent.started", f"agent {label} started", agent=label)
        if not burst_parallel_progress:
            print_agent_progress(f"agent {label} starting…")
        try:
            out = await fn(ctx)
            duration_ms = int((time.perf_counter() - t0) * 1000)
            emit_gendd(
                _log,
                "agent.completed",
                f"agent {label} completed in {duration_ms}ms",
                agent=label,
                duration_ms=duration_ms,
            )
            n = len(out) if isinstance(out, list) else 0
            if not burst_parallel_progress:
                print_agent_progress(f"agent {label} finished in {duration_ms} ms ({n} findings)")
            return out
        except Exception as exc:
            duration_ms = int((time.perf_counter() - t0) * 1000)
            emit_gendd(
                _log,
                "agent.failed",
                f"agent {label} failed: {exc}",
                agent=label,
                duration_ms=duration_ms,
                error_type=type(exc).__name__,
                level=logging.ERROR,
            )
            if not burst_parallel_progress:
                print_agent_progress(f"agent {label} failed after {duration_ms} ms: {exc}")
            return exc
        finally:
            active.discard(label)

    hb_task: asyncio.Task[None] | None = None
    if heartbeat_interval_seconds is not None and heartbeat_interval_seconds > 0:
        hb_task = asyncio.create_task(
            heartbeat_loop(
                interval_seconds=heartbeat_interval_seconds,
                active_agents=active,
                logger=_log,
            )
        )

    if burst_parallel_progress:
        write_stderr_atomic(f"gendd: {len(fns)} specialists running in parallel…\n")

    try:
        tasks = [run_wrapped(fn) for fn in fns]
        parts = await asyncio.gather(*tasks)
        emit_gendd(
            _log,
            "parallel.agents.done",
            f"parallel specialist phase finished ({len(fns)} agents)",
            agent_count=len(fns),
        )
    finally:
        if hb_task is not None:
            hb_task.cancel()
            try:
                await hb_task
            except asyncio.CancelledError:
                pass

    if burst_parallel_progress:
        n_fail = sum(1 for p in parts if isinstance(p, Exception))
        n_ok = len(parts) - n_fail
        if n_fail:
            write_stderr_atomic(
                f"gendd: parallel specialists finished ({n_ok} ok, {n_fail} failed)\n"
            )
        else:
            write_stderr_atomic(f"gendd: parallel specialists finished ({n_ok} agents)\n")

    out: list[Finding] = []
    for p in parts:
        if isinstance(p, Exception):
            out.append(
                Finding(
                    agent="orchestrator",
                    severity=Severity.HIGH,
                    title="Agent failed",
                    description=str(p),
                )
            )
        else:
            out.extend(p)
    return out


async def run_pipeline(
    command: str,
    model: Any,
    diff_text: str,
    rules_block: str,
    osv_summary: str,
    *,
    context_bundle: dict[str, object] | None = None,
    license_signals: str = "",
    infra_hints: str = "",
    performance_hints: str = "",
    telemetry_hints: str = "",
    accessibility_hints: str = "",
    heartbeat_interval_seconds: float | None = 30.0,
    specialist_fns: list[AgentFn] | None = None,
    rules_by_agent: dict[str, str] | None = None,
    context_paths_by_agent: dict[str, dict[str, list[str]]] | None = None,
) -> list[Finding]:
    from gendd_governance.agents.base import AgentContext

    if specialist_fns is not None and command != AI_SELECT_COMMAND:
        raise ValueError(f"specialist_fns is only valid when command is {AI_SELECT_COMMAND!r}")

    rb_map = rules_by_agent if rules_by_agent else None
    cp_map = context_paths_by_agent if context_paths_by_agent else None

    ctx = AgentContext(
        model=model,
        diff_text=diff_text,
        rules_block=rules_block,
        osv_summary=osv_summary,
        context_bundle=context_bundle,
        license_signals=license_signals,
        infra_hints=infra_hints,
        performance_hints=performance_hints,
        telemetry_hints=telemetry_hints,
        accessibility_hints=accessibility_hints,
        rules_by_agent=rb_map,
        context_paths_by_agent=cp_map,
    )

    if command == AI_SELECT_COMMAND:
        if not specialist_fns:
            msg = (
                f"{AI_SELECT_COMMAND!r} requires a non-empty specialist_fns list "
                f"(got {specialist_fns!r})"
            )
            _log.warning("%s", msg)
            raise ValueError(msg)
        burst_parallel = len(specialist_fns) > 1
        return await _run_parallel_specialists(
            ctx,
            specialist_fns,
            heartbeat_interval_seconds=heartbeat_interval_seconds,
            burst_parallel_progress=burst_parallel,
        )

    fns = agents_for_command(command)
    return await _run_parallel_specialists(
        ctx,
        fns,
        heartbeat_interval_seconds=heartbeat_interval_seconds,
        burst_parallel_progress=False,
    )


def build_graph() -> Any:
    """Minimal LangGraph graph for future multi-node flows; pipeline uses run_pipeline directly."""
    from langgraph.graph import END, StateGraph

    async def passthrough(state: dict[str, Any]) -> dict[str, Any]:
        return state

    g = StateGraph(dict)
    g.add_node("noop", passthrough)
    g.set_entry_point("noop")
    g.add_edge("noop", END)
    return g.compile()
