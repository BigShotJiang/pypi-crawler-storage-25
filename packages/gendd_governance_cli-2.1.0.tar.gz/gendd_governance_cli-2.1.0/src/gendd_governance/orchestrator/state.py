from __future__ import annotations

from typing import TypedDict


class GovernanceState(TypedDict, total=False):
    """LangGraph state payload (serializable dicts)."""

    command: str
    findings: list[dict]
    message: str
