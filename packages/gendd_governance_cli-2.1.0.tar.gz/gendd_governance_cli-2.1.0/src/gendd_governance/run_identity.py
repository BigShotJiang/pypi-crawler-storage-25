from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version

from langchain_core.language_models.chat_models import BaseChatModel

from gendd_governance.config import Settings
from gendd_governance.observability.logging import write_stderr_atomic
from gendd_governance.providers.stub import OfflineStubChatModel


def cli_package_version() -> str:
    try:
        return version("gendd-governance-cli")
    except PackageNotFoundError:
        return "unknown"


@dataclass(frozen=True)
class RunIdentity:
    cli_version: str
    model_provider: str
    model_name: str


def resolve_run_identity(settings: Settings, model: BaseChatModel) -> RunIdentity:
    ver = cli_package_version()
    if isinstance(model, OfflineStubChatModel):
        return RunIdentity(ver, settings.model_provider, "offline-stub")

    p = settings.model_provider
    if p == "vertex":
        name = settings.vertex_model
    elif p == "openai":
        name = settings.openai_model
    elif p == "azure_openai":
        name = settings.azure_openai_deployment
    elif p == "bedrock":
        name = settings.bedrock_model_id or "(unset)"
    elif p == "anthropic":
        name = settings.anthropic_model
    else:
        name = "(unknown)"

    return RunIdentity(ver, p, name)


def format_run_banner_line(identity: RunIdentity) -> str:
    return (
        f"gendd: CLI {identity.cli_version} | "
        f"provider {identity.model_provider} | model {identity.model_name}"
    )


def write_run_identity_banner(identity: RunIdentity) -> None:
    """Emit the run identity line to stderr (green on a TTY unless ``NO_COLOR`` is set)."""
    line = format_run_banner_line(identity)
    use_color = sys.stderr.isatty() and not (os.environ.get("NO_COLOR") or "").strip()
    if use_color:
        line = f"\033[32m{line}\033[0m"
    write_stderr_atomic(line + "\n")
