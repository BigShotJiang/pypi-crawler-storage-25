from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_compliance_agent(ctx: AgentContext):
    system = build_agent_system_prompt("compliance_policy_system")
    lic = ctx.license_signals[:25_000] if ctx.license_signals else "(none)"
    user = f"""## License / manifest signals (deterministic)
{lic}

## Organizational rules (policy pack)
{ctx.rules_for("compliance")[:65_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "compliance", system, user)
