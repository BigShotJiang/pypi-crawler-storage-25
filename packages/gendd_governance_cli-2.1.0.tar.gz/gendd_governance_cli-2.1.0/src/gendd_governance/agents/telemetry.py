from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_telemetry_agent(ctx: AgentContext):
    system = build_agent_system_prompt("telemetry_product_system")
    hints = ctx.telemetry_hints[:20_000] if ctx.telemetry_hints else "(none)"
    user = f"""## Telemetry keyword hints (deterministic)
{hints}

## Organizational rules
{ctx.rules_for("telemetry")[:60_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "telemetry", system, user)
