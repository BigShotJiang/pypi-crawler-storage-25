from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_security_agent(ctx: AgentContext):
    system = build_agent_system_prompt("security_auditor_system")
    user = f"""## OSV / dependency signals
{ctx.osv_summary[:40_000]}

## Organizational security-related rules
{ctx.rules_for("security")[:60_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "security", system, user)
