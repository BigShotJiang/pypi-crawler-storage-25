from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_reviewer_agent(ctx: AgentContext):
    system = build_agent_system_prompt("code_reviewer_system")
    user = f"""## Organizational rules (standards + prompts)
{ctx.rules_for("reviewer")[:80_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "reviewer", system, user)
