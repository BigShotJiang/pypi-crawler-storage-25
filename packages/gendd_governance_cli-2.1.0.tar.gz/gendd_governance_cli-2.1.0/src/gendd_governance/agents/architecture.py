from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.context.context_builder import format_deterministic_context_block_for_agent
from gendd_governance.prompts import build_agent_system_prompt


async def run_architecture_agent(ctx: AgentContext):
    system = build_agent_system_prompt("architecture_consistency_system")
    extra = format_deterministic_context_block_for_agent("architecture", ctx.context_bundle)
    user = f"""## Rules / ADR hints
{ctx.rules_for("architecture")[:80_000]}

{extra}## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "architecture", system, user)
