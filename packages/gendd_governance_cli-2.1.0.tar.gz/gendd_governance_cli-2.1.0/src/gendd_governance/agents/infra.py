from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_infra_agent(ctx: AgentContext):
    system = build_agent_system_prompt("infra_cicd_terraform_system")
    hints = ctx.infra_hints[:40_000] if ctx.infra_hints else "(none)"
    user = f"""## Infra / CI/CD / Terraform hints (deterministic)
{hints}

## Organizational rules
{ctx.rules_for("infra")[:55_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "infra", system, user)
