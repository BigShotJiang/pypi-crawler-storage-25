from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_maintainability_agent(ctx: AgentContext):
    system = build_agent_system_prompt("maintainability_analyst_system")
    user = f"""## Rules
{ctx.rules_for("maintainability")[:60_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "maintainability", system, user)
