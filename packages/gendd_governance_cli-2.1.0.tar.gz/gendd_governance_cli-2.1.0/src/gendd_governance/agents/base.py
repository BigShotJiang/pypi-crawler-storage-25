from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import HumanMessage, SystemMessage

from gendd_governance.agents.json_utils import parse_findings_json
from gendd_governance.aggregation.findings import Finding
from gendd_governance.observability.logging import write_stderr_atomic
from gendd_governance.observability.token_usage import record_chat_usage


def _env_print_agent_llm_output() -> bool:
    v = (os.environ.get("GENDD_PRINT_AGENT_LLM_OUTPUT") or "").strip().lower()
    return v in ("1", "true", "yes", "on")


@dataclass
class AgentContext:
    model: BaseChatModel
    diff_text: str
    rules_block: str
    osv_summary: str
    context_bundle: dict[str, Any] | None = None
    license_signals: str = ""
    infra_hints: str = ""
    performance_hints: str = ""
    telemetry_hints: str = ""
    accessibility_hints: str = ""
    rules_by_agent: dict[str, str] | None = None
    context_paths_by_agent: dict[str, dict[str, list[str]]] | None = None

    def rules_for(self, agent_label: str) -> str:
        if self.rules_by_agent and agent_label in self.rules_by_agent:
            return self.rules_by_agent[agent_label]
        return self.rules_block

    def context_path_overrides(self, agent_label: str) -> dict[str, list[str]] | None:
        if not self.context_paths_by_agent:
            return None
        return self.context_paths_by_agent.get(agent_label)


async def invoke_findings(
    ctx: AgentContext,
    agent_name: str,
    system: str,
    user: str,
) -> list[Finding]:
    messages = [
        SystemMessage(content=system),
        HumanMessage(content=user),
    ]
    loop = asyncio.get_event_loop()

    def _invoke():
        return ctx.model.invoke(messages)

    resp = await loop.run_in_executor(None, _invoke)
    record_chat_usage(ctx.model, agent_name, messages, resp)
    content = getattr(resp, "content", None) or str(resp)
    if isinstance(content, list):
        content = "".join(str(x.get("text", x)) if isinstance(x, dict) else str(x) for x in content)
    text = str(content)
    if _env_print_agent_llm_output():
        cap = 12_000
        body = text if len(text) <= cap else text[:cap] + "\n…(truncated)"
        write_stderr_atomic(f"gendd: agent {agent_name} raw model output:\n{body}\n")
    return parse_findings_json(text, agent_name)
