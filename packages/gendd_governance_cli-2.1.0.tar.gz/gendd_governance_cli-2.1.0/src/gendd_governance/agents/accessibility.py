from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.context.context_builder import format_deterministic_context_block_for_agent
from gendd_governance.prompts import build_agent_system_prompt


async def run_accessibility_agent(ctx: AgentContext):
    system = build_agent_system_prompt("accessibility_ui_system")
    extra = format_deterministic_context_block_for_agent("accessibility", ctx.context_bundle)
    hints = ctx.accessibility_hints[:20_000] if ctx.accessibility_hints else "(none)"
    user = f"""## Accessibility hints (deterministic)
{hints}

## Organizational rules
{ctx.rules_for("accessibility")[:55_000]}

{extra}## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "accessibility", system, user)
