from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.context.context_builder import format_deterministic_context_block_for_agent
from gendd_governance.prompts import build_agent_system_prompt


async def run_test_validator_agent(ctx: AgentContext):
    system = build_agent_system_prompt("test_adequacy_validator_system")
    extra = format_deterministic_context_block_for_agent(
        "test_validator",
        ctx.context_bundle,
        path_overrides=ctx.context_path_overrides("test_validator"),
    )
    user = f"""## Rules
{ctx.rules_for("test_validator")[:60_000]}

{extra}## Git diff (look for test files and code under test)
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "test_validator", system, user)
