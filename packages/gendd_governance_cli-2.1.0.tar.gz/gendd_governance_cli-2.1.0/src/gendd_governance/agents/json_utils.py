from __future__ import annotations

import json
import re
from typing import Any

from gendd_governance.aggregation.findings import Finding, Severity


def _coerce_severity(raw: Any) -> Severity:
    if isinstance(raw, Severity):
        return raw
    s = str(raw or "info").lower()
    for sev in Severity:
        if sev.value == s:
            return sev
    return Severity.INFO


def parse_findings_json(text: str, default_agent: str) -> list[Finding]:
    """Parse model output: JSON object with findings array or raw array."""
    t = text.strip()
    if "```" in t:
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", t)
        if m:
            t = m.group(1).strip()
    try:
        data = json.loads(t)
    except json.JSONDecodeError:
        return [
            Finding(
                agent=default_agent,
                severity=Severity.MEDIUM,
                title="Unparseable model output",
                description=t[:2000],
            )
        ]

    items: list[Any]
    if isinstance(data, dict) and "findings" in data:
        items = data["findings"]
    elif isinstance(data, list):
        items = data
    else:
        items = []

    out: list[Finding] = []
    for it in items:
        if not isinstance(it, dict):
            continue
        try:
            raw_line = it.get("line")
            line: int | None
            if raw_line is None:
                line = None
            elif isinstance(raw_line, int):
                line = raw_line
            elif isinstance(raw_line, str) and raw_line.isdigit():
                line = int(raw_line)
            else:
                line = None
            out.append(
                Finding(
                    agent=str(it.get("agent") or default_agent),
                    severity=_coerce_severity(it.get("severity")),
                    title=str(it.get("title") or "Finding"),
                    description=str(it.get("description") or ""),
                    file=it.get("file") if isinstance(it.get("file"), str) else None,
                    line=line,
                    rule_id=it.get("rule_id") if isinstance(it.get("rule_id"), str) else None,
                    suggested_fix=it.get("suggested_fix")
                    if isinstance(it.get("suggested_fix"), str)
                    else None,
                    plan_mode_prompt=it.get("plan_mode_prompt")
                    if isinstance(it.get("plan_mode_prompt"), str)
                    else None,
                )
            )
        except Exception:
            continue
    return out
