from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_performance_agent(ctx: AgentContext):
    system = build_agent_system_prompt("performance_resource_system")
    hints = ctx.performance_hints[:20_000] if ctx.performance_hints else "(none)"
    user = f"""## Performance heuristics (deterministic)
{hints}

## Organizational rules
{ctx.rules_for("performance")[:60_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "performance", system, user)
