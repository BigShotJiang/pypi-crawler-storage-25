from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_build_hygiene_agent(ctx: AgentContext):
    system = build_agent_system_prompt("build_hygiene_system")
    hints = ctx.infra_hints[:40_000] if ctx.infra_hints else "(none)"
    user = f"""## Workflow / pipeline hints (deterministic; same extract as infra for CI YAML)
{hints}

## Organizational rules
{ctx.rules_for("build_hygiene")[:55_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "build_hygiene", system, user)
