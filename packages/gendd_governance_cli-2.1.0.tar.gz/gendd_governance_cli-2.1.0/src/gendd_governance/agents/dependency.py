from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_dependency_agent(ctx: AgentContext):
    system = build_agent_system_prompt("dependency_risk_analyst_system")
    user = f"""## OSV batch summary
{ctx.osv_summary[:50_000]}

## Rules context
{ctx.rules_for("dependency")[:40_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "dependency", system, user)
