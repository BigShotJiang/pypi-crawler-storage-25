from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.context.context_builder import format_deterministic_context_block_for_agent
from gendd_governance.prompts import build_agent_system_prompt


async def run_documentation_agent(ctx: AgentContext):
    system = build_agent_system_prompt("documentation_verifier_system")
    extra = format_deterministic_context_block_for_agent(
        "documentation",
        ctx.context_bundle,
        path_overrides=ctx.context_path_overrides("documentation"),
    )
    user = f"""## Rules
{ctx.rules_for("documentation")[:60_000]}

{extra}## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "documentation", system, user)
