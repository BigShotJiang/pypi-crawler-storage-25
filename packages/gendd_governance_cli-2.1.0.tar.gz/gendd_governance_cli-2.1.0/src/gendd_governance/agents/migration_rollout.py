from __future__ import annotations

from gendd_governance.agents.base import AgentContext, invoke_findings
from gendd_governance.prompts import build_agent_system_prompt


async def run_migration_rollout_agent(ctx: AgentContext):
    system = build_agent_system_prompt("migration_rollout_system")
    user = f"""## Organizational rules
{ctx.rules_for("migration_rollout")[:70_000]}

## Git diff
{ctx.diff_text[:100_000]}
"""
    return await invoke_findings(ctx, "migration_rollout", system, user)
