from __future__ import annotations

import logging
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path

from gendd_governance.rules.models import CodeStandardRow, ReusablePromptRow
from gendd_governance.rules.paths import (
    collect_cursor_rule_paths,
    collect_skill_paths,
    relative_posix,
)

logger = logging.getLogger(__name__)


@dataclass
class LoadedRules:
    """Flattened text for LLM context."""

    standards: list[CodeStandardRow] = field(default_factory=list)
    prompts: list[ReusablePromptRow] = field(default_factory=list)

    def as_prompt_block(self, max_chars: int = 120_000) -> str:
        parts: list[str] = []
        for s in self.standards:
            c = s.content or ""
            parts.append(f"### Standard [{s.id}] ({s.tech_stack})\n{c}\n")
        for p in self.prompts:
            c = p.content or ""
            parts.append(f"### Reusable prompt [{p.id}] ({p.domain})\n{c}\n")
        text = "\n".join(parts)
        if len(text) <= max_chars:
            return text
        return text[: max_chars - 20] + "\n... [truncated]\n"


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def _skill_domain(rel_posix: str) -> str:
    if rel_posix.startswith(".claude/skills/"):
        return "claude_skill"
    if rel_posix.startswith(".cursor/skills/"):
        return "cursor_skill"
    return "skill"


def load_rules_from_repo(repo_root: Path) -> LoadedRules:
    """Load Cursor rules and repo-local skills from the repository tree."""
    rp = repo_root.resolve()
    rule_paths = collect_cursor_rule_paths(rp)
    skill_paths = collect_skill_paths(rp)
    rels = [relative_posix(rp, p) for p in rule_paths] + [
        relative_posix(rp, p) for p in skill_paths
    ]
    want = frozenset(r for r in rels if r)
    return load_rules_by_ids(rp, want)


def load_rules_by_ids(repo_root: Path, ids: Iterable[str]) -> LoadedRules:
    """Load only rules/skills whose repo-relative POSIX id appears in ``ids``."""
    rp = repo_root.resolve()
    want = frozenset(ids)
    standards: list[CodeStandardRow] = []
    prompts: list[ReusablePromptRow] = []

    for path in collect_cursor_rule_paths(rp):
        rel = relative_posix(rp, path)
        if not rel or rel not in want:
            continue
        try:
            text = _read_text(path)
        except OSError as e:
            logger.warning("read rule %s: %s", rel, e)
            continue
        standards.append(
            CodeStandardRow(
                id=rel,
                techStack="cursor_rule",
                content=text,
                name=path.stem,
            )
        )

    for path in collect_skill_paths(rp):
        rel = relative_posix(rp, path)
        if not rel or rel not in want:
            continue
        try:
            text = _read_text(path)
        except OSError as e:
            logger.warning("read skill %s: %s", rel, e)
            continue
        domain = _skill_domain(rel)
        prompts.append(
            ReusablePromptRow(
                id=rel,
                name=path.parent.name if path.name == "SKILL.md" else path.stem,
                domain=domain,
                content=text,
                sourcePath=rel,
            )
        )

    standards.sort(key=lambda s: s.id.lower())
    prompts.sort(key=lambda p: p.id.lower())
    return LoadedRules(standards=standards, prompts=prompts)


def loaded_rules_subset(loaded: LoadedRules, ids: frozenset[str]) -> LoadedRules:
    """Return a copy of ``loaded`` containing only rows whose ``id`` is in ``ids``."""
    standards = [s for s in loaded.standards if s.id in ids]
    prompts = [p for p in loaded.prompts if p.id in ids]
    return LoadedRules(standards=standards, prompts=prompts)
