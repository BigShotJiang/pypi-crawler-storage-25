"""LLM-assisted selection of rule/skill bodies and related doc/test paths per specialist."""

from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import HumanMessage, SystemMessage

from gendd_governance.observability.token_usage import record_chat_usage
from gendd_governance.rules.index import RuleCatalogEntry, catalog_rule_ids
from gendd_governance.rules.loader import LoadedRules, load_rules_by_ids, loaded_rules_subset

logger = logging.getLogger(__name__)

_ROUTER_SYSTEM = """You are a governance context router for a multi-agent code review pipeline. \
You must choose (1) which repository rule/skill documents each specialist needs, and (2) which \
related documentation and test file paths are worth including for agents that review docs or tests.

Return ONLY valid JSON (no markdown fences, no commentary). Top-level keys:
- "selections": map each agent_label to a list of rule/skill repo-relative paths.
- "context_paths": optional map with "documentation" -> {"related_docs": [...]} and/or \
"test_validator" -> {"related_tests": [...]} using only paths from the candidate lists in the user \
message.

Rules for "selections":
- Keys under "selections" MUST be exactly the agent labels provided.
- Values are lists of rule/skill ids copied verbatim from the rules catalog (may be empty).
- Every id MUST appear in the rules catalog.
- Respect max_extra_non_always_per_agent for ids that are not alwaysApply in the catalog.
- Prefer precision over recall for rules.

Rules for "context_paths":
- Only use keys "documentation" and/or "test_validator" when those path lists are non-empty in \
the prompt. Other agents should be omitted or given empty objects.
- Paths in related_docs MUST be copied verbatim from the candidate related docs list.
- Paths in related_tests MUST be copied verbatim from the candidate related tests list.
- Prefer precision; empty lists are allowed.
- Do not exceed max_context_paths_per_category entries per related_docs or related_tests list.
"""


_AGENT_ROUTER_HINTS: dict[str, str] = {
    "reviewer": "General code review, correctness, readability.",
    "security": "Secrets, injection, authn/z, unsafe patterns.",
    "dependency": "Dependencies, licenses, supply chain.",
    "test_validator": "Test coverage, adequacy of tests for changes.",
    "maintainability": "Maintainability, complexity, tech debt.",
    "architecture": "Structure, boundaries, layering, coupling.",
    "documentation": "Docs, README, comments vs code behavior.",
    "api_contract": "APIs, breaking changes, versioning.",
    "migration_rollout": "Migrations, rollout, backwards compatibility.",
    "performance": "Performance, hot paths, complexity.",
    "telemetry": "Logging, metrics, tracing.",
    "accessibility": "A11y, UI semantics.",
    "infra": "IaC, containers, CI/CD config.",
    "changelog": "Release notes, changelog hygiene.",
    "change_narrative": "Human-readable diff walkthrough; how files fit together.",
    "build_hygiene": "Build scripts, tooling, repo hygiene.",
    "compliance": "Policy, regulatory, organizational compliance.",
}


def _empty_rules_placeholder() -> str:
    return (
        "(no project rules matched this agent's router selection: add .cursor/rules or skills "
        "under .cursor/skills or .claude/skills)"
    )


def merge_and_cap_selection(
    selected: list[str],
    always_apply: frozenset[str],
    *,
    max_extra: int,
    valid_ids: frozenset[str],
) -> list[str]:
    """Always-include ids first, then up to max_extra more validated ids (stable order)."""
    out: list[str] = []
    seen: set[str] = set()
    for i in sorted(always_apply):
        if i in valid_ids and i not in seen:
            out.append(i)
            seen.add(i)
    n_extra = 0
    for i in selected:
        if i not in valid_ids or i in seen:
            continue
        if i in always_apply:
            continue
        if n_extra >= max_extra:
            break
        out.append(i)
        seen.add(i)
        n_extra += 1
    return out


def fallback_rule_selection(
    catalog: list[RuleCatalogEntry],
    agent_labels: list[str],
    changed_paths: list[str],
    diff_digest: str,
    *,
    max_extra: int,
) -> dict[str, list[str]]:
    """Offline / parse-failure fallback: alwaysApply plus keyword overlap scoring."""
    if not catalog:
        return {label: [] for label in agent_labels}
    valid = catalog_rule_ids(catalog)
    always = frozenset(e.id for e in catalog if e.always_apply)
    pool = [e for e in catalog if e.id not in always]
    hay = f"{diff_digest}\n{' '.join(changed_paths)}".lower()

    def score(entry: RuleCatalogEntry) -> int:
        d = f"{entry.description}\n{entry.id}".lower()
        s = 0
        for word in re.findall(r"[a-z][a-z0-9_-]{2,}", d):
            if word in hay:
                s += 1
        for fragment in re.findall(r"[a-z][a-z0-9_/\\.-]{3,}", entry.id.lower()):
            if fragment in hay:
                s += 2
        return s

    ranked = sorted(pool, key=lambda e: (-score(e), e.id.lower()))
    out: dict[str, list[str]] = {}
    for _label in agent_labels:
        picked = [e.id for e in ranked[: max_extra if max_extra > 0 else 0]]
        out[_label] = merge_and_cap_selection(picked, always, max_extra=max_extra, valid_ids=valid)
    return out


def _path_keyword_score(path: str, hay: str) -> int:
    low = path.lower()
    s = 0
    for word in re.findall(r"[a-z][a-z0-9_-]{2,}", low):
        if word in hay:
            s += 1
    for fragment in re.findall(r"[a-z][a-z0-9_/\\.-]{3,}", low):
        if fragment in hay:
            s += 2
    return s


def fallback_context_path_selection(
    candidate_related_tests: list[str],
    candidate_related_docs: list[str],
    changed_paths: list[str],
    diff_digest: str,
    *,
    max_paths: int,
) -> dict[str, dict[str, list[str]]]:
    """Offline / invalid JSON: rank candidates by overlap with diff and changed paths."""
    hay = f"{diff_digest}\n{' '.join(changed_paths)}".lower()
    out: dict[str, dict[str, list[str]]] = {}
    if candidate_docs := list(candidate_related_docs):
        ranked = sorted(
            candidate_docs,
            key=lambda p: (-_path_keyword_score(p, hay), p.lower()),
        )
        out["documentation"] = {"related_docs": ranked[:max_paths]}
    if candidate_tests := list(candidate_related_tests):
        ranked = sorted(
            candidate_tests,
            key=lambda p: (-_path_keyword_score(p, hay), p.lower()),
        )
        out["test_validator"] = {"related_tests": ranked[:max_paths]}
    return out


def _coerce_selections_payload(data: object) -> dict[str, list[str]] | None:
    if not isinstance(data, dict):
        return None
    raw_sel = data.get("selections")
    if not isinstance(raw_sel, dict):
        return None
    out: dict[str, list[str]] = {}
    for k, v in raw_sel.items():
        if not isinstance(k, str):
            continue
        if not isinstance(v, list):
            continue
        ids: list[str] = []
        for item in v:
            if isinstance(item, str) and item.strip():
                ids.append(item.strip())
        out[k] = ids
    return out


def _parse_router_json_dict(text: str) -> dict[str, object] | None:
    text = text.strip()
    if not text:
        return None
    fence = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.DOTALL)
    if fence:
        text = fence.group(1).strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None
    return data


def finalize_context_paths(
    raw: object,
    candidate_tests: frozenset[str],
    candidate_docs: frozenset[str],
    *,
    max_paths: int,
) -> dict[str, dict[str, list[str]]]:
    """Validate and cap LLM context_paths; unknown paths dropped."""
    if not isinstance(raw, dict):
        return {}
    out: dict[str, dict[str, list[str]]] = {}

    doc_block = raw.get("documentation")
    if isinstance(doc_block, dict) and candidate_docs:
        rd = doc_block.get("related_docs")
        if isinstance(rd, list):
            clean: list[str] = []
            for x in rd:
                if not isinstance(x, str):
                    continue
                s = x.strip()
                if s in candidate_docs and s not in clean:
                    clean.append(s)
                if len(clean) >= max_paths:
                    break
            out["documentation"] = {"related_docs": clean}

    tv_block = raw.get("test_validator")
    if isinstance(tv_block, dict) and candidate_tests:
        rt = tv_block.get("related_tests")
        if isinstance(rt, list):
            clean_t: list[str] = []
            for x in rt:
                if not isinstance(x, str):
                    continue
                s = x.strip()
                if s in candidate_tests and s not in clean_t:
                    clean_t.append(s)
                if len(clean_t) >= max_paths:
                    break
            out["test_validator"] = {"related_tests": clean_t}

    return out


def finalize_selections(
    catalog: list[RuleCatalogEntry],
    raw_by_label: dict[str, list[str]],
    agent_labels: list[str],
    *,
    max_extra: int,
) -> dict[str, list[str]]:
    valid = catalog_rule_ids(catalog)
    always = frozenset(e.id for e in catalog if e.always_apply)
    out: dict[str, list[str]] = {}
    for label in agent_labels:
        picked = list(raw_by_label.get(label, []))
        out[label] = merge_and_cap_selection(picked, always, max_extra=max_extra, valid_ids=valid)
    return out


async def select_rules_for_agents(
    model: BaseChatModel,
    catalog: list[RuleCatalogEntry],
    agent_labels: list[str],
    *,
    diff_digest: str,
    changed_paths: list[str],
    max_extra: int,
    candidate_related_tests: list[str] | None = None,
    candidate_related_docs: list[str] | None = None,
    context_paths_max: int = 5,
) -> tuple[dict[str, list[str]], dict[str, dict[str, list[str]]]]:
    """Batched LLM call: rule ids per agent plus narrowed related_docs / related_tests paths."""
    ct = list(candidate_related_tests or [])
    cd = list(candidate_related_docs or [])
    cand_tests = frozenset(ct)
    cand_docs = frozenset(cd)

    if not catalog and not ct and not cd:
        return {label: [] for label in agent_labels}, {}

    lines = ["## Rules catalog (id | alwaysApply | kind | description)"]
    if catalog:
        for e in catalog:
            aa = "yes" if e.always_apply else "no"
            lines.append(f"- {e.id} | {aa} | {e.kind} | {e.description}")
    else:
        lines.append("(none)")

    hint_lines = ["## Agents"]
    for lb in agent_labels:
        hint = _AGENT_ROUTER_HINTS.get(lb, "Specialist governance agent.")
        hint_lines.append(f"- {lb}: {hint}")

    user = f"""{chr(10).join(hint_lines)}

{chr(10).join(lines)}

## Candidate related tests (repo-relative)
{json.dumps(ct, indent=2)}

## Candidate related docs (repo-relative)
{json.dumps(cd, indent=2)}

## Changed paths (repo-relative)
{json.dumps(changed_paths, indent=2)}

## Diff digest (truncated)
{diff_digest}

## Constraints
- max_extra_non_always_per_agent (rules): {max_extra}
- max_context_paths_per_category (related_docs / related_tests per agent): {context_paths_max}
- Always-apply rule entries are injected for every agent automatically; do not count them against \
max_extra_non_always_per_agent.

Respond with a single JSON object containing "selections" and "context_paths" as described in the \
system message.
"""
    loop = asyncio.get_event_loop()
    messages = [SystemMessage(content=_ROUTER_SYSTEM), HumanMessage(content=user)]

    def _invoke() -> str:
        resp = model.invoke(messages)
        record_chat_usage(model, "rules_router", messages, resp)
        content = getattr(resp, "content", None) or str(resp)
        if isinstance(content, list):
            content = "".join(
                str(x.get("text", x)) if isinstance(x, dict) else str(x) for x in content
            )
        return str(content)

    raw_text = await loop.run_in_executor(None, _invoke)
    raw_dict = _parse_router_json_dict(raw_text)
    if raw_dict is None:
        logger.warning("governance router returned non-JSON; using fallbacks for rules and paths")
        return (
            fallback_rule_selection(
                catalog, agent_labels, changed_paths, diff_digest, max_extra=max_extra
            ),
            fallback_context_path_selection(
                ct, cd, changed_paths, diff_digest, max_paths=context_paths_max
            ),
        )

    selections_parsed = _coerce_selections_payload(raw_dict)
    if selections_parsed is None:
        logger.warning("governance router JSON missing selections; using rule fallback")
        rules_out = fallback_rule_selection(
            catalog, agent_labels, changed_paths, diff_digest, max_extra=max_extra
        )
    else:
        rules_out = finalize_selections(
            catalog, selections_parsed, agent_labels, max_extra=max_extra
        )

    ctx_block = raw_dict.get("context_paths")
    if ctx_block is None:
        if ct or cd:
            logger.warning(
                "governance router JSON missing context_paths; using deterministic path fallback"
            )
            context_out = fallback_context_path_selection(
                ct, cd, changed_paths, diff_digest, max_paths=context_paths_max
            )
        else:
            context_out = {}
    else:
        context_out = finalize_context_paths(
            ctx_block, cand_tests, cand_docs, max_paths=context_paths_max
        )

    return rules_out, context_out


def build_per_agent_rule_prompts(
    repo_root: Path,
    selections: dict[str, list[str]],
) -> tuple[dict[str, str], LoadedRules]:
    """Load each agent's rules from disk once (union), then subset in memory."""
    union_ids: set[str] = set()
    for ids in selections.values():
        union_ids.update(ids)
    if not union_ids:
        empty = LoadedRules()
        placeholder = _empty_rules_placeholder()
        return {label: placeholder for label in selections}, empty

    full = load_rules_by_ids(repo_root, union_ids)
    by_agent: dict[str, str] = {}
    for label, ids in selections.items():
        want = frozenset(ids)
        sub = loaded_rules_subset(full, want)
        block = sub.as_prompt_block()
        if not block.strip():
            block = _empty_rules_placeholder()
        by_agent[label] = block
    return by_agent, full


def router_log_payload(
    catalog: list[RuleCatalogEntry],
    selections: dict[str, list[str]],
    rules_by_agent: dict[str, str],
    *,
    context_paths: dict[str, dict[str, list[str]]] | None = None,
) -> dict[str, object]:
    """Structured fields for emit_gendd (rules.router.completed)."""
    payload: dict[str, object] = {
        "catalog_size": len(catalog),
        "selections": {k: list(v) for k, v in selections.items()},
        "rules_chars_by_agent": {k: len(v) for k, v in rules_by_agent.items()},
    }
    if context_paths is not None:
        payload["context_paths"] = {k: dict(v) for k, v in context_paths.items()}
        payload["context_path_counts"] = {
            k: sum(len(x) for x in v.values()) for k, v in context_paths.items()
        }
    return payload
