from __future__ import annotations

from pydantic import BaseModel, Field


class CodeStandardRow(BaseModel):
    id: str
    tech_stack: str = Field(default="Other", alias="techStack")
    content: str | None = None
    name: str | None = None
    metadata: dict | None = None

    model_config = {"populate_by_name": True, "extra": "ignore"}


class ReusablePromptRow(BaseModel):
    id: str
    name: str | None = None
    domain: str = "Other"
    content: str | None = None
    source_path: str | None = Field(default=None, alias="sourcePath")

    model_config = {"populate_by_name": True, "extra": "ignore"}
