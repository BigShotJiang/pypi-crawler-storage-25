"""Build a lightweight rule/skill catalog (metadata only) for LLM routing."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import frontmatter

from gendd_governance.rules.paths import (
    collect_cursor_rule_paths,
    collect_skill_paths,
    relative_posix,
)

# Skills can be large; only the head is scanned for YAML frontmatter and the first heading.
_INDEX_READ_MAX_BYTES: int = 96_000


@dataclass(frozen=True)
class RuleCatalogEntry:
    """One discoverable Cursor rule or repo skill (bodies are not loaded here)."""

    id: str
    kind: Literal["rule", "skill"]
    description: str
    always_apply: bool


def _first_markdown_heading(markdown: str) -> str:
    for line in (markdown or "").splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            return stripped.lstrip("#").strip() or ""
    return ""


def _description_from_indexed_text(path: Path, text: str) -> tuple[str, bool, str]:
    """Return (description, always_apply, remainder_after_frontmatter_or_empty)."""
    try:
        post = frontmatter.loads(text)
    except Exception:
        body = text
        return path.stem.replace("_", " "), False, body
    meta = post.metadata or {}
    raw_desc = meta.get("description")
    desc = str(raw_desc).strip() if raw_desc is not None else ""
    always = meta.get("alwaysApply") is True
    body = post.content or ""
    if not desc:
        desc = _first_markdown_heading(body) or path.stem.replace("_", " ")
    return desc, always, body


def _read_index_head(path: Path) -> str:
    with path.open(encoding="utf-8", errors="replace") as f:
        return f.read(_INDEX_READ_MAX_BYTES)


def build_rule_catalog(repo_root: Path) -> list[RuleCatalogEntry]:
    """Scan repo for rules/skills and return catalog entries (metadata only)."""
    rp = repo_root.resolve()
    entries: list[RuleCatalogEntry] = []

    for path in collect_cursor_rule_paths(rp):
        rel = relative_posix(rp, path)
        if not rel:
            continue
        try:
            head = _read_index_head(path)
        except OSError:
            continue
        desc, always, _body = _description_from_indexed_text(path, head)
        entries.append(RuleCatalogEntry(id=rel, kind="rule", description=desc, always_apply=always))

    for path in collect_skill_paths(rp):
        rel = relative_posix(rp, path)
        if not rel:
            continue
        try:
            head = _read_index_head(path)
        except OSError:
            continue
        desc, always, _body = _description_from_indexed_text(path, head)
        entries.append(
            RuleCatalogEntry(id=rel, kind="skill", description=desc, always_apply=always)
        )

    return sorted(entries, key=lambda e: e.id.lower())


def catalog_rule_ids(catalog: list[RuleCatalogEntry]) -> frozenset[str]:
    return frozenset(e.id for e in catalog)
