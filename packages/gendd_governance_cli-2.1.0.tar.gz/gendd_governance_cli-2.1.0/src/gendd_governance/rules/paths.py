"""Discover Cursor rule and skill paths under a repository (no file body reads)."""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

RULE_SUFFIXES: frozenset[str] = frozenset({".md", ".mdc"})


def is_safe_under_repo(repo_root: Path, path: Path) -> bool:
    """True if resolved path stays under resolved repo root."""
    try:
        rp = repo_root.resolve()
        resolved = path.resolve()
        resolved.relative_to(rp)
        return True
    except (ValueError, OSError):
        return False


def relative_posix(repo_root: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(repo_root.resolve()).as_posix()
    except ValueError:
        return path.name


def collect_cursor_rule_paths(repo_root: Path) -> list[Path]:
    rules_dir = repo_root / ".cursor" / "rules"
    if not rules_dir.is_dir():
        return []
    out: list[Path] = []
    for p in rules_dir.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in RULE_SUFFIXES:
            continue
        if not is_safe_under_repo(repo_root, p):
            logger.warning("skip rule path outside repo: %s", p)
            continue
        out.append(p)
    return sorted(out, key=lambda x: x.as_posix().lower())


def collect_skill_paths(repo_root: Path) -> list[Path]:
    patterns = (".cursor/skills/**/SKILL.md", ".claude/skills/**/SKILL.md")
    seen: set[Path] = set()
    for pattern in patterns:
        for p in repo_root.glob(pattern):
            if not p.is_file():
                continue
            if not is_safe_under_repo(repo_root, p):
                logger.warning("skip skill path outside repo: %s", p)
                continue
            seen.add(p.resolve())
    return sorted(seen, key=lambda x: x.as_posix().lower())
