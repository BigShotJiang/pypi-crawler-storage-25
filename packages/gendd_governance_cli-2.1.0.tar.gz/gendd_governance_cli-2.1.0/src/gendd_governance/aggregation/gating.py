from __future__ import annotations

from dataclasses import dataclass

from gendd_governance.aggregation.findings import AggregatedResult, Severity


@dataclass(frozen=True)
class GateConfig:
    max_critical: int = 0
    max_high: int = 0
    max_medium: int = 999
    max_low: int = 999
    advisory_mode: bool = False


def evaluate_gate(result: AggregatedResult, config: GateConfig) -> AggregatedResult:
    """Set passed=False when severity counts exceed thresholds (unless advisory)."""
    if config.advisory_mode:
        out = result.model_copy()
        out.passed = True
        out.advisory = True
        return out

    by = result.by_severity
    failed = False
    reasons: list[str] = []

    def check(sev: Severity, max_allowed: int) -> None:
        nonlocal failed
        n = by.get(sev.value, 0)
        if n > max_allowed:
            failed = True
            reasons.append(f"{sev.value}: {n} > max {max_allowed}")

    check(Severity.CRITICAL, config.max_critical)
    check(Severity.HIGH, config.max_high)
    check(Severity.MEDIUM, config.max_medium)
    check(Severity.LOW, config.max_low)

    out = result.model_copy()
    out.passed = not failed
    if failed:
        out.message = (out.message + " | " if out.message else "") + "GATE: " + "; ".join(reasons)
    return out
