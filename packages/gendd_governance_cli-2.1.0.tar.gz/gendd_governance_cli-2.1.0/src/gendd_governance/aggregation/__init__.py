"""Aggregated findings and gating. Import from ``gendd_governance.aggregation.*`` submodules."""
