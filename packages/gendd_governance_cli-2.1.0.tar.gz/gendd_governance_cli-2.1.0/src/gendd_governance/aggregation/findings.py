from __future__ import annotations

from collections.abc import Sequence
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field

_PLAN_MODE_PROMPT_MAX_CHARS = 400


class Severity(StrEnum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Finding(BaseModel):
    """Single governance finding from an agent."""

    agent: str
    severity: Severity
    title: str
    description: str = ""
    file: str | None = None
    line: int | None = None
    rule_id: str | None = None
    suggested_fix: str | None = None
    plan_mode_prompt: str | None = None

    model_config = {"extra": "ignore"}


def _trim_plan_mode_text(text: str, max_chars: int = _PLAN_MODE_PROMPT_MAX_CHARS) -> str:
    text = text.strip()
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3] + "..."


def resolved_plan_mode_prompt(
    finding: Finding,
    *,
    changed_files: Sequence[str] | None = None,
    related_tests: Sequence[str] | None = None,
) -> str | None:
    """Text for console/SARIF: model-supplied plan_mode_prompt or a minimal fallback."""
    explicit = (finding.plan_mode_prompt or "").strip()
    if explicit:
        return _trim_plan_mode_text(explicit)

    suggested = (finding.suggested_fix or "").strip()
    if not suggested:
        return None

    goal_line = suggested.splitlines()[0].strip()
    if len(goal_line) > 200:
        goal_line = goal_line[:197] + "..."

    lines: list[str] = [f"Goal: {goal_line}"]
    paths: list[str] = []
    if finding.file:
        loc = finding.file + (f" (~L{finding.line})" if finding.line is not None else "")
        paths.append(loc)

    cf = list(changed_files or ())
    for p in cf:
        if p != finding.file and p not in paths:
            paths.append(p)
        if len(paths) >= 5:
            break

    rt = list(related_tests or ())
    for p in rt:
        if p not in paths:
            paths.append(p)
        if len(paths) >= 6:
            break

    if paths:
        lines.append("Read first: " + ", ".join(paths[:6]))

    lines.append("Deliver: plan with decision points only, no code.")
    return _trim_plan_mode_text("\n".join(lines))


class LlmCallTokenUsage(BaseModel):
    """Per-LLM-call token accounting (API, model tokenizer, or heuristic)."""

    call_id: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None
    method: str = "api"


class RunSummary(BaseModel):
    """CLI version, resolved model, and token usage for a governance run."""

    cli_version: str
    model_provider: str
    model_name: str
    context_window_tokens: int | None = None
    max_prompt_tokens: int | None = None
    max_total_tokens: int | None = None
    max_prompt_vs_context_pct: float | None = None
    total_input_tokens: int | None = None
    total_output_tokens: int | None = None
    total_tokens: int | None = None
    llm_calls: list[LlmCallTokenUsage] = Field(default_factory=list)
    notes: str = ""


class AggregatedResult(BaseModel):
    """Consolidated output after aggregation (before optional PR post)."""

    findings: list[Finding] = Field(default_factory=list)
    by_severity: dict[str, int] = Field(default_factory=dict)
    passed: bool = True
    advisory: bool = False
    message: str = ""
    run: RunSummary | None = None

    def model_dump_json_pretty(self) -> str:
        return self.model_dump_json(indent=2)

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "findings": [f.model_dump() for f in self.findings],
            "by_severity": self.by_severity,
            "passed": self.passed,
            "advisory": self.advisory,
            "message": self.message,
        }
        if self.run is not None:
            out["run"] = self.run.model_dump()
        return out
