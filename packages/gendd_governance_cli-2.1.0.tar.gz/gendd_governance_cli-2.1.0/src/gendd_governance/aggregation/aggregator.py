from __future__ import annotations

from collections import Counter

from gendd_governance.aggregation.findings import AggregatedResult, Finding, Severity


def aggregate_findings(findings: list[Finding], advisory: bool = False) -> AggregatedResult:
    """Merge and count findings by severity."""
    by_sev = Counter(f.severity.value for f in findings)
    by_severity = {s.value: by_sev.get(s.value, 0) for s in Severity}
    msg_parts = [f"{k}: {v}" for k, v in sorted(by_severity.items()) if v]
    return AggregatedResult(
        findings=list(findings),
        by_severity=by_severity,
        passed=True,
        advisory=advisory,
        message="; ".join(msg_parts) if msg_parts else "No findings",
    )
