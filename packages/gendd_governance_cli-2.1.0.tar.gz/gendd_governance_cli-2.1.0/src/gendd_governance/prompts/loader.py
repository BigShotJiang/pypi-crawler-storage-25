from __future__ import annotations

from pathlib import Path

_SYSTEM_DIR = Path(__file__).resolve().parent / "system"


def load_system_prompt(stem: str) -> str:
    """Load a single prompt file from ``prompts/system/{stem}.txt``."""
    path = _SYSTEM_DIR / f"{stem}.txt"
    if not path.is_file():
        raise FileNotFoundError(f"Missing system prompt file: {path}")
    return path.read_text(encoding="utf-8").strip()


def build_agent_system_prompt(role_stem: str) -> str:
    """Combine a role-specific system prompt with the shared JSON findings contract."""
    role = load_system_prompt(role_stem)
    contract = load_system_prompt("json_findings_output_contract")
    return f"{role}\n\n{contract}"


def build_super_phase_system_prompt(role_stem: str) -> str:
    """Combine a super-phase role prompt with the super-phase JSON findings contract."""
    role = load_system_prompt(role_stem)
    contract = load_system_prompt("json_findings_super_phase_contract")
    return f"{role}\n\n{contract}"
