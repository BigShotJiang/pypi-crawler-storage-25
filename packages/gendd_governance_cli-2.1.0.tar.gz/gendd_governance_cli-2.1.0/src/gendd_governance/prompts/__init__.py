"""LLM system prompts live in ``prompts/system/*.txt`` (one file per role + shared contract)."""

from gendd_governance.prompts.loader import build_agent_system_prompt, load_system_prompt

__all__ = ["build_agent_system_prompt", "load_system_prompt"]
