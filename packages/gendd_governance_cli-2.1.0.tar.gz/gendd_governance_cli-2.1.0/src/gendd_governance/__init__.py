"""GenDD Agentic Governance — multi-agent SDLC governance engine."""

__version__ = "0.1.0"
