from __future__ import annotations

import os
import subprocess
from pathlib import Path

from gendd_governance.aggregation.findings import AggregatedResult
from gendd_governance.context.github import infer_pr_number_from_github_ref, post_pr_comment_rest
from gendd_governance.output.console import format_plain_text


def maybe_post_pr_comment(
    repo_root: Path,
    result: AggregatedResult,
    enabled: bool,
) -> bool:
    """Post summary to PR via `gh pr comment` or GitHub REST."""
    if not enabled:
        return False
    ref = os.environ.get("GITHUB_REF")
    num = infer_pr_number_from_github_ref(ref)
    if num is None:
        return False
    body = "## GenDD Governance\n\n```\n" + format_plain_text(result)[:60000] + "\n```"
    try:
        p = subprocess.run(
            ["gh", "pr", "comment", str(num), "--body", body],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        if p.returncode == 0:
            return True
    except (FileNotFoundError, OSError):
        pass

    token = os.environ.get("GITHUB_TOKEN")
    repo = os.environ.get("GITHUB_REPOSITORY")
    if token and repo:
        return post_pr_comment_rest(token, repo, num, body)
    return False
