"""Output sinks (console, json, sarif, PR). Import from ``gendd_governance.output.*`` submodules."""
