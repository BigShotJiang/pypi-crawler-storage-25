from __future__ import annotations

import logging
import os
import shutil
import sys
from dataclasses import dataclass
from io import StringIO

from rich import box
from rich.align import Align
from rich.console import Console, Group
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from gendd_governance.aggregation.findings import (
    AggregatedResult,
    RunSummary,
    Severity,
    resolved_plan_mode_prompt,
)
from gendd_governance.observability.logging import write_stderr_atomic

logger = logging.getLogger(__name__)

_PATH_LIST_CAP = 80


def format_run_summary_footer(run: RunSummary) -> str:
    """Single-line CLI version, model, token totals, and optional context-window hint."""
    parts: list[str] = [
        f"CLI {run.cli_version}",
        f"provider {run.model_provider}",
        f"model {run.model_name}",
    ]
    tin, tout, ttot = run.total_input_tokens, run.total_output_tokens, run.total_tokens
    if tin is not None or tout is not None or ttot is not None:
        parts.append(f"LLM calls {len(run.llm_calls)}")
        parts.append(f"tokens in={tin} out={tout} total={ttot}")
    if run.max_prompt_tokens is not None:
        ctx = run.context_window_tokens
        if ctx:
            pct = run.max_prompt_vs_context_pct
            pct_s = f" ({pct}% of context window)" if pct is not None else ""
            parts.append(f"max prompt ≈{run.max_prompt_tokens} / ctx {ctx}{pct_s}")
        else:
            parts.append(f"max prompt ≈{run.max_prompt_tokens} tok")
    if run.notes.strip():
        parts.append(run.notes.strip())
    return " · ".join(parts)


# Ai-super can yield many findings; unbounded Markdown panels overwhelm embedded terminals.
_DEFAULT_MAX_FINDING_PANELS = 25


def _console_width_chars() -> int:
    """Clamp width: some hosts report oversized columns and Rich then lays out poorly."""
    raw = (os.environ.get("GENDD_CONSOLE_WIDTH") or "").strip()
    if raw.isdigit():
        return max(40, min(int(raw), 200))
    try:
        w = shutil.get_terminal_size(fallback=(100, 24)).columns
    except OSError:
        w = 100
    return max(56, min(w, 100))


def _max_finding_detail_panels() -> int:
    raw = (os.environ.get("GENDD_CONSOLE_MAX_FINDING_PANELS") or "").strip()
    if raw.isdigit():
        return max(1, min(int(raw), 500))
    return _DEFAULT_MAX_FINDING_PANELS


def _use_plain_report() -> bool:
    """Plain-text report when explicitly requested (no Rich / panels).

    Default is Rich (panels, tables, colors). Some Win/Git Bash setups rarely crash in native
    Rich render paths; use ``GENDD_CONSOLE_PLAIN=1`` if you need the ASCII-only report there.
    """

    return (os.environ.get("GENDD_CONSOLE_PLAIN") or "").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )


def _use_ascii_box_borders() -> bool:
    """Use Rich's ASCII (``+---``) box drawing instead of rounded Unicode panels.

    Default is rounded Unicode everywhere (cleaner). Opt in to ASCII with ``GENDD_CONSOLE_ASCII=1``
    (piping, hosts that garble wide chars). On Windows only, ``GENDD_CONSOLE_UNICODE=0``
    also selects ASCII for compatibility with older configuration.
    """
    if (os.environ.get("GENDD_CONSOLE_ASCII") or "").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    ):
        return True
    u = (os.environ.get("GENDD_CONSOLE_UNICODE") or "").strip().lower()
    if u in ("0", "false", "no", "off") and sys.platform == "win32":
        return True
    return False


def _governance_console() -> Console:
    """Rich Console: stderr + ``safe_box`` + rounded panels by default (see `_panel_box`).

    Do **not** force ``legacy_windows=True`` on all Windows hosts: Git Bash / Cursor use a
    Unix-like TTY; legacy mode can crash or truncate output mid-render.
    """
    return Console(
        stderr=True,
        emoji=False,
        safe_box=True,
        width=_console_width_chars(),
    )


def _governance_console_stringio() -> tuple[Console, StringIO]:
    """Rich Console writing to an in-memory buffer (render, then one atomic stderr write)."""

    buf = StringIO()
    console = Console(
        file=buf,
        width=_console_width_chars(),
        emoji=False,
        safe_box=True,
        force_terminal=True,
    )
    return console, buf


def _panel_box() -> box.Box:
    return box.ASCII if _use_ascii_box_borders() else box.ROUNDED


@dataclass(frozen=True)
class ConsoleRunScope:
    """What each agent sees: shared rules bundle and file paths in scope."""

    command: str
    scope_description: str | None
    agent_names: list[str]
    rules_cursor_count: int
    rules_skill_count: int
    rule_paths: list[str]
    changed_files: list[str]
    related_tests: list[str]
    related_docs: list[str]
    related_code: list[str]
    rules_mode: str = "full"
    catalog_rule_paths: list[str] | None = None


def _append_path_list(lines: list[str], heading: str, paths: list[str]) -> None:
    if not paths:
        lines.append(f"[bold]{heading}[/bold] [dim](0)[/dim]")
        return
    lines.append(f"[bold]{heading}[/bold] ({len(paths)}):")
    shown = paths[:_PATH_LIST_CAP]
    for p in shown:
        lines.append(f"  [dim]{p}[/dim]")
    rest = len(paths) - _PATH_LIST_CAP
    if rest > 0:
        lines.append(f"  [dim]… and {rest} more[/dim]")


def _print_run_scope(console: Console, scope: ConsoleRunScope) -> None:
    lines: list[str] = []
    lines.append(f"[bold]Command[/bold]  {scope.command}")
    if scope.scope_description:
        lines.append(f"[bold]Diff scope[/bold]  {scope.scope_description}")
    lines.append(f"[bold]Agents[/bold]  ({len(scope.agent_names)}): {', '.join(scope.agent_names)}")
    total_rules = scope.rules_cursor_count + scope.rules_skill_count
    if scope.rules_mode == "select" and scope.catalog_rule_paths is not None:
        n_cat = len(scope.catalog_rule_paths)
        lines.append(
            f"[bold]Rules[/bold]  ([cyan]select[/cyan] mode): "
            f"{scope.rules_cursor_count} cursor rules + {scope.rules_skill_count} skills "
            f"injected ([cyan]{total_rules}[/cyan] items) "
            f"from [dim]{n_cat}[/dim] cataloged paths"
        )
        skipped = sorted(set(scope.catalog_rule_paths) - set(scope.rule_paths))
        _append_path_list(lines, "Rule & skill paths (injected)", scope.rule_paths)
        if skipped:
            _append_path_list(lines, "Cataloged but not injected", skipped)
    else:
        lines.append(
            f"[bold]Rules[/bold]  ([cyan]full[/cyan] load, shared by each agent): "
            f"{scope.rules_cursor_count} cursor rules + {scope.rules_skill_count} skills "
            f"= [cyan]{total_rules}[/cyan] items"
        )
        _append_path_list(lines, "Rule & skill paths", scope.rule_paths)
    _append_path_list(lines, "Changed files (diff)", scope.changed_files)
    rel_total = len(scope.related_tests) + len(scope.related_docs) + len(scope.related_code)
    if rel_total:
        lines.append(
            f"[bold]Related context[/bold]  "
            f"tests: {len(scope.related_tests)}, "
            f"docs: {len(scope.related_docs)}, "
            f"imports: {len(scope.related_code)}"
        )
        _append_path_list(lines, "Related tests", scope.related_tests)
        _append_path_list(lines, "Related docs", scope.related_docs)
        _append_path_list(lines, "Related imports", scope.related_code)
    lines.append("")
    body = "\n".join(lines).rstrip()
    console.print(
        Panel(
            body,
            title="[bold]Run scope[/bold]",
            border_style="dim",
            box=_panel_box(),
        )
    )


_SEV_ORDER = ("critical", "high", "medium", "low", "info")


def _severity_counts_table(by_severity: dict[str, int]) -> Table:
    tbl = Table(
        box=box.ASCII if _use_ascii_box_borders() else box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold",
        expand=False,
        pad_edge=False,
    )
    extras = sorted(k for k in by_severity if k not in _SEV_ORDER)
    for key in _SEV_ORDER:
        tbl.add_column(key.capitalize(), justify="center")
    for key in extras:
        tbl.add_column(key, justify="center")
    row = [str(by_severity.get(key, 0)) for key in _SEV_ORDER]
    row.extend(str(by_severity[key]) for key in extras)
    tbl.add_row(*row)
    return tbl


def _severity_border(sev: Severity) -> str:
    if sev == Severity.CRITICAL:
        return "red"
    if sev == Severity.HIGH:
        return "red1"
    if sev == Severity.MEDIUM:
        return "yellow"
    if sev == Severity.LOW:
        return "blue"
    return "dim"


def _format_plain_report_body(
    result: AggregatedResult,
    run_scope: ConsoleRunScope | None,
) -> str:
    """Full governance report without Rich (safe on Git Bash / embedded Windows terminals)."""
    lines: list[str] = [
        "GenDD Governance",
        (
            f"Status: {'PASSED' if result.passed else 'FAILED'}  "
            f"Advisory: {'yes' if result.advisory else 'no'}"
        ),
    ]
    if result.message.strip():
        lines.append(f"Message: {result.message.strip()}")
    if result.by_severity:
        lines.append(
            "Severity counts: "
            + ", ".join(f"{k}={v}" for k, v in sorted(result.by_severity.items()))
        )
    lines.append("")
    if run_scope is not None:
        lines.append("--- Run scope ---")
        lines.append(f"Command: {run_scope.command}")
        if run_scope.scope_description:
            lines.append(f"Diff scope: {run_scope.scope_description}")
        lines.append(f"Agents ({len(run_scope.agent_names)}): {', '.join(run_scope.agent_names)}")
        lines.append(
            f"Rules ({run_scope.rules_mode}): {run_scope.rules_cursor_count} cursor rules + "
            f"{run_scope.rules_skill_count} skills"
        )
        if run_scope.rule_paths:
            label = (
                "Rule & skill paths (injected)"
                if run_scope.rules_mode == "select"
                else "Rule & skill paths"
            )
            lines.append(f"{label}:")
            for p in run_scope.rule_paths[:_PATH_LIST_CAP]:
                lines.append(f"  {p}")
        if run_scope.rules_mode == "select" and run_scope.catalog_rule_paths:
            skipped = sorted(set(run_scope.catalog_rule_paths) - set(run_scope.rule_paths))
            if skipped:
                lines.append("Cataloged but not injected:")
                for p in skipped[:_PATH_LIST_CAP]:
                    lines.append(f"  {p}")
        if run_scope.changed_files:
            lines.append("Changed files (diff):")
            for p in run_scope.changed_files[:_PATH_LIST_CAP]:
                lines.append(f"  {p}")
        rel = (
            len(run_scope.related_tests) + len(run_scope.related_docs) + len(run_scope.related_code)
        )
        if rel:
            lines.append(
                f"Related context — tests: {len(run_scope.related_tests)}, "
                f"docs: {len(run_scope.related_docs)}, imports: {len(run_scope.related_code)}"
            )
            for label, paths in (
                ("Related tests", run_scope.related_tests),
                ("Related docs", run_scope.related_docs),
                ("Related imports", run_scope.related_code),
            ):
                if paths:
                    lines.append(f"{label}:")
                    for p in paths[:40]:
                        lines.append(f"  {p}")
        lines.append("")

    lines.append("--- Findings ---")
    if not result.findings:
        lines.append("(none)")
    for f in result.findings:
        loc = ""
        if f.file:
            loc = f"  {f.file}" + (f":{f.line}" if f.line is not None else "")
        lines.append(f"[{f.severity.value}] {f.agent}: {f.title}{loc}")
        if f.description.strip():
            for block in f.description.strip().splitlines():
                lines.append(f"  {block}")
        if f.suggested_fix and f.suggested_fix.strip():
            lines.append("  Suggested fix:")
            for block in f.suggested_fix.strip().splitlines():
                lines.append(f"    {block}")
        plan = resolved_plan_mode_prompt(
            f,
            changed_files=run_scope.changed_files if run_scope is not None else None,
            related_tests=run_scope.related_tests if run_scope is not None else None,
        )
        if plan:
            lines.append("  Plan-mode prompt:")
            for block in plan.splitlines():
                lines.append(f"    {block}")
        lines.append("")
    if result.run is not None:
        lines.append("--- Run metadata ---")
        lines.append(format_run_summary_footer(result.run))
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def _print_plain_report(
    result: AggregatedResult,
    run_scope: ConsoleRunScope | None,
) -> None:
    write_stderr_atomic(_format_plain_report_body(result, run_scope))


def _print_console_report_rich(
    result: AggregatedResult,
    *,
    run_scope: ConsoleRunScope | None,
) -> None:
    # Avoid soft_wrap=True: it sets no_wrap + overflow ignore on print and clips long
    # Markdown/lines instead of folding to the terminal width.
    # Render to a buffer then one atomic stderr write so worker-thread logging and
    # gendd: progress lines cannot splice into the middle of Rich's many small writes.
    console, buf = _governance_console_stringio()
    if run_scope is not None:
        _print_run_scope(console, run_scope)
    status = "[green]PASSED[/green]" if result.passed else "[red]FAILED[/red]"
    adv = "yes" if result.advisory else "no"
    header = Group(
        f"[bold]GenDD Governance[/bold]  {status}  [dim]Advisory:[/dim] {adv}",
    )
    console.print(Panel(header, border_style="cyan", box=_panel_box()))

    summary_body: list = []
    if result.message.strip():
        summary_body.append(Markdown(result.message))
    if result.by_severity:
        if summary_body:
            summary_body.append(Text(""))
        summary_body.append(Align.center(Text("Severity counts", style="bold")))
        summary_body.append(Align.center(_severity_counts_table(result.by_severity)))
    if summary_body:
        console.print(
            Panel(
                Group(*summary_body),
                title="[bold]Summary[/bold]",
                border_style="blue",
                box=_panel_box(),
            )
        )

    if result.findings:
        table = Table(
            title="Findings overview",
            box=_panel_box(),
            show_header=True,
            header_style="bold cyan",
            expand=False,
        )
        table.add_column("Severity", overflow="fold", max_width=10)
        table.add_column("Agent", overflow="fold", max_width=18)
        table.add_column("Title", overflow="fold")
        table.add_column("Location", overflow="fold", max_width=36)
        for f in result.findings:
            loc = ""
            if f.file:
                loc = f"{f.file}" + (f":{f.line}" if f.line is not None else "")
            table.add_row(
                f.severity.value,
                f.agent,
                f.title,
                loc,
            )
        console.print(table)

    detailed = [
        f
        for f in result.findings
        if (
            f.description.strip()
            or (f.suggested_fix or "").strip()
            or (f.plan_mode_prompt or "").strip()
        )
    ]
    cap = _max_finding_detail_panels()
    for f in detailed[:cap]:
        parts: list[str] = []
        if f.description.strip():
            parts.append(f.description.strip())
        if f.suggested_fix and f.suggested_fix.strip():
            parts.append("**Suggested fix**\n\n" + f.suggested_fix.strip())
        plan_block = resolved_plan_mode_prompt(
            f,
            changed_files=run_scope.changed_files if run_scope is not None else None,
            related_tests=run_scope.related_tests if run_scope is not None else None,
        )
        if plan_block:
            parts.append("**Plan-mode prompt**\n\n" + plan_block)
        body = "\n\n".join(parts)
        title = f"[{f.severity.value}] {f.agent}: {f.title}"
        console.print(
            Panel(
                Markdown(body),
                title=title,
                title_align="left",
                border_style=_severity_border(f.severity),
                box=_panel_box(),
            )
        )
    rest = len(detailed) - cap
    if rest > 0:
        console.print(
            f"[dim]{rest} more findings with detail not shown here (see JSON/SARIF output, "
            f"or set GENDD_CONSOLE_MAX_FINDING_PANELS)[/dim]"
        )

    if result.run is not None:
        console.print(Text(format_run_summary_footer(result.run), style="dim"))

    write_stderr_atomic(buf.getvalue())


def print_console_report(
    result: AggregatedResult,
    *,
    run_scope: ConsoleRunScope | None = None,
) -> None:
    if _use_plain_report():
        _print_plain_report(result, run_scope)
        return
    try:
        _print_console_report_rich(result, run_scope=run_scope)
    except Exception as exc:
        logger.warning(
            "Rich console report failed (%s); falling back to plain text",
            exc,
            exc_info=True,
        )
        write_stderr_atomic(
            "GenDD Governance (plain-text fallback; fix Rich/theme/encoding and retry)\n"
            + format_plain_text(result)
        )


def format_plain_text(result: AggregatedResult) -> str:
    lines = [
        f"Passed: {result.passed}",
        f"Message: {result.message}",
        "",
    ]
    for f in result.findings:
        loc = f"{f.file}:{f.line}" if f.file else ""
        lines.append(f"[{f.severity.value}] {f.agent} {f.title} {loc}")
        if f.description:
            lines.append(f"  {f.description[:500]}")
    return "\n".join(lines)
