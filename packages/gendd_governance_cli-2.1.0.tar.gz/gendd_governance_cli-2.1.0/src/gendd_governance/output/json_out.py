from __future__ import annotations

import json
from pathlib import Path

from gendd_governance.aggregation.findings import AggregatedResult


def write_json_report(path: Path | None, result: AggregatedResult) -> str:
    text = json.dumps(result.to_dict(), indent=2)
    if path:
        path.write_text(text, encoding="utf-8")
    return text
