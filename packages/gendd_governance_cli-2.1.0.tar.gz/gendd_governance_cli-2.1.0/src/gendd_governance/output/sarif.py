from __future__ import annotations

import json
from pathlib import Path

from gendd_governance.aggregation.findings import (
    AggregatedResult,
    Finding,
    resolved_plan_mode_prompt,
)


def _result_from_finding(f: Finding, idx: int) -> dict:
    loc = None
    if f.file:
        phys: dict = {"artifactLocation": {"uri": f.file}}
        if f.line is not None:
            phys["region"] = {"startLine": f.line}
        loc = {"physicalLocation": phys}
    text = f"{f.title}\n{f.description}"
    plan = resolved_plan_mode_prompt(f)
    if plan:
        text = f"{text}\n\nPlan-mode prompt:\n{plan}"
    return {
        "ruleId": f.rule_id or f.agent,
        "level": _sarif_level(f.severity.value),
        "message": {"text": text},
        "locations": [loc] if loc else [],
    }


def _sarif_level(severity: str) -> str:
    if severity in ("critical", "high"):
        return "error"
    if severity == "medium":
        return "warning"
    return "note"


def findings_to_sarif(result: AggregatedResult) -> dict:
    return {
        "version": "2.1.0",
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "gendd-governance-cli",
                        "informationUri": "https://github.com/hatchworks/gendd-agentic-governance",
                    }
                },
                "results": [_result_from_finding(f, i) for i, f in enumerate(result.findings)],
            }
        ],
    }


def write_sarif(path: Path | None, result: AggregatedResult) -> str:
    doc = findings_to_sarif(result)
    text = json.dumps(doc, indent=2)
    if path:
        path.write_text(text, encoding="utf-8")
    return text
