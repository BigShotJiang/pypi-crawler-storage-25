from __future__ import annotations

import re
from dataclasses import dataclass, field

import httpx

OSV_BATCH_URL = "https://api.osv.dev/v1/querybatch"


@dataclass
class OsvVulnSummary:
    text: str = ""
    raw_results: list[dict] = field(default_factory=list)


def _guess_packages_from_diff(diff_text: str) -> list[dict]:
    """Heuristic: npm, PyPI package mentions in diff."""
    queries: list[dict] = []
    seen: set[tuple[str, str, str]] = set()

    # package.json: "name": "1.2.3"
    for m in re.finditer(r'["\']([@\w\-./]+)["\']\s*:\s*["\']?([\^~>=]*)([\d][\w.\-]*)', diff_text):
        name, _rng, ver = m.group(1), m.group(2), m.group(3)
        if "/" in name and not name.startswith("@"):
            continue
        key = ("npm", name, ver)
        if key not in seen and ver:
            seen.add(key)
            queries.append({"package": {"ecosystem": "npm", "name": name}, "version": ver})

    # requirements: name==version
    for m in re.finditer(r"^\+([a-zA-Z0-9_\-\[\]]+)==([\d][\w.\-]*)", diff_text, re.MULTILINE):
        name, ver = m.group(1), m.group(2)
        key = ("PyPI", name.lower(), ver)
        if key not in seen:
            seen.add(key)
            queries.append({"package": {"ecosystem": "PyPI", "name": name}, "version": ver})

    return queries[:50]


def query_osv_batch(queries: list[dict]) -> list[dict]:
    if not queries:
        return []
    body = {"queries": queries}
    with httpx.Client(timeout=60.0) as client:
        r = client.post(OSV_BATCH_URL, json=body, headers={"Content-Type": "application/json"})
        r.raise_for_status()
        data = r.json()
    return data.get("results") or []


def build_osv_summary_for_diff(diff_text: str) -> OsvVulnSummary:
    """Query OSV for guessed packages from diff; return human-readable summary."""
    queries = _guess_packages_from_diff(diff_text)
    if not queries:
        return OsvVulnSummary(text="(No third-party packages detected in diff for OSV lookup.)")

    try:
        results = query_osv_batch(queries)
    except Exception as e:
        return OsvVulnSummary(text=f"OSV query failed: {e}")

    lines: list[str] = []
    for i, q in enumerate(queries):
        res = results[i] if i < len(results) else {}
        vulns = res.get("vulns") or []
        pkg = q.get("package", {})
        name = pkg.get("name", "?")
        ver = q.get("version", "?")
        eco = pkg.get("ecosystem", "?")
        if not vulns:
            lines.append(f"- {eco} {name}@{ver}: no known vulns in OSV (batch result).")
            continue
        ids = [v.get("id", "?") for v in vulns[:10]]
        lines.append(f"- {eco} {name}@{ver}: {len(vulns)} vuln(s) e.g. {', '.join(ids)}")
    return OsvVulnSummary(text="\n".join(lines), raw_results=results)
