from __future__ import annotations

import pyfiglet
from rich.console import Console

from gendd_governance.wizard.style import print_gradient_line


def print_wizard_banner(console: Console | None = None, subtitle: str | None = None) -> None:
    c = console or Console()
    fig = pyfiglet.Figlet(font="slant")
    c.print(fig.renderText("GenDD"), style="bold cyan", end="")
    print_gradient_line(c, "Agentic Governance")
    if subtitle:
        c.print(subtitle, style="dim")
    c.print()
