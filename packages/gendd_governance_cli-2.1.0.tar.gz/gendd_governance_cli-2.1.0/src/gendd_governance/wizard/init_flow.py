from __future__ import annotations

import sys
from typing import Literal

import questionary
from questionary import Choice

Provider = Literal["vertex", "openai", "azure_openai", "bedrock", "anthropic"]

QUESTIONARY_STYLE = questionary.Style(
    [
        ("qmark", "fg:cyan bold"),
        ("question", "bold"),
        ("answer", "fg:green"),
        ("pointer", "fg:cyan bold"),
        ("highlighted", "fg:cyan bold"),
        ("selected", "fg:green"),
        ("separator", "fg:#6c6c6c"),
        ("instruction", "fg:#6c6c6c"),
    ]
)


def default_env_text() -> str:
    """Non-interactive template aligned with `.env.example` / Settings."""
    return """# GenDD Agentic Governance — local config (edit as needed)
# Model provider: vertex | openai | azure_openai | bedrock | anthropic
GENDD_MODEL_PROVIDER=vertex
GENDD_VERTEX_MODEL=gemini-2.0-flash-001
GENDD_VERTEX_LOCATION=us-central1
# GOOGLE_CLOUD_PROJECT=

# OpenAI / Azure (when not using Vertex)
# OPENAI_API_KEY=
# GENDD_OPENAI_MODEL=gpt-4o-mini
# AZURE_OPENAI_API_KEY=
# AZURE_OPENAI_ENDPOINT=
# AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o-mini
# AZURE_OPENAI_API_VERSION=2024-08-01-preview

# AWS Bedrock (GENDD_MODEL_PROVIDER=bedrock; use AWS credential chain)
# GENDD_BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20240620-v1:0
# GENDD_BEDROCK_REGION=us-east-1
# AWS_REGION=us-east-1

# Anthropic API (GENDD_MODEL_PROVIDER=anthropic)
# ANTHROPIC_API_KEY=
# GENDD_ANTHROPIC_MODEL=claude-3-5-sonnet-20241022

# Gating — the CLI exits with failure when finding counts exceed these limits (unless advisory).
# GENDD_ADVISORY_MODE: If true, always exit 0; findings still print; the gate never fails the run.
GENDD_ADVISORY_MODE=false
# GENDD_GATE_MAX_CRITICAL: Max CRITICAL findings allowed (0 = any critical fails the gate).
GENDD_GATE_MAX_CRITICAL=0
# GENDD_GATE_MAX_HIGH: Max HIGH findings allowed (0 = any high fails the gate).
GENDD_GATE_MAX_HIGH=0
# GENDD_GATE_MAX_MEDIUM: Max MEDIUM findings allowed.
GENDD_GATE_MAX_MEDIUM=999
# GENDD_GATE_MAX_LOW: Max LOW findings allowed.
GENDD_GATE_MAX_LOW=999

# GitHub PR comments (optional)
# GITHUB_TOKEN=
# GITHUB_REPOSITORY=owner/repo
"""


def _prompt_text(message: str, default: str = "") -> str:
    r = questionary.text(message, default=default, style=QUESTIONARY_STYLE).ask()
    if r is None:
        raise KeyboardInterrupt
    return r.strip()


def _prompt_password(message: str) -> str:
    r = questionary.password(message, style=QUESTIONARY_STYLE).ask()
    if r is None:
        raise KeyboardInterrupt
    return r.strip()


def _prompt_confirm(message: str, default: bool = True) -> bool:
    r = questionary.confirm(message, default=default, style=QUESTIONARY_STYLE).ask()
    if r is None:
        raise KeyboardInterrupt
    return bool(r)


def _prompt_non_negative_int(message: str, default: int) -> int:
    default_s = str(default)
    while True:
        r = questionary.text(message, default=default_s, style=QUESTIONARY_STYLE).ask()
        if r is None:
            raise KeyboardInterrupt
        raw = r.strip() or default_s
        try:
            v = int(raw)
        except ValueError:
            print("Enter a whole number (for example 0 or 999).", file=sys.stderr)
            continue
        if v < 0:
            print("Enter zero or a positive integer.", file=sys.stderr)
            continue
        return v


def _collect_gate_env_lines() -> list[str]:
    """Prompt for gate / advisory settings; returns `.env` lines including comments."""
    advisory = _prompt_confirm(
        "Enable advisory mode? When on, the CLI always exits 0: findings still appear, "
        "but the gate never fails the run.",
        default=False,
    )
    max_critical = _prompt_non_negative_int(
        "Max CRITICAL findings before the gate fails (0 = fail if there is any critical; "
        "increase to allow more)",
        0,
    )
    max_high = _prompt_non_negative_int(
        "Max HIGH findings before the gate fails (0 = fail if there is any high)",
        0,
    )
    max_medium = _prompt_non_negative_int(
        "Max MEDIUM findings before the gate fails",
        999,
    )
    max_low = _prompt_non_negative_int(
        "Max LOW findings before the gate fails",
        999,
    )
    adv = "true" if advisory else "false"
    return [
        "# Gating — severity thresholds; non-zero exit when counts exceed limits "
        "(unless advisory).",
        "# GENDD_ADVISORY_MODE: If true, always exit success; gate outcome is advisory only.",
        f"GENDD_ADVISORY_MODE={adv}",
        "# GENDD_GATE_MAX_CRITICAL: Allowed CRITICAL findings (0 = none allowed).",
        f"GENDD_GATE_MAX_CRITICAL={max_critical}",
        "# GENDD_GATE_MAX_HIGH: Allowed HIGH findings (0 = none allowed).",
        f"GENDD_GATE_MAX_HIGH={max_high}",
        "# GENDD_GATE_MAX_MEDIUM: Allowed MEDIUM findings.",
        f"GENDD_GATE_MAX_MEDIUM={max_medium}",
        "# GENDD_GATE_MAX_LOW: Allowed LOW findings.",
        f"GENDD_GATE_MAX_LOW={max_low}",
    ]


def collect_init_answers() -> str:
    """Interactive wizard; returns full `.env` file body."""
    choice = questionary.select(
        "Model provider",
        choices=[
            Choice(title="Google Vertex AI (Gemini)", value="vertex"),
            Choice(title="OpenAI", value="openai"),
            Choice(title="Azure OpenAI", value="azure_openai"),
            Choice(title="AWS Bedrock", value="bedrock"),
            Choice(title="Anthropic API", value="anthropic"),
        ],
        style=QUESTIONARY_STYLE,
    ).ask()
    if choice is None:
        raise KeyboardInterrupt
    provider: Provider = choice  # type: ignore[assignment]

    lines = [
        "# GenDD Agentic Governance — generated by `gendd init`",
        f"GENDD_MODEL_PROVIDER={provider}",
        "",
    ]

    if provider == "vertex":
        vm = _prompt_text("Vertex model", "gemini-2.0-flash-001")
        lines.append(f"GENDD_VERTEX_MODEL={vm}")
        loc = _prompt_text("Vertex location", "us-central1")
        lines.append(f"GENDD_VERTEX_LOCATION={loc}")
        proj = _prompt_text("Google Cloud project ID (optional)", "")
        if proj:
            lines.append(f"GOOGLE_CLOUD_PROJECT={proj}")
        lines.append("")
    elif provider == "openai":
        key = _prompt_password("OpenAI API key")
        if not key:
            raise ValueError("OpenAI API key is required for provider openai")
        lines.append(f"OPENAI_API_KEY={key}")
        model = _prompt_text("OpenAI model", "gpt-4o-mini")
        lines.append(f"GENDD_OPENAI_MODEL={model}")
        lines.append("")
    elif provider == "azure_openai":
        key = _prompt_password("Azure OpenAI API key")
        if not key:
            raise ValueError("Azure OpenAI API key is required")
        lines.append(f"AZURE_OPENAI_API_KEY={key}")
        endpoint = _prompt_text("Azure OpenAI endpoint")
        if not endpoint:
            raise ValueError("Azure OpenAI endpoint is required")
        lines.append(f"AZURE_OPENAI_ENDPOINT={endpoint}")
        dep = _prompt_text("Deployment name", "gpt-4o-mini")
        lines.append(f"AZURE_OPENAI_DEPLOYMENT_NAME={dep}")
        ver = _prompt_text("API version", "2024-08-01-preview")
        lines.append(f"AZURE_OPENAI_API_VERSION={ver}")
        lines.append("")
    elif provider == "bedrock":
        region = _prompt_text("Bedrock region", "us-east-1")
        lines.append(f"GENDD_BEDROCK_REGION={region}")
        mid = _prompt_text(
            "Bedrock model ID",
            "anthropic.claude-3-5-sonnet-20240620-v1:0",
        )
        lines.append(f"GENDD_BEDROCK_MODEL_ID={mid}")
        lines.append(f"AWS_REGION={region}")
        lines.append("")
    else:
        key = _prompt_password("Anthropic API key")
        if not key:
            raise ValueError("Anthropic API key is required")
        lines.append(f"ANTHROPIC_API_KEY={key}")
        model = _prompt_text("Anthropic model", "claude-3-5-sonnet-20241022")
        lines.append(f"GENDD_ANTHROPIC_MODEL={model}")
        lines.append("")

    lines += _collect_gate_env_lines()
    lines += [
        "",
        "# GitHub PR comments (optional)",
        "# GITHUB_TOKEN=",
        "# GITHUB_REPOSITORY=owner/repo",
        "",
    ]

    if _prompt_confirm("Configure GitHub token and repository now?", default=False):
        tok = _prompt_password("GitHub token (paste or leave empty to skip)")
        if tok:
            lines.append(f"GITHUB_TOKEN={tok}")
            repo = _prompt_text("GitHub repository (owner/repo)", "")
            if repo:
                lines.append(f"GITHUB_REPOSITORY={repo}")
        lines.append("")

    return "\n".join(lines)
