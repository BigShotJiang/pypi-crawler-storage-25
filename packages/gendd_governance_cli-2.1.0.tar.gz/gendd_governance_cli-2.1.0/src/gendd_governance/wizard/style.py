from __future__ import annotations

from rich.console import Console
from rich.text import Text


def gradient_text(
    line: str,
    rgb_start: tuple[int, int, int],
    rgb_end: tuple[int, int, int],
) -> Text:
    """Per-character RGB gradient (gradient-string-style terminal UX)."""
    t = Text()
    n = max(len(line), 1)
    rs, gs, bs = rgb_start
    re, ge, be = rgb_end
    for i, ch in enumerate(line):
        if ch == "\n":
            t.append("\n")
            continue
        alpha = i / (n - 1) if n > 1 else 0.0
        r = int(rs + (re - rs) * alpha)
        g = int(gs + (ge - gs) * alpha)
        b = int(bs + (be - bs) * alpha)
        t.append(ch, style=f"#{r:02x}{g:02x}{b:02x}")
    return t


def print_gradient_line(console: Console, line: str) -> None:
    console.print(gradient_text(line, (99, 102, 241), (236, 72, 153)))
