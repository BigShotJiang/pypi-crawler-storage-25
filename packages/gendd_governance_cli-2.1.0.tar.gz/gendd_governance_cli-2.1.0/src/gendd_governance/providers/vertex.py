from __future__ import annotations

import warnings

from langchain_google_vertexai import ChatVertexAI

from gendd_governance.config import Settings


def build_vertex(settings: Settings) -> ChatVertexAI:
    kwargs: dict = {
        "model_name": settings.vertex_model,
        "location": settings.vertex_location,
    }
    if settings.google_cloud_project:
        kwargs["project"] = settings.google_cloud_project
    # LangChain marks ChatVertexAI deprecated in favor of langchain-google-genai; we still use
    # Vertex AI client-side until a coordinated migration. Suppress at the callsite so filters
    # that rely on ``warnings`` module resolution (often empty on Windows) still apply.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        return ChatVertexAI(**kwargs)
