from __future__ import annotations

import json
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage
from langchain_core.outputs import ChatGeneration, ChatResult


class OfflineStubChatModel(BaseChatModel):
    """Returns empty findings without calling an external API (for --offline / CI smoke)."""

    @property
    def _llm_type(self) -> str:
        return "offline-stub"

    def _generate(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: Any = None,
        **kwargs: Any,
    ) -> ChatResult:
        text = json.dumps({"findings": []})
        return ChatResult(generations=[ChatGeneration(message=AIMessage(content=text))])
