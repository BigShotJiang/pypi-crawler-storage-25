from __future__ import annotations

from langchain_anthropic import ChatAnthropic

from gendd_governance.config import Settings


def build_anthropic(settings: Settings) -> ChatAnthropic:
    if not settings.anthropic_api_key:
        raise RuntimeError("ANTHROPIC_API_KEY is required for anthropic provider")
    return ChatAnthropic(
        model=settings.anthropic_model,
        api_key=settings.anthropic_api_key,
    )
