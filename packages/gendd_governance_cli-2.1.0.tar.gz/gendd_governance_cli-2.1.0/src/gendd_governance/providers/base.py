from __future__ import annotations

from langchain_core.language_models.chat_models import BaseChatModel

from gendd_governance.config import Settings


def get_chat_model(settings: Settings) -> BaseChatModel:
    p = settings.model_provider
    if p == "vertex":
        from gendd_governance.providers.vertex import build_vertex

        return build_vertex(settings)
    if p == "openai":
        from gendd_governance.providers.openai import build_openai

        return build_openai(settings)
    if p == "azure_openai":
        from gendd_governance.providers.azure_openai import build_azure_openai

        return build_azure_openai(settings)
    if p == "bedrock":
        from gendd_governance.providers.bedrock import build_bedrock

        return build_bedrock(settings)
    if p == "anthropic":
        from gendd_governance.providers.anthropic import build_anthropic

        return build_anthropic(settings)
    raise ValueError(f"Unknown provider: {p}")
