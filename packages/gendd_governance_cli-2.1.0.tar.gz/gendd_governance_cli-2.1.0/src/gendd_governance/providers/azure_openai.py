from __future__ import annotations

from langchain_openai import AzureChatOpenAI

from gendd_governance.config import Settings


def build_azure_openai(settings: Settings) -> AzureChatOpenAI:
    if not settings.azure_openai_api_key or not settings.azure_openai_endpoint:
        raise RuntimeError(
            "AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT required for azure_openai"
        )
    return AzureChatOpenAI(
        azure_endpoint=settings.azure_openai_endpoint,
        api_key=settings.azure_openai_api_key,
        api_version=settings.azure_openai_api_version,
        deployment_name=settings.azure_openai_deployment,
    )
