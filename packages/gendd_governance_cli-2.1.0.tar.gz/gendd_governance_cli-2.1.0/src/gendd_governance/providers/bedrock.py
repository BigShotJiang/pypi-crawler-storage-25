from __future__ import annotations

import os

from langchain_aws import ChatBedrockConverse

from gendd_governance.config import Settings


def _resolve_bedrock_region(settings: Settings) -> str:
    if settings.bedrock_region:
        return settings.bedrock_region
    for key in ("AWS_REGION", "AWS_DEFAULT_REGION"):
        v = os.environ.get(key)
        if v:
            return v
    raise RuntimeError(
        "AWS region required for bedrock: set GENDD_BEDROCK_REGION or "
        "AWS_REGION / AWS_DEFAULT_REGION"
    )


def build_bedrock(settings: Settings) -> ChatBedrockConverse:
    if not settings.bedrock_model_id:
        raise RuntimeError("GENDD_BEDROCK_MODEL_ID is required for bedrock provider")
    region = _resolve_bedrock_region(settings)
    return ChatBedrockConverse(
        model=settings.bedrock_model_id,
        region_name=region,
    )
