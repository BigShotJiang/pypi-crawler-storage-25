from __future__ import annotations

from langchain_openai import ChatOpenAI

from gendd_governance.config import Settings


def build_openai(settings: Settings) -> ChatOpenAI:
    if not settings.openai_api_key:
        raise RuntimeError("OPENAI_API_KEY is required for openai provider")
    return ChatOpenAI(
        model=settings.openai_model,
        api_key=settings.openai_api_key,
    )
