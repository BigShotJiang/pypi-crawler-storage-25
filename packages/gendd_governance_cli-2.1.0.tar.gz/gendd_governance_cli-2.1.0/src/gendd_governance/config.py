from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from gendd_governance.context.repo import get_repo_root

GENDD_LOCAL_CONFIG_DIR = ".gendd-agentic-governance"

GITIGNORE_MARK_START = "# GenDD Agentic Governance (local CLI config; may contain secrets)"
GITIGNORE_ENTRY = ".gendd-agentic-governance/"


@dataclass(frozen=True)
class SuperPhaseLimits:
    """Character caps for super-phase synthesis/calibration prompts (diff, rules, findings JSON)."""

    max_diff_synthesis: int = 100_000
    max_rules_synthesis: int = 80_000
    max_diff_calibration: int = 100_000
    max_rules_calibration: int = 40_000
    max_findings_json_chars: int = 50_000


class Settings(BaseSettings):
    """Environment-driven configuration for governance CLI and providers."""

    model_config = SettingsConfigDict(
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    model_provider: Literal["vertex", "openai", "azure_openai", "bedrock", "anthropic"] = Field(
        default="vertex",
        alias="GENDD_MODEL_PROVIDER",
    )
    vertex_model: str = Field(default="gemini-2.0-flash-001", alias="GENDD_VERTEX_MODEL")
    vertex_location: str = Field(default="us-central1", alias="GENDD_VERTEX_LOCATION")
    google_cloud_project: str | None = Field(default=None, alias="GOOGLE_CLOUD_PROJECT")

    openai_api_key: str | None = Field(default=None, alias="OPENAI_API_KEY")
    openai_model: str = Field(default="gpt-4o-mini", alias="GENDD_OPENAI_MODEL")

    azure_openai_api_key: str | None = Field(default=None, alias="AZURE_OPENAI_API_KEY")
    azure_openai_endpoint: str | None = Field(default=None, alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_deployment: str = Field(
        default="gpt-4o-mini",
        alias="AZURE_OPENAI_DEPLOYMENT_NAME",
    )
    azure_openai_api_version: str = Field(
        default="2024-08-01-preview",
        alias="AZURE_OPENAI_API_VERSION",
    )

    bedrock_region: str | None = Field(default=None, alias="GENDD_BEDROCK_REGION")
    bedrock_model_id: str | None = Field(default=None, alias="GENDD_BEDROCK_MODEL_ID")

    anthropic_api_key: str | None = Field(default=None, alias="ANTHROPIC_API_KEY")
    anthropic_model: str = Field(
        default="claude-3-5-sonnet-20241022",
        alias="GENDD_ANTHROPIC_MODEL",
    )

    advisory_mode: bool = Field(default=False, alias="GENDD_ADVISORY_MODE")
    gate_max_critical: int = Field(default=0, alias="GENDD_GATE_MAX_CRITICAL")
    gate_max_high: int = Field(default=0, alias="GENDD_GATE_MAX_HIGH")
    gate_max_medium: int = Field(default=999, alias="GENDD_GATE_MAX_MEDIUM")
    gate_max_low: int = Field(default=999, alias="GENDD_GATE_MAX_LOW")

    github_token: str | None = Field(default=None, alias="GITHUB_TOKEN")
    github_repository: str | None = Field(default=None, alias="GITHUB_REPOSITORY")

    # Observability (structured JSON logs; see docs/observability.md)
    log_format: Literal["json", "text"] = Field(default="text", alias="GENDD_LOG_FORMAT")
    log_level: str = Field(default="INFO", alias="GENDD_LOG_LEVEL")
    log_heartbeat_interval_seconds: float = Field(
        default=30.0,
        alias="GENDD_LOG_HEARTBEAT_INTERVAL_SECONDS",
    )
    log_service_name: str = Field(default="gendd-governance-cli", alias="GENDD_SERVICE_NAME")
    log_service_version: str | None = Field(default=None, alias="GENDD_SERVICE_VERSION")

    rules_context_mode: Literal["full", "select"] = Field(
        default="select",
        alias="GENDD_RULES_CONTEXT_MODE",
    )
    rules_select_max_per_agent: int = Field(default=8, alias="GENDD_RULES_SELECT_MAX_PER_AGENT")
    rules_router_diff_chars: int = Field(default=24_000, alias="GENDD_RULES_ROUTER_DIFF_CHARS")

    context_paths_select_max: int = Field(default=5, alias="GENDD_CONTEXT_PATHS_SELECT_MAX")
    context_router_max_per_category: int = Field(
        default=15,
        alias="GENDD_CONTEXT_ROUTER_MAX_PER_CATEGORY",
    )


def workspace_root(cwd: Path | None = None) -> Path:
    return Path(cwd or Path.cwd()).resolve()


def gendd_local_config_dir(repo_root: Path) -> Path:
    return repo_root / GENDD_LOCAL_CONFIG_DIR


def gendd_local_env_path(repo_root: Path) -> Path:
    return gendd_local_config_dir(repo_root) / ".env"


def resolve_env_file_paths(repo_root: Path) -> tuple[Path, ...]:
    """Existing env files only; later paths override earlier (pydantic-settings)."""
    cwd_env = Path.cwd().resolve() / ".env"
    gendd_env = gendd_local_env_path(repo_root).resolve()
    paths: list[Path] = []
    if cwd_env.is_file():
        paths.append(cwd_env)
    if gendd_env.is_file():
        paths.append(gendd_env)
    return tuple(paths)


def load_settings(repo_root: Path | None = None) -> Settings:
    """Load Settings from optional cwd `.env` then repo `.gendd-agentic-governance/.env`."""
    root = get_repo_root(repo_root or Path.cwd())
    files = resolve_env_file_paths(root)
    if not files:
        return Settings()
    return Settings(_env_file=files, _env_file_encoding="utf-8")


def ensure_gitignore_has_gendd_dir(repo_root: Path) -> bool:
    """Append GenDD ignore block to repo `.gitignore` if missing. Returns True if file changed."""
    path = repo_root / ".gitignore"
    block = f"{GITIGNORE_MARK_START}\n{GITIGNORE_ENTRY}\n"
    if path.is_file():
        text = path.read_text(encoding="utf-8")
        if GITIGNORE_ENTRY in text:
            return False
        if not text.endswith("\n"):
            text += "\n"
        text += "\n" + block
        path.write_text(text, encoding="utf-8")
        return True
    path.write_text(block, encoding="utf-8")
    return True
