"""Best-effort snapshot of the latest governance run.

Written to ``.gendd-agentic-governance/last-run.json`` (relative to the repo).
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from gendd_governance.aggregation.findings import AggregatedResult
from gendd_governance.config import gendd_local_config_dir

logger = logging.getLogger(__name__)

LAST_RUN_FILENAME = "last-run.json"
LAST_RUN_VERSION = 2
MIN_REPEAT_VERSION = 2

DiffSource = Literal["git", "github_pr"]


@dataclass(frozen=True)
class LastRunReplay:
    """Subset of ``last-run.json`` (v2 ``replay``) used to rebuild a run without prompts.

    ``diff_source`` — Whether the saved run used a local ``git`` diff or GitHub PR context
    (``github_pr``). PR repeats still require PR context in the environment at replay time.

    ``git_scope`` — For ``git`` diffs: ``unstaged``, ``staged``, ``range``, or ``commit``.
    ``None`` when ``diff_source`` is ``github_pr``.

    ``base`` / ``head`` — Refs that bounded the diff for ``git`` runs. For ``github_pr``
    snapshots these are placeholders; the live PR diff is resolved from the environment.

    ``commit_sha`` — When ``git_scope`` is ``commit``, the single commit to analyze;
    otherwise an optional recorded tip for other scopes.

    ``specialist_labels`` — Agent labels from ``select`` / ``ai-select``; ``None`` when
    the last command was a single-agent ``gendd run`` (for example ``ai-review``).
    """

    diff_source: DiffSource
    git_scope: str | None
    base: str
    head: str
    commit_sha: str | None
    specialist_labels: list[str] | None


def last_run_path(repo_root: Path) -> Path:
    return gendd_local_config_dir(repo_root) / LAST_RUN_FILENAME


def _replay_to_dict(replay: LastRunReplay) -> dict[str, Any]:
    if replay.diff_source == "github_pr":
        git_part: dict[str, Any] | None = None
    else:
        git_part = {
            "scope": replay.git_scope,
            "base": replay.base,
            "head": replay.head,
            "commit_sha": replay.commit_sha,
        }
    return {
        "diff_source": replay.diff_source,
        "git": git_part,
        "specialist_labels": list(replay.specialist_labels) if replay.specialist_labels else None,
    }


def _replay_from_dict(replay: dict[str, Any]) -> LastRunReplay:
    diff_source = replay.get("diff_source")
    if diff_source not in ("git", "github_pr"):
        msg = f"replay.diff_source must be 'git' or 'github_pr', got {diff_source!r}"
        raise ValueError(msg)
    if diff_source == "github_pr":
        return LastRunReplay(
            diff_source="github_pr",
            git_scope=None,
            base="origin/main",
            head="HEAD",
            commit_sha=None,
            specialist_labels=_coerce_label_list(replay.get("specialist_labels")),
        )
    raw_git = replay.get("git")
    if not isinstance(raw_git, dict):
        msg = "replay.git must be an object when diff_source is 'git'"
        raise ValueError(msg)
    scope = raw_git.get("scope")
    if scope not in ("unstaged", "staged", "range", "commit"):
        msg = f"replay.git.scope must be a valid git scope, got {scope!r}"
        raise ValueError(msg)
    base = str(raw_git.get("base") or "origin/main")
    head = str(raw_git.get("head") or "HEAD")
    commit = raw_git.get("commit_sha")
    commit_sha = str(commit).strip() if commit else None
    if scope == "commit" and not commit_sha:
        msg = "replay.git.commit_sha is required when scope is 'commit'"
        raise ValueError(msg)
    return LastRunReplay(
        diff_source="git",
        git_scope=scope,
        base=base,
        head=head,
        commit_sha=commit_sha,
        specialist_labels=_coerce_label_list(replay.get("specialist_labels")),
    )


def _coerce_label_list(raw: object) -> list[str] | None:
    if raw is None:
        return None
    if not isinstance(raw, list):
        msg = f"specialist_labels must be a list of strings or null, got {type(raw).__name__}"
        raise ValueError(msg)
    out = [str(x) for x in raw]
    if not out:
        return None
    return out


def read_last_run_payload(repo_root: Path) -> dict[str, Any]:
    """Read and parse ``last-run.json``; raise FileNotFoundError or JSON errors."""
    path = last_run_path(repo_root)
    if not path.is_file():
        msg = f"No last run snapshot at {path}"
        raise FileNotFoundError(msg)
    return json.loads(path.read_text(encoding="utf-8"))


def parse_replay_for_repeat(data: dict[str, Any]) -> LastRunReplay:
    """Validate v2+ payload and return :class:`LastRunReplay` for ``gendd repeat``."""
    version = data.get("version")
    if not isinstance(version, int) or version < MIN_REPEAT_VERSION:
        msg = (
            f"last-run.json must be version {MIN_REPEAT_VERSION} or newer for repeat. "
            "Run `gendd run` or `gendd select` once to refresh the snapshot."
        )
        raise ValueError(msg)
    raw = data.get("replay")
    if not isinstance(raw, dict):
        msg = (
            "last-run.json is missing a valid `replay` block. "
            "Run `gendd run` or `gendd select` once to refresh the snapshot."
        )
        raise ValueError(msg)
    return _replay_from_dict(raw)


def write_last_run_snapshot(
    repo_root: Path,
    *,
    command: str,
    scope_description: str | None,
    base_ref: str | None,
    head_ref: str | None,
    result: AggregatedResult,
    replay: LastRunReplay | None = None,
) -> None:
    """Best-effort write; logs a warning on failure without raising."""
    path = last_run_path(repo_root)
    payload: dict[str, Any] = {
        "version": LAST_RUN_VERSION,
        "saved_at": datetime.now(tz=UTC).isoformat(),
        "command": command,
        "scope_description": scope_description,
        "base_ref": base_ref,
        "head_ref": head_ref,
        "result": result.to_dict(),
    }
    if replay is not None:
        payload["replay"] = _replay_to_dict(replay)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except OSError as e:
        logger.warning("Could not write last-run snapshot to %s: %s", path, e)
