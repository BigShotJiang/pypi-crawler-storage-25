from __future__ import annotations

import os
from pathlib import Path

import frontmatter
import questionary
from rich.console import Console

from gendd_governance.config import (
    ensure_gitignore_has_gendd_dir,
    gendd_local_config_dir,
    gendd_local_env_path,
)
from gendd_governance.context.repo import get_repo_root
from gendd_governance.wizard.banner import print_wizard_banner
from gendd_governance.wizard.init_flow import (
    QUESTIONARY_STYLE,
    collect_init_answers,
    default_env_text,
)


def _write_config_readme(gendd_dir: Path) -> None:
    body = """# Local GenDD configuration

This folder holds **machine-local** settings for the GenDD Agentic Governance CLI.

- **`.env`** — model provider and API-related environment variables (may contain secrets).
- Do **not** commit this directory; it should be listed in `.gitignore`.

Regenerate or extend with `gendd init`.
"""
    post = frontmatter.Post(body)
    post.metadata["generator"] = "gendd-agentic-governance"
    post.metadata["kind"] = "local-config"
    (gendd_dir / "CONFIG.md").write_text(frontmatter.dumps(post), encoding="utf-8")


def run_init(
    repo_root: Path,
    *,
    force: bool,
    defaults: bool,
    skip_banner: bool = False,
) -> int:
    console = Console(stderr=True)
    gendd_dir = gendd_local_config_dir(repo_root)
    env_path = gendd_local_env_path(repo_root)

    ensure_gitignore_has_gendd_dir(repo_root)

    if env_path.exists() and not force:
        console.print(
            f"[red]Already initialized:[/red] {env_path}\n"
            "Use [bold]--force[/bold] to overwrite, or remove the file.",
        )
        return 1

    if env_path.exists() and force and not defaults:
        r = questionary.confirm(
            f"Overwrite {env_path}?",
            default=False,
            style=QUESTIONARY_STYLE,
        ).ask()
        if not r:
            console.print("Aborted.")
            return 1

    if not skip_banner and not defaults:
        print_wizard_banner(console, subtitle="First-time setup — local configuration")

    try:
        content = default_env_text() if defaults else collect_init_answers()
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]")
        return 130
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        return 2

    gendd_dir.mkdir(parents=True, exist_ok=True)
    if os.name != "nt":
        try:
            os.chmod(gendd_dir, 0o700)
        except OSError:
            pass

    env_path.write_text(content, encoding="utf-8")
    if os.name != "nt":
        try:
            os.chmod(env_path, 0o600)
        except OSError:
            pass

    _write_config_readme(gendd_dir)

    console.print(f"[green]Wrote[/green] {env_path}")
    console.print(f"[green]Ensured .gitignore[/green] in {repo_root}")
    return 0


def run_init_command(argv_cwd: Path, force: bool, defaults: bool) -> int:
    repo_root = get_repo_root(argv_cwd)
    return run_init(repo_root, force=force, defaults=defaults)
