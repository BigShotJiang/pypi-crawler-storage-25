from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Final

# Cap per category in the returned bundle (MVP).
MAX_PER_CATEGORY: Final[int] = 10

# Read only the head of each file when scanning imports.
_IMPORT_SCAN_MAX_BYTES: Final[int] = 120_000

# Max entries when walking repo docs/ for .md files.
_DOCS_WALK_MAX_FILES: Final[int] = 200

# How far up from a file's directory we look for tests/ and __tests__/.
_PARENT_TEST_DIR_DEPTH: Final[int] = 3

_BINARY_SUFFIXES: Final[frozenset[str]] = frozenset(
    {
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".webp",
        ".ico",
        ".pdf",
        ".zip",
        ".gz",
        ".tar",
        ".woff",
        ".woff2",
        ".ttf",
        ".eot",
        ".mp4",
        ".mp3",
        ".wasm",
        ".exe",
        ".dll",
        ".so",
        ".dylib",
    }
)


def _posix_relative(repo_root: Path, path: Path) -> str:
    try:
        rel = path.resolve().relative_to(repo_root.resolve())
    except ValueError:
        return ""
    return rel.as_posix()


def _safe_under_repo(repo_root: Path, path: Path) -> Path | None:
    try:
        rp = repo_root.resolve()
        resolved = path.resolve()
        resolved.relative_to(rp)
        return resolved
    except (ValueError, OSError):
        return None


def _should_analyze(path: Path) -> bool:
    if not path.is_file():
        return False
    suf = path.suffix.lower()
    if suf in _BINARY_SUFFIXES:
        return False
    return True


def _stem_and_suffix(path: Path) -> tuple[str, str]:
    """``user.service.ts`` → (``user.service``, ``.ts``)."""
    if not path.name:
        return "", ""
    if path.suffix:
        stem = path.name[: -len(path.suffix)]
        return stem, path.suffix.lower()
    return path.name, ""


def _rank_key(score: int, rel: str) -> tuple[int, str]:
    """Higher score first; then lexicographic path for stability."""
    return (-score, rel)


def _collect_test_dirs_for_file(repo_root: Path, file_dir: Path) -> list[Path]:
    roots: list[Path] = []
    seen: set[Path] = set()

    def add(p: Path) -> None:
        rp = _safe_under_repo(repo_root, p)
        if rp is None:
            return
        if rp not in seen:
            seen.add(rp)
            roots.append(rp)

    add(file_dir)
    for name in ("tests", "__tests__"):
        add(repo_root / name)
    cur = file_dir
    for _ in range(_PARENT_TEST_DIR_DEPTH):
        cur = cur.parent
        if cur == repo_root.parent or not str(cur).startswith(str(repo_root)):
            break
        for name in ("tests", "__tests__"):
            add(cur / name)
    return roots


def _score_test_candidate(
    candidate: Path,
    changed_path: Path,
    stem: str,
    *,
    search_root: Path,
) -> int:
    """Higher = better. Zero means not a match."""
    name = candidate.name
    if stem and stem not in name:
        return 0
    if not (
        f"{stem}.test." in name
        or f"{stem}.spec." in name
        or name.startswith(f"test_{stem}.")
        or name.startswith(f"test-{stem}.")
        or ".test." in name
        or ".spec." in name
    ):
        # Loose: any file with stem and typical test markers
        if not (".test." in name or ".spec." in name or name.startswith("test_")):
            return 0

    cdir = candidate.parent
    fdir = changed_path.parent

    if cdir == fdir:
        base = 10_000
    elif search_root.name in ("tests", "__tests__") or "tests" in cdir.parts:
        base = 6_000
    else:
        base = 3_000

    exactish = (
        name == f"{stem}.test{changed_path.suffix}"
        or name == f"{stem}.spec{changed_path.suffix}"
        or name == f"test_{stem}{changed_path.suffix}"
    )
    if exactish:
        return base + 500
    if stem and name.startswith(stem):
        return base + 200
    return base


def _find_related_tests(
    repo_root: Path,
    changed_path: Path,
    stem: str,
) -> list[tuple[int, str]]:
    out: list[tuple[int, str]] = []
    search_roots = _collect_test_dirs_for_file(repo_root, changed_path.parent)
    ext = changed_path.suffix.lower()

    for sroot in search_roots:
        if not sroot.is_dir():
            continue
        try:
            entries = list(sroot.iterdir())
        except OSError:
            continue
        for ent in entries:
            if not ent.is_file():
                continue
            if (
                ext
                and ent.suffix.lower() != ext
                and ".test." not in ent.name
                and ".spec." not in ent.name
            ):
                # Prefer same language; still allow .tsx vs .ts via test markers
                if not (".test." in ent.name or ".spec." in ent.name):
                    continue
            sc = _score_test_candidate(ent, changed_path, stem, search_root=sroot)
            if sc <= 0:
                continue
            rel = _posix_relative(repo_root, ent)
            if rel:
                out.append((sc, rel))
    out.sort(key=lambda t: _rank_key(t[0], t[1]))
    return out


def _collect_docs_same_dir(repo_root: Path, file_dir: Path, stem: str) -> list[tuple[int, str]]:
    out: list[tuple[int, str]] = []
    try:
        entries = list(file_dir.iterdir())
    except OSError:
        return out
    for ent in entries:
        if not ent.is_file() or ent.suffix.lower() != ".md":
            continue
        rel = _posix_relative(repo_root, ent)
        if not rel:
            continue
        if ent.name.lower() == "readme.md":
            out.append((9000, rel))
        elif stem and stem in ent.stem.lower():
            out.append((7500, rel))
        else:
            out.append((5000, rel))
    return out


def _iter_docs_tree_limited(docs_root: Path) -> list[Path]:
    found: list[Path] = []
    count = 0
    for dirpath, _dirnames, filenames in os.walk(docs_root):
        for fn in filenames:
            if not fn.endswith(".md"):
                continue
            found.append(Path(dirpath) / fn)
            count += 1
            if count >= _DOCS_WALK_MAX_FILES:
                return found
    return found


def _find_docs_from_docs_folder(
    repo_root: Path, stem: str, folder_hint: str
) -> list[tuple[int, str]]:
    docs_root = repo_root / "docs"
    if not docs_root.is_dir():
        return []
    paths = _iter_docs_tree_limited(docs_root)
    out: list[tuple[int, str]] = []
    stem_l = stem.lower()
    hint_l = folder_hint.lower()
    for p in paths:
        rel = _posix_relative(repo_root, p)
        if not rel:
            continue
        rp = rel.lower()
        score = 1000
        if stem_l and stem_l in rp:
            score += 3000
        if hint_l and hint_l in rp:
            score += 1500
        out.append((score, rel))
    out.sort(key=lambda t: _rank_key(t[0], t[1]))
    return out


def _resolve_js_relative(parent: Path, rel: str, repo_root: Path, seen: set[str]) -> None:
    if not rel.startswith((".",)):
        return
    raw = rel.lstrip("./").replace("\\", "/")
    base_path = (parent / raw).resolve()
    candidates = [base_path]
    for ext in (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".json"):
        candidates.append((parent / f"{raw}{ext}").resolve())
    for candidate in candidates:
        if candidate.is_file():
            pr = _posix_relative(repo_root, candidate)
            if pr and pr not in seen:
                seen.add(pr)
            return


def _extract_relative_imports(file_path: Path, repo_root: Path) -> list[str]:
    """Resolve only relative import paths (./ ../ and Python-relative)."""
    try:
        raw = file_path.read_bytes()[:_IMPORT_SCAN_MAX_BYTES].decode("utf-8", errors="replace")
    except OSError:
        return []

    seen: set[str] = set()
    parent = file_path.parent

    # JS/TS: import ... from './x', require('./x'), import('./x')
    for rx in (
        re.compile(r"""from\s+['"](\.\.?\/[^'"]+)['"]"""),
        re.compile(r"""require\(\s*['"](\.\.?\/[^'"]+)['"]"""),
        re.compile(r"""import\s*\(\s*['"](\.\.?\/[^'"]+)['"]"""),
    ):
        for m in rx.finditer(raw):
            _resolve_js_relative(parent, m.group(1), repo_root, seen)

    # Go: import "./foo"
    for m in re.finditer(r'import\s+"(\.\.?\/[^"]+)"', raw):
        rel = m.group(1)
        tgt = (parent / rel).resolve()
        candidates = [tgt, tgt.with_suffix(".go")]
        for candidate in candidates:
            if candidate.is_file():
                pr = _posix_relative(repo_root, candidate)
                if pr and pr not in seen:
                    seen.add(pr)
                break

    # Python: from .pkg.mod import / from . import name
    file_dir = file_path.parent
    for m in re.finditer(r"^\s*from\s+(\.+)([\w.]+)\s+import\s+", raw, re.MULTILINE):
        dots = m.group(1)
        mod = m.group(2)
        up = len(dots) - 1
        base = file_dir
        for _ in range(up):
            base = base.parent
        parts = mod.split(".")
        tgt = base.joinpath(*parts)
        for candidate in (tgt.with_suffix(".py"), tgt / "__init__.py"):
            if candidate.is_file():
                pr = _posix_relative(repo_root, candidate)
                if pr and pr not in seen:
                    seen.add(pr)
                break

    for m in re.finditer(r"^\s*from\s+(\.+)\s+import\s+([\w.]+)", raw, re.MULTILINE):
        dots = m.group(1)
        mod = m.group(2).split(",")[0].strip()
        if not mod:
            continue
        up = len(dots) - 1
        base = file_dir
        for _ in range(up):
            base = base.parent
        parts = mod.split(".")
        tgt = base.joinpath(*parts)
        for candidate in (tgt.with_suffix(".py"), tgt / "__init__.py"):
            if candidate.is_file():
                pr = _posix_relative(repo_root, candidate)
                if pr and pr not in seen:
                    seen.add(pr)
                break

    return sorted(seen)


def _merge_cap(scored: list[tuple[int, str]], cap: int) -> list[str]:
    best: dict[str, int] = {}
    for sc, rel in scored:
        best[rel] = max(best.get(rel, -999_999), sc)
    ordered = sorted(best.items(), key=lambda item: _rank_key(item[1], item[0]))
    return [rel for rel, _sc in ordered[:cap]]


def format_deterministic_context_block(bundle: dict[str, object] | None) -> str:
    """Render ``context_bundle`` for agent user prompts."""
    if not bundle:
        return ""
    lines = ["## Related context (deterministic)", ""]
    for key, heading in (
        ("changed_files", "Changed files"),
        ("related_tests", "Related tests"),
        ("related_docs", "Related docs"),
        ("related_code", "Related code (imports)"),
    ):
        items = bundle.get(key)
        if not isinstance(items, list) or not items:
            continue
        lines.append(f"### {heading}")
        for p in items:
            lines.append(f"- {p}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


_AGENT_CONTEXT_KEYS: dict[str, tuple[str, ...]] = {
    "documentation": ("changed_files", "related_docs"),
    "test_validator": ("changed_files", "related_tests"),
    "architecture": ("changed_files", "related_code"),
    "api_contract": ("changed_files", "related_code"),
    "accessibility": ("changed_files",),
    "changelog": ("changed_files",),
}


def format_deterministic_context_block_for_agent(
    agent_label: str,
    bundle: dict[str, object] | None,
    path_overrides: dict[str, list[str]] | None = None,
) -> str:
    """Subset of deterministic context paths relevant to a specialist (smaller prompts).

    ``path_overrides`` may replace ``related_tests`` / ``related_docs`` lists for this agent
    (e.g. LLM-narrowed paths). Keys not present in overrides use ``bundle`` as usual.
    """
    if not bundle:
        return ""
    keys = _AGENT_CONTEXT_KEYS.get(agent_label)
    if keys is None:
        return format_deterministic_context_block(bundle)
    key_to_heading: dict[str, str] = {
        "changed_files": "Changed files",
        "related_tests": "Related tests",
        "related_docs": "Related docs",
        "related_code": "Related code (imports)",
    }
    lines = ["## Related context (deterministic)", ""]
    for key in keys:
        heading = key_to_heading[key]
        if path_overrides is not None and key in path_overrides:
            items = path_overrides[key]
        else:
            items = bundle.get(key)
        if not isinstance(items, list) or not items:
            continue
        lines.append(f"### {heading}")
        for p in items:
            lines.append(f"- {p}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


class ContextBuilder:
    """Deterministic, bounded context for agents from changed paths (tests, docs, imports)."""

    def build_context(
        self,
        changed_files: list[str],
        repo_root: str,
        *,
        max_per_category: int | None = None,
    ) -> dict[str, object]:
        """Build related tests, docs, and direct imports for AI agents.

        ``changed_files`` entries are paths relative to the repository root or absolute
        paths inside the repo. Output lists contain repo-relative POSIX paths, capped
        at ``max_per_category`` or :data:`MAX_PER_CATEGORY` when omitted.
        """
        root = Path(repo_root)
        normalized_changed: list[str] = []
        seen_ch: set[str] = set()

        for cf in changed_files:
            p = Path(cf)
            if p.is_absolute():
                full = p
            else:
                full = root / cf
            safe = _safe_under_repo(root, full)
            if safe is None or not safe.is_file():
                continue
            rel = _posix_relative(root, safe)
            if not rel or rel in seen_ch:
                continue
            seen_ch.add(rel)
            normalized_changed.append(rel)

        tests_acc: list[tuple[int, str]] = []
        docs_acc: list[tuple[int, str]] = []
        code_acc: list[tuple[int, str]] = []

        for rel in normalized_changed:
            cp = root / rel
            if not _should_analyze(cp):
                continue
            stem, _suf = _stem_and_suffix(cp)
            folder_hint = cp.parent.name

            tests_acc.extend(_find_related_tests(root, cp, stem))
            docs_acc.extend(_collect_docs_same_dir(root, cp.parent, stem))
            docs_acc.extend(_find_docs_from_docs_folder(root, stem, folder_hint))

            for imp in _extract_relative_imports(cp, root):
                code_acc.append((5000, imp))

        cap = max_per_category if max_per_category is not None else MAX_PER_CATEGORY
        return {
            "changed_files": list(normalized_changed),
            "related_tests": _merge_cap(tests_acc, cap),
            "related_docs": _merge_cap(docs_acc, cap),
            "related_code": _merge_cap(code_acc, cap),
        }
