"""Deterministic, bounded hints derived from the diff (no network)."""

from __future__ import annotations

import re
from pathlib import Path

_MAX_SECTION: int = 8_000

_LICENSE_PATH_RE = re.compile(
    r"^\+.*(?:LICENSE|LICENCE|COPYING|NOTICE)(?:\.|$)",
    re.MULTILINE | re.IGNORECASE,
)
_MANIFEST_PATH_RE = re.compile(
    r"(?:^|\s)(package\.json|package-lock\.json|pnpm-lock\.yaml|yarn\.lock|"
    r"requirements.*\.txt|pyproject\.toml|Pipfile(?:\.lock)?|poetry\.lock|"
    r"go\.mod|go\.sum|pom\.xml|build\.gradle(?:\.kts)?|gradle\.lockfile|"
    r"Cargo\.toml|Cargo\.lock|Gemfile(?:\.lock)?|composer\.json)",
    re.IGNORECASE,
)

_INFRA_PATH_HINTS = (
    ".github/workflows/",
    ".gitlab-ci.yml",
    ".circleci/",
    "azure-pipelines",
    ".buildkite/",
    "Jenkinsfile",
    ".tf",
    ".tfvars",
    ".hcl",
)

_UI_SUFFIXES: frozenset[str] = frozenset(
    {
        ".tsx",
        ".jsx",
        ".vue",
        ".svelte",
        ".css",
        ".scss",
        ".less",
        ".html",
        ".htm",
    }
)


def _truncate(s: str, max_chars: int = _MAX_SECTION) -> str:
    if len(s) <= max_chars:
        return s
    return s[: max_chars - 40] + "\n… (truncated for size)"


def build_license_signals_for_diff(diff_text: str) -> str:
    """Heuristic license / third-party signals from the unified diff."""
    lines: list[str] = []
    if _LICENSE_PATH_RE.search(diff_text):
        lines.append("- Diff adds or changes lines in LICENSE, NOTICE, or similar files.")
    if _MANIFEST_PATH_RE.search(diff_text):
        lines.append(
            "- Diff touches a dependency manifest or lockfile "
            "(third-party license exposure may change)."
        )
    # Added PyPI/npm style deps on + lines
    added_pkgs = 0
    for rx in (
        re.compile(r'^\+[^+].*["\']([@\w\-./]+)["\']\s*:\s*["\']?[\^~>=]*([\d][\w.\-]*)'),
        re.compile(r"^\+([a-zA-Z0-9_\-\[\]]+)==([\d][\w.\-]*)"),
    ):
        added_pkgs += len(rx.findall(diff_text, re.MULTILINE))
    if added_pkgs:
        lines.append(
            f"- Heuristic: ~{min(added_pkgs, 99)} added manifest dependency line(s) detected."
        )
    if not lines:
        return "(No license/manifest signals extracted from diff.)"
    return _truncate("\n".join(lines))


def _is_infra_path(rel: str) -> bool:
    p = rel.replace("\\", "/").lower()
    return any(h.lower() in p for h in _INFRA_PATH_HINTS) or p.endswith((".tf", ".tfvars", ".hcl"))


def _extract_added_lines_for_path(diff_text: str, rel_path: str) -> list[str]:
    """Collect + lines from the hunk for a file (best-effort)."""
    norm = rel_path.replace("\\", "/")
    pattern = re.compile(
        rf"^\+\+\+ b/{re.escape(norm)}\s*$",
        re.MULTILINE,
    )
    m = pattern.search(diff_text)
    if not m:
        return []
    start = m.end()
    nxt = re.search(r"^diff --git ", diff_text[start:], re.MULTILINE)
    chunk = diff_text[start:] if nxt is None else diff_text[start : start + nxt.start()]
    out: list[str] = []
    for line in chunk.splitlines():
        if line.startswith("+") and not line.startswith("+++"):
            out.append(line[1:].rstrip()[:500])
    return out[:200]


def build_infra_hints_for_diff(diff_text: str, changed_paths: list[str]) -> str:
    """Shallow CI/CD and Terraform/HCL cues from changed paths and diff hunks."""
    infra_files = [p for p in changed_paths if _is_infra_path(p)]
    if not infra_files:
        if not re.search(r"\.github/workflows/|\.gitlab-ci|\.tf\b|\.hcl\b", diff_text, re.I):
            return "(No CI/CD or Terraform/HCL paths detected in changed paths.)"
        infra_files = ["(see diff — path list unavailable)"]

    lines: list[str] = ["## Infra-related changed paths", ""]
    for p in infra_files[:30]:
        lines.append(f"- {p}")
    lines.append("")

    interesting: list[str] = []
    for p in changed_paths:
        if not _is_infra_path(p):
            continue
        for raw in _extract_added_lines_for_path(diff_text, p):
            low = raw.lower().strip()
            if any(
                k in low
                for k in (
                    "uses:",
                    "runs-on:",
                    "continue-on-error:",
                    "strategy:",
                    "matrix:",
                    "secrets.",
                    "oidc",
                    "permissions:",
                    "terraform",
                    "provider ",
                    "resource ",
                    "backend ",
                    "lifecycle ",
                )
            ):
                interesting.append(raw[:400])
            if len(interesting) >= 40:
                break
        if len(interesting) >= 40:
            break

    if interesting:
        lines.append("## Added lines of interest (heuristic)")
        for s in interesting[:40]:
            lines.append(f"- {s}")
    return _truncate("\n".join(lines))


_PERF_PATTERNS = (
    r"time\.sleep\(",
    r"\.sleep\(",
    r"for\s+.+\s+in\s+.+\s*:.*\n\+.*await\s+",
    r"SELECT\s+.+\s+FROM",  # coarse: SQL in loop often appears in adjacent + lines
)


def build_performance_hints_for_diff(diff_text: str, changed_paths: list[str]) -> str:
    hints: list[str] = []
    for pat in _PERF_PATTERNS:
        if re.search(pat, diff_text, re.IGNORECASE | re.MULTILINE):
            hints.append(
                f"- Diff matches heuristic pattern `{pat}` (possible hot-path / blocking risk)."
            )
    if not hints:
        return "(No coarse performance heuristics matched the diff.)"
    return _truncate("\n".join(hints))


_TELEMETRY_KEYS = (
    "logger.",
    "logging.",
    "log.",
    "structlog",
    "opentelemetry",
    "prometheus",
    "statsd",
    "datadog",
    "metric.",
    "histogram",
    "trace",
    "span",
    "sentry",
)


def build_telemetry_hints_for_diff(diff_text: str, changed_paths: list[str]) -> str:
    low_diff = diff_text.lower()
    hits = [k for k in _TELEMETRY_KEYS if k.lower() in low_diff]
    if not hits:
        return "(No obvious telemetry/logging keywords in diff.)"
    return _truncate(
        "## Telemetry-related keywords in diff (heuristic)\n"
        + "\n".join(f"- `{h}`" for h in hits[:25])
    )


_A11Y_KEYS = (
    "aria-",
    "role=",
    "tabindex",
    "alt=",
    "focus",
    "keyboard",
    "screen reader",
    "wcag",
)


def build_accessibility_hints_for_diff(diff_text: str, changed_paths: list[str]) -> str:
    ui_paths = [p for p in changed_paths if Path(p).suffix.lower() in _UI_SUFFIXES]
    if not ui_paths and not re.search(r"\.(tsx|jsx|vue|svelte|css|scss|html)\b", diff_text, re.I):
        return "(No UI/markup/CSS paths in change list; skip a11y unless diff shows otherwise.)"
    low = diff_text.lower()
    keys = [k for k in _A11Y_KEYS if k.lower() in low]
    lines = []
    if ui_paths:
        lines.append("## UI-related paths")
        for p in ui_paths[:25]:
            lines.append(f"- {p}")
        lines.append("")
    if keys:
        lines.append("## Accessibility-related tokens in diff (heuristic)")
        lines.extend(f"- `{k}`" for k in keys[:20])
    else:
        lines.append("(UI paths changed but no common a11y tokens matched in diff text.)")
    return _truncate("\n".join(lines))
