from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Literal

GitDiffScope = Literal["unstaged", "staged", "range", "commit"]


def get_changed_paths(repo_root: Path, base: str, head: str) -> list[str]:
    """Return paths changed between base and head (``git diff --name-only``).

    Uses the same three-dot / two-dot fallback strategy as :func:`get_git_diff`.
    On failure, returns an empty list.
    """
    try:
        out = subprocess.run(
            ["git", "diff", "--name-only", "--no-renames", f"{base}...{head}"],
            cwd=repo_root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            check=False,
        )
        if out.returncode != 0:
            out = subprocess.run(
                ["git", "diff", "--name-only", "--no-renames", f"{base}..{head}"],
                cwd=repo_root,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=120,
                check=False,
            )
        if out.returncode != 0:
            return []
        return [ln.strip() for ln in (out.stdout or "").splitlines() if ln.strip()]
    except (subprocess.SubprocessError, OSError):
        return []


def _git_diff_plain(repo_root: Path, *git_args: str) -> str:
    try:
        out = subprocess.run(
            ["git", *git_args],
            cwd=repo_root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            check=False,
        )
        combined = (out.stdout or "") + (out.stderr if out.returncode and not out.stdout else "")
        return combined
    except (subprocess.SubprocessError, OSError) as e:
        return f"# git {' '.join(git_args)} failed: {e}\n"


def _git_name_only(repo_root: Path, *git_args: str) -> list[str]:
    try:
        out = subprocess.run(
            ["git", *git_args],
            cwd=repo_root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            check=False,
        )
        if out.returncode != 0:
            return []
        return [ln.strip() for ln in (out.stdout or "").splitlines() if ln.strip()]
    except (subprocess.SubprocessError, OSError):
        return []


def get_unstaged_diff(repo_root: Path) -> str:
    """Unified diff for unstaged changes: tracked (``git diff``) plus untracked files.

    Paths follow ``git ls-files --others --modified --exclude-standard``. Untracked
    file content is included via ``git diff --no-index`` against the null device.
    """
    tracked = _git_diff_plain(repo_root, "diff")
    unstaged_rels = get_unstaged_changed_paths(repo_root)
    tracked_rels = set(
        _git_name_only(repo_root, "diff", "--name-only", "--no-renames")
    )
    untracked = [p for p in unstaged_rels if p not in tracked_rels]
    if not untracked:
        return tracked
    parts: list[str] = []
    if tracked.strip():
        parts.append(tracked if tracked.endswith("\n") else tracked + "\n")
    for rel in sorted(untracked):
        if not _is_safe_repo_relative_path(rel):
            continue
        file_path = (repo_root / rel).resolve()
        try:
            file_path.relative_to(repo_root.resolve())
        except ValueError:
            continue
        if not file_path.is_file():
            continue
        parts.append(
            _git_diff_plain(
                repo_root, "diff", "--no-index", os.devnull, rel.replace("\\", "/")
            )
        )
    return "".join(parts)


def get_staged_diff(repo_root: Path) -> str:
    """Unified diff for staged changes (index vs HEAD)."""
    return _git_diff_plain(repo_root, "diff", "--cached")


def get_commit_diff(repo_root: Path, sha: str) -> str:
    """Unified patch for a single commit (``git show``)."""
    return _git_diff_plain(repo_root, "show", "--pretty=format:", "--patch", sha)


def _is_safe_repo_relative_path(rel: str) -> bool:
    if not rel or rel.startswith(("/", "\\")):
        return False
    p = Path(rel)
    if p.is_absolute():
        return False
    return ".." not in p.parts


def get_unstaged_changed_paths(repo_root: Path) -> list[str]:
    return _git_name_only(
        repo_root, "ls-files", "--others", "--modified", "--exclude-standard"
    )


def get_staged_changed_paths(repo_root: Path) -> list[str]:
    return _git_name_only(repo_root, "diff", "--cached", "--name-only", "--no-renames")


def get_commit_changed_paths(repo_root: Path, sha: str) -> list[str]:
    return _git_name_only(repo_root, "show", "--pretty=format:", "--name-only", "--no-renames", sha)


def resolve_git_diff(
    repo_root: Path,
    scope: GitDiffScope,
    base: str,
    head: str,
    commit_sha: str | None,
) -> tuple[str, str | None, str | None]:
    """Return ``(diff_text, base_ref, head_ref)`` for logging and :func:`resolve_changed_paths`.

    For unstaged, staged, and commit scopes, *base_ref* and *head_ref* are ``None`` so path
    resolution uses the patch text (or git name-only helpers where applicable).
    """
    if scope == "unstaged":
        return get_unstaged_diff(repo_root), None, None
    if scope == "staged":
        return get_staged_diff(repo_root), None, None
    if scope == "commit":
        sha = (commit_sha or "").strip()
        if not sha:
            return "# error: commit SHA is required for scope=commit\n", None, None
        return get_commit_diff(repo_root, sha), None, None
    return get_git_diff(repo_root, base, head), base, head


def resolve_changed_paths(
    repo_root: Path,
    diff_text: str,
    base: str | None,
    head: str | None,
) -> list[str]:
    """Prefer ``git diff --name-only`` when *base* and *head* are set; else parse the patch."""
    if base is not None and head is not None:
        git_paths = get_changed_paths(repo_root, base, head)
        if git_paths:
            return git_paths
    return parse_changed_paths_from_unified_diff(diff_text)


def parse_changed_paths_from_unified_diff(diff_text: str) -> list[str]:
    """Extract changed file paths from a unified diff (no git required).

    Parses ``diff --git a/... b/...`` lines. Order is preserved; duplicates removed.
    """
    seen: set[str] = set()
    out: list[str] = []
    for line in diff_text.splitlines():
        if not line.startswith("diff --git "):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        # b/path — use destination side when present
        b_spec = parts[3]
        if b_spec.startswith("b/"):
            path = b_spec[2:]
        else:
            path = b_spec
        if path in ("/dev/null", "dev/null"):
            continue
        if path not in seen:
            seen.add(path)
            out.append(path)
    return out


def get_git_diff(repo_root: Path, base: str, head: str) -> str:
    """Return unified diff for base..head (e.g. origin/main..HEAD)."""
    try:
        out = subprocess.run(
            ["git", "diff", f"{base}...{head}"],
            cwd=repo_root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            check=False,
        )
        if out.returncode != 0:
            # Fallback: two-dot range
            out = subprocess.run(
                ["git", "diff", f"{base}..{head}"],
                cwd=repo_root,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=120,
                check=False,
            )
        return (out.stdout or "") + (out.stderr if out.returncode and not out.stdout else "")
    except (subprocess.SubprocessError, OSError) as e:
        return f"# git diff failed: {e}\n"
