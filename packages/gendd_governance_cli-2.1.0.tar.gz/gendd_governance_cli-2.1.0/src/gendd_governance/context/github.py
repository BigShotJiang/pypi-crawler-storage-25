from __future__ import annotations

import json
import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx


@dataclass
class PrContext:
    number: int
    base_ref: str
    head_ref: str
    title: str
    body: str
    diff_text: str


def infer_pr_number_from_github_ref(ref: str | None) -> int | None:
    if not ref:
        return None
    m = re.match(r"refs/pull/(\d+)/merge", ref) or re.match(r"refs/pull/(\d+)/head", ref)
    if m:
        return int(m.group(1))
    return None


def run_gh_pr_view(repo_root: Path, number: int) -> dict[str, Any] | None:
    """Use GitHub CLI when available."""
    try:
        out = subprocess.run(
            [
                "gh",
                "pr",
                "view",
                str(number),
                "--json",
                "title,body,baseRefName,headRefName,number",
            ],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=60,
            check=True,
        )
        return json.loads(out.stdout)
    except (subprocess.CalledProcessError, FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def run_gh_pr_diff(repo_root: Path, number: int) -> str:
    try:
        out = subprocess.run(
            ["gh", "pr", "diff", str(number)],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
        )
        return out.stdout or out.stderr or ""
    except (subprocess.SubprocessError, OSError) as e:
        return f"# gh pr diff failed: {e}\n"


def get_pr_context_from_env(repo_root: Path) -> PrContext | None:
    """Build PR context from GITHUB_REF + gh, or None."""
    ref = os.environ.get("GITHUB_REF")
    num = infer_pr_number_from_github_ref(ref)
    if num is None:
        return None
    meta = run_gh_pr_view(repo_root, num)
    diff_text = run_gh_pr_diff(repo_root, num)
    if not meta:
        return PrContext(
            number=num,
            base_ref="unknown",
            head_ref="unknown",
            title="",
            body="",
            diff_text=diff_text,
        )
    return PrContext(
        number=num,
        base_ref=str(meta.get("baseRefName") or "unknown"),
        head_ref=str(meta.get("headRefName") or "unknown"),
        title=str(meta.get("title") or ""),
        body=str(meta.get("body") or ""),
        diff_text=diff_text,
    )


def post_pr_comment_rest(
    token: str,
    owner_repo: str,
    pr_number: int,
    body: str,
) -> bool:
    """POST issue comment on PR via GitHub REST API."""
    if "/" not in owner_repo:
        return False
    owner, repo = owner_repo.split("/", 1)
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{pr_number}/comments"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    try:
        r = httpx.post(url, headers=headers, json={"body": body}, timeout=60.0)
        return r.is_success
    except OSError:
        return False
