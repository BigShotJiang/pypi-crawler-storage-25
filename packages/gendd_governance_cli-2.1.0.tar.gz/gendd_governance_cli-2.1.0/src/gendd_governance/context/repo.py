from __future__ import annotations

import subprocess
from pathlib import Path


def get_repo_root(cwd: Path | None = None) -> Path:
    root = cwd or Path.cwd()
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=root,
            capture_output=True,
            text=True,
            check=True,
            timeout=30,
        )
        return Path(out.stdout.strip()).resolve()
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        return root.resolve()
