from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import argcomplete

from gendd_governance.cli_parser import build_arg_parser
from gendd_governance.commands import GOVERNANCE_COMMANDS
from gendd_governance.config import (
    Settings,
    gendd_local_env_path,
    load_settings,
    workspace_root,
)
from gendd_governance.orchestrator.command_metadata import AI_SELECT_COMMAND

if TYPE_CHECKING:
    from gendd_governance.last_run import LastRunReplay
    from gendd_governance.orchestrator.graph import AgentFn
    from gendd_governance.output.console import ConsoleRunScope
    from gendd_governance.rules.loader import LoadedRules

logger = logging.getLogger(__name__)


def get_chat_model(settings: Settings):
    """Lazy binding so ``import gendd_governance.cli`` stays light; tests patch this name."""
    from gendd_governance.providers.base import get_chat_model as _impl

    return _impl(settings)


def get_repo_root(cwd: Path | None = None) -> Path:
    from gendd_governance.context.repo import get_repo_root as _impl

    return _impl(cwd)


def configure_logging(settings: Settings) -> None:
    from gendd_governance.observability.logging import configure_logging as _impl

    _impl(settings)


def resolve_git_diff(*args: Any, **kwargs: Any) -> Any:
    from gendd_governance.context.diff import resolve_git_diff as _impl

    return _impl(*args, **kwargs)


def resolve_changed_paths(*args: Any, **kwargs: Any) -> Any:
    from gendd_governance.context.diff import resolve_changed_paths as _impl

    return _impl(*args, **kwargs)


def get_pr_context_from_env(repo_root: Path) -> Any:
    from gendd_governance.context.github import get_pr_context_from_env as _impl

    return _impl(repo_root)


def _suppress_noisy_dependency_warnings() -> None:
    """Reduce stderr noise from known third-party warnings during CLI runs."""
    warnings.filterwarnings(
        "ignore",
        category=DeprecationWarning,
        module=r"gendd_governance\.providers\.vertex",
    )
    warnings.filterwarnings(
        "ignore",
        message=r"The class `ChatVertexAI` was deprecated in LangChain 3\.2\.0.*",
        category=Warning,
    )
    warnings.filterwarnings(
        "ignore",
        category=UserWarning,
        module=r"google\.auth\._default",
    )


def _parse_formats(s: str) -> set[str]:
    parts = {x.strip().lower() for x in s.split(",") if x.strip()}
    return parts or {"console"}


def _build_console_run_scope(
    command: str,
    scope_description: str | None,
    rules: LoadedRules,
    changed_git_paths: list[str],
    context_bundle: dict[str, object] | None,
    *,
    specialist_fns: list[AgentFn] | None = None,
    rules_mode: str = "full",
    catalog_rule_paths: list[str] | None = None,
) -> ConsoleRunScope:
    """Summarize rules and paths shown in the console (shared across all agents)."""
    from gendd_governance.orchestrator.graph import AGENT_LABELS, agents_for_command
    from gendd_governance.output.console import ConsoleRunScope

    if specialist_fns is not None:
        agent_names = [AGENT_LABELS[fn] for fn in specialist_fns]
    else:
        fns = agents_for_command(command)
        agent_names = [AGENT_LABELS[fn] for fn in fns]
    rule_paths = sorted({s.id for s in rules.standards} | {p.id for p in rules.prompts})
    changed_files: list[str]
    if context_bundle and context_bundle.get("changed_files"):
        raw_cf = context_bundle["changed_files"]
        if isinstance(raw_cf, list) and raw_cf:
            changed_files = [str(x) for x in raw_cf]
        else:
            changed_files = list(changed_git_paths)
    else:
        changed_files = list(changed_git_paths)

    def _str_list(key: str) -> list[str]:
        if not context_bundle:
            return []
        raw = context_bundle.get(key)
        if not isinstance(raw, list):
            return []
        return [str(x) for x in raw]

    return ConsoleRunScope(
        command=command,
        scope_description=scope_description,
        agent_names=agent_names,
        rules_cursor_count=len(rules.standards),
        rules_skill_count=len(rules.prompts),
        rule_paths=rule_paths,
        changed_files=changed_files,
        related_tests=_str_list("related_tests"),
        related_docs=_str_list("related_docs"),
        related_code=_str_list("related_code"),
        rules_mode=rules_mode,
        catalog_rule_paths=catalog_rule_paths,
    )


def _build_last_run_replay(
    *,
    from_pr: bool,
    scope: str,
    base: str,
    head: str,
    commit_sha: str | None,
    command: str,
    specialist_fns: list[AgentFn] | None,
) -> LastRunReplay:
    from gendd_governance.last_run import LastRunReplay
    from gendd_governance.orchestrator.graph import AGENT_LABELS

    if command == AI_SELECT_COMMAND and specialist_fns:
        specialist_labels: list[str] | None = [AGENT_LABELS[fn] for fn in specialist_fns]
    else:
        specialist_labels = None
    if from_pr:
        return LastRunReplay(
            diff_source="github_pr",
            git_scope=None,
            base=base,
            head=head,
            commit_sha=None,
            specialist_labels=specialist_labels,
        )
    return LastRunReplay(
        diff_source="git",
        git_scope=scope,
        base=base,
        head=head,
        commit_sha=commit_sha,
        specialist_labels=specialist_labels,
    )


def _maybe_hint_missing_config(repo_root: Path, offline: bool) -> None:
    if offline:
        return
    if gendd_local_env_path(repo_root).is_file():
        return
    if os.environ.get("GENDD_MODEL_PROVIDER"):
        return
    print(
        "Tip: run `gendd init` (or set GENDD_MODEL_PROVIDER / credentials in the environment).",
        file=sys.stderr,
    )


async def run_governance_from_diff_text(
    command: str,
    settings: Settings,
    repo_root: Path,
    diff_text: str,
    offline: bool,
    formats: set[str],
    json_path: Path | None,
    sarif_path: Path | None,
    post_pr: bool,
    *,
    last_run_replay: LastRunReplay,
    verbose: bool = False,
    base_ref: str | None = None,
    head_ref: str | None = None,
    scope_description: str | None = None,
    specialist_fns: list[AgentFn] | None = None,
) -> int:
    """Run agents and outputs given an already-resolved diff text."""
    from gendd_governance.aggregation.aggregator import aggregate_findings
    from gendd_governance.aggregation.gating import GateConfig, evaluate_gate
    from gendd_governance.context.context_builder import ContextBuilder
    from gendd_governance.context.supplemental_signals import (
        build_accessibility_hints_for_diff,
        build_infra_hints_for_diff,
        build_license_signals_for_diff,
        build_performance_hints_for_diff,
        build_telemetry_hints_for_diff,
    )
    from gendd_governance.last_run import write_last_run_snapshot
    from gendd_governance.observability.logging import emit_gendd, set_progress_stdout_preferred
    from gendd_governance.observability.token_usage import (
        build_run_summary,
        snapshot_calls,
        token_usage_collector_scope,
    )
    from gendd_governance.output.console import print_console_report
    from gendd_governance.output.github_pr import maybe_post_pr_comment
    from gendd_governance.output.json_out import write_json_report
    from gendd_governance.output.sarif import write_sarif
    from gendd_governance.providers.stub import OfflineStubChatModel
    from gendd_governance.rules.loader import load_rules_from_repo
    from gendd_governance.run_identity import resolve_run_identity, write_run_identity_banner
    from gendd_governance.security.osv import build_osv_summary_for_diff

    if command == AI_SELECT_COMMAND and not specialist_fns:
        msg = (
            f"error: command {AI_SELECT_COMMAND!r} requires a non-empty specialist_fns "
            f"(got {specialist_fns!r})"
        )
        print(msg, file=sys.stderr)
        logger.warning(msg)
        emit_gendd(
            logger,
            "job.failed",
            "ai-select missing specialist agents",
            stage="validate",
            exit_code=2,
            level=logging.ERROR,
        )
        return 2

    set_progress_stdout_preferred("console" in formats)
    try:
        with token_usage_collector_scope():
            t0 = time.perf_counter()
            diff_bytes = len(diff_text.encode("utf-8"))
            osv = build_osv_summary_for_diff(diff_text)

            context_bundle: dict[str, object] | None = None
            changed_paths: list[str] = []
            try:
                changed_paths = resolve_changed_paths(repo_root, diff_text, base_ref, head_ref)
                if changed_paths:
                    ctx_cap: int | None = (
                        settings.context_router_max_per_category
                        if settings.rules_context_mode == "select"
                        else None
                    )
                    context_bundle = ContextBuilder().build_context(
                        changed_paths,
                        str(repo_root.resolve()),
                        max_per_category=ctx_cap,
                    )
                    if not any(
                        context_bundle.get(k)
                        for k in ("changed_files", "related_tests", "related_docs", "related_code")
                    ):
                        context_bundle = None
            except Exception as e:
                logger.warning("Deterministic context build failed: %s", e)
                context_bundle = None

            license_signals = build_license_signals_for_diff(diff_text)
            infra_hints = build_infra_hints_for_diff(diff_text, changed_paths)
            performance_hints = build_performance_hints_for_diff(diff_text, changed_paths)
            telemetry_hints = build_telemetry_hints_for_diff(diff_text, changed_paths)
            accessibility_hints = build_accessibility_hints_for_diff(diff_text, changed_paths)

            try:
                model = OfflineStubChatModel() if offline else get_chat_model(settings)
            except Exception as e:
                logger.exception("Model init failed: %s", e)
                emit_gendd(
                    logger,
                    "job.failed",
                    "model init failed",
                    stage="model",
                    exit_code=2,
                    error_type=type(e).__name__,
                    level=logging.ERROR,
                )
                print(f"Error initializing model: {e}", file=sys.stderr)
                return 2

            identity = resolve_run_identity(settings, model)
            write_run_identity_banner(identity)
            emit_gendd(
                logger,
                "job.started",
                "governance run started",
                diff_bytes=diff_bytes,
                cli_version=identity.cli_version,
                model_provider=identity.model_provider,
                model_name=identity.model_name,
            )

            rules_empty_msg = (
                "(no project rules: add .cursor/rules or skills under "
                ".cursor/skills or .claude/skills)"
            )
            changed_files_list: list[str] = []
            if context_bundle and isinstance(context_bundle.get("changed_files"), list):
                raw_cf = context_bundle["changed_files"]
                changed_files_list = [str(x) for x in raw_cf]
            elif changed_paths:
                changed_files_list = list(changed_paths)

            digest_cap = max(0, settings.rules_router_diff_chars)
            diff_digest = diff_text[:digest_cap] if digest_cap else ""

            from gendd_governance.orchestrator.graph import (
                AGENT_LABELS,
                agents_for_command,
                run_pipeline,
            )
            from gendd_governance.rules.index import build_rule_catalog
            from gendd_governance.rules.select import (
                build_per_agent_rule_prompts,
                fallback_context_path_selection,
                fallback_rule_selection,
                router_log_payload,
                select_rules_for_agents,
            )

            if specialist_fns is not None:
                agent_labels_for_rules = [AGENT_LABELS[fn] for fn in specialist_fns]
            else:
                agent_labels_for_rules = [AGENT_LABELS[fn] for fn in agents_for_command(command)]

            rules_mode = settings.rules_context_mode
            catalog_rule_paths: list[str] | None = None
            rules_by_agent: dict[str, str] | None = None
            context_paths_by_agent: dict[str, dict[str, list[str]]] | None = None
            try:
                if settings.rules_context_mode == "full":
                    rules = load_rules_from_repo(repo_root)
                    rules_block = rules.as_prompt_block()
                    if not rules_block.strip():
                        rules_block = rules_empty_msg
                else:
                    catalog = build_rule_catalog(repo_root)
                    catalog_rule_paths = sorted({e.id for e in catalog})
                    max_extra = max(0, settings.rules_select_max_per_agent)
                    cand_tests: list[str] = []
                    cand_docs: list[str] = []
                    if context_bundle:
                        rt = context_bundle.get("related_tests")
                        if isinstance(rt, list):
                            cand_tests = [str(x) for x in rt]
                        rd = context_bundle.get("related_docs")
                        if isinstance(rd, list):
                            cand_docs = [str(x) for x in rd]
                    ctx_paths_max = max(0, settings.context_paths_select_max)
                    if offline or isinstance(model, OfflineStubChatModel):
                        selections = fallback_rule_selection(
                            catalog,
                            agent_labels_for_rules,
                            changed_files_list,
                            diff_digest,
                            max_extra=max_extra,
                        )
                        context_paths = fallback_context_path_selection(
                            cand_tests,
                            cand_docs,
                            changed_files_list,
                            diff_digest,
                            max_paths=ctx_paths_max,
                        )
                    else:
                        selections, context_paths = await select_rules_for_agents(
                            model,
                            catalog,
                            agent_labels_for_rules,
                            diff_digest=diff_digest,
                            changed_paths=changed_files_list,
                            max_extra=max_extra,
                            candidate_related_tests=cand_tests,
                            candidate_related_docs=cand_docs,
                            context_paths_max=ctx_paths_max,
                        )
                    rules_by_agent, rules = build_per_agent_rule_prompts(repo_root, selections)
                    rules_block = rules.as_prompt_block()
                    if not rules_block.strip():
                        rules_block = rules_empty_msg
                    context_paths_by_agent = context_paths if context_paths else None
                    emit_gendd(
                        logger,
                        "rules.router.completed",
                        "rules routing completed",
                        **router_log_payload(
                            catalog,
                            selections,
                            rules_by_agent,
                            context_paths=context_paths,
                        ),
                    )
            except Exception as e:
                logger.exception("Rules load failed: %s", e)
                emit_gendd(
                    logger,
                    "job.failed",
                    "rules load failed",
                    stage="rules",
                    exit_code=2,
                    error_type=type(e).__name__,
                    level=logging.ERROR,
                )
                print(f"Error loading project rules: {e}", file=sys.stderr)
                return 2

            findings = await run_pipeline(
                command,
                model,
                diff_text,
                rules_block,
                osv.text,
                context_bundle=context_bundle,
                license_signals=license_signals,
                infra_hints=infra_hints,
                performance_hints=performance_hints,
                telemetry_hints=telemetry_hints,
                accessibility_hints=accessibility_hints,
                heartbeat_interval_seconds=settings.log_heartbeat_interval_seconds,
                specialist_fns=specialist_fns,
                rules_by_agent=rules_by_agent,
                context_paths_by_agent=context_paths_by_agent,
            )

            agg = aggregate_findings(findings, advisory=settings.advisory_mode)
            run_summary = build_run_summary(identity, snapshot_calls())
            agg = agg.model_copy(update={"run": run_summary})
            gate = GateConfig(
                max_critical=settings.gate_max_critical,
                max_high=settings.gate_max_high,
                max_medium=settings.gate_max_medium,
                max_low=settings.gate_max_low,
                advisory_mode=settings.advisory_mode,
            )
            result = evaluate_gate(agg, gate)

            write_last_run_snapshot(
                repo_root,
                command=command,
                scope_description=scope_description,
                base_ref=base_ref,
                head_ref=head_ref,
                result=result,
                replay=last_run_replay,
            )

            if "console" in formats:
                print_console_report(
                    result,
                    run_scope=_build_console_run_scope(
                        command,
                        scope_description,
                        rules,
                        changed_paths,
                        context_bundle,
                        specialist_fns=specialist_fns,
                        rules_mode=rules_mode,
                        catalog_rule_paths=catalog_rule_paths,
                    ),
                )
            if "json" in formats:
                text = write_json_report(json_path, result)
                if json_path is None:
                    json_stdout = verbose or "console" not in formats
                    if json_stdout:
                        print(text)
            if "sarif" in formats:
                p = sarif_path or Path("governance-result.sarif")
                write_sarif(p, result)

            maybe_post_pr_comment(repo_root, result, post_pr)

            duration_ms = int((time.perf_counter() - t0) * 1000)
            exit_code = 0 if result.passed else 1
            emit_gendd(
                logger,
                "job.completed",
                "governance run completed",
                exit_code=exit_code,
                gate_passed=result.passed,
                findings_total=len(result.findings),
                by_severity=dict(result.by_severity),
                duration_ms=duration_ms,
                advisory=result.advisory,
                cli_version=result.run.cli_version if result.run else None,
                model_provider=result.run.model_provider if result.run else None,
                model_name=result.run.model_name if result.run else None,
                llm_call_count=len(result.run.llm_calls) if result.run else None,
                total_input_tokens=result.run.total_input_tokens if result.run else None,
                total_output_tokens=result.run.total_output_tokens if result.run else None,
                total_tokens=result.run.total_tokens if result.run else None,
                max_prompt_tokens=result.run.max_prompt_tokens if result.run else None,
            )
            return exit_code
    finally:
        set_progress_stdout_preferred(True)


async def _run_once(
    command: str,
    settings: Settings,
    repo_root: Path,
    *,
    scope: str,
    base: str,
    head: str,
    commit_sha: str | None,
    offline: bool,
    formats: set[str],
    json_path: Path | None,
    sarif_path: Path | None,
    post_pr: bool,
    verbose: bool = False,
    specialist_fns: list[AgentFn] | None = None,
) -> int:
    import uuid

    from gendd_governance.context.diff import GitDiffScope
    from gendd_governance.observability.logging import gendd_run_context

    pr = get_pr_context_from_env(repo_root)
    if pr:
        diff_text = pr.diff_text
        base_ref: str | None = None
        head_ref: str | None = None
        scope_desc = f"Pull request #{pr.number} (GitHub)"
        logger.info("Using PR #%s diff from gh", pr.number)
        last_run_replay = _build_last_run_replay(
            from_pr=True,
            scope=scope,
            base=base,
            head=head,
            commit_sha=commit_sha,
            command=command,
            specialist_fns=specialist_fns,
        )
    else:
        diff_text, base_ref, head_ref = resolve_git_diff(
            repo_root,
            cast(GitDiffScope, scope),
            base,
            head,
            commit_sha,
        )
        scope_desc = _scope_label(scope, base, head, commit_sha)
        if scope == "range":
            logger.info("Using git diff %s...%s", base, head)
        elif scope == "unstaged":
            logger.info(
                "Using unstaged diff: git diff (tracked) + git diff --no-index (untracked)"
            )
        elif scope == "staged":
            logger.info("Using staged git diff (index vs HEAD)")
        else:
            logger.info("Using git show %s", commit_sha)
        last_run_replay = _build_last_run_replay(
            from_pr=False,
            scope=scope,
            base=base,
            head=head,
            commit_sha=commit_sha,
            command=command,
            specialist_fns=specialist_fns,
        )

    run_id = str(uuid.uuid4())
    with gendd_run_context(job_id=run_id, command=command):
        return await run_governance_from_diff_text(
            command,
            settings,
            repo_root,
            diff_text,
            offline,
            formats,
            json_path,
            sarif_path,
            post_pr,
            last_run_replay=last_run_replay,
            verbose=verbose,
            base_ref=base_ref,
            head_ref=head_ref,
            scope_description=scope_desc,
            specialist_fns=specialist_fns,
        )


def _scope_label(scope: str, base: str, head: str, commit_sha: str | None) -> str:
    if scope == "unstaged":
        return "Unstaged changes (working tree, incl. untracked)"
    if scope == "staged":
        return "Staged changes (index vs HEAD)"
    if scope == "commit":
        c = (commit_sha or "").strip()
        return f"Commit {c}" if c else "Commit"
    return f"Branch range ({base}…{head})"


def _prompt_commit_sha() -> str:
    import questionary

    from gendd_governance.wizard.init_flow import QUESTIONARY_STYLE

    r = questionary.text(
        "Commit SHA (full or short)",
        style=QUESTIONARY_STYLE,
    ).ask()
    if r is None:
        raise KeyboardInterrupt
    return r.strip()


def _prompt_specialist_agents() -> list[AgentFn]:
    import questionary
    from questionary import Choice

    from gendd_governance.orchestrator.graph import (
        AGENT_LABELS,
        SPECIALIST_FNS_ALPHABETICAL,
        parse_specialist_labels,
    )
    from gendd_governance.wizard.init_flow import QUESTIONARY_STYLE

    choices = [
        Choice(AGENT_LABELS[fn], value=AGENT_LABELS[fn]) for fn in SPECIALIST_FNS_ALPHABETICAL
    ]
    picked = questionary.checkbox(
        "Which agents should run? (space to toggle, enter to confirm)",
        choices=choices,
        style=QUESTIONARY_STYLE,
    ).ask()
    if picked is None:
        raise KeyboardInterrupt
    if not picked:
        print("Select at least one agent.", file=sys.stderr)
        raise SystemExit(2)
    return parse_specialist_labels(",".join(picked))


def _prompt_specialist_agents_with_defaults(preselected_labels: list[str]) -> list[AgentFn]:
    import questionary
    from questionary import Choice

    from gendd_governance.orchestrator.graph import (
        AGENT_LABELS,
        SPECIALIST_FNS_ALPHABETICAL,
        parse_specialist_labels,
    )
    from gendd_governance.wizard.init_flow import QUESTIONARY_STYLE

    pre: set[str] = set(preselected_labels)
    choices = [
        Choice(
            AGENT_LABELS[fn],
            value=AGENT_LABELS[fn],
            checked=(AGENT_LABELS[fn] in pre),
        )
        for fn in SPECIALIST_FNS_ALPHABETICAL
    ]
    picked = questionary.checkbox(
        "Which agents should run? (space to toggle, enter to confirm; "
        "suggested agents start selected)",
        choices=choices,
        style=QUESTIONARY_STYLE,
    ).ask()
    if picked is None:
        raise KeyboardInterrupt
    if not picked:
        print("Select at least one agent.", file=sys.stderr)
        raise SystemExit(2)
    return parse_specialist_labels(",".join(picked))


def _finalize_specialist_agents(agents_csv: str | None) -> list[AgentFn]:
    from gendd_governance.orchestrator.graph import parse_specialist_labels

    if agents_csv is not None and agents_csv.strip():
        try:
            return parse_specialist_labels(agents_csv)
        except ValueError as e:
            print(f"error: {e}", file=sys.stderr)
            raise SystemExit(2) from e
    if sys.stdin.isatty():
        return _prompt_specialist_agents()
    print(
        "error: `gendd select` needs --agents when stdin is not a TTY "
        "(comma-separated specialist labels, e.g. reviewer,security).",
        file=sys.stderr,
    )
    raise SystemExit(2)


def _prompt_run_scope(default_base: str, default_head: str) -> tuple[str, str | None]:
    import questionary
    from questionary import Choice

    from gendd_governance.wizard.init_flow import QUESTIONARY_STYLE

    choice = questionary.select(
        "What should we diff?",
        choices=[
            Choice("Unstaged changes (working tree, incl. untracked)", value="unstaged"),
            Choice("Staged changes (index vs HEAD)", value="staged"),
            Choice(f"Branch range ({default_base}…{default_head})", value="range"),
            Choice("Single commit (you will enter a SHA)", value="commit"),
        ],
        style=QUESTIONARY_STYLE,
    ).ask()
    if choice is None:
        raise KeyboardInterrupt
    if choice == "commit":
        sha = _prompt_commit_sha()
        if not sha:
            print("A commit SHA is required.", file=sys.stderr)
            raise SystemExit(2)
        return "commit", sha
    return choice, None


def _finalize_run_scope(args: argparse.Namespace) -> tuple[str, str | None]:
    if args.scope is not None:
        scope: str = args.scope
        commit_sha = (args.commit or "").strip() or None
        if scope == "commit":
            if not commit_sha:
                if sys.stdin.isatty():
                    commit_sha = _prompt_commit_sha()
                if not commit_sha:
                    print(
                        "error: --commit is required when --scope=commit "
                        "(or run interactively to enter a SHA)",
                        file=sys.stderr,
                    )
                    raise SystemExit(2)
        return scope, commit_sha

    if sys.stdin.isatty():
        return _prompt_run_scope(args.base, args.head)

    return "unstaged", None


def _run_suggest_command(args: argparse.Namespace, repo_root: Path, settings: Settings) -> int:
    """Recommend agents from metadata; optionally prompt like `select` then run governance."""
    import asyncio

    from gendd_governance.context.diff import GitDiffScope
    from gendd_governance.suggest.agents_from_metadata import agents_from_metadata

    pr = get_pr_context_from_env(repo_root)
    if pr:
        diff_text = pr.diff_text
        base_ref, head_ref = None, None
        scope, commit_sha = "range", None
    else:
        scope, commit_sha = _finalize_run_scope(args)
        diff_text, base_ref, head_ref = resolve_git_diff(
            repo_root,
            cast(GitDiffScope, scope),
            args.base,
            args.head,
            commit_sha,
        )

    changed_paths = resolve_changed_paths(repo_root, diff_text, base_ref, head_ref)
    result = agents_from_metadata(changed_paths, diff_text, collect_reasons=args.verbose)

    if result.is_empty_scope:
        print(
            "gendd suggest: no changes detected (no paths and no diff hunks); "
            "recommending reviewer only.",
            file=sys.stderr,
        )

    print_only = (
        getattr(args, "print_only", False) or getattr(args, "json", False) or not sys.stdin.isatty()
    )
    interactive = not print_only
    if interactive:
        print(
            f"gendd suggest: pre-selecting agents in the checklist: {', '.join(result.agents)}",
            file=sys.stderr,
        )
        _maybe_hint_missing_config(repo_root, args.offline)
        specialist_fns = _prompt_specialist_agents_with_defaults(result.agents)
        formats = _parse_formats(args.format)
        try:
            return asyncio.run(
                _run_once(
                    AI_SELECT_COMMAND,
                    settings,
                    repo_root,
                    scope=scope,
                    base=args.base,
                    head=args.head,
                    commit_sha=commit_sha,
                    offline=args.offline,
                    formats=formats,
                    json_path=args.json_out,
                    sarif_path=args.sarif_out,
                    post_pr=args.post_pr,
                    verbose=args.verbose,
                    specialist_fns=specialist_fns,
                )
            )
        except KeyboardInterrupt:
            return 130

    if getattr(args, "json", False):
        payload: dict[str, object] = {"agents": result.agents}
        if args.verbose:
            payload["reasons"] = result.reasons
        print(json.dumps(payload, indent=2))
    else:
        print(",".join(result.agents))
        if args.verbose and result.reasons:
            for label in result.agents:
                for reason in result.reasons.get(label, []):
                    print(f"# {label}: {reason}", file=sys.stderr)
    return 0


def main(argv: list[str] | None = None) -> int:
    _suppress_noisy_dependency_warnings()
    raw = list(sys.argv[1:] if argv is None else argv)

    prog = os.path.basename(sys.argv[0]) if argv is None and sys.argv else "gendd"
    parser = build_arg_parser(prog)
    argcomplete.autocomplete(parser)
    args = parser.parse_args(raw)

    if args.action == "help":
        from gendd_governance.cli_help import print_cli_reference

        print_cli_reference(prog=prog)
        return 0

    if args.action == "init":
        from gendd_governance.init_cmd import run_init_command

        return run_init_command(workspace_root(), force=args.force, defaults=args.defaults)

    import asyncio

    from gendd_governance.last_run import parse_replay_for_repeat, read_last_run_payload

    repo_root = get_repo_root(workspace_root())
    settings = load_settings(repo_root)
    configure_logging(settings)

    if args.action == "suggest":
        try:
            return _run_suggest_command(args, repo_root, settings)
        except KeyboardInterrupt:
            return 130

    if args.action == "repeat":
        _maybe_hint_missing_config(repo_root, args.offline)
        formats = _parse_formats(args.format)
        try:
            data = read_last_run_payload(repo_root)
            replay = parse_replay_for_repeat(data)
        except FileNotFoundError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        except (OSError, ValueError) as e:
            print(f"error: {e}", file=sys.stderr)
            return 2

        command = data.get("command")
        if not isinstance(command, str) or not command.strip():
            print("error: last-run.json has no valid `command` field.", file=sys.stderr)
            return 2
        if command != AI_SELECT_COMMAND and command not in GOVERNANCE_COMMANDS:
            print(
                f"error: last-run command {command!r} is not a supported governance command. "
                "Run a new `gendd run <command>` or `gendd select` to refresh last-run.json.",
                file=sys.stderr,
            )
            return 2
        if command == AI_SELECT_COMMAND:
            if not replay.specialist_labels:
                print(
                    "error: last `ai-select` run did not record specialist_labels; "
                    "run `gendd select` again.",
                    file=sys.stderr,
                )
                return 2
            from gendd_governance.orchestrator.graph import parse_specialist_labels

            try:
                specialist_fns = parse_specialist_labels(",".join(replay.specialist_labels))
            except ValueError as e:
                print(f"error: {e}", file=sys.stderr)
                return 2
        else:
            specialist_fns = None

        try:
            if replay.diff_source == "github_pr":
                if not get_pr_context_from_env(repo_root):
                    print(
                        "error: last run used a GitHub PR diff; `repeat` needs the same "
                        "PR context (e.g. in CI with GITHUB_REF, or with gh available).",
                        file=sys.stderr,
                    )
                    return 2
                return asyncio.run(
                    _run_once(
                        command,
                        settings,
                        repo_root,
                        scope="unstaged",
                        base="origin/main",
                        head="HEAD",
                        commit_sha=None,
                        offline=args.offline,
                        formats=formats,
                        json_path=args.json_out,
                        sarif_path=args.sarif_out,
                        post_pr=args.post_pr,
                        verbose=args.verbose,
                        specialist_fns=specialist_fns,
                    )
                )
            assert replay.git_scope is not None
            return asyncio.run(
                _run_once(
                    command,
                    settings,
                    repo_root,
                    scope=replay.git_scope,
                    base=replay.base,
                    head=replay.head,
                    commit_sha=replay.commit_sha,
                    offline=args.offline,
                    formats=formats,
                    json_path=args.json_out,
                    sarif_path=args.sarif_out,
                    post_pr=args.post_pr,
                    verbose=args.verbose,
                    specialist_fns=specialist_fns,
                )
            )
        except KeyboardInterrupt:
            return 130

    if args.action == "select":
        _maybe_hint_missing_config(repo_root, args.offline)
        formats = _parse_formats(args.format)
        try:
            specialist_fns = _finalize_specialist_agents(args.agents)
            pr_ctx = get_pr_context_from_env(repo_root)
            if pr_ctx:
                scope, commit_sha = "range", None
            else:
                scope, commit_sha = _finalize_run_scope(args)
            return asyncio.run(
                _run_once(
                    AI_SELECT_COMMAND,
                    settings,
                    repo_root,
                    scope=scope,
                    base=args.base,
                    head=args.head,
                    commit_sha=commit_sha,
                    offline=args.offline,
                    formats=formats,
                    json_path=args.json_out,
                    sarif_path=args.sarif_out,
                    post_pr=args.post_pr,
                    verbose=args.verbose,
                    specialist_fns=specialist_fns,
                )
            )
        except KeyboardInterrupt:
            return 130

    if args.action == "run" or args.action in GOVERNANCE_COMMANDS:
        _maybe_hint_missing_config(repo_root, args.offline)
        formats = _parse_formats(args.format)
        try:
            pr_ctx = get_pr_context_from_env(repo_root)
            if pr_ctx:
                scope, commit_sha = "range", None
            else:
                scope, commit_sha = _finalize_run_scope(args)
            return asyncio.run(
                _run_once(
                    args.command,
                    settings,
                    repo_root,
                    scope=scope,
                    base=args.base,
                    head=args.head,
                    commit_sha=commit_sha,
                    offline=args.offline,
                    formats=formats,
                    json_path=args.json_out,
                    sarif_path=args.sarif_out,
                    post_pr=args.post_pr,
                    verbose=args.verbose,
                )
            )
        except KeyboardInterrupt:
            return 130

    return 2


def __getattr__(name: str) -> object:
    """Lazy ``questionary`` so ``import gendd_governance.cli`` stays free of the TUI stack."""
    if name == "questionary":
        import questionary

        return questionary
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


if __name__ == "__main__":
    raise SystemExit(main())
