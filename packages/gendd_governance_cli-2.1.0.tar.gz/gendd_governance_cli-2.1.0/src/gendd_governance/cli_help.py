"""Full CLI reference for `gendd help` (rich output)."""

from __future__ import annotations

import sys
from importlib.metadata import PackageNotFoundError, version

from gendd_governance.commands import GOVERNANCE_COMMANDS
from gendd_governance.config import GENDD_LOCAL_CONFIG_DIR


def _pkg_version() -> str:
    try:
        return version("gendd-governance-cli")
    except PackageNotFoundError:
        return "unknown"


def print_cli_reference(*, prog: str) -> None:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    from gendd_governance.orchestrator.command_metadata import (
        COMMAND_TO_AGENT_LABELS,
        SPECIALIST_LABELS_ORDERED,
    )

    console = Console(file=sys.stdout, highlight=False)
    title = Text.assemble(
        ("GenDD Agentic Governance CLI", "bold"),
        (f"  (v{_pkg_version()})", "dim"),
    )
    console.print(Panel(title, border_style="cyan", expand=False))
    console.print()

    console.rule("[bold]Ways to invoke")
    console.print(
        f"[dim]•[/dim] [cyan]{prog} help[/cyan] — this reference\n"
        f"[dim]•[/dim] [cyan]{prog} init[/cyan] [dim][--force] [--defaults][/dim]\n"
        f"[dim]•[/dim] [cyan]{prog} run[/cyan] [dim]<command>[/dim] [dim][run options…][/dim]\n"
        f"[dim]•[/dim] [cyan]{prog} select[/cyan] "
        f"[dim][--agents …][run options…][/dim] — pick specialists, "
        f"then run on a diff\n"
        f"[dim]•[/dim] [cyan]{prog} suggest[/cyan] "
        f"[dim][--print-only|--json][-v][run options…][/dim] — from metadata, "
        f"TTY defaults to the same checklist as [cyan]select[/cyan] with suggestions "
        f"pre-selected, then runs; use [bold]--print-only[/bold] or [bold]--json[/bold] "
        f"for labels only\n"
        f"[dim]•[/dim] [cyan]{prog} repeat[/cyan] "
        f"[dim][run options…][/dim] — same diff scope and command as "
        f"[bold]{GENDD_LOCAL_CONFIG_DIR}/last-run.json[/bold] (v2+)\n"
        f"[dim]•[/dim] [cyan]{prog} <command>[/cyan] [dim][run options…][/dim] "
        f"— same as [cyan]{prog} run <command>[/cyan] "
        f"([dim]{', '.join(GOVERNANCE_COMMANDS[:3])}, …[/dim])\n"
    )
    console.print(
        "[bold]Shell tab completion[/bold] (bash / zsh / fish): install [cyan]argcomplete[/cyan], "
        "then for example\n"
        '[cyan]eval "$(register-python-argcomplete gendd)"[/cyan] in your shell rc '
        "(or [cyan]activate-global-python-argcomplete --user[/cyan]).\n"
        "Use the same executable name you run "
        "([cyan]gendd[/cyan], [cyan]gendd-governance[/cyan], …).\n"
    )

    console.rule("[bold]Subcommands")
    t_sub = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
    t_sub.add_column("Command", style="cyan", no_wrap=True)
    t_sub.add_column("Purpose")
    t_sub.add_row("help", "Print this reference (no repo or network required).")
    t_sub.add_row(
        "init",
        f"Create [bold]{GENDD_LOCAL_CONFIG_DIR}/.env[/bold] (interactive wizard or "
        "[bold]--defaults[/bold] template).",
    )
    t_sub.add_row(
        "run",
        "Run governance agents on a git diff; [bold]command[/bold] selects which agents.",
    )
    labels_hint = ", ".join(sorted(SPECIALIST_LABELS_ORDERED, key=str.casefold)[:4]) + ", …"
    t_sub.add_row(
        "select",
        "Interactive multi-select of specialist agents (or [bold]--agents[/bold] "
        f"comma-separated labels: [dim]{labels_hint}[/dim]); same run options as [bold]run[/bold].",
    )
    t_sub.add_row(
        "suggest",
        "Heuristic specialist pre-selection from changed paths and a capped diff slice. "
        "In a TTY, defaults to the same checklist as [bold]select[/bold] with suggestions "
        "pre-selected, then runs. Use [bold]--print-only[/bold] or [bold]--json[/bold] "
        "to print labels only (or for scripts).",
    )
    t_sub.add_row(
        "repeat",
        f"Re-run with the same scope and command as the last completed run "
        f"([bold]{GENDD_LOCAL_CONFIG_DIR}/last-run.json[/bold] v2+).",
    )
    console.print(t_sub)
    console.print()

    console.rule("[bold]Run — governance commands [dim](positional)[/dim]")
    t_cmd = Table(show_header=True, header_style="bold")
    t_cmd.add_column("command", style="cyan", no_wrap=True)
    t_cmd.add_column("Agents / stages")
    for name in GOVERNANCE_COMMANDS:
        labels = ", ".join(COMMAND_TO_AGENT_LABELS[name])
        t_cmd.add_row(name, labels)
    console.print(t_cmd)
    console.print()

    console.rule("[bold]Run — flags")
    t_flags = Table(show_header=True, header_style="bold")
    t_flags.add_column("Option", style="cyan", no_wrap=True)
    t_flags.add_column("Description")
    t_flags.add_row(
        "--agents LABELS",
        "Only for [bold]select[/bold]: comma-separated specialist labels "
        "(e.g. [bold]reviewer,security[/bold]). Required when stdin is not a TTY.",
    )
    t_flags.add_row(
        "--scope",
        "[unstaged|staged|range|commit] What to diff. "
        "Omitted + interactive TTY → prompt. "
        "Omitted + non-TTY → [bold]unstaged[/bold].",
    )
    t_flags.add_row("--commit SHA", "With [bold]--scope=commit[/bold]: revision to show.")
    t_flags.add_row(
        "--base REF",
        "With [bold]--scope=range[/bold]: base of range (default [bold]origin/main[/bold]).",
    )
    t_flags.add_row(
        "--head REF",
        "With [bold]--scope=range[/bold]: head of range (default [bold]HEAD[/bold]).",
    )
    t_flags.add_row(
        "--format",
        "Comma-separated: [bold]console[/bold], [bold]json[/bold], [bold]sarif[/bold]. "
        "Default [bold]console,json[/bold] (JSON not echoed to stdout unless [bold]-v[/bold]).",
    )
    t_flags.add_row("--json-out PATH", "Write JSON report to file.")
    t_flags.add_row("--sarif-out PATH", "Write SARIF (default file if flag without path).")
    t_flags.add_row("--post-pr", "Post summary to GitHub PR when PR context is detected.")
    t_flags.add_row(
        "--offline",
        "Stub LLM (no cloud). Rules use [bold]select[/bold] mode with deterministic fallback "
        "(alwaysApply + keyword routing), not the LLM router.",
    )
    t_flags.add_row("-v, --verbose", "With default format, also print JSON on stdout.")
    t_flags.add_row(
        "(stdout / stderr)",
        "While agents run, [bold]gendd: …[/bold] progress lines go to **stdout** when "
        "[bold]console[/bold] is in [bold]--format[/bold] (default), so they stay separate "
        "from INFO logs and the Rich report on stderr. With [bold]--format json[/bold] only, "
        "progress stays on stderr so stdout stays machine-readable JSON.",
    )
    console.print(t_flags)
    console.print()

    console.rule("[bold]Diff scope — behavior")
    console.print(
        "[bold]unstaged[/bold] — [dim]git diff[/dim] (tracked) + [dim]git diff --no-index[/dim] "
        "for untracked; paths: [dim]git ls-files -o -m --exclude-standard[/dim]\n"
        "[bold]staged[/bold] — [dim]git diff --cached[/dim] (index vs HEAD)\n"
        "[bold]range[/bold] — [dim]git diff base…head[/dim] (merge-base style with fallback)\n"
        "[bold]commit[/bold] — [dim]git show[/dim] patch for one revision\n\n"
        "When GitHub PR context is available ([dim]gh[/dim] / env), the PR diff is used and "
        "scope is not prompted.\n"
    )

    console.rule("[bold]Init — flags")
    t_init = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
    t_init.add_column("Option", style="cyan", no_wrap=True)
    t_init.add_column("Description")
    t_init.add_row("--force", "Overwrite existing local .env.")
    t_init.add_row("--defaults", "Write commented template only (no prompts).")
    console.print(t_init)
    console.print()

    console.rule("[bold]Configuration [dim](environment / .env)[/dim]")
    console.print(
        "Loaded from the process environment, then [bold].env[/bold] in the current working "
        "directory, then [bold]"
        f"{GENDD_LOCAL_CONFIG_DIR}/.env[/bold] under the git repo root (later overrides "
        "earlier).\n"
        "[bold]run[/bold], [bold]select[/bold], and [bold]gendd <ai-*>[/bold] shorthands share "
        "the same governance pipeline once invocation-specific options are resolved; model, "
        "gate, logging, and console formatting variables apply the same way. "
        "[bold]--format[/bold], [bold]-v[/bold], and [bold]GENDD_CONSOLE_*[/bold] / "
        "[bold]GENDD_LOG_*[/bold] affect [bold]select[/bold] outputs exactly as they do for "
        "[bold]run[/bold].\n"
    )
    t_env = Table(show_header=True, header_style="bold")
    t_env.add_column("Variable", style="cyan", no_wrap=True)
    t_env.add_column("Role")
    rows: list[tuple[str, str]] = [
        ("GENDD_MODEL_PROVIDER", "vertex | openai | azure_openai | bedrock | anthropic"),
        ("GENDD_VERTEX_MODEL", "Gemini model id"),
        ("GENDD_VERTEX_LOCATION", "Vertex region"),
        ("GOOGLE_CLOUD_PROJECT", "GCP project (Vertex)"),
        ("OPENAI_API_KEY", "OpenAI"),
        ("GENDD_OPENAI_MODEL", "OpenAI model id"),
        ("AZURE_OPENAI_API_KEY", "Azure OpenAI"),
        ("AZURE_OPENAI_ENDPOINT", "Azure OpenAI"),
        ("AZURE_OPENAI_DEPLOYMENT_NAME", "Azure deployment"),
        ("AZURE_OPENAI_API_VERSION", "Azure API version"),
        ("GENDD_BEDROCK_REGION", "AWS Bedrock region"),
        ("GENDD_BEDROCK_MODEL_ID", "Bedrock model id"),
        ("ANTHROPIC_API_KEY", "Anthropic API"),
        ("GENDD_ANTHROPIC_MODEL", "Anthropic model id"),
        ("GENDD_ADVISORY_MODE", "If true, gate never fails the process exit code"),
        ("GENDD_GATE_MAX_CRITICAL", "Allowed CRITICAL findings (0 = none)"),
        ("GENDD_GATE_MAX_HIGH", "Allowed HIGH findings"),
        ("GENDD_GATE_MAX_MEDIUM", "Allowed MEDIUM findings"),
        ("GENDD_GATE_MAX_LOW", "Allowed LOW findings"),
        ("GITHUB_TOKEN", "Optional: PR comment API"),
        ("GITHUB_REPOSITORY", "Optional: owner/repo for PR comments"),
        ("GENDD_LOG_FORMAT", "json | text"),
        ("GENDD_LOG_LEVEL", "Logging level"),
        ("GENDD_LOG_HEARTBEAT_INTERVAL_SECONDS", "Structured log heartbeat interval"),
        (
            "GENDD_LOG_AGENT_LIFECYCLE",
            "With text logs, structured per-agent INFO lines are hidden; set 1 to show them. "
            "Parallel runs always print short gendd: progress lines to stderr regardless",
        ),
        (
            "GENDD_PRINT_AGENT_LLM_OUTPUT",
            "Set 1 to echo each agent's raw model response (truncated) to stderr after it returns",
        ),
        (
            "GENDD_CONSOLE_ASCII",
            "Set 1 for +/- ASCII box borders; default is rounded Unicode panels",
        ),
        (
            "GENDD_CONSOLE_UNICODE",
            "Windows: set 0 to force ASCII borders (same as GENDD_CONSOLE_ASCII=1)",
        ),
        (
            "GENDD_CONSOLE_PLAIN",
            (
                "Set 1 for plain-text console report (no Rich panels); "
                "default is formatted Rich output"
            ),
        ),
        ("GENDD_CONSOLE_WIDTH", "Optional fixed width (chars) for Rich console output"),
        (
            "GENDD_CONSOLE_MAX_FINDING_PANELS",
            "Max per-finding detail panels in console report (default 25)",
        ),
        (
            "GENDD_RULES_CONTEXT_MODE",
            "full | select — load all bodies (full) or route per agent (select; default)",
        ),
        (
            "GENDD_RULES_SELECT_MAX_PER_AGENT",
            "Max non-alwaysApply rule ids per agent (alwaysApply entries are extra)",
        ),
        (
            "GENDD_RULES_ROUTER_DIFF_CHARS",
            "Truncation cap for diff text in the rules router prompt",
        ),
        (
            "GENDD_CONTEXT_PATHS_SELECT_MAX",
            "Max related doc or test paths per agent after LLM routing (select mode)",
        ),
        (
            "GENDD_CONTEXT_ROUTER_MAX_PER_CATEGORY",
            "Candidate pool size for related tests/docs before routing (select mode)",
        ),
        ("GENDD_SERVICE_NAME", "Service name in logs"),
        ("GENDD_SERVICE_VERSION", "Service version in logs"),
    ]
    for var, role in rows:
        t_env.add_row(var, role)
    console.print(t_env)
    console.print()

    console.rule("[bold]Project rules")
    console.print(
        "Agents receive bundled content from [bold].cursor/rules[/bold] (*.mdc), "
        "[bold].cursor/skills/**/SKILL.md[/bold], and [bold].claude/skills/**/SKILL.md[/bold] "
        "under the repository root.\n"
    )

    console.rule("[bold]Exit codes")
    console.print(
        "[bold]0[/bold] — gate passed (or advisory mode)\n"
        "[bold]1[/bold] — gate failed\n"
        "[bold]2[/bold] — setup error (e.g. rules load, model init)\n"
        "[bold]130[/bold] — interrupted (Ctrl+C)\n"
    )

    console.rule("[bold]More help")
    console.print(f"[dim]•[/dim] [cyan]{prog} --help[/cyan] — argparse summary for the top level\n")
    console.print(
        f"[dim]•[/dim] [cyan]{prog} run --help[/cyan] — argparse summary for [bold]run[/bold]\n"
    )
    console.print(
        f"[dim]•[/dim] [cyan]{prog} select --help[/cyan] — "
        "argparse summary for [bold]select[/bold]\n"
    )
    console.print(
        f"[dim]•[/dim] [cyan]{prog} init --help[/cyan] — argparse summary for [bold]init[/bold]\n"
    )
