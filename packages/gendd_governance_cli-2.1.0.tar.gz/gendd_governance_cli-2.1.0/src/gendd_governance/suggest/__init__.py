"""Metadata-only agent suggestions (no LLM, no network)."""

from gendd_governance.suggest.agents_from_metadata import SuggestResult, agents_from_metadata

__all__ = ["SuggestResult", "agents_from_metadata"]
