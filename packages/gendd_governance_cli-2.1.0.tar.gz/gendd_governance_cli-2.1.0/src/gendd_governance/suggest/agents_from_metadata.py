"""Heuristic specialist selection from paths and a bounded diff slice.

No network and no file reads.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from gendd_governance.orchestrator.command_metadata import SPECIALIST_LABELS_ORDERED

# Keep aligned with context/supplemental_signals.py path and pattern heuristics.
_DEFAULT_MAX_DIFF_BYTES: int = 512 * 1024

_LICENSE_PATH_RE = re.compile(
    r"^\+.*(?:LICENSE|LICENCE|COPYING|NOTICE)(?:\.|$)",
    re.MULTILINE | re.IGNORECASE,
)
_MANIFEST_PATH_RE = re.compile(
    r"(?:^|\s)(package\.json|package-lock\.json|pnpm-lock\.yaml|yarn\.lock|"
    r"requirements.*\.txt|pyproject\.toml|Pipfile(?:\.lock)?|poetry\.lock|"
    r"go\.mod|go\.sum|pom\.xml|build\.gradle(?:\.kts)?|gradle\.lockfile|"
    r"Cargo\.toml|Cargo\.lock|Gemfile(?:\.lock)?|composer\.json)",
    re.IGNORECASE,
)

_INFRA_PATH_HINTS: tuple[str, ...] = (
    ".github/workflows/",
    ".gitlab-ci.yml",
    ".circleci/",
    "azure-pipelines",
    ".buildkite/",
    "jenkinsfile",
    ".tf",
    ".tfvars",
    ".hcl",
)

_UI_SUFFIXES: frozenset[str] = frozenset(
    {
        ".tsx",
        ".jsx",
        ".vue",
        ".svelte",
        ".css",
        ".scss",
        ".less",
        ".html",
        ".htm",
    }
)

_PERF_PATTERNS: tuple[str, ...] = (
    r"time\.sleep\(",
    r"\.sleep\(",
    r"for\s+.+\s+in\s+.+\s*:.*\n\+.*await\s+",
    r"SELECT\s+.+\s+FROM",
)

_TELEMETRY_KEYS: tuple[str, ...] = (
    "logger.",
    "logging.",
    "log.",
    "structlog",
    "opentelemetry",
    "prometheus",
    "statsd",
    "datadog",
    "metric.",
    "histogram",
    "trace",
    "span",
    "sentry",
)

_A11Y_KEYS: tuple[str, ...] = (
    "aria-",
    "role=",
    "tabindex",
    "alt=",
    "focus",
    "keyboard",
    "screen reader",
    "wcag",
)

_LOCKFILE_BASENAMES: frozenset[str] = frozenset(
    {
        "package-lock.json",
        "pnpm-lock.yaml",
        "yarn.lock",
        "poetry.lock",
        "pipfile.lock",
        "go.sum",
        "cargo.lock",
        "gemfile.lock",
        "composer.lock",
        "gradle.lockfile",
        "package.json",
        "pyproject.toml",
        "pipfile",
        "go.mod",
        "cargo.toml",
        "gemfile",
        "composer.json",
        "pom.xml",
        "build.gradle",
        "build.gradle.kts",
    }
)


def _norm_rel(p: str) -> str:
    return p.replace("\\", "/").strip()


def _is_infra_path(rel: str) -> bool:
    p = rel.lower()
    return any(h in p for h in _INFRA_PATH_HINTS) or p.endswith((".tf", ".tfvars", ".hcl"))


def _has_unified_diff(diff_text: str) -> bool:
    return bool(re.search(r"^diff --git ", diff_text, re.MULTILINE))


def _order_labels(picked: set[str]) -> list[str]:
    return [lb for lb in SPECIALIST_LABELS_ORDERED if lb in picked]


@dataclass
class SuggestResult:
    """Ordered specialist labels and optional per-label reasons."""

    agents: list[str]
    reasons: dict[str, list[str]] = field(default_factory=dict)
    is_empty_scope: bool = False


def agents_from_metadata(
    changed_paths: list[str],
    diff_text: str,
    *,
    max_diff_bytes: int = _DEFAULT_MAX_DIFF_BYTES,
    collect_reasons: bool = False,
) -> SuggestResult:
    """Return recommended specialist labels from paths and a capped diff slice.

    *collect_reasons*: when True, fill :attr:`SuggestResult.reasons` with short explanation strings.
    """
    capped = diff_text if len(diff_text) <= max_diff_bytes else diff_text[:max_diff_bytes]
    has_paths = any(bool(p.strip()) for p in changed_paths)
    has_diff_hunks = _has_unified_diff(diff_text)
    has_changes = has_paths or has_diff_hunks

    picked: set[str] = set()
    reasons: dict[str, list[str]] = {}

    def add(label: str, reason: str) -> None:
        picked.add(label)
        if collect_reasons:
            reasons.setdefault(label, []).append(reason)

    if not has_changes:
        add("reviewer", "No changed paths or unified diff detected; defaulting to reviewer.")
        return SuggestResult(agents=_order_labels(picked), reasons=reasons, is_empty_scope=True)

    add("reviewer", "Baseline code review for scoped changes.")

    norms = [_norm_rel(p) for p in changed_paths if p.strip()]

    for rel in norms:
        low = rel.lower()
        base = Path(rel).name.lower()

        is_dep_path = base in _LOCKFILE_BASENAMES or (
            base.startswith("requirements") and base.endswith(".txt")
        )
        if is_dep_path:
            add("dependency", f"Dependency manifest or lockfile path: {rel}")

        if "/migrations/" in f"/{low}/" or "/alembic/" in f"/{low}/" or "flyway" in low:
            add("migration_rollout", f"Migration-style path: {rel}")
        if "migration" in low and (low.endswith(".sql") or "/db/" in f"/{low}/"):
            add("migration_rollout", f"Possible DB migration path: {rel}")

        if low.endswith("changelog.md") or base.startswith("changelog") or base == "history.md":
            add("changelog", f"Changelog or history path: {rel}")

        if _is_infra_path(rel):
            add("infra", f"CI/CD or infra path: {rel}")
        is_compose = base in {"compose.yaml", "compose.yml"}
        if base == "dockerfile" or "docker-compose" in base or is_compose:
            add("infra", f"Container or compose path: {rel}")
        elif any(
            fragment in low
            for fragment in (
                "/k8s/",
                "/kubernetes/",
                "/helm/",
                "/charts/",
                "chart.yaml",
                "values.yaml",
            )
        ):
            add("infra", f"Kubernetes or Helm path: {rel}")

        stem, suf = Path(rel).stem.lower(), Path(rel).suffix.lower()
        if suf in _UI_SUFFIXES:
            add("accessibility", f"UI/markup/CSS path: {rel}")
        if any(
            token in low
            for token in (
                "/docs/",
                "readme.md",
                "contributing.md",
                "doc/",
                "/documentation/",
            )
        ) or (suf == ".md" and "node_modules" not in low):
            add("documentation", f"Documentation path: {rel}")

        test_name = (
            "test" in stem
            or stem.startswith("test_")
            or stem.endswith("_test")
            or "/test/" in f"/{low}/"
            or "/tests/" in f"/{low}/"
            or "/__tests__/" in f"/{low}/"
            or ".spec." in base
            or ".test." in base
        )
        if test_name:
            add("test_validator", f"Test-like path: {rel}")

        if any(
            x in low
            for x in (
                "openapi",
                "swagger",
                "graphql",
                "api.raml",
                ".graphql",
            )
        ) or base.endswith((".graphql", ".gql")):
            add("api_contract", f"API or schema path: {rel}")

        if any(
            x in f"/{low}/"
            for x in (
                "/security/",
                "/auth/",
                "/crypto/",
                "/secrets/",
            )
        ) or any(
            x in base
            for x in (
                "oauth",
                "jwt",
                "saml",
                "secrets",
                "vault",
            )
        ):
            add("security", f"Security-sensitive path: {rel}")

        if any(x in low for x in (".eslintrc", "ruff.toml", "pre-commit", "makefile")):
            add("build_hygiene", f"Lint/build config path: {rel}")

        if any(x in low for x in ("privacy", "compliance", "gdpr", "hipaa", "soc2")):
            add("compliance", f"Compliance-related path: {rel}")

        if "adr/" in low or "/architecture" in low or base.endswith("arc42"):
            add("architecture", f"Architecture or ADR path: {rel}")

    if len({p for p in norms if p}) >= 3:
        add(
            "change_narrative",
            "Several files touched; changes-summary helps explain how they connect.",
        )

    # Diff-based (bounded slice)
    if _LICENSE_PATH_RE.search(capped):
        add("compliance", "Diff adds or changes LICENSE, NOTICE, or similar lines.")
    if _MANIFEST_PATH_RE.search(capped):
        add("dependency", "Diff touches a dependency manifest or lockfile.")
    for rx in (
        re.compile(r'^\+[^+].*["\']([@\w\-./]+)["\']\s*:\s*["\']?[\^~>=]*([\d][\w.\-]*)'),
        re.compile(r"^\+([a-zA-Z0-9_\-\[\]]+)==([\d][\w.\-]*)"),
    ):
        if rx.findall(capped, re.MULTILINE):
            add("dependency", "Added dependency line(s) in diff.")
            break

    low_c = capped.lower()
    for pat in _PERF_PATTERNS:
        if re.search(pat, capped, re.IGNORECASE | re.MULTILINE):
            add("performance", f"Diff matches performance heuristic: {pat!r}")
            break

    hits = [k for k in _TELEMETRY_KEYS if k.lower() in low_c]
    if hits:
        add("telemetry", f"Telemetry/logging keywords in diff: {', '.join(hits[:8])}")

    if any(Path(p).suffix.lower() in _UI_SUFFIXES for p in norms):
        keys = [k for k in _A11Y_KEYS if k.lower() in low_c]
        if keys:
            add(
                "accessibility",
                f"Accessibility-related tokens in diff: {', '.join(keys[:10])}",
            )

    agents = _order_labels(picked)
    return SuggestResult(agents=agents, reasons=reasons, is_empty_scope=False)
