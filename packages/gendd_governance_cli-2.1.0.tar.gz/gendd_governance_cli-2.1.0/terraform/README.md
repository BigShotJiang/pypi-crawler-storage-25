# Terraform (removed)

Google Artifact Registry, Workload Identity Federation, and related resources were **defined in this repository** and have been **removed from the tree**. Publishing now uses **public PyPI** with **Trusted Publishing (OIDC)** from GitHub Actions (`pypa/gh-action-pypi-publish`).

If those resources still exist in your GCP project, destroy them **before** or **from** a checkout that still has the old `.tf` files (for example from git history), or remove them manually in Cloud Console.

**State bucket caveat:** The previous module created a GCS bucket for Terraform state. If remote state lived **in that bucket**, migrate or delete state carefully so you do not strand resources or lock yourself out of `terraform destroy`.

**GitHub:** Remove secrets and variables that were only used for Artifact Registry publish (for example `GCP_WORKLOAD_IDENTITY_PROVIDER`, `GCP_SERVICE_ACCOUNT_EMAIL`, `GCP_PROJECT_ID`, `GCP_ARTIFACT_REGISTRY_UPLOAD_URL`) from repository or environment settings when no longer needed.
