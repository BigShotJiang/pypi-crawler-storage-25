from pydantic import Field

from kubex.k8s.v1_34.core.v1.app_armor_profile import AppArmorProfile
from kubex.k8s.v1_34.core.v1.se_linux_options import SELinuxOptions
from kubex.k8s.v1_34.core.v1.seccomp_profile import SeccompProfile
from kubex.k8s.v1_34.core.v1.sysctl import Sysctl
from kubex.k8s.v1_34.core.v1.windows_security_context_options import (
    WindowsSecurityContextOptions,
)
from kubex_core.models.base import BaseK8sModel


class PodSecurityContext(BaseK8sModel):
    """PodSecurityContext holds pod-level security attributes and common container settings. Some fields are also present in container.securityContext. Field values of container.securityContext take precedence over field values of PodSecurityContext."""

    app_armor_profile: AppArmorProfile | None = Field(
        default=None,
        alias="appArmorProfile",
        description="appArmorProfile is the AppArmor options to use by the containers in this pod. Note that this field cannot be set when spec.os.name is windows.",
    )
    fs_group: int | None = Field(
        default=None,
        alias="fsGroup",
        description="A special supplemental group that applies to all containers in a pod. Some volume types allow the Kubelet to change the ownership of that volume to be owned by the pod: 1. The owning GID will be the FSGroup 2. The setgid bit is set (new files created in the volume will be owned by FSGroup) 3. The permission bits are OR'd with rw-rw---- If unset, the Kubelet will not modify the ownership and permissions of any volume. Note that this field cannot be set when spec.os.name is windows.",
    )
    fs_group_change_policy: str | None = Field(
        default=None,
        alias="fsGroupChangePolicy",
        description='fsGroupChangePolicy defines behavior of changing ownership and permission of the volume before being exposed inside Pod. This field will only apply to volume types which support fsGroup based ownership(and permissions). It will have no effect on ephemeral volume types such as: secret, configmaps and emptydir. Valid values are "OnRootMismatch" and "Always". If not specified, "Always" is used. Note that this field cannot be set when spec.os.name is windows.',
    )
    run_as_group: int | None = Field(
        default=None,
        alias="runAsGroup",
        description="The GID to run the entrypoint of the container process. Uses runtime default if unset. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence for that container. Note that this field cannot be set when spec.os.name is windows.",
    )
    run_as_non_root: bool | None = Field(
        default=None,
        alias="runAsNonRoot",
        description="Indicates that the container must run as a non-root user. If true, the Kubelet will validate the image at runtime to ensure that it does not run as UID 0 (root) and fail to start the container if it does. If unset or false, no such validation will be performed. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence.",
    )
    run_as_user: int | None = Field(
        default=None,
        alias="runAsUser",
        description="The UID to run the entrypoint of the container process. Defaults to user specified in image metadata if unspecified. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence for that container. Note that this field cannot be set when spec.os.name is windows.",
    )
    se_linux_change_policy: str | None = Field(
        default=None,
        alias="seLinuxChangePolicy",
        description='seLinuxChangePolicy defines how the container\'s SELinux label is applied to all volumes used by the Pod. It has no effect on nodes that do not support SELinux or to volumes does not support SELinux. Valid values are "MountOption" and "Recursive". "Recursive" means relabeling of all files on all Pod volumes by the container runtime. This may be slow for large volumes, but allows mixing privileged and unprivileged Pods sharing the same volume on the same node. "MountOption" mounts all eligible Pod volumes with `-o context` mount option. This requires all Pods that share the same volume to use the same SELinux label. It is not possible to share the same volume among privileged and unprivileged Pods. Eligible volumes are in-tree FibreChannel and iSCSI volumes, and all CSI volumes whose CSI driver announces SELinux support by setting spec.seLinuxMount: true in their CSIDriver instance. Other volumes are always re-labelled recursively. "MountOption" value is allowed only when SELinuxMount feature gate is enabled. If not specified and SELinuxMount feature gate is enabled, "MountOption" is used. If not specified and SELinuxMount feature gate is disabled, "MountOption" is used for ReadWriteOncePod volumes and "Recursive" for all other volumes. This field affects only Pods that have SELinux label set, either in PodSecurityContext or in SecurityContext of all containers. All Pods that use the same volume should use the same seLinuxChangePolicy, otherwise some pods can get stuck in ContainerCreating state. Note that this field cannot be set when spec.os.name is windows.',
    )
    se_linux_options: SELinuxOptions | None = Field(
        default=None,
        alias="seLinuxOptions",
        description="The SELinux context to be applied to all containers. If unspecified, the container runtime will allocate a random SELinux context for each container. May also be set in SecurityContext. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence for that container. Note that this field cannot be set when spec.os.name is windows.",
    )
    seccomp_profile: SeccompProfile | None = Field(
        default=None,
        alias="seccompProfile",
        description="The seccomp options to use by the containers in this pod. Note that this field cannot be set when spec.os.name is windows.",
    )
    supplemental_groups: list[int] | None = Field(
        default=None,
        alias="supplementalGroups",
        description="A list of groups applied to the first process run in each container, in addition to the container's primary GID and fsGroup (if specified). If the SupplementalGroupsPolicy feature is enabled, the supplementalGroupsPolicy field determines whether these are in addition to or instead of any group memberships defined in the container image. If unspecified, no additional groups are added, though group memberships defined in the container image may still be used, depending on the supplementalGroupsPolicy field. Note that this field cannot be set when spec.os.name is windows.",
    )
    supplemental_groups_policy: str | None = Field(
        default=None,
        alias="supplementalGroupsPolicy",
        description='Defines how supplemental groups of the first container processes are calculated. Valid values are "Merge" and "Strict". If not specified, "Merge" is used. (Alpha) Using the field requires the SupplementalGroupsPolicy feature gate to be enabled and the container runtime must implement support for this feature. Note that this field cannot be set when spec.os.name is windows.',
    )
    sysctls: list[Sysctl] | None = Field(
        default=None,
        alias="sysctls",
        description="Sysctls hold a list of namespaced sysctls used for the pod. Pods with unsupported sysctls (by the container runtime) might fail to launch. Note that this field cannot be set when spec.os.name is windows.",
    )
    windows_options: WindowsSecurityContextOptions | None = Field(
        default=None,
        alias="windowsOptions",
        description="The Windows specific settings applied to all containers. If unspecified, the options within a container's SecurityContext will be used. If set in both SecurityContext and PodSecurityContext, the value specified in SecurityContext takes precedence. Note that this field cannot be set when spec.os.name is linux.",
    )
