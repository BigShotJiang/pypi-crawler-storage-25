# cqterrain
Helper Libary to Generate 3d models of greebles, buildings, and terrain using [CadQuery](https://cadquery.readthedocs.io/en/latest/intro.html).

## Examples
|||
|-|-|
|[![](documentation/image/building/17.png)](documentation/building.md)|[![](documentation/image/tile/30.png)](documentation/tile.md)|
|[![Pipe Mockup](./documentation/image/pipe/15.png)](documentation/pipe.md)|[![Pipe Mockup](./documentation/image/shieldwall/48.png)](documentation/shieldwall.md)|
|[![Book Case](./documentation/image/book/cover.png)](documentation/book.md)|[![Crystal Example](./documentation/image/crystal/05.png)](documentation/crystal.md)|

## Project Documention
* [Documentation](documentation/README.md)
  * [Barrier](documentation/barrier.md)
  * [Book](documentation/book.md)
  * [Bridge](documentation/bridge.md)
  * [Building](documentation/building.md)
  * [Crystal](documentation/crystal.md) 
  * [Damage](documentation/damage.md)
  * [Door](documentation/door.md)
  * [Floor](documentation/floor.md)
  * [Greeble](documentation/greeble.md)
  * [Material](documentation/material.md)
  * [Minibase](documentation/minibase.md)
  * [Pipe](documentation/pipe.md)
  * [Roof](documentation/roof.md)
  * [Ruin](documentation/ruin.md)
  * [Shieldwall](documentation/shieldwall.md)
  * [Spool](documentation/spool.md)
  * [Stairs](documentation/stairs.md)
  * [Tile](documentation/tile.md)
  * [Window](documentation/window.md)
  * [Walkway](documentation/walkway.md)
  * [Misc](documentation/misc.md) aka everything else
    * ladder
    * obelisk
    * stones
    * support


## Changes
* [Changelog](./changes.md)


## Dependencies
* [CadQuery 2.x](https://github.com/CadQuery/cadquery)
* [cadqueryhelper](https://github.com/medicationforall/cadqueryhelper)


## Projects Using This Library
* [Jersey Barrier Set](https://miniforall.com/jerseybarriers)
* [Pipe Terrain Set](https://miniforall.com/pipeterrain)
* [Shieldwall Terrain Set](https://miniforall.com/shieldwall)
* [Walkway Terrain Set](https://miniforall.com/walkways)

---

## Installation

Pip install from Pypi https://pypi.org/project/cqterrain/

    pip install cqterrain


**OR**

To install cqterrain directly from GitHub, run the following `pip` command:

	pip install git+https://github.com/medicationforall/cqterrain

**OR**

### Local Installation
From the cloned cqterrain directory run.

	pip install ./

---

## Running Example Scripts
[example_runner.py](example_runner.py) runs all examples.

``` bash
C:\Users\<user>\home\3d\cqterrain>python example_runner.py
```

**OR**

### Running individual examples
* From the root of the project run one of the example scripts:
  
``` bash
C:\Users\<user>\home\3d\cqterrain>python ./example/stairs.py
```
