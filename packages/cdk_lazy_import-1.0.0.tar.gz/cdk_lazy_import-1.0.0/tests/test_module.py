def test_import_works() -> None:
    import cdk_lazy_import

    assert hasattr(cdk_lazy_import, "__version__")


def test_install_exported() -> None:
    import cdk_lazy_import

    assert hasattr(cdk_lazy_import, "install")
