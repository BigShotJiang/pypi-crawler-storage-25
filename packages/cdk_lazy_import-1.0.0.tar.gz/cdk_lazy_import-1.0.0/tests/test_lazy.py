from __future__ import annotations

import importlib
import importlib.abc
import importlib.machinery
import importlib.util
import pathlib
import sys
import types
from typing import Any
import pytest

from cdk_lazy_import._lazy import (
    _CDK_PACKAGE,
    _CDKLazyFinder,
    _LazyLoader,
    _LazyModule,
    install,
)


@pytest.fixture(autouse=True)
def _clean_finder() -> Any:
    """Remove any installed _CDKLazyFinder from sys.meta_path before/after each test."""
    original_meta_path = sys.meta_path.copy()
    original_instance = _CDKLazyFinder.instance
    sys.meta_path[:] = [f for f in sys.meta_path if not isinstance(f, _CDKLazyFinder)]
    _CDKLazyFinder.instance = None
    yield
    sys.meta_path[:] = original_meta_path
    _CDKLazyFinder.instance = original_instance


@pytest.fixture()
def fake_aws_cdk(tmp_path: pathlib.Path) -> Any:
    """Create a minimal fake aws_cdk package on disk and register it in sys.modules."""
    pkg_dir = tmp_path / "aws_cdk"
    pkg_dir.mkdir()
    (pkg_dir / "__init__.py").write_text("")

    # Create a fake aws_s3 subpackage
    s3_dir = pkg_dir / "aws_s3"
    s3_dir.mkdir()
    (s3_dir / "__init__.py").write_text("Bucket = 'FakeBucket'\n")

    # Create a fake aws_iam subpackage
    iam_dir = pkg_dir / "aws_iam"
    iam_dir.mkdir()
    (iam_dir / "__init__.py").write_text("Role = 'FakeRole'\nPolicy = 'FakePolicy'\n")

    # Create a non-service subpackage (should NOT be lazified)
    cx_dir = pkg_dir / "cx_api"
    cx_dir.mkdir()
    (cx_dir / "__init__.py").write_text("CX = 'real'\n")

    # Create a single-file non-service module
    (pkg_dir / "pipelines.py").write_text("Pipeline = 'real'\n")

    # Register the fake aws_cdk package
    fake_mod = types.ModuleType(_CDK_PACKAGE)
    fake_mod.__path__ = [str(pkg_dir)]
    fake_mod.__package__ = _CDK_PACKAGE
    fake_mod.__spec__ = importlib.machinery.ModuleSpec(
        _CDK_PACKAGE,
        None,
        is_package=True,
    )
    fake_mod.__spec__.submodule_search_locations = [str(pkg_dir)]

    saved_modules: dict[str, types.ModuleType | None] = {}
    keys_to_clean = [
        _CDK_PACKAGE,
        f"{_CDK_PACKAGE}.aws_s3",
        f"{_CDK_PACKAGE}.aws_iam",
        f"{_CDK_PACKAGE}.cx_api",
        f"{_CDK_PACKAGE}.pipelines",
    ]
    for key in keys_to_clean:
        saved_modules[key] = sys.modules.pop(key, None)

    sys.modules[_CDK_PACKAGE] = fake_mod

    # Add tmp_path to sys.path so the real import machinery can find submodules
    sys.path.insert(0, str(tmp_path))

    yield pkg_dir

    # Cleanup
    sys.path.remove(str(tmp_path))
    for key in keys_to_clean:
        sys.modules.pop(key, None)
    for key, val in saved_modules.items():
        if val is not None:
            sys.modules[key] = val


class TestLazyModule:
    def test_repr(self) -> None:
        mod = _LazyModule("aws_cdk.aws_s3", None)
        assert repr(mod) == "<lazy module 'aws_cdk.aws_s3'>"

    def test_package_is_set(self) -> None:
        mod = _LazyModule("aws_cdk.aws_s3", None)
        assert mod.__package__ == _CDK_PACKAGE

    def test_path_with_dir(self, tmp_path: pathlib.Path) -> None:
        mod = _LazyModule("aws_cdk.aws_s3", str(tmp_path))
        assert mod.__path__ == [str(tmp_path)]

    def test_path_without_dir(self) -> None:
        mod = _LazyModule("aws_cdk.aws_s3", None)
        assert mod.__path__ == []

    def test_lazy_real_starts_none(self) -> None:
        mod = _LazyModule("aws_cdk.aws_s3", None)
        assert mod._lazy_real is None


class TestLazyLoader:
    def test_create_module_with_dir(self, tmp_path: pathlib.Path) -> None:
        subdir = tmp_path / "aws_s3"
        subdir.mkdir()
        loader = _LazyLoader(tmp_path)
        spec = importlib.machinery.ModuleSpec("aws_cdk.aws_s3", loader, is_package=True)
        mod = loader.create_module(spec)
        assert isinstance(mod, _LazyModule)
        assert mod.__name__ == "aws_cdk.aws_s3"
        assert mod.__path__ == [str(subdir)]

    def test_create_module_without_dir(self, tmp_path: pathlib.Path) -> None:
        loader = _LazyLoader(tmp_path)
        spec = importlib.machinery.ModuleSpec("aws_cdk.aws_s3", loader, is_package=True)
        mod = loader.create_module(spec)
        assert isinstance(mod, _LazyModule)
        assert mod.__path__ == []

    def test_exec_module_is_noop(self, tmp_path: pathlib.Path) -> None:
        loader = _LazyLoader(tmp_path)
        mod = types.ModuleType("test")
        loader.exec_module(mod)  # should not raise


class TestCDKLazyFinder:
    def test_find_spec_intercepts_service_modules(self, tmp_path: pathlib.Path) -> None:
        finder = _CDKLazyFinder(tmp_path)
        spec = finder.find_spec("aws_cdk.aws_s3", None)
        assert spec is not None
        assert spec.name == "aws_cdk.aws_s3"

    def test_find_spec_ignores_non_service_modules(self, tmp_path: pathlib.Path) -> None:
        finder = _CDKLazyFinder(tmp_path)
        assert finder.find_spec("aws_cdk.cx_api", None) is None
        assert finder.find_spec("aws_cdk.pipelines", None) is None
        assert finder.find_spec("aws_cdk._jsii", None) is None

    def test_find_spec_ignores_deep_imports(self, tmp_path: pathlib.Path) -> None:
        finder = _CDKLazyFinder(tmp_path)
        assert finder.find_spec("aws_cdk.aws_s3.notifications", None) is None

    def test_find_spec_ignores_unrelated_packages(self, tmp_path: pathlib.Path) -> None:
        finder = _CDKLazyFinder(tmp_path)
        assert finder.find_spec("boto3", None) is None
        assert finder.find_spec("other.aws_s3", None) is None

    def test_find_spec_skips_already_resolved_real_module(self, tmp_path: pathlib.Path) -> None:
        finder = _CDKLazyFinder(tmp_path)
        real_mod = types.ModuleType("aws_cdk.aws_s3")
        sys.modules["aws_cdk.aws_s3"] = real_mod
        try:
            assert finder.find_spec("aws_cdk.aws_s3", None) is None
        finally:
            sys.modules.pop("aws_cdk.aws_s3", None)

    def test_find_spec_allows_replacing_lazy_module(self, tmp_path: pathlib.Path) -> None:
        finder = _CDKLazyFinder(tmp_path)
        lazy_mod = _LazyModule("aws_cdk.aws_s3", None)
        sys.modules["aws_cdk.aws_s3"] = lazy_mod
        try:
            spec = finder.find_spec("aws_cdk.aws_s3", None)
            assert spec is not None
        finally:
            sys.modules.pop("aws_cdk.aws_s3", None)

    def test_instance_class_var_is_set(self, tmp_path: pathlib.Path) -> None:
        finder = _CDKLazyFinder(tmp_path)
        assert _CDKLazyFinder.instance is finder


class TestInstall:
    def test_install_when_aws_cdk_available(self, fake_aws_cdk: pathlib.Path) -> None:
        install()
        finders = [f for f in sys.meta_path if isinstance(f, _CDKLazyFinder)]
        assert len(finders) == 1
        assert finders[0] is _CDKLazyFinder.instance

    def test_install_is_idempotent(self, fake_aws_cdk: pathlib.Path) -> None:
        install()
        install()
        finders = [f for f in sys.meta_path if isinstance(f, _CDKLazyFinder)]
        assert len(finders) == 1

    def test_install_noop_when_aws_cdk_missing(self, monkeypatch: pytest.MonkeyPatch) -> None:
        # Ensure aws_cdk is not findable via sys.modules or sys.path
        sys.modules.pop(_CDK_PACKAGE, None)
        monkeypatch.setattr(sys, "path", [])
        install()
        finders = [f for f in sys.meta_path if isinstance(f, _CDKLazyFinder)]
        assert len(finders) == 0


class TestEndToEnd:
    def test_lazy_import_resolves_on_attribute_access(self, fake_aws_cdk: pathlib.Path) -> None:
        install()

        # Import should return a lazy module
        mod = importlib.import_module("aws_cdk.aws_s3")
        assert isinstance(mod, _LazyModule)

        # Attribute access triggers real import
        assert mod.Bucket == "FakeBucket"

        # After resolution, the real module is cached
        assert mod._lazy_real is not None

    def test_multi_attribute_access(self, fake_aws_cdk: pathlib.Path) -> None:
        install()

        mod = importlib.import_module("aws_cdk.aws_iam")
        assert isinstance(mod, _LazyModule)

        # First access triggers resolution
        assert mod.Role == "FakeRole"
        # Second access uses cached real module
        assert mod.Policy == "FakePolicy"

    def test_non_service_module_not_intercepted(self, fake_aws_cdk: pathlib.Path) -> None:
        install()

        mod = importlib.import_module("aws_cdk.cx_api")
        assert not isinstance(mod, _LazyModule)
        assert mod.CX == "real"

    def test_parent_attribute_updated_after_resolution(self, fake_aws_cdk: pathlib.Path) -> None:
        install()

        mod = importlib.import_module("aws_cdk.aws_s3")
        # Trigger resolution
        _ = mod.Bucket

        parent = sys.modules[_CDK_PACKAGE]
        assert hasattr(parent, "aws_s3")
        assert not isinstance(parent.aws_s3, _LazyModule)

    def test_finder_restored_after_import_error(self, fake_aws_cdk: pathlib.Path) -> None:
        install()

        mod = _LazyModule("aws_cdk.aws_nonexistent", None)
        sys.modules["aws_cdk.aws_nonexistent"] = mod

        with pytest.raises(ModuleNotFoundError):
            _ = mod.something

        # Finder should be restored even after an error
        finders = [f for f in sys.meta_path if isinstance(f, _CDKLazyFinder)]
        assert len(finders) == 1


class TestRealAwsCdk:
    """Tests using the real aws-cdk-lib package (available as a dev dependency)."""

    @pytest.fixture(autouse=True)
    def _clean_aws_cdk_submodules(self) -> Any:
        """Remove aws_cdk.aws_* submodules so the lazy finder can intercept them."""
        saved: dict[str, types.ModuleType] = {}
        for key in list(sys.modules):
            if key.startswith(f"{_CDK_PACKAGE}.aws_"):
                saved[key] = sys.modules.pop(key)
        # Also clear any cached attributes on the parent package
        parent = sys.modules.get(_CDK_PACKAGE)
        saved_attrs: dict[str, object] = {}
        if parent is not None:
            for attr in list(vars(parent)):
                if attr.startswith("aws_"):
                    saved_attrs[attr] = getattr(parent, attr)
                    delattr(parent, attr)
        yield
        # Restore original state
        for key in list(sys.modules):
            if key.startswith(f"{_CDK_PACKAGE}.aws_") and key not in saved:
                del sys.modules[key]
        sys.modules.update(saved)
        if parent is not None:
            for attr, val in saved_attrs.items():
                setattr(parent, attr, val)

    def test_install_with_real_aws_cdk(self) -> None:
        install()
        finders = [f for f in sys.meta_path if isinstance(f, _CDKLazyFinder)]
        assert len(finders) == 1

    def test_lazy_import_real_aws_s3(self) -> None:
        install()
        # aws_cdk.__init__ eagerly references aws_s3 types, so the lazy stub
        # resolves during import. Verify the resolved module works correctly.
        mod = importlib.import_module("aws_cdk.aws_s3")
        assert hasattr(mod, "Bucket")
        assert hasattr(mod, "IBucket")

    def test_real_non_service_module_not_intercepted(self) -> None:
        install()
        # cx_api is a non-service module — should load normally
        mod = importlib.import_module("aws_cdk.cx_api")
        assert not isinstance(mod, _LazyModule)


class TestPthFile:
    def test_pth_file_exists(self) -> None:
        pth_path = pathlib.Path(__file__).parents[1] / "cdk_lazy_import.pth"
        assert pth_path.exists()

    def test_pth_file_content(self) -> None:
        pth_path = pathlib.Path(__file__).parents[1] / "cdk_lazy_import.pth"
        content = pth_path.read_text().strip()
        assert content == "import cdk_lazy_import; cdk_lazy_import.install()"


class TestVersion:
    def test_version_is_string(self) -> None:
        import cdk_lazy_import

        assert isinstance(cdk_lazy_import.__version__, str)

    def test_version_is_not_empty(self) -> None:
        import cdk_lazy_import

        assert len(cdk_lazy_import.__version__) > 0
