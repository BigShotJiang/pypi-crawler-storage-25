"""Lazy-load aws_cdk submodules to speed up CDK synth.

Installs a meta path finder that intercepts ``import aws_cdk.aws_*``
service submodules and returns lightweight stub modules instead of eagerly
loading all ~300 service packages.  Each stub resolves to the real module
on first attribute access.  Non-service submodules (_jsii, cx_api,
pipelines, etc.) are imported normally.
"""

from __future__ import annotations

import importlib
import importlib.abc
import importlib.machinery
import importlib.util
import pathlib
import sys
import types
from typing import ClassVar

# Top-level package whose submodules we intercept.
_CDK_PACKAGE: str = "aws_cdk"

# Prefix for AWS service submodules (e.g. aws_s3, aws_iam, aws_lambda).
# Only these are lazified — everything else loads eagerly as normal.
_LAZY_PREFIX: str = "aws_"


class _LazyModule(types.ModuleType):
    """A stub module that defers loading until first attribute access.

    On first ``__getattr__`` call, the stub removes itself from
    ``sys.modules``, performs the real import, and caches the result in
    ``_lazy_real``.  Subsequent attribute lookups delegate directly to the
    cached real module — this is critical for multi-name imports like
    ``from aws_cdk.aws_iam import Role, Policy`` where ``__getattr__`` is
    called once per name on the same object.
    """

    __slots__ = ("_lazy_real",)

    _lazy_real: types.ModuleType | None

    def __init__(self, name: str, path: str | None) -> None:
        super().__init__(name)
        self.__package__ = _CDK_PACKAGE
        self.__path__ = [path] if path else []
        self.__loader__ = None
        self._lazy_real = None

    def __getattr__(self, attr: str) -> object:
        if self._lazy_real is not None:
            return getattr(self._lazy_real, attr)

        # Evict the stub so the real import machinery can take over.
        sys.modules.pop(self.__name__, None)

        # Temporarily remove our finder to avoid intercepting the real import.
        finder = _CDKLazyFinder.instance
        if finder is not None and finder in sys.meta_path:
            sys.meta_path.remove(finder)
        try:
            self._lazy_real = importlib.import_module(self.__name__)
        finally:
            if finder is not None and finder not in sys.meta_path:
                sys.meta_path.insert(0, finder)

        # Update the parent package's attribute to point at the real module
        # so future dotted access (aws_cdk.aws_iam) skips the stub.
        parent = sys.modules.get(_CDK_PACKAGE)
        if parent is not None:
            short_name = self.__name__.rpartition(".")[2]
            setattr(parent, short_name, self._lazy_real)

        return getattr(self._lazy_real, attr)

    def __repr__(self) -> str:
        return f"<lazy module {self.__name__!r}>"


class _LazyLoader(importlib.abc.Loader):
    """Loader that creates :class:`_LazyModule` stubs without executing them."""

    def __init__(self, pkg_dir: pathlib.Path) -> None:
        self._pkg_dir = pkg_dir

    def create_module(self, spec: importlib.machinery.ModuleSpec) -> _LazyModule:
        child_name = spec.name.rpartition(".")[2]
        subdir = self._pkg_dir / child_name
        path = str(subdir) if subdir.is_dir() else None
        return _LazyModule(spec.name, path)

    def exec_module(self, module: types.ModuleType) -> None:
        """No-op — the stub defers all execution to first attribute access."""


class _CDKLazyFinder(importlib.abc.MetaPathFinder):
    """Meta path finder that intercepts direct ``aws_cdk.aws_*`` imports.

    Only intercepts single-level submodules (e.g. ``aws_cdk.aws_s3``, not
    ``aws_cdk.aws_s3.notifications``).  Deeper imports are handled normally
    once the parent resolves.
    """

    instance: ClassVar[_CDKLazyFinder | None] = None

    def __init__(self, pkg_dir: pathlib.Path) -> None:
        _CDKLazyFinder.instance = self
        self._loader = _LazyLoader(pkg_dir)

    def find_spec(
        self,
        fullname: str,
        path: object,
        target: types.ModuleType | None = None,
    ) -> importlib.machinery.ModuleSpec | None:
        # Only intercept direct children of aws_cdk (exactly one dot).
        if not fullname.startswith(f"{_CDK_PACKAGE}.") or fullname.count(".") != 1:
            return None

        submodule_name = fullname.rpartition(".")[2]
        if not submodule_name.startswith(_LAZY_PREFIX):
            return None

        # Don't replace an already-resolved real module.
        existing = sys.modules.get(fullname)
        if existing is not None and not isinstance(existing, _LazyModule):
            return None

        return importlib.machinery.ModuleSpec(fullname, self._loader, is_package=True)


def install() -> None:
    """Install the lazy finder if ``aws_cdk`` is available.

    Safe to call multiple times — subsequent calls are no-ops if the finder
    is already registered.
    """
    if _CDKLazyFinder.instance is not None and _CDKLazyFinder.instance in sys.meta_path:
        return

    spec = importlib.util.find_spec(_CDK_PACKAGE)
    if spec is None or not spec.submodule_search_locations:
        return

    pkg_dir = pathlib.Path(spec.submodule_search_locations[0])
    if pkg_dir.is_dir():
        sys.meta_path.insert(0, _CDKLazyFinder(pkg_dir))
