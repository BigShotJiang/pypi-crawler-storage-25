"""Lazy-load aws_cdk submodules to speed up CDK synth.

This package is activated automatically via a ``.pth`` file when installed.
No manual imports or configuration are needed.
"""

from __future__ import annotations

import importlib.metadata as _importlib_metadata

from ._lazy import install

__all__ = ["__version__", "install"]

__version__: str = _importlib_metadata.version(__package__ or __name__)
