"""localfit — GPU toolkit for local LLMs. Will it fit? Benchmark. Monitor. Serve."""

__version__ = "1.6.0"
