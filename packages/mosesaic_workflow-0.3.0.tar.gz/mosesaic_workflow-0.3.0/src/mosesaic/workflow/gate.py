"""
human_gate() — suspends a workflow and waits for external approval.

Usage inside a workflow::

    approved = await human_gate(
        message="Please review the draft",
        payload=draft,
        timeout_hours=24,
    )
    if not approved:
        return WorkflowResult.rejected()

The gate emits a HumanGateEvent to the workflow's event log and blocks until
WorkflowRuntime.resolve_gate(gate_id, approved=True/False) is called, or until
the timeout expires (raises HumanGateTimeout).
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from mosesaic.workflow.context import _current_workflow_ctx
from mosesaic.workflow.result import HumanGateTimeout


@dataclass(frozen=True)
class HumanGateEvent:
    """Emitted to the workflow event log when a human gate is reached."""

    gate_id: UUID
    message: str
    payload: Any
    workflow_name: str
    timestamp: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )


async def human_gate(
    message: str,
    payload: Any = None,
    *,
    timeout_hours: float = 24.0,
) -> bool:
    """
    Suspend the workflow and wait for a human to approve or reject.

    Args:
        message:       Human-readable description of what needs review.
        payload:       The artifact to review (draft, plan, etc.).
        timeout_hours: How long to wait before raising HumanGateTimeout.

    Returns:
        True if approved, False if rejected.

    Raises:
        HumanGateTimeout: If no resolution arrives before timeout_hours.
        RuntimeError:     If called outside a workflow context.
    """
    import anyio

    ctx = _current_workflow_ctx.get(None)
    if ctx is None:
        raise RuntimeError(
            "human_gate() called outside of a workflow context. "
            "Use it only inside a @workflow-decorated function."
        )

    gate_id = uuid4()
    timeout_seconds = timeout_hours * 3600

    # Register the gate state so WorkflowRuntime can resolve it
    from mosesaic.workflow.context import _GateState
    gate_state = _GateState()
    ctx._gates[str(gate_id)] = gate_state

    # Emit event to workflow event log (readable via runtime.gate_events)
    event = HumanGateEvent(
        gate_id=gate_id,
        message=message,
        payload=payload,
        workflow_name=getattr(ctx, "_workflow_name", "unknown"),
    )
    ctx._gate_events.append(event)  # type: ignore[attr-defined]

    # Block until resolved or timed out
    try:
        return await gate_state.wait(timeout_seconds=timeout_seconds)
    except TimeoutError:
        raise HumanGateTimeout(str(gate_id), timeout_seconds)
