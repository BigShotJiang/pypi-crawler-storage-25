"""
verify() — retry loop for verification patterns.

Usage::

    async for attempt in verify(max_attempts=5, budget_usd=0.30):
        review = await step("reviewer", input=draft)
        if review["passed"]:
            break                     # success — exits the loop cleanly
        draft = await step("writer", input=review["feedback"])
        # no break → loops to the next attempt

If max_attempts is exhausted without a break, VerificationFailed is raised.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import AsyncIterator

from mosesaic.workflow.result import VerificationFailed


@dataclass(frozen=True)
class VerifyAttempt:
    """Yielded on each iteration of a verify() loop."""

    attempt: int      # 1-based attempt number
    max_attempts: int # total attempts allowed
    budget_usd: float | None = None

    @property
    def remaining(self) -> int:
        """How many more attempts are available (including the current one)."""
        return self.max_attempts - self.attempt + 1

    @property
    def is_last(self) -> bool:
        return self.attempt == self.max_attempts


async def verify(
    max_attempts: int = 3,
    *,
    budget_usd: float | None = None,
) -> AsyncIterator[VerifyAttempt]:
    """
    Async generator that drives a retry loop.

    Yields a VerifyAttempt on each iteration. The caller breaks out of the
    loop on success. If the loop runs to exhaustion, VerificationFailed is raised.

    Args:
        max_attempts: Maximum number of times the body may execute.
        budget_usd:   Optional per-loop budget cap (informational for now;
                      enforced by LLM context in future).
    """
    if max_attempts < 1:
        raise ValueError(f"max_attempts must be >= 1, got {max_attempts}")

    for i in range(max_attempts):
        attempt = VerifyAttempt(
            attempt=i + 1,
            max_attempts=max_attempts,
            budget_usd=budget_usd,
        )
        yield attempt
        # If we reach here the body didn't break → loop continues
        if i == max_attempts - 1:
            # Final iteration exhausted without success
            raise VerificationFailed(max_attempts)
