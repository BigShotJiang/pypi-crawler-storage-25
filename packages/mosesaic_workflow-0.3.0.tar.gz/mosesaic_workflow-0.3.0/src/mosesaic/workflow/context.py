"""WorkflowContext — injected into every workflow function."""

from __future__ import annotations
from contextvars import ContextVar
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from mosesaic.core.agent import AgentDefinition

# Set by WorkflowRuntime before invoking the workflow function.
# step() / parallel() / verify() read this to find the current context.
_current_workflow_ctx: ContextVar["WorkflowContext"] = ContextVar(
    "_current_workflow_ctx"
)


class WorkflowContext:
    """
    Passed to every workflow function. Holds:
    - input: the payload that started this workflow run
    - _agents: registered AgentDefinitions, keyed by name
    - _checkpoint: step-result cache (persists results across crashes)
    - _gates: pending human-gate events, keyed by gate_id
    """

    def __init__(
        self,
        input: Any,
        agents: dict[str, "AgentDefinition"],
        *,
        workflow_name: str = "unknown",
        budget_usd: float | None = None,
        step_timeout_seconds: float = 120.0,
        checkpoint: dict[str, Any] | None = None,
        gates: dict[str, "_GateState"] | None = None,
        llm_factory: Any | None = None,
        memory: Any | None = None,
    ) -> None:
        self.input = input
        self.budget_usd = budget_usd
        self.step_timeout_seconds = step_timeout_seconds
        self._workflow_name = workflow_name

        self._agents = agents
        self._checkpoint: dict[str, Any] = checkpoint if checkpoint is not None else {}
        self._gates: dict[str, "_GateState"] = gates if gates is not None else {}
        self._gate_events: list[Any] = []
        self._llm_factory = llm_factory
        self._memory = memory

    # --- internal helpers used by step() / human_gate() ---

    async def _run_step(self, agent_name: str, step_input: Any, *, step_key: str | None = None) -> Any:
        """Run an agent step, cache result, return output."""
        cache_key = step_key or agent_name
        if cache_key in self._checkpoint:
            return self._checkpoint[cache_key]

        if agent_name not in self._agents:
            raise KeyError(f"No agent named '{agent_name}' is registered with this workflow")

        from mosesaic.workflow._runner import run_agent_step
        result = await run_agent_step(
            self._agents[agent_name],
            step_input,
            timeout_seconds=self.step_timeout_seconds,
            llm_factory=self._llm_factory,
            memory=self._memory,
        )
        self._checkpoint[cache_key] = result
        return result


class _GateState:
    """State for a pending human_gate."""

    def __init__(self) -> None:
        import anyio
        self._event = anyio.Event()
        self.approved: bool | None = None

    def resolve(self, *, approved: bool) -> None:
        self.approved = approved
        self._event.set()

    async def wait(self, timeout_seconds: float) -> bool:
        import anyio
        with anyio.fail_after(timeout_seconds):
            await self._event.wait()
        return bool(self.approved)
