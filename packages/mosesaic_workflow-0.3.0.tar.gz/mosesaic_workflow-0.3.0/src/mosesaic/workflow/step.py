"""
Free functions: step() and parallel().

These must be called from inside a workflow function — they read the current
WorkflowContext from a ContextVar set by WorkflowRuntime before invocation.
"""

from __future__ import annotations
from typing import Any, Coroutine, TypeVar

import anyio

from mosesaic.workflow.context import _current_workflow_ctx

T = TypeVar("T")


async def step(agent_name: str, input: Any = None, *, key: str | None = None) -> Any:
    """
    Run a single agent step and return its output.

    Args:
        agent_name: Name of the registered agent to run.
        input:      Payload delivered to the agent as its first message.
        key:        Optional checkpoint key (defaults to agent_name).
                    Use an explicit key when the same agent is called
                    multiple times in one workflow.

    Returns:
        The payload of the last message the agent sent, or None.

    Raises:
        StepError:  If the agent raises an exception or times out.
        RuntimeError: If called outside a workflow context.
    """
    ctx = _current_workflow_ctx.get(None)
    if ctx is None:
        raise RuntimeError(
            "step() called outside of a workflow context. "
            "Use it only inside a @workflow-decorated function."
        )
    return await ctx._run_step(agent_name, input, step_key=key)


async def parallel(*coros: Coroutine[Any, Any, T]) -> tuple[Any, ...]:
    """
    Run multiple coroutines (typically step() calls) concurrently.

    Returns a tuple of their results in the same order they were provided.

    Example::

        draft, citations = await parallel(
            step("writer",           input=sources),
            step("citation-checker", input=sources),
        )

    Raises:
        StepError: If any step fails (first failure wins, others cancelled).
    """
    results: list[Any] = [None] * len(coros)

    async def _run(i: int, coro: Coroutine[Any, Any, Any]) -> None:
        results[i] = await coro

    async with anyio.create_task_group() as tg:
        for i, coro in enumerate(coros):
            tg.start_soon(_run, i, coro)

    return tuple(results)
