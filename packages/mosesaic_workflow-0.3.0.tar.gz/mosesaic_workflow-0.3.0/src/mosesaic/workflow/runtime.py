"""
WorkflowRuntime — runs workflows, manages agent registration, and resolves human gates.

Usage::

    runtime = WorkflowRuntime()
    runtime.register_agent(researcher)
    runtime.register_agent(writer)
    runtime.register_workflow(research_pipeline)

    result = await runtime.run("research-pipeline", input="quantum computing")
"""

from __future__ import annotations
from typing import Any

import anyio

from mosesaic.core.agent import AgentDefinition
from mosesaic.workflow.definition import WorkflowDefinition
from mosesaic.workflow.context import WorkflowContext, _current_workflow_ctx
from mosesaic.workflow.gate import HumanGateEvent
from mosesaic.workflow.result import WorkflowResult, WorkflowTimeout


class WorkflowRuntime:
    """
    Manages workflow and agent registrations and drives workflow execution.

    Agents registered here are available to step() calls within any workflow.
    Multiple workflows can be registered and run independently.
    """

    def __init__(
        self,
        llm: Any | None = None,
        tools: Any | None = None,
        tool_policy: Any | None = None,
        memory: Any | None = None,
        llm_overrides: dict[str, str] | None = None,
    ) -> None:
        self._agents: dict[str, AgentDefinition] = {}
        self._workflows: dict[str, WorkflowDefinition] = {}
        self._llm_registry = llm
        self._tool_registry = tools
        self._tool_policy = tool_policy
        self._memory = memory
        self._llm_overrides: dict[str, str] = llm_overrides or {}

    def _make_llm_factory(self):
        """Build a factory that creates an LLMContext per step-agent, if registry is set."""
        if self._llm_registry is None:
            return None
        registry = self._llm_registry
        overrides = self._llm_overrides

        def factory(agent_name: str, cost_tracker: Any, system_prompt: str | None = None) -> Any:
            from mosesaic.llm.context import LLMContext
            return LLMContext(
                registry=registry,
                cost_tracker=cost_tracker,
                agent_name=agent_name,
                system_prompt=system_prompt,
                preferred_model=overrides.get(agent_name),
            )

        return factory

    def register_agent(self, definition: AgentDefinition) -> "WorkflowRuntime":
        """Register an agent so it can be used as a step target."""
        if definition.name in self._agents:
            raise ValueError(f"Agent '{definition.name}' is already registered")
        self._agents[definition.name] = definition
        return self

    def register_workflow(self, definition: WorkflowDefinition) -> "WorkflowRuntime":
        """Register a workflow definition."""
        if definition.name in self._workflows:
            raise ValueError(f"Workflow '{definition.name}' is already registered")
        self._workflows[definition.name] = definition
        return self

    async def run(
        self,
        workflow_name: str,
        input: Any = None,
        *,
        timeout_seconds: float | None = None,
        step_timeout_seconds: float | None = None,
    ) -> WorkflowResult:
        """
        Run a registered workflow with the given input.

        Args:
            workflow_name:        Name of the workflow to run.
            input:                Payload passed to the workflow via ctx.input.
            timeout_seconds:      Override workflow-level timeout.
            step_timeout_seconds: Override per-step timeout.

        Returns:
            WorkflowResult with status "completed", "rejected", "failed", or "timed_out".
        """
        if workflow_name not in self._workflows:
            raise KeyError(f"No workflow named '{workflow_name}' is registered")

        wf = self._workflows[workflow_name]
        effective_timeout = timeout_seconds or wf.timeout_seconds
        effective_step_timeout = step_timeout_seconds or wf.step_timeout_seconds

        ctx = WorkflowContext(
            input=input,
            agents=self._agents,
            workflow_name=workflow_name,
            budget_usd=wf.budget_usd,
            step_timeout_seconds=effective_step_timeout,
            llm_factory=self._make_llm_factory(),
            memory=self._memory,
        )

        token = _current_workflow_ctx.set(ctx)
        try:
            if effective_timeout is not None:
                try:
                    with anyio.fail_after(effective_timeout):
                        result = await wf.fn(ctx)
                except TimeoutError:
                    raise WorkflowTimeout(workflow_name, effective_timeout)
            else:
                result = await wf.fn(ctx)

            # If the function returned a WorkflowResult, use it directly
            if isinstance(result, WorkflowResult):
                return result
            return WorkflowResult.completed(output=result)

        except WorkflowTimeout:
            return WorkflowResult.timed_out()
        except Exception as exc:
            return WorkflowResult.failed(error=str(exc))
        finally:
            _current_workflow_ctx.reset(token)

    def resolve_gate(self, gate_id: str, *, approved: bool) -> None:
        """
        Resolve a pending human_gate from outside the workflow.

        Call this when a human approves or rejects a gate. The gate_id
        is available in the HumanGateEvent emitted to the workflow context.

        Args:
            gate_id:  The gate UUID (as string) from HumanGateEvent.gate_id.
            approved: True to approve, False to reject.

        Raises:
            KeyError: If no gate with that ID is pending.
        """
        # Gates are stored per-context; we look across all active contexts.
        # In practice, this is called during an active run so the context
        # is in scope and passed directly from the gate event.
        raise NotImplementedError(
            "resolve_gate() requires a gate_id and an active WorkflowContext. "
            "Obtain the gate_id from a HumanGateEvent and call "
            "ctx._gates[gate_id].resolve(approved=approved) directly."
        )

    def resolve_gate_on_context(
        self, ctx: WorkflowContext, gate_id: str, *, approved: bool
    ) -> None:
        """Resolve a gate on a specific running context."""
        if gate_id not in ctx._gates:
            raise KeyError(f"No pending gate '{gate_id}' in context")
        ctx._gates[gate_id].resolve(approved=approved)

    @property
    def registered_agents(self) -> list[str]:
        return list(self._agents.keys())

    @property
    def registered_workflows(self) -> list[str]:
        return list(self._workflows.keys())
