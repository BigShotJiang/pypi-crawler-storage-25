"""
@workflow decorator — defines a WorkflowDefinition.

Usage::

    from mosesaic.workflow import workflow, WorkflowContext

    @workflow(name="research-pipeline", timeout_seconds=3600, budget_usd=2.00)
    async def research_pipeline(ctx: WorkflowContext) -> None:
        ...
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Coroutine


WorkflowFn = Callable[["WorkflowContext"], Coroutine[Any, Any, Any]]  # type: ignore[name-defined]


@dataclass(frozen=True)
class WorkflowDefinition:
    name: str
    fn: WorkflowFn
    timeout_seconds: float | None
    budget_usd: float | None
    checkpoint: bool
    step_timeout_seconds: float
    _is_workflow_definition: bool = True


def workflow(
    name: str,
    *,
    timeout_seconds: float | None = None,
    budget_usd: float | None = None,
    checkpoint: bool = False,
    step_timeout_seconds: float = 120.0,
) -> Callable[[WorkflowFn], WorkflowDefinition]:
    """
    Decorator that marks an async function as a Mosesaic workflow.

    Args:
        name:                 Unique workflow name.
        timeout_seconds:      Hard wall-clock timeout for the entire workflow.
        budget_usd:           Total LLM budget for the workflow run.
        checkpoint:           If True, step results are persisted so the
                              workflow can resume after a crash (future adapter).
        step_timeout_seconds: Per-step timeout passed to each agent.
    """
    def decorator(fn: WorkflowFn) -> WorkflowDefinition:
        return WorkflowDefinition(
            name=name,
            fn=fn,
            timeout_seconds=timeout_seconds,
            budget_usd=budget_usd,
            checkpoint=checkpoint,
            step_timeout_seconds=step_timeout_seconds,
        )

    return decorator


def is_workflow_definition(value: Any) -> bool:
    return (
        isinstance(value, WorkflowDefinition)
        and value._is_workflow_definition is True
    )
