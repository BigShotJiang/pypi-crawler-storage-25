"""
Internal: runs a single agent in an isolated mini-runtime and captures its output.

Design:
- Each step() spins up a fresh MessageBus + AgentLifecycle
- The agent receives the step input as its first message (from "__workflow__")
- Output is the payload of the last message sent BY the agent (from event log)
- If the agent sends nothing, step returns None
- Exceptions from the agent are re-raised as StepError
"""

from __future__ import annotations
from typing import Any, TYPE_CHECKING

import anyio

if TYPE_CHECKING:
    from mosesaic.core.agent import AgentDefinition


async def run_agent_step(
    definition: "AgentDefinition",
    step_input: Any,
    *,
    timeout_seconds: float = 120.0,
    llm_factory: Any | None = None,
    memory: Any | None = None,
) -> Any:
    from mosesaic.core.bus import MessageBus
    from mosesaic.core.cost import CostTracker
    from mosesaic.core.message import AgentMessage, MessageType
    from mosesaic.core.lifecycle import AgentLifecycle
    from mosesaic.core.context import AgentContext
    from mosesaic.workflow.result import StepError

    bus = MessageBus()
    bus.register(definition.name)

    # Deliver the step input before the agent starts
    input_msg = AgentMessage(
        from_agent="__workflow__",
        to_agent=definition.name,
        type=MessageType.TASK,
        payload=step_input,
    )
    await bus.send(input_msg)

    cost_tracker = CostTracker(agent_name=definition.name)
    lifecycle = AgentLifecycle()

    llm = (
        llm_factory(definition.name, cost_tracker, definition.system_prompt)
        if llm_factory is not None
        else None
    )

    from mosesaic.core.spawner import Spawner
    spawner = Spawner(
        llm_factory=llm_factory,
        memory=memory,
    )

    ctx = AgentContext(
        agent_name=definition.name,
        bus=bus,
        cost_tracker=cost_tracker,
        lifecycle=lifecycle,
        llm=llm,
        memory=memory,
        spawner=spawner,
    )

    from mosesaic.core.progress import emit_progress, ProgressEvent
    emit_progress(ProgressEvent(type="step_start", agent=definition.name))
    try:
        with anyio.fail_after(timeout_seconds):
            await definition.fn(ctx)
    except TimeoutError:
        emit_progress(ProgressEvent(type="step_done", agent=definition.name))
        raise StepError(definition.name, f"timed out after {timeout_seconds}s")
    except Exception as exc:
        emit_progress(ProgressEvent(type="step_done", agent=definition.name))
        raise StepError(definition.name, str(exc)) from exc
    emit_progress(ProgressEvent(type="step_done", agent=definition.name))

    # Capture output: last message sent BY the agent (excludes the input we delivered)
    sent_by_agent = [
        msg for msg in bus.event_log()
        if msg.from_agent == definition.name
    ]
    return sent_by_agent[-1].payload if sent_by_agent else None
