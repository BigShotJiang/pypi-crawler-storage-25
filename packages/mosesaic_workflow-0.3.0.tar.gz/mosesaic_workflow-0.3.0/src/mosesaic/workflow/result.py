"""Workflow outcome types and exceptions."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass(frozen=True)
class WorkflowResult:
    """Returned by a completed workflow run."""

    status: Literal["completed", "rejected", "failed", "timed_out"]
    output: Any = None
    error: str | None = None

    @classmethod
    def completed(cls, output: Any = None) -> "WorkflowResult":
        return cls(status="completed", output=output)

    @classmethod
    def rejected(cls) -> "WorkflowResult":
        return cls(status="rejected")

    @classmethod
    def failed(cls, error: str) -> "WorkflowResult":
        return cls(status="failed", error=error)

    @classmethod
    def timed_out(cls) -> "WorkflowResult":
        return cls(status="timed_out")


class StepError(RuntimeError):
    """Raised when an agent step fails or produces no output."""

    def __init__(self, agent_name: str, reason: str) -> None:
        super().__init__(f"Step '{agent_name}' failed: {reason}")
        self.agent_name = agent_name
        self.reason = reason


class VerificationFailed(RuntimeError):
    """Raised when all verification attempts are exhausted."""

    def __init__(self, max_attempts: int) -> None:
        super().__init__(
            f"Verification failed after {max_attempts} attempt(s)"
        )
        self.max_attempts = max_attempts


class HumanGateTimeout(RuntimeError):
    """Raised when a human_gate call exceeds its timeout."""

    def __init__(self, gate_id: str, timeout_seconds: float) -> None:
        super().__init__(
            f"Human gate '{gate_id}' timed out after {timeout_seconds}s"
        )
        self.gate_id = gate_id
        self.timeout_seconds = timeout_seconds


class WorkflowTimeout(RuntimeError):
    """Raised when a workflow run exceeds its total timeout."""

    def __init__(self, name: str, timeout_seconds: float) -> None:
        super().__init__(
            f"Workflow '{name}' timed out after {timeout_seconds}s"
        )
        self.name = name
        self.timeout_seconds = timeout_seconds
