"""Mosesaic Workflow DSL — step, parallel, verify, human_gate, @workflow."""

from mosesaic.workflow.result import (
    WorkflowResult,
    StepError,
    VerificationFailed,
    HumanGateTimeout,
    WorkflowTimeout,
)
from mosesaic.workflow.context import WorkflowContext
from mosesaic.workflow.step import step, parallel
from mosesaic.workflow.verify import verify, VerifyAttempt
from mosesaic.workflow.gate import human_gate, HumanGateEvent
from mosesaic.workflow.definition import workflow, WorkflowDefinition, is_workflow_definition
from mosesaic.workflow.runtime import WorkflowRuntime

__all__ = [
    # Result types
    "WorkflowResult",
    "StepError",
    "VerificationFailed",
    "HumanGateTimeout",
    "WorkflowTimeout",
    # Context
    "WorkflowContext",
    # DSL primitives
    "step",
    "parallel",
    "verify",
    "VerifyAttempt",
    "human_gate",
    "HumanGateEvent",
    # Definition
    "workflow",
    "WorkflowDefinition",
    "is_workflow_definition",
    # Runtime
    "WorkflowRuntime",
]
