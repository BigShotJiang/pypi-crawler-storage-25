"""Tests for WorkflowRuntime with LLM support."""
import pytest
from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry
from mosesaic.workflow import (
    step, workflow, WorkflowRuntime, WorkflowContext,
)


def _make_registry(response: str = "mock reply") -> tuple[ProviderRegistry, MockProvider]:
    provider = MockProvider(
        responses={"mock-cheap": response},
        capabilities={
            "mock-cheap": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
        },
        input_tokens=10,
        output_tokens=10,
    )
    registry = ProviderRegistry()
    registry.register(provider)
    return registry, provider


@pytest.mark.anyio
async def test_workflow_step_agent_gets_llm():
    registry, _ = _make_registry("hello from llm")

    @agent(name="llm-user")
    async def llm_user_agent(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        response = await ctx.llm.chat(messages=[{"role": "user", "content": "test"}])
        await ctx.send(msg.from_agent, response.content)

    @workflow(name="test-wf")
    async def wf(ctx: WorkflowContext):
        return await step("llm-user", input="go")

    runtime = WorkflowRuntime(llm=registry)
    runtime.register_agent(llm_user_agent)
    runtime.register_workflow(wf)

    result = await runtime.run("test-wf")
    assert result.status == "completed"
    assert result.output == "hello from llm"


@pytest.mark.anyio
async def test_workflow_step_agent_without_llm_raises():
    @agent(name="needs-llm")
    async def needs_llm_agent(ctx: AgentContext) -> None:
        await ctx.receive()
        await ctx.llm.chat(messages=[{"role": "user", "content": "test"}])

    @workflow(name="no-llm-wf")
    async def wf(ctx: WorkflowContext):
        return await step("needs-llm", input="go")

    runtime = WorkflowRuntime()  # no llm
    runtime.register_agent(needs_llm_agent)
    runtime.register_workflow(wf)

    result = await runtime.run("no-llm-wf")
    assert result.status == "failed"
    assert "LLM" in result.error


@pytest.mark.anyio
async def test_workflow_step_agent_system_prompt_prepended():
    registry, provider = _make_registry("ok")

    @agent(name="has-persona", system_prompt="You are a pirate.")
    async def has_persona_agent(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.llm.chat(messages=[{"role": "user", "content": "hello"}])
        await ctx.send(msg.from_agent, "done")

    @workflow(name="persona-wf")
    async def wf(ctx: WorkflowContext):
        return await step("has-persona", input="go")

    runtime = WorkflowRuntime(llm=registry)
    runtime.register_agent(has_persona_agent)
    runtime.register_workflow(wf)

    await runtime.run("persona-wf")
    assert provider.calls[0]["messages"][0].role == "system"
    assert provider.calls[0]["messages"][0].content == "You are a pirate."
