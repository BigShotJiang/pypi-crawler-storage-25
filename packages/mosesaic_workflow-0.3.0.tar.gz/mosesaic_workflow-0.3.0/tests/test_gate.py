"""Tests for human_gate()."""

import pytest
import anyio
from mosesaic.workflow import (
    human_gate, workflow, WorkflowRuntime, WorkflowResult, HumanGateTimeout
)
from mosesaic.workflow.context import _current_workflow_ctx


@pytest.mark.anyio
async def test_gate_approved():
    rt = WorkflowRuntime()
    captured_ctx = []

    @workflow(name="gate-approve")
    async def wf(ctx):
        # Capture ctx so the resolver can find the gate
        captured_ctx.append(ctx)
        approved = await human_gate("Please review", payload="draft text", timeout_hours=1)
        return "approved" if approved else "rejected"

    rt.register_workflow(wf)
    results: list[WorkflowResult] = []

    async def run_wf():
        results.append(await rt.run("gate-approve"))

    async def resolver():
        # Wait for the workflow to register the gate
        for _ in range(50):
            if captured_ctx and captured_ctx[0]._gate_events:
                break
            await anyio.sleep(0.01)
        ctx = captured_ctx[0]
        gate_event = ctx._gate_events[0]
        rt.resolve_gate_on_context(ctx, str(gate_event.gate_id), approved=True)

    async with anyio.create_task_group() as tg:
        tg.start_soon(run_wf)
        tg.start_soon(resolver)

    assert results[0].output == "approved"


@pytest.mark.anyio
async def test_gate_rejected():
    rt = WorkflowRuntime()
    captured_ctx = []

    @workflow(name="gate-reject")
    async def wf(ctx):
        captured_ctx.append(ctx)
        approved = await human_gate("Approve?", timeout_hours=1)
        return "approved" if approved else "rejected"

    rt.register_workflow(wf)
    results: list[WorkflowResult] = []

    async def run_wf():
        results.append(await rt.run("gate-reject"))

    async def resolver():
        for _ in range(50):
            if captured_ctx and captured_ctx[0]._gate_events:
                break
            await anyio.sleep(0.01)
        ctx = captured_ctx[0]
        gate_event = ctx._gate_events[0]
        rt.resolve_gate_on_context(ctx, str(gate_event.gate_id), approved=False)

    async with anyio.create_task_group() as tg:
        tg.start_soon(run_wf)
        tg.start_soon(resolver)

    assert results[0].output == "rejected"


@pytest.mark.anyio
async def test_gate_timeout():
    rt = WorkflowRuntime()

    @workflow(name="gate-timeout")
    async def wf(ctx):
        await human_gate("Review", timeout_hours=0.00001)  # ~0.036s

    rt.register_workflow(wf)
    result = await rt.run("gate-timeout")
    assert result.status == "failed"
    assert "timed out" in result.error.lower()


@pytest.mark.anyio
async def test_gate_event_metadata():
    rt = WorkflowRuntime()
    captured_ctx = []

    @workflow(name="gate-metadata")
    async def wf(ctx):
        captured_ctx.append(ctx)
        approved = await human_gate("Need review", payload={"key": "val"}, timeout_hours=1)
        return approved

    rt.register_workflow(wf)

    async def resolver():
        for _ in range(50):
            if captured_ctx and captured_ctx[0]._gate_events:
                break
            await anyio.sleep(0.01)
        ctx = captured_ctx[0]
        event = ctx._gate_events[0]
        assert event.message == "Need review"
        assert event.payload == {"key": "val"}
        assert event.workflow_name == "gate-metadata"
        rt.resolve_gate_on_context(ctx, str(event.gate_id), approved=True)

    async with anyio.create_task_group() as tg:
        tg.start_soon(lambda: rt.run("gate-metadata"))
        tg.start_soon(resolver)


def test_gate_invalid_id_raises():
    """resolve_gate_on_context raises KeyError for unknown gate_id."""
    from mosesaic.workflow.context import WorkflowContext, _GateState
    rt = WorkflowRuntime()

    # Create a bare context with no gates
    ctx = WorkflowContext(input=None, agents={})
    with pytest.raises(KeyError):
        rt.resolve_gate_on_context(ctx, "nonexistent-id", approved=True)


@pytest.mark.anyio
async def test_gate_outside_workflow_raises():
    with pytest.raises(RuntimeError, match="outside of a workflow context"):
        await human_gate("Approve?")
