"""Tests for verify() retry loop."""

import pytest
from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.workflow import (
    step, verify, workflow, WorkflowRuntime, VerificationFailed, VerifyAttempt
)


@pytest.fixture
def runtime():
    return WorkflowRuntime()


@pytest.mark.anyio
async def test_verify_succeeds_first_attempt(runtime):
    attempts = []

    @workflow(name="w1")
    async def wf(ctx):
        async for v in verify(max_attempts=5):
            attempts.append(v.attempt)
            break  # succeed immediately

    runtime.register_workflow(wf)
    result = await runtime.run("w1")
    assert result.status == "completed"
    assert attempts == [1]


@pytest.mark.anyio
async def test_verify_retries_and_succeeds(runtime):
    attempts = []

    @workflow(name="w2")
    async def wf(ctx):
        async for v in verify(max_attempts=5):
            attempts.append(v.attempt)
            if v.attempt >= 3:
                break  # succeed on attempt 3

    runtime.register_workflow(wf)
    result = await runtime.run("w2")
    assert result.status == "completed"
    assert attempts == [1, 2, 3]


@pytest.mark.anyio
async def test_verify_exhausted_raises(runtime):
    @workflow(name="w3")
    async def wf(ctx):
        async for v in verify(max_attempts=3):
            pass  # never break

    runtime.register_workflow(wf)
    result = await runtime.run("w3")
    assert result.status == "failed"
    assert "3" in result.error  # VerificationFailed mentions max_attempts


@pytest.mark.anyio
async def test_verify_attempt_metadata():
    """VerifyAttempt carries correct attempt/max_attempts/remaining."""
    collected: list[VerifyAttempt] = []

    async def run():
        async for v in verify(max_attempts=4):
            collected.append(v)
            if v.attempt == 2:
                break

    await run()
    assert collected[0].attempt == 1
    assert collected[0].max_attempts == 4
    assert collected[0].remaining == 4
    assert collected[1].attempt == 2
    assert collected[1].remaining == 3
    assert collected[1].is_last is False


@pytest.mark.anyio
async def test_verify_last_attempt_flag():
    collected: list[VerifyAttempt] = []

    async def run():
        try:
            async for v in verify(max_attempts=2):
                collected.append(v)
        except VerificationFailed:
            pass

    await run()
    assert collected[-1].is_last is True


@pytest.mark.anyio
async def test_verify_max_attempts_one_and_break():
    """max_attempts=1 succeeds if body breaks."""
    ran = False

    async def run():
        nonlocal ran
        async for _ in verify(max_attempts=1):
            ran = True
            break

    await run()
    assert ran


@pytest.mark.anyio
async def test_verify_max_attempts_one_no_break():
    """max_attempts=1 fails if body doesn't break."""
    with pytest.raises(VerificationFailed):
        async for _ in verify(max_attempts=1):
            pass  # no break


@pytest.mark.anyio
async def test_verify_invalid_max_attempts():
    with pytest.raises(ValueError, match="max_attempts"):
        async for _ in verify(max_attempts=0):
            pass
