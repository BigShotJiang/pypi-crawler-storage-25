"""Shared fixtures for mosesaic-workflow tests."""

import pytest
from mosesaic.core.agent import agent, AgentDefinition
from mosesaic.core.context import AgentContext


@pytest.fixture
def echo_agent() -> AgentDefinition:
    """Agent that receives a message and echoes its payload back."""
    @agent(name="echo")
    async def _echo(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.send("__workflow__", msg.payload)
    return _echo


@pytest.fixture
def upper_agent() -> AgentDefinition:
    """Agent that uppercases a string payload."""
    @agent(name="upper")
    async def _upper(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.send("__workflow__", str(msg.payload).upper())
    return _upper


@pytest.fixture
def failing_agent() -> AgentDefinition:
    """Agent that always raises."""
    @agent(name="failing")
    async def _failing(ctx: AgentContext) -> None:
        await ctx.receive()
        raise ValueError("intentional failure")
    return _failing


@pytest.fixture
def silent_agent() -> AgentDefinition:
    """Agent that receives but sends nothing."""
    @agent(name="silent")
    async def _silent(ctx: AgentContext) -> None:
        await ctx.receive()
        # intentionally sends nothing
    return _silent
