"""Tests for WorkflowRuntime."""

import pytest
from mosesaic.core.agent import agent
from mosesaic.core.context import AgentContext
from mosesaic.workflow import (
    step, workflow, WorkflowRuntime, WorkflowResult,
    is_workflow_definition,
)


@pytest.fixture
def echo_runtime(echo_agent):
    rt = WorkflowRuntime()
    rt.register_agent(echo_agent)
    return rt


@pytest.mark.anyio
async def test_run_returns_completed_result(echo_runtime):
    @workflow(name="simple")
    async def wf(ctx):
        return "done"

    echo_runtime.register_workflow(wf)
    result = await echo_runtime.run("simple", input="x")
    assert isinstance(result, WorkflowResult)
    assert result.status == "completed"
    assert result.output == "done"


@pytest.mark.anyio
async def test_run_with_explicit_workflow_result(echo_runtime):
    @workflow(name="explicit")
    async def wf(ctx):
        return WorkflowResult.rejected()

    echo_runtime.register_workflow(wf)
    result = await echo_runtime.run("explicit")
    assert result.status == "rejected"


@pytest.mark.anyio
async def test_run_ctx_input_available(echo_runtime):
    @workflow(name="input-test")
    async def wf(ctx):
        return ctx.input

    echo_runtime.register_workflow(wf)
    result = await echo_runtime.run("input-test", input={"key": 42})
    assert result.output == {"key": 42}


@pytest.mark.anyio
async def test_run_unknown_workflow_raises(echo_runtime):
    with pytest.raises(KeyError, match="ghost"):
        await echo_runtime.run("ghost")


@pytest.mark.anyio
async def test_run_catches_exception(echo_runtime):
    @workflow(name="boom")
    async def wf(ctx):
        raise ValueError("something broke")

    echo_runtime.register_workflow(wf)
    result = await echo_runtime.run("boom")
    assert result.status == "failed"
    assert "something broke" in result.error


@pytest.mark.anyio
async def test_run_timeout(echo_runtime):
    @workflow(name="slow")
    async def wf(ctx):
        import anyio
        await anyio.sleep(9999)

    echo_runtime.register_workflow(wf)
    result = await echo_runtime.run("slow", timeout_seconds=0.05)
    assert result.status == "timed_out"


@pytest.mark.anyio
async def test_workflow_timeout_from_definition():
    rt = WorkflowRuntime()

    @workflow(name="short", timeout_seconds=0.05)
    async def wf(ctx):
        import anyio
        await anyio.sleep(9999)

    rt.register_workflow(wf)
    result = await rt.run("short")
    assert result.status == "timed_out"


def test_duplicate_agent_registration(echo_agent):
    rt = WorkflowRuntime()
    rt.register_agent(echo_agent)
    with pytest.raises(ValueError, match="already registered"):
        rt.register_agent(echo_agent)


def test_duplicate_workflow_registration(echo_runtime):
    @workflow(name="dup")
    async def wf(ctx): pass

    echo_runtime.register_workflow(wf)
    with pytest.raises(ValueError, match="already registered"):
        echo_runtime.register_workflow(wf)


def test_registered_agents_and_workflows(echo_agent, upper_agent):
    rt = WorkflowRuntime()
    rt.register_agent(echo_agent)
    rt.register_agent(upper_agent)

    @workflow(name="one")
    async def wf1(ctx): pass

    @workflow(name="two")
    async def wf2(ctx): pass

    rt.register_workflow(wf1)
    rt.register_workflow(wf2)

    assert set(rt.registered_agents) == {"echo", "upper"}
    assert set(rt.registered_workflows) == {"one", "two"}


def test_is_workflow_definition():
    @workflow(name="x")
    async def wf(ctx): pass

    assert is_workflow_definition(wf)
    assert not is_workflow_definition("string")
    assert not is_workflow_definition({})
    assert not is_workflow_definition(None)


@pytest.mark.anyio
async def test_multi_step_workflow():
    rt = WorkflowRuntime()

    @agent(name="adder")
    async def adder(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.send("__workflow__", msg.payload + 10)

    @agent(name="doubler")
    async def doubler(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.send("__workflow__", msg.payload * 2)

    rt.register_agent(adder)
    rt.register_agent(doubler)

    @workflow(name="pipeline")
    async def pipeline(ctx):
        added = await step("adder", input=ctx.input)
        doubled = await step("doubler", input=added)
        return doubled

    rt.register_workflow(pipeline)
    result = await rt.run("pipeline", input=5)
    assert result.output == 30  # (5+10)*2
