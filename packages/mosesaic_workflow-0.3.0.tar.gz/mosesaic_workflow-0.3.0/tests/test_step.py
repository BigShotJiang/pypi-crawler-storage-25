"""Tests for step() and parallel()."""

import pytest
from mosesaic.core.agent import agent, AgentDefinition
from mosesaic.core.context import AgentContext
from mosesaic.workflow import step, parallel, workflow, WorkflowRuntime, StepError


@pytest.fixture
def runtime(echo_agent, upper_agent, failing_agent, silent_agent):
    rt = WorkflowRuntime()
    rt.register_agent(echo_agent)
    rt.register_agent(upper_agent)
    rt.register_agent(failing_agent)
    rt.register_agent(silent_agent)
    return rt


@pytest.mark.anyio
async def test_step_returns_agent_output(runtime):
    @workflow(name="w1")
    async def wf(ctx):
        return await step("echo", input="hello")

    runtime.register_workflow(wf)
    result = await runtime.run("w1", input=None)
    assert result.status == "completed"
    assert result.output == "hello"


@pytest.mark.anyio
async def test_step_transforms_payload(runtime):
    @workflow(name="w2")
    async def wf(ctx):
        return await step("upper", input="hello world")

    runtime.register_workflow(wf)
    result = await runtime.run("w2", input=None)
    assert result.output == "HELLO WORLD"


@pytest.mark.anyio
async def test_step_silent_agent_returns_none(runtime):
    @workflow(name="w3")
    async def wf(ctx):
        out = await step("silent", input="x")
        return out

    runtime.register_workflow(wf)
    result = await runtime.run("w3")
    assert result.status == "completed"
    assert result.output is None


@pytest.mark.anyio
async def test_step_failing_agent_fails_workflow(runtime):
    @workflow(name="w4")
    async def wf(ctx):
        await step("failing", input="x")

    runtime.register_workflow(wf)
    result = await runtime.run("w4")
    assert result.status == "failed"
    assert "intentional failure" in result.error


@pytest.mark.anyio
async def test_step_uses_ctx_input(runtime):
    @workflow(name="w5")
    async def wf(ctx):
        return await step("echo", input=ctx.input)

    runtime.register_workflow(wf)
    result = await runtime.run("w5", input="from-outside")
    assert result.output == "from-outside"


@pytest.mark.anyio
async def test_step_outside_workflow_raises():
    with pytest.raises(RuntimeError, match="outside of a workflow context"):
        await step("echo", input="x")


@pytest.mark.anyio
async def test_parallel_runs_steps_concurrently(runtime):
    @workflow(name="w6")
    async def wf(ctx):
        a, b = await parallel(
            step("echo", input="one"),
            step("upper", input="two"),
        )
        return {"a": a, "b": b}

    runtime.register_workflow(wf)
    result = await runtime.run("w6")
    assert result.output == {"a": "one", "b": "TWO"}


@pytest.mark.anyio
async def test_parallel_empty_tuple(runtime):
    @workflow(name="w7")
    async def wf(ctx):
        return await parallel()

    runtime.register_workflow(wf)
    result = await runtime.run("w7")
    assert result.output == ()


@pytest.mark.anyio
async def test_step_checkpoint_caches_result(runtime):
    call_count = 0

    @agent(name="counter")
    async def counter_agent(ctx: AgentContext) -> None:
        nonlocal call_count
        call_count += 1
        msg = await ctx.receive()
        await ctx.send("__workflow__", call_count)

    rt2 = WorkflowRuntime()
    rt2.register_agent(counter_agent)

    @workflow(name="w8")
    async def wf(ctx):
        a = await step("counter", input="x", key="my-step")
        b = await step("counter", input="x", key="my-step")  # same key → cached
        return (a, b)

    rt2.register_workflow(wf)
    result = await rt2.run("w8")
    assert result.output == (1, 1)   # second call was cached
    assert call_count == 1           # agent only ran once
