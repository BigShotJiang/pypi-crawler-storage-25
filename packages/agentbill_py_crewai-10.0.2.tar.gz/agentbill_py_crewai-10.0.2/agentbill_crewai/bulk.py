"""AgentBill CrewAI Bulk Operations - v10.1.0

Batch recording of signals for CrewAI workflows.
"""

import time
import uuid
import json
import urllib.request
import urllib.error
from typing import Optional, Dict, Any, List

from .signals import get_signal_config


GROUPING_KEYS = {"session_id", "workflow_id", "batch_id", "correlation_id"}


def record_bulk(
    records: List[Dict[str, Any]],
    *,
    customer_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Record multiple signals/events in a single batch request.
    
    Args:
        records: List of record dicts, each containing event_name (required)
        customer_id: Default customer ID for all records
        
    Returns:
        Dict with success status and results per record
    """
    config = get_signal_config()
    api_key = config.get("api_key")
    if not api_key:
        raise ValueError("AgentBill not initialized. Call set_signal_config() first.")
    
    if not records:
        return {"success": True, "processed": 0, "results": []}
    
    default_customer_id = customer_id or config.get("customer_id")
    base_url = config.get("base_url", "https://api.agentbill.io")
    url = f"{base_url}/functions/v1/otel-collector"
    debug = config.get("debug", False)
    
    spans = []
    results = []
    
    for i, record in enumerate(records):
        event_name = record.get("event_name")
        if not event_name:
            results.append({"index": i, "success": False, "error": "event_name is required"})
            continue
        
        trace_id = record.get("trace_id") or uuid.uuid4().hex
        span_id = record.get("span_id") or uuid.uuid4().hex[:16]
        now_ns = int(time.time() * 1_000_000_000)
        record_customer_id = record.get("customer_id", default_customer_id)
        
        attributes = [
            {"key": "agentbill.event_name", "value": {"stringValue": event_name}},
            {"key": "agentbill.is_business_event", "value": {"boolValue": True}},
            {"key": "agentbill.data_source", "value": {"stringValue": "crewai-sdk"}},
            {"key": "agentbill.bulk_index", "value": {"intValue": str(i)}},
        ]
        
        if record_customer_id:
            attributes.append({"key": "agentbill.customer_id", "value": {"stringValue": record_customer_id}})
        if config.get("agent_id"):
            attributes.append({"key": "agentbill.agent_id", "value": {"stringValue": config["agent_id"]}})
        
        if "revenue" in record:
            attributes.append({"key": "agentbill.revenue", "value": {"doubleValue": record["revenue"]}})
            attributes.append({"key": "agentbill.currency", "value": {"stringValue": record.get("currency", "USD")}})
        
        if record.get("metadata"):
            attributes.append({"key": "agentbill.metadata", "value": {"stringValue": json.dumps(record["metadata"])}})
        
        # Business context
        for field in ["product_id", "feature_flag", "environment", "deployment_version", "region", "tenant_id",
                       "error_type", "error_message", "category", "priority", "session_id", "order_id"]:
            if record.get(field):
                attributes.append({"key": f"agentbill.{field}", "value": {"stringValue": record[field]}})
        
        # Group by
        if record.get("group_by"):
            for k, v in record["group_by"].items():
                if k in GROUPING_KEYS:
                    attributes.append({"key": f"agentbill.{k}", "value": {"stringValue": v}})
        
        spans.append({
            "traceId": trace_id,
            "spanId": span_id,
            "parentSpanId": record.get("parent_span_id", ""),
            "name": "agentbill.trace.signal",
            "kind": 1,
            "startTimeUnixNano": str(now_ns),
            "endTimeUnixNano": str(now_ns),
            "attributes": attributes,
            "status": {"code": 1},
        })
        
        results.append({"index": i, "success": True, "trace_id": trace_id, "span_id": span_id})
    
    if not spans:
        return {"success": False, "processed": 0, "results": results, "error": "No valid records"}
    
    payload = {
        "resourceSpans": [{
            "resource": {
                "attributes": [
                    {"key": "service.name", "value": {"stringValue": "agentbill-crewai-sdk"}},
                    {"key": "agentbill.is_bulk", "value": {"boolValue": True}},
                ],
            },
            "scopeSpans": [{
                "scope": {"name": "agentbill.signals", "version": "10.1.0"},
                "spans": spans,
            }],
        }],
    }
    
    headers = {"x-api-key": api_key, "Content-Type": "application/json"}
    
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=30) as resp:
            is_success = resp.status == 200
        
        if debug:
            print(f"[AgentBill] {'✓' if is_success else '⚠️'} Bulk recorded {len(spans)} signals")
        
        return {"success": is_success, "processed": len(spans), "results": results}
    except Exception as e:
        if debug:
            print(f"[AgentBill] ⚠️ Bulk recording error: {e}")
        return {"success": False, "processed": 0, "results": results, "error": str(e)}
