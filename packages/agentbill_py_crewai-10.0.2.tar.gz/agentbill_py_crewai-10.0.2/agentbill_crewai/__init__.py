"""AgentBill CrewAI Integration

Zero-config crew tracking for CrewAI agents in AgentBill.
v10.1.0: Added record_bulk for batch signal operations
"""

from .tracker import track_crew
from .orders import OrdersResource
from .bulk import record_bulk

__version__ = "10.1.0"
__all__ = ["track_crew", "OrdersResource", "record_bulk"]
