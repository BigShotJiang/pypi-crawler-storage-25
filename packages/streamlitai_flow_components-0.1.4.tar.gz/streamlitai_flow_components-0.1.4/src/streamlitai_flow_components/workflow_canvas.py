"""WorkflowCanvas — the single Streamlit custom component for the visual canvas."""

import os
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import streamlit.components.v1 as components

from streamlitai_flow_components.models import Edge, WorkflowNode

_BUILD_DIR = Path(__file__).parent / "frontend" / "build"
_DEV_MODE = os.getenv("STREAMLIT_COMPONENT_DEV", "false").lower() == "true"

if _DEV_MODE:
    _component_func = components.declare_component(
        "workflow_canvas",
        url="http://localhost:3001",
    )
else:
    if not (_BUILD_DIR / "index.html").is_file():
        raise RuntimeError(
            "Packaged frontend assets were not found at "
            f"{_BUILD_DIR}. Run `cd frontend && pnpm build` before building/"
            "publishing this package, or set STREAMLIT_COMPONENT_DEV=true "
            "for local development with `pnpm dev`."
        )
    _component_func = components.declare_component(
        "workflow_canvas",
        path=str(_BUILD_DIR),
    )


def workflow_canvas(
    nodes: Sequence[WorkflowNode],
    edges: Sequence[Edge] | None = None,
    height: int = 600,
    editable: bool = False,  # noqa: FBT001, FBT002
    agent_options: Sequence[dict[str, Any]] | None = None,
    team_options: Sequence[dict[str, Any]] | None = None,
    key: str | None = None,
) -> dict[str, Any] | None:
    """Render an interactive workflow canvas with drag-and-connect nodes.

    Parameters
    ----------
    nodes:
        Sequence of workflow node objects (e.g. ``AgentNode``).
        Each must implement ``to_dict()`` returning a React Flow node dict.
    edges:
        Optional sequence of ``Edge`` objects defining connections between nodes.
    height:
        Canvas height in pixels.
    editable:
        When ``True``, a dock appears at the bottom of the canvas allowing
        users to add new nodes, and each node gets a delete button on hover.
    agent_options:
        Selectable agent profiles shown in a dropdown on Agent cards when
        ``editable`` is ``True``.  Each dict should contain at least
        ``"name"`` and ``"model_name"``; ``"metadata"`` is optional.
    team_options:
        Selectable team profiles shown in a dropdown on Team cards when
        ``editable`` is ``True``.  Each dict should contain at least
        ``"name"``; ``"mode"``, ``"agents"``, and ``"metadata"`` are optional.
    key:
        Optional Streamlit widget key for stable identity across reruns.

    Returns
    -------
    dict or None
        ``{"nodes": [...], "edges": [...]}`` with updated positions/connections
        after user interaction, or ``None`` before first interaction.

    """
    serialized_nodes = [n.to_dict() for n in nodes]
    serialized_edges = [e.to_dict() for e in (edges or [])]
    result: dict[str, Any] | None = _component_func(
        nodes=serialized_nodes,
        edges=serialized_edges,
        height=height,
        editable=editable,
        agent_options=list(agent_options) if agent_options else [],
        team_options=list(team_options) if team_options else [],
        key=key,
        default=None,
    )
    return result
