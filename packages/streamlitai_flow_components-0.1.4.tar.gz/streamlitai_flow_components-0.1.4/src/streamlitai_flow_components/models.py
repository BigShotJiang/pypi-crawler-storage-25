"""Shared types for workflow nodes and edges."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class WorkflowNode(Protocol):
    """Protocol for any node that can live on the workflow canvas."""

    id: str  # noqa: A003
    position: tuple[float, float]

    def to_dict(self) -> dict[str, Any]: ...


@dataclass(frozen=True)
class Edge:
    """A directed connection between two workflow nodes."""

    source: str
    target: str
    id: str | None = None  # noqa: A003
    source_handle: str | None = None
    target_handle: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialise to the React Flow edge format."""
        d: dict[str, Any] = {
            "id": self.id or f"{self.source}-{self.target}",
            "source": self.source,
            "target": self.target,
        }
        if self.source_handle is not None:
            d["sourceHandle"] = self.source_handle
        if self.target_handle is not None:
            d["targetHandle"] = self.target_handle
        return d
