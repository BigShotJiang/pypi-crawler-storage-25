"""RouterNode dataclass — an N-way routing hub for branching logic."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Route:
    """A single named route with an optional condition."""

    name: str
    condition: str | None = None


@dataclass(frozen=True)
class RouterNode:
    """A router node that directs flow to one or more named routes."""

    id: str  # noqa: A003
    name: str
    routes: tuple[Route, ...] = ()
    position: tuple[float, float] = (0, 0)
    metadata: dict[str, object] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialise to React Flow node format."""
        return {
            "id": self.id,
            "type": "router",
            "position": {"x": self.position[0], "y": self.position[1]},
            "data": {
                "name": self.name,
                "routes": [
                    {"name": r.name, "condition": r.condition} for r in self.routes
                ],
                "metadata": self.metadata,
            },
        }
