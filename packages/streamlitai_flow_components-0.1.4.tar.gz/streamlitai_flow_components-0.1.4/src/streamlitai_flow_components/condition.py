"""ConditionNode dataclass — a binary decision gate (true / false)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ConditionNode:
    """A condition node that gates workflow execution based on criteria."""

    id: str  # noqa: A003
    name: str
    condition: str
    position: tuple[float, float] = (0, 0)
    metadata: dict[str, object] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialise to React Flow node format."""
        return {
            "id": self.id,
            "type": "condition",
            "position": {"x": self.position[0], "y": self.position[1]},
            "data": {
                "name": self.name,
                "condition": self.condition,
                "metadata": self.metadata,
            },
        }
