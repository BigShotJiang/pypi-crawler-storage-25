"""TeamNode dataclass — data model for a team of agents on the workflow canvas."""

from dataclasses import dataclass
from typing import Any

from streamlitai_flow_components.agent import AgentNode


@dataclass(frozen=True)
class TeamNode:
    """A team node containing multiple agents, placed on the workflow canvas.

    Parameters
    ----------
    id:
        Unique identifier for the team.
    name:
        Display name shown as the card title.
    agents:
        Tuple of AgentNode instances belonging to this team.
    mode:
        Coordination mode label (e.g. "Coordinate", "Delegate"). Shown as a badge.
    position:
        (x, y) coordinates on the canvas.
    metadata:
        Optional key-value pairs rendered below the card header.

    """

    id: str  # noqa: A003
    name: str
    agents: tuple[AgentNode, ...] = ()
    mode: str | None = "Coordinate"
    position: tuple[float, float] = (0, 0)
    metadata: dict[str, object] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialise to React Flow node format."""
        return {
            "id": self.id,
            "type": "team",
            "position": {"x": self.position[0], "y": self.position[1]},
            "data": {
                "name": self.name,
                "mode": self.mode,
                "agents": [{"name": a.name, "model_name": a.model_name} for a in self.agents],
                "metadata": self.metadata,
            },
        }
