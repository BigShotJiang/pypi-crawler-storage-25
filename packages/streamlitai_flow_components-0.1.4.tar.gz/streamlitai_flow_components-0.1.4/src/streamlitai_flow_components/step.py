"""StepNode dataclass — a container node that wraps an executor (Agent or Team)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from streamlitai_flow_components.agent import AgentNode
from streamlitai_flow_components.team import TeamNode


@dataclass(frozen=True)
class StepNode:
    """A step node that wraps exactly one executor (agent or team) on the canvas.

    Parameters
    ----------
    id:
        Unique identifier for the step.
    name:
        Display name shown as the card title.
    description:
        Optional description shown below the step name.
    executor:
        The agent or team executing this step, or None for an empty drop zone.
    position:
        (x, y) coordinates on the canvas.
    metadata:
        Optional key-value pairs rendered below the card header.

    """

    id: str  # noqa: A003
    name: str
    description: str | None = None
    executor: AgentNode | TeamNode | None = None
    position: tuple[float, float] = (0, 0)
    metadata: dict[str, object] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialise to React Flow node format."""
        executor_data: dict[str, Any] | None = None
        if isinstance(self.executor, AgentNode):
            executor_data = {
                "type": "agent",
                "id": self.executor.id,
                "name": self.executor.name,
                "model_name": self.executor.model_name,
                "metadata": self.executor.metadata,
            }
        elif isinstance(self.executor, TeamNode):
            executor_data = {
                "type": "team",
                "id": self.executor.id,
                "name": self.executor.name,
                "mode": self.executor.mode,
                "agents": [
                    {"name": a.name, "model_name": a.model_name}
                    for a in self.executor.agents
                ],
                "metadata": self.executor.metadata,
            }

        return {
            "id": self.id,
            "type": "step",
            "position": {"x": self.position[0], "y": self.position[1]},
            "data": {
                "name": self.name,
                "description": self.description,
                "executor": executor_data,
                "metadata": self.metadata,
            },
        }
