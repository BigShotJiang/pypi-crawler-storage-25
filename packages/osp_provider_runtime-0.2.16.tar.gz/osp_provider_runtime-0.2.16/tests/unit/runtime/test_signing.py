from __future__ import annotations

import base64
import hashlib
import hmac
import uuid
from typing import Any

import pytest

from osp_provider_runtime.config import RuntimeConfig
from osp_provider_runtime.signing import (
    HDR_SIG_ALG,
    HDR_SIG_KID,
    HDR_SIG_NONCE,
    HDR_SIG_TS,
    HDR_SIG_VALUE,
    HDR_SIG_VERSION,
    build_update_signature_headers,
    get_signing_secret_bytes,
)


def _base_config(**kwargs: Any) -> RuntimeConfig:
    return RuntimeConfig(
        rabbitmq_url="amqp://guest:guest@localhost:5672/",
        request_queue="provider.demo",
        request_exchange="osp.from_orch",
        request_binding="demo.#",
        updates_exchange="osp.to_orch",
        updates_routing_key="demo",
        **kwargs,
    )


def test_get_signing_secret_bytes_from_utf8_text() -> None:
    config = _base_config(updates_signing_secret="super-secret")
    assert get_signing_secret_bytes(config) == b"super-secret"


def test_get_signing_secret_bytes_from_base64() -> None:
    config = _base_config(updates_signing_secret_b64=base64.b64encode(b"abc123").decode("ascii"))
    assert get_signing_secret_bytes(config) == b"abc123"


def test_get_signing_secret_bytes_rejects_ambiguous_secret_config() -> None:
    config = _base_config(
        updates_signing_secret="plain",
        updates_signing_secret_b64=base64.b64encode(b"binary").decode("ascii"),
    )
    with pytest.raises(ValueError, match="set only one"):
        get_signing_secret_bytes(config)


def test_get_signing_secret_bytes_rejects_invalid_base64() -> None:
    config = _base_config(updates_signing_secret_b64="not base64???")
    with pytest.raises(ValueError, match="not valid base64"):
        get_signing_secret_bytes(config)


def test_build_update_signature_headers_uses_stable_canonical_shape(monkeypatch: Any) -> None:
    config = _base_config(
        updates_signing_enabled=True,
        updates_signing_kid="demo/current",
        updates_signing_secret="top-secret",
    )
    monkeypatch.setattr("osp_provider_runtime.signing.time.time", lambda: 1_700_000_000)
    monkeypatch.setattr(
        "osp_provider_runtime.signing.uuid.uuid4",
        lambda: uuid.UUID("12345678-1234-5678-1234-567812345678"),
    )

    body = b'{"status":"ok"}'
    headers = build_update_signature_headers(
        config=config,
        exchange="osp.to_orch",
        routing_key="demo.event.v1",
        content_type="application/json",
        body=body,
    )

    assert headers[HDR_SIG_VERSION] == "1"
    assert headers[HDR_SIG_ALG] == "hmac-sha256"
    assert headers[HDR_SIG_KID] == "demo/current"
    assert headers[HDR_SIG_TS] == "1700000000"
    assert headers[HDR_SIG_NONCE] == "12345678123456781234567812345678"

    canonical = "\n".join(
        [
            "v1",
            "kid=demo/current",
            "ts=1700000000",
            "nonce=12345678123456781234567812345678",
            "exchange=osp.to_orch",
            "routing_key=demo.event.v1",
            "content_type=application/json",
            f"body_sha256={hashlib.sha256(body).hexdigest()}",
        ]
    ).encode("utf-8")
    digest = hmac.new(b"top-secret", canonical, hashlib.sha256).digest()
    expected_sig = base64.b64encode(digest).decode("ascii")
    assert headers[HDR_SIG_VALUE] == expected_sig
