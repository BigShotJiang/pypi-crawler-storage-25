"""HMAC signing helpers for provider -> orchestrator update messages.

Why HMAC here (explicit, intentional):
    - We need a boring, low-churn authenticity check for provider updates.
    - HMAC-SHA256 keeps implementation and operations simple (no PKI rollout).
    - In this threat model, host compromise is already game over; this protects
      primarily against message spoofing from bus-level credentials misuse.

Signing contract:
    - Sign raw message bytes (via SHA-256 digest), not parsed JSON.
    - Include exchange/routing/content-type + timestamp + nonce in input.
    - Emit versioned headers so verifier can evolve safely.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import time
import uuid

from .config import RuntimeConfig

SIG_VERSION = "1"
SIG_ALG = "hmac-sha256"

HDR_SIG_VERSION = "x-osp-sig-v"
HDR_SIG_ALG = "x-osp-sig-alg"
HDR_SIG_KID = "x-osp-sig-kid"
HDR_SIG_TS = "x-osp-sig-ts"
HDR_SIG_NONCE = "x-osp-sig-nonce"
HDR_SIG_VALUE = "x-osp-sig"


def _canonical_signing_input(
    *,
    kid: str,
    ts: str,
    nonce: str,
    exchange: str,
    routing_key: str,
    content_type: str,
    body: bytes,
) -> bytes:
    body_sha256 = hashlib.sha256(body).hexdigest()
    lines = [
        f"v{SIG_VERSION}",
        f"kid={kid}",
        f"ts={ts}",
        f"nonce={nonce}",
        f"exchange={exchange}",
        f"routing_key={routing_key}",
        f"content_type={content_type}",
        f"body_sha256={body_sha256}",
    ]
    return "\n".join(lines).encode("utf-8")


def get_signing_secret_bytes(config: RuntimeConfig) -> bytes:
    """Resolve configured signing secret bytes or raise ValueError."""
    has_b64 = bool(config.updates_signing_secret_b64)
    has_text = bool(config.updates_signing_secret)
    if has_b64 and has_text:
        raise ValueError("set only one of updates_signing_secret and updates_signing_secret_b64")
    if has_b64:
        secret_b64 = str(config.updates_signing_secret_b64 or "")
        try:
            secret = base64.b64decode(secret_b64, validate=True)
        except Exception as exc:  # noqa: BLE001
            raise ValueError("updates_signing_secret_b64 is not valid base64") from exc
        if not secret:
            raise ValueError("updates_signing_secret_b64 must not decode to empty bytes")
        return secret
    if has_text:
        secret_text = str(config.updates_signing_secret or "")
        secret = secret_text.encode("utf-8")
        if not secret:
            raise ValueError("updates_signing_secret must not be empty")
        return secret
    raise ValueError("updates signing enabled but no secret configured")


def build_update_signature_headers(
    *,
    config: RuntimeConfig,
    exchange: str,
    routing_key: str,
    content_type: str,
    body: bytes,
) -> dict[str, str]:
    """Build signature headers for a provider update publish."""
    kid = str(config.updates_signing_kid or "").strip()
    if not kid:
        raise ValueError("updates signing enabled but updates_signing_kid is empty")
    secret = get_signing_secret_bytes(config)
    ts = str(int(time.time()))
    nonce = uuid.uuid4().hex
    canonical = _canonical_signing_input(
        kid=kid,
        ts=ts,
        nonce=nonce,
        exchange=exchange,
        routing_key=routing_key,
        content_type=content_type,
        body=body,
    )
    signature = hmac.new(secret, canonical, hashlib.sha256).digest()
    sig_b64 = base64.b64encode(signature).decode("ascii")
    return {
        HDR_SIG_VERSION: SIG_VERSION,
        HDR_SIG_ALG: SIG_ALG,
        HDR_SIG_KID: kid,
        HDR_SIG_TS: ts,
        HDR_SIG_NONCE: nonce,
        HDR_SIG_VALUE: sig_b64,
    }
