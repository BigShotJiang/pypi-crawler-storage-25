#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

# Avoid desktop keyring prompts/locks; prefer ~/.pypirc or explicit env vars.
export PYTHON_KEYRING_BACKEND=keyring.backends.null.Keyring

VERSION="$(
python - <<'PY'
from pathlib import Path
import tomllib

data = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
print(data["project"]["version"])
PY
)"

DIST_DIR="${ROOT_DIR}/dist"
WHL_FILE="${DIST_DIR}/osp_provider_runtime-${VERSION}-py3-none-any.whl"
SDIST_FILE="${DIST_DIR}/osp_provider_runtime-${VERSION}.tar.gz"

echo "Publishing osp-provider-runtime version ${VERSION}"
rm -rf "${DIST_DIR}"
python -m build

ARTIFACTS=(
  "${WHL_FILE}"
  "${SDIST_FILE}"
)

for artifact in "${ARTIFACTS[@]}"; do
  if [[ ! -f "${artifact}" ]]; then
    echo "Missing expected artifact: ${artifact}" >&2
    exit 1
  fi
done

UNEXPECTED_COUNT="$(find "${DIST_DIR}" -maxdepth 1 -type f | wc -l | tr -d ' ')"
if [[ "${UNEXPECTED_COUNT}" -ne 2 ]]; then
  echo "Unexpected files in ${DIST_DIR}. Refusing to publish." >&2
  find "${DIST_DIR}" -maxdepth 1 -type f -print >&2
  exit 1
fi

twine check "${ARTIFACTS[@]}"
twine upload "$@" "${ARTIFACTS[@]}"

rm -rf "${DIST_DIR}"
echo "Publish complete. Removed ${DIST_DIR}."
