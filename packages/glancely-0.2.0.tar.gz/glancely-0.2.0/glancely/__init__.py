"""glancely: all-in-one personal tracker as one openclaw skill bundle."""

__version__ = "0.2.0"

__all__ = ["__version__"]
