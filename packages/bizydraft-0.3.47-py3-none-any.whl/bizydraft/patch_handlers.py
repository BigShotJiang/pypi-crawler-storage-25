import asyncio
import math
import mimetypes
import os
import tempfile
import uuid
from io import BytesIO
from urllib.parse import unquote

import aiohttp
from aiohttp import ClientSession, ClientTimeout, web
from loguru import logger
from PIL import Image, ImageOps

try:
    import execution
    import folder_paths
    from server import PromptServer

    comfy_server = PromptServer.instance
except ImportError:
    logger.error(
        "failed to import ComfyUI modules, ensure PYTHONPATH is set correctly. (export PYTHONPATH=$PYTHONPATH:/path/to/ComfyUI)"
    )
    exit(1)

# 100MB
BIZYDRAFT_MAX_FILE_SIZE = int(os.getenv("BIZYDRAFT_MAX_FILE_SIZE", 100 * 1024 * 1024))
# 图片限制 10MB 大小
BIZYDRAFT_MAX_IMAGE_FILE_SIZE = int(
    os.getenv("BIZYDRAFT_MAX_IMAGE_FILE_SIZE", 10 * 1024 * 1024)
)
# 20分钟
BIZYDRAFT_REQUEST_TIMEOUT = int(os.getenv("BIZYDRAFT_REQUEST_TIMEOUT", 20 * 60))
BIZYDRAFT_CHUNK_SIZE = int(os.getenv("BIZYDRAFT_CHUNK_SIZE", 1024 * 16))  # 16KB

# HTTP客户端连接池配置（参考 server.py）
HTTP_CLIENT_TOTAL_TIMEOUT = int(os.getenv("HTTP_CLIENT_TOTAL_TIMEOUT", 300))
HTTP_CLIENT_CONNECT_TIMEOUT = int(os.getenv("HTTP_CLIENT_CONNECT_TIMEOUT", 50))
HTTP_CLIENT_LIMIT = int(os.getenv("HTTP_CLIENT_LIMIT", 100))
HTTP_CLIENT_LIMIT_PER_HOST = int(os.getenv("HTTP_CLIENT_LIMIT_PER_HOST", 50))
HTTP_CLIENT_DNS_TTL = int(os.getenv("HTTP_CLIENT_DNS_TTL", 300))
HTTP_CLIENT_KEEPALIVE_TIMEOUT = int(os.getenv("HTTP_CLIENT_KEEPALIVE_TIMEOUT", 30))

HTTP_PREFIX_OPTIONS = ("http:", "https:")

# 复用的客户端会话（模块级别）
_client_session = None


def _get_client_session():
    """获取或创建复用的客户端会话

    参考 server.py 中的实现，复用 ClientSession 以提高性能
    避免每次请求都创建新的 session，减少连接开销
    """
    global _client_session
    if _client_session is None or _client_session.closed:
        # 配置连接超时和连接池限制
        timeout = ClientTimeout(
            total=HTTP_CLIENT_TOTAL_TIMEOUT,
            connect=HTTP_CLIENT_CONNECT_TIMEOUT,
        )
        connector = aiohttp.TCPConnector(
            limit=HTTP_CLIENT_LIMIT,
            limit_per_host=HTTP_CLIENT_LIMIT_PER_HOST,
            ttl_dns_cache=HTTP_CLIENT_DNS_TTL,
            use_dns_cache=True,
            keepalive_timeout=HTTP_CLIENT_KEEPALIVE_TIMEOUT,
        )
        _client_session = ClientSession(timeout=timeout, connector=connector)
    return _client_session


# 规范化subfolder URL
def normalize_url(url: str) -> str:
    if not url:
        return url

    # 提取URL部分（如果包含http）
    if "http" in url:
        url = url[url.find("http") :]

    # URL解码
    url = unquote(url)

    # 修复协议格式：https:/ 或 http:/ -> https:// 或 http://
    if url.startswith("https:/") and not url.startswith("https://"):
        url = "https://" + url[7:]  # 跳过 "https:/"
    elif url.startswith("http:/") and not url.startswith("http://"):
        url = "http://" + url[6:]  # 跳过 "http:/"

    return url


async def download_async_stream_to_temp_file(async_stream, max_size):
    """从异步流式数据下载到临时文件

    Args:
        async_stream: 异步迭代器，产生数据块
        max_size: 最大文件大小（字节）

    Returns:
        str: 临时文件路径

    Raises:
        ValueError: 文件大小超过限制
    """
    temp_fd, temp_path = tempfile.mkstemp(suffix=".tmp")
    try:
        total_bytes = 0
        with os.fdopen(temp_fd, "wb") as temp_file:
            async for chunk in async_stream:
                total_bytes += len(chunk)
                if total_bytes > max_size:
                    os.unlink(temp_path)
                    raise ValueError(
                        f"File size exceeds limit ({human_readable_size(max_size)})"
                    )
                temp_file.write(chunk)
        return temp_path
    except Exception:
        if os.path.exists(temp_path):
            try:
                os.unlink(temp_path)
            except Exception:
                pass
        raise


def process_image_from_file(temp_path, channel, preview, original_filename):
    """从临时文件处理图片

    Args:
        temp_path (str): 临时文件路径
        channel (str): 图像通道处理模式
            - "rgb": 转换为RGB格式，移除alpha通道
            - "a": 提取alpha通道，创建透明度图像
        preview (str, optional): 预览参数，格式为 "format;quality"
            - format: 目标格式 (webp, jpeg)
            - quality: 压缩质量，默认为90
        original_filename (str): 原始文件名

    Returns:
        tuple: (body_bytes, content_type, original_filename)
    """
    try:
        # PIL 使用 memory-mapped I/O，内存占用更少
        with Image.open(temp_path) as img:
            # 处理 preview 参数
            if preview is not None:
                preview_info = preview.split(";")
                image_format = preview_info[0]
                if image_format not in ["webp", "jpeg"] or "a" in channel:
                    image_format = "webp"

                quality = 90
                if preview_info[-1].isdigit():
                    quality = max(1, min(int(preview_info[-1]), 100))  # 限制范围 1-100

                buffer = BytesIO()
                if image_format in ["jpeg"] or channel == "rgb":
                    img = img.convert("RGB")
                img.save(buffer, format=image_format, quality=quality)
                buffer.seek(0)

                return (buffer.read(), f"image/{image_format}", original_filename)

            # 处理 channel 参数
            if channel == "rgb":
                logger.debug("Converting image to RGB (removing alpha)")
                if img.mode == "RGBA":
                    r, g, b, a = img.split()
                    new_img = Image.merge("RGB", (r, g, b))
                else:
                    new_img = img.convert("RGB")

                buffer = BytesIO()
                new_img.save(buffer, format="PNG")
                buffer.seek(0)

                return (buffer.read(), "image/png", original_filename)

            elif channel == "a":
                logger.debug("Extracting alpha channel only")
                if img.mode == "RGBA":
                    _, _, _, a = img.split()
                else:
                    a = Image.new("L", img.size, 255)

                alpha_img = Image.new("RGBA", img.size)
                alpha_img.putalpha(a)
                alpha_buffer = BytesIO()
                alpha_img.save(alpha_buffer, format="PNG")
                alpha_buffer.seek(0)

                return (alpha_buffer.read(), "image/png", original_filename)

    except Exception as e:
        logger.error(f"图像处理失败: {str(e)}", exc_info=True)
        raise


async def view_image(request):

    logger.debug(f"Received request for /view with query: {request.rel_url.query}")
    if "filename" not in request.rel_url.query:
        logger.warning("'filename' not provided in query string, returning 404")
        return web.Response(status=404, text="'filename' not provided in query string")

    filename = request.rel_url.query["filename"]
    subfolder = request.rel_url.query.get("subfolder", "")
    channel = request.rel_url.query.get("channel", "rgba")
    preview = request.rel_url.query.get("preview", None)
    if not filename.startswith(HTTP_PREFIX_OPTIONS) and "http" not in subfolder:
        logger.warning(
            f"Invalid OSS URL format: {filename=}, {subfolder=} only URLs are supported"
        )
        return web.Response(
            status=400, text="Invalid filename format(only url supported)"
        )

    try:
        subfolder = normalize_url(subfolder)

        # 构建完整URL
        full_url = (
            f"{subfolder}/{filename}"
            if not filename.startswith(HTTP_PREFIX_OPTIONS)
            else filename
        )

        # 获取原始文件名用于响应头
        original_filename = filename.split("/")[-1] if "/" in filename else filename

        content_type, _ = mimetypes.guess_type(full_url)

        # 使用复用的客户端会话
        session = _get_client_session()
        async with session.get(full_url) as resp:
            resp.raise_for_status()

            # 优先使用服务器返回的Content-Type，如果无法获取则使用猜测的类型
            final_content_type = (
                resp.headers.get("Content-Type")
                or content_type
                or "application/octet-stream"
            )

            content_length = int(resp.headers.get("Content-Length", 0))
            if content_length > BIZYDRAFT_MAX_FILE_SIZE:
                logger.warning(
                    f"File size {human_readable_size(content_length)} exceeds limit {human_readable_size(BIZYDRAFT_MAX_FILE_SIZE)}"
                )
                return web.Response(
                    status=413,
                    text=f"File size exceeds limit ({human_readable_size(BIZYDRAFT_MAX_FILE_SIZE)})",
                )

            # 检查是否需要图像处理（preview或channel参数）
            is_image = final_content_type and final_content_type.startswith("image/")
            needs_processing = is_image and (preview is not None or channel != "rgba")

            if needs_processing:
                logger.debug(f"Image processing requested: {channel=}, {preview=}")

                temp_path = None
                try:
                    # 使用通用函数下载到临时文件
                    temp_path = await download_async_stream_to_temp_file(
                        resp.content.iter_chunked(BIZYDRAFT_CHUNK_SIZE),
                        BIZYDRAFT_MAX_IMAGE_FILE_SIZE,
                    )

                    # 从临时文件处理图片
                    loop = asyncio.get_running_loop()
                    body_bytes, content_type, filename = await loop.run_in_executor(
                        None,
                        process_image_from_file,
                        temp_path,
                        channel,
                        preview,
                        original_filename,
                    )

                    return web.Response(
                        body=body_bytes,
                        content_type=content_type,
                        headers={"Content-Disposition": f'filename="{filename}"'},
                    )

                except ValueError as e:
                    # 文件大小超限
                    return web.Response(status=413, text=str(e))
                except Exception as e:
                    logger.error(f"图像处理失败: {str(e)}", exc_info=True)
                    return web.Response(
                        status=500,
                        text=f"Image processing failed: {str(e)}",
                    )
                finally:
                    # 清理临时文件
                    if temp_path and os.path.exists(temp_path):
                        try:
                            os.unlink(temp_path)
                        except Exception as cleanup_error:
                            logger.warning(
                                f"Failed to cleanup temp file {temp_path}: {cleanup_error}"
                            )

            # 默认流式传输（无需处理或非图像文件）
            headers = {
                "Content-Disposition": f'attachment; filename="{original_filename}"',
                "Content-Type": final_content_type,
            }

            proxy_response = web.StreamResponse(headers=headers)
            await proxy_response.prepare(request)

            total_bytes = 0
            async for chunk in resp.content.iter_chunked(BIZYDRAFT_CHUNK_SIZE):
                total_bytes += len(chunk)
                if total_bytes > BIZYDRAFT_MAX_FILE_SIZE:
                    await proxy_response.write(b"")
                    return web.Response(
                        status=413,
                        text=f"File size exceeds limit during streaming ({human_readable_size(BIZYDRAFT_MAX_FILE_SIZE)})",
                    )
                await proxy_response.write(chunk)

            return proxy_response

    except asyncio.TimeoutError:
        return web.Response(
            status=504,
            text=f"Request timed out (max {BIZYDRAFT_REQUEST_TIMEOUT//60} minutes)",
        )
    except Exception as e:
        logger.error(f"Error in view_image: {str(e)}", exc_info=True)
        return web.Response(
            status=502, text=f"Failed to fetch remote resource: {str(e)}"
        )


def human_readable_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"


async def view_video(request):
    """处理VHS插件的viewvideo接口，支持从OSS URL加载视频"""
    logger.debug(
        f"Received request for /vhs/viewvideo with query: {request.rel_url.query}"
    )

    if "filename" not in request.rel_url.query:
        logger.warning("'filename' not provided in query string, returning 404")
        return web.Response(status=404, text="'filename' not provided in query string")

    # VHS插件的filename参数本身就是完整的URL（可能是URL编码的）
    filename = unquote(request.rel_url.query["filename"])

    if not filename.startswith(HTTP_PREFIX_OPTIONS):
        logger.warning(f"Invalid filename format: {filename=}, only URLs are supported")
        return web.Response(
            status=400, text="Invalid filename format(only url supported)"
        )

    try:
        content_type, _ = mimetypes.guess_type(filename)

        # 使用复用的客户端会话
        session = _get_client_session()
        async with session.get(filename) as resp:
            resp.raise_for_status()

            # 优先使用服务器返回的Content-Type
            final_content_type = (
                resp.headers.get("Content-Type")
                or content_type
                or "application/octet-stream"
            )

            content_length = int(resp.headers.get("Content-Length", 0))
            if content_length > BIZYDRAFT_MAX_FILE_SIZE:
                logger.warning(
                    f"File size {human_readable_size(content_length)} exceeds limit {human_readable_size(BIZYDRAFT_MAX_FILE_SIZE)}"
                )
                return web.Response(
                    status=413,
                    text=f"File size exceeds limit ({human_readable_size(BIZYDRAFT_MAX_FILE_SIZE)})",
                )

            headers = {
                "Content-Disposition": f'attachment; filename="{uuid.uuid4()}"',
                "Content-Type": final_content_type,
            }

            proxy_response = web.StreamResponse(headers=headers)
            await proxy_response.prepare(request)

            total_bytes = 0
            async for chunk in resp.content.iter_chunked(BIZYDRAFT_CHUNK_SIZE):
                total_bytes += len(chunk)
                if total_bytes > BIZYDRAFT_MAX_FILE_SIZE:
                    await proxy_response.write(b"")
                    return web.Response(
                        status=413,
                        text=f"File size exceeds limit during streaming ({human_readable_size(BIZYDRAFT_MAX_FILE_SIZE)})",
                    )
                await proxy_response.write(chunk)

            return proxy_response

    except asyncio.TimeoutError:
        return web.Response(
            status=504,
            text=f"Request timed out (max {BIZYDRAFT_REQUEST_TIMEOUT//60} minutes)",
        )
    except Exception as e:
        return web.Response(
            status=502, text=f"Failed to fetch remote resource: {str(e)}"
        )


async def view_audio(request):
    """处理VHS插件的viewaudio接口，支持从OSS URL加载音频"""
    logger.debug(
        f"Received request for /vhs/viewaudio with query: {request.rel_url.query}"
    )

    if "filename" not in request.rel_url.query:
        logger.warning("'filename' not provided in query string, returning 404")
        return web.Response(status=404, text="'filename' not provided in query string")

    # VHS插件的filename参数本身就是完整的URL（可能是URL编码的）
    filename = unquote(request.rel_url.query["filename"])

    if not filename.startswith(HTTP_PREFIX_OPTIONS):
        logger.warning(f"Invalid filename format: {filename=}, only URLs are supported")
        return web.Response(
            status=400, text="Invalid filename format(only url supported)"
        )

    try:
        content_type, _ = mimetypes.guess_type(filename)

        # 使用复用的客户端会话
        session = _get_client_session()
        async with session.get(filename) as resp:
            resp.raise_for_status()

            # 优先使用服务器返回的Content-Type
            final_content_type = (
                resp.headers.get("Content-Type")
                or content_type
                or "application/octet-stream"
            )

            content_length = int(resp.headers.get("Content-Length", 0))
            if content_length > BIZYDRAFT_MAX_FILE_SIZE:
                logger.warning(
                    f"File size {human_readable_size(content_length)} exceeds limit {human_readable_size(BIZYDRAFT_MAX_FILE_SIZE)}"
                )
                return web.Response(
                    status=413,
                    text=f"File size exceeds limit ({human_readable_size(BIZYDRAFT_MAX_FILE_SIZE)})",
                )

            headers = {
                "Content-Disposition": f'attachment; filename="{uuid.uuid4()}"',
                "Content-Type": final_content_type,
            }

            proxy_response = web.StreamResponse(headers=headers)
            await proxy_response.prepare(request)

            total_bytes = 0
            async for chunk in resp.content.iter_chunked(BIZYDRAFT_CHUNK_SIZE):
                total_bytes += len(chunk)
                if total_bytes > BIZYDRAFT_MAX_FILE_SIZE:
                    await proxy_response.write(b"")
                    return web.Response(
                        status=413,
                        text=f"File size exceeds limit during streaming ({human_readable_size(BIZYDRAFT_MAX_FILE_SIZE)})",
                    )
                await proxy_response.write(chunk)

            return proxy_response

    except asyncio.TimeoutError:
        return web.Response(
            status=504,
            text=f"Request timed out (max {BIZYDRAFT_REQUEST_TIMEOUT//60} minutes)",
        )
    except Exception as e:
        return web.Response(
            status=502, text=f"Failed to fetch remote resource: {str(e)}"
        )


async def query_video(request):
    """处理VHS插件的queryvideo接口，使用 PyAV 提取远端OSS视频的元数据"""
    logger.debug(
        f"Received request for /vhs/queryvideo with query: {request.rel_url.query}"
    )

    if "filename" not in request.rel_url.query:
        logger.warning("'filename' not provided in query string, returning 404")
        return web.Response(status=404, text="'filename' not provided in query string")

    filename = unquote(request.rel_url.query["filename"])

    if not filename.startswith(HTTP_PREFIX_OPTIONS):
        return web.json_response(
            {"error": "Only remote URLs supported by proxy"}, status=400
        )

    # 声明简单的字典作为缓存，避免同一个视频多次刷新页面重复探针消耗带宽
    if not hasattr(query_video, "cache"):
        query_video.cache = {}

    try:
        if filename in query_video.cache:
            source = query_video.cache[filename]
        else:
            import av

            loop = asyncio.get_running_loop()

            def get_metadata():
                with av.open(
                    filename, mode="r", options={"timeout": "5000000"}
                ) as container:
                    video_stream = next(
                        (s for s in container.streams if s.type == "video"), None
                    )
                    if not video_stream:
                        raise ValueError("No video stream found")

                    fps = (
                        float(video_stream.average_rate)
                        if video_stream.average_rate
                        else 30.0
                    )
                    width = video_stream.width or 0
                    height = video_stream.height or 0
                    duration = (
                        float(video_stream.duration * video_stream.time_base)
                        if video_stream.duration and video_stream.time_base
                        else 0.0
                    )
                    frames = video_stream.frames
                    if frames == 0 and duration > 0:
                        frames = round(duration * fps)

                    alpha = False
                    if video_stream.pix_fmt in ("rgba", "yuva420p", "argb"):
                        alpha = True

                    return {
                        "fps": fps,
                        "duration": duration,
                        "size": [width, height],
                        "alpha": alpha,
                        "frames": frames,
                    }

            source = await loop.run_in_executor(None, get_metadata)

            # 记录到缓存字典，上限 100 以防内存溢出
            if len(query_video.cache) > 100:
                query_video.cache.pop(next(iter(query_video.cache)))
            query_video.cache[filename] = source

        force_rate = request.rel_url.query.get("force_rate")
        loaded_fps = (
            float(force_rate) if force_rate and float(force_rate) > 0 else source["fps"]
        )
        loaded_duration = source["duration"] - float(
            request.rel_url.query.get("start_time", 0)
        )
        skip_first_frames = int(request.rel_url.query.get("skip_first_frames", 0))
        if loaded_fps > 0:
            loaded_duration -= skip_first_frames / loaded_fps
        nth = int(request.rel_url.query.get("select_every_nth", 1))
        if nth > 0:
            loaded_fps /= nth
        loaded_frames = round(loaded_duration * loaded_fps)

        metadata = {
            "source": source,
            "loaded": {
                "duration": loaded_duration,
                "fps": loaded_fps,
                "frames": loaded_frames,
            },
        }
        return web.json_response(metadata)
    except Exception as e:
        logger.error(
            f"Error querying video metadata in backend: {str(e)}", exc_info=True
        )
        # 必须返回完整结构的 fallback 字典，避免前端读取 source.fps 时抛出 undefined 毁掉整个组件
        fallback_metadata = {
            "source": {
                "fps": 30.0,
                "duration": 0.0,
                "size": [0, 0],
                "alpha": False,
                "frames": 0,
            },
            "loaded": {"duration": 0.0, "fps": 30.0, "frames": 0},
        }
        return web.json_response(fallback_metadata, status=200)
