from loguru import logger

_FRONTEND_WARNING_DISABLED_ATTR = "_bizydraft_frontend_warning_disabled"


def disable_frontend_version_warning():
    try:
        import app.frontend_management as frontend_management
    except Exception as exc:
        logger.warning(f"Failed to import app.frontend_management: {exc}")
        return False

    if getattr(frontend_management, _FRONTEND_WARNING_DISABLED_ATTR, False):
        return True

    original_get_required = getattr(
        frontend_management, "get_required_frontend_version", None
    )
    if original_get_required is None:
        logger.warning(
            "app.frontend_management.get_required_frontend_version is missing"
        )
        return False

    def _get_effective_required_frontend_version():
        try:
            installed_version = frontend_management.get_installed_frontend_version()
        except Exception:
            installed_version = None

        return installed_version or original_get_required()

    def _skip_frontend_version_check(*args, **kwargs):
        return None

    frontend_management.get_required_frontend_version = (
        _get_effective_required_frontend_version
    )
    frontend_management.check_frontend_version = _skip_frontend_version_check

    frontend_manager = getattr(frontend_management, "FrontendManager", None)
    if frontend_manager is not None:
        frontend_manager.get_required_frontend_version = classmethod(
            lambda cls: _get_effective_required_frontend_version()
        )

    setattr(frontend_management, _FRONTEND_WARNING_DISABLED_ATTR, True)
    logger.info("Disabled ComfyUI frontend version warnings.")
    return True


def prestartup_patch():
    disable_frontend_version_warning()

    def empty_download(*args, **kwargs):
        logger.warning(f"Blocked download {args}")
        return

    import torch.hub

    torch.hub.download_url_to_file = empty_download

    import huggingface_hub

    huggingface_hub.hf_hub_download = empty_download

    if not torch.cuda.is_available():
        logger.warning("CUDA is NOT available")
        torch.cuda.current_device = lambda: 0
        torch.cuda.device_count = lambda: 1
        torch.cuda.get_device_name = lambda x=0: "Fake CUDA Device"
        torch.cuda.get_device_properties = lambda x=0: type(
            "FakeProps",
            (),
            {
                "name": "Fake CUDA Device",
                "major": 8,
                "minor": 0,
                "total_memory": 8589934592,
                "multi_processor_count": 80,
                "uuid": "019f4533-ac25-1db6-21b9-97977befe1ef",
                "L2_cache_size": "60MB",
            },
        )()
