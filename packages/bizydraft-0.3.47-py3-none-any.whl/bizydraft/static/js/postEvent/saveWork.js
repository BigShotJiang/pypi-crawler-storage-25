import { createMD5, createCRC64, createSHA256 } from "../lib/hash-wasm.js";

/**
 * 计算文件的复合哈希值 (SHA256 based on MD5 + CRC64)
 * 算法: sha256(base64(md5) + crc64_decimal)
 * @param {Blob|File|string} content - 文件、Blob 或字符串
 * @returns {Promise<{checksum: string, md5Hash: string}>}
 */
export async function calculateWorkflowHash(content) {
  let blob = content;
  if (typeof content === "string") {
    blob = new Blob([content], { type: "application/json" });
  }

  const chunkSize = 1024 * 1024; // 1MB chunks

  const md5Hasher = await createMD5();
  const crc64Hasher = await createCRC64();
  const sha256Hasher = await createSHA256();

  md5Hasher.init();
  crc64Hasher.init();
  sha256Hasher.init();

  const fileSize = blob.size;
  let offset = 0;

  // 分块读取并计算 MD5 和 CRC64
  while (offset < fileSize) {
    const chunk = blob.slice(offset, offset + chunkSize);
    const buffer = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = () => reject(new Error("FileReader error"));
      reader.readAsArrayBuffer(chunk);
    });

    const uint8Array = new Uint8Array(buffer);
    md5Hasher.update(uint8Array);
    crc64Hasher.update(uint8Array);

    offset += buffer.byteLength;
  }

  // 处理 MD5: Hex -> Base64
  const md5HashHex = md5Hasher.digest();
  const md5Bytes = new Uint8Array(
    md5HashHex.match(/.{2}/g).map((byte) => parseInt(byte, 16))
  );
  const base64Md5 = btoa(String.fromCharCode(...md5Bytes));

  // 处理 CRC64: Hex -> Decimal String
  const crc64HashHex = crc64Hasher.digest();
  const flippedCrc64 = BigInt("0x" + crc64HashHex).toString(10);

  // 计算最终 SHA256
  const combinedString = `${base64Md5}${flippedCrc64}`;
  sha256Hasher.update(combinedString);
  const sha256sum = sha256Hasher.digest();

  return { checksum: sha256sum, md5Hash: base64Md5 };
}

// const WORKFLOW_HASH_STRIP_KEYS = new Set([
//   "color",
//   "bgcolor",
//   "extra",
//   "videopreview",
// ]);

// const WORKFLOW_HASH_STRIP_WIDGETS_NODE_TYPES = [
//   "easy showAnything",
//   "ShowText|pysssss",
//   "PD_ShowText",
//   "PreviewAny",
//   "ShowTextForGPT",
//   "JjkShowText",
//   "Show any to JSON [Crystools]",
// ];

// function workflowJsonReplacerForHash(key, value) {
//   if (WORKFLOW_HASH_STRIP_KEYS.has(key)) {
//     return undefined;
//   }
//   return value;
// }

// /**
//  * 规范化工作流对象，供 checksum / 保存哈希使用（与 saveWork 一致）
//  * @param {object} workflow - 内层 workflow 对象；若外层为 { workflow } 需先 unwrap
//  */
// export function normalizeWorkflowForHash(workflow) {

//   if (!normalized.nodes || !Array.isArray(normalized.nodes)) {
//     return normalized;
//   }

//   for (const node of normalized.nodes) {
//     const nodeType = node.type || node.class_type;
//     if (nodeType && nodeType.includes("Preview3D")) {
//       if (node.properties && node.properties["Last Time Model File"]) {
//         delete node.properties["Last Time Model File"];
//       }
//       if (node.properties && node.properties["Camera Config"]) {
//         delete node.properties["Camera Config"];
//       }
//       if (node.widgets_values) {
//         delete node.widgets_values;
//       }
//     }
//     if (nodeType && nodeType.includes("Image Comparer (rgthree)")) {
//       if (node.widgets_values) {
//         delete node.widgets_values;
//       }
//     }
//     if (nodeType && WORKFLOW_HASH_STRIP_WIDGETS_NODE_TYPES.includes(nodeType)) {
//       if (node.widgets_values) {
//         delete node.widgets_values;
//       }
//     }
//     if (node.size) {
//       delete node.size;
//     }
//   }

//   return normalized;
// }

/**
 * 保存工作流并计算哈希值
 * @param {object} workflow - ComfyUI 工作流对象
 * @returns {Promise<{checksum: string, workflowStr: string}>}
 */
export async function saveWork(workflow) {
  try {
    // 兼容处理：如果传入的是 { workflow: {...} } 格式，提取内层
    let actualWorkflow = workflow;
    if (workflow.workflow && typeof workflow.workflow === "object") {
      actualWorkflow = workflow.workflow;
    }

    // const normalized = normalizeWorkflowForHash(actualWorkflow);
    const normalized = actualWorkflow;

    // 序列化并计算哈希
    const workflowStr = JSON.stringify(normalized);
    const { checksum, md5Hash } = await calculateWorkflowHash(workflowStr);

    return {
      checksum,
      workflowStr,
      md5Hash,
    };
  } catch (error) {
    console.error("Hash calculation failed:", error);
    throw error;
  }
}
