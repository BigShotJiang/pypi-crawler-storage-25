import { app } from "../../../scripts/app.js";
import { draftFetch } from "../utils/draftFetch.js";
import {
  enableAIAppMode,
  disableAIAppMode,
  selectInputNode,
  deselectInputNode,
  updateInputNodeWidget,
  getSelectedInputNodes,
  clearSelectedInputNodes,
  toggleExportMode,
} from "../aiAppHandler.js";
import { focusNodeOnly } from "../nodeFocusHandler.js";
import { processNodeMeta, hasModelInput } from "../tool.js";
import { saveWorkflowToServer } from "./saveWorkflow.js";
import { calculateWorkflowHash } from "./saveWork.js";
import { runWorkflowHandler } from "./runWorkflowHandler.js";
import { validateWorkflowNodes } from "./workflowValidation.js";

const customErrorStyles = new Map();

// 用于节流的时间戳
let lastRunWorkflowTime = 0;
const THROTTLE_TIME = 2000; // 2秒

export function createHandlers(createSocket, closeSocket) {
  const methods = {
    customSocket: async function (params) {
      const socket = createSocket(params.url);
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "customSocket",
          result: "自定义socket执行结果",
        },
        "*"
      );
      return socket;
    },

    closeSocket: function () {
      const result = closeSocket();
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "closeSocket",
          result: result ? "Socket连接已关闭" : "Socket连接关闭失败或已关闭",
        },
        "*"
      );
      return result;
    },

    clearCanvas: function () {
      app.clean();
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "clearCanvas",
          result: true,
        },
        "*"
      );
      return true;
    },

    loadWorkflow: async function (params) {
      let workflowJson = params.json;
      if (!workflowJson && (params.contentUrl || params.content_url)) {
        const contentUrl = params.contentUrl || params.content_url;
        try {
          workflowJson = await draftFetch(contentUrl);
          if (!workflowJson) {
            throw new Error("下载工作流失败");
          }
        } catch (err) {
          console.error("loadWorkflow fetch 失败:", err);
          window.parent.postMessage(
            {
              type: "functionResult",
              method: "loadWorkflow",
              result: false,
              error: err?.message || "加载工作流失败",
            },
            "*"
          );
          return false;
        }
      }
      if (!workflowJson) {
        console.error("loadWorkflow: 缺少 json 或 contentUrl");
        return false;
      }
      app.clean();
      document.dispatchEvent(
        new CustomEvent("workflowLoaded", { detail: workflowJson })
      );
      if (workflowJson.templates && workflowJson.templates.length > 0) {
        await app.loadTemplateData(workflowJson);
      } else if (workflowJson.version) {
        await app.loadGraphData(workflowJson);
      } else {
        await app.loadApiJson(workflowJson, "bizyair");
      }
      console.log("-----------loadWorkflow-----------", workflowJson);
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "loadWorkflow",
          result: true,
        },
        "*"
      );
      return true;
    },

    replaceWorkflow: async function (params) {
      const downloadUrl = params.downloadUrl || params.download_url;
      if (!downloadUrl) {
        console.error("replaceWorkflow: 缺少 downloadUrl");
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "replaceWorkflow",
            result: false,
            error: "缺少 downloadUrl",
          },
          "*"
        );
        return;
      }
      try {
        const workflowJson = await draftFetch(downloadUrl);
        if (!workflowJson) {
          throw new Error("下载工作流失败");
        }
        app.clean();
        document.dispatchEvent(
          new CustomEvent("workflowLoaded", { detail: workflowJson })
        );
        if (workflowJson.templates && workflowJson.templates.length > 0) {
          await app.loadTemplateData(workflowJson);
        } else if (workflowJson.version) {
          await app.loadGraphData(workflowJson);
        } else {
          await app.loadApiJson(workflowJson, "bizyair");
        }
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "replaceWorkflow",
            result: true,
          },
          "*"
        );
      } catch (err) {
        console.error("replaceWorkflow 失败:", err);
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "replaceWorkflow",
            result: false,
            error: err?.message || "替换工作流失败",
          },
          "*"
        );
      }
    },

    saveWorkflow: async function (params) {
      const graph = await app.graphToPrompt();
      const workflowName = params?.workflowJsonName || "workflow";
      const cleanData = JSON.parse(JSON.stringify(graph.workflow));
      window.parent.postMessage(
        {
          type: "requestDownload",
          payload: { data: cleanData, filename: workflowName },
        },
        "*"
      );
    },

    getWorkflow: async function (params) {
      await saveWorkflowToServer(params);
    },

    getWorkflowNotSave: async function () {
      const graph = await app.graphToPrompt();
      const normalized = graph.workflow;
      const jsonStr = JSON.stringify(normalized);
      const { checksum } = await calculateWorkflowHash(jsonStr);

      window.parent.postMessage(
        {
          type: "functionResult",
          method: "getWorkflowNotSave",
          result: { checksum },
        },
        "*"
      );
      return normalized;
    },

    // 新增：获取 workflow 和 output
    getWorkflowWithOutput: async function () {
      const graph = await app.graphToPrompt();
      for (const key in graph.output) {
        graph.output[key]._meta.id = Number(key);
        graph.output[key]._meta.class_type = graph.output[key].class_type;
      }
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "getWorkflowWithOutput",
          result: {
            workflow: JSON.parse(JSON.stringify(graph.workflow)),
            output: JSON.parse(JSON.stringify(graph.output)),
          },
        },
        "*"
      );
      return { workflow: graph.workflow, output: graph.output };
    },

    saveApiJson: async function (params) {
      const graph = await app.graphToPrompt();

      // 添加计费标识
      await processNodeMeta((runtimeNode, meta) => {
        const isPayNode = !!hasModelInput(runtimeNode);
        if (isPayNode) {
          meta.trd_node = true;
        }
      }, graph);

      const filename = params?.workflowJsonName || "workflow_api";
      const cleanData = JSON.parse(JSON.stringify(graph.output));
      window.parent.postMessage(
        {
          type: "requestDownload",
          payload: { data: cleanData, filename },
        },
        "*"
      );
    },

    getClientId: function () {
      const clientId = sessionStorage.getItem("clientId");
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "getClientId",
          result: clientId,
        },
        "*"
      );
      return clientId;
    },

    runWorkflow: async function (params) {
      await runWorkflowHandler(params);
    },

    setCookie: function (params) {
      const setCookieFunc = (name, value, days) => {
        let expires = "";
        if (days) {
          const date = new Date();
          date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
          expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
      };
      // console.log("-----------setCookie-----------", params)
      // console.log("-----------setCookie-----------", params)
      setCookieFunc(params.name, params.value, params.days);
      return true;
    },

    removeCookie: function (params) {
      const expires = new Date(0).toUTCString();
      document.cookie = params.name + "=; expires=" + expires + "; path=/";
      return true;
    },

    fitView: function () {
      app.canvas.fitViewToSelectionAnimated();
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "fitView",
          result: true,
        },
        "*"
      );
      return true;
    },

    clickAssistant: function () {
      const assistantBtn = document.querySelector(".btn-assistant");
      if (assistantBtn) {
        assistantBtn.click();
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "clickAssistant",
            result: true,
          },
          "*"
        );
        return true;
      } else {
        console.warn("Assistant button not found");
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "clickAssistant",
            result: false,
          },
          "*"
        );
        return false;
      }
    },

    clickCommunity: function () {
      const communityBtn = document.querySelector(".btn-community");
      if (communityBtn) {
        communityBtn.click();
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "clickCommunity",
            result: true,
          },
          "*"
        );
        return true;
      } else {
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "clickCommunity",
            result: false,
          },
          "*"
        );
        return false;
      }
    },

    toPublish: async function () {
      const graph = await app.graphToPrompt();
      const normalized = graph.workflow;
      const jsonStr = JSON.stringify(normalized);
      const { checksum } = await calculateWorkflowHash(jsonStr);

      window.parent.postMessage(
        {
          type: "functionResult",
          method: "toPublish",
          result: { checksum },
        },
        "*"
      );
      return { checksum };
    },

    convertNodeFormat: async function (params) {
      console.log("postEvent.js - convertNodeFormat 被调用，参数:", params);
      const graph = await app.graphToPrompt();
      const isBizyAirParam = params?.isBizyAir;
      const fromSource = params?.from || "unknown";
      const comfy2bizyair =
        isBizyAirParam === true ||
        isBizyAirParam === "true" ||
        isBizyAirParam === 1 ||
        isBizyAirParam === "1";

      const workflowPayload =
        graph && graph.workflow && typeof graph.workflow === "object"
          ? graph.workflow
          : {};

      const data = await draftFetch("/bizyair/node_converter", {
        method: "POST",
        body: {
          ...workflowPayload,
          comfy2bizyair,
        },
      });

      const converted = data?.data ?? data;
      if (converted) {
        await app.loadGraphData(converted, true, false, "convert_test");
      }

      window.parent.postMessage(
        {
          type: "functionResult",
          method: "convertNodeFormat",
          params,
          result: {
            success: true,
            from: fromSource,
            isBizyAir: isBizyAirParam,
          },
        },
        "*"
      );
      return { success: true, from: fromSource, isBizyAir: isBizyAirParam };
    },

    loadGraphData: async function (params) {
      const { json, clear = true, center = false, workflow_name = "" } = params;
      if (clear) {
        app.clean();
      }
      await app.loadGraphData(json, clear, center, workflow_name);

      window.parent.postMessage(
        {
          type: "functionResult",
          method: "loadGraphData",
          result: true,
        },
        "*"
      );
      return true;
    },

    // AI应用相关方法
    toggleAIAppMode: function (params) {
      const enable = params.enable === true;
      const result = enable ? enableAIAppMode() : disableAIAppMode();
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "toggleAIAppMode",
          result: result,
        },
        "*"
      );
      return result;
    },

    selectInputNode: function (params) {
      if (!params.nodeId) return false;
      const result = selectInputNode(params.nodeId);
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "selectInputNode",
          result: result,
        },
        "*"
      );
      return result;
    },

    selectExportNode: function (params) {
      if (!params.nodeId) return false;
      const result = selectInputNode(params.nodeId);
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "selectExportNode",
          result: result,
        },
        "*"
      );
      return result;
    },

    deselectInputNode: function (params) {
      if (!params.nodeId) return false;
      const result = deselectInputNode(params.nodeId);
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "deselectInputNode",
          result: result,
        },
        "*"
      );
      return result;
    },

    updateInputNodeWidget: function (params) {
      if (!params.nodeId || params.widgetName === undefined) return false;
      const result = updateInputNodeWidget(
        params.nodeId,
        params.widgetName,
        params.value
      );
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "updateInputNodeWidget",
          result: result,
        },
        "*"
      );
      return result;
    },

    getInputNodes: function () {
      const result = getSelectedInputNodes();
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "getInputNodes",
          result: result,
        },
        "*"
      );
      return result;
    },

    clearInputNodes: function () {
      const result = clearSelectedInputNodes();
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "clearInputNodes",
          result: result,
        },
        "*"
      );
      return result;
    },

    toggleExportMode: function (params) {
      const result = toggleExportMode(params);
      window.parent.postMessage(
        {
          type: "functionResult",
          method: "toggleExportMode",
          result: result,
        },
        "*"
      );
      return result;
    },

    openCustomError: function (params) {
      const {
        nodeId,
        nodeType,
        errorMessage,
        borderColor = "#FF0000",
      } = params;
      const nodeIds = Array.isArray(nodeId) ? nodeId : [nodeId];

      function injectErrorDialogStyles() {
        const styleId = "custom-error-dialog-styles";
        if (document.getElementById(styleId)) {
          return; // 样式已经存在
        }

        const style = document.createElement("style");
        style.id = styleId;
        style.textContent = `
                        .comfy-error-report .no-results-placeholder p {
                            text-align: left;
                        }
                    `;
        document.head.appendChild(style);
      }
      injectErrorDialogStyles();

      function simulateExecutionError(id, type, msg, color) {
        // const originalNodeErrorStyle = node.strokeStyles?.['nodeError']
        const node = app.graph.getNodeById(id);
        if (node) {
          if (!customErrorStyles.has(id)) {
            customErrorStyles.set(id, {
              originalStyle: node.strokeStyles?.["nodeError"],
              customColor: color,
              nodeId: id,
            });
          }
          node.strokeStyles = node.strokeStyles || {};
          node.strokeStyles["nodeError"] = function () {
            // if (this.id === nodeId) {
            return { color: color, lineWidth: 2 }; // 自定义颜色和线宽
            // }
          };
        }
        const mockErrorEvent = {
          detail: {
            node_id: id,
            node_type: type,
            exception_message: msg,
            exception_type: "ManualError",
            traceback: ["Manual error triggered"],
            executed: [],
            prompt_id: "manual",
            timestamp: Date.now(),
          },
        };

        // 手动触发事件监听器
        app.api.dispatchCustomEvent("execution_error", mockErrorEvent.detail);
      }

      nodeIds.forEach((id) =>
        simulateExecutionError(id, nodeType, errorMessage, borderColor)
      );
      app.canvas.draw(true, true);

      // 添加发送消息给前端折叠侧边栏的代码
      window.parent.postMessage(
        {
          type: "collapseParamSelector",
          method: "collapseParamSelector",
          result: true,
        },
        "*"
      );

      window.parent.postMessage(
        { type: "functionResult", method: "openCustomError", result: true },
        "*"
      );
    },

    openCustomErrorUseJsonData: function (jsonData) {
      // 手动触发事件监听器
      app.api.dispatchCustomEvent("execution_error", jsonData);
      // 添加发送消息给前端折叠侧边栏的代码
      window.parent.postMessage(
        {
          type: "collapseParamSelector",
          method: "collapseParamSelector",
          result: true,
        },
        "*"
      );

      window.parent.postMessage(
        {
          type: "functionResult",
          method: "openCustomErrorUseJsonData",
          result: true,
        },
        "*"
      );
    },

    clearAllCustomStyles: function () {
      customErrorStyles.forEach((styleInfo, nodeId) => {
        const node = app.graph.getNodeById(nodeId);
        if (!node) return;
        // console.log(node);
        // 恢复原始样式
        if (styleInfo.originalStyle) {
          node.strokeStyles["nodeError"] = styleInfo.originalStyle;
        } else {
          delete node.strokeStyles["nodeError"];
        }

        // 从映射中移除
        customErrorStyles.delete(nodeId);
      });

      // 重绘画布
      app.canvas.draw(true, true);
    },

    focusNodeOnly: function (params) {
      if (!params.nodeId) return false;
      const result = focusNodeOnly(params.nodeId);
      window.parent.postMessage(
        { type: "functionResult", method: "focusNodeOnly", result: result },
        "*"
      );
      return result;
    },

    addNode: function (params) {
      try {
        const { modelName, modelType, versionId } = params;

        if (!modelName || !modelType || !versionId) {
          console.error("addNode: 缺少必需参数", params);
          window.parent.postMessage(
            {
              type: "functionResult",
              method: "addNode",
              error: "缺少必需参数: modelName, modelType, versionId",
              success: false,
            },
            "*"
          );
          return false;
        }

        // 根据模型类型确定节点类型
        let nodeTypes = {
          LoRA: "LoraLoader",
          Controlnet: "ControlNetLoader",
          Checkpoint: "CheckpointLoaderSimple",
          VAE: "VAELoader",
          CLIP: "CLIPLoader",
          UNet: "UNETLoader",
          Upscaler: "UpscaleModelLoader",
          Detection: "ONNXDetectorProvider",
          Other: "IPAdapterModelLoader",
        };

        const nodeID = nodeTypes[modelType] || "ControlNetLoader";

        // 使用 LiteGraph 创建节点
        const node = LiteGraph.createNode(nodeID);
        if (!node) throw new Error(`无法创建节点类型: ${nodeID}`);

        node.color = "#7C3AED";
        const versionIdStr = versionId ? versionId.toString() : "";

        if (node.widgets) {
          node.widgets.forEach((widget) => {
            if (!widget) return;
            if (
              [
                "lora_name",
                "ckpt_name",
                "control_net_name",
                "vae_name",
                "unet_name",
                "model_name",
              ].includes(widget.name)
            ) {
              widget.value = modelName;
            }
            if (widget.name === "model_version_id") widget.value = versionIdStr;
            if (modelType === "LoRA") {
              if (
                widget.name === "strength_model" ||
                widget.name === "strength_clip"
              )
                widget.value = 1.0;
            }
          });
          node.widgets_values = node.widgets.map((w) => w.value);
        }

        const currentConfig = app.graph.serialize();
        const nodeCount = currentConfig.nodes?.length || 0;
        const visibleRect = app.canvas.visible_area;
        const offsetX = (nodeCount % 3) * 30;
        const offsetY = Math.floor(nodeCount / 3) * 25;
        const baseX = visibleRect ? visibleRect[0] + 100 : 100;
        const baseY = visibleRect ? visibleRect[1] + 100 : 100;

        node.pos = [baseX + offsetX, baseY + offsetY];
        app.graph.add(node);

        window.parent.postMessage(
          {
            type: "functionResult",
            method: "addNode",
            result: { success: true, nodeId: node.id, nodeType: nodeID },
          },
          "*"
        );
        return true;
      } catch (error) {
        console.error("添加节点失败:", error);
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "addNode",
            error: error.message || "添加节点失败",
            success: false,
          },
          "*"
        );
        return false;
      }
    },

    saveAndSwitch: async function () {
      try {
        const url = new URL(window.location.href);
        const workflowId = url.searchParams.get("id");
        if (workflowId) {
          await saveWorkflowToServer({ workflowId, type: 0 });
        }
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "saveAndSwitch",
            result: { success: true },
          },
          "*"
        );
      } catch (e) {
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "saveAndSwitch",
            result: { success: false, error: e?.message || "保存失败" },
          },
          "*"
        );
      }
    },

    deselectExportNode: function (params) {
      if (params && params.nodeId !== undefined) {
        if (typeof window.deselectInputNode === "function") {
          window.deselectInputNode(params.nodeId);
        }
      }
    },

    clearExportNodes: function () {
      if (typeof window.clearExportNodes === "function") {
        window.clearExportNodes();
      }
    },

    saveOriginalNodeColors: function (params) {
      if (typeof window.saveOriginalNodeColors === "function") {
        window.saveOriginalNodeColors(params.workflowId);
      }
    },

    // 校验工作流节点类型
    validateWorkflowNodes: async function (params) {
      const contentUrl = params.contentUrl || params.content_url;
      if (!contentUrl) {
        window.parent.postMessage(
          {
            type: "functionResult",
            method: "validateWorkflowNodes",
            result: { isValid: false, error: "缺少 contentUrl" },
          },
          "*"
        );
        return;
      }
      const result = await validateWorkflowNodes(contentUrl);
      window.parent.postMessage(
        { type: "functionResult", method: "validateWorkflowNodes", result },
        "*"
      );
    },

    handleKeyDown: function (event) {
      // 禁用 Ctrl+S 保存工作流
      if ((event.ctrlKey || event.metaKey) && event.key === "s") {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        return;
      }

      // 禁用 Ctrl+Shift+K / Cmd+Shift+K
      if (
        (event.ctrlKey || event.metaKey) &&
        event.shiftKey &&
        (event.key === "k" || event.key === "K")
      ) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        return;
      }

      // 监听 Ctrl+Enter 快捷键执行工作流
      if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();

        // 节流：检查距离上次执行是否已经过了2秒
        const now = Date.now();
        if (now - lastRunWorkflowTime < THROTTLE_TIME) {
          console.log("触发频率过高，请稍后再试");
          return;
        }

        // 更新上次执行时间
        lastRunWorkflowTime = now;

        window.parent.postMessage(
          { type: "functionResult", method: "ctrlEnter", result: true },
          "*"
        );
      }
    },
  };

  return methods;
}
