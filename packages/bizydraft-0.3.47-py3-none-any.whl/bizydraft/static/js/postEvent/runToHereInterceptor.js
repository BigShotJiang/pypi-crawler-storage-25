/**
 * "Run to here" 命令拦截器
 *
 * 功能：拦截 ComfyUI 的"运行到此处"命令，获取选中节点的执行路径，
 *       并通过 postMessage 通知父窗口（BizyHome）执行工作流
 *
 * 通信流程：
 * 1. 用户在 ComfyUI 点击"运行到此处"按钮
 * 2. 拦截 Comfy.QueueSelectedOutputNodes 命令
 * 3. 获取选中输出节点的 executionIds（执行路径）
 * 4. 发送消息给父窗口，父窗口调用 runWorkflow 并传入 partial_execution_targets
 * 5. 后端执行部分工作流
 */

/**
 * 在子图中查找目标图的执行路径
 *
 * 用于处理嵌套子图的情况，例如：
 * - 主图 -> 子图A -> 子图B -> 目标图
 * - 返回路径如 "5:3:2" 表示从主图的节点5 -> 子图A的节点3 -> 子图B的节点2
 *
 * @param {Object} target - 目标图（通常是当前选中的子图）
 * @param {Object} root - 根图（主图）
 * @returns {string|undefined} 执行路径，如 "5:3:2" 或 undefined
 */
export function findPartialExecutionPathToGraph(target, root) {
  for (const node of root.nodes) {
    if (!node.isSubgraphNode?.()) continue;
    if (node.subgraph === target) return `${node.id}`;
    const subpath = findPartialExecutionPathToGraph(target, node.subgraph);
    if (subpath !== undefined) return `${node.id}:${subpath}`;
  }
  return undefined;
}

/**
 * 从节点集合中收集信息（深度优先遍历）
 *
 * 使用栈进行深度优先遍历，支持处理嵌套子图
 *
 * @param {Array} nodes - 节点数组
 * @param {Function} collector - 收集函数，返回要收集的数据
 * @param {Function} contextBuilder - 上下文构建函数，用于构建子节点的上下文
 * @param {any} initialContext - 初始上下文
 * @returns {Array} 收集结果数组
 */
export function collectFromNodes(
  nodes,
  collector,
  contextBuilder,
  initialContext
) {
  const results = [];
  const stack = nodes.map((node) => ({ node, context: initialContext }));
  while (stack.length) {
    const { node, context } = stack.pop();
    const data = collector(node, context);
    if (data !== null) results.push(data);
    const childContext = contextBuilder(node, context);
    if (node.isSubgraphNode?.() && node.subgraph) {
      const children = node.subgraph.nodes || [];
      for (let i = children.length - 1; i >= 0; i--) {
        stack.push({ node: children[i], context: childContext });
      }
    }
  }
  return results;
}

/**
 * 获取选中节点的执行 ID 列表
 *
 * 执行 ID 用于告诉后端需要执行到哪些节点为止
 * 例如：["1", "2:5", "3"] 表示执行到节点1、节点2的子节点5、节点3
 *
 * @param {Array} selectedNodes - 选中的节点数组
 * @returns {string[]} 执行 ID 数组
 */
export function getExecutionIdsForSelectedNodes(selectedNodes) {
  const startGraph = selectedNodes[0]?.graph;
  if (!startGraph) return [];
  const rootGraph = startGraph.rootGraph ?? startGraph;
  const parentPath = startGraph.isRootGraph
    ? ""
    : findPartialExecutionPathToGraph(startGraph, rootGraph);
  if (parentPath === undefined) return [];
  return collectFromNodes(
    selectedNodes,
    (node, parentExecutionId) => {
      const nodeId = String(node.id);
      return parentExecutionId ? `${parentExecutionId}:${nodeId}` : nodeId;
    },
    (node, parentExecutionId) => {
      const nodeId = String(node.id);
      return parentExecutionId ? `${parentExecutionId}:${nodeId}` : nodeId;
    },
    parentPath
  );
}

/**
 * 设置 "Run to here" 命令拦截器
 *
 * 拦截步骤：
 * 1. 获取 Vue 应用实例和 Pinia store
 * 2. 从 command store 获取 "Comfy.QueueSelectedOutputNodes" 命令
 * 3. 替换命令的 function，拦截执行
 * 4. 获取选中节点并计算 executionIds
 * 5. 通过 postMessage 通知父窗口
 */
export function setupRunToHereInterceptor() {
  // 1. 获取 Vue 应用实例
  const vueApp = document.querySelector("#vue-app")?.__vue_app__;
  if (!vueApp) {
    console.log("[Run to here] Vue app not found, retrying...");
    setTimeout(setupRunToHereInterceptor, 500);
    return;
  }

  // 2. 获取 Pinia 状态管理
  const pinia = vueApp.config.globalProperties?.$pinia;
  if (!pinia) {
    console.log("[Run to here] Pinia not found, retrying...");
    setTimeout(setupRunToHereInterceptor, 500);
    return;
  }

  // 3. 获取 ComfyUI 的 command store 和 canvas store
  const commandStore = pinia._s?.get("command");
  const canvasStore = pinia._s?.get("canvas");

  if (!commandStore || !canvasStore) {
    console.log("[Run to here] Stores not found, retrying...");
    setTimeout(setupRunToHereInterceptor, 500);
    return;
  }

  // 4. 获取 "Run to here" 命令
  const cmd = commandStore.getCommand?.("Comfy.QueueSelectedOutputNodes");
  if (!cmd) {
    console.log(
      "[Run to here] Command 'Comfy.QueueSelectedOutputNodes' not found, retrying..."
    );
    setTimeout(setupRunToHereInterceptor, 500);
    return;
  }

  // 5. 保存原始命令函数（可选，用于恢复）
  window.__origQueueSelectedOutputNodes = cmd.function;

  // 6. 替换命令函数，拦截执行
  cmd.function = async function (metadata) {
    // 获取画布上选中的节点
    const selectedItems = canvasStore.selectedItems ?? [];
    // 过滤出有 graph 和 id 的节点
    const selectedNodes = selectedItems.filter(
      (i) => i?.graph && i?.id != null
    );
    // 过滤出输出节点（output_node 为 true 的节点）
    const selectedOutputNodes = selectedNodes.filter(
      (n) => n.constructor?.nodeData?.output_node
    );

    // 获取选中节点的执行 ID
    const executionIds = getExecutionIdsForSelectedNodes(selectedOutputNodes);

    console.log("[Run to here intercepted]", {
      metadata,
      selectedNodes,
      selectedOutputNodes,
      executionIds,
    });

    // 7. 发送消息给父窗口（BizyHome）
    window.parent.postMessage(
      {
        type: "functionResult",
        method: "runToHere",
        result: {
          executionIds,
        },
      },
      "*"
    );
  };

  console.log("[Run to here] Interceptor setup successfully!");
}
