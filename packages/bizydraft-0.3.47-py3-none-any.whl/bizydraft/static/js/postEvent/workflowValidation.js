import { getSelectedInputNodes } from "../aiAppHandler.js";
import { draftFetch } from "../utils/draftFetch.js";

export async function validateWorkflowNodes(contentUrl) {
  try {
    const workflowJsonData = await draftFetch(contentUrl);
    if (!workflowJsonData) {
      console.error("下载工作流JSON文件失败:", workflowJsonData);
      return { isValid: false, error: "下载工作流JSON文件失败" };
    }

    const remoteNodeTypes = new Set();
    if (workflowJsonData.nodes && Array.isArray(workflowJsonData.nodes)) {
      workflowJsonData.nodes.forEach((node) => {
        if (node.type) {
          remoteNodeTypes.add(node.type);
        }
      });
    }

    const selectedNodes = getSelectedInputNodes();
    for (const node of selectedNodes) {
      if (node.type && !remoteNodeTypes.has(node.type)) {
        console.warn(`节点类型不匹配: ${node.type} 不在远程工作流中`);
        return {
          isValid: false,
          error: `节点类型 ${node.type} 不在远程工作流中`,
        };
      }
    }
    return { isValid: true };
  } catch (err) {
    console.error("校验工作流失败:", err);
    return {
      isValid: false,
      error: err?.message || "校验工作流失败",
    };
  }
}
