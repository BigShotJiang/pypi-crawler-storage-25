import { app } from "../../../scripts/app.js";

/**
 * 轻量级检查画布上是否有 Use Everywhere 相关节点
 * 仅进行一次 O(N) 线性扫描，避免 UE 插件内部复杂的递归解析和元数据清洗
 */
export function hasUENodes() {
  if (!app?.graph?._nodes) return false;
  return app.graph._nodes.some((node) => {
    // 检查节点类型是否包含 UE 关键字
    const type = node.comfyClass || node.type;
    const isUE =
      type &&
      (type === "Anything Everywhere" ||
        type.startsWith("Anything Everywhere") ||
        type === "Seed Everywhere" ||
        type === "Prompts Everywhere");
    // 同时也检查是否有 ue_convert 属性（UE 插件提供的特殊标记）
    return isUE || node.properties?.ue_convert;
  });
}

/**
 * 优化后的获取 Prompt 方法
 * 如果环境中有 UE 插件且当前图包含 UE 节点，则调用增强方法；否则使用原生方法。
 */
export async function getPromptOptimized() {
  if (app.ue_modified_prompt && hasUENodes()) {
    return await app.ue_modified_prompt();
  }
  return await app.graphToPrompt();
}
