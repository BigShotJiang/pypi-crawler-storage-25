import { app } from "../../scripts/app.js";

app.registerExtension({
  name: "comfy.BizyAir.del.comfyui.default",
  async setup() {
    const vueApp = document.querySelector("#vue-app")?.__vue_app__;
    const pinia = vueApp?.config?.globalProperties?.$pinia;
    const missingModelStore = pinia._s.get("missingModel");
    const executionErrorStore = pinia._s.get("executionError");

    // 备份原方法，方便恢复
    window.__missingModelPatch ??= {
      runMissingModelPipeline: app.runMissingModelPipeline?.bind(app),
    };
    // 清掉当前已存在的缺失模型状态，并中断当前验证
    missingModelStore?.clearMissingModels?.();
    // 屏蔽后续工作流加载时的缺失模型扫描/报错
    app.runMissingModelPipeline = async () => ({ missingModels: [] });
    // 顺手关掉因为缺失模型弹出的错误面板
    executionErrorStore?.dismissErrorOverlay?.();
  },
});
