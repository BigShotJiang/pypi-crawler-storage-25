// 保存原始的 WebSocket 构造函数
const OriginalWebSocket = window.WebSocket;

// 保存原始的 fetch 函数
const OriginalFetch = window.fetch;

// 保存原始的 XMLHttpRequest
const OriginalXHR = window.XMLHttpRequest;

// 需要跳过的 URL 数组
const skipFetchUrls = ["manager/badge_mode", "pysssss/autocomplete"];

// 需要拦截并上传到 OSS 的路由
const uploadRoutes = [
  "/upload/image",
  "/upload/mask",
  "/api/upload/image",
  "/api/upload/mask",
];

// 三方库加载状态缓存
let libsLoadingPromise = null;

function getUploadedFileUrlMap() {
  if (!(window.__bizyDraftUploadedFileUrlMap instanceof Map)) {
    window.__bizyDraftUploadedFileUrlMap = new Map();
  }
  return window.__bizyDraftUploadedFileUrlMap;
}

function cacheUploadedFileUrl(fileName, ossUrl) {
  if (!fileName || !ossUrl) {
    return;
  }
  getUploadedFileUrlMap().set(fileName, ossUrl);
}

/**
 * 加载外部脚本的辅助函数
 */
function loadScript(url) {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = url;
    s.onload = resolve;
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

/**
 * 确保 pako 和 UPNG 库已加载（单例模式）
 */
function ensureLibsLoaded() {
  if (libsLoadingPromise) return libsLoadingPromise;

  libsLoadingPromise = (async () => {
    try {
      // 自动获取当前脚本所在目录，用于生成库文件的本地路径
      let baseDir = "";
      if (document.currentScript) {
        baseDir = document.currentScript.src.substring(
          0,
          document.currentScript.src.lastIndexOf("/")
        );
      } else {
        // 模块化加载时的降级方案
        const scripts = document.getElementsByTagName("script");
        const selfScript = Array.from(scripts).find((s) =>
          s.src.includes("disableComfyWebSocket.js")
        );
        if (selfScript) {
          baseDir = selfScript.src.substring(
            0,
            selfScript.src.lastIndexOf("/")
          );
        }
      }

      if (!window.pako) {
        await loadScript(`${baseDir}/lib/pako.min.js`);
      }
      if (!window.pako) {
        throw new Error("pako 库加载失败，无法进行 PNG 编码");
      }

      if (!window.UPNG) {
        await loadScript(`${baseDir}/lib/UPNG.js`);
      }
      if (!window.UPNG) {
        throw new Error("UPNG 库加载失败");
      }
    } catch (error) {
      // 加载失败时重置缓存，允许后续重试
      libsLoadingPromise = null;
      throw error;
    }
  })();

  return libsLoadingPromise;
}

/**
 * 统一处理上传请求的核心逻辑
 */
async function handleUploadRequest(url, formData) {
  const { fileToOss } = await import("./uploadFile.js");

  const file = formData.get("image");
  const type = formData.get("type");

  if (!file || !(file instanceof File)) {
    throw new Error("未找到文件或文件格式错误");
  }

  const isMaskUpload = url.includes("/mask");
  let ossUrl;

  if (isMaskUpload) {
    const originalRef = formData.get("original_ref");
    const maskResult = await handleMaskUpload(
      file,
      type,
      originalRef,
      fileToOss
    );
    ossUrl = maskResult.url;
  } else {
    const result = await fileToOss(file);
    ossUrl = result.url;
  }

  const lastSlash = ossUrl.lastIndexOf("/");
  const fileName = ossUrl.substring(lastSlash + 1);
  cacheUploadedFileUrl(fileName, ossUrl);
  return {
    name: fileName,
    subfolder: ossUrl.substring(0, lastSlash), // OSS 基础路径
    type: type || "input",
  };
}

/**
 * 检查 URL 是否需要拦截
 */
function shouldInterceptUrl(url, urlList) {
  const urlString = typeof url === "string" ? url : url.toString();
  return urlList.some((item) => urlString.includes(item));
}

/**
 * 模拟 XHR 成功响应
 */
function mockXHRResponse(xhr, data) {
  const responseText = typeof data === "string" ? data : JSON.stringify(data);
  Object.defineProperty(xhr, "status", { value: 200, writable: false });
  Object.defineProperty(xhr, "statusText", { value: "OK", writable: false });
  Object.defineProperty(xhr, "readyState", { value: 4, writable: false });
  Object.defineProperty(xhr, "responseText", {
    value: responseText,
    writable: false,
  });
  Object.defineProperty(xhr, "response", {
    value: responseText,
    writable: false,
  });

  if (xhr.onreadystatechange) xhr.onreadystatechange();
  if (xhr.onload) xhr.onload();
}

class FakeWebSocket {
  constructor(url) {
    this.url = url;
    this.readyState = WebSocket.CONNECTING; // 核心：保持 CONNECTING 状态
    console.warn("[BizyDraft] 已阻止 WebSocket 连接:", url);
  }
  send() {}
  close() {}
  addEventListener() {}
  removeEventListener() {}
}

window.WebSocket = function (url, protocols) {
  //精确拦截/ws请求
  if (typeof url === "string" && /^wss?:\/\/[^/]+\/ws(\?.*)?$/.test(url)) {
    return new FakeWebSocket(url);
  }
  // 其他连接正常创建，不影响
  return new OriginalWebSocket(url, protocols);
};

// 保留 WebSocket 的静态属性和原型
Object.setPrototypeOf(window.WebSocket, OriginalWebSocket);
window.WebSocket.prototype = OriginalWebSocket.prototype;

// 复制静态常量（使用 defineProperty 避免只读属性错误）
["CONNECTING", "OPEN", "CLOSING", "CLOSED"].forEach((prop) => {
  Object.defineProperty(window.WebSocket, prop, {
    value: OriginalWebSocket[prop],
    writable: false,
    enumerable: true,
    configurable: true,
  });
});

// 拦截 fetch 请求
window.fetch = async function (url, options) {
  const urlString = typeof url === "string" ? url : url.toString();

  // 检查 URL 是否在跳过列表中
  if (shouldInterceptUrl(urlString, skipFetchUrls)) {
    console.warn("[BizyDraft] 已阻止 fetch 请求:", urlString);
    return Promise.resolve(
      new Response(null, {
        status: 200,
        statusText: "OK",
        headers: new Headers({ "Content-Type": "application/json" }),
      })
    );
  }

  // 检查是否是上传路由
  if (
    shouldInterceptUrl(urlString, uploadRoutes) &&
    options?.method === "POST" &&
    options.body instanceof FormData
  ) {
    console.log(
      "[BizyDraft] 拦截上传请求，转发到 OSS:",
      urlString,
      options.body.get("image")
    );

    try {
      const result = await handleUploadRequest(urlString, options.body);
      return new Response(JSON.stringify(result), {
        status: 200,
        headers: new Headers({ "Content-Type": "application/json" }),
      });
    } catch (error) {
      console.error("[BizyDraft] OSS 上传失败:", error);
      return OriginalFetch.apply(this, arguments);
    }
  }

  // 其他请求正常发送
  return OriginalFetch.apply(this, arguments);
};

/**
 * 处理 mask 上传
 */
async function handleMaskUpload(file, type, originalRefStr, fileToOss) {
  // 上传文件的辅助函数
  const uploadFile = async (fileToUpload) => {
    const result = await fileToOss(fileToUpload);
    return { url: result.url, type: type || "input" };
  };

  // 如果没有 original_ref，直接上传 mask
  if (!originalRefStr) {
    return uploadFile(file);
  }

  try {
    const originalRef = JSON.parse(originalRefStr);
    const originalFilename = originalRef.filename;
    const originalSubfolder = originalRef.subfolder || "";

    if (!originalFilename) {
      throw new Error("No filename in original_ref");
    }

    // 构建原始图片的 URL
    let originalUrl;
    if (originalSubfolder.includes("http")) {
      originalUrl = `${decodeURIComponent(
        originalSubfolder
      )}/${originalFilename}`;
    } else if (
      originalFilename.startsWith("http://") ||
      originalFilename.startsWith("https://")
    ) {
      originalUrl = originalFilename;
    } else {
      // 本地文件，直接上传 mask
      return uploadFile(file);
    }

    // 下载原始图片
    const originalResponse = await OriginalFetch(originalUrl);
    if (!originalResponse.ok) {
      throw new Error(
        `Failed to download original image: ${originalResponse.status}`
      );
    }
    const originalBlob = await originalResponse.blob();

    // 使用 Canvas 处理图片：应用 alpha 通道
    const processedBlob = await applyMaskToImage(originalBlob, file);

    // 上传处理后的图片
    const processedFile = new File(
      [processedBlob],
      `clipspace-mask-${Date.now()}.png`,
      { type: "image/png" }
    );
    return uploadFile(processedFile);
  } catch (error) {
    console.error("[BizyDraft] Mask 处理失败:", error);
    // 失败时直接上传原始 mask
    return uploadFile(file);
  }
}

/**
 * 完美的混合处理方案：
 * 1. 使用原生 ImageDecoder 解码（支持 JPG, WebP, PNG 等所有格式，解决 JPG 无 Alpha 的问题）
 * 2. 在内存中手动合并通道 (RGB 源自原图，A 源自遮罩)
 * 3. 使用 UPNG.js 二进制编码输出，确保像素 100% 还原且无 Canvas 污染
 */
async function applyMaskToImage(originalBlob, maskFile) {
  // 1. 确保编码库可用
  await ensureLibsLoaded();

  // 2. 定义高精度解码函数 (规范化输出为 RGBA)
  const decodeToPixels = async (blob) => {
    const decoder = new ImageDecoder({
      data: blob.stream(),
      type: blob.type,
      premultiplyAlpha: "none", // 保证我们拿到的是未被渲染引擎修改过的原始 R,G,B,A 数值
    });

    const { image } = await decoder.decode();
    const width = image.displayWidth;
    const height = image.displayHeight;

    // 关键修正：显式要求格式为 "RGBA"
    // 不同浏览器和系统默认格式可能是 "BGRA" (例如 macOS/Windows 常见的显存格式)
    // 如果不指定，导致解析出的数据变为 [B, G, R, A]，UPNG 会将其误判为 R 通道，导致图片全红
    const pixels = new Uint8ClampedArray(width * height * 4);
    if (image.copyTo) {
      await image.copyTo(pixels, {
        rect: { x: 0, y: 0, width, height },
        format: "RGBA", // 强制统一输出为 R-G-B-A 顺序
      });
    } else {
      throw new Error("浏览器不支持原生的位图拷贝 API (image.copyTo)");
    }

    image.close();
    return { pixels, width, height };
  };

  try {
    const [original, mask] = await Promise.all([
      decodeToPixels(originalBlob),
      decodeToPixels(maskFile),
    ]);

    if (original.width !== mask.width || original.height !== mask.height) {
      throw new Error("图片与遮罩尺寸不匹配");
    }

    const { pixels: targetPixels, width, height } = original;
    const { pixels: maskPixels } = mask;

    // 3. 严格通道混合：注入 Alpha 通道
    for (let i = 0; i < targetPixels.length; i += 4) {
      targetPixels[i + 3] = maskPixels[i + 3]; // 覆盖 Alpha 通道
    }

    // 4. 二进制无损编码
    const newPngBuf = UPNG.encode([targetPixels.buffer], width, height, 0);

    return new Blob([newPngBuf], { type: "image/png" });
  } catch (error) {
    console.error("[BizyDraft] 高级合并处理失败:", error);
    throw error;
  }
}

// 拦截 XMLHttpRequest
window.XMLHttpRequest = function () {
  const xhr = new OriginalXHR();
  const originalOpen = xhr.open;
  const originalSend = xhr.send;
  let requestUrl = "";
  let requestMethod = "";

  xhr.open = function (method, url, ...args) {
    requestUrl = typeof url === "string" ? url : url.toString();
    requestMethod = method.toUpperCase();
    return originalOpen.apply(xhr, [method, url, ...args]);
  };

  xhr.send = function (body) {
    // 检查是否在跳过列表中
    if (shouldInterceptUrl(requestUrl, skipFetchUrls)) {
      console.warn("[BizyDraft] 已阻止 XHR 请求:", requestUrl);
      setTimeout(() => mockXHRResponse(xhr, ""), 0);
      return;
    }

    // 检查是否是上传路由
    if (
      shouldInterceptUrl(requestUrl, uploadRoutes) &&
      requestMethod === "POST" &&
      body instanceof FormData
    ) {
      console.log("[BizyDraft] 拦截 XHR 上传请求，转发到 OSS:", requestUrl);

      (async () => {
        try {
          const result = await handleUploadRequest(requestUrl, body);
          mockXHRResponse(xhr, result);
        } catch (error) {
          console.error("[BizyDraft] OSS 上传失败 (XHR):", error);
          originalSend.call(xhr, body);
        }
      })();

      return;
    }

    // 其他请求正常发送
    return originalSend.apply(xhr, arguments);
  };

  return xhr;
};

// 保留 XMLHttpRequest 的静态属性和原型
Object.setPrototypeOf(window.XMLHttpRequest, OriginalXHR);
window.XMLHttpRequest.prototype = OriginalXHR.prototype;
