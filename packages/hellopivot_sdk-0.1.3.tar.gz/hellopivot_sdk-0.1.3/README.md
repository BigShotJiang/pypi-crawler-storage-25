# hellopivot-sdk

Official Python SDK for the Pivot REST API.

This SDK is generated from the Pivot REST OpenAPI specification with
[`openapi-python-client`](https://github.com/openapi-generators/openapi-python-client).
Nearly all request/response models and endpoint functions are generated.

## Installation

```bash
pip install hellopivot-sdk
```

## Quick start

```python
import os

from hellopivot_sdk import AuthenticatedClient
from hellopivot_sdk.api.spaces import get_spaces_by_organization_id

client = AuthenticatedClient(
    base_url="https://api.pivot.app",
    token=os.environ["PIVOT_API_KEY"],
)

with client as authenticated_client:
    response = get_spaces_by_organization_id.sync(
        organization_id="your-org-id",
        offset=0,
        client=authenticated_client,
    )
    print(response)
```

## Development

This project uses [uv](https://docs.astral.sh/uv/) for dependency management and
packaging.

```bash
uv sync --group dev
uv run --group dev ruff check --select I .
uv run --group dev pytest
uv build
```
