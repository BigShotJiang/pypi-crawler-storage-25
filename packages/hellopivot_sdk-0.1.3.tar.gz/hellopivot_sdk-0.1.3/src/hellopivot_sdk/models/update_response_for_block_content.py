from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rich_content import RichContent


T = TypeVar("T", bound="UpdateResponseForBlockContent")


@_attrs_define
class UpdateResponseForBlockContent:
    """
    Attributes:
        rich_content (RichContent):
    """

    rich_content: RichContent
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rich_content import RichContent

        rich_content = self.rich_content.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "richContent": rich_content,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rich_content import RichContent

        d = dict(src_dict)
        rich_content = RichContent.from_dict(d.pop("richContent"))

        update_response_for_block_content = cls(
            rich_content=rich_content,
        )

        update_response_for_block_content.additional_properties = d
        return update_response_for_block_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
