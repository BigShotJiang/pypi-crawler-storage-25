from enum import Enum


class AssetType(str, Enum):
    ASSET_TYPE_TRANSCRIPT = "ASSET_TYPE_TRANSCRIPT"
    ASSET_TYPE_UNSPECIFIED = "ASSET_TYPE_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
