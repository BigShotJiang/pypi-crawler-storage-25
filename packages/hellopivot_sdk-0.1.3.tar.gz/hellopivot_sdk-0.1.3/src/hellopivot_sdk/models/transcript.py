from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chapter import Chapter
    from ..models.sentence import Sentence


T = TypeVar("T", bound="Transcript")


@_attrs_define
class Transcript:
    """
    Attributes:
        text (str | Unset):
        completed_at (datetime.datetime | Unset):
        duration (float | Unset):
        confidence (float | Unset):
        sentences (list[Sentence] | Unset):
        chapters (list[Chapter] | Unset):
    """

    text: str | Unset = UNSET
    completed_at: datetime.datetime | Unset = UNSET
    duration: float | Unset = UNSET
    confidence: float | Unset = UNSET
    sentences: list[Sentence] | Unset = UNSET
    chapters: list[Chapter] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.chapter import Chapter
        from ..models.sentence import Sentence

        text = self.text

        completed_at: str | Unset = UNSET
        if not isinstance(self.completed_at, Unset):
            completed_at = self.completed_at.isoformat()

        duration = self.duration

        confidence = self.confidence

        sentences: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.sentences, Unset):
            sentences = []
            for sentences_item_data in self.sentences:
                sentences_item = sentences_item_data.to_dict()
                sentences.append(sentences_item)

        chapters: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.chapters, Unset):
            chapters = []
            for chapters_item_data in self.chapters:
                chapters_item = chapters_item_data.to_dict()
                chapters.append(chapters_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if text is not UNSET:
            field_dict["text"] = text
        if completed_at is not UNSET:
            field_dict["completedAt"] = completed_at
        if duration is not UNSET:
            field_dict["duration"] = duration
        if confidence is not UNSET:
            field_dict["confidence"] = confidence
        if sentences is not UNSET:
            field_dict["sentences"] = sentences
        if chapters is not UNSET:
            field_dict["chapters"] = chapters

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chapter import Chapter
        from ..models.sentence import Sentence

        d = dict(src_dict)
        text = d.pop("text", UNSET)

        _completed_at = d.pop("completedAt", UNSET)
        completed_at: datetime.datetime | Unset
        if isinstance(_completed_at, Unset):
            completed_at = UNSET
        else:
            completed_at = isoparse(_completed_at)

        duration = d.pop("duration", UNSET)

        confidence = d.pop("confidence", UNSET)

        _sentences = d.pop("sentences", UNSET)
        sentences: list[Sentence] | Unset = UNSET
        if _sentences is not UNSET:
            sentences = []
            for sentences_item_data in _sentences:
                sentences_item = Sentence.from_dict(sentences_item_data)

                sentences.append(sentences_item)

        _chapters = d.pop("chapters", UNSET)
        chapters: list[Chapter] | Unset = UNSET
        if _chapters is not UNSET:
            chapters = []
            for chapters_item_data in _chapters:
                chapters_item = Chapter.from_dict(chapters_item_data)

                chapters.append(chapters_item)

        transcript = cls(
            text=text,
            completed_at=completed_at,
            duration=duration,
            confidence=confidence,
            sentences=sentences,
            chapters=chapters,
        )

        transcript.additional_properties = d
        return transcript

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
