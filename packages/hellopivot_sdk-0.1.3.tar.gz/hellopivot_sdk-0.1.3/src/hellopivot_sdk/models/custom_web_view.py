from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.custom_web_view_open_style import CustomWebViewOpenStyle
from ..models.custom_web_view_status import CustomWebViewStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="CustomWebView")


@_attrs_define
class CustomWebView:
    """
    Attributes:
        id (str | Unset):
        url (str | Unset):
        display_name (str | Unset):
        icon (str | Unset):
        status (CustomWebViewStatus | Unset):
        open_style (CustomWebViewOpenStyle | Unset):
        group_id (str | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        deleted_at (datetime.datetime | Unset):
    """

    id: str | Unset = UNSET
    url: str | Unset = UNSET
    display_name: str | Unset = UNSET
    icon: str | Unset = UNSET
    status: CustomWebViewStatus | Unset = UNSET
    open_style: CustomWebViewOpenStyle | Unset = UNSET
    group_id: str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    deleted_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        url = self.url

        display_name = self.display_name

        icon = self.icon

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        open_style: str | Unset = UNSET
        if not isinstance(self.open_style, Unset):
            open_style = self.open_style.value

        group_id = self.group_id

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        deleted_at: str | Unset = UNSET
        if not isinstance(self.deleted_at, Unset):
            deleted_at = self.deleted_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if url is not UNSET:
            field_dict["url"] = url
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if icon is not UNSET:
            field_dict["icon"] = icon
        if status is not UNSET:
            field_dict["status"] = status
        if open_style is not UNSET:
            field_dict["openStyle"] = open_style
        if group_id is not UNSET:
            field_dict["groupId"] = group_id
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if deleted_at is not UNSET:
            field_dict["deletedAt"] = deleted_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        url = d.pop("url", UNSET)

        display_name = d.pop("displayName", UNSET)

        icon = d.pop("icon", UNSET)

        _status = d.pop("status", UNSET)
        status: CustomWebViewStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = CustomWebViewStatus(_status)

        _open_style = d.pop("openStyle", UNSET)
        open_style: CustomWebViewOpenStyle | Unset
        if isinstance(_open_style, Unset):
            open_style = UNSET
        else:
            open_style = CustomWebViewOpenStyle(_open_style)

        group_id = d.pop("groupId", UNSET)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _deleted_at = d.pop("deletedAt", UNSET)
        deleted_at: datetime.datetime | Unset
        if isinstance(_deleted_at, Unset):
            deleted_at = UNSET
        else:
            deleted_at = isoparse(_deleted_at)

        custom_web_view = cls(
            id=id,
            url=url,
            display_name=display_name,
            icon=icon,
            status=status,
            open_style=open_style,
            group_id=group_id,
            created_at=created_at,
            updated_at=updated_at,
            deleted_at=deleted_at,
        )

        custom_web_view.additional_properties = d
        return custom_web_view

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
