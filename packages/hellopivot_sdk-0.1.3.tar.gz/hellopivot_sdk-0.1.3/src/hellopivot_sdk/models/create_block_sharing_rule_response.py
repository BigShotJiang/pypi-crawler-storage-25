from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.block_sharing_rule import BlockSharingRule


T = TypeVar("T", bound="CreateBlockSharingRuleResponse")


@_attrs_define
class CreateBlockSharingRuleResponse:
    """
    Attributes:
        sharing_rule (BlockSharingRule | Unset):
    """

    sharing_rule: BlockSharingRule | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.block_sharing_rule import BlockSharingRule

        sharing_rule: dict[str, Any] | Unset = UNSET
        if not isinstance(self.sharing_rule, Unset):
            sharing_rule = self.sharing_rule.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if sharing_rule is not UNSET:
            field_dict["sharingRule"] = sharing_rule

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.block_sharing_rule import BlockSharingRule

        d = dict(src_dict)
        _sharing_rule = d.pop("sharingRule", UNSET)
        sharing_rule: BlockSharingRule | Unset
        if isinstance(_sharing_rule, Unset):
            sharing_rule = UNSET
        else:
            sharing_rule = BlockSharingRule.from_dict(_sharing_rule)

        create_block_sharing_rule_response = cls(
            sharing_rule=sharing_rule,
        )

        create_block_sharing_rule_response.additional_properties = d
        return create_block_sharing_rule_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
