from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="MemberView")


@_attrs_define
class MemberView:
    """
    Attributes:
        user_id (str | Unset):
        initials (str | Unset):
        profile_picture_url (str | Unset):
        is_integration_user (bool | Unset):
    """

    user_id: str | Unset = UNSET
    initials: str | Unset = UNSET
    profile_picture_url: str | Unset = UNSET
    is_integration_user: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        initials = self.initials

        profile_picture_url = self.profile_picture_url

        is_integration_user = self.is_integration_user

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if initials is not UNSET:
            field_dict["initials"] = initials
        if profile_picture_url is not UNSET:
            field_dict["profilePictureUrl"] = profile_picture_url
        if is_integration_user is not UNSET:
            field_dict["isIntegrationUser"] = is_integration_user

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("userId", UNSET)

        initials = d.pop("initials", UNSET)

        profile_picture_url = d.pop("profilePictureUrl", UNSET)

        is_integration_user = d.pop("isIntegrationUser", UNSET)

        member_view = cls(
            user_id=user_id,
            initials=initials,
            profile_picture_url=profile_picture_url,
            is_integration_user=is_integration_user,
        )

        member_view.additional_properties = d
        return member_view

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
