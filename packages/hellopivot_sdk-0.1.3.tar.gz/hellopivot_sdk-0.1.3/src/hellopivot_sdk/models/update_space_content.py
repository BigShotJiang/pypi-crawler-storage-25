from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_space_content_link_sharing import UpdateSpaceContentLinkSharing
from ..models.update_space_content_organization_sharing import UpdateSpaceContentOrganizationSharing
from ..models.update_space_content_public_sharing import UpdateSpaceContentPublicSharing
from ..models.update_space_content_type import UpdateSpaceContentType
from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateSpaceContent")


@_attrs_define
class UpdateSpaceContent:
    """
    Attributes:
        name (str | Unset):
        organization_sharing (UpdateSpaceContentOrganizationSharing | Unset):
        link_sharing (UpdateSpaceContentLinkSharing | Unset):
        public_sharing (UpdateSpaceContentPublicSharing | Unset):
        type_ (UpdateSpaceContentType | Unset):
        other_type_name (str | Unset):
        tags (list[str] | Unset):
        template_type (str | Unset):
        icon_name (str | Unset):
        enable_progress_tracking (bool | Unset):
        only_allow_existing_organization_members (bool | Unset):
        allow_block_sharing_organization_members (bool | Unset):
        allow_block_sharing_public (bool | Unset):
        allow_block_sharing_users (bool | Unset):
        cover_photo_x_offset (int | Unset):
        cover_photo_y_offset (int | Unset):
        default_space_role_id (str | Unset):
    """

    name: str | Unset = UNSET
    organization_sharing: UpdateSpaceContentOrganizationSharing | Unset = UNSET
    link_sharing: UpdateSpaceContentLinkSharing | Unset = UNSET
    public_sharing: UpdateSpaceContentPublicSharing | Unset = UNSET
    type_: UpdateSpaceContentType | Unset = UNSET
    other_type_name: str | Unset = UNSET
    tags: list[str] | Unset = UNSET
    template_type: str | Unset = UNSET
    icon_name: str | Unset = UNSET
    enable_progress_tracking: bool | Unset = UNSET
    only_allow_existing_organization_members: bool | Unset = UNSET
    allow_block_sharing_organization_members: bool | Unset = UNSET
    allow_block_sharing_public: bool | Unset = UNSET
    allow_block_sharing_users: bool | Unset = UNSET
    cover_photo_x_offset: int | Unset = UNSET
    cover_photo_y_offset: int | Unset = UNSET
    default_space_role_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        organization_sharing: str | Unset = UNSET
        if not isinstance(self.organization_sharing, Unset):
            organization_sharing = self.organization_sharing.value

        link_sharing: str | Unset = UNSET
        if not isinstance(self.link_sharing, Unset):
            link_sharing = self.link_sharing.value

        public_sharing: str | Unset = UNSET
        if not isinstance(self.public_sharing, Unset):
            public_sharing = self.public_sharing.value

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        other_type_name = self.other_type_name

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        template_type = self.template_type

        icon_name = self.icon_name

        enable_progress_tracking = self.enable_progress_tracking

        only_allow_existing_organization_members = self.only_allow_existing_organization_members

        allow_block_sharing_organization_members = self.allow_block_sharing_organization_members

        allow_block_sharing_public = self.allow_block_sharing_public

        allow_block_sharing_users = self.allow_block_sharing_users

        cover_photo_x_offset = self.cover_photo_x_offset

        cover_photo_y_offset = self.cover_photo_y_offset

        default_space_role_id = self.default_space_role_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if organization_sharing is not UNSET:
            field_dict["organizationSharing"] = organization_sharing
        if link_sharing is not UNSET:
            field_dict["linkSharing"] = link_sharing
        if public_sharing is not UNSET:
            field_dict["publicSharing"] = public_sharing
        if type_ is not UNSET:
            field_dict["type"] = type_
        if other_type_name is not UNSET:
            field_dict["otherTypeName"] = other_type_name
        if tags is not UNSET:
            field_dict["tags"] = tags
        if template_type is not UNSET:
            field_dict["templateType"] = template_type
        if icon_name is not UNSET:
            field_dict["iconName"] = icon_name
        if enable_progress_tracking is not UNSET:
            field_dict["enableProgressTracking"] = enable_progress_tracking
        if only_allow_existing_organization_members is not UNSET:
            field_dict["onlyAllowExistingOrganizationMembers"] = only_allow_existing_organization_members
        if allow_block_sharing_organization_members is not UNSET:
            field_dict["allowBlockSharingOrganizationMembers"] = allow_block_sharing_organization_members
        if allow_block_sharing_public is not UNSET:
            field_dict["allowBlockSharingPublic"] = allow_block_sharing_public
        if allow_block_sharing_users is not UNSET:
            field_dict["allowBlockSharingUsers"] = allow_block_sharing_users
        if cover_photo_x_offset is not UNSET:
            field_dict["coverPhotoXOffset"] = cover_photo_x_offset
        if cover_photo_y_offset is not UNSET:
            field_dict["coverPhotoYOffset"] = cover_photo_y_offset
        if default_space_role_id is not UNSET:
            field_dict["defaultSpaceRoleId"] = default_space_role_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        _organization_sharing = d.pop("organizationSharing", UNSET)
        organization_sharing: UpdateSpaceContentOrganizationSharing | Unset
        if isinstance(_organization_sharing, Unset):
            organization_sharing = UNSET
        else:
            organization_sharing = UpdateSpaceContentOrganizationSharing(_organization_sharing)

        _link_sharing = d.pop("linkSharing", UNSET)
        link_sharing: UpdateSpaceContentLinkSharing | Unset
        if isinstance(_link_sharing, Unset):
            link_sharing = UNSET
        else:
            link_sharing = UpdateSpaceContentLinkSharing(_link_sharing)

        _public_sharing = d.pop("publicSharing", UNSET)
        public_sharing: UpdateSpaceContentPublicSharing | Unset
        if isinstance(_public_sharing, Unset):
            public_sharing = UNSET
        else:
            public_sharing = UpdateSpaceContentPublicSharing(_public_sharing)

        _type_ = d.pop("type", UNSET)
        type_: UpdateSpaceContentType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = UpdateSpaceContentType(_type_)

        other_type_name = d.pop("otherTypeName", UNSET)

        tags = cast(list[str], d.pop("tags", UNSET))

        template_type = d.pop("templateType", UNSET)

        icon_name = d.pop("iconName", UNSET)

        enable_progress_tracking = d.pop("enableProgressTracking", UNSET)

        only_allow_existing_organization_members = d.pop("onlyAllowExistingOrganizationMembers", UNSET)

        allow_block_sharing_organization_members = d.pop("allowBlockSharingOrganizationMembers", UNSET)

        allow_block_sharing_public = d.pop("allowBlockSharingPublic", UNSET)

        allow_block_sharing_users = d.pop("allowBlockSharingUsers", UNSET)

        cover_photo_x_offset = d.pop("coverPhotoXOffset", UNSET)

        cover_photo_y_offset = d.pop("coverPhotoYOffset", UNSET)

        default_space_role_id = d.pop("defaultSpaceRoleId", UNSET)

        update_space_content = cls(
            name=name,
            organization_sharing=organization_sharing,
            link_sharing=link_sharing,
            public_sharing=public_sharing,
            type_=type_,
            other_type_name=other_type_name,
            tags=tags,
            template_type=template_type,
            icon_name=icon_name,
            enable_progress_tracking=enable_progress_tracking,
            only_allow_existing_organization_members=only_allow_existing_organization_members,
            allow_block_sharing_organization_members=allow_block_sharing_organization_members,
            allow_block_sharing_public=allow_block_sharing_public,
            allow_block_sharing_users=allow_block_sharing_users,
            cover_photo_x_offset=cover_photo_x_offset,
            cover_photo_y_offset=cover_photo_y_offset,
            default_space_role_id=default_space_role_id,
        )

        update_space_content.additional_properties = d
        return update_space_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
