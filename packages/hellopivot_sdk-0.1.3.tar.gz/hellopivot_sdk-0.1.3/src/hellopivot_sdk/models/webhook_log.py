from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="WebhookLog")


@_attrs_define
class WebhookLog:
    """
    Attributes:
        org_id (str | Unset):
        webhook_id (str | Unset):
        timestamp (str | Unset):
        event_type (str | Unset):
        subject (str | Unset):
        request_payload (str | Unset):
        response_status (int | Unset):
        response_body (str | Unset):
        success (bool | Unset):
        error_message (str | Unset):
        retry_count (int | Unset):
    """

    org_id: str | Unset = UNSET
    webhook_id: str | Unset = UNSET
    timestamp: str | Unset = UNSET
    event_type: str | Unset = UNSET
    subject: str | Unset = UNSET
    request_payload: str | Unset = UNSET
    response_status: int | Unset = UNSET
    response_body: str | Unset = UNSET
    success: bool | Unset = UNSET
    error_message: str | Unset = UNSET
    retry_count: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        org_id = self.org_id

        webhook_id = self.webhook_id

        timestamp = self.timestamp

        event_type = self.event_type

        subject = self.subject

        request_payload = self.request_payload

        response_status = self.response_status

        response_body = self.response_body

        success = self.success

        error_message = self.error_message

        retry_count = self.retry_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if org_id is not UNSET:
            field_dict["orgId"] = org_id
        if webhook_id is not UNSET:
            field_dict["webhookId"] = webhook_id
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if event_type is not UNSET:
            field_dict["eventType"] = event_type
        if subject is not UNSET:
            field_dict["subject"] = subject
        if request_payload is not UNSET:
            field_dict["requestPayload"] = request_payload
        if response_status is not UNSET:
            field_dict["responseStatus"] = response_status
        if response_body is not UNSET:
            field_dict["responseBody"] = response_body
        if success is not UNSET:
            field_dict["success"] = success
        if error_message is not UNSET:
            field_dict["errorMessage"] = error_message
        if retry_count is not UNSET:
            field_dict["retryCount"] = retry_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        org_id = d.pop("orgId", UNSET)

        webhook_id = d.pop("webhookId", UNSET)

        timestamp = d.pop("timestamp", UNSET)

        event_type = d.pop("eventType", UNSET)

        subject = d.pop("subject", UNSET)

        request_payload = d.pop("requestPayload", UNSET)

        response_status = d.pop("responseStatus", UNSET)

        response_body = d.pop("responseBody", UNSET)

        success = d.pop("success", UNSET)

        error_message = d.pop("errorMessage", UNSET)

        retry_count = d.pop("retryCount", UNSET)

        webhook_log = cls(
            org_id=org_id,
            webhook_id=webhook_id,
            timestamp=timestamp,
            event_type=event_type,
            subject=subject,
            request_payload=request_payload,
            response_status=response_status,
            response_body=response_body,
            success=success,
            error_message=error_message,
            retry_count=retry_count,
        )

        webhook_log.additional_properties = d
        return webhook_log

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
