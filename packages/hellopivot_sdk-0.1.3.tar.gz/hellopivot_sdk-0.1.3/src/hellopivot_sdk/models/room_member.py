from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.room_member_role import RoomMemberRole
from ..models.room_member_status import RoomMemberStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="RoomMember")


@_attrs_define
class RoomMember:
    """
    Attributes:
        id (str | Unset):
        room_id (str | Unset):
        user_id (str | Unset):
        status (RoomMemberStatus | Unset):
        role (RoomMemberRole | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        created_by_id (str | Unset):
        updated_by_id (str | Unset):
    """

    id: str | Unset = UNSET
    room_id: str | Unset = UNSET
    user_id: str | Unset = UNSET
    status: RoomMemberStatus | Unset = UNSET
    role: RoomMemberRole | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    created_by_id: str | Unset = UNSET
    updated_by_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        room_id = self.room_id

        user_id = self.user_id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        role: str | Unset = UNSET
        if not isinstance(self.role, Unset):
            role = self.role.value

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        created_by_id = self.created_by_id

        updated_by_id = self.updated_by_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if room_id is not UNSET:
            field_dict["roomId"] = room_id
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if status is not UNSET:
            field_dict["status"] = status
        if role is not UNSET:
            field_dict["role"] = role
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if created_by_id is not UNSET:
            field_dict["createdById"] = created_by_id
        if updated_by_id is not UNSET:
            field_dict["updatedById"] = updated_by_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        room_id = d.pop("roomId", UNSET)

        user_id = d.pop("userId", UNSET)

        _status = d.pop("status", UNSET)
        status: RoomMemberStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = RoomMemberStatus(_status)

        _role = d.pop("role", UNSET)
        role: RoomMemberRole | Unset
        if isinstance(_role, Unset):
            role = UNSET
        else:
            role = RoomMemberRole(_role)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        created_by_id = d.pop("createdById", UNSET)

        updated_by_id = d.pop("updatedById", UNSET)

        room_member = cls(
            id=id,
            room_id=room_id,
            user_id=user_id,
            status=status,
            role=role,
            created_at=created_at,
            updated_at=updated_at,
            created_by_id=created_by_id,
            updated_by_id=updated_by_id,
        )

        room_member.additional_properties = d
        return room_member

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
