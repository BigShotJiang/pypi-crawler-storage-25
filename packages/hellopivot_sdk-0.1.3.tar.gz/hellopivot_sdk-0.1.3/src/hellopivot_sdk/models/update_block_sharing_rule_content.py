from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_block_sharing_rule_content_rule import UpdateBlockSharingRuleContentRule
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rule_subject import RuleSubject


T = TypeVar("T", bound="UpdateBlockSharingRuleContent")


@_attrs_define
class UpdateBlockSharingRuleContent:
    """
    Attributes:
        subject (RuleSubject):
        rule (UpdateBlockSharingRuleContentRule):
    """

    subject: RuleSubject
    rule: UpdateBlockSharingRuleContentRule
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rule_subject import RuleSubject

        subject = self.subject.to_dict()

        rule = self.rule.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "subject": subject,
                "rule": rule,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rule_subject import RuleSubject

        d = dict(src_dict)
        subject = RuleSubject.from_dict(d.pop("subject"))

        rule = UpdateBlockSharingRuleContentRule(d.pop("rule"))

        update_block_sharing_rule_content = cls(
            subject=subject,
            rule=rule,
        )

        update_block_sharing_rule_content.additional_properties = d
        return update_block_sharing_rule_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
