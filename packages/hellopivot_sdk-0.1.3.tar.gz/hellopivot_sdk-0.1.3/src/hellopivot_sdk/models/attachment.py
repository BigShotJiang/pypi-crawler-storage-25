from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.attachment_mime_type import AttachmentMimeType
from ..models.attachment_type import AttachmentType
from ..types import UNSET, Unset

T = TypeVar("T", bound="Attachment")


@_attrs_define
class Attachment:
    """
    Attributes:
        id (str | Unset):
        file_id (str | Unset):
        file_url (str | Unset):
        display_name (str | Unset):
        type_ (AttachmentType | Unset):
        mime_type (AttachmentMimeType | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
    """

    id: str | Unset = UNSET
    file_id: str | Unset = UNSET
    file_url: str | Unset = UNSET
    display_name: str | Unset = UNSET
    type_: AttachmentType | Unset = UNSET
    mime_type: AttachmentMimeType | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        file_id = self.file_id

        file_url = self.file_url

        display_name = self.display_name

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        mime_type: str | Unset = UNSET
        if not isinstance(self.mime_type, Unset):
            mime_type = self.mime_type.value

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if file_id is not UNSET:
            field_dict["fileId"] = file_id
        if file_url is not UNSET:
            field_dict["fileUrl"] = file_url
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if type_ is not UNSET:
            field_dict["type"] = type_
        if mime_type is not UNSET:
            field_dict["mimeType"] = mime_type
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        file_id = d.pop("fileId", UNSET)

        file_url = d.pop("fileUrl", UNSET)

        display_name = d.pop("displayName", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: AttachmentType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = AttachmentType(_type_)

        _mime_type = d.pop("mimeType", UNSET)
        mime_type: AttachmentMimeType | Unset
        if isinstance(_mime_type, Unset):
            mime_type = UNSET
        else:
            mime_type = AttachmentMimeType(_mime_type)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        attachment = cls(
            id=id,
            file_id=file_id,
            file_url=file_url,
            display_name=display_name,
            type_=type_,
            mime_type=mime_type,
            created_at=created_at,
            updated_at=updated_at,
        )

        attachment.additional_properties = d
        return attachment

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
