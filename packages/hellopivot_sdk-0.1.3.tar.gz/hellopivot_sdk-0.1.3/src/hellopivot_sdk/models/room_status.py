from enum import Enum


class RoomStatus(str, Enum):
    ROOM_STATUS_ACTIVE = "ROOM_STATUS_ACTIVE"
    ROOM_STATUS_ARCHIVED = "ROOM_STATUS_ARCHIVED"
    ROOM_STATUS_DELETED = "ROOM_STATUS_DELETED"
    ROOM_STATUS_UNSPECIFIED = "ROOM_STATUS_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
