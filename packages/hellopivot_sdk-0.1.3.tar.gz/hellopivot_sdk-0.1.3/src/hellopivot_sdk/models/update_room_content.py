from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_room_content_room_type import UpdateRoomContentRoomType
from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateRoomContent")


@_attrs_define
class UpdateRoomContent:
    """
    Attributes:
        name (str | Unset):
        topic (str | Unset):
        room_type (UpdateRoomContentRoomType | Unset):
        hide_recording_by_default (bool | Unset):
        record_automatically (bool | Unset):
        hide_recording_transcript (bool | Unset):
        allow_recording_download (bool | Unset):
    """

    name: str | Unset = UNSET
    topic: str | Unset = UNSET
    room_type: UpdateRoomContentRoomType | Unset = UNSET
    hide_recording_by_default: bool | Unset = UNSET
    record_automatically: bool | Unset = UNSET
    hide_recording_transcript: bool | Unset = UNSET
    allow_recording_download: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        topic = self.topic

        room_type: str | Unset = UNSET
        if not isinstance(self.room_type, Unset):
            room_type = self.room_type.value

        hide_recording_by_default = self.hide_recording_by_default

        record_automatically = self.record_automatically

        hide_recording_transcript = self.hide_recording_transcript

        allow_recording_download = self.allow_recording_download

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if topic is not UNSET:
            field_dict["topic"] = topic
        if room_type is not UNSET:
            field_dict["roomType"] = room_type
        if hide_recording_by_default is not UNSET:
            field_dict["hideRecordingByDefault"] = hide_recording_by_default
        if record_automatically is not UNSET:
            field_dict["recordAutomatically"] = record_automatically
        if hide_recording_transcript is not UNSET:
            field_dict["hideRecordingTranscript"] = hide_recording_transcript
        if allow_recording_download is not UNSET:
            field_dict["allowRecordingDownload"] = allow_recording_download

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        topic = d.pop("topic", UNSET)

        _room_type = d.pop("roomType", UNSET)
        room_type: UpdateRoomContentRoomType | Unset
        if isinstance(_room_type, Unset):
            room_type = UNSET
        else:
            room_type = UpdateRoomContentRoomType(_room_type)

        hide_recording_by_default = d.pop("hideRecordingByDefault", UNSET)

        record_automatically = d.pop("recordAutomatically", UNSET)

        hide_recording_transcript = d.pop("hideRecordingTranscript", UNSET)

        allow_recording_download = d.pop("allowRecordingDownload", UNSET)

        update_room_content = cls(
            name=name,
            topic=topic,
            room_type=room_type,
            hide_recording_by_default=hide_recording_by_default,
            record_automatically=record_automatically,
            hide_recording_transcript=hide_recording_transcript,
            allow_recording_download=allow_recording_download,
        )

        update_room_content.additional_properties = d
        return update_room_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
