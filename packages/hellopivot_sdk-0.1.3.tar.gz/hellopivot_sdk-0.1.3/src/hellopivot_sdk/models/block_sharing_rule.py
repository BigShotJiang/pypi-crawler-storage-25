from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.block_sharing_rule_rule import BlockSharingRuleRule
from ..models.block_sharing_rule_status import BlockSharingRuleStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rule_subject import RuleSubject


T = TypeVar("T", bound="BlockSharingRule")


@_attrs_define
class BlockSharingRule:
    """
    Attributes:
        id (str | Unset):
        subject (RuleSubject | Unset):
        rule (BlockSharingRuleRule | Unset):
        status (BlockSharingRuleStatus | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        created_by_id (str | Unset):
        updated_by_id (str | Unset):
        block_id (str | Unset):
    """

    id: str | Unset = UNSET
    subject: RuleSubject | Unset = UNSET
    rule: BlockSharingRuleRule | Unset = UNSET
    status: BlockSharingRuleStatus | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    created_by_id: str | Unset = UNSET
    updated_by_id: str | Unset = UNSET
    block_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rule_subject import RuleSubject

        id = self.id

        subject: dict[str, Any] | Unset = UNSET
        if not isinstance(self.subject, Unset):
            subject = self.subject.to_dict()

        rule: str | Unset = UNSET
        if not isinstance(self.rule, Unset):
            rule = self.rule.value

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        created_by_id = self.created_by_id

        updated_by_id = self.updated_by_id

        block_id = self.block_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if subject is not UNSET:
            field_dict["subject"] = subject
        if rule is not UNSET:
            field_dict["rule"] = rule
        if status is not UNSET:
            field_dict["status"] = status
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if created_by_id is not UNSET:
            field_dict["createdById"] = created_by_id
        if updated_by_id is not UNSET:
            field_dict["updatedById"] = updated_by_id
        if block_id is not UNSET:
            field_dict["blockId"] = block_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rule_subject import RuleSubject

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        _subject = d.pop("subject", UNSET)
        subject: RuleSubject | Unset
        if isinstance(_subject, Unset):
            subject = UNSET
        else:
            subject = RuleSubject.from_dict(_subject)

        _rule = d.pop("rule", UNSET)
        rule: BlockSharingRuleRule | Unset
        if isinstance(_rule, Unset):
            rule = UNSET
        else:
            rule = BlockSharingRuleRule(_rule)

        _status = d.pop("status", UNSET)
        status: BlockSharingRuleStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = BlockSharingRuleStatus(_status)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        created_by_id = d.pop("createdById", UNSET)

        updated_by_id = d.pop("updatedById", UNSET)

        block_id = d.pop("blockId", UNSET)

        block_sharing_rule = cls(
            id=id,
            subject=subject,
            rule=rule,
            status=status,
            created_at=created_at,
            updated_at=updated_at,
            created_by_id=created_by_id,
            updated_by_id=updated_by_id,
            block_id=block_id,
        )

        block_sharing_rule.additional_properties = d
        return block_sharing_rule

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
