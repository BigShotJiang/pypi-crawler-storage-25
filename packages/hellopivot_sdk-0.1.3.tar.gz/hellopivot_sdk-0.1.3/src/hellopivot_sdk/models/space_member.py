from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.space_member_status import SpaceMemberStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="SpaceMember")


@_attrs_define
class SpaceMember:
    """
    Attributes:
        id (str | Unset):
        user_id (str | Unset):
        space_id (str | Unset):
        title (str | Unset):
        role_ids (list[str] | Unset):
        space_org_id (str | Unset):
        status (SpaceMemberStatus | Unset):
        space_membership_tier_id (str | Unset):
        wallstreet_subscription_id (str | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        last_seen_here_at (datetime.datetime | Unset):
        created_by_id (str | Unset):
        is_integration_user (bool | Unset):
        sponsoring_group_ids (list[str] | Unset):
        has_been_individually_customized (bool | Unset):
    """

    id: str | Unset = UNSET
    user_id: str | Unset = UNSET
    space_id: str | Unset = UNSET
    title: str | Unset = UNSET
    role_ids: list[str] | Unset = UNSET
    space_org_id: str | Unset = UNSET
    status: SpaceMemberStatus | Unset = UNSET
    space_membership_tier_id: str | Unset = UNSET
    wallstreet_subscription_id: str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    last_seen_here_at: datetime.datetime | Unset = UNSET
    created_by_id: str | Unset = UNSET
    is_integration_user: bool | Unset = UNSET
    sponsoring_group_ids: list[str] | Unset = UNSET
    has_been_individually_customized: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        user_id = self.user_id

        space_id = self.space_id

        title = self.title

        role_ids: list[str] | Unset = UNSET
        if not isinstance(self.role_ids, Unset):
            role_ids = self.role_ids

        space_org_id = self.space_org_id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        space_membership_tier_id = self.space_membership_tier_id

        wallstreet_subscription_id = self.wallstreet_subscription_id

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        last_seen_here_at: str | Unset = UNSET
        if not isinstance(self.last_seen_here_at, Unset):
            last_seen_here_at = self.last_seen_here_at.isoformat()

        created_by_id = self.created_by_id

        is_integration_user = self.is_integration_user

        sponsoring_group_ids: list[str] | Unset = UNSET
        if not isinstance(self.sponsoring_group_ids, Unset):
            sponsoring_group_ids = self.sponsoring_group_ids

        has_been_individually_customized = self.has_been_individually_customized

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if space_id is not UNSET:
            field_dict["spaceId"] = space_id
        if title is not UNSET:
            field_dict["title"] = title
        if role_ids is not UNSET:
            field_dict["roleIds"] = role_ids
        if space_org_id is not UNSET:
            field_dict["spaceOrgId"] = space_org_id
        if status is not UNSET:
            field_dict["status"] = status
        if space_membership_tier_id is not UNSET:
            field_dict["spaceMembershipTierId"] = space_membership_tier_id
        if wallstreet_subscription_id is not UNSET:
            field_dict["wallstreetSubscriptionId"] = wallstreet_subscription_id
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if last_seen_here_at is not UNSET:
            field_dict["lastSeenHereAt"] = last_seen_here_at
        if created_by_id is not UNSET:
            field_dict["createdById"] = created_by_id
        if is_integration_user is not UNSET:
            field_dict["isIntegrationUser"] = is_integration_user
        if sponsoring_group_ids is not UNSET:
            field_dict["sponsoringGroupIds"] = sponsoring_group_ids
        if has_been_individually_customized is not UNSET:
            field_dict["hasBeenIndividuallyCustomized"] = has_been_individually_customized

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        user_id = d.pop("userId", UNSET)

        space_id = d.pop("spaceId", UNSET)

        title = d.pop("title", UNSET)

        role_ids = cast(list[str], d.pop("roleIds", UNSET))

        space_org_id = d.pop("spaceOrgId", UNSET)

        _status = d.pop("status", UNSET)
        status: SpaceMemberStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = SpaceMemberStatus(_status)

        space_membership_tier_id = d.pop("spaceMembershipTierId", UNSET)

        wallstreet_subscription_id = d.pop("wallstreetSubscriptionId", UNSET)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _last_seen_here_at = d.pop("lastSeenHereAt", UNSET)
        last_seen_here_at: datetime.datetime | Unset
        if isinstance(_last_seen_here_at, Unset):
            last_seen_here_at = UNSET
        else:
            last_seen_here_at = isoparse(_last_seen_here_at)

        created_by_id = d.pop("createdById", UNSET)

        is_integration_user = d.pop("isIntegrationUser", UNSET)

        sponsoring_group_ids = cast(list[str], d.pop("sponsoringGroupIds", UNSET))

        has_been_individually_customized = d.pop("hasBeenIndividuallyCustomized", UNSET)

        space_member = cls(
            id=id,
            user_id=user_id,
            space_id=space_id,
            title=title,
            role_ids=role_ids,
            space_org_id=space_org_id,
            status=status,
            space_membership_tier_id=space_membership_tier_id,
            wallstreet_subscription_id=wallstreet_subscription_id,
            created_at=created_at,
            updated_at=updated_at,
            last_seen_here_at=last_seen_here_at,
            created_by_id=created_by_id,
            is_integration_user=is_integration_user,
            sponsoring_group_ids=sponsoring_group_ids,
            has_been_individually_customized=has_been_individually_customized,
        )

        space_member.additional_properties = d
        return space_member

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
