from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="RoomInvitation")


@_attrs_define
class RoomInvitation:
    """
    Attributes:
        room_id (str | Unset):
        room_role (str | Unset):
        email (str | Unset):
        room_invite_created_by_id (str | Unset):
        room_invite_updated_by_id (str | Unset):
        room_invite_created_at (datetime.datetime | Unset):
        room_invite_updated_at (datetime.datetime | Unset):
    """

    room_id: str | Unset = UNSET
    room_role: str | Unset = UNSET
    email: str | Unset = UNSET
    room_invite_created_by_id: str | Unset = UNSET
    room_invite_updated_by_id: str | Unset = UNSET
    room_invite_created_at: datetime.datetime | Unset = UNSET
    room_invite_updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        room_id = self.room_id

        room_role = self.room_role

        email = self.email

        room_invite_created_by_id = self.room_invite_created_by_id

        room_invite_updated_by_id = self.room_invite_updated_by_id

        room_invite_created_at: str | Unset = UNSET
        if not isinstance(self.room_invite_created_at, Unset):
            room_invite_created_at = self.room_invite_created_at.isoformat()

        room_invite_updated_at: str | Unset = UNSET
        if not isinstance(self.room_invite_updated_at, Unset):
            room_invite_updated_at = self.room_invite_updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if room_id is not UNSET:
            field_dict["roomId"] = room_id
        if room_role is not UNSET:
            field_dict["roomRole"] = room_role
        if email is not UNSET:
            field_dict["email"] = email
        if room_invite_created_by_id is not UNSET:
            field_dict["roomInviteCreatedById"] = room_invite_created_by_id
        if room_invite_updated_by_id is not UNSET:
            field_dict["roomInviteUpdatedById"] = room_invite_updated_by_id
        if room_invite_created_at is not UNSET:
            field_dict["roomInviteCreatedAt"] = room_invite_created_at
        if room_invite_updated_at is not UNSET:
            field_dict["roomInviteUpdatedAt"] = room_invite_updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        room_id = d.pop("roomId", UNSET)

        room_role = d.pop("roomRole", UNSET)

        email = d.pop("email", UNSET)

        room_invite_created_by_id = d.pop("roomInviteCreatedById", UNSET)

        room_invite_updated_by_id = d.pop("roomInviteUpdatedById", UNSET)

        _room_invite_created_at = d.pop("roomInviteCreatedAt", UNSET)
        room_invite_created_at: datetime.datetime | Unset
        if isinstance(_room_invite_created_at, Unset):
            room_invite_created_at = UNSET
        else:
            room_invite_created_at = isoparse(_room_invite_created_at)

        _room_invite_updated_at = d.pop("roomInviteUpdatedAt", UNSET)
        room_invite_updated_at: datetime.datetime | Unset
        if isinstance(_room_invite_updated_at, Unset):
            room_invite_updated_at = UNSET
        else:
            room_invite_updated_at = isoparse(_room_invite_updated_at)

        room_invitation = cls(
            room_id=room_id,
            room_role=room_role,
            email=email,
            room_invite_created_by_id=room_invite_created_by_id,
            room_invite_updated_by_id=room_invite_updated_by_id,
            room_invite_created_at=room_invite_created_at,
            room_invite_updated_at=room_invite_updated_at,
        )

        room_invitation.additional_properties = d
        return room_invitation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
