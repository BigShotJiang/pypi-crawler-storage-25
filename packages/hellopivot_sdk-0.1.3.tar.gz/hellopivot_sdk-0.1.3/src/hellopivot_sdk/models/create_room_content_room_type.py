from enum import Enum


class CreateRoomContentRoomType(str, Enum):
    ROOM_TYPE_AUDIO = "ROOM_TYPE_AUDIO"
    ROOM_TYPE_CHAT = "ROOM_TYPE_CHAT"
    ROOM_TYPE_DIRECT = "ROOM_TYPE_DIRECT"
    ROOM_TYPE_POST = "ROOM_TYPE_POST"
    ROOM_TYPE_STREAMING = "ROOM_TYPE_STREAMING"
    ROOM_TYPE_UNSPECIFIED = "ROOM_TYPE_UNSPECIFIED"
    ROOM_TYPE_VIDEO = "ROOM_TYPE_VIDEO"

    def __str__(self) -> str:
        return str(self.value)
