from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.block_sharing_rule import BlockSharingRule


T = TypeVar("T", bound="GetSharingRulesByBlockIdResponse")


@_attrs_define
class GetSharingRulesByBlockIdResponse:
    """
    Attributes:
        sharing_rules (list[BlockSharingRule] | Unset):
    """

    sharing_rules: list[BlockSharingRule] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.block_sharing_rule import BlockSharingRule

        sharing_rules: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.sharing_rules, Unset):
            sharing_rules = []
            for sharing_rules_item_data in self.sharing_rules:
                sharing_rules_item = sharing_rules_item_data.to_dict()
                sharing_rules.append(sharing_rules_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if sharing_rules is not UNSET:
            field_dict["sharingRules"] = sharing_rules

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.block_sharing_rule import BlockSharingRule

        d = dict(src_dict)
        _sharing_rules = d.pop("sharingRules", UNSET)
        sharing_rules: list[BlockSharingRule] | Unset = UNSET
        if _sharing_rules is not UNSET:
            sharing_rules = []
            for sharing_rules_item_data in _sharing_rules:
                sharing_rules_item = BlockSharingRule.from_dict(sharing_rules_item_data)

                sharing_rules.append(sharing_rules_item)

        get_sharing_rules_by_block_id_response = cls(
            sharing_rules=sharing_rules,
        )

        get_sharing_rules_by_block_id_response.additional_properties = d
        return get_sharing_rules_by_block_id_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
