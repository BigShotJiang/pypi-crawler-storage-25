from enum import Enum


class MessageType(str, Enum):
    MESSAGE_TYPE_AUDIO_CALL = "MESSAGE_TYPE_AUDIO_CALL"
    MESSAGE_TYPE_UNSPECIFIED = "MESSAGE_TYPE_UNSPECIFIED"
    MESSAGE_TYPE_VIDEO_CALL = "MESSAGE_TYPE_VIDEO_CALL"

    def __str__(self) -> str:
        return str(self.value)
