from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.webhook_subscription_input import WebhookSubscriptionInput


T = TypeVar("T", bound="CreateWebhookContent")


@_attrs_define
class CreateWebhookContent:
    """
    Attributes:
        name (str):
        endpoint_url (str):
        subscriptions (list[WebhookSubscriptionInput]):
        description (str | Unset):
    """

    name: str
    endpoint_url: str
    subscriptions: list[WebhookSubscriptionInput]
    description: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.webhook_subscription_input import WebhookSubscriptionInput

        name = self.name

        endpoint_url = self.endpoint_url

        subscriptions = []
        for subscriptions_item_data in self.subscriptions:
            subscriptions_item = subscriptions_item_data.to_dict()
            subscriptions.append(subscriptions_item)

        description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "endpointUrl": endpoint_url,
                "subscriptions": subscriptions,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.webhook_subscription_input import WebhookSubscriptionInput

        d = dict(src_dict)
        name = d.pop("name")

        endpoint_url = d.pop("endpointUrl")

        subscriptions = []
        _subscriptions = d.pop("subscriptions")
        for subscriptions_item_data in _subscriptions:
            subscriptions_item = WebhookSubscriptionInput.from_dict(subscriptions_item_data)

            subscriptions.append(subscriptions_item)

        description = d.pop("description", UNSET)

        create_webhook_content = cls(
            name=name,
            endpoint_url=endpoint_url,
            subscriptions=subscriptions,
            description=description,
        )

        create_webhook_content.additional_properties = d
        return create_webhook_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
