from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="RuleSubject")


@_attrs_define
class RuleSubject:
    """
    Attributes:
        user_id (str | Unset):
        group_id (str | Unset):
        space_role_id (str | Unset):
        space_membership_tier_id (str | Unset):
        space_id (str | Unset):
    """

    user_id: str | Unset = UNSET
    group_id: str | Unset = UNSET
    space_role_id: str | Unset = UNSET
    space_membership_tier_id: str | Unset = UNSET
    space_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        group_id = self.group_id

        space_role_id = self.space_role_id

        space_membership_tier_id = self.space_membership_tier_id

        space_id = self.space_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if group_id is not UNSET:
            field_dict["groupId"] = group_id
        if space_role_id is not UNSET:
            field_dict["spaceRoleId"] = space_role_id
        if space_membership_tier_id is not UNSET:
            field_dict["spaceMembershipTierId"] = space_membership_tier_id
        if space_id is not UNSET:
            field_dict["spaceId"] = space_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("userId", UNSET)

        group_id = d.pop("groupId", UNSET)

        space_role_id = d.pop("spaceRoleId", UNSET)

        space_membership_tier_id = d.pop("spaceMembershipTierId", UNSET)

        space_id = d.pop("spaceId", UNSET)

        rule_subject = cls(
            user_id=user_id,
            group_id=group_id,
            space_role_id=space_role_id,
            space_membership_tier_id=space_membership_tier_id,
            space_id=space_id,
        )

        rule_subject.additional_properties = d
        return rule_subject

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
