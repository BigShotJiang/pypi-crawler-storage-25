from enum import Enum


class GetSpacesByOrganizationIdStatus(str, Enum):
    ACTIVE = "active"
    ARCHIVED = "archived"
    DELETED = "deleted"
    HIDDEN = "hidden"

    def __str__(self) -> str:
        return str(self.value)
