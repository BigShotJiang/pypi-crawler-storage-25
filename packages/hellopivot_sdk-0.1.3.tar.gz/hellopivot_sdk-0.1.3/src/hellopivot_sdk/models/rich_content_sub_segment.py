from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rich_content_segment import RichContentSegment


T = TypeVar("T", bound="RichContentSubSegment")


@_attrs_define
class RichContentSubSegment:
    """
    Attributes:
        children (list[RichContentSegment] | Unset):
        detail (int | Unset):
        format_ (int | Unset):
        mode (str | Unset):
        style (str | Unset):
        text (str | Unset):
        type_ (str | Unset):
        mention_name (str | Unset):
        version (int | Unset):
        direction (str | Unset):
        indent (int | Unset):
        rel (str | Unset):
        target (str | Unset):
        title (str | Unset):
        url (str | Unset):
        list_type (str | Unset):
        start (int | Unset):
        tag (str | Unset):
        language (str | Unset):
        is_unlinked (bool | Unset):
        checked (bool | Unset):
        mention_user_id (str | Unset):
    """

    children: list[RichContentSegment] | Unset = UNSET
    detail: int | Unset = UNSET
    format_: int | Unset = UNSET
    mode: str | Unset = UNSET
    style: str | Unset = UNSET
    text: str | Unset = UNSET
    type_: str | Unset = UNSET
    mention_name: str | Unset = UNSET
    version: int | Unset = UNSET
    direction: str | Unset = UNSET
    indent: int | Unset = UNSET
    rel: str | Unset = UNSET
    target: str | Unset = UNSET
    title: str | Unset = UNSET
    url: str | Unset = UNSET
    list_type: str | Unset = UNSET
    start: int | Unset = UNSET
    tag: str | Unset = UNSET
    language: str | Unset = UNSET
    is_unlinked: bool | Unset = UNSET
    checked: bool | Unset = UNSET
    mention_user_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rich_content_segment import RichContentSegment

        children: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.children, Unset):
            children = []
            for children_item_data in self.children:
                children_item = children_item_data.to_dict()
                children.append(children_item)

        detail = self.detail

        format_ = self.format_

        mode = self.mode

        style = self.style

        text = self.text

        type_ = self.type_

        mention_name = self.mention_name

        version = self.version

        direction = self.direction

        indent = self.indent

        rel = self.rel

        target = self.target

        title = self.title

        url = self.url

        list_type = self.list_type

        start = self.start

        tag = self.tag

        language = self.language

        is_unlinked = self.is_unlinked

        checked = self.checked

        mention_user_id = self.mention_user_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if children is not UNSET:
            field_dict["children"] = children
        if detail is not UNSET:
            field_dict["detail"] = detail
        if format_ is not UNSET:
            field_dict["format"] = format_
        if mode is not UNSET:
            field_dict["mode"] = mode
        if style is not UNSET:
            field_dict["style"] = style
        if text is not UNSET:
            field_dict["text"] = text
        if type_ is not UNSET:
            field_dict["type"] = type_
        if mention_name is not UNSET:
            field_dict["mentionName"] = mention_name
        if version is not UNSET:
            field_dict["version"] = version
        if direction is not UNSET:
            field_dict["direction"] = direction
        if indent is not UNSET:
            field_dict["indent"] = indent
        if rel is not UNSET:
            field_dict["rel"] = rel
        if target is not UNSET:
            field_dict["target"] = target
        if title is not UNSET:
            field_dict["title"] = title
        if url is not UNSET:
            field_dict["url"] = url
        if list_type is not UNSET:
            field_dict["listType"] = list_type
        if start is not UNSET:
            field_dict["start"] = start
        if tag is not UNSET:
            field_dict["tag"] = tag
        if language is not UNSET:
            field_dict["language"] = language
        if is_unlinked is not UNSET:
            field_dict["isUnlinked"] = is_unlinked
        if checked is not UNSET:
            field_dict["checked"] = checked
        if mention_user_id is not UNSET:
            field_dict["mentionUserId"] = mention_user_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rich_content_segment import RichContentSegment

        d = dict(src_dict)
        _children = d.pop("children", UNSET)
        children: list[RichContentSegment] | Unset = UNSET
        if _children is not UNSET:
            children = []
            for children_item_data in _children:
                children_item = RichContentSegment.from_dict(children_item_data)

                children.append(children_item)

        detail = d.pop("detail", UNSET)

        format_ = d.pop("format", UNSET)

        mode = d.pop("mode", UNSET)

        style = d.pop("style", UNSET)

        text = d.pop("text", UNSET)

        type_ = d.pop("type", UNSET)

        mention_name = d.pop("mentionName", UNSET)

        version = d.pop("version", UNSET)

        direction = d.pop("direction", UNSET)

        indent = d.pop("indent", UNSET)

        rel = d.pop("rel", UNSET)

        target = d.pop("target", UNSET)

        title = d.pop("title", UNSET)

        url = d.pop("url", UNSET)

        list_type = d.pop("listType", UNSET)

        start = d.pop("start", UNSET)

        tag = d.pop("tag", UNSET)

        language = d.pop("language", UNSET)

        is_unlinked = d.pop("isUnlinked", UNSET)

        checked = d.pop("checked", UNSET)

        mention_user_id = d.pop("mentionUserId", UNSET)

        rich_content_sub_segment = cls(
            children=children,
            detail=detail,
            format_=format_,
            mode=mode,
            style=style,
            text=text,
            type_=type_,
            mention_name=mention_name,
            version=version,
            direction=direction,
            indent=indent,
            rel=rel,
            target=target,
            title=title,
            url=url,
            list_type=list_type,
            start=start,
            tag=tag,
            language=language,
            is_unlinked=is_unlinked,
            checked=checked,
            mention_user_id=mention_user_id,
        )

        rich_content_sub_segment.additional_properties = d
        return rich_content_sub_segment

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
