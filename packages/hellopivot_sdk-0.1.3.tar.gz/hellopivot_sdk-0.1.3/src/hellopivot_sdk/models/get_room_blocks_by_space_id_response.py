from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.block import Block
    from ..models.room_info import RoomInfo


T = TypeVar("T", bound="GetRoomBlocksBySpaceIdResponse")


@_attrs_define
class GetRoomBlocksBySpaceIdResponse:
    """
    Attributes:
        room_blocks (list[Block] | Unset):
        room_info (list[RoomInfo] | Unset):
    """

    room_blocks: list[Block] | Unset = UNSET
    room_info: list[RoomInfo] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.block import Block
        from ..models.room_info import RoomInfo

        room_blocks: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.room_blocks, Unset):
            room_blocks = []
            for room_blocks_item_data in self.room_blocks:
                room_blocks_item = room_blocks_item_data.to_dict()
                room_blocks.append(room_blocks_item)

        room_info: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.room_info, Unset):
            room_info = []
            for room_info_item_data in self.room_info:
                room_info_item = room_info_item_data.to_dict()
                room_info.append(room_info_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if room_blocks is not UNSET:
            field_dict["roomBlocks"] = room_blocks
        if room_info is not UNSET:
            field_dict["roomInfo"] = room_info

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.block import Block
        from ..models.room_info import RoomInfo

        d = dict(src_dict)
        _room_blocks = d.pop("roomBlocks", UNSET)
        room_blocks: list[Block] | Unset = UNSET
        if _room_blocks is not UNSET:
            room_blocks = []
            for room_blocks_item_data in _room_blocks:
                room_blocks_item = Block.from_dict(room_blocks_item_data)

                room_blocks.append(room_blocks_item)

        _room_info = d.pop("roomInfo", UNSET)
        room_info: list[RoomInfo] | Unset = UNSET
        if _room_info is not UNSET:
            room_info = []
            for room_info_item_data in _room_info:
                room_info_item = RoomInfo.from_dict(room_info_item_data)

                room_info.append(room_info_item)

        get_room_blocks_by_space_id_response = cls(
            room_blocks=room_blocks,
            room_info=room_info,
        )

        get_room_blocks_by_space_id_response.additional_properties = d
        return get_room_blocks_by_space_id_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
