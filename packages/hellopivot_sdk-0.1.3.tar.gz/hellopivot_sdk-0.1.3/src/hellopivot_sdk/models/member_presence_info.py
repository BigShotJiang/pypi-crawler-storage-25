from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.member_presence_info_state import MemberPresenceInfoState
from ..types import UNSET, Unset

T = TypeVar("T", bound="MemberPresenceInfo")


@_attrs_define
class MemberPresenceInfo:
    """
    Attributes:
        presence_id (str | Unset):
        user_id (str | Unset):
        name (str | Unset):
        state (MemberPresenceInfoState | Unset):
        joined_at (datetime.datetime | Unset):
    """

    presence_id: str | Unset = UNSET
    user_id: str | Unset = UNSET
    name: str | Unset = UNSET
    state: MemberPresenceInfoState | Unset = UNSET
    joined_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        presence_id = self.presence_id

        user_id = self.user_id

        name = self.name

        state: str | Unset = UNSET
        if not isinstance(self.state, Unset):
            state = self.state.value

        joined_at: str | Unset = UNSET
        if not isinstance(self.joined_at, Unset):
            joined_at = self.joined_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if presence_id is not UNSET:
            field_dict["presenceId"] = presence_id
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if name is not UNSET:
            field_dict["name"] = name
        if state is not UNSET:
            field_dict["state"] = state
        if joined_at is not UNSET:
            field_dict["joinedAt"] = joined_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        presence_id = d.pop("presenceId", UNSET)

        user_id = d.pop("userId", UNSET)

        name = d.pop("name", UNSET)

        _state = d.pop("state", UNSET)
        state: MemberPresenceInfoState | Unset
        if isinstance(_state, Unset):
            state = UNSET
        else:
            state = MemberPresenceInfoState(_state)

        _joined_at = d.pop("joinedAt", UNSET)
        joined_at: datetime.datetime | Unset
        if isinstance(_joined_at, Unset):
            joined_at = UNSET
        else:
            joined_at = isoparse(_joined_at)

        member_presence_info = cls(
            presence_id=presence_id,
            user_id=user_id,
            name=name,
            state=state,
            joined_at=joined_at,
        )

        member_presence_info.additional_properties = d
        return member_presence_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
