from enum import Enum


class CreateSpaceRoleContentType(str, Enum):
    SPACE_ROLE_TYPE_FULL = "SPACE_ROLE_TYPE_FULL"
    SPACE_ROLE_TYPE_GUEST = "SPACE_ROLE_TYPE_GUEST"
    SPACE_ROLE_TYPE_UNSPECIFIED = "SPACE_ROLE_TYPE_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
