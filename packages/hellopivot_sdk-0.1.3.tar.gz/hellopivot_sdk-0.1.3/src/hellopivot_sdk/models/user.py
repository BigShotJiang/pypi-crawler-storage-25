from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.user_status import UserStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user_email import UserEmail


T = TypeVar("T", bound="User")


@_attrs_define
class User:
    """
    Attributes:
        id (str | Unset):
        first_name (str | Unset):
        last_name (str | Unset):
        primary_email (str | Unset):
        emails (list[UserEmail] | Unset):
        username (str | Unset):
        status (UserStatus | Unset):
        profile_photo_file_id (str | Unset):
        profile_photo_url (str | Unset):
        profile_pronouns (str | Unset):
        profile_location (str | Unset):
        profile_about (str | Unset):
        timezone (str | Unset):
        integration_id (str | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        banned_at (datetime.datetime | Unset):
        deleted_at (datetime.datetime | Unset):
        presence_token (str | Unset):
    """

    id: str | Unset = UNSET
    first_name: str | Unset = UNSET
    last_name: str | Unset = UNSET
    primary_email: str | Unset = UNSET
    emails: list[UserEmail] | Unset = UNSET
    username: str | Unset = UNSET
    status: UserStatus | Unset = UNSET
    profile_photo_file_id: str | Unset = UNSET
    profile_photo_url: str | Unset = UNSET
    profile_pronouns: str | Unset = UNSET
    profile_location: str | Unset = UNSET
    profile_about: str | Unset = UNSET
    timezone: str | Unset = UNSET
    integration_id: str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    banned_at: datetime.datetime | Unset = UNSET
    deleted_at: datetime.datetime | Unset = UNSET
    presence_token: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.user_email import UserEmail

        id = self.id

        first_name = self.first_name

        last_name = self.last_name

        primary_email = self.primary_email

        emails: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.emails, Unset):
            emails = []
            for emails_item_data in self.emails:
                emails_item = emails_item_data.to_dict()
                emails.append(emails_item)

        username = self.username

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        profile_photo_file_id = self.profile_photo_file_id

        profile_photo_url = self.profile_photo_url

        profile_pronouns = self.profile_pronouns

        profile_location = self.profile_location

        profile_about = self.profile_about

        timezone = self.timezone

        integration_id = self.integration_id

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        banned_at: str | Unset = UNSET
        if not isinstance(self.banned_at, Unset):
            banned_at = self.banned_at.isoformat()

        deleted_at: str | Unset = UNSET
        if not isinstance(self.deleted_at, Unset):
            deleted_at = self.deleted_at.isoformat()

        presence_token = self.presence_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if first_name is not UNSET:
            field_dict["firstName"] = first_name
        if last_name is not UNSET:
            field_dict["lastName"] = last_name
        if primary_email is not UNSET:
            field_dict["primaryEmail"] = primary_email
        if emails is not UNSET:
            field_dict["emails"] = emails
        if username is not UNSET:
            field_dict["username"] = username
        if status is not UNSET:
            field_dict["status"] = status
        if profile_photo_file_id is not UNSET:
            field_dict["profilePhotoFileId"] = profile_photo_file_id
        if profile_photo_url is not UNSET:
            field_dict["profilePhotoUrl"] = profile_photo_url
        if profile_pronouns is not UNSET:
            field_dict["profilePronouns"] = profile_pronouns
        if profile_location is not UNSET:
            field_dict["profileLocation"] = profile_location
        if profile_about is not UNSET:
            field_dict["profileAbout"] = profile_about
        if timezone is not UNSET:
            field_dict["timezone"] = timezone
        if integration_id is not UNSET:
            field_dict["integrationId"] = integration_id
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if banned_at is not UNSET:
            field_dict["bannedAt"] = banned_at
        if deleted_at is not UNSET:
            field_dict["deletedAt"] = deleted_at
        if presence_token is not UNSET:
            field_dict["presenceToken"] = presence_token

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_email import UserEmail

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        first_name = d.pop("firstName", UNSET)

        last_name = d.pop("lastName", UNSET)

        primary_email = d.pop("primaryEmail", UNSET)

        _emails = d.pop("emails", UNSET)
        emails: list[UserEmail] | Unset = UNSET
        if _emails is not UNSET:
            emails = []
            for emails_item_data in _emails:
                emails_item = UserEmail.from_dict(emails_item_data)

                emails.append(emails_item)

        username = d.pop("username", UNSET)

        _status = d.pop("status", UNSET)
        status: UserStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = UserStatus(_status)

        profile_photo_file_id = d.pop("profilePhotoFileId", UNSET)

        profile_photo_url = d.pop("profilePhotoUrl", UNSET)

        profile_pronouns = d.pop("profilePronouns", UNSET)

        profile_location = d.pop("profileLocation", UNSET)

        profile_about = d.pop("profileAbout", UNSET)

        timezone = d.pop("timezone", UNSET)

        integration_id = d.pop("integrationId", UNSET)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _banned_at = d.pop("bannedAt", UNSET)
        banned_at: datetime.datetime | Unset
        if isinstance(_banned_at, Unset):
            banned_at = UNSET
        else:
            banned_at = isoparse(_banned_at)

        _deleted_at = d.pop("deletedAt", UNSET)
        deleted_at: datetime.datetime | Unset
        if isinstance(_deleted_at, Unset):
            deleted_at = UNSET
        else:
            deleted_at = isoparse(_deleted_at)

        presence_token = d.pop("presenceToken", UNSET)

        user = cls(
            id=id,
            first_name=first_name,
            last_name=last_name,
            primary_email=primary_email,
            emails=emails,
            username=username,
            status=status,
            profile_photo_file_id=profile_photo_file_id,
            profile_photo_url=profile_photo_url,
            profile_pronouns=profile_pronouns,
            profile_location=profile_location,
            profile_about=profile_about,
            timezone=timezone,
            integration_id=integration_id,
            created_at=created_at,
            updated_at=updated_at,
            banned_at=banned_at,
            deleted_at=deleted_at,
            presence_token=presence_token,
        )

        user.additional_properties = d
        return user

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
