from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_room_content_room_type import CreateRoomContentRoomType
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateRoomContent")


@_attrs_define
class CreateRoomContent:
    """
    Attributes:
        name (str):
        room_type (CreateRoomContentRoomType):
        topic (str | Unset):
        hide_recording_by_default (bool | Unset):
        record_automatically (bool | Unset):
        hide_recording_transcript (bool | Unset):
        allow_recording_download (bool | Unset):
    """

    name: str
    room_type: CreateRoomContentRoomType
    topic: str | Unset = UNSET
    hide_recording_by_default: bool | Unset = UNSET
    record_automatically: bool | Unset = UNSET
    hide_recording_transcript: bool | Unset = UNSET
    allow_recording_download: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        room_type = self.room_type.value

        topic = self.topic

        hide_recording_by_default = self.hide_recording_by_default

        record_automatically = self.record_automatically

        hide_recording_transcript = self.hide_recording_transcript

        allow_recording_download = self.allow_recording_download

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "roomType": room_type,
            }
        )
        if topic is not UNSET:
            field_dict["topic"] = topic
        if hide_recording_by_default is not UNSET:
            field_dict["hideRecordingByDefault"] = hide_recording_by_default
        if record_automatically is not UNSET:
            field_dict["recordAutomatically"] = record_automatically
        if hide_recording_transcript is not UNSET:
            field_dict["hideRecordingTranscript"] = hide_recording_transcript
        if allow_recording_download is not UNSET:
            field_dict["allowRecordingDownload"] = allow_recording_download

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        room_type = CreateRoomContentRoomType(d.pop("roomType"))

        topic = d.pop("topic", UNSET)

        hide_recording_by_default = d.pop("hideRecordingByDefault", UNSET)

        record_automatically = d.pop("recordAutomatically", UNSET)

        hide_recording_transcript = d.pop("hideRecordingTranscript", UNSET)

        allow_recording_download = d.pop("allowRecordingDownload", UNSET)

        create_room_content = cls(
            name=name,
            room_type=room_type,
            topic=topic,
            hide_recording_by_default=hide_recording_by_default,
            record_automatically=record_automatically,
            hide_recording_transcript=hide_recording_transcript,
            allow_recording_download=allow_recording_download,
        )

        create_room_content.additional_properties = d
        return create_room_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
