from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.message import Message


T = TypeVar("T", bound="GetRoomMessagesResponse")


@_attrs_define
class GetRoomMessagesResponse:
    """
    Attributes:
        messages (list[Message] | Unset):
        next_cursor_sent_at (datetime.datetime | Unset):
        next_cursor_message_id (str | Unset):
        shard_has_more (bool | Unset):
        next_partition_cursor (datetime.datetime | Unset): Always returned. Provides the timestamp to use as
            cursor_sent_at to query the next older partition.
             Calculated from the room-specific partitioning algorithm. Clients should use the room's
             created_at to determine when to stop querying older partitions.
    """

    messages: list[Message] | Unset = UNSET
    next_cursor_sent_at: datetime.datetime | Unset = UNSET
    next_cursor_message_id: str | Unset = UNSET
    shard_has_more: bool | Unset = UNSET
    next_partition_cursor: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.message import Message

        messages: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.messages, Unset):
            messages = []
            for messages_item_data in self.messages:
                messages_item = messages_item_data.to_dict()
                messages.append(messages_item)

        next_cursor_sent_at: str | Unset = UNSET
        if not isinstance(self.next_cursor_sent_at, Unset):
            next_cursor_sent_at = self.next_cursor_sent_at.isoformat()

        next_cursor_message_id = self.next_cursor_message_id

        shard_has_more = self.shard_has_more

        next_partition_cursor: str | Unset = UNSET
        if not isinstance(self.next_partition_cursor, Unset):
            next_partition_cursor = self.next_partition_cursor.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if messages is not UNSET:
            field_dict["messages"] = messages
        if next_cursor_sent_at is not UNSET:
            field_dict["nextCursorSentAt"] = next_cursor_sent_at
        if next_cursor_message_id is not UNSET:
            field_dict["nextCursorMessageId"] = next_cursor_message_id
        if shard_has_more is not UNSET:
            field_dict["shardHasMore"] = shard_has_more
        if next_partition_cursor is not UNSET:
            field_dict["nextPartitionCursor"] = next_partition_cursor

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message import Message

        d = dict(src_dict)
        _messages = d.pop("messages", UNSET)
        messages: list[Message] | Unset = UNSET
        if _messages is not UNSET:
            messages = []
            for messages_item_data in _messages:
                messages_item = Message.from_dict(messages_item_data)

                messages.append(messages_item)

        _next_cursor_sent_at = d.pop("nextCursorSentAt", UNSET)
        next_cursor_sent_at: datetime.datetime | Unset
        if isinstance(_next_cursor_sent_at, Unset):
            next_cursor_sent_at = UNSET
        else:
            next_cursor_sent_at = isoparse(_next_cursor_sent_at)

        next_cursor_message_id = d.pop("nextCursorMessageId", UNSET)

        shard_has_more = d.pop("shardHasMore", UNSET)

        _next_partition_cursor = d.pop("nextPartitionCursor", UNSET)
        next_partition_cursor: datetime.datetime | Unset
        if isinstance(_next_partition_cursor, Unset):
            next_partition_cursor = UNSET
        else:
            next_partition_cursor = isoparse(_next_partition_cursor)

        get_room_messages_response = cls(
            messages=messages,
            next_cursor_sent_at=next_cursor_sent_at,
            next_cursor_message_id=next_cursor_message_id,
            shard_has_more=shard_has_more,
            next_partition_cursor=next_partition_cursor,
        )

        get_room_messages_response.additional_properties = d
        return get_room_messages_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
