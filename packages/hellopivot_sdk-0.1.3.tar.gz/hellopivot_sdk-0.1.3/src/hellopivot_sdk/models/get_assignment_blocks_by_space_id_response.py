from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.block import Block


T = TypeVar("T", bound="GetAssignmentBlocksBySpaceIdResponse")


@_attrs_define
class GetAssignmentBlocksBySpaceIdResponse:
    """
    Attributes:
        assignment_blocks (list[Block] | Unset):
    """

    assignment_blocks: list[Block] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.block import Block

        assignment_blocks: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.assignment_blocks, Unset):
            assignment_blocks = []
            for assignment_blocks_item_data in self.assignment_blocks:
                assignment_blocks_item = assignment_blocks_item_data.to_dict()
                assignment_blocks.append(assignment_blocks_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if assignment_blocks is not UNSET:
            field_dict["assignmentBlocks"] = assignment_blocks

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.block import Block

        d = dict(src_dict)
        _assignment_blocks = d.pop("assignmentBlocks", UNSET)
        assignment_blocks: list[Block] | Unset = UNSET
        if _assignment_blocks is not UNSET:
            assignment_blocks = []
            for assignment_blocks_item_data in _assignment_blocks:
                assignment_blocks_item = Block.from_dict(assignment_blocks_item_data)

                assignment_blocks.append(assignment_blocks_item)

        get_assignment_blocks_by_space_id_response = cls(
            assignment_blocks=assignment_blocks,
        )

        get_assignment_blocks_by_space_id_response.additional_properties = d
        return get_assignment_blocks_by_space_id_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
