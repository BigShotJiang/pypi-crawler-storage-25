from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.room_recording_recording_type import RoomRecordingRecordingType
from ..models.room_recording_status import RoomRecordingStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.asset import Asset


T = TypeVar("T", bound="RoomRecording")


@_attrs_define
class RoomRecording:
    """
    Attributes:
        id (str | Unset):
        room_id (str | Unset):
        recording_url (str | Unset):
        title (str | Unset):
        recording_type (RoomRecordingRecordingType | Unset):
        view_count (str | Unset):
        thumbnail_url (str | Unset):
        captions_url (str | Unset):
        duration (str | Unset):
        direct_download_url (str | Unset):
        assets (list[Asset] | Unset):
        status (RoomRecordingStatus | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
    """

    id: str | Unset = UNSET
    room_id: str | Unset = UNSET
    recording_url: str | Unset = UNSET
    title: str | Unset = UNSET
    recording_type: RoomRecordingRecordingType | Unset = UNSET
    view_count: str | Unset = UNSET
    thumbnail_url: str | Unset = UNSET
    captions_url: str | Unset = UNSET
    duration: str | Unset = UNSET
    direct_download_url: str | Unset = UNSET
    assets: list[Asset] | Unset = UNSET
    status: RoomRecordingStatus | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.asset import Asset

        id = self.id

        room_id = self.room_id

        recording_url = self.recording_url

        title = self.title

        recording_type: str | Unset = UNSET
        if not isinstance(self.recording_type, Unset):
            recording_type = self.recording_type.value

        view_count = self.view_count

        thumbnail_url = self.thumbnail_url

        captions_url = self.captions_url

        duration = self.duration

        direct_download_url = self.direct_download_url

        assets: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.assets, Unset):
            assets = []
            for assets_item_data in self.assets:
                assets_item = assets_item_data.to_dict()
                assets.append(assets_item)

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if room_id is not UNSET:
            field_dict["roomId"] = room_id
        if recording_url is not UNSET:
            field_dict["recordingUrl"] = recording_url
        if title is not UNSET:
            field_dict["title"] = title
        if recording_type is not UNSET:
            field_dict["recordingType"] = recording_type
        if view_count is not UNSET:
            field_dict["viewCount"] = view_count
        if thumbnail_url is not UNSET:
            field_dict["thumbnailUrl"] = thumbnail_url
        if captions_url is not UNSET:
            field_dict["captionsUrl"] = captions_url
        if duration is not UNSET:
            field_dict["duration"] = duration
        if direct_download_url is not UNSET:
            field_dict["directDownloadUrl"] = direct_download_url
        if assets is not UNSET:
            field_dict["assets"] = assets
        if status is not UNSET:
            field_dict["status"] = status
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.asset import Asset

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        room_id = d.pop("roomId", UNSET)

        recording_url = d.pop("recordingUrl", UNSET)

        title = d.pop("title", UNSET)

        _recording_type = d.pop("recordingType", UNSET)
        recording_type: RoomRecordingRecordingType | Unset
        if isinstance(_recording_type, Unset):
            recording_type = UNSET
        else:
            recording_type = RoomRecordingRecordingType(_recording_type)

        view_count = d.pop("viewCount", UNSET)

        thumbnail_url = d.pop("thumbnailUrl", UNSET)

        captions_url = d.pop("captionsUrl", UNSET)

        duration = d.pop("duration", UNSET)

        direct_download_url = d.pop("directDownloadUrl", UNSET)

        _assets = d.pop("assets", UNSET)
        assets: list[Asset] | Unset = UNSET
        if _assets is not UNSET:
            assets = []
            for assets_item_data in _assets:
                assets_item = Asset.from_dict(assets_item_data)

                assets.append(assets_item)

        _status = d.pop("status", UNSET)
        status: RoomRecordingStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = RoomRecordingStatus(_status)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        room_recording = cls(
            id=id,
            room_id=room_id,
            recording_url=recording_url,
            title=title,
            recording_type=recording_type,
            view_count=view_count,
            thumbnail_url=thumbnail_url,
            captions_url=captions_url,
            duration=duration,
            direct_download_url=direct_download_url,
            assets=assets,
            status=status,
            created_at=created_at,
            updated_at=updated_at,
        )

        room_recording.additional_properties = d
        return room_recording

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
