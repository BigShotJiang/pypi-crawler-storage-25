from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.space_member import SpaceMember


T = TypeVar("T", bound="UpdateSpaceMemberResponse")


@_attrs_define
class UpdateSpaceMemberResponse:
    """
    Attributes:
        member (SpaceMember | Unset):
    """

    member: SpaceMember | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.space_member import SpaceMember

        member: dict[str, Any] | Unset = UNSET
        if not isinstance(self.member, Unset):
            member = self.member.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if member is not UNSET:
            field_dict["member"] = member

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.space_member import SpaceMember

        d = dict(src_dict)
        _member = d.pop("member", UNSET)
        member: SpaceMember | Unset
        if isinstance(_member, Unset):
            member = UNSET
        else:
            member = SpaceMember.from_dict(_member)

        update_space_member_response = cls(
            member=member,
        )

        update_space_member_response.additional_properties = d
        return update_space_member_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
