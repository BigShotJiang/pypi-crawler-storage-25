from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.space_link_sharing import SpaceLinkSharing
from ..models.space_organization_sharing import SpaceOrganizationSharing
from ..models.space_public_sharing import SpacePublicSharing
from ..models.space_status import SpaceStatus
from ..models.space_template_type import SpaceTemplateType
from ..models.space_type import SpaceType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.label import Label
    from ..models.member_view import MemberView
    from ..models.space_role import SpaceRole


T = TypeVar("T", bound="Space")


@_attrs_define
class Space:
    """
    Attributes:
        id (str | Unset):
        organization_id (str | Unset):
        name (str | Unset):
        type_ (SpaceType | Unset):
        personal_space_user_id (str | Unset):
        other_type_name (str | Unset):
        organization_sharing (SpaceOrganizationSharing | Unset):
        link_sharing (SpaceLinkSharing | Unset):
        public_sharing (SpacePublicSharing | Unset):
        link_sharing_secret (str | Unset):
        tags (list[str] | Unset):
        status (SpaceStatus | Unset):
        template_type (SpaceTemplateType | Unset):
        cover_photo_file_id (str | Unset):
        cover_photo_x_offset (int | Unset):
        cover_photo_y_offset (int | Unset):
        icon_name (str | Unset):
        default_space_role_id (str | Unset):
        description_block_id (str | Unset):
        enable_progress_tracking (bool | Unset):
        only_allow_existing_organization_members (bool | Unset):
        allow_block_sharing_organization_members (bool | Unset):
        allow_block_sharing_public (bool | Unset):
        allow_block_sharing_users (bool | Unset):
        cover_photo_file_url (str | Unset):
        roles (list[SpaceRole] | Unset):
        member_count (int | Unset):
        members_view (list[MemberView] | Unset):
        start_date (datetime.datetime | Unset):
        end_date (datetime.datetime | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        deleted_at (datetime.datetime | Unset):
        last_activity_at (datetime.datetime | Unset):
        created_by_id (str | Unset):
        pilot_token (str | Unset):
        labels (list[Label] | Unset):
    """

    id: str | Unset = UNSET
    organization_id: str | Unset = UNSET
    name: str | Unset = UNSET
    type_: SpaceType | Unset = UNSET
    personal_space_user_id: str | Unset = UNSET
    other_type_name: str | Unset = UNSET
    organization_sharing: SpaceOrganizationSharing | Unset = UNSET
    link_sharing: SpaceLinkSharing | Unset = UNSET
    public_sharing: SpacePublicSharing | Unset = UNSET
    link_sharing_secret: str | Unset = UNSET
    tags: list[str] | Unset = UNSET
    status: SpaceStatus | Unset = UNSET
    template_type: SpaceTemplateType | Unset = UNSET
    cover_photo_file_id: str | Unset = UNSET
    cover_photo_x_offset: int | Unset = UNSET
    cover_photo_y_offset: int | Unset = UNSET
    icon_name: str | Unset = UNSET
    default_space_role_id: str | Unset = UNSET
    description_block_id: str | Unset = UNSET
    enable_progress_tracking: bool | Unset = UNSET
    only_allow_existing_organization_members: bool | Unset = UNSET
    allow_block_sharing_organization_members: bool | Unset = UNSET
    allow_block_sharing_public: bool | Unset = UNSET
    allow_block_sharing_users: bool | Unset = UNSET
    cover_photo_file_url: str | Unset = UNSET
    roles: list[SpaceRole] | Unset = UNSET
    member_count: int | Unset = UNSET
    members_view: list[MemberView] | Unset = UNSET
    start_date: datetime.datetime | Unset = UNSET
    end_date: datetime.datetime | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    deleted_at: datetime.datetime | Unset = UNSET
    last_activity_at: datetime.datetime | Unset = UNSET
    created_by_id: str | Unset = UNSET
    pilot_token: str | Unset = UNSET
    labels: list[Label] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.label import Label
        from ..models.member_view import MemberView
        from ..models.space_role import SpaceRole

        id = self.id

        organization_id = self.organization_id

        name = self.name

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        personal_space_user_id = self.personal_space_user_id

        other_type_name = self.other_type_name

        organization_sharing: str | Unset = UNSET
        if not isinstance(self.organization_sharing, Unset):
            organization_sharing = self.organization_sharing.value

        link_sharing: str | Unset = UNSET
        if not isinstance(self.link_sharing, Unset):
            link_sharing = self.link_sharing.value

        public_sharing: str | Unset = UNSET
        if not isinstance(self.public_sharing, Unset):
            public_sharing = self.public_sharing.value

        link_sharing_secret = self.link_sharing_secret

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        template_type: str | Unset = UNSET
        if not isinstance(self.template_type, Unset):
            template_type = self.template_type.value

        cover_photo_file_id = self.cover_photo_file_id

        cover_photo_x_offset = self.cover_photo_x_offset

        cover_photo_y_offset = self.cover_photo_y_offset

        icon_name = self.icon_name

        default_space_role_id = self.default_space_role_id

        description_block_id = self.description_block_id

        enable_progress_tracking = self.enable_progress_tracking

        only_allow_existing_organization_members = self.only_allow_existing_organization_members

        allow_block_sharing_organization_members = self.allow_block_sharing_organization_members

        allow_block_sharing_public = self.allow_block_sharing_public

        allow_block_sharing_users = self.allow_block_sharing_users

        cover_photo_file_url = self.cover_photo_file_url

        roles: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.roles, Unset):
            roles = []
            for roles_item_data in self.roles:
                roles_item = roles_item_data.to_dict()
                roles.append(roles_item)

        member_count = self.member_count

        members_view: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.members_view, Unset):
            members_view = []
            for members_view_item_data in self.members_view:
                members_view_item = members_view_item_data.to_dict()
                members_view.append(members_view_item)

        start_date: str | Unset = UNSET
        if not isinstance(self.start_date, Unset):
            start_date = self.start_date.isoformat()

        end_date: str | Unset = UNSET
        if not isinstance(self.end_date, Unset):
            end_date = self.end_date.isoformat()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        deleted_at: str | Unset = UNSET
        if not isinstance(self.deleted_at, Unset):
            deleted_at = self.deleted_at.isoformat()

        last_activity_at: str | Unset = UNSET
        if not isinstance(self.last_activity_at, Unset):
            last_activity_at = self.last_activity_at.isoformat()

        created_by_id = self.created_by_id

        pilot_token = self.pilot_token

        labels: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.labels, Unset):
            labels = []
            for labels_item_data in self.labels:
                labels_item = labels_item_data.to_dict()
                labels.append(labels_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if organization_id is not UNSET:
            field_dict["organizationId"] = organization_id
        if name is not UNSET:
            field_dict["name"] = name
        if type_ is not UNSET:
            field_dict["type"] = type_
        if personal_space_user_id is not UNSET:
            field_dict["personalSpaceUserId"] = personal_space_user_id
        if other_type_name is not UNSET:
            field_dict["otherTypeName"] = other_type_name
        if organization_sharing is not UNSET:
            field_dict["organizationSharing"] = organization_sharing
        if link_sharing is not UNSET:
            field_dict["linkSharing"] = link_sharing
        if public_sharing is not UNSET:
            field_dict["publicSharing"] = public_sharing
        if link_sharing_secret is not UNSET:
            field_dict["linkSharingSecret"] = link_sharing_secret
        if tags is not UNSET:
            field_dict["tags"] = tags
        if status is not UNSET:
            field_dict["status"] = status
        if template_type is not UNSET:
            field_dict["templateType"] = template_type
        if cover_photo_file_id is not UNSET:
            field_dict["coverPhotoFileId"] = cover_photo_file_id
        if cover_photo_x_offset is not UNSET:
            field_dict["coverPhotoXOffset"] = cover_photo_x_offset
        if cover_photo_y_offset is not UNSET:
            field_dict["coverPhotoYOffset"] = cover_photo_y_offset
        if icon_name is not UNSET:
            field_dict["iconName"] = icon_name
        if default_space_role_id is not UNSET:
            field_dict["defaultSpaceRoleId"] = default_space_role_id
        if description_block_id is not UNSET:
            field_dict["descriptionBlockId"] = description_block_id
        if enable_progress_tracking is not UNSET:
            field_dict["enableProgressTracking"] = enable_progress_tracking
        if only_allow_existing_organization_members is not UNSET:
            field_dict["onlyAllowExistingOrganizationMembers"] = only_allow_existing_organization_members
        if allow_block_sharing_organization_members is not UNSET:
            field_dict["allowBlockSharingOrganizationMembers"] = allow_block_sharing_organization_members
        if allow_block_sharing_public is not UNSET:
            field_dict["allowBlockSharingPublic"] = allow_block_sharing_public
        if allow_block_sharing_users is not UNSET:
            field_dict["allowBlockSharingUsers"] = allow_block_sharing_users
        if cover_photo_file_url is not UNSET:
            field_dict["coverPhotoFileUrl"] = cover_photo_file_url
        if roles is not UNSET:
            field_dict["roles"] = roles
        if member_count is not UNSET:
            field_dict["memberCount"] = member_count
        if members_view is not UNSET:
            field_dict["membersView"] = members_view
        if start_date is not UNSET:
            field_dict["startDate"] = start_date
        if end_date is not UNSET:
            field_dict["endDate"] = end_date
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if deleted_at is not UNSET:
            field_dict["deletedAt"] = deleted_at
        if last_activity_at is not UNSET:
            field_dict["lastActivityAt"] = last_activity_at
        if created_by_id is not UNSET:
            field_dict["createdById"] = created_by_id
        if pilot_token is not UNSET:
            field_dict["pilotToken"] = pilot_token
        if labels is not UNSET:
            field_dict["labels"] = labels

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.label import Label
        from ..models.member_view import MemberView
        from ..models.space_role import SpaceRole

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        organization_id = d.pop("organizationId", UNSET)

        name = d.pop("name", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: SpaceType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = SpaceType(_type_)

        personal_space_user_id = d.pop("personalSpaceUserId", UNSET)

        other_type_name = d.pop("otherTypeName", UNSET)

        _organization_sharing = d.pop("organizationSharing", UNSET)
        organization_sharing: SpaceOrganizationSharing | Unset
        if isinstance(_organization_sharing, Unset):
            organization_sharing = UNSET
        else:
            organization_sharing = SpaceOrganizationSharing(_organization_sharing)

        _link_sharing = d.pop("linkSharing", UNSET)
        link_sharing: SpaceLinkSharing | Unset
        if isinstance(_link_sharing, Unset):
            link_sharing = UNSET
        else:
            link_sharing = SpaceLinkSharing(_link_sharing)

        _public_sharing = d.pop("publicSharing", UNSET)
        public_sharing: SpacePublicSharing | Unset
        if isinstance(_public_sharing, Unset):
            public_sharing = UNSET
        else:
            public_sharing = SpacePublicSharing(_public_sharing)

        link_sharing_secret = d.pop("linkSharingSecret", UNSET)

        tags = cast(list[str], d.pop("tags", UNSET))

        _status = d.pop("status", UNSET)
        status: SpaceStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = SpaceStatus(_status)

        _template_type = d.pop("templateType", UNSET)
        template_type: SpaceTemplateType | Unset
        if isinstance(_template_type, Unset):
            template_type = UNSET
        else:
            template_type = SpaceTemplateType(_template_type)

        cover_photo_file_id = d.pop("coverPhotoFileId", UNSET)

        cover_photo_x_offset = d.pop("coverPhotoXOffset", UNSET)

        cover_photo_y_offset = d.pop("coverPhotoYOffset", UNSET)

        icon_name = d.pop("iconName", UNSET)

        default_space_role_id = d.pop("defaultSpaceRoleId", UNSET)

        description_block_id = d.pop("descriptionBlockId", UNSET)

        enable_progress_tracking = d.pop("enableProgressTracking", UNSET)

        only_allow_existing_organization_members = d.pop("onlyAllowExistingOrganizationMembers", UNSET)

        allow_block_sharing_organization_members = d.pop("allowBlockSharingOrganizationMembers", UNSET)

        allow_block_sharing_public = d.pop("allowBlockSharingPublic", UNSET)

        allow_block_sharing_users = d.pop("allowBlockSharingUsers", UNSET)

        cover_photo_file_url = d.pop("coverPhotoFileUrl", UNSET)

        _roles = d.pop("roles", UNSET)
        roles: list[SpaceRole] | Unset = UNSET
        if _roles is not UNSET:
            roles = []
            for roles_item_data in _roles:
                roles_item = SpaceRole.from_dict(roles_item_data)

                roles.append(roles_item)

        member_count = d.pop("memberCount", UNSET)

        _members_view = d.pop("membersView", UNSET)
        members_view: list[MemberView] | Unset = UNSET
        if _members_view is not UNSET:
            members_view = []
            for members_view_item_data in _members_view:
                members_view_item = MemberView.from_dict(members_view_item_data)

                members_view.append(members_view_item)

        _start_date = d.pop("startDate", UNSET)
        start_date: datetime.datetime | Unset
        if isinstance(_start_date, Unset):
            start_date = UNSET
        else:
            start_date = isoparse(_start_date)

        _end_date = d.pop("endDate", UNSET)
        end_date: datetime.datetime | Unset
        if isinstance(_end_date, Unset):
            end_date = UNSET
        else:
            end_date = isoparse(_end_date)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _deleted_at = d.pop("deletedAt", UNSET)
        deleted_at: datetime.datetime | Unset
        if isinstance(_deleted_at, Unset):
            deleted_at = UNSET
        else:
            deleted_at = isoparse(_deleted_at)

        _last_activity_at = d.pop("lastActivityAt", UNSET)
        last_activity_at: datetime.datetime | Unset
        if isinstance(_last_activity_at, Unset):
            last_activity_at = UNSET
        else:
            last_activity_at = isoparse(_last_activity_at)

        created_by_id = d.pop("createdById", UNSET)

        pilot_token = d.pop("pilotToken", UNSET)

        _labels = d.pop("labels", UNSET)
        labels: list[Label] | Unset = UNSET
        if _labels is not UNSET:
            labels = []
            for labels_item_data in _labels:
                labels_item = Label.from_dict(labels_item_data)

                labels.append(labels_item)

        space = cls(
            id=id,
            organization_id=organization_id,
            name=name,
            type_=type_,
            personal_space_user_id=personal_space_user_id,
            other_type_name=other_type_name,
            organization_sharing=organization_sharing,
            link_sharing=link_sharing,
            public_sharing=public_sharing,
            link_sharing_secret=link_sharing_secret,
            tags=tags,
            status=status,
            template_type=template_type,
            cover_photo_file_id=cover_photo_file_id,
            cover_photo_x_offset=cover_photo_x_offset,
            cover_photo_y_offset=cover_photo_y_offset,
            icon_name=icon_name,
            default_space_role_id=default_space_role_id,
            description_block_id=description_block_id,
            enable_progress_tracking=enable_progress_tracking,
            only_allow_existing_organization_members=only_allow_existing_organization_members,
            allow_block_sharing_organization_members=allow_block_sharing_organization_members,
            allow_block_sharing_public=allow_block_sharing_public,
            allow_block_sharing_users=allow_block_sharing_users,
            cover_photo_file_url=cover_photo_file_url,
            roles=roles,
            member_count=member_count,
            members_view=members_view,
            start_date=start_date,
            end_date=end_date,
            created_at=created_at,
            updated_at=updated_at,
            deleted_at=deleted_at,
            last_activity_at=last_activity_at,
            created_by_id=created_by_id,
            pilot_token=pilot_token,
            labels=labels,
        )

        space.additional_properties = d
        return space

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
