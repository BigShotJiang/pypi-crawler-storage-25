from enum import Enum


class AttachmentMimeType(str, Enum):
    MIME_TYPE_AUDIO = "MIME_TYPE_AUDIO"
    MIME_TYPE_BYTES = "MIME_TYPE_BYTES"
    MIME_TYPE_IMAGE = "MIME_TYPE_IMAGE"
    MIME_TYPE_PDF = "MIME_TYPE_PDF"
    MIME_TYPE_UNSPECIFIED = "MIME_TYPE_UNSPECIFIED"
    MIME_TYPE_VIDEO = "MIME_TYPE_VIDEO"
    MIME_TYPE_WORD = "MIME_TYPE_WORD"

    def __str__(self) -> str:
        return str(self.value)
