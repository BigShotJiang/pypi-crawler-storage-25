from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_space_member_content_status import UpdateSpaceMemberContentStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateSpaceMemberContent")


@_attrs_define
class UpdateSpaceMemberContent:
    """
    Attributes:
        role_ids (list[str] | Unset):
        title (str | Unset):
        status (UpdateSpaceMemberContentStatus | Unset):
    """

    role_ids: list[str] | Unset = UNSET
    title: str | Unset = UNSET
    status: UpdateSpaceMemberContentStatus | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        role_ids: list[str] | Unset = UNSET
        if not isinstance(self.role_ids, Unset):
            role_ids = self.role_ids

        title = self.title

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if role_ids is not UNSET:
            field_dict["roleIds"] = role_ids
        if title is not UNSET:
            field_dict["title"] = title
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        role_ids = cast(list[str], d.pop("roleIds", UNSET))

        title = d.pop("title", UNSET)

        _status = d.pop("status", UNSET)
        status: UpdateSpaceMemberContentStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = UpdateSpaceMemberContentStatus(_status)

        update_space_member_content = cls(
            role_ids=role_ids,
            title=title,
            status=status,
        )

        update_space_member_content.additional_properties = d
        return update_space_member_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
