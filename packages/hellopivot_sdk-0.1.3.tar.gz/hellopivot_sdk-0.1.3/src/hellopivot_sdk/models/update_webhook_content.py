from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_webhook_content_status import UpdateWebhookContentStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.webhook_subscription_input import WebhookSubscriptionInput


T = TypeVar("T", bound="UpdateWebhookContent")


@_attrs_define
class UpdateWebhookContent:
    """
    Attributes:
        name (str | Unset):
        description (str | Unset):
        endpoint_url (str | Unset):
        subscriptions (list[WebhookSubscriptionInput] | Unset): If provided, replaces all subscriptions. At least one
            subscription is required.
        status (UpdateWebhookContentStatus | Unset):
    """

    name: str | Unset = UNSET
    description: str | Unset = UNSET
    endpoint_url: str | Unset = UNSET
    subscriptions: list[WebhookSubscriptionInput] | Unset = UNSET
    status: UpdateWebhookContentStatus | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.webhook_subscription_input import WebhookSubscriptionInput

        name = self.name

        description = self.description

        endpoint_url = self.endpoint_url

        subscriptions: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.subscriptions, Unset):
            subscriptions = []
            for subscriptions_item_data in self.subscriptions:
                subscriptions_item = subscriptions_item_data.to_dict()
                subscriptions.append(subscriptions_item)

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if endpoint_url is not UNSET:
            field_dict["endpointUrl"] = endpoint_url
        if subscriptions is not UNSET:
            field_dict["subscriptions"] = subscriptions
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.webhook_subscription_input import WebhookSubscriptionInput

        d = dict(src_dict)
        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        endpoint_url = d.pop("endpointUrl", UNSET)

        _subscriptions = d.pop("subscriptions", UNSET)
        subscriptions: list[WebhookSubscriptionInput] | Unset = UNSET
        if _subscriptions is not UNSET:
            subscriptions = []
            for subscriptions_item_data in _subscriptions:
                subscriptions_item = WebhookSubscriptionInput.from_dict(subscriptions_item_data)

                subscriptions.append(subscriptions_item)

        _status = d.pop("status", UNSET)
        status: UpdateWebhookContentStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = UpdateWebhookContentStatus(_status)

        update_webhook_content = cls(
            name=name,
            description=description,
            endpoint_url=endpoint_url,
            subscriptions=subscriptions,
            status=status,
        )

        update_webhook_content.additional_properties = d
        return update_webhook_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
