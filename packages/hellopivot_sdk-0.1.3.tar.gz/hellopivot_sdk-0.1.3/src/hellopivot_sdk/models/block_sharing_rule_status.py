from enum import Enum


class BlockSharingRuleStatus(str, Enum):
    SHARING_RULE_STATUS_ACTIVE = "SHARING_RULE_STATUS_ACTIVE"
    SHARING_RULE_STATUS_DELETED = "SHARING_RULE_STATUS_DELETED"
    SHARING_RULE_STATUS_UNSPECIFIED = "SHARING_RULE_STATUS_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
