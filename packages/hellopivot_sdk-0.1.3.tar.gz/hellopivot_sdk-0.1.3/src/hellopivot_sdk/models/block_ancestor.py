from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.block_ancestor_type import BlockAncestorType
from ..types import UNSET, Unset

T = TypeVar("T", bound="BlockAncestor")


@_attrs_define
class BlockAncestor:
    """
    Attributes:
        type_ (BlockAncestorType | Unset):
        id (str | Unset):
    """

    type_: BlockAncestorType | Unset = UNSET
    id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        id = self.id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if id is not UNSET:
            field_dict["id"] = id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _type_ = d.pop("type", UNSET)
        type_: BlockAncestorType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = BlockAncestorType(_type_)

        id = d.pop("id", UNSET)

        block_ancestor = cls(
            type_=type_,
            id=id,
        )

        block_ancestor.additional_properties = d
        return block_ancestor

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
