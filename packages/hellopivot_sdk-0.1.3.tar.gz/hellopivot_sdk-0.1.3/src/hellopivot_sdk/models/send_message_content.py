from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rich_content import RichContent


T = TypeVar("T", bound="SendMessageContent")


@_attrs_define
class SendMessageContent:
    """
    Attributes:
        rich_content (RichContent):
        thread_parent_message_id (str | Unset):
        inline_reply_message_id (str | Unset):
    """

    rich_content: RichContent
    thread_parent_message_id: str | Unset = UNSET
    inline_reply_message_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rich_content import RichContent

        rich_content = self.rich_content.to_dict()

        thread_parent_message_id = self.thread_parent_message_id

        inline_reply_message_id = self.inline_reply_message_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "richContent": rich_content,
            }
        )
        if thread_parent_message_id is not UNSET:
            field_dict["threadParentMessageId"] = thread_parent_message_id
        if inline_reply_message_id is not UNSET:
            field_dict["inlineReplyMessageId"] = inline_reply_message_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rich_content import RichContent

        d = dict(src_dict)
        rich_content = RichContent.from_dict(d.pop("richContent"))

        thread_parent_message_id = d.pop("threadParentMessageId", UNSET)

        inline_reply_message_id = d.pop("inlineReplyMessageId", UNSET)

        send_message_content = cls(
            rich_content=rich_content,
            thread_parent_message_id=thread_parent_message_id,
            inline_reply_message_id=inline_reply_message_id,
        )

        send_message_content.additional_properties = d
        return send_message_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
