from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="PersistedBreakoutData")


@_attrs_define
class PersistedBreakoutData:
    """
    Attributes:
        is_breakout_groups_running (bool | Unset):
        breakout_room_ids (list[str] | Unset):
    """

    is_breakout_groups_running: bool | Unset = UNSET
    breakout_room_ids: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        is_breakout_groups_running = self.is_breakout_groups_running

        breakout_room_ids: list[str] | Unset = UNSET
        if not isinstance(self.breakout_room_ids, Unset):
            breakout_room_ids = self.breakout_room_ids

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if is_breakout_groups_running is not UNSET:
            field_dict["isBreakoutGroupsRunning"] = is_breakout_groups_running
        if breakout_room_ids is not UNSET:
            field_dict["breakoutRoomIds"] = breakout_room_ids

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        is_breakout_groups_running = d.pop("isBreakoutGroupsRunning", UNSET)

        breakout_room_ids = cast(list[str], d.pop("breakoutRoomIds", UNSET))

        persisted_breakout_data = cls(
            is_breakout_groups_running=is_breakout_groups_running,
            breakout_room_ids=breakout_room_ids,
        )

        persisted_breakout_data.additional_properties = d
        return persisted_breakout_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
