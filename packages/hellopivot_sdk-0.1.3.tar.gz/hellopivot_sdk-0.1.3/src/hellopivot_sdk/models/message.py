from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, BinaryIO, Generator, TextIO, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.message_status import MessageStatus
from ..models.message_type import MessageType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.attachment import Attachment
    from ..models.reaction import Reaction
    from ..models.receipt import Receipt
    from ..models.rich_content import RichContent


T = TypeVar("T", bound="Message")


@_attrs_define
class Message:
    """
    Attributes:
        id (str | Unset):
        room_id (str | Unset):
        user_id (str | Unset):
        thread_parent_message_id (str | Unset):
        inline_reply_message_id (str | Unset):
        parent_recording_id (str | Unset):
        recording_position_timestamp (int | Unset):
        has_attached_blocks (bool | Unset):
        rich_content (RichContent | Unset):
        status (MessageStatus | Unset):
        reactions (list[Reaction] | Unset):
        receipts (list[Receipt] | Unset):
        attachments (list[Attachment] | Unset):
        sent_at (datetime.datetime | Unset):
        scheduled_send_at (datetime.datetime | Unset):
        deleted_at (datetime.datetime | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        thread_replies_count (int | Unset):
        thread_users_ids (list[str] | Unset):
        last_thread_reply_at (datetime.datetime | Unset):
        type_ (MessageType | Unset):
        call_ended_at (datetime.datetime | Unset):
        call_participant_user_ids (list[str] | Unset):
    """

    id: str | Unset = UNSET
    room_id: str | Unset = UNSET
    user_id: str | Unset = UNSET
    thread_parent_message_id: str | Unset = UNSET
    inline_reply_message_id: str | Unset = UNSET
    parent_recording_id: str | Unset = UNSET
    recording_position_timestamp: int | Unset = UNSET
    has_attached_blocks: bool | Unset = UNSET
    rich_content: RichContent | Unset = UNSET
    status: MessageStatus | Unset = UNSET
    reactions: list[Reaction] | Unset = UNSET
    receipts: list[Receipt] | Unset = UNSET
    attachments: list[Attachment] | Unset = UNSET
    sent_at: datetime.datetime | Unset = UNSET
    scheduled_send_at: datetime.datetime | Unset = UNSET
    deleted_at: datetime.datetime | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    thread_replies_count: int | Unset = UNSET
    thread_users_ids: list[str] | Unset = UNSET
    last_thread_reply_at: datetime.datetime | Unset = UNSET
    type_: MessageType | Unset = UNSET
    call_ended_at: datetime.datetime | Unset = UNSET
    call_participant_user_ids: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.attachment import Attachment
        from ..models.reaction import Reaction
        from ..models.receipt import Receipt
        from ..models.rich_content import RichContent

        id = self.id

        room_id = self.room_id

        user_id = self.user_id

        thread_parent_message_id = self.thread_parent_message_id

        inline_reply_message_id = self.inline_reply_message_id

        parent_recording_id = self.parent_recording_id

        recording_position_timestamp = self.recording_position_timestamp

        has_attached_blocks = self.has_attached_blocks

        rich_content: dict[str, Any] | Unset = UNSET
        if not isinstance(self.rich_content, Unset):
            rich_content = self.rich_content.to_dict()

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        reactions: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.reactions, Unset):
            reactions = []
            for reactions_item_data in self.reactions:
                reactions_item = reactions_item_data.to_dict()
                reactions.append(reactions_item)

        receipts: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.receipts, Unset):
            receipts = []
            for receipts_item_data in self.receipts:
                receipts_item = receipts_item_data.to_dict()
                receipts.append(receipts_item)

        attachments: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.attachments, Unset):
            attachments = []
            for attachments_item_data in self.attachments:
                attachments_item = attachments_item_data.to_dict()
                attachments.append(attachments_item)

        sent_at: str | Unset = UNSET
        if not isinstance(self.sent_at, Unset):
            sent_at = self.sent_at.isoformat()

        scheduled_send_at: str | Unset = UNSET
        if not isinstance(self.scheduled_send_at, Unset):
            scheduled_send_at = self.scheduled_send_at.isoformat()

        deleted_at: str | Unset = UNSET
        if not isinstance(self.deleted_at, Unset):
            deleted_at = self.deleted_at.isoformat()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        thread_replies_count = self.thread_replies_count

        thread_users_ids: list[str] | Unset = UNSET
        if not isinstance(self.thread_users_ids, Unset):
            thread_users_ids = self.thread_users_ids

        last_thread_reply_at: str | Unset = UNSET
        if not isinstance(self.last_thread_reply_at, Unset):
            last_thread_reply_at = self.last_thread_reply_at.isoformat()

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        call_ended_at: str | Unset = UNSET
        if not isinstance(self.call_ended_at, Unset):
            call_ended_at = self.call_ended_at.isoformat()

        call_participant_user_ids: list[str] | Unset = UNSET
        if not isinstance(self.call_participant_user_ids, Unset):
            call_participant_user_ids = self.call_participant_user_ids

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if room_id is not UNSET:
            field_dict["roomId"] = room_id
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if thread_parent_message_id is not UNSET:
            field_dict["threadParentMessageId"] = thread_parent_message_id
        if inline_reply_message_id is not UNSET:
            field_dict["inlineReplyMessageId"] = inline_reply_message_id
        if parent_recording_id is not UNSET:
            field_dict["parentRecordingId"] = parent_recording_id
        if recording_position_timestamp is not UNSET:
            field_dict["recordingPositionTimestamp"] = recording_position_timestamp
        if has_attached_blocks is not UNSET:
            field_dict["hasAttachedBlocks"] = has_attached_blocks
        if rich_content is not UNSET:
            field_dict["richContent"] = rich_content
        if status is not UNSET:
            field_dict["status"] = status
        if reactions is not UNSET:
            field_dict["reactions"] = reactions
        if receipts is not UNSET:
            field_dict["receipts"] = receipts
        if attachments is not UNSET:
            field_dict["attachments"] = attachments
        if sent_at is not UNSET:
            field_dict["sentAt"] = sent_at
        if scheduled_send_at is not UNSET:
            field_dict["scheduledSendAt"] = scheduled_send_at
        if deleted_at is not UNSET:
            field_dict["deletedAt"] = deleted_at
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if thread_replies_count is not UNSET:
            field_dict["threadRepliesCount"] = thread_replies_count
        if thread_users_ids is not UNSET:
            field_dict["threadUsersIds"] = thread_users_ids
        if last_thread_reply_at is not UNSET:
            field_dict["lastThreadReplyAt"] = last_thread_reply_at
        if type_ is not UNSET:
            field_dict["type"] = type_
        if call_ended_at is not UNSET:
            field_dict["callEndedAt"] = call_ended_at
        if call_participant_user_ids is not UNSET:
            field_dict["callParticipantUserIds"] = call_participant_user_ids

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.attachment import Attachment
        from ..models.reaction import Reaction
        from ..models.receipt import Receipt
        from ..models.rich_content import RichContent

        d = dict(src_dict)
        id = d.pop("id", UNSET)

        room_id = d.pop("roomId", UNSET)

        user_id = d.pop("userId", UNSET)

        thread_parent_message_id = d.pop("threadParentMessageId", UNSET)

        inline_reply_message_id = d.pop("inlineReplyMessageId", UNSET)

        parent_recording_id = d.pop("parentRecordingId", UNSET)

        recording_position_timestamp = d.pop("recordingPositionTimestamp", UNSET)

        has_attached_blocks = d.pop("hasAttachedBlocks", UNSET)

        _rich_content = d.pop("richContent", UNSET)
        rich_content: RichContent | Unset
        if isinstance(_rich_content, Unset):
            rich_content = UNSET
        else:
            rich_content = RichContent.from_dict(_rich_content)

        _status = d.pop("status", UNSET)
        status: MessageStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = MessageStatus(_status)

        _reactions = d.pop("reactions", UNSET)
        reactions: list[Reaction] | Unset = UNSET
        if _reactions is not UNSET:
            reactions = []
            for reactions_item_data in _reactions:
                reactions_item = Reaction.from_dict(reactions_item_data)

                reactions.append(reactions_item)

        _receipts = d.pop("receipts", UNSET)
        receipts: list[Receipt] | Unset = UNSET
        if _receipts is not UNSET:
            receipts = []
            for receipts_item_data in _receipts:
                receipts_item = Receipt.from_dict(receipts_item_data)

                receipts.append(receipts_item)

        _attachments = d.pop("attachments", UNSET)
        attachments: list[Attachment] | Unset = UNSET
        if _attachments is not UNSET:
            attachments = []
            for attachments_item_data in _attachments:
                attachments_item = Attachment.from_dict(attachments_item_data)

                attachments.append(attachments_item)

        _sent_at = d.pop("sentAt", UNSET)
        sent_at: datetime.datetime | Unset
        if isinstance(_sent_at, Unset):
            sent_at = UNSET
        else:
            sent_at = isoparse(_sent_at)

        _scheduled_send_at = d.pop("scheduledSendAt", UNSET)
        scheduled_send_at: datetime.datetime | Unset
        if isinstance(_scheduled_send_at, Unset):
            scheduled_send_at = UNSET
        else:
            scheduled_send_at = isoparse(_scheduled_send_at)

        _deleted_at = d.pop("deletedAt", UNSET)
        deleted_at: datetime.datetime | Unset
        if isinstance(_deleted_at, Unset):
            deleted_at = UNSET
        else:
            deleted_at = isoparse(_deleted_at)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        thread_replies_count = d.pop("threadRepliesCount", UNSET)

        thread_users_ids = cast(list[str], d.pop("threadUsersIds", UNSET))

        _last_thread_reply_at = d.pop("lastThreadReplyAt", UNSET)
        last_thread_reply_at: datetime.datetime | Unset
        if isinstance(_last_thread_reply_at, Unset):
            last_thread_reply_at = UNSET
        else:
            last_thread_reply_at = isoparse(_last_thread_reply_at)

        _type_ = d.pop("type", UNSET)
        type_: MessageType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = MessageType(_type_)

        _call_ended_at = d.pop("callEndedAt", UNSET)
        call_ended_at: datetime.datetime | Unset
        if isinstance(_call_ended_at, Unset):
            call_ended_at = UNSET
        else:
            call_ended_at = isoparse(_call_ended_at)

        call_participant_user_ids = cast(list[str], d.pop("callParticipantUserIds", UNSET))

        message = cls(
            id=id,
            room_id=room_id,
            user_id=user_id,
            thread_parent_message_id=thread_parent_message_id,
            inline_reply_message_id=inline_reply_message_id,
            parent_recording_id=parent_recording_id,
            recording_position_timestamp=recording_position_timestamp,
            has_attached_blocks=has_attached_blocks,
            rich_content=rich_content,
            status=status,
            reactions=reactions,
            receipts=receipts,
            attachments=attachments,
            sent_at=sent_at,
            scheduled_send_at=scheduled_send_at,
            deleted_at=deleted_at,
            created_at=created_at,
            updated_at=updated_at,
            thread_replies_count=thread_replies_count,
            thread_users_ids=thread_users_ids,
            last_thread_reply_at=last_thread_reply_at,
            type_=type_,
            call_ended_at=call_ended_at,
            call_participant_user_ids=call_participant_user_ids,
        )

        message.additional_properties = d
        return message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
