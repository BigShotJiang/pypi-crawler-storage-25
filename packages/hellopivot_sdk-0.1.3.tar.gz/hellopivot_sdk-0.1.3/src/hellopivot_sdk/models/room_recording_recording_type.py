from enum import Enum


class RoomRecordingRecordingType(str, Enum):
    ROOM_RECORDING_TYPE_CLIP = "ROOM_RECORDING_TYPE_CLIP"
    ROOM_RECORDING_TYPE_ORIGINAL = "ROOM_RECORDING_TYPE_ORIGINAL"
    ROOM_RECORDING_TYPE_UNSPECIFIED = "ROOM_RECORDING_TYPE_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
