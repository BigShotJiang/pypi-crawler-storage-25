from enum import Enum


class BlockResponseStatus(str, Enum):
    BLOCK_RESPONSE_STATUS_DRAFT = "BLOCK_RESPONSE_STATUS_DRAFT"
    BLOCK_RESPONSE_STATUS_SENT = "BLOCK_RESPONSE_STATUS_SENT"
    BLOCK_RESPONSE_STATUS_UNSPECIFIED = "BLOCK_RESPONSE_STATUS_UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
