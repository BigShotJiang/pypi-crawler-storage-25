from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.remove_label_from_space_response import RemoveLabelFromSpaceResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    space_id: str,
    label_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/spaces/{space_id}/labels/{label_id}".format(
            space_id=quote(str(space_id), safe=""),
            label_id=quote(str(label_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RemoveLabelFromSpaceResponse | Status:
    if response.status_code == 200:
        response_200 = RemoveLabelFromSpaceResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RemoveLabelFromSpaceResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    space_id: str,
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RemoveLabelFromSpaceResponse | Status]:
    """Remove label from space

     Removes a single label from a space.

    Args:
        space_id (str):
        label_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RemoveLabelFromSpaceResponse | Status]
    """

    kwargs = _get_kwargs(
        space_id=space_id,
        label_id=label_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    space_id: str,
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> RemoveLabelFromSpaceResponse | Status | None:
    """Remove label from space

     Removes a single label from a space.

    Args:
        space_id (str):
        label_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RemoveLabelFromSpaceResponse | Status
    """

    return sync_detailed(
        space_id=space_id,
        label_id=label_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    space_id: str,
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RemoveLabelFromSpaceResponse | Status]:
    """Remove label from space

     Removes a single label from a space.

    Args:
        space_id (str):
        label_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RemoveLabelFromSpaceResponse | Status]
    """

    kwargs = _get_kwargs(
        space_id=space_id,
        label_id=label_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    space_id: str,
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> RemoveLabelFromSpaceResponse | Status | None:
    """Remove label from space

     Removes a single label from a space.

    Args:
        space_id (str):
        label_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RemoveLabelFromSpaceResponse | Status
    """

    return (
        await asyncio_detailed(
            space_id=space_id,
            label_id=label_id,
            client=client,
        )
    ).parsed
