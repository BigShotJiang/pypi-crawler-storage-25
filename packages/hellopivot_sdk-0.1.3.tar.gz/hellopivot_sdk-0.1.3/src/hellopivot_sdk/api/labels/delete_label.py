from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_label_response import DeleteLabelResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    label_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/labels/{label_id}".format(
            label_id=quote(str(label_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DeleteLabelResponse | Status:
    if response.status_code == 200:
        response_200 = DeleteLabelResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeleteLabelResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteLabelResponse | Status]:
    """Delete label

     Deletes a label.

    Args:
        label_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteLabelResponse | Status]
    """

    kwargs = _get_kwargs(
        label_id=label_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteLabelResponse | Status | None:
    """Delete label

     Deletes a label.

    Args:
        label_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteLabelResponse | Status
    """

    return sync_detailed(
        label_id=label_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[DeleteLabelResponse | Status]:
    """Delete label

     Deletes a label.

    Args:
        label_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteLabelResponse | Status]
    """

    kwargs = _get_kwargs(
        label_id=label_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    label_id: str,
    *,
    client: AuthenticatedClient | Client,
) -> DeleteLabelResponse | Status | None:
    """Delete label

     Deletes a label.

    Args:
        label_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteLabelResponse | Status
    """

    return (
        await asyncio_detailed(
            label_id=label_id,
            client=client,
        )
    ).parsed
