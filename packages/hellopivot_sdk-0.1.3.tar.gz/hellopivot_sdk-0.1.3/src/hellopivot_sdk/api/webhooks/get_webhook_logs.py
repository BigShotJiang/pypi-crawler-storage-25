from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_webhook_logs_response import GetWebhookLogsResponse
from ...models.status import Status
from ...types import UNSET, Response, Unset


def _get_kwargs(
    organization_id: str,
    webhook_id: str,
    *,
    before_time: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["beforeTime"] = before_time

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/organizations/{organization_id}/webhooks/{webhook_id}/logs".format(
            organization_id=quote(str(organization_id), safe=""),
            webhook_id=quote(str(webhook_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetWebhookLogsResponse | Status:
    if response.status_code == 200:
        response_200 = GetWebhookLogsResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetWebhookLogsResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    organization_id: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,
    before_time: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[GetWebhookLogsResponse | Status]:
    """Get webhook logs

     Returns delivery logs for a webhook. Logs are retained for 30 days.

    Args:
        organization_id (str):
        webhook_id (str):
        before_time (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWebhookLogsResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        webhook_id=webhook_id,
        before_time=before_time,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    organization_id: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,
    before_time: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> GetWebhookLogsResponse | Status | None:
    """Get webhook logs

     Returns delivery logs for a webhook. Logs are retained for 30 days.

    Args:
        organization_id (str):
        webhook_id (str):
        before_time (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWebhookLogsResponse | Status
    """

    return sync_detailed(
        organization_id=organization_id,
        webhook_id=webhook_id,
        client=client,
        before_time=before_time,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    organization_id: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,
    before_time: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[GetWebhookLogsResponse | Status]:
    """Get webhook logs

     Returns delivery logs for a webhook. Logs are retained for 30 days.

    Args:
        organization_id (str):
        webhook_id (str):
        before_time (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWebhookLogsResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        webhook_id=webhook_id,
        before_time=before_time,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    organization_id: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,
    before_time: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> GetWebhookLogsResponse | Status | None:
    """Get webhook logs

     Returns delivery logs for a webhook. Logs are retained for 30 days.

    Args:
        organization_id (str):
        webhook_id (str):
        before_time (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWebhookLogsResponse | Status
    """

    return (
        await asyncio_detailed(
            organization_id=organization_id,
            webhook_id=webhook_id,
            client=client,
            before_time=before_time,
            limit=limit,
        )
    ).parsed
