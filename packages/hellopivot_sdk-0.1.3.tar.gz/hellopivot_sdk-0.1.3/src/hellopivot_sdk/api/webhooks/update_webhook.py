from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.status import Status
from ...models.update_webhook_content import UpdateWebhookContent
from ...models.update_webhook_response import UpdateWebhookResponse
from ...types import UNSET, Response


def _get_kwargs(
    organization_id: str,
    webhook_id: str,
    *,
    body: UpdateWebhookContent,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/organizations/{organization_id}/webhooks/{webhook_id}".format(
            organization_id=quote(str(organization_id), safe=""),
            webhook_id=quote(str(webhook_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Status | UpdateWebhookResponse:
    if response.status_code == 200:
        response_200 = UpdateWebhookResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Status | UpdateWebhookResponse]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    organization_id: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWebhookContent,
) -> Response[Status | UpdateWebhookResponse]:
    """Update webhook

     Updates an existing webhook. If subscriptions are provided, they replace all existing subscriptions.

    Args:
        organization_id (str):
        webhook_id (str):
        body (UpdateWebhookContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Status | UpdateWebhookResponse]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        webhook_id=webhook_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    organization_id: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWebhookContent,
) -> Status | UpdateWebhookResponse | None:
    """Update webhook

     Updates an existing webhook. If subscriptions are provided, they replace all existing subscriptions.

    Args:
        organization_id (str):
        webhook_id (str):
        body (UpdateWebhookContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Status | UpdateWebhookResponse
    """

    return sync_detailed(
        organization_id=organization_id,
        webhook_id=webhook_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    organization_id: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWebhookContent,
) -> Response[Status | UpdateWebhookResponse]:
    """Update webhook

     Updates an existing webhook. If subscriptions are provided, they replace all existing subscriptions.

    Args:
        organization_id (str):
        webhook_id (str):
        body (UpdateWebhookContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Status | UpdateWebhookResponse]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        webhook_id=webhook_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    organization_id: str,
    webhook_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateWebhookContent,
) -> Status | UpdateWebhookResponse | None:
    """Update webhook

     Updates an existing webhook. If subscriptions are provided, they replace all existing subscriptions.

    Args:
        organization_id (str):
        webhook_id (str):
        body (UpdateWebhookContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Status | UpdateWebhookResponse
    """

    return (
        await asyncio_detailed(
            organization_id=organization_id,
            webhook_id=webhook_id,
            client=client,
            body=body,
        )
    ).parsed
