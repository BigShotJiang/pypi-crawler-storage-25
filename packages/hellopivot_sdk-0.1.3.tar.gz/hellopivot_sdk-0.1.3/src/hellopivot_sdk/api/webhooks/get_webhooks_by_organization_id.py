from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_webhooks_by_organization_id_response import GetWebhooksByOrganizationIdResponse
from ...models.status import Status
from ...types import UNSET, Response, Unset


def _get_kwargs(
    organization_id: str,
    *,
    name: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["name"] = name

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/organizations/{organization_id}/webhooks".format(
            organization_id=quote(str(organization_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetWebhooksByOrganizationIdResponse | Status:
    if response.status_code == 200:
        response_200 = GetWebhooksByOrganizationIdResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetWebhooksByOrganizationIdResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    organization_id: str,
    *,
    client: AuthenticatedClient | Client,
    name: str | Unset = UNSET,
) -> Response[GetWebhooksByOrganizationIdResponse | Status]:
    """List webhooks

     Returns webhooks for the organization. Supports optional case-insensitive name filtering via the
    `name` query parameter.

    Args:
        organization_id (str):
        name (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWebhooksByOrganizationIdResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        name=name,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    organization_id: str,
    *,
    client: AuthenticatedClient | Client,
    name: str | Unset = UNSET,
) -> GetWebhooksByOrganizationIdResponse | Status | None:
    """List webhooks

     Returns webhooks for the organization. Supports optional case-insensitive name filtering via the
    `name` query parameter.

    Args:
        organization_id (str):
        name (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWebhooksByOrganizationIdResponse | Status
    """

    return sync_detailed(
        organization_id=organization_id,
        client=client,
        name=name,
    ).parsed


async def asyncio_detailed(
    organization_id: str,
    *,
    client: AuthenticatedClient | Client,
    name: str | Unset = UNSET,
) -> Response[GetWebhooksByOrganizationIdResponse | Status]:
    """List webhooks

     Returns webhooks for the organization. Supports optional case-insensitive name filtering via the
    `name` query parameter.

    Args:
        organization_id (str):
        name (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWebhooksByOrganizationIdResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        name=name,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    organization_id: str,
    *,
    client: AuthenticatedClient | Client,
    name: str | Unset = UNSET,
) -> GetWebhooksByOrganizationIdResponse | Status | None:
    """List webhooks

     Returns webhooks for the organization. Supports optional case-insensitive name filtering via the
    `name` query parameter.

    Args:
        organization_id (str):
        name (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWebhooksByOrganizationIdResponse | Status
    """

    return (
        await asyncio_detailed(
            organization_id=organization_id,
            client=client,
            name=name,
        )
    ).parsed
