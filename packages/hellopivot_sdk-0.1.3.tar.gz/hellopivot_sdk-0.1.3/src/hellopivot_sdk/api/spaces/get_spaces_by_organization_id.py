from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_spaces_by_organization_id_response import GetSpacesByOrganizationIdResponse
from ...models.get_spaces_by_organization_id_sort_by import GetSpacesByOrganizationIdSortBy
from ...models.get_spaces_by_organization_id_space_types_item import GetSpacesByOrganizationIdSpaceTypesItem
from ...models.get_spaces_by_organization_id_status import GetSpacesByOrganizationIdStatus
from ...models.status import Status
from ...types import UNSET, Response, Unset


def _get_kwargs(
    organization_id: str,
    offset: int,
    *,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
    search_query: str | Unset = UNSET,
    label_ids: list[str] | Unset = UNSET,
    exclude_label_ids: bool | Unset = UNSET,
    space_types: list[GetSpacesByOrganizationIdSpaceTypesItem] | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_status: str | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = status.value

    params["status"] = json_status

    json_sort_by: str | Unset = UNSET
    if not isinstance(sort_by, Unset):
        json_sort_by = sort_by.value

    params["sortBy"] = json_sort_by

    params["searchQuery"] = search_query

    json_label_ids: list[str] | Unset = UNSET
    if not isinstance(label_ids, Unset):
        json_label_ids = label_ids

    params["labelIds"] = json_label_ids

    params["excludeLabelIds"] = exclude_label_ids

    json_space_types: list[str] | Unset = UNSET
    if not isinstance(space_types, Unset):
        json_space_types = []
        for space_types_item_data in space_types:
            space_types_item = space_types_item_data.value
            json_space_types.append(space_types_item)

    params["spaceTypes"] = json_space_types

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/organizations/{organization_id}/spaces/{offset}".format(
            organization_id=quote(str(organization_id), safe=""),
            offset=quote(str(offset), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetSpacesByOrganizationIdResponse | Status:
    if response.status_code == 200:
        response_200 = GetSpacesByOrganizationIdResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetSpacesByOrganizationIdResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    organization_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
    search_query: str | Unset = UNSET,
    label_ids: list[str] | Unset = UNSET,
    exclude_label_ids: bool | Unset = UNSET,
    space_types: list[GetSpacesByOrganizationIdSpaceTypesItem] | Unset = UNSET,
) -> Response[GetSpacesByOrganizationIdResponse | Status]:
    """List spaces

     Returns spaces in the organization. Supports filtering, sorting, and name search via query
    parameters. If no status is provided, only active spaces are returned. You can further refine
    results with searchQuery, labelIds, excludeLabelIds, and spaceTypes.

    Args:
        organization_id (str):
        offset (int):
        status (GetSpacesByOrganizationIdStatus | Unset):
        sort_by (GetSpacesByOrganizationIdSortBy | Unset):
        search_query (str | Unset):
        label_ids (list[str] | Unset):
        exclude_label_ids (bool | Unset):
        space_types (list[GetSpacesByOrganizationIdSpaceTypesItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetSpacesByOrganizationIdResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        offset=offset,
        status=status,
        sort_by=sort_by,
        search_query=search_query,
        label_ids=label_ids,
        exclude_label_ids=exclude_label_ids,
        space_types=space_types,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    organization_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
    search_query: str | Unset = UNSET,
    label_ids: list[str] | Unset = UNSET,
    exclude_label_ids: bool | Unset = UNSET,
    space_types: list[GetSpacesByOrganizationIdSpaceTypesItem] | Unset = UNSET,
) -> GetSpacesByOrganizationIdResponse | Status | None:
    """List spaces

     Returns spaces in the organization. Supports filtering, sorting, and name search via query
    parameters. If no status is provided, only active spaces are returned. You can further refine
    results with searchQuery, labelIds, excludeLabelIds, and spaceTypes.

    Args:
        organization_id (str):
        offset (int):
        status (GetSpacesByOrganizationIdStatus | Unset):
        sort_by (GetSpacesByOrganizationIdSortBy | Unset):
        search_query (str | Unset):
        label_ids (list[str] | Unset):
        exclude_label_ids (bool | Unset):
        space_types (list[GetSpacesByOrganizationIdSpaceTypesItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetSpacesByOrganizationIdResponse | Status
    """

    return sync_detailed(
        organization_id=organization_id,
        offset=offset,
        client=client,
        status=status,
        sort_by=sort_by,
        search_query=search_query,
        label_ids=label_ids,
        exclude_label_ids=exclude_label_ids,
        space_types=space_types,
    ).parsed


async def asyncio_detailed(
    organization_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
    search_query: str | Unset = UNSET,
    label_ids: list[str] | Unset = UNSET,
    exclude_label_ids: bool | Unset = UNSET,
    space_types: list[GetSpacesByOrganizationIdSpaceTypesItem] | Unset = UNSET,
) -> Response[GetSpacesByOrganizationIdResponse | Status]:
    """List spaces

     Returns spaces in the organization. Supports filtering, sorting, and name search via query
    parameters. If no status is provided, only active spaces are returned. You can further refine
    results with searchQuery, labelIds, excludeLabelIds, and spaceTypes.

    Args:
        organization_id (str):
        offset (int):
        status (GetSpacesByOrganizationIdStatus | Unset):
        sort_by (GetSpacesByOrganizationIdSortBy | Unset):
        search_query (str | Unset):
        label_ids (list[str] | Unset):
        exclude_label_ids (bool | Unset):
        space_types (list[GetSpacesByOrganizationIdSpaceTypesItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetSpacesByOrganizationIdResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        offset=offset,
        status=status,
        sort_by=sort_by,
        search_query=search_query,
        label_ids=label_ids,
        exclude_label_ids=exclude_label_ids,
        space_types=space_types,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    organization_id: str,
    offset: int,
    *,
    client: AuthenticatedClient | Client,
    status: GetSpacesByOrganizationIdStatus | Unset = UNSET,
    sort_by: GetSpacesByOrganizationIdSortBy | Unset = UNSET,
    search_query: str | Unset = UNSET,
    label_ids: list[str] | Unset = UNSET,
    exclude_label_ids: bool | Unset = UNSET,
    space_types: list[GetSpacesByOrganizationIdSpaceTypesItem] | Unset = UNSET,
) -> GetSpacesByOrganizationIdResponse | Status | None:
    """List spaces

     Returns spaces in the organization. Supports filtering, sorting, and name search via query
    parameters. If no status is provided, only active spaces are returned. You can further refine
    results with searchQuery, labelIds, excludeLabelIds, and spaceTypes.

    Args:
        organization_id (str):
        offset (int):
        status (GetSpacesByOrganizationIdStatus | Unset):
        sort_by (GetSpacesByOrganizationIdSortBy | Unset):
        search_query (str | Unset):
        label_ids (list[str] | Unset):
        exclude_label_ids (bool | Unset):
        space_types (list[GetSpacesByOrganizationIdSpaceTypesItem] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetSpacesByOrganizationIdResponse | Status
    """

    return (
        await asyncio_detailed(
            organization_id=organization_id,
            offset=offset,
            client=client,
            status=status,
            sort_by=sort_by,
            search_query=search_query,
            label_ids=label_ids,
            exclude_label_ids=exclude_label_ids,
            space_types=space_types,
        )
    ).parsed
