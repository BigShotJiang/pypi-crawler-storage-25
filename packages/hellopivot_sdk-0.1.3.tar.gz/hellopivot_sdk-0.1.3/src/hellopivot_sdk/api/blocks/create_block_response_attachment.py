from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_block_response_attachment_content import CreateBlockResponseAttachmentContent
from ...models.create_block_response_attachment_response import CreateBlockResponseAttachmentResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    response_id: str,
    *,
    body: CreateBlockResponseAttachmentContent,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/blocks/responses/{response_id}/attachments".format(
            response_id=quote(str(response_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateBlockResponseAttachmentResponse | Status:
    if response.status_code == 200:
        response_200 = CreateBlockResponseAttachmentResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateBlockResponseAttachmentResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    response_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBlockResponseAttachmentContent,
) -> Response[CreateBlockResponseAttachmentResponse | Status]:
    """Create an attachment for a block response

     Adds a file to a block response.

    Args:
        response_id (str):
        body (CreateBlockResponseAttachmentContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateBlockResponseAttachmentResponse | Status]
    """

    kwargs = _get_kwargs(
        response_id=response_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    response_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBlockResponseAttachmentContent,
) -> CreateBlockResponseAttachmentResponse | Status | None:
    """Create an attachment for a block response

     Adds a file to a block response.

    Args:
        response_id (str):
        body (CreateBlockResponseAttachmentContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateBlockResponseAttachmentResponse | Status
    """

    return sync_detailed(
        response_id=response_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    response_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBlockResponseAttachmentContent,
) -> Response[CreateBlockResponseAttachmentResponse | Status]:
    """Create an attachment for a block response

     Adds a file to a block response.

    Args:
        response_id (str):
        body (CreateBlockResponseAttachmentContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateBlockResponseAttachmentResponse | Status]
    """

    kwargs = _get_kwargs(
        response_id=response_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    response_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBlockResponseAttachmentContent,
) -> CreateBlockResponseAttachmentResponse | Status | None:
    """Create an attachment for a block response

     Adds a file to a block response.

    Args:
        response_id (str):
        body (CreateBlockResponseAttachmentContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateBlockResponseAttachmentResponse | Status
    """

    return (
        await asyncio_detailed(
            response_id=response_id,
            client=client,
            body=body,
        )
    ).parsed
