from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_block_sharing_rule_content import CreateBlockSharingRuleContent
from ...models.create_block_sharing_rule_response import CreateBlockSharingRuleResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    block_id: str,
    *,
    body: CreateBlockSharingRuleContent,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/blocks/{block_id}/sharing-rules".format(
            block_id=quote(str(block_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateBlockSharingRuleResponse | Status:
    if response.status_code == 200:
        response_200 = CreateBlockSharingRuleResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateBlockSharingRuleResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    block_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBlockSharingRuleContent,
) -> Response[CreateBlockSharingRuleResponse | Status]:
    """Create block sharing rule

     Creates a sharing rule for a block.

    Args:
        block_id (str):
        body (CreateBlockSharingRuleContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateBlockSharingRuleResponse | Status]
    """

    kwargs = _get_kwargs(
        block_id=block_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    block_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBlockSharingRuleContent,
) -> CreateBlockSharingRuleResponse | Status | None:
    """Create block sharing rule

     Creates a sharing rule for a block.

    Args:
        block_id (str):
        body (CreateBlockSharingRuleContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateBlockSharingRuleResponse | Status
    """

    return sync_detailed(
        block_id=block_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    block_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBlockSharingRuleContent,
) -> Response[CreateBlockSharingRuleResponse | Status]:
    """Create block sharing rule

     Creates a sharing rule for a block.

    Args:
        block_id (str):
        body (CreateBlockSharingRuleContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateBlockSharingRuleResponse | Status]
    """

    kwargs = _get_kwargs(
        block_id=block_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    block_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateBlockSharingRuleContent,
) -> CreateBlockSharingRuleResponse | Status | None:
    """Create block sharing rule

     Creates a sharing rule for a block.

    Args:
        block_id (str):
        body (CreateBlockSharingRuleContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateBlockSharingRuleResponse | Status
    """

    return (
        await asyncio_detailed(
            block_id=block_id,
            client=client,
            body=body,
        )
    ).parsed
