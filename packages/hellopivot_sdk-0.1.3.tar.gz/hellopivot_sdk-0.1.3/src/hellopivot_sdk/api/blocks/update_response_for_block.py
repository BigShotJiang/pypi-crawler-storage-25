from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.status import Status
from ...models.update_response_for_block_content import UpdateResponseForBlockContent
from ...models.update_response_for_block_response import UpdateResponseForBlockResponse
from ...types import UNSET, Response


def _get_kwargs(
    response_id: str,
    *,
    body: UpdateResponseForBlockContent,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/blocks/responses/{response_id}".format(
            response_id=quote(str(response_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Status | UpdateResponseForBlockResponse:
    if response.status_code == 200:
        response_200 = UpdateResponseForBlockResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Status | UpdateResponseForBlockResponse]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    response_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateResponseForBlockContent,
) -> Response[Status | UpdateResponseForBlockResponse]:
    """Update block response

     Updates an existing block response.

    Args:
        response_id (str):
        body (UpdateResponseForBlockContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Status | UpdateResponseForBlockResponse]
    """

    kwargs = _get_kwargs(
        response_id=response_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    response_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateResponseForBlockContent,
) -> Status | UpdateResponseForBlockResponse | None:
    """Update block response

     Updates an existing block response.

    Args:
        response_id (str):
        body (UpdateResponseForBlockContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Status | UpdateResponseForBlockResponse
    """

    return sync_detailed(
        response_id=response_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    response_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateResponseForBlockContent,
) -> Response[Status | UpdateResponseForBlockResponse]:
    """Update block response

     Updates an existing block response.

    Args:
        response_id (str):
        body (UpdateResponseForBlockContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Status | UpdateResponseForBlockResponse]
    """

    kwargs = _get_kwargs(
        response_id=response_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    response_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateResponseForBlockContent,
) -> Status | UpdateResponseForBlockResponse | None:
    """Update block response

     Updates an existing block response.

    Args:
        response_id (str):
        body (UpdateResponseForBlockContent):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Status | UpdateResponseForBlockResponse
    """

    return (
        await asyncio_detailed(
            response_id=response_id,
            client=client,
            body=body,
        )
    ).parsed
