from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.revoke_invite_by_id_response import RevokeInviteByIdResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    organization_id: str,
    invite_id: str,
    email: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/organizations/{organization_id}/invites/{invite_id}/{email}".format(
            organization_id=quote(str(organization_id), safe=""),
            invite_id=quote(str(invite_id), safe=""),
            email=quote(str(email), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RevokeInviteByIdResponse | Status:
    if response.status_code == 200:
        response_200 = RevokeInviteByIdResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RevokeInviteByIdResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    organization_id: str,
    invite_id: str,
    email: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RevokeInviteByIdResponse | Status]:
    """Revoke invite by ID

     Revokes an invitation by its unique ID and email address.

    Args:
        organization_id (str):
        invite_id (str):
        email (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RevokeInviteByIdResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        invite_id=invite_id,
        email=email,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    organization_id: str,
    invite_id: str,
    email: str,
    *,
    client: AuthenticatedClient | Client,
) -> RevokeInviteByIdResponse | Status | None:
    """Revoke invite by ID

     Revokes an invitation by its unique ID and email address.

    Args:
        organization_id (str):
        invite_id (str):
        email (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RevokeInviteByIdResponse | Status
    """

    return sync_detailed(
        organization_id=organization_id,
        invite_id=invite_id,
        email=email,
        client=client,
    ).parsed


async def asyncio_detailed(
    organization_id: str,
    invite_id: str,
    email: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RevokeInviteByIdResponse | Status]:
    """Revoke invite by ID

     Revokes an invitation by its unique ID and email address.

    Args:
        organization_id (str):
        invite_id (str):
        email (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RevokeInviteByIdResponse | Status]
    """

    kwargs = _get_kwargs(
        organization_id=organization_id,
        invite_id=invite_id,
        email=email,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    organization_id: str,
    invite_id: str,
    email: str,
    *,
    client: AuthenticatedClient | Client,
) -> RevokeInviteByIdResponse | Status | None:
    """Revoke invite by ID

     Revokes an invitation by its unique ID and email address.

    Args:
        organization_id (str):
        invite_id (str):
        email (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RevokeInviteByIdResponse | Status
    """

    return (
        await asyncio_detailed(
            organization_id=organization_id,
            invite_id=invite_id,
            email=email,
            client=client,
        )
    ).parsed
