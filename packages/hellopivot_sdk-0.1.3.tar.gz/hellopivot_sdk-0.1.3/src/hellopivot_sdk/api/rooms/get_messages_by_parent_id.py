from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_messages_by_parent_id_response import GetMessagesByParentIdResponse
from ...models.status import Status
from ...types import UNSET, Response, Unset


def _get_kwargs(
    room_id: str,
    parent_id: str,
    *,
    offset: int | Unset = UNSET,
    full_tree: bool | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["offset"] = offset

    params["fullTree"] = full_tree

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/rooms/{room_id}/messages/{parent_id}/children".format(
            room_id=quote(str(room_id), safe=""),
            parent_id=quote(str(parent_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetMessagesByParentIdResponse | Status:
    if response.status_code == 200:
        response_200 = GetMessagesByParentIdResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetMessagesByParentIdResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    room_id: str,
    parent_id: str,
    *,
    client: AuthenticatedClient | Client,
    offset: int | Unset = UNSET,
    full_tree: bool | Unset = UNSET,
) -> Response[GetMessagesByParentIdResponse | Status]:
    """List message replies (Deprecated)

     Deprecated: Use GET /v2/rooms/{room_id}/threads/{parent_id}/messages instead. Returns replies under
    a parent message.

    Args:
        room_id (str):
        parent_id (str):
        offset (int | Unset):
        full_tree (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetMessagesByParentIdResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        parent_id=parent_id,
        offset=offset,
        full_tree=full_tree,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    room_id: str,
    parent_id: str,
    *,
    client: AuthenticatedClient | Client,
    offset: int | Unset = UNSET,
    full_tree: bool | Unset = UNSET,
) -> GetMessagesByParentIdResponse | Status | None:
    """List message replies (Deprecated)

     Deprecated: Use GET /v2/rooms/{room_id}/threads/{parent_id}/messages instead. Returns replies under
    a parent message.

    Args:
        room_id (str):
        parent_id (str):
        offset (int | Unset):
        full_tree (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetMessagesByParentIdResponse | Status
    """

    return sync_detailed(
        room_id=room_id,
        parent_id=parent_id,
        client=client,
        offset=offset,
        full_tree=full_tree,
    ).parsed


async def asyncio_detailed(
    room_id: str,
    parent_id: str,
    *,
    client: AuthenticatedClient | Client,
    offset: int | Unset = UNSET,
    full_tree: bool | Unset = UNSET,
) -> Response[GetMessagesByParentIdResponse | Status]:
    """List message replies (Deprecated)

     Deprecated: Use GET /v2/rooms/{room_id}/threads/{parent_id}/messages instead. Returns replies under
    a parent message.

    Args:
        room_id (str):
        parent_id (str):
        offset (int | Unset):
        full_tree (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetMessagesByParentIdResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        parent_id=parent_id,
        offset=offset,
        full_tree=full_tree,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    room_id: str,
    parent_id: str,
    *,
    client: AuthenticatedClient | Client,
    offset: int | Unset = UNSET,
    full_tree: bool | Unset = UNSET,
) -> GetMessagesByParentIdResponse | Status | None:
    """List message replies (Deprecated)

     Deprecated: Use GET /v2/rooms/{room_id}/threads/{parent_id}/messages instead. Returns replies under
    a parent message.

    Args:
        room_id (str):
        parent_id (str):
        offset (int | Unset):
        full_tree (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetMessagesByParentIdResponse | Status
    """

    return (
        await asyncio_detailed(
            room_id=room_id,
            parent_id=parent_id,
            client=client,
            offset=offset,
            full_tree=full_tree,
        )
    ).parsed
