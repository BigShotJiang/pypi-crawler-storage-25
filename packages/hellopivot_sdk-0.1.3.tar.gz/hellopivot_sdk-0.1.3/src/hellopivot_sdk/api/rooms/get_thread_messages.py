import datetime
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx
from dateutil.parser import isoparse

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_thread_messages_response import GetThreadMessagesResponse
from ...models.status import Status
from ...types import UNSET, Response, Unset


def _get_kwargs(
    room_id: str,
    parent_id: str,
    *,
    cursor_sent_at: datetime.datetime | Unset = UNSET,
    cursor_message_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_cursor_sent_at: str | Unset = UNSET
    if not isinstance(cursor_sent_at, Unset):
        json_cursor_sent_at = cursor_sent_at.isoformat()
    params["cursorSentAt"] = json_cursor_sent_at

    params["cursorMessageId"] = cursor_message_id

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v2/rooms/{room_id}/threads/{parent_id}/messages".format(
            room_id=quote(str(room_id), safe=""),
            parent_id=quote(str(parent_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetThreadMessagesResponse | Status:
    if response.status_code == 200:
        response_200 = GetThreadMessagesResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetThreadMessagesResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    room_id: str,
    parent_id: str,
    *,
    client: AuthenticatedClient | Client,
    cursor_sent_at: datetime.datetime | Unset = UNSET,
    cursor_message_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[GetThreadMessagesResponse | Status]:
    """List thread messages

     Returns messages in a thread using cursor-based pagination (oldest first). For guidance and
    examples, see https://pivot.app/docs/developers/rest-api/message-retrieval.

    Args:
        room_id (str):
        parent_id (str):
        cursor_sent_at (datetime.datetime | Unset):
        cursor_message_id (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetThreadMessagesResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        parent_id=parent_id,
        cursor_sent_at=cursor_sent_at,
        cursor_message_id=cursor_message_id,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    room_id: str,
    parent_id: str,
    *,
    client: AuthenticatedClient | Client,
    cursor_sent_at: datetime.datetime | Unset = UNSET,
    cursor_message_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> GetThreadMessagesResponse | Status | None:
    """List thread messages

     Returns messages in a thread using cursor-based pagination (oldest first). For guidance and
    examples, see https://pivot.app/docs/developers/rest-api/message-retrieval.

    Args:
        room_id (str):
        parent_id (str):
        cursor_sent_at (datetime.datetime | Unset):
        cursor_message_id (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetThreadMessagesResponse | Status
    """

    return sync_detailed(
        room_id=room_id,
        parent_id=parent_id,
        client=client,
        cursor_sent_at=cursor_sent_at,
        cursor_message_id=cursor_message_id,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    room_id: str,
    parent_id: str,
    *,
    client: AuthenticatedClient | Client,
    cursor_sent_at: datetime.datetime | Unset = UNSET,
    cursor_message_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[GetThreadMessagesResponse | Status]:
    """List thread messages

     Returns messages in a thread using cursor-based pagination (oldest first). For guidance and
    examples, see https://pivot.app/docs/developers/rest-api/message-retrieval.

    Args:
        room_id (str):
        parent_id (str):
        cursor_sent_at (datetime.datetime | Unset):
        cursor_message_id (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetThreadMessagesResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        parent_id=parent_id,
        cursor_sent_at=cursor_sent_at,
        cursor_message_id=cursor_message_id,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    room_id: str,
    parent_id: str,
    *,
    client: AuthenticatedClient | Client,
    cursor_sent_at: datetime.datetime | Unset = UNSET,
    cursor_message_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> GetThreadMessagesResponse | Status | None:
    """List thread messages

     Returns messages in a thread using cursor-based pagination (oldest first). For guidance and
    examples, see https://pivot.app/docs/developers/rest-api/message-retrieval.

    Args:
        room_id (str):
        parent_id (str):
        cursor_sent_at (datetime.datetime | Unset):
        cursor_message_id (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetThreadMessagesResponse | Status
    """

    return (
        await asyncio_detailed(
            room_id=room_id,
            parent_id=parent_id,
            client=client,
            cursor_sent_at=cursor_sent_at,
            cursor_message_id=cursor_message_id,
            limit=limit,
        )
    ).parsed
