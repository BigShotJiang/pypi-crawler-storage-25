import datetime
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx
from dateutil.parser import isoparse

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_room_recordings_by_room_id_response import GetRoomRecordingsByRoomIdResponse
from ...models.status import Status
from ...types import UNSET, Response, Unset


def _get_kwargs(
    room_id: str,
    *,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_cursor_created_at: str | Unset = UNSET
    if not isinstance(cursor_created_at, Unset):
        json_cursor_created_at = cursor_created_at.isoformat()
    params["cursorCreatedAt"] = json_cursor_created_at

    params["cursorId"] = cursor_id

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/rooms/{room_id}/recordings".format(
            room_id=quote(str(room_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetRoomRecordingsByRoomIdResponse | Status:
    if response.status_code == 200:
        response_200 = GetRoomRecordingsByRoomIdResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetRoomRecordingsByRoomIdResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    room_id: str,
    *,
    client: AuthenticatedClient | Client,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[GetRoomRecordingsByRoomIdResponse | Status]:
    """List room recordings

     Returns recordings for a room, including transcripts and other assets.

    Args:
        room_id (str):
        cursor_created_at (datetime.datetime | Unset):
        cursor_id (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetRoomRecordingsByRoomIdResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        cursor_created_at=cursor_created_at,
        cursor_id=cursor_id,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    room_id: str,
    *,
    client: AuthenticatedClient | Client,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> GetRoomRecordingsByRoomIdResponse | Status | None:
    """List room recordings

     Returns recordings for a room, including transcripts and other assets.

    Args:
        room_id (str):
        cursor_created_at (datetime.datetime | Unset):
        cursor_id (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetRoomRecordingsByRoomIdResponse | Status
    """

    return sync_detailed(
        room_id=room_id,
        client=client,
        cursor_created_at=cursor_created_at,
        cursor_id=cursor_id,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    room_id: str,
    *,
    client: AuthenticatedClient | Client,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> Response[GetRoomRecordingsByRoomIdResponse | Status]:
    """List room recordings

     Returns recordings for a room, including transcripts and other assets.

    Args:
        room_id (str):
        cursor_created_at (datetime.datetime | Unset):
        cursor_id (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetRoomRecordingsByRoomIdResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        cursor_created_at=cursor_created_at,
        cursor_id=cursor_id,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    room_id: str,
    *,
    client: AuthenticatedClient | Client,
    cursor_created_at: datetime.datetime | Unset = UNSET,
    cursor_id: str | Unset = UNSET,
    limit: int | Unset = UNSET,
) -> GetRoomRecordingsByRoomIdResponse | Status | None:
    """List room recordings

     Returns recordings for a room, including transcripts and other assets.

    Args:
        room_id (str):
        cursor_created_at (datetime.datetime | Unset):
        cursor_id (str | Unset):
        limit (int | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetRoomRecordingsByRoomIdResponse | Status
    """

    return (
        await asyncio_detailed(
            room_id=room_id,
            client=client,
            cursor_created_at=cursor_created_at,
            cursor_id=cursor_id,
            limit=limit,
        )
    ).parsed
