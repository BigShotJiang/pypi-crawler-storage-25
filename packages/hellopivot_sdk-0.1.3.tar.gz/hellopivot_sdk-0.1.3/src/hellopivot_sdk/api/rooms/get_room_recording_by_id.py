import datetime
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx
from dateutil.parser import isoparse

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_room_recording_by_id_response import GetRoomRecordingByIdResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    room_id: str,
    recording_id: str,
    *,
    created_at: datetime.datetime,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_created_at = created_at.isoformat()
    params["createdAt"] = json_created_at

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/rooms/{room_id}/recordings/{recording_id}".format(
            room_id=quote(str(room_id), safe=""),
            recording_id=quote(str(recording_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetRoomRecordingByIdResponse | Status:
    if response.status_code == 200:
        response_200 = GetRoomRecordingByIdResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetRoomRecordingByIdResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    room_id: str,
    recording_id: str,
    *,
    client: AuthenticatedClient | Client,
    created_at: datetime.datetime,
) -> Response[GetRoomRecordingByIdResponse | Status]:
    """Get room recording

     Returns a specific room recording by ID, including transcripts and other assets.

    Args:
        room_id (str):
        recording_id (str):
        created_at (datetime.datetime):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetRoomRecordingByIdResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        recording_id=recording_id,
        created_at=created_at,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    room_id: str,
    recording_id: str,
    *,
    client: AuthenticatedClient | Client,
    created_at: datetime.datetime,
) -> GetRoomRecordingByIdResponse | Status | None:
    """Get room recording

     Returns a specific room recording by ID, including transcripts and other assets.

    Args:
        room_id (str):
        recording_id (str):
        created_at (datetime.datetime):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetRoomRecordingByIdResponse | Status
    """

    return sync_detailed(
        room_id=room_id,
        recording_id=recording_id,
        client=client,
        created_at=created_at,
    ).parsed


async def asyncio_detailed(
    room_id: str,
    recording_id: str,
    *,
    client: AuthenticatedClient | Client,
    created_at: datetime.datetime,
) -> Response[GetRoomRecordingByIdResponse | Status]:
    """Get room recording

     Returns a specific room recording by ID, including transcripts and other assets.

    Args:
        room_id (str):
        recording_id (str):
        created_at (datetime.datetime):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetRoomRecordingByIdResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        recording_id=recording_id,
        created_at=created_at,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    room_id: str,
    recording_id: str,
    *,
    client: AuthenticatedClient | Client,
    created_at: datetime.datetime,
) -> GetRoomRecordingByIdResponse | Status | None:
    """Get room recording

     Returns a specific room recording by ID, including transcripts and other assets.

    Args:
        room_id (str):
        recording_id (str):
        created_at (datetime.datetime):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetRoomRecordingByIdResponse | Status
    """

    return (
        await asyncio_detailed(
            room_id=room_id,
            recording_id=recording_id,
            client=client,
            created_at=created_at,
        )
    ).parsed
