from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.revoke_room_invite_response import RevokeRoomInviteResponse
from ...models.status import Status
from ...types import UNSET, Response


def _get_kwargs(
    room_id: str,
    email: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/rooms/{room_id}/invites/{email}".format(
            room_id=quote(str(room_id), safe=""),
            email=quote(str(email), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> RevokeRoomInviteResponse | Status:
    if response.status_code == 200:
        response_200 = RevokeRoomInviteResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)

    try:
        response_default = Status.from_dict(response.json())
    except ValueError:
        response_default = Status.from_dict({})

    return response_default


def _safe_http_status(code: int) -> int | HTTPStatus:
    try:
        return HTTPStatus(code)
    except ValueError:
        return code


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[RevokeRoomInviteResponse | Status]:
    return Response(
        status_code=_safe_http_status(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    room_id: str,
    email: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RevokeRoomInviteResponse | Status]:
    """Revoke room invite

     Revokes an invitation to a room by email address.

    Args:
        room_id (str):
        email (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RevokeRoomInviteResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        email=email,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    room_id: str,
    email: str,
    *,
    client: AuthenticatedClient | Client,
) -> RevokeRoomInviteResponse | Status | None:
    """Revoke room invite

     Revokes an invitation to a room by email address.

    Args:
        room_id (str):
        email (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RevokeRoomInviteResponse | Status
    """

    return sync_detailed(
        room_id=room_id,
        email=email,
        client=client,
    ).parsed


async def asyncio_detailed(
    room_id: str,
    email: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[RevokeRoomInviteResponse | Status]:
    """Revoke room invite

     Revokes an invitation to a room by email address.

    Args:
        room_id (str):
        email (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RevokeRoomInviteResponse | Status]
    """

    kwargs = _get_kwargs(
        room_id=room_id,
        email=email,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    room_id: str,
    email: str,
    *,
    client: AuthenticatedClient | Client,
) -> RevokeRoomInviteResponse | Status | None:
    """Revoke room invite

     Revokes an invitation to a room by email address.

    Args:
        room_id (str):
        email (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RevokeRoomInviteResponse | Status
    """

    return (
        await asyncio_detailed(
            room_id=room_id,
            email=email,
            client=client,
        )
    ).parsed
