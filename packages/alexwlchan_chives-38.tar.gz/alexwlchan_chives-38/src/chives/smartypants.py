"""
A Python implementation of SmartyPants, a tool for adding "smart punctuation"
to text -- for example, curly quotes and smart dashes.

This is based on SmartyPants.pl, a BSD-licensed Perl script written
by John Gruber. See https://daringfireball.net/projects/smartypants/

It is also based on SmartyPants.py, a Python fork of SmartyPants
maintained by Chad Miller, Yu-Jie Lin, Leo Hemsted, and Justin Mayer.
See https://pypi.org/project/smartypants/

This module is not intended to be used directly -- use `chives.text` instead.
"""

from collections.abc import Iterator
import re
from typing import Literal, NamedTuple


def smartypants(text: str) -> str:
    """
    Add smart punctuation to a piece of text.
    """
    skipped_tag_stack: list[str] = []
    in_pre = False
    result: list[str] = []

    # Preserve context for single-character quote tokens. Remember the last
    # character of the previous token, so we can curl them correctly.
    prev_token_last_char = ""

    for token in tokenize(text):
        if token.type == "tag":
            # Don't mess with quotes inside some tags.  This does not handle
            # self <closing/> tags!
            result.append(token.value)

            if skip_match := TAGS_TO_SKIP_RE.match(token.value):
                is_closing = bool(skip_match.group("closing"))
                tag_name = skip_match.group("tag_name").lower()

                if not is_closing:
                    skipped_tag_stack.append(tag_name)
                    in_pre = True
                else:
                    if skipped_tag_stack:
                        if tag_name == skipped_tag_stack[-1]:
                            skipped_tag_stack.pop()
                        else:  # pragma: no cover
                            assert 0
                            pass
                            # This close doesn't match the open.  This isn't
                            # XHTML.  We should barf here.
                    else:  # pragma: no cover
                        pass
                    if not skipped_tag_stack:
                        in_pre = False

        else:
            text = token.value
            # Remember the last character of this token before processing.
            last_char = text[-1:]
            if not in_pre:
                # Process escaped characters; they shouldn't have smart
                # punctuation added.
                text = re.sub(r"\\\\", "&#92;", text)
                text = re.sub(r'\\"', "&#34;", text)
                text = re.sub(r"\\'", "&#39;", text)
                text = re.sub(r"\\\.", "&#46;", text)
                text = re.sub(r"\\-", "&#45;", text)
                text = re.sub(r"\\`", "&#96;", text)

                # Convert quote entities back to regular quotes
                text = re.sub("&quot;", '"', text)

                # Convert dashes
                text = re.sub("---", "—", text)
                text = re.sub("--", "–", text)

                # Convert ellipses
                text = re.sub(r"\.\.\.", "…", text)
                text = re.sub(r"\. \. \.", "…", text)

                if text == "'":
                    # Special case: single-character ' token
                    if re.match(r"\S", prev_token_last_char):  # pragma: no cover
                        text = "’"
                    else:
                        text = "‘"
                elif text == '"':
                    # Special case: single-character " token
                    if re.match(r"\S", prev_token_last_char):  # pragma: no cover
                        text = "”"
                    else:
                        text = "“"

                else:
                    text = convert_quotes(text)

                # Convert entities
                CTBL = {
                    "&#8211;": "–",
                    "&#8212;": "—",
                    "&#8216;": "‘",
                    "&#8217;": "’",
                    "&#8220;": "“",
                    "&#8221;": "”",
                    "&#8230;": "…",
                }

                for k, v in CTBL.items():
                    text = text.replace(k, v)

            prev_token_last_char = last_char
            result.append(text)

    return "".join(result)


def convert_quotes(text: str) -> str:
    """
    Convert quotes in *text* into HTML curly quote entities.

    This is based on a function of the same name from the Python
    SmartyPants.py library.

    TODO: Use named entities.
    """
    punct_class = r"""[!"#\$\%'()*+,-.\/:;<=>?\@\[\\\]\^_`{|}~]"""

    # Special case if the very first character is a quote followed by
    # punctuation at a non-word-break. Close the quotes by brute force:
    text = re.sub(r"""^'(?=%s\\B)""" % (punct_class,), "&#8217;", text)
    text = re.sub(r"""^"(?=%s\\B)""" % (punct_class,), "&#8221;", text)

    # Special case for double sets of quotes, e.g.:
    #   <p>He said, "'Quoted' words in a larger quote."</p>
    text = re.sub(r""""'(?=\w)""", "&#8220;&#8216;", text)
    text = re.sub(r"""'"(?=\w)""", "&#8216;&#8220;", text)

    # Special case for decade abbreviations (the '80s):
    text = re.sub(r"""\b'(?=\d{2}s)""", "&#8217;", text)

    close_class = r"[^\ \t\r\n\[\{\(\-]"
    dec_dashes = "&#8211;|&#8212;"

    # Get most opening single quotes:
    opening_single_quotes_regex = re.compile(
        r"""
            (
                \s          |   # a whitespace char, or
                &nbsp;      |   # a non-breaking space entity, or
                --          |   # dashes, or
                &[mn]dash;  |   # named dash entities
                %s          |   # or decimal entities
                &\#x201[34];    # or hex
            )
            '                 # the quote
            (?=\w)            # followed by a word character
            """
        % (dec_dashes,),
        re.VERBOSE,
    )
    text = opening_single_quotes_regex.sub(r"\1&#8216;", text)

    closing_single_quotes_regex = re.compile(
        r"""
            (%s)
            '
            (?!\s | s\b | \d)
            """
        % (close_class,),
        re.VERBOSE,
    )
    text = closing_single_quotes_regex.sub(r"\1&#8217;", text)

    closing_single_quotes_regex = re.compile(
        r"""
            (%s)
            '
            (\s | s\b)
            """
        % (close_class,),
        re.VERBOSE,
    )
    text = closing_single_quotes_regex.sub(r"\1&#8217;\2", text)

    # Any remaining single quotes should be opening ones:
    text = re.sub("'", "&#8216;", text)

    # Get most opening double quotes:
    opening_double_quotes_regex = re.compile(
        r"""
            (
                \s          |   # a whitespace char, or
                &nbsp;      |   # a non-breaking space entity, or
                --          |   # dashes, or
                &[mn]dash;  |   # named dash entities
                %s          |   # or decimal entities
                &\#x201[34];    # or hex
            )
            "                 # the quote
            (?=\w)            # followed by a word character
            """
        % (dec_dashes,),
        re.VERBOSE,
    )
    text = opening_double_quotes_regex.sub(r"\1&#8220;", text)

    # Double closing quotes:
    closing_double_quotes_regex = re.compile(
        r"""
            #(%s)?   # character that indicates the quote should be closing
            "
            (?=\s)
            """
        % (close_class,),
        re.VERBOSE,
    )
    text = closing_double_quotes_regex.sub("&#8221;", text)

    closing_double_quotes_regex = re.compile(
        r"""
            ^
            "
            (?=%s)
            """
        % (punct_class,),
        re.VERBOSE,
    )
    text = closing_double_quotes_regex.sub("&#8221;", text)

    closing_double_quotes_regex = re.compile(
        r"""
            (%s)   # character that indicates the quote should be closing
            "
            """
        % (close_class,),
        re.VERBOSE,
    )
    text = closing_double_quotes_regex.sub(r"\1&#8221;", text)

    # Any remaining quotes should be opening ones.
    text = re.sub('"', "&#8220;", text)

    return text


# This regex matches HTML tags that use one of these tags.
tags_to_skip = "|".join(["pre", "samp", "code", "tt", "kbd", "script", "style", "math"])
TAGS_TO_SKIP_RE = re.compile(
    r"<(?P<closing>/)?(?P<tag_name>%s)[^>]*>" % tags_to_skip, re.IGNORECASE
)


class Token(NamedTuple):
    """
    A token in the input text.

    A token is either:

    -   a tag, possibly with nested tags, such as `<a href="<example>">`, or
    -   a run of text between tags.

    """

    type: Literal["text", "tag"]
    value: str


def tokenize(text: str) -> Iterator[Token]:
    """
    Find all the tokens in the input text.

    This is based on two existing functions:

    *   The `_tokenize()` subroutine from Brad Choate's MTRegex plugin.
        http://www.bradchoate.com/past/mtregex.php
    *   The `_tokenize()` function from the SmartyPants.py library.
        https://github.com/justinmayer/smartypants.py/blob/main/smartypants.py
    """
    # Matches text outside an HTML tag followed by a comment or a tag.
    tag_soup = re.compile(
        r"(?P<text>[^<]*)"
        r"(?P<tag><!--(?P<comment>.*?)--\s*>|<[^>]*>)",
        re.DOTALL,
    )

    previous_end = 0

    while match := tag_soup.match(text, previous_end):
        if match.group("text"):
            yield Token(type="text", value=match.group("text"))

        # if -- in text part of comment, then it's not a comment, therefore it
        # should be converted.
        #
        # In HTML4 [1]:
        #   [...] Authors should avoid putting two or more adjacent hyphens
        #   inside comments.
        #
        # In HTML5 [2]:
        #   [...] the comment may have text, with the additional restriction
        #   that the text must not [...], nor contain two consecutive U+002D
        #   HYPHEN-MINUS characters (--)
        #
        # [1]: http://www.w3.org/TR/REC-html40/intro/sgmltut.html#h-3.2.4
        # [2]: http://www.w3.org/TR/html5/syntax.html#comments
        tag = match.group("tag")
        if match.group("comment") and "--" in match.group("comment"):
            yield Token(type="text", value=tag)
        else:
            yield Token(type="tag", value=tag)

        previous_end = match.end()
        print(previous_end)

    if previous_end < len(text):
        yield Token(type="text", value=text[previous_end:])
