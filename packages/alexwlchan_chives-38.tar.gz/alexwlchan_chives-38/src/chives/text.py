"""
Functions for dealing with text.
"""

from chives.smartypants import smartypants


def smartify(text: str) -> str:
    """
    Add curly quotes and smart dashes to a string.
    """
    return smartypants(text)
