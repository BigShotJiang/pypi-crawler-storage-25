# قارئ القرآن الكريم - Quran Reader

نظام الاستعلام عن بيانات القرءان الكريم بسهولة.



## 🚀 الاستخدام


#### قراءة البيانات

```python
from quran_ayas.quran_reader import QuranReader

# تحميل قاعدة البيانات
reader = QuranReader()
```

#### أ) قراءة آية كاملة

```python
ayah = reader.get_ayah(surah_number=1, ayah_number=1)
print(ayah)
# بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
```

#### ب) قراءة كلمة محددة

```python
# الكلمة الأولى (index 0)
word = reader.get_word_at_index(surah_number=1, ayah_number=1, word_index=0)
print(word)
# بِسْمِ

# الكلمة الثانية (index 1)
word = reader.get_word_at_index(surah_number=1, ayah_number=1, word_index=1)
print(word)
# اللَّهِ
```

#### ج) معلومات عن سورة

```python
info = reader.get_surah_info(surah_number=1)
print(info)
# {'surah_number': 1, 'ayat_count': 7, 'ayat_numbers': [1, 2, 3, 4, 5, 6, 7]}
```

#### د) طباعة آية مع أرقام الكلمات

```python
reader.print_ayah(surah_number=1, ayah_number=1, show_word_indices=True)

# النتيجة:
# ============================================================
# السورة 1 - الآية 1
# ============================================================
# 
# [0] بِسْمِ
# [1] اللَّهِ
# [2] الرَّحْمَٰنِ
# [3] الرَّحِيمِ
# 
# عدد الكلمات: 4
# ============================================================
```

#### هـ) قراءة كل آيات سورة

```python
ayat = reader.get_all_ayat_in_surah(surah_number=1)
for ayah_num, ayah_text in ayat.items():
    print(f"{ayah_num}. {ayah_text}")
```

#### و) البحث في آية

```python
found = reader.search_in_ayah(
    surah_number=1, 
    ayah_number=1, 
    search_text="الرَّحْمَٰنِ"
)
print(found)  # True
```

#### ز) عدد الكلمات في آية

```python
count = reader.get_word_count(surah_number=1, ayah_number=1)
print(count)  # 4
```

---

## 📝 الدوال المتاحة

| الدالة | الوصف |
|--------|-------|
| `get_ayah(surah, ayah)` | الحصول على آية كاملة |
| `get_word_at_index(surah, ayah, index)` | الحصول على كلمة محددة |
| `get_surah_info(surah)` | معلومات عن السورة |
| `get_all_ayat_in_surah(surah)` | كل آيات السورة |
| `search_in_ayah(surah, ayah, text)` | البحث في آية |
| `get_word_count(surah, ayah)` | عدد كلمات الآية |
| `print_ayah(surah, ayah, show_indices)` | طباعة منسقة |

---

## 🎯 أمثلة عملية

### مثال 2: استعراض سورة كاملة مع التحليل

```python
reader = QuranReader()

# قراءة كل آيات الفاتحة
ayat = reader.get_all_ayat_in_surah(1)

for ayah_num, ayah_text in ayat.items():
    print(f"\n{'='*60}")
    print(f"الآية {ayah_num}: {ayah_text}")
    print('='*60)
```

---

## ⚙️ متطلبات التشغيل

- Python 3.6+
- لا توجد مكتبات خارجية مطلوبة (استخدام المكتبات القياسية فقط)

---

## 📦 الملفات

- `quran_reader.py` - قراءة والاستعلام عن البيانات
- `quran.json` - قاعدة البيانات (يتم إنشاؤها)

---

## 💡 ملاحظات

- أرقام الآيات والكلمات تبدأ من 1 (ليس من 0)
- لكن الـ `word_index` يبدأ من 0 (لأنه index في Python)
- يتم تنظيف المسافات الزائدة تلقائياً
- يدعم Unicode كامل للنصوص العربية

---

## ✅ التثبيت

```bash
pip install quran-ayas
```