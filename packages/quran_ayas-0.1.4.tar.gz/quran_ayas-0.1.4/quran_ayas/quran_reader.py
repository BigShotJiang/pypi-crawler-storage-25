import json
import os

class QuranReader:
    
    def __init__(self, json_file=None):
        
        if json_file is None:
            BASE_DIR = os.path.dirname(os.path.abspath(__file__))
            self.json_file = os.path.join(BASE_DIR, 'quran.json')
        else:
            self.json_file = json_file
            
        self.quran_data = {}
        self._load_data()
    
    def _load_data(self):

        if not os.path.exists(self.json_file):
            raise FileNotFoundError(f"quran data are not found {self.json_file}")
        
        try:
            with open(self.json_file, 'r', encoding='utf-8') as f:
                self.quran_data = json.load(f)
        except Exception as e:
            raise Exception(f"Error in reading data: {e}")
    
    def get_ayah(self, surah_number, ayah_number):

        surah_key = str(surah_number)
        ayah_key = str(ayah_number)
        
        if surah_key not in self.quran_data:
            print(f"Surah: {surah_number} is not found!")
            return None
        
        if ayah_key not in self.quran_data[surah_key]:
            print(f"Aya number: {ayah_number} is not found in surah {surah_number}!")
            return None
        
        return self.quran_data[surah_key][ayah_key]
    
    def get_word_at_index(self, surah_number, ayah_number, word_index):
        
        ayah_text = self.get_ayah(surah_number, ayah_number)
        
        if ayah_text is None:
            return None
        
        words = ayah_text.split()
        
        if word_index < 0 or word_index >= len(words):
            print(f"Word number: {word_index} is not found!")
            print(f"Surah contains only {len(words)} word.")
            return None
        
        return words[word_index]
    
    def get_surah_info(self, surah_number):

        surah_key = str(surah_number)
        
        if surah_key not in self.quran_data:
            print(f"Surah number: {surah_number} is not found!")
            return None
        
        ayat_count = len(self.quran_data[surah_key])
        
        return {
            "surah_number": surah_number,
            "ayat_count": ayat_count,
            "ayat_numbers": sorted([int(a) for a in self.quran_data[surah_key].keys()])
        }
    
    def get_all_ayat_in_surah(self, surah_number):
        surah_key = str(surah_number)
        
        if surah_key not in self.quran_data:
            print(f"Surah number: {surah_number} is not found!")
            return None
        
        return self.quran_data[surah_key]
    
    def search_in_ayah(self, surah_number, ayah_number, search_text):

        ayah_text = self.get_ayah(surah_number, ayah_number)
        
        if ayah_text is None:
            return False
        
        return search_text in ayah_text
    
    def get_word_count(self, surah_number, ayah_number):

        ayah_text = self.get_ayah(surah_number, ayah_number)
        
        if ayah_text is None:
            return 0
        
        return len(ayah_text.split())
    
    def print_ayah(self, surah_number, ayah_number, show_word_indices=False):

        ayah_text = self.get_ayah(surah_number, ayah_number)
        
        if ayah_text is None:
            return
        
        print("=" * 60)
        print(f"Surah = {surah_number}, Aya = {ayah_number}")
        print("=" * 60)
        
        if show_word_indices:
            words = ayah_text.split()
            print()
            for i, word in enumerate(words):
                print(f"[{i}] {word}")
            print()
        else:
            print(f"\n{ayah_text}\n")
        
        word_count = len(ayah_text.split())
        print(f"Number of words: {word_count}")
        print("=" * 60)