from quran_reader import QuranReader

reader = QuranReader()

ayah = reader.get_ayah(surah_number=1, ayah_number=1)
print(ayah)