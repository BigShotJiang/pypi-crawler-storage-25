"""Tests for CLI module."""

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

from rich.console import Console
from typer.testing import CliRunner

from teich.cli import BatchProgressReporter, CONFIG_TEMPLATE, app
from teich.runner import SessionProgressUpdate, TraceMetrics

runner = CliRunner()


def test_init_command(tmp_path: Path):
    """Test init command creates files."""
    result = runner.invoke(app, ["init", str(tmp_path)])

    assert result.exit_code == 0
    assert "Created" in result.output

    # Check files were created
    assert (tmp_path / "config.yaml").exists()
    assert (tmp_path / "prompts.jsonl").exists()


def test_init_command_existing_files(tmp_path: Path):
    """Test init command handles existing files."""
    # Create existing file
    (tmp_path / "config.yaml").write_text("existing")

    result = runner.invoke(app, ["init", str(tmp_path)])

    assert result.exit_code == 0
    assert "Already exists" in result.output


def test_checked_in_config_example_matches_init_template():
    example_path = Path(__file__).resolve().parent.parent / "config.example.yaml"
    assert example_path.read_text(encoding="utf-8") == CONFIG_TEMPLATE


def test_generate_command_missing_config():
    """Test generate command fails with missing config."""
    result = runner.invoke(app, ["generate", "-c", "/nonexistent/config.yaml"])

    assert result.exit_code == 1
    assert "not found" in result.output


def test_generate_command_no_prompts(tmp_path: Path):
    """Test generate command fails when no prompts configured."""
    config_file = tmp_path / "config.yaml"
    config_file.write_text("""
model:
  model: codex-mini-latest
prompts: []
""")

    result = runner.invoke(app, ["generate", "-c", str(config_file)])

    assert result.exit_code == 1
    assert "No prompts configured" in result.output


def test_generate_command_accepts_follow_up_prompts_for_codex_provider(tmp_path: Path):
    prompts_file = tmp_path / "prompts.jsonl"
    prompts_file.write_text(
        json.dumps({"prompt": "Build app", "follow_up_prompts": ["Add tests"]}) + "\n",
        encoding="utf-8",
    )
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: codex
model:
  model: codex-mini-latest
prompts_file: {prompts_file}
output:
  traces_dir: {tmp_path}/output
openai_api_key: sk-test
""")

    with patch('teich.cli.CodexRunner') as mock_runner:
        mock_instance = MagicMock()
        mock_instance.run_all.return_value = [tmp_path / "output/session1.jsonl"]
        mock_runner.return_value = mock_instance

        output_dir = tmp_path / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "session1.jsonl").write_text(
            '{"type":"session_meta","payload":{"id":"session1","base_instructions":{"text":"You are a coding agent."}}}\n'
            '{"type":"response_item","payload":{"type":"message","role":"user","content":[{"type":"input_text","text":"Build app"}]}}\n'
            '{"type":"response_item","payload":{"type":"message","role":"assistant","content":[{"type":"output_text","text":"Done"}]}}\n',
            encoding="utf-8",
        )

        result = runner.invoke(app, ["generate", "-c", str(config_file)])

    assert result.exit_code == 0
    assert "Success" in result.output
    kwargs = mock_instance.run_all.call_args.kwargs
    assert kwargs["prompt_inputs"][0].follow_up_prompts == ["Add tests"]


def test_generate_command_success_codex(tmp_path: Path):
    """Test generate command runs successfully with codex provider."""
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: codex
model:
  model: codex-mini-latest
prompts:
  - Build a todo app
output:
  traces_dir: {tmp_path}/output
openai_api_key: sk-test
""")

    with patch('teich.cli.CodexRunner') as mock_runner:
        mock_instance = MagicMock()
        mock_instance.run_all.return_value = [tmp_path / "output/session1.jsonl"]
        mock_runner.return_value = mock_instance

        output_dir = tmp_path / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "session1.jsonl").write_text(
            '{"type":"session_meta","payload":{"id":"session1","base_instructions":{"text":"You are a coding agent.\\n\\nAvailable tools:\\n- bash: Run shell commands\\n"}}}\n'
            '{"type":"response_item","payload":{"type":"message","role":"user","content":[{"type":"input_text","text":"Build a todo app"}]}}\n'
            '{"type":"response_item","payload":{"type":"function_call","name":"bash","call_id":"call_1","arguments":"{\\"command\\":\\"ls\\"}"}}\n'
        )

        result = runner.invoke(app, ["generate", "-c", str(config_file)])

        assert result.exit_code == 0
        assert "Success" in result.output
        assert "Generated 1 JSONL files" in result.output
        assert "tokens=" in result.output
        assert "api_tokens=" not in result.output
        assert "est_total_tokens=" not in result.output
        assert (output_dir / "README.md").exists()
        readme = (output_dir / "README.md").read_text(encoding="utf-8")
        assert "All assistant responses were generated by **codex-mini-latest**." in readme
        assert '- "agent-traces"' in readme
        assert '- "codex"' in readme
        assert '- "distillation"' in readme
        assert '- "codex-mini-latest"' in readme
        assert '- "teich"' in readme
        assert "## Training-ready tools" in readme
        assert "tools.json" not in readme
        assert "<details>" in readme
        assert "<summary>Training-ready tool schema snapshot</summary>" in readme
        assert '"name": "bash"' in readme
        assert '"command"' in readme
        assert not (output_dir / "tools.json").exists()


def test_generate_command_success_chat(tmp_path: Path):
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: chat
model:
  model: gpt-4.1-mini
prompts:
  - Hello
output:
  traces_dir: {tmp_path}/output
api:
  provider: openai
  api_key: sk-test
  wire_api: responses
""")

    with patch('teich.cli.ChatRunner') as mock_runner:
        mock_instance = MagicMock()
        mock_instance.run_all.return_value = [tmp_path / "output/chat-session.jsonl"]
        mock_runner.return_value = mock_instance

        output_dir = tmp_path / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "chat-session.jsonl").write_text(
            '{"messages":[{"role":"system","content":"You are a helpful assistant","thinking":null},{"role":"user","content":"Hello","thinking":null},{"role":"assistant","content":"Hi!","thinking":"I should greet the user."}],"system":"You are a helpful assistant","prompt":"Hello","thinking":"I should greet the user.","response":"Hi!","model":"gpt-4.1-mini","provider":"openai"}\n',
            encoding="utf-8",
        )

        result = runner.invoke(app, ["generate", "-c", str(config_file)])

        assert result.exit_code == 0
        assert "Success" in result.output
        assert (output_dir / "README.md").exists()
        readme = (output_dir / "README.md").read_text(encoding="utf-8")
        assert '- "conversational"' in readme
        assert '- "distillation"' in readme
        assert '- "teich"' in readme
        assert '- "gpt-4.1-mini"' in readme
        assert "newline-delimited JSON training examples generated by teich" in readme
        assert "Chat-only datasets include `messages` plus convenience fields like optional `system`, `prompt`, `follow_up_prompts`, `thinking`, `response`, and `responses`." in readme
        assert not (output_dir / "tools.json").exists()


def test_generate_command_resume_skips_completed_chat_prompts(tmp_path: Path):
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: chat
model:
  model: gpt-4.1-mini
prompts:
  - Hello
  - Who are you?
output:
  traces_dir: {tmp_path}/output
api:
  provider: openai
  api_key: sk-test
  wire_api: responses
""")
    output_dir = tmp_path / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "chat.jsonl").write_text(
        json.dumps({"prompt": "Hello", "response": "Hi", "messages": [{"role": "assistant", "content": "Hi"}]})
        + "\n",
        encoding="utf-8",
    )

    with patch('teich.cli.ChatRunner') as mock_runner:
        mock_instance = MagicMock()
        mock_instance.run_all.return_value = [output_dir / "chat.jsonl"]
        mock_runner.return_value = mock_instance

        result = runner.invoke(app, ["generate", "-c", str(config_file), "--resume"])

        assert result.exit_code == 0
        kwargs = mock_instance.run_all.call_args.kwargs
        assert kwargs["resume"] is True
        assert [prompt_input.prompt for prompt_input in kwargs["prompt_inputs"]] == ["Who are you?"]
        assert "skipping 1 configured prompts" in result.output


def test_generate_command_writes_readme_for_partial_outputs_on_failure(tmp_path: Path):
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: chat
model:
  model: gpt-4.1-mini
prompts:
  - Hello
  - Who are you?
output:
  traces_dir: {tmp_path}/output
api:
  provider: openai
  api_key: sk-test
  wire_api: responses
""")
    output_dir = tmp_path / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "chat.jsonl").write_text(
        json.dumps({"prompt": "Hello", "response": "Hi", "messages": [{"role": "assistant", "content": "Hi"}]})
        + "\n",
        encoding="utf-8",
    )

    with patch('teich.cli.ChatRunner') as mock_runner:
        mock_instance = MagicMock()
        mock_instance.run_all.side_effect = RuntimeError("boom")
        mock_runner.return_value = mock_instance

        result = runner.invoke(app, ["generate", "-c", str(config_file)])

        assert result.exit_code == 1
        assert "Wrote README for partial outputs" in result.output
        assert "Error: boom" in result.output
        assert (output_dir / "README.md").exists()


def test_generate_command_publishes_dataset_when_publish_repo_is_configured(tmp_path: Path):
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: chat
model:
  model: gpt-4.1-mini
prompts:
  - Hello
output:
  traces_dir: {tmp_path}/output
publish:
  repo_id: armand0e/test-dataset
  hf_token: hf-test123
  private: true
api:
  provider: openai
  api_key: sk-test
  wire_api: responses
""")

    with patch('teich.cli.ChatRunner') as mock_runner, patch('teich.cli.HfApi') as mock_api_cls:
        mock_instance = MagicMock()
        mock_instance.run_all.return_value = [tmp_path / "output/chat-session.jsonl"]
        mock_runner.return_value = mock_instance

        output_dir = tmp_path / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "chat-session.jsonl").write_text(
            '{"messages":[{"role":"system","content":"You are a helpful assistant","thinking":null},{"role":"user","content":"Hello","thinking":null},{"role":"assistant","content":"Hi!","thinking":"I should greet the user."}],"system":"You are a helpful assistant","prompt":"Hello","thinking":"I should greet the user.","response":"Hi!","model":"gpt-4.1-mini","provider":"openai"}\n',
            encoding="utf-8",
        )
        mock_api = MagicMock()
        mock_api.create_repo.return_value = "https://huggingface.co/datasets/armand0e/test-dataset"
        mock_api_cls.return_value = mock_api

        result = runner.invoke(app, ["generate", "-c", str(config_file)])

        assert result.exit_code == 0
        assert "Published dataset: https://huggingface.co/datasets/armand0e/test-dataset" in result.output
        mock_api_cls.assert_called_once_with(token="hf-test123")
        mock_api.create_repo.assert_called_once_with(
            repo_id="armand0e/test-dataset",
            repo_type="dataset",
            private=True,
            exist_ok=True,
        )
        mock_api.delete_file.assert_called_once_with(
            path_in_repo="tools.json",
            repo_id="armand0e/test-dataset",
            repo_type="dataset",
            commit_message="Remove legacy teich tools snapshot",
        )
        mock_api.upload_large_folder.assert_called_once_with(
            repo_id="armand0e/test-dataset",
            folder_path=str(output_dir),
            repo_type="dataset",
            private=True,
            ignore_patterns=["partials/**"],
        )
        mock_api.upload_folder.assert_not_called()


def test_generate_command_prompts_before_publishing_partial_outputs_and_defaults_no(tmp_path: Path):
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: chat
model:
  model: gpt-4.1-mini
prompts:
  - Hello
  - Who are you?
output:
  traces_dir: {tmp_path}/output
publish:
  repo_id: armand0e/test-dataset
  hf_token: hf-test123
api:
  provider: openai
  api_key: sk-test
  wire_api: responses
""")
    output_dir = tmp_path / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "chat.jsonl").write_text(
        json.dumps({"prompt": "Hello", "response": "Hi", "messages": [{"role": "assistant", "content": "Hi"}]})
        + "\n",
        encoding="utf-8",
    )

    with patch('teich.cli.ChatRunner') as mock_runner, patch('teich.cli.HfApi') as mock_api_cls:
        mock_instance = MagicMock()
        mock_instance.run_all.side_effect = RuntimeError("timeout")
        mock_runner.return_value = mock_instance

        result = runner.invoke(app, ["generate", "-c", str(config_file)], input="\n")

        assert result.exit_code == 1
        assert "Wrote README for partial outputs" in result.output
        assert "Upload successful traces to Hugging Face dataset armand0e/test-dataset?" in result.output
        assert "Skipping Hugging Face upload for partial outputs" in result.output
        mock_api_cls.assert_not_called()


def test_generate_command_does_not_prompt_to_publish_after_keyboard_interrupt(tmp_path: Path):
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: chat
model:
  model: gpt-4.1-mini
prompts:
  - Hello
output:
  traces_dir: {tmp_path}/output
publish:
  repo_id: armand0e/test-dataset
  hf_token: hf-test123
api:
  provider: openai
  api_key: sk-test
  wire_api: responses
""")
    output_dir = tmp_path / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "chat.jsonl").write_text(
        json.dumps({"prompt": "Hello", "response": "Hi", "messages": [{"role": "assistant", "content": "Hi"}]})
        + "\n",
        encoding="utf-8",
    )

    with patch('teich.cli.ChatRunner') as mock_runner, patch('teich.cli.HfApi') as mock_api_cls:
        mock_instance = MagicMock()
        mock_instance.run_all.side_effect = KeyboardInterrupt
        mock_runner.return_value = mock_instance

        result = runner.invoke(app, ["generate", "-c", str(config_file)])

        assert result.exit_code == 130
        assert "Wrote README for partial outputs" in result.output
        assert "Upload successful traces to Hugging Face dataset" not in result.output
        assert "Skipping Hugging Face upload for interrupted run" in result.output
        assert 'hf upload armand0e/test-dataset . . --repo-type dataset --exclude "partials/**"' in result.output
        assert "Interrupted. Completed outputs remain on disk" in result.output
        mock_api_cls.assert_not_called()


def test_generate_command_can_publish_partial_outputs_after_failure(tmp_path: Path):
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: chat
model:
  model: gpt-4.1-mini
prompts:
  - Hello
  - Who are you?
output:
  traces_dir: {tmp_path}/output
publish:
  repo_id: armand0e/test-dataset
  hf_token: hf-test123
api:
  provider: openai
  api_key: sk-test
  wire_api: responses
""")
    output_dir = tmp_path / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "chat.jsonl").write_text(
        json.dumps({"prompt": "Hello", "response": "Hi", "messages": [{"role": "assistant", "content": "Hi"}]})
        + "\n",
        encoding="utf-8",
    )
    (output_dir / "partials").mkdir()
    (output_dir / "partials" / "partial.jsonl").write_text("partial\n", encoding="utf-8")

    with patch('teich.cli.ChatRunner') as mock_runner, patch('teich.cli.HfApi') as mock_api_cls:
        mock_instance = MagicMock()
        mock_instance.run_all.side_effect = RuntimeError("timeout")
        mock_runner.return_value = mock_instance
        mock_api = MagicMock()
        mock_api.create_repo.return_value = "https://huggingface.co/datasets/armand0e/test-dataset"
        mock_api_cls.return_value = mock_api

        result = runner.invoke(app, ["generate", "-c", str(config_file)], input="y\n")

        assert result.exit_code == 1
        assert "Published partial dataset: https://huggingface.co/datasets/armand0e/test-dataset" in result.output
        mock_api.delete_file.assert_called_once_with(
            path_in_repo="tools.json",
            repo_id="armand0e/test-dataset",
            repo_type="dataset",
            commit_message="Remove legacy teich tools snapshot",
        )
        mock_api.upload_large_folder.assert_called_once_with(
            repo_id="armand0e/test-dataset",
            folder_path=str(output_dir),
            repo_type="dataset",
            private=False,
            ignore_patterns=["partials/**"],
        )
        mock_api.upload_folder.assert_not_called()


def test_generate_command_deduplicates_configured_prompts_before_running(tmp_path: Path):
    config_file = tmp_path / "config.yaml"
    config_file.write_text(f"""
agent:
  provider: chat
model:
  model: gpt-4.1-mini
prompts:
  - Hello
  - Hello
  - Who are you?
output:
  traces_dir: {tmp_path}/output
api:
  provider: openai
  api_key: sk-test
  wire_api: responses
""")

    with patch('teich.cli.ChatRunner') as mock_runner:
        mock_instance = MagicMock()
        mock_instance.run_all.return_value = [tmp_path / "output/chat.jsonl"]
        mock_runner.return_value = mock_instance
        output_dir = tmp_path / "output"
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "chat.jsonl").write_text(
            json.dumps({"prompt": "Hello", "response": "Hi", "messages": [{"role": "assistant", "content": "Hi"}]})
            + "\n",
            encoding="utf-8",
        )

        result = runner.invoke(app, ["generate", "-c", str(config_file)])

        assert result.exit_code == 0
        kwargs = mock_instance.run_all.call_args.kwargs
        assert [prompt_input.prompt for prompt_input in kwargs["prompt_inputs"]] == ["Hello", "Who are you?"]


def test_batch_progress_reporter_only_shows_queued_and_running_rows():
    console = Console(record=True, width=160)
    reporter = BatchProgressReporter(console)

    reporter.update(
        SessionProgressUpdate(
            prompt_id="queued-1",
            prompt_index=1,
            total_prompts=3,
            prompt="Queued prompt",
            prompt_preview="Queued prompt",
            status="queued",
        )
    )
    reporter.update(
        SessionProgressUpdate(
            prompt_id="running-1",
            prompt_index=2,
            total_prompts=3,
            prompt="Running prompt",
            prompt_preview="Running prompt",
            status="running",
            metrics=TraceMetrics(total_tokens=42, total_cost=0.125, model="codex-mini-latest"),
        )
    )
    reporter.update(
        SessionProgressUpdate(
            prompt_id="completed-1",
            prompt_index=3,
            total_prompts=3,
            prompt="Completed prompt",
            prompt_preview="Completed prompt",
            status="completed",
            metrics=TraceMetrics(total_tokens=99, total_cost=0.5, model="codex-mini-latest"),
        )
    )

    console.print(reporter._render())
    output = console.export_text()

    assert "queued=1 running=1 completed=1 failed=0" in output
    assert "tokens=141" in output
    assert "Queued prompt" in output
    assert "Running prompt" in output
    assert "Completed prompt" not in output
    assert "api tokens" not in output
    assert "est. total" not in output


def test_batch_progress_reporter_marks_unknown_usage_as_na():
    console = Console(record=True, width=160)
    reporter = BatchProgressReporter(console)

    reporter.update(
        SessionProgressUpdate(
            prompt_id="running-1",
            prompt_index=1,
            total_prompts=1,
            prompt="Running prompt",
            prompt_preview="Running prompt",
            status="running",
            metrics=TraceMetrics(model="minimax/minimax-m2.5:free"),
        )
    )

    console.print(reporter._render())
    output = console.export_text()

    assert "tokens=N/A cost=N/A" in output
    assert "minimax/minimax-m2.5:free" in output


def test_batch_progress_reporter_refreshes_elapsed_without_status_update():
    reporter = BatchProgressReporter(Console(record=True, width=160))
    fake_live = MagicMock()
    reporter._live = fake_live
    reporter.update(
        SessionProgressUpdate(
            prompt_id="running-1",
            prompt_index=1,
            total_prompts=1,
            prompt="Running prompt",
            prompt_preview="Running prompt",
            status="running",
            started_at=datetime.now(timezone.utc) - timedelta(seconds=65),
        )
    )

    reporter._refresh_live_once()

    assert fake_live.update.call_count >= 2
    refreshed_renderable = fake_live.update.call_args.args[0]
    console = Console(record=True, width=160)
    console.print(refreshed_renderable)
    assert "01:05" in console.export_text()
