"""GDB system tools — status, tag listing, instance listing, and authentication."""

from __future__ import annotations

import logging
from typing import Any

import httpx
from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_common.auth_diagnose import _infer_auth_type
from mcp_eregistrations_gdb.gdb_client import GDBClient, GDBClientError, translate_error
from mcp_eregistrations_gdb.server import mcp

logger = logging.getLogger(__name__)


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_auth_token(instance: str | None = None) -> dict[str, Any]:
    """Get a raw bearer token for external integrations.

    Returns a short-lived access token (~5 min) for use in Node,
    shell, cron, or other non-Python runtimes that need GDB access.
    Requires prior authentication via gdb_auth_login.

    Args:
        instance: Instance name (default: auto-select).

    Returns:
        dict with access_token, token_endpoint, client_id, instance.
    """
    from mcp_eregistrations_common.auth import get_or_refresh_token
    from mcp_eregistrations_common.auth_store import get_refresh_context
    from mcp_eregistrations_common.config import resolve_auth_key

    inst = resolve_auth_key(instance)

    token = await get_or_refresh_token(inst)
    if not token:
        raise ToolError(
            f"No valid token for '{inst}'. Run gdb_auth_login first to authenticate."
        )

    # Include metadata so consumers can refresh independently
    ctx = get_refresh_context(inst)
    result: dict[str, Any] = {
        "access_token": token,
        "instance": inst,
    }
    if ctx:
        result["token_endpoint"] = ctx.get("token_endpoint", "")
        result["client_id"] = ctx.get("client_id", "")

    return result


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_status(
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Get GDB server health and version.

    Args:
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with version, status, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            result: dict[str, Any] = await client.get("/api/v1/status")
            result["trace_id"] = client.trace_id
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="status") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_tag_list(
    trace_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """List all GDB tags.

    Args:
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).
        instance: Instance name (default: auto-select).

    Returns:
        dict with count, tags, trace_id.
    """
    try:
        async with GDBClient.for_instance(instance, trace_id=trace_id) as client:
            data = await client.get("/api/v1/tags")
            raw = data if isinstance(data, list) else data.get("results", [])
            tags = [
                {
                    "id": t.get("id"),
                    "name": t.get("name"),
                }
                for t in raw
            ]
            return {
                "count": len(tags),
                "tags": tags,
                "trace_id": client.trace_id,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="tag") from e


@mcp.tool()
async def gdb_auth_login(
    username: str | None = None,
    password: str | None = None,
    instance: str | None = None,
    force_refresh: bool = False,
) -> dict[str, Any]:
    """Authenticate with eRegistrations. Shared across BPA/GDB/DS.

    Tries silent auto-login from stored credentials/tokens first.
    Only asks for credentials when no stored auth is available.

    Args:
        username: Username (email). Required on first login.
        password: Password. Required on first login.
        instance: Instance name (default: auto-select).
        force_refresh: Evict cached token before re-auth (default: False).

    Returns:
        dict with success, user_email, instance (plus refreshed when applicable).
    """
    from mcp_eregistrations_common.auth import (
        AuthenticationError,
        clear_cached_token,
        get_or_refresh_token,
        keycloak_password_grant,
    )
    from mcp_eregistrations_common.auth_store import (
        get_credentials,
        store_credentials,
        store_refresh_context,
    )
    from mcp_eregistrations_common.config import (
        get_instance_config,
        resolve_auth_key,
    )

    inst = resolve_auth_key(instance)

    # 1. Try silent auto-login (stored tokens/credentials from BPA login).
    #    force_refresh=True skips this branch so we go straight to a fresh mint.
    if not username and not force_refresh:
        token = await get_or_refresh_token(inst)
        if token:
            creds = get_credentials(inst)
            return {
                "success": True,
                "message": f"Authenticated as {creds[0] if creds else 'stored user'}.",
                "user_email": creds[0] if creds else "stored user",
                "instance": inst,
            }

    # 1b. force_refresh without explicit creds: evict cache, attempt
    #     refresh-token grant (or stored-creds password grant) via common plumbing.
    if not username and force_refresh:
        token = await get_or_refresh_token(inst, force_refresh=True)
        if token:
            creds = get_credentials(inst)
            return {
                "success": True,
                "refreshed": True,
                "message": (
                    f"Token refreshed for {creds[0] if creds else 'stored user'}."
                ),
                "user_email": creds[0] if creds else "stored user",
                "instance": inst,
            }
        return {
            "action_required": "ask_credentials",
            "message": (
                f"Cache cleared for '{inst}' but no refresh token or stored "
                "credentials were available. Provide username/password, or "
                "login via BPA MCP first."
            ),
            "instance": inst,
        }

    # 2. Try provided credentials, fall back to stored
    if not username or not password:
        creds = get_credentials(inst)
        if creds:
            username, password = creds
    if not username or not password:
        return {
            "action_required": "ask_credentials",
            "message": (
                f"No stored credentials for '{inst}'. "
                "Provide username and password, or login via BPA MCP first."
            ),
            "instance": inst,
        }

    # 3. Keycloak password grant
    config = get_instance_config(inst)
    keycloak_url = config.get("keycloak_url")
    if not keycloak_url or not config.get("keycloak_realm"):
        raise ToolError(
            f"No Keycloak configuration for '{inst}' "
            "(keycloak_url or keycloak_realm missing). "
            "For CAS instances, login via BPA MCP first — GDB will auto-authenticate."
        )

    if force_refresh:
        clear_cached_token(inst)

    try:
        result = await keycloak_password_grant(
            keycloak_url=keycloak_url,
            realm=config["keycloak_realm"],
            client_id=config.get("keycloak_client_id", "mcp-eregistrations-bpa"),
            username=username,
            password=password,
        )
    except (AuthenticationError, httpx.RequestError, ValueError) as e:
        # Narrow catch: AuthenticationError from keycloak_password_grant,
        # httpx.RequestError for network failures, ValueError for malformed
        # JSON responses. Unrelated exceptions (RuntimeError, TypeError, etc.)
        # propagate so bugs surface rather than being mis-wrapped as auth failures.
        raise ToolError(f"Authentication failed for '{inst}': {e}") from e

    store_credentials(
        inst,
        username,
        password,
        keycloak_url=keycloak_url,
        keycloak_realm=config["keycloak_realm"],
        client_id=config.get("keycloak_client_id", "mcp-eregistrations-bpa"),
    )
    store_refresh_context(
        inst,
        refresh_token=result.get("refresh_token", ""),
        token_endpoint=result["token_endpoint"],
        client_id=config.get("keycloak_client_id", "mcp-eregistrations-bpa"),
    )

    return {
        "success": True,
        "message": f"Authenticated as {username}.",
        "user_email": username,
        "instance": inst,
    }


@mcp.tool()
async def gdb_auth_clear(
    instance: str | None = None,
    clear_refresh_token: bool = False,
) -> dict[str, Any]:
    """Clear cached auth state for an instance. Idempotent.

    Evicts the in-memory access token so the next call re-authenticates.
    Set clear_refresh_token=True to also drop the stored refresh token
    (forces a full re-login via credentials or BPA MCP on next call).

    Args:
        instance: Instance name (default: auto-select).
        clear_refresh_token: Also drop stored refresh token (default: False).

    Returns:
        dict with success, instance, cleared_access_token,
        cleared_refresh_token, next_action.
    """
    from mcp_eregistrations_common.auth import clear_cached_token
    from mcp_eregistrations_common.auth_store import (
        clear_refresh_context,
        get_credentials,
        get_refresh_context,
    )
    from mcp_eregistrations_common.config import (
        get_instance_config,
        resolve_auth_key,
    )

    inst = resolve_auth_key(instance)
    config = get_instance_config(inst)
    auth_type = _infer_auth_type(config)

    cleared_access = clear_cached_token(inst)
    cleared_refresh = clear_refresh_context(inst) if clear_refresh_token else False

    has_refresh = get_refresh_context(inst) is not None
    has_creds = get_credentials(inst) is not None

    if auth_type == "cas":
        next_action = {
            "code": "call_bpa_auth_login",
            "message": (
                "CAS instance: run BPA MCP `auth_login` (silent or with "
                "credentials) to re-establish the session. GDB will pick up "
                "the new token on the next call."
            ),
        }
    elif has_refresh:
        next_action = {
            "code": "retry_any_call",
            "message": (
                "Cache cleared. The next GDB call will silently re-auth via "
                "the stored refresh token."
            ),
        }
    elif auth_type == "keycloak" and has_creds:
        next_action = {
            "code": "call_gdb_auth_login",
            "message": (
                "No refresh token on file. Run `gdb_auth_login` (stored "
                "credentials will be used) to mint a fresh token."
            ),
        }
    else:
        next_action = {
            "code": "call_bpa_auth_login",
            "message": (
                "No auth material available. Run BPA MCP `auth_login` with "
                "credentials, then GDB will silently re-auth."
            ),
        }

    return {
        "success": True,
        "instance": inst,
        "cleared_access_token": cleared_access,
        "cleared_refresh_token": cleared_refresh,
        "next_action": next_action,
    }


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_auth_diagnose(
    instance: str | None = None,
    trace_id: str | None = None,
) -> dict[str, Any]:
    """Diagnose the current GDB auth state without mutating it.

    Reads the cached bearer token, decodes its claims (if JWT), and probes
    GET /api/v1/status directly to see whether the backend currently accepts
    the token. Safe, read-only, no re-authentication.

    Args:
        instance: Instance name (default: auto-select).
        trace_id: Optional trace ID for log correlation (auto-generated if omitted).

    Returns:
        dict with instance, auth_type, token_present, token_format,
        token_claims, refresh_context, probe, hints, trace_id.
    """
    from mcp_eregistrations_common.auth_diagnose import diagnose_auth
    from mcp_eregistrations_common.config import get_instance_config, resolve_auth_key

    inst = resolve_auth_key(instance)
    config = get_instance_config(inst)
    gdb_url = config.get("gdb_url", "")
    probe_url = f"{gdb_url.rstrip('/')}/api/v1/status" if gdb_url else None

    return await diagnose_auth(
        instance=inst,
        trace_id=trace_id,
        server_label="GDB",
        login_tool_name="gdb_auth_login",
        probe_url=probe_url,
    )
