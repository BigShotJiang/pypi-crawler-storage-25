"""Shared authentication for MCP eRegistrations components.

Provides:
- Keycloak password grant (used by all components)
- Token sharing via AuthStore (access + refresh tokens)
- Cross-server token resolution (login once, use everywhere)
- JWT claim decoding for diagnostic display (no signature verification)
"""

from __future__ import annotations

import base64
import json
import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)


def decode_jwt_claims(token: str) -> dict[str, Any] | None:
    """Decode a JWT's payload claims without verifying the signature.

    Returns None for tokens that are empty, opaque, malformed, or whose
    payload is not JSON. Used only for diagnostic display — never for
    authorization decisions.
    """
    if not token:
        return None
    parts = token.split(".")
    if len(parts) != 3:
        return None
    payload_b64 = parts[1]
    padded = payload_b64 + "=" * (-len(payload_b64) % 4)
    try:
        decoded = base64.urlsafe_b64decode(padded.encode("ascii"))
        claims = json.loads(decoded)
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    if not isinstance(claims, dict):
        return None
    return claims


class AuthenticationError(Exception):
    """Authentication failed."""


# ---------------------------------------------------------------------------
# In-memory token cache (per-process)
# ---------------------------------------------------------------------------

_access_tokens: dict[str, str] = {}

# Diagnostic state: records the last refresh-token failure reason per
# instance so gdb_auth_diagnose and equivalents can surface it. Set by
# get_or_refresh_token when refresh_access_token raises; cleared on any
# successful token mint. Not a security boundary — display only.
_refresh_failures: dict[str, str] = {}


def get_cached_token(instance: str) -> str | None:
    """Get access token from in-memory cache."""
    return _access_tokens.get(instance)


def get_last_refresh_failure(instance: str) -> str | None:
    """Return the last recorded refresh-token failure reason for this instance.

    Returns None if no failure has been recorded or it has been cleared by
    a subsequent successful token mint.
    """
    return _refresh_failures.get(instance)


def clear_cached_token(instance: str) -> bool:
    """Evict the in-memory access token (and last refresh-failure) for an instance.

    Returns True if an access token was present and was evicted, False otherwise.
    Also clears the diagnostic refresh-failure entry so the next mint starts
    with a clean slate. Idempotent.
    """
    had_token = instance in _access_tokens
    _access_tokens.pop(instance, None)
    _refresh_failures.pop(instance, None)
    return had_token


# ---------------------------------------------------------------------------
# Token storage (thin wrapper over AuthStore)
# ---------------------------------------------------------------------------


def store_shared_tokens(
    instance: str,
    *,
    access_token: str,
    refresh_token: str | None = None,
    token_endpoint: str | None = None,
    client_id: str | None = None,
) -> None:
    """Store tokens in memory and persist refresh context to AuthStore.

    Args:
        instance: Instance name (e.g., "jamaica").
        access_token: Access token to cache in memory.
        refresh_token: Refresh token to persist for cross-session auth.
        token_endpoint: Token endpoint URL (stored with refresh token).
        client_id: Client ID (stored with refresh token).
    """
    _access_tokens[instance] = access_token

    if refresh_token and token_endpoint and client_id:
        from mcp_eregistrations_common.auth_store import store_refresh_context

        try:
            store_refresh_context(
                instance,
                refresh_token=refresh_token,
                token_endpoint=token_endpoint,
                client_id=client_id,
            )
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Keycloak operations
# ---------------------------------------------------------------------------


async def keycloak_password_grant(
    *,
    keycloak_url: str,
    realm: str,
    client_id: str,
    username: str,
    password: str,
    verify_ssl: bool = True,
) -> dict[str, Any]:
    """Authenticate via Keycloak password grant.

    Args:
        keycloak_url: Keycloak base URL.
        realm: Keycloak realm.
        client_id: OIDC client ID.
        username: Username.
        password: Password.

    Returns:
        dict with access_token, refresh_token, expires_in, token_endpoint.

    Raises:
        AuthenticationError: If discovery or auth fails.
    """
    well_known = (
        f"{keycloak_url.rstrip('/')}/realms/{realm}/.well-known/openid-configuration"
    )

    async with httpx.AsyncClient(verify=verify_ssl) as client:
        # Discover token endpoint
        discovery = await client.get(well_known)
        if discovery.status_code != 200:
            raise AuthenticationError(
                f"OIDC discovery failed at {well_known} "
                f"(HTTP {discovery.status_code}). "
                "Check keycloak_url and realm."
            )
        token_endpoint = discovery.json().get("token_endpoint")
        if not token_endpoint:
            raise AuthenticationError("OIDC discovery response missing token_endpoint.")

        # Password grant
        token_response = await client.post(
            token_endpoint,
            data={
                "grant_type": "password",
                "client_id": client_id,
                "username": username,
                "password": password,
            },
        )

        if token_response.status_code != 200:
            error = "Unknown error"
            try:
                error = token_response.json().get("error_description", error)
            except Exception:
                error = token_response.text
            raise AuthenticationError(
                f"Authentication failed for '{username}': {error}"
            )

        result: dict[str, Any] = token_response.json()
        result["token_endpoint"] = token_endpoint
        return result


async def refresh_access_token(
    *,
    token_endpoint: str,
    client_id: str,
    refresh_token: str,
    client_secret: str | None = None,
    redirect_uri: str | None = None,
    verify_ssl: bool = True,
) -> dict[str, Any]:
    """Exchange refresh token for new access token.

    Supports both Keycloak (client_id in body) and CAS (Basic Auth +
    redirect_uri). CAS params are optional — when present, the request
    uses Basic Auth header instead of client_id in body.

    Args:
        token_endpoint: Token endpoint URL.
        client_id: OIDC/OAuth client ID.
        refresh_token: Refresh token.
        client_secret: CAS client secret (enables Basic Auth).
        redirect_uri: CAS redirect URI (required by CAS servers).

    Returns:
        dict with access_token, refresh_token, expires_in.

    Raises:
        AuthenticationError: If refresh fails.
    """
    headers: dict[str, str] = {}
    data: dict[str, str] = {
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
    }

    if client_secret:
        # CAS: Basic Auth header + redirect_uri (CAS requires redirect_uri
        # on ALL /access_token calls, even refresh_token grants)
        import base64

        creds = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
        headers["Authorization"] = f"Basic {creds}"
        headers["Content-Type"] = "application/x-www-form-urlencoded"
        data["redirect_uri"] = redirect_uri or "http://127.0.0.1:9876/callback"
    else:
        # Keycloak: client_id in body
        data["client_id"] = client_id

    async with httpx.AsyncClient(verify=verify_ssl) as client:
        response = await client.post(token_endpoint, headers=headers, data=data)

        if response.status_code != 200:
            # Prefer the most specific field available. CAS responses omit
            # error_description but carry `fail_reason` + `error`; Keycloak
            # uses `error_description` + `error`. Fall back to raw text only
            # when the body isn't JSON.
            error = "Unknown error"
            try:
                body = response.json()
                error = (
                    body.get("error_description")
                    or body.get("fail_reason")
                    or body.get("error")
                    or error
                )
            except Exception:
                error = response.text
            raise AuthenticationError(f"Token refresh failed: {error}")

        result: dict[str, Any] = response.json()
        return result


async def get_or_refresh_token(
    instance: str, *, force_refresh: bool = False
) -> str | None:
    """Get a valid access token: cache -> refresh -> password grant -> None.

    Args:
        instance: Instance name.
        force_refresh: If True, evict the in-memory cache before lookup so
            the refresh-token or password-grant path must run. Used by the
            401 retry path to recover from a stale cached token that the
            backend has begun rejecting.

    Returns:
        Access token string, or None if no token available.
    """
    if force_refresh:
        _access_tokens.pop(instance, None)

    # 1. In-memory cache — force_refresh=True evicts above; otherwise a hit
    #    here short-circuits and returns the cached token without re-contacting
    #    the auth server.
    token = _access_tokens.get(instance)
    if token:
        return token

    from mcp_eregistrations_common.auth_store import (
        get_auth_config,
        get_credentials,
        get_refresh_context,
        store_refresh_context,
    )
    from mcp_eregistrations_common.config import get_builtin_instance, load_profiles

    profiles = load_profiles()
    profile = profiles.get(instance) or get_builtin_instance(instance) or {}
    verify_ssl = profile.get("verify_ssl", True)

    # 2. Refresh token
    ctx = get_refresh_context(instance)
    # Invariant: auth_store.get_refresh_context() writes refresh_token,
    # token_endpoint, and client_id together. Guarding all three defensively
    # here so a hand-edited auth.json with a partial entry can't KeyError out.
    if (
        ctx
        and ctx.get("refresh_token")
        and ctx.get("token_endpoint")
        and ctx.get("client_id")
    ):
        try:
            result = await refresh_access_token(
                token_endpoint=ctx["token_endpoint"],
                client_id=ctx["client_id"],
                refresh_token=ctx["refresh_token"],
                client_secret=ctx.get("cas_client_secret"),
                redirect_uri=ctx.get("redirect_uri"),
                verify_ssl=verify_ssl,
            )
            store_refresh_context(
                instance,
                refresh_token=result.get("refresh_token", ctx["refresh_token"]),
                token_endpoint=ctx["token_endpoint"],
                client_id=ctx["client_id"],
                cas_client_secret=ctx.get("cas_client_secret"),
                redirect_uri=ctx.get("redirect_uri"),
            )
            access_token: str = result["access_token"]
            _access_tokens[instance] = access_token
            # Mint succeeded — clear any stale diagnostic.
            _refresh_failures.pop(instance, None)
            return access_token
        except AuthenticationError as e:
            # Record the reason so gdb_auth_diagnose can surface it. The
            # silent swallow that used to live here hid the exact signal
            # users need to diagnose "why are my requests unauthenticated?"
            # (issue #86).
            _refresh_failures[instance] = str(e)
        except Exception as e:
            # Non-auth exceptions (network, decode, etc.) — still record so
            # the user gets a diagnostic breadcrumb instead of a silent None.
            _refresh_failures[instance] = f"{type(e).__name__}: {e}"

    # 3. Password grant from stored credentials
    creds = get_credentials(instance)
    auth_cfg = get_auth_config(instance)

    # 3a. Keycloak password grant (OIDC discovery + grant)
    # Invariant: auth_store.get_auth_config() returns non-None only when both
    # keycloak_url AND keycloak_realm are present. Guarding both defensively
    # here so a future refactor can't silently re-introduce issue #93's
    # KeyError class on realm lookup.
    if (
        creds
        and auth_cfg
        and auth_cfg.get("keycloak_url")
        and auth_cfg.get("keycloak_realm")
    ):
        try:
            result = await keycloak_password_grant(
                keycloak_url=auth_cfg["keycloak_url"],
                realm=auth_cfg["keycloak_realm"],
                client_id=auth_cfg.get("client_id", "mcp-eregistrations-bpa"),
                username=creds[0],
                password=creds[1],
                verify_ssl=verify_ssl,
            )
            store_refresh_context(
                instance,
                refresh_token=result.get("refresh_token", ""),
                token_endpoint=result["token_endpoint"],
                client_id=auth_cfg.get("client_id", "mcp-eregistrations-bpa"),
            )
            access_token2: str = result["access_token"]
            _access_tokens[instance] = access_token2
            # Mint succeeded — clear any stale diagnostic.
            _refresh_failures.pop(instance, None)
            return access_token2
        except Exception:
            pass

    return None
