# Numera/NeuralNet/rnn.py
import numpy as np
from Numera.Core.Matrices import Matrix
from Numera.NeuralNet.nn import NN


class Embedding:
    """Table de vecteurs — convertit un index en vecteur dense"""

    def __init__(self, vocab_size, embed_dim):
        NN.seed(42)
        self.W = Matrix(np.random.randn(vocab_size, embed_dim) * 0.01)
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim

    def forward(self, idx):
        """idx : entier → vecteur (embed_dim × 1)"""
        return Matrix(self.W._data[idx].reshape(-1, 1))

    def backward(self, idx, dout, lr):
        self.W._data[idx] -= lr * dout._data.flatten()


class GRUCell:
    """
    Cellule GRU (Gated Recurrent Unit)
    Mieux qu'un RNN simple — gère les dépendances longues.

    Formules :
      z = sigmoid(Wz·[h, x] + bz)   ← porte de mise à jour
      r = sigmoid(Wr·[h, x] + br)   ← porte de réinitialisation
      h̃ = tanh(Wh·[r*h, x] + bh)   ← état candidat
      h = (1-z)*h + z*h̃             ← nouvel état caché
    """

    def __init__(self, input_dim, hidden_dim):
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        k = np.sqrt(1 / hidden_dim)

        # Poids des 3 portes — concaténés [h, x]
        def W(rows): return Matrix(np.random.uniform(-k, k, (rows, hidden_dim + input_dim)))
        def b(rows): return Matrix(np.zeros((rows, 1)))

        self.Wz, self.bz = W(hidden_dim), b(hidden_dim)
        self.Wr, self.br = W(hidden_dim), b(hidden_dim)
        self.Wh, self.bh = W(hidden_dim), b(hidden_dim)

        self.cache = {}

    def forward(self, x, h_prev):
        """
        x      : (input_dim × 1)
        h_prev : (hidden_dim × 1)
        retourne h_new : (hidden_dim × 1)
        """
        hx = Matrix(np.vstack([h_prev._data, x._data]))

        z  = NN.sigmoid((self.Wz @ hx) + self.bz)
        r  = NN.sigmoid((self.Wr @ hx) + self.br)
        rh = Matrix(r._data * h_prev._data)
        rhx = Matrix(np.vstack([rh._data, x._data]))
        h_hat = NN.tanh((self.Wh @ rhx) + self.bh)
        h_new = Matrix((1.0 - z._data) * h_prev._data + z._data * h_hat._data)

        # Sauvegarder pour backprop
        self.cache = dict(x=x, h_prev=h_prev, hx=hx,
                          z=z, r=r, rh=rh, rhx=rhx,
                          h_hat=h_hat, h_new=h_new)
        return h_new

    def backward(self, dh_new, lr):
        c = self.cache
        h_prev, x = c['h_prev'], c['x']
        z, r, h_hat = c['z'], c['r'], c['h_hat']

        # Gradient h̃
        dh_hat = Matrix(dh_new._data * z._data)
        dh_hat_raw = Matrix(dh_hat._data * (1 - h_hat._data ** 2))

        # Gradient z
        dz = Matrix(dh_new._data * (h_hat._data - h_prev._data))
        dz_raw = Matrix(dz._data * z._data * (1 - z._data))

        # Gradient Wh, bh
        dWh = dh_hat_raw @ c['rhx'].T
        dbh = Matrix(dh_hat_raw._data.sum(axis=1, keepdims=True))

        # Gradient Wz, bz
        dWz = dz_raw @ c['hx'].T
        dbz = Matrix(dz_raw._data.sum(axis=1, keepdims=True))

        # Gradient r
        d_rhx = self.Wh.T @ dh_hat_raw
        d_rh = Matrix(d_rhx._data[:self.hidden_dim])
        dr = Matrix(d_rh._data * h_prev._data)
        dr_raw = Matrix(dr._data * r._data * (1 - r._data))
        dWr = dr_raw @ c['hx'].T
        dbr = Matrix(dr_raw._data.sum(axis=1, keepdims=True))

        # Gradient h_prev
        dh_prev = Matrix(dh_new._data * (1 - z._data) +
                         (self.Wr.T @ dr_raw)._data[:self.hidden_dim] +
                         (self.Wz.T @ dz_raw)._data[:self.hidden_dim] +
                         d_rh._data * r._data)

        # Gradient x
        dx = Matrix((self.Wh.T @ dh_hat_raw)._data[self.hidden_dim:] +
                    (self.Wz.T @ dz_raw)._data[self.hidden_dim:] +
                    (self.Wr.T @ dr_raw)._data[self.hidden_dim:])

        # Mise à jour
        self.Wz = self.Wz - dWz * lr
        self.bz = self.bz - dbz * lr
        self.Wr = self.Wr - dWr * lr
        self.br = self.br - dbr * lr
        self.Wh = self.Wh - dWh * lr
        self.bh = self.bh - dbh * lr

        return dx, dh_prev


class CharLM:
    """
    Mini LLM character-level avec GRU.
    Apprend à prédire le caractère suivant.
    """

    def __init__(self, text, hidden_dim=128, embed_dim=32, lr=0.001):
        # Vocabulaire
        self.chars = sorted(set(text))
        self.vocab_size = len(self.chars)
        self.ch2idx = {c: i for i, c in enumerate(self.chars)}
        self.idx2ch = {i: c for i, c in enumerate(self.chars)}
        self.lr = lr
        self.hidden_dim = hidden_dim

        print(f"  Vocabulaire : {self.vocab_size} caractères")
        print(f"  Texte       : {len(text)} caractères")

        # Couches
        self.embed = Embedding(self.vocab_size, embed_dim)
        self.gru   = GRUCell(embed_dim, hidden_dim)
        self.Wy    = Matrix(np.random.randn(self.vocab_size, hidden_dim) * 0.01)
        self.by    = Matrix(np.zeros((self.vocab_size, 1)))

    def _forward_step(self, idx, h):
        x = self.embed.forward(idx)
        h = self.gru.forward(x, h)
        logits = (self.Wy @ h) + self.by
        probs = NN.softmax(logits)
        return probs, h, x

    def _loss(self, probs, target_idx):
        p = float(probs._data[target_idx, 0])
        return -np.log(max(p, 1e-8))

    def train(self, text, epochs=50, seq_len=25, verbose=True):
        """Entraîne le modèle sur le texte"""
        losses = []

        for epoch in range(epochs):
            epoch_loss = 0.0
            h = Matrix(np.zeros((self.hidden_dim, 1)))
            n_seq = 0

            for start in range(0, len(text) - seq_len, seq_len):
                seq = text[start:start + seq_len + 1]
                hs, probs_list, xs, idxs = [], [], [], []

                h = Matrix(np.zeros((self.hidden_dim, 1)))

                # Forward
                loss = 0.0
                for t in range(len(seq) - 1):
                    idx = self.ch2idx[seq[t]]
                    target = self.ch2idx[seq[t + 1]]
                    probs, h, x = self._forward_step(idx, h)
                    loss += self._loss(probs, target)
                    hs.append(h)
                    probs_list.append(probs)
                    xs.append(x)
                    idxs.append(idx)

                loss /= (len(seq) - 1)
                epoch_loss += loss
                n_seq += 1

                # Backward (BPTT)
                dh = Matrix(np.zeros((self.hidden_dim, 1)))
                for t in reversed(range(len(seq) - 1)):
                    target = self.ch2idx[seq[t + 1]]
                    dlogits = probs_list[t]._data.copy()
                    dlogits[target] -= 1.0
                    dlogits = Matrix(dlogits / (len(seq) - 1))

                    # Gradient Wy, by
                    h_t = hs[t]
                    dWy = dlogits @ h_t.T
                    dby = dlogits
                    self.Wy = self.Wy - dWy * self.lr
                    self.by = self.by - dby * self.lr

                    dh_from_y = Matrix(self.Wy.T._data @ dlogits._data)
                    dh_total = Matrix(dh_from_y._data + dh._data)

                    dx, dh = self.gru.backward(dh_total, self.lr)
                    self.embed.backward(idxs[t], dx, self.lr)

            epoch_loss /= max(n_seq, 1)
            losses.append(epoch_loss)

            if verbose and epoch % 5 == 0:
                sample = self.generate("Le ", n=40)
                print(f"  Epoch {epoch:3d} — Loss : {epoch_loss:.4f} — '{sample}'")

        return losses

    def generate(self, seed, n=100, temperature=0.8):
        """Génère du texte à partir d'une graine"""
        h = Matrix(np.zeros((self.hidden_dim, 1)))
        result = seed

        # Initialiser avec la graine
        for c in seed:
            if c in self.ch2idx:
                idx = self.ch2idx[c]
                probs, h, _ = self._forward_step(idx, h)

        # Générer
        idx = self.ch2idx.get(seed[-1], 0)
        for _ in range(n):
            probs, h, _ = self._forward_step(idx, h)
            # Temperature sampling
            p = probs._data.flatten().astype(np.float64)
            p = np.exp(np.log(p + 1e-8) / temperature)
            p /= p.sum()
            idx = np.random.choice(len(p), p=p)
            result += self.idx2ch[idx]

        return result
