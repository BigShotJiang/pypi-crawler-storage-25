# Numera/NeuralNet/nn.py
import numpy as np
from . import _nn_core as _core
from Numera.Core.Matrices import Matrix
from .visualizer import visualize_network


class NN:

    # ── Génération de matrices ─────────────────────────────────
    @staticmethod
    def seed(n):
        np.random.seed(n)

    @staticmethod
    def zeros(rows, cols):
        return Matrix(_core.zeros(rows, cols))

    @staticmethod
    def ones(rows, cols):
        return Matrix(_core.ones(rows, cols))

    @staticmethod
    def random(rows, cols):
        return Matrix(_core.random_matrix(rows, cols))

    # ── Fonctions d'activation ─────────────────────────────────
    @staticmethod
    def sigmoid(m):
        return Matrix(_core.sigmoid(m._data))

    @staticmethod
    def sigmoid_deriv(m):
        return Matrix(_core.sigmoid_deriv(m._data))

    @staticmethod
    def relu(m):
        return Matrix(_core.relu(m._data))

    @staticmethod
    def relu_deriv(m):
        return Matrix(_core.relu_deriv(m._data))

    @staticmethod
    def tanh(m):
        return Matrix(_core.tanh_f(m._data))

    @staticmethod
    def tanh_deriv(m):
        return Matrix(_core.tanh_deriv(m._data))

    @staticmethod
    def softmax(m):
        return Matrix(_core.softmax(m._data))

    # ── Fonctions de perte ─────────────────────────────────────
    @staticmethod
    def mse(y_pred, y_true):
        """Mean Squared Error"""
        return _core.mse(y_pred._data, y_true._data)

    @staticmethod
    def mse_deriv(y_pred, y_true):
        return Matrix(_core.mse_deriv(y_pred._data, y_true._data))

    @staticmethod
    def binary_cross_entropy(y_pred, y_true):
        """Binary Cross-Entropy"""
        return _core.binary_cross_entropy(y_pred._data, y_true._data)

    @staticmethod
    def cross_entropy(y_pred, y_true):
        """Categorical Cross-Entropy"""
        return _core.cross_entropy(y_pred._data, y_true._data)

    # ── Initialisation des poids ───────────────────────────────
    @staticmethod
    def xavier(fan_in, fan_out):
        """Initialisation Xavier — recommandée pour sigmoid/tanh"""
        return Matrix(_core.xavier(fan_in, fan_out))

    @staticmethod
    def he(fan_in, fan_out):
        """Initialisation He — recommandée pour ReLU"""
        return Matrix(_core.he(fan_in, fan_out))
    
    @staticmethod
    def visualize(layers, weights=None, biases=None, title="Réseau de neurones"):
        """
        Affiche une fenêtre de visualisation du réseau.

        Example
        -------
        NN.visualize([3, 4, 1], [W1, W2], [b1, b2])
        """
        visualize_network(layers, weights, biases, title)
