# Numera/NeuralNet/visualizer.py
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np


def visualize_network(layers, weights=None, biases=None, title="Réseau de neurones"):
    """
    Visualise un réseau de neurones.

    Parameters
    ----------
    layers : list[int]
        Nombre de neurones par couche. Ex: [3, 4, 1]
    weights : list[Matrix], optional
        Poids entre chaque couche. Ex: [W1, W2]
    biases : list[Matrix], optional
        Biais de chaque couche. Ex: [b1, b2]
    title : str
        Titre de la fenêtre

    Example
    -------
    visualize_network([3, 4, 1], [W1, W2], [b1, b2])
    """
    fig, ax = plt.subplots(figsize=(14, 8))
    ax.set_facecolor("#0f0f1a")
    fig.patch.set_facecolor("#0f0f1a")
    ax.set_title(title, color="white", fontsize=14, fontweight="bold", pad=20)
    ax.axis("off")

    n_layers = len(layers)
    max_neurons = max(layers)

    # ── Positions des neurones ─────────────────────────────────
    positions = []
    for i, n in enumerate(layers):
        x = i / (n_layers - 1) if n_layers > 1 else 0.5
        col = []
        for j in range(n):
            y = (j - (n - 1) / 2) * (0.8 / max(max_neurons - 1, 1))
            col.append((x, y))
        positions.append(col)

    # ── Connexions avec poids ──────────────────────────────────
    if weights:
        for l in range(len(weights)):
            W = weights[l]._data if hasattr(weights[l], '_data') else np.array(weights[l])
            w_min, w_max = W.min(), W.max()
            w_range = max(abs(w_min), abs(w_max), 1e-8)

            for j, (x2, y2) in enumerate(positions[l + 1]):
                for i, (x1, y1) in enumerate(positions[l]):
                    w = W[j, i]
                    # Couleur : bleu = positif, rouge = négatif
                    intensity = abs(w) / w_range
                    if w >= 0:
                        color = (0.2, 0.4 + 0.5 * intensity, 1.0, 0.15 + 0.6 * intensity)
                    else:
                        color = (1.0, 0.2, 0.2 + 0.3 * intensity, 0.15 + 0.6 * intensity)

                    linewidth = 0.5 + 2.0 * intensity
                    ax.plot([x1, x2], [y1, y2],
                            color=color, linewidth=linewidth, zorder=1)

                    # Afficher le poids au milieu de la connexion
                    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
                    ax.text(mx, my, f"{w:.2f}",
                            ha="center", va="center",
                            fontsize=6, color="white",
                            bbox=dict(boxstyle="round,pad=0.1",
                                      fc="#0f0f1a", ec="none", alpha=0.7),
                            zorder=3)

    # ── Neurones ───────────────────────────────────────────────
    layer_names = ["Entrée"] + [f"Cachée {i}" for i in range(1, n_layers - 1)] + ["Sortie"]
    colors_layers = ["#4CAF50", "#2196F3", "#9C27B0", "#FF9800", "#F44336"]

    for l, col in enumerate(positions):
        color = colors_layers[l % len(colors_layers)]

        # Nom de la couche
        ax.text(col[0][0], max(max_neurons - 1, 1) / 2 + 0.15,
                layer_names[l],
                ha="center", va="bottom",
                fontsize=9, color="white", fontweight="bold")

        for j, (x, y) in enumerate(col):
            # Cercle du neurone
            circle = plt.Circle((x, y), 0.04,
                                 color=color, zorder=4,
                                 ec="white", linewidth=1.5)
            ax.add_patch(circle)

            # Numéro du neurone
            ax.text(x, y, str(j + 1),
                    ha="center", va="center",
                    fontsize=7, color="white",
                    fontweight="bold", zorder=5)

            # Biais
            if biases and l > 0:
                b_idx = l - 1
                if b_idx < len(biases):
                    B = biases[b_idx]._data if hasattr(biases[b_idx], '_data') else np.array(biases[b_idx])
                    if j < B.shape[0]:
                        b_val = B[j, 0]
                        ax.text(x + 0.005, y - 0.065,
                                f"b={b_val:.2f}",
                                ha="center", va="top",
                                fontsize=6, color="#FFD700",
                                bbox=dict(boxstyle="round,pad=0.1",
                                          fc="#0f0f1a", ec="#FFD700",
                                          linewidth=0.5, alpha=0.8),
                                zorder=5)

    # ── Légende ────────────────────────────────────────────────
    legend = [
        mpatches.Patch(color="#2196F3", label="Poids positif"),
        mpatches.Patch(color="#F44336", label="Poids négatif"),
        mpatches.Patch(color="#FFD700", label="Biais"),
    ]
    ax.legend(handles=legend, loc="lower right",
              facecolor="#1a1a2e", edgecolor="white",
              labelcolor="white", fontsize=8)

    ax.set_xlim(-0.1, 1.1)
    ax.set_ylim(-0.6, 0.6)
    ax.set_aspect('equal')
    plt.tight_layout()
    plt.show()