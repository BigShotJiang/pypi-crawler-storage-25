"""Telegram Bot client wrapper for managing bot operations."""

import asyncio
import logging
import os
from typing import Optional, Any, Union, cast

from telegram import Bot, Message, InputMediaPhoto
from telegram.constants import ParseMode
from telegram.error import TelegramError, TimedOut, NetworkError, RetryAfter

# Configure logging
logger = logging.getLogger(__name__)


def _resolve_parse_mode(parse_mode: Optional[str]) -> Optional[ParseMode]:
    """Convert a parse_mode string to the corresponding ParseMode constant.

    Supported values (case-insensitive):
    - "Markdown"    → ParseMode.MARKDOWN   (legacy v1)
    - "MarkdownV2"  → ParseMode.MARKDOWN_V2 (recommended)
    - "HTML"        → ParseMode.HTML
    - None / "None" / "" → None (no formatting)
    """
    if not parse_mode or parse_mode.strip().lower() in ("none", ""):
        return None
    normalized = parse_mode.strip().lower().replace("_", "").replace(" ", "")
    if normalized == "markdownv2":
        return ParseMode.MARKDOWN_V2
    if normalized == "markdown":
        return ParseMode.MARKDOWN
    if normalized == "html":
        return ParseMode.HTML
    logger.warning(f"Unknown parse_mode '{parse_mode}', falling back to None")
    return None


class TelegramBotClient:
    """
    Wrapper for Telegram Bot API operations.

    This client provides a simplified interface for common bot operations
    like publishing, editing, and searching messages in channels.
    """

    def __init__(self, bot_token: Optional[str] = None):
        """
        Initialize Telegram bot client.

        Args:
            bot_token: Telegram bot token. If not provided, reads from TELEGRAM_BOT_TOKEN env var.

        Raises:
            ValueError: If bot token is not provided and not found in environment.
        """
        self.bot_token = bot_token or os.getenv("TELEGRAM_BOT_TOKEN")
        if not self.bot_token:
            logger.error(
                "Bot token not provided and TELEGRAM_BOT_TOKEN environment variable not set"
            )
            raise ValueError(
                "Telegram bot token is required. "
                "Provide it as argument or set TELEGRAM_BOT_TOKEN environment variable."
            )

        logger.info("Initializing Telegram bot client")
        self.bot = Bot(token=self.bot_token)
        self._message_cache: dict[str, list[dict[str, Any]]] = {}
        logger.info("Telegram bot client initialized successfully")

    MAX_MESSAGE_LENGTH = 4096
    MAX_RETRIES = 3

    async def _retry(self, fn, operation_name: str = "operation") -> Any:
        """Execute an async Telegram API call with retry/backoff for transient errors.

        Handles RetryAfter (rate limiting) by waiting the requested duration without
        counting against MAX_RETRIES. Handles TimedOut and NetworkError with
        exponential backoff (2s, 4s) up to MAX_RETRIES attempts.
        """
        attempt = 0
        while True:
            try:
                return await fn()
            except RetryAfter as e:
                wait_time = e.retry_after + 1
                logger.warning(
                    f"{operation_name}: rate limited by Telegram, waiting {wait_time}s"
                )
                await asyncio.sleep(wait_time)
            except (TimedOut, NetworkError) as e:
                attempt += 1
                if attempt >= self.MAX_RETRIES:
                    logger.error(
                        f"{operation_name}: failed after {self.MAX_RETRIES} attempts: {e}"
                    )
                    raise
                wait_time = attempt * 2  # 2s, 4s
                logger.warning(
                    f"{operation_name}: transient error (attempt {attempt}/{self.MAX_RETRIES}), "
                    f"retrying in {wait_time}s: {e}"
                )
                await asyncio.sleep(wait_time)

    def _split_text(self, text: str) -> list[str]:
        """Split text into chunks of at most MAX_MESSAGE_LENGTH characters, breaking on newlines."""
        if len(text) <= self.MAX_MESSAGE_LENGTH:
            return [text]

        chunks = []
        while len(text) > self.MAX_MESSAGE_LENGTH:
            split_pos = text.rfind("\n", 0, self.MAX_MESSAGE_LENGTH)
            if split_pos <= 0:
                split_pos = self.MAX_MESSAGE_LENGTH
            chunks.append(text[:split_pos])
            text = text[split_pos:].lstrip("\n")
        if text:
            chunks.append(text)
        return chunks

    async def publish_message(
        self,
        channel_id: str,
        text: str,
        parse_mode: str = "Markdown",
        disable_web_page_preview: bool = False,
        disable_notification: bool = False,
    ) -> dict[str, Any]:
        """
        Publish a message to a Telegram channel.

        Args:
            channel_id: Channel username (e.g., '@mychannel') or chat ID
            text: Message text to publish
            parse_mode: Parse mode for text formatting ('Markdown', 'HTML', or None)
            disable_web_page_preview: Disable link previews
            disable_notification: Send message silently

        Returns:
            Dictionary with message details including message_id, date, and text.
            If text exceeds 4096 characters, it is split across multiple messages;
            the returned dict reflects the first message and includes 'parts' count.

        Raises:
            TelegramError: If message publishing fails
        """
        try:
            logger.info(f"Publishing message to channel {channel_id}")
            pm = _resolve_parse_mode(parse_mode)

            chunks = self._split_text(text)
            first_result: Optional[dict[str, Any]] = None

            for i, chunk in enumerate(chunks):
                message = await self._retry(
                    lambda c=chunk: self.bot.send_message(
                        chat_id=channel_id,
                        text=c,
                        parse_mode=pm,
                        disable_web_page_preview=disable_web_page_preview,
                        disable_notification=disable_notification,
                    ),
                    "publish_message",
                )
                result = {
                    "message_id": message.message_id,
                    "chat_id": message.chat_id,
                    "date": message.date.isoformat(),
                    "text": message.text,
                    "link": self._get_message_link(channel_id, message.message_id),
                }
                self._cache_message(channel_id, result)
                logger.info(
                    f"Published message part {i + 1}/{len(chunks)} "
                    f"(id={message.message_id}) to channel {channel_id}"
                )
                if first_result is None:
                    first_result = result

            assert first_result is not None
            if len(chunks) > 1:
                first_result["parts"] = len(chunks)

            return first_result

        except TelegramError as e:
            logger.error(f"Failed to publish message to channel {channel_id}: {e}", exc_info=True)
            raise TelegramError(f"Failed to publish message: {str(e)}") from e

    async def publish_photo(
        self,
        channel_id: str,
        photo: Union[str, bytes, Any],
        caption: Optional[str] = None,
        parse_mode: str = "Markdown",
        disable_notification: bool = False,
    ) -> dict[str, Any]:
        """
        Publish a photo to a Telegram channel.

        Args:
            channel_id: Channel username (e.g., '@mychannel') or chat ID
            photo: Photo to send. Can be:
                - File path (str) to local image file
                - URL (str) to remote image
                - File-like object or bytes
                - file_id of a photo that exists on Telegram servers
            caption: Optional caption text for the photo
            parse_mode: Parse mode for caption formatting ('Markdown', 'HTML', or None)
            disable_notification: Send message silently

        Returns:
            Dictionary with message details including message_id, date, caption, and photo info

        Raises:
            TelegramError: If photo publishing fails
        """
        try:
            logger.info(f"Publishing photo to channel {channel_id}")
            pm = _resolve_parse_mode(parse_mode)

            message = await self._retry(
                lambda: self.bot.send_photo(
                    chat_id=channel_id,
                    photo=photo,
                    caption=caption,
                    parse_mode=pm,
                    disable_notification=disable_notification,
                ),
                "publish_photo",
            )

            # Get the largest photo size
            photo_info = None
            if message.photo:
                largest_photo = max(message.photo, key=lambda p: p.file_size or 0)
                photo_info = {
                    "file_id": largest_photo.file_id,
                    "file_unique_id": largest_photo.file_unique_id,
                    "width": largest_photo.width,
                    "height": largest_photo.height,
                    "file_size": largest_photo.file_size,
                }

            result = {
                "message_id": message.message_id,
                "chat_id": message.chat_id,
                "date": message.date.isoformat(),
                "caption": message.caption,
                "photo": photo_info,
                "link": self._get_message_link(channel_id, message.message_id),
            }

            # Cache the message for search
            self._cache_message(channel_id, result)
            logger.info(
                f"Successfully published photo message {message.message_id} to channel {channel_id}"
            )

            return result

        except TelegramError as e:
            logger.error(f"Failed to publish photo to channel {channel_id}: {e}", exc_info=True)
            raise TelegramError(f"Failed to publish photo: {str(e)}") from e

    async def publish_photo_album(
        self,
        channel_id: str,
        photos: list[dict[str, Any]],
        disable_notification: bool = False,
    ) -> dict[str, Any]:
        """
        Publish multiple photos as an album (media group) to a Telegram channel.

        Args:
            channel_id: Channel username (e.g., '@mychannel') or chat ID
            photos: List of photo dictionaries, each containing:
                - photo: Photo to send (file path, URL, or file_id)
                - caption: Optional caption text for this photo
                - parse_mode: Optional parse mode ('Markdown', 'HTML', or None)
            disable_notification: Send message silently

        Returns:
            Dictionary with album details including message_ids, dates, and photo info

        Raises:
            TelegramError: If album publishing fails
            ValueError: If photos list is invalid (must contain 2-10 photos)
        """
        try:
            # Validate photos list
            if not photos:
                raise ValueError("Photos list cannot be empty")
            if len(photos) == 1:
                # Fall back to single photo when only one item is provided
                photo_data = photos[0]
                if not photo_data.get("photo"):
                    raise ValueError("Photo at index 0 is missing 'photo' field")
                logger.info(
                    "publish_photo_album: only 1 photo provided, falling back to publish_photo"
                )
                return await self.publish_photo(
                    channel_id=channel_id,
                    photo=photo_data["photo"],
                    caption=photo_data.get("caption"),
                    parse_mode=photo_data.get("parse_mode", "Markdown"),
                    disable_notification=disable_notification,
                )
            if len(photos) > 10:
                raise ValueError("Album cannot contain more than 10 photos")

            logger.info(f"Publishing photo album with {len(photos)} photos to channel {channel_id}")

            # Build media group
            media_group = []
            for idx, photo_data in enumerate(photos):
                photo = photo_data.get("photo")
                if not photo:
                    raise ValueError(f"Photo at index {idx} is missing 'photo' field")

                caption = photo_data.get("caption")
                parse_mode_str = photo_data.get("parse_mode", "Markdown")

                pm = _resolve_parse_mode(parse_mode_str)

                # Create InputMediaPhoto object
                media_item = InputMediaPhoto(
                    media=photo,
                    caption=caption,
                    parse_mode=pm,
                )
                media_group.append(media_item)

            # Send media group
            messages = await self._retry(
                lambda: self.bot.send_media_group(
                    chat_id=channel_id,
                    media=media_group,
                    disable_notification=disable_notification,
                ),
                "publish_photo_album",
            )

            # Process results
            album_messages = []
            for message in messages:
                # Get the largest photo size
                photo_info = None
                if message.photo:
                    largest_photo = max(message.photo, key=lambda p: p.file_size or 0)
                    photo_info = {
                        "file_id": largest_photo.file_id,
                        "file_unique_id": largest_photo.file_unique_id,
                        "width": largest_photo.width,
                        "height": largest_photo.height,
                        "file_size": largest_photo.file_size,
                    }

                msg_data = {
                    "message_id": message.message_id,
                    "chat_id": message.chat_id,
                    "date": message.date.isoformat(),
                    "caption": message.caption,
                    "photo": photo_info,
                    "link": self._get_message_link(channel_id, message.message_id),
                }
                album_messages.append(msg_data)

                # Cache each message
                self._cache_message(channel_id, msg_data)

            result = {
                "album_id": messages[0].media_group_id if messages else None,
                "message_count": len(messages),
                "messages": album_messages,
                "first_message_id": messages[0].message_id if messages else None,
                "chat_id": messages[0].chat_id if messages else None,
            }

            logger.info(
                f"Successfully published photo album with {len(messages)} photos to channel {channel_id}"
            )

            return result

        except ValueError as e:
            logger.error(f"Invalid photo album parameters: {e}")
            raise ValueError(str(e)) from e
        except TelegramError as e:
            logger.error(
                f"Failed to publish photo album to channel {channel_id}: {e}", exc_info=True
            )
            raise TelegramError(f"Failed to publish photo album: {str(e)}") from e

    async def edit_message(
        self,
        channel_id: str,
        message_id: int,
        new_text: str,
        parse_mode: str = "Markdown",
    ) -> dict[str, Any]:
        """
        Edit an existing message in a Telegram channel.

        Args:
            channel_id: Channel username (e.g., '@mychannel') or chat ID
            message_id: ID of the message to edit
            new_text: New message text
            parse_mode: Parse mode for text formatting ('Markdown', 'HTML', or None)

        Returns:
            Dictionary with updated message details

        Raises:
            TelegramError: If message editing fails
        """
        try:
            logger.info(f"Editing message {message_id} in channel {channel_id}")
            pm = _resolve_parse_mode(parse_mode)

            message = await self._retry(
                lambda: self.bot.edit_message_text(
                    chat_id=channel_id,
                    message_id=message_id,
                    text=new_text,
                    parse_mode=pm,
                ),
                "edit_message",
            )

            # When chat_id and message_id are provided, result is always a Message
            message = cast(Message, message)

            result = {
                "message_id": message.message_id,
                "chat_id": message.chat_id,
                "date": message.date.isoformat(),
                "edit_date": message.edit_date.isoformat() if message.edit_date else None,
                "text": message.text,
                "link": self._get_message_link(channel_id, message.message_id),
            }

            # Update cache
            self._update_cache(channel_id, result)
            logger.info(f"Successfully edited message {message_id} in channel {channel_id}")

            return result

        except TelegramError as e:
            logger.error(
                f"Failed to edit message {message_id} in channel {channel_id}: {e}", exc_info=True
            )
            raise TelegramError(f"Failed to edit message: {str(e)}") from e

    async def edit_message_caption(
        self,
        channel_id: str,
        message_id: int,
        new_caption: str,
        parse_mode: str = "Markdown",
    ) -> dict[str, Any]:
        """
        Edit the caption of a photo message in a Telegram channel.

        Note: This only works for messages with media (photos, videos, etc.).
        You cannot change the photo itself, only the caption text.

        Args:
            channel_id: Channel username (e.g., '@mychannel') or chat ID
            message_id: ID of the message to edit
            new_caption: New caption text
            parse_mode: Parse mode for caption formatting ('Markdown', 'HTML', or None)

        Returns:
            Dictionary with updated message details

        Raises:
            TelegramError: If caption editing fails
        """
        try:
            logger.info(f"Editing caption for message {message_id} in channel {channel_id}")
            pm = _resolve_parse_mode(parse_mode)

            message = await self._retry(
                lambda: self.bot.edit_message_caption(
                    chat_id=channel_id,
                    message_id=message_id,
                    caption=new_caption,
                    parse_mode=pm,
                ),
                "edit_message_caption",
            )

            # When chat_id and message_id are provided, result is always a Message
            message = cast(Message, message)

            # Get the largest photo size if available
            photo_info = None
            if message.photo:
                largest_photo = max(message.photo, key=lambda p: p.file_size or 0)
                photo_info = {
                    "file_id": largest_photo.file_id,
                    "file_unique_id": largest_photo.file_unique_id,
                    "width": largest_photo.width,
                    "height": largest_photo.height,
                    "file_size": largest_photo.file_size,
                }

            result = {
                "message_id": message.message_id,
                "chat_id": message.chat_id,
                "date": message.date.isoformat(),
                "edit_date": message.edit_date.isoformat() if message.edit_date else None,
                "caption": message.caption,
                "photo": photo_info,
                "link": self._get_message_link(channel_id, message.message_id),
            }

            # Update cache
            self._update_cache(channel_id, result)
            logger.info(
                f"Successfully edited caption for message {message_id} in channel {channel_id}"
            )

            return result

        except TelegramError as e:
            logger.error(
                f"Failed to edit caption for message {message_id} in channel {channel_id}: {e}",
                exc_info=True,
            )
            raise TelegramError(f"Failed to edit message caption: {str(e)}") from e

    async def delete_message(
        self,
        channel_id: str,
        message_id: int,
    ) -> bool:
        """
        Delete a message from a Telegram channel.

        Args:
            channel_id: Channel username (e.g., '@mychannel') or chat ID
            message_id: ID of the message to delete

        Returns:
            True if message was deleted successfully

        Raises:
            TelegramError: If message deletion fails
        """
        try:
            logger.info(f"Deleting message {message_id} from channel {channel_id}")
            result = await self._retry(
                lambda: self.bot.delete_message(
                    chat_id=channel_id,
                    message_id=message_id,
                ),
                "delete_message",
            )

            # Remove from cache
            self._remove_from_cache(channel_id, message_id)
            logger.info(f"Successfully deleted message {message_id} from channel {channel_id}")

            return result

        except TelegramError as e:
            logger.error(
                f"Failed to delete message {message_id} from channel {channel_id}: {e}",
                exc_info=True,
            )
            raise TelegramError(f"Failed to delete message: {str(e)}") from e

    async def get_channel_info(self, channel_id: str) -> dict[str, Any]:
        """
        Get information about a Telegram channel.

        Args:
            channel_id: Channel username (e.g., '@mychannel') or chat ID

        Returns:
            Dictionary with channel information

        Raises:
            TelegramError: If channel info retrieval fails
        """
        try:
            logger.info(f"Getting info for channel {channel_id}")
            chat = await self._retry(
                lambda: self.bot.get_chat(chat_id=channel_id),
                "get_channel_info",
            )
            member_count = await self._retry(
                lambda: self.bot.get_chat_member_count(chat_id=channel_id),
                "get_channel_info",
            )

            result = {
                "id": chat.id,
                "title": chat.title,
                "username": chat.username,
                "type": chat.type,
                "description": chat.description,
                "invite_link": chat.invite_link,
                "member_count": member_count,
            }
            logger.info(f"Successfully retrieved info for channel {channel_id}")

            return result

        except TelegramError as e:
            logger.error(f"Failed to get channel info for {channel_id}: {e}", exc_info=True)
            raise TelegramError(f"Failed to get channel info: {str(e)}") from e

    def search_messages(
        self,
        channel_id: str,
        query: Optional[str] = None,
        limit: int = 10,
        offset: int = 0,
    ) -> dict[str, Any]:
        """
        Search messages in the local cache.

        Note: Telegram Bot API doesn't support message search directly.
        This searches through cached messages from publish/edit operations.

        Args:
            channel_id: Channel username or chat ID
            query: Search query (searches in message text/caption). If None, returns all cached messages.
            limit: Maximum number of results to return
            offset: Number of results to skip (for pagination)

        Returns:
            Dictionary containing:
            - messages: List of matching messages
            - count: Number of messages in this page
            - total: Total number of matching messages
            - offset: Current offset
            - limit: Current limit
            - has_more: Whether more results are available
            - next_offset: Offset for next page (if has_more)
            - query: The search query
            - channel_id: The channel ID
        """
        logger.debug(
            f"Searching messages in channel {channel_id} with query: {query}, limit: {limit}, offset: {offset}"
        )
        cached_messages = self._message_cache.get(channel_id, [])

        if query:
            # Case-insensitive search in message text and caption
            query_lower = query.lower()
            results = [
                msg
                for msg in cached_messages
                if query_lower in msg.get("text", "").lower()
                or query_lower in msg.get("caption", "").lower()
            ]
        else:
            results = cached_messages

        # Sort by date (newest first)
        results.sort(key=lambda x: x.get("date", ""), reverse=True)

        # Apply pagination
        total = len(results)
        paginated_results = results[offset : offset + limit]
        has_more = total > offset + limit

        logger.debug(
            f"Found {len(paginated_results)} of {total} matching messages in channel {channel_id}"
        )

        return {
            "messages": paginated_results,
            "count": len(paginated_results),
            "total": total,
            "offset": offset,
            "limit": limit,
            "has_more": has_more,
            "next_offset": offset + limit if has_more else None,
            "query": query,
            "channel_id": channel_id,
        }

    def _get_message_link(self, channel_id: str, message_id: int) -> Optional[str]:
        """Generate a public link to the message if channel has username."""
        if channel_id.startswith("@"):
            username = channel_id[1:]  # Remove @ prefix
            return f"https://t.me/{username}/{message_id}"
        return None

    def _cache_message(self, channel_id: str, message_data: dict[str, Any]) -> None:
        """Add message to cache."""
        if channel_id not in self._message_cache:
            self._message_cache[channel_id] = []
        self._message_cache[channel_id].append(message_data)
        logger.debug(f"Cached message {message_data.get('message_id')} for channel {channel_id}")

    def _update_cache(self, channel_id: str, message_data: dict[str, Any]) -> None:
        """Update cached message."""
        if channel_id in self._message_cache:
            for i, msg in enumerate(self._message_cache[channel_id]):
                if msg.get("message_id") == message_data.get("message_id"):
                    self._message_cache[channel_id][i] = message_data
                    logger.debug(
                        f"Updated cached message {message_data.get('message_id')} for channel {channel_id}"
                    )
                    return
        # If not found in cache, add it
        self._cache_message(channel_id, message_data)

    def _remove_from_cache(self, channel_id: str, message_id: int) -> None:
        """Remove message from cache."""
        if channel_id in self._message_cache:
            self._message_cache[channel_id] = [
                msg
                for msg in self._message_cache[channel_id]
                if msg.get("message_id") != message_id
            ]
            logger.debug(f"Removed message {message_id} from cache for channel {channel_id}")

    async def get_message_info(self, channel_id: str, message_id: int) -> dict[str, Any]:
        """
        Get information about a specific message.

        This is useful for debugging or determining message type before editing.

        Args:
            channel_id: Channel username (e.g., '@mychannel') or chat ID
            message_id: ID of the message to inspect

        Returns:
            Dictionary with message information including type, content, etc.

        Raises:
            TelegramError: If message retrieval fails
        """
        try:
            logger.info(f"Getting info for message {message_id} in channel {channel_id}")
            # Use forward_message to get message info (then delete the forwarded copy)
            # Unfortunately, Telegram Bot API doesn't have a direct "get message" endpoint
            # So we need to check the cache or use other methods

            # Check cache first
            cached = self._message_cache.get(channel_id, [])
            for msg in cached:
                if msg.get("message_id") == message_id:
                    logger.info(
                        f"Successfully retrieved message {message_id} info from channel {channel_id} (from cache)"
                    )
                    return {
                        **msg,
                        "source": "cache",
                        "status": "success",
                    }

            # If not in cache, we can't get it with Bot API (limitation)
            logger.debug(f"Message {message_id} not found in cache for channel {channel_id}")
            return {
                "status": "not_found",
                "message": f"Message {message_id} not found in cache. The Telegram Bot API doesn't provide a way to fetch arbitrary messages. Only messages published/edited through this tool are cached.",
                "hint": "Try publishing or editing the message through this tool to add it to the cache.",
            }

        except TelegramError as e:
            logger.error(
                f"Failed to get message info for {message_id} in channel {channel_id}: {e}",
                exc_info=True,
            )
            raise TelegramError(f"Failed to get message info: {str(e)}") from e

    async def check_channel_access(self, channel_id: str) -> dict[str, Any]:
        """
        Check whether the bot is an admin and can post messages in a channel.

        Args:
            channel_id: Channel username (e.g., '@mychannel') or numeric chat ID

        Returns:
            Dictionary with keys:
            - can_post: bool — True if the bot can post messages
            - is_admin: bool — True if the bot is listed as an administrator
            - channel_id: the channel that was checked
            - bot_username: bot's username (only present when can_post is True)
            - permissions: dict of relevant permissions (only present when is_admin is True)
            - reason: human-readable explanation when can_post is False

        Raises:
            TelegramError: If the channel is not found or the API call fails
        """
        try:
            logger.info(f"Checking channel access for {channel_id}")
            bot_info = await self._retry(
                lambda: self.bot.get_me(),
                "check_channel_access",
            )
            admins = await self._retry(
                lambda: self.bot.get_chat_administrators(chat_id=channel_id),
                "check_channel_access",
            )

            bot_admin = None
            for admin in admins:
                if admin.user.id == bot_info.id:
                    bot_admin = admin
                    break

            if bot_admin is None:
                logger.info(f"Bot is not an admin in {channel_id}")
                return {
                    "can_post": False,
                    "is_admin": False,
                    "channel_id": channel_id,
                    "reason": "Bot is not an administrator in this channel. "
                              "Add the bot as an admin with 'Post Messages' permission.",
                }

            can_post = getattr(bot_admin, "can_post_messages", True)
            if not can_post:
                logger.info(f"Bot lacks can_post_messages in {channel_id}")
                return {
                    "can_post": False,
                    "is_admin": True,
                    "channel_id": channel_id,
                    "reason": "Bot does not have 'Post Messages' permission in this channel.",
                    "permissions": {
                        "can_post_messages": False,
                        "can_edit_messages": getattr(bot_admin, "can_edit_messages", False),
                        "can_delete_messages": getattr(bot_admin, "can_delete_messages", False),
                    },
                }

            result = {
                "can_post": True,
                "is_admin": True,
                "channel_id": channel_id,
                "bot_username": bot_info.username,
                "permissions": {
                    "can_post_messages": True,
                    "can_edit_messages": getattr(bot_admin, "can_edit_messages", False),
                    "can_delete_messages": getattr(bot_admin, "can_delete_messages", False),
                },
            }
            logger.info(f"Bot has post access to {channel_id}")
            return result

        except TelegramError as e:
            logger.error(f"Failed to check channel access for {channel_id}: {e}", exc_info=True)
            raise TelegramError(f"Failed to check channel access: {str(e)}") from e

    async def close(self) -> None:
        """Close bot session and cleanup resources."""
        # python-telegram-bot handles cleanup automatically
        pass
