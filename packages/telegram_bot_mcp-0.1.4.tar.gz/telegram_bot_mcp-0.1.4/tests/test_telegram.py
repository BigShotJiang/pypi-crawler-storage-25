"""Tests for Telegram tools."""

import os
import pytest
from unittest.mock import AsyncMock, Mock, patch
from datetime import datetime

from telegram.error import TelegramError, TimedOut, NetworkError, RetryAfter

from telegram_bot_mcp import server
from telegram_bot_mcp.telegram_bot.client import TelegramBotClient

# Access the tool functions directly (new MCP version)
telegram_publish_message = server.telegram_publish_message
telegram_publish_photo = server.telegram_publish_photo
telegram_publish_photo_album = server.telegram_publish_photo_album
telegram_edit_message = server.telegram_edit_message
telegram_edit_message_caption = server.telegram_edit_message_caption
telegram_delete_message = server.telegram_delete_message
telegram_search_messages = server.telegram_search_messages
telegram_get_channel_info = server.telegram_get_channel_info
telegram_check_channel_access = server.telegram_check_channel_access


@pytest.fixture
def mock_bot_token():
    """Set up mock bot token."""
    original = os.environ.get("TELEGRAM_BOT_TOKEN")
    os.environ["TELEGRAM_BOT_TOKEN"] = "123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
    yield
    if original:
        os.environ["TELEGRAM_BOT_TOKEN"] = original
    else:
        del os.environ["TELEGRAM_BOT_TOKEN"]


@pytest.fixture
def mock_telegram_message():
    """Create a mock Telegram message object."""
    message = Mock()
    message.message_id = 12345
    message.chat_id = -1001234567890
    message.date = datetime(2024, 1, 15, 10, 30, 0)
    message.edit_date = None
    message.text = "Test message"
    return message


@pytest.fixture
def mock_telegram_photo_message():
    """Create a mock Telegram photo message object."""
    photo_size = Mock()
    photo_size.file_id = "AgACAgIAAxkBAAMCY1234567890"
    photo_size.file_unique_id = "AQADAgATxxx"
    photo_size.width = 1280
    photo_size.height = 720
    photo_size.file_size = 102400

    message = Mock()
    message.message_id = 12345
    message.chat_id = -1001234567890
    message.date = datetime(2024, 1, 15, 10, 30, 0)
    message.edit_date = None
    message.caption = "Test photo caption"
    message.photo = [photo_size]
    return message


@pytest.fixture
def mock_telegram_album_messages():
    """Create a list of mock Telegram photo messages for an album."""
    messages = []
    media_group_id = "12345678901234567"

    for i in range(3):
        photo_size = Mock()
        photo_size.file_id = f"AgACAgIAAxkBAAMCY123456789{i}"
        photo_size.file_unique_id = f"AQADAgATxx{i}"
        photo_size.width = 1280
        photo_size.height = 720
        photo_size.file_size = 102400 + (i * 1000)

        message = Mock()
        message.message_id = 12345 + i
        message.chat_id = -1001234567890
        message.date = datetime(2024, 1, 15, 10, 30, i)
        message.edit_date = None
        message.caption = f"Photo {i + 1}" if i == 0 else None
        message.photo = [photo_size]
        message.media_group_id = media_group_id
        messages.append(message)

    return messages


class TestTelegramClient:
    """Tests for TelegramBotClient."""

    def test_client_init_with_token(self):
        """Test client initialization with explicit token."""
        client = TelegramBotClient(bot_token="test_token")
        assert client.bot_token == "test_token"
        assert client.bot is not None

    def test_client_init_from_env(self, mock_bot_token):
        """Test client initialization from environment variable."""
        client = TelegramBotClient()
        assert client.bot_token is not None
        assert client.bot is not None

    def test_client_init_no_token(self):
        """Test client initialization fails without token."""
        # Temporarily remove env var
        original = os.environ.get("TELEGRAM_BOT_TOKEN")
        if "TELEGRAM_BOT_TOKEN" in os.environ:
            del os.environ["TELEGRAM_BOT_TOKEN"]

        with pytest.raises(ValueError, match="Telegram bot token is required"):
            TelegramBotClient()

        # Restore env var
        if original:
            os.environ["TELEGRAM_BOT_TOKEN"] = original

    @pytest.mark.asyncio
    async def test_publish_message(self, mock_bot_token, mock_telegram_message):
        """Test publishing a message."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.send_message = AsyncMock(return_value=mock_telegram_message)

            client = TelegramBotClient()
            result = await client.publish_message(
                channel_id="@testchannel",
                text="Test message",
            )

            assert result["message_id"] == 12345
            assert result["chat_id"] == -1001234567890
            assert result["text"] == "Test message"
            assert "link" in result
            mock_bot_instance.send_message.assert_called_once()

    @pytest.mark.asyncio
    async def test_edit_message(self, mock_bot_token, mock_telegram_message):
        """Test editing a message."""
        mock_telegram_message.edit_date = datetime(2024, 1, 15, 11, 0, 0)
        mock_telegram_message.text = "Updated message"

        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.edit_message_text = AsyncMock(return_value=mock_telegram_message)

            client = TelegramBotClient()
            result = await client.edit_message(
                channel_id="@testchannel",
                message_id=12345,
                new_text="Updated message",
            )

            assert result["message_id"] == 12345
            assert result["text"] == "Updated message"
            assert result["edit_date"] is not None
            mock_bot_instance.edit_message_text.assert_called_once()

    @pytest.mark.asyncio
    async def test_delete_message(self, mock_bot_token):
        """Test deleting a message."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.delete_message = AsyncMock(return_value=True)

            client = TelegramBotClient()
            result = await client.delete_message(
                channel_id="@testchannel",
                message_id=12345,
            )

            assert result is True
            mock_bot_instance.delete_message.assert_called_once()

    def test_search_messages_with_query(self, mock_bot_token):
        """Test searching messages with a query."""
        client = TelegramBotClient()

        # Manually populate cache
        client._message_cache["@testchannel"] = [
            {"message_id": 1, "text": "Hello world", "date": "2024-01-15T10:00:00"},
            {"message_id": 2, "text": "Goodbye world", "date": "2024-01-15T11:00:00"},
            {"message_id": 3, "text": "Test message", "date": "2024-01-15T12:00:00"},
        ]

        result = client.search_messages(
            channel_id="@testchannel",
            query="world",
            limit=10,
        )

        assert result["count"] == 2
        assert result["total"] == 2
        assert len(result["messages"]) == 2
        assert all("world" in msg["text"].lower() for msg in result["messages"])
        # Should be sorted by date (newest first)
        assert result["messages"][0]["message_id"] == 2

    def test_search_messages_no_query(self, mock_bot_token):
        """Test searching messages without a query (get all)."""
        client = TelegramBotClient()

        client._message_cache["@testchannel"] = [
            {"message_id": 1, "text": "Message 1", "date": "2024-01-15T10:00:00"},
            {"message_id": 2, "text": "Message 2", "date": "2024-01-15T11:00:00"},
        ]

        result = client.search_messages(
            channel_id="@testchannel",
            query=None,
            limit=10,
        )

        assert result["count"] == 2
        assert len(result["messages"]) == 2

    @pytest.mark.asyncio
    async def test_get_channel_info(self, mock_bot_token):
        """Test getting channel information."""
        mock_chat = Mock()
        mock_chat.id = -1001234567890
        mock_chat.title = "Test Channel"
        mock_chat.username = "testchannel"
        mock_chat.type = "channel"
        mock_chat.description = "A test channel"
        mock_chat.invite_link = "https://t.me/testchannel"

        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.get_chat = AsyncMock(return_value=mock_chat)
            mock_bot_instance.get_chat_member_count = AsyncMock(return_value=1234)

            client = TelegramBotClient()
            result = await client.get_channel_info(channel_id="@testchannel")

            assert result["id"] == -1001234567890
            assert result["title"] == "Test Channel"
            assert result["username"] == "testchannel"
            assert result["member_count"] == 1234

    @pytest.mark.asyncio
    async def test_get_message_info_from_cache(self, mock_bot_token):
        """Test getting message info from cache."""
        client = TelegramBotClient()

        # Manually populate cache
        test_message = {
            "message_id": 12345,
            "chat_id": -1001234567890,
            "text": "Test message",
            "date": "2024-01-15T10:30:00",
        }
        client._message_cache["@testchannel"] = [test_message]

        result = await client.get_message_info(
            channel_id="@testchannel",
            message_id=12345,
        )

        assert result["status"] == "success"
        assert result["source"] == "cache"
        assert result["message_id"] == 12345
        assert result["text"] == "Test message"

    @pytest.mark.asyncio
    async def test_get_message_info_not_found(self, mock_bot_token):
        """Test getting message info when not in cache."""
        client = TelegramBotClient()

        result = await client.get_message_info(
            channel_id="@testchannel",
            message_id=99999,
        )

        assert result["status"] == "not_found"
        assert "not found in cache" in result["message"]
        assert "hint" in result

    def test_get_message_link_with_username(self, mock_bot_token):
        """Test generating message link for channel with username."""
        client = TelegramBotClient()
        link = client._get_message_link("@testchannel", 12345)
        assert link == "https://t.me/testchannel/12345"

    def test_get_message_link_without_username(self, mock_bot_token):
        """Test generating message link for channel without username."""
        client = TelegramBotClient()
        link = client._get_message_link("-1001234567890", 12345)
        assert link is None

    @pytest.mark.asyncio
    async def test_publish_photo(self, mock_bot_token, mock_telegram_photo_message):
        """Test publishing a photo."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.send_photo = AsyncMock(return_value=mock_telegram_photo_message)

            client = TelegramBotClient()
            result = await client.publish_photo(
                channel_id="@testchannel",
                photo="/path/to/image.jpg",
                caption="Test photo caption",
            )

            assert result["message_id"] == 12345
            assert result["chat_id"] == -1001234567890
            assert result["caption"] == "Test photo caption"
            assert "photo" in result
            assert result["photo"]["file_id"] == "AgACAgIAAxkBAAMCY1234567890"
            assert result["photo"]["width"] == 1280
            assert result["photo"]["height"] == 720
            assert "link" in result
            mock_bot_instance.send_photo.assert_called_once()

    @pytest.mark.asyncio
    async def test_edit_message_caption(self, mock_bot_token, mock_telegram_photo_message):
        """Test editing a photo message caption."""
        mock_telegram_photo_message.edit_date = datetime(2024, 1, 15, 11, 0, 0)
        mock_telegram_photo_message.caption = "Updated caption"

        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.edit_message_caption = AsyncMock(
                return_value=mock_telegram_photo_message
            )

            client = TelegramBotClient()
            result = await client.edit_message_caption(
                channel_id="@testchannel",
                message_id=12345,
                new_caption="Updated caption",
            )

            assert result["message_id"] == 12345
            assert result["caption"] == "Updated caption"
            assert result["edit_date"] is not None
            assert "photo" in result
            assert result["photo"]["file_id"] == "AgACAgIAAxkBAAMCY1234567890"
            mock_bot_instance.edit_message_caption.assert_called_once()

    @pytest.mark.asyncio
    async def test_publish_photo_album(self, mock_bot_token, mock_telegram_album_messages):
        """Test publishing a photo album."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.send_media_group = AsyncMock(
                return_value=mock_telegram_album_messages
            )

            client = TelegramBotClient()
            photos = [
                {"photo": "/path/to/photo1.jpg", "caption": "Photo 1"},
                {"photo": "/path/to/photo2.jpg"},
                {"photo": "/path/to/photo3.jpg"},
            ]
            result = await client.publish_photo_album(
                channel_id="@testchannel",
                photos=photos,
            )

            assert result["album_id"] == "12345678901234567"
            assert result["message_count"] == 3
            assert result["first_message_id"] == 12345
            assert len(result["messages"]) == 3
            assert result["messages"][0]["caption"] == "Photo 1"
            mock_bot_instance.send_media_group.assert_called_once()

    @pytest.mark.asyncio
    async def test_publish_photo_album_single_photo_fallback(
        self, mock_bot_token, mock_telegram_photo_message
    ):
        """Test that a single-photo list falls back to publish_photo."""
        client = TelegramBotClient()
        expected = {
            "message_id": mock_telegram_photo_message.message_id,
            "chat_id": mock_telegram_photo_message.chat_id,
            "date": mock_telegram_photo_message.date.isoformat(),
            "caption": mock_telegram_photo_message.caption,
            "photo": None,
            "link": f"https://t.me/testchannel/{mock_telegram_photo_message.message_id}",
        }
        with patch.object(client, "publish_photo", new_callable=AsyncMock) as mock_pub:
            mock_pub.return_value = expected
            result = await client.publish_photo_album(
                channel_id="@testchannel",
                photos=[{"photo": "/path/to/photo1.jpg", "caption": "Test caption"}],
            )
        assert result["message_id"] == mock_telegram_photo_message.message_id
        mock_pub.assert_called_once_with(
            channel_id="@testchannel",
            photo="/path/to/photo1.jpg",
            caption="Test caption",
            parse_mode="Markdown",
            disable_notification=False,
        )

    @pytest.mark.asyncio
    async def test_publish_photo_album_validation(self, mock_bot_token):
        """Test photo album validation errors."""
        client = TelegramBotClient()

        # Test with too many photos
        with pytest.raises(ValueError, match="cannot contain more than 10"):
            photos = [{"photo": f"/path/to/photo{i}.jpg"} for i in range(11)]
            await client.publish_photo_album(
                channel_id="@testchannel",
                photos=photos,
            )

        # Test with missing photo field
        with pytest.raises(ValueError, match="missing 'photo' field"):
            await client.publish_photo_album(
                channel_id="@testchannel",
                photos=[{"photo": "/path/to/photo1.jpg"}, {"caption": "No photo"}],
            )


class TestTelegramTools:
    """Tests for Telegram tool functions."""

    @pytest.mark.asyncio
    async def test_publish_message_tool(self, mock_bot_token, mock_telegram_message):
        """Test publish_message tool function."""
        with patch("telegram_bot_mcp.server._get_client") as mock_get_client:
            mock_client = Mock()
            mock_client.publish_message = AsyncMock(
                return_value={
                    "message_id": 12345,
                    "chat_id": -1001234567890,
                    "date": "2024-01-15T10:30:00",
                    "text": "Test message",
                    "link": "https://t.me/testchannel/12345",
                }
            )
            mock_get_client.return_value = mock_client

            result = await telegram_publish_message(
                channel_id="@testchannel",
                text="Test message",
                response_format="json",
            )

            assert result["message_id"] == 12345
            assert "error" not in result

    @pytest.mark.asyncio
    async def test_edit_message_tool(self, mock_bot_token):
        """Test edit_message tool function."""
        with patch("telegram_bot_mcp.server._get_client") as mock_get_client:
            mock_client = Mock()
            mock_client.edit_message = AsyncMock(
                return_value={
                    "message_id": 12345,
                    "text": "Updated message",
                    "edit_date": "2024-01-15T11:00:00",
                }
            )
            mock_get_client.return_value = mock_client

            result = await telegram_edit_message(
                channel_id="@testchannel",
                message_id=12345,
                new_text="Updated message",
                response_format="json",
            )

            assert result["message_id"] == 12345
            assert "error" not in result

    @pytest.mark.asyncio
    async def test_delete_message_tool(self, mock_bot_token):
        """Test delete_message tool function."""
        with patch("telegram_bot_mcp.server._get_client") as mock_get_client:
            mock_client = Mock()
            mock_client.delete_message = AsyncMock(return_value=True)
            mock_get_client.return_value = mock_client

            result = await telegram_delete_message(
                channel_id="@testchannel",
                message_id=12345,
                response_format="json",
            )

            assert result["success"] is True
            assert result["status"] == "deleted"

    def test_search_messages_tool(self, mock_bot_token):
        """Test search_messages tool function."""
        with patch("telegram_bot_mcp.server._get_client") as mock_get_client:
            mock_client = Mock()
            mock_client.search_messages = Mock(
                return_value={
                    "messages": [
                        {"message_id": 1, "text": "Test 1"},
                        {"message_id": 2, "text": "Test 2"},
                    ],
                    "count": 2,
                    "total": 2,
                    "offset": 0,
                    "limit": 10,
                    "has_more": False,
                    "next_offset": None,
                    "query": "test",
                    "channel_id": "@testchannel",
                }
            )
            mock_get_client.return_value = mock_client

            result = telegram_search_messages(
                channel_id="@testchannel",
                query="test",
                response_format="json",
            )

            assert result["count"] == 2
            assert len(result["messages"]) == 2
            assert result["status"] == "success"

    @pytest.mark.asyncio
    async def test_get_channel_info_tool(self, mock_bot_token):
        """Test get_channel_info tool function."""
        with patch("telegram_bot_mcp.server._get_client") as mock_get_client:
            mock_client = Mock()
            mock_client.get_channel_info = AsyncMock(
                return_value={
                    "id": -1001234567890,
                    "title": "Test Channel",
                    "username": "testchannel",
                    "member_count": 1234,
                }
            )
            mock_get_client.return_value = mock_client

            result = await telegram_get_channel_info(
                channel_id="@testchannel", response_format="json"
            )

            assert result["id"] == -1001234567890
            assert result["title"] == "Test Channel"
            assert result["status"] == "success"

    @pytest.mark.asyncio
    async def test_publish_photo_tool(self, mock_bot_token):
        """Test publish_photo tool function."""
        with patch("telegram_bot_mcp.server._get_client") as mock_get_client:
            mock_client = Mock()
            mock_client.publish_photo = AsyncMock(
                return_value={
                    "message_id": 12345,
                    "chat_id": -1001234567890,
                    "date": "2024-01-15T10:30:00",
                    "caption": "Test photo caption",
                    "photo": {
                        "file_id": "AgACAgIAAxkBAAMCY1234567890",
                        "width": 1280,
                        "height": 720,
                        "file_size": 102400,
                    },
                    "link": "https://t.me/testchannel/12345",
                }
            )
            mock_get_client.return_value = mock_client

            result = await telegram_publish_photo(
                channel_id="@testchannel",
                photo="/path/to/image.jpg",
                caption="Test photo caption",
                response_format="json",
            )

            assert result["message_id"] == 12345
            assert result["caption"] == "Test photo caption"
            assert "photo" in result
            assert result["photo"]["file_id"] == "AgACAgIAAxkBAAMCY1234567890"
            assert "error" not in result

    @pytest.mark.asyncio
    async def test_edit_message_caption_tool(self, mock_bot_token):
        """Test edit_message_caption tool function."""
        with patch("telegram_bot_mcp.server._get_client") as mock_get_client:
            mock_client = Mock()
            mock_client.edit_message_caption = AsyncMock(
                return_value={
                    "message_id": 12345,
                    "caption": "Updated caption",
                    "edit_date": "2024-01-15T11:00:00",
                    "photo": {
                        "file_id": "AgACAgIAAxkBAAMCY1234567890",
                        "width": 1280,
                        "height": 720,
                        "file_size": 102400,
                    },
                }
            )
            mock_get_client.return_value = mock_client

            result = await telegram_edit_message_caption(
                channel_id="@testchannel",
                message_id=12345,
                new_caption="Updated caption",
                response_format="json",
            )

            assert result["message_id"] == 12345
            assert result["caption"] == "Updated caption"
            assert result["edit_date"] == "2024-01-15T11:00:00"
            assert "photo" in result
            assert "error" not in result

    @pytest.mark.asyncio
    async def test_publish_photo_album_tool(self, mock_bot_token):
        """Test publish_photo_album tool function."""
        with patch("telegram_bot_mcp.server._get_client") as mock_get_client:
            mock_client = Mock()
            mock_client.publish_photo_album = AsyncMock(
                return_value={
                    "album_id": "12345678901234567",
                    "message_count": 3,
                    "first_message_id": 12345,
                    "messages": [
                        {
                            "message_id": 12345,
                            "caption": "Photo 1",
                            "photo": {"file_id": "AgACAgIAAxkBAAMCY1234567890"},
                        },
                        {
                            "message_id": 12346,
                            "caption": None,
                            "photo": {"file_id": "AgACAgIAAxkBAAMCY1234567891"},
                        },
                        {
                            "message_id": 12347,
                            "caption": None,
                            "photo": {"file_id": "AgACAgIAAxkBAAMCY1234567892"},
                        },
                    ],
                }
            )
            mock_get_client.return_value = mock_client

            photos = [
                {"photo": "/path/to/photo1.jpg", "caption": "Photo 1"},
                {"photo": "/path/to/photo2.jpg"},
                {"photo": "/path/to/photo3.jpg"},
            ]
            result = await telegram_publish_photo_album(
                channel_id="@testchannel",
                photos=photos,
                response_format="json",
            )

            assert result["album_id"] == "12345678901234567"
            assert result["message_count"] == 3
            assert result["first_message_id"] == 12345
            assert len(result["messages"]) == 3
            assert "error" not in result


class TestResolveParseModeHelper:
    """Tests for the _resolve_parse_mode helper."""

    def test_markdown_v2(self):
        from telegram.constants import ParseMode
        from telegram_bot_mcp.telegram_bot.client import _resolve_parse_mode
        assert _resolve_parse_mode("MarkdownV2") == ParseMode.MARKDOWN_V2
        assert _resolve_parse_mode("markdownv2") == ParseMode.MARKDOWN_V2
        assert _resolve_parse_mode("markdown_v2") == ParseMode.MARKDOWN_V2

    def test_markdown_v1(self):
        from telegram.constants import ParseMode
        from telegram_bot_mcp.telegram_bot.client import _resolve_parse_mode
        assert _resolve_parse_mode("Markdown") == ParseMode.MARKDOWN
        assert _resolve_parse_mode("markdown") == ParseMode.MARKDOWN

    def test_html(self):
        from telegram.constants import ParseMode
        from telegram_bot_mcp.telegram_bot.client import _resolve_parse_mode
        assert _resolve_parse_mode("HTML") == ParseMode.HTML
        assert _resolve_parse_mode("html") == ParseMode.HTML

    def test_none_variants(self):
        from telegram_bot_mcp.telegram_bot.client import _resolve_parse_mode
        assert _resolve_parse_mode(None) is None
        assert _resolve_parse_mode("None") is None
        assert _resolve_parse_mode("") is None

    def test_unknown_falls_back_to_none(self):
        from telegram_bot_mcp.telegram_bot.client import _resolve_parse_mode
        assert _resolve_parse_mode("InvalidMode") is None


class TestRetryLogic:
    """Tests for the _retry helper method."""

    @pytest.mark.asyncio
    async def test_retry_succeeds_first_attempt(self, mock_bot_token):
        """_retry returns immediately on success."""
        client = TelegramBotClient()
        fn = AsyncMock(return_value="ok")
        result = await client._retry(fn, "test_op")
        assert result == "ok"
        assert fn.call_count == 1

    @pytest.mark.asyncio
    async def test_retry_rate_limit_then_success(self, mock_bot_token):
        """_retry waits on RetryAfter without counting against MAX_RETRIES."""
        client = TelegramBotClient()
        rate_err = RetryAfter(3)
        fn = AsyncMock(side_effect=[rate_err, "ok"])

        with patch("telegram_bot_mcp.telegram_bot.client.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            result = await client._retry(fn, "test_op")

        assert result == "ok"
        assert fn.call_count == 2
        mock_sleep.assert_called_once_with(4)  # retry_after(3) + 1

    @pytest.mark.asyncio
    async def test_retry_timeout_succeeds_on_second_attempt(self, mock_bot_token):
        """_retry retries once on TimedOut and succeeds."""
        client = TelegramBotClient()
        fn = AsyncMock(side_effect=[TimedOut(), "ok"])

        with patch("telegram_bot_mcp.telegram_bot.client.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            result = await client._retry(fn, "test_op")

        assert result == "ok"
        assert fn.call_count == 2
        mock_sleep.assert_called_once_with(2)  # attempt 1 * 2

    @pytest.mark.asyncio
    async def test_retry_network_error_succeeds_on_second_attempt(self, mock_bot_token):
        """_retry retries on NetworkError."""
        client = TelegramBotClient()
        fn = AsyncMock(side_effect=[NetworkError("connection reset"), "ok"])

        with patch("telegram_bot_mcp.telegram_bot.client.asyncio.sleep", new_callable=AsyncMock):
            result = await client._retry(fn, "test_op")

        assert result == "ok"

    @pytest.mark.asyncio
    async def test_retry_exhausted_raises(self, mock_bot_token):
        """_retry raises after MAX_RETRIES transient failures."""
        client = TelegramBotClient()
        fn = AsyncMock(side_effect=TimedOut())

        with patch("telegram_bot_mcp.telegram_bot.client.asyncio.sleep", new_callable=AsyncMock):
            with pytest.raises(TimedOut):
                await client._retry(fn, "test_op")

        assert fn.call_count == client.MAX_RETRIES

    @pytest.mark.asyncio
    async def test_retry_non_transient_error_raises_immediately(self, mock_bot_token):
        """_retry does not retry on non-transient TelegramError."""
        client = TelegramBotClient()
        fn = AsyncMock(side_effect=TelegramError("Unauthorized"))

        with patch("telegram_bot_mcp.telegram_bot.client.asyncio.sleep", new_callable=AsyncMock):
            with pytest.raises(TelegramError):
                await client._retry(fn, "test_op")

        assert fn.call_count == 1  # no retry


class TestSplitText:
    """Tests for _split_text helper."""

    def test_short_text_not_split(self, mock_bot_token):
        client = TelegramBotClient()
        text = "short"
        assert client._split_text(text) == ["short"]

    def test_exact_limit_not_split(self, mock_bot_token):
        client = TelegramBotClient()
        text = "x" * TelegramBotClient.MAX_MESSAGE_LENGTH
        assert client._split_text(text) == [text]

    def test_long_text_split_on_newline(self, mock_bot_token):
        client = TelegramBotClient()
        # Build text > 4096 with a newline before the limit
        part1 = "a" * 4000 + "\n"
        part2 = "b" * 200
        text = part1 + part2
        chunks = client._split_text(text)
        assert len(chunks) == 2
        assert chunks[0] == "a" * 4000
        assert chunks[1] == "b" * 200

    def test_long_text_no_newline_split_at_limit(self, mock_bot_token):
        client = TelegramBotClient()
        text = "x" * 5000
        chunks = client._split_text(text)
        assert len(chunks) == 2
        assert len(chunks[0]) == TelegramBotClient.MAX_MESSAGE_LENGTH
        assert chunks[1] == "x" * (5000 - TelegramBotClient.MAX_MESSAGE_LENGTH)


class TestClientErrorPaths:
    """Tests for error handling in TelegramBotClient methods."""

    @pytest.mark.asyncio
    async def test_publish_message_long_text_sends_parts(self, mock_bot_token, mock_telegram_message):
        """publish_message sends multiple messages for long text and returns parts count."""
        long_text = "word " * 1000  # ~5000 chars
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.send_message = AsyncMock(return_value=mock_telegram_message)
            client = TelegramBotClient()
            result = await client.publish_message(channel_id="@testchannel", text=long_text)

        assert "parts" in result
        assert result["parts"] >= 2
        assert mock_bot_instance.send_message.call_count >= 2

    @pytest.mark.asyncio
    async def test_publish_message_telegram_error(self, mock_bot_token):
        """publish_message re-raises TelegramError."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.send_message = AsyncMock(side_effect=TelegramError("Bad request"))
            client = TelegramBotClient()
            with pytest.raises(TelegramError, match="Failed to publish message"):
                await client.publish_message(channel_id="@testchannel", text="hi")

    @pytest.mark.asyncio
    async def test_publish_photo_telegram_error(self, mock_bot_token):
        """publish_photo re-raises TelegramError."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.send_photo = AsyncMock(side_effect=TelegramError("Bad request"))
            client = TelegramBotClient()
            with pytest.raises(TelegramError, match="Failed to publish photo"):
                await client.publish_photo(channel_id="@testchannel", photo="/img.jpg")

    @pytest.mark.asyncio
    async def test_publish_photo_album_empty_list(self, mock_bot_token):
        """publish_photo_album raises ValueError for empty list."""
        client = TelegramBotClient()
        with pytest.raises(ValueError, match="cannot be empty"):
            await client.publish_photo_album(channel_id="@testchannel", photos=[])

    @pytest.mark.asyncio
    async def test_publish_photo_album_single_missing_photo_field(self, mock_bot_token):
        """publish_photo_album raises ValueError when single item has no photo field."""
        client = TelegramBotClient()
        with pytest.raises(ValueError, match="missing 'photo' field"):
            await client.publish_photo_album(
                channel_id="@testchannel",
                photos=[{"caption": "no photo key"}],
            )

    @pytest.mark.asyncio
    async def test_edit_message_telegram_error(self, mock_bot_token):
        """edit_message re-raises TelegramError."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.edit_message_text = AsyncMock(side_effect=TelegramError("can't edit"))
            client = TelegramBotClient()
            with pytest.raises(TelegramError, match="Failed to edit message"):
                await client.edit_message(channel_id="@testchannel", message_id=1, new_text="x")

    @pytest.mark.asyncio
    async def test_edit_message_caption_telegram_error(self, mock_bot_token):
        """edit_message_caption re-raises TelegramError."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.edit_message_caption = AsyncMock(side_effect=TelegramError("can't edit"))
            client = TelegramBotClient()
            with pytest.raises(TelegramError, match="Failed to edit message caption"):
                await client.edit_message_caption(channel_id="@testchannel", message_id=1, new_caption="x")

    @pytest.mark.asyncio
    async def test_delete_message_telegram_error(self, mock_bot_token):
        """delete_message re-raises TelegramError."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.delete_message = AsyncMock(side_effect=TelegramError("can't delete"))
            client = TelegramBotClient()
            with pytest.raises(TelegramError, match="Failed to delete message"):
                await client.delete_message(channel_id="@testchannel", message_id=1)

    @pytest.mark.asyncio
    async def test_get_channel_info_telegram_error(self, mock_bot_token):
        """get_channel_info re-raises TelegramError."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.get_chat = AsyncMock(side_effect=TelegramError("chat not found"))
            client = TelegramBotClient()
            with pytest.raises(TelegramError, match="Failed to get channel info"):
                await client.get_channel_info(channel_id="@testchannel")

    def test_update_cache_existing_message(self, mock_bot_token):
        """_update_cache replaces an existing cached message."""
        client = TelegramBotClient()
        old = {"message_id": 1, "text": "old"}
        client._message_cache["@ch"] = [old]
        new = {"message_id": 1, "text": "new"}
        client._update_cache("@ch", new)
        assert client._message_cache["@ch"][0]["text"] == "new"
        assert len(client._message_cache["@ch"]) == 1

    def test_update_cache_new_message_added(self, mock_bot_token):
        """_update_cache appends when message_id is not in cache."""
        client = TelegramBotClient()
        client._message_cache["@ch"] = [{"message_id": 1, "text": "first"}]
        client._update_cache("@ch", {"message_id": 2, "text": "second"})
        assert len(client._message_cache["@ch"]) == 2

    def test_remove_from_cache(self, mock_bot_token):
        """_remove_from_cache removes the right message."""
        client = TelegramBotClient()
        client._message_cache["@ch"] = [
            {"message_id": 1},
            {"message_id": 2},
            {"message_id": 3},
        ]
        client._remove_from_cache("@ch", 2)
        ids = [m["message_id"] for m in client._message_cache["@ch"]]
        assert ids == [1, 3]

    @pytest.mark.asyncio
    async def test_close_does_not_raise(self, mock_bot_token):
        """close() completes without error."""
        client = TelegramBotClient()
        await client.close()  # should not raise


class TestCheckChannelAccess:
    """Tests for check_channel_access."""

    def _make_admin(self, bot_id, can_post=True, can_edit=False, can_delete=False):
        admin = Mock()
        admin.user = Mock()
        admin.user.id = bot_id
        admin.can_post_messages = can_post
        admin.can_edit_messages = can_edit
        admin.can_delete_messages = can_delete
        return admin

    @pytest.mark.asyncio
    async def test_bot_not_admin(self, mock_bot_token):
        """Returns can_post=False when bot is not in admin list."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            bot_info = Mock(id=1111, username="mybot")
            other_admin = self._make_admin(9999)
            mock_bot_instance.get_me = AsyncMock(return_value=bot_info)
            mock_bot_instance.get_chat_administrators = AsyncMock(return_value=[other_admin])
            client = TelegramBotClient()
            result = await client.check_channel_access("@testchannel")

        assert result["can_post"] is False
        assert result["is_admin"] is False
        assert "not an administrator" in result["reason"]

    @pytest.mark.asyncio
    async def test_bot_admin_no_post_permission(self, mock_bot_token):
        """Returns can_post=False when bot is admin but lacks can_post_messages."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            bot_info = Mock(id=1111, username="mybot")
            bot_admin = self._make_admin(1111, can_post=False)
            mock_bot_instance.get_me = AsyncMock(return_value=bot_info)
            mock_bot_instance.get_chat_administrators = AsyncMock(return_value=[bot_admin])
            client = TelegramBotClient()
            result = await client.check_channel_access("@testchannel")

        assert result["can_post"] is False
        assert result["is_admin"] is True
        assert result["permissions"]["can_post_messages"] is False
        assert "Post Messages" in result["reason"]

    @pytest.mark.asyncio
    async def test_bot_has_full_access(self, mock_bot_token):
        """Returns can_post=True with permissions dict when bot is a full admin."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            bot_info = Mock(id=1111, username="mybot")
            bot_admin = self._make_admin(1111, can_post=True, can_edit=True, can_delete=True)
            mock_bot_instance.get_me = AsyncMock(return_value=bot_info)
            mock_bot_instance.get_chat_administrators = AsyncMock(return_value=[bot_admin])
            client = TelegramBotClient()
            result = await client.check_channel_access("@testchannel")

        assert result["can_post"] is True
        assert result["is_admin"] is True
        assert result["bot_username"] == "mybot"
        assert result["permissions"]["can_post_messages"] is True
        assert result["permissions"]["can_edit_messages"] is True
        assert result["permissions"]["can_delete_messages"] is True

    @pytest.mark.asyncio
    async def test_check_channel_access_telegram_error(self, mock_bot_token):
        """check_channel_access re-raises TelegramError."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.get_me = AsyncMock(side_effect=TelegramError("chat not found"))
            client = TelegramBotClient()
            with pytest.raises(TelegramError, match="Failed to check channel access"):
                await client.check_channel_access("@testchannel")


class TestToolErrorPaths:
    """Tests for error responses returned by server tool functions."""

    def _make_client(self, **overrides):
        """Return a Mock client with AsyncMock stubs."""
        client = Mock()
        defaults = {
            "publish_message": AsyncMock(return_value={"message_id": 1, "chat_id": 1, "date": "x", "text": "t", "link": None}),
            "publish_photo": AsyncMock(return_value={"message_id": 1, "chat_id": 1, "date": "x", "caption": None, "photo": None, "link": None}),
            "publish_photo_album": AsyncMock(return_value={"album_id": "a", "message_count": 2, "first_message_id": 1, "chat_id": 1, "messages": []}),
            "edit_message": AsyncMock(return_value={"message_id": 1, "chat_id": 1, "date": "x", "edit_date": None, "text": "t", "link": None}),
            "edit_message_caption": AsyncMock(return_value={"message_id": 1, "chat_id": 1, "date": "x", "edit_date": None, "caption": "c", "photo": None, "link": None}),
            "delete_message": AsyncMock(return_value=True),
            "get_channel_info": AsyncMock(return_value={"id": 1, "title": "T", "username": "t", "type": "channel", "description": None, "invite_link": None, "member_count": 0}),
            "check_channel_access": AsyncMock(return_value={"can_post": True, "is_admin": True, "channel_id": "@t", "bot_username": "bot", "permissions": {"can_post_messages": True, "can_edit_messages": False, "can_delete_messages": False}}),
            "search_messages": Mock(return_value={"messages": [], "count": 0, "total": 0, "offset": 0, "limit": 10, "has_more": False, "next_offset": None, "query": None, "channel_id": "@t"}),
        }
        defaults.update(overrides)
        for attr, val in defaults.items():
            setattr(client, attr, val)
        return client

    # --- Markdown format responses ---

    @pytest.mark.asyncio
    async def test_publish_message_markdown_response(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = await telegram_publish_message(channel_id="@t", text="hi", response_format="markdown")
        assert "content" in result
        assert "data" in result

    @pytest.mark.asyncio
    async def test_publish_photo_markdown_response(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = await telegram_publish_photo(channel_id="@t", photo="/img.jpg", response_format="markdown")
        assert "content" in result

    @pytest.mark.asyncio
    async def test_publish_photo_album_markdown_response(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = await telegram_publish_photo_album(channel_id="@t", photos=[{"photo": "/a.jpg"}, {"photo": "/b.jpg"}], response_format="markdown")
        assert "content" in result

    @pytest.mark.asyncio
    async def test_edit_message_markdown_response(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = await telegram_edit_message(channel_id="@t", message_id=1, new_text="x", response_format="markdown")
        assert "content" in result

    @pytest.mark.asyncio
    async def test_edit_message_caption_markdown_response(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = await telegram_edit_message_caption(channel_id="@t", message_id=1, new_caption="x", response_format="markdown")
        assert "content" in result

    @pytest.mark.asyncio
    async def test_delete_message_markdown_response(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = await telegram_delete_message(channel_id="@t", message_id=1, response_format="markdown")
        assert "content" in result

    def test_search_messages_markdown_response(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = telegram_search_messages(channel_id="@t", response_format="markdown")
        assert "content" in result

    @pytest.mark.asyncio
    async def test_get_channel_info_markdown_response(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = await telegram_get_channel_info(channel_id="@t", response_format="markdown")
        assert "content" in result

    # --- TelegramError paths ---

    @pytest.mark.asyncio
    async def test_publish_message_tool_telegram_error(self, mock_bot_token):
        client = self._make_client(publish_message=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_message(channel_id="@t", text="hi", response_format="json")
        assert result["status"] == "failed"
        assert "error" in result

    @pytest.mark.asyncio
    async def test_publish_photo_tool_telegram_error(self, mock_bot_token):
        client = self._make_client(publish_photo=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo(channel_id="@t", photo="/img.jpg", response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_publish_photo_album_tool_telegram_error(self, mock_bot_token):
        client = self._make_client(publish_photo_album=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo_album(channel_id="@t", photos=[{"photo": "/a.jpg"}], response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_edit_message_tool_telegram_error(self, mock_bot_token):
        client = self._make_client(edit_message=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message(channel_id="@t", message_id=1, new_text="x", response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_edit_message_caption_tool_telegram_error(self, mock_bot_token):
        client = self._make_client(edit_message_caption=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message_caption(channel_id="@t", message_id=1, new_caption="x", response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_delete_message_tool_telegram_error(self, mock_bot_token):
        client = self._make_client(delete_message=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_delete_message(channel_id="@t", message_id=1, response_format="json")
        assert result["status"] == "failed"

    def test_search_messages_tool_error(self, mock_bot_token):
        client = self._make_client(search_messages=Mock(side_effect=Exception("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = telegram_search_messages(channel_id="@t", response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_get_channel_info_tool_telegram_error(self, mock_bot_token):
        client = self._make_client(get_channel_info=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_get_channel_info(channel_id="@t", response_format="json")
        assert result["status"] == "failed"

    # --- telegram_check_channel_access tool ---

    @pytest.mark.asyncio
    async def test_check_channel_access_tool_json_success(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = await telegram_check_channel_access(channel_id="@t", response_format="json")
        assert result["can_post"] is True
        assert result["status"] == "success"

    @pytest.mark.asyncio
    async def test_check_channel_access_tool_markdown(self, mock_bot_token):
        with patch("telegram_bot_mcp.server._get_client", return_value=self._make_client()):
            result = await telegram_check_channel_access(channel_id="@t", response_format="markdown")
        assert "content" in result
        assert "✅" in result["content"]

    @pytest.mark.asyncio
    async def test_check_channel_access_tool_not_admin_markdown(self, mock_bot_token):
        access_result = {"can_post": False, "is_admin": False, "channel_id": "@t", "reason": "Not admin"}
        client = self._make_client(check_channel_access=AsyncMock(return_value=access_result))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_check_channel_access(channel_id="@t", response_format="markdown")
        assert "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_check_channel_access_tool_telegram_error(self, mock_bot_token):
        client = self._make_client(check_channel_access=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_check_channel_access(channel_id="@t", response_format="json")
        assert result["status"] == "failed"
        assert "error" in result

    @pytest.mark.asyncio
    async def test_check_channel_access_tool_unexpected_error(self, mock_bot_token):
        client = self._make_client(check_channel_access=AsyncMock(side_effect=RuntimeError("oops")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_check_channel_access(channel_id="@t", response_format="json")
        assert result["status"] == "failed"

    # --- Exception (non-TelegramError) paths ---

    @pytest.mark.asyncio
    async def test_publish_message_unexpected_error(self, mock_bot_token):
        client = self._make_client(publish_message=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_message(channel_id="@t", text="hi", response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_publish_photo_unexpected_error(self, mock_bot_token):
        client = self._make_client(publish_photo=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo(channel_id="@t", photo="/img.jpg", response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_publish_photo_album_value_error(self, mock_bot_token):
        """publish_photo_album tool handles ValueError from client."""
        client = self._make_client(publish_photo_album=AsyncMock(side_effect=ValueError("empty")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo_album(channel_id="@t", photos=[], response_format="json")
        assert result["status"] == "failed"
        assert "Invalid photo album" in result["message"]

    @pytest.mark.asyncio
    async def test_publish_photo_album_unexpected_error(self, mock_bot_token):
        client = self._make_client(publish_photo_album=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo_album(channel_id="@t", photos=[{"photo": "/a.jpg"}], response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_edit_message_unexpected_error(self, mock_bot_token):
        client = self._make_client(edit_message=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message(channel_id="@t", message_id=1, new_text="x", response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_edit_message_caption_unexpected_error(self, mock_bot_token):
        client = self._make_client(edit_message_caption=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message_caption(channel_id="@t", message_id=1, new_caption="x", response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_delete_message_unexpected_error(self, mock_bot_token):
        client = self._make_client(delete_message=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_delete_message(channel_id="@t", message_id=1, response_format="json")
        assert result["status"] == "failed"

    @pytest.mark.asyncio
    async def test_get_channel_info_unexpected_error(self, mock_bot_token):
        client = self._make_client(get_channel_info=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_get_channel_info(channel_id="@t", response_format="json")
        assert result["status"] == "failed"

    # --- Hint injection in edit_message TelegramError ---

    @pytest.mark.asyncio
    async def test_edit_message_tool_hint_cant_edit(self, mock_bot_token):
        """edit_message appends a note when Telegram says can't be edited."""
        err = TelegramError("Message can't be edited")
        client = self._make_client(edit_message=AsyncMock(side_effect=err))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message(channel_id="@t", message_id=1, new_text="x", response_format="json")
        assert "edit_message_caption" in result["message"]

    @pytest.mark.asyncio
    async def test_edit_message_tool_hint_not_modified(self, mock_bot_token):
        """edit_message appends a note when content is identical."""
        err = TelegramError("Message is not modified")
        client = self._make_client(edit_message=AsyncMock(side_effect=err))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message(channel_id="@t", message_id=1, new_text="x", response_format="json")
        assert "identical" in result["message"]

    @pytest.mark.asyncio
    async def test_edit_caption_tool_hint_cant_edit(self, mock_bot_token):
        err = TelegramError("Message can't be edited")
        client = self._make_client(edit_message_caption=AsyncMock(side_effect=err))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message_caption(channel_id="@t", message_id=1, new_caption="x", response_format="json")
        assert "edit_message" in result["message"]

    @pytest.mark.asyncio
    async def test_edit_caption_tool_hint_not_modified(self, mock_bot_token):
        err = TelegramError("Message is not modified")
        client = self._make_client(edit_message_caption=AsyncMock(side_effect=err))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message_caption(channel_id="@t", message_id=1, new_caption="x", response_format="json")
        assert "identical" in result["message"]

    @pytest.mark.asyncio
    async def test_edit_caption_tool_hint_no_caption(self, mock_bot_token):
        err = TelegramError("Message has no caption")
        client = self._make_client(edit_message_caption=AsyncMock(side_effect=err))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message_caption(channel_id="@t", message_id=1, new_caption="x", response_format="json")
        assert "caption" in result["message"]

    # --- delete_message returns False ---

    @pytest.mark.asyncio
    async def test_delete_message_returns_false(self, mock_bot_token):
        """delete_message tool shows failed status when bot returns False."""
        client = self._make_client(delete_message=AsyncMock(return_value=False))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_delete_message(channel_id="@t", message_id=1, response_format="json")
        assert result["success"] is False
        assert result["status"] == "failed"

    # --- formatter branches ---

    @pytest.mark.asyncio
    async def test_publish_photo_markdown_with_photo_and_file_size(self, mock_bot_token):
        """_format_photo_markdown includes photo dimensions and file size."""
        photo_result = {
            "message_id": 1, "chat_id": 1, "date": "2024-01-01T00:00:00",
            "caption": "cap", "link": None,
            "photo": {"width": 800, "height": 600, "file_size": 12345},
        }
        client = self._make_client(publish_photo=AsyncMock(return_value=photo_result))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo(channel_id="@t", photo="/img.jpg", response_format="markdown")
        assert "800x600" in result["content"]
        assert "12345" in result["content"]

    def test_search_messages_markdown_with_results(self, mock_bot_token):
        """_format_search_markdown renders messages list and has_more notice."""
        search_result = {
            "messages": [
                {"message_id": 1, "text": "Hello world", "date": "2024-01-01T10:00:00"},
                {"message_id": 2, "text": "Goodbye", "date": "2024-01-01T11:00:00"},
            ],
            "count": 2, "total": 5, "offset": 0, "limit": 2,
            "has_more": True, "next_offset": 2, "query": "hello", "channel_id": "@t",
        }
        client = self._make_client(search_messages=Mock(return_value=search_result))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = telegram_search_messages(channel_id="@t", query="hello", response_format="markdown")
        assert "Hello world" in result["content"] or "Message 1" in result["content"]
        assert "more messages available" in result["content"]

    @pytest.mark.asyncio
    async def test_delete_message_markdown_failed(self, mock_bot_token):
        """_format_delete_markdown shows failure when success=False."""
        client = self._make_client(delete_message=AsyncMock(return_value=False))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_delete_message(channel_id="@t", message_id=1, response_format="markdown")
        assert "Failed to Delete" in result["content"]

    @pytest.mark.asyncio
    async def test_get_channel_info_markdown_with_username(self, mock_bot_token):
        """_format_channel_info_markdown includes username when present."""
        info = {"id": -1, "title": "My Chan", "username": "mychan", "type": "channel",
                "description": "desc", "invite_link": "https://t.me/mychan", "member_count": 42}
        client = self._make_client(get_channel_info=AsyncMock(return_value=info))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_get_channel_info(channel_id="@mychan", response_format="markdown")
        assert "@mychan" in result["content"]
        assert "42" in result["content"]

    # --- Markdown error responses (else branches in exception handlers) ---

    @pytest.mark.asyncio
    async def test_publish_message_telegram_error_markdown(self, mock_bot_token):
        client = self._make_client(publish_message=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_message(channel_id="@t", text="hi", response_format="markdown")
        assert "content" in result
        assert "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_publish_message_unexpected_error_markdown(self, mock_bot_token):
        client = self._make_client(publish_message=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_message(channel_id="@t", text="hi", response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_publish_photo_telegram_error_markdown(self, mock_bot_token):
        client = self._make_client(publish_photo=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo(channel_id="@t", photo="/img.jpg", response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_publish_photo_unexpected_error_markdown(self, mock_bot_token):
        client = self._make_client(publish_photo=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo(channel_id="@t", photo="/img.jpg", response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_publish_photo_album_value_error_markdown(self, mock_bot_token):
        client = self._make_client(publish_photo_album=AsyncMock(side_effect=ValueError("empty")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo_album(channel_id="@t", photos=[], response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_publish_photo_album_telegram_error_markdown(self, mock_bot_token):
        client = self._make_client(publish_photo_album=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo_album(channel_id="@t", photos=[{"photo": "/a.jpg"}, {"photo": "/b.jpg"}], response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_publish_photo_album_unexpected_error_markdown(self, mock_bot_token):
        client = self._make_client(publish_photo_album=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_publish_photo_album(channel_id="@t", photos=[{"photo": "/a.jpg"}], response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_edit_message_telegram_error_markdown(self, mock_bot_token):
        client = self._make_client(edit_message=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message(channel_id="@t", message_id=1, new_text="x", response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_edit_message_unexpected_error_markdown(self, mock_bot_token):
        client = self._make_client(edit_message=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message(channel_id="@t", message_id=1, new_text="x", response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_edit_message_caption_telegram_error_markdown(self, mock_bot_token):
        client = self._make_client(edit_message_caption=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message_caption(channel_id="@t", message_id=1, new_caption="x", response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_edit_message_caption_unexpected_error_markdown(self, mock_bot_token):
        client = self._make_client(edit_message_caption=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_edit_message_caption(channel_id="@t", message_id=1, new_caption="x", response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_delete_message_telegram_error_markdown(self, mock_bot_token):
        client = self._make_client(delete_message=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_delete_message(channel_id="@t", message_id=1, response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_delete_message_unexpected_error_markdown(self, mock_bot_token):
        client = self._make_client(delete_message=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_delete_message(channel_id="@t", message_id=1, response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_check_channel_access_unexpected_error_markdown(self, mock_bot_token):
        client = self._make_client(check_channel_access=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_check_channel_access(channel_id="@t", response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_get_channel_info_telegram_error_markdown(self, mock_bot_token):
        client = self._make_client(get_channel_info=AsyncMock(side_effect=TelegramError("bad")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_get_channel_info(channel_id="@t", response_format="markdown")
        assert "content" in result and "❌" in result["content"]

    @pytest.mark.asyncio
    async def test_get_channel_info_unexpected_error_markdown(self, mock_bot_token):
        client = self._make_client(get_channel_info=AsyncMock(side_effect=RuntimeError("crash")))
        with patch("telegram_bot_mcp.server._get_client", return_value=client):
            result = await telegram_get_channel_info(channel_id="@t", response_format="markdown")
        assert "content" in result and "❌" in result["content"]


class TestClientPublishPhotoAlbumTelegramError:
    """Tests for TelegramError path in publish_photo_album client method."""

    @pytest.mark.asyncio
    async def test_publish_photo_album_telegram_error(self, mock_bot_token):
        """publish_photo_album re-raises TelegramError from send_media_group."""
        with patch("telegram_bot_mcp.telegram_bot.client.Bot") as MockBot:
            mock_bot_instance = MockBot.return_value
            mock_bot_instance.send_media_group = AsyncMock(side_effect=TelegramError("flood"))
            client = TelegramBotClient()
            with pytest.raises(TelegramError, match="Failed to publish photo album"):
                await client.publish_photo_album(
                    channel_id="@testchannel",
                    photos=[{"photo": "/a.jpg"}, {"photo": "/b.jpg"}],
                )
