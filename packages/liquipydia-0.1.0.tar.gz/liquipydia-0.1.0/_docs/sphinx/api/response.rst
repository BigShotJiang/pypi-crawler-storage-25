Response
========

.. autoclass:: liquipydia.ApiResponse
