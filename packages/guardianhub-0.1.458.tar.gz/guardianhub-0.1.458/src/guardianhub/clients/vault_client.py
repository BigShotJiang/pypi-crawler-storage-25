import os
import hvac
from typing import Optional, Dict, Any
from guardianhub import get_logger


logger = get_logger(__name__)


class VaultClient:
    """Vault client for secure credential management with tenant support"""
    
    def __init__(self, tenant_id: str):
        # Lazy import to avoid circular dependency with settings.py
        from guardianhub.config.settings import settings
        
        # Use settings.vault which reads from config JSON or env vars (GH_VAULT__URL, GH_VAULT__TOKEN)
        self.vault_url = settings.vault.url
        self.vault_token = settings.vault.token
        self.tenant_id = tenant_id
        self.namespace = "yantramops/tenants"
        self.client = None
        
    def _get_client(self) -> hvac.Client:
        """Get or create Vault client"""
        if not self.client:
            if not self.vault_token:
                raise ValueError("Vault token not available - set GH_VAULT__TOKEN or add to config JSON")
            
            try:
                self.client = hvac.Client(
                    url=self.vault_url,
                    token=self.vault_token,
                    verify=False
                )
                
                if not self.client.is_authenticated():
                    raise ValueError("Failed to authenticate with Vault")
                    
            except Exception as e:
                raise ValueError(f"Failed to connect to Vault: {str(e)}")
        
        return self.client
    
    def get_postgres_credentials(self) -> Dict[str, str]:
        """Get all postgres credentials for the current tenant"""
        try:
            client = self._get_client()
            
            # Use tenant-specific postgres credential path
            path = f"{self.namespace}/{self.tenant_id}/core/postgres_cred"
            
            logger.info(f"Reading postgres credentials from Vault path: {path}")
            response = client.secrets.kv.v2.read_secret_version(path=path)
            
            if not response or 'data' not in response:
                raise ValueError("No postgres credentials found in Vault")
            
            return response['data']['data']
            
        except Exception as e:
            logger.error(f"Failed to retrieve postgres credentials: {str(e)}")
            raise


def get_database_credentials_from_vault(tenant_id) -> Dict[str, str]:
    """Get database credentials from Vault with fallback to environment variables"""
    try:
        vault_client = VaultClient(tenant_id=tenant_id)
        postgres_creds = vault_client.get_postgres_credentials()
        
        logger.info(f"✅ Retrieved database credentials from Vault for tenant: {tenant_id}")
        
        return {
            "host": postgres_creds.get("DB_HOST", "guardianhub"),
            "port": postgres_creds.get("DB_PORT", "5432"),
            "user": postgres_creds.get("DB_USERNAME", "adminuser"),
            "password": postgres_creds.get("DB_PASSWORD", "masteradminpassword123"),
            "database": postgres_creds.get("MASTER_TENANT_DB", "db_guardian_tenant_master")
        }
        
    except Exception as e:
        logger.warning(f"⚠️ Failed to get credentials from Vault: {e}")
        logger.info("🔄 Falling back to environment variables...")
        
        # Fallback to environment variables
        return {
            "host": os.getenv("POSTGRES_HOST", "guardianhub"),
            "port": os.getenv("POSTGRES_PORT", "5432"),
            "user": os.getenv("MASTER_DB_ADMIN", "adminuser"),
            "password": os.getenv("MASTER_DB_ADMIN_PASSWORD", "masteradminpassword123"),
            "database": os.getenv("MASTER_TENANT_DB", "db_guardian_tenant_master")
        }
