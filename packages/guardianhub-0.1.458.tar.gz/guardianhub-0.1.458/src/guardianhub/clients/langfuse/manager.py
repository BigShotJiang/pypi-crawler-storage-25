"""Langfuse Manager for singleton connection management.

This module provides a manager that ensures only one instance of the Langfuse
client is created and used throughout the application.
"""

from __future__ import annotations

from typing import Optional

import httpx
from langfuse import Langfuse

from guardianhub import get_logger
from guardianhub.config.settings import settings
from guardianhub.observability.otel_helper import configure_resource

LOGGER = get_logger(__name__)

# TODO: For future reference - ThreadPool impl to handle multiple connection
class LangfuseManager:
    """Manages the singleton instance of the Langfuse client."""
    _client: Optional[Langfuse] = None
    _initialized = False
    _current_host: Optional[str] = None
    _current_public_key: Optional[str] = None

    @classmethod
    def get_instance(
            cls,
            public_key: Optional[str] = None,
            secret_key: Optional[str] = None,
            host: Optional[str] = None,
            **kwargs
    ) -> Optional[Langfuse]:

        # 1. Resolve what the host SHOULD be right now
        target_host = host or settings.endpoints.get("LANGFUSE_HOST")
        target_pk = public_key or settings.credentials.get("LANGFUSE_PUBLIC_KEY")
        target_sk = secret_key or settings.credentials.get("LANGFUSE_SECRET_KEY")

        # 2. If we already have a client, check if it's the RIGHT one
        # We check public_key too in case two tenants use the same host but different projects
        if cls._client:
            if cls._current_host == target_host and cls._current_public_key == target_pk:
                return cls._client
            else:
                LOGGER.info(f"🔄 Tenant Switch detected (Host: {target_host}). Resetting Langfuse singleton.")
                cls.reset()

        # 3. Validation
        if not target_pk or not target_sk:
            LOGGER.warning("Langfuse credentials missing. Skipping initialization.")
            return None

        # 4. Initialization
        try:
            LOGGER.info(f"🚀 Initializing New Langfuse Client for Host: {target_host}")
            cls._client = Langfuse(
                public_key=target_pk,
                secret_key=target_sk,
                host=target_host,
                **kwargs
            )
            # Store the host and public_key separately since Langfuse client doesn't expose them
            cls._current_host = target_host
            cls._current_public_key = target_pk

            # Use the connection check
            if cls.check_langfuse_connection():
                cls._initialized = True
                return cls._client

            # If connection fails, we don't cache it
            cls._client = None
            cls._current_host = None
            cls._current_public_key = None
            return None

        except Exception as exc:
            LOGGER.exception("Failed to initialize Langfuse client: %s", exc)
            cls._client = None
            cls._current_host = None
            cls._current_public_key = None
            return None

    @classmethod
    def check_langfuse_connection(cls) -> bool:
        """
        Check if the Langfuse connection is valid by attempting to authenticate.

        Returns:
            bool: True if the connection is valid, False otherwise
        """
        if not cls._client:
            LOGGER.warning("Langfuse client is not initialized")
            return False

        try:
            # Test the connection with a timeout to prevent hanging
            is_authenticated = cls._client.auth_check()
            if is_authenticated:
                LOGGER.info("✅ Successfully authenticated with Langfuse")
                return True
            else:
                LOGGER.warning("❌ Failed to authenticate with Langfuse - Invalid credentials")
                return False
        except httpx.ConnectError as e:
            LOGGER.error(f"❌ Could not connect to Langfuse server: {str(e)}. "
                         "Please check your network connection and Langfuse server status.")
            return False
        except Exception as e:
            LOGGER.error(f"❌ Error connecting to Langfuse: {str(e)}", exc_info=True)
            return False

    @classmethod
    def flush(cls) -> None:
        """Flushes the managed Langfuse client instance."""
        if cls._client:
            cls._client.flush()
            LOGGER.info("Langfuse manager flushed the client.")

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton to allow creating a new client with different credentials."""
        if cls._client:
            cls._client.flush()
            cls._client = None
        cls._initialized = False
        cls._current_host = None
        cls._current_public_key = None
        LOGGER.info("Langfuse manager reset - new client can be initialized")
