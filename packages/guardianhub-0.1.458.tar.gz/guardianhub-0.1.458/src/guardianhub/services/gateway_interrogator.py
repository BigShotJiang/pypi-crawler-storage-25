# guardianhub_sdk/services/gateway_interrogator.py
from guardianhub.config.settings import settings
from guardianhub import get_logger
import websockets
from typing import Dict

logger = get_logger(__name__)
class SovereignGatewayInterrogator:
    def __init__(self, gateway_url: str = None):
        self.gateway_url = gateway_url or settings.endpoints.GATEWAY_WS_URL
        self.ws = None

    async def _get_auth_context(self, GATEWAY_TOKEN=None) -> Dict[str, str]:
        """Recover tenant-specific Gateway token from the Vault."""
        from opentelemetry import baggage
        from guardianhub import DEFAULT_SYSTEM_TENANT_ID

        tenant_id = baggage.get_baggage("tenant_id") or DEFAULT_SYSTEM_TENANT_ID

        # 🏢 Recovery: In a true sovereign setup, pull the token from the tenant's container
        from guardianhub.services import TenantContainerRegistry
        container = await TenantContainerRegistry.get_container(tenant_id=tenant_id)

        # Pulling the specific Gateway token authorized for this tenant
        token = container.vault.get("GATEWAY_TOKEN") or GATEWAY_TOKEN
        return {"tenant_id": tenant_id, "token": token}

    async def connect(self):
        auth = await self._get_auth_context()
        headers = {
            "Authorization": f"Bearer {auth['token']}",
            "X-Tenant-ID": auth['tenant_id']
        }
        self.ws = await websockets.connect(self.gateway_url, additional_headers=headers)
        logger.info(f"🔌 WebSocket established for Tenant: {auth['tenant_id']}")