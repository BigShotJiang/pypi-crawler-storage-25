import base64
from typing import Any, Optional, Union, Tuple
import os

# 1. SDK Check (Brain/Muscle Separation)
try:
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    HAS_OTEL_SDK = True
except ImportError:
    HAS_OTEL_SDK = False

from opentelemetry import trace, metrics
from opentelemetry.propagate import set_global_textmap
from opentelemetry.propagators.composite import CompositePropagator
from opentelemetry.baggage.propagation import W3CBaggagePropagator
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor

from guardianhub.config.settings import settings
from guardianhub import get_logger
from guardianhub import DEFAULT_SYSTEM_TENANT_ID

from guardianhub.observability.otel_middlewares import SovereignContextProcessor
from guardianhub.observability.span_filters import InfrastructureTraceFilter
from guardianhub.observability.filtering_exporter import FilteringSpanExporter

from opentelemetry import baggage as otel_baggage, context as otel_context

logger = get_logger(__name__)


def _fastapi_request_hook(span, scope: dict[str, Any]) -> None:
    if not span or not scope:
        return

    # 1. Unified Physical Extraction
    headers = {k.decode("utf-8").lower(): v.decode("utf-8") for k, v in scope.get("headers", [])}

    user_id = headers.get("x-user-email") or headers.get("x-user-id") or headers.get("userid")
    tenant_id = headers.get("x-tenant-id")
    session_id = headers.get("x-conversation-id") or headers.get("x-session-id")

    # 2. Permanent Span Tagging (Langfuse & OTel)
    if user_id:
        span.set_attribute("langfuse.user.id", str(user_id))
        span.set_attribute("ctx.user_id", str(user_id))
    if session_id:
        span.set_attribute("langfuse.session.id", str(session_id))
        span.set_attribute("ctx.session_id", str(session_id))
    if tenant_id:
        span.set_attribute("langfuse.trace.metadata.tenant", str(tenant_id))
        span.set_attribute("ctx.tenant_id", str(tenant_id))

    # 3. 🧠 Spirit World Seeding (Baggage)
    # This ensures HTTPX and Temporal calls automatically carry the identity
    ctx = otel_context.get_current()
    if user_id: ctx = otel_baggage.set_value("user_id", user_id, ctx)
    if tenant_id: ctx = otel_baggage.set_value("tenant_id", tenant_id, ctx)
    if session_id: ctx = otel_baggage.set_value("session_id", session_id, ctx)


def configure_instrumentation(
    app,
    enable_console_export: bool = False,
    excluded_urls: str = "/health,/metrics,/portrait,/ensure,/api/v1/mission-control/lineage,/query-cypher",
    httpx_excluded_urls: Union[str, Tuple[str, ...]] = "/health,/metrics,/portrait,vectordb.guardianhub.com,graphdb.guardianhub.com",
) -> None:
    # 1️⃣ Setup Global Propagation (Crucial: Works even without SDK)
    set_global_textmap(CompositePropagator([
        TraceContextTextMapPropagator(),
        W3CBaggagePropagator()
    ]))
    logger.info("Configured Global Composite Propagator (TraceContext + Baggage)")

    if not HAS_OTEL_SDK:
        logger.warning("OpenTelemetry SDK not found. Running in Propagation-Only mode.")
        return

    from guardianhub.config.vault_manager import VaultManager
    import asyncio

    # We use a sync-wrapper or run_until_complete if this is at entry point
    try:
        vault = VaultManager()
        loop = asyncio.get_event_loop()
        # Fetch from your existing path: yantramops/tenants/system/observability/langfuse
        if loop.is_running():
            # If the loop is already humming, we use a Task or a future bridge
            # For instrumentation boot, we usually want to block until we have the key
            import nest_asyncio
            nest_asyncio.apply()
            system_secrets = asyncio.run(vault.fetch_tenant_secrets(DEFAULT_SYSTEM_TENANT_ID))
        else:
            system_secrets = asyncio.run(vault.fetch_tenant_secrets(DEFAULT_SYSTEM_TENANT_ID))

        if system_secrets:
            vault.populate_session_tenant(system_secrets)
            logger.info("🛡️ System-level observability identity anchored successfully.")
    except Exception as e:
        logger.error(f"❌ Failed to anchor System identity: {e}")

    # Now, when we pull 'pk' and 'sk' below, they are valid 'system' keys
    pk = getattr(settings.credentials, "LANGFUSE_PUBLIC_KEY", os.getenv("LANGFUSE_PUBLIC_KEY"))
    sk = getattr(settings.credentials, "LANGFUSE_SECRET_KEY", os.getenv("LANGFUSE_SECRET_KEY"))
    host = getattr(settings.endpoints, "LANGFUSE_HOST", os.getenv("LANGFUSE_HOST"))
    otlp_endpoint = getattr(settings.endpoints, "LANGFUSE_HOST", os.getenv("LANGFUSE_HOST"))

    # 2️⃣ Setup Resource and Tracer Provider
    logger.info('***********************JAYANT***********************')
    logger.info(
        f"Setting up OpenTelemetry tracer provider: service_name={settings.service.name}, "
        f"otlp_endpoint={host}"
        f"LANGFUSE_SECRET_KEY={pk}"
        f"LANGFUSE_PUBLIC_KEY={sk}"
    )
    logger.info('***********************JAYANT***********************')

    
    resource = Resource.create({
        "service.name": settings.service.name,
        "deployment.environment": settings.endpoints.ENVIRONMENT,
        "service.version": settings.service.version,
    })

    logger.info(
        f"Created OpenTelemetry resource: service_name={settings.service.name}, "
        f"environment={settings.endpoints.ENVIRONMENT}, version={settings.service.version}"
    )

    tracer_provider = TracerProvider(resource=resource)

    # 3️⃣ Register Sovereign Processor (The Tenant Mapping)
    tracer_provider.add_span_processor(SovereignContextProcessor())
    logger.debug("Registered SovereignContextProcessor for tenant-aware tracing")

    # 3️⃣.5 Register Infrastructure Filter (Suppress noisy health/ensure spans)
    tracer_provider.add_span_processor(InfrastructureTraceFilter())
    logger.debug("Registered InfrastructureTraceFilter to suppress noisy spans")

    # 4️⃣ Configure OTLP Trace Exporter WITH Resilient Timeout
    if otlp_endpoint:
        logger.debug(f"Configuring OTLP trace exporter: endpoint={otlp_endpoint}")
        
        # Use getattr to avoid the AttributeError if Pydantic hasn't mapped them to the root
        # pk = getattr(settings.credentials, "LANGFUSE_PUBLIC_KEY", os.getenv("LANGFUSE_PUBLIC_KEY"))
        # sk = getattr(settings.credentials, "LANGFUSE_SECRET_KEY", os.getenv("LANGFUSE_SECRET_KEY"))

        logger.debug(
            f"Retrieved Langfuse credentials: has_public_key={bool(pk)}, "
            f"has_secret_key={bool(sk)}, public_key_prefix={pk[:10] + '...' if pk else None}"
        )

        if not pk or not sk:
            logger.error(
                f"❌ OTLP Auth failed: Keys not found in settings or environment. "
                f"has_public_key={bool(pk)}, has_secret_key={bool(sk)}, "
                f"LANGFUSE_PUBLIC_KEY_env={bool(os.getenv('LANGFUSE_PUBLIC_KEY'))}, "
                f"LANGFUSE_SECRET_KEY_env={bool(os.getenv('LANGFUSE_SECRET_KEY'))}"
            )
            return

        # 1. Prepare Headers
        auth_str = f"{pk}:{sk}"
        encoded_auth = base64.b64encode(auth_str.encode()).decode()

        project_id = getattr(settings.credentials, "LANGFUSE_PROJECT_ID", os.getenv("LANGFUSE_PROJECT_ID"))
        logger.debug(
            f"Prepared authentication headers: has_project_id={bool(project_id)}, "
            f"project_id={project_id[:10] + '...' if project_id else None}"
        )

        # 2. Use the BASE bridge URL (The SDK will append /v1/traces)
        # If your SDK version DOES NOT append it, use the full path.
        # But usually, providing the base /otel/ path is safer.
        base_otel_endpoint = f"{settings.endpoints.LANGFUSE_HOST}/api/public/otel/v1/traces"
        logger.debug(
            f"Constructed OTLP endpoint: base_endpoint={base_otel_endpoint}, "
            f"langfuse_host={settings.endpoints.LANGFUSE_HOST}"
        )

        trace_exporter = OTLPSpanExporter(
            endpoint=base_otel_endpoint,
            headers={
                "Authorization": f"Basic {encoded_auth}",
                "x-langfuse-project-id": project_id  # <--- CRITICAL ADDITION
            },
            timeout=10  # Give it time to breathe
        )

        logger.debug(
            f"Created OTLP span exporter: endpoint={base_otel_endpoint}, "
            f"timeout=10, has_auth=True, has_project_id={bool(project_id)}"
        )

        # Use BatchSpanProcessor with filtering wrapper
        filtering_exporter = FilteringSpanExporter(trace_exporter)
        tracer_provider.add_span_processor(BatchSpanProcessor(filtering_exporter))
        logger.info(
            f"Traces exported to: {otlp_endpoint}/api/public/otel (Auth Enabled), "
            f"endpoint={otlp_endpoint}/api/public/otel, exporter_type=BatchSpanProcessor, auth_enabled=True"
        )
    else:
        logger.warning(
            f"No OTLP endpoint configured - traces will not be exported, "
            f"langfuse_host={settings.endpoints.get('LANGFUSE_HOST')}"
        )

    trace.set_tracer_provider(tracer_provider)

    # 5️⃣ Instrument FastAPI & HTTPX
    FastAPIInstrumentor.instrument_app(
        app=app,
        tracer_provider=tracer_provider,
        excluded_urls=excluded_urls,
        server_request_hook=_fastapi_request_hook,
        http_capture_headers_server_request=["user-agent", "content-type", "x-tenant-id","x-user-email"],
        http_capture_headers_server_response=["content-type"]
    )

    excluded_urls_param = ",".join(httpx_excluded_urls) if isinstance(httpx_excluded_urls, tuple) else httpx_excluded_urls
    HTTPXClientInstrumentor().instrument(
        excluded_urls=excluded_urls_param,
        tracer_provider=tracer_provider
    )

    logger.info("Instrumentation complete: Tenant-Aware and Langfuse-Ready.")