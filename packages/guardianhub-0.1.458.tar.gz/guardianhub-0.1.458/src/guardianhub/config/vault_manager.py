import httpx
import hvac
from typing import Any, Dict
import json
from pathlib import Path


from guardianhub import get_logger
from guardianhub.clients.langfuse.manager import LangfuseManager
from guardianhub.config.settings import CoreSettings
from guardianhub.config.settings import settings
from guardianhub import DEFAULT_SYSTEM_TENANT_ID



logger = get_logger(__name__)


def mask_secrets(data: dict) -> dict:
    """Mask sensitive values for logging. Shows full keys, masks values."""
    if not data:
        return {}
    return {key: "***MASKED***" for key in data.keys()}


class VaultManager:
    def __init__(self):
        self.client = httpx.Client(
            base_url=settings.endpoints.VAULT_MANAGER_URL,
            timeout=120.0
        )
        # Get the directory where vault_manager.py is located
        current_dir = Path(__file__).parent.resolve()

        # Build the absolute path to the manifest file
        # This points to: .../guardianhub/config/manifests/Infrastructure_keys_manifest.json
        self.manifest_path = current_dir / "manifests" / "Infrastructure_keys_manifest.json"

        # Optional: Safety check to ensure the file exists at startup
        if not self.manifest_path.exists():
            logger.error(f"❌ Infrastructure manifest not found at: {self.manifest_path}")

    async def fetch_tenant_secrets(self, tenant_id: str) -> Dict[str, Dict[str, Any]]:
        """
        Fetches secrets from Vault mapped by service name as defined in the manifest.
        Prevents key collisions (e.g., DB_HOST) by nesting them under service keys.
        """
        try:
            vault_url = settings.vault.url
            vault_token = settings.vault.token

            if not vault_token:
                logger.warning("⚠️ No Vault token found")
                return {}

            client = hvac.Client(url=vault_url, token=vault_token)

            # Load the manifest structure
            with open(self.manifest_path, 'r') as f:
                manifest = json.load(f)

            structured_secrets = {}
            namespace = "yantramops/tenants"

            # Iterate through the manifest blocks (yantram, core, llm, etc.)
            for category_block in manifest:
                for category, services in category_block.items():
                    for service_config in services:
                        service_name = service_config["service"]
                        # Remove leading slash and construct path
                        vault_sub_path = service_config["vault_path"].lstrip('/')

                        tenant_path = f"{namespace}/{tenant_id}/{vault_sub_path}"
                        system_path = f"{namespace}/system/{vault_sub_path}"

                        # Attempt to read from Tenant path, fallback to System path
                        service_data = self._read_vault_with_fallback(client, tenant_path, system_path)

                        if service_data:
                            # Filter data based on required_keys in manifest to ensure clean response
                            required_keys = service_config.get("required_keys", [])
                            filtered_data = {
                                k: service_data[k] for k in required_keys
                                if k in service_data and service_data[k] not in ["default_value", "placeholder", ""]
                            }

                            if filtered_data:
                                structured_secrets[service_name] = filtered_data
                                logger.info(f"✅ Loaded {len(filtered_data)} keys for service: {service_name}")

            return structured_secrets

        except Exception as e:
            logger.error(f"❌ Failed to fetch structured tenant secrets: {e}")
            return {}

    def _read_vault_with_fallback(self, client, tenant_path: str, system_path: str):
        """Helper to try tenant path then system path"""
        try:
            res = client.secrets.kv.v2.read_secret_version(path=tenant_path)
            return res['data']['data']
        except Exception:
            try:
                res = client.secrets.kv.v2.read_secret_version(path=system_path)
                return res['data']['data']
            except Exception:
                return None

    def populate_session_tenant(self, structured_secrets: dict):
        """
        Injects structured secrets into settings by service identity.
        """
        if not structured_secrets:
            logger.warning("[VaultManager] No secrets to populate.")
            return

        try:
            # Logic to sync service-specific URLs
            for service_block in ["yantram_core", "yantram_agents", "yantram_external"]:
                if service_block in structured_secrets:
                    for key, value in structured_secrets[service_block].items():
                        # Only update if the endpoint is defined in our Settings
                        if hasattr(settings.endpoints, key):
                            setattr(settings.endpoints, key, value)
                            logger.debug(f"Updated endpoint {key} from {service_block}")

            # 1. CORE DATABASE MAPPING
            # Mapping Postgres to the unified POSTGRES_URL
            if "postgres_cred" in structured_secrets:
                pg = structured_secrets["postgres_cred"]
                pg_url = (
                    f"postgresql+asyncpg://{pg.get('DB_USERNAME')}:"
                    f"{pg.get('DB_PASSWORD')}@"
                    f"{pg.get('DB_HOST')}:{pg.get('DB_PORT')}/"
                    f"{pg.get('MASTER_TENANT_DB')}"
                )
                settings.endpoints.POSTGRES_URL = pg_url
                logger.info("✅ Postgres URL reconstructed and updated.")

            # Mapping Neo4j (using its specific service block host/URL)
            if "neo4j" in structured_secrets:
                neo = structured_secrets["neo4j"]
                settings.endpoints.GRAPH_DB_URL = neo.get("GRAPH_DB_URL") or neo.get("DB_HOST")
                logger.info("✅ Neo4j Endpoint updated from neo4j service block.")

            # 2. VECTOR (ChromaDB) MAPPING
            if "chromadb" in structured_secrets:
                chroma = structured_secrets["chromadb"]
                settings.endpoints.VECTOR_SERVICE_URL = chroma.get("VECTOR_SERVICE_URL")

                for key, value in chroma.items():
                    attr_name = key.lower()
                    if hasattr(settings.vector, attr_name):
                        # FIX: Handle string-to-list conversion for collections
                        if attr_name == "additional_collections" and isinstance(value, str):
                            try:
                                # Try parsing as JSON list first
                                parsed_value = json.loads(value)
                                if isinstance(parsed_value, list):
                                    value = parsed_value
                                else:
                                    # Fallback: comma separated string
                                    value = [v.strip() for v in value.split(",")]
                            except json.JSONDecodeError:
                                # Fallback: comma separated string
                                value = [v.strip() for v in value.split(",")]

                        setattr(settings.vector, attr_name, value)

            # 3. OBSERVABILITY (Langfuse)
            if "langfuse" in structured_secrets:
                lf = structured_secrets["langfuse"]
                settings.endpoints.LANGFUSE_HOST = lf.get("LANGFUSE_HOST")
                # Populate credentials for SDK access
                settings.credentials.LANGFUSE_PUBLIC_KEY = lf.get("LANGFUSE_PUBLIC_KEY")
                settings.credentials.LANGFUSE_SECRET_KEY = lf.get("LANGFUSE_SECRET_KEY")
                settings.credentials.LANGFUSE_PROJECT_ID = lf.get("LANGFUSE_PROJECT_ID")

            # 4. LLM CONFIGURATION (Dynamic Registry)
            # Check for common LLM service names in the response
            for provider in ["aura", "openai", "gemini", "deepseek"]:
                if provider in structured_secrets:
                    llm_data = structured_secrets[provider]
                    # Update the LLM model_configs dict in settings
                    config = {
                        "model_name": llm_data.get("LLM_MODEL_NAME"),
                        "api_key": llm_data.get("LLM_API_KEY"),
                        "base_url": llm_data.get("LLM_BASE_URL") or llm_data.get("LLM_URL"),
                        "provider": provider.upper()
                    }
                    # Use standard Pydantic update if available, or manual dict update
                    settings.llm.model_configs[provider] = config

            # 5. LEGACY FLAT ACCESS (Optional)
            # If any part of the app still expects GH_CREDENTIALS.DB_HOST,
            # we can flatten everything into the credentials object as a fallback.
            for service, keys in structured_secrets.items():
                for key, value in keys.items():
                    setattr(settings.credentials, key.upper(), value)

            # --- FINALIZATION ---
            # Reset managers to pick up new configurations
            LangfuseManager.reset()

            # Build a summary of updated endpoints for verification
            # We filter for uppercase keys (standard for endpoints) or all public attributes
            current_endpoints = {
                k: v for k, v in settings.endpoints.__dict__.items()
                if not k.startswith("_")
            }

            logger.info("📡 [Final Endpoint Configuration]")
            for endpoint, url in current_endpoints.items():
                logger.info(f"   🔗 {endpoint:<30} -> {url}")

            logger.info(f"🚀 Tenant session hydration complete for service blocks: {list(structured_secrets.keys())}")
            logger.info(f"🚀 Tenant session hydration complete for service blocks: {list(structured_secrets.keys())}")

        except Exception as e:
            logger.error(f"❌ Failed to update settings from structured secrets: {e}", exc_info=True)