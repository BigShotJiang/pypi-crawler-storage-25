# Changelog

All notable changes to `mgf-alembic` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
the project follows [SemVer](https://semver.org/spec/v2.0.0.html). Per
the 0.x window ([SemVer 0.x](https://semver.org/#spec-item-4) and rule
**AP-03** from `mgf-common/docs/standards/API_DESIGN.md`), MINOR
releases MAY break the public API. Pin tightly:

```toml
mgf-alembic = ">=0.X.0,<0.Y"   # one minor at a time
```

The release-engineering discipline that produces this changelog is in
[`mgf-common/docs/standards/RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md).

---

## [Unreleased]

Nothing yet.

---

## [0.1.1] — 2026-05-11

PyPI: <https://pypi.org/project/mgf-alembic/0.1.1/> · Tag: `v0.1.1`

> **Pin-walk patch release — no source change.** Walks the
> `mgf-common` pin forward to `>=0.33,<0.34`, the AP-12
> deprecation-removal release. `mgf-alembic` source is clean of the
> three removed names (`mgf.common.configure`,
> `mgf.common.config.make_settings_config`,
> `mgf.common.exceptions.EnvironmentError`), so no code change is
> needed — only the dependency declaration moves.

### Changed

- **Dependency pin** — `mgf-common>=0.30,<0.31` → `mgf-common>=0.33,<0.34`.
  Lets consumers install `mgf-alembic` alongside the current
  `mgf-common` line.

---

## [0.1.0] — 2026-05-10

PyPI: <https://pypi.org/project/mgf-alembic/0.1.0/> · Tag: `v0.1.0`

> **Maiden voyage** — extracted from `mgf-common` v0.29.0 per the
> federation split plan ([mgf-common/docs/release/federation_roadmap.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/release/federation_roadmap.md)).
> Paired ship with mgf-sqlalchemy v0.1.0 (this sibling depends on it).
> Cutover guide: [`docs/cutover/v0.1.0.md`](docs/cutover/v0.1.0.md).

### Added

- **`mgf.alembic.configure_env`** — one call replaces the ~40-line
  `env.py` boilerplate every async-SQLAlchemy + alembic project
  ships. Detects sync vs async drivers from the URL prefix
  (`postgresql+asyncpg://`, `postgresql+psycopg://`,
  `mysql+aiomysql://`, `mysql+asyncmy://`, `sqlite+aiosqlite://`)
  and runs the migration via `asyncio.run` for async URLs;
  falls through to the sync path otherwise. Plumbs
  `compare_type`, `compare_server_default`, `naming_convention`,
  `include_object`, `include_schemas` through to
  `alembic.context.configure` (PAPER-22 — `include_object` /
  `include_schemas` were added in mgf-common v0.19; carried over
  byte-identical).

### Engineering

- 11 tests carried over from `mgf-common/tests/unit/alembic/test_env.py`
  — every pre-extraction failure mode stays green at parity. Coverage
  threshold ≥80% (matches mgf-common's standard).
- Imports rewrite from `mgf.common.alembic.*` to `mgf.alembic.*`.
  No private-import leaks; the sibling reaches into mgf-common only
  through public names.
- `mgf-common>=0.30,<0.31` + `mgf-sqlalchemy>=0.1,<0.2` runtime
  dependencies. AP-03 0.x window pin discipline applies — bump in
  lock-step with mgf-common's next minor.
- PEP 420 namespace package (no top-level `mgf/__init__.py`); the
  wheel ships `src/mgf/` as-is so `mgf.alembic`, `mgf.sqlalchemy`,
  `mgf.fastapi`, `mgf.http`, and `mgf.common` coexist as siblings.
