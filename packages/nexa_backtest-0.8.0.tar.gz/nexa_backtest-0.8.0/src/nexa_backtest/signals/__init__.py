"""Signal providers and registry."""
