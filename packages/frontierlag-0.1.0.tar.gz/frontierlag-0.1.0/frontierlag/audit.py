"""
Audit logic — compute a frontier-lag report from paper metadata.

The audit takes an already-parsed :class:`PaperMetadata` (caller's
responsibility to populate it) and computes the three audit dimensions
from the paper's own structural report:

    Capability dimension   — how far the tested model sits from the
                             frontier at evaluation date (ECI points and
                             calendar months).
    Tier dimension         — whether a stronger same-family sibling was
                             already shipping at evaluation date.
    Configuration dimension — whether the paper discloses the reasoning
                             mode, tools, scaffolding, and sampling
                             configuration that determine how much of
                             the underlying capability was elicited.

The report does NOT compute counterfactual capability. That was the single
most attacked move in the companion paper's methods debate; the package
mirrors the paper's stance that configuration disclosure is descriptive,
not a capability adjustment.

The ``audit`` function is deterministic and performs no I/O.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import date, datetime
from typing import Any, Iterable

from frontierlag._version import FREEZE_DATE
from frontierlag.lookup import (
    FrontierSnapshot,
    ModelRecord,
    get_frontier_at_date,
    lookup_model,
)


# ---------------------------------------------------------------------------
# Input and output types
# ---------------------------------------------------------------------------


@dataclass
class PaperMetadata:
    """Metadata a caller must supply to :func:`audit`.

    ``evaluation_date`` is the date of model access reported by the paper; if
    absent, callers should use the paper's publication date and set
    ``evaluation_date_inferred`` so the report can flag the substitution.

    ``configuration_disclosures`` is a dict whose keys match the VERSIO-AI v1
    configuration items (see ``versio_ai`` in the companion repository). A
    value of True means "paper explicitly reports this"; False means "paper
    is silent"; None means "not applicable to this model" (e.g. reasoning
    mode for GPT-4o, which has none).
    """

    title: str | None = None
    doi: str | None = None
    publication_date: date | None = None
    evaluation_date: date | None = None
    evaluation_date_inferred: bool = False
    primary_model: str | None = None
    all_models: list[str] = field(default_factory=list)
    configuration_disclosures: dict[str, bool | None] = field(default_factory=dict)
    human_comparator_present: bool | None = None
    conclusion_valence: str | None = None  # positive | neutral | mixed | negative

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "PaperMetadata":
        def _as_date(v: Any) -> date | None:
            if v is None or v == "":
                return None
            if isinstance(v, date):
                return v
            return datetime.strptime(str(v), "%Y-%m-%d").date()

        return cls(
            title=d.get("title"),
            doi=d.get("doi"),
            publication_date=_as_date(d.get("publication_date")),
            evaluation_date=_as_date(d.get("evaluation_date")),
            evaluation_date_inferred=bool(d.get("evaluation_date_inferred", False)),
            primary_model=d.get("primary_model"),
            all_models=list(d.get("all_models") or []),
            configuration_disclosures=dict(d.get("configuration_disclosures") or {}),
            human_comparator_present=d.get("human_comparator_present"),
            conclusion_valence=d.get("conclusion_valence"),
        )


@dataclass
class AuditReport:
    """Output of :func:`audit`.

    Everything is JSON-serialisable. ``to_dict`` / ``to_json`` emit the same
    structure the CLI prints and the static site embeds.
    """

    paper_title: str | None
    paper_doi: str | None
    evaluation_date: str | None
    evaluation_date_inferred: bool
    primary_model_input: str | None
    primary_model_canonical: str | None
    primary_model_release_date: str | None
    primary_model_eci: float | None
    frontier_model_at_date: str | None
    frontier_eci_at_date: float | None
    frontier_release_date_at_date: str | None
    capability_gap_eci: float | None
    capability_gap_months: int | None
    tier_gap_siblings: int | None
    tier_gap_sibling_names: list[str]
    configuration_disclosure_rate: float | None
    configuration_disclosure_missing: list[str]
    compound_failure: bool | None
    notes: list[str]
    thresholds: dict[str, float]
    data_freeze_date: str = FREEZE_DATE

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True)

    def to_text(self) -> str:
        """Human-readable rendering used by the CLI."""
        lines: list[str] = []
        lines.append(f"frontierlag audit (data freeze: {self.data_freeze_date})")
        lines.append("=" * 72)
        if self.paper_title:
            lines.append(f"Paper:  {self.paper_title}")
        if self.paper_doi:
            lines.append(f"DOI:    {self.paper_doi}")
        eval_str = self.evaluation_date or "unknown"
        if self.evaluation_date_inferred:
            eval_str += "  (inferred from publication date — paper did not report access date)"
        lines.append(f"Evaluation date: {eval_str}")
        lines.append("")
        lines.append("Primary model tested")
        if self.primary_model_canonical:
            lines.append(
                f"  input  : {self.primary_model_input!r} "
                f"→ canonical: {self.primary_model_canonical}"
            )
            lines.append(
                f"  release: {self.primary_model_release_date or '—'}     "
                f"ECI: {_fmt_eci(self.primary_model_eci)}"
            )
        else:
            lines.append(
                f"  input  : {self.primary_model_input!r} "
                "(not recognised — extend config.yaml to add an alias)"
            )
        lines.append("")
        lines.append("Frontier at evaluation date")
        if self.frontier_model_at_date:
            lines.append(
                f"  {self.frontier_model_at_date} "
                f"(released {self.frontier_release_date_at_date}, "
                f"ECI {_fmt_eci(self.frontier_eci_at_date)})"
            )
        else:
            lines.append("  —  evaluation date precedes recorded trajectory")
        lines.append("")
        lines.append("Audit dimensions")
        lines.append(
            f"  Capability gap : "
            f"{_fmt_eci(self.capability_gap_eci)} ECI pts   "
            f"{_fmt_months(self.capability_gap_months)}"
        )
        lines.append(
            f"  Tier gap       : "
            f"{self.tier_gap_siblings if self.tier_gap_siblings is not None else '—'} "
            f"stronger same-family sibling(s) available"
        )
        if self.tier_gap_sibling_names:
            lines.append(f"                   e.g. {', '.join(self.tier_gap_sibling_names[:3])}")
        disclosure = (
            f"{self.configuration_disclosure_rate * 100:.0f}%"
            if self.configuration_disclosure_rate is not None
            else "—"
        )
        lines.append(f"  Configuration  : {disclosure} of applicable items disclosed")
        if self.configuration_disclosure_missing:
            lines.append(
                f"                   undisclosed: {', '.join(self.configuration_disclosure_missing)}"
            )
        lines.append("")
        if self.compound_failure is True:
            lines.append("Compound failure: YES — fails all three dimensions at pre-registered thresholds.")
        elif self.compound_failure is False:
            lines.append("Compound failure: no")
        else:
            lines.append("Compound failure: undetermined (insufficient structured metadata).")
        if self.notes:
            lines.append("")
            lines.append("Notes")
            for n in self.notes:
                lines.append(f"  - {n}")
        lines.append("")
        lines.append(
            "This report uses the Epoch AI Capabilities Index as the frontier measure. "
            "See the companion paper for construct-validity caveats."
        )
        return "\n".join(lines)


def _fmt_eci(v: float | None) -> str:
    return f"{v:+.1f}" if v is not None else "—"


def _fmt_months(v: int | None) -> str:
    if v is None:
        return "(months: —)"
    return f"({v:+d} months)"


# ---------------------------------------------------------------------------
# Audit logic
# ---------------------------------------------------------------------------


# Configuration items we check disclosure of. These mirror the VERSIO-AI
# v1.0 configuration block exactly — update both when either changes.
CONFIGURATION_ITEMS: tuple[str, ...] = (
    "model_version_exact",
    "provider_or_access_method",
    "access_date",
    "reasoning_mode",
    "reasoning_effort_or_budget",
    "tool_use",
    "scaffolding_or_agent_framework",
    "prompting_strategy",
    "sampling_parameters",
    "n_samples_or_seeds",
)


def audit(metadata: PaperMetadata | dict[str, Any], *, thresholds: dict[str, float] | None = None) -> AuditReport:
    """Compute a frontier-lag report for a paper's structured metadata.

    Parameters
    ----------
    metadata
        A :class:`PaperMetadata` or an equivalent plain dict.
    thresholds
        Optional override for the pre-registered thresholds. Keys: same as
        ``config.yaml::thresholds``. Missing keys fall through to defaults.
    """
    if isinstance(metadata, dict):
        metadata = PaperMetadata.from_dict(metadata)

    from frontierlag.lookup import _load_config  # avoid import cycle at module import

    cfg = _load_config()
    thr = dict(cfg.get("thresholds", {}))
    if thresholds:
        thr.update(thresholds)

    notes: list[str] = []

    # ------- Resolve primary model -------
    primary_record: ModelRecord | None = None
    if metadata.primary_model:
        primary_record = lookup_model(metadata.primary_model)
        if not primary_record.known:
            notes.append(
                f"Primary model {metadata.primary_model!r} did not match any known alias. "
                "Extend config.yaml or submit a PR to add it."
            )

    # ------- Evaluation date -------
    eval_date = metadata.evaluation_date or metadata.publication_date
    if eval_date is None:
        notes.append("No evaluation or publication date available — gap measures will be null.")
    elif metadata.evaluation_date is None and metadata.publication_date is not None:
        notes.append(
            "Evaluation date absent; publication date used as substitute. This biases the gap "
            "downward (the model was actually accessed earlier than publication)."
        )

    # ------- Frontier at evaluation date -------
    snapshot: FrontierSnapshot | None = None
    if eval_date is not None:
        snapshot = get_frontier_at_date(eval_date)

    # ------- Capability gap -------
    gap_eci: float | None = None
    gap_months: int | None = None
    if snapshot and primary_record and primary_record.known and primary_record.eci_score is not None:
        gap_eci = snapshot.frontier_eci - primary_record.eci_score
    if snapshot and primary_record and primary_record.known and primary_record.release_date is not None:
        # Months between model release and frontier release at eval date.
        delta_days = (snapshot.frontier_release_date - primary_record.release_date).days
        gap_months = int(round(delta_days / 30.4375))

    # ------- Tier gap -------
    tier_siblings, tier_sibling_names = _tier_gap(
        primary_record=primary_record,
        eval_date=eval_date,
    )

    # ------- Configuration disclosure -------
    disc_rate, disc_missing = _config_disclosure(metadata.configuration_disclosures)

    # ------- Compound failure -------
    compound = _compound_failure(
        gap_eci=gap_eci,
        gap_months=gap_months,
        tier_siblings=tier_siblings,
        disc_rate=disc_rate,
        thresholds=thr,
    )

    return AuditReport(
        paper_title=metadata.title,
        paper_doi=metadata.doi,
        evaluation_date=eval_date.isoformat() if eval_date else None,
        evaluation_date_inferred=bool(metadata.evaluation_date is None and metadata.publication_date is not None),
        primary_model_input=metadata.primary_model,
        primary_model_canonical=primary_record.canonical if primary_record and primary_record.known else None,
        primary_model_release_date=(
            primary_record.release_date.isoformat()
            if primary_record and primary_record.release_date
            else None
        ),
        primary_model_eci=primary_record.eci_score if primary_record and primary_record.known else None,
        frontier_model_at_date=snapshot.frontier_model if snapshot else None,
        frontier_eci_at_date=snapshot.frontier_eci if snapshot else None,
        frontier_release_date_at_date=(
            snapshot.frontier_release_date.isoformat() if snapshot else None
        ),
        capability_gap_eci=gap_eci,
        capability_gap_months=gap_months,
        tier_gap_siblings=tier_siblings,
        tier_gap_sibling_names=list(tier_sibling_names),
        configuration_disclosure_rate=disc_rate,
        configuration_disclosure_missing=list(disc_missing),
        compound_failure=compound,
        notes=notes,
        thresholds={
            "capability_gap_eci_points": float(thr.get("capability_gap_eci_points", 10.0)),
            "capability_gap_months": float(thr.get("capability_gap_months", 12)),
            "configuration_disclosure_min": float(thr.get("configuration_disclosure_min", 0.5)),
            "tier_gap_siblings_min": float(thr.get("tier_gap_siblings_min", 1)),
        },
    )


# ---------------------------------------------------------------------------
# Dimension helpers
# ---------------------------------------------------------------------------


def _tier_gap(
    *,
    primary_record: ModelRecord | None,
    eval_date: date | None,
) -> tuple[int | None, list[str]]:
    """Count same-family siblings with higher ECI available at ``eval_date``.

    Returns ``(count, list_of_sibling_names)`` where count is None if the
    primary record is unknown or the ECI is unknown.
    """
    if primary_record is None or not primary_record.known or primary_record.eci_score is None:
        return None, []
    if eval_date is None:
        return None, []

    from frontierlag.lookup import _load_model_lookup

    lookup = _load_model_lookup()
    family = _family_of(primary_record.canonical or "", primary_record.org)
    siblings: list[tuple[str, float]] = []
    for name, entry in lookup.items():
        if name == primary_record.canonical:
            continue
        sib_family = _family_of(name, entry.get("org"))
        if sib_family != family:
            continue
        eci = entry.get("eci_score")
        if eci is None:
            continue
        rel = entry.get("release_date")
        if not rel:
            continue
        try:
            rel_date = datetime.strptime(rel, "%Y-%m-%d").date()
        except ValueError:
            continue
        if rel_date > eval_date:
            continue
        if float(eci) > float(primary_record.eci_score):
            siblings.append((name, float(eci)))

    siblings.sort(key=lambda t: t[1], reverse=True)
    return len(siblings), [n for n, _ in siblings]


def _family_of(canonical: str, org: str | None) -> str:
    """Map a canonical model name to its family string.

    We use coarse families — fine enough to distinguish GPT vs Claude vs
    Gemini, coarse enough that intra-family tier comparisons (GPT-4o vs
    GPT-4o-mini) are meaningful. Update alongside config aliases.
    """
    c = canonical.lower()
    if c.startswith("gpt") or c.startswith("o1") or c.startswith("o3") or c.startswith("o4"):
        return "openai"
    if c.startswith("claude"):
        return "anthropic"
    if c.startswith("gemini"):
        return "google-gemini"
    if c.startswith("grok"):
        return "xai"
    if c.startswith("llama"):
        return "meta-llama"
    if c.startswith("mistral") or c.startswith("mixtral"):
        return "mistral"
    if c.startswith("deepseek"):
        return "deepseek"
    if c.startswith("qwen"):
        return "qwen"
    return (org or "other").lower()


def _config_disclosure(
    disclosures: dict[str, bool | None],
) -> tuple[float | None, list[str]]:
    """Compute disclosure rate over applicable configuration items.

    ``None`` values mark items that do not apply (e.g. reasoning mode for a
    model without a reasoning mode); those items are excluded from both
    numerator and denominator.
    """
    if not disclosures:
        return None, list(CONFIGURATION_ITEMS)

    applicable = [k for k in CONFIGURATION_ITEMS if disclosures.get(k) is not None]
    if not applicable:
        return None, list(CONFIGURATION_ITEMS)

    disclosed = [k for k in applicable if bool(disclosures.get(k))]
    missing = [k for k in applicable if not bool(disclosures.get(k))]
    return len(disclosed) / len(applicable), missing


def _compound_failure(
    *,
    gap_eci: float | None,
    gap_months: int | None,
    tier_siblings: int | None,
    disc_rate: float | None,
    thresholds: dict[str, float],
) -> bool | None:
    """Fails all three dimensions at pre-registered thresholds.

    Returns None if any dimension is missing data (we do not want to call a
    paper a "pass" when we simply couldn't measure it).
    """
    cap_pts = thresholds.get("capability_gap_eci_points", 10.0)
    cap_mo = thresholds.get("capability_gap_months", 12)
    tier_min = thresholds.get("tier_gap_siblings_min", 1)
    disc_min = thresholds.get("configuration_disclosure_min", 0.5)

    cap_fail: bool | None
    if gap_eci is None and gap_months is None:
        cap_fail = None
    else:
        cap_fail = (gap_eci is not None and gap_eci >= cap_pts) or (
            gap_months is not None and gap_months >= cap_mo
        )

    tier_fail = None if tier_siblings is None else tier_siblings >= tier_min
    disc_fail = None if disc_rate is None else disc_rate < disc_min

    if any(v is None for v in (cap_fail, tier_fail, disc_fail)):
        return None
    return bool(cap_fail and tier_fail and disc_fail)


__all__ = [
    "PaperMetadata",
    "AuditReport",
    "audit",
    "CONFIGURATION_ITEMS",
]


def iter_dimensions(report: AuditReport) -> Iterable[tuple[str, Any]]:
    """Iterate over the three dimensions as (name, value) pairs."""
    yield "capability_gap_eci", report.capability_gap_eci
    yield "capability_gap_months", report.capability_gap_months
    yield "tier_gap_siblings", report.tier_gap_siblings
    yield "configuration_disclosure_rate", report.configuration_disclosure_rate
