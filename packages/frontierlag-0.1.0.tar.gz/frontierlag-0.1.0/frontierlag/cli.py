"""
Command-line entry point.

Invocations:

    frontierlag check <DOI> [options]
    frontierlag lookup <MODEL>
    frontierlag frontier <YYYY-MM-DD>
    frontierlag info

All commands accept ``--json`` for machine-readable output.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime

from frontierlag._version import FREEZE_DATE, __version__
from frontierlag.audit import AuditReport
from frontierlag.lookup import (
    get_frontier_at_date,
    list_known_models,
    lookup_model,
)
from frontierlag.resolver import ResolverError, check as resolve_and_audit


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="frontierlag",
        description=(
            "Audit the capability gap between frontier AI and a paper's evaluation. "
            "See https://arxiv.org/abs/TBD for the companion paper."
        ),
    )
    parser.add_argument(
        "--version", action="version", version=f"frontierlag {__version__} (data freeze {FREEZE_DATE})"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # ---- check ----
    p_check = sub.add_parser("check", help="Audit a paper by DOI.")
    p_check.add_argument("doi", help="DOI string (bare or https://doi.org/… form).")
    p_check.add_argument(
        "--model",
        dest="primary_model",
        help="Override the primary model (e.g. 'GPT-4').",
    )
    p_check.add_argument(
        "--eval-date",
        dest="evaluation_date",
        help="Evaluation date (YYYY-MM-DD) if the paper reports one.",
    )
    p_check.add_argument(
        "--config-file",
        dest="config_file",
        help=(
            "Optional JSON file whose top-level object is a "
            "configuration_disclosures dict (keys = VERSIO-AI item names, "
            "values = true/false/null)."
        ),
    )
    p_check.add_argument("--json", action="store_true", help="Emit JSON instead of text.")

    # ---- lookup ----
    p_lookup = sub.add_parser("lookup", help="Look up a single model's metadata.")
    p_lookup.add_argument("model", help="Model name (alias or canonical).")
    p_lookup.add_argument("--json", action="store_true", help="Emit JSON instead of text.")

    # ---- frontier ----
    p_frontier = sub.add_parser("frontier", help="Print the frontier model at a given date.")
    p_frontier.add_argument("target_date", help="YYYY-MM-DD")
    p_frontier.add_argument("--json", action="store_true")

    # ---- info ----
    sub.add_parser("info", help="Print package version and freeze-date info.")

    # ---- models ----
    p_models = sub.add_parser("models", help="List known canonical model names.")
    p_models.add_argument("--json", action="store_true")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "check":
            return _cmd_check(args)
        if args.command == "lookup":
            return _cmd_lookup(args)
        if args.command == "frontier":
            return _cmd_frontier(args)
        if args.command == "info":
            return _cmd_info()
        if args.command == "models":
            return _cmd_models(args)
    except ResolverError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:  # surface unexpected failures as non-zero
        print(f"error: {exc}", file=sys.stderr)
        return 3

    parser.print_help()
    return 1


# ---------------------------------------------------------------------------
# Command implementations
# ---------------------------------------------------------------------------


def _cmd_check(args: argparse.Namespace) -> int:
    config_disclosures = None
    if args.config_file:
        with open(args.config_file, "r", encoding="utf-8") as f:
            config_disclosures = json.load(f)
    report: AuditReport = resolve_and_audit(
        args.doi,
        primary_model=args.primary_model,
        evaluation_date=args.evaluation_date,
        configuration_disclosures=config_disclosures,
    )
    if args.json:
        print(report.to_json())
    else:
        print(report.to_text())
    return 0


def _cmd_lookup(args: argparse.Namespace) -> int:
    record = lookup_model(args.model)
    if args.json:
        out = {
            "input_name": record.input_name,
            "canonical": record.canonical,
            "known": record.known,
            "release_date": record.release_date.isoformat() if record.release_date else None,
            "eci_score": record.eci_score,
            "org": record.org,
            "tier": record.tier,
            "has_reasoning_mode": record.has_reasoning_mode,
        }
        print(json.dumps(out, indent=2))
    else:
        print(record)
    return 0


def _cmd_frontier(args: argparse.Namespace) -> int:
    try:
        target = datetime.strptime(args.target_date, "%Y-%m-%d").date()
    except ValueError:
        print(f"error: invalid date {args.target_date!r}; use YYYY-MM-DD", file=sys.stderr)
        return 2
    snapshot = get_frontier_at_date(target)
    if snapshot is None:
        print(f"No frontier recorded on or before {target.isoformat()}.", file=sys.stderr)
        return 1
    if args.json:
        print(
            json.dumps(
                {
                    "at_date": snapshot.at_date.isoformat(),
                    "month_start": snapshot.month_start.isoformat(),
                    "frontier_model": snapshot.frontier_model,
                    "frontier_eci": snapshot.frontier_eci,
                    "frontier_release_date": snapshot.frontier_release_date.isoformat(),
                },
                indent=2,
            )
        )
    else:
        print(
            f"Frontier on {snapshot.at_date.isoformat()}: "
            f"{snapshot.frontier_model} "
            f"(released {snapshot.frontier_release_date.isoformat()}, "
            f"ECI {snapshot.frontier_eci:.2f})"
        )
    return 0


def _cmd_info() -> int:
    print(f"frontierlag {__version__}")
    print(f"data freeze: {FREEZE_DATE}")
    print("companion paper: https://arxiv.org/abs/TBD")
    print("dataset:         https://osf.io/TBD")
    return 0


def _cmd_models(args: argparse.Namespace) -> int:
    names = list_known_models()
    if args.json:
        print(json.dumps(names, indent=2))
    else:
        for n in names:
            print(n)
    return 0


if __name__ == "__main__":
    sys.exit(main())
