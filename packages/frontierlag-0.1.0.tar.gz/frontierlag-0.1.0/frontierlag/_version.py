"""Version and data-freeze metadata for frontierlag.

These constants are the single source of truth for the package's version and
for the freeze date printed in every audit report and on the static site.
When you update the frozen dataset, bump both.
"""

__version__ = "1.0.0"

# The date of the snapshot embedded in ``frontierlag/data/``. Printed at the
# top of every audit report so readers know how stale the comparison is.
FREEZE_DATE = "2026-04-01"
