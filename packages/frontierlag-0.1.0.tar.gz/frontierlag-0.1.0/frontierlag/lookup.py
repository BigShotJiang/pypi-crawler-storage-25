"""
Lookup primitives: model → ECI, date → frontier, alias → canonical.

All three lookups read from the frozen dataset shipped inside the package.
No network I/O; deterministic given (model name, date) inputs.

Design:
    * ``lookup_model`` returns a ``ModelRecord`` dataclass (never None for
      known aliases) so callers can always print something informative.
    * ``get_frontier_at_date`` returns the best-known frontier for an
      arbitrary calendar date (padded to the first of the month; the monthly
      trajectory is calendar-aligned).
    * Aliases are matched case-insensitively with common whitespace and
      punctuation collapsed; unknown aliases return a record with
      ``known=False`` and a null ECI.
"""
from __future__ import annotations

import csv
import json
import re
import unicodedata
from dataclasses import dataclass
from datetime import date, datetime
from functools import lru_cache
from importlib import resources
from pathlib import Path
from typing import Any

import yaml

# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------


def _data_path(filename: str) -> Path:
    """Resolve a packaged data file via importlib.resources."""
    ref = resources.files("frontierlag").joinpath(filename)
    # ``as_file`` returns a context-managed Path; the data files are plain
    # CSV/JSON/YAML so reading once at import time is safe.
    with resources.as_file(ref) as p:
        return Path(p)


@lru_cache(maxsize=1)
def _load_config() -> dict[str, Any]:
    path = _data_path("config.yaml")
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


@lru_cache(maxsize=1)
def _load_model_lookup() -> dict[str, dict[str, Any]]:
    path = _data_path("data/model_version_lookup.json")
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


@lru_cache(maxsize=1)
def _load_eci_scores() -> dict[str, float]:
    """Return ``{canonical_name: eci_score}`` where a score is available."""
    path = _data_path("data/eci_scores.csv")
    out: dict[str, float] = {}
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row.get("Model") or row.get("Display name")
            raw = row.get("eci")
            if not name or not raw:
                continue
            try:
                out[name] = float(raw)
            except (TypeError, ValueError):
                continue
    return out


@lru_cache(maxsize=1)
def _load_trajectory() -> list[tuple[date, str, float, date]]:
    """Return (month_start, model, eci, release_date) rows, sorted ascending."""
    path = _data_path("data/monthly_frontier_trajectory.csv")
    rows: list[tuple[date, str, float, date]] = []
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            try:
                month = datetime.strptime(r["date"], "%Y-%m-%d").date()
                release = datetime.strptime(r["frontier_release_date"], "%Y-%m-%d").date()
                eci = float(r["frontier_eci"])
            except (KeyError, ValueError):
                continue
            rows.append((month, r["frontier_model"], eci, release))
    rows.sort(key=lambda t: t[0])
    return rows


# ---------------------------------------------------------------------------
# Alias normalisation
# ---------------------------------------------------------------------------


_WHITESPACE_RE = re.compile(r"\s+")


def _normalise(name: str) -> str:
    """Lower, NFKD-fold, strip, collapse whitespace and punctuation noise."""
    s = unicodedata.normalize("NFKD", name)
    s = s.lower().strip()
    s = s.replace("_", "-")
    s = _WHITESPACE_RE.sub(" ", s)
    return s


def _separator_agnostic(s: str) -> str:
    """Collapse hyphens, underscores, and whitespace to a single space.

    Used for alias resolution so that ``gpt-5.4-pro``, ``gpt-5.4 pro``,
    ``gpt_5.4_pro``, and ``gpt 5.4 pro`` all match the same alias key.
    """
    out = re.sub(r"[\s_\-]+", " ", s).strip()
    return out


def _resolve_alias(name: str) -> str | None:
    """Return canonical model name for ``name`` or None if unknown.

    Alias matching is separator-agnostic: hyphens, underscores, and
    whitespace are all treated as equivalent separators, so every
    common model-name spelling resolves to the same canonical entry.
    """
    cfg = _load_config()
    aliases: dict[str, str] = cfg.get("aliases", {})
    input_key = _separator_agnostic(_normalise(name))
    # Exact separator-agnostic alias hit.
    for alias_key, canonical in aliases.items():
        if _separator_agnostic(_normalise(alias_key)) == input_key:
            return canonical
    # Exact canonical-name hit.
    lookup = _load_model_lookup()
    for canonical in lookup:
        if _separator_agnostic(_normalise(canonical)) == input_key:
            return canonical
    # ECI-table hit.
    eci = _load_eci_scores()
    for canonical in eci:
        if _separator_agnostic(_normalise(canonical)) == input_key:
            return canonical
    return None


# ---------------------------------------------------------------------------
# Public data classes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ModelRecord:
    """A single model's metadata as shipped in the frozen dataset."""

    input_name: str
    canonical: str | None
    release_date: date | None
    org: str | None
    tier: str | None
    eci_score: float | None
    has_reasoning_mode: bool | None
    known: bool

    def __str__(self) -> str:
        if not self.known:
            return f"<unknown model: {self.input_name!r}>"
        bits = [f"{self.canonical}"]
        if self.release_date:
            bits.append(f"released {self.release_date.isoformat()}")
        if self.eci_score is not None:
            bits.append(f"ECI {self.eci_score:.1f}")
        if self.tier:
            bits.append(f"tier={self.tier}")
        return "  ".join(bits)


@dataclass(frozen=True)
class FrontierSnapshot:
    """Frontier model at a given calendar month."""

    at_date: date
    month_start: date
    frontier_model: str
    frontier_eci: float
    frontier_release_date: date


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def lookup_model(name: str) -> ModelRecord:
    """Return a :class:`ModelRecord` for ``name``, known or not.

    The record is always populated with ``input_name``; when the alias is
    known, remaining fields are filled from the model-version lookup and the
    ECI scores table. Unknown aliases return ``known=False``.
    """
    canonical = _resolve_alias(name)
    if canonical is None:
        return ModelRecord(
            input_name=name,
            canonical=None,
            release_date=None,
            org=None,
            tier=None,
            eci_score=None,
            has_reasoning_mode=None,
            known=False,
        )

    lookup = _load_model_lookup()
    entry = lookup.get(canonical, {})
    eci_scores = _load_eci_scores()

    release_date: date | None = None
    if entry.get("release_date"):
        try:
            release_date = datetime.strptime(entry["release_date"], "%Y-%m-%d").date()
        except ValueError:
            release_date = None

    eci = entry.get("eci_score")
    if eci is None:
        eci = eci_scores.get(canonical)

    return ModelRecord(
        input_name=name,
        canonical=canonical,
        release_date=release_date,
        org=entry.get("org"),
        tier=entry.get("tier"),
        eci_score=float(eci) if eci is not None else None,
        has_reasoning_mode=entry.get("has_reasoning_mode"),
        known=True,
    )


def get_frontier_at_date(target: date | str) -> FrontierSnapshot | None:
    """Return the frontier model known to exist on ``target``.

    The monthly trajectory is aligned to the first of the month. For any
    ``target`` we return the entry for the month containing ``target``; if
    ``target`` precedes the first recorded month we return None.
    """
    if isinstance(target, str):
        target = datetime.strptime(target, "%Y-%m-%d").date()

    rows = _load_trajectory()
    if not rows or target < rows[0][0]:
        return None

    month_start = target.replace(day=1)
    # Find the latest trajectory row with month <= month_start.
    chosen = rows[0]
    for row in rows:
        if row[0] > month_start:
            break
        chosen = row
    month, model, eci, release = chosen
    return FrontierSnapshot(
        at_date=target,
        month_start=month,
        frontier_model=model,
        frontier_eci=eci,
        frontier_release_date=release,
    )


def list_known_models() -> list[str]:
    """Return the sorted list of canonical model names the package knows."""
    names = set(_load_model_lookup().keys()) | set(_load_eci_scores().keys())
    return sorted(names)
