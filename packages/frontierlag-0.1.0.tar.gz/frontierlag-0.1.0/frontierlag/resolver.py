"""
DOI → :class:`PaperMetadata` resolver.

The resolver has two layers:

    1. A *frozen-corpus hit* — if the DOI appears in the embedded audit
       dataset (``frontierlag/data/frozen_audit.json``, populated from the
       paper's own corpus), we return the stored extraction. This is the
       fast, cache-hit, offline path the static site relies on.

    2. A *live resolution* — if the DOI is unknown to the frozen corpus,
       we query CrossRef (for DOI metadata + publication date) and
       OpenAlex (for primary-topic hints). We do NOT attempt to extract
       model-identification from the abstract at this layer; that is a
       separate, tested pipeline (see the companion paper's extraction
       prompt). The resolver returns a ``PaperMetadata`` with publication
       date filled and a note that models must be supplied manually.

Callers should catch :class:`ResolverError` for network failures.
"""
from __future__ import annotations

import json
import logging
from datetime import date, datetime
from functools import lru_cache
from importlib import resources
from pathlib import Path
from typing import Any

import requests
import yaml

from frontierlag.audit import AuditReport, PaperMetadata, audit
from frontierlag.lookup import _load_config

logger = logging.getLogger(__name__)


class ResolverError(RuntimeError):
    """Raised when DOI resolution fails beyond the offline path."""


# ---------------------------------------------------------------------------
# Frozen-corpus cache
# ---------------------------------------------------------------------------


@lru_cache(maxsize=1)
def _load_frozen_audit() -> dict[str, dict[str, Any]]:
    """Return the DOI → metadata cache shipped with the package.

    The file is optional; if the paper's extraction is incomplete at release
    time, the file may be missing or empty and we fall back to live
    resolution. Each entry's value matches :class:`PaperMetadata.from_dict`.
    """
    ref = resources.files("frontierlag").joinpath("data/frozen_audit.json")
    try:
        with resources.as_file(ref) as p:
            path = Path(p)
            if not path.exists() or path.stat().st_size == 0:
                return {}
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
    except FileNotFoundError:
        return {}

    if isinstance(data, list):
        # Accept list-of-records format; normalise to dict keyed on DOI.
        data = {r["doi"]: r for r in data if r.get("doi")}
    return {_canonical_doi(k): v for k, v in data.items()}


def _canonical_doi(doi: str) -> str:
    """Strip common DOI prefixes and normalise case/whitespace."""
    s = doi.strip().lower()
    for prefix in ("https://doi.org/", "http://doi.org/", "doi.org/", "doi:"):
        if s.startswith(prefix):
            s = s[len(prefix):]
    return s


# ---------------------------------------------------------------------------
# Live resolvers
# ---------------------------------------------------------------------------


def _crossref_lookup(doi: str) -> dict[str, Any] | None:
    cfg = _load_config()
    url = cfg["doi_resolvers"]["crossref"] + doi
    headers = {"User-Agent": cfg["http"]["user_agent"], "Accept": "application/json"}
    try:
        resp = requests.get(url, headers=headers, timeout=cfg["http"]["timeout_seconds"])
    except requests.RequestException as exc:
        logger.warning("crossref request failed: %s", exc)
        return None
    if resp.status_code != 200:
        return None
    try:
        msg = resp.json().get("message") or {}
    except ValueError:
        return None
    return msg


def _openalex_lookup(doi: str) -> dict[str, Any] | None:
    cfg = _load_config()
    url = cfg["doi_resolvers"]["openalex"] + f"https://doi.org/{doi}"
    headers = {"User-Agent": cfg["http"]["user_agent"], "Accept": "application/json"}
    try:
        resp = requests.get(url, headers=headers, timeout=cfg["http"]["timeout_seconds"])
    except requests.RequestException as exc:
        logger.warning("openalex request failed: %s", exc)
        return None
    if resp.status_code != 200:
        return None
    try:
        return resp.json()
    except ValueError:
        return None


def _pub_date_from_crossref(msg: dict[str, Any]) -> date | None:
    for key in ("published-print", "published-online", "issued", "created", "deposited"):
        parts = (msg.get(key) or {}).get("date-parts") or []
        if parts and parts[0]:
            p = parts[0]
            try:
                year = int(p[0])
                month = int(p[1]) if len(p) > 1 else 1
                day = int(p[2]) if len(p) > 2 else 1
                return date(year, month, max(1, min(28, day)))
            except (TypeError, ValueError):
                continue
    return None


def _pub_date_from_openalex(msg: dict[str, Any]) -> date | None:
    for key in ("publication_date", "from_publication_date"):
        raw = msg.get(key)
        if raw:
            try:
                return datetime.strptime(raw, "%Y-%m-%d").date()
            except ValueError:
                continue
    year = msg.get("publication_year")
    if year:
        try:
            return date(int(year), 1, 1)
        except (TypeError, ValueError):
            return None
    return None


def resolve(doi: str) -> PaperMetadata:
    """Return :class:`PaperMetadata` for ``doi``, using the frozen cache first.

    Raises :class:`ResolverError` only if both the frozen cache and the live
    resolvers fail to return anything usable.
    """
    key = _canonical_doi(doi)
    frozen = _load_frozen_audit()
    if key in frozen:
        record = dict(frozen[key])
        record.setdefault("doi", key)
        return PaperMetadata.from_dict(record)

    cross = _crossref_lookup(key)
    oalex = _openalex_lookup(key)
    if cross is None and oalex is None:
        raise ResolverError(
            f"Could not resolve DOI {doi!r} via CrossRef or OpenAlex. "
            "Check the DOI and your network."
        )

    title: str | None = None
    pub_date: date | None = None
    if cross is not None:
        t = cross.get("title") or []
        if t:
            title = t[0]
        pub_date = _pub_date_from_crossref(cross)
    if pub_date is None and oalex is not None:
        pub_date = _pub_date_from_openalex(oalex)
    if title is None and oalex is not None:
        title = oalex.get("title") or oalex.get("display_name")

    return PaperMetadata(
        title=title,
        doi=key,
        publication_date=pub_date,
        evaluation_date=None,
        evaluation_date_inferred=False,
        primary_model=None,
        all_models=[],
        configuration_disclosures={},
        human_comparator_present=None,
        conclusion_valence=None,
    )


# ---------------------------------------------------------------------------
# Public convenience API
# ---------------------------------------------------------------------------


def check(
    doi: str,
    *,
    primary_model: str | None = None,
    evaluation_date: str | date | None = None,
    configuration_disclosures: dict[str, bool | None] | None = None,
) -> AuditReport:
    """Resolve ``doi`` and run the audit.

    If the DOI is in the frozen corpus, the embedded extraction is used and
    the remaining keyword arguments are treated as *overrides* for each
    field (useful for "what if this paper had disclosed reasoning mode?"
    sensitivity checks). If the DOI is not in the corpus, the caller must
    supply at least ``primary_model`` for the audit to yield capability and
    tier dimensions; configuration dimension is always computable when
    ``configuration_disclosures`` is passed.
    """
    metadata = resolve(doi)

    if primary_model is not None:
        metadata.primary_model = primary_model
        if primary_model not in metadata.all_models:
            metadata.all_models = [primary_model] + metadata.all_models
    if evaluation_date is not None:
        if isinstance(evaluation_date, str):
            evaluation_date = datetime.strptime(evaluation_date, "%Y-%m-%d").date()
        metadata.evaluation_date = evaluation_date
    if configuration_disclosures is not None:
        metadata.configuration_disclosures = dict(configuration_disclosures)

    return audit(metadata)


__all__ = ["check", "resolve", "ResolverError"]
