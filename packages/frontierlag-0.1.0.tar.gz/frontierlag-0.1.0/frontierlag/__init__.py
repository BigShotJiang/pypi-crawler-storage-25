"""
frontierlag — Audit the capability gap between frontier AI and published academic evaluations.

A companion to the paper "Frontier Lag: A Bibliometric Audit of Capability Misrepresentation
in Academic AI Evaluation" (Gringras, 2026).

Quick start:

    >>> import frontierlag as fl
    >>> report = fl.check("10.1038/s41591-024-03425-5")
    >>> print(report)

Or from the shell:

    $ frontierlag check 10.1038/s41591-024-03425-5

The package exposes three public entry points:

    fl.check(doi)           — resolve a paper's models and compute its frontier lag
    fl.audit(metadata)      — audit already-extracted metadata (skip DOI resolution)
    fl.lookup_model(name)   — look up a single model's release date and ECI score

Data files are frozen at package build time (see ``frontierlag.FREEZE_DATE``).
Quarterly refreshes are published via pip upgrade.
"""

from frontierlag._version import FREEZE_DATE, __version__
from frontierlag.audit import AuditReport, audit
from frontierlag.lookup import (
    get_frontier_at_date,
    list_known_models,
    lookup_model,
)
from frontierlag.resolver import check

__all__ = [
    "__version__",
    "FREEZE_DATE",
    "check",
    "audit",
    "AuditReport",
    "lookup_model",
    "get_frontier_at_date",
    "list_known_models",
]
