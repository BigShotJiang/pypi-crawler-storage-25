"""
Access to the frozen audit dataset shipped with the package.

The dataset is a JSON array of extracted records, one per paper in the
companion audit. ``load_dataset`` exposes it as a list of plain dicts so
users can filter, aggregate, or cross-reference against their own corpus
without depending on pandas.
"""
from __future__ import annotations

import json
from functools import lru_cache
from importlib import resources
from pathlib import Path
from typing import Any, Callable, Iterator

from frontierlag._version import FREEZE_DATE


@lru_cache(maxsize=1)
def load_dataset() -> list[dict[str, Any]]:
    """Return all records in the frozen audit dataset.

    Returns an empty list if the dataset file is absent (e.g. during the
    package's launch day before production extraction completes). Callers
    should check ``FREEZE_DATE`` to display the snapshot date.
    """
    ref = resources.files("frontierlag").joinpath("data/frozen_audit.json")
    try:
        with resources.as_file(ref) as p:
            path = Path(p)
            if not path.exists() or path.stat().st_size == 0:
                return []
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
    except FileNotFoundError:
        return []

    if isinstance(data, dict):
        return list(data.values())
    return list(data)


def filter_dataset(
    *,
    domain: str | None = None,
    year: int | None = None,
    primary_model: str | None = None,
    predicate: Callable[[dict[str, Any]], bool] | None = None,
) -> list[dict[str, Any]]:
    """Filter the frozen dataset by any combination of fields.

    All arguments are ANDed together. ``predicate`` accepts a function for
    arbitrary filtering (e.g. ``lambda r: r['capability_gap_eci'] >= 10``).
    """
    records = load_dataset()
    out: list[dict[str, Any]] = []
    for r in records:
        if domain is not None and r.get("domain") != domain:
            continue
        if year is not None and r.get("publication_year") != year:
            continue
        if primary_model is not None and r.get("primary_model") != primary_model:
            continue
        if predicate is not None and not predicate(r):
            continue
        out.append(r)
    return out


def iter_dataset() -> Iterator[dict[str, Any]]:
    """Iterate records lazily (useful for large downstream pipelines)."""
    yield from load_dataset()


def dataset_freeze_date() -> str:
    """Return the freeze date of the embedded dataset (ISO YYYY-MM-DD)."""
    return FREEZE_DATE


__all__ = [
    "load_dataset",
    "filter_dataset",
    "iter_dataset",
    "dataset_freeze_date",
]
