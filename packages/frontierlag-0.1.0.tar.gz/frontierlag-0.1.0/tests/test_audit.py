"""Tests for frontierlag.audit."""
from __future__ import annotations

from datetime import date

import pytest

from frontierlag.audit import CONFIGURATION_ITEMS, PaperMetadata, audit


class TestAudit:
    def test_gpt4_paper_in_2025_flags_compound_failure(self) -> None:
        # A paper testing GPT-4 (Mar 2023) at eval Oct 2024 with no
        # configuration disclosure should fire all three dimensions. GPT-4
        # has ECI ~126 and multiple OpenAI siblings with higher ECI by
        # Oct 2024.
        m = PaperMetadata(
            title="Testing GPT-4 on clinical reasoning",
            doi="10.0000/example",
            publication_date=date(2025, 1, 15),
            evaluation_date=date(2024, 10, 1),
            primary_model="GPT-4",
            configuration_disclosures={k: False for k in CONFIGURATION_ITEMS},
        )
        report = audit(m)
        assert report.primary_model_canonical == "GPT-4 (Mar 2023)"
        assert report.capability_gap_eci is not None
        assert report.capability_gap_eci >= 10
        assert report.capability_gap_months is not None
        assert report.capability_gap_months >= 12
        assert report.tier_gap_siblings is not None and report.tier_gap_siblings >= 1
        assert report.configuration_disclosure_rate == 0.0
        assert report.compound_failure is True

    def test_legacy_gpt35_resolves_to_dated_variant_with_eci(self) -> None:
        # Post-D3 alias fix: "GPT-3.5" resolves to "GPT-3.5 Turbo (Jun 2023)",
        # the earliest-release dated variant per pre-reg SC-17. Both the
        # capability-gap ECI points and the calendar-months gap are now
        # computable — ECI comes from the frozen Epoch snapshot, months
        # from the release-date difference.
        m = PaperMetadata(
            primary_model="GPT-3.5",
            publication_date=date(2025, 1, 15),
            evaluation_date=date(2024, 10, 1),
        )
        report = audit(m)
        assert report.primary_model_canonical == "GPT-3.5 Turbo (Jun 2023)"
        assert report.capability_gap_eci is not None
        assert report.capability_gap_eci > 10  # Well behind 2024 frontier.
        assert report.capability_gap_months is not None
        assert report.capability_gap_months >= 12

    def test_contemporary_frontier_paper_passes(self) -> None:
        # A paper testing GPT-5.4 Pro at evaluation date 2026-03-10 with
        # full disclosure. Gap should be small (within threshold), no
        # stronger siblings, full disclosure.
        m = PaperMetadata(
            title="Frontier benchmark",
            publication_date=date(2026, 4, 1),
            evaluation_date=date(2026, 3, 10),
            primary_model="GPT-5.4 Pro",
            configuration_disclosures={k: True for k in CONFIGURATION_ITEMS},
        )
        report = audit(m)
        assert report.primary_model_canonical == "GPT-5.4 Pro"
        assert report.capability_gap_eci is not None
        # Tested model outscores or is within a few ECI points of the
        # monthly-trajectory frontier — well below the 10-point threshold.
        assert report.capability_gap_eci < 5
        assert report.configuration_disclosure_rate == 1.0
        assert report.compound_failure is False

    def test_none_evaluation_date_flagged_in_notes(self) -> None:
        m = PaperMetadata(
            title="x",
            primary_model="GPT-4",
            publication_date=None,
            evaluation_date=None,
        )
        report = audit(m)
        assert any("No evaluation or publication date" in n for n in report.notes)
        assert report.capability_gap_months is None

    def test_publication_date_substitution_noted(self) -> None:
        m = PaperMetadata(
            title="x",
            primary_model="GPT-4",
            publication_date=date(2024, 6, 1),
            evaluation_date=None,
        )
        report = audit(m)
        assert report.evaluation_date_inferred is True
        assert any("Evaluation date absent" in n for n in report.notes)

    def test_unknown_primary_model_adds_note(self) -> None:
        m = PaperMetadata(
            title="x",
            primary_model="SomeFakeModel-2099",
            publication_date=date(2025, 1, 1),
        )
        report = audit(m)
        assert report.primary_model_canonical is None
        assert any("did not match any known alias" in n for n in report.notes)

    def test_configuration_disclosure_with_mixed_values(self) -> None:
        disclosures = {k: False for k in CONFIGURATION_ITEMS}
        disclosures["model_version_exact"] = True
        disclosures["access_date"] = True
        disclosures["reasoning_mode"] = None  # not applicable
        m = PaperMetadata(
            primary_model="GPT-4o",
            publication_date=date(2024, 12, 1),
            configuration_disclosures=disclosures,
        )
        report = audit(m)
        # 2 of 9 applicable items disclosed.
        assert report.configuration_disclosure_rate == pytest.approx(2 / 9, abs=1e-6)

    def test_from_dict_roundtrip(self) -> None:
        payload = {
            "title": "x",
            "doi": "10.0000/x",
            "publication_date": "2025-06-01",
            "evaluation_date": "2025-05-01",
            "primary_model": "Claude 3.5 Sonnet",
            "configuration_disclosures": {"model_version_exact": True},
        }
        m = PaperMetadata.from_dict(payload)
        assert m.publication_date == date(2025, 6, 1)
        assert m.evaluation_date == date(2025, 5, 1)
        report = audit(m)
        assert report.primary_model_canonical == "Claude 3.5 Sonnet"

    def test_thresholds_override(self) -> None:
        m = PaperMetadata(
            primary_model="GPT-4o",
            publication_date=date(2025, 1, 1),
            evaluation_date=date(2024, 11, 1),
            configuration_disclosures={k: True for k in CONFIGURATION_ITEMS},
        )
        strict = audit(m, thresholds={"capability_gap_eci_points": 0.01})
        lenient = audit(m, thresholds={"capability_gap_eci_points": 100})
        # With a stricter threshold the capability dim fails more often.
        assert strict.thresholds["capability_gap_eci_points"] == 0.01
        assert lenient.thresholds["capability_gap_eci_points"] == 100

    def test_report_json_roundtrip(self) -> None:
        import json as _json
        m = PaperMetadata(
            primary_model="GPT-4",
            publication_date=date(2024, 1, 1),
            configuration_disclosures={k: True for k in CONFIGURATION_ITEMS},
        )
        s = audit(m).to_json()
        parsed = _json.loads(s)
        assert parsed["primary_model_canonical"] == "GPT-4 (Mar 2023)"
        assert "data_freeze_date" in parsed

    def test_report_text_contains_canonical_headers(self) -> None:
        m = PaperMetadata(
            primary_model="GPT-4",
            publication_date=date(2024, 6, 1),
            configuration_disclosures={k: True for k in CONFIGURATION_ITEMS},
        )
        text = audit(m).to_text()
        assert "frontierlag audit" in text
        assert "Audit dimensions" in text
        assert "Configuration" in text
