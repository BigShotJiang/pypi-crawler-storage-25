"""Tests for the frontierlag CLI."""
from __future__ import annotations

import io
import json
from contextlib import redirect_stdout, redirect_stderr

import pytest

from frontierlag import cli


class TestCli:
    def test_info_prints_version(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = cli.main(["info"])
        assert rc == 0
        out = buf.getvalue()
        assert "frontierlag" in out
        assert "data freeze" in out

    def test_lookup_known_model(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = cli.main(["lookup", "GPT-4"])
        assert rc == 0
        assert "GPT-4" in buf.getvalue()

    def test_lookup_unknown_model_still_zero_exit(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = cli.main(["lookup", "NotAModel-1234"])
        # We return zero; the output reports "unknown model". Shell consumers
        # can grep for '<unknown' if they care.
        assert rc == 0
        assert "unknown" in buf.getvalue().lower()

    def test_lookup_json_roundtrip(self) -> None:
        # Post-D3 alias fix: "GPT-4o" resolves to the dated variant
        # "GPT-4o (May 2024)" (the earliest-release GPT-4o snapshot per
        # pre-reg SC-17), so the ECI score from the frozen Epoch snapshot
        # is populated.
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = cli.main(["lookup", "--json", "GPT-4o"])
        assert rc == 0
        parsed = json.loads(buf.getvalue())
        assert parsed["canonical"] == "GPT-4o (May 2024)"
        assert parsed["known"] is True
        assert parsed["eci_score"] is not None

    def test_frontier_command(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = cli.main(["frontier", "2025-06-01"])
        assert rc == 0
        assert "2025-06-01" in buf.getvalue()

    def test_frontier_invalid_date(self) -> None:
        err = io.StringIO()
        with redirect_stderr(err):
            rc = cli.main(["frontier", "not-a-date"])
        assert rc == 2
        assert "invalid date" in err.getvalue()

    def test_models_list_contains_canonical(self) -> None:
        buf = io.StringIO()
        with redirect_stdout(buf):
            rc = cli.main(["models", "--json"])
        assert rc == 0
        names = json.loads(buf.getvalue())
        assert "Claude Opus 4.6" in names

    def test_check_without_network_fails_gracefully(self) -> None:
        # An obviously invalid DOI should raise ResolverError -> rc 2. We
        # avoid real network in tests; this exercises the error path.
        import frontierlag.resolver as r

        orig_cross = r._crossref_lookup
        orig_oalex = r._openalex_lookup
        r._crossref_lookup = lambda doi: None
        r._openalex_lookup = lambda doi: None
        try:
            err = io.StringIO()
            with redirect_stderr(err):
                rc = cli.main(["check", "10.0000/totally-fake-doi"])
            assert rc == 2
            assert "error" in err.getvalue().lower()
        finally:
            r._crossref_lookup = orig_cross
            r._openalex_lookup = orig_oalex
