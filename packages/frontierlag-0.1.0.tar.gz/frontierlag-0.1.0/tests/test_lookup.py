"""Tests for frontierlag.lookup."""
from __future__ import annotations

from datetime import date

import pytest

from frontierlag.lookup import (
    ModelRecord,
    get_frontier_at_date,
    list_known_models,
    lookup_model,
)


class TestLookupModel:
    def test_known_alias_resolves(self) -> None:
        r = lookup_model("GPT-4")
        assert r.known is True
        assert r.canonical == "GPT-4 (Mar 2023)"
        assert r.release_date == date(2023, 3, 15)
        assert r.org == "OpenAI"
        assert r.eci_score is not None and r.eci_score > 100

    def test_unknown_alias_returns_known_false(self) -> None:
        r = lookup_model("NotARealModel-9000")
        assert r.known is False
        assert r.canonical is None
        assert r.eci_score is None

    def test_case_insensitive_alias(self) -> None:
        a = lookup_model("gpt-4o-mini")
        b = lookup_model("GPT-4o mini")
        assert a.known and b.known
        assert a.canonical == b.canonical == "GPT-4o mini"

    def test_canonical_name_as_input(self) -> None:
        r = lookup_model("Claude Opus 4.5")
        assert r.known is True
        assert r.canonical == "Claude Opus 4.5"

    def test_whitespace_and_underscore_normalised(self) -> None:
        a = lookup_model("gpt_4")
        b = lookup_model("  GPT-4 ")
        assert a.known and b.known
        assert a.canonical == b.canonical


class TestFrontierAtDate:
    def test_frontier_before_trajectory_returns_none(self) -> None:
        assert get_frontier_at_date(date(2020, 1, 1)) is None

    def test_frontier_mid_2024(self) -> None:
        snap = get_frontier_at_date(date(2024, 7, 15))
        assert snap is not None
        # Trajectory has Claude 3.5 Sonnet as frontier July/August 2024.
        assert snap.frontier_model == "Claude 3.5 Sonnet"

    def test_frontier_matches_latest_recorded(self) -> None:
        snap = get_frontier_at_date(date(2026, 4, 10))
        assert snap is not None
        assert snap.frontier_model == "GPT-5.4 Pro"
        assert snap.frontier_eci > 155

    def test_month_padding_rounds_down_to_first_of_month(self) -> None:
        snap = get_frontier_at_date(date(2025, 1, 31))
        assert snap is not None
        # January 2025 row; frontier at that time was o3.
        assert snap.month_start == date(2025, 1, 1)
        assert snap.frontier_model == "o3"

    def test_string_date_accepted(self) -> None:
        snap = get_frontier_at_date("2025-09-01")
        assert snap is not None
        assert snap.frontier_model == "GPT-5"


class TestListKnownModels:
    def test_nonempty(self) -> None:
        names = list_known_models()
        assert len(names) > 20
        assert any(n.startswith("Claude") for n in names)
        assert any(n.startswith("GPT") for n in names)

    def test_sorted(self) -> None:
        names = list_known_models()
        assert names == sorted(names)
