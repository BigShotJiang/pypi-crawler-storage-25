"""Node execution logic for different node types."""

import inspect
from typing import Any

from duragraph.nodes import NodeMetadata
from duragraph.types import State


async def execute_llm_node(
    node_name: str,
    metadata: NodeMetadata,
    state: State,
) -> dict[str, Any]:
    """Execute an LLM node with optional tool calling.

    Args:
        node_name: Name of the node.
        metadata: Node metadata with LLM configuration.
        state: Current state.

    Returns:
        State updates from the LLM, potentially including tool results.
    """
    from duragraph.llm import LLMRequest, get_provider
    from duragraph.tools import resolve_tool_calls

    config = metadata.config
    model = config.get("model", "gpt-4o-mini")
    temperature = config.get("temperature", 0.7)
    max_tokens = config.get("max_tokens")
    system_prompt = config.get("system_prompt")
    tool_schemas = config.get("tool_schemas", [])

    # Resolve prompt template if attached via @prompt decorator
    prompt_meta = config.get("_prompt_metadata")
    if prompt_meta:
        from duragraph.prompts.template import PromptLibrary

        library: PromptLibrary | None = config.get("_prompt_library")
        if library is not None:
            tmpl = library.get(prompt_meta["prompt_id"], version=prompt_meta.get("version"))
            template_vars = {
                k: v for k, v in state.items() if isinstance(v, (str, int, float, bool))
            }
            system_prompt = tmpl.render(
                **{k: template_vars[k] for k in tmpl.variables if k in template_vars}
            )

    # Build messages from state
    messages = []
    if "messages" in state:
        # State contains conversation messages
        messages = state["messages"].copy()
    elif "input" in state:
        # Simple input
        messages = [{"role": "user", "content": str(state["input"])}]
    else:
        # Use entire state as context
        messages = [{"role": "user", "content": str(state)}]

    # Get provider and make request
    provider = get_provider(model)
    request = LLMRequest(
        messages=messages,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        system_prompt=system_prompt,
        tools=tool_schemas,  # Pass tool schemas instead of names
    )

    response = await provider.acomplete(request)

    # Update state with response
    result: dict[str, Any] = {}

    # Handle tool calls if present
    if response.tool_calls:
        # Execute tools and get results
        tool_results = resolve_tool_calls(response.tool_calls)

        # Add assistant message with tool calls
        if "messages" in state:
            messages.append(
                {
                    "role": "assistant",
                    "content": response.content,
                    "tool_calls": response.tool_calls,
                }
            )
            # Add tool results
            messages.extend(tool_results)

            # Make another LLM call to process tool results
            follow_up_request = LLMRequest(
                messages=messages,
                model=model,
                temperature=temperature,
                max_tokens=max_tokens,
                system_prompt=system_prompt,
                tools=tool_schemas,
            )

            follow_up_response = await provider.acomplete(follow_up_request)

            # Add final response
            messages.append({"role": "assistant", "content": follow_up_response.content})

            result["messages"] = messages
            result["response"] = follow_up_response.content
        else:
            # For non-message mode, just store tool call info
            result["tool_calls"] = response.tool_calls
            result["tool_results"] = tool_results
            result["response"] = response.content
    else:
        # No tool calls, handle normally
        if "messages" in state:
            messages.append({"role": "assistant", "content": response.content})
            result["messages"] = messages
        else:
            result["response"] = response.content

    return result


async def execute_dspy_node(
    node_name: str,
    metadata: NodeMetadata,
    node_method: Any,
    state: State,
) -> dict[str, Any]:
    """Execute a DSPy module node.

    Builds the DSPy module from node config, runs it with inputs
    extracted from state, merges outputs back, then calls the
    user's method body for optional post-processing.

    Args:
        node_name: Name of the node.
        metadata: Node metadata with DSPy configuration.
        node_method: The decorated method (called after DSPy execution).
        state: Current state.

    Returns:
        Updated state dict.
    """
    from duragraph.dspy.module import DspyNodeConfig, execute_dspy_module

    config = metadata.config
    dspy_config = DspyNodeConfig(
        signature=config["signature"],
        module=config.get("module", "ChainOfThought"),
        model=config.get("model"),
        temperature=config.get("temperature", 0.7),
        max_tokens=config.get("max_tokens"),
        tools=config.get("tools", []),
        input_map=config.get("input_map"),
        output_map=config.get("output_map"),
        optimized_path=config.get("optimized_path"),
    )

    updated_state = await execute_dspy_module(dspy_config, state)

    if inspect.iscoroutinefunction(node_method):
        result = await node_method(updated_state)
    else:
        result = node_method(updated_state)

    if isinstance(result, dict):
        return result
    return updated_state


async def execute_function_node(
    node_method: Any,
    state: State,
) -> Any:
    """Execute a regular function node (sync or async).

    Args:
        node_method: The node method to execute.
        state: Current state.

    Returns:
        The raw result from the node method. Callers should check if it's
        a dict for state updates, or a string for routing decisions.
    """
    if inspect.iscoroutinefunction(node_method):
        result = await node_method(state)
    else:
        result = node_method(state)

    return result


async def execute_node(
    node_name: str,
    metadata: NodeMetadata,
    node_method: Any,
    state: State,
) -> Any:
    """Execute a node based on its type.

    Args:
        node_name: Name of the node.
        metadata: Node metadata.
        node_method: The node method.
        state: Current state.

    Returns:
        For LLM nodes, always returns a dict of state updates.
        For function/tool/router/human nodes, returns the raw result
        (may be a dict, string, or None).
    """
    node_type = metadata.node_type

    if node_type == "llm":
        return await execute_llm_node(node_name, metadata, state)
    elif node_type == "dspy":
        return await execute_dspy_node(node_name, metadata, node_method, state)
    elif node_type == "subgraph":
        from duragraph.subgraph import execute_subgraph

        config = metadata.config
        return await execute_subgraph(
            config["graph_cls"], state, config.get("input_map", {}), config.get("output_map", {})
        )
    elif node_type in ("function", "tool", "router", "human"):
        return await execute_function_node(node_method, state)
    else:
        raise ValueError(f"Unknown node type: {node_type}")
