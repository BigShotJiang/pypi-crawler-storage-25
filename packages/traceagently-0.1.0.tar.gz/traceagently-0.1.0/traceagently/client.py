from __future__ import annotations

import time
from contextlib import contextmanager
from typing import Any, Dict, Generator, Optional

import httpx

_API_BASE = "https://api.traceagently.com"


class Trace:
    """
    Active trace handle. Use as a context manager or call .end() manually.

    with ta.trace(agent_id="my-agent", task="Do something") as t:
        t.thought("Thinking...")
        t.tool_call("search", {"query": "..."})
        t.tool_result({"results": [...]})
        t.final_response("Done")
    """

    def __init__(self, client: "TraceAgently", trace_id: str) -> None:
        self._client = client
        self.trace_id = trace_id
        self._ended = False

    # ------------------------------------------------------------------ #
    # Event helpers                                                        #
    # ------------------------------------------------------------------ #

    def thought(self, content: str, tokens: Optional[int] = None, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Record a reasoning step."""
        self._event("thought", content, tokens=tokens, metadata=metadata)

    def tool_call(self, tool_name: str, args: Optional[Dict[str, Any]] = None, tokens: Optional[int] = None, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Record a tool invocation."""
        import json
        content = json.dumps({"tool": tool_name, "args": args or {}})
        self._event("tool_call", content, tokens=tokens, metadata=metadata)

    def tool_result(self, result: Any, tokens: Optional[int] = None, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Record the result returned by a tool."""
        import json
        content = result if isinstance(result, str) else json.dumps(result)
        self._event("tool_result", content, tokens=tokens, metadata=metadata)

    def error(self, message: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Record an error event."""
        self._event("error", message, metadata=metadata)

    def final_response(self, content: str, tokens: Optional[int] = None, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Record the agent's final response and end the trace."""
        self._event("final_response", content, tokens=tokens, metadata=metadata)
        self.end()

    # ------------------------------------------------------------------ #
    # Lifecycle                                                            #
    # ------------------------------------------------------------------ #

    def end(self, status: str = "completed") -> None:
        """Explicitly end the trace."""
        if self._ended:
            return
        self._ended = True
        try:
            self._client._request(
                "PATCH",
                f"/traces/{self.trace_id}",
                {"status": status, "endedAt": int(time.time() * 1000)},
            )
        except Exception:
            pass  # Best-effort — never crash the agent

    def _event(
        self,
        event_type: str,
        content: str,
        tokens: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self._ended:
            return
        payload: Dict[str, Any] = {
            "type": event_type,
            "content": content,
            "timestamp": int(time.time() * 1000),
        }
        if tokens is not None:
            payload["tokens"] = tokens
        if metadata:
            payload["metadata"] = metadata

        try:
            self._client._request("POST", f"/traces/{self.trace_id}/events", payload)
        except Exception:
            pass  # Best-effort — never crash the agent

    # ------------------------------------------------------------------ #
    # Context manager                                                      #
    # ------------------------------------------------------------------ #

    def __enter__(self) -> "Trace":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is not None:
            try:
                import traceback
                self.error(f"{exc_type.__name__}: {exc_val}\n{''.join(traceback.format_tb(exc_tb))}")
            except Exception:
                pass
            self.end(status="failed")
        else:
            if not self._ended:
                self.end(status="completed")


class TraceAgently:
    """
    TraceAgently client.

    ta = TraceAgently(api_key="ta_live_...")

    # Context manager — auto-closes on exit
    with ta.trace(agent_id="support-bot", task="Refund user #123") as t:
        t.thought("Checking order database")
        t.tool_call("get_order", {"user_id": 123})
        t.tool_result({"status": "delivered"})
        t.final_response("Cannot refund a delivered order")

    # Or manual
    t = ta.start_trace(agent_id="support-bot", task="Refund user #123")
    t.thought("...")
    t.end()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _API_BASE,
        timeout: float = 10.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "traceagently-python/0.1.0",
            },
            timeout=timeout,
        )

    def trace(
        self,
        agent_id: str,
        task: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Trace:
        """
        Start a trace and return a context manager.

        with ta.trace(agent_id="my-agent", task="Do something") as t:
            t.thought("...")
        """
        return self.start_trace(agent_id=agent_id, task=task, metadata=metadata)

    def start_trace(
        self,
        agent_id: str,
        task: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Trace:
        """Start a trace and return the Trace handle."""
        payload: Dict[str, Any] = {
            "agentId": agent_id,
            "task": task,
            "startedAt": int(time.time() * 1000),
        }
        if metadata:
            payload["metadata"] = metadata

        resp = self._request("POST", "/traces", payload)
        trace_id = resp["traceId"]
        return Trace(client=self, trace_id=trace_id)

    def _request(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        response = self._http.request(method, path, json=body)
        response.raise_for_status()
        if response.content:
            return response.json()
        return {}

    def __del__(self) -> None:
        try:
            self._http.close()
        except Exception:
            pass
