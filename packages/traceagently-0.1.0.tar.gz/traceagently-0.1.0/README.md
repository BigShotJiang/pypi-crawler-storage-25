# traceagently

Real-time observability for AI agents. See every thought, tool call, and error — live.

## Install

```bash
pip install traceagently
```

## Quick Start

```python
from traceagently import TraceAgently

ta = TraceAgently(api_key="ta_live_...")

with ta.trace(agent_id="support-bot", task="Refund user #123") as trace:
    trace.thought("I need to check the order database")
    trace.tool_call("check_order", {"user_id": 123})
    trace.tool_result({"status": "delivered"})
    trace.final_response("Cannot refund a delivered order")
```

Traces appear live at [app.traceagently.com](https://app.traceagently.com).

## Event Types

| Method | Description |
|---|---|
| `trace.thought(content)` | A reasoning step |
| `trace.tool_call(name, args)` | Tool invocation |
| `trace.tool_result(result)` | Tool result |
| `trace.error(message)` | An error |
| `trace.final_response(content)` | Final answer — also ends the trace |

The context manager automatically:
- Marks the trace `completed` on clean exit
- Captures the exception and marks the trace `failed` on error

## Works with any framework

```python
# LangChain callback
# CrewAI hook
# Raw OpenAI loop
# Any agent you wrote yourself
```

## API Keys

Get your API key at [app.traceagently.com/dashboard/keys](https://app.traceagently.com/dashboard/keys).

## Links

- [Dashboard](https://app.traceagently.com)
- [Docs](https://traceagently.com/docs)
- [GitHub](https://github.com/traceagently/sdk-python)
