"""Generic audit logger for tracking MCP operations.

Shared across BPA, Translation, and other MCP servers. Each server provides
its own ``get_connection`` callable so the logger is DB-agnostic.
"""

from __future__ import annotations

import json

# ---------------------------------------------------------------------------
# Type for the get_connection callable each server must supply
# ---------------------------------------------------------------------------
from contextlib import AbstractAsyncContextManager
from pathlib import Path
from typing import Any, Protocol

import aiosqlite

from mcp_eregistrations_common.audit.models import AuditEntry, AuditStatus


class GetConnection(Protocol):
    """Protocol for the async context-manager factory that yields a DB conn."""

    def __call__(
        self, db_path: Path | None = None
    ) -> AbstractAsyncContextManager[aiosqlite.Connection]: ...


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class AuditEntryNotFoundError(Exception):
    """Raised when an audit entry is not found."""


class AuditEntryImmutableError(Exception):
    """Raised when attempting to modify a finalized audit entry."""


# ---------------------------------------------------------------------------
# AuditLogger
# ---------------------------------------------------------------------------


class AuditLogger:
    """Append-only audit logger for MCP operations.

    This logger implements the audit-before-write pattern:
    1. Call record_pending() BEFORE executing the operation
    2. Call mark_success() or mark_failed() AFTER the operation completes

    The audit log is append-only: entries can only be created and their
    status updated, never deleted or modified otherwise.

    Args:
        db_path: Optional path to SQLite database.
        get_connection: Async context-manager factory that yields a
            configured ``aiosqlite.Connection``. Each MCP server provides
            its own (BPA uses ``mcp_eregistrations_bpa.db.get_connection``).
    """

    def __init__(
        self,
        db_path: Path | None = None,
        get_connection: GetConnection | None = None,
    ):
        self._db_path = db_path
        self._get_connection = get_connection

    def _conn(self) -> AbstractAsyncContextManager[aiosqlite.Connection]:
        """Return the connection context manager for ``self._db_path``."""
        if self._get_connection is None:
            raise RuntimeError(
                "AuditLogger requires a get_connection callable. "
                "Pass one at construction time or use a server-specific subclass."
            )
        return self._get_connection(self._db_path)

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------

    async def record_pending(
        self,
        user_email: str,
        operation_type: str,
        object_type: str,
        params: dict[str, Any],
        object_id: str | None = None,
    ) -> str:
        """Record a pending operation BEFORE execution.

        Args:
            user_email: Email of the user performing the operation.
            operation_type: Type (create, update, delete, link, unlink).
            object_type: Type (service, registration, field, determinant, action).
            params: Parameters passed to the operation.
            object_id: Optional ID of the object being operated on.

        Returns:
            The audit entry ID (UUID string).
        """
        entry = AuditEntry.create(
            user_email=user_email,
            operation_type=operation_type,
            object_type=object_type,
            params=params,
            object_id=object_id,
        )

        async with self._conn() as conn:
            await conn.execute(
                """
                INSERT INTO audit_logs (
                    id, timestamp, user_email, operation_type, object_type,
                    object_id, params, status, result, rollback_state_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    entry.id,
                    entry.timestamp,
                    entry.user_email,
                    entry.operation_type,
                    entry.object_type,
                    entry.object_id,
                    json.dumps(entry.params),
                    entry.status.value,
                    None,
                    None,
                ),
            )
            await conn.commit()

        return entry.id

    async def mark_success(self, audit_id: str, result: dict[str, Any]) -> None:
        """Mark operation as successful with result summary.

        Args:
            audit_id: The audit entry ID returned by record_pending().
            result: Summary of the operation result.

        Raises:
            AuditEntryNotFoundError: If audit_id does not exist.
            AuditEntryImmutableError: If entry is not in PENDING status.
        """
        async with self._conn() as conn:
            cursor = await conn.execute(
                "SELECT status FROM audit_logs WHERE id = ?",
                (audit_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                raise AuditEntryNotFoundError(f"Audit entry '{audit_id}' not found")
            if row["status"] != AuditStatus.PENDING.value:
                raise AuditEntryImmutableError(
                    f"Cannot modify audit entry with status '{row['status']}'. "
                    "Only PENDING entries can be updated."
                )

            await conn.execute(
                "UPDATE audit_logs SET status = ?, result = ? WHERE id = ?",
                (AuditStatus.SUCCESS.value, json.dumps(result), audit_id),
            )
            await conn.commit()

    async def mark_failed(self, audit_id: str, error_message: str) -> None:
        """Mark operation as failed with error details.

        Args:
            audit_id: The audit entry ID returned by record_pending().
            error_message: Description of the error that occurred.

        Raises:
            AuditEntryNotFoundError: If audit_id does not exist.
            AuditEntryImmutableError: If entry is not in PENDING status.
        """
        async with self._conn() as conn:
            cursor = await conn.execute(
                "SELECT status FROM audit_logs WHERE id = ?",
                (audit_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                raise AuditEntryNotFoundError(f"Audit entry '{audit_id}' not found")
            if row["status"] != AuditStatus.PENDING.value:
                raise AuditEntryImmutableError(
                    f"Cannot modify audit entry with status '{row['status']}'. "
                    "Only PENDING entries can be updated."
                )

            await conn.execute(
                "UPDATE audit_logs SET status = ?, result = ? WHERE id = ?",
                (
                    AuditStatus.FAILED.value,
                    json.dumps({"error": error_message}),
                    audit_id,
                ),
            )
            await conn.commit()

    async def save_rollback_state(
        self,
        audit_id: str,
        object_type: str,
        object_id: str,
        previous_state: dict[str, Any],
    ) -> str:
        """Save rollback state for an audit entry.

        Args:
            audit_id: The audit entry ID to associate the rollback state with.
            object_type: Type of object (service, registration, etc.).
            object_id: ID of the object.
            previous_state: The object state before the operation.

        Returns:
            The rollback state ID (UUID string).
        """
        import uuid

        rollback_state_id = str(uuid.uuid4())

        async with self._conn() as conn:
            await conn.execute(
                """
                INSERT INTO rollback_states (
                    id, audit_log_id, object_type, object_id, previous_state
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (
                    rollback_state_id,
                    audit_id,
                    object_type,
                    object_id,
                    json.dumps(previous_state),
                ),
            )
            # Backfill object_id on the audit row. record_pending may have
            # been called before the server-side id was known (e.g. create
            # operations where the id is generated by the backend POST/PUT
            # response). save_rollback_state knows the resolved id, so update
            # it here in the same transaction. Existing object_id values are
            # preserved via COALESCE when the caller intentionally set one
            # upfront.
            await conn.execute(
                """
                UPDATE audit_logs
                SET rollback_state_id = ?,
                    object_id = COALESCE(object_id, ?)
                WHERE id = ?
                """,
                (rollback_state_id, object_id, audit_id),
            )
            await conn.commit()

        return rollback_state_id

    async def get_rollback_state(self, audit_id: str) -> dict[str, Any] | None:
        """Return the persisted rollback state for an audit entry, or None."""
        async with self._conn() as conn:
            cursor = await conn.execute(
                """
                SELECT previous_state FROM rollback_states
                WHERE audit_log_id = ?
                """,
                (audit_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                return None
            state: dict[str, Any] = json.loads(row[0])
            return state

    async def get_entry(self, audit_id: str) -> AuditEntry | None:
        """Retrieve audit entry by ID.

        Args:
            audit_id: The audit entry ID to retrieve.

        Returns:
            The AuditEntry if found, None otherwise.
        """
        async with self._conn() as conn:
            cursor = await conn.execute(
                "SELECT * FROM audit_logs WHERE id = ?",
                (audit_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                return None
            return AuditEntry.from_row(dict(row))

    async def list_entries(
        self,
        operation_type: str | None = None,
        user_email: str | None = None,
        object_type: str | None = None,
        since_iso: str | None = None,
        limit: int = 50,
    ) -> list[AuditEntry]:
        """Filtered listing of audit_logs, newest first."""
        clauses: list[str] = []
        params: list[Any] = []
        if operation_type is not None:
            clauses.append("operation_type = ?")
            params.append(operation_type)
        if user_email is not None:
            clauses.append("user_email = ?")
            params.append(user_email)
        if object_type is not None:
            clauses.append("object_type = ?")
            params.append(object_type)
        if since_iso is not None:
            clauses.append("timestamp >= ?")
            params.append(since_iso)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        params.append(limit)

        async with self._conn() as conn:
            cursor = await conn.execute(
                f"SELECT * FROM audit_logs {where} ORDER BY timestamp DESC LIMIT ?",  # noqa: S608 — {where} built from hardcoded column names; all user values use ? placeholders
                tuple(params),
            )
            rows = await cursor.fetchall()
            return [AuditEntry.from_row(dict(r)) for r in rows]
