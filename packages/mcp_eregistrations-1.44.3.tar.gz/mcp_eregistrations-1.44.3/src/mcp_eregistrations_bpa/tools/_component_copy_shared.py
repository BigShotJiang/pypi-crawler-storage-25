"""Shared helpers for component_copy tools (issue #107).

Provides FK-handling rules, source-component fetch, cross-service alias
validation, key rewrite, and a property-level diff helper used by
component_diff. All copy tools compose the existing FormPatchEngine + adapters;
this module supplies the transforms that run before the patch is built.
"""

from __future__ import annotations

import re
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any, Literal

from fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.bpa_client.errors import (
    BPAClientError,
    BPANotFoundError,
    translate_error,
)
from mcp_eregistrations_bpa.patch.adapters.print_document import (
    PrintDocumentAdapter,
)
from mcp_eregistrations_bpa.patch.adapters.role_form import RoleFormAdapter
from mcp_eregistrations_bpa.patch.adapters.service_form import ServiceFormAdapter
from mcp_eregistrations_bpa.tools.formio_helpers import find_component

# ── FK field classification ──────────────────────────────────────────

# FK fields that are scoped to a single service (UUIDs valid only in that service).
SERVICE_SCOPED_FK_FIELDS: frozenset[str] = frozenset(
    {
        "registrations",
        "determinantIds",
        "behaviourId",
        "effectsIds",
        "componentActionId",
        "componentFormulaId",
        "componentValidationId",
        # Row-id arrays (BPA-backend JsonUtil#createFieldsToRemoveSet
        # confirms these as FK arrays). Each pairs with a parent FK above:
        # - formulaRowIds → ComponentFormulaId's FormulaRow children
        # - actionRowIds  → ComponentActionId's ActionRow children
        # - validationRowIds → ComponentValidationId's ValidationRow children
        # - blacklistRowIds  → ComponentValidationId's blacklist children
        # See ComponentFormulaStrategy.java / FormComponentActionsStrategy.java
        # / ComponentValidationStrategy.java in BPA-backend.
        "formulaRowIds",
        "actionRowIds",
        "validationRowIds",
        "blacklistRowIds",
    }
)

# FK fields that reference globally-scoped resources (safe to alias across services).
GLOBAL_FK_FIELDS: frozenset[str] = frozenset(
    {
        "classificationField",  # references global classification UUIDs
    }
)

KNOWN_FK_FIELDS: frozenset[str] = SERVICE_SCOPED_FK_FIELDS | GLOBAL_FK_FIELDS

# Canonical "strip" values per FK field. None means "drop the key entirely".
FK_STRIP_VALUE: dict[str, Any] = {
    "registrations": {},
    "determinantIds": [],
    "behaviourId": "",
    "effectsIds": [],
    "componentActionId": "",
    "componentFormulaId": "",
    "componentValidationId": "",
    "classificationField": None,  # drop the whole nested object
    # Row-id arrays — paired with their parent FK above (same handler dim).
    "formulaRowIds": [],
    "actionRowIds": [],
    "validationRowIds": [],
    "blacklistRowIds": [],
}


# ── Type aliases ─────────────────────────────────────────────────────

HandlingChoice = Literal["strip", "alias", "copy"]
CopyValueFromChoice = Literal["strip", "preserve"]
SourceType = Literal["form", "print_document", "role_form"]


# Match camelCase identifiers ending in "Id" or "Ids" — heuristic for FK fields.
_ID_FIELD_PATTERN = re.compile(r"^[a-z][a-zA-Z0-9]*Id[s]?$")


# ── HandlingPolicy ───────────────────────────────────────────────────


@dataclass
class HandlingPolicy:
    """Per-FK handling decisions plus cross-service flag and warnings.

    The dataclass is mutable: ``apply_fk_handling`` records unknown-FK
    warnings on the same instance the caller passed in.
    """

    behaviour: HandlingChoice = "strip"
    effect: HandlingChoice = "strip"
    determinant: HandlingChoice = "strip"
    component_action: HandlingChoice = "strip"
    component_formula: HandlingChoice = "strip"
    component_validation: HandlingChoice = "strip"
    classification: HandlingChoice = "alias"  # global, safe default
    copy_value_from: CopyValueFromChoice = "strip"
    cross_service: bool = False
    unknown_fk_warnings: list[str] = field(default_factory=list)
    # Collector for "copy" mode: drained by caller after dict transform to
    # issue post-copy upserts (e.g., recreate the source formula in the
    # destination service). Each entry: {source_formula_id, dest_component_key}.
    pending_formula_copies: list[dict[str, str]] = field(default_factory=list)

    def __post_init__(self) -> None:
        # Refuse "alias" for component_formula — would violate the
        # @UniqueConstraint(service_id, componentKey) backend constraint.
        if self.component_formula == "alias":
            raise ValueError(
                "component_formula='alias' is not supported: backend "
                "@UniqueConstraint(service_id, componentKey) prohibits "
                "sharing a single formula UUID across two components. Use "
                "'copy' (re-creates formula in destination) or 'strip'."
            )


# Map FK field name -> attribute name on HandlingPolicy.
# Row-id arrays use the same handler dimension as their parent FK so users
# don't need a separate per-row-array knob.
_FIELD_TO_HANDLER: dict[str, str] = {
    "behaviourId": "behaviour",
    "effectsIds": "effect",
    "determinantIds": "determinant",
    "componentActionId": "component_action",
    "actionRowIds": "component_action",
    "componentFormulaId": "component_formula",
    "formulaRowIds": "component_formula",
    "componentValidationId": "component_validation",
    "validationRowIds": "component_validation",
    "blacklistRowIds": "component_validation",
    "classificationField": "classification",
}


# ── apply_fk_handling ────────────────────────────────────────────────


def apply_fk_handling(
    component: dict[str, Any],
    policy: HandlingPolicy,
    *,
    deep: bool,
) -> tuple[dict[str, Any], list[str]]:
    """Apply FK handling to a component dict (returns a deep copy).

    Args:
        component: Source component dict (NOT mutated).
        policy: Per-FK handling decisions. May be mutated to record
            ``unknown_fk_warnings`` (cross-service unknowns).
        deep: If True, recurse into ``components`` / ``columns[].components`` /
            ``rows[][]`` containers and apply handling at every level.

    Returns:
        ``(transformed_component, stripped_field_log)``.
    """
    result = deepcopy(component)
    stripped_log: list[str] = []
    _transform_one(result, policy, stripped_log, deep=deep)
    return result, stripped_log


def _transform_one(
    comp: dict[str, Any],
    policy: HandlingPolicy,
    stripped_log: list[str],
    *,
    deep: bool,
) -> None:
    """Mutate ``comp`` in place: strip per policy, log unknown FKs, recurse."""
    # 1. Apply known FKs (excluding 'registrations' — handled separately below)
    for field_name in list(comp.keys()):
        if field_name not in _FIELD_TO_HANDLER:
            continue
        handler_attr = _FIELD_TO_HANDLER[field_name]
        choice: HandlingChoice = getattr(policy, handler_attr)
        if choice == "strip":
            strip_val = FK_STRIP_VALUE.get(field_name)
            if strip_val is None:
                comp.pop(field_name, None)
            else:
                comp[field_name] = deepcopy(strip_val)
            stripped_log.append(field_name)
        elif choice == "copy":
            # Only component_formula uses "copy" mode today. Capture source FK,
            # strip the field (caller will repopulate via post-copy upsert),
            # record a pending copy task on the policy. The other "copy"-able
            # FKs (action, validation) can be added later following same pattern.
            if (
                handler_attr == "component_formula"
                and field_name == "componentFormulaId"
            ):
                source_id = comp.get("componentFormulaId")
                if source_id:
                    policy.pending_formula_copies.append(
                        {
                            "source_formula_id": source_id,
                            "dest_component_key": comp.get("key", ""),
                        }
                    )
                comp[field_name] = ""
                stripped_log.append(field_name)
            elif handler_attr == "component_formula" and field_name == "formulaRowIds":
                comp[field_name] = []
                stripped_log.append(field_name)
            else:
                # "copy" not yet supported for this handler — fall back to strip
                strip_val = FK_STRIP_VALUE.get(field_name)
                if strip_val is None:
                    comp.pop(field_name, None)
                else:
                    comp[field_name] = deepcopy(strip_val)
                stripped_log.append(field_name)
        # alias: leave as-is

    # 2. Registrations: ALWAYS stripped (caller reauto-assigns from destination).
    if "registrations" in comp and comp["registrations"]:
        comp["registrations"] = {}
        stripped_log.append("registrations")

    # 3. copyValueFrom: separate handling
    if "copyValueFrom" in comp and policy.copy_value_from == "strip":
        if comp["copyValueFrom"]:
            comp["copyValueFrom"] = []
            stripped_log.append("copyValueFrom")

    # 4. Cross-service: warn for unknown *Id/*Ids fields not in KNOWN_FK_FIELDS.
    if policy.cross_service:
        for field_name in comp.keys():
            if (
                _ID_FIELD_PATTERN.match(field_name)
                and field_name not in KNOWN_FK_FIELDS
                and field_name not in policy.unknown_fk_warnings
            ):
                policy.unknown_fk_warnings.append(field_name)

    # 5. Recurse into children when deep=True
    if not deep:
        return

    for child_key in ("components", "columns", "rows"):
        children = comp.get(child_key)
        if not isinstance(children, list):
            continue
        if child_key == "components":
            for child in children:
                if isinstance(child, dict):
                    _transform_one(child, policy, stripped_log, deep=True)
        elif child_key == "columns":
            for col in children:
                if isinstance(col, dict):
                    inner = col.get("components", [])
                    if isinstance(inner, list):
                        for child in inner:
                            if isinstance(child, dict):
                                _transform_one(child, policy, stripped_log, deep=True)
        elif child_key == "rows":
            for row in children:
                if isinstance(row, list):
                    for cell in row:
                        if isinstance(cell, dict):
                            _transform_one(cell, policy, stripped_log, deep=True)


# ── fetch_source_component ───────────────────────────────────────────


async def fetch_source_component(
    *,
    client: Any,
    source_type: SourceType,
    source_id: str | int,
    source_key: str,
    source_form_type: str,
) -> tuple[dict[str, Any], str]:
    """Read a source component dict and return its owning service id.

    Args:
        client: Authenticated BPAClient.
        source_type: ``'form' | 'print_document' | 'role_form'``.
        source_id: Owning service id (form), document id (print_document), or
            role id (role_form).
        source_key: Component key to locate.
        source_form_type: Form type when ``source_type == 'form'``; ignored
            otherwise.

    Returns:
        ``(component_dict, source_service_id)``.

    Raises:
        ToolError: source artifact not found, or component key not present.
    """
    adapter: ServiceFormAdapter | PrintDocumentAdapter | RoleFormAdapter
    if source_type == "form":
        adapter = ServiceFormAdapter(client, source_id, form_type=source_form_type)
    elif source_type == "print_document":
        adapter = PrintDocumentAdapter(client)
    elif source_type == "role_form":
        adapter = RoleFormAdapter(client)
    else:
        raise ToolError(f"Unknown source_type: {source_type!r}")

    try:
        components = await adapter.fetch(str(source_id))
    except BPANotFoundError:
        raise ToolError(
            f"Source {source_type} '{source_id}' not found. "
            "Verify the id with the matching list/get tool."
        ) from None
    except BPAClientError as e:
        raise translate_error(
            e, resource_type=source_type, resource_id=source_id
        ) from e

    located = find_component(components, source_key)
    if located is None:
        raise ToolError(
            f"Source component '{source_key}' not found in "
            f"{source_type}={source_id}. Use the matching *_get tool to "
            "list available component keys."
        )
    component_dict, _path = located

    # Resolve source's parent service id.
    # Convention check (live-verified May 2026): the three adapter envelopes
    # do NOT echo their parent service. ServiceFormAdapter exposes
    # {active, formSchema, id, jsonDeterminants, partAForm, tutorials, type};
    # PrintDocumentAdapter exposes {active, businessKey, formSchema, formType,
    # id, isExternal, name, shortName, sortOrder, tutorials, uniqueName};
    # RoleFormAdapter has no `service` field either.
    #
    # However, for form sources the BPA URL is service-keyed
    # (`/service/{id}/applicant-form`), so source_id IS the service_id.
    # For print_document and role_form sources we have no cheap way to
    # recover the parent service from a single fetch, so we leave the
    # service_id empty — callers must guard cross-service detection
    # against empty values to avoid false positives.
    if source_type == "form":
        source_service_id = str(source_id)
    else:
        envelope = getattr(adapter, "envelope", None) or {}
        source_service_id = str(
            (envelope.get("service") or {}).get("id") or envelope.get("serviceId") or ""
        )
    return component_dict, source_service_id


# ── validate_aliased_fks ─────────────────────────────────────────────


async def validate_aliased_fks(
    *,
    client: Any,
    component: dict[str, Any],
    policy: HandlingPolicy,
    destination_service_id: str,
    source_service_id: str,
) -> list[dict[str, str]]:
    """Validate aliased FK IDs exist in the destination service.

    Only triggers when ``source_service_id != destination_service_id`` AND the
    relevant FK is set to ``alias``. Returns a list of error dicts; empty list
    means OK.

    Each error dict has keys: ``field``, ``id``, ``remediation``.

    NOTE: Currently validates ``behaviourId`` and ``determinantIds`` only —
    these are the most commonly aliased FKs. Other aliased FKs
    (``effectsIds``, ``componentActionId``, ``componentFormulaId``,
    ``componentValidationId``) are accepted without validation, with the
    boundary documented in each tool's docstring.
    """
    if source_service_id == destination_service_id:
        return []

    errors: list[dict[str, str]] = []

    # Behaviour
    if policy.behaviour == "alias":
        beh_id = component.get("behaviourId") or ""
        if beh_id:
            try:
                await client.get(
                    "/component_behaviour/{id}",
                    path_params={"id": beh_id},
                    resource_type="component_behaviour",
                    resource_id=beh_id,
                )
            except BPANotFoundError:
                errors.append(
                    {
                        "field": "behaviourId",
                        "id": beh_id,
                        "remediation": (
                            "set behaviour_handling='strip' or copy the "
                            f"behaviour to service {destination_service_id} first"
                        ),
                    }
                )

    # Determinants
    if policy.determinant == "alias":
        det_ids = component.get("determinantIds") or []
        if det_ids:
            try:
                dest_dets = await client.get_list(
                    "/service/{service_id}/determinant",
                    path_params={"service_id": destination_service_id},
                    resource_type="determinant",
                )
                dest_ids = {str(d.get("id")) for d in dest_dets}
                missing = [d for d in det_ids if str(d) not in dest_ids]
                if missing:
                    errors.append(
                        {
                            "field": "determinantIds",
                            "id": ",".join(str(m) for m in missing),
                            "remediation": (
                                "set determinant_handling='strip' or copy each "
                                "determinant to the destination service first"
                            ),
                        }
                    )
            except BPAClientError:
                errors.append(
                    {
                        "field": "determinantIds",
                        "id": ",".join(str(d) for d in det_ids),
                        "remediation": (
                            "could not list destination determinants; verify the "
                            "destination service exists and you are authenticated"
                        ),
                    }
                )

    return errors


# ── rewrite_top_level_key + compute_property_diff ────────────────────


def rewrite_top_level_key(component: dict[str, Any], new_key: str) -> dict[str, Any]:
    """Return a deep copy of ``component`` with its top-level ``key`` replaced.

    Descendant keys are preserved as-is. Caller is responsible for descendant
    collision detection against the destination tree (the patch engine raises
    on duplicates).
    """
    result = deepcopy(component)
    result["key"] = new_key
    return result


def compute_property_diff(
    source: dict[str, Any],
    target: dict[str, Any],
) -> dict[str, Any]:
    """Compute a property-level diff between two component dicts.

    Args:
        source: Component dict A.
        target: Component dict B.

    Returns:
        ``{equivalent: bool, differences: [{property, source_value, target_value}, ...],
        summary: str}``.
    """
    all_keys = set(source.keys()) | set(target.keys())
    differences: list[dict[str, Any]] = []
    for key in sorted(all_keys):
        sval_present = key in source
        tval_present = key in target
        sval = source.get(key) if sval_present else None
        tval = target.get(key) if tval_present else None
        if sval != tval:
            differences.append(
                {
                    "property": key,
                    "source_value": sval,
                    "target_value": tval,
                }
            )

    equivalent = len(differences) == 0
    summary = (
        "components are equivalent"
        if equivalent
        else f"{len(differences)} property difference(s)"
    )
    return {
        "equivalent": equivalent,
        "differences": differences,
        "summary": summary,
    }


# ── drain_pending_formula_copies ─────────────────────────────────────


async def drain_pending_formula_copies(
    client: Any,
    policy: HandlingPolicy,
    dest_service_id: str,
    on_orphan_determinant: str = "skip",
) -> dict[str, Any]:
    """Drain HandlingPolicy.pending_formula_copies — recreate formulas at destination.

    For each (source_formula_id, dest_component_key) pair recorded during the
    component dict-transform pass (Task 18), this helper:
    1. Fetches the source formula by ID via /componentformulas/{id} (service-
       agnostic single-formula GET).
    2. Translates determinant references in each row via _translate_row_determinants
       (Task 22 helper). Note: alias_map is currently empty — translation is a
       no-op pass-through under on_orphan='preserve'; under on_orphan='skip' any
       row with determinant references is dropped. Populating alias_map by
       querying destination determinants is future work.
    3. Upserts the translated rows under the destination service+component_key
       via PUT /service/{dest_service_id}/componentformulas/{component_key}.

    Args:
        client: An open BPAClient.
        policy: HandlingPolicy with pending_formula_copies populated.
        dest_service_id: Destination service UUID.
        on_orphan_determinant: One of "skip" (default), "preserve", "error".
            Passed through to _translate_row_determinants.

    Returns:
        dict with `formulas_copied` (int), `formulas_skipped` (int — source
        404 between dict-transform and drainage), `rows_dropped_orphan` (int),
        `pending_count` (int — total drained).

    Note:
        Errors from the destination PUT propagate (caller handles audit
        lifecycle). BPANotFoundError on source-formula GET is swallowed
        (idempotent: source deleted between transform and drainage means the
        destination component should have no formula, consistent with strip
        mode).
    """
    from mcp_eregistrations_bpa.bpa_client.errors import (
        BPANotFoundError as _BPANotFoundError,
    )
    from mcp_eregistrations_bpa.tools.component_formulas import (
        _to_backend_row,
        _translate_row_determinants,
    )

    formulas_copied = 0
    formulas_skipped = 0
    rows_dropped_orphan = 0
    pending_count = len(policy.pending_formula_copies)
    # TODO: build alias_map by querying destination determinants. For now,
    # empty alias_map means every cross-service determinant ref is an orphan;
    # on_orphan_determinant controls how those are handled.
    alias_map: dict[str, str] = {}

    for pending in policy.pending_formula_copies:
        source_formula_id = pending["source_formula_id"]
        dest_component_key = pending["dest_component_key"]
        if not dest_component_key:
            # Defensive: dict-transform should always set this; skip if missing.
            formulas_skipped += 1
            continue

        # Fetch source formula (service-agnostic single-id endpoint)
        try:
            source_formula = await client.get(
                "/componentformulas/{id}",
                path_params={"id": source_formula_id},
                resource_type="component_formula",
                resource_id=source_formula_id,
            )
        except _BPANotFoundError:
            # Source vanished between dict-transform and drainage — skip.
            formulas_skipped += 1
            continue

        # Translate each row, applying the on_orphan policy
        rows_to_copy: list[dict[str, Any]] = []
        for raw_row in source_formula.get("formulaRows") or []:
            snake_row = {
                "json_determinants": raw_row.get("jsonDeterminants"),
                "infix": raw_row.get("infix"),
                "pretty_print_infix_formula": raw_row.get("prettyPrintInfixFormula"),
                "json_logic": raw_row.get("jsonLogic"),
                "meta": raw_row.get("meta"),
                "sort_order": raw_row.get("sortOrder"),
            }
            translated, orphans = _translate_row_determinants(
                snake_row,
                alias_map,
                on_orphan=on_orphan_determinant,
            )
            if translated is None:
                rows_dropped_orphan += 1
                continue
            rows_to_copy.append(translated)

        if not rows_to_copy:
            # All rows dropped (or source had none). Skip the destination PUT.
            formulas_skipped += 1
            continue

        # Upsert in destination
        body = {
            "componentKey": dest_component_key,
            "formulaRows": [_to_backend_row(r) for r in rows_to_copy],
        }
        await client.put(
            "/service/{service_id}/componentformulas/{component_key}",
            path_params={
                "service_id": dest_service_id,
                "component_key": dest_component_key,
            },
            json=body,
            resource_type="component_formula",
            resource_id=f"{dest_service_id}/{dest_component_key}",
        )
        formulas_copied += 1

    return {
        "pending_count": pending_count,
        "formulas_copied": formulas_copied,
        "formulas_skipped": formulas_skipped,
        "rows_dropped_orphan": rows_dropped_orphan,
    }
