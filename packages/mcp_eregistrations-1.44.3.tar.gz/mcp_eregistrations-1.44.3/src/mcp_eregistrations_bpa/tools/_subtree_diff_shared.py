"""Subtree-aware diff helpers for subtree_diff tool (issue #118).

Walks two Form.io subtrees, builds {key: component_dict} maps for each,
and produces a per-key diff using the existing leaf-comparator
``compute_property_diff`` from ``_component_copy_shared``.

CONTRACT ASSUMPTION (v1):
    ``compute_property_diff`` (_component_copy_shared.py:424) does NOT
    recurse into the children-bearing fields ``components`` / ``columns``
    / ``tabs`` / ``rows``. This module strips those fields before per-node
    comparison so structural deltas surface only via the walker, never as
    opaque blobs. If that contract changes, this module must be revisited.

Container traversal mirrors ``find_component`` (formio_helpers.py:175):
``components[]``, ``columns[].components[]``, ``tabs[].components[]``,
``rows[][].components[]``. It does NOT mirror ``apply_fk_handling``'s
walker (_component_copy_shared.py:211), which omits ``tabs`` —
pre-existing latent bug, out of scope here.
"""

from __future__ import annotations

from typing import Any

from mcp_eregistrations_bpa.tools.formio_helpers import MAX_RECURSION_DEPTH

__all__ = [
    "collect_keyed_descendants",
    "compute_subtree_diff",
]

# Children-bearing fields excluded from per-node property diff (single source of truth).
_CHILDREN_FIELDS: frozenset[str] = frozenset({"components", "columns", "tabs", "rows"})


def collect_keyed_descendants(
    component: dict[str, Any],
) -> tuple[dict[str, dict[str, Any]], list[str]]:
    """Walk a Form.io subtree and return ``({key: component}, warnings)``.

    Includes the root component itself in the key map (if it has a key).
    Container traversal mirrors ``find_component``: ``components[]``,
    ``columns[].components[]``, ``tabs[].components[]``,
    ``rows[][].components[]``.

    Args:
        component: Root component of the subtree to walk.

    Returns:
        Tuple ``(key_map, warnings)`` where ``key_map`` is
        ``{component_key: component_dict}`` (first-match-wins on duplicates)
        and ``warnings`` is a list of human-readable strings (DUPLICATE_KEY
        and UNKNOWN_CONTAINER_FIELD codes).

    Raises:
        RecursionError: If subtree depth exceeds ``MAX_RECURSION_DEPTH``.
    """
    key_map: dict[str, dict[str, Any]] = {}
    warnings: list[str] = []
    _walk(component, key_map, warnings, _depth=0)
    return key_map, warnings


def _walk(
    component: Any,
    key_map: dict[str, dict[str, Any]],
    warnings: list[str],
    *,
    _depth: int,
) -> None:
    if _depth > MAX_RECURSION_DEPTH:
        raise RecursionError(
            f"Component tree exceeds maximum depth of {MAX_RECURSION_DEPTH}"
        )
    if not isinstance(component, dict):
        return

    # Record this node (first-match-wins on duplicates).
    key = component.get("key")
    if isinstance(key, str) and key:
        if key in key_map:
            # SPEC F1 — duplicate key surfaces as a warning; first-match wins.
            warnings.append(
                f"DUPLICATE_KEY: '{key}' appears more than once; first occurrence kept."
            )
        else:
            key_map[key] = component

    # Direct components[] children.
    nested = component.get("components")
    if isinstance(nested, list):
        for child in nested:
            _walk(child, key_map, warnings, _depth=_depth + 1)

    # columns[].components[] children.
    columns = component.get("columns")
    if isinstance(columns, list):
        for col in columns:
            if isinstance(col, dict):
                col_components = col.get("components")
                if isinstance(col_components, list):
                    for child in col_components:
                        _walk(child, key_map, warnings, _depth=_depth + 1)

    # tabs[].components[] children.
    tabs = component.get("tabs")
    if isinstance(tabs, list):
        for tab in tabs:
            if isinstance(tab, dict):
                tab_components = tab.get("components")
                if isinstance(tab_components, list):
                    for child in tab_components:
                        _walk(child, key_map, warnings, _depth=_depth + 1)

    # rows[][].components[] children (table shape).
    rows = component.get("rows")
    if isinstance(rows, list):
        for row in rows:
            if isinstance(row, list):
                for cell in row:
                    if isinstance(cell, dict):
                        cell_components = cell.get("components")
                        if isinstance(cell_components, list):
                            for child in cell_components:
                                _walk(child, key_map, warnings, _depth=_depth + 1)

    # SPEC F4 — Forward-compat: detect unknown ``list[dict]`` fields whose
    # elements carry a ``components`` list. These look like containers we
    # don't recognize, so flag them so the diff doesn't silently drop
    # descendants when Form.io adds new container shapes.
    for field_name, field_value in component.items():
        if (
            field_name in _CHILDREN_FIELDS
            or field_name in _IGNORED_FIELDS_FOR_CONTAINER_HEURISTIC
        ):
            continue
        if not isinstance(field_value, list) or not field_value:
            continue
        if all(
            isinstance(elem, dict) and isinstance(elem.get("components"), list)
            for elem in field_value
        ):
            warnings.append(
                f"UNKNOWN_CONTAINER_FIELD: field '{field_name}' contains "
                "components-bearing entries but is not in the known container set "
                f"{sorted(_CHILDREN_FIELDS)}; descendants are not walked."
            )


# Top-level fields that look like list[dict] but are NOT containers. Kept
# narrow on purpose: only fields known to live alongside ``components`` in
# real BPA exports.
_IGNORED_FIELDS_FOR_CONTAINER_HEURISTIC: frozenset[str] = frozenset(
    {
        # Form.io select/radio "values" — list of {label,value} dicts that
        # never carry components but match the same shape heuristic if a
        # caller hand-builds them oddly. Defensive only.
        "values",
        "data",
    }
)


def _strip_children_fields(component: dict[str, Any]) -> dict[str, Any]:
    """Return a shallow copy of ``component`` with children fields removed.

    Children fields are walked structurally by ``collect_keyed_descendants``,
    so per-node property comparisons must omit them — otherwise structural
    deltas leak into the per-node diff as opaque blobs (the very gap
    ``component_diff`` had that motivates this tool).
    """
    return {k: v for k, v in component.items() if k not in _CHILDREN_FIELDS}


def compute_subtree_diff(
    source: dict[str, Any],
    target: dict[str, Any],
) -> dict[str, Any]:
    """Per-key structural + property diff between two Form.io subtrees.

    Walks both subtrees, builds ``{key: component}`` maps, then for each
    shared key runs ``compute_property_diff`` on the children-stripped
    components. Keys present on only one side land in
    ``missing_in_target`` / ``missing_in_source``.

    Returns:
        dict with:
            - equivalent: bool — True iff no missing keys and no shared-key
              property differences.
            - missing_in_target: list[str] — keys in source but not target.
            - missing_in_source: list[str] — keys in target but not source.
            - property_diffs: dict[str, {differences: [...], summary: str}]
              — per-shared-key property delta (no ``equivalent`` echoed; L4).
            - summary: str — locked format (L2).
            - node_count: {source: int, target: int} — node tally per side
              (L3, always >= 1).
            - warnings: list[str] — side-tagged DUPLICATE_KEY /
              UNKNOWN_CONTAINER_FIELD entries.
    """
    # Local import to keep module-import cost low and avoid circulars.
    from mcp_eregistrations_bpa.tools._component_copy_shared import (
        compute_property_diff,
    )

    src_map, src_warnings = collect_keyed_descendants(source)
    tgt_map, tgt_warnings = collect_keyed_descendants(target)

    src_keys = set(src_map.keys())
    tgt_keys = set(tgt_map.keys())

    missing_in_target = sorted(src_keys - tgt_keys)
    missing_in_source = sorted(tgt_keys - src_keys)

    property_diffs: dict[str, dict[str, Any]] = {}
    for key in sorted(src_keys & tgt_keys):
        src_node = _strip_children_fields(src_map[key])
        tgt_node = _strip_children_fields(tgt_map[key])

        # SPEC F3 — type mismatch short-circuit. Two components with the
        # same key but different ``type`` are functionally different
        # widgets; enumerating per-property deltas is misleading noise.
        # Surface a compact entry instead.
        src_type = src_node.get("type")
        tgt_type = tgt_node.get("type")
        if src_type != tgt_type:
            property_diffs[key] = {
                "type_mismatch": True,
                "source_type": src_type,
                "target_type": tgt_type,
                "summary": (f"type mismatch: {src_type!r} vs {tgt_type!r}"),
            }
            continue

        per_diff = compute_property_diff(src_node, tgt_node)
        if not per_diff["equivalent"]:
            # SPEC L4: do NOT echo ``equivalent`` inside the per-key entry.
            property_diffs[key] = {
                "differences": per_diff["differences"],
                "summary": per_diff["summary"],
            }

    equivalent = not missing_in_target and not missing_in_source and not property_diffs

    if equivalent:
        summary = "subtrees are equivalent"
    else:
        summary = (
            f"{len(missing_in_target)} missing in target, "
            f"{len(missing_in_source)} missing in source, "
            f"{len(property_diffs)} property diff(s)"
        )

    warnings = [f"source: {w}" for w in src_warnings] + [
        f"target: {w}" for w in tgt_warnings
    ]

    return {
        "equivalent": equivalent,
        "missing_in_target": missing_in_target,
        "missing_in_source": missing_in_source,
        "property_diffs": property_diffs,
        "summary": summary,
        "node_count": {"source": len(src_map), "target": len(tgt_map)},
        "warnings": warnings,
    }
