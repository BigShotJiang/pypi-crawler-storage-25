"""MCP tools for editing role forms via the FormPatchEngine.

These tools provide structured, diff-aware editing of Form.io schemas
embedded in BPA roles.  They wrap the generic ``FormPatchEngine`` with the
``RoleFormAdapter`` so callers work at the *role* level rather than
manipulating raw JSON.

Write operations follow the audit-before-write pattern:
1. Auth check
2. Fetch role via RoleFormAdapter
3. Apply operations via FormPatchEngine
4. Audit (pending -> success/failed)
5. Save modified tree back via adapter

NOTE: patch.* imports are deferred to function bodies to avoid a circular
import.  Chain: tools/__init__ -> role_forms -> patch.engine -> patch.diff
-> tools.formio_helpers -> (triggers tools/__init__ again).
"""

from __future__ import annotations

from copy import deepcopy
from typing import TYPE_CHECKING, Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.audit.context import (
    NotAuthenticatedError,
    get_current_user_email,
)
from mcp_eregistrations_bpa.audit.logger import AuditLogger
from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import (
    BPAClientError,
    translate_error,
)
from mcp_eregistrations_bpa.config import resolve_db_path

if TYPE_CHECKING:
    from mcp_eregistrations_bpa.patch.engine import PatchResult
    from mcp_eregistrations_bpa.patch.operations import Operation

__all__ = [
    "role_form_component_update",
    "role_form_component_add",
    "role_form_component_remove",
    "role_form_patch",
    "register_role_form_tools",
]


# ── Internal helpers ──────────────────────────────────────────────


def _diff_to_dict(result: PatchResult) -> dict[str, Any]:
    """Serialize a PatchResult.diff into a JSON-friendly dict."""
    return result.diff.to_dict()


async def _execute_patch(
    role_id: str | int,
    operations: list[Operation],
    *,
    instance: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Core patch execution shared by all role_form_* tools.

    1. Auth check
    2. Fetch role via RoleFormAdapter
    3. Apply operations via FormPatchEngine
    4. If dry_run: return diff without PUT
    5. Audit-before-write: record pending, save rollback state
    6. Save modified tree
    7. Mark audit success/failed
    """
    # Deferred imports to break circular dependency
    from mcp_eregistrations_bpa.patch.adapters.role_form import RoleFormAdapter
    from mcp_eregistrations_bpa.patch.engine import FormPatchEngine

    # 1. Auth
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            # 2. Fetch
            adapter = RoleFormAdapter(client)
            try:
                components = await adapter.fetch(str(role_id))
            except BPAClientError as e:
                raise translate_error(e, resource_type="role") from e

            # 3. Apply patch
            engine = FormPatchEngine()
            result = engine.apply(components, operations, dry_run=dry_run)

            if not result.success:
                raise ToolError(f"Patch failed: {'; '.join(result.errors)}")

            diff_dict = _diff_to_dict(result)

            # 4. Dry run — return diff only
            if dry_run:
                return {
                    "success": True,
                    "dry_run": True,
                    "role_id": str(role_id),
                    "diff": diff_dict,
                }

            # 5. Audit-before-write
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type="role_form",
                object_id=str(role_id),
                params={
                    "operations_count": len(operations),
                    "diff_summary": diff_dict["summary"],
                },
            )

            # Save rollback state (previous form envelope)
            previous_state = deepcopy(adapter.envelope) or {}
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="role",
                object_id=str(role_id),
                previous_state=previous_state,
            )

            # 6. Save modified tree
            try:
                assert result.modified_tree is not None
                await adapter.save(result.modified_tree)

                # 7a. Mark success
                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "role_id": str(role_id),
                        "diff_summary": diff_dict["summary"],
                    },
                )

                return {
                    "success": True,
                    "dry_run": False,
                    "role_id": str(role_id),
                    "diff": diff_dict,
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                # 7b. Mark failed
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="role") from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="role") from e


# ── MCP tools ────────────────────────────────────────────────────


async def role_form_component_update(
    role_id: str | int,
    component_key: str,
    properties: dict[str, Any],
    instance: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Update a component's properties in a role form. Audited write operation.

    Args:
        role_id: Role ID.
        component_key: Key of the component to modify.
        properties: Properties to set (e.g. {"label": "First Name"}).
        instance: Instance profile name (from instance_list).
        dry_run: Preview changes without saving (default: False).

    Returns:
        dict with success, diff, role_id, audit_id.
    """
    from mcp_eregistrations_bpa.patch.operations import (
        Operation,
        OperationType,
    )

    if not properties:
        raise ToolError(
            "No properties provided. Pass a dict of properties to update "
            '(e.g. properties={"label": "First Name"}).'
        )

    op = Operation(
        op=OperationType.SET,
        key=component_key,
        properties=dict(properties),
    )
    return await _execute_patch(role_id, [op], instance=instance, dry_run=dry_run)


async def role_form_component_add(
    role_id: str | int,
    component: dict[str, Any],
    parent_key: str | None = None,
    position: int | None = None,
    instance: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Add a component to a role form. Audited write operation.

    Args:
        role_id: Role ID.
        component: Form.io component dict (must include key and type).
        parent_key: Insert inside this container (default: root).
        position: Zero-based insertion index (default: append).
        instance: Instance profile name (from instance_list).
        dry_run: Preview changes without saving (default: False).

    Returns:
        dict with success, diff, role_id, audit_id.
    """
    from mcp_eregistrations_bpa.patch.operations import (
        Operation,
        OperationType,
    )

    op = Operation(
        op=OperationType.ADD,
        component=component,
        parent_key=parent_key,
        position=position,
    )
    return await _execute_patch(role_id, [op], instance=instance, dry_run=dry_run)


async def role_form_component_remove(
    role_id: str | int,
    component_key: str,
    instance: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Remove a component from a role form. Audited write operation.

    Args:
        role_id: Role ID.
        component_key: Key of the component to remove.
        instance: Instance profile name (from instance_list).
        dry_run: Preview changes without saving (default: False).

    Returns:
        dict with success, diff, role_id, audit_id.
    """
    from mcp_eregistrations_bpa.patch.operations import (
        Operation,
        OperationType,
    )

    op = Operation(op=OperationType.REMOVE, key=component_key)
    return await _execute_patch(role_id, [op], instance=instance, dry_run=dry_run)


async def role_form_patch(
    role_id: str | int,
    operations: list[dict[str, Any]],
    instance: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Apply a batch of patch operations to a role form. Audited write operation.

    Args:
        role_id: Role ID.
        operations: List of operation dicts (each must have 'op' key).
        instance: Instance profile name (from instance_list).
        dry_run: Preview changes without saving (default: False).

    Returns:
        dict with success, diff, role_id, operations_count, audit_id.
    """
    from mcp_eregistrations_bpa.patch.operations import Operation

    if not operations:
        raise ToolError("No operations provided.")

    ops = [Operation.from_dict(d) for d in operations]
    result = await _execute_patch(role_id, ops, instance=instance, dry_run=dry_run)
    result["operations_count"] = len(ops)
    return result


# ── Component copy (issue #107) ──────────────────────────────────


from mcp_eregistrations_bpa.patch.adapters.role_form import (  # noqa: E402
    RoleFormAdapter,
)
from mcp_eregistrations_bpa.patch.engine import FormPatchEngine  # noqa: E402


async def role_form_component_copy(
    role_id: str | int,
    source_type: str,
    source_id: str | int,
    source_key: str,
    new_key: str,
    *,
    source_form_type: str = "applicant",
    parent_key: str | None = None,
    position: int | None = None,
    deep: bool = True,
    fk_handling: str | None = None,
    behaviour_handling: str | None = None,
    effect_handling: str | None = None,
    determinant_handling: str | None = None,
    component_action_handling: str | None = None,
    component_formula_handling: str | None = None,
    component_validation_handling: str | None = None,
    classification_handling: str | None = None,
    copy_value_from_handling: str = "strip",
    on_orphan_determinant: str = "skip",
    instance: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Copy a component from any artifact into this role form. Audited write.

    See form_component_copy for FK-handling semantics. Differences for role_form:
    no column_index/row_index/cell_index parameters (mirrors role_form_component_add
    asymmetry); audit object_type='role_form_component_copy'.

    Args:
        role_id: Destination role ID.
        source_type: 'form' | 'print_document' | 'role_form'.
        source_id: Source artifact id.
        source_key: Source component key.
        new_key: Destination component key (must be unique).
        source_form_type, parent_key, position, deep, fk_handling, *_handling,
        copy_value_from_handling, instance, dry_run: see form_component_copy.
        on_orphan_determinant: Policy for formula rows referencing determinants
            not in the destination service alias map: 'skip' (default, drops
            the row), 'preserve' (keeps orphan refs as-is), or 'error' (raises
            ToolError on first orphan). Only relevant when
            component_formula_handling='copy'.

    Returns:
        dict with copied, dry_run, role_id, source, destination,
        stripped_fields, validation_warnings, verification, diff, audit_id
        (audit_id omitted when dry_run=True), and optionally formula_drainage
        (when component_formula_handling='copy').
    """
    from copy import deepcopy as _deepcopy

    from mcp_eregistrations_bpa.patch.operations import Operation, OperationType
    from mcp_eregistrations_bpa.tools._component_copy_shared import (
        HandlingPolicy,
        apply_fk_handling,
        fetch_source_component,
        rewrite_top_level_key,
        validate_aliased_fks,
    )
    from mcp_eregistrations_bpa.tools.formio_helpers import find_component

    def _resolve(per_field: str | None, default: str) -> str:
        if per_field is not None:
            return per_field
        if fk_handling is not None:
            return fk_handling
        return default

    policy = HandlingPolicy(
        behaviour=_resolve(behaviour_handling, "strip"),  # type: ignore[arg-type]
        effect=_resolve(effect_handling, "strip"),  # type: ignore[arg-type]
        determinant=_resolve(determinant_handling, "strip"),  # type: ignore[arg-type]
        component_action=_resolve(component_action_handling, "strip"),  # type: ignore[arg-type]
        component_formula=_resolve(component_formula_handling, "strip"),  # type: ignore[arg-type]
        component_validation=_resolve(component_validation_handling, "strip"),  # type: ignore[arg-type]
        classification=_resolve(classification_handling, "alias"),  # type: ignore[arg-type]
        copy_value_from=copy_value_from_handling,  # type: ignore[arg-type]
    )

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    if (
        str(source_id) == str(role_id)
        and source_type == "role_form"
        and source_key == new_key
    ):
        raise ToolError("Source and destination identical — pick a different new_key.")

    audit_id: str | None = None

    try:
        async with BPAClient.for_instance(instance) as client:
            source_component, source_service_id = await fetch_source_component(
                client=client,
                source_type=source_type,  # type: ignore[arg-type]
                source_id=source_id,
                source_key=source_key,
                source_form_type=source_form_type,
            )

            adapter = RoleFormAdapter(client)
            try:
                components = await adapter.fetch(str(role_id))
            except BPAClientError as e:
                raise translate_error(e, resource_type="role") from e
            destination_envelope = adapter.envelope or {}
            destination_service_id = str(
                (destination_envelope.get("service") or {}).get("id")
                or destination_envelope.get("serviceId")
                or ""
            )

            # Only treat as cross-service when source_service_id is known
            # (see forms.py:form_component_copy for full rationale).
            policy.cross_service = bool(source_service_id) and (
                source_service_id != destination_service_id
            )

            transformed, stripped_fields = apply_fk_handling(
                source_component, policy, deep=deep
            )

            if not deep:
                for child_key in ("components", "columns", "rows"):
                    transformed.pop(child_key, None)

            validation_errors = await validate_aliased_fks(
                client=client,
                component=transformed,
                policy=policy,
                destination_service_id=destination_service_id,
                source_service_id=source_service_id,
            )
            if validation_errors:
                msg_lines = [
                    f"  - {e['field']}={e['id']}: {e['remediation']}"
                    for e in validation_errors
                ]
                raise ToolError(
                    "Cross-service alias validation failed for the following "
                    "FK fields. Either set the corresponding *_handling param "
                    "to 'strip', or copy the referenced records first:\n"
                    + "\n".join(msg_lines)
                )

            transformed = rewrite_top_level_key(transformed, new_key)

            op = Operation(
                op=OperationType.ADD,
                component=transformed,
                parent_key=parent_key,
                position=position,
            )

            engine = FormPatchEngine()
            result = engine.apply(components, [op], dry_run=dry_run)
            if not result.success:
                raise ToolError(f"Patch failed: {'; '.join(result.errors)}")

            diff_dict = result.diff.to_dict()

            if dry_run:
                return {
                    "copied": True,
                    "dry_run": True,
                    "role_id": str(role_id),
                    "source": {
                        "type": source_type,
                        "id": str(source_id),
                        "key": source_key,
                        "service_id": source_service_id,
                    },
                    "destination": {
                        "role_id": str(role_id),
                        "service_id": destination_service_id,
                        "parent_key": parent_key,
                        "position": position,
                        "key": new_key,
                    },
                    "stripped_fields": stripped_fields,
                    "validation_warnings": _deepcopy(policy.unknown_fk_warnings),
                    "diff": diff_dict,
                }

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="create",
                object_type="role_form_component_copy",
                params={
                    "role_id": str(role_id),
                    "source_type": source_type,
                    "source_id": str(source_id),
                    "source_key": source_key,
                    "new_key": new_key,
                    "stripped_fields": stripped_fields,
                },
            )
            previous_state = _deepcopy(adapter.envelope) or {}
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="role",
                object_id=str(role_id),
                previous_state=previous_state,
            )

            try:
                assert result.modified_tree is not None
                await adapter.save(result.modified_tree)
                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "role_id": str(role_id),
                        "new_key": new_key,
                        "diff_summary": diff_dict.get("summary", {}),
                    },
                )
            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="role") from e

            verification = "ok"
            verification_issues: list[str] = []
            try:
                final_components = await adapter.fetch(str(role_id))
                if find_component(final_components, new_key) is None:
                    verification = "partial_failure"
                    verification_issues.append(
                        f"component '{new_key}' not present after write"
                    )
            except BPAClientError:
                verification = "partial_failure"
                verification_issues.append("post-write fetch failed")

            # Drain pending formula copies (component_formula_handling='copy')
            drainage_summary: dict[str, Any] | None = None
            if policy.pending_formula_copies:
                from mcp_eregistrations_bpa.tools._component_copy_shared import (
                    drain_pending_formula_copies,
                )

                drainage_summary = await drain_pending_formula_copies(
                    client=client,
                    policy=policy,
                    dest_service_id=destination_service_id,
                    on_orphan_determinant=on_orphan_determinant,
                )

            out: dict[str, Any] = {
                "copied": True,
                "dry_run": False,
                "role_id": str(role_id),
                "source": {
                    "type": source_type,
                    "id": str(source_id),
                    "key": source_key,
                    "service_id": source_service_id,
                },
                "destination": {
                    "role_id": str(role_id),
                    "service_id": destination_service_id,
                    "parent_key": parent_key,
                    "position": position,
                    "key": new_key,
                },
                "stripped_fields": stripped_fields,
                "validation_warnings": _deepcopy(policy.unknown_fk_warnings),
                "verification": verification,
                "verification_issues": verification_issues,
                "diff": diff_dict,
                "audit_id": audit_id,
            }
            if drainage_summary is not None:
                out["formula_drainage"] = drainage_summary
            return out

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="role") from e


# ── Registration ─────────────────────────────────────────────────


def register_role_form_tools(mcp: Any) -> None:
    """Register role form tools with the MCP server.

    Args:
        mcp: The FastMCP server instance.
    """
    from mcp_eregistrations_bpa.tools.annotations import WRITE

    mcp.tool(annotations=WRITE)(role_form_component_update)
    mcp.tool(annotations=WRITE)(role_form_component_add)
    mcp.tool(annotations=WRITE)(role_form_component_remove)
    mcp.tool(annotations=WRITE)(role_form_component_copy)
    mcp.tool(annotations=WRITE)(role_form_patch)
