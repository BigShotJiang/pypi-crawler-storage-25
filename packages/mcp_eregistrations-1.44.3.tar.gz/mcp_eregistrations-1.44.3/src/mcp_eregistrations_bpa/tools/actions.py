"""Component action tools for BPA API.

This module provides MCP tools for managing component actions
in the BPA API. Component actions link bots to form components,
enabling workflow automation (e.g., button triggers bot execution).

Tools:
    componentaction_get: Get component actions by ID
    componentaction_get_by_component: Get actions for a form component
    componentaction_get_system_actions: List built-in system button actions
    componentaction_list_by_service: List every component action in a service
    componentaction_save: Create/replace component actions (audited)
    componentaction_update: Update component actions by ID (audited)
    componentaction_delete: Remove component actions (audited)
    componentaction_delete_by_bot: Batch-remove bot references service-wide (audited)
"""

from __future__ import annotations

import asyncio
import logging
import re
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.audit.context import (
    NotAuthenticatedError,
    get_current_user_email,
)
from mcp_eregistrations_bpa.audit.logger import AuditLogger
from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import (
    BPAClientError,
    BPANotFoundError,
    translate_error,
)
from mcp_eregistrations_bpa.config import resolve_db_path
from mcp_eregistrations_bpa.tools._determinant_shared import build_determinant_refs
from mcp_eregistrations_bpa.tools._form_shared import (
    parse_form_schema,
    simplify_components,
)
from mcp_eregistrations_bpa.tools.formio_helpers import find_component
from mcp_eregistrations_bpa.tools.forms import FORM_TYPES

logger = logging.getLogger(__name__)

# UUID pattern for distinguishing real bot IDs from system bot names
_UUID_PATTERN = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE
)

# System action categories derived from CustomButtonAction.java
_SYSTEM_ACTION_CATEGORIES: dict[str, str] = {
    # Applicant (PartA) actions
    "saveData": "applicant",
    "saveA5": "applicant",
    "saveSENDPAGE": "applicant",
    "savePAYMENTPAGE": "applicant",
    "saveDOCUMENT": "applicant",
    "start_kyc": "applicant",
    "saveA3": "applicant",
    "saveA4": "applicant",
    "saveB3": "applicant",
    # Processing (PartB) actions
    "fileValidated": "processing",
    "fileDecline": "processing",
    "fileReject": "processing",
    "cancelFile": "processing",
    "saveSendBackPage": "processing",
    "assignFile": "processing",
    # Print actions
    "printApplicantGuide": "print",
    "printApplicantFile": "print",
    "printEntirePartAButton": "print",
    # Navigation actions
    "goToNextPage": "navigation",
    "goToPreviousPage": "navigation",
    "validateCurrentTab": "navigation",
}

__all__ = [
    "componentaction_get",
    "componentaction_get_by_component",
    "componentaction_get_system_actions",
    "componentaction_list_by_service",
    "componentaction_save",
    "componentaction_update",
    "componentaction_delete",
    "componentaction_delete_by_bot",
    "register_action_tools",
]


async def componentaction_get(id: str, instance: str | None = None) -> dict[str, Any]:
    """Get component actions by ID.

    Args:
        id: The unique identifier of the component actions record.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, service_id, component_key, actions.
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                data = await client.get(
                    "/componentactions/{id}",
                    path_params={"id": id},
                    resource_type="componentactions",
                    resource_id=id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"ComponentActions '{id}' not found. Verify the ID is correct."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="componentactions", resource_id=id
        ) from e

    return _transform_component_actions(data)


async def componentaction_get_by_component(
    service_id: str | int, component_key: str, instance: str | None = None
) -> dict[str, Any]:
    """Get component actions for a specific form component.

    Args:
        service_id: The service containing the component.
        component_key: The form component key/identifier.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, service_id, component_key, actions.
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                data = await client.get(
                    "/service/{service_id}/componentactions/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="componentactions",
                )
            except BPANotFoundError:
                raise ToolError(
                    f"No actions found for component '{component_key}' "
                    f"in service '{service_id}'."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="componentactions") from e

    return _transform_component_actions(data)


_ACTION_FETCH_BATCH = 10


async def componentaction_list_by_service(
    service_id: str | int,
    instance: str | None = None,
    bot_id: str | None = None,
    form_types: list[str] | None = None,
) -> dict[str, Any]:
    """List every component action in a service across form types.

    Walks each form schema for the service, collects componentActionId
    references, and aggregates the underlying ComponentActions records.
    No backend endpoint provides this list; aggregation is client-side.

    The bot_id filter matches only LIVE bot references. After a bot is
    deleted, the BPA backend silently drops the reference from the
    serialized actions (botIdArray is @JsonIgnored). The filter cannot
    locate orphaned references to deleted bots — use the dedicated
    cleanup workflow for that.

    Args:
        service_id: Service to scan.
        instance: Instance profile name (from instance_list).
        bot_id: Optional filter — keep only items where any live bot
            reference matches this id.
        form_types: Subset of form types to scan (default: all four —
            applicant, guide, send_file, payment).

    Returns:
        dict with service_id, total, items, warnings.
    """
    selected_types = list(FORM_TYPES.keys()) if form_types is None else list(form_types)

    invalid = [ft for ft in selected_types if ft not in FORM_TYPES]
    if invalid:
        valid = ", ".join(sorted(FORM_TYPES.keys()))
        raise ToolError(f"Invalid form_type(s): {invalid}. Valid: {valid}.")

    warnings_list: list[dict[str, Any]] = []
    discovered: list[tuple[str, str, str]] = []  # (component_key, action_id, form_type)

    try:
        async with BPAClient.for_instance(instance) as client:
            for ft in selected_types:
                config = FORM_TYPES[ft]
                try:
                    form_data = await client.get(
                        config["get_endpoint"],
                        path_params={"id": service_id},
                        params={"reusable": "false"},
                        resource_type="form",
                        resource_id=f"{service_id}/{ft}",
                    )
                except BPANotFoundError:
                    warnings_list.append(
                        {
                            "form_type": ft,
                            "reason": "form not configured for this service",
                        }
                    )
                    continue

                schema = parse_form_schema(form_data)
                walked = simplify_components(schema.get("components", []))
                for entry in walked:
                    action_id = entry.get("component_action_id")
                    key = entry.get("key")
                    if action_id and key:
                        discovered.append((key, action_id, ft))

            seen_ids: set[str] = set()
            unique: list[tuple[str, str, str]] = []
            for triple in discovered:
                if triple[1] not in seen_ids:
                    seen_ids.add(triple[1])
                    unique.append(triple)

            items: list[dict[str, Any]] = []
            for batch_start in range(0, len(unique), _ACTION_FETCH_BATCH):
                batch = unique[batch_start : batch_start + _ACTION_FETCH_BATCH]
                tasks = [
                    client.get(
                        "/componentactions/{id}",
                        path_params={"id": aid},
                        resource_type="componentactions",
                        resource_id=aid,
                    )
                    for _, aid, _ in batch
                ]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                for (comp_key, action_id, ft), result in zip(
                    batch, results, strict=True
                ):
                    if isinstance(result, BaseException):
                        warnings_list.append(
                            {
                                "action_id": action_id,
                                "component_key": comp_key,
                                "form_type": ft,
                                "reason": str(result),
                            }
                        )
                        continue
                    transformed = _transform_component_actions(result)
                    transformed["form_type"] = ft
                    items.append(transformed)
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="componentactions") from e

    if bot_id is not None:
        filtered: list[dict[str, Any]] = []
        for item in items:
            for action in item.get("actions", []):
                if any(bot.get("id") == bot_id for bot in action.get("bots", [])):
                    filtered.append(item)
                    break
        items = filtered

    return {
        "service_id": str(service_id),
        "total": len(items),
        "items": items,
        "warnings": warnings_list,
    }


def _transform_bot(bot: dict[str, Any]) -> dict[str, Any]:
    """Transform a bot object from camelCase to snake_case.

    Args:
        bot: Raw bot object from API.

    Returns:
        dict: Transformed bot with snake_case keys.
    """
    return {
        "id": bot.get("id"),
        "bot_type": bot.get("botType"),
        "name": bot.get("name"),
        "description": bot.get("description"),
        "enabled": bot.get("enabled", True),
    }


def _transform_component_actions(data: dict[str, Any]) -> dict[str, Any]:
    """Transform API response to snake_case format.

    Args:
        data: Raw API response with camelCase keys.

    Returns:
        dict: Transformed response with snake_case keys.
    """
    actions = []
    for action in data.get("actions", []):
        bots = [_transform_bot(bot) for bot in action.get("bots", [])]
        actions.append(
            {
                "id": action.get("id"),
                "json_determinants": action.get("jsonDeterminants"),
                "bots": bots,
                "sort_order": action.get("sortOrderNumber"),
                "parallel": action.get("parallel", False),
                "mandatory": action.get("mandatory", False),
                "multiple_bot": action.get("multipleBot", False),
                "multiple_field_key": action.get("multipleFieldKey"),
            }
        )

    return {
        "id": data.get("id"),
        "service_id": data.get("serviceId"),
        "component_key": data.get("componentKey"),
        "actions": actions,
    }


def _is_system_bot_id(bot_id: str) -> bool:
    """Check if a bot ID looks like a system bot (non-UUID, snake_case name)."""
    return not _UUID_PATTERN.match(bot_id)


def _api_action_to_save_input(
    action: dict[str, Any], bot_ids: list[str]
) -> dict[str, Any]:
    """Convert a snake_case API action row into componentaction_save input shape.

    The list_by_service / get_by_component path returns rows with `bots`
    populated as full Bot objects. componentaction_save expects each row
    to specify either `bot_id` (single) or `bot_ids` (multi). All other
    fields round-trip as-is.
    """
    save_input: dict[str, Any] = {
        "sort_order": action.get("sort_order"),
        "parallel": action.get("parallel", False),
        "mandatory": action.get("mandatory", False),
    }
    if len(bot_ids) == 1:
        save_input["bot_id"] = bot_ids[0]
    else:
        save_input["bot_ids"] = list(bot_ids)

    json_dets = action.get("json_determinants")
    if json_dets is not None:
        save_input["json_determinants"] = json_dets

    if action.get("multiple_bot"):
        save_input["multiple_bot"] = True
        save_input["multiple_field_key"] = action.get("multiple_field_key")

    return save_input


def _filter_actions_excluding_bot(
    actions: list[dict[str, Any]], bot_id: str
) -> tuple[list[dict[str, Any]], str]:
    """Compute reduced action list with all references to bot_id removed.

    Returns (reduced_save_input_actions, label) where label is one of:
        - "deleted": every row referenced only this bot; nothing remains.
          Caller should componentaction_delete the whole component.
        - "row_removed": at least one row was dropped AND others survive.
        - "bot_removed": no rows dropped, but the bot was trimmed out of
          one or more multi-bot rows.
        - "unchanged": the bot was not referenced by any row (defensive).

    Multi-bot rows whose `bot_ids` collapse to empty after removal are
    dropped (validation requires ≥1 bot per row).
    """
    reduced: list[dict[str, Any]] = []
    row_dropped = False
    bot_trimmed = False
    bot_seen = False

    for action in actions:
        action_bot_ids = [b.get("id") for b in action.get("bots", []) if b.get("id")]
        if bot_id in action_bot_ids:
            bot_seen = True
            remaining = [bid for bid in action_bot_ids if bid != bot_id]
            if not remaining:
                row_dropped = True
                continue
            bot_trimmed = True
            reduced.append(_api_action_to_save_input(action, remaining))
        else:
            reduced.append(_api_action_to_save_input(action, action_bot_ids))

    if not bot_seen:
        return reduced, "unchanged"
    if not reduced:
        return reduced, "deleted"
    if row_dropped:
        return reduced, "row_removed"
    if bot_trimmed:
        return reduced, "bot_removed"
    return reduced, "unchanged"


def _validate_actions(actions: list[dict[str, Any]]) -> None:
    """Validate action dicts (shared by save and update).

    Raises:
        ToolError: If validation fails.
    """
    if not actions:
        raise ToolError(
            "'actions' must be a non-empty list. "
            "To remove all actions, use 'componentaction_delete' instead."
        )
    seen_bot_ids: set[str] = set()
    for i, action in enumerate(actions):
        if not isinstance(action, dict):
            raise ToolError(
                f"actions[{i}] must be a dict, got {type(action).__name__}."
            )

        has_bot_id = bool(action.get("bot_id"))
        has_bot_ids = "bot_ids" in action

        if has_bot_id and has_bot_ids:
            raise ToolError(
                f"actions[{i}]: 'bot_id' and 'bot_ids' are mutually exclusive. "
                "Use 'bot_id' for single-bot or 'bot_ids' for multi-bot."
            )
        if not has_bot_id and not has_bot_ids:
            raise ToolError(
                f"actions[{i}] is missing required 'bot_id' (or 'bot_ids'). "
                "Each action must specify which bot to trigger."
            )

        # Duplicate bot_id across action rows
        if has_bot_id:
            bot_id = action["bot_id"]
            if bot_id in seen_bot_ids:
                raise ToolError(
                    f"actions[{i}]: Duplicate bot_id '{bot_id}'. "
                    "Each action row must reference a unique bot."
                )
            seen_bot_ids.add(bot_id)

        if has_bot_ids:
            bot_ids = action["bot_ids"]
            if not isinstance(bot_ids, list) or len(bot_ids) == 0:
                raise ToolError(f"actions[{i}]: 'bot_ids' must be a non-empty list.")
            # Check for duplicates within bot_ids
            unique_ids = set(bot_ids)
            if len(unique_ids) != len(bot_ids):
                raise ToolError(f"actions[{i}]: 'bot_ids' contains duplicates.")

        # multi-bot validation
        multiple_bot = action.get("multiple_bot", False)
        if multiple_bot and not action.get("multiple_field_key"):
            raise ToolError(
                f"actions[{i}]: 'multiple_field_key' is required when "
                "'multiple_bot' is True."
            )

        # determinant_ids validation
        if "determinant_ids" in action:
            det_ids = action["determinant_ids"]
            if not isinstance(det_ids, list) or not all(
                isinstance(d, str) for d in det_ids
            ):
                raise ToolError(
                    f"actions[{i}]: 'determinant_ids' must be a list "
                    "of strings (determinant UUIDs)."
                )
            if len(det_ids) == 0:
                raise ToolError(f"actions[{i}]: 'determinant_ids' must not be empty.")
            logic = action.get("logic", "AND")
            if logic.upper() not in ("AND", "OR"):
                raise ToolError(
                    f"actions[{i}]: 'logic' must be 'AND' or 'OR', got {logic!r}."
                )

        if "sort_order" in action:
            sort_order = action["sort_order"]
            if not isinstance(sort_order, int) or sort_order < 0:
                raise ToolError(
                    f"actions[{i}]: sort_order must be a non-negative integer, "
                    f"got {sort_order!r}."
                )


async def _verify_bot_ids(client: Any, actions: list[dict[str, Any]]) -> None:
    """Verify all referenced bots exist. System bots (non-UUID) are warned, not failed.

    Raises:
        ToolError: If a real bot (UUID) is not found.
    """
    for i, action in enumerate(actions):
        all_ids: list[str] = []
        if action.get("bot_ids"):
            all_ids = action["bot_ids"]
        elif action.get("bot_id"):
            all_ids = [action["bot_id"]]

        for bot_id in all_ids:
            if _is_system_bot_id(bot_id):
                logger.info(
                    "actions[%d]: Bot ID '%s' appears to be a system bot, "
                    "skipping verification.",
                    i,
                    bot_id,
                )
                continue
            try:
                await client.get(
                    "/bot/{id}",
                    path_params={"id": bot_id},
                    resource_type="bot",
                    resource_id=bot_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"actions[{i}]: Bot '{bot_id}' not found. "
                    "Use 'bot_list' to see available bots."
                ) from None


def _build_actions_payload(actions: list[dict[str, Any]]) -> dict[str, Any]:
    """Build the camelCase API payload from action dicts.

    Returns:
        dict with 'actions' key containing the API-formatted action rows.
    """
    api_actions = []
    for i, action in enumerate(actions):
        # Build bots array
        if action.get("bot_ids"):
            bots = [{"id": bid} for bid in action["bot_ids"]]
        else:
            bots = [{"id": action["bot_id"]}]

        # Build jsonDeterminants: prefer structured determinant_ids
        json_dets = None
        if action.get("determinant_ids"):
            logic = action.get("logic", "AND")
            json_dets = build_determinant_refs(action["determinant_ids"], logic)
        elif action.get("json_determinants"):
            json_dets = action["json_determinants"]

        row: dict[str, Any] = {
            "bots": bots,
            "sortOrderNumber": action.get("sort_order", i),
            "parallel": action.get("parallel", False),
            "mandatory": action.get("mandatory", False),
            "jsonDeterminants": json_dets,
        }

        # Multi-bot flags
        if action.get("multiple_bot"):
            row["multipleBot"] = True
            row["multipleFieldKey"] = action["multiple_field_key"]

        api_actions.append(row)
    return {"actions": api_actions}


def _collect_bot_ids(actions: list[dict[str, Any]]) -> list[str]:
    """Collect all bot IDs from action dicts for audit logging."""
    ids: list[str] = []
    for action in actions:
        if action.get("bot_ids"):
            ids.extend(action["bot_ids"])
        elif action.get("bot_id"):
            ids.append(action["bot_id"])
    return ids


async def _sync_action_metadata_to_form(
    client: Any,
    service_id: str | int,
    component_key: str,
    component_action_id: str | None,
    action_row_ids: list[str],
    form_type: str = "applicant",
) -> bool:
    """Sync componentActionId and actionRowIds to form component.

    The BPA frontend updates these properties via postMessage after saving
    actions. MCP must do this explicitly so the action counter/icon A
    appears in the form builder.

    Best-effort: returns False on any error without raising.
    """
    try:
        form_config = FORM_TYPES.get(form_type)
        if not form_config:
            return False

        form_data = await client.get(
            form_config["get_endpoint"],
            path_params={"id": service_id},
            params={"reusable": "false"},
            resource_type="form",
        )
        form_schema = parse_form_schema(form_data)
        components = form_schema.get("components", [])
        comp_result = find_component(components, component_key)
        if comp_result is None:
            return False

        comp, _ = comp_result
        comp["componentActionId"] = component_action_id or ""
        comp["actionRowIds"] = action_row_ids
        form_data["formSchema"] = form_schema
        await client.put(
            form_config["put_endpoint"],
            path_params={"form_id": form_data["id"]},
            json=form_data,
            resource_type="form",
        )
        return True
    except Exception:
        logger.debug(
            "Best-effort action metadata sync failed for %s/%s",
            service_id,
            component_key,
            exc_info=True,
        )
        return False


async def _resolve_form_type_for_component(
    client: Any,
    service_id: str | int,
    component_key: str,
) -> str | None:
    """Probe FORM_TYPES to find which form owns this component_key.

    Best-effort: returns the first form_type whose schema contains the
    component, or None if no form contains it (or all probes fail). Skips
    forms that 404 or otherwise error.
    """
    probe_order = ("applicant", "guide", "send_file", "payment", "document_form")
    for form_type in probe_order:
        config = FORM_TYPES.get(form_type)
        if not config:
            continue
        try:
            form_data = await client.get(
                config["get_endpoint"],
                path_params={"id": service_id},
                params={"reusable": "false"},
                resource_type="form",
            )
        except Exception:
            logger.debug(
                "Form-type probe GET failed for %s/%s",
                service_id,
                form_type,
                exc_info=True,
            )
            continue
        try:
            schema = parse_form_schema(form_data)
            if find_component(schema.get("components", []), component_key) is not None:
                return form_type
        except Exception:
            logger.debug(
                "Form-type probe parse failed for %s/%s",
                service_id,
                form_type,
                exc_info=True,
            )
            continue
    return None


async def _sync_action_metadata_to_role(
    client: Any,
    role_id: str,
    component_key: str,
    component_action_id: str | None,
    action_row_ids: list[str],
) -> bool:
    """Sync componentActionId/actionRowIds to a role-form component.

    Best-effort: returns False on any error without raising. Mirrors
    _sync_behaviour_metadata_to_role_form in shape (GET /role/{id},
    mutate component, PUT /role with id in body).
    """
    try:
        host_data = await client.get(
            "/role/{role_id}",
            path_params={"role_id": role_id},
            resource_type="role",
        )
        schema = parse_form_schema(host_data)
        comp_result = find_component(schema.get("components", []), component_key)
        if comp_result is None:
            return False
        comp, _ = comp_result
        comp["componentActionId"] = component_action_id or ""
        comp["actionRowIds"] = action_row_ids
        host_data["formSchema"] = schema
        await client.put(
            "/role",
            json=host_data,
            resource_type="role",
            resource_id=host_data.get("id", role_id),
        )
        return True
    except Exception:
        logger.debug(
            "Best-effort action metadata sync to role failed for %s/%s",
            role_id,
            component_key,
            exc_info=True,
        )
        return False


async def _sync_action_metadata_to_print_document(
    client: Any,
    document_id: str,
    component_key: str,
    component_action_id: str | None,
    action_row_ids: list[str],
) -> bool:
    """Sync componentActionId/actionRowIds to a print-document component.

    Best-effort: returns False on any error without raising. Mirrors
    _sync_behaviour_metadata_to_print_document in shape (GET/PUT
    /print-documents/{id}).
    """
    try:
        host_data = await client.get(
            "/print-documents/{id}",
            path_params={"id": document_id},
            resource_type="print_document",
        )
        schema = parse_form_schema(host_data)
        comp_result = find_component(schema.get("components", []), component_key)
        if comp_result is None:
            return False
        comp, _ = comp_result
        comp["componentActionId"] = component_action_id or ""
        comp["actionRowIds"] = action_row_ids
        host_data["formSchema"] = schema
        await client.put(
            "/print-documents/{id}",
            path_params={"id": document_id},
            json=host_data,
            resource_type="print_document",
            resource_id=str(document_id),
        )
        return True
    except Exception:
        logger.debug(
            "Best-effort action metadata sync to print_document failed for %s/%s",
            document_id,
            component_key,
            exc_info=True,
        )
        return False


def _validate_action_host(
    form_type: str | None,
    role_id: str | None,
    print_document_id: str | None,
) -> None:
    """Validate mutual exclusion of action-host parameters.

    At most one of (non-None form_type, role_id, print_document_id) may
    be set. When all are None, the tool will probe forms via
    _resolve_form_type_for_component.

    Raises:
        ToolError: when more than one host is set, or when form_type is
            not a FORM_TYPES key.
    """
    set_count = sum(bool(x) for x in (form_type, role_id, print_document_id))
    if set_count > 1:
        raise ToolError(
            "form_type, role_id, and print_document_id are mutually "
            "exclusive. Pass at most one (or none for auto-detect)."
        )
    if form_type is not None and form_type not in FORM_TYPES:
        valid = ", ".join(sorted(FORM_TYPES.keys()))
        raise ToolError(f"Invalid form_type '{form_type}'. Valid: {valid}.")


async def _dispatch_action_metadata_sync(
    client: Any,
    *,
    service_id: str | int,
    component_key: str,
    component_action_id: str | None,
    action_row_ids: list[str],
    form_type: str | None,
    role_id: str | None,
    print_document_id: str | None,
) -> bool:
    """Route the metadata sync to the right host based on which param is set.

    When role_id is set → sync to /role/{role_id}.
    When print_document_id is set → sync to /print-documents/{id}.
    Otherwise (form_type set or all None) → sync to the matching service
    form, auto-detecting via _resolve_form_type_for_component when
    form_type is None. Falls back to applicant when no form contains the
    component, matching prior semantics.
    """
    if role_id:
        return await _sync_action_metadata_to_role(
            client, role_id, component_key, component_action_id, action_row_ids
        )
    if print_document_id:
        return await _sync_action_metadata_to_print_document(
            client,
            print_document_id,
            component_key,
            component_action_id,
            action_row_ids,
        )
    resolved_form_type = form_type
    if resolved_form_type is None:
        resolved_form_type = await _resolve_form_type_for_component(
            client, service_id, component_key
        )
    return await _sync_action_metadata_to_form(
        client,
        service_id,
        component_key,
        component_action_id,
        action_row_ids,
        form_type=resolved_form_type or "applicant",
    )


async def componentaction_save(
    service_id: str | int,
    component_key: str,
    actions: list[dict[str, Any]],
    form_type: str | None = None,
    role_id: str | None = None,
    print_document_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Save component actions linking bots to a component. Audited write operation.

    Args:
        service_id: Parent service ID.
        component_key: Form component key to attach actions to.
        actions: List of action dicts. Each requires bot_id (str) or
            bot_ids (list[str]) for multi-bot. Optional: sort_order (int),
            parallel (bool), mandatory (bool), determinant_ids (list[str],
            preferred), logic (str, "AND"/"OR", default "AND"),
            json_determinants (str, raw fallback), multiple_bot (bool),
            multiple_field_key (str, required when multiple_bot=True).
        form_type: Which service form owns the button (applicant, guide,
            send_file, payment, document_form). When omitted (and no
            role_id / print_document_id given), the tool probes service
            forms in that order and syncs to the first match.
        role_id: Sync metadata to this role's form instead of a service
            form. Mutually exclusive with form_type and print_document_id.
        print_document_id: Sync metadata to this print document instead
            of a service form. Mutually exclusive with form_type and role_id.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with component_key, action_count, service_id, audit_id, metadata_synced.
    """
    # Pre-flight validation (no audit record for validation failures)
    if not service_id:
        raise ToolError("'service_id' is required.")
    if not component_key or (
        isinstance(component_key, str) and not component_key.strip()
    ):
        raise ToolError("'component_key' is required.")
    _validate_actions(actions)
    _validate_action_host(form_type, role_id, print_document_id)

    # Get authenticated user for audit
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            # Verify service exists
            try:
                await client.get(
                    "/service/{id}",
                    path_params={"id": service_id},
                    resource_type="service",
                    resource_id=service_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Cannot save component actions: Service '{service_id}' not found. "
                    "Use 'service_list' to see available services."
                ) from None

            # Verify bots exist (system bots skipped gracefully)
            await _verify_bot_ids(client, actions)

            # Fetch existing state for rollback (may not exist yet)
            existing_state = None
            try:
                existing_state = await client.get(
                    "/service/{service_id}/componentactions/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="componentactions",
                )
            except BPANotFoundError:
                pass  # No existing actions — this is a create

            # Build payload
            payload = _build_actions_payload(actions)

            # Create PENDING audit record
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="save",
                object_type="componentactions",
                params={
                    "service_id": str(service_id),
                    "component_key": component_key,
                    "action_count": len(actions),
                    "bot_ids": _collect_bot_ids(actions),
                    "had_existing": existing_state is not None,
                    "form_type": form_type,
                    "role_id": role_id,
                    "print_document_id": print_document_id,
                },
            )

            # Save rollback state
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="componentactions",
                object_id=f"{service_id}/{component_key}",
                previous_state=existing_state or {},
            )

            try:
                result = await client.put(
                    "/service/{service_id}/componentactions/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    json=payload,
                    resource_type="componentactions",
                )

                # Dispatch metadata sync to the right host (form, role, or
                # print_document) based on which selector param was given.
                ca_id = result.get("id")
                row_ids = [
                    a.get("id") for a in result.get("actions", []) if a.get("id")
                ]
                metadata_synced = await _dispatch_action_metadata_sync(
                    client,
                    service_id=service_id,
                    component_key=component_key,
                    component_action_id=ca_id,
                    action_row_ids=row_ids,
                    form_type=form_type,
                    role_id=role_id,
                    print_document_id=print_document_id,
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "component_key": component_key,
                        "action_count": len(actions),
                        "service_id": str(service_id),
                        "metadata_synced": metadata_synced,
                    },
                )

                return {
                    "component_key": component_key,
                    "action_count": len(actions),
                    "actions": _transform_component_actions(result).get("actions", []),
                    "service_id": str(service_id),
                    "audit_id": audit_id,
                    "metadata_synced": metadata_synced,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="componentactions") from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="service", resource_id=service_id) from e


async def componentaction_delete(
    service_id: str | int,
    component_key: str,
    form_type: str | None = None,
    role_id: str | None = None,
    print_document_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Remove all actions from a component. Audited write operation.

    Args:
        service_id: Parent service ID.
        component_key: Form component key to remove actions from.
        form_type: Which service form owns the button (applicant, guide,
            send_file, payment, document_form). When omitted (and no
            role_id / print_document_id given), probes forms to find the
            component.
        role_id: Clear metadata from this role's form. Mutually exclusive
            with form_type and print_document_id.
        print_document_id: Clear metadata from this print document.
            Mutually exclusive with form_type and role_id.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with deleted, component_key, service_id, audit_id, metadata_cleared.
    """
    if not service_id:
        raise ToolError("'service_id' is required.")
    if not component_key or (
        isinstance(component_key, str) and not component_key.strip()
    ):
        raise ToolError("'component_key' is required.")

    _validate_action_host(form_type, role_id, print_document_id)

    # Get authenticated user for audit
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            # Fetch existing state for rollback
            try:
                existing_state = await client.get(
                    "/service/{service_id}/componentactions/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="componentactions",
                )
            except BPANotFoundError:
                return {
                    "deleted": False,
                    "component_key": component_key,
                    "service_id": str(service_id),
                    "message": "No actions found for this component. "
                    "Nothing to delete.",
                }

            # Create PENDING audit record
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="delete",
                object_type="componentactions",
                object_id=f"{service_id}/{component_key}",
                params={
                    "service_id": str(service_id),
                    "component_key": component_key,
                    "form_type": form_type,
                    "role_id": role_id,
                    "print_document_id": print_document_id,
                },
            )

            # Save rollback state
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="componentactions",
                object_id=f"{service_id}/{component_key}",
                previous_state=existing_state,
            )

            try:
                await client.delete(
                    "/service/{service_id}/componentactions/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="componentactions",
                )

                # Clear actionRowIds from the right host (best-effort)
                metadata_cleared = await _dispatch_action_metadata_sync(
                    client,
                    service_id=service_id,
                    component_key=component_key,
                    component_action_id=None,
                    action_row_ids=[],
                    form_type=form_type,
                    role_id=role_id,
                    print_document_id=print_document_id,
                )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "deleted": True,
                        "component_key": component_key,
                        "service_id": str(service_id),
                        "metadata_cleared": metadata_cleared,
                    },
                )

                return {
                    "deleted": True,
                    "component_key": component_key,
                    "service_id": str(service_id),
                    "deleted_actions": _transform_component_actions(existing_state),
                    "metadata_cleared": metadata_cleared,
                    "audit_id": audit_id,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="componentactions") from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="componentactions") from e


async def componentaction_get_system_actions(
    instance: str | None = None,
) -> dict[str, Any]:
    """List built-in system button actions available for form components.

    Args:
        instance: Instance profile name (from instance_list).

    Returns:
        dict with actions list (id, name, category), count, note.
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            data = await client.get(
                "/service/button_actions",
                resource_type="button_actions",
            )
    except BPAClientError as e:
        raise translate_error(e, resource_type="button_actions") from e

    # data is expected to be a list of action objects
    if not isinstance(data, list):
        logger.warning(
            "GET /service/button_actions returned %s instead of list, got: %s",
            type(data).__name__,
            str(data)[:200],
        )
    actions_list: list[dict[str, Any]] = data if isinstance(data, list) else []

    categorized: list[dict[str, str]] = []
    for action in actions_list:
        action_id = action.get("id") or action.get("name", "")
        category = _SYSTEM_ACTION_CATEGORIES.get(action_id, "other")
        categorized.append(
            {
                "id": action_id,
                "name": action.get("name", action_id),
                "category": category,
            }
        )

    return {
        "actions": categorized,
        "count": len(categorized),
        "note": (
            "System actions use their id as bot_id in componentaction_save. "
            "They do not appear in bot_list."
        ),
    }


async def componentaction_update(
    id: str,
    actions: list[dict[str, Any]],
    form_type: str | None = None,
    role_id: str | None = None,
    print_document_id: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Update component actions by ID. Audited write operation.

    Use when you have a componentaction ID (from componentaction_get
    or a component's componentActionId field). Replaces all action
    rows atomically.

    Args:
        id: ComponentActions record ID.
        actions: List of action dicts (same format as componentaction_save).
        form_type: Which service form owns the button (applicant, guide,
            send_file, payment, document_form). When omitted (and no
            role_id / print_document_id given), probes service forms via
            the record's componentKey + serviceId.
        role_id: Sync metadata to this role's form. Mutually exclusive
            with form_type and print_document_id.
        print_document_id: Sync metadata to this print document.
            Mutually exclusive with form_type and role_id.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, component_key, action_count, audit_id, metadata_synced.
    """
    if not id or (isinstance(id, str) and not id.strip()):
        raise ToolError("'id' is required.")
    _validate_actions(actions)
    _validate_action_host(form_type, role_id, print_document_id)

    # Get authenticated user for audit
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            # Verify record exists and capture for rollback
            try:
                existing_state = await client.get(
                    "/componentactions/{id}",
                    path_params={"id": id},
                    resource_type="componentactions",
                    resource_id=id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"ComponentActions '{id}' not found. Verify the ID is correct."
                ) from None

            # Verify bots exist (system bots skipped gracefully)
            await _verify_bot_ids(client, actions)

            # Build payload
            payload = _build_actions_payload(actions)

            # Create PENDING audit record
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type="componentactions",
                object_id=id,
                params={
                    "id": id,
                    "action_count": len(actions),
                    "bot_ids": _collect_bot_ids(actions),
                    "form_type": form_type,
                    "role_id": role_id,
                    "print_document_id": print_document_id,
                },
            )

            # Save rollback state
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="componentactions",
                object_id=id,
                previous_state=existing_state,
            )

            try:
                result = await client.put(
                    "/componentactions/{id}",
                    path_params={"id": id},
                    json=payload,
                    resource_type="componentactions",
                )

                component_key = result.get("componentKey") or existing_state.get(
                    "componentKey", ""
                )
                update_service_id = result.get("serviceId") or existing_state.get(
                    "serviceId", ""
                )

                # Dispatch metadata sync to the right host (best-effort).
                # update_service_id + component_key come from the record; the
                # role_id / print_document_id selectors come from the caller.
                metadata_synced = False
                if update_service_id and component_key:
                    ca_id = result.get("id")
                    row_ids = [
                        a.get("id") for a in result.get("actions", []) if a.get("id")
                    ]
                    metadata_synced = await _dispatch_action_metadata_sync(
                        client,
                        service_id=update_service_id,
                        component_key=component_key,
                        component_action_id=ca_id,
                        action_row_ids=row_ids,
                        form_type=form_type,
                        role_id=role_id,
                        print_document_id=print_document_id,
                    )

                await audit_logger.mark_success(
                    audit_id,
                    result={
                        "id": id,
                        "component_key": component_key,
                        "action_count": len(actions),
                        "metadata_synced": metadata_synced,
                    },
                )

                return {
                    "id": id,
                    "component_key": component_key,
                    "action_count": len(actions),
                    "actions": _transform_component_actions(result).get("actions", []),
                    "audit_id": audit_id,
                    "metadata_synced": metadata_synced,
                }

            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="componentactions") from e

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="componentactions", resource_id=id
        ) from e


async def componentaction_delete_by_bot(
    service_id: str | int,
    bot_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Batch-remove all references to a bot across a service. Audited destructive.

    The bot MUST still exist when this is called; after `bot_delete` the BPA
    API silently filters orphan references and they can no longer be located.
    Workflow: cleanup → bot_delete (not the reverse).

    Per affected component: rows that reference ONLY this bot are dropped;
    multi-bot rows have just this bot trimmed out. If every row on the
    component is single-bot to this bot, the whole component's actions are
    deleted in one call.

    Args:
        service_id: Service to scan.
        bot_id: Bot whose references to purge (UUID or system bot id).
        instance: Instance profile name (from instance_list).

    Returns:
        dict with service_id, bot_id, affected_count, affected_components
        (list of {component_key, action, audit_id}), audit_id.
    """
    if not service_id or (isinstance(service_id, str) and not service_id.strip()):
        raise ToolError("'service_id' is required.")
    if not bot_id or not bot_id.strip():
        raise ToolError("'bot_id' is required.")

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    is_system_bot = _is_system_bot_id(bot_id)

    async def _bot_exists(client: Any) -> bool:
        try:
            await client.get(
                "/bot/{id}",
                path_params={"id": bot_id},
                resource_type="bot",
                resource_id=bot_id,
            )
            return True
        except BPANotFoundError:
            return False

    try:
        async with BPAClient.for_instance(instance) as client:
            # Pre-flight 1: bot must still exist (skip for system bots).
            if not is_system_bot and not await _bot_exists(client):
                raise ToolError(
                    f"Bot '{bot_id}' is already deleted. After a bot is "
                    "deleted, the BPA API silently filters orphan references "
                    "from action serialization, so they cannot be enumerated. "
                    "Recovery options: (1) rollback the bot deletion via the "
                    "'rollback' tool, then re-run this cleanup before "
                    "re-deleting; or (2) re-save each affected component "
                    "manually using componentaction_save with the live action "
                    "list (this drops orphans as a side effect)."
                )

            # Pre-flight 2: service must exist.
            try:
                await client.get(
                    "/service/{id}",
                    path_params={"id": service_id},
                    resource_type="service",
                    resource_id=service_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Service '{service_id}' not found. "
                    "Use 'service_list' to see available services."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="service", resource_id=service_id) from e

    # Create the top-level batch audit row.
    audit_logger = AuditLogger(db_path=resolve_db_path(instance))
    audit_id = await audit_logger.record_pending(
        user_email=user_email,
        operation_type="delete_by_bot",
        object_type="componentactions",
        object_id=f"{service_id}/by-bot/{bot_id}",
        params={
            "service_id": str(service_id),
            "bot_id": bot_id,
        },
    )

    # Discover affected components via the existing primitive.
    try:
        list_result = await componentaction_list_by_service(
            service_id=service_id, instance=instance, bot_id=bot_id
        )
    except ToolError:
        await audit_logger.mark_failed(
            audit_id, "componentaction_list_by_service raised ToolError"
        )
        raise

    items = list_result.get("items", [])

    if not items:
        # Empty result: confirm the bot is still alive. Otherwise we may have
        # raced a concurrent bot_delete and orphans are now hidden.
        if not is_system_bot:
            try:
                async with BPAClient.for_instance(instance) as client:
                    if not await _bot_exists(client):
                        msg = (
                            f"Bot '{bot_id}' was deleted concurrently while "
                            "this cleanup was running. Orphan references can "
                            "no longer be enumerated via the API. Roll back "
                            "the bot deletion or re-save affected components "
                            "manually."
                        )
                        await audit_logger.mark_failed(audit_id, msg)
                        raise ToolError(msg)
            except ToolError:
                raise
            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(e, resource_type="bot", resource_id=bot_id) from e

        await audit_logger.mark_success(
            audit_id,
            result={
                "service_id": str(service_id),
                "bot_id": bot_id,
                "affected_count": 0,
            },
        )
        return {
            "service_id": str(service_id),
            "bot_id": bot_id,
            "affected_count": 0,
            "affected_components": [],
            "audit_id": audit_id,
        }

    # Per-component cleanup. Stop on first failure to keep semantics simple
    # for callers; prior successes are reported in the error message.
    affected_components: list[dict[str, Any]] = []
    succeeded_keys: list[str] = []

    for item in items:
        component_key = item.get("component_key")
        if not component_key:
            continue
        reduced, label = _filter_actions_excluding_bot(item.get("actions", []), bot_id)
        if label == "unchanged":
            # Defensive — shouldn't happen with bot_id filter on, skip.
            continue

        try:
            if label == "deleted":
                inner = await componentaction_delete(
                    service_id=service_id,
                    component_key=component_key,
                    instance=instance,
                )
            else:
                inner = await componentaction_save(
                    service_id=service_id,
                    component_key=component_key,
                    actions=reduced,
                    instance=instance,
                )
        except ToolError as e:
            failure_msg = (
                f"componentaction_delete_by_bot failed on component "
                f"'{component_key}': {e!s}. "
                f"Completed: {succeeded_keys or '[]'}. "
                f"Use 'rollback' against the per-component audit records "
                f"to undo, or re-run the tool to retry remaining components."
            )
            await audit_logger.mark_failed(audit_id, failure_msg)
            raise ToolError(failure_msg) from e

        affected_components.append(
            {
                "component_key": component_key,
                "action": label,
                "audit_id": inner.get("audit_id"),
            }
        )
        succeeded_keys.append(component_key)

    await audit_logger.mark_success(
        audit_id,
        result={
            "service_id": str(service_id),
            "bot_id": bot_id,
            "affected_count": len(affected_components),
            "components": [c["component_key"] for c in affected_components],
        },
    )

    return {
        "service_id": str(service_id),
        "bot_id": bot_id,
        "affected_count": len(affected_components),
        "affected_components": affected_components,
        "audit_id": audit_id,
    }


def register_action_tools(mcp: Any) -> None:
    """Register action tools with the MCP server.

    Args:
        mcp: The FastMCP server instance.
    """
    from mcp_eregistrations_bpa.tools.annotations import DESTRUCTIVE, READ, WRITE

    # Read operations
    mcp.tool(annotations=READ)(componentaction_get)
    mcp.tool(annotations=READ)(componentaction_get_by_component)
    mcp.tool(annotations=READ)(componentaction_get_system_actions)
    mcp.tool(annotations=READ)(componentaction_list_by_service)
    # Write operations
    mcp.tool(annotations=WRITE)(componentaction_save)
    mcp.tool(annotations=WRITE)(componentaction_update)
    mcp.tool(annotations=DESTRUCTIVE)(componentaction_delete)
    mcp.tool(annotations=DESTRUCTIVE)(componentaction_delete_by_bot)
