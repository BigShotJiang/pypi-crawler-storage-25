"""Pure helpers for component formula tooling.

Component formulas are wire-strings using `;;` as token separator (per
`BPA-frontend/src/app/models/infix-formula/costView.ts:32`). Backend stores
`infix` as opaque TEXT; we only catch the most common authoring mistake
(space-separated tokens). Quoted literals may legitimately contain whitespace.
"""

from __future__ import annotations

import json
import re

from fastmcp.exceptions import ToolError

# Quoted single-string literal — internal whitespace OK.
_QUOTED_LITERAL = re.compile(r"^'[^']*'$")
# Bare token shapes the validator recognizes as not-needing-quote-escaping.
_BARE_TOKEN = re.compile(
    r"^[A-Za-z_][A-Za-z0-9_.]*$"
    r"|^[<>=!&|+\-*/^#,()?:]+$"
    r"|^-?\d+(\.\d+)?$"
    r"|^\d{4}-\d{2}-\d{2}$"
)


def _validate_infix(infix: str) -> None:
    """Reject space-separated infix input. Pass-through opaque otherwise.

    Backend stores `infix` as `@Column(TEXT)` and does not parse it. We catch
    the most common authoring mistake — caller forgot the `;;` separator —
    while passing through unknown token shapes (which the backend will accept
    and DataWeave will either compile or fail at publish time).

    Critical: tokens like `'Hello World'` are valid (quoted literals with
    internal whitespace). The validator must split on `;;` first, then check
    per-token shape.
    """
    if not infix:
        return  # Empty is valid (caller may want to clear)
    tokens = [t.strip() for t in infix.split(";;")]
    tokens = [t for t in tokens if t]  # Filter empties (allows trailing ;;)
    for tok in tokens:
        if _QUOTED_LITERAL.match(tok):
            continue  # Quoted literal — internal whitespace OK
        if _BARE_TOKEN.match(tok):
            continue  # Recognized bare shape — passes
        if any(c.isspace() for c in tok):
            raise ToolError(
                f"Token {tok!r} contains whitespace but is not a quoted "
                f"literal. infix must use ';;' as token separator, not "
                f"whitespace. Example: ( ;; 'data.x' ;; = ;; 'Y' ;; )"
            )


def _compute_pretty_print(infix: str) -> str:
    """Compute pretty_print_infix_formula from infix.

    Pragmatic transform (per spec § 8). Strips `data.`/`row.` prefixes from
    references; replaces `dateToday` → `Today`; joins on space instead of
    `;;`. Does NOT resolve property IDs to display labels (would require
    fetching the form's component list — out of scope per spec).

    The UI's full prettyPrint resolves to display labels (e.g., `companyType`
    → `Director`); this implementation does not. The UI overwrites this
    sidecar field on every save anyway, so the visible-to-end-user form is
    transient.

    Filters empty tokens to avoid double-spaces in output.
    """
    if not infix:
        return ""
    out: list[str] = []
    for tok in (t.strip() for t in infix.split(";;")):
        if not tok:
            continue
        if tok == "dateToday":
            out.append("Today")
        elif tok.startswith("'data.") and tok.endswith("'"):
            out.append(tok[6:-1])  # strip 'data. and trailing '
        elif tok.startswith("'row.") and tok.endswith("'"):
            out.append(tok[5:-1])
        else:
            out.append(tok)
    return " ".join(out)


def _validate_json_determinants_shape(s: str) -> None:
    """Validate the determinant-reference shape (not just JSON-parseable).

    The UI query-builder expects::

        [{"type":"AND|OR","items":[{"type":"AND|OR","determinantId":"<uuid>"}, ...]}]

    Inline JSONLogic (e.g., ``{"==": [{"var":"x"}, true]}``) passes Spring's
    ``@ValidateJson`` (the backend only checks JSON parseability) but breaks
    the UI's frontend query-builder. We catch that mistake here.

    Empty array ``[]`` is accepted — represents "no conditions".

    Args:
        s: Stringified JSON to validate.

    Raises:
        ToolError: if the string is not JSON, or does not match the shape.
    """
    try:
        parsed = json.loads(s)
    except json.JSONDecodeError as e:
        raise ToolError(f"json_determinants is not valid JSON: {e}") from e

    if not isinstance(parsed, list):
        raise ToolError(
            "json_determinants must be a determinant-reference array, "
            "got a non-array. Use build_determinant_refs() helper."
        )
    for group in parsed:
        if not isinstance(group, dict):
            raise ToolError(
                "json_determinants groups must be objects with "
                "{type, items}. Use build_determinant_refs() helper."
            )
        if "type" not in group or "items" not in group:
            raise ToolError(
                "json_determinants is not in determinant-reference shape "
                "(missing 'type' or 'items' key). Use build_determinant_refs() "
                "helper. Inline JSONLogic is rejected — the UI query-builder "
                "cannot render it."
            )
        if not isinstance(group["items"], list):
            raise ToolError(
                "json_determinants 'items' must be an array of "
                "{type, determinantId} objects."
            )
        for item in group["items"]:
            if not isinstance(item, dict) or "determinantId" not in item:
                raise ToolError(
                    "json_determinants is not in determinant-reference shape "
                    "(item missing 'determinantId'). Use build_determinant_refs()."
                )
