"""MCP tools for BPA media library operations.

Media files are deployment-scoped (Flavour B) assets — typically PDFs —
referenced by buttons via the "Download file" system action.

Write operations follow the audit-before-write pattern:
1. Validate parameters (pre-flight, no audit record if validation fails)
2. Create PENDING audit record
3. Execute BPA API call
4. Update audit record to SUCCESS or FAILED

Write operations are annotated irreversible in the audit record because
content replacement and deletion cannot be rolled back automatically
without versioning (no versioning history is in scope — see issue #95).

API Endpoints used:
- GET    /media                 - List all media files
- GET    /media/{id}            - Get one media file metadata
- POST   /media                 - Upload (multipart)
- PUT    /media/{id}            - Replace content, keep id (UUID-stable)
- DELETE /media/{id}            - Delete (409 with usages when referenced)
- GET    /media/{id}/usages     - List buttons referencing this media
"""

from __future__ import annotations

import base64
import binascii
import json as _json
import mimetypes
import os
import re
from pathlib import Path
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.audit.context import (
    NotAuthenticatedError,
    get_current_user_email,
)
from mcp_eregistrations_bpa.audit.logger import AuditLogger
from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import (
    BPAClientError,
    BPANotFoundError,
    translate_error,
)
from mcp_eregistrations_bpa.config import resolve_db_path
from mcp_eregistrations_bpa.tools.large_response import large_response_handler

__all__ = [
    "media_list",
    "media_get",
    "media_usages",
    "media_upload",
    "media_replace",
    "media_delete",
    "media_public_url",
    "register_media_tools",
]


_DATA_URL_RE = re.compile(r"^data:([^;,]+);base64,(.+)$", re.DOTALL)


def _transform_media_response(data: dict[str, Any]) -> dict[str, Any]:
    """Transform a MediaFile API response from camelCase to snake_case."""
    return {
        "id": data.get("id"),
        "name": data.get("name"),
        "content_type": data.get("contentType"),
        "size_bytes": data.get("sizeBytes"),
        "uploaded_at": data.get("uploadedAt"),
        "uploaded_by": data.get("uploadedBy"),
    }


def _transform_usage_response(data: dict[str, Any]) -> dict[str, Any]:
    """Transform a MediaUsage API response from camelCase to snake_case.

    Preserves the `context` discriminator and only emits the navigation
    fields present in the payload (form_*, role_*, document_*, bot_*).
    """
    out: dict[str, Any] = {
        "service_id": data.get("serviceId"),
        "service_name": data.get("serviceName"),
        "component_key": data.get("componentKey"),
        "component_name": data.get("componentName"),
        "context": data.get("context"),
    }
    for k_in, k_out in (
        ("formId", "form_id"),
        ("formName", "form_name"),
        ("roleId", "role_id"),
        ("roleName", "role_name"),
        ("documentId", "document_id"),
        ("documentName", "document_name"),
        ("botId", "bot_id"),
        ("botName", "bot_name"),
    ):
        if k_in in data:
            out[k_out] = data.get(k_in)
    return out


def _coerce_body(body: Any) -> dict[str, Any]:
    """Return body as a dict — parse JSON string, accept dict, else empty."""
    if isinstance(body, dict):
        return body
    if isinstance(body, str):
        try:
            parsed = _json.loads(body)
        except (ValueError, TypeError):
            return {}
        return parsed if isinstance(parsed, dict) else {}
    return {}


def _read_media_input(
    file_input: str,
    *,
    name: str | None,
    content_type: str | None,
) -> tuple[str, bytes, str]:
    """Resolve file_input (path or base64) into (filename, bytes, content_type).

    Resolution order:
        1. data URL — `data:<mime>;base64,<payload>` — extracts mime + bytes.
        2. Local path — if `file_input` is an existing readable file.
        3. Raw base64 — best-effort base64 decode of the string.
    """
    m = _DATA_URL_RE.match(file_input)
    if m:
        detected_ct = m.group(1)
        try:
            payload = base64.b64decode(m.group(2), validate=True)
        except (binascii.Error, ValueError) as e:
            raise ToolError(f"Invalid base64 payload in data URL: {e}") from e
        return (name or "media", payload, content_type or detected_ct)

    p = Path(file_input).expanduser()
    if p.exists() and p.is_file():
        payload = p.read_bytes()
        guessed, _ = mimetypes.guess_type(p.name)
        return (
            name or p.name,
            payload,
            content_type or guessed or "application/octet-stream",
        )

    try:
        payload = base64.b64decode(file_input, validate=True)
    except (binascii.Error, ValueError) as e:
        raise ToolError(
            "Unable to read media input. Expected one of:\n"
            "  - a path to an existing file on the MCP host\n"
            "  - a data URL (data:<mime>;base64,<payload>)\n"
            "  - a raw base64-encoded string (then `name` is required).\n"
            f"Decode error: {e}"
        ) from e
    if not name:
        raise ToolError(
            "When passing raw base64, `name` is required (e.g. 'guide.pdf')."
        )
    return (
        name,
        payload,
        content_type or mimetypes.guess_type(name)[0] or "application/octet-stream",
    )


def _restheart_url(override: str | None) -> str:
    """Resolve the RestHeart base URL with trailing slash."""
    base = (
        override
        or os.environ.get("RESTHEART_URL")
        or os.environ.get("RESTHEART_PUBLIC_URL")
    )
    if not base:
        raise ToolError(
            "Cannot resolve RestHeart base URL.\n"
            "Pass `restheart_url=...` or set the RESTHEART_URL environment "
            "variable to e.g. 'https://host.example.org/restheart/'."
        )
    return base.rstrip("/") + "/"


# ---- READ-ONLY TOOLS ----------------------------------------------------


@large_response_handler(
    threshold_bytes=50 * 1024,
    navigation={
        "list_all": "jq '.media_files'",
        "find_by_name": "jq '.media_files[] | select(.name | contains(\"<q>\"))'",
    },
)
async def media_list(instance: str | None = None) -> dict[str, Any]:
    """List media files in the deployment library.

    Args:
        instance: Instance profile name (from instance_list).

    Returns:
        dict with media_files, total.
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            items = await client.get_list(
                "/media",
                resource_type="media",
            )
    except BPAClientError as e:
        raise translate_error(e, resource_type="media") from e

    media = [_transform_media_response(m) for m in items]
    return {"media_files": media, "total": len(media)}


async def media_get(
    media_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Get one media file's metadata.

    Args:
        media_id: Media file UUID.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, name, content_type, size_bytes, uploaded_at, uploaded_by.
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                data = await client.get(
                    "/media/{id}",
                    path_params={"id": media_id},
                    resource_type="media",
                    resource_id=media_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Media file '{media_id}' not found. "
                    "Use 'media_list' to see available files."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="media", resource_id=media_id) from e

    return _transform_media_response(data)


async def media_usages(
    media_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """List buttons referencing a media file.

    Args:
        media_id: Media file UUID.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with media_id, usages, total.
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                items = await client.get_list(
                    "/media/{id}/usages",
                    path_params={"id": media_id},
                    resource_type="media_usages",
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Media file '{media_id}' not found. "
                    "Use 'media_list' to see available files."
                ) from None
    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(
            e, resource_type="media_usages", resource_id=media_id
        ) from e

    usages = [_transform_usage_response(u) for u in items]
    return {"media_id": media_id, "usages": usages, "total": len(usages)}


async def media_public_url(
    media_id: str,
    *,
    restheart_url: str | None = None,
) -> dict[str, str]:
    """Return the public binary URL for a media file (no auth).

    Pure helper — does not call the backend. Useful for embedding in
    print documents or DS deep-links. Resolves the RestHeart base URL
    from `restheart_url` arg, `RESTHEART_URL` env, or `RESTHEART_PUBLIC_URL` env.

    Args:
        media_id: Media file UUID.
        restheart_url: Optional override; defaults to env vars.

    Returns:
        dict with url.
    """
    base = _restheart_url(restheart_url)
    return {"url": f"{base}eregsystem/media.files/{media_id}/binary"}


# ---- WRITE TOOLS (audit-before-write, irreversible) ---------------------


async def media_upload(
    file_input: str,
    name: str | None = None,
    content_type: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Upload a new media file. Audited write operation. Irreversible.

    The backend re-detects MIME and rejects with HTTP 415 if the declared
    and detected types disagree — the body `{declared, detected}` is
    surfaced verbatim in the ToolError.

    Args:
        file_input: Path to a local file, a data URL
            (`data:<mime>;base64,<payload>`), or a raw base64 string.
        name: Filename override (required for raw base64).
        content_type: MIME override; default: detected from input.
        instance: Instance profile name (from instance_list).

    Returns:
        dict with id, name, content_type, size_bytes, uploaded_at,
        uploaded_by, audit_id.
    """
    filename, payload, ctype = _read_media_input(
        file_input, name=name, content_type=content_type
    )

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="create",
                object_type="media",
                params={
                    "filename": filename,
                    "content_type": ctype,
                    "size_bytes": len(payload),
                    "_irreversible": True,
                },
            )

            try:
                data = await client.post(
                    "/media",
                    files={"file": (filename, payload, ctype)},
                    resource_type="media",
                )
            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                if getattr(e, "status_code", None) == 415:
                    body = _coerce_body(getattr(e, "response_body", None))
                    raise ToolError(
                        f"Upload rejected: MIME mismatch. "
                        f"declared={body.get('declared')}, "
                        f"detected={body.get('detected')}."
                    ) from e
                raise translate_error(e, resource_type="media") from e

            created_id = data.get("id")
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="media",
                object_id=str(created_id),
                previous_state={
                    "id": created_id,
                    "_operation": "create",
                    "_irreversible": True,
                },
            )
            await audit_logger.mark_success(
                audit_id,
                result={"media_id": created_id, "name": data.get("name")},
            )

            result = _transform_media_response(data)
            result["audit_id"] = audit_id
            return result

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="media") from e


async def media_replace(
    media_id: str,
    file_input: str,
    name: str | None = None,
    content_type: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Replace a media file's content. UUID is stable. Audited. Irreversible.

    The prior content is overwritten in place and cannot be recovered
    (no versioning per the architecture spec on issue #95).

    Args:
        media_id: Media file UUID (preserved across the replace).
        file_input: New file content — same accepted formats as media_upload.
        name: Filename override.
        content_type: MIME override.
        instance: Instance profile name.

    Returns:
        dict with id (unchanged), name, content_type, size_bytes,
        uploaded_at, uploaded_by, audit_id.
    """
    filename, payload, ctype = _read_media_input(
        file_input, name=name, content_type=content_type
    )

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                await client.get(
                    "/media/{id}",
                    path_params={"id": media_id},
                    resource_type="media",
                    resource_id=media_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Media file '{media_id}' not found. "
                    "Use 'media_list' to see available files."
                ) from None

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type="media",
                params={
                    "media_id": media_id,
                    "filename": filename,
                    "content_type": ctype,
                    "size_bytes": len(payload),
                    "_irreversible": True,
                },
            )

            try:
                data = await client.put(
                    "/media/{id}",
                    path_params={"id": media_id},
                    files={"file": (filename, payload, ctype)},
                    resource_type="media",
                    resource_id=media_id,
                )
            except BPAClientError as e:
                await audit_logger.mark_failed(audit_id, str(e))
                if getattr(e, "status_code", None) == 415:
                    body = _coerce_body(getattr(e, "response_body", None))
                    raise ToolError(
                        f"Replace rejected: MIME mismatch. "
                        f"declared={body.get('declared')}, "
                        f"detected={body.get('detected')}."
                    ) from e
                raise translate_error(
                    e, resource_type="media", resource_id=media_id
                ) from e

            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="media",
                object_id=str(media_id),
                previous_state={
                    "id": media_id,
                    "_operation": "update",
                    "_irreversible": True,
                },
            )
            await audit_logger.mark_success(
                audit_id,
                result={"media_id": media_id, "name": data.get("name")},
            )

            result = _transform_media_response(data)
            result["audit_id"] = audit_id
            return result

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="media", resource_id=media_id) from e


async def media_delete(
    media_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a media file. Audited destructive operation. Irreversible.

    On HTTP 409 (file referenced by one or more buttons), the response
    carries the list of `usages` and the file is NOT deleted — the caller
    must detach those references before retrying.

    Args:
        media_id: Media file UUID.
        instance: Instance profile name.

    Returns:
        dict with media_id, deleted (bool), audit_id, plus usages (list)
        if delete was refused.
    """
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                await client.get(
                    "/media/{id}",
                    path_params={"id": media_id},
                    resource_type="media",
                    resource_id=media_id,
                )
            except BPANotFoundError:
                raise ToolError(
                    f"Media file '{media_id}' not found. "
                    "Use 'media_list' to see available files."
                ) from None

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="delete",
                object_type="media",
                params={"media_id": media_id, "_irreversible": True},
            )

            try:
                await client.delete(
                    "/media/{id}",
                    path_params={"id": media_id},
                    resource_type="media",
                    resource_id=media_id,
                )
            except BPAClientError as e:
                if getattr(e, "status_code", None) == 409:
                    body = _coerce_body(getattr(e, "response_body", None))
                    raw_usages = body.get("usages") or []
                    if not isinstance(raw_usages, list):
                        raw_usages = []
                    usages = [_transform_usage_response(u) for u in raw_usages]
                    await audit_logger.mark_failed(
                        audit_id,
                        f"Media file in use ({len(usages)} reference(s))",
                    )
                    return {
                        "media_id": media_id,
                        "deleted": False,
                        "usages": usages,
                        "audit_id": audit_id,
                    }
                await audit_logger.mark_failed(audit_id, str(e))
                raise translate_error(
                    e, resource_type="media", resource_id=media_id
                ) from e

            await audit_logger.mark_success(audit_id, result={"media_id": media_id})
            return {
                "media_id": media_id,
                "deleted": True,
                "audit_id": audit_id,
            }

    except ToolError:
        raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="media", resource_id=media_id) from e


# ---- REGISTRATION -------------------------------------------------------


def register_media_tools(mcp: Any) -> None:
    """Register media tools with the MCP server.

    Args:
        mcp: The FastMCP server instance.
    """
    from mcp_eregistrations_bpa.tools.annotations import DESTRUCTIVE, READ, WRITE

    # Read operations
    mcp.tool(annotations=READ)(media_list)
    mcp.tool(annotations=READ)(media_get)
    mcp.tool(annotations=READ)(media_usages)
    mcp.tool(annotations=READ)(media_public_url)
    # Write operations (audit-before-write, irreversible)
    mcp.tool(annotations=WRITE)(media_upload)
    mcp.tool(annotations=WRITE)(media_replace)
    mcp.tool(annotations=DESTRUCTIVE)(media_delete)
