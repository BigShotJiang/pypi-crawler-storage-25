"""ComponentFormula CRUD tools for BPA MCP.

Tools for the Formula tab on form fields. Backend stores `infix` opaquely
as @Column(TEXT) — wire-stable for any function or operator the BPA UI
exposes. See spec at docs/plans/2026-05-10-issue-158-componentformula-crud.md.

CRITICAL — row-ID instability:
    Backend `update()` does `clear() + addAll()` (ComponentFormulaController:69-70).
    With @OneToMany(orphanRemoval=true), JPA physically deletes ALL old
    FormulaRow entities and inserts new ones on every PUT. Every PUT
    regenerates every row's UUID. Callers MUST NOT cache row IDs across
    writes. Use sort_order or content for cross-write tracking.

CRITICAL — wire format:
    - `infix`, `pretty_print_infix_formula`, `json_determinants`: plain strings.
    - `json_logic`, `meta`: JSON objects on the wire (@JsonRawValue +
      JsonNode setter). MCP accepts dicts; do NOT stringify.
    - `;;` is the token separator inside `infix`.
"""

from __future__ import annotations

import re
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.audit.context import (
    NotAuthenticatedError,
    get_current_user_email,
)
from mcp_eregistrations_bpa.audit.logger import AuditLogger
from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import (
    BPAClientError,
    BPANotFoundError,
    translate_error,
)
from mcp_eregistrations_bpa.config import resolve_db_path
from mcp_eregistrations_bpa.constants.form_endpoints import FORM_ENDPOINTS
from mcp_eregistrations_bpa.tools._form_shared import parse_form_schema
from mcp_eregistrations_bpa.tools._infix_helpers import (
    _compute_pretty_print,
    _validate_infix,
    _validate_json_determinants_shape,
)

# Matches `"determinantId":"<uuid>"` (allows optional whitespace around colon).
# Used by _translate_row_determinants to extract referenced determinant UUIDs
# from the json_determinants string for cross-service formula copy.
_DETERMINANT_ID_RE = re.compile(r'"determinantId"\s*:\s*"([^"]+)"')


def _transform_formula_row(row: dict[str, Any]) -> dict[str, Any]:
    """Transform a FormulaRow camelCase payload to snake_case MCP shape.

    json_logic and meta arrive as native JSON objects (per @JsonRawValue) —
    keep them as dicts. Other fields stay as strings.
    """
    return {
        "id": row.get("id"),
        "json_determinants": row.get("jsonDeterminants"),
        "infix": row.get("infix"),
        "pretty_print_infix_formula": row.get("prettyPrintInfixFormula"),
        "json_logic": row.get("jsonLogic"),  # dict (or None)
        "meta": row.get("meta"),  # dict (or None)
        "sort_order": row.get("sortOrder"),
    }


def _transform_componentformula(payload: dict[str, Any]) -> dict[str, Any]:
    """Transform a ComponentFormula camelCase payload to snake_case MCP shape."""
    rows = payload.get("formulaRows") or []
    return {
        "id": payload.get("id"),
        "service_id": payload.get("serviceId"),
        "component_key": payload.get("componentKey"),
        "rows": [_transform_formula_row(r) for r in rows],
    }


async def componentformula_get(
    service_id: str,
    component_key: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Fetch the component formula for a form field.

    Args:
        service_id: BPA service UUID.
        component_key: Form-component key (e.g., "myField").
        instance: Target instance name (default: configured default).

    Returns:
        dict with id, service_id, component_key, rows (list).
    """
    try:
        async with BPAClient.for_instance(instance) as client:
            try:
                payload = await client.get(
                    "/service/{service_id}/componentformulas/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
            except BPANotFoundError as e:
                raise ToolError(
                    f"No component formula found for service '{service_id}', "
                    f"component_key '{component_key}'. Verify the component "
                    f"exists via form_component_get; create the formula via "
                    f"componentformula_upsert."
                ) from e
            if payload is None:
                raise ToolError(
                    f"No component formula found for service '{service_id}', "
                    f"component_key '{component_key}'. Verify the component "
                    f"exists via form_component_get; create the formula via "
                    f"componentformula_upsert."
                )
            return _transform_componentformula(payload)
    except BPAClientError as e:
        raise translate_error(e, resource_type="component_formula") from e


def _preflight_validate_rows(rows: list[dict[str, Any]]) -> None:
    """Validate row payloads BEFORE any audit log entry.

    For each row: validate infix shape and json_determinants shape. Failure
    here means no audit row is created (preserves audit-log signal-to-noise).

    Args:
        rows: List of row dicts (snake_case, MCP shape).

    Raises:
        ToolError: prefixed with ``Row {i}:`` so the caller knows which row failed.
    """
    for i, row in enumerate(rows):
        try:
            _validate_infix(row.get("infix") or "")
            jd = row.get("json_determinants")
            if jd is not None:
                _validate_json_determinants_shape(jd)
        except ToolError as e:
            raise ToolError(f"Row {i}: {e}") from e


async def _preflight_validate_service(client: BPAClient, service_id: str) -> None:
    """Verify the service exists. Raises ToolError if not."""
    try:
        await client.get(
            "/service/{id}",
            path_params={"id": service_id},
            resource_type="service",
            resource_id=service_id,
        )
    except BPANotFoundError as e:
        raise ToolError(
            f"Service '{service_id}' not found. Use service_list() to "
            f"discover available services."
        ) from e


def _walk_components(node: Any, target_key: str) -> bool:
    """Recursively walk a Form.io component tree looking for ``target_key``.

    Form.io children live under:
    - ``components`` (most containers)
    - ``columns[].components`` (columns layout)
    - ``tabs[]`` (some BPA schemas use this sibling-key for tab panes;
      matches ``formio_helpers.find_component`` lines 246-257)
    - ``rows[][]`` (table layout — each row is a list of cells, each cell
      is a dict whose ``components`` we walk further)

    Args:
        node: Either a single component dict, a list of components, or
            None. Bare strings/numbers are ignored.
        target_key: The component key to find.

    Returns:
        True if any descendant (or the node itself) has ``key == target_key``.
    """
    if isinstance(node, dict):
        if node.get("key") == target_key:
            return True
        # Direct children under "components"
        children = node.get("components")
        if isinstance(children, list):
            for c in children:
                if _walk_components(c, target_key):
                    return True
        # columns[].components
        cols = node.get("columns")
        if isinstance(cols, list):
            for col in cols:
                if isinstance(col, dict):
                    for c in col.get("components") or []:
                        if _walk_components(c, target_key):
                            return True
        # tabs[] — some BPA schemas use 'tabs' as a sibling to 'components'.
        # Matches formio_helpers.find_component (lines 246-257).
        tabs = node.get("tabs")
        if isinstance(tabs, list):
            for tab in tabs:
                if _walk_components(tab, target_key):
                    return True
        # rows[][] — rows[i][j] is a cell dict with .components
        rows = node.get("rows")
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, list):
                    for cell in row:
                        if _walk_components(cell, target_key):
                            return True
    elif isinstance(node, list):
        for c in node:
            if _walk_components(c, target_key):
                return True
    return False


async def _preflight_validate_component_key(
    client: BPAClient, service_id: str, component_key: str
) -> None:
    """Verify ``component_key`` exists in some form / role_form / print_doc.

    Scans all 4 form types (applicant, guide, send_file, payment), every role
    form via /service/{service_id}/role, and every print doc via
    /service/{service_id}/print-documents. Returns on first match; raises
    ToolError if not found anywhere.

    Backend has no enforcement: a PUT against an unknown component_key creates
    an orphan formula that breaks at service-publish time. This pre-flight
    surfaces the typo at MCP boundary instead.

    Args:
        client: BPAClient instance (caller manages the async context).
        service_id: BPA service UUID.
        component_key: The Form.io component key to find.

    Raises:
        ToolError: When ``component_key`` is not found in any form.
    """
    # 1-4. Four form types. Stop on first match.
    for endpoint in tuple(cfg["get_endpoint"] for cfg in FORM_ENDPOINTS.values()):
        try:
            form_data = await client.get(
                endpoint,
                path_params={"id": service_id},
                resource_type="form",
                resource_id=service_id,
            )
            schema = parse_form_schema(form_data)
            if _walk_components(schema.get("components", []), component_key):
                return
        except BPANotFoundError:
            # This form type isn't configured for the service — try next.
            continue

    # 5. Role forms (list).
    try:
        roles = await client.get(
            "/service/{service_id}/role",
            path_params={"service_id": service_id},
            resource_type="role",
            resource_id=service_id,
        )
        # Handle either list response or {content: [...]} pageable shape.
        role_list = (
            roles if isinstance(roles, list) else (roles or {}).get("content") or []
        )
        for role in role_list:
            schema = parse_form_schema(role)
            if _walk_components(schema.get("components", []), component_key):
                return
    except BPANotFoundError:
        pass

    # 6. Print documents — list returns metadata-only DTOs (no formSchema),
    # so we must fetch each individually via GET /print-documents/{id}.
    # Verified against PrintDocumentFormController.java:143-155 +
    # PrintDocumentFormDto.java:12-45 (no formSchema on the list DTO).
    try:
        docs = await client.get(
            "/service/{id}/print-documents",
            path_params={"id": service_id},
            resource_type="print_document",
            resource_id=service_id,
        )
        doc_list = docs if isinstance(docs, list) else (docs or {}).get("content") or []
        for doc_meta in doc_list:
            doc_id = doc_meta.get("id")
            if not doc_id:
                continue
            try:
                doc = await client.get(
                    "/print-documents/{id}",
                    path_params={"id": doc_id},
                    resource_type="print_document",
                    resource_id=str(doc_id),
                )
            except BPANotFoundError:
                # Doc deleted between list-fetch and individual-fetch — skip.
                continue
            schema = parse_form_schema(doc)
            if _walk_components(schema.get("components", []), component_key):
                return
    except BPANotFoundError:
        pass

    raise ToolError(
        f"component_key '{component_key}' not found in any form, role_form, "
        f"or print_document of service '{service_id}'. Verify the component "
        f"exists via form_component_get."
    )


def _to_backend_row(row: dict[str, Any]) -> dict[str, Any]:
    """Build the FormulaRow camelCase payload sent to the backend.

    - infix, prettyPrintInfixFormula, jsonDeterminants: plain strings.
    - jsonLogic, meta: JSON objects (per @JsonRawValue + JsonNode setter).
    - Auto-compute prettyPrintInfixFormula when caller omits it.
    """
    pretty = row.get("pretty_print_infix_formula")
    if pretty is None:
        pretty = _compute_pretty_print(row.get("infix") or "")
    out: dict[str, Any] = {
        "infix": row.get("infix"),
        "prettyPrintInfixFormula": pretty,
        "sortOrder": row.get("sort_order"),
    }
    if "json_determinants" in row:
        out["jsonDeterminants"] = row["json_determinants"]
    if "json_logic" in row:
        out["jsonLogic"] = row["json_logic"]
    if "meta" in row:
        out["meta"] = row["meta"]
    if "id" in row:
        out["id"] = row["id"]
    return out


async def componentformula_upsert(
    service_id: str,
    component_key: str,
    rows: list[dict[str, Any]],
    instance: str | None = None,
) -> dict[str, Any]:
    """Create or replace the component formula for a form field.

    Audited write operation. Passing rows=[] triggers backend's
    implicit-delete when a formula already exists, or returns a no-op dict
    when there is nothing to delete.

    Args:
        service_id: BPA service UUID.
        component_key: Form-component key (e.g., "myField").
        rows: List of row payloads. Each: json_determinants (string),
            infix (string), json_logic (dict), meta (dict),
            sort_order (int), pretty_print_infix_formula (optional string).
        instance: Target instance name.

    Returns:
        dict in one of three shapes:
        - rows-present: {id, service_id, component_key, rows, audit_id}
        - empty rows + existing formula: {deleted: true, audit_id}
        - empty rows + no formula:       {no_op: true, reason, audit_id}
    """
    # Pre-flight validation — no audit on failure
    _preflight_validate_rows(rows)

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            await _preflight_validate_service(client, service_id)
            await _preflight_validate_component_key(client, service_id, component_key)

            # Capture before-state for rollback
            try:
                before_state = await client.get(
                    "/service/{service_id}/componentformulas/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
            except BPANotFoundError:
                before_state = None

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="upsert",
                object_type="component_formula",
                params={
                    "service_id": service_id,
                    "component_key": component_key,
                    "rows": rows,
                },
                object_id=f"{service_id}/{component_key}",
            )
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="component_formula",
                object_id=f"{service_id}/{component_key}",
                previous_state={"before_state": before_state},
            )

            try:
                if rows:
                    body = {
                        "componentKey": component_key,
                        "formulaRows": [_to_backend_row(r) for r in rows],
                    }
                    response = await client.put(
                        "/service/{service_id}/componentformulas/{component_key}",
                        path_params={
                            "service_id": service_id,
                            "component_key": component_key,
                        },
                        json=body,
                        resource_type="component_formula",
                        resource_id=f"{service_id}/{component_key}",
                    )
                    transformed = _transform_componentformula(response or {})
                    transformed["audit_id"] = audit_id
                    await audit_logger.mark_success(audit_id, transformed)
                    return transformed
                else:
                    # Empty rows path — distinguishes "deleted existing" from
                    # "no-op on missing" (per spec § 5).
                    if before_state is None:
                        result = {
                            "no_op": True,
                            "reason": (
                                "no formula exists and rows=[]; nothing to delete"
                            ),
                            "audit_id": audit_id,
                        }
                        await audit_logger.mark_success(audit_id, result)
                        return result
                    # Existing formula → backend's empty-rows-delete branch
                    body = {
                        "componentKey": component_key,
                        "formulaRows": [],
                    }
                    await client.put(
                        "/service/{service_id}/componentformulas/{component_key}",
                        path_params={
                            "service_id": service_id,
                            "component_key": component_key,
                        },
                        json=body,
                        resource_type="component_formula",
                        resource_id=f"{service_id}/{component_key}",
                    )
                    result = {"deleted": True, "audit_id": audit_id}
                    await audit_logger.mark_success(audit_id, result)
                    return result
            except Exception as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="component_formula") from e


async def componentformula_delete(
    service_id: str,
    component_key: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete the component formula for a form field. Audited write operation.

    Idempotent: returns {deleted: false, note} when no formula exists,
    without raising. DELETE only runs when the formula is confirmed to exist.

    Args:
        service_id: BPA service UUID.
        component_key: Form-component key (e.g., "myField").
        instance: Target instance name (default: configured default).

    Returns:
        dict with deleted (bool), audit_id, and optional note.
    """
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            await _preflight_validate_service(client, service_id)
            await _preflight_validate_component_key(client, service_id, component_key)

            # Capture before-state for rollback (None = no formula exists)
            try:
                before_state = await client.get(
                    "/service/{service_id}/componentformulas/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
            except BPANotFoundError:
                before_state = None

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="delete",
                object_type="component_formula",
                params={
                    "service_id": service_id,
                    "component_key": component_key,
                },
                object_id=f"{service_id}/{component_key}",
            )
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="component_formula",
                object_id=f"{service_id}/{component_key}",
                previous_state={"before_state": before_state},
            )

            try:
                if before_state is None:
                    result = {
                        "deleted": False,
                        "note": "formula not found — nothing to delete",
                        "audit_id": audit_id,
                    }
                    await audit_logger.mark_success(audit_id, result)
                    return result

                await client.delete(
                    "/service/{service_id}/componentformula/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
                result = {"deleted": True, "audit_id": audit_id}
                await audit_logger.mark_success(audit_id, result)
                return result
            except Exception as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="component_formula") from e


async def componentformula_row_create(
    service_id: str,
    component_key: str,
    row: dict[str, Any],
    position: int | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Insert a new row into a component formula. Audited write operation.

    Read-modify-write on top of the bulk PUT (no row-level backend endpoint).
    NOTE: Row UUIDs are NOT stable — every PUT regenerates all row UUIDs
    (spec § 4a). This tool returns the FULL post-write rows list with new IDs.

    Args:
        service_id: BPA service UUID.
        component_key: Form-component key.
        row: Row payload (json_determinants, infix, json_logic, meta).
            Any caller-supplied ``sort_order`` is IGNORED: append mode
            always uses max+1; insert mode always uses ``position``. Any
            caller-supplied ``id`` is IGNORED (backend regenerates all
            UUIDs per spec § 4a).
        position: 0-based insertion position. None = append at end.
        instance: Target instance name.

    Returns:
        dict with row_id, sort_order, rows (full post-write list), audit_id.
    """
    # Pre-flight validation — no audit on failure
    _preflight_validate_rows([row])

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            await _preflight_validate_service(client, service_id)
            await _preflight_validate_component_key(client, service_id, component_key)

            # Read current state
            try:
                current = await client.get(
                    "/service/{service_id}/componentformulas/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
            except BPANotFoundError:
                current = None

            # Build new rows list from current state (strip IDs — backend regenerates)
            existing_rows: list[dict[str, Any]] = []
            if current:
                for r in current.get("formulaRows") or []:
                    tr = _transform_formula_row(r)
                    tr.pop("id", None)
                    existing_rows.append(tr)

            if position is None:
                # Append mode: auto-assign sort_order = max + 1
                max_so = max(
                    (r.get("sort_order") or 0 for r in existing_rows), default=-1
                )
                new_sort_order = max_so + 1
                new_row = dict(row)
                new_row.pop("id", None)  # spec § 4a — backend regenerates all UUIDs
                new_row["sort_order"] = new_sort_order
                new_rows = existing_rows + [new_row]
            else:
                # Insert mode: renumber existing rows at i >= position, then insert
                renumbered: list[dict[str, Any]] = []
                for r in existing_rows:
                    so = r.get("sort_order") or 0
                    if so >= position:
                        r = dict(r)
                        r["sort_order"] = so + 1
                    renumbered.append(r)
                new_sort_order = position
                new_row = dict(row)
                new_row.pop("id", None)  # spec § 4a — backend regenerates all UUIDs
                new_row["sort_order"] = new_sort_order
                new_rows = renumbered + [new_row]

            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="create",
                object_type="component_formula_row",
                params={
                    "service_id": service_id,
                    "component_key": component_key,
                    "row": row,
                    "position": position,
                },
                object_id=f"{service_id}/{component_key}",
            )
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="component_formula_row",
                object_id=f"{service_id}/{component_key}",
                previous_state={"before_state": current},
            )

            try:
                body = {
                    "componentKey": component_key,
                    "formulaRows": [_to_backend_row(r) for r in new_rows],
                }
                response = await client.put(
                    "/service/{service_id}/componentformulas/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    json=body,
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
                transformed = _transform_componentformula(response or {})

                # Identify the new row in the post-write list by sort_order
                # (UUIDs changed — match by content)
                created_row = next(
                    (
                        r
                        for r in transformed["rows"]
                        if r.get("sort_order") == new_sort_order
                    ),
                    None,
                )
                result: dict[str, Any] = {
                    "row_id": created_row["id"] if created_row else None,
                    "sort_order": new_sort_order,
                    "rows": transformed["rows"],
                    "audit_id": audit_id,
                }
                await audit_logger.mark_success(audit_id, result)
                return result
            except Exception as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="component_formula") from e


async def componentformula_row_update(
    service_id: str,
    component_key: str,
    row_id: str,
    patch: dict[str, Any],
    instance: str | None = None,
) -> dict[str, Any]:
    """Update a single row in a component formula. Audited write operation.

    Read-modify-write. row_id is valid only as of the immediately-prior
    componentformula_get or row_create response (UUIDs change on every PUT —
    spec § 4a). Returned row_id is the NEW UUID after the write; callers
    should use it for subsequent updates.

    Args:
        service_id: BPA service UUID.
        component_key: Form-component key.
        row_id: UUID of the row to update (as of last fetch/create). Raises
            ToolError if not found in the current formula state.
        patch: Partial dict of fields to update (infix, json_determinants,
            json_logic, meta, sort_order). Fields not in the patch retain
            their existing values. Any caller-supplied `id` is IGNORED
            (backend regenerates all UUIDs per spec § 4a).
        instance: Target instance name.

    Returns:
        dict with row_id (NEW post-write UUID), sort_order, rows (full
        post-write list), audit_id.
    """
    # Pre-flight validation — no audit on failure
    patch_fields = {
        k: v for k, v in patch.items() if k in ("infix", "json_determinants")
    }
    if patch_fields:
        _preflight_validate_rows([patch_fields])

    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            await _preflight_validate_service(client, service_id)
            await _preflight_validate_component_key(client, service_id, component_key)

            # Read current state
            try:
                current = await client.get(
                    "/service/{service_id}/componentformulas/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
            except BPANotFoundError:
                current = None

            current_rows: list[dict[str, Any]] = (
                current.get("formulaRows") or [] if current else []
            )

            # Find target row by id
            target_idx = next(
                (i for i, r in enumerate(current_rows) if r.get("id") == row_id),
                None,
            )
            if target_idx is None:
                existing_ids = [r.get("id") for r in current_rows]
                raise ToolError(
                    f"Row '{row_id}' not found in formula. "
                    f"Existing row IDs: {existing_ids}. "
                    "Note: row UUIDs change on every PUT (spec § 4a) — "
                    "re-fetch via componentformula_get."
                )

            # Build new rows list: transform all to snake_case + strip id,
            # apply patch to target row
            new_rows: list[dict[str, Any]] = []
            target_sort_order: int | None = None
            for i, r in enumerate(current_rows):
                snake = _transform_formula_row(r)
                snake.pop("id", None)
                if i == target_idx:
                    snake.update(patch)
                    snake.pop(
                        "id", None
                    )  # Task-13 lesson: strip any id the patch may carry
                    # Task-25 live-probe finding: if caller patched ``infix``
                    # but did not override ``pretty_print_infix_formula``,
                    # drop the stale pretty_print carried from the prior
                    # write so ``_to_backend_row`` recomputes it from the
                    # new infix via ``_compute_pretty_print``. Without this,
                    # the destination row keeps the OLD pretty_print, which
                    # is what the UI displays on read-back.
                    if "infix" in patch and "pretty_print_infix_formula" not in patch:
                        snake.pop("pretty_print_infix_formula", None)
                    target_sort_order = snake.get("sort_order")
                new_rows.append(snake)

            # Audit (pre-write, real signatures D5-D7)
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="update",
                object_type="component_formula_row",
                params={
                    "service_id": service_id,
                    "component_key": component_key,
                    "row_id": row_id,
                    "patch": patch,
                },
                object_id=f"{service_id}/{component_key}",
            )
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="component_formula_row",
                object_id=f"{service_id}/{component_key}",
                previous_state={"before_state": current},
            )

            try:
                body = {
                    "componentKey": component_key,
                    "formulaRows": [_to_backend_row(r) for r in new_rows],
                }
                response = await client.put(
                    "/service/{service_id}/componentformulas/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    json=body,
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
                transformed = _transform_componentformula(response or {})

                # Identify the updated row in post-write list by sort_order match
                # (UUIDs changed — spec § 4a)
                updated_row = next(
                    (
                        r
                        for r in transformed["rows"]
                        if r.get("sort_order") == target_sort_order
                    ),
                    None,
                )
                result: dict[str, Any] = {
                    "row_id": updated_row["id"] if updated_row else None,
                    "sort_order": target_sort_order,
                    "rows": transformed["rows"],
                    "audit_id": audit_id,
                }
                await audit_logger.mark_success(audit_id, result)
                return result
            except Exception as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="component_formula") from e


async def componentformula_row_delete(
    service_id: str,
    component_key: str,
    row_id: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a single row from a component formula. Audited write operation.

    Read-modify-write. row_id is valid only as of the immediately-prior
    componentformula_get or row_create response (UUIDs change on every PUT —
    spec § 4a).

    When the deleted row was the LAST row, the bulk PUT sends an empty rows
    list, which triggers backend's empty-rows-implicit-delete (per spec § 5):
    the entire formula record is removed. The response surfaces this with
    `formula_deleted: True`.

    Args:
        service_id: BPA service UUID.
        component_key: Form-component key.
        row_id: UUID of the row to delete (as of last fetch/create). Raises
            ToolError if not found in the current formula state.
        instance: Target instance name.

    Returns:
        dict in one of two shapes:
        - normal delete: {removed: row_id, remaining: int, rows: [...], audit_id}
        - last-row delete: {removed: row_id, remaining: 0,
          formula_deleted: True, audit_id}
    """
    # Pre-flight validation — no audit on failure
    try:
        user_email = get_current_user_email(instance=instance)
    except NotAuthenticatedError as e:
        raise ToolError(str(e)) from e

    try:
        async with BPAClient.for_instance(instance) as client:
            await _preflight_validate_service(client, service_id)
            await _preflight_validate_component_key(client, service_id, component_key)

            # Read current state
            try:
                current = await client.get(
                    "/service/{service_id}/componentformulas/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
            except BPANotFoundError:
                current = None

            current_rows: list[dict[str, Any]] = (
                current.get("formulaRows") or [] if current else []
            )

            # Find target row by id — BEFORE record_pending (spec §4a)
            target_idx = next(
                (i for i, r in enumerate(current_rows) if r.get("id") == row_id),
                None,
            )
            if target_idx is None:
                existing_ids = [r.get("id") for r in current_rows]
                raise ToolError(
                    f"Row '{row_id}' not found in formula. "
                    f"Existing row IDs: {existing_ids}. "
                    "Note: row UUIDs change on every PUT (spec § 4a) — "
                    "re-fetch via componentformula_get."
                )

            # Build new rows list (without the target row)
            new_rows: list[dict[str, Any]] = [
                _transform_formula_row(r)
                for i, r in enumerate(current_rows)
                if i != target_idx
            ]
            for r in new_rows:
                r.pop("id", None)

            # Audit (pre-write, real signatures D5-D7)
            audit_logger = AuditLogger(db_path=resolve_db_path(instance))
            audit_id = await audit_logger.record_pending(
                user_email=user_email,
                operation_type="delete",
                object_type="component_formula_row",
                params={
                    "service_id": service_id,
                    "component_key": component_key,
                    "row_id": row_id,
                },
                object_id=f"{service_id}/{component_key}",
            )
            await audit_logger.save_rollback_state(
                audit_id=audit_id,
                object_type="component_formula_row",
                object_id=f"{service_id}/{component_key}",
                previous_state={"before_state": current},
            )

            try:
                body = {
                    "componentKey": component_key,
                    "formulaRows": [_to_backend_row(r) for r in new_rows],
                }
                response = await client.put(
                    "/service/{service_id}/componentformulas/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    json=body,
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )

                # Build result — two terminal branches based on last-row deletion
                if not new_rows:
                    # Empty-rows PUT triggers backend's implicit delete (spec § 5).
                    # The PUT response echoes the pre-delete state — we ignore it.
                    result: dict[str, Any] = {
                        "removed": row_id,
                        "remaining": 0,
                        "formula_deleted": True,
                        "audit_id": audit_id,
                    }
                else:
                    transformed = _transform_componentformula(response or {})
                    result = {
                        "removed": row_id,
                        "remaining": len(transformed["rows"]),
                        "rows": transformed["rows"],
                        "audit_id": audit_id,
                    }

                await audit_logger.mark_success(audit_id, result)
                return result
            except Exception as e:
                await audit_logger.mark_failed(audit_id, str(e))
                raise
    except BPAClientError as e:
        raise translate_error(e, resource_type="component_formula") from e


def register_component_formula_tools(mcp: Any) -> None:
    """Register component formula tools with the MCP server.

    Args:
        mcp: The FastMCP server instance.
    """
    from mcp_eregistrations_bpa.tools.annotations import DESTRUCTIVE, READ, WRITE

    # Read operations
    mcp.tool(annotations=READ)(componentformula_get)

    # Write operations
    mcp.tool(annotations=WRITE)(componentformula_upsert)
    mcp.tool(annotations=WRITE)(componentformula_row_create)
    mcp.tool(annotations=WRITE)(componentformula_row_update)

    # Destructive operations
    mcp.tool(annotations=DESTRUCTIVE)(componentformula_delete)
    mcp.tool(annotations=DESTRUCTIVE)(componentformula_row_delete)


def _rows_content_match(
    a: list[dict[str, Any]] | None,
    b: list[dict[str, Any]] | None,
) -> bool:
    """Compare row contents (infix + sort_order + json_determinants), ignoring UUIDs.

    Row UUIDs change on every PUT (per spec § 4a). Compare by content to detect
    actual drift. Both inputs are expected to be snake_case row dicts (per
    _transform_formula_row); the caller in _apply_componentformula_rollback
    normalizes the raw GET response before passing it here.
    """
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    if len(a) != len(b):
        return False
    # Sort by sort_order for stable comparison
    sa = sorted(a, key=lambda r: r.get("sort_order") or 0)
    sb = sorted(b, key=lambda r: r.get("sort_order") or 0)
    for ra, rb in zip(sa, sb, strict=True):
        if ra.get("infix") != rb.get("infix"):
            return False
        if ra.get("json_determinants") != rb.get("json_determinants"):
            return False
        if (ra.get("sort_order") or 0) != (rb.get("sort_order") or 0):
            return False
    return True


async def _apply_componentformula_rollback(
    instance: str | None,
    service_id: str,
    component_key: str,
    before_state: dict[str, Any] | None,
    post_write_state: dict[str, Any] | None,
) -> None:
    """Rollback handler with drift protection (per spec § 9).

    Refuses to apply rollback if a concurrent save has changed the formula
    since the MCP write. Logs a clear warning so the user can recover manually
    from the audit log.
    """
    async with BPAClient.for_instance(instance) as client:
        # Re-fetch current state
        try:
            current = await client.get(
                "/service/{service_id}/componentformulas/{component_key}",
                path_params={"service_id": service_id, "component_key": component_key},
                resource_type="component_formula",
                resource_id=f"{service_id}/{component_key}",
            )
        except BPANotFoundError:
            current = None

        # Compare against post_write_state (what MCP wrote, modulo UUID changes).
        # `current` is the raw GET response (camelCase from the backend).
        # `post_write_state` is the audit log's `result` field, which was stored
        # via _transform_componentformula — snake_case throughout (`rows` not
        # `formulaRows`; `json_determinants` not `jsonDeterminants`; `sort_order`
        # not `sortOrder`). Normalize `current` to the same snake_case shape so
        # _rows_content_match can do apples-to-apples comparison.
        # When the formula has no rows (or no post_write_state), use None on
        # both sides so the helper's both-None branch returns True (rather than
        # treating None vs [] as a mismatch).
        post_rows = (post_write_state or {}).get("rows") or None
        raw_cur_rows = (current or {}).get("formulaRows") if current else None
        cur_rows = (
            [_transform_formula_row(r) for r in raw_cur_rows] if raw_cur_rows else None
        )
        if not _rows_content_match(post_rows, cur_rows):
            raise ToolError(
                "Rollback refused: external save detected since MCP write. "
                "Before-state preserved in audit log for manual recovery."
            )

        # Apply before_state
        if before_state is None:
            # MCP created the formula; rollback deletes it.
            # If `current is None` here, the drift check already returned True
            # for both-None and there's nothing to delete; if `current is not
            # None`, the formula still exists and we delete it. Any
            # BPANotFoundError now means the service itself is gone —
            # propagate honestly (backend only 404s on missing service, not
            # missing formula; see ComponentFormulaController.java:111-123).
            if current is not None:
                await client.delete(
                    "/service/{service_id}/componentformula/{component_key}",
                    path_params={
                        "service_id": service_id,
                        "component_key": component_key,
                    },
                    resource_type="component_formula",
                    resource_id=f"{service_id}/{component_key}",
                )
        else:
            # MCP modified the formula; rollback restores the rows.
            body = {
                "componentKey": component_key,
                "formulaRows": before_state.get("formulaRows") or [],
            }
            await client.put(
                "/service/{service_id}/componentformulas/{component_key}",
                path_params={"service_id": service_id, "component_key": component_key},
                json=body,
                resource_type="component_formula",
                resource_id=f"{service_id}/{component_key}",
            )


def _translate_row_determinants(
    row: dict[str, Any],
    alias_map: dict[str, str],
    on_orphan: str = "skip",
) -> tuple[dict[str, Any] | None, list[str]]:
    """Translate `determinantId` references in a row's json_determinants.

    Used by cross-service component-formula copy (Tasks 19-21 in the
    parallel session): when a row references a determinant by its
    source-service UUID, this rewrites the reference to the destination-
    service UUID via the alias_map already built by the existing copy
    logic.

    Args:
        row: Row payload (snake_case dict).
        alias_map: source_determinant_id -> destination_determinant_id.
        on_orphan: Policy when a referenced ID is not in alias_map:
            - "skip" (default): return (None, orphans) — caller drops row.
            - "preserve": return (row_with_orphan_id_kept, orphans).
            - "error": raise ToolError listing all orphan IDs.

    Returns:
        Tuple of (translated_row_or_None, orphan_id_list).
        - translated_row is None only when on_orphan="skip" AND orphans
          were found.
        - orphan_id_list is empty when every referenced ID was mapped.

    Raises:
        ToolError: When on_orphan="error" and at least one orphan exists.
    """
    jd = row.get("json_determinants")
    if not jd:
        return row, []
    referenced_ids = _DETERMINANT_ID_RE.findall(jd)
    orphans = [i for i in referenced_ids if i not in alias_map]

    if orphans and on_orphan == "error":
        raise ToolError(
            f"Cross-service formula copy hit orphan determinant ID(s) "
            f"{orphans} not in alias map. Either map them, change "
            f"on_orphan_determinant to 'skip' or 'preserve', or use "
            f"component_formula_handling='strip'."
        )
    if orphans and on_orphan == "skip":
        return None, orphans

    # preserve mode (or no orphans): rewrite mapped IDs, leave orphans alone.
    new_jd = jd
    for src_id, dest_id in alias_map.items():
        new_jd = new_jd.replace(f'"{src_id}"', f'"{dest_id}"')
    new_row = dict(row)
    new_row["json_determinants"] = new_jd
    return new_row, orphans
