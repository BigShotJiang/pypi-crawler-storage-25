"""Rollback manager for BPA operations.

This module provides the RollbackManager class for executing rollback operations
on BPA objects. It handles endpoint resolution, state retrieval, and API calls
to restore objects to their previous state.

Rollback strategies by operation type:
- create: DELETE the created object
- update: PUT with previous_state values to restore
- delete: POST to recreate object with previous_state
- link: Reverse the link operation (unlink)
- unlink: Reverse the unlink operation (link)
"""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from mcp_eregistrations_bpa.bpa_client import BPAClient
from mcp_eregistrations_bpa.bpa_client.errors import BPAClientError, BPANotFoundError
from mcp_eregistrations_bpa.constants.form_endpoints import FORM_ENDPOINTS
from mcp_eregistrations_bpa.db import get_connection

__all__ = [
    "RollbackManager",
    "RollbackError",
    "RollbackNotPossibleError",
    "IntentionallyNonRollbackableError",
    "ROLLBACK_ENDPOINTS",
    "_NON_ROLLBACKABLE_EXACT",
    "_NON_ROLLBACKABLE_OP",
    "_NON_ROLLBACKABLE_PREFIX",
    "_CUSTOM_BRANCH_HANDLERS",
]


class RollbackError(Exception):
    """Base exception for rollback operations."""

    pass


class RollbackNotPossibleError(RollbackError):
    """Raised when rollback cannot be performed for a given audit entry."""

    pass


class IntentionallyNonRollbackableError(RollbackNotPossibleError):
    """Raised for audit rows whose object_type is intentionally not rollbackable.

    Distinct from ``RollbackError("Rollback not supported...")`` which means
    "we don't know how to roll this back yet." This error means "we know,
    and we've decided not to" — e.g. notifications (events, not entities),
    idempotent repair operations, irreversible side-effects.

    The ``reason`` attribute carries the policy reason (machine-readable
    short string) so audit consumers can branch on it.
    """

    def __init__(self, message: str, reason: str) -> None:
        super().__init__(message)
        self.reason = reason


# Mapping: object_type -> (delete_endpoint, update_endpoint, create_endpoint)
# Endpoints use {id}, {service_id}, {registration_id} placeholders for substitution
# IMPORTANT: These endpoints must match the actual BPA API specification
# See: _bmad-output/implementation-artifacts/bpa-api-reference.md
ROLLBACK_ENDPOINTS: dict[str, tuple[str | None, str | None, str | None]] = {
    # Service: PUT /service with ID in body, DELETE /service/{id}
    "service": ("/service/{id}", "/service", "/service"),
    # Registration: No PUT endpoint exists in BPA API, create via service
    "registration": (
        "/registration/{id}",
        None,  # No PUT /registration endpoint in BPA API
        "/service/{service_id}/registration",
    ),
    # Determinants: Generic type used by determinant_delete, type-specific used by
    # individual create/update tools. All share the same generic DELETE endpoint.
    # Create endpoint for "determinant" is resolved by _get_create_endpoint using
    # the determinant_type param.
    "determinant": (
        "/service/{service_id}/determinant/{id}",
        None,  # Update is type-specific, use the typed entries below
        None,  # Create is type-specific, handled in _get_create_endpoint
    ),
    "textdeterminant": (
        "/service/{service_id}/determinant/{id}",
        "/service/{service_id}/textdeterminant",
        "/service/{service_id}/textdeterminant",
    ),
    "selectdeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/selectdeterminant",
    ),
    "radiodeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/radiodeterminant",
    ),
    "booleandeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/booleandeterminant",
    ),
    "numericdeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/numericdeterminant",
    ),
    "datedeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/datedeterminant",
    ),
    "classificationdeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/classificationdeterminant",
    ),
    "griddeterminant": (
        "/service/{service_id}/determinant/{id}",
        None,
        "/service/{service_id}/griddeterminant",
    ),
    # Bot: No DELETE endpoint, PUT /bot with ID in body
    "bot": (
        None,  # No DELETE /bot endpoint in BPA API
        "/bot",
        "/service/{service_id}/bot",
    ),
    # Role: DELETE /role/{id}, PUT /role with ID in body
    "role": (
        "/role/{id}",
        "/role",
        "/service/{service_id}/role",
    ),
    # Document Requirement: Uses underscore in endpoint path
    "documentrequirement": (
        "/document_requirement/{id}",
        "/document_requirement",
        "/registration/{registration_id}/document_requirement",
    ),
    # Cost: DELETE /cost/{id}, PUT /cost with ID in body
    # Note: Create has fixcost/formulacost variants, handled by cost_type param
    "cost": (
        "/cost/{id}",
        "/cost",
        None,  # Create endpoint depends on cost_type, handled in _get_create_endpoint
    ),
    # Message: Global templates, DELETE /message/{id}, PUT /message, POST /message
    "message": (
        "/message/{id}",
        "/message",
        "/message",
    ),
    # Classification group (issue #103):
    #   create→DELETE /classification_group/{id} (uses standard branch)
    #   update→PUT /classification_group with body{id,...} — custom branch
    #     strips internal _operation marker before sending
    #   delete→POST /classification_group/{classification_id} + per-field
    #     re-add — custom branch in execute_rollback (the standard
    #     create-on-delete-rollback is insufficient because it can't recreate
    #     the lost ClassificationFieldGroup join rows).
    # The {classification_id} placeholder is substituted by _get_create_endpoint
    # from audit params['classification_id']. Group update has no path id
    # (id goes in body); group delete uses {id} not {classification_id}.
    "classification_group": (
        "/classification_group/{id}",
        "/classification_group",
        "/classification_group/{classification_id}",
    ),
    # Classification field group-set (issue #103):
    # All None — DO NOT REMOVE this entry. The custom branch in
    # execute_rollback dispatches `classification_field` BEFORE the standard
    # endpoint resolvers ever see it. The entry exists solely so the
    # `if object_type not in ROLLBACK_ENDPOINTS` registration check passes.
    # If this entry were dropped, validate_rollback() would reject every
    # entry_set_groups audit row as "not supported".
    "classification_field": (
        None,
        None,
        None,
    ),
    # BotRoleBots: No DELETE endpoint (backend). Delete is implemented as
    # PUT /botrolebots/{id} with actions=[]. See botrolebots module and
    # issue #94. Rollback routed via special-case branch below because the
    # shape doesn't fit the standard (delete, update, create) triple.
    "botrolebots": (
        None,  # Custom delete via PUT with empty actions
        "/botrolebots/{id}",
        "/role/{role_id}/botrolebots",
    ),
    # ComponentFormula + ComponentFormulaRow (issue #158):
    # All None — DO NOT REMOVE these entries. The custom branch in
    # execute_rollback dispatches both object_types to
    # _apply_componentformula_rollback BEFORE the standard endpoint resolvers
    # see them. The entries exist solely so the `if object_type not in
    # ROLLBACK_ENDPOINTS` registration check in validate_rollback() passes.
    # Rollback semantics: re-fetch current state, drift-check against
    # post_write_state, then apply before_state via DELETE (if before_state
    # is None — formula was created) or PUT (if before_state existed —
    # formula was modified or deleted).
    "component_formula": (None, None, None),
    "component_formula_row": (None, None, None),
    # Forms (issue #169): all three audit object_types share the same rollback
    # semantics — PUT the previous form envelope back to the form_type-specific
    # endpoint. Endpoints differ per form_type (applicant/guide/send_file/payment),
    # so they're resolved dynamically from FORM_ENDPOINTS in
    # _get_update_endpoint's special-case branch. Entries exist solely so the
    # `if object_type not in ROLLBACK_ENDPOINTS` registration check in
    # validate_rollback()/_get_update_endpoint() passes.
    "form": (None, None, None),
    "form_component": (None, None, None),
    "form_component_copy": (None, None, None),
    # Issue #124 — standard CRUD types (live-verified 2026-05-13).
    # Classification: PUT /classification body{id,...}, DELETE /classification/{id}
    "classification": (
        "/classification/{id}",
        "/classification",
        "/classification",
    ),
    # RegistrationInstitution: no PUT endpoint exists; create via registration context
    "registration_institution": (
        "/registration_institution/{id}",
        None,
        "/registration/{registration_id}/registration_institution",
    ),
    # Bot mappings (dynamic literal `type_label = f"bot_{mapping_type}_mapping"`
    # in bot_mappings.py — resolved to two static entries by the CI test).
    # InputMappingController: POST /bot/{bot_id}/input_mapping, PUT /input_mapping/{id},
    # DELETE /input_mapping/{id}
    "bot_input_mapping": (
        "/input_mapping/{id}",
        "/input_mapping/{id}",
        "/bot/{bot_id}/input_mapping",
    ),
    "bot_output_mapping": (
        "/output_mapping/{id}",
        "/output_mapping/{id}",
        "/bot/{bot_id}/output_mapping",
    ),
    # Issue #124 Milestone B — link/unlink operations (live-verified against
    # BPA-backend controllers, 2026-05-13).
    # The `link` rollback strategy: DELETE the link record by its captured id.
    # The `unlink` rollback strategy: POST recreate the link (new id assigned).
    # Update is None for all four — these are link/unlink records, not updatable.
    #
    # RoleUnitController.java:31, 51 — POST creates, DELETE soft-nullifies unitId.
    "role_unit": (
        "/role_unit/{id}",
        None,
        "/role/{role_id}/role_unit",
    ),
    # RoleInstitutionController.java:43, 85 — POST creates with body=institution_id,
    # DELETE removes the link.
    "role_institution": (
        "/role_institution/{id}",
        None,
        "/role/{role_id}/role_institution",
    ),
    # RoleRegistrationController.java:44, 128 — POST creates with body=registration_id,
    # DELETE removes the link.
    "role_registration": (
        "/role_registration/{id}",
        None,
        "/role/{role_id}/role_registration",
    ),
    # ServiceController.java:428, 448 — composite path key, no id in URL.
    "service_registration": (
        "/service_registration/{service_id}/{registration_id}",
        None,
        "/service_registration/{service_id}/{registration_id}",
    ),
    # Issue #124 — Milestone B stubs. These types are dispatched by custom
    # branches (or will be after B-Tx lands). Their (None, None, None) here
    # exists solely so the registration check passes. The RaisingHandler stub
    # branch in execute_rollback intercepts them with a clear "not yet
    # implemented (#124-B)" error.
    "effect": (None, None, None),
    "behaviour": (None, None, None),
    "componentactions": (None, None, None),
    "print_document": (None, None, None),
    "print_document_component": (None, None, None),
    "print_document_component_copy": (None, None, None),
    "print_document_sort": (None, None, None),
    "role_form": (None, None, None),
    "role_form_component_copy": (None, None, None),
    "role_status": (None, None, None),
}

# Alias for document_requirement (audit logs use underscore variant)
ROLLBACK_ENDPOINTS["document_requirement"] = ROLLBACK_ENDPOINTS["documentrequirement"]


# Object_types intentionally NOT rollbackable. Distinct from "not yet
# registered" — these have a verified reason for being unrecoverable via
# the rollback tool. See issue #124 for the audit. Reasons must be
# one-line, user-facing, and machine-readable.
_NON_ROLLBACKABLE_EXACT: dict[str, str] = {
    "notification": "events, not configurable entities",
    "behaviour_metadata_repair": (
        "idempotent repair; undoing reintroduces the inconsistency it fixed"
    ),
    "debug_batch": "composite auto-fix; per-fix reversal is the wrong primitive",
    "media": "media uploads are irreversible (file already in object storage)",
    "institution": (
        "institutions are Keycloak groups, not BPA entities; "
        "recovery via keycloak-mcp.kc_delete_group"
    ),
    # Milestone A promoted link types to full rollback in Milestone B —
    # see ROLLBACK_ENDPOINTS for role_unit/role_institution/role_registration/
    # service_registration and the link/unlink handlers in execute_rollback.
}

# Operation-aware non-rollbackable: (object_type, operation_type) -> reason.
# These are operation_type-aware because the object_type itself has SOME rollback
# coverage (standard CRUD), but specific operations on it don't.
_NON_ROLLBACKABLE_OP: dict[tuple[str, str], str] = {
    ("service", "copy"): (
        "whole-service operation; recovery via service_delete + service_import_on_top"
    ),
    ("service", "import_on_top"): (
        "whole-service operation; recovery via service_delete + re-import"
    ),
    ("service", "repair_roles"): (
        "structural repair on multiple roles; recovery via service-level restore"
    ),
    ("bot", "clone"): "bot lifecycle; recovery via bot_history_revert",
    ("bot", "revert"): "bot history operation; re-apply forward via bot_history_revert",
    ("bot", "upgrade"): "bot lifecycle; recovery via bot_history_revert",
    ("bot", "set_service_version"): (
        "bot lifecycle; recovery via bot_history_revert or bot_set_service_version"
    ),
    # componentaction_delete_by_bot (issue #173) audits the operation
    # but does not call save_rollback_state — there is no captured
    # state for the individual deleted actions, only the bot reference.
    # Recovery: re-create the actions via componentaction_save.
    # The CI completeness test (#124-A) classifies this via _NON_ROLLBACKABLE_OP.
    ("componentactions", "delete_by_bot"): (
        "bulk delete by bot reference does not capture per-action state; "
        "recovery via componentaction_save"
    ),
}

# Prefix-pattern non-rollbackable: object_type startswith key -> reason.
# Used for dynamically-generated audit literals (e.g., the debugger creates
# audit rows with object_type=f"debug_{X}" — see debugger.py).
_NON_ROLLBACKABLE_PREFIX: dict[str, str] = {
    "debug_": "debugger fix; no rollback state captured in tool",
}


def _classify_non_rollbackable(object_type: str, operation_type: str) -> str | None:
    """Return the policy reason if this audit row is non-rollbackable, else None.

    Check order: exact match → op-aware match → prefix match. Returns None if
    no policy applies (the type is rollbackable, registered or not).
    """
    if object_type in _NON_ROLLBACKABLE_EXACT:
        return _NON_ROLLBACKABLE_EXACT[object_type]
    op_key = (object_type, operation_type)
    if op_key in _NON_ROLLBACKABLE_OP:
        return _NON_ROLLBACKABLE_OP[op_key]
    for prefix, reason in _NON_ROLLBACKABLE_PREFIX.items():
        if object_type.startswith(prefix):
            return reason
    return None


# Issue #178: Hibernate optimistic-locking detection for effect.delete rollback.
# When the captured behaviour references a hard-deleted child Effect, PUT
# /behaviour fails with HTTP 500 and a body containing the substring
# "updated or deleted by another transaction" (Hibernate StaleObjectStateException
# / org.hibernate.ObjectOptimisticLockingFailureException). We match on the
# substring rather than the status code alone because BPA returns 500 for
# many other backend errors; the substring is the disambiguating signal.
_HIBERNATE_OPTIMISTIC_LOCK_SIGNAL = "updated or deleted by another transaction"


def _is_hibernate_optimistic_lock_error(error: BPAClientError) -> bool:
    """Return True if `error` is the Hibernate stale-row 500 we care about."""
    if getattr(error, "status_code", None) != 500:
        return False
    return _HIBERNATE_OPTIMISTIC_LOCK_SIGNAL in str(error)


def _strip_child_ids(behaviour: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of `behaviour` with `id` removed and every nested
    effect's `id` removed. Used by the issue #178 fallback so the backend
    treats the POST as a fresh insert and assigns new UUIDs throughout.

    The shape is `{id, componentKey, effects: [{id, ...}, ...], ...}`. We
    DO NOT recurse beyond effect-level — there's no deeper nesting in the
    Behaviour entity that carries Hibernate-managed ids.
    """
    stripped: dict[str, Any] = {k: v for k, v in behaviour.items() if k != "id"}
    effects = stripped.get("effects")
    if isinstance(effects, list):
        stripped["effects"] = [
            {k: v for k, v in eff.items() if k != "id"}
            if isinstance(eff, dict)
            else eff
            for eff in effects
        ]
    return stripped


# Object_types handled by custom branches in execute_rollback (before the
# standard endpoint resolvers see them). Source of truth for the CI
# completeness test — every entry here MUST have a corresponding
# `if object_type == "X"` (or `in {...}`) branch in execute_rollback.
#
# Adding a new entry without a matching branch causes audit rows of that
# type to silently fall through to the standard resolvers (which will
# either succeed unexpectedly or raise a confusing error). Removing an
# entry without removing its branch leaves dead code.
_CUSTOM_BRANCH_HANDLERS: frozenset[str] = frozenset(
    {
        # Existing branches (pre-#124).
        "botrolebots",  # issue #94 — manager.py special-case branch
        "classification_group",  # issue #103
        "classification_field",  # issue #103
        "component_formula",  # issue #158
        "component_formula_row",  # issue #158
        "form",  # issue #169
        "form_component",  # issue #169
        "form_component_copy",  # issue #169
        # Issue #124 Milestone-B stubs (handled by RaisingHandler until B-Tx
        # implementations land; each then gets a real custom branch).
        "effect",
        "behaviour",
        "componentactions",
        "print_document",
        "print_document_component",
        "print_document_component_copy",
        "print_document_sort",
        "role_form",
        "role_form_component_copy",
        "role_status",
    }
)


# Issue #124 — historical note. Milestone A introduced _MILESTONE_B_STUBS
# as a transition mechanism: types whose real handler shipped in Milestone B
# raised a clear "not yet implemented (#124-B)" error during the gap.
# Milestone B implemented all 10 handlers (see execute_rollback custom
# branches), so the set is now empty and the gap is closed. Kept as an
# empty frozenset for any test that inspects it; remove in a future cleanup
# if no callers remain.
_MILESTONE_B_STUBS: frozenset[str] = frozenset()


class RollbackManager:
    """Manages rollback operations for BPA write operations.

    This class handles:
    1. Validation of rollback eligibility
    2. Retrieval of previous state from rollback_states
    3. Endpoint resolution based on object type
    4. Execution of the rollback via BPA API
    5. Marking the original operation as rolled back

    Concurrency (issue #179): perform_rollback acquires a per-audit-id
    asyncio.Lock to prevent two concurrent calls on the same audit_id from
    both passing the "already rolled back?" check and double-executing the
    rollback API call. Single-process scope only — cross-process safety
    requires database-level locking and is out of scope.
    """

    # Class-level lock registry: audit_id -> Lock. Shared across all
    # RollbackManager instances so two managers (e.g., different db_paths
    # against the same audit DB, or test fixtures) serialize correctly.
    # Guard with _locks_guard to make registry creation atomic.
    _locks: dict[str, asyncio.Lock] = {}
    _locks_guard: asyncio.Lock | None = None

    # Cap on the per-audit lock dict. The MCP server can accumulate one
    # lock per audit ID rolled back since process start; for a long-running
    # server that becomes a slow memory leak. Once we exceed the cap we
    # evict UNLOCKED entries in insertion order (Python dicts preserve it).
    # The cap is generous — at typical rollback rates this only kicks in
    # after thousands of rollbacks.
    _LOCKS_CAP = 1024

    def __init__(
        self, db_path: Path | None = None, instance: str | None = None
    ) -> None:
        """Initialize the RollbackManager.

        Args:
            db_path: Optional path to SQLite database. Uses default if not provided.
            instance: Instance profile name for BPA API calls.
        """
        self._db_path = db_path
        self._instance = instance

    @classmethod
    async def _acquire_audit_lock(cls, audit_id: str) -> asyncio.Lock:
        """Return the lock for `audit_id`, creating it atomically if needed.

        The meta-lock _locks_guard is created lazily on first use because
        asyncio.Lock requires a running event loop at construction time and
        the class itself is imported at module-load. Doing this here also
        makes the class import-safe in non-async contexts.
        """
        if cls._locks_guard is None:
            cls._locks_guard = asyncio.Lock()
        async with cls._locks_guard:
            lock = cls._locks.get(audit_id)
            if lock is None:
                # Evict before adding so we don't exceed the cap.
                cls._maybe_evict_locks()
                lock = asyncio.Lock()
                cls._locks[audit_id] = lock
        return lock

    @classmethod
    def _maybe_evict_locks(cls) -> None:
        """Bound _locks memory by evicting UNLOCKED entries when at cap.

        Held entries (an active rollback is in progress) are skipped — we
        cannot evict a held lock without breaking the in-progress rollback.
        FIFO order on the dict (Python preserves insertion order).
        """
        if len(cls._locks) < cls._LOCKS_CAP:
            return
        # Evict the oldest unlocked entries until we drop below the cap.
        # `locked()` is sync and safe to call from this sync helper.
        to_remove = []
        for k, v in cls._locks.items():
            if not v.locked():
                to_remove.append(k)
                if len(cls._locks) - len(to_remove) < cls._LOCKS_CAP:
                    break
        for k in to_remove:
            del cls._locks[k]

    async def _get_audit_entry(self, audit_id: str) -> dict[str, Any] | None:
        """Fetch an audit entry by ID.

        Args:
            audit_id: The UUID of the audit entry.

        Returns:
            Dict with audit entry data, or None if not found.
        """
        async with get_connection(self._db_path) as conn:
            cursor = await conn.execute(
                """
                SELECT id, timestamp, user_email, operation_type, object_type,
                       object_id, params, status, result, rollback_state_id
                FROM audit_logs
                WHERE id = ?
                """,
                (audit_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                return None
            return dict(row)

    async def _get_rollback_state(
        self, rollback_state_id: str
    ) -> dict[str, Any] | None:
        """Fetch a rollback state by ID.

        Args:
            rollback_state_id: The UUID of the rollback state.

        Returns:
            Dict with rollback state data, or None if not found.
        """
        async with get_connection(self._db_path) as conn:
            cursor = await conn.execute(
                """
                SELECT id, audit_log_id, object_type, object_id,
                       previous_state, created_at
                FROM rollback_states
                WHERE id = ?
                """,
                (rollback_state_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                return None
            return dict(row)

    def _check_already_rolled_back(self, result: dict[str, Any] | None) -> bool:
        """Check if an operation was already rolled back.

        Args:
            result: The result field from audit_logs (parsed JSON).

        Returns:
            True if already rolled back, False otherwise.
        """
        if result is None:
            return False
        return "rolled_back_at" in result

    async def validate_rollback(self, audit_id: str) -> dict[str, Any]:
        """Validate that a rollback can be performed for the given audit entry.

        This performs all pre-flight checks:
        1. Audit entry exists
        2. Operation status is 'success' (not failed or pending)
        3. Operation has not already been rolled back
        4. Rollback state exists

        Args:
            audit_id: The UUID of the audit entry to validate.

        Returns:
            The audit entry dict if validation passes.

        Raises:
            RollbackNotPossibleError: If rollback cannot be performed.
        """
        # Check audit entry exists
        entry = await self._get_audit_entry(audit_id)
        if entry is None:
            raise RollbackNotPossibleError(
                f"Audit entry '{audit_id}' not found. "
                "Use 'audit_list' to see available entries."
            )

        # Check status
        status = entry["status"]
        if status == "failed":
            raise RollbackNotPossibleError(
                f"Operation '{audit_id}' failed and made no changes. "
                "Nothing to rollback."
            )
        if status == "pending":
            raise RollbackNotPossibleError(
                f"Operation '{audit_id}' is still pending. "
                "Wait for it to complete before attempting rollback."
            )

        # Check if already rolled back
        result = json.loads(entry["result"]) if entry["result"] else None
        if self._check_already_rolled_back(result):
            # result is guaranteed to be a dict if check returns True
            assert result is not None
            rolled_back_at = result.get("rolled_back_at", "unknown time")
            raise RollbackNotPossibleError(
                f"Operation '{audit_id}' was already rolled back at {rolled_back_at}. "
                "Use 'audit_get' to see current state."
            )

        # Issue #124 — check policy: is this object_type intentionally
        # non-rollbackable? Ordered AFTER the "failed/pending/already-rolled-back"
        # checks because those describe THIS operation's state; policy applies
        # only to successful, un-rolled-back operations that we then decide not
        # to support.
        non_rollbackable_reason = _classify_non_rollbackable(
            entry["object_type"], entry["operation_type"]
        )
        if non_rollbackable_reason is not None:
            raise IntentionallyNonRollbackableError(
                f"Operation '{audit_id}' on "
                f"'{entry['object_type']}'.{entry['operation_type']} "
                f"is intentionally non-rollbackable: {non_rollbackable_reason}.",
                reason=non_rollbackable_reason,
            )

        # Check rollback state exists
        if entry["rollback_state_id"] is None:
            raise RollbackNotPossibleError(
                f"Operation '{audit_id}' has no saved state for rollback. "
                "This may be an older operation before rollback was enabled."
            )

        return entry

    def _get_delete_endpoint(
        self, object_type: str, object_id: str, params: dict[str, Any]
    ) -> str:
        """Resolve the DELETE endpoint for an object type.

        Args:
            object_type: The type of object (service, registration, etc.)
            object_id: The ID of the object to delete.
            params: Additional parameters for endpoint resolution (service_id, etc.)

        Returns:
            The resolved DELETE endpoint path.

        Raises:
            RollbackError: If object type not supported or endpoint not available.
        """
        if object_type not in ROLLBACK_ENDPOINTS:
            raise RollbackError(
                f"Rollback not supported for object type '{object_type}'."
            )

        delete_endpoint, _, _ = ROLLBACK_ENDPOINTS[object_type]
        if delete_endpoint is None:
            raise RollbackError(
                f"DELETE operation not available for object type '{object_type}'."
            )

        # Substitute placeholders
        endpoint = delete_endpoint.replace("{id}", str(object_id))
        if "{service_id}" in endpoint:
            service_id = params.get("service_id")
            if not service_id:
                raise RollbackError(
                    f"Cannot resolve DELETE endpoint for '{object_type}': "
                    "service_id not found in params."
                )
            endpoint = endpoint.replace("{service_id}", str(service_id))
        if "{registration_id}" in endpoint:
            registration_id = params.get("registration_id")
            if not registration_id:
                raise RollbackError(
                    f"Cannot resolve DELETE endpoint for '{object_type}': "
                    "registration_id not found in params."
                )
            endpoint = endpoint.replace("{registration_id}", str(registration_id))
        if "{role_id}" in endpoint:
            role_id = params.get("role_id")
            if not role_id:
                raise RollbackError(
                    f"Cannot resolve DELETE endpoint for '{object_type}': "
                    "role_id not found in params."
                )
            endpoint = endpoint.replace("{role_id}", str(role_id))

        return endpoint

    def _get_update_endpoint(
        self, object_type: str, object_id: str, params: dict[str, Any]
    ) -> str:
        """Resolve the PUT endpoint for an object type.

        Args:
            object_type: The type of object (service, registration, etc.)
            object_id: The ID of the object to update.
            params: Additional parameters for endpoint resolution.

        Returns:
            The resolved PUT endpoint path.

        Raises:
            RollbackError: If object type not supported or endpoint not available.
        """
        if object_type not in ROLLBACK_ENDPOINTS:
            raise RollbackError(
                f"Rollback not supported for object type '{object_type}'."
            )

        # Special case (issue #169): form rollback endpoint depends on form_type.
        # All three form-related audit object_types share the same restore path —
        # PUT the previous envelope back to the form_type's PUT endpoint.
        if object_type in {"form", "form_component", "form_component_copy"}:
            form_type = params.get("form_type")
            if not form_type:
                raise RollbackError(
                    f"Cannot resolve UPDATE endpoint for '{object_type}': "
                    "form_type not found in audit params."
                )
            cfg = FORM_ENDPOINTS.get(form_type)
            if cfg is None:
                raise RollbackError(
                    f"Cannot resolve UPDATE endpoint for '{object_type}': "
                    f"unknown form_type '{form_type}' (expected one of: "
                    f"{', '.join(sorted(FORM_ENDPOINTS))})."
                )
            return cfg["put_endpoint"].replace("{form_id}", str(object_id))

        _, update_endpoint, _ = ROLLBACK_ENDPOINTS[object_type]
        if update_endpoint is None:
            raise RollbackError(
                f"UPDATE operation not available for object type '{object_type}'."
            )

        # Substitute placeholders
        endpoint = update_endpoint.replace("{id}", str(object_id))
        if "{service_id}" in endpoint:
            service_id = params.get("service_id")
            if not service_id:
                raise RollbackError(
                    f"Cannot resolve UPDATE endpoint for '{object_type}': "
                    "service_id not found in params."
                )
            endpoint = endpoint.replace("{service_id}", str(service_id))

        return endpoint

    def _get_create_endpoint(self, object_type: str, params: dict[str, Any]) -> str:
        """Resolve the POST endpoint for an object type.

        Args:
            object_type: The type of object (service, registration, etc.)
            params: Additional parameters for endpoint resolution.

        Returns:
            The resolved POST endpoint path.

        Raises:
            RollbackError: If object type not supported or endpoint not available.
        """
        if object_type not in ROLLBACK_ENDPOINTS:
            raise RollbackError(
                f"Rollback not supported for object type '{object_type}'."
            )

        # Special case: cost has two create endpoints depending on cost_type
        if object_type == "cost":
            cost_type = params.get("cost_type", "fixed")
            registration_id = params.get("registration_id")
            if not registration_id:
                raise RollbackError(
                    "Cannot resolve CREATE endpoint for 'cost': "
                    "registration_id not found in params."
                )
            if cost_type == "formula":
                return f"/registration/{registration_id}/formulacost"
            return f"/registration/{registration_id}/fixcost"

        # Special case: generic "determinant" resolves to type-specific endpoint
        if object_type == "determinant":
            det_type = params.get("determinant_type", "")
            service_id = params.get("service_id")
            if not service_id:
                raise RollbackError(
                    "Cannot resolve CREATE endpoint for 'determinant': "
                    "service_id not found in params."
                )
            type_map = {
                "text": "textdeterminant",
                "boolean": "booleandeterminant",
                "selection": "selectdeterminant",
                "numeric": "numericdeterminant",
                "date": "datedeterminant",
                "classification": "classificationdeterminant",
                "grid": "griddeterminant",
            }
            endpoint_type = type_map.get(det_type)
            if not endpoint_type:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for determinant: "
                    f"unknown determinant_type '{det_type}' in params."
                )
            return f"/service/{service_id}/{endpoint_type}"

        _, _, create_endpoint = ROLLBACK_ENDPOINTS[object_type]
        if create_endpoint is None:
            # Defensive: classification_field has (None,None,None) on purpose
            # (custom branch in execute_rollback handles it before we get here).
            # If anyone routes around the special-case branches in the future,
            # we want a clean RollbackError, not None.replace() AttributeError.
            raise RollbackError(
                f"CREATE operation not available for object type '{object_type}'."
            )

        # Substitute placeholders
        endpoint = create_endpoint
        if "{service_id}" in endpoint:
            service_id = params.get("service_id")
            if not service_id:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for '{object_type}': "
                    "service_id not found in params."
                )
            endpoint = endpoint.replace("{service_id}", str(service_id))
        if "{registration_id}" in endpoint:
            registration_id = params.get("registration_id")
            if not registration_id:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for '{object_type}': "
                    "registration_id not found in params."
                )
            endpoint = endpoint.replace("{registration_id}", str(registration_id))
        if "{classification_id}" in endpoint:
            classification_id = params.get("classification_id")
            if not classification_id:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for '{object_type}': "
                    "classification_id not found in params."
                )
            endpoint = endpoint.replace("{classification_id}", str(classification_id))
        if "{bot_id}" in endpoint:
            bot_id = params.get("bot_id")
            if not bot_id:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for '{object_type}': "
                    "bot_id not found in params."
                )
            endpoint = endpoint.replace("{bot_id}", str(bot_id))
        if "{role_id}" in endpoint:
            role_id = params.get("role_id")
            if not role_id:
                raise RollbackError(
                    f"Cannot resolve CREATE endpoint for '{object_type}': "
                    "role_id not found in params."
                )
            endpoint = endpoint.replace("{role_id}", str(role_id))

        return endpoint

    async def execute_rollback(
        self,
        operation_type: str,
        object_type: str,
        object_id: str,
        previous_state: dict[str, Any] | None,
        params: dict[str, Any],
        result: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute the rollback operation via BPA API.

        Strategy by operation type:
        - create: DELETE the object (no previous state needed)
        - update: PUT with previous_state values
        - delete: POST to recreate with previous_state
        - link: Call unlink operation
        - unlink: Call link operation

        Args:
            operation_type: The original operation type (create, update, delete, etc.)
            object_type: The type of object.
            object_id: The ID of the object.
            previous_state: The state to restore (None for create operations).
            params: Additional context parameters from the original operation.
            result: Optional post-write state from the original operation's audit
                `result` field (stored by mark_success). Used by component_formula
                rollback for drift detection (compare current state vs what MCP
                wrote). None for standard rollback paths.

        Returns:
            Dict with rollback execution result.

        Raises:
            RollbackError: If the BPA API call fails.
        """
        try:
            async with BPAClient.for_instance(self._instance) as client:
                # Special-case: botrolebots has no DELETE endpoint and needs
                # a wrapped previous_state ({role_id, record, _was_create}).
                # Issue #94.
                if object_type == "botrolebots":
                    return await self._rollback_botrolebots(
                        client,
                        operation_type=operation_type,
                        object_id=object_id,
                        previous_state=previous_state,
                    )

                # Special-case: classification_group delete needs to recreate
                # group AND restore field-group joins. Issue #103.
                if object_type == "classification_group" and operation_type == "delete":
                    return await self._rollback_classification_group_delete(
                        client,
                        object_id=object_id,
                        previous_state=previous_state,
                    )

                # Special-case: classification_group update strips internal
                # markers from the PUT body. Issue #103.
                if object_type == "classification_group" and operation_type == "update":
                    body = {
                        k: v
                        for k, v in (previous_state or {}).items()
                        if not k.startswith("_")
                    }
                    await client.put("/classification_group", json=body)
                    return {"action": "restored", "state": body}

                # Special-case: classification_field (entry_set_groups)
                # rollback uses POST /classification/{type_id}/field with
                # the captured pre-state entry. Issue #103.
                if object_type == "classification_field" and operation_type == "update":
                    return await self._rollback_classification_field_update(
                        client,
                        previous_state=previous_state,
                    )

                # Special-case: classification_field create (issue #186) --
                # rollback deletes the new entry via
                # DELETE /classification/field/{entry_id} (the same path the
                # BPA admin UI uses). Idempotent on 404 (the entry may have
                # been manually deleted between create and rollback).
                if object_type == "classification_field" and operation_type == "create":
                    return await self._rollback_classification_field_create(
                        client,
                        previous_state=previous_state,
                    )

                # Special-case: component_formula + component_formula_row (#158).
                # Both share the same rollback semantics: restore the whole formula
                # state with drift protection. Uses the result field (post_write_state)
                # from the audit log for content-based drift comparison (UUIDs change
                # on every PUT — CLAUDE.md § "Row UUIDs are NOT stable across writes").
                # Routes to _apply_componentformula_rollback.
                if object_type in ("component_formula", "component_formula_row"):
                    from fastmcp.exceptions import ToolError

                    from mcp_eregistrations_bpa.tools.component_formulas import (
                        _apply_componentformula_rollback,
                    )

                    # object_id format: "{service_id}/{component_key}" (set by all 5
                    # write tools' record_pending calls).
                    if "/" not in object_id:
                        raise RollbackError(
                            f"component_formula rollback: object_id '{object_id}' is "
                            f"not in expected 'service_id/component_key' format."
                        )
                    service_id, component_key = object_id.split("/", 1)

                    # before_state is wrapped in {"before_state": ...} by all 5 tools'
                    # save_rollback_state calls. previous_state itself comes from
                    # rollback_state['previous_state'] (already parsed by
                    # perform_rollback).
                    before_state = (previous_state or {}).get("before_state")
                    # post_write_state is the result dict from mark_success.
                    # For row tools and upsert: shape is {id, service_id,
                    #     component_key, rows: [...], audit_id, ...}.
                    # For delete: shape is {deleted: ...} or {no_op: ...} —
                    #     these have no formulaRows to drift-check.
                    # _apply_componentformula_rollback tolerates either shape via
                    # its `(post_write_state or {}).get("formulaRows")` extraction.
                    post_write_state = result

                    try:
                        await _apply_componentformula_rollback(
                            instance=self._instance,
                            service_id=service_id,
                            component_key=component_key,
                            before_state=before_state,
                            post_write_state=post_write_state,
                        )
                    except ToolError as e:
                        raise RollbackNotPossibleError(
                            f"Rollback refused: {e}. Inspect audit log via "
                            "audit_get(audit_id=...) and recover manually if needed."
                        ) from e
                    return {
                        "action": "restored" if before_state is not None else "deleted",
                        "object_id": object_id,
                    }

                # ====== Issue #124-B custom handlers ======
                # Effect/behaviour family — effects live INSIDE a Behaviour
                # entity; mutating an effect = PUT the whole behaviour.
                if object_type == "effect" and operation_type == "create":
                    return await self._rollback_effect_create(
                        client, object_id=object_id, previous_state=previous_state
                    )
                if object_type == "effect" and operation_type == "delete":
                    return await self._rollback_effect_delete(
                        client, previous_state=previous_state, params=params
                    )
                if object_type == "behaviour" and operation_type == "delete":
                    return await self._rollback_behaviour_delete(
                        client, previous_state=previous_state, params=params
                    )
                # Componentactions.save — upsert; rollback dispatches by had_existing
                if object_type == "componentactions" and operation_type == "save":
                    return await self._rollback_componentactions_save(
                        client, previous_state=previous_state, params=params
                    )
                # Print document family — composite PUT-back / POST-recreate
                if object_type in {
                    "print_document",
                    "print_document_component",
                    "print_document_component_copy",
                }:
                    return await self._rollback_print_document_composite(
                        client,
                        operation_type=operation_type,
                        object_id=object_id,
                        previous_state=previous_state,
                        params=params,
                    )
                if object_type == "print_document_sort" and operation_type == "update":
                    return await self._rollback_print_document_sort(
                        client, previous_state=previous_state
                    )
                # Role form family — the role-form is a slice of the Role
                # entity; rollback PUTs the full role body back via /role.
                if object_type in {"role_form", "role_form_component_copy"}:
                    return await self._rollback_role_form_composite(
                        client, previous_state=previous_state
                    )
                # Role status — sub-type-specific PUT endpoints
                if object_type == "role_status":
                    return await self._rollback_role_status(
                        client,
                        operation_type=operation_type,
                        object_id=object_id,
                        previous_state=previous_state,
                        params=params,
                    )
                # Role unit unlink — backend DELETE is a soft-null; rollback
                # PUTs /role_institution to restore unitId on the same record.
                # Link rollback (DELETE) is handled by the generic link branch
                # above.
                if object_type == "role_unit" and operation_type == "unlink":
                    return await self._rollback_role_unit_unlink(
                        client, previous_state=previous_state
                    )

                if operation_type == "create":
                    # Delete the created object
                    endpoint = self._get_delete_endpoint(object_type, object_id, params)
                    await client.delete(endpoint)
                    return {"action": "deleted", "object_id": object_id}

                elif operation_type == "update":
                    # Restore previous values
                    endpoint = self._get_update_endpoint(object_type, object_id, params)
                    api_result = await client.put(endpoint, json=previous_state)
                    return {"action": "restored", "state": api_result}

                elif operation_type == "delete":
                    # Recreate the object
                    endpoint = self._get_create_endpoint(object_type, params)

                    # Messages: strip ID fields (BPA rejects recreating with same ID)
                    # Other types: preserve original payload
                    if object_type == "message":
                        create_payload = {
                            k: v
                            for k, v in (previous_state or {}).items()
                            if k not in ("id", "businessKey", "business_key")
                        }
                        api_result = await client.post(endpoint, json=create_payload)
                        return {
                            "action": "recreated",
                            "new_id": api_result.get("id") if api_result else None,
                            "original_id": (
                                previous_state.get("id") if previous_state else None
                            ),
                        }
                    else:
                        api_result = await client.post(endpoint, json=previous_state)
                        return {
                            "action": "recreated",
                            "new_id": api_result.get("id") if api_result else None,
                        }

                elif operation_type == "link":
                    # Issue #124-B: rollback a link by DELETEing the exact link
                    # record. The link's id was captured in save_rollback_state's
                    # object_id (see registrations.py:838 for the service_registration
                    # precedent and roles.py:1388/1486 for role_institution/
                    # role_registration). For service_registration the composite
                    # (service_id, registration_id) IS the identity; for the others
                    # the link record has a regular {id}.
                    #
                    # Drift detection (per FAILURE lens F1 in spec): a 404 means
                    # the link was removed elsewhere — surface this distinctly so
                    # the operator doesn't think the rollback succeeded.
                    endpoint = self._get_delete_endpoint(object_type, object_id, params)
                    try:
                        await client.delete(endpoint)
                    except BPAClientError as e:
                        if getattr(e, "status_code", None) == 404:
                            raise RollbackError(
                                f"Link {object_id} for '{object_type}' no longer "
                                "exists. It may have been unlinked by another "
                                "operation; check audit log for context."
                            ) from e
                        raise
                    return {
                        "action": "unlinked",
                        "object_id": object_id,
                        "endpoint": endpoint,
                    }

                elif operation_type == "unlink":
                    # Issue #124-B: rollback an unlink by re-POSTing the link.
                    # The new link will have a different id than the original;
                    # surface this in the result (precedent: behaviour.delete
                    # rollback returns new_id at manager.py:1112-1116).
                    endpoint = self._get_create_endpoint(object_type, params)
                    api_result = await client.post(endpoint, json=previous_state)
                    new_id = (
                        api_result.get("id") if isinstance(api_result, dict) else None
                    )
                    return {
                        "action": "relinked",
                        "new_link_id": new_id,
                        "original_link_id": object_id,
                        "endpoint": endpoint,
                    }

                else:
                    raise RollbackError(
                        f"Unknown operation type '{operation_type}'. "
                        "Cannot determine rollback strategy."
                    )

        except BPAClientError as e:
            raise RollbackError(f"BPA API error during rollback: {e}") from e

    async def _rollback_botrolebots(
        self,
        client: BPAClient,
        *,
        operation_type: str,
        object_id: str,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Rollback for BotRoleBots (issue #94).

        The backend has no DELETE endpoint, and the previous_state shape
        carries a `_was_create` marker + the raw record. Rollback strategy:

        - operation_type=create: PUT /botrolebots/{id} with actions=[] to
          delete the created record. `object_id` must be the botrolebots_id,
          which the save tool stores when was_create=True (from post-write
          verify) or None if the POST failed mid-flight.
        - operation_type=update: PUT /botrolebots/{id} with the captured
          previous actions to restore prior state.
        - operation_type=delete: POST /role/{role_id}/botrolebots with the
          saved actions to recreate.
        """
        if previous_state is None:
            raise RollbackError(
                "Cannot rollback botrolebots: previous_state is missing."
            )

        record = previous_state.get("record") or {}
        role_id = previous_state.get("role_id")
        actions = record.get("actions") or []

        if operation_type == "create":
            # Delete the created record via empty-actions PUT.
            if not object_id or object_id in ("None", ""):
                raise RollbackError(
                    "Cannot rollback botrolebots create: botrolebots_id "
                    "was not captured. The save may have failed before "
                    "the record was committed."
                )
            await client.put(
                f"/botrolebots/{object_id}",
                json={"actions": []},
            )
            return {"action": "deleted", "object_id": object_id}

        if operation_type == "update":
            if not object_id:
                raise RollbackError(
                    "Cannot rollback botrolebots update: object_id missing."
                )
            # Strip server-assigned ids so backend treats this as fresh save.
            clean_actions = [{k: v for k, v in a.items() if k != "id"} for a in actions]
            await client.put(
                f"/botrolebots/{object_id}",
                json={"actions": clean_actions},
            )
            return {"action": "restored", "object_id": object_id}

        if operation_type == "delete":
            if not role_id:
                raise RollbackError(
                    "Cannot rollback botrolebots delete: role_id missing "
                    "in previous_state."
                )
            clean_actions = [{k: v for k, v in a.items() if k != "id"} for a in actions]
            await client.post(
                f"/role/{role_id}/botrolebots",
                json={"actions": clean_actions},
            )
            return {"action": "recreated", "role_id": role_id}

        raise RollbackError(
            f"Unknown operation_type '{operation_type}' for botrolebots."
        )

    async def _rollback_classification_group_delete(
        self,
        client: BPAClient,
        *,
        object_id: str,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Recreate a deleted classification_group + restore its field joins.

        Backend deletes ClassificationFieldGroup rows when a group is deleted.
        Rollback re-creates the group (new ID assigned by backend) and then,
        for each affected field_id, re-fetches the entry and POSTs it with
        the new group appended to its classificationGroups list.

        Continues on per-field error so a single failure doesn't abort the
        whole rollback — the failed_field_ids list lets operators investigate.
        """
        if not previous_state or "group" not in previous_state:
            raise RollbackError(
                "previous_state must contain 'group' for classification_group "
                "delete rollback."
            )
        group = previous_state["group"]
        type_id = group.get("classification_type_id")
        if not type_id:
            raise RollbackError(
                "previous_state.group.classification_type_id required for "
                "classification_group delete rollback."
            )

        # 1. Recreate the group. If a concurrent caller has already created
        # a group with this name, surface clearly — manual intervention is
        # required, we can't silently merge.
        group_payload: dict[str, Any] = {"name": group.get("name")}
        if group.get("sort_order") is not None:
            group_payload["sortOrder"] = group["sort_order"]
        if group.get("visible") is not None:
            group_payload["visible"] = group["visible"]
        try:
            created = await client.post(
                f"/classification_group/{type_id}", json=group_payload
            )
        except BPAClientError as e:
            if "already exists" in str(e).lower():
                raise RollbackError(
                    f"Cannot rollback delete of group '{group.get('name')}': "
                    f"a group with this name was created in the interim. "
                    f"Manual intervention required to reconcile. "
                    f"Field IDs that lost their membership: "
                    f"{previous_state.get('field_ids') or []}. "
                    f"Backend message: {e}"
                ) from e
            raise
        new_group_id = created.get("id") if isinstance(created, dict) else None

        # 2. Restore each field's group membership
        field_ids = previous_state.get("field_ids") or []
        restored: list[str] = []
        failed: list[dict[str, Any]] = []
        if field_ids and new_group_id:
            try:
                pageable = await client.get_all_pageable(
                    "/classification/{id}/pageable",
                    path_params={"id": type_id},
                    resource_type="classification",
                )
                entries_by_id = {
                    e.get("id"): e for e in (pageable.get("content") or [])
                }
            except Exception as e:
                # Couldn't enumerate fields — surface the failure but keep
                # the new group already recreated.
                return {
                    "action": "recreated_with_join_rows",
                    "new_group_id": new_group_id,
                    "restored_field_count": 0,
                    "failed_field_ids": [
                        {"id": fid, "error": f"pre-fetch: {e}"} for fid in field_ids
                    ],
                }

            for fid in field_ids:
                target = entries_by_id.get(fid)
                if target is None:
                    failed.append({"id": fid, "error": "field not found"})
                    continue
                try:
                    payload = {
                        k: v
                        for k, v in target.items()
                        if k
                        not in (
                            "createdBy",
                            "createdWhen",
                            "lastChangedBy",
                            "lastChangedWhen",
                        )
                    }
                    existing_groups = list(payload.get("classificationGroups") or [])
                    # Append new group only if not already present
                    if not any(g.get("id") == new_group_id for g in existing_groups):
                        existing_groups.append(
                            {
                                "id": new_group_id,
                                "name": group.get("name"),
                                "sortOrder": group.get("sort_order"),
                            }
                        )
                    payload["classificationGroups"] = existing_groups
                    await client.post(
                        f"/classification/{type_id}/field",
                        json=payload,
                    )
                    restored.append(fid)
                except Exception as e:
                    failed.append({"id": fid, "error": str(e)})

        return {
            "action": "recreated_with_join_rows",
            "new_group_id": new_group_id,
            "restored_field_count": len(restored),
            "failed_field_ids": failed,
        }

    async def _rollback_classification_field_update(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Re-POST the captured pre-state entry to restore its groups verbatim.

        previous_state must contain previous_entry (the deepcopy captured at
        write-time). Internal markers (_operation, etc.) are stripped before
        sending.
        """
        if not previous_state or "previous_entry" not in previous_state:
            raise RollbackError(
                "previous_state must contain 'previous_entry' for "
                "classification_field update rollback."
            )
        type_id = previous_state.get("classification_id")
        if not type_id:
            raise RollbackError(
                "previous_state.classification_id required for "
                "classification_field update rollback."
            )
        entry = previous_state["previous_entry"]
        # Strip stale audit fields just in case they slipped into capture
        body = {
            k: v
            for k, v in entry.items()
            if k
            not in (
                "createdBy",
                "createdWhen",
                "lastChangedBy",
                "lastChangedWhen",
            )
        }
        await client.post(
            f"/classification/{type_id}/field",
            json=body,
        )
        return {
            "action": "restored",
            "entry_id": previous_state.get("entry_id"),
            "classification_id": type_id,
        }

    async def _rollback_classification_field_create(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Rollback a classification_entry_create by deleting the new entry.

        Issue #186: classification_entry_create's rollback is a single
        DELETE call against /classification/field/{entry_id} -- the same
        path the BPA admin UI uses. Idempotent on 404: if the entry was
        deleted manually between create and rollback, surface a 'noop'
        instead of failing.
        """
        if not previous_state or not previous_state.get("entry_id"):
            raise RollbackError(
                "previous_state must contain 'entry_id' for "
                "classification_field create rollback."
            )
        entry_id = str(previous_state["entry_id"])
        try:
            await client.delete(f"/classification/field/{entry_id}")
        except BPANotFoundError:
            # Already gone -- treat as success. Operationally: the entry
            # was deleted manually between create and rollback. Either way
            # the desired post-rollback state (entry absent) holds.
            return {
                "action": "noop",
                "entry_id": entry_id,
                "note": "Entry already absent (404 on DELETE).",
            }
        return {
            "action": "deleted",
            "entry_id": entry_id,
        }

    # ====== Issue #124-B custom handlers ======
    #
    # Each handler implements rollback for a Milestone-B object_type whose
    # previous_state shape or recovery semantics don't fit the standard
    # (delete, update, create) tuple. Dispatched from execute_rollback BEFORE
    # the generic create/update/delete/link/unlink branches.

    async def _rollback_effect_create(
        self,
        client: BPAClient,
        *,
        object_id: str,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Rollback an effect.create.

        previous_state captures host metadata + the new effect's id but NOT
        the effect content. Rollback strategy:
          - If was_new_behaviour: DELETE the whole behaviour we just created.
          - Else: fetch the behaviour, remove the effect by id, PUT back.
        """
        if not previous_state:
            raise RollbackError(
                "Cannot rollback effect.create: previous_state is missing."
            )
        behaviour_id = previous_state.get("behaviour_id")
        effect_id = previous_state.get("effect_id") or object_id
        was_new_behaviour = previous_state.get("was_new_behaviour", False)

        if not behaviour_id:
            raise RollbackError(
                "Cannot rollback effect.create: behaviour_id missing from "
                "previous_state."
            )

        if was_new_behaviour:
            # Created behaviour wraps only this effect; nuking it cleans up.
            try:
                await client.delete(f"/behaviour/{behaviour_id}")
            except BPAClientError as e:
                if getattr(e, "status_code", None) == 404:
                    raise RollbackError(
                        f"Cannot rollback effect.create: behaviour "
                        f"'{behaviour_id}' no longer exists. Manual "
                        "reconciliation may be required."
                    ) from e
                raise
            return {
                "action": "deleted",
                "behaviour_id": behaviour_id,
                "effect_id": effect_id,
            }

        # Pre-existing behaviour — fetch, drop the effect, PUT back.
        try:
            behaviour = await client.get(f"/behaviour/{behaviour_id}")
        except BPAClientError as e:
            if getattr(e, "status_code", None) == 404:
                raise RollbackError(
                    f"Cannot rollback effect.create: parent behaviour "
                    f"'{behaviour_id}' no longer exists. Manual "
                    "reconciliation required."
                ) from e
            raise
        effects = behaviour.get("effects") or []
        remaining = [e for e in effects if e.get("id") != effect_id]
        if len(remaining) == len(effects):
            # Effect already removed elsewhere — surface as drift, do not
            # silently succeed.
            raise RollbackError(
                f"Cannot rollback effect.create: effect '{effect_id}' is no "
                f"longer in behaviour '{behaviour_id}'. May have been "
                "removed by another operation."
            )
        behaviour["effects"] = remaining
        await client.put("/behaviour", json=behaviour)
        return {
            "action": "restored",
            "behaviour_id": behaviour_id,
            "effect_id": effect_id,
            "remaining_effect_count": len(remaining),
        }

    async def _rollback_effect_delete(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any] | None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Rollback an effect.delete.

        previous_state IS the full pre-mutation Behaviour entity (saved by
        effect_delete with object_type="behaviour" — note the diverging
        audit/rollback-state object_type, see manager.py:1076 and
        behaviours.py:2338). Rollback PUTs the behaviour back.

        Issue #178: if PUT fails with a Hibernate optimistic-locking 500
        (the deleted Effect row was hard-deleted from the DB and the
        captured payload still references it), fall back to POST recreate
        via /service/{service_id}/behaviour with child IDs stripped so
        the backend assigns fresh UUIDs.
        """
        if not previous_state:
            raise RollbackError(
                "Cannot rollback effect.delete: previous_state is missing."
            )
        behaviour_id = previous_state.get("id")
        try:
            await client.put("/behaviour", json=previous_state)
        except BPAClientError as e:
            if _is_hibernate_optimistic_lock_error(e):
                return await self._effect_delete_hard_recover(
                    client,
                    previous_state=previous_state,
                    params=params or {},
                    original_error=e,
                )
            raise RollbackError(
                f"Failed to restore behaviour '{behaviour_id}' for "
                f"effect.delete rollback: {e}"
            ) from e
        return {
            "action": "restored",
            "behaviour_id": behaviour_id,
            "effect_count": len(previous_state.get("effects") or []),
            "warnings": [
                "Restored effects may have new ids; references to original "
                "effect ids will not resolve."
            ],
        }

    async def _effect_delete_hard_recover(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any],
        params: dict[str, Any],
        original_error: BPAClientError,
    ) -> dict[str, Any]:
        """Issue #178 fallback: hard-deleted child rows broke the PUT.

        Strategy: strip ids from the behaviour and its nested effects so
        the backend treats it as a fresh insert. POST to
        /service/{service_id}/behaviour. The new behaviour gets a new id;
        each restored effect also gets a new id. Surface both old and new
        ids in the result + an explicit warning that downstream references
        will not resolve.

        service_id must be in audit params (the same source effect_delete's
        record_pending uses — see behaviours.py:2334). If missing, surface
        the original error rather than silently choosing a wrong service.
        """
        service_id = params.get("service_id")
        if not service_id:
            raise RollbackError(
                f"Failed to restore behaviour '{previous_state.get('id')}' "
                f"for effect.delete rollback: {original_error}. Cannot "
                "attempt POST-recreate fallback because service_id is "
                "missing from audit params."
            ) from original_error
        stripped = _strip_child_ids(previous_state)
        try:
            api_result = await client.post(
                f"/service/{service_id}/behaviour", json=stripped
            )
        except BPAClientError as e:
            raise RollbackError(
                f"Failed to restore behaviour '{previous_state.get('id')}' "
                f"via POST-recreate fallback: {e}"
            ) from e
        new_behaviour_id = (
            api_result.get("id") if isinstance(api_result, dict) else None
        )
        return {
            "action": "recreated",
            "new_behaviour_id": new_behaviour_id,
            "original_behaviour_id": previous_state.get("id"),
            "effect_count": len(previous_state.get("effects") or []),
            "warnings": [
                "Hard-deleted child rows forced POST-recreate; behaviour "
                "and all effect ids differ from originals. Downstream "
                "references will not resolve."
            ],
        }

    async def _rollback_behaviour_delete(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any] | None,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Rollback a behaviour.delete by recreating with a NEW id.

        previous_state is the captured full Behaviour. POST to
        /service/{service_id}/behaviour. Backend assigns a new id; surface
        in result so the operator knows downstream references to the old id
        will not resolve.
        """
        if not previous_state:
            raise RollbackError(
                "Cannot rollback behaviour.delete: previous_state is missing."
            )
        service_id = params.get("service_id")
        if not service_id:
            raise RollbackError(
                "Cannot rollback behaviour.delete: service_id missing from "
                "audit params."
            )
        api_result = await client.post(
            f"/service/{service_id}/behaviour", json=previous_state
        )
        new_id = api_result.get("id") if isinstance(api_result, dict) else None
        return {
            "action": "recreated",
            "new_behaviour_id": new_id,
            "original_behaviour_id": previous_state.get("id"),
            "warnings": [
                "Recreated behaviour has a new id; references to original "
                "behaviour/effect ids will not resolve."
            ],
        }

    async def _rollback_componentactions_save(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any] | None,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Rollback a componentactions.save.

        save is an upsert. Dispatch on params['had_existing']:
          - False (was a create): DELETE the componentactions
          - True (was an update): PUT previous_state back
        """
        service_id = params.get("service_id")
        component_key = params.get("component_key")
        if not service_id or not component_key:
            raise RollbackError(
                "Cannot rollback componentactions.save: service_id or "
                "component_key missing from audit params."
            )
        endpoint = f"/service/{service_id}/componentactions/{component_key}"
        had_existing = params.get("had_existing", False)
        if not had_existing:
            # Was effectively a create — undo by deleting.
            await client.delete(endpoint)
            return {
                "action": "deleted",
                "service_id": service_id,
                "component_key": component_key,
            }
        # Was an update — PUT prior state back.
        await client.put(endpoint, json=previous_state or {})
        return {
            "action": "restored",
            "service_id": service_id,
            "component_key": component_key,
        }

    async def _rollback_print_document_composite(
        self,
        client: BPAClient,
        *,
        operation_type: str,
        object_id: str,
        previous_state: dict[str, Any] | None,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Rollback a print_document / print_document_component /
        print_document_component_copy mutation.

        Strategy:
          - create: DELETE /print-documents/{id}
          - update / component edits / copy create: PUT /print-documents/{id}
            with the captured doc body
          - delete: POST /service/{service_id}/print-documents to recreate
        """
        if operation_type == "create":
            doc_id = (previous_state or {}).get("id") or object_id
            if not doc_id:
                raise RollbackError(
                    "Cannot rollback print_document create: doc id missing "
                    "from previous_state and object_id."
                )
            await client.delete(f"/print-documents/{doc_id}")
            return {"action": "deleted", "document_id": doc_id}
        if operation_type == "delete":
            service_id = params.get("service_id")
            if not service_id:
                raise RollbackError(
                    "Cannot rollback print_document delete: service_id "
                    "missing from audit params."
                )
            api_result = await client.post(
                f"/service/{service_id}/print-documents",
                json=previous_state or {},
            )
            new_id = api_result.get("id") if isinstance(api_result, dict) else None
            return {
                "action": "recreated",
                "new_document_id": new_id,
                "original_document_id": (previous_state or {}).get("id"),
                "warnings": [
                    "Recreated print_document has a new id; references to "
                    "original id will not resolve."
                ]
                if new_id and new_id != (previous_state or {}).get("id")
                else [],
            }
        # update / component_* operations — PUT the captured doc back
        doc_id = (previous_state or {}).get("id") or object_id
        if not doc_id:
            raise RollbackError(
                "Cannot rollback print_document update: document id missing."
            )
        await client.put(f"/print-documents/{doc_id}", json=previous_state)
        return {"action": "restored", "document_id": doc_id}

    async def _rollback_print_document_sort(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Rollback a print_document_sort.update by re-PUT'ing the original
        documents list to /sortprintdocuments. previous_state shape:
        ``{"documents": [...]}`` per print_documents.py:1587.
        """
        if not previous_state or "documents" not in previous_state:
            raise RollbackError(
                "Cannot rollback print_document_sort: 'documents' missing "
                "from previous_state."
            )
        await client.put(
            "/sortprintdocuments",
            content=json.dumps(previous_state["documents"]),
        )
        return {
            "action": "restored",
            "document_count": len(previous_state["documents"]),
        }

    async def _rollback_role_form_composite(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Rollback role_form / role_form_component_copy.

        role-form is a slice of the Role entity. previous_state IS the
        envelope captured by RoleFormAdapter; PUT it back via /role.
        Endpoint precedent: patch/adapters/role_form.py:103.
        """
        if not previous_state:
            raise RollbackError("Cannot rollback role_form: previous_state is missing.")
        await client.put("/role", json=previous_state)
        return {
            "action": "restored",
            "role_id": previous_state.get("id"),
        }

    async def _rollback_role_status(
        self,
        client: BPAClient,
        *,
        operation_type: str,
        object_id: str,
        previous_state: dict[str, Any] | None,
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """Rollback role_status create / update / delete.

        Backend has no generic PUT — update path is sub-type-specific
        (RoleStatusController.java:103-203). previous_state carries
        ``roleStatusType`` which maps to the endpoint suffix.

        Strategy:
          - create: DELETE /role_status/{id} — only user_defined statuses can
            be created, system types (FilePending etc.) cannot.
          - update: PUT /role_status/{id}/{suffix} with previous body
          - delete: POST /role/{role_id}/role_status/user_defined_status with
            previous body — same caveat (only user_defined statuses can be
            recreated; system statuses are seeded by the platform).
        """
        # Endpoint-suffix map mirrors role_status.py:_STATUS_TYPE_TO_ENDPOINT
        type_to_suffix = {
            "UserDefinedStatus": "user_defined_status",
            "FileValidatedStatus": "file_validated_status",
            "FileRejectStatus": "file_reject_status",
            "FilePendingStatus": "file_pending_status",
            "FileDeclineStatus": "file_decline_status",
        }
        if operation_type == "create":
            await client.delete(f"/role_status/{object_id}")
            return {"action": "deleted", "role_status_id": object_id}
        if operation_type == "update":
            status_type = (previous_state or {}).get("roleStatusType", "")
            suffix = type_to_suffix.get(status_type)
            if not suffix:
                raise RollbackError(
                    f"Cannot rollback role_status.update: unknown "
                    f"roleStatusType '{status_type}' in previous_state "
                    f"(expected one of: {sorted(type_to_suffix)})."
                )
            await client.put(
                f"/role_status/{object_id}/{suffix}",
                json=previous_state,
            )
            return {"action": "restored", "role_status_id": object_id}
        if operation_type == "delete":
            role_id = params.get("role_id") or (previous_state or {}).get("role_id")
            status_type = (previous_state or {}).get("roleStatusType", "")
            if status_type != "UserDefinedStatus":
                raise RollbackError(
                    f"Cannot rollback role_status.delete: status type "
                    f"'{status_type}' is a system status and cannot be "
                    "recreated via the rollback tool."
                )
            if not role_id:
                raise RollbackError(
                    "Cannot rollback role_status.delete: role_id missing "
                    "from audit params and previous_state."
                )
            api_result = await client.post(
                f"/role/{role_id}/role_status/user_defined_status",
                json=previous_state,
            )
            new_id = api_result.get("id") if isinstance(api_result, dict) else None
            return {
                "action": "recreated",
                "new_role_status_id": new_id,
                "original_role_status_id": (previous_state or {}).get("id"),
            }
        raise RollbackError(
            f"Unknown operation_type '{operation_type}' for role_status."
        )

    async def _rollback_role_unit_unlink(
        self,
        client: BPAClient,
        *,
        previous_state: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Rollback role_unit.unlink.

        Backend DELETE /role_unit/{id} only sets unitId=null on an existing
        RoleInstitution record (RoleUnitController.java:56-59). Standard
        unlink rollback (POST recreate) would create a duplicate record.
        Instead, PUT /role_institution with the captured payload to restore
        unitId on the SAME record.
        """
        if not previous_state:
            raise RollbackError(
                "Cannot rollback role_unit.unlink: previous_state is missing."
            )
        await client.put("/role_institution", json=previous_state)
        return {
            "action": "restored",
            "role_institution_id": previous_state.get("id"),
            "unit_id": previous_state.get("unitId"),
        }

    async def _mark_rolled_back(
        self,
        audit_id: str,
        rollback_audit_id: str,
        rolled_back_at: str,
    ) -> None:
        """Mark the original audit entry as rolled back.

        Updates the result field of the original audit entry to include
        rollback metadata, preventing double-rollback.

        Args:
            audit_id: The original audit entry ID.
            rollback_audit_id: The ID of the rollback audit entry.
            rolled_back_at: ISO 8601 timestamp of when rollback occurred.
        """
        async with get_connection(self._db_path) as conn:
            # Get current result
            cursor = await conn.execute(
                "SELECT result FROM audit_logs WHERE id = ?",
                (audit_id,),
            )
            row = await cursor.fetchone()
            if row is None:
                return

            # Update result with rollback info
            current_result = json.loads(row["result"]) if row["result"] else {}
            current_result["rolled_back_at"] = rolled_back_at
            current_result["rollback_audit_id"] = rollback_audit_id

            await conn.execute(
                "UPDATE audit_logs SET result = ? WHERE id = ?",
                (json.dumps(current_result), audit_id),
            )
            await conn.commit()

    async def perform_rollback(self, audit_id: str) -> dict[str, Any]:
        """Perform a complete rollback operation.

        This is the main entry point for rollback operations. It:
        1. Validates the rollback can be performed
        2. Retrieves the previous state
        3. Executes the rollback via BPA API
        4. Marks the original operation as rolled back

        Note: This method does NOT create an audit record for the rollback
        operation itself - that should be done by the calling tool.

        Concurrency (issue #179): two concurrent calls with the same
        audit_id are serialized via a per-audit-id asyncio.Lock. The first
        call's mark_rolled_back updates the result field; the second call
        re-runs validate_rollback and trips the `_check_already_rolled_back`
        gate, raising RollbackNotPossibleError. Without the lock, both
        calls could pass that gate and double-execute the BPA API call.

        Single-process scope only. Cross-process serialization (multiple
        MCP server instances against the same audit DB) would require
        database-level locking (SELECT FOR UPDATE on the audit row) and
        is out of scope.

        Args:
            audit_id: The UUID of the audit entry to rollback.

        Returns:
            Dict with rollback result including:
            - status: "success"
            - message: Human-readable description
            - original_operation: Details of what was rolled back
            - restored_state: The restored object state (if applicable)

        Raises:
            RollbackNotPossibleError: If validation fails.
            RollbackError: If execution fails.
        """
        lock = await self._acquire_audit_lock(audit_id)
        async with lock:
            return await self._perform_rollback_unlocked(audit_id)

    async def _perform_rollback_unlocked(self, audit_id: str) -> dict[str, Any]:
        """Implementation of perform_rollback assuming the per-audit lock
        is already held. Do not call directly — call perform_rollback,
        which acquires the lock first.
        """
        # Validate rollback
        entry = await self.validate_rollback(audit_id)

        # Get rollback state
        rollback_state = await self._get_rollback_state(entry["rollback_state_id"])
        if rollback_state is None:
            raise RollbackError(
                f"Rollback state '{entry['rollback_state_id']}' not found. "
                "Database may be corrupted."
            )

        # Parse previous state
        previous_state = (
            json.loads(rollback_state["previous_state"])
            if rollback_state["previous_state"]
            else None
        )

        # Parse params for context (service_id, registration_id, etc.)
        params = json.loads(entry["params"]) if entry["params"] else {}

        # Parse post-write state from audit result field (used by
        # component_formula rollback for drift detection).
        result_field = json.loads(entry["result"]) if entry.get("result") else None

        # Execute rollback
        operation_type = entry["operation_type"]
        object_type = entry["object_type"]
        # For create operations, object_id in audit_logs is None (we don't know ID
        # until after creation). Use object_id from rollback_state as fallback.
        object_id = entry["object_id"] or rollback_state["object_id"]

        exec_result = await self.execute_rollback(
            operation_type=operation_type,
            object_type=object_type,
            object_id=object_id,
            previous_state=previous_state,
            params=params,
            result=result_field,
        )

        # Invalidate form cache after form rollback (issue #169 expanded to
        # cover all three form-related audit object_types).
        if object_type in {"form", "form_component", "form_component_copy"}:
            service_id = params.get("service_id")
            form_type = params.get("form_type")
            if service_id and form_type:
                try:
                    from mcp_eregistrations_bpa.db.form_cache import (
                        invalidate_form_cache,
                    )

                    await invalidate_form_cache(
                        str(service_id), form_type, self._db_path
                    )
                except Exception:  # noqa: S110 — best-effort cache invalidation after rollback; SQLite/import errors are non-fatal.
                    pass

        # Build message
        action = exec_result.get("action", "unknown")
        if action == "deleted":
            message = (
                f"Rolled back 'create' on {object_type} '{object_id}' - object deleted"
            )
        elif action == "restored":
            message = f"Rolled back 'update' on {object_type} '{object_id}'"
        elif action == "recreated":
            new_id = exec_result.get("new_id", "unknown")
            message = (
                f"Rolled back 'delete' on {object_type} '{object_id}' - "
                f"object recreated as '{new_id}'"
            )
        else:
            message = f"Rolled back '{operation_type}' on {object_type} '{object_id}'"

        # Build response
        rolled_back_at = datetime.now(UTC).isoformat()
        result: dict[str, Any] = {
            "status": "success",
            "message": message,
            "original_operation": {
                "audit_id": entry["id"],
                "operation_type": operation_type,
                "object_type": object_type,
                "object_id": object_id,
                "timestamp": entry["timestamp"],
            },
            "restored_state": previous_state,
            "rolled_back_at": rolled_back_at,
        }

        # Add new_id for recreated objects
        if action == "recreated" and exec_result.get("new_id"):
            result["new_object_id"] = exec_result["new_id"]

        # Issue #179: persist the rolled_back_at flag to the audit row so
        # future perform_rollback calls (and audit_get queries) see this
        # operation as already rolled back. _mark_rolled_back exists since
        # the original rollback feature (story 3-9) but was never invoked
        # by perform_rollback — making _check_already_rolled_back a dead
        # guard. Without this persistence, the per-audit mutex would still
        # prevent concurrent double-execute, but a SERIAL second call (e.g.
        # operator hits rollback twice) would re-execute. The rollback_audit_id
        # arg is None here because we don't mint a new audit row for the
        # rollback itself (the calling tool does — see audit_get docs).
        await self._mark_rolled_back(
            audit_id=audit_id,
            rollback_audit_id="",  # Calling tool is expected to set this
            rolled_back_at=rolled_back_at,
        )

        return result
