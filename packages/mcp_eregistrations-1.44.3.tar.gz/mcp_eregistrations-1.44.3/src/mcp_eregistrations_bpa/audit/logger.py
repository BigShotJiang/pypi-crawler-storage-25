"""BPA audit logger — thin wrapper around the common AuditLogger.

Automatically injects BPA's ``get_connection`` so callers don't need to
provide it. Adds a BPA-specific bidirectional rollback contract on top of
the common ``mark_success`` (issue #177).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mcp_eregistrations_bpa.db import get_connection
from mcp_eregistrations_common.audit.logger import (  # noqa: F401
    AuditEntryImmutableError,
    AuditEntryNotFoundError,
)
from mcp_eregistrations_common.audit.logger import (
    AuditLogger as _CommonAuditLogger,
)

__all__ = [
    "AuditEntryImmutableError",
    "AuditEntryNotFoundError",
    "AuditContractError",
    "AuditLogger",
]


class AuditContractError(Exception):
    """Raised when an audit row is marked success without making an explicit
    rollback decision (issue #177).

    The BPA audit contract requires every write operation to either:
      1. Call ``save_rollback_state(...)`` to capture a rollback target, OR
      2. Operate on an object_type/operation_type pair classified as
         intentionally non-rollbackable (see
         ``mcp_eregistrations_bpa.rollback.manager._classify_non_rollbackable``).

    A tool that does neither leaves its audit row un-rollbackable at
    runtime with a confusing "no saved state" error. This contract closes
    that gap at audit time so the defect surfaces in dev, not in
    production.

    Resolution paths (the error message includes these):
      - Call ``save_rollback_state(...)`` before ``mark_success(...)``
      - Add ``(object_type, operation_type)`` to ``_NON_ROLLBACKABLE_OP``
        in ``rollback/manager.py`` with a one-line reason
      - Or add ``object_type`` to ``_NON_ROLLBACKABLE_EXACT`` or
        ``_NON_ROLLBACKABLE_PREFIX`` for blanket classification
    """


class AuditLogger(_CommonAuditLogger):
    """BPA-specific AuditLogger.

    Auto-injects BPA's ``get_connection`` and adds the issue #177
    bidirectional rollback contract on ``mark_success``: a write operation
    cannot be marked success unless EITHER ``save_rollback_state`` was
    called for the same audit_id OR the object_type is classified as
    intentionally non-rollbackable.
    """

    def __init__(self, db_path: Path | None = None):
        super().__init__(db_path=db_path, get_connection=get_connection)

    async def mark_success(self, audit_id: str, result: dict[str, Any]) -> None:
        """Mark operation as successful with result summary.

        Issue #177 contract: a BPA audit row cannot be marked success
        unless EITHER rollback state was captured for it OR the
        (object_type, operation_type) is intentionally non-rollbackable.

        The contract check ONLY fires on PENDING rows. If the row is
        already in SUCCESS/FAILED state, the parent's mark_success raises
        AuditEntryImmutableError before our check would matter — that
        ordering preserves backward compatibility for tests that exercise
        the append-only enforcement.

        Raises:
            AuditEntryNotFoundError: If audit_id does not exist.
            AuditEntryImmutableError: If entry is not in PENDING status.
            AuditContractError: If the operation has neither rollback
                state nor a non-rollbackable classification.
        """
        # The rollback classifier and the common parent both need to run.
        # Import lazily to avoid loading rollback machinery at module load
        # time (and to keep audit/ importable even if rollback/ ever has
        # an issue).
        from mcp_eregistrations_bpa.rollback.manager import (
            _classify_non_rollbackable,
        )

        async with self._conn() as conn:
            cursor = await conn.execute(
                "SELECT status, operation_type, object_type, rollback_state_id "
                "FROM audit_logs WHERE id = ?",
                (audit_id,),
            )
            row = await cursor.fetchone()

        # Only enforce the contract on PENDING rows. For missing rows or
        # already-finalised rows, fall through to the parent's checks
        # (NotFound / ImmutableError) so we don't change those failure
        # modes.
        if row is not None and row["status"] == "pending":
            object_type = row["object_type"]
            operation_type = row["operation_type"]
            has_rollback_state = row["rollback_state_id"] is not None
            non_rollbackable_reason = _classify_non_rollbackable(
                object_type, operation_type
            )
            if not has_rollback_state and non_rollbackable_reason is None:
                raise AuditContractError(
                    f"Audit row '{audit_id}' on "
                    f"'{object_type}'.{operation_type} was marked success "
                    "without calling save_rollback_state(...) AND the type "
                    "is not classified as intentionally non-rollbackable. "
                    "Pick one of:\n"
                    "  1. Call save_rollback_state(audit_id, object_type, "
                    "object_id, previous_state) BEFORE mark_success(...)\n"
                    "  2. Add (object_type, operation_type) to "
                    "_NON_ROLLBACKABLE_OP in rollback/manager.py with a "
                    "one-line reason if this operation has no recoverable "
                    "previous state\n"
                    "  3. Add object_type to _NON_ROLLBACKABLE_EXACT or "
                    "_NON_ROLLBACKABLE_PREFIX for blanket classification\n"
                    "See issue #177 for context."
                )

        # Delegate the actual mark_success (which also re-validates pending
        # status and writes the SUCCESS row + result JSON).
        await super().mark_success(audit_id, result)
