"""Custom exception hierarchy for MCP server."""


class MCPError(Exception):
    """Base exception for all MCP server errors."""

    pass


class ConfigurationError(MCPError):
    """Raised when configuration is invalid or missing."""

    pass


class CASSecretMissingError(ConfigurationError):
    """Raised when a CAS profile is loaded but its client secret cannot be
    resolved from the auth store.

    Subclass of ConfigurationError so existing generic handlers still catch
    it transparently; the named subclass gives callers (tests, the autopilot
    bot, log-based alerting) a stable type to pattern-match on instead of a
    brittle error-string match.
    """

    pass


class AuthenticationError(MCPError):
    """Raised when authentication fails."""

    pass


class BPAClientError(MCPError):
    """Raised when BPA API client encounters an error."""

    pass


class PermissionDeniedError(MCPError):
    """Raised when user lacks required permission.

    This is distinct from AuthenticationError which indicates
    the user is not authenticated at all. PermissionDeniedError means
    the user is authenticated but lacks specific permissions.

    Note: Named PermissionDeniedError to avoid shadowing Python's
    built-in PermissionError (an OSError subclass).
    """

    pass
