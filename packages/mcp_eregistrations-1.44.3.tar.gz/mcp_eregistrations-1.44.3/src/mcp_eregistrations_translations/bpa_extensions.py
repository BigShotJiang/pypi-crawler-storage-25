"""Standalone BPA HTTP client for translation tools.

Self-contained client that talks directly to the BPA REST API without
depending on BPAClient from the BPA package. Follows the same pattern
as GDBClient and DSClient (for_instance + async context manager + common auth).
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import httpx
from fastmcp.exceptions import ToolError

_DEFAULT_TIMEOUT = 30.0
_BPA_API_PATH = "/bparest/bpa/v2016/06"

logger = logging.getLogger(__name__)


class TranslationBPAClientError(Exception):
    """Error from BPA API during translation operations."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class TranslationBPAClient:
    """Async HTTP client for BPA translation API endpoints.

    Usage:
        async with TranslationBPAClient.for_instance("jamaica") as client:
            rows = await client.get_all_translations("svc-1")
    """

    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        instance: str | None = None,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        self._base_url = base_url.rstrip("/")
        if not self._base_url.endswith(_BPA_API_PATH):
            self._base_url = self._base_url + _BPA_API_PATH
        self._token = token
        self._instance = instance
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @classmethod
    def for_instance(cls, instance: str | None = None) -> TranslationBPAClient:
        """Create a client from instance config.

        Uses the common config module (instances.yaml + component profiles).
        Token resolved lazily in __aenter__ from common auth module.
        """
        from mcp_eregistrations_common.config import get_instance_config

        config = get_instance_config(instance)
        bpa_url = config.get("bpa_url")
        if not bpa_url:
            raise ToolError(
                f"No bpa_url configured for instance '{instance}'. "
                f"Check instances.yaml or register with instance_add."
            )
        return cls(base_url=bpa_url, instance=instance)

    async def _resolve_token(self) -> str | None:
        """Resolve a fresh access token from common auth module."""
        if self._instance:
            from mcp_eregistrations_common.auth import get_or_refresh_token

            return await get_or_refresh_token(self._instance)
        return self._token

    async def __aenter__(self) -> TranslationBPAClient:
        if not self._token:
            self._token = await self._resolve_token()

        headers: dict[str, str] = {"Accept": "application/json"}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers=headers,
            timeout=self._timeout,
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    def _ensure_client(self) -> httpx.AsyncClient:
        """Return the httpx client, raising if not in context manager."""
        assert self._client is not None, (
            "Use 'async with TranslationBPAClient(...)' first"
        )
        return self._client

    # -- Low-level HTTP methods ------------------------------------------------

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """GET request, return parsed JSON."""
        client = self._ensure_client()
        resp = await client.get(path, params=params)
        return self._handle_response(resp)

    async def put(
        self, path: str, json: dict[str, Any] | list[Any] | None = None
    ) -> Any:
        """PUT request with JSON body."""
        client = self._ensure_client()
        resp = await client.put(path, json=json)
        return self._handle_response(resp)

    async def post(
        self,
        path: str,
        json: dict[str, Any] | list[Any] | None = None,
        timeout: float | None = None,
    ) -> Any:
        """POST request. Optional per-call timeout override for slow endpoints."""
        client = self._ensure_client()
        if timeout is not None:
            resp = await client.post(path, json=json, timeout=timeout)
        else:
            resp = await client.post(path, json=json)
        return self._handle_response(resp)

    def _handle_response(self, resp: httpx.Response) -> Any:
        """Check response status and return JSON or raise."""
        if resp.status_code == 204:
            return {}
        if resp.status_code in (200, 201):
            if not resp.content:
                return {}
            return resp.json()

        # Error path
        try:
            body = resp.json()
        except Exception:
            body = resp.text

        msg = body.get("message", str(body)) if isinstance(body, dict) else str(body)
        raise TranslationBPAClientError(msg, status_code=resp.status_code)

    # -- Translation-specific methods ------------------------------------------

    async def get_translations_page(
        self,
        service_id: str,
        page_no: int = 1,
        page_size: int = 25,
        types: list[str] | None = None,
        form_id: str | None = None,
        form_type: str | None = None,
    ) -> dict[str, Any]:
        """GET /service/{id}/translations with custom pagination.

        Args:
            service_id: Service UUID.
            page_no: Page number (default: 1).
            page_size: Results per page (default: 25).
            types: Filter by translation types.
            form_id: Filter by form ID.
            form_type: Filter by form type.

        Returns:
            dict with pageNumber, resultsPerPage, totalResults, items.
        """
        params: dict[str, Any] = {"pageNo": page_no, "pageSize": page_size}
        if types:
            params["type"] = types
        if form_id:
            params["formId"] = form_id
        if form_type:
            params["formType"] = form_type
        result: dict[str, Any] = await self.get(
            f"service/{service_id}/translations", params=params
        )
        return result

    async def get_all_translations(
        self,
        service_id: str,
        types: list[str] | None = None,
        form_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch all pages of the translation matrix.

        First page is fetched synchronously to learn totalResults; remaining
        pages are fetched concurrently with asyncio.gather.

        Args:
            service_id: Service UUID.
            types: Filter by translation types.
            form_id: Filter by form ID.

        Returns:
            Flat list of matrix rows (in page order).
        """
        page_size = 100
        first_page = await self.get_translations_page(
            service_id,
            page_no=1,
            page_size=page_size,
            types=types,
            form_id=form_id,
        )
        all_items: list[dict[str, Any]] = list(first_page.get("items", []))
        total = first_page.get("totalResults", 0)

        if total <= page_size:
            return all_items

        # Fan-out remaining pages concurrently.
        last_page = (total + page_size - 1) // page_size
        remaining = [
            self.get_translations_page(
                service_id,
                page_no=page_no,
                page_size=page_size,
                types=types,
                form_id=form_id,
            )
            for page_no in range(2, last_page + 1)
        ]
        pages = await asyncio.gather(*remaining)
        for page in pages:
            all_items.extend(page.get("items", []))
        return all_items

    async def update_local_translation(
        self, service_id: str, body: dict[str, Any]
    ) -> dict[str, Any]:
        """PUT /service/{id}/local_translation -- single entry.

        Args:
            service_id: Service UUID.
            body: Translation payload.

        Returns:
            dict with updated translation.
        """
        result: dict[str, Any] = await self.put(
            f"service/{service_id}/local_translation", json=body
        )
        return result

    async def search_translations(
        self, service_id: str, search_string: str, **kwargs: Any
    ) -> dict[str, Any]:
        """GET /service/{id}/search_translations.

        Args:
            service_id: Service UUID.
            search_string: Text to search for.
            **kwargs: Additional query params (e.g. exactMatch).

        Returns:
            dict with items, totalResults.
        """
        params: dict[str, Any] = {"searchString": search_string, **kwargs}
        result: dict[str, Any] = await self.get(
            f"service/{service_id}/search_translations", params=params
        )
        return result

    async def update_global_translation(self, body: dict[str, Any]) -> dict[str, Any]:
        """PUT /translation/general/global_translation -- DS system string.

        Args:
            body: Global translation payload.

        Returns:
            dict with updated translation.
        """
        result: dict[str, Any] = await self.put(
            "translation/general/global_translation", json=body
        )
        return result

    async def delete_translations(self, ids: list[str]) -> dict[str, Any]:
        """POST /translation/delete -- delete a batch of translation IDs.

        Returns:
            dict with deletedIds, unauthorizedIds.
        """
        result: dict[str, Any] = await self.post("translation/delete", json=ids)
        return result

    async def sync_translation_keys(
        self, domain: str, keys: list[str]
    ) -> dict[str, Any]:
        """PUT /translations/sync/{domain} -- push keys to GTS.

        Args:
            domain: Translation domain (e.g. "DS").
            keys: List of translation keys to sync.

        Returns:
            dict with sync result.
        """
        result: dict[str, Any] = await self.put(
            f"translations/sync/{domain}", json=keys
        )
        return result

    async def get_cached_translations(self, lang: str = "en") -> dict[str, str]:
        """GET /translation/cached -- the BPA translation cache map.

        Returns the resolved fieldId -> value map for the requested language.
        Used by global_status to probe whether the Global
        Translation bootstrap has run on this instance.

        Args:
            lang: Language code (default: "en").

        Returns:
            dict of fieldId (e.g. "nav.services") -> resolved string.
            Empty dict if the cache has never been populated.
        """
        result = await self.get("translation/cached", params={"lang": lang})
        if isinstance(result, dict):
            return {k: v for k, v in result.items() if isinstance(v, str)}
        return {}

    async def reload_global_translations(
        self, timeout: float = 120.0
    ) -> dict[str, Any]:
        """POST /translation/general/reload_global -- pull from GTS.

        Backend iterates every active language and every translation domain
        (BPA, DS, STATISTICS) and reconciles them against the Global catalog.
        Internally invokes reloadTranslationCache() on success, so callers do
        NOT need to call reload_cache separately.

        The real call takes 10-30s depending on language count and GTS latency.

        Args:
            timeout: Per-call timeout in seconds (default: 120.0).

        Returns:
            dict with message (str), status (str). Typical message:
            "Created N translations and updated M translations within Z ms."
        """
        result: dict[str, Any] = await self.post(
            "translation/general/reload_global", timeout=timeout
        )
        return result

    async def reload_cache_only_translations(
        self, timeout: float = 30.0
    ) -> dict[str, Any]:
        """POST /translation/general/reload_cache -- rebuild in-memory cache only.

        Backend rebuilds the in-memory bpaTranslationCache from existing
        GeneralTranslation rows in the local DB. No GTS round-trip, no DB writes.
        Lighter than reload_global_translations -- use after a backend deploy
        when the local DB is known good but the cache is suspected stale.

        Args:
            timeout: Per-call timeout in seconds (default: 30.0).

        Returns:
            dict with backend's response (typically message, status).
        """
        result: dict[str, Any] = await self.post(
            "translation/general/reload_cache", timeout=timeout
        )
        return result

    async def get_languages(self) -> list[dict[str, Any]]:
        """GET /language -- active languages.

        Returns:
            List of language dicts with code, active fields.
        """
        result = await self.get("language")
        if isinstance(result, list):
            return result
        # Some endpoints wrap in a dict; unwrap if needed
        items: list[dict[str, Any]] = result.get("items", result.get("content", []))
        return items

    async def list_services(self) -> list[dict[str, Any]]:
        """GET /service -- active services in the instance."""
        result = await self.get("service")
        if isinstance(result, list):
            return result
        items: list[dict[str, Any]] = result.get("content", result.get("items", []))
        return items

    async def get_translation_settings(self) -> dict[str, bool]:
        """GET /translation/general/properties."""
        raw: dict[str, Any] = await self.get("translation/general/properties")
        return {k: bool(v) for k, v in raw.items()}

    async def set_translation_settings(
        self,
        local_authorized: bool | None,
        local_supersedes_global: bool | None,
    ) -> dict[str, Any]:
        """PUT /translation/general/properties."""
        bpa_props: dict[str, bool] = {}
        if local_authorized is not None:
            bpa_props["localAuthorized"] = local_authorized
        if local_supersedes_global is not None:
            bpa_props["localSupersedesGlobal"] = local_supersedes_global
        body = {"bpaProperties": bpa_props}
        result: dict[str, Any] = await self.put(
            "translation/general/properties",
            json=body,
        )
        return result

    async def replace_or_create_translation(
        self, service_id: str, dto: dict[str, Any]
    ) -> dict[str, Any]:
        """POST /service/{id}/replace_or_create -- rename or create translation row."""
        result: dict[str, Any] = await self.post(
            f"service/{service_id}/replace_or_create",
            json=dto,
        )
        return result
