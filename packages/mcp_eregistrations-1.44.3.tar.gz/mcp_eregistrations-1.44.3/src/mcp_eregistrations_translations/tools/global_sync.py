"""Global Translation Service sync tools.

Two tools that automate the "Global Translation" button workflow in the BPA
admin UI. Together they replace the SSH + curl recovery runbook used when a
country instance comes up without the initial translation pull from the
Global Translation Service (GTS).

- global_status  -- read-only probe. Reports whether the instance
  needs a reload.
- global_reload  -- audited write. Triggers the pull and parses
  the upstream summary message.

See src/mcp_eregistrations_translations/CLAUDE.md for package patterns.
"""

from __future__ import annotations

import re
from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_translations.audit_helpers import (
    get_audit_logger,
    get_current_user_email,
)
from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.server import mcp

_CANONICAL_PROBE_KEYS: tuple[str, ...] = (
    "nav.services",
    "nav.annexes",
    "header.settings",
    "level.general",
    "page.translations.global_trans_btn",
)

_RELOAD_SUMMARY_RE = re.compile(
    r"Created\s+(?P<created>\d+)\s+translations\s+and\s+updated\s+"
    r"(?P<updated>\d+)\s+translations\s+within\s+(?P<duration>\d+)\s+ms",
    re.IGNORECASE,
)


def _parse_reload_message(message: str) -> tuple[int, int, int]:
    """Extract (created, updated, duration_ms) from the backend summary.

    Returns (-1, -1, -1) when the message doesn't match — the caller should
    still return success but expose the raw message for inspection.
    """
    match = _RELOAD_SUMMARY_RE.search(message or "")
    if not match:
        return -1, -1, -1
    return (
        int(match.group("created")),
        int(match.group("updated")),
        int(match.group("duration")),
    )


async def _check_global_status(
    instance: str | None,
    probe_keys: list[str] | None,
    language: str,
) -> dict[str, Any]:
    """Internal probe used by both status and reload tools."""
    keys = list(probe_keys) if probe_keys else list(_CANONICAL_PROBE_KEYS)

    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            cache = await client.get_cached_translations(lang=language)
    except TranslationBPAClientError as e:
        if e.status_code in (401, 403):
            raise ToolError(
                "Not authorized to read the translation cache. "
                "Authenticate with auth_login using an operator that has the "
                "translation admin role."
            ) from e
        raise ToolError(f"BPA API error reading translation cache: {e}") from e

    resolved: dict[str, str] = {}
    missing: list[str] = []
    for k in keys:
        value = cache.get(k)
        if value:
            resolved[k] = value
        else:
            missing.append(k)

    reload_recommended = bool(missing) or not cache
    if reload_recommended:
        recommendation = (
            f"Run global_reload — {len(missing)} of "
            f"{len(keys)} probe keys unresolved on '{language}'."
        )
    else:
        recommendation = "No action needed — instance is in sync with GTS."

    return {
        "instance": instance or "default",
        "language": language,
        "reload_recommended": reload_recommended,
        "probed_keys": keys,
        "missing_keys": missing,
        "sample_resolved": resolved,
        "cache_size": len(cache),
        "recommendation": recommendation,
    }


@mcp.tool()
async def global_status(
    instance: str | None = None,
    probe_keys: list[str] | None = None,
    language: str = "en",
) -> dict[str, Any]:
    """Check if an instance is in sync with the Global Translation Service.

    Probes canonical BPA shell keys against /translation/cached. If any probe
    key is missing or empty, recommends running global_reload.

    Args:
        instance: Instance profile name.
        probe_keys: Keys to probe (default: canonical 5-key BPA shell set).
        language: Language code to probe (default: "en").

    Returns:
        dict with instance, language, reload_recommended, probed_keys,
        missing_keys, sample_resolved, cache_size, recommendation.
    """
    return await _check_global_status(instance, probe_keys, language)


@mcp.tool()
async def global_reload(
    instance: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """Pull translations from the Global Translation Service. Audited write.

    Equivalent of the "Global Translation" button in the BPA admin UI.
    Backend iterates all active languages and reconciles BPA, DS, and
    STATISTICS domains. The cache is reloaded internally — no separate call
    needed.

    Refuses to run when global_status reports no action needed,
    unless force=True.

    Args:
        instance: Instance profile name.
        force: Run even if the instance already looks in sync (default: False).

    Returns:
        dict with instance, created, updated, duration_ms, status,
        raw_message, audit_id, forced.
    """
    if not force:
        status = await _check_global_status(instance, None, "en")
        if not status["reload_recommended"]:
            raise ToolError(
                "Instance appears to be in sync with the Global Translation "
                "Service already. Run global_status for details, "
                "or pass force=True to reload anyway."
            )

    user_email = await get_current_user_email(instance)
    audit_logger = await get_audit_logger(instance)
    audit_id = await audit_logger.record_pending(
        user_email=user_email,
        operation_type="TRANSLATION_GLOBAL_RELOAD",
        object_type="TRANSLATION",
        params={"instance": instance or "default", "forced": force},
    )

    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            response = await client.reload_global_translations()
    except TranslationBPAClientError as e:
        await audit_logger.mark_failed(audit_id, error_message=str(e))
        if e.status_code in (401, 403):
            raise ToolError(
                "Not authorized to reload global translations. The operator "
                "must have the translation admin role in this instance's "
                "Keycloak realm."
            ) from e
        raise ToolError(f"BPA API error during global translation reload: {e}") from e

    raw_message = (
        response.get("message", "") if isinstance(response, dict) else str(response)
    )
    status_str = response.get("status", "OK") if isinstance(response, dict) else "OK"
    created, updated, duration_ms = _parse_reload_message(raw_message)

    await audit_logger.mark_success(
        audit_id,
        result={
            "created": created,
            "updated": updated,
            "duration_ms": duration_ms,
            "status": status_str,
        },
    )

    return {
        "instance": instance or "default",
        "created": created,
        "updated": updated,
        "duration_ms": duration_ms,
        "status": status_str,
        "raw_message": raw_message,
        "audit_id": audit_id,
        "forced": force,
    }


@mcp.tool()
async def cache_reload(
    instance: str | None = None,
) -> dict[str, Any]:
    """Rebuild the in-memory translation cache from the local DB. Audited write.

    Equivalent of the "Reload Cache" button in the BPA admin UI. Lighter than
    global_reload -- no GTS round-trip, no DB writes. Use after a backend deploy
    when the local DB is known good but the in-memory cache may be stale.

    Args:
        instance: Instance profile name.

    Returns:
        dict with instance, status, raw_message, audit_id.
    """
    user_email = await get_current_user_email(instance)
    audit_logger = await get_audit_logger(instance)
    audit_id = await audit_logger.record_pending(
        user_email=user_email,
        operation_type="TRANSLATION_CACHE_RELOAD",
        object_type="TRANSLATION",
        params={"instance": instance or "default"},
    )

    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            response = await client.reload_cache_only_translations()
    except TranslationBPAClientError as e:
        await audit_logger.mark_failed(audit_id, error_message=str(e))
        if e.status_code in (401, 403):
            raise ToolError(
                "Not authorized to reload the translation cache. The operator "
                "must have the translation admin role in this instance's "
                "Keycloak realm."
            ) from e
        raise ToolError(f"BPA API error during cache reload: {e}") from e

    raw_message = (
        response.get("message", "") if isinstance(response, dict) else str(response)
    )
    status_str = response.get("status", "OK") if isinstance(response, dict) else "OK"

    await audit_logger.mark_success(
        audit_id,
        result={"status": status_str},
    )

    return {
        "instance": instance or "default",
        "status": status_str,
        "raw_message": raw_message,
        "audit_id": audit_id,
    }
