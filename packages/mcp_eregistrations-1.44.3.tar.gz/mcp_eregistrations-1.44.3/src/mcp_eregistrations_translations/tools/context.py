"""Translation context tool: compiled translation brief with structural context."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_bpa.constants.form_endpoints import FORM_ENDPOINTS
from mcp_eregistrations_translations.bpa_extensions import (
    TranslationBPAClient,
    TranslationBPAClientError,
)
from mcp_eregistrations_translations.context.compiler import compile_translation_brief
from mcp_eregistrations_translations.keys import count_coverage
from mcp_eregistrations_translations.server import mcp

# Form type to BPA GET endpoint mapping — TranslationBPAClient expects paths
# without a leading slash, so strip it from the canonical map locally.
_FORM_ENDPOINTS: dict[str, str] = {
    ft: cfg["get_endpoint"].lstrip("/") for ft, cfg in FORM_ENDPOINTS.items()
}


def _auto_select_reference_lang(
    rows: list[dict[str, Any]], target_lang: str
) -> str | None:
    """Pick the most-complete non-target, non-English language as reference.

    Returns None if only en + target exist (bilingual).
    """
    coverage = count_coverage(rows)
    candidates = {
        lang: counts["translated"]
        for lang, counts in coverage.items()
        if lang not in ("en", target_lang)
    }
    if not candidates:
        return None
    return max(candidates, key=lambda k: candidates[k])


@mcp.tool()
async def context(
    service_id: str,
    target_lang: str,
    form_id: str | None = None,
    form_type: str | None = None,
    category: str | None = None,
    include_translated: bool = False,
    page: int = 1,
    page_size: int = 50,
    reference_lang: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Compiled translation brief with structural context.

    Args:
        service_id: Service UUID.
        target_lang: Language code to translate into.
        form_id: Filter matrix by form ID.
        form_type: Form type for structural paths
            (applicant, guide, send_file, payment).
        category: Filter by category (service, forms, roles, etc.).
        include_translated: Include already-translated entries (default: False).
        page: Page number (default: 1).
        page_size: Entries per page (default: 50).
        reference_lang: Reference language code (auto-selected if omitted).
        instance: Instance profile name (default: active profile).

    Returns:
        dict with service_id, service_name, target_lang, reference_lang, brief.
    """
    try:
        async with TranslationBPAClient.for_instance(instance) as client:
            # Fetch service metadata
            service = await client.get(f"service/{service_id}")
            service_name: str = service.get("name", "")

            # Fetch translation matrix
            rows = await client.get_all_translations(service_id, form_id=form_id)

            # Fetch form structure if form_type specified
            form_structure: list[dict[str, Any]] | None = None
            if form_type:
                endpoint_tpl = _FORM_ENDPOINTS.get(form_type)
                if endpoint_tpl:
                    try:
                        endpoint = endpoint_tpl.replace("{id}", service_id)
                        form_data = await client.get(
                            endpoint,
                            params={"reusable": "false"},
                        )
                        form_structure = form_data.get("components")
                    except TranslationBPAClientError:
                        pass  # Form not available, proceed without paths

    except TranslationBPAClientError as e:
        raise ToolError(f"BPA API error for service '{service_id}': {e}") from e

    # Auto-select reference language if not provided
    if reference_lang is None:
        reference_lang = _auto_select_reference_lang(rows, target_lang)

    # Compile the brief
    brief = compile_translation_brief(
        rows=rows,
        target_lang=target_lang,
        reference_lang=reference_lang,
        form_structure=form_structure,
        category=category,
        include_translated=include_translated,
        page=page,
        page_size=page_size,
    )

    return {
        "service_id": service_id,
        "service_name": service_name,
        "target_lang": target_lang,
        "reference_lang": reference_lang,
        "brief": brief,
    }
