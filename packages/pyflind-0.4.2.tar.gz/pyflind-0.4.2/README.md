# Python FieldLineIndustries

A python library for interfacing with FieldLine Industries' products.

Install with:
```
pip install -U pyflind
```

See the [documentation](https://pyflind.readthedocs.io/en/latest/) for usage and examples.
