from collections.abc import Mapping, Sequence
import logging
import wavfile

from .base import FliRecorder, FliRecording


WAV_TS_SCALE = 1000000 # convert time to integer number of microseconds


class WavRecorder(FliRecorder):
    '''Iteratively record a set of sampled signals in a WAV formatted file.

    The filename and samplerate is set on instantiation and the channels to
    save in the file are automatically determined on the first call to
    write_data. When recording is complete call close.

    Metadata is stored in the comment string of the WAV file as key=value
    string pairs separated by ';'. Information required to reconstruct the
    provided data is automatically inserted and used when loading the
    recording. Any provided metadata is appended and also available when
    loaded but otherwise unused.

    Args:
        filename: name of WAV file
        fs: samplerate in Hz
    '''

    def __init__(self, filename: str, fs: float = 0, metadata: Mapping[str,str] = {}) -> None:
        self._filename = filename
        self._fs = fs
        self._metadata = metadata
        self._wav_fs = int(fs)
        self._chs = []
        self._comment = ''
        self._rx_t0 = None
        self._wav = None

    def _open_wav(self, data: Mapping[str|int, Sequence[int|float]]) -> None:
        '''Internal function to open a WAV file.

        Saves metadata required to reconstruct the original channel data
        in the WAV comment tag.

        Args:
            data: block of samples as for :func:`write_data`
        '''
        self._chs = [ str(c) for c in data.keys() ]
        self._comment = 'channels=' + ','.join(self._chs)
        self._rx_t0 = None
        if self._fs != self._wav_fs:
            self._comment += f';fs={self._fs}'

        for ch in self._chs:
            if 'rx_t' in ch:
                if self._rx_t0 is None:
                    self._rx_t0 = data[ch][0]
                else:
                    self._rx_t0 = min(data[ch][0], self._rx_t0)

        if self._rx_t0 is not None:
            self._comment += f';rx_t0={self._rx_t0}'

        for k,v in self._metadata.items():
            self._comment += f';{k}={v}'

        self._wav = wavfile.open(self._filename,
                                 'w',
                                 sample_rate=self._wav_fs,
                                 num_channels=len(self._chs),
                                 bits_per_sample=32,
                                 fmt=wavfile.chunk.WavFormat.EXTENSIBLE)
        self._wav.add_metadata(comment=self._comment)

    def close(self) -> None:
        if self._wav is not None:
            self._wav.close()
            self._wav = None

    def write_data(self, data: Mapping[str|int, Sequence[int|float]]) -> int:
        '''Write a block of samples to the file.

        The data is provided in a dictionary of sample arrays, each having
        the same length (number of samples). The keys represent signal names
        which correspond to channels in the WAV file. The WAV file is opened
        and metadata written on the first call to write_data which determines
        the set of fields and order of fields for the file. Each subsequent
        call to write_data must have the same fields and appends the samples
        to the WAV file.

        Args:
            data: block of samples to write

        Returns:
            int: number of samples written
        '''
        if self._wav is None:
            self._open_wav(data)

        n_samples = len(data[self._chs[0]])
        frames = []
        for i in range(n_samples):
            frame = []
            for ch in self._chs:
                value = data[ch][i]

                # channel type specific conversion to int
                if 'rx_t' in ch:
                    value = int(round((value-self._rx_t0)*WAV_TS_SCALE))
                elif 'rtt' in ch:
                    value = int(round(value*WAV_TS_SCALE))
                else:
                    # TODO warn if loss of precision?
                    value = int(value)

                frame.append(value)

            frames.append(frame)

        self._wav.write(frames)

        return n_samples


class WavRecordingError(Exception):
    pass


class WavRecording(FliRecording):
    '''Load a set of sampled signals from a WAV formatted file.

    Data is retrievable by channel/stream name by indexing an object
    of this type. The object also supports iteration and will iterate
    through all streams except time (computed sample time). This makes
    for convenient signal processing or plotting, for example::

        wav_recording = WavRecording('some_file.wav')
        t = wav_recording['time']
        for stream in wav_recording:
            do_something(t, wav_recording[stream])

    Args:
        filename: name of WAV file
        time_zero: subtract the first timestamp from all times if True
        fs: ignored, actual samplerate extracted from file
        limit: max number of samples to read from file, 0 for all
        convert_field: convert channels representing magnetic field to units of T if True
    '''
    def __init__(self,
                 filename: str,
                 time_zero: bool = False,
                 fs: float = 0.0,
                 limit: int = 0,
                 convert_field: bool = True) -> None:
        self._filename = filename
        self._logger = logging.getLogger('WavRecording')

        wav = wavfile.open(filename, 'r')
        self._fs = wav.sample_rate

        # parse metadata from comment
        self._comment = wav.metadata['comment']
        self._metadata = {}
        for part in self._comment.split(';'):
            if '=' not in part:
                continue
            k,v = part.split('=')

            if k == 'channels':
                v = v.split(',')
            elif k in ['fs', 'rx_t0']:
                v = float(v)

            self._metadata[k] = v

        # process metadata
        if 'channels' in self._metadata:
            self.ch_names = self._metadata['channels']
            if len(self.ch_names) != wav.num_channels:
                raise WavRecordingError(f'channel mismatch: {len(self.ch_names)} in comment, {wav.num_channels} in file')
        else:
            self._logger.error(f'channel list not found in WAV comment')
            self.ch_names = [ f'chan_{n}' for n in range(wav.num_channels) ]

        if 'fs' in self._metadata:
            self._fs = self._metadata['fs']

        if 'rx_t0' in self._metadata:
            self._rx_t0 = self._metadata['rx_t0']
        else:
            self._rx_t0 = 0

        # read and convert samples
        self._data = [ [] for _ in range(len(self.ch_names)) ]

        num_frames = limit if limit > 0 else None
        frames = wav.read(num_frames=num_frames)
        wav.close()

        for frame in frames:
            for i,ch in enumerate(self.ch_names):
                value = frame[i]

                if 'rx_t' in ch:
                    value = float(value)/WAV_TS_SCALE+self._rx_t0
                elif 'rtt' in ch:
                    value = float(value)/WAV_TS_SCALE
                elif convert_field:
                    if 'larmor_freq' in ch:
                        value = float(value) * 4e-3 / (2**32-1) / 6.99583
                    elif 'mag' in ch:
                        value = float(value) * 1e-13

                self._data[i].append(value)

        # compute time either from n stream or assuming no loss of samples
        if 'n' in self.ch_names:
            n_ch_idx = self.ch_names.index('n')
            scale = self._fs if self._fs > 0 else 1
            self._time = [ n / scale for n in self._data[n_ch_idx] ]
        else:
            scale = self._fs if self._fs > 0 else 1
            self._time = [ n / scale for n in range(len(self._data[0])) ]

        if time_zero:
            self._time = [ t - self._time[0] for t in self._time ]
