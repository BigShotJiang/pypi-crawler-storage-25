from collections.abc import Mapping
from .base import FliRecorder, FliRecording, FliRecorderError, FliRecordingError
from .csv import CsvRecorder, CsvRecording
from .wav import WavRecorder, WavRecording


FliRecorderClasses = {
        'csv': CsvRecorder,
        'wav': WavRecorder,
}

FliRecordingClasses = {
        'csv': CsvRecording,
        'wav': WavRecording,
}

def get_fli_recorder(filename: str, fs: float = 0, metadata: Mapping[str,str] = {}) -> FliRecorder:
    '''Instantiate the appropriate subclass of FliRecorder based on file type.

    Args:
        filename: name of file
        fs: samplerate in Hz
        metadata: string metadata to store with the recording
    '''
    file_ext = filename.split('.')[-1]

    if file_ext in FliRecorderClasses:
        return FliRecorderClasses[file_ext](filename, fs, metadata)
    else:
        raise FliRecorderError(f'unknown file type: {file_ext}')

def get_fli_recording(filename: str,
                      time_zero: bool = False,
                      fs: float = 0.0,
                      limit: int = 0,
                      convert_field: bool = True) -> FliRecording:
    '''Instantiate the appropriate subclass of FliRecording based on file type.

    Args:
        filename: name of CSV file
        time_zero: subtract the first timestamp from all times if True
        fs: samplerate in Hz if known, otherwise computed from file
        limit: max number of samples to read from file, 0 for all
        convert_field: convert magnetic field channels to units of T if True
    '''
    file_ext = filename.split('.')[-1]

    if file_ext in FliRecordingClasses:
        return FliRecordingClasses[file_ext](filename, time_zero, fs, limit, convert_field)
    else:
        raise FliRecordingError(f'unknown file type: {file_ext}')
