from abc import ABC, abstractmethod
from collections.abc import Iterator, Mapping, Sequence


class FliRecorderError(Exception):
    pass


class FliRecorder(ABC):
    '''Iteratively record a set of sampled signals to a file.

    Abstract base class defining a common interface for recording
    to any type of file implemented by subclasses.

    Args:
        filename: name of file
        fs: samplerate in Hz
        metadata: string metadata to store with the recording
    '''
    @abstractmethod
    def __init__(self, filename: str, fs: float = 0, metadata: Mapping[str,str] = {}) -> None:
        pass

    @abstractmethod
    def close(self) -> None:
        '''Close the recording.

        No more data can be written after calling close.
        '''
        pass

    @abstractmethod
    def write_data(self, data: Mapping[str|int, Sequence[int|float]]) -> int:
        '''Write a block of samples to the file.

        The data is provided in a dictionary of sample arrays, each having
        the same length (number of samples). The keys represent signal names
        which correspond to fields/channels in the file. All calls must have
        the same fields and append the samples to the recording file.

        Args:
            data: block of samples to write

        Returns:
            int: number of samples written
        '''
        pass


class FliRecordingError(Exception):
    pass


class FliRecording(ABC):
    '''Load a set of sampled signals from a file.

    Abstract base class defining a common interface for loading a
    recording of any type of file implemented by subclasses.

    A 'time' stream is automatically computed in a manner specific
    to the file type.

    Data is retrievable by stream/channel/column name by indexing an
    object of this type. The object also supports iteration and will
    iterate through all streams except time. This makes for convenient
    signal processing or plotting, for example::

        recording = FliRecordingSubClass('some_file.type')
        t = recording['time']
        for stream in recording:
            do_something(t, recording[stream])

    Args:
        filename: name of CSV file
        time_zero: subtract the first timestamp from all times if True
        fs: samplerate in Hz if known, otherwise computed from file
        limit: max number of samples to read from file, 0 for all
        convert_field: convert magnetic field channels to units of T if True
    '''
    @abstractmethod
    def __init__(self,
                 filename: str,
                 time_zero: bool = False,
                 fs: float = 0.0,
                 limit: int = 0,
                 convert_field: bool = True) -> None:
        self._filename = filename
        self._fs = fs
        self._data = []
        self._time = []
        self.ch_names = []
        self._metadata = {}

    def samplerate(self) -> float:
        '''Get the file samplerate.

        Samplerate is either provided at instantiation or computed as
        the mean period between samples.

        Returns:
            float: samplerate in Hz
        '''
        return self._fs

    def metadata(self) -> Mapping[str,str]:
        '''Get any metadata from the recording.

        Recording metadata is optional and may not be supported by all
        file types. If metadata isn't supported or wasn't recorded then
        an empty dict is returned.

        Returns:
            Mapping[str,str]: metadata dictionary
        '''
        return self._metadata.copy()

    def __getitem__(self, index: str) -> Sequence[float]:
        '''Get the data samples for a stream.

        Args:
            index: stream/channel/column name

        Returns:
            Sequence[float]: data samples
        '''
        if index == 'time':
            return self._time
        else:
            return self._data[self.ch_names.index(index)]

    def __iter__(self) -> Iterator[str]:
        '''Get an iterator for data streams.

        Returns:
            Iterator[str]: iterator of non-time stream names
        '''
        return iter(self.ch_names)

    def stream_matches_critera(self, stream_list: Sequence[str], stream: str) -> bool:
        '''Check if a stream name matches a list of criteria.

        Args:
            stream_list: list of stream names or substrings to match in stream names
            stream: stream name to check for matches in stream_list criteria

        Returns:
            bool: True if stream matches criteria in stream_list, False otherwise
        '''
        # check for exact matches
        if stream in stream_list:
            return True

        # check for substring matches
        for stream_filter in stream_list:
            if stream_filter in stream:
                return True

        return False

    def match_streams(self, criteria: Sequence[str]) -> Sequence[str]:
        '''Return a list of streams matching specified criteria.

        Criteria list may include exact stream names and stream name substrings.
        Exact matches take priority and when found are removed from substring
        searches on remaining streams. An empty list of criteria will return
        all stream names.

        Args:
            criteria: list of stream names or substrings to find

        Returns:
            Sequence[str]: list of stream names found to match criteria
        '''
        if len(criteria) == 0:
            return self.ch_names
        else:
            ret_ch = []
            search_channels = []
            # add exact matches and remove them from the running for partial matches
            for ch in criteria:
                if ch in self.ch_names:
                    ret_ch.append(ch)
                else:
                    search_channels.append(ch)

            # check remaining args for partial matches
            for ch in self.ch_names:
                if self.stream_matches_critera(search_channels, ch):
                    ret_ch.append(ch)

            return ret_ch
