from collections.abc import Mapping, Sequence
import csv
import datetime as dt
import numpy as np

from .base import FliRecorder, FliRecording


class CsvRecorder(FliRecorder):
    '''Iteratively record a set of sampled signals in a CSV formatted file.

    The output file is opened on instantiation and the fields (columns) to
    save in the file are automatically determined on the first call to
    write_data. When recording is complete call close.

    Metadata is not currently supported with CSV files.

    Args:
        filename: name of CSV file
    '''

    def __init__(self, filename: str, fs: float = 0, metadata: Mapping[str,str] = {}) -> None:
        self._filename = filename
        self._fs = fs # not used in CSV
        self._metadata = metadata # not used in CSV
        self._fp = open(filename, 'w', newline='')
        self._writer = csv.writer(self._fp, delimiter=',')
        self._header = None

    def close(self) -> None:
        self._fp.close()
        self._writer = None

    def write_data(self, data: Mapping[str|int, Sequence[int|float]]) -> int:
        '''Write a block of samples to the file.

        The data is provided in a dictionary of sample arrays, each having
        the same length (number of samples). The keys represent signal names
        which correspond to fields/columns in the CSV file. The CSV header is
        written on the first call to write_data which determines the set of
        fields and order of fields for the file. Each subsequent call to
        write_data must have the same fields and appends the samples to the
        CSV file.

        Args:
            data: block of samples to write

        Returns:
            int: number of samples written
        '''
        if self._writer is None:
            raise Exception(f'CSV file closed')
        if self._header is None:
            self._header = list(data.keys())
            self._writer.writerow(self._header)

        n_rows = len(data[self._header[0]])
        for i in range(n_rows):
            row = []
            for k in self._header:
                val = data[k][i]
                if val.is_integer():
                    val = int(val)
                row.append(val)
            self._writer.writerow(row)

        return n_rows


class CsvRecording(FliRecording):
    '''Load a set of sampled signals from a CSV formatted file.

    The CSV file is expected to represent a set of sampled signals or
    time series with uniform sampling rate. Several ways of of storing
    timestamps are supported to accommodate various formats used by
    FieldLine software as well as files from other sources. In all
    supported cases the time field(s) are converted to a floating point
    value in seconds and available through the 'time' key. If the file
    contains a 'time' column then it is interpreted as a float and used
    unaltered. Columns which are recognized as representing magnetic
    field values are automatically converted to units of Tesla as the
    file is read.

    By default the samplerate of the file is computed as the mean time
    between samples using available timestamps. For short recordings
    with rx_t columns this may be inaccurate due to sample buffering
    during the recording. This can be solved by providing the
    samplerate if is known or ignoring the time stream and computing
    your own separately.

    Data is retrievable by stream/channel/column name by indexing an
    object of this type. The object also supports iteration and will
    iterate through all streams except time. This makes for convenient
    signal processing or plotting, for example::

        csv_recording = CsvRecording('some_file.csv')
        t = csv_recording['time']
        for stream in csv_recording:
            do_something(t, csv_recording[stream])

    Args:
        filename: name of CSV file
        time_zero: subtract the first timestamp from all times if True
        fs: samplerate in Hz, 0 to estimate from timestamps
        limit: max number of samples to read from file, 0 for all
        convert_field: convert magnetic field channels to units of T if True
    '''
    def __init__(self,
                 filename: str,
                 time_zero: bool = False,
                 fs: float = 0.0,
                 limit: int = 0,
                 convert_field: bool = True) -> None:
        self._filename = filename
        self._fs = fs
        self._data = []
        self._time = []
        self.ch_names = []
        self._metadata = {}
        system_date_time = False
        date_col_i = 0
        time_col_i = 1
        time_from_n = False
        n_samples = 0
        with open(self._filename, newline='') as csvfile:
            reader = csv.reader((line.replace('\0','') for line in csvfile))
            header = next(reader)

            if 'System_Date' in header and 'System_Time' in header:
                system_date_time = True
                date_col_i = header.index('System_Date')
                time_col_i = header.index('System_Time')

            for col in header:
                if col.lower() != 'time' and col != 'System_Date' and col != 'System_Time':
                    self.ch_names.append(col)
                    self._data.append([])
                if 'rx_t' in col:
                    time_from_n = True

            for row in reader:
                for i,col in enumerate(header):
                    if col.lower() == 'time':
                        self._time.append(float(row[i]))
                    elif col == 'n':
                        val = int(row[i])
                        self._time.append(val)
                        self._data[self.ch_names.index(col)].append(val)
                    elif col not in ['System_Date', 'System_Time']:
                        if col.endswith('-18') or 'dds_output_freq' in col or 'rf_freq' in col or 'larmor_freq' in col:
                            val = float(row[i])
                            if convert_field:
                                val *= 4e-3 / (2**32-1) / 6.99583
                            self._data[self.ch_names.index(col)].append(val)
                        elif col.endswith('-23') or 'mag_mz' in col or 'mag' in col:
                            val = float(row[i])
                            if convert_field:
                                val *= 1e-13
                            self._data[self.ch_names.index(col)].append(val)
                        else:
                            self._data[self.ch_names.index(col)].append(float(row[i]))
                if system_date_time:
                    ts = dt.datetime.strptime(f'{row[date_col_i]} {row[time_col_i]}', '%Y-%m-%d %H:%M:%S.%f')
                    self._time.append(ts.timestamp())
                n_samples += 1
                if limit > 0 and n_samples > limit:
                    break
        if time_from_n:
            if self._fs == 0:
                rx_t_ch = None
                for ch in self.ch_names:
                    if 'rx_t' in ch:
                        rx_t_ch = ch
                        break
                if rx_t_ch is not None:
                    ts = np.mean(np.diff(self._data[self.ch_names.index(rx_t_ch)]))
                    if ts > 0:
                        self._fs = 1/ts
            if self._fs != 0:
                self._time = [ n/self._fs for n in self._time ]

        if self._fs == 0:
            self._fs = float(1/np.mean(np.diff(self._time)))

        if time_zero:
            self._time = [ t - self._time[0] for t in self._time ]
