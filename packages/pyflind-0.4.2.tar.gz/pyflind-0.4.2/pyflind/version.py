from pathlib import Path
import subprocess


def _get_git_version() -> str|None:
    try:
        root = Path(__file__).resolve().parent.parent
        return subprocess.check_output(
            ['git', 'describe', '--always', '--long', '--dirty'],
            cwd=root,
            stderr=subprocess.DEVNULL,
        ).decode().strip().replace('-', '.', count=1).replace('-', '+', count=1).replace('-','.')
    except Exception:
        return None


def get_version() -> str:
    # try git first for dev environment
    v = _get_git_version()
    if v:
        return v

    # fallback to baked-in version
    try:
        from ._version import VERSION
        return VERSION
    except Exception:
        return 'unknown'


def get_version_and_write() -> str:
    # use this during packaging to generate the baked-in version
    version = get_version()
    out = Path(__file__).parent/ '_version.py'
    out.write_text(f'VERSION = "{version}"\n')
    return version
