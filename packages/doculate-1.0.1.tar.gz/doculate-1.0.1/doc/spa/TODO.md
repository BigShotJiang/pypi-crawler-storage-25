# TODO

A continuación se presenta una lista de cosas por hacer en futuras versiones, ordenadas por prioridad:

- [ ] Glosario de términos reservados.
- [ ] Listas (índices) de acciones específicas, errores y buenas prácticas que incluyan la sección que las contiene.
- [ ] Referencias cruzadas a secciones, términos reservados, acciones específicas, entornos, etc.
- [ ] Argumentos de entornos para modificar cosas como el lenguaje de programación utilizado, estilo, etc.
- [ ] Panel opcional en entornos de código para mostrar su salida.
- [ ] Entorno de lista de *checkboxes*.
- [ ] Soporte para delimitadores y emojis en título.
- [ ] Soporte para emojis.
- [ ] Estilos de entornos de código predefinidos (además del actual con barras de título con diferente color).
- [ ] Ajuste de ciertos espaciados verticales entre elementos.
- [ ] Delimitadores especiales o implementación de argumentos opcionales para establecer el lenguaje de código entre línea.
- [ ] Capacidad para establecer o desactivar el lenguaje utilizado en código entre línea mediante banderas.
- [ ] No se están traduciendo los caracteres `─`, `│`, `└`, `├`.
- [ ] Permitir al usuario agregar entornos de código y agregar más configuraciones para modificar su estilo.
- [ ] Implementar corrección para códigos entre línea largos para que no se salgan del margen del documento.
- [ ] Estilo por defecto de código para elementos de descripciones de entornos como *Opciones*, *Argumentos*, etc., el cual se podrá cambiar mediante los argumentos de entornos cuando se implementen.
- [ ] Símbolo especial para términos que requieran un formato especial.
- [ ] Delimitadores análogos a `f"..."`, `k"..."`, etc., para dar formato a mensajes de errores, warnings e info, que, por ejemplo, coloreen todo el texto de rojo, amarillo y azul.
- [ ] Implementar formato de elementos de descripciones de línea aparte apilados.
- [ ] Entorno o patrón para insertar imágenes.
- [ ] Entorno multicolumna.
- [ ] Implementar delimitadores invisibles para colorear contenido de entornos como `equation`, `tikzpicture`, etc., en el resaltado de sintaxis de $\LaTeX$.
- [ ] Hacer que el indentado del contenido de un elemento de lista en el `TXT`, después de la primera línea, sea opcional.
- [ ] Soporte para colocar tablas largas en varias páginas, sin que se salgan del margen, así como un ancho máximo para las que se salen horizontalmente.
- [ ] Argumentos especiales para entornos de tabla (cuando se implementen argumentos de entornos) para establecer su formato, así como entornos predefinidos con los estilos o formatos más utilizados.
- [ ] Mostrar información complementaria del lado derecho de la barra de título de entornos de código, como el lenguaje utilizado.
- [ ] Botón de copiar código del lado derecho de la barra de título o esquina del cuadro de código y su configuración correspondiente para mostrarlo o no.
- [ ] Subcomando CLI `get-example` para obtener un `TXT` ejemplo para poder hacer pruebas rápidas o probar el paquete por primera vez.
- [ ] Formato y parser de referencias formales a $\text{Bib}\TeX$.
