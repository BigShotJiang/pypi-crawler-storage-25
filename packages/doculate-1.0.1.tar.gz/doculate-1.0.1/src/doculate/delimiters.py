from dataclasses import dataclass, fields
import re

from .config_defaults import _ConfigDefaults
from .utils import is_list_of_str


class Delimiters(list):
	def __init__(self, 
		open: str = _ConfigDefaults.default_inline_normal_delimiter,
		close: str = _ConfigDefaults.default_inline_normal_delimiter
	): 
		super().__init__([open, close])
		self.open = open
		self.close = close


class _InlineDelimiters:
	"""
	Class for defining inline text delimiters.
	Delimiters, both normal and no-nesting delimiters, that do not accept nesting of other delimiters in their content, can be given explicitly in the constructor or, if these are not specified, they can be automatically constructed, through a discriminating element given in the constructor.
	The corresponding LaTeX delimiters also can be specified.
	"""

	def __init__(self, 
		id: str, 
		normal: Delimiters | list[str] | list[Delimiters | list[str]] = None, 
		no_nesting: Delimiters | list[str] | list[Delimiters | list[str]] = None, 
		only_no_nesting: bool = False, 
		signature_constructor: str | list[str] = None, 
		common_normal_delimiter: str = _ConfigDefaults.default_inline_normal_delimiter, 
		common_no_nesting_delimiter: str = _ConfigDefaults.default_inline_no_nesting_delimiter, 
		common_unambiguous_normal_delimiters: list[str] = _ConfigDefaults.default_unambiguous_normal_delimiters, 
		LaTeX: Delimiters = Delimiters("\\textnormal{", "}"), 
		# TODO: implement normal LaTeX delimiters as default delimiters (maybe None).
		LaTeX_protect: Delimiters | list[Delimiters] = Delimiters("\\textnormal{", "}"), 
		LaTeX_intitle: Delimiters | list[Delimiters] = Delimiters("\\textnormal{", "}")
	):
		self.id = id
		self.normal = normal
		self.no_nesting = no_nesting
		self.only_no_nesting = only_no_nesting
		self._signature_constructor = signature_constructor
		self.common_normal_delimiter = common_normal_delimiter
		self.common_no_nesting_delimiter = common_no_nesting_delimiter
		self.common_unambiguous_normal_delimiters = common_unambiguous_normal_delimiters

		if self.normal or self.no_nesting: 
			self._signature_constructor = None

			if self.normal and not self.defined_through_Delimiters(self.normal):
				self.normal = self.construct_Delimiters(self.normal)
			if self.no_nesting and not self.defined_through_Delimiters(self.no_nesting):
				self.no_nesting = self.construct_Delimiters(self.no_nesting)
		
		elif self._signature_constructor: 
			self.signature_init()
		else:
			raise ValueError("Explicit delimiters or `signature_constructor` is required.")

		self.LaTeX: Delimiters = LaTeX
		self.LaTeX_protect: Delimiters | list[Delimiters] = LaTeX_protect
		self.LaTeX_intitle: Delimiters | list[Delimiters] = LaTeX_intitle

		# Workaround for only no nestig delimiter generation from `signature_constructor`.
		if self.only_no_nesting: self.normal = None
	
	@property
	def signature_constructor(self):
		return self._signature_constructor

	@signature_constructor.setter
	def signature_constructor(self, value):
		self._signature_constructor = value
		self.signature_init()

	def signature_init(self):
		if isinstance(self.signature_constructor, str): 
			self.normal, self.no_nesting = self.construct_signature_Delimiters(
				self.signature_constructor, 
				self.common_normal_delimiter, 
				self.common_no_nesting_delimiter, 
				self.common_unambiguous_normal_delimiters
			)
		else:
			self.normal = []
			self.no_nesting = []
			for sig in self.signature_constructor: 
				norm, no_nest = self.construct_signature_Delimiters(
					sig, 
					self.common_normal_delimiter, 
					self.common_no_nesting_delimiter, 
					self.common_unambiguous_normal_delimiters
				)
				if norm: self.normal.extend(norm)
				self.no_nesting.append(no_nest)
		
		if not self.normal or self.only_no_nesting: self.normal = None

	@staticmethod
	def is_list_of_Delimiters(obj):
		return isinstance(obj, list) and all([isinstance(elem, Delimiters) for elem in obj])

	@staticmethod
	def defined_through_Delimiters(obj):
		return isinstance(obj, Delimiters) or _InlineDelimiters.is_list_of_Delimiters(obj)

	@staticmethod
	def construct_Delimiters(delimiters): 
		if is_list_of_str(delimiters):
			new_delimiters = Delimiters(delimiters[0], delimiters[1])
		else:
			new_delimiters = [Delimiters(delims[0], delims[1]) for delims in delimiters]
		return new_delimiters

	@staticmethod
	def construct_signature_Delimiters(
		signature: str, 
		common_normal_delimiter: str, 
		common_no_nesting_delimiter: str, 
		common_unambiguous_normal_delimiters: list[str]
	) -> tuple[Delimiters]: 

		open_normal = signature + common_normal_delimiter
		close_normal = common_normal_delimiter

		open_unambiguous_normal = signature + common_unambiguous_normal_delimiters[0]
		close_unambiguous_normal = common_unambiguous_normal_delimiters[1]

		open_no_nesting = signature + common_no_nesting_delimiter
		close_no_nesting = common_no_nesting_delimiter

		normal = [Delimiters(open_normal, close_normal), Delimiters(open_unambiguous_normal, close_unambiguous_normal)]
		no_nesting = Delimiters(open_no_nesting, close_no_nesting)

		return normal, no_nesting

# TODO: define repetitive functions structure in another util function.
class _InlineDelimitersUtils:
	@staticmethod
	def get_delims_list(delimiters_instance) -> list[str]: 
		delims_list = []
		if not delimiters_instance: return delims_list

		if isinstance(delimiters_instance[0], list):
			delims_list.extend(delimiters_instance)
		else:
			delims_list.append(delimiters_instance)

		return delims_list
	
	@staticmethod
	def get_open_delims_list(delimiters_instance) -> list[str]: 
		delims = set()
		if not delimiters_instance: return delims

		if isinstance(delimiters_instance[0], list):
			delims.update([rf"{delims.open}" for delims in delimiters_instance])
		else:
			delims.add(rf"{delimiters_instance.open}")

		return list(delims)

	@staticmethod
	def get_close_delims_list(delimiters_instance) -> list[str]: 
		delims = set()
		if not delimiters_instance: return delims

		if isinstance(delimiters_instance[0], list):
			delims.update([delims.close for delims in delimiters_instance])
		else:
			delims.add(delimiters_instance.close)

		return list(delims)

	@staticmethod
	def get_open_to_close_delims_dict(delimiters_instance) -> dict[str, str]: 
		delims_dict = {}
		if not delimiters_instance: return delims_dict

		if isinstance(delimiters_instance[0], list): 
			for delims in delimiters_instance:
				delims_dict[delims.open] = delims.close
		else:
			delims_dict[delimiters_instance.open] = delimiters_instance.close

		return delims_dict

	@staticmethod
	def make_delimiters_string(delimiters_list):
		delims_list = []
		for delim in delimiters_list: delims_list.append(re.escape(delim))
		delims_string = '|'.join(delims_list)
		return fr"(?<!\\)(?:{delims_string})"
	
	@staticmethod
	def make_replacements_string(replacements_list):
		repls_list = []
		for repl in replacements_list: repls_list.append(re.escape(repl))
		repls_string = '|'.join(repls_list)
		return fr"{repls_string}"

	def _get_delimiters_ids(self): 
		ids = []
		for delim in fields(self): 
			delim_ins = getattr(self, delim.name)
			ids.append(delim_ins.id)
		return ids

	def _get_delimiters_pairs(self, only_no_nesting: bool = False, only_normal: bool = False) -> list[list[str]]:
		all_delimiters = []

		for inline_delims in fields(self): 
			inline_delimiters_instance = getattr(self, inline_delims.name)

			if not only_no_nesting:
				normal_delims = inline_delimiters_instance.normal
				all_delimiters.extend(self.get_delims_list(normal_delims))

			if not only_normal:
				no_nesting_delims = inline_delimiters_instance.no_nesting
				all_delimiters.extend(self.get_delims_list(no_nesting_delims))

		return all_delimiters

	def _get_open_delimiters(self, only_no_nesting: bool = False, only_normal: bool = False):
		open_delimiters = set()

		for inline_delims in fields(self): 
			inline_delimiters_instance = getattr(self, inline_delims.name)

			if not only_no_nesting:
				normal_delims = inline_delimiters_instance.normal
				open_delimiters.update(self.get_open_delims_list(normal_delims))

			if not only_normal:
				no_nesting_delims = inline_delimiters_instance.no_nesting
				open_delimiters.update(self.get_open_delims_list(no_nesting_delims))

		return sorted(list(open_delimiters))

	def _get_close_delimiters(self, only_no_nesting: bool = False, only_normal: bool = False):
		close_delimiters = set()

		for inline_delims in fields(self): 
			inline_delimiters_instance = getattr(self, inline_delims.name)

			if not only_no_nesting:
				normal_delims = inline_delimiters_instance.normal
				close_delimiters.update(self.get_close_delims_list(normal_delims))

			if not only_normal:
				no_nesting_delims = inline_delimiters_instance.no_nesting
				close_delimiters.update(self.get_close_delims_list(no_nesting_delims))

		return sorted(list(close_delimiters))

	def _get_all_open_delim_to_close_delim(self, 
		only_no_nesting: bool = False, 
		only_normal: bool = False
	) -> dict[str, str]: 

		open_to_close = {}

		if only_no_nesting and only_normal: 
			raise ValueError("Arguments `only_no_nesting` and `only_normal` cannot be both True.")

		for inline_delims in fields(self): 
			inline_delimiters_instance = getattr(self, inline_delims.name)

			if not only_no_nesting:
				normal_delims = inline_delimiters_instance.normal
				open_to_close.update(self.get_open_to_close_delims_dict(normal_delims))
			if not only_normal:
				no_nesting_delims = inline_delimiters_instance.no_nesting
				open_to_close.update(self.get_open_to_close_delims_dict(no_nesting_delims))

		return open_to_close

	def _get_all_open_delim_to_LaTeX_delims(self):
		open_to_latex = {}

		for inline_delims in fields(self): 
			open_delimiters = set()
			inline_delimiters_instance = getattr(self, inline_delims.name)

			normal_delims = inline_delimiters_instance.normal
			no_nesting_delims = inline_delimiters_instance.no_nesting

			open_delimiters.update(self.get_open_delims_list(normal_delims))
			open_delimiters.update(self.get_open_delims_list(no_nesting_delims))

			for open_delim in open_delimiters:
				open_to_latex[open_delim] = inline_delimiters_instance.LaTeX

		return open_to_latex
	
	def _get_all_open_delim_to_LaTeX_protected_delims(self):
		open_to_latex_protected = {}

		for inline_delims in fields(self): 
			open_delimiters = set()
			inline_delimiters_instance = getattr(self, inline_delims.name)

			normal_delims = inline_delimiters_instance.normal
			no_nesting_delims = inline_delimiters_instance.no_nesting

			open_delimiters.update(self.get_open_delims_list(normal_delims))
			open_delimiters.update(self.get_open_delims_list(no_nesting_delims))

			for open_delim in open_delimiters:
				open_to_latex_protected[open_delim] = inline_delimiters_instance.LaTeX_protect

		return open_to_latex_protected

	def _get_all_open_delim_to_LaTeX_intitle_delims(self):
		open_to_latex_intitle = {}

		for inline_delims in fields(self): 
			open_delimiters = set()
			inline_delimiters_instance = getattr(self, inline_delims.name)

			normal_delims = inline_delimiters_instance.normal
			no_nesting_delims = inline_delimiters_instance.no_nesting

			open_delimiters.update(self.get_open_delims_list(normal_delims))
			open_delimiters.update(self.get_open_delims_list(no_nesting_delims))

			for open_delim in open_delimiters:
				open_to_latex_intitle[open_delim] = inline_delimiters_instance.LaTeX_intitle

		return open_to_latex_intitle

	def _get_all_open_delim_to_id(self):
		open_to_id = {}

		for inline_delims in fields(self): 
			open_delimiters = set()
			inline_delimiters_instance = getattr(self, inline_delims.name)

			normal_delims = inline_delimiters_instance.normal
			no_nesting_delims = inline_delimiters_instance.no_nesting
			
			open_delimiters.update(self.get_open_delims_list(normal_delims))
			open_delimiters.update(self.get_open_delims_list(no_nesting_delims))

			for open_delim in open_delimiters:
				open_to_id[open_delim] = inline_delimiters_instance.id

		return open_to_id

	def _id_to_LaTeX_delimiters(self):
		id_to_latex = {}

		for inline_delims in fields(self): 
			inline_delimiters_instance = getattr(self, inline_delims.name)
			id_to_latex[inline_delimiters_instance.id] = inline_delimiters_instance.LaTeX

		return id_to_latex

	def _get_all_single_delimiter_list(self, only_no_nesting: bool = False, only_normal: bool = False):
		all_single_delims = set()
		all_delims_pairs = self._get_delimiters_pairs(only_no_nesting = only_no_nesting, only_normal = only_normal)

		for j in all_delims_pairs: all_single_delims |= {j[0], j[1]}

		return sorted(list(all_single_delims), key = lambda x: -len(x))

	def _get_delimiters_string(self):
		return '|'.join(self._get_all_single_delimiter_list())

	def _get_delimiters_string_with_groups(self):
		return '|'.join(f"({d})" for d in self._get_all_single_delimiter_list())
	
	def validate_delimiters(self) -> None:
		"""
		Delimiters validation of conditions to reduce potential ambiguities.
		If a validation is not met, a `ValueError` will be raised.
		"""
		...
	
	# TODO: make real method using self and not an argument.
	def get_no_nesting_open_delims_class(self, delimiters): 
		delims = []
		for delims_field in vars(delimiters): 
			delims_ins = getattr(delimiters, delims_field)
			if isinstance(delims_ins.no_nesting, Delimiters):
				delims.append(delims_ins.no_nesting.open)
			else:
				delims.extend([delims.open for delims in delims_ins.no_nesting])
		return delims

	@staticmethod
	def is_list_of_Delimiters(obj):
		return isinstance(obj, list) and all([isinstance(elem, Delimiters) for elem in obj])

# TODO: it seems expresing delimiters values as raw strings is more efficient than using normal strings, verify if this is true and decide which approach to use.
# TODO: restrict only-no-nesting delimiters to not having normal delimiters.
# TODO: make default delimiters values use default normal and no nesting delimiters settings instead literal strings.
@dataclass
class _DefaultTextStyleInlineDelimiters(_InlineDelimitersUtils):
	# Default `italics` also defined in `InlineDelimiters` constructor until class improvement.
	italics: _InlineDelimiters = _InlineDelimiters(
		id = "italics", 
		normal = [
			Delimiters("i'", "'"), 
			Delimiters("i\"", "\""), 
			Delimiters(
				f"i{_ConfigDefaults.default_unambiguous_normal_delimiters[0]}", 
				f"{_ConfigDefaults.default_unambiguous_normal_delimiters[1]}"
			)
		], 
		no_nesting = Delimiters("\"", "\""), 
		LaTeX = Delimiters("\\textit{", "}")
	)
	normal_text: _InlineDelimiters = _InlineDelimiters(
		id = "normal_text", 
		signature_constructor = 't', 
		LaTeX = Delimiters("\\textnormal{", "}")
	)
	bold: _InlineDelimiters = _InlineDelimiters(
		id = "bold",
		signature_constructor = 'b',
		LaTeX = Delimiters("\\textbf{", "}")
	)
	math: _InlineDelimiters = _InlineDelimiters(
		id = "math",
		no_nesting = Delimiters("$", "$"), 
		LaTeX = Delimiters("$", "$")
	)
	slanted: _InlineDelimiters = _InlineDelimiters(
		id = "slanted",
		signature_constructor = 's',
		LaTeX = Delimiters("\\textsl{", "}")
	)
	small_caps: _InlineDelimiters = _InlineDelimiters(
		id = "small_caps",
		signature_constructor = 'sc',
		LaTeX = Delimiters("\\textsc{", "}")
	)
	quotes: _InlineDelimiters = _InlineDelimiters(
		id = "quotes",
		signature_constructor = 'q',
		LaTeX = Delimiters("\\enquote{", "}")
	)
	underline: _InlineDelimiters = _InlineDelimiters(
		id = "underline",
		signature_constructor = 'u',
		LaTeX = Delimiters("\\underline{", "}")
	)

@dataclass
class _DefaultCodeInlineDelimiters(_InlineDelimitersUtils):
	code: _InlineDelimiters = _InlineDelimiters(
		id = "code", 
		only_no_nesting = True, 
		no_nesting = Delimiters("`", "`"), 
		LaTeX = Delimiters("\\lstinline`", "`"), 
		LaTeX_intitle = Delimiters("\\lstintitle`", "`"), 
		LaTeX_protect = Delimiters("\\protect\\lstintitle!", "!")
	)
	referenced_code: _InlineDelimiters = _InlineDelimiters(
		id = "referenced_code", 
		only_no_nesting = True, 
		no_nesting = Delimiters("r`", "`"), 
		LaTeX = Delimiters("\\lstinline`", "`"), 
		LaTeX_intitle = Delimiters("\\lstintitle`", "`"), 
		LaTeX_protect = Delimiters("\\protect\\lstintitle!", "!")
	)
	special_code: _InlineDelimiters = _InlineDelimiters(
		id = "special_code", 
		only_no_nesting = True, 
		signature_constructor = 'e', 
		LaTeX = Delimiters("\\lstinline\"", "\""), 
		LaTeX_intitle = Delimiters("\\lstintitle\"", "\""), 
		LaTeX_protect = Delimiters("\\protect\\lstintitle!", "!")
	)
	referenced_special_code: _InlineDelimiters = _InlineDelimiters(
		id = "referenced_special_code", 
		only_no_nesting = True, 
		signature_constructor = "re", 
		LaTeX = Delimiters("\\lstinline\"", "\""), 
		LaTeX_intitle = Delimiters("\\lstintitle\"", "\""), 
		LaTeX_protect = Delimiters("\\protect\\lstintitle!", "!")
	)

@dataclass
class _DefaultCommentInlineDelimiters(_InlineDelimitersUtils):
	# Default `comment` also defined in `InlineDelimiters` constructor until class improvement.
	comment: _InlineDelimiters = _InlineDelimiters(
		id = "comment", 
		only_no_nesting = True, 
		no_nesting = [
			Delimiters(
				_ConfigDefaults.block_comment_delimiters[0], 
				_ConfigDefaults.block_comment_delimiters[1]
			), 
			Delimiters("cc\"", "\"")
		], 
		LaTeX = Delimiters(
				_ConfigDefaults.LaTeX_block_comment_delimiters[0], 
				_ConfigDefaults.LaTeX_block_comment_delimiters[1]
			)
	)

@dataclass
class _DefaultOtherInlineDelimiters(_InlineDelimitersUtils):
	file: _InlineDelimiters = _InlineDelimiters(
		id = "file", 
		only_no_nesting = True, 
		signature_constructor = 'f', 
		LaTeX = Delimiters("\\file\"", "\""), 
		LaTeX_intitle = Delimiters("\\fileintitle!", "!"), 
		LaTeX_protect = Delimiters("\\protect\\fileintitle!", "!")		# TODO: change confusing command `\Verb`.
	)
	directory: _InlineDelimiters = _InlineDelimiters(
		id = "directory", 
		only_no_nesting = True, 
		signature_constructor = 'd', 
		LaTeX = Delimiters("\\dir\"", "\""), 
		LaTeX_intitle = Delimiters("\\dirintitle!", "!"), 
		LaTeX_protect = Delimiters("\\protect\\dirintitle!", "!")
	)
	label: _InlineDelimiters = _InlineDelimiters(
		id = "label", 
		only_no_nesting = True, 
		signature_constructor = 'l', 
		LaTeX = Delimiters("\\label{", "}")
	)
	reference: _InlineDelimiters = _InlineDelimiters(
		id = "reference", 
		signature_constructor = 'r', 
		LaTeX = Delimiters("\\textsl{", "}")
	)
	cite: _InlineDelimiters = _InlineDelimiters(
		id = "cite", 
		only_no_nesting = True, 
		signature_constructor = 'c', 
		LaTeX = Delimiters("\\cite{", "}")
	)
	footnote: _InlineDelimiters = _InlineDelimiters(
		id = "footnote", 
		signature_constructor = "fn", 
		LaTeX = Delimiters("\\footnote{", "}")
	)
	hyperlink: _InlineDelimiters = _InlineDelimiters(
		id = "hyperlink", 
		only_no_nesting = True, 
		signature_constructor = 'h', 
		LaTeX = Delimiters("\\url{", "}")
	)
	keyboard: _InlineDelimiters = _InlineDelimiters(
		id = "keyboard", 
		only_no_nesting = True, 
		signature_constructor = 'k', 
		LaTeX = Delimiters("\\key|", "|"), 
		LaTeX_intitle = Delimiters("\\keyintitle!", "!"), 
		LaTeX_protect = Delimiters("\\protect\\keyintitle!", "!")
	)
	button: _InlineDelimiters = _InlineDelimiters(
		id = "button", 
		only_no_nesting = True, 
		signature_constructor = "bu", 
		LaTeX = Delimiters("\\textsl{", "}")
	)
	# Default `LaTeX` also defined in `InlineDelimiters` constructor until class improvement.
	LaTeX: _InlineDelimiters = _InlineDelimiters(
		id = "LaTeX", 
		only_no_nesting = True, 
		no_nesting = [
			Delimiters("L\"", "\""), 
			Delimiters("LaT\"", "\""), 
			Delimiters("LaTeX\"", "\"")
		], 
		LaTeX = Delimiters("", "")
	)

@dataclass
class _DefaultInlineDelimiters(
	_DefaultCodeInlineDelimiters, 
	_DefaultTextStyleInlineDelimiters, 
	_DefaultOtherInlineDelimiters, 
	_DefaultCommentInlineDelimiters
):
	pass

@dataclass
class InlineDelimiters(_DefaultInlineDelimiters):
	def __init__(self, 
		common_normal_delimiter = _ConfigDefaults.default_inline_normal_delimiter, 
		common_no_nesting_delimiter = _ConfigDefaults.default_inline_no_nesting_delimiter, 
		common_unambiguous_normal_delimiters = _ConfigDefaults.default_unambiguous_normal_delimiters, 
		block_comment_delimiters = _ConfigDefaults.block_comment_delimiters
	):
		self.common_normal_delimiter = common_normal_delimiter
		self.common_no_nesting_delimiter = common_no_nesting_delimiter
		self.common_unambiguous_normal_delimiters = common_unambiguous_normal_delimiters
		self.block_comment_delimiters = block_comment_delimiters

		super().__init__()

		# All below is a temporal workaround to update all delimiters classes to use possibly changed config parameters in constructor.
		# Needs to improve to do it automatically.
		self.code_delimiters = _DefaultCodeInlineDelimiters()
		for field in fields(self.code_delimiters): 
			delim_inst = getattr(self, field.name)
			self.update_delimiter(delim_inst)
			setattr(self.code_delimiters, field.name, delim_inst)
		self.text_delimiters = _DefaultTextStyleInlineDelimiters()
		for field in fields(self.text_delimiters):
			delim_inst = getattr(self, field.name)
			self.update_delimiter(delim_inst)
			setattr(self.text_delimiters, field.name, delim_inst)
		self.comment_delimiters = _DefaultCommentInlineDelimiters()
		for field in fields(self.comment_delimiters):
			delim_inst = getattr(self, field.name)
			self.update_delimiter(delim_inst)
			setattr(self.comment_delimiters, field.name, delim_inst)
		self.other_delimiters = _DefaultOtherInlineDelimiters()
		for field in fields(self.other_delimiters):
			delim_inst = getattr(self, field.name)
			self.update_delimiter(delim_inst)
			setattr(self.other_delimiters, field.name, delim_inst)

		self.italics.normal = [
			Delimiters(f"i{self.common_normal_delimiter}", f"{self.common_normal_delimiter}"), 
			Delimiters("i\"", "\""), 
			Delimiters(
				f"i{self.common_unambiguous_normal_delimiters[0]}", 
				f"{self.common_unambiguous_normal_delimiters[1]}"
			)
		]
		self.italics.no_nesting = Delimiters(f"{self.common_no_nesting_delimiter}", f"{self.common_no_nesting_delimiter}")

		self.comment.no_nesting = [
			Delimiters(
				self.block_comment_delimiters[0], 
				self.block_comment_delimiters[1]
			), 
			Delimiters(f"cc{self.common_no_nesting_delimiter}", f"{self.common_no_nesting_delimiter}")
		]

		self.LaTeX.no_nesting = [
			Delimiters(f"L{self.common_no_nesting_delimiter}", f"{self.common_no_nesting_delimiter}"), 
			Delimiters(f"LaT{self.common_no_nesting_delimiter}", f"{self.common_no_nesting_delimiter}"), 
			Delimiters(f"LaTeX{self.common_no_nesting_delimiter}", f"{self.common_no_nesting_delimiter}")
		]

		self.open_delimiters = self._get_open_delimiters()
		self.close_delimiters = self._get_close_delimiters()
	
	def update_delimiter(self, delim_inst):
		inline_delims_constructor_params = vars(delim_inst).copy()

		sig = inline_delims_constructor_params["_signature_constructor"]

		# Detect if normal and no_nesting delims were generated from signature_constructor. If so, delete it and reconstruct from new default normal, no_nesting and unambiguous delimiters. If normal or no_nesting were given in default constructor leave them as they are.
		norm = inline_delims_constructor_params["normal"]
		if sig and self.is_list_of_Delimiters(norm) and len(norm) == 2 \
		and norm[0].open == sig + inline_delims_constructor_params["common_normal_delimiter"] \
		and norm[1].open == sig + inline_delims_constructor_params["common_unambiguous_normal_delimiters"][0]:
			inline_delims_constructor_params["normal"] = None
		
		no_nest = inline_delims_constructor_params["no_nesting"]
		if sig and isinstance(no_nest, Delimiters) and no_nest.open == sig + inline_delims_constructor_params["common_no_nesting_delimiter"]:
			inline_delims_constructor_params["no_nesting"] = None

		inline_delims_constructor_params["common_normal_delimiter"] = self.common_normal_delimiter
		inline_delims_constructor_params["common_no_nesting_delimiter"] = self.common_no_nesting_delimiter
		inline_delims_constructor_params["common_unambiguous_normal_delimiters"] = self.common_unambiguous_normal_delimiters
		inline_delims_constructor_params["signature_constructor"] = inline_delims_constructor_params["_signature_constructor"]
		del inline_delims_constructor_params["_signature_constructor"]
		
		delim_inst.__init__(**inline_delims_constructor_params)