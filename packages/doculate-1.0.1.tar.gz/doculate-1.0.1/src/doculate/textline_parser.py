import re

from .config import config


# TODO: turn this class into a more generic text parser class, since it is used to parse any text content, not only full text lines.
class TextLineParser:

	def __init__(self, line_state = None):
	
		self.inline_delimiters = config.delimiters
		self.line_state = line_state

		self._delimiters_stack = []
		self._static_content_stack = []
		self._delimiters_spaced_stack = []

		self.LaTeX_special_replacements = config.LaTeX_special_replacements
		self.LaTeX_code_special_replacements = config.LaTeX_code_special_replacements
		self.LaTeX_url_special_replacements = config.LaTeX_url_special_replacements

		self.special_replacements_keys_string = config.special_replacements_keys_string
		self.code_special_replacements_keys_string = config.code_special_replacements_keys_string
		self.url_special_replacements_keys_string = config.url_special_replacements_keys_string
		
		self.open_delim_to_LaTeX_delims = self.inline_delimiters._get_all_open_delim_to_LaTeX_delims()
		self.open_delim_to_LaTeX_intitle_delims = self.inline_delimiters._get_all_open_delim_to_LaTeX_intitle_delims()
		self.open_delim_to_LaTeX_protected_delims = self.inline_delimiters._get_all_open_delim_to_LaTeX_protected_delims()

		self.hyperlink_open_delims = self.inline_delimiters.get_open_delims_list(self.inline_delimiters.hyperlink.no_nesting)
		# TODO: quit this when cross references are implemented.
		self.reference_open_delims = self.inline_delimiters.get_open_delims_list(self.inline_delimiters.reference.normal)
		self.footnote_open_delims = self.inline_delimiters.get_open_delims_list(self.inline_delimiters.footnote.normal)
		self.code_open_delims = config.code_open_delims

	def extract_delimiters_static_content(self, line, delimiters_stack = None):
		if delimiters_stack is None: 
			delimiters_stack = self.get_inline_delimiters_stack(line)

		open_no_nesting = self.inline_delimiters._get_open_delimiters(only_no_nesting = True)
		close_no_nesting = self.inline_delimiters._get_close_delimiters(only_no_nesting = True)
		open_normal = self.inline_delimiters._get_open_delimiters(only_normal = True)
		normal_delimiters = self.inline_delimiters._get_all_single_delimiter_list(only_normal = True)

		open_to_close_delims = self.inline_delimiters._get_all_open_delim_to_close_delim()
		open_to_close_no_nesting_delims = self.inline_delimiters._get_all_open_delim_to_close_delim(only_no_nesting = True)

		static_content_stack = []
		line_rest = line
		purged_line = ""
		prev_delim = None

		# TODO: check if reducing stack to only no nesting delimiters is more efficient.
		for delim in delimiters_stack:
			if delim in open_no_nesting and open_to_close_delims.get(prev_delim) != delim:
				delim_match = re.search(r"(?<!\\)(?:" + re.escape(delim) + r")", line_rest)
				new_start = delim_match.start()
				#purged_line += line_rest[:new_start]
				purged_line += self.replace_special_characters(line_rest[:new_start]) + delim + ' '	# Temporary solution.
				new_start = delim_match.end()
				line_rest = line_rest[new_start:]
				prev_delim = delim
			elif delim in close_no_nesting and open_to_close_no_nesting_delims.get(prev_delim) == delim:
				delim_match = re.search(re.escape(delim), line_rest)
				new_end = delim_match.start()
				static_content = line_rest[:new_end]
				if static_content == "": 
					# TODO: change for logger warning.
					print("Empty delimiters content found.")
				static_content_stack.append(static_content)
				purged_line += delim
				new_start = delim_match.end()
				line_rest = line_rest[new_start:]
				prev_delim = None
			elif delim in normal_delimiters: #continue
				# Temporary solution.
				delim_match = re.search(r"(?<!\\)(?:" + re.escape(delim) + r")", line_rest)
				new_start = delim_match.start()
				purged_line += self.replace_special_characters(line_rest[:new_start]) + delim
				new_start = delim_match.end()
				line_rest = line_rest[new_start:]
				prev_delim = delim if delim in open_normal else None
			else: raise ValueError(f"Delimiter {delim} not recognized.")

		#purged_line += line_rest
		purged_line += self.replace_special_characters(line_rest)		# Temporary solution.

		return static_content_stack, purged_line
	
	def _aux_delimiter_replacement(self, match_object, delimiters_stack, static_content_stack): 
		open_normal = self.inline_delimiters._get_open_delimiters(only_normal = True)
		open_no_nesting = self.inline_delimiters._get_open_delimiters(only_no_nesting = True)
		open_comment = [delims.open for delims in self.inline_delimiters.comment.no_nesting]
		close_delimiters = self.inline_delimiters._get_close_delimiters()

		open_to_close_delims = self.inline_delimiters._get_all_open_delim_to_close_delim()
		aux_stack = self._aux_stack

		delim = match_object.group()
		delim = delim.replace(' ', '')
		top_delim = delimiters_stack.pop()

		if delim != top_delim: 
			raise ValueError(f"Matched delimiter: {delim}, is not last delimiter in stack: {top_delim}.")
		prev_delim = aux_stack[-1] if aux_stack else None

		if delim in open_no_nesting and open_to_close_delims.get(prev_delim) != delim:
			if delim not in open_comment or config.parse_inline_line_comments:
				static_content = static_content_stack.pop()
				# TODO: quit this when cross references are implemented.
				if set(aux_stack) & set(self.reference_open_delims):
					static_content = self.replace_code_special_characters(static_content)
					replacement = self.open_delim_to_LaTeX_delims[delim][0].replace('`', '!') + static_content
				elif self.line_state.identifier == config._patterns.SectionHeader.name \
				and delim in config.protect_section_delims:
					static_content = self.replace_code_special_characters(static_content)
					replacement = self.open_delim_to_LaTeX_protected_delims[delim][0] + static_content
				# TODO: change `protect_section_delims` to `intitle_section_delims`.
				elif self.line_state.identifier == config._patterns.ActionErrorBestPractice.name \
				and delim in config.protect_section_delims:
					static_content = self.replace_code_special_characters(static_content)
					replacement = self.open_delim_to_LaTeX_intitle_delims[delim][0] + static_content
				elif self.line_state.identifier == config._patterns.ParagraphHeader.name \
				and delim in config.protect_section_delims:
					static_content = self.replace_code_special_characters(static_content)
					replacement = self.open_delim_to_LaTeX_intitle_delims[delim][0] + static_content
				elif delim in self.hyperlink_open_delims and prev_delim in open_normal:
					static_content = self.replace_url_special_characters(static_content)
					replacement = self.open_delim_to_LaTeX_delims[delim][0] + static_content
				elif set(aux_stack) & set(self.footnote_open_delims):
					static_content = self.replace_code_special_characters(static_content)
					replacement = self.open_delim_to_LaTeX_delims[delim][0] + static_content
				else:
					replacement = self.open_delim_to_LaTeX_delims[delim][0] + static_content
			else:
				replacement = ""
			aux_stack.append(delim)
			prev_delim = delim
		elif delim in open_normal and open_to_close_delims.get(prev_delim) != delim:
			replacement = self.open_delim_to_LaTeX_delims[delim][0]
			aux_stack.append(delim)
			prev_delim = delim
		elif delim in close_delimiters and open_to_close_delims.get(prev_delim) == delim:
			if prev_delim not in open_comment or config.parse_inline_line_comments:
				# TODO: quit this when cross references are implemented.
				if set(aux_stack) & set(self.reference_open_delims):
					replacement = self.open_delim_to_LaTeX_delims[prev_delim][1].replace('`', '!')
				elif self.line_state.identifier == config._patterns.SectionHeader.name \
				and prev_delim in config.protect_section_delims:
					replacement = self.open_delim_to_LaTeX_protected_delims[prev_delim][1]
				elif self.line_state.identifier == config._patterns.ActionErrorBestPractice.name \
				and prev_delim in config.protect_section_delims:
					replacement = self.open_delim_to_LaTeX_intitle_delims[prev_delim][1]
				elif self.line_state.identifier == config._patterns.ParagraphHeader.name \
				and prev_delim in config.protect_section_delims:
					replacement = self.open_delim_to_LaTeX_intitle_delims[prev_delim][1]
				else:
					replacement = self.open_delim_to_LaTeX_delims[prev_delim][1]
			else: 
				replacement = ""
			aux_stack.pop()
			prev_delim = aux_stack[-1] if aux_stack else None
		else: 
			raise ValueError(f"Delimiter {delim} not recognized.")

		return replacement

	def _delimiter_replacement(self, match_object): 
		return self._aux_delimiter_replacement(
			match_object, 
			self._delimiters_stack, 
			self._static_content_stack
		)
	
	def delimiter_replacement(self, purged_line, spaced_delimiters_stack): 
		
		replaced_line = ""
		line_rest = purged_line

		for delim in spaced_delimiters_stack:
			match_object = re.search(fr"(?<!\\)(?:{re.escape(delim)})", line_rest)

			if match_object:
				new_start = match_object.start()
		
				replacement = self._aux_delimiter_replacement(
					match_object, 
					self._delimiters_stack, 
					self._static_content_stack
				)

				replaced_line += line_rest[:new_start] + replacement

				new_start = match_object.end()
				line_rest = line_rest[new_start:]
			
		replaced_line += line_rest
		
		return replaced_line

	# TODO: verify if `extract_delimiters_static_content()` and `replace_special_characters()` parts could be separated as external steps, so `replace_delimiters()` would work with the purged line and then another step could handle the static content in `parse_line()` function.
	def _replace_delimiters(self, line, delimiters_stack = None): 
		if delimiters_stack is None: 
			delimiters_stack = self.get_inline_delimiters_stack(line)

		if not delimiters_stack: 
			#return line
			return self.replace_special_characters(line)		# Temporary solution.

		delimiters_stack.reverse()
		self._delimiters_stack = delimiters_stack
		self._aux_stack = []

		static_content, purged_line = self.extract_delimiters_static_content(line)

		static_content.reverse()
		self._static_content_stack = static_content

		LaTeX_line = self.delimiter_replacement(purged_line, self._delimiters_spaced_stack)
		
		if self._delimiters_stack != []: 
			raise ValueError("Some line delimiters were not closed.")
		if self._static_content_stack != []: 
			raise ValueError("Static content not processed.")

		return LaTeX_line

	def replace_delimiters(self, line, delimiters_stack = None):
		if not line: return ""

		LaTeX_line, end_comment_content = self.purge_end_line_comments(line, delimiters_stack)
		if not end_comment_content: LaTeX_line = self._replace_delimiters(line, delimiters_stack)
		elif config.parse_line_comments: 
			LaTeX_line += f"%{end_comment_content}"
		else: LaTeX_line = re.match(r"(.*[^ \t])[ \t]*$", LaTeX_line).group(1)

		return LaTeX_line

	def _replace_special_characters(self, match_object): 
		element = match_object.group()
		return self.LaTeX_special_replacements[element]
	
	def _replace_code_special_characters(self, match_object): 
		element = match_object.group()
		return self.LaTeX_code_special_replacements[element]
	
	def _replace_url_special_characters(self, match_object): 
		element = match_object.group()
		return self.LaTeX_url_special_replacements[element]

	def replace_special_characters(self, purged_line): 
		purged_line = re.sub(
			self.special_replacements_keys_string, 
			self._replace_special_characters, 
			purged_line
		)

		return purged_line
	
	def replace_code_special_characters(self, static_line): 
		static_line = re.sub(
			self.code_special_replacements_keys_string, 
			self._replace_code_special_characters, 
			static_line
		)

		return static_line
	
	def replace_url_special_characters(self, static_line): 
		static_line = re.sub(
			self.url_special_replacements_keys_string, 
			self._replace_url_special_characters, 
			static_line
		)

		return static_line

	# TODO: make another "light" version which do not make any replacement, only to get the purged line and pass it to other functions, like `get_identifier()`.
	def purge_end_line_comments(self, line, delimiters_stack):
		LaTeX_line = line
		comment_symbol = config.line_comment_symbol
		line_split = line.split(comment_symbol)
		
		if len(line_split) >= 2:
			text_content = ""
			for i, sub_string in enumerate(line_split[:-1]):
				
				if i > 0: text_content += comment_symbol
				text_content += sub_string
				end_comment_content = f"{comment_symbol}".join(line_split[i + 1:])
				try:
					LaTeX_line = self._replace_delimiters(text_content, delimiters_stack)
					success_parse = True
				except:
					end_comment_content = None
					success_parse = False
				
				if success_parse: break
		else:
			end_comment_content = None
		
		return LaTeX_line, end_comment_content

	# TODO: lighter (check ToDo on `purge_end_line_comments()`).
	def light_purge_end_line_comments(self, line, delimiters_stack = None):
		purged_line = line
		comment_symbol = config.line_comment_symbol
		line_split = line.split(comment_symbol)
		
		if len(line_split) >= 2 and line_split[0].replace(" ", '').replace("\t", ''):
			text_content = ""
			for i, sub_string in enumerate(line_split[:-1]):
				
				if i > 0: text_content += comment_symbol
				text_content += sub_string
				end_comment_content = f"{comment_symbol}".join(line_split[i + 1:])
				try:
					self._replace_delimiters(text_content, delimiters_stack)
					success_parse = True
				except:
					end_comment_content = None
					success_parse = False
				
				if success_parse: 
					purged_line = re.match(r"(.*[^ \t])[ \t]*$", text_content).group(1)
					break
		else:
			end_comment_content = None
		
		return purged_line, end_comment_content

	# TODO: this function also could do the work of `extract_delimiters_static_content()`, in expense of readability and simplicity. Decide if it stays or is integrated in this function.
	# TODO: make this function a `split_text_line()` which returns a list of tuples with distincts parts of the line and their text_identifier (text, static content, open_normal_delim, close_no_nesting_delim, etc.), then this function could be redefined to only take the parts which identifier is a delimiter.
	# TODO: when searching for delimiters, search first for scaped ones and ignore them. Make a string pattern with two groups, one for scaped and other for real delimiters. If match with the first group, take it as part of normal text.
	def get_inline_delimiters_stack(self, line: str) -> list[str]:
		stack = []
		complete_stack = []
		self._delimiters_spaced_stack = []
		line_rest = line

		open_delims = self.inline_delimiters._get_open_delimiters()
		open_normal = self.inline_delimiters._get_open_delimiters(only_normal = True)
		open_no_nesting = self.inline_delimiters._get_open_delimiters(only_no_nesting = True)
		close_delims = self.inline_delimiters._get_close_delimiters()

		open_to_close_delims = self.inline_delimiters._get_all_open_delim_to_close_delim()

		open_delims_string = self.inline_delimiters.make_delimiters_string(open_delims)

		delims_match = re.search(open_delims_string, line)

		while delims_match:

			prev_delim = stack[-1] if len(stack) >= 1 else None
			delim = delims_match.group()

			complete_stack.append(delim)

			new_start = delims_match.end()
			line_rest = line_rest[new_start:]

			if delim in open_no_nesting and open_to_close_delims.get(prev_delim) != delim: 
				stack.append(delim)
				self._delimiters_spaced_stack.append(delim + ' ')
				close_delim = open_to_close_delims[delim]
				delims_match = re.search(re.escape(close_delim), line_rest)
			elif delim in open_normal and open_to_close_delims.get(prev_delim) != delim: 
				stack.append(delim)
				self._delimiters_spaced_stack.append(delim)
				close_delim = open_to_close_delims[delim]
				new_search_delims_string = self.inline_delimiters.make_delimiters_string(open_delims + [close_delim])
				delims_match = re.search(new_search_delims_string, line_rest)
			elif delim in close_delims: 
				if open_to_close_delims.get(prev_delim) == delim:
					self._delimiters_spaced_stack.append(delim)
					stack.pop()
				else: raise ValueError("Closing delimiter does not match last opened delimiter.")
				
				new_search_delims_string = self.inline_delimiters.make_delimiters_string(
					open_delims if not stack else open_delims + [open_to_close_delims[stack[-1]]]
				)
				delims_match = re.search(new_search_delims_string, line_rest)
			else: raise ValueError(f"Delimiter {delim} not recognized.")

		if stack != []: raise ValueError(f"Not all delimiters were closed (stack: {stack}).")

		return complete_stack