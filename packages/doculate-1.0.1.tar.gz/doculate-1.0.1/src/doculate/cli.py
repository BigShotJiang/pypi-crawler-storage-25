import argparse
import sys
from typing import overload
from dataclasses import dataclass

from doculate.config import config
from doculate.parser import Parser
from doculate.latex.preamble import Preamble
from doculate.utils import get_file_name

def main():
	cli = doculate_cli()

	# TODO: give most `add_argument()` params through `cli` object.
	common_args = ArgumentParser(add_help = False)
	common_args.add_argument(cli.config_file, type = str, default = None, help = cli.config_file.help)
	common_args.add_argument(cli.output_dir, type = str, default = None, help = cli.output_dir.help)
	common_args.add_argument(cli.title, type = str, default = None, help = cli.title.help)
	common_args.add_argument(cli.author, type = str, default = None, help = cli.author.help)
	common_args.add_argument(cli.programming_languages, type = str, default = None, nargs = '+', help = cli.programming_languages.help)
	common_args.add_argument(cli.programming_languages_definition_files, type = str, default = None, nargs = '+', help = cli.programming_languages_definition_files.help)

	command = ArgumentParser(description = "Main command for docuLaTe.", parents = [common_args])
	command.add_argument(cli.input_file, type = str, default = None, help = cli.input_file.help)
	command.add_argument(cli.only_parse_file, action = "store_true")
	command.add_argument(cli.only_create_preamble_files, action = "store_true")
	command.add_argument(cli.only_analyze_file, action = "store_true")
	command.add_argument(cli.parsed_file_name, type = str, default = None, help = cli.parsed_file_name.help)
	command.add_argument(cli.preamble_file_name, type = str, default = None, help = cli.preamble_file_name.help)
	command.add_argument(cli.line_state_file_name, type = str, default = None, help = cli.line_state_file_name.help)

	subcommands = command.add_subparsers(title = "Subcommands", action = _SubParsersAction, dest = "subcommand")

	subcom_parse_file = subcommands.add_parser(cli.parse_file, aliases = [cli.parse_file.alias], parents = [common_args], help = cli.parse_file.help)
	subcom_parse_file.add_argument(cli.parse_file.input_parse_file, type = str, default = None, help = cli.parse_file.input_parse_file.help)
	subcom_parse_file.add_argument(cli.parse_file.output_file, type = str, default = None, help = cli.parse_file.output_file.help)
	subcom_parse_file.add_argument(cli.parse_file.output_log, type = str, default = None, help = cli.parse_file.output_log.help)
	#subcom_parse_file.set_defaults(func = set_parse_file)

	subcom_create_preamble = subcommands.add_parser(cli.create_preamble, aliases = [cli.create_preamble.alias], parents = [common_args], help = cli.create_preamble.help)
	subcom_create_preamble.add_argument(cli.create_preamble.input_preamble_file, type = str, default = None, help = cli.create_preamble.input_preamble_file.help)
	subcom_create_preamble.add_argument(cli.create_preamble.output_file, type = str, default = None, help = cli.create_preamble.output_file.help)
	#subcom_create_preamble.set_defaults(func = set_create_preamble)

	subcom_analyze_file = subcommands.add_parser(cli.analyze_file, aliases = [cli.analyze_file.alias], parents = [common_args], help = cli.analyze_file.help)
	subcom_analyze_file.add_argument(cli.analyze_file.input_analyze_file, type = str, default = None, help = cli.analyze_file.input_analyze_file.help)
	subcom_analyze_file.add_argument(cli.analyze_file.output_file, type = str, default = None, help = cli.analyze_file.output_file.help)
	#subcom_analyze_file.set_defaults(func = set_analyze_file)
	
	no_args = len(sys.argv) < 2
	no_main_positional = not no_args and (sys.argv[1] in cli.subcommands or sys.argv[1][0] == '-')

	if no_args: sys.argv.append("")
	elif no_main_positional: sys.argv[1:] = [""] + sys.argv[1:]

	args = command.parse_args()
	input_file = args.input_file
	subcommand = args.subcommand

	if config_file := args.config_file: config.reset(config_file)

	if no_args:
		if not config.config_files_opened: print("No config file detected."); raise SystemExit
		if not config.txt_input_file: print("No input file in config file was detected."); raise SystemExit
	elif input_file:
		set_input_file_configs(input_file)
	elif subcommand in [cli.parse_file.repr, cli.parse_file.alias]:
		input_parse_file = args.input_parse_file
		if not input_parse_file: print("No file to parse was received."); raise SystemExit
		set_input_file_configs(input_parse_file)
		output_file = args.output_file
		output_log = args.output_log
	elif subcommand in [cli.create_preamble.repr, cli.create_preamble.alias]:
		input_preamble_file = args.input_preamble_file
		if not input_preamble_file: print("No content input file for preamble was received."); raise SystemExit
		set_input_file_configs(input_preamble_file)
		output_file = args.output_file
		if output_file: config.preamble_file_name = output_file
	elif subcommand in [cli.analyze_file.repr, cli.analyze_file.alias]:
		input_analyze_file = args.input_analyze_file
		if not input_analyze_file: print("No file to analyze was received."); raise SystemExit
		output_file = args.output_file
	elif config.txt_input_file: 
		pass
	else:
		print("No input file or subcommand was received."); raise SystemExit

	if output_dir := args.output_dir: config.output_dir = output_dir
	if title := args.title: config.title = title
	if author := args.author: config.author = author
	if programming_languages := args.programming_languages: 
		if not config.main_programming_language:
			config.main_programming_language = programming_languages[0]
			programming_languages = programming_languages[1:]
		config.programming_languages = programming_languages
	if programming_languages_definition_files := args.programming_languages_definition_files: 
		config.programming_languages_definition_files = programming_languages_definition_files
	if preamble_file_name := args.preamble_file_name: config.preamble_file_name = preamble_file_name

	only_parse_file = args.only_parse_file
	only_create_preamble_files = args.only_create_preamble_files
	only_analyze_file = args.only_analyze_file
	parsed_file_name = args.parsed_file_name
	line_state_file_name = args.line_state_file_name

	if (input_file or config.txt_input_file) and not subcommand:
		parser = Parser(input_file, parsed_file_name, line_state_file_name)
		preamble = Preamble(parsed_file_name, preamble_file_name)
		if not only_parse_file and not only_create_preamble_files and not only_analyze_file:
			parser.parse_file()
			preamble.create_preamble_files()
		elif only_analyze_file: parser.analyze_file()
		elif only_parse_file: parser.parse_file()
		elif only_create_preamble_files: preamble.create_preamble_files()
	elif subcommand in [cli.parse_file.repr, cli.parse_file.alias]:
		parser = Parser()
		parser.parse_file(input_parse_file, output_file, output_log)
	elif subcommand in [cli.create_preamble.repr, cli.create_preamble.alias]:
		preamble = Preamble()
		preamble.create_preamble_files(input_preamble_file, output_file)
	elif subcommand in [cli.analyze_file.repr, cli.analyze_file.alias]:
		parser = Parser()
		parser.analyze_file(input_analyze_file, output_file)

@dataclass
class Argument:
	repr: str
	short_repr: str = None
	type = str
	allowed_values: str | list = None
	default = None
	help: str = None

	def __repr__(self):
		return self.repr

@dataclass
class SubCommand:
	repr: str
	alias: str | list[str] = None
	type = str
	default = None
	help: str = None

	def __repr__(self):
		return self.repr

	def set_argument(self, **kwargs):
		for k, v in kwargs.items():
			setattr(self, k, Argument(v))

@dataclass
class Command:
	repr: str
	type = str
	default = None
	help: str = None

	def __repr__(self):
		return self.repr

	def set_subcommand(self, **kwargs):
		for k, v in kwargs.items():
			setattr(self, k, SubCommand(v))
	
	def set_argument(self, **kwargs):
		for k, v in kwargs.items():
			setattr(self, k, Argument(v))

class CLI:

	def __init__(self, main_command = None):
		self.commands = []
		self.subcommands = []
		self.arguments = []

		if main_command: 
			self.main_command = main_command
			self.set_command(main_command = self.main_command)

	def __repr__(self):
		return self.main_command.repr

	def set_command(self, **kwargs):
		for k, v in kwargs.items():
			setattr(self, k, Command(v))
			self.commands.append(v)
	
	def set_subcommand(self, command: Command = None, **kwargs):
		if not command:
			for k, v in kwargs.items():
				setattr(self, k, SubCommand(v))
				self.subcommands.append(v)
		else:
			for k, v in kwargs.items():
				command.set_subcommand(**kwargs)
	
	def set_argument(self, **kwargs):
		for k, v in kwargs.items():
			setattr(self, k, Argument(v))
			self.arguments.append(v)

def doculate_cli():
	doculate_cli = CLI("doculate")

	doculate_cli.set_argument(input_file = "input_file")
	doculate_cli.set_argument(config_file = "--config-file")
	doculate_cli.set_argument(output_dir = "--output-dir")
	doculate_cli.set_argument(only_parse_file = "--only-parse-file")
	doculate_cli.set_argument(only_create_preamble_files = "--only-create-preamble-files")
	doculate_cli.set_argument(only_analyze_file = "--only-analyze-file")
	doculate_cli.set_argument(title = "--title")
	doculate_cli.set_argument(author = "--author")
	doculate_cli.set_argument(programming_languages = "--programming-languages")
	doculate_cli.set_argument(programming_languages_definition_files = "--programming-languages-definition-files")
	doculate_cli.set_argument(parsed_file_name = "--parsed-file-name")
	doculate_cli.set_argument(preamble_file_name = "--preamble-file-name")
	doculate_cli.set_argument(line_state_file_name = "--line-state-file-name")

	# TODO: improve definition structure.
	doculate_cli.config_file.short_repr = "-c"
	doculate_cli.output_dir.short_repr = "-d"
	doculate_cli.title.short_repr = "-t"
	doculate_cli.author.short_repr = "-a"
	doculate_cli.programming_languages.short_repr = "-p"
	doculate_cli.programming_languages_definition_files.short_repr = "-f"
	doculate_cli.line_state_file_name.short_repr = "-s"

	doculate_cli.input_file.help = "Plain text file to parse."
	doculate_cli.config_file.help = "JSON configuration file. If present, CLI options have priority over JSON."
	doculate_cli.output_dir.help = "Directory path where output files will be placed."
	doculate_cli.title.help = "Document title shown in front page."
	doculate_cli.author.help = "Document author shown in front page."
	doculate_cli.programming_languages.help = "Syntax highlighting for entered programming languages (if supported)."
	doculate_cli.programming_languages_definition_files.help = "Programming languages definition files for syntax highlighting."
	doculate_cli.parsed_file_name.help = "Output file name with .tex extension."
	doculate_cli.preamble_file_name.help = "Output preamble main file name with .tex extension."

	doculate_cli.set_subcommand(parse_file = "parse-file")
	doculate_cli.parse_file.alias = 'p'
	doculate_cli.subcommands.append(doculate_cli.parse_file.alias)
	doculate_cli.parse_file.set_argument(input_parse_file = "input_parse_file")
	doculate_cli.parse_file.set_argument(output_file = "--output-file")
	doculate_cli.parse_file.set_argument(output_log = "--output-log")
	doculate_cli.parse_file.output_file.short_repr = "-o"

	doculate_cli.parse_file.help = "Parse txt file to LaTeX file."
	doculate_cli.parse_file.input_parse_file.help = "Plain text file to parse."
	doculate_cli.parse_file.output_file.help = "Output file name with .tex extension."
	doculate_cli.parse_file.output_log.help = "Output log file name for input -> output line comparison"

	doculate_cli.set_subcommand(create_preamble = "create-preamble")
	doculate_cli.create_preamble.alias = "pr"
	doculate_cli.subcommands.append(doculate_cli.create_preamble.alias)
	doculate_cli.create_preamble.set_argument(input_preamble_file = "input_preamble_file")
	doculate_cli.create_preamble.set_argument(output_file = "--output-file")
	doculate_cli.create_preamble.output_file.short_repr = "-o"

	doculate_cli.create_preamble.help = "Create preamble LaTeX files."
	doculate_cli.create_preamble.input_preamble_file.help = "Document .tex file with main content (parse file output)."
	doculate_cli.create_preamble.output_file.help = "Output preamble main file name with .tex extension."

	doculate_cli.set_subcommand(analyze_file = "analyze-file")
	doculate_cli.analyze_file.alias = 'a'
	doculate_cli.subcommands.append(doculate_cli.analyze_file.alias)
	doculate_cli.analyze_file.set_argument(input_analyze_file = "input_analyze_file")
	doculate_cli.analyze_file.set_argument(output_file = "--output-file")
	doculate_cli.analyze_file.output_file.short_repr = "-o"

	doculate_cli.analyze_file.help = "Verify correct parsing."
	doculate_cli.analyze_file.input_analyze_file.help = "Plain text file to parse."
	doculate_cli.analyze_file.output_file.help = "Output log file name."

	return doculate_cli


class ArgumentParser(argparse.ArgumentParser):

	@overload
	def add_argument(self, *name_or_flags: str, **kwargs) -> argparse.Action: ...

	@overload
	def add_argument(self, name_or_flags: Argument, **kwargs) -> argparse.Action: ...

	def add_argument(self, *args, **kwargs):
		if len(args) == 1 and isinstance(args[0], Argument):
			arg = args[0]
			if arg.short_repr: args = (arg.repr, arg.short_repr)
			else: args = (arg.repr, )

		return super().add_argument(*args, **kwargs)


class _SubParsersAction(argparse._SubParsersAction):

	@overload
	def add_parser(self, name: str, **kwargs) -> argparse.ArgumentParser: ...

	@overload
	def add_parser(self, name: SubCommand, **kwargs) -> argparse.ArgumentParser: ...

	def add_parser(self, name, **kwargs):
		if isinstance(name, SubCommand):
			name = name.repr

		return super().add_parser(name, **kwargs)

def set_input_file_configs(input_file):
	old_content_file_name = config.content_file_name
	
	config.txt_input_file = input_file
	config.content_file_name = get_file_name(input_file)
	config.content_input_tex_file = config.content_file_name + ".tex"
	
	if not config.title or config.title == old_content_file_name: config.title = config.content_file_name
	if (not config.main_programming_language and config.use_file_name_if_no_main_language) \
	or (config.main_programming_language == old_content_file_name and config.use_file_name_if_no_main_language): 
		config.main_programming_language = config.content_file_name