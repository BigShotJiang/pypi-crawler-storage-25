class _ConfigDefaults:
	txt_input_file = None
	output_dir = "./"
	output_line_state_log_dir = output_dir

	title = None
	author = None
	date = "\\today"

	main_font_size = "12pt"

	page_left_margin = "25mm"
	page_right_margin = "25mm"
	page_top_margin = "40mm"
	page_bottom_margin = "30mm"

	front_page_left_margin = "50pt"
	front_page_right_margin = "50pt"
	front_page_top_margin = "1ex"
	front_page_bottom_margin = "1ex"

	title_font_size = "200"

	tableofcontents_name = "Contents"

	sections = ["book", "part", "chapter", "section", "subsection", "subsubsection"]
	minor_sections = sections[-3:].copy()
	root_section = "chapter"
	paragraphs = ["paragraph", "subparagraph"]

	header_mark = "#"
	library_mark = "+"
	paragraph_mark = header_mark
	section_marks_unit = "-"
	term_mark = r"\*"
	#end_term_mark = term_mark		# Not yet implemented
	#special_term_mark = r"\*"		# Not yet implemented
	action_error_best_practice_mark = r"\*"
	#action_mark = action_error_best_practice_mark		# Not yet implemented
	#error_mark = action_mark							# Not yet implemented
	#best_practice_mark = action_mark					# Not yet implemented
	list_mark = "-"
	description_mark = "-"
	informal_reference_mark = r"\[\]"
	block_comment_delimiters = ["(%", "%)"]
	LaTeX_block_comment_delimiters = ["\\iffalse{}", "\\fi"]
	line_comment_symbol = r"%%"

	_implicit_env_prefix = "Implicit"
	_implicit_after_elem_env_prefix = "AfterElem"
	_env_content_identifier_suffix = "_content"
	_env_content_empty_line_identifier_suffix = "_empty_content"
	_ignored_line_identifier_prefix = "ignored_"

	# TODO: pass to _DefaultInlineDelimiters class.
	default_inline_normal_delimiter = "'"
	default_inline_no_nesting_delimiter = "\""
	default_unambiguous_normal_delimiters = ['{', '}']

	default_LaTeX_special_replacements = {
		'\\': "\\textbackslash{}", 
		'^': "\\textasciicircum{}", 
		'_': r'\_', 
		'&': r'\&', 
		'%': r'\%', 
		'$': r'\$', 
		'#': r'\#', 
		'{': r'\{', 
		'}': r'\}', 
		'~': "\\textasciitilde{}", 
		"TeX": "\\TeX{}", 
		"LaTeX": "\\LaTeX{}", 
		"BibTeX": "\\textsc{Bib}\\TeX{}",
	}
	LaTeX_special_replacements = default_LaTeX_special_replacements.copy()

	default_LaTeX_code_special_replacements = {
		'\\': "\\\\", 
		'%': r'\%', 
		'{': r'\{', 
		'}': r'\}', 
		'#': r'\#'
	}
	LaTeX_code_special_replacements = default_LaTeX_code_special_replacements.copy()

	default_LaTeX_url_special_replacements = {
		'\\': "\\\\", 
		'%': r'\%', 
		'#': r'\#'
	}
	LaTeX_url_special_replacements = default_LaTeX_url_special_replacements.copy()

	colon_rule_when_no_identifiers = True
	default_list_element_when_no_identifiers = True

	ignore_sintax_initial_tabs = True
	ignore_example_initial_tabs = True

	ignore_initial_and_final_env_empty_lines = True

	initial_indent_pseudo_env = "initial_nest"
	item_type_stack_placeholder = "placeholder"

	simple_term_command = "\\Term"
	first_term_command = "\\FirstTerm"
	comma_term_command = "\\CommaTerm"
	final_term_command = "\\FinalTerm"
	final_ellipsis_term_command = "\\FinalEllipsisTerm"
	informal_reference_command = "\\InformalReference"

	action_error_best_practice_command = "\\ActionErrorBP"
	#action_command = "\\Action"				# Not yet implemented
	#error_command = "\\Error"					# Not yet implemented
	#best_practice_command = "\\BestPractice"	# Not yet implemented

	parse_informal_references = True
	parse_block_comments = False
	parse_line_comments = True
	parse_inline_line_comments = True

	# TODO: integrate colors in environment code class.
	default_code_background_color = "gray!10!white"
	code_background_color = default_code_background_color
	default_code_title_color = "gray!70!black"
	code_title_color = default_code_title_color
	default_code_frame_color = "gray!70!white"
	code_frame_color = default_code_frame_color
	default_code_environments_title_colors = {
		"Sintax": "violet!30!gray", 
		"CodeSintax": "violet!30!gray", 
		"Example": "green!30!gray", 
		"Examples": "green!30!gray!85!black", 
		"AntiExample": "red!30!gray", 
		"AntiExamples": "red!30!gray!85!black", 
		"Code": "blue!30!gray", 
		"CodeExample": "green!30!gray", 
		"CodeAntiExample": "red!30!gray", 
		"CommandsCode": "black!30!gray", 
		"Configuration": "cyan!30!gray", 
		"Class": "blue!30!gray", 
		"Function": "blue!30!gray", 
		"Procedure": "blue!30!gray", 
		"Definition": "yellow!80!black", 
		"Definitions": "yellow!72!black"
	}
	code_environments_title_colors = default_code_environments_title_colors.copy()

	code_environments_font_size = "small"

	header_pre_chapter_mark = "Chapter "
	header_pos_chapter_mark = ". "

	default_front_page_file_name = "front_page.tex"
	front_page_file_name = default_front_page_file_name
	default_preamble_file_name = "preamble.tex"
	preamble_file_name = default_preamble_file_name

	main_programming_language = None
	programming_languages: list[str] = None
	use_file_name_if_no_main_language = False

	programming_languages_definition_files: str | list[str] = None