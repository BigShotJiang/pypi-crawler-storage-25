import shutil
import os

cwd = os.getcwd()

latex_resources_path = os.path.dirname(os.path.realpath(__file__)) + "/latex"

def is_list_of_str(obj):
	return isinstance(obj, list) and all(isinstance(elem, str) for elem in obj)

def remove_initial_tabs(string, n: int = None):
	if not n: return string.lstrip('\t')
	else: 
		for _ in range(n): 
			if string and string[0] == '\t': string = string[1:] 
			else: break
	return string

def copy_dir(dir_path, destination):
	if not os.path.exists(destination):
		shutil.copytree(dir_path, destination)
	else:
		print(f"Folder {destination} already exists. Can't be overwritten. Delete it first and try again if you want to do so.")
		# TODO: raise a WARN,
		#raise ValueError(f"Folder {destination} already exists. Currently can't overwrite. Delete it first and try again.")

def file_exists(file: str):
	return os.path.isfile(file)

def get_file_name(file_path):
	file_name = file_path.split('/')[-1]
	file_name = file_name.split('.')
	if len(file_name) > 1: 
		file_name = '.'.join(file_name[:-1])
	else: file_name = file_name[0]
	
	return file_name