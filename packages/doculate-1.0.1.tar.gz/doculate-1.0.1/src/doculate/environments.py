from dataclasses import dataclass, fields, field

from doculate.config_defaults import _ConfigDefaults


class _Environment: 
	def __init__(self, 
		id: str, 
		values: list[str], 
		LaTeX_name: str = None, 
		LaTeX_delimiters: list[str] = None
	):
		self.id = id
		self.values = values
		self.LaTeX_name = LaTeX_name
		self.LaTeX_delimiters = LaTeX_delimiters

class _BlockEnvironment: 
	def __init__(self, 
		id: str, 
		delimiters: list[str], 
		LaTeX_name: str = None, 
		LaTeX_delimiters: list[str] = None
	):
		self.id = id
		self.delimiters = delimiters
		self.LaTeX_name = LaTeX_name
		self.LaTeX_delimiters = LaTeX_delimiters

# TODO: divide class into list-like and code environments (make proper adjustments in config.py).
@dataclass
class _DefaultEnvironments: 
	Sintax: _Environment = _Environment(
		id = "Sintax", 
		values = ["Sintaxis"], 
		LaTeX_name = "syntax"
	)
	CodeSintax: _Environment = _Environment(
		id = "CodeSintax", 
		values = ["Sintaxis código"], 
		LaTeX_name = "code_syntax"
	)
	Example: _Environment = _Environment(
		id = "Example", 
		values = ["Ejemplo", "Ej."], 
		LaTeX_name = "example"
	)
	Examples: _Environment = _Environment(
		id = "Examples", 
		values = ["Ejemplos", "Ejs."], 
		LaTeX_name = "examples"
	)
	AntiExample: _Environment = _Environment(
		id = "AntiExample", 
		values = [
			"Antiejemplo", 
			"Anti-ejemplo", 
			"Ant. ej.", 
			"A. ej."
		], 
		LaTeX_name = "antiexample"
	)
	AntiExamples: _Environment = _Environment(
		id = "AntiExamples", 
		values = [
			"Antiejemplos", 
			"Anti-ejemplos", 
			"Ant. ejs.", 
			"A. ejs."
		], 
		LaTeX_name = "antiexamples"
	)
	Code: _Environment = _Environment(
		id = "Code", 
		values = ["Código", "Cod."], 
		LaTeX_name = "code"
	)
	CommandsCode: _Environment = _Environment(
		id = "CommandsCode", 
		values = ["Comando", "Comandos código"], 
		LaTeX_name = "commands_code"
	)
	Commands: _Environment = _Environment(
		id = "Commands", 
		values = ["Comandos"], 
		LaTeX_name = "commands"
	)
	Subcommands: _Environment = _Environment(
		id = "Subcommands", 
		values = ["Subcomandos", "Subcom."], 
		LaTeX_name = "subcommands"
	)
	Configuration: _Environment = _Environment(
		id = "Configuration", 
		values = [
			"Configuración", 
			"Conf.", 
			"Configuraciones", 
			"Confs."
		], 
		LaTeX_name = "configuration"
	)
	ConfigurationOptions: _Environment = _Environment(
		id = "ConfigurationOptions", 
		values = [
			"Opciones de configuración", 
			"Opc. conf.",
		], 
		LaTeX_name = "configuration_options"
	)
	Definition: _Environment = _Environment(
		id = "Definition", 
		values = ["Definición", "Def."], 
		LaTeX_name = "definition"
	)
	Definitions: _Environment = _Environment(
		id = "Definitions", 
		values = ["Definiciones", "Defs."], 
		LaTeX_name = "definitions"
	)
	CodeExample: _Environment = _Environment(
		id = "CodeExample", 
		values = [
			"Código ejemplo", 
			"Cod. ej.", 
			"Códigos ejemplo", 
			"Cods. ej."
		], 
		LaTeX_name = "codeexample"
	)
	CodeAntiExample: _Environment = _Environment(
		id = "CodeAntiExample", 
		values = [
			"Código antiejemplo", 
			"Códigos antiejemplo", 
			"Cod. antiej.", 
			"Cods. antiej.", 
			"Cod. aej.", 
			"Cods. aej."
		], 
		LaTeX_name = "code_antiexample"
	)
	Function: _Environment = _Environment(
		id = "Function", 
		values = [
			"Función", 
			"Func.", 
			"Funciones código", 
			"Funciones cód.", 
			"Funcs. cód.", 
			"Código función", 
			"Cód. función", 
			"Cód. func.", 
			"Código funciones", 
			"Cód. funciones", 
			"Cód. funcs."
		], 
		LaTeX_name = "func"
	)
	Functions: _Environment = _Environment(
		id = "Functions", 
		values = ["Funciones", "Funcs."], 
		LaTeX_name = "functions"
	)
	Procedure: _Environment = _Environment(
		id = "Procedure", 
		values = [
			"Procedimiento", 
			"Proc.", 
			"Procedimientos código", 
			"Procedimientos cód.", 
			"Procs. cód.", 
			"Código procedimiento", 
			"Cód. procedimiento", 
			"Cód. proc.", 
			"Código procedimientos", 
			"Cód. procedimientos", 
			"Cód. procs."
		], 
		LaTeX_name = "proc"
	)
	Procedures: _Environment = _Environment(
		id = "Procedures", 
		values = ["Procedimientos", "Procs."], 
		LaTeX_name = "procs"
	)
	Classes: _Environment = _Environment(
		id = "Classes", 
		values = ["Clases"], 
		LaTeX_name = "classes"
	)
	Class: _Environment = _Environment(
		id = "Class", 
		values = [
			"Clase", 
			"Clase código", 
			"Clases código", 
			"Clase cód.", 
			"Clases cód.", 
			"Clas. cód.", 
			"Cls. cód.", 
			"Código clase", 
			"Código clases", 
			"Cód. clases", 
			"Cód. clas.", 
			"Cód. cls."
		], 
		LaTeX_name = "class"
	)
	Options: _Environment = _Environment(
		id = "Options", 
		values = ["Opciones"], 
		LaTeX_name = "options"
	)
	List: _Environment = _Environment(
		id = "List", 
		values = ["Lista"], 
		LaTeX_name = "itemize"
	)
	Enumerate: _Environment = _Environment(
		id = "Enumerate", 
		values = ["Enumeración", "Enum."],
		LaTeX_name = "enumerate"
	)
	Description: _Environment = _Environment(
		id = "Description", 
		values = ["Descripción", "Desc."],
		LaTeX_name = "description"
	)
	Fields: _Environment = _Environment(
		id = "Fields", 
		values = ["Campos", "Llaves", "Claves"],
		LaTeX_name = "fields"
	)
	Arguments: _Environment = _Environment(
		id = "Arguments", 
		values = [
			"Argumentos", 
			"Args.", 
			"Argumentos requeridos", 
			"Args. req.", 
			"Argumentos opcionales", 
			"Args. opt."
		], 
		LaTeX_name = "arguments"
	)
	Parameters: _Environment = _Environment(
		id = "Parameters", 
		values = [
			"Parámetros", 
			"Params.", 
			"Parámetros requeridos", 
			"Params. req.", 
			"Parámetros opcionales", 
			"Params. opt."
		], 
		LaTeX_name = "parameters"
	)
	Members: _Environment = _Environment(
		id = "Members", 
		values = ["Miembros"], 
		LaTeX_name = "members"
	)
	Methods: _Environment = _Environment(
		id = "Methods", 
		values = ["Métodos", "Méts."], 
		LaTeX_name = "methods"
	)
	Attributes: _Environment = _Environment(
		id = "Attributes", 
		values = ["Atributos", "Atribs."], 
		LaTeX_name = "attributes"
	)
	Values: _Environment = _Environment(
		id = "Values", 
		values = [
			"Valores", 
			"Vals.", 
			"Posibles valores", 
			"Pos. vals.", 
			"Constantes"
		], 
		LaTeX_name = "values"
	)
	Math: _Environment = _Environment(
		id = "Math", 
		values = ["Texto matemático", "Mat.", "Ecuación", "Ec."], 
		LaTeX_name = "equation"
	)
	MathExpressions: _Environment = _Environment(
		id = "MathExpressions", 
		values = [
			"Expresiones matemáticas", 
			"Ecuaciones", 
			"Mats.", 
			"Ecs."
		], 
		LaTeX_name = "equation"
	)
	AlignedMathExpressions: _Environment = _Environment(
		id = "AlignedMathExpressions", 
		values = [
			"Expresiones matemáticas alin.", 
			"Ecuaciones alin.", 
			"Alin. Mats.", 
			"Alin. Ecs.", 
			"A. Ecs."
		], 
		LaTeX_name = "align*"
	)
	Table: _Environment = _Environment(
		id = "Table", 
		values = ["Tabla"], 
		LaTeX_name = "tabular"
		#LaTeX_delimiters = ["\\begin{table}[H]", "\\end{table}"]
	)
	LaTeX: _Environment = _Environment(
		id = "LaTeX", 
		values = ["LaTeX", "Latex", "latex"], 
		LaTeX_delimiters = ["", ""]
	)
	Comment: _Environment = _Environment(
		id = "Comment", 
		values = ["Comentario", "Comentarios"], 
		LaTeX_delimiters = ["\\iffalse", "\\fi"]
	)

@dataclass
class _SpecialEnvironments: 
	BlockComment: _BlockEnvironment = _BlockEnvironment(
		id = "BlockComment", 
		delimiters = _ConfigDefaults.block_comment_delimiters, 
		LaTeX_delimiters = _ConfigDefaults.LaTeX_block_comment_delimiters
	)


class Environments(_DefaultEnvironments): 

	def __init__(self): 
		self.ids = self._get_environments_ids()
		self.env_id_to_LaTeX_delimiters = self._get_env_id_to_LaTeX_delimiters()

		super().__init__()

	def _get_environments_ids(self): 
		ids = []
		for env in fields(self): 
			env_ins = getattr(self, env.name)
			ids.append(env_ins.id)
		return ids

	def _get_environments_values(self): 
		values = []
		for env in fields(self): 
			env_ins = getattr(self, env.name)
			values += env_ins.values
		return values

	def _get_env_values_string(self): 
		env_values = []
		for env in fields(self):
			env_ins = getattr(self, env.name)
			env_values += env_ins.values
		return '|'.join(env_values).replace('.', r"\.")

	def _get_env_values_to_ids(self): 
		vals_to_ids = {}
		for env in fields(self): 
			env_ins = getattr(self, env.name)
			id = env_ins.id
			for val in env_ins.values: 
				vals_to_ids[val] = id
		return vals_to_ids
	
	def _get_env_id_to_LaTeX_delimiters(self):
		LaTeX_env_delims = {}
		for env in fields(self): 
			env_ins = getattr(self, env.name)
			if env_ins.LaTeX_name is not None:
				LaTeX_env_delims[env_ins.id] = [
					f"\\begin{{{env_ins.LaTeX_name.replace('_', '-')}}}", 
					f"\\end{{{env_ins.LaTeX_name.replace('_', '-')}}}"]
			else:  
				LaTeX_env_delims[env_ins.id] = env_ins.LaTeX_delimiters

		return LaTeX_env_delims