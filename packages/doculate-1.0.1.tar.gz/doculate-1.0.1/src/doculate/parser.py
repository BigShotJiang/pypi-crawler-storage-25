# Copyright (c) 2025 José Alberto López López
# License: Personal Use Only – see LICENSE file for details.


# TODO: include symbol or numeration at the beginning of each action, error and best practice (maybe indent content like in terms?).
# TODO: inspect for incorrect shared references asigments instead copy ones.
# TODO: inspect for innecesary deepcopies or define a more efficient `__deepcopy__`.
# TODO: make strict environment closing when reducing tabs in empty lines in code environments.
# TODO: raise an error from parser when a list-like environment is recognized as normal list and it has an element whose pattern is recognized as description element; or vice versa.
# TODO: change line identifier to "block_comment_content" for subsequent lines after open block comment line.
# TODO: expand logic to take list elems subsequent text lines at same level or indented one extra level as part of that element, until another element starts or the list environment closes.
# TODO: implement escape or special delimiters system to insert delimiters characters inside delimited content.
# TODO: implement multicolumn environment.
# TODO: provide a way to replace the inline delimiters, not to the LaTeX similars, but to others delimiters style, defined in JSON or some map format (and possibly, in future, all other elements, like environments headers, etc.), returning a copy of the original TXT file with the delimiters changed.
# TODO: add environment to env. stack from environment identifier making easier for next line logic to know in where environment is it?
# TODO: line comments are interpreted as text lines.
# TODO: paragraph followed by block comment (or environment) between blank lines followed by another paragraph is not leaving a blank line between paragraphs when `parse_block_comments` is `False`.
# TODO: add blank space at start and end of parsed inside-line comment when it doesn't have them.
# TODO: option to output one file per chapter, part, or some top level section.
# TODO: implement an enumerate environment or print a counter for informal references.
# TODO: make special replacements in normal delimiters no nesting content?
# TODO: lowercase environment name to indicate not framed (boxed) code and first letter uppercase to do so? or with a starred version?
# TODO: environment for large tables.
# TODO: a special term symbol or syntax for difficult match terms, where, without ambiguity and no restrictions, the content always be treat as a term.
# TODO: in addition to prior ToDo, make and test a pattern where, if a term ends with two or more repetition of `.` `?` or `!` (excluding special case of four `.` for action ending with ellipsis), be treat as a term, excluding the last character.
# TODO: next line description stacked elements.

import os

from .config import config
from .line_analizer import LineAnalyzer
from .line_state import LineState
from .utils import remove_initial_tabs


class Parser:

	def __init__(self, 
		input_file: str = None, 
		output_file: str = None, 
		output_line_state_log: str = None, 
		output_line_comp_log: str = None
	):
		self.input_file = input_file
		self.output_file = output_file
		self.output_line_state_log = output_line_state_log
		self.output_line_comp_log = output_line_comp_log

		self.patterns = config._patterns
		self.line_analyzer = LineAnalyzer()
		self.terms_identifiers = self.line_analyzer.terms_identifiers
		self.action_error_bp_identifiers = self.line_analyzer.action_error_bp_identifiers
		self.line_comments_identifiers = config._line_comments_identifiers
		self.block_comments_identifiers = config._block_comments_identifiers

	def analyze_file(self, 
		input_file: str = None, 
		output_file: str = None, 
		limit: int = None
	):
		self.reset()

		if not input_file: input_file = self.input_file
		if not output_file: output_file = self.output_line_state_log

		if not input_file: input_file = config.txt_input_file
		if not output_file: output_file = config.output_line_state_log_dir + config.content_file_name + "_line_state.log"

		with open(input_file, 'r') as input_file_stream: 
			if not os.path.exists(config.output_line_state_log_dir): os.makedirs(config.output_line_state_log_dir)
			if output_file: output_file = open(output_file, 'w', buffering = 1)

			print("Analyzing file:", input_file)

			lines = input_file_stream.read().splitlines()
			i = 0
			for line in lines[:limit]:
				i += 1
				try:
					state = self.line_analyzer.update_line_state(line)
					if output_file: output_file.write(str(state) + '\n')
				except Exception as e:
					raise ValueError("Error while parsing line {}: {}".format(i, e))
			if output_file: output_file.close()

			print("File analysis completed")

	def parse_line(self, line): 

		line_identifier = self.line_analyzer.line_state.identifier
		env_stack = self.line_analyzer.line_state.environment_stack
		current_env = env_stack[-1] if env_stack else None
		nest_level = self.line_analyzer.line_state.nest_level
		new_envs = self.line_analyzer.line_state._new_environments
		pop_envs = self.line_analyzer.line_state._pop_environments.copy()
		pop_envs.reverse()
		prev_identifier = self.line_analyzer.prev_line_state.identifier
		match_object = self.line_analyzer.line_state._match_object
		real_list_item_identifier = self.line_analyzer.line_state._real_item_type
		_prev_library_headers = self.line_analyzer.prev_line_state._library_headers
		_library_headers = self.line_analyzer.line_state._library_headers
		parse_block_comments = config.parse_block_comments
		parse_line_comments = config.parse_line_comments

		replace_delimiters = self.line_analyzer.textline_parser.replace_delimiters

		EmptyLine = self.line_analyzer.patterns.EmptyLine.name
		TextLine = self.line_analyzer.patterns.TextLine.name

		ignored_lines_identifiers = config._ignored_lines_identifiers

		# TODO: turn `EnvironmentsToParse` into config variable?
		Environments = config.environments.ids
		CodeEnvironments = config._code_environments_identifiers
		LaTeX = config.environments.LaTeX.id
		EnvironmentsToParse = Environments.copy()
		EnvironmentsToParse.remove(LaTeX)
		if not parse_block_comments: EnvironmentsToParse.remove(config.environments.Comment.id)

		ImplicitEnvironments = config._implicit_list_like_envs_identifiers \
			+ config._after_elem_implicit_list_like_envs_identifiers
		EnvironmentsContent = config._ignore_lines_envs_content
		EnvironmentsEmptyContent = config._ignore_lines_envs_empty_content
		
		list_elem = self.line_analyzer.patterns.list_elem.name
		enum_elem = self.line_analyzer.patterns.enum_elem.name
		same_line_desc_elem = self.line_analyzer.patterns.DescriptionItems.same_line_desc_elem.name
		next_line_desc_elem = self.line_analyzer.patterns.DescriptionItems.next_line_desc_elem.name
		same_line_desc_elems = self.line_analyzer.patterns.DescriptionItems.same_line_desc_elems.name
		next_line_desc_elems = self.line_analyzer.patterns.DescriptionItems.next_line_desc_elems.name

		table_row = self.line_analyzer.patterns.TableItems.table_row
		table_elems = config._table_elems_identifiers

		informal_reference = self.patterns.InformalReference.name

		section_header = self.line_analyzer.patterns.SectionHeader
		library_header = self.line_analyzer.patterns.LibraryHeader
		paragraph_header = self.line_analyzer.patterns.ParagraphHeader

		env_to_LaTeX_delims = config.environments.env_id_to_LaTeX_delimiters | \
			config.implicit_envs_to_LaTeX_delimiters | \
			config.after_elem_implicit_envs_to_LaTeX_delimiters

		open_envs_lines = []
		close_envs_lines = []
		parsed_prev_line = ""
		parsed_line = ""

		if new_envs:
			for env in new_envs:
				if env in EnvironmentsToParse + ImplicitEnvironments:
					open_envs_lines.append(env_to_LaTeX_delims[env][0])
		open_envs_lines = "%\n" + '\n'.join(open_envs_lines) if open_envs_lines else ""

		if pop_envs:
			if self.line_analyzer.line_state._table_metadata["last_row"]:
				# Uncomment when use `table` environment or other `tabular` wrapper.
				...#close_envs_lines.append("\\end{tabular}")
			for env in pop_envs:
				if env in EnvironmentsToParse + ImplicitEnvironments:
					close_envs_lines.append(env_to_LaTeX_delims[env][1])
		close_envs_lines = '\n'.join(close_envs_lines) + "\n%" if close_envs_lines else ""

		if current_env in CodeEnvironments: 
			line = remove_initial_tabs(line, nest_level)
		else: line = remove_initial_tabs(line)

		# Previous identifier based parsing
		if prev_identifier == library_header.name:
			if line_identifier != library_header.name or len(_library_headers) == 1:
				prev_library_marks = self.line_analyzer.prev_line_state._match_object.group(1)
				if len(_prev_library_headers) == 1:
					library_title = self.line_analyzer.textline_parser.replace_code_special_characters(_prev_library_headers[0])
					library_title = library_format(library_title)
					parsed_prev_line = library(prev_library_marks, library_title)
				else:
					for i, lib_title in enumerate(_prev_library_headers):
						library_title = self.line_analyzer.textline_parser.replace_code_special_characters(lib_title)
						_prev_library_headers[i] = library_format(library_title)
					lib_titles = ", ".join(_prev_library_headers)
					parsed_prev_line = library(prev_library_marks, lib_titles)
			else:
				pass
		else:
			pass

		# Current identifier based parsing
		if line_identifier == EmptyLine: 
			parsed_line = None
		
		elif line_identifier in ignored_lines_identifiers: 
			parsed_line = None
		
		elif line_identifier == TextLine: 
			parsed_line = replace_delimiters(line)
			if prev_identifier == EmptyLine and not open_envs_lines and not close_envs_lines: 
				parsed_line = '\n' + parsed_line
		
		elif line_identifier in Environments: 
			parsed_line = None
		
		elif line_identifier == list_elem:
			elem_content = match_object.group(1)
			elem_content = replace_delimiters(elem_content)
			parsed_line = item(elem_content)
		
		elif line_identifier == same_line_desc_elem:
			same_line_desc = self.line_analyzer.patterns.DescriptionItems.same_line_desc_elem.name
			next_line_desc = self.line_analyzer.patterns.DescriptionItems.next_line_desc_elem.name

			if real_list_item_identifier == same_line_desc:
				elem = match_object.group(1)
				elem = replace_delimiters(elem)
				elem_content = match_object.group(2)
				elem_content = replace_delimiters(elem_content)
				parsed_line = desc_item(elem, elem_content)
			elif real_list_item_identifier == next_line_desc:
				index = match_object.lastindex
				elem = match_object.group(index)
				elem = replace_delimiters(elem)
				parsed_line = desc_item(elem)
			else:
				raise ValueError("Same line item cannot be parsed.")
		
		elif line_identifier == next_line_desc_elem:
			next_line_desc = self.line_analyzer.patterns.DescriptionItems.next_line_desc_elem.name
			same_line_desc = self.line_analyzer.patterns.DescriptionItems.same_line_desc_elem.name
			if real_list_item_identifier == next_line_desc:
				index = match_object.lastindex
				elem = match_object.group(index)
				elem = replace_delimiters(elem)
				parsed_line = desc_item(elem)
			elif real_list_item_identifier == same_line_desc:
				elem = match_object.group(1)
				elem = replace_delimiters(elem)
				elem_content = match_object.group(2)
				elem_content = replace_delimiters(elem_content)
				parsed_line = desc_item_n(elem, elem_content)
			else:
				raise ValueError("Next line item cannot be parsed.")
			
			# TODO: workaround to implement nextline behaviour. Remove when a dedicated nextline environment is implemented.
			if self.line_analyzer.line_state._first_list_item:
				parsed_line = "[nextline_test]%\n" + parsed_line
		
		elif line_identifier == same_line_desc_elems:
			same_line_elems = self.line_analyzer.patterns.DescriptionItems.same_line_desc_elems.name
			next_line_elems = self.line_analyzer.patterns.DescriptionItems.next_line_desc_elems.name
			if real_list_item_identifier == same_line_elems:
				elems = match_object.group(1)
				elems = elems.split(", ")
				for i, _ in enumerate(elems): elems[i] = replace_delimiters(elems[i])
				elem_content = match_object.group(2)
				elem_content = replace_delimiters(elem_content)
				parsed_line = desc_items(elems, elem_content)
			elif real_list_item_identifier == next_line_elems:
				elems = match_object.group(1)
				elems = elems.split(", ")
				for i, _ in enumerate(elems): elems[i] = replace_delimiters(elems[i])
				parsed_line = desc_items(elems)
			else:
				raise ValueError("Same line items cannot be parsed.")
		
		elif line_identifier == next_line_desc_elems:
			next_line_elems = self.line_analyzer.patterns.DescriptionItems.next_line_desc_elems.name
			same_line_elems = self.line_analyzer.patterns.DescriptionItems.same_line_desc_elems.name
			if real_list_item_identifier == next_line_elems:
				elems = match_object.group(1)
				elems = elems.split(", ")
				for i, _ in enumerate(elems): elems[i] = replace_delimiters(elems[i])
				parsed_line = desc_items(elems)
			elif real_list_item_identifier == same_line_elems:
				elems = match_object.group(1)
				elems = elems.split(", ")
				for i, _ in enumerate(elems): elems[i] = replace_delimiters(elems[i])
				elem_content = match_object.group(2)
				elem_content = replace_delimiters(elem_content)
				parsed_line = desc_items_n(elems, elem_content)
			else:
				raise ValueError("Next line items cannot be parsed.")
			
			# TODO: workaround to implement nextline behaviour. Remove when a dedicated nextline environment is implemented.
			if self.line_analyzer.line_state._first_list_item:
				parsed_line = "[nextline_test]%\n" + parsed_line
		
		elif line_identifier == enum_elem:
			if elem_content := match_object.group(1):
				elem_content = replace_delimiters(elem_content)
				parsed_line = item(elem_content)
			else:
				parsed_line = item()
		
		elif line_identifier in self.terms_identifiers:
			simple_term = self.line_analyzer.patterns.Terms.simple_term
			comma_separated_terms = self.line_analyzer.patterns.Terms.comma_separated_terms
			ellipsis_separated_terms = self.line_analyzer.patterns.Terms.ellipsis_separated_terms
			final_ellipsis_terms = self.line_analyzer.patterns.Terms.final_ellipsis_terms
			
			if line_identifier == simple_term.name:
				term = match_object.group(1)
				parsed_line = single_term(term)
			
			elif line_identifier == comma_separated_terms.name:
				terms = match_object.group(1)
				terms = terms.split(", ")
				parsed_line = first_term(terms[0])
				for term in terms[1:-1]: 
					parsed_line += comma_term(term)
				parsed_line += final_term(terms[-1])
			
			elif line_identifier == ellipsis_separated_terms.name:
				terms = match_object.group(1)
				terms = terms.split(", ")
				final_terms = match_object.group(2)
				final_terms = final_terms.split(", ")

				parsed_line = first_term(terms[0])
				for term in terms[1:-1]: 
					parsed_line += comma_term(term)
				
				len_final_terms = len(final_terms)
				if len_final_terms == 1: 
					parsed_line += e_final_term(final_terms[0])
				else:
					parsed_line += e_comma_term_c(final_terms[0])
					for term in final_terms[1:-1]: parsed_line += comma_term(term)
					parsed_line += final_term(final_terms[-1])
			
			elif line_identifier == final_ellipsis_terms.name:
				terms = match_object.group(1)
				terms = terms.split(", ")

				len_terms = len(terms)
				if len_terms == 1: 
					parsed_line += final_ellipsis_term(terms[0])
				else:
					parsed_line = first_term(terms[0])
					for term in terms[1:-1]: parsed_line += comma_term(term)
					parsed_line += final_ellipsis_term(terms[-1])
		
		elif line_identifier in self.action_error_bp_identifiers:
			action_error_bp = match_object.group(1)
			action_error_bp = replace_delimiters(action_error_bp)

			parsed_line = act_err_bp(action_error_bp)

		elif line_identifier == section_header.name:
			section_marks = match_object.group(1)
			section_title = match_object.group(2)
			section_title = replace_delimiters(section_title)

			parsed_line = section(section_marks, section_title)
		
		elif line_identifier == library_header.name:
			parsed_line = None
		
		elif line_identifier == paragraph_header.name:
			paragraph_marks = match_object.group(1)
			paragraph_title = match_object.group(2)
			paragraph_title = replace_delimiters(paragraph_title)

			parsed_line = paragraph(paragraph_marks, paragraph_title)
		
		elif line_identifier in table_elems:
			num_columns = self.line_analyzer.line_state._table_metadata["num_columns"]

			if self.line_analyzer.line_state._table_metadata["first_row"]:
				# Uncomment when use `table` environment or other `tabular` wrapper.
				#open_envs_lines += "\n\\begin{{tabular}}{{@{{}}{cols_spec}@{{}}}}".format(cols_spec = num_columns * 'l')
				open_envs_lines += "{{@{{}}{cols_spec}@{{}}}}".format(cols_spec = num_columns * 'l')

			if line_identifier == table_row.name:
				row_cells = match_object.group(1)
				row_cells = row_cells.split('\t')
				row_cells = [i for i in row_cells if i != ""]

				for cell in row_cells[:-1]:
					parsed_line += replace_delimiters(cell) + " & "
				parsed_line += replace_delimiters(row_cells[-1])

				if num_columns > len(row_cells):
					for _ in range(num_columns - len(row_cells)):
						parsed_line += " & "

				parsed_line += " \\\\"
			else:
				row_cell = match_object.group(1)
				parsed_line = replace_delimiters(row_cell)

				if num_columns > 1:
					for _ in range(num_columns - 1):
						parsed_line += " & "

				parsed_line += " \\\\"
		
		elif line_identifier == informal_reference:
			if config.parse_informal_references:
				inf_ref_content = replace_delimiters(match_object.group(1))
				parsed_line = informal_ref(inf_ref_content)
			else: parsed_line = None
		
		elif line_identifier in self.line_comments_identifiers:
			if line_identifier == self.patterns.FullLineComment.name:
				if parse_line_comments: parsed_line = "% " + match_object.group(1)
				else: parsed_line = None

		elif line_identifier in self.block_comments_identifiers:
			if not parse_block_comments: parsed_line = None
			elif line_identifier == config.block_comment_content_identifier:
				parsed_line = line
			elif line_identifier == self.patterns.OpenBlockComment.name:
				comment_content = match_object.group(1)
				if comment_content: comment_content = ' ' + comment_content
				parsed_line = config.special_environments.BlockComment.LaTeX_delimiters[0] + comment_content
			elif line_identifier == self.patterns.CloseBlockComment.name:
				comment_content = match_object.group(1)
				if comment_content: comment_content = comment_content + ' '
				parsed_line = comment_content + config.special_environments.BlockComment.LaTeX_delimiters[1]

		elif line_identifier in EnvironmentsContent:
			if prev_identifier in EnvironmentsEmptyContent:
				line = '\n' + line
			parsed_line = line
		elif line_identifier in EnvironmentsEmptyContent:
			parsed_line = None

		else:
			# TODO: turn into WARN log.
			#print(f"Warning: No parsing rules defined for line identifier '{line_identifier}'. Line returned unchanged.")
			parsed_line = line

		if not parsed_line and (open_envs_lines or close_envs_lines or parsed_prev_line): parsed_line = ""
		if parsed_line and open_envs_lines: open_envs_lines += '\n'
		if parsed_line and close_envs_lines: close_envs_lines += '\n'

		return parsed_prev_line + close_envs_lines + open_envs_lines + parsed_line if parsed_line or parsed_line == "" else None

	# TODO: split this function in two for `output_log`.
	def parse_file(self, 
		input_file: str = None, 
		output_file: str =  None, 
		output_log: str = None, 
		limit: int = None
	):
		self.reset()

		if not input_file: input_file = self.input_file
		if not output_file: output_file = self.output_file
		if not output_log: output_log = self.output_line_comp_log

		if not input_file: input_file = config.txt_input_file
		if not output_file: output_file = config.output_dir + config.content_file_name + ".tex"

		with open(input_file, 'r') as input_file_stream:
			if not os.path.exists(config.output_dir): os.makedirs(config.output_dir)
			output_file_stream = open(output_file, 'w', buffering = 1)

			if not output_log: output_log_stream = None
			else: output_log_stream = open(output_log, 'w', buffering = 1)

			print("Parsing file:", input_file)

			lines = input_file_stream.read().splitlines()
			i = 0
			for line in lines[:limit]: 
				i += 1
				try:
					line_state = self.line_analyzer.update_line_state(line)
					parsed_line = self.parse_line(line)
				except Exception as e:
					raise ValueError("Error while parsing line {}: {}".format(i, e))

				inline_delimiters_stack = line_state.inline_delimiters_stack
				if parsed_line or parsed_line == "": output_file_stream.write(parsed_line + '\n')
				if output_log_stream: 
					log_parsed_line = parsed_line.replace('\n', '\n' + ' '*8) if parsed_line or parsed_line == "" else ""
					# TODO: option for only including log lines with changes.
					output_log_stream.write(str(i) + ' ' + str(inline_delimiters_stack) + '\n')
					output_log_stream.write("[ TXT ] " + line + '\n')
					output_log_stream.write("[LaTeX] " + log_parsed_line + "\n\n")
			
			if self.line_analyzer.line_state.environment_stack:
				closing_line = self.close_last_line_pending_envs(self.line_analyzer.line_state.environment_stack)
				output_file_stream.write(closing_line + '\n')

			if output_file_stream: output_file_stream.close()
			if output_log_stream: output_log_stream.close()

			print("File parsing completed")

	def close_last_line_pending_envs(self, pending_envs: list) -> str:
		pending_envs.reverse()
		LaTeX = config.environments.LaTeX.id
		Environments = config.environments.ids
		ImplicitEnvironments = config._implicit_list_like_envs_identifiers \
			+ config._after_elem_implicit_list_like_envs_identifiers
		# TODO: turn `EnvironmentsToParse` into config variable?
		EnvironmentsToParse = Environments.copy()
		EnvironmentsToParse.remove(LaTeX)
		env_to_LaTeX_delims = config.environments.env_id_to_LaTeX_delimiters | \
			config.implicit_envs_to_LaTeX_delimiters | \
			config.after_elem_implicit_envs_to_LaTeX_delimiters
		if not config.parse_block_comments: EnvironmentsToParse.remove(config.environments.Comment.id)
		close_envs_lines = []
		
		if self.line_analyzer.line_state._table_metadata["last_row"]:
			# Uncomment when use `table` environment or other `tabular` wrapper.
			...#close_envs_lines.append("\\end{tabular}")
		for env in pending_envs:
			if env in EnvironmentsToParse + ImplicitEnvironments:
				close_envs_lines.append(env_to_LaTeX_delims[env][1])
		close_envs_lines = '\n'.join(close_envs_lines) + "\n%" if close_envs_lines else ""

		return close_envs_lines

	def reset(self): 
		self.line_analyzer = LineAnalyzer(
			line_state = LineState(), 
			prev_line_state = LineState()
		)


def section(section_marks, section_title):
	return f"\\{config.sections_map.get(section_marks, config.sections[-1])}{{{section_title}}}"
def library(library_marks, library_title):
	return f"\\{config.library_sections_map.get(library_marks, config.sections[-1])}{{{library_title}}}"
def paragraph(paragraph_marks, paragraph_title):
	return f"\\{config.paragraph_map.get(paragraph_marks, config.paragraphs[-1])}{{{paragraph_title}}}"
def library_format(library_title):
	return f"{config._patterns.inline_delimiters.code.LaTeX_protect[0]}{library_title}{config._patterns.inline_delimiters.code.LaTeX_protect[1]}"

def item(content = ""):
	return f"\\item {content}"
def desc_item(label, content = ""):
	return f"\\item[{label}] {content}"
def desc_item_n(label, content = ""):
	return f"\\item[{label}]\n{content}"
def desc_items(elems: list, content: str = ""):
	return f"\\item[{", ".join(elems)}] {content}"
def desc_items_n(elems: list, content: str = ""):
	return f"\\item[{", ".join(elems)}]\n{content}"

def single_term(term):
	term = f"{{{term}}}" if '{' not in term and '}' not in term else f"!{term}!"
	return f"{config.simple_term_command}{term}"
def first_term(term):
	term = f"{{{term}}}" if '{' not in term and '}' not in term else f"!{term}!"
	return f"{config.first_term_command}{term}, "
def first_term_c(term):
	term = f"{{{term}}}" if '{' not in term and '}' not in term else f"!{term}!"
	return f"{config.first_term_command}{term}, "
def comma_term(term):
	term = f"{{{term}}}" if '{' not in term and '}' not in term else f"!{term}!"
	return f"{config.comma_term_command}{term}, "
def comma_term_c(term):
	term = f"{{{term}}}" if '{' not in term and '}' not in term else f"!{term}!"
	return f"{config.comma_term_command}{term}, "
def e_comma_term_c(term):
	term = f"{{{term}}}" if '{' not in term and '}' not in term else f"!{term}!"
	return f"..., {config.comma_term_command}{term}, "
def final_term(term):
	term = f"{{{term}}}" if '{' not in term and '}' not in term else f"!{term}!"
	return f"{config.final_term_command}{term}"
def e_final_term(term):
	term = f"{{{term}}}" if '{' not in term and '}' not in term else f"!{term}!"
	return f"..., {config.final_term_command}{term}"
def final_ellipsis_term(term):
	term = f"{{{term}}}" if '{' not in term and '}' not in term else f"!{term}!"
	return f"{config.final_ellipsis_term_command}{term}"

def act_err_bp(action_error_bp):
	return f"{config.action_error_best_practice_command}{{{action_error_bp}}}"

def informal_ref(informal_reference_content):
	return f"{config.informal_reference_command}{{{informal_reference_content}}}"