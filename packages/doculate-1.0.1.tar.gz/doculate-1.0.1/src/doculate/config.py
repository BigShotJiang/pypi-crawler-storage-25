# TODO: ensure all `config` members are read only.
# TODO: use `fields()` (or `vars()`), `.name`, `getattr()` and `setattr()` instead `eval()` and `exec()`.

import json
import re

from .config_defaults import _ConfigDefaults
from .patterns import Patterns
from .environments import Environments, _SpecialEnvironments
from .delimiters import Delimiters, InlineDelimiters
from .utils import get_file_name, file_exists

from copy import deepcopy


class Config(_ConfigDefaults):

	def __init__(self, config_file: str = None):
		self.environments = deepcopy(Environments())
		self.special_environments = deepcopy(_SpecialEnvironments())

		self.environments_ids = self.environments._get_environments_ids()
		self.environments_lower_ids_to_ids = {id.lower(): id for id in self.environments_ids}

		self.config_files_opened = []
		json_config = self.import_json_config(json_file = config_file)

		# TODO: improve.
		if json_config:
			if json_config.get("default_inline_normal_delimiter"): self.default_inline_normal_delimiter = json_config["default_inline_normal_delimiter"]
			if json_config.get("default_inline_no_nesting_delimiter"): self.default_inline_no_nesting_delimiter = json_config["default_inline_no_nesting_delimiter"]
			if self.is_list_of_str(json_config.get("default_unambiguous_normal_delimiters")) \
			and len(json_config["default_unambiguous_normal_delimiters"]) == 2:
				self.default_unambiguous_normal_delimiters = json_config["default_unambiguous_normal_delimiters"]
			if self.is_list_of_str(json_config.get("block_comment_delimiters")) \
			and len(json_config["block_comment_delimiters"]) == 2:
				self.block_comment_delimiters = json_config["block_comment_delimiters"]

		self.delimiters = deepcopy(InlineDelimiters(
			self.default_inline_normal_delimiter, 
			self.default_inline_no_nesting_delimiter, 
			self.default_unambiguous_normal_delimiters, 
			self.block_comment_delimiters
		))

		self.delimiters_ids = self.delimiters._get_delimiters_ids()
		self.delimiters_lower_ids_to_ids = {id.lower(): id for id in self.delimiters_ids}

		if json_config: self.set_json_config(json_config)

		# TODO: change this when change unnecessary default class in patterns.
		self._patterns = Patterns(
			section_marks_unit = self.section_marks_unit, 
			header_mark = self.header_mark, 
			library_mark = self.library_mark, 
			paragraph_mark = self.paragraph_mark, 
			environments = self.environments, 
			special_environments = self.special_environments, 
			term_mark = self.term_mark, 
			action_error_best_practice_mark = self.action_error_best_practice_mark, 
			list_mark = self.list_mark, 
			description_mark = self.description_mark, 
			line_comment_symbol = self.line_comment_symbol, 
			block_comment_delimiters = [re.escape(i) for i in self.block_comment_delimiters], 
			inline_delimiters = self.delimiters, 
			colon_rule_when_no_identifiers = self.colon_rule_when_no_identifiers, 
			default_list_element_when_no_identifiers = self.default_list_element_when_no_identifiers, 
			informal_reference_mark = self.informal_reference_mark
		)

		if self.output_dir[-1] != '/': 
			self.output_dir = self.output_dir + '/'
		if self.output_line_state_log_dir[-1] != '/': 
			self.output_line_state_log_dir = self.output_line_state_log_dir + '/'
		
		# TODO: move this to preamble_string.py with named colors.
		for env in self.default_code_environments_title_colors:
			if not self.code_environments_title_colors.get(env):
				self.code_environments_title_colors[env] = self.default_code_title_color 
		
		# TODO: rename category, since math, table, comment and LaTeX seems not fit at first glance.
		self._code_environments_identifiers = [
			self.environments.Sintax.id, 
			self.environments.CodeSintax.id, 
			self.environments.Example.id, 
			self.environments.Examples.id, 
			self.environments.AntiExample.id, 
			self.environments.AntiExamples.id, 
			self.environments.Code.id, 
			self.environments.CodeExample.id, 
			self.environments.CodeAntiExample.id, 
			self.environments.CommandsCode.id, 
			self.environments.Configuration.id, 
			self.environments.Class.id, 
			self.environments.Function.id, 
			self.environments.Procedure.id, 
			self.environments.Definition.id, 
			self.environments.Definitions.id, 
			self.environments.Math.id, 
			self.environments.MathExpressions.id, 
			self.environments.AlignedMathExpressions.id, 
			self.environments.Table.id, 	# TODO: is correct to place it here?
			self.environments.LaTeX.id, 
			self.environments.Comment.id
		]

		self._itemize_like_envs_identifiers = [self.environments.List.id]
		self._enumerate_like_envs_identifiers = [self.environments.Enumerate.id]
		self._description_like_envs_identifiers = [
			self.environments.Description.id, 
			self.environments.Options.id, 
			self.environments.Values.id, 
			self.environments.Arguments.id, 
			self.environments.Attributes.id, 
			self.environments.Parameters.id, 
			self.environments.Classes.id, 
			self.environments.Functions.id, 
			self.environments.Procedures.id, 
			self.environments.Members.id, 
			self.environments.Methods.id, 
			self.environments.Fields.id, 
			self.environments.Commands.id, 
			self.environments.Subcommands.id, 
			self.environments.ConfigurationOptions.id
		]
		self._table_like_envs_identifiers = [self.environments.Table.id]

		self._no_implicit_itemize_like_envs_identifiers = self._itemize_like_envs_identifiers.copy()
		self._no_implicit_enumerate_like_envs_identifiers = self._enumerate_like_envs_identifiers.copy()
		self._no_implicit_description_like_envs_identifiers = self._description_like_envs_identifiers.copy()
		self._no_implicit_table_like_envs_identifiers = self._table_like_envs_identifiers.copy()

		self._itemize_and_description_like_envs_identifiers = \
			self._itemize_like_envs_identifiers + \
			self._description_like_envs_identifiers

		self._list_like_envs_identifiers = \
			self._itemize_like_envs_identifiers + \
			self._enumerate_like_envs_identifiers + \
			self._description_like_envs_identifiers + \
			self._table_like_envs_identifiers

		self._elem_list_like_identifiers = [
			self._patterns.list_elem.name, 
			self._patterns.enum_elem.name, 
		] + self._patterns.get_patterns_names(self._patterns.DescriptionItems) \
		+ self._patterns.get_patterns_names(self._patterns.TableItems)

		self._itemize_and_description_elem_list_like_identifiers = \
			[self._patterns.list_elem.name] + \
			self._patterns.get_patterns_names(self._patterns.DescriptionItems)

		self._table_elems_identifiers = self._patterns.get_patterns_names(self._patterns.TableItems)

		self._implicit_list_like_envs_identifiers = [self._implicit_env_prefix + i for i in self._list_like_envs_identifiers]
		self._after_elem_implicit_list_like_envs_identifiers = [self._implicit_after_elem_env_prefix + i for i in self._implicit_list_like_envs_identifiers]
		self.append_implcit_and_after_elem_envs(self._itemize_like_envs_identifiers)
		self.append_implcit_and_after_elem_envs(self._enumerate_like_envs_identifiers)
		self.append_implcit_and_after_elem_envs(self._description_like_envs_identifiers)
		self.append_implcit_and_after_elem_envs(self._table_like_envs_identifiers)
		self.append_implcit_and_after_elem_envs(self._itemize_and_description_like_envs_identifiers)

		EmptyLine = self._patterns.EmptyLine.name
		EnvironmentsIds = self.environments.ids
		SectionHeader = self._patterns.SectionHeader.name
		ParagraphHeader = self._patterns.ParagraphHeader.name
		LibraryHeader = self._patterns.LibraryHeader.name
		ActionErrorBestPractice = self._patterns.ActionErrorBestPractice.name
		CloseBlockComment = self._patterns.CloseBlockComment.name
		Terms = self._patterns.get_patterns_names(self._patterns.Terms)

		self.empty_line_identifiers = [
			self._patterns.EmptyLine.name, 
			self._ignored_line_identifier_prefix + self._patterns.EmptyLine.name
		]

		ignored_line_prefix = self._ignored_line_identifier_prefix

		self.implicit_envs_to_LaTeX_delimiters = {}
		self.after_elem_implicit_envs_to_LaTeX_delimiters = {}
		
		for env_id in self._list_like_envs_identifiers: 
			implicit_env_id = self._implicit_env_prefix + env_id
			after_elem_implicit_env_id = self._implicit_after_elem_env_prefix + implicit_env_id

			self.implicit_envs_to_LaTeX_delimiters[implicit_env_id] = \
				self.environments.env_id_to_LaTeX_delimiters[env_id]
			self.after_elem_implicit_envs_to_LaTeX_delimiters[after_elem_implicit_env_id] = \
				self.environments.env_id_to_LaTeX_delimiters[env_id]

		self._identifiers_that_increment_env_stack = [
			self._patterns.StartEnvironment.name, 
			self._patterns.list_elem.name, 
			self._patterns.enum_elem.name, 
			self.special_environments.BlockComment.id, 
			self._patterns.ActionErrorBestPractice.name
		] + self._patterns.get_patterns_names(self._patterns.DescriptionItems) \
			+ self.environments.ids \
			+ self._implicit_list_like_envs_identifiers \
			+ self._after_elem_implicit_list_like_envs_identifiers \
			+ [self.initial_indent_pseudo_env] \
			+ Terms

		self._ignore_lines_envs = [
			self.environments.CodeExample.id, 
			self.environments.CodeAntiExample.id, 
			self.environments.Code.id, 
			self.environments.CodeSintax.id, 
			self.environments.CommandsCode.id, 
			self.environments.Configuration.id, 
			self.environments.Class.id, 
			self.environments.Function.id, 
			self.environments.Procedure.id, 
			self.environments.Definition.id, 
			self.environments.Definitions.id, 
			self.environments.Math.id, 
			self.environments.MathExpressions.id, 
			self.environments.AlignedMathExpressions.id, 
			self.environments.LaTeX.id, 
			self.environments.Comment.id
		]
		if self.ignore_sintax_initial_tabs: 
			self._ignore_lines_envs.append(self.environments.Sintax.id)
		if self.ignore_example_initial_tabs: 
			self._ignore_lines_envs.append(self.environments.Example.id)
			self._ignore_lines_envs.append(self.environments.Examples.id)
			self._ignore_lines_envs.append(self.environments.AntiExample.id)
			self._ignore_lines_envs.append(self.environments.AntiExamples.id)

		_content_suffix = self._env_content_identifier_suffix
		_empty_content_suffix = self._env_content_empty_line_identifier_suffix

		# TODO: change first "ignore" prefix to "code" or something else.
		self._ignore_lines_envs_content = [i.lower() + _content_suffix for i in self._ignore_lines_envs]
		self._ignore_lines_envs_empty_content = [i.lower() + _empty_content_suffix for i in self._ignore_lines_envs]
		self._ignore_ignored_lines_envs_content = [ignored_line_prefix + i for i in self._ignore_lines_envs_empty_content]

		self.ignore_empty_line_after_identifiers = EnvironmentsIds + [ 
			SectionHeader, 
			ParagraphHeader, 
			LibraryHeader, 
			ActionErrorBestPractice, 
			EmptyLine, 
			ignored_line_prefix + EmptyLine, 
			CloseBlockComment
		] + Terms
		
		self._ignored_lines_identifiers = [ignored_line_prefix + EmptyLine] \
			+ self._ignore_ignored_lines_envs_content
		if not self.parse_block_comments: self._ignored_lines_identifiers.append(self.environments.Comment.id.lower() + _content_suffix)

		self._ignore_tabs_patterns = [		# TODO: change confusing name.
			self._patterns.EmptyLine.name, 
			self._patterns.FullLineComment.name, 
			ignored_line_prefix + EmptyLine
		]

		self._open_block_identifiers = [
			self._patterns.OpenBlockComment.name
		]

		self._open_ignored_block_identifiers = [
			self._patterns.OpenBlockComment.name
		]

		self._ignore_lines_blocks = [
			self.special_environments.BlockComment.id
		]

		self._ignore_lines_blocks_content = [i.lower() + _content_suffix for i in self._ignore_lines_blocks]

		self._close_block_identifiers = [
			self._patterns.CloseBlockComment.name
		]

		self.block_comment_content_identifier = self.special_environments.BlockComment.id.lower() + _content_suffix

		self._line_comments_identifiers = [
			self._patterns.FullLineComment.name
		]

		self._block_comments_identifiers = [
			self._patterns.OpenBlockComment.name, 
			self.block_comment_content_identifier, 
			self._patterns.CloseBlockComment.name
		]

		self._comments_identifiers = self._line_comments_identifiers + self._block_comments_identifiers

		extra_LaTeX_special_replacements = {}
		replacements_values = set(self.LaTeX_special_replacements.values())
		for k, v in self.LaTeX_special_replacements.items(): 
			all_delim_list = self.delimiters._get_all_single_delimiter_list()
			# If a special replacement is also a delimiter, the user must escape it.
			if k not in all_delim_list: 
				extra_LaTeX_special_replacements[k] = v
				extra_LaTeX_special_replacements["\\" + k] = "\\" + k
			# Scaped delimiters are considered as normal text.
			else:
				if "\\" + k not in replacements_values:
					extra_LaTeX_special_replacements["\\" + k] = k
				else: 
					extra_LaTeX_special_replacements["\\" + k] = "\\" + k
		self.LaTeX_special_replacements = extra_LaTeX_special_replacements
		keys_list = sorted(self.LaTeX_special_replacements.keys(), key = lambda x: -len(x))
		self.special_replacements_keys_string = self.delimiters.make_delimiters_string(keys_list)

		keys_list = sorted(self.LaTeX_code_special_replacements.keys(), key = lambda x: -len(x))
		self.code_special_replacements_keys_string = self.delimiters.make_replacements_string(keys_list)

		keys_list = sorted(self.LaTeX_url_special_replacements.keys(), key = lambda x: -len(x))
		self.url_special_replacements_keys_string = self.delimiters.make_replacements_string(keys_list)

		self.sections_map = {}
		root_section_index = self.sections.index(self.root_section)
		for i in range(root_section_index, len(self.sections)): 
			self.sections_map[self.header_mark*(i - root_section_index + 1)] = self.sections[i]
		
		self.root_library_section = self.root_section
		self.library_sections_map = {}
		root_library_section_index = self.sections.index(self.root_library_section)
		for i in range(root_library_section_index, len(self.sections)): 
			self.library_sections_map[self.library_mark*(i - root_library_section_index + 1)] = self.sections[i]
		
		self.paragraph_map = {}
		for i in range(len(self.paragraphs)): 
			self.paragraph_map[self.paragraph_mark*(i + 7)] = self.paragraphs[i]

		self.code_open_delims = self.delimiters.get_no_nesting_open_delims_class(self.delimiters.code_delimiters)
		self.verb_open_delims = [
			self.delimiters.other_delimiters.file.no_nesting.open, 
			self.delimiters.other_delimiters.directory.no_nesting.open, 
			self.delimiters.other_delimiters.keyboard.no_nesting.open
		]

		self.protect_section_delims = self.code_open_delims + self.verb_open_delims

		self.content_file_name = get_file_name(self.txt_input_file) if self.txt_input_file else None
		self.content_input_tex_file = self.content_file_name + ".tex" if self.content_file_name else None

		if not self.title and self.content_file_name: self.title = self.content_file_name
		if not self.author: self.author = ""
		if not self.date: self.date = ""

		if not self.main_programming_language and self.use_file_name_if_no_main_language: 
			self.main_programming_language = self.content_file_name

		if not self.main_programming_language \
		or self.main_programming_language.lower() in ["plaintext", "plain", "plain text", "none"]: 
			self.main_programming_language = ""
	
	def append_implcit_and_after_elem_envs(self, envs_list): 
		envs_list += [self._implicit_env_prefix + i for i in envs_list] + \
			[self._implicit_after_elem_env_prefix + self._implicit_env_prefix + i for i in envs_list]

	def import_json_config(self, json_file: str = None):
		if not json_file: 
			for file_name in ["conf", "config", "configuration", "doculate", "docuLaTe"]:
				if file_exists(file_name): json_file = file_name
				if file_exists(file_name + ".json"): json_file = file_name + ".json"
		
		if not json_file: return None

		with open(json_file, "r") as j_file:
			json_config = json.load(j_file)

		self.config_files_opened.append(json_file)
		
		if json_config.get("config_file") and json_config["config_file"] not in self.config_files_opened:
			json_config = self.import_json_config(json_config["config_file"])
		
		return json_config

	def valid_environment_config_fields(self, env_config):
		valid_fields = []

		if isinstance(env_config, dict):
			values = env_config.get("values")
			add_values = env_config.get("add_values")

			if not values and not add_values: return valid_fields

			#if isinstance(values, str) and len(values) > 0: valid_fields.append("values")
			#if isinstance(add_values, str) and len(add_values) > 0: valid_fields.append("add_values")
			
			if self.is_list_of_str(values): valid_fields.append("values")
			if self.is_list_of_str(add_values): valid_fields.append("add_values")
	
		return valid_fields

	def set_environment_config_fields(self, env, env_config, valid_fields):
		for field in valid_fields:
			if field[:4] != "add_": 
				exec(f"self.environments.{env}.{field} = {env_config[field]}")
			else:
				exec(f"self.environments.{env}.{field[4:]} += {env_config[field]}")

	def valid_delimiter_config_fields(self, delim_config):
		valid_fields = []

		if isinstance(delim_config, dict):
			signature_constructor = delim_config.get("signature_constructor")
			add_signature_constructor = delim_config.get("add_signature_constructor")
			normal = delim_config.get("normal")
			add_normal = delim_config.get("add_normal")
			no_nesting = delim_config.get("no_nesting")
			add_no_nesting = delim_config.get("add_no_nesting")

			if not any([
				signature_constructor, 
				add_signature_constructor, 
				normal, 
				add_normal, 
				no_nesting, 
				add_no_nesting
			]): 
				return valid_fields

			if (isinstance(signature_constructor, str) and len(signature_constructor) > 0) \
			or self.is_list_of_str(signature_constructor): 
				valid_fields.append("signature_constructor")
			if (isinstance(add_signature_constructor, str) and len(add_signature_constructor) > 0) \
			or self.is_list_of_str(add_signature_constructor): 
				valid_fields.append("add_signature_constructor")

			if (self.is_list_of_str(normal) and len(normal) == 2) \
			or self.is_list_of_delims(normal):
				valid_fields.append("normal")
			if (self.is_list_of_str(add_normal) and len(add_normal) == 2) \
			or self.is_list_of_delims(add_normal): 
				valid_fields.append("add_normal")
			if (self.is_list_of_str(no_nesting) and len(no_nesting) == 2) \
			or self.is_list_of_delims(no_nesting):
				valid_fields.append("no_nesting")
			if (self.is_list_of_str(add_no_nesting) and len(add_no_nesting) == 2) \
			or self.is_list_of_delims(add_no_nesting):
				valid_fields.append("add_no_nesting")
	
		return valid_fields

	def set_delimiters_config_fields(self, delim, delim_config, valid_fields):
		for field in valid_fields:
			if field[:4] != "add_": 
				if isinstance(delim_config[field], str):
					exec(f"self.delimiters.{delim}.{field} = \"{delim_config[field]}\"")
				else:
					if isinstance(delim_config[field][0], str):
						setattr(eval(f"self.delimiters.{delim}"), field, Delimiters(*delim_config[field]))
					elif isinstance(delim_config[field][0], list):
						for i, delims in enumerate(delim_config[field]): 
							delim_config[field][i] = Delimiters(*delims)
						setattr(eval(f"self.delimiters.{delim}"), field, delim_config[field])
			elif field == "add_signature_constructor":
				_field = field[4:]
				if not eval(f"self.delimiters.{delim}.{_field}"):
					if isinstance(delim_config[field], str):
						exec(f"self.delimiters.{delim}.{_field} = \"{delim_config[field]}\"")
					else:
						exec(f"self.delimiters.{delim}.{_field} = {delim_config[field]}")
				elif isinstance(delim_config[field], str) \
				and isinstance(eval(f"self.delimiters.{delim}.{_field}"), str):
					exec(f"self.delimiters.{delim}.{_field} = [self.delimiters.{delim}.{_field}, \"{delim_config[field]}\"]")
				elif isinstance(delim_config[field], list) \
				and isinstance(eval(f"self.delimiters.{delim}.{_field}"), str):
					l = delim_config[field].copy()
					exec(f"l.append(self.delimiters.{delim}.{_field})")
					exec(f"self.delimiters.{delim}.{_field} = l")
				elif isinstance(delim_config[field], str) \
				and isinstance(eval(f"self.delimiters.{delim}.{_field}"), list):
					exec(f"self.delimiters.{delim}.{_field}.append(\"{delim_config[field]}\")")
				elif isinstance(delim_config[field], list) \
				and isinstance(eval(f"self.delimiters.{delim}.{_field}"), list):
					exec(f"self.delimiters.{delim}.{_field}.extend(delim_config[\"{field}\"])")
				else:
					raise ValueError(f"Invalid {delim} delimiter json configuration field: {field}")
			else:
				_field = field[4:]
				if isinstance(delim_config[field][0], str) \
				and isinstance(eval(f"self.delimiters.{delim}.{_field}[0]"), str):
					setattr(eval(f"self.delimiters.{delim}"), _field, [eval(f"self.delimiters.{delim}.{_field}"), Delimiters(*delim_config[field])])
				elif isinstance(delim_config[field][0], list) \
				and isinstance(eval(f"self.delimiters.{delim}.{_field}[0]"), str):
					for i, delims in enumerate(delim_config[field]): delim_config[field][i] = Delimiters(*delims)
					l = delim_config[field].copy()
					exec(f"l.append(self.delimiters.{delim}.{_field})")
					exec(f"self.delimiters.{delim}.{_field} = l")
				elif isinstance(delim_config[field][0], str) \
				and isinstance(eval(f"self.delimiters.{delim}.{_field}[0]"), list):
					exec(f"self.delimiters.{delim}.{_field}.append(Delimiters(*delim_config[\"{field}\"]))")
				elif isinstance(delim_config[field][0], list) \
				and isinstance(eval(f"self.delimiters.{delim}.{_field}[0]"), list):
					for i, delims in enumerate(delim_config[field]): delim_config[field][i] = Delimiters(*delims)
					exec(f"self.delimiters.{delim}.{_field}.extend(delim_config[\"{field}\"])")
				else:
					raise ValueError(f"Invalid {delim} delimiter json configuration field: {field}")

	def is_list_of_str(self, l):
		if isinstance(l, list) and len(l) > 0 \
		and all([isinstance(i, str) and len(i) > 0 for i in l]): 
			result = True
		else: result = False
		
		return result

	def is_list_of_delims(self, l):
		if isinstance(l, list) and len(l) > 0 \
		and all([isinstance(i, list) and len(i) == 2 for i in l]) \
		and all([isinstance(j, str) and len(j) > 0 for i in l for j in i]):
			result = True
		else: result = False
		
		return result
	
	def is_dict_of_str_to_str(self, d):
		if isinstance(d, dict) and len(d) > 0 \
		and all([isinstance(i, str) and len(i) > 0 for i in d]) \
		and all([isinstance(i, str) and len(i) > 0 for i in d.values()]):
			result = True
		else: result = False

		return result

	def is_dict_of_str_to_list_of_str(self, d):
		if isinstance(d, dict) and len(d) > 0 \
		and all([isinstance(i, str) and len(i) > 0 for i in d]) \
		and all([self.is_list_of_str(i) for i in d.values()]):
			result = True
		else: result = False

		return result

	def is_dict_of_dicts(self, d):
		if isinstance(d, dict) and len(d) > 0 \
		and all([isinstance(i, dict) and len(i) > 0 for i in d]):
			result = True
		else: result = False

		return result

	def set_json_config(self, json_config):
		json_configs_types = self.json_configs_types
		
		for conf in json_config:
			if json_configs_types.get(conf) and isinstance(json_config[conf], json_configs_types[conf]):
				
				if isinstance(json_config[conf], str) and json_config[conf]:
					exec(f"self.{conf} = \"{json_config[conf].replace("\"", "\\\"")}\"")
				elif isinstance(json_config[conf], bool) and json_config[conf]:
					exec(f"self.{conf} = {json_config[conf]}")
				
				elif self.is_list_of_str(json_config[conf]):
					exec(f"self.{conf} = {json_config[conf]}")
				
				elif self.is_dict_of_str_to_str(json_config[conf]):
					if conf[:4] != "add_": 
						exec(f"self.{conf} = {json_config[conf]}")
					else:
						exec(f"self.{conf[4:]} = self.{conf[4:]}.copy(); self.{conf[4:]}.update({json_config[conf]})")
				
				elif conf == "environments":
					envs_conf = json_config[conf]
					lower_env_to_conf = {id.lower(): envs_conf[id] for id in envs_conf.keys()}
					valid_envs = set(lower_env_to_conf.keys()) & set(self.environments_lower_ids_to_ids.keys())
					
					for env_id in valid_envs:
						if valid_fields := self.valid_environment_config_fields(lower_env_to_conf[env_id]):
							self.set_environment_config_fields(
								self.environments_lower_ids_to_ids[env_id], 
								lower_env_to_conf[env_id], 
								valid_fields
							)
				elif conf == "delimiters":
					delims_conf = json_config[conf]
					lower_delim_to_conf = {id.lower(): delims_conf[id] for id in delims_conf.keys()}
					valid_delims = set(lower_delim_to_conf.keys()) & set(self.delimiters_lower_ids_to_ids.keys())
					
					for delim_id in valid_delims:
						if valid_fields := self.valid_delimiter_config_fields(lower_delim_to_conf[delim_id]):
							self.set_delimiters_config_fields(
								self.delimiters_lower_ids_to_ids[delim_id], 
								lower_delim_to_conf[delim_id], 
								valid_fields
							)

	json_configs_types = {
		"config_file": str, 
		"txt_input_file": str, 
		"output_dir": str, 
		"output_line_state_log_dir": str, 

		"title": str, 
		"author": str, 
		"date": str, 

		"main_font_size": str, 

		"page_left_margin": str, 
		"page_right_margin": str, 
		"page_top_margin": str, 
		"page_bottom_margin": str, 

		"front_page_left_margin": str, 
		"front_page_right_margin": str, 
		"front_page_top_margin": str, 
		"front_page_bottom_margin": str, 

		"title_font_size": str, 
		
		"tableofcontents_name": str, 
		
		"root_section": str, 

		"header_mark": str, 
		"library_mark": str, 
		"paragraph_mark": str, 
		"section_marks_unit": str, 
		"term_mark": str, 
		"action_error_best_practice_mark": str, 
		"list_mark": str, 
		"description_mark": str, 
		"informal_reference_mark": str, 
		"block_comment_delimiters": list, 
		"line_comment_symbol": str, 

		"default_inline_normal_delimiter": str, 
		"default_inline_no_nesting_delimiter": str, 
		"default_unambiguous_normal_delimiters": list, 

		"LaTeX_special_replacements": dict, 
		"LaTeX_code_special_replacements": dict, 
		"LaTeX_url_special_replacements": dict, 
		"add_LaTeX_special_replacements": dict, 
		"add_LaTeX_code_special_replacements": dict, 
		"add_LaTeX_url_special_replacements": dict, 
		
		"colon_rule_when_no_identifiers": bool, 
		"default_list_element_when_no_identifiers": bool, 

		"parse_informal_references": bool, 
		"parse_block_comments": bool, 
		"parse_line_comments": bool, 
		"parse_inline_line_comments": bool, 

		"code_background_color": str, 
		"code_title_color": str, 
		"code_frame_color": str, 
		"code_environments_title_colors": dict, 
		"add_code_environments_title_colors": dict, 

		"code_environments_font_size": str, 
		"header_pre_chapter_mark": str, 
		"header_pos_chapter_mark": str, 
		"front_page_file_name": str, 
		"preamble_file_name": str, 

		"main_programming_language": str, 
		"programming_languages": (str, list), 
		"programming_languages_definition_files": (str, list), 
		"use_file_name_if_no_main_language": bool, 

		"environments": dict, 
		"delimiters": dict, 

		"environments_fields": {
			"values": list, 
			"add_values": list
		}, 
		"delimiters_fields": {
			"signature_constructor": (str, list), 
			"add_signature_constructor": (str, list), 
			"normal": list, 
			"add_normal": list, 
			"no_nesting": list, 
			"add_no_nesting": list
		}
	}

	def set_defaults(self):
		defaults = vars(_ConfigDefaults)
		for attr in defaults:
			if attr[:2] != "__": setattr(self, attr, defaults[attr])

	def reset(self, config_file: str = None):
		self.set_defaults()
		self.__init__(config_file = config_file)


config = Config()