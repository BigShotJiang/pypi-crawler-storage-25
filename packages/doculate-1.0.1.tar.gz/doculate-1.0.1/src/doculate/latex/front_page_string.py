from ..config import config

def create_front_page_string():
	front_page_string = \
	f"""
	% !TEX encoding = UTF-8 Unicode
	\\newsetlength{{\\frontpageleftmargin}}{{{config.front_page_left_margin}}}
	\\newsetlength{{\\frontpagerightmargin}}{{{config.front_page_right_margin}}}
	\\newsetlength{{\\frontpagetopmargin}}{{{config.front_page_top_margin}}}
	\\newsetlength{{\\frontpagebottommargin}}{{{config.front_page_bottom_margin}}}
	%
	\\def\\fonttitlesize{{{config.title_font_size}}}
	\\newsetlength{{\\fonttitleheight}}{{\\fonttitlesize pt}}
	\\newsetlength{{\\pretitleskip}}{{-0.15\\fonttitleheight}}
	\\newsetlength{{\\titlewidth}}{{\\widthof{{\\fontsize{{\\fonttitlesize}}{{\\fonttitlesize}}\\selectfont\\thetitle}}}}
	%
	\\thispagestyle{{empty}}%
	%
	\\newgeometry{{%
		left = \\frontpageleftmargin, 
		right = \\frontpagerightmargin, 
		bottom = \\frontpagebottommargin, 
		top = \\frontpagetopmargin, 
		headheight = 0pt, 
		headsep = 0pt, 
		nomarginpar
	}}
	%
	\\begingroup%
	\\setlength{{\\parindent}}{{0pt}}%
	\\setlength{{\\lineskip}}{{0pt}}%
	\\setlength{{\\baselineskip}}{{0pt}}%
	\\setlength{{\\parskip}}{{0pt}}%
	%
	% ------------------------------------------------------------------------------------------------------------------------------
	%
	\\begin{{minipage}}[c][\\textheight]{{\\linewidth}}
	\\vskip\\pretitleskip%
	\\begingroup%
	\\ifdim\\titlewidth < \\textwidth%
		\\fontsize{{\\fonttitlesize}}{{\\fonttitlesize}}\\selectfont\\thetitle%
	\\else%
		\\resizebox{{\\textwidth}}{{!}}{{\\thetitle}}%
	\\fi%
	\\endgroup%
	\\vskip 7em%
	\\hfill\\Large\\theauthor%
	\\end{{minipage}}
	%
	\\endgroup%
	\\restoregeometry%
	"""

	return front_page_string