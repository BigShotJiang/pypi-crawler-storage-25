from ..config import config
from ..textline_parser import TextLineParser
from ..line_state import LineState
from ..utils import file_exists, latex_resources_path

replace_title_delimiters = TextLineParser(LineState(identifier=config._patterns.SectionHeader.name)).replace_delimiters


def create_preamble_string(content_input_tex_file = None):
	if not content_input_tex_file: content_input_tex_file = config.content_file_name
	
	preamble_string = \
	f"""
	% !TEX encoding = UTF-8 Unicode
	\\documentclass[letterpaper, oneside, {config.main_font_size}]{{memoir}}
	\\usepackage{{fontspec}}
	\\usepackage{{lmodern}}


	% Rutas a utilizar
	\\makeatletter
	\\def\\input@path{{
		{{./front_page/}}
		{{./def/}}
		{{./redef/}}
		{{./listings/languages/}}
		{{./listings/styles/}}
		{{./utils/}}
	}}
	\\makeatother


	% Dimensiones del documento
	\\usepackage{{geometry}}
	\\geometry{{
		left = {config.page_left_margin}, 
		right = {config.page_right_margin}, 
		top = {config.page_top_margin}, 
		bottom = {config.page_bottom_margin}
	}}


	% Paquetes básicos
	\\usepackage{{float}}
	\\usepackage{{calc}}
	\\usepackage{{ragged2e}}
	\\usepackage{{anyfontsize}}
	\\usepackage{{scalerel}}
	\\usepackage{{graphicx}}
	\\usepackage[table]{{xcolor}}
	\\usepackage{{etoolbox}}
	\\usepackage{{csquotes}}

	
	% Utilidades
	\\input{{utils.tex}}


	% Título del documento
	\\title{{{replace_title_delimiters(config.title)}}}
	\\author{{{config.author}}}
	\\date{{{config.date}}}


	% Tabla de contenidos
	\\renewcommand{{\\contentsname}}{{{config.tableofcontents_name}}}
	\\renewcommand\\printtoctitle[1]{{\\bfseries\\fontsize{{25}}{{25}}\\selectfont #1}}
	\\settocdepth{{{set_toc_depth(config.root_section)}}}
	\\setsecnumdepth{{{set_title_numeration_depth(config.root_section)}}}
	\\renewcommand*{{\\cftchapterfont}}{{\\bfseries\\boldmath}}


	% Títulos de secciones
	%\\renewcommand*{{\\chapterheadstart}}{{}}
	\\renewcommand*{{\\printchaptername}}{{}}
	\\renewcommand*{{\\chapternamenum}}{{}}
	\\renewcommand*{{\\printchapternum}}{{}}
	\\renewcommand*{{\\afterchapternum}}{{}}
	\\renewcommand*{{\\printchapternonum}}{{}}
	\\renewcommand*{{\\chaptitlefont}}{{\\normalfont\\boldmath\\bfseries\\fontsize{{35}}{{35}}\\selectfont}}
	\\setlength{{\\afterchapskip}}{{40pt + 1ex}}

	\\setsecnumformat{{}}
	\\setsecindent{{0em}}
	\\setsecheadstyle{{\\normalfont\\boldmath\\bfseries\\fontsize{{25}}{{25}}\\selectfont}}
	\\setbeforesecskip{{-1cm}}
	\\setaftersecskip{{5ex}}

	\\setsubsecindent{{0em}}
	\\setsubsecheadstyle{{\\normalfont\\Large\\bfseries\\boldmath}}
	\\setbeforesubsecskip{{-1cm}}
	\\setaftersubsecskip{{3ex}}

	\\setsubsubsecindent{{0em}}
	\\setsubsubsecheadstyle{{\\normalfont\\large\\bfseries\\boldmath}}
	\\setbeforesubsubsecskip{{-1cm}}
	\\setaftersubsubsecskip{{2ex}}

	\\setparaindent{{0em}}
	\\setparaheadstyle{{\\normalfont\\normalsize\\bfseries\\boldmath}}
	\\setbeforeparaskip{{-3.25ex plus 1ex minus 0.2ex}}
	\\setafterparaskip{{1ex}}

	\\setsubparaindent{{0em}}
	\\setsubparaheadstyle{{\\normalfont\\normalsize\\bfseries\\boldmath}}
	\\setbeforesubparaskip{{-3.25ex plus 1ex minus 0.2ex}}
	\\setaftersubparaskip{{0.5ex}}

	% Lógica
	\\let\\Oldbook\\book%
	\\renewcommand{{\\book}}[1]{{\\Oldbook{{#1}}\\leftskip=0em\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}}}
	\\let\\Oldpart\\part%
	\\renewcommand{{\\part}}[1]{{\\Oldpart{{#1}}\\leftskip=0em\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}}}
	\\let\\Oldchapter\\chapter%
	\\renewcommand{{\\chapter}}[1]{{\\Oldchapter{{#1}}\\leftskip=0em}}
	\\let\\oldsection\\section%
	\\renewcommand{{\\section}}[1]{{\\par\\leftskip=0em\\oldsection{{#1}}}}
	\\let\\oldsubsection\\subsection%
	\\renewcommand{{\\subsection}}[1]{{\\par\\leftskip=0em\\oldsubsection{{#1}}}}
	\\let\\oldsubsubsection\\subsubsection%
	\\renewcommand{{\\subsubsection}}[1]{{\\par\\leftskip=0em\\oldsubsubsection{{#1}}}}
	{root_section_redefinitions(config.root_section)}

	% Listas y descripciones
	\\usepackage{{enumitem}}

	\\input{{enumitem_defs.tex}}
	\\input{{enumitem_redefs.tex}}

	% Viñetas.
	\\newcommand{{\\Square}}{{\\raisebox{{0.1\\baselineskip}}{{\\fontsize{{5}}{{5}}\\selectfont$\\blacksquare$}}}}

	\\setlist[itemize, 1]{{
		label = \\Square, 
		topsep = 1em, 
		labelindent = \\leftskip + \\parindent, 
		itemsep = 2pt, 
		leftmargin = *
	}}
	\\setlist[itemize, 2]{{
		label = $\\circ$, 
		itemsep = 2pt, 
		labelindent = 0pt, 
		leftmargin = \\leftskip + \\leftmargin
	}}
	\\setlist[itemize, 3]{{
		label = \\textbf{{\\textendash}}, 
		itemsep = 2pt, 
		labelindent = 0pt, 
		leftmargin = \\leftskip + \\leftmargin
	}}

	\\setlist[enumerate]{{
		label = {{\\arabic*.}}, 
		ref = \\arabic*, 
		topsep = 1.2em, 
		labelindent = \\leftskip + \\parindent, 
		align = left, 
		leftmargin = *
	}}

	\\SetEnumitemKey{{description_base_1}}{{
		before = \\enabledescription\\let\\item\\lstitem, 
		font = \\normalfont, 
		align = left,
		topsep = 1em, 
		itemindent = 0pt, 
		labelindent = \\leftskip + \\parindent, 
		style = sameline, 
		itemsep = 2pt, 
		leftmargin = \\leftskip + 2\\parindent, 
		after = \\disabledescription
	}}
	\\SetEnumitemKey{{description_base_2}}{{
		before = \\enabledescription\\let\\item\\lstitem, 
		style = sameline, 
		font = \\normalfont, 
		align = left, 
		itemindent = 0pt, 
		labelindent = \\parindent, 
		itemsep = 2pt, 
		leftmargin = 2\\parindent, 
		after = \\disabledescription
	}}
	\\SetEnumitemKey{{description_base_3}}{{
		before = \\enabledescription\\let\\item\\lstitem, 
		style = sameline, 
		font = \\normalfont, 
		align = left,
		labelindent = \\parindent, 
		itemsep = 2pt, 
		leftmargin = 2\\parindent, 
		after = \\disabledescription
	}}

	\\SetEnumitemKey{{nextline_test}}{{
		before = \\enableDescription\\let\\item\\lstnextitem, 
		style = sameline, 
		labelindent = \\leftskip + \\parindent, 
		itemsep = 1ex, 
		leftmargin = *, 
		after = \\disableDescription
	}}

	% Descripciones de misma línea.
	\\newlist{{description_base}}{{description}}{{3}}
	\\setlist[description_base, 1]{{description_base_1}}
	\\setlist[description_base, 2]{{description_base_2}}
	\\setlist[description_base, 3]{{description_base_3}}

	\\setlist[description, 1]{{description_base_1, font = \\normalfont\\bfseries\\boldmath}}
	\\setlist[description, 2]{{description_base_2, font = \\normalfont\\bfseries\\boldmath}}
	\\setlist[description, 3]{{description_base_3, font = \\normalfont\\bfseries\\boldmath}}

	\\SetEnumitemKey{{Description}}{{
		topsep = \\baselineskip, 
		font = \\normalfont\\bfseries, 
		labelindent = 0pt, 
		style = nextline, 
		itemsep = \\baselineskip - \\parsep, 
		leftmargin = \\leftskip
	}}

	% Tal vez se pueda ahorrar toda esta lógica con `leftmargin=*`.
	\\AtBeginEnvironment{{description}}{{%
		\\ifhmode
			%
		\\else
			\\vskip 0pt%
		\\fi
	}}

	{description_environments_definitions()}

	% Descripciones de línea aparte.
	\\newlist{{Description}}{{description}}{{3}}
	\\setlist[Description, 1]{{Description}}

	% Contador para etiquetado automático de enumeraciones
	\\newcounter{{enum}}
	\\AtBeginEnvironment{{enumerate}}{{\\refstepcounter{{enum}}}}


	% Código de programación
	\\usepackage{{listings}}
	{
	input_main_programming_language_definition_files() + 
  	input_languages_definition_files()
	}
	\\newfontfamily\\ttalternative{{FreeMono}}[Scale = MatchLowercase]

	\\lstset{{
		{lstset_global_languages()}, 
		basicstyle = \\normalfont\\ttfamily, 
		aboveskip = 0pt, 
		belowskip = 0pt, 
		breaklines = true, 
		showspaces = false, 
		showstringspaces = false, 
		columns = flexible, 
		tabsize = 4, 
		gobble = 4, 
		literate = 
			{{“}}{{{{\\ttalternative “}}}}1 
			{{”}}{{{{\\ttalternative ”}}}}1 
			{{‘}}{{{{\\textquoteleft}}}}1 
			{{’}}{{{{\\textquoteright}}}}1 
			{{␣}}{{{{\\textvisiblespace}}}}1
	}}

	% Corrección para identificar correctamente caracteres de opción `literate` en código.
	\\makeatletter
	\\lst@AddToHook{{Init}}{{%
	\\catcode`“=\\active
	\\catcode`”=\\active
	\\catcode`‘=\\active
	\\catcode`’=\\active
	\\catcode`␣=\\active
	}}
	\\makeatother

	\\lstdefinestyle{{plaintext}}{{
		language =, 
		style =, 
		basicstyle = \\normalfont\\ttfamily
	}}
	\\lstdefinestyle{{intitle}}{{style = plaintext, basicstyle = \\ttfamily}}
	\\lstdefinestyle{{inline}}{{}}

	\\AtBeginDocument{{\\lstMakeShortInline[style=inline]`}}

	\\newcommand{{\\file}}[1]{{\\lstinline[style = plaintext]#1}}	%[
	\\newcommand{{\\dir}}[1]{{\\lstinline[style = plaintext]#1}}	%[
	\\newcommand{{\\key}}[1]{{\\lstinline[style = plaintext]#1}}	%[

	\\newcommand{{\\lstintitle}}[1]{{\\lstinline[style = intitle]#1}}	%[
	\\newcommand{{\\fileintitle}}[1]{{\\lstinline[style = intitle]#1}}	%[
	\\newcommand{{\\dirintitle}}[1]{{\\lstinline[style = intitle]#1}}	%[
	\\newcommand{{\\keyintitle}}[1]{{\\lstinline[style = intitle]#1}}	%[

	\\newlength{{\\afteractionerrorbpskip}}
	\\setlength{{\\afteractionerrorbpskip}}{{0.5em}}


	% Cajas de entornos
	\\usepackage[most]{{tcolorbox}}
	\\tcbuselibrary{{breakable}}

	{code_environments_colors_definitions()}

	\\tcbset{{
	basestyle/.style = {{
		width = \\linewidth - \\leftskip, 
		colback = background_code_color, 
		colbacktitle = default_title_code_color, 
		colframe = code_frame_color, 
		sharp corners, 
		before skip = 1.2em, 
		after skip = 1.2em, 
		boxsep = 2pt, 
		left = 1pt, 
		right = 1pt, 
		top = 2pt, 
		bottom = 0pt, 
		boxrule = 0.4pt, 
		toptitle = 2pt, 
		titlerule = 0pt, 
		bottomtitle = 2pt, 
		listing only, 
		fonttitle = \\ttfamily\\large\\itshape, 
		listing options = {{
			basicstyle = \\normalfont\\{config.code_environments_font_size}\\ttfamily
		}}, 
		breakable, 
		toprule at break = 0pt, 
		bottomrule at break = 0pt
	}}}}

	{code_environments_definitions()}

	\\def\\atbegintcblisting{{\\ifbool{{in_description}}{{\\ifvmode\\leavevmode\\fi}}{{}}}}

	{code_environments_wrapper(
		before = "\\AtBeginEnvironment{", 
		after = "}{\\atbegintcblisting}")}

	\\makeatletter
	\\def\\aftertcblisting{{\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}}}
	\\makeatother

	{code_environments_wrapper( 
		before = "\\AfterEndEnvironment{", 
		after = "}{\\aftertcblisting}")}


	% Acciones específicas, errores y buenas prácticas
	\\makeatletter
	\\newcommand{{\\ActionErrorBP}}[1]{{%
		\\ifhmode
			\\par\\addvspace{{1em}}
		\\else
			\\par
		\\fi
		\\leftskip=0em
		\\noindent
		\\textbf{{\\textsl{{\\boldmath #1}}}}\\par%
		\\vskip\\afteractionerrorbpskip%
		\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}%
	}}

	
	% Términos
	\\newlength{{\\termcontentmargin}}
	\\setlength{{\\termcontentmargin}}{{2em}}
	\\newlength{{\\aftertermskip}}
	\\setlength{{\\aftertermskip}}{{0.5em}}


	\\NewDocumentCommand{{\\Term}}{{v}}{{%
		\\ifhmode
			\\par\\addvspace{{1em}}
		\\else
			\\par
		\\fi
		\\leftskip=0em
		\\noindent
		\\lstinline{{#1}}\\par% {{
		\\leftskip=\\termcontentmargin%
		\\@ifnextchar\\Term{{%
			% No hacer nada
		}}{{%
		\\@ifnextchar\\FinalEllipsisTerm{{%
			% No hacer nada
		}}{{%
		\\@ifnextchar\\begin{{%
			\\vskip\\aftertermskip%
			\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}%
		}}{{%
			\\vskip\\aftertermskip%
			\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}%
		}}}}}}
	}}

	\\NewDocumentCommand{{\\FirstTerm}}{{v}}{{%
		\\ifhmode
			\\par\\addvspace{{1em}}
		\\else
			\\par
		\\fi
		\\leftskip=0em
		\\noindent
		\\lstinline{{#1}}% {{
	}}

	\\NewDocumentCommand{{\\FinalTerm}}{{v}}{{%
		\\lstinline{{#1}}\\par% {{
		\\leftskip=\\termcontentmargin%
		\\@ifnextchar\\Term{{%
			% No hacer nada
		}}{{%
		\\@ifnextchar\\FinalEllipsisTerm{{%
			% No hacer nada
		}}{{%
		\\@ifnextchar\\begin{{%
			\\vskip\\aftertermskip%
			\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}%
		}}{{%
			\\vskip\\aftertermskip%
			\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}%
		}}}}}}
	}}

	\\NewDocumentCommand{{\\FinalEllipsisTerm}}{{v}}{{%
		\\ifhmode
			\\par\\addvspace{{1em}}
		\\else
			\\par
		\\fi
		\\leftskip=0em
		\\noindent
		\\lstinline{{#1}}, ...\\par% {{
		\\leftskip=\\termcontentmargin%
		\\@ifnextchar\\Term{{%
			% No hacer nada
		}}{{%
		\\@ifnextchar\\FinalEllipsisTerm{{%
			% No hacer nada
		}}{{%
		\\@ifnextchar\\begin{{%
			\\vskip\\aftertermskip%
			\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}%
		}}{{%
			\\vskip\\aftertermskip%
			\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}%
		}}}}}}
	}}
	\\makeatother

	\\let\\CommaTerm\\lstinline

	\\def\\informalreferencebullet{{[]}}
	\\newcommand{{\\InformalReference}}[1]{{\\noindent\\informalreferencebullet\\ #1\\par}}


	% Tablas
	%\\usepackage{{longtable}}
	\\usepackage{{array, multirow}}
	\\usepackage{{cellspace}}
	\\renewcommand{{\\arraystretch}}{{1.5}}

	\\newlength{{\\tableindent}}
	\\setlength{{\\tableindent}}{{\\parindent}}
	\\newlength{{\\tabletopsep}}
	\\setlength{{\\tabletopsep}}{{1em}}
	\\usepackage{{hhline}}

	% Code before removing `table` environment.
	\\iffalse
	\\newlength{{\\tableleftmargin}}
	\\makeatletter
	\\BeforeBeginEnvironment{{table}}{{%
		\\vspace{{-\\lineskip}}%
		\\ifbool{{in_Description}}{{%
			\\setlength{{\\tableleftmargin}}{{\\leftskip + \\leftmargin + \\tableindent}}%
		}}{{%
			\\ifbool{{in_description}}{{%
				\\setlength{{\\tableleftmargin}}{{\\leftskip + \\leftmargin + \\tableindent}}%
			}}{{%
				\\setlength{{\\tableleftmargin}}{{\\leftskip + \\tableindent}}%
			}}%
		}}%
	}}
	\\BeforeBeginEnvironment{{tabular}}{{\\hskip\\tableleftmargin}}
	\\AfterEndEnvironment{{table}}{{\\ignorespacesafterend\\nointerlineskip\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}}}
	\\makeatother
	\\fi

	% Code after removing `table` environment.
	\\BeforeBeginEnvironment{{tabular}}{{\\ifbool{{in_description}}{{\\mbox{{}}}}{{}}\\par\\vskip\\tabletopsep\\noindent\\hskip\\tableindent}}
	\\AfterEndEnvironment{{tabular}}{{\\vskip\\tabletopsep\\everypar{{\\setbox0\\lastbox\\everypar{{}}}}}}


	% Caption
	\\usepackage[labelfont = bf]{{caption}}
	\\setlength{{\\abovecaptionskip}}{{20pt}}
	%\\setlength{{\\belowcaptionskip}}{{0pt}}
	\\captionsetup[figure]{{name = Figura}}
	\\captionsetup[table]{{name = Tabla}}


	% Matemáticas
	\\usepackage{{amsmath}}
	\\usepackage{{amsfonts}}
	\\usepackage{{amssymb}}

	% Espacio antes y después de entornos matemáticos.
	\\AtBeginDocument{{
	\\setlength{{\\belowdisplayskip}}{{1.5\\baselineskip}}
	\\setlength{{\\abovedisplayskip}}{{1.5\\baselineskip}}
	\\setlength{{\\abovedisplayshortskip}}{{1.5\\baselineskip}}
	\\setlength{{\\belowdisplayshortskip}}{{1.5\\baselineskip}}
	}}


	% Encabezado
	\\nouppercaseheads
	\\createmark{{{section_level_left_header_mark(config.root_section)}}}{{left}}{{shownumber}}{{{config.header_pre_chapter_mark}}}{{{config.header_pos_chapter_mark}}}
	\\createmark{{{section_level_right_header_mark(config.root_section)}}}{{right}}{{shownumber}}{{}}{{ \\slshape}}
	%\\renewcommand{{\\chaptermark}}[1]{{\\markboth{{#1}}{{}}}}
	%\\renewcommand{{\\sectionmark}}[1]{{\\markright{{#1}}}}
	\\makepagestyle{{main}}
	\\makeheadrule{{main}}{{\\linewidth}}{{0.5pt}}
	%\\makeevenhead{{main}}{{\\rightmark}}{{}}{{}}
	\\makeoddhead{{main}}{{\\leftmark}}{{}}{{\\rightmark}}
	\\makeoddfoot{{main}}{{}}{{\\thepage}}{{}}


	% Notas al pie
	\\usepackage{{zref-perpage}}	% Necesario para arreglar bug.
	\\zmakeperpage{{footnote}}		% Necesario para arreglar bug.
	\\usepackage[hang, perpage, bottom, symbol]{{footmisc}}
	\\input{{footmisc_redefs.tex}}
	\\let\\oldfootnote\\footnote
	\\renewcommand{{\\footnote}}{{\\negthickspace\\oldfootnote}}
	\\renewcommand{{\\thempfootnote}}{{\\fnsymbol{{mpfootnote}}}}
	\\setlength{{\\footnotemargin}}{{0.6em}}


	% Subrayado especial
	\\usepackage{{contour}}
	\\usepackage[normalem]{{ulem}}
	\\renewcommand{{\\ULdepth}}{{1.8pt}}
	\\contourlength{{0.8pt}}
	\\newcommand{{\\miSubrayado}}[1]{{%
		\\uline{{\\phantom{{#1}}}}%
		\\llap{{\\contour{{white}}{{#1}}}}%
	}}


	% Hipervínculos
	\\usepackage{{hyperref}}
	\\usepackage{{url}}
	\\hypersetup{{hidelinks}}


	%===============================================================================================================================
	\\begin{{document}}
	%===============================================================================================================================
	%
	%
	\\include{{front_page}}
	\\pagestyle{{plain}}%
	\\pagenumbering{{roman}}%
	%
	\\tableofcontents*%
	\\cleardoublepage%
	\\pagestyle{{main}}%
	%
	\\pagenumbering{{arabic}}%
	\\setcounter{{page}}{{1}}%
	%
	\\include{{{content_input_tex_file}}}
	%
	%
	%===============================================================================================================================
	\\end{{document}}
	%===============================================================================================================================
	"""

	return preamble_string


def description_environments_definitions():
	description_environments_definitions = []

	for env_id in config._description_like_envs_identifiers:

		if config._implicit_env_prefix in env_id \
		or env_id == config.environments.Description.id: 
			continue
		
		env_obj = getattr(config.environments, env_id)

		desc_env_def = \
		f"""
		\\newenvironment{{{env_obj.LaTeX_name}}}
			{{\\preenvtext{{{env_obj.values[0]}}}
			\\begin{{description_base}}}}
			{{\\end{{description_base}}}}
		"""

		description_environments_definitions.append(desc_env_def)

	description_environments_definitions = ''.join(description_environments_definitions).replace("\n\t", "\n")
	
	return description_environments_definitions[2:-2]

def code_environments_colors_definitions():
	code_environments_colors_defs = []
	title_color = config.code_environments_title_colors

	color_def = f"\\colorlet{{background_code_color}}{{{config.code_background_color}}}" \
		if ',' not in config.code_background_color else \
			f"\\definecolor{{background_code_color}}{{rgb}}{{{config.code_background_color}}}"
	code_environments_colors_defs.append(color_def)

	color_def = f"\\colorlet{{default_title_code_color}}{{{config.default_code_title_color}}}" \
		if ',' not in config.default_code_title_color else \
			f"\\definecolor{{default_title_code_color}}{{rgb}}{{{config.default_code_title_color}}}"
	code_environments_colors_defs.append(color_def)

	color_def = f"\\colorlet{{code_frame_color}}{{{config.code_frame_color}}}" \
		if ',' not in config.code_frame_color else \
			f"\\definecolor{{code_frame_color}}{{rgb}}{{{config.code_frame_color}}}"
	code_environments_colors_defs.append(color_def)

	for env_id in config._ignore_lines_envs:
		if env_id in [
			config.environments.Math.id,
			config.environments.MathExpressions.id,
			config.environments.AlignedMathExpressions.id,
			config.environments.LaTeX.id,
			config.environments.Comment.id
		]: continue

		color_name = env_id.lower() + "_title_color"
		color_value = title_color[env_id]
		
		color_def = f"\\colorlet{{{color_name}}}{{{color_value}}}" \
			if ',' not in color_value else \
				f"\\definecolor{{{color_name}}}{{rgb}}{{{color_value}}}"

		code_environments_colors_defs.append(color_def)

	code_environments_colors_defs = '\n'.join(code_environments_colors_defs).replace("\n\t", "\n")
	
	return code_environments_colors_defs

def code_environments_definitions():
	code_environments_definitions = []

	for env_id in config._ignore_lines_envs:
		if env_id in [
			config.environments.Math.id,
			config.environments.MathExpressions.id,
			config.environments.AlignedMathExpressions.id,
			config.environments.LaTeX.id,
			config.environments.Comment.id
		]: continue
		
		env_obj = getattr(config.environments, env_id)

		code_env_def = \
		f"""
		\\newtcblisting[auto counter, number within = {numeration_top_section(config.root_section)}]{{{env_obj.LaTeX_name.replace('_', '-')}}}{{%
			basestyle, 
			title = {{{env_obj.values[0]} \\thetcbcounter}}, 
			colbacktitle = {env_id.lower()}_title_color}}
		"""

		code_environments_definitions.append(code_env_def)

	code_environments_definitions = ''.join(code_environments_definitions).replace("\n\t", "\n")
	
	return code_environments_definitions[2:-2]

def code_environments_wrapper(before = "", after = ""):
	code_environments_wrapper = []

	for env_id in config._ignore_lines_envs:
		if env_id in [
			config.environments.Math.id,
			config.environments.MathExpressions.id,
			config.environments.AlignedMathExpressions.id,
			config.environments.LaTeX.id,
			config.environments.Comment.id
		]: continue

		env_obj = getattr(config.environments, env_id)

		code_env_wrap = before + env_obj.LaTeX_name.replace('_', '-') + after

		code_environments_wrapper.append(code_env_wrap)
	
	code_environments_wrapper = '\n'.join(code_environments_wrapper)
	
	return code_environments_wrapper

def exists_language_or_style_default_files(languages: str | list[str]):
	files = []

	if isinstance(languages, list):
		for language in languages:
			language_file = f"{language.lower()}-language.tex"
			style_file = f"{language.lower()}-style.tex"
			language_exists = file_exists(latex_resources_path + "/listings/languages/" + language_file)
			style_exists = file_exists(latex_resources_path + "/listings/styles/" + style_file)

			if language_exists: files.append(language_file)
			else: files.append(None)
			if style_exists: files.append(style_file)
			else: files.append(None)
	else:
		language_file = f"{languages.lower()}-language.tex"
		style_file = f"{languages.lower()}-style.tex"
		language_exists = file_exists(latex_resources_path + "/listings/languages/" + language_file)
		style_exists = file_exists(latex_resources_path + "/listings/styles/" + style_file)

		if language_exists: files.append(language_file)
		else: files.append(None)
		if style_exists: files.append(style_file)
		else: files.append(None)
	
	if all([f is None for f in files]): files = []

	return files

def input_main_programming_language_definition_files():
	main_language = config.main_programming_language
	if not main_language: return ""

	files = exists_language_or_style_default_files(main_language)
	language_file, style_file = files if files else [None, None]

	# Don't input main language default files if they have same name as user files.
	user_files = config.programming_languages_definition_files
	if not user_files: user_files = []
	if user_files and not isinstance(user_files, list): user_files = [user_files]
	for file_path in user_files:
		user_file = file_path.split('/')[-1]
		if language_file == user_file: language_file = None
		if style_file == user_file: style_file = None

	inputs = ""

	if language_file:
		inputs += f"\\input{{{language_file}}}"
		if style_file: inputs += '\n'
	if style_file:
		inputs += f"\\input{{{style_file}}}"
	if language_file or style_file: 
		inputs = '\n' + inputs + '\n'
	
	return inputs

def input_languages_definition_files():
	inputs = ""
	languages = config.programming_languages
	user_files = config.programming_languages_definition_files

	if not languages: languages = []
	if languages and not isinstance(languages, list): languages = [languages]
	if not user_files: user_files = []
	if user_files and not isinstance(user_files, list): user_files = [user_files]

	if languages:
		if config.main_programming_language in languages: 
			languages.remove(config.main_programming_language)
		default_files = exists_language_or_style_default_files(languages)
		default_files = [i for i in default_files if i != None]

		# Don't input language default file if it have the same name as a user file.
		for file_path in user_files:
			user_file = file_path.split('/')[-1]
			for default_file in default_files:
				if default_file == user_file: default_files.remove(default_file)

		for file in default_files[:-1]:
			if file: inputs += f"\\input{{{file}}}\n"
		if default_files: inputs += f"\\input{{{default_files[-1]}}}"
		if inputs and user_files: inputs += '\n'
	
	if user_files: 
		for file in user_files[:-1]: inputs += f"\\input{{{file}}}\n"
		inputs += f"\\input{{{user_files[-1]}}}"
	
	if languages or user_files: 
		inputs = '\n' + inputs + '\n'
	
	return inputs

def lstset_global_languages():
	languages = ""

	if config.programming_languages:
		languages += "classoffset = 0, \n\t\t"
		languages += f"language = {config.main_programming_language}, \n\t\t"
		for i, language in enumerate(config.programming_languages):
			languages += f"classoffset = {(i+1)*10}, \n\t\t"
			languages += f"alsolanguage = {language}, \n\t\t"
		languages += "classoffset = 0"
	else:
		languages += f"language = {config.main_programming_language}"
	
	return languages

def set_toc_depth(root_section): 
	if root_section in config.sections[:-2]:
		i = config.sections.index(root_section) + 2
		depth = config.sections[i]
	else:
		depth = config.sections[-1]
	
	return depth

def set_title_numeration_depth(root_section):
	return set_toc_depth(root_section)

def numeration_top_section(root_section):
	if root_section not in config.minor_sections:
		mark = "chapter"
	else: mark = root_section

	return mark

def section_level_left_header_mark(root_section):
	return numeration_top_section(root_section)

def section_level_right_header_mark(root_section): 
	if root_section not in config.minor_sections:
		mark = config.minor_sections[0]
	elif root_section != config.minor_sections[-1]:
		i = config.minor_sections.index(root_section) + 1
		mark = config.minor_sections[i]
	else:
		mark = "paragraph"	# Does nothing
	
	return mark

def root_section_redefinitions(root_section):
	redefinitions = ""

	if root_section in config.minor_sections:
		redefinitions += "\n\t"

		i = config.minor_sections.index(root_section)
		usable_sections = config.minor_sections[i:].copy()
		thepresecs = ""

		for j, sec in enumerate(usable_sections):
			thepresecs += f"\\the{usable_sections[j-1]}." if j > 0 else ""
			redefinitions += f"\\renewcommand{{\\the{sec}}}{{{thepresecs}\\arabic{{{sec}}}}}"
			redefinitions += "\n\t"
		
		redefs = []
		for j, sec in enumerate(usable_sections[1:]):
			replacement = config.minor_sections[j]
			redefs.append(
				f"""
				\\let\\oldcft{replacement}font\\cft{replacement}font
				\\let\\oldcft{replacement}pagefont\\cft{replacement}pagefont
				\\let\\oldcft{replacement}indent\\cft{replacement}indent
				\\let\\oldcft{replacement}numwidth\\cft{replacement}numwidth
				\\let\\oldcftbefore{replacement}skip\\cftbefore{replacement}skip
				\\renewcommand{{\\cft{sec}font}}{{\\oldcft{replacement}font}}
				\\renewcommand{{\\cft{sec}pagefont}}{{\\oldcft{replacement}pagefont}}
				\\renewcommand{{\\cft{sec}indent}}{{\\oldcft{replacement}indent}}
				\\renewcommand{{\\cft{sec}numwidth}}{{\\oldcft{replacement}numwidth}}
				\\renewcommand{{\\cftbefore{sec}skip}}{{\\oldcftbefore{replacement}skip}}
				""".replace("\t\t", "")
			)
		for redef in redefs[::-1]: redefinitions += redef

		sec = usable_sections[0]
		redef = \
			f"""
			\\renewcommand{{\\cft{sec}font}}{{\\cftchapterfont}}
			\\renewcommand{{\\cft{sec}pagefont}}{{\\cftchapterpagefont}}
			\\renewcommand{{\\cft{sec}indent}}{{\\cftchapterindent}}
			\\renewcommand{{\\cft{sec}numwidth}}{{\\cftchapternumwidth}}
			\\renewcommand{{\\cftbefore{sec}skip}}{{\\cftbeforechapterskip}}
			\\renewcommand{{\\cft{sec}dotsep}}{{\\cftnodots}}
			""".replace("\t\t", "")
		redefinitions += redef
	
	return redefinitions