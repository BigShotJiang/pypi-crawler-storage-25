from ..config import config
from ..utils import copy_dir, latex_resources_path
from .preamble_string import create_preamble_string
from .front_page_string import create_front_page_string

import os

class Preamble:

	def __init__(self, 
		content_input_tex_file: str = None, 
		output_main_file_name: str = None
	):
		self.content_input_tex_file = content_input_tex_file
		self.output_main_file_name = output_main_file_name

	def create_preamble_files(
		self, content_input_tex_file: str = None, 
		output_main_file_name: str = None, 
		output_dir: str = None
	): 
		# TODO: turn to INFO log.
		#print(f"{latex_resources_path = }")
		if not content_input_tex_file: content_input_tex_file = self.content_input_tex_file
		if not output_main_file_name: output_main_file_name = self.output_main_file_name
		
		if not content_input_tex_file: content_input_tex_file = config.content_file_name
		if not output_main_file_name: output_main_file_name = config.preamble_file_name
		if not output_dir: output_dir = config.output_dir

		print("Creating preamble files...")

		preamble_string = create_preamble_string(content_input_tex_file)
		
		if not os.path.exists(output_dir): os.makedirs(output_dir)
		with open(output_dir + output_main_file_name, 'w') as file: 
			file.write(preamble_string[2:].replace("\n\t", "\n"))
		
		front_page_string = create_front_page_string()
		front_page_dir = output_dir + "front_page/"
		if not os.path.exists(front_page_dir): os.makedirs(front_page_dir)
		with open(front_page_dir + config.front_page_file_name, 'w') as file: 
			file.write(front_page_string[2:].replace("\n\t", "\n"))
		
		copy_dir(latex_resources_path + "/def", output_dir + "def")
		copy_dir(latex_resources_path + "/redef", output_dir + "redef")
		copy_dir(latex_resources_path + "/listings", output_dir + "listings")
		copy_dir(latex_resources_path + "/utils", output_dir + "utils")

		print("Preamble files created")