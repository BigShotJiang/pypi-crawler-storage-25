from dataclasses import dataclass, field
from re import Match


class EnvStack(list): 
	def __init__(self, *args, valid_envs = []): 
		super().__init__(*args)
		self.valid_envs = valid_envs
	
	@property
	def last(self):
		return self[-1] if self != [] else None
	
	@property
	def first(self):
		return self[0] if self != [] else None

	def append_env(self, item): 
		if item in self.valid_envs: self.append(item)

class List(list):
	def __init__(self, *args): 
		super().__init__(*args)
	
	@property
	def last(self):
		return self[-1] if self != [] else None

	@last.setter
	def last(self, value):
		self[-1] = value

@dataclass
class LineState:
	line: str = None
	line_number: int = None
	identifier: str = None
	nest_level: int = None
	environment_stack: EnvStack = None
	inline_delimiters_stack: list = None
	_new_environments: list = None
	_pop_environments: list = None
	_item_type_stack: List[list[int, str]] = None
	_real_item_type: str = None
	_first_list_item: bool = None
	_indented_term_content: bool = None
	_library_headers: list[str] = field(default_factory = list)
	_table_metadata: dict = field(default_factory = dict)
	_match_object: Match = None

	def __repr__(self):
		return "({} {} {} {}) {}".format(
			self.line_number, 
			self.environment_stack, 
			self.identifier, 
			self.nest_level, 
			self.line
		)

	# def __repr__(self):
	# 	return "{} {}".format(
	# 		self.inline_delimiters_stack,  
	# 		self.line
	# 	)

	def __post_init__(self):
		self._table_metadata = {
			"num_columns": None, 
			"first_row": None, 
			"last_row": None
		}