# TODO: try greedy expressions (e.g. ` ?+`) when possible to speed up matches.

from dataclasses import dataclass, InitVar
import re

from .config_defaults import _ConfigDefaults
from .environments import Environments, _SpecialEnvironments
from .delimiters import InlineDelimiters


@dataclass(frozen = True)
class _Pattern: 
	name: str
	pattern: str

@dataclass(frozen = True)
class _AuxPattern:
	name: str
	pattern: str

class _Patterns:
	def __init__(self, **kwargs):
		for key, value in kwargs.items():
			if not isinstance(value, _Pattern):
				raise ValueError("Only values of type `_Pattern` are allowed.")
			setattr(self, key, value)

# TODO: change this default unnecessary class and to take all of its values from config (caution with circular imports).
@dataclass
class _DefaultPatterns: 
	_default_header_mark = _ConfigDefaults.header_mark
	_default_section_marks_unit = _ConfigDefaults.section_marks_unit
	_default_library_mark = _ConfigDefaults.library_mark
	_default_paragraph_mark = _ConfigDefaults.paragraph_mark
	_default_inline_delimiters = InlineDelimiters()
	_default_environments = Environments()
	_default_special_environments = _SpecialEnvironments()
	_default_env_values_string = _default_environments._get_env_values_string()
	_default_term_mark = _ConfigDefaults.term_mark
	_default_action_error_best_practice_mark = _ConfigDefaults.action_error_best_practice_mark
	_default_description_mark = _ConfigDefaults.description_mark
	_default_list_mark = _ConfigDefaults.list_mark
	_default_line_comment_symbol = _ConfigDefaults.line_comment_symbol
	_default_block_comment_delimiters = [re.escape(i) for i in _ConfigDefaults.block_comment_delimiters]
	_default_colon_rule_when_no_identifiers = _ConfigDefaults.colon_rule_when_no_identifiers
	_default_default_list_element_when_no_identifiers = _ConfigDefaults.default_list_element_when_no_identifiers
	_default_informal_reference_mark = _ConfigDefaults.informal_reference_mark
	_default_list_env_id = _default_environments.List.id
	_default_desc_env_id = _default_environments.Description.id
	_default_enum_env_id = _default_environments.Enumerate.id
	_default_table_env_id = _default_environments.Table.id

	# Methods to get patterns that require parameters
	@staticmethod
	def section_header_pattern(header_mark = _default_header_mark, section_marks_unit = _default_section_marks_unit):
		return r"(%s{1,6})(?!%s) ?((?:.(?!%s))+) ?(?:%s{2,})?$" % (header_mark, header_mark, section_marks_unit*2, section_marks_unit)
	@staticmethod
	def library_header_pattern(library_mark = _default_library_mark, section_marks_unit = _default_section_marks_unit):
		return r"(\%s{1,6}) ?((?:.(?!%s))+) ?(?:%s{2,})?$" % (library_mark, section_marks_unit*2, section_marks_unit)
	@staticmethod
	def paragraph_header_pattern(paragraph_mark = _default_paragraph_mark):
		return r"[\t ]*(%s{7,8}) (.+)$" % paragraph_mark
	@staticmethod
	def start_environment_pattern(env_values_string = _default_env_values_string):
		return r"^\t*({envs}): *$".format(envs = env_values_string)
	@staticmethod
	def item_elem_pattern(list_mark = _default_list_mark, description_mark = _default_description_mark):
		return r"\t*(?:{l_mark}|{d_mark}) ?(.+)".format(l_mark = list_mark, d_mark = description_mark)
	@staticmethod
	def list_elem_pattern(
		list_mark = _default_list_mark, 
		description_mark = _default_description_mark, 
		colon_rule_when_no_identifiers = _default_colon_rule_when_no_identifiers, 
		default_list_element_when_no_identifiers = _default_default_list_element_when_no_identifiers, 
		list_env_id = _default_list_env_id, 
		desc_env_id = _default_desc_env_id, 
		env = None
	): 
		if env == list_env_id or list_mark != description_mark: 
			return r"\t*{l_mark} ?(.+)(?<!  )$".format(l_mark = list_mark)
		elif env == desc_env_id: return r"(?!)"
		else: 
			if colon_rule_when_no_identifiers: 
				return r"\t*{l_mark} ?((?:.(?!: ))+)(?<!:)(?<!: )(?<!  )$".format(l_mark = list_mark)
			else: 
				if default_list_element_when_no_identifiers: 
					return r"\t*{l_mark} ?(.+)(?<!  )$".format(l_mark = list_mark)
				else: return r"(?!)"
	@staticmethod
	def same_line_description_elem_pattern(description_mark = _default_description_mark):
		return r"\t*{desc_mark} ?((?:.(?!, ))+?)(?:: (.+)|  )$".format(desc_mark = description_mark)
	@staticmethod
	def next_line_description_elem_pattern(description_mark = _default_description_mark):
		return r"\t*{desc_mark} ?(?:((?:.(?!, ))+): *|((?:.(?!, )(?!: ))+)) *$".format(desc_mark = description_mark)
	@staticmethod
	def same_line_description_elems_pattern(description_mark = _default_description_mark):
		return r"\t*{desc_mark} ?((?:(?:(?:.(?!, ))+.|.), )+?(?:.(?!, ))+?)(?::  |: (.+)|  )$".format(desc_mark = description_mark)
	@staticmethod
	def next_line_description_elems_pattern(description_mark = _default_description_mark):
		return r"\t*{desc_mark} ?((?:(?:(?:.(?!, )(?!: ))+.|.), )+(?:.(?!, ))+?):? *$".format(desc_mark = description_mark)
	@staticmethod
	def text_line_pattern(
		list_mark = _default_list_mark, 
		description_mark = _default_description_mark, 
		mark = _default_term_mark, 
		act_error_bp_mark = _default_action_error_best_practice_mark, 
		section_marks_unit = _default_section_marks_unit, 
		informal_reference_mark = _default_informal_reference_mark, 
		block_comment_mark = _default_block_comment_delimiters[0], 
		line_comment_mark = _default_line_comment_symbol
	):
		return r"(?>\t*)(?!{desc_mark}|{l_mark}|{term_mark}|{act_err_bp_mark}|[0-9]+\. |[0-9]+\. ?$|{sec_mark}+|{ref_mark}|{l_comment_mark}|{b_comment_mark})([^\t]+)(\.|:|\?|!|\"|') ?$" \
			.format(
				l_mark = list_mark, 
				desc_mark = description_mark, 
				term_mark = mark, 
				act_err_bp_mark = act_error_bp_mark, 
				sec_mark = section_marks_unit, 
				ref_mark = informal_reference_mark, 
				l_comment_mark = line_comment_mark, 
				b_comment_mark = block_comment_mark
			)
	@staticmethod
	def open_inline_delimiters_pattern(inline_delimiters = _default_inline_delimiters): 
		open_delimiters = inline_delimiters._get_open_delimiters()
		open_delimiters_string = re.escape('|'.join(open_delimiters))
		return r"({open_delims})".format(open_delims = open_delimiters_string)
	@staticmethod
	def simple_term_pattern(term_mark = _default_term_mark):
		return r"{term_mark}((?:.(?!, ))+(?<![\.\?!])$|[\.\?!]+$|(?:[^A-Za-z](?!, ))+$)".format(term_mark = term_mark)
	@staticmethod
	def comma_separated_terms_pattern(term_mark = _default_term_mark):
		return r"{term_mark}((?:(?:(?:.(?!, ))+.|.), (?!\.\.\.))+(?:(?:.(?!, ))+(?<![\.\?!])$|[\.\?!]+$))".format(term_mark = term_mark)
	@staticmethod
	def ellipsis_separated_terms_pattern(term_mark = _default_term_mark):
		return r"{term_mark}((?:(?:(?:.(?!, ))+.|.), )+)\.\.\.,? ?((?:.+)(?<![\.\?!])$|[\.\?!]+$)".format(term_mark = term_mark)
	@staticmethod
	def final_ellipsis_terms_pattern(term_mark = _default_term_mark):
		return r"{term_mark}((?:(?:(?:(?:.(?!, ))+.|.), )+)?(?:(?:.(?!, ))+?.|.)),? ?(?<!\.)\.\.\.$".format(term_mark = term_mark)
	@staticmethod
	def action_error_best_practice_pattern(action_error_best_practice_mark = _default_action_error_best_practice_mark):
		return r"{act_err_bp_mark}(?![\.\?!])(.+)(?:\.$|(?<=[\?!])$)".format(act_err_bp_mark = action_error_best_practice_mark)
	@staticmethod
	def informal_reference_pattern(informal_reference_mark = _default_informal_reference_mark): 
		return r"(?:{ref_mark}|\[[1-9]+\]) ?(.+)".format(ref_mark = informal_reference_mark)
	@staticmethod
	def open_block_comment_pattern(
		open_block_comment_mark = _default_block_comment_delimiters[0], 
		close_block_comment_mark = _default_block_comment_delimiters[1]
	):
		return r"[\t ]*+{open_mark} ?((?:.(?!{close_mark}))*)" \
			.format(
				open_mark = open_block_comment_mark, 
				close_mark = close_block_comment_mark
			)
	@staticmethod
	def close_block_comment_pattern(close_block_comment_mark = _default_block_comment_delimiters[1]):
		return r"[\t ]*+(.*) ?{close_mark} *$".format(close_mark = close_block_comment_mark)
	@staticmethod
	def full_line_comment_pattern(line_comment_symbol = _default_line_comment_symbol):
		return r"[ \t]*+{comment_symbol} ?(.*)".format(comment_symbol = line_comment_symbol)
	@staticmethod
	def final_line_comment_pattern(line_comment_symbol = _default_line_comment_symbol, open_block_comment_mark = _default_block_comment_delimiters[0]):
		return r"[ \t]*+(.+?)[ \t]*{comment_symbol} ?(.*)".format(comment_symbol = line_comment_symbol, open_mark = open_block_comment_mark)
	@staticmethod
	def inside_line_comment_pattern(block_comment_delims = _default_block_comment_delimiters):
		return r"[\t ]*+(.*) ?{open_mark} ?((?:.(?!{close_mark}))*.) ?{close_mark} ?(.*)" \
			.format(
				open_mark = block_comment_delims[0], 
				close_mark = block_comment_delims[1]
			)
	# All patterns are mutually exclusive
	SectionHeader: _Pattern = _Pattern(
		name = "SectionHeader", 
		pattern = section_header_pattern()
	)
	ParagraphHeader: _Pattern = _Pattern(
		name = "ParagraphHeader", 
		pattern = paragraph_header_pattern()
	)
	LibraryHeader: _Pattern = _Pattern(
		name = "LibraryHeader", 
		pattern = library_header_pattern()
	)
	StartEnvironment: _Pattern = _Pattern(
		name = "StartEnvironment", 
		pattern = start_environment_pattern()
	)
	TextLine: _Pattern = _Pattern(
		name = "TextLine", 
		pattern = text_line_pattern()
	)
	EmptyLine: _Pattern = _Pattern(
		name = "EmptyLine", 
		pattern = r"[\t ]*$"
	)
	Terms: _Patterns = _Patterns(
		simple_term = _Pattern(
			name = "simple_term", 
			pattern = simple_term_pattern()
		), 
		comma_separated_terms = _Pattern(
			name = "comma_separated_terms", 
			pattern = comma_separated_terms_pattern()
		), 
		ellipsis_separated_terms = _Pattern(
			name = "ellipsis_separated_terms", 
			pattern = ellipsis_separated_terms_pattern()
		), 
		final_ellipsis_terms = _Pattern(
			name = "final_ellipsis_terms", 
			pattern = final_ellipsis_terms_pattern()
		)
	)
	ActionErrorBestPractice: _Pattern = _Pattern(
		name = "Action/Error/BestPractice", 
		pattern = action_error_best_practice_pattern()
	)
	OpenInlineDelimiter: _Pattern = _Pattern(
		name = "OpenInlineDelimiter", 
		pattern = open_inline_delimiters_pattern()
	)
	item_elem: _Pattern = _Pattern(
		name = "item_elem", 
		pattern = item_elem_pattern()
	)
	list_elem: _Pattern = _Pattern(
		name = "list_elem", 
		pattern = list_elem_pattern()
	)
	enum_elem: _Pattern = _Pattern(
		name = "enum_elem", 
		pattern = r"\t*[0-9]+(?:\.|:)(?: ? ?(.+)|$)"
	)
	DescriptionItems: _Patterns = _Patterns(
		same_line_desc_elem = _Pattern(
			name = "same_line_desc_elem", 
			pattern = same_line_description_elem_pattern()
		), 
		next_line_desc_elem = _Pattern(
			name = "next_line_desc_elem", 
			pattern = next_line_description_elem_pattern()
		), 
		same_line_desc_elems = _Pattern(
			name = "same_line_desc_elems", 
			pattern = same_line_description_elems_pattern()
		), 
		next_line_desc_elems = _Pattern(
			name = "next_line_desc_elems", 
			pattern = next_line_description_elems_pattern()
		)
	)
	OpenBlockComment: _Pattern = _Pattern(
		name = "OpenBlockComment", 
		pattern = open_block_comment_pattern()
	)
	CloseBlockComment: _Pattern = _Pattern(
		name = "CloseBlockComment", 
		pattern = close_block_comment_pattern()
	)
	FullLineComment: _Pattern = _Pattern(
		name = "FullLineComment", 
		pattern = full_line_comment_pattern()
	)
	InformalReference: _Pattern = _Pattern(
		name = "InformalReference", 
		pattern = informal_reference_pattern()
	)
	TableItems: _Patterns = _Patterns(
		table_row = _Pattern(
			name = "table_row", 
			pattern = r"\t*((?:[^\t]+\t+)+[^\t]+)\t*$"
		), 
		table_single_elem = _Pattern(
			name = "table_single_elem", 
			pattern = r"\t*([^\t]+)$"
		), 
		implicit_table_single_elem = _Pattern(
			name = "implicit_table_single_elem", 
			pattern = r"\t*([^\t]+)\t+$"
		), 
		table_elem = _Pattern(
			name = "table_elem", 
			pattern = r"\t*([^\t]+)\t*$"
		)
	)
	# Not used in parsing
	FinalLineComment: _Pattern = _Pattern(
		name = "FinalLineComment", 
		pattern = final_line_comment_pattern()
	)
	InsideLineComment: _Pattern = _Pattern(
		name = "InsideLineComment", 
		pattern = inside_line_comment_pattern()
	)
	initial_tabs: _AuxPattern = _AuxPattern(
		name = "initial_tabs", 
		pattern = r"(\t*)"
	)

@dataclass
class Patterns(_DefaultPatterns): 
	section_marks_unit: InitVar[str] = _DefaultPatterns._default_section_marks_unit
	header_mark: InitVar[str] = _DefaultPatterns._default_header_mark
	library_mark: InitVar[str] = _DefaultPatterns._default_library_mark
	paragraph_mark: InitVar[str] = _DefaultPatterns._default_paragraph_mark
	environments: InitVar[str] = _DefaultPatterns._default_environments
	special_environments: InitVar[str] = _DefaultPatterns._default_special_environments
	term_mark: InitVar[str] = _DefaultPatterns._default_term_mark
	action_error_best_practice_mark: InitVar[str] = _DefaultPatterns._default_action_error_best_practice_mark
	list_mark: InitVar[str] = _DefaultPatterns._default_list_mark
	description_mark: InitVar[str] = _DefaultPatterns._default_description_mark
	line_comment_symbol: InitVar[str] = _DefaultPatterns._default_line_comment_symbol
	block_comment_delimiters: InitVar[str] = _DefaultPatterns._default_block_comment_delimiters
	inline_delimiters: InitVar[InlineDelimiters] = _DefaultPatterns._default_inline_delimiters
	colon_rule_when_no_identifiers: InitVar[str] = _DefaultPatterns._default_colon_rule_when_no_identifiers
	default_list_element_when_no_identifiers: InitVar[str] = _DefaultPatterns._default_default_list_element_when_no_identifiers
	informal_reference_mark: InitVar[str] = _DefaultPatterns._default_informal_reference_mark

	list_env_id = _DefaultPatterns._default_list_env_id
	desc_env_id = _DefaultPatterns._default_desc_env_id
	enum_env_id = _DefaultPatterns._default_enum_env_id
	table_env_id = _DefaultPatterns._default_table_env_id

	def __post_init__(
		self, 
		section_marks_unit, 
		header_mark, 
		library_mark, 
		paragraph_mark, 
		environments, 
		special_environments, 
		term_mark, 
		action_error_best_practice_mark, 
		list_mark, 
		description_mark, 
		line_comment_symbol, 
		block_comment_delimiters, 
		inline_delimiters, 
		colon_rule_when_no_identifiers, 
		default_list_element_when_no_identifiers, 
		informal_reference_mark
	): 
		self.SectionHeader = _Pattern(
			self.SectionHeader.name, 
			pattern = self.section_header_pattern(header_mark = header_mark, section_marks_unit = section_marks_unit)
		)
		self.ParagraphHeader = _Pattern(
			self.ParagraphHeader.name, 
			pattern = self.paragraph_header_pattern(paragraph_mark = paragraph_mark)
		)
		self.LibraryHeader = _Pattern(
			name = self.LibraryHeader.name, 
			pattern = self.library_header_pattern(library_mark = library_mark, section_marks_unit = section_marks_unit)
		)
		env_values_string = environments._get_env_values_string()
		self.StartEnvironment = _Pattern(
			self.StartEnvironment.name, 
			pattern = self.start_environment_pattern(env_values_string = env_values_string)
		)
		self.TextLine = _Pattern(
			self.TextLine.name, 
			pattern = self.text_line_pattern(
				list_mark = list_mark, 
				description_mark = description_mark, 
				mark = term_mark, 
				act_error_bp_mark = action_error_best_practice_mark, 
				section_marks_unit = section_marks_unit, 
				informal_reference_mark = informal_reference_mark, 
				block_comment_mark = block_comment_delimiters[0], 
				line_comment_mark = line_comment_symbol
			)
		)
		self.Terms.simple_term = _Pattern(
			self.Terms.simple_term.name, 
			pattern = self.simple_term_pattern(term_mark = term_mark)
		)
		self.Terms.comma_separated_terms = _Pattern(
			self.Terms.comma_separated_terms.name, 
			pattern = self.comma_separated_terms_pattern(term_mark = term_mark)
		)
		self.Terms.ellipsis_separated_terms = _Pattern(
			self.Terms.ellipsis_separated_terms.name, 
			pattern = self.ellipsis_separated_terms_pattern(term_mark = term_mark)
		)
		self.Terms.final_ellipsis_terms = _Pattern(
			self.Terms.final_ellipsis_terms.name, 
			pattern = self.final_ellipsis_terms_pattern(term_mark = term_mark)
		)
		self.ActionErrorBestPractice = _Pattern(
			self.ActionErrorBestPractice.name, 
			pattern = self.action_error_best_practice_pattern(
				action_error_best_practice_mark = action_error_best_practice_mark
			)
		)
		self.OpenInlineDelimiter = _Pattern(
			self.OpenInlineDelimiter.name, 
			pattern = self.open_inline_delimiters_pattern(inline_delimiters = inline_delimiters)
		)
		self.item_elem = _Pattern(
			self.item_elem.name, 
			pattern = self.item_elem_pattern(
				list_mark = list_mark, 
				description_mark = description_mark
			)
		)
		self.list_elem = _Pattern(
			self.list_elem.name, 
			pattern = self.list_elem_pattern(
				list_mark = list_mark, 
				description_mark = description_mark, 
				colon_rule_when_no_identifiers = colon_rule_when_no_identifiers, 
				default_list_element_when_no_identifiers = default_list_element_when_no_identifiers
			)
		)
		self.DescriptionItems.same_line_desc_elem = _Pattern(
			self.DescriptionItems.same_line_desc_elem.name, 
			pattern = self.same_line_description_elem_pattern(description_mark = description_mark)
		)
		self.DescriptionItems.next_line_desc_elem = _Pattern(
			self.DescriptionItems.next_line_desc_elem.name, 
			pattern = self.next_line_description_elem_pattern(description_mark = description_mark)
		)
		self.DescriptionItems.same_line_desc_elems = _Pattern(
			self.DescriptionItems.same_line_desc_elems.name, 
			pattern = self.same_line_description_elems_pattern(description_mark = description_mark)
		)
		self.DescriptionItems.next_line_desc_elems = _Pattern(
			self.DescriptionItems.next_line_desc_elems.name, 
			pattern = self.next_line_description_elems_pattern(description_mark = description_mark)
		)
		self.OpenBlockComment = _Pattern(
			self.OpenBlockComment.name, 
			pattern = self.open_block_comment_pattern(
				open_block_comment_mark = block_comment_delimiters[0], 
				close_block_comment_mark = block_comment_delimiters[1]
			)
		)
		self.CloseBlockComment = _Pattern(
			self.CloseBlockComment.name, 
			pattern = self.close_block_comment_pattern(close_block_comment_mark = block_comment_delimiters[1])
		)
		self.FullLineComment = _Pattern(
			self.FullLineComment.name, 
			pattern = self.full_line_comment_pattern(line_comment_symbol = line_comment_symbol)
		)
		self.InformalReference = _Pattern(
			self.InformalReference.name, 
			pattern = self.informal_reference_pattern(informal_reference_mark = informal_reference_mark)
		)
		self.FinalLineComment = _Pattern(
			self.FinalLineComment.name, 
			pattern = self.final_line_comment_pattern(
				line_comment_symbol = line_comment_symbol, 
				open_block_comment_mark = block_comment_delimiters[0]
			)
		)
		self.InsideLineComment = _Pattern(
			self.InsideLineComment.name, 
			pattern = self.inside_line_comment_pattern(block_comment_delims = block_comment_delimiters)
		)

		# TODO: change confusing name.
		self.open_close_block_patterns = {
			special_environments.BlockComment.id: self.CloseBlockComment.name, 
			self.OpenBlockComment.name: self.CloseBlockComment.name
		}
		self.open_block_to_block_env = {
			self.OpenBlockComment.name: special_environments.BlockComment.id
		}

	# TODO: make real method using self and not an argument.
	def get_patterns_names(self, patterns: _Patterns): 
		patterns_names = []
		for sub_pattern_field in vars(patterns): 
			sub_pattern_ins = getattr(patterns, sub_pattern_field)
			patterns_names.append(sub_pattern_ins.name)
		return patterns_names