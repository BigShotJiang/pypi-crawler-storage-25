from dataclasses import fields
import re
import copy

from .config import config
from .line_state import LineState, EnvStack, List
from .patterns import _Patterns, _Pattern
from .textline_parser import TextLineParser


class LineAnalyzer: 

	def __init__(self, 
		line_state = LineState(), 
		prev_line_state = LineState()
	):
		self.line_state = line_state
		self.prev_line_state = prev_line_state
		self.textline_parser = TextLineParser(line_state = self.line_state)
		self.patterns = config._patterns

		self.valid_envs = config._identifiers_that_increment_env_stack
		self.item_name_to_env_id = self._get_items_names_to_envs_ids()
		self.item_name_to_implicit_env_id = self._get_items_names_to_envs_ids(implicit_env = True)
		self.item_name_to_after_elem_implicit_env_id = self._get_items_names_to_envs_ids(after_elem_env = True)
		self.terms_identifiers = self.patterns.get_patterns_names(self.patterns.Terms)
		self.action_error_bp_identifiers = [self.patterns.ActionErrorBestPractice.name]
		self.terms_act_err_bp_identifiers = self.terms_identifiers + self.action_error_bp_identifiers
		self.headers_identifiers = [self.patterns.SectionHeader.name, self.patterns.LibraryHeader.name]
		self.headers_terms_act_err_bp_identifiers = self.terms_identifiers + self.action_error_bp_identifiers + self.headers_identifiers
		self.empty_line_identifiers = config.empty_line_identifiers
		self.table_content_identifiers = self.empty_line_identifiers + config._table_elems_identifiers
		self.comments_identifiers = config._comments_identifiers

	def _get_initial_tabs_count(self, line):
		initial_tabs_pattern = self.patterns.initial_tabs.pattern
		tabs_count = re.match(initial_tabs_pattern, line).group(1)
		return tabs_count.count('\t')

	def _match_in_patterns(self, patterns: _Patterns, line): 
		pattern_name = None
		for sub_pattern_field in vars(patterns): 
			sub_pattern_ins = getattr(patterns, sub_pattern_field)
			if result := re.match(sub_pattern_ins.pattern, line):
				self.line_state._match_object = result
				pattern_name = sub_pattern_ins.name
				break
		return pattern_name

	def _get_items_names_to_envs_ids(self, implicit_env = False, after_elem_env = False): 
		item_name_to_env_id = {}

		prefix = config._implicit_env_prefix if implicit_env else ""
		prefix = config._implicit_after_elem_env_prefix + config._implicit_env_prefix if after_elem_env else prefix

		item_name_to_env_id[config._patterns.list_elem.name] = prefix + config._patterns.list_env_id
		item_name_to_env_id[config._patterns.enum_elem.name] = prefix + config._patterns.enum_env_id
		for i in config._patterns.get_patterns_names(config._patterns.DescriptionItems):
			item_name_to_env_id[i] = prefix + config._patterns.desc_env_id
		for i in config._patterns.get_patterns_names(config._patterns.TableItems):
			item_name_to_env_id[i] = prefix + config._patterns.table_env_id
		
		return item_name_to_env_id
	
	def _resolve_reported_item_type(self, state, last_list_elem_state):
		next_line_desc_elem = self.patterns.DescriptionItems.next_line_desc_elem
		next_line_desc_elems = self.patterns.DescriptionItems.next_line_desc_elems
		same_line_desc_elem = self.patterns.DescriptionItems.same_line_desc_elem
		same_line_desc_elems = self.patterns.DescriptionItems.same_line_desc_elems

		if last_list_elem_state == state: return last_list_elem_state

		match last_list_elem_state, state:
			case next_line_desc_elem.name, same_line_desc_elem.name: return last_list_elem_state
			case same_line_desc_elem.name, next_line_desc_elem.name: return last_list_elem_state

			case same_line_desc_elem.name, same_line_desc_elems.name: return state
			case next_line_desc_elem.name, next_line_desc_elems.name: return state
			
			case same_line_desc_elem.name, next_line_desc_elems.name: return same_line_desc_elems.name
			case next_line_desc_elem.name, same_line_desc_elems.name: return next_line_desc_elems.name

			case same_line_desc_elems.name, same_line_desc_elem.name: return state
			case next_line_desc_elems.name, next_line_desc_elem.name: return state

			case same_line_desc_elems.name, next_line_desc_elem.name: return same_line_desc_elem.name
			case next_line_desc_elems.name, same_line_desc_elem.name: return next_line_desc_elem.name

			case same_line_desc_elems.name, next_line_desc_elems.name: return last_list_elem_state
			case next_line_desc_elems.name, same_line_desc_elems.name: return last_list_elem_state

			case x, y: 
				if x and y: raise ValueError(f"Item identifier {x} or {y} cannot be resolved.")
				else: raise ValueError(f"Item identifier cannot be resolved.")

	def _resolve_item(self, line, current_env): 
		prev_identifier = self.prev_line_state.identifier
		prev_nest_level = self.prev_line_state.nest_level
		item_type_stack = self.prev_line_state._item_type_stack
		miss_indent_envs = config._after_elem_implicit_list_like_envs_identifiers
		miss_indent_envs_count = sum(i in miss_indent_envs for i in self.prev_line_state.environment_stack)
		delta_nest_level = self._get_initial_tabs_count(line) - (self.prev_line_state.nest_level - miss_indent_envs_count)

		patterns = self.patterns
		
		# Determine type of all but first list elements.
		self.line_state._first_list_item = False

		last_list_elem_state = item_type_stack.last[1] if item_type_stack else None

		if last_list_elem_state \
		and last_list_elem_state != config.item_type_stack_placeholder \
		and (
			delta_nest_level == 0 
			# Next condition handles most of delta -1 indentation cases, next elif handles the rest.
			or (delta_nest_level == -1 and prev_identifier == patterns.TextLine.name)
		):
			if current_env in config._itemize_like_envs_identifiers \
			or (delta_nest_level == -1 and current_env == patterns.list_elem.name):
				self.line_state._real_item_type = last_list_elem_state
				return last_list_elem_state
			else:
				state = self._match_in_patterns(patterns.DescriptionItems, line)
				self.line_state._real_item_type = state
				return self._resolve_reported_item_type(state, last_list_elem_state)

		elif item_type_stack and delta_nest_level < 0:
			# TODO: caution when there is an implicit after elem environment, verify that works well in that case.
			rev_item_type_stack = copy.deepcopy(item_type_stack)
			rev_item_type_stack.reverse()
			for item in rev_item_type_stack:
				if item[1] != config.item_type_stack_placeholder \
				and prev_nest_level + delta_nest_level == item[0]:
					if item[1] == patterns.list_elem.name:
						self.line_state._real_item_type = item[1]
						return item[1]
					elif state := self._match_in_patterns(patterns.DescriptionItems, line):
						self.line_state._real_item_type = state
						return self._resolve_reported_item_type(state, item[1])
					else: raise ValueError("Description item identifier cannot be resolved.")

		# Determine type of first list element.
		self.line_state._first_list_item = True
		
		# TODO: improve this when change unnecessary default class in patterns.
		list_pattern = patterns.list_elem_pattern(
				list_mark = config.list_mark, 
				description_mark = config.description_mark, 
				colon_rule_when_no_identifiers = config.colon_rule_when_no_identifiers, 
				default_list_element_when_no_identifiers = config.default_list_element_when_no_identifiers, 
				list_env_id = config.environments.List.id, 
				desc_env_id = config.environments.Description.id, 
				env = current_env
			)

		if current_env in config._no_implicit_itemize_like_envs_identifiers \
		or prev_identifier in config._no_implicit_itemize_like_envs_identifiers:
			self.line_state._real_item_type = patterns.list_elem.name
			return patterns.list_elem.name
		elif current_env in config._no_implicit_description_like_envs_identifiers \
		or prev_identifier in config._no_implicit_description_like_envs_identifiers: 
			if result := self._match_in_patterns(patterns.DescriptionItems, line):
				self.line_state._real_item_type = result
				return result
			else: raise ValueError("Item identifier cannot be resolved.")
		elif result := re.match(list_pattern, line):
			self.line_state._match_object = result
			self.line_state._real_item_type = patterns.list_elem.name
			return patterns.list_elem.name
		elif result := self._match_in_patterns(patterns.DescriptionItems, line):
			self.line_state._real_item_type = result
			return result
		else: raise ValueError("Item identifier cannot be resolved.")

	def get_identifier(self, line, stack_env = None):
		line_state = self.line_state
		prev_line_state = self.prev_line_state

		if not stack_env: 
			if not prev_line_state.environment_stack: 
				stack_env = EnvStack([], valid_envs = self.valid_envs)
			else: stack_env = prev_line_state.environment_stack
		
		current_env = stack_env.last
		patterns = self.patterns
		prev_identifier = prev_line_state.identifier
		if not (prev_nest_level := prev_line_state.nest_level):
			prev_nest_level = 0
		
		miss_indent_envs = config._after_elem_implicit_list_like_envs_identifiers
		miss_indent_envs_count = sum(i in miss_indent_envs for i in stack_env)

		delta_nest_level = self._get_initial_tabs_count(line) - (prev_nest_level - miss_indent_envs_count)

		ignore_empty_line_after_identifiers = config.ignore_empty_line_after_identifiers

		ignore_lines_envs_content = \
			config._ignore_lines_envs_content + \
			config._ignore_lines_envs_empty_content + \
			config._ignore_ignored_lines_envs_content
		ignored_line_prefix = config._ignored_line_identifier_prefix
		content_suffix = config._env_content_identifier_suffix
		empty_content_suffix = config._env_content_empty_line_identifier_suffix
		is_empty_line = re.match(patterns.EmptyLine.pattern, line)

		if is_empty_line and prev_identifier in ignore_empty_line_after_identifiers:
			if prev_identifier in config._ignore_lines_envs:
				identifier = ignored_line_prefix + prev_identifier.lower() + empty_content_suffix
			else:
				identifier = ignored_line_prefix + patterns.EmptyLine.name
			return identifier
		elif prev_identifier in config._ignore_lines_envs and delta_nest_level > 0: 
			identifier = prev_identifier.lower() + content_suffix
			return identifier
		elif prev_identifier in ignore_lines_envs_content and (delta_nest_level >= 0 or is_empty_line): 
			if is_empty_line: 
				identifier = current_env.lower() + empty_content_suffix
			else:
				identifier = current_env.lower() + content_suffix
			return identifier
		elif current_env in config._ignore_lines_blocks:
			is_closing_block = re.match(patterns.CloseBlockComment.pattern, line)
			if not is_closing_block:
				if prev_identifier in config._ignore_lines_blocks_content: 
					return prev_identifier
				else: 
					return current_env.lower() + content_suffix
		elif prev_identifier in config._open_ignored_block_identifiers:
			is_closing_block = re.match(patterns.CloseBlockComment.pattern, line)
			if not is_closing_block:
				return self.patterns.open_block_to_block_env[prev_identifier].lower() + content_suffix

		identifier = ""
		env_id = config.environments._get_env_values_to_ids()

		for field in fields(patterns): 
			field_ins = getattr(patterns, field.name)
			
			if isinstance(field_ins, _Pattern): 
				result = re.match(field_ins.pattern, line)
				if result: 
					if field_ins is patterns.StartEnvironment: 
						identifier = env_id[result.group(1)]
					else: identifier = field_ins.name
					line_state._match_object = result
					break
			elif isinstance(field_ins, _Patterns): 
				for sub_field in vars(field_ins): 
					field_sub_ins = getattr(field_ins, sub_field)
					result = re.match(field_sub_ins.pattern, line)
					if result: 
						if field_sub_ins is patterns.StartEnvironment: 
							identifier = env_id[result.group(1)]
						else: identifier = field_sub_ins.name
						break
				
				if result: 
					line_state._match_object = result
					break
		
		# Resolve pending identifier state
		if identifier == patterns.item_elem.name: 
			identifier = self._resolve_item(line, current_env)
		elif current_env == config.environments.Table.id \
		and identifier not in self.table_content_identifiers \
		and delta_nest_level == 0:
			if result := re.match(patterns.TableItems.table_single_elem.pattern, line):
				line_state._match_object = result
				identifier = patterns.TableItems.table_single_elem.name
			else: 
				identifier = None
				raise ValueError("Line {} does not match with any pattern".format(prev_line_state.line_number + 1))
		elif not identifier: 
			raise ValueError("Line {} does not match with any pattern".format(prev_line_state.line_number + 1))
		
		return identifier

	def ignore_line_Q(self, line, stack_env = None, identifier = None): 
		if not identifier: identifier = self.get_identifier(line)
		if not stack_env: 
			if not self.prev_line_state.environment_stack: 
				stack_env = EnvStack([], valid_envs = self.valid_envs)
			else: stack_env = self.prev_line_state.environment_stack

		if not (prev_nest_level := self.prev_line_state.nest_level):
			prev_nest_level = 0
		
		miss_indent_envs = config._after_elem_implicit_list_like_envs_identifiers
		miss_indent_envs_count = sum(i in miss_indent_envs for i in stack_env)

		delta_nest_level = self._get_initial_tabs_count(line) - (prev_nest_level - miss_indent_envs_count)
		
		current_env = None if stack_env == [] else stack_env[-1]

		ignore_lines_envs_content = config._ignore_lines_envs_content + config._ignore_lines_envs_empty_content + config._ignore_ignored_lines_envs_content
		
		ignore_line = identifier in config._ignore_tabs_patterns \
			or identifier in ignore_lines_envs_content \
			or (current_env in config._ignore_lines_envs 
				and delta_nest_level >= 0) \
			or current_env in config._ignore_lines_blocks
		
		return ignore_line

	def update_environment_stack(self, line, identifier = None, stack_env = None): 
		if not identifier: identifier = self.get_identifier(line)
		if stack_env:
			stack_env = copy.copy(stack_env)
		else:
			if not self.prev_line_state.environment_stack: 
				stack_env = EnvStack([], valid_envs = self.valid_envs)
			else: stack_env = copy.copy(self.prev_line_state.environment_stack)

		if not (prev_nest_level := self.prev_line_state.nest_level):
			prev_nest_level = 0
		
		terms_identifiers = self.terms_identifiers
		action_error_bp_identifiers = self.action_error_bp_identifiers
		initial_tabs_count = self._get_initial_tabs_count(line)
		
		miss_indent_envs = config._after_elem_implicit_list_like_envs_identifiers
		miss_indent_envs_count = sum(i in miss_indent_envs for i in stack_env)
		miss_indent_envs_count += 1 if self.line_state._indented_term_content == False else 0

		delta_indent_level = initial_tabs_count - (prev_nest_level - miss_indent_envs_count)

		current_env = None if stack_env == [] else stack_env[-1]

		table_env = config.environments.Table.id
		implicit_table_env = self.item_name_to_implicit_env_id[self.patterns.TableItems.table_row.name]
		after_elem_table_env = self.item_name_to_after_elem_implicit_env_id[self.patterns.TableItems.table_row.name]

		prev_identifier = self.prev_line_state.identifier

		ignore_lines_envs_content = config._ignore_lines_envs_content + config._ignore_lines_envs_empty_content + config._ignore_ignored_lines_envs_content

		_new_environments = []
		_pop_environments = []

		if identifier in config._close_block_identifiers: 
			if prev_identifier not in config._open_block_identifiers:
				if self.patterns.open_close_block_patterns[current_env] == identifier: 
					stack_env.pop()
				else: raise ValueError("Block closing does not correspond with current block.")
			else:
				if self.patterns.open_close_block_patterns[prev_identifier] == identifier: 
					pass
				else: raise ValueError("Block closing does not correspond with current block.")
		elif delta_indent_level >= 2 and not self.ignore_line_Q(line, stack_env, identifier): 
			raise ValueError("Line {}: Cannot increase indentation more than one tab at a time.".format(self.prev_line_state.line_number + 1))
		elif current_env in [table_env, implicit_table_env, after_elem_table_env] \
		and delta_indent_level == 1 \
		and not self.ignore_line_Q(line, stack_env, identifier): 
			raise ValueError("Line {}: Cannot nest anything inside table environment.".format(self.prev_line_state.line_number + 1))
		elif prev_identifier in terms_identifiers and identifier not in terms_identifiers:
			stack_env.append_env(prev_identifier)
			_new_environments.append(prev_identifier)
		elif prev_identifier in action_error_bp_identifiers:
			stack_env.append_env(prev_identifier)
			_new_environments.append(prev_identifier)
		elif prev_identifier in config.environments.ids \
		and (delta_indent_level == 1 or identifier in ignore_lines_envs_content + config._ignore_tabs_patterns): 
			stack_env.append_env(prev_identifier)
			_new_environments.append(prev_identifier)
		elif prev_identifier in config._elem_list_like_identifiers \
		and identifier not in config._elem_list_like_identifiers \
		and (delta_indent_level == 1 or identifier in self.empty_line_identifiers): 
			stack_env.append_env(prev_identifier)
			_new_environments.append(prev_identifier)
		elif prev_identifier in config._open_block_identifiers:
			if prev_identifier == self.patterns.OpenBlockComment.name:
				stack_env.append_env(config.special_environments.BlockComment.id)
				_new_environments.append(config.special_environments.BlockComment.id)
			else:
				stack_env.append_env(prev_identifier)
				_new_environments.append(prev_identifier)
		elif identifier in config._ignore_lines_blocks_content + ignore_lines_envs_content: 
			pass
		elif identifier in config._elem_list_like_identifiers \
		and current_env not in config._list_like_envs_identifiers + config._implicit_list_like_envs_identifiers \
		and delta_indent_level == 1: 
			stack_env.append_env(self.item_name_to_implicit_env_id[identifier])
			_new_environments.append(self.item_name_to_implicit_env_id[identifier])
		elif identifier in config._elem_list_like_identifiers \
		and ((prev_identifier in config._elem_list_like_identifiers 
				and delta_indent_level == 1) \
			or (prev_identifier == self.patterns.EmptyLine.name 
				and delta_indent_level == 0 \
				and current_env not in config.environments.ids + [implicit_table_env, after_elem_table_env]
			)
		): 
			stack_env.append_env(prev_identifier)	# TODO: check if this is correct when prev_identifier is an empty line.
			stack_env.append_env(self.item_name_to_after_elem_implicit_env_id[identifier])
			_new_environments.extend(stack_env[-2:])
		elif identifier in self.empty_line_identifiers: 
			pass
		elif identifier in self.comments_identifiers and delta_indent_level >= 0:
			pass
		elif delta_indent_level == 1 and stack_env == []: 
			stack_env.append_env(config.initial_indent_pseudo_env)
			_new_environments.append(config.initial_indent_pseudo_env)
		elif delta_indent_level < 0: 
			no_indent_envs_count = 0
			stack_copy = stack_env.copy()
			for i in range(delta_indent_level, 0):
				if stack_env[i] in config._after_elem_implicit_list_like_envs_identifiers: 
					del stack_env[i]
					no_indent_envs_count += 1
			_pop_environments.extend(stack_copy[delta_indent_level - no_indent_envs_count:])
			del stack_env[delta_indent_level:]
		
		return stack_env, _new_environments, _pop_environments

	def _update_item_type_stack(self, identifier, _new_environments, _pop_environments):
		item_type_stack = copy.copy(self.prev_line_state._item_type_stack) \
			if self.prev_line_state._item_type_stack else List()
		nest_level = self.line_state.nest_level

		for env in _pop_environments: 
			if env in config._itemize_and_description_like_envs_identifiers:
				item_type_stack.pop()

		for env in _new_environments:
			if env in config._itemize_and_description_like_envs_identifiers:
				if identifier in config._itemize_and_description_elem_list_like_identifiers:
					item_type_stack.append([nest_level, identifier])
				else: item_type_stack.append([nest_level, config.item_type_stack_placeholder])
		
		if item_type_stack.last and item_type_stack.last[1] == config.item_type_stack_placeholder \
		and identifier in config._itemize_and_description_elem_list_like_identifiers:
			item_type_stack.last[1] = identifier
		
		return item_type_stack

	def _get_nest_level(self, stack_env = None): 
		if stack_env is None: 
			stack_env = EnvStack([], valid_envs = self.valid_envs)
		return len(stack_env)

	def _is_indented_term_act_err_bp_content(self, line):
		prev_state = self.prev_line_state
		prev_env_stack = prev_state.environment_stack if prev_state.environment_stack else EnvStack([])
		identifier = self.line_state.identifier

		if (prev_state._indented_term_content is None 
			and (
				prev_env_stack.first not in self.terms_act_err_bp_identifiers 
				and prev_state.identifier not in self.terms_act_err_bp_identifiers
			)
		) or identifier in self.headers_terms_act_err_bp_identifiers:
			return None
		elif prev_state._indented_term_content is not None \
		and prev_env_stack.first in self.terms_act_err_bp_identifiers:
			return prev_state._indented_term_content
		elif prev_state._indented_term_content is None \
		and (prev_env_stack.first in self.terms_act_err_bp_identifiers 
			or (prev_state.identifier in self.terms_act_err_bp_identifiers 
				and identifier not in self.terms_identifiers)
		):
			if identifier not in self.empty_line_identifiers:
				if self._get_initial_tabs_count(line) == 0: 
					return False
				else: 
					return True
			else: 
				return prev_state._indented_term_content
		elif prev_state._indented_term_content is not None \
		and (prev_env_stack.first not in self.terms_act_err_bp_identifiers 
	   		or identifier in self.terms_act_err_bp_identifiers):
			return None
		else:
			raise ValueError("Can't determine if it's indented content.")

	def update_library_headers(self, identifier, prev_identifier):
		library_header = config._patterns.LibraryHeader
		
		if identifier == library_header.name:
			library_title = self.line_state._match_object.group(2)

			if prev_identifier == library_header.name:
				marks = self.line_state._match_object.group(1)
				prev_marks = self.prev_line_state._match_object.group(1)
				if marks == prev_marks:
					self.line_state._library_headers = self.prev_line_state._library_headers.copy()
					self.line_state._library_headers.append(library_title)
				else:
					self.line_state._library_headers = [library_title]
			else:
				self.line_state._library_headers.append(library_title)
		else:
			if self.line_state._library_headers != []:
				self.line_state._library_headers = []

	def update_table_metadata(self, identifier):
		line_state = self.line_state

		if line_state.environment_stack.last not in config._table_like_envs_identifiers:
			if set(config._table_like_envs_identifiers) & set(line_state._pop_environments):
				line_state._table_metadata["last_row"] = True
				line_state._table_metadata["first_row"] = None
				line_state._table_metadata["num_columns"] = None
			elif line_state._table_metadata["last_row"]:
				line_state._table_metadata["last_row"] = None
		elif identifier in config._table_elems_identifiers \
		and not line_state._table_metadata["num_columns"]:
			if identifier == self.patterns.TableItems.table_row.name:
				row_cells = self.line_state._match_object.group(1)
				row_cells = row_cells.split('\t')
				row_cells = [i for i in row_cells if i != ""]
				line_state._table_metadata["num_columns"] = len(row_cells)
			else:
				line_state._table_metadata["num_columns"] = 1
			
			line_state._table_metadata["first_row"] = True
			line_state._table_metadata["last_row"] = False
		else:
			line_state._table_metadata["first_row"] = False
			line_state._table_metadata["last_row"] = False

	def set_line_state(self, line, prev_line_state = None): 
		if not prev_line_state: 
			prev_line_state = self.prev_line_state
		
		line_state = self.line_state

		line_state.line = line
		line_state.line_number = 1 if not prev_line_state.line_number else prev_line_state.line_number + 1

		if config.line_comment_symbol in line:
			uncommented_line, end_comment = self.textline_parser.light_purge_end_line_comments(line)
			if end_comment: line = uncommented_line
		
		line_state.identifier = self.get_identifier(line, prev_line_state.environment_stack)

		line_state._indented_term_content = self._is_indented_term_act_err_bp_content(line)

		line_state.environment_stack, \
		line_state._new_environments, \
		line_state._pop_environments = \
			self.update_environment_stack(
				line, 
				line_state.identifier, 
				prev_line_state.environment_stack
			)

		self.update_library_headers(line_state.identifier, prev_line_state.identifier)
		self.update_table_metadata(line_state.identifier)

		line_state.nest_level = self._get_nest_level(line_state.environment_stack)

		line_state._item_type_stack = self._update_item_type_stack(
			line_state.identifier, 
			line_state._new_environments, 
			line_state._pop_environments
		)
		
		# TODO: apply similar actions for `inline_delimiters_stack`, which should be based on line identifier, as text line parser.
		if line_state.identifier == self.patterns.TextLine.name:
			line_state.inline_delimiters_stack = self.textline_parser.get_inline_delimiters_stack(line)
		else: line_state.inline_delimiters_stack = []

		if line_state.identifier == self.patterns.CloseBlockComment.name \
		and line_state.nest_level - prev_line_state.nest_level not in [-1, 0]: 
			raise ValueError("Cannot close block comment at a different nesting level.")

	def update_line_state(self, line): 
		self.prev_line_state = copy.deepcopy(self.line_state)
		self.set_line_state(line, self.prev_line_state)

		return self.line_state