# TODO

Next, a to-do list with next implementations for future versions is presented, ordered by priority:

- [ ] Keywords glossary.
- [ ] Lists (table of contents) of specific actions, errors and best practices, by section.
- [ ] Cross references to sections, keywords, specific actions, errors, best practices, etc.
- [ ] Environments arguments, to modify features like the programming language used, style, etc.
- [ ] Optional panel to show code environments output.
- [ ] Checkbox list environment.
- [ ] Support for emojis.
- [ ] Default code environment styles (in addition to current title bar style).
- [ ] Adjust some vertical spacings between elements.
- [ ] Special delimiters or optional delimiter argument implementation to indicate the programming language to be used in inline code.
- [ ] Flag feature to enable or disable the used programming language for inline code.
- [ ] Characters `─`, `│`, `└` and `├` are not being translated to output file.
- [ ] Allow user adding code environments, and add more configurations to modify their style.
- [ ] Fix inline code to support long inline code without invade the document margin.
- [ ] Default code style for description elements in *Options*, *Arguments*, etc., environments, which can be modified through environments arguments when they are implemented.
- [ ] Special symbol for keywords that requires a special format.
- [ ] Delimiters analogous to `f"..."`, `k"..."`, etc., to format error, warning and info messages, for instance, coloring their content in red, yellow and blue.
- [ ] Implement nextline stacked description elements format.
- [ ] Environment or pattern to insert images.
- [ ] Multi-column environment.
- [ ] Invisible delimiters to color content of environments like `equation`, `tikzpicture`, etc., in $\LaTeX$ syntax highlighting.
- [ ] Make indentation after first line of a list element content or for content of keywords, specific actions, etc., in `TXT` to be optional.
- [ ] Support for large vertical and horizontal tables, to be divided in several pages, preventing them getting off the page.
- [ ] Special arguments for table environments (when environment arguments are implemented) to indicate their format, and predefined environments that apply the most used ones.
- [ ] Show complementary information on the right side of code environment title bar, like the current language, a copy button, etc.
- [ ] Button to copy an environment code, which could be placed in the right side of the title bar or in a corner in the code frame, and also a configuration option to show it or not.
- [ ] CLI subcommand `get-example` to get a `TXT` example for quick tests or to test the package commands for first time.
- [ ] Format and parser for formal references, placing them in an output $\text{Bib}\TeX$ file.
