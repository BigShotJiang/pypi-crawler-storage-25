# Mimir

**The personal agent operating system. Self-hosted. Multi-agent.
Auditable for every decision your team makes.**

Mimir is the supervisor that lives on your VPS. He spawns specialist agents on
demand — each with bounded vault access, scoped skills, and a verifiable audit
trail. He learns from your workflow, trains his team from theirs, and lets you
replay or branch any agent's decision.

You supervise Mimir. Mimir supervises the team.

> **Status:** v0.0.1 — namespace placeholder. Public alpha targets July 2026.
> Substrate ([persistence-os](https://github.com/nawsaafa/persistence-os))
> v0.8.5a1 shipped, 2093 tests passing. Mimir's user-facing surfaces (spawn /
> train / supervise / audit-export) land Phase D of the 14-week ship plan.

---

## Install

Paste this into Claude Code (once `v0.1.0` ships):

```
/mimir install
```

Claude Code will provision Mimir on your VPS or local machine, mint your
Ed25519 keys, wire up your MCP, and start the agent loop. 90 seconds, end to
end.

→ [Watch the install demo](https://mimir-os.com/demo) (1:32) — *coming Week 12*

## Six things Mimir does

**1. Spawns specialists under your authority.**
```bash
mimir spawn --scope "watch my GitHub PRs and summarize once per hour" --tier SAFE
✓ child[watcher-7af1] running. token=t-... skills=[gh-fetch, summarize]
```

**2. Trains them from their audit logs.** When a child accomplishes something
well, Mimir distills the pattern into a skill, runs it through four promotion
gates (replay byte-identity, audit-chain integrity, score delta on held-out
tasks, stub coverage), and registers it in that child's library.

```bash
mimir train watcher-7af1
analyzing 247 audit entries from last 24h...
candidate skill: "filter promotional PR comments before summarizing"
running gates: G1 ✓  G2 ✓  G3 ✓ (Δ score +0.18)  G4 ✓
✓ promoted. watcher-7af1 now has 3 skills.
```

**3. Coordinates them via software-transactional memory.** Two children that
need shared state (scribe writing email-summaries, courier updating calendar
from them) commit atomically — either both ship or neither does.

**4. Forks-and-votes when uncertain.** Mimir spawns N children to try N
approaches, scores them, commits only the winner's facts. The N-1 losing
branches leave zero trace in your vault history.

**5. Filters every read by tier.** Each child has a Mom-tier capability token
(PUBLIC / SAFE / SENSITIVE / PII). Vault queries are filtered server-side; a
SAFE-tier child literally cannot read PII datoms even if it tries.

**6. Audits everything end-to-end.** Every spawn, every read, every write,
every halt — one Ed25519-signed datom in a Merkle-chained log spanning the
whole fleet.

```bash
mimir verify chain.edn
✓ Chain valid. 1,247 events. Root hash 0xa8f2c1d4...

mimir replay --agent watcher-7af1 --from chain://event-1247
mimir branch --agent watcher-7af1 --from chain://event-1247
mimir export --format=eu-ai-act --from 2026-05-01 --to 2026-08-01
```

## A first-in-class memory graph

Bitemporal datoms (Datomic-style) underneath; an Obsidian-grade graph view on
top. Search by tag, full-text, vector proximity, or graph distance. Tier ×
bucket taxonomy with biomimetic decay so old context doesn't drown new
context. Mom-tier security classification (PUBLIC / SAFE / SENSITIVE / PII)
on every memory.

## Multi-platform reach

Talk to Mimir from WhatsApp, Slack, Telegram, iMessage, or email. Same memory,
same audit chain, every platform.

```bash
mimir adapter add whatsapp --twilio-sid AC...
mimir adapter add slack --workspace acme.slack.com
```

## Pricing

| Tier | Price | What you get |
|---|---|---|
| **Self-hosted** | Free / Apache 2 | Everything above. Run the Docker image on your VPS. |
| **Mimir Pro** | $29/mo | Hosted Ed25519 retention (90d), email support, multi-device sync, web UI access. |
| **Mimir Team** | $199/mo (5 seats) | Shared memory graph, RBAC, team audit dashboard, 1y retention. |
| **Mimir Compliance** | $2,500/mo | EU residency, ISO/IEC 24970 mapping, expert-witness export, dedicated tenant, SLAs, SSO. |

The OSS tier is the funnel. The Compliance tier funds development.

## Three things only Mimir can do

```python
# 1. Branch any audit point at datom granularity
mimir branch --agent watcher-7af1 --from chain://event-1247

# 2. Replay any decision deterministically
mimir replay --agent watcher-7af1 --from chain://event-1247 \
              --intervene tool=write_file:/etc/foo

# 3. Export an EU AI Act Article 12 evidence package
mimir export --format=eu-ai-act --from 2026-05-01 --to 2026-08-01 > evidence.tar.gz
```

[Hermes-agent](https://github.com/NousResearch/hermes-agent) (Nous Research,
129K stars) only supports `/undo` and cannot do any of these without a
substrate rewrite. Letta, Mem0, and AnythingLLM have memory but no audit
chain. Cursor, Cline, and Aider have neither memory nor audit at the substrate
layer.

## Why Mimir exists

Built by Nawfal Saadi — Director of Business Development MENA & Green Hydrogen
at Scatec ASA, running a multi-billion-dollar megaproject. After 9 months of
9pm-to-4am evenings in Casablanca building the substrate that would let his
own team's agents survive cross-shift handoffs without losing context, Mimir
is what came out.

The duality of operator + builder is the thesis: agents that pass an auditor's
test deserve to be in production. Agents that don't, don't.

In Norse myth, after Mimir's death, Odin preserves his head and consults it
as an oracle for every major decision. *That's the relationship you have
with your agents now.*

## Architecture

Mimir bundles four open-source projects under one Docker image:

- **[persistence-os](https://github.com/nawsaafa/persistence-os)** — the
  bitemporal substrate (datom log, plan AST, audit chain, DB.fork, replay
  engine). AGPL-3.
- **ai-box memory graph** — tier × bucket vault with biomimetic decay and
  Mom security tiers. (Source published Phase E.)
- **juba-bridge multi-platform** — WhatsApp / Slack / Telegram / iMessage /
  email adapters. (Source published Phase E.)
- **persistence-coder** — the agent loop that powers Mimir and his children.

Mimir itself is the supervisor + capability-tier filter + skill curator +
CLI surface that ties them together.

→ [Architecture deep-dive](https://mimir-os.com/arch) — *coming Week 12*

## Roadmap

| Phase | Target | Deliverable |
|---|---|---|
| A | Week 1 | persistence-os pushed to public origin; mimir-os repos seeded; namespaces locked. |
| B | Weeks 2-3 | Ed25519 audit signing on substrate; tamper-evident demo video. |
| C | Weeks 4-6 | persistence-coder MVP `v0.9.0a1`; wrong-path-steering demo video. |
| D | Weeks 7-11 | Mimir bundle: supervisor, tiered vault, install skill, agent fleet UI, six CLI verbs. |
| E | Weeks 12-13 | Public launch: HN, ProductHunt, PyPI release, Docker image, install command. |
| F | Week 14 | Mimir Compliance tier: EU AI Act Article 12 export; first paid pilots. |

## License

Mimir (this repo) is **Apache 2.0**. The substrate underneath
([persistence-os](https://github.com/nawsaafa/persistence-os)) is **AGPL-3** —
copyleft, runtime use unencumbered, only forks-into-closed-products
restricted. Commercial license available for vertical integrators.

```
pip install mimir-os                    # PyPI
docker pull mimiros/mimir-os:latest     # Docker Hub (registry namespace differs)
/mimir install                          # Anthropic Skill, in any Claude Code session
```

---

**Substrate:** [`nawsaafa/persistence-os`](https://github.com/nawsaafa/persistence-os) ·
**Docs:** [mimir-os.com](https://mimir-os.com) ·
**Contact:** nawfal.saadi@aiconsults.io
