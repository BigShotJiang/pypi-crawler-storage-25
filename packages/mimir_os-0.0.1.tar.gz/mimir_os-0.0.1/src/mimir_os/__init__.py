"""Mimir — the personal agent operating system.

Self-hosted. Multi-agent. Auditable for every decision your team makes.

This is the v0.0.1 namespace placeholder. The full surface lands in v0.1.0.

See: https://github.com/mimir-os/mimir-os
     https://mimir-os.com
"""

__version__ = "0.0.1"
__all__ = ["__version__"]
