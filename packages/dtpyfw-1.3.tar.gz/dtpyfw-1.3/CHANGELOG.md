# Changelog

All notable changes to `dtpyfw` are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## Versions

| Version | Date | Highlights |
|---|---|---|
| [1.0](docs/changelogs/1.0.md) | 2026-04-24 | Python 3.13, full audit pass, production-stable — first stable release |
