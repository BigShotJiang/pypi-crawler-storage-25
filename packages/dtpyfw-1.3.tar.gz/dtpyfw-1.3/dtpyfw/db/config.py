"""Configuration builder for :mod:`dtpyfw.db` utilities."""

from typing import Any, Self

from ..core.coerce import coerce_bool
from ..core.config import ConfigBuilder

__all__ = ("DatabaseConfig",)


class DatabaseConfig(ConfigBuilder):
    """Simple builder for SQLAlchemy connection settings.

    This class provides a fluent interface for configuring database
    connections, supporting both synchronous and asynchronous drivers,
    connection pooling, and separate read/write database configurations.
    """

    def __init__(self) -> None:
        """Initialize DatabaseConfig with default settings."""
        super().__init__()
        self._config.update({
            "db_backend": "postgresql",
            "db_driver_async": "asyncpg",
            "connect_args": None,
        })

    def set_db_backend(self, db_backend: str) -> Self:
        """Set the database backend.

        Args:
            db_backend: Database backend type (e.g., 'postgresql', 'mysql').

        Returns:
            Self for method chaining.
        """
        self._config["db_backend"] = db_backend
        return self

    def set_db_driver_sync(self, db_driver_sync: str) -> Self:
        """Set the synchronous database driver.

        Args:
            db_driver_sync: Synchronous driver name (e.g., 'psycopg2').

        Returns:
            Self for method chaining.
        """
        self._config["db_driver_sync"] = db_driver_sync
        return self

    def set_db_driver_async(self, db_driver_async: str) -> Self:
        """Set the asynchronous database driver.

        Args:
            db_driver_async: Asynchronous driver name (e.g., 'asyncpg').

        Returns:
            Self for method chaining.
        """
        self._config["db_driver_async"] = db_driver_async
        return self

    def set_connect_args(self, connect_args: dict[str, Any]) -> Self:
        """Set extra connection arguments for the database driver.

        Args:
            connect_args: Dictionary of driver-specific connection arguments.

        Returns:
            Self for method chaining.
        """
        self._config["connect_args"] = connect_args
        return self

    def set_db_url(self, db_url: str) -> Self:
        """Set full database URL for both read and write operations.

        Args:
            db_url: Complete database connection URL string.

        Returns:
            Self for method chaining.
        """
        self._config["db_url"] = db_url
        return self

    def set_db_url_read(self, db_url_read: str) -> Self:
        """Set a read-only database URL.

        If not provided, the write URL will be used for read operations.

        Args:
            db_url_read: Database URL for read-only operations.

        Returns:
            Self for method chaining.
        """
        self._config["db_url_read"] = db_url_read
        return self

    def set_db_user(self, db_user: str) -> Self:
        """Set the database username.

        Args:
            db_user: Database username for authentication.

        Returns:
            Self for method chaining.
        """
        self._config["db_user"] = db_user
        return self

    def set_db_password(self, db_password: str) -> Self:
        """Set the database password.

        Args:
            db_password: Database password for authentication.

        Returns:
            Self for method chaining.
        """
        self._config["db_password"] = db_password
        return self

    def set_db_host(self, db_host: str) -> Self:
        """Set the database host for write operations.

        Args:
            db_host: Hostname or IP address of the database server.

        Returns:
            Self for method chaining.
        """
        self._config["db_host"] = db_host
        return self

    def set_db_host_read(self, db_host_read: str) -> Self:
        """Set the database host for read-only operations.

        Args:
            db_host_read: Hostname or IP address for read replicas.

        Returns:
            Self for method chaining.
        """
        self._config["db_host_read"] = db_host_read
        return self

    def set_db_port(self, db_port: int | str) -> Self:
        """Set the database port.

        Args:
            db_port: Port number for database connections. Accepts int or string
                (as returned by ``Env.get()``).

        Returns:
            Self for method chaining.
        """
        self._config["db_port"] = int(db_port)
        return self

    def set_db_name(self, db_name: str) -> Self:
        """Set the database name.

        Args:
            db_name: Name of the database to connect to.

        Returns:
            Self for method chaining.
        """
        self._config["db_name"] = db_name
        return self

    def set_db_ssl(self, db_ssl: bool) -> Self:
        """Enable or disable SSL for the database connection.

        Args:
            db_ssl: True to enable SSL/TLS, False to disable.

        Returns:
            Self for method chaining.
        """
        self._config["db_ssl"] = db_ssl
        return self

    def set_db_pool_size(self, db_pool_size: int | str) -> Self:
        """Set the database connection pool size.

        Args:
            db_pool_size: Maximum number of connections in the pool. Accepts int
                or string (as returned by ``Env.get()``).

        Returns:
            Self for method chaining.
        """
        self._config["db_pool_size"] = int(db_pool_size)
        return self

    def set_db_max_overflow(self, db_max_overflow: int | str) -> Self:
        """Set the database connection pool overflow limit.

        Args:
            db_max_overflow: Maximum number of connections beyond pool_size.
                Accepts int or string (as returned by ``Env.get()``).

        Returns:
            Self for method chaining.
        """
        self._config["db_max_overflow"] = int(db_max_overflow)
        return self

    @classmethod
    def from_env(cls, prefix: str = "db_") -> Self:
        """Build a DatabaseConfig from environment variables.

        Reads standard database connection parameters from the environment
        using the given prefix. Variables read (with default prefix ``db_``):
        ``db_host``, ``db_port``, ``db_user``, ``db_password``, ``db_name``,
        ``db_pool_size``, ``db_host_read``, ``db_ssl``.

        All variables must be registered via ``Env.register()`` before calling
        this method (``load_file`` silently ignores unregistered vars).

        Args:
            prefix: Prefix for the environment variable names. Defaults to
                ``"db_"``.  Pass ``"read_db_"`` to read a secondary replica
                config.

        Returns:
            A configured ``DatabaseConfig`` instance ready to pass to
            ``DatabaseInstance``.

        Example::

            Env.register(["db_host", "db_port", "db_user", "db_password",
                          "db_name", "db_pool_size", "db_ssl"])
            Env.load_file(".env")
            db_config = DatabaseConfig.from_env()
            database = DatabaseInstance(config=db_config)
        """
        from ..core.env import Env

        config = (
            cls()
            .set_db_host(Env.get(f"{prefix}host", ""))
            .set_db_port(Env.get(f"{prefix}port", "5432"))
            .set_db_user(Env.get(f"{prefix}user", ""))
            .set_db_password(Env.get(f"{prefix}password", ""))
            .set_db_name(Env.get(f"{prefix}name", ""))
        )
        if pool_size := Env.get(f"{prefix}pool_size"):
            config = config.set_db_pool_size(pool_size)
        if host_read := Env.get(f"{prefix}host_read"):
            config = config.set_db_host_read(host_read)
        if url_read := Env.get(f"{prefix}url_read"):
            config = config.set_db_url_read(url_read)
        if (ssl_val := Env.get(f"{prefix}ssl")) is not None:
            config = config.set_db_ssl(coerce_bool(ssl_val))
        return config
