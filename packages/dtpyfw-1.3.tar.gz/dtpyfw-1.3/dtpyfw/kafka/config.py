from typing import Self

from ..core.coerce import coerce_bool
from ..core.config import ConfigBuilder


class KafkaConfig(ConfigBuilder):
    """Builder for Kafka connection settings.

    A configuration builder that supports both full URL-based
    configuration and individual parameter-based configuration for Kafka
    clients. Provides a fluent interface for setting connection
    parameters.
    """

    def set_kafka_url(self, url: str) -> Self:
        """Set the full Kafka connection URL.

        Provide a complete Kafka URL with authentication and multiple brokers.
        This method simplifies configuration when all connection details can
        be expressed in a single URL string.

        Args:
            url: Complete Kafka URL in format
                 'kafka://user:pass@host1:9092,host2:9092'

        Returns:
            Self reference for method chaining.
        """
        self._config["kafka_url"] = url
        return self

    def set_bootstrap_servers(self, servers: list[str]) -> Self:
        """Set the list of Kafka bootstrap servers.

        Configure the initial Kafka broker addresses used to discover
        the full cluster membership.

        Args:
            servers: List of broker addresses in 'host:port' format.

        Returns:
            Self reference for method chaining.
        """
        self._config["bootstrap_servers"] = servers
        return self

    def set_security_protocol(self, protocol: str) -> Self:
        """Set the security protocol for broker communication.

        Defines the protocol used to communicate with brokers, determining
        encryption and authentication requirements.

        Args:
            protocol: Protocol name such as 'PLAINTEXT', 'SSL', 'SASL_PLAINTEXT',
                     or 'SASL_SSL'.

        Returns:
            Self reference for method chaining.
        """
        self._config["security_protocol"] = protocol
        return self

    def set_sasl_mechanism(self, mechanism: str) -> Self:
        """Set the SASL authentication mechanism.

        Specifies which SASL mechanism to use for authentication when
        using SASL-based security protocols.

        Args:
            mechanism: SASL mechanism name such as 'PLAIN', 'SCRAM-SHA-256',
                      'SCRAM-SHA-512', or 'GSSAPI'.

        Returns:
            Self reference for method chaining.
        """
        self._config["sasl_mechanism"] = mechanism
        return self

    def set_sasl_plain_username(self, username: str) -> Self:
        """Set the username for PLAIN SASL authentication.

        Configures the username credential used with SASL/PLAIN
        authentication mechanism.

        Args:
            username: Authentication username for SASL/PLAIN.

        Returns:
            Self reference for method chaining.
        """
        self._config["sasl_plain_username"] = username
        return self

    def set_sasl_plain_password(self, password: str) -> Self:
        """Set the password for PLAIN SASL authentication.

        Configures the password credential used with SASL/PLAIN
        authentication mechanism.

        Args:
            password: Authentication password for SASL/PLAIN.

        Returns:
            Self reference for method chaining.
        """
        self._config["sasl_plain_password"] = password
        return self

    def set_client_id(self, client_id: str) -> Self:
        """Set the client identifier for Kafka connections.

        Assigns a logical identifier for the client application, which
        appears in broker logs and metrics.

        Args:
            client_id: Unique identifier for this Kafka client application.

        Returns:
            Self reference for method chaining.
        """
        self._config["client_id"] = client_id
        return self

    def set_group_id(self, group_id: str) -> Self:
        """Set the consumer group identifier.

        Assigns the consumer group ID for coordinating consumption across
        multiple consumer instances. Required for consumer applications.

        Args:
            group_id: Unique identifier for the consumer group.

        Returns:
            Self reference for method chaining.
        """
        self._config["group_id"] = group_id
        return self

    def set_auto_offset_reset(self, offset: str) -> Self:
        """Set the auto offset reset policy.

        Defines what to do when there is no initial offset in Kafka or if
        the current offset no longer exists on the server.

        Args:
            offset: Reset policy - 'earliest' to reset to the beginning,
                   'latest' to reset to the end, or 'none' to throw exception.

        Returns:
            Self reference for method chaining.
        """
        self._config["auto_offset_reset"] = offset
        return self

    def set_enable_auto_commit(self, flag: bool | str) -> Self:
        """Enable or disable automatic offset committing.

        Controls whether consumed message offsets are automatically
        committed to Kafka or must be manually committed.

        Args:
            flag: True to enable auto-commit, False to require manual commits.
                Accepts bool or string ("true"/"false"/"1"/"0").

        Returns:
            Self reference for method chaining.
        """
        self._config["enable_auto_commit"] = coerce_bool(flag)
        return self

    @classmethod
    def from_env(cls, prefix: str = "kafka_") -> Self:
        """Build a KafkaConfig from environment variables.

        Args:
            prefix: Env var prefix. Defaults to "kafka_".
                    Reads {prefix}url, {prefix}brokers, {prefix}user,
                    {prefix}password, {prefix}group_id, {prefix}auto_offset_reset,
                    {prefix}security_protocol, {prefix}sasl_mechanism.

        Returns:
            Configured KafkaConfig instance.
        """
        from ..core.env import Env

        config = cls()
        if url := Env.get(f"{prefix}url"):
            config = config.set_kafka_url(url)
        elif brokers := Env.get(f"{prefix}brokers"):
            config = config.set_bootstrap_servers(brokers.split(","))
        if protocol := Env.get(f"{prefix}security_protocol"):
            config = config.set_security_protocol(protocol)
        if mechanism := Env.get(f"{prefix}sasl_mechanism"):
            config = config.set_sasl_mechanism(mechanism)
        if username := Env.get(f"{prefix}user"):
            config = config.set_sasl_plain_username(username)
        if password := Env.get(f"{prefix}password"):
            config = config.set_sasl_plain_password(password)
        if group_id := Env.get(f"{prefix}group_id"):
            config = config.set_group_id(group_id)
        if offset_reset := Env.get(f"{prefix}auto_offset_reset"):
            config = config.set_auto_offset_reset(offset_reset)
        return config
