"""Retry utilities for functions with exponential backoff."""

import asyncio
import inspect
import random
import time
from collections.abc import Awaitable, Callable
from functools import wraps
from typing import Any, TypeVar

from ..log import footprint
from .exception import exception_to_dict
from .jsonable_encoder import jsonable_encoder

__all__ = (
    "retry_async",
    "retry",
    "retry_wrapper",
)

T = TypeVar("T")


async def retry_async(
    func: Callable[..., Awaitable[T]],
    *args: Any,
    sleep_time: int | float = 2,
    max_attempts: int = 3,
    backoff: int | float = 2,
    exceptions: tuple[type[Exception], ...] = (Exception,),
    log_tries: bool = False,
    **kwargs: Any,
) -> T:
    """Retry an async function with exponential backoff.

    Description:
        Executes an async callable with automatic retry logic. On failure,
        waits with exponentially increasing delay before retrying. Logs
        final failures to footprint.

    Args:
        func: The async callable to execute.
        *args: Positional arguments to pass to func.
        sleep_time: Initial delay in seconds between retries.
        max_attempts: Maximum number of attempts before giving up.
        backoff: Multiplier for increasing delay after each retry.
        exceptions: Tuple of exception types to catch and retry.
        log_tries: If True, logs warnings for each retry attempt.
        **kwargs: Keyword arguments to pass to func.

    Returns:
        The result from the successful function execution.

    Raises:
        Exception: The caught exception if all retry attempts fail.
    """
    controller = f"{__name__}.retry_async"
    delay = sleep_time
    for attempt in range(1, max_attempts + 1):
        try:
            return await func(*args, **kwargs)
        except exceptions as e:
            error_dict = exception_to_dict(e)
            error_dict["kwargs"] = jsonable_encoder(kwargs)
            error_dict["args"] = jsonable_encoder(args)
            if attempt == max_attempts:
                footprint.leave(
                    log_type="error",
                    message=f"We could not finish the current job in the function {func.__name__}.",
                    controller=controller,
                    subject=f"Error at {func.__name__}",
                    payload=error_dict,
                )
                raise
            elif log_tries:
                footprint.leave(
                    log_type="warning",
                    message=f"An error happened while we retry to run {func.__name__} at the {attempt} attempt{'s' if attempt > 1 else ''}.",
                    controller=controller,
                    subject=f"Warning at retrying {func.__name__}",
                    payload=error_dict,
                )
            await asyncio.sleep(delay)
            delay *= backoff
    # This should never be reached, but satisfies type checker
    raise RuntimeError("Retry logic failed unexpectedly")


def retry(
    func: Callable[..., T],
    *args: Any,
    sleep_time: int | float = 2,
    max_attempts: int = 3,
    backoff: int | float = 2,
    exceptions: tuple[type[Exception], ...] = (Exception,),
    log_tries: bool = False,
    max_total_time: float | None = None,
    jitter: bool = False,
    **kwargs: Any,
) -> T:
    """Retry a synchronous callable with exponential backoff.

    Description:
        Executes a callable with automatic retry logic. On failure, waits
        with exponentially increasing delay before retrying. Raises
        ``TypeError`` immediately if the function is async — use
        ``retry_async`` or ``retry_wrapper`` for coroutines.

    Args:
        func: The synchronous callable to execute.
        *args: Positional arguments to pass to func.
        sleep_time: Initial delay in seconds between retries.
        max_attempts: Maximum number of attempts before giving up.
        backoff: Multiplier for increasing delay after each retry.
        exceptions: Tuple of exception types to catch and retry.
        log_tries: If True, logs warnings for each retry attempt.
        max_total_time: Optional budget in seconds. When set, retrying stops
            if the elapsed wall-clock time exceeds this value before the next
            attempt, and the last exception is re-raised.
        jitter: When True, adds a random 0–50% fraction of the current wait
            time to each sleep duration to spread retry storms.
        **kwargs: Keyword arguments to pass to func.

    Returns:
        The result from the successful function execution.

    Raises:
        TypeError: If ``func`` is a coroutine function.
        Exception: The caught exception if all retry attempts fail.
    """
    if inspect.iscoroutinefunction(func):
        raise TypeError("retry() does not support async functions — use retry_async() instead")

    controller = f"{__name__}.retry"
    delay = sleep_time
    start_time = time.monotonic() if max_total_time is not None else None

    for attempt in range(1, max_attempts + 1):
        try:
            return func(*args, **kwargs)
        except exceptions as e:
            error_dict = exception_to_dict(e)
            error_dict["kwargs"] = jsonable_encoder(kwargs)
            error_dict["args"] = jsonable_encoder(args)
            if attempt == max_attempts:
                footprint.leave(
                    log_type="error",
                    message=f"We could not finish the current job in the function {func.__name__}.",
                    controller=controller,
                    subject=f"Error at {func.__name__}",
                    payload=error_dict,
                )
                raise
            elif log_tries:
                footprint.leave(
                    log_type="warning",
                    message=f"An error happened while we retry to run {func.__name__} at the {attempt} attempt{'s' if attempt > 1 else ''}.",
                    controller=controller,
                    subject=f"Warning at retrying {func.__name__}",
                    payload=error_dict,
                )
            if start_time is not None and max_total_time is not None:
                if time.monotonic() - start_time >= max_total_time:
                    raise
            actual_sleep = delay + (random.uniform(0, delay * 0.5) if jitter else 0)
            time.sleep(actual_sleep)
            delay *= backoff
    # This should never be reached, but satisfies type checker
    raise RuntimeError("Retry logic failed unexpectedly")


def retry_wrapper(
    max_attempts: int = 3,
    sleep_time: int | float = 2,
    backoff: int | float = 2,
    exceptions: tuple[type[Exception], ...] = (Exception,),
    log_tries: bool = False,
    max_total_time: float | None = None,
    jitter: bool = False,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator for retrying functions with exponential backoff.

    Description:
        Returns a decorator that wraps sync or async functions with retry
        logic. Automatically detects if the decorated function is async
        and applies the appropriate retry mechanism.

    Args:
        max_attempts: Maximum number of attempts before giving up.
        sleep_time: Initial delay in seconds between retries.
        backoff: Multiplier for increasing delay after each retry.
        exceptions: Tuple of exception types to catch and retry.
        log_tries: If True, logs warnings for each retry attempt.
        max_total_time: Optional budget in seconds. When set, retrying stops
            if the elapsed wall-clock time exceeds this value before the next
            attempt, and the last exception is re-raised.
        jitter: When True, adds a random 0–50% fraction of the current wait
            time to each sleep duration to spread retry storms.

    Returns:
        A decorator function that wraps callables with retry logic.
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            return await retry_async(
                func,  # type: ignore
                *args,
                max_attempts=max_attempts,
                sleep_time=sleep_time,
                backoff=backoff,
                exceptions=exceptions,
                log_tries=log_tries,
                **kwargs,
            )

        @wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> T:
            return retry(
                func,
                *args,
                max_attempts=max_attempts,
                sleep_time=sleep_time,
                backoff=backoff,
                exceptions=exceptions,
                log_tries=log_tries,
                max_total_time=max_total_time,
                jitter=jitter,
                **kwargs,
            )

        if asyncio.iscoroutinefunction(func):
            return async_wrapper  # type: ignore
        else:
            return sync_wrapper

    return decorator
