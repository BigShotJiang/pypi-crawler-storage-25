"""Enum definitions used across the framework."""

from enum import StrEnum

__all__ = ("OrderingType",)


class OrderingType(StrEnum):
    """Generic ascending/descending ordering options."""

    desc = "desc"
    asc = "asc"
