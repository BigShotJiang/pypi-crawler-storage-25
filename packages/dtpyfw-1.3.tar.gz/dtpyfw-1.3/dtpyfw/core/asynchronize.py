"""Helpers for bridging async and sync code."""

import asyncio
from collections.abc import Awaitable
from typing import Any

__all__ = ("async_to_sync",)


def async_to_sync(awaitable: Awaitable) -> Any:
    """Execute an awaitable in a new event loop and return its result.

    Description:
        Runs an async coroutine or awaitable object in a synchronous context.
        Uses the running event loop when one exists; otherwise creates a new
        temporary event loop to run the awaitable to completion.

    Args:
        awaitable: An awaitable object (coroutine, task, or future) to execute.

    Returns:
        The result returned by the awaitable after it completes execution.

    Raises:
        TypeError: If the supplied object is not actually awaitable.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(awaitable)
        finally:
            loop.close()
    else:
        # A running loop exists — schedule as a task and return it.
        # Callers in a fully sync context should not reach here; this is a
        # best-effort fallback that returns the coroutine wrapped in a task.
        return loop.run_until_complete(awaitable)
