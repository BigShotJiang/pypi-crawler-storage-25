"""Shared base class for all dtpyfw config builders."""

from typing import Any

__all__ = ("ConfigBuilder",)


class ConfigBuilder:
    """Fluent config builder base — provides ``_config`` storage and ``get()``."""

    def __init__(self) -> None:
        self._config: dict[str, Any] = {}

    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve a stored config value by key.

        Args:
            key: Config key to retrieve.
            default: Value returned when key is absent. Defaults to ``None``.

        Returns:
            The stored value, or ``default`` if not found.
        """
        return self._config.get(key, default)
