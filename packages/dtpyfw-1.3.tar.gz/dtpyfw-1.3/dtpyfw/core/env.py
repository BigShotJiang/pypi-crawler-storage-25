"""Utility helpers for interacting with environment variables."""

import os
from functools import lru_cache
from typing import Any

from ..log import footprint

__all__ = ("Env",)


class Env:
    """Lightweight wrapper around ``os.environ`` with allow-list support.

    Description:
        Provides controlled access to environment variables with an allow-list
        mechanism. Only variables explicitly registered can be loaded from files
        or accessed via the get method.
    """

    _allowed_variables: set[str] = set()

    @classmethod
    def load_file(cls, file_path: str, override: bool = False, fail_on_missing: bool = False) -> None:
        """Load key/value pairs from a ``.env`` style file.

        Description:
            Reads environment variables from a file and loads them into os.environ.
            Only variables that have been registered via register() are loaded.
            Blank lines and lines starting with ``#`` are skipped. Values may be
            wrapped in single or double quotes (the quotes are stripped). Inline
            comments (`` #``) are stripped from unquoted values. The ``get``
            cache is cleared after loading so freshly loaded values are visible
            on the next call.

        Args:
            file_path: Path to the file containing environment variables.
            override: When True, existing environment variables will be overwritten.
            fail_on_missing: If True, raises FileNotFoundError when the file is missing.

        Returns:
            None

        Raises:
            FileNotFoundError: If fail_on_missing is True and the file doesn't exist.
        """
        controller = f"{__name__}.Env.load_file"
        if not os.path.exists(file_path):
            if fail_on_missing:
                raise FileNotFoundError(f"The file {file_path} does not exist.")

            return

        with open(file_path) as file:
            for line in file:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, _, raw = line.partition("=")
                key = key.strip().upper()
                value = raw.strip()
                # Strip surrounding quotes (single or double)
                if len(value) >= 2 and value[0] in ('"', "'") and value[-1] == value[0]:
                    value = value[1:-1]
                elif " #" in value:
                    # Strip inline comment for unquoted values
                    value = value[: value.index(" #")].rstrip()
                if key in cls._allowed_variables:
                    if override or key not in os.environ:
                        os.environ[key] = value
                else:
                    footprint.leave(
                        log_type="warning",
                        message=f"Skipping unallowed environment variable {key}.",
                        controller=controller,
                        subject="Unallowed Environment Variable",
                    )

        cls.reset()

    @classmethod
    def register(cls, variables: list[str] | set[str]) -> None:
        """Register environment variable names that are allowed to be loaded.

        Description:
            Adds variable names to the internal allow-list. Only registered
            variables can be loaded from files via load_file(). Variable names
            are automatically converted to uppercase.

        Args:
            variables: A list or set of environment variable names to register (case-insensitive).

        Returns:
            None
        """
        cls._allowed_variables.update([item.upper() for item in variables])

    @classmethod
    @lru_cache(maxsize=128)
    def get(cls, key: str, default: Any = None) -> Any:
        """Retrieve a variable from ``os.environ`` with optional default.

        Description:
            Gets an environment variable value. The key is automatically
            converted to uppercase. Returns the default if the variable
            is not set. Results are cached for performance.

        Args:
            key: The environment variable name to retrieve.
            default: Value to return if the variable is not set. Defaults to None.

        Returns:
            The value of the environment variable, or the default value if not found.
        """
        value = os.getenv(key.upper())
        return value if value is not None else default

    @classmethod
    def reset(cls) -> None:
        """Clear the LRU cache on ``get``.

        Description:
            Invalidates all cached environment variable lookups so that
            subsequent calls to ``get`` re-read from ``os.environ``. Call
            this after programmatically mutating ``os.environ`` or after
            loading a new env file.

        Returns:
            None
        """
        cls.get.cache_clear()

    @classmethod
    def registered(cls) -> list[str]:
        """Return the list of registered environment variable names.

        Description:
            Returns all variable names that have been added to the internal
            allow-list via ``register()``. Names are returned in uppercase as
            stored.

        Returns:
            A sorted list of registered environment variable names.
        """
        return sorted(cls._allowed_variables)

    @classmethod
    def get_int(cls, key: str, default: int | None = None) -> int | None:
        """Retrieve an environment variable coerced to ``int``.

        Description:
            Gets an environment variable value and attempts to convert it to
            an integer. Returns the default if the variable is not set or if
            conversion fails.

        Args:
            key: The environment variable name to retrieve.
            default: Value to return if the variable is not set or cannot be
                converted. Defaults to None.

        Returns:
            The value as an integer, or the default value if not found or invalid.
        """
        value = cls.get(key)
        if value is None:
            return default
        try:
            return int(value)
        except (ValueError, TypeError):
            return default

    @classmethod
    def get_float(cls, key: str, default: float | None = None) -> float | None:
        """Retrieve an environment variable coerced to ``float``.

        Description:
            Gets an environment variable value and attempts to convert it to a
            float. Returns the default if the variable is not set or if
            conversion fails.

        Args:
            key: The environment variable name to retrieve.
            default: Value to return if the variable is not set or cannot be
                converted. Defaults to None.

        Returns:
            The value as a float, or the default value if not found or invalid.
        """
        value = cls.get(key)
        if value is None:
            return default
        try:
            return float(value)
        except (ValueError, TypeError):
            return default

    @classmethod
    def get_bool(cls, key: str, default: bool | None = None) -> bool | None:
        """Retrieve an environment variable coerced to ``bool``.

        Description:
            Gets an environment variable value and interprets it as a boolean.
            The strings ``"1"``, ``"true"``, ``"yes"``, and ``"on"``
            (case-insensitive) are truthy; all other non-empty strings are
            falsy. Returns the default if the variable is not set.

        Args:
            key: The environment variable name to retrieve.
            default: Value to return if the variable is not set. Defaults to None.

        Returns:
            True or False based on the variable value, or the default if not found.
        """
        value = cls.get(key)
        if value is None:
            return default
        return value.strip().lower() in ("1", "true", "yes", "on")

    @classmethod
    def get_list(cls, key: str, separator: str = ",", default: list[str] | None = None) -> list[str]:
        """Retrieve an environment variable as a list of strings.

        Description:
            Gets an environment variable value and splits it into a list using
            the specified separator. Strips whitespace from each item and
            removes empty items. Returns the default (or an empty list) if the
            variable is not set.

        Args:
            key: The environment variable name to retrieve.
            separator: Delimiter used to split the value. Defaults to ``","``
            default: Value to return if the variable is not set. When None,
                returns an empty list. Defaults to None.

        Returns:
            A list of non-empty, whitespace-stripped strings from the variable
            value, or the default list if the variable is not set.
        """
        value = cls.get(key)
        if value is None:
            return default if default is not None else []
        return [v.strip() for v in value.split(separator) if v.strip()]
