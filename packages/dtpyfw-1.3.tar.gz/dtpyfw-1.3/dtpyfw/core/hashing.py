"""Helpers for hashing arbitrary data."""

import hashlib
import json
from collections.abc import Callable
from typing import Any

__all__ = ("hash_data",)

# Dispatch table mapping algorithm name to a zero-argument factory that returns
# a fresh hash object.  MD5 and SHA-1 are marked usedforsecurity=False for FIPS
# compatibility (they are used only for checksums, not security primitives).
# SHA-256/512 and the BLAKE variants are security-grade and do not carry the
# flag.  The blake2* factories are lambdas because they require the data to be
# passed at construction time; they are therefore called differently in
# hash_data below.
_HASHERS: dict[str, Callable[[], Any]] = {
    "md5": lambda: hashlib.md5(usedforsecurity=False),
    "sha1": lambda: hashlib.sha1(usedforsecurity=False),
    "sha256": hashlib.sha256,
    "sha512": hashlib.sha512,
}


def serialize_data(data: Any) -> bytes:
    """Serialize data into a bytes object for hashing.

    Description:
        Converts various data types into a consistent byte representation
        suitable for hashing. Handles strings, dictionaries, and other
        JSON-serializable types with fallback to repr().

    Args:
        data: The data to serialize. Can be str, dict, list, tuple, or other types.

    Returns:
        The serialized data as bytes.
    """
    if isinstance(data, str):
        return data.encode("utf-8")
    if isinstance(data, dict):
        return json.dumps(data, sort_keys=True, default=str).encode("utf-8")
    try:
        # Attempt JSON serialization for other types (e.g., list, tuple)
        return json.dumps(data).encode("utf-8")
    except (TypeError, OverflowError):
        # Fallback to repr for objects that aren't JSON serializable
        return repr(data).encode("utf-8")


def hash_data(data: Any, algorithm: str = "sha512") -> str:
    """Hash the provided data using the specified algorithm.

    Description:
        Serializes the input data and generates a cryptographic hash using
        one of the supported algorithms. Default algorithm is SHA-512.

    Args:
        data: The data to hash. Can be any serializable type.
        algorithm: The hashing algorithm to use. Supported values:
            'md5', 'sha1', 'sha256', 'sha512', 'blake2b', 'blake2s'.
            Defaults to 'sha512'.

    Returns:
        The hexadecimal string representation of the hash digest.

    Raises:
        ValueError: If an unsupported algorithm is specified.
    """
    serialized = serialize_data(data)
    algo = algorithm.lower()

    if algo in _HASHERS:
        hash_obj = _HASHERS[algo]()
        hash_obj.update(serialized)
        return hash_obj.hexdigest()

    if algo == "blake2b":
        # Using 16-byte digest size for a 32-character hex digest
        return hashlib.blake2b(serialized, digest_size=16).hexdigest()
    if algo == "blake2s":
        # Using 16-byte digest size for a 32-character hex digest
        return hashlib.blake2s(serialized, digest_size=16).hexdigest()

    raise ValueError("Unsupported algorithm selected.")
