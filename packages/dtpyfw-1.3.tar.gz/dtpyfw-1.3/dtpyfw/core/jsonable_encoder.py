"""Wrapper around :func:`json.dumps` that forces serialization of unknown
types.

This module provides utilities to ensure data can be safely JSON-encoded
by converting it through a JSON round-trip with string fallbacks.
"""

import json
from datetime import date, datetime
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel

__all__ = ("jsonable_encoder",)


def _default(obj: object) -> object:
    """Fallback serializer for :func:`json.dumps`.

    Description:
        Converts types that are not natively JSON-serializable to a
        JSON-compatible form. Pydantic models are expanded via
        ``model_dump()``. UUID, datetime, date, and Enum values are
        coerced to their string representation. All other types fall
        back to ``str()``.

    Args:
        obj: The object that could not be serialized by the default encoder.

    Returns:
        A JSON-serializable representation of the object.
    """
    if isinstance(obj, BaseModel):
        return obj.model_dump(mode="json")
    if isinstance(obj, (UUID, datetime, date, Enum)):
        return str(obj)
    return str(obj)


def jsonable_encoder(data: Any) -> Any:
    """Return data encoded to JSON and back to ensure primitives only.

    Description:
        Converts the input data to JSON format and then parses it back,
        ensuring all values are JSON-compatible primitives. Pydantic
        models are expanded via ``model_dump()``. UUID, datetime, date,
        and Enum values are coerced to strings. All other non-serializable
        types fall back to ``str()``.

    Args:
        data: The data to encode, can be any type.

    Returns:
        The data with all values converted to JSON-compatible primitives.
    """
    return json.loads(json.dumps(data, default=_default))
