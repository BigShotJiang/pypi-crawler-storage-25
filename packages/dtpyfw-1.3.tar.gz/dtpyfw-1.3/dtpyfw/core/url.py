"""Small URL manipulation helpers."""

from typing import Any
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

__all__ = ("add_query_param",)


def add_query_param(url: str, params: dict[str, Any]) -> str:
    """Add, update, or remove query parameters in a URL.

    This function takes a URL and a dictionary of parameters, then merges
    them into the URL's query string. If a parameter already exists its
    value is updated. Passing ``None`` as a value removes the key.

    Args:
        url: The original URL.
        params: A dictionary of query parameters to add, update, or remove.
            Pass ``None`` as a value to remove an existing key.

    Returns:
        The new URL with the updated query parameters.
    """

    url_parts = urlparse(url)
    query_params = parse_qs(url_parts.query)
    for key, value in params.items():
        if value is None:
            query_params.pop(str(key), None)
        else:
            query_params[key] = value
    new_query = urlencode(query_params, doseq=True)
    new_url = urlunparse(
        (
            url_parts.scheme,
            url_parts.netloc,
            url_parts.path,
            url_parts.params,
            new_query,
            url_parts.fragment,
        )
    )
    return new_url
