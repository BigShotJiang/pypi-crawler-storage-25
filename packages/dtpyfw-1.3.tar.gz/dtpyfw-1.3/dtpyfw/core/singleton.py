"""Singleton pattern decorators for class instantiation."""

from typing import Any

__all__ = (
    "singleton_class",
    "singleton_class_by_args",
)


def singleton_class[T](cls: type[T]) -> type[T]:
    """Decorator ensuring a class has only one instance regardless of arguments.

    Description:
        Patches ``__new__`` and ``__init__`` on the decorated class so that
        only one instance is ever created. Subsequent calls return the same
        object. The class identity is preserved, so ``isinstance`` checks
        continue to work correctly.

    Args:
        cls: The class to convert to a singleton.

    Returns:
        The same class, patched with singleton behaviour.
    """
    original_init = cls.__init__
    _state: dict[str, Any] = {"instance": None, "initialized": False}

    def __new__(klass: type, *args: Any, **kwargs: Any) -> T:
        if _state["instance"] is None:
            _state["instance"] = object.__new__(klass)
        return _state["instance"]  # type: ignore[return-value]

    def __init__(self: Any, *args: Any, **kwargs: Any) -> None:
        if not _state["initialized"]:
            original_init(self, *args, **kwargs)
            _state["initialized"] = True

    cls.__new__ = __new__  # type: ignore[method-assign]
    cls.__init__ = __init__  # type: ignore[method-assign]
    return cls


def singleton_class_by_args[T](cls: type[T]) -> type[T]:
    """Decorator ensuring one instance per unique set of constructor arguments.

    Description:
        Patches ``__new__`` and ``__init__`` on the decorated class so that
        instances are keyed by their constructor arguments. Each unique
        ``(args, kwargs)`` combination yields one cached instance. The class
        identity is preserved so ``isinstance`` checks work correctly.

    Args:
        cls: The class to apply argument-based singleton behaviour to.

    Returns:
        The same class, patched with per-argument singleton behaviour.
    """
    original_init = cls.__init__
    _instances: dict[Any, T] = {}
    _initialized: set[Any] = set()

    def __new__(klass: type, *args: Any, **kwargs: Any) -> T:
        key = (args, frozenset(kwargs.items()))
        if key not in _instances:
            _instances[key] = object.__new__(klass)  # type: ignore[assignment]
        return _instances[key]

    def __init__(self: Any, *args: Any, **kwargs: Any) -> None:
        key = (args, frozenset(kwargs.items()))
        if key not in _initialized:
            original_init(self, *args, **kwargs)
            _initialized.add(key)

    cls.__new__ = __new__  # type: ignore[method-assign]
    cls.__init__ = __init__  # type: ignore[method-assign]
    return cls
