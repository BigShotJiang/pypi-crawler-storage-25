"""Core utilities module providing foundational helpers for the framework."""

from .chunking import chunk_list, chunk_list_generator
from .coerce import coerce_bool
from .config import ConfigBuilder
from .exception import RequestException, exception_to_dict
from .hashing import hash_data
from .jsonable_encoder import jsonable_encoder
from .require_extra import require_extra
from .retry import retry_wrapper

__all__ = (
    "ConfigBuilder",
    "RequestException",
    "chunk_list",
    "chunk_list_generator",
    "coerce_bool",
    "exception_to_dict",
    "hash_data",
    "jsonable_encoder",
    "require_extra",
    "retry_wrapper",
)

require_extra("core", "requests")
