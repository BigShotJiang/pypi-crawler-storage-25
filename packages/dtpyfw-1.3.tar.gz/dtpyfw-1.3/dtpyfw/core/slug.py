"""Helpers for normalising strings into URL slugs."""

import re
import unicodedata

__all__ = ("create_slug",)


def create_slug(name: str) -> str | None:
    """Generate a URL-friendly slug from a string.

    This function converts a string into a slug by normalising Unicode
    diacritics first, then lowercasing, replacing spaces with hyphens,
    and removing all characters that are not letters, numbers, hyphens,
    or underscores.

    Args:
        name: The string to convert into a slug.

    Returns:
        The generated slug as a string, or None if the input is empty.
    """

    if not name:
        return None

    # NFKD decomposition first so accented chars (e.g. é → e + ́) survive
    # the subsequent ASCII stripping step.
    slug = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("utf-8")

    # Lowercase and replace spaces with hyphens
    slug = slug.lower().replace(" ", "-")

    # Remove any characters that are not letters, numbers, hyphens, or underscores
    slug = re.sub(r"[^a-z0-9\-_]", "", slug)

    # Remove any leading or trailing hyphens
    slug = slug.strip("-")

    return slug
