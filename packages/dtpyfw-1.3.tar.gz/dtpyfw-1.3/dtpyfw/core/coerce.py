"""Type coercion helpers shared across config builders."""

__all__ = ("coerce_bool",)


def coerce_bool(value: bool | str) -> bool:
    """Coerce a bool or string value to bool.

    Treats ``"0"``, ``"false"``, ``"no"``, ``"off"``, and ``""`` as ``False``.
    All other strings — including unrecognized values — are ``True``.
    Real bools pass through unchanged.

    Use this for config-setter inputs where the caller may pass env-var strings.
    For reading directly from env vars, prefer ``Env.get_bool(key)`` instead.

    Args:
        value: A bool or string representation of a boolean.

    Returns:
        Coerced bool.
    """
    if isinstance(value, str):
        return value.strip().lower() not in ("0", "false", "no", "off", "")
    return bool(value)
