"""S3-compatible bucket storage utilities.

This module provides high-level interfaces for interacting with
S3-compatible object storage services using boto3.
"""

from ..core.require_extra import require_extra

require_extra("bucket", "boto3", "botocore")

from .bucket import Bucket  # noqa: E402

__all__ = ("Bucket",)
