"""Simple wrapper around boto3 S3 client."""

from collections.abc import Generator
from contextlib import contextmanager
from typing import IO
from urllib.parse import urlparse

import boto3
from botocore.client import BaseClient
from botocore.config import Config as BotocoreConfig
from botocore.exceptions import ClientError, NoCredentialsError

from ..core.exception import RequestException
from ..log import footprint

__all__ = ("Bucket",)


@contextmanager
def _boto_errors(controller: str) -> Generator[None, None, None]:
    """Context manager that translates boto3 exceptions into `RequestException`.

    Args:
        controller: Dotted controller path included in the raised exception.

    Yields:
        None — wraps the body of the ``with`` block.

    Raises:
        RequestException: For `NoCredentialsError` (500) or any `ClientError` (500).
    """
    try:
        yield
    except NoCredentialsError as exc:
        raise RequestException(
            status_code=500,
            controller=controller,
            message="S3 credentials not configured.",
        ) from exc
    except ClientError as exc:
        code = exc.response["Error"]["Code"]
        msg = exc.response["Error"]["Message"]
        raise RequestException(
            status_code=500,
            controller=controller,
            message=f"S3 error {code}: {msg}",
        ) from exc


class Bucket:
    """High level interface for reading/writing files to S3 compatible storage."""

    def __init__(
        self,
        name: str,
        endpoint_url: str | None = None,
        access_key: str | None = None,
        secret_key: str | None = None,
        region_name: str | None = None,
        boto_config: BotocoreConfig | None = None,
        public_base_url: str | None = None,
    ) -> None:
        """Initialize S3-compatible bucket client.

        Args:
            name: Name of the S3 bucket.
            endpoint_url: S3 API endpoint URL. Pass for any non-AWS provider (R2, Spaces,
                MinIO, etc.). Leave ``None`` for native AWS S3 (boto3 uses regional routing).
            access_key: AWS access key ID or equivalent.
            secret_key: AWS secret access key or equivalent.
            region_name: AWS region name. Required for native AWS S3; optional for
                S3-compatible providers (some require it for SigV4 signing).
            boto_config: Optional ``botocore.config.Config`` forwarded to the boto3 client.
            public_base_url: Base URL used by ``url_generator`` to build public object URLs.
                Set this when the public object URL differs from the API endpoint — e.g.
                Cloudflare R2 (``"https://pub-<hash>.r2.dev"`` or a custom domain), or
                an AWS CloudFront distribution. When omitted, ``url_generator`` falls back to
                ``{endpoint_url}/{bucket}/{key}``.
        """
        safe_endpoint: str | None = None
        if endpoint_url is not None:
            parsed = urlparse(endpoint_url)
            safe_endpoint = f"{parsed.scheme}://{parsed.netloc}" if parsed.netloc else endpoint_url

        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.__init__",
            message="Initializing Bucket",
            payload={
                "name": name,
                "endpoint_url": safe_endpoint,
                "region_name": region_name,
            },
        )

        self._name: str = name
        self._endpoint_url = endpoint_url
        self._region_name = region_name
        self._boto_config = boto_config
        self._public_base_url = public_base_url.rstrip("/") if public_base_url else None

        self._s3_client: BaseClient = boto3.client(
            "s3",
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            endpoint_url=endpoint_url,
            region_name=region_name,
            config=boto_config,
        )

    @classmethod
    def from_env(cls, prefix: str = "s3_") -> "Bucket":
        """Construct a ``Bucket`` instance from environment variables.

        Reads the following env vars (with the given prefix):
        ``{prefix}bucket_name``, ``{prefix}access_key``, ``{prefix}secret_key``,
        ``{prefix}endpoint_url``, ``{prefix}mode``.

        Args:
            prefix: Env-var prefix (default ``"s3_"``).

        Returns:
            A fully configured ``Bucket`` instance.
        """
        from dtpyfw.core.env import Env

        return cls(
            name=Env.get(f"{prefix}bucket_name"),
            access_key=Env.get(f"{prefix}access_key"),
            secret_key=Env.get(f"{prefix}secret_key"),
            endpoint_url=Env.get(f"{prefix}endpoint_url", None),
            region_name=Env.get(f"{prefix}region", None),
            public_base_url=Env.get(f"{prefix}public_url", None),
        )

    def url_generator(self, key: str) -> str:
        """Generate the public URL for an object in the bucket.

        When ``public_base_url`` is set, returns ``{public_base_url}/{key}`` — the caller
        controls the full base, so no bucket name is appended (correct for R2 CDN domains,
        CloudFront distributions, and any provider where the bucket is implicit in the base).

        When only ``endpoint_url`` is set, returns ``{endpoint_url}/{bucket}/{key}`` — the
        path-style format used by DigitalOcean Spaces, MinIO, and similar providers.

        Args:
            key: Object key/path within the bucket.

        Returns:
            Public URL string for accessing the object.
        """
        if self._public_base_url:
            return f"{self._public_base_url}/{key}"
        return f"{self._endpoint_url}/{self._name}/{key}"

    def get_s3(self) -> BaseClient:
        """Get the underlying boto3 S3 client instance.

        Returns:
            The boto3 BaseClient for S3 operations.
        """
        return self._s3_client

    def get_bucket_name(self) -> str:
        """Get the configured bucket name.

        Returns:
            The configured bucket name.
        """
        return self._name

    def check_file_exists(self, key: str) -> bool:
        """Check if an object exists in the bucket.

        Args:
            key: Object key/path to check for existence.

        Returns:
            True if the object exists, False if the object is not found.

        Raises:
            RequestException: If a non-404 S3 error occurs (e.g. 403, 5xx) or credentials
                are missing.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.check_file_exists",
            message=f"Checking if file exists: {key}",
            payload={"key": key},
        )
        controller = f"{__name__}.Bucket.check_file_exists"
        try:
            self._s3_client.head_object(Bucket=self._name, Key=key)
            return True
        except NoCredentialsError as exc:
            raise RequestException(
                status_code=500,
                controller=controller,
                message="S3 credentials not configured.",
            ) from exc
        except ClientError as exc:
            code = exc.response["Error"]["Code"]
            if code in ("404", "NoSuchKey"):
                return False
            msg = exc.response["Error"]["Message"]
            raise RequestException(
                status_code=500,
                controller=controller,
                message=f"S3 error {code}: {msg}",
            ) from exc

    def upload(self, file: bytes, key: str, content_type: str, cache_control: str = "no-cache") -> str:
        """Upload bytes content to the bucket.

        Args:
            file: Binary content to upload.
            key: Object key/path for the uploaded content.
            content_type: MIME type of the content.
            cache_control: Cache control header value (default: ``"no-cache"``).

        Returns:
            Public URL of the uploaded object.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.upload",
            message=f"Uploading file to key: {key}",
            payload={
                "key": key,
                "content_type": content_type,
                "cache_control": cache_control,
            },
        )
        with _boto_errors(f"{__name__}.Bucket.upload"):
            self._s3_client.put_object(
                Body=file,
                Bucket=self._name,
                Key=key,
                ContentType=content_type,
                CacheControl=cache_control,
            )
        return self.url_generator(key=key)

    def upload_fileobj(self, fileobj: IO[bytes], key: str, content_type: str = "application/octet-stream") -> str:
        """Stream a file-like object directly to the bucket without reading it into memory.

        Args:
            fileobj: Open binary file-like object to upload.
            key: Object key/path for the uploaded content.
            content_type: MIME type of the content (default: ``"application/octet-stream"``).

        Returns:
            Public URL of the uploaded object.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.upload_fileobj",
            message=f"Uploading file object to key: {key}",
            payload={"key": key, "content_type": content_type},
        )
        with _boto_errors(f"{__name__}.Bucket.upload_fileobj"):
            self._s3_client.upload_fileobj(
                fileobj,
                self._name,
                key,
                ExtraArgs={"ContentType": content_type},
            )
        return self.url_generator(key)

    def download(self, key: str, filepath: str) -> None:
        """Download an object from the bucket to a local file.

        Args:
            key: Object key/path to download.
            filepath: Local filesystem path where the file will be saved.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.download",
            message=f"Downloading file from key: {key} to {filepath}",
            payload={"key": key, "filepath": filepath},
        )
        with _boto_errors(f"{__name__}.Bucket.download"):
            self._s3_client.download_file(
                Bucket=self._name,
                Key=key,
                Filename=filepath,
            )

    def download_fileobj(self, key: str, file: IO[bytes]) -> None:
        """Download an object from the bucket into an open file object.

        Args:
            key: Object key/path to download.
            file: Open file object to write the downloaded content into.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.download_fileobj",
            message=f"Downloading file from key: {key} to file object",
            payload={"key": key},
        )
        with _boto_errors(f"{__name__}.Bucket.download_fileobj"):
            self._s3_client.download_fileobj(
                Bucket=self._name,
                Key=key,
                Fileobj=file,
            )

    def get_object(self, key: str) -> bytes:
        """Fetch the full content of an object from the bucket.

        Args:
            key: Object key/path to retrieve.

        Returns:
            Raw bytes of the object body.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.get_object",
            message=f"Getting object for key: {key}",
            payload={"key": key},
        )
        with _boto_errors(f"{__name__}.Bucket.get_object"):
            response = self._s3_client.get_object(Bucket=self._name, Key=key)
            return response["Body"].read()

    def stream_download(self, key: str, chunk_size: int = 8192) -> Generator[bytes, None, None]:
        """Stream an object from the bucket as a sequence of byte chunks.

        Args:
            key: Object key/path to stream.
            chunk_size: Number of bytes per chunk (default: 8192).

        Yields:
            Successive ``bytes`` chunks of the object body until exhausted.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.stream_download",
            message=f"Streaming download for key: {key}",
            payload={"key": key, "chunk_size": chunk_size},
        )
        with _boto_errors(f"{__name__}.Bucket.stream_download"):
            response = self._s3_client.get_object(Bucket=self._name, Key=key)
            body = response["Body"]
            while chunk := body.read(chunk_size):
                yield chunk

    def upload_by_path(
        self,
        file_path: str,
        key: str,
        content_type: str = "application/octet-stream",
        cache_control: str = "no-cache",
    ) -> str:
        """Upload a file from the local filesystem to the bucket via the TransferManager.

        Uses ``boto3.client.upload_file`` internally, which automatically selects
        multipart upload for large files.

        Args:
            file_path: Local filesystem path to the file to upload.
            key: Object key/path for the uploaded content.
            content_type: MIME type of the content (default: ``"application/octet-stream"``).
            cache_control: Cache control header value (default: ``"no-cache"``).

        Returns:
            Public URL of the uploaded object.

        Raises:
            RequestException: With status 404 if ``file_path`` does not exist, or 500 for
                other filesystem errors.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.upload_by_path",
            message=f"Uploading file from path: {file_path} to key: {key}",
            payload={
                "file_path": file_path,
                "key": key,
                "content_type": content_type,
                "cache_control": cache_control,
            },
        )
        try:
            with _boto_errors(f"{__name__}.Bucket.upload_by_path"):
                self._s3_client.upload_file(
                    file_path,
                    self._name,
                    key,
                    ExtraArgs={"ContentType": content_type},
                )
        except FileNotFoundError as exc:
            raise RequestException(
                status_code=404,
                controller=f"{__name__}.Bucket.upload_by_path",
                message=f"File not found: {file_path}",
            ) from exc
        except OSError as exc:
            raise RequestException(
                status_code=500,
                controller=f"{__name__}.Bucket.upload_by_path",
                message=f"Cannot read file: {exc}",
            ) from exc
        return self.url_generator(key)

    def list_objects(self, prefix: str = "", max_keys: int = 1000) -> list[str]:
        """List object keys in the bucket, optionally filtered by prefix.

        Uses the S3 paginator so results are not capped at 1000 by the API.

        Args:
            prefix: Key prefix to filter results (default: ``""`` — all keys).
            max_keys: Maximum total number of keys to return (default: 1000).

        Returns:
            List of matching object key strings.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.list_objects",
            message=f"Listing objects with prefix: {prefix!r}",
            payload={"prefix": prefix, "max_keys": max_keys},
        )
        with _boto_errors(f"{__name__}.Bucket.list_objects"):
            paginator = self._s3_client.get_paginator("list_objects_v2")
            keys: list[str] = []
            for page in paginator.paginate(
                Bucket=self._name,
                Prefix=prefix,
                PaginationConfig={"MaxItems": max_keys},
            ):
                for obj in page.get("Contents", []):
                    keys.append(obj["Key"])
            return keys

    def delete_objects(self, keys: list[str]) -> int:
        """Batch-delete a list of objects from the bucket.

        Splits requests into batches of 1000 (the S3 API limit).

        Args:
            keys: List of object keys to delete.

        Returns:
            Total count of successfully deleted objects.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.delete_objects",
            message=f"Batch deleting {len(keys)} objects",
            payload={"count": len(keys)},
        )
        if not keys:
            return 0
        deleted = 0
        for i in range(0, len(keys), 1000):
            batch = keys[i : i + 1000]
            with _boto_errors(f"{__name__}.Bucket.delete_objects"):
                response = self._s3_client.delete_objects(
                    Bucket=self._name,
                    Delete={"Objects": [{"Key": k} for k in batch]},
                )
                deleted += len(response.get("Deleted", []))
        return deleted

    def delete_prefix(self, prefix: str) -> int:
        """Delete all objects whose key starts with ``prefix``.

        Convenience wrapper around :meth:`list_objects` + :meth:`delete_objects`.

        Args:
            prefix: Key prefix — all matching objects are deleted.

        Returns:
            Total count of deleted objects (0 if no matches found).
        """
        keys = self.list_objects(prefix=prefix, max_keys=100_000)
        return self.delete_objects(keys) if keys else 0

    def duplicate(self, source_key: str, destination_key: str, cache_control: str = "no-cache") -> str:
        """Duplicate an object within the bucket.

        Args:
            source_key: Object key/path to copy from.
            destination_key: Object key/path to copy to.
            cache_control: Cache control header value (default: ``"no-cache"``).

        Returns:
            Public URL of the duplicated object.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.duplicate",
            message=f"Duplicating file from {source_key} to {destination_key}",
            payload={
                "source_key": source_key,
                "destination_key": destination_key,
                "cache_control": cache_control,
            },
        )
        with _boto_errors(f"{__name__}.Bucket.duplicate"):
            self._s3_client.copy(
                CopySource={"Bucket": self._name, "Key": source_key},
                Bucket=self._name,
                Key=destination_key,
                ExtraArgs={"CacheControl": cache_control},
            )
        return self.url_generator(key=destination_key)

    def safe_duplicate(self, source_key: str, cache_control: str = "no-cache") -> str:
        """Duplicate an object avoiding name collisions by appending a counter.

        Args:
            source_key: Object key/path to copy from.
            cache_control: Cache control header value (default: ``"no-cache"``).

        Returns:
            Public URL of the duplicated object with a unique key.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.safe_duplicate",
            message=f"Safely duplicating file from {source_key}",
            payload={"source_key": source_key, "cache_control": cache_control},
        )
        default_key = source_key
        key = default_key
        i = 2
        filename = default_key.rsplit("/", 1)[-1]
        if "." in filename:
            name, ext = default_key.rsplit(".", 1)
            key_template = f"{name}-{{i}}.{ext}"
        else:
            key_template = default_key + "-{i}"
        while self.check_file_exists(key):
            key = key_template.format(i=i)
            i += 1

        return self.duplicate(source_key=source_key, destination_key=key, cache_control=cache_control)

    def delete(self, key: str) -> bool:
        """Delete an object from the bucket.

        Args:
            key: Object key/path to delete.

        Returns:
            True if the object was successfully deleted.

        Raises:
            RequestException: If an S3 error occurs during deletion.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.delete",
            message=f"Deleting file with key: {key}",
            payload={"key": key},
        )
        with _boto_errors(f"{__name__}.Bucket.delete"):
            self._s3_client.delete_object(Bucket=self._name, Key=key)
        return True

    def generate_presigned_url(self, key: str, method: str = "get_object", expires_in: int = 3600) -> str:
        """Generate a time-limited pre-signed URL for a bucket object.

        Args:
            key: Object key/path to sign.
            method: S3 client method name (default: ``"get_object"``). Use
                ``"put_object"`` for upload URLs.
            expires_in: URL validity in seconds (default: 3600).

        Returns:
            Pre-signed URL string.
        """
        footprint.leave(
            log_type="debug",
            controller=f"{__name__}.Bucket.generate_presigned_url",
            message=f"Generating presigned URL for key: {key}",
            payload={"key": key, "method": method, "expires_in": expires_in},
        )
        with _boto_errors(f"{__name__}.Bucket.generate_presigned_url"):
            return self._s3_client.generate_presigned_url(
                method,
                Params={"Bucket": self._name, "Key": key},
                ExpiresIn=expires_in,
            )
