"""Public entry points: ``collect_startup_report`` and ``emit_startup_report``.

Both functions are pure in the sense that they never raise, never exit, and
never block startup.  All dependency probes run concurrently inside a
``ThreadPoolExecutor`` bounded by ``probe_timeout_seconds``.

Emission targets
----------------
- **stdout banner** — plain ASCII, printed with ``print()`` so it is
  visible even if the logging stack is not yet initialised.
- **footprint** — ``dtpyfw.log.footprint.leave(...)`` called once after
  the banner.

Neither target is external (no Kafka, no Redis Stream, no HTTP).
"""

from __future__ import annotations

import datetime
import sys
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from typing import Any, Literal

from .probes import (
    probe_bucket,
    probe_database,
    probe_environment,
    probe_ftp,
    probe_kafka,
    probe_logging,
    probe_opensearch,
    probe_process,
    probe_redis,
)
from .schema import DependenciesInfo, ProbeResult, StartupReport

__all__ = ("collect_startup_report", "emit_startup_report")

# ---------------------------------------------------------------------------
# Aggregate status helpers
# ---------------------------------------------------------------------------


def _aggregate_status(probe_results: list[ProbeResult]) -> Literal["ok", "degraded", "down"]:
    """Compute overall health from a flat list of probe results.

    Rules (per user decision):
    - ``ok`` — all non-skipped probes are ``ok`` (or everything is skipped).
    - ``down`` — every probe that actually ran (status != ``"skipped"``) is
      ``"down"``.
    - ``degraded`` — at least one probe is ``ok`` AND at least one is
      ``"down"``.  Also ``degraded`` (not ``down``) when only a subset
      of non-critical probes fail.  Err on the side of ``degraded``.

    Args:
        probe_results: Flat list of ``ProbeResult`` instances from all probes.

    Returns:
        One of ``"ok"``, ``"degraded"``, or ``"down"``.
    """
    ran = [r for r in probe_results if r.status != "skipped"]
    if not ran:
        return "ok"

    down_count = sum(1 for r in ran if r.status == "down")
    ok_count = sum(1 for r in ran if r.status == "ok")

    if down_count == 0:
        return "ok"
    if ok_count == 0:
        return "down"
    return "degraded"


def _timeout_probe() -> ProbeResult:
    """Return a synthetic ``down`` ProbeResult representing a timeout."""
    return ProbeResult(status="down", latency_ms=None, error="timeout", details=None)


# ---------------------------------------------------------------------------
# Banner formatting
# ---------------------------------------------------------------------------

_SEP = "=" * 64


def _fmt_status(status: str) -> str:
    """Right-pad status string for column alignment."""
    return status.ljust(8)


def _fmt_latency(latency_ms: float | None) -> str:
    """Format latency for banner display."""
    if latency_ms is None:
        return "    - ms"
    return f"{latency_ms:>6.1f} ms"


def _format_banner(report: dict[str, Any]) -> str:
    """Build the plain-ASCII startup banner string.

    The banner is suitable for printing to stdout in any container
    environment.  No ANSI colour codes are used.

    Args:
        report: The dict returned by ``collect_startup_report``.

    Returns:
        A multi-line ASCII string ending with a newline.
    """
    lines: list[str] = []

    proc = report.get("process", {})
    service_name = proc.get("service_name", "unknown")
    role = proc.get("role", "unknown")
    status = report.get("status", "unknown")
    version_str = f" v{proc.get('service_version')}" if proc.get("service_version") else ""

    lines.append(_SEP)
    lines.append(f"DealerTower Startup Report  {service_name}{version_str} ({role})  status={status}")
    lines.append(_SEP)

    # Process line
    pid = proc.get("pid", "?")
    host = proc.get("hostname", "?")
    py = proc.get("python_version", "?")
    fw = proc.get("dtpyfw_version", "?")
    lines.append(f"process    : pid={pid} host={host} python={py} dtpyfw={fw}")

    # Runtime line
    cwd = proc.get("cwd", "?")
    cpu = proc.get("cpu_count", "?")
    tz = proc.get("timezone", "?")
    uptime = proc.get("uptime_seconds")
    uptime_str = f"{uptime:.2f}s" if uptime is not None else "?"
    mem = proc.get("total_memory_mb")
    mem_str = f" mem={mem:.0f}MB" if mem is not None else ""
    lines.append(f"runtime    : cwd={cwd} cpu={cpu}{mem_str} tz={tz} uptime={uptime_str}")

    # Additional process flags
    debug = proc.get("is_debugger_active", False)
    aio = proc.get("asyncio_loop_running", False)
    lines.append(f"flags      : debugger={debug} asyncio_loop={aio}")

    lines.append("")

    # Environment section
    env = report.get("environment", {})
    reg = env.get("registered_count", 0)
    set_c = env.get("set_count", 0)
    miss = env.get("missing_count", 0)
    lines.append(f"environment ({reg} registered, {set_c} set, {miss} missing):")

    env_vars = env.get("variables", [])
    # Compute column width from the longest name so no name is truncated.
    max_name_len = max((len(v.get("name", "")) for v in env_vars), default=0)
    name_col_width = max(max_name_len, 28) + 2  # at least 30 chars total

    for var in env_vars:
        name = var.get("name", "?")
        is_secret = var.get("is_secret", False)
        is_set = var.get("is_set", False)
        value = var.get("value")

        name_col = f"  {name:<{name_col_width}}"
        if is_secret:
            lines.append(f"{name_col} [secret]")
        elif not is_set:
            lines.append(f"{name_col} [not set]")
        else:
            lines.append(f"{name_col} = {value}")

    lines.append("")

    # Logging section
    log = report.get("logging", {})
    level = log.get("level", "?")
    lprint = log.get("print", "?")
    jprint = log.get("json_print", "?")
    store = log.get("store", "?")
    celery = log.get("celery_mode", "?")
    uvicorn = log.get("uvicorn_mode", "?")
    lines.append(
        f"logging    : level={level} print={lprint} json={jprint} store={store} " f"celery={celery} uvicorn={uvicorn}"
    )
    handlers = log.get("root_handlers", [])
    lines.append(f"handlers   : {', '.join(handlers) if handlers else 'none'}")

    lines.append("")

    # Dependencies section
    deps = report.get("dependencies", {})
    lines.append("dependencies:")

    # Database
    db_probe = deps.get("database")
    if db_probe is None:
        lines.append(f"  {'database':<12}: skipped")
    else:
        st = db_probe.get("status", "?")
        lat = _fmt_latency(db_probe.get("latency_ms"))
        err = db_probe.get("error")
        err_str = f"  error={err}" if err else ""
        lines.append(f"  {'database':<12}: {_fmt_status(st)} ({lat}){err_str}")

    # Redis (list)
    redis_probes = deps.get("redis")
    if redis_probes is None:
        lines.append(f"  {'redis':<12}: skipped")
    else:
        for i, rp in enumerate(redis_probes):
            st = rp.get("status", "?")
            lat = _fmt_latency(rp.get("latency_ms"))
            err = rp.get("error")
            detail = rp.get("details") or {}
            name_hint = detail.get("name", "")
            name_str = f"  name={name_hint}" if name_hint else ""
            err_str = f"  error={err}" if err else ""
            lines.append(f"  {'redis[' + str(i) + ']':<12}: {_fmt_status(st)} ({lat}){name_str}{err_str}")

    # Singular deps
    for dep_key in ("opensearch", "kafka", "bucket", "ftp"):
        dep_probe = deps.get(dep_key)
        if dep_probe is None:
            lines.append(f"  {dep_key:<12}: skipped")
        else:
            st = dep_probe.get("status", "?")
            lat = _fmt_latency(dep_probe.get("latency_ms"))
            err = dep_probe.get("error")
            err_str = f"  error={err}" if err else ""
            lines.append(f"  {dep_key:<12}: {_fmt_status(st)} ({lat}){err_str}")

    # Extras
    extras = report.get("extras", {})
    if extras:
        lines.append("")
        lines.append("extras:")
        for extra_name, extra_result in extras.items():
            st = extra_result.get("status", "?") if isinstance(extra_result, dict) else str(extra_result)
            lines.append(f"  {extra_name:<12}: {st}")

    # Notes
    notes = report.get("notes", [])
    if notes:
        lines.append("")
        lines.append("notes:")
        lines.extend(f"  - {note}" for note in notes)

    lines.append(_SEP)

    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def collect_startup_report(
    *,
    service_name: str,
    process_role: str,
    database: Any = None,
    redis: Any = None,
    opensearch: Any = None,
    kafka: Any = None,
    bucket: Any = None,
    ftp: Any = None,
    log_config: Any = None,
    service_version: str | None = None,
    extra_probes: list[Callable[[], tuple[str, dict[str, Any]]]] | None = None,
    probe_timeout_seconds: float = 2.0,
    secret_name_hints: frozenset[str] | None = None,
) -> dict[str, Any]:
    """Collect a startup snapshot for the running process.

    All dependency probes run concurrently inside a bounded
    ``ThreadPoolExecutor``.  Each probe is individually timeout-guarded
    at ``probe_timeout_seconds``.  Environment, logging, and process
    sections are gathered synchronously (no I/O).

    No exceptions propagate from this function.  Partial failures produce
    ``"down"`` probe entries; the caller always receives a complete dict.

    Args:
        service_name: Human-readable service identifier included in the
            report and banner.
        process_role: Process role label.  Common values: ``"api"``,
            ``"worker"``, ``"streamer"``, ``"script"``.  Any string is
            accepted.
        database: ``DatabaseInstance`` to probe.  Omit or pass ``None``
            to skip the database probe.
        redis: ``RedisInstance`` **or** a list of ``RedisInstance`` objects
            to probe.  Omit or pass ``None`` to skip.
        opensearch: ``OpenSearchClient`` to probe.  ``None`` to skip.
        kafka: ``KafkaInstance`` to probe.  ``None`` to skip.
        bucket: ``Bucket`` to probe.  ``None`` to skip.
        ftp: ``FTPClient`` to probe.  ``None`` to skip.
        log_config: ``LogConfig`` instance for the logging section.
            ``None`` produces an all-``None`` logging snapshot.
        service_version: Optional version string stored in the report.
        extra_probes: Optional list of zero-argument callables, each
            returning a ``(name, result_dict)`` tuple.  Results are merged
            into ``report["extras"]``.  Each callable is run inside the
            executor with the same timeout guard.
        probe_timeout_seconds: Per-probe wall-clock timeout in seconds.
            A probe that exceeds this limit is recorded as
            ``{"status": "down", "error": "timeout"}``.
        secret_name_hints: Extra substring tokens that flag an env-var
            name as secret, merged with the default set.  ``None`` means
            use only the defaults.

    Returns:
        A plain ``dict`` matching the ``StartupReport`` schema.  Always
        contains at least ``schema_version``, ``generated_at``, ``status``,
        ``process``, ``environment``, ``logging``, ``dependencies``,
        ``extras``, and ``notes``.
    """
    notes: list[str] = []
    generated_at = datetime.datetime.now(datetime.UTC).isoformat()

    # --- synchronous sections (no I/O) ---
    try:
        process_info = probe_process(service_name, process_role, service_version)
    except Exception as exc:
        notes.append(f"process probe error: {exc}")
        # Build a minimal ProcessInfo to avoid crashing the whole report
        import os
        import platform
        import socket

        from .schema import ProcessInfo

        process_info = ProcessInfo(
            service_name=service_name,
            service_version=service_version,
            role=process_role,
            hostname=socket.gethostname(),
            pid=os.getpid(),
            python_version=platform.python_version(),
            platform=platform.platform(),
            dtpyfw_version="unknown",
            cwd=os.getcwd(),
            cpu_count=None,
            total_memory_mb=None,
            timezone="unknown",
            process_started_at=None,
            uptime_seconds=None,
            is_debugger_active=False,
            asyncio_loop_running=False,
        )

    try:
        env_info = probe_environment(secret_name_hints)
    except Exception as exc:
        notes.append(f"environment probe error: {exc}")
        from .schema import EnvironmentInfo

        env_info = EnvironmentInfo(registered_count=0, set_count=0, missing_count=0, variables=[])

    if env_info.registered_count == 0:
        notes.append("No env vars registered. Call Env.register([...]) before collect_startup_report.")

    try:
        logging_info = probe_logging(log_config)
    except Exception as exc:
        notes.append(f"logging probe error: {exc}")
        from .schema import LoggingInfo

        logging_info = LoggingInfo(
            level=None,
            print=None,
            json_print=None,
            store=None,
            api_url_set=False,
            api_key_set=False,
            celery_mode=None,
            uvicorn_mode=None,
            opensearch_mode=None,
            root_handlers=[],
        )

    # --- concurrent dependency probes ---
    # Normalise redis to a list
    redis_list: list[Any] | None = None
    if redis is not None:
        redis_list = redis if isinstance(redis, list) else [redis]

    # Build futures map
    futures: dict[str, Future[Any]] = {}
    extra_futures: dict[str, Future[Any]] = {}

    executor = ThreadPoolExecutor(max_workers=16, thread_name_prefix="dtpyfw-diag")

    if database is not None:
        futures["database"] = executor.submit(probe_database, database)

    if redis_list is not None:
        for idx, ri in enumerate(redis_list):
            # Attempt to derive a name — prefer public attribute, fall back to private
            inst_name: str | None = getattr(ri, "name", None) or getattr(ri, "_name", None)
            if inst_name is None:
                inst_name = f"redis_{idx}"
            futures[f"redis_{idx}"] = executor.submit(probe_redis, ri, inst_name)

    if opensearch is not None:
        futures["opensearch"] = executor.submit(probe_opensearch, opensearch)

    if kafka is not None:
        futures["kafka"] = executor.submit(probe_kafka, kafka, probe_timeout_seconds)

    if bucket is not None:
        futures["bucket"] = executor.submit(probe_bucket, bucket)

    if ftp is not None:
        futures["ftp"] = executor.submit(probe_ftp, ftp)

    if extra_probes:
        for ep_fn in extra_probes:
            ep_key = getattr(ep_fn, "__name__", repr(ep_fn))
            extra_futures[ep_key] = executor.submit(ep_fn)

    # Collect results with per-probe timeout
    def _collect(key: str, future: Future[ProbeResult]) -> ProbeResult:
        try:
            return future.result(timeout=probe_timeout_seconds)
        except FuturesTimeoutError:
            return _timeout_probe()
        except Exception as exc:
            return ProbeResult(status="down", error=str(exc))

    dep_results: dict[str, ProbeResult | list[ProbeResult]] = {}

    if "database" in futures:
        dep_results["database"] = _collect("database", futures["database"])

    if redis_list is not None:
        redis_results: list[ProbeResult] = []
        for idx in range(len(redis_list)):
            key = f"redis_{idx}"
            if key in futures:
                redis_results.append(_collect(key, futures[key]))
        dep_results["redis"] = redis_results

    for dep_key in ("opensearch", "kafka", "bucket", "ftp"):
        if dep_key in futures:
            dep_results[dep_key] = _collect(dep_key, futures[dep_key])

    extras_dict: dict[str, Any] = {}
    for ep_key, ep_future in extra_futures.items():
        try:
            ep_name, ep_result = ep_future.result(timeout=probe_timeout_seconds)
            extras_dict[ep_name] = ep_result
        except FuturesTimeoutError:
            extras_dict[ep_key] = {"status": "down", "error": "timeout"}
        except Exception as exc:
            extras_dict[ep_key] = {"status": "down", "error": str(exc)}

    # Release threads immediately; timed-out futures are already abandoned.
    executor.shutdown(wait=False, cancel_futures=True)

    # Build DependenciesInfo
    deps_info = DependenciesInfo(
        database=dep_results.get("database"),  # type: ignore[arg-type]
        redis=dep_results.get("redis"),  # type: ignore[arg-type]
        opensearch=dep_results.get("opensearch"),  # type: ignore[arg-type]
        kafka=dep_results.get("kafka"),  # type: ignore[arg-type]
        bucket=dep_results.get("bucket"),  # type: ignore[arg-type]
        ftp=dep_results.get("ftp"),  # type: ignore[arg-type]
    )

    # Compute aggregate status
    all_probes: list[ProbeResult] = []
    for val in dep_results.values():
        if isinstance(val, list):
            all_probes.extend(val)
        elif isinstance(val, ProbeResult):
            all_probes.append(val)
    status = _aggregate_status(all_probes)

    report = StartupReport(
        schema_version=1,
        generated_at=generated_at,
        status=status,
        process=process_info,
        environment=env_info,
        logging=logging_info,
        dependencies=deps_info,
        extras=extras_dict,
        notes=notes,
    )

    return report.model_dump()


def _acquire_parent_marker(service_name: str) -> bool:
    """Atomically claim a per-parent-process emission marker.

    Returns ``True`` when this caller is the FIRST sibling under the
    current parent process (typically a Gunicorn / Celery master) to
    request emission for ``service_name``; ``False`` when another sibling
    already claimed it.

    The marker is a zero-byte file in ``tempfile.gettempdir()`` keyed on
    ``os.getppid()`` and a sanitised ``service_name``.  Container temp
    dirs are wiped on restart so stale markers across deploys are not a
    concern.

    Never raises — any filesystem error degrades to ``True`` (proceed
    with emission) so a misbehaving tmpdir cannot silence diagnostics.
    """
    import os
    import re
    import tempfile

    try:
        safe_name = re.sub(r"[^a-zA-Z0-9_-]+", "_", service_name) or "service"
        marker_path = os.path.join(
            tempfile.gettempdir(),
            f"dtpyfw-startup-{os.getppid()}-{safe_name}.lock",
        )
        fd = os.open(marker_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
        return True
    except FileExistsError:
        return False
    except Exception:
        return True


def emit_startup_report(
    *,
    service_name: str,
    process_role: str,
    database: Any = None,
    redis: Any = None,
    opensearch: Any = None,
    kafka: Any = None,
    bucket: Any = None,
    ftp: Any = None,
    log_config: Any = None,
    service_version: str | None = None,
    extra_probes: list[Callable[[], tuple[str, dict[str, Any]]]] | None = None,
    probe_timeout_seconds: float = 2.0,
    secret_name_hints: frozenset[str] | None = None,
    print_banner: bool = True,
    log_via_footprint: bool = True,
    emit_once_per_parent: bool = True,
) -> dict[str, Any]:
    """Collect a startup snapshot and emit it to stdout and/or ``footprint``.

    This is the recommended entry point for service boot sequences.
    It calls ``collect_startup_report`` with the same arguments and then
    emits the result.  All arguments beyond ``print_banner``,
    ``log_via_footprint``, and ``emit_once_per_parent`` are forwarded
    unchanged.

    Emission targets:

    - **stdout banner** (``print_banner=True``): A fixed-width plain ASCII
      block written with ``print()`` to ``sys.stdout``.  This remains
      visible even before the logging stack is initialised.
    - **footprint** (``log_via_footprint=True``): One structured log call
      via ``dtpyfw.log.footprint.leave``.  ``log_type`` mirrors the
      aggregate status (``"info"`` → ok, ``"warning"`` → degraded,
      ``"error"`` → down).

    This function never raises and never blocks startup.

    Args:
        service_name: Human-readable service identifier.
        process_role: Process role label (``"api"``, ``"worker"``, etc.).
        database: Optional ``DatabaseInstance`` to probe.
        redis: Optional ``RedisInstance`` or list thereof to probe.
        opensearch: Optional ``OpenSearchClient`` to probe.
        kafka: Optional ``KafkaInstance`` to probe.
        bucket: Optional ``Bucket`` to probe.
        ftp: Optional ``FTPClient`` to probe.
        log_config: Optional ``LogConfig`` for the logging section.
        service_version: Optional version string.
        extra_probes: Optional list of callables returning
            ``(name, result_dict)``.
        probe_timeout_seconds: Per-probe wall-clock timeout.
        secret_name_hints: Extra secret-name hint tokens.
        print_banner: When ``True`` (default), print the ASCII banner to
            ``sys.stdout``.
        log_via_footprint: When ``True`` (default), call
            ``footprint.leave`` with the full report as payload.
        emit_once_per_parent: When ``True`` (default), only the first
            sibling process under the current parent (e.g. the first
            Gunicorn worker under its master, the first Celery worker
            under its master) actually probes and emits.  Other siblings
            return a stub dict with ``status="skipped"`` after a
            ``FileExistsError`` on the parent-keyed marker.  Set to
            ``False`` for single-process callers (scripts, one-off
            healthchecks) when you want every invocation to emit.

    Returns:
        The same ``dict`` returned by ``collect_startup_report``, OR a
        small stub ``{"schema_version": 1, "status": "skipped", ...}``
        when ``emit_once_per_parent`` short-circuits this caller.
    """
    if emit_once_per_parent and not _acquire_parent_marker(service_name):
        return {
            "schema_version": 1,
            "status": "skipped",
            "skipped_reason": "duplicate_parent",
            "process": {"service_name": service_name, "role": process_role},
        }

    report = collect_startup_report(
        service_name=service_name,
        process_role=process_role,
        database=database,
        redis=redis,
        opensearch=opensearch,
        kafka=kafka,
        bucket=bucket,
        ftp=ftp,
        log_config=log_config,
        service_version=service_version,
        extra_probes=extra_probes,
        probe_timeout_seconds=probe_timeout_seconds,
        secret_name_hints=secret_name_hints,
    )

    if print_banner:
        try:
            banner = _format_banner(report)
            print(banner, file=sys.stdout, end="", flush=True)
        except Exception:
            pass  # Never block startup due to banner formatting

    if log_via_footprint:
        try:
            from dtpyfw.log import footprint

            status = report.get("status", "unknown")
            log_type = "info" if status == "ok" else ("warning" if status == "degraded" else "error")
            footprint.leave(
                log_type=log_type,
                controller="dtpyfw.diagnostics.report.emit_startup_report",
                subject="Startup Report",
                message=f"Startup snapshot for {service_name} ({process_role}) — status={status}",
                payload=report,
            )
        except Exception:
            pass  # Never block startup due to footprint failure

    return report
