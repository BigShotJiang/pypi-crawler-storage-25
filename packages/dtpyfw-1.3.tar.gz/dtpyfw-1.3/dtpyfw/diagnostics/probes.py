"""Probe functions for every supported dependency type.

Design principles
-----------------
- **Never raise.** Every probe body is wrapped in ``try/except Exception``.
  Failures produce ``{"status": "down", "error": str(exc), "latency_ms": elapsed}``.
- **Import lazily.** Each probe imports its dtpyfw subpackage inside the
  function body so that a missing extra downgrades the probe to
  ``{"status": "skipped"}`` without aborting the whole report.
- **Minimal I/O.** Probes do the smallest possible operation that
  exercises the network path (``SELECT 1``, ``PING``, list 1 object, …).
- **Attribute-based LogConfig reading.** ``_probe_logging`` reads
  ``LogConfig`` fields via ``getattr`` so the log subpackage is not
  imported at module level and no coupling is introduced.

Attributes read from ``LogConfig`` via ``getattr``:
    ``_config["log_level"]``, ``_config["log_print"]``,
    ``_config["json_log_print"]``, ``_config["log_store"]``,
    ``_config["api_url"]``, ``_config["api_key"]``,
    ``_config["celery_mode"]``, ``_config["uvicorn_mode"]``,
    ``_config["opensearch_mode"]``.
"""

from __future__ import annotations

import asyncio
import datetime
import logging
import os
import platform
import socket
import sys
import time
from typing import Any, Literal

from .redact import is_secret_name, scrub_url
from .schema import (
    EnvironmentInfo,
    EnvVarInfo,
    LoggingInfo,
    ProbeResult,
    ProcessInfo,
)

__all__ = (
    "probe_bucket",
    "probe_database",
    "probe_environment",
    "probe_ftp",
    "probe_kafka",
    "probe_logging",
    "probe_opensearch",
    "probe_process",
    "probe_redis",
)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_SKIPPED: dict[str, Any] = {"latency_ms": None, "error": None, "details": None}


def _timed_probe(
    fn: Any,
) -> tuple[Literal["ok", "down"], float | None, str | None, dict[str, Any] | None]:
    """Run *fn()* and return (status, latency_ms, error, details).

    Args:
        fn: Zero-argument callable that returns ``(ok: bool, error: Exception | None, details: dict | None)``.

    Returns:
        Four-tuple of status literal, latency in ms (or None), error string
        (or None), and optional detail dict.
    """
    t0 = time.monotonic()
    try:
        ok, err, details = fn()
        latency_ms = round((time.monotonic() - t0) * 1000, 2)
        if ok:
            return "ok", latency_ms, None, details
        return "down", latency_ms, str(err) if err else "probe returned False", details
    except Exception as exc:
        latency_ms = round((time.monotonic() - t0) * 1000, 2)
        return "down", latency_ms, str(exc), None


# ---------------------------------------------------------------------------
# Dependency probes
# ---------------------------------------------------------------------------


def probe_database(database_instance: Any) -> ProbeResult:
    """Probe a ``DatabaseInstance`` for connectivity.

    Calls ``dtpyfw.db.health.is_database_connected`` which executes
    ``SELECT 1`` on both the write and read engines.

    Args:
        database_instance: A ``dtpyfw.db.database.DatabaseInstance``.

    Returns:
        A ``ProbeResult`` with ``status`` ``"ok"``, ``"down"``, or
        ``"skipped"`` when the ``[db]`` extra is not installed.
    """
    try:
        from dtpyfw.db.health import is_database_connected
    except ImportError:
        return ProbeResult(status="skipped", **_SKIPPED)

    def _run() -> tuple[bool, Exception | None, dict[str, Any] | None]:
        ok, err = is_database_connected(database_instance)
        return ok, err, None

    status, latency_ms, error, details = _timed_probe(_run)
    return ProbeResult(status=status, latency_ms=latency_ms, error=error, details=details)


def probe_redis(redis_instance: Any, name: str | None = None) -> ProbeResult:
    """Probe a single ``RedisInstance`` for connectivity.

    Calls ``dtpyfw.redis.health.is_redis_connected`` which sends a
    ``PING`` command and verifies the response.

    Args:
        redis_instance: A ``dtpyfw.redis.connection.RedisInstance``.
        name: Optional human-readable label for this instance (shown in
            the banner and stored in ``details``).

    Returns:
        A ``ProbeResult`` with the instance name in ``details`` when
        provided.
    """
    try:
        from dtpyfw.redis.health import is_redis_connected
    except ImportError:
        return ProbeResult(status="skipped", **_SKIPPED)

    def _run() -> tuple[bool, Exception | None, dict[str, Any] | None]:
        ok, err = is_redis_connected(redis_instance)
        detail: dict[str, Any] | None = {"name": name} if name else None
        return ok, err, detail

    status, latency_ms, error, details = _timed_probe(_run)
    if name and details is None:
        details = {"name": name}
    return ProbeResult(status=status, latency_ms=latency_ms, error=error, details=details)


def probe_opensearch(opensearch_client: Any) -> ProbeResult:
    """Probe an ``OpenSearchClient`` for cluster connectivity.

    Calls ``dtpyfw.opensearch.health.is_opensearch_connected`` which
    invokes the client's ``is_healthy()`` method.

    Args:
        opensearch_client: A ``dtpyfw.opensearch.client.OpenSearchClient``.

    Returns:
        A ``ProbeResult`` reflecting cluster availability.
    """
    try:
        from dtpyfw.opensearch.health import is_opensearch_connected
    except ImportError:
        return ProbeResult(status="skipped", **_SKIPPED)

    def _run() -> tuple[bool, Exception | None, dict[str, Any] | None]:
        ok, err = is_opensearch_connected(opensearch_client)
        return ok, err, None

    status, latency_ms, error, details = _timed_probe(_run)
    return ProbeResult(status=status, latency_ms=latency_ms, error=error, details=details)


def probe_kafka(kafka_instance: Any, probe_timeout_seconds: float = 2.0) -> ProbeResult:
    """Probe a ``KafkaInstance`` by attempting to create a short-lived producer.

    Creates a producer and immediately closes it.  The probe succeeds when
    ``KafkaProducer`` initialises without error, which implies that the
    broker is reachable and credentials are valid.

    Args:
        kafka_instance: A ``dtpyfw.kafka.connection.KafkaInstance``.
        probe_timeout_seconds: Outer deadline passed down from the report
            collector; inner waits are bounded to one third of this value
            so that three sequential calls fit within the outer timeout.

    Returns:
        A ``ProbeResult`` with the bootstrap servers in ``details``.
    """
    try:
        from dtpyfw.kafka.connection import (  # noqa: F401 — import check only
            KafkaInstance,
        )
    except ImportError:
        return ProbeResult(status="skipped", **_SKIPPED)

    # Bound each inner wait so three sequential calls fit within the outer timeout.
    inner_ms = int(max(500, probe_timeout_seconds / 3) * 1000)
    inner_s = max(0.5, probe_timeout_seconds / 3)

    def _run() -> tuple[bool, Exception | None, dict[str, Any] | None]:
        try:
            _base = getattr(kafka_instance, "_base", None)
            bootstrap = _base.get("bootstrap_servers") if isinstance(_base, dict) else None
        except Exception:
            bootstrap = None
        producer = kafka_instance.get_producer(request_timeout_ms=inner_ms, max_block_ms=inner_ms)
        producer.flush(timeout=inner_s)
        producer.close(timeout=inner_s)
        return True, None, {"bootstrap_servers": bootstrap}

    status, latency_ms, error, details = _timed_probe(_run)
    return ProbeResult(status=status, latency_ms=latency_ms, error=error, details=details)


def probe_bucket(bucket_instance: Any) -> ProbeResult:
    """Probe an S3-compatible ``Bucket`` by listing up to one object.

    Uses ``list_objects(prefix="", max_keys=1)`` — a lightweight paginator
    call that requires valid credentials and reachable endpoint.

    Args:
        bucket_instance: A ``dtpyfw.bucket.bucket.Bucket``.

    Returns:
        A ``ProbeResult`` with the bucket name in ``details``.
    """
    try:
        from dtpyfw.bucket.bucket import Bucket  # noqa: F401 — import check only
    except ImportError:
        return ProbeResult(status="skipped", **_SKIPPED)

    def _run() -> tuple[bool, Exception | None, dict[str, Any] | None]:
        bucket_name = bucket_instance.get_bucket_name()
        bucket_instance.list_objects(prefix="", max_keys=1)
        return True, None, {"bucket_name": bucket_name}

    status, latency_ms, error, details = _timed_probe(_run)
    return ProbeResult(status=status, latency_ms=latency_ms, error=error, details=details)


def probe_ftp(ftp_client: Any) -> ProbeResult:
    """Probe an ``FTPClient`` by performing the cheapest available connectivity check.

    Calls ``check_connection()`` which opens a connection, sends a ``NOOP``
    (FTP) or ``normalize(".")`` (SFTP), and immediately closes it.  No
    directory listing is performed.

    Args:
        ftp_client: A ``dtpyfw.ftp.client.FTPClient``.

    Returns:
        A ``ProbeResult`` with the server address in ``details``.
    """
    try:
        from dtpyfw.ftp.client import FTPClient  # noqa: F401 — import check only
    except ImportError:
        return ProbeResult(status="skipped", **_SKIPPED)

    def _run() -> tuple[bool, Exception | None, dict[str, Any] | None]:
        server = getattr(ftp_client, "server", None)
        port = getattr(ftp_client, "port", None)
        ok, err = ftp_client.check_connection()
        return ok, err, {"server": server, "port": port}

    status, latency_ms, error, details = _timed_probe(_run)
    return ProbeResult(status=status, latency_ms=latency_ms, error=error, details=details)


# ---------------------------------------------------------------------------
# Always-on probes (no extra deps)
# ---------------------------------------------------------------------------


def probe_environment(extra_hints: frozenset[str] | None = None) -> EnvironmentInfo:
    """Snapshot all variables registered with ``Env.register``.

    For non-secret variables the actual value is surfaced.  URL-shaped
    values have their ``userinfo`` component scrubbed before display.
    Secret variables show only their name with a ``[secret]`` marker —
    the value is always ``None`` in the returned dict.

    Args:
        extra_hints: Optional additional tokens (merged with
            ``DEFAULT_SECRET_HINTS``) that flag a variable as secret.

    Returns:
        An ``EnvironmentInfo`` instance listing all registered variables.
    """
    from dtpyfw.core.env import Env

    registered = Env.registered()
    variables: list[EnvVarInfo] = []

    for name in registered:
        secret = is_secret_name(name, extra_hints)
        raw = Env.get(name)
        is_set = raw is not None

        if secret or not is_set:
            display_value: str | None = None
        else:
            # Scrub userinfo from URL-shaped non-secret values
            display_value = scrub_url(raw)

        variables.append(
            EnvVarInfo(
                name=name,
                is_secret=secret,
                is_set=is_set,
                value=display_value,
            )
        )

    set_count = sum(1 for v in variables if v.is_set)
    missing_count = len(variables) - set_count

    return EnvironmentInfo(
        registered_count=len(variables),
        set_count=set_count,
        missing_count=missing_count,
        variables=variables,
    )


def probe_logging(log_config: Any | None) -> LoggingInfo:
    """Snapshot the active ``LogConfig`` settings via defensive attribute reads.

    All ``LogConfig`` fields are read through ``getattr`` on the internal
    ``_config`` dict so this function never raises even when ``log_config``
    is ``None`` or a partially-built instance.

    Attributes read from ``log_config._config``:
        ``log_level``, ``log_print``, ``json_log_print``, ``log_store``,
        ``api_url``, ``api_key``, ``celery_mode``, ``uvicorn_mode``,
        ``opensearch_mode``.

    Args:
        log_config: A ``dtpyfw.log.config.LogConfig`` instance or ``None``.

    Returns:
        A ``LoggingInfo`` instance populated from the config (or all
        ``None`` / ``False`` fields when config is absent).
    """
    cfg: dict[str, Any] = {}
    if log_config is not None:
        cfg = getattr(log_config, "_config", {}) or {}  # private attr read is intentional — no public accessor

    root_logger = logging.getLogger()
    handler_names = [type(h).__name__ for h in root_logger.handlers]

    return LoggingInfo(
        level=cfg.get("log_level"),
        print=cfg.get("log_print"),
        json_print=cfg.get("json_log_print"),
        store=cfg.get("log_store"),
        api_url_set=bool(cfg.get("api_url")),
        api_key_set=bool(cfg.get("api_key")),
        celery_mode=cfg.get("celery_mode"),
        uvicorn_mode=cfg.get("uvicorn_mode"),
        opensearch_mode=cfg.get("opensearch_mode"),
        root_handlers=handler_names,
    )


def probe_process(
    service_name: str,
    process_role: str,
    service_version: str | None,
) -> ProcessInfo:
    """Collect runtime process metadata.

    Includes hostname, PID, Python version, platform string, dtpyfw
    version, current working directory, CPU count, total memory (via
    ``psutil`` when available), timezone, process start time, uptime,
    debugger detection, and asyncio loop status.

    Args:
        service_name: Consumer-supplied identifier for the service.
        process_role: Role label such as ``"api"``, ``"worker"``, or
            ``"script"``.
        service_version: Consumer-supplied version string, or ``None``.

    Returns:
        A fully populated ``ProcessInfo`` instance.
    """
    # dtpyfw version
    try:
        from importlib.metadata import PackageNotFoundError
        from importlib.metadata import version as pkg_version

        try:
            dtpyfw_ver = pkg_version("dtpyfw")
        except PackageNotFoundError:
            dtpyfw_ver = "unknown"
    except Exception:
        dtpyfw_ver = "unknown"

    # CPU count
    cpu_count: int | None = os.cpu_count()

    # Total memory and process start time via psutil (optional)
    total_memory_mb: float | None = None
    process_started_at: str | None = None
    uptime_seconds: float | None = None
    try:
        import psutil

        total_memory_mb = round(psutil.virtual_memory().total / (1024 * 1024), 1)
        proc = psutil.Process(os.getpid())
        create_time = proc.create_time()
        dt = datetime.datetime.fromtimestamp(create_time, tz=datetime.UTC)
        process_started_at = dt.isoformat()
        uptime_seconds = round(time.time() - create_time, 2)
    except ImportError:
        pass
    except Exception:
        pass

    # Timezone
    try:
        tz_name = time.strftime("%Z")
    except Exception:
        tz_name = "unknown"

    # Debugger detection
    try:
        is_debugger_active = sys.gettrace() is not None
    except Exception:
        is_debugger_active = False

    # asyncio loop running in calling thread
    try:
        asyncio.get_running_loop()
        asyncio_loop_running = True
    except RuntimeError:
        asyncio_loop_running = False

    return ProcessInfo(
        service_name=service_name,
        service_version=service_version,
        role=process_role,
        hostname=socket.gethostname(),
        pid=os.getpid(),
        python_version=platform.python_version(),
        platform=platform.platform(),
        dtpyfw_version=dtpyfw_ver,
        cwd=os.getcwd(),
        cpu_count=cpu_count,
        total_memory_mb=total_memory_mb,
        timezone=tz_name,
        process_started_at=process_started_at,
        uptime_seconds=uptime_seconds,
        is_debugger_active=is_debugger_active,
        asyncio_loop_running=asyncio_loop_running,
    )
