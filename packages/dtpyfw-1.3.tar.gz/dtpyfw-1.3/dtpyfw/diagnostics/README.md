# Diagnostics

Boot-time health snapshots for microservices.

`collect_startup_report(...)` and `emit_startup_report(...)` gather process metadata, environment state, and concurrent dependency probes into a structured dict or JSON log.

All probes run in parallel with per-probe timeouts; the functions never raise or block startup.

See [../../.claude/rules/dtpyfw-diagnostics.md](../../.claude/rules/dtpyfw-diagnostics.md) for the complete API, behavior contract, integration patterns, and gotchas.

Quick example:

```python
from dtpyfw.diagnostics import emit_startup_report
from app.config.database import database
from app.config.log import log_config

emit_startup_report(
    service_name="my-service",
    process_role="api",
    service_version="1.0",
    database=database,
    log_config=log_config,
)
```

The result is printed as an ASCII banner to stdout and logged via `footprint.leave()`.
