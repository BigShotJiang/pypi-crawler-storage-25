"""dtpyfw.diagnostics — startup snapshot utilities.

Provides two public callables that consumers can wire into their boot
sequence to capture and emit a structured runtime snapshot without
blocking startup or raising on partial failures.

Public API::

    from dtpyfw.diagnostics import collect_startup_report, emit_startup_report
    from dtpyfw.diagnostics import StartupReport, ProbeResult

No extras are imported at module level; every optional dependency
(db, redis, opensearch, kafka, bucket, ftp) is imported lazily inside
the probe functions and gracefully downgrades to ``{"status": "skipped"}``
when the extra is not installed.
"""

from __future__ import annotations

from .report import collect_startup_report, emit_startup_report
from .schema import ProbeResult, StartupReport

__all__ = (
    "ProbeResult",
    "StartupReport",
    "collect_startup_report",
    "emit_startup_report",
)
