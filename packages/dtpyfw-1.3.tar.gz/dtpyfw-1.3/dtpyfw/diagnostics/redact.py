"""Secret-name detection and URL scrubbing for diagnostic output.

Rules
-----
- A variable name is considered secret when any token in
  ``DEFAULT_SECRET_HINTS`` appears as a *substring* (case-insensitive)
  of the variable name.
- URL values are scrubbed of their ``userinfo`` component (the
  ``user:password@`` part) before being surfaced in non-secret env-var
  output so that connection strings do not leak credentials even when
  the *variable name* is not flagged as secret.
"""

from __future__ import annotations

import re
from urllib.parse import urlparse, urlunparse

__all__ = (
    "DEFAULT_SECRET_HINTS",
    "is_secret_name",
    "scrub_url",
)

# ---------------------------------------------------------------------------
# Default set of substring tokens that mark a variable as secret.
# Checked case-insensitively against the full variable name.
# NOTE: "URL" and "CONNECTION" are intentionally omitted — many URL/connection
#       variables are non-secret endpoints; URL values have their userinfo
#       component scrubbed by scrub_url() instead of hiding the whole value.
# ---------------------------------------------------------------------------
DEFAULT_SECRET_HINTS: frozenset[str] = frozenset(
    {
        "PASSWORD",
        "SECRET",
        "TOKEN",
        "KEY",
        "DSN",
        "PRIVATE",
        "CREDENTIAL",
        "AUTH",
        "LICENSE",
        "APIKEY",
    }
)

# Pre-compile a regex that detects common URL schemes so we can route
# values through scrub_url when the variable is *not* flagged as secret
# but the value looks like a URL with embedded credentials.
_URL_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+\-.]*://")


def is_secret_name(name: str, extra_hints: frozenset[str] | None = None) -> bool:
    """Return ``True`` when ``name`` contains any secret hint substring.

    The check is case-insensitive and substring-based: ``"DB_PASSWORD"``
    matches because ``"PASSWORD"`` is a substring of it.

    Args:
        name: Environment variable name to evaluate (case-insensitive).
        extra_hints: Optional additional hints merged with
            ``DEFAULT_SECRET_HINTS`` for this call.

    Returns:
        ``True`` if the name should be treated as secret, ``False``
        otherwise.
    """
    upper = name.upper()
    hints = DEFAULT_SECRET_HINTS
    if extra_hints:
        hints = hints | extra_hints
    return any(hint in upper for hint in hints)


def scrub_url(value: str | None) -> str | None:
    """Strip ``userinfo`` (``user:password@``) from a URL-shaped value.

    If ``value`` is ``None``, empty, or does not look like a URL with a
    scheme, it is returned unchanged.  The function never raises; malformed
    URLs are returned as-is.

    Args:
        value: String that may or may not be a URL, or ``None``.

    Returns:
        The original string with any ``userinfo`` component removed, or
        the original value unchanged when it is not URL-shaped or is ``None``.
    """
    if not value:
        return value
    if not _URL_SCHEME_RE.match(value):
        return value
    try:
        parsed = urlparse(value)
        # Replace netloc: strip userinfo but keep host and port
        if parsed.username or parsed.password:
            host_part = parsed.hostname or ""
            if parsed.port:
                host_part = f"{host_part}:{parsed.port}"
            clean = parsed._replace(netloc=host_part)
            return urlunparse(clean)
        return value
    except Exception:
        return value
