"""Pydantic v2 models for the dtpyfw startup report.

These models define the structure of the dict returned by
``collect_startup_report``.  They are kept intentionally flat so that
``json.dumps(report, default=str)`` always succeeds without a custom
encoder.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict

__all__ = (
    "DependenciesInfo",
    "EnvVarInfo",
    "EnvironmentInfo",
    "LoggingInfo",
    "ProbeResult",
    "ProcessInfo",
    "StartupReport",
)


class ProbeResult(BaseModel):
    """Result of a single dependency connectivity probe.

    Attributes:
        status: One of ``"ok"``, ``"down"``, or ``"skipped"``.
        latency_ms: Round-trip time for the probe in milliseconds,
            or ``None`` when not applicable.
        error: Human-readable error message when ``status`` is ``"down"``,
            or ``None`` on success.
        details: Optional extra information returned by the probe.
    """

    model_config = ConfigDict(from_attributes=True)

    status: Literal["ok", "down", "skipped"]
    latency_ms: float | None = None
    error: str | None = None
    details: dict[str, Any] | None = None


class EnvVarInfo(BaseModel):
    """Snapshot of a single registered environment variable.

    Attributes:
        name: Uppercase variable name as registered with ``Env.register``.
        is_secret: ``True`` when the name matches a secret hint and the
            real value must never be surfaced.
        is_set: ``True`` when the variable is present in the environment.
        value: The actual value for non-secret variables that are set;
            always ``None`` for secrets and for unset variables.
    """

    model_config = ConfigDict(from_attributes=True)

    name: str
    is_secret: bool
    is_set: bool
    value: str | None


class EnvironmentInfo(BaseModel):
    """Aggregate view of all registered environment variables.

    Attributes:
        registered_count: Total number of variables registered via
            ``Env.register``.
        set_count: Number of registered variables that have a value.
        missing_count: Number of registered variables with no value.
        variables: Per-variable detail list, sorted by name.
    """

    model_config = ConfigDict(from_attributes=True)

    registered_count: int
    set_count: int
    missing_count: int
    variables: list[EnvVarInfo]


class LoggingInfo(BaseModel):
    """Snapshot of the active ``LogConfig`` settings.

    Attributes are read defensively via ``getattr`` so this model
    never raises when ``log_config`` is ``None`` or partially built.

    Attributes:
        level: Effective logging level string, e.g. ``"INFO"``.
        print: Whether console output is enabled.
        json_print: Whether JSON-formatted console output is enabled.
        store: Whether remote log-store (logging MS) is enabled.
        api_url_set: Whether a logging MS URL has been configured.
        api_key_set: Whether a logging MS API key has been configured.
        celery_mode: Whether Celery logging integration is active.
        uvicorn_mode: Whether Uvicorn logging integration is active.
        opensearch_mode: Whether OpenSearch library log suppression is active.
        root_handlers: Names of handlers attached to the root logger.
    """

    model_config = ConfigDict(from_attributes=True)

    level: str | None
    print: bool | None
    json_print: bool | None
    store: bool | None
    api_url_set: bool
    api_key_set: bool
    celery_mode: bool | None
    uvicorn_mode: bool | None
    opensearch_mode: bool | None
    root_handlers: list[str]


class ProcessInfo(BaseModel):
    """Runtime process metadata collected at report generation time.

    Attributes:
        service_name: Consumer-supplied service identifier.
        service_version: Consumer-supplied service version string.
        role: Process role label such as ``"api"``, ``"worker"``, or
            ``"script"``.
        hostname: Container or machine hostname.
        pid: Operating system process identifier.
        python_version: Full Python version string, e.g. ``"3.13.0"``.
        platform: Platform description string.
        dtpyfw_version: Installed ``dtpyfw`` package version.
        cwd: Current working directory at report generation time.
        cpu_count: Number of logical CPUs available to the process, or
            ``None`` when unavailable.
        total_memory_mb: Total system memory in mebibytes when ``psutil``
            is available, otherwise ``None``.
        timezone: Local timezone name reported by the operating system.
        process_started_at: ISO-8601 timestamp when the process started,
            derived from the process creation time, or ``None`` when
            unavailable.
        uptime_seconds: Seconds elapsed since the process started, or
            ``None`` when unavailable.
        is_debugger_active: ``True`` when a debugger is detected (``sys.gettrace``).
        asyncio_loop_running: ``True`` when an asyncio event loop is active
            in the calling thread.
    """

    model_config = ConfigDict(from_attributes=True)

    service_name: str
    service_version: str | None
    role: str
    hostname: str
    pid: int
    python_version: str
    platform: str
    dtpyfw_version: str
    cwd: str
    cpu_count: int | None
    total_memory_mb: float | None
    timezone: str
    process_started_at: str | None
    uptime_seconds: float | None
    is_debugger_active: bool
    asyncio_loop_running: bool


class DependenciesInfo(BaseModel):
    """Probe outcomes for each optional dependency.

    Each field is either a ``ProbeResult`` (for singular dependencies),
    a list of ``ProbeResult`` (for Redis, which may have multiple
    instances), or ``None`` when the dependency was not passed by the
    caller (equivalent to ``{"status": "skipped"}``).

    Attributes:
        database: Database connectivity probe result.
        redis: Redis probe results; one entry per instance passed.
        opensearch: OpenSearch probe result.
        kafka: Kafka probe result.
        bucket: S3-compatible bucket probe result.
        ftp: FTP/SFTP probe result.
    """

    model_config = ConfigDict(from_attributes=True)

    database: ProbeResult | None = None
    redis: list[ProbeResult] | None = None
    opensearch: ProbeResult | None = None
    kafka: ProbeResult | None = None
    bucket: ProbeResult | None = None
    ftp: ProbeResult | None = None


class StartupReport(BaseModel):
    """Complete startup snapshot for a single process boot.

    Attributes:
        schema_version: Always ``1``; bump when the structure changes.
        generated_at: ISO-8601 UTC timestamp when the report was built.
        status: Aggregate health: ``"ok"`` all probes passed,
            ``"degraded"`` at least one probe failed, ``"down"`` every
            probe that ran failed.
        process: Runtime process metadata.
        environment: Registered environment variable snapshot.
        logging: Active logging configuration snapshot.
        dependencies: Per-dependency probe results.
        extras: Results from caller-supplied extra probes.
        notes: Free-text annotations added by the report builder.
    """

    model_config = ConfigDict(from_attributes=True)

    schema_version: Literal[1] = 1
    generated_at: str
    status: Literal["ok", "degraded", "down"]
    process: ProcessInfo
    environment: EnvironmentInfo
    logging: LoggingInfo
    dependencies: DependenciesInfo
    extras: dict[str, Any]
    notes: list[str]
