"""API-based log handler for sending logs to remote endpoints."""

import json
import logging
import queue
import threading
from time import sleep
from typing import Any

import requests

from . import footprint

__all__ = ("LoggerHandler",)


class Logger:
    """A client for sending log records to a remote API endpoint.

    This class handles the HTTP POST request to the logging API, including
    authentication and JSON serialization. It also implements a retry
    mechanism with backoff for transient network errors.

    Args:
        logging_api_url: The URL of the remote logging API endpoint.
        logging_api_key: The API key for authenticating with the logging API.
    """

    def __init__(self, logging_api_url: str, logging_api_key: str) -> None:
        """Initialize the Logger client with API endpoint and authentication.

        Args:
            logging_api_url: The URL of the remote logging API endpoint.
            logging_api_key: The API key for authenticating with the logging API.
        """
        self.api_url = logging_api_url
        self.api_key = logging_api_key

        self.headers = {
            "Authorization": f"{self.api_key}",
            "Content-Type": "application/json",
        }

    def log(self, details: dict[str, Any]) -> bool | None:
        """Send a log entry to the remote API.

        Attempts to send a log entry to the configured remote API endpoint
        with retry logic for handling transient network failures. Retries up
        to 3 times with a 1-second backoff between attempts.

        Args:
            details: A dictionary containing the log data to be sent to the API.

        Returns:
            True if the log was successfully sent, None otherwise.
        """
        controller = f"{__name__}.Logger.log"
        max_retries = 3
        backoff_seconds = 1
        for attempt in range(1, max_retries + 1):
            try:
                response = requests.post(
                    url=self.api_url,
                    data=json.dumps(details, default=str),
                    headers=self.headers,
                    timeout=5,
                )
                response.raise_for_status()
                return True
            except requests.exceptions.RequestException as e:
                if attempt < max_retries:
                    sleep(backoff_seconds)
                else:
                    footprint.leave(
                        log_type="warning",
                        controller=controller,
                        subject="Log Sending Error",
                        message=f"Failed to send log to API: {e}",
                        payload={
                            "data": details,
                        },
                    )
        return None


class LoggerHandler(logging.Handler):
    """A logging handler that sends log records to a remote API.

    This handler integrates with Python's logging framework to forward log
    records to a remote API endpoint. It can be configured to filter logs,
    sending only those marked as "footprints" when in footprint-only mode.

    Log records are enqueued immediately and delivered by a single background
    worker thread. ``emit`` never blocks the caller. On ``close()``, the
    handler waits up to 10 seconds for the worker to drain remaining items
    before returning — ensuring graceful-shutdown contexts (FastAPI, Celery,
    Redis Streamer) do not lose in-flight logs.

    Args:
        logging_api_url: The URL of the remote logging API endpoint.
        logging_api_key: The API key for authenticating with the logging API.
        only_footprint_mode: If True, only send logs marked as footprints.

    Attributes:
        only_footprint_mode: Whether to filter non-footprint logs.
        logger: The Logger instance used to send logs to the API.
    """

    _DRAIN_TIMEOUT = 10  # seconds to wait for worker drain on close()

    def __init__(
        self,
        logging_api_url: str,
        logging_api_key: str,
        only_footprint_mode: bool,
    ) -> None:
        """Initialize the LoggerHandler with API configuration.

        Args:
            logging_api_url: The URL of the remote logging API endpoint.
            logging_api_key: The API key for authenticating with the logging API.
            only_footprint_mode: If True, only send logs marked as footprints.
        """
        super().__init__()
        self.only_footprint_mode = only_footprint_mode
        self.logger = Logger(
            logging_api_url=logging_api_url,
            logging_api_key=logging_api_key,
        )
        self._queue: queue.SimpleQueue[dict[str, Any] | None] = queue.SimpleQueue()
        self._worker = threading.Thread(
            target=self._drain,
            daemon=True,
            name="dtpyfw-log-worker",
        )
        self._worker.start()

    def _drain(self) -> None:
        while True:
            item = self._queue.get()
            if item is None:  # stop sentinel from close()
                return
            self.logger.log(details=item)

    def emit(self, record: logging.LogRecord) -> None:
        """Enqueue a log record for delivery to the remote API.

        Returns immediately — the background worker thread performs the
        actual HTTP POST. When ``only_footprint_mode`` is enabled, non-
        footprint records are discarded before enqueuing.

        Args:
            record: The log record to be emitted to the remote API.
        """
        details = record.__dict__.get("details") or {}

        if self.only_footprint_mode and not details.get("footprint"):
            return None

        details["log_type"] = details.get("log_type") or record.levelname.lower()
        details["subject"] = details.get("subject") or "Unnamed"
        details["controller"] = details.get("controller") or record.funcName
        details["message"] = details.get("message") or self.format(record)
        self._queue.put(details)

    def close(self) -> None:
        """Stop the background worker and wait for queued items to drain.

        Sends a stop sentinel to the worker thread and waits up to
        ``_DRAIN_TIMEOUT`` seconds for remaining items to be delivered.
        Called automatically by ``logging.shutdown()`` at process exit.
        """
        self._queue.put(None)  # sentinel
        self._worker.join(timeout=self._DRAIN_TIMEOUT)
        super().close()
