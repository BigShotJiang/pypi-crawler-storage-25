"""Logging configuration management."""

from typing import Self

from ..core.coerce import coerce_bool
from ..core.config import ConfigBuilder

__all__ = ("LogConfig",)


class LogConfig(ConfigBuilder):
    """A builder for configuring the logging system.

    This class provides a fluent interface for setting logging configuration
    options such as API endpoints, log levels, file storage, and Celery mode.
    All setter methods return self to enable method chaining.

    Attributes:
        _config: Internal dictionary storing configuration key-value pairs.

    Example:
        >>> config = LogConfig()
        >>> config.set_api_url("https://api.example.com/logs") \\
        ...       .set_log_level("DEBUG") \\
        ...       .set_log_print("true")
    """

    def set_api_url(self, api_url: str) -> Self:
        """Set the URL for the remote logging API.

        Args:
            api_url: The URL endpoint for the remote logging API.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["api_url"] = api_url
        return self

    def set_api_key(self, api_key: str) -> Self:
        """Set the API key for the remote logging API.

        Args:
            api_key: The authentication key for the remote logging API.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["api_key"] = api_key
        return self

    def set_log_print(self, log_print: bool | str = True) -> Self:
        """Set whether to print logs to the console.

        Args:
            log_print: A boolean value indicating if console logging is enabled.
                Accepts bool or string ("true"/"false"/"1"/"0"). Defaults to True.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["log_print"] = coerce_bool(log_print)
        return self

    def set_json_log_print(self, json_log_print: bool | str) -> Self:
        """Set whether to use JSON format for console log output.

        When enabled, logs are printed as single-line JSON objects suitable
        for cloud logging platforms and log aggregation services. This format
        enables proper log level filtering and metadata querying.

        ERROR and CRITICAL level logs are sent to stderr (often shown in red),
        while DEBUG, INFO, and WARNING logs go to stdout.

        Args:
            json_log_print: If True, use JSON format for console output.
                Defaults to True when not explicitly set.

        Returns:
            The LogConfig instance for method chaining.

        Example:
            >>> config = LogConfig()
            >>> config.set_log_print(True).set_json_log_print(True)
            # Output: {"level":"info","message":"User logged in","controller":"auth"}
        """
        self._config["json_log_print"] = coerce_bool(json_log_print)
        return self

    def set_log_store(self, log_store: bool | str) -> Self:
        """Set whether to store logs (e.g., in a file or via API).

        Args:
            log_store: A boolean value indicating if log storage is enabled.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["log_store"] = coerce_bool(log_store)
        return self

    def set_log_level(self, log_level: str) -> Self:
        """Set the minimum logging level (e.g., 'INFO', 'DEBUG').

        Args:
            log_level: The logging level as a string (converted to uppercase).

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["log_level"] = (log_level or "INFO").upper()
        return self

    def set_log_file_name(self, log_file_name: str) -> Self:
        """Set the name of the log file.

        Args:
            log_file_name: The filename for storing log output.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["log_file_name"] = log_file_name
        return self

    def set_log_file_backup_count(self, log_file_backup_count: int) -> Self:
        """Set the number of backup log files to keep.

        Args:
            log_file_backup_count: The number of rotated log files to retain.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["log_file_backup_count"] = int(log_file_backup_count)
        return self

    def set_log_file_max_size(self, log_file_max_size: int) -> Self:
        """Set the maximum size of a log file in bytes.

        Args:
            log_file_max_size: The maximum log file size in bytes before rotation.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["log_file_max_size"] = int(log_file_max_size)
        return self

    def set_only_footprint_mode(self, only_footprint_mode: bool | str) -> Self:
        """Set whether to only log messages marked as 'footprints'.

        This is typically used with the API handler to filter logs, ensuring
        only logs explicitly marked as footprints are sent to the remote API.

        Args:
            only_footprint_mode: If True, only footprint logs are sent to API.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["only_footprint_mode"] = coerce_bool(only_footprint_mode)
        return self

    def set_celery_mode(self, celery_mode: bool | str) -> Self:
        """Configure logging for a Celery worker context.

        This adapts the logging setup for Celery's process model, enabling
        specialized handling for Celery workers and tasks.

        Args:
            celery_mode: If True, configure logging for Celery workers.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["celery_mode"] = coerce_bool(celery_mode)
        return self

    def set_uvicorn_mode(self, uvicorn_mode: bool | str) -> Self:
        """Configure logging for Uvicorn/FastAPI applications.

        When enabled, applies the same logging handlers (including JSON
        format) to uvicorn's loggers, ensuring consistent log output across
        your application and the ASGI server.

        Configures these loggers:
            - uvicorn
            - uvicorn.error
            - uvicorn.access (only if access_log_mode is True)

        Args:
            uvicorn_mode: If True, configure logging for Uvicorn.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["uvicorn_mode"] = coerce_bool(uvicorn_mode)
        return self

    def set_opensearch_mode(self, opensearch_mode: bool | str) -> Self:
        """Configure logging for OpenSearch client library.

        When enabled, applies the same logging handlers (including JSON
        format) to opensearch-py's logger, ensuring consistent log output for
        OpenSearch operations.

        Configures these loggers:
            - opensearch
            - opensearchpy

        Args:
            opensearch_mode: If True, configure logging for OpenSearch client.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["opensearch_mode"] = coerce_bool(opensearch_mode)
        return self

    def set_gunicorn_mode(self, gunicorn_mode: bool | str) -> Self:
        """Configure logging for Gunicorn WSGI server.

        When enabled, applies the same logging handlers (including JSON
        format) to gunicorn's loggers, ensuring consistent log output across
        your application and the WSGI server.

        Configures these loggers:
            - gunicorn
            - gunicorn.error
            - gunicorn.access (only if access_log_mode is True)

        Args:
            gunicorn_mode: If True, configure logging for Gunicorn.

        Returns:
            The LogConfig instance for method chaining.
        """
        self._config["gunicorn_mode"] = coerce_bool(gunicorn_mode)
        return self

    def set_access_log_mode(self, access_log_mode: bool | str) -> Self:
        """Enable or disable HTTP access logging.

        When disabled (default), access logs from uvicorn.access and
        gunicorn.access are suppressed. This reduces log noise from
        health checks and routine requests.

        When enabled, access logs are output using the configured format
        (JSON if json_log_print is True).

        Args:
            access_log_mode: If True, enable access logging. Defaults to False.

        Returns:
            The LogConfig instance for method chaining.

        Example:
            >>> config = LogConfig()
            >>> config.set_log_print(True) \
            ...       .set_access_log_mode(True)  # Enable access logs
        """
        self._config["access_log_mode"] = coerce_bool(access_log_mode)
        return self

    @classmethod
    def from_env(cls, api_prefix: str = "logging_ms_") -> "LogConfig":
        """Build a LogConfig from environment variables.

        Reads API credentials using ``api_prefix`` (default ``"logging_ms_"``)
        and log-behaviour flags from standard names regardless of prefix.

        Variables read:
            ``{api_prefix}url``, ``{api_prefix}key``,
            ``log_level``, ``log_print``, ``log_store``,
            ``json_log_print``, ``opensearch_mode``,
            ``celery_mode``, ``uvicorn_mode``.

        All variables must be registered via ``Env.register()`` before calling
        this method.

        Args:
            api_prefix: Prefix for the remote logging API credentials.
                Defaults to ``"logging_ms_"``.

        Returns:
            A configured ``LogConfig`` instance ready to pass to
            ``log_initializer``.

        Example::

            Env.register([
                "logging_ms_url", "logging_ms_key",
                "log_level", "log_print", "log_store",
                "json_log_print", "opensearch_mode",
            ])
            Env.load_file(".env")
            log_config = LogConfig.from_env()
            log_initializer(config=log_config)
        """
        from ..core.env import Env

        config = cls()
        if api_url := Env.get(f"{api_prefix}url"):
            config = config.set_api_url(api_url)
        if api_key := Env.get(f"{api_prefix}key"):
            config = config.set_api_key(api_key)
        if log_level := Env.get("log_level"):
            config = config.set_log_level(log_level)
        if (log_print := Env.get("log_print")) is not None:
            config = config.set_log_print(log_print)
        if (log_store := Env.get("log_store")) is not None:
            config = config.set_log_store(log_store)
        if (json_log_print := Env.get("json_log_print")) is not None:
            config = config.set_json_log_print(json_log_print)
        if (opensearch_mode := Env.get("opensearch_mode")) is not None:
            config = config.set_opensearch_mode(opensearch_mode)
        if (celery_mode := Env.get("celery_mode")) is not None:
            config = config.set_celery_mode(celery_mode)
        if (uvicorn_mode := Env.get("uvicorn_mode")) is not None:
            config = config.set_uvicorn_mode(uvicorn_mode)
        return config
