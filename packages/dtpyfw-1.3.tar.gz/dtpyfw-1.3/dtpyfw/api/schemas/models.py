from datetime import date, datetime
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

from ...core.enums import OrderingType

__all__ = (
    "Sorting",
    "SearchPayload",
    "NumberRange",
    "TimeRange",
    "DateRange",
    "BaseModelEnumValue",
    "ListPayloadResponse",
)


class Sorting(BaseModel):
    """Sorting configuration for query results.

    Description:
        Specifies how to sort query results by defining the field to sort on
        and the ordering direction (ascending or descending).
    """

    sort_by: str = Field(..., description="The field name to sort results by.")
    order_by: OrderingType = Field(
        default=OrderingType.asc,
        description="Sorting direction: ascending or descending.",
    )


class SearchPayload(BaseModel):
    """Common request payload for paginated and searchable list endpoints.

    Description:
        Standard request body for list/search endpoints, providing pagination,
        sorting, and free-text search capabilities.
    """

    model_config = ConfigDict(use_enum_values=True)

    page: Annotated[int, Field(ge=1)] | None = Field(default=1, description="Page number to retrieve (must be >= 1).")
    items_per_page: Annotated[int, Field(ge=1, le=30)] | None = Field(
        default=20, description="Number of items per page (max 30)."
    )
    sorting: list[Sorting] | None = Field(
        default=None, description="Optional list of sorting rules applied to the query."
    )
    search: str | None = Field(default="", description="Optional search term to filter results.")


class NumberRange(BaseModel):
    """Range filter for numeric values.

    Description:
        Defines minimum and maximum bounds for filtering numeric data,
        such as prices, quantities, or scores.
    """

    min: int | None = Field(default=None, description="Minimum value allowed in the range.")
    max: int | None = Field(default=None, description="Maximum value allowed in the range.")


class TimeRange(BaseModel):
    """Range filter for time values.

    Description:
        Defines minimum and maximum datetime bounds for filtering temporal data,
        such as creation dates or event timestamps.
    """

    min: datetime | None = Field(default=None, description="Minimum datetime allowed in the range.")
    max: datetime | None = Field(default=None, description="Maximum datetime allowed in the range.")


class DateRange(BaseModel):
    """Range filter for date values.

    Description:
        Defines minimum and maximum date bounds for filtering date-only data,
        without time components.
    """

    min: date | None = Field(default=None, description="Minimum date allowed in the range.")
    max: date | None = Field(default=None, description="Maximum date allowed in the range.")


class BaseModelEnumValue(BaseModel):
    """Base model configured to serialize enums as their values.

    Description:
        Pydantic base class that configures automatic serialization of Enum
        fields to their string/integer values instead of the enum names.
    """

    model_config = ConfigDict(use_enum_values=True)


class ListPayloadResponse(BaseModel):
    """Standard response structure for paginated list endpoints.

    Description:
        Provides pagination metadata alongside list results, including total
        count, page information, and navigation flags.
    """

    total_row: int | None = Field(default=None, description="Total number of rows matching the query.")
    last_page: int | None = Field(default=None, description="The index of the last available page.")
    has_next: bool | None = Field(default=None, description="Indicates if there is a next page available.")
