"""Validation exception handler middleware for FastAPI."""

import re
from typing import Any, cast

from fastapi import Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response

from ...log import footprint
from ..routes.response import return_response
from ._utils import _redact_headers

__all__ = ("validation_exception_handler",)

_SENSITIVE_FIELD_RE: re.Pattern[str] = re.compile(r"password|token|secret|key", re.IGNORECASE)


def _redact_error_input(input_value: Any) -> Any:
    """Recursively redact sensitive field values inside a validation error input.

    Description:
        Walks a dict (or passes through other types) and replaces values whose
        keys match the sensitive-field pattern with ``"[REDACTED]"``.  Operates
        on a copy; the original is not mutated.

    Args:
        input_value: The raw ``input`` value from a Pydantic validation error.

    Returns:
        Any: The sanitised copy (dict) or the original value unchanged.
    """
    if not isinstance(input_value, dict):
        return input_value
    return {
        k: "[REDACTED]" if _SENSITIVE_FIELD_RE.search(k) else _redact_error_input(v) for k, v in input_value.items()
    }


def _redact_errors_for_log(errors: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return a copy of the errors list with sensitive input fields redacted.

    Description:
        Produces a new list of error dicts where each ``"input"`` value has
        been passed through ``_redact_error_input`` so that passwords, tokens,
        secrets, and keys are not written to structured logs.

    Args:
        errors: List of Pydantic error dicts as returned by ``exc.errors()``.

    Returns:
        list[dict[str, Any]]: Sanitised copy of the errors list.
    """
    result: list[dict[str, Any]] = []
    for error in errors:
        sanitised = dict(error)
        if "input" in sanitised:
            sanitised["input"] = _redact_error_input(sanitised["input"])
        result.append(sanitised)
    return result


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> Response:
    """Handle validation errors and format them into readable responses.

    Description:
        FastAPI exception handler that processes request validation errors,
        extracts the first error with location and message details, logs it,
        and returns a standardized 422 error response.  Raw input data is
        never echoed back to the caller; sensitive fields are redacted in logs.

    Args:
        request: The incoming FastAPI request that failed validation.
        exc: The validation error exception containing error details.

    Returns:
        Response: Formatted JSON error response with status code 422.
    """
    error_message = ""
    for error in exc.errors():
        location = " -> ".join(map(str, error["loc"]))
        error_message = f"Error [location: '{location}'; message: '{error['msg']}']."
        break

    footprint.leave(
        log_type="debug",
        controller=f"{__name__}.validation_exception_handler",
        subject="validation_exception",
        message=error_message,
        payload={
            "url": request.url.path,
            "method": request.method,
            "headers": _redact_headers(dict(request.headers)),
            "errors": _redact_errors_for_log(cast(list[dict[str, Any]], exc.errors())),
        },
    )

    return return_response(
        data=error_message,
        status_code=422,
        response_class=JSONResponse,
    )
