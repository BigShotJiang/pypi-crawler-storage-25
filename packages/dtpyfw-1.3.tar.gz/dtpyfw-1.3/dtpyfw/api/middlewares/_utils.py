"""Shared utility helpers for API middleware modules."""

__all__ = ("_redact_headers",)

_DEFAULT_SENSITIVE_HEADERS: frozenset[str] = frozenset({"authorization", "cookie", "x-api-key", "user-permissions"})

_DEFAULT_SENSITIVE_QUERY_PARAMS: frozenset[str] = frozenset({"api_key", "key", "token", "secret", "password"})

_REDACTED: str = "[REDACTED]"


def _redact_headers(
    headers: dict[str, str],
    sensitive: set[str] | frozenset[str] = _DEFAULT_SENSITIVE_HEADERS,
) -> dict[str, str]:
    """Return a copy of *headers* with sensitive values replaced by ``[REDACTED]``.

    Description:
        Iterates over the supplied header dict, comparing each key (lowercased)
        against the *sensitive* set, and replaces matching values with a
        placeholder string.  The original dict is never mutated.

    Args:
        headers: Raw header dict to sanitise (keys may be mixed-case).
        sensitive: Set of lowercase header names whose values should be redacted.
            Defaults to ``{"authorization", "cookie", "x-api-key", "user-permissions"}``.

    Returns:
        dict[str, str]: New dict with sensitive values replaced by ``"[REDACTED]"``.
    """
    return {key: _REDACTED if key.lower() in sensitive else value for key, value in headers.items()}


def _redact_query_params(
    params: dict[str, str],
    sensitive: set[str] | frozenset[str] = _DEFAULT_SENSITIVE_QUERY_PARAMS,
) -> dict[str, str]:
    """Return a copy of *params* with sensitive query-parameter values replaced by ``[REDACTED]``.

    Description:
        Iterates over the supplied query-parameter dict, comparing each key
        (lowercased) against the *sensitive* set, and replaces matching values
        with a placeholder string.  The original dict is never mutated.

    Args:
        params: Raw query-parameter dict to sanitise (keys may be mixed-case).
        sensitive: Set of lowercase parameter names whose values should be redacted.
            Defaults to ``{"api_key", "key", "token", "secret", "password"}``.

    Returns:
        dict[str, str]: New dict with sensitive values replaced by ``"[REDACTED]"``.
    """
    return {key: _REDACTED if key.lower() in sensitive else value for key, value in params.items()}
