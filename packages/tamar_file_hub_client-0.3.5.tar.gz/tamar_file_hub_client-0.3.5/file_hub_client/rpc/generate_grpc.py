"""
Generate gRPC Python code for the File Hub client SDK.

Usage:
    python -m file_hub_client.rpc.generate_grpc
    python file_hub_client/rpc/generate_grpc.py
    file-hub-gen-proto
"""
import os
import re
import subprocess
import sys
from pathlib import Path

import google.protobuf


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROTO_SRC = PROJECT_ROOT / "file_hub_client" / "rpc" / "protos"
OUT_DIR = PROJECT_ROOT / "file_hub_client" / "rpc" / "gen"
PROTOBUF_INCLUDE = Path(google.protobuf.__file__).parent

_VERSION_CHECK_RE = re.compile(
    r"\nGRPC_GENERATED_VERSION = '[^']*'\n"
    r"GRPC_VERSION = grpc\.__version__\n"
    r"_version_not_supported = False\n\n"
    r"try:\n"
    r"    from grpc\._utilities import first_version_is_lower\n"
    r"    _version_not_supported = first_version_is_lower\(GRPC_VERSION, GRPC_GENERATED_VERSION\)\n"
    r"except ImportError:\n"
    r"    _version_not_supported = True\n\n"
    r"if _version_not_supported:\n"
    r"    raise RuntimeError\([^)]*\)\n",
    re.DOTALL,
)


def _ensure_init_files() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for dirpath, _, _ in os.walk(OUT_DIR):
        path = Path(dirpath)
        if path.name.startswith("_"):
            continue
        init_file = path / "__init__.py"
        if not init_file.exists():
            init_file.write_text("# Auto-generated init file for gRPC package\n", encoding="utf-8")


def _fix_generated_imports() -> None:
    pb2_modules = {gen_file.stem for gen_file in OUT_DIR.rglob("*_pb2.py")}

    for gen_file in OUT_DIR.rglob("*.py"):
        text = gen_file.read_text(encoding="utf-8")
        original = text

        for mod in pb2_modules:
            pattern = re.compile(rf"^(import {re.escape(mod)} as )", re.MULTILINE)
            text = pattern.sub(rf"from . import {mod} as ", text)

        text = _VERSION_CHECK_RE.sub("\n", text)

        if text != original:
            gen_file.write_text(text, encoding="utf-8")
            print(f"  fixed: {gen_file.relative_to(PROJECT_ROOT)}")


def main() -> int:
    _ensure_init_files()

    proto_files = sorted(PROTO_SRC.rglob("*.proto"))
    if not proto_files:
        raise FileNotFoundError(f"No .proto files found in {PROTO_SRC}")

    cmd = [
        sys.executable,
        "-m",
        "grpc_tools.protoc",
        f"-I{PROTO_SRC}",
        f"-I{PROTOBUF_INCLUDE}",
        f"--python_out={OUT_DIR}",
        f"--grpc_python_out={OUT_DIR}",
        *[str(path) for path in proto_files],
    ]

    print("Generating gRPC code...")
    print(f"  proto src: {PROTO_SRC}")
    print(f"  out dir:   {OUT_DIR}")
    print(f"  files:     {[path.name for path in proto_files]}")

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print("gRPC generation failed:", file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        return result.returncode

    _fix_generated_imports()
    _ensure_init_files()
    print(f"Generated {len(proto_files)} proto files.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
