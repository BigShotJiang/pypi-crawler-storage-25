from __future__ import annotations

from typing import Any, Dict, List, Optional

import grpc

from .base_document_service import BaseDocumentService
from ...errors import DocumentNotFoundError, ValidationError
from ...rpc.async_client import AsyncGrpcClient
from ...schemas.document import (
    AddDocumentAgentOperationsResponse,
    AppendDocumentContentResponse,
    CloneDocumentResponse,
    DocumentListResponse,
    DocumentPermissionResponse,
    DocumentWithContentResponse,
)
from ...utils.retry import retry_with_backoff


class AsyncDocumentService(BaseDocumentService):
    """Asynchronous Document service."""

    def __init__(self, client: AsyncGrpcClient):
        self.client = client

    async def _stub(self) -> Any:
        from ...rpc.gen import document_service_pb2_grpc

        return await self.client.get_stub(document_service_pb2_grpc.DocumentServiceStub)

    def _metadata(self, request_id: Optional[str], metadata: Dict[str, str]) -> Any:
        return self.client.build_metadata(request_id=request_id, **metadata)

    @staticmethod
    def _raise_not_found(identifier: str) -> None:
        raise DocumentNotFoundError(identifier)

    @retry_with_backoff(max_retries=3)
    async def create_document(
        self,
        title: str,
        content: Optional[Dict[str, Any]] = None,
        *,
        folder_id: Optional[str] = None,
        default_folder_name: Optional[str] = None,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> DocumentWithContentResponse:
        from ...rpc.gen import document_service_pb2

        if not title:
            raise ValidationError("title is required", field="title")

        request = document_service_pb2.CreateDocumentRequest(title=title)
        request.content.CopyFrom(self._dict_to_struct(content))
        if folder_id is not None:
            request.folder_id = folder_id
        if default_folder_name is not None:
            request.default_folder_name = default_folder_name

        stub = await self._stub()
        response = await stub.CreateDocument(request, metadata=self._metadata(request_id, metadata))
        return self._convert_document_with_content(response)

    @retry_with_backoff(max_retries=3)
    async def get_document(
        self,
        *,
        document_id: Optional[str] = None,
        content_id: Optional[str] = None,
        record_visit: bool = False,
        ip_address: Optional[str] = None,
        device: Optional[str] = None,
        referrer: Optional[str] = None,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> DocumentWithContentResponse:
        from ...rpc.gen import document_service_pb2

        if not document_id and not content_id:
            raise ValidationError("document_id or content_id is required")

        request = document_service_pb2.GetDocumentRequest(record_visit=record_visit)
        if document_id is not None:
            request.document_id = document_id
        if content_id is not None:
            request.content_id = content_id
        if ip_address is not None:
            request.ip_address = ip_address
        if device is not None:
            request.device = device
        if referrer is not None:
            request.referrer = referrer

        stub = await self._stub()
        try:
            response = await stub.GetDocument(request, metadata=self._metadata(request_id, metadata))
        except grpc.RpcError as exc:
            if exc.code() == grpc.StatusCode.NOT_FOUND:
                self._raise_not_found(document_id or content_id or "")
            raise
        return self._convert_document_with_content(response)

    @retry_with_backoff(max_retries=3)
    async def update_document(
        self,
        document_id: str,
        content: Dict[str, Any],
        *,
        title: Optional[str] = None,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> DocumentWithContentResponse:
        from ...rpc.gen import document_service_pb2

        request = document_service_pb2.UpdateDocumentRequest(document_id=document_id)
        request.content.CopyFrom(self._dict_to_struct(content))
        if title is not None:
            request.title = title

        stub = await self._stub()
        try:
            response = await stub.UpdateDocument(request, metadata=self._metadata(request_id, metadata))
        except grpc.RpcError as exc:
            if exc.code() == grpc.StatusCode.NOT_FOUND:
                self._raise_not_found(document_id)
            raise
        return self._convert_document_with_content(response)

    @retry_with_backoff(max_retries=3)
    async def delete_document(self, document_id: str, *, request_id: Optional[str] = None, **metadata: str) -> None:
        from ...rpc.gen import document_service_pb2

        stub = await self._stub()
        try:
            await stub.DeleteDocument(
                document_service_pb2.DeleteDocumentRequest(document_id=document_id),
                metadata=self._metadata(request_id, metadata),
            )
        except grpc.RpcError as exc:
            if exc.code() == grpc.StatusCode.NOT_FOUND:
                self._raise_not_found(document_id)
            raise

    @retry_with_backoff(max_retries=3)
    async def search_documents(
        self,
        *,
        search_text: Optional[str] = None,
        limit: Optional[int] = 100,
        offset: Optional[int] = 0,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> DocumentListResponse:
        from ...rpc.gen import document_service_pb2

        request = document_service_pb2.SearchDocumentsRequest()
        if search_text is not None:
            request.search_text = search_text
        if limit is not None:
            request.limit = limit
        if offset is not None:
            request.offset = offset

        stub = await self._stub()
        response = await stub.SearchDocuments(request, metadata=self._metadata(request_id, metadata))
        return self._convert_document_list(response)

    @retry_with_backoff(max_retries=3)
    async def list_owner_documents(
        self,
        *,
        user_id: Optional[str] = None,
        limit: Optional[int] = 100,
        offset: Optional[int] = 0,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> DocumentListResponse:
        from ...rpc.gen import document_service_pb2

        request = document_service_pb2.ListDocumentsRequest()
        if user_id is not None:
            request.user_id = user_id
        if limit is not None:
            request.limit = limit
        if offset is not None:
            request.offset = offset

        stub = await self._stub()
        response = await stub.ListOwnerDocuments(request, metadata=self._metadata(request_id, metadata))
        return self._convert_document_list(response)

    @retry_with_backoff(max_retries=3)
    async def list_recently_visited_documents(
        self,
        *,
        user_id: Optional[str] = None,
        limit: Optional[int] = 100,
        offset: Optional[int] = 0,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> DocumentListResponse:
        from ...rpc.gen import document_service_pb2

        request = document_service_pb2.ListDocumentsRequest()
        if user_id is not None:
            request.user_id = user_id
        if limit is not None:
            request.limit = limit
        if offset is not None:
            request.offset = offset

        stub = await self._stub()
        response = await stub.ListRecentlyVisitedDocuments(request, metadata=self._metadata(request_id, metadata))
        return self._convert_document_list(response)

    @retry_with_backoff(max_retries=3)
    async def share_document(
        self,
        document_id: str,
        target_user_id: str,
        *,
        permission_type: str = "viewer",
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> DocumentPermissionResponse:
        from ...rpc.gen import document_service_pb2

        request = document_service_pb2.ShareDocumentRequest(
            document_id=document_id,
            target_user_id=target_user_id,
            permission_type=permission_type,
        )
        stub = await self._stub()
        response = await stub.ShareDocument(request, metadata=self._metadata(request_id, metadata))
        return self._convert_permission(response)

    @retry_with_backoff(max_retries=3)
    async def clone_document(
        self,
        source_document_id: str,
        target_org_id: str,
        target_user_id: str,
        *,
        target_folder_id: Optional[str] = None,
        new_document_title: Optional[str] = None,
        default_folder_name: Optional[str] = None,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> CloneDocumentResponse:
        from ...rpc.gen import document_service_pb2

        request = document_service_pb2.CloneDocumentRequest(
            source_document_id=source_document_id,
            target_org_id=target_org_id,
            target_user_id=target_user_id,
        )
        if target_folder_id is not None:
            request.target_folder_id = target_folder_id
        if new_document_title is not None:
            request.new_document_title = new_document_title
        if default_folder_name is not None:
            request.default_folder_name = default_folder_name

        stub = await self._stub()
        response = await stub.CloneDocument(request, metadata=self._metadata(request_id, metadata))
        return self._convert_clone(response)

    @retry_with_backoff(max_retries=3)
    async def append_document_content(
        self,
        document_id: str,
        content: Dict[str, Any],
        *,
        target_org_id: Optional[str] = None,
        target_user_id: Optional[str] = None,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> AppendDocumentContentResponse:
        from ...rpc.gen import document_service_pb2

        request = document_service_pb2.AppendDocumentContentRequest(document_id=document_id)
        request.content.CopyFrom(self._dict_to_struct(content))
        if target_org_id is not None:
            request.target_org_id = target_org_id
        if target_user_id is not None:
            request.target_user_id = target_user_id

        stub = await self._stub()
        response = await stub.AppendDocumentContent(request, metadata=self._metadata(request_id, metadata))
        return self._convert_append(response)

    @retry_with_backoff(max_retries=3)
    async def update_document_content(
        self,
        document_id: str,
        content_id: str,
        content: Dict[str, Any],
        *,
        target_org_id: Optional[str] = None,
        target_user_id: Optional[str] = None,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> DocumentWithContentResponse:
        from ...rpc.gen import document_service_pb2

        request = document_service_pb2.UpdateDocumentContentRequest(
            document_id=document_id,
            content_id=content_id,
        )
        request.content.CopyFrom(self._dict_to_struct(content))
        if target_org_id is not None:
            request.target_org_id = target_org_id
        if target_user_id is not None:
            request.target_user_id = target_user_id

        stub = await self._stub()
        response = await stub.UpdateDocumentContent(request, metadata=self._metadata(request_id, metadata))
        return self._convert_document_with_content(response)

    @retry_with_backoff(max_retries=3)
    async def add_document_agent_operations(
        self,
        operations: List[Dict[str, Any]],
        *,
        request_id: Optional[str] = None,
        **metadata: str,
    ) -> AddDocumentAgentOperationsResponse:
        from ...rpc.gen import document_service_pb2

        request = document_service_pb2.AddDocumentAgentOperationsRequest()
        for operation in operations:
            item = request.operations.add(
                target_user_id=operation.get("target_user_id", ""),
                type=operation.get("type", ""),
            )
            if operation.get("document_id") is not None:
                item.document_id = operation["document_id"]
            item.data.CopyFrom(self._dict_to_struct(operation.get("data") or {}))

        stub = await self._stub()
        response = await stub.AddDocumentAgentOperations(request, metadata=self._metadata(request_id, metadata))
        return self._convert_agent_operations(response)
