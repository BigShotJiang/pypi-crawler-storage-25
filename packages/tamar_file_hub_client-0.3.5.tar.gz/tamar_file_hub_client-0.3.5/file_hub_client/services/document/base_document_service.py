from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from google.protobuf.json_format import MessageToDict, ParseDict
from google.protobuf.struct_pb2 import Struct

from ...errors import ValidationError
from ...schemas.document import (
    AddDocumentAgentOperationsResponse,
    AppendDocumentContentResponse,
    CloneDocumentResponse,
    DocumentAgentOperation,
    DocumentInfo,
    DocumentListResponse,
    DocumentPermissionResponse,
    DocumentWithContentResponse,
)


class BaseDocumentService:
    """Shared converters and validators for Document SDK services."""

    @staticmethod
    def _dict_to_struct(value: Optional[Dict[str, Any]]) -> Struct:
        if value is None:
            value = {}
        if not isinstance(value, dict):
            raise ValidationError("content must be a dict", field="content")

        message = Struct()
        ParseDict(value, message)
        return message

    @staticmethod
    def _struct_to_dict(value: Struct) -> Dict[str, Any]:
        if value is None:
            return {}
        return MessageToDict(value, preserving_proto_field_name=True)

    @staticmethod
    def _timestamp_to_datetime(value: Any) -> Optional[datetime]:
        if value is None:
            return None
        if getattr(value, "seconds", 0) == 0 and getattr(value, "nanos", 0) == 0:
            return None
        return value.ToDatetime()

    def _convert_document(self, document: Any) -> DocumentInfo:
        return DocumentInfo(
            id=document.id,
            org_id=document.org_id,
            user_id=document.user_id,
            title=document.title,
            folder_id=document.folder_id or None,
            created_by=document.created_by,
            created_by_role=document.created_by_role,
            version=document.version,
            created_at=self._timestamp_to_datetime(document.created_at),
            updated_at=self._timestamp_to_datetime(document.updated_at),
            hit_document_content_ids=list(document.hit_document_content_ids),
            last_visited_at=self._timestamp_to_datetime(document.last_visited_at),
        )

    def _convert_document_with_content(self, response: Any) -> DocumentWithContentResponse:
        return DocumentWithContentResponse(
            document=self._convert_document(response.document),
            content=self._struct_to_dict(response.content),
        )

    def _convert_document_list(self, response: Any) -> DocumentListResponse:
        return DocumentListResponse(items=[self._convert_document(item) for item in response.documents])

    def _convert_permission(self, response: Any) -> DocumentPermissionResponse:
        return DocumentPermissionResponse(
            document_id=response.document_id,
            subject_type=response.subject_type,
            subject_id=response.subject_id,
            permission_type=response.permission_type,
        )

    def _convert_clone(self, response: Any) -> CloneDocumentResponse:
        return CloneDocumentResponse(
            document=self._convert_document(response.document),
            content=self._struct_to_dict(response.content),
            content_count=response.content_count,
        )

    def _convert_append(self, response: Any) -> AppendDocumentContentResponse:
        return AppendDocumentContentResponse(
            document=self._convert_document(response.document),
            content=self._struct_to_dict(response.content),
            content_id=response.content_id,
        )

    def _convert_agent_operation(self, operation: Any) -> DocumentAgentOperation:
        return DocumentAgentOperation(
            id=operation.id,
            document_id=operation.document_id,
            target_user_id=operation.target_user_id,
            type=operation.type,
            data=self._struct_to_dict(operation.data),
            status=operation.status,
        )

    def _convert_agent_operations(self, response: Any) -> AddDocumentAgentOperationsResponse:
        return AddDocumentAgentOperationsResponse(
            items=[self._convert_agent_operation(item) for item in response.operations]
        )
