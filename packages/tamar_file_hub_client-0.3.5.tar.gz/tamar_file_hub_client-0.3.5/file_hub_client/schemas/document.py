from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


JsonObject = Dict[str, Any]


class DocumentInfo(BaseModel):
    """Document metadata returned by File Hub."""

    id: str = Field(..., description="Document ID")
    org_id: str = Field(..., description="Organization ID")
    user_id: str = Field(..., description="Owner user ID")
    title: str = Field(..., description="Document title")
    folder_id: Optional[str] = Field(default=None, description="Folder ID")
    created_by: str = Field(..., description="Creator ID")
    created_by_role: str = Field(..., description="Creator role")
    version: int = Field(default=1, description="Document version")
    created_at: Optional[datetime] = Field(default=None, description="Created time")
    updated_at: Optional[datetime] = Field(default=None, description="Updated time")
    hit_document_content_ids: List[str] = Field(default_factory=list, description="Matched content IDs")
    last_visited_at: Optional[datetime] = Field(default=None, description="Last visited time")


class DocumentWithContentResponse(BaseModel):
    """Document metadata plus expanded content."""

    document: DocumentInfo
    content: JsonObject = Field(default_factory=dict)


class DocumentListResponse(BaseModel):
    """Document list response."""

    items: List[DocumentInfo] = Field(default_factory=list)


class DocumentPermissionResponse(BaseModel):
    """Document permission response."""

    document_id: str
    subject_type: str
    subject_id: str
    permission_type: str


class CloneDocumentResponse(BaseModel):
    """Cloned document response."""

    document: DocumentInfo
    content: JsonObject = Field(default_factory=dict)
    content_count: int = 0


class AppendDocumentContentResponse(BaseModel):
    """Append document content response."""

    document: DocumentInfo
    content: JsonObject = Field(default_factory=dict)
    content_id: str


class DocumentAgentOperation(BaseModel):
    """Agent operation created for a document."""

    id: str
    document_id: str
    target_user_id: str
    type: str
    data: JsonObject = Field(default_factory=dict)
    status: int = 0


class AddDocumentAgentOperationsResponse(BaseModel):
    """Batch-created document agent operations."""

    items: List[DocumentAgentOperation] = Field(default_factory=list)
