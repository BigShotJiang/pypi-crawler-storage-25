from __future__ import annotations
try:
    from . import copiar
except ImportError:
    import copiar

def own(name):
    return copiar.Copiar.copy(copiar.Copiar, name, Exception)

ModuleError = own('ModuleError')
TypeException = own('TypeException')
PyPIException = own('PyPIException')

