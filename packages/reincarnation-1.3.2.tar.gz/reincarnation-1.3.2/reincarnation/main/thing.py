import textwrap
import inspect

def getcode(func):
    source = inspect.getsource(func)
    lines = source.splitlines()

    header_end_index = 0
    for i, line in enumerate(lines):
        if line.strip().endswith(':'):
            header_end_index = i + 1
            break

    body_lines = lines[header_end_index:]

    body_raw = "\n".join(body_lines)

    x = textwrap.dedent(body_raw)
    x = x.replace('return', 'r =')

    return x

