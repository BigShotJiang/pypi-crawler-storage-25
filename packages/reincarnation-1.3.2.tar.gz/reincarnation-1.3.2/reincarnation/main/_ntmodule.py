import sys
import importlib
import inspect
import os
import types
from typing import Any
from datetime import datetime
from hunter import Q, trace, CodePrinter, VarsPrinter, CallPrinter

__all__ = list([])

def __getattr__(name):
    """Dynamic import hook: reincarnation.module.any_module"""
    if name in sys.modules:
        return sys.modules[name]
    try:
        return importlib.import_module(name)
    except ImportError:
        raise AttributeError(f"Module '{name}' is not reachable via Reincarnation.")

def where(module_name):
    """Find the physical path of a module"""
    try:
        mod = importlib.import_module(module_name) if isinstance(module_name, str) else module_name
        return os.path.abspath(mod.__file__)
    except Exception:
        return "Unknown or Built-in"

__all__.append("where")

def reload(module_obj):
    """Force reincarnation: Reload an existing module"""
    return importlib.reload(module_obj)

__all__.append("reload")

def source(obj):
    """Extract the DNA: Get source code of any function or class"""
    try:
        return inspect.getsource(obj)
    except Exception as e:
        return f"Could not extract source: {e}"

__all__.append("source")

def hijack(target_module_name, func_name, new_func):
    """Function Transplant: Replace a function in another module"""
    mod = importlib.import_module(target_module_name) if isinstance(target_module_name, str) else target_module_name
    original = getattr(mod, func_name)
    setattr(mod, func_name, new_func)
    return original # Return original to allow restoration later

__all__.append('hijack')

def steal(from_module, to_module, attr_name):
    """Attribute Theft: Move a function/class from one module to another"""
    src = importlib.import_module(from_module) if isinstance(from_module, str) else from_module
    dst = importlib.import_module(to_module) if isinstance(to_module, str) else to_module
    setattr(dst, attr_name, getattr(src, attr_name))

__all__.append('steal')

def peek(module_name):
    """X-Ray Vision: List all members of a module without importing manually"""
    mod = importlib.import_module(module_name) if isinstance(module_name, str) else module_name
    return [item for item in dir(mod) if not item.startswith('__')]

__all__.append('peek')

def teleport(path):
    """Add a new dimension: Inject a path into sys.path for instant access"""
    if path not in sys.path:
        sys.path.insert(0, path)

__all__.append('teleport')

def exists(module_name):
    """Ghost Scanner: Check if a module can be found without loading it"""
    return importlib.util.find_spec(module_name) is not None

__all__.append('exists')

def is_external(module_name):
    """Detects if the module was installed via pip or is local."""
    mod = importlib.import_module(module_name) if isinstance(module_name, str) else module_name
    if not hasattr(mod, '__file__'):
        return False

    path = mod.__file__
    return "site-packages" in path or "dist-packages" in path

__all__.append('is_external')

safe_local_import = types.ModuleType

__all__.append('safe_local_import')

def ModuleType(name='sys'):
    return importlib.import_module(name) if isinstance(name, str) else name

__all__.append('ModuleType')

def search(module, string):
    module_ = ModuleType(module)
    output = {}
    num = 0

    if hasattr(module_, '__file__'):
        for i in open(module_.__file__, 'r').readlines():
            num +=1
            if string in i:
                output[num] = i
    return output

__all__.append('search')

def _module_setattr(module='os', attr: Any='attr0', attr_value: Any='str'):
    module = ModuleType(module)
    setattr(module, attr, attr_value)

class InfoBugger:
    def __init__(self):
        self.InfoBuggerConsole = []
    def log(self, message):
        n = datetime.now()
        msg = f'[{n.day if n.day > 9 else f'0{n.day}'}.{n.month if n.month > 9 else f'0{n.month}'} {n.year} {n.hour}:{n.minute}] {message}\n'
        self.InfoBuggerConsole.append(msg)
        sys.stdout.write(msg)
        sys.stdout.flush()
        return self.InfoBuggerConsole
    def infolog(self, message):
        n = datetime.now()
        msg = f'{os.path.basename(sys.executable)}: [{n.day if n.day > 9 else f'0{n.day}'}.{n.month if n.month > 9 else f'0{n.month}'} {n.year} {n.hour}:{n.minute}] {message}'
        self.InfoBuggerConsole.append(msg)
        sys.stdout.write(msg)
        sys.stdout.flush()
        return self.InfoBuggerConsole

class BasicCatcher:
    def __init__(self):
        pass
    def getfile(self, module):
        if isinstance(module, str):
            return __import__(module).__file__
        else:
            return module.__file__

def _call_catcher():
    stack = inspect.stack()
    for frame in stack:
        if frame.filename != __file__:
            return os.path.abspath(frame.filename)
    return os.path.abspath(stack[1].filename)

get_caller_path = _call_catcher


def is_external_caller() -> bool:
    caller_file = get_caller_path()
    package_dir = os.path.abspath(os.path.dirname(__file__))
    return not caller_file.startswith(package_dir)

def log_external_calls(func):
    def wrapper(*args, **kwargs):
        if is_external_caller():
            InfoBugger().log(f'function {func.__name__} called from {get_caller_path()}')
        return func(*args, **kwargs)
    return wrapper

class UniversalTracker:
    def __init__(self, target=None):
        self.target = target
        self.tracer = None

    def start(self, trace_vars=True, show_std=False):
        if self.target:
            query = Q(module_contains=self.target) | Q(filename_has=self.target)
        else:
            caller_frame = sys._getframe(1)
            caller_file = os.path.basename(caller_frame.f_code.co_filename)
            query = Q(filename_has=caller_file)

        if not show_std:
            query &= ~Q(filename_contains='Python') & ~Q(filename_contains='lib')

        action = VarsPrinter if trace_vars else CodePrinter
        self.tracer = trace(query, action=action)
        return self.tracer

    def stop(self):
        if self.tracer:
            self.tracer.stop()

def monitor(func):
    def wrapper(*args, **kwargs):
        with trace(Q(function=func.__name__), action=CallPrinter):
            return func(*args, **kwargs)
    return wrapper

def quick_trace(target_name=None):
    q = Q(filename_has=target_name) if target_name else Q()
    trace(q & ~Q(filename_contains='lib'), action=CodePrinter)

class InfoSelf:
    def __init__(self):
        self.file = get_caller_path()
        self.folder = os.path.dirname(self.file)
        self.filename = os.path.basename(self.file)
        self.joined_file = os.path.join(self.folder, self.filename)
        self.filecontent = open(self.file, 'r').read()
        self.filename_noformat = self.filename.split('.')[0]
        self.access = os.access(self.file, os.R_OK | os.W_OK | os.X_OK)
        self.isfile = os.path.isfile(self.file)
        self.isdir = os.path.isdir(self.file)
        self.islink = os.path.islink(self.file)
        self.executable_folder = os.path.dirname(sys.executable)
        self.executable_filename = os.path.basename(sys.executable)
        self.executable = sys.executable
        self.joined_executable = os.path.join(self.executable_folder, self.executable_filename)
        self.executable_filename_noformat = self.executable_filename.split('.')[0]
        self.lines = open(self.file, 'r').readlines()
        self.infobugger_file = __file__
        self.infobugger_filename = os.path.basename(self.infobugger_file)
        self.infobugger_lines = open(self.infobugger_file, 'r').readlines()
        self.infobugger_folder = os.path.dirname(self.infobugger_file)
        self.infobugger_islink = os.path.islink(self.infobugger_file)
        self.infobugger_isfile = os.path.isfile(self.infobugger_file)
        self.infobugger_isdir = os.path.isdir(self.infobugger_file)
        self.executable_islink = os.path.islink(self.executable)
        self.executable_isfile = os.path.isfile(self.executable)
        self.executable_isdir = os.path.isdir(self.executable)
        self.infobugger_filecontent = open(self.infobugger_file, 'r').read()


__all__.extend([
    'InfoBugger',
    'quick_trace',
    'monitor',
    'UniversalTracker',
    'is_external_caller',
    'log_external_calls',
    'get_caller_path',
    'Q',
    'trace',
    'CodePrinter',
    'VarsPrinter',
    'CallPrinter',
    'datetime',
    'InfoSelf',
    'BasicCatcher'
])

def coolimport(module_name):
    return sys.modules[module_name]

__all__.append('coolimport')

setattr = _module_setattr