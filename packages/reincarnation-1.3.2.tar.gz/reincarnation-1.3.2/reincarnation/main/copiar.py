import os

class Copiar:
    def copy(self, name, obj, args={}):
        return type(name, (obj,), args)

class mainpath:
    def get(self):
        return os.path.abspath(__file__)

if '__file__' in globals():
    del __file__