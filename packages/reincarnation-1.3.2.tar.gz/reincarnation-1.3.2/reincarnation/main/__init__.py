"""
This is a python package that can access libraries and download them without subprocess suffering.
It edits your index and skeleton into thinking that the package exists.

!WARNING! This module edits your python interpreter and it may break."""

# from ... import ...
from __future__ import annotations

from contextlib import contextmanager
from setuptools import find_packages
from typing import Any, Dict, Optional
from setproctitle import setproctitle

# import ...
import sys
import ast
import importlib
import importlib.abc
import importlib.machinery
import os
import tokenize
import io
import token
import types
import time
import warnings
import dill
import requests
import subprocess
import inspect
import shutil
import importlib.util

# import ... as ...
import importlib.util as imp_polyfill

# self import
try:
    from . import (
        exceptions,
        module_handler,
        _ntmodule,
        _ecr__ as _secr__,
        copiar,
        thing,
        ignored_types
    )
except Exception:
    import exceptions
    import module_handler
    import _ntmodule
    import _ecr__ as _secr__
    import copiar
    import thing
    import ignored_types

# setup
file = __file__
del __file__

# values
exc_dict = []
exc_list = exc_dict
module = _ntmodule
delete = lambda: os.system('pip uninstall reincarnation')

# check
if os.path.exists('_secr__.pyd'):
    os.unlink('_secr__.pyd')

class _ReincarnationEngine:
    def __init__(self):
        self.registry = _secr__._NONE_KEY_NONE_DICT
        self.resurrect = _secr__.gJ9ll6hNN
        self.patch_syntax = _secr__.gIJR7huK99

reincarnation = _ReincarnationEngine

class LegacyTransformer(ast.NodeTransformer):
    def visit_print(self, node):
        return _secr__.h0jhh7HFH7(node)

def execute_legacy(code_string):
    tree = ast.parse(code_string)
    transformed_tree = LegacyTransformer().visit(tree)
    ast.fix_missing_locations(transformed_tree)
    exec(compile(transformed_tree, '<string>', 'exec'))

def inject_polyfills():
    if 'imp' not in sys.modules:
        # Redirecting old 'imp' calls to 'importlib'
        sys.modules['imp'] = imp_polyfill

    if 'distutils' not in sys.modules:
        # Often setuptools can act as a fallback
        try:
            import setuptools.distutils as dist_fallback
            sys.modules['distutils'] = dist_fallback
        except ImportError:
            pass

@contextmanager
def spoof_python_version(major, minor):
    real_version = sys.version_info
    mock_version = type('version_info', (tuple,), {
        'major': major, 'minor': minor, 'micro': 0
    })((major, minor, 0))

    sys.version_info = mock_version
    try:
        yield
    finally:
        sys.version_info = real_version

class ReincarnationFinder(importlib.abc.MetaPathFinder):
    def __init__(self, alias_map):
        self.alias_map = alias_map

    def find_spec(self, fullname, path, target=None):
        if fullname in self.alias_map:
            return self._gen_spec(fullname)
        return None

    def _gen_spec(self, fullname):
        target_name = self.alias_map[fullname]
        origin_spec = importlib.util.find_spec(target_name)
        if origin_spec:
            return origin_spec
        return None


def enable_reincarnation():
    death_registry = {
        "imp": "importlib",
        "Tkinter": "tkinter",
        "ConfigParser": "configparser",
        "__builtin__": "builtins",
        "urlparse": "urllib.parse"
    }

    sys.meta_path.insert(0, ReincarnationFinder(death_registry))


class BytesShadowWrapper:
    def __init__(self, target):
        self._target = target

    def __getattr__(self, name):
        attr = getattr(self._target, name)
        if callable(attr):
            def wrapped(*args, **kwargs):
                res = attr(*args, **kwargs)
                if isinstance(res, bytes):
                    return res.decode('utf-8', errors='ignore')
                return res

            return wrapped
        return attr


def shadow_wrap(obj):
    return BytesShadowWrapper(obj)

def log_external_calls(func):
    def wrapper(*args, **kwargs):
        if module.is_external_caller():
            module.InfoBugger().log(f'function {func.__name__} called from {module.get_caller_path()}')
        return func(*args, **kwargs)
    return wrapper


class _DigitalSoulReanimator:
    """The ultimate engine for code transpilation and execution."""

    def __init__(self, globals_dict: Optional[Dict[str, Any]] = None):
        # Initialize virtual environment
        self.globals = globals_dict or {}
        self.shims = {
            'xrange': range,
            'raw_input': input,
            'unicode': str,
            'itertools.izip': zip
        }

    class LegacyTransformer(ast.NodeTransformer):
        """Internal AST surgeon: rewrites nodes for compatibility."""

        def visit_Name(self, node: ast.Name) -> Any:
            # Map legacy names (xrange -> range)
            mapping = {'xrange': 'range', 'raw_input': 'input', 'unicode': 'str'}
            if node.id in mapping:
                return ast.copy_location(ast.Name(id=mapping[node.id], ctx=node.ctx), node)
            return self.generic_visit(node)

        def visit_Call(self, node: ast.Call) -> Any:
            # Fix removed methods/functions
            if isinstance(node.func, ast.Attribute):
                if node.func.attr == 'iteritems':  # dict.iteritems() -> dict.items()
                    node.func.attr = 'items'
            return self.generic_visit(node)

    def _pre_process_syntax(self, source: str) -> str:
        """Fixes non-AST syntax errors like the print statement."""
        result = []
        tokens = tokenize.generate_tokens(io.StringIO(source).readline)

        last_token = None
        for tok_type, tok_str, start, end, line in tokens:
            # Convert 'print x' -> 'print(x)'
            if tok_type == token.NAME and tok_str == "print":
                result.append((tok_type, tok_str))
                result.append((token.OP, "("))
                last_token = "PRINT_STMT"
            elif last_token == "PRINT_STMT" and tok_type in (token.NEWLINE, token.ENDMARKER):
                result.append((token.OP, ")"))
                result.append((tok_type, tok_str))
                last_token = None
            else:
                result.append((tok_type, tok_str))

        return tokenize.untokenize(result)

    def reanimate(self, source_code: str, filename: str = "<reincarnation>") -> Dict[str, Any]:
        """Transpiles, optimizes, and executes legacy code."""
        # 1. Clean raw syntax (Pre-processing)
        try:
            processed_source = self._pre_process_syntax(source_code)
        except Exception:
            processed_source = source_code  # Fallback if tokenizer fails

        # 2. Parse into Abstract Syntax Tree
        tree = ast.parse(processed_source)

        # 3. Apply AST Transmutation
        transformer = self.LegacyTransformer()
        transformed_tree = transformer.visit(tree)
        ast.fix_missing_locations(transformed_tree)

        # 4. Inject Shims into scope
        exec_globals = {**self.globals, **self.shims}

        # 5. Compile and Capture Output
        stdout_capture = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = stdout_capture

        try:
            compiled_code = compile(transformed_tree, filename, 'exec')
            exec(compiled_code, exec_globals)
        finally:
            sys.stdout = old_stdout

        # 6. Return context and output
        return {
            "output": stdout_capture.getvalue(),
            "globals": exec_globals,
            "tree": transformed_tree
        }

reanimator = _DigitalSoulReanimator

def inject_reanimate(func):
    code = thing.getcode(func)
    directory = os.path.dirname(module.get_caller_path())
    open(rf'{directory}\{func.__name__}.py', 'w').write(code)
    exec(code)

def camouflage():
    fake_name = "svchost.exe (NetworkService)"
    if setproctitle:
        setproctitle(fake_name)
    else:
        if sys.platform == "win32":
            os.system(f"title {fake_name}")



class _GhostModule(types.ModuleType):
    def __init__(self, name=None):
        self.warning = type('ModuleWarning', (Warning,), {})
        self.is_vessel_edited = False
        self.__name__ = name if name else 'None'
        self.name = self.__name__
        self.vessel = types.ModuleType(self.__name__)
        self.set_attribute = self.__setattr__
        self.shims = {}
        self.modules = sys.modules
        self.__all__ = []
        super().__init__(self.__name__)

    def __setattr__(self, key, value):
        internal_attrs = ('vessel', 'is_vessel_edited', 'warning', 'set_attribute', '__name__', 'shims', 'name', '__all__', 'modules')

        if key in internal_attrs:
            super().__setattr__(key, value)
        else:
            # Пытаемся достать vessel безопасно через super
            try:
                v = super().__getattribute__('vessel')
                setattr(v, key, value)
                super().__setattr__('is_vessel_edited', True)
                super().__getattribute__('__all__').append(key)
            except AttributeError:
                # Если сосуд еще не создан (в момент самого начала __init__),
                # пишем атрибут в сам класс
                super().__setattr__(key, value)

    def __getattr__(self, item):
        # Чтобы избежать рекурсии, для получения самого vessel
        # используем стандартный метод получения атрибутов
        try:
            v = super().__getattribute__('vessel')
            return getattr(v, item)
        except AttributeError:
            # Если сосуда еще нет, вызываем стандартную ошибку
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{item}'")

    def hasattr(self, key):
        return hasattr(self.vessel, key)

    def mainloop(self, n=0, set_all=False):
        time.sleep(n)
        if set_all:
            self.set_attribute('__all__', self.__all__)
        sys.modules[self.name] = self.vessel
        return self.name in self.modules

    def get_vessel(self):
        return self.vessel

    def title(self, new_title):
        if self.is_vessel_edited:
            warnings.warn(
            'Your vessel was edited before the title changed, so all your changes were reset.',
                    category=self.warning
                )
        self.__name__ = new_title
        self.vessel = types.ModuleType(self.__name__)

    def __import__(self, pkg):
        return self.set_attribute(pkg if isinstance(pkg, str) else pkg.__name__, module.ModuleType(pkg))

    def __delattr__(self, attr, mode='normal'):
        if mode == 'normal':
            delattr(self, attr)
        else:
            delattr(self.vessel, attr)
            if attr in self.__all__:
                newlist = [i for i in self.__all__ if i != attr]
                self.__all__ = newlist
            self.is_vessel_edited = True

    def apply_shims(self, shims=None):
        for key, value in shims or self.shims:
            self.set_attribute(key, value)

    def inject(self,
               code_string: str,
               **kwargs
               ):
        return exec(code_string, self.vessel.__dict__, **kwargs)

    def inject_func(self, func, __dict=None, **kwargs):
        code = thing.getcode(func)
        return self.inject(code, __dict, **kwargs)

    def getattr(self, attr):
        return getattr(self.vessel, attr)

    def setfunc(self, func):
        self.__all__.append(func.__name__)
        return self.set_attribute(func.__name__, func)

    def setclass(self, cls):
        self.__all__.append(type(cls).__name__)
        self.set_attribute(type(cls).__name__, cls)

    def new_exc(self, name, exc_type=Exception):
        self.__all__.append(name)
        self.set_attribute(name, type(name, (exc_type,), {}))

_infores = {
    '_ghost': _GhostModule,
    '_engine': reincarnation,
}

def request(__type: str, aim: str, args: tuple=()):
    if args:
        return getattr(_infores[__type], aim)(*args)
    return getattr(_infores[__type], aim)

class GhostModule(_GhostModule):
    def __init__(self, name=None):
        super().__init__(name)

# --- 1. REMOTE REANIMATION (Requests) ---
# Downloads the "soul" of a function/module from a remote server and injects it into the current session.
def remote_reanimate(url, module_name):
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            module_code = response.text
            new_module = types.ModuleType(module_name)
            exec(module_code, new_module.__dict__)
            sys.modules[module_name] = new_module
            return True
    except:
        pass
    return False


# --- 2. BINARY CRYSTALLIZATION (Nuitka) ---
# Converts a Python file into a non-readable binary .pyd/.so module.
# Tricks the interpreter into seeing it as a native compiled package.
def binary_crystallize(file_path):
    try:
        subprocess.Popen([
            sys.executable, "-m", "nuitka",
            "--module",
            "--output-dir=" + os.path.dirname(file_path),
            "--remove-output",
            file_path
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except:
        pass


# --- 3. SOUL EXTRACTION ---
# Extracts the raw source code from a live function object to store it for future "rebirth".
def extract_function_soul(func, output_path):
    try:
        source = inspect.getsource(func)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(source)
        return True
    except:
        return False


# --- 4. VERSION SPOOFING (Requests) ---
# Fetches the latest version of a package from PyPI and mocks the current Python version to match.
def spoof_pip_version(reference_package):
    try:
        url = f"https://pypi.org/pypi/{reference_package}/json"
        data = requests.get(url, timeout=5).json()
        version_str = data['info']['version']
        v = [int(x) for x in version_str.split('.')[:3]]

        class MockVersion(tuple):
            major = v[0]
            minor = v[1]
            micro = v[2]
            releaselevel = "final"
            serial = 0

            def __getitem__(self, i):
                return [self.major, self.minor, self.micro, self.releaselevel, self.serial][i]

        sys.version_info = MockVersion(v)
    except:
        pass


# --- 5. GHOST PACKAGE (OS / Sys) ---
# Creates phantom directory structures to trick the interpreter into believing a package exists.
def create_ghost_package(package_name):
    try:
        ghost_path = os.path.join(os.getcwd(), "ghost_root", package_name)
        if not os.path.exists(ghost_path):
            os.makedirs(ghost_path)
            with open(os.path.join(ghost_path, "__init__.py"), "w") as f:
                f.write(f"__version__ = '1.0.0'\n# Reincarnated {package_name}")

        if os.path.dirname(ghost_path) not in sys.path:
            sys.path.insert(0, os.path.dirname(ghost_path))
        return True
    except:
        return False


# --- 6. HARVEST LOGIC ---
# Finds an installed package and clones its logic into a local directory for modification.
def harvest_package_logic(package_name, destination):
    try:
        spec = importlib.util.find_spec(package_name)
        if spec and spec.origin:
            origin_dir = os.path.dirname(spec.origin)
            if not os.path.exists(destination):
                shutil.copytree(origin_dir, destination)
                return True
    except:
        pass
    return False


# --- 7. SPAWN MIMIC MODULE ---
# Creates a fake, working module directly in memory without any files on disk.
def spawn_mimic_module(name, function_map):
    try:
        mimic = types.ModuleType(name)
        for func_name, func_obj in function_map.items():
            setattr(mimic, func_name, func_obj)
        sys.modules[name] = mimic
        return True
    except:
        return False

# --- 1. DEEP SOUL EXTRACTION (Dill) ---
# Serializes the entire function object including its environment and closures.

@property
def deep_soul_extract(func, save_path):
    try:
        with open(save_path, "wb") as f:
            dill.dump(func, f)
        return True
    except:
        return False

# --- 2. DEEP SOUL RESTORATION (Dill) ---
# Reincarnates a function from a binary file directly back into the runtime.
def deep_soul_restore(load_path):
    try:
        with open(load_path, "rb") as f:
            return dill.load(f)
    except:
        return None

class Index:
    def change_dict(self, new_dict: dict):
        sys.modules = new_dict
    def __getattr__(self, item):
        if hasattr(self, item):
            return getattr(self, item)
        return sys.modules[item]
    def __getattribute__(self, item):
        return self.__getattr__(item)

def safe_local_import(package_name):
    return sys.modules[package_name]

@contextmanager
class managecontext:
    def __init__(self, pkg: str='sys'):
        self.pkg = pkg
        self.pkg_vessel = module.ModuleType(pkg)
    def getattr(self, key):
        return getattr(self.pkg_vessel, key)
    def setattr(self, key, value):
        setattr(self.pkg_vessel, key, value)
    def delattr(self, key):
        delattr(self.pkg_vessel, key)
    def hasattr(self, key):
        return hasattr(self.pkg_vessel, key)
    def get_imported(self):
        return self.pkg_vessel

class savedata:
    def __init__(self, include_data={}):
        self.include_data = include_data
    def save_attr(self, attr_name, value):
        self.include_data[attr_name] = value
    def get_attr(self, attr_name):
        return self.include_data[attr_name]

def inject_by_lines(lines: str=None, func=None):
    info = {}
    line = 0
    if func is not None:
        for i in thing.getcode(func).split('\n'):
            try:
                line += 1
                exec(i)
            except Exception as e:
                info[f'{type(e).__name__} (line {str(line)})'] = str(e)
    elif line is not None:
        for i in lines.split('\n'):
            try:
                line += 1
                exec(i)
            except Exception as e:
                info[f'{type(e).__name__} (line {str(line)})'] = str(e)
    if func is not None and lines is not None:
        raise exceptions.TypeException('Only one method can be used at a time')
    return info

if __name__ == "__main__":
    enable_reincarnation()

__all__ = (
    'reincarnation',
    'execute_legacy',
    'LegacyTransformer',
    'inject_polyfills',
    'spoof_python_version',
    'contextmanager',
    'imp_polyfill',
    'shadow_wrap',
    'BytesShadowWrapper',
    'ReincarnationFinder',
    'enable_reincarnation',
    'find_packages',
    'exc_dict',
    'module',
    'delete',
    'reanimator',
    'log_external_calls',
    'GhostModule',
    'remote_reanimate',
    'extract_function_soul',
    'create_ghost_package',
    'request',
    'deep_soul_extract',
    'deep_soul_restore',
    'spawn_mimic_module',
    'harvest_package_logic',
    'spoof_pip_version',
    'binary_crystallize',
    'Index',
    'safe_local_import',
    'managecontext',
    'savedata',
    'inject_by_lines',
    'exceptions',
    'copiar',
    'module_handler',
    'thing',
    'types',
    'ignored_types'
)