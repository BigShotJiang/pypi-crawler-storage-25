from types import *
import types as _types

_string = type('string', (str,), {})
_builtin_function_or_method = type('builtin_function_or_method', (object,), {})
_exception = type('exception', (Exception,), {})
_module = type('module', (ModuleType,), {})
_OverrideType = type('OverrideType', (object,), {})
_method = type('method', (object,), {})
_function = FunctionType
_deleted_object = type('deleted_object', (object,), {})

del _deleted_object
try:
    _deleted_object = type('deleted_object', (_deleted_object,), {})
except NameError:
    _deleted_object = type('deleted_object', (object,), {})

class string(_string):
    pass

class builtin_function_or_method(_builtin_function_or_method):
    pass

class exception(_exception):
    pass

class module(_module):
    pass

class OverrideType(_OverrideType):
    pass

class method(_method):
    pass

class deleted_object(_deleted_object):
    pass

__all__ = [
    'string',
    'builtin_function_or_method',
    'exception',
    'module',
    'OverrideType',
    'method',
    'deleted_object'
]

__all__.extend([i for i in _types.__all__ if i not in __all__])