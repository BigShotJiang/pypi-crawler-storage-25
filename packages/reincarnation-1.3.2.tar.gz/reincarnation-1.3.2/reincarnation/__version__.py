__author__ = 'Andrew Sergeevich'
__email__ = 'jumpki11@hotmail.com'
__version__ = '1.2.8'
__license__ = 'MIT License'