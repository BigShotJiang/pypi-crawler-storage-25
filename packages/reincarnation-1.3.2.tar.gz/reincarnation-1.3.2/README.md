# Reincarnation: Code Immortality Engine

![](https://img.shields.io/badge/python-3.7%2B-blue.svg)

![](https://img.shields.io/badge/License-MIT-yellow.svg)

# 1.2.8: WHAT'S NEW?
* More `GhostModule` features
* More functions and code
* New file: `ignored_types.py`

## 💥 THE PROBLEM: CODE IS DYING 💥
Python evolves and breaks the old. Libraries like `pythonnet` or modules like `distutils` become ghosts in the digital graveyard.

## 🚀 THE SOLUTION: REINCARNATION ENGINE 🚀
**Reincarnation** is digital resurrection for your legacy Python projects. It allows you to run outdated code on modern interpreters seamlessly.

## FEATURES: THE NINE LIVES OF CODE
*   **🔮 Future Annotations:** Uses `from __future__ import annotations` for lazy evaluation.
*   **⚙️ AST Transpilation:** Rewrites old syntax (like `print x`) into modern calls (`print(x)`) on the fly.
*   **👻 Module Polyfills:** Replaces removed modules (`imp`, `distutils`, `Tkinter`) with modern equivalents.
*   **🎭 Version Spoofing:** Tricks libraries into thinking they run on older Python versions.
*   **🔗 Global Import Hook:** Intercepts imports via `sys.meta_path` to provide resurrected modules.
*   **🌉 Byte/String Bridge:** Handles Python 2-to-3 encoding issues transparently.
*   **🌐 Ghost Env:** Virtual variables to satisfy legacy requirements.

## 🛠️ GETTING STARTED
1. **Install:**
   `pip install reincarnation`

2. **The Ritual:**
   Add this at the very beginning of your legacy script:
   
```python
import reincarnation
reincarnation.enable_universal_resurrection() 

import tkinter 
import imp 
print 'Hello from the past!' 
   ```

 ⚡️ ADVANCED USAGE
Define custom shims for specific variables:
``` python
import reincarnation
def my_modern_ref(dll): print(f"Linked: {dll}")

reincarnation.enable_resurrection(
    shims={"clr.AddReference": my_modern_ref}
)
```


 🤝 CONTRIBUTING
Contributions are welcome! Join us in building a more resilient software future.

 📜 LICENSE
Licensed under the MIT License.