ODIN is a demo Python package for optical engineers.
We believe in a straightforward path to great design and tolerancing.
Let the best wavefront win😄

## Requirements

- Python 3.x, ZOSAPI, NumPy, clr, os, winreg, random

# Math Module

## Interferometry Math Utilities

 Lightweight Python helpers for common interferometry conversions.
 Convert surface irregularity and optical power between fringes,
 millimeters, and radius of curvature.

## Features

 - Irregularity conversion: fringes ↔ millimeters
 - Optical power conversion: fringes ↔ millimeters
 - Supports concave (CC) and convex (CX) surfaces
 - NumPy-only dependency
 - Simple random value generator for simulation/testing

## Main Class
```Python
Math()
 ```
- Main interface for using Math functions.

## Functions

```Python
irrFrToMm(fringes, wavelength_nm)
```
- Convert surface irregularity from fringes to millimeters.
```Python
irrMmToFr(irregularity_mm, wavelength_nm)
```
- Convert surface irregularity from millimeters to fringes.
```Python
powFrToMm(diameter_mm, nominal_radius_mm, surface_type, fringes, wavelength_nm)
```
- Convert power in fringes to corrected radius in millimeters.
```Python
powMmToFr(diameter_mm, nominal_radius_mm, surface_type, power_mm, wavelength_nm)
```
- Convert power in millimeters to fringes.
```Python
randomValue(distribution="uniform")
```
- Generate a random value between -1 and 1.
    - Distributions: uniform, gauss, parabolic

# ZOSpy Module

A demo Python wrapper for Zemax OpticStudio (ZOS-API)

## ZOSpy – OpticStudio Automation Utilities

Lightweight Python interface for connecting to Zemax OpticStudio,
manipulating lens data, merit functions, and running tolerancing
analyses via ZOS-API.

## Features

- Offline ZMX file read/write/edit without OpticStudio
- Connect to OpticStudio (Interactive or Standalone)
- Open, save, and modify ZMX/ZOS files
- Lens Data Editor (LDE) surface and parameter control
- Merit Function Editor (MFE) access
- Local optimization control
- Monte Carlo tolerancing utilities

## Main Class
```Python
ZOSpy()
 ```
- Main interface for connecting to and controlling OpticStudio.

## File Handling
```Python
readOfflineZmx(pathToZmx)
```
- Read a .zmx file as text into memory.
```Python
writeOfflineZmx(pathToZmxWithNewName)
```
- Write modified offline .zmx content to file.
```Python
openFile(path)
```
- Open a ZMX or ZOS file in OpticStudio.
```Python
saveFile()
```
- Save the current system.
```Python
saveAsFile(pathWithName)
```
- Save the system under a new name.

## Connections
```Python
connectOS()
```
- Connect via Interactive Extension.
```Python
connectOSSA()
```
- Connect via Standalone Application.
```Python
disconnectOS()
```
- Close OpticStudio and release the connection.

## OfflineLDE
```Python
OfflineLDE.getParameter(surface, parameter)
```
- Read a surface parameter from offline ZMX text.
```Python
OfflineLDE.setParameter(surface, parameter, value)
```
- Modify a surface parameter in offline ZMX text.

## LDE (Lens Data Editor)
```Python
LDE.getSurfaceByComment(comment)
```
- Find a surface index by comment.
```Python
LDE.addSurfaceAfter(surface)
LDE.addSurfaceBefore(surface)
```
- Add new surfaces relative to an existing one.
```Python
LDE.removeSurfaces(first_surface, last_surface)
```
- Remove a range of surfaces.
```Python
LDE.setSurfaceType(surface, type)
```
- Change the surface type.
```Python
LDE.setParameter(surface, parameter, value)
```
- Set a surface parameter.
```Python
LDE.getParameter(surface, parameter)
```
- Get a surface parameter value.
```Python
LDE.ignoreSurface(surface, bool)
```
- Enable or ignore a surface.
```Python
LDE.setUiUpdate(bool)
```
- Enable or disable live UI updates.
```Python
LDE.removeAllVariable()
```
- Remove all variables from the system.
```Python
LDE.setCoordinateBreakToElement(surface_1, surface_2, color)
```
- Group surfaces into an element using coordinate breaks.

## MFE (Merit Function Editor)
```Python
MFE.loadMeritFunction(path)
```
- Load a merit function file.
```Python
MFE.calculateMeritFunction()
```
- alculate the current merit function.
```Python
MFE.getTarget(line)
MFE.setTarget(line, target)
```
- Get or set merit function targets.
```Python
MFE.getWeight(line)
MFE.setWeight(line, weight)
```
- Get or set merit function weights.
```Python
MFE.getValue(line)
```
- Read a merit function value.

## TDE (Tolerance Data Editor)
```Python
TDE.loadTDE(path)
```

## Tolerancing
```Python
Tolerancing.getMonteCarlo()
```
- Run a single Monte Carlo tolerancing analysis.
```Python
Tolerancing.runMonteCarlos(cores, ScriptIndex, NumberOfRuns, NumberToSave)
```
- Run multiple Monte Carlo simulations.
```Python
Tolerancing.getData(column)
```
- Extract a column of Monte Carlo result data.

## Analysis
```Python
Analysis.getUnitNormalizedSensitivityMatrix(input_array)
```
- Calculate the sensitivity of MFE operands relative to specific parameter perturbations and record nominal states.
```Python
Analysis.plotSensitivityMatrix(sensitivity_matrix, input_array)
```
- Generate a heatmap visualization of the sensitivity data with dynamic scaling and parameter labeling.


## Database Module

### SQL Server Database Utilities

Lightweight Python helper class for connecting to and interacting
with a Microsoft SQL Server database.
Provides simple methods for connection handling, table inspection,
and filtered data retrieval.
Uses a config.ini file for credential management.

### Features

- Connect / disconnect using config file
- List all database tables
- Show table structure (columns, types, length)
- Display full table content
- Filtered data retrieval (pn, sn)
- Table whitelist for basic SQL injection protection
- Uses pymssql

### Main Class

```Python
Database()
```
- Main interface for managing database operations.

### Functions

```Python
connect(config_path, password=None)
```
- Connect to the database using a config.ini file.
- Internal Access Only: This function is password-protected and intended for use by authorized colleagues only.

```Python
disconnect()
```
- Close the active database connection.

```Python
listTables()
```
- List all base tables in the database.

```Python
showTableStructure(table_name)
```
- Display column structure of a selected table.

```Python
showTableData(table_name)
```
- Display all rows from a selected table.

```Python
getData(table, pn, sn)
```
- Retrieve rows filtered by part number (pn) and serial number (sn).
- Table must be in the allowed whitelist.

```Python
getThicknessData(pn, sn)
```
- Retrieve rows from the thickness table filtered by part number (pn) and serial number (sn).
- Automatically searches within the [LentsTrace].[dbo].[thickness] path.
- Results are sorted by [datetime] in descending order.

```Python
getRadiusData(pn, sn, side)
```
- Retrieve rows from the Radii table filtered by part number (pn), serial number (sn), and side.
- Automatically searches within the [LentsTrace].[dbo].[Radii] path.
- Results are sorted by [datetime] in descending order.

```Python
getOwiData(pn, sn, side)
```
- Retrieve rows from the OWI table filtered by part number (pn), serial number (sn), and side.
- The side parameter is matched against the strana column in the database.
- Results are sorted by the measurement timestamp [mereno] in descending order.

### Example config.ini

```ini
[database]
server = YOUR_SERVER
database = YOUR_DATABASE
username = YOUR_USERNAME
password = YOUR_PASSWORD
```