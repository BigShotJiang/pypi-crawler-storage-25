import pymssql
import configparser
from .security import protected

class MSSQLDatabase:
    def __init__(self):
        self.conn = None
        self.server = None
        self.database = None
        self.username = None
        self.password = None

    @protected
    def connect(self, config_path, password=None):
        """
        Connect to the database using a config file.

        Parameters:
            config_path (str): Path to config.ini with credentials.
        """
        try:
            config = configparser.ConfigParser()
            config.read(config_path)

            self.server = config["database"]["server"]
            self.database = config["database"]["database"]
            self.username = config["database"]["username"]
            self.password = config["database"]["password"]

            self.conn = pymssql.connect(
                server=self.server,
                user=self.username,
                password=self.password,
                database=self.database
            )

            print("Connection successful!")

        except Exception as e:
            print("Error connecting to the database:", e)

    def disconnect(self):
        """
        Close the active database connection.
        """
        try:
            if self.conn:
                self.conn.close()
                self.conn = None
                print("Disconnected from the database.")
            else:
                print("No active connection to disconnect.")
        except Exception as e:
            print("Error disconnecting from the database:", e)


    def listTables(self):
        """
        List all base tables in the database.
        """
        if not self.conn:
            print("Not connected to the database.")
            return

        try:
            cursor = self.conn.cursor()
            query = """
            SELECT TABLE_NAME
            FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_TYPE = 'BASE TABLE'
            """
            cursor.execute(query)
            tables = cursor.fetchall()

            print("Tables in the database:")
            for table in tables:
                print(table[0])
        except Exception as e:
            print("Error fetching tables:", e)

    def showTableStructure(self, table_name):
        """
        Show column structure of a table.

        Parameters:
            table_name (str): Table name.
        """
        if not self.conn:
            print("Not connected to the database.")
            return

        try:
            cursor = self.conn.cursor()
            query = """
            SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = %s
            """
            cursor.execute(query, (table_name,))
            columns = cursor.fetchall()

            print(f"Structure of the table '{table_name}':")
            print(f"{'Column Name':<30} {'Data Type':<15} {'Max Length'}")
            print("=" * 60)

            for column in columns:
                column_name, data_type, max_length = column
                max_length = max_length if max_length is not None else ''
                print(f"{column_name:<30} {data_type:<15} {max_length}")

        except Exception as e:
            print(f"Error fetching structure of table '{table_name}':", e)

    def showTableData(self, table_name):
        """
        Display all data from a table.

        Parameters:
            table_name (str): Table name.
        """
        if not self.conn:
            print("Not connected to the database.")
            return

        try:
            cursor = self.conn.cursor()
            query = f"SELECT * FROM {table_name}"
            cursor.execute(query)

            rows = cursor.fetchall()
            columns = [column[0] for column in cursor.description]

            print(f"Data in the table '{table_name}':")
            print(columns)

            for row in rows:
                print(row)

        except Exception as e:
            print(f"Error fetching data from table '{table_name}':", e)

    def getData(self, table, pn, sn):
        """
        Get rows filtered by pn and sn.

        Parameters:
            table (str): Table name (must be allowed).
            pn: Part number filter.
            sn: Serial number filter.

        Returns:
            list | None: Matching rows, empty list, or None on error.
        """
        if not self.conn:
            print("Not connected to the database.")
            return None

        try:
            # Optional but strongly recommended: whitelist tables
            allowed_tables = [
                "NewView7100",
                "ASI",
                "Radii",
                "sysdiagrams",
                "OWI",
                "OWI_vyr",
                "diameter",
                "thickness"
                ]
            if table not in allowed_tables:
                raise ValueError("Invalid table name")

            cursor = self.conn.cursor(as_dict=True)

            query = f"""
                SELECT *
                FROM {table}
                WHERE pn = %s AND sn = %s
            """

            cursor.execute(query, (pn, sn))
            rows = cursor.fetchall()

            if rows:
                print(f"{len(rows)} record(s) found for pn='{pn}', sn='{sn}'")
                return rows
            else:
                print(f"No records found for pn='{pn}', sn='{sn}'")
                return []

        except Exception as e:
            print(f"Error fetching data for pn='{pn}', sn='{sn}':", e)
            return None

    def getThicknessData(self, pn, sn):
            """
            Get thickness data filtered by pn and sn from the thickness table.
            Ordered by datetime descending.

            Parameters:
                pn (int): Part number filter.
                sn (int): Serial number filter.

            Returns:
                list | None: List of matching records (dictionaries), empty list, or None on error.
            """
            if not self.conn:
                print("Not connected to the database.")
                return None

            try:
                cursor = self.conn.cursor(as_dict=True)

                # Using LIKE with parameters requires adding % to the values
                # Using [LentsTrace].[dbo].[thickness] as requested
                query = f"""
                    SELECT *
                    FROM [LentsTrace].[dbo].[thickness]
                    WHERE pn = {pn} AND sn = {sn}
                    ORDER BY [datetime] DESC;
                """

                cursor.execute(query)
                rows = cursor.fetchall()

                if rows:
                    print(f"{len(rows)} thickness record(s) found for pn='{pn}', sn='{sn}'")
                    return rows
                else:
                    print(f"No thickness records found for pn='{pn}', sn='{sn}'")
                    return []

            except Exception as e:
                print(f"Error fetching thickness data for pn='{pn}', sn='{sn}':", e)
                return None

    def getRadiusData(self, pn, sn, side):
            """
            Get radii data filtered by pn, sn, and side from the Radii table.
            Ordered by datetime descending.

            Parameters:
                pn (int): Part number filter.
                sn (int): Serial number filter.
                side (str): Side identifier (e.g., 'L', 'R').

            Returns:
                list | None: List of matching rows as dictionaries, empty list, or None on error.
            """
            if not self.conn:
                print("Not connected to the database.")
                return None

            try:
                cursor = self.conn.cursor(as_dict=True)

                # SQL query using parameterized inputs for security and reliability
                query = f"""
                    SELECT *
                    FROM [LentsTrace].[dbo].[Radii]
                    WHERE pn = {pn} AND sn = {sn} AND side = '{side}'
                    ORDER BY [datetime] DESC;
                """

                cursor.execute(query)
                rows = cursor.fetchall()

                if rows:
                    print(f"{len(rows)} radii record(s) found for pn='{pn}', sn='{sn}', side='{side}'")
                    return rows
                else:
                    print(f"No radii records found for pn='{pn}', sn='{sn}', side='{side}'")
                    return []

            except Exception as e:
                print(f"Error fetching radii data for pn='{pn}', sn='{sn}', side='{side}':", e)
                return None

    def getOwiData(self, pn, sn, side):
            """
            Get OWI data filtered by pn, sn, and side (strana).
            Ordered by mereno descending.

            Parameters:
                pn (int): Part number filter.
                sn (int): Serial number filter.
                side (str): Side identifier (e.g., 'L', 'R').

            Returns:
                list | None: List of matching rows, empty list, or None on error.
            """
            if not self.conn:
                print("Not connected to the database.")
                return None

            try:
                cursor = self.conn.cursor(as_dict=True)

                # Note: Using 'strana' for the column and 'mereno' for ordering as per your query
                query = f"""
                    SELECT *
                    FROM [LentsTrace].[dbo].[OWI]
                    WHERE pn = {pn} AND sn = {sn} AND strana = '{side}'
                    ORDER BY [mereno] DESC;
                """

                cursor.execute(query)
                rows = cursor.fetchall()

                if rows:
                    print(f"{len(rows)} OWI record(s) found for pn='{pn}', sn='{sn}', side='{side}'")
                    return rows
                else:
                    print(f"No OWI records found for pn='{pn}', sn='{sn}', side='{side}'")
                    return []

            except Exception as e:
                print(f"Error fetching OWI data for pn='{pn}', sn='{sn}', side='{side}':", e)
                return None

    def getAsiData(self, pn, sn, side):
            """
            Get ASI data filtered by pn, sn, and side (strana).
            Ordered by mereno descending.

            Parameters:
                pn (int): Part number filter.
                sn (int): Serial number filter.
                side (str): Side identifier (e.g., 'L', 'R').

            Returns:
                list | None: List of matching rows, empty list, or None on error.
            """
            if not self.conn:
                print("Not connected to the database.")
                return None

            try:
                cursor = self.conn.cursor(as_dict=True)

                # Note: Using 'strana' for the column and 'mereno' for ordering as per your query
                query = f"""
                    SELECT *
                    FROM [LentsTrace].[dbo].[ASI]
                    WHERE pn = {pn} AND sn = {sn} AND strana = '{side}'
                    ORDER BY [mereno] DESC;
                """

                cursor.execute(query)
                rows = cursor.fetchall()

                if rows:
                    print(f"{len(rows)} ASI record(s) found for pn='{pn}', sn='{sn}', side='{side}'")
                    return rows
                else:
                    print(f"No ASI records found for pn='{pn}', sn='{sn}', side='{side}'")
                    return []

            except Exception as e:
                print(f"Error fetching ASI data for pn='{pn}', sn='{sn}', side='{side}':", e)
                return None


    def runSqlQuery(self, sqlRequest):
            """
            Execute a raw SQL query string and return the results.

            Parameters:
                sqlRequest (str): The full SQL query string to execute.

            Returns:
                list | None: Matching rows (as dicts), an empty list if no results, 
                            or None if a connection or execution error occurs.
            """
            # 1. Connection Guard
            if not self.conn:
                print("Not connected to the database.")
                return None

            try:
                # 2. Initialize cursor (as_dict=True to match your getData style)
                cursor = self.conn.cursor(as_dict=True)

                # 3. Execute the provided SQL string
                # Note: Since this accepts a raw string, ensure the input is 
                # sanitized or from a trusted source to prevent SQL injection.
                cursor.execute(sqlRequest)
                
                # 4. Fetch results
                rows = cursor.fetchall()

                if rows:
                    print(f"Query executed successfully. {len(rows)} record(s) returned.")
                    return rows
                else:
                    print("Query executed successfully. No records found.")
                    return []

            except Exception as e:
                print(f"Error executing SQL request: {e}")
                return None