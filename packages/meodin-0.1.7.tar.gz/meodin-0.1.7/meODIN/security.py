import functools
import hashlib
from datetime import datetime

# Hash password
ALREADY_HASHED = "aa80db16cccb516f33b28308aa738d7a5fdbd2c4280a3732c27335f986592228"

def protected(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # 1. Check the Year
        current_year = datetime.now().year
        if current_year != 2026:
            raise PermissionError(
                f"Access Denied: This library is only authorized for use in 2026. "
                f"Current year detected: {current_year}"
            )

        # 2. Check the Password
        provided = kwargs.get('password', "")
        provided_hash = hashlib.sha256(str(provided).encode()).hexdigest()

        if provided_hash == ALREADY_HASHED:
            # Clean up before calling the function
            kwargs.pop('password', None)
            return func(*args, **kwargs)
        else:
            raise PermissionError("Access Denied: Incorrect Password.")
            
    return wrapper