from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    description = f.read()

setup(
    name="meodin",
    version="0.1.7",
    description="Optical Design Integrated Network",
    author="Sebastian Gedeon",
    author_email="sebastian.gedeon@gmail.com",
    packages=find_packages(),
    install_requires=["requests", "pymssql"],
    python_requires=">=3.7",
    license="MIT",
    license_files=("LICENSE",),
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    long_description=description,
    long_description_content_type="text/markdown"
)

