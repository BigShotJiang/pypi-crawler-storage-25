default_app_config = "django_realtime_chat.apps.DjangoRealtimeChatConfig"
__version__ = "1.3.4"
__author__ = "Armand Kouassi (krak225)"
__email__ = ""