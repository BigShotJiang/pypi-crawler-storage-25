#include <stdio.h>
#include <string.h>

int main() {
  char production[20], prefix[10], part1[10], part2[10];
  int i, j = 0, k = 0;

  printf("Enter production (Example: A=abC|abD): ");
  scanf("%s", production);

  // Find common prefix
  for (i = 2; production[i] != '|' && production[i + 3] != '\0'; i++) {
    if (production[i] == production[i + 3]) {
      prefix[j++] = production[i];
    } else {
      break;
    }
  }
  prefix[j] = '\0';

  // Extract remaining parts
  i = 2 + j;
  while (production[i] != '|') {
    part1[k++] = production[i++];
  }
  part1[k] = '\0';

  i = i + 1;
  k = 0;
  while (production[i] != '\0') {
    part2[k++] = production[i++];
  }
  part2[k] = '\0';

  // Output
  printf("\nAfter Left Factoring:\n");

  printf("%c -> %s%c'\n", production[0], prefix, production[0]);
  printf("%c' -> %s | %s\n", production[0], part1, part2);

  return 0;
}