#include <stdio.h>
#include <string.h>

int main() {
  char production[20], alpha[10], beta[10];
  char non_terminal;
  int i = 0, j = 0, k = 0;

  printf("Enter production (Example: E=E+T|T): ");
  scanf("%s", production);

  non_terminal = production[0];

  // Separate alpha and beta
  for (i = 2; i < strlen(production); i++) {
    if (production[i] == non_terminal) {
      // alpha part
      i++;
      while (production[i] != '|' && production[i] != '\0') {
        alpha[j++] = production[i++];
      }
    } else {
      // beta part
      while (production[i] != '|' && production[i] != '\0') {
        beta[k++] = production[i++];
      }
    }
  }

  alpha[j] = '\0';
  beta[k] = '\0';

  // Output new grammar
  printf("\nAfter removing left recursion:\n");

  printf("%c -> %s%c'\n", non_terminal, beta, non_terminal);
  printf("%c' -> %s%c' | e\n", non_terminal, alpha, non_terminal);

  return 0;
}