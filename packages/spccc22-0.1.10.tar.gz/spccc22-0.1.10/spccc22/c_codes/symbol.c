#include <stdio.h>
#include <string.h>

int main() {
  char type[10], var[10];
  int size;

  printf("Enter number of variables: ");
  int n;
  scanf("%d", &n);

  printf("\nSymbol Table:\n");
  printf("Variable\tType\tSize\n");

  for (int i = 0; i < n; i++) {
    scanf("%s %s", type, var);

    // Determine size
    if (strcmp(type, "int") == 0)
      size = 2;
    else if (strcmp(type, "float") == 0)
      size = 4;
    else if (strcmp(type, "char") == 0)
      size = 1;
    else
      size = 0;

    printf("%s\t\t%s\t%d\n", var, type, size);
  }

  return 0;
}