#include <stdio.h>
#include <string.h>

char table[5][5][10];
char nonTerminals[] = {'E', 'R', 'T'};
char terminals[] = {'i', '+', '$'};

int main() {

  // Initialize table with empty
  for (int i = 0; i < 5; i++)
    for (int j = 0; j < 5; j++)
      strcpy(table[i][j], " ");

  // Fill table manually using FIRST & FOLLOW rules

  // E → TR , FIRST(E) = {i}
  strcpy(table[0][0], "E->TR");

  // R → +TR , FIRST = {+}
  strcpy(table[1][1], "R->+TR");

  // R → ε , FOLLOW(R) = {$}
  strcpy(table[1][2], "R->e");

  // T → i , FIRST = {i}
  strcpy(table[2][0], "T->i");

  // Print table
  printf("\nLL(1) Parsing Table:\n\n");

  printf("      i       +       $\n");

  for (int i = 0; i < 3; i++) {
    printf("%c  ", nonTerminals[i]);
    for (int j = 0; j < 3; j++) {
      printf("%-8s", table[i][j]);
    }
    printf("\n");
  }

  return 0;
}