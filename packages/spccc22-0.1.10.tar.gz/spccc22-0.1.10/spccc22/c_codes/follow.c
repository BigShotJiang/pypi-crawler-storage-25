#include <ctype.h>
#include <stdio.h>
#include <string.h>

char production[10][10];
char first[10][10], follow[10][10];
int n;

void addToSet(char *set, char c) {
  int i;
  for (i = 0; set[i] != '\0'; i++) {
    if (set[i] == c)
      return;
  }
  set[i] = c;
  set[i + 1] = '\0';
}

void findFollow(char c) {
  int i, j;

  // If start symbol
  if (c == production[0][0]) {
    addToSet(follow[c - 'A'], '$');
  }

  for (i = 0; i < n; i++) {
    for (j = 2; production[i][j] != '\0'; j++) {

      if (production[i][j] == c) {

        // Case: A → αBβ
        if (production[i][j + 1] != '\0') {
          char next = production[i][j + 1];

          if (!isupper(next)) {
            addToSet(follow[c - 'A'], next);
          } else {
            int k;
            for (k = 0; first[next - 'A'][k] != '\0'; k++) {
              if (first[next - 'A'][k] != '$')
                addToSet(follow[c - 'A'], first[next - 'A'][k]);
            }
          }
        } else {
          // Case: A → αB
          if (production[i][0] != c)
            findFollow(production[i][0]);

          int k;
          for (k = 0; follow[production[i][0] - 'A'][k] != '\0'; k++) {
            addToSet(follow[c - 'A'], follow[production[i][0] - 'A'][k]);
          }
        }
      }
    }
  }
}

int main() {
  int i;
  char c;

  printf("Enter number of productions: ");
  scanf("%d", &n);

  printf("Enter productions (Example: E=TR):\n");
  for (i = 0; i < n; i++) {
    scanf("%s", production[i]);
  }

  // Input FIRST sets
  printf("Enter FIRST sets:\n");
  for (i = 0; i < n; i++) {
    printf("FIRST(%c): ", production[i][0]);
    scanf("%s", first[production[i][0] - 'A']);
  }

  printf("Enter non-terminal to find FOLLOW: ");
  scanf(" %c", &c);

  findFollow(c);

  printf("FOLLOW(%c) = { ", c);
  for (i = 0; follow[c - 'A'][i] != '\0'; i++) {
    printf("%c ", follow[c - 'A'][i]);
  }
  printf("}\n");

  return 0;
}