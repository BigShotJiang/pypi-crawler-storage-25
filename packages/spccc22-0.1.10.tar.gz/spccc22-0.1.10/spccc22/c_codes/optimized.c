#include <stdio.h>
#include <string.h>

int main() {
  char op1[10], op2[10], op[5], res[10];
  char prev_expr[20] = "";
  char curr_expr[20];

  printf("Enter number of statements: ");
  int n;
  scanf("%d", &n);

  printf("Enter statements (Example: a = b + c):\n");

  for (int i = 0; i < n; i++) {
    scanf("%s = %s %s %s", res, op1, op, op2);

    // Create expression string
    sprintf(curr_expr, "%s%s%s", op1, op, op2);

    // Constant folding
    if (op1[0] >= '0' && op1[0] <= '9' && op2[0] >= '0' && op2[0] <= '9') {

      int val1 = op1[0] - '0';
      int val2 = op2[0] - '0';
      int result;

      if (strcmp(op, "+") == 0)
        result = val1 + val2;
      else if (strcmp(op, "-") == 0)
        result = val1 - val2;
      else if (strcmp(op, "*") == 0)
        result = val1 * val2;
      else if (strcmp(op, "/") == 0)
        result = val1 / val2;

      printf("%s = %d\n", res, result);
    }

    // Common subexpression
    else if (strcmp(curr_expr, prev_expr) == 0) {
      printf("%s = (reuse previous result)\n", res);
    }

    else {
      printf("%s = %s %s %s\n", res, op1, op, op2);
      strcpy(prev_expr, curr_expr);
    }
  }

  return 0;
}