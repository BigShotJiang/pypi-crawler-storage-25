#include <stdio.h>
#include <string.h>

int main() {
  FILE *fp, *mnt, *mdt;
  char label[10], opcode[10], operand[10];
  int mdtc = 1;

  fp = fopen("input.txt", "r");
  mnt = fopen("mnt.txt", "w");
  mdt = fopen("mdt.txt", "w");

  while (fscanf(fp, "%s %s %s", label, opcode, operand) != EOF) {

    if (strcmp(opcode, "MACRO") == 0) {
      // Read next line (macro name)
      fscanf(fp, "%s %s %s", label, opcode, operand);

      // Write to MNT
      fprintf(mnt, "%s\t%d\n", opcode, mdtc);

      // Write to MDT
      fprintf(mdt, "%s %s %s\n", label, opcode, operand);
      mdtc++;

      // Read till MEND
      while (strcmp(opcode, "MEND") != 0) {
        fscanf(fp, "%s %s %s", label, opcode, operand);
        fprintf(mdt, "%s %s %s\n", label, opcode, operand);
        mdtc++;
      }
    }
  }

  fclose(fp);
  fclose(mnt);
  fclose(mdt);

  printf("Pass 1 completed.\n");
  printf("MNT and MDT generated.\n");

  return 0;
}