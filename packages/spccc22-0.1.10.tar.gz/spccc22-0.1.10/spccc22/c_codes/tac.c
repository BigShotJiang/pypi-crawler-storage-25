#include <stdio.h>
#include <string.h>

int main() {
  char exp[20];
  int i = 0, temp = 1;

  printf("Enter expression: ");
  scanf("%s", exp);

  printf("\nThree Address Code:\n");

  // First handle * and /
  for (i = 0; exp[i] != '\0'; i++) {
    if (exp[i] == '*' || exp[i] == '/') {
      printf("t%d = %c %c %c\n", temp, exp[i - 1], exp[i], exp[i + 1]);

      exp[i + 1] = '0' + temp; // replace with temp variable
      temp++;
    }
  }

  // Then handle + and -
  for (i = 0; exp[i] != '\0'; i++) {
    if (exp[i] == '+' || exp[i] == '-') {
      printf("t%d = %c %c %c\n", temp, exp[i - 1], exp[i], exp[i + 1]);

      exp[i + 1] = '0' + temp;
      temp++;
    }
  }

  return 0;
}