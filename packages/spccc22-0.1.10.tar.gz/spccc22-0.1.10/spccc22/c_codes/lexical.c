#include <ctype.h>
#include <stdio.h>
#include <string.h>

int isKeyword(char word[]) {
  char keywords[6][10] = {"int", "float", "if", "else", "while", "return"};
  int i;

  for (i = 0; i < 6; i++) {
    if (strcmp(word, keywords[i]) == 0)
      return 1;
  }
  return 0;
}

int main() {
  char input[100], word[20];
  int i = 0, j = 0;

  printf("Enter the statement: ");
  gets(input);

  while (input[i] != '\0') {
    if (isalpha(input[i])) {
      j = 0;
      while (isalnum(input[i])) {
        word[j++] = input[i++];
      }
      word[j] = '\0';

      if (isKeyword(word))
        printf("%s -> Keyword\n", word);
      else
        printf("%s -> Identifier\n", word);
    } else if (isdigit(input[i])) {
      j = 0;
      while (isdigit(input[i])) {
        word[j++] = input[i++];
      }
      word[j] = '\0';

      printf("%s -> Number\n", word);
    } else if (strchr("+-*/=", input[i])) {
      printf("%c -> Operator\n", input[i]);
      i++;
    } else if (strchr(";,()", input[i])) {
      printf("%c -> Special Symbol\n", input[i]);
      i++;
    } else {
      i++;
    }
  }

  return 0;
}