#include <ctype.h>
#include <stdio.h>

char productions[10][10];
char first[10];

int n;

void findFirst(char c, int pos) {
  int i;

  // If terminal
  if (!isupper(c)) {
    first[pos++] = c;
    return;
  }

  for (i = 0; i < n; i++) {
    if (productions[i][0] == c) {
      if (productions[i][2] == '$') {
        first[pos++] = '$'; // epsilon
      } else if (!isupper(productions[i][2])) {
        first[pos++] = productions[i][2];
      } else {
        findFirst(productions[i][2], pos);
      }
    }
  }
}

int main() {
  int i;
  char c;

  printf("Enter number of productions: ");
  scanf("%d", &n);

  printf("Enter productions (Example: E=TR):\n");
  for (i = 0; i < n; i++) {
    scanf("%s", productions[i]);
  }

  printf("Enter non-terminal to find FIRST: ");
  scanf(" %c", &c);

  findFirst(c, 0);

  printf("FIRST(%c) = { ", c);
  for (i = 0; first[i] != '\0'; i++) {
    printf("%c ", first[i]);
  }
  printf("}\n");

  return 0;
}