# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# Copyright (c) 2025-2026 Faculty of Physics, University of Warsaw
# Licensed under GPL-3.0-or-later

"""OpenBCI ReadManager — read, write and convert OBCI signal recordings."""

__version__ = "1.2.3"
