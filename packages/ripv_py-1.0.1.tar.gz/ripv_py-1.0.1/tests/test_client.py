"""Tests for the PersonalVault Python SDK."""

from __future__ import annotations

import time
from unittest.mock import patch

import httpx
import pytest
import pytest_asyncio  # noqa: F401 (ensures plugin is loaded)
import respx

import pv
from pv import (
    pv_async,
    init,
    PVAuthError,
    PVDeniedError,
    PVKeyNotFoundError,
    PVNotInitializedError,
)
from pv import client as _client

API_URL = "http://localhost:8923"
FAKE_KEY = "pvault_bk_testkey123"
MOCK_KEYS = {"OPENAI_API_KEY": "sk-test123", "DB_PASS": "secret456"}


@pytest.fixture(autouse=True)
def _reset_state(monkeypatch):
    """Reset SDK internal state before each test."""
    _client._key_cache.clear()
    _client._initialized = False
    _client._cache_expiry = 0.0
    _client._cache_ttl = 3600
    monkeypatch.setenv("PV_API_URL", API_URL)
    monkeypatch.delenv("PV_API_KEY", raising=False)
    yield


# ---------------------------------------------------------------------------
# PV_API_KEY missing
# ---------------------------------------------------------------------------

class TestMissingApiKey:
    def test_sync_init_raises(self):
        with pytest.raises(PVAuthError, match="PV_API_KEY not found"):
            init()

    @pytest.mark.asyncio
    async def test_async_raises(self):
        with pytest.raises(PVAuthError, match="PV_API_KEY not found"):
            await pv_async("ANY_KEY")


# ---------------------------------------------------------------------------
# Sync pv() before init
# ---------------------------------------------------------------------------

class TestNotInitialized:
    def test_pv_raises(self):
        with pytest.raises(PVNotInitializedError, match="not initialized"):
            pv("SOME_KEY")


# ---------------------------------------------------------------------------
# Key not found
# ---------------------------------------------------------------------------

class TestKeyNotFound:
    @respx.mock
    def test_sync_key_not_found(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(200, json={"keys": MOCK_KEYS})
        )
        init()
        with pytest.raises(PVKeyNotFoundError, match="MISSING"):
            pv("MISSING")

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_key_not_found(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(200, json={"keys": MOCK_KEYS})
        )
        with pytest.raises(PVKeyNotFoundError, match="MISSING"):
            await pv_async("MISSING")


# ---------------------------------------------------------------------------
# Successful retrieval
# ---------------------------------------------------------------------------

class TestSuccessfulRetrieval:
    @respx.mock
    def test_sync_flow(self, monkeypatch):
        """import pv; pv.init(); pv("KEY") pattern."""
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(200, json={"keys": MOCK_KEYS})
        )
        pv.init()
        assert pv("OPENAI_API_KEY") == "sk-test123"
        assert pv("DB_PASS") == "secret456"

    @respx.mock
    @pytest.mark.asyncio
    async def test_async_flow(self, monkeypatch):
        """from pv import pv_async; await pv_async("KEY") pattern."""
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(200, json={"keys": MOCK_KEYS})
        )
        assert await pv_async("OPENAI_API_KEY") == "sk-test123"
        assert await pv_async("DB_PASS") == "secret456"


# ---------------------------------------------------------------------------
# Cache expiry
# ---------------------------------------------------------------------------

class TestCacheExpiry:
    @respx.mock
    def test_expired_cache_raises_not_initialized(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(200, json={"keys": MOCK_KEYS})
        )
        init()
        assert pv("OPENAI_API_KEY") == "sk-test123"

        # Force cache expiry
        _client._cache_expiry = time.time() - 1
        with pytest.raises(PVNotInitializedError):
            pv("OPENAI_API_KEY")


# ---------------------------------------------------------------------------
# HTTP error handling
# ---------------------------------------------------------------------------

class TestHttpErrors:
    @respx.mock
    def test_401_raises_auth_error(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(
                401, json={"error": "Invalid or expired backend key"}
            )
        )
        with pytest.raises(PVAuthError, match="Invalid or expired"):
            init()

    @respx.mock
    def test_403_raises_denied_error(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(
                403, json={"error": "IP not in allowlist"}
            )
        )
        with pytest.raises(PVDeniedError, match="IP not in allowlist"):
            init()

    @respx.mock
    @pytest.mark.asyncio
    async def test_401_async(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(
                401, json={"error": "Invalid or expired backend key"}
            )
        )
        with pytest.raises(PVAuthError):
            await pv_async("ANY")

    @respx.mock
    @pytest.mark.asyncio
    async def test_403_async(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(403, json={"error": "Access denied"})
        )
        with pytest.raises(PVDeniedError):
            await pv_async("ANY")


# ---------------------------------------------------------------------------
# User-Agent header
# ---------------------------------------------------------------------------

class TestUserAgent:
    @respx.mock
    def test_sends_user_agent(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        route = respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(200, json={"keys": MOCK_KEYS})
        )
        init()
        request = route.calls[0].request
        assert request.headers["user-agent"] == "pv-python-sdk/1.0.0"


# ---------------------------------------------------------------------------
# Cache TTL env var
# ---------------------------------------------------------------------------

class TestCacheTTLConfig:
    @respx.mock
    def test_custom_ttl(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        _client._cache_ttl = 60  # 1 minute
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(200, json={"keys": MOCK_KEYS})
        )
        init()
        # Verify expiry is roughly 60s from now, not 3600s
        assert _client._cache_expiry < time.time() + 120


# ---------------------------------------------------------------------------
# Init is idempotent when cache is valid
# ---------------------------------------------------------------------------

class TestIdempotentInit:
    @respx.mock
    def test_init_only_fetches_once(self, monkeypatch):
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        route = respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(200, json={"keys": MOCK_KEYS})
        )
        init()
        init()
        assert route.call_count == 1


# ---------------------------------------------------------------------------
# Module is callable (import pv; pv("KEY"))
# ---------------------------------------------------------------------------

class TestCallableModule:
    @respx.mock
    def test_module_callable(self, monkeypatch):
        """Verify `import pv; pv.init(); pv('KEY')` works."""
        monkeypatch.setenv("PV_API_KEY", FAKE_KEY)
        respx.post(f"{API_URL}/api/backend/keys").mock(
            return_value=httpx.Response(200, json={"keys": MOCK_KEYS})
        )
        pv.init()
        # pv is the module, calling it should work
        assert pv("OPENAI_API_KEY") == "sk-test123"
        assert pv("DB_PASS") == "secret456"