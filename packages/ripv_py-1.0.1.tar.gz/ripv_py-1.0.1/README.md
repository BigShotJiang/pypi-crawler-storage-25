# PersonalVault Python SDK

Secure API key retrieval for Python backend applications.

## Installation

```bash
pip install ripv-py
```

## Quick Start

### Environment Variables

```bash
export PV_API_KEY="pvault_bk_..."       # Required - your backend key
export PV_API_URL="https://pv.sprkt.xyz"  # Optional - defaults to https://pv.sprkt.xyz
export PV_CACHE_TTL="3600"              # Optional - cache TTL in seconds (default: 3600)
```

### Synchronous (Django, Flask)

```python
import pv

# Initialize once at startup
pv.init()

# Call the module directly to retrieve keys
openai_key = pv("OPENAI_API_KEY")
db_password = pv("DB_PASS")
```

Or with named imports:

```python
from pv import init, pv

init()
openai_key = pv("OPENAI_API_KEY")
```

### Asynchronous (FastAPI, AIOHTTP)

```python
from pv import pv_async

# Auto-initializes on first call, then serves from cache
openai_key = await pv_async("OPENAI_API_KEY")
db_password = await pv_async("DB_PASS")
```

## API Reference

### `init() -> None`
Synchronously fetch and cache all allowed keys. Blocks until complete.

### `pv(key_name: str) -> str`
Synchronous cache lookup. Raises `PVNotInitializedError` if `init()` hasn't been called or cache has expired.

### `pv_async(key_name: str) -> str`
Async key retrieval. Automatically initializes/refreshes the cache when needed.

## Exceptions

| Exception | When |
|---|---|
| `PVAuthError` | `PV_API_KEY` missing, invalid, or expired |
| `PVDeniedError` | Server rejected request (IP allowlist, etc.) |
| `PVKeyNotFoundError` | Key not in vault or not allowed for this backend key |
| `PVNotInitializedError` | `pv()` called before `init()` or cache expired |

## Framework Examples

### FastAPI

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from pv import pv_async, pv

@asynccontextmanager
async def lifespan(app: FastAPI):
    await pv_async("DB_URL")  # warm the cache
    yield

app = FastAPI(lifespan=lifespan)

@app.get("/")
async def root():
    return {"db": pv("DB_URL")}
```

### Flask

```python
from flask import Flask
from pv import init, pv

app = Flask(__name__)
init()  # fetch keys at import time

@app.route("/")
def index():
    return {"db": pv("DB_URL")}
```

### Django (settings.py)

```python
from pv import init, pv

init()

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "PASSWORD": pv("DB_PASS"),
    }
}
```
