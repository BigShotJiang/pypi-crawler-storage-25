"""Core PersonalVault SDK client with sync and async key retrieval."""

from __future__ import annotations

import os
import time
from typing import Dict, List, Optional

import httpx

__all__ = [
    "pv",
    "pv_async",
    "init",
    "PVAuthError",
    "PVDeniedError",
    "PVKeyNotFoundError",
    "PVNotInitializedError",
]

_SDK_VERSION = "1.0.1"
_USER_AGENT = f"pv-python-sdk/{_SDK_VERSION}"


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class PVAuthError(Exception):
    """Raised when the PV_API_KEY is missing, invalid, or expired."""


class PVDeniedError(Exception):
    """Raised when the server rejects the request (403)."""


class PVKeyNotFoundError(Exception):
    """Raised when a requested key is not present in the vault cache."""


class PVNotInitializedError(Exception):
    """Raised when pv() is called before the SDK has been initialized."""


# ---------------------------------------------------------------------------
# Internal state
# ---------------------------------------------------------------------------

_key_cache: Dict[str, str] = {}
_initialized: bool = False
_cache_expiry: float = 0.0
_cache_ttl: int = int(os.environ.get("PV_CACHE_TTL", "3600"))


def _is_cache_valid() -> bool:
    return _initialized and time.time() < _cache_expiry


def _get_api_key() -> str:
    key = os.environ.get("PV_API_KEY")
    if not key:
        raise PVAuthError(
            "PersonalVault: PV_API_KEY not found in environment.\n"
            "Generate one at https://pv.sprkt.xyz/dashboard -> Backend Keys"
        )
    return key


def _get_api_url() -> str:
    return os.environ.get("PV_API_URL", "https://pv.sprkt.xyz")


def _build_headers(api_key: str) -> Dict[str, str]:
    return {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}",
        "User-Agent": _USER_AGENT,
    }


def _handle_error_response(status_code: int, data: dict) -> None:
    error_msg = data.get("error", "")
    if status_code == 401:
        raise PVAuthError(error_msg or "Invalid or expired backend key")
    if status_code == 403:
        raise PVDeniedError(error_msg or "Access denied")
    raise Exception(error_msg or f"Request failed with status {status_code}")


def _apply_fetched_keys(keys: Dict[str, str]) -> None:
    global _key_cache, _initialized, _cache_expiry
    _key_cache = keys
    _initialized = True
    _cache_expiry = time.time() + _cache_ttl


# ---------------------------------------------------------------------------
# Sync fetch (uses httpx.Client)
# ---------------------------------------------------------------------------

def _fetch_keys_sync(key_names: Optional[List[str]] = None) -> Dict[str, str]:
    api_key = _get_api_key()
    url = f"{_get_api_url()}/api/backend/keys"
    body: dict = {}
    if key_names:
        body["keyNames"] = key_names

    with httpx.Client() as client:
        resp = client.post(url, json=body, headers=_build_headers(api_key))

    if resp.status_code != 200:
        try:
            data = resp.json()
        except Exception:
            data = {}
        _handle_error_response(resp.status_code, data)

    return resp.json()["keys"]


# ---------------------------------------------------------------------------
# Async fetch (uses httpx.AsyncClient)
# ---------------------------------------------------------------------------

async def _fetch_keys_async(key_names: Optional[List[str]] = None) -> Dict[str, str]:
    api_key = _get_api_key()
    url = f"{_get_api_url()}/api/backend/keys"
    body: dict = {}
    if key_names:
        body["keyNames"] = key_names

    async with httpx.AsyncClient() as client:
        resp = await client.post(url, json=body, headers=_build_headers(api_key))

    if resp.status_code != 200:
        try:
            data = resp.json()
        except Exception:
            data = {}
        _handle_error_response(resp.status_code, data)

    return resp.json()["keys"]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def init() -> None:
    """Synchronously initialize the SDK by fetching keys from PersonalVault.

    Use this in synchronous frameworks (Django, Flask) that don't have an
    event loop. Blocks until the fetch completes.

    Raises:
        PVAuthError: If PV_API_KEY is missing or invalid.
        PVDeniedError: If the server rejects the request.
    """
    if _is_cache_valid():
        return
    keys = _fetch_keys_sync()
    _apply_fetched_keys(keys)


def pv(key_name: str) -> str:
    """Synchronously retrieve a key from the in-memory cache.

    The SDK must be initialized first via ``init()`` or ``pv_async()``.

    Args:
        key_name: The name of the key to retrieve.

    Returns:
        The key value as a string.

    Raises:
        PVNotInitializedError: If the SDK has not been initialized or the
            cache has expired.
        PVKeyNotFoundError: If the key is not in the cache.
    """
    if not _is_cache_valid():
        raise PVNotInitializedError(
            "PersonalVault: not initialized. "
            "Use pv_async() for the first call or call init()."
        )
    value = _key_cache.get(key_name)
    if value is None:
        raise PVKeyNotFoundError(
            f"Key '{key_name}' not found in vault or not allowed for this backend key"
        )
    return value


async def pv_async(key_name: str) -> str:
    """Asynchronously retrieve a key, initializing the SDK if needed.

    On the first call (or after cache expiry), this fetches keys from the
    PersonalVault server. Subsequent calls return from the in-memory cache.

    Args:
        key_name: The name of the key to retrieve.

    Returns:
        The key value as a string.

    Raises:
        PVAuthError: If PV_API_KEY is missing or invalid.
        PVDeniedError: If the server rejects the request.
        PVKeyNotFoundError: If the key is not in the fetched results.
    """
    if not _is_cache_valid():
        keys = await _fetch_keys_async()
        _apply_fetched_keys(keys)

    value = _key_cache.get(key_name)
    if value is None:
        raise PVKeyNotFoundError(
            f"Key '{key_name}' not found in vault or not allowed for this backend key"
        )
    return value