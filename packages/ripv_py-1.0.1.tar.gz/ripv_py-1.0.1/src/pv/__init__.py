"""PersonalVault Python SDK - secure API key retrieval for backend applications.

Usage (sync):
    import pv
    pv.init()
    openai_key = pv("OPENAI_API_KEY")

Usage (async):
    from pv import pv_async
    openai_key = await pv_async("OPENAI_API_KEY")
"""

import types
import sys

from pv.client import (
    pv,
    pv_async,
    init,
    PVAuthError,
    PVDeniedError,
    PVKeyNotFoundError,
    PVNotInitializedError,
)

__all__ = [
    "pv",
    "pv_async",
    "init",
    "PVAuthError",
    "PVDeniedError",
    "PVKeyNotFoundError",
    "PVNotInitializedError",
]

__version__ = "1.0.1"


class _CallableModule(types.ModuleType):
    """Makes ``import pv; pv("KEY")`` work by forwarding calls to ``pv.pv``."""

    def __call__(self, key_name: str) -> str:
        return pv(key_name)


# Replace this module's class so the module itself is callable.
_self = sys.modules[__name__]
_self.__class__ = _CallableModule