raise ImportError(
    "This package name was reserved to prevent typosquatting against "
    "the 'mareforma' project. Install the canonical package instead: "
    "pip install mareforma"
)
