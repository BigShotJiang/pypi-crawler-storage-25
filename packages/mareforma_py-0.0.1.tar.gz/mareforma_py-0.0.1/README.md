# Defensive name reservation

This PyPI name was reserved by the Mareforma project to prevent
typosquatting. The package you want is `mareforma`:

    pip install mareforma

If you intended to publish under this name and would like to take it
over for a legitimate use, please open a discussion at
<https://github.com/mareforma/mareforma/discussions>.
