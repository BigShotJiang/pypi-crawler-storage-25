#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 #
#                                                                       #
#########################################################################

import sys

from .squidientbasereport import SquidientBaseReport


class SquidientCaseReport(SquidientBaseReport):

    # _____________________________________
    def __init__(self, case):

        super().__init__(case)

    # _____________________________________
    def init_test(self):

        self._test = {
            "name": self._json["name"],
            "files": [],
            "hostname": "unknown",
            "env": {},
        }

    # _____________________________________
    def _stringify_status(self, value):

        if isinstance(value, bool):
            return "OK" if value else "FAIL"

        return str(value)

    # _____________________________________
    def _build_table(self, title, headers, rows):

        widths = []

        for index, header in enumerate(headers):
            column_values = [header] + [row[index] for row in rows]
            widths.append(max(len(value) for value in column_values))

        def sep():
            return "+-" + "-+-".join("-" * width for width in widths) + "-+"

        def fmt(row):
            return "| " + " | ".join(
                row[index].ljust(widths[index]) for index in range(len(headers))
            ) + " |"

        lines = [title, "=" * len(title), sep(), fmt(headers), sep()]

        for row in rows:
            lines.append(fmt(row))

        lines.append(sep())

        return "\n".join(lines)

    # _____________________________________
    def files_report_console(self):

        headers = [
            "file",
            "method",
            "tolerance",
            "maxAbs",
            "maxRel",
            "maxError",
            "differences",
            "total",
            "error",
            "status",
        ]

        rows = []

        for file_test in self._test.get("files", []):
            rows.append([
                str(file_test.get("file", "")),
                str(file_test.get("method", "")),
                str(file_test.get("tolerance", "")),
                str(file_test.get("maxAbs", "")),
                str(file_test.get("maxRel", "")),
                str(file_test.get("maxError", "")),
                str(file_test.get("differences", "")),
                str(file_test.get("total", "")),
                str(file_test.get("error", "")),
                self._stringify_status(file_test.get("status", "")),
            ])

        return self._build_table(str(self._test.get("name", "?")), headers, rows)

    # _____________________________________
    def run(self):

        self.open_json()
        self.init_test()
        self.validate_files()
        self.save_json()

        print(self.files_report_console())


def main(argv=None):

    if argv is None:
        argv = sys.argv

    if len(argv) < 2:
        print("Usage: sqreport [case]")
        return 1

    report = SquidientCaseReport(argv[1])
    report.run()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())