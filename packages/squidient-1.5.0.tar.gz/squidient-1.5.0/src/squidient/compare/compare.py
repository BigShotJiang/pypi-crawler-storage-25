#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        # 
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################
from .methods.absolute import Absolute
from .methods.close import Close
from .methods.power import Power
from .methods.relative import Relative
from .methods.diff import Diff
from .methods.l1norm import L1Norm
from .methods.l1relative import L1Relative
from .methods.l2norm import L2Norm
from .methods.l2relative import L2Relative
from .methods.linfnorm import LInfNorm
from .methods.linfrelative import LInfRelative
from ..utils.utils import *

methods = {
    "diff": Diff,
    "absolute": Absolute,
    "relative": Relative,
    "close": Close,
    "power": Power,
    "l1norm": L1Norm,
    "l1relative": L1Relative,
    "l2norm": L2Norm,
    "l2relative": L2Relative,
    "linfnorm": LInfNorm,
    "linfrelative": LInfRelative,
}

class Compare:

    # _____________________________________
    def __init__(self, base, test, method, tolerance, rows=None, cols=None):
        logger.debug("Comparing files base: " + base + " and test: " + test)
        self._base = base
        self._test = test
        self._method = method
        self._tolerance = tolerance
        self._status = True
        self._error = "OK"
        self._comparisonMethod = None
        self._rows = rows
        self._cols = cols

    def compare(self):
        if self._status:
            cls = methods.get(self._method)
            if cls is None:
                raise ValueError(f"Unknown method: {self._method}")

            self._comparisonMethod = cls(
                self._base,
                self._test,
                self._method,
                self._tolerance,
                rows=self._rows,
                cols=self._cols,
            )
        if self._comparisonMethod.read():
            self._comparisonMethod.compare_all()
        return self._comparisonMethod.get_res()

    @property
    def comparisonMethod(self):
        return self._comparisonMethod


