#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        #
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################



from .scalartolerance import *


class Absolute(ScalarTolerance):

    def __init__(self, ref, test, method, tolerance, rows=None, cols=None):
        super().__init__(ref, test, method, tolerance, rows, cols)

    def _test_tolerance_format(self):
        try:
            self._tolerance = float(self._tolerance)
        except:
            logger.warning("Tolerance parameter is not a float")
            self._status = False
            self._error = "parameter"

    def compare_pair(self, svref : str, svtest : str) -> bool:
        vref = float(svref)
        vtest = float(svtest)
        self._compute_current_abs_and_rel(vref, vtest)
        self._compute_max_and_min_values(vref, vtest)
        self._maxError = self._maxAbs
        self._currentError = self._currentAbs
        return self._currentAbs <= self._tolerance

    def format_tolerance(self):
        return self._tolerance
