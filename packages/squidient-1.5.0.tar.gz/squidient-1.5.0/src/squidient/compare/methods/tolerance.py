#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        # 
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################



from ...utils.utils import *
import re
from abc import ABC, abstractmethod


class Tolerance(ABC):

    # _____________________________________
    def __init__(self, ref, test, method, tolerance, rows=None, cols=None):
        logger.debug("Comparing files ref: " + ref + " and test: " + test)
        self._ref = ref
        self._test = test
        self._method = method
        self._tolerance = tolerance
        self._status = True
        self._error = "OK"
        self._refContent = []
        self._testContent = []
        self._differences = 0
        self._total = -1
        self._rows = rows
        self._cols = cols
        self._maxAbs = 0
        self._maxRel = 0
        self._maxError = None
        self._maxValue = None
        self._minValue = None
        self._test_tolerance_format()
        self._currentAbs = None
        self._currentRel = None
        self._currentError = None
        self._total = 0

    def compare(self):
        if self._status:
            self.compare_all()
        return self.get_res()

    def get_res(self):
        res = {}
        res["tolerance"] = self.format_tolerance()
        res["maxError"] = self._maxError
        res["maxAbs"] = self._maxAbs
        res["maxRel"] = self._maxRel
        res["differences"] = self._differences
        res["total"] = self._total
        res["status"] = self._status
        res["error"] = self._error
        return res

    @abstractmethod
    def _test_tolerance_format(self):
        pass

    @abstractmethod
    def format_tolerance(self):
        pass

    # _____________________________________
    def read(self):
        """
            Read the input files for comparison and take only
            the data to compare
        """

        logger.debug("Reading base: " + self._ref)
        with open(self._ref) as f:
            for line in f:
                if line[0] == '#':
                    continue
                values = re.findall(r"-?\d\.\d{8}E[+-]\d{3}", line)
                if values != []:
                    self._refContent.append(values)

        logger.debug("Reading test: " + self._test)
        with open(self._test) as f:
            for line in f:
                if line[0] == '#':
                    continue
                values = re.findall(r"-?\d\.\d{8}E[+-]\d{3}", line)
                if values != []:
                    self._testContent.append(values)

        if self._rows is None:
            logger.debug("Computing rows")
            rows = range(len(self._refContent))
            logger.debug("There are " + str(len(self._refContent)) + " rows")
            if len(self._refContent) == 0:
                logger.warning("Base does not have rows!")
                self._status = False
                self._error = "empty base"

        else:
            logger.debug("Getting rows from json")
            rows = self._rows
        cols = {}
        for r in rows:
            if int(r) > len(self._refContent) - 1:
                logger.warning("Row out of range: " + str(r))
                self._status = False
                self._error = "lines"
                return False
            if self._cols is None:
                cols[r] = range(len(self._refContent[r]))
            else:
                cols[r] = self._cols
                to_remove = []
                for c in cols[r]:
                    if int(c) > len(self._refContent[r]) - 1:
                        logger.warning("Column out of range :" + str(c) + ", line :" + str(r))
                        to_remove.append(c)
                for t in to_remove:
                    cols[r].remove(t)
        if self._rows is None and self._cols is None:
            if len(self._refContent) == len(self._testContent):
                for base, test in zip(self._refContent, self._testContent):
                    if len(base) != len(test):
                        logger.warning("Files do not have the same number of columns")
                        self._status = False
                        self._error = "columns"
                        return False
            else:
                logger.warning("Files do not have the same number of lines")
                self._status = False
                self._error = "lines"
                return False
        self._rows = rows
        self._cols = cols
        return self._status


    @abstractmethod
    def compare_all(self):
        pass

    @abstractmethod
    def compare_pair(self, vref, vtest):
        pass

    def get_refcontent(self):
        return self._refContent

    def get_testcontent(self):
        return self._testContent

    def _compute_max_error(self):
        if self._maxError is None or float(self._currentError) >= float(self._maxError):
            self._maxError = self._currentError

    def get_current_abs(self):
        return self._currentAbs

    def get_current_rel(self):
        return self._currentRel

    def get_current_error(self):
        return self._currentError
