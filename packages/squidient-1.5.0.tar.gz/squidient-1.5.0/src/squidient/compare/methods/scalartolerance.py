#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        # 
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################



from .tolerance import *
from abc import abstractmethod


class ScalarTolerance(Tolerance):

    # _____________________________________
    def __init__(self, ref, test, method, tolerance, rows=None, cols=None):
        super().__init__(ref, test, method, tolerance, rows, cols)

    # _____________________________________
    def compare_all(self):
        """
            Compare all the values base vs test.
        """
        # Comparison
        for i in self._rows:
            for j in self._cols[i]:
                self._total += 1
                if not (self.compare_pair(self._refContent[i][j],
                                          self._testContent[i][j])):
                    self._differences = self._differences + 1
        # Result
        if self._differences > 0:
            self._status = False
            self._error = "tolerance"

    # _____________________________________
    @abstractmethod
    def compare_pair(self, vref : str, vtest : str) -> bool:
        pass

    def _compute_current_abs_and_rel(self, vref, vtest):
        self._currentAbs = abs(float(vref) - float(vtest))
        denom = float(vref)
        if denom == 0.0:
            denom = float(vtest)
            if denom == 0.0:
                self._currentRel = 0
            else:
                self._currentRel = (abs(float(vref) - float(vtest)) / abs(denom))
        else:
            self._currentRel = (abs(float(vref) - float(vtest)) / abs(denom))
        self._update_max_abs_and_rel()

    # _____________________________________
    def _compute_max_and_min_values(self, vref, vtest):
        if self._maxValue is None or max(float(vref), float(vtest)) > self._maxValue:
            self._maxValue = max(float(vref), float(vtest))
        if self._minValue is None or min(float(vref), float(vtest)) < self._minValue:
            self._minValue = min(float(vref), float(vtest))

    #_____________________________________
    def _update_max_abs_and_rel(self):
        if self._maxAbs is None or self._currentAbs > self._maxAbs:
                self._maxAbs = self._currentAbs
        if self._maxRel is None or self._currentRel > self._maxRel:
            self._maxRel = self._currentRel


