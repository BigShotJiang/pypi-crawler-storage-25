#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        #
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################


import math

from .scalartolerance import *


class Power(ScalarTolerance):

    def __init__(self, ref, test, method, tolerance, rows=None, cols=None):
        super().__init__(ref, test, method, tolerance, rows, cols)


    def _test_tolerance_format(self):
        try:
            self._tolerance = int(self._tolerance)
        except:
            logger.warning("Tolerance parameter is not an integer")
            self._status = False
            self._error = "parameter"

    def compare_pair(self, vref : float, vtest : float) -> bool:
        self._compute_current_abs_and_rel(vref, vtest)
        self._compute_current_error(vref, vtest)
        self._compute_max_and_min_values(vref, vtest)
        self._compute_max_error()
        return float(self._currentError) >= self._tolerance

    def format_tolerance(self):
        return self._tolerance

    def _compute_current_error(self, svref: str, svtest: str) -> None:
        # Power
        exp1 = float("1.0" + svref[-5:])
        fval1 = float(svref) / exp1
        fval2 = float(svtest) / exp1

        if self._currentAbs == 0:
            self._currentError = "inf"
        else:
            diff = abs(fval1 - fval2)
            if diff == 0:
                self._currentError = "inf"
            elif diff > 1:
                self._currentError = -1
            else:
                self._currentError = max(-1, math.floor(-math.log10(diff)))

    def _compute_max_error(self):
        if self._maxError is None or isinstance(self._currentError, int) and float(self._currentError) < float(self._maxError):
            self._maxError = self._currentError

