#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        #
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################



from .scalartolerance import *


class Diff(ScalarTolerance):

    def __init__(self, ref, test, method, tolerance, rows=None, cols=None):
        super().__init__(ref, test, method, tolerance, rows, cols)

    def _test_tolerance_format(self):
        pass

    def read(self):
        self._total = 0

    def compare_pair(self, vref : str, vtest : str) -> bool:
        pass

    def format_tolerance(self):
        return self._tolerance

    def compare_all(self):
        self._status = command("diff " + self._ref + " " + self._test)
        if not self._status:
            self._error = "diff"
