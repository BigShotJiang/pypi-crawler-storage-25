#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        #
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################



from .vectortolerance import *


class L1Relative(VectorTolerance):

    def __init__(self, ref, test, method, tolerance, rows=None, cols=None):
        super().__init__(ref, test, method, tolerance, rows, cols)

    def _test_tolerance_format(self):
        try:
            self._tolerance = float(self._tolerance)
        except:
            logger.warning("Tolerance parameter is not a float")
            self._status = False
            self._error = "parameter"

    def compare_pair(self, vref : List[float], vtest : List[float]) -> bool:
        self._compute_current_abs_and_rel(vref, vtest)
        self._compute_current_error(vref, vtest)
        self._compute_max_and_min_values(vref, vtest)
        self._compute_max_error()
        return self._currentError <= self._tolerance

    def format_tolerance(self):
        return self._tolerance

    def _compute_current_error(self, vref: List[float], vtest: List[float]) -> None:
        num = sum(abs(a - b) for a, b in zip(vref, vtest))
        den = sum(abs(a) for a in vref)
        self._currentError = num / den if den != 0 else (0.0 if num == 0 else float("inf"))