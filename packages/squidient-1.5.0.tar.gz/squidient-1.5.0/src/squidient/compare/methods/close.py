#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        #
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################



import math

from .scalartolerance import *


class Close(ScalarTolerance):

    def __init__(self, ref, test, method, tolerance, rows=None, cols=None):
        self._atol = 0.0
        self._rtol = 0.0
        self._currentClose = 0.0
        super().__init__(ref, test, method, tolerance, rows, cols)

    def _test_tolerance_format(self):
        if "atol" not in self._tolerance or "rtol" not in self._tolerance:
            logger.warning("Tolerance parameter does not contain 'atol' and 'rtol'")
            self._status = False
            self._error = "parameter"
        else:
            try:
                self._rtol = float(self._tolerance["rtol"])
            except:
                logger.warning("'rtol' parameter is not a float")
                self._status = False
                self._error = "parameter"
            try:
                self._atol = float(self._tolerance["atol"])
            except:
                logger.warning("'atol' parameter is not a float")
                self._status = False
                self._error = "parameter"

    def format_tolerance(self):
        return f'atol={self._atol}, rtol={self._rtol}'

    def compare_pair(self, svref : str, svtest : str) -> bool:
        vref = float(svref)
        vtest = float(svtest)
        self._compute_current_abs_and_rel(vref, vtest)
        self._compute_current_close(vref, vtest)
        self._currentError = self._currentAbs
        self._compute_max_and_min_values(vref, vtest)
        self._compute_max_error()
        return self._currentAbs <= self._currentClose

    def _compute_current_close(self, vref: float, vtest: float) -> None:
        self._currentClose = self._atol + self._rtol * max(abs(vref), abs(vtest))
