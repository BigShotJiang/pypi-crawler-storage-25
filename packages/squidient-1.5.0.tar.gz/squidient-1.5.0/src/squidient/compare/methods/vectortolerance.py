from typing import List

from .tolerance import *
from abc import abstractmethod


class VectorTolerance(Tolerance):

    def __init__(self, ref, test, method, tolerance, rows=None, cols=None):
        super().__init__(ref, test, method, tolerance, rows, cols)
        self._currentAbs = []
        self._currentRel = []

    def compare_all(self):
        for i in self._rows:
            self._total += 1
            row_index = int(i)
            cols = self._cols[i]

            vref = [
                float(self._refContent[row_index][int(j)])
                for j in cols
            ]

            vtest = [
                float(self._testContent[row_index][int(j)])
                for j in cols
            ]

            if not self.compare_pair(vref, vtest):
                self._differences += 1

        if self._differences > 0:
            self._status = False
            self._error = "tolerance"

    @abstractmethod
    def compare_pair(self, vref: List[float], vtest: List[float]) -> bool:
        pass

    def _compute_current_abs_and_rel(self, vref: List[float], vtest: List[float]):
        self._currentAbs = []
        self._currentRel = []

        for vrefi, vtesti in zip(vref, vtest):
            abs_error = abs(vrefi - vtesti)
            self._currentAbs.append(abs_error)

            denom = vrefi
            if denom == 0.0:
                denom = vtesti

            if denom == 0.0:
                rel_error = 0.0
            else:
                rel_error = abs_error / abs(denom)

            self._currentRel.append(rel_error)

        self._update_max_abs_and_rel()

    def _compute_max_and_min_values(self, vref: List[float], vtest: List[float]):
        for vrefi, vtesti in zip(vref, vtest):
            current_max = max(vrefi, vtesti)
            current_min = min(vrefi, vtesti)

            if self._maxValue is None or current_max > self._maxValue:
                self._maxValue = current_max

            if self._minValue is None or current_min < self._minValue:
                self._minValue = current_min

    def _update_max_abs_and_rel(self):
        if self._currentAbs:
            current_max_abs = max(self._currentAbs)
            if self._maxAbs is None or current_max_abs > self._maxAbs:
                self._maxAbs = current_max_abs

        if self._currentRel:
            current_max_rel = max(self._currentRel)
            if self._maxRel is None or current_max_rel > self._maxRel:
                self._maxRel = current_max_rel

    def get_current_abs(self) -> List[float]:
        return self._currentAbs

    def get_current_rel(self) -> List[float]:
        return self._currentRel

    def get_current_error(self):
        return self._currentError