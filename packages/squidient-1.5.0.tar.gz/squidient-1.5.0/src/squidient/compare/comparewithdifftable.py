#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        #
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################

from typing import Any, Dict, List, Optional, Sequence, Union

from .compare import Compare
from .methods.scalartolerance import ScalarTolerance
from .methods.tolerance import Tolerance
from .methods.vectortolerance import VectorTolerance


class CompareWithDiffTable(Compare):
    """
    Extends Compare to extract and print only differing entries in a console-friendly table.
    """

    def __init__(
        self,
        base,
        test,
        method,
        tolerance,
        rows=None,
        cols=None,
    ):
        super().__init__(base, test, method, tolerance, rows=rows, cols=cols)
        self._diff_entries: List[Dict[str, Any]] = []
        self._refcontent = None
        self._testcontent = None

    def compare(self):
        """
        Run the comparison and, for numeric methods, collect only failing entries.
        """
        result = super().compare()
        self._refcontent = self._comparisonMethod.get_refcontent()
        self._testcontent = self._comparisonMethod.get_testcontent()

        if (
            result.get("status") is False
            and isinstance(self._comparisonMethod, Tolerance)
            and self._method != "diff"
            and self._can_collect_diff_entries()
        ):
            self._collect_diff_entries()

        return result

    def get_diff_entries(self) -> List[Dict[str, Any]]:
        return list(self._diff_entries)



    def _can_collect_diff_entries(self) -> bool:
        """
        Check whether the class has enough information to collect entry-level diffs.
        """
        return (
            self._refcontent is not None
            and self._testcontent is not None
            and self._rows is not None
            and self._cols is not None
        )

    def _collect_diff_entries(self):
        """
        Collect only the entries that fail the comparison, along with useful metrics.
        """
        self._diff_entries = []

        if isinstance(self._comparisonMethod, ScalarTolerance):
            for row_index in self._rows:
                for col_index in self._cols[row_index]:
                    ref_value = self._refcontent[row_index][col_index]
                    test_value = self._testcontent[row_index][col_index]

                    if not self._comparisonMethod.compare_pair(ref_value, test_value):
                        self._diff_entries.append(
                            self._build_diff_entry(
                                row=row_index,
                                col=col_index,
                                ref=ref_value,
                                test=test_value,
                            )
                        )

        elif isinstance(self._comparisonMethod, VectorTolerance):
            for row_index in self._rows:
                ref_value = self._refcontent[row_index]
                test_value = self._testcontent[row_index]

                if not self._comparisonMethod.compare_pair(ref_value, test_value):
                    self._diff_entries.append(
                        self._build_diff_entry(
                            row=row_index,
                            ref=ref_value,
                            test=test_value,
                        )
                    )

    def _build_diff_entry(
        self,
        row: int,
        ref: Any,
        test: Any,
        col: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Build a normalized diff entry dictionary.
        """
        entry = {
            "row": int(row),
            "ref": ref,
            "test": test,
            "abs": self._comparisonMethod.get_current_abs(),
            "rel": self._comparisonMethod.get_current_rel(),
            "error": self._comparisonMethod.get_current_error(),
        }

        if col is not None:
            entry["col"] = int(col)

        return entry

    def build_numeric_diff_table(
        self,
        title: str,
        result: Dict[str, Any],
        max_rows: int,
    ) -> str:
        """
        Build the output table for numeric comparison failures.
        """
        entries = self.get_diff_entries()

        if not entries:
            return _build_summary_table(title, "FAIL", result)

        has_col = any("col" in entry for entry in entries)

        if has_col:
            headers = ["row", "col", "ref", "test", "abs", "rel", "error"]
            table_rows = [
                [
                    str(entry["row"]),
                    str(entry.get("col", "")),
                    str(entry["ref"]),
                    str(entry["test"]),
                    _safe_float_str(entry["abs"]),
                    _safe_float_str(entry["rel"]),
                    str(entry["error"]),
                ]
                for entry in entries[:max_rows]
            ]
        else:
            headers = ["row", "ref", "test", "abs", "rel", "error"]
            table_rows = [
                [
                    str(entry["row"]),
                    str(entry["ref"]),
                    str(entry["test"]),
                    _safe_float_str(entry["abs"]),
                    _safe_float_str(entry["rel"]),
                    str(entry["error"]),
                ]
                for entry in entries[:max_rows]
            ]

        if len(entries) > max_rows:
            overflow_row = ["..."] * (len(headers) - 1) + [f"+{len(entries) - max_rows} more"]
            table_rows.append(overflow_row)

        return _ascii_table(
            f"{title}  => FAIL: showing only failing entries",
            headers,
            table_rows,
        )

    def build_text_diff_table(
        self,
        title: str,
        ref_path: str,
        test_path: str,
        max_rows: int,
    ) -> str:
        """
        Build the output table for plain text diff failures.
        """
        try:
            base_lines = _read_lines(ref_path)
            test_lines = _read_lines(test_path)
        except Exception as exc:
            return _ascii_table(
                title,
                ["status", "error"],
                [["FAIL", f"diff-read: {exc}"]],
            )

        diff_rows = _collect_line_differences(base_lines, test_lines, max_rows)

        return _ascii_table(
            f"{title}  => FAIL: showing differing lines (simple diff)",
            ["line", "base", "test"],
            diff_rows if diff_rows else [["-", "-", "-"]],
        )


def _build_summary_table(
    title: str,
    status: str,
    result: Dict[str, Any],
) -> str:
    """
    Build a summary table for comparison results.
    """
    return _ascii_table(
        title,
        ["status", "error", "differences", "total", "maxAbs", "maxRel", "maxError"],
        [[
            status,
            str(result.get("error", "OK" if status == "OK" else "")),
            str(result.get("differences", 0 if status == "OK" else "")),
            str(result.get("total", 0 if status == "OK" else "")),
            _safe_float_str(result.get("maxAbs", 0 if status == "OK" else "")),
            _safe_float_str(result.get("maxRel", 0 if status == "OK" else "")),
            str(result.get("maxError", 0 if status == "OK" else "")),
        ]],
    )


def _read_lines(path: str) -> List[str]:
    """
    Read a text file as UTF-8 with replacement for undecodable characters.
    """
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        return handle.readlines()


def _collect_line_differences(
    base_lines: List[str],
    test_lines: List[str],
    max_rows: int,
) -> List[List[str]]:
    """
    Collect differing lines using a simple positional comparison.
    """
    max_length = max(len(base_lines), len(test_lines))
    diff_rows: List[List[str]] = []

    for index in range(max_length):
        base_line = base_lines[index].rstrip("\n") if index < len(base_lines) else "<NO LINE>"
        test_line = test_lines[index].rstrip("\n") if index < len(test_lines) else "<NO LINE>"

        if base_line != test_line:
            diff_rows.append([str(index), base_line[:120], test_line[:120]])
            if len(diff_rows) >= max_rows:
                break

    if len(diff_rows) == max_rows and max_length > max_rows:
        diff_rows.append(["...", "...", "..."])

    return diff_rows


def _ascii_table(title: str, headers: List[str], rows: List[List[str]]) -> str:
    """
    Build a plain ASCII table.
    """
    widths = [len(header) for header in headers]

    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))

    def separator() -> str:
        return "+-" + "-+-".join("-" * width for width in widths) + "-+"

    def format_row(row: List[str]) -> str:
        return "| " + " | ".join(
            row[i].ljust(widths[i]) for i in range(len(headers))
        ) + " |"

    output = [
        title,
        "=" * len(title),
        separator(),
        format_row(headers),
        separator(),
    ]

    for row in rows:
        output.append(format_row(row))

    output.append(separator())

    return "\n".join(output)


def _safe_float_str(value: Any) -> str:
    """
    Format floats compactly, and fall back to str() for non-numeric values.
    """
    try:
        return f"{float(value):.6g}"
    except Exception:
        return str(value)


def print_diff_table_for_file(
        ref_path: str,
        test_path: str,
        method: str,
        tolerance: Union[str, float, int, Dict[str, float]],
        rows: Optional[Sequence[int]] = None,
        cols: Optional[Sequence[int]] = None,
        max_rows: int = 200,
) -> str:
    """
    Return a console-friendly table.

    - If comparison passes: return a short OK message.
    - If FAIL:
        * numeric methods: show only failing entries
        * diff method: show a compact diff-like line list
    """
    cmp_obj = CompareWithDiffTable(
        ref_path,
        test_path,
        method,
        tolerance,
        rows=rows,
        cols=cols,
    )
    result = cmp_obj.compare()

    tol_str = str(cmp_obj.comparisonMethod.format_tolerance())
    title = f"{test_path}  (method={method}, tolerance={tol_str})"

    if result.get("status", True):
        return _build_summary_table(title, "OK", result)

    if method != "diff":
        return cmp_obj.build_numeric_diff_table(title, result, max_rows)

    return cmp_obj.build_text_diff_table(title, ref_path, test_path, max_rows)
