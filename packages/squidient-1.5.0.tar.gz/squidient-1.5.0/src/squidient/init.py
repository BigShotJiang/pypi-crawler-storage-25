from __future__ import annotations

import os
import shutil
from pathlib import Path
from typing import Union
import squidient

try:
    from importlib.resources import files as ir_files
except ImportError:
    from importlib_resources import files as ir_files  # Python < 3.9


def _walk_traversable(root):
    stack = [(root, Path())]
    while stack:
        node, rel = stack.pop()
        if node.is_dir():
            for child in node.iterdir():
                stack.append((child, rel / child.name))
        else:
            yield node, rel


def copy_packaged_tree(
    package_module,
    resource_dir: str,
    dst_dir: Union[str, Path],
    overwrite: bool = False,
) -> None:
    """
    Copy a packaged resource directory recursively to dst_dir,
    preserving files and subdirectories.
    """
    dst_root = Path(dst_dir)
    dst_root.mkdir(parents=True, exist_ok=True)

    pkg_root = ir_files(package_module)
    root = pkg_root.joinpath(resource_dir)

    if not root.is_dir():
        raise FileNotFoundError(
            f"Resource directory '{resource_dir}' not found in package "
            f"'{package_module.__name__}'"
        )

    _copy_traversable_tree(root, dst_root, overwrite=overwrite)


def _copy_traversable_tree(src, dst: Path, overwrite: bool = False) -> None:
    """
    Recursively copy a Traversable tree to a filesystem path.
    """
    entries = list(src.iterdir())

    if not entries:
        return

    for entry in entries:
        out = dst / entry.name

        if entry.is_dir():
            out.mkdir(parents=True, exist_ok=True)
            _copy_traversable_tree(entry, out, overwrite=overwrite)
        else:
            out.parent.mkdir(parents=True, exist_ok=True)

            if out.exists() and not overwrite:
                continue

            with entry.open("rb") as src_f, out.open("wb") as dst_f:
                shutil.copyfileobj(src_f, dst_f)

def init_squidient(dist_dir: str=".") -> None:
    #import squidient  # IMPORTANT: import the module, don't pass a string
    Path(dist_dir + "/squidient").mkdir(parents=True, exist_ok=True)
    copy_packaged_tree(squidient, "data", dist_dir + "/.", overwrite=True)
    copy_packaged_tree(squidient, "sqreport", dist_dir + "/squidient/sqreport", overwrite=True)
    copy_packaged_tree(squidient, "compare", dist_dir + "/squidient/compare", overwrite=True)
    copy_packaged_tree(squidient, "utils", dist_dir + "/squidient/utils", overwrite=True)


if __name__ == "__main__":
    init_squidient()
    print("OK: copied squidient/data/* into current directory")