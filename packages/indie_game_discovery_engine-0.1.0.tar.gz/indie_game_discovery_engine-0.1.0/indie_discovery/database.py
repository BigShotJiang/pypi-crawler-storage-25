"""SQLite database interface with async support."""

import os
from typing import List, Optional
from datetime import datetime
from sqlalchemy import select, update, delete, func
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.types import String, Integer, Float, DateTime, Boolean, JSON


DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./indie_games.db")

engine = create_async_engine(DATABASE_URL, echo=False)
async_session_maker = async_sessionmaker(engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class GameDB(Base):
    __tablename__ = "games"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    title: Mapped[str] = mapped_column(String, index=True)
    developer: Mapped[str] = mapped_column(String, index=True)
    url: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(String, default="")
    price_cents: Mapped[int] = mapped_column(Integer, default=0)
    tags: Mapped[List[str]] = mapped_column(JSON, default=list)
    platforms: Mapped[List[str]] = mapped_column(JSON, default=list)
    release_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    last_updated: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    download_count: Mapped[int] = mapped_column(Integer, default=0)
    rating: Mapped[float] = mapped_column(Float, default=0.0)
    rating_count: Mapped[int] = mapped_column(Integer, default=0)
    screenshot_urls: Mapped[List[str]] = mapped_column(JSON, default=list)
    steam_deck_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    completion_rate: Mapped[float] = mapped_column(Float, default=0.0)
    comment_count: Mapped[int] = mapped_column(Integer, default=0)
    update_frequency_days: Mapped[float] = mapped_column(Float, default=0.0)
    scraped_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class DeveloperDB(Base):
    __tablename__ = "developers"

    username: Mapped[str] = mapped_column(String, primary_key=True)
    display_name: Mapped[str] = mapped_column(String)
    profile_url: Mapped[str] = mapped_column(String)
    game_count: Mapped[int] = mapped_column(Integer, default=0)
    followers: Mapped[int] = mapped_column(Integer, default=0)
    avg_rating: Mapped[float] = mapped_column(Float, default=0.0)
    last_active: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    bio: Mapped[str] = mapped_column(String, default="")
    social_links: Mapped[List[str]] = mapped_column(JSON, default=list)
    scraped_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class VisualFingerprintDB(Base):
    __tablename__ = "visual_fingerprints"

    game_id: Mapped[str] = mapped_column(String, primary_key=True)
    phash: Mapped[str] = mapped_column(String, index=True)
    dominant_colors: Mapped[List[str]] = mapped_column(JSON, default=list)
    color_histogram: Mapped[List[int]] = mapped_column(JSON, default=list)


class UserProfileDB(Base):
    __tablename__ = "user_profiles"

    user_id: Mapped[str] = mapped_column(String, primary_key=True)
    owned_games: Mapped[List[str]] = mapped_column(JSON, default=list)
    liked_games: Mapped[List[str]] = mapped_column(JSON, default=list)
    disliked_games: Mapped[List[str]] = mapped_column(JSON, default=list)
    preferred_tags: Mapped[List[str]] = mapped_column(JSON, default=list)
    preferred_price_max: Mapped[int] = mapped_column(Integer, default=2000)
    preferred_platforms: Mapped[List[str]] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    last_updated: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


async def init_db() -> None:
    """Create all tables."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_session() -> AsyncSession:
    """Get async database session."""
    async with async_session_maker() as session:
        yield session


# Repository pattern for clean data access


class GameRepository:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_id(self, game_id: str) -> Optional[GameDB]:
        result = await self.session.execute(select(GameDB).where(GameDB.id == game_id))
        return result.scalar_one_or_none()

    async def get_by_tags(self, tags: List[str], limit: int = 100) -> List[GameDB]:
        # SQLite JSON queries are limited, so we'll filter in memory
        result = await self.session.execute(select(GameDB).limit(limit * 2))
        games = result.scalars().all()
        # Filter games that have any of the requested tags
        filtered = [g for g in games if any(tag in g.tags for tag in tags)]
        return filtered[:limit]

    async def search_hidden_gems(
        self, max_downloads: int = 5000, min_rating: float = 4.0, limit: int = 20
    ) -> List[GameDB]:
        stmt = (
            select(GameDB)
            .where(GameDB.download_count <= max_downloads)
            .where(GameDB.rating >= min_rating)
            .where(GameDB.rating_count >= 3)  # At least 3 ratings for validity
            .order_by(GameDB.rating.desc())
            .limit(limit)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def save(self, game: GameDB) -> None:
        self.session.add(game)
        await self.session.commit()

    async def save_batch(self, games: List[GameDB]) -> None:
        self.session.add_all(games)
        await self.session.commit()
