"""Data models for games, developers, and recommendations."""

from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, HttpUrl, Field


class Developer(BaseModel):
    """itch.io developer/creator model."""

    username: str
    display_name: str
    profile_url: HttpUrl
    game_count: int = 0
    followers: int = 0
    avg_rating: float = 0.0
    last_active: Optional[datetime] = None
    bio: Optional[str] = None
    social_links: List[str] = Field(default_factory=list)


class Game(BaseModel):
    """itch.io game model."""

    id: str  # Derived from URL slug
    title: str
    developer: str  # Username
    url: HttpUrl
    description: str = ""
    price_cents: int = 0  # 0 for free, 999 for $9.99
    tags: List[str] = Field(default_factory=list)
    platforms: List[str] = Field(default_factory=list)  # windows, mac, linux, browser
    release_date: Optional[datetime] = None
    last_updated: Optional[datetime] = None
    download_count: int = 0
    rating: float = 0.0
    rating_count: int = 0
    screenshot_urls: List[str] = Field(default_factory=list)
    steam_deck_verified: bool = False
    completion_rate: float = 0.0  # If available from itch.io
    comment_count: int = 0
    update_frequency_days: float = 0.0  # Avg days between updates


class VisualFingerprint(BaseModel):
    """Perceptual hash and color data for visual matching."""

    game_id: str
    phash: str  # Hex string of perceptual hash
    dominant_colors: List[str] = Field(default_factory=list)  # Hex color codes
    color_histogram: List[int] = Field(default_factory=list)  # 64-bin histogram


class Recommendation(BaseModel):
    """A recommended game with explanation."""

    game: Game
    gem_score: float = Field(ge=0, le=100)  # Hidden gem score
    similarity_score: float = Field(ge=0, le=1)  # To seed game/user profile
    why_recommended: str  # Human-readable explanation
    match_reasons: List[str] = Field(default_factory=list)  # Tags: visual, creator, tags, etc.


class UserProfile(BaseModel):
    """User preferences learned from library."""

    user_id: str
    owned_games: List[str] = Field(default_factory=list)  # Game IDs
    liked_games: List[str] = Field(default_factory=list)
    disliked_games: List[str] = Field(default_factory=list)
    preferred_tags: List[str] = Field(default_factory=list)
    preferred_price_max: int = 2000  # $20
    preferred_platforms: List[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_updated: datetime = Field(default_factory=datetime.utcnow)
