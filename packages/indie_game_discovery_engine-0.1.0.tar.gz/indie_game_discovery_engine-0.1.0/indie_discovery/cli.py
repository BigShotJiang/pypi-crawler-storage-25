"""Command-line interface for the discovery engine."""

import asyncio
import sys
from typing import Optional
import click
from indie_discovery.scrapers.game_scraper import ItchIOScraper
from indie_discovery.database import init_db, async_session_maker, GameRepository, GameDB
from indie_discovery.analysis.gem_scorer import GemScorer


@click.group()
def main():
    """Indie Game Discovery CLI - Find hidden gems on itch.io."""
    pass


@main.command()
@click.argument("title")
@click.option("--platform", default=None, help="Filter by platform (windows/mac/linux/steamdeck)")
@click.option("--limit", default=10, help="Number of recommendations")
def find_similar(title: str, platform: Optional[str], limit: int):
    """Find games similar to a specific title."""
    click.echo(f"🔍 Searching for games similar to '{title}'...")
    click.echo("⚠️  This feature requires a populated database. Run 'scrape' first.")
    # TODO: Implement similarity search after database is populated


@main.command()
@click.option("--genre", default=None, help="Genre to discover (platformer, puzzle, etc.)")
@click.option("--max-downloads", default=5000, help="Max download count for 'hidden' status")
@click.option("--min-rating", default=4.0, help="Minimum rating (0-5)")
@click.option("--limit", default=20, help="Number of games to show")
def discover(genre: Optional[str], max_downloads: int, min_rating: float, limit: int):
    """Discover hidden gem indie games."""
    asyncio.run(_discover_async(genre, max_downloads, min_rating, limit))


async def _discover_async(
    genre: Optional[str], max_downloads: int, min_rating: float, limit: int
):
    """Async implementation of discover command."""
    await init_db()

    async with async_session_maker() as session:
        repo = GameRepository(session)

        click.echo(f"🎮 Discovering hidden gems...")
        if genre:
            click.echo(f"   Genre: {genre}")
        click.echo(f"   Max downloads: {max_downloads}")
        click.echo(f"   Min rating: {min_rating}★\n")

        games = await repo.search_hidden_gems(max_downloads, min_rating, limit)

        if not games:
            click.echo("❌ No games found. Database may be empty. Run 'scrape' first.")
            return

        scorer = GemScorer()

        for i, game in enumerate(games, 1):
            gem_score = scorer.calculate_gem_score(game)

            click.echo(f"{i}. {click.style(game.title, fg='green', bold=True)}")
            click.echo(f"   Developer: {game.developer}")
            click.echo(f"   Rating: {game.rating:.1f}★ ({game.rating_count} ratings)")
            click.echo(f"   Gem Score: {gem_score:.1f}/100")
            click.echo(f"   URL: {game.url}")
            if game.tags:
                click.echo(f"   Tags: {', '.join(game.tags[:5])}")
            click.echo()


@main.command()
@click.option("--genre", default=None, help="Genre to scrape (leave empty for all)")
@click.option("--pages", default=3, help="Number of browse pages to scrape")
def scrape(genre: Optional[str], pages: int):
    """Scrape itch.io for game data (populates database)."""
    asyncio.run(_scrape_async(genre, pages))


async def _scrape_async(genre: Optional[str], pages: int):
    """Async implementation of scrape command."""
    await init_db()
    scraper = ItchIOScraper()

    try:
        click.echo(f"🕷️  Scraping itch.io...")
        if genre:
            click.echo(f"   Genre: {genre}")
        click.echo(f"   Pages: {pages}\n")

        all_games = []

        for page in range(1, pages + 1):
            click.echo(f"📄 Scraping page {page}...")
            game_urls = await scraper.scrape_browse_page(genre, page)

            for url in game_urls:
                game = await scraper.scrape_game(url)
                if game:
                    all_games.append(game)
                    click.echo(f"   ✓ {game.title}")

        # Save to database
        async with async_session_maker() as session:
            repo = GameRepository(session)
            games_db = [
                GameDB(
                    id=g.id,
                    title=g.title,
                    developer=g.developer,
                    url=str(g.url),
                    description=g.description,
                    price_cents=g.price_cents,
                    tags=g.tags,
                    platforms=g.platforms,
                    release_date=g.release_date,
                    last_updated=g.last_updated,
                    download_count=g.download_count,
                    rating=g.rating,
                    rating_count=g.rating_count,
                    screenshot_urls=g.screenshot_urls,
                    steam_deck_verified=g.steam_deck_verified,
                    completion_rate=g.completion_rate,
                    comment_count=g.comment_count,
                    update_frequency_days=g.update_frequency_days,
                )
                for g in all_games
            ]
            await repo.save_batch(games_db)

        click.echo(f"\n✅ Scraped {len(all_games)} games successfully!")

    finally:
        await scraper.close()


if __name__ == "__main__":
    main()
