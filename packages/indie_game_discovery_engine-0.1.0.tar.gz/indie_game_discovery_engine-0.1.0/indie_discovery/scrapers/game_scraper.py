"""Scraper for itch.io game pages and browse listings."""

import asyncio
import re
from typing import List, Optional
from datetime import datetime
from urllib.parse import urljoin, urlparse
import httpx
from bs4 import BeautifulSoup

from indie_discovery.models import Game, Developer


class ItchIOScraper:
    """Rate-limited scraper for itch.io."""

    BASE_URL = "https://itch.io"
    RATE_LIMIT = 1.0  # Seconds between requests

    def __init__(self):
        self.client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "User-Agent": "IndieGameDiscoveryBot/0.1 (Educational Research; +https://github.com/yourusername/indie-game-discovery-engine)"
            },
        )
        self._last_request = 0.0

    async def _rate_limit(self) -> None:
        """Enforce rate limiting."""
        now = asyncio.get_event_loop().time()
        elapsed = now - self._last_request
        if elapsed < self.RATE_LIMIT:
            await asyncio.sleep(self.RATE_LIMIT - elapsed)
        self._last_request = asyncio.get_event_loop().time()

    async def scrape_game(self, url: str) -> Optional[Game]:
        """Scrape a single game page."""
        await self._rate_limit()

        try:
            response = await self.client.get(url)
            response.raise_for_status()
        except httpx.HTTPError as e:
            print(f"Failed to scrape {url}: {e}")
            return None

        soup = BeautifulSoup(response.text, "html.parser")

        # Extract game ID from URL
        game_id = urlparse(url).path.strip("/").replace("/", "-")

        # Title
        title_elem = soup.find("h1", class_="game_title")
        title = title_elem.text.strip() if title_elem else "Unknown"

        # Developer
        dev_elem = soup.find("a", class_="user_link")
        developer = dev_elem.text.strip() if dev_elem else "Unknown"

        # Description
        desc_elem = soup.find("div", class_="formatted_description")
        description = desc_elem.get_text(strip=True) if desc_elem else ""

        # Price
        price_cents = 0
        price_elem = soup.find("div", class_="buy_row")
        if price_elem:
            price_text = price_elem.get_text()
            match = re.search(r"\$(\d+(?:\.\d{2})?)", price_text)
            if match:
                price_cents = int(float(match.group(1)) * 100)

        # Tags
        tags = []
        tag_elems = soup.find_all("a", class_="tag")
        for tag_elem in tag_elems:
            tags.append(tag_elem.text.strip())

        # Platforms
        platforms = []
        platform_icons = soup.find_all("span", class_="icon")
        for icon in platform_icons:
            platform = icon.get("title", "").lower()
            if "windows" in platform:
                platforms.append("windows")
            elif "mac" in platform or "osx" in platform:
                platforms.append("mac")
            elif "linux" in platform:
                platforms.append("linux")
            elif "android" in platform:
                platforms.append("android")
            elif "web" in platform or "html5" in platform:
                platforms.append("browser")

        # Screenshots
        screenshot_urls = []
        screenshot_elems = soup.find_all("a", class_="screenshot_list_item")
        for screenshot_elem in screenshot_elems:
            img_url = screenshot_elem.get("href")
            if img_url:
                screenshot_urls.append(urljoin(self.BASE_URL, img_url))

        # Rating (if available)
        rating = 0.0
        rating_count = 0
        rating_elem = soup.find("div", class_="aggregate_rating")
        if rating_elem:
            rating_text = rating_elem.get_text()
            match = re.search(r"([\d.]+)\s*stars?.*?(\d+)\s*ratings?", rating_text, re.IGNORECASE)
            if match:
                rating = float(match.group(1))
                rating_count = int(match.group(2))

        # Downloads (not always public)
        download_count = 0
        download_elem = soup.find("td", string=re.compile(r"Downloads", re.IGNORECASE))
        if download_elem:
            download_text = download_elem.find_next_sibling("td").get_text()
            download_count = int(re.sub(r"\D", "", download_text))

        return Game(
            id=game_id,
            title=title,
            developer=developer,
            url=url,
            description=description,
            price_cents=price_cents,
            tags=tags,
            platforms=list(set(platforms)),
            screenshot_urls=screenshot_urls[:5],  # Max 5 screenshots
            rating=rating,
            rating_count=rating_count,
            download_count=download_count,
        )

    async def scrape_browse_page(
        self, genre: Optional[str] = None, page: int = 1
    ) -> List[str]:
        """Scrape game URLs from a browse page."""
        await self._rate_limit()

        url = f"{self.BASE_URL}/games"
        params = {"page": page}
        if genre:
            params["genre"] = genre

        try:
            response = await self.client.get(url, params=params)
            response.raise_for_status()
        except httpx.HTTPError as e:
            print(f"Failed to scrape browse page: {e}")
            return []

        soup = BeautifulSoup(response.text, "html.parser")

        game_urls = []
        game_cells = soup.find_all("div", class_="game_cell")
        for cell in game_cells:
            link = cell.find("a", class_="game_link")
            if link and link.get("href"):
                game_urls.append(urljoin(self.BASE_URL, link["href"]))

        return game_urls

    async def close(self) -> None:
        """Close the HTTP client."""
        await self.client.aclose()
