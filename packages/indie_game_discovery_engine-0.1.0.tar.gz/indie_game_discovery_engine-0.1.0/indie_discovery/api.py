"""FastAPI server for the discovery engine."""

import os
from typing import List, Optional
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession
import stripe

from indie_discovery.database import init_db, get_session, GameRepository, GameDB
from indie_discovery.models import Game, Recommendation
from indie_discovery.analysis.recommender import RecommendationEngine
from indie_discovery.analysis.gem_scorer import GemScorer

# Stripe configuration
stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_PUBLISHABLE_KEY = os.getenv("STRIPE_PUBLISHABLE_KEY", "")
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize database on startup."""
    await init_db()
    yield


app = FastAPI(
    title="Indie Game Discovery Engine",
    description="Find hidden indie gems on itch.io with AI-powered recommendations",
    version="0.1.0",
    lifespan=lifespan,
)

templates = Jinja2Templates(directory="indie_discovery/templates")


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Landing page."""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/discover")
async def discover_games(
    genre: Optional[str] = None,
    max_price: Optional[int] = None,
    platform: Optional[str] = None,
    min_gem_score: float = 0,
    limit: int = 20,
    session: AsyncSession = Depends(get_session),
) -> dict:
    """
    Get personalized game recommendations.

    Query params:
        - genre: platformer, puzzle, rpg, visual-novel, etc.
        - max_price: Max price in cents (999 = $9.99)
        - platform: windows, mac, linux, steamdeck, browser
        - min_gem_score: Minimum hidden gem score (0-100)
        - limit: Number of results (default 20)
    """
    repo = GameRepository(session)

    # Get candidate games
    if genre:
        games_db = await repo.get_by_tags([genre], limit=limit * 2)
    else:
        games_db = await repo.search_hidden_gems(limit=limit * 2)

    # Convert to domain models
    games = [
        Game(
            id=g.id,
            title=g.title,
            developer=g.developer,
            url=g.url,
            description=g.description,
            price_cents=g.price_cents,
            tags=g.tags,
            platforms=g.platforms,
            release_date=g.release_date,
            last_updated=g.last_updated,
            download_count=g.download_count,
            rating=g.rating,
            rating_count=g.rating_count,
            screenshot_urls=g.screenshot_urls,
            steam_deck_verified=g.steam_deck_verified,
            completion_rate=g.completion_rate,
            comment_count=g.comment_count,
            update_frequency_days=g.update_frequency_days,
        )
        for g in games_db
    ]

    # Apply filters
    if max_price is not None:
        games = [g for g in games if g.price_cents <= max_price]

    if platform:
        if platform == "steamdeck":
            games = [g for g in games if g.steam_deck_verified]
        else:
            games = [g for g in games if platform in g.platforms]

    # Score and filter by gem score
    scorer = GemScorer()
    scored_games = []
    for game in games:
        gem_score = scorer.calculate_gem_score(game)
        if gem_score >= min_gem_score:
            scored_games.append((game, gem_score))

    # Sort by gem score
    scored_games.sort(key=lambda x: x[1], reverse=True)

    # Build recommendations
    recommendations = []
    for game, gem_score in scored_games[:limit]:
        recommendations.append(
            {
                "title": game.title,
                "developer": game.developer,
                "url": str(game.url),
                "price_cents": game.price_cents,
                "gem_score": round(gem_score, 1),
                "why_recommended": f"Hidden gem with {game.rating:.1f}★ rating, updated {int(game.update_frequency_days) if game.update_frequency_days > 0 else 'recently'}",
                "tags": game.tags,
                "screenshot_url": game.screenshot_urls[0] if game.screenshot_urls else None,
                "steam_deck_verified": game.steam_deck_verified,
            }
        )

    return {"recommendations": recommendations, "total": len(scored_games)}


@app.get("/pricing", response_class=HTMLResponse)
async def pricing_page(request: Request):
    """Pricing page with Stripe checkout."""
    return templates.TemplateResponse(
        "pricing.html",
        {
            "request": request,
            "stripe_publishable_key": STRIPE_PUBLISHABLE_KEY,
        },
    )


@app.post("/create-checkout-session")
async def create_checkout_session():
    """Create Stripe Checkout session for Pro subscription."""
    if not stripe.api_key:
        raise HTTPException(status_code=500, detail="Stripe not configured")

    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[
                {
                    "price_data": {
                        "currency": "usd",
                        "product_data": {
                            "name": "Indie Discovery Pro",
                            "description": "Unlimited recommendations, Steam Deck priority, email alerts",
                        },
                        "unit_amount": 499,  # $4.99
                        "recurring": {"interval": "month"},
                    },
                    "quantity": 1,
                }
            ],
            mode="subscription",
            success_url=os.getenv("BASE_URL", "http://localhost:8000") + "/success",
            cancel_url=os.getenv("BASE_URL", "http://localhost:8000") + "/cancel",
        )
        return {"sessionId": checkout_session.id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/success", response_class=HTMLResponse)
async def success_page(request: Request):
    """Payment success page."""
    return templates.TemplateResponse("success.html", {"request": request})


@app.get("/cancel", response_class=HTMLResponse)
async def cancel_page(request: Request):
    """Payment cancelled page."""
    return templates.TemplateResponse("cancel.html", {"request": request})


@app.post("/webhook")
async def stripe_webhook(request: Request):
    """Handle Stripe webhook events."""
    if not STRIPE_WEBHOOK_SECRET:
        raise HTTPException(status_code=500, detail="Webhook secret not configured")

    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payload")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Invalid signature")

    # Handle subscription events
    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        # TODO: Activate user's Pro subscription in database
        print(f"Subscription created: {session['id']}")

    return {"status": "success"}


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy"}
