"""Recommendation engine combining multiple signals."""

from typing import List, Optional, Dict
from indie_discovery.models import Game, Recommendation, UserProfile, VisualFingerprint
from indie_discovery.analysis.visual_matcher import VisualMatcher
from indie_discovery.analysis.gem_scorer import GemScorer


class RecommendationEngine:
    """Generate personalized game recommendations."""

    def __init__(self):
        self.visual_matcher = VisualMatcher()
        self.gem_scorer = GemScorer()

    async def recommend(
        self,
        candidate_games: List[Game],
        seed_game: Optional[Game] = None,
        user_profile: Optional[UserProfile] = None,
        fingerprints: Optional[Dict[str, VisualFingerprint]] = None,
        limit: int = 20,
    ) -> List[Recommendation]:
        """
        Generate recommendations based on seed game or user profile.

        Args:
            candidate_games: Pool of games to recommend from
            seed_game: Reference game for similarity matching
            user_profile: User preferences for personalization
            fingerprints: Visual fingerprints for similarity matching
            limit: Max recommendations to return
        """
        recommendations = []

        for game in candidate_games:
            # Skip if user already owns/disliked
            if user_profile:
                if game.id in user_profile.owned_games or game.id in user_profile.disliked_games:
                    continue

            # Calculate similarity score
            similarity_score = 0.0
            match_reasons = []

            # Visual similarity to seed game
            if seed_game and fingerprints:
                seed_fp = fingerprints.get(seed_game.id)
                game_fp = fingerprints.get(game.id)
                if seed_fp and game_fp:
                    visual_sim = self.visual_matcher.compute_visual_similarity(
                        seed_fp.phash, seed_fp.color_histogram, game_fp.phash, game_fp.color_histogram
                    )
                    similarity_score += visual_sim * 0.4
                    if visual_sim > 0.7:
                        match_reasons.append("visual")

            # Tag overlap
            if seed_game:
                tag_overlap = len(set(game.tags) & set(seed_game.tags))
                if tag_overlap > 0:
                    tag_score = tag_overlap / max(len(seed_game.tags), 1)
                    similarity_score += tag_score * 0.3
                    match_reasons.append("tags")

            # User profile matching
            if user_profile:
                # Preferred tags
                tag_match = len(set(game.tags) & set(user_profile.preferred_tags))
                if tag_match > 0:
                    similarity_score += (tag_match / len(user_profile.preferred_tags)) * 0.2
                    match_reasons.append("tags")

                # Price filter
                if game.price_cents > user_profile.preferred_price_max:
                    continue

                # Platform filter
                if user_profile.preferred_platforms:
                    if not any(p in game.platforms for p in user_profile.preferred_platforms):
                        continue

            # Calculate gem score
            gem_score = self.gem_scorer.calculate_gem_score(game)

            # Generate explanation
            why = self._generate_explanation(game, seed_game, match_reasons)

            recommendations.append(
                Recommendation(
                    game=game,
                    gem_score=gem_score,
                    similarity_score=similarity_score,
                    why_recommended=why,
                    match_reasons=match_reasons,
                )
            )

        # Sort by combined score (similarity * 0.5 + gem_score/100 * 0.5)
        recommendations.sort(
            key=lambda r: r.similarity_score * 0.5 + (r.gem_score / 100) * 0.5, reverse=True
        )

        return recommendations[:limit]

    def _generate_explanation(
        self, game: Game, seed_game: Optional[Game], match_reasons: List[str]
    ) -> str:
        """Generate human-readable recommendation explanation."""
        parts = []

        if "visual" in match_reasons and seed_game:
            parts.append(f"Visual style matches {seed_game.title}")

        if "tags" in match_reasons and seed_game:
            common_tags = set(game.tags) & set(seed_game.tags)
            if common_tags:
                parts.append(f"Shares {', '.join(list(common_tags)[:2])} themes")

        if game.update_frequency_days > 0 and game.update_frequency_days <= 30:
            parts.append(f"Active dev with updates every {int(game.update_frequency_days)} days")

        if game.rating >= 4.5 and game.rating_count >= 5:
            parts.append(f"{game.rating:.1f}★ rating from {game.rating_count} players")

        if game.steam_deck_verified:
            parts.append("Steam Deck verified")

        return ", ".join(parts) if parts else "High quality indie title"
