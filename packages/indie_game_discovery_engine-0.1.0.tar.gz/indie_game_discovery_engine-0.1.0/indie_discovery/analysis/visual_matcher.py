"""Visual similarity matching using perceptual hashing."""

import io
from typing import List, Tuple
import httpx
from PIL import Image
import imagehash
import numpy as np
from sklearn.cluster import KMeans


class VisualMatcher:
    """Match games by screenshot visual similarity."""

    def __init__(self):
        self.client = httpx.AsyncClient(timeout=30.0)

    async def compute_fingerprint(self, image_url: str) -> Tuple[str, List[str], List[int]]:
        """
        Compute perceptual hash, dominant colors, and color histogram.

        Returns:
            (phash_hex, dominant_colors, color_histogram)
        """
        try:
            response = await self.client.get(image_url)
            response.raise_for_status()
            img = Image.open(io.BytesIO(response.content))
        except Exception as e:
            print(f"Failed to download {image_url}: {e}")
            return ("0" * 16, [], [0] * 64)

        # Convert to RGB if needed
        if img.mode != "RGB":
            img = img.convert("RGB")

        # Perceptual hash
        phash = imagehash.phash(img, hash_size=8)
        phash_hex = str(phash)

        # Dominant colors (k-means on pixel data)
        img_small = img.resize((100, 100))
        pixels = np.array(img_small).reshape(-1, 3)
        kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
        kmeans.fit(pixels)
        dominant_colors = [self._rgb_to_hex(color) for color in kmeans.cluster_centers_.astype(int)]

        # Color histogram (8x8x8 bins in RGB space)
        histogram, _ = np.histogramdd(
            pixels, bins=[8, 8, 8], range=[[0, 256], [0, 256], [0, 256]]
        )
        color_histogram = histogram.flatten().astype(int).tolist()

        return phash_hex, dominant_colors, color_histogram

    @staticmethod
    def _rgb_to_hex(rgb: np.ndarray) -> str:
        """Convert RGB array to hex color string."""
        return "#{:02x}{:02x}{:02x}".format(int(rgb[0]), int(rgb[1]), int(rgb[2]))

    @staticmethod
    def hamming_distance(hash1: str, hash2: str) -> int:
        """Calculate Hamming distance between two phash hex strings."""
        if len(hash1) != len(hash2):
            return 999  # Invalid comparison
        return sum(c1 != c2 for c1, c2 in zip(hash1, hash2))

    @staticmethod
    def histogram_similarity(hist1: List[int], hist2: List[int]) -> float:
        """
        Calculate histogram similarity using correlation coefficient.

        Returns:
            Similarity score from 0 (different) to 1 (identical).
        """
        if len(hist1) != len(hist2):
            return 0.0

        h1 = np.array(hist1, dtype=float)
        h2 = np.array(hist2, dtype=float)

        # Normalize
        h1 = h1 / (h1.sum() + 1e-8)
        h2 = h2 / (h2.sum() + 1e-8)

        # Correlation
        correlation = np.corrcoef(h1, h2)[0, 1]
        return max(0.0, correlation)  # Clamp to [0, 1]

    def compute_visual_similarity(
        self,
        phash1: str,
        hist1: List[int],
        phash2: str,
        hist2: List[int],
    ) -> float:
        """
        Combine perceptual hash distance and histogram similarity.

        Returns:
            Similarity score from 0 (different) to 1 (identical).
        """
        # Hamming distance (lower is more similar)
        hamming = self.hamming_distance(phash1, phash2)
        max_hamming = len(phash1) * 4  # Max bits in hex string
        phash_similarity = 1 - (hamming / max_hamming)

        # Histogram similarity
        hist_similarity = self.histogram_similarity(hist1, hist2)

        # Weighted average (phash is stronger signal)
        return 0.7 * phash_similarity + 0.3 * hist_similarity

    async def close(self) -> None:
        """Close HTTP client."""
        await self.client.aclose()
