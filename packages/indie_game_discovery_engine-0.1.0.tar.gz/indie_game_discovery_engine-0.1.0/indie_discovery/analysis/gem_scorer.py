"""Calculate 'hidden gem' score for games."""

from datetime import datetime, timedelta
from indie_discovery.models import Game


class GemScorer:
    """Score games for 'hidden gem' potential."""

    @staticmethod
    def calculate_gem_score(game: Game) -> float:
        """
        Calculate hidden gem score (0-100).

        Factors:
        - Dev engagement (updates, comment responses)
        - Rating quality (high rating with decent sample size)
        - Uniqueness (low download count but active)
        - Platform support (Steam Deck = bonus)
        """
        score = 0.0

        # 1. Dev engagement (0-30 points)
        if game.update_frequency_days > 0:
            # Frequent updates are good (weekly = 7 days)
            if game.update_frequency_days <= 7:
                score += 30
            elif game.update_frequency_days <= 30:
                score += 20
            elif game.update_frequency_days <= 90:
                score += 10

        # Comment engagement
        if game.comment_count > 0:
            score += min(10, game.comment_count / 2)  # Up to 10 bonus points

        # 2. Rating quality (0-25 points)
        if game.rating_count >= 3:
            rating_score = (game.rating / 5.0) * 20  # Perfect 5-star = 20 pts
            # Sample size bonus
            if game.rating_count >= 10:
                rating_score += 5
            score += rating_score

        # 3. Uniqueness / Hidden status (0-20 points)
        # Inverse relationship with download count
        if game.download_count < 100:
            score += 20
        elif game.download_count < 500:
            score += 15
        elif game.download_count < 2000:
            score += 10
        elif game.download_count < 5000:
            score += 5

        # 4. Platform support (0-15 points)
        if game.steam_deck_verified:
            score += 10
        if "linux" in game.platforms:
            score += 3
        if "browser" in game.platforms:
            score += 2  # Easy access

        # 5. Recency bonus (0-10 points)
        if game.last_updated:
            days_since_update = (datetime.utcnow() - game.last_updated).days
            if days_since_update <= 30:
                score += 10
            elif days_since_update <= 90:
                score += 5

        return min(100.0, score)
