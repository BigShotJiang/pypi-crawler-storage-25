"""Indie Game Discovery Engine - Find hidden gems on itch.io."""

__version__ = "0.1.0"
