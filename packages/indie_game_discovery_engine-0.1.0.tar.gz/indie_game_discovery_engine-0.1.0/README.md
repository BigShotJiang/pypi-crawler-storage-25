# indie-game-discovery-engine

Discover hidden indie gems on itch.io through intelligent pattern matching and recommendation algorithms.

## What is this?

indie-game-discovery-engine solves the overwhelming choice problem in indie gaming by analyzing play patterns, creator networks, and visual aesthetics to surface undiscovered titles tailored to your tastes. Instead of scrolling through thousands of games, get personalized recommendations based on what makes games special—not just what's trending.

## Features

- **Visual Aesthetic Matching** — Analyzes screenshots to find games with similar visual styles
- **Play Pattern Analysis** — Recommends games based on community engagement and play history
- **Creator Network Intelligence** — Discovers games from developers connected to creators you follow
- **Gem Scoring Algorithm** — Ranks hidden games by quality metrics including update frequency and community sentiment
- **itch.io Integration** — Direct scraping of game metadata, tags, and developer information
- **REST API & CLI** — Both programmatic and command-line interfaces for easy integration

## Quick Start

### Installation

```bash
pip install indie-discovery
```

Or from source:

```bash
git clone <repo>
cd indie-game-discovery-engine
pip install -e .
```

### Basic Usage

#### Via CLI

```bash
# Recommend games similar to a specific title
indie-discovery recommend --game "Celeste"

# Find hidden gems in a category
indie-discovery discover --category puzzle --limit 10

# Analyze a game's aesthetic
indie-discovery analyze --game-id <id> --visual
```

#### Via Python API

```python
from indie_discovery import Recommender, VisualMatcher

# Get recommendations
recommender = Recommender()
gems = recommender.find_similar_games("Hollow Knight", limit=5)

# Visual matching
matcher = VisualMatcher()
similar = matcher.find_by_aesthetic(game_id="my-game")
```

## Usage Examples

```python
from indie_discovery.analysis import GemScorer
from indie_discovery.scrapers import GameScraper

# Scrape itch.io and score games
scraper = GameScraper()
games = scraper.fetch_games(category="adventure", limit=100)

scorer = GemScorer()
ranked = scorer.score_gems(games)

for game in ranked[:10]:
    print(f"{game.title}: {game.gem_score}/100")
```

## Tech Stack

- **Python 3.10+** — Core language
- **SQLite/PostgreSQL** — Game metadata and analysis storage
- **FastAPI** — REST API
- **Pillow** — Screenshot analysis and visual matching
- **Beautiful Soup** — itch.io scraping
- **scikit-learn** — Recommendation algorithms

## License

MIT