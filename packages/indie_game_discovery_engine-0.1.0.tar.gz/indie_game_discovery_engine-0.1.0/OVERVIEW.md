# indie-game-discovery-engine

A Steam-like discovery algorithm for itch.io games that surfaces hidden indie gems based on play patterns, creator networks, and aesthetic similarity. Solves the "10,000 games, nothing to play" problem by analyzing game metadata, screenshots, and dev update frequency to recommend undiscovered titles. Built for indie game enthusiasts who want personalized recommendations beyond Steam's algorithm.
