# Cross-Auth End-to-End Tests

This directory contains cross-app Playwright tests for the example applications.

Right now it covers the FastAPI hybrid backend and the separate SPA demo, with
Playwright tests written in TypeScript.

## What It Tests

- auth-code + token login from the separate SPA
- bearer-authenticated API access from the SPA
- GitHub account linking for a session-authenticated backend user
- GitHub account linking for a bearer-authenticated client

Current specs:

- `tests/session-social-login.spec.ts`
- `tests/session-linking.spec.ts`
- `tests/spa-linking.spec.ts`
- `tests/spa-auth.spec.ts`

## Run It

```bash
cd e2e
bun install
bunx playwright install chromium
bun run test:e2e
```

Headed mode:

```bash
bun run test:e2e:headed
```

The Playwright config starts:

- `examples/fastapi` on `http://127.0.0.1:8000`
- `examples/spa` on `http://127.0.0.1:5173`

by default. If you want Playwright to reuse servers you already started
manually, set `PLAYWRIGHT_REUSE_SERVERS=1`.
