"""SQLite persistence for strategy state.

Stores fills, positions, and periodic portfolio snapshots so the bot can
recover its state after a crash or restart without losing trade history.
"""
from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from auspicium.strategy.models import Fill, Portfolio, Position

log = logging.getLogger(__name__)


class StateManager:
    """Persists strategy state to SQLite for crash recovery.

    DB location: {strategy_dir}/state.db

    Tables:
        fills               — every completed fill, keyed by fill ID
        positions           — current open positions (upserted on every change)
        portfolio_snapshots — periodic equity snapshots (every 60 s by default)
    """

    def __init__(self, db_path: str | Path) -> None:
        self._path = Path(db_path)
        self._conn = sqlite3.connect(str(self._path))
        self._conn.row_factory = sqlite3.Row
        self._create_tables()
        log.info("StateManager opened: %s", self._path)

    # ------------------------------------------------------------------ #
    # Schema                                                               #
    # ------------------------------------------------------------------ #

    def _create_tables(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS fills (
                id          TEXT PRIMARY KEY,
                order_id    TEXT NOT NULL,
                market      TEXT NOT NULL,
                side        TEXT NOT NULL,
                outcome     TEXT NOT NULL,
                price       REAL NOT NULL,
                size        REAL NOT NULL,
                fee         REAL NOT NULL DEFAULT 0,
                timestamp   TEXT NOT NULL,
                status      TEXT NOT NULL DEFAULT 'CONFIRMED'
            );

            CREATE TABLE IF NOT EXISTS positions (
                market      TEXT PRIMARY KEY,
                side        TEXT NOT NULL,
                outcome     TEXT NOT NULL,
                size        REAL NOT NULL,
                entry_price REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS portfolio_snapshots (
                timestamp       TEXT PRIMARY KEY,
                cash            REAL NOT NULL,
                total_value     REAL NOT NULL,
                realized_pnl    REAL NOT NULL,
                unrealized_pnl  REAL NOT NULL,
                daily_pnl       REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS indicators (
                name      TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                value     REAL NOT NULL,
                PRIMARY KEY (name, timestamp)
            );

            CREATE TABLE IF NOT EXISTS indicator_meta (
                name       TEXT PRIMARY KEY,
                pane       TEXT DEFAULT 'primary',
                color      TEXT DEFAULT '#2196F3',
                line_width INTEGER DEFAULT 1,
                levels     TEXT DEFAULT NULL
            );
        """)
        self._conn.commit()

    # ------------------------------------------------------------------ #
    # Writes                                                               #
    # ------------------------------------------------------------------ #

    def record_fill(self, fill: Fill) -> None:
        """Persist a fill. Uses INSERT OR IGNORE so replays are idempotent."""
        self._conn.execute(
            """INSERT OR IGNORE INTO fills
               (id, order_id, market, side, outcome, price, size, fee, timestamp, status)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                fill.order_id,          # use order_id as fill id (paper: 1:1)
                fill.order_id,
                fill.market,
                fill.side,
                fill.outcome,
                fill.price,
                fill.size,
                fill.fee,
                fill.timestamp.isoformat(),
                fill.status,
            ),
        )
        self._conn.commit()

    def update_position(self, position: Position) -> None:
        """Upsert a position row."""
        self._conn.execute(
            """INSERT OR REPLACE INTO positions
               (market, side, outcome, size, entry_price)
               VALUES (?, ?, ?, ?, ?)""",
            (position.market, position.side, position.outcome,
             position.size, position.entry_price),
        )
        self._conn.commit()

    def remove_position(self, market: str) -> None:
        """Delete a position (called when position is fully closed)."""
        self._conn.execute("DELETE FROM positions WHERE market = ?", (market,))
        self._conn.commit()

    def snapshot_portfolio(self, portfolio: Portfolio) -> None:
        """Write a periodic portfolio snapshot for equity curve reconstruction."""
        self._conn.execute(
            """INSERT OR REPLACE INTO portfolio_snapshots
               (timestamp, cash, total_value, realized_pnl, unrealized_pnl, daily_pnl)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                datetime.now(timezone.utc).isoformat(),
                portfolio.cash,
                portfolio.total_value,
                portfolio.realized_pnl,
                portfolio.unrealized_pnl,
                portfolio.daily_pnl,
            ),
        )
        self._conn.commit()

    # ------------------------------------------------------------------ #
    # Reads (for crash recovery)                                           #
    # ------------------------------------------------------------------ #

    def load_positions(self) -> dict[str, Position]:
        """Load all open positions from DB. Called on runner startup."""
        rows = self._conn.execute("SELECT * FROM positions").fetchall()
        positions: dict[str, Position] = {}
        for row in rows:
            p = Position(
                market=row["market"],
                side=row["side"],
                outcome=row["outcome"],
                size=row["size"],
                entry_price=row["entry_price"],
            )
            positions[p.market] = p
        log.info("Loaded %d positions from state DB", len(positions))
        return positions

    def load_portfolio_snapshot(self) -> Portfolio | None:
        """Load the most recent portfolio snapshot. Returns None if none saved."""
        row = self._conn.execute(
            "SELECT * FROM portfolio_snapshots ORDER BY timestamp DESC LIMIT 1"
        ).fetchone()
        if not row:
            return None
        positions = self.load_positions()
        return Portfolio(
            cash=row["cash"],
            positions=positions,
            total_value=row["total_value"],
            realized_pnl=row["realized_pnl"],
            unrealized_pnl=row["unrealized_pnl"],
            daily_pnl=row["daily_pnl"],
        )

    def get_fills(self, limit: int = 100) -> list[Fill]:
        """Return the most recent fills, newest first."""
        rows = self._conn.execute(
            "SELECT * FROM fills ORDER BY timestamp DESC LIMIT ?", (limit,)
        ).fetchall()
        fills = []
        for row in rows:
            fills.append(Fill(
                order_id=row["order_id"],
                market=row["market"],
                side=row["side"],
                outcome=row["outcome"],
                price=row["price"],
                size=row["size"],
                fee=row["fee"],
                timestamp=datetime.fromisoformat(row["timestamp"]),
                status=row["status"],
            ))
        return fills

    def get_daily_pnl(self) -> float:
        """Compute today's realized PnL from fills (approximate from fee-adjusted cost)."""
        today = datetime.now(timezone.utc).date().isoformat()
        rows = self._conn.execute(
            "SELECT side, price, size, fee FROM fills WHERE timestamp >= ?",
            (today,),
        ).fetchall()
        pnl = 0.0
        for row in rows:
            sign = -1.0 if row["side"] == "BUY" else 1.0
            pnl += sign * row["price"] * row["size"] - row["fee"]
        return pnl

    def record_indicators(self, indicators: dict) -> None:
        """Persist current indicator values to SQLite (live mode only).

        Upserts meta, inserts only NEW data points (INSERT OR IGNORE).
        Call every N ticks from the runner; never called in backtest mode.

        Args:
            indicators: dict from strategy.indicators — the full nested dict
                        with "name", "pane", "color", "line_width", "levels", "data".
        """
        for name, ind in indicators.items():
            self._conn.execute(
                """INSERT OR REPLACE INTO indicator_meta (name, pane, color, line_width, levels)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    name,
                    ind.get("pane", "primary"),
                    ind.get("color", "#2196F3"),
                    ind.get("line_width", 1),
                    json.dumps(ind.get("levels")) if ind.get("levels") is not None else None,
                ),
            )
            for point in ind.get("data", []):
                self._conn.execute(
                    "INSERT OR IGNORE INTO indicators (name, timestamp, value) VALUES (?, ?, ?)",
                    (name, point["time"], point["value"]),
                )
        self._conn.commit()

    def load_indicators(self, name: str | None = None, limit: int = 500) -> dict:
        """Load indicator time series and metadata from SQLite.

        Args:
            name:  If set, load only this indicator. Otherwise load all.
            limit: Max data points per indicator (newest first).

        Returns:
            dict matching the chart data contract format — same shape as
            strategy.indicators (keyed by name).
        """
        # Load meta
        if name is not None:
            meta_rows = self._conn.execute(
                "SELECT * FROM indicator_meta WHERE name = ?", (name,)
            ).fetchall()
        else:
            meta_rows = self._conn.execute("SELECT * FROM indicator_meta").fetchall()

        result: dict = {}
        for meta in meta_rows:
            ind_name = meta["name"]
            levels_raw = meta["levels"]
            levels = json.loads(levels_raw) if levels_raw is not None else None

            # Load data points (oldest first for chart rendering)
            if name is not None:
                data_rows = self._conn.execute(
                    """SELECT timestamp, value FROM indicators WHERE name = ?
                       ORDER BY timestamp ASC LIMIT ?""",
                    (ind_name, limit),
                ).fetchall()
            else:
                data_rows = self._conn.execute(
                    """SELECT timestamp, value FROM indicators WHERE name = ?
                       ORDER BY timestamp ASC LIMIT ?""",
                    (ind_name, limit),
                ).fetchall()

            result[ind_name] = {
                "name": ind_name,
                "type": "line",
                "pane": meta["pane"],
                "color": meta["color"],
                "line_width": meta["line_width"],
                "levels": levels,
                "data": [{"time": row["timestamp"], "value": row["value"]} for row in data_rows],
            }
        return result

    # ------------------------------------------------------------------ #
    # Lifecycle                                                            #
    # ------------------------------------------------------------------ #

    def close(self) -> None:
        """Close the SQLite connection."""
        self._conn.close()
        log.info("StateManager closed: %s", self._path)
