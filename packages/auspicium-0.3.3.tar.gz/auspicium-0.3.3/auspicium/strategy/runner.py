"""StrategyRunner — async event loop that drives a Strategy subclass.

Responsibilities:
  - Load config.yaml and manifest.yaml from the strategy directory
  - Validate the environment (raises if AUSPICIUM_ENV=design)
  - Wire up PaperExchange / StateManager / RiskGuardian / StrategyMonitor
  - Run the WebSocket event loop, dispatch ticks, handle fills
  - Respond to SIGTERM with a clean shutdown

CLI usage::

    python -m auspicium.strategy.runner \\
        --strategy-dir ./strategies/my_strategy \\
        --strategy-class MyStrategy \\
        --log-level INFO

Or from Python::

    from auspicium.strategy.runner import StrategyRunner
    from my_strategy import MyStrategy

    runner = StrategyRunner(MyStrategy, strategy_dir="./strategies/my_strategy")
    asyncio.run(runner.run())
"""
from __future__ import annotations

import argparse
import asyncio
import importlib
import logging
import signal
import sys
from pathlib import Path
from typing import Type

import yaml

from auspicium.config import get_config
from auspicium.connectors.stream import StreamConnector
from auspicium.errors import AuspiciumError
from auspicium.strategy.base import Strategy
from auspicium.strategy.models import Fill, Portfolio
from auspicium.strategy.monitor import StrategyMonitor
from auspicium.strategy.paper import PaperExchange
from auspicium.strategy.risk import RiskGuardian
from auspicium.strategy.state import StateManager

log = logging.getLogger(__name__)


class StrategyRunner:
    """Drives a Strategy subclass through its full lifecycle.

    Args:
        strategy_cls:   The Strategy subclass to instantiate and run.
        config:         Optional dict of strategy params (overrides config.yaml).
        strategy_dir:   Path to the strategy directory (contains config.yaml,
                        manifest.yaml, and state.db will be created here).
                        Defaults to the current working directory.
    """

    def __init__(
        self,
        strategy_cls: Type[Strategy],
        config: dict | None = None,
        strategy_dir: str | Path | None = None,
    ) -> None:
        self._strategy_cls = strategy_cls
        self._strategy_dir = Path(strategy_dir) if strategy_dir else Path.cwd()
        self._shutdown_requested = False
        self._tick_count: int = 0

        # --- Load config.yaml and manifest.yaml ---
        strategy_config = self._load_yaml("config.yaml")
        if config:
            strategy_config.update(config)

        manifest = self._load_yaml("manifest.yaml")
        risk_limits = manifest.get("risk", {})

        # --- Validate environment ---
        cfg = get_config()
        if cfg.env == "design":
            raise AuspiciumError(
                "Set AUSPICIUM_ENV=quality to run live, "
                "or use auspicium.backtest for design mode"
            )

        # --- Create exchange adapter ---
        if cfg.env == "quality":
            self._exchange = PaperExchange(
                initial_cash=strategy_config.get("initial_cash", 10_000.0),
                fill_callback=None,  # registered below after strategy is created
            )
        else:
            # production — Phase 3 placeholder
            raise NotImplementedError(
                "Production exchange adapter not yet implemented (Phase 3)"
            )

        # --- Create supporting components ---
        db_path = self._strategy_dir / "state.db"
        self._state = StateManager(db_path)
        self._risk = RiskGuardian(risk_limits)

        # --- Instantiate strategy ---
        self._strategy = strategy_cls(
            config=strategy_config,
            exchange=self._exchange,
            state=self._state,
            risk=self._risk,
        )

        # --- Register fill callback AFTER strategy is created ---
        # Registering here (not in PaperExchange.__init__) ensures the callback
        # can close over self._strategy, which didn't exist at exchange creation time.
        self._exchange._fill_callback = self._on_fill

        # --- Call configure() so the strategy declares its subscriptions ---
        self._strategy.configure()

        # --- Create monitor (after configure so class name is final) ---
        self._monitor = StrategyMonitor(strategy_cls.__name__)

        log.info(
            "StrategyRunner initialised: strategy=%s env=%s dir=%s",
            strategy_cls.__name__, cfg.env, self._strategy_dir,
        )

    # ------------------------------------------------------------------ #
    # Lifecycle                                                             #
    # ------------------------------------------------------------------ #

    async def run(self) -> None:
        """Enter the WebSocket event loop and drive the strategy until shutdown."""
        # Install SIGTERM handler for graceful shutdown
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGTERM, self._request_shutdown)

        # Crash recovery: restore positions from SQLite
        saved_positions = self._state.load_positions()
        if saved_positions:
            self._strategy._portfolio.positions.update(saved_positions)
            log.info("Recovered %d positions from state DB", len(saved_positions))

        log.info("Starting event loop…")

        try:
            async with StreamConnector.connect() as ws:
                # Subscribe to all channels declared in configure()
                for sub in self._strategy._subscriptions:
                    channel = sub.get("channel", "")
                    source = sub.get("source", "")
                    symbol = sub.get("symbol", "")
                    await ws.subscribe(channel, source=source, symbol=symbol)
                    log.debug("Subscribed: channel=%s source=%s symbol=%s", channel, source, symbol)

                async for tick in ws:
                    if self._shutdown_requested:
                        break

                    # Set current tick time so emit_indicator() uses correct timestamp
                    self._strategy._last_tick_ts = tick.timestamp_ms // 1000

                    # Dispatch to strategy
                    try:
                        await self._strategy.on_data(tick)
                    except Exception as exc:
                        log.error("on_data raised an unhandled exception: %s", exc, exc_info=True)

                    # Check pending limit orders against current tick price
                    current_prices: dict[str, float] = {}
                    if tick.symbol and isinstance(tick.payload, dict):
                        price = (
                            tick.payload.get("close")
                            or tick.payload.get("price")
                            or tick.payload.get("yes_price")
                        )
                        if price is not None:
                            current_prices[tick.symbol] = float(price)
                    await self._exchange.check_pending_orders(current_prices)

                    # Update Prometheus metrics
                    self._monitor.update(
                        self._strategy._portfolio,
                        open_order_count=len(self._strategy._open_orders),
                    )

                    self._tick_count += 1

                    # Snapshot portfolio every ~60 ticks (cheap heuristic)
                    if self._tick_count % 60 == 0:
                        self._state.snapshot_portfolio(self._strategy._portfolio)

                    # Persist indicator values every 10 ticks
                    if self._tick_count % 10 == 0 and self._strategy._indicator_log:
                        self._state.record_indicators(self._strategy.indicators)

                    # Auto-kill if risk limits breached
                    if self._risk.should_auto_kill(self._strategy._portfolio):
                        log.error("Auto-kill triggered — shutting down")
                        break

        except Exception as exc:
            log.error("Event loop error: %s", exc, exc_info=True)
        finally:
            await self._strategy.on_shutdown()
            self._state.snapshot_portfolio(self._strategy._portfolio)
            self._state.close()
            log.info("StrategyRunner shut down cleanly.")

    def _request_shutdown(self) -> None:
        """Signal handler — request a clean shutdown after the next tick."""
        log.info("SIGTERM received — requesting shutdown after next tick")
        self._shutdown_requested = True

    # ------------------------------------------------------------------ #
    # Fill callback                                                         #
    # ------------------------------------------------------------------ #

    async def _on_fill(self, fill: Fill) -> None:
        """Called by PaperExchange after every simulated fill.

        Updates the strategy portfolio, persists the fill, notifies the
        strategy, and records the fill in Prometheus.
        """
        strategy = self._strategy
        portfolio = strategy._portfolio

        # Remove from open orders
        strategy._open_orders.pop(fill.order_id, None)

        # Update portfolio cash and positions from fill
        _apply_fill_to_portfolio(portfolio, fill)

        # Persist fill and updated positions
        self._state.record_fill(fill)
        for pos in portfolio.positions.values():
            self._state.update_position(pos)

        # Remove closed positions from DB
        # (a position is closed if it was removed from portfolio.positions by _apply_fill)
        # We detect this by comparing before/after — simpler: StateManager.remove_position
        # is called explicitly when we detect the position is gone.

        # Notify strategy
        try:
            await strategy.on_fill(fill)
        except Exception as exc:
            log.error("on_fill raised an unhandled exception: %s", exc, exc_info=True)

        # Record in Prometheus
        self._monitor.record_fill(fill)

    # ------------------------------------------------------------------ #
    # Helpers                                                               #
    # ------------------------------------------------------------------ #

    def _load_yaml(self, filename: str) -> dict:
        """Load a YAML file from the strategy directory. Returns {} if missing."""
        path = self._strategy_dir / filename
        if not path.exists():
            log.debug("%s not found in %s — using defaults", filename, self._strategy_dir)
            return {}
        try:
            return yaml.safe_load(path.read_text()) or {}
        except yaml.YAMLError as exc:
            log.warning("Failed to parse %s: %s", filename, exc)
            return {}


# ------------------------------------------------------------------ #
# Portfolio fill application                                           #
# ------------------------------------------------------------------ #

def _apply_fill_to_portfolio(portfolio: Portfolio, fill: Fill) -> None:
    """Apply a fill to a Portfolio in-place.

    Updates cash and positions. Called by the runner's fill callback.

    For BUY: deduct cost from cash, add/average into position.
    For SELL: add proceeds to cash, reduce/close position.
    Realized PnL and daily PnL are updated on close.
    """
    from auspicium.strategy.models import Position

    cost = fill.size * fill.price + fill.fee
    if fill.side == "BUY":
        portfolio.cash -= cost
        pos = portfolio.positions.get(fill.market)
        if pos is None:
            portfolio.positions[fill.market] = Position(
                market=fill.market,
                side="LONG",
                outcome=fill.outcome,
                size=fill.size,
                entry_price=fill.price,
            )
        else:
            total = pos.size + fill.size
            pos.entry_price = (pos.entry_price * pos.size + fill.price * fill.size) / total
            pos.size = total
    else:  # SELL
        proceeds = fill.size * fill.price - fill.fee
        portfolio.cash += proceeds
        pos = portfolio.positions.get(fill.market)
        if pos is not None:
            realized = (fill.price - pos.entry_price) * fill.size
            portfolio.realized_pnl += realized
            portfolio.daily_pnl += realized
            remaining = pos.size - fill.size
            if remaining <= 1e-9:
                del portfolio.positions[fill.market]
            else:
                pos.size = remaining
        else:
            # Short open
            portfolio.positions[fill.market] = Position(
                market=fill.market,
                side="SHORT",
                outcome=fill.outcome,
                size=fill.size,
                entry_price=fill.price,
            )


# ------------------------------------------------------------------ #
# CLI entry point                                                       #
# ------------------------------------------------------------------ #

def main() -> None:
    """CLI entry point for ``python -m auspicium.strategy.runner``."""
    parser = argparse.ArgumentParser(
        prog="auspicium.strategy.runner",
        description="Run an Auspicium trading strategy",
    )
    parser.add_argument(
        "--strategy-dir",
        default=".",
        help="Path to the strategy directory (contains config.yaml and manifest.yaml)",
    )
    parser.add_argument(
        "--strategy-class",
        required=True,
        help="Dotted import path to the Strategy subclass, e.g. my_strategy.MyStrategy",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging verbosity (default: INFO)",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)-8s %(name)s — %(message)s",
    )

    # Dynamically import the strategy class
    module_path, class_name = args.strategy_class.rsplit(".", 1)
    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        print(f"ERROR: Could not import module '{module_path}': {exc}", file=sys.stderr)
        sys.exit(1)

    strategy_cls = getattr(module, class_name, None)
    if strategy_cls is None:
        print(f"ERROR: Class '{class_name}' not found in module '{module_path}'", file=sys.stderr)
        sys.exit(1)

    if not issubclass(strategy_cls, Strategy):
        print(f"ERROR: '{class_name}' is not a subclass of Strategy", file=sys.stderr)
        sys.exit(1)

    runner = StrategyRunner(strategy_cls, strategy_dir=args.strategy_dir)
    asyncio.run(runner.run())


if __name__ == "__main__":
    main()
