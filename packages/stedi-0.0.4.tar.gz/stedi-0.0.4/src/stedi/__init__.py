"""The Stedi SDK for Python.

    from stedi import Stedi
    from stedi.payers import SearchPayersInput

    async with Stedi() as client:
        result = await client.payers.search_payers(
            SearchPayersInput(query="Aetna"),
        )
"""

from __future__ import annotations

import os
from typing import Any

from stedi_claims import Claims as _Claims
from stedi_payers import Payers as _Payers

from . import claims as claims
from . import payers as payers


class Stedi:
    """The Stedi SDK client.

    :param api_key: Your Stedi API key. If omitted, read from the
        ``STEDI_API_KEY`` environment variable.
    :param max_attempts: Maximum number of attempts per request, including
        the initial attempt. Default is ``3``. Pass ``1`` to disable retries.
    :raises ValueError: If neither ``api_key`` nor ``STEDI_API_KEY`` is set.
    """

    payers: _Payers
    claims: _Claims

    def __init__(
        self,
        *,
        api_key: str | None = None,
        max_attempts: int | None = None,
    ) -> None:
        resolved = api_key if api_key is not None else os.environ.get("STEDI_API_KEY")
        if not resolved:
            raise ValueError(
                "Stedi API key required. Pass `api_key=` to Stedi() or set "
                "STEDI_API_KEY in the environment."
            )
        kwargs: dict[str, Any] = {"api_key": resolved}
        if max_attempts is not None:
            kwargs["max_attempts"] = max_attempts
        self.payers = _Payers(**kwargs)
        self.claims = _Claims(**kwargs)

    async def aclose(self) -> None:
        """Close all underlying HTTP transports."""
        await self.payers.aclose()
        await self.claims.aclose()

    async def __aenter__(self) -> Stedi:
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()


__version__: str = "0.0.4"

__all__ = ["Stedi", "__version__", "claims", "payers"]
