"""The Stedi Payers SDK for Python.

    from stedi_payers import Payers, SearchPayersInput

    async with Payers() as client:
        response = await client.search_payers(SearchPayersInput(query="Aetna"))
"""

from __future__ import annotations

import os
from typing import Any

from smithy_core.interfaces.retries import RetryStrategy as RetryStrategy
from smithy_core.retries import SimpleRetryStrategy as SimpleRetryStrategy
from smithy_http.aio.aiohttp import AIOHTTPClient
from smithy_http.aio.identity.apikey import APIKeyIdentityResolver

from .client import Payers as _Payers
from .config import Config
from .models import SearchPayersInput as SearchPayersInput
from .models import SearchPayersOutput as SearchPayersOutput

_ENDPOINT_URI = "https://payers.us.stedi.com"


class _SharedTransport(AIOHTTPClient):
    """Returns self from ``__deepcopy__`` so the underlying aiohttp session
    is shared across the deepcopy-per-call that smithy-python's generated
    client performs. Without this, every operation mints a fresh session
    that's never closed."""

    def __deepcopy__(self, memo: dict[int, object]) -> _SharedTransport:
        return self


class Payers(_Payers):
    """Stedi Payers SDK client.

    :param api_key: Your Stedi API key. If omitted, read from the
        ``STEDI_API_KEY`` environment variable.
    :param max_attempts: Maximum number of attempts per request, including
        the initial attempt. Default is ``3``. Pass ``1`` to disable retries.
    :param retry_strategy: Advanced override. Pass a custom
        :class:`RetryStrategy` to fully control retry behavior; takes
        precedence over ``max_attempts``.
    :raises ValueError: If neither ``api_key`` nor ``STEDI_API_KEY`` is set.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        max_attempts: int | None = None,
        retry_strategy: RetryStrategy | None = None,
    ) -> None:
        resolved = api_key if api_key is not None else os.environ.get("STEDI_API_KEY")
        if not resolved:
            raise ValueError(
                "Stedi API key required. Pass `api_key=` to Payers() or set "
                "STEDI_API_KEY in the environment."
            )
        config_kwargs: dict[str, Any] = {
            "api_key": resolved,
            "endpoint_uri": _ENDPOINT_URI,
            "transport": _SharedTransport(),
        }
        if retry_strategy is not None:
            config_kwargs["retry_strategy"] = retry_strategy
        elif max_attempts is not None:
            config_kwargs["retry_strategy"] = SimpleRetryStrategy(max_attempts=max_attempts)
        config = Config(**config_kwargs)
        config.api_key_identity_resolver = APIKeyIdentityResolver()
        super().__init__(config=config)

    async def aclose(self) -> None:
        """Close the underlying HTTP transport."""
        transport = getattr(self._config, "transport", None)
        if transport is not None:
            session = getattr(transport, "_session", None)
            if session is not None and not session.closed:
                await session.close()

    async def __aenter__(self) -> Payers:
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()


__version__: str = "0.0.4"

__all__ = [
    "Payers",
    "RetryStrategy",
    "SearchPayersInput",
    "SearchPayersOutput",
    "SimpleRetryStrategy",
    "__version__",
]
