"""The Stedi Claims SDK for Python.

    from stedi_claims import Claims, ClaimsCms1500SubmissionInput

    async with Claims() as client:
        response = await client.claims_cms1500_submission(ClaimsCms1500SubmissionInput(...))
"""

from __future__ import annotations

import os
from typing import Any

from smithy_core.interfaces.retries import RetryStrategy as RetryStrategy
from smithy_core.retries import SimpleRetryStrategy as SimpleRetryStrategy
from smithy_http.aio.aiohttp import AIOHTTPClient
from smithy_http.aio.identity.apikey import APIKeyIdentityResolver

from .client import Claims as _Claims
from .config import Config
from .models import ClaimsCms1500SubmissionInput as ClaimsCms1500SubmissionInput
from .models import ClaimsCms1500SubmissionOutput as ClaimsCms1500SubmissionOutput

_ENDPOINT_URI = "https://claims.us.stedi.com"


class _SharedTransport(AIOHTTPClient):
    """Returns self from ``__deepcopy__`` so the underlying aiohttp session
    is shared across the deepcopy-per-call that smithy-python's generated
    client performs. Without this, every operation mints a fresh session
    that's never closed."""

    def __deepcopy__(self, memo: dict[int, object]) -> _SharedTransport:
        return self


class Claims(_Claims):
    """Stedi Claims SDK client.

    :param api_key: Your Stedi API key. If omitted, read from the
        ``STEDI_API_KEY`` environment variable.
    :param max_attempts: Maximum number of attempts per request, including
        the initial attempt. Default is ``3``. Pass ``1`` to disable retries.
    :param retry_strategy: Advanced override. Pass a custom
        :class:`RetryStrategy` to fully control retry behavior; takes
        precedence over ``max_attempts``.
    :raises ValueError: If neither ``api_key`` nor ``STEDI_API_KEY`` is set.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        max_attempts: int | None = None,
        retry_strategy: RetryStrategy | None = None,
    ) -> None:
        resolved = api_key if api_key is not None else os.environ.get("STEDI_API_KEY")
        if not resolved:
            raise ValueError(
                "Stedi API key required. Pass `api_key=` to Claims() or set "
                "STEDI_API_KEY in the environment."
            )
        config_kwargs: dict[str, Any] = {
            "api_key": resolved,
            "endpoint_uri": _ENDPOINT_URI,
            "transport": _SharedTransport(),
        }
        if retry_strategy is not None:
            config_kwargs["retry_strategy"] = retry_strategy
        elif max_attempts is not None:
            config_kwargs["retry_strategy"] = SimpleRetryStrategy(max_attempts=max_attempts)
        config = Config(**config_kwargs)
        config.api_key_identity_resolver = APIKeyIdentityResolver()
        super().__init__(config=config)

    async def aclose(self) -> None:
        """Close the underlying HTTP transport."""
        transport = getattr(self._config, "transport", None)
        if transport is not None:
            session = getattr(transport, "_session", None)
            if session is not None and not session.closed:
                await session.close()

    async def __aenter__(self) -> Claims:
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()


__version__: str = "0.0.4"

__all__ = [
    "Claims",
    "ClaimsCms1500SubmissionInput",
    "ClaimsCms1500SubmissionOutput",
    "RetryStrategy",
    "SimpleRetryStrategy",
    "__version__",
]
