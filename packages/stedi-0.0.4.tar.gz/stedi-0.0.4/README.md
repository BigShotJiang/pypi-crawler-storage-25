# stedi

The Stedi SDK for Python.

## Install

```sh
pip install stedi
# or
uv add stedi
```

## Usage

```python
from stedi import Stedi
from stedi.payers import SearchPayersInput
from stedi.claims import ClaimsCms1500SubmissionInput

# `STEDI_API_KEY` is read from os.environ automatically.
async with Stedi() as client:
    # Payers
    payers = await client.payers.search_payers(
        SearchPayersInput(query="Aetna"),
    )

    # Claims (production key required for submission)
    claim = await client.claims.claims_cms1500_submission(
        ClaimsCms1500SubmissionInput(...),
    )
```

Get an API key from [your Stedi account](https://www.stedi.com/app).

## More examples

[github.com/Stedi/sdk/tree/main/examples/python](https://github.com/Stedi/sdk/tree/main/examples/python)

## Docs

- [docs.stedi.com](https://docs.stedi.com)
- [Source](https://github.com/Stedi/sdk)
- [Report an issue](https://github.com/Stedi/sdk/issues)

## License

Apache-2.0
