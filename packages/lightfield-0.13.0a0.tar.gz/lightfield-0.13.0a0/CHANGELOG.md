# Changelog

## 0.13.0-alpha (2026-05-22)

Full Changelog: [v0.12.0-alpha...v0.13.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.12.0-alpha...v0.13.0-alpha)

### Features

* **api:** Email API release ([e3f681b](https://github.com/Lightfld/lightfield-python/commit/e3f681b85c0a8400680dcd31e7f4ec236b1f7e2b))
* **api:** fix email request body to messageBody ([1d8b38c](https://github.com/Lightfld/lightfield-python/commit/1d8b38cdfac00e895d78902c41a1dc29de57fea3))

## 0.12.0-alpha (2026-05-21)

Full Changelog: [v0.11.0-alpha...v0.12.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.11.0-alpha...v0.12.0-alpha)

### Features

* **api:** allow email get + send API ([8a329f1](https://github.com/Lightfld/lightfield-python/commit/8a329f1463bde9333b9b2b5482226f8293dee672))

## 0.11.0-alpha (2026-05-21)

Full Changelog: [v0.10.0-alpha...v0.11.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.10.0-alpha...v0.11.0-alpha)

### Features

* **api:** release email API ([cf48229](https://github.com/Lightfld/lightfield-python/commit/cf48229caedc959e1f273ea7428c374033d8e36a))
* **internal/types:** support eagerly validating pydantic iterators ([4494960](https://github.com/Lightfld/lightfield-python/commit/4494960e807444469a1076bd773138afc6c9deda))


### Bug Fixes

* **client:** add missing f-string prefix in file type error message ([ddc3f05](https://github.com/Lightfld/lightfield-python/commit/ddc3f0577b85282dadb46e09937dcfa1c77d7b2b))


### Chores

* update SDK settings ([717f01b](https://github.com/Lightfld/lightfield-python/commit/717f01bf647490ffdde2ffc2faa542037731ffcc))
* update SDK settings ([b142251](https://github.com/Lightfld/lightfield-python/commit/b1422510fbf30742a7447aba26124bca1fd4ccf6))

## 0.10.0-alpha (2026-05-06)

Full Changelog: [v0.9.0-alpha...v0.10.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.9.0-alpha...v0.10.0-alpha)

### Features

* **api:** manual updates to test custom objects ([41fbcb6](https://github.com/Lightfld/lightfield-python/commit/41fbcb66f8ad14a3b408880f1283719e4e1e74c0))
* **api:** validate endpoint ([e4f221f](https://github.com/Lightfld/lightfield-python/commit/e4f221fc4a4a9aef73f87d7104aac2c74d980a20))
* support setting headers via env ([5e392af](https://github.com/Lightfld/lightfield-python/commit/5e392af7f32e7abadef5120356ab1ad8d682f804))


### Bug Fixes

* use correct field name format for multipart file arrays ([678eff7](https://github.com/Lightfld/lightfield-python/commit/678eff786a7fb5fcfb86c0239a71b35c6a838f98))


### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([035c82d](https://github.com/Lightfld/lightfield-python/commit/035c82d3321e0815b2c3873b0e04c5db7f855883))


### Chores

* **internal:** more robust bootstrap script ([7a73cba](https://github.com/Lightfld/lightfield-python/commit/7a73cba8abbc7a1c2e810b48c82eb4534f68a438))
* **internal:** reformat pyproject.toml ([b484f4d](https://github.com/Lightfld/lightfield-python/commit/b484f4d0f83ff97d2aa5dbdcbf2b8469c0573187))
* **tests:** bump steady to v0.22.1 ([797f442](https://github.com/Lightfld/lightfield-python/commit/797f442389ed62bd77d31c6c094540cd0540e024))

## 0.9.0-alpha (2026-04-18)

Full Changelog: [v0.8.1-alpha...v0.9.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.8.1-alpha...v0.9.0-alpha)

### Features

* **api:** tighten object API field schemas and named OpenAPI models ([e126fcd](https://github.com/Lightfld/lightfield-python/commit/e126fcd82c163bfdc8d8e0ebfb27238562713a78))


### Bug Fixes

* **api:** improve typing on JSON fields ([524af02](https://github.com/Lightfld/lightfield-python/commit/524af0262dba701eae2c47d85adebd06f72dc139))
* ensure file data are only sent as 1 parameter ([b4ea9d1](https://github.com/Lightfld/lightfield-python/commit/b4ea9d105abb7ed84dad86579e9cd426bca58c7f))


### Chores

* **api:** clean named schemas, safer sdk generation ([d5df68b](https://github.com/Lightfld/lightfield-python/commit/d5df68b0372bebd931a9c6c6a7128a633215f6da))
* remove custom code ([538f874](https://github.com/Lightfld/lightfield-python/commit/538f874da7cd4b8182ee071c55d6548eea9fbe28))

## 0.8.1-alpha (2026-04-09)

Full Changelog: [v0.8.0-alpha...v0.8.1-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.8.0-alpha...v0.8.1-alpha)

### Chores

* **api:** update file endpoint docs ([10acb75](https://github.com/Lightfld/lightfield-python/commit/10acb75e2bf55edc536d956976e755f3360038a7))

## 0.8.0-alpha (2026-04-09)

Full Changelog: [v0.7.0-alpha...v0.8.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.7.0-alpha...v0.8.0-alpha)

### Features

* **api:** add meetings and files endpoints ([46022ac](https://github.com/Lightfld/lightfield-python/commit/46022ace6a29e35583854b92d3fe951f6154c141))


### Bug Fixes

* **api:** untyped fields for typescript ([70bc78e](https://github.com/Lightfld/lightfield-python/commit/70bc78efa05c5e085240530a7e1a58008aac782f))
* **client:** preserve hardcoded query params when merging with user params ([d10f91c](https://github.com/Lightfld/lightfield-python/commit/d10f91c4e3d93e6bdc144158a0244cc97cbe39af))

## 0.7.0-alpha (2026-04-04)

Full Changelog: [v0.6.1-alpha...v0.7.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.6.1-alpha...v0.7.0-alpha)

### Features

* **api:** manual updates ([01c4f5e](https://github.com/Lightfld/lightfield-python/commit/01c4f5e7c059b28567567ec4643b6d70e4a056d9))


### Chores

* **api:** add lists documentation ([f4ca427](https://github.com/Lightfld/lightfield-python/commit/f4ca427d925879ab075f87802d93da93386de4fa))

## 0.6.1-alpha (2026-04-03)

Full Changelog: [v0.6.0-alpha...v0.6.1-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.6.0-alpha...v0.6.1-alpha)

### Chores

* **api:** update note documentation ([8f00d47](https://github.com/Lightfld/lightfield-python/commit/8f00d47d2ab76ef6a1e70b416b81253b489764c8))

## 0.6.0-alpha (2026-04-03)

Full Changelog: [v0.5.3-alpha...v0.6.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.5.3-alpha...v0.6.0-alpha)

### Features

* **api:** add notes and lists API ([7660644](https://github.com/Lightfld/lightfield-python/commit/7660644bbe60ab0c3791c714052bbc19772015ce))
* **internal:** implement indices array format for query and form serialization ([8963bdc](https://github.com/Lightfld/lightfield-python/commit/8963bdcb4db4ce2524df96f46d5bcdb4b30d9ef4))


### Chores

* **tests:** bump steady to v0.20.1 ([9bc928b](https://github.com/Lightfld/lightfield-python/commit/9bc928bda5081719ae476788de41c6095613b8de))
* **tests:** bump steady to v0.20.2 ([0f70443](https://github.com/Lightfld/lightfield-python/commit/0f70443402e2f737541672f59d739b371ca4cc1f))

## 0.5.3-alpha (2026-03-25)

Full Changelog: [v0.5.2-alpha...v0.5.3-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.5.2-alpha...v0.5.3-alpha)

### Chores

* **ci:** skip lint on metadata-only changes ([4c79a2f](https://github.com/Lightfld/lightfield-python/commit/4c79a2f12ad995dd2ca9c69d74809f614c8bc0d1))
* **internal:** update gitignore ([3da348c](https://github.com/Lightfld/lightfield-python/commit/3da348caeae6362ed39391352ed9c8e419477a57))
* **tests:** bump steady to v0.19.4 ([d79751c](https://github.com/Lightfld/lightfield-python/commit/d79751c68edc2afae2cb8bda49c72235715071f0))
* **tests:** bump steady to v0.19.5 ([71a9c92](https://github.com/Lightfld/lightfield-python/commit/71a9c928a0854a3a019ade2e0ee80403285d5064))
* **tests:** bump steady to v0.19.6 ([76df449](https://github.com/Lightfld/lightfield-python/commit/76df449745e38405e66f8cfeb879883861e44178))
* **tests:** bump steady to v0.19.7 ([09b6fb0](https://github.com/Lightfld/lightfield-python/commit/09b6fb0fd46adbc7f2eb8a4ed8598e8814c81338))

## 0.5.2-alpha (2026-03-20)

Full Changelog: [v0.5.1-alpha...v0.5.2-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.5.1-alpha...v0.5.2-alpha)

### Bug Fixes

* **api:** resolve system and custom attribute collision error ([2c95b87](https://github.com/Lightfld/lightfield-python/commit/2c95b870461ce287cb7f4782d829c4d3918c93cd))


### Chores

* remove custom code ([0788362](https://github.com/Lightfld/lightfield-python/commit/0788362d21e83815a627ca9ec1ea8e4f37376311))

## 0.5.1-alpha (2026-03-20)

Full Changelog: [v0.5.0-alpha...v0.5.1-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.5.0-alpha...v0.5.1-alpha)

### Chores

* **api:** add response model refs ([2f362a4](https://github.com/Lightfld/lightfield-python/commit/2f362a475bb440810e9074c6a704c910b871ea62))

## 0.5.0-alpha (2026-03-20)

Full Changelog: [v0.4.1-alpha...v0.5.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.4.1-alpha...v0.5.0-alpha)

### Features

* **api:** add field/relationship param descriptions ([c0d5646](https://github.com/Lightfld/lightfield-python/commit/c0d5646ce73488ce29f991edc7037c536b0715a7))
* **api:** manual updates ([f8b635f](https://github.com/Lightfld/lightfield-python/commit/f8b635f37648fef559e5d28701090c345f5a80c8))
* **api:** manual updates ([2cb65c0](https://github.com/Lightfld/lightfield-python/commit/2cb65c0dc0283902518b3dbc151b5d198bbf4259))
* **api:** member and workflow run ([4db8977](https://github.com/Lightfld/lightfield-python/commit/4db8977034353cb65c1bda864486a99bab94fd74))
* **api:** update field descriptions, plural to singular keys, change READONLY_MARKDOWN type to MARKDOWN ([047faa5](https://github.com/Lightfld/lightfield-python/commit/047faa5486b0987f20bfb39128a5a80df70ca07b))


### Bug Fixes

* sanitize endpoint path params ([b5f80c1](https://github.com/Lightfld/lightfield-python/commit/b5f80c1659fa78337c79f3e99ef70358d2815f52))


### Chores

* configure new SDK language ([8789568](https://github.com/Lightfld/lightfield-python/commit/8789568a672c1e97f07e0c677cb31f30b38b74db))


### Refactors

* **tests:** switch from prism to steady ([3736973](https://github.com/Lightfld/lightfield-python/commit/37369738b4e43dd29d80618293ac4916308a37e6))

## 0.4.1-alpha (2026-03-17)

Full Changelog: [v0.4.0-alpha...v0.4.1-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.4.0-alpha...v0.4.1-alpha)

### Chores

* update SDK settings ([8b419d7](https://github.com/Lightfld/lightfield-python/commit/8b419d76793dbda1156321d11953da18408070f0))
* update SDK settings ([29c79bc](https://github.com/Lightfld/lightfield-python/commit/29c79bcae7114b05fc85a10e3d4a9d3d1e9c0985))

## 0.4.0-alpha (2026-03-17)

Full Changelog: [v0.3.0-alpha...v0.4.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.3.0-alpha...v0.4.0-alpha)

### Features

* **api:** shorten system attribute prefixes, add attribute definition endpoint ([6898ed2](https://github.com/Lightfld/lightfield-python/commit/6898ed2e5f969af28c4b48627bf54dc2d329af14))


### Chores

* update SDK settings ([435006a](https://github.com/Lightfld/lightfield-python/commit/435006af8efbcdb4cd55d79c4b0e0e19e3fd57b5))
* update SDK settings ([cfd6529](https://github.com/Lightfld/lightfield-python/commit/cfd65297eb0df88c3ddb0e6c8089f22ec7fcaef0))

## 0.3.0-alpha (2026-03-17)

Full Changelog: [v0.2.0-alpha...v0.3.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.2.0-alpha...v0.3.0-alpha)

### Features

* **api:** add Go SDK and CLI targets to Stainless config ([905fbd3](https://github.com/Lightfld/lightfield-python/commit/905fbd38bd049c8bd70e40f1ca77ec4dab46ceec))

## 0.2.0-alpha (2026-03-17)

Full Changelog: [v0.1.0-alpha...v0.2.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.1.0-alpha...v0.2.0-alpha)

### Features

* Add lightfield version header ([a47de18](https://github.com/Lightfld/lightfield-python/commit/a47de188ce7157e8d034f146491b0d495a1d4f69))
* **api:** rename response fields for camelCase consistency and cleaner relationship keys ([e9d1fba](https://github.com/Lightfld/lightfield-python/commit/e9d1fba77dbbe504c5fdc26c32861d480ddd07a9))
* Migrate relationship fixes and translation layer logic to monorepo ([897d417](https://github.com/Lightfld/lightfield-python/commit/897d417aaf16026ff8741115cccad02971da2fd1))


### Bug Fixes

* **api:** add minimum to total count ([c25bb69](https://github.com/Lightfld/lightfield-python/commit/c25bb69869b85d9a1de5b1ab4be057d63d657954))
* **deps:** bump minimum typing-extensions version ([49c73de](https://github.com/Lightfld/lightfield-python/commit/49c73de636fdaf52be52ea08dba073c50262abfc))
* **pydantic:** do not pass `by_alias` unless set ([00d8c6d](https://github.com/Lightfld/lightfield-python/commit/00d8c6d8dc026ef97627b956f2a6cfccff15b812))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([b4b3cd0](https://github.com/Lightfld/lightfield-python/commit/b4b3cd005df634c433ddc2caf29ca0cd7354bae8))
* **internal:** tweak CI branches ([37c323d](https://github.com/Lightfld/lightfield-python/commit/37c323db6bd39279a1cf4cdc1798636124e71fc5))
* remove custom code ([764f496](https://github.com/Lightfld/lightfield-python/commit/764f496eb6d032f94f1da4ae4ed053d6e96393f9))
* update SDK settings ([03c0b5d](https://github.com/Lightfld/lightfield-python/commit/03c0b5d9c83d918d1276ae2cec24f5537e15baf4))
* update SDK settings ([5887798](https://github.com/Lightfld/lightfield-python/commit/588779846c3d17539ef34ca543ba4c5502ebe735))
* update SDK settings ([a0bcca3](https://github.com/Lightfld/lightfield-python/commit/a0bcca38f83f827a374c73bd5984848e5cc9364d))
* update SDK settings ([053fb56](https://github.com/Lightfld/lightfield-python/commit/053fb56ff86d5a3e043da330cd97e57e82691070))
* update SDK settings ([b02c497](https://github.com/Lightfld/lightfield-python/commit/b02c497b4b5ada2118734706fedc483ae74568b4))


### Refactors

* update api fields ([3bce3f0](https://github.com/Lightfld/lightfield-python/commit/3bce3f0d372d0296b3621f071f226b9bea5b4687))

## 0.1.0-alpha (2026-03-07)

Full Changelog: [v0.0.1...v0.1.0-alpha](https://github.com/Lightfld/lightfield-python/compare/v0.0.1...v0.1.0-alpha)

### Features

* **api:** manual update - split up endpoints and harden schemas ([ddfa8da](https://github.com/Lightfld/lightfield-python/commit/ddfa8da2714c874d4e4bd617cf24353a128f23cc))
* **api:** manual updates ([d699c8c](https://github.com/Lightfld/lightfield-python/commit/d699c8c22c87a33ca0a9d761bc67e77f84ea17af))
* **api:** manual updates ([807c1ac](https://github.com/Lightfld/lightfield-python/commit/807c1ac1e1b5bfa50b89a5172ad001533738bb65))
* **api:** manual updates ([6d6db6c](https://github.com/Lightfld/lightfield-python/commit/6d6db6c14f97d4ae2565ad1ce13132ab7163795d))


### Chores

* configure new SDK language ([078c58b](https://github.com/Lightfld/lightfield-python/commit/078c58b97819ca30245a35851cea1c1d89b95893))
* configure new SDK language ([2e251a4](https://github.com/Lightfld/lightfield-python/commit/2e251a4b900102671a8004b8c344bc97edd5401d))
* update SDK settings ([8ac4102](https://github.com/Lightfld/lightfield-python/commit/8ac4102852bd4a46f1af4f3070c114f563483905))
* update SDK settings ([2740ec3](https://github.com/Lightfld/lightfield-python/commit/2740ec3eba755516cb5db0e44d96dca81407ea2d))
* update SDK settings ([5725ac1](https://github.com/Lightfld/lightfield-python/commit/5725ac17fd2fbbb10a5721a0b03b0e584db41f27))
* update SDK settings ([c3d8388](https://github.com/Lightfld/lightfield-python/commit/c3d83883a671e7945d713f18f58be4cee4bccdcd))
* update SDK settings ([ff1d73c](https://github.com/Lightfld/lightfield-python/commit/ff1d73c367590d0a578519bce74c49fc608303bb))
* update SDK settings ([3bd4e46](https://github.com/Lightfld/lightfield-python/commit/3bd4e466acd4555e98e7049ca0c1fc17e7f62b4a))
* update SDK settings ([b1bed0e](https://github.com/Lightfld/lightfield-python/commit/b1bed0efbd5ec5100e12bc87b17d32546c7bb255))
* update SDK settings ([5bdad3c](https://github.com/Lightfld/lightfield-python/commit/5bdad3c9d8713ac4a996224aaf707c7847be379f))
