# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "OpportunityCreateParams",
    "FieldsUntypedFieldsUntypedItem",
    "FieldsUntypedFieldsUntypedItemAddress",
    "FieldsUntypedFieldsUntypedItemFullName",
]


class OpportunityCreateParams(TypedDict, total=False):
    fields: Required[Union[Dict[str, Optional[FieldsUntypedFieldsUntypedItem]]]]
    """Field values for the new opportunity.

    System fields use a `$` prefix (e.g. `$name`, `$stage`); custom attributes use
    their bare slug. Required: `$name` (string) and `$stage` (option ID or label).
    Fields of type `SINGLE_SELECT` or `MULTI_SELECT` accept either an option ID or
    label from the field's `typeConfiguration.options` — call the
    <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u> to
    discover available fields and options. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Required[Union[Dict[str, Union[str, SequenceNotStr[str]]]]]
    """Relationships to set on the new opportunity.

    System relationships use a `$` prefix (e.g. `$account`, `$owner`); custom
    relationships use their bare slug. `$account` is required. Each value is a
    single entity ID or an array of IDs. Call the
    <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u> to
    list available relationship keys.
    """


class FieldsUntypedFieldsUntypedItemAddress(TypedDict, total=False):
    city: Optional[str]
    """City name."""

    country: Optional[str]
    """2-letter ISO 3166-1 alpha-2 country code."""

    latitude: Optional[float]
    """Latitude coordinate."""

    longitude: Optional[float]
    """Longitude coordinate."""

    postal_code: Annotated[Optional[str], PropertyInfo(alias="postalCode")]
    """Postal or ZIP code."""

    state: Optional[str]
    """State or province."""

    street: Optional[str]
    """Street address line 1."""

    street2: Optional[str]
    """Street address line 2."""


class FieldsUntypedFieldsUntypedItemFullName(TypedDict, total=False):
    first_name: Annotated[Optional[str], PropertyInfo(alias="firstName")]
    """The contact's first name."""

    last_name: Annotated[Optional[str], PropertyInfo(alias="lastName")]
    """The contact's last name."""


FieldsUntypedFieldsUntypedItem: TypeAlias = Union[
    str, float, bool, SequenceNotStr[str], FieldsUntypedFieldsUntypedItemAddress, FieldsUntypedFieldsUntypedItemFullName
]
