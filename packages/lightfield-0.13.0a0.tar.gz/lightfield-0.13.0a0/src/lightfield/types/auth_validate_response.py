# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["AuthValidateResponse"]


class AuthValidateResponse(BaseModel):
    active: bool
    """Whether the current API key is valid. Always `true` on successful responses."""

    scopes: List[str]
    """Granted public scopes for the current API key.

    Empty when the key has full access.
    """

    subject_type: Literal["user", "workspace"] = FieldInfo(alias="subjectType")
    """Whether the API key belongs to a `user` or `workspace`."""

    token_type: Literal["api_key"] = FieldInfo(alias="tokenType")
    """Credential family, always `api_key`."""
