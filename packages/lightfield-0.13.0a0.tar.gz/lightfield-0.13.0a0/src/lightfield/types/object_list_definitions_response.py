# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ObjectListDefinitionsResponse", "Data"]


class Data(BaseModel):
    label: str
    """Human-readable display name."""

    object_type: str = FieldInfo(alias="objectType")
    """The slug used to reference this object type in the API."""


class ObjectListDefinitionsResponse(BaseModel):
    data: List[Data]
    """All object types available to the caller."""
