# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["FileCompleteParams"]


class FileCompleteParams(TypedDict, total=False):
    md5: str
    """Optional MD5 hex digest of the uploaded file for checksum verification."""
