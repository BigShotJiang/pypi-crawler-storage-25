# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["MeetingUpdateParams", "Fields", "Relationships", "RelationshipsTranscript"]


class MeetingUpdateParams(TypedDict, total=False):
    fields: Fields
    """Field values to update.

    Only `$privacySetting` is writable, and omitted fields are left unchanged.
    """

    relationships: Relationships
    """Relationship operations to apply.

    Only `$transcript.replace` is supported; removing or clearing `$transcript` is
    not supported.
    """


class Fields(TypedDict, total=False):
    """Field values to update.

    Only `$privacySetting` is writable, and omitted fields are left unchanged.
    """

    privacy_setting: Required[Annotated[Optional[Literal["FULL", "METADATA"]], PropertyInfo(alias="$privacySetting")]]
    """The privacy setting for the meeting."""


class RelationshipsTranscript(TypedDict, total=False):
    replace: Required[str]
    """The file ID to set as the meeting transcript."""


class Relationships(TypedDict, total=False):
    """Relationship operations to apply.

    Only `$transcript.replace` is supported; removing or clearing `$transcript` is not supported.
    """

    transcript: Required[Annotated[RelationshipsTranscript, PropertyInfo(alias="$transcript")]]
