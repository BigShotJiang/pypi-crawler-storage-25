# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["TaskCreateParams", "Fields"]


class TaskCreateParams(TypedDict, total=False):
    fields: Required[Fields]
    """Field values for the new task.

    Tasks only support the documented system fields, all prefixed with `$` (e.g.
    `$title`, `$status`). Required: `$title` (string) and `$status` (one of `TODO`,
    `IN_PROGRESS`, `COMPLETE`, `CANCELLED`). Call the
    <u>[definitions endpoint](/api/resources/task/methods/definitions)</u> to
    discover the available fields. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Required[Union[Dict[str, Union[str, SequenceNotStr[str]]]]]
    """Relationships to set on the new task.

    System relationships use a `$` prefix (e.g. `$account`, `$assignedTo`); custom
    relationships use their bare slug. `$assignedTo` is required. Each value is a
    single entity ID or an array of IDs. Call the
    <u>[definitions endpoint](/api/resources/task/methods/definitions)</u> to list
    available relationship keys.
    """


class Fields(TypedDict, total=False):
    """Field values for the new task.

    Tasks only support the documented system fields, all prefixed with `$` (e.g. `$title`, `$status`). Required: `$title` (string) and `$status` (one of `TODO`, `IN_PROGRESS`, `COMPLETE`, `CANCELLED`). Call the <u>[definitions endpoint](/api/resources/task/methods/definitions)</u> to discover the available fields. See <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for value type details.
    """

    status: Required[Annotated[str, PropertyInfo(alias="$status")]]
    """Task status. One of: `TODO`, `IN_PROGRESS`, `COMPLETE`, `CANCELLED`."""

    title: Required[Annotated[str, PropertyInfo(alias="$title")]]
    """Title of the task."""

    description: Annotated[Optional[str], PropertyInfo(alias="$description")]
    """Description of the task in markdown format."""

    due_at: Annotated[Optional[str], PropertyInfo(alias="$dueAt")]
    """Due date as an ISO 8601 datetime string."""
