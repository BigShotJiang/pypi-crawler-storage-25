# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["ObjectUpdateParams", "Fields", "FieldsAddress", "FieldsFullName", "Relationships"]


class ObjectUpdateParams(TypedDict, total=False):
    entity_slug: Required[Annotated[str, PropertyInfo(alias="entitySlug")]]
    """The slug of the custom object type."""

    fields: Dict[str, Optional[Fields]]
    """Field names to values. Only provided fields are modified."""

    relationships: Dict[str, Relationships]
    """Relationship names to operations (`add`, `remove`, or `replace`)."""


class FieldsAddress(TypedDict, total=False):
    city: Optional[str]
    """City name."""

    country: Optional[str]
    """2-letter ISO 3166-1 alpha-2 country code."""

    latitude: Optional[float]
    """Latitude coordinate."""

    longitude: Optional[float]
    """Longitude coordinate."""

    postal_code: Annotated[Optional[str], PropertyInfo(alias="postalCode")]
    """Postal or ZIP code."""

    state: Optional[str]
    """State or province."""

    street: Optional[str]
    """Street address line 1."""

    street2: Optional[str]
    """Street address line 2."""


class FieldsFullName(TypedDict, total=False):
    first_name: Annotated[Optional[str], PropertyInfo(alias="firstName")]
    """The contact's first name."""

    last_name: Annotated[Optional[str], PropertyInfo(alias="lastName")]
    """The contact's last name."""


Fields: TypeAlias = Union[str, float, bool, SequenceNotStr[str], FieldsAddress, FieldsFullName]


class Relationships(TypedDict, total=False):
    """An operation to modify a relationship.

    Provide one of `add`, `remove`, or `replace`.
    """

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str], None]
    """A single entity ID or an array of entity IDs."""
