# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["EmailDraftParams", "MessageBody"]


class EmailDraftParams(TypedDict, total=False):
    from_: Required[Annotated[str, PropertyInfo(alias="from")]]
    """Bare email address (no display name).

    Must match a connected email account owned by the API key user. Compared
    case-insensitively. Mailbox where the draft is created.
    """

    attachments: SequenceNotStr[str]
    """Optional list of file IDs (uploaded via the Files API) to attach to the draft.

    Maximum 5 attachments per draft, each ≤ 3MB.
    """

    bcc: SequenceNotStr[str]
    """Bcc recipients (same shape as `to`)."""

    cc: SequenceNotStr[str]
    """Cc recipients (same shape as `to`)."""

    message_body: Annotated[MessageBody, PropertyInfo(alias="messageBody")]
    """Email message body (HTML or plain text)."""

    subject: str
    """Email subject."""

    to: SequenceNotStr[str]
    """Recipient email addresses (bare, no display names). Up to 500."""


class MessageBody(TypedDict, total=False):
    """Email message body (HTML or plain text)."""

    content: Required[str]
    """Email body content."""

    content_type: Annotated[Literal["HTML", "TEXT"], PropertyInfo(alias="contentType")]
    """Defaults to `HTML`."""
