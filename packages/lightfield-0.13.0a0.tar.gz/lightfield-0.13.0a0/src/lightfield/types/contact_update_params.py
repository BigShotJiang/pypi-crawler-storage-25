# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from typing_extensions import Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "ContactUpdateParams",
    "FieldsUntypedFieldsUntypedItem",
    "FieldsUntypedFieldsUntypedItemAddress",
    "FieldsUntypedFieldsUntypedItemFullName",
    "RelationshipsUntypedRelationshipsUntypedItem",
]


class ContactUpdateParams(TypedDict, total=False):
    fields: Union[Dict[str, Optional[FieldsUntypedFieldsUntypedItem]]]
    """
    Field values to update — only provided fields are modified; omitted fields are
    left unchanged. System fields use a `$` prefix (e.g. `$email`); custom
    attributes use their bare slug. Note: `$name` is an object
    `{ firstName, lastName }`, not a plain string. Call the
    <u>[definitions endpoint](/api/resources/contact/methods/definitions)</u> for
    available fields and types. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Union[Dict[str, RelationshipsUntypedRelationshipsUntypedItem]]
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$account`). Each value is an
    operation object with `add`, `remove`, or `replace`.
    """


class FieldsUntypedFieldsUntypedItemAddress(TypedDict, total=False):
    city: Optional[str]
    """City name."""

    country: Optional[str]
    """2-letter ISO 3166-1 alpha-2 country code."""

    latitude: Optional[float]
    """Latitude coordinate."""

    longitude: Optional[float]
    """Longitude coordinate."""

    postal_code: Annotated[Optional[str], PropertyInfo(alias="postalCode")]
    """Postal or ZIP code."""

    state: Optional[str]
    """State or province."""

    street: Optional[str]
    """Street address line 1."""

    street2: Optional[str]
    """Street address line 2."""


class FieldsUntypedFieldsUntypedItemFullName(TypedDict, total=False):
    first_name: Annotated[Optional[str], PropertyInfo(alias="firstName")]
    """The contact's first name."""

    last_name: Annotated[Optional[str], PropertyInfo(alias="lastName")]
    """The contact's last name."""


FieldsUntypedFieldsUntypedItem: TypeAlias = Union[
    str, float, bool, SequenceNotStr[str], FieldsUntypedFieldsUntypedItemAddress, FieldsUntypedFieldsUntypedItemFullName
]


class RelationshipsUntypedRelationshipsUntypedItem(TypedDict, total=False):
    """An operation to modify a relationship.

    Provide one of `add`, `remove`, or `replace`.
    """

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str], None]
    """A single entity ID or an array of entity IDs."""
