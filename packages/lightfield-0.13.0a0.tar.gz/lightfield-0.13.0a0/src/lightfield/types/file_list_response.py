# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FileListResponse", "Data"]


class Data(BaseModel):
    id: str
    """Unique identifier for the file."""

    completed_at: Optional[str] = FieldInfo(alias="completedAt", default=None)
    """When the file upload was completed."""

    created_at: str = FieldInfo(alias="createdAt")
    """When the file upload session was created."""

    expires_at: Optional[str] = FieldInfo(alias="expiresAt", default=None)
    """When the upload session expires. Null once completed, cancelled, or expired."""

    filename: str
    """Original filename."""

    mime_type: str = FieldInfo(alias="mimeType")
    """MIME type of the file."""

    size_bytes: int = FieldInfo(alias="sizeBytes")
    """File size in bytes."""

    status: Literal["PENDING", "COMPLETED", "CANCELLED", "EXPIRED"]
    """Current upload status of the file."""


class FileListResponse(BaseModel):
    data: List[Data]
    """Array of file objects for the current page."""

    object: str
    """The object type, always `"list"`."""

    total_count: int = FieldInfo(alias="totalCount")
    """Total number of matching files."""
