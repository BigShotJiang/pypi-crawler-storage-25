# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "ObjectCreateResponse",
    "Fields",
    "FieldsValue",
    "FieldsValueAddress",
    "FieldsValueFullName",
    "Relationships",
]


class FieldsValueAddress(BaseModel):
    city: Optional[str] = None
    """City name."""

    country: Optional[str] = None
    """2-letter ISO 3166-1 alpha-2 country code."""

    latitude: Optional[float] = None
    """Latitude coordinate."""

    longitude: Optional[float] = None
    """Longitude coordinate."""

    postal_code: Optional[str] = FieldInfo(alias="postalCode", default=None)
    """Postal or ZIP code."""

    state: Optional[str] = None
    """State or province."""

    street: Optional[str] = None
    """Street address line 1."""

    street2: Optional[str] = None
    """Street address line 2."""


class FieldsValueFullName(BaseModel):
    first_name: Optional[str] = FieldInfo(alias="firstName", default=None)
    """The contact's first name."""

    last_name: Optional[str] = FieldInfo(alias="lastName", default=None)
    """The contact's last name."""


FieldsValue: TypeAlias = Union[str, float, bool, List[str], FieldsValueAddress, FieldsValueFullName, None]


class Fields(BaseModel):
    value: Optional[FieldsValue] = None
    """The field value, or null if unset."""

    value_type: Literal[
        "ADDRESS",
        "CHECKBOX",
        "CURRENCY",
        "DATETIME",
        "EMAIL",
        "FULL_NAME",
        "MARKDOWN",
        "MULTI_SELECT",
        "NUMBER",
        "SINGLE_SELECT",
        "SOCIAL_HANDLE",
        "TELEPHONE",
        "TEXT",
        "URL",
        "HTML",
    ] = FieldInfo(alias="valueType")
    """The data type of the field."""


class Relationships(BaseModel):
    cardinality: str
    """Whether the relationship is `has_one` or `has_many`."""

    object_type: str = FieldInfo(alias="objectType")
    """The type of the related object (e.g. `account`, `contact`)."""

    values: List[str]
    """IDs of the related entities."""


class ObjectCreateResponse(BaseModel):
    id: str
    """Unique identifier for the entity."""

    created_at: str = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp of when the entity was created."""

    fields: Dict[str, Fields]
    """Map of field names to their typed values.

    System fields are prefixed with `$` (e.g. `$name`, `$email`); custom attributes
    use their bare slug.
    """

    http_link: Optional[str] = FieldInfo(alias="httpLink", default=None)
    """URL to view the entity in the Lightfield web app, or null."""

    relationships: Dict[str, Relationships]
    """Map of relationship names to their associated entities.

    System relationships are prefixed with `$` (e.g. `$owner`, `$contact`).
    """

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """ISO 8601 timestamp of when the entity was last updated, or null."""

    external_id: Optional[str] = FieldInfo(alias="externalId", default=None)
    """External identifier for the entity, or null if unset."""
