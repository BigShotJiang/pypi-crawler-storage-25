# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "ListCreateParams",
    "Fields",
    "Relationships",
    "RelationshipsAccounts",
    "RelationshipsContacts",
    "RelationshipsOpportunities",
]


class ListCreateParams(TypedDict, total=False):
    fields: Required[Fields]
    """Field values for the new list. Required: `$name` (string) and `$objectType`."""

    relationships: Relationships
    """Relationships to set on the new list."""


class Fields(TypedDict, total=False):
    """Field values for the new list. Required: `$name` (string) and `$objectType`."""

    name: Required[Annotated[str, PropertyInfo(alias="$name")]]
    """Display name of the list."""

    object_type: Required[Annotated[str, PropertyInfo(alias="$objectType")]]
    """The type of entities this list contains.

    Use `$account`, `$contact`, or `$opportunity` (the `$` prefix identifies system
    types). Bare slugs without the prefix (e.g. `account`) are accepted for backward
    compatibility but are deprecated.
    """


class RelationshipsAccounts(TypedDict, total=False):
    accounts: Required[Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$accounts")]]
    """Account ID(s) to add as initial members. List `$objectType` must be `account`."""


class RelationshipsContacts(TypedDict, total=False):
    contacts: Required[Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$contacts")]]
    """Contact ID(s) to add as initial members. List `$objectType` must be `contact`."""


class RelationshipsOpportunities(TypedDict, total=False):
    opportunities: Required[Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$opportunities")]]
    """Opportunity ID(s) to add as initial members.

    List `$objectType` must be `opportunity`.
    """


Relationships: TypeAlias = Union[RelationshipsAccounts, RelationshipsContacts, RelationshipsOpportunities]
