# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FileURLResponse"]


class FileURLResponse(BaseModel):
    expires_at: str = FieldInfo(alias="expiresAt")
    """When the download URL expires."""

    url: str
    """Temporary download URL for the file."""
