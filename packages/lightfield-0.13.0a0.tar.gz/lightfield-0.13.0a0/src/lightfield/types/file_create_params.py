# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["FileCreateParams"]


class FileCreateParams(TypedDict, total=False):
    filename: Required[str]
    """Original filename."""

    mime_type: Required[Annotated[str, PropertyInfo(alias="mimeType")]]
    """MIME type of the file. Must be allowed for the given purpose (if specified)."""

    size_bytes: Required[Annotated[int, PropertyInfo(alias="sizeBytes")]]
    """Expected file size in bytes. Maximum 512 MB."""

    purpose: Literal["meeting_transcript", "knowledge_user", "knowledge_workspace", "email_attachment"]
    """Optional validation hint.

    When provided, the server enforces purpose-specific MIME type and file size
    constraints. Use `meeting_transcript` for files that will be attached to a
    meeting as its transcript. Use `knowledge_user` or `knowledge_workspace` to add
    the file to the authenticated user's or workspace's Knowledge, making it
    available to the AI assistant. Not persisted or returned in responses.
    """
