# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "MemberListResponse",
    "Data",
    "DataFields",
    "DataFieldsEmail",
    "DataFieldsName",
    "DataFieldsNameValue",
    "DataFieldsProfileImage",
    "DataFieldsRole",
]


class DataFieldsEmail(BaseModel):
    """The member's email address."""

    value: str
    """The field value."""

    value_type: Literal["EMAIL"] = FieldInfo(alias="valueType")
    """The data type of the field value."""


class DataFieldsNameValue(BaseModel):
    first_name: Optional[str] = FieldInfo(alias="firstName", default=None)
    """The contact's first name."""

    last_name: Optional[str] = FieldInfo(alias="lastName", default=None)
    """The contact's last name."""


class DataFieldsName(BaseModel):
    """The member's full name."""

    value: DataFieldsNameValue

    value_type: Literal["FULL_NAME"] = FieldInfo(alias="valueType")
    """The data type of the field value."""


class DataFieldsProfileImage(BaseModel):
    """URL of the member's profile image, or null if unset."""

    value: Optional[str] = None
    """The field value, or null if unset."""

    value_type: Literal["URL"] = FieldInfo(alias="valueType")
    """The data type of the field value."""


class DataFieldsRole(BaseModel):
    """The member's workspace role."""

    value: str
    """The field value."""

    value_type: Literal["TEXT"] = FieldInfo(alias="valueType")
    """The data type of the field value."""


class DataFields(BaseModel):
    """Map of field names to their typed values."""

    email: DataFieldsEmail = FieldInfo(alias="$email")
    """The member's email address."""

    name: DataFieldsName = FieldInfo(alias="$name")
    """The member's full name."""

    profile_image: DataFieldsProfileImage = FieldInfo(alias="$profileImage")
    """URL of the member's profile image, or null if unset."""

    role: DataFieldsRole = FieldInfo(alias="$role")
    """The member's workspace role."""


class Data(BaseModel):
    id: str
    """Unique identifier for the member."""

    created_at: str = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp of when the member was created."""

    fields: DataFields
    """Map of field names to their typed values."""

    http_link: Optional[str] = FieldInfo(alias="httpLink", default=None)
    """URL to view the member in the Lightfield web app, or null."""

    relationships: object
    """Members do not expose writable or readable relationships in this API."""

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """ISO 8601 timestamp of when the member was last updated, or null."""


class MemberListResponse(BaseModel):
    data: List[Data]
    """Array of member objects for the current page."""

    object: str
    """The object type, always `"list"`."""

    total_count: int = FieldInfo(alias="totalCount")
    """Total number of members in the workspace."""
