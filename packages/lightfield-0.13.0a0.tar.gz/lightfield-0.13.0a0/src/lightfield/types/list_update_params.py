# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "ListUpdateParams",
    "Fields",
    "Relationships",
    "RelationshipsAccounts",
    "RelationshipsAccountsAccounts",
    "RelationshipsContacts",
    "RelationshipsContactsContacts",
    "RelationshipsOpportunities",
    "RelationshipsOpportunitiesOpportunities",
]


class ListUpdateParams(TypedDict, total=False):
    fields: Fields
    """
    Field values to update — only provided fields are modified; omitted fields are
    left unchanged.
    """

    relationships: Relationships
    """Relationship operations.

    Use the key matching the list's `$objectType` (e.g. `$accounts` for an account
    list).
    """


class Fields(TypedDict, total=False):
    """
    Field values to update — only provided fields are modified; omitted fields are left unchanged.
    """

    name: Annotated[str, PropertyInfo(alias="$name")]
    """Display name of the list."""


class RelationshipsAccountsAccounts(TypedDict, total=False):
    """Add/remove accounts. List `$objectType` must be `account`."""

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the list."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the list."""


class RelationshipsAccounts(TypedDict, total=False):
    accounts: Required[Annotated[RelationshipsAccountsAccounts, PropertyInfo(alias="$accounts")]]
    """Add/remove accounts. List `$objectType` must be `account`."""


class RelationshipsContactsContacts(TypedDict, total=False):
    """Add/remove contacts. List `$objectType` must be `contact`."""

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the list."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the list."""


class RelationshipsContacts(TypedDict, total=False):
    contacts: Required[Annotated[RelationshipsContactsContacts, PropertyInfo(alias="$contacts")]]
    """Add/remove contacts. List `$objectType` must be `contact`."""


class RelationshipsOpportunitiesOpportunities(TypedDict, total=False):
    """Add/remove opportunities. List `$objectType` must be `opportunity`."""

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the list."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the list."""


class RelationshipsOpportunities(TypedDict, total=False):
    opportunities: Required[Annotated[RelationshipsOpportunitiesOpportunities, PropertyInfo(alias="$opportunities")]]
    """Add/remove opportunities. List `$objectType` must be `opportunity`."""


Relationships: TypeAlias = Union[RelationshipsAccounts, RelationshipsContacts, RelationshipsOpportunities]
