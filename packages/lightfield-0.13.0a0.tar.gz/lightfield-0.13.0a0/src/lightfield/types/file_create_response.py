# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["FileCreateResponse"]


class FileCreateResponse(BaseModel):
    id: str
    """Unique identifier for the file."""

    completed_at: Optional[str] = FieldInfo(alias="completedAt", default=None)
    """When the file upload was completed."""

    created_at: str = FieldInfo(alias="createdAt")
    """When the file upload session was created."""

    expires_at: Optional[str] = FieldInfo(alias="expiresAt", default=None)
    """When the upload session expires. Null once completed, cancelled, or expired."""

    filename: str
    """Original filename."""

    mime_type: str = FieldInfo(alias="mimeType")
    """MIME type of the file."""

    size_bytes: int = FieldInfo(alias="sizeBytes")
    """File size in bytes."""

    status: Literal["PENDING", "COMPLETED", "CANCELLED", "EXPIRED"]
    """Current upload status of the file."""

    upload_headers: Dict[str, str] = FieldInfo(alias="uploadHeaders")
    """Headers to include in the upload request."""

    upload_url: str = FieldInfo(alias="uploadUrl")
    """Upload URL. Upload the file bytes directly to this URL."""
