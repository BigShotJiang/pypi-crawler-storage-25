# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["NoteCreateParams", "Fields", "Relationships"]


class NoteCreateParams(TypedDict, total=False):
    fields: Required[Fields]
    """Field values for the new note.

    `$title` is required; `$content` is optional. See
    **[Fields and relationships](/using-the-api/fields-and-relationships/)** for
    value type details.
    """

    relationships: Relationships
    """Relationships to set on the new note.

    System relationships use a `$` prefix (e.g. `$account`, `$opportunity`). Each
    value is a single entity ID or an array of IDs. The note author is automatically
    set to the API key owner.
    """


class Fields(TypedDict, total=False):
    """Field values for the new note.

    `$title` is required; `$content` is optional. See **[Fields and relationships](/using-the-api/fields-and-relationships/)** for value type details.
    """

    title: Required[Annotated[str, PropertyInfo(alias="$title")]]
    """Title of the note."""

    content: Annotated[Optional[str], PropertyInfo(alias="$content")]
    """Content of the note as markdown formatted text."""


class Relationships(TypedDict, total=False):
    """Relationships to set on the new note.

    System relationships use a `$` prefix (e.g. `$account`, `$opportunity`). Each value is a single entity ID or an array of IDs. The note author is automatically set to the API key owner.
    """

    account: Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$account")]
    """ID(s) of accounts to associate with this note."""

    opportunity: Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$opportunity")]
    """ID(s) of opportunities to associate with this note."""
