# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ListCreateResponse", "Fields", "FieldsValue", "FieldsValueAddress", "FieldsValueFullName"]


class FieldsValueAddress(BaseModel):
    city: Optional[str] = None
    """City name."""

    country: Optional[str] = None
    """2-letter ISO 3166-1 alpha-2 country code."""

    latitude: Optional[float] = None
    """Latitude coordinate."""

    longitude: Optional[float] = None
    """Longitude coordinate."""

    postal_code: Optional[str] = FieldInfo(alias="postalCode", default=None)
    """Postal or ZIP code."""

    state: Optional[str] = None
    """State or province."""

    street: Optional[str] = None
    """Street address line 1."""

    street2: Optional[str] = None
    """Street address line 2."""


class FieldsValueFullName(BaseModel):
    first_name: Optional[str] = FieldInfo(alias="firstName", default=None)
    """The contact's first name."""

    last_name: Optional[str] = FieldInfo(alias="lastName", default=None)
    """The contact's last name."""


FieldsValue: TypeAlias = Union[str, float, bool, List[str], FieldsValueAddress, FieldsValueFullName, None]


class Fields(BaseModel):
    value: Optional[FieldsValue] = None
    """The field value, or null if unset."""

    value_type: Literal[
        "ADDRESS",
        "CHECKBOX",
        "CURRENCY",
        "DATETIME",
        "EMAIL",
        "FULL_NAME",
        "MARKDOWN",
        "MULTI_SELECT",
        "NUMBER",
        "SINGLE_SELECT",
        "SOCIAL_HANDLE",
        "TELEPHONE",
        "TEXT",
        "URL",
        "HTML",
    ] = FieldInfo(alias="valueType")
    """The data type of the field."""


class ListCreateResponse(BaseModel):
    id: str
    """Unique identifier for the list."""

    created_at: str = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp of when the list was created."""

    fields: Dict[str, Fields]
    """Map of field names to their typed values.

    System fields are prefixed with `$` (e.g. `$name`, `$objectType`).
    """

    http_link: Optional[str] = FieldInfo(alias="httpLink", default=None)
    """URL to view the list in the Lightfield web app, or null."""
