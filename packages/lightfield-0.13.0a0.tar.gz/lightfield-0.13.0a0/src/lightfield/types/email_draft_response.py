# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["EmailDraftResponse"]


class EmailDraftResponse(BaseModel):
    drafted_at: str = FieldInfo(alias="draftedAt")
    """ISO 8601 timestamp of when the draft was created."""
