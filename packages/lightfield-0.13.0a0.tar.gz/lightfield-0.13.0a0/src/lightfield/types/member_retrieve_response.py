# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "MemberRetrieveResponse",
    "Fields",
    "FieldsEmail",
    "FieldsName",
    "FieldsNameValue",
    "FieldsProfileImage",
    "FieldsRole",
]


class FieldsEmail(BaseModel):
    """The member's email address."""

    value: str
    """The field value."""

    value_type: Literal["EMAIL"] = FieldInfo(alias="valueType")
    """The data type of the field value."""


class FieldsNameValue(BaseModel):
    first_name: Optional[str] = FieldInfo(alias="firstName", default=None)
    """The contact's first name."""

    last_name: Optional[str] = FieldInfo(alias="lastName", default=None)
    """The contact's last name."""


class FieldsName(BaseModel):
    """The member's full name."""

    value: FieldsNameValue

    value_type: Literal["FULL_NAME"] = FieldInfo(alias="valueType")
    """The data type of the field value."""


class FieldsProfileImage(BaseModel):
    """URL of the member's profile image, or null if unset."""

    value: Optional[str] = None
    """The field value, or null if unset."""

    value_type: Literal["URL"] = FieldInfo(alias="valueType")
    """The data type of the field value."""


class FieldsRole(BaseModel):
    """The member's workspace role."""

    value: str
    """The field value."""

    value_type: Literal["TEXT"] = FieldInfo(alias="valueType")
    """The data type of the field value."""


class Fields(BaseModel):
    """Map of field names to their typed values."""

    email: FieldsEmail = FieldInfo(alias="$email")
    """The member's email address."""

    name: FieldsName = FieldInfo(alias="$name")
    """The member's full name."""

    profile_image: FieldsProfileImage = FieldInfo(alias="$profileImage")
    """URL of the member's profile image, or null if unset."""

    role: FieldsRole = FieldInfo(alias="$role")
    """The member's workspace role."""


class MemberRetrieveResponse(BaseModel):
    id: str
    """Unique identifier for the member."""

    created_at: str = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp of when the member was created."""

    fields: Fields
    """Map of field names to their typed values."""

    http_link: Optional[str] = FieldInfo(alias="httpLink", default=None)
    """URL to view the member in the Lightfield web app, or null."""

    relationships: object
    """Members do not expose writable or readable relationships in this API."""

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """ISO 8601 timestamp of when the member was last updated, or null."""
