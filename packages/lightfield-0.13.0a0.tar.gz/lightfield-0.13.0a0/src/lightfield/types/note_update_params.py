# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "NoteUpdateParams",
    "Fields",
    "Relationships",
    "RelationshipsAccount",
    "RelationshipsAccountAdd",
    "RelationshipsAccountRemove",
    "RelationshipsOpportunity",
    "RelationshipsOpportunityAdd",
    "RelationshipsOpportunityRemove",
]


class NoteUpdateParams(TypedDict, total=False):
    fields: Fields
    """
    Field values to update — only provided fields are modified; omitted fields are
    left unchanged. See
    **[Fields and relationships](/using-the-api/fields-and-relationships/)** for
    value type details.
    """

    relationships: Relationships
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$account`, `$opportunity`). Each
    value is an operation object with `add` or `remove`.
    """


class Fields(TypedDict, total=False):
    """
    Field values to update — only provided fields are modified; omitted fields are left unchanged. See **[Fields and relationships](/using-the-api/fields-and-relationships/)** for value type details.
    """

    content: Annotated[Optional[str], PropertyInfo(alias="$content")]
    """Content of the note as markdown formatted text."""

    title: Annotated[Optional[str], PropertyInfo(alias="$title")]
    """Title of the note."""


class RelationshipsAccountAdd(TypedDict, total=False):
    add: Required[Union[str, SequenceNotStr[str]]]
    """Entity ID(s) to add to the relationship."""


class RelationshipsAccountRemove(TypedDict, total=False):
    remove: Required[Union[str, SequenceNotStr[str]]]
    """Entity ID(s) to remove from the relationship."""


RelationshipsAccount: TypeAlias = Union[RelationshipsAccountAdd, RelationshipsAccountRemove]


class RelationshipsOpportunityAdd(TypedDict, total=False):
    add: Required[Union[str, SequenceNotStr[str]]]
    """Entity ID(s) to add to the relationship."""


class RelationshipsOpportunityRemove(TypedDict, total=False):
    remove: Required[Union[str, SequenceNotStr[str]]]
    """Entity ID(s) to remove from the relationship."""


RelationshipsOpportunity: TypeAlias = Union[RelationshipsOpportunityAdd, RelationshipsOpportunityRemove]


class Relationships(TypedDict, total=False):
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$account`, `$opportunity`). Each value is an operation object with `add` or `remove`.
    """

    account: Annotated[RelationshipsAccount, PropertyInfo(alias="$account")]
    """Operation to modify associated accounts."""

    opportunity: Annotated[RelationshipsOpportunity, PropertyInfo(alias="$opportunity")]
    """Operation to modify associated opportunities."""
