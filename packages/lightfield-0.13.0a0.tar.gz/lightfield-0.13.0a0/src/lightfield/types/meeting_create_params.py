# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["MeetingCreateParams", "Fields", "Relationships"]


class MeetingCreateParams(TypedDict, total=False):
    fields: Required[Fields]
    """Field values for the new MANUAL meeting.

    System fields use a `$` prefix (for example `$title`, `$startDate`, `$endDate`).
    Required: `$title`, `$startDate`, and `$endDate`. `$organizerEmail` accepts a
    single email address when provided; `$attendeeEmails` accepts an array of email
    addresses. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    auto_create_records: Annotated[bool, PropertyInfo(alias="autoCreateRecords")]
    """
    When true, the initial post-create meeting sync may auto-create account and
    contact records for external attendees.
    """

    relationships: Relationships
    """Relationships to set on the new meeting.

    Only `$transcript` is writable on create; all other meeting relationships are
    system-managed.
    """


class Fields(TypedDict, total=False):
    """Field values for the new MANUAL meeting.

    System fields use a `$` prefix (for example `$title`, `$startDate`, `$endDate`). Required: `$title`, `$startDate`, and `$endDate`. `$organizerEmail` accepts a single email address when provided; `$attendeeEmails` accepts an array of email addresses. See <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for value type details.
    """

    end_date: Required[Annotated[str, PropertyInfo(alias="$endDate")]]
    """The end time of the meeting in ISO 8601 format. Must be in the past."""

    start_date: Required[Annotated[str, PropertyInfo(alias="$startDate")]]
    """The start time of the meeting in ISO 8601 format. Must be in the past."""

    title: Required[Annotated[str, PropertyInfo(alias="$title")]]
    """The title of the meeting."""

    attendee_emails: Annotated[SequenceNotStr[str], PropertyInfo(alias="$attendeeEmails")]
    """A list of attendee email addresses."""

    description: Annotated[Optional[str], PropertyInfo(alias="$description")]
    """A description of the meeting."""

    meeting_url: Annotated[Optional[str], PropertyInfo(alias="$meetingUrl")]
    """The URL for the meeting."""

    organizer_email: Annotated[Optional[str], PropertyInfo(alias="$organizerEmail")]
    """The email address of the meeting organizer.

    This field accepts a single email address.
    """

    privacy_setting: Annotated[Optional[Literal["FULL", "METADATA"]], PropertyInfo(alias="$privacySetting")]
    """The privacy setting for the meeting (`FULL` or `METADATA`)."""


class Relationships(TypedDict, total=False):
    """Relationships to set on the new meeting.

    Only `$transcript` is writable on create; all other meeting relationships are system-managed.
    """

    transcript: Required[Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$transcript")]]
    """The ID of the file to attach as the meeting transcript when creating the
    meeting.

    Only one transcript can be attached to a meeting.
    """
