# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["EmailSendResponse"]


class EmailSendResponse(BaseModel):
    sent_at: str = FieldInfo(alias="sentAt")
    """ISO 8601 timestamp of when the send completed."""
