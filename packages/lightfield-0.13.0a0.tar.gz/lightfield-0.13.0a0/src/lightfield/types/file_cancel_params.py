# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["FileCancelParams", "Body"]


class FileCancelParams(TypedDict, total=False):
    body: Body


class Body(TypedDict, total=False):
    pass
