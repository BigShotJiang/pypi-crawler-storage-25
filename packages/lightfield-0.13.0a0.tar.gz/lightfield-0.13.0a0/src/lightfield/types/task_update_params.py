# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["TaskUpdateParams", "Fields", "RelationshipsUntypedRelationshipsUntypedItem"]


class TaskUpdateParams(TypedDict, total=False):
    fields: Fields
    """
    Field values to update — only provided fields are modified; omitted fields are
    left unchanged. Tasks only support the documented system fields, all prefixed
    with `$` (e.g. `$title`, `$status`). Call the
    <u>[definitions endpoint](/api/resources/task/methods/definitions)</u> for
    available fields. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Union[Dict[str, RelationshipsUntypedRelationshipsUntypedItem]]
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$account`, `$assignedTo`). Each
    value is an operation object with `add`, `remove`, or `replace`.
    """


class Fields(TypedDict, total=False):
    """
    Field values to update — only provided fields are modified; omitted fields are left unchanged. Tasks only support the documented system fields, all prefixed with `$` (e.g. `$title`, `$status`). Call the <u>[definitions endpoint](/api/resources/task/methods/definitions)</u> for available fields. See <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for value type details.
    """

    description: Annotated[Optional[str], PropertyInfo(alias="$description")]
    """Description of the task in markdown format."""

    due_at: Annotated[Optional[str], PropertyInfo(alias="$dueAt")]
    """Due date as an ISO 8601 datetime string."""

    status: Annotated[Optional[str], PropertyInfo(alias="$status")]
    """Task status. One of: `TODO`, `IN_PROGRESS`, `COMPLETE`, `CANCELLED`."""

    title: Annotated[Optional[str], PropertyInfo(alias="$title")]
    """Title of the task."""


class RelationshipsUntypedRelationshipsUntypedItem(TypedDict, total=False):
    """An operation to modify a relationship.

    Provide one of `add`, `remove`, or `replace`.
    """

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str], None]
    """A single entity ID or an array of entity IDs."""
