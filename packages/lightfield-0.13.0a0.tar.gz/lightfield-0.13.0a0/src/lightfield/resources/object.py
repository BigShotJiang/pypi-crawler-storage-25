# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional

import httpx

from ..types import object_list_params, object_create_params, object_update_params
from .._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.object_list_response import ObjectListResponse
from ..types.object_create_response import ObjectCreateResponse
from ..types.object_update_response import ObjectUpdateResponse
from ..types.object_retrieve_response import ObjectRetrieveResponse
from ..types.object_definitions_response import ObjectDefinitionsResponse
from ..types.object_list_definitions_response import ObjectListDefinitionsResponse

__all__ = ["ObjectResource", "AsyncObjectResource"]


class ObjectResource(SyncAPIResource):
    """Custom objects and relationships are available on Pro and Growth plans.

    Records can be fetched and manipulated via these endpoints, and definitions can be fetched to discover the available custom object types in the system.
    """

    @cached_property
    def with_raw_response(self) -> ObjectResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return ObjectResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ObjectResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return ObjectResourceWithStreamingResponse(self)

    def create(
        self,
        entity_slug: str,
        *,
        fields: Dict[str, Optional[object_create_params.Fields]],
        relationships: Dict[str, Union[str, SequenceNotStr[str]]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectCreateResponse:
        """
        Creates a new record for the specified custom object type.

        Args:
          entity_slug: The slug of the custom object type.

          fields: Field names to values for the new record.

          relationships: Relationship names to entity ID(s) to associate.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        return self._post(
            path_template("/v1/objects/{entity_slug}/values", entity_slug=entity_slug),
            body=maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                object_create_params.ObjectCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectCreateResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        entity_slug: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectRetrieveResponse:
        """
        Retrieves a single record by ID for the specified custom object type.

        Args:
          entity_slug: The slug of the custom object type.

          id: The ID of the record to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v1/objects/{entity_slug}/values/{id}", entity_slug=entity_slug, id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectRetrieveResponse,
        )

    def update(
        self,
        id: str,
        *,
        entity_slug: str,
        fields: Dict[str, Optional[object_update_params.Fields]] | Omit = omit,
        relationships: Dict[str, object_update_params.Relationships] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectUpdateResponse:
        """Updates an existing record by ID for the specified custom object type.

        Only
        included fields and relationships are modified.

        Args:
          entity_slug: The slug of the custom object type.

          id: The ID of the record to update.

          fields: Field names to values. Only provided fields are modified.

          relationships: Relationship names to operations (`add`, `remove`, or `replace`).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/v1/objects/{entity_slug}/values/{id}", entity_slug=entity_slug, id=id),
            body=maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                object_update_params.ObjectUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectUpdateResponse,
        )

    def list(
        self,
        entity_slug: str,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectListResponse:
        """Returns a paginated list of records for the specified custom object type.

        Use
        `offset` and `limit` to paginate through results, and `$field` query parameters
        to filter. See <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more
        information about <u>[pagination](/using-the-api/list-endpoints/#pagination)</u>
        and <u>[filtering](/using-the-api/list-endpoints/#filtering)</u>.

        Args:
          entity_slug: The slug of the custom object type.

          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        return self._get(
            path_template("/v1/objects/{entity_slug}", entity_slug=entity_slug),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    object_list_params.ObjectListParams,
                ),
            ),
            cast_to=ObjectListResponse,
        )

    def definitions(
        self,
        entity_slug: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectDefinitionsResponse:
        """
        Returns field and relationship definitions for the specified custom object type.

        Args:
          entity_slug: The slug of the custom object type.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        return self._get(
            path_template("/v1/objects/{entity_slug}/definitions", entity_slug=entity_slug),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectDefinitionsResponse,
        )

    def list_definitions(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectListDefinitionsResponse:
        """Returns all custom object types available to the caller."""
        return self._get(
            "/v1/objects",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectListDefinitionsResponse,
        )


class AsyncObjectResource(AsyncAPIResource):
    """Custom objects and relationships are available on Pro and Growth plans.

    Records can be fetched and manipulated via these endpoints, and definitions can be fetched to discover the available custom object types in the system.
    """

    @cached_property
    def with_raw_response(self) -> AsyncObjectResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return AsyncObjectResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncObjectResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return AsyncObjectResourceWithStreamingResponse(self)

    async def create(
        self,
        entity_slug: str,
        *,
        fields: Dict[str, Optional[object_create_params.Fields]],
        relationships: Dict[str, Union[str, SequenceNotStr[str]]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectCreateResponse:
        """
        Creates a new record for the specified custom object type.

        Args:
          entity_slug: The slug of the custom object type.

          fields: Field names to values for the new record.

          relationships: Relationship names to entity ID(s) to associate.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        return await self._post(
            path_template("/v1/objects/{entity_slug}/values", entity_slug=entity_slug),
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                object_create_params.ObjectCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectCreateResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        entity_slug: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectRetrieveResponse:
        """
        Retrieves a single record by ID for the specified custom object type.

        Args:
          entity_slug: The slug of the custom object type.

          id: The ID of the record to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v1/objects/{entity_slug}/values/{id}", entity_slug=entity_slug, id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectRetrieveResponse,
        )

    async def update(
        self,
        id: str,
        *,
        entity_slug: str,
        fields: Dict[str, Optional[object_update_params.Fields]] | Omit = omit,
        relationships: Dict[str, object_update_params.Relationships] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectUpdateResponse:
        """Updates an existing record by ID for the specified custom object type.

        Only
        included fields and relationships are modified.

        Args:
          entity_slug: The slug of the custom object type.

          id: The ID of the record to update.

          fields: Field names to values. Only provided fields are modified.

          relationships: Relationship names to operations (`add`, `remove`, or `replace`).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/v1/objects/{entity_slug}/values/{id}", entity_slug=entity_slug, id=id),
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                object_update_params.ObjectUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectUpdateResponse,
        )

    async def list(
        self,
        entity_slug: str,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectListResponse:
        """Returns a paginated list of records for the specified custom object type.

        Use
        `offset` and `limit` to paginate through results, and `$field` query parameters
        to filter. See <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more
        information about <u>[pagination](/using-the-api/list-endpoints/#pagination)</u>
        and <u>[filtering](/using-the-api/list-endpoints/#filtering)</u>.

        Args:
          entity_slug: The slug of the custom object type.

          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        return await self._get(
            path_template("/v1/objects/{entity_slug}", entity_slug=entity_slug),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    object_list_params.ObjectListParams,
                ),
            ),
            cast_to=ObjectListResponse,
        )

    async def definitions(
        self,
        entity_slug: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectDefinitionsResponse:
        """
        Returns field and relationship definitions for the specified custom object type.

        Args:
          entity_slug: The slug of the custom object type.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not entity_slug:
            raise ValueError(f"Expected a non-empty value for `entity_slug` but received {entity_slug!r}")
        return await self._get(
            path_template("/v1/objects/{entity_slug}/definitions", entity_slug=entity_slug),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectDefinitionsResponse,
        )

    async def list_definitions(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ObjectListDefinitionsResponse:
        """Returns all custom object types available to the caller."""
        return await self._get(
            "/v1/objects",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ObjectListDefinitionsResponse,
        )


class ObjectResourceWithRawResponse:
    def __init__(self, object: ObjectResource) -> None:
        self._object = object

        self.create = to_raw_response_wrapper(
            object.create,
        )
        self.retrieve = to_raw_response_wrapper(
            object.retrieve,
        )
        self.update = to_raw_response_wrapper(
            object.update,
        )
        self.list = to_raw_response_wrapper(
            object.list,
        )
        self.definitions = to_raw_response_wrapper(
            object.definitions,
        )
        self.list_definitions = to_raw_response_wrapper(
            object.list_definitions,
        )


class AsyncObjectResourceWithRawResponse:
    def __init__(self, object: AsyncObjectResource) -> None:
        self._object = object

        self.create = async_to_raw_response_wrapper(
            object.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            object.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            object.update,
        )
        self.list = async_to_raw_response_wrapper(
            object.list,
        )
        self.definitions = async_to_raw_response_wrapper(
            object.definitions,
        )
        self.list_definitions = async_to_raw_response_wrapper(
            object.list_definitions,
        )


class ObjectResourceWithStreamingResponse:
    def __init__(self, object: ObjectResource) -> None:
        self._object = object

        self.create = to_streamed_response_wrapper(
            object.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            object.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            object.update,
        )
        self.list = to_streamed_response_wrapper(
            object.list,
        )
        self.definitions = to_streamed_response_wrapper(
            object.definitions,
        )
        self.list_definitions = to_streamed_response_wrapper(
            object.list_definitions,
        )


class AsyncObjectResourceWithStreamingResponse:
    def __init__(self, object: AsyncObjectResource) -> None:
        self._object = object

        self.create = async_to_streamed_response_wrapper(
            object.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            object.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            object.update,
        )
        self.list = async_to_streamed_response_wrapper(
            object.list,
        )
        self.definitions = async_to_streamed_response_wrapper(
            object.definitions,
        )
        self.list_definitions = async_to_streamed_response_wrapper(
            object.list_definitions,
        )
