# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import email_list_params, email_send_params, email_draft_params
from .._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.email_list_response import EmailListResponse
from ..types.email_send_response import EmailSendResponse
from ..types.email_draft_response import EmailDraftResponse
from ..types.email_retrieve_response import EmailRetrieveResponse

__all__ = ["EmailResource", "AsyncEmailResource"]


class EmailResource(SyncAPIResource):
    """Emails represent messages synced from connected email accounts in Lightfield.

    Read responses are privacy-aware and may be redacted based on the caller.
    """

    @cached_property
    def with_raw_response(self) -> EmailResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return EmailResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EmailResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return EmailResourceWithStreamingResponse(self)

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailRetrieveResponse:
        """Retrieves a single email by its ID.

        Email fields are redacted based on the
        caller-specific privacy resolution, and the response includes a read-only
        `accessLevel`.

        **[Required scope](/using-the-api/scopes/):** `emails:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the email to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v1/emails/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailRetrieveResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailListResponse:
        """Returns a paginated list of emails.

        Use `offset` and `limit` to paginate through
        results. Each email is privacy-filtered per caller, includes a read-only
        `accessLevel`, and may redact the subject at metadata-only access.
        `fields.$body` is not included on list items; use GET `/v1/emails/{id}` for
        message body HTML. See <u>[List endpoints](/using-the-api/list-endpoints/)</u>
        for more information about pagination.

        **[Required scope](/using-the-api/scopes/):** `emails:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/emails",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    email_list_params.EmailListParams,
                ),
            ),
            cast_to=EmailListResponse,
        )

    def draft(
        self,
        *,
        from_: str,
        attachments: SequenceNotStr[str] | Omit = omit,
        bcc: SequenceNotStr[str] | Omit = omit,
        cc: SequenceNotStr[str] | Omit = omit,
        message_body: email_draft_params.MessageBody | Omit = omit,
        subject: str | Omit = omit,
        to: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailDraftResponse:
        """
        Creates a draft in the connected email account that owns the `from` address.
        Mirrors native email-client behavior: only `from` is required — `to`, `cc`,
        `bcc`, `subject`, `messageBody`, and `attachments` are all optional. At least
        one of those optional fields must be populated; sending only `from` returns
        a 400.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `emails:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          from_: Bare email address (no display name). Must match a connected email account owned
              by the API key user. Compared case-insensitively. Mailbox where the draft is
              created.

          attachments: Optional list of file IDs (uploaded via the Files API) to attach to the draft.
              Maximum 5 attachments per draft, each ≤ 3MB.

          bcc: Bcc recipients (same shape as `to`).

          cc: Cc recipients (same shape as `to`).

          message_body: Email message body (HTML or plain text).

          subject: Email subject.

          to: Recipient email addresses (bare, no display names). Up to 500.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/emails/draft",
            body=maybe_transform(
                {
                    "from_": from_,
                    "attachments": attachments,
                    "bcc": bcc,
                    "cc": cc,
                    "message_body": message_body,
                    "subject": subject,
                    "to": to,
                },
                email_draft_params.EmailDraftParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailDraftResponse,
        )

    def send(
        self,
        *,
        from_: str,
        message_body: email_send_params.MessageBody,
        subject: str,
        to: SequenceNotStr[str],
        attachments: SequenceNotStr[str] | Omit = omit,
        bcc: SequenceNotStr[str] | Omit = omit,
        cc: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailSendResponse:
        """
        Sends an email via the connected email account that owns the `from` address.
        Currently supports new sends only; replies and forwards are not yet supported.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `emails:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          from_: Bare email address (no display name). Must match a connected email account owned
              by the API key user. Compared case-insensitively. Used as the From header when
              sending.

          message_body: Email message body (HTML or plain text).

          subject: Email subject. Cannot be empty.

          to: Recipient email addresses (bare, no display names). At least 1, at most 500.

          attachments: Optional list of file IDs (uploaded via the Files API) to attach to the email.
              Maximum 5 attachments per email, each ≤ 3MB.

          bcc: Bcc recipients (same shape as `to`).

          cc: Cc recipients (same shape as `to`).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/emails/send",
            body=maybe_transform(
                {
                    "from_": from_,
                    "message_body": message_body,
                    "subject": subject,
                    "to": to,
                    "attachments": attachments,
                    "bcc": bcc,
                    "cc": cc,
                },
                email_send_params.EmailSendParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailSendResponse,
        )


class AsyncEmailResource(AsyncAPIResource):
    """Emails represent messages synced from connected email accounts in Lightfield.

    Read responses are privacy-aware and may be redacted based on the caller.
    """

    @cached_property
    def with_raw_response(self) -> AsyncEmailResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return AsyncEmailResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEmailResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return AsyncEmailResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailRetrieveResponse:
        """Retrieves a single email by its ID.

        Email fields are redacted based on the
        caller-specific privacy resolution, and the response includes a read-only
        `accessLevel`.

        **[Required scope](/using-the-api/scopes/):** `emails:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the email to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v1/emails/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailRetrieveResponse,
        )

    async def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailListResponse:
        """Returns a paginated list of emails.

        Use `offset` and `limit` to paginate through
        results. Each email is privacy-filtered per caller, includes a read-only
        `accessLevel`, and may redact the subject at metadata-only access.
        `fields.$body` is not included on list items; use GET `/v1/emails/{id}` for
        message body HTML. See <u>[List endpoints](/using-the-api/list-endpoints/)</u>
        for more information about pagination.

        **[Required scope](/using-the-api/scopes/):** `emails:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/emails",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    email_list_params.EmailListParams,
                ),
            ),
            cast_to=EmailListResponse,
        )

    async def draft(
        self,
        *,
        from_: str,
        attachments: SequenceNotStr[str] | Omit = omit,
        bcc: SequenceNotStr[str] | Omit = omit,
        cc: SequenceNotStr[str] | Omit = omit,
        message_body: email_draft_params.MessageBody | Omit = omit,
        subject: str | Omit = omit,
        to: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailDraftResponse:
        """
        Creates a draft in the connected email account that owns the `from` address.
        Mirrors native email-client behavior: only `from` is required — `to`, `cc`,
        `bcc`, `subject`, `messageBody`, and `attachments` are all optional. At least
        one of those optional fields must be populated; sending only `from` returns
        a 400.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `emails:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          from_: Bare email address (no display name). Must match a connected email account owned
              by the API key user. Compared case-insensitively. Mailbox where the draft is
              created.

          attachments: Optional list of file IDs (uploaded via the Files API) to attach to the draft.
              Maximum 5 attachments per draft, each ≤ 3MB.

          bcc: Bcc recipients (same shape as `to`).

          cc: Cc recipients (same shape as `to`).

          message_body: Email message body (HTML or plain text).

          subject: Email subject.

          to: Recipient email addresses (bare, no display names). Up to 500.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/emails/draft",
            body=await async_maybe_transform(
                {
                    "from_": from_,
                    "attachments": attachments,
                    "bcc": bcc,
                    "cc": cc,
                    "message_body": message_body,
                    "subject": subject,
                    "to": to,
                },
                email_draft_params.EmailDraftParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailDraftResponse,
        )

    async def send(
        self,
        *,
        from_: str,
        message_body: email_send_params.MessageBody,
        subject: str,
        to: SequenceNotStr[str],
        attachments: SequenceNotStr[str] | Omit = omit,
        bcc: SequenceNotStr[str] | Omit = omit,
        cc: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EmailSendResponse:
        """
        Sends an email via the connected email account that owns the `from` address.
        Currently supports new sends only; replies and forwards are not yet supported.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `emails:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          from_: Bare email address (no display name). Must match a connected email account owned
              by the API key user. Compared case-insensitively. Used as the From header when
              sending.

          message_body: Email message body (HTML or plain text).

          subject: Email subject. Cannot be empty.

          to: Recipient email addresses (bare, no display names). At least 1, at most 500.

          attachments: Optional list of file IDs (uploaded via the Files API) to attach to the email.
              Maximum 5 attachments per email, each ≤ 3MB.

          bcc: Bcc recipients (same shape as `to`).

          cc: Cc recipients (same shape as `to`).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/emails/send",
            body=await async_maybe_transform(
                {
                    "from_": from_,
                    "message_body": message_body,
                    "subject": subject,
                    "to": to,
                    "attachments": attachments,
                    "bcc": bcc,
                    "cc": cc,
                },
                email_send_params.EmailSendParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EmailSendResponse,
        )


class EmailResourceWithRawResponse:
    def __init__(self, email: EmailResource) -> None:
        self._email = email

        self.retrieve = to_raw_response_wrapper(
            email.retrieve,
        )
        self.list = to_raw_response_wrapper(
            email.list,
        )
        self.draft = to_raw_response_wrapper(
            email.draft,
        )
        self.send = to_raw_response_wrapper(
            email.send,
        )


class AsyncEmailResourceWithRawResponse:
    def __init__(self, email: AsyncEmailResource) -> None:
        self._email = email

        self.retrieve = async_to_raw_response_wrapper(
            email.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            email.list,
        )
        self.draft = async_to_raw_response_wrapper(
            email.draft,
        )
        self.send = async_to_raw_response_wrapper(
            email.send,
        )


class EmailResourceWithStreamingResponse:
    def __init__(self, email: EmailResource) -> None:
        self._email = email

        self.retrieve = to_streamed_response_wrapper(
            email.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            email.list,
        )
        self.draft = to_streamed_response_wrapper(
            email.draft,
        )
        self.send = to_streamed_response_wrapper(
            email.send,
        )


class AsyncEmailResourceWithStreamingResponse:
    def __init__(self, email: AsyncEmailResource) -> None:
        self._email = email

        self.retrieve = async_to_streamed_response_wrapper(
            email.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            email.list,
        )
        self.draft = async_to_streamed_response_wrapper(
            email.draft,
        )
        self.send = async_to_streamed_response_wrapper(
            email.send,
        )
