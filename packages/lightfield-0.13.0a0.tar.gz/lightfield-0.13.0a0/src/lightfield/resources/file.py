# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import file_list_params, file_cancel_params, file_create_params, file_complete_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.file_url_response import FileURLResponse
from ..types.file_list_response import FileListResponse
from ..types.file_cancel_response import FileCancelResponse
from ..types.file_create_response import FileCreateResponse
from ..types.file_complete_response import FileCompleteResponse
from ..types.file_retrieve_response import FileRetrieveResponse

__all__ = ["FileResource", "AsyncFileResource"]


class FileResource(SyncAPIResource):
    """Files are used to upload documents via presigned URLs.

    After uploading and completing a file, link it to resources through their own APIs (e.g. attach a transcript to a meeting). See <u>[File uploads](/using-the-api/file-uploads/)</u> for the full upload flow and supported purposes. For meeting transcript attachments, see <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>.
    """

    @cached_property
    def with_raw_response(self) -> FileResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return FileResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FileResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return FileResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        filename: str,
        mime_type: str,
        size_bytes: int,
        purpose: Literal["meeting_transcript", "knowledge_user", "knowledge_workspace", "email_attachment"]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileCreateResponse:
        """
        Creates a new file upload session and returns an upload URL.

        After uploading the file bytes to `uploadUrl`, call
        `POST /v1/files/{id}/complete` to finalize the upload. Optionally pass `purpose`
        to validate MIME type and size constraints at creation time. See
        <u>[File uploads](/using-the-api/file-uploads/)</u> for the full upload flow,
        supported purposes, and size limits. If you are uploading a meeting transcript,
        see
        <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>
        for the follow-up meeting attachment flow.

        **[Required scope](/using-the-api/scopes/):** `files:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          filename: Original filename.

          mime_type: MIME type of the file. Must be allowed for the given purpose (if specified).

          size_bytes: Expected file size in bytes. Maximum 512 MB.

          purpose: Optional validation hint. When provided, the server enforces purpose-specific
              MIME type and file size constraints. Use `meeting_transcript` for files that
              will be attached to a meeting as its transcript. Use `knowledge_user` or
              `knowledge_workspace` to add the file to the authenticated user's or workspace's
              Knowledge, making it available to the AI assistant. Not persisted or returned in
              responses.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/files",
            body=maybe_transform(
                {
                    "filename": filename,
                    "mime_type": mime_type,
                    "size_bytes": size_bytes,
                    "purpose": purpose,
                },
                file_create_params.FileCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileCreateResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileRetrieveResponse:
        """
        Retrieves a single file by its ID.

        **[Required scope](/using-the-api/scopes/):** `files:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the file to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v1/files/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileRetrieveResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileListResponse:
        """Returns a paginated list of files in your workspace.

        Use `offset` and `limit` to
        paginate through results. See
        <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more information
        about pagination.

        **[Required scope](/using-the-api/scopes/):** `files:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/files",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    file_list_params.FileListParams,
                ),
            ),
            cast_to=FileListResponse,
        )

    def cancel(
        self,
        id: str,
        *,
        body: file_cancel_params.Body | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileCancelResponse:
        """Cancels a pending upload by transitioning the file to `CANCELLED`.

        Only files in
        `PENDING` status can be cancelled. **[Required scope](/using-the-api/scopes/):**
        `files:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the file to cancel.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/v1/files/{id}/cancel", id=id),
            body=maybe_transform(body, file_cancel_params.FileCancelParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileCancelResponse,
        )

    def complete(
        self,
        id: str,
        *,
        md5: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileCompleteResponse:
        """
        Finalizes an upload after the file bytes have been uploaded.

        If an optional `md5` hex digest is provided, the server validates the checksum
        before marking the file as completed.

        **[Required scope](/using-the-api/scopes/):** `files:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the file to complete.

          md5: Optional MD5 hex digest of the uploaded file for checksum verification.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/v1/files/{id}/complete", id=id),
            body=maybe_transform({"md5": md5}, file_complete_params.FileCompleteParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileCompleteResponse,
        )

    def url(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileURLResponse:
        """Returns a temporary download URL for the file.

        Only available for files in
        `COMPLETED` status.

        **[Required scope](/using-the-api/scopes/):** `files:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the file to download.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v1/files/{id}/url", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileURLResponse,
        )


class AsyncFileResource(AsyncAPIResource):
    """Files are used to upload documents via presigned URLs.

    After uploading and completing a file, link it to resources through their own APIs (e.g. attach a transcript to a meeting). See <u>[File uploads](/using-the-api/file-uploads/)</u> for the full upload flow and supported purposes. For meeting transcript attachments, see <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>.
    """

    @cached_property
    def with_raw_response(self) -> AsyncFileResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return AsyncFileResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFileResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return AsyncFileResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        filename: str,
        mime_type: str,
        size_bytes: int,
        purpose: Literal["meeting_transcript", "knowledge_user", "knowledge_workspace", "email_attachment"]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileCreateResponse:
        """
        Creates a new file upload session and returns an upload URL.

        After uploading the file bytes to `uploadUrl`, call
        `POST /v1/files/{id}/complete` to finalize the upload. Optionally pass `purpose`
        to validate MIME type and size constraints at creation time. See
        <u>[File uploads](/using-the-api/file-uploads/)</u> for the full upload flow,
        supported purposes, and size limits. If you are uploading a meeting transcript,
        see
        <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>
        for the follow-up meeting attachment flow.

        **[Required scope](/using-the-api/scopes/):** `files:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          filename: Original filename.

          mime_type: MIME type of the file. Must be allowed for the given purpose (if specified).

          size_bytes: Expected file size in bytes. Maximum 512 MB.

          purpose: Optional validation hint. When provided, the server enforces purpose-specific
              MIME type and file size constraints. Use `meeting_transcript` for files that
              will be attached to a meeting as its transcript. Use `knowledge_user` or
              `knowledge_workspace` to add the file to the authenticated user's or workspace's
              Knowledge, making it available to the AI assistant. Not persisted or returned in
              responses.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/files",
            body=await async_maybe_transform(
                {
                    "filename": filename,
                    "mime_type": mime_type,
                    "size_bytes": size_bytes,
                    "purpose": purpose,
                },
                file_create_params.FileCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileCreateResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileRetrieveResponse:
        """
        Retrieves a single file by its ID.

        **[Required scope](/using-the-api/scopes/):** `files:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the file to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v1/files/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileRetrieveResponse,
        )

    async def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileListResponse:
        """Returns a paginated list of files in your workspace.

        Use `offset` and `limit` to
        paginate through results. See
        <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more information
        about pagination.

        **[Required scope](/using-the-api/scopes/):** `files:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/files",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    file_list_params.FileListParams,
                ),
            ),
            cast_to=FileListResponse,
        )

    async def cancel(
        self,
        id: str,
        *,
        body: file_cancel_params.Body | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileCancelResponse:
        """Cancels a pending upload by transitioning the file to `CANCELLED`.

        Only files in
        `PENDING` status can be cancelled. **[Required scope](/using-the-api/scopes/):**
        `files:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the file to cancel.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/v1/files/{id}/cancel", id=id),
            body=await async_maybe_transform(body, file_cancel_params.FileCancelParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileCancelResponse,
        )

    async def complete(
        self,
        id: str,
        *,
        md5: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileCompleteResponse:
        """
        Finalizes an upload after the file bytes have been uploaded.

        If an optional `md5` hex digest is provided, the server validates the checksum
        before marking the file as completed.

        **[Required scope](/using-the-api/scopes/):** `files:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the file to complete.

          md5: Optional MD5 hex digest of the uploaded file for checksum verification.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/v1/files/{id}/complete", id=id),
            body=await async_maybe_transform({"md5": md5}, file_complete_params.FileCompleteParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileCompleteResponse,
        )

    async def url(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileURLResponse:
        """Returns a temporary download URL for the file.

        Only available for files in
        `COMPLETED` status.

        **[Required scope](/using-the-api/scopes/):** `files:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the file to download.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v1/files/{id}/url", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileURLResponse,
        )


class FileResourceWithRawResponse:
    def __init__(self, file: FileResource) -> None:
        self._file = file

        self.create = to_raw_response_wrapper(
            file.create,
        )
        self.retrieve = to_raw_response_wrapper(
            file.retrieve,
        )
        self.list = to_raw_response_wrapper(
            file.list,
        )
        self.cancel = to_raw_response_wrapper(
            file.cancel,
        )
        self.complete = to_raw_response_wrapper(
            file.complete,
        )
        self.url = to_raw_response_wrapper(
            file.url,
        )


class AsyncFileResourceWithRawResponse:
    def __init__(self, file: AsyncFileResource) -> None:
        self._file = file

        self.create = async_to_raw_response_wrapper(
            file.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            file.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            file.list,
        )
        self.cancel = async_to_raw_response_wrapper(
            file.cancel,
        )
        self.complete = async_to_raw_response_wrapper(
            file.complete,
        )
        self.url = async_to_raw_response_wrapper(
            file.url,
        )


class FileResourceWithStreamingResponse:
    def __init__(self, file: FileResource) -> None:
        self._file = file

        self.create = to_streamed_response_wrapper(
            file.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            file.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            file.list,
        )
        self.cancel = to_streamed_response_wrapper(
            file.cancel,
        )
        self.complete = to_streamed_response_wrapper(
            file.complete,
        )
        self.url = to_streamed_response_wrapper(
            file.url,
        )


class AsyncFileResourceWithStreamingResponse:
    def __init__(self, file: AsyncFileResource) -> None:
        self._file = file

        self.create = async_to_streamed_response_wrapper(
            file.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            file.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            file.list,
        )
        self.cancel = async_to_streamed_response_wrapper(
            file.cancel,
        )
        self.complete = async_to_streamed_response_wrapper(
            file.complete,
        )
        self.url = async_to_streamed_response_wrapper(
            file.url,
        )
