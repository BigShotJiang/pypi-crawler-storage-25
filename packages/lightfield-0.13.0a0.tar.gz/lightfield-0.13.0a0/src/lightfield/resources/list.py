# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import (
    list_list_params,
    list_create_params,
    list_update_params,
    list_list_accounts_params,
    list_list_contacts_params,
    list_list_opportunities_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.list_list_response import ListListResponse
from ..types.list_create_response import ListCreateResponse
from ..types.list_update_response import ListUpdateResponse
from ..types.list_retrieve_response import ListRetrieveResponse
from ..types.list_list_accounts_response import ListListAccountsResponse
from ..types.list_list_contacts_response import ListListContactsResponse
from ..types.list_list_opportunities_response import ListListOpportunitiesResponse

__all__ = ["ListResource", "AsyncListResource"]


class ListResource(SyncAPIResource):
    """
    Lists are curated collections of accounts, contacts, or opportunities in Lightfield. Each list contains entities of a single type.
    """

    @cached_property
    def with_raw_response(self) -> ListResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return ListResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ListResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return ListResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        fields: list_create_params.Fields,
        relationships: list_create_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListCreateResponse:
        """Creates a new list.

        The `$name` and `$objectType` fields are required.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `lists:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          fields: Field values for the new list. Required: `$name` (string) and `$objectType`.

          relationships: Relationships to set on the new list.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/lists",
            body=maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                list_create_params.ListCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ListCreateResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListRetrieveResponse:
        """
        Retrieves a single list by its ID.

        **[Required scope](/using-the-api/scopes/):** `lists:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the list to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v1/lists/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ListRetrieveResponse,
        )

    def update(
        self,
        id: str,
        *,
        fields: list_update_params.Fields | Omit = omit,
        relationships: list_update_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListUpdateResponse:
        """Updates an existing list by ID.

        Only included fields are modified.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `lists:update`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the list to update.

          fields: Field values to update — only provided fields are modified; omitted fields are
              left unchanged.

          relationships: Relationship operations. Use the key matching the list's `$objectType` (e.g.
              `$accounts` for an account list).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/v1/lists/{id}", id=id),
            body=maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                list_update_params.ListUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ListUpdateResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListListResponse:
        """Returns a paginated list of lists.

        Use `offset` and `limit` to paginate through
        results. See <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more
        information about pagination.

        **[Required scope](/using-the-api/scopes/):** `lists:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/lists",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    list_list_params.ListListParams,
                ),
            ),
            cast_to=ListListResponse,
        )

    def list_accounts(
        self,
        list_id: str,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListListAccountsResponse:
        """
        Returns a paginated list of accounts that belong to the specified list.

        **[Required scopes](/using-the-api/scopes/):** `lists:read` and `accounts:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          list_id: Unique identifier of the list.

          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not list_id:
            raise ValueError(f"Expected a non-empty value for `list_id` but received {list_id!r}")
        return self._get(
            path_template("/v1/lists/{list_id}/accounts", list_id=list_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    list_list_accounts_params.ListListAccountsParams,
                ),
            ),
            cast_to=ListListAccountsResponse,
        )

    def list_contacts(
        self,
        list_id: str,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListListContactsResponse:
        """
        Returns a paginated list of contacts that belong to the specified list.

        **[Required scopes](/using-the-api/scopes/):** `lists:read` and `contacts:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          list_id: Unique identifier of the list.

          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not list_id:
            raise ValueError(f"Expected a non-empty value for `list_id` but received {list_id!r}")
        return self._get(
            path_template("/v1/lists/{list_id}/contacts", list_id=list_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    list_list_contacts_params.ListListContactsParams,
                ),
            ),
            cast_to=ListListContactsResponse,
        )

    def list_opportunities(
        self,
        list_id: str,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListListOpportunitiesResponse:
        """
        Returns a paginated list of opportunities that belong to the specified list.

        **[Required scopes](/using-the-api/scopes/):** `lists:read` and
        `opportunities:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          list_id: Unique identifier of the list.

          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not list_id:
            raise ValueError(f"Expected a non-empty value for `list_id` but received {list_id!r}")
        return self._get(
            path_template("/v1/lists/{list_id}/opportunities", list_id=list_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    list_list_opportunities_params.ListListOpportunitiesParams,
                ),
            ),
            cast_to=ListListOpportunitiesResponse,
        )


class AsyncListResource(AsyncAPIResource):
    """
    Lists are curated collections of accounts, contacts, or opportunities in Lightfield. Each list contains entities of a single type.
    """

    @cached_property
    def with_raw_response(self) -> AsyncListResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return AsyncListResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncListResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return AsyncListResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        fields: list_create_params.Fields,
        relationships: list_create_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListCreateResponse:
        """Creates a new list.

        The `$name` and `$objectType` fields are required.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `lists:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          fields: Field values for the new list. Required: `$name` (string) and `$objectType`.

          relationships: Relationships to set on the new list.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/lists",
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                list_create_params.ListCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ListCreateResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListRetrieveResponse:
        """
        Retrieves a single list by its ID.

        **[Required scope](/using-the-api/scopes/):** `lists:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the list to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v1/lists/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ListRetrieveResponse,
        )

    async def update(
        self,
        id: str,
        *,
        fields: list_update_params.Fields | Omit = omit,
        relationships: list_update_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListUpdateResponse:
        """Updates an existing list by ID.

        Only included fields are modified.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `lists:update`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the list to update.

          fields: Field values to update — only provided fields are modified; omitted fields are
              left unchanged.

          relationships: Relationship operations. Use the key matching the list's `$objectType` (e.g.
              `$accounts` for an account list).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/v1/lists/{id}", id=id),
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                list_update_params.ListUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ListUpdateResponse,
        )

    async def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListListResponse:
        """Returns a paginated list of lists.

        Use `offset` and `limit` to paginate through
        results. See <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more
        information about pagination.

        **[Required scope](/using-the-api/scopes/):** `lists:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/lists",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    list_list_params.ListListParams,
                ),
            ),
            cast_to=ListListResponse,
        )

    async def list_accounts(
        self,
        list_id: str,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListListAccountsResponse:
        """
        Returns a paginated list of accounts that belong to the specified list.

        **[Required scopes](/using-the-api/scopes/):** `lists:read` and `accounts:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          list_id: Unique identifier of the list.

          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not list_id:
            raise ValueError(f"Expected a non-empty value for `list_id` but received {list_id!r}")
        return await self._get(
            path_template("/v1/lists/{list_id}/accounts", list_id=list_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    list_list_accounts_params.ListListAccountsParams,
                ),
            ),
            cast_to=ListListAccountsResponse,
        )

    async def list_contacts(
        self,
        list_id: str,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListListContactsResponse:
        """
        Returns a paginated list of contacts that belong to the specified list.

        **[Required scopes](/using-the-api/scopes/):** `lists:read` and `contacts:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          list_id: Unique identifier of the list.

          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not list_id:
            raise ValueError(f"Expected a non-empty value for `list_id` but received {list_id!r}")
        return await self._get(
            path_template("/v1/lists/{list_id}/contacts", list_id=list_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    list_list_contacts_params.ListListContactsParams,
                ),
            ),
            cast_to=ListListContactsResponse,
        )

    async def list_opportunities(
        self,
        list_id: str,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ListListOpportunitiesResponse:
        """
        Returns a paginated list of opportunities that belong to the specified list.

        **[Required scopes](/using-the-api/scopes/):** `lists:read` and
        `opportunities:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          list_id: Unique identifier of the list.

          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not list_id:
            raise ValueError(f"Expected a non-empty value for `list_id` but received {list_id!r}")
        return await self._get(
            path_template("/v1/lists/{list_id}/opportunities", list_id=list_id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    list_list_opportunities_params.ListListOpportunitiesParams,
                ),
            ),
            cast_to=ListListOpportunitiesResponse,
        )


class ListResourceWithRawResponse:
    def __init__(self, list: ListResource) -> None:
        self._list = list

        self.create = to_raw_response_wrapper(
            list.create,
        )
        self.retrieve = to_raw_response_wrapper(
            list.retrieve,
        )
        self.update = to_raw_response_wrapper(
            list.update,
        )
        self.list = to_raw_response_wrapper(
            list.list,
        )
        self.list_accounts = to_raw_response_wrapper(
            list.list_accounts,
        )
        self.list_contacts = to_raw_response_wrapper(
            list.list_contacts,
        )
        self.list_opportunities = to_raw_response_wrapper(
            list.list_opportunities,
        )


class AsyncListResourceWithRawResponse:
    def __init__(self, list: AsyncListResource) -> None:
        self._list = list

        self.create = async_to_raw_response_wrapper(
            list.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            list.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            list.update,
        )
        self.list = async_to_raw_response_wrapper(
            list.list,
        )
        self.list_accounts = async_to_raw_response_wrapper(
            list.list_accounts,
        )
        self.list_contacts = async_to_raw_response_wrapper(
            list.list_contacts,
        )
        self.list_opportunities = async_to_raw_response_wrapper(
            list.list_opportunities,
        )


class ListResourceWithStreamingResponse:
    def __init__(self, list: ListResource) -> None:
        self._list = list

        self.create = to_streamed_response_wrapper(
            list.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            list.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            list.update,
        )
        self.list = to_streamed_response_wrapper(
            list.list,
        )
        self.list_accounts = to_streamed_response_wrapper(
            list.list_accounts,
        )
        self.list_contacts = to_streamed_response_wrapper(
            list.list_contacts,
        )
        self.list_opportunities = to_streamed_response_wrapper(
            list.list_opportunities,
        )


class AsyncListResourceWithStreamingResponse:
    def __init__(self, list: AsyncListResource) -> None:
        self._list = list

        self.create = async_to_streamed_response_wrapper(
            list.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            list.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            list.update,
        )
        self.list = async_to_streamed_response_wrapper(
            list.list,
        )
        self.list_accounts = async_to_streamed_response_wrapper(
            list.list_accounts,
        )
        self.list_contacts = async_to_streamed_response_wrapper(
            list.list_contacts,
        )
        self.list_opportunities = async_to_streamed_response_wrapper(
            list.list_opportunities,
        )
