# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import meeting_list_params, meeting_create_params, meeting_update_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.meeting_list_response import MeetingListResponse
from ..types.meeting_create_response import MeetingCreateResponse
from ..types.meeting_update_response import MeetingUpdateResponse
from ..types.meeting_retrieve_response import MeetingRetrieveResponse

__all__ = ["MeetingResource", "AsyncMeetingResource"]


class MeetingResource(SyncAPIResource):
    """Meetings represent synced or manually created interactions in Lightfield.

    Read responses are privacy-aware and may be redacted based on the caller. For transcript uploads and attachment flows, see <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>.
    """

    @cached_property
    def with_raw_response(self) -> MeetingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return MeetingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> MeetingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return MeetingResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        fields: meeting_create_params.Fields,
        auto_create_records: bool | Omit = omit,
        relationships: meeting_create_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeetingCreateResponse:
        """Creates a new meeting record.

        This endpoint only supports creation of meetings
        in the past. The `$title`, `$startDate`, and `$endDate` fields are required.
        Only the `$transcript` relationship is writable on create; all other meeting
        relationships are system-managed. The `$account` and `$opportunity`
        relationships are read-only and are derived from the meeting's `$contact`
        attendees and the accounts/opportunities those contacts belong to. The response
        is privacy-aware and includes a read-only `accessLevel`. See
        <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>
        for the full file upload and transcript attachment flow.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `meetings:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          fields: Field values for the new MANUAL meeting. System fields use a `$` prefix (for
              example `$title`, `$startDate`, `$endDate`). Required: `$title`, `$startDate`,
              and `$endDate`. `$organizerEmail` accepts a single email address when provided;
              `$attendeeEmails` accepts an array of email addresses. See
              <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
              value type details.

          auto_create_records: When true, the initial post-create meeting sync may auto-create account and
              contact records for external attendees.

          relationships: Relationships to set on the new meeting. Only `$transcript` is writable on
              create; all other meeting relationships are system-managed.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/meetings",
            body=maybe_transform(
                {
                    "fields": fields,
                    "auto_create_records": auto_create_records,
                    "relationships": relationships,
                },
                meeting_create_params.MeetingCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeetingCreateResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeetingRetrieveResponse:
        """Retrieves a single meeting by its ID.

        Meeting fields and transcript visibility
        are redacted based on the caller-specific privacy resolution, and the response
        includes a read-only `accessLevel`.

        **[Required scope](/using-the-api/scopes/):** `meetings:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the meeting to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v1/meetings/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeetingRetrieveResponse,
        )

    def update(
        self,
        id: str,
        *,
        fields: meeting_update_params.Fields | Omit = omit,
        relationships: meeting_update_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeetingUpdateResponse:
        """Updates an existing meeting by ID.

        Only included fields and relationships are
        modified.

        Only `fields.$privacySetting` and `relationships.$transcript.replace` are
        writable. Use `$transcript.replace` to set the meeting transcript. Clearing or
        removing `$transcript` is not supported. The `$account` and `$opportunity`
        relationships are read-only and are derived from the meeting's `$contact`
        attendees and the accounts/opportunities those contacts belong to. The response
        is privacy-aware and includes a read-only `accessLevel`. See
        <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>
        for the full file upload and transcript attachment flow.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `meetings:update`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the meeting to update.

          fields: Field values to update. Only `$privacySetting` is writable, and omitted fields
              are left unchanged.

          relationships: Relationship operations to apply. Only `$transcript.replace` is supported;
              removing or clearing `$transcript` is not supported.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/v1/meetings/{id}", id=id),
            body=maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                meeting_update_params.MeetingUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeetingUpdateResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeetingListResponse:
        """Returns a paginated list of meetings.

        Use `offset` and `limit` to paginate
        through results. Each meeting is privacy-filtered per caller, includes a
        read-only `accessLevel`, and may redact transcript or content fields based on
        the caller-specific privacy resolution. See
        <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more information
        about pagination.

        **[Required scope](/using-the-api/scopes/):** `meetings:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/meetings",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    meeting_list_params.MeetingListParams,
                ),
            ),
            cast_to=MeetingListResponse,
        )


class AsyncMeetingResource(AsyncAPIResource):
    """Meetings represent synced or manually created interactions in Lightfield.

    Read responses are privacy-aware and may be redacted based on the caller. For transcript uploads and attachment flows, see <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>.
    """

    @cached_property
    def with_raw_response(self) -> AsyncMeetingResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return AsyncMeetingResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncMeetingResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return AsyncMeetingResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        fields: meeting_create_params.Fields,
        auto_create_records: bool | Omit = omit,
        relationships: meeting_create_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeetingCreateResponse:
        """Creates a new meeting record.

        This endpoint only supports creation of meetings
        in the past. The `$title`, `$startDate`, and `$endDate` fields are required.
        Only the `$transcript` relationship is writable on create; all other meeting
        relationships are system-managed. The `$account` and `$opportunity`
        relationships are read-only and are derived from the meeting's `$contact`
        attendees and the accounts/opportunities those contacts belong to. The response
        is privacy-aware and includes a read-only `accessLevel`. See
        <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>
        for the full file upload and transcript attachment flow.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `meetings:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          fields: Field values for the new MANUAL meeting. System fields use a `$` prefix (for
              example `$title`, `$startDate`, `$endDate`). Required: `$title`, `$startDate`,
              and `$endDate`. `$organizerEmail` accepts a single email address when provided;
              `$attendeeEmails` accepts an array of email addresses. See
              <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
              value type details.

          auto_create_records: When true, the initial post-create meeting sync may auto-create account and
              contact records for external attendees.

          relationships: Relationships to set on the new meeting. Only `$transcript` is writable on
              create; all other meeting relationships are system-managed.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/meetings",
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "auto_create_records": auto_create_records,
                    "relationships": relationships,
                },
                meeting_create_params.MeetingCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeetingCreateResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeetingRetrieveResponse:
        """Retrieves a single meeting by its ID.

        Meeting fields and transcript visibility
        are redacted based on the caller-specific privacy resolution, and the response
        includes a read-only `accessLevel`.

        **[Required scope](/using-the-api/scopes/):** `meetings:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the meeting to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v1/meetings/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeetingRetrieveResponse,
        )

    async def update(
        self,
        id: str,
        *,
        fields: meeting_update_params.Fields | Omit = omit,
        relationships: meeting_update_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeetingUpdateResponse:
        """Updates an existing meeting by ID.

        Only included fields and relationships are
        modified.

        Only `fields.$privacySetting` and `relationships.$transcript.replace` are
        writable. Use `$transcript.replace` to set the meeting transcript. Clearing or
        removing `$transcript` is not supported. The `$account` and `$opportunity`
        relationships are read-only and are derived from the meeting's `$contact`
        attendees and the accounts/opportunities those contacts belong to. The response
        is privacy-aware and includes a read-only `accessLevel`. See
        <u>[Uploading meeting transcripts](/using-the-api/uploading-meeting-transcripts/)</u>
        for the full file upload and transcript attachment flow.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `meetings:update`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the meeting to update.

          fields: Field values to update. Only `$privacySetting` is writable, and omitted fields
              are left unchanged.

          relationships: Relationship operations to apply. Only `$transcript.replace` is supported;
              removing or clearing `$transcript` is not supported.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/v1/meetings/{id}", id=id),
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                meeting_update_params.MeetingUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeetingUpdateResponse,
        )

    async def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeetingListResponse:
        """Returns a paginated list of meetings.

        Use `offset` and `limit` to paginate
        through results. Each meeting is privacy-filtered per caller, includes a
        read-only `accessLevel`, and may redact transcript or content fields based on
        the caller-specific privacy resolution. See
        <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more information
        about pagination.

        **[Required scope](/using-the-api/scopes/):** `meetings:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/meetings",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    meeting_list_params.MeetingListParams,
                ),
            ),
            cast_to=MeetingListResponse,
        )


class MeetingResourceWithRawResponse:
    def __init__(self, meeting: MeetingResource) -> None:
        self._meeting = meeting

        self.create = to_raw_response_wrapper(
            meeting.create,
        )
        self.retrieve = to_raw_response_wrapper(
            meeting.retrieve,
        )
        self.update = to_raw_response_wrapper(
            meeting.update,
        )
        self.list = to_raw_response_wrapper(
            meeting.list,
        )


class AsyncMeetingResourceWithRawResponse:
    def __init__(self, meeting: AsyncMeetingResource) -> None:
        self._meeting = meeting

        self.create = async_to_raw_response_wrapper(
            meeting.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            meeting.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            meeting.update,
        )
        self.list = async_to_raw_response_wrapper(
            meeting.list,
        )


class MeetingResourceWithStreamingResponse:
    def __init__(self, meeting: MeetingResource) -> None:
        self._meeting = meeting

        self.create = to_streamed_response_wrapper(
            meeting.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            meeting.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            meeting.update,
        )
        self.list = to_streamed_response_wrapper(
            meeting.list,
        )


class AsyncMeetingResourceWithStreamingResponse:
    def __init__(self, meeting: AsyncMeetingResource) -> None:
        self._meeting = meeting

        self.create = async_to_streamed_response_wrapper(
            meeting.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            meeting.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            meeting.update,
        )
        self.list = async_to_streamed_response_wrapper(
            meeting.list,
        )
