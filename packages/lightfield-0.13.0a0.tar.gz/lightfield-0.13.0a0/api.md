# Auth

Types:

```python
from lightfield.types import AuthValidateResponse
```

Methods:

- <code title="get /v1/auth/validate">client.auth.<a href="./src/lightfield/resources/auth.py">validate</a>() -> <a href="./src/lightfield/types/auth_validate_response.py">AuthValidateResponse</a></code>

# Account

Types:

```python
from lightfield.types import (
    AccountCreateResponse,
    AccountDefinitionsResponse,
    AccountListResponse,
    AccountRetrieveResponse,
    AccountUpdateResponse,
)
```

Methods:

- <code title="post /v1/accounts">client.account.<a href="./src/lightfield/resources/account.py">create</a>(\*\*<a href="src/lightfield/types/account_create_params.py">params</a>) -> <a href="./src/lightfield/types/account_create_response.py">AccountCreateResponse</a></code>
- <code title="get /v1/accounts/{id}">client.account.<a href="./src/lightfield/resources/account.py">retrieve</a>(id) -> <a href="./src/lightfield/types/account_retrieve_response.py">AccountRetrieveResponse</a></code>
- <code title="post /v1/accounts/{id}">client.account.<a href="./src/lightfield/resources/account.py">update</a>(id, \*\*<a href="src/lightfield/types/account_update_params.py">params</a>) -> <a href="./src/lightfield/types/account_update_response.py">AccountUpdateResponse</a></code>
- <code title="get /v1/accounts">client.account.<a href="./src/lightfield/resources/account.py">list</a>(\*\*<a href="src/lightfield/types/account_list_params.py">params</a>) -> <a href="./src/lightfield/types/account_list_response.py">AccountListResponse</a></code>
- <code title="get /v1/accounts/definitions">client.account.<a href="./src/lightfield/resources/account.py">definitions</a>() -> <a href="./src/lightfield/types/account_definitions_response.py">AccountDefinitionsResponse</a></code>

# Contact

Types:

```python
from lightfield.types import (
    ContactCreateResponse,
    ContactDefinitionsResponse,
    ContactListResponse,
    ContactRetrieveResponse,
    ContactUpdateResponse,
)
```

Methods:

- <code title="post /v1/contacts">client.contact.<a href="./src/lightfield/resources/contact.py">create</a>(\*\*<a href="src/lightfield/types/contact_create_params.py">params</a>) -> <a href="./src/lightfield/types/contact_create_response.py">ContactCreateResponse</a></code>
- <code title="get /v1/contacts/{id}">client.contact.<a href="./src/lightfield/resources/contact.py">retrieve</a>(id) -> <a href="./src/lightfield/types/contact_retrieve_response.py">ContactRetrieveResponse</a></code>
- <code title="post /v1/contacts/{id}">client.contact.<a href="./src/lightfield/resources/contact.py">update</a>(id, \*\*<a href="src/lightfield/types/contact_update_params.py">params</a>) -> <a href="./src/lightfield/types/contact_update_response.py">ContactUpdateResponse</a></code>
- <code title="get /v1/contacts">client.contact.<a href="./src/lightfield/resources/contact.py">list</a>(\*\*<a href="src/lightfield/types/contact_list_params.py">params</a>) -> <a href="./src/lightfield/types/contact_list_response.py">ContactListResponse</a></code>
- <code title="get /v1/contacts/definitions">client.contact.<a href="./src/lightfield/resources/contact.py">definitions</a>() -> <a href="./src/lightfield/types/contact_definitions_response.py">ContactDefinitionsResponse</a></code>

# List

Types:

```python
from lightfield.types import (
    ListCreateResponse,
    ListListAccountsResponse,
    ListListContactsResponse,
    ListListOpportunitiesResponse,
    ListListResponse,
    ListRetrieveResponse,
    ListUpdateResponse,
)
```

Methods:

- <code title="post /v1/lists">client.list.<a href="./src/lightfield/resources/list.py">create</a>(\*\*<a href="src/lightfield/types/list_create_params.py">params</a>) -> <a href="./src/lightfield/types/list_create_response.py">ListCreateResponse</a></code>
- <code title="get /v1/lists/{id}">client.list.<a href="./src/lightfield/resources/list.py">retrieve</a>(id) -> <a href="./src/lightfield/types/list_retrieve_response.py">ListRetrieveResponse</a></code>
- <code title="post /v1/lists/{id}">client.list.<a href="./src/lightfield/resources/list.py">update</a>(id, \*\*<a href="src/lightfield/types/list_update_params.py">params</a>) -> <a href="./src/lightfield/types/list_update_response.py">ListUpdateResponse</a></code>
- <code title="get /v1/lists">client.list.<a href="./src/lightfield/resources/list.py">list</a>(\*\*<a href="src/lightfield/types/list_list_params.py">params</a>) -> <a href="./src/lightfield/types/list_list_response.py">ListListResponse</a></code>
- <code title="get /v1/lists/{listId}/accounts">client.list.<a href="./src/lightfield/resources/list.py">list_accounts</a>(list_id, \*\*<a href="src/lightfield/types/list_list_accounts_params.py">params</a>) -> <a href="./src/lightfield/types/list_list_accounts_response.py">ListListAccountsResponse</a></code>
- <code title="get /v1/lists/{listId}/contacts">client.list.<a href="./src/lightfield/resources/list.py">list_contacts</a>(list_id, \*\*<a href="src/lightfield/types/list_list_contacts_params.py">params</a>) -> <a href="./src/lightfield/types/list_list_contacts_response.py">ListListContactsResponse</a></code>
- <code title="get /v1/lists/{listId}/opportunities">client.list.<a href="./src/lightfield/resources/list.py">list_opportunities</a>(list_id, \*\*<a href="src/lightfield/types/list_list_opportunities_params.py">params</a>) -> <a href="./src/lightfield/types/list_list_opportunities_response.py">ListListOpportunitiesResponse</a></code>

# Meeting

Types:

```python
from lightfield.types import (
    MeetingCreateResponse,
    MeetingListResponse,
    MeetingRetrieveResponse,
    MeetingUpdateResponse,
)
```

Methods:

- <code title="post /v1/meetings">client.meeting.<a href="./src/lightfield/resources/meeting.py">create</a>(\*\*<a href="src/lightfield/types/meeting_create_params.py">params</a>) -> <a href="./src/lightfield/types/meeting_create_response.py">MeetingCreateResponse</a></code>
- <code title="get /v1/meetings/{id}">client.meeting.<a href="./src/lightfield/resources/meeting.py">retrieve</a>(id) -> <a href="./src/lightfield/types/meeting_retrieve_response.py">MeetingRetrieveResponse</a></code>
- <code title="post /v1/meetings/{id}">client.meeting.<a href="./src/lightfield/resources/meeting.py">update</a>(id, \*\*<a href="src/lightfield/types/meeting_update_params.py">params</a>) -> <a href="./src/lightfield/types/meeting_update_response.py">MeetingUpdateResponse</a></code>
- <code title="get /v1/meetings">client.meeting.<a href="./src/lightfield/resources/meeting.py">list</a>(\*\*<a href="src/lightfield/types/meeting_list_params.py">params</a>) -> <a href="./src/lightfield/types/meeting_list_response.py">MeetingListResponse</a></code>

# Note

Types:

```python
from lightfield.types import (
    NoteCreateResponse,
    NoteListResponse,
    NoteRetrieveResponse,
    NoteUpdateResponse,
)
```

Methods:

- <code title="post /v1/notes">client.note.<a href="./src/lightfield/resources/note.py">create</a>(\*\*<a href="src/lightfield/types/note_create_params.py">params</a>) -> <a href="./src/lightfield/types/note_create_response.py">NoteCreateResponse</a></code>
- <code title="get /v1/notes/{id}">client.note.<a href="./src/lightfield/resources/note.py">retrieve</a>(id) -> <a href="./src/lightfield/types/note_retrieve_response.py">NoteRetrieveResponse</a></code>
- <code title="post /v1/notes/{id}">client.note.<a href="./src/lightfield/resources/note.py">update</a>(id, \*\*<a href="src/lightfield/types/note_update_params.py">params</a>) -> <a href="./src/lightfield/types/note_update_response.py">NoteUpdateResponse</a></code>
- <code title="get /v1/notes">client.note.<a href="./src/lightfield/resources/note.py">list</a>(\*\*<a href="src/lightfield/types/note_list_params.py">params</a>) -> <a href="./src/lightfield/types/note_list_response.py">NoteListResponse</a></code>

# Opportunity

Types:

```python
from lightfield.types import (
    OpportunityCreateResponse,
    OpportunityDefinitionsResponse,
    OpportunityListResponse,
    OpportunityRetrieveResponse,
    OpportunityUpdateResponse,
)
```

Methods:

- <code title="post /v1/opportunities">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">create</a>(\*\*<a href="src/lightfield/types/opportunity_create_params.py">params</a>) -> <a href="./src/lightfield/types/opportunity_create_response.py">OpportunityCreateResponse</a></code>
- <code title="get /v1/opportunities/{id}">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">retrieve</a>(id) -> <a href="./src/lightfield/types/opportunity_retrieve_response.py">OpportunityRetrieveResponse</a></code>
- <code title="post /v1/opportunities/{id}">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">update</a>(id, \*\*<a href="src/lightfield/types/opportunity_update_params.py">params</a>) -> <a href="./src/lightfield/types/opportunity_update_response.py">OpportunityUpdateResponse</a></code>
- <code title="get /v1/opportunities">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">list</a>(\*\*<a href="src/lightfield/types/opportunity_list_params.py">params</a>) -> <a href="./src/lightfield/types/opportunity_list_response.py">OpportunityListResponse</a></code>
- <code title="get /v1/opportunities/definitions">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">definitions</a>() -> <a href="./src/lightfield/types/opportunity_definitions_response.py">OpportunityDefinitionsResponse</a></code>

# Task

Types:

```python
from lightfield.types import (
    TaskCreateResponse,
    TaskDefinitionsResponse,
    TaskListResponse,
    TaskRetrieveResponse,
    TaskUpdateResponse,
)
```

Methods:

- <code title="post /v1/tasks">client.task.<a href="./src/lightfield/resources/task.py">create</a>(\*\*<a href="src/lightfield/types/task_create_params.py">params</a>) -> <a href="./src/lightfield/types/task_create_response.py">TaskCreateResponse</a></code>
- <code title="get /v1/tasks/{id}">client.task.<a href="./src/lightfield/resources/task.py">retrieve</a>(id) -> <a href="./src/lightfield/types/task_retrieve_response.py">TaskRetrieveResponse</a></code>
- <code title="post /v1/tasks/{id}">client.task.<a href="./src/lightfield/resources/task.py">update</a>(id, \*\*<a href="src/lightfield/types/task_update_params.py">params</a>) -> <a href="./src/lightfield/types/task_update_response.py">TaskUpdateResponse</a></code>
- <code title="get /v1/tasks">client.task.<a href="./src/lightfield/resources/task.py">list</a>(\*\*<a href="src/lightfield/types/task_list_params.py">params</a>) -> <a href="./src/lightfield/types/task_list_response.py">TaskListResponse</a></code>
- <code title="get /v1/tasks/definitions">client.task.<a href="./src/lightfield/resources/task.py">definitions</a>() -> <a href="./src/lightfield/types/task_definitions_response.py">TaskDefinitionsResponse</a></code>

# Member

Types:

```python
from lightfield.types import MemberListResponse, MemberRetrieveResponse
```

Methods:

- <code title="get /v1/members/{id}">client.member.<a href="./src/lightfield/resources/member.py">retrieve</a>(id) -> <a href="./src/lightfield/types/member_retrieve_response.py">MemberRetrieveResponse</a></code>
- <code title="get /v1/members">client.member.<a href="./src/lightfield/resources/member.py">list</a>(\*\*<a href="src/lightfield/types/member_list_params.py">params</a>) -> <a href="./src/lightfield/types/member_list_response.py">MemberListResponse</a></code>

# WorkflowRun

Types:

```python
from lightfield.types import WorkflowRunStatusResponse
```

Methods:

- <code title="get /v1/workflowRun/{runId}/status">client.workflow_run.<a href="./src/lightfield/resources/workflow_run.py">status</a>(run_id) -> <a href="./src/lightfield/types/workflow_run_status_response.py">WorkflowRunStatusResponse</a></code>

# File

Types:

```python
from lightfield.types import (
    FileCancelResponse,
    FileCompleteResponse,
    FileCreateResponse,
    FileListResponse,
    FileRetrieveResponse,
    FileURLResponse,
)
```

Methods:

- <code title="post /v1/files">client.file.<a href="./src/lightfield/resources/file.py">create</a>(\*\*<a href="src/lightfield/types/file_create_params.py">params</a>) -> <a href="./src/lightfield/types/file_create_response.py">FileCreateResponse</a></code>
- <code title="get /v1/files/{id}">client.file.<a href="./src/lightfield/resources/file.py">retrieve</a>(id) -> <a href="./src/lightfield/types/file_retrieve_response.py">FileRetrieveResponse</a></code>
- <code title="get /v1/files">client.file.<a href="./src/lightfield/resources/file.py">list</a>(\*\*<a href="src/lightfield/types/file_list_params.py">params</a>) -> <a href="./src/lightfield/types/file_list_response.py">FileListResponse</a></code>
- <code title="post /v1/files/{id}/cancel">client.file.<a href="./src/lightfield/resources/file.py">cancel</a>(id, \*\*<a href="src/lightfield/types/file_cancel_params.py">params</a>) -> <a href="./src/lightfield/types/file_cancel_response.py">FileCancelResponse</a></code>
- <code title="post /v1/files/{id}/complete">client.file.<a href="./src/lightfield/resources/file.py">complete</a>(id, \*\*<a href="src/lightfield/types/file_complete_params.py">params</a>) -> <a href="./src/lightfield/types/file_complete_response.py">FileCompleteResponse</a></code>
- <code title="get /v1/files/{id}/url">client.file.<a href="./src/lightfield/resources/file.py">url</a>(id) -> <a href="./src/lightfield/types/file_url_response.py">FileURLResponse</a></code>

# Object

Types:

```python
from lightfield.types import (
    ObjectCreateResponse,
    ObjectDefinitionsResponse,
    ObjectListDefinitionsResponse,
    ObjectListResponse,
    ObjectRetrieveResponse,
    ObjectUpdateResponse,
)
```

Methods:

- <code title="post /v1/objects/{entitySlug}/values">client.object.<a href="./src/lightfield/resources/object.py">create</a>(entity_slug, \*\*<a href="src/lightfield/types/object_create_params.py">params</a>) -> <a href="./src/lightfield/types/object_create_response.py">ObjectCreateResponse</a></code>
- <code title="get /v1/objects/{entitySlug}/values/{id}">client.object.<a href="./src/lightfield/resources/object.py">retrieve</a>(id, \*, entity_slug) -> <a href="./src/lightfield/types/object_retrieve_response.py">ObjectRetrieveResponse</a></code>
- <code title="post /v1/objects/{entitySlug}/values/{id}">client.object.<a href="./src/lightfield/resources/object.py">update</a>(id, \*, entity_slug, \*\*<a href="src/lightfield/types/object_update_params.py">params</a>) -> <a href="./src/lightfield/types/object_update_response.py">ObjectUpdateResponse</a></code>
- <code title="get /v1/objects/{entitySlug}">client.object.<a href="./src/lightfield/resources/object.py">list</a>(entity_slug, \*\*<a href="src/lightfield/types/object_list_params.py">params</a>) -> <a href="./src/lightfield/types/object_list_response.py">ObjectListResponse</a></code>
- <code title="get /v1/objects/{entitySlug}/definitions">client.object.<a href="./src/lightfield/resources/object.py">definitions</a>(entity_slug) -> <a href="./src/lightfield/types/object_definitions_response.py">ObjectDefinitionsResponse</a></code>
- <code title="get /v1/objects">client.object.<a href="./src/lightfield/resources/object.py">list_definitions</a>() -> <a href="./src/lightfield/types/object_list_definitions_response.py">ObjectListDefinitionsResponse</a></code>

# Email

Types:

```python
from lightfield.types import (
    EmailDraftResponse,
    EmailListResponse,
    EmailRetrieveResponse,
    EmailSendResponse,
)
```

Methods:

- <code title="get /v1/emails/{id}">client.email.<a href="./src/lightfield/resources/email.py">retrieve</a>(id) -> <a href="./src/lightfield/types/email_retrieve_response.py">EmailRetrieveResponse</a></code>
- <code title="get /v1/emails">client.email.<a href="./src/lightfield/resources/email.py">list</a>(\*\*<a href="src/lightfield/types/email_list_params.py">params</a>) -> <a href="./src/lightfield/types/email_list_response.py">EmailListResponse</a></code>
- <code title="post /v1/emails/draft">client.email.<a href="./src/lightfield/resources/email.py">draft</a>(\*\*<a href="src/lightfield/types/email_draft_params.py">params</a>) -> <a href="./src/lightfield/types/email_draft_response.py">EmailDraftResponse</a></code>
- <code title="post /v1/emails/send">client.email.<a href="./src/lightfield/resources/email.py">send</a>(\*\*<a href="src/lightfield/types/email_send_params.py">params</a>) -> <a href="./src/lightfield/types/email_send_response.py">EmailSendResponse</a></code>
