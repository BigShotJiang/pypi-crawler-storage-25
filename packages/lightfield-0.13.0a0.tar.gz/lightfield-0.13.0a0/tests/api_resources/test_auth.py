# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from lightfield import Lightfield, AsyncLightfield
from tests.utils import assert_matches_type
from lightfield.types import AuthValidateResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAuth:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_validate(self, client: Lightfield) -> None:
        auth = client.auth.validate()
        assert_matches_type(AuthValidateResponse, auth, path=["response"])

    @parametrize
    def test_raw_response_validate(self, client: Lightfield) -> None:
        response = client.auth.with_raw_response.validate()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = response.parse()
        assert_matches_type(AuthValidateResponse, auth, path=["response"])

    @parametrize
    def test_streaming_response_validate(self, client: Lightfield) -> None:
        with client.auth.with_streaming_response.validate() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = response.parse()
            assert_matches_type(AuthValidateResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncAuth:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_validate(self, async_client: AsyncLightfield) -> None:
        auth = await async_client.auth.validate()
        assert_matches_type(AuthValidateResponse, auth, path=["response"])

    @parametrize
    async def test_raw_response_validate(self, async_client: AsyncLightfield) -> None:
        response = await async_client.auth.with_raw_response.validate()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        auth = await response.parse()
        assert_matches_type(AuthValidateResponse, auth, path=["response"])

    @parametrize
    async def test_streaming_response_validate(self, async_client: AsyncLightfield) -> None:
        async with async_client.auth.with_streaming_response.validate() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            auth = await response.parse()
            assert_matches_type(AuthValidateResponse, auth, path=["response"])

        assert cast(Any, response.is_closed) is True
