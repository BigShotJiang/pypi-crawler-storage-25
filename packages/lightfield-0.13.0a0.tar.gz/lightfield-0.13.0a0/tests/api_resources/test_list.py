# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from lightfield import Lightfield, AsyncLightfield
from tests.utils import assert_matches_type
from lightfield.types import (
    ListListResponse,
    ListCreateResponse,
    ListUpdateResponse,
    ListRetrieveResponse,
    ListListAccountsResponse,
    ListListContactsResponse,
    ListListOpportunitiesResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestList:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Lightfield) -> None:
        list_ = client.list.create(
            fields={
                "name": "$name",
                "object_type": "$objectType",
            },
        )
        assert_matches_type(ListCreateResponse, list_, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Lightfield) -> None:
        list_ = client.list.create(
            fields={
                "name": "$name",
                "object_type": "$objectType",
            },
            relationships={"accounts": "string"},
        )
        assert_matches_type(ListCreateResponse, list_, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Lightfield) -> None:
        response = client.list.with_raw_response.create(
            fields={
                "name": "$name",
                "object_type": "$objectType",
            },
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = response.parse()
        assert_matches_type(ListCreateResponse, list_, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Lightfield) -> None:
        with client.list.with_streaming_response.create(
            fields={
                "name": "$name",
                "object_type": "$objectType",
            },
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = response.parse()
            assert_matches_type(ListCreateResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: Lightfield) -> None:
        list_ = client.list.retrieve(
            "id",
        )
        assert_matches_type(ListRetrieveResponse, list_, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Lightfield) -> None:
        response = client.list.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = response.parse()
        assert_matches_type(ListRetrieveResponse, list_, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Lightfield) -> None:
        with client.list.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = response.parse()
            assert_matches_type(ListRetrieveResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.list.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_update(self, client: Lightfield) -> None:
        list_ = client.list.update(
            id="id",
        )
        assert_matches_type(ListUpdateResponse, list_, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Lightfield) -> None:
        list_ = client.list.update(
            id="id",
            fields={"name": "$name"},
            relationships={
                "accounts": {
                    "add": "string",
                    "remove": "string",
                }
            },
        )
        assert_matches_type(ListUpdateResponse, list_, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Lightfield) -> None:
        response = client.list.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = response.parse()
        assert_matches_type(ListUpdateResponse, list_, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Lightfield) -> None:
        with client.list.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = response.parse()
            assert_matches_type(ListUpdateResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.list.with_raw_response.update(
                id="",
            )

    @parametrize
    def test_method_list(self, client: Lightfield) -> None:
        list_ = client.list.list()
        assert_matches_type(ListListResponse, list_, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Lightfield) -> None:
        list_ = client.list.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(ListListResponse, list_, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Lightfield) -> None:
        response = client.list.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = response.parse()
        assert_matches_type(ListListResponse, list_, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Lightfield) -> None:
        with client.list.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = response.parse()
            assert_matches_type(ListListResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_list_accounts(self, client: Lightfield) -> None:
        list_ = client.list.list_accounts(
            list_id="listId",
        )
        assert_matches_type(ListListAccountsResponse, list_, path=["response"])

    @parametrize
    def test_method_list_accounts_with_all_params(self, client: Lightfield) -> None:
        list_ = client.list.list_accounts(
            list_id="listId",
            limit=1,
            offset=0,
        )
        assert_matches_type(ListListAccountsResponse, list_, path=["response"])

    @parametrize
    def test_raw_response_list_accounts(self, client: Lightfield) -> None:
        response = client.list.with_raw_response.list_accounts(
            list_id="listId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = response.parse()
        assert_matches_type(ListListAccountsResponse, list_, path=["response"])

    @parametrize
    def test_streaming_response_list_accounts(self, client: Lightfield) -> None:
        with client.list.with_streaming_response.list_accounts(
            list_id="listId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = response.parse()
            assert_matches_type(ListListAccountsResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_accounts(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `list_id` but received ''"):
            client.list.with_raw_response.list_accounts(
                list_id="",
            )

    @parametrize
    def test_method_list_contacts(self, client: Lightfield) -> None:
        list_ = client.list.list_contacts(
            list_id="listId",
        )
        assert_matches_type(ListListContactsResponse, list_, path=["response"])

    @parametrize
    def test_method_list_contacts_with_all_params(self, client: Lightfield) -> None:
        list_ = client.list.list_contacts(
            list_id="listId",
            limit=1,
            offset=0,
        )
        assert_matches_type(ListListContactsResponse, list_, path=["response"])

    @parametrize
    def test_raw_response_list_contacts(self, client: Lightfield) -> None:
        response = client.list.with_raw_response.list_contacts(
            list_id="listId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = response.parse()
        assert_matches_type(ListListContactsResponse, list_, path=["response"])

    @parametrize
    def test_streaming_response_list_contacts(self, client: Lightfield) -> None:
        with client.list.with_streaming_response.list_contacts(
            list_id="listId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = response.parse()
            assert_matches_type(ListListContactsResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_contacts(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `list_id` but received ''"):
            client.list.with_raw_response.list_contacts(
                list_id="",
            )

    @parametrize
    def test_method_list_opportunities(self, client: Lightfield) -> None:
        list_ = client.list.list_opportunities(
            list_id="listId",
        )
        assert_matches_type(ListListOpportunitiesResponse, list_, path=["response"])

    @parametrize
    def test_method_list_opportunities_with_all_params(self, client: Lightfield) -> None:
        list_ = client.list.list_opportunities(
            list_id="listId",
            limit=1,
            offset=0,
        )
        assert_matches_type(ListListOpportunitiesResponse, list_, path=["response"])

    @parametrize
    def test_raw_response_list_opportunities(self, client: Lightfield) -> None:
        response = client.list.with_raw_response.list_opportunities(
            list_id="listId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = response.parse()
        assert_matches_type(ListListOpportunitiesResponse, list_, path=["response"])

    @parametrize
    def test_streaming_response_list_opportunities(self, client: Lightfield) -> None:
        with client.list.with_streaming_response.list_opportunities(
            list_id="listId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = response.parse()
            assert_matches_type(ListListOpportunitiesResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list_opportunities(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `list_id` but received ''"):
            client.list.with_raw_response.list_opportunities(
                list_id="",
            )


class TestAsyncList:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.create(
            fields={
                "name": "$name",
                "object_type": "$objectType",
            },
        )
        assert_matches_type(ListCreateResponse, list_, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.create(
            fields={
                "name": "$name",
                "object_type": "$objectType",
            },
            relationships={"accounts": "string"},
        )
        assert_matches_type(ListCreateResponse, list_, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLightfield) -> None:
        response = await async_client.list.with_raw_response.create(
            fields={
                "name": "$name",
                "object_type": "$objectType",
            },
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = await response.parse()
        assert_matches_type(ListCreateResponse, list_, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLightfield) -> None:
        async with async_client.list.with_streaming_response.create(
            fields={
                "name": "$name",
                "object_type": "$objectType",
            },
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = await response.parse()
            assert_matches_type(ListCreateResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.retrieve(
            "id",
        )
        assert_matches_type(ListRetrieveResponse, list_, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLightfield) -> None:
        response = await async_client.list.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = await response.parse()
        assert_matches_type(ListRetrieveResponse, list_, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLightfield) -> None:
        async with async_client.list.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = await response.parse()
            assert_matches_type(ListRetrieveResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.list.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.update(
            id="id",
        )
        assert_matches_type(ListUpdateResponse, list_, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.update(
            id="id",
            fields={"name": "$name"},
            relationships={
                "accounts": {
                    "add": "string",
                    "remove": "string",
                }
            },
        )
        assert_matches_type(ListUpdateResponse, list_, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLightfield) -> None:
        response = await async_client.list.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = await response.parse()
        assert_matches_type(ListUpdateResponse, list_, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLightfield) -> None:
        async with async_client.list.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = await response.parse()
            assert_matches_type(ListUpdateResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.list.with_raw_response.update(
                id="",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.list()
        assert_matches_type(ListListResponse, list_, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(ListListResponse, list_, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLightfield) -> None:
        response = await async_client.list.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = await response.parse()
        assert_matches_type(ListListResponse, list_, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLightfield) -> None:
        async with async_client.list.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = await response.parse()
            assert_matches_type(ListListResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_list_accounts(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.list_accounts(
            list_id="listId",
        )
        assert_matches_type(ListListAccountsResponse, list_, path=["response"])

    @parametrize
    async def test_method_list_accounts_with_all_params(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.list_accounts(
            list_id="listId",
            limit=1,
            offset=0,
        )
        assert_matches_type(ListListAccountsResponse, list_, path=["response"])

    @parametrize
    async def test_raw_response_list_accounts(self, async_client: AsyncLightfield) -> None:
        response = await async_client.list.with_raw_response.list_accounts(
            list_id="listId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = await response.parse()
        assert_matches_type(ListListAccountsResponse, list_, path=["response"])

    @parametrize
    async def test_streaming_response_list_accounts(self, async_client: AsyncLightfield) -> None:
        async with async_client.list.with_streaming_response.list_accounts(
            list_id="listId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = await response.parse()
            assert_matches_type(ListListAccountsResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_accounts(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `list_id` but received ''"):
            await async_client.list.with_raw_response.list_accounts(
                list_id="",
            )

    @parametrize
    async def test_method_list_contacts(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.list_contacts(
            list_id="listId",
        )
        assert_matches_type(ListListContactsResponse, list_, path=["response"])

    @parametrize
    async def test_method_list_contacts_with_all_params(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.list_contacts(
            list_id="listId",
            limit=1,
            offset=0,
        )
        assert_matches_type(ListListContactsResponse, list_, path=["response"])

    @parametrize
    async def test_raw_response_list_contacts(self, async_client: AsyncLightfield) -> None:
        response = await async_client.list.with_raw_response.list_contacts(
            list_id="listId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = await response.parse()
        assert_matches_type(ListListContactsResponse, list_, path=["response"])

    @parametrize
    async def test_streaming_response_list_contacts(self, async_client: AsyncLightfield) -> None:
        async with async_client.list.with_streaming_response.list_contacts(
            list_id="listId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = await response.parse()
            assert_matches_type(ListListContactsResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_contacts(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `list_id` but received ''"):
            await async_client.list.with_raw_response.list_contacts(
                list_id="",
            )

    @parametrize
    async def test_method_list_opportunities(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.list_opportunities(
            list_id="listId",
        )
        assert_matches_type(ListListOpportunitiesResponse, list_, path=["response"])

    @parametrize
    async def test_method_list_opportunities_with_all_params(self, async_client: AsyncLightfield) -> None:
        list_ = await async_client.list.list_opportunities(
            list_id="listId",
            limit=1,
            offset=0,
        )
        assert_matches_type(ListListOpportunitiesResponse, list_, path=["response"])

    @parametrize
    async def test_raw_response_list_opportunities(self, async_client: AsyncLightfield) -> None:
        response = await async_client.list.with_raw_response.list_opportunities(
            list_id="listId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        list_ = await response.parse()
        assert_matches_type(ListListOpportunitiesResponse, list_, path=["response"])

    @parametrize
    async def test_streaming_response_list_opportunities(self, async_client: AsyncLightfield) -> None:
        async with async_client.list.with_streaming_response.list_opportunities(
            list_id="listId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            list_ = await response.parse()
            assert_matches_type(ListListOpportunitiesResponse, list_, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list_opportunities(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `list_id` but received ''"):
            await async_client.list.with_raw_response.list_opportunities(
                list_id="",
            )
