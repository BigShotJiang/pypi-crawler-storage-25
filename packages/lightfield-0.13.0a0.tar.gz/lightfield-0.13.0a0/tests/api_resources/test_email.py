# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from lightfield import Lightfield, AsyncLightfield
from tests.utils import assert_matches_type
from lightfield.types import (
    EmailListResponse,
    EmailSendResponse,
    EmailDraftResponse,
    EmailRetrieveResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestEmail:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_retrieve(self, client: Lightfield) -> None:
        email = client.email.retrieve(
            "id",
        )
        assert_matches_type(EmailRetrieveResponse, email, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Lightfield) -> None:
        response = client.email.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = response.parse()
        assert_matches_type(EmailRetrieveResponse, email, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Lightfield) -> None:
        with client.email.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = response.parse()
            assert_matches_type(EmailRetrieveResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.email.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_list(self, client: Lightfield) -> None:
        email = client.email.list()
        assert_matches_type(EmailListResponse, email, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Lightfield) -> None:
        email = client.email.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(EmailListResponse, email, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Lightfield) -> None:
        response = client.email.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = response.parse()
        assert_matches_type(EmailListResponse, email, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Lightfield) -> None:
        with client.email.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = response.parse()
            assert_matches_type(EmailListResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_draft(self, client: Lightfield) -> None:
        email = client.email.draft(
            from_="sales@acme.com",
        )
        assert_matches_type(EmailDraftResponse, email, path=["response"])

    @parametrize
    def test_method_draft_with_all_params(self, client: Lightfield) -> None:
        email = client.email.draft(
            from_="sales@acme.com",
            attachments=["file_01abc2def3ghi4jkl5mno6pqr"],
            bcc=["lead@example.com"],
            cc=["lead@example.com"],
            message_body={
                "content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>",
                "content_type": "HTML",
            },
            subject="subject",
            to=["lead@example.com"],
        )
        assert_matches_type(EmailDraftResponse, email, path=["response"])

    @parametrize
    def test_raw_response_draft(self, client: Lightfield) -> None:
        response = client.email.with_raw_response.draft(
            from_="sales@acme.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = response.parse()
        assert_matches_type(EmailDraftResponse, email, path=["response"])

    @parametrize
    def test_streaming_response_draft(self, client: Lightfield) -> None:
        with client.email.with_streaming_response.draft(
            from_="sales@acme.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = response.parse()
            assert_matches_type(EmailDraftResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_send(self, client: Lightfield) -> None:
        email = client.email.send(
            from_="sales@acme.com",
            message_body={"content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>"},
            subject="Following up on our chat",
            to=["lead@example.com"],
        )
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @parametrize
    def test_method_send_with_all_params(self, client: Lightfield) -> None:
        email = client.email.send(
            from_="sales@acme.com",
            message_body={
                "content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>",
                "content_type": "HTML",
            },
            subject="Following up on our chat",
            to=["lead@example.com"],
            attachments=["file_01abc2def3ghi4jkl5mno6pqr"],
            bcc=["lead@example.com"],
            cc=["lead@example.com"],
        )
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @parametrize
    def test_raw_response_send(self, client: Lightfield) -> None:
        response = client.email.with_raw_response.send(
            from_="sales@acme.com",
            message_body={"content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>"},
            subject="Following up on our chat",
            to=["lead@example.com"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = response.parse()
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @parametrize
    def test_streaming_response_send(self, client: Lightfield) -> None:
        with client.email.with_streaming_response.send(
            from_="sales@acme.com",
            message_body={"content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>"},
            subject="Following up on our chat",
            to=["lead@example.com"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = response.parse()
            assert_matches_type(EmailSendResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncEmail:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLightfield) -> None:
        email = await async_client.email.retrieve(
            "id",
        )
        assert_matches_type(EmailRetrieveResponse, email, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLightfield) -> None:
        response = await async_client.email.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = await response.parse()
        assert_matches_type(EmailRetrieveResponse, email, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLightfield) -> None:
        async with async_client.email.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = await response.parse()
            assert_matches_type(EmailRetrieveResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.email.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncLightfield) -> None:
        email = await async_client.email.list()
        assert_matches_type(EmailListResponse, email, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLightfield) -> None:
        email = await async_client.email.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(EmailListResponse, email, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLightfield) -> None:
        response = await async_client.email.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = await response.parse()
        assert_matches_type(EmailListResponse, email, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLightfield) -> None:
        async with async_client.email.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = await response.parse()
            assert_matches_type(EmailListResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_draft(self, async_client: AsyncLightfield) -> None:
        email = await async_client.email.draft(
            from_="sales@acme.com",
        )
        assert_matches_type(EmailDraftResponse, email, path=["response"])

    @parametrize
    async def test_method_draft_with_all_params(self, async_client: AsyncLightfield) -> None:
        email = await async_client.email.draft(
            from_="sales@acme.com",
            attachments=["file_01abc2def3ghi4jkl5mno6pqr"],
            bcc=["lead@example.com"],
            cc=["lead@example.com"],
            message_body={
                "content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>",
                "content_type": "HTML",
            },
            subject="subject",
            to=["lead@example.com"],
        )
        assert_matches_type(EmailDraftResponse, email, path=["response"])

    @parametrize
    async def test_raw_response_draft(self, async_client: AsyncLightfield) -> None:
        response = await async_client.email.with_raw_response.draft(
            from_="sales@acme.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = await response.parse()
        assert_matches_type(EmailDraftResponse, email, path=["response"])

    @parametrize
    async def test_streaming_response_draft(self, async_client: AsyncLightfield) -> None:
        async with async_client.email.with_streaming_response.draft(
            from_="sales@acme.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = await response.parse()
            assert_matches_type(EmailDraftResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_send(self, async_client: AsyncLightfield) -> None:
        email = await async_client.email.send(
            from_="sales@acme.com",
            message_body={"content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>"},
            subject="Following up on our chat",
            to=["lead@example.com"],
        )
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @parametrize
    async def test_method_send_with_all_params(self, async_client: AsyncLightfield) -> None:
        email = await async_client.email.send(
            from_="sales@acme.com",
            message_body={
                "content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>",
                "content_type": "HTML",
            },
            subject="Following up on our chat",
            to=["lead@example.com"],
            attachments=["file_01abc2def3ghi4jkl5mno6pqr"],
            bcc=["lead@example.com"],
            cc=["lead@example.com"],
        )
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @parametrize
    async def test_raw_response_send(self, async_client: AsyncLightfield) -> None:
        response = await async_client.email.with_raw_response.send(
            from_="sales@acme.com",
            message_body={"content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>"},
            subject="Following up on our chat",
            to=["lead@example.com"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        email = await response.parse()
        assert_matches_type(EmailSendResponse, email, path=["response"])

    @parametrize
    async def test_streaming_response_send(self, async_client: AsyncLightfield) -> None:
        async with async_client.email.with_streaming_response.send(
            from_="sales@acme.com",
            message_body={"content": "<p>Hi there,</p><p>Following up on our chat earlier this week.</p>"},
            subject="Following up on our chat",
            to=["lead@example.com"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            email = await response.parse()
            assert_matches_type(EmailSendResponse, email, path=["response"])

        assert cast(Any, response.is_closed) is True
