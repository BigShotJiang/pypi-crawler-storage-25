# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from lightfield import Lightfield, AsyncLightfield
from tests.utils import assert_matches_type
from lightfield.types import (
    FileURLResponse,
    FileListResponse,
    FileCancelResponse,
    FileCreateResponse,
    FileCompleteResponse,
    FileRetrieveResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestFile:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Lightfield) -> None:
        file = client.file.create(
            filename="x",
            mime_type="mimeType",
            size_bytes=1,
        )
        assert_matches_type(FileCreateResponse, file, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Lightfield) -> None:
        file = client.file.create(
            filename="x",
            mime_type="mimeType",
            size_bytes=1,
            purpose="meeting_transcript",
        )
        assert_matches_type(FileCreateResponse, file, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Lightfield) -> None:
        response = client.file.with_raw_response.create(
            filename="x",
            mime_type="mimeType",
            size_bytes=1,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = response.parse()
        assert_matches_type(FileCreateResponse, file, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Lightfield) -> None:
        with client.file.with_streaming_response.create(
            filename="x",
            mime_type="mimeType",
            size_bytes=1,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = response.parse()
            assert_matches_type(FileCreateResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: Lightfield) -> None:
        file = client.file.retrieve(
            "id",
        )
        assert_matches_type(FileRetrieveResponse, file, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Lightfield) -> None:
        response = client.file.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = response.parse()
        assert_matches_type(FileRetrieveResponse, file, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Lightfield) -> None:
        with client.file.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = response.parse()
            assert_matches_type(FileRetrieveResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.file.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_list(self, client: Lightfield) -> None:
        file = client.file.list()
        assert_matches_type(FileListResponse, file, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Lightfield) -> None:
        file = client.file.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(FileListResponse, file, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Lightfield) -> None:
        response = client.file.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = response.parse()
        assert_matches_type(FileListResponse, file, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Lightfield) -> None:
        with client.file.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = response.parse()
            assert_matches_type(FileListResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_cancel(self, client: Lightfield) -> None:
        file = client.file.cancel(
            id="id",
        )
        assert_matches_type(FileCancelResponse, file, path=["response"])

    @parametrize
    def test_method_cancel_with_all_params(self, client: Lightfield) -> None:
        file = client.file.cancel(
            id="id",
            body={},
        )
        assert_matches_type(FileCancelResponse, file, path=["response"])

    @parametrize
    def test_raw_response_cancel(self, client: Lightfield) -> None:
        response = client.file.with_raw_response.cancel(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = response.parse()
        assert_matches_type(FileCancelResponse, file, path=["response"])

    @parametrize
    def test_streaming_response_cancel(self, client: Lightfield) -> None:
        with client.file.with_streaming_response.cancel(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = response.parse()
            assert_matches_type(FileCancelResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_cancel(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.file.with_raw_response.cancel(
                id="",
            )

    @parametrize
    def test_method_complete(self, client: Lightfield) -> None:
        file = client.file.complete(
            id="id",
        )
        assert_matches_type(FileCompleteResponse, file, path=["response"])

    @parametrize
    def test_method_complete_with_all_params(self, client: Lightfield) -> None:
        file = client.file.complete(
            id="id",
            md5="210b9798eb53baa4e69d31c1071cf03d",
        )
        assert_matches_type(FileCompleteResponse, file, path=["response"])

    @parametrize
    def test_raw_response_complete(self, client: Lightfield) -> None:
        response = client.file.with_raw_response.complete(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = response.parse()
        assert_matches_type(FileCompleteResponse, file, path=["response"])

    @parametrize
    def test_streaming_response_complete(self, client: Lightfield) -> None:
        with client.file.with_streaming_response.complete(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = response.parse()
            assert_matches_type(FileCompleteResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_complete(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.file.with_raw_response.complete(
                id="",
            )

    @parametrize
    def test_method_url(self, client: Lightfield) -> None:
        file = client.file.url(
            "id",
        )
        assert_matches_type(FileURLResponse, file, path=["response"])

    @parametrize
    def test_raw_response_url(self, client: Lightfield) -> None:
        response = client.file.with_raw_response.url(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = response.parse()
        assert_matches_type(FileURLResponse, file, path=["response"])

    @parametrize
    def test_streaming_response_url(self, client: Lightfield) -> None:
        with client.file.with_streaming_response.url(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = response.parse()
            assert_matches_type(FileURLResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_url(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.file.with_raw_response.url(
                "",
            )


class TestAsyncFile:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.create(
            filename="x",
            mime_type="mimeType",
            size_bytes=1,
        )
        assert_matches_type(FileCreateResponse, file, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.create(
            filename="x",
            mime_type="mimeType",
            size_bytes=1,
            purpose="meeting_transcript",
        )
        assert_matches_type(FileCreateResponse, file, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLightfield) -> None:
        response = await async_client.file.with_raw_response.create(
            filename="x",
            mime_type="mimeType",
            size_bytes=1,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = await response.parse()
        assert_matches_type(FileCreateResponse, file, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLightfield) -> None:
        async with async_client.file.with_streaming_response.create(
            filename="x",
            mime_type="mimeType",
            size_bytes=1,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = await response.parse()
            assert_matches_type(FileCreateResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.retrieve(
            "id",
        )
        assert_matches_type(FileRetrieveResponse, file, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLightfield) -> None:
        response = await async_client.file.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = await response.parse()
        assert_matches_type(FileRetrieveResponse, file, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLightfield) -> None:
        async with async_client.file.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = await response.parse()
            assert_matches_type(FileRetrieveResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.file.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.list()
        assert_matches_type(FileListResponse, file, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(FileListResponse, file, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLightfield) -> None:
        response = await async_client.file.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = await response.parse()
        assert_matches_type(FileListResponse, file, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLightfield) -> None:
        async with async_client.file.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = await response.parse()
            assert_matches_type(FileListResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_cancel(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.cancel(
            id="id",
        )
        assert_matches_type(FileCancelResponse, file, path=["response"])

    @parametrize
    async def test_method_cancel_with_all_params(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.cancel(
            id="id",
            body={},
        )
        assert_matches_type(FileCancelResponse, file, path=["response"])

    @parametrize
    async def test_raw_response_cancel(self, async_client: AsyncLightfield) -> None:
        response = await async_client.file.with_raw_response.cancel(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = await response.parse()
        assert_matches_type(FileCancelResponse, file, path=["response"])

    @parametrize
    async def test_streaming_response_cancel(self, async_client: AsyncLightfield) -> None:
        async with async_client.file.with_streaming_response.cancel(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = await response.parse()
            assert_matches_type(FileCancelResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_cancel(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.file.with_raw_response.cancel(
                id="",
            )

    @parametrize
    async def test_method_complete(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.complete(
            id="id",
        )
        assert_matches_type(FileCompleteResponse, file, path=["response"])

    @parametrize
    async def test_method_complete_with_all_params(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.complete(
            id="id",
            md5="210b9798eb53baa4e69d31c1071cf03d",
        )
        assert_matches_type(FileCompleteResponse, file, path=["response"])

    @parametrize
    async def test_raw_response_complete(self, async_client: AsyncLightfield) -> None:
        response = await async_client.file.with_raw_response.complete(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = await response.parse()
        assert_matches_type(FileCompleteResponse, file, path=["response"])

    @parametrize
    async def test_streaming_response_complete(self, async_client: AsyncLightfield) -> None:
        async with async_client.file.with_streaming_response.complete(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = await response.parse()
            assert_matches_type(FileCompleteResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_complete(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.file.with_raw_response.complete(
                id="",
            )

    @parametrize
    async def test_method_url(self, async_client: AsyncLightfield) -> None:
        file = await async_client.file.url(
            "id",
        )
        assert_matches_type(FileURLResponse, file, path=["response"])

    @parametrize
    async def test_raw_response_url(self, async_client: AsyncLightfield) -> None:
        response = await async_client.file.with_raw_response.url(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file = await response.parse()
        assert_matches_type(FileURLResponse, file, path=["response"])

    @parametrize
    async def test_streaming_response_url(self, async_client: AsyncLightfield) -> None:
        async with async_client.file.with_streaming_response.url(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file = await response.parse()
            assert_matches_type(FileURLResponse, file, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_url(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.file.with_raw_response.url(
                "",
            )
