# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from lightfield import Lightfield, AsyncLightfield
from tests.utils import assert_matches_type
from lightfield.types import (
    MeetingListResponse,
    MeetingCreateResponse,
    MeetingUpdateResponse,
    MeetingRetrieveResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestMeeting:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Lightfield) -> None:
        meeting = client.meeting.create(
            fields={
                "end_date": "$endDate",
                "start_date": "$startDate",
                "title": "$title",
            },
        )
        assert_matches_type(MeetingCreateResponse, meeting, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Lightfield) -> None:
        meeting = client.meeting.create(
            fields={
                "end_date": "$endDate",
                "start_date": "$startDate",
                "title": "$title",
                "attendee_emails": ["string"],
                "description": "$description",
                "meeting_url": "$meetingUrl",
                "organizer_email": "$organizerEmail",
                "privacy_setting": "FULL",
            },
            auto_create_records=True,
            relationships={"transcript": "string"},
        )
        assert_matches_type(MeetingCreateResponse, meeting, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Lightfield) -> None:
        response = client.meeting.with_raw_response.create(
            fields={
                "end_date": "$endDate",
                "start_date": "$startDate",
                "title": "$title",
            },
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        meeting = response.parse()
        assert_matches_type(MeetingCreateResponse, meeting, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Lightfield) -> None:
        with client.meeting.with_streaming_response.create(
            fields={
                "end_date": "$endDate",
                "start_date": "$startDate",
                "title": "$title",
            },
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            meeting = response.parse()
            assert_matches_type(MeetingCreateResponse, meeting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: Lightfield) -> None:
        meeting = client.meeting.retrieve(
            "id",
        )
        assert_matches_type(MeetingRetrieveResponse, meeting, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Lightfield) -> None:
        response = client.meeting.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        meeting = response.parse()
        assert_matches_type(MeetingRetrieveResponse, meeting, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Lightfield) -> None:
        with client.meeting.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            meeting = response.parse()
            assert_matches_type(MeetingRetrieveResponse, meeting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.meeting.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_update(self, client: Lightfield) -> None:
        meeting = client.meeting.update(
            id="id",
        )
        assert_matches_type(MeetingUpdateResponse, meeting, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Lightfield) -> None:
        meeting = client.meeting.update(
            id="id",
            fields={"privacy_setting": "FULL"},
            relationships={"transcript": {"replace": "replace"}},
        )
        assert_matches_type(MeetingUpdateResponse, meeting, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Lightfield) -> None:
        response = client.meeting.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        meeting = response.parse()
        assert_matches_type(MeetingUpdateResponse, meeting, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Lightfield) -> None:
        with client.meeting.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            meeting = response.parse()
            assert_matches_type(MeetingUpdateResponse, meeting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.meeting.with_raw_response.update(
                id="",
            )

    @parametrize
    def test_method_list(self, client: Lightfield) -> None:
        meeting = client.meeting.list()
        assert_matches_type(MeetingListResponse, meeting, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Lightfield) -> None:
        meeting = client.meeting.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(MeetingListResponse, meeting, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Lightfield) -> None:
        response = client.meeting.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        meeting = response.parse()
        assert_matches_type(MeetingListResponse, meeting, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Lightfield) -> None:
        with client.meeting.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            meeting = response.parse()
            assert_matches_type(MeetingListResponse, meeting, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncMeeting:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncLightfield) -> None:
        meeting = await async_client.meeting.create(
            fields={
                "end_date": "$endDate",
                "start_date": "$startDate",
                "title": "$title",
            },
        )
        assert_matches_type(MeetingCreateResponse, meeting, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLightfield) -> None:
        meeting = await async_client.meeting.create(
            fields={
                "end_date": "$endDate",
                "start_date": "$startDate",
                "title": "$title",
                "attendee_emails": ["string"],
                "description": "$description",
                "meeting_url": "$meetingUrl",
                "organizer_email": "$organizerEmail",
                "privacy_setting": "FULL",
            },
            auto_create_records=True,
            relationships={"transcript": "string"},
        )
        assert_matches_type(MeetingCreateResponse, meeting, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLightfield) -> None:
        response = await async_client.meeting.with_raw_response.create(
            fields={
                "end_date": "$endDate",
                "start_date": "$startDate",
                "title": "$title",
            },
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        meeting = await response.parse()
        assert_matches_type(MeetingCreateResponse, meeting, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLightfield) -> None:
        async with async_client.meeting.with_streaming_response.create(
            fields={
                "end_date": "$endDate",
                "start_date": "$startDate",
                "title": "$title",
            },
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            meeting = await response.parse()
            assert_matches_type(MeetingCreateResponse, meeting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLightfield) -> None:
        meeting = await async_client.meeting.retrieve(
            "id",
        )
        assert_matches_type(MeetingRetrieveResponse, meeting, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLightfield) -> None:
        response = await async_client.meeting.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        meeting = await response.parse()
        assert_matches_type(MeetingRetrieveResponse, meeting, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLightfield) -> None:
        async with async_client.meeting.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            meeting = await response.parse()
            assert_matches_type(MeetingRetrieveResponse, meeting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.meeting.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncLightfield) -> None:
        meeting = await async_client.meeting.update(
            id="id",
        )
        assert_matches_type(MeetingUpdateResponse, meeting, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLightfield) -> None:
        meeting = await async_client.meeting.update(
            id="id",
            fields={"privacy_setting": "FULL"},
            relationships={"transcript": {"replace": "replace"}},
        )
        assert_matches_type(MeetingUpdateResponse, meeting, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLightfield) -> None:
        response = await async_client.meeting.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        meeting = await response.parse()
        assert_matches_type(MeetingUpdateResponse, meeting, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLightfield) -> None:
        async with async_client.meeting.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            meeting = await response.parse()
            assert_matches_type(MeetingUpdateResponse, meeting, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.meeting.with_raw_response.update(
                id="",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncLightfield) -> None:
        meeting = await async_client.meeting.list()
        assert_matches_type(MeetingListResponse, meeting, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLightfield) -> None:
        meeting = await async_client.meeting.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(MeetingListResponse, meeting, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLightfield) -> None:
        response = await async_client.meeting.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        meeting = await response.parse()
        assert_matches_type(MeetingListResponse, meeting, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLightfield) -> None:
        async with async_client.meeting.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            meeting = await response.parse()
            assert_matches_type(MeetingListResponse, meeting, path=["response"])

        assert cast(Any, response.is_closed) is True
