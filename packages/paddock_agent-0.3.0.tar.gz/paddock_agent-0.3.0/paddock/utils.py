"""Paddock utility functions — Git operations, path helpers, process management."""
from __future__ import annotations

import json
import os
import re
import shlex
import signal
import subprocess
from fnmatch import fnmatch
from pathlib import Path
from typing import Any

from .config import resolve_project_path


# ============================================================
# Process management
# ============================================================

def pid_alive(pid: int) -> bool:
    """Check if a process is still running."""
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def terminate_process(pid: int, timeout: int = 30) -> None:
    """Gracefully terminate a process: SIGTERM, then SIGKILL after timeout."""
    if not pid_alive(pid):
        return
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return

    import time
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not pid_alive(pid):
            return
        time.sleep(1)

    try:
        os.kill(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


# ============================================================
# Git operations
# ============================================================

def run_git(args: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess[str]:
    """Run a git command."""
    return subprocess.run(
        ["git"] + args, cwd=str(cwd), check=check,
        text=True, capture_output=True,
    )


def ensure_worktree(repo_root: Path, worktrees_root: Path,
                    objective_id: str, branch: str | None = None) -> tuple[str, Path]:
    """Ensure a git worktree exists for the given objective. Returns (branch, worktree_path)."""
    slug = objective_id.strip().replace("_", "-")
    if not branch:
        branch = f"wt/{slug}"
    worktree_path = (worktrees_root / slug).resolve()

    if worktree_path.exists():
        return branch, worktree_path

    worktree_path.parent.mkdir(parents=True, exist_ok=True)
    run_git(
        ["worktree", "add", "-b", branch, str(worktree_path)],
        cwd=repo_root, check=True,
    )
    return branch, worktree_path


def cleanup_worktree(repo_root: Path, worktree_path: str | Path) -> None:
    """Remove a git worktree."""
    wt = Path(worktree_path)
    if not wt.exists():
        return
    run_git(["worktree", "remove", "--force", str(wt)], cwd=repo_root, check=False)


def is_worktree_clean(cwd: Path) -> bool:
    """Check if a worktree has no uncommitted changes."""
    result = run_git(["status", "--short"], cwd=cwd, check=False)
    return not result.stdout.strip()


def branch_has_diff(repo_root: Path, branch: str) -> bool:
    """Check if branch has any diff against main."""
    result = run_git(["diff", "--name-only", f"main...{branch}"], cwd=repo_root, check=False)
    return bool(result.stdout.strip())


def get_branch_changed_files(repo_root: Path, branch: str) -> list[str]:
    """Get list of files changed in branch relative to main."""
    result = run_git(["diff", "--name-only", f"main...{branch}"], cwd=repo_root, check=False)
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def git_merge_no_ff(repo_root: Path, branch: str, message: str) -> dict[str, Any]:
    """Merge a branch into current branch (main) with --no-ff.

    On conflict, aborts immediately and returns failure with the list of
    conflicted files. The caller is responsible for escalating to needs_review.
    Auto-resolving conflicts (--theirs / --ours) is intentionally NOT done here
    because it silently introduces semantic errors into the codebase.
    """
    result = run_git(
        ["merge", "--no-ff", "--no-commit", branch],
        cwd=repo_root, check=False,
    )
    if result.returncode != 0:
        # Check for conflicts
        conflict_check = run_git(["diff", "--name-only", "--diff-filter=U"], cwd=repo_root, check=False)
        conflicted = [f.strip() for f in conflict_check.stdout.splitlines() if f.strip()]
        run_git(["merge", "--abort"], cwd=repo_root, check=False)
        err = f"Conflicts in: {conflicted}" if conflicted else result.stderr.strip()
        return {"success": False, "error": err, "conflicts": conflicted}

    # No conflicts — commit the merge
    commit_result = run_git(["commit", "-m", message], cwd=repo_root, check=False)
    if commit_result.returncode != 0:
        run_git(["merge", "--abort"], cwd=repo_root, check=False)
        return {"success": False, "error": commit_result.stderr.strip()}

    head = run_git(["rev-parse", "HEAD"], cwd=repo_root)
    return {"success": True, "commit_hash": head.stdout.strip()}


def get_commits_since_main(worktree_path: Path) -> list[dict[str, str]]:
    """Get commits in worktree branch that are not in main."""
    result = run_git(
        ["log", "main..HEAD", "--format=%H|%s", "--reverse"],
        cwd=worktree_path, check=False,
    )
    if result.returncode != 0 or not result.stdout.strip():
        return []

    commits = []
    for line in result.stdout.strip().splitlines():
        parts = line.split("|", 1)
        if len(parts) == 2:
            commit_hash, message = parts
            # Get files changed in this commit
            files_result = run_git(
                ["diff-tree", "--no-commit-id", "--name-only", "-r", commit_hash],
                cwd=worktree_path, check=False,
            )
            files = [f.strip() for f in files_result.stdout.splitlines() if f.strip()]
            commits.append({
                "hash": commit_hash.strip(),
                "message": message.strip(),
                "files": files,
            })
    return commits


def git_head(cwd: Path) -> str:
    """Get current HEAD commit hash."""
    result = run_git(["rev-parse", "HEAD"], cwd=cwd)
    return result.stdout.strip()


# ============================================================
# Path scope helpers
# ============================================================

def path_conflict(scope_a: list[str] | None, scope_b: list[str] | None) -> bool:
    """Check if two path scopes overlap."""
    if not scope_a or not scope_b:
        return False

    def roots(items: list[str]) -> list[str]:
        result: list[str] = []
        for item in items:
            cleaned = item.replace("**", "").replace("*", "").strip("/")
            if cleaned:
                result.append(cleaned)
        return result

    for left in roots(scope_a):
        for right in roots(scope_b):
            if left.startswith(right) or right.startswith(left):
                return True
    return False


def matches_scope(path: str, patterns: list[str]) -> bool:
    """Check if a file path matches any of the given glob patterns."""
    return any(fnmatch(path, p) for p in patterns)


def all_files_in_scope(files: list[str], scope: list[str]) -> bool:
    """Check if all files match at least one pattern in scope."""
    return all(matches_scope(f, scope) for f in files)


def matches_any_pattern(path: str, patterns: list[str]) -> bool:
    """Check if a file path matches any pattern (for integrator_only checks)."""
    return any(fnmatch(path, p) for p in patterns)


# ============================================================
# Agent command helpers
# ============================================================

def render_agent_command(command_template: str, prompt_file: str,
                         worktree: str | None = None) -> list[str] | str:
    """Render an agent command template with variable substitution.

    If the template contains shell special chars (pipes, $(...), etc.),
    returns a raw string for use with shell=True.
    Otherwise returns a shlex-split list.
    """
    cmd = command_template
    cmd = cmd.replace("{prompt_file}", prompt_file)
    cmd = cmd.replace("{prompt}", prompt_file)
    if worktree:
        cmd = cmd.replace("{worktree}", worktree)
    # Detect shell syntax: pipes, subshell, redirects, $( )
    if any(c in cmd for c in ("|", "$(", "&&", "||", ">", "<")):
        return cmd  # caller must use shell=True
    return shlex.split(cmd)


# ============================================================
# Session summary parsing
# ============================================================

SESSION_SUMMARY_START = "---SESSION_SUMMARY---"
SESSION_SUMMARY_END = "---END_SESSION_SUMMARY---"


def parse_session_summary(log_file: str | Path) -> dict[str, Any] | None:
    """Extract SESSION_SUMMARY block from agent log output."""
    path = Path(log_file)
    if not path.exists():
        return None

    content = path.read_text(encoding="utf-8", errors="replace")
    start = content.rfind(SESSION_SUMMARY_START)
    end = content.rfind(SESSION_SUMMARY_END)

    if start == -1 or end == -1 or end <= start:
        return None

    summary_text = content[start + len(SESSION_SUMMARY_START):end].strip()

    # Parse simple YAML-like key: value pairs
    result: dict[str, Any] = {}
    current_key = None
    current_value_lines: list[str] = []

    for line in summary_text.splitlines():
        # Check for top-level key
        match = re.match(r'^(\w+):\s*(.*)', line)
        if match and not line.startswith("  "):
            if current_key:
                result[current_key] = _finalize_value(current_value_lines)
            current_key = match.group(1)
            current_value_lines = [match.group(2)] if match.group(2) else []
        elif current_key:
            current_value_lines.append(line)

    if current_key:
        result[current_key] = _finalize_value(current_value_lines)

    return result


def _finalize_value(lines: list[str]) -> Any:
    """Convert collected lines into a value."""
    text = "\n".join(lines).strip()
    if not text:
        return ""
    if text.lower() in ("true", "false"):
        return text.lower() == "true"
    try:
        return int(text)
    except ValueError:
        pass
    # Check if it looks like a list
    if text.startswith("- "):
        items = []
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("- "):
                items.append(line[2:].strip())
        return items
    return text
