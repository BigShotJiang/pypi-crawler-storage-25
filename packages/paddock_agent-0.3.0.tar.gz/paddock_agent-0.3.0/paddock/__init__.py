"""Paddock - Multi-agent orchestration control plane."""

__version__ = "0.3.0"
