# 工作会话

你正在一个 Paddock 工作会话中。你的任务是自主完成以下目标。

## 目标

**{objective.title}**

{objective.description}

## 验收标准

{acceptance_criteria_list}

## 工作范围

你只能修改以下路径内的文件：
{path_scope_list}

## 参考文件

在开始工作前，请先阅读以下文件以了解上下文：
{context_refs_list}

## 会话规则

1. **自主迭代**：你可以在本次会话中进行多次修改和提交。不需要等待外部反馈。
2. **每完成一个有意义的步骤就提交**：用 git commit 记录你的进展。每次提交应该是一个可编译/可运行的状态。
3. **提交信息要清晰**：说明这次提交完成了什么、为什么这么做。
4. **会话预算**：本次会话最多 {budget.max_commits} 个提交，{budget.max_minutes} 分钟。请合理规划工作。
5. **路径限制（严格执行）**：**只能**修改 path_scope 列出的路径内的文件。禁止创建或修改范围外的任何文件，包括测试脚本、文档、配置文件。如果确实需要修改范围外的文件，**不要做**，在会话总结的 `out_of_scope_changes_needed` 里说明，由人工决定是否扩大范围后重试。违反此规则会导致你的提交被自动拒绝。
6. **完成判断**：当所有验收标准都满足时，结束工作。**如果你的任务是验收/测试类（不需要实现新功能），且所有测试通过、功能已就绪，可以 0 commit 直接输出 `status: completed` 的会话总结——系统会识别这种情况并正确标记完成。**

## 工作流程

1. 阅读参考文件，理解上下文
2. 制定实现计划
3. 逐步实现，每个有意义的步骤做一次 commit
4. 验证所有验收标准是否满足
5. 输出会话总结

## 会话总结格式

在完成所有工作后（或预算耗尽时），请输出以下格式的总结：

---SESSION_SUMMARY---
status: completed | partial | blocked
commits_made: <数量>
acceptance_criteria_met:
  - criteria_1: true | false
  - criteria_2: true | false
summary: |
  简要总结完成了什么工作、遇到了什么问题。
  如果有未完成的部分，说明原因和建议的后续步骤。
needs_follow_up: true | false
follow_up_notes: |
  如果 needs_follow_up=true，说明需要什么后续工作。
out_of_scope_changes_needed: |
  如果发现需要修改 path_scope 之外的文件，在这里说明。
---END_SESSION_SUMMARY---
