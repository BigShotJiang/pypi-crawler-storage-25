"""Paddock configuration management."""
from __future__ import annotations

import importlib.resources
import os
from pathlib import Path


def _detect_workspace() -> Path:
    """Detect the Paddock workspace directory (runtime state lives here).

    Resolution order:
    1. PADDOCK_ROOT env var  — explicit override
    2. Current working directory — standard 'paddock init' workspace
    """
    env = os.environ.get("PADDOCK_ROOT")
    if env:
        return Path(env).resolve()
    return Path.cwd()


def _detect_package_root() -> Path:
    """Detect the installed package root (source tree or site-packages).

    Used only for scripts/ resolution when running from source.
    Not needed after CLI migration is complete.
    """
    return Path(__file__).resolve().parent.parent


def _get_templates_dir() -> Path:
    """Locate the templates directory.

    - When installed via pip: use importlib.resources to find package data
    - When running from source tree: fall back to repo templates/
    """
    try:
        # Python 3.9+: importlib.resources.files
        ref = importlib.resources.files("paddock") / "templates"
        # Materialise to a real path (works for both zip and directory installs)
        with importlib.resources.as_file(ref) as p:
            if p.exists():
                return p
    except (TypeError, FileNotFoundError):
        pass
    # Fallback: source tree layout  paddock/config.py → repo root → templates/
    src_templates = _detect_package_root() / "templates"
    if src_templates.exists():
        return src_templates
    raise FileNotFoundError(
        "Cannot locate Paddock templates directory. "
        "Set PADDOCK_ROOT or reinstall the package."
    )


# ---------------------------------------------------------------------------
# Public path constants
# ---------------------------------------------------------------------------

# Workspace root — where runtime/, projects/ live (set by user / paddock init)
PADDOCK_ROOT = _detect_workspace()

# Package root — only used for scripts/ lookup when running from source
_PACKAGE_ROOT = _detect_package_root()

DB_PATH = PADDOCK_ROOT / os.environ.get("PADDOCK_DB", "runtime/paddock.db")
TEMPLATES_DIR = _get_templates_dir()
RUNTIME_DIR = PADDOCK_ROOT / "runtime"
PROJECTS_DIR = PADDOCK_ROOT / "projects"
SCRIPTS_DIR = _PACKAGE_ROOT / "scripts"

# Supervisor defaults
DEFAULT_POLL_SECONDS = int(os.environ.get("PADDOCK_POLL_SECONDS", "20"))
DEFAULT_PLANNER_COOLDOWN = int(os.environ.get("PADDOCK_PLANNER_COOLDOWN", "300"))
DEFAULT_DURATION_MINUTES = 60
DEFAULT_MAX_PARALLEL = 2

# Logging
LOG_LEVEL = os.environ.get("PADDOCK_LOG_LEVEL", "INFO")

# Proxy env for agent CLI calls.
# Set PADDOCK_PROXY to enable a proxy for all agent subprocesses, e.g.:
#   export PADDOCK_PROXY=http://127.0.0.1:7897
# Leave unset (default) to pass through the current environment's proxy settings.
_proxy_url = os.environ.get("PADDOCK_PROXY", "")
DEFAULT_PROXY_ENV: dict[str, str] = (
    {
        "HTTP_PROXY": _proxy_url,
        "HTTPS_PROXY": _proxy_url,
        "ALL_PROXY": _proxy_url,
        "NO_PROXY": os.environ.get("PADDOCK_NO_PROXY", "localhost,127.0.0.1,::1"),
        "NODE_OPTIONS": "--use-env-proxy",
    }
    if _proxy_url
    else {}
)


def resolve_project_path(relative_path: str) -> Path:
    """Resolve a path relative to PADDOCK_ROOT."""
    p = Path(relative_path)
    if p.is_absolute():
        return p
    return (PADDOCK_ROOT / p).resolve()


def ensure_runtime_dirs(project_id: str | None = None) -> None:
    """Ensure runtime directories exist."""
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    if project_id:
        logs_dir = RUNTIME_DIR / "projects" / project_id / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)


def build_agent_env(agent: dict | None = None) -> dict[str, str]:
    """Build environment dict for agent subprocess calls.

    If agent has an 'env' JSON field, those values override the defaults.
    Agents that don't need proxy (mc, kimi) should set proxy vars to empty string.
    """
    import json as _json
    env = os.environ.copy()

    # Apply default proxy (only as fallback)
    for key, value in DEFAULT_PROXY_ENV.items():
        env.setdefault(key, value)
        env.setdefault(key.lower(), value)

    # Apply agent-specific env overrides (can clear proxy by setting empty string)
    if agent and agent.get("env"):
        try:
            raw = agent["env"]
            # Handle double-encoded JSON
            while isinstance(raw, str):
                raw = _json.loads(raw)
            agent_env = raw if isinstance(raw, dict) else {}
            for key, value in agent_env.items():
                if value == "":
                    env.pop(key, None)
                    env.pop(key.lower(), None)
                else:
                    env[key] = value
        except (ValueError, TypeError):
            pass

    # Remove vars that interfere with claude CLI's own auth/routing
    for key in ("ANTHROPIC_BASE_URL", "ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_CUSTOM_HEADERS"):
        env.pop(key, None)
    return env
