"""Paddock CLI — unified command-line interface."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

import typer
from typing_extensions import Annotated

app = typer.Typer(
    name="paddock",
    help="Multi-agent engineering orchestration framework.",
    no_args_is_help=True,
)

project_app = typer.Typer(help="Manage projects.", no_args_is_help=True)
supervisor_app = typer.Typer(help="Control the supervisor loop.", no_args_is_help=True)
admin_app = typer.Typer(help="Admin dashboard.", no_args_is_help=True)

app.add_typer(project_app, name="project")
app.add_typer(supervisor_app, name="supervisor")
app.add_typer(admin_app, name="admin")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _workspace_root() -> Path:
    """Return current workspace root (cwd, or PADDOCK_ROOT env var)."""
    env = os.environ.get("PADDOCK_ROOT")
    return Path(env).resolve() if env else Path.cwd()


def _require_workspace() -> Path:
    """Abort with a helpful message if not inside an initialised workspace."""
    root = _workspace_root()
    if not (root / "projects").exists():
        typer.echo(
            f"[error] No Paddock workspace found in {root}\n"
            "Run 'paddock init' first.",
            err=True,
        )
        raise typer.Exit(1)
    return root


def _scripts_dir() -> Path:
    """Locate the scripts/ directory (works for both pip install and source tree)."""
    # Installed: paddock/cli.py lives in site-packages/paddock/, scripts/ is sibling
    candidate = Path(__file__).resolve().parent.parent / "scripts"
    if candidate.exists():
        return candidate
    typer.echo("[error] Cannot locate Paddock scripts/ directory.", err=True)
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# paddock init
# ---------------------------------------------------------------------------

@app.command()
def init(
    directory: Annotated[Optional[Path], typer.Argument(help="Workspace directory (default: current directory)")] = None,
):
    """Initialise a new Paddock workspace."""
    root = Path(directory).resolve() if directory else Path.cwd()
    root.mkdir(parents=True, exist_ok=True)

    created = []

    # projects/
    projects_dir = root / "projects"
    projects_dir.mkdir(exist_ok=True)
    example = projects_dir / "example.yaml"
    if not example.exists():
        # Copy from package data
        pkg_example = Path(__file__).parent.parent / "projects" / "example.yaml"
        if pkg_example.exists():
            shutil.copy(pkg_example, example)
        else:
            example.write_text(
                "# Paddock project config — copy and rename this file\n"
                "slug: my-project\n"
                "name: My Project\n"
                "repo_root: ../my-project\n"
                "worktrees_root: ../my-project-wt\n"
            )
        created.append("projects/example.yaml")

    # runtime/
    runtime_dir = root / "runtime" / "projects"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    created.append("runtime/")

    # .env
    env_file = root / ".env"
    if not env_file.exists():
        env_file.write_text(
            "# Paddock workspace configuration\n"
            "# PADDOCK_ROOT is set automatically when you run paddock from this directory\n\n"
            "# Database path (default: runtime/paddock.db)\n"
            "# PADDOCK_DB=runtime/paddock.db\n\n"
            "# Proxy for agent CLI calls (optional)\n"
            "# PADDOCK_PROXY=http://127.0.0.1:7897\n"
        )
        created.append(".env")

    # Initialise database
    scripts = _scripts_dir()
    result = subprocess.run(
        [sys.executable, str(scripts / "init_db.py")],
        cwd=str(root),
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        typer.echo(f"[warn] Database init failed: {result.stderr.strip()}", err=True)
    else:
        created.append("runtime/paddock.db")

    typer.echo(f"✓ Paddock workspace initialised at {root}")
    for item in created:
        typer.echo(f"  created: {item}")
    typer.echo("\nNext steps:")
    typer.echo("  paddock project add <path-to-your-repo>")
    typer.echo("  paddock supervisor start")


# ---------------------------------------------------------------------------
# paddock project
# ---------------------------------------------------------------------------

@project_app.command("add")
def project_add(
    repo_path: Annotated[Path, typer.Argument(help="Path to the git repository to manage")],
    slug: Annotated[Optional[str], typer.Option(help="Project slug (default: directory name)")] = None,
    name: Annotated[Optional[str], typer.Option(help="Human-readable project name")] = None,
):
    """Register a project with Paddock."""
    root = _require_workspace()
    repo = Path(repo_path).resolve()

    if not repo.exists():
        typer.echo(f"[error] Path does not exist: {repo}", err=True)
        raise typer.Exit(1)
    if not (repo / ".git").exists():
        typer.echo(f"[error] Not a git repository: {repo}", err=True)
        raise typer.Exit(1)

    project_slug = slug or repo.name
    project_name = name or project_slug
    worktrees = repo.parent / f"{repo.name}-wt"

    config_path = root / "projects" / f"{project_slug}.yaml"
    if config_path.exists():
        typer.echo(f"[error] Project '{project_slug}' already exists: {config_path}", err=True)
        raise typer.Exit(1)

    # Write relative paths when possible
    try:
        rel_repo = os.path.relpath(repo, root)
        rel_wt = os.path.relpath(worktrees, root)
    except ValueError:
        # On Windows, relpath can fail across drives
        rel_repo = str(repo)
        rel_wt = str(worktrees)

    config_path.write_text(
        f"slug: {project_slug}\n"
        f"name: {project_name}\n"
        f"repo_root: {rel_repo}\n"
        f"worktrees_root: {rel_wt}\n"
    )

    # Register in database
    scripts = _scripts_dir()
    result = subprocess.run(
        [sys.executable, str(scripts / "init_db.py"), "--seed-project", str(config_path)],
        cwd=str(root),
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        typer.echo(f"[warn] Could not register in database: {result.stderr.strip()}", err=True)

    typer.echo(f"✓ Project '{project_slug}' registered")
    typer.echo(f"  config:    {config_path}")
    typer.echo(f"  repo:      {rel_repo}")
    typer.echo(f"  worktrees: {rel_wt}")
    typer.echo(f"\nEdit {config_path} to customise integrator_only_patterns and other settings.")


@project_app.command("list")
def project_list():
    """List all registered projects."""
    root = _require_workspace()
    configs = sorted((root / "projects").glob("*.yaml"))
    configs = [c for c in configs if c.name != "example.yaml"]

    if not configs:
        typer.echo("No projects registered. Run 'paddock project add <path>'.")
        return

    import yaml  # already a dependency
    for config_path in configs:
        try:
            cfg = yaml.safe_load(config_path.read_text())
            slug = cfg.get("slug", config_path.stem)
            name = cfg.get("name", slug)
            repo = cfg.get("repo_root", "?")
            typer.echo(f"  {slug:20s}  {name:30s}  {repo}")
        except Exception:
            typer.echo(f"  {config_path.stem}  (could not parse config)")


# ---------------------------------------------------------------------------
# paddock supervisor
# ---------------------------------------------------------------------------

@supervisor_app.command("start")
def supervisor_start(
    project: Annotated[Optional[str], typer.Option("--project", "-p", help="Only process this project")] = None,
    poll: Annotated[int, typer.Option(help="Poll interval in seconds")] = 20,
    duration: Annotated[int, typer.Option(help="Max run duration in minutes")] = 60,
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
    once: Annotated[bool, typer.Option("--once", help="Run one iteration then exit")] = False,
):
    """Start the supervisor loop."""
    root = _require_workspace()
    scripts = _scripts_dir()

    cmd = [
        sys.executable, str(scripts / "supervisor_v2.py"),
        f"--poll-seconds={poll}",
        f"--duration-minutes={duration}",
    ]
    if project:
        cmd += [f"--project={project}"]
    if dry_run:
        cmd.append("--dry-run")
    if once:
        cmd.append("--once")

    typer.echo(f"Starting supervisor (poll={poll}s, duration={duration}m)...")
    try:
        subprocess.run(cmd, cwd=str(root), check=True)
    except KeyboardInterrupt:
        typer.echo("\nSupervisor stopped.")
    except subprocess.CalledProcessError as e:
        raise typer.Exit(e.returncode)


@supervisor_app.command("status")
def supervisor_status():
    """Show active sessions and project status."""
    root = _require_workspace()

    try:
        sys.path.insert(0, str(_scripts_dir().parent))
        from paddock.db import PaddockDB
        db = PaddockDB()
        projects = db.list_active_projects()

        if not projects:
            typer.echo("No active projects.")
            return

        for p in projects:
            sessions = db.get_active_sessions(p["id"])
            objectives = db.list_objectives(p["id"])
            ready = [o for o in objectives if o["status"] == "ready"]
            in_progress = [o for o in objectives if o["status"] == "in_progress"]
            typer.echo(f"\n{p['name']} ({p['id']})")
            typer.echo(f"  active sessions : {len(sessions)}")
            typer.echo(f"  ready objectives: {len(ready)}")
            typer.echo(f"  in progress     : {len(in_progress)}")
    except Exception as e:
        typer.echo(f"[error] {e}", err=True)
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# paddock planner
# ---------------------------------------------------------------------------

@app.command()
def planner(
    project: Annotated[str, typer.Option("--project", "-p", help="Project slug")],
    dry_run: Annotated[bool, typer.Option("--dry-run")] = False,
):
    """Run the planner for a project (generates Objectives from Goals)."""
    root = _require_workspace()
    scripts = _scripts_dir()

    cmd = [sys.executable, str(scripts / "planner.py"), f"--project={project}"]
    if dry_run:
        cmd.append("--dry-run")

    try:
        subprocess.run(cmd, cwd=str(root), check=True)
    except subprocess.CalledProcessError as e:
        raise typer.Exit(e.returncode)


# ---------------------------------------------------------------------------
# paddock admin
# ---------------------------------------------------------------------------

@admin_app.command("start")
def admin_start(
    host: Annotated[str, typer.Option(help="Bind host")] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="Bind port")] = 8100,
):
    """Start the admin dashboard (requires paddock-agent[admin])."""
    try:
        import uvicorn
    except ImportError:
        typer.echo(
            "[error] Admin dependencies not installed.\n"
            "Run: pip install 'paddock-agent[admin]'",
            err=True,
        )
        raise typer.Exit(1)

    root = _require_workspace()

    typer.echo(f"Starting Paddock Admin at http://{host}:{port}")
    typer.echo("Press Ctrl+C to stop.")

    import os
    os.environ.setdefault("PADDOCK_ROOT", str(root))

    from paddock.admin.server import create_app
    uvicorn.run(create_app(), host=host, port=port)


@admin_app.command("stop")
def admin_stop():
    """Stop the admin dashboard (if running in background)."""
    root = _require_workspace()
    pid_file = root / "runtime" / "admin.pid"
    if not pid_file.exists():
        typer.echo("Admin dashboard is not running.")
        return
    import signal as _signal
    pid = int(pid_file.read_text().strip())
    try:
        os.kill(pid, _signal.SIGTERM)
        pid_file.unlink()
        typer.echo(f"Stopped admin dashboard (pid={pid})")
    except ProcessLookupError:
        pid_file.unlink(missing_ok=True)
        typer.echo("Admin dashboard was not running.")


# ---------------------------------------------------------------------------
# paddock version
# ---------------------------------------------------------------------------

@app.command()
def version():
    """Show Paddock version."""
    from paddock import __version__
    typer.echo(f"Paddock {__version__}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    app()


if __name__ == "__main__":
    main()
