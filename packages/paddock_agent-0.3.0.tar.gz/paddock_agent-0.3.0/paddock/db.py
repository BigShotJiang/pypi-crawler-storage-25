"""
Paddock SQLite data layer.

Single source of truth for all Paddock state.
Used by both scripts/ (supervisor, planner, dispatch) and admin/ (API).
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Generator

from .config import DB_PATH

SCHEMA_VERSION = 1


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _json_dumps(obj: Any) -> str | None:
    if obj is None:
        return None
    return json.dumps(obj, ensure_ascii=False)


def _json_loads(s: str | None) -> Any:
    if not s:
        return None
    return json.loads(s)


# ============================================================
# Schema
# ============================================================

SCHEMA_SQL = """
-- Projects
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    repo_root TEXT NOT NULL,
    worktrees_root TEXT NOT NULL,
    integrator_only_patterns TEXT,  -- JSON array
    max_parallel_sessions INTEGER DEFAULT 2,
    session_defaults TEXT,          -- JSON: {scope_level, max_commits_per_session, max_minutes_per_session}
    enabled INTEGER DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Agents (actual CLI tools)
CREATE TABLE IF NOT EXISTS agents (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    cli_command TEXT NOT NULL,
    command_template TEXT NOT NULL,
    description TEXT,
    supported_features TEXT,  -- JSON array
    enabled INTEGER DEFAULT 1,
    icon TEXT DEFAULT '🤖',
    color TEXT DEFAULT '#666',
    env TEXT,                 -- JSON
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Workers (logical roles)
CREATE TABLE IF NOT EXISTS workers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    role_type TEXT NOT NULL DEFAULT 'implementer',
    icon TEXT DEFAULT '👤',
    color TEXT DEFAULT '#3b82f6',
    strategy_mode TEXT DEFAULT 'fixed',
    strategy_fixed_agent TEXT,
    strategy_agent_priority TEXT,  -- JSON list
    strategy_content_rules TEXT,   -- JSON
    prompt_template TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Goals
CREATE TABLE IF NOT EXISTS goals (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id),
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'active',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Milestones
CREATE TABLE IF NOT EXISTS milestones (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id),
    goal_id TEXT NOT NULL REFERENCES goals(id),
    title TEXT NOT NULL,
    description TEXT,
    success_criteria TEXT,  -- JSON array
    status TEXT DEFAULT 'active',
    sort_order INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Phases
CREATE TABLE IF NOT EXISTS phases (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id),
    milestone_id TEXT NOT NULL REFERENCES milestones(id),
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'active',
    sort_order INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Objectives (the dispatchable work unit, replaces V1 tasks)
CREATE TABLE IF NOT EXISTS objectives (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id),
    phase_id TEXT REFERENCES phases(id),
    worker_id TEXT REFERENCES workers(id),
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    acceptance_criteria TEXT NOT NULL,  -- JSON array
    path_scope TEXT,                    -- JSON array
    depends_on TEXT,                    -- JSON array of objective ids
    context_refs TEXT,                  -- JSON array of file paths
    status TEXT DEFAULT 'todo',         -- todo | ready | active | done | failed | paused
    priority INTEGER DEFAULT 0,
    session_budget TEXT,                -- JSON: {max_commits, max_minutes}
    outcome_summary TEXT,
    branch TEXT,
    worktree TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- Sessions (agent work sessions, replaces V1 runs)
CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    objective_id TEXT NOT NULL REFERENCES objectives(id),
    project_id TEXT NOT NULL REFERENCES projects(id),
    agent_id TEXT REFERENCES agents(id),
    status TEXT DEFAULT 'running',  -- running | completed | failed | timeout | cancelled
    pid INTEGER,
    budget TEXT NOT NULL,           -- JSON: {max_commits, max_minutes}
    prompt TEXT,
    log_file TEXT,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    outcome TEXT,
    error_message TEXT,
    checkpoint_count INTEGER DEFAULT 0
);

-- Checkpoints (commits within a session)
CREATE TABLE IF NOT EXISTS checkpoints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL REFERENCES sessions(id),
    objective_id TEXT NOT NULL REFERENCES objectives(id),
    commit_hash TEXT NOT NULL,
    commit_message TEXT,
    files_changed TEXT,              -- JSON array
    review_status TEXT DEFAULT 'pending',  -- pending | approved | rejected
    review_note TEXT,
    created_at TEXT NOT NULL
);

-- Events
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id TEXT,
    type TEXT NOT NULL,
    payload TEXT,  -- JSON
    created_at TEXT NOT NULL
);

-- Planner runs
CREATE TABLE IF NOT EXISTS planner_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id TEXT NOT NULL REFERENCES projects(id),
    status TEXT DEFAULT 'running',  -- running | completed | failed
    pid INTEGER,
    objective TEXT,
    plan_output TEXT,
    log_file TEXT,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    applied_at TEXT,
    error_message TEXT
);

-- Loop stages (kept for admin UI compatibility)
CREATE TABLE IF NOT EXISTS loop_stages (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    worker_id TEXT NOT NULL,
    enabled INTEGER DEFAULT 1,
    auto_trigger INTEGER DEFAULT 0,
    config TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at TEXT,
    updated_at TEXT,
    FOREIGN KEY (worker_id) REFERENCES workers(id)
);

-- Loop settings (kept for admin UI compatibility)
CREATE TABLE IF NOT EXISTS loop_settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

-- Health logs (kept for admin UI compatibility)
CREATE TABLE IF NOT EXISTS health_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    agent_name TEXT,
    status TEXT,
    command TEXT,
    stdout TEXT,
    stderr TEXT,
    exit_code INTEGER,
    latency_ms REAL,
    error TEXT,
    timestamp TEXT,
    FOREIGN KEY (agent_id) REFERENCES agents(id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_objectives_project_status ON objectives(project_id, status);
CREATE INDEX IF NOT EXISTS idx_objectives_phase ON objectives(phase_id);
CREATE INDEX IF NOT EXISTS idx_sessions_project_status ON sessions(project_id, status);
CREATE INDEX IF NOT EXISTS idx_sessions_objective ON sessions(objective_id);
CREATE INDEX IF NOT EXISTS idx_checkpoints_session ON checkpoints(session_id);
CREATE INDEX IF NOT EXISTS idx_events_project_type ON events(project_id, type);
CREATE INDEX IF NOT EXISTS idx_events_created ON events(created_at);
CREATE INDEX IF NOT EXISTS idx_planner_runs_project ON planner_runs(project_id);
CREATE INDEX IF NOT EXISTS idx_health_logs_agent ON health_logs(agent_id);
CREATE INDEX IF NOT EXISTS idx_health_logs_time ON health_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_loop_stages_order ON loop_stages(sort_order);
CREATE INDEX IF NOT EXISTS idx_goals_project ON goals(project_id);
CREATE INDEX IF NOT EXISTS idx_milestones_project ON milestones(project_id);
CREATE INDEX IF NOT EXISTS idx_phases_project ON phases(project_id);
"""


# ============================================================
# Connection management
# ============================================================

class PaddockDB:
    """Central database access for all Paddock operations."""

    def __init__(self, db_path: str | Path | None = None):
        self._db_path = Path(db_path) if db_path else DB_PATH

    def initialize(self) -> None:
        """Create tables and enable WAL mode."""
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.executescript(SCHEMA_SQL)
            conn.commit()

    @contextmanager
    def _connect(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(str(self._db_path), timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
        finally:
            conn.close()

    def _dict(self, row: sqlite3.Row | None) -> dict[str, Any] | None:
        if row is None:
            return None
        return dict(row)

    def _dicts(self, rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
        return [dict(r) for r in rows]

    # ============================================================
    # Projects
    # ============================================================

    def upsert_project(self, p: dict[str, Any]) -> None:
        now = _now()
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO projects (id, name, repo_root, worktrees_root,
                    integrator_only_patterns, max_parallel_sessions, session_defaults,
                    enabled, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, repo_root=excluded.repo_root,
                    worktrees_root=excluded.worktrees_root,
                    integrator_only_patterns=excluded.integrator_only_patterns,
                    max_parallel_sessions=excluded.max_parallel_sessions,
                    session_defaults=excluded.session_defaults,
                    enabled=excluded.enabled, updated_at=excluded.updated_at
            """, (
                p["id"], p["name"], p["repo_root"], p["worktrees_root"],
                _json_dumps(_json_loads(p.get("integrator_only_patterns")) if isinstance(p.get("integrator_only_patterns"), str) else p.get("integrator_only_patterns")),
                p.get("max_parallel_sessions", 2),
                _json_dumps(_json_loads(p.get("session_defaults")) if isinstance(p.get("session_defaults"), str) else p.get("session_defaults")),
                1 if p.get("enabled", True) else 0,
                now, now,
            ))
            conn.commit()

    def get_project(self, project_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
            return self._dict(row)

    def list_active_projects(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM projects WHERE enabled=1 ORDER BY id").fetchall()
            return self._dicts(rows)

    def list_all_projects(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM projects ORDER BY id").fetchall()
            return self._dicts(rows)

    def delete_project(self, project_id: str) -> bool:
        with self._connect() as conn:
            # Cascade delete related data
            conn.execute("DELETE FROM events WHERE project_id=?", (project_id,))
            conn.execute("DELETE FROM planner_runs WHERE project_id=?", (project_id,))
            # Delete sessions and checkpoints
            session_ids = [r[0] for r in conn.execute(
                "SELECT id FROM sessions WHERE project_id=?", (project_id,)
            ).fetchall()]
            for sid in session_ids:
                conn.execute("DELETE FROM checkpoints WHERE session_id=?", (sid,))
            conn.execute("DELETE FROM sessions WHERE project_id=?", (project_id,))
            conn.execute("DELETE FROM objectives WHERE project_id=?", (project_id,))
            # Delete goals hierarchy
            conn.execute("DELETE FROM phases WHERE project_id=?", (project_id,))
            conn.execute("DELETE FROM milestones WHERE project_id=?", (project_id,))
            conn.execute("DELETE FROM goals WHERE project_id=?", (project_id,))
            cur = conn.execute("DELETE FROM projects WHERE id=?", (project_id,))
            conn.commit()
            return cur.rowcount > 0

    # ============================================================
    # Agents
    # ============================================================

    def upsert_agent(self, a: dict[str, Any]) -> None:
        now = _now()
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO agents (id, name, cli_command, command_template, description,
                    supported_features, enabled, icon, color, env, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, cli_command=excluded.cli_command,
                    command_template=excluded.command_template,
                    description=excluded.description,
                    supported_features=excluded.supported_features,
                    enabled=excluded.enabled, icon=excluded.icon, color=excluded.color,
                    env=excluded.env, updated_at=excluded.updated_at
            """, (
                a["id"], a["name"], a["cli_command"], a["command_template"],
                a.get("description", ""),
                _json_dumps(a.get("supported_features")),
                1 if a.get("enabled", True) else 0,
                a.get("icon", "🤖"), a.get("color", "#666"),
                _json_dumps(a.get("env")),
                now, now,
            ))
            conn.commit()

    def get_agent(self, agent_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
            return self._dict(row)

    def list_agents(self, enabled_only: bool = False) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if enabled_only:
                rows = conn.execute("SELECT * FROM agents WHERE enabled=1 ORDER BY id").fetchall()
            else:
                rows = conn.execute("SELECT * FROM agents ORDER BY id").fetchall()
            return self._dicts(rows)

    def delete_agent(self, agent_id: str) -> bool:
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM agents WHERE id=?", (agent_id,))
            conn.commit()
            return cur.rowcount > 0

    # ============================================================
    # Workers
    # ============================================================

    def upsert_worker(self, w: dict[str, Any]) -> None:
        now = _now()
        strategy = w.get("strategy", {})
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO workers (id, name, description, role_type, icon, color,
                    strategy_mode, strategy_fixed_agent, strategy_agent_priority,
                    strategy_content_rules, prompt_template, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, description=excluded.description,
                    role_type=excluded.role_type, icon=excluded.icon, color=excluded.color,
                    strategy_mode=excluded.strategy_mode,
                    strategy_fixed_agent=excluded.strategy_fixed_agent,
                    strategy_agent_priority=excluded.strategy_agent_priority,
                    strategy_content_rules=excluded.strategy_content_rules,
                    prompt_template=excluded.prompt_template,
                    updated_at=excluded.updated_at
            """, (
                w["id"], w["name"], w.get("description", ""),
                w.get("role_type", "implementer"),
                w.get("icon", "👤"), w.get("color", "#3b82f6"),
                strategy.get("mode", w.get("strategy_mode", "fixed")),
                strategy.get("fixed_agent", w.get("strategy_fixed_agent", "")),
                _json_dumps(strategy.get("agent_priority", _json_loads(w.get("strategy_agent_priority")))),
                _json_dumps(strategy.get("content_rules", _json_loads(w.get("strategy_content_rules")))),
                w.get("prompt_template"),
                now, now,
            ))
            conn.commit()

    def get_worker(self, worker_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM workers WHERE id=?", (worker_id,)).fetchone()
            return self._dict(row)

    def list_workers(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM workers ORDER BY id").fetchall()
            return self._dicts(rows)

    def delete_worker(self, worker_id: str) -> bool:
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM workers WHERE id=?", (worker_id,))
            conn.commit()
            return cur.rowcount > 0

    # ============================================================
    # Goals / Milestones / Phases
    # ============================================================

    def upsert_goal(self, g: dict[str, Any]) -> None:
        now = _now()
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO goals (id, project_id, title, description, status, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    title=excluded.title, description=excluded.description,
                    status=excluded.status, updated_at=excluded.updated_at
            """, (
                g["id"], g["project_id"], g["title"],
                g.get("description", ""), g.get("status", "active"), now, now,
            ))
            conn.commit()

    def get_active_goal(self, project_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM goals WHERE project_id=? AND status='active' ORDER BY created_at DESC LIMIT 1",
                (project_id,)
            ).fetchone()
            return self._dict(row)

    def list_goals(self, project_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM goals WHERE project_id=? ORDER BY created_at", (project_id,)).fetchall()
            return self._dicts(rows)

    def upsert_milestone(self, m: dict[str, Any]) -> None:
        now = _now()
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO milestones (id, project_id, goal_id, title, description,
                    success_criteria, status, sort_order, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    title=excluded.title, description=excluded.description,
                    success_criteria=excluded.success_criteria, status=excluded.status,
                    sort_order=excluded.sort_order, updated_at=excluded.updated_at
            """, (
                m["id"], m["project_id"], m["goal_id"], m["title"],
                m.get("description", ""), _json_dumps(m.get("success_criteria")),
                m.get("status", "active"), m.get("sort_order", 0), now, now,
            ))
            conn.commit()

    def get_active_milestone(self, project_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM milestones WHERE project_id=? AND status='active' ORDER BY sort_order LIMIT 1",
                (project_id,)
            ).fetchone()
            return self._dict(row)

    def list_milestones(self, project_id: str, goal_id: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if goal_id:
                rows = conn.execute(
                    "SELECT * FROM milestones WHERE project_id=? AND goal_id=? ORDER BY sort_order",
                    (project_id, goal_id)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM milestones WHERE project_id=? ORDER BY sort_order",
                    (project_id,)
                ).fetchall()
            return self._dicts(rows)

    def upsert_phase(self, p: dict[str, Any]) -> None:
        now = _now()
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO phases (id, project_id, milestone_id, title, description,
                    status, sort_order, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    title=excluded.title, description=excluded.description,
                    status=excluded.status, sort_order=excluded.sort_order,
                    updated_at=excluded.updated_at
            """, (
                p["id"], p["project_id"], p["milestone_id"], p["title"],
                p.get("description", ""), p.get("status", "active"),
                p.get("sort_order", 0), now, now,
            ))
            conn.commit()

    def get_active_phase(self, project_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM phases WHERE project_id=? AND status='active' ORDER BY sort_order LIMIT 1",
                (project_id,)
            ).fetchone()
            return self._dict(row)

    def list_phases(self, project_id: str, milestone_id: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if milestone_id:
                rows = conn.execute(
                    "SELECT * FROM phases WHERE project_id=? AND milestone_id=? ORDER BY sort_order",
                    (project_id, milestone_id)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM phases WHERE project_id=? ORDER BY sort_order",
                    (project_id,)
                ).fetchall()
            return self._dicts(rows)

    # ============================================================
    # Phase Checks
    # ============================================================

    def upsert_phase_checks(self, phase_id: str, project_id: str, checks: list[dict[str, Any]]) -> None:
        """Replace checks for a phase, but preserve any already-passed checks.

        If existing checks have passed entries, we keep them and only replace
        the non-passed ones. This prevents Planner from overwriting verified checks.
        """
        now = _now()
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT description, status FROM phase_checks WHERE phase_id=? AND project_id=?",
                (phase_id, project_id)
            ).fetchall()
            passed_descriptions = {r[0] for r in existing if r[1] == "passed"}

            # Only delete non-passed checks
            if passed_descriptions:
                conn.execute(
                    "DELETE FROM phase_checks WHERE phase_id=? AND project_id=? AND status != 'passed'",
                    (phase_id, project_id)
                )
            else:
                conn.execute("DELETE FROM phase_checks WHERE phase_id=? AND project_id=?", (phase_id, project_id))

            for c in checks:
                # Skip if a passed check with same description already exists
                if c["description"] in passed_descriptions:
                    continue
                conn.execute("""
                    INSERT INTO phase_checks (phase_id, project_id, description, check_type,
                        check_command, expected, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)
                """, (phase_id, project_id, c["description"], c["check_type"],
                      c["check_command"], c.get("expected"), now, now))
            conn.commit()

    def list_phase_checks(self, phase_id: str, project_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM phase_checks WHERE phase_id=? AND project_id=? ORDER BY id",
                (phase_id, project_id)
            ).fetchall()
            return self._dicts(rows)

    def update_phase_check(self, check_id: int, status: str, output: str) -> None:
        now = _now()
        with self._connect() as conn:
            conn.execute(
                "UPDATE phase_checks SET status=?, last_run=?, last_output=?, updated_at=? WHERE id=?",
                (status, now, output[:2000] if output else "", now, check_id)
            )
            conn.commit()

    # ============================================================
    # Objectives
    # ============================================================

    def create_objective(self, o: dict[str, Any]) -> None:
        now = _now()
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO objectives (id, project_id, phase_id, worker_id,
                    title, description, acceptance_criteria, path_scope, depends_on,
                    context_refs, status, priority, session_budget, branch, worktree,
                    created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                o["id"], o["project_id"], o.get("phase_id"), o.get("worker_id"),
                o["title"], o["description"],
                _json_dumps(o["acceptance_criteria"]),
                _json_dumps(o.get("path_scope")),
                _json_dumps(o.get("depends_on")),
                _json_dumps(o.get("context_refs")),
                o.get("status", "todo"),
                o.get("priority", 0),
                _json_dumps(o.get("session_budget")),
                o.get("branch"), o.get("worktree"),
                now, now,
            ))
            conn.commit()

    def get_objective(self, objective_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM objectives WHERE id=?", (objective_id,)).fetchone()
            return self._dict(row)

    def update_objective(self, objective_id: str, fields: dict[str, Any]) -> None:
        if not fields:
            return
        fields["updated_at"] = _now()
        # JSON-encode known JSON fields
        json_fields = {"acceptance_criteria", "path_scope", "depends_on", "context_refs", "session_budget"}
        processed = {}
        for k, v in fields.items():
            if k in json_fields and v is not None and not isinstance(v, str):
                processed[k] = _json_dumps(v)
            else:
                processed[k] = v

        set_clause = ", ".join(f"{k}=?" for k in processed)
        values = list(processed.values()) + [objective_id]
        with self._connect() as conn:
            conn.execute(f"UPDATE objectives SET {set_clause} WHERE id=?", values)
            conn.commit()

    def list_objectives(self, project_id: str, status: list[str] | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if status:
                placeholders = ",".join("?" * len(status))
                rows = conn.execute(
                    f"SELECT * FROM objectives WHERE project_id=? AND status IN ({placeholders}) ORDER BY priority DESC, created_at",
                    [project_id] + status,
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM objectives WHERE project_id=? ORDER BY priority DESC, created_at",
                    (project_id,)
                ).fetchall()
            return self._dicts(rows)

    def get_ready_objectives(self, project_id: str, max_count: int = 10) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM objectives WHERE project_id=? AND status='ready' ORDER BY priority DESC, created_at LIMIT ?",
                (project_id, max_count),
            ).fetchall()
            return self._dicts(rows)

    def delete_objective(self, objective_id: str) -> bool:
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM objectives WHERE id=?", (objective_id,))
            conn.commit()
            return cur.rowcount > 0

    # ============================================================
    # Sessions
    # ============================================================

    def create_session(self, s: dict[str, Any]) -> int:
        now = _now()
        with self._connect() as conn:
            cur = conn.execute("""
                INSERT INTO sessions (objective_id, project_id, agent_id, status, pid,
                    budget, prompt, log_file, started_at, outcome, error_message, checkpoint_count)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                s["objective_id"], s["project_id"], s.get("agent_id"),
                s.get("status", "running"), s.get("pid"),
                _json_dumps(s["budget"]),
                s.get("prompt"), s.get("log_file"),
                s.get("started_at", now),
                s.get("outcome"), s.get("error_message"),
                s.get("checkpoint_count", 0),
            ))
            conn.commit()
            return cur.lastrowid  # type: ignore[return-value]

    def get_session(self, session_id: int) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM sessions WHERE id=?", (session_id,)).fetchone()
            return self._dict(row)

    def update_session(self, session_id: int, fields: dict[str, Any]) -> None:
        if not fields:
            return
        if "budget" in fields and not isinstance(fields["budget"], str):
            fields["budget"] = _json_dumps(fields["budget"])
        set_clause = ", ".join(f"{k}=?" for k in fields)
        values = list(fields.values()) + [session_id]
        with self._connect() as conn:
            conn.execute(f"UPDATE sessions SET {set_clause} WHERE id=?", values)
            conn.commit()

    def get_active_sessions(self, project_id: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM sessions WHERE project_id=? AND status='running' ORDER BY started_at",
                (project_id,),
            ).fetchall()
            return self._dicts(rows)

    def list_sessions(self, project_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM sessions WHERE project_id=? ORDER BY started_at DESC LIMIT ?",
                (project_id, limit),
            ).fetchall()
            return self._dicts(rows)

    def get_sessions_by_status(self, project_id: str, status: str) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM sessions WHERE project_id=? AND status=? ORDER BY started_at",
                (project_id, status),
            ).fetchall()
            return self._dicts(rows)

    # ============================================================
    # Checkpoints
    # ============================================================

    def add_checkpoint(self, cp: dict[str, Any]) -> int:
        now = _now()
        with self._connect() as conn:
            cur = conn.execute("""
                INSERT INTO checkpoints (session_id, objective_id, commit_hash,
                    commit_message, files_changed, review_status, review_note, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                cp["session_id"], cp["objective_id"], cp["commit_hash"],
                cp.get("commit_message"), _json_dumps(cp.get("files_changed")),
                cp.get("review_status", "pending"), cp.get("review_note"),
                cp.get("created_at", now),
            ))
            conn.commit()
            return cur.lastrowid  # type: ignore[return-value]

    def list_checkpoints(self, session_id: int) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM checkpoints WHERE session_id=? ORDER BY id",
                (session_id,),
            ).fetchall()
            return self._dicts(rows)

    def update_checkpoint_review(self, checkpoint_id: int, status: str, note: str | None = None) -> None:
        with self._connect() as conn:
            conn.execute(
                "UPDATE checkpoints SET review_status=?, review_note=? WHERE id=?",
                (status, note, checkpoint_id),
            )
            conn.commit()

    # ============================================================
    # Events
    # ============================================================

    def emit_event(self, project_id: str | None, event_type: str, payload: dict[str, Any] | None = None) -> int:
        now = _now()
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO events (project_id, type, payload, created_at) VALUES (?, ?, ?, ?)",
                (project_id, event_type, _json_dumps(payload), now),
            )
            conn.commit()
            return cur.lastrowid  # type: ignore[return-value]

    def list_events(self, project_id: str | None = None, since: str | None = None,
                    event_type: str | None = None, limit: int = 200) -> list[dict[str, Any]]:
        with self._connect() as conn:
            clauses: list[str] = []
            params: list[Any] = []
            if project_id:
                clauses.append("project_id=?")
                params.append(project_id)
            if since:
                clauses.append("created_at>=?")
                params.append(since)
            if event_type:
                clauses.append("type=?")
                params.append(event_type)
            where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
            rows = conn.execute(
                f"SELECT * FROM events{where} ORDER BY created_at DESC LIMIT ?",
                params + [limit],
            ).fetchall()
            return self._dicts(rows)

    # ============================================================
    # Planner runs
    # ============================================================

    def create_planner_run(self, r: dict[str, Any]) -> int:
        now = _now()
        with self._connect() as conn:
            cur = conn.execute("""
                INSERT INTO planner_runs (project_id, status, pid, objective,
                    plan_output, log_file, started_at, error_message)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                r["project_id"], r.get("status", "running"), r.get("pid"),
                r.get("objective"), r.get("plan_output"), r.get("log_file"),
                r.get("started_at", now), r.get("error_message"),
            ))
            conn.commit()
            return cur.lastrowid  # type: ignore[return-value]

    def update_planner_run(self, run_id: int, fields: dict[str, Any]) -> None:
        if not fields:
            return
        set_clause = ", ".join(f"{k}=?" for k in fields)
        values = list(fields.values()) + [run_id]
        with self._connect() as conn:
            conn.execute(f"UPDATE planner_runs SET {set_clause} WHERE id=?", values)
            conn.commit()

    def get_latest_planner_run(self, project_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM planner_runs WHERE project_id=? ORDER BY started_at DESC LIMIT 1",
                (project_id,),
            ).fetchone()
            return self._dict(row)

    def list_planner_runs(self, project_id: str, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM planner_runs WHERE project_id=? ORDER BY started_at DESC LIMIT ?",
                (project_id, limit),
            ).fetchall()
            return self._dicts(rows)

    # ============================================================
    # Loop stages (admin UI compatibility)
    # ============================================================

    def save_loop_stage(self, stage: dict[str, Any]) -> None:
        now = _now()
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO loop_stages (id, name, description, worker_id, enabled,
                    auto_trigger, config, sort_order, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name=excluded.name, description=excluded.description,
                    worker_id=excluded.worker_id, enabled=excluded.enabled,
                    auto_trigger=excluded.auto_trigger, config=excluded.config,
                    sort_order=excluded.sort_order, updated_at=excluded.updated_at
            """, (
                stage["id"], stage.get("name", stage["id"]),
                stage.get("description", ""), stage.get("worker_id", ""),
                1 if stage.get("enabled", True) else 0,
                1 if stage.get("auto_trigger", False) else 0,
                _json_dumps(stage.get("config", {})),
                stage.get("sort_order", 0), now, now,
            ))
            conn.commit()

    def load_loop_stages(self) -> list[dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM loop_stages ORDER BY sort_order, id").fetchall()
            return self._dicts(rows)

    def delete_loop_stage(self, stage_id: str) -> bool:
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM loop_stages WHERE id=?", (stage_id,))
            conn.commit()
            return cur.rowcount > 0

    def reorder_loop_stages(self, stage_ids: list[str]) -> None:
        with self._connect() as conn:
            for i, sid in enumerate(stage_ids):
                conn.execute("UPDATE loop_stages SET sort_order=? WHERE id=?", (i, sid))
            conn.commit()

    # Loop settings
    def set_loop_setting(self, key: str, value: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO loop_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )
            conn.commit()

    def get_loop_setting(self, key: str, default: str = "") -> str:
        with self._connect() as conn:
            row = conn.execute("SELECT value FROM loop_settings WHERE key=?", (key,)).fetchone()
            return row["value"] if row else default

    # Health logs
    def add_health_log(self, log: dict[str, Any]) -> None:
        with self._connect() as conn:
            conn.execute("""
                INSERT INTO health_logs (agent_id, agent_name, status, command, stdout,
                    stderr, exit_code, latency_ms, error, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                log["agent_id"], log.get("agent_name", ""),
                log.get("status", ""), log.get("command", ""),
                log.get("stdout", ""), log.get("stderr", ""),
                log.get("exit_code", -1), log.get("latency_ms", 0),
                log.get("error", ""), log.get("timestamp", _now()),
            ))
            conn.commit()

    def get_health_logs(self, agent_id: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if agent_id:
                rows = conn.execute(
                    "SELECT * FROM health_logs WHERE agent_id=? ORDER BY timestamp DESC LIMIT ?",
                    (agent_id, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM health_logs ORDER BY timestamp DESC LIMIT ?",
                    (limit,),
                ).fetchall()
            return self._dicts(rows)

    def clear_health_logs(self) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM health_logs")
            conn.commit()
