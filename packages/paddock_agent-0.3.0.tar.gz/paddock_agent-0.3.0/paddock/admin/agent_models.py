"""
简化后的 Agent 系统 - 两层架构（使用 SQLite 存储）
- Agent: 实际 CLI 工具（claudecode, codex, kimicode, mccode...）
- Worker: 逻辑角色（Developer, Researcher, Integrator...）
- WorkerStrategy: 每个 Worker 的派发策略配置
"""
from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from .db import (
    add_health_log,
    get_health_logs,
    load_agent as db_load_agent,
    load_agents as db_load_agents,
    load_worker as db_load_worker,
    load_workers as db_load_workers,
    save_agent as db_save_agent,
    save_worker as db_save_worker,
)


# ==================== Agent（实际 CLI 工具） ====================

class AgentStatus(str, Enum):
    OK = "ok"
    ERROR = "error"
    UNKNOWN = "unknown"
    NOT_CONFIGURED = "not_configured"


@dataclass
class Agent:
    """Agent = 实际安装的 CLI 工具"""
    id: str                          # 唯一标识，如 "claudecode", "mccode"
    name: str                        # 显示名称，如 "Claude Code"
    cli_command: str                 # CLI 命令，如 "claude", "mccode"
    command_template: str = ""       # 完整命令模板
    description: str = ""
    enabled: bool = True
    icon: str = "🤖"
    color: str = "#666"
    env: dict[str, str] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "cli_command": self.cli_command,
            "command_template": self.command_template,
            "description": self.description,
            "enabled": self.enabled,
            "icon": self.icon,
            "color": self.color,
            "env": self.env,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Agent:
        return cls(
            id=data["id"],
            name=data.get("name", data["id"]),
            cli_command=data.get("cli_command", data["id"]),
            command_template=data.get("command_template", ""),
            description=data.get("description", ""),
            enabled=data.get("enabled", True),
            icon=data.get("icon", "🤖"),
            color=data.get("color", "#666"),
            env=data.get("env", {}),
        )


# ==================== Worker（逻辑角色） ====================

class DispatchMode(str, Enum):
    """派发模式"""
    FIXED = "fixed"           # 固定使用指定 Agent
    AUTO = "auto"             # 自动选择（按优先级）
    ROUND_ROBIN = "round_robin"  # 轮询


@dataclass
class WorkerStrategy:
    """Worker 的派发策略"""
    mode: DispatchMode = DispatchMode.FIXED
    # FIXED 模式：指定使用哪个 agent
    fixed_agent: str = ""
    # AUTO/ROUND_ROBIN 模式：优先级列表
    agent_priority: list[str] = field(default_factory=list)
    # 任务内容关键词匹配（可选）
    content_rules: list[dict[str, Any]] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode.value,
            "fixed_agent": self.fixed_agent,
            "agent_priority": self.agent_priority,
            "content_rules": self.content_rules,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WorkerStrategy:
        return cls(
            mode=DispatchMode(data.get("mode", "fixed")),
            fixed_agent=data.get("fixed_agent", ""),
            agent_priority=data.get("agent_priority", []),
            content_rules=data.get("content_rules", []),
        )


@dataclass
class Worker:
    """Worker = 研发流程中的逻辑角色"""
    id: str                          # 唯一标识，如 "developer"
    name: str                        # 显示名称，如 "开发者"
    description: str = ""
    icon: str = "👤"
    color: str = "#3b82f6"
    # 派发策略配置
    strategy: WorkerStrategy = field(default_factory=lambda: WorkerStrategy(
        mode=DispatchMode.FIXED,
        fixed_agent="",
        agent_priority=[],
    ))
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "icon": self.icon,
            "color": self.color,
            "strategy": self.strategy.to_dict(),
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Worker:
        return cls(
            id=data["id"],
            name=data.get("name", data["id"]),
            description=data.get("description", ""),
            icon=data.get("icon", "👤"),
            color=data.get("color", "#3b82f6"),
            strategy=WorkerStrategy.from_dict(data.get("strategy", {})),
        )


# ==================== 默认配置 ====================

DEFAULT_AGENTS: list[Agent] = [
    Agent(
        id="claudecode",
        name="Claude Code",
        cli_command="claude",
        command_template="claude --prompt-file {prompt_file} --working-dir {worktree}",
        description="Anthropic Claude Code CLI",
        icon="🧠",
        color="#d97757",
    ),
    Agent(
        id="codex",
        name="OpenAI Codex",
        cli_command="npx",
        command_template="npx @openai/codex -a full-auto -q $(cat {prompt_file}) --cwd {worktree}",
        description="OpenAI Codex CLI",
        icon="🤖",
        color="#10a37f",
    ),
    Agent(
        id="kimicode",
        name="Kimi CLI",
        cli_command="kimi",
        command_template="kimi task --file {prompt_file} --cwd {worktree}",
        description="Kimi 智能助手 CLI",
        icon="🌙",
        color="#4f46e5",
    ),
    Agent(
        id="mccode",
        name="MC Code",
        cli_command="mccode",
        command_template="mccode --prompt-file {prompt_file} --working-dir {worktree}",
        description="MC Code (Claude 替代入口)",
        icon="⚡",
        color="#f59e0b",
    ),
]

DEFAULT_WORKERS: list[Worker] = [
    Worker(
        id="developer",
        name="开发者",
        description="代码实现、功能开发",
        icon="💻",
        color="#3b82f6",
        strategy=WorkerStrategy(
            mode=DispatchMode.FIXED,
            fixed_agent="claudecode",
            agent_priority=["claudecode", "mccode", "kimicode"],
        ),
    ),
    Worker(
        id="researcher",
        name="研究员",
        description="规则研究、资料分析",
        icon="🔬",
        color="#8b5cf6",
        strategy=WorkerStrategy(
            mode=DispatchMode.FIXED,
            fixed_agent="codex",
            agent_priority=["codex", "kimicode"],
        ),
    ),
    Worker(
        id="integrator",
        name="整合者",
        description="代码审查、合并整合",
        icon="🔀",
        color="#10b981",
        strategy=WorkerStrategy(
            mode=DispatchMode.FIXED,
            fixed_agent="claudecode",
            agent_priority=["claudecode", "mccode"],
        ),
    ),
    Worker(
        id="documenter",
        name="文档员",
        description="文档编写、Session 记录",
        icon="📝",
        color="#f59e0b",
        strategy=WorkerStrategy(
            mode=DispatchMode.FIXED,
            fixed_agent="kimicode",
            agent_priority=["kimicode", "claudecode"],
        ),
    ),
]


# ==================== 数据操作（使用 SQLite） ====================

def load_agents() -> list[Agent]:
    """加载所有 Agent"""
    rows = db_load_agents()
    return [Agent.from_dict(row) for row in rows]


def load_agent(agent_id: str) -> Agent | None:
    """加载单个 Agent"""
    row = db_load_agent(agent_id)
    return Agent.from_dict(row) if row else None


def save_agent(agent: Agent) -> None:
    """保存 Agent"""
    db_save_agent(agent.to_dict())


def save_agents(agents: list[Agent]) -> None:
    """保存所有 Agent"""
    for agent in agents:
        db_save_agent(agent.to_dict())


def load_workers() -> list[Worker]:
    """加载所有 Worker"""
    rows = db_load_workers()
    return [Worker.from_dict(row) for row in rows]


def load_worker(worker_id: str) -> Worker | None:
    """加载单个 Worker"""
    row = db_load_worker(worker_id)
    return Worker.from_dict(row) if row else None


def save_worker(worker: Worker) -> None:
    """保存 Worker"""
    db_save_worker(worker.to_dict())


def save_workers(workers: list[Worker]) -> None:
    """保存所有 Worker"""
    for worker in workers:
        db_save_worker(worker.to_dict())


def update_worker_strategy(worker_id: str, strategy: WorkerStrategy) -> Worker | None:
    """更新 Worker 的策略配置"""
    worker = load_worker(worker_id)
    if worker:
        worker.strategy = strategy
        save_worker(worker)
    return worker


# ==================== 派发逻辑 ====================

def dispatch_task(worker_id: str, task_context: dict[str, Any]) -> dict[str, Any]:
    """
    根据 Worker 策略派发任务到具体 Agent
    
    Returns:
        {
            "worker_id": str,
            "worker_name": str,
            "agent_id": str,
            "agent_name": str,
            "command": list[str],
            "reason": str,
        }
    """
    workers = load_workers()
    agents = load_agents()
    
    worker = next((w for w in workers if w.id == worker_id), None)
    if not worker:
        raise ValueError(f"Worker not found: {worker_id}")
    
    strategy = worker.strategy
    agent_id = ""
    reason = ""
    
    if strategy.mode == DispatchMode.FIXED:
        # 固定模式：直接使用配置的 Agent
        agent_id = strategy.fixed_agent
        reason = f"Worker '{worker.name}' 配置为固定使用 '{agent_id}'"
    
    elif strategy.mode == DispatchMode.AUTO:
        # 自动模式：按优先级选择第一个可用的
        for aid in strategy.agent_priority:
            agent = next((a for a in agents if a.id == aid and a.enabled), None)
            if agent:
                agent_id = aid
                reason = f"自动选择：优先级列表中第一个可用 Agent '{aid}'"
                break
        if not agent_id:
            # 回退到第一个可用的
            agent = next((a for a in agents if a.enabled), None)
            if agent:
                agent_id = agent.id
                reason = f"优先级列表无可用 Agent，回退到 '{agent_id}'"
    
    elif strategy.mode == DispatchMode.ROUND_ROBIN:
        # TODO: 实现轮询逻辑（需要持久化状态）
        pass
    
    if not agent_id:
        raise ValueError(f"No available agent for worker: {worker_id}")
    
    agent = next((a for a in agents if a.id == agent_id), None)
    if not agent:
        raise ValueError(f"Agent not found: {agent_id}")
    
    # 构建命令
    vars_dict = {
        "prompt_file": task_context.get("prompt_file", ""),
        "worktree": task_context.get("worktree", "."),
    }
    command = agent.command_template
    for key, value in vars_dict.items():
        command = command.replace(f"{{{key}}}", value)
    
    return {
        "worker_id": worker.id,
        "worker_name": worker.name,
        "agent_id": agent.id,
        "agent_name": agent.name,
        "command": command.split(),
        "cli_command": agent.cli_command,
        "reason": reason,
        "strategy_mode": strategy.mode.value,
    }


# ==================== 健康检查 ====================

@dataclass
class HealthCheckResult:
    agent_id: str
    agent_name: str
    status: str
    command: str
    stdout: str
    stderr: str
    exit_code: int
    latency_ms: float
    timestamp: str
    error: str = ""


def check_agent_health(agent: Agent) -> HealthCheckResult:
    """检查单个 Agent 的健康状态"""
    import time
    
    start = time.time()
    command = f"{agent.cli_command} --version"
    stdout = ""
    stderr = ""
    exit_code = -1
    status = "unknown"
    error = ""
    
    try:
        result = subprocess.run(
            [agent.cli_command, "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        latency = (time.time() - start) * 1000
        exit_code = result.returncode
        stdout = result.stdout
        stderr = result.stderr
        
        if result.returncode == 0:
            status = "ok"
        else:
            status = "error"
            error = result.stderr or "Unknown error"
            
    except FileNotFoundError:
        latency = (time.time() - start) * 1000
        status = "not_configured"
        error = f"{agent.cli_command} 未安装"
    except subprocess.TimeoutExpired:
        latency = 10000
        status = "error"
        error = "健康检查超时"
    except Exception as e:
        latency = (time.time() - start) * 1000
        status = "error"
        error = str(e)
    
    # 记录日志到 SQLite
    result = HealthCheckResult(
        agent_id=agent.id,
        agent_name=agent.name,
        status=status,
        command=command,
        stdout=stdout[:1000],
        stderr=stderr[:1000],
        exit_code=exit_code,
        latency_ms=latency,
        timestamp=datetime.now().isoformat(),
        error=error,
    )
    
    add_health_log({
        "agent_id": result.agent_id,
        "agent_name": result.agent_name,
        "status": result.status,
        "command": result.command,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "exit_code": result.exit_code,
        "latency_ms": result.latency_ms,
        "timestamp": result.timestamp,
        "error": result.error,
    })
    
    return result


def get_health_logs(agent_id: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
    """获取健康检查日志"""
    from db import get_health_logs as db_get_health_logs
    return db_get_health_logs(agent_id=agent_id, limit=limit)
