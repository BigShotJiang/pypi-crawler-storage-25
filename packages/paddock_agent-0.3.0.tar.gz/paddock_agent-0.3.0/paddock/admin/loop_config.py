"""
研发 Loop 配置 - 定义研发流程各环节使用哪个 Worker（使用 SQLite 存储）
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .db import (
    delete_loop_stage as db_delete_loop_stage,
    get_loop_setting,
    load_loop_stages as db_load_loop_stages,
    reorder_loop_stages as db_reorder_loop_stages,
    save_loop_stage as db_save_loop_stage,
    set_loop_setting,
)


@dataclass
class LoopStage:
    """研发 Loop 的一个环节"""
    id: str                          # 环节标识，如 "plan", "implement", "review"
    name: str                        # 显示名称，如 "计划", "实现", "审查"
    description: str = ""
    worker_id: str = ""              # 使用哪个 Worker（逻辑角色）
    enabled: bool = True             # 是否启用
    auto_trigger: bool = False       # 是否自动触发
    # 环节特定的配置
    config: dict[str, Any] = field(default_factory=dict)
    sort_order: int = 0              # 排序顺序


@dataclass
class LoopConfig:
    """研发 Loop 完整配置"""
    name: str = "Paddock Standard Loop"
    description: str = "标准研发流程"
    stages: list[LoopStage] = field(default_factory=list)
    # 全局配置
    settings: dict[str, Any] = field(default_factory=dict)


# 默认研发 Loop 配置
DEFAULT_LOOP = LoopConfig(
    name="Paddock Standard Loop",
    description="标准多 Agent 协作研发流程",
    stages=[
        LoopStage(
            id="plan",
            name="计划",
            description="Coordinator 分析任务、制定计划",
            worker_id="coordinator",  # Coordinator 是特殊的 Worker
            enabled=True,
            auto_trigger=True,
            sort_order=0,
        ),
        LoopStage(
            id="implement",
            name="实现",
            description="Developer 执行代码实现",
            worker_id="developer",
            enabled=True,
            auto_trigger=False,  # 需要人工确认或条件触发
            sort_order=1,
        ),
        LoopStage(
            id="integrate",
            name="整合",
            description="Integrator 审查并合并代码",
            worker_id="integrator",
            enabled=True,
            auto_trigger=False,
            sort_order=2,
        ),
        LoopStage(
            id="document",
            name="文档",
            description="Documenter 编写 Session 记录",
            worker_id="documenter",
            enabled=True,
            auto_trigger=False,
            sort_order=3,
        ),
    ],
    settings={
        "parallel_limit": 3,          # 最大并行任务数
        "auto_advance": False,        # 是否自动推进到下一环节
        "require_approval": True,     # 是否需要人工确认
    },
)


def load_loop_config() -> LoopConfig:
    """加载研发 Loop 配置（从 SQLite）"""
    stages = db_load_loop_stages()
    
    return LoopConfig(
        name=get_loop_setting("name", DEFAULT_LOOP.name),
        description=get_loop_setting("description", DEFAULT_LOOP.description),
        stages=[LoopStage(
            id=s["id"],
            name=s["name"],
            description=s["description"],
            worker_id=s["worker_id"],
            enabled=s["enabled"],
            auto_trigger=s["auto_trigger"],
            config=s["config"],
            sort_order=s["sort_order"],
        ) for s in stages],
        settings={
            "parallel_limit": int(get_loop_setting("parallel_limit", "3")),
            "auto_advance": get_loop_setting("auto_advance", "False").lower() == "true",
            "require_approval": get_loop_setting("require_approval", "True").lower() == "true",
        },
    )


def save_loop_config(config: LoopConfig) -> None:
    """保存研发 Loop 配置（到 SQLite）"""
    # 保存设置
    set_loop_setting("name", config.name)
    set_loop_setting("description", config.description)
    set_loop_setting("parallel_limit", str(config.settings.get("parallel_limit", 3)))
    set_loop_setting("auto_advance", str(config.settings.get("auto_advance", False)))
    set_loop_setting("require_approval", str(config.settings.get("require_approval", True)))


def update_loop_stage(stage_id: str, updates: dict[str, Any]) -> LoopStage | None:
    """更新 Loop 环节"""
    config = load_loop_config()
    for stage in config.stages:
        if stage.id == stage_id:
            if "worker_id" in updates:
                stage.worker_id = updates["worker_id"]
            if "enabled" in updates:
                stage.enabled = updates["enabled"]
            if "auto_trigger" in updates:
                stage.auto_trigger = updates["auto_trigger"]
            if "config" in updates:
                stage.config = {**stage.config, **updates["config"]}
            if "name" in updates:
                stage.name = updates["name"]
            if "description" in updates:
                stage.description = updates["description"]
            
            # 保存到数据库
            db_save_loop_stage({
                "id": stage.id,
                "name": stage.name,
                "description": stage.description,
                "worker_id": stage.worker_id,
                "enabled": stage.enabled,
                "auto_trigger": stage.auto_trigger,
                "config": stage.config,
                "sort_order": stage.sort_order,
            })
            return stage
    return None


def reorder_loop_stages(stage_ids: list[str]) -> LoopConfig:
    """重新排序 Loop 环节"""
    db_reorder_loop_stages(stage_ids)
    return load_loop_config()


def add_loop_stage(stage: LoopStage) -> LoopConfig:
    """添加新环节"""
    # 获取当前最大 sort_order
    stages = db_load_loop_stages()
    max_order = max((s["sort_order"] for s in stages), default=-1)
    stage.sort_order = max_order + 1
    
    db_save_loop_stage({
        "id": stage.id,
        "name": stage.name,
        "description": stage.description,
        "worker_id": stage.worker_id,
        "enabled": stage.enabled,
        "auto_trigger": stage.auto_trigger,
        "config": stage.config,
        "sort_order": stage.sort_order,
    })
    return load_loop_config()


def remove_loop_stage(stage_id: str) -> LoopConfig:
    """移除环节"""
    db_delete_loop_stage(stage_id)
    return load_loop_config()


def toggle_loop_stage(stage_id: str, enabled: bool | None = None) -> LoopStage | None:
    """启用/禁用 Loop 环节"""
    config = load_loop_config()
    for stage in config.stages:
        if stage.id == stage_id:
            if enabled is None:
                enabled = not stage.enabled
            stage.enabled = enabled
            db_save_loop_stage({
                "id": stage.id,
                "name": stage.name,
                "description": stage.description,
                "worker_id": stage.worker_id,
                "enabled": stage.enabled,
                "auto_trigger": stage.auto_trigger,
                "config": stage.config,
                "sort_order": stage.sort_order,
            })
            return stage
    return None
