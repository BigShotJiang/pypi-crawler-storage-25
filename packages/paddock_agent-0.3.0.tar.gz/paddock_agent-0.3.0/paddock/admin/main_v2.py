"""
新的 API - 两层架构：Agent（工具）+ Worker（角色）+ Loop（流程）
"""
from __future__ import annotations

from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

from agent_models import (
    Agent,
    DispatchMode,
    HealthCheckResult,
    Worker,
    WorkerStrategy,
    check_agent_health,
    dispatch_task,
    get_health_logs,
    load_agents,
    load_workers,
    save_agents,
    save_workers,
    update_worker_strategy,
)
from loop_config import (
    LoopStage,
    add_loop_stage,
    load_loop_config,
    remove_loop_stage,
    reorder_loop_stages,
    save_loop_config,
    update_loop_stage,
)

app = FastAPI(title="Paddock Admin V2", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5174", "http://127.0.0.1:5174", "http://127.0.0.1:4174"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==================== Agent API ====================

@app.get("/api/v2/agents")
async def list_agents() -> dict[str, Any]:
    """获取所有 Agent（实际 CLI 工具）"""
    agents = load_agents()
    return {"agents": [a.to_dict() for a in agents]}


@app.post("/api/v2/agents")
async def create_agent(payload: dict[str, Any]) -> dict[str, Any]:
    """创建新 Agent"""
    agent = Agent.from_dict(payload)
    agents = load_agents()
    agents.append(agent)
    save_agents(agents)
    return {"ok": True, "agent": agent.to_dict()}


@app.put("/api/v2/agents/{agent_id}")
async def update_agent(agent_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    """更新 Agent"""
    agents = load_agents()
    for i, a in enumerate(agents):
        if a.id == agent_id:
            agents[i] = Agent.from_dict({**a.to_dict(), **payload})
            save_agents(agents)
            return {"ok": True, "agent": agents[i].to_dict()}
    raise HTTPException(status_code=404, detail="Agent not found")


@app.delete("/api/v2/agents/{agent_id}")
async def delete_agent(agent_id: str) -> dict[str, Any]:
    """删除 Agent"""
    agents = load_agents()
    agents = [a for a in agents if a.id != agent_id]
    save_agents(agents)
    return {"ok": True}


@app.post("/api/v2/agents/{agent_id}/check")
async def check_agent(agent_id: str) -> dict[str, Any]:
    """检查单个 Agent 健康状态"""
    agents = load_agents()
    agent = next((a for a in agents if a.id == agent_id), None)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    result = check_agent_health(agent)
    return {
        "ok": True,
        "result": {
            "agent_id": result.agent_id,
            "agent_name": result.agent_name,
            "status": result.status,
            "latency_ms": result.latency_ms,
            "version": result.stdout.strip()[:100] if result.stdout else "",
            "error": result.error,
        },
    }


@app.get("/api/v2/agents/health-logs")
async def list_health_logs(
    agent_id: str = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200)
) -> dict[str, Any]:
    """获取健康检查日志"""
    logs = get_health_logs(agent_id=agent_id, limit=limit)
    return {"logs": logs}


# ==================== Worker API ====================

@app.get("/api/v2/workers")
async def list_workers() -> dict[str, Any]:
    """获取所有 Worker（逻辑角色）"""
    workers = load_workers()
    return {"workers": [w.to_dict() for w in workers]}


@app.post("/api/v2/workers")
async def create_worker(payload: dict[str, Any]) -> dict[str, Any]:
    """创建新 Worker"""
    worker = Worker.from_dict(payload)
    workers = load_workers()
    workers.append(worker)
    save_workers(workers)
    return {"ok": True, "worker": worker.to_dict()}


@app.put("/api/v2/workers/{worker_id}")
async def update_worker(worker_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    """更新 Worker"""
    workers = load_workers()
    for i, w in enumerate(workers):
        if w.id == worker_id:
            workers[i] = Worker.from_dict({**w.to_dict(), **payload})
            save_workers(workers)
            return {"ok": True, "worker": workers[i].to_dict()}
    raise HTTPException(status_code=404, detail="Worker not found")


@app.put("/api/v2/workers/{worker_id}/strategy")
async def update_worker_strategy_endpoint(worker_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    """更新 Worker 的派发策略"""
    strategy = WorkerStrategy(
        mode=DispatchMode(payload.get("mode", "fixed")),
        fixed_agent=payload.get("fixed_agent", ""),
        agent_priority=payload.get("agent_priority", []),
        content_rules=payload.get("content_rules", []),
    )
    worker = update_worker_strategy(worker_id, strategy)
    if not worker:
        raise HTTPException(status_code=404, detail="Worker not found")
    return {"ok": True, "worker": worker.to_dict()}


@app.post("/api/v2/workers/{worker_id}/dispatch")
async def dispatch_to_worker(worker_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    """模拟派发任务到 Worker，返回实际使用的 Agent"""
    try:
        result = dispatch_task(worker_id, payload)
        return {"ok": True, "result": result}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


# ==================== Loop API ====================

@app.get("/api/v2/loop")
async def get_loop_config() -> dict[str, Any]:
    """获取研发 Loop 配置"""
    config = load_loop_config()
    return {
        "name": config.name,
        "description": config.description,
        "stages": [
            {
                "id": s.id,
                "name": s.name,
                "description": s.description,
                "worker_id": s.worker_id,
                "enabled": s.enabled,
                "auto_trigger": s.auto_trigger,
                "config": s.config,
            }
            for s in config.stages
        ],
        "settings": config.settings,
    }


@app.put("/api/v2/loop")
async def update_loop(payload: dict[str, Any]) -> dict[str, Any]:
    """更新 Loop 配置"""
    config = load_loop_config()
    if "name" in payload:
        config.name = payload["name"]
    if "description" in payload:
        config.description = payload["description"]
    if "settings" in payload:
        config.settings = {**config.settings, **payload["settings"]}
    save_loop_config(config)
    return {"ok": True}


@app.put("/api/v2/loop/stages/{stage_id}")
async def update_stage(stage_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    """更新 Loop 环节"""
    stage = update_loop_stage(stage_id, payload)
    if not stage:
        raise HTTPException(status_code=404, detail="Stage not found")
    return {"ok": True, "stage": {
        "id": stage.id,
        "name": stage.name,
        "worker_id": stage.worker_id,
        "enabled": stage.enabled,
    }}


@app.post("/api/v2/loop/stages/reorder")
async def reorder_stages(payload: dict[str, Any]) -> dict[str, Any]:
    """重新排序 Loop 环节"""
    stage_ids = payload.get("stage_ids", [])
    config = reorder_loop_stages(stage_ids)
    return {"ok": True}


# ==================== Dashboard API ====================

@app.get("/api/v2/dashboard")
async def dashboard() -> dict[str, Any]:
    """仪表盘数据"""
    agents = load_agents()
    workers = load_workers()
    loop = load_loop_config()
    
    # 统计
    agent_stats = {
        "total": len(agents),
        "enabled": sum(1 for a in agents if a.enabled),
        "healthy": 0,  # TODO: 从缓存读取
    }
    
    worker_stats = {
        "total": len(workers),
        "fixed_mode": sum(1 for w in workers if w.strategy.mode == DispatchMode.FIXED),
        "auto_mode": sum(1 for w in workers if w.strategy.mode == DispatchMode.AUTO),
    }
    
    return {
        "agents": agent_stats,
        "workers": worker_stats,
        "loop": {
            "name": loop.name,
            "stage_count": len(loop.stages),
            "enabled_stages": sum(1 for s in loop.stages if s.enabled),
        },
    }
