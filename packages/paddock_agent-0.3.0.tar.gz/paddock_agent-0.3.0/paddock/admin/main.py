from __future__ import annotations

import json
import os
import signal
import subprocess
from pathlib import Path
from typing import Any

import yaml
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

ROOT = Path(__file__).resolve().parents[3]
PROJECTS_DIR = ROOT / "projects"
RUNTIME_DIR = ROOT / "runtime" / "projects"
DEFAULT_PROJECT = os.environ.get("PADDOCK_PROJECT") or ""

app = FastAPI(title="Paddock Admin", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5174", "http://127.0.0.1:5174", "http://127.0.0.1:4174"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _read_yaml(path: Path) -> Any:
    if not path.exists():
        return None
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def _read_json(path: Path) -> Any:
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            rows.append({"type": "parse_error", "raw": line})
    return rows


def _pid_alive(pid: int | None) -> bool:
    if not pid:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _project_config(project: str) -> dict[str, Any]:
    return _read_yaml(PROJECTS_DIR / f"{project}.yaml") or {}


def _project_meta(project: str) -> dict[str, Any]:
    config = _project_config(project)
    meta_path = config.get("project_meta_path")
    if not meta_path:
        return {}
    return _read_yaml(Path(meta_path)) or {}


def _project_meta_path(project: str) -> Path | None:
    config = _project_config(project)
    meta_path = config.get("project_meta_path")
    if not meta_path:
        return None
    return Path(meta_path)


def _write_yaml(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(payload, allow_unicode=True, sort_keys=False), encoding="utf-8")


def _runtime_root(project: str) -> Path:
    config = _project_config(project)
    return Path(config.get("runtime_root", RUNTIME_DIR / project)).resolve()


def _repo_root(project: str) -> Path:
    config = _project_config(project)
    return Path(config["repo_root"]).resolve()


def _git_status(project: str) -> list[str]:
    repo = _repo_root(project)
    if not repo.exists():
        return []
    result = subprocess.run(["git", "status", "--short"], cwd=str(repo), capture_output=True, text=True, check=False)
    return [line for line in result.stdout.splitlines() if line.strip()]


def _git_worktrees(project: str) -> list[dict[str, str]]:
    repo = _repo_root(project)
    if not repo.exists():
        return []
    result = subprocess.run(["git", "worktree", "list", "--porcelain"], cwd=str(repo), capture_output=True, text=True, check=False)
    rows: list[dict[str, str]] = []
    current: dict[str, str] = {}
    for line in result.stdout.splitlines():
        if not line.strip():
            if current:
                rows.append(current)
                current = {}
            continue
        key, _, value = line.partition(" ")
        if key == "worktree":
            current["path"] = value
        elif key == "branch":
            current["branch"] = value.replace("refs/heads/", "")
        elif key == "HEAD":
            current["head"] = value
    if current:
        rows.append(current)
    return rows


def _status_counts(tasks: list[dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for task in tasks:
        status = task.get("status", "unknown")
        counts[status] = counts.get(status, 0) + 1
    return counts


def _parallelism(tasks: list[dict[str, Any]]) -> dict[str, int]:
    in_progress = [task for task in tasks if task.get("status") == "in_progress"]
    ready = [task for task in tasks if task.get("status") == "ready"]
    blocked = [task for task in tasks if task.get("status") == "blocked"]
    review = [task for task in tasks if task.get("status") == "review"]
    return {
        "in_progress": len(in_progress),
        "ready": len(ready),
        "blocked": len(blocked),
        "review": len(review),
        "mode_score": len(in_progress) + len(ready),
    }


def _pipeline_state(tasks: list[dict[str, Any]], coordinator: dict[str, Any] | None) -> str:
    counts = _status_counts(tasks)
    if counts.get("in_progress") or counts.get("review") or counts.get("ready"):
        return "active"
    if counts.get("todo"):
        return "queued"
    if coordinator and coordinator.get("status") == "blocked":
        return "graph_exhausted"
    return "idle"


# ==================== Goal Management (三层结构) ====================

def _goal_management(project: str) -> dict[str, Any]:
    """获取目标管理系统数据（目标-里程碑-关键动作三层结构）"""
    meta = _project_meta(project)
    
    # 优先读取 v2 结构
    goal_management_v2 = meta.get("goal_management_v2")
    if goal_management_v2:
        # 如果 v2 已有数据，直接返回
        if goal_management_v2.get("actions"):
            return goal_management_v2
        # v2 存在但 actions 为空，检查是否有旧数据需要迁移
        goal_management_old = meta.get("goal_management")
        if goal_management_old and goal_management_old.get("phases"):
            migrated = _migrate_goal_management(goal_management_old)
            # 自动保存迁移后的数据
            _save_goal_management_v2(project, migrated)
            return migrated
        return goal_management_v2
    
    # 没有 v2，尝试迁移旧数据
    goal_management_old = meta.get("goal_management")
    if goal_management_old:
        migrated = _migrate_goal_management(goal_management_old)
        # 自动保存迁移后的数据
        _save_goal_management_v2(project, migrated)
        return migrated
    
    return {
        "goals": [],
        "milestones": [],
        "actions": [],
        "current_goal_id": "",
        "current_milestone_id": "",
    }


def _save_goal_management_v2(project: str, data: dict[str, Any]) -> None:
    """保存目标管理 v2 数据"""
    meta_path = _project_meta_path(project)
    if meta_path is None:
        return
    meta = _project_meta(project)
    meta["goal_management_v2"] = data
    if "goal_management" in meta:
        meta.pop("goal_management", None)
    _write_yaml(meta_path, meta)


def _migrate_goal_management(old_data: dict[str, Any]) -> dict[str, Any]:
    """将旧的两层结构迁移为三层结构"""
    old_goal = old_data.get("goal", {})
    old_milestones = old_data.get("milestones", [])
    old_phases = old_data.get("phases", [])
    
    # 创建目标
    goal_id = "goal-1"
    goals = [{
        "id": goal_id,
        "title": old_goal.get("title", ""),
        "description": old_goal.get("description", ""),
        "status": "active",
    }]
    
    # 迁移里程碑
    milestones = []
    actions = []
    for m in old_milestones:
        m_id = m.get("id", f"m-{len(milestones)}")
        milestones.append({
            "id": m_id,
            "goal_id": goal_id,
            "title": m.get("title", ""),
            "description": m.get("description", ""),
            "status": m.get("status", "todo"),
            "order": len(milestones),
        })
        # 将旧的 phase 迁移为关键动作
        linked_phases = [p for p in old_phases if p.get("milestone_id") == m_id]
        for p in linked_phases:
            actions.append({
                "id": p.get("id", f"a-{len(actions)}"),
                "milestone_id": m_id,
                "title": p.get("title", ""),
                "description": p.get("description", ""),
                "acceptance_criteria": [],  # 新字段
                "status": p.get("status", "todo"),
                "task_ids": p.get("task_ids", []),
            })
    
    return {
        "goals": goals,
        "milestones": milestones,
        "actions": actions,
        "current_goal_id": goal_id,
        "current_milestone_id": old_data.get("current_milestone_id", ""),
    }


# ==================== Agent APIs ====================

# ==================== Dispatch Strategy ====================

@app.get("/dispatch-strategy")
async def get_dispatch_strategy() -> dict[str, Any]:
    """获取当前派发策略"""
    from dispatch_strategy import load_dispatch_strategy
    strategy = load_dispatch_strategy()
    return {"strategy": strategy.to_dict()}


@app.put("/dispatch-strategy")
async def update_dispatch_strategy_endpoint(payload: dict[str, Any]) -> dict[str, Any]:
    """更新派发策略"""
    from dispatch_strategy import update_dispatch_strategy
    strategy = update_dispatch_strategy(payload)
    return {"ok": True, "strategy": strategy.to_dict()}


@app.post("/dispatch-strategy/preview")
async def preview_dispatch(payload: dict[str, Any]) -> dict[str, Any]:
    """预览任务会派发给哪个 agent（Worker 角色与 Agent 解耦）"""
    from dispatch_strategy import select_agent_for_task, load_dispatch_strategy
    
    task_role = payload.get("task_role", "")
    task_title = payload.get("task_title", "")
    task_id = payload.get("task_id", "")
    task_files = payload.get("task_files", [])
    
    # 获取可用 agents
    agents = load_agents_config()
    available_agents = [a.id for a in agents if a.enabled]
    
    result = select_agent_for_task(
        task_role=task_role,
        task_title=task_title,
        task_id=task_id,
        task_files=task_files,
        available_agents=available_agents,
    )
    
    strategy = load_dispatch_strategy()
    
    # 获取 agent 名称
    agent_name = next((a.name for a in agents if a.id == result["agent_id"]), result["agent_id"])
    
    return {
        "task_role": task_role,
        "task_title": task_title,
        "selected_agent": result["agent_id"],
        "agent_name": agent_name,
        "strategy_type": result["strategy"],
        "reason": result["reason"],
        "decision_log": result["decision_log"],
        "available_agents": available_agents,
        "role_mappings": strategy.force_config,
    }


# ==================== Legacy APIs ====================

@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/projects")
async def projects() -> dict[str, Any]:
    items = []
    for path in sorted(PROJECTS_DIR.glob("*.yaml")):
        config = _read_yaml(path) or {}
        items.append({"slug": path.stem, "name": config.get("name", path.stem), "repo_root": config.get("repo_root", "")})
    return {"default_project": DEFAULT_PROJECT, "projects": items}


# 保留旧接口兼容性
@app.post("/goal-management")
async def save_goal_management(payload: dict[str, Any]) -> dict[str, Any]:
    project = payload.get("project") or DEFAULT_PROJECT
    goal_management = payload.get("goal_management")
    if not isinstance(goal_management, dict):
        raise HTTPException(status_code=400, detail="goal_management must be an object")
    meta_path = _project_meta_path(project)
    if meta_path is None:
        raise HTTPException(status_code=400, detail="project has no project_meta_path")
    meta = _project_meta(project)
    meta["goal_management_v2"] = goal_management
    if "goal_management" in meta:
        meta.pop("goal_management", None)
    _write_yaml(meta_path, meta)
    return {"ok": True, "project": project}


# 新的三层结构目标管理 API
@app.get("/goal-management-v2")
async def get_goal_management_v2(project: str = Query(default=DEFAULT_PROJECT)) -> dict[str, Any]:
    """获取三层结构目标管理数据"""
    return _goal_management(project)


@app.post("/goal-management-v2")
async def save_goal_management_v2(payload: dict[str, Any]) -> dict[str, Any]:
    """保存三层结构目标管理数据"""
    project = payload.get("project") or DEFAULT_PROJECT
    goal_data = payload.get("data")
    if not isinstance(goal_data, dict):
        raise HTTPException(status_code=400, detail="data must be an object")
    meta_path = _project_meta_path(project)
    if meta_path is None:
        raise HTTPException(status_code=400, detail="project has no project_meta_path")
    meta = _project_meta(project)
    meta["goal_management_v2"] = goal_data
    if "goal_management" in meta:
        meta.pop("goal_management", None)
    _write_yaml(meta_path, meta)
    return {"ok": True, "project": project}


@app.post("/goal-management-v2/parse-markdown")
async def parse_goal_markdown(payload: dict[str, Any]) -> dict[str, Any]:
    """解析目标管理的 Markdown 格式"""
    markdown = payload.get("markdown", "")
    
    goals = []
    milestones = []
    actions = []
    
    current_goal = None
    current_milestone = None
    current_action = None
    
    # 用于累积描述的缓冲
    goal_desc_buffer = []
    milestone_desc_buffer = []
    action_desc_buffer = []
    
    lines = markdown.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        
        # 目标: # 标题
        if stripped.startswith("# ") and not stripped.startswith("## "):
            # 保存之前的描述
            if current_goal and goal_desc_buffer:
                current_goal["description"] = "\n".join(goal_desc_buffer).strip()
                goal_desc_buffer = []
            if current_milestone and milestone_desc_buffer:
                current_milestone["description"] = "\n".join(milestone_desc_buffer).strip()
                milestone_desc_buffer = []
            
            current_goal = {
                "id": f"goal-{len(goals)}",
                "title": stripped[2:].strip(),
                "description": "",
                "status": "active",
            }
            goals.append(current_goal)
            current_milestone = None
            current_action = None
            i += 1
            # 读取目标描述（直到遇到下一个 # 或 ## 或 -）
            while i < len(lines):
                next_line = lines[i]
                next_stripped = next_line.strip()
                if not next_stripped:
                    i += 1
                    continue
                if next_stripped.startswith("#") or next_stripped.startswith("-"):
                    break
                goal_desc_buffer.append(next_line.rstrip())
                i += 1
            if goal_desc_buffer:
                current_goal["description"] = "\n".join(goal_desc_buffer).strip()
                goal_desc_buffer = []
            continue
        
        # 里程碑: ## 标题
        elif stripped.startswith("## "):
            # 保存之前的描述
            if current_milestone and milestone_desc_buffer:
                current_milestone["description"] = "\n".join(milestone_desc_buffer).strip()
                milestone_desc_buffer = []
            
            if current_goal:
                current_milestone = {
                    "id": f"m-{len(milestones)}",
                    "goal_id": current_goal["id"],
                    "title": stripped[3:].strip(),
                    "description": "",
                    "status": "todo",
                    "order": len(milestones),
                }
                milestones.append(current_milestone)
            current_action = None
            i += 1
            # 读取里程碑描述（直到遇到下一个 # 或 ## 或 -）
            while i < len(lines):
                next_line = lines[i]
                next_stripped = next_line.strip()
                if not next_stripped:
                    i += 1
                    continue
                if next_stripped.startswith("#") or next_stripped.startswith("-"):
                    break
                milestone_desc_buffer.append(next_line.rstrip())
                i += 1
            if milestone_desc_buffer:
                current_milestone["description"] = "\n".join(milestone_desc_buffer).strip()
                milestone_desc_buffer = []
            continue
        
        # 关键动作: - 标题
        elif stripped.startswith("- ") and current_milestone and not stripped.startswith("- [ ]"):
            # 保存之前的动作描述
            if current_action and action_desc_buffer:
                current_action["description"] = "\n".join(action_desc_buffer).strip()
                action_desc_buffer = []
            
            current_action = {
                "id": f"a-{len(actions)}",
                "milestone_id": current_milestone["id"],
                "title": stripped[2:].strip(),
                "description": "",
                "acceptance_criteria": [],
                "status": "todo",
            }
            actions.append(current_action)
            i += 1
            # 读取动作描述和验收标准
            while i < len(lines):
                next_line = lines[i]
                next_stripped = next_line.strip()
                if not next_stripped:
                    i += 1
                    continue
                # 验收标准: - [ ]
                if next_stripped.startswith("- [ ] "):
                    criterion = next_stripped[6:].strip()
                    current_action["acceptance_criteria"].append(criterion)
                    i += 1
                # 缩进的描述文本
                elif next_line.startswith("    "):
                    action_desc_buffer.append(next_line[4:].rstrip())
                    i += 1
                # 遇到下一个动作或里程碑或目标
                elif next_stripped.startswith("-") or next_stripped.startswith("#"):
                    break
                else:
                    break
            if action_desc_buffer:
                current_action["description"] = "\n".join(action_desc_buffer).strip()
                action_desc_buffer = []
            continue
        
        i += 1
    
    # 保存最后的描述
    if current_action and action_desc_buffer:
        current_action["description"] = "\n".join(action_desc_buffer).strip()
    
    return {
        "goals": goals,
        "milestones": milestones,
        "actions": actions,
    }


@app.post("/goal-management-v2/to-markdown")
async def goal_to_markdown(payload: dict[str, Any]) -> dict[str, Any]:
    """将目标数据转换为 Markdown"""
    data = payload.get("data", {})
    goals = data.get("goals", [])
    milestones = data.get("milestones", [])
    actions = data.get("actions", [])
    
    lines = []
    
    for goal in goals:
        lines.append(f"# {goal.get('title', '')}")
        if goal.get("description"):
            # 保留多行描述格式
            for desc_line in goal["description"].splitlines():
                lines.append(desc_line)
            lines.append("")
        
        # 找到该目标下的里程碑
        goal_milestones = [m for m in milestones if m.get("goal_id") == goal.get("id")]
        goal_milestones.sort(key=lambda x: x.get("order", 0))
        
        for milestone in goal_milestones:
            lines.append(f"## {milestone.get('title', '')}")
            if milestone.get("description"):
                # 保留多行描述格式
                for desc_line in milestone["description"].splitlines():
                    lines.append(desc_line)
                lines.append("")
            
            # 找到该里程碑下的关键动作
            ms_actions = [a for a in actions if a.get("milestone_id") == milestone.get("id")]
            for action in ms_actions:
                lines.append(f"- {action.get('title', '')}")
                if action.get("description"):
                    # 缩进保留多行描述
                    for desc_line in action["description"].splitlines():
                        lines.append(f"    {desc_line}")
                for criterion in action.get("acceptance_criteria", []):
                    lines.append(f"    - [ ] {criterion}")
                lines.append("")
        
        lines.append("")
    
    return {"markdown": "\n".join(lines)}


@app.get("/snapshot")
async def snapshot(project: str = Query(default=DEFAULT_PROJECT)) -> dict[str, Any]:
    runtime = _runtime_root(project)
    config = _project_config(project)
    meta = _project_meta(project)
    tasks_doc = _read_yaml(runtime / "tasks.yaml") or {"tasks": []}
    tasks = tasks_doc.get("tasks", [])
    task_map = {task.get("id"): task for task in tasks}

    runs = []
    for path in sorted((runtime / "runs").glob("*.json")):
        if path.name == "_coordinator.json":
            continue
        payload = _read_json(path)
        if not payload:
            continue
        task = task_map.get(payload.get("task_id"))
        task_status = task.get("status") if task else None
        run_status = payload.get("status")
        if task_status == "merged" and run_status != "in_progress":
            continue
        if task_status in {"blocked", "todo", "ready"} and run_status == "review":
            continue
        runs.append(payload)

    plans = []
    for path in sorted((runtime / "plans").glob("*.yaml")):
        plans.append({"name": path.name, "mtime": path.stat().st_mtime, "path": str(path)})

    dispatches = []
    for path in sorted((runtime / "dispatch").glob("*.md")):
        dispatches.append({"name": path.name, "mtime": path.stat().st_mtime, "path": str(path)})

    coordinator = _read_json(runtime / "runs" / "_coordinator.json")
    if coordinator and coordinator.get("status") == "in_progress" and not _pid_alive(coordinator.get("pid")):
        coordinator = {
            **coordinator,
            "status": "stale",
            "error": "Coordinator process is no longer running and no applied plan is visible.",
        }

    pipeline_state = _pipeline_state(tasks, coordinator)

    goal_management = _goal_management(project)
    
    # 兼容旧字段
    goals = goal_management.get("goals", [])
    milestones = goal_management.get("milestones", [])
    actions = goal_management.get("actions", [])
    
    current_goal_id = goal_management.get("current_goal_id", "")
    current_milestone_id = goal_management.get("current_milestone_id", "")
    
    current_goal = next((g for g in goals if g.get("id") == current_goal_id), goals[0] if goals else None)
    current_milestone = next((m for m in milestones if m.get("id") == current_milestone_id), None)

    return {
        "project": {
            "slug": project,
            "name": config.get("name", project),
            "repo_root": config.get("repo_root", ""),
            "runtime_root": str(runtime),
            "big_goal": current_goal.get("title", "") if current_goal else "",
            "small_goal": current_milestone.get("title", "") if current_milestone else "",
            "current_goal": current_goal.get("title", "") if current_goal else "",
            "current_phase": current_milestone.get("title", "") if current_milestone else "",
            "phase_outcome": current_milestone.get("description", "") if current_milestone else "",
            "current_gap": meta.get("current_gap", ""),
            "milestones": [m.get("title", "") for m in milestones],
            "success_criteria": [],
        },
        "goal_management": goal_management,
        "tasks": tasks,
        "status_counts": _status_counts(tasks),
        "parallelism": _parallelism(tasks),
        "pipeline_state": pipeline_state,
        "runs": runs,
        "events": _read_jsonl(runtime / "runs" / "events.jsonl")[-200:],
        "dispatches": dispatches,
        "plans": plans,
        "coordinator": coordinator,
        "git_status": _git_status(project),
        "worktrees": _git_worktrees(project),
        "board_markdown": (runtime / "board.md").read_text(encoding="utf-8") if (runtime / "board.md").exists() else "",
        "reviews_markdown": (runtime / "reviews.md").read_text(encoding="utf-8") if (runtime / "reviews.md").exists() else "",
        "agents": [],
    }


# ==================== V2 Objective/Session Routes ====================

from .routes_v2 import router as v2_router
app.include_router(v2_router)


