"""Paddock Admin Server — serves API + frontend static files."""
from __future__ import annotations

import importlib.resources
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from .agent_models import (
    Agent,
    DispatchMode,
    Worker,
    WorkerStrategy,
    check_agent_health,
    dispatch_task,
    get_health_logs,
    load_agents,
    load_workers,
    save_agents,
    save_workers,
    update_worker_strategy,
)
from .loop_config import (
    load_loop_config,
    reorder_loop_stages,
    save_loop_config,
    update_loop_stage,
)
from .routes_v2 import router as v2_router


def _find_frontend_dist() -> Path:
    """Locate the bundled frontend dist directory."""
    try:
        ref = importlib.resources.files("paddock") / "admin_frontend"
        with importlib.resources.as_file(ref) as p:
            if p.exists():
                return p
    except (TypeError, FileNotFoundError):
        pass
    # Fallback: source tree
    src = Path(__file__).resolve().parents[2] / "paddock" / "admin_frontend"
    if src.exists():
        return src
    raise FileNotFoundError(
        "Cannot locate admin frontend dist. "
        "Run 'npm run build' in admin/frontend/ first."
    )


def create_app() -> FastAPI:
    app = FastAPI(title="Paddock Admin", version="0.2.0")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # V2 API routes (objectives, sessions, projects, etc.)
    app.include_router(v2_router)

    # Agent / Worker / Loop API routes (inline)
    _register_agent_worker_routes(app)

    # Serve frontend — must be last so API routes take priority
    dist = _find_frontend_dist()
    app.mount("/assets", StaticFiles(directory=str(dist / "assets")), name="assets")

    @app.get("/", include_in_schema=False)
    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str = ""):
        """Serve the React SPA for all non-API routes."""
        index = dist / "index.html"
        return FileResponse(str(index))

    return app


def _register_agent_worker_routes(app: FastAPI) -> None:
    """Register agent/worker/loop routes directly on the app."""
    from typing import Any
    from fastapi import HTTPException, Query

    @app.get("/api/v2/agents")
    async def list_agents() -> dict[str, Any]:
        return {"agents": [a.to_dict() for a in load_agents()]}

    @app.post("/api/v2/agents")
    async def create_agent(payload: dict[str, Any]) -> dict[str, Any]:
        agent = Agent.from_dict(payload)
        agents = load_agents()
        agents.append(agent)
        save_agents(agents)
        return {"ok": True, "agent": agent.to_dict()}

    @app.put("/api/v2/agents/{agent_id}")
    async def update_agent(agent_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        agents = load_agents()
        for i, a in enumerate(agents):
            if a.id == agent_id:
                agents[i] = Agent.from_dict({**a.to_dict(), **payload})
                save_agents(agents)
                return {"ok": True, "agent": agents[i].to_dict()}
        raise HTTPException(status_code=404, detail="Agent not found")

    @app.delete("/api/v2/agents/{agent_id}")
    async def delete_agent(agent_id: str) -> dict[str, Any]:
        save_agents([a for a in load_agents() if a.id != agent_id])
        return {"ok": True}

    @app.post("/api/v2/agents/{agent_id}/check")
    async def check_agent(agent_id: str) -> dict[str, Any]:
        agent = next((a for a in load_agents() if a.id == agent_id), None)
        if not agent:
            raise HTTPException(status_code=404, detail="Agent not found")
        result = check_agent_health(agent)
        return {"ok": True, "result": {
            "agent_id": result.agent_id,
            "agent_name": result.agent_name,
            "status": result.status,
            "latency_ms": result.latency_ms,
            "version": result.stdout.strip()[:100] if result.stdout else "",
            "error": result.error,
        }}

    @app.get("/api/v2/agents/health-logs")
    async def list_health_logs(
        agent_id: str = Query(default=None),
        limit: int = Query(default=50, ge=1, le=200),
    ) -> dict[str, Any]:
        return {"logs": get_health_logs(agent_id=agent_id, limit=limit)}

    @app.get("/api/v2/workers")
    async def list_workers() -> dict[str, Any]:
        return {"workers": [w.to_dict() for w in load_workers()]}

    @app.post("/api/v2/workers")
    async def create_worker(payload: dict[str, Any]) -> dict[str, Any]:
        worker = Worker.from_dict(payload)
        workers = load_workers()
        workers.append(worker)
        save_workers(workers)
        return {"ok": True, "worker": worker.to_dict()}

    @app.put("/api/v2/workers/{worker_id}")
    async def update_worker(worker_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        workers = load_workers()
        for i, w in enumerate(workers):
            if w.id == worker_id:
                workers[i] = Worker.from_dict({**w.to_dict(), **payload})
                save_workers(workers)
                return {"ok": True, "worker": workers[i].to_dict()}
        raise HTTPException(status_code=404, detail="Worker not found")

    @app.put("/api/v2/workers/{worker_id}/strategy")
    async def update_worker_strategy_ep(worker_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        strategy = WorkerStrategy(
            mode=DispatchMode(payload.get("mode", "fixed")),
            fixed_agent=payload.get("fixed_agent", ""),
            agent_priority=payload.get("agent_priority", []),
            content_rules=payload.get("content_rules", []),
        )
        worker = update_worker_strategy(worker_id, strategy)
        if not worker:
            raise HTTPException(status_code=404, detail="Worker not found")
        return {"ok": True, "worker": worker.to_dict()}

    @app.get("/api/v2/loop")
    async def get_loop_config() -> dict[str, Any]:
        config = load_loop_config()
        return {
            "name": config.name,
            "description": config.description,
            "stages": [{"id": s.id, "name": s.name, "description": s.description,
                        "worker_id": s.worker_id, "enabled": s.enabled,
                        "auto_trigger": s.auto_trigger, "config": s.config}
                       for s in config.stages],
            "settings": config.settings,
        }

    @app.put("/api/v2/loop")
    async def update_loop(payload: dict[str, Any]) -> dict[str, Any]:
        config = load_loop_config()
        if "name" in payload:
            config.name = payload["name"]
        if "description" in payload:
            config.description = payload["description"]
        if "settings" in payload:
            config.settings = {**config.settings, **payload["settings"]}
        save_loop_config(config)
        return {"ok": True}

    @app.put("/api/v2/loop/stages/{stage_id}")
    async def update_stage(stage_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        stage = update_loop_stage(stage_id, payload)
        if not stage:
            raise HTTPException(status_code=404, detail="Stage not found")
        return {"ok": True, "stage": {"id": stage.id, "name": stage.name,
                                      "worker_id": stage.worker_id, "enabled": stage.enabled}}

    @app.post("/api/v2/loop/stages/reorder")
    async def reorder_stages(payload: dict[str, Any]) -> dict[str, Any]:
        reorder_loop_stages(payload.get("stage_ids", []))
        return {"ok": True}
