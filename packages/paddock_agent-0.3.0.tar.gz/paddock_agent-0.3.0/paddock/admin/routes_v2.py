"""
Paddock V2 API Routes — Objectives, Sessions, Flow Control.

These routes use the shared paddock.db module and add new V2 concepts
while keeping existing V1/V2 agent/worker/loop APIs intact.
"""
from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, HTTPException, Query

from paddock.db import PaddockDB
from paddock.config import DB_PATH

router = APIRouter(prefix="/api/v2", tags=["v2"])

# Shared DB instance
from typing import Optional
_db: Optional[PaddockDB] = None


def get_db() -> PaddockDB:
    global _db
    if _db is None:
        _db = PaddockDB(DB_PATH)
        _db.initialize()
    return _db


# ==================== Projects ====================

@router.get("/projects")
async def list_projects() -> dict[str, Any]:
    db = get_db()
    return {"projects": db.list_all_projects()}


@router.post("/projects")
async def create_project(payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    required = ["id", "name", "repo_root", "worktrees_root"]
    for field in required:
        if not payload.get(field):
            raise HTTPException(status_code=400, detail=f"{field} is required")
    db.upsert_project(payload)
    return {"ok": True, "project": db.get_project(payload["id"])}


@router.put("/projects/{project_id}")
async def update_project(project_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    if not db.get_project(project_id):
        raise HTTPException(status_code=404, detail="Project not found")
    payload["id"] = project_id
    db.upsert_project(payload)
    return {"ok": True, "project": db.get_project(project_id)}


@router.delete("/projects/{project_id}")
async def delete_project(project_id: str) -> dict[str, Any]:
    db = get_db()
    if not db.delete_project(project_id):
        raise HTTPException(status_code=404, detail="Project not found")
    return {"ok": True}


# ==================== Goals / Milestones / Phases ====================

@router.get("/projects/{project_id}/goals")
async def get_goals(project_id: str) -> dict[str, Any]:
    db = get_db()
    goal = db.get_active_goal(project_id)
    milestone = db.get_active_milestone(project_id)
    phase = db.get_active_phase(project_id)
    return {
        "goal": goal,
        "milestone": milestone,
        "phase": phase,
        "all_goals": db.list_goals(project_id),
        "all_milestones": db.list_milestones(project_id),
        "all_phases": db.list_phases(project_id),
    }


@router.get("/projects/{project_id}/phase-checks")
async def get_phase_checks(project_id: str) -> dict[str, Any]:
    """Get phase checks for the active phase."""
    db = get_db()
    phase = db.get_active_phase(project_id)
    if not phase:
        return {"phase_id": None, "checks": []}
    checks = db.list_phase_checks(phase["id"], project_id)
    passed = sum(1 for c in checks if c["status"] == "passed")
    return {
        "phase_id": phase["id"],
        "phase_title": phase["title"],
        "checks": checks,
        "summary": {"passed": passed, "total": len(checks)},
    }


@router.put("/projects/{project_id}/goals")
async def update_goals(project_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    if payload.get("goal"):
        g = payload["goal"]
        g["project_id"] = project_id
        db.upsert_goal(g)
    if payload.get("milestone"):
        m = payload["milestone"]
        m["project_id"] = project_id
        db.upsert_milestone(m)
    if payload.get("phase"):
        p = payload["phase"]
        p["project_id"] = project_id
        db.upsert_phase(p)
    return {"ok": True}


# ==================== Goal / Milestone / Phase status ====================

@router.put("/goals/goal/{goal_id}/status")
async def update_goal_status(goal_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    goals = [g for p in db.list_all_projects() for g in db.list_goals(p["id"]) if g["id"] == goal_id]
    if not goals:
        raise HTTPException(status_code=404, detail="Goal not found")
    g = goals[0]
    db.upsert_goal({**g, "status": payload.get("status", g["status"])})
    return {"ok": True}


@router.put("/goals/milestone/{milestone_id}/status")
async def update_milestone_status(milestone_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    # Find milestone across all projects
    for p in db.list_all_projects():
        milestones = db.list_milestones(p["id"])
        for m in milestones:
            if m["id"] == milestone_id:
                db.upsert_milestone({**m, "status": payload.get("status", m["status"])})
                return {"ok": True}
    raise HTTPException(status_code=404, detail="Milestone not found")


@router.put("/goals/phase/{phase_id}/status")
async def update_phase_status(phase_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    for p in db.list_all_projects():
        phases = db.list_phases(p["id"])
        for ph in phases:
            if ph["id"] == phase_id:
                db.upsert_phase({**ph, "status": payload.get("status", ph["status"])})
                return {"ok": True}
    raise HTTPException(status_code=404, detail="Phase not found")


# ==================== Objectives ====================

JSON_OBJECTIVE_FIELDS = ("acceptance_criteria", "path_scope", "depends_on", "context_refs", "session_budget")

def _parse_objective_json_fields(obj: dict[str, Any]) -> None:
    for field in JSON_OBJECTIVE_FIELDS:
        if obj.get(field) and isinstance(obj[field], str):
            try:
                obj[field] = json.loads(obj[field])
            except (json.JSONDecodeError, TypeError):
                pass

@router.get("/projects/{project_id}/objectives")
async def list_objectives(
    project_id: str,
    status: str = Query(default=None, description="Comma-separated status filter"),
) -> dict[str, Any]:
    db = get_db()
    status_list = status.split(",") if status else None
    objectives = db.list_objectives(project_id, status=status_list)

    # Parse JSON fields for API response
    for obj in objectives:
        _parse_objective_json_fields(obj)

    # Compute summary counts
    all_objs = db.list_objectives(project_id)
    summary = {}
    for o in all_objs:
        s = o.get("status", "unknown")
        summary[s] = summary.get(s, 0) + 1

    return {"objectives": objectives, "summary": summary}


@router.post("/projects/{project_id}/objectives")
async def create_objective(project_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    if not payload.get("id"):
        raise HTTPException(status_code=400, detail="id is required")
    if not payload.get("title"):
        raise HTTPException(status_code=400, detail="title is required")

    payload["project_id"] = project_id
    payload.setdefault("description", "")
    payload.setdefault("acceptance_criteria", [])

    if db.get_objective(payload["id"]):
        raise HTTPException(status_code=409, detail=f"Objective {payload['id']} already exists")

    db.create_objective(payload)
    return {"ok": True, "objective": db.get_objective(payload["id"])}


@router.put("/objectives/{objective_id}")
async def update_objective(objective_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    if not db.get_objective(objective_id):
        raise HTTPException(status_code=404, detail="Objective not found")
    db.update_objective(objective_id, payload)
    return {"ok": True, "objective": db.get_objective(objective_id)}


@router.delete("/objectives/{objective_id}")
async def delete_objective(objective_id: str) -> dict[str, Any]:
    db = get_db()
    if not db.delete_objective(objective_id):
        raise HTTPException(status_code=404, detail="Objective not found")
    return {"ok": True}


@router.post("/objectives/{objective_id}/override")
async def override_objective(objective_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Human override: force-approve all rejected checkpoints and mark objective done."""
    db = get_db()
    obj = db.get_objective(objective_id)
    if not obj:
        raise HTTPException(status_code=404, detail="Objective not found")

    # Approve all pending/rejected checkpoints
    from paddock.db import PaddockDB as _DB
    sessions = db.get_sessions_by_status(obj["project_id"], "completed")
    obj_sessions = [s for s in sessions if s["objective_id"] == objective_id]
    for s in obj_sessions:
        for cp in db.list_checkpoints(s["id"]):
            if cp["review_status"] != "approved":
                db.update_checkpoint_review(cp["id"], "approved", f"Human override: {payload.get('note', 'approved by human')}")

    db.update_objective(objective_id, {"status": "done", "review_feedback": None})
    db.emit_event(obj["project_id"], "objective_done", {
        "objective_id": objective_id,
        "reason": "human_override",
    })
    return {"ok": True}


@router.post("/objectives/{objective_id}/retry")
async def retry_objective(objective_id: str, payload: dict[str, Any] = {}) -> dict[str, Any]:
    """Human retry: reset objective to ready with optional custom prompt injection."""
    db = get_db()
    obj = db.get_objective(objective_id)
    if not obj:
        raise HTTPException(status_code=404, detail="Objective not found")

    human_prompt = payload.get("human_prompt", "")
    db.update_objective(objective_id, {
        "status": "ready",
        "branch": None,
        "worktree": None,
        "retry_count": int(obj.get("retry_count") or 0),  # keep count for tracking
        "human_prompt": human_prompt or None,
        "review_feedback": obj.get("review_feedback"),
    })
    db.emit_event(obj["project_id"], "objective_retry", {
        "objective_id": objective_id,
        "reason": "human_retry",
        "human_prompt": human_prompt,
    })
    return {"ok": True}


@router.post("/objectives/{objective_id}/skip")
async def skip_objective(objective_id: str, payload: dict[str, Any] = {}) -> dict[str, Any]:
    """Human skip: mark objective as failed and move on."""
    db = get_db()
    obj = db.get_objective(objective_id)
    if not obj:
        raise HTTPException(status_code=404, detail="Objective not found")

    db.update_objective(objective_id, {
        "status": "failed",
        "review_feedback": payload.get("reason", "Skipped by human"),
    })
    db.emit_event(obj["project_id"], "objective_failed", {
        "objective_id": objective_id,
        "reason": payload.get("reason", "skipped_by_human"),
    })
    return {"ok": True}


# ==================== Sessions ====================

@router.get("/projects/{project_id}/sessions")
async def list_sessions(
    project_id: str,
    limit: int = Query(default=50, ge=1, le=200),
) -> dict[str, Any]:
    db = get_db()
    sessions = db.list_sessions(project_id, limit=limit)
    active = db.get_active_sessions(project_id)

    for s in sessions:
        if s.get("budget") and isinstance(s["budget"], str):
            try:
                s["budget"] = json.loads(s["budget"])
            except (json.JSONDecodeError, TypeError):
                pass

    return {
        "sessions": sessions,
        "active_count": len(active),
    }


@router.get("/sessions/{session_id}")
async def get_session(session_id: int) -> dict[str, Any]:
    db = get_db()
    session = db.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    checkpoints = db.list_checkpoints(session_id)
    for cp in checkpoints:
        if cp.get("files_changed") and isinstance(cp["files_changed"], str):
            try:
                cp["files_changed"] = json.loads(cp["files_changed"])
            except (json.JSONDecodeError, TypeError):
                pass

    if session.get("budget") and isinstance(session["budget"], str):
        try:
            session["budget"] = json.loads(session["budget"])
        except (json.JSONDecodeError, TypeError):
            pass

    return {"session": session, "checkpoints": checkpoints}


@router.get("/sessions/{session_id}/log")
async def get_session_log(
    session_id: int,
    tail: int = Query(default=200, description="Number of lines from end"),
) -> dict[str, Any]:
    db = get_db()
    session = db.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    log_file = session.get("log_file")
    if not log_file or not Path(log_file).exists():
        return {"log": "", "lines": 0}

    lines = Path(log_file).read_text(encoding="utf-8", errors="replace").splitlines()
    tail_lines = lines[-tail:] if len(lines) > tail else lines
    return {"log": "\n".join(tail_lines), "lines": len(lines)}


@router.post("/sessions/{session_id}/cancel")
async def cancel_session(session_id: int) -> dict[str, Any]:
    db = get_db()
    session = db.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    if session["status"] != "running":
        raise HTTPException(status_code=400, detail="Session is not running")

    import os
    pid = session.get("pid")
    if pid:
        try:
            os.kill(int(pid), 15)  # SIGTERM
        except (ProcessLookupError, PermissionError):
            pass

    from datetime import datetime, timezone
    db.update_session(session_id, {
        "status": "cancelled",
        "finished_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
    })
    return {"ok": True}


# ==================== Flow Config ====================

@router.get("/projects/{project_id}/flow-config")
async def get_flow_config(project_id: str) -> dict[str, Any]:
    db = get_db()
    project = db.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    defaults = json.loads(project.get("session_defaults") or "{}")
    return {
        "scope_level": defaults.get("scope_level", "medium"),
        "max_commits_per_session": defaults.get("max_commits_per_session", 5),
        "max_minutes_per_session": defaults.get("max_minutes_per_session", 30),
        "max_parallel_sessions": project.get("max_parallel_sessions", 2),
        "planner_agent": defaults.get("planner_agent", ""),
    }


@router.put("/projects/{project_id}/flow-config")
async def update_flow_config(project_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    project = db.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    session_defaults = {
        "scope_level": payload.get("scope_level", "medium"),
        "max_commits_per_session": payload.get("max_commits_per_session", 5),
        "max_minutes_per_session": payload.get("max_minutes_per_session", 30),
    }

    update = {"id": project_id, "name": project["name"],
              "repo_root": project["repo_root"], "worktrees_root": project["worktrees_root"],
              "session_defaults": session_defaults}

    if "max_parallel_sessions" in payload:
        update["max_parallel_sessions"] = payload["max_parallel_sessions"]

    db.upsert_project(update)
    return {"ok": True}


# ==================== Events ====================

@router.get("/projects/{project_id}/events")
async def list_events(
    project_id: str,
    since: str = Query(default=None),
    type: str = Query(default=None),
    limit: int = Query(default=200, ge=1, le=1000),
) -> dict[str, Any]:
    db = get_db()
    events = db.list_events(project_id, since=since, event_type=type, limit=limit)
    for e in events:
        if e.get("payload") and isinstance(e["payload"], str):
            try:
                e["payload"] = json.loads(e["payload"])
            except (json.JSONDecodeError, TypeError):
                pass
    return {"events": events}


# ==================== Supervisor ====================

_supervisor_process: Optional[Any] = None

@router.get("/supervisor/status")
async def supervisor_status() -> dict[str, Any]:
    """Check if supervisor is running."""
    global _supervisor_process
    import os, signal as _signal
    pid = None
    alive = False
    if _supervisor_process is not None:
        pid = _supervisor_process.pid
        try:
            os.kill(pid, 0)
            alive = True
        except (ProcessLookupError, OSError):
            alive = False
    return {"running": alive, "pid": pid}


@router.post("/supervisor/start")
async def supervisor_start(payload: dict[str, Any] = {}) -> dict[str, Any]:
    """Start supervisor in background."""
    global _supervisor_process
    import os, signal as _signal

    # Check if already running
    if _supervisor_process is not None:
        try:
            os.kill(_supervisor_process.pid, 0)
            return {"ok": True, "already_running": True, "pid": _supervisor_process.pid}
        except (ProcessLookupError, OSError):
            _supervisor_process = None

    paddock_root = Path(__file__).resolve().parents[3]
    supervisor_script = paddock_root / "scripts" / "supervisor_v2.py"
    if not supervisor_script.exists():
        raise HTTPException(status_code=500, detail="supervisor_v2.py not found")

    project = payload.get("project")
    poll = int(payload.get("poll_seconds", 15))
    duration = int(payload.get("duration_minutes", 480))
    max_parallel = payload.get("max_parallel")

    cmd = [sys.executable, str(supervisor_script),
           "--poll-seconds", str(poll),
           "--duration-minutes", str(duration)]
    if project:
        cmd += ["--project", project]
    if max_parallel is not None:
        cmd += ["--max-parallel", str(int(max_parallel))]

    log_dir = paddock_root / "runtime" / "supervisor"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "supervisor.log"

    import subprocess as _sp
    with open(log_file, "a") as lf:
        _supervisor_process = _sp.Popen(
            cmd, cwd=str(paddock_root),
            stdout=lf, stderr=_sp.STDOUT,
        )

    return {"ok": True, "pid": _supervisor_process.pid, "log_file": str(log_file)}


@router.post("/supervisor/stop")
async def supervisor_stop() -> dict[str, Any]:
    """Stop the supervisor."""
    global _supervisor_process
    import os, signal as _signal
    if _supervisor_process is None:
        return {"ok": True, "was_running": False}
    try:
        os.kill(_supervisor_process.pid, _signal.SIGTERM)
        _supervisor_process = None
        return {"ok": True, "was_running": True}
    except (ProcessLookupError, OSError):
        _supervisor_process = None
        return {"ok": True, "was_running": False}


@router.get("/supervisor/log")
async def supervisor_log(tail: int = Query(default=100, ge=1, le=500)) -> dict[str, Any]:
    """Read supervisor log."""
    paddock_root = Path(__file__).resolve().parents[3]
    log_file = paddock_root / "runtime" / "supervisor" / "supervisor.log"
    if not log_file.exists():
        return {"log": ""}
    lines = log_file.read_text(encoding="utf-8", errors="replace").splitlines()
    return {"log": "\n".join(lines[-tail:])}


# ==================== Planner ====================

@router.get("/projects/{project_id}/planner-runs")
async def list_planner_runs(
    project_id: str,
    limit: int = Query(default=20, ge=1, le=100),
) -> dict[str, Any]:
    db = get_db()
    return {"runs": db.list_planner_runs(project_id, limit=limit)}


@router.get("/planner/log")
async def get_planner_log(
    project: str = Query(...),
    tail: int = Query(default=200, ge=1, le=1000),
) -> dict[str, Any]:
    """Read the latest planner log file for a project."""
    db = get_db()
    latest = db.get_latest_planner_run(project)
    if not latest or not latest.get("log_file"):
        return {"log": "", "status": None}
    log_path = Path(latest["log_file"])
    if not log_path.exists():
        return {"log": "", "status": latest.get("status")}
    lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
    return {
        "log": "\n".join(lines[-tail:]),
        "status": latest.get("status"),
        "run_id": latest.get("id"),
        "pid": latest.get("pid"),
    }


@router.post("/projects/{project_id}/planner/trigger")
async def trigger_planner(project_id: str, payload: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Manually trigger the planner for a project.
    Optional body: { "agent_id": "claude" }
    """
    import subprocess
    db = get_db()
    project = db.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    scripts_dir = Path(__file__).resolve().parents[3] / "scripts"
    planner_script = scripts_dir / "planner.py"
    if not planner_script.exists():
        raise HTTPException(status_code=500, detail="Planner script not found")

    paddock_root = scripts_dir.parent

    # Resolve agent: body > project.planner_agent > first enabled
    agent_id = (payload or {}).get("agent_id") or project.get("planner_agent")

    # Save planner_agent preference inside session_defaults JSON
    if agent_id:
        import json as _json
        defaults = _json.loads(project.get("session_defaults") or "{}")
        if defaults.get("planner_agent") != agent_id:
            defaults["planner_agent"] = agent_id
            db.upsert_project({**project, "session_defaults": defaults})

    run_id = db.create_planner_run({
        "project_id": project_id,
        "status": "running",
        "pid": 0,
    })

    log_file = paddock_root / "runtime" / "projects" / project_id / "logs" / "planner.log"
    log_file.parent.mkdir(parents=True, exist_ok=True)

    cmd = [sys.executable, str(planner_script), "--project", project_id]
    if agent_id:
        cmd += ["--agent", agent_id]

    lf = open(log_file, "w")
    process = subprocess.Popen(
        cmd,
        cwd=str(paddock_root),
        stdout=lf,
        stderr=subprocess.STDOUT,
    )
    lf.close()  # Child process inherits the fd; safe to close parent's copy

    db.update_planner_run(run_id, {"pid": process.pid, "log_file": str(log_file)})

    return {"ok": True, "planner_run_id": run_id, "pid": process.pid, "agent_id": agent_id}


# ==================== Dashboard Snapshot (V2) ====================

@router.get("/projects/{project_id}/snapshot")
async def project_snapshot(project_id: str) -> dict[str, Any]:
    """Full project state snapshot for the dashboard."""
    db = get_db()
    project = db.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    goal = db.get_active_goal(project_id)
    milestone = db.get_active_milestone(project_id)
    phase = db.get_active_phase(project_id)

    all_objectives = db.list_objectives(project_id)
    for obj in all_objectives:
        _parse_objective_json_fields(obj)
    obj_summary = {}
    for o in all_objectives:
        s = o.get("status", "unknown")
        obj_summary[s] = obj_summary.get(s, 0) + 1

    active_sessions = db.get_active_sessions(project_id)
    recent_sessions = db.list_sessions(project_id, limit=10)

    defaults = json.loads(project.get("session_defaults") or "{}")

    # Pipeline state
    if active_sessions or obj_summary.get("active"):
        pipeline_state = "active"
    elif obj_summary.get("ready"):
        pipeline_state = "queued"
    elif obj_summary.get("todo"):
        pipeline_state = "waiting"
    else:
        pipeline_state = "idle"

    events = db.list_events(project_id, limit=50)
    for e in events:
        if e.get("payload") and isinstance(e["payload"], str):
            try:
                e["payload"] = json.loads(e["payload"])
            except (json.JSONDecodeError, TypeError):
                pass

    return {
        "project": {
            "id": project_id,
            "name": project.get("name", project_id),
            "repo_root": project.get("repo_root", ""),
            "worktrees_root": project.get("worktrees_root", ""),
        },
        "goal": goal,
        "milestone": milestone,
        "phase": phase,
        "flow_config": {
            "scope_level": defaults.get("scope_level", "medium"),
            "max_commits_per_session": defaults.get("max_commits_per_session", 5),
            "max_minutes_per_session": defaults.get("max_minutes_per_session", 30),
            "max_parallel_sessions": project.get("max_parallel_sessions", 2),
        },
        "objectives": {
            "summary": obj_summary,
            "items": all_objectives,
        },
        "sessions": {
            "active": active_sessions,
            "recent": recent_sessions,
        },
        "pipeline_state": pipeline_state,
        "events": events,
    }


# ==================== Agents ====================

@router.get("/agents")
async def v2_list_agents(enabled_only: bool = False) -> dict[str, Any]:
    db = get_db()
    return {"agents": db.list_agents(enabled_only=enabled_only)}


@router.post("/agents")
async def v2_create_agent(payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    agent_id = payload.get("id")
    if not agent_id:
        raise HTTPException(status_code=400, detail="Agent ID required")
    if db.get_agent(agent_id):
        raise HTTPException(status_code=400, detail=f"Agent {agent_id} already exists")
    db.upsert_agent(payload)
    return {"ok": True, "agent": db.get_agent(agent_id)}


@router.get("/agents/{agent_id}")
async def v2_get_agent(agent_id: str) -> dict[str, Any]:
    db = get_db()
    agent = db.get_agent(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent": agent}


@router.put("/agents/{agent_id}")
async def v2_update_agent(agent_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    existing = db.get_agent(agent_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Agent not found")
    payload["id"] = agent_id
    db.upsert_agent({**existing, **payload})
    return {"ok": True, "agent": db.get_agent(agent_id)}


@router.delete("/agents/{agent_id}")
async def v2_delete_agent(agent_id: str) -> dict[str, Any]:
    db = get_db()
    if not db.delete_agent(agent_id):
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"ok": True}


async def _run_agent_health_check_async(agent: dict[str, Any]) -> dict[str, Any]:
    """真实健康检查（异步）：发送最小 prompt，验证 API 连通性。"""
    import asyncio, tempfile, os, time
    sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
    from paddock.config import build_agent_env
    from paddock.utils import render_agent_command

    start = time.time()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False, encoding="utf-8") as f:
        f.write("Reply with exactly one word: OK")
        prompt_file = f.name

    try:
        # Build a fast probe command — override slow models with haiku for CLI-based agents
        cli = agent["cli_command"].split()[0]  # e.g. "claude", "mc", "kimi", "codex"
        probe_template = agent["command_template"]

        # codex: real API call (no model override needed, uses default)
        # kimi: real API call with default model

        # For claude/mc-code: override model with haiku (fastest)
        if cli in ("claude", "mc") and "--model" in probe_template:
            import re as _re
            probe_template = _re.sub(r"--model\s+\S+", "--model claude-haiku-4-5-20251001", probe_template)
        elif cli in ("claude", "mc") and "--model" not in probe_template:
            probe_template = probe_template.replace("-p ", "--model claude-haiku-4-5-20251001 -p ")

        # For kimi: ensure --print mode
        if cli == "kimi" and "--print" not in probe_template:
            probe_template = probe_template.replace("kimi ", "kimi --print --output-format text --final-message-only ")

        cmd = render_agent_command(probe_template, prompt_file)
        use_shell = isinstance(cmd, str)
        env = build_agent_env(agent)

        if use_shell:
            proc = await asyncio.create_subprocess_shell(
                cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, env=env,
            )
        else:
            proc = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, env=env,
            )

        try:
            stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=45)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.communicate()
            return {"status": "error", "message": "timeout (45s)", "latency_ms": (time.time() - start) * 1000}

        latency = (time.time() - start) * 1000
        output = (stdout_b or b"").decode("utf-8", errors="replace").strip()
        err = (stderr_b or b"").decode("utf-8", errors="replace").strip()

        if proc.returncode != 0:
            return {"status": "error", "message": (err or output)[:200], "latency_ms": latency}
        if not output:
            return {"status": "error", "message": "no output", "latency_ms": latency}

        lower = output.lower()
        for pat in ["authorization failed", "authentication", "invalid", "401", "403",
                    "api error", "unable to connect", "econnreset", "failed to"]:
            if pat in lower:
                return {"status": "error", "message": output[:200], "latency_ms": latency}

        return {"status": "ok", "message": output[:100], "latency_ms": latency}
    except Exception as e:
        return {"status": "error", "message": str(e)[:200], "latency_ms": (time.time() - start) * 1000}
    finally:
        try:
            os.unlink(prompt_file)
        except OSError:
            pass


@router.post("/agents/health")
async def v2_check_all_agents() -> dict[str, Any]:
    """真实健康检查：对每个 enabled agent 并发发送最小 prompt，验证 API 连通性。"""
    import asyncio
    db = get_db()
    agents = db.list_agents(enabled_only=True)

    async def check_one(agent: dict[str, Any]) -> dict[str, Any]:
        health = await _run_agent_health_check_async(agent)
        db.add_health_log({
            "agent_id": agent["id"], "agent_name": agent["name"],
            "command": agent["command_template"][:100],
            "stdout": health["message"] if health["status"] == "ok" else "",
            "stderr": health["message"] if health["status"] != "ok" else "",
            "exit_code": 0 if health["status"] == "ok" else 1,
            "latency_ms": health["latency_ms"], "status": health["status"],
            "error": "" if health["status"] == "ok" else health["message"],
        })
        return {"config": agent, "health": {**health, "version": ""}}

    results = await asyncio.gather(*[check_one(a) for a in agents])
    return {"agents": list(results)}


@router.post("/agents/{agent_id}/check")
async def v2_check_agent(agent_id: str) -> dict[str, Any]:
    db = get_db()
    agent = db.get_agent(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    health = await _run_agent_health_check_async(agent)
    return {"ok": True, "result": {"agent_id": agent_id, "agent_name": agent["name"], **health}}


@router.get("/agents/health-logs")
async def v2_list_health_logs(
    agent_id: str = Query(default=None),
    limit: int = Query(default=50, ge=1, le=200),
) -> dict[str, Any]:
    db = get_db()
    return {"logs": db.get_health_logs(agent_id=agent_id, limit=limit)}


@router.delete("/agents/health-logs")
async def v2_clear_health_logs() -> dict[str, Any]:
    db = get_db()
    db.clear_health_logs()
    return {"ok": True}


# ==================== Workers ====================

def _enrich_worker(w: dict[str, Any]) -> dict[str, Any]:
    """Convert flat DB columns into nested strategy object for frontend."""
    if w and "strategy" not in w:
        w["strategy"] = {
            "mode": w.get("strategy_mode", "fixed"),
            "fixed_agent": w.get("strategy_fixed_agent", ""),
            "agent_priority": json.loads(w["strategy_agent_priority"]) if w.get("strategy_agent_priority") else [],
            "content_rules": json.loads(w["strategy_content_rules"]) if w.get("strategy_content_rules") else [],
        }
    return w


@router.get("/workers")
async def v2_list_workers() -> dict[str, Any]:
    db = get_db()
    return {"workers": [_enrich_worker(w) for w in db.list_workers()]}


@router.post("/workers")
async def v2_create_worker(payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    worker_id = payload.get("id")
    if not worker_id:
        raise HTTPException(status_code=400, detail="Worker ID required")
    if db.get_worker(worker_id):
        raise HTTPException(status_code=400, detail=f"Worker {worker_id} already exists")
    db.upsert_worker(payload)
    return {"ok": True, "worker": db.get_worker(worker_id)}


@router.put("/workers/{worker_id}")
async def v2_update_worker(worker_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    existing = db.get_worker(worker_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Worker not found")
    payload["id"] = worker_id
    db.upsert_worker({**existing, **payload})
    return {"ok": True, "worker": db.get_worker(worker_id)}


@router.delete("/workers/{worker_id}")
async def v2_delete_worker(worker_id: str) -> dict[str, Any]:
    db = get_db()
    if not db.delete_worker(worker_id):
        raise HTTPException(status_code=404, detail="Worker not found")
    return {"ok": True}


@router.put("/workers/{worker_id}/strategy")
async def v2_update_worker_strategy(worker_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    worker = db.get_worker(worker_id)
    if not worker:
        raise HTTPException(status_code=404, detail="Worker not found")

    strategy = {
        "mode": payload.get("mode", "fixed"),
        "fixed_agent": payload.get("fixed_agent", worker.get("strategy_fixed_agent", "")),
        "agent_priority": payload.get("agent_priority", []),
        "content_rules": payload.get("content_rules", []),
    }
    worker["strategy"] = strategy
    db.upsert_worker(worker)
    return {"ok": True, "worker": _enrich_worker(db.get_worker(worker_id))}


# ==================== Loop Stages ====================

@router.get("/loop")
async def v2_list_loop_stages() -> dict[str, Any]:
    db = get_db()
    return {"stages": db.load_loop_stages()}


@router.put("/loop/stages/{stage_id}")
async def v2_update_loop_stage(stage_id: str, payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    stage = {
        "id": stage_id,
        "name": payload.get("name", ""),
        "description": payload.get("description", ""),
        "worker_id": payload.get("worker_id", ""),
        "enabled": payload.get("enabled", True),
        "sort_order": payload.get("sort_order", 0),
        "config": payload.get("config", {}),
    }
    db.save_loop_stage(stage)
    return {"ok": True, "stage": stage}


@router.post("/loop/stages")
async def v2_add_loop_stage(payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    import uuid
    stage = {
        "id": payload.get("id", str(uuid.uuid4())),
        "name": payload.get("name", ""),
        "description": payload.get("description", ""),
        "worker_id": payload.get("worker_id", ""),
        "enabled": payload.get("enabled", True),
        "sort_order": payload.get("sort_order", 999),
        "config": payload.get("config", {}),
    }
    db.save_loop_stage(stage)
    return {"ok": True, "stage": stage}


@router.delete("/loop/stages/{stage_id}")
async def v2_delete_loop_stage(stage_id: str) -> dict[str, Any]:
    db = get_db()
    if not db.delete_loop_stage(stage_id):
        raise HTTPException(status_code=404, detail="Stage not found")
    return {"ok": True}


@router.post("/loop/stages/reorder")
async def v2_reorder_loop_stages(payload: dict[str, Any]) -> dict[str, Any]:
    db = get_db()
    db.reorder_loop_stages(payload.get("stage_ids", []))
    return {"ok": True, "stages": db.load_loop_stages()}


@router.post("/loop/stages/{stage_id}/toggle")
async def v2_toggle_loop_stage(stage_id: str, payload: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    db = get_db()
    stages = db.load_loop_stages()
    stage = next((s for s in stages if s["id"] == stage_id), None)
    if not stage:
        raise HTTPException(status_code=404, detail="Stage not found")
    enabled = payload.get("enabled") if payload else None
    if enabled is None:
        enabled = not stage.get("enabled", True)
    stage["enabled"] = enabled
    db.save_loop_stage(stage)
    return {"ok": True, "stage": stage}
