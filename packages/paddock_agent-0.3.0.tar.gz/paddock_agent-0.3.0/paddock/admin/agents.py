"""
Agent 接口层抽象 - 支持 Claude、Codex、Kimi 等多种 agent 系统
"""
from __future__ import annotations

import json
import os
import subprocess
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

import yaml

AGENTS_CONFIG_PATH = Path(__file__).resolve().parents[3] / "runtime" / "agents.yaml"


class AgentType(str, Enum):
    CLAUDE = "claude"
    CODEX = "codex"
    KIMI = "kimi"


class AgentStatus(str, Enum):
    OK = "ok"
    ERROR = "error"
    UNKNOWN = "unknown"
    NOT_CONFIGURED = "not_configured"


@dataclass
class AgentConfig:
    """Agent 配置"""
    id: str
    name: str
    type: AgentType
    enabled: bool = True
    # 命令行参数模板，支持变量替换
    command_template: str = ""
    # 环境变量
    env: dict[str, str] = field(default_factory=dict)
    # 额外参数
    extra_args: dict[str, Any] = field(default_factory=dict)
    # 描述
    description: str = ""
    # 图标/颜色标识
    icon: str = ""
    color: str = "#666"

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type.value,
            "enabled": self.enabled,
            "command_template": self.command_template,
            "env": self.env,
            "extra_args": self.extra_args,
            "description": self.description,
            "icon": self.icon,
            "color": self.color,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentConfig:
        return cls(
            id=data["id"],
            name=data.get("name", data["id"]),
            type=AgentType(data.get("type", "claude")),
            enabled=data.get("enabled", True),
            command_template=data.get("command_template", ""),
            env=data.get("env", {}),
            extra_args=data.get("extra_args", {}),
            description=data.get("description", ""),
            icon=data.get("icon", ""),
            color=data.get("color", "#666"),
        )


@dataclass
class HealthCheckResult:
    """健康检查结果"""
    status: AgentStatus
    message: str = ""
    latency_ms: float = 0.0
    version: str = ""


class AgentInterface(ABC):
    """Agent 接口抽象基类"""

    def __init__(self, config: AgentConfig):
        self.config = config

    @abstractmethod
    def health_check(self) -> HealthCheckResult:
        """检查 agent 可用性"""
        pass

    @abstractmethod
    def build_command(
        self,
        prompt_file: Path,
        worktree: Path | None = None,
        extra_vars: dict[str, str] | None = None,
    ) -> list[str]:
        """构建启动命令行参数"""
        pass

    @abstractmethod
    def dispatch(
        self,
        prompt_file: Path,
        worktree: Path | None = None,
        extra_vars: dict[str, str] | None = None,
    ) -> subprocess.Popen:
        """派发任务到 agent"""
        pass

    def _substitute_vars(self, template: str, vars_dict: dict[str, str]) -> str:
        """变量替换"""
        result = template
        for key, value in vars_dict.items():
            result = result.replace(f"{{{key}}}", value)
        return result


class ClaudeInterface(AgentInterface):
    """Claude Code CLI 接口"""

    def health_check(self) -> HealthCheckResult:
        import time
        from dispatch_strategy import HealthCheckLog, log_health_check
        
        start = time.time()
        command = "claude --version"
        stdout = ""
        stderr = ""
        exit_code = -1
        error_msg = ""
        
        try:
            result = subprocess.run(
                ["claude", "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            latency = (time.time() - start) * 1000
            exit_code = result.returncode
            stdout = result.stdout
            stderr = result.stderr
            
            # 记录日志
            log = HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout[:1000],  # 限制长度
                stderr=stderr[:1000],
                exit_code=exit_code,
                latency_ms=latency,
                status="ok" if result.returncode == 0 else "error",
                error=stderr if result.returncode != 0 else "",
            )
            log_health_check(log)
            
            if result.returncode == 0:
                version = result.stdout.strip().split()[-1] if result.stdout else ""
                return HealthCheckResult(
                    status=AgentStatus.OK,
                    message="Claude CLI 可用",
                    latency_ms=latency,
                    version=version,
                )
            return HealthCheckResult(
                status=AgentStatus.ERROR,
                message=f"Claude CLI 返回错误: {result.stderr}",
                latency_ms=latency,
            )
        except FileNotFoundError:
            latency = (time.time() - start) * 1000
            error_msg = "Claude CLI 未安装 (npm install -g @anthropic-ai/claude-code)"
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                latency_ms=latency,
                status="not_configured",
                error=error_msg,
            ))
            return HealthCheckResult(
                status=AgentStatus.NOT_CONFIGURED,
                message=error_msg,
            )
        except subprocess.TimeoutExpired:
            latency = (time.time() - start) * 1000
            error_msg = "健康检查超时"
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                latency_ms=10000,
                status="error",
                error=error_msg,
            ))
            return HealthCheckResult(
                status=AgentStatus.ERROR,
                message=error_msg,
                latency_ms=10000,
            )
        except Exception as e:
            latency = (time.time() - start) * 1000
            error_msg = f"检查失败: {e}"
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout,
                stderr=stderr,
                exit_code=exit_code,
                latency_ms=latency,
                status="error",
                error=error_msg,
            ))
            return HealthCheckResult(
                status=AgentStatus.ERROR,
                message=error_msg,
            )

    def build_command(
        self,
        prompt_file: Path,
        worktree: Path | None = None,
        extra_vars: dict[str, str] | None = None,
    ) -> list[str]:
        vars_dict = {
            "prompt_file": str(prompt_file),
            "worktree": str(worktree) if worktree else ".",
            **(extra_vars or {}),
        }
        
        if self.config.command_template:
            cmd_str = self._substitute_vars(self.config.command_template, vars_dict)
            return cmd_str.split()
        
        # 默认命令
        cmd = ["claude", "--prompt-file", str(prompt_file)]
        if worktree:
            cmd.extend(["--working-dir", str(worktree)])
        return cmd

    def dispatch(
        self,
        prompt_file: Path,
        worktree: Path | None = None,
        extra_vars: dict[str, str] | None = None,
    ) -> subprocess.Popen:
        cmd = self.build_command(prompt_file, worktree, extra_vars)
        env = os.environ.copy()
        env.update(self.config.env)
        
        cwd = worktree if worktree else Path.cwd()
        return subprocess.Popen(
            cmd,
            cwd=str(cwd),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )


class CodexInterface(AgentInterface):
    """Codex CLI 接口"""

    def health_check(self) -> HealthCheckResult:
        import time
        from dispatch_strategy import HealthCheckLog, log_health_check
        
        start = time.time()
        command = "npx @openai/codex --version"
        stdout = ""
        stderr = ""
        exit_code = -1
        
        try:
            result = subprocess.run(
                ["npx", "@openai/codex", "--version"],
                capture_output=True,
                text=True,
                timeout=15,
            )
            latency = (time.time() - start) * 1000
            exit_code = result.returncode
            stdout = result.stdout
            stderr = result.stderr
            
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout[:1000],
                stderr=stderr[:1000],
                exit_code=exit_code,
                latency_ms=latency,
                status="ok" if result.returncode == 0 else "error",
                error=stderr if result.returncode != 0 else "",
            ))
            
            if result.returncode == 0:
                version = result.stdout.strip() if result.stdout else ""
                return HealthCheckResult(
                    status=AgentStatus.OK,
                    message="Codex CLI 可用",
                    latency_ms=latency,
                    version=version,
                )
            return HealthCheckResult(
                status=AgentStatus.ERROR,
                message=f"Codex CLI 返回错误: {result.stderr}",
                latency_ms=latency,
            )
        except FileNotFoundError as e:
            latency = (time.time() - start) * 1000
            error_msg = "npx 未安装或 Codex 不可用"
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout,
                stderr=str(e),
                exit_code=-1,
                latency_ms=latency,
                status="not_configured",
                error=error_msg,
            ))
            return HealthCheckResult(
                status=AgentStatus.NOT_CONFIGURED,
                message=error_msg,
            )
        except subprocess.TimeoutExpired:
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout,
                stderr=stderr,
                exit_code=-1,
                latency_ms=15000,
                status="error",
                error="健康检查超时",
            ))
            return HealthCheckResult(
                status=AgentStatus.ERROR,
                message="健康检查超时",
                latency_ms=15000,
            )
        except Exception as e:
            latency = (time.time() - start) * 1000
            error_msg = f"检查失败: {e}"
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout,
                stderr=stderr,
                exit_code=-1,
                latency_ms=latency,
                status="error",
                error=error_msg,
            ))
            return HealthCheckResult(
                status=AgentStatus.ERROR,
                message=error_msg,
            )

    def build_command(
        self,
        prompt_file: Path,
        worktree: Path | None = None,
        extra_vars: dict[str, str] | None = None,
    ) -> list[str]:
        vars_dict = {
            "prompt_file": str(prompt_file),
            "worktree": str(worktree) if worktree else ".",
            **(extra_vars or {}),
        }
        
        if self.config.command_template:
            cmd_str = self._substitute_vars(self.config.command_template, vars_dict)
            return cmd_str.split()
        
        # 默认命令
        cmd = ["npx", "@openai/codex", "-a", "full-auto"]
        # Codex 需要读取 prompt 文件内容
        if prompt_file.exists():
            content = prompt_file.read_text(encoding="utf-8")
            cmd.extend(["-q", content])
        if worktree:
            cmd.extend(["--cwd", str(worktree)])
        return cmd

    def dispatch(
        self,
        prompt_file: Path,
        worktree: Path | None = None,
        extra_vars: dict[str, str] | None = None,
    ) -> subprocess.Popen:
        cmd = self.build_command(prompt_file, worktree, extra_vars)
        env = os.environ.copy()
        env.update(self.config.env)
        
        cwd = worktree if worktree else Path.cwd()
        return subprocess.Popen(
            cmd,
            cwd=str(cwd),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )


class KimiInterface(AgentInterface):
    """Kimi CLI 接口"""

    def health_check(self) -> HealthCheckResult:
        import time
        from dispatch_strategy import HealthCheckLog, log_health_check
        
        start = time.time()
        command = "kimi --version"
        stdout = ""
        stderr = ""
        exit_code = -1
        
        try:
            result = subprocess.run(
                ["kimi", "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            latency = (time.time() - start) * 1000
            exit_code = result.returncode
            stdout = result.stdout
            stderr = result.stderr
            
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout[:1000],
                stderr=stderr[:1000],
                exit_code=exit_code,
                latency_ms=latency,
                status="ok" if result.returncode == 0 else "error",
                error=stderr if result.returncode != 0 else "",
            ))
            
            if result.returncode == 0:
                version = result.stdout.strip() if result.stdout else ""
                return HealthCheckResult(
                    status=AgentStatus.OK,
                    message="Kimi CLI 可用",
                    latency_ms=latency,
                    version=version,
                )
            return HealthCheckResult(
                status=AgentStatus.ERROR,
                message=f"Kimi CLI 返回错误: {result.stderr}",
                latency_ms=latency,
            )
        except FileNotFoundError as e:
            latency = (time.time() - start) * 1000
            error_msg = "Kimi CLI 未安装 (pip install kimi-cli)"
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout,
                stderr=str(e),
                exit_code=-1,
                latency_ms=latency,
                status="not_configured",
                error=error_msg,
            ))
            return HealthCheckResult(
                status=AgentStatus.NOT_CONFIGURED,
                message=error_msg,
            )
        except subprocess.TimeoutExpired:
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout,
                stderr=stderr,
                exit_code=-1,
                latency_ms=10000,
                status="error",
                error="健康检查超时",
            ))
            return HealthCheckResult(
                status=AgentStatus.ERROR,
                message="健康检查超时",
                latency_ms=10000,
            )
        except Exception as e:
            latency = (time.time() - start) * 1000
            error_msg = f"检查失败: {e}"
            log_health_check(HealthCheckLog(
                timestamp=datetime.now().isoformat(),
                agent_id=self.config.id,
                agent_name=self.config.name,
                command=command,
                stdout=stdout,
                stderr=stderr,
                exit_code=-1,
                latency_ms=latency,
                status="error",
                error=error_msg,
            ))
            return HealthCheckResult(
                status=AgentStatus.ERROR,
                message=error_msg,
            )

    def build_command(
        self,
        prompt_file: Path,
        worktree: Path | None = None,
        extra_vars: dict[str, str] | None = None,
    ) -> list[str]:
        vars_dict = {
            "prompt_file": str(prompt_file),
            "worktree": str(worktree) if worktree else ".",
            **(extra_vars or {}),
        }
        
        if self.config.command_template:
            cmd_str = self._substitute_vars(self.config.command_template, vars_dict)
            return cmd_str.split()
        
        # 默认命令
        cmd = ["kimi", "task", "--file", str(prompt_file)]
        if worktree:
            cmd.extend(["--cwd", str(worktree)])
        return cmd

    def dispatch(
        self,
        prompt_file: Path,
        worktree: Path | None = None,
        extra_vars: dict[str, str] | None = None,
    ) -> subprocess.Popen:
        cmd = self.build_command(prompt_file, worktree, extra_vars)
        env = os.environ.copy()
        env.update(self.config.env)
        
        cwd = worktree if worktree else Path.cwd()
        return subprocess.Popen(
            cmd,
            cwd=str(cwd),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )


# Agent 接口工厂
AGENT_INTERFACES: dict[AgentType, type[AgentInterface]] = {
    AgentType.CLAUDE: ClaudeInterface,
    AgentType.CODEX: CodexInterface,
    AgentType.KIMI: KimiInterface,
}


def get_agent_interface(config: AgentConfig) -> AgentInterface:
    """获取 agent 接口实例"""
    interface_class = AGENT_INTERFACES.get(config.type, ClaudeInterface)
    return interface_class(config)


# 配置管理

DEFAULT_AGENTS: list[AgentConfig] = [
    AgentConfig(
        id="claude",
        name="Claude Code",
        type=AgentType.CLAUDE,
        enabled=True,
        command_template="claude --prompt-file {prompt_file} --working-dir {worktree}",
        description="Anthropic Claude Code CLI",
        icon="🧠",
        color="#d97757",
    ),
    AgentConfig(
        id="codex",
        name="OpenAI Codex",
        type=AgentType.CODEX,
        enabled=False,
        command_template="npx @openai/codex -a full-auto -q $(cat {prompt_file}) --cwd {worktree}",
        description="OpenAI Codex CLI",
        icon="🤖",
        color="#10a37f",
    ),
    AgentConfig(
        id="kimi",
        name="Kimi CLI",
        type=AgentType.KIMI,
        enabled=True,
        command_template="kimi task --file {prompt_file} --cwd {worktree}",
        description="Kimi 智能助手 CLI",
        icon="🌙",
        color="#4f46e5",
    ),
]


def load_agents_config() -> list[AgentConfig]:
    """加载 agents 配置"""
    if not AGENTS_CONFIG_PATH.exists():
        # 首次使用，创建默认配置
        save_agents_config(DEFAULT_AGENTS)
        return DEFAULT_AGENTS
    
    try:
        data = yaml.safe_load(AGENTS_CONFIG_PATH.read_text(encoding="utf-8"))
        if not data or "agents" not in data:
            return DEFAULT_AGENTS
        return [AgentConfig.from_dict(item) for item in data["agents"]]
    except Exception:
        return DEFAULT_AGENTS


def save_agents_config(agents: list[AgentConfig]) -> None:
    """保存 agents 配置"""
    AGENTS_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = {"agents": [agent.to_dict() for agent in agents]}
    AGENTS_CONFIG_PATH.write_text(yaml.safe_dump(data, allow_unicode=True), encoding="utf-8")


def get_agent_config(agent_id: str) -> AgentConfig | None:
    """获取指定 agent 配置"""
    agents = load_agents_config()
    for agent in agents:
        if agent.id == agent_id:
            return agent
    return None


def update_agent_config(agent_id: str, updates: dict[str, Any]) -> AgentConfig | None:
    """更新 agent 配置"""
    agents = load_agents_config()
    for i, agent in enumerate(agents):
        if agent.id == agent_id:
            # 更新字段
            for key, value in updates.items():
                if key == "type" and isinstance(value, str):
                    # 特殊处理 type 字段，转换为 AgentType 枚举
                    setattr(agent, key, AgentType(value))
                elif hasattr(agent, key):
                    setattr(agent, key, value)
            save_agents_config(agents)
            return agents[i]
    return None


def add_agent_config(config: AgentConfig) -> AgentConfig:
    """添加新的 agent 配置"""
    agents = load_agents_config()
    agents.append(config)
    save_agents_config(agents)
    return config


def delete_agent_config(agent_id: str) -> bool:
    """删除 agent 配置"""
    agents = load_agents_config()
    original_len = len(agents)
    agents = [a for a in agents if a.id != agent_id]
    if len(agents) < original_len:
        save_agents_config(agents)
        return True
    return False


def check_all_agents_health() -> list[dict[str, Any]]:
    """检查所有 agent 的健康状态"""
    agents = load_agents_config()
    results = []
    for config in agents:
        interface = get_agent_interface(config)
        health = interface.health_check()
        results.append({
            "config": config.to_dict(),
            "health": {
                "status": health.status.value,
                "message": health.message,
                "latency_ms": health.latency_ms,
                "version": health.version,
            },
        })
    return results
