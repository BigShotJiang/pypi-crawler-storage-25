"""
Agent 派发策略层
支持强行指派和按任务特性决定两种策略
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

import yaml

# 配置文件路径
DISPATCH_CONFIG_PATH = Path(__file__).resolve().parents[3] / "runtime" / "dispatch_strategy.yaml"
HEALTH_CHECK_LOGS_PATH = Path(__file__).resolve().parents[3] / "runtime" / "health_check_logs.jsonl"


class DispatchStrategyType(str, Enum):
    """派发策略类型"""
    FORCE = "force"  # 强行指派
    AUTO = "auto"    # 按任务特性自动决定


class WorkerType(str, Enum):
    """Worker 逻辑角色类型（与具体 Agent 解耦）"""
    DEVELOPER = "developer"           # 代码开发
    RESEARCHER = "researcher"         # 研究分析
    INTEGRATOR = "integrator"         # 整合审查
    DOCUMENTER = "documenter"         # 文档编写
    TESTER = "tester"                 # 测试验证


@dataclass
class DispatchStrategy:
    """派发策略配置"""
    strategy_type: DispatchStrategyType = DispatchStrategyType.AUTO
    # 强行指派配置
    force_config: dict[str, str] = field(default_factory=dict)  # worker_type -> agent_id
    # 自动派发配置（按任务特性匹配）
    auto_config: dict[str, Any] = field(default_factory=dict)
    # 默认 agent
    default_agent: str = "claude"
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "strategy_type": self.strategy_type.value,
            "force_config": self.force_config,
            "auto_config": self.auto_config,
            "default_agent": self.default_agent,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DispatchStrategy:
        return cls(
            strategy_type=DispatchStrategyType(data.get("strategy_type", "auto")),
            force_config=data.get("force_config", {}),
            auto_config=data.get("auto_config", {}),
            default_agent=data.get("default_agent", "claude"),
        )


@dataclass
class HealthCheckLog:
    """健康检查日志条目"""
    timestamp: str
    agent_id: str
    agent_name: str
    command: str
    stdout: str
    stderr: str
    exit_code: int
    latency_ms: float
    status: str
    error: str = ""
    
    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "command": self.command,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "exit_code": self.exit_code,
            "latency_ms": self.latency_ms,
            "status": self.status,
            "error": self.error,
        }


# 默认派发策略（Worker 角色与 Agent 解耦）
DEFAULT_DISPATCH_STRATEGY = DispatchStrategy(
    strategy_type=DispatchStrategyType.AUTO,
    force_config={
        # Worker 逻辑角色 -> Agent ID 映射
        WorkerType.DEVELOPER.value: "claude",      # 开发工作默认用 Claude
        WorkerType.RESEARCHER.value: "codex",      # 研究工作默认用 Codex
        WorkerType.INTEGRATOR.value: "claude",     # 整合工作默认用 Claude
        WorkerType.DOCUMENTER.value: "claude",     # 文档工作默认用 Claude
        WorkerType.TESTER.value: "kimi",           # 测试工作默认用 Kimi
    },
    auto_config={
        # 按任务内容关键词匹配（优先级高于角色映射）
        "content_keywords": {
            "claude": ["implement", "code", "develop", "build", "create", "fix", "refactor"],
            "codex": ["research", "analyze", "extract", "investigate", "study"],
            "kimi": ["document", "write", "summarize", "translate"],
        },
        # 按文件类型匹配
        "file_type_mapping": {
            ".py": "claude",
            ".js": "claude",
            ".ts": "claude",
            ".tsx": "claude",
            ".md": "kimi",
        },
    },
    default_agent="claude",
)


def load_dispatch_strategy() -> DispatchStrategy:
    """加载派发策略配置"""
    if not DISPATCH_CONFIG_PATH.exists():
        save_dispatch_strategy(DEFAULT_DISPATCH_STRATEGY)
        return DEFAULT_DISPATCH_STRATEGY
    
    try:
        data = yaml.safe_load(DISPATCH_CONFIG_PATH.read_text(encoding="utf-8"))
        return DispatchStrategy.from_dict(data)
    except Exception:
        return DEFAULT_DISPATCH_STRATEGY


def save_dispatch_strategy(strategy: DispatchStrategy) -> None:
    """保存派发策略配置"""
    DISPATCH_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    DISPATCH_CONFIG_PATH.write_text(
        yaml.safe_dump(strategy.to_dict(), allow_unicode=True, sort_keys=False),
        encoding="utf-8"
    )


def update_dispatch_strategy(updates: dict[str, Any]) -> DispatchStrategy:
    """更新派发策略配置"""
    strategy = load_dispatch_strategy()
    
    if "strategy_type" in updates:
        strategy.strategy_type = DispatchStrategyType(updates["strategy_type"])
    if "force_config" in updates:
        strategy.force_config = updates["force_config"]
    if "auto_config" in updates:
        strategy.auto_config = updates["auto_config"]
    if "default_agent" in updates:
        strategy.default_agent = updates["default_agent"]
    
    save_dispatch_strategy(strategy)
    return strategy


def select_agent_for_task(
    task_role: str,
    task_title: str = "",
    task_id: str = "",
    task_files: list[str] | None = None,
    available_agents: list[str] | None = None,
) -> dict[str, Any]:
    """
    根据策略为任务选择合适的 agent（Worker 角色与 Agent 解耦）
    
    Args:
        task_role: Worker 逻辑角色 (如 developer, researcher, integrator)
                 或旧的角色名 (如 claude_worker, codex_worker) - 会自动映射
        task_title: 任务标题
        task_id: 任务ID
        task_files: 任务相关文件列表
        available_agents: 可用的 agent 列表
    
    Returns:
        包含选中 agent_id 和决策原因的字典
    """
    strategy = load_dispatch_strategy()
    available_agents = available_agents or ["claude", "codex", "kimi"]
    task_files = task_files or []
    
    # 决策记录（用于解释为什么选择该 agent）
    decision_log: list[str] = []
    
    # 辅助函数：检查 agent 是否可用
    def is_available(agent_id: str) -> bool:
        return agent_id in available_agents
    
    # 强行指派策略
    if strategy.strategy_type == DispatchStrategyType.FORCE:
        decision_log.append("策略: 强行指派")
        # 检查是否有针对该 worker 类型的强制配置
        forced_agent = strategy.force_config.get(task_role)
        if forced_agent and is_available(forced_agent):
            decision_log.append(f"Worker '{task_role}' 强制指派到 '{forced_agent}'")
            return {
                "agent_id": forced_agent,
                "worker_role": task_role,
                "strategy": "force",
                "reason": "forced_by_role",
                "decision_log": decision_log,
            }
        # 否则返回默认 agent
        if is_available(strategy.default_agent):
            decision_log.append(f"使用默认 Agent: {strategy.default_agent}")
            return {
                "agent_id": strategy.default_agent,
                "worker_role": task_role,
                "strategy": "force",
                "reason": "forced_default",
                "decision_log": decision_log,
            }
        # 默认 agent 不可用，返回第一个可用 agent
        if available_agents:
            decision_log.append(f"默认 Agent 不可用，使用: {available_agents[0]}")
            return {
                "agent_id": available_agents[0],
                "worker_role": task_role,
                "strategy": "force",
                "reason": "fallback_to_first_available",
                "decision_log": decision_log,
            }
    
    # 自动策略 - 按任务特性决定
    decision_log.append("策略: 自动匹配")
    
    # 1. 首先检查 force_config 中是否有该 worker 角色的映射
    if task_role in strategy.force_config:
        mapped_agent = strategy.force_config[task_role]
        if is_available(mapped_agent):
            decision_log.append(f"Worker 角色 '{task_role}' 映射到 Agent '{mapped_agent}'")
            return {
                "agent_id": mapped_agent,
                "worker_role": task_role,
                "strategy": "auto",
                "reason": "role_mapping",
                "decision_log": decision_log,
            }
    
    # 2. 按任务内容关键词匹配（优先级最高）
    task_content = f"{task_title} {task_id}".lower()
    for agent_id, keywords in strategy.auto_config.get("content_keywords", {}).items():
        if is_available(agent_id):
            for keyword in keywords:
                if keyword.lower() in task_content:
                    decision_log.append(f"任务内容匹配关键词 '{keyword}' -> Agent '{agent_id}'")
                    return {
                        "agent_id": agent_id,
                        "worker_role": task_role,
                        "strategy": "auto",
                        "reason": "content_keyword_match",
                        "matched_keyword": keyword,
                        "decision_log": decision_log,
                    }
    
    # 3. 按文件类型匹配
    file_type_mapping = strategy.auto_config.get("file_type_mapping", {})
    for file_path in task_files:
        ext = Path(file_path).suffix.lower()
        if ext in file_type_mapping:
            agent_id = file_type_mapping[ext]
            if is_available(agent_id):
                decision_log.append(f"文件类型 '{ext}' 匹配 Agent '{agent_id}'")
                return {
                    "agent_id": agent_id,
                    "worker_role": task_role,
                    "strategy": "auto",
                    "reason": "file_type_match",
                    "matched_extension": ext,
                    "decision_log": decision_log,
                }
    
    # 4. 返回默认 agent
    if is_available(strategy.default_agent):
        decision_log.append(f"无匹配规则，使用默认 Agent: {strategy.default_agent}")
        return {
            "agent_id": strategy.default_agent,
            "worker_role": task_role,
            "strategy": "auto",
            "reason": "default",
            "decision_log": decision_log,
        }
    
    # 5. 默认 agent 不可用，返回第一个可用 agent
    if available_agents:
        decision_log.append(f"默认 Agent 不可用，使用: {available_agents[0]}")
        return {
            "agent_id": available_agents[0],
            "worker_role": task_role,
            "strategy": "auto",
            "reason": "fallback",
            "decision_log": decision_log,
        }
    
    # 没有任何可用 agent
    decision_log.append("错误: 没有可用的 Agent")
    return {
        "agent_id": "",
        "worker_role": task_role,
        "strategy": "auto",
        "reason": "no_agent_available",
        "error": "No agent available",
        "decision_log": decision_log,
    }


def log_health_check(log: HealthCheckLog) -> None:
    """记录健康检查日志"""
    HEALTH_CHECK_LOGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    
    # 追加写入 JSONL 格式
    with open(HEALTH_CHECK_LOGS_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(log.to_dict(), ensure_ascii=False) + "\n")


def get_health_check_logs(agent_id: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
    """获取健康检查日志"""
    if not HEALTH_CHECK_LOGS_PATH.exists():
        return []
    
    logs = []
    with open(HEALTH_CHECK_LOGS_PATH, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                log = json.loads(line)
                if agent_id is None or log.get("agent_id") == agent_id:
                    logs.append(log)
            except json.JSONDecodeError:
                continue
    
    # 返回最新的 limit 条
    return logs[-limit:][::-1]


def clear_health_check_logs() -> None:
    """清空健康检查日志"""
    if HEALTH_CHECK_LOGS_PATH.exists():
        HEALTH_CHECK_LOGS_PATH.unlink()
