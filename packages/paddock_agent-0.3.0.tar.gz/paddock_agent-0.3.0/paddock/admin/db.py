"""
SQLite 数据库层 - 替代原有的 YAML/JSONL 文件存储
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Generator

from paddock.config import DB_PATH


def init_db() -> None:
    """初始化数据库表结构"""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    
    with get_db() as db:
        # Agent 表（实际 CLI 工具）
        db.execute("""
            CREATE TABLE IF NOT EXISTS agents (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                cli_command TEXT NOT NULL,
                command_template TEXT,
                description TEXT,
                enabled INTEGER DEFAULT 1,
                icon TEXT,
                color TEXT,
                env TEXT,  -- JSON
                created_at TEXT,
                updated_at TEXT
            )
        """)
        
        # Worker 表（逻辑角色）
        db.execute("""
            CREATE TABLE IF NOT EXISTS workers (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                icon TEXT,
                color TEXT,
                strategy_mode TEXT DEFAULT 'fixed',
                strategy_fixed_agent TEXT,
                strategy_agent_priority TEXT,  -- JSON list
                strategy_content_rules TEXT,   -- JSON
                created_at TEXT,
                updated_at TEXT
            )
        """)
        
        # Loop Stage 表（研发流程环节）
        db.execute("""
            CREATE TABLE IF NOT EXISTS loop_stages (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                worker_id TEXT NOT NULL,
                enabled INTEGER DEFAULT 1,
                auto_trigger INTEGER DEFAULT 0,
                config TEXT,  -- JSON
                sort_order INTEGER DEFAULT 0,
                created_at TEXT,
                updated_at TEXT,
                FOREIGN KEY (worker_id) REFERENCES workers(id)
            )
        """)
        
        # Loop 全局配置表
        db.execute("""
            CREATE TABLE IF NOT EXISTS loop_settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        
        # 健康检查日志表
        db.execute("""
            CREATE TABLE IF NOT EXISTS health_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_id TEXT NOT NULL,
                agent_name TEXT,
                status TEXT,
                command TEXT,
                stdout TEXT,
                stderr TEXT,
                exit_code INTEGER,
                latency_ms REAL,
                error TEXT,
                timestamp TEXT,
                FOREIGN KEY (agent_id) REFERENCES agents(id)
            )
        """)
        
        # 创建索引
        db.execute("CREATE INDEX IF NOT EXISTS idx_health_logs_agent ON health_logs(agent_id)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_health_logs_time ON health_logs(timestamp)")
        db.execute("CREATE INDEX IF NOT EXISTS idx_loop_stages_order ON loop_stages(sort_order)")
        
        db.commit()


@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    """获取数据库连接"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


# ==================== Agent 操作 ====================

def save_agent(agent: dict[str, Any]) -> None:
    """保存或更新 Agent"""
    with get_db() as db:
        now = datetime.now().isoformat()
        db.execute("""
            INSERT INTO agents (id, name, cli_command, command_template, description, 
                              enabled, icon, color, env, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                name = excluded.name,
                cli_command = excluded.cli_command,
                command_template = excluded.command_template,
                description = excluded.description,
                enabled = excluded.enabled,
                icon = excluded.icon,
                color = excluded.color,
                env = excluded.env,
                updated_at = excluded.updated_at
        """, (
            agent["id"],
            agent.get("name", agent["id"]),
            agent.get("cli_command", agent["id"]),
            agent.get("command_template", ""),
            agent.get("description", ""),
            1 if agent.get("enabled", True) else 0,
            agent.get("icon", "🤖"),
            agent.get("color", "#666"),
            json.dumps(agent.get("env", {})),
            now,
            now,
        ))
        db.commit()


def load_agents() -> list[dict[str, Any]]:
    """加载所有 Agent"""
    with get_db() as db:
        cursor = db.execute("SELECT * FROM agents ORDER BY id")
        rows = cursor.fetchall()
        return [_row_to_agent(row) for row in rows]


def load_agent(agent_id: str) -> dict[str, Any] | None:
    """加载单个 Agent"""
    with get_db() as db:
        cursor = db.execute("SELECT * FROM agents WHERE id = ?", (agent_id,))
        row = cursor.fetchone()
        return _row_to_agent(row) if row else None


def delete_agent(agent_id: str) -> bool:
    """删除 Agent"""
    with get_db() as db:
        cursor = db.execute("DELETE FROM agents WHERE id = ?", (agent_id,))
        db.commit()
        return cursor.rowcount > 0


def _row_to_agent(row: sqlite3.Row) -> dict[str, Any]:
    """数据库行转 Agent 字典"""
    return {
        "id": row["id"],
        "name": row["name"],
        "cli_command": row["cli_command"],
        "command_template": row["command_template"],
        "description": row["description"],
        "enabled": bool(row["enabled"]),
        "icon": row["icon"],
        "color": row["color"],
        "env": json.loads(row["env"] or "{}"),
    }


# ==================== Worker 操作 ====================

def save_worker(worker: dict[str, Any]) -> None:
    """保存或更新 Worker"""
    with get_db() as db:
        now = datetime.now().isoformat()
        strategy = worker.get("strategy", {})
        db.execute("""
            INSERT INTO workers (id, name, description, icon, color,
                               strategy_mode, strategy_fixed_agent,
                               strategy_agent_priority, strategy_content_rules,
                               created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                name = excluded.name,
                description = excluded.description,
                icon = excluded.icon,
                color = excluded.color,
                strategy_mode = excluded.strategy_mode,
                strategy_fixed_agent = excluded.strategy_fixed_agent,
                strategy_agent_priority = excluded.strategy_agent_priority,
                strategy_content_rules = excluded.strategy_content_rules,
                updated_at = excluded.updated_at
        """, (
            worker["id"],
            worker.get("name", worker["id"]),
            worker.get("description", ""),
            worker.get("icon", "👤"),
            worker.get("color", "#3b82f6"),
            strategy.get("mode", "fixed"),
            strategy.get("fixed_agent", ""),
            json.dumps(strategy.get("agent_priority", [])),
            json.dumps(strategy.get("content_rules", [])),
            now,
            now,
        ))
        db.commit()


def load_workers() -> list[dict[str, Any]]:
    """加载所有 Worker"""
    with get_db() as db:
        cursor = db.execute("SELECT * FROM workers ORDER BY id")
        rows = cursor.fetchall()
        return [_row_to_worker(row) for row in rows]


def load_worker(worker_id: str) -> dict[str, Any] | None:
    """加载单个 Worker"""
    with get_db() as db:
        cursor = db.execute("SELECT * FROM workers WHERE id = ?", (worker_id,))
        row = cursor.fetchone()
        return _row_to_worker(row) if row else None


def _row_to_worker(row: sqlite3.Row) -> dict[str, Any]:
    """数据库行转 Worker 字典"""
    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"],
        "icon": row["icon"],
        "color": row["color"],
        "strategy": {
            "mode": row["strategy_mode"],
            "fixed_agent": row["strategy_fixed_agent"],
            "agent_priority": json.loads(row["strategy_agent_priority"] or "[]"),
            "content_rules": json.loads(row["strategy_content_rules"] or "[]"),
        },
    }


# ==================== Loop Stage 操作 ====================

def save_loop_stage(stage: dict[str, Any]) -> None:
    """保存或更新 Loop Stage"""
    with get_db() as db:
        now = datetime.now().isoformat()
        db.execute("""
            INSERT INTO loop_stages (id, name, description, worker_id, enabled,
                                   auto_trigger, config, sort_order, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                name = excluded.name,
                description = excluded.description,
                worker_id = excluded.worker_id,
                enabled = excluded.enabled,
                auto_trigger = excluded.auto_trigger,
                config = excluded.config,
                sort_order = excluded.sort_order,
                updated_at = excluded.updated_at
        """, (
            stage["id"],
            stage.get("name", stage["id"]),
            stage.get("description", ""),
            stage.get("worker_id", ""),
            1 if stage.get("enabled", True) else 0,
            1 if stage.get("auto_trigger", False) else 0,
            json.dumps(stage.get("config", {})),
            stage.get("sort_order", 0),
            now,
            now,
        ))
        db.commit()


def load_loop_stages() -> list[dict[str, Any]]:
    """加载所有 Loop Stage（按顺序）"""
    with get_db() as db:
        cursor = db.execute("SELECT * FROM loop_stages ORDER BY sort_order, id")
        rows = cursor.fetchall()
        return [_row_to_stage(row) for row in rows]


def delete_loop_stage(stage_id: str) -> bool:
    """删除 Loop Stage"""
    with get_db() as db:
        cursor = db.execute("DELETE FROM loop_stages WHERE id = ?", (stage_id,))
        db.commit()
        return cursor.rowcount > 0


def reorder_loop_stages(stage_ids: list[str]) -> None:
    """重新排序 Loop Stage"""
    with get_db() as db:
        for i, stage_id in enumerate(stage_ids):
            db.execute(
                "UPDATE loop_stages SET sort_order = ? WHERE id = ?",
                (i, stage_id)
            )
        db.commit()


def _row_to_stage(row: sqlite3.Row) -> dict[str, Any]:
    """数据库行转 Stage 字典"""
    return {
        "id": row["id"],
        "name": row["name"],
        "description": row["description"],
        "worker_id": row["worker_id"],
        "enabled": bool(row["enabled"]),
        "auto_trigger": bool(row["auto_trigger"]),
        "config": json.loads(row["config"] or "{}"),
        "sort_order": row["sort_order"],
    }


# ==================== Loop Settings 操作 ====================

def set_loop_setting(key: str, value: str) -> None:
    """设置 Loop 全局配置"""
    with get_db() as db:
        db.execute("""
            INSERT INTO loop_settings (key, value) VALUES (?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value
        """, (key, value))
        db.commit()


def get_loop_setting(key: str, default: str = "") -> str:
    """获取 Loop 全局配置"""
    with get_db() as db:
        cursor = db.execute("SELECT value FROM loop_settings WHERE key = ?", (key,))
        row = cursor.fetchone()
        return row["value"] if row else default


# ==================== Health Logs 操作 ====================

def add_health_log(log: dict[str, Any]) -> None:
    """添加健康检查日志"""
    with get_db() as db:
        db.execute("""
            INSERT INTO health_logs 
            (agent_id, agent_name, status, command, stdout, stderr, exit_code, latency_ms, error, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            log["agent_id"],
            log.get("agent_name", ""),
            log.get("status", ""),
            log.get("command", ""),
            log.get("stdout", ""),
            log.get("stderr", ""),
            log.get("exit_code", -1),
            log.get("latency_ms", 0),
            log.get("error", ""),
            log.get("timestamp", datetime.now().isoformat()),
        ))
        db.commit()


def get_health_logs(agent_id: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
    """获取健康检查日志"""
    with get_db() as db:
        if agent_id:
            cursor = db.execute(
                """SELECT * FROM health_logs 
                   WHERE agent_id = ? 
                   ORDER BY timestamp DESC LIMIT ?""",
                (agent_id, limit)
            )
        else:
            cursor = db.execute(
                "SELECT * FROM health_logs ORDER BY timestamp DESC LIMIT ?",
                (limit,)
            )
        rows = cursor.fetchall()
        return [dict(row) for row in rows]


def clear_health_logs() -> None:
    """清空健康检查日志"""
    with get_db() as db:
        db.execute("DELETE FROM health_logs")
        db.commit()


# ==================== 数据迁移 ====================

def migrate_from_yaml() -> None:
    """从旧版 YAML 文件迁移数据到 SQLite"""
    from agent_models import DEFAULT_AGENTS, DEFAULT_WORKERS
    from loop_config import DEFAULT_LOOP
    
    print("Migrating data from YAML to SQLite...")
    
    # 迁移 Agents
    for agent in DEFAULT_AGENTS:
        save_agent(agent.to_dict())
    print(f"  Migrated {len(DEFAULT_AGENTS)} agents")
    
    # 迁移 Workers
    for worker in DEFAULT_WORKERS:
        save_worker(worker.to_dict())
    print(f"  Migrated {len(DEFAULT_WORKERS)} workers")
    
    # 迁移 Loop Stages
    for i, stage in enumerate(DEFAULT_LOOP.stages):
        stage_dict = {
            "id": stage.id,
            "name": stage.name,
            "description": stage.description,
            "worker_id": stage.worker_id,
            "enabled": stage.enabled,
            "auto_trigger": stage.auto_trigger,
            "config": stage.config,
            "sort_order": i,
        }
        save_loop_stage(stage_dict)
    print(f"  Migrated {len(DEFAULT_LOOP.stages)} loop stages")
    
    # 迁移 Loop Settings
    set_loop_setting("name", DEFAULT_LOOP.name)
    set_loop_setting("description", DEFAULT_LOOP.description)
    set_loop_setting("parallel_limit", str(DEFAULT_LOOP.settings.get("parallel_limit", 3)))
    set_loop_setting("auto_advance", str(DEFAULT_LOOP.settings.get("auto_advance", False)))
    set_loop_setting("require_approval", str(DEFAULT_LOOP.settings.get("require_approval", True)))
    print("  Migrated loop settings")
    
    print("Migration complete!")


# 初始化数据库
init_db()
