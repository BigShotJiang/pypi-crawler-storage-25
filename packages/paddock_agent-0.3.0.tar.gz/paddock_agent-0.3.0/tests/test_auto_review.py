"""Tests for auto_review logic in supervisor_v2."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from paddock.utils import all_files_in_scope, matches_any_pattern, path_conflict


class TestAutoReview(unittest.TestCase):
    def test_path_conflict_overlap(self) -> None:
        self.assertTrue(path_conflict(["src/**"], ["src/module"]))
        self.assertTrue(path_conflict(["docs"], ["docs/rules.md"]))
        self.assertFalse(path_conflict(["frontend/**"], ["backend/**"]))

    def test_all_files_in_scope(self) -> None:
        scope = ["src/**", "docs/*.md"]
        self.assertTrue(all_files_in_scope(["src/app.py", "docs/readme.md"], scope))
        self.assertFalse(all_files_in_scope(["src/app.py", "tests/test.py"], scope))

    def test_matches_integrator_only(self) -> None:
        patterns = ["README.md", "docs/rules-core.md", ".paddock/**"]
        self.assertTrue(matches_any_pattern("README.md", patterns))
        self.assertTrue(matches_any_pattern(".paddock/project.yaml", patterns))
        self.assertFalse(matches_any_pattern("src/app.py", patterns))


if __name__ == "__main__":
    unittest.main()
