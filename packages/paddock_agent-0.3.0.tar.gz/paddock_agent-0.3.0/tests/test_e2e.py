"""Paddock V2 End-to-End tests: full workflow simulation via API + DB."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "admin" / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Use a temp DB for E2E tests (separate from unit test DB)
_tmp_db = tempfile.NamedTemporaryFile(suffix="-e2e.db", delete=False)
_tmp_db.close()
os.environ["PADDOCK_DB_PATH"] = _tmp_db.name

from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)


class TestFullProjectWorkflow(unittest.TestCase):
    """Test a complete project lifecycle: create → configure → objectives → snapshot."""

    PROJECT_ID = "e2e-proj"

    def setUp(self) -> None:
        client.delete(f"/api/v2/projects/{self.PROJECT_ID}")

    def tearDown(self) -> None:
        client.delete(f"/api/v2/projects/{self.PROJECT_ID}")

    def test_full_project_lifecycle(self) -> None:
        # 1. Create project
        r = client.post("/api/v2/projects", json={
            "id": self.PROJECT_ID,
            "name": "E2E Test Project",
            "repo_root": "../e2e-repo",
            "worktrees_root": "../e2e-worktrees",
            "max_parallel_sessions": 2,
            "session_defaults": {
                "scope_level": "medium",
                "max_commits_per_session": 5,
                "max_minutes_per_session": 30,
            },
        })
        self.assertEqual(r.status_code, 200)

        # 2. Set goal
        r = client.put(f"/api/v2/projects/{self.PROJECT_ID}/goals", json={
            "goal": {
                "id": "g-e2e",
                "title": "Build a complete game prototype",
                "description": "End-to-end game development",
                "status": "active",
            },
            "milestone": {
                "id": "m-e2e",
                "goal_id": "g-e2e",
                "title": "Core mechanics",
                "status": "active",
            },
            "phase": {
                "id": "p-e2e",
                "milestone_id": "m-e2e",
                "title": "Implementation phase",
                "status": "active",
            },
        })
        self.assertEqual(r.status_code, 200)

        # 3. Create objectives
        objectives = [
            {
                "id": "obj-e2e-001",
                "title": "Implement combat system",
                "description": "Create the core combat loop with attack/defense mechanics",
                "acceptance_criteria": [
                    "Player can attack enemies",
                    "Damage calculation works correctly",
                    "Game over when HP reaches 0",
                ],
                "status": "todo",
                "priority": 10,
            },
            {
                "id": "obj-e2e-002",
                "title": "Implement item system",
                "description": "Create inventory and item usage mechanics",
                "acceptance_criteria": [
                    "Player can pick up items",
                    "Items can be used from inventory",
                ],
                "status": "todo",
                "depends_on": ["obj-e2e-001"],
                "priority": 5,
            },
        ]
        for obj in objectives:
            r = client.post(f"/api/v2/projects/{self.PROJECT_ID}/objectives", json=obj)
            self.assertEqual(r.status_code, 200, f"Failed to create {obj['id']}: {r.text}")

        # 4. Get snapshot and verify structure
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/snapshot")
        self.assertEqual(r.status_code, 200)
        snap = r.json()

        self.assertEqual(snap["project"]["id"], self.PROJECT_ID)
        self.assertEqual(snap["project"]["name"], "E2E Test Project")
        self.assertEqual(snap["goal"]["title"], "Build a complete game prototype")
        self.assertEqual(snap["milestone"]["title"], "Core mechanics")
        self.assertEqual(snap["phase"]["title"], "Implementation phase")
        self.assertEqual(snap["objectives"]["summary"].get("todo", 0), 2)
        self.assertEqual(len(snap["objectives"]["items"]), 2)
        self.assertEqual(snap["pipeline_state"], "waiting")
        self.assertEqual(snap["sessions"]["active"], [])

        # 5. Update objective status to ready
        r = client.put("/api/v2/objectives/obj-e2e-001", json={"status": "ready"})
        self.assertEqual(r.status_code, 200)

        # 6. Verify snapshot reflects change
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/snapshot")
        snap2 = r.json()
        self.assertEqual(snap2["pipeline_state"], "queued")

        # 7. List objectives filtered by status
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/objectives?status=ready")
        self.assertEqual(r.status_code, 200)
        ready_objs = r.json()["objectives"]
        self.assertEqual(len(ready_objs), 1)
        self.assertEqual(ready_objs[0]["id"], "obj-e2e-001")

        # 8. Acceptance criteria should be parsed as list (not raw JSON string)
        criteria = ready_objs[0].get("acceptance_criteria")
        self.assertIsInstance(criteria, list)
        self.assertIn("Player can attack enemies", criteria)

        # 9. depends_on should be parsed as list
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/objectives?status=todo")
        todo_objs = r.json()["objectives"]
        obj2 = next(o for o in todo_objs if o["id"] == "obj-e2e-002")
        self.assertIsInstance(obj2.get("depends_on"), list)
        self.assertIn("obj-e2e-001", obj2["depends_on"])


class TestAgentWorkerIntegration(unittest.TestCase):
    """Test agent + worker configuration flow."""

    def setUp(self) -> None:
        client.delete("/api/v2/agents/e2e-agent")
        client.delete("/api/v2/workers/e2e-worker")

    def tearDown(self) -> None:
        client.delete("/api/v2/agents/e2e-agent")
        client.delete("/api/v2/workers/e2e-worker")

    def test_agent_worker_setup(self) -> None:
        # Create agent
        r = client.post("/api/v2/agents", json={
            "id": "e2e-agent",
            "name": "E2E Agent",
            "cli_command": "e2e-cli",
            "command_template": "e2e-cli --dangerously-skip-permissions -p {prompt_file}",
            "supported_features": ["code", "research"],
            "enabled": True,
        })
        self.assertEqual(r.status_code, 200)

        # Create worker using that agent
        r = client.post("/api/v2/workers", json={
            "id": "e2e-worker",
            "name": "E2E Worker",
            "role_type": "implementer",
            "strategy": {
                "mode": "fixed",
                "fixed_agent": "e2e-agent",
            },
        })
        self.assertEqual(r.status_code, 200)

        # Verify agent appears in list
        r = client.get("/api/v2/agents")
        agent_ids = [a["id"] for a in r.json()["agents"]]
        self.assertIn("e2e-agent", agent_ids)

        # Verify worker appears in list
        r = client.get("/api/v2/workers")
        worker_ids = [w["id"] for w in r.json()["workers"]]
        self.assertIn("e2e-worker", worker_ids)

        # Update worker strategy to auto
        r = client.put("/api/v2/workers/e2e-worker/strategy", json={
            "mode": "auto",
            "agent_priority": ["e2e-agent"],
        })
        self.assertEqual(r.status_code, 200)


class TestFlowConfigIntegration(unittest.TestCase):
    """Test flow config read/write cycle."""

    PROJECT_ID = "e2e-flow-proj"

    def setUp(self) -> None:
        client.post("/api/v2/projects", json={
            "id": self.PROJECT_ID, "name": "Flow E2E",
            "repo_root": "../x", "worktrees_root": "../xwt",
        })

    def tearDown(self) -> None:
        client.delete(f"/api/v2/projects/{self.PROJECT_ID}")

    def test_flow_config_roundtrip(self) -> None:
        # Update config
        r = client.put(f"/api/v2/projects/{self.PROJECT_ID}/flow-config", json={
            "scope_level": "strict",
            "max_commits_per_session": 3,
            "max_minutes_per_session": 15,
            "max_parallel_sessions": 1,
        })
        self.assertEqual(r.status_code, 200)

        # Read back
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/flow-config")
        self.assertEqual(r.status_code, 200)
        cfg = r.json()
        self.assertEqual(cfg["scope_level"], "strict")
        self.assertEqual(cfg["max_commits_per_session"], 3)
        self.assertEqual(cfg["max_minutes_per_session"], 15)
        self.assertEqual(cfg["max_parallel_sessions"], 1)

        # Snapshot should reflect new max_parallel
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/snapshot")
        snap = r.json()
        self.assertEqual(snap["flow_config"]["max_parallel_sessions"], 1)


class TestMultiProjectIsolation(unittest.TestCase):
    """Test that multiple projects are properly isolated."""

    def setUp(self) -> None:
        for pid in ["e2e-proj-a", "e2e-proj-b"]:
            client.delete(f"/api/v2/projects/{pid}")
        client.post("/api/v2/projects", json={
            "id": "e2e-proj-a", "name": "Project A",
            "repo_root": "../a", "worktrees_root": "../a-wt",
        })
        client.post("/api/v2/projects", json={
            "id": "e2e-proj-b", "name": "Project B",
            "repo_root": "../b", "worktrees_root": "../b-wt",
        })

    def tearDown(self) -> None:
        for pid in ["e2e-proj-a", "e2e-proj-b"]:
            client.delete(f"/api/v2/projects/{pid}")

    def test_objectives_are_project_scoped(self) -> None:
        import uuid
        obj_a = f"obj-a-{uuid.uuid4().hex[:6]}"
        obj_b = f"obj-b-{uuid.uuid4().hex[:6]}"

        client.post("/api/v2/projects/e2e-proj-a/objectives", json={
            "id": obj_a, "title": "Obj A", "description": "...",
            "acceptance_criteria": [], "status": "todo",
        })
        client.post("/api/v2/projects/e2e-proj-b/objectives", json={
            "id": obj_b, "title": "Obj B", "description": "...",
            "acceptance_criteria": [], "status": "todo",
        })

        r_a = client.get("/api/v2/projects/e2e-proj-a/objectives")
        r_b = client.get("/api/v2/projects/e2e-proj-b/objectives")

        ids_a = [o["id"] for o in r_a.json()["objectives"]]
        ids_b = [o["id"] for o in r_b.json()["objectives"]]

        self.assertIn(obj_a, ids_a)
        self.assertNotIn(obj_b, ids_a)
        self.assertIn(obj_b, ids_b)
        self.assertNotIn(obj_a, ids_b)

    def test_both_projects_in_list(self) -> None:
        r = client.get("/api/v2/projects")
        ids = [p["id"] for p in r.json()["projects"]]
        self.assertIn("e2e-proj-a", ids)
        self.assertIn("e2e-proj-b", ids)


if __name__ == "__main__":
    unittest.main()
