"""Paddock V2 API integration tests using FastAPI TestClient."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "admin" / "backend"))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import os

# Use a temp DB for tests
_tmp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp_db.close()
os.environ["PADDOCK_DB_PATH"] = _tmp_db.name

from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)


class TestProjectsAPI(unittest.TestCase):
    def setUp(self) -> None:
        # Clean slate: delete test project if exists
        client.delete("/api/v2/projects/test-proj")

    def test_list_projects_empty(self) -> None:
        r = client.get("/api/v2/projects")
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertIn("projects", data)
        self.assertIsInstance(data["projects"], list)

    def test_create_and_get_project(self) -> None:
        payload = {
            "id": "test-proj",
            "name": "Test Project",
            "repo_root": "../test",
            "worktrees_root": "../test-wt",
        }
        r = client.post("/api/v2/projects", json=payload)
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertTrue(data["ok"])
        self.assertEqual(data["project"]["id"], "test-proj")

        # Verify it appears in list
        r = client.get("/api/v2/projects")
        ids = [p["id"] for p in r.json()["projects"]]
        self.assertIn("test-proj", ids)

    def test_create_project_missing_fields(self) -> None:
        r = client.post("/api/v2/projects", json={"id": "bad"})
        self.assertEqual(r.status_code, 400)

    def test_update_project(self) -> None:
        client.post("/api/v2/projects", json={
            "id": "test-proj", "name": "Old Name",
            "repo_root": "../x", "worktrees_root": "../xwt",
        })
        r = client.put("/api/v2/projects/test-proj", json={
            "name": "New Name", "repo_root": "../x", "worktrees_root": "../xwt",
        })
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["project"]["name"], "New Name")

    def test_update_nonexistent_project(self) -> None:
        r = client.put("/api/v2/projects/does-not-exist", json={"name": "X", "repo_root": "../x", "worktrees_root": "../xwt"})
        self.assertEqual(r.status_code, 404)

    def test_delete_project(self) -> None:
        client.post("/api/v2/projects", json={
            "id": "test-proj", "name": "To Delete",
            "repo_root": "../x", "worktrees_root": "../xwt",
        })
        r = client.delete("/api/v2/projects/test-proj")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json()["ok"])

    def test_snapshot_not_found(self) -> None:
        r = client.get("/api/v2/projects/nonexistent/snapshot")
        self.assertEqual(r.status_code, 404)

    def test_snapshot_structure(self) -> None:
        client.post("/api/v2/projects", json={
            "id": "test-proj", "name": "Snap Test",
            "repo_root": "../x", "worktrees_root": "../xwt",
        })
        r = client.get("/api/v2/projects/test-proj/snapshot")
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertIn("project", data)
        self.assertIn("objectives", data)
        self.assertIn("sessions", data)
        self.assertIn("pipeline_state", data)
        self.assertIn("events", data)
        self.assertEqual(data["pipeline_state"], "idle")


class TestAgentsAPI(unittest.TestCase):
    def setUp(self) -> None:
        # Ensure seed agents exist
        client.delete("/api/v2/agents/test-agent")

    def test_list_agents(self) -> None:
        r = client.get("/api/v2/agents")
        self.assertEqual(r.status_code, 200)
        self.assertIn("agents", r.json())

    def test_create_agent(self) -> None:
        payload = {
            "id": "test-agent",
            "name": "Test Agent",
            "cli_command": "test-cli",
            "command_template": "test-cli -p {prompt_file}",
        }
        r = client.post("/api/v2/agents", json=payload)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["agent"]["id"], "test-agent")

    def test_create_duplicate_agent_fails(self) -> None:
        payload = {
            "id": "test-agent",
            "name": "Test Agent",
            "cli_command": "test-cli",
            "command_template": "test-cli -p {prompt_file}",
        }
        client.post("/api/v2/agents", json=payload)
        r = client.post("/api/v2/agents", json=payload)
        self.assertEqual(r.status_code, 400)

    def test_get_agent(self) -> None:
        client.post("/api/v2/agents", json={
            "id": "test-agent", "name": "TA",
            "cli_command": "cli", "command_template": "cli {prompt_file}",
        })
        r = client.get("/api/v2/agents/test-agent")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["agent"]["id"], "test-agent")

    def test_get_nonexistent_agent(self) -> None:
        r = client.get("/api/v2/agents/does-not-exist")
        self.assertEqual(r.status_code, 404)

    def test_update_agent(self) -> None:
        client.post("/api/v2/agents", json={
            "id": "test-agent", "name": "Old",
            "cli_command": "cli", "command_template": "cli {prompt_file}",
        })
        r = client.put("/api/v2/agents/test-agent", json={"name": "New"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["agent"]["name"], "New")

    def test_delete_agent(self) -> None:
        client.post("/api/v2/agents", json={
            "id": "test-agent", "name": "Del",
            "cli_command": "cli", "command_template": "cli {prompt_file}",
        })
        r = client.delete("/api/v2/agents/test-agent")
        self.assertEqual(r.status_code, 200)
        # Verify gone
        r2 = client.get("/api/v2/agents/test-agent")
        self.assertEqual(r2.status_code, 404)


class TestWorkersAPI(unittest.TestCase):
    def setUp(self) -> None:
        client.delete("/api/v2/workers/test-worker")

    def test_list_workers(self) -> None:
        r = client.get("/api/v2/workers")
        self.assertEqual(r.status_code, 200)
        self.assertIn("workers", r.json())

    def test_create_worker(self) -> None:
        payload = {
            "id": "test-worker",
            "name": "Test Worker",
            "role_type": "implementer",
            "strategy": {"mode": "fixed", "fixed_agent": "claude"},
        }
        r = client.post("/api/v2/workers", json=payload)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["worker"]["id"], "test-worker")

    def test_update_worker_strategy(self) -> None:
        client.post("/api/v2/workers", json={
            "id": "test-worker", "name": "TW", "role_type": "implementer",
            "strategy": {"mode": "fixed", "fixed_agent": "claude"},
        })
        r = client.put("/api/v2/workers/test-worker/strategy", json={
            "mode": "auto", "agent_priority": ["claude", "codex"],
        })
        self.assertEqual(r.status_code, 200)

    def test_delete_worker(self) -> None:
        client.post("/api/v2/workers", json={
            "id": "test-worker", "name": "TW", "role_type": "implementer",
            "strategy": {"mode": "fixed", "fixed_agent": "claude"},
        })
        r = client.delete("/api/v2/workers/test-worker")
        self.assertEqual(r.status_code, 200)


class TestObjectivesAPI(unittest.TestCase):
    PROJECT_ID = "obj-test-proj"

    def setUp(self) -> None:
        client.post("/api/v2/projects", json={
            "id": self.PROJECT_ID, "name": "Obj Test",
            "repo_root": "../x", "worktrees_root": "../xwt",
        })

    def tearDown(self) -> None:
        client.delete(f"/api/v2/projects/{self.PROJECT_ID}")

    def test_list_objectives_empty(self) -> None:
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/objectives")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["objectives"], [])

    def test_create_objective(self) -> None:
        import uuid
        obj_id = f"obj-{uuid.uuid4().hex[:8]}"
        payload = {
            "id": obj_id,
            "title": "Test Objective",
            "description": "Do something useful",
            "acceptance_criteria": ["Criterion 1", "Criterion 2"],
            "status": "todo",
        }
        r = client.post(f"/api/v2/projects/{self.PROJECT_ID}/objectives", json=payload)
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertEqual(data["objective"]["id"], obj_id)
        self.assertEqual(data["objective"]["title"], "Test Objective")

    def test_list_objectives_with_filter(self) -> None:
        client.post(f"/api/v2/projects/{self.PROJECT_ID}/objectives", json={
            "id": "obj-todo", "title": "Todo", "description": "...",
            "acceptance_criteria": [], "status": "todo",
        })
        client.post(f"/api/v2/projects/{self.PROJECT_ID}/objectives", json={
            "id": "obj-done", "title": "Done", "description": "...",
            "acceptance_criteria": [], "status": "done",
        })
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/objectives?status=todo")
        self.assertEqual(r.status_code, 200)
        objs = r.json()["objectives"]
        self.assertTrue(all(o["status"] == "todo" for o in objs))

    def test_update_objective(self) -> None:
        client.post(f"/api/v2/projects/{self.PROJECT_ID}/objectives", json={
            "id": "obj-upd", "title": "Old", "description": "...",
            "acceptance_criteria": [], "status": "todo",
        })
        r = client.put("/api/v2/objectives/obj-upd", json={"title": "New Title", "status": "ready"})
        self.assertEqual(r.status_code, 200)

    def test_delete_objective(self) -> None:
        client.post(f"/api/v2/projects/{self.PROJECT_ID}/objectives", json={
            "id": "obj-del", "title": "Del", "description": "...",
            "acceptance_criteria": [], "status": "todo",
        })
        r = client.delete("/api/v2/objectives/obj-del")
        self.assertEqual(r.status_code, 200)


class TestSessionsAPI(unittest.TestCase):
    PROJECT_ID = "sess-test-proj"

    def setUp(self) -> None:
        client.post("/api/v2/projects", json={
            "id": self.PROJECT_ID, "name": "Sess Test",
            "repo_root": "../x", "worktrees_root": "../xwt",
        })

    def tearDown(self) -> None:
        client.delete(f"/api/v2/projects/{self.PROJECT_ID}")

    def test_list_sessions_empty(self) -> None:
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/sessions")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["sessions"], [])

    def test_get_nonexistent_session(self) -> None:
        r = client.get("/api/v2/sessions/99999")
        self.assertEqual(r.status_code, 404)


class TestGoalsAPI(unittest.TestCase):
    PROJECT_ID = "goals-test-proj"

    def setUp(self) -> None:
        client.post("/api/v2/projects", json={
            "id": self.PROJECT_ID, "name": "Goals Test",
            "repo_root": "../x", "worktrees_root": "../xwt",
        })

    def tearDown(self) -> None:
        client.delete(f"/api/v2/projects/{self.PROJECT_ID}")

    def test_get_goals_empty(self) -> None:
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/goals")
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertIn("goal", data)
        self.assertIn("milestone", data)
        self.assertIn("phase", data)

    def test_create_goal(self) -> None:
        r = client.put(f"/api/v2/projects/{self.PROJECT_ID}/goals", json={
            "goal": {
                "id": "g-001",
                "title": "Build something great",
                "description": "A long-term vision",
                "status": "active",
            }
        })
        self.assertEqual(r.status_code, 200)
        # Verify
        r2 = client.get(f"/api/v2/projects/{self.PROJECT_ID}/goals")
        self.assertEqual(r2.json()["goal"]["title"], "Build something great")


class TestEventsAPI(unittest.TestCase):
    PROJECT_ID = "events-test-proj"

    def setUp(self) -> None:
        client.post("/api/v2/projects", json={
            "id": self.PROJECT_ID, "name": "Events Test",
            "repo_root": "../x", "worktrees_root": "../xwt",
        })

    def tearDown(self) -> None:
        client.delete(f"/api/v2/projects/{self.PROJECT_ID}")

    def test_list_events_empty(self) -> None:
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/events")
        self.assertEqual(r.status_code, 200)
        self.assertIn("events", r.json())


class TestFlowConfigAPI(unittest.TestCase):
    PROJECT_ID = "flow-test-proj"

    def setUp(self) -> None:
        client.post("/api/v2/projects", json={
            "id": self.PROJECT_ID, "name": "Flow Test",
            "repo_root": "../x", "worktrees_root": "../xwt",
        })

    def tearDown(self) -> None:
        client.delete(f"/api/v2/projects/{self.PROJECT_ID}")

    def test_get_flow_config(self) -> None:
        r = client.get(f"/api/v2/projects/{self.PROJECT_ID}/flow-config")
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertIn("scope_level", data)
        self.assertIn("max_commits_per_session", data)
        self.assertIn("max_minutes_per_session", data)
        self.assertIn("max_parallel_sessions", data)

    def test_update_flow_config(self) -> None:
        r = client.put(f"/api/v2/projects/{self.PROJECT_ID}/flow-config", json={
            "scope_level": "strict",
            "max_commits_per_session": 3,
            "max_minutes_per_session": 20,
            "max_parallel_sessions": 1,
        })
        self.assertEqual(r.status_code, 200)
        # Verify
        r2 = client.get(f"/api/v2/projects/{self.PROJECT_ID}/flow-config")
        self.assertEqual(r2.json()["max_parallel_sessions"], 1)


if __name__ == "__main__":
    unittest.main()
