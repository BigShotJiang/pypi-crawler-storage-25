"""Tests for planner output parsing."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


class TestPlannerParser(unittest.TestCase):
    def test_parse_yaml_objectives(self) -> None:
        raw = """
reasoning: |
  Need to implement combat system
objectives:
  - id: combat-damage
    title: Implement damage calculation
    description: |
      Create a damage formula and apply it to combat actions.
    acceptance_criteria:
      - Damage formula exists in src/combat/damage.py
      - Unit tests pass
    path_scope:
      - "src/combat/**"
    depends_on: []
    worker_id: implementer
    priority: 0
"""
        # The actual parse function is inside supervisor_v2 as _parse_planner_objectives
        from scripts.supervisor_v2 import _parse_planner_objectives

        objectives = _parse_planner_objectives(raw)
        self.assertEqual(len(objectives), 1)
        self.assertEqual(objectives[0]["id"], "combat-damage")
        self.assertEqual(objectives[0]["title"], "Implement damage calculation")
        self.assertEqual(objectives[0]["acceptance_criteria"], [
            "Damage formula exists in src/combat/damage.py",
            "Unit tests pass",
        ])

    def test_parse_empty_objectives(self) -> None:
        from scripts.supervisor_v2 import _parse_planner_objectives
        objectives = _parse_planner_objectives("no yaml here")
        self.assertEqual(len(objectives), 0)


if __name__ == "__main__":
    unittest.main()
