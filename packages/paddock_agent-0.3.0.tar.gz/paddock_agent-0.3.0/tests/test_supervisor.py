"""Tests for supervisor_v2 core logic."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from paddock.db import PaddockDB
from paddock.utils import pid_alive


class MockDB:
    """Lightweight mock for testing supervisor logic without real DB."""

    def __init__(self):
        self.objectives: list[dict] = []
        self.sessions: list[dict] = []
        self.checkpoints: list[dict] = []
        self.events: list[dict] = []

    def list_objectives(self, project_id: str, status: list[str] | None = None):
        objs = [o for o in self.objectives if o["project_id"] == project_id]
        if status:
            objs = [o for o in objs if o["status"] in status]
        return objs

    def get_objective(self, objective_id: str):
        for o in self.objectives:
            if o["id"] == objective_id:
                return o
        return None

    def update_objective(self, objective_id: str, fields: dict) -> None:
        o = self.get_objective(objective_id)
        if o:
            o.update(fields)

    def get_active_sessions(self, project_id: str):
        return [s for s in self.sessions if s["project_id"] == project_id and s["status"] == "running"]

    def get_session(self, session_id: int):
        for s in self.sessions:
            if s["id"] == session_id:
                return s
        return None

    def update_session(self, session_id: int, fields: dict) -> None:
        s = self.get_session(session_id)
        if s:
            s.update(fields)

    def list_checkpoints(self, session_id: int):
        return [c for c in self.checkpoints if c["session_id"] == session_id]

    def add_checkpoint(self, cp: dict) -> int:
        cp_id = len(self.checkpoints) + 1
        cp["id"] = cp_id
        self.checkpoints.append(cp)
        return cp_id

    def emit_event(self, project_id: str | None, event_type: str, payload: dict | None = None) -> int:
        self.events.append({"project_id": project_id, "type": event_type, "payload": payload or {}})
        return len(self.events)

    def get_latest_planner_run(self, project_id: str):
        return None

    def get_active_goal(self, project_id: str):
        return {"id": "g-1", "title": "Test Goal", "status": "active"}

    def get_active_phase(self, project_id: str):
        return {"id": "p-1", "title": "Test Phase", "status": "active", "milestone_id": "m-1"}

    def list_goals(self, project_id: str):
        return [{"id": "g-1", "status": "active"}]

    def list_phase_checks(self, phase_id: str, project_id: str):
        return []  # No checks by default in tests


class TestSupervisorLogic(unittest.TestCase):
    def test_unlock_ready_objectives(self) -> None:
        from scripts.supervisor_v2 import unlock_ready_objectives

        db = MockDB()
        db.objectives = [
            {"id": "obj-1", "project_id": "p1", "status": "done", "depends_on": "[]"},
            {"id": "obj-2", "project_id": "p1", "status": "todo", "depends_on": json.dumps(["obj-1"])},
            {"id": "obj-3", "project_id": "p1", "status": "todo", "depends_on": json.dumps(["obj-1", "obj-2"])},
        ]

        unlocked = unlock_ready_objectives(db, {"id": "p1"})
        self.assertIn("obj-2", unlocked)
        self.assertNotIn("obj-3", unlocked)
        self.assertEqual(db.get_objective("obj-2")["status"], "ready")

    def test_planner_needed(self) -> None:
        from scripts.supervisor_v2 import planner_needed

        db = MockDB()
        db.objectives = [
            {"id": "obj-1", "project_id": "p1", "status": "ready"},
        ]
        project = {"id": "p1", "max_parallel_sessions": 2}
        self.assertTrue(planner_needed(db, project, cooldown_seconds=0))

        db.objectives.append({"id": "obj-2", "project_id": "p1", "status": "active"})
        # obj-2 is an objective, not a session, so active sessions remain 0
        self.assertTrue(planner_needed(db, project, cooldown_seconds=0))

        db.sessions.append({"id": 1, "project_id": "p1", "status": "running", "objective_id": "obj-2"})
        self.assertFalse(planner_needed(db, project, cooldown_seconds=0))

    def test_pid_alive(self) -> None:
        import os
        self.assertTrue(pid_alive(os.getpid()))
        self.assertFalse(pid_alive(999999))


if __name__ == "__main__":
    unittest.main()
