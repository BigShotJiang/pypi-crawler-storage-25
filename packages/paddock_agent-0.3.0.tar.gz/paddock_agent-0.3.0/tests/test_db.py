"""Tests for paddock.db module."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from paddock.db import PaddockDB


class TestPaddockDB(unittest.TestCase):
    def setUp(self) -> None:
        self.db_path = Path(tempfile.mktemp(suffix=".db"))
        self.db = PaddockDB(self.db_path)
        self.db.initialize()

    def tearDown(self) -> None:
        if self.db_path.exists():
            self.db_path.unlink()

    def test_project_crud(self) -> None:
        self.db.upsert_project({
            "id": "test-proj",
            "name": "Test Project",
            "repo_root": "../test",
            "worktrees_root": "../test-wt",
        })
        proj = self.db.get_project("test-proj")
        self.assertIsNotNone(proj)
        self.assertEqual(proj["name"], "Test Project")

        self.db.upsert_project({"id": "test-proj", "name": "Updated", "repo_root": "../test", "worktrees_root": "../test-wt"})
        proj = self.db.get_project("test-proj")
        self.assertEqual(proj["name"], "Updated")

        active = self.db.list_active_projects()
        self.assertEqual(len(active), 1)

        self.db.delete_project("test-proj")
        self.assertIsNone(self.db.get_project("test-proj"))

    def test_agent_crud(self) -> None:
        self.db.upsert_agent({
            "id": "claude",
            "name": "Claude",
            "cli_command": "claude",
            "command_template": "claude -p {prompt_file}",
        })
        agent = self.db.get_agent("claude")
        self.assertIsNotNone(agent)
        self.assertEqual(agent["name"], "Claude")

        agents = self.db.list_agents(enabled_only=True)
        self.assertEqual(len(agents), 1)

        self.db.delete_agent("claude")
        self.assertIsNone(self.db.get_agent("claude"))

    def test_worker_crud(self) -> None:
        self.db.upsert_worker({
            "id": "dev",
            "name": "Developer",
            "role_type": "implementer",
            "strategy_mode": "fixed",
            "strategy_fixed_agent": "claude",
        })
        worker = self.db.get_worker("dev")
        self.assertIsNotNone(worker)
        self.assertEqual(worker["name"], "Developer")

    def test_objective_crud(self) -> None:
        self.db.upsert_project({
            "id": "p1", "name": "P1", "repo_root": "../p1", "worktrees_root": "../p1-wt"
        })
        self.db.create_objective({
            "id": "obj-1",
            "project_id": "p1",
            "title": "Test Objective",
            "description": "Do something",
            "acceptance_criteria": json.dumps(["criteria 1"]),
            "status": "todo",
        })
        obj = self.db.get_objective("obj-1")
        self.assertIsNotNone(obj)
        self.assertEqual(obj["title"], "Test Objective")

        self.db.update_objective("obj-1", {"status": "ready"})
        obj = self.db.get_objective("obj-1")
        self.assertEqual(obj["status"], "ready")

        ready = self.db.get_ready_objectives("p1", max_count=10)
        self.assertEqual(len(ready), 1)

        self.db.delete_objective("obj-1")
        self.assertIsNone(self.db.get_objective("obj-1"))

    def test_session_and_checkpoints(self) -> None:
        self.db.upsert_project({
            "id": "p1", "name": "P1", "repo_root": "../p1", "worktrees_root": "../p1-wt"
        })
        self.db.create_objective({
            "id": "obj-1", "project_id": "p1", "title": "T", "description": "D",
            "acceptance_criteria": json.dumps([]), "status": "active",
        })
        sid = self.db.create_session({
            "objective_id": "obj-1",
            "project_id": "p1",
            "status": "running",
            "budget": json.dumps({"max_commits": 5, "max_minutes": 30}),
        })
        self.assertIsInstance(sid, int)

        session = self.db.get_session(sid)
        self.assertIsNotNone(session)
        self.assertEqual(session["status"], "running")

        active = self.db.get_active_sessions("p1")
        self.assertEqual(len(active), 1)

        cp_id = self.db.add_checkpoint({
            "session_id": sid,
            "objective_id": "obj-1",
            "commit_hash": "abc123",
            "files_changed": json.dumps(["a.py"]),
        })
        self.assertIsInstance(cp_id, int)

        cps = self.db.list_checkpoints(sid)
        self.assertEqual(len(cps), 1)
        self.assertEqual(cps[0]["commit_hash"], "abc123")

    def test_events(self) -> None:
        self.db.emit_event("p1", "test_event", {"foo": "bar"})
        events = self.db.list_events("p1", limit=10)
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["type"], "test_event")

    def test_planner_runs(self) -> None:
        self.db.upsert_project({
            "id": "p1", "name": "P1", "repo_root": "../p1", "worktrees_root": "../p1-wt"
        })
        rid = self.db.create_planner_run({
            "project_id": "p1",
            "status": "running",
            "pid": 1234,
        })
        self.assertIsInstance(rid, int)

        latest = self.db.get_latest_planner_run("p1")
        self.assertIsNotNone(latest)
        self.assertEqual(latest["status"], "running")


if __name__ == "__main__":
    unittest.main()
