from __future__ import annotations

import argparse
import json
import subprocess
import time
from datetime import datetime, timezone
from fnmatch import fnmatch
from pathlib import Path

from common import (
    BOARD_PATH,
    CONTEXT,
    REVIEWS_PATH,
    TASKS_PATH,
    changed_files_for_branch,
    coordinator_state_path,
    emit_event,
    ensure_runtime_dirs,
    git_head,
    load_tasks,
    path_conflict,
    pid_alive,
    read_json,
    run_command,
    run_state_path,
    resolve_worktree,
    save_tasks,
    task_ready,
    working_tree_clean,
    write_json,
)

SCRIPT_DIR = Path(__file__).resolve().parent


def parse_iso_timestamp(value: str | None) -> float | None:
    if not value:
        return None
    normalized = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized).timestamp()
    except ValueError:
        return None


def refresh_finished_runs(task_data: dict) -> list[str]:
    finished: list[str] = []
    for task in task_data["tasks"]:
        if task.get("status") != "in_progress":
            continue
        run_file = run_state_path(task["id"])
        if not run_file.exists():
            continue
        payload = read_json(run_file)
        pid = payload.get("pid")
        if payload.get("dry_run"):
            continue
        if not pid or pid_alive(int(pid)):
            continue
        task["status"] = "review"
        payload["status"] = "review"
        payload["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        run_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        emit_event("task_finished", task_id=task["id"], status=task["status"], pid=pid)
        finished.append(task["id"])
    return finished


def append_review_log(task_id: str, status: str, note: str) -> None:
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%SZ")
    with REVIEWS_PATH.open("a", encoding="utf-8") as handle:
        handle.write(f"\n### auto-review `{task_id}` @ {timestamp}\n\n")
        handle.write(f"- status: `{status}`\n")
        handle.write(f"- note: {note}\n")


def rewrite_board(task_data: dict) -> None:
    merged = [task["id"] for task in task_data["tasks"] if task.get("status") == "merged"]
    ready = [task["id"] for task in task_data["tasks"] if task.get("status") == "ready"]
    in_progress = [task["id"] for task in task_data["tasks"] if task.get("status") == "in_progress"]
    review = [task["id"] for task in task_data["tasks"] if task.get("status") == "review"]
    blocked = [task["id"] for task in task_data["tasks"] if task.get("status") == "blocked"]
    lines = [
        "# Board",
        "",
        f"Project: `{CONTEXT.name}`",
        f"Repo: `{CONTEXT.repo_root}`",
        f"Runtime: `{CONTEXT.runtime_root}`",
        "",
        "## Current Round",
        "",
        "Merged:",
        "",
    ]
    lines.extend([f"- `{item}`" for item in merged] or ["- None"])
    lines.extend(["", "Ready next:", ""])
    lines.extend([f"- `{item}`" for item in ready] or ["- None"])
    lines.extend(["", "In progress:", ""])
    lines.extend([f"- `{item}`" for item in in_progress] or ["- None"])
    lines.extend(["", "Review queue:", ""])
    lines.extend([f"- `{item}`" for item in review] or ["- None"])
    lines.extend(["", "Blocked:", ""])
    lines.extend([f"- `{item}`" for item in blocked] or ["- None"])
    BOARD_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def auto_review_merge(task: dict) -> tuple[str, str]:
    branch = task.get("branch")
    if not branch:
        return "review", "No branch configured; requires integrator."
    if not working_tree_clean():
        return "review", "Main worktree is dirty; skipping auto-merge."
    changed_files = changed_files_for_branch(branch)
    if not changed_files:
        return "blocked", "Branch has no diff against main."
    for changed in changed_files:
        if not any(fnmatch(changed, scope) for scope in task.get("path_scope", [])):
            return "review", f"Changed file outside path_scope: {changed}"
        if any(fnmatch(changed, pattern) for pattern in CONTEXT.integrator_only_patterns):
            return "review", f"Changed integrator-only file: {changed}"

    verification = task.get("automation", {}).get("verify", [])
    worktree_path = resolve_worktree(task)
    for command in verification:
        result = run_command(["/bin/zsh", "-lc", command], cwd=worktree_path, check=False)
        if result.returncode != 0:
            return "blocked", f"Verification failed: {command}"

    before = git_head()
    merge_message = f"Auto-merge task '{task['id']}' from branch '{branch}'"
    run_command(["git", "merge", "--no-ff", branch, "-m", merge_message], cwd=CONTEXT.repo_root)
    after = git_head()
    task["status"] = "merged"
    task.setdefault("review", {})
    task["review"]["decision"] = "merge"
    task["review"]["merged_commit"] = after
    task["review"]["reviewed_branch_head"] = before
    run_file = run_state_path(task["id"])
    if run_file.exists():
        payload = read_json(run_file)
        payload["status"] = "merged"
        payload["merged_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        payload["merged_commit"] = after
        write_json(run_file, payload)
    return "merged", f"Merged branch {branch} into main at {after}."


def process_review_queue(task_data: dict) -> list[str]:
    results: list[str] = []
    for task in task_data["tasks"]:
        if task.get("status") != "review":
            continue
        decision, note = auto_review_merge(task)
        review_meta = task.setdefault("review", {})
        last_auto_status = review_meta.get("last_auto_status")
        last_auto_note = review_meta.get("last_auto_note")
        if decision == "merged":
            results.append(task["id"])
            append_review_log(task["id"], "merge", note)
            emit_event("task_merged", task_id=task["id"], note=note, branch=task.get("branch", ""))
            review_meta["last_auto_status"] = "merge"
            review_meta["last_auto_note"] = note
        elif decision == "blocked":
            task["status"] = "blocked"
            if last_auto_status != "blocked" or last_auto_note != note:
                append_review_log(task["id"], "blocked", note)
                emit_event("task_blocked", task_id=task["id"], note=note)
            review_meta["last_auto_status"] = "blocked"
            review_meta["last_auto_note"] = note
        else:
            if last_auto_status != "review" or last_auto_note != note:
                append_review_log(task["id"], "review", note)
                emit_event("task_review_required", task_id=task["id"], note=note)
            review_meta["last_auto_status"] = "review"
            review_meta["last_auto_note"] = note
    return results


def unlock_ready_tasks(task_data: dict) -> list[str]:
    task_map = {task["id"]: task for task in task_data["tasks"]}
    unlocked: list[str] = []
    for task in task_data["tasks"]:
        if task.get("status") != "todo":
            continue
        deps = task.get("depends_on", [])
        if deps and all(task_map[dep].get("status") == "merged" for dep in deps):
            task["status"] = "ready"
            emit_event("task_ready", task_id=task["id"], depends_on=deps)
            unlocked.append(task["id"])
    return unlocked


def active_tasks(task_data: dict) -> list[dict]:
    return [task for task in task_data["tasks"] if task.get("status") == "in_progress"]


def ready_tasks(task_data: dict) -> list[dict]:
    task_map = {task["id"]: task for task in task_data["tasks"]}
    return [task for task in task_data["tasks"] if task_ready(task, task_map)]


def next_ready_tasks(task_data: dict, max_parallel: int) -> list[dict]:
    task_map = {task["id"]: task for task in task_data["tasks"]}
    running = active_tasks(task_data)
    available_slots = max_parallel - len(running)
    if available_slots <= 0:
        return []

    selected: list[dict] = []
    for task in task_data["tasks"]:
        if not task_ready(task, task_map):
            continue
        candidate_scope = task.get("path_scope", [])
        if any(path_conflict(candidate_scope, other.get("path_scope", [])) for other in running + selected):
            continue
        selected.append(task)
        if len(selected) >= available_slots:
            break
    return selected


def dispatch(task_id: str, dry_run: bool) -> None:
    base = [str(SCRIPT_DIR / "dispatch_task.py"), task_id]
    run = [str(SCRIPT_DIR / "run_agent.py"), task_id]
    if dry_run:
        base.append("--dry-run")
        run.append("--dry-run")
    subprocess.run(["python3", *base], cwd=str(FRAMEWORK_ROOT), check=True)
    subprocess.run(["python3", *run], cwd=str(FRAMEWORK_ROOT), check=True)


def load_coordinator_state() -> dict | None:
    path = coordinator_state_path()
    if not path.exists():
        return None
    return read_json(path)


def save_coordinator_state(state: dict) -> None:
    write_json(coordinator_state_path(), state)


def coordinator_needed(task_data: dict, min_ready_threshold: int) -> bool:
    if any(task.get("status") == "review" for task in task_data["tasks"]):
        return False
    supply = len(ready_tasks(task_data)) + len(active_tasks(task_data))
    return supply < min_ready_threshold


def coordinator_in_progress() -> bool:
    state = load_coordinator_state()
    if not state:
        return False
    if state.get("status") != "in_progress":
        return False
    pid = state.get("pid")
    return bool(pid and pid_alive(int(pid)))


def coordinator_in_cooldown(cooldown_seconds: int) -> bool:
    state = load_coordinator_state()
    if not state:
        return False
    if state.get("status") == "in_progress":
        return True
    if cooldown_seconds <= 0:
        return False
    last_ts = (
        parse_iso_timestamp(state.get("finished_at"))
        or parse_iso_timestamp(state.get("started_at"))
        or parse_iso_timestamp(state.get("applied_at"))
    )
    if last_ts is None:
        return False
    return (time.time() - last_ts) < cooldown_seconds


def start_coordinator(dry_run: bool, objective: str, min_ready_threshold: int) -> None:
    command = [
        "python3",
        str(SCRIPT_DIR / "run_coordinator.py"),
        "--objective",
        objective,
        "--min-ready",
        str(min_ready_threshold),
    ]
    if dry_run:
        command.append("--dry-run")
    subprocess.run(command, cwd=str(FRAMEWORK_ROOT), check=True)


def process_coordinator_plan(dry_run: bool) -> list[str]:
    state = load_coordinator_state()
    if not state:
        return []
    if state.get("status") == "in_progress":
        pid = state.get("pid")
        if pid and pid_alive(int(pid)):
            return []
        state["status"] = "finished"
        state["finished_at"] = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
        save_coordinator_state(state)
        emit_event("coordinator_finished", plan_file=state.get("plan_file", ""), pid=pid)

    if state.get("applied"):
        return []

    plan_file = state.get("plan_file")
    if not plan_file:
        state["status"] = "blocked"
        state["error"] = "Coordinator finished without plan_file"
        save_coordinator_state(state)
        emit_event("coordinator_blocked", reason="missing plan_file")
        return []

    plan_path = FRAMEWORK_ROOT / plan_file
    if not plan_path.exists():
        state["status"] = "blocked"
        state["error"] = f"Coordinator finished without writing plan file: {plan_file}"
        save_coordinator_state(state)
        emit_event("coordinator_blocked", reason="missing_plan_file", plan_file=plan_file)
        return []

    command = ["python3", str(SCRIPT_DIR / "apply_plan.py"), "--plan", str(plan_path)]
    if dry_run:
        command.append("--dry-run")
    result = subprocess.run(command, cwd=str(FRAMEWORK_ROOT), text=True, capture_output=True, check=False)
    if result.returncode != 0:
        state["status"] = "blocked"
        state["error"] = result.stderr or result.stdout or "apply_plan failed"
        save_coordinator_state(state)
        emit_event("coordinator_blocked", reason="apply_plan_failed", detail=state["error"])
        return []

    applied_changes = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    state["applied"] = True
    state["status"] = "applied"
    state["applied_at"] = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    state["applied_changes"] = applied_changes
    save_coordinator_state(state)
    emit_event("coordinator_applied", plan_file=plan_file, changes=applied_changes)
    return applied_changes


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Paddock supervisor loop.")
    parser.add_argument("--duration-minutes", type=int, default=60)
    parser.add_argument("--poll-seconds", type=int, default=20)
    parser.add_argument("--max-parallel", type=int, default=2)
    parser.add_argument("--min-ready-threshold", type=int, default=1)
    parser.add_argument("--coordinator-cooldown-seconds", type=int, default=300)
    parser.add_argument("--coordinator-objective", default="保持流水线持续推进，并补充下一批可执行任务。")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()

    ensure_runtime_dirs()
    deadline = time.time() + args.duration_minutes * 60

    while True:
        task_data = load_tasks()
        finished = refresh_finished_runs(task_data)
        merged = process_review_queue(task_data)
        applied_changes = process_coordinator_plan(args.dry_run)
        if applied_changes:
            task_data = load_tasks()
        unlocked = unlock_ready_tasks(task_data)
        ready = next_ready_tasks(task_data, args.max_parallel)
        rewrite_board(task_data)
        save_tasks(task_data)

        if finished:
            print("Finished tasks moved to review:", ", ".join(finished))
        if merged:
            print("Auto-merged tasks:", ", ".join(merged))
        if applied_changes:
            print("Applied coordinator plan:", ", ".join(applied_changes))
        if unlocked:
            print("Unlocked ready tasks:", ", ".join(unlocked))

        if (
            coordinator_needed(task_data, args.min_ready_threshold)
            and not coordinator_in_progress()
            and not coordinator_in_cooldown(args.coordinator_cooldown_seconds)
        ):
            print("Starting coordinator...")
            start_coordinator(args.dry_run, args.coordinator_objective, args.min_ready_threshold)
            applied_changes = process_coordinator_plan(args.dry_run)
            if applied_changes:
                task_data = load_tasks()
                ready = next_ready_tasks(task_data, args.max_parallel)
                rewrite_board(task_data)
                save_tasks(task_data)
                print("Applied coordinator plan:", ", ".join(applied_changes))

        if ready:
            print("Dispatching:", ", ".join(task["id"] for task in ready))
            for task in ready:
                dispatch(task["id"], dry_run=args.dry_run)
        else:
            print("No ready task to dispatch.")

        if args.once:
            break
        if time.time() >= deadline:
            print("Supervisor duration reached.")
            break
        time.sleep(args.poll_seconds)


if __name__ == "__main__":
    from common import FRAMEWORK_ROOT

    main()
