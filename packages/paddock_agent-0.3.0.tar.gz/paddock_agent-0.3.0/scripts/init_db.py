#!/usr/bin/env python3
"""Initialize Paddock V2 database with schema and seed data."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

try:
    import paddock  # noqa: F401 — already installed via pip
except ImportError:
    # Running from source tree: add repo root to path
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from paddock.db import PaddockDB
from paddock.config import DB_PATH


def seed_default_agents(db: PaddockDB) -> None:
    """Insert default agent configurations."""
    agents = [
        {
            "id": "claude",
            "name": "Claude",
            "cli_command": "claude",
            "command_template": "claude --dangerously-skip-permissions -p {prompt_file}",
            "description": "Anthropic Claude CLI agent",
            "supported_features": ["code", "research", "review"],
            "enabled": True,
            "icon": "🟣",
            "color": "#7c3aed",
        },
        {
            "id": "codex",
            "name": "Codex",
            "cli_command": "codex",
            "command_template": "codex exec --dangerously-bypass-approvals-and-sandbox {prompt_file}",
            "description": "OpenAI Codex CLI agent",
            "supported_features": ["code", "research"],
            "enabled": True,
            "icon": "🟢",
            "color": "#10b981",
        },
    ]
    for a in agents:
        db.upsert_agent(a)
    print(f"  Seeded {len(agents)} agents")


def seed_default_workers(db: PaddockDB) -> None:
    """Insert default worker configurations."""
    workers = [
        {
            "id": "implementer",
            "name": "Implementer",
            "description": "Code implementation worker",
            "role_type": "implementer",
            "icon": "🔨",
            "color": "#3b82f6",
            "strategy": {"mode": "fixed", "fixed_agent": "claude"},
        },
        {
            "id": "researcher",
            "name": "Researcher",
            "description": "Research and analysis worker",
            "role_type": "researcher",
            "icon": "🔍",
            "color": "#8b5cf6",
            "strategy": {"mode": "fixed", "fixed_agent": "codex"},
        },
        {
            "id": "integrator",
            "name": "Integrator",
            "description": "Review and integration worker",
            "role_type": "integrator",
            "icon": "🔗",
            "color": "#f59e0b",
            "strategy": {"mode": "fixed", "fixed_agent": "claude"},
        },
    ]
    for w in workers:
        db.upsert_worker(w)
    print(f"  Seeded {len(workers)} workers")


def main() -> None:
    parser = argparse.ArgumentParser(description="Initialize Paddock V2 database.")
    parser.add_argument("--db", type=str, default=str(DB_PATH), help="Database file path")
    parser.add_argument("--seed", action="store_true", help="Insert default agent/worker seed data")
    parser.add_argument("--reset", action="store_true", help="Delete existing DB and recreate")
    args = parser.parse_args()

    db_path = Path(args.db)

    if args.reset and db_path.exists():
        db_path.unlink()
        print(f"Deleted existing database: {db_path}")

    db = PaddockDB(db_path)
    db.initialize()
    print(f"Database initialized: {db_path}")

    if args.seed:
        print("Seeding default data...")
        seed_default_agents(db)
        seed_default_workers(db)
        print("Done.")


if __name__ == "__main__":
    main()
