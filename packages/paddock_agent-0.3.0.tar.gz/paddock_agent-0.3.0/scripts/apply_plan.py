from __future__ import annotations

import argparse
from pathlib import Path

import yaml

from common import PLANS_DIR, emit_event, get_task, load_tasks, save_tasks


def latest_plan() -> Path:
    plans = sorted(PLANS_DIR.glob("*.yaml"))
    if not plans:
        raise FileNotFoundError(f"No coordinator plan file found in {PLANS_DIR}")
    return plans[-1]


def main() -> None:
    parser = argparse.ArgumentParser(description="Apply a structured coordinator plan to runtime tasks.")
    parser.add_argument("--plan", default="")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    plan_path = Path(args.plan).resolve() if args.plan else latest_plan()
    plan = yaml.safe_load(plan_path.read_text(encoding="utf-8")) or {}
    actions = plan.get("actions", [])
    if not isinstance(actions, list):
        raise ValueError("Plan file must contain a top-level 'actions' list")

    data = load_tasks()
    changed: list[str] = []
    for action in actions:
        action_type = action.get("type")
        if action_type == "add_task":
            task = action.get("task")
            if not isinstance(task, dict):
                task = {key: value for key, value in action.items() if key != "type"}
            if not task or "id" not in task:
                raise ValueError("add_task requires task.id")
            try:
                get_task(data, task["id"])
            except KeyError:
                data["tasks"].append(task)
                changed.append(f"add:{task['id']}")
            else:
                raise ValueError(f"Task already exists: {task['id']}")
        elif action_type == "update_task":
            task_id = action.get("task_id")
            fields = action.get("fields", {})
            task = get_task(data, task_id)
            task.update(fields)
            changed.append(f"update:{task_id}")
        else:
            raise ValueError(f"Unsupported action type: {action_type}")

    if args.dry_run:
        print("\n".join(changed))
        return

    save_tasks(data)
    emit_event("plan_applied", plan_file=str(plan_path), actions=changed)
    print("\n".join(changed))


if __name__ == "__main__":
    main()
