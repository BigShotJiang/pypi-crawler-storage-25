from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from fnmatch import fnmatch
from pathlib import Path
from typing import Any

import yaml


SCRIPT_DIR = Path(__file__).resolve().parent
FRAMEWORK_ROOT = Path(os.environ.get("PADDOCK_ROOT", SCRIPT_DIR.parent)).resolve()
PROJECTS_DIR = FRAMEWORK_ROOT / "projects"
RUNTIME_PROJECTS_DIR = FRAMEWORK_ROOT / "runtime" / "projects"
DEFAULT_PROJECT = os.environ.get("PADDOCK_PROJECT") or None
_proxy_url = os.environ.get("PADDOCK_PROXY", "")
DEFAULT_PROXY_ENV: dict[str, str] = (
    {
        "HTTP_PROXY": _proxy_url,
        "HTTPS_PROXY": _proxy_url,
        "ALL_PROXY": _proxy_url,
        "NO_PROXY": os.environ.get("PADDOCK_NO_PROXY", "localhost,127.0.0.1,::1"),
        "NODE_OPTIONS": "--use-env-proxy",
    }
    if _proxy_url
    else {}
)
DEFAULT_INTEGRATOR_ONLY_PATTERNS = [
    "README.md",
    "AGENTS.md",
    "CHECKPOINTS.md",
    "docs/rules-core.md",
    "docs/ai-architecture.md",
    "docs/tech-choices.md",
    ".paddock/**",
]


@dataclass(frozen=True)
class ProjectContext:
    slug: str
    name: str
    repo_root: Path
    worktrees_root: Path
    runtime_root: Path
    project_config_path: Path
    integrator_only_patterns: list[str]


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _load_yaml(path: Path) -> dict[str, Any]:
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def _project_config_path(slug: str) -> Path:
    override = os.environ.get("PADDOCK_PROJECT_CONFIG")
    if override:
        return Path(override).resolve()
    return (PROJECTS_DIR / f"{slug}.yaml").resolve()


def load_project_context(project_slug: str | None = None) -> ProjectContext:
    slug = project_slug or DEFAULT_PROJECT
    if not slug:
        raise ValueError(
            "No project specified. Set PADDOCK_PROJECT env var or pass --project <slug>."
        )
    config_path = _project_config_path(slug)
    config = _load_yaml(config_path)

    repo_root = Path(config["repo_root"]).resolve()
    worktrees_root = Path(config["worktrees_root"]).resolve()
    runtime_root = Path(config.get("runtime_root", RUNTIME_PROJECTS_DIR / slug)).resolve()

    patterns = list(DEFAULT_INTEGRATOR_ONLY_PATTERNS)
    patterns.extend(config.get("integrator_only_patterns", []))

    return ProjectContext(
        slug=slug,
        name=config.get("name", slug),
        repo_root=repo_root,
        worktrees_root=worktrees_root,
        runtime_root=runtime_root,
        project_config_path=config_path,
        integrator_only_patterns=patterns,
    )


CONTEXT = load_project_context(os.environ.get("PADDOCK_PROJECT"))
TASKS_PATH = CONTEXT.runtime_root / "tasks.yaml"
BOARD_PATH = CONTEXT.runtime_root / "board.md"
REVIEWS_PATH = CONTEXT.runtime_root / "reviews.md"
DISPATCH_DIR = CONTEXT.runtime_root / "dispatch"
RUNS_DIR = CONTEXT.runtime_root / "runs"
RUN_LOGS_DIR = RUNS_DIR / "logs"
LOCKS_DIR = CONTEXT.runtime_root / "locks"
PLANS_DIR = CONTEXT.runtime_root / "plans"
EVENTS_PATH = RUNS_DIR / "events.jsonl"
TEMPLATES_DIR = FRAMEWORK_ROOT / "templates"


def ensure_runtime_dirs() -> None:
    for path in (DISPATCH_DIR, RUNS_DIR, RUN_LOGS_DIR, LOCKS_DIR, PLANS_DIR):
        path.mkdir(parents=True, exist_ok=True)


def load_tasks() -> dict[str, Any]:
    with TASKS_PATH.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    if "tasks" not in data or not isinstance(data["tasks"], list):
        raise ValueError(f"{TASKS_PATH} is missing a top-level 'tasks' list")
    return data


def save_tasks(data: dict[str, Any]) -> None:
    with TASKS_PATH.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(data, handle, allow_unicode=True, sort_keys=False)


def get_task(data: dict[str, Any], task_id: str) -> dict[str, Any]:
    for task in data["tasks"]:
        if task["id"] == task_id:
            return task
    raise KeyError(f"Unknown task id: {task_id}")


def task_slug(task_id: str) -> str:
    return task_id.strip().replace("_", "-")


def default_branch(task_id: str) -> str:
    return f"wt/{task_slug(task_id)}"


def default_worktree(task_id: str) -> str:
    return str((CONTEXT.worktrees_root / task_slug(task_id)).resolve())


def resolve_worktree(task: dict[str, Any]) -> Path:
    worktree = task.get("worktree") or default_worktree(task["id"])
    return Path(worktree).resolve() if os.path.isabs(worktree) else (CONTEXT.repo_root / worktree).resolve()


def write_json(path: Path, payload: dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False)
        handle.write("\n")


def run_command(cmd: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=str(cwd), check=check, text=True, capture_output=True)


def run_command_streaming(
    cmd: list[str],
    cwd: Path,
    env: dict[str, str] | None = None,
    stdout_handle: Any | None = None,
    stdin_handle: Any | None = None,
) -> subprocess.Popen[bytes]:
    return subprocess.Popen(
        cmd,
        cwd=str(cwd),
        env=env,
        stdin=stdin_handle,
        stdout=stdout_handle,
        stderr=subprocess.STDOUT,
        text=False,
    )


def ensure_worktree(task: dict[str, Any], dry_run: bool = False) -> tuple[str, str]:
    branch = task.get("branch") or default_branch(task["id"])
    worktree = task.get("worktree") or default_worktree(task["id"])
    worktree_path = resolve_worktree(task)
    task["branch"] = branch
    task["worktree"] = worktree
    if worktree_path.exists():
        return branch, worktree
    if dry_run:
        return branch, worktree
    worktree_path.parent.mkdir(parents=True, exist_ok=True)
    run_command(["git", "worktree", "add", "-b", branch, str(worktree_path)], cwd=CONTEXT.repo_root, check=True)
    return branch, worktree


def prompt_path(task_id: str, kind: str = "worker") -> Path:
    suffix = "md" if kind == "worker" else "txt"
    return DISPATCH_DIR / f"{task_slug(task_id)}-{kind}.{suffix}"


def run_state_path(task_id: str) -> Path:
    return RUNS_DIR / f"{task_slug(task_id)}.json"


def coordinator_state_path() -> Path:
    return RUNS_DIR / "_coordinator.json"


def log_path(task_id: str) -> Path:
    return RUN_LOGS_DIR / f"{task_slug(task_id)}.log"


def lock_path(task_id: str) -> Path:
    return LOCKS_DIR / f"{task_slug(task_id)}.lock"


def path_conflict(scope_a: list[str], scope_b: list[str]) -> bool:
    def roots(items: list[str]) -> list[str]:
        result: list[str] = []
        for item in items:
            cleaned = item.replace("**", "").replace("*", "").strip("/")
            if cleaned:
                result.append(cleaned)
        return result

    for left in roots(scope_a):
        for right in roots(scope_b):
            if left.startswith(right) or right.startswith(left):
                return True
    return False


def task_ready(task: dict[str, Any], task_map: dict[str, dict[str, Any]]) -> bool:
    if task.get("status") != "ready":
        return False
    return all(task_map[dep].get("status") == "merged" for dep in task.get("depends_on", []))


def pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


@dataclass
class AgentCommand:
    executable: str
    args: list[str]

    def full_command(self, prompt: str) -> list[str]:
        return [self.executable, *self.args, prompt]


def default_agent_command(role: str) -> AgentCommand:
    if role == "claude_worker":
        return AgentCommand("claude", ["--dangerously-skip-permissions", "-p"])
    if role in {"codex_worker", "codex_integrator", "coordinator"}:
        return AgentCommand("codex", ["exec", "--dangerously-bypass-approvals-and-sandbox"])
    raise ValueError(f"Unsupported role: {role}")


def build_agent_env() -> dict[str, str]:
    env = os.environ.copy()
    for key, value in DEFAULT_PROXY_ENV.items():
        env.setdefault(key, value)
        env.setdefault(key.lower(), value)
    return env


def changed_files_for_branch(branch: str) -> list[str]:
    result = run_command(["git", "diff", "--name-only", f"main...{branch}"], cwd=CONTEXT.repo_root)
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def working_tree_clean() -> bool:
    result = run_command(["git", "status", "--short"], cwd=CONTEXT.repo_root)
    return not result.stdout.strip()


def git_head() -> str:
    result = run_command(["git", "rev-parse", "HEAD"], cwd=CONTEXT.repo_root)
    return result.stdout.strip()


def emit_event(event_type: str, **fields: Any) -> None:
    ensure_runtime_dirs()
    payload = {
        "type": event_type,
        "timestamp": now_iso(),
        "project": CONTEXT.slug,
        **fields,
    }
    append_jsonl(EVENTS_PATH, payload)


def absolute_runtime_path(path: Path) -> str:
    return str(path.resolve())


def relative_runtime_path(path: Path) -> str:
    return str(path.relative_to(FRAMEWORK_ROOT))


def project_read_paths() -> list[Path]:
    return [
        CONTEXT.repo_root / "README.md",
        CONTEXT.repo_root / "AGENTS.md",
        CONTEXT.repo_root / "CHECKPOINTS.md",
    ]


def matches_scope(path: str, patterns: list[str]) -> bool:
    return any(fnmatch(path, pattern) for pattern in patterns)
