#!/usr/bin/env python3
"""
Paddock Planner V2 — Generates Objectives from project goals.

Replaces V1 run_coordinator.py. Instead of generating fine-grained tasks,
the Planner produces Objectives with acceptance criteria that agents can
work on autonomously in sessions.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

import yaml

try:
    import paddock  # noqa: F401 — already installed via pip
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from paddock.config import (
    PADDOCK_ROOT,
    TEMPLATES_DIR,
    build_agent_env,
    resolve_project_path,
)
from paddock.db import PaddockDB


def _now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


SCOPE_DESCRIPTIONS = {
    "small": "单一、聚焦的改动，预期 1-2 个 commit",
    "medium": "一个完整功能或模块，预期 3-5 个 commit（默认）",
    "large": "跨模块的架构性变更，预期 5-10 个 commit",
}

SCOPE_COMMITS = {
    "small": "1-2",
    "medium": "3-5",
    "large": "5-10",
}


def build_planner_prompt(db: PaddockDB, project: dict) -> str:
    """Build the prompt for the planner agent."""
    goal = db.get_active_goal(project["id"])
    milestone = db.get_active_milestone(project["id"])
    phase = db.get_active_phase(project["id"])

    completed = db.list_objectives(project["id"], status=["done"])
    active = db.list_objectives(project["id"], status=["active"])
    failed = db.list_objectives(project["id"], status=["failed"])

    # Read scope config
    defaults = json.loads(project.get("session_defaults") or "{}")
    scope_level = defaults.get("scope_level", "medium")

    # Read project context files
    repo_root = resolve_project_path(project["repo_root"])
    context_files_content = _read_project_context(repo_root)

    # Try to load template
    template_path = TEMPLATES_DIR / "planner.md"
    if template_path.exists():
        template = template_path.read_text(encoding="utf-8")
        # Do variable substitution
        template = template.replace("{project.name}", project.get("name", project["id"]))
        template = template.replace("{goal.title}", goal["title"] if goal else "(未设定)")
        template = template.replace("{goal.description}", goal.get("description", "") if goal else "")
        template = template.replace("{milestone.title}", milestone["title"] if milestone else "(未设定)")
        template = template.replace("{milestone.description}", milestone.get("description", "") if milestone else "")
        template = template.replace("{phase.title}", phase["title"] if phase else "(未设定)")
        template = template.replace("{phase.description}", phase.get("description", "") if phase else "")
        template = template.replace("{completed_objectives_summary}", _format_objectives(completed))
        template = template.replace("{active_objectives_summary}", _format_objectives(active))
        template = template.replace("{project_files_content}", context_files_content)
        template = template.replace("{scope_level}", scope_level)
        template = template.replace("{expected_commits}", SCOPE_COMMITS.get(scope_level, "3-5"))
        template = template.replace("{scope_description}", SCOPE_DESCRIPTIONS.get(scope_level, SCOPE_DESCRIPTIONS["medium"]))
        return template

    # Inline fallback
    return _build_inline_prompt(
        project, goal, milestone, phase,
        completed, active, failed,
        context_files_content, scope_level,
    )


def _build_inline_prompt(project, goal, milestone, phase,
                          completed, active, failed,
                          context_files_content, scope_level):
    goal_title = goal["title"] if goal else "(未设定)"
    goal_desc = goal.get("description", "") if goal else ""
    ms_title = milestone["title"] if milestone else "(未设定)"
    ms_desc = milestone.get("description", "") if milestone else ""
    ph_title = phase["title"] if phase else "(未设定)"
    ph_desc = phase.get("description", "") if phase else ""

    return f"""# 角色

你是 Paddock Planner，负责为项目规划下一批工作目标（Objective）。

# 当前项目状态

## 项目信息
- 项目：{project.get("name", project["id"])}
- 当前目标：{goal_title} — {goal_desc}
- 当前里程碑：{ms_title} — {ms_desc}
- 当前阶段：{ph_title} — {ph_desc}

## 已完成的 Objective
{_format_objectives(completed)}

## 当前活跃的 Objective
{_format_objectives(active)}

## 失败的 Objective（供参考）
{_format_objectives(failed)}

## 项目文件（用于理解上下文）
{context_files_content}

# 流控配置

- scope_level: {scope_level}
- 每个 Objective 预期产出: {SCOPE_COMMITS.get(scope_level, "3-5")} 个 commit
- 每个 Objective 描述的粒度应该是：{SCOPE_DESCRIPTIONS.get(scope_level, SCOPE_DESCRIPTIONS["medium"])}

# 你的任务

基于当前阶段（{ph_title}）的目标和已完成的工作，规划接下来 1-3 个 Objective。

## 要求

1. 每个 Objective 必须有明确的、可验证的验收标准（acceptance_criteria）
2. Objective 粒度应符合 scope_level = {scope_level} 的要求
3. 不要拆得过细（如"创建单个文件"），Agent 会自己决定实现细节
4. 描述应聚焦于"达成什么结果"，而非"执行什么步骤"
5. path_scope 要合理划分，避免不同 Objective 间的路径冲突
6. 如果当前 Phase 的目标已基本完成，输出空列表并说明原因

## 输出格式

严格输出以下 YAML（用 ```yaml 包裹），不要输出其他内容：

```yaml
reasoning: |
  简要说明你的规划思路
objectives:
  - id: objective-slug-name
    title: 简短标题
    description: |
      详细描述要达成的结果，包括关键要求和约束。
      Agent 需要根据这个描述自主决定实现方案。
    acceptance_criteria:
      - 验收标准 1：具体、可检验的条件
      - 验收标准 2：具体、可检验的条件
    path_scope:
      - "src/module/**"
    depends_on: []
    context_refs:
      - "docs/architecture.md"
    worker_id: "implementer"
    priority: 0
```

**重要**：直接输出上述格式的 YAML，不要解释、不要总结、不要提问。只输出 ```yaml 代码块。
"""


def _format_objectives(objectives: list[dict]) -> str:
    if not objectives:
        return "(无)"
    lines = []
    for o in objectives[-10:]:  # Last 10 only
        criteria = json.loads(o.get("acceptance_criteria") or "[]")
        criteria_str = ", ".join(criteria[:3]) if criteria else ""
        lines.append(f"- **{o['id']}**: {o['title']} [{o['status']}]")
        if criteria_str:
            lines.append(f"  验收标准: {criteria_str}")
        if o.get("outcome_summary"):
            lines.append(f"  结果: {o['outcome_summary'][:100]}")
    return "\n".join(lines)


def _read_project_context(repo_root: Path) -> str:
    """Read key project files for planner context."""
    context_files = [
        "README.md",
        "AGENTS.md",
        "CHECKPOINTS.md",
    ]
    parts = []
    for filename in context_files:
        filepath = repo_root / filename
        if filepath.exists():
            content = filepath.read_text(encoding="utf-8", errors="replace")
            if len(content) > 3000:
                content = content[:3000] + "\n... (truncated)"
            parts.append(f"### {filename}\n```\n{content}\n```")
    return "\n\n".join(parts) if parts else "(no project files found)"


def main() -> None:
    parser = argparse.ArgumentParser(description="Paddock Planner V2")
    parser.add_argument("--project", required=True, help="Project ID")
    parser.add_argument("--agent", default=None, help="Agent ID to use for planning (overrides project config)")
    parser.add_argument("--timeout-seconds", type=int, default=600)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    db = PaddockDB()
    project = db.get_project(args.project)
    if not project:
        print(f"Error: project '{args.project}' not found", file=sys.stderr)
        sys.exit(1)

    prompt = build_planner_prompt(db, project)

    if args.dry_run:
        print(prompt)
        return

    # Select agent for planner
    # Priority: --agent arg > project.planner_agent config > first enabled agent
    agents = db.list_agents(enabled_only=True)
    if not agents:
        print("Error: no enabled agents", file=sys.stderr)
        sys.exit(1)

    import json as _json
    defaults = _json.loads(project.get("session_defaults") or "{}")
    planner_agent_id = getattr(args, "agent", None) or defaults.get("planner_agent")
    if planner_agent_id:
        agent = db.get_agent(planner_agent_id)
        if not agent or not agent.get("enabled"):
            print(f"Warning: planner_agent '{planner_agent_id}' not found or disabled, falling back", file=sys.stderr)
            agent = None
    else:
        agent = None

    if agent is None:
        # Fallback priority:
        # 1. mc-code (internal company Claude, no proxy needed, has --print)
        # 2. Any agent with --print mode (non-interactive, reliable YAML output)
        # 3. First enabled agent
        mc = db.get_agent("mc-code")
        if mc and mc.get("enabled"):
            agent = mc
        else:
            def _is_print_mode(a: dict) -> bool:
                t = a.get("command_template", "")
                return "--print" in t or ("cat " in t and " | " in t and "kimi" not in t)
            print_agents = [a for a in agents if _is_print_mode(a)]
            agent = print_agents[0] if print_agents else agents[0]
        print(f"[paddock] planner using agent: {agent['id']} (auto-selected)", file=sys.stderr)
    # Write prompt to temp file
    prompt_file = PADDOCK_ROOT / "runtime" / "projects" / args.project / "logs" / "planner-prompt.md"
    prompt_file.parent.mkdir(parents=True, exist_ok=True)
    prompt_file.write_text(prompt, encoding="utf-8")

    from paddock.utils import render_agent_command
    cmd = render_agent_command(agent["command_template"], str(prompt_file))

    repo_root = resolve_project_path(project["repo_root"])

    # Find the planner_run record created by trigger_planner API (most recent for this project)
    run = db.get_latest_planner_run(args.project)
    run_id: int | None = run["id"] if run else None

    log_file = PADDOCK_ROOT / "runtime" / "projects" / args.project / "logs" / "planner.log"
    log_file.parent.mkdir(parents=True, exist_ok=True)

    if run_id:
        db.update_planner_run(run_id, {"log_file": str(log_file), "status": "running"})

    use_shell = isinstance(cmd, str)

    # For "cat {file} | cmd" patterns, read file content and pass via stdin
    # (shell pipe + capture_output=True can cause mc/claude to exit immediately)
    stdin_data: str | None = None
    if use_shell and "cat " in str(cmd) and " | " in str(cmd):
        import re as _re
        cat_match = _re.match(r"cat\s+(\S+)\s*\|(.+)", str(cmd))
        if cat_match:
            cat_file = cat_match.group(1)
            rest_cmd = cat_match.group(2).strip()
            try:
                stdin_data = Path(cat_file).read_text(encoding="utf-8")
                cmd = rest_cmd
                use_shell = True
            except OSError:
                pass

    try:
        result = subprocess.run(
            cmd,
            cwd=str(repo_root),
            env=build_agent_env(agent),
            text=True,
            input=stdin_data,
            capture_output=True,
            timeout=args.timeout_seconds,
            check=False,
            shell=use_shell,
        )
    except subprocess.TimeoutExpired:
        msg = "[paddock] planner timed out"
        print(msg, file=sys.stderr)
        log_file.write_text(msg, encoding="utf-8")
        if run_id:
            db.update_planner_run(run_id, {"status": "failed", "error_message": "timeout", "finished_at": _now()})
        sys.exit(1)

    output = result.stdout or ""
    stderr_out = result.stderr or ""

    # Write log
    log_file.write_text(output + ("\n--- stderr ---\n" + stderr_out if stderr_out else ""), encoding="utf-8")

    if result.returncode != 0 and "```yaml" not in output and "objectives:" not in output:
        err = stderr_out[:500] or f"exit code {result.returncode}"
        print(f"[paddock] planner agent failed: {err}", file=sys.stderr)
        if run_id:
            db.update_planner_run(run_id, {"status": "failed", "error_message": err, "plan_output": output[:2000], "finished_at": _now()})
        sys.exit(result.returncode)

    # Parse YAML from output (even if returncode != 0, agent may have produced valid output)
    applied = _parse_and_apply(db, args.project, output, run_id)
    print(f"[paddock] planner applied {applied} objectives", file=sys.stderr)


def _parse_and_apply(db: PaddockDB, project_id: str, output: str, run_id: int | None) -> int:
    """Extract YAML block from agent output and write objectives to DB."""
    # Find ```yaml ... ``` block (handles ```yaml and ```yml)
    match = re.search(r"```ya?ml\s*\n(.*?)```", output, re.DOTALL | re.IGNORECASE)
    if not match:
        # Try to find a YAML block starting with 'reasoning:' or 'objectives:'
        yaml_start = re.search(r"^(reasoning:|objectives:)", output, re.MULTILINE)
        if yaml_start:
            raw_yaml = output[yaml_start.start():].strip()
        else:
            err = "No YAML block found in planner output"
            print(f"[paddock] {err}", file=sys.stderr)
            if run_id:
                db.update_planner_run(run_id, {
                    "status": "failed",
                    "error_message": err,
                    "plan_output": output[:2000],
                    "finished_at": _now(),
                })
            return 0
    else:
        raw_yaml = match.group(1)

    try:
        data = yaml.safe_load(raw_yaml)
    except yaml.YAMLError as e:
        err = f"YAML parse error: {e}"
        print(f"[paddock] {err}", file=sys.stderr)
        if run_id:
            db.update_planner_run(run_id, {
                "status": "failed",
                "error_message": err,
                "plan_output": output[:2000],
                "finished_at": _now(),
            })
        return 0

    if not isinstance(data, dict):
        if run_id:
            db.update_planner_run(run_id, {
                "status": "failed",
                "error_message": "output is not a YAML dict",
                "plan_output": output[:2000],
                "finished_at": _now(),
            })
        return 0

    objectives = data.get("objectives") or []
    reasoning = data.get("reasoning", "")
    phase_checks = data.get("phase_checks") or []

    # Persist phase_checks to DB (replace existing checks for current phase)
    if phase_checks:
        phase = db.get_active_phase(project_id)
        if phase:
            valid_checks = []
            for c in phase_checks:
                if isinstance(c, dict) and c.get("description") and c.get("check_command"):
                    valid_checks.append({
                        "description": str(c["description"]),
                        "check_type": str(c.get("check_type", "shell")),
                        "check_command": str(c["check_command"]),
                        "expected": str(c["expected"]) if c.get("expected") else None,
                    })
            if valid_checks:
                db.upsert_phase_checks(phase["id"], project_id, valid_checks)
                print(f"[paddock] upserted {len(valid_checks)} phase checks for phase {phase['id']}", file=sys.stderr)

    count = 0
    for obj in objectives:
        if not isinstance(obj, dict) or not obj.get("id") or not obj.get("title"):
            continue
        obj_id = str(obj["id"])
        # Skip if already exists
        if db.get_objective(obj_id):
            print(f"[paddock] objective {obj_id} already exists, skipping", file=sys.stderr)
            continue
        record = {
            "id": obj_id,
            "project_id": project_id,
            "title": str(obj.get("title", "")),
            "description": str(obj.get("description", "")),
            "acceptance_criteria": obj.get("acceptance_criteria") or [],
            "path_scope": obj.get("path_scope") or [],
            "depends_on": obj.get("depends_on") or [],
            "context_refs": obj.get("context_refs") or [],
            "worker_id": obj.get("worker_id", "implementer"),
            "priority": int(obj.get("priority", 0)),
            "status": "ready",
            "session_budget": obj.get("session_budget"),
        }
        try:
            db.create_objective(record)
            db.emit_event(project_id, "objective_ready", {"id": obj_id, "title": record["title"]})
            count += 1
        except Exception as e:
            print(f"[paddock] failed to create objective {obj_id}: {e}", file=sys.stderr)

    if run_id:
        db.update_planner_run(run_id, {
            "status": "completed",
            "plan_output": output[:4000],
            "objective": reasoning[:500] if reasoning else f"{count} objectives created",
            "applied_at": _now(),
            "finished_at": _now(),
        })

    return count


if __name__ == "__main__":
    main()
