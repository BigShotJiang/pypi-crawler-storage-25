from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

from common import (
    BOARD_PATH,
    CONTEXT,
    PLANS_DIR,
    REVIEWS_PATH,
    TASKS_PATH,
    TEMPLATES_DIR,
    build_agent_env,
    coordinator_state_path,
    default_agent_command,
    emit_event,
    ensure_runtime_dirs,
    now_iso,
    project_read_paths,
    read_json,
    relative_runtime_path,
    write_json,
)


def build_prompt(plan_path: Path, objective: str, min_ready: int) -> str:
    lines = [
        "你是本轮 Coordinator。",
        "不要依赖聊天上下文，先阅读项目工件。",
        "",
        f"项目：`{CONTEXT.name}`",
        f"repo: `{CONTEXT.repo_root}`",
        f"runtime: `{CONTEXT.runtime_root}`",
        "",
        "开始前先读：",
    ]
    read_paths = project_read_paths() + [TASKS_PATH, BOARD_PATH, REVIEWS_PATH, TEMPLATES_DIR / "coordinator.md"]
    for index, path in enumerate(read_paths, start=1):
        lines.append(f"{index}. `{path}`")

    lines.extend(
        [
            "",
            f"本轮目标：{objective}",
            f"当前要求：至少维持 {min_ready} 个 ready task，除非依赖无法满足。",
            "",
            "请输出一份结构化计划到以下文件：",
            f"- `{plan_path}`",
            "",
            "无论你是否新增任务，都必须创建该文件。",
            "如果这一轮没有合适的新任务，也必须写入：",
            "actions: []",
            "",
            "文件格式必须为 YAML，顶层结构：",
            "actions:",
            "  - type: add_task | update_task",
            "    ...",
            "",
            "约束：",
            "- 每轮最多新增 3 个任务",
            "- 新任务必须有 id/title/role/status/path_scope/depends_on/outputs",
            "- status 只能使用 ready 或 todo，不要使用 pending 等其他值",
            "- 只生成当前阶段紧邻的下一步任务，不要发散",
            "- 不要直接改 tasks.yaml，由后续 apply_plan.py 应用",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Launch a coordinator agent to write a structured plan.")
    parser.add_argument("--objective", default="保持流水线持续推进，并补充下一批可执行任务。")
    parser.add_argument("--min-ready", type=int, default=1)
    parser.add_argument("--timeout-seconds", type=int, default=180)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    ensure_runtime_dirs()
    stamp = now_iso().replace(":", "-")
    plan_path = PLANS_DIR / f"{stamp}-plan.yaml"
    prompt = build_prompt(plan_path, args.objective, args.min_ready)
    command = default_agent_command("coordinator").full_command("-")

    if args.dry_run:
        print(plan_path)
        print(" ".join(command))
        return

    env = build_agent_env()
    log_path = CONTEXT.runtime_root / "runs" / "logs" / f"{stamp}-coordinator.log"
    prompt_path = log_path.with_suffix(".prompt.txt")
    with log_path.open("ab") as handle, open(prompt_path, "wb") as prompt_log:
        prompt_bytes = prompt.encode("utf-8")
        prompt_log.write(prompt_bytes)

    write_json(
        coordinator_state_path(),
        {
            "type": "coordinator",
            "status": "in_progress",
            "pid": None,
            "started_at": now_iso(),
            "objective": args.objective,
            "plan_file": relative_runtime_path(plan_path),
            "log_file": relative_runtime_path(log_path),
            "prompt_file": relative_runtime_path(prompt_path),
            "applied": False,
        },
    )
    emit_event(
        "coordinator_started",
        pid=None,
        objective=args.objective,
        plan_file=relative_runtime_path(plan_path),
        log_file=relative_runtime_path(log_path),
    )

    try:
        result = subprocess.run(
            command,
            cwd=str(CONTEXT.repo_root),
            env=env,
            input=prompt,
            text=True,
            capture_output=True,
            timeout=args.timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired:
        with log_path.open("ab") as handle:
            handle.write(b"\n[paddock] coordinator timed out\n")
        state = read_json(coordinator_state_path())
        state["status"] = "blocked"
        state["finished_at"] = now_iso()
        state["error"] = f"Coordinator timed out after {args.timeout_seconds}s"
        write_json(coordinator_state_path(), state)
        emit_event("coordinator_blocked", reason="timeout", timeout_seconds=args.timeout_seconds)
        print("blocked: timeout")
        return

    with log_path.open("ab") as handle:
        if result.stdout:
            handle.write(result.stdout.encode("utf-8", errors="replace"))
        if result.stderr:
            handle.write(b"\n[stderr]\n")
            handle.write(result.stderr.encode("utf-8", errors="replace"))

    state = read_json(coordinator_state_path())
    state["finished_at"] = now_iso()
    state["returncode"] = result.returncode
    if result.returncode != 0:
        state["status"] = "blocked"
        state["error"] = f"Coordinator exited with code {result.returncode}"
        write_json(coordinator_state_path(), state)
        emit_event("coordinator_blocked", reason="exit_nonzero", returncode=result.returncode)
        print(f"blocked: exit {result.returncode}")
        return

    state["status"] = "finished"
    write_json(coordinator_state_path(), state)
    emit_event("coordinator_finished", plan_file=relative_runtime_path(plan_path))
    print("finished")


if __name__ == "__main__":
    main()
