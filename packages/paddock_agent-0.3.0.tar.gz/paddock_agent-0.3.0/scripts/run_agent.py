from __future__ import annotations

import argparse

from common import (
    build_agent_env,
    default_agent_command,
    emit_event,
    ensure_runtime_dirs,
    get_task,
    load_tasks,
    log_path,
    now_iso,
    prompt_path,
    relative_runtime_path,
    resolve_worktree,
    run_command_streaming,
    run_state_path,
    save_tasks,
    write_json,
)


def main() -> None:
    parser = argparse.ArgumentParser(description="Launch a worker or integrator agent for a task.")
    parser.add_argument("task_id")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    ensure_runtime_dirs()
    data = load_tasks()
    task = get_task(data, args.task_id)
    prompt_file = prompt_path(task["id"])
    prompt = prompt_file.read_text(encoding="utf-8")
    worktree = resolve_worktree(task)
    command = default_agent_command(task["role"]).full_command(prompt)
    run_file = run_state_path(task["id"])

    payload = {
        "task_id": task["id"],
        "role": task["role"],
        "status": "in_progress",
        "branch": task.get("branch", ""),
        "worktree": task.get("worktree", ""),
        "prompt_file": relative_runtime_path(prompt_file),
        "started_at": now_iso(),
        "pid": None,
        "log_file": relative_runtime_path(log_path(task["id"])),
        "command": command,
        "dry_run": args.dry_run,
    }

    if args.dry_run:
        emit_event(
            "task_dispatch_dry_run",
            task_id=task["id"],
            role=task["role"],
            branch=task.get("branch", ""),
            worktree=task.get("worktree", ""),
            command=command,
        )
        print("DRY RUN")
        print("cwd:", worktree)
        print("cmd:", " ".join(command))
        return

    task["status"] = "in_progress"
    agent_env = build_agent_env()
    with log_path(task["id"]).open("ab") as handle:
        process = run_command_streaming(command, cwd=worktree, env=agent_env, stdout_handle=handle)

    payload["pid"] = process.pid
    write_json(run_file, payload)
    save_tasks(data)
    emit_event(
        "task_started",
        task_id=task["id"],
        role=task["role"],
        pid=process.pid,
        branch=task.get("branch", ""),
        worktree=task.get("worktree", ""),
        log_file=payload["log_file"],
    )
    print(process.pid)


if __name__ == "__main__":
    main()
