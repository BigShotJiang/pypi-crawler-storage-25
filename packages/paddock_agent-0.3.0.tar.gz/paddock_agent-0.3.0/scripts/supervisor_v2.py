#!/usr/bin/env python3
"""
Paddock Supervisor V2 — Objective/Session-based orchestration.

Main control loop that drives the entire Paddock pipeline:
1. Harvest finished sessions
2. Review checkpoints
3. Merge completed objectives
4. Unlock ready objectives
5. Trigger planner if needed
6. Apply planner output
7. Dispatch new sessions
"""
from __future__ import annotations

import argparse
import json
import logging
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock

try:
    import paddock  # noqa: F401 — already installed via pip
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from paddock.config import (
    DEFAULT_DURATION_MINUTES,
    DEFAULT_MAX_PARALLEL,
    DEFAULT_PLANNER_COOLDOWN,
    DEFAULT_POLL_SECONDS,
    PADDOCK_ROOT,
    LOG_LEVEL,
    build_agent_env,
    ensure_runtime_dirs,
    resolve_project_path,
)
from paddock.db import PaddockDB
from paddock.utils import (
    all_files_in_scope,
    branch_has_diff,
    cleanup_worktree,
    ensure_worktree,
    get_branch_changed_files,
    get_commits_since_main,
    git_merge_no_ff,
    is_worktree_clean,
    matches_any_pattern,
    parse_session_summary,
    pid_alive,
    render_agent_command,
    terminate_process,
)

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("supervisor")


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _parse_iso(value: str | None) -> float | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def _json_loads(s: str | None) -> list | dict | None:
    if not s:
        return None
    return json.loads(s)


# ============================================================
# Phase 1: Harvest finished sessions
# ============================================================

_EXTERNAL_ERROR_PATTERNS = [
    ("rate_limit_reached_error", "API 用量限制 (429)"),
    ("You've reached your usage limit", "API 用量限制"),
    ("rate limit", "API 速率限制"),
    ("429", "HTTP 429 Too Many Requests"),
    ("ECONNRESET", "网络连接中断 (ECONNRESET)"),
    ("Unable to connect to API", "无法连接 API"),
    ("API Error: 401", "API 认证失败 (401)"),
    ("API Error: 403", "API 权限不足 (403)"),
    ("API Error: 500", "API 服务端错误 (500)"),
    ("API Error: 502", "API 网关错误 (502)"),
    ("API Error: 503", "API 服务不可用 (503)"),
    ("context length exceeded", "上下文长度超限"),
    ("maximum context", "上下文长度超限"),
    ("LLM provider error", "LLM 提供商错误"),
]


def _detect_external_error(log_file: str) -> str | None:
    """Scan session log for external interruption patterns.
    Returns a human-readable error description, or None if clean exit.
    """
    try:
        path = Path(log_file)
        if not path.exists():
            return None
        # Only scan last 3KB — errors appear near the end
        size = path.stat().st_size
        offset = max(0, size - 3072)
        with open(path, "rb") as f:
            f.seek(offset)
            tail = f.read().decode("utf-8", errors="replace")
        for pattern, description in _EXTERNAL_ERROR_PATTERNS:
            if pattern.lower() in tail.lower():
                return description
    except Exception:
        pass
    return None


def harvest_finished_sessions(db: PaddockDB, project: dict) -> list[int]:
    """Check running sessions, harvest those whose process has ended."""
    harvested: list[int] = []
    for session in db.get_active_sessions(project["id"]):
        pid = session.get("pid")
        if not pid:
            continue

        if pid_alive(int(pid)):
            # Still running — check budget timeout
            _check_session_timeout(db, session)
            continue

        # Process ended — harvest
        objective = db.get_objective(session["objective_id"])
        if not objective:
            continue

        worktree_path = Path(objective["worktree"]) if objective.get("worktree") else None

        # Scan new commits
        checkpoint_count = 0
        if worktree_path and worktree_path.exists():
            commits = get_commits_since_main(worktree_path)
            for commit in commits:
                # Check if checkpoint already recorded
                existing = db.list_checkpoints(session["id"])
                if any(cp["commit_hash"] == commit["hash"] for cp in existing):
                    continue
                db.add_checkpoint({
                    "session_id": session["id"],
                    "objective_id": session["objective_id"],
                    "commit_hash": commit["hash"],
                    "commit_message": commit["message"],
                    "files_changed": commit.get("files", []),
                })
                checkpoint_count += 1

        # Parse session summary from log
        outcome = None
        external_error: str | None = None
        if session.get("log_file"):
            summary = parse_session_summary(session["log_file"])
            if summary:
                outcome = json.dumps(summary, ensure_ascii=False)
            # Detect external interruption patterns in log
            external_error = _detect_external_error(session["log_file"])

        total_checkpoints = len(db.list_checkpoints(session["id"]))

        # If interrupted by external error but has commits → partial completion
        if external_error and total_checkpoints > 0:
            final_status = "completed"  # Work is valid, still merge it
            log.warning("Session %d interrupted by external error (%s) but has %d checkpoint(s) — treating as partial completion",
                        session["id"], external_error[:60], total_checkpoints)
        elif external_error and total_checkpoints == 0:
            final_status = "completed"  # No work done, will be handled as no-checkpoints
            log.warning("Session %d interrupted by external error (%s) with no commits",
                        session["id"], external_error[:60])
        else:
            final_status = "completed"

        db.update_session(session["id"], {
            "status": final_status,
            "finished_at": _now(),
            "outcome": outcome,
            "checkpoint_count": total_checkpoints,
            "error_message": f"[外部中断] {external_error}" if external_error else None,
        })

        db.emit_event(project["id"], "session_completed", {
            "session_id": session["id"],
            "objective_id": session["objective_id"],
            "checkpoint_count": total_checkpoints,
            "interrupted_by": external_error,
        })

        if external_error:
            log.info("Session %d completed (objective=%s, checkpoints=%d) ⚠ interrupted: %s",
                     session["id"], session["objective_id"], total_checkpoints, external_error[:80])
        else:
            log.info("Session %d completed (objective=%s, checkpoints=%d)",
                     session["id"], session["objective_id"], total_checkpoints)
        harvested.append(session["id"])

    return harvested


def _check_session_timeout(db: PaddockDB, session: dict) -> None:
    """Terminate session if it exceeds budget max_minutes."""
    budget = _json_loads(session.get("budget"))
    if not budget or not budget.get("max_minutes"):
        return

    started = _parse_iso(session.get("started_at"))
    if not started:
        return

    elapsed_minutes = (time.time() - started) / 60
    if elapsed_minutes > budget["max_minutes"]:
        pid = session.get("pid")
        if pid and pid_alive(int(pid)):
            log.warning("Session %d exceeded budget (%d min), terminating PID %d",
                        session["id"], budget["max_minutes"], pid)
            terminate_process(int(pid), timeout=30)
            db.update_session(session["id"], {
                "status": "timeout",
                "finished_at": _now(),
                "error_message": f"Exceeded budget of {budget['max_minutes']} minutes",
            })
            db.emit_event(session["project_id"], "session_timeout", {
                "session_id": session["id"],
                "objective_id": session["objective_id"],
            })


# ============================================================
# Phase 2: Review checkpoints
# ============================================================

def process_checkpoint_reviews(db: PaddockDB, project: dict) -> None:
    """Auto-review checkpoints of completed sessions."""
    integrator_only = _json_loads(project.get("integrator_only_patterns")) or []

    # Process both completed and timeout sessions
    sessions_to_review = (
        db.get_sessions_by_status(project["id"], "completed") +
        db.get_sessions_by_status(project["id"], "timeout")
    )
    for session in sessions_to_review:
        objective = db.get_objective(session["objective_id"])
        if not objective or objective["status"] not in ("active", "done"):
            continue

        checkpoints = db.list_checkpoints(session["id"])
        if not checkpoints:
            if objective["status"] != "active":
                continue

            # No commits — check if agent explicitly reported success in SESSION_SUMMARY
            outcome = session.get("outcome")
            if outcome:
                try:
                    summary = json.loads(outcome) if isinstance(outcome, str) else outcome
                    if isinstance(summary, dict) and summary.get("status") == "completed":
                        # Agent said it's done (e.g. validation task: tests passed, nothing to commit)
                        db.update_objective(objective["id"], {"status": "done"})
                        db.emit_event(project["id"], "objective_done", {
                            "objective_id": objective["id"],
                            "session_id": session["id"],
                            "reason": "agent_reported_complete_no_commits",
                        })
                        log.info("Objective %s marked done (agent reported complete, 0 commits — likely validation/acceptance task)",
                                 objective["id"])
                        continue
                except (json.JSONDecodeError, TypeError):
                    pass

            # Check for any running session on this objective
            other_running = [
                s for s in db.get_active_sessions(project["id"])
                if s["objective_id"] == objective["id"]
            ]
            if other_running:
                continue
            # Check for any other completed/timeout session with checkpoints for this objective
            other_completed_with_work = [
                s for s in (
                    db.get_sessions_by_status(project["id"], "completed") +
                    db.get_sessions_by_status(project["id"], "timeout")
                )
                if s["objective_id"] == objective["id"]
                and s["id"] != session["id"]
                and db.list_checkpoints(s["id"])
            ]
            if other_completed_with_work:
                continue
            db.update_objective(objective["id"], {"status": "failed"})
            db.emit_event(project["id"], "objective_failed", {
                "objective_id": objective["id"],
                "reason": "no_checkpoints",
            })
            log.warning("Objective %s failed: no checkpoints", objective["id"])
            continue

        scope = _json_loads(objective.get("path_scope"))
        all_approved = True

        for cp in checkpoints:
            if cp["review_status"] != "pending":
                if cp["review_status"] != "approved":
                    all_approved = False
                continue

            files = _json_loads(cp.get("files_changed")) or []
            status, note = _auto_review_checkpoint(files, scope, integrator_only)
            db.update_checkpoint_review(cp["id"], status, note)

            if status != "approved":
                all_approved = False
                log.info("Checkpoint %s review: %s — %s", cp["commit_hash"][:8], status, note)

        if all_approved and objective["status"] == "active":
            db.update_objective(objective["id"], {"status": "done"})
            db.emit_event(project["id"], "objective_done", {
                "objective_id": objective["id"],
                "session_id": session["id"],
            })
            log.info("Objective %s marked done", objective["id"])
        elif not all_approved and objective["status"] == "active":
            # Some checkpoints rejected — check if there's still a running session
            other_running = [
                s for s in db.get_active_sessions(project["id"])
                if s["objective_id"] == objective["id"]
            ]
            if other_running:
                continue  # Still running, wait

            _handle_rejected_objective(db, project, objective, session, checkpoints)


MAX_AUTO_RETRIES = 2

# Paths that are always safe to auto-include when agent writes there.
# Format: (substring_to_match, glob_to_add_to_scope)
# Rule: if ALL rejected files match patterns here, auto-expand scope instead of retrying.
_AUTO_EXPAND_PATTERNS = [
    # Test files — always reasonable to write tests
    ("app/backend/tests/", "app/backend/tests/**"),
    ("app/frontend/tests/", "app/frontend/tests/**"),
    ("tests/", "tests/**"),
    ("test_", None),                        # files named test_*
    # Session notes — agent documents its work
    ("docs/sessions/", "docs/sessions/**"),
    ("docs/sessions", "docs/sessions/**"),
    # Any backend src file — all backend subdirs are interconnected
    # (main.py registers routes, state.py is shared, agent/engine/models/routers all depend on each other)
    ("app/backend/src/", "app/backend/src/**"),
    # Any frontend src file
    ("app/frontend/src/", "app/frontend/src/**"),
    # Markdown docs
    (".md", None),
]


def _try_expand_scope(db: PaddockDB, objective: dict, rejected_checkpoints: list[dict]) -> bool:
    """If all rejections are 'Files out of scope' for safe paths, auto-expand scope.
    Returns True if scope was expanded."""
    import re as _re

    scope_violations = [
        cp for cp in rejected_checkpoints
        if "out of scope" in (cp["review_note"] or "").lower()
    ]
    non_scope_rejections = [
        cp for cp in rejected_checkpoints
        if "out of scope" not in (cp["review_note"] or "").lower()
    ]

    # Only auto-expand if ALL rejections are scope violations
    if not scope_violations or non_scope_rejections:
        return False

    # Extract the out-of-scope file paths from rejection notes
    out_of_scope_files: list[str] = []
    for cp in scope_violations:
        note = cp["review_note"] or ""
        # Parse "Files out of scope: ['path/to/file.py', ...]"
        match = _re.search(r"\[(.+?)\]", note)
        if match:
            try:
                files = _json_loads("[" + match.group(1) + "]") or []
                out_of_scope_files.extend(files)
            except Exception:
                pass

    if not out_of_scope_files:
        return False

    # Check if all out-of-scope files match safe auto-expand patterns
    new_globs: set[str] = set()
    for f in out_of_scope_files:
        matched = False
        for pattern_prefix, glob in _AUTO_EXPAND_PATTERNS:
            if pattern_prefix in f or f.startswith(pattern_prefix):
                if glob:
                    new_globs.add(glob)
                else:
                    # Build glob from file's directory
                    parts = f.split("/")
                    if len(parts) >= 2:
                        new_globs.add("/".join(parts[:-1]) + "/**")
                    else:
                        new_globs.add(f.rsplit(".", 1)[0] + "*")
                matched = True
                break
        if not matched:
            # Unknown path — don't auto-expand, let human decide
            log.info("Auto-expand skipped: unknown out-of-scope path %s", f)
            return False

    # Expand the scope
    current_scope = _json_loads(objective.get("path_scope")) or []
    expanded = list(set(current_scope) | new_globs)
    db.update_objective(objective["id"], {"path_scope": expanded})
    log.info("Auto-expanded path_scope for %s: added %s", objective["id"], new_globs)
    return True


def _handle_rejected_objective(db: PaddockDB, project: dict, objective: dict,
                                session: dict, checkpoints: list[dict]) -> None:
    """Handle an objective whose checkpoints were rejected.

    retry_count < MAX_AUTO_RETRIES → dispatch a correction session with rejection feedback
    retry_count >= MAX_AUTO_RETRIES → escalate to needs_review for human intervention
    """
    retry_count = int(objective.get("retry_count") or 0)
    rejected = [cp for cp in checkpoints if cp["review_status"] == "rejected"]
    feedback_lines = []
    for cp in rejected:
        feedback_lines.append(f"- commit {cp['commit_hash'][:8]}: {cp['review_note']}")
    feedback = "\n".join(feedback_lines)

    # Auto-expand path_scope for safe "Files out of scope" rejections
    # This runs regardless of retry_count — scope expansion never consumes a retry
    scope_expanded = _try_expand_scope(db, objective, rejected)
    if scope_expanded:
        for cp in rejected:
            if "out of scope" in (cp["review_note"] or "").lower():
                db.update_checkpoint_review(cp["id"], "pending", None)
        # Also reset needs_review back to active so review runs again
        if objective["status"] == "needs_review":
            db.update_objective(objective["id"], {"status": "active"})
        log.info("Objective %s: expanded path_scope, re-reviewing", objective["id"])
        return

    if retry_count < MAX_AUTO_RETRIES:
        log.info("Objective %s has %d rejected checkpoints, auto-retry %d/%d",
                 objective["id"], len(rejected), retry_count + 1, MAX_AUTO_RETRIES)
        db.update_objective(objective["id"], {
            "retry_count": retry_count + 1,
            "review_feedback": feedback,
        })
        db.emit_event(project["id"], "objective_retry", {
            "objective_id": objective["id"],
            "retry_count": retry_count + 1,
            "feedback": feedback,
        })
        # Re-dispatch as a correction session
        _dispatch_correction_session(db, project, objective, feedback)
    else:
        log.warning("Objective %s exceeded max retries (%d), escalating to needs_review",
                    objective["id"], MAX_AUTO_RETRIES)
        db.update_objective(objective["id"], {
            "status": "needs_review",
            "review_feedback": feedback,
        })
        db.emit_event(project["id"], "objective_needs_human_review", {
            "objective_id": objective["id"],
            "reason": f"Failed auto-review after {MAX_AUTO_RETRIES} retries",
            "feedback": feedback,
        })


def _dispatch_correction_session(db: PaddockDB, project: dict, objective: dict,
                                  feedback: str) -> None:
    """Dispatch a correction session with rejection feedback injected into the prompt."""
    repo_root = resolve_project_path(project["repo_root"])
    worktrees_root = resolve_project_path(project["worktrees_root"])

    worker = None
    if objective.get("worker_id"):
        worker = db.get_worker(objective["worker_id"])
    if not worker:
        workers = db.list_workers()
        worker = workers[0] if workers else None

    agent = _select_agent(db, worker)
    if not agent:
        log.error("No available agent for correction session on %s", objective["id"])
        return

    # Reuse existing worktree/branch if available, otherwise create new
    branch = objective.get("branch")
    worktree_path = Path(objective["worktree"]) if objective.get("worktree") else None
    if not worktree_path or not worktree_path.exists():
        branch, worktree_path = ensure_worktree(repo_root, worktrees_root, objective["id"])
        db.update_objective(objective["id"], {"branch": branch, "worktree": str(worktree_path)})

    budget = _compute_budget(project, objective)
    base_prompt = _build_session_prompt(db, project, objective, worker, budget)

    # Inject correction context
    human_prompt = objective.get("human_prompt") or ""
    human_section = f"\n## 💬 人工补充指令\n\n{human_prompt}\n" if human_prompt else ""
    is_merge_conflict = "merge conflict" in feedback.lower()

    if is_merge_conflict:
        correction_section = f"""
## ⚠️ 修正会话 — 合并冲突

这个分支在合并到 main 时发生了冲突：

{feedback}

**请按以下步骤解决冲突**：
1. 运行 `git merge main` 将 main 的最新变更合并进来
2. 解决冲突文件（保留两边的功能，不要丢弃任何一方的代码）
3. `git add` 解决后的文件
4. `git commit` 完成合并
5. 验证功能仍然正常
{human_section}
解决完成后输出会话总结。
"""
    else:
        correction_section = f"""
## ⚠️ 修正会话

这是第 {objective.get('retry_count', 1)} 次重试。上一次会话的部分提交被自动审查系统拒绝，原因如下：

{feedback}

**请在本次会话中修正上述问题**：
- 如果是"Files out of scope"：删除或移动那些文件到允许的路径内，或者完全不创建它们
- 如果是"Modified integrator-only file"：撤销对该文件的修改（git revert 或手动还原）
- 如果是"Empty commit"：确保每次提交都包含实际的文件变更
{human_section}
修正完成后，正常完成剩余的验收标准。
"""
    prompt = base_prompt + "\n" + correction_section

    ensure_runtime_dirs(project["id"])
    prompt_file = PADDOCK_ROOT / "runtime" / "projects" / project["id"] / "logs" / f"prompt-{objective['id']}-retry{objective.get('retry_count',1)}.md"
    prompt_file.write_text(prompt, encoding="utf-8")

    cmd = render_agent_command(agent["command_template"], str(prompt_file), str(worktree_path))
    log_file = str(PADDOCK_ROOT / "runtime" / "projects" / project["id"] / "logs" / f"session-{objective['id']}-retry{objective.get('retry_count',1)}.log")

    use_shell = isinstance(cmd, str)
    with open(log_file, "w") as lf:
        process = subprocess.Popen(
            cmd, cwd=str(worktree_path),
            stdout=lf, stderr=subprocess.STDOUT,
            env=build_agent_env(agent),
            shell=use_shell,
        )

    session_id = db.create_session({
        "objective_id": objective["id"],
        "project_id": project["id"],
        "agent_id": agent["id"],
        "status": "running",
        "pid": process.pid,
        "budget": budget,
        "prompt": prompt,
        "log_file": log_file,
    })

    log.info("Correction session %d started for %s (retry=%d, pid=%d)",
             session_id, objective["id"], objective.get("retry_count", 1), process.pid)


def _auto_review_checkpoint(files: list[str], scope: list | None,
                            integrator_only: list[str]) -> tuple[str, str]:
    """Review a single checkpoint. Returns (status, note).

    scope is treated as a hint only — we do NOT reject based on scope violations.
    Scope violations are auto-expanded by _try_expand_scope before this is called.
    The only hard rejection is: modifying integrator-only files.
    """
    if not files:
        return "rejected", "Empty commit — no files changed"

    # scope check removed — path_scope is advisory, not a hard gate.
    # Real protection comes from integrator_only_patterns below.

    for f in files:
        if matches_any_pattern(f, integrator_only):
            return "rejected", f"Modified integrator-only file: {f}"

    return "approved", "Auto-approved"


# ============================================================
# Phase 3: Merge completed objectives
# ============================================================

def merge_completed_objectives(db: PaddockDB, project: dict) -> list[str]:
    """Merge done objectives into main."""
    merged: list[str] = []
    repo_root = resolve_project_path(project["repo_root"])

    for obj in db.list_objectives(project["id"], status=["done"]):
        branch = obj.get("branch")
        if not branch:
            continue

        # Already merged check: no diff means already merged
        if not branch_has_diff(repo_root, branch):
            # Clean up worktree
            if obj.get("worktree"):
                cleanup_worktree(repo_root, obj["worktree"])
            continue

        # Safety: main worktree must be clean
        if not is_worktree_clean(repo_root):
            log.warning("Main worktree dirty, skipping merge for %s", obj["id"])
            continue

        result = git_merge_no_ff(
            repo_root, branch,
            message=f"Merge objective '{obj['title']}' [{obj['id']}]"
        )

        if result["success"]:
            db.emit_event(project["id"], "objective_merged", {
                "objective_id": obj["id"],
                "commit": result["commit_hash"],
            })
            log.info("Merged objective %s at %s", obj["id"], result["commit_hash"][:8])
            merged.append(obj["id"])

            # Clean up worktree
            if obj.get("worktree"):
                cleanup_worktree(repo_root, obj["worktree"])
        else:
            error = result.get("error", "")
            conflicts = result.get("conflicts", [])
            log.error("Merge failed for %s: %s", obj["id"], error)

            # Auto-dispatch an integrator session to resolve the conflict
            # Only escalate to human after MAX_AUTO_RETRIES attempts
            retry_count = int(obj.get("retry_count") or 0)
            feedback = f"Merge conflict: {error}"

            if retry_count < MAX_AUTO_RETRIES:
                log.info("Merge conflict for %s — dispatching integrator to resolve (attempt %d/%d)",
                         obj["id"], retry_count + 1, MAX_AUTO_RETRIES)
                db.update_objective(obj["id"], {
                    "status": "active",
                    "retry_count": retry_count + 1,
                    "review_feedback": feedback,
                })
                _dispatch_conflict_resolution(db, project, obj, conflicts, feedback)
            else:
                log.warning("Objective %s exceeded max retries for merge conflict, escalating to needs_review",
                            obj["id"])
                db.update_objective(obj["id"], {
                    "status": "needs_review",
                    "review_feedback": feedback,
                })
                db.emit_event(project["id"], "objective_needs_human_review", {
                    "objective_id": obj["id"],
                    "reason": "merge_conflict",
                    "error": error,
                    "conflicts": conflicts,
                })
                log.warning("Objective %s escalated to needs_review (merge conflict)", obj["id"])

    return merged


def _dispatch_conflict_resolution(db: PaddockDB, project: dict, objective: dict,
                                   conflicts: list[str], feedback: str) -> None:
    """Dispatch an integrator session to resolve merge conflicts.

    The integrator runs in the existing worktree, does 'git merge main',
    resolves conflicts (preserving both sides' functionality), then commits.
    """
    repo_root = resolve_project_path(project["repo_root"])
    worktrees_root = resolve_project_path(project["worktrees_root"])

    # Use integrator worker for conflict resolution
    worker = db.get_worker("integrator")
    if not worker:
        workers = db.list_workers()
        worker = next((w for w in workers if w.get("role_type") == "integrator"), None)
        if not worker and workers:
            worker = workers[0]

    agent = _select_agent(db, worker)
    if not agent:
        log.error("No available agent for conflict resolution on %s", objective["id"])
        return

    # Reuse existing worktree
    branch = objective.get("branch")
    worktree_path = Path(objective["worktree"]) if objective.get("worktree") else None
    if not worktree_path or not worktree_path.exists():
        try:
            branch, worktree_path = ensure_worktree(repo_root, worktrees_root, objective["id"])
            db.update_objective(objective["id"], {"branch": branch, "worktree": str(worktree_path)})
        except Exception as e:
            log.error("Failed to create worktree for conflict resolution: %s", e)
            return

    conflict_files_str = "\n".join(f"- {f}" for f in conflicts)
    prompt = f"""# 合并冲突修复会话

你的任务是解决以下分支合并到 main 时产生的代码冲突。

## 冲突信息

分支：{branch}
冲突文件：
{conflict_files_str}

## 操作步骤

1. 执行 `git merge main` 将 main 的最新代码合并进来
2. 对每个冲突文件，解决冲突标记（<<<<<<< / ======= / >>>>>>>）
   - **保留双方的功能**，不要丢弃任何一方的代码
   - 如果两边改了同一个类/函数，合并两边的改动
   - 如果有语义矛盾（如一边删了某个类，另一边引用了它），以引用方为准（补全缺失的定义）
3. `git add` 所有解决后的文件
4. `git commit -m "fix: resolve merge conflicts with main"`
5. 验证代码可以正常导入：`python -c "from src.main import app"`

## 注意

- 不要用 `git checkout --theirs` 或 `git checkout --ours` 直接覆盖
- 必须手动合并，保证双方功能都保留
- 修复完成后输出会话总结

{_build_session_summary_template()}"""

    ensure_runtime_dirs(project["id"])
    prompt_file = PADDOCK_ROOT / "runtime" / "projects" / project["id"] / "logs" / f"conflict-{objective['id']}.md"
    prompt_file.write_text(prompt, encoding="utf-8")

    budget = {"max_commits": 3, "max_minutes": 30}
    cmd = render_agent_command(agent["command_template"], str(prompt_file), str(worktree_path))
    log_file = str(PADDOCK_ROOT / "runtime" / "projects" / project["id"] / "logs" / f"conflict-session-{objective['id']}.log")

    use_shell = isinstance(cmd, str)
    with open(log_file, "w") as lf:
        process = subprocess.Popen(
            cmd, cwd=str(worktree_path),
            stdout=lf, stderr=subprocess.STDOUT,
            env=build_agent_env(agent),
            shell=use_shell,
        )

    session_id = db.create_session({
        "objective_id": objective["id"],
        "project_id": project["id"],
        "agent_id": agent["id"],
        "status": "running",
        "pid": process.pid,
        "budget": budget,
        "prompt": prompt,
        "log_file": log_file,
    })

    db.emit_event(project["id"], "conflict_resolution_started", {
        "objective_id": objective["id"],
        "session_id": session_id,
        "conflicts": conflicts,
    })
    log.info("Conflict resolution session %d started for %s (pid=%d, files=%s)",
             session_id, objective["id"], process.pid, conflicts)


def _build_session_summary_template() -> str:
    return """---SESSION_SUMMARY---
status: completed | partial | blocked
commits_made: <数量>
acceptance_criteria_met:
  - merge_conflicts_resolved: true | false
summary: |
  说明解决了哪些冲突，保留了哪些功能。
needs_follow_up: false
---END_SESSION_SUMMARY---"""


# ============================================================
# Phase 4: Unlock ready objectives
# ============================================================

def unlock_ready_objectives(db: PaddockDB, project: dict) -> list[str]:
    """Transition todo → ready when dependencies are met."""
    unlocked: list[str] = []
    for obj in db.list_objectives(project["id"], status=["todo"]):
        deps = _json_loads(obj.get("depends_on")) or []
        if not deps:
            db.update_objective(obj["id"], {"status": "ready"})
            db.emit_event(project["id"], "objective_ready", {"objective_id": obj["id"]})
            unlocked.append(obj["id"])
            continue

        all_done = True
        blocked_by: list[str] = []
        for dep_id in deps:
            dep = db.get_objective(dep_id)
            if not dep or dep["status"] != "done":
                all_done = False
                # If dependency is permanently stuck, escalate downstream too
                if dep and dep["status"] in ("failed", "needs_review"):
                    blocked_by.append(dep_id)

        if all_done:
            db.update_objective(obj["id"], {"status": "ready"})
            db.emit_event(project["id"], "objective_ready", {"objective_id": obj["id"]})
            unlocked.append(obj["id"])
        elif blocked_by:
            # Dependency failed/needs_review → escalate this objective too
            feedback = f"依赖任务未完成，需要人工处理：{', '.join(blocked_by)}"
            db.update_objective(obj["id"], {
                "status": "needs_review",
                "review_feedback": feedback,
            })
            db.emit_event(project["id"], "objective_needs_human_review", {
                "objective_id": obj["id"],
                "reason": "blocked_dependency",
                "blocked_by": blocked_by,
            })
            log.warning("Objective %s blocked by failed deps: %s", obj["id"], blocked_by)

    if unlocked:
        log.info("Unlocked objectives: %s", ", ".join(unlocked))
    return unlocked


# ============================================================
# Phase 5: Planner trigger
# ============================================================

def planner_needed(db: PaddockDB, project: dict, cooldown_seconds: int) -> bool:
    """Determine if we should start the planner."""
    latest = db.get_latest_planner_run(project["id"])

    # Already running
    if latest and latest["status"] == "running":
        pid = latest.get("pid")
        if pid and pid_alive(int(pid)):
            return False
        # PID died — mark as failed
        db.update_planner_run(latest["id"], {
            "status": "failed",
            "finished_at": _now(),
            "error_message": "Process died unexpectedly",
        })

    # Cooldown
    if latest and latest.get("finished_at"):
        elapsed = time.time() - (_parse_iso(latest["finished_at"]) or 0)
        if elapsed < cooldown_seconds:
            return False

    # Stop if Goal is completed
    goal = db.get_active_goal(project["id"])
    if not goal:
        # No active goal — check if all goals are completed
        all_goals = db.list_goals(project["id"])
        if all_goals and all(g["status"] == "completed" for g in all_goals):
            log.info("All goals completed for project %s — planner not needed", project["id"])
            return False

    # Stop if current Phase is completed (waiting for advance_goal_state to run)
    phase = db.get_active_phase(project["id"])
    if not phase:
        return False  # No active phase — state machine needs to advance first

    # If phase has checks and none have passed yet, pause planner until checks run
    # (prevents Planner from over-planning when phase is actually done)
    phase = db.get_active_phase(project["id"])
    if phase:
        checks = db.list_phase_checks(phase["id"], project["id"])
        if checks:
            non_passed = [c for c in checks if c["status"] != "passed"]
            all_work_done = not db.list_objectives(project["id"], status=["active", "ready"])
            if all_work_done and non_passed:
                # Phase has pending/failed checks and no active work — wait for checks to run
                log.debug("Planner paused: waiting for phase checks to execute (%d pending)",
                          len(non_passed))
                return False

    # Supply check
    max_parallel = project.get("max_parallel_sessions", DEFAULT_MAX_PARALLEL)
    ready = db.list_objectives(project["id"], status=["ready"])
    active = db.get_active_sessions(project["id"])
    supply = len(ready) + len(active)

    return supply < max_parallel


def start_planner(db: PaddockDB, project: dict) -> None:
    """Start a planner subprocess."""
    scripts_dir = Path(__file__).resolve().parent
    planner_script = scripts_dir / "planner.py"

    if not planner_script.exists():
        log.warning("Planner script not found: %s", planner_script)
        return

    log_file = str(PADDOCK_ROOT / "runtime" / "projects" / project["id"] / "logs" / f"planner-{int(time.time())}.log")
    Path(log_file).parent.mkdir(parents=True, exist_ok=True)

    cmd = [sys.executable, str(planner_script), "--project", project["id"]]

    with open(log_file, "w") as lf:
        process = subprocess.Popen(
            cmd, cwd=str(PADDOCK_ROOT),
            stdout=lf, stderr=subprocess.STDOUT,
        )

    run_id = db.create_planner_run({
        "project_id": project["id"],
        "status": "running",
        "pid": process.pid,
        "log_file": log_file,
    })

    db.emit_event(project["id"], "planner_started", {
        "planner_run_id": run_id,
        "pid": process.pid,
    })
    log.info("Planner started (pid=%d, run=%d)", process.pid, run_id)


# ============================================================
# Phase 6: Apply planner output
# ============================================================

def apply_planner_output(db: PaddockDB, project: dict) -> int:
    """Apply completed planner output: create new objectives."""
    latest = db.get_latest_planner_run(project["id"])
    if not latest:
        return 0

    # Check if running planner has finished
    if latest["status"] == "running":
        pid = latest.get("pid")
        if pid and pid_alive(int(pid)):
            return 0
        # Process finished — read output
        plan_output = None
        if latest.get("log_file") and Path(latest["log_file"]).exists():
            plan_output = Path(latest["log_file"]).read_text(encoding="utf-8", errors="replace")
        db.update_planner_run(latest["id"], {
            "status": "completed",
            "finished_at": _now(),
            "plan_output": plan_output,
        })
        latest = db.get_latest_planner_run(project["id"])
        if not latest:
            return 0

    if latest["status"] != "completed" or latest.get("applied_at"):
        return 0

    plan_output = latest.get("plan_output", "")
    if not plan_output:
        db.update_planner_run(latest["id"], {"applied_at": _now()})
        return 0

    objectives = _parse_planner_objectives(plan_output)
    added = 0
    phase_done_signal = (objectives is not None and len(objectives) == 0)

    for obj_def in (objectives or []):
        obj_id = obj_def.get("id")
        if not obj_id:
            continue
        if db.get_objective(obj_id):
            log.info("Objective %s already exists, skipping", obj_id)
            continue

        db.create_objective({
            "id": obj_id,
            "project_id": project["id"],
            "phase_id": obj_def.get("phase_id"),
            "worker_id": obj_def.get("worker_id"),
            "title": obj_def.get("title", obj_id),
            "description": obj_def.get("description", ""),
            "acceptance_criteria": obj_def.get("acceptance_criteria", []),
            "path_scope": obj_def.get("path_scope", []),
            "depends_on": obj_def.get("depends_on", []),
            "context_refs": obj_def.get("context_refs", []),
            "status": "todo",
            "priority": obj_def.get("priority", 0),
            "session_budget": obj_def.get("session_budget"),
        })
        added += 1
        log.info("Created objective: %s — %s", obj_id, obj_def.get("title", ""))

    db.update_planner_run(latest["id"], {"applied_at": _now()})
    if added:
        db.emit_event(project["id"], "plan_applied", {
            "planner_run_id": latest["id"],
            "objectives_added": added,
        })
    if phase_done_signal:
        # Planner returned empty list — extract reasoning
        reasoning = ""
        try:
            import re as _re, yaml as _yaml
            match = _re.search(r"```ya?ml\s*\n(.*?)```", plan_output, _re.DOTALL | _re.IGNORECASE)
            raw = match.group(1) if match else plan_output
            data = _yaml.safe_load(raw)
            if isinstance(data, dict):
                reasoning = data.get("reasoning", "")
        except Exception:
            pass
        log.info("Planner returned 0 objectives. Reasoning: %s", reasoning[:200])
        db.emit_event(project["id"], "planner_phase_done_signal", {
            "planner_run_id": latest["id"],
            "reasoning": reasoning[:500],
        })
        return -1  # Sentinel: planner said nothing left to do in current phase

    return added


def run_phase_checks(db: PaddockDB, project: dict) -> tuple[bool, int, int]:
    """Execute all phase_checks for the active phase.

    Returns (all_passed, passed_count, total_count).
    Only runs checks if there are no active/ready objectives (work must be done first).
    """
    project_id = project["id"]
    phase = db.get_active_phase(project_id)
    if not phase:
        return False, 0, 0

    checks = db.list_phase_checks(phase["id"], project_id)
    if not checks:
        return False, 0, 0

    # Don't run checks if there's still active work
    active_objs = db.list_objectives(project_id, status=["active", "ready"])
    if active_objs:
        return False, 0, len(checks)

    repo_root = resolve_project_path(project["repo_root"])
    passed = 0

    for check in checks:
        if check["status"] == "passed":
            passed += 1
            continue  # Already passed, skip re-running

        cmd = check["check_command"]
        try:
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True,
                timeout=30, cwd=str(repo_root),
            )
            output = (result.stdout + result.stderr).strip()
            expected = check.get("expected") or ""

            if result.returncode == 0 and (not expected or expected in output):
                db.update_phase_check(check["id"], "passed", output)
                log.info("Phase check PASSED: %s", check["description"])
                passed += 1
            else:
                db.update_phase_check(check["id"], "failed", output)
                log.info("Phase check FAILED: %s | output: %s", check["description"], output[:100])
        except subprocess.TimeoutExpired:
            db.update_phase_check(check["id"], "failed", "timeout")
            log.warning("Phase check TIMEOUT: %s", check["description"])
        except Exception as e:
            db.update_phase_check(check["id"], "failed", str(e))
            log.error("Phase check ERROR: %s | %s", check["description"], e)

    total = len(checks)
    all_passed = (passed == total)
    log.info("Phase checks: %d/%d passed for phase '%s'", passed, total, phase["title"])

    if all_passed:
        db.emit_event(project_id, "phase_checks_passed", {
            "phase_id": phase["id"], "title": phase["title"], "checks": total
        })

    return all_passed, passed, total


def advance_goal_state(db: PaddockDB, project: dict, checks_all_passed: bool) -> None:
    """State machine: Phase → Milestone → Goal completion.

    Triggered only when all phase_checks pass. Strictly one-directional — no rollback.
    """
    if not checks_all_passed:
        return

    project_id = project["id"]
    phase = db.get_active_phase(project_id)
    if not phase:
        return

    # Mark current Phase completed
    db.upsert_phase({**phase, "status": "completed"})
    log.info("Phase '%s' marked completed (all checks passed)", phase["title"])
    db.emit_event(project_id, "phase_completed", {"phase_id": phase["id"], "title": phase["title"]})

    # Find next todo Phase in same Milestone
    milestone_id = phase["milestone_id"]
    all_phases = db.list_phases(project_id, milestone_id=milestone_id)
    next_phase = next(
        (p for p in sorted(all_phases, key=lambda x: x.get("sort_order", 0))
         if p["status"] == "todo"),
        None
    )

    if next_phase:
        db.upsert_phase({**next_phase, "status": "active"})
        log.info("Advanced to Phase '%s'", next_phase["title"])
        db.emit_event(project_id, "phase_started", {"phase_id": next_phase["id"], "title": next_phase["title"]})
        return

    # All Phases in this Milestone done → complete Milestone
    milestone = db.get_active_milestone(project_id)
    if not milestone:
        return
    db.upsert_milestone({**milestone, "status": "completed"})
    log.info("Milestone '%s' marked completed", milestone["title"])
    db.emit_event(project_id, "milestone_completed", {"milestone_id": milestone["id"], "title": milestone["title"]})

    # Find next todo Milestone in same Goal
    goal_id = milestone["goal_id"]
    all_milestones = db.list_milestones(project_id, goal_id=goal_id)
    next_milestone = next(
        (m for m in sorted(all_milestones, key=lambda x: x.get("sort_order", 0))
         if m["status"] == "todo"),
        None
    )

    if next_milestone:
        db.upsert_milestone({**next_milestone, "status": "active"})
        # Activate first Phase of new Milestone
        new_phases = db.list_phases(project_id, milestone_id=next_milestone["id"])
        first_phase = next(
            (p for p in sorted(new_phases, key=lambda x: x.get("sort_order", 0))
             if p["status"] == "todo"),
            None
        )
        if first_phase:
            db.upsert_phase({**first_phase, "status": "active"})
            log.info("Advanced to Milestone '%s' / Phase '%s'",
                     next_milestone["title"], first_phase["title"])
        db.emit_event(project_id, "milestone_started", {
            "milestone_id": next_milestone["id"], "title": next_milestone["title"]
        })
        return

    # All Milestones done → complete Goal
    goal = db.get_active_goal(project_id)
    if not goal:
        return
    db.upsert_goal({**goal, "status": "completed"})
    log.info("🎉 Goal '%s' completed! Project done.", goal["title"])
    db.emit_event(project_id, "goal_completed", {"goal_id": goal["id"], "title": goal["title"]})


def _parse_planner_objectives(raw_output: str) -> list[dict]:
    """Parse planner output to extract objective definitions."""
    import yaml as _yaml

    # Find YAML block in output
    # Try to find ```yaml ... ``` block first
    import re
    yaml_match = re.search(r'```ya?ml\s*\n(.*?)```', raw_output, re.DOTALL)
    if yaml_match:
        yaml_text = yaml_match.group(1)
    else:
        # Try to parse the whole output as YAML
        yaml_text = raw_output

    try:
        data = _yaml.safe_load(yaml_text)
    except Exception:
        log.error("Failed to parse planner output as YAML")
        return []

    if isinstance(data, dict):
        return data.get("objectives", [])
    return []


# ============================================================
# Phase 7: Dispatch ready objectives
# ============================================================

def dispatch_ready_objectives(db: PaddockDB, project: dict, dry_run: bool = False) -> list[str]:
    """Start sessions for ready objectives.

    Each objective runs in its own git worktree, so parallel work on the same
    files is safe. Conflicts are resolved at merge time, not dispatch time.
    """
    max_parallel = project.get("max_parallel_sessions", DEFAULT_MAX_PARALLEL)
    active_sessions = db.get_active_sessions(project["id"])
    available_slots = max_parallel - len(active_sessions)

    if available_slots <= 0:
        return []

    ready = db.get_ready_objectives(project["id"], max_count=available_slots + 5)
    dispatched: list[str] = []

    # Only skip objectives that already have a running session
    active_objective_ids = {s["objective_id"] for s in active_sessions}

    for obj in ready:
        if len(dispatched) >= available_slots:
            break

        if obj["id"] in active_objective_ids:
            continue

        if dry_run:
            log.info("[DRY RUN] Would dispatch objective: %s", obj["id"])
            dispatched.append(obj["id"])
            continue

        try:
            session_id = _dispatch_one(db, project, obj)
        except Exception as e:
            log.error("Failed to dispatch %s: %s", obj["id"], e)
            continue
        if session_id:
            dispatched.append(obj["id"])
            active_objective_ids.add(obj["id"])

    if dispatched:
        log.info("Dispatched: %s", ", ".join(dispatched))
    return dispatched


def _dispatch_one(db: PaddockDB, project: dict, objective: dict) -> int | None:
    """Dispatch a single objective as a new session."""
    # Resolve paths
    repo_root = resolve_project_path(project["repo_root"])
    worktrees_root = resolve_project_path(project["worktrees_root"])

    # Select worker and agent
    worker = None
    if objective.get("worker_id"):
        worker = db.get_worker(objective["worker_id"])
    if not worker:
        workers = db.list_workers()
        worker = workers[0] if workers else None

    agent = _select_agent(db, worker)
    if not agent:
        log.error("No available agent for objective %s", objective["id"])
        return None

    # Ensure worktree — retry once if creation fails (stale lock/ref)
    try:
        branch, worktree_path = ensure_worktree(repo_root, worktrees_root, objective["id"])
    except Exception as e:
        log.warning("Worktree creation failed for %s (%s), retrying after prune", objective["id"], e)
        import subprocess as _sp
        _sp.run(["git", "worktree", "prune"], cwd=str(repo_root), check=False)
        branch, worktree_path = ensure_worktree(repo_root, worktrees_root, objective["id"])

    # Verify worktree directory actually exists before launching agent
    if not worktree_path.exists():
        log.error("Worktree path does not exist after creation: %s", worktree_path)
        raise RuntimeError(f"Worktree path missing: {worktree_path}")

    # Compute session budget
    budget = _compute_budget(project, objective)

    # Build prompt
    prompt = _build_session_prompt(db, project, objective, worker, budget)

    # Write prompt to temp file
    ensure_runtime_dirs(project["id"])
    prompt_file = PADDOCK_ROOT / "runtime" / "projects" / project["id"] / "logs" / f"prompt-{objective['id']}.md"
    prompt_file.write_text(prompt, encoding="utf-8")

    # Render command
    cmd = render_agent_command(
        agent["command_template"],
        str(prompt_file),
        str(worktree_path),
    )

    # Start process
    log_file = str(PADDOCK_ROOT / "runtime" / "projects" / project["id"] / "logs" / f"session-{objective['id']}.log")

    use_shell = isinstance(cmd, str)
    with open(log_file, "w") as lf:
        process = subprocess.Popen(
            cmd, cwd=str(worktree_path),
            stdout=lf, stderr=subprocess.STDOUT,
            env=build_agent_env(agent),
            shell=use_shell,
        )

    # Update DB
    session_id = db.create_session({
        "objective_id": objective["id"],
        "project_id": project["id"],
        "agent_id": agent["id"],
        "status": "running",
        "pid": process.pid,
        "budget": budget,
        "prompt": prompt,
        "log_file": log_file,
    })

    db.update_objective(objective["id"], {
        "status": "active",
        "branch": branch,
        "worktree": str(worktree_path),
    })

    db.emit_event(project["id"], "session_started", {
        "session_id": session_id,
        "objective_id": objective["id"],
        "agent_id": agent["id"],
        "pid": process.pid,
    })

    log.info("Started session %d for %s (agent=%s, pid=%d)",
             session_id, objective["id"], agent["id"], process.pid)
    return session_id


def _select_agent(db: PaddockDB, worker: dict | None) -> dict | None:
    """Select an agent based on worker strategy."""
    if worker:
        mode = worker.get("strategy_mode", "fixed")
        if mode == "fixed" and worker.get("strategy_fixed_agent"):
            agent = db.get_agent(worker["strategy_fixed_agent"])
            if agent and agent.get("enabled"):
                return agent

        priority = _json_loads(worker.get("strategy_agent_priority")) or []
        for agent_id in priority:
            agent = db.get_agent(agent_id)
            if agent and agent.get("enabled"):
                return agent

    # Fallback: first enabled agent
    agents = db.list_agents(enabled_only=True)
    return agents[0] if agents else None


def _compute_budget(project: dict, objective: dict) -> dict:
    """Compute session budget from objective override or project defaults."""
    obj_budget = _json_loads(objective.get("session_budget"))
    if obj_budget:
        return obj_budget

    defaults = _json_loads(project.get("session_defaults")) or {}
    return {
        "max_commits": defaults.get("max_commits_per_session", 5),
        "max_minutes": defaults.get("max_minutes_per_session", 30),
    }


def _build_session_prompt(db: PaddockDB, project: dict, objective: dict,
                          worker: dict | None, budget: dict) -> str:
    """Build the prompt sent to the agent for a session."""
    acceptance_criteria = _json_loads(objective.get("acceptance_criteria")) or []
    path_scope = _json_loads(objective.get("path_scope")) or []
    context_refs = _json_loads(objective.get("context_refs")) or []

    criteria_lines = "\n".join(f"- {c}" for c in acceptance_criteria) or "- (none specified)"
    scope_lines = "\n".join(f"- `{p}`" for p in path_scope) or "- (unrestricted)"
    refs_lines = "\n".join(f"- `{r}`" for r in context_refs) or "- (none)"

    # Load custom template if worker specifies one
    template_name = None
    if worker:
        role_type = worker.get("role_type", "implementer")
        template_name = f"session-{role_type}.md"

    template_path = PADDOCK_ROOT / "templates" / (template_name or "session-worker.md")
    if template_path.exists():
        template = template_path.read_text(encoding="utf-8")
        # Variable substitution
        template = template.replace("{objective.title}", objective["title"])
        template = template.replace("{objective.description}", objective.get("description", ""))
        template = template.replace("{acceptance_criteria_list}", criteria_lines)
        template = template.replace("{path_scope_list}", scope_lines)
        template = template.replace("{context_refs_list}", refs_lines)
        template = template.replace("{budget.max_commits}", str(budget.get("max_commits", 5)))
        template = template.replace("{budget.max_minutes}", str(budget.get("max_minutes", 30)))
        return template

    # Inline fallback prompt
    return f"""# 工作会话

你正在一个 Paddock 工作会话中。你的任务是自主完成以下目标。

## 目标

**{objective["title"]}**

{objective.get("description", "")}

## 验收标准

{criteria_lines}

## 工作范围

你只能修改以下路径内的文件：
{scope_lines}

## 参考文件

在开始工作前，请先阅读以下文件以了解上下文：
{refs_lines}

## 会话规则

1. **自主迭代**：你可以在本次会话中进行多次修改和提交。不需要等待外部反馈。
2. **每完成一个有意义的步骤就提交**：用 git commit 记录你的进展。每次提交应该是一个可编译/可运行的状态。
3. **提交信息要清晰**：说明这次提交完成了什么、为什么这么做。
4. **会话预算**：本次会话最多 {budget.get("max_commits", 5)} 个提交，{budget.get("max_minutes", 30)} 分钟。请合理规划工作。
5. **路径限制**：不要修改 path_scope 之外的文件。如果发现需要修改范围外的文件，在会话总结中说明。
6. **完成判断**：当所有验收标准都满足时，结束工作。

## 工作流程

1. 阅读参考文件，理解上下文
2. 制定实现计划
3. 逐步实现，每个有意义的步骤做一次 commit
4. 验证所有验收标准是否满足
5. 输出会话总结

## 会话总结格式

在完成所有工作后（或预算耗尽时），请输出以下格式的总结：

---SESSION_SUMMARY---
status: completed | partial | blocked
commits_made: <数量>
acceptance_criteria_met:
  - criteria_1: true | false
  - criteria_2: true | false
summary: |
  简要总结完成了什么工作、遇到了什么问题。
  如果有未完成的部分，说明原因和建议的后续步骤。
needs_follow_up: true | false
follow_up_notes: |
  如果 needs_follow_up=true，说明需要什么后续工作。
out_of_scope_changes_needed: |
  如果发现需要修改 path_scope 之外的文件，在这里说明。
---END_SESSION_SUMMARY---
"""


# ============================================================
# Main loop
# ============================================================

def _process_one_project(
    db: PaddockDB,
    project: dict,
    planner_cooldown: int,
    dry_run: bool,
    log_lock: Lock,
) -> None:
    """Run one full supervisor iteration for a single project.

    Designed to be called from a ThreadPoolExecutor worker — each project
    gets its own thread so slow LLM calls or subprocess waits in one project
    don't block others.

    # TODO(asyncio): Replace ThreadPoolExecutor with asyncio.gather() once the
    # internal blocking calls are migrated:
    #   - process_checkpoint_reviews → async HTTP (httpx AsyncClient)
    #   - start_planner / dispatch → asyncio.create_subprocess_exec
    #   - PaddockDB → aiosqlite (or run_in_executor for SQLite)
    # At that point this function becomes: async def _process_one_project(...)
    # and the executor wrapper in _run_one_iteration can be removed.
    """
    ensure_runtime_dirs(project["id"])

    # Phase 1: Harvest finished sessions
    harvested = harvest_finished_sessions(db, project)

    # Phase 2: Review checkpoints
    # TODO(asyncio): This calls an LLM synchronously and is the main blocking
    # hotspot. High-priority candidate for async migration.
    process_checkpoint_reviews(db, project)

    # Phase 3: Merge completed objectives
    merged = merge_completed_objectives(db, project)

    # Phase 4: Unlock ready objectives (dependency graph)
    unlocked = unlock_ready_objectives(db, project)

    # Phase 5: Trigger planner if needed
    if planner_needed(db, project, planner_cooldown):
        with log_lock:
            log.info("Starting planner for project %s", project["id"])
        if not dry_run:
            # TODO(asyncio): start_planner launches a subprocess; replace with
            # asyncio.create_subprocess_exec so we can await it without blocking.
            start_planner(db, project)
        else:
            log.info("[DRY RUN] Would start planner for %s", project["id"])

    # Phase 6: Apply planner output
    added = apply_planner_output(db, project)
    if added == -1:
        added = 0

    # Phase 6.5: Run phase checks → advance state machine if all pass
    checks_passed, n_passed, n_total = run_phase_checks(db, project)
    if n_total > 0:
        with log_lock:
            log.info("Project %s phase checks: %d/%d passed", project["id"], n_passed, n_total)
    advance_goal_state(db, project, checks_all_passed=checks_passed)

    # Phase 7: Dispatch ready objectives to agent sessions
    # TODO(asyncio): dispatch also launches subprocesses; same migration path
    # as start_planner above.
    dispatched = dispatch_ready_objectives(db, project, dry_run=dry_run)

    if any([harvested, merged, unlocked, added, dispatched]):
        with log_lock:
            log.info(
                "Project %s: harvested=%d merged=%d unlocked=%d planned=%d dispatched=%d",
                project["id"], len(harvested), len(merged), len(unlocked), added, len(dispatched),
            )


def _run_one_iteration(
    db: PaddockDB,
    projects: list[dict],
    planner_cooldown: int,
    dry_run: bool,
) -> None:
    """Process all active projects concurrently using a thread pool.

    Each project runs in its own thread so one slow project (e.g. LLM review
    taking 30s) doesn't delay others.

    # TODO(asyncio): Replace with:
    #     await asyncio.gather(*[
    #         _process_one_project(db, p, planner_cooldown, dry_run)
    #         for p in projects
    #     ])
    # once _process_one_project is fully async.
    """
    if not projects:
        log.warning("No active projects found")
        return

    if len(projects) == 1:
        # Fast path: skip thread overhead for single project
        try:
            _process_one_project(db, projects[0], planner_cooldown, dry_run, Lock())
        except Exception as e:
            log.error("Error processing project %s: %s", projects[0]["id"], e, exc_info=True)
        return

    # One thread per project — projects are I/O-bound (LLM calls, subprocesses)
    # so thread-per-project is efficient and avoids GIL contention.
    log_lock = Lock()  # Prevent interleaved log lines across threads
    with ThreadPoolExecutor(max_workers=len(projects), thread_name_prefix="paddock-project") as pool:
        futures = {
            pool.submit(_process_one_project, db, project, planner_cooldown, dry_run, log_lock): project
            for project in projects
        }
        for future in as_completed(futures):
            project = futures[future]
            try:
                future.result()
            except Exception as e:
                log.error("Error processing project %s: %s", project["id"], e, exc_info=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Paddock Supervisor V2")
    parser.add_argument("--duration-minutes", type=int, default=DEFAULT_DURATION_MINUTES)
    parser.add_argument("--poll-seconds", type=int, default=DEFAULT_POLL_SECONDS)
    parser.add_argument("--max-parallel", type=int, default=None,
                        help="Override project max_parallel_sessions")
    parser.add_argument("--planner-cooldown", type=int, default=DEFAULT_PLANNER_COOLDOWN)
    parser.add_argument("--project", type=str, default=None,
                        help="Only process this project (default: all enabled)")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--once", action="store_true", help="Run one iteration then exit")
    args = parser.parse_args()

    db = PaddockDB()
    db.initialize()

    deadline = time.time() + args.duration_minutes * 60
    iteration = 0

    log.info("Supervisor V2 started (duration=%dm, poll=%ds, dry_run=%s)",
             args.duration_minutes, args.poll_seconds, args.dry_run)

    while True:
        iteration += 1

        if args.project:
            project = db.get_project(args.project)
            projects = [project] if project else []
        else:
            projects = db.list_active_projects()

        # Apply max_parallel override to all projects before dispatching
        if args.max_parallel is not None:
            for p in projects:
                p["max_parallel_sessions"] = args.max_parallel

        _run_one_iteration(db, projects, args.planner_cooldown, args.dry_run)

        if args.once:
            log.info("Single iteration complete, exiting.")
            break

        if time.time() >= deadline:
            log.info("Duration reached (%dm). Waiting for active sessions...", args.duration_minutes)
            _graceful_shutdown(db, args.project, timeout=120)
            break

        time.sleep(args.poll_seconds)


def _graceful_shutdown(db: PaddockDB, project_filter: str | None, timeout: int = 120) -> None:
    """Wait for active sessions to finish before exiting."""
    deadline = time.time() + timeout

    while time.time() < deadline:
        if project_filter:
            project = db.get_project(project_filter)
            projects = [project] if project else []
        else:
            projects = db.list_active_projects()

        total_active = 0
        for project in projects:
            active = db.get_active_sessions(project["id"])
            # Check which are still alive
            alive = [s for s in active if s.get("pid") and pid_alive(int(s["pid"]))]
            total_active += len(alive)

            # Harvest any that have finished
            harvest_finished_sessions(db, project)
            process_checkpoint_reviews(db, project)
            merge_completed_objectives(db, project)

        if total_active == 0:
            log.info("All sessions completed. Exiting.")
            return

        log.info("Waiting for %d active session(s)...", total_active)
        time.sleep(10)

    log.warning("Graceful shutdown timeout reached. %d session(s) still running.", total_active)


if __name__ == "__main__":
    main()
