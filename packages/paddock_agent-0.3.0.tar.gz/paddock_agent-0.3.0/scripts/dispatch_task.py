from __future__ import annotations

import argparse

from common import (
    CONTEXT,
    REVIEWS_PATH,
    BOARD_PATH,
    TASKS_PATH,
    TEMPLATES_DIR,
    emit_event,
    ensure_runtime_dirs,
    ensure_worktree,
    get_task,
    load_tasks,
    project_read_paths,
    prompt_path,
    relative_runtime_path,
    save_tasks,
)


def build_prompt(task: dict) -> str:
    lines = [
        f"你是本轮任务的执行 agent，角色类型：{task['role']}。",
        "不要依赖聊天上下文，先阅读项目工件后再开始。",
        "",
        "项目工作区：",
        f"- repo: `{CONTEXT.repo_root}`",
        f"- worktree: `{task.get('worktree', '')}`",
        "",
        "开始前先读：",
    ]

    read_paths = project_read_paths() + [TASKS_PATH, BOARD_PATH, REVIEWS_PATH]
    template_name = {
        "claude_worker": "claude-worker.md",
        "codex_worker": "codex-worker.md",
    }.get(task["role"], "codex-integrator.md")
    read_paths.append(TEMPLATES_DIR / template_name)

    for index, path in enumerate(read_paths, start=1):
        lines.append(f"{index}. `{path}`")

    lines.extend(
        [
            "",
            f"任务 ID：{task['id']}",
            f"标题：{task['title']}",
            "",
            "允许修改路径：",
        ]
    )
    lines.extend([f"- `{path}`" for path in task.get("path_scope", [])])

    lines.extend(["", "依赖任务："])
    if task.get("depends_on"):
        lines.extend([f"- `{dep}`" for dep in task["depends_on"]])
    else:
        lines.append("- 无")

    lines.extend(["", "任务说明："])
    for note in task.get("notes", []):
        lines.append(f"- {note}")

    lines.extend(
        [
            "",
            "运行态路径：",
            f"- tasks: `{TASKS_PATH}`",
            f"- board: `{BOARD_PATH}`",
            f"- reviews: `{REVIEWS_PATH}`",
            "",
            "完成后必须：",
            "1. 提交当前 worktree 中与你任务相关的改动",
            "2. 写一份 docs/sessions/YYYY-MM-DD-<topic>.md",
            "3. 不直接 merge 到 main",
            "4. 结束时在最终回复中说明新增文件、验证方式、刻意没做的内容",
        ]
    )

    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a dispatch prompt and ensure task worktree exists.")
    parser.add_argument("task_id")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    ensure_runtime_dirs()
    data = load_tasks()
    task = get_task(data, args.task_id)
    ensure_worktree(task, dry_run=args.dry_run)
    prompt = build_prompt(task)
    target = prompt_path(task["id"])
    target.write_text(prompt, encoding="utf-8")
    save_tasks(data)
    emit_event(
        "dispatch_prompt_generated",
        task_id=task["id"],
        role=task["role"],
        branch=task.get("branch", ""),
        worktree=task.get("worktree", ""),
        prompt_file=relative_runtime_path(target),
    )
    print(target)


if __name__ == "__main__":
    main()
