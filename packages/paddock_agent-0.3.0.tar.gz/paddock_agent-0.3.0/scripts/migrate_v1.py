#!/usr/bin/env python3
"""
Migrate Paddock V1 data (YAML/JSONL files) into V2 SQLite database.

Reads:
- projects/*.yaml → projects table
- runtime/projects/*/tasks.yaml → objectives table
- runtime/projects/*/runs/*.json → sessions table
- runtime/projects/*/runs/events.jsonl → events table
- .paddock/project.yaml → goals/milestones/phases tables

Usage:
    python scripts/migrate_v1.py [--project my-project] [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

try:
    import paddock  # noqa: F401 — already installed via pip
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from paddock.db import PaddockDB
from paddock.config import DB_PATH, PADDOCK_ROOT


def load_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return rows


def migrate_project(db: PaddockDB, project_config_path: Path, dry_run: bool = False) -> None:
    """Migrate a single project from V1 YAML to V2 SQLite."""
    config = load_yaml(project_config_path)
    slug = config.get("slug", project_config_path.stem)

    print(f"\n=== Migrating project: {slug} ===")

    # 1. Project config
    project_data = {
        "id": slug,
        "name": config.get("name", slug),
        "repo_root": config.get("repo_root", ""),
        "worktrees_root": config.get("worktrees_root", ""),
        "integrator_only_patterns": config.get("integrator_only_patterns", []),
        "max_parallel_sessions": 2,
        "session_defaults": {"scope_level": "medium", "max_commits_per_session": 5, "max_minutes_per_session": 30},
        "enabled": True,
    }

    if not dry_run:
        db.upsert_project(project_data)
    print(f"  Project: {slug} ({config.get('name', slug)})")

    # 2. Goal management from project meta
    meta_path = config.get("project_meta_path")
    if meta_path:
        meta = load_yaml(Path(meta_path))
        _migrate_goals(db, slug, meta, dry_run)

    # 3. Tasks → Objectives
    runtime_root = Path(config.get("runtime_root", PADDOCK_ROOT / "runtime" / "projects" / slug))
    tasks_path = runtime_root / "tasks.yaml"
    tasks_data = load_yaml(tasks_path)
    tasks = tasks_data.get("tasks", [])

    obj_count = 0
    for task in tasks:
        task_id = task.get("id")
        if not task_id:
            continue

        # Map V1 status to V2 status
        v1_status = task.get("status", "todo")
        status_map = {
            "merged": "done",
            "in_progress": "active",
            "review": "active",
            "blocked": "failed",
            "ready": "ready",
            "todo": "todo",
        }
        v2_status = status_map.get(v1_status, "todo")

        # Map V1 role to V2 worker_id
        role_map = {
            "claude_worker": "implementer",
            "codex_worker": "researcher",
            "codex_integrator": "integrator",
        }
        worker_id = role_map.get(task.get("role", ""), "implementer")

        obj = {
            "id": task_id,
            "project_id": slug,
            "worker_id": worker_id,
            "title": task.get("title", task_id),
            "description": "\n".join(task.get("notes", [])) if isinstance(task.get("notes"), list) else str(task.get("notes", "")),
            "acceptance_criteria": task.get("outputs", []) if isinstance(task.get("outputs"), list) else [],
            "path_scope": task.get("path_scope", []),
            "depends_on": task.get("depends_on", []),
            "status": v2_status,
            "branch": task.get("branch"),
            "worktree": task.get("worktree"),
        }

        if not dry_run:
            try:
                db.create_objective(obj)
                obj_count += 1
            except Exception as e:
                print(f"  Warning: failed to create objective {task_id}: {e}")
        else:
            obj_count += 1

    print(f"  Objectives: {obj_count} migrated from {len(tasks)} tasks")

    # 4. Runs → Sessions
    runs_dir = runtime_root / "runs"
    session_count = 0
    if runs_dir.exists():
        for run_file in runs_dir.glob("*.json"):
            if run_file.name.startswith("_"):
                continue
            try:
                run_data = json.loads(run_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue

            task_id = run_data.get("task_id")
            if not task_id:
                continue

            session = {
                "objective_id": task_id,
                "project_id": slug,
                "status": {"in_progress": "running", "review": "completed", "merged": "completed"}.get(
                    run_data.get("status", ""), "completed"
                ),
                "pid": run_data.get("pid"),
                "budget": {"max_commits": 5, "max_minutes": 30},
                "log_file": run_data.get("log_file"),
                "started_at": run_data.get("started_at"),
                "finished_at": run_data.get("finished_at"),
            }

            if not dry_run:
                try:
                    db.create_session(session)
                    session_count += 1
                except Exception as e:
                    print(f"  Warning: failed to create session for {task_id}: {e}")
            else:
                session_count += 1

    print(f"  Sessions: {session_count} migrated")

    # 5. Events
    events_path = runtime_root / "runs" / "events.jsonl"
    events = load_jsonl(events_path)
    event_count = 0
    for event in events:
        if not dry_run:
            db.emit_event(
                slug,
                event.get("type", "unknown"),
                {k: v for k, v in event.items() if k not in ("type", "timestamp", "project")},
            )
        event_count += 1
    print(f"  Events: {event_count} migrated")


def _migrate_goals(db: PaddockDB, project_id: str, meta: dict, dry_run: bool) -> None:
    """Migrate goal management from project meta YAML."""
    # Try v2 structure first
    gm = meta.get("goal_management_v2") or meta.get("goal_management")
    if not gm:
        return

    # Handle v2 structure (goals/milestones/actions)
    goals = gm.get("goals", [])
    if not goals:
        # V1 structure: single goal
        old_goal = gm.get("goal", {})
        if old_goal:
            goals = [{"id": "goal-1", "title": old_goal.get("title", ""), "description": old_goal.get("description", "")}]

    for g in goals:
        goal_data = {
            "id": g.get("id", "goal-1"),
            "project_id": project_id,
            "title": g.get("title", ""),
            "description": g.get("description", ""),
            "status": g.get("status", "active"),
        }
        if not dry_run:
            db.upsert_goal(goal_data)

    milestones = gm.get("milestones", [])
    for m in milestones:
        ms_data = {
            "id": m.get("id", f"m-{milestones.index(m)}"),
            "project_id": project_id,
            "goal_id": m.get("goal_id", goals[0]["id"] if goals else "goal-1"),
            "title": m.get("title", ""),
            "description": m.get("description", ""),
            "status": m.get("status", "active"),
            "sort_order": m.get("order", milestones.index(m)),
        }
        if not dry_run:
            db.upsert_milestone(ms_data)

    # V2 actions → phases
    actions = gm.get("actions", [])
    phases = gm.get("phases", [])
    phase_source = phases if phases else actions

    for p in phase_source:
        phase_data = {
            "id": p.get("id", f"p-{phase_source.index(p)}"),
            "project_id": project_id,
            "milestone_id": p.get("milestone_id", milestones[0]["id"] if milestones else "m-0"),
            "title": p.get("title", ""),
            "description": p.get("description", ""),
            "status": p.get("status", "active"),
            "sort_order": phase_source.index(p),
        }
        if not dry_run:
            db.upsert_phase(phase_data)

    goal_count = len(goals)
    ms_count = len(milestones)
    phase_count = len(phase_source)
    print(f"  Goals: {goal_count}, Milestones: {ms_count}, Phases: {phase_count}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Migrate Paddock V1 data to V2 SQLite.")
    parser.add_argument("--project", type=str, default=None, help="Migrate specific project (default: all)")
    parser.add_argument("--db", type=str, default=str(DB_PATH), help="Database file path")
    parser.add_argument("--dry-run", action="store_true", help="Print what would be done without writing")
    parser.add_argument("--seed-agents", action="store_true", help="Also seed default agents/workers")
    args = parser.parse_args()

    db = PaddockDB(args.db)
    db.initialize()
    print(f"Database: {args.db}")

    if args.seed_agents:
        from init_db import seed_default_agents, seed_default_workers
        seed_default_agents(db)
        seed_default_workers(db)

    projects_dir = PADDOCK_ROOT / "projects"
    if args.project:
        config_path = projects_dir / f"{args.project}.yaml"
        if not config_path.exists():
            print(f"Error: {config_path} not found", file=sys.stderr)
            sys.exit(1)
        migrate_project(db, config_path, dry_run=args.dry_run)
    else:
        for config_path in sorted(projects_dir.glob("*.yaml")):
            migrate_project(db, config_path, dry_run=args.dry_run)

    print("\nMigration complete!")


if __name__ == "__main__":
    main()
