from __future__ import annotations

import argparse
import json

from common import emit_event, get_task, load_tasks, now_iso, read_json, run_state_path, save_tasks


def main() -> None:
    parser = argparse.ArgumentParser(description="Advance a completed run into review or blocked.")
    parser.add_argument("task_id")
    parser.add_argument("--exit-code", type=int, default=0)
    args = parser.parse_args()

    data = load_tasks()
    task = get_task(data, args.task_id)
    run_file = run_state_path(task["id"])
    payload = read_json(run_file) if run_file.exists() else {"task_id": task["id"]}

    if args.exit_code == 0:
        task["status"] = "review"
        payload["status"] = "review"
    else:
        task["status"] = "blocked"
        payload["status"] = "blocked"
        payload["failure_exit_code"] = args.exit_code

    payload["finished_at"] = now_iso()
    save_tasks(data)
    run_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    emit_event("task_finalized", task_id=task["id"], status=task["status"], exit_code=args.exit_code)
    print(task["status"])


if __name__ == "__main__":
    main()
