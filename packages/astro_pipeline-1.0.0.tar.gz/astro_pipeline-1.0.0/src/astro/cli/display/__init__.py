"""Rich dashboard package."""
