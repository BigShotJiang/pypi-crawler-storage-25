# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0](https://github.com/starlincs/astro/releases/tag/v1.0.0) - 2026-05-24

### Added

- First stable release (version 1.0.0)
