
    export CI_API_V4_URL=https://forge.apps.education.fr/api/v4 
    export CI_PAGES_DOMAIN=forge.apps.education.fr
    export CI_SERVER_URL=forge.apps.education.fr


SVT

    export CI_PROJECT_NAMESPACE_ID=XXX
    export CI_PROJECT_ID=XXX

Markdown

    export CI_PROJECT_NAMESPACE_ID=XXX
    export CI_PROJECT_ID=XXX

paternaultlouis

    export CI_PROJECT_NAMESPACE_ID=XXX
    export CI_PROJECT_ID=XXX

ferronier

    export CI_PROJECT_NAMESPACE_ID=27270
    export CI_PROJECT_ID=12471

---

- documenter
- améliorer les messages d'erreur
