# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Fonctions génériques pour faire des tests"""

import contextlib
import json
import pathlib
import tomllib
from collections.abc import Iterable, Iterator
from typing import Any

import yaml

from ferronier import data


@contextlib.contextmanager
def _load_json(filename: pathlib.Path | str) -> Iterator:
    with open(filename, encoding="utf8") as file:
        yield json.load(file)


@contextlib.contextmanager
def _load_yaml(filename: pathlib.Path | str) -> Iterator:
    with open(filename, encoding="utf8") as file:
        yield yaml.load(file.read(), Loader=yaml.Loader)


@contextlib.contextmanager
def _load_toml(filename: pathlib.Path | str) -> Iterator:
    with open(filename, mode="rb") as file:
        yield tomllib.load(file)


SUFFIXES = {
    "json": _load_json,
    "yaml": _load_yaml,
    "toml": _load_toml,
}


def datafiles(files: Iterable[pathlib.Path]) -> Iterable[tuple[pathlib.Path, Any, Any]]:
    """Itère les fichiers de tests.

    Prend en argument une liste de fichiers `FICHIER.toml`, et itère des
    triplets : `(FICHIER.toml, conf FICHIER.control.{json,yaml})`, où :

    - `FICHIER.toml` est le nom du fichier de configuration ;
    - `conf` est son contenu (interprété comme du TOML) ;
    - `FICHIER.control.{json,yaml,toml}` est le contenu fichier témoin (c'est-à-dire
      le résultat attendu), interprété comme du JSON ou YAML.
    """
    for configfile in files:
        with open(configfile, mode="rb") as config:
            for suffix, readfile in SUFFIXES.items():
                try:
                    with readfile(
                        configfile.with_suffix(f".control.{ suffix }")
                    ) as control:
                        yield (configfile, tomllib.load(config), control)
                except FileNotFoundError:
                    continue
