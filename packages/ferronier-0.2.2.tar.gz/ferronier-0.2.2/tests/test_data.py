# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Tests de la variable `data` du fichier de configuration"""

import contextlib
import pathlib
from typing import Any

import pytest

from ferronier import data
from ferronier.plugins import PLUGINS

from . import datafiles

DATADIR = pathlib.Path(__file__).parent / f"{pathlib.Path(__file__).stem}"

PLUGINS.load({"plugins": {"yaml": {}}})


@pytest.mark.parametrize("filename, config, control", datafiles(DATADIR.glob("*.toml")))
def test_data(filename: str | pathlib.Path, config: Any, control: Any):
    """Test la récupération des données de différentes manières."""
    # pylint: disable=unused-argument
    with contextlib.chdir(DATADIR):
        assert data.load(config["data"]) == control
