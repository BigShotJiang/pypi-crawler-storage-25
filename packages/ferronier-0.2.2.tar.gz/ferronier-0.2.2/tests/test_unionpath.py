# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Test du module unionpath"""

import pathlib

from ferronier import unionpath

DATADIR = pathlib.Path(__file__).parent / f"{pathlib.Path(__file__).stem}"


def path2dict(path: pathlib.Path | unionpath.UnionPath) -> dict[str, dict | str]:
    """Turn the path content into a dict.

    Keys are content (file and directory names).
    Values are:
        - for a file: None
        - for a directory: its content, as returned by `path2dict`.
    """
    content = {}
    for child in path.iterdir():
        if child.is_file():
            content[str(child.name)] = None
        elif child.is_dir():
            content[str(child.name)] = path2dict(child)
    return content


def test_unionpath() -> None:
    """Test le module :mod:`ferronier.unionpath`."""
    assert path2dict(
        unionpath.UnionPath(DATADIR / "a", DATADIR / "b", DATADIR / "c")
    ) == path2dict(DATADIR / "control")
