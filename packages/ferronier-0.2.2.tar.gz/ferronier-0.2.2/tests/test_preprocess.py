# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Test du pré-traitement des données"""

import contextlib
import pathlib
from typing import Any

import pytest

from ferronier import data

from . import datafiles

DATADIR = pathlib.Path(__file__).parent / f"{pathlib.Path(__file__).stem}"


@pytest.mark.parametrize(
    "filename, config, control", datafiles(DATADIR.glob("preprocess-*toml"))
)
def test_preprocess(filename: pathlib.Path | str, config: Any, control: Any):
    """Test les option de preprocess."""
    # pylint: disable=unused-argument
    with contextlib.chdir(DATADIR):
        assert (
            data.preprocess(
                data.load(config["data"]), conf=config.get("preprocess", {})
            )
            == control
        )
