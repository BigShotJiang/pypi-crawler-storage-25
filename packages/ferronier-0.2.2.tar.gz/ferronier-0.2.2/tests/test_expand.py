# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Test du module expand."""

from typing import Any

import pytest

from ferronier import expand

DATA1 = {1: {"foo": [1, 2]}, 2: {"foo": [1, 3], "bar": [0, 0]}, 3: {"foo": [2, 4]}}

DATA2 = {
    1: {"*": [1, 2], "a.b": ["a", "b"]},
    2: {"*": [1, 3], "a.b": ["b", "b"]},
    3: {"*": [2, 4], "a.b": ["a", "c"]},
}

DATA3 = [{"foo": [1, 2]}, {"foo": [1, 3]}, {"foo": [2, 4]}]

DATA4 = [
    ["a", "b", "c"],
    [1, 2, 3],
]

PARAMETRIZE = [
    # Dict of dicts
    ((DATA1, "*.foo.*"), [1, 2, 3, 4]),
    # List of dicts
    ((DATA3, "*.foo.*"), [1, 2, 3, 4]),
    # List of lists
    ((DATA4, [None, 1]), ["b", 2]),
    # Escape keys
    (
        (
            DATA2,
            "*.\\*.*",
        ),
        [1, 2, 3, 4],
    ),
    (
        (
            DATA2,
            "*.a\\.b.*",
        ),
        ["a", "b", "c"],
    ),
]


@pytest.mark.parametrize("args, control", PARAMETRIZE)
def test_expand(args: list, control: Any):
    """Tests de la fonction :func:`ferronier.expand.expand_values`."""
    assert set(expand.expand_values(*args)) == set(control)
