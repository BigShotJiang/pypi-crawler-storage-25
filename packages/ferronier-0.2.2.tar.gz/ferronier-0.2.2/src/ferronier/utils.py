# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Quelques outils."""

import functools
import os
import pathlib
from collections.abc import Callable
from typing import Any

from . import unionpath


def apply[T](postprocess: Callable[[Any], T]) -> Callable[[Callable], Callable]:
    """Returns a decorator that applies the `postprocess` argument to the return value.

    >>> @apply(str)
    ... def sum(a, b):
    ...     return a + b
    >>> sum(1, 2)
    '3'
    >>> @apply(list)
    ... def squares(n):
    ...     for i in range(n):
    ...         yield i**2
    >>> squares(5)
    [0, 1, 4, 9, 16]
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., T]:
        """Decorator that applies :func:`postprocess` to the return value of `func`."""

        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> T:
            return postprocess(func(*args, **kwargs))

        return wrapper

    return decorator


def sync(source: pathlib.Path | unionpath.UnionPath, dest: os.PathLike) -> None:
    """Recursively copy `source` into `dest.

    Recursively copy `source` into `dest`, replacing existing files, and
    leaving existing files and directories untouches.
    """
    for root, __, files in source.walk():
        (dest / (root.relative_to(source))).mkdir(parents=True, exist_ok=True)
        for file in files:
            (root / file).copy_into(dest / (root.relative_to(source)))
