# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Système de plugins"""

import argparse
import datetime
import gettext
import importlib.metadata
import json
import tomllib
from collections.abc import Callable
from typing import Any, Concatenate

import babel.support


class PluginDirector:  # pylint: disable=too-few-public-methods
    """Manage plugins: plugins register functions here, to be accessible to the main program."""

    def __init__(self):
        self.hook_source = {}
        self.hook_fileformat = {}
        self.hook_preprocess_global = {}
        self.hook_preprocess_local = {}
        self.hook_before_render = set()
        self.hook_after_render = set()
        self.hook_gettext = set()

    def load(self, conf: dict, args: None | argparse.Namespace = None) -> None:
        """Load plugins: Register functions of plugins declared in the configuration file."""
        if args is None:
            args = argparse.Namespace()
        for name in ["default"] + list(conf.get("plugins", {}).keys()):
            entrypoints = list(
                importlib.metadata.entry_points(group="ferronier.plugins", name=name)
            )
            if not entrypoints:
                raise ValueError(
                    f"Error: Could not load plugin '{name}'. Is it installed?"
                )
            for entrypoint in entrypoints:
                entrypoint.load()(self, conf, args)

    def register_source(self, name: str, function: Callable[[dict], Any]) -> None:
        """Register a function as a data source.

        :param name: Name of the source (to be declared by `data.source = NAME`
            in the configuration file).
        :param function: Function to be called to get data from this source.
        """
        if name in self.hook_source:
            raise ValueError(
                f"""Error: A source plugin has already been registered with name `{name}`."""
            )
        self.hook_source[name] = function

    def register_gettext(
        self,
        function: Callable[
            [tuple[str] | None], gettext.NullTranslations | babel.support.Translations
        ],
    ):
        """Register a function that search gettext translations."""
        self.hook_gettext.add(function)

    def register_preprocess_global[**P](
        self, name: str, function: Callable[Concatenate[dict | list, list, P], None]
    ) -> None:
        """Register a global preprocessor.

        Global preprocessor are functions that act on the data, and need to
        access the whole data (as opposed to `preprocess_local` functions).

        :param name: Name of the preprocessor (to be used in the configuration file).
        :param function: Function to be called to process data.
        """
        if name in self.hook_preprocess_global or name in self.hook_preprocess_local:
            raise ValueError(
                f"""Error: A preprocess plugin has already been registered with name `{name}`."""
            )
        self.hook_preprocess_global[name] = function

    def register_preprocess_local[**P](
        self, name: str, function: Callable[Concatenate[Any, P], Any]
    ) -> None:
        """Register a local preprocessor.

        Local preprocessor are functions that act on the data, but does not
        need access to the whole data (as opposed to `preprocess_global`
        functions).

        :param name: Name of the preprocessor (to be used in the configuration file).
        :param function: Function to be called to process data.
        """
        if name in self.hook_preprocess_global or name in self.hook_preprocess_local:
            raise ValueError(
                f"""Error: A preprocess plugin has already been registered with name `{name}`."""
            )
        self.hook_preprocess_local[name] = function

    def register_fileformat(self, name: str, function: Callable[[Any], Any]) -> None:
        """Register a file format.

        `local` and `remote` sources can process data as being json, toml, etc.
        data. This functions register a new file format.

        :param name: File format (used implicitely as the file or URL
            extension, or explicitely as `format = NAME` in the configuration
            file).
        :param function: Function to be called to process data.
        """
        if name in self.hook_fileformat:
            raise ValueError(
                f"""Error: A fileformat plugin has already been registered with name `{name}`."""
            )
        self.hook_fileformat[name] = function

    def register_before_render(self, function: Callable[[Any], None]) -> None:
        """Register a function called before pages are generated.

        :param function: Function to be called.
        """
        self.hook_before_render.add(function)

    def register_after_render(self, function: Callable[[Any], None]) -> None:
        """Register a function called after pages have been generated.

        :param function: Function to be called.
        """
        self.hook_after_render.add(function)


PLUGINS = PluginDirector()


def register(director: PluginDirector, conf: str, args: argparse.Namespace) -> None:
    """Register functions to be accessible from plugins."""
    # pylint: disable=import-outside-toplevel, unused-argument, cyclic-import
    # Packages imported here to prevent circular imports at loading time.
    from .data import fileformat, preprocessor
    from .data.source import dict as sourcedict
    from .data.source import local as sourcelocal
    from .data.source import merge as sourcemerge
    from .data.source import remote as sourceremote
    from .data.source import self as sourceself

    # Data sources
    director.register_source("dict", sourcedict.load)
    director.register_source("local", sourcelocal.load)
    director.register_source("merge", sourcemerge.load)
    director.register_source("remote", sourceremote.load)
    director.register_source("self", sourceself.load)

    # Preprocess
    director.register_preprocess_global("rename", preprocessor.rename)
    director.register_preprocess_local("datetime.date", datetime.date.strptime)
    director.register_preprocess_local("datetime.datetime", datetime.datetime.strptime)
    director.register_preprocess_local(
        "datetime.fromtimestamp", datetime.datetime.fromtimestamp
    )
    director.register_preprocess_local("datetime.time", datetime.time.strptime)
    director.register_preprocess_local("json.decode", json.loads)
    director.register_preprocess_local("json.encode", json.dumps)
    director.register_preprocess_local("toml", tomllib.loads)

    # File formats
    director.register_fileformat("csv", fileformat.load_csv)
    director.register_fileformat("json", json.loads)
    director.register_fileformat("toml", fileformat.load_toml)
