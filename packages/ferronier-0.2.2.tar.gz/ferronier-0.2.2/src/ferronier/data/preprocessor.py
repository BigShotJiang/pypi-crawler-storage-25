# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Several data preprocessors."""

import re

from ..expand import split

RE_FORMAT = re.compile(r"^{(\d+)}$")


def rename(
    data: list | dict,
    keys: list,
    *,
    args: list | None = None,
    kwargs: dict | None = None,
) -> None:
    """Move data around.

    E.g. move `data["foo"]["bar"]` to `data["baz"][3]`.
    """
    if args is None:
        args = []
    if len(args) != 1:
        raise ValueError(
            # pylint: disable=line-too-long
            "Exactly one argument is accepted to `rename` preprocess function: the destination path."
        )
    if kwargs:
        raise ValueError(
            "No named arguments are accepted to `rename` preprocess function."
        )
    dest = list(split(args[0]))
    source = keys

    # Replacing interpolated strings
    # That is, replace '{i}' by 'source[i]', and so on.
    for i, key in enumerate(list(dest)):
        try:
            dest[i] = source[int(RE_FORMAT.match(dest[i]).groups()[0])]  # type: ignore
        except AttributeError:
            pass

    # Setting data to the near destination item (so that data[dest[-1]] is the last item).
    root = data
    for key in dest[:-1]:
        if key not in data:
            data[key] = {}  # type: ignore
        data = data[key]  # type: ignore

    # Looking for the near source item
    for key in source[:-1]:
        root = root[key]
    data[dest[-1]] = root[source[-1]]  # type: ignore
    del root[source[-1]]
