# Copyright 2025-2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Charge différents formats de fichiers"""

import csv
import io
import tomllib
from typing import Any


def load_toml(data: bytes | str) -> Any:
    """Interprète l'argument comme une chaîne au format TOML."""
    if isinstance(data, bytes):
        return tomllib.loads(data.decode("utf8"))
    if isinstance(data, str):
        return tomllib.loads(data)
    raise TypeError(f"Unsupported type `{type(data)}`.")


def load_csv(data: bytes | str) -> list[dict]:
    """Interprète l'argument comme une chaîne au format CSV."""
    if isinstance(data, bytes):
        data = data.decode("utf8")
    return list(csv.DictReader(io.StringIO(data)))
