# Copyright 2025-2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Gestion des données dans le fichier de configuration : récupération et traitement."""

import dataclasses
import importlib.metadata
import logging
import re
from collections.abc import Callable
from typing import Any

from .. import expand
from ..plugins import PLUGINS

LOGGER = logging.getLogger("ferronier.data")
LOGGER.setLevel(logging.INFO)

RE_URL = re.compile(r"^\w*://")


def load(conf: str | dict) -> Any:
    """Charge les données définies dans le fichier de configuration.

    C'est la fonction principale, qui :
        - récupére les données en fonction de la source indiquée ;
        - effecture le prétraitement éventuel.

    La configuration dépend du format de données utilisée ;
    le type de la valeur de retour dépend des données chargées.

    :param conf: Configuration des données.
    :return: Les données.
    """
    # Get data
    if isinstance(conf, str):
        if RE_URL.match(conf):
            return PLUGINS.hook_source["remote"]({"url": conf})
        return PLUGINS.hook_source["local"]({"path": conf})
    if isinstance(conf, dict):
        LOGGER.info(f"""Getting data from source "{conf["source"]}".""")
        if "source" not in conf:
            raise ValueError("Expected a `data.source` value.")
        try:
            return PLUGINS.hook_source[conf["source"]](conf)
        except KeyError as error:
            raise ValueError(
                f"""No loader found for source {conf["source"]}."""
            ) from error
    raise TypeError(f"Wrong type for `data`: must be string or dict, not {type(conf)}.")


@dataclasses.dataclass
class Preprocessor:
    """Gère l'application d'un prétraitement aux données.

    :param functionname: Nom de la fonction à appliquer (définie dans un plugin).
    :param root: Donnees à traiter.
    :param args: Paramètres positionnels à passer à la fonction de traitement
        (définis dans le fichier de configuration).
    :param kwargs: Paramètres nommés à passer à la fonction de traitement
        (définis dans le fichier de configuration).
    """

    functionname: str
    root: Any
    _: dataclasses.KW_ONLY
    args: list = dataclasses.field(default_factory=list)
    kwargs: dict = dataclasses.field(default_factory=dict)

    def __call__(self, keys: list) -> Any:
        return self.process(keys, self.root)

    def process(self, keys: list, data: Any, *, prefix: list | None = None) -> None:
        """Applique le traitement aux données.

        :param keys: Chemin des clefs sur laquelle appliquer le traitement.
            Une clef valant `None` signifie : appliquer sur toutes les clefs.
        :param data: Les données sur lesquelles appliquer le traitement.
        :param prefix: Les clefs ayant mené à ces données.
            Utile pour savoir si les données données en argument sont
            l'ensemble des données, ou un sous-ensemble.
        """
        if prefix is None:
            prefix = []
        if data is None:
            data = self.root
        if keys[0] is None:
            if isinstance(data, list):
                for key in range(len(data)):
                    self.process([key] + keys[1:], data, prefix=prefix)
            elif isinstance(data, dict):
                for key in data:
                    self.process([key] + keys[1:], data, prefix=prefix)
        else:
            if len(keys) == 1:
                if self.functionname in PLUGINS.hook_preprocess_local:
                    data[keys[0]] = PLUGINS.hook_preprocess_local[self.functionname](
                        data[keys[0]], *self.args, **self.kwargs
                    )
                elif self.functionname in PLUGINS.hook_preprocess_global:
                    PLUGINS.hook_preprocess_global[self.functionname](
                        self.root, prefix + keys, args=self.args, kwargs=self.kwargs
                    )
                else:
                    raise ValueError(
                        # pylint: disable=line-too-long
                        f"""No preprocessor "{self.functionname}" found in groups "ferronier.preprocess-local" or "ferronier.preprocess-global"."""
                    )
            else:
                self.process(keys[1:], data[keys[0]], prefix=prefix + [keys[0]])


def preprocess(data: Any, conf: dict | list) -> Any:
    """Applique le traitement des données définies dans le fichier de configuration.

    :param data: Les données définies dans le fichier de configuration.
    :param conf: La section `preprocess` du fichier de configuration.
    :return: Les données, traitées.
    """
    if isinstance(conf, dict):
        for keys, function in conf.items():
            if isinstance(function, str):
                name = function
                args = []
            elif isinstance(function, list):
                name, *args = function
            else:
                raise TypeError(f"Invalid type {type(function)} for function.")
            Preprocessor(name, data, args=args)(
                list(expand.escape_star(expand.split(keys)))
            )
        return data
    if isinstance(conf, list):
        for step in conf:
            Preprocessor(
                step["function"],
                data,
                args=step.get("args", []),
                kwargs=step.get("kwargs", {}),
            )(list(expand.escape_star(step["keys"])))
        return data
    raise TypeError(f"Invalid type {type(conf)} for argument `conf`.")
