# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Merge data from multiple sources"""

import itertools
from collections.abc import Mapping, Sequence

from ...data import load as parent_load


def load(conf: dict) -> dict | list:
    """Merge data from multiple sources"""
    data = [parent_load(value) for value in conf.get("data", {})]
    if all(isinstance(item, Sequence) for item in data):
        return list(itertools.chain(*data))
    if all(isinstance(item, Mapping) for item in data):
        merged = {}
        for item in reversed(data):  # First item has precedence
            merged |= item
        return merged
    raise TypeError("All types of `merge` data must be lists or dicts.")
