# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Load data from the configuration file itself."""

from typing import Any


def load(conf: dict) -> Any:
    """Load data from the configuration file itself."""
    try:
        return conf["data"]
    except KeyError as error:
        raise ValueError(  # pylint: disable=line-too-long
            "Élément `data.data` manquant dans le fichier de configuration, obligatoire pour des données de type `self`."
        ) from error
