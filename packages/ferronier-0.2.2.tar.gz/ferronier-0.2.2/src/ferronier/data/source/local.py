# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Load data from local filesystem."""

from typing import Any

from ...plugins import PLUGINS


def formatdata(data: Any, fileformat: str | None, path: str) -> Any:
    """Interpret data with a given format.

    :param data: The data to parse.
    :param fileformat: The file format (or None, if unknown).
    :param path: The data path (file path or url). Used to guess file format,
        if not explicitely defined.
    """
    if fileformat is None and "." in path:
        # Format is implicitely defined
        fileformat = path.rsplit(".", maxsplit=1)[1]
        if fileformat not in PLUGINS.hook_fileformat:
            # No plugin defined to process the guessed file format.
            # Back to no processing
            fileformat = None

    if fileformat:
        try:
            return PLUGINS.hook_fileformat[fileformat](data)
        except KeyError as error:
            raise ValueError(
                f"""No processor found for file format `{fileformat}`."""
            ) from error

    # No format defined: do not preprocess data
    return data


def load(conf: dict) -> Any:
    """Load data from local filesystem."""
    if isinstance(conf, dict):
        try:
            source = conf["path"]
        except KeyError as error:
            raise ValueError("Expected a `data.path` value.") from error
    else:
        raise TypeError(f"Unsupported type `{type(conf)}`.")

    with open(source, mode="rb") as file:
        return formatdata(
            file.read(),
            fileformat=conf.get("format", None),
            path=conf["path"],
        )
