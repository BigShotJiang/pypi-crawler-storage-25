# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Load data from a remote server.

Data is cached, so it is not downloaded again each time."""

import hashlib
import logging
import pathlib
from typing import Any

import requests

from .local import formatdata

LOGGER = logging.getLogger("ferronier.data.remote")


def cachedir() -> pathlib.Path:
    "Return the path of the cache directory (which might not exist)"
    return pathlib.Path.cwd() / ".cache"


def load(conf: dict) -> Any:
    """Load data from a remote server."""
    cachename = cachedir() / hashlib.md5(conf["url"].encode()).hexdigest()
    if cachename.exists():
        LOGGER.warning(
            # pylint: disable=line-too-long
            f"Le fichier {cachename} existe déjà : les données ne sont pas re-téléchargées. Supprimez ce fichier pour forcer le téléchargement."
        )
        with open(cachename, mode="rb") as file:
            return formatdata(
                file.read(), fileformat=conf.get("format", None), path=conf["url"]
            )

    response = requests.get(conf["url"], timeout=60)
    response.raise_for_status()
    data = response.content
    cachename.parent.mkdir(exist_ok=True, parents=True)
    with open(cachename, mode="wb") as file:
        file.write(data)
        return formatdata(data, fileformat=conf.get("format", None), path=conf["url"])
