# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Handle recursive __getitem__.

For instance, given a list `keys`, provide functions to return or iterate, over
`data[keys[0]][keys[1]][…]`.

`None` keys are interpreted as wildcard, and every possible combination is then yielded.
"""

import enum
import logging
from collections.abc import Iterable, Iterator, Mapping, Sequence
from typing import Any

logging.basicConfig()
LOGGER = logging.getLogger("ferronier")
LOGGER.setLevel(logging.INFO)


class KeysError(Exception):
    """Raised when keys cannot be expanded in some data."""


def split(text: str) -> Iterator[str]:
    """Split text using "." as a delimiter, which may be escaped by and antislash.

    >>> list(split("a.b.c"))
    ['a', 'b', 'c']
    >>> list(split(r"a.b\\.c"))
    ['a', 'b.c']
    >>> list(split(r"a.b\\\\.c"))
    ['a', 'b\\\\', 'c']
    >>> list(split(r'a.b\\\\.c'))
    ['a', 'b\\\\', 'c']
    >>> list(split(""))
    []
    """
    iterator = iter(text)
    word = ""
    while True:
        try:
            token = next(iterator)
        except StopIteration:
            if word:
                yield word
            return
        if token == ".":
            yield word
            word = ""
            continue
        if token == "\\":
            try:
                token += next(iterator)
            except StopIteration as error:
                raise ValueError(
                    "Cannot have a `\\\\` at the last character of the string."
                ) from error
            if token[1] in "\\.":
                token = token[1]

        word += token


def escape_star(keys: Iterable[str]) -> Iterator[str | None]:
    """Non-escaped stars in `keys` are converted to `None`.

    >> escape_star([42, "toto", "*", "\\*"])
    [42, 'toto', None, '\\*']
    """
    for item in keys:
        if item == "*":
            yield None
        elif item == "\\*":
            yield "*"
        else:
            yield item


class ONKEYERROR(enum.Enum):
    """What to do with missing keys."""

    RAISE = enum.auto()
    WARN = enum.auto()
    IGNORE = enum.auto()
    DEFAULT = enum.auto()


def expand_items(
    data: Sequence | Mapping,
    keys: Iterable | str,
    *,
    onkeyerror: ONKEYERROR = ONKEYERROR.WARN,
    default: Any = None,
) -> Iterator[tuple[list, Any]]:
    """Iterate over `(key, value)` of `data[keys[0]][keys[1]][…]`.

    :param keys: List of keys. Any `None` item is considered as a wildcard,
        and every available keys are expanded. See :func:`expand_items` for an example.
    :param data: List or dict of list or dict of … of any type.
    :param onkeyerror: What to do if keys do not exist (or (sub)data is not subscriptable):
        - `ONKEYERROR.WARN`: log a warning, and continue;
        - `ONKEYERROR.RAISE`: raise a :class:`KeysError`;
        - `ONKEYERROR.IGNORE`: ignore (sub)data, and continue;
        - `ONKEYERROR.DEFAULT`: return the default value (argument `default`).

    For instance, let data be:

    .. code-block:: python

       data = {
         "foo": [
            "one",
            "two",
            "three",
            ],
         "bar": [
            "a",
            "b",
            ],
        }

    Then, in `expand_items(data, [None, 1])`, `None` is a wildcard for any key
    in the first dict, so this calls yields: `["two", "b"]`.
    """
    # pylint: disable = too-many-branches
    if isinstance(keys, str):
        keys = list(escape_star(split(keys)))
    else:
        keys = list(keys)
    if not keys:
        yield ([], data)
        return

    if keys[0] is None:
        # Wildcard key: iterate over every single instance
        if isinstance(data, Sequence):
            # Data is a list: keys are integers.
            for i, item in enumerate(data):
                for expanded_keys, expanded_values in expand_items(
                    item, keys[1:], onkeyerror=onkeyerror
                ):
                    yield (
                        [i] + expanded_keys,
                        expanded_values,
                    )
        elif isinstance(data, Mapping):
            # Data is a dict: keys are `dict.keys()`
            for key, item in data.items():
                for expanded_keys, expanded_values in expand_items(
                    item, keys[1:], onkeyerror=onkeyerror
                ):
                    yield (
                        [key] + expanded_keys,
                        expanded_values,
                    )
        else:
            # Other types are not handled.
            raise TypeError(f"Invalid type {type(data)} for data `{data}`.")
    else:
        # No wildcard: iterate over a single key.
        try:
            # Trigger an error if data is not subscriptable, or key is unknown.
            data[keys[0]]  # type: ignore
        except TypeError, KeyError:
            if onkeyerror == ONKEYERROR.WARN:
                if isinstance(data, Mapping):
                    choices = [f'"{key}"' for key in data.keys()]
                elif isinstance(data, Sequence):
                    choices = [str(i) for i in range(len(data))]
                else:
                    choices = None
                if choices is None:
                    # pylint: disable=line-too-long
                    LOGGER.warning(
                        f"No such key `{keys[0]}`: `{data}` (of type `{type(data)}`) is not subscriptable. Path ignored."
                    )
                else:
                    # pylint: disable=line-too-long
                    LOGGER.warning(
                        f"""No such key `{keys[0]}`: possible choices are {", ".join(choices)}. Path ignored."""
                    )
                return
            if onkeyerror == ONKEYERROR.IGNORE:
                return
            if onkeyerror == ONKEYERROR.RAISE:
                raise
            if onkeyerror == ONKEYERROR.DEFAULT:
                yield from default
                return
        for expanded_keys, expanded_value in expand_items(
            data[keys[0]], keys[1:], onkeyerror=onkeyerror  # type: ignore
        ):
            yield (
                [keys[0]] + expanded_keys,
                expanded_value,
            )


def expand_values(
    data: Sequence | Mapping,
    keys: str | Sequence,
    *,
    onkeyerror: ONKEYERROR = ONKEYERROR.WARN,
    default: Any = None,
) -> Any:
    """Iterate over values `data[keys[0]][keys[1]][…]`.

    Parameters have the same meaning as :func:`expand_items`.

    Any `None` key is considered a wildcard and every available keys are expanded.
    See :func:`expand_items` for an example.
    """
    for _, value in expand_items(data, keys, onkeyerror=onkeyerror, default=default):
        yield value


def expand_keys(
    data: Sequence | Mapping,
    keys: str | Sequence,
    *,
    onkeyerror: ONKEYERROR = ONKEYERROR.WARN,
    default: Any = None,
) -> Iterable:
    """Iterate over `keys` as (sub)keys of `data`.

    Parameters have the same meaning as :func:`expand_items`.

    Any `None` key is considered a wildcard and every available keys are expanded.
    See :func:`expand_items` for an example.
    """
    for subkeys, _ in expand_items(data, keys, onkeyerror=onkeyerror, default=default):
        yield subkeys


def contains(data: Mapping | Sequence, keys: str | Sequence | Mapping) -> bool:
    """Returns true if data[keys[0]][keys[1]]… exists"""
    if isinstance(keys, str):
        return contains(data, list(split(keys)))
    if keys:
        if keys[0] in data:
            return contains(data[keys[0]], keys[1:])
        return False
    return True


def getitem(
    data: Mapping | Sequence,
    keys: str | Sequence | Mapping,
    *,
    onkeyerror: ONKEYERROR = ONKEYERROR.RAISE,
    default: Any = None,
) -> Any:
    """Return data[keys[0]][keys[1]]…

    >>> getitem({"a": [None, {"b": 1729}]}, ("a", 1, "b"))
    1729
    >>> getitem({"a": [None, {"b": 1729}]}, ("a", 1, "a"), onkeyerror=ONKEYERROR.DEFAULT, default=0)
    0
    """
    if isinstance(keys, str):
        return getitem(data, list(split(keys)), onkeyerror=onkeyerror, default=default)
    if keys:
        try:
            return getitem(data[keys[0]], keys[1:])
        except KeyError as error:
            if onkeyerror == ONKEYERROR.DEFAULT:
                return default
            if onkeyerror == ONKEYERROR.RAISE:
                raise
            raise NotImplementedError() from error
    return data
