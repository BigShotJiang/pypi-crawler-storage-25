# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Default, boring, theme.

There are two ways to customize it.

1. (Easy) Define the following variables in your `ferronier.toml` file:

    - `head`: Content of HTML `<head>` block.
    - `nav`: Content of HTML `<nav>` block (navigation bar, for instance).
    - `header`: Content of HTML `<header>` block.
    - `main`: Content of HTML `<main>` block.
    - `footer`: Content of HTML `<footer>` block.

2. (A bit more work) Create and use a [child jinja2
    template](https://jinja.palletsprojects.com/en/stable/templates/#base-template),
    where you can rededine the blocks `head`, `nav`, `header`, `main`, `footer`
    (same meaning as above).
"""
