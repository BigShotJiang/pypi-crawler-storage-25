# Copyright 2025-2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Construit une page web à partir d'un extrait de la cartographie de la Forge."""

import importlib.metadata
import importlib.resources
import pathlib
from collections.abc import Callable, Iterable, Iterator, Reversible
from types import ModuleType
from typing import Any

import jinja2

from ..unionpath import UnionPath
from ..utils import apply


def load(theme: str) -> ModuleType:
    """Load theme

    :param theme: Name of the theme, as a key in the `ferronier.themes`
        entrypoints group in the `pyproject.toml` file.
    :return: The module corresponding to the theme.
    """
    for entrypoint in importlib.metadata.entry_points(
        group="ferronier.themes", name=theme
    ):
        loaded = entrypoint.load()
        if isinstance(loaded, ModuleType):
            return loaded
        raise TypeError(f"Theme entrypoints must be modules (not {type(loaded)}).")
    raise ValueError(f"No theme entrypoint named `{theme}`.")


class Theme:
    """An HTML theme: static files, pages, and so on."""

    def __init__(self, name: str | None, *, confdir: pathlib.Path):
        self._roots: list[pathlib.Path | ModuleType] = [confdir]

        if name is None:
            return

        # Only the first theme can be a directory. The other ones are modules
        if name.startswith("/"):
            self._roots.append(pathlib.Path(name))
        elif name.startswith("./"):
            self._roots.append(confdir / name)
        else:
            while True:
                if isinstance(name, str):
                    self._roots.append(load(name))
                    try:
                        name = getattr(self._roots[-1], "EXTENDS")
                    except AttributeError:
                        break
                else:
                    raise TypeError(
                        # pylint: disable=line-too-long
                        f"Extended theme names must be strings: value `{name}` (of type `{type(name)}`), from module {self._roots[-1]}, is not.)"
                    )

    def __iter__(self) -> Iterator[pathlib.Path | ModuleType]:
        yield from self._roots

    def __reversed__(self) -> Iterator[pathlib.Path | ModuleType]:
        yield from reversed(self._roots)

    def __truediv__(self, other: str | pathlib.Path) -> UnionPath:
        paths = []
        for root in self:
            if isinstance(root, ModuleType):
                paths.append(importlib.resources.files(root))
            elif isinstance(root, pathlib.Path):
                paths.append(root)
        return UnionPath(*(path / other for path in paths if (path / other).exists()))

    @apply(list)
    def loaders(self) -> Iterable[jinja2.BaseLoader]:
        """Returns a list of :class:`jinja2.BaseLoader` loaders."""
        for root in self:
            if isinstance(root, ModuleType):
                try:
                    yield jinja2.PackageLoader(root.__name__, "templates")
                except ValueError:
                    # Le paquet n'a pas de sous-dossier `templates`. On l'ignore.
                    pass
            elif isinstance(root, pathlib.Path):
                if (root / "templates").exists():
                    yield jinja2.FileSystemLoader((root / "templates").absolute())
