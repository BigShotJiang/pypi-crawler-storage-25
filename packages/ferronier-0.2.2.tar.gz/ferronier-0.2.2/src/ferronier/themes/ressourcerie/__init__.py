# Copyright 2025-2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Produit une page présentant des ressources à partir de l'API de la ressourcerie.

Voir par exemple les ressources [en lien avec le
[Markdown](https://ressourcerie.forge.apps.education.fr/api/v2/classements/Tags_libres/Markdown.json).
"""  # pylint: disable=line-too-long
