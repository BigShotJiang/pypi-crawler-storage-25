async function fetchFile(url) {
    // Fetch the content of the file.
    const response = await(fetch(url));
    if (!response.ok) {
        return "<p>Erreur lors du téléchargement de la description longue…";
    } else {
        return await response.text();
    }
}

// TOOLTIPS et MODAL
document.addEventListener('DOMContentLoaded', function () {
  // Détection d’un device tactile
  const isTouchDevice = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;

  // Ne créer les tooltips que si on n’est PAS sur mobile/tactile
  if (!isTouchDevice) {
    const tooltipTriggerList = [].slice.call(
      document.querySelectorAll('[data-bs-toggle="tooltip"]')
    );
    tooltipTriggerList.forEach(el => {
      new bootstrap.Tooltip(el, { trigger: 'hover' });
    });
  }

  // Gestion des modales des descriptions de chaque fiche
  const modal = document.getElementById('modalDescription');
  const bodyEl = modal.querySelector('.modal-body');
  modal.addEventListener('show.bs.modal', async function (event) {
    const btn = event.relatedTarget;
    bodyEl.innerHTML = "<p>Chargement…</p>"
    bodyEl.innerHTML = await fetchFile(btn.getAttribute('data-description'));
  });
});
