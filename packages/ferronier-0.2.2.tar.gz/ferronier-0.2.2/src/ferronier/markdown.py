# Copyright 2025-2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Fournit un filtre markdown pour jinja"""

import pathlib
from collections.abc import Callable

import mistune


def link_absolute2relative(source: str, href: str) -> str:
    """Transforme un lien absolu en lien relatif.

    :param source: Page (ou fichier markdown) à partir de laquelle le lien est considéré.
    :param href: Lien, qui est supposé absolu.

    >>> link_absolute2relative("/foo/bar/index.html", "/baz")
    '../../../baz'
    >>> link_absolute2relative("foo/index.html", "/bar")
    '../bar'
    >>> link_absolute2relative("foo/bar/index.html", "/baz")
    '../../baz'
    >>> link_absolute2relative("/foo/bar/index.html", "/foo/baz")
    '../../../foo/baz'
    """
    if href == "/" and source.count("/") == 0:
        # Going to root from a file in the root directory
        return "."
    if href == "/":
        # Going back to root
        return "/".join([".."] * (source.count("/")))
    if source.count("/") == 0:
        # Going somewhere from root
        return href.lstrip("/")
    # Going back to root, then to href
    return "/".join([".."] * (source.count("/"))) + href


class _HTMLRenderer(mistune.HTMLRenderer):
    """Renderer HTML qui transforme les liens absolus en relatifs."""

    def __init__(self, *args, **kwargs):
        self._source = kwargs.pop("source")
        super().__init__(*args, **kwargs)

    def link(self, text: str, url: str, title: str | None = None) -> str:
        if url.startswith("/"):
            return super().link(
                text, url=link_absolute2relative(self._source, url), title=title
            )
        return super().link(text, url, title)


def markdown(source: pathlib.Path | str) -> Callable[[str], str]:
    """Renvoit un filtre jinja2 qui transforme du texte en markdown"""
    _renderer = mistune.create_markdown(renderer=_HTMLRenderer(source=str(source)))

    def renderer(value: str) -> str:
        """Interprète l'argument comme du markdown, et renvoit le HTML correspondant."""
        return _renderer(value)  # type: ignore

    return renderer
