# Copyright 2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Une objet ressemblant à pathlib.Path qui va piocher ses fichiers dans plusieurs dossiers."""

import collections
import os
import pathlib
from collections.abc import Iterable


class UnionPath(os.PathLike):
    """Un chemin, qui est l'union de plusieurs chemins.

    Par exemple, l'énumération du contenu de cet objet liste l'ensemble des
    contenus des chemins en argument. En cas de conflit (le même sous-chemin
    dans différents chemins), le premier chemin est prioritaire.

    :param roots: Liste des chemins dans lesquels rechercher.
    """

    def __init__(self, /, *roots: str | pathlib.Path):
        if roots:
            self.roots = [pathlib.Path(item) for item in roots]
        else:
            self.roots = [pathlib.Path()]

    def __fspath__(self) -> str:
        """Renvoit la chaîne du premier chemin.

        Utile pour que cet objet puisse être interprété comme un chemin, par
        `open()` par exemple.
        """
        return str(self.roots[0])

    def iterdir(self) -> Iterable[UnionPath]:
        """Itère l'ensemble du contenu du chemin en cours.

        Même comportement que :meth:`pathlib.Path.iterdir`.
        """
        union = collections.defaultdict(list)
        for root in self.roots:
            for child in root.iterdir():
                if child not in union[child.name]:
                    union[child.name].append(child)
        for paths in union.values():
            yield self.__class__(*paths)

    def walk(self, *args, **kwargs) -> Iterable[tuple[UnionPath, list[str], list[str]]]:
        """Parcours l'arbre, en renvoyant des triplets `(dirpath, dirnames, filenames)`.

        Même comportement que :meth:`pathlib.Path.walk`.
        Les arguments `args` et `kwargs` sont passés directement à :meth:`pathlib.Path.walk`.
        """
        union = collections.defaultdict(lambda: collections.defaultdict(set))
        for root in self.roots:
            for dirpath, dirnames, filenames in root.walk(*args, **kwargs):
                union[dirpath.relative_to(root)]["dirnames"].update(dirnames)
                union[dirpath.relative_to(root)]["filenames"].update(filenames)
        for path, children in union.items():
            yield (
                self.__class__(*(root / path for root in self.roots)),
                list(children["dirnames"]),
                list(children["filenames"]),
            )

    def __str__(self) -> str:
        return str(self.roots[0])

    def __truediv__(self, other: str | pathlib.Path) -> UnionPath:
        return self.__class__(
            *(root / other for root in self.roots if (root / other).exists())
        )

    def relative_to(self, other: UnionPath | str | pathlib.Path) -> pathlib.Path:
        """Renvoit le chemin de l'objet courant, relatif à l'argument."""
        if isinstance(other, UnionPath):
            for path in other.roots:
                try:
                    return self.relative_to(path)
                except ValueError:
                    pass
        else:
            for root in self.roots:
                try:
                    return root.relative_to(other)
                except ValueError:
                    pass
        raise ValueError(
            # pylint: disable=line-too-long
            f"""'{self}' is not in the subpath of '{other}' OR one path is relative and the other is absolute."""
        )

    def is_file(self) -> bool:
        """Renvoit `True` si cet objet représente un fichier."""
        return self.roots[0].is_file()

    def is_dir(self) -> bool:
        """Renvoit `True` si cet objet représente un dossier."""
        return self.roots[0].is_dir()

    @property
    def name(self) -> str:
        """Renvoit le nom du chemin courant (le dernier élément)."""
        return self.roots[0].name

    def copy_into(self, target_dir: pathlib.Path) -> pathlib.Path:
        """Copie l'arbre source dans dans `target_dir`.

        La source est au format :class:`UnionPath`, et l'ensemble des fichiers concernés est copié.
        """
        if self.is_dir():
            (target_dir / self.name).mkdir(exist_ok=True)
            for path in self.iterdir():
                path.copy_into(target_dir / self.name)
        elif self.is_file():
            pathlib.Path(self).copy_into(target_dir)
        else:
            raise TypeError(
                f"""Chemin {self} ignoré : ce n'est ni un fichier ni un répertoire."""
            )
        return target_dir / self.name
