# Copyright 2025-2026 Louis Paternault
#
# This is free software: you can redistribute it and/or modify
# it under the terms of the GNU Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Public License for more details.
#
# You should have received a copy of the GNU Public License
# along with this.  If not, see <http://www.gnu.org/licenses/>.

"""Construit une page web à partir d'un extrait de la cartographie de la Forge."""

import argparse
import contextlib
import datetime
import functools
import gettext
import locale
import logging
import pathlib
import re
import textwrap
import tomllib
from collections.abc import Iterable

import babel
import babel.support
import jinja2
import slugify

from . import __version__, data, themes
from .expand import ONKEYERROR, expand_items, expand_values
from .markdown import link_absolute2relative, markdown
from .plugins import PLUGINS
from .utils import sync

logging.basicConfig()
LOGGER = logging.getLogger("ferronier")
LOGGER.setLevel(logging.INFO)

RE_BRACKETS = re.compile(r"^([^{}]*){([^{}]+)}([^{}]*)$")

# Toutes ces valeurs peuvent être surchargées dans le fichier de configuration donné en argument
DEFAULT_CONF = {
    "plugins": {},
    "theme": "default",
}


def analyse_ligne_de_commande() -> argparse.Namespace:
    """Analyse la ligne de commande, et renvoit les options lues."""
    parser = argparse.ArgumentParser(
        prog="ferronier",
        # pylint: disable=line-too-long
        description="Un générateur de sites web statiques opérant à partir de données (au format json par exemple) plutôt qu'à partir de fichiers.",
    )
    parser.add_argument(
        "--version", action="version", version=f"ferronier {__version__}"
    )
    parser.add_argument(
        "DIR",
        help="Fichier de configuration, au format toml.",
        type=pathlib.Path,
    )
    parser.add_argument(
        "DEST", help="Dossier de destination", default="public", type=pathlib.Path
    )
    parser.add_argument(
        "--debug",
        help=textwrap.dedent("""\
                    Affiche des informations de debuggage. Valeurs possibles :
                    - none : aucune information ;
                    - dump : affiche les données une fois pré-traitées ;
                    - pdb : comme `dump`, puis ouvre une console python.

                    Cette commande est expérimentale, utilisée pour le développement de ce logiciel, et son comportement peut changer sans prévenir.
                    """),
        nargs="?",
        choices=["none", "pdb", "dump"],
        default="none",
    )
    return parser.parse_args()


def maybefile(texte: str, *, cwd: pathlib.Path | None = None) -> str:
    """Renvoit la chaîne, ou le contenu du fichier décrit.

    - Si le texte commence par `file:`, alors la suite est interprétée comme un
      nom de fichier, qui est ouvert, et le contenu du fichier est renvoyé.
    - Sinon, le texte lui-même est renvoyé.

    :param texte: Texte, renvoyé tel quel s'il ne commence pas par `file:`, et
        interprété comme un nom de fichier, dont le contenu est renvoyé, sinon.
    :param cwd: Si non `None`, chemin à partir duquel doit être interprété le
        nom de fichier décrit par `texte`.
    """
    if texte.startswith("file:"):
        filename = texte[len("file:") :]
        if cwd is not None:
            filename = cwd / filename
        with open(filename, encoding="utf8") as file:
            return file.read()
    return texte


def localesort(
    iterable: Iterable[str], attribute: str | int | None = None, reverse: bool = False
) -> Iterable[str]:
    """Sort data, according to the current locale."""
    if attribute is None:
        key = locale.strxfrm
    else:
        key = lambda x: locale.strxfrm(  # pylint: disable=unnecessary-lambda-assignment
            x[attribute]
        )
    return sorted(iterable, key=key, reverse=reverse)


def main() -> None:
    """Fonction principale."""
    # pylint: disable=too-many-locals, too-many-branches, too-many-statements
    # Je pense que cette fonction, bien que longue, est bien documentée (grâce aux log).
    # Si ce n'est pas le cas, il faudra la découper en sous-fonctions.
    LOGGER.info("Analyse des arguments de la ligne de commande.")
    options = analyse_ligne_de_commande()

    LOGGER.info("Lecture du fichier de configuration")
    with open(options.DIR, mode="rb") as configfile:
        conf: dict = DEFAULT_CONF | tomllib.load(configfile)

    LOGGER.info("Chargement des plugins")
    PLUGINS.load(conf, options)

    LOGGER.info("Vérification des répertoires")
    try:
        options.DEST.mkdir(exist_ok=True)
    except OSError as error:
        raise RuntimeError(
            f"Erreur: Impossible de créer le répertoire {options.DEST} : {error}"
        ) from error

    LOGGER.info("Génération des données exportées")
    if not isinstance(conf.get("export", {}), dict):
        raise TypeError(
            # pylint: disable=line-too-long
            f"""La donnée `export` doit être de type dictionnaire (actuellement {type(conf["export"])})."""
        )
    exported = conf.get("export", {})
    exported["_conf"] = conf
    # Redundant (because it can be accessed by `exported["_conf"]["plugins"]`) but convenient
    exported["_plugins"] = conf.get("plugins", {})
    exported["_meta"] = {
        "now": datetime.datetime.now(),
        "version": __version__,
    }

    confdir = options.DIR.parent
    with contextlib.chdir(confdir):
        LOGGER.info("Téléchargement des données")
        exported["data"] = data.preprocess(
            data.load(conf["data"]), conf=conf.get("preprocess", {})
        )
        if options.debug == "dump" or options.debug is None:
            # pylint: disable=import-outside-toplevel
            import pprint

            pprint.pprint(exported)
        elif options.debug == "pdb":
            try:
                # pylint: disable=import-outside-toplevel, forgotten-debug-statement
                import pprint

                import ipdb

                pprint.pprint(exported)
                ipdb.set_trace()
            except ImportError:
                LOGGER.info(
                    "Install `ipdb` and re-run this command to have a nicer debugger."
                )
                breakpoint()

    LOGGER.info("Chargement du thème")
    theme: themes.Theme = themes.Theme(conf["theme"], confdir=pathlib.Path(confdir))

    LOGGER.info("Copie des fichiers statiques des thèmes")
    sync(theme / "static", options.DEST)

    LOGGER.info("Chargement des modèles")
    # Définition de la locale
    conf["locale"] = babel.Locale.parse(conf.get("locale", babel.Locale.default()))
    try:
        locale.setlocale(locale.LC_ALL, str(conf["locale"]))
    except locale.Error as error:
        LOGGER.warning(
            f"""Ignoring wrong or badly configured locale {conf["locale"]}: {error}."""
        )
    env = jinja2.Environment(
        loader=jinja2.ChoiceLoader(theme.loaders()),
        extensions=["jinja2.ext.i18n"],
    )
    env.install_gettext_callables(  # pylint: disable=no-member # type: ignore
        gettext=gettext.gettext, ngettext=gettext.ngettext, newstyle=True
    )
    for function in PLUGINS.hook_gettext:
        # pylint: disable=no-member
        env.install_gettext_translations(function((conf["locale"].language,)))  # type: ignore
    env.filters |= {
        "expandvalues": functools.partial(expand_values, onkeyerror=ONKEYERROR.DEFAULT),
        "localesort": localesort,
        "maybefile": functools.partial(maybefile, cwd=confdir),
        "slugify": slugify.slugify,
    }
    fmt = babel.support.Format(conf["locale"])
    env.filters |= {
        f"format.{ name }": getattr(fmt, name)
        for name in dir(fmt)
        if not name.startswith("_")
    }

    LOGGER.info("Pré-traitement")
    for function in PLUGINS.hook_before_render:
        function(exported["data"])

    LOGGER.info("Génération des pages")
    for sourcepath, _, filenames in (theme / "content").walk():
        for sourcename in filenames:
            destpath = options.DEST / sourcepath.relative_to(theme / "content")
            destpath.mkdir(exist_ok=True, parents=True)
            env.filters |= {
                "markdown": markdown(
                    str((sourcepath / sourcename).relative_to(theme / "content"))
                ),
                "url": functools.partial(
                    link_absolute2relative,
                    str((sourcepath / sourcename).relative_to(theme / "content")),
                ),
            }
            if "{" in sourcename or "}" in sourcename:
                if match := RE_BRACKETS.match(sourcename):
                    prefix, center, suffix = match.groups()
                    destnames = [
                        (f"{prefix}{expanded}{suffix}", keys)
                        for keys, expanded in expand_items(
                            exported["data"],
                            center,
                            onkeyerror=ONKEYERROR.WARN,
                        )
                    ]
                else:
                    raise ValueError(
                        # pylint: disable=line-too-long
                        f"Exactly one pair of brackets is accepted in filename of the `content` directory. File `{sourcepath/sourcename}` violates this rule."
                    )
            else:
                destnames = [(sourcename, [])]
            for destname, keys in destnames:
                with (
                    open(sourcepath / sourcename, encoding="utf8") as source,
                    open(destpath / destname, encoding="utf8", mode="w") as dest,
                ):
                    dest.write(
                        env.from_string(source.read()).render(
                            **(exported | {"_keys": keys})
                        )
                    )

    LOGGER.info("Post-traitement")
    for function in PLUGINS.hook_after_render:
        function(exported["data"])


if __name__ == "__main__":
    main()
