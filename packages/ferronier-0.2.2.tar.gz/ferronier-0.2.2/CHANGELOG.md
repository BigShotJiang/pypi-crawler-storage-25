# Ferronier

## Ferronier 0.2.2 (2026-04-29)

* Fix (?) publish process.

## Ferronier 0.2.1 (2026-04-29)

* Themes:

  * `portail`: Modal did not display the long description.
  * `default`: Add a default theme.

## Ferronier 0.2.0 (2026-04-17)

* Add support for translated templates.
* Minor internal improvements.

## Ferronier 0.1.0 (2026-04-14)

* First published version
