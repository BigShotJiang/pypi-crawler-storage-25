`ferronier` — Générateur de site web statique à partir de données (JSON, TOML, YAML…)
=====================================================================================

> **Ferronnier / Ferronnière d'art** : Spécialiste du fer forgé, le ferronnier d'art aménage intérieur (luminaires, tables...) et extérieur (rampes d'escaliers, grilles, **portails**...). Créateur, il dessine et innove constamment pour s'adapter à tous les styles d'architecture.
>
> *Source : [ONISEP](https://www.onisep.fr/ressources/univers-metier/metiers/ferronnier-ferronniere-d-art)*
