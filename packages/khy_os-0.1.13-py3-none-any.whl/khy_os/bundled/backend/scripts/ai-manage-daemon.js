#!/usr/bin/env node

/**
 * Detached runner for AI management stack.
 * - Starts AI management backend server
 * - Optionally starts ai-frontend dev server on an available port
 * - Exposes a tiny control API for page lifecycle heartbeat
 * - Auto-shuts down on idle to release occupied ports
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const net = require('net');
const crypto = require('crypto');
const { spawn } = require('child_process');
const aiManagementServer = require('../src/services/aiManagementServer');
const { getDataHome, getLegacyDataHome } = require('../src/utils/dataHome');

const KHY_DIR = getDataHome();
const RUNTIME_FILE = path.join(KHY_DIR, 'ai_manage_runtime.json');
const LEGACY_RUNTIME_FILE = path.join(getLegacyDataHome(), 'ai_manage_runtime.json');
const LOG_DIR = path.join(KHY_DIR, 'logs');

const DEFAULT_API_PORT = 9090;
const DEFAULT_FRONTEND_PORT = 8090;
const DEFAULT_IDLE_MS = 10 * 60_000;
const DEFAULT_SESSION_TTL_MS = 35_000;
const DEFAULT_STARTUP_GRACE_MS = 10 * 60_000;
const DEFAULT_FRONTEND_WAIT_MS = 90_000;
const DEFAULT_FRONTEND_ENTRY_PATH = '/admin/ai-gateway';
const DEFAULT_AUTH_BOOTSTRAP_TTL_MS = 30 * 60_000;

let controlServer = null;
let controlPort = 0;
const controlToken = crypto.randomBytes(18).toString('hex');

let apiPort = 0;
let frontendPort = 0;
let frontendHost = '127.0.0.1';
let frontendUrl = '';
let frontendAvailable = false;
let frontendManaged = false;
let frontendProc = null;
let frontendReason = '';
let frontendLogFile = null;
let authBootstrap = {
  token: '',
  username: '',
  expiresAt: 0,
  updatedAt: 0,
};

const sessions = new Map(); // sid -> lastSeenAt
let startupAt = Date.now();
let lastActiveAt = Date.now();
let seenAnySession = false;
let gcTimer = null;
let shuttingDown = false;

function parseIntArg(argv, name, fallback) {
  const idx = argv.indexOf(name);
  if (idx === -1) return fallback;
  const raw = argv[idx + 1];
  const n = parseInt(raw, 10);
  if (!Number.isFinite(n)) return fallback;
  return n;
}

function parsePortArg(argv, name, fallback) {
  const n = parseIntArg(argv, name, fallback);
  if (!Number.isFinite(n) || n <= 0 || n > 65535) return fallback;
  return n;
}

function parseStringArg(argv, name, fallback = '') {
  const idx = argv.indexOf(name);
  if (idx === -1) return fallback;
  const raw = argv[idx + 1];
  if (!raw || raw.startsWith('--')) return fallback;
  return String(raw).trim() || fallback;
}

function hasFlag(argv, name) {
  return argv.includes(name);
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function writeRuntime(extra = {}) {
  ensureDir(path.dirname(RUNTIME_FILE));
  const payload = {
    pid: process.pid,
    controlPort,
    controlToken,
    apiPort,
    frontendPort,
    frontendHost,
    frontendUrl,
    frontendAvailable,
    frontendManaged,
    frontendPid: frontendProc && frontendProc.pid ? frontendProc.pid : null,
    sessions: sessions.size,
    startupAt,
    updatedAt: Date.now(),
    ...extra,
  };
  fs.writeFileSync(RUNTIME_FILE, JSON.stringify(payload, null, 2), 'utf-8');
}

function clearRuntime() {
  for (const filePath of [RUNTIME_FILE, LEGACY_RUNTIME_FILE]) {
    try {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    } catch {
      // best effort
    }
  }
}

function isPidAlive(pid) {
  if (!pid || pid <= 0) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

async function waitForExit(pid, timeoutMs = 5000) {
  const started = Date.now();
  while ((Date.now() - started) < timeoutMs) {
    if (!isPidAlive(pid)) return true;
    await new Promise(r => setTimeout(r, 150));
  }
  return !isPidAlive(pid);
}

async function terminatePid(pid) {
  if (!isPidAlive(pid)) return;
  const useGroupSignal = process.platform !== 'win32';
  if (useGroupSignal) {
    try { process.kill(-pid, 'SIGTERM'); } catch { /* ignore */ }
  }
  try { process.kill(pid, 'SIGTERM'); } catch { /* ignore */ }
  const exited = await waitForExit(pid, 4000);
  if (!exited) {
    if (useGroupSignal) {
      try { process.kill(-pid, 'SIGKILL'); } catch { /* ignore */ }
    }
    try { process.kill(pid, 'SIGKILL'); } catch { /* ignore */ }
    await waitForExit(pid, 1500);
  }
}

function canBindPort(host, port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once('error', () => resolve(false));
    server.once('listening', () => {
      server.close(() => resolve(true));
    });
    server.listen(port, host);
  });
}

function isPortOpen(host, port) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ host, port });
    socket.setTimeout(900);
    socket.once('connect', () => {
      socket.destroy();
      resolve(true);
    });
    socket.once('timeout', () => {
      socket.destroy();
      resolve(false);
    });
    socket.once('error', () => resolve(false));
  });
}

async function findAvailablePort(host, startPort, maxScan = 60) {
  for (let p = startPort; p < startPort + maxScan; p++) {
    // eslint-disable-next-line no-await-in-loop
    if (await canBindPort(host, p)) return p;
  }
  return null;
}

function safeJsonParse(raw) {
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function clearAuthBootstrap() {
  authBootstrap = {
    token: '',
    username: '',
    expiresAt: 0,
    updatedAt: 0,
  };
}

function setAuthBootstrap(token, username, ttlMs = DEFAULT_AUTH_BOOTSTRAP_TTL_MS) {
  const nextToken = String(token || '').trim();
  if (!nextToken) {
    clearAuthBootstrap();
    return false;
  }
  const nextUser = String(username || '').trim();
  const ttl = Math.max(
    30_000,
    parseInt(String(ttlMs || DEFAULT_AUTH_BOOTSTRAP_TTL_MS), 10) || DEFAULT_AUTH_BOOTSTRAP_TTL_MS
  );
  authBootstrap = {
    token: nextToken,
    username: nextUser,
    expiresAt: Date.now() + ttl,
    updatedAt: Date.now(),
  };
  return true;
}

function getAuthBootstrap() {
  if (!authBootstrap.token) return null;
  if (authBootstrap.expiresAt > 0 && Date.now() > authBootstrap.expiresAt) {
    clearAuthBootstrap();
    return null;
  }
  return { ...authBootstrap };
}

function normalizeWebPath(pathname = DEFAULT_FRONTEND_ENTRY_PATH) {
  const raw = String(pathname || '').trim();
  if (!raw) return DEFAULT_FRONTEND_ENTRY_PATH;
  return raw.startsWith('/') ? raw : `/${raw}`;
}

function resolveFrontendDistDir({ frontendDistDir, frontendDir }) {
  const candidates = [];
  const seen = new Set();
  const push = (value) => {
    const text = String(value || '').trim();
    if (!text) return;
    const resolved = path.resolve(text);
    if (seen.has(resolved)) return;
    seen.add(resolved);
    candidates.push(resolved);
  };

  push(frontendDistDir);
  push(process.env.AI_FRONTEND_DIST_DIR);
  push(process.env.KHY_AI_FRONTEND_DIST_DIR);

  if (frontendDir) {
    push(path.join(frontendDir, 'dist'));
    push(path.join(frontendDir, 'build'));
  }

  if (process.env.KHYQUANT_ROOT) {
    const root = path.resolve(process.env.KHYQUANT_ROOT);
    const parent = path.resolve(root, '..');
    const grandParent = path.resolve(root, '..', '..');
    const roots = [root, parent, grandParent];
    for (const base of roots) {
      push(path.join(base, 'ai-frontend', 'dist'));
      push(path.join(base, 'frontend', 'dist'));
    }
  }

  const cwd = process.cwd();
  push(path.join(cwd, 'ai-frontend', 'dist'));
  push(path.join(cwd, 'frontend', 'dist'));

  for (const dir of candidates) {
    try {
      if (fs.existsSync(path.join(dir, 'index.html'))) {
        return dir;
      }
    } catch {
      // try next candidate
    }
  }
  return '';
}

function _parseAllowedOrigins(raw) {
  const text = String(raw || '*').trim();
  if (!text || text === '*') return ['*'];
  return text
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
}

function _isOriginAllowed(origin, allowedOrigins) {
  if (!origin) return false;
  if (!Array.isArray(allowedOrigins) || allowedOrigins.length === 0) return false;
  if (allowedOrigins.includes('*')) return true;
  return allowedOrigins.some((item) => item === origin);
}

function buildCorsHeaders(req) {
  const requestOrigin = String(req?.headers?.origin || '').trim();
  const allowedOrigins = _parseAllowedOrigins(
    process.env.AI_MANAGE_CONTROL_CORS_ORIGINS
      || process.env.AI_MGMT_CORS_ORIGINS
      || '*'
  );
  const allowOrigin = requestOrigin && _isOriginAllowed(requestOrigin, allowedOrigins)
    ? requestOrigin
    : (allowedOrigins.includes('*') ? '*' : (allowedOrigins[0] || '*'));

  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Vary': 'Origin',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Khy-Token, Authorization, Accept, Origin',
    'Access-Control-Max-Age': '600',
    'Access-Control-Allow-Private-Network': 'true',
  };
}

function sendJson(req, res, code, payload) {
  const body = code === 204 ? '' : JSON.stringify(payload);
  const headers = {
    ...buildCorsHeaders(req),
  };
  if (code !== 204) {
    headers['Content-Type'] = 'application/json';
    headers['Content-Length'] = Buffer.byteLength(body);
  }
  res.writeHead(code, headers);
  if (code === 204) {
    res.end();
    return;
  }
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve) => {
    let raw = '';
    req.on('data', chunk => { raw += chunk.toString(); });
    req.on('end', () => resolve(raw));
    req.on('error', () => resolve(''));
  });
}

function readAuthToken(req, urlObj) {
  const headerToken = String(req.headers['x-khy-token'] || '').trim();
  if (headerToken) return headerToken;
  return String(urlObj.searchParams.get('token') || '').trim();
}

async function startFrontendProcess({ host, basePort, frontendDir, apiPort: backendPort }) {
  const pkgPath = path.join(frontendDir, 'package.json');
  if (!fs.existsSync(pkgPath)) {
    return { ok: false, reason: `未找到 package.json: ${pkgPath}` };
  }

  const port = await findAvailablePort(host, basePort);
  if (!port) {
    return { ok: false, reason: `未找到可用端口 (起始 ${basePort})` };
  }

  const npmCmd = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const args = ['--prefix', frontendDir, 'run', 'dev', '--', '--host', host, '--port', String(port)];

  ensureDir(LOG_DIR);
  const logFile = path.join(LOG_DIR, 'ai_frontend_dev.log');
  const fd = fs.openSync(logFile, 'a');

  const child = spawn(npmCmd, args, {
    cwd: path.resolve(frontendDir, '..'),
    detached: process.platform !== 'win32',
    env: {
      ...process.env,
      AI_FRONTEND_PORT: String(port),
      VITE_AI_API_BASE_URL: '',
      // Browser should call same-origin "/api" to avoid CORS when host is not localhost.
      // Vite dev server proxies these paths to the management backend target.
      VITE_AI_PROXY_TARGET: `http://127.0.0.1:${backendPort}`,
      BROWSER: 'none',
    },
    stdio: ['ignore', fd, fd],
  });
  fs.closeSync(fd);

  let spawnError = '';
  let exitSummary = '';
  let exitedEarly = false;
  child.once('error', (err) => {
    spawnError = err && err.message ? err.message : String(err);
    exitedEarly = true;
  });
  child.once('exit', (code, signal) => {
    exitedEarly = true;
    const codeText = Number.isFinite(Number(code)) ? `code=${Number(code)}` : `code=${String(code)}`;
    exitSummary = `前端进程提前退出 (${codeText}${signal ? `, signal=${signal}` : ''})`;
  });

  const startupWaitMs = Math.max(
    8000,
    parseInt(process.env.AI_MANAGE_FRONTEND_WAIT_MS || String(DEFAULT_FRONTEND_WAIT_MS), 10) || DEFAULT_FRONTEND_WAIT_MS
  );
  const startedAt = Date.now();
  let ready = false;
  while ((Date.now() - startedAt) < startupWaitMs) {
    // eslint-disable-next-line no-await-in-loop
    if (await isPortOpen(host, port)) {
      ready = true;
      break;
    }
    if (spawnError || exitedEarly) break;
    // eslint-disable-next-line no-await-in-loop
    await new Promise((resolve) => setTimeout(resolve, 250));
  }

  if (!ready) {
    if (child.pid) await terminatePid(child.pid);
    if (spawnError) {
      return { ok: false, reason: `启动前端失败: ${spawnError}`, logFile };
    }
    if (exitSummary) {
      return { ok: false, reason: `${exitSummary}（请检查依赖是否已安装）`, logFile };
    }
    return { ok: false, reason: `前端端口 ${port} 启动超时 (${Math.round(startupWaitMs / 1000)}s)`, logFile };
  }

  return { ok: true, child, port, logFile };
}

async function resolveFrontend({
  host,
  requestedPort,
  autoFrontend,
  noFrontend,
  frontendDir,
  frontendDistDir,
  apiPort: backendPort,
}) {
  const entryPath = normalizeWebPath(
    process.env.AI_FRONTEND_ENTRY_PATH
      || process.env.KHY_AI_FRONTEND_ENTRY_PATH
      || DEFAULT_FRONTEND_ENTRY_PATH
  );
  const staticDistDir = resolveFrontendDistDir({ frontendDistDir, frontendDir });
  const staticFrontendUrl = `http://${host}:${backendPort}${entryPath}`;

  const useStaticFallback = (reason = '') => {
    if (!staticDistDir) return null;
    return {
      available: true,
      managed: false,
      static: true,
      staticDir: staticDistDir,
      entryPath,
      port: backendPort,
      url: staticFrontendUrl,
      reason: reason || `静态前端已启用: ${staticDistDir}`,
    };
  };

  if (noFrontend) {
    return { available: false, managed: false, port: requestedPort, reason: 'disabled' };
  }

  // Prefer managed frontend with auto port fallback.
  if (autoFrontend && frontendDir) {
    const started = await startFrontendProcess({
      host,
      basePort: requestedPort,
      frontendDir,
      apiPort: backendPort,
    });
    if (started.ok) {
      return {
        available: true,
        managed: true,
        port: started.port,
        child: started.child,
        static: false,
        staticDir: '',
        entryPath,
        url: `http://${host}:${started.port}`,
        logFile: started.logFile,
      };
    }

    const staticFallback = useStaticFallback(started.reason);
    if (staticFallback) return staticFallback;

    const allowExternalFallback = String(
      process.env.AI_MANAGE_ALLOW_EXTERNAL_FRONTEND_FALLBACK || 'false'
    ).toLowerCase() === 'true';
    if (!allowExternalFallback) {
      return {
        available: false,
        managed: false,
        port: requestedPort,
        reason: started.reason || 'managed-start-failed',
      };
    }
    // Fall through to external frontend probe only when explicitly enabled.
  } else if (autoFrontend && !frontendDir) {
    const staticFallback = useStaticFallback('未找到可启动的 ai-frontend 开发目录');
    if (staticFallback) return staticFallback;

    const allowExternalFallback = String(
      process.env.AI_MANAGE_ALLOW_EXTERNAL_FRONTEND_FALLBACK || 'false'
    ).toLowerCase() === 'true';
    if (!allowExternalFallback) {
      return {
        available: false,
        managed: false,
        port: requestedPort,
        reason: '未找到 ai-frontend 目录（可通过 --frontend-dir 指定）',
      };
    }
  }

  const externalOpen = await isPortOpen(host, requestedPort);
  if (externalOpen) {
    return {
      available: true,
      managed: false,
      static: false,
      staticDir: '',
      entryPath,
      port: requestedPort,
      url: `http://${host}:${requestedPort}`,
      reason: 'external',
    };
  }

  const staticFallback = useStaticFallback('external-unavailable');
  if (staticFallback) return staticFallback;

  return {
    available: false,
    managed: false,
    static: false,
    staticDir: '',
    entryPath,
    port: requestedPort,
    reason: 'unavailable',
  };
}

function buildStatusPayload() {
  return {
    ok: true,
    runtime: {
      pid: process.pid,
      apiPort,
      frontendPort,
      frontendHost,
      frontendUrl,
      frontendAvailable,
      frontendManaged,
      frontendPid: frontendProc && frontendProc.pid ? frontendProc.pid : null,
      frontendReason,
      frontendLogFile,
      authBootstrapEnabled: !!getAuthBootstrap(),
      controlPort,
      sessions: sessions.size,
      seenAnySession,
      startupAt,
      lastActiveAt,
    },
  };
}

function upsertSession(sid) {
  if (!sid) return;
  sessions.set(sid, Date.now());
  lastActiveAt = Date.now();
  seenAnySession = true;
}

function removeSession(sid) {
  if (!sid) return;
  sessions.delete(sid);
}

async function shutdown(reason = 'unknown') {
  if (shuttingDown) return;
  shuttingDown = true;

  if (gcTimer) {
    clearInterval(gcTimer);
    gcTimer = null;
  }

  try {
    if (controlServer) {
      await new Promise(resolve => controlServer.close(() => resolve()));
      controlServer = null;
    }
  } catch {
    // best effort
  }

  try {
    await aiManagementServer.stop();
  } catch {
    // best effort
  }

  if (frontendManaged && frontendProc && frontendProc.pid) {
    await terminatePid(frontendProc.pid);
  }

  clearRuntime();

  // eslint-disable-next-line no-console
  console.log(`[ai-manage-daemon] shutdown: ${reason}`);
  process.exit(0);
}

function startGcLoop({ idleMs, sessionTtlMs, startupGraceMs }) {
  gcTimer = setInterval(() => {
    const now = Date.now();

    for (const [sid, lastSeen] of sessions) {
      if ((now - lastSeen) > sessionTtlMs) sessions.delete(sid);
    }

    writeRuntime({ sessions: sessions.size });

    if (sessions.size > 0) {
      lastActiveAt = now;
      return;
    }

    const limit = seenAnySession ? idleMs : startupGraceMs;
    if ((now - lastActiveAt) >= limit) {
      shutdown(seenAnySession ? 'idle' : 'startup-timeout').catch(() => process.exit(1));
    }
  }, 5000);
  gcTimer.unref();
}

function createControlServer() {
  controlServer = http.createServer(async (req, res) => {
    if (req.method === 'OPTIONS') {
      return sendJson(req, res, 204, {});
    }

    const urlObj = new URL(req.url, 'http://127.0.0.1');
    const pathname = urlObj.pathname;
    const token = readAuthToken(req, urlObj);
    if (token !== controlToken) {
      return sendJson(req, res, 401, { ok: false, error: 'unauthorized' });
    }

    if (req.method === 'GET' && pathname === '/status') {
      return sendJson(req, res, 200, buildStatusPayload());
    }

    if (req.method === 'POST' && pathname === '/shutdown') {
      sendJson(req, res, 200, { ok: true });
      shutdown('requested').catch(() => process.exit(1));
      return;
    }

    if (req.method === 'GET' && pathname === '/auth/bootstrap') {
      const payload = getAuthBootstrap();
      return sendJson(req, res, 200, {
        ok: true,
        data: payload ? {
          token: payload.token,
          username: payload.username || '',
          expiresAt: payload.expiresAt || 0,
        } : null,
      });
    }

    if (req.method === 'POST' && pathname === '/auth/bootstrap') {
      const bodyRaw = await readBody(req);
      const body = safeJsonParse(bodyRaw || '{}');
      const enabled = body.enabled !== false;
      const tokenText = String(body.token || '').trim();
      const username = String(body.username || '').trim();
      const ttlMs = Math.max(
        30_000,
        parseInt(String(body.ttlMs || process.env.AI_MANAGE_AUTH_BOOTSTRAP_TTL_MS || DEFAULT_AUTH_BOOTSTRAP_TTL_MS), 10)
          || DEFAULT_AUTH_BOOTSTRAP_TTL_MS
      );

      let applied = false;
      if (enabled && tokenText) {
        applied = setAuthBootstrap(tokenText, username, ttlMs);
      } else {
        clearAuthBootstrap();
      }

      writeRuntime({ authBootstrapEnabled: !!getAuthBootstrap() });
      return sendJson(req, res, 200, {
        ok: true,
        enabled: applied,
      });
    }

    if ((req.method === 'POST' || req.method === 'GET') && (pathname === '/open' || pathname === '/ping' || pathname === '/close')) {
      const bodyRaw = await readBody(req);
      const body = safeJsonParse(bodyRaw || '{}');
      const sid = String(body.sid || urlObj.searchParams.get('sid') || '').trim();
      if (!sid) return sendJson(req, res, 400, { ok: false, error: 'missing sid' });

      if (pathname === '/close') {
        removeSession(sid);
      } else {
        upsertSession(sid);
      }
      return sendJson(req, res, 200, { ok: true, sessions: sessions.size });
    }

    return sendJson(req, res, 404, { ok: false, error: 'not found' });
  });
}

async function listenControlServer() {
  await new Promise((resolve, reject) => {
    controlServer.once('error', reject);
    controlServer.listen(0, '127.0.0.1', () => {
      const addr = controlServer.address();
      controlPort = addr && typeof addr === 'object' ? addr.port : 0;
      resolve();
    });
  });
}

async function main() {
  const argv = process.argv.slice(2);
  const requestedApiPort = parsePortArg(argv, '--api-port', DEFAULT_API_PORT);
  const requestedFrontendPort = parsePortArg(argv, '--frontend-port', DEFAULT_FRONTEND_PORT);
  const idleMs = Math.max(10_000, parseIntArg(argv, '--idle-ms', DEFAULT_IDLE_MS));
  const sessionTtlMs = Math.max(10_000, parseIntArg(argv, '--session-ttl-ms', DEFAULT_SESSION_TTL_MS));
  const startupGraceMs = Math.max(20_000, parseIntArg(argv, '--startup-grace-ms', DEFAULT_STARTUP_GRACE_MS));
  const autoFrontend = !hasFlag(argv, '--no-auto-frontend');
  const noFrontend = hasFlag(argv, '--no-frontend');
  const frontendDir = parseStringArg(argv, '--frontend-dir', '');
  const frontendDistDir = parseStringArg(argv, '--frontend-dist-dir', '');
  frontendHost = parseStringArg(argv, '--frontend-host', '127.0.0.1');

  apiPort = await aiManagementServer.start(requestedApiPort);

  const frontend = await resolveFrontend({
    host: frontendHost,
    requestedPort: requestedFrontendPort,
    autoFrontend,
    noFrontend,
    frontendDir,
    frontendDistDir,
    apiPort,
  });

  if (typeof aiManagementServer.configureFrontendStatic === 'function') {
    aiManagementServer.configureFrontendStatic({
      distDir: frontend.static ? frontend.staticDir : '',
      entryPath: frontend.entryPath || DEFAULT_FRONTEND_ENTRY_PATH,
    });
  }

  frontendPort = frontend.port;
  frontendAvailable = !!frontend.available;
  frontendManaged = !!frontend.managed;
  frontendReason = String(frontend.reason || '').trim();
  frontendLogFile = frontend.logFile || null;
  frontendUrl = String(frontend.url || `http://${frontendHost}:${frontendPort}`).trim()
    || `http://${frontendHost}:${frontendPort}`;
  if (frontend.child) {
    frontendProc = frontend.child;
    frontendProc.on('exit', () => {
      frontendProc = null;
      if (frontendManaged) {
        frontendAvailable = false;
        frontendReason = '前端进程已退出';
        writeRuntime({ frontendAvailable: false, frontendPid: null, frontendReason });
      }
    });
  }

  createControlServer();
  await listenControlServer();
  startupAt = Date.now();
  lastActiveAt = Date.now();

  writeRuntime({
    idleMs,
    sessionTtlMs,
    startupGraceMs,
    frontendLogFile,
    frontendReason,
  });

  startGcLoop({ idleMs, sessionTtlMs, startupGraceMs });
}

process.on('SIGTERM', () => { shutdown('sigterm').catch(() => process.exit(1)); });
process.on('SIGINT', () => { shutdown('sigint').catch(() => process.exit(1)); });
process.on('uncaughtException', (err) => {
  // eslint-disable-next-line no-console
  console.error('[ai-manage-daemon] uncaughtException:', err && err.message ? err.message : String(err));
  shutdown('uncaught-exception').catch(() => process.exit(1));
});
process.on('unhandledRejection', (err) => {
  // eslint-disable-next-line no-console
  console.error('[ai-manage-daemon] unhandledRejection:', err && err.message ? err.message : String(err));
  shutdown('unhandled-rejection').catch(() => process.exit(1));
});

main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('[ai-manage-daemon] start failed:', err && err.message ? err.message : String(err));
  clearRuntime();
  process.exit(1);
});
