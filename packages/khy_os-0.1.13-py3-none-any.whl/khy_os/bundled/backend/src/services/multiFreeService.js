const axios = require('axios');
const jwt = require('jsonwebtoken');
const { toGoogleInlineData, toOpenAIVisionBlocks, toAnthropicImageBlocks } = require('./gateway/adapters/_imageCompat');
const { extractPrimaryApiKey } = require('./apiKeyFormat');

class MultiFreeService {
  constructor() {
    this.baiduToken = null;
    this.baiduTokenExpireAt = 0;
    const googleApiKey = extractPrimaryApiKey(process.env.GOOGLE_GEMINI_API_KEY)
      || extractPrimaryApiKey(process.env.GEMINI_API_KEY);
    const groqApiKey = extractPrimaryApiKey(process.env.GROQ_API_KEY);
    const openRouterApiKey = extractPrimaryApiKey(process.env.OPENROUTER_API_KEY);
    const openAiApiKey = extractPrimaryApiKey(process.env.OPENAI_API_KEY);
    const anthropicApiKey = extractPrimaryApiKey(process.env.ANTHROPIC_API_KEY);
    const traeApiKey = extractPrimaryApiKey(process.env.TRAE_API_KEY);
    const zhipuApiKey = extractPrimaryApiKey(process.env.ZHIPU_API_KEY);
    const xunfeiApiKey = extractPrimaryApiKey(process.env.XUNFEI_API_KEY);
    const baiduApiKey = extractPrimaryApiKey(process.env.BAIDU_API_KEY);
    const baiduSecretKey = extractPrimaryApiKey(process.env.BAIDU_SECRET_KEY)
      || extractPrimaryApiKey(process.env.BAIDU_API_SECRET)
      || extractPrimaryApiKey(process.env.BAIDU_SECRET);
    const alibabaApiKey = extractPrimaryApiKey(process.env.ALIBABA_API_KEY)
      || extractPrimaryApiKey(process.env.DASHSCOPE_API_KEY);
    const huggingFaceToken = extractPrimaryApiKey(process.env.HUGGINGFACE_TOKEN);

    this.providers = {
      google: {
        name: 'Google Gemini',
        apiKey: googleApiKey,
        enabled: !!googleApiKey,
        model: 'gemini-2.5-flash',
        priority: 1,
        supportsVision: true,
      },
      groq: {
        name: 'Groq',
        apiKey: groqApiKey,
        enabled: !!groqApiKey,
        model: 'llama-3.3-70b-versatile',
        priority: 2,
        supportsVision: false,
      },
      openrouter: {
        name: 'OpenRouter',
        apiKey: openRouterApiKey,
        enabled: !!openRouterApiKey,
        model: 'meta-llama/llama-3.3-70b-instruct',
        priority: 3,
        supportsVision: false,
      },
      openai: {
        name: 'OpenAI',
        apiKey: openAiApiKey,
        enabled: !!openAiApiKey,
        model: 'gpt-4o-mini',
        priority: 4,
        supportsVision: true,
      },
      anthropic: {
        name: 'Anthropic',
        apiKey: anthropicApiKey,
        enabled: !!anthropicApiKey,
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6',
        priority: 4,
        supportsVision: true,
        availableModels: [
          { id: 'claude-opus-4-6', name: 'Claude Opus 4.6', tier: 'ultra' },
          { id: 'claude-sonnet-4-6', name: 'Claude Sonnet 4.6', tier: 'high' },
          { id: 'claude-haiku-4-5-20251001', name: 'Claude Haiku 4.5', tier: 'medium' },
        ],
      },
      trae: {
        name: 'Trae API',
        apiKey: traeApiKey,
        enabled: !!traeApiKey,
        model: process.env.TRAE_MODEL || 'gpt-4o',
        priority: 5,
        supportsVision: true,
        baseUrl: (process.env.TRAE_API_ENDPOINT || 'https://api.trae.ai').replace(/\/v1\/?$/, ''),
        availableModels: [
          { id: 'gpt-4o', name: 'GPT-4o', tier: 'high' },
          { id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', tier: 'high' },
          { id: 'deepseek-v3', name: 'DeepSeek V3', tier: 'high' },
          { id: 'doubao-1.5-pro', name: 'Doubao 1.5 Pro', tier: 'high' },
        ],
      },
      zhipu: {
        name: '智谱AI',
        apiKey: zhipuApiKey,
        enabled: !!zhipuApiKey,
        model: process.env.ZHIPU_MODEL || 'glm-4-plus',
        priority: 5,
        supportsVision: true,
        availableModels: [
          { id: 'glm-4-plus', name: 'GLM-4-Plus', tier: 'ultra' },
          { id: 'glm-4-0520', name: 'GLM-4', tier: 'high' },
          { id: 'glm-4-air', name: 'GLM-4-Air', tier: 'medium' },
          { id: 'glm-4-airx', name: 'GLM-4-AirX', tier: 'high' },
          { id: 'glm-4-long', name: 'GLM-4-Long (1M tokens)', tier: 'high' },
          { id: 'glm-4-flash', name: 'GLM-4-Flash (Free)', tier: 'low' },
          { id: 'glm-4v-plus', name: 'GLM-4V-Plus (Vision)', tier: 'ultra' },
        ],
      },
      xunfei: {
        name: '讯飞星火',
        apiKey: xunfeiApiKey,
        enabled: !!xunfeiApiKey,
        model: 'lite',
        priority: 6,
        supportsVision: false,
      },
      baidu: {
        name: '百度文心',
        apiKey: baiduApiKey,
        secretKey: baiduSecretKey || '',
        enabled: !!baiduApiKey,
        model: 'ERNIE-Bot',
        priority: 7,
        supportsVision: false,
      },
      alibaba: {
        name: '通义千问',
        apiKey: alibabaApiKey,
        enabled: !!alibabaApiKey,
        model: process.env.QWEN_MODEL || 'qwen-max',
        priority: 8,
        supportsVision: true,
        availableModels: [
          { id: 'qwen-max', name: 'Qwen-Max', tier: 'ultra' },
          { id: 'qwen-plus', name: 'Qwen-Plus', tier: 'high' },
          { id: 'qwen-turbo', name: 'Qwen-Turbo', tier: 'medium' },
          { id: 'qwen-long', name: 'Qwen-Long (10M tokens)', tier: 'high' },
          { id: 'qwen-vl-max', name: 'Qwen-VL-Max (Vision)', tier: 'ultra' },
          { id: 'qwen-vl-plus', name: 'Qwen-VL-Plus (Vision)', tier: 'high' },
          { id: 'qwen-coder-plus', name: 'Qwen-Coder-Plus', tier: 'high' },
          { id: 'qwen2.5-72b-instruct', name: 'Qwen2.5-72B', tier: 'ultra' },
          { id: 'qwen2.5-32b-instruct', name: 'Qwen2.5-32B', tier: 'high' },
          { id: 'qwen2.5-14b-instruct', name: 'Qwen2.5-14B', tier: 'medium' },
          { id: 'qwen2.5-7b-instruct', name: 'Qwen2.5-7B', tier: 'low' },
        ],
      },
      huggingface: {
        name: 'HuggingFace',
        apiKey: huggingFaceToken,
        enabled: !!huggingFaceToken,
        model: 'mistralai/Mistral-7B-Instruct-v0.2',
        priority: 9,
        supportsVision: false,
      }
    };
  }

  getAvailableProviders() {
    return Object.entries(this.providers)
      .filter(([, provider]) => provider.enabled)
      .sort(([, a], [, b]) => a.priority - b.priority)
      .map(([key, provider]) => ({ key, ...provider }));
  }

  getAvailableProvider() {
    const providers = this.getAvailableProviders();
    return providers.length > 0 ? providers[0] : null;
  }

  getStatus() {
    const available = this.getAvailableProviders();
    return {
      available: available.length > 0,
      provider: available[0]?.name || 'local-fallback',
      configuredProviders: available.map((p) => p.name),
      message: available.length > 0
        ? `${available.length} provider(s) configured`
        : 'No cloud providers configured, using local fallback'
    };
  }

  async testConnection() {
    const availableProviders = this.getAvailableProviders().map((p) => p.name);
    if (availableProviders.length === 0) {
      return {
        success: false,
        message: 'No LLM providers configured',
        provider: 'local-fallback',
        response: null,
        availableProviders,
        results: []
      };
    }

    const result = await this.generateResponse('Reply with one short sentence: connection ok.', {
      temperature: 0,
      maxTokens: 64
    });

    return {
      success: result.success,
      message: result.success ? 'LLM connection test completed' : 'LLM connection test failed',
      provider: result.provider,
      response: result.content,
      availableProviders,
      results: result.attempts || []
    };
  }

  async analyze(payload = {}) {
    const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
    const stockCode = payload.stockCode || 'UNKNOWN';
    const result = await this.generateResponse(prompt, {
      temperature: payload.temperature ?? 0.4,
      maxTokens: payload.maxTokens ?? 1500
    });

    if (result.success && result.content) {
      return result.content;
    }

    return this.localFallback(payload.agentId, stockCode);
  }

  async generateResponse(prompt, options = {}) {
    const temperature = options.temperature ?? 0.4;
    const maxTokens = options.maxTokens ?? 1024;
    const requestedProvider = String(options.provider || '').trim().toLowerCase();
    const requestedModel = String(options.model || '').trim();

    if (!prompt || !prompt.trim()) {
      return {
        success: false,
        content: 'Prompt is empty',
        provider: 'none',
        attempts: []
      };
    }

    const allProviders = this.getAvailableProviders();
    let providers = allProviders;

    if (requestedProvider) {
      providers = allProviders.filter((p) => p.key === requestedProvider);
      if (providers.length === 0) {
        return {
          success: false,
          content: `Provider not configured: ${requestedProvider}`,
          provider: 'none',
          attempts: [],
          availableProviders: allProviders.map((p) => p.key)
        };
      }
    }

    if (requestedModel && providers.length > 1) {
      const scoreByModel = (provider) => {
        if (provider.model === requestedModel) return 3;
        if (Array.isArray(provider.availableModels) && provider.availableModels.some((m) => m.id === requestedModel)) return 2;
        return 0;
      };
      providers = [...providers].sort((a, b) => {
        const diff = scoreByModel(b) - scoreByModel(a);
        if (diff !== 0) return diff;
        return a.priority - b.priority;
      });
    }

    const attempts = [];

    for (const provider of providers) {
      // Skip non-vision providers when images are present
      if (options.images && options.images.length > 0 && !provider.supportsVision) {
        attempts.push({ provider: provider.name, success: false, error: 'No vision support' });
        continue;
      }

      try {
        const result = await this.callProvider(provider, prompt, {
          temperature,
          maxTokens,
          images: options.images,
          model: requestedModel || provider.model,
          tools: options.tools,
          structuredMessages: options.structuredMessages,
          system: options.system,
          onChunk: options.onChunk,
          thinking: options.thinking,
        });
        // callProvider now returns { content, tokenUsage, thinking? } or a plain string (legacy)
        const content = typeof result === 'string' ? result : result?.content;
        const tokenUsage = typeof result === 'object' ? result?.tokenUsage : null;
        const thinking = typeof result === 'object' ? result?.thinking : null;

        if (typeof content === 'string' && content.trim()) {
          attempts.push({ provider: provider.name, success: true });
          return {
            success: true,
            content: content.trim(),
            provider: provider.name,
            model: requestedModel || provider.model,
            tokenUsage: tokenUsage || null,
            thinking: thinking || undefined,
            attempts,
            availableProviders: providers.map((p) => p.name)
          };
        }

        attempts.push({ provider: provider.name, success: false, error: 'Empty response' });
      } catch (error) {
        attempts.push({ provider: provider.name, success: false, error: error.message });
      }
    }

    return {
      success: false,
      content: this.localFallback('general', 'UNKNOWN'),
      provider: 'local-fallback',
      attempts,
      availableProviders: providers.map((p) => p.name)
    };
  }

  async callProvider(provider, prompt, opts) {
    switch (provider.key) {
      case 'google':
        return this.callGoogle(provider, prompt, opts);
      case 'groq':
        return this.callGroq(provider, prompt, opts);
      case 'openrouter':
        return this.callOpenRouter(provider, prompt, opts);
      case 'openai':
        return this.callOpenAI(provider, prompt, opts);
      case 'anthropic':
        return this.callAnthropic(provider, prompt, opts);
      case 'trae':
        return this.callOpenAI(provider, prompt, opts);
      case 'zhipu':
        return this.callZhipu(provider, prompt, opts);
      case 'xunfei':
        return this.callXunfei(provider, prompt, opts);
      case 'baidu':
        return this.callBaidu(provider, prompt, opts);
      case 'alibaba':
        return this.callAlibaba(provider, prompt, opts);
      case 'huggingface':
        return this.callHuggingFace(provider, prompt, opts);
      default:
        throw new Error(`Unsupported provider: ${provider.key}`);
    }
  }

  async callGoogle(provider, prompt, opts) {
    const model = opts.model || provider.model || 'gemini-2.5-flash';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${provider.apiKey}`;

    // Build parts: images first (if any), then text
    const parts = [];
    if (opts.images && opts.images.length > 0) {
      for (const block of toGoogleInlineData(opts.images)) parts.push(block);
    }
    parts.push({ text: prompt });

    const response = await axios.post(url, {
      contents: [{ parts }],
      generationConfig: {
        temperature: opts.temperature,
        maxOutputTokens: opts.maxTokens
      }
    }, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 30000
    });

    const content = response.data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const meta = response.data?.usageMetadata;
    const tokenUsage = meta ? {
      inputTokens: meta.promptTokenCount || 0,
      outputTokens: meta.candidatesTokenCount || 0,
      totalTokens: meta.totalTokenCount || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callGroq(provider, prompt, opts) {
    const model = opts.model || provider.model || 'llama-3.3-70b-versatile';
    const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
      model,
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    const content = response.data?.choices?.[0]?.message?.content || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callOpenRouter(provider, prompt, opts) {
    const model = opts.model || provider.model;
    const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
      model,
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://khyquant.com',
        'X-Title': 'khy OS'
      },
      timeout: 30000
    });

    const content = response.data?.choices?.[0]?.message?.content || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callOpenAI(provider, prompt, opts) {
    // Support custom base URL (relay/proxy) via OPENAI_BASE_URL env
    // Strip trailing /v1 if present to prevent double /v1/v1 paths
    let baseUrl = provider.baseUrl || process.env.OPENAI_BASE_URL || 'https://api.openai.com';
    baseUrl = baseUrl.replace(/\/v1\/?$/, '');
    const model = opts.model || provider.model;

    // Build message content: multimodal array if images present, plain string otherwise
    let messageContent;
    if (opts.images && opts.images.length > 0) {
      messageContent = [
        ...toOpenAIVisionBlocks(opts.images),
        { type: 'text', text: prompt },
      ];
    } else {
      messageContent = prompt;
    }

    // Use structured messages if available, otherwise single user message
    const messages = opts.structuredMessages && opts.structuredMessages.length > 0
      ? opts.structuredMessages
      : [{ role: 'user', content: messageContent }];

    const requestBody = {
      model,
      messages,
      temperature: opts.temperature,
      max_tokens: opts.maxTokens,
    };

    // Inject tool definitions for native function calling
    if (opts.tools && opts.tools.length > 0) {
      requestBody.tools = opts.tools.map(t => ({
        type: 'function',
        function: { name: t.name, description: t.description, parameters: t.parameters },
      }));
    }

    // ── Streaming path: SSE for real-time output ────────────────────
    if (typeof opts.onChunk === 'function') {
      requestBody.stream = true;
      const response = await axios.post(`${baseUrl}/v1/chat/completions`, requestBody, {
        headers: {
          Authorization: `Bearer ${provider.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: opts.timeoutMs || 120000,
        responseType: 'stream',
        signal: opts.signal,
      });

      let content = '';
      const toolCallAccum = {}; // index → {name, arguments}
      let inputTokens = 0, outputTokens = 0;

      return new Promise((resolve, reject) => {
        let buffer = '';
        const stream = response.data;

        stream.on('data', (chunk) => {
          buffer += chunk.toString();
          const lines = buffer.split('\n');
          buffer = lines.pop(); // keep incomplete line

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed || !trimmed.startsWith('data: ')) continue;
            const payload = trimmed.slice(6);
            if (payload === '[DONE]') continue;

            try {
              const data = JSON.parse(payload);
              const delta = data.choices?.[0]?.delta;
              if (!delta) continue;

              // Text content
              if (delta.content) {
                content += delta.content;
                opts.onChunk({ type: 'text', text: delta.content });
              }

              // Tool calls (streamed incrementally)
              if (delta.tool_calls) {
                for (const tc of delta.tool_calls) {
                  const idx = tc.index ?? 0;
                  if (!toolCallAccum[idx]) toolCallAccum[idx] = { name: '', arguments: '' };
                  if (tc.function?.name) toolCallAccum[idx].name = tc.function.name;
                  if (tc.function?.arguments) toolCallAccum[idx].arguments += tc.function.arguments;
                }
              }

              // Usage info (some providers send this in the last chunk)
              if (data.usage) {
                inputTokens = data.usage.prompt_tokens || 0;
                outputTokens = data.usage.completion_tokens || 0;
                opts.onChunk({ type: 'cost', cost: {
                  inputTokens, outputTokens,
                  totalTokens: data.usage.total_tokens || inputTokens + outputTokens,
                }});
              }
            } catch { /* skip malformed SSE lines */ }
          }
        });

        stream.on('end', () => {
          // Finalize accumulated tool calls
          const toolCalls = Object.values(toolCallAccum).filter(tc => tc.name);
          if (toolCalls.length > 0) {
            const toolCallText = toolCalls.map(tc => {
              let params;
              try { params = JSON.parse(tc.arguments); } catch { params = tc.arguments; }
              return `<tool_call>${JSON.stringify({ name: tc.name, params })}</tool_call>`;
            }).join('\n');
            content = content ? `${content}\n${toolCallText}` : toolCallText;

            for (const tc of toolCalls) {
              opts.onChunk({ type: 'tool_use', tool: tc.name });
            }
          }

          const tokenUsage = (inputTokens || outputTokens) ? {
            inputTokens, outputTokens,
            totalTokens: inputTokens + outputTokens,
          } : null;
          resolve({ content, tokenUsage });
        });

        stream.on('error', reject);
      });
    }

    // ── Non-streaming fallback ──────────────────────────────────────
    const response = await axios.post(`${baseUrl}/v1/chat/completions`, requestBody, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    const msg = response.data?.choices?.[0]?.message;
    let content = msg?.content || '';

    // Convert native tool_calls to <tool_call> format for unified parsing
    if (msg?.tool_calls && msg.tool_calls.length > 0) {
      const toolCallText = msg.tool_calls.map(tc => {
        const fn = tc.function;
        let params;
        try { params = JSON.parse(fn.arguments); } catch { params = fn.arguments; }
        return `<tool_call>${JSON.stringify({ name: fn.name, params })}</tool_call>`;
      }).join('\n');
      content = content ? `${content}\n${toolCallText}` : toolCallText;
    }

    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callAnthropic(provider, prompt, opts) {
    // Support custom base URL (relay/proxy) via ANTHROPIC_BASE_URL env
    const baseUrl = (provider.baseUrl || process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/+$/, '');
    const isRelay = !baseUrl.includes('api.anthropic.com');

    // Build message content: multimodal array if images present, plain string otherwise
    let messageContent;
    if (opts.images && opts.images.length > 0 && !isRelay) {
      messageContent = [
        ...toAnthropicImageBlocks(opts.images),
        { type: 'text', text: prompt },
      ];
    } else {
      messageContent = prompt;
    }

    // Build messages: use structured messages if available
    let apiMessages;
    let systemContent = '';
    if (opts.structuredMessages && opts.structuredMessages.length > 0) {
      // Anthropic uses separate system param, extract it from messages
      const sysMsg = opts.structuredMessages.find(m => m.role === 'system');
      if (sysMsg) systemContent = sysMsg.content;
      apiMessages = opts.structuredMessages
        .filter(m => m.role !== 'system')
        .map(m => ({ role: m.role, content: m.content }));
      // Ensure first message is user role (Anthropic requirement)
      if (apiMessages.length > 0 && apiMessages[0].role !== 'user') {
        apiMessages.unshift({ role: 'user', content: '(context follows)' });
      }
    } else {
      apiMessages = [{ role: 'user', content: messageContent }];
    }
    if (opts.system && !systemContent) systemContent = opts.system;

    const body = {
      model: opts.model || provider.model,
      max_tokens: opts.maxTokens,
      temperature: opts.temperature,
      messages: apiMessages,
    };

    // Add system prompt with cache breakpoint for Anthropic prompt caching
    // This reduces repeated system prompt costs by ~90%
    if (systemContent) {
      const cacheBoundary = '<!-- CACHE_BOUNDARY -->';
      const boundaryIdx = systemContent.indexOf(cacheBoundary);
      if (boundaryIdx > 0 && !isRelay) {
        // Split at cache boundary: stable prefix (cached) + dynamic suffix
        const stablePrefix = systemContent.slice(0, boundaryIdx).trim();
        const dynamicSuffix = systemContent.slice(boundaryIdx + cacheBoundary.length).trim();
        body.system = [
          { type: 'text', text: stablePrefix, cache_control: { type: 'ephemeral' } },
          { type: 'text', text: dynamicSuffix },
        ];
      } else {
        body.system = systemContent;
      }
    }

    // Add tool definitions for native tool use
    if (opts.tools && opts.tools.length > 0 && !isRelay) {
      body.tools = opts.tools.map(t => ({
        name: t.name,
        description: t.description,
        input_schema: t.parameters || { type: 'object', properties: {} },
      }));
    }

    // Enable thinking/extended thinking for supported models on official API
    if (!isRelay && opts.thinking) {
      // Anthropic extended thinking: { type: "enabled", budget_tokens: N }
      body.thinking = { type: 'enabled', budget_tokens: opts.thinking.budgetTokens || 10000 };
      // Extended thinking requires higher max_tokens
      body.max_tokens = Math.max(body.max_tokens || 4096, 16000);
    }

    // Relay compatibility: don't include extended_thinking or thinking fields
    if (isRelay) {
      delete body.thinking;
      delete body.extended_thinking;
      delete body.tools; // Relays may not support tools
    }

    // ── Streaming path for Anthropic ────────────────────────────────
    if (typeof opts.onChunk === 'function' && !isRelay) {
      body.stream = true;
      const response = await axios.post(`${baseUrl}/v1/messages`, body, {
        headers: {
          'x-api-key': provider.apiKey,
          'anthropic-version': '2024-10-22',
          'anthropic-beta': 'prompt-caching-2024-07-31',
          'Content-Type': 'application/json',
        },
        timeout: opts.timeoutMs || 120000,
        responseType: 'stream',
        signal: opts.signal,
      });

      let content = '';
      let thinkingContent = '';
      let currentToolName = '';
      let currentToolInput = '';
      let inputTokens = 0, outputTokens = 0;
      const toolUseBlocks = [];

      return new Promise((resolve, reject) => {
        let buffer = '';
        const stream = response.data;

        stream.on('data', (chunk) => {
          buffer += chunk.toString();
          const lines = buffer.split('\n');
          buffer = lines.pop();

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith('data: ')) continue;
            const payload = trimmed.slice(6);
            if (payload === '[DONE]') continue;

            try {
              const event = JSON.parse(payload);

              // Anthropic SSE event types
              switch (event.type) {
                case 'content_block_start': {
                  const block = event.content_block;
                  if (block?.type === 'tool_use') {
                    currentToolName = block.name || '';
                    currentToolInput = '';
                    opts.onChunk({ type: 'tool_use', tool: currentToolName });
                  } else if (block?.type === 'thinking') {
                    opts.onChunk({ type: 'thinking', text: '' });
                  }
                  break;
                }
                case 'content_block_delta': {
                  const delta = event.delta;
                  if (delta?.type === 'text_delta' && delta.text) {
                    content += delta.text;
                    opts.onChunk({ type: 'text', text: delta.text });
                  } else if (delta?.type === 'thinking_delta' && delta.thinking) {
                    thinkingContent += delta.thinking;
                    opts.onChunk({ type: 'thinking', text: delta.thinking });
                  } else if (delta?.type === 'input_json_delta' && delta.partial_json) {
                    currentToolInput += delta.partial_json;
                  }
                  break;
                }
                case 'content_block_stop': {
                  if (currentToolName) {
                    let input = {};
                    try { input = JSON.parse(currentToolInput); } catch { /* ignore */ }
                    toolUseBlocks.push({ name: currentToolName, input });
                    currentToolName = '';
                    currentToolInput = '';
                  }
                  break;
                }
                case 'message_delta': {
                  if (event.usage) {
                    outputTokens = event.usage.output_tokens || 0;
                    opts.onChunk({ type: 'cost', cost: {
                      inputTokens, outputTokens,
                      totalTokens: inputTokens + outputTokens,
                    }});
                  }
                  break;
                }
                case 'message_start': {
                  if (event.message?.usage) {
                    inputTokens = event.message.usage.input_tokens || 0;
                    opts.onChunk({ type: 'cost', cost: {
                      inputTokens, outputTokens: 0,
                      totalTokens: inputTokens,
                    }});
                  }
                  break;
                }
              }
            } catch { /* skip malformed SSE lines */ }
          }
        });

        stream.on('end', () => {
          // Finalize tool_use blocks
          if (toolUseBlocks.length > 0) {
            const toolCallText = toolUseBlocks.map(block =>
              `<tool_call>${JSON.stringify({ name: block.name, params: block.input || {} })}</tool_call>`
            ).join('\n');
            content = content ? `${content}\n${toolCallText}` : toolCallText;
          }

          const tokenUsage = (inputTokens || outputTokens) ? {
            inputTokens, outputTokens,
            totalTokens: inputTokens + outputTokens,
          } : null;
          resolve({ content, tokenUsage, thinking: thinkingContent || undefined });
        });

        stream.on('error', reject);
      });
    }

    // ── Non-streaming fallback ──────────────────────────────────────
    let response;
    try {
      response = await axios.post(`${baseUrl}/v1/messages`, body, {
        headers: {
          'x-api-key': provider.apiKey,
          'anthropic-version': '2024-10-22',
          'anthropic-beta': 'prompt-caching-2024-07-31',
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });
    } catch (err) {
      if (isRelay && err.response?.status === 400) {
        const minimalBody = {
          model: opts.model || provider.model,
          max_tokens: opts.maxTokens,
          temperature: opts.temperature,
          messages: [{ role: 'user', content: messageContent }],
        };
        response = await axios.post(`${baseUrl}/v1/messages`, minimalBody, {
          headers: {
            'x-api-key': provider.apiKey,
            'anthropic-version': '2024-10-22',
            'Content-Type': 'application/json'
          },
          timeout: 30000
        });
      } else {
        throw err;
      }
    }

    // Extract content: handle text, thinking, and tool_use blocks
    let content = '';
    let thinkingContent = '';
    const contentBlocks = response.data?.content || [];
    const toolUseBlocks = [];
    for (const block of contentBlocks) {
      if (block.type === 'text') {
        content += block.text;
      } else if (block.type === 'tool_use') {
        toolUseBlocks.push(block);
      } else if (block.type === 'thinking') {
        thinkingContent += (block.thinking || '');
      }
    }
    if (!content && !toolUseBlocks.length) content = response.data?.content?.[0]?.text || '';

    if (toolUseBlocks.length > 0) {
      const toolCallText = toolUseBlocks.map(block =>
        `<tool_call>${JSON.stringify({ name: block.name, params: block.input || {} })}</tool_call>`
      ).join('\n');
      content = content ? `${content}\n${toolCallText}` : toolCallText;
    }

    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.input_tokens || 0,
      outputTokens: usage.output_tokens || 0,
      totalTokens: (usage.input_tokens || 0) + (usage.output_tokens || 0),
    } : null;
    return { content, tokenUsage, thinking: thinkingContent || undefined };
  }

  generateZhipuJWT(apiKey) {
    const [id, secret] = apiKey.split('.');
    if (!id || !secret) {
      throw new Error('Invalid Zhipu API key format, expected id.secret');
    }

    const payload = {
      api_key: id,
      exp: Math.round(Date.now() / 1000) + 3600,
      timestamp: Math.round(Date.now() / 1000)
    };

    return jwt.sign(payload, secret, {
      algorithm: 'HS256',
      header: { alg: 'HS256', sign_type: 'SIGN' }
    });
  }

  async callZhipu(provider, prompt, opts) {
    const model = opts.model || provider.model;
    const token = this.generateZhipuJWT(provider.apiKey);
    const baseUrl = (provider.baseUrl || 'https://open.bigmodel.cn/api/paas/v4').replace(/\/+$/, '');
    const endpoint = /\/chat\/completions$/i.test(baseUrl)
      ? baseUrl
      : `${baseUrl}/chat/completions`;

    // Build multimodal content for vision models
    let messageContent = prompt;
    if (opts.images && opts.images.length > 0 && /glm-4v/i.test(model)) {
      messageContent = [
        ...toOpenAIVisionBlocks(opts.images),
        { type: 'text', text: prompt },
      ];
    }

    const response = await axios.post(endpoint, {
      model,
      messages: [{ role: 'user', content: messageContent }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      timeout: 60000
    });

    const content = response.data?.choices?.[0]?.message?.content || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callXunfei(provider, prompt, opts) {
    const model = opts.model || provider.model || 'lite';
    const response = await axios.post('https://spark-api-open.xf-yun.com/v1/chat/completions', {
      model,
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    const content = response.data?.choices?.[0]?.message?.content || response.data?.result || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callAlibaba(provider, prompt, opts) {
    const model = opts.model || provider.model;
    const baseUrl = (provider.baseUrl || 'https://dashscope.aliyuncs.com').replace(/\/+$/, '');

    // Use OpenAI-compatible API for newer models (qwen-max, qwen-plus, etc.)
    const useCompatible = /^qwen[2-]/.test(model) || ['qwen-max', 'qwen-plus', 'qwen-turbo', 'qwen-long', 'qwen-vl-max', 'qwen-vl-plus', 'qwen-coder-plus'].includes(model);
    const compatibleUrl = /\/compatible-mode\/v1$/i.test(baseUrl)
      ? `${baseUrl}/chat/completions`
      : `${baseUrl}/compatible-mode/v1/chat/completions`;
    const legacyUrl = /\/api\/v1$/i.test(baseUrl)
      ? `${baseUrl}/services/aigc/text-generation/generation`
      : `${baseUrl}/api/v1/services/aigc/text-generation/generation`;

    if (useCompatible) {
      const response = await axios.post(compatibleUrl, {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature,
        max_tokens: opts.maxTokens,
      }, {
        headers: {
          Authorization: `Bearer ${provider.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: 60000,
      });

      const content = response.data?.choices?.[0]?.message?.content || '';
      const usage = response.data?.usage;
      const tokenUsage = usage ? {
        inputTokens: usage.prompt_tokens || 0,
        outputTokens: usage.completion_tokens || 0,
        totalTokens: usage.total_tokens || 0,
      } : null;
      return { content, tokenUsage };
    }

    // Legacy DashScope API
    const response = await axios.post(legacyUrl, {
      model,
      input: {
        messages: [{ role: 'user', content: prompt }]
      },
      parameters: {
        result_format: 'message',
        temperature: opts.temperature,
        max_tokens: opts.maxTokens
      }
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    const content = response.data?.output?.choices?.[0]?.message?.content || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.input_tokens || 0,
      outputTokens: usage.output_tokens || 0,
      totalTokens: usage.total_tokens || (usage.input_tokens || 0) + (usage.output_tokens || 0),
    } : null;
    return { content, tokenUsage };
  }

  async getBaiduAccessToken(provider) {
    const now = Date.now();
    if (this.baiduToken && now < this.baiduTokenExpireAt) {
      return this.baiduToken;
    }

    // Mutex: if another call is already refreshing, wait for it
    if (this._baiduTokenPromise) {
      return this._baiduTokenPromise;
    }

    this._baiduTokenPromise = (async () => {
      try {
        if (!provider.secretKey) {
          throw new Error('Missing BAIDU_SECRET_KEY for OAuth flow');
        }

        const tokenUrl = `https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=${provider.apiKey}&client_secret=${provider.secretKey}`;
        const tokenResponse = await axios.get(tokenUrl, { timeout: 20000 });
        const accessToken = tokenResponse.data?.access_token;

        if (!accessToken) {
          throw new Error('Failed to obtain Baidu access token');
        }

        const expiresIn = Number(tokenResponse.data?.expires_in || 2592000);
        // Add jitter to prevent thundering herd on token expiry
        const jitter = 300 + Math.floor(Math.random() * 300);
        this.baiduToken = accessToken;
        this.baiduTokenExpireAt = now + Math.max(60, expiresIn - jitter) * 1000;
        return accessToken;
      } finally {
        this._baiduTokenPromise = null;
      }
    })();

    return this._baiduTokenPromise;
  }

  async callBaidu(provider, prompt, opts) {
    const accessToken = await this.getBaiduAccessToken(provider);
    const baseUrl = (provider.baseUrl || 'https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop').replace(/\/+$/, '');
    const endpoint = /\/chat\/completions$/i.test(baseUrl)
      ? baseUrl
      : `${baseUrl}/chat/completions`;
    const response = await axios.post(
      endpoint,
      {
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature,
        top_p: 0.8
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        timeout: 30000
      }
    );

    const content = response.data?.result || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callHuggingFace(provider, prompt, opts) {
    const model = opts.model || provider.model;
    const response = await axios.post(
      `https://api-inference.huggingface.co/models/${model}`,
      {
        inputs: prompt,
        parameters: {
          max_new_tokens: Math.min(opts.maxTokens, 512),
          temperature: opts.temperature
        }
      },
      {
        headers: {
          Authorization: `Bearer ${provider.apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 45000
      }
    );

    let content = '';
    if (Array.isArray(response.data) && response.data[0]?.generated_text) {
      content = response.data[0].generated_text;
    } else if (typeof response.data?.generated_text === 'string') {
      content = response.data.generated_text;
    }

    // HuggingFace does not return token counts; estimate
    const { estimateTokens } = require('./tokenUsageService');
    const tokenUsage = {
      inputTokens: estimateTokens(prompt),
      outputTokens: estimateTokens(content),
      totalTokens: estimateTokens(prompt) + estimateTokens(content),
    };
    return { content, tokenUsage };
  }

  localFallback(agentId = 'general', stockCode = 'UNKNOWN') {
    const templates = {
      fundamentals: `【基本面分析】${stockCode} 估值与盈利能力处于可追踪区间，建议结合季报数据和行业对比后再做加仓决策。`,
      market: `【市场分析】${stockCode} 当前处于震荡整理结构，建议等待放量突破信号确认后再积极布局。`,
      social: `【情绪分析】${stockCode} 市场情绪分歧较大，建议避免情绪化操作，严格执行既定交易规则。`,
      news: `【新闻分析】${stockCode} 当前暂无明确单边催化剂，建议密切关注官方公告及政策变化动向。`,
      strategy: `【策略分析】${stockCode} 适合采用分批建仓策略，严格设置止损位并控制风险预算。`,
      risk: `【风险分析】${stockCode} 主要风险来自波动率扩张和流动性变化，建议保持保守仓位管理。`
    };

    return templates[agentId] || `【综合分析】${stockCode} 在线大模型服务暂时不可用，已返回本地规则兜底分析结果。`;
  }
}

module.exports = MultiFreeService;
