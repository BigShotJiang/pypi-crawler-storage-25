'use strict';

/**
 * retryWithBackoff.js — Exponential backoff retry with jitter.
 *
 * Ported from OpenClaw's retry.ts:
 *   - Configurable attempts, delay bounds, jitter
 *   - shouldRetry predicate for error classification
 *   - retryAfterMs parser for server backpressure (Retry-After header)
 *   - onRetry callback for telemetry
 *
 * Constants:
 *   DEFAULT_ATTEMPTS = 3
 *   DEFAULT_MIN_DELAY = 300ms
 *   DEFAULT_MAX_DELAY = 30000ms
 *   DEFAULT_JITTER = 1.0 (±100%)
 */

const DEFAULT_ATTEMPTS = 3;
const DEFAULT_MIN_DELAY = 300;
const DEFAULT_MAX_DELAY = 30000;
const DEFAULT_JITTER = 1.0;

// ── Persistent retry mode (CI / unattended) ─────────────────────────────
// Enabled via KHY_UNATTENDED_RETRY=true. For 429/529 errors only.
// Keeps retrying with capped backoff until the rate window resets or
// an absolute cap (6h) is reached. Emits heartbeat every 30s to keep
// CI hosts alive.
const PERSISTENT_MAX_BACKOFF_MS = 5 * 60 * 1000;   // 5 min cap per sleep
const PERSISTENT_ABSOLUTE_CAP_MS = 6 * 60 * 60 * 1000; // 6 hour hard stop
const HEARTBEAT_INTERVAL_MS = 30_000;                // 30s keepalive

/**
 * Execute a function with exponential backoff retry.
 *
 * @param {function} fn - Async function to execute
 * @param {object} [opts]
 * @param {number} [opts.attempts=3] - Max attempts (1 = no retry)
 * @param {number} [opts.minDelayMs=300] - Minimum delay between retries
 * @param {number} [opts.maxDelayMs=30000] - Maximum delay between retries
 * @param {number} [opts.jitter=1.0] - Jitter fraction [0,1]. 1.0 = ±100%
 * @param {string} [opts.label] - Diagnostic label for logging
 * @param {function} [opts.shouldRetry] - (err, attempt) => boolean. Default: always retry
 * @param {function} [opts.retryAfterMs] - (err) => number|undefined. Extract Retry-After from error
 * @param {function} [opts.onRetry] - (info: RetryInfo) => void. Called before each retry sleep
 * @param {AbortSignal} [opts.signal] - AbortSignal for cancellation
 * @returns {Promise<T>} Result of fn()
 */
async function retryWithBackoff(fn, opts = {}) {
  const {
    attempts = DEFAULT_ATTEMPTS,
    minDelayMs = DEFAULT_MIN_DELAY,
    maxDelayMs = DEFAULT_MAX_DELAY,
    jitter = DEFAULT_JITTER,
    label,
    shouldRetry,
    retryAfterMs,
    onRetry,
    signal,
  } = opts;

  const maxAttempts = Math.max(1, Math.floor(attempts));

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    // Check abort before each attempt
    if (signal?.aborted) {
      throw new Error(`Retry aborted${label ? ` (${label})` : ''}`);
    }

    try {
      return await fn(attempt);
    } catch (err) {
      // Last attempt — throw without retry
      if (attempt >= maxAttempts) throw err;

      // Check if error is retryable
      if (shouldRetry && !shouldRetry(err, attempt)) throw err;

      // Calculate delay
      let baseDelay;

      // Check for server-specified retry-after
      const serverDelay = retryAfterMs ? retryAfterMs(err) : undefined;
      if (serverDelay != null && serverDelay > 0) {
        baseDelay = Math.max(serverDelay, minDelayMs);
      } else {
        // Exponential backoff: minDelay * 2^(attempt-1)
        baseDelay = minDelayMs * Math.pow(2, attempt - 1);
      }

      // Apply jitter: ±(jitter * baseDelay)
      if (jitter > 0) {
        const jitterRange = jitter * baseDelay;
        baseDelay += (Math.random() * 2 - 1) * jitterRange;
      }

      // Clamp to [minDelayMs, maxDelayMs]
      const delayMs = Math.min(maxDelayMs, Math.max(minDelayMs, Math.round(baseDelay)));

      // Emit retry callback
      if (onRetry) {
        onRetry({
          attempt,
          maxAttempts,
          delayMs,
          err,
          label,
        });
      }

      // Sleep with abort support
      await _sleep(delayMs, signal);
    }
  }
}

/**
 * Parse Retry-After from HTTP-style errors.
 * Handles both seconds (integer) and date (HTTP-date) formats.
 *
 * @param {Error|object} err
 * @returns {number|undefined} milliseconds to wait
 */
function parseRetryAfter(err) {
  const header = err?.response?.headers?.['retry-after']
    || err?.headers?.['retry-after']
    || err?.retryAfter;

  if (header == null) return undefined;

  // Integer seconds
  const seconds = Number(header);
  if (!isNaN(seconds) && seconds > 0) {
    return Math.ceil(seconds * 1000);
  }

  // HTTP-date format
  try {
    const date = new Date(header);
    const ms = date.getTime() - Date.now();
    return ms > 0 ? ms : undefined;
  } catch {
    return undefined;
  }
}

/**
 * Common shouldRetry predicate for HTTP errors.
 * Retries on 429 (rate limit), 5xx (server error), network errors.
 *
 * @param {Error|object} err
 * @returns {boolean}
 */
function isRetryableError(err) {
  if (!err) return false;

  // Network errors
  if (err.code === 'ECONNRESET' || err.code === 'ETIMEDOUT' || err.code === 'ENOTFOUND') {
    return true;
  }

  // HTTP status codes
  const status = err.status || err.statusCode || err.response?.status;
  if (status === 429) return true; // Rate limited
  if (status >= 500 && status < 600) return true; // Server error

  // Anthropic/OpenAI overloaded
  if (err.type === 'overloaded_error') return true;
  if (/overloaded|rate.?limit|too.?many.?requests|capacity/i.test(err.message || '')) {
    return true;
  }

  return false;
}

function _sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    if (signal) {
      const onAbort = () => {
        clearTimeout(timer);
        reject(new Error('Retry sleep aborted'));
      };
      signal.addEventListener('abort', onAbort, { once: true });
      // Clean up listener after sleep completes
      const origResolve = resolve;
      resolve = () => {
        signal.removeEventListener('abort', onAbort);
        origResolve();
      };
    }
  });
}

/**
 * Check if an error qualifies for persistent retry (capacity/rate errors).
 * @param {Error|object} err
 * @returns {boolean}
 */
function isPersistentRetryable(err) {
  if (!err) return false;
  const status = err.status || err.statusCode || err.response?.status;
  if (status === 429 || status === 529) return true;
  if (err.type === 'overloaded_error') return true;
  if (/overloaded|too.?many.?requests|capacity/i.test(err.message || '')) return true;
  return false;
}

/**
 * Persistent retry mode for CI/unattended environments.
 *
 * Unlike normal retry, this keeps retrying capacity errors (429/529) with
 * capped exponential backoff and periodic heartbeat output. Designed for
 * long-running CI jobs where dropping the request is worse than waiting.
 *
 * Enable via: KHY_UNATTENDED_RETRY=true environment variable.
 *
 * @param {function} fn - Async function to execute
 * @param {object} [opts]
 * @param {AbortSignal} [opts.signal]
 * @param {function} [opts.onHeartbeat] - (info) => void. Called every 30s during waits.
 * @param {function} [opts.onRetry] - (info) => void.
 * @param {string} [opts.label]
 * @returns {Promise<T>}
 */
async function persistentRetry(fn, opts = {}) {
  const { signal, onHeartbeat, onRetry, label } = opts;
  const startTime = Date.now();
  let attempt = 0;

  while (true) {
    if (signal?.aborted) {
      throw new Error(`Persistent retry aborted${label ? ` (${label})` : ''}`);
    }

    attempt++;
    try {
      return await fn(attempt);
    } catch (err) {
      // Only persist on capacity errors
      if (!isPersistentRetryable(err)) throw err;

      // Check absolute cap
      const elapsed = Date.now() - startTime;
      if (elapsed >= PERSISTENT_ABSOLUTE_CAP_MS) {
        throw new Error(
          `Persistent retry exceeded ${Math.round(PERSISTENT_ABSOLUTE_CAP_MS / 3600000)}h cap after ${attempt} attempts${label ? ` (${label})` : ''}: ${err.message}`
        );
      }

      // Calculate delay: exponential with cap
      const serverDelay = parseRetryAfter(err);
      let delayMs;
      if (serverDelay && serverDelay > 0) {
        delayMs = Math.min(serverDelay, PERSISTENT_MAX_BACKOFF_MS);
      } else {
        delayMs = Math.min(DEFAULT_MIN_DELAY * Math.pow(2, attempt - 1), PERSISTENT_MAX_BACKOFF_MS);
      }

      if (onRetry) {
        onRetry({ attempt, delayMs, err, label, persistent: true });
      }

      // Chunk long sleep into heartbeat intervals
      let slept = 0;
      while (slept < delayMs) {
        if (signal?.aborted) throw new Error('Persistent retry aborted during sleep');
        const chunk = Math.min(HEARTBEAT_INTERVAL_MS, delayMs - slept);
        await _sleep(chunk, signal);
        slept += chunk;
        if (onHeartbeat && slept < delayMs) {
          onHeartbeat({
            attempt,
            elapsed: Date.now() - startTime,
            remainingMs: delayMs - slept,
            label,
          });
        }
      }
    }
  }
}

/**
 * Check if persistent retry mode is enabled.
 * @returns {boolean}
 */
function isPersistentRetryEnabled() {
  const v = process.env.KHY_UNATTENDED_RETRY || '';
  return v === 'true' || v === '1';
}

module.exports = {
  retryWithBackoff,
  persistentRetry,
  isPersistentRetryEnabled,
  isPersistentRetryable,
  parseRetryAfter,
  isRetryableError,
  DEFAULT_ATTEMPTS,
  DEFAULT_MIN_DELAY,
  DEFAULT_MAX_DELAY,
  DEFAULT_JITTER,
  PERSISTENT_MAX_BACKOFF_MS,
  PERSISTENT_ABSOLUTE_CAP_MS,
  HEARTBEAT_INTERVAL_MS,
};
