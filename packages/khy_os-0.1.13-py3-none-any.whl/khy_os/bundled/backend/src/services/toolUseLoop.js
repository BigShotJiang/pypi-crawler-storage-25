/**
 * Tool-Use Loop — iterative AI ↔ tool execution cycle.
 *
 * Inspired by Claude Code's agentic loop:
 *   1. Send user message + tool definitions → AI
 *   2. Parse AI response for tool calls
 *   3. Execute tools (with permission checks)
 *   4. Append results to conversation, loop back to step 1
 *   5. When AI responds without tool calls → return final answer
 *
 * Safety: hard max-iterations limit, per-tool timeout, audit logging.
 * Feature flag: KHY_TOOL_LOOP=false disables this, falling back to legacy.
 */
const chalk = require('chalk').default || require('chalk');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { diagnostics, generateTraceId: genDiagTraceId } = require('./diagnosticEvents');
const { runWithConcurrency } = require('./concurrencyLimiter');
const { analyzeCommand } = require('./shellSafetyValidator');
const { normalizeToolCall } = require('./claudeCompat');
const { applyIntentGate } = require('./intentGate');

// Exec approval (multi-level permission, complements shellSafetyValidator)
let _execApproval;
try {
  const { execApproval } = require('./execApproval');
  _execApproval = execApproval;
} catch { _execApproval = null; }

// Hook system (lazy-loaded, auto-initializes with built-in ToolGuards)
let _hookSystem = undefined; // undefined = not yet loaded, null = unavailable
function _getHookSystem() {
  if (_hookSystem !== undefined) return _hookSystem;
  try {
    const hs = require('../cli/hooks/hookSystem');
    // Auto-initialize if not yet done (registers built-in guards)
    if (typeof hs.isInitialized === 'function' && !hs.isInitialized()) {
      hs.init(process.env.KHYQUANT_CWD || process.cwd());
    }
    // Return hookSystem if any hooks (including built-in guards) are registered
    _hookSystem = (hs.registry && hs.registry.count > 0) ? hs : null;
  } catch {
    _hookSystem = null;
  }
  return _hookSystem;
}

// ── Content-fingerprint guard (staleness detection for edits) ─────
function _fileContentHash(filePath) {
  try {
    const buf = Buffer.alloc(10240);
    const fd = fs.openSync(filePath, 'r');
    const bytesRead = fs.readSync(fd, buf, 0, 10240, 0);
    fs.closeSync(fd);
    return crypto.createHash('md5').update(buf.slice(0, bytesRead)).digest('hex');
  } catch { return null; }
}

// ── Constants ──────────────────────────────────────────────────────

const MAX_ITERATIONS = 25;
const MAX_ELAPSED_MS_DEFAULT = 300000;
const TOOL_CALL_REGEX = /<tool_call>\s*(\w+)\s*\(([^)]*)\)\s*<\/tool_call>/g;
const JSON_TOOL_CALL_REGEX = /<tool_call>\s*(\{[\s\S]*?\})\s*<\/tool_call>/g;
const NATURAL_ACTION_TO_TOOL = {
  // Search
  '搜索': 'web_search',
  'search': 'web_search',
  'websearch': 'web_search',
  'web_search': 'web_search',
  '查找': 'search',

  // Market quote
  '行情': 'quote',
  'quote': 'quote',
  '报价': 'quote',
  '价格': 'quote',

  // Backtest
  '回测': 'backtest',
  'backtest': 'backtest',

  // Build / Test / Lint / Verify
  '构建': 'build_project',
  'build': 'build_project',
  '编译': 'build_project',
  '测试': 'run_tests',
  'test': 'run_tests',
  'lint': 'lint_code',
  '检查': 'lint_code',
  '代码检查': 'lint_code',
  '验证': 'verify_artifact',
  'verify': 'verify_artifact',
  '交付验证': 'verify_artifact',

  // K-line / data fetch
  'k线': 'data_fetch',
  'K线': 'data_fetch',
  'kline': 'data_fetch',
  'k线查询': 'data_fetch',

  // Strategy list
  '策略列表': 'strategy_list',
  'strategylist': 'strategy_list',
  'strategy_list': 'strategy_list',

  // File operations
  '读取文件': 'read_file',
  '读文件': 'read_file',
  'readfile': 'read_file',
  'read_file': 'read_file',
  '写入文件': 'write_file',
  'writefile': 'write_file',
  'write_file': 'write_file',
  '创建项目': 'scaffoldFiles',
  '项目脚手架': 'scaffoldFiles',
  '脚手架': 'scaffoldFiles',
  '目录结构': 'scaffoldFiles',
  '批量创建': 'scaffoldFiles',
  '并行写入': 'scaffoldFiles',
  'scaffold': 'scaffoldFiles',
  'scaffold_files': 'scaffoldFiles',
  'project_scaffold': 'scaffoldFiles',

  // Shell
  '命令': 'shell_command',
  'shell': 'shell_command',
  'bash': 'shell_command',
  'shellcommand': 'shell_command',
  'shell_command': 'shell_command',

  // App launch
  '打开应用': 'open_app',
  '启动应用': 'open_app',
  '打开程序': 'open_app',
  'openapp': 'open_app',
  'open_app': 'open_app',
  '应用': 'open_app',
  '浏览器': 'open_app',

  // Git
  'git状态': 'git_status',
  'gitstatus': 'git_status',
  'git_status': 'git_status',
  'git差异': 'git_diff',
  'gitdiff': 'git_diff',
  'git_diff': 'git_diff',

  // Glob file search
  '文件搜索': 'glob',
  'glob': 'glob',
  'find': 'glob',
  'find_files': 'glob',

  // Grep content search
  '内容搜索': 'grep',
  'grep': 'grep',
  'rg': 'grep',
  'search_content': 'grep',

  // Edit file (precise replacement)
  '编辑': 'editFile',
  'edit': 'editFile',
  '修改文件': 'editFile',
  'edit_file': 'editFile',
  'replace': 'editFile',

  // Image -> Web restore
  '网页还原': 'image2web',
  '图转网页': 'image2web',
  '截图还原': 'image2web',
  '截图转网页': 'image2web',
  'image2web': 'image2web',
  'image_to_web': 'image2web',
  'screenshot_to_html': 'image2web',
};

function _normalizeToolKey(name = '') {
  return String(name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function _expandToolNameVariants(name = '') {
  const raw = String(name || '').trim();
  if (!raw) return [];
  const variants = new Set();
  const push = (value) => {
    const text = String(value || '').trim();
    if (!text) return;
    variants.add(text);
    variants.add(text.toLowerCase());
    variants.add(_normalizeToolKey(text));
  };

  push(raw);
  push(raw.replace(/[\s-]+/g, '_'));
  push(raw.replace(/([a-z])([A-Z])/g, '$1_$2').toLowerCase());
  push(raw.replace(/_([a-z])/g, (_, c) => c.toUpperCase()));

  try {
    const normalized = normalizeToolCall(raw, {});
    if (normalized?.name) push(normalized.name);
  } catch { /* best effort */ }

  return [...variants].filter(Boolean);
}

function _canonicalizeToolCall(call) {
  if (!call || call.legacy) return call;
  try {
    let rawName = String(call.name || '');
    let rawParams = call.params || {};
    const fnLike = rawName.match(/^([A-Za-z_][\w-]*)\s*\(([\s\S]*)\)$/);
    if (fnLike) {
      rawName = fnLike[1];
      const inlineArg = String(fnLike[2] || '').trim();
      if (inlineArg && Object.keys(rawParams).length === 0) {
        if (/^(shell_command|shellCommand|bash)$/i.test(rawName)) rawParams = { command: inlineArg };
        else if (/^(open_app|openApp)$/i.test(rawName)) rawParams = { name: inlineArg };
      }
    }
    const normalized = normalizeToolCall(rawName, rawParams);
    if (normalized && normalized.name) {
      return {
        ...call,
        name: normalized.name,
        params: normalized.params || {},
      };
    }
  } catch { /* keep original call */ }
  return call;
}

function _parsePositiveInt(value, fallback, min = 1, max = Number.MAX_SAFE_INTEGER) {
  const n = Number.parseInt(String(value || '').trim(), 10);
  if (!Number.isFinite(n) || n < min) return fallback;
  return Math.min(max, n);
}

function _resolveMaxIterations(requestedMaxIterations) {
  if (requestedMaxIterations !== undefined && requestedMaxIterations !== null) {
    return _parsePositiveInt(requestedMaxIterations, MAX_ITERATIONS, 1, 100);
  }
  return _parsePositiveInt(process.env.KHY_TOOL_LOOP_MAX_ITERATIONS, MAX_ITERATIONS, 1, 100);
}

function _resolveMaxElapsedMs() {
  const base = _parsePositiveInt(
    process.env.KHY_TOOL_LOOP_MAX_MS,
    MAX_ELAPSED_MS_DEFAULT,
    5000,
    30 * 60 * 1000,
  );
  // Apply global timeout multiplier
  try {
    const { applyMultiplier } = require('./adaptiveOutput');
    return applyMultiplier(base);
  } catch {
    return base;
  }
}

function _resolveTaskScale(userMessage = '', options = {}) {
  const explicit = String(options.taskScale || '').trim().toLowerCase();
  if (explicit === 'small' || explicit === 'normal' || explicit === 'large') return explicit;
  const text = String(userMessage || '');
  const largeHint = /大型任务|大任务|完整实现|全量|全流程|端到端|深度|深入|deep|exhaustive|end-to-end|full implementation/i.test(text);
  if (largeHint || text.length >= 700 || (text.length >= 450 && /\n/.test(text))) return 'large';
  if (text.length <= 120 && !/\n/.test(text)) return 'small';
  return 'normal';
}

function _isTransientLoopErrorType(errorType = '') {
  const t = String(errorType || '').trim().toLowerCase();
  return t === 'timeout'
    || t === 'cancelled'
    || t === 'network'
    || t === 'process'
    || t === 'unknown';
}

/**
 * Check if an AI result represents a cooldown/cached failure that should NOT
 * be retried.  Gateway returns these when an adapter's recent failure is still
 * within its cooldown window — retrying immediately will produce the exact
 * same cached error, wasting iterations.
 */
function _isCooldownFailure(aiResult) {
  if (!aiResult) return false;
  const content = String(aiResult.content || '');
  const error = String(aiResult.error || '');
  const combined = content + ' ' + error;
  return /\bcooldown\b/i.test(combined) || /recent.*failure.*cached/i.test(combined);
}

function _resolveTransientRecoveryMax(userMessage = '', options = {}) {
  const explicit = parseInt(String(options.maxTransientRecoveries ?? ''), 10);
  if (Number.isFinite(explicit)) return Math.max(0, Math.min(6, explicit));
  const scale = _resolveTaskScale(userMessage, options);
  if (scale === 'small') {
    const n = parseInt(String(process.env.KHY_TOOL_LOOP_TRANSIENT_RECOVERIES_SMALL || '0'), 10);
    return Number.isFinite(n) ? Math.max(0, Math.min(3, n)) : 0;
  }
  if (scale === 'large') {
    const n = parseInt(String(process.env.KHY_TOOL_LOOP_TRANSIENT_RECOVERIES_LARGE || '3'), 10);
    return Number.isFinite(n) ? Math.max(0, Math.min(6, n)) : 3;
  }
  const n = parseInt(String(process.env.KHY_TOOL_LOOP_TRANSIENT_RECOVERIES || '1'), 10);
  return Number.isFinite(n) ? Math.max(0, Math.min(4, n)) : 1;
}

function _recoveryDelayMs(attemptIndex = 0) {
  const base = Math.max(300, parseInt(String(process.env.KHY_TOOL_LOOP_RECOVERY_DELAY_MS || '1200'), 10) || 1200);
  const exp = Math.min(4, Math.max(0, attemptIndex));
  const jitter = Math.random() * 300;
  return Math.round(base * Math.pow(1.65, exp) + jitter);
}

function _formatDurationMs(ms) {
  const totalSec = Math.max(1, Math.ceil(Number(ms || 0) / 1000));
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  if (m > 0 && s > 0) return `${m}m ${s}s`;
  if (m > 0) return `${m}m`;
  return `${s}s`;
}

function _envFlagEnabled(rawValue, defaultValue = true) {
  if (rawValue === undefined || rawValue === null || String(rawValue).trim() === '') return defaultValue;
  const normalized = String(rawValue).trim().toLowerCase();
  if (['1', 'true', 'on', 'yes', 'y'].includes(normalized)) return true;
  if (['0', 'false', 'off', 'no', 'n'].includes(normalized)) return false;
  return defaultValue;
}

const DEFAULT_CAPABILITY_POLICY = Object.freeze({
  enabled: true,
  blockMode: 'strict',
  tasks: [
    {
      key: 'file_edit',
      patterns: [
        '修改', '编辑', '重构', '实现', '修复', '新增', '添加', '删除', '替换', '写入', '创建文件',
        'apply patch', 'edit file', 'write file', 'refactor', 'implement', 'fix', 'update', 'replace', 'remove', 'delete',
      ],
      requiredTools: ['editFile', 'writeFile', 'shellCommand', 'file_edit', 'file_write'],
      reason: '当前环境缺少文件编辑/写入能力（edit/write/shell 工具不可用）。',
    },
    {
      key: 'shell_exec',
      patterns: [
        '运行命令', '执行命令', '终端', 'shell', 'bash', 'cmd', '运行测试', '构建', '编译', '安装依赖',
        'npm', 'pnpm', 'yarn', 'pytest', 'cargo', 'go test', 'make', 'docker', 'kubectl',
      ],
      requiredTools: ['shellCommand', 'run_tests', 'build_project', 'lint_code', 'executeCode'],
      reason: '当前环境缺少命令执行能力（shell/build/test 工具不可用）。',
    },
    {
      key: 'web_search',
      patterns: ['联网', '上网', '互联网', 'web search', '网页搜索', '搜索网页', '查网页', 'fetch url', '访问网站', 'browser search'],
      requiredTools: ['webSearch', 'webFetch', 'search'],
      reason: '当前环境缺少联网检索能力（webSearch/webFetch 不可用）。',
    },
    {
      key: 'app_launch',
      patterns: ['打开应用', '启动应用', '打开程序', '打开浏览器', 'open app', 'launch app', 'start app', 'open browser'],
      requiredTools: ['open_app', 'shellCommand'],
      reason: '当前环境缺少应用启动能力（open_app/shell 工具不可用）。',
    },
  ],
  model: {
    enabled: true,
    ignoreIssuePatterns: ['上下文可能不够'],
    blockWhenHardIssueCountAtLeast: 2,
    blockWhenComplexAndHardIssueCountAtLeast: 1,
    complexMinChars: 160,
    maxRecommendations: 3,
  },
});

function _cloneCapabilityTasks(tasks = []) {
  if (!Array.isArray(tasks)) return [];
  return tasks
    .filter(task => task && typeof task === 'object')
    .map(task => ({
      ...task,
      patterns: Array.isArray(task.patterns) ? [...task.patterns] : [],
      requiredTools: Array.isArray(task.requiredTools) ? [...task.requiredTools] : [],
    }));
}

function _mergeCapabilityPolicy(basePolicy = {}, overridePolicy = {}) {
  const baseModel = basePolicy && typeof basePolicy.model === 'object' ? basePolicy.model : {};
  const overrideModel = overridePolicy && typeof overridePolicy.model === 'object' ? overridePolicy.model : {};
  return {
    ...basePolicy,
    ...(overridePolicy || {}),
    tasks: Array.isArray(overridePolicy?.tasks)
      ? _cloneCapabilityTasks(overridePolicy.tasks)
      : _cloneCapabilityTasks(basePolicy.tasks || []),
    model: {
      ...baseModel,
      ...overrideModel,
    },
  };
}

function _defaultCapabilityPolicyPath() {
  const home = String(process.env.HOME || process.env.USERPROFILE || '').trim();
  if (!home) return '';
  return path.join(home, '.khyquant', 'capability-policy.json');
}

function _loadCapabilityPolicy(options = {}) {
  let policy = _mergeCapabilityPolicy(DEFAULT_CAPABILITY_POLICY, {});

  if (options && options.capabilityPolicy && typeof options.capabilityPolicy === 'object') {
    policy = _mergeCapabilityPolicy(policy, options.capabilityPolicy);
  }

  const envPolicyJson = String(process.env.KHY_CAPABILITY_POLICY_JSON || '').trim();
  if (envPolicyJson) {
    try {
      const parsed = JSON.parse(envPolicyJson);
      if (parsed && typeof parsed === 'object') {
        policy = _mergeCapabilityPolicy(policy, parsed);
      }
    } catch { /* ignore malformed JSON */ }
  }

  const policyPath = String(
    options.capabilityPolicyFile
      || process.env.KHY_CAPABILITY_POLICY_FILE
      || _defaultCapabilityPolicyPath()
  ).trim();
  if (policyPath && fs.existsSync(policyPath)) {
    try {
      const parsed = JSON.parse(String(fs.readFileSync(policyPath, 'utf-8') || '{}'));
      if (parsed && typeof parsed === 'object') {
        policy = _mergeCapabilityPolicy(policy, parsed);
      }
    } catch { /* ignore malformed file */ }
  }

  return policy;
}

function _collectEnabledToolNameSet() {
  const out = new Set();
  const registerName = (name) => {
    for (const v of _expandToolNameVariants(name)) out.add(v);
  };

  try {
    const toolRegistry = require('../tools');
    const enabled = toolRegistry.getEnabled ? toolRegistry.getEnabled() : toolRegistry.getAll?.();
    if (!enabled) return out;

    const names = enabled instanceof Map ? [...enabled.keys()] : Object.keys(enabled);
    for (const name of names) registerName(name);

    const defs = enabled instanceof Map ? [...enabled.values()] : Object.values(enabled);
    for (const tool of defs) {
      if (Array.isArray(tool?.aliases)) {
        for (const alias of tool.aliases) registerName(alias);
      }
    }
  } catch { /* best effort */ }

  return out;
}

function _hasAnyToolEnabled(enabledToolSet, candidates = []) {
  if (!(enabledToolSet instanceof Set) || enabledToolSet.size === 0) return false;
  for (const name of candidates) {
    const variants = _expandToolNameVariants(name);
    for (const variant of variants) {
      if (enabledToolSet.has(variant)) return true;
    }
  }
  return false;
}

function _containsPattern(text, pattern) {
  const haystack = String(text || '');
  if (pattern instanceof RegExp) return pattern.test(haystack);
  const raw = String(pattern || '').trim();
  if (!raw) return false;
  if (raw.startsWith('re:')) {
    try {
      return new RegExp(raw.slice(3), 'i').test(haystack);
    } catch {
      return haystack.toLowerCase().includes(raw.slice(3).toLowerCase());
    }
  }
  return haystack.toLowerCase().includes(raw.toLowerCase());
}

function _detectCapabilityNeeds(message = '', policy = DEFAULT_CAPABILITY_POLICY) {
  const text = String(message || '');
  if (!text) return [];
  const tasks = Array.isArray(policy?.tasks) ? policy.tasks : [];
  const hits = [];
  for (const task of tasks) {
    if (!task || typeof task !== 'object') continue;
    const patterns = Array.isArray(task.patterns) ? task.patterns : [];
    if (patterns.some(pattern => _containsPattern(text, pattern))) {
      hits.push(task);
    }
  }
  return hits;
}

function _dedupeText(items = []) {
  const seen = new Set();
  const out = [];
  for (const item of items) {
    const normalized = String(item || '').trim();
    if (!normalized || seen.has(normalized)) continue;
    seen.add(normalized);
    out.push(normalized);
  }
  return out;
}

function _assessExecutionCapability(userMessage, options = {}) {
  const policy = _loadCapabilityPolicy(options);
  const gateEnabled = _envFlagEnabled(options.capabilityGate, _envFlagEnabled(process.env.KHY_TASK_CAPABILITY_GATE, true));
  const enabled = gateEnabled && _envFlagEnabled(policy.enabled, true);
  const mode = String(policy.blockMode || 'strict').trim().toLowerCase();
  const assessment = {
    enabled,
    mode: (mode === 'warn' || mode === 'warning' || mode === 'warn-only') ? 'warn' : 'strict',
    canProceed: true,
    reasons: [],
    warnings: [],
    recommendations: [],
  };
  if (!enabled) return assessment;

  const text = String(userMessage || '').trim();
  if (!text) return assessment;

  const needs = _detectCapabilityNeeds(text, policy);
  const enabledToolSet = _collectEnabledToolNameSet();
  for (const need of needs) {
    const requiredTools = Array.isArray(need?.requiredTools) ? need.requiredTools : [];
    if (requiredTools.length === 0) continue;
    const hasTool = _hasAnyToolEnabled(enabledToolSet, requiredTools);
    if (!hasTool) {
      assessment.reasons.push(
        String(need.reason || `当前环境缺少执行能力：${need.key || 'unknown-task'}`).trim(),
      );
    }
  }

  try {
    const aiEntry = require('../cli/ai');
    if (aiEntry && typeof aiEntry.checkModelCapability === 'function') {
      const modelCheck = aiEntry.checkModelCapability(text);
      if (modelCheck && Array.isArray(modelCheck.issues) && modelCheck.issues.length > 0) {
        const modelCfg = (policy && typeof policy.model === 'object') ? policy.model : {};
        if (_envFlagEnabled(modelCfg.enabled, true)) {
          const ignoreList = Array.isArray(modelCfg.ignoreIssuePatterns) ? modelCfg.ignoreIssuePatterns : [];
          const hardIssues = modelCheck.issues.filter((issue) => {
            const textIssue = String(issue || '');
            return !ignoreList.some(p => _containsPattern(textIssue, p));
          });
        const complexOrAction = _isComplexTask(text) || _looksLikeActionRequest(text);
          const hardIssueMin = Math.max(1, parseInt(String(modelCfg.blockWhenHardIssueCountAtLeast ?? '2'), 10) || 2);
          const complexHardIssueMin = Math.max(1, parseInt(String(modelCfg.blockWhenComplexAndHardIssueCountAtLeast ?? '1'), 10) || 1);
          const complexMinChars = Math.max(20, parseInt(String(modelCfg.complexMinChars ?? '160'), 10) || 160);
          const shouldBlockByModel = hardIssues.length >= hardIssueMin
            || (hardIssues.length >= complexHardIssueMin && complexOrAction && text.length >= complexMinChars);

          if (shouldBlockByModel) {
            assessment.reasons.push(`模型能力预判不足：${hardIssues.join('；')}`);
          } else if (modelCheck.issues.length > 0) {
            assessment.warnings.push(`模型能力提醒：${modelCheck.issues.join('；')}`);
          }

          if (Array.isArray(modelCheck.recommendations) && modelCheck.recommendations.length > 0) {
            const labels = modelCheck.recommendations
              .map((item) => String(item?.label || item?.key || '').trim())
              .filter(Boolean);
            assessment.recommendations.push(...labels);
          }
        }
      }
    }
  } catch { /* best effort */ }

  const modelCfg = (policy && typeof policy.model === 'object') ? policy.model : {};
  const maxRecommendations = Math.max(1, parseInt(String(modelCfg.maxRecommendations ?? '3'), 10) || 3);
  assessment.reasons = _dedupeText(assessment.reasons);
  assessment.warnings = _dedupeText(assessment.warnings);
  assessment.recommendations = _dedupeText(assessment.recommendations).slice(0, maxRecommendations);

  if (assessment.mode === 'warn' && assessment.reasons.length > 0) {
    assessment.warnings.push(...assessment.reasons.map(reason => `预判阻断已降级为告警：${reason}`));
    assessment.reasons = [];
    assessment.warnings = _dedupeText(assessment.warnings);
  }

  assessment.canProceed = assessment.reasons.length === 0;
  return assessment;
}

function _formatCapabilityFailureResponse(assessment) {
  const reasons = Array.isArray(assessment?.reasons) ? assessment.reasons : [];
  const lines = [
    '抱歉，执行前能力预判未通过，当前无法可靠完成该任务。',
  ];
  for (let i = 0; i < reasons.length; i++) {
    lines.push(`${i + 1}. ${reasons[i]}`);
  }
  if (Array.isArray(assessment?.recommendations) && assessment.recommendations.length > 0) {
    lines.push(`建议切换模型后重试：${assessment.recommendations.join('、')}`);
  }
  lines.push('你可以把任务拆小、补充更具体上下文，或明确可用工具后再试。');
  return lines.join('\n');
}

function _extractDecisionPreview(reply = '') {
  const plain = _stripToolCalls(_stripExecutionPlan(String(reply || '')))
    .replace(/\s+/g, ' ')
    .trim();
  if (!plain) return '';

  const sentence = plain
    .split(/[\n。！？.!?]/)
    .map(s => s.trim())
    .find(Boolean) || plain;

  return sentence.slice(0, 160);
}

function _normalizeToolNameForDisplay(name = '') {
  const raw = String(name || '').trim();
  if (!raw) return '';
  if (raw === '_legacy_cmd') return 'command';
  return raw
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    .replace(/_/g, '-')
    .toLowerCase();
}

function _buildPlannedToolList(toolCalls = [], maxItems = 6) {
  const names = [];
  const seen = new Set();
  for (const call of toolCalls) {
    const normalized = _normalizeToolNameForDisplay(call?.name);
    if (!normalized || seen.has(normalized)) continue;
    seen.add(normalized);
    names.push(normalized);
    if (names.length >= maxItems) break;
  }
  return names;
}

function _resolveAutoWebSearchMode(userMessage, requestedMode = 'auto') {
  const normalizedRequested = String(requestedMode || 'auto').trim().toLowerCase();
  const allowed = new Set(['auto', 'news', 'docs', 'academic', 'general']);
  const safeRequested = allowed.has(normalizedRequested) ? normalizedRequested : 'auto';
  if (safeRequested !== 'auto') return safeRequested;

  const raw = _sanitizeSearchSourceMessage(String(userMessage || ''));
  if (!raw) return 'general';

  if (/(论文|paper|arxiv|doi|research|study|benchmark|dataset|citation|methodology|survey)/i.test(raw)) {
    return 'academic';
  }
  if (/(文档|docs?|documentation|api|sdk|readme|manual|reference|接口|参数|安装|install|quickstart|error\s*code)/i.test(raw)) {
    return 'docs';
  }
  if (/(新闻|热点|热搜|头条|快讯|今日|今天|最新|时事|发布|trending|headline|breaking|latest\s+news)/i.test(raw)) {
    return 'news';
  }
  return 'general';
}

// ── Main Loop ──────────────────────────────────────────────────────

/**
 * Run an iterative tool-use loop: AI generates tool calls, system executes
 * them, feeds results back, and AI continues until it has a final answer.
 *
 * @param {string} userMessage - The user's original message
 * @param {object} options
 * @param {function} options.chat - AI chat function (message, opts) => { reply, ... }
 * @param {object} [options.chatOpts] - Options passed through to chat()
 * @param {number} [options.maxIterations] - Safety limit on loop iterations (fallback: KHY_TOOL_LOOP_MAX_ITERATIONS or 10)
 * @param {function} [options.onToolCall] - Callback before tool execution: (toolName, params, iteration)
 * @param {function} [options.onToolResult] - Callback after tool execution: (toolName, params, result, iteration, elapsedMs)
 * @param {function} [options.onIteration] - Callback at each iteration start: (iteration, totalCalls)
 * @param {function} [options.onPlanReady] - Callback when execution plan is parsed: (plan)
 * @param {function} [options.onPlanProgress] - Callback as plan steps progress: (stepIndex, status)
 * @param {function} [options.onParallelBatch] - Callback before a parallel batch runs: (calls, iteration)
 * @param {function} [options.onNoToolCall] - Callback when an iteration returns no tool calls: (iteration, reply, info)
 * @param {function} [options.onCapabilityCheck] - Callback when execution capability is assessed: (assessment)
 * @param {function} [options.onDecision] - Callback when each round decision is made: ({ iteration, mode, preview, toolCount, tools })
 * @param {function} [options.onIterationSummary] - Callback after each round tools finish: ({ iteration, total, succeeded, failed, denied, deduped, readOnlyOnly })
 * @returns {Promise<{ finalResponse: string, toolCallLog: Array, iterations: number, provider?: string }>}
 */
async function runToolUseLoop(userMessage, options = {}) {
  const {
    chat,
    chatOpts = {},
    maxIterations: requestedMaxIterations,
    sessionId: requestedSessionId,
    onToolCall,
    onToolResult,
    onIteration,
    onPlanReady,
    onPlanProgress,
    onParallelBatch,
    onNoToolCall,
    onCapabilityCheck,
    onDecision,
    onIterationSummary,
    onCheckpoint,
  } = options;

  if (!chat || typeof chat !== 'function') {
    throw new Error('toolUseLoop: chat function is required');
  }

  const originalUserMessage = String(userMessage || '');
  const gatedInput = applyIntentGate(originalUserMessage, options.intentGate || {});

  let traceAudit = null;
  try {
    traceAudit = require('./traceAuditService');
    traceAudit.ensureDiagnosticsBridge();
  } catch { /* optional */ }
  const diagTraceId = options?._diagTraceId || genDiagTraceId();
  const traceSessionId = requestedSessionId || traceAudit?.getContext?.()?.sessionId || null;
  if (options && typeof options === 'object') {
    options._diagTraceId = diagTraceId;
  }
  if (traceAudit && traceSessionId) {
    try {
      traceAudit.attachTrace(diagTraceId, traceSessionId);
      traceAudit.logEvent('agent.loop.start', {
        maxIterations: _resolveMaxIterations(requestedMaxIterations),
        messagePreview: originalUserMessage.slice(0, 600),
        activatedModes: gatedInput.activatedModes || [],
      }, {
        sessionId: traceSessionId,
        traceId: diagTraceId,
        source: 'tool-loop',
        visibility: 'summary',
      });
    } catch { /* non-critical */ }
  }

  const toolCallLog = [];
  let currentMessage = gatedInput.message;
  let lastResult = null;
  let totalToolCalls = 0;
  let preflightApproved = null; // Set<string> of batch-approved tool names
  let executionPlan = null;     // Parsed execution plan { steps: [...] }
  let currentPlanStep = 0;
  let noToolNudgeUsed = false;
  const resolvedMaxIterations = _resolveMaxIterations(requestedMaxIterations);
  const transientRecoveryMax = _resolveTransientRecoveryMax(originalUserMessage, options);
  const effectiveMaxIterations = Math.min(160, resolvedMaxIterations + transientRecoveryMax);
  const maxElapsedMs = _resolveMaxElapsedMs();
  let transientRecoveryUsed = 0;

  // Dedup: track ALL tool calls (both success and failure) to avoid re-executing
  // identical calls. Previously only tracked failures, which allowed the AI to
  // call the same successful command (e.g. `tree /f .`) 10 times in a loop.
  const executedCallKeys = new Map(); // key -> { result, count }
  const fileReadHashes = new Map();   // absolutePath -> md5(first 10KB) for staleness detection
  let consecutiveDedupIterations = 0; // track consecutive all-deduped rounds

  // Phase 2: 5-detector loop detection (replaces simple dedup for advanced checks)
  let loopDetector;
  try {
    const { ToolLoopDetector } = require('./toolLoopDetector');
    loopDetector = new ToolLoopDetector();
    // Register known tools for unknown-tool detection
    try {
      const toolRegistry = require('../tools');
      const allTools = toolRegistry.getEnabled ? toolRegistry.getEnabled() : toolRegistry.getAll();
      if (allTools) {
        const knownNameSet = new Set();
        const registerName = (name) => {
          for (const v of _expandToolNameVariants(name)) knownNameSet.add(v);
        };
        const names = allTools instanceof Map ? [...allTools.keys()] : Object.keys(allTools);
        for (const name of names) registerName(name);
        // Also register aliases so snake_case/camelCase variants are recognized
        for (const tool of (allTools instanceof Map ? allTools.values() : Object.values(allTools))) {
          if (tool.aliases && Array.isArray(tool.aliases)) {
            for (const alias of tool.aliases) registerName(alias);
          }
        }
        // Register common natural-language mappings to avoid false unknown-tool loops.
        for (const mappedName of Object.values(NATURAL_ACTION_TO_TOOL)) registerName(mappedName);
        for (const common of ['shellCommand', 'shell_command', 'bash', 'writeFile', 'write_file', 'readFile', 'read_file', 'editFile', 'edit_file', 'open_app', 'openApp']) {
          registerName(common);
        }
        loopDetector.registerTools([...knownNameSet]);
      }
    } catch { /* registry not available, skip unknown-tool detection */ }
  } catch { loopDetector = null; /* toolLoopDetector not available */ }

  const capabilityAssessment = _assessExecutionCapability(originalUserMessage, options);
  if (typeof onCapabilityCheck === 'function') {
    try { onCapabilityCheck(capabilityAssessment); } catch { /* non-critical */ }
  }
  if (!capabilityAssessment.canProceed) {
    return {
      finalResponse: _formatCapabilityFailureResponse(capabilityAssessment),
      toolCallLog,
      iterations: 0,
      stopped: true,
      capabilityAssessment,
      errorType: 'capability',
    };
  }

  const transparencyEnabled = _envFlagEnabled(
    options.transparency,
    _envFlagEnabled(process.env.KHY_TOOL_LOOP_TRANSPARENCY, true),
  );
  const effectiveChatOpts = {
    ...((chatOpts && typeof chatOpts === 'object') ? chatOpts : {}),
  };
  // In loop mode, intermediate replies often include short prefaces before
  // <tool_call>. Suppress those prefaces when a tool call is detected to
  // avoid duplicated/half-cut narration in terminal output.
  if (effectiveChatOpts.suppressPrefixOnToolCall === undefined) {
    effectiveChatOpts.suppressPrefixOnToolCall = _envFlagEnabled(
      process.env.KHY_TOOL_LOOP_SUPPRESS_TOOL_PREFACE,
      true
    );
  }
  const intentForceOverride = _envFlagEnabled(
    options?.intentGate?.forceOverride,
    _envFlagEnabled(process.env.KHY_ULTRAWORK_FORCE_OVERRIDE, false),
  );
  const gatePatch = (gatedInput && typeof gatedInput.chatOptsPatch === 'object')
    ? gatedInput.chatOptsPatch
    : {};
  for (const [key, value] of Object.entries(gatePatch)) {
    if (value === undefined || value === null || value === '') continue;
    const existing = effectiveChatOpts[key];
    const canSet = intentForceOverride || existing === undefined || existing === null || existing === '';
    if (canSet) effectiveChatOpts[key] = value;
  }
  // Pass intentGate directive to chat layer for system prompt injection
  if (gatedInput.systemDirective) {
    effectiveChatOpts._intentDirective = gatedInput.systemDirective;
  }
  const emitDecision = (payload) => {
    if (!transparencyEnabled || typeof onDecision !== 'function') return;
    try { onDecision(payload); } catch { /* non-critical */ }
  };
  const emitIterationSummary = (payload) => {
    if (!transparencyEnabled || typeof onIterationSummary !== 'function') return;
    try { onIterationSummary(payload); } catch { /* non-critical */ }
  };

  // Inject planning prompt for complex tasks
  const isComplex = _isComplexTask(originalUserMessage);
  if (isComplex && process.env.KHY_TASK_PLAN !== 'false') {
    currentMessage = _injectPlanningPrompt(currentMessage);
  }
  if (Array.isArray(capabilityAssessment.warnings) && capabilityAssessment.warnings.length > 0) {
    const warningText = capabilityAssessment.warnings.join('；').slice(0, 240);
    currentMessage += `\n\n[SYSTEM: Capability precheck note: ${warningText}. Continue execution only when feasible. If blocked, explain why clearly.]`;
  }
  if (_looksLikeAppLaunchRequest(originalUserMessage)) {
    currentMessage += '\n\n[SYSTEM: For app launch tasks, use the open_app tool first. Avoid shell probing commands like which/ps/nohup/grep unless open_app has already failed and you explain that failure.]';
  }

  // Guardrails: idle timeout (activity-aware), read-only cap, and consecutive failure cap
  // These thresholds adapt based on task complexity instead of being fixed
  const loopStartTime = Date.now();
  let lastActivityTime = Date.now(); // Reset on each productive iteration
  let lastCheckpointTime = Date.now(); // For onCheckpoint throttling
  const IDLE_TIMEOUT_MS = maxElapsedMs; // Reuse config value as idle timeout, not hard wall
  const MAX_READ_ONLY_ITERATIONS = isComplex ? 8 : 5;
  const MAX_CONSECUTIVE_FAILURES = isComplex ? 5 : 3;
  const MAX_WEB_LOOKUP_FAILURES = 2;
  let consecutiveReadOnlyIterations = 0;
  let consecutiveFailureIterations = 0;
  let consecutiveWebLookupFailureIterations = 0;

  // ── Crash recovery: inject prior canonical state if available ──────
  try {
    const _canonicalState = require('./canonicalState');
    const sessionId = requestedSessionId || 'default';
    const recovered = _canonicalState.load(sessionId);
    if (recovered && recovered.goal && (Date.now() - (recovered.timestamp || 0)) < 3600_000) {
      const recoveryPrompt = _canonicalState.formatAsPrompt(recovered);
      if (recoveryPrompt) {
        currentMessage = `[SYSTEM: Recovered context from prior session]\n${recoveryPrompt}\n\n---\n\n${currentMessage}`;
      }
    }
  } catch { /* canonical state recovery is best-effort */ }

  try {

  for (let iteration = 1; iteration <= effectiveMaxIterations; iteration++) {
    if (onIteration) onIteration(iteration, totalToolCalls);

    // Idle guardrail: only timeout when no productive activity for IDLE_TIMEOUT_MS.
    // Active tool execution resets the timer, so long-running tasks don't get killed.
    const idleMs = Date.now() - lastActivityTime;
    if (idleMs > IDLE_TIMEOUT_MS) {
      const limitText = _formatDurationMs(IDLE_TIMEOUT_MS);
      const collected = _stripToolCalls(_stripExecutionPlan(lastResult?.reply || ''));
      const hasSubstantiveContent = collected.length > 80;
      const timeWarning = hasSubstantiveContent
        ? `\n\n${chalk.yellow(`⚠ AI 已 ${limitText} 无新进展，返回已收集到的信息。如需继续请重新发送请求。`)}`
        : `\n\n${chalk.yellow(`⚠ 抱歉，AI 在 ${limitText} 内未能取得进展。`)}` +
          `\n${chalk.dim('建议：1) 将问题拆分为更小的步骤  2) 提供更具体的上下文  3) 尝试换一种问法')}`;
      return {
        finalResponse: (hasSubstantiveContent ? collected : '很抱歉，处理过程中未能取得进展。') + timeWarning,
        toolCallLog,
        iterations: iteration - 1,
        provider: lastResult?.provider,
        timeLimitReached: true,
        maxElapsedMs: IDLE_TIMEOUT_MS,
      };
    }

    // Read-only guardrail: if AI keeps reading without acting, nudge it forward
    // Use a gentler, more context-aware prompt instead of demanding immediate stop
    if (consecutiveReadOnlyIterations >= MAX_READ_ONLY_ITERATIONS) {
      currentMessage += '\n\n[SYSTEM: You have read quite a few files now. You likely have enough context. Time to act — start making changes, running commands, or give your answer. If you genuinely need to read more, explain why in one sentence first.]';
      consecutiveReadOnlyIterations = 0;
    }

    // ── Capacity Checkpoint 1: Pre-Request ────────────────────────────
    // Evaluate context pressure before API call. If crowded, trim.
    // Also run seam manager to archive old context if thresholds are hit.
    try {
      const _capacityFlow = require('./capacityFlow');
      const _estimateTokensFn = (text) => Math.ceil((text || '').length / 4);
      const _usedTokens = conversationMessages.reduce(
        (sum, m) => sum + _estimateTokensFn(typeof m.content === 'string' ? m.content : JSON.stringify(m.content || '')),
        0
      );
      const _contextWindow = effectiveChatOpts?.contextWindowTokens || parseInt(process.env.KHY_CONTEXT_WINDOW, 10) || 128000;

      // Seam manager: append-only archiving at graduated thresholds
      try {
        const _seamMgr = require('./seamManager');
        const seamResult = await _seamMgr.checkAndApply(conversationMessages, _usedTokens);
        if (seamResult.applied) {
          conversationMessages = seamResult.messages;
        }
      } catch { /* seam is best-effort */ }

      const preCheck = _capacityFlow.preRequestCheckpoint({
        usedTokens: _usedTokens,
        contextWindow: _contextWindow,
        messages: conversationMessages,
      });
      if (preCheck.decision !== _capacityFlow.CapacityDecision.None) {
        conversationMessages = _capacityFlow.applyDecision(
          preCheck.decision,
          conversationMessages,
          { estimateTokens: _estimateTokensFn, contextWindow: _contextWindow }
        );
      }
      // Drive coherence state machine from checkpoint result
      try {
        const { getCoherenceState } = require('./coherenceState');
        const csm = getCoherenceState();
        csm.transition(preCheck);
        if (preCheck.decision !== _capacityFlow.CapacityDecision.None) {
          csm.completeOperation(); // refresh was applied inline
        }
      } catch { /* coherence tracking is optional */ }
    } catch { /* capacity flow is best-effort, never blocks the loop */ }

    // 1. Send to AI
    // Hook: PrePrompt — allow hooks to modify prompt or block
    const hookSys = _getHookSystem();
    if (hookSys) {
      try {
        const promptHr = await hookSys.trigger('PrePrompt', { prompt: currentMessage, iteration });
        if (promptHr.blocked) break;
        if (promptHr.context?.prompt) currentMessage = promptHr.context.prompt;
      } catch { /* hook failure should not block AI pipeline */ }
    }

    // Auto-reasoning: resolve effort tier from user message keywords
    // Only on first iteration (the original user message); follow-ups keep same tier.
    if (iteration === 1 && effectiveChatOpts.reasoning_effort === 'auto') {
      try {
        const _autoReasoning = require('./autoReasoning');
        const tier = _autoReasoning.resolveEffort(currentMessage, {
          isSubagent: !!effectiveChatOpts._isSubagent,
        });
        const provider = effectiveChatOpts.provider || effectiveChatOpts.adapter || 'anthropic';
        const reasoningParams = _autoReasoning.effortToParams(tier, provider);
        Object.assign(effectiveChatOpts, reasoningParams);
      } catch { /* auto-reasoning is best-effort */ }
    }

    const aiResult = await chat(currentMessage, {
      ...effectiveChatOpts,
      _isFollowUp: iteration > 1,
    });

    // Activity: AI responded (even if error, the channel is alive)
    lastActivityTime = Date.now();

    if (aiResult && aiResult.errorType) {
      // Cooldown failures are deterministic — retrying immediately will hit
      // the same cached error.  Skip transient recovery and fail fast.
      const cooldown = _isCooldownFailure(aiResult);
      const transient = !cooldown && _isTransientLoopErrorType(aiResult.errorType);
      if (transient && transientRecoveryUsed < transientRecoveryMax) {
        const attemptIdx = transientRecoveryUsed;
        transientRecoveryUsed++;
        const delayMs = _recoveryDelayMs(attemptIdx);
        try {
          if (traceAudit) {
            traceAudit.logEvent('agent.loop.resume', {
              reason: aiResult.errorType,
              attempt: transientRecoveryUsed,
              maxAttempts: transientRecoveryMax,
              delayMs,
              iteration,
            }, {
              sessionId: traceSessionId,
              traceId: diagTraceId,
              source: 'tool-loop',
              visibility: 'summary',
            });
          }
        } catch { /* non-critical */ }
        currentMessage += '\n\n[SYSTEM: Previous round failed due transient channel interruption. Resume from completed progress. Do NOT repeat successful tool calls. Continue execution.]';
        await new Promise((r) => setTimeout(r, delayMs));
        continue;
      }
      const appLaunchFallback = await _recoverOpenAppAfterAiInterruption(
        aiResult,
        userMessage,
        toolCallLog,
        { sessionId: traceSessionId, traceId: diagTraceId }
      );
      if (appLaunchFallback) {
        return {
          finalResponse: appLaunchFallback,
          toolCallLog,
          iterations: iteration,
          provider: aiResult.provider,
          tokenUsage: aiResult.tokenUsage,
          effort: aiResult.effort,
          errorType: aiResult.errorType,
          stopped: true,
          recoveredFromInterruptedChannel: true,
        };
      }
      const totalExecuted = toolCallLog.length;
      const succeededExecuted = toolCallLog.filter(item => item && item.result && item.result.success).length;
      const progressSummary = totalExecuted > 0
        ? `已完成 ${succeededExecuted}/${totalExecuted} 个工具步骤。`
        : '本轮尚未完成可确认的执行步骤。';
      const errorMessages = {
        timeout: `抱歉，AI 在执行过程中超时，当前任务未完成，已停止本次请求。${progressSummary}你可以稍后重试，或将任务拆分后继续。`,
        network: '抱歉，网络连接出现问题，无法完成请求。请检查网络连接后重试。',
        rate_limit: '当前请求过于频繁，AI 服务暂时限流。请稍等片刻后重试。',
        auth: 'AI 服务认证失败，请检查 API Key 配置。',
        cancelled: '请求已取消。',
        process: 'AI 服务进程异常中断，正在尝试恢复。如持续出现请重启服务。',
      };
      const friendlyMsg = errorMessages[aiResult.errorType]
        || aiResult.reply
        || `抱歉，遇到了未预期的问题（${aiResult.errorType}），我暂时无法处理这个请求。`;
      return {
        finalResponse: String(friendlyMsg),
        toolCallLog,
        iterations: iteration,
        provider: aiResult.provider,
        tokenUsage: aiResult.tokenUsage,
        effort: aiResult.effort,
        errorType: aiResult.errorType,
        stopped: true,
      };
    }

    if (!aiResult || !aiResult.reply) {
      return {
        finalResponse: aiResult?.reply || '抱歉，AI 未能生成有效回复。这可能是模型暂时不可用，请稍后重试。',
        toolCallLog,
        iterations: iteration,
        provider: aiResult?.provider,
        tokenUsage: aiResult?.tokenUsage,
      };
    }

    lastResult = aiResult;

    // Hook: PostResponse — notify hooks after AI response
    if (hookSys) {
      try {
        await hookSys.trigger('PostResponse', { reply: aiResult.reply, iteration });
      } catch { /* non-critical */ }
    }

    // Feed AI text to loop detector for chanting detection
    if (loopDetector && aiResult.reply) {
      loopDetector.feedContent(aiResult.reply);
    }

    // 2. Parse tool calls from AI response
    let toolCalls = _parseToolCalls(aiResult.reply).map(_canonicalizeToolCall);

    // 2a. Parse execution plan from first response (task decomposition)
    if (iteration === 1 && isComplex && !executionPlan) {
      executionPlan = _parseExecutionPlan(aiResult.reply);
      if (executionPlan && onPlanReady) {
        onPlanReady(executionPlan);
      }
    }

    // Also include legacy [CMD:...] commands as pseudo-tool-calls
    if (aiResult.commands && aiResult.commands.length > 0) {
      for (const cmd of aiResult.commands) {
        toolCalls.push({ name: '_legacy_cmd', params: { command: cmd }, legacy: true });
      }
    }

    toolCalls = _rewriteShellCallsForAppLaunch(toolCalls, userMessage);

    // Patch empty web_search queries — models sometimes decide to search
    // but fail to include the query parameter.  Derive from user message.
    _patchEmptySearchQuery(toolCalls, originalUserMessage);

    // Auto-web-search: when the first round likely needs external/current info
    // but AI gave no tool call, inject one or more web_search calls proactively.
    let autoWebSearchInjected = false;
    let autoScaffoldInjected = false;
    if (
      toolCalls.length === 0
      && iteration === 1
      && _envFlagEnabled(process.env.KHY_AUTO_WEBSEARCH_ON_INFO_TASK, true)
      && _looksLikeInfoSearchRequest(originalUserMessage)
    ) {
      const maxAutoQueries = _parsePositiveInt(process.env.KHY_AUTO_WEBSEARCH_QUERY_CANDIDATES, 3, 1, 6);
      const configuredMode = options?.autoWebSearchMode || options?.autoWebSearch?.mode || process.env.KHY_AUTO_WEBSEARCH_MODE || 'auto';
      const resolvedMode = _resolveAutoWebSearchMode(originalUserMessage, configuredMode);
      const candidates = _buildSearchQueryCandidates(originalUserMessage, maxAutoQueries, resolvedMode);
      if (candidates.length > 0) {
        toolCalls = candidates.map((query) => ({
          name: 'web_search',
          params: { query },
        }));
        autoWebSearchInjected = true;
      }
    }

    // Auto-scaffold: when intent is project structure creation and no tool call
    // was returned, infer a scaffold spec from user text and execute directly.
    // Sanitize to strip [System Skill/Memory/Context] hints injected by the
    // agentic harness — their descriptions contain words like "scaffold" and
    // "initialize...project" that would otherwise false-positive every request.
    const sanitizedOriginal = _sanitizeSearchSourceMessage(originalUserMessage);
    const scaffoldOriginal = _sanitizeSearchSourceMessage(originalUserMessage, { collapseWhitespace: false });
    if (
      toolCalls.length === 0
      && iteration === 1
      && _envFlagEnabled(process.env.KHY_AUTO_SCAFFOLD_ON_INTENT, true)
      && _looksLikeProjectScaffoldRequest(scaffoldOriginal)
    ) {
      const defaultConcurrency = _parsePositiveInt(process.env.KHY_SCAFFOLD_DEFAULT_CONCURRENCY, 4, 1, 16);
      const parsedScaffold = _extractScaffoldSpecFromMessage(scaffoldOriginal, { defaultConcurrency });
      if (parsedScaffold) {
        toolCalls = [{ name: 'scaffoldFiles', params: parsedScaffold }];
        autoScaffoldInjected = true;
      }
    }

    const intentFilter = _filterToolCallsByIntent(toolCalls, originalUserMessage);
    const removedIntentMismatchCalls = Array.isArray(intentFilter.removed) ? intentFilter.removed : [];
    toolCalls = Array.isArray(intentFilter.kept) ? intentFilter.kept : toolCalls;

    if (removedIntentMismatchCalls.length > 0 && toolCalls.length === 0 && iteration === 1 && !noToolNudgeUsed) {
      noToolNudgeUsed = true;
      const strippedReply = _stripToolCalls(_stripExecutionPlan(aiResult.reply));
      if (onNoToolCall) {
        onNoToolCall(iteration, strippedReply, {
          placeholder: _looksLikeProgressOnlyReply(strippedReply),
          actionTask: _looksLikeActionRequest(userMessage),
          autoContinued: true,
          intentMismatch: true,
        });
      }
      currentMessage = _buildNoToolCallNudge(
        userMessage,
        `${strippedReply}\n\n[System notice] open_app was blocked because this request does not appear to be an app-launch command. Answer the user directly or use a relevant non-launch tool.`
      );
      continue;
    }

    const plannedTools = _buildPlannedToolList(toolCalls);
    emitDecision({
      iteration,
      mode: toolCalls.length > 0 ? 'tool' : 'final',
      preview: autoWebSearchInjected
        ? `Auto web search(${_resolveAutoWebSearchMode(originalUserMessage, options?.autoWebSearchMode || options?.autoWebSearch?.mode || process.env.KHY_AUTO_WEBSEARCH_MODE || 'auto')}) x${toolCalls.length}: ${String(toolCalls[0]?.params?.query || '').slice(0, 80)}`
        : autoScaffoldInjected
          ? `Auto scaffold: ${String(toolCalls[0]?.params?.root || '.')} (${Array.isArray(toolCalls[0]?.params?.directories) ? toolCalls[0].params.directories.length : 0} dirs / ${Array.isArray(toolCalls[0]?.params?.files) ? toolCalls[0].params.files.length : 0} files)`
        : _extractDecisionPreview(aiResult.reply),
      toolCount: toolCalls.length,
      tools: plannedTools,
    });

    // 3. No tool calls → final response
    if (toolCalls.length === 0) {
      const strippedReply = _stripToolCalls(_stripExecutionPlan(aiResult.reply));
      const placeholder = _looksLikeProgressOnlyReply(strippedReply);
      const sanitizedUser = _sanitizeSearchSourceMessage(userMessage);
      const actionTask = _looksLikeActionRequest(sanitizedUser);
      const appLaunchTask = _looksLikeAppLaunchRequest(sanitizedUser);
      const infoSearchTask = _looksLikeInfoSearchRequest(sanitizedUser);
      const scaffoldTask = _looksLikeProjectScaffoldRequest(sanitizedUser);

      if (iteration === 1 && !noToolNudgeUsed && appLaunchTask) {
        noToolNudgeUsed = true;
        if (onNoToolCall) {
          onNoToolCall(iteration, strippedReply, { placeholder, actionTask, appLaunchTask, autoContinued: true });
        }
        currentMessage = _buildAppLaunchToolNudge(userMessage, strippedReply);
        continue;
      }

      if (iteration === 1 && !noToolNudgeUsed && infoSearchTask) {
        noToolNudgeUsed = true;
        if (onNoToolCall) {
          onNoToolCall(iteration, strippedReply, { placeholder, actionTask, infoSearchTask, autoContinued: true });
        }
        currentMessage = _buildWebSearchToolNudge(userMessage, strippedReply);
        continue;
      }

      if (iteration === 1 && !noToolNudgeUsed && scaffoldTask) {
        noToolNudgeUsed = true;
        if (onNoToolCall) {
          onNoToolCall(iteration, strippedReply, { placeholder, actionTask, scaffoldTask, autoContinued: true });
        }
        currentMessage = _buildScaffoldToolNudge(userMessage, strippedReply);
        continue;
      }

      // If the first reply is only a progress preface ("我来检查...") with no tool
      // calls, nudge once so the loop doesn't appear to "stop after OK".
      if (iteration === 1 && !noToolNudgeUsed && placeholder && actionTask) {
        noToolNudgeUsed = true;
        if (onNoToolCall) {
          onNoToolCall(iteration, strippedReply, { placeholder, actionTask, autoContinued: true });
        }
        currentMessage = _buildNoToolCallNudge(userMessage, strippedReply);
        continue;
      }
      if (onNoToolCall) {
        onNoToolCall(iteration, strippedReply, { placeholder, actionTask, autoContinued: false });
      }
      // Mark remaining plan steps as completed
      if (executionPlan && onPlanProgress) {
        for (let i = currentPlanStep; i < executionPlan.steps.length; i++) {
          if (executionPlan.steps[i].status !== 'completed') {
            onPlanProgress(i, 'completed');
          }
        }
      }
      return {
        finalResponse: strippedReply,
        toolCallLog,
        iterations: iteration,
        provider: aiResult.provider,
        tokenUsage: aiResult.tokenUsage,
        effort: aiResult.effort,
      };
    }

    // 3a. Preflight permission batch check (first iteration, 2+ tools)
    if (iteration === 1 && toolCalls.length >= 2 && process.env.KHY_PREFLIGHT !== 'false' && !preflightApproved) {
      try {
        const { runPreflight } = require('./preflightPermission');
        const pfResult = await runPreflight(toolCalls);
        preflightApproved = pfResult.approved;

        // Set preflight context in toolCalling so individual requestPermission() checks it
        try {
          const toolCalling = require('./toolCalling');
          toolCalling.setPreflightContext(preflightApproved);
        } catch { /* non-critical */ }

        // If all tools denied, stop early
        if (pfResult.denied.size > 0 && pfResult.approved.size === 0) {
          return {
            finalResponse: _stripToolCalls(aiResult.reply) + `\n\n${chalk.yellow('⚠ All tools denied in preflight check, stopping.')}`,
            toolCallLog,
            iterations: iteration,
            provider: aiResult.provider,
            stopped: true,
          };
        }
      } catch { /* preflight not available — continue with individual approval */ }
    }

    // 4. Execute tool calls — parallel for concurrency-safe, sequential for rest
    const toolResults = [];
    const parallelCalls = [];
    const sequentialCalls = [];

    // Classify calls by concurrency safety
    // Static set of known-safe tools as fallback when registry isn't available
    const KNOWN_CONCURRENCY_SAFE = new Set([
      'quote', 'data_fetch', 'search', 'strategy_list', 'web_search',
      'read_file', 'git_status', 'git_diff', 'git_log', 'tool_search',
      // camelCase aliases
      'readFile', 'gitStatus', 'gitDiff', 'gitLog', 'webSearch',
      'dataFetch', 'strategyList', 'toolSearch', 'glob', 'grep', 'ls', 'notebookRead',
    ]);

    let toolRegistry;
    try { toolRegistry = require('../tools'); } catch { toolRegistry = null; }

    for (const call of toolCalls) {
      if (call.legacy) {
        sequentialCalls.push(call);
        continue;
      }
      let isSafe = false;
      // Try dynamic check from registry first
      if (toolRegistry) {
        const regTool = toolRegistry.get(call.name);
        if (regTool && typeof regTool.isConcurrencySafe === 'function') {
          isSafe = regTool.isConcurrencySafe(call.params);
        } else {
          // Fallback to static set
          isSafe = KNOWN_CONCURRENCY_SAFE.has(call.name);
        }
      } else {
        // No registry — use static set
        isSafe = KNOWN_CONCURRENCY_SAFE.has(call.name);
      }
      if (isSafe) {
        parallelCalls.push(call);
      } else {
        sequentialCalls.push(call);
      }
    }

    // Execute parallel calls via toolCalling.executeTool (includes permission system)
    if (parallelCalls.length >= 2) {
      if (onParallelBatch) onParallelBatch(parallelCalls, iteration);
      const toolCalling = require('./toolCalling');
      const parallelPromises = parallelCalls.map(async (call) => {
        totalToolCalls++;
        if (onToolCall) onToolCall(call.name, call.params, iteration);

        // Hook: PreToolUse — allow hooks to block or modify params
        if (hookSys) {
          try {
            const hr = await hookSys.trigger('PreToolUse', { toolName: call.name, params: call.params, iteration, _fileReadHashes: fileReadHashes });
            if (hr.blocked) {
              const result = { success: false, error: `[Hook] ${hr.reason || 'Blocked by PreToolUse hook'}` };
              if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
              return { tool: call.name, params: call.params, result, elapsed: 0 };
            }
            if (hr.context?.params) call.params = hr.context.params;
          } catch { /* hook failure should not block tool execution */ }
        }

        // Loop detection: check before executing
        if (loopDetector) {
          const detection = loopDetector.check(call.name, call.params);
          if (detection.stuck && (detection.level === 'circuit_breaker' || detection.level === 'critical')) {
            const result = { success: false, error: `[LoopDetector:${detection.detector}] ${detection.message}`, _loopDetected: true };
            if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
            return { tool: call.name, params: call.params, result, elapsed: 0 };
          }
          if (detection.level === 'warning' && detection.message) {
            // Attach warning to result so it appears in tool result message
            call._loopWarning = detection.message;
          }
        }

        // Dedup: skip tool calls already executed with identical params (success or failure)
        const dedupKey = JSON.stringify({ t: call.name, p: call.params });
        const prevExec = executedCallKeys.get(dedupKey);
        if (prevExec) {
          prevExec.count++;
          const result = { ...prevExec.result, _deduped: true,
            _dedupNote: `This exact call was already executed (attempt #${prevExec.count}). Use the previous result.` };
          if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
          return { tool: call.name, params: call.params, result, elapsed: 0 };
        }

        if (loopDetector) loopDetector.recordCall(call.name, call.params);

        // Shell command safety check (parallel path)
        if ((call.name === 'shell_command' || call.name === 'shellCommand' || call.name === 'bash') && call.params?.command) {
          const safety = analyzeCommand(call.params.command);
          if (!safety.safe) {
            const result = { success: false, error: `[ShellSafety] Command blocked (${safety.maxSeverity}): ${safety.risks.filter(r => r.severity === 'critical').map(r => r.detail).join('; ')}` };
            if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
            return { tool: call.name, params: call.params, result, elapsed: 0 };
          }
          // Exec approval check (multi-level permission)
          if (_execApproval) {
            const approval = _execApproval.checkCommand(call.params.command);
            if (!approval.allowed && !approval.requestId) {
              const result = { success: false, error: `[ExecApproval] ${approval.reason} (risk: ${approval.risk})` };
              if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
              return { tool: call.name, params: call.params, result, elapsed: 0 };
            }
          }
        }

        const start = Date.now();
        const diagSpanId = diagnostics.emitToolCall(call.name, call.params, { traceId: diagTraceId });
        if (traceAudit) {
          try {
            traceAudit.logEvent('agent.tool.call', {
              toolName: call.name,
              params: call.params,
              iteration,
              parallel: true,
            }, {
              sessionId: traceSessionId,
              traceId: diagTraceId,
              source: 'tool-loop',
              visibility: 'summary',
            });
          } catch { /* non-critical */ }
        }
        const writeCtx = _captureWriteFileDiffContext(call);
        let result;
        try {
          result = await toolCalling.executeTool(call.name, call.params, {
            sessionId: traceSessionId,
            traceId: diagTraceId,
          });
        } catch (err) {
          result = { success: false, error: err.message };
        }
        result = await _recoverOpenAppAfterShellFailure(
          call,
          result,
          userMessage,
          toolCalling,
          { sessionId: traceSessionId, traceId: diagTraceId }
        );
        result = await _recoverWebSearchAfterShellFailure(
          call,
          result,
          userMessage,
          toolCalling,
          { sessionId: traceSessionId, traceId: diagTraceId }
        );
        diagnostics.emitToolResult(diagSpanId, result, result?.error ? result.error : null, { traceId: diagTraceId });
        if (traceAudit) {
          try {
            traceAudit.logEvent('agent.tool.result', {
              toolName: call.name,
              success: !!result?.success,
              denied: !!result?.denied,
              error: result?.error || null,
              iteration,
              parallel: true,
            }, {
              sessionId: traceSessionId,
              traceId: diagTraceId,
              source: 'tool-loop',
              visibility: 'summary',
            });
          } catch { /* non-critical */ }
        }
        // Track ALL executed calls for dedup (not just failures)
        executedCallKeys.set(dedupKey, { result, count: 1 });

        // Content-fingerprint: cache hash after successful read_file
        if (/^(read_file|readFile)$/i.test(call.name) && result?.success) {
          const fp = call.params?.path || call.params?.file_path;
          if (fp) {
            try {
              const abs = path.resolve(process.env.KHYQUANT_CWD || process.cwd(), fp);
              const hash = _fileContentHash(abs);
              if (hash) {
                try {
                  const st = fs.statSync(abs);
                  fileReadHashes.set(abs, { hash, mtime: st.mtimeMs, size: st.size });
                } catch {
                  fileReadHashes.set(abs, { hash, mtime: null, size: null });
                }
              }
            } catch { /* best-effort */ }
          }
        }

        if (loopDetector) loopDetector.recordOutcome(call.name, call.params, result);

        if (writeCtx && result && typeof result === 'object') {
          result._khyWriteDiff = writeCtx;
        }
        const elapsed = Date.now() - start;

        // Hook: PostToolUse — allow hooks to transform result
        if (hookSys) {
          try {
            const postHr = await hookSys.trigger('PostToolUse', { toolName: call.name, params: call.params, result, elapsed, _fileReadHashes: fileReadHashes });
            if (postHr.context?.result) result = postHr.context.result;
          } catch { /* non-critical */ }
        }

        if (onToolResult) onToolResult(call.name, call.params, result, iteration, elapsed);
        return { tool: call.name, params: call.params, result, elapsed, _loopWarning: call._loopWarning };
      });

      const settled = await Promise.allSettled(parallelPromises);
      for (const s of settled) {
        if (s.status === 'fulfilled') {
          toolResults.push(s.value);
          toolCallLog.push({ iteration, ...s.value });
          // G1: Inject LSP diagnostics from parallel tool results
          if (s.value.result?._lspDiagnostics && messages) {
            messages.push({ role: 'user', content: s.value.result._lspDiagnostics, _synthetic: true });
          }
          // Plan progress for parallel calls
          if (executionPlan && onPlanProgress) {
            const stepIdx = _matchToolCallToStep(s.value.tool, s.value.params, executionPlan, currentPlanStep);
            if (stepIdx >= 0) {
              const status = (s.value.result && s.value.result.success) ? 'completed' : 'error';
              onPlanProgress(stepIdx, status);
              executionPlan.steps[stepIdx].status = status;
              if (status === 'completed' && stepIdx >= currentPlanStep) currentPlanStep = stepIdx + 1;
            }
          }
          if (s.value.result && s.value.result.denied) {
            return {
              finalResponse: _stripToolCalls(aiResult.reply) + `\n\n${chalk.yellow('⚠ Tool execution denied by user, stopping.')}`,
              toolCallLog, iterations: iteration, provider: aiResult.provider, stopped: true,
            };
          }
        } else {
          const entry = { tool: 'unknown', params: {}, result: { success: false, error: s.reason?.message || 'Promise rejected' }, elapsed: 0 };
          toolResults.push(entry);
          toolCallLog.push({ iteration, ...entry });
        }
      }
    } else {
      // Move single parallel call back to sequential
      sequentialCalls.unshift(...parallelCalls);
    }

    // Execute sequential calls
    for (const call of sequentialCalls) {
      totalToolCalls++;

      // Skip legacy commands — they are handled by the existing REPL pipeline
      if (call.legacy) {
        toolResults.push({
          tool: '_legacy_cmd',
          params: call.params,
          result: { success: true, note: 'Executed via legacy command pipeline' },
        });
        toolCallLog.push({
          iteration,
          tool: '_legacy_cmd',
          params: call.params,
          result: { success: true },
          elapsed: 0,
        });
        continue;
      }

      if (onToolCall) onToolCall(call.name, call.params, iteration);

      // Content-fingerprint staleness check before edit
      if (/^(editFile|edit_file|edit)$/i.test(call.name)) {
        const fp = call.params?.file_path || call.params?.filePath || call.params?.path;
        if (fp) {
          try {
            const abs = path.resolve(process.env.KHYQUANT_CWD || process.cwd(), fp);
            const cachedEntry = fileReadHashes.get(abs);
            if (cachedEntry) {
              const currentHash = _fileContentHash(abs);
              if (currentHash && currentHash !== cachedEntry.hash) {
                if (!call.params) call.params = {};
                call.params._staleWarning = 'File changed since last read. Content may not match — consider re-reading first.';
                fileReadHashes.delete(abs);
              }
            }
          } catch { /* best-effort */ }
        }
      }

      // Hook: PreToolUse — allow hooks to block or modify params (sequential path)
      if (hookSys) {
        try {
          const hr = await hookSys.trigger('PreToolUse', { toolName: call.name, params: call.params, iteration, _fileReadHashes: fileReadHashes });
          if (hr.blocked) {
            const result = { success: false, error: `[Hook] ${hr.reason || 'Blocked by PreToolUse hook'}` };
            if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
            toolResults.push({ tool: call.name, params: call.params, result, elapsed: 0 });
            toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed: 0 });
            continue;
          }
          if (hr.context?.params) call.params = hr.context.params;
        } catch { /* hook failure should not block tool execution */ }
      }

      // Loop detection: check before executing
      if (loopDetector) {
        const detection = loopDetector.check(call.name, call.params);
        if (detection.stuck && (detection.level === 'circuit_breaker' || detection.level === 'critical')) {
          const result = { success: false, error: `[LoopDetector:${detection.detector}] ${detection.message}`, _loopDetected: true };
          if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
          toolResults.push({ tool: call.name, params: call.params, result, elapsed: 0 });
          toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed: 0 });
          if (detection.level === 'circuit_breaker') break; // stop all sequential calls
          continue;
        }
        // Warning: inject hint and tag the call for result message
        if (detection.level === 'warning' && detection.message) {
          currentMessage += `\n[LoopDetector warning: ${detection.message}]`;
          call._loopWarning = detection.message;
        }
      }

      // Dedup: skip tool calls already executed with identical params (success or failure)
      const dedupKey = JSON.stringify({ t: call.name, p: call.params });
      const prevExec = executedCallKeys.get(dedupKey);
      if (prevExec) {
        prevExec.count++;
        const result = { ...prevExec.result, _deduped: true,
          _dedupNote: `This exact call was already executed (attempt #${prevExec.count}). Use the previous result.` };
        const elapsed = 0;
        if (onToolResult) onToolResult(call.name, call.params, result, iteration, elapsed);
        toolResults.push({ tool: call.name, params: call.params, result, elapsed });
        toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed });
        continue;
      }

      if (loopDetector) loopDetector.recordCall(call.name, call.params);

      // Shell command safety check (sequential path)
      if ((call.name === 'shell_command' || call.name === 'shellCommand' || call.name === 'bash') && call.params?.command) {
        const safety = analyzeCommand(call.params.command);
        if (!safety.safe) {
          const result = { success: false, error: `[ShellSafety] Command blocked (${safety.maxSeverity}): ${safety.risks.filter(r => r.severity === 'critical').map(r => r.detail).join('; ')}` };
          if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
          toolResults.push({ tool: call.name, params: call.params, result, elapsed: 0 });
          toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed: 0 });
          continue;
        }
        // Exec approval check (multi-level permission)
        if (_execApproval) {
          const approval = _execApproval.checkCommand(call.params.command);
          if (!approval.allowed && !approval.requestId) {
            const result = { success: false, error: `[ExecApproval] ${approval.reason} (risk: ${approval.risk})` };
            if (onToolResult) onToolResult(call.name, call.params, result, iteration, 0);
            toolResults.push({ tool: call.name, params: call.params, result, elapsed: 0 });
            toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed: 0 });
            continue;
          }
        }
      }

      const start = Date.now();
      const seqDiagSpanId = diagnostics.emitToolCall(call.name, call.params, { traceId: diagTraceId });
      if (traceAudit) {
        try {
          traceAudit.logEvent('agent.tool.call', {
            toolName: call.name,
            params: call.params,
            iteration,
            parallel: false,
          }, {
            sessionId: traceSessionId,
            traceId: diagTraceId,
            source: 'tool-loop',
            visibility: 'summary',
          });
        } catch { /* non-critical */ }
      }
      const writeCtx = _captureWriteFileDiffContext(call);
      let result;
      let toolCalling = null;

      try {
        // Use toolCalling.executeTool which includes permission system
        toolCalling = require('./toolCalling');
        result = await toolCalling.executeTool(call.name, call.params, {
          sessionId: traceSessionId,
          traceId: diagTraceId,
        });
      } catch (err) {
        // Fallback: try tool registry directly
        try {
          const toolRegistry = require('../tools');
          result = await toolRegistry.execute(call.name, call.params);
        } catch (err2) {
          result = { success: false, error: err2.message || err.message };
        }
      }
      if (!toolCalling) {
        try { toolCalling = require('./toolCalling'); } catch { toolCalling = null; }
      }
      if (toolCalling) {
        result = await _recoverOpenAppAfterShellFailure(
          call,
          result,
          userMessage,
          toolCalling,
          { sessionId: traceSessionId, traceId: diagTraceId }
        );
        result = await _recoverWebSearchAfterShellFailure(
          call,
          result,
          userMessage,
          toolCalling,
          { sessionId: traceSessionId, traceId: diagTraceId }
        );
      }
      diagnostics.emitToolResult(seqDiagSpanId, result, result?.error ? result.error : null, { traceId: diagTraceId });
      if (traceAudit) {
        try {
          traceAudit.logEvent('agent.tool.result', {
            toolName: call.name,
            success: !!result?.success,
            denied: !!result?.denied,
            error: result?.error || null,
            iteration,
            parallel: false,
          }, {
            sessionId: traceSessionId,
            traceId: diagTraceId,
            source: 'tool-loop',
            visibility: 'summary',
          });
        } catch { /* non-critical */ }
      }

      // Track ALL executed calls for dedup (not just failures)
      executedCallKeys.set(dedupKey, { result, count: 1 });

      // Content-fingerprint: cache hash after successful read_file
      if (/^(read_file|readFile)$/i.test(call.name) && result?.success) {
        const fp = call.params?.path || call.params?.file_path;
        if (fp) {
          try {
            const abs = path.resolve(process.env.KHYQUANT_CWD || process.cwd(), fp);
            const hash = _fileContentHash(abs);
            if (hash) fileReadHashes.set(abs, hash);
          } catch { /* best-effort */ }
        }
      }

      if (loopDetector) loopDetector.recordOutcome(call.name, call.params, result);

      const elapsed = Date.now() - start;
      if (writeCtx && result && typeof result === 'object') {
        result._khyWriteDiff = writeCtx;
      }

      // Audit logging (non-critical)
      try {
        const { logToolExecution } = require('./auditLog');
        logToolExecution({
          tool: call.name,
          params: call.params,
          result,
          elapsed,
        });
      } catch { /* audit failure is non-critical */ }

      // Hook: PostToolUse — allow hooks to transform result (sequential path)
      if (hookSys) {
        try {
          const postHr = await hookSys.trigger('PostToolUse', { toolName: call.name, params: call.params, result, elapsed, _fileReadHashes: fileReadHashes });
          if (postHr.context?.result) result = postHr.context.result;
        } catch { /* non-critical */ }
      }

      // G1: Inject LSP diagnostics as synthetic message for AI self-correction
      if (result?._lspDiagnostics && messages) {
        messages.push({ role: 'user', content: result._lspDiagnostics, _synthetic: true });
      }

      if (onToolResult) onToolResult(call.name, call.params, result, iteration, elapsed);

      // Update plan progress if we have an execution plan
      if (executionPlan && onPlanProgress) {
        const stepIdx = _matchToolCallToStep(call.name, call.params, executionPlan, currentPlanStep);
        if (stepIdx >= 0) {
          const status = (result && result.success) ? 'completed' : 'error';
          onPlanProgress(stepIdx, status);
          executionPlan.steps[stepIdx].status = status;
          if (status === 'completed' && stepIdx >= currentPlanStep) {
            currentPlanStep = stepIdx + 1;
            // Mark next step as in_progress
            if (currentPlanStep < executionPlan.steps.length) {
              onPlanProgress(currentPlanStep, 'in_progress');
            }
          }
        }
      }

      toolResults.push({ tool: call.name, params: call.params, result, _loopWarning: call._loopWarning });
      toolCallLog.push({ iteration, tool: call.name, params: call.params, result, elapsed });

      // Update content-fingerprint after successful edit/write
      if (result?.success && /^(editFile|edit_file|edit|write_file|writeFile)$/i.test(call.name)) {
        const fp = call.params?.file_path || call.params?.filePath || call.params?.path;
        if (fp) {
          try {
            const abs = path.resolve(process.env.KHYQUANT_CWD || process.cwd(), fp);
            const hash = _fileContentHash(abs);
            if (hash) fileReadHashes.set(abs, hash);
          } catch { /* best-effort */ }
        }
      }

      // Auto-verify: if write_file failed, automatically read the file to check state
      if (result && !result.success && (call.name === 'write_file' || call.name === 'writeFile') && call.params?.path) {
        try {
          const toolCalling = require('./toolCalling');
          const verifyResult = await toolCalling.executeTool('read_file', { path: call.params.path });
          if (verifyResult && verifyResult.success) {
            toolResults.push({ tool: 'read_file', params: { path: call.params.path }, result: verifyResult, elapsed: 0, _autoVerify: true });
            toolCallLog.push({ iteration, tool: 'read_file', params: { path: call.params.path }, result: verifyResult, elapsed: 0, _autoVerify: true });
          }
        } catch { /* verification is best-effort */ }
      }

      // Auto-recovery: if editFile failed, inject guidance hint + auto-read file
      if (result && !result.success &&
          (call.name === 'editFile' || call.name === 'edit_file' || call.name === 'edit')) {
        const errMsg = String(result.error?.message || result.error || '');
        const filePath = call.params?.file_path || call.params?.filePath || call.params?.path;
        let hint = '';
        if (errMsg.includes('not found in'))
          hint = `Edit failed: old_string was not found in the file. The text may have changed or whitespace/indentation does not match. Use read_file to see the current content of ${filePath || 'the file'}, then retry with the exact text.`;
        else if (/appears.*times/.test(errMsg))
          hint = 'Edit failed: old_string matches multiple locations. Include more surrounding context lines in old_string to make it unique, or use replace_all: true.';
        else if (errMsg.includes('ENOENT') || errMsg.includes('File not found'))
          hint = `Edit failed: file ${filePath || ''} does not exist. Check the path with glob, then retry.`;
        if (hint) result.hint = hint;
        // Auto-read on "not found" to give AI fresh file content
        if (errMsg.includes('not found in') && filePath) {
          try {
            const toolCalling = require('./toolCalling');
            const vr = await toolCalling.executeTool('read_file', { path: filePath });
            if (vr && vr.success) {
              toolResults.push({ tool: 'read_file', params: { path: filePath }, result: vr, elapsed: 0, _autoVerify: true });
              toolCallLog.push({ iteration, tool: 'read_file', params: { path: filePath }, result: vr, elapsed: 0, _autoVerify: true });
            }
          } catch { /* best-effort */ }
        }
      }

      // If user denied the tool, stop the loop
      if (result && result.denied) {
        return {
          finalResponse: _stripToolCalls(aiResult.reply) + `\n\n${chalk.yellow('⚠ Tool execution denied by user, stopping.')}`,
          toolCallLog,
          iterations: iteration,
          provider: aiResult.provider,
          stopped: true,
        };
      }
    }

    // 5. Build follow-up message with tool results
    currentMessage = _buildToolResultMessage(toolResults);

    // ── Capacity Checkpoint 2: Post-Tool ─────────────────────────────
    // After tool execution, check if context expanded dangerously.
    try {
      const _capacityFlow2 = require('./capacityFlow');
      const _estimateTokensFn2 = (text) => Math.ceil((text || '').length / 4);
      const _usedTokens2 = conversationMessages.reduce(
        (sum, m) => sum + _estimateTokensFn2(typeof m.content === 'string' ? m.content : JSON.stringify(m.content || '')),
        0
      ) + _estimateTokensFn2(currentMessage);
      const _contextWindow2 = effectiveChatOpts?.contextWindowTokens || parseInt(process.env.KHY_CONTEXT_WINDOW, 10) || 128000;
      const _failedCount = toolResults.filter(tr => tr.result && !tr.result.success).length;
      const postCheck = _capacityFlow2.postToolCheckpoint({
        toolResults,
        usedTokens: _usedTokens2,
        contextWindow: _contextWindow2,
        iterationErrors: _failedCount,
        totalIterations: iteration,
      });
      if (postCheck.decision !== _capacityFlow2.CapacityDecision.None) {
        conversationMessages = _capacityFlow2.applyDecision(
          postCheck.decision,
          conversationMessages,
          { estimateTokens: _estimateTokensFn2, contextWindow: _contextWindow2 }
        );
      }
      // Drive coherence state from post-tool checkpoint
      try {
        const { getCoherenceState } = require('./coherenceState');
        const csm2 = getCoherenceState();
        csm2.transition(postCheck);
        if (postCheck.decision !== _capacityFlow2.CapacityDecision.None) {
          csm2.completeOperation();
        }
      } catch { /* coherence tracking is optional */ }
    } catch { /* best-effort */ }

    // Activity: tools executed successfully, reset idle timer
    if (toolResults.length > 0) {
      lastActivityTime = Date.now();
    }

    // 6. Track read-only iterations (AI only reading without acting)
    const READ_ONLY_TOOLS = new Set([
      'read_file', 'readFile',
      'search', 'toolSearch',
      'git_status', 'gitStatus',
      'git_diff', 'gitDiff',
      'git_log',
      'strategy_list', 'strategyList',
      'quote', 'grep', 'glob', 'ls', 'webSearch', 'web_search', 'webFetch', 'notebookRead',
    ]);
    const allReadOnly = toolResults.length > 0 && toolResults.every(tr => {
      // For shell commands, check if the command is read-only (ls, cat, grep, find, etc.)
      if (tr.tool === 'shell_command' || tr.tool === 'shellCommand') {
        const cmd = (tr.params?.command || '').trim().split(/\s+/)[0];
        const readOnlyCmds = new Set(['ls', 'cat', 'head', 'tail', 'grep', 'rg', 'find', 'wc', 'file', 'stat', 'pwd', 'which', 'echo', 'tree', 'du', 'df']);
        return readOnlyCmds.has(cmd);
      }
      return READ_ONLY_TOOLS.has(tr.tool);
    });
    if (allReadOnly) {
      consecutiveReadOnlyIterations++;
    } else {
      consecutiveReadOnlyIterations = 0;
    }

    if (toolResults.length > 0) {
      const succeeded = toolResults.filter(tr => !!tr?.result?.success).length;
      const denied = toolResults.filter(tr => !!tr?.result?.denied).length;
      const deduped = toolResults.filter(tr => !!tr?.result?._deduped).length;
      const failed = Math.max(0, toolResults.length - succeeded - denied);
      emitIterationSummary({
        iteration,
        total: toolResults.length,
        succeeded,
        failed,
        denied,
        deduped,
        readOnlyOnly: allReadOnly,
      });

      // ── onCheckpoint: emit every 5 iterations or 60s ──
      if (typeof onCheckpoint === 'function' &&
          (iteration % 5 === 0 || Date.now() - lastCheckpointTime > 60000)) {
        try {
          onCheckpoint({ iteration, totalToolCalls, toolCallLog: toolCallLog.slice(-20) });
        } catch { /* best-effort */ }
        lastCheckpointTime = Date.now();
      }

      // All calls deduped → model is stuck repeating the same tool calls.
      // Exit gracefully instead of burning remaining iterations.
      if (deduped > 0 && deduped === toolResults.length) {
        consecutiveDedupIterations++;
        if (consecutiveDedupIterations >= 1) {
          // Find the best result from previous executions to return
          const prevResult = [...executedCallKeys.values()].find(e => e.result?.success);
          const exitMsg = prevResult
            ? (prevResult.result.output || prevResult.result.content || prevResult.result.text || 'Task completed successfully.')
            : 'All tool calls were duplicates of previous successful calls. Task is complete.';
          return {
            finalResponse: typeof exitMsg === 'string' ? exitMsg : JSON.stringify(exitMsg),
            toolCallLog,
            iterations: iteration,
            provider: aiResult?.provider,
            tokenUsage: aiResult?.tokenUsage,
          };
        }
      } else {
        consecutiveDedupIterations = 0;
      }
    }

    // Consecutive failure guardrail — adaptive error handling
    // Instead of a blanket "stop retrying", analyze failure patterns:
    //   - Permission denied → tell AI to skip that tool or ask user
    //   - Unknown tool → tell AI to use a different tool name
    //   - Network error → tell AI the network may be restricted
    //   - Other → only bail out after threshold
    const allFailed = toolResults.length > 0 && toolResults.every(tr =>
      tr.result && !tr.result.success
    );
    if (allFailed) {
      const allWebLookupFailed = toolResults.every((tr) => _isWebLookupToolName(tr?.tool));
      if (allWebLookupFailed) {
        consecutiveWebLookupFailureIterations++;
        consecutiveFailureIterations = 0;
        const keepSearching = consecutiveWebLookupFailureIterations < MAX_WEB_LOOKUP_FAILURES;
        const guidance = keepSearching
          ? 'Web lookup failed in this round. Try one alternative query formulation (more specific keywords) and avoid repeating the same query.'
          : 'Web lookup keeps failing. Stop calling web tools and continue with a best-effort answer from local/context knowledge. Explicitly mark uncertainty for time-sensitive claims.';
        currentMessage = _buildToolResultMessage(toolResults)
          + '\n\n[SYSTEM: ' + guidance + ']';
        continue;
      }

      consecutiveFailureIterations++;
      consecutiveWebLookupFailureIterations = 0;

      // ── Capacity Checkpoint 3: Error Escalation ──────────────────
      // On repeated failures, consider resetting context or replanning.
      try {
        const _capacityFlow3 = require('./capacityFlow');
        const _estimateTokensFn3 = (text) => Math.ceil((text || '').length / 4);
        const _usedTokens3 = conversationMessages.reduce(
          (sum, m) => sum + _estimateTokensFn3(typeof m.content === 'string' ? m.content : JSON.stringify(m.content || '')),
          0
        );
        const _contextWindow3 = effectiveChatOpts?.contextWindowTokens || parseInt(process.env.KHY_CONTEXT_WINDOW, 10) || 128000;
        const _recentErrors = toolResults.map(tr => tr?.result?.error).filter(Boolean);
        const errCheck = _capacityFlow3.errorEscalationCheckpoint({
          consecutiveErrors: consecutiveFailureIterations,
          recentErrors: _recentErrors,
          usedTokens: _usedTokens3,
          contextWindow: _contextWindow3,
        });
        if (errCheck.decision === _capacityFlow3.CapacityDecision.VerifyReplan) {
          // Save canonical state snapshot before resetting context for replan
          try {
            const _canonicalState = require('./canonicalState');
            const snapshot = _canonicalState.buildSnapshot({
              messages: conversationMessages,
              toolCallLog,
              model: effectiveChatOpts?.model,
              workspace: effectiveChatOpts?.cwd || process.cwd(),
            });
            _canonicalState.save(snapshot);
            // Inject snapshot as replan context so the model knows prior state
            const replanPrompt = _canonicalState.formatAsPrompt(snapshot);
            currentMessage += `\n\n${replanPrompt}`;
          } catch { /* canonical state is best-effort */ }
          conversationMessages = _capacityFlow3.applyDecision(
            errCheck.decision,
            conversationMessages,
            { estimateTokens: _estimateTokensFn3, contextWindow: _contextWindow3 }
          );
        }
        // Drive coherence state from error escalation checkpoint
        try {
          const { getCoherenceState } = require('./coherenceState');
          const csm3 = getCoherenceState();
          csm3.transition(errCheck);
          if (errCheck.decision !== _capacityFlow3.CapacityDecision.None) {
            csm3.completeOperation();
          }
        } catch { /* coherence tracking is optional */ }
      } catch { /* best-effort */ }

      // Classify failures for targeted guidance
      const errors = toolResults.map((tr) => {
        const err = tr?.result?.error;
        if (!err) return '';
        if (typeof err === 'string') return err.toLowerCase();
        if (typeof err === 'object') {
          const text = [err.code, err.message, err.hint].filter(Boolean).join(' ');
          return text.toLowerCase();
        }
        return String(err).toLowerCase();
      });
      const hasPermDenied = errors.some(e => e.includes('denied') || e.includes('permission'));
      const hasUnknownTool = errors.some(e => e.includes('unknown tool'));
      const hasNetwork = errors.some(e => e.includes('network') || e.includes('timeout') || e.includes('404') || e.includes('econnrefused'));
      const hasLoopDetected = errors.some(e => e.includes('loopdetector') || e.includes('loop detected'));

      if (consecutiveFailureIterations >= MAX_CONSECUTIVE_FAILURES) {
        // Build context-aware guidance instead of blanket "STOP"
        const hints = [];
        if (hasPermDenied) hints.push('Some tools were denied by the user — skip those tools or ask the user to approve.');
        if (hasUnknownTool) hints.push('Some tool names were not recognized — check available tools and use correct names.');
        if (hasNetwork) hints.push('Network requests are failing — the environment may be offline or restricted. Use local knowledge instead.');
        if (hasLoopDetected) hints.push('Loop detection triggered — change your approach completely.');
        const guidance = hints.length > 0 ? hints.join(' ') : 'Multiple approaches have failed.';

        currentMessage = _buildToolResultMessage(toolResults)
          + '\n\n[SYSTEM: Tool calls have failed for ' + consecutiveFailureIterations
          + ' consecutive iterations. ' + guidance
          + ' 请坦诚告知用户你目前的能力限制，说明已完成的部分和无法完成的部分，并给出可行的替代建议。不要假装能做到实际做不到的事。]';
        const summaryResult = await chat(currentMessage, { ...chatOpts, _isFollowUp: true });
        const summaryText = summaryResult?.reply || 'Tool calls failed repeatedly.';
        return {
          finalResponse: _stripToolCalls(_stripExecutionPlan(summaryText)),
          toolCallLog,
          iterations: iteration,
          provider: summaryResult?.provider || lastResult?.provider,
          tokenUsage: summaryResult?.tokenUsage,
          consecutiveFailureBailout: true,
        };
      }
    } else {
      consecutiveFailureIterations = 0;
      consecutiveWebLookupFailureIterations = 0;
    }
  }

  // Exceeded max iterations
  const warning = `\n\n${chalk.yellow(`⚠ 已达到最大执行步骤数（${effectiveMaxIterations}）。`)}` +
    `\n${chalk.dim('任务可能尚未完全完成，可以继续发送请求让我接着处理剩余部分。')}`;
  return {
    finalResponse: _stripToolCalls(_stripExecutionPlan(lastResult?.reply || '')) + warning,
    toolCallLog,
    iterations: effectiveMaxIterations,
    provider: lastResult?.provider,
    maxIterationsReached: true,
    maxIterations: effectiveMaxIterations,
    transientRecoveries: transientRecoveryUsed,
  };

  } finally {
    // Always cleanup preflight context, even on error
    try {
      const toolCalling = require('./toolCalling');
      toolCalling.clearPreflightContext();
    } catch { /* non-critical */ }
  }
}

// ── Parsing ────────────────────────────────────────────────────────

/**
 * Parse tool calls from AI response text.
 * Supports two formats:
 *   1. <tool_call>tool_name(param1, param2)</tool_call>
 *   2. <tool_call>{"name": "tool", "params": {...}}</tool_call>
 *
 * @param {string} text - AI response text
 * @returns {Array<{name: string, params: object}>}
 */
function _parseToolCalls(text) {
  if (!text) return [];

  const calls = [];

  // Format 1: JSON-style tool calls
  const jsonMatches = [...text.matchAll(/<tool_call>\s*(\{[\s\S]*?\})\s*<\/tool_call>/g)];
  for (const match of jsonMatches) {
    try {
      const { safeJsonParse } = require('./gateway/safeJsonParse');
      const parsed = safeJsonParse(match[1], null);
      if (parsed && parsed.name) {
        const normalized = normalizeToolCall(parsed.name, parsed.params || parsed.arguments || {});
        calls.push({ name: normalized.name, params: normalized.params });
      }
    } catch { /* skip malformed JSON */ }
  }

  // Format 2: function-call-style tool calls
  // e.g. <tool_call>git_status()</tool_call> or <tool_call>shellCommand(command: "dir")</tool_call>
  const funcMatches = [...text.matchAll(/<tool_call>\s*([\w_]+)\s*\(([\s\S]*?)\)\s*<\/tool_call>/g)];
  for (const match of funcMatches) {
    const rawName = match[1];
    const argsStr = match[2].trim();

    const params = _parseFunctionArgs(rawName, argsStr);
    const normalized = normalizeToolCall(rawName, params);
    // Avoid only true duplicates (same tool + same params)
    const sameCallExists = calls.some((c) => (
      c.name === normalized.name
      && JSON.stringify(c.params || {}) === JSON.stringify(normalized.params || {})
    ));
    if (sameCallExists) continue;
    calls.push({ name: normalized.name, params: normalized.params });
  }

  // Format 3: natural-language tool calls from local models
  // e.g. 【调用策略列表：all】 / 【调用回测：symbol=000300 strategy=ma_cross】
  if (calls.length === 0) {
    const naturalSource = _stripExecutionPlan(String(text || ''));
    const naturalCalls = _parseNaturalToolCalls(naturalSource);
    if (naturalCalls.length > 0) {
      return naturalCalls.map((call) => {
        const normalized = normalizeToolCall(call.name, call.params || {});
        return { ...call, name: normalized.name, params: normalized.params };
      });
    }
  }

  return calls;
}

function _parseNaturalToolCalls(text) {
  if (!text) return [];
  const out = [];
  const src = String(text);

  const matches = [...src.matchAll(/【\s*调用\s*([^：:\]】\n]{1,32})\s*(?:[：:]\s*([^】]*?))?\s*】/g)];
  for (const m of matches) {
    // Lenient line-prefix check: allow 【调用】 anywhere in the line.
    // Only skip if the prefix looks like a plan description header
    // (e.g. inside a markdown code block or deeply nested structure).
    const linePrefix = src.slice(0, m.index || 0).split('\n').pop() || '';
    const inCodeBlock = /```/.test(src.slice(Math.max(0, (m.index || 0) - 500), m.index));
    if (inCodeBlock) continue;

    const rawAction = String(m[1] || '').trim();
    const rawArg = String(m[2] || '').trim();
    const toolName = _mapNaturalActionToTool(rawAction);
    if (!toolName) continue;

    // Relaxed tail check: allow most trailing text.
    // Only skip if it looks like a plan-description line with significant
    // natural-language explanation after the tag AND the tool is not an action tool.
    const endIdx = (m.index || 0) + m[0].length;
    const tail = src.slice(endIdx).split('\n')[0].trim();
    const allowTailForActionTool = (toolName === 'open_app' || toolName === 'shell_command'
      || toolName === 'write_file' || toolName === 'read_file' || toolName === 'editFile');
    // Only skip if tail is a long CJK explanation (>15 chars), suggesting a plan description
    if (!allowTailForActionTool && tail.length > 15 && !/^[，,。.!！?？:：;；\s]*$/.test(tail)) continue;

    const params = _buildNaturalToolParams(toolName, rawArg);
    out.push({ name: toolName, params, natural: true, rawAction, rawArg });
  }

  return out;
}

function _mapNaturalActionToTool(action) {
  const raw = String(action || '').trim();
  if (!raw) return null;
  const key = raw.toLowerCase().replace(/\s+/g, '');
  if (NATURAL_ACTION_TO_TOOL[key]) return NATURAL_ACTION_TO_TOOL[key];
  if (NATURAL_ACTION_TO_TOOL[raw]) return NATURAL_ACTION_TO_TOOL[raw];

  // Fuzzy fallback for slight phrasing differences
  if (/(回测|backtest)/i.test(raw)) return 'backtest';
  if (/(k线|kline|日线|周线|月线|分钟线)/i.test(raw)) return 'data_fetch';
  if (/(策略|strategy)/i.test(raw)) return 'strategy_list';
  if (/(行情|报价|价格|quote|price)/i.test(raw)) return 'quote';
  if (/(搜索|search|web)/i.test(raw)) return 'web_search';
  if (/(读取|read)/i.test(raw)) return 'read_file';
  if (/(写入|write)/i.test(raw)) return 'write_file';
  if (/(脚手架|scaffold|创建项目|项目结构|目录结构|批量创建|并行写入)/i.test(raw)) return 'scaffoldFiles';
  if (/(命令|shell|bash|terminal|cmd)/i.test(raw)) return 'shell_command';
  if (/(打开|启动|运行|应用|程序|浏览器|open|launch|run)/i.test(raw)) return 'open_app';
  if (/(git状态|gitstatus)/i.test(raw)) return 'git_status';
  if (/(git差异|gitdiff)/i.test(raw)) return 'git_diff';
  return null;
}

function _parseLooseKv(argText = '') {
  const out = {};
  const s = String(argText || '').trim();
  if (!s) return out;
  const parts = s.split(/[\s,，]+/).filter(Boolean);
  for (const p of parts) {
    const m = p.match(/^([a-zA-Z_]+)=(.+)$/);
    if (m) out[m[1]] = m[2];
  }
  return out;
}

function _cleanParams(obj = {}) {
  return Object.fromEntries(
    Object.entries(obj).filter(([, v]) => v !== undefined && v !== null && v !== '')
  );
}

function _buildNaturalToolParams(toolName, argText) {
  const raw = String(argText || '').trim();
  const kv = _parseLooseKv(raw);

  if (toolName === 'strategy_list' || toolName === 'git_status') return {};

  if (toolName === 'quote') {
    return _cleanParams({ symbol: kv.symbol || kv.code || raw });
  }

  if (toolName === 'backtest') {
    const firstToken = raw.split(/\s+/).filter(Boolean)[0];
    return _cleanParams({
      symbol: kv.symbol || kv.code || firstToken || '000300',
      strategy: kv.strategy,
      start: kv.start,
      end: kv.end,
      capital: kv.capital !== undefined ? _coerceValue(String(kv.capital)) : undefined,
    });
  }

  if (toolName === 'data_fetch') {
    const parts = raw.split(/\s+/).filter(Boolean);
    return _cleanParams({
      symbol: kv.symbol || kv.code || parts[0] || '000001',
      period: kv.period || parts[1],
    });
  }

  if (toolName === 'search') {
    return _cleanParams({ keyword: kv.keyword || raw });
  }

  if (toolName === 'web_search') {
    return _cleanParams({ query: kv.query || kv.keyword || raw || '最新市场信息' });
  }

  if (toolName === 'read_file') {
    return _cleanParams({ path: raw.replace(/^\/+/, '') });
  }

  if (toolName === 'write_file') {
    const [filePath, ...rest] = raw.split('|');
    return _cleanParams({
      path: (filePath || '').trim(),
      content: rest.join('|').trim(),
    });
  }

  if (toolName === 'shell_command') {
    return _cleanParams({ command: raw });
  }

  if (toolName === 'open_app') {
    return _cleanParams({ name: raw || kv.name || kv.app || kv.application });
  }

  if (toolName === 'git_diff') {
    return raw ? _cleanParams({ file: raw }) : {};
  }

  return {};
}

/**
 * Parse function-call-style arguments into an object.
 * Maps positional args to parameter names based on tool schema.
 *
 * @param {string} toolName
 * @param {string} argsStr - Raw argument string
 * @returns {object}
 */
function _parseFunctionArgs(toolName, argsStr) {
  if (!argsStr) return {};

  // Try JSON parse first (e.g. {"symbol": "sh600519"} or {"command": "dir"})
  try {
    if (argsStr.startsWith('{')) {
      return JSON.parse(argsStr);
    }
  } catch { /* fall through */ }

  // Try key: "value" pairs (AI often uses this format, e.g. command: "dir /b", cwd: "D:\\")
  const kvColonRe = /(\w+)\s*:\s*(?:"([^"]*?)"|'([^']*?)'|([^,)]+))/g;
  let kvMatch;
  const colonParams = {};
  let hasColonPairs = false;
  while ((kvMatch = kvColonRe.exec(argsStr)) !== null) {
    hasColonPairs = true;
    // Quoted values (groups 2/3) stay as strings; unquoted (group 4) get type coercion
    if (kvMatch[2] !== undefined) {
      colonParams[kvMatch[1]] = kvMatch[2];
    } else if (kvMatch[3] !== undefined) {
      colonParams[kvMatch[1]] = kvMatch[3];
    } else {
      colonParams[kvMatch[1]] = _coerceValue((kvMatch[4] ?? '').trim());
    }
  }
  if (hasColonPairs) return colonParams;

  // Try key=value pairs (e.g. symbol=sh600519, staged=true)
  if (argsStr.includes('=')) {
    const params = {};
    const pairs = argsStr.split(',').map(s => s.trim());
    for (const pair of pairs) {
      const [key, ...rest] = pair.split('=');
      const value = rest.join('=').trim().replace(/^["']|["']$/g, '');
      params[key.trim()] = _coerceValue(value);
    }
    return params;
  }

  // Positional argument: map to the first required parameter
  try {
    const toolRegistry = require('../tools');
    const normalized = normalizeToolCall(toolName, {}).name || toolName;
    const tool = toolRegistry.get(normalized);
    if (tool && tool.inputSchema) {
      const firstRequired = Object.entries(tool.inputSchema)
        .find(([, rule]) => rule.required);
      if (firstRequired) {
        return { [firstRequired[0]]: argsStr.replace(/^["']|["']$/g, '') };
      }
    }
  } catch { /* registry not available */ }

  // Fallback: use 'command' as the default param (most common tool)
  return { command: argsStr.replace(/^["']|["']$/g, '') };
}

/**
 * Coerce string values to appropriate JS types.
 */
function _coerceValue(str) {
  if (str === 'true') return true;
  if (str === 'false') return false;
  if (str === 'null') return null;
  const num = Number(str);
  if (!isNaN(num) && str !== '') return num;
  return str;
}

// ── Formatting ─────────────────────────────────────────────────────

/**
 * Build a follow-up message containing tool execution results.
 * Formatted so the AI can understand what happened and continue.
 */
function _buildToolResultMessage(toolResults) {
  const parts = ['[Tool execution results]\n'];

  for (const tr of toolResults) {
    if (tr.tool === '_legacy_cmd') continue;

    // Mark auto-verification reads clearly
    if (tr._autoVerify) {
      parts.push(`Tool: ${tr.tool} (auto-verify after write failure)`);
    } else if (tr.result._deduped) {
      const verb = tr.result.success ? 'succeeded' : 'failed';
      parts.push(`Tool: ${tr.tool} (SKIPPED — identical call already ${verb}. Do NOT call it again with the same parameters. Use the previous result or try a DIFFERENT approach.)`);
    } else if (tr.result._loopDetected) {
      parts.push(`Tool: ${tr.tool} (BLOCKED — loop detected. Change your approach entirely.)`);
    } else {
      parts.push(`Tool: ${tr.tool}`);
    }

    // Append loop detection warning if present
    if (tr._loopWarning) {
      parts.push(`[LoopWarning: ${tr._loopWarning} — try a different tool or approach]`);
    }
    if (tr.result.success) {
      // Include relevant output fields
      const output = tr.result.output || tr.result.content || tr.result.result;
      if (output) {
        const text = typeof output === 'string' ? output : JSON.stringify(output);
        // D13: Smart per-tool truncation with noise classification
        try {
          const _smartTrunc = require('./smartTruncation');
          const contextBudget = Number(process.env.KHY_CONTEXT_TOKEN_LIMIT) || 65536;
          const truncResult = _smartTrunc.truncate(tr.tool, text, { contextBudget });
          if (truncResult.truncated) {
            const omitted = truncResult.originalLen - truncResult.text.length;
            parts.push(`Result: ${truncResult.text}\n... [${truncResult.strategy}: ${omitted} chars omitted, ${Math.ceil(omitted / 4)} est. tokens saved]`);
          } else {
            parts.push(`Result: ${truncResult.text}`);
          }
        } catch {
          // Fallback: simple hard truncation
          const maxLen = 50000;
          if (text.length > maxLen) {
            parts.push(`Result: ${text.slice(0, maxLen)}\n... [truncated ${text.length - maxLen} chars]`);
          } else {
            parts.push(`Result: ${text}`);
          }
        }
      } else {
        parts.push('Result: Success');
      }
    } else {
      // Structured error (ToolError) vs legacy string error
      const err = tr.result.error;
      if (err && typeof err === 'object' && err.code) {
        parts.push(`[ERROR:${err.code}] ${err.message}`);
        if (err.hint) parts.push(`Hint: ${err.hint}`);
        parts.push(`Retryable: ${err.retryable ? 'yes' : 'no'}`);
      } else {
        // Safely stringify error objects to avoid "[object Object]" display
        const errStr = (err && typeof err === 'object')
          ? (err.message || JSON.stringify(err))
          : (err || 'Unknown error');
        parts.push(`Error: ${errStr}`);
        if (tr.result && tr.result.hint) {
          parts.push(`Hint: ${tr.result.hint}`);
        }
      }
    }
    parts.push('');
  }

  return parts.join('\n');
}

/**
 * Remove <tool_call> tags from text for display purposes.
 */
function _stripToolCalls(text) {
  if (!text) return '';
  return text
    .replace(/<tool_call>[\s\S]*?<\/tool_call>/g, '')
    .replace(/【\s*调用\s*([^：:\]】\n]{1,32})\s*(?:[：:]\s*([^】]*?))?\s*】/g, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

/**
 * Remove <execution_plan> tags from text for display purposes.
 */
function _stripExecutionPlan(text) {
  if (!text) return text;
  return text.replace(/<execution_plan>[\s\S]*?<\/execution_plan>/g, '').trim();
}

/**
 * Heuristic: does this look like a "work preface" instead of a real answer?
 */
function _looksLikeProgressOnlyReply(text) {
  if (!text) return false;
  const t = text.replace(/\s+/g, ' ').trim();
  if (!t) return false;
  if (t.length > 220) return false;
  if (/<tool_call>/i.test(t)) return false;
  if (/```/.test(t)) return false;
  if (/\n\s*\d+\.\s+/.test(t)) return false;
  const cn = /^(我来|我先|让我|正在|继续|先去|下面我来|我会先)/;
  const en = /^(let me|i(?:'| a)m (?:going to|now)|continuing to|i will)/i;
  const hasTaskVerb = /(检查|排查|查看|分析|探索|处理|修复|定位|梳理|总结|review|inspect|check|analy[sz]e|investigate)/i.test(t);
  return (cn.test(t) || en.test(t)) && hasTaskVerb;
}

/**
 * Heuristic: does the user request likely require concrete actions/tools?
 */
function _looksLikeActionRequest(text) {
  if (!text) return false;
  return /(继续|检查|排查|修复|实现|修改|review|审查|自我检查|排错|定位|运行|执行|测试|验证|debug|调试|看下|看看)/i.test(text);
}

function _looksLikeAppLaunchRequest(text) {
  if (!text) return false;
  const raw = String(text || '').trim();
  if (!raw) return false;

  // If the user pasted multi-line logs/transcripts, bias to the last meaningful
  // line because that is usually the actual question.
  const lines = raw.split('\n').map(s => String(s || '').trim()).filter(Boolean);
  let focus = lines.length > 1 ? lines[lines.length - 1] : raw;
  focus = focus.replace(/^>\s*/, '').trim();
  if (!focus) return false;

  const issueMarkers = /(之后|下一句|下句话|上一句|本轮|上轮|变成|重复|误判|为什么|怎么|问题|故障|异常|报错|日志|记录|复现|bug)/i;
  const directCn = /^(?:请|帮我|麻烦|可以|能否|请你|帮忙)?\s*(?:打开|启动|运行)\s*[^\n]{1,48}$/i;
  const directEn = /^(?:please\s+)?(?:open|launch|start|run)\b[\s\S]{1,48}$/i;
  const target = _extractAppTargetFromUserMessage(focus);
  const shortTarget = target && target.length <= 24;

  if (shortTarget && (directCn.test(focus) || directEn.test(focus))) {
    return !issueMarkers.test(focus);
  }
  if (issueMarkers.test(focus)) return false;

  return /(打开|启动|运行).*(应用|程序|软件|工具|客户端|浏览器|编辑器|查看器|飞书|微信|qq|钉钉|lark|feishu|pdf|图片|图像)/i.test(focus)
    || /\b(open|launch|start|run)\b[\s\S]{0,40}\b(app|application|program|tool|editor|viewer|browser|lark|feishu|pdf|image|photo)\b/i.test(focus);
}

function _looksLikeProjectScaffoldRequest(text) {
  if (!text) return false;
  const raw = String(text || '').trim();
  if (!raw) return false;
  return /(创建|生成|搭建|初始化|新建).*(项目|工程|目录|文件|结构|脚手架)/i.test(raw)
    || /(批量|并行).*(创建|写入).*(文件|目录)/i.test(raw)
    || /\b(create|generate|scaffold|bootstrap|initialize)\b[\s\S]{0,48}\b(project|workspace|folder|directory|file|structure)\b/i.test(raw)
    || /\b(batch|parallel)\b[\s\S]{0,48}\b(write|create)\b[\s\S]{0,32}\b(files?|folders?)\b/i.test(raw);
}

function _isShellToolName(name = '') {
  const n = String(name || '').trim().toLowerCase();
  return n === 'shell_command' || n === 'shellcommand' || n === 'bash';
}

function _looksLikeShellAppProbeCommand(command = '') {
  const cmd = String(command || '').trim().toLowerCase();
  if (!cmd) return false;
  return /\b(which|whereis|command\s+-v|type\s+-p|ps\s+aux|pgrep|pidof|nohup|xdg-open|gtk-launch|gio\s+launch)\b/.test(cmd)
    || /\bgrep\s+-i\b/.test(cmd);
}

function _normalizeAppTarget(target = '') {
  let text = String(target || '').trim();
  if (!text) return '';

  text = text
    .replace(/^(请|帮我|麻烦|能否|可以|帮忙)\s*/g, '')
    .replace(/^(打开|启动|运行)\s*/g, '')
    .replace(/^(一个|一款|一下|下)\s*/g, '')
    .replace(/(应用|程序|软件|工具|客户端|浏览器|app|application|program|tool|client|browser)$/ig, '')
    .replace(/^(能|可以)\s*/g, '')
    .replace(/^编辑\s*/g, '')
    .replace(/^用于\s*/g, '')
    .replace(/的$/g, '')
    .trim();

  if (/pdf/i.test(text) && text.length > 12) return 'pdf';
  return text;
}

function _extractAppTargetFromShellCommand(command = '') {
  const raw = String(command || '').trim();
  if (!raw) return '';
  const normalized = raw.replace(/\s+/g, ' ');

  const launchLike = normalized.match(/^(?:nohup\s+)?([a-z0-9._+-]+)/i);
  if (launchLike) {
    const bin = String(launchLike[1] || '').toLowerCase();
    const probeBins = new Set(['which', 'whereis', 'command', 'type', 'ps', 'pgrep', 'pidof', 'grep', 'bash', 'sh', 'zsh', 'env', 'nohup']);
    if (bin && !probeBins.has(bin)) return _normalizeAppTarget(bin);
  }

  const whichMatch = normalized.match(/\bwhich\s+(.+)$/i);
  if (whichMatch) {
    const tokens = whichMatch[1].split(/\s+/).filter(Boolean);
    for (const tokenRaw of tokens) {
      const token = String(tokenRaw || '').replace(/^['"`]+|['"`]+$/g, '');
      if (!token) continue;
      if (/^[|;&]/.test(token) || token.includes('||') || token.includes('&&') || token.includes(';')) break;
      if (/^\d+>/.test(token) || /^2>/.test(token) || /^1>/.test(token)) break;
      if (token.startsWith('-')) continue;
      if (/^[a-z0-9._+-]+$/i.test(token)) return _normalizeAppTarget(token.toLowerCase());
    }
  }

  const grepMatch = normalized.match(/\bgrep\s+(?:-[^\s]+\s+)*['"]?([a-z0-9._+-]{2,})['"]?/i);
  if (grepMatch) return _normalizeAppTarget(String(grepMatch[1] || '').toLowerCase());

  return '';
}

function _extractAppCandidatesFromShellCommand(command = '') {
  const out = [];
  const raw = String(command || '').trim();
  if (!raw) return out;
  const normalized = raw.replace(/\s+/g, ' ');

  const whichMatch = normalized.match(/\bwhich\s+(.+)$/i);
  if (whichMatch) {
    const tokens = whichMatch[1].split(/\s+/).filter(Boolean);
    for (const tokenRaw of tokens) {
      const token = String(tokenRaw || '').replace(/^['"`]+|['"`]+$/g, '');
      if (!token) continue;
      if (/^[|;&]/.test(token) || token.includes('||') || token.includes('&&') || token.includes(';')) break;
      if (/^\d+>/.test(token) || /^2>/.test(token) || /^1>/.test(token)) break;
      if (token.startsWith('-')) continue;
      if (/^[a-z0-9._+-]+$/i.test(token)) out.push(_normalizeAppTarget(token.toLowerCase()));
    }
  }

  const first = _extractAppTargetFromShellCommand(command);
  if (first) out.unshift(first);

  return [...new Set(out.filter(Boolean))];
}

function _extractAppTargetFromUserMessage(userMessage = '') {
  const raw = String(userMessage || '').trim();
  if (!raw) return '';

  if (/(图片|图像|image|photo).*(编辑器|editor)/i.test(raw)) return 'gimp';
  if (/pdf/i.test(raw) && /(编辑|修改|editor|edit)/i.test(raw)) return 'libreoffice';

  const quoted = raw.match(/["'“”](.+?)["'“”]/);
  if (quoted && quoted[1]) {
    const normalized = _normalizeAppTarget(quoted[1]);
    if (normalized) return normalized;
  }

  const cnVerb = raw.match(/(?:打开|启动|运行)\s*([^\n，。,;；:：]{1,80})/);
  if (cnVerb && cnVerb[1]) {
    const normalized = _normalizeAppTarget(cnVerb[1]);
    if (normalized) return normalized;
  }

  const enVerb = raw.match(/\b(?:open|launch|start|run)\b\s+([a-z0-9._+\-\s]{2,80})/i);
  if (enVerb && enVerb[1]) {
    const normalized = _normalizeAppTarget(enVerb[1]);
    if (normalized) return normalized;
  }

  if (/pdf/i.test(raw)) return 'pdf';
  return '';
}

function _extractErrorTextFromResult(result = {}) {
  const err = result?.error;
  if (!err) return '';
  if (typeof err === 'string') return err;
  if (typeof err === 'object') return [err.code, err.message, err.hint].filter(Boolean).join(' ');
  return String(err);
}

function _isShellExecutorUnavailableResult(result = {}) {
  if (!result || result.success) return false;
  const err = result.error;
  if (err && typeof err === 'object' && String(err.code || '').toLowerCase() === 'executor_unavailable') return true;
  const text = `${_extractErrorTextFromResult(result)} ${String(result.hint || '')}`.toLowerCase();
  return /fork:\s*retry:\s*resource temporarily unavailable/.test(text)
    || /cannot fork subprocess/.test(text)
    || /executor[_\s-]*unavailable/.test(text);
}

function _looksLikeInfoSearchRequest(text) {
  if (!text) return false;
  const raw = _sanitizeSearchSourceMessage(String(text || ''));
  if (!raw) return false;
  return /(搜索|搜一下|查一下|查查|新闻|热点|热搜|今日|今天|最新|时事|头条|文档|接口|参数|说明|官网|readme|manual|documentation|api|reference|web\s*search|search|news|headline|trending)/i.test(raw);
}

async function _recoverWebSearchAfterShellFailure(call, result, userMessage, toolCalling, execContext = {}) {
  if (!call || !_isShellToolName(call.name)) return result;
  const shellCommand = String(call.params?.command || '').trim();
  if (!shellCommand) return result;
  if (!_isShellExecutorUnavailableResult(result)) return result;
  if (!_looksLikeInfoSearchRequest(userMessage)) return result;

  const previousHint = String(result?.hint || '').trim();
  const normalizedQuery = String(userMessage || '').trim() || 'latest news';
  let fallback = null;
  let recoveredTarget = '';

  const _tryTool = async (toolName, params) => {
    try {
      const r = await toolCalling.executeTool(toolName, params, execContext);
      if (r && r.success) {
        recoveredTarget = toolName;
        return {
          ...r,
          success: true,
          _autoRecovered: true,
          _autoRecoveredFrom: 'shell_command',
          _autoRecoveredTarget: toolName,
        };
      }
      fallback = r;
      return null;
    } catch (err) {
      fallback = { success: false, error: err.message || `${toolName} failed` };
      return null;
    }
  };

  // Tier-1: web search (current/hot news, docs, web knowledge)
  const webRecovered = await _tryTool('web_search', { query: normalizedQuery });
  if (webRecovered) return webRecovered;

  // Tier-2: local/market symbol search fallback for degraded network environments
  const searchRecovered = await _tryTool('search', { keyword: normalizedQuery });
  if (searchRecovered) return searchRecovered;

  // Tier-3: try toolSearch when model asks about tools/commands instead of external news
  if (/(工具|命令|command|tool)/i.test(normalizedQuery)) {
    const toolRecovered = await _tryTool('toolSearch', { query: normalizedQuery });
    if (toolRecovered) return toolRecovered;
  }

  const fallbackErr = String(
    _extractErrorTextFromResult(fallback) || fallback?.hint || 'web_search/search fallback failed'
  ).trim();
  const failHint = `Auto-recovery web_search/search fallback failed: ${fallbackErr}`;
  return {
    ...result,
    hint: previousHint ? `${previousHint} ${failHint}` : failHint,
    _autoRecoveredTarget: recoveredTarget || null,
  };
}

function _findLatestSuccessfulOpenAppEntry(toolCallLog = []) {
  if (!Array.isArray(toolCallLog) || toolCallLog.length === 0) return null;
  for (let i = toolCallLog.length - 1; i >= 0; i--) {
    const entry = toolCallLog[i];
    const tool = String(entry?.tool || '').trim().toLowerCase();
    if (!entry?.result?.success) continue;
    if (tool === 'open_app' || tool === 'openapp') return entry;
    if (_isShellToolName(tool) && entry.result?._autoRecoveredTarget) return entry;
  }
  return null;
}

function _findLatestFailedOpenAppEntry(toolCallLog = []) {
  if (!Array.isArray(toolCallLog) || toolCallLog.length === 0) return null;
  for (let i = toolCallLog.length - 1; i >= 0; i--) {
    const entry = toolCallLog[i];
    const tool = String(entry?.tool || '').trim().toLowerCase();
    if (tool !== 'open_app' && tool !== 'openapp') continue;
    if (entry?.result?.success) continue;
    return entry;
  }
  return null;
}

function _findLatestShellExecutorUnavailableEntry(toolCallLog = []) {
  if (!Array.isArray(toolCallLog) || toolCallLog.length === 0) return null;
  for (let i = toolCallLog.length - 1; i >= 0; i--) {
    const entry = toolCallLog[i];
    if (!entry || !_isShellToolName(entry.tool)) continue;
    if (_isShellExecutorUnavailableResult(entry.result)) return entry;
  }
  return null;
}

function _buildAppLaunchRecoveryCandidates(userMessage = '', shellEntry = null) {
  const candidates = [];
  const msgTarget = _extractAppTargetFromUserMessage(userMessage);
  if (msgTarget) candidates.push(msgTarget);
  const shellCommand = String(shellEntry?.params?.command || '').trim();
  if (shellCommand) candidates.push(..._extractAppCandidatesFromShellCommand(shellCommand));
  return [...new Set(candidates.map(v => String(v || '').trim()).filter(Boolean))];
}

async function _recoverOpenAppAfterAiInterruption(aiResult = {}, userMessage = '', toolCallLog = [], execContext = {}) {
  const errorType = String(aiResult?.errorType || '').trim().toLowerCase();
  if (!['process', 'cancelled', 'timeout', 'network', 'unknown'].includes(errorType)) return null;
  if (!_looksLikeAppLaunchRequest(userMessage)) return null;

  const interruptionText = `AI 通道在结果整理阶段中断（${errorType || 'unknown'}）。`;
  const succeededEntry = _findLatestSuccessfulOpenAppEntry(toolCallLog);
  if (succeededEntry) {
    const output = String(succeededEntry.result?.output || '').trim();
    if (output) return `${output}\n\n${interruptionText}`;
    const appName = String(
      succeededEntry.params?.name
      || succeededEntry.result?._autoRecoveredTarget
      || _extractAppTargetFromUserMessage(userMessage)
      || '目标应用'
    ).trim();
    return `已执行打开应用：${appName}。\n\n${interruptionText}`;
  }

  const failedOpenAppEntry = _findLatestFailedOpenAppEntry(toolCallLog);
  if (failedOpenAppEntry) {
    const appName = String(
      failedOpenAppEntry.params?.name
      || _extractAppTargetFromUserMessage(userMessage)
      || '目标应用'
    ).trim();
    const failureText = String(
      _extractErrorTextFromResult(failedOpenAppEntry.result)
      || failedOpenAppEntry.result?.hint
      || 'open_app failed'
    ).trim();
    return `打开应用 ${appName} 失败：${failureText}\n\n${interruptionText}`;
  }

  const shellEntry = _findLatestShellExecutorUnavailableEntry(toolCallLog);
  if (!shellEntry) return null;
  const candidates = _buildAppLaunchRecoveryCandidates(userMessage, shellEntry);
  if (candidates.length === 0) return null;

  let toolCalling = null;
  try {
    toolCalling = require('./toolCalling');
  } catch {
    return null;
  }

  let fallback = null;
  for (const appName of candidates) {
    try {
      fallback = await toolCalling.executeTool('open_app', { name: appName }, execContext);
    } catch (err) {
      fallback = { success: false, error: err.message || 'open_app failed' };
    }
    if (fallback && fallback.success) {
      const output = String(fallback.output || '').trim();
      return (output || `已执行打开应用：${appName}。`) + `\n\n${interruptionText}`;
    }
  }

  const candidateText = candidates[0];
  const failureText = String(
    _extractErrorTextFromResult(fallback) || fallback?.hint || 'open_app fallback failed'
  ).trim();
  return `打开应用 ${candidateText} 失败：${failureText}\n\n${interruptionText}`;
}

async function _recoverOpenAppAfterShellFailure(call, result, userMessage, toolCalling, execContext = {}) {
  if (!call || !_isShellToolName(call.name)) return result;
  const shellCommand = String(call.params?.command || '').trim();
  if (!shellCommand) return result;
  if (!_isShellExecutorUnavailableResult(result)) return result;
  if (!_looksLikeAppLaunchRequest(userMessage) && !_looksLikeShellAppProbeCommand(shellCommand)) return result;

  const candidates = _extractAppCandidatesFromShellCommand(shellCommand);
  const msgTarget = _extractAppTargetFromUserMessage(userMessage);
  if (msgTarget) candidates.push(msgTarget);
  const uniqueCandidates = [...new Set(candidates.filter(Boolean))];
  if (uniqueCandidates.length === 0) return result;

  let fallback = null;
  let usedTarget = '';
  for (const appName of uniqueCandidates) {
    usedTarget = appName;
    try {
      fallback = await toolCalling.executeTool('open_app', { name: appName }, execContext);
    } catch (err) {
      fallback = { success: false, error: err.message || 'open_app failed' };
    }
    if (fallback && fallback.success) {
      const out = String(fallback.output || '').trim();
      return {
        ...fallback,
        success: true,
        output: out || `Recovered via open_app("${appName}")`,
        _autoRecovered: true,
        _autoRecoveredFrom: 'shell_command',
        _autoRecoveredTarget: appName,
      };
    }
  }

  const fallbackErr = String(_extractErrorTextFromResult(fallback) || fallback?.hint || 'open_app failed').trim();
  const previousHint = String(result?.hint || '').trim();
  const failHint = `Auto-recovery open_app("${usedTarget}") failed: ${fallbackErr}`;
  return {
    ...result,
    hint: previousHint ? `${previousHint} ${failHint}` : failHint,
  };
}

function _unwrapPastedContent(raw = '') {
  return String(raw || '').replace(/<pasted-content>\n([\s\S]*?)\n<\/pasted-content>/g, '$1').trim();
}

function _looksLikeFilePathToken(token = '') {
  const t = String(token || '').trim().replace(/^['"`]+|['"`]+$/g, '');
  if (!t) return false;
  if (/^https?:\/\//i.test(t)) return false;
  if (/^[A-Za-z]:\\?$/.test(t)) return false;
  if (/[<>*?|]/.test(t)) return false;
  if (/[\\/]/.test(t)) return true;
  return /\.[a-zA-Z0-9]{1,10}$/.test(t);
}

function _looksLikeDirectoryToken(token = '') {
  const t = String(token || '').trim().replace(/^['"`]+|['"`]+$/g, '');
  if (!t) return false;
  if (/[<>*?|]/.test(t)) return false;
  if (/[\\/]\s*$/.test(t)) return true;
  if (!/[\\/]/.test(t)) return false;
  return !/\.[a-zA-Z0-9]{1,10}$/.test(t);
}

function _extractScaffoldSpecFromMessage(userMessage, options = {}) {
  const raw = _unwrapPastedContent(userMessage);
  if (!raw) return null;

  const defaultConcurrency = _parsePositiveInt(options.defaultConcurrency, 4, 1, 16);
  const maxFiles = _parsePositiveInt(options.maxFiles, 120, 1, 500);
  const maxDirs = _parsePositiveInt(options.maxDirs, 160, 1, 500);

  let root = '.';
  const explicitRoot = raw.match(/(?:^|\s)(?:root|cwd|目录|路径)\s*[:=：]\s*([^\s,，;；]+)/i);
  if (explicitRoot && explicitRoot[1]) root = explicitRoot[1].trim();

  const dirs = new Set();
  const files = new Map();
  const addDir = (value) => {
    const d = String(value || '').trim().replace(/^['"`]+|['"`]+$/g, '').replace(/[\\/]+$/g, '');
    if (!d || d === '.' || d === './') return;
    if (dirs.size < maxDirs) dirs.add(d);
  };
  const addFile = (filePath, content = '') => {
    const f = String(filePath || '').trim().replace(/^['"`]+|['"`]+$/g, '');
    if (!f) return;
    if (!files.has(f) && files.size < maxFiles) files.set(f, String(content || ''));
  };

  const inlineCodeTokens = [...raw.matchAll(/`([^`]+)`/g)].map(m => String(m[1] || '').trim()).filter(Boolean);
  for (const token of inlineCodeTokens) {
    if (_looksLikeFilePathToken(token)) addFile(token);
    else if (_looksLikeDirectoryToken(token)) addDir(token);
  }

  const lines = raw.split('\n').map(s => String(s || '').trim()).filter(Boolean);
  for (const lineRaw of lines) {
    const line = lineRaw
      .replace(/^\s*(?:[-*+•]|\d+[.)]|[└├│])\s*/g, '')
      .trim();
    if (!line) continue;

    const pair = line.match(/^([A-Za-z0-9_./\\-]+\.[A-Za-z0-9]{1,10})\s*(?::|=>)\s*([\s\S]*)$/);
    if (pair && pair[1]) {
      addFile(pair[1], pair[2] || '');
      continue;
    }

    if (line.endsWith('/') || line.endsWith('\\')) {
      addDir(line);
      continue;
    }

    if (_looksLikeFilePathToken(line)) {
      addFile(line);
      continue;
    }

    if (_looksLikeDirectoryToken(line)) {
      addDir(line);
      continue;
    }
  }

  for (const filePath of files.keys()) {
    const parent = path.dirname(filePath);
    if (parent && parent !== '.' && parent !== filePath) addDir(parent);
  }

  if (dirs.size === 0 && files.size === 0) return null;
  return {
    root,
    directories: [...dirs],
    files: [...files.entries()].map(([p, c]) => ({ path: p, content: c })),
    overwrite: false,
    writeConcurrency: defaultConcurrency,
  };
}

function _sanitizeSearchSourceMessage(raw = '', options = {}) {
  const collapseWhitespace = options.collapseWhitespace !== false;
  let text = String(raw || '')
    .replace(/<pasted-content>\n([\s\S]*?)\n<\/pasted-content>\s*/g, '$1\n')
    // Strip system-injected sections that pollute downstream intent/query parsing.
    .replace(/\[System (?:Skill|Memory|Context)[^\]]*\][\s\S]*?(?=\[System |$)/gi, ' ');

  if (collapseWhitespace) {
    return text.replace(/\s+/g, ' ').trim();
  }

  return text
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

function _buildSearchQueryCandidates(userMessage, maxCandidates = 3, mode = 'auto') {
  const source = _sanitizeSearchSourceMessage(userMessage);
  if (!source) return [];

  const resolvedMode = _resolveAutoWebSearchMode(source, mode);
  const limit = _parsePositiveInt(maxCandidates, 3, 1, 8);
  const candidates = [];
  const terms = [];
  const termSet = new Set();

  const pushCandidate = (value) => {
    const query = String(value || '').replace(/\s+/g, ' ').trim().slice(0, 200);
    if (!query || candidates.includes(query)) return;
    candidates.push(query);
  };

  const pushTerm = (value) => {
    const text = String(value || '').trim();
    if (!text) return;
    const low = text.toLowerCase();
    if (termSet.has(low)) return;
    termSet.add(low);
    terms.push(text);
  };

  // Keep the full user intent as the first candidate.
  pushCandidate(source);

  // Quoted phrases are usually explicit topic nouns.
  const quoted = source.match(/["'“”‘’《》「」『』][^"'“”‘’《》「」『』]{2,48}["'“”‘’《》「」『』]/g) || [];
  for (const phrase of quoted) {
    const clean = phrase.replace(/^["'“”‘’《》「」『』]|["'“”‘’《》「」『』]$/g, '').trim();
    if (clean) pushTerm(clean);
  }

  // Pull topic-like tokens and filter generic verbs/function words.
  const stopwords = new Set([
    '帮我', '请', '麻烦', '一下', '搜索', '搜一下', '查一下', '查查', '查找', '查询',
    '今天', '今日', '最新', '新闻', '热点', '热搜', '资料', '信息', '网页', '联网', '内网',
    'search', 'find', 'lookup', 'look', 'up', 'latest', 'today', 'news', 'trending', 'please', 'help', 'me',
  ]);
  const tokens = source.match(/[\u4e00-\u9fa5]{2,24}|[A-Za-z][A-Za-z0-9+#_.-]{1,31}/g) || [];
  for (const token of tokens) {
    const t = String(token || '').trim();
    const low = t.toLowerCase();
    if (!t || stopwords.has(low)) continue;
    pushTerm(t);
  }

  // Inject mode-aware directional queries before broad combinations.
  const topicSeed = terms.slice(0, 3).join(' ').trim() || source.slice(0, 80);
  if (topicSeed) {
    if (resolvedMode === 'news') {
      pushCandidate(`${topicSeed} 最新动态`);
      pushCandidate(`${topicSeed} latest news today`);
    } else if (resolvedMode === 'docs') {
      pushCandidate(`${topicSeed} official documentation`);
      pushCandidate(`${topicSeed} API reference`);
    } else if (resolvedMode === 'academic') {
      pushCandidate(`${topicSeed} arxiv paper`);
      pushCandidate(`${topicSeed} benchmark dataset`);
    } else if (resolvedMode === 'general') {
      pushCandidate(`${topicSeed} overview`);
    }
  }

  // Build noun-combination candidates from top extracted terms.
  const topTerms = terms.slice(0, 6);
  for (let i = 0; i < topTerms.length; i++) {
    pushCandidate(topTerms[i]);
    if (candidates.length >= limit) break;
    for (let j = i + 1; j < topTerms.length; j++) {
      pushCandidate(`${topTerms[i]} ${topTerms[j]}`);
      if (candidates.length >= limit) break;
    }
    if (candidates.length >= limit) break;
  }

  return candidates.slice(0, limit);
}

/**
 * Patch web_search / webSearch calls that have an empty or missing query.
 * Models sometimes decide to search but omit the query parameter entirely.
 * We derive a reasonable query from the user's original message so the
 * search doesn't fail with "Search query is empty".
 */
function _patchEmptySearchQuery(toolCalls, userMessage) {
  if (!Array.isArray(toolCalls) || !userMessage) return;
  const searchNames = new Set(['web_search', 'webSearch', 'websearch', 'search_web']);
  const configuredMode = process.env.KHY_AUTO_WEBSEARCH_MODE || 'auto';
  const fallbackQuery = _buildSearchQueryCandidates(userMessage, 1, configuredMode)[0] || '';
  for (const call of toolCalls) {
    if (!call || !searchNames.has(call.name)) continue;
    const q = String(call.params?.query || call.params?.q || '').trim();
    if (q) continue;
    // Use derived noun-focused query candidate.
    if (fallbackQuery) {
      if (!call.params) call.params = {};
      call.params.query = fallbackQuery;
    }
  }
}

function _isWebLookupToolName(toolName = '') {
  const normalized = String(toolName || '').toLowerCase().replace(/[\s_-]/g, '');
  return normalized === 'websearch'
    || normalized === 'webfetch'
    || normalized === 'websearchmcp'
    || normalized === 'search';
}

function _rewriteShellCallsForAppLaunch(toolCalls = [], userMessage = '') {
  if (!Array.isArray(toolCalls) || toolCalls.length === 0) return toolCalls;
  if (!_looksLikeAppLaunchRequest(userMessage)) return toolCalls;

  return toolCalls.map((call) => {
    if (!call || call.legacy) return call;
    if (!_isShellToolName(call.name)) return call;
    const command = String(call.params?.command || '').trim();
    if (!command || !_looksLikeShellAppProbeCommand(command)) return call;

    const appName = _extractAppTargetFromShellCommand(command) || _extractAppTargetFromUserMessage(userMessage);
    if (!appName) return call;

    return {
      ...call,
      name: 'open_app',
      params: { name: appName },
      _compatRewritten: true,
      _originalShellCommand: command,
    };
  });
}

function _filterToolCallsByIntent(toolCalls = [], userMessage = '') {
  if (!Array.isArray(toolCalls) || toolCalls.length === 0) {
    return { kept: toolCalls, removed: [] };
  }

  const allowOpenApp = _looksLikeAppLaunchRequest(userMessage);
  if (allowOpenApp) {
    return { kept: toolCalls, removed: [] };
  }

  const kept = [];
  const removed = [];
  for (const call of toolCalls) {
    const normalized = String(call?.name || '').toLowerCase().replace(/[\s_-]/g, '');
    if (normalized === 'openapp') removed.push(call);
    else kept.push(call);
  }

  return { kept, removed };
}

function _buildAppLaunchToolNudge(userMessage, previousReply) {
  return [
    '[System follow-up: app-launch intent detected]',
    'The user is asking to launch an application.',
    'Choose tools based on intent, not command probing.',
    'If launching is feasible, call open_app with the most likely app name inferred from user language.',
    'Use shell_command only after open_app fails and explain why.',
    '',
    '[Required next output]',
    '- Either output at least one <tool_call>...</tool_call> immediately,',
    '- Or explain a concrete runtime blocker (for example: no graphical session) with actionable next step.',
    '',
    `[Original user request]\n${userMessage}`,
    '',
    `[Previous response]\n${previousReply}`,
  ].join('\n');
}

/**
 * Build a one-shot continuation nudge when AI returns no tool calls.
 */
function _buildNoToolCallNudge(userMessage, previousReply) {
  return [
    '[System follow-up: continue execution]',
    'The previous response looks like a progress note without tool execution.',
    'Continue immediately.',
    'Choose one path only:',
    '1) If actions are needed, output one or more <tool_call>...</tool_call> now.',
    '   You may also use natural format like: 【调用工具名：参数】.',
    '2) If no tool is needed, output the final complete answer now.',
    'Do not output another progress preface.',
    '',
    `[Original user request]\n${userMessage}`,
    '',
    `[Previous response]\n${previousReply}`,
  ].join('\n');
}

function _buildWebSearchToolNudge(userMessage, previousReply) {
  return [
    '[System follow-up: web-search required]',
    'The user request likely needs current external information.',
    'In your next response, choose one path only:',
    '1) Call web_search immediately with a concrete query derived from the user request.',
    '2) If web_search is unavailable, explain the concrete blocker and provide a best-effort answer with uncertainty.',
    'Do not output another progress preface.',
    '',
    '[Required]',
    '- Prefer <tool_call>{"name":"web_search","params":{"query":"..."}}</tool_call>.',
    '- Query must be non-empty and specific.',
    '',
    `[Original user request]\n${userMessage}`,
    '',
    `[Previous response]\n${previousReply}`,
  ].join('\n');
}

function _buildScaffoldToolNudge(userMessage, previousReply) {
  return [
    '[System follow-up: project scaffolding required]',
    'The user request is about creating project folders/files quickly.',
    'In your next response, choose one path only:',
    '1) Call scaffoldFiles now with root/directories/files and writeConcurrency.',
    '2) If scaffoldFiles is unavailable, call writeFile/editFile with a concrete ordered plan immediately.',
    'Do not output another progress preface.',
    '',
    '[Required]',
    '- Prefer <tool_call>{"name":"scaffoldFiles","params":{"root":"...","directories":[...],"files":[{"path":"...","content":"..."}],"writeConcurrency":4}}</tool_call>.',
    '- Use batch creation and parallel writes when creating many files.',
    '',
    `[Original user request]\n${userMessage}`,
    '',
    `[Previous response]\n${previousReply}`,
  ].join('\n');
}

/**
 * Capture before/after context for writeFile so UI can render real diffs.
 * @param {{name: string, params: object}} call
 * @returns {{filePath: string, beforeContent: string, afterContent: string}|null}
 */
function _captureWriteFileDiffContext(call) {
  try {
    if (!call || !call.name) return null;
    const toolName = String(call.name).toLowerCase().replace(/[\s_-]/g, '');
    const cwd = process.env.KHYQUANT_CWD || process.cwd();

    // writeFile / write_file / write
    if (toolName === 'writefile' || toolName === 'write') {
      const relPath = call.params?.path || call.params?.file_path || call.params?.filePath;
      const afterContent = call.params?.content;
      if (!relPath || typeof afterContent !== 'string') return null;
      const filePath = path.isAbsolute(relPath) ? relPath : path.resolve(cwd, relPath);
      const beforeContent = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf-8') : '';
      return { filePath, beforeContent, afterContent };
    }

    // editFile / edit_file / edit / multiedit
    if (toolName === 'editfile' || toolName === 'edit' || toolName === 'multiedit') {
      const relPath = call.params?.file_path || call.params?.filePath || call.params?.path;
      if (!relPath) return null;
      const filePath = path.isAbsolute(relPath) ? relPath : path.resolve(cwd, relPath);
      if (!fs.existsSync(filePath)) return null;
      const beforeContent = fs.readFileSync(filePath, 'utf-8');
      const oldStr = call.params?.old_string || call.params?.oldString || '';
      const newStr = call.params?.new_string || call.params?.newString || '';
      if (!oldStr) return null;
      let afterContent;
      if (call.params?.replace_all || call.params?.replaceAll) {
        afterContent = beforeContent.split(oldStr).join(newStr);
      } else {
        const pos = beforeContent.indexOf(oldStr);
        afterContent = pos >= 0
          ? beforeContent.slice(0, pos) + newStr + beforeContent.slice(pos + oldStr.length)
          : beforeContent;
      }
      if (beforeContent === afterContent) return null;
      return { filePath, beforeContent, afterContent };
    }

    return null;
  } catch {
    return null;
  }
}

// ── Task Decomposition ────────────────────────────────────────────

/**
 * Determine if a user message represents a complex multi-step task.
 * Uses multi-dimensional heuristics instead of simple keyword matching:
 *   1. Length — longer messages tend to be multi-step
 *   2. Structure — numbered lists, bullet points, multiple sentences
 *   3. Scope — mentions multiple files, components, or actions
 *   4. Connectives — sequential/parallel intent markers (weighted, not binary)
 *
 * @param {string} message
 * @returns {boolean}
 */
function _isComplexTask(message) {
  if (!message) return false;

  let score = 0;

  // Dimension 1: Length (graduated scoring)
  if (message.length > 500) score += 3;
  else if (message.length > 300) score += 2;
  else if (message.length > 150) score += 1;

  // Dimension 2: Structure indicators
  const lines = message.split('\n').filter(l => l.trim());
  if (lines.length >= 4) score += 2;
  // Numbered lists or bullet points
  const listItems = lines.filter(l => /^\s*(\d+[.、)）]|[-*·•►▶])\s/.test(l));
  if (listItems.length >= 2) score += 2;
  // Multiple sentences (Chinese or English)
  const sentenceCount = (message.match(/[。！？.!?]/g) || []).length;
  if (sentenceCount >= 3) score += 1;

  // Dimension 3: Scope — mentions of multiple targets
  const filePatterns = (message.match(/\.\w{1,5}\b/g) || []).length; // .js, .py, .vue etc.
  if (filePatterns >= 2) score += 1;
  const pathPatterns = (message.match(/[/\\]\w+/g) || []).length;
  if (pathPatterns >= 3) score += 1;
  // Multiple action verbs
  const actionVerbs = (message.match(/(修改|创建|删除|添加|修复|重构|实现|fix|add|create|update|remove|refactor|implement)/gi) || []).length;
  if (actionVerbs >= 3) score += 2;
  else if (actionVerbs >= 2) score += 1;

  // Dimension 4: Sequential/parallel connectives (lighter weight than before)
  const connectives = (message.match(/(然后|接着|之后|首先|最后|同时|分别|再|还需要|还要|then|first|next|finally|after that|also)/gi) || []).length;
  if (connectives >= 2) score += 2;
  else if (connectives >= 1) score += 1;

  // Threshold: score >= 4 is considered complex
  return score >= 4;
}

/**
 * Inject planning instruction into the user message so AI outputs
 * an execution plan alongside tool calls in the same response.
 * @param {string} message
 * @returns {string}
 */
function _injectPlanningPrompt(message) {
  const planInst = [
    '[System: This task has multiple steps.',
    'Before starting, briefly outline your approach (2-5 numbered steps with specific file/function names).',
    'Wrap it in <execution_plan> tags. Then immediately begin the first step.',
    'Between steps, provide a brief status update. Do NOT just silently chain tool calls.]',
  ].join(' ');
  return `${planInst}\n\n${message}`;
}

/**
 * Parse an execution plan from AI response text.
 * @param {string} text - AI response
 * @returns {{steps: Array<{id: number, description: string, toolHint: string, status: string}>} | null}
 */
function _parseExecutionPlan(text) {
  if (!text) return null;
  const match = text.match(/<execution_plan>([\s\S]*?)<\/execution_plan>/);
  if (!match) return null;

  const planText = match[1].trim();
  const lines = planText.split('\n').filter(l => l.trim());
  const steps = [];

  for (const line of lines) {
    // Match patterns like: "1. [shell_command] Run git status" or "1. Check the file"
    const stepMatch = line.match(/^\s*(\d+)\.\s*(?:\[([^\]]*)\]\s*)?(.+)/);
    if (stepMatch) {
      steps.push({
        id: parseInt(stepMatch[1], 10),
        toolHint: stepMatch[2] || '',
        description: stepMatch[3].trim(),
        status: 'pending',
      });
    }
  }

  return steps.length > 0 ? { steps } : null;
}

/**
 * Match a tool call to the most likely plan step.
 * Uses tool name matching and sequential advancement.
 * @param {string} toolName
 * @param {object} params
 * @param {object} plan - { steps: [...] }
 * @param {number} currentStep - Current plan step index
 * @returns {number} Matched step index, or -1 if no match
 */
function _matchToolCallToStep(toolName, params, plan, currentStep) {
  if (!plan || !plan.steps || plan.steps.length === 0) return -1;

  // Try matching current step first (sequential advancement)
  if (currentStep < plan.steps.length) {
    const step = plan.steps[currentStep];
    if (step.status !== 'completed') {
      // Match by tool hint
      if (step.toolHint && toolName.includes(step.toolHint.replace(/_/g, ''))) {
        return currentStep;
      }
      // Match by description containing tool-related keywords
      const desc = step.description.toLowerCase();
      const normalizedTool = toolName.replace(/_/g, ' ').toLowerCase();
      if (desc.includes(normalizedTool) || desc.includes(toolName)) {
        return currentStep;
      }
      // Default: advance sequentially
      return currentStep;
    }
  }

  // Look ahead for a matching step
  for (let i = currentStep + 1; i < plan.steps.length; i++) {
    const step = plan.steps[i];
    if (step.status === 'completed') continue;
    if (step.toolHint && toolName.includes(step.toolHint.replace(/_/g, ''))) {
      return i;
    }
  }

  return -1;
}

/**
 * Check if the tool-use loop is enabled via feature flag.
 * @returns {boolean}
 */
function isEnabled() {
  return process.env.KHY_TOOL_LOOP !== 'false';
}

// ── Exports ────────────────────────────────────────────────────────

module.exports = {
  runToolUseLoop,
  isEnabled,
  MAX_ITERATIONS,
  MAX_ELAPSED_MS_DEFAULT,
  // Exposed for testing
  _parseToolCalls,
  _stripToolCalls,
  _buildToolResultMessage,
  _isComplexTask,
  _parseExecutionPlan,
  _matchToolCallToStep,
  _resolveMaxIterations,
  _resolveMaxElapsedMs,
  _formatDurationMs,
  _loadCapabilityPolicy,
  _assessExecutionCapability,
  _looksLikeInfoSearchRequest,
  _looksLikeProjectScaffoldRequest,
  _extractScaffoldSpecFromMessage,
  _sanitizeSearchSourceMessage,
  _resolveAutoWebSearchMode,
  _buildSearchQueryCandidates,
  _recoverWebSearchAfterShellFailure,
  _looksLikeAppLaunchRequest,
  _extractAppTargetFromUserMessage,
  _filterToolCallsByIntent,
  _rewriteShellCallsForAppLaunch,
};
