'use strict';

/**
 * toolGuards.js — Built-in ToolGuard hooks for tool execution safety.
 *
 * Guards shipped with the system:
 *   1. OutputSizeGuard    (PostToolUse)  — truncate outputs >200KB
 *   2. EditBoundaryGuard  (PreToolUse)  — block edits outside project root
 *   3. ShellTimeoutGuard  (PreToolUse)  — warn on shell commands without timeout
 *   4. PriorReadGuard     (PreToolUse)  — block edits on files not yet read (G5)
 *   5. FileStaleGuard     (PreToolUse)  — block edits on externally modified files (G5 TOCTOU)
 *   6. LspDiagnosticsGuard (PostToolUse) — inject LSP diagnostics after edits (G1)
 *
 * Disable all guards: KHY_TOOL_GUARDS=false
 * Disable individual guards: add source ID to hooks.json "disabled" array
 */

const fs = require('fs');
const path = require('path');

const MAX_OUTPUT_BYTES = 200 * 1024; // 200KB

/**
 * PostToolUse guard: truncate tool output exceeding MAX_OUTPUT_BYTES.
 */
function outputSizeGuard(ctx) {
  if (ctx.result && typeof ctx.result === 'object') {
    const output = ctx.result.output || ctx.result.content || ctx.result.text;
    if (typeof output === 'string' && output.length > MAX_OUTPUT_BYTES) {
      return {
        action: 'modify',
        result: {
          ...ctx.result,
          output: output.slice(0, MAX_OUTPUT_BYTES) + '\n... [truncated by OutputSizeGuard]',
          _truncated: true,
          _originalSize: output.length,
        },
      };
    }
  }
  return { action: 'allow' };
}

/**
 * PreToolUse guard: block file edits/writes outside the project root.
 */
function editBoundaryGuard(ctx) {
  const filePath = ctx.params?.file_path || ctx.params?.filePath || ctx.params?.path;
  if (!filePath) return { action: 'allow' };

  const root = process.env.KHYQUANT_CWD || process.cwd();
  let abs;
  try {
    abs = path.resolve(root, filePath);
  } catch {
    return { action: 'allow' }; // can't resolve — let the tool handle it
  }

  const normalizedRoot = root.endsWith(path.sep) ? root : root + path.sep;
  if (abs !== root && !abs.startsWith(normalizedRoot)) {
    return {
      action: 'block',
      reason: `Edit outside project root blocked: ${abs} is not under ${root}`,
    };
  }
  return { action: 'allow' };
}

/**
 * PreToolUse guard: warn when shell commands lack a timeout parameter.
 */
function shellTimeoutGuard(ctx) {
  if (!ctx.params?.timeout && !ctx.params?.timeout_ms) {
    return {
      action: 'modify',
      params: {
        ...ctx.params,
        _timeoutWarning: 'No timeout specified for shell command. Consider adding timeout_ms to prevent hanging.',
      },
    };
  }
  return { action: 'allow' };
}

// ── Rate Limit Guard (PreToolUse) ──────────────────────────────────

const _toolCallCounts = new Map(); // toolName → [timestamp, ...]
const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX = 50;

/**
 * PreToolUse guard: block tools called more than RATE_LIMIT_MAX times per minute.
 */
function rateLimitGuard(ctx) {
  const tool = ctx.toolName || ctx.params?._toolName;
  if (!tool) return { action: 'allow' };
  const now = Date.now();
  const history = _toolCallCounts.get(tool) || [];
  const recent = history.filter(ts => now - ts < RATE_LIMIT_WINDOW_MS);
  recent.push(now);
  _toolCallCounts.set(tool, recent);
  if (recent.length > RATE_LIMIT_MAX) {
    return {
      action: 'block',
      reason: `Rate limit: ${tool} called ${recent.length} times in ${RATE_LIMIT_WINDOW_MS / 1000}s (max ${RATE_LIMIT_MAX})`,
    };
  }
  return { action: 'allow' };
}

// ── Path Traversal Guard (PreToolUse) ─────────────────────────────

/**
 * PreToolUse guard: block file paths that escape the project root via '..' traversal.
 */
function pathTraversalGuard(ctx) {
  const fp = ctx.params?.file_path || ctx.params?.path || ctx.params?.filePath || '';
  if (!fp || !fp.includes('..')) return { action: 'allow' };
  if (!/\.\.[/\\]/.test(fp)) return { action: 'allow' };

  const root = process.env.KHYQUANT_CWD || process.cwd();
  try {
    const resolved = path.resolve(root, fp);
    const normalizedRoot = root.endsWith(path.sep) ? root : root + path.sep;
    if (resolved !== root && !resolved.startsWith(normalizedRoot)) {
      return {
        action: 'block',
        reason: `Path traversal detected: ${fp} resolves outside project root`,
      };
    }
  } catch { /* can't resolve — let the tool handle it */ }
  return { action: 'allow' };
}

// ── Error Recovery Guard (PostToolUse) ────────────────────────────

/**
 * PostToolUse guard: inject recovery hints for common error patterns.
 */
function errorRecoveryGuard(ctx) {
  const result = ctx.result;
  if (!result || result.success !== false) return { action: 'allow' };

  const error = result.error || result.output || '';
  let hint = null;
  if (/old_?string not found|no match/i.test(error)) {
    hint = 'Re-read the file to get current content, then retry with updated old_string.';
  } else if (/permission denied/i.test(error)) {
    hint = 'Check file permissions or use an alternative path.';
  } else if (/timed?\s*out/i.test(error)) {
    hint = 'Break the command into smaller steps or increase timeout.';
  }

  if (hint) {
    return { action: 'modify', result: { ...result, _recoveryHint: hint } };
  }
  return { action: 'allow' };
}

// ── Prior-Read Enforcement Guard (PreToolUse) — G5 ──────────────
const EDIT_TOOL_PATTERN = /^(editFile|edit_file|edit|write_file|writeFile|apply_patch)$/i;

function _resolveFilePath(fp) {
  if (!fp) return null;
  try {
    return path.resolve(process.env.KHYQUANT_CWD || process.cwd(), fp);
  } catch { return null; }
}

/**
 * PreToolUse guard: block file edits/writes when the file has not been read
 * in the current session. Prevents blind edits on files the model hasn't seen.
 */
function priorReadGuard(ctx) {
  const fp = ctx.params?.file_path || ctx.params?.path || ctx.params?.filePath;
  if (!fp) return { action: 'allow' };
  // apply_patch operates on multiple files — skip per-file check here
  if (/^apply_patch$/i.test(ctx.toolName)) return { action: 'allow' };
  const abs = _resolveFilePath(fp);
  if (!abs) return { action: 'allow' };
  const readMap = ctx._fileReadHashes;
  if (!readMap) return { action: 'allow' }; // no tracking available = allow (backward compat)
  if (!readMap.has(abs)) {
    return {
      action: 'block',
      reason: `Prior-read required: ${fp} was not read this session. Use the Read tool first.`,
    };
  }
  return { action: 'allow' };
}

/**
 * PreToolUse guard: block edits on files that have been externally modified
 * since the last read (TOCTOU check via mtime + size).
 */
function fileStaleGuard(ctx) {
  const fp = ctx.params?.file_path || ctx.params?.path || ctx.params?.filePath;
  if (!fp) return { action: 'allow' };
  if (/^apply_patch$/i.test(ctx.toolName)) return { action: 'allow' };
  const abs = _resolveFilePath(fp);
  if (!abs) return { action: 'allow' };
  const readMap = ctx._fileReadHashes;
  const entry = readMap?.get(abs);
  if (!entry || entry.mtime == null) return { action: 'allow' };
  try {
    const st = fs.statSync(abs);
    if (st.mtimeMs !== entry.mtime || st.size !== entry.size) {
      return {
        action: 'block',
        reason: `File changed since last read (external modification detected). Re-read before editing: ${fp}`,
      };
    }
  } catch { /* file gone — let the tool handle it */ }
  return { action: 'allow' };
}

// ── LSP Post-Edit Diagnostics Guard (PostToolUse) — G1 ──────────

const LSP_DIAG_WAIT_MS = parseInt(process.env.KHY_LSP_DIAG_WAIT_MS, 10) || 200;

/**
 * PostToolUse guard: after successful file edits, collect LSP diagnostics
 * and attach them to the result so the AI can self-correct.
 */
async function lspDiagnosticsGuard(ctx) {
  if (!ctx.result?.success) return { action: 'allow' };
  const fp = ctx.params?.file_path || ctx.params?.path || ctx.params?.filePath;
  if (!fp) return { action: 'allow' };

  try {
    let lspClient;
    try { lspClient = require('./lspClient'); } catch { return { action: 'allow' }; }
    if (!lspClient || typeof lspClient.getDiagnostics !== 'function') return { action: 'allow' };
    if (typeof lspClient.isInitialized === 'function' && !lspClient.isInitialized()) return { action: 'allow' };

    const abs = _resolveFilePath(fp);
    if (!abs) return { action: 'allow' };

    // Notify LSP server of file change
    if (typeof lspClient.didSave === 'function') {
      await lspClient.didSave(abs);
    } else if (typeof lspClient.didChange === 'function') {
      await lspClient.didChange(abs);
    }

    // Wait briefly for diagnostics push from LSP server
    await new Promise(r => setTimeout(r, LSP_DIAG_WAIT_MS));

    const diags = lspClient.getDiagnostics(abs) || [];
    if (diags.length === 0) return { action: 'allow' };

    const formatted = diags.map(d => {
      const line = (d.range?.start?.line || 0) + 1;
      const sev = d.severity === 1 ? 'Error' : d.severity === 2 ? 'Warning' : 'Info';
      const code = d.code ? ` (${d.code})` : '';
      return `  Line ${line}: [${sev}] ${d.message}${code}`;
    }).join('\n');

    return {
      action: 'modify',
      result: {
        ...ctx.result,
        _lspDiagnostics: `<diagnostics file="${fp}">\n${formatted}\n</diagnostics>`,
      },
    };
  } catch { return { action: 'allow' }; }
}

/**
 * Register all built-in ToolGuard hooks with the hook system.
 * @param {Object} hookSystem - The hook system facade (hookSystem.js)
 * @returns {number} Number of guards registered
 */
function registerBuiltinGuards(hookSystem) {
  if (process.env.KHY_TOOL_GUARDS === 'false') return 0;
  if (!hookSystem || typeof hookSystem.registerFunction !== 'function') return 0;

  let count = 0;

  hookSystem.registerFunction('PostToolUse', outputSizeGuard, {
    source: 'builtin:OutputSizeGuard',
    priority: 10,
  });
  count++;

  hookSystem.registerFunction('PreToolUse', editBoundaryGuard, {
    source: 'builtin:EditBoundaryGuard',
    priority: 10,
    pattern: 'editFile|edit_file|edit|write_file|writeFile',
  });
  count++;

  hookSystem.registerFunction('PreToolUse', shellTimeoutGuard, {
    source: 'builtin:ShellTimeoutGuard',
    priority: 10,
    pattern: 'shell_command|shellCommand|bash',
  });
  count++;

  hookSystem.registerFunction('PreToolUse', rateLimitGuard, {
    source: 'builtin:RateLimitGuard',
    priority: 5,
  });
  count++;

  hookSystem.registerFunction('PreToolUse', pathTraversalGuard, {
    source: 'builtin:PathTraversalGuard',
    priority: 5,
    pattern: 'editFile|edit_file|edit|write_file|writeFile|read_file|readFile',
  });
  count++;

  hookSystem.registerFunction('PostToolUse', errorRecoveryGuard, {
    source: 'builtin:ErrorRecoveryGuard',
    priority: 15,
  });
  count++;

  // ── G5: Prior-read + TOCTOU guards ─────────────────────────────

  hookSystem.registerFunction('PreToolUse', priorReadGuard, {
    source: 'builtin:PriorReadGuard',
    priority: 8,
    pattern: 'editFile|edit_file|edit|write_file|writeFile|apply_patch',
  });
  count++;

  hookSystem.registerFunction('PreToolUse', fileStaleGuard, {
    source: 'builtin:FileStaleGuard',
    priority: 8,
    pattern: 'editFile|edit_file|edit|write_file|writeFile|apply_patch',
  });
  count++;

  // ── G1: LSP post-edit diagnostics injection ────────────────────

  hookSystem.registerFunction('PostToolUse', lspDiagnosticsGuard, {
    source: 'builtin:LspDiagnosticsGuard',
    priority: 12,
    pattern: 'editFile|edit_file|edit|write_file|writeFile|apply_patch',
  });
  count++;

  return count;
}

module.exports = {
  outputSizeGuard,
  editBoundaryGuard,
  shellTimeoutGuard,
  rateLimitGuard,
  pathTraversalGuard,
  errorRecoveryGuard,
  priorReadGuard,
  fileStaleGuard,
  lspDiagnosticsGuard,
  registerBuiltinGuards,
  MAX_OUTPUT_BYTES,
  RATE_LIMIT_WINDOW_MS,
  RATE_LIMIT_MAX,
  _toolCallCounts,
};
