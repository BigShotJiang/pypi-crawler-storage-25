'use strict';

/**
 * agenticHarnessService.js
 *
 * Five-pillar runtime composition for:
 *   1) Context engineering
 *   2) Agent loop resiliency
 *   3) Skills activation
 *   4) Memory engineering
 *   5) Harness-level observability
 *
 * This module does not replace existing services. It assembles them into one
 * reusable entrypoint so CLI/REPL/sub-agents can share the same workflow.
 */

const crypto = require('crypto');
const path = require('path');
const { AgentContext } = require('./agentContext');
const { routeContextStrategy, truncateToolResults } = require('./contextRouter');
const { compress } = require('./contextCompressor');
const { estimateTokens } = require('./contextWasm');
const { runToolUseLoop } = require('./toolUseLoop');
const { retryWithBackoff, isRetryableError } = require('./retryWithBackoff');
const backgroundTaskManager = require('./backgroundTaskManager');
const projectMemoryService = require('./projectMemoryService');
const memdir = require('../memdir');
const skills = require('../skills');

const DEFAULTS = Object.freeze({
  contextBudget: 128000,
  retryAttempts: 2,
  retryMinDelayMs: 700,
  retryMaxDelayMs: 5000,
  memoryHintLimit: 4,
  skillHintLimit: 6,
  cacheTtlMs: 120000,
  maxCacheEntries: 256,
  maxContinuationRounds: 3,
  continuationCooldownMs: 1500,
  maxRemediationRounds: 2,
});

function createAgenticHarness(options = {}) {
  const cfg = {
    ...DEFAULTS,
    ...(options || {}),
  };

  const hintCache = _createTtlCache(cfg.cacheTtlMs, cfg.maxCacheEntries);
  const vectorRetriever = typeof cfg.vectorRetriever === 'function' ? cfg.vectorRetriever : null;

  async function buildContextPacket(input = {}) {
    const userMessage = String(input.userMessage || '').trim();
    const systemPrompt = String(input.systemPrompt || '');
    const contextBudget = Math.max(2048, Number(input.contextBudget || cfg.contextBudget) || cfg.contextBudget);
    const messages = _cloneMessages(input.messages);
    const recentFiles = _safeArray(input.recentFiles);
    const cwd = input.cwd || process.cwd();

    const contextRoute = routeContextStrategy(messages, systemPrompt, userMessage, contextBudget);
    let workingMessages = _cloneMessages(messages);

    if (contextRoute.route === 'truncate_tool_results_only' || contextRoute.route === 'compact_then_truncate') {
      truncateToolResults(workingMessages, Math.max(0, contextRoute.overflow));
    }

    if ((contextRoute.route === 'compact_only' || contextRoute.route === 'compact_then_truncate')
      && typeof input.callModelForCompression === 'function'
      && workingMessages.length > 0) {
      try {
        const compactResult = await compress(workingMessages, {
          estimateTokensFn: estimateTokens,
          callModelFn: input.callModelForCompression,
          contextWindowTokens: contextBudget,
        });
        if (Array.isArray(compactResult.compressed)) {
          workingMessages = compactResult.compressed;
        }
      } catch {
        // Compression is best-effort. The route info still indicates pressure.
      }
    }

    const cacheKey = _hashInput(JSON.stringify({
      userMessage,
      cwd,
      recentFiles,
      memoryHintLimit: input.memoryHintLimit || cfg.memoryHintLimit,
      skillHintLimit: input.skillHintLimit || cfg.skillHintLimit,
    }));

    let hints = hintCache.get(cacheKey);
    if (!hints) {
      const memoryHints = await _collectMemoryHints({
        userMessage,
        maxItems: Math.max(1, Number(input.memoryHintLimit || cfg.memoryHintLimit) || cfg.memoryHintLimit),
        vectorRetriever,
      });
      const skillHints = _collectSkillHints({
        userMessage,
        cwd,
        recentFiles,
        maxItems: Math.max(1, Number(input.skillHintLimit || cfg.skillHintLimit) || cfg.skillHintLimit),
      });
      hints = { memoryHints, skillHints };
      hintCache.set(cacheKey, hints);
    }

    const tokenEstimate = workingMessages.reduce((sum, msg) => sum + estimateTokens(msg.content || ''), 0)
      + estimateTokens(systemPrompt)
      + estimateTokens(userMessage);

    return {
      userMessage,
      cwd,
      messages: workingMessages,
      recentFiles,
      contextBudget,
      tokenEstimate,
      contextRoute,
      memoryHints: hints.memoryHints,
      skillHints: hints.skillHints,
    };
  }

  async function run(request = {}) {
    const userMessage = String(request.userMessage || '').trim();
    const chat = request.chat;
    if (!userMessage) throw new Error('agenticHarnessService: userMessage is required');
    if (typeof chat !== 'function') throw new Error('agenticHarnessService: chat function is required');

    const cwd = request.cwd || process.cwd();
    const chatOpts = request.chatOpts || {};
    const onEvent = typeof request.onEvent === 'function' ? request.onEvent : null;
    let effectiveUserMessage = userMessage;

    // ── Boulder State: resume from cross-session checkpoint ──
    const boulderResumeEnabled = !['0', 'false', 'off', 'no'].includes(
      String(process.env.KHY_BOULDER_RESUME || 'true').trim().toLowerCase(),
    );
    if (boulderResumeEnabled) {
      try {
        const { loadBoulderState, isSimilarMessage } = require('./boulderState');
        const saved = loadBoulderState(cwd);
        if (saved && saved.status === 'in_progress' && isSimilarMessage(userMessage, saved.userMessage)) {
          effectiveUserMessage = `[SYSTEM: Resuming from checkpoint. ${saved.iterations} iterations completed, round ${saved.continuationRound}. Modes: ${(saved.activatedModes || []).join(', ') || 'none'}. Continue where you left off.]\n\n${userMessage}`;
          if (onEvent) onEvent({ type: 'boulder_resume', previousIterations: saved.iterations, previousRound: saved.continuationRound });
        }
      } catch { /* boulderState not available — skip */ }
    }

    const startedAt = Date.now();
    const defaultLabel = `agentic:${path.basename(cwd)}`;
    const taskHandle = backgroundTaskManager.register({
      type: 'agent',
      label: request.taskLabel || defaultLabel,
      meta: {
        phase: 'prepare',
        cwd,
      },
    });

    const runtimeCtx = request.agentContext instanceof AgentContext
      ? request.agentContext
      : new AgentContext({
          role: request.role || 'general',
          toolFilter: request.toolFilter || null,
          config: request.agentConfig || {},
        });

    try {
      const contextPacket = await buildContextPacket({
        userMessage,
        messages: request.messages,
        systemPrompt: request.systemPrompt,
        contextBudget: request.contextBudget,
        cwd,
        recentFiles: request.recentFiles,
        memoryHintLimit: request.memoryHintLimit,
        skillHintLimit: request.skillHintLimit,
        callModelForCompression: async (text, opts) => chat(text, {
          ...chatOpts,
          ...opts,
          _isFollowUp: true,
        }),
      });

      taskHandle.task.meta.phase = 'loop';
      taskHandle.task.updatedAt = Date.now();

      let loopInput = _buildLoopInput(contextPacket);
      // If resuming from boulder state, prepend resume context
      if (effectiveUserMessage !== userMessage) {
        const resumePrefix = effectiveUserMessage.slice(0, effectiveUserMessage.indexOf('\n\n'));
        loopInput = resumePrefix + '\n\n' + loopInput;
      }
      const loopOptions = request.loopOptions || {};

      // Boulder State: checkpoint callback for toolUseLoop
      const _boulderCheckpoint = boulderResumeEnabled ? (info) => {
        try {
          const { saveBoulderState } = require('./boulderState');
          const { detectModes } = require('./intentGate');
          saveBoulderState(cwd, {
            taskId: taskHandle?.id,
            userMessage,
            toolCallLog: info.toolCallLog,
            iterations: info.iteration + (info._totalPreviousIterations || 0),
            continuationRound: info._continuationRound || 0,
            activatedModes: detectModes(userMessage).modes,
            status: 'in_progress',
          });
        } catch { /* best-effort */ }
      } : undefined;

      const runLoopOnce = async () => {
        const result = await runToolUseLoop(loopInput, {
          ...loopOptions,
          chat,
          chatOpts: {
            ...chatOpts,
            _agentContext: runtimeCtx,
          },
          onCheckpoint: _boulderCheckpoint,
        });
        if (_isRetryableLoopOutcome(result)) {
          const err = new Error(`Transient tool loop error: ${result.errorType}`);
          err.code = `tool-loop-${result.errorType}`;
          err.loopResult = result;
          throw err;
        }
        return result;
      };

      let loopResult;
      try {
        loopResult = await retryWithBackoff(runLoopOnce, {
          attempts: Math.max(1, Number(request.retryAttempts || cfg.retryAttempts) || cfg.retryAttempts),
          minDelayMs: Math.max(100, Number(request.retryMinDelayMs || cfg.retryMinDelayMs) || cfg.retryMinDelayMs),
          maxDelayMs: Math.max(500, Number(request.retryMaxDelayMs || cfg.retryMaxDelayMs) || cfg.retryMaxDelayMs),
          shouldRetry: (err) => {
            if (err && err.loopResult) return true;
            return isRetryableError(err);
          },
          onRetry: (retryInfo) => {
            if (!onEvent) return;
            onEvent({
              type: 'retry',
              attempt: retryInfo.attempt,
              maxAttempts: retryInfo.maxAttempts,
              delayMs: retryInfo.delayMs,
              error: retryInfo.err?.message || 'retry',
            });
          },
        });
      } catch (err) {
        if (err && err.loopResult) {
          loopResult = err.loopResult;
        } else {
          throw err;
        }
      }

      // ── Ralph Loop: auto-continuation when iteration limit is reached ──
      let activatedModes = [];
      try {
        const { detectModes } = require('./intentGate');
        activatedModes = detectModes(userMessage).modes || [];
      } catch { /* intentGate unavailable — keep default */ }
      const complexityFactor = _assessTaskComplexity(userMessage, activatedModes, loopResult);
      const adaptiveMaxRounds = Math.min(Math.ceil(3 * complexityFactor), 8);
      const maxContinuationRounds = Math.max(0, Math.min(adaptiveMaxRounds,
        Number(request.maxContinuationRounds ?? cfg.maxContinuationRounds) || adaptiveMaxRounds));
      let continuationRound = 0;
      let allToolCallLogs = [...(loopResult?.toolCallLog || [])];
      let totalIterations = loopResult?.iterations || 0;

      while (
        loopResult?.maxIterationsReached
        && continuationRound < maxContinuationRounds
        && _shouldAutoContinue(userMessage)
      ) {
        continuationRound++;
        if (onEvent) {
          onEvent({ type: 'continuation', round: continuationRound, maxRounds: maxContinuationRounds });
        }

        // Brief cooldown between rounds
        await new Promise(r => setTimeout(r, cfg.continuationCooldownMs));

        const summary = _buildContinuationSummary(loopResult);
        const continuationMessage = _buildContinuationInput(
          userMessage, summary, continuationRound, maxContinuationRounds,
        );

        try {
          loopResult = await runToolUseLoop(continuationMessage, {
            ...loopOptions,
            chat,
            chatOpts: {
              ...chatOpts,
              _agentContext: runtimeCtx,
            },
            onCheckpoint: _boulderCheckpoint,
          });
          allToolCallLogs.push(...(loopResult?.toolCallLog || []));
          totalIterations += (loopResult?.iterations || 0);

          // Boulder State: checkpoint after each continuation round
          try {
            const { saveBoulderState } = require('./boulderState');
            const { detectModes } = require('./intentGate');
            saveBoulderState(cwd, {
              taskId: taskHandle?.id,
              userMessage,
              toolCallLog: allToolCallLogs,
              iterations: totalIterations,
              continuationRound,
              activatedModes: detectModes(userMessage).modes,
              status: 'in_progress',
            });
          } catch { /* best-effort */ }
        } catch (contErr) {
          // Continuation failure is non-fatal; keep previous result
          if (onEvent) onEvent({ type: 'continuation_error', round: continuationRound, error: contErr?.message });
          break;
        }
      }

      // Merge continuation results
      if (continuationRound > 0) {
        loopResult = {
          ...loopResult,
          toolCallLog: allToolCallLogs,
          iterations: totalIterations,
          continuationRounds: continuationRound,
        };
      }

      // ── Delivery Gate: post-loop deliverable verification ──────────
      let deliveryGateReport = null;
      const deliveryGateEnabled = String(process.env.KHY_DELIVERY_GATE || 'true').trim().toLowerCase();
      const maxRemediationRounds = Math.max(0, Math.min(3,
        Number(process.env.KHY_DELIVERY_MAX_REMEDIATION ?? cfg.maxRemediationRounds) || cfg.maxRemediationRounds));

      if (
        !['0', 'false', 'off', 'no'].includes(deliveryGateEnabled)
        && !loopResult?.stopped
        && !loopResult?.errorType
        && maxRemediationRounds > 0
      ) {
        try {
          const { detectModes, getAcceptanceCriteria } = require('./intentGate');
          const modes = detectModes(userMessage);
          const criteria = getAcceptanceCriteria(modes.modes);

          if (criteria.length > 0) {
            const { evaluateDelivery, buildRemediationPrompt, inferProjectRoot } = require('./deliveryGate');
            const projectRoot = inferProjectRoot(allToolCallLogs.length > 0 ? allToolCallLogs : (loopResult?.toolCallLog || []), cwd);

            deliveryGateReport = evaluateDelivery(projectRoot, criteria, {
              finalResponse: String(loopResult?.finalResponse || ''),
              toolCallLog: allToolCallLogs.length > 0 ? allToolCallLogs : (loopResult?.toolCallLog || []),
            });

            let remediationRound = 0;

            while (
              !deliveryGateReport.passed
              && deliveryGateReport.missing.length > 0
              && remediationRound < maxRemediationRounds
            ) {
              remediationRound++;
              if (onEvent) {
                onEvent({
                  type: 'delivery_remediation',
                  round: remediationRound,
                  maxRounds: maxRemediationRounds,
                  missing: deliveryGateReport.missing.map(m => m.label),
                });
              }

              await new Promise(r => setTimeout(r, cfg.continuationCooldownMs));

              const remediationPrompt = buildRemediationPrompt(
                userMessage,
                deliveryGateReport.missing,
                deliveryGateReport.warnings,
                remediationRound,
                maxRemediationRounds,
              );

              try {
                const remediationResult = await runToolUseLoop(remediationPrompt, {
                  ...loopOptions,
                  chat,
                  chatOpts: {
                    ...chatOpts,
                    _agentContext: runtimeCtx,
                  },
                });
                allToolCallLogs.push(...(remediationResult?.toolCallLog || []));
                totalIterations += (remediationResult?.iterations || 0);

                loopResult = {
                  ...loopResult,
                  ...remediationResult,
                  toolCallLog: allToolCallLogs,
                  iterations: totalIterations,
                };
              } catch (remErr) {
                if (onEvent) onEvent({ type: 'delivery_remediation_error', round: remediationRound, error: remErr?.message });
                break;
              }

              // Re-evaluate after remediation
              deliveryGateReport = evaluateDelivery(projectRoot, criteria, {
                finalResponse: String(loopResult?.finalResponse || ''),
                toolCallLog: allToolCallLogs,
              });
            }

            if (remediationRound > 0) {
              deliveryGateReport.remediationRounds = remediationRound;
            }
          }
        } catch (gateErr) {
          // Delivery gate is best-effort — never block the main flow
          if (onEvent) onEvent({ type: 'delivery_gate_error', error: gateErr?.message });
        }
      }

      // ── Boulder State: clear checkpoint on completion ──
      try {
        const { clearBoulderState } = require('./boulderState');
        clearBoulderState(cwd);
      } catch { /* best-effort */ }

      const finishedAt = Date.now();
      const harnessReport = {
        durationMs: finishedAt - startedAt,
        contextRoute: contextPacket.contextRoute.route,
        tokenEstimate: contextPacket.tokenEstimate,
        memoryHints: contextPacket.memoryHints,
        skillHints: contextPacket.skillHints,
        iterations: Number(loopResult?.iterations || 0),
        toolCalls: Array.isArray(loopResult?.toolCallLog) ? loopResult.toolCallLog.length : 0,
        taskId: taskHandle.task.id,
        continuationRounds: continuationRound,
        deliveryGate: deliveryGateReport ? {
          passed: deliveryGateReport.passed,
          missing: deliveryGateReport.missing.map(m => m.label),
          warnings: deliveryGateReport.warnings.map(w => w.label),
          remediationRounds: deliveryGateReport.remediationRounds || 0,
        } : null,
        analytics: {
          adaptiveRounds: maxContinuationRounds,
          roundsUsed: continuationRound,
          roundEfficiency: continuationRound > 0
            ? (allToolCallLogs.filter(tc => tc.success !== false).length / Math.max(1, allToolCallLogs.length))
            : null,
          boulderResumed: !!boulderResumeUsed,
          complexityFactor: typeof complexityFactor !== 'undefined' ? complexityFactor : null,
        },
      };

      try {
        projectMemoryService.saveSessionTrace(cwd, {
          type: 'agentic_harness_run',
          promptPreview: userMessage.slice(0, 500),
          contextRoute: harnessReport.contextRoute,
          iterations: harnessReport.iterations,
          toolCalls: harnessReport.toolCalls,
          memoryHints: harnessReport.memoryHints.map(item => item.filename),
          skillHints: harnessReport.skillHints.map(item => item.trigger || item.name),
          durationMs: harnessReport.durationMs,
          success: !loopResult?.errorType,
        });
      } catch {
        // Session trace persistence is best-effort.
      }

      backgroundTaskManager.complete(taskHandle.task.id, harnessReport);
      if (onEvent) onEvent({ type: 'completed', report: harnessReport });

      return {
        ...loopResult,
        harness: harnessReport,
      };
    } catch (err) {
      backgroundTaskManager.fail(taskHandle.task.id, err?.message || 'agentic harness failed');
      if (onEvent) onEvent({ type: 'failed', error: err?.message || 'agentic harness failed' });
      throw err;
    }
  }

  return {
    run,
    buildContextPacket,
    config: { ...cfg },
    clearCache: () => hintCache.clear(),
  };
}

function _buildLoopInput(packet) {
  const sections = [packet.userMessage];

  if (packet.memoryHints.length > 0) {
    sections.push([
      '[System Memory Hints]',
      ...packet.memoryHints.map((item, idx) => `${idx + 1}. ${item.title} (${item.filename}) - ${item.snippet}`),
    ].join('\n'));
  }

  if (packet.skillHints.length > 0) {
    sections.push([
      '[System Skill Hints]',
      ...packet.skillHints.map((item, idx) => `${idx + 1}. ${item.trigger || item.name}: ${item.description}`),
    ].join('\n'));
  }

  if (packet.contextRoute.route !== 'fits') {
    sections.push(
      `[System Context Route] route=${packet.contextRoute.route}; overflow=${packet.contextRoute.overflow}; `
      + `toolResultTokens=${packet.contextRoute.toolResultTokens}.`,
    );
  }

  return sections.join('\n\n');
}

function _isRetryableLoopOutcome(loopResult) {
  const retryable = new Set(['timeout', 'network', 'process', 'unknown', 'cancelled']);
  const errorType = String(loopResult?.errorType || '').trim().toLowerCase();
  if (!errorType || !retryable.has(errorType)) return false;
  // Cooldown failures are deterministic — the adapter cached a recent failure
  // and won't retry until the cooldown expires.  Retrying immediately is futile.
  const content = String(loopResult?.finalResponse || loopResult?.content || '');
  if (/\bcooldown\b/i.test(content) || /recent.*failure.*cached/i.test(content)) return false;
  const calls = Array.isArray(loopResult?.toolCallLog) ? loopResult.toolCallLog.length : 0;
  return calls === 0;
}

async function _collectMemoryHints({ userMessage, maxItems, vectorRetriever }) {
  if (!userMessage) return [];
  const queryTokens = _tokenize(userMessage);
  if (queryTokens.size === 0) return [];

  const candidates = [];
  const seen = new Set();

  const pushHit = (hit, source) => {
    const filename = String(hit?.filename || '').trim();
    if (!filename || seen.has(filename)) return;
    seen.add(filename);
    const frontmatter = hit.frontmatter || {};
    const joined = [frontmatter.name, frontmatter.description, ...(hit.matches || [])].filter(Boolean).join(' ');
    const textTokens = _tokenize(joined);
    const score = _overlapScore(queryTokens, textTokens);
    candidates.push({
      filename,
      title: String(frontmatter.name || filename),
      snippet: _safeSnippet((hit.matches || []).join(' | ') || frontmatter.description || ''),
      score,
      source,
    });
  };

  try {
    const direct = memdir.searchMemories(userMessage);
    for (const hit of direct) pushHit(hit, 'text');
  } catch {
    // ignore
  }

  if (candidates.length < maxItems) {
    const tokenQueries = [...queryTokens].filter(t => t.length >= 2).slice(0, 4);
    for (const token of tokenQueries) {
      try {
        const tokenHits = memdir.searchMemories(token);
        for (const hit of tokenHits) pushHit(hit, 'token');
      } catch {
        // ignore
      }
      if (candidates.length >= maxItems * 3) break;
    }
  }

  if (vectorRetriever) {
    try {
      const vectorHits = await vectorRetriever({
        query: userMessage,
        maxItems: maxItems * 2,
      });
      if (Array.isArray(vectorHits)) {
        for (const hit of vectorHits) {
          pushHit({
            filename: hit.filename || hit.id || `vector-${candidates.length + 1}`,
            frontmatter: {
              name: hit.title || hit.name || hit.filename || 'vector-memory',
              description: hit.description || '',
            },
            matches: [hit.snippet || hit.content || ''],
          }, 'vector');
        }
      }
    } catch {
      // Vector retrieval is optional.
    }
  }

  return candidates
    .sort((a, b) => b.score - a.score || a.filename.localeCompare(b.filename))
    .slice(0, maxItems)
    .map(({ filename, title, snippet, source }) => ({ filename, title, snippet, source }));
}

function _collectSkillHints({ userMessage, cwd, recentFiles, maxItems }) {
  try {
    skills.discoverAllSkills(cwd);
    const activeSkills = skills.getActiveSkills({ cwd, recentFiles });
    if (!Array.isArray(activeSkills) || activeSkills.length === 0) return [];

    const queryTokens = _tokenize(userMessage);
    const scored = activeSkills.map((skill) => {
      const baseText = [
        skill.name,
        skill.description,
        skill.trigger,
        ...(skill.tags || []),
      ].filter(Boolean).join(' ');
      const skillTokens = _tokenize(baseText);
      return {
        name: skill.name,
        trigger: skill.trigger,
        description: _safeSnippet(skill.description || '', 140),
        score: _overlapScore(queryTokens, skillTokens),
      };
    });

    const hasSignal = scored.some(item => item.score > 0);
    const picked = (hasSignal
      ? scored.filter(item => item.score > 0)
      : scored
    )
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
      .slice(0, maxItems)
      .map(({ name, trigger, description }) => ({ name, trigger, description }));

    return picked;
  } catch {
    return [];
  }
}

function _tokenize(text) {
  const raw = String(text || '').toLowerCase();
  const out = new Set();
  const words = raw.match(/[a-z0-9_./-]+/g) || [];
  for (const word of words) {
    const normalized = word.trim();
    if (normalized.length >= 2) out.add(normalized);
  }

  // Keep CJK bigrams to support Chinese query matching.
  const cjk = (raw.match(/[\u4e00-\u9fff]+/g) || []).join('');
  for (let i = 0; i < cjk.length - 1; i++) {
    out.add(cjk.slice(i, i + 2));
  }
  return out;
}

function _overlapScore(left, right) {
  if (!(left instanceof Set) || !(right instanceof Set) || left.size === 0 || right.size === 0) {
    return 0;
  }
  let hit = 0;
  for (const token of left) {
    if (right.has(token)) hit++;
  }
  return hit / left.size;
}

function _safeSnippet(text, maxLen = 180) {
  const oneLine = String(text || '').replace(/\s+/g, ' ').trim();
  if (oneLine.length <= maxLen) return oneLine;
  return `${oneLine.slice(0, maxLen - 1)}…`;
}

function _cloneMessages(messages) {
  if (!Array.isArray(messages)) return [];
  return messages.map((msg) => ({
    role: String(msg?.role || 'assistant'),
    content: String(msg?.content || ''),
  }));
}

function _safeArray(value) {
  return Array.isArray(value) ? value.filter(Boolean) : [];
}

function _hashInput(input) {
  return crypto.createHash('sha1').update(String(input || '')).digest('hex');
}

function _createTtlCache(ttlMs, maxEntries) {
  const ttl = Math.max(1000, Number(ttlMs) || DEFAULTS.cacheTtlMs);
  const cap = Math.max(16, Number(maxEntries) || DEFAULTS.maxCacheEntries);
  const map = new Map();

  function get(key) {
    const entry = map.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      map.delete(key);
      return null;
    }
    return entry.value;
  }

  function set(key, value) {
    if (map.size >= cap) {
      const firstKey = map.keys().next().value;
      if (firstKey !== undefined) map.delete(firstKey);
    }
    map.set(key, {
      value,
      expiresAt: Date.now() + ttl,
    });
  }

  function clear() {
    map.clear();
  }

  return { get, set, clear };
}

// ── Ralph Loop helpers ──────────────────────────────────────────────

/**
 * Assess task complexity to determine adaptive Ralph Loop rounds.
 * @param {string} userMessage - The original user prompt
 * @param {string[]} activatedModes - Intent modes (from IntentGate)
 * @param {object|null} firstLoopResult - Result of the first tool-use loop iteration
 * @returns {number} Complexity factor (1.0 – 2.5)
 */
function _assessTaskComplexity(userMessage, activatedModes, firstLoopResult) {
  let factor = 1.0;
  if ((userMessage || '').length > 2000) factor += 0.5;
  const modes = activatedModes || [];
  if (modes.includes('ultrawork') || modes.includes('coding')) factor += 0.5;
  const toolCount = firstLoopResult?.toolCallLog?.length || 0;
  if (toolCount > 10) factor += 0.5;
  return factor;
}

function _shouldAutoContinue(userMessage) {
  const envFlag = String(process.env.KHY_RALPH_LOOP || '').trim().toLowerCase();
  if (['0', 'false', 'off', 'no'].includes(envFlag)) return false;

  try {
    const { detectModes } = require('./intentGate');
    const modes = detectModes(userMessage);
    return modes.ultrawork || modes.coding;
  } catch {
    return false;
  }
}

function _buildContinuationSummary(loopResult) {
  const log = Array.isArray(loopResult?.toolCallLog) ? loopResult.toolCallLog : [];
  const writes = [];
  const shells = [];
  const reads = [];
  let successes = 0;
  let failures = 0;

  for (const entry of log) {
    const tool = String(entry.tool || '');
    const ok = entry.result?.success !== false;
    if (ok) successes++; else failures++;

    if (/write|scaffold|edit/i.test(tool)) {
      const p = entry.params?.path || entry.params?.file_path || entry.params?.root || '';
      if (p) writes.push(p);
    } else if (/shell/i.test(tool)) {
      const cmd = String(entry.params?.command || '').slice(0, 80);
      if (cmd) shells.push(cmd);
    } else if (/read/i.test(tool)) {
      const p = entry.params?.path || entry.params?.file_path || '';
      if (p) reads.push(p);
    }
  }

  const parts = [`Tool calls: ${log.length} (${successes} ok, ${failures} failed)`];
  if (writes.length > 0) parts.push(`Files written/edited: ${writes.slice(0, 15).join(', ')}${writes.length > 15 ? ` (+${writes.length - 15} more)` : ''}`);
  if (shells.length > 0) parts.push(`Shell commands: ${shells.slice(0, 5).join('; ')}${shells.length > 5 ? ` (+${shells.length - 5} more)` : ''}`);
  if (reads.length > 0) parts.push(`Files read: ${reads.slice(0, 10).join(', ')}${reads.length > 10 ? ` (+${reads.length - 10} more)` : ''}`);

  const lastReply = String(loopResult?.finalResponse || '').trim();
  if (lastReply) parts.push(`Last AI response: ${lastReply.slice(0, 300)}`);

  return parts.join('\n');
}

function _buildContinuationInput(originalMessage, summary, round, maxRounds) {
  return [
    `[SYSTEM: Ralph Loop continuation round ${round}/${maxRounds} — auto-continuing because iteration limit was reached.]`,
    '',
    '[Original task]',
    originalMessage.slice(0, 500),
    '',
    '[Progress so far]',
    summary,
    '',
    '[Instructions]',
    'Continue from where the previous round left off.',
    'Do NOT repeat work already completed — focus only on remaining steps.',
    'If the task is now complete, provide a final summary of what was accomplished.',
  ].join('\n');
}

module.exports = {
  createAgenticHarness,
  DEFAULTS,
};
