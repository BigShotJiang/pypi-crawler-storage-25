'use strict';

/**
 * Session Persistence — save/restore conversation sessions to disk.
 *
 * Sessions are stored as JSON files under ~/.khyquant/sessions/{sessionId}.json.
 * Used by the daemon to survive restarts and by CLI to resume sessions.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { getDataDir } = require('../utils/dataHome');

function _sessionsDir() {
  return getDataDir('sessions');
}

function _filePath(sessionId) {
  const safe = String(sessionId).replace(/[^a-zA-Z0-9_-]/g, '');
  return path.join(_sessionsDir(), `${safe}.json`);
}

/**
 * Persist a session to disk.
 * @param {string} sessionId - Unique session identifier
 * @param {object} state - Session state to persist
 * @param {Array} state.messages - Conversation messages
 * @param {string} [state.title] - Session title
 * @param {string} [state.model] - Model used
 * @param {object} [state.metadata] - Additional metadata
 * @returns {string} sessionId
 */
function persistSession(sessionId, state) {
  if (!sessionId) {
    sessionId = 'sess-' + crypto.randomBytes(4).toString('hex');
  }

  const data = {
    sessionId,
    title: state.title || '',
    model: state.model || '',
    messages: state.messages || [],
    messageCount: (state.messages || []).length,
    metadata: state.metadata || {},
    createdAt: state.createdAt || Date.now(),
    updatedAt: Date.now(),
  };

  fs.writeFileSync(_filePath(sessionId), JSON.stringify(data, null, 2), 'utf-8');

  // Write-through to search index (best-effort, non-blocking)
  try {
    const searchIndex = require('./sessionSearchIndex');
    searchIndex.init();
    searchIndex.indexSession(sessionId, data);
  } catch { /* search index is optional */ }

  return sessionId;
}

/**
 * Restore a session from disk.
 * @param {string} sessionId
 * @returns {object|null}
 */
function restoreSession(sessionId) {
  try {
    const raw = fs.readFileSync(_filePath(sessionId), 'utf-8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/**
 * List all persisted sessions with metadata.
 * @param {object} [opts]
 * @param {number} [opts.limit=50]
 * @returns {Array<{ sessionId: string, title: string, model: string, messageCount: number, updatedAt: number }>}
 */
function listPersistedSessions(opts = {}) {
  const dir = _sessionsDir();
  const limit = opts.limit || 50;

  let files;
  try {
    files = fs.readdirSync(dir).filter(f => f.endsWith('.json'));
  } catch {
    return [];
  }

  const sessions = [];
  for (const file of files) {
    if (sessions.length >= limit) break;
    try {
      const raw = fs.readFileSync(path.join(dir, file), 'utf-8');
      const data = JSON.parse(raw);
      sessions.push({
        sessionId: data.sessionId,
        title: data.title || '(untitled)',
        model: data.model || '',
        messageCount: data.messageCount || 0,
        updatedAt: data.updatedAt || 0,
      });
    } catch { /* skip corrupt */ }
  }

  sessions.sort((a, b) => b.updatedAt - a.updatedAt);
  return sessions;
}

/**
 * Delete a persisted session.
 * @param {string} sessionId
 * @returns {boolean}
 */
function deleteSession(sessionId) {
  try {
    fs.unlinkSync(_filePath(sessionId));
    // Remove from search index
    try {
      const searchIndex = require('./sessionSearchIndex');
      searchIndex.removeSessionIndex(sessionId);
    } catch { /* optional */ }
    return true;
  } catch {
    return false;
  }
}

/**
 * Remove sessions older than the threshold.
 * @param {number} [olderThanMs=604800000] - Default: 7 days
 * @returns {number} Number of sessions cleaned up
 */
function cleanupStaleSessions(olderThanMs = 7 * 24 * 60 * 60 * 1000) {
  const dir = _sessionsDir();
  const cutoff = Date.now() - olderThanMs;
  let cleaned = 0;

  let files;
  try {
    files = fs.readdirSync(dir).filter(f => f.endsWith('.json'));
  } catch {
    return 0;
  }

  for (const file of files) {
    try {
      const raw = fs.readFileSync(path.join(dir, file), 'utf-8');
      const data = JSON.parse(raw);
      if ((data.updatedAt || 0) < cutoff) {
        fs.unlinkSync(path.join(dir, file));
        cleaned++;
      }
    } catch { /* skip */ }
  }

  return cleaned;
}

module.exports = {
  persistSession,
  restoreSession,
  listPersistedSessions,
  deleteSession,
  cleanupStaleSessions,
};
