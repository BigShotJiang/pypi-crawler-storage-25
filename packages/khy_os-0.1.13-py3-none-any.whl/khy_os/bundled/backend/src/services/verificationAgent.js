'use strict';

/**
 * Verification Agent — adversarial post-implementation testing.
 *
 * After code changes, spawns a lightweight verification pass that:
 *   1. Runs syntax checks on modified files
 *   2. Runs linters (if configured)
 *   3. Runs test suites (if present)
 *   4. Runs build (if configured)
 *   5. Reports pass/fail with actionable feedback
 *
 * Inspired by Claude Code's verification agent that runs adversarially
 * against implementation changes.
 *
 * @module verificationAgent
 */

const { execSync, spawnSync } = require('child_process');
const fs = require('fs');
const { findPython } = require('../utils/pythonPath');
const path = require('path');
const log = require('../utils/logger');

// ── Constants ──────────────────────────────────────────────────────

const VERIFICATION_TIMEOUT = 60000; // 60s per step
const MAX_OUTPUT_CHARS = 5000;

// ── Detectors ──────────────────────────────────────────────────────

/**
 * Detect project type and available verification steps.
 * @param {string} cwd - Project root
 * @returns {{ type: string, steps: string[] }}
 */
function detectProject(cwd) {
  const steps = [];
  let type = 'unknown';

  // Node.js
  const pkgPath = path.join(cwd, 'package.json');
  if (fs.existsSync(pkgPath)) {
    type = 'node';
    steps.push('syntax');
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8'));
      if (pkg.scripts) {
        if (pkg.scripts.lint) steps.push('lint');
        if (pkg.scripts.test) steps.push('test');
        if (pkg.scripts.build) steps.push('build');
        if (pkg.scripts.typecheck || pkg.scripts['type-check']) steps.push('typecheck');
      }
    } catch { /* skip */ }
    return { type, steps };
  }

  // Python
  if (fs.existsSync(path.join(cwd, 'pyproject.toml')) || fs.existsSync(path.join(cwd, 'setup.py'))) {
    type = 'python';
    steps.push('syntax');
    if (_commandExists('ruff')) steps.push('lint');
    else if (_commandExists('flake8')) steps.push('lint');
    if (_commandExists('pytest')) steps.push('test');
    return { type, steps };
  }

  // Rust
  if (fs.existsSync(path.join(cwd, 'Cargo.toml'))) {
    type = 'rust';
    steps.push('build'); // cargo check
    if (_commandExists('cargo')) {
      steps.push('test');
      steps.push('lint'); // clippy
    }
    return { type, steps };
  }

  // Go
  if (fs.existsSync(path.join(cwd, 'go.mod'))) {
    type = 'go';
    steps.push('build'); // go build
    steps.push('test');
    if (_commandExists('golangci-lint')) steps.push('lint');
    return { type, steps };
  }

  return { type, steps };
}

function _commandExists(cmd) {
  try {
    const check = process.platform === 'win32' ? `where ${cmd}` : `which ${cmd}`;
    execSync(check, { stdio: 'ignore', timeout: 3000 });
    return true;
  } catch {
    return false;
  }
}

// ── Step Runners ───────────────────────────────────────────────────

/**
 * Run syntax check on modified files.
 * @param {string[]} files - Modified file paths
 * @param {string} projectType
 * @param {string} cwd
 * @returns {{ pass: boolean, output: string }}
 */
function _runSyntaxCheck(files, projectType, cwd) {
  const errors = [];

  for (const file of files) {
    const ext = path.extname(file).toLowerCase();
    try {
      if (ext === '.js' || ext === '.mjs' || ext === '.cjs') {
        execSync(`node -c "${file}"`, { cwd, timeout: 10000, stdio: 'pipe' });
      } else if (ext === '.py') {
        const pyBin = findPython();
        execSync(`"${pyBin}" -c "import py_compile; py_compile.compile('${file}', doraise=True)"`, {
          cwd, timeout: 10000, stdio: 'pipe',
        });
      } else if (ext === '.json') {
        JSON.parse(fs.readFileSync(path.resolve(cwd, file), 'utf-8'));
      }
    } catch (err) {
      errors.push(`${file}: ${(err.stderr || err.message || '').toString().slice(0, 200)}`);
    }
  }

  return {
    pass: errors.length === 0,
    output: errors.length > 0 ? errors.join('\n') : 'All files pass syntax check',
  };
}

/**
 * Run a npm/yarn/pnpm script.
 * @param {string} script - Script name
 * @param {string} cwd
 * @returns {{ pass: boolean, output: string }}
 */
function _runNpmScript(script, cwd) {
  // Detect package manager
  let pm = 'npm';
  if (fs.existsSync(path.join(cwd, 'pnpm-lock.yaml'))) pm = 'pnpm';
  else if (fs.existsSync(path.join(cwd, 'yarn.lock'))) pm = 'yarn';

  try {
    const result = spawnSync(pm, ['run', script], {
      cwd,
      timeout: VERIFICATION_TIMEOUT,
      encoding: 'utf-8',
      stdio: 'pipe',
    });
    const output = `${result.stdout || ''}${result.stderr || ''}`.slice(0, MAX_OUTPUT_CHARS);
    return { pass: result.status === 0, output };
  } catch (err) {
    return { pass: false, output: err.message.slice(0, MAX_OUTPUT_CHARS) };
  }
}

/**
 * Run Python linter.
 * @param {string[]} files
 * @param {string} cwd
 * @returns {{ pass: boolean, output: string }}
 */
function _runPythonLint(files, cwd) {
  const pyFiles = files.filter(f => f.endsWith('.py'));
  if (pyFiles.length === 0) return { pass: true, output: 'No Python files to lint' };

  const linter = _commandExists('ruff') ? 'ruff check' : 'flake8';
  try {
    const result = spawnSync(linter.split(' ')[0], [...linter.split(' ').slice(1), ...pyFiles], {
      cwd, timeout: VERIFICATION_TIMEOUT, encoding: 'utf-8', stdio: 'pipe',
    });
    const output = `${result.stdout || ''}${result.stderr || ''}`.slice(0, MAX_OUTPUT_CHARS);
    return { pass: result.status === 0, output };
  } catch (err) {
    return { pass: false, output: err.message };
  }
}

/**
 * Run Rust verification (cargo check + clippy).
 * @param {string} step - 'build', 'lint', or 'test'
 * @param {string} cwd
 * @returns {{ pass: boolean, output: string }}
 */
function _runCargoStep(step, cwd) {
  const commands = {
    build: ['cargo', ['check', '--quiet']],
    lint: ['cargo', ['clippy', '--', '-D', 'warnings']],
    test: ['cargo', ['test', '--quiet']],
  };
  const [cmd, args] = commands[step] || commands.build;
  try {
    const result = spawnSync(cmd, args, {
      cwd, timeout: VERIFICATION_TIMEOUT, encoding: 'utf-8', stdio: 'pipe',
    });
    const output = `${result.stdout || ''}${result.stderr || ''}`.slice(0, MAX_OUTPUT_CHARS);
    return { pass: result.status === 0, output };
  } catch (err) {
    return { pass: false, output: err.message };
  }
}

/**
 * Run Go verification.
 * @param {string} step
 * @param {string} cwd
 * @returns {{ pass: boolean, output: string }}
 */
function _runGoStep(step, cwd) {
  const commands = {
    build: ['go', ['build', './...']],
    test: ['go', ['test', './...']],
    lint: ['golangci-lint', ['run']],
  };
  const [cmd, args] = commands[step] || commands.build;
  try {
    const result = spawnSync(cmd, args, {
      cwd, timeout: VERIFICATION_TIMEOUT, encoding: 'utf-8', stdio: 'pipe',
    });
    const output = `${result.stdout || ''}${result.stderr || ''}`.slice(0, MAX_OUTPUT_CHARS);
    return { pass: result.status === 0, output };
  } catch (err) {
    return { pass: false, output: err.message };
  }
}

// ── Main Verification Pipeline ─────────────────────────────────────

/**
 * Run the full verification pipeline against changed files.
 *
 * @param {object} params
 * @param {string[]} params.files - List of modified file paths (relative to cwd)
 * @param {string} [params.cwd] - Project root directory
 * @param {string[]} [params.skipSteps] - Steps to skip
 * @param {boolean} [params.failFast=false] - Stop at first failure
 * @returns {{ passed: boolean, steps: Array<{ name: string, pass: boolean, output: string, durationMs: number }>, summary: string }}
 */
function verify(params) {
  const cwd = params.cwd || process.env.KHYQUANT_CWD || process.cwd();
  const files = params.files || [];
  const skipSteps = new Set(params.skipSteps || []);
  const failFast = params.failFast || false;

  const { type, steps } = detectProject(cwd);
  const results = [];
  let allPassed = true;

  for (const step of steps) {
    if (skipSteps.has(step)) continue;

    const start = Date.now();
    let result;

    try {
      switch (step) {
        case 'syntax':
          result = _runSyntaxCheck(files, type, cwd);
          break;
        case 'lint':
          if (type === 'node') result = _runNpmScript('lint', cwd);
          else if (type === 'python') result = _runPythonLint(files, cwd);
          else if (type === 'rust') result = _runCargoStep('lint', cwd);
          else if (type === 'go') result = _runGoStep('lint', cwd);
          else result = { pass: true, output: 'No linter available' };
          break;
        case 'typecheck':
          result = _runNpmScript(step === 'typecheck' ? 'typecheck' : 'type-check', cwd);
          break;
        case 'test':
          if (type === 'node') result = _runNpmScript('test', cwd);
          else if (type === 'python') {
            try {
              const r = spawnSync('pytest', ['--tb=short', '-q'], {
                cwd, timeout: VERIFICATION_TIMEOUT, encoding: 'utf-8', stdio: 'pipe',
              });
              result = { pass: r.status === 0, output: `${r.stdout || ''}${r.stderr || ''}`.slice(0, MAX_OUTPUT_CHARS) };
            } catch (e) {
              result = { pass: false, output: e.message };
            }
          }
          else if (type === 'rust') result = _runCargoStep('test', cwd);
          else if (type === 'go') result = _runGoStep('test', cwd);
          else result = { pass: true, output: 'No test runner available' };
          break;
        case 'build':
          if (type === 'node') result = _runNpmScript('build', cwd);
          else if (type === 'rust') result = _runCargoStep('build', cwd);
          else if (type === 'go') result = _runGoStep('build', cwd);
          else result = { pass: true, output: 'No build step available' };
          break;
        default:
          result = { pass: true, output: `Unknown step: ${step}` };
      }
    } catch (err) {
      result = { pass: false, output: `Step error: ${err.message}` };
    }

    const durationMs = Date.now() - start;
    results.push({ name: step, pass: result.pass, output: result.output, durationMs });

    if (!result.pass) {
      allPassed = false;
      if (failFast) break;
    }
  }

  // Build summary
  const passCount = results.filter(r => r.pass).length;
  const failCount = results.filter(r => !r.pass).length;
  const totalMs = results.reduce((s, r) => s + r.durationMs, 0);
  const failNames = results.filter(r => !r.pass).map(r => r.name);

  let summary;
  if (results.length === 0) {
    summary = `No verification steps detected for ${type} project.`;
  } else if (allPassed) {
    summary = `All ${passCount} verification step(s) passed (${totalMs}ms).`;
  } else {
    summary = `${failCount}/${results.length} step(s) failed: ${failNames.join(', ')} (${totalMs}ms).`;
  }

  return { passed: allPassed, steps: results, summary, projectType: type };
}

/**
 * Quick syntax-only verification for a list of files.
 * Used as a lightweight post-edit check.
 *
 * @param {string[]} files - Absolute or relative paths
 * @param {string} [cwd]
 * @returns {{ pass: boolean, errors: string[] }}
 */
function quickSyntaxCheck(files, cwd) {
  cwd = cwd || process.env.KHYQUANT_CWD || process.cwd();
  const result = _runSyntaxCheck(files, 'auto', cwd);
  return {
    pass: result.pass,
    errors: result.pass ? [] : result.output.split('\n').filter(Boolean),
  };
}

module.exports = {
  verify,
  quickSyntaxCheck,
  detectProject,
  VERIFICATION_TIMEOUT,
};
