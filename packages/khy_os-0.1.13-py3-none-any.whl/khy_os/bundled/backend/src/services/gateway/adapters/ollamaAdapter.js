/**
 * Ollama Adapter — connect to a local Ollama instance for LLM inference.
 *
 * Ollama runs on http://localhost:11434 by default and exposes an
 * OpenAI-compatible API at /api/generate and /api/chat.
 *
 * Detection: GET /api/tags (list available models).
 * Generation: POST /api/generate { model, prompt, stream: false }
 */
const http = require('http');
const os = require('os');
const { parseNdjsonNodeStream } = require('../../ndjsonStream');
const { toOllamaBase64Images } = require('./_imageCompat');

// Register Ollama in media provider registry when detected
let _mediaRegistered = false;
function _updateMediaRegistry(available) {
  try {
    const { mediaRegistry } = require('../../mediaUnderstanding');
    mediaRegistry.setAvailability('ollama', available);
    _mediaRegistered = true;
  } catch { /* mediaUnderstanding not available */ }
}

const { OLLAMA_HOST } = require('../../../constants/serviceDefaults');

const DEFAULT_HOST = OLLAMA_HOST;
const DEFAULT_MODEL = 'qwen3.5:4b'; // Matches local GGUF model
const TIMEOUT_MS = 120_000;

let _available = null;
let _models = [];

// ── Memory-aware model selection ────────────────────────────────────────
// Known model memory requirements (GiB, Q4_K_M quantization)
const MODEL_MEMORY_GIB = {
  'qwen2.5:0.5b':  0.8,  'qwen2.5:1.5b':  1.5,  'qwen2.5:3b':    2.5,
  'qwen2.5:7b':    5.4,  'qwen2.5:14b':   9.5,   'qwen2.5:32b':   20,
  'qwen3.5:4b':    3.2,
  'llama3.2:1b':   1.3,  'llama3.2:3b':    2.5,   'llama3.1:8b':   5.5,
  'llama3.1:70b':  42,
  'phi3:mini':     2.5,  'phi3.5:mini':    2.5,
  'gemma2:2b':     2.0,  'gemma2:9b':      6.5,
  'mistral:7b':    5.2,  'deepseek-coder:6.7b': 4.5,
  'codellama:7b':  5.0,  'codellama:13b':  8.5,
  'starcoder2:3b': 2.5,  'starcoder2:7b':  5.0,
};

// Fallback model preferences (smallest → larger)
const FALLBACK_MODELS = [
  'qwen2.5:0.5b', 'qwen2.5:1.5b', 'llama3.2:1b', 'phi3:mini',
  'gemma2:2b', 'qwen2.5:3b', 'qwen3.5:4b', 'llama3.2:3b',
  'starcoder2:3b', 'deepseek-coder:6.7b',
];

/**
 * Estimate model memory requirement (GiB).
 * Uses static table for known models, heuristic for unknown.
 * Heuristic: ~0.7 GiB per billion params (Q4) + 0.5 GiB overhead.
 */
function estimateModelMemoryGiB(modelId) {
  const id = String(modelId || '').toLowerCase().trim();
  if (MODEL_MEMORY_GIB[id]) return MODEL_MEMORY_GIB[id];

  // Try to extract parameter count from ":Nb" tag (e.g. qwen2:7b → 7)
  const match = id.match(/:(\d+(?:\.\d+)?)b/);
  if (match) {
    const billions = parseFloat(match[1]);
    return +(billions * 0.7 + 0.5).toFixed(1);
  }
  return 5.0; // conservative default
}

/**
 * Find a smaller model that fits in available memory.
 * Returns null if no suitable fallback found.
 */
function findMemoryFitModel(availableGiB, installedModels = []) {
  const installed = new Set(installedModels.map(m => String(m).toLowerCase().trim()));

  // First: check FALLBACK_MODELS order (preferred small models)
  for (const m of FALLBACK_MODELS) {
    if (installed.has(m) && estimateModelMemoryGiB(m) <= availableGiB) return m;
  }

  // Second: check all installed models, pick smallest that fits
  const candidates = [...installed]
    .map(m => ({ id: m, mem: estimateModelMemoryGiB(m) }))
    .filter(c => c.mem <= availableGiB)
    .sort((a, b) => a.mem - b.mem);
  return candidates.length > 0 ? candidates[0].id : null;
}

function normalizeAbortReason(reason) {
  if (!reason) return 'aborted';
  if (typeof reason === 'string') return reason;
  if (reason && typeof reason.message === 'string') return reason.message;
  try { return JSON.stringify(reason); } catch { return String(reason); }
}

function createAbortError(reason) {
  const err = new Error(`Ollama request aborted: ${normalizeAbortReason(reason)}`);
  err.name = 'AbortError';
  err.code = 'ABORT_ERR';
  return err;
}

function classifyOllamaError(status, message = '') {
  const lower = String(message || '').toLowerCase();
  if (/aborterror|abort_err|\baborted\b|\brequest aborted\b|\babort(ed)? by\b|signal aborted|user[-\s]?cancel/.test(lower)) return 'cancelled';
  if (/\bcancelled\b|\bcanceled\b/.test(lower)) return 'process';
  if (/timeout|timed out/.test(lower)) return 'timeout';
  if (/econnrefused|econnreset|enotfound|network|socket hang up|fetch failed/.test(lower)) return 'network';
  if (status === 401 || status === 403) return 'auth';
  if (status === 429) return 'rate_limit';
  if (status === 404) return 'unavailable';
  if (status >= 500 && status < 600) return 'server_error';
  if (status >= 400) return 'bad_request';
  return 'unknown';
}

function extractOllamaErrorMessage(result, fallback = '') {
  if (!result) return String(fallback || '').trim();
  const data = result.data;
  if (data && typeof data === 'object') {
    const direct = String(data.error || data.message || '').trim();
    if (direct) return direct;
    if (data.message && typeof data.message === 'object') {
      const nested = String(data.message.error || data.message.content || '').trim();
      if (nested) return nested;
    }
  }
  if (typeof data === 'string') {
    const text = data.trim();
    if (text) return text.slice(0, 500);
  }
  return String(fallback || '').trim();
}

/**
 * Make an HTTP request to the Ollama API.
 */
function ollamaRequest(path, method = 'GET', body = null, requestOptions = {}) {
  const host = process.env.OLLAMA_HOST || DEFAULT_HOST;
  const url = new URL(path, host);
  const timeoutMs = Number.isFinite(Number(requestOptions.timeoutMs))
    ? Math.max(1000, Number(requestOptions.timeoutMs))
    : (method === 'GET' ? 3000 : TIMEOUT_MS);
  const signal = requestOptions.signal || null;

  return new Promise((resolve, reject) => {
    if (signal && signal.aborted) {
      reject(createAbortError(signal.reason));
      return;
    }

    const options = {
      // Force IPv4 to avoid Windows dual-stack DNS delay
      hostname: url.hostname === 'localhost' ? '127.0.0.1' : url.hostname,
      port: url.port,
      path: url.pathname,
      method,
      headers: { 'Content-Type': 'application/json' },
      timeout: timeoutMs,
    };

    let settled = false;
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      if (signal && onAbort) {
        try { signal.removeEventListener('abort', onAbort); } catch { /* ignore */ }
      }
      if (hardTimer) clearTimeout(hardTimer);
      fn(value);
    };
    const onAbort = () => {
      const err = createAbortError(signal ? signal.reason : null);
      try { req.destroy(err); } catch { /* ignore */ }
      finish(reject, err);
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          finish(resolve, { status: res.statusCode, data: JSON.parse(data) });
        } catch {
          finish(resolve, { status: res.statusCode, data: data });
        }
      });
    });

    // Hard timeout AFTER req is declared to avoid referencing before initialization
    const hardTimer = setTimeout(() => {
      req.destroy();
      finish(reject, new Error('Ollama request timeout'));
    }, timeoutMs);

    if (signal) {
      signal.addEventListener('abort', onAbort, { once: true });
    }

    req.on('error', (err) => { finish(reject, err); });
    req.on('timeout', () => {
      req.destroy();
      finish(reject, new Error('Ollama request timeout'));
    });

    if (body) {
      req.write(JSON.stringify(body));
    }
    req.end();
  });
}

/**
 * Detect if Ollama is running and has models available.
 * Returns cached result unless forceRefresh is true.
 * Because detection uses async HTTP, call detectAsync() for fresh probe.
 */
function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;
  // Synchronous path can only return cached value; trigger async probe
  detectAsync().catch(() => {});
  return _available || false;
}

/**
 * Async detection — probe Ollama /api/tags via Node http (no curl dependency).
 */
async function detectAsync() {
  try {
    const result = await ollamaRequest('/api/tags', 'GET');
    if (result.status === 200 && result.data?.models?.length > 0) {
      _models = result.data.models.map(m => m.name || m.model);
      _available = true;
      _updateMediaRegistry(true);
      return true;
    }
    _available = false;
    _updateMediaRegistry(false);
    return false;
  } catch {
    _available = false;
    _models = [];
    _updateMediaRegistry(false);
    return false;
  }
}

/**
 * Build structured messages array for /api/chat from options.
 * Converts internal message format to Ollama-compatible format.
 */
function buildChatMessages(prompt, options) {
  const messages = [];

  // If structured messages are provided, use them
  if (options.messages && Array.isArray(options.messages) && options.messages.length > 0) {
    for (const msg of options.messages) {
      if (msg.role === 'user') {
        messages.push({ role: 'user', content: msg.content });
      } else if (msg.role === 'assistant') {
        messages.push({ role: 'assistant', content: msg.content });
      } else if (msg.role === 'tool') {
        // Ollama doesn't natively support tool role; merge into last user message or create new one
        const toolText = `[Tool Execution Results]:\n${msg.content}`;
        const last = messages[messages.length - 1];
        if (last && last.role === 'user' && last.content.startsWith('[Tool Execution Results]:')) {
          last.content += `\n\n${toolText}`;
        } else {
          messages.push({ role: 'user', content: toolText });
        }
      }
    }
    return messages;
  }

  // Fallback: single user message from prompt
  messages.push({ role: 'user', content: prompt });
  return messages;
}

function attachImagesToLatestUserMessage(messages = [], imageBase64List = []) {
  if (!Array.isArray(imageBase64List) || imageBase64List.length === 0) return messages;
  const next = Array.isArray(messages)
    ? messages.map((msg) => (msg && typeof msg === 'object' ? { ...msg } : msg))
    : [];

  let userIndex = -1;
  for (let i = next.length - 1; i >= 0; i--) {
    if (String(next[i]?.role || '').toLowerCase() === 'user') {
      userIndex = i;
      break;
    }
  }

  if (userIndex < 0) {
    next.push({ role: 'user', content: '', images: [...imageBase64List] });
    return next;
  }

  const target = next[userIndex] || { role: 'user', content: '' };
  const existing = Array.isArray(target.images) ? target.images.filter(Boolean) : [];
  target.images = [...existing, ...imageBase64List];
  next[userIndex] = target;
  return next;
}

function buildGeneratePromptFromMessages(prompt, options) {
  const parts = [];
  if (options.system) {
    parts.push(`[System]\n${options.system}`);
  }
  const messages = buildChatMessages(prompt, options);
  for (const msg of messages) {
    const role = String(msg.role || 'user').toLowerCase();
    const content = String(msg.content || '').trim();
    if (!content) continue;
    if (role === 'assistant') {
      parts.push(`[Assistant]\n${content}`);
    } else {
      parts.push(`[User]\n${content}`);
    }
  }
  parts.push('[Assistant]\n');
  return parts.filter(Boolean).join('\n\n');
}

/**
 * Generate a response using the Ollama /api/chat (multi-turn) API.
 */
async function generate(prompt, options = {}) {
  let model = String(options.model || process.env.OLLAMA_MODEL || DEFAULT_MODEL).trim() || DEFAULT_MODEL;

  // Memory-aware model selection: auto-downgrade if not enough RAM
  const freeMemGiB = os.freemem() / (1024 ** 3);
  const requiredGiB = estimateModelMemoryGiB(model);
  if (requiredGiB > freeMemGiB) {
    const fallback = findMemoryFitModel(freeMemGiB, _models);
    if (fallback) {
      const msg = `内存不足: ${model} 需要 ${requiredGiB}GiB，可用 ${freeMemGiB.toFixed(1)}GiB → 自动降级到 ${fallback}`;
      if (typeof options.onChunk === 'function') options.onChunk({ type: 'status', text: msg });
      model = fallback;
    } else if (freeMemGiB < 1.0) {
      return {
        success: false,
        content: `内存严重不足 (${freeMemGiB.toFixed(1)}GiB)，${model} 需要 ${requiredGiB}GiB。\n` +
          '建议: 运行 `ollama pull qwen2.5:0.5b` 下载超小模型，或关闭其他程序释放内存。',
        provider: `Ollama (${model})`,
        adapter: 'ollama',
        errorType: 'memory',
        attempts: [{ provider: `Ollama (${model})`, success: false, error: 'insufficient memory' }],
      };
    }
    // If freeMemGiB >= 1.0 but no installed fallback, attempt anyway (Ollama may swap)
  }
  const runtime = require('../../khyUpgradeRuntime');
  const sourceText = options.userMessage || prompt || '';
  const forcedTemperature = runtime.lockTemperature(sourceText);
  const forcedTopP = runtime.lockTopP(sourceText);
  const requestSignal = options.abortSignal || options.signal || null;
  const timeoutMs = Number.isFinite(Number(options.timeoutMs))
    ? Math.max(1000, Number(options.timeoutMs))
    : TIMEOUT_MS;
  const normalizedImages = toOllamaBase64Images(options.images || []);
  if (Array.isArray(options.images) && options.images.length > 0 && normalizedImages.length === 0) {
    return {
      success: false,
      content: '检测到图片输入，但当前图片格式无法转换为 Ollama 需要的 base64。',
      provider: `Ollama (${model})`,
      adapter: 'ollama',
      errorType: 'unsupported_image',
      attempts: [{ provider: `Ollama (${model})`, success: false, error: 'image payload normalization failed' }],
    };
  }

  try {
    if (process.env.OLLAMA_AUTO_START !== 'false') {
      const { ensureOllamaRunning } = require('../../ollamaModelManager');
      const ensure = await ensureOllamaRunning({ autoStart: true, waitMs: 4000 });
      if (!ensure.running) {
        const ensureErr = ensure.error || 'Ollama not available';
        return {
          success: false,
          content: ensureErr,
          provider: 'Ollama',
          adapter: 'ollama',
          error: ensureErr,
          errorType: classifyOllamaError(0, ensureErr),
          attempts: [{ provider: `Ollama (${model})`, success: false, error: ensureErr }],
        };
      }
    }

    const messages = attachImagesToLatestUserMessage(
      buildChatMessages(prompt, options),
      normalizedImages
    );
    const chatPayload = {
      model,
      messages,
      system: options.system || undefined,
      stream: false,
      options: {
        temperature: forcedTemperature,
        top_p: forcedTopP,
        num_predict: options.maxTokens || 2048,
      },
    };

    let result = await ollamaRequest('/api/chat', 'POST', chatPayload, {
      signal: requestSignal,
      timeoutMs,
    });

    if (result.status === 200 && result.data && result.data.message) {
      return {
        success: true,
        content: result.data.message.content,
        provider: `Ollama (${model})`,
        adapter: 'ollama',
        model,
        attempts: [{ provider: `Ollama (${model})`, success: true }],
      };
    }

    // Compatibility fallback: some Ollama builds/models fail on /api/chat but
    // can still serve /api/generate reliably.
    const shouldFallbackGenerate = [404, 405, 500, 501, 502, 503].includes(Number(result.status || 0));
    if (shouldFallbackGenerate) {
      const generatePayload = {
        model,
        prompt: buildGeneratePromptFromMessages(prompt, options),
        images: normalizedImages.length > 0 ? normalizedImages : undefined,
        stream: false,
        options: {
          temperature: forcedTemperature,
          top_p: forcedTopP,
          num_predict: options.maxTokens || 2048,
        },
      };
      const fallback = await ollamaRequest('/api/generate', 'POST', generatePayload, {
        signal: requestSignal,
        timeoutMs,
      });
      if (fallback.status === 200 && fallback.data && typeof fallback.data.response === 'string') {
        return {
          success: true,
          content: fallback.data.response,
          provider: `Ollama (${model})`,
          adapter: 'ollama',
          model,
          attempts: [{ provider: `Ollama (${model})`, success: true }],
        };
      }
      // keep the richer error for diagnosis
      result = fallback.status >= 400 ? fallback : result;
    }

    // Model not found — try to suggest pulling
    if (result.status === 404) {
      const message = `模型 ${model} 未找到。请运行: ollama pull ${model}`;
      return {
        success: false,
        content: message,
        provider: 'Ollama',
        adapter: 'ollama',
        error: 'model not found',
        errorType: 'unavailable',
        attempts: [{ provider: `Ollama (${model})`, success: false, error: 'model not found' }],
      };
    }

    const detail = extractOllamaErrorMessage(result, `HTTP ${result.status}`);
    const httpError = `HTTP ${result.status}${detail && !/^http\s+\d+/i.test(detail) ? `: ${detail}` : ''}`;
    return {
      success: false,
      content: '',
      provider: 'Ollama',
      adapter: 'ollama',
      error: httpError,
      errorType: classifyOllamaError(result.status, httpError),
      statusCode: result.status,
      attempts: [{ provider: `Ollama (${model})`, success: false, error: httpError, statusCode: result.status }],
    };
  } catch (err) {
    if ((err && err.code === 'ECONNREFUSED') || /ECONNREFUSED/i.test(err?.message || '')) {
      const message = 'Ollama 服务未启动，已自动回退到其他 AI 通道。';
      return {
        success: false,
        content: message,
        provider: 'Ollama',
        adapter: 'ollama',
        error: 'ECONNREFUSED',
        errorType: 'network',
        attempts: [{ provider: `Ollama (${model})`, success: false, error: 'ECONNREFUSED' }],
      };
    }
    const errMsg = err && err.message ? err.message : String(err);
    return {
      success: false,
      content: '',
      provider: 'Ollama',
      adapter: 'ollama',
      error: errMsg,
      errorType: classifyOllamaError(0, errMsg),
      attempts: [{ provider: `Ollama (${model})`, success: false, error: errMsg }],
    };
  }
}

/**
 * Get adapter status.
 */
function getStatus() {
  const available = detect();
  const model = process.env.OLLAMA_MODEL || DEFAULT_MODEL;
  return {
    name: 'Ollama 本地模型',
    type: 'ollama',
    available,
    detail: available
      ? `${_models.length} 个模型 (当前: ${model})`
      : '未运行 — ollama serve 启动服务',
  };
}

/**
 * Get list of available models.
 */
function getModels() {
  return _models;
}

async function listModels() {
  if (!_models.length) {
    await detectAsync();
  }
  const current = process.env.OLLAMA_MODEL || DEFAULT_MODEL;
  const freeMemGiB = os.freemem() / (1024 ** 3);
  return (_models || []).map((id) => {
    const memEst = estimateModelMemoryGiB(id);
    let memoryFit = 'ok';
    if (memEst > freeMemGiB) memoryFit = 'insufficient';
    else if (memEst > freeMemGiB * 0.8) memoryFit = 'tight';
    return {
      id,
      name: id,
      provider: 'ollama',
      description: 'Ollama local model',
      isDefault: id === current,
      discoverySource: 'local',
      connectionMode: 'local',
      memoryEstimateGiB: memEst,
      memoryFit,
    };
  });
}

function destroy() {
  _available = null;
  _models = [];
}

module.exports = { detect, detectAsync, generate, getStatus, getModels, listModels, destroy };
