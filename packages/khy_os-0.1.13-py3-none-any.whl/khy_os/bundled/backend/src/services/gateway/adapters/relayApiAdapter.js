/**
 * Relay API Adapter — connect to third-party OpenAI-compatible Claude API relays.
 *
 * Supports:
 * - AWS Bedrock relay (Lambda/API Gateway)
 * - Third-party relay stations (OpenAI-SB, API2D, OhMyGPT, etc.)
 * - Self-hosted VPS reverse proxy (Nginx, Caddy)
 * - Cloudflare Workers proxy
 *
 * Config via environment variables:
 *   RELAY_API_ENDPOINT=https://your-relay.com/v1
 *   RELAY_API_KEY=sk-xxx
 *   RELAY_API_MODEL=claude-sonnet-4-20250514
 */
const https = require('https');
const http = require('http');
const { URL } = require('url');
const { extractPrimaryApiKey } = require('../../apiKeyFormat');

const DEFAULT_MODEL = 'claude-sonnet-4-20250514';
const TIMEOUT_MS = 120_000;
const MODELS_CACHE_TTL_MS = 5 * 60 * 1000;
const DEFAULT_RETRY_TOTAL_ATTEMPTS = 3;
const DEFAULT_RETRY_BASE_DELAY_MS = 350;
const DEFAULT_RETRY_MAX_DELAY_MS = 1800;

let _available = null;
let _modelsCache = { at: 0, list: null };

function normalizeAbortReason(reason) {
  if (!reason) return 'aborted';
  if (typeof reason === 'string') return reason;
  if (reason && typeof reason.message === 'string') return reason.message;
  try { return JSON.stringify(reason); } catch { return String(reason); }
}

function createAbortError(reason) {
  const err = new Error(`request aborted: ${normalizeAbortReason(reason)}`);
  err.name = 'AbortError';
  err.code = 'ABORT_ERR';
  return err;
}

function _parsePositiveInt(raw, fallback, min = 1, max = 8) {
  const parsed = parseInt(String(raw ?? fallback), 10);
  if (!Number.isFinite(parsed) || parsed < min) return fallback;
  return Math.min(max, parsed);
}

function _parseMs(raw, fallback, min = 0) {
  const parsed = parseInt(String(raw ?? fallback), 10);
  if (!Number.isFinite(parsed) || parsed <= 0) return fallback;
  return Math.max(min, parsed);
}

function _isAbortLikeError(err) {
  if (!err) return false;
  if (err.name === 'AbortError' || err.code === 'ABORT_ERR') return true;
  const msg = String(err.message || '').toLowerCase();
  return /request aborted|abort_err|\baborted\b|signal aborted|user[-\s]?cancel/.test(msg);
}

function _isTransientRelayError(err, statusCode = 0, errorText = '') {
  const status = Number(statusCode || 0);
  if ([408, 409, 425, 429, 500, 502, 503, 504, 529].includes(status)) return true;
  const msg = String(errorText || err?.message || '').toLowerCase();
  if (!msg) return false;
  if (/request timeout|proxy timeout|timed out|deadline exceeded/.test(msg)) return true;
  if (/(?:econnreset|econnrefused|enotfound|ehostunreach|enetunreach|eai_again|socket hang up|fetch failed|getaddrinfo|network error|broken pipe)/.test(msg)) return true;
  if (/client network socket disconnected before secure tls connection was established|before secure tls connection was established/.test(msg)) return true;
  if (/temporarily unavailable|service unavailable|bad gateway/.test(msg)) return true;
  return false;
}

function _classifyRelayFailure(errorText = '', statusCode = 0) {
  const status = Number(statusCode || 0);
  const lower = String(errorText || '').toLowerCase();
  if (/request timeout|proxy timeout|timed out|deadline exceeded/.test(lower)) return 'timeout';
  if (status === 401 || status === 403 || /unauthorized|forbidden|invalid api key|auth/.test(lower)) return 'auth';
  if (status === 429 || /rate limit|too many requests/.test(lower)) return 'rate_limit';
  if (_isTransientRelayError(null, status, lower)) return 'network';
  if (status >= 500 && status < 600) return 'server_error';
  return 'unknown';
}

function _sleepAbortable(delayMs, signal = null) {
  return new Promise((resolve, reject) => {
    const waitMs = Math.max(0, Math.floor(Number(delayMs) || 0));
    if (waitMs <= 0) {
      resolve();
      return;
    }
    if (signal && signal.aborted) {
      reject(createAbortError(signal.reason));
      return;
    }
    let timer = null;
    const onAbort = () => {
      if (timer) clearTimeout(timer);
      if (signal) {
        try { signal.removeEventListener('abort', onAbort); } catch { /* ignore */ }
      }
      reject(createAbortError(signal ? signal.reason : null));
    };
    if (signal) {
      signal.addEventListener('abort', onAbort, { once: true });
    }
    timer = setTimeout(() => {
      if (signal) {
        try { signal.removeEventListener('abort', onAbort); } catch { /* ignore */ }
      }
      resolve();
    }, waitMs);
    timer.unref?.();
  });
}

// ── Config helpers ──

function getConfig() {
  return {
    endpoint: process.env.RELAY_API_ENDPOINT || '',
    key: extractPrimaryApiKey(process.env.RELAY_API_KEY),
    model: process.env.RELAY_API_MODEL || DEFAULT_MODEL,
  };
}

// ── HTTP request with optional proxy support ──

function makeRequest(url, { method = 'POST', headers = {}, body, timeout = TIMEOUT_MS, signal = null } = {}) {
  return new Promise((resolve, reject) => {
    if (signal && signal.aborted) {
      reject(createAbortError(signal.reason));
      return;
    }

    let settled = false;
    let connectReq = null;
    let activeReq = null;

    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      if (signal && onAbort) {
        try { signal.removeEventListener('abort', onAbort); } catch { /* ignore */ }
      }
      fn(value);
    };
    const finishResolve = (value) => finish(resolve, value);
    const finishReject = (err) => finish(reject, err);
    const onAbort = () => {
      const abortErr = createAbortError(signal ? signal.reason : null);
      try { if (connectReq && !connectReq.destroyed) connectReq.destroy(abortErr); } catch { /* ignore */ }
      try { if (activeReq && !activeReq.destroyed) activeReq.destroy(abortErr); } catch { /* ignore */ }
      finishReject(abortErr);
    };
    if (signal) {
      signal.addEventListener('abort', onAbort, { once: true });
    }

    const parsed = new URL(url);
    const mod = parsed.protocol === 'https:' ? https : http;

    // Check for proxy environment variables
    const proxyUrl = process.env.https_proxy || process.env.HTTPS_PROXY ||
                     process.env.http_proxy || process.env.HTTP_PROXY;

    // TLS Sidecar: route through sidecar for configured target domains
    let effectiveProxy = proxyUrl;
    try {
      const sidecar = require('../tlsSidecar');
      if (sidecar.shouldProxy(parsed.hostname)) {
        effectiveProxy = sidecar.getProxyUrl();
      }
    } catch { /* sidecar not available */ }

    let options = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method,
      headers,
      timeout,
    };

    // If proxy is configured, route through it
    if (effectiveProxy && parsed.protocol === 'https:') {
      try {
        const proxy = new URL(effectiveProxy);
        // CONNECT tunnel via proxy
        connectReq = http.request({
          hostname: proxy.hostname,
          port: proxy.port || 80,
          method: 'CONNECT',
          path: `${parsed.hostname}:${parsed.port || 443}`,
          timeout,
        });
        connectReq.on('connect', (res, socket) => {
          if (res.statusCode !== 200) {
            finishReject(new Error(`Proxy CONNECT failed: ${res.statusCode}`));
            return;
          }
          const tunnelOptions = {
            ...options,
            socket,
            agent: false,
          };
          activeReq = https.request(tunnelOptions, handleResponse(finishResolve, finishReject));
          activeReq.on('error', finishReject);
          activeReq.on('timeout', () => {
            activeReq.destroy();
            finishReject(new Error('request timeout'));
          });
          if (body) activeReq.write(typeof body === 'string' ? body : JSON.stringify(body));
          activeReq.end();
        });
        connectReq.on('error', finishReject);
        connectReq.on('timeout', () => {
          connectReq.destroy();
          finishReject(new Error('proxy timeout'));
        });
        connectReq.end();
        return;
      } catch { /* fall through to direct request */ }
    }

    activeReq = mod.request(options, handleResponse(finishResolve, finishReject));
    activeReq.on('error', finishReject);
    activeReq.on('timeout', () => {
      activeReq.destroy();
      finishReject(new Error('request timeout'));
    });
    if (body) activeReq.write(typeof body === 'string' ? body : JSON.stringify(body));
    activeReq.end();
  });
}

function handleResponse(resolve, reject) {
  return (res) => {
    // For streaming: return the response object directly
    if (res.headers['content-type']?.includes('text/event-stream')) {
      resolve({ status: res.statusCode, stream: res, headers: res.headers });
      return;
    }
    let data = '';
    res.on('data', chunk => { data += chunk; });
    res.on('end', () => {
      try { resolve({ status: res.statusCode, data: JSON.parse(data), headers: res.headers }); }
      catch { resolve({ status: res.statusCode, data, headers: res.headers }); }
    });
    res.on('error', reject);
  };
}

// ── SSE stream parser ──

function parseSSEStream(stream, onChunk, signal = null) {
  return new Promise((resolve, reject) => {
    if (signal && signal.aborted) {
      reject(createAbortError(signal.reason));
      return;
    }

    let content = '';
    let model = null;
    let buffer = '';
    const onAbort = () => {
      const err = createAbortError(signal ? signal.reason : null);
      try { stream.destroy(err); } catch { /* ignore */ }
      if (signal) {
        try { signal.removeEventListener('abort', onAbort); } catch { /* ignore */ }
      }
      reject(err);
    };
    if (signal) {
      signal.addEventListener('abort', onAbort, { once: true });
    }

    stream.on('data', (chunk) => {
      buffer += chunk.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop() || ''; // keep incomplete line in buffer

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const payload = line.slice(6).trim();
          if (payload === '[DONE]') continue;
          try {
            const obj = JSON.parse(payload);
            // OpenAI format
            const delta = obj.choices?.[0]?.delta;
            if (delta?.content) {
              content += delta.content;
              if (onChunk) onChunk({ type: 'text', text: delta.content });
            }
            // Anthropic format (some relays use this)
            if (obj.type === 'content_block_delta' && obj.delta?.text) {
              content += obj.delta.text;
              if (onChunk) onChunk({ type: 'text', text: obj.delta.text });
            }
            // Thinking content
            if (delta?.reasoning_content || delta?.thinking) {
              const text = delta.reasoning_content || delta.thinking;
              if (onChunk) onChunk({ type: 'thinking', text });
            }
            if (obj.model) model = obj.model;
          } catch { /* skip malformed SSE */ }
        }
      }
    });

    stream.on('end', () => {
      if (signal) {
        try { signal.removeEventListener('abort', onAbort); } catch { /* ignore */ }
      }
      resolve({ content, model });
    });
    stream.on('error', (err) => {
      if (signal) {
        try { signal.removeEventListener('abort', onAbort); } catch { /* ignore */ }
      }
      reject(err);
    });
  });
}

// ── Adapter interface ──

function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;
  const cfg = getConfig();
  _available = !!(cfg.endpoint && cfg.key);
  if (forceRefresh) _modelsCache = { at: 0, list: null };
  return _available;
}

function parseRelayModelHints() {
  const raw = String(process.env.RELAY_API_MODELS || '').trim();
  if (!raw) return [];
  return raw
    .split(',')
    .map(s => s.trim())
    .filter(Boolean)
    .map(id => ({
      id,
      name: id,
      isDefault: false,
      provider: 'relay_api',
      description: '',
      discoverySource: 'hint',
    }));
}

async function listModels() {
  const cfg = getConfig();
  const endpoint = (cfg.endpoint || '').replace(/\/+$/, '');
  const key = cfg.key || '';

  const fallback = [
    {
      id: cfg.model || DEFAULT_MODEL,
      name: cfg.model || DEFAULT_MODEL,
      isDefault: true,
      provider: 'relay_api',
      description: '',
      discoverySource: 'config',
    },
    ...parseRelayModelHints(),
  ];

  if (!endpoint || !key) return fallback;

  const now = Date.now();
  if (_modelsCache.list && now - _modelsCache.at < MODELS_CACHE_TTL_MS) {
    return _modelsCache.list;
  }

  try {
    const res = await makeRequest(`${endpoint}/models`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${key}`,
        'Accept': 'application/json',
      },
      body: null,
      timeout: 15000,
    });
    if (res.status === 200 && res.data) {
      const rows = Array.isArray(res.data.data) ? res.data.data : [];
      const models = rows
        .map(m => ({
          id: String(m.id || '').trim(),
          name: String(m.id || '').trim(),
          isDefault: String(m.id || '').trim() === (cfg.model || DEFAULT_MODEL),
          provider: 'relay_api',
          description: '',
          discoverySource: 'remote',
        }))
        .filter(m => !!m.id);

      if (models.length > 0) {
        _modelsCache = { at: now, list: models };
        return models;
      }
    }
  } catch {
    // fallback below
  }

  _modelsCache = { at: now, list: fallback };
  return fallback;
}

async function generate(prompt, options = {}) {
  const cfg = getConfig();
  // Support external key/endpoint override (from apiKeyPool)
  const activeKey = options.apiKey || cfg.key;
  const activeEndpoint = options.apiEndpoint || cfg.endpoint;

  if (!activeEndpoint || !activeKey) {
    return {
      success: false, content: '', provider: 'Relay API', adapter: 'relay_api',
      error: 'RELAY_API_ENDPOINT and RELAY_API_KEY not configured',
      attempts: [{ provider: 'Relay API', success: false, error: 'not_configured' }],
    };
  }

  const model = options.model || cfg.model;
  const endpoint = activeEndpoint.replace(/\/+$/, '');
  const url = `${endpoint}/chat/completions`;
  const useStream = !!(options.onChunk);
  const signal = options.abortSignal || options.signal || null;
  const timeoutMs = Number.isFinite(Number(options.timeoutMs))
    ? Math.max(1000, Number(options.timeoutMs))
    : TIMEOUT_MS;
  const envRetryAttempts = process.env.RELAY_API_RETRY_ATTEMPTS;
  const envRetryTotalAttempts = process.env.RELAY_API_RETRY_TOTAL_ATTEMPTS;
  const totalAttempts = (() => {
    if (options.retryTotalAttempts !== undefined) {
      return _parsePositiveInt(options.retryTotalAttempts, DEFAULT_RETRY_TOTAL_ATTEMPTS, 1, 8);
    }
    if (envRetryTotalAttempts !== undefined) {
      return _parsePositiveInt(envRetryTotalAttempts, DEFAULT_RETRY_TOTAL_ATTEMPTS, 1, 8);
    }
    if (envRetryAttempts !== undefined) {
      const retryOnly = _parsePositiveInt(envRetryAttempts, DEFAULT_RETRY_TOTAL_ATTEMPTS - 1, 0, 7);
      return Math.min(8, retryOnly + 1);
    }
    return DEFAULT_RETRY_TOTAL_ATTEMPTS;
  })();
  const retryBaseDelayMs = _parseMs(
    options.retryBaseDelayMs ?? process.env.RELAY_API_RETRY_BASE_DELAY_MS ?? String(DEFAULT_RETRY_BASE_DELAY_MS),
    DEFAULT_RETRY_BASE_DELAY_MS,
    50
  );
  const retryMaxDelayMs = _parseMs(
    options.retryMaxDelayMs ?? process.env.RELAY_API_RETRY_MAX_DELAY_MS ?? String(DEFAULT_RETRY_MAX_DELAY_MS),
    DEFAULT_RETRY_MAX_DELAY_MS,
    retryBaseDelayMs
  );

  // Build messages: use structured messages if provided, else wrap prompt
  let messages;
  if (options.messages && options.messages.length > 0) {
    messages = options.messages.map(m => ({ role: m.role, content: m.content }));
    // Prepend system message if provided
    if (options.system) {
      messages = [{ role: 'system', content: options.system }, ...messages];
    }
  } else {
    messages = [{ role: 'user', content: prompt }];
    if (options.system) {
      messages = [{ role: 'system', content: options.system }, ...messages];
    }
  }

  const body = {
    model,
    messages,
    stream: useStream,
    temperature: options.temperature ?? 0.3,
    max_tokens: options.maxTokens ?? 2048,
  };

  let streamedChars = 0;
  const trackedOnChunk = (chunk) => {
    if (chunk && chunk.type === 'text' && chunk.text) {
      streamedChars += String(chunk.text).length;
    }
    if (typeof options.onChunk === 'function') {
      try { options.onChunk(chunk); } catch { /* best effort */ }
    }
  };

  for (let attemptNo = 1; attemptNo <= totalAttempts; attemptNo++) {
    const isRetryAttempt = attemptNo > 1;
    try {
      if (isRetryAttempt && typeof options.onChunk === 'function') {
        try {
          options.onChunk({
            type: 'status',
            text: `Relay API 网络重试 ${attemptNo}/${totalAttempts}（目标: ${model}）`,
          });
        } catch { /* best effort */ }
      }
      const res = await makeRequest(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${activeKey}`,
          'Accept': useStream ? 'text/event-stream' : 'application/json',
        },
        body,
        timeout: timeoutMs,
        signal,
      });

      if (res.status !== 200 && !res.stream) {
        const errMsg = res.data?.error?.message || res.data?.message || `HTTP ${res.status}`;
        const errorType = _classifyRelayFailure(errMsg, res.status);
        const canRetry = attemptNo < totalAttempts && _isTransientRelayError(null, res.status, errMsg);
        if (canRetry) {
          const delayMs = Math.min(
            retryMaxDelayMs,
            Math.round(retryBaseDelayMs * Math.pow(1.8, Math.max(0, attemptNo - 1)))
          );
          if (typeof options.onChunk === 'function') {
            try {
              options.onChunk({
                type: 'status',
                text: `Relay API 请求失败（HTTP ${res.status}），等待 ${delayMs}ms 后继续重试 ${attemptNo + 1}/${totalAttempts}`,
              });
            } catch { /* best effort */ }
          }
          await _sleepAbortable(delayMs, signal);
          continue;
        }
        return {
          success: false, content: '', provider: 'Relay API', adapter: 'relay_api',
          error: errMsg, errorType, statusCode: res.status, headers: res.headers || null,
          attempts: [{ provider: `Relay API (${model})`, success: false, error: errMsg, statusCode: res.status, errorType }],
        };
      }

      // Streaming response
      if (res.stream) {
        const { content, model: usedModel } = await parseSSEStream(res.stream, trackedOnChunk, signal);
        const displayModel = usedModel || model;
        return {
          success: true,
          content: content.trim(),
          provider: `Relay (${displayModel})`,
          adapter: 'relay_api',
          model: displayModel,
          attempts: [{ provider: `Relay API (${displayModel})`, success: true }],
        };
      }

      // Non-streaming response
      const data = res.data;
      const content = data.choices?.[0]?.message?.content ||
                      data.content?.[0]?.text || // Anthropic format
                      '';
      const usedModel = data.model || model;

      if (!content) {
        return {
          success: false, content: '', provider: 'Relay API', adapter: 'relay_api',
          error: 'Empty response',
          errorType: 'unknown',
          attempts: [{ provider: `Relay API (${usedModel})`, success: false, error: 'empty_response', errorType: 'unknown' }],
        };
      }

      return {
        success: true,
        content: content.trim(),
        provider: `Relay (${usedModel})`,
        adapter: 'relay_api',
        model: usedModel,
        tokenUsage: data.usage ? {
          inputTokens: data.usage.prompt_tokens,
          outputTokens: data.usage.completion_tokens,
          totalTokens: data.usage.total_tokens,
        } : null,
        attempts: [{ provider: `Relay API (${usedModel})`, success: true }],
      };
    } catch (err) {
      if (_isAbortLikeError(err)) {
        return {
          success: false, content: '', provider: 'Relay API', adapter: 'relay_api',
          error: err.message,
          errorType: 'cancelled',
          attempts: [{ provider: `Relay API (${model})`, success: false, error: err.message, errorType: 'cancelled' }],
        };
      }
      const errMsg = String(err?.message || 'unknown error');
      const errorType = _classifyRelayFailure(errMsg, err?.status || err?.statusCode || 0);
      const canRetry = attemptNo < totalAttempts
        && _isTransientRelayError(err, err?.status || err?.statusCode || 0, errMsg)
        && !(useStream && streamedChars > 0);
      if (canRetry) {
        const delayMs = Math.min(
          retryMaxDelayMs,
          Math.round(retryBaseDelayMs * Math.pow(1.8, Math.max(0, attemptNo - 1)))
        );
        if (typeof options.onChunk === 'function') {
          try {
            options.onChunk({
              type: 'status',
              text: `Relay API 网络抖动（${errMsg.slice(0, 80)}），等待 ${delayMs}ms 后继续重试 ${attemptNo + 1}/${totalAttempts}`,
            });
          } catch { /* best effort */ }
        }
        await _sleepAbortable(delayMs, signal);
        continue;
      }
      return {
        success: false, content: '', provider: 'Relay API', adapter: 'relay_api',
        error: errMsg,
        errorType,
        attempts: [{ provider: `Relay API (${model})`, success: false, error: errMsg, errorType }],
      };
    }
  }

  return {
    success: false,
    content: '',
    provider: 'Relay API',
    adapter: 'relay_api',
    error: 'Relay API retries exhausted',
    errorType: 'network',
    attempts: [{ provider: `Relay API (${model})`, success: false, error: 'retries exhausted', errorType: 'network' }],
  };
}

function getStatus() {
  detect();
  const cfg = getConfig();
  let detail;
  if (_available) {
    const endpoint = cfg.endpoint.replace(/\/+$/, '');
    const host = (() => { try { return new URL(endpoint).hostname; } catch { return endpoint; } })();
    detail = `已配置 → ${host} (${cfg.model})`;
  } else {
    detail = '未配置 — 运行 khy gateway config 设置中转地址和密钥';
  }
  return { name: 'API 中转', type: 'relay_api', available: _available, detail };
}

function destroy() {
  _available = null;
  _modelsCache = { at: 0, list: null };
}

module.exports = { detect, listModels, generate, getStatus, destroy };
