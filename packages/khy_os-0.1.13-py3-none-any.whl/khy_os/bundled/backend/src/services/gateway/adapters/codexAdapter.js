/**
 * Codex Adapter — invoke OpenAI Codex CLI or direct Responses API.
 *
 * Two modes:
 *   cli    (default) — spawns `codex exec --json`, Codex manages its own tool loop
 *   direct — calls Mindflow Responses API directly, KHY manages tool loop with native tools
 *
 * Set GATEWAY_CODEX_MODE=direct to use the API mode with Glob/Grep/Read/Edit/Write.
 */
const { execFileSync, spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { extractPrimaryApiKey } = require('../../apiKeyFormat');
const { toCodexInputImages } = require('./_imageCompat');
const { safeKill } = require('../../../tools/platformUtils');

const TIMEOUT_MS = parseInt(
  process.env.GATEWAY_CODEX_TIMEOUT_MS
  || process.env.KHY_CODEX_TIMEOUT_MS
  || '45000',
  10
);
const PROBE_TIMEOUT_MS = 4000;
const VERSION_PROBE_TIMEOUT_MS = 3500;
const MAX_BUFFER = 10 * 1024 * 1024;

// ── Direct mode constants ─────────────────────────────────────────
const CODEX_MODE = String(process.env.GATEWAY_CODEX_MODE || 'cli').trim().toLowerCase();
const CODEX_DIRECT_TIMEOUT_MS = parseInt(process.env.CODEX_DIRECT_TIMEOUT_MS || '120000', 10);
const CODEX_DIRECT_MAX_ITERATIONS = parseInt(process.env.CODEX_DIRECT_MAX_ITERATIONS || '10', 10);

// Auto-raise gateway per-adapter timeout for direct mode (multi-turn tool loop needs more time)
if (CODEX_MODE === 'direct' && !process.env.GATEWAY_CODEX_TIMEOUT_MS) {
  process.env.GATEWAY_CODEX_TIMEOUT_MS = '120000';
}

// Fallback models if config cannot be read
const FALLBACK_MODELS = [
  { id: 'o4-mini', name: 'o4-mini', isDefault: true },
  { id: 'o3', name: 'o3', isDefault: false },
  { id: 'gpt-4.1', name: 'GPT-4.1', isDefault: false },
];

let _available = null;
let _lastDetectError = '';
let _execProbeOk = null;
let _lastExecProbeError = '';
let _configCache = null;
let _providerModels = null; // cached set of model IDs from provider API
let _runtimeDiagnostics = {
  at: 0,
  healed: false,
  diagnosis: '',
  lastError: '',
  trigger: '',
};

function isReconnectChannelClosed(message = '') {
  return /reconnecting|channel closed|failed to record rollout items/i.test(String(message || ''));
}

function safeEmitStatus(options, text) {
  if (!options || typeof options.onChunk !== 'function') return;
  try { options.onChunk({ type: 'status', text: String(text || '') }); } catch { /* best effort */ }
}

function recordRuntimeDiagnostics(payload = {}) {
  _runtimeDiagnostics = {
    at: Date.now(),
    healed: !!payload.healed,
    diagnosis: compactText(payload.diagnosis || '', 320),
    lastError: compactText(payload.lastError || '', 320),
    trigger: String(payload.trigger || 'unknown').trim() || 'unknown',
  };
}

function getRuntimeDiagnostics() {
  return { ..._runtimeDiagnostics };
}

function compactText(value, maxLen = 200) {
  const t = String(value || '').replace(/\s+/g, ' ').trim();
  if (!t) return '';
  return t.length > maxLen ? `${t.slice(0, maxLen - 1)}…` : t;
}

function escapeRegExp(text = '') {
  return String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function parseTomlSection(content = '', sectionName = '') {
  const key = String(sectionName || '').trim();
  if (!key) return '';
  const pattern = new RegExp(`\\[${escapeRegExp(key)}\\]([\\s\\S]*?)(?=\\n\\[|$)`);
  const matched = String(content || '').match(pattern);
  return matched ? String(matched[1] || '') : '';
}

function extractQuotedValue(source = '', key = '') {
  const k = String(key || '').trim();
  if (!k) return null;
  const matched = String(source || '').match(new RegExp(`^\\s*${escapeRegExp(k)}\\s*=\\s*"([^"]+)"\\s*$`, 'm'));
  return matched ? String(matched[1] || '').trim() : null;
}

function isOpenAIBaseUrl(rawUrl = '') {
  const input = String(rawUrl || '').trim();
  if (!input) return false;
  try {
    const parsed = new URL(input);
    return parsed.hostname.toLowerCase() === 'api.openai.com';
  } catch {
    return /api\.openai\.com/i.test(input);
  }
}

function hasCustomProviderConfig(config = {}) {
  const modelProvider = String(config.modelProvider || '').trim().toLowerCase();
  if (modelProvider && modelProvider !== 'openai' && modelProvider !== 'oss') return true;
  if (config.providerBaseUrl && !isOpenAIBaseUrl(config.providerBaseUrl)) return true;
  return false;
}

function isLikelyProviderTransportFailure(message = '') {
  const lower = String(message || '').toLowerCase();
  return (
    /reconnecting|channel closed|failed to record rollout items|stream disconnected|error sending request for url/.test(lower)
    || /network|fetch failed|socket hang up|getaddrinfo|econn|enotfound|ehostunreach|enetunreach|tls|proxy/.test(lower)
    || /timeout|timed out|deadline exceeded|http 5\d\d/.test(lower)
  );
}

function buildOpenAIFallbackArgs(baseArgs = []) {
  const args = Array.isArray(baseArgs) ? baseArgs.slice() : [];
  // Avoid carrying custom-provider model slug into OpenAI fallback.
  const modelIdx = args.indexOf('--model');
  if (modelIdx >= 0) args.splice(modelIdx, 2);
  args.push('-c', 'model_provider="openai"');
  args.push('-c', 'openai_base_url="https://api.openai.com/v1"');
  const fallbackModel = String(process.env.GATEWAY_CODEX_OPENAI_FALLBACK_MODEL || '').trim();
  if (fallbackModel) args.push('-c', `model="${fallbackModel}"`);
  return args;
}

function shouldTryOpenAIFallback(message = '', config = {}, options = {}) {
  const enabled = String(
    process.env.GATEWAY_CODEX_OPENAI_FALLBACK_ENABLED
    || process.env.GATEWAY_CODEX_PROVIDER_FALLBACK_OPENAI
    || 'true'
  ).toLowerCase() !== 'false';
  if (!enabled) return false;
  if (options && options.disableProviderFallback) return false;
  if (!hasCustomProviderConfig(config)) return false;
  return isLikelyProviderTransportFailure(message);
}

function resolveExecTimeoutMs(options = {}) {
  const envTimeout = parseInt(
    process.env.GATEWAY_CODEX_TIMEOUT_MS
    || process.env.KHY_CODEX_TIMEOUT_MS
    || String(TIMEOUT_MS),
    10
  ) || TIMEOUT_MS;
  const hasExplicitTimeout = options.timeoutMs !== undefined && options.timeoutMs !== null && options.timeoutMs !== '';
  let timeoutMs = hasExplicitTimeout
    ? parseInt(options.timeoutMs, 10)
    : envTimeout;
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) timeoutMs = envTimeout;
  timeoutMs = Math.max(15000, timeoutMs);

  const modelHint = String(options.model || '').toLowerCase();
  const maxTokens = parseInt(options.maxTokens || 0, 10) || 0;
  const highComplexity = !!options.thinking
    || maxTokens >= 4096
    || /claude-opus|opus|gpt-5|o3|o4|reason/i.test(modelHint);

  // For high-effort/high-context requests, avoid premature 45s class timeouts.
  if (!hasExplicitTimeout && highComplexity) {
    timeoutMs = Math.max(timeoutMs, 120000);
  }

  const maxTimeout = Math.max(
    30000,
    parseInt(process.env.GATEWAY_CODEX_MAX_TIMEOUT_MS || '86400000', 10) || 86400000
  );
  timeoutMs = Math.min(timeoutMs, maxTimeout);
  return timeoutMs;
}

function probeCodexVersion() {
  try {
    const r = spawnSync('codex', ['--version'], {
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: VERSION_PROBE_TIMEOUT_MS,
      encoding: 'utf-8',
      env: process.env,
    });
    if (r && !r.error && r.status === 0) {
      const out = compactText((r.stdout || r.stderr || '').trim(), 120) || 'ok';
      return { ok: true, detail: out };
    }
    if (r && r.error) return { ok: false, detail: compactText(r.error.message || String(r.error), 120) || 'probe error' };
    return { ok: false, detail: compactText(`exit ${r?.status}`, 120) };
  } catch (err) {
    return { ok: false, detail: compactText(err && err.message ? err.message : String(err), 120) || 'probe exception' };
  }
}

function diagnoseReconnectFailure(errMessage = '') {
  const parts = [];
  const versionProbe = probeCodexVersion();
  parts.push(versionProbe.ok ? `codex=${versionProbe.detail}` : `codex_probe=${versionProbe.detail}`);

  const execUsable = probeExecUsable(true);
  if (!execUsable) {
    parts.push(`exec_probe=${compactText(_lastExecProbeError || 'unavailable', 120)}`);
  } else {
    parts.push('exec_probe=ok');
  }

  const config = readCodexConfig() || {};
  if (config.model) parts.push(`config_model=${compactText(config.model, 64)}`);
  if (config.profile) parts.push(`profile=${compactText(config.profile, 64)}`);
  if (config.providerBaseUrl) parts.push(`provider=${compactText(config.providerBaseUrl, 96)}`);
  if (/sandbox/i.test(String(errMessage || ''))) parts.push('hint=retry_no_sbx');

  return compactText(parts.join('; '), 320);
}

function maybeSelfHealReconnect(options = {}) {
  const autoHealEnabled = String(
    process.env.GATEWAY_CODEX_AUTO_DISABLE_SANDBOX_ON_RECONNECT || 'true'
  ).toLowerCase() !== 'false';
  if (!autoHealEnabled) return false;

  const current = String(process.env.GATEWAY_CODEX_SANDBOX || 'workspace-write').trim().toLowerCase();
  if (!current || current === 'none') return false;

  process.env.GATEWAY_CODEX_SANDBOX = 'none';
  safeEmitStatus(options, 'Codex 自愈: 已临时禁用 sandbox（仅当前进程），后续请求将自动重试该模式');
  return true;
}

function normalizeAbortReason(reason) {
  if (!reason) return 'aborted';
  if (typeof reason === 'string') return reason;
  if (reason && typeof reason.message === 'string') return reason.message;
  try { return JSON.stringify(reason); } catch { return String(reason); }
}

function isAbortLikeError(err) {
  const msg = String(err && err.message ? err.message : err || '');
  const lower = msg.toLowerCase();
  return (
    err && (
      err.name === 'AbortError'
      || err.code === 'ABORT_ERR'
      || /\baborted\b|\brequest aborted\b|\babort(ed)? by\b|signal aborted|user[-\s]?cancel/.test(lower)
    )
  );
}

function summarizeValue(v, maxLen = 180) {
  try {
    const str = typeof v === 'string' ? v : JSON.stringify(v);
    if (!str) return '';
    const oneLine = str.replace(/\s+/g, ' ').trim();
    return oneLine.length > maxLen ? `${oneLine.slice(0, maxLen - 1)}…` : oneLine;
  } catch {
    return '';
  }
}

function extractMessageText(item) {
  if (!item || typeof item !== 'object') return '';
  if (typeof item.text === 'string' && item.text.trim()) return item.text.trim();
  if (typeof item.message === 'string' && item.message.trim()) return item.message.trim();

  const pullFromContent = (content) => {
    if (!Array.isArray(content)) return '';
    const parts = [];
    for (const blk of content) {
      if (!blk) continue;
      if (typeof blk === 'string') {
        parts.push(blk);
        continue;
      }
      if (typeof blk.text === 'string' && blk.text.trim()) {
        parts.push(blk.text.trim());
      }
    }
    return parts.join('\n').trim();
  };

  const fromContent = pullFromContent(item.content);
  if (fromContent) return fromContent;
  const fromMsgContent = pullFromContent(item.message?.content);
  if (fromMsgContent) return fromMsgContent;
  const fromResultContent = pullFromContent(item.result?.content);
  if (fromResultContent) return fromResultContent;
  return '';
}

function getItemType(event) {
  return String(event?.item?.type || event?.item_type || event?.type || '').toLowerCase();
}

function inferToolName(itemType, item) {
  if ((itemType.includes('command') || itemType.includes('shell')) && item?.command) return 'bash';
  // Detect file write/edit operations
  if (itemType.includes('file') || itemType.includes('write') || itemType.includes('edit') || itemType.includes('patch')) {
    if (itemType.includes('write') || itemType.includes('create')) return 'file_write';
    if (itemType.includes('edit') || itemType.includes('patch')) return 'file_edit';
    return 'file_op';
  }
  return item?.tool_name || item?.name || item?.tool || item?.command_name || 'tool';
}

function inferToolInput(itemType, item) {
  if ((itemType.includes('command') || itemType.includes('shell')) && item?.command) return summarizeValue(item.command, 120);
  // Surface file path for file operations
  if (item?.file_path || item?.path) {
    const fp = item.file_path || item.path;
    const extra = item?.description || item?.summary || '';
    return summarizeValue(extra ? `${fp} — ${extra}` : fp, 120);
  }
  return summarizeValue(item?.input || item?.arguments || item?.params || item?.request || '', 120);
}

function inferToolOutput(itemType, item) {
  if ((itemType.includes('command') || itemType.includes('shell')) && item?.output) return summarizeValue(item.output, 180);
  // File operation output
  if (item?.file_path || item?.path) {
    const fp = item.file_path || item.path;
    return summarizeValue(item?.result || item?.response || item?.output || `wrote ${fp}`, 180);
  }
  return summarizeValue(item?.result || item?.response || item?.output || item?.content || '', 180);
}

function isToolLike(itemType, item) {
  if (!itemType) return false;
  if (itemType.includes('tool') || itemType.includes('command') || itemType.includes('shell')) return true;
  // Capture file operations (write, edit, patch, create, delete) emitted by Codex
  if (itemType.includes('file') || itemType.includes('write') || itemType.includes('edit') || itemType.includes('patch')) return true;
  // Capture code interpreter / execution events
  if (itemType.includes('exec') || itemType.includes('action')) return true;
  return !!(item && (item.tool_name || item.command || item.file_path || item.path));
}

function emitCodexEvent(event, state, options = {}) {
  const onChunk = typeof options.onChunk === 'function' ? options.onChunk : null;
  const emit = (chunk) => { if (onChunk) onChunk(chunk); };
  const eventType = String(event?.type || '').toLowerCase();
  const item = event?.item || {};
  const itemType = getItemType(event);
  const itemId = String(item.id || event.item_id || event.id || `${eventType}:${Date.now()}`);
  const now = Date.now();

  if (eventType === 'error') {
    emit({ type: 'status', text: String(event.message || 'codex error') });
    return;
  }

  if (eventType === 'turn.started') {
    emit({ type: 'status', text: 'Codex 开始处理请求' });
    return;
  }
  if (eventType === 'turn.completed') {
    emit({ type: 'status', text: 'Codex 完成处理' });
    return;
  }

  if (eventType.startsWith('item.')) {
    if (eventType === 'item.started') {
      if (itemType.includes('reasoning')) {
        const t = summarizeValue(item.text || item.summary || '开始思考', 120);
        emit({ type: 'thinking', text: t });
        return;
      }
      if (isToolLike(itemType, item)) {
        state.toolCalls += 1;
        state.activeTools.set(itemId, { startedAt: now, tool: inferToolName(itemType, item) });
        emit({
          type: 'tool_use',
          tool: inferToolName(itemType, item),
          input: inferToolInput(itemType, item),
          id: itemId,
        });
        return;
      }
      return;
    }

    if (eventType === 'item.updated') {
      if (itemType.includes('reasoning')) {
        const t = summarizeValue(item.text || item.summary || event.delta || '', 120);
        if (t) emit({ type: 'thinking', text: t });
      }
      return;
    }

    if (eventType === 'item.completed') {
      if (itemType.includes('reasoning')) {
        const t = summarizeValue(item.text || item.summary || '思考完成', 120);
        if (t) emit({ type: 'thinking', text: t });
        return;
      }
      if (isToolLike(itemType, item)) {
        const toolInfo = state.activeTools.get(itemId);
        if (toolInfo && toolInfo.startedAt) {
          state.toolDurationMs += Math.max(0, now - toolInfo.startedAt);
        }
        state.activeTools.delete(itemId);
        const out = inferToolOutput(itemType, item) || 'done';
        emit({ type: 'tool_result', id: itemId, content: out });
        return;
      }

      if (itemType.includes('message') || itemType.includes('assistant')) {
        const text = extractMessageText(item);
        if (text) {
          state.finalParts.push(text);
          emit({ type: 'text', text });
        }
      }
      return;
    }
  }

  // Fallback: capture possible message payload outside item.* events
  if (eventType.includes('message')) {
    const text = extractMessageText(event.item || event.message || event);
    if (text) {
      state.finalParts.push(text);
      emit({ type: 'text', text });
    }
  }
}

/**
 * Parse codex config.toml to extract configured model and provider info.
 */
function readCodexConfig() {
  if (_configCache) return _configCache;
  const homeDir = require('os').homedir();
  const candidates = [
    path.join(homeDir, '.codex', 'config.toml'),
    path.join(homeDir, '.config', 'codex', 'config.toml'),
  ];
  for (const configPath of candidates) {
    try {
      if (!fs.existsSync(configPath)) continue;
      const content = fs.readFileSync(configPath, 'utf-8');
      const result = { model: null, profile: null, modelProvider: null, providerBaseUrl: null };

      // Extract top-level model
      result.model = extractQuotedValue(content, 'model') || null;

      // Extract profile
      result.profile = extractQuotedValue(content, 'profile') || null;
      result.modelProvider = extractQuotedValue(content, 'model_provider') || null;

      // Extract profile-specific settings (override top-level)
      if (result.profile) {
        const profileSection = parseTomlSection(content, `profiles.${result.profile}`);
        const pModel = extractQuotedValue(profileSection, 'model');
        if (pModel) result.model = pModel;
        const pProvider = extractQuotedValue(profileSection, 'model_provider');
        if (pProvider) result.modelProvider = pProvider;
      }

      // Extract provider base_url (prefer selected provider section)
      if (result.modelProvider) {
        const providerSection = (
          parseTomlSection(content, `model_providers.${result.modelProvider}`)
          || parseTomlSection(content, `providers.${result.modelProvider}`)
        );
        const providerUrl = extractQuotedValue(providerSection, 'base_url');
        if (providerUrl) result.providerBaseUrl = providerUrl;
      }
      if (!result.providerBaseUrl) {
        const providerMatch = content.match(/base_url\s*=\s*"([^"]+)"/);
        if (providerMatch) result.providerBaseUrl = providerMatch[1];
      }

      _configCache = result;
      return result;
    } catch { /* ignore */ }
  }
  _configCache = {};
  return _configCache;
}

function commandExists(cmd) {
  // Primary detection: execute the command directly.
  try {
    const r = spawnSync(cmd, ['--version'], {
      stdio: 'ignore',
      timeout: 5000,
      env: process.env,
    });
    if (r && !r.error && r.status === 0) {
      _lastDetectError = '';
      return true;
    }
    if (r && r.error) {
      _lastDetectError = r.error.message || String(r.error);
    } else if (typeof r.status === 'number' && r.status !== 0) {
      _lastDetectError = `exit ${r.status}`;
    }
  } catch (err) {
    _lastDetectError = err.message || String(err);
  }

  // Fallback: PATH lookup (best-effort only).
  try {
    const lookup = process.platform === 'win32' ? 'where' : 'which';
    execFileSync(lookup, [cmd], { stdio: 'pipe', timeout: 5000 });
    _lastDetectError = '';
    return true;
  } catch (err) {
    _lastDetectError = _lastDetectError || err.message || String(err);
    return false;
  }
}

function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;
  // Direct mode only needs CODEX_API_KEY (or pool key), no CLI binary required
  if (CODEX_MODE === 'direct') {
    _available = !!extractPrimaryApiKey(process.env.CODEX_API_KEY);
    if (!_available) {
      try {
        const pool = require('../../apiKeyPool');
        pool.init();
        _available = pool.hasAvailableKeys('codex') || pool.hasAvailableKeys('openai');
      } catch { /* pool unavailable */ }
    }
    _lastDetectError = _available ? '' : 'CODEX_API_KEY not set and no pool keys';
    return _available;
  }
  _available = commandExists('codex');
  if (forceRefresh) {
    _execProbeOk = null;
    _lastExecProbeError = '';
  }
  return _available;
}

function probeExecUsable(forceRefresh = false) {
  if (!forceRefresh && _execProbeOk !== null) return _execProbeOk;
  try {
    const r = spawnSync('codex', ['exec', '--help'], {
      stdio: 'ignore',
      timeout: PROBE_TIMEOUT_MS,
      env: process.env,
    });
    if (r && !r.error && r.status === 0) {
      _execProbeOk = true;
      _lastExecProbeError = '';
      return true;
    }
    if (r && r.error) {
      _lastExecProbeError = r.error.message || String(r.error);
    } else {
      _lastExecProbeError = `codex exec --help exit ${r?.status}`;
    }
    _execProbeOk = false;
    return false;
  } catch (err) {
    _lastExecProbeError = err.message || String(err);
    _execProbeOk = false;
    return false;
  }
}

function resolveUpstreamProviderMeta(config = {}) {
  const provider = String(config.modelProvider || '').trim() || 'openai';
  const rawBaseUrl = String(config.providerBaseUrl || '').trim();
  if (!rawBaseUrl) return { provider, host: '' };
  try {
    const u = new URL(rawBaseUrl);
    return { provider, host: u.host || u.hostname || rawBaseUrl };
  } catch {
    return { provider, host: rawBaseUrl };
  }
}

async function listModels() {
  const config = readCodexConfig();
  const configModel = config.model;
  const upstreamMeta = resolveUpstreamProviderMeta(config);
  const transportMode = CODEX_MODE === 'direct' ? 'direct' : 'bridge';

  // Try to fetch models from the provider's API
  if (config.providerBaseUrl) {
    try {
      const envKey = extractPrimaryApiKey(process.env.CODEX_API_KEY)
        || extractPrimaryApiKey(process.env.OPENAI_API_KEY)
        || '';
      if (envKey) {
        const https = require('https');
        const http = require('http');
        const url = new URL(`${config.providerBaseUrl}/models`);
        const client = url.protocol === 'https:' ? https : http;
        const models = await new Promise((resolve, reject) => {
          const req = client.get(url, { headers: { Authorization: `Bearer ${envKey}` }, timeout: 5000 }, (res) => {
            let data = '';
            res.on('data', chunk => { data += chunk; });
            res.on('end', () => {
              try {
                const parsed = JSON.parse(data);
                resolve((parsed.data || []).map(m => ({
                  id: m.id,
                  name: m.id,
                  isDefault: m.id === configModel,
                  provider: 'codex',
                  description: '',
                  discoverySource: 'remote',
                  connectionMode: transportMode,
                  upstreamProvider: upstreamMeta.provider,
                  upstreamHost: upstreamMeta.host,
                })));
              } catch { resolve(null); }
            });
          });
          req.on('error', () => resolve(null));
          req.on('timeout', () => { req.destroy(); resolve(null); });
        });
        if (models && models.length > 0) {
          _providerModels = new Set(models.map(m => m.id));
          return models;
        }
      }
    } catch { /* fallback below */ }
  }

  // Fallback: use config model + known defaults
  if (configModel) {
    return [
      {
        id: configModel,
        name: configModel,
        isDefault: true,
        provider: 'codex',
        description: '',
        discoverySource: 'config',
        connectionMode: transportMode,
        upstreamProvider: upstreamMeta.provider,
        upstreamHost: upstreamMeta.host,
      },
      ...FALLBACK_MODELS
        .filter(m => m.id !== configModel)
        .map(m => ({
          ...m,
          isDefault: false,
          provider: 'codex',
          description: '',
          discoverySource: 'builtin',
          connectionMode: transportMode,
          upstreamProvider: upstreamMeta.provider,
          upstreamHost: upstreamMeta.host,
        })),
    ];
  }

  return FALLBACK_MODELS.map(m => ({
    ...m,
    provider: 'codex',
    description: '',
    discoverySource: 'builtin',
    connectionMode: transportMode,
    upstreamProvider: upstreamMeta.provider,
    upstreamHost: upstreamMeta.host,
  }));
}

function isUserModelAllowed(modelId, config = {}) {
  const chosen = String(modelId || '').trim();
  if (!chosen) return false;
  if (chosen === config.model) return true;
  // If provider model catalog is not loaded yet, optimistically allow user-selected model.
  // Unknown-model failures are already handled by retry logic without --model.
  if (!_providerModels || _providerModels.size === 0) return true;
  return _providerModels.has(chosen);
}

function runCodexExec(prompt, args, options = {}) {
  return new Promise((resolve, reject) => {
    const timeoutMs = resolveExecTimeoutMs(options);
    const abortSignal = options.abortSignal || null;

    const isWin = process.platform === 'win32';
    const child = spawn(isWin ? 'codex.cmd' : 'codex', args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: process.env,
      shell: isWin,
    });

    if (options.onChunk) {
      try { options.onChunk({ type: 'status', text: 'Codex 启动中...' }); } catch { /* best effort */ }
      if (timeoutMs > 45000) {
        try { options.onChunk({ type: 'status', text: `Codex 已启用增强超时窗口：${Math.round(timeoutMs / 1000)}s` }); } catch { /* best effort */ }
      }
    }

    const jsonMode = args.includes('--json');
    let stdout = '';
    let stdoutBuffer = '';
    let stderr = '';
    const state = {
      finalParts: [],
      toolCalls: 0,
      toolDurationMs: 0,
      activeTools: new Map(),
    };
    let finished = false;
    let heartbeatTimer = null;
    let idleTimer = null;
    let killGraceTimer = null;
    let killedByIdleTimeout = false;
    let lastActivityAt = Date.now();
    const killChild = (signal = 'SIGKILL') => {
      // Some mocked or transient child-process objects may not expose pid yet.
      // In that case, call child.kill directly as a best-effort fallback.
      if ((!child || !child.pid) && child && typeof child.kill === 'function') {
        try { child.kill(signal); return; } catch { /* continue to safeKill */ }
      }
      safeKill(child, signal);
    };
    const clearIdleTimer = () => {
      if (idleTimer) {
        clearTimeout(idleTimer);
        idleTimer = null;
      }
    };
    const scheduleIdleTimeout = () => {
      if (finished || killedByIdleTimeout) return;
      clearIdleTimer();
      idleTimer = setTimeout(() => {
        if (finished || killedByIdleTimeout) return;
        const idleMs = Date.now() - lastActivityAt;
        killedByIdleTimeout = true;
        try {
          if (options.onChunk) {
            options.onChunk({
              type: 'status',
              text: `Codex idle timeout: no subprocess output for ${Math.round(idleMs / 1000)}s, stopping request`,
            });
          }
        } catch { /* best effort */ }
        killChild('SIGTERM');
        if (killGraceTimer) clearTimeout(killGraceTimer);
        killGraceTimer = setTimeout(() => {
          if (!finished) killChild('SIGKILL');
        }, 1500);
        killGraceTimer.unref?.();
      }, timeoutMs);
      idleTimer.unref?.();
    };
    const touchActivity = () => {
      lastActivityAt = Date.now();
      scheduleIdleTimeout();
    };

    let abortWatcher = null;
    const done = (err, value) => {
      if (finished) return;
      finished = true;
      clearIdleTimer();
      if (killGraceTimer) clearTimeout(killGraceTimer);
      clearInterval(heartbeatTimer);
      if (abortWatcher && abortSignal && typeof abortSignal.removeEventListener === 'function') {
        try { abortSignal.removeEventListener('abort', abortWatcher); } catch { /* ignore */ }
      }
      if (err) reject(err);
      else resolve(value);
    };

    const abortChild = (reason) => {
      const err = new Error(`codex request aborted: ${normalizeAbortReason(reason)}`);
      err.name = 'AbortError';
      err.code = 'ABORT_ERR';
      killChild('SIGKILL');
      done(err);
    };

    if (abortSignal && abortSignal.aborted) {
      abortChild(abortSignal.reason);
      return;
    }

    if (abortSignal && typeof abortSignal.addEventListener === 'function') {
      abortWatcher = () => abortChild(abortSignal.reason);
      abortSignal.addEventListener('abort', abortWatcher, { once: true });
    }

    const startedAt = Date.now();
    const heartbeatIntervalMs = Math.max(
      3000,
      parseInt(process.env.GATEWAY_CODEX_HEARTBEAT_MS || '10000', 10) || 10000
    );
    heartbeatTimer = setInterval(() => {
      if (finished || !options.onChunk) return;
      const elapsedSec = Math.max(1, Math.round((Date.now() - startedAt) / 1000));
      try { options.onChunk({ type: 'status', text: `等待 OpenAI Codex 流式输出（已等待 ${elapsedSec}s）` }); } catch { /* best effort */ }
    }, heartbeatIntervalMs);
    heartbeatTimer.unref?.();
    scheduleIdleTimeout();

    child.stdout.on('data', (chunk) => {
      touchActivity();
      if (stdout.length < MAX_BUFFER) stdout += chunk;
      const text = chunk.toString();
      if (!jsonMode) {
        if (options.onChunk) options.onChunk({ type: 'text', text });
        return;
      }
      stdoutBuffer += text;
      const lines = stdoutBuffer.split('\n');
      stdoutBuffer = lines.pop() || '';
      for (const raw of lines) {
        const line = raw.trim();
        if (!line) continue;
        let event = null;
        try { event = JSON.parse(line); } catch { /* non-JSON line from CLI wrapper */ }
        if (event && typeof event === 'object') {
          emitCodexEvent(event, state, options);
        } else if (/reconnecting|channel closed|failed to record rollout items/i.test(line)) {
          if (options.onChunk) options.onChunk({ type: 'status', text: line });
        }
      }
    });
    // Codex CLI may output JSON events to stderr (same pattern as Claude CLI >= 2.x).
    // Parse JSON lines from stderr; accumulate non-JSON as plain error text.
    let stderrJsonBuffer = '';
    child.stderr.on('data', (chunk) => {
      touchActivity();
      const raw = chunk.toString();
      stderrJsonBuffer += raw;
      const stderrLines = stderrJsonBuffer.split('\n');
      stderrJsonBuffer = stderrLines.pop();
      for (const line of stderrLines) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        if (jsonMode && trimmed.startsWith('{')) {
          try {
            const event = JSON.parse(trimmed);
            if (event && typeof event === 'object' && typeof event.type === 'string') {
              emitCodexEvent(event, state, options);
              continue;
            }
          } catch { /* not valid JSON, fall through */ }
        }
        // Non-JSON stderr — accumulate for error diagnostics
        if (stderr.length < MAX_BUFFER) stderr += trimmed + '\n';
        // Fail fast when Codex enters reconnect loop.
        if (/ERROR:\s*Reconnecting/i.test(trimmed) || /failed to record rollout items|channel closed/i.test(trimmed)) {
          killChild('SIGKILL');
          done(new Error('codex backend reconnecting/channel closed'));
        }
      }
    });

    child.on('close', (code) => {
      // Drain trailing stdout JSON buffer
      if (jsonMode && stdoutBuffer.trim()) {
        try {
          const evt = JSON.parse(stdoutBuffer.trim());
          emitCodexEvent(evt, state, options);
        } catch { /* ignore trailing partial */ }
      }
      // Drain trailing stderr buffer.
      // Important: some codex builds emit a single stderr line without trailing
      // newline (e.g. "ERROR: Reconnecting..." / "canceled"), so we must not
      // drop this tail on process close.
      const trailingStderr = stderrJsonBuffer.trim();
      if (trailingStderr) {
        let consumedAsJson = false;
        if (jsonMode && trailingStderr.startsWith('{')) {
          try {
            const evt = JSON.parse(trailingStderr);
            if (evt && typeof evt === 'object' && typeof evt.type === 'string') {
              emitCodexEvent(evt, state, options);
              consumedAsJson = true;
            }
          } catch { /* fall through and treat as plain stderr text */ }
        }
        if (!consumedAsJson) {
          if (stderr.length < MAX_BUFFER) stderr += `${trailingStderr}\n`;
          if (/ERROR:\s*Reconnecting/i.test(trailingStderr) || /failed to record rollout items|channel closed/i.test(trailingStderr)) {
            done(new Error('codex backend reconnecting/channel closed'));
            return;
          }
        }
      }

      if (killedByIdleTimeout) {
        done(new Error(`codex idle timeout after ${timeoutMs}ms without subprocess output`));
        return;
      }

      if (code === 0) {
        const content = jsonMode
          ? state.finalParts.join('\n').trim()
          : stdout.trim();
        if (content) {
          done(null, {
            content,
            toolSummary: {
              totalCalls: state.toolCalls,
              totalDurationMs: state.toolDurationMs,
            },
          });
          return;
        }
      }
      done(new Error(stderr.trim() || `codex exited with code ${code}`));
    });

    child.on('error', (err) => done(err));
    child.stdin.on('error', () => {});
    child.stdin.write(prompt);
    child.stdin.end();
  });
}

// ═══════════════════════════════════════════════════════════════════
// ── Direct API Mode — call Mindflow Responses API with KHY tools ─
// ═══════════════════════════════════════════════════════════════════

function _normalizeAbortReason(reason) {
  if (!reason) return 'aborted';
  if (typeof reason === 'string') return reason;
  return reason.message || String(reason);
}

/**
 * HTTP client for Responses API. Supports proxy + abort signal.
 */
function makeDirectRequest(url, body, { timeout = CODEX_DIRECT_TIMEOUT_MS, signal = null } = {}) {
  return new Promise((resolve, reject) => {
    if (signal && signal.aborted) {
      const err = new Error(`codex direct request aborted: ${_normalizeAbortReason(signal.reason)}`);
      err.name = 'AbortError';
      reject(err);
      return;
    }

    let settled = false;
    let activeReq = null;
    let connectReq = null;

    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      if (signal && onAbort) {
        try { signal.removeEventListener('abort', onAbort); } catch { /* ignore */ }
      }
      fn(value);
    };
    const finishResolve = (v) => finish(resolve, v);
    const finishReject = (e) => finish(reject, e);
    const onAbort = () => {
      const err = new Error(`codex direct request aborted: ${_normalizeAbortReason(signal ? signal.reason : null)}`);
      err.name = 'AbortError';
      try { if (connectReq && !connectReq.destroyed) connectReq.destroy(err); } catch { /* ignore */ }
      try { if (activeReq && !activeReq.destroyed) activeReq.destroy(err); } catch { /* ignore */ }
      finishReject(err);
    };
    if (signal) signal.addEventListener('abort', onAbort, { once: true });

    const parsed = new URL(url);
    const mod = parsed.protocol === 'https:' ? https : http;
    const payload = JSON.stringify(body);

    // Resolve API key: env > apiKeyPool (codex or openai provider)
    let codexApiKey = extractPrimaryApiKey(process.env.CODEX_API_KEY) || '';
    if (!codexApiKey) {
      try {
        const pool = require('../../apiKeyPool');
        pool.init();
        const picked = pool.pick('codex') || pool.pick('openai');
        if (picked) codexApiKey = picked.key;
      } catch { /* pool unavailable */ }
    }

    const headers = {
      'Authorization': `Bearer ${codexApiKey}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload),
    };

    const handleResponse = (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (res.statusCode >= 400) {
            const msg = parsed.error?.message || parsed.message || `HTTP ${res.statusCode}`;
            finishReject(new Error(`Codex API error ${res.statusCode}: ${msg}`));
          } else {
            finishResolve(parsed);
          }
        } catch {
          finishReject(new Error(`Codex API: invalid JSON response (HTTP ${res.statusCode})`));
        }
      });
    };

    // Proxy support
    const proxyUrl = process.env.https_proxy || process.env.HTTPS_PROXY ||
                     process.env.http_proxy || process.env.HTTP_PROXY;

    let effectiveProxy = proxyUrl;
    try {
      const sidecar = require('../tlsSidecar');
      if (sidecar.shouldProxy(parsed.hostname)) effectiveProxy = sidecar.getProxyUrl();
    } catch { /* sidecar not available */ }

    const reqOptions = {
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: 'POST',
      headers,
      timeout,
    };

    if (effectiveProxy && parsed.protocol === 'https:') {
      try {
        const proxy = new URL(effectiveProxy);
        connectReq = http.request({
          hostname: proxy.hostname,
          port: proxy.port || 80,
          method: 'CONNECT',
          path: `${parsed.hostname}:${parsed.port || 443}`,
          timeout,
        });
        connectReq.on('connect', (res, socket) => {
          if (res.statusCode !== 200) {
            finishReject(new Error(`Proxy CONNECT failed: ${res.statusCode}`));
            return;
          }
          activeReq = https.request({ ...reqOptions, socket, agent: false }, handleResponse);
          activeReq.on('error', finishReject);
          activeReq.on('timeout', () => { activeReq.destroy(); finishReject(new Error('request timeout')); });
          activeReq.write(payload);
          activeReq.end();
        });
        connectReq.on('error', finishReject);
        connectReq.on('timeout', () => { connectReq.destroy(); finishReject(new Error('proxy timeout')); });
        connectReq.end();
        return;
      } catch { /* fall through to direct */ }
    }

    activeReq = mod.request(reqOptions, handleResponse);
    activeReq.on('error', finishReject);
    activeReq.on('timeout', () => { activeReq.destroy(); finishReject(new Error('request timeout')); });
    activeReq.write(payload);
    activeReq.end();
  });
}

/**
 * Build Responses API tool definitions from KHY's native tool registry.
 */
function buildDirectToolDefs() {
  try {
    const { getToolDefinitions } = require('../../toolCalling');
    const defs = getToolDefinitions();
    // PascalCase names only — claudeCompat handles aliases at execution time
    const ALLOWED = new Set(['Bash', 'Read', 'Write', 'Edit', 'Glob', 'Grep', 'web_search']);
    const seen = new Set();
    return defs.filter(d => {
      if (!ALLOWED.has(d.name) || seen.has(d.name)) return false;
      seen.add(d.name);
      return true;
    }).map(d => ({
      type: 'function',
      name: d.name,
      description: d.description || '',
      parameters: d.parameters || { type: 'object', properties: {} },
    }));
  } catch {
    // Fallback: minimal tool set
    return [
      { type: 'function', name: 'Bash', description: 'Execute a shell command', parameters: { type: 'object', properties: { command: { type: 'string', description: 'Shell command to execute' } }, required: ['command'] } },
      { type: 'function', name: 'Read', description: 'Read a file', parameters: { type: 'object', properties: { file_path: { type: 'string', description: 'Absolute file path' } }, required: ['file_path'] } },
      { type: 'function', name: 'Glob', description: 'Find files by glob pattern', parameters: { type: 'object', properties: { pattern: { type: 'string', description: 'Glob pattern like **/*.js' } }, required: ['pattern'] } },
      { type: 'function', name: 'Grep', description: 'Search file contents with regex', parameters: { type: 'object', properties: { pattern: { type: 'string', description: 'Regex pattern' }, path: { type: 'string', description: 'Directory to search' } }, required: ['pattern'] } },
      { type: 'function', name: 'Edit', description: 'Edit a file with string replacement', parameters: { type: 'object', properties: { file_path: { type: 'string', description: 'File path' }, old_string: { type: 'string', description: 'Text to replace' }, new_string: { type: 'string', description: 'Replacement text' } }, required: ['file_path', 'old_string', 'new_string'] } },
      { type: 'function', name: 'Write', description: 'Write/create a file', parameters: { type: 'object', properties: { file_path: { type: 'string', description: 'File path' }, content: { type: 'string', description: 'File content' } }, required: ['file_path', 'content'] } },
      { type: 'function', name: 'web_search', description: 'Search the web for current information (news, docs, prices, etc.)', parameters: { type: 'object', properties: { query: { type: 'string', description: 'Search query (max 200 chars)' } }, required: ['query'] } },
    ];
  }
}

/**
 * Parse Responses API output array into text parts and function calls.
 */
function parseDirectResponse(output) {
  const textParts = [];
  const functionCalls = [];
  for (const item of (output || [])) {
    if (!item || typeof item !== 'object') continue;
    if (item.type === 'message' && (item.role === 'assistant' || !item.role)) {
      const text = extractMessageText(item);
      if (text) textParts.push(text);
    } else if (item.type === 'function_call') {
      functionCalls.push({
        call_id: item.call_id || item.id || `fc_${Date.now()}_${functionCalls.length}`,
        name: item.name || 'unknown',
        arguments: item.arguments || '{}',
      });
    }
  }
  return { textParts, functionCalls };
}

/**
 * Build system prompt for direct mode — structured function calling.
 *
 * Design principles:
 * - Ignores options.system (the HARDCORE_SYSTEM_PROMPT designed for XML tool-call format)
 * - ~3K chars — enough context for intelligent behavior, not so much it drowns tool defs
 * - Core rules extracted from HARDCORE (khyUpgradeRuntime.js:7-231), adapted for Responses API
 * - No <tool_call> XML syntax (Direct mode uses native function calling)
 * - No [Plan]/[Summary] tags (ai.js synthesizes lifecycle events)
 */
function buildDirectSystemPrompt(_options = {}) {
  const cwd = process.cwd();
  const platform = process.platform;
  return [
    // ── 1. Role & Capabilities ──
    'You are an expert-level software engineering assistant embedded in KHY OS.',
    'You help users with: code reading/writing/debugging/refactoring, file management,',
    'shell operations, system tasks, and technical analysis.',
    '',

    // ── 2. Core Rules ──
    '# Core Rules',
    '1. ACT IMMEDIATELY. Call tools right away. NEVER ask "shall I proceed?" or "if you agree".',
    '   Do NOT describe what you would do — just do it. No filler, no preamble.',
    '2. Think before acting: understand intent → pick right tool → execute → summarize concisely.',
    '3. Same tool + same params = call only once. Never repeat identical calls.',
    '4. When unsure, say so honestly. Never fabricate file contents or code behavior.',
    '5. On error: diagnose root cause first, then try alternatives. Never retry the same failing call.',
    '6. When asked about code, files, or project structure, ALWAYS use tools first. Never guess.',
    '7. When asked to CREATE a file, you MUST call Write. When asked to MODIFY a file, you MUST call Edit.',
    '8. Keep answers SHORT: 3-5 sentences for simple questions, 8-10 max for complex ones.',
    '9. Respond in the SAME LANGUAGE as the user\'s message. Code/comments stay in English.',
    '',

    // ── 3. Tool Selection ──
    '# Tool Selection (mandatory)',
    '- Find files by name/pattern → Glob (NOT Bash with find/ls)',
    '- Search text inside files → Grep (NOT Bash with grep/rg, NOT Glob-then-Read)',
    '- Read a file → Read (NOT Bash with cat/head/tail)',
    '- Edit a file (exact string replacement) → Edit (NOT Bash with sed/awk)',
    '- Create/overwrite a file → Write (NOT Bash with echo/cat)',
    '- Shell commands (git, npm, build, test, etc.) → Bash',
    '',
    'NEVER use Bash for operations that have a dedicated tool.',
    'If Glob/Grep returns 0 results, try a broader pattern before giving up.',
    'For large files (>300 lines), use Read with offset+limit to read specific sections,',
    'or use Grep to locate the target first. Do NOT read the entire large file.',
    'To find a function definition, use Grep with output_mode "content" — NOT Glob (Glob searches names, not content).',
    '',

    // ── 4. Edit Tool — Critical Rules ──
    '# Edit Tool Rules',
    '- ALWAYS Read the file first before calling Edit. You need exact content.',
    '- old_string must be copied VERBATIM from the Read result — exact whitespace, indentation, line breaks.',
    '- Do NOT include line numbers in old_string (Read shows "N\\t<content>", use only <content>).',
    '- Include enough surrounding context in old_string to make it unique in the file.',
    '- If you need to replace all occurrences, use replace_all: true.',
    '',

    // ── 5. Error Recovery ──
    '# Error Recovery',
    '- File not found → use Glob to search for the correct path, then retry.',
    '- Edit old_string not found → Re-Read the file, copy the exact text, retry.',
    '- Permission denied → inform the user.',
    '- Command failed → read the error, diagnose, try alternative approach.',
    '- NEVER retry the exact same failing call. Always change something.',
    '',

    // ── 6. Code Quality & Safety ──
    '# Code Quality',
    '- Read files before modifying. Never modify code you haven\'t read.',
    '- Prefer editing existing files over creating new ones.',
    '- Before creating a file with Write, check if it already exists using Glob.',
    '- Don\'t add features beyond what was asked. Don\'t over-engineer.',
    '- Be careful with security: no XSS, SQL injection, or command injection.',
    '- For destructive/irreversible actions, confirm with the user first.',
    '',

    // ── 7. Multi-Step Tasks ──
    '# Multi-Step Tasks',
    '- For complex tasks, plan your steps: locate → read → analyze → act → verify.',
    '- For cross-file tasks, use Grep to batch-locate all targets first, then process each.',
    '- Don\'t waste iterations reading files one by one — use Grep for bulk discovery.',
    '',

    // ── 8. Environment ──
    `Working directory: ${cwd}`,
    `Platform: ${platform}`,
  ].join('\n');
}

/**
 * Core agentic loop for direct API mode.
 * Calls Mindflow Responses API, executes tools via KHY's toolCalling, feeds results back.
 */
async function runCodexDirect(prompt, options = {}) {
  const config = readCodexConfig() || {};
  const baseUrl = config.providerBaseUrl || 'https://ai.mindflow.com.cn/v1';
  // Validate options.model against known provider models before using it.
  // Gateway's _modelSwitch may inject a model from another adapter (e.g., 'qwen3.5:4b')
  // that the Codex provider doesn't support.
  let model = config.model || 'gpt-5.3-codex-review';
  if (options.model && isUserModelAllowed(options.model, config)) model = options.model;
  const onChunk = typeof options.onChunk === 'function' ? options.onChunk : null;
  const emit = (chunk) => { if (onChunk) { try { onChunk(chunk); } catch { /* best effort */ } } };

  const toolDefs = buildDirectToolDefs();
  const systemPrompt = buildDirectSystemPrompt(options);

  // Build initial input — include images in OpenAI vision format if provided
  const userContent = [{ type: 'input_text', text: prompt }];
  const codexImages = toCodexInputImages(options.images || []);
  if (codexImages.length > 0) {
    for (const imageItem of codexImages) userContent.push(imageItem);
  }
  const input = [
    { type: 'message', role: 'user', content: userContent },
  ];

  const state = {
    finalParts: [],
    toolCalls: 0,
    toolDurationMs: 0,
  };

  // Dedup: prevent repeated identical tool calls
  const seenCalls = new Set();

  if (process.env.CODEX_DIRECT_DEBUG === '1') {
    emit({ type: 'status', text: `[debug] tools: ${toolDefs.length}, model: ${model}, endpoint: ${baseUrl}` });
    emit({ type: 'status', text: `[debug] tool names: ${toolDefs.map(t => t.name).join(', ')}` });
    emit({ type: 'status', text: `[debug] system prompt length: ${systemPrompt.length} chars` });
  }
  emit({ type: 'status', text: 'Codex Direct 启动中...' });

  for (let iteration = 0; iteration < CODEX_DIRECT_MAX_ITERATIONS; iteration++) {
    emit({ type: 'status', text: `Codex Direct: round ${iteration + 1}` });

    // Force tool invocation on the first round to prevent the model from
    // replying with plain text instructions instead of actually executing tools.
    // Subsequent rounds use "auto" so the model can produce a final text answer
    // once the necessary tool calls are complete.
    const toolChoice = iteration === 0 ? 'required' : 'auto';

    const requestBody = {
      model,
      instructions: systemPrompt,
      input,
      tools: toolDefs,
      tool_choice: toolChoice,
      max_output_tokens: options.maxTokens || 4096,
      temperature: options.temperature ?? 0.7,
      stream: false,
    };

    // Emit periodic heartbeats during API call to prevent gateway idle timeout
    const reqStart = Date.now();
    const heartbeatInterval = setInterval(() => {
      const elapsed = ((Date.now() - reqStart) / 1000).toFixed(0);
      emit({ type: 'status', text: `Codex Direct: waiting for model response... ${elapsed}s` });
    }, 5000);

    if (process.env.CODEX_DIRECT_DEBUG === '1') {
      const payloadSize = JSON.stringify(requestBody).length;
      emit({ type: 'status', text: `[debug] POST ${baseUrl}/responses, payload: ${payloadSize} bytes, tools: ${toolDefs.length}` });
    }

    let response;
    try {
      response = await makeDirectRequest(
        `${baseUrl}/responses`,
        requestBody,
        { timeout: CODEX_DIRECT_TIMEOUT_MS, signal: options.abortSignal || null },
      );
      if (process.env.CODEX_DIRECT_DEBUG === '1') {
        emit({ type: 'status', text: `[debug] response received in ${((Date.now() - reqStart) / 1000).toFixed(1)}s` });
      }
    } catch (err) {
      emit({ type: 'status', text: `API error (${((Date.now() - reqStart) / 1000).toFixed(1)}s): ${compactText(err.message, 100)}` });
      throw err;
    } finally {
      clearInterval(heartbeatInterval);
    }

    // Debug: log raw response structure for diagnostics
    if (process.env.CODEX_DIRECT_DEBUG === '1') {
      const debugKeys = Object.keys(response || {}).join(', ');
      const outputLen = Array.isArray(response.output) ? response.output.length : 'N/A';
      const textField = typeof response.text === 'string' ? response.text.slice(0, 200) : (response.text ? JSON.stringify(response.text).slice(0, 200) : 'N/A');
      emit({ type: 'status', text: `[debug] keys: ${debugKeys}, output: ${outputLen}, status: ${response.status || 'none'}` });
      emit({ type: 'status', text: `[debug] text field: ${textField}` });
      const toolCount = Array.isArray(response.tools) ? response.tools.length : 'N/A';
      const toolChoice = JSON.stringify(response.tool_choice || 'N/A').slice(0, 100);
      emit({ type: 'status', text: `[debug] tools: ${toolCount}, tool_choice: ${toolChoice}, model: ${response.model || 'N/A'}` });
      if (response.usage) emit({ type: 'status', text: `[debug] usage: in=${response.usage.input_tokens} out=${response.usage.output_tokens}` });
      if (Array.isArray(response.output)) {
        for (const item of response.output.slice(0, 5)) {
          emit({ type: 'status', text: `[debug] item: type=${item.type}, role=${item.role || '-'}, keys=${Object.keys(item).join(',')}` });
        }
      }
    }

    // Note: response.text is a config object (format/verbosity), NOT response content.
    // Content comes from response.output items.

    const { textParts, functionCalls } = parseDirectResponse(response.output);

    // Accumulate text
    for (const text of textParts) {
      state.finalParts.push(text);
      emit({ type: 'text', text });
    }

    // Done if no tool calls requested
    // Note: some Responses API providers return status=completed even with function_calls,
    // so we rely on functionCalls.length, not status alone.
    if (functionCalls.length === 0) {
      emit({ type: 'status', text: 'Codex Direct 完成' });
      break;
    }

    // Execute tool calls — auto-approve since the user already approved the AI request.
    // Without this, interactive permission prompts hang in non-interactive/piped mode.
    let toolCalling, claudeCompat;
    try {
      toolCalling = require('../../toolCalling');
      claudeCompat = require('../../claudeCompat');
    } catch (err) {
      emit({ type: 'status', text: 'Tool system unavailable' });
      break;
    }

    // Temporarily enable dangerous mode to auto-approve tool calls in the loop.
    const wasDangerous = toolCalling.isDangerousMode();
    if (!wasDangerous) toolCalling.enableDangerousMode();

    for (const fc of functionCalls) {
      // Dedup check
      const dedupKey = `${fc.name}:${fc.arguments}`;
      if (seenCalls.has(dedupKey)) {
        // Append skip result and continue
        input.push({ type: 'function_call', call_id: fc.call_id, name: fc.name, arguments: fc.arguments });
        input.push({ type: 'function_call_output', call_id: fc.call_id, output: JSON.stringify({ error: 'Duplicate call skipped' }) });
        continue;
      }
      seenCalls.add(dedupKey);

      state.toolCalls++;

      // Parse arguments
      let parsedArgs = {};
      try { parsedArgs = typeof fc.arguments === 'string' ? JSON.parse(fc.arguments) : (fc.arguments || {}); } catch {
        const { safeJsonParse } = require('../safeJsonParse');
        parsedArgs = typeof fc.arguments === 'string' ? safeJsonParse(fc.arguments, {}) : (fc.arguments || {});
      }

      // Normalize tool name/params via claudeCompat
      const normalized = claudeCompat.normalizeToolCall(fc.name, parsedArgs);

      emit({
        type: 'tool_use',
        tool: fc.name,
        input: compactText(JSON.stringify(parsedArgs), 120),
        id: fc.call_id,
      });

      const start = Date.now();
      let result;
      try {
        result = await toolCalling.executeTool(normalized.name, normalized.params);
      } catch (err) {
        result = { success: false, error: err.message || 'tool execution failed' };
      }
      const elapsed = Date.now() - start;
      state.toolDurationMs += elapsed;

      // Build output string for the model
      let outputStr;
      if (result && result.success) {
        const content = result.output || result.content || result.result || result.text || 'success';
        outputStr = typeof content === 'string' ? content : JSON.stringify(content);
        // Cap large outputs to prevent context overflow
        if (outputStr.length > 8000) outputStr = outputStr.slice(0, 8000) + '\n...(truncated)';
      } else {
        outputStr = JSON.stringify({ error: (result && result.error) || 'tool execution failed' });
      }

      emit({
        type: 'tool_result',
        id: fc.call_id,
        content: compactText(outputStr, 180),
      });

      // Append function_call + result to input for next API turn
      input.push({ type: 'function_call', call_id: fc.call_id, name: fc.name, arguments: typeof fc.arguments === 'string' ? fc.arguments : JSON.stringify(fc.arguments) });
      input.push({ type: 'function_call_output', call_id: fc.call_id, output: outputStr });
    }

    // Restore previous permission mode
    if (!wasDangerous) toolCalling.disableDangerousMode();
  }

  const content = state.finalParts.join('\n').trim();
  return {
    content: content || 'Codex Direct: no response generated',
    toolSummary: {
      totalCalls: state.toolCalls,
      totalDurationMs: state.toolDurationMs,
    },
  };
}

/**
 * Direct mode generate wrapper — same return shape as CLI mode.
 */
async function generateDirect(prompt, options = {}) {
  if (!detect()) {
    return {
      success: false,
      content: '',
      provider: 'Codex (direct)',
      adapter: 'codex',
      error: _lastDetectError || 'CODEX_API_KEY not configured',
      errorType: 'auth',
      attempts: [{ provider: 'Codex (direct)', success: false, error: 'CODEX_API_KEY not set' }],
    };
  }

  const config = readCodexConfig() || {};
  // Same model validation as runCodexDirect — don't blindly use gateway-injected model
  let usedModel = config.model || 'gpt-5.3-codex-review';
  if (options.model && isUserModelAllowed(options.model, config)) usedModel = options.model;

  try {
    if (options.onChunk) {
      try { options.onChunk({ type: 'status', text: `Codex Direct (${usedModel})` }); } catch { /* best effort */ }
    }

    const result = await runCodexDirect(prompt, options);
    return {
      success: true,
      content: result.content,
      provider: `Codex Direct (${usedModel})`,
      model: usedModel,
      adapter: 'codex',
      toolSummary: result.toolSummary,
      attempts: [{ provider: 'Codex (direct)', success: true }],
    };
  } catch (err) {
    const lower = String(err.message || '').toLowerCase();
    let errorType = 'unknown';
    if (/abort/i.test(lower)) errorType = 'abort';
    else if (/timeout/i.test(lower)) errorType = 'timeout';
    else if (/unauthorized|api.?key|401/i.test(lower)) errorType = 'auth';
    else if (/rate.?limit|429/i.test(lower)) errorType = 'rate_limit';
    else if (/network|econnrefused|enotfound|socket/i.test(lower)) errorType = 'network';

    return {
      success: false,
      content: '',
      provider: 'Codex (direct)',
      adapter: 'codex',
      error: err.message,
      errorType,
      attempts: [{ provider: 'Codex (direct)', success: false, error: err.message }],
    };
  }
}

// ═══════════════════════════════════════════════════════════════════
// ── App-launch intent interception ──────────────────────────────
// ═══════════════════════════════════════════════════════════════════

// Detect simple "open <app>" prompts and execute via KHY's unified tool chain
// instead of delegating to Codex CLI (which cannot set DISPLAY or use .desktop files).
const _OPEN_APP_RE = /^(?:打开|启动|运行|open|launch|start|run)\s*(.+)$/i;

async function _tryAppLaunchIntent(prompt, options) {
  const text = String(prompt || '').trim();
  const m = _OPEN_APP_RE.exec(text);
  if (!m) return null;

  const appQuery = m[1].trim();
  if (!appQuery || appQuery.length > 30) return null; // Too long to be an app name

  // Check against APP_ALIAS_MAP to verify this is actually an app
  let toolCalling;
  try { toolCalling = require('../../services/toolCalling'); } catch { return null; }
  const candidates = toolCalling._buildAppCandidates(appQuery);
  if (!candidates || candidates.length === 0) return null;

  // At least one candidate must match a known alias
  const aliasMap = toolCalling.APP_ALIAS_MAP;
  const hasKnownApp = candidates.some(c =>
    aliasMap[c] || Object.values(aliasMap).includes(c)
  );
  if (!hasKnownApp) return null;

  // Execute via KHY's open_app tool
  const { onChunk } = options;
  if (onChunk) {
    onChunk({ type: 'tool_use', tool: 'open_app', input: appQuery, id: 'app_launch_0' });
  }

  try {
    const result = await toolCalling.executeTool('open_app', { name: appQuery });
    const ok = result && result.success;
    const output = ok
      ? (result.output || `已启动 ${appQuery}`)
      : (result.error || `无法启动 ${appQuery}`);

    if (onChunk) {
      onChunk({ type: 'tool_result', id: 'app_launch_0', content: output });
    }

    return {
      success: ok,
      content: output,
      provider: 'KHY open_app',
      adapter: 'codex',
      model: 'native',
      attempts: [{ provider: 'KHY open_app', success: ok }],
    };
  } catch (err) {
    const errMsg = `启动失败: ${err.message}`;
    if (onChunk) {
      onChunk({ type: 'tool_result', id: 'app_launch_0', content: errMsg });
    }
    return null; // Fall through to normal Codex flow
  }
}

// ═══════════════════════════════════════════════════════════════════
// ── CLI Mode (existing) ──────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════

async function generate(prompt, options = {}) {
  // ── App-launch intent interception ─────────────────────────────
  // Codex CLI manages its own tool loop and cannot call KHY's open_app.
  // Intercept "open <app>" intents and execute via KHY's unified tool chain
  // so DISPLAY is set and .desktop files are resolved correctly.
  const _appLaunchResult = await _tryAppLaunchIntent(prompt, options);
  if (_appLaunchResult) return _appLaunchResult;

  // Branch: direct API mode bypasses CLI entirely
  // Also force direct mode when images are present — CLI stdin is text-only
  if (CODEX_MODE === 'direct' || (Array.isArray(options.images) && options.images.length > 0)) {
    return generateDirect(prompt, options);
  }

  if (!detect()) {
    return { success: false, content: '', provider: 'Codex', adapter: 'codex', attempts: [] };
  }
  if (!probeExecUsable()) {
    return {
      success: false,
      content: '',
      provider: 'Codex',
      adapter: 'codex',
      error: _lastExecProbeError || 'codex exec unavailable',
      errorType: 'unknown',
      attempts: [{ provider: 'Codex', success: false, error: _lastExecProbeError || 'codex exec unavailable' }],
    };
  }

  const args = ['exec', '--color', 'never', '--skip-git-repo-check'];
  if (process.env.GATEWAY_CODEX_JSON !== 'false') {
    args.push('--json');
  }
  const sandboxMode = String(process.env.GATEWAY_CODEX_SANDBOX || 'workspace-write').trim();
  if (sandboxMode && sandboxMode !== 'none') {
    args.push('--sandbox', sandboxMode);
  }

  const codexConfig = readCodexConfig() || {};

  // Only pass --model if it's known to be available on the configured provider.
  // Passing an unsupported model causes codex to enter a reconnect loop.
  let usedModel = null;
  if (options.model) {
    if (isUserModelAllowed(options.model, codexConfig)) {
      args.push('--model', options.model);
      usedModel = options.model;
    } else {
      usedModel = codexConfig.model || null;
    }
  }

  let providerModel = usedModel || 'default';
  try {
    let execResult;

    try {
      execResult = await runCodexExec(prompt, args, {
        ...options,
        model: providerModel,
      });
    } catch (firstErr) {
      const msg = String(firstErr?.message || '').toLowerCase();
      const retryArgs = args.slice();
      let shouldRetry = false;

      // Old codex versions may not support --json.
      if (retryArgs.includes('--json') && /(unknown|unrecognized|unexpected).*(--json|json)/i.test(msg)) {
        const ji = retryArgs.indexOf('--json');
        if (ji >= 0) {
          retryArgs.splice(ji, 1);
          shouldRetry = true;
        }
      }

      // Model mismatch can trigger backend reconnect; retry once without --model.
      if (usedModel && /(unknown model|invalid model|model .*not found|unsupported model|model_not_found)/i.test(msg)) {
        const mi = retryArgs.indexOf('--model');
        if (mi >= 0) {
          retryArgs.splice(mi, 2);
          providerModel = 'default';
          shouldRetry = true;
        }
      }

      // Some codex builds fail under strict sandbox; retry without explicit sandbox flag.
      if (!shouldRetry && /(reconnecting|channel closed|failed to record rollout items|sandbox)/i.test(msg)) {
        const si = retryArgs.indexOf('--sandbox');
        if (si >= 0) {
          retryArgs.splice(si, 2);
          shouldRetry = true;
        }
      }

      if (!shouldRetry) throw firstErr;
      if (options.onChunk) {
        try {
          options.onChunk({ type: 'status', text: 'Codex 重试中（自动降级参数）...' });
        } catch { /* best effort */ }
      }
      execResult = await runCodexExec(prompt, retryArgs, {
        ...options,
        model: providerModel,
      });
    }

    return {
      success: true,
      content: execResult.content,
      provider: `Codex (${providerModel})`,
      adapter: 'codex',
      toolSummary: execResult.toolSummary || { totalCalls: 0, totalDurationMs: 0 },
      attempts: [{ provider: 'Codex', success: true }],
    };
  } catch (err) {
    const rawMessage = String(err && err.message ? err.message : err || 'codex failed');
    let classifyMessage = rawMessage;
    let finalErrorMessage = rawMessage;

    // Custom provider transport failure fallback:
    // when config points to a non-OpenAI provider and transport is unhealthy,
    // retry once with OpenAI provider override.
    if (shouldTryOpenAIFallback(rawMessage, codexConfig, options)) {
      safeEmitStatus(options, 'Codex 检测到自定义 provider 异常，尝试回退 OpenAI provider...');
      const fallbackArgs = buildOpenAIFallbackArgs(args);
      try {
        const fallbackResult = await runCodexExec(prompt, fallbackArgs, {
          ...options,
          model: 'default',
        });
        safeEmitStatus(options, 'Codex provider 回退成功（OpenAI）');
        recordRuntimeDiagnostics({
          healed: true,
          diagnosis: 'provider_fallback=openai',
          lastError: rawMessage,
          trigger: 'provider_fallback_recovered',
        });
        return {
          success: true,
          content: fallbackResult.content,
          provider: 'Codex (openai-fallback)',
          adapter: 'codex',
          toolSummary: fallbackResult.toolSummary || { totalCalls: 0, totalDurationMs: 0 },
          attempts: [
            { provider: 'Codex', success: false, error: rawMessage },
            { provider: 'Codex (openai-fallback)', success: true },
          ],
        };
      } catch (fallbackErr) {
        const fallbackMsg = String(fallbackErr && fallbackErr.message ? fallbackErr.message : fallbackErr || 'openai fallback failed');
        safeEmitStatus(options, `Codex provider 回退失败: ${compactText(fallbackMsg, 120)}`);
        classifyMessage = fallbackMsg;
        finalErrorMessage = `${rawMessage} | openai_fallback=${compactText(fallbackMsg, 240)}`;
      }
    }

    if (isReconnectChannelClosed(classifyMessage || rawMessage)) {
      safeEmitStatus(options, 'Codex 通道异常，执行快速自检...');
      const healed = maybeSelfHealReconnect(options);
      // If self-heal changed sandbox mode, run one immediate retry without explicit
      // sandbox flag before returning a hard failure.
      if (healed) {
        const healedRetryArgs = args.slice();
        const sandboxIdx = healedRetryArgs.indexOf('--sandbox');
        if (sandboxIdx >= 0) {
          healedRetryArgs.splice(sandboxIdx, 2);
        }
        safeEmitStatus(options, 'Codex 自愈后重试中...');
        try {
          const healedResult = await runCodexExec(prompt, healedRetryArgs, {
            ...options,
            model: providerModel,
          });
          safeEmitStatus(options, 'Codex 自愈后重试成功');
          recordRuntimeDiagnostics({
            healed: true,
            diagnosis: 'recovered_after_retry',
            lastError: rawMessage,
            trigger: 'reconnect_recovered',
          });
          return {
            success: true,
            content: healedResult.content,
            provider: `Codex (${providerModel})`,
            adapter: 'codex',
            toolSummary: healedResult.toolSummary || { totalCalls: 0, totalDurationMs: 0 },
            attempts: [{ provider: 'Codex', success: true }],
          };
        } catch (retryErr) {
          classifyMessage = String(retryErr && retryErr.message ? retryErr.message : retryErr || rawMessage);
        }
      }

      const diagnosis = diagnoseReconnectFailure(classifyMessage || rawMessage);
      recordRuntimeDiagnostics({
        healed,
        diagnosis,
        lastError: classifyMessage || rawMessage,
        trigger: 'reconnect',
      });
      if (diagnosis) {
        safeEmitStatus(options, `Codex 自检: ${diagnosis}`);
      }
      const extras = [];
      if (healed) extras.push('self_heal=mode_none');
      if (diagnosis) extras.push(`diagnosis=${diagnosis}`);
      if (extras.length > 0) {
        finalErrorMessage = `${classifyMessage || rawMessage} | ${extras.join(' | ')}`;
      }
    }

    const lower = String(classifyMessage || rawMessage).toLowerCase();
    let errorType = 'unknown';
    if (isAbortLikeError(err)) errorType = 'cancelled';
    else if (/\bcancelled\b|\bcanceled\b/.test(lower)) errorType = 'process';
    else if (lower.includes('timeout')) errorType = 'timeout';
    else if (lower.includes('eacces') || lower.includes('eperm')) errorType = 'permission';
    else if (lower.includes('enoent') || lower.includes('not found')) errorType = 'unavailable';
    else if (lower.includes('unauthorized') || lower.includes('api key') || lower.includes('login')) errorType = 'auth';
    else if (lower.includes('rate') && lower.includes('limit')) errorType = 'rate_limit';
    else if (/reconnecting|channel closed|failed to record rollout items|spawn|exited with code/.test(lower)) errorType = 'process';

    return {
      success: false,
      content: '',
      provider: 'Codex',
      adapter: 'codex',
      error: finalErrorMessage,
      errorType,
      attempts: [{ provider: 'Codex', success: false, error: finalErrorMessage }],
    };
  }
}

function getStatus() {
  detect();
  const config = readCodexConfig() || {};
  const upstreamMeta = resolveUpstreamProviderMeta(config);
  const isOpenAiLike = !upstreamMeta.provider
    || String(upstreamMeta.provider).toLowerCase() === 'openai'
    || String(upstreamMeta.provider).toLowerCase() === 'oss';
  const codexName = isOpenAiLike ? 'OpenAI Codex' : `Codex CLI (${upstreamMeta.provider})`;
  if (CODEX_MODE === 'direct') {
    return {
      name: 'Codex Direct API',
      type: 'codex',
      available: _available,
      detail: _available
        ? `Direct API 可用 (${compactText(config.providerBaseUrl || 'mindflow', 60)})`
        : `CODEX_API_KEY 未配置${_lastDetectError ? ` (${_lastDetectError})` : ''}`,
    };
  }
  const transportLabel = CODEX_MODE === 'direct' ? '直连' : '桥接';
  return {
    name: codexName,
    type: 'codex',
    available: _available,
    detail: _available
      ? `codex CLI ${transportLabel}可用${upstreamMeta.host ? ` · 上游 ${upstreamMeta.host}` : ''}`
      : `未检测到 codex 命令${_lastDetectError ? ` (${_lastDetectError})` : ''}`,
  };
}

function destroy() {
  _available = null;
  _execProbeOk = null;
  _lastDetectError = '';
  _lastExecProbeError = '';
  _configCache = null;
  _providerModels = null;
  _runtimeDiagnostics = {
    at: 0,
    healed: false,
    diagnosis: '',
    lastError: '',
    trigger: '',
  };
}

module.exports = { detect, listModels, generate, getStatus, getRuntimeDiagnostics, destroy };
