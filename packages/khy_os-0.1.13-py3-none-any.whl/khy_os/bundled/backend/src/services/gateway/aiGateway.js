/**
 * AI Gateway — central service that routes AI requests through
 * a priority-ordered cascade of adapters:
 *   1. CLI tools (Claude Code, Codex, Aider)
 *   2. Cloud API providers (MultiFreeService)
 *   3. Web relay (manual browser-based relay, always available)
 *
 * Singleton export — matches project convention.
 */
const { spawn } = require('child_process');
const { createKeyedRateLimiter } = require('../rateLimiter');
const { retryWithBackoff, isRetryableError, parseRetryAfter } = require('../retryWithBackoff');
const { diagnostics, generateTraceId: genDiagTraceId } = require('../diagnosticEvents');
const { usageTracker } = require('../usageTracker');
const { evaluateGuard, formatWarning: formatGuardWarning } = require('../contextWindowGuard');
let _traceAudit = null;
try {
  _traceAudit = require('../traceAuditService');
  _traceAudit.ensureDiagnosticsBridge();
} catch {
  _traceAudit = null;
}
const keySelector = require('./keySelector');
const localLLMAdapter = require('./adapters/localLLMAdapter');
let localLLMService = null;
try {
  localLLMService = require('../localLLMService');
} catch {
  localLLMService = null;
}
const cliToolAdapter = require('./adapters/cliToolAdapter');
const kiroAdapter = require('./adapters/kiroAdapter');
const cursorAdapter = require('./adapters/cursorAdapter');
const traeAdapter = require('./adapters/traeAdapter');
const claudeAdapter = require('./adapters/claudeAdapter');
const codexAdapter = require('./adapters/codexAdapter');
const windsurfAdapter = require('./adapters/windsurfAdapter');
const vscodeAdapter = require('./adapters/vscodeAdapter');
const warpAdapter = require('./adapters/warpAdapter');
const ollamaAdapter = require('./adapters/ollamaAdapter');
const cursor2apiAdapter = require('./adapters/cursor2apiAdapter');
const relayApiAdapter = require('./adapters/relayApiAdapter');
const apiAdapter = require('./adapters/apiAdapter');
const webRelayAdapter = require('./adapters/webRelayAdapter');
const clipboardRelayAdapter = require('./adapters/clipboardRelayAdapter');
const { createSequentialQueue } = require('../sequentialQueue');
const { RedisHealthStore } = require('./redisHealthStore');
const { createRedisRateLimiter } = require('./redisRateLimiter');
const { createRequestDedup } = require('./requestDedup');
const { ChannelHealthBroadcaster } = require('./channelHealthBroadcaster');

// ── Live model switching ────────────
let _modelSwitch;
try {
  const { getInstance: getModelSwitch } = require('../liveModelSwitch');
  _modelSwitch = getModelSwitch();
} catch { _modelSwitch = null; }

// ── Advanced diagnostics ────────────
let _advDiag;
try {
  const { getInstance: getAdvDiag } = require('../advancedDiagnostics');
  _advDiag = getAdvDiag();
} catch { _advDiag = null; }

// ── Error classification (enhanced with errorClassifier) ────────────
const { detectErrorKindDeep, formatErrorMessage: fmtError, isRetryable: _ecIsRetryable } = require('../errorClassifier');

function classifyError(status, message = '') {
  const rawMessage = String(message || '');
  const lower = rawMessage.toLowerCase();
  if (/adapter\s+\S+\s+idle timeout|stream idle timeout|\bidle timeout\b/.test(lower)) return 'timeout';

  // Distinguish explicit user/abort-controller cancellation from generic "canceled":
  // many upstream CLIs use plain "canceled" for process/channel interruption.
  // We only classify as "cancelled" when message clearly indicates an abort signal.
  if (/aborterror|abort_err|\baborted\b|\brequest aborted\b|\babort(ed)? by\b|signal aborted|user[-\s]?cancel/.test(lower)) {
    return 'cancelled';
  }
  if (/\bcancelled\b|\bcanceled\b/.test(lower)) return 'process';
  if (/reconnecting|channel closed|failed to record rollout items|adapter\s+\S+\s+queue timeout|queue task timeout/.test(lower)) return 'process';
  if (/\b(?:econnreset|econnrefused|enotfound|ehostunreach|enetunreach|eai_again)\b|fetch failed|socket hang up|getaddrinfo|network error/.test(lower)) {
    return 'network';
  }

  // Unified structured detection (errorClassifier now covers all 13 kinds)
  if (status || rawMessage) {
    const errObj = { code: status, message: rawMessage };
    const kind = detectErrorKindDeep(errObj);
    if (kind) return kind;
  }

  // Minimal residual fallback for patterns errorClassifier may miss
  if (/did not respond within|stream stalled|unresponsive/.test(lower)) return 'timeout';
  if (/adapter .* unavailable|not installed|command .* not found/.test(lower)) return 'unavailable';

  // Status-code fallback (for bare numeric status without message)
  if (status === 400) return 'bad_request';
  if (status === 408 || status === 504) return 'timeout';

  return 'unknown';
}

function _sanitizeFailureMessage(message, maxLen = 220) {
  const text = String(fmtError(message || '') || message || '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!text) return 'unknown error';
  return text.length > maxLen ? `${text.slice(0, maxLen - 1)}…` : text;
}

function _normalizeAdapterSig(raw) {
  const s = String(raw || '').trim().toLowerCase();
  if (!s) return 'adapter';
  if (s === 'localllm' || s === 'local llm' || s.includes('local (') || s.includes('本地模型')) return 'localllm';
  if (s === 'codex' || s.includes('openai codex')) return 'codex';
  if (s === 'claude' || s.includes('anthropic')) return 'claude';
  if (s === 'ollama' || s.includes('ollama')) return 'ollama';
  if (s === 'api' || s.includes('multifree')) return 'api';
  if (s === 'relay' || s.includes('relay')) return 'relay';
  return s;
}

function _buildFailureReasonSection(attempts = [], maxLines = 8) {
  if (!Array.isArray(attempts) || attempts.length === 0) return '';
  const failed = attempts.filter(a => a && a.success === false);
  if (failed.length === 0) return '';

  const lines = [];
  const seen = new Set();
  let uniqueFailedCount = 0;
  for (const attempt of failed) {
    const adapter = String(attempt.adapterKey || attempt.provider || 'adapter').trim() || 'adapter';
    const adapterSig = _normalizeAdapterSig(attempt.adapterKey || attempt.provider || 'adapter');
    const statusCode = attempt.statusCode || attempt.status || attempt.code;
    const statusNum = Number(statusCode);
    const status = Number.isFinite(statusNum) && statusNum > 0 ? ` (${statusNum})` : '';
    const errType = String(attempt.errorType || classifyError(statusCode, attempt.error || '') || '').trim();
    const errTypeSig = errType.toLowerCase();
    const kind = errType ? ` [${errType}]` : '';
    const err = _sanitizeFailureMessage(attempt.error || attempt.message || 'unknown error');
    const sig = `${adapterSig}|${Number.isFinite(statusNum) ? statusNum : 0}|${errTypeSig}|${err}`;
    if (seen.has(sig)) continue;
    seen.add(sig);
    uniqueFailedCount += 1;
    if (lines.length < Math.max(1, maxLines)) {
      lines.push(`- ${adapter}${status}${kind}: ${err}`);
    }
  }

  if (lines.length === 0) return '';
  if (uniqueFailedCount > lines.length) {
    lines.push(`- ... 还有 ${uniqueFailedCount - lines.length} 条失败记录`);
  }
  return `真实失败原因:\n${lines.join('\n')}`;
}

function _prependFailureReason(baseContent, attempts, maxLines = 8) {
  const reason = _buildFailureReasonSection(attempts, maxLines);
  const body = String(baseContent || '').trim();
  if (!reason) return body;
  if (/真实失败原因/.test(body)) return body;
  return body ? `${reason}\n\n${body}` : reason;
}

function _shouldUseFastFail(errorType = '') {
  const t = String(errorType || '').toLowerCase();
  return t === 'auth' || t === 'permission' || t === 'unavailable' || t === 'process';
}

function _parseMs(raw, fallback, min = 0) {
  const parsed = parseInt(String(raw ?? fallback), 10);
  if (!Number.isFinite(parsed) || parsed <= 0) return fallback;
  return Math.max(min, parsed);
}

function _parsePositiveInt(raw, fallback, min = 1, max = 16) {
  const parsed = parseInt(String(raw ?? fallback), 10);
  if (!Number.isFinite(parsed) || parsed < min) return fallback;
  return Math.min(max, parsed);
}

function _isRetryableResultErrorType(errorType = '') {
  return _ecIsRetryable(String(errorType || '').trim().toLowerCase());
}

const PROCESS_SENSITIVE_ADAPTER_KEYS = new Set([
  'cli',
  'codex',
  'claude',
  'kiro',
  'cursor',
  'trae',
  'windsurf',
  'vscode',
  'warp',
  'cursor2api',
]);

const DEFAULT_PROCESS_FAILOVER_CANDIDATES = ['relay_api', 'api', 'relay', 'ollama'];
const DEFAULT_API_POOL_PROVIDER_ALIASES = Object.freeze({
  openai: 'openai',
  gpt: 'openai',
  anthropic: 'anthropic',
  claude: 'anthropic',
  trae: 'trae',
  deepseek: 'deepseek',
  qwen: 'qwen',
  alibaba: 'qwen',
  dashscope: 'qwen',
  glm: 'glm',
  zhipu: 'glm',
  doubao: 'doubao',
  wenxin: 'wenxin',
  baidu: 'wenxin',
  relay: 'relay',
});
const DEFAULT_API_POOL_TO_SERVICE_PROVIDER = Object.freeze({
  openai: 'openai',
  anthropic: 'anthropic',
  trae: 'trae',
  deepseek: 'openai',
  qwen: 'alibaba',
  glm: 'zhipu',
  doubao: 'openai',
  wenxin: 'baidu',
  relay: 'openai',
});
const DEFAULT_API_POOL_DEFAULT_MODEL_MAP = Object.freeze({
  deepseek: 'deepseek-chat',
  doubao: 'doubao-pro-32k',
  qwen: 'qwen-plus',
  glm: 'glm-4-plus',
  wenxin: 'ERNIE-Bot',
  anthropic: 'claude-sonnet-4-6',
  openai: 'gpt-4o-mini',
  trae: 'gpt-4o',
  relay: 'gpt-4o-mini',
});

function _parseJsonMap(raw) {
  const text = String(raw || '').trim();
  if (!text) return {};
  try {
    const parsed = JSON.parse(text);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed;
    }
  } catch {
    return {};
  }
  return {};
}

function _getApiPoolAliasMap() {
  const extra = _parseJsonMap(process.env.GATEWAY_API_POOL_PROVIDER_ALIAS_MAP || '');
  const merged = { ...DEFAULT_API_POOL_PROVIDER_ALIASES };
  for (const [k, v] of Object.entries(extra)) {
    const key = String(k || '').trim().toLowerCase();
    const value = String(v || '').trim().toLowerCase();
    if (!key || !value) continue;
    merged[key] = value;
  }
  return merged;
}

function _getApiPoolToServiceMap() {
  const extra = _parseJsonMap(process.env.GATEWAY_API_POOL_SERVICE_MAP || '');
  const merged = { ...DEFAULT_API_POOL_TO_SERVICE_PROVIDER };
  for (const [k, v] of Object.entries(extra)) {
    const key = String(k || '').trim().toLowerCase();
    const value = String(v || '').trim().toLowerCase();
    if (!key || !value) continue;
    merged[key] = value;
  }
  return merged;
}

function _getApiPoolDefaultModelMap() {
  const extra = _parseJsonMap(process.env.GATEWAY_API_POOL_DEFAULT_MODEL_MAP || '');
  const merged = { ...DEFAULT_API_POOL_DEFAULT_MODEL_MAP };
  for (const [k, v] of Object.entries(extra)) {
    const key = String(k || '').trim().toLowerCase();
    const value = String(v || '').trim();
    if (!key || !value) continue;
    merged[key] = value;
  }
  return merged;
}

function _normalizeApiPoolProvider(raw) {
  const normalized = String(raw || '').trim().toLowerCase();
  if (!normalized) return null;
  const aliases = _getApiPoolAliasMap();
  return aliases[normalized] || normalized;
}

function _resolveApiPoolProviderForRequest(options = {}) {
  const explicitPool = _normalizeApiPoolProvider(options.apiPoolProvider);
  if (explicitPool) return explicitPool;

  const explicitProvider = _normalizeApiPoolProvider(options.provider);
  if (explicitProvider) return explicitProvider;

  const model = String(options.model || '').trim();
  const scoped = model.match(/^([a-z0-9_-]+)[:/](.+)$/i);
  if (scoped) {
    const fromModel = _normalizeApiPoolProvider(scoped[1]);
    if (fromModel) return fromModel;
  }

  return _normalizeApiPoolProvider(process.env.GATEWAY_API_POOL_PROVIDER || '');
}

function _mapApiPoolProviderToServiceProvider(poolProvider) {
  const mapped = _getApiPoolToServiceMap()[String(poolProvider || '').toLowerCase()] || null;
  return mapped || null;
}

function _defaultModelForApiPoolProvider(poolProvider) {
  const normalized = String(poolProvider || '').toLowerCase();
  if (normalized === 'deepseek') return process.env.DEEPSEEK_MODEL || _getApiPoolDefaultModelMap().deepseek;
  if (normalized === 'doubao') return process.env.DOUBAO_MODEL || _getApiPoolDefaultModelMap().doubao;
  if (normalized === 'qwen') return process.env.QWEN_MODEL || _getApiPoolDefaultModelMap().qwen;
  if (normalized === 'glm') return process.env.GLM_MODEL || process.env.ZHIPU_MODEL || _getApiPoolDefaultModelMap().glm;
  if (normalized === 'wenxin') return process.env.WENXIN_MODEL || _getApiPoolDefaultModelMap().wenxin;
  if (normalized === 'anthropic') return process.env.ANTHROPIC_MODEL || _getApiPoolDefaultModelMap().anthropic;
  if (normalized === 'openai') return process.env.OPENAI_MODEL || _getApiPoolDefaultModelMap().openai;
  if (normalized === 'trae') return process.env.TRAE_MODEL || _getApiPoolDefaultModelMap().trae;
  if (normalized === 'relay') return process.env.RELAY_API_MODEL || process.env.OPENAI_MODEL || _getApiPoolDefaultModelMap().relay;
  const mapped = _getApiPoolDefaultModelMap()[normalized];
  if (mapped) return mapped;
  return null;
}

function _isProcessSensitiveAdapter(adapterKey) {
  const key = String(adapterKey || '').trim().toLowerCase();
  return PROCESS_SENSITIVE_ADAPTER_KEYS.has(key);
}

function _parseProcessFailoverCandidates(raw) {
  const list = String(raw || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
  return list.length > 0 ? list : DEFAULT_PROCESS_FAILOVER_CANDIDATES;
}

function _resolveResultErrorType(statusCode, message, explicitType) {
  const rawType = String(explicitType || '').trim();
  if (!rawType || rawType.toLowerCase() === 'unknown') {
    return classifyError(statusCode, message);
  }
  return rawType;
}

function _extractResultErrorMessage(result) {
  const direct = _sanitizeFailureMessage(result?.error || result?.message || '');
  if (direct && direct !== 'unknown error') return direct;
  if (Array.isArray(result?.attempts)) {
    for (const attempt of result.attempts) {
      if (!attempt || attempt.success !== false) continue;
      const attemptMsg = _sanitizeFailureMessage(attempt.error || attempt.message || '');
      if (attemptMsg && attemptMsg !== 'unknown error') return attemptMsg;
    }
  }
  const content = _sanitizeFailureMessage(result?.content || '');
  if (content && content !== 'unknown error') return content;
  return 'unknown error';
}

function normalizeModelForAdapter(adapterKey, model) {
  if (!model || typeof model !== 'string') return model;
  const m = model.trim();
  if (!m) return model;

  if (adapterKey === 'codex') {
    // Prevent carrying Claude model ids into Codex CLI requests.
    if (/^claude[-_]/i.test(m) || m.includes('sonnet') || m.includes('opus') || m.includes('haiku')) {
      return null;
    }
  }
  if (adapterKey === 'claude') {
    // Prevent carrying non-Claude model ids into Claude CLI requests.
    // Claude adapter should only receive claude-* style model ids.
    if (!/^claude[-_]/i.test(m)) {
      return null;
    }
  }

  return model;
}

function resolvePreferredModelForAdapter(adapterKey, model) {
  const normalized = normalizeModelForAdapter(adapterKey, model);
  if (!normalized || typeof normalized !== 'string') return null;
  const trimmed = normalized.trim();
  return trimmed || null;
}

function buildPreferredAdapterRecoveryHint(preferredAdapter, error) {
  const adapter = String(preferredAdapter || '').trim() || 'unknown';
  const adapterKey = adapter.toLowerCase();
  const adapterDisplay = ({
    cli: 'CLI 工具桥接',
    codex: 'Codex',
    claude: 'Claude',
    kiro: 'Kiro',
    cursor: 'Cursor',
    trae: 'Trae',
    windsurf: 'Windsurf',
    vscode: 'VSCode',
    warp: 'Warp',
    localllm: '本地模型',
    ollama: 'Ollama',
    api: 'API',
    relay: 'Web Relay',
  })[adapterKey] || adapter;
  const lower = String(error || '').toLowerCase();
  const abortLike = /aborterror|abort_err|\baborted\b|\brequest aborted\b|\babort(ed)? by\b|signal aborted|user[-\s]?cancel/.test(lower);
  const processCanceledLike = !abortLike && /\bcancelled\b|\bcanceled\b/.test(lower);
  const lines = [
    processCanceledLike
      ? `已选择模型通道进程中断（非用户取消）: ${error || 'canceled'}`
      : `已选择模型通道请求失败: ${error || 'unknown error'}`,
    '',
    '建议下一步:',
    '  1) 运行 `khy gateway status` 查看各通道实测状态',
    '  2) 运行 `khy gateway model` 仅选择“可执行”模型',
  ];
  if (processCanceledLike) {
    lines.push(`  3) 运行 \`khy gateway reconnect ${adapter}\` 强制重连后重试`);
    lines.push('  4) 默认会自动放宽 strict 并尝试兜底通道；如被手动关闭可设置 GATEWAY_STRICT_AUTO_RELAX_ON_PROCESS=true');
  } else if (lower.includes('apikeysource') || lower.includes('auth') || lower.includes('unauthorized') || lower.includes('login')) {
    if (adapterKey === 'cli') {
      const cliTarget = lower.includes('claude') ? 'Claude Code'
        : (lower.includes('codex') ? 'Codex' : 'Codex/Claude');
      lines.push(`  3) 重新登录 ${cliTarget} 后再试`);
    } else {
      lines.push(`  3) 重新登录 ${adapterDisplay} 后再试`);
    }
  } else if (lower.includes('reconnecting') || lower.includes('channel closed')) {
    if (adapterKey === 'cli') {
      const cliTarget = lower.includes('claude') ? 'Claude Code'
        : (lower.includes('codex') ? 'Codex' : 'Codex/Claude');
      lines.push(`  3) 重启 ${cliTarget} CLI 会话并重试`);
    } else {
      lines.push(`  3) 重启 ${adapterDisplay} CLI 会话并重试`);
    }
  } else if (lower.includes('loopback listen is not permitted') || lower.includes('listen eperm')) {
    lines.push('  3) 运行 `khy doctor` 检查本地监听能力与本地模型后端');
    lines.push('  4) 若处于沙箱/受限环境，请切换到 API/桥接通道（khy gateway model）');
  } else if (lower.includes('timeout')) {
    lines.push('  3) 检查网络/代理后重试');
  } else if (lower.includes('bridge canceled') || lower.includes('handshake timeout') || lower.includes('without emitting stream-json')) {
    lines.push(`  3) Claude CLI 桥接模式异常 — 尝试设置 GATEWAY_CLAUDE_MODE=direct 直连 API`);
    lines.push('  4) 或配置 RELAY_API_ENDPOINT + RELAY_API_KEY 启用中继兜底');
    lines.push('  5) 运行 `khy doctor` 检查 Claude CLI 版本兼容性');
  }
  return lines.join('\n');
}

function normalizeAbortReason(reason) {
  if (!reason) return 'aborted';
  if (typeof reason === 'string') return reason;
  if (reason && typeof reason.message === 'string') return reason.message;
  try { return JSON.stringify(reason); } catch { return String(reason); }
}

function createAbortError(reason) {
  const err = new Error(normalizeAbortReason(reason));
  err.name = 'AbortError';
  err.code = 'ABORT_ERR';
  return err;
}

function throwIfAborted(signal) {
  if (signal && signal.aborted) {
    throw createAbortError(signal.reason || 'aborted');
  }
}

function createLinkedAbortController(parentSignal) {
  const controller = new AbortController();
  let detach = () => {};

  if (parentSignal) {
    if (parentSignal.aborted) {
      controller.abort(parentSignal.reason);
    } else if (typeof parentSignal.addEventListener === 'function') {
      const onAbort = () => {
        try { controller.abort(parentSignal.reason); } catch { /* ignore */ }
      };
      parentSignal.addEventListener('abort', onAbort, { once: true });
      detach = () => {
        try { parentSignal.removeEventListener('abort', onAbort); } catch { /* ignore */ }
      };
    }
  }

  return {
    controller,
    signal: controller.signal,
    abort: (reason) => {
      if (!controller.signal.aborted) {
        try { controller.abort(reason); } catch { /* ignore */ }
      }
    },
    cleanup: detach,
  };
}

class AIGateway {
  constructor() {
    this._adapters = [
      { key: 'localLLM', adapter: localLLMAdapter, priority: 0, enabled: true },
      { key: 'cli', adapter: cliToolAdapter, priority: 1, enabled: true },
      { key: 'kiro', adapter: kiroAdapter, priority: 2, enabled: true },
      { key: 'cursor', adapter: cursorAdapter, priority: 3, enabled: true },
      { key: 'trae', adapter: traeAdapter, priority: 4, enabled: true },
      { key: 'claude', adapter: claudeAdapter, priority: 5, enabled: true },
      { key: 'codex', adapter: codexAdapter, priority: 6, enabled: true },
      { key: 'windsurf', adapter: windsurfAdapter, priority: 7, enabled: true },
      { key: 'vscode', adapter: vscodeAdapter, priority: 8, enabled: true },
      { key: 'warp', adapter: warpAdapter, priority: 9, enabled: true },
      { key: 'ollama', adapter: ollamaAdapter, priority: 10, enabled: true },
      { key: 'cursor2api', adapter: cursor2apiAdapter, priority: 11, enabled: true },
      { key: 'relay_api', adapter: relayApiAdapter, priority: 12, enabled: true },
      { key: 'api', adapter: apiAdapter, priority: 13, enabled: true },
      { key: 'relay', adapter: webRelayAdapter, priority: 14, enabled: true },
      { key: 'clipboard', adapter: clipboardRelayAdapter, priority: 15, enabled: true },
    ];
    this._initialized = false;
    this._initPromise = null;

    // ── Redis-backed state (graceful degradation to in-memory) ──────────
    const _getRedisClient = () => {
      try {
        const { getRedisClient } = require('@khy/shared/src/services/cacheService');
        return getRedisClient();
      } catch { return null; }
    };
    const redisHealthEnabled = String(process.env.GATEWAY_REDIS_HEALTH_ENABLED || 'true').toLowerCase() !== 'false';
    this._healthStore = redisHealthEnabled
      ? new RedisHealthStore({ getRedisClient: _getRedisClient })
      : new RedisHealthStore({ getRedisClient: () => null }); // pure memory mode

    // Distributed rate limiter (Redis ZSET sliding window, fallback to memory)
    const redisRlEnabled = String(process.env.GATEWAY_REDIS_RATELIMIT_ENABLED || 'true').toLowerCase() !== 'false';
    this._distributedLimiter = createRedisRateLimiter({
      getRedisClient: redisRlEnabled ? _getRedisClient : () => null,
      maxRequests: 10,
      windowMs: 60000,
    });

    // Request deduplication
    this._dedup = createRequestDedup({ getRedisClient: _getRedisClient });

    // Channel health broadcaster
    let notifyAll = null;
    try {
      const ns = require('../notificationService');
      if (ns && typeof ns.broadcastToAll === 'function') {
        notifyAll = ns.broadcastToAll.bind(ns);
      }
    } catch { /* notificationService not available */ }
    this._healthBroadcaster = new ChannelHealthBroadcaster({
      healthStore: this._healthStore,
      broadcast: (type, data) => {
        try {
          if (notifyAll) notifyAll({ type, ...data });
        } catch { /* notificationService not available */ }
      },
    });

    // Anti-ban: token bucket rate limiter (per adapter) — kept as fast in-memory fallback
    this._requestLog = {};          // key → timestamps of recent requests
    this._adapterFailures = {};     // key → consecutive failure count (synced with healthStore)
    this._lastRefreshTime = 0;      // last adapter re-detection time
    // Local adapters that don't need rate limiting
    this._localAdapters = new Set(['localLLM', 'ollama']);
    // Recent adapter failure cache for fast-fail (prevents repeated stalls on dead channels)
    this._adapterLastError = {};
    // Cooldown self-heal probe state (adapterKey -> in-flight promise / meta)
    this._cooldownSelfHealInFlight = new Map();
    this._cooldownSelfHealMeta = {};
    this._cooldownSelfHealTimer = null;
    this._cooldownSelfHealMidpointTimers = new Map();
    // Fixed-window rate limiter (replaces manual timestamp tracking for new callers)
    this._keyedLimiter = createKeyedRateLimiter({ maxRequests: 10, windowMs: 60_000 });
    // Per-adapter sequential queue (prevents concurrent bridge collisions).
    // Keep a bounded timeout so a stuck adapter task cannot block all followers forever.
    // Timeout only releases queue progression; the underlying task may still finish later.
    const queueTimeoutMs = Math.max(
      0,
      parseInt(process.env.GATEWAY_ADAPTER_QUEUE_TIMEOUT_MS || '300000', 10) || 300000
    );
    this._adapterQueue = createSequentialQueue({ taskTimeoutMs: queueTimeoutMs });
    const defaultSerializedAdapters = [
      'localLLM',
      'ollama',
      'codex',
      'claude',
      'cli',
      'clipboard',
    ];
    const serializedEnvList = String(process.env.GATEWAY_SERIAL_ADAPTERS || '')
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);
    const parallelEnvSet = new Set(
      String(process.env.GATEWAY_PARALLEL_ADAPTERS || '')
        .split(',')
        .map(s => s.trim().toLowerCase())
        .filter(Boolean)
    );
    this._serializedAdapterKeys = new Set(
      (serializedEnvList.length > 0 ? serializedEnvList : defaultSerializedAdapters)
    );
    if (parallelEnvSet.size > 0) {
      for (const key of Array.from(this._serializedAdapterKeys)) {
        if (parallelEnvSet.has(String(key || '').toLowerCase())) {
          this._serializedAdapterKeys.delete(key);
        }
      }
    }
  }

  /**
   * Periodic cleanup of stale adapter data to prevent memory leaks.
   */
  _cleanupStaleData() {
    const validKeys = new Set(this._adapters.map(a => a.key));
    for (const key of Object.keys(this._requestLog)) {
      if (!validKeys.has(key)) delete this._requestLog[key];
      else if (this._requestLog[key].length > 100) {
        this._requestLog[key] = this._requestLog[key].slice(-100);
      }
    }
    for (const key of Object.keys(this._adapterFailures)) {
      if (!validKeys.has(key)) delete this._adapterFailures[key];
      else if (this._adapterFailures[key] > 20) this._adapterFailures[key] = 20;
    }
    for (const key of Object.keys(this._adapterLastError)) {
      if (!validKeys.has(key)) delete this._adapterLastError[key];
    }
    for (const key of Object.keys(this._cooldownSelfHealMeta)) {
      if (!validKeys.has(key)) delete this._cooldownSelfHealMeta[key];
    }
    for (const key of Array.from(this._cooldownSelfHealInFlight.keys())) {
      if (!validKeys.has(key)) this._cooldownSelfHealInFlight.delete(key);
    }
    for (const key of Array.from(this._cooldownSelfHealMidpointTimers.keys())) {
      if (!validKeys.has(key)) this._clearCooldownSelfHealMidpointTimer(key);
    }
  }

  _clearCooldownSelfHealMidpointTimer(adapterKey) {
    const current = this._cooldownSelfHealMidpointTimers.get(adapterKey);
    if (current && current.timer) {
      clearTimeout(current.timer);
    }
    this._cooldownSelfHealMidpointTimers.delete(adapterKey);
  }

  _clearAllCooldownSelfHealMidpointTimers() {
    for (const key of Array.from(this._cooldownSelfHealMidpointTimers.keys())) {
      this._clearCooldownSelfHealMidpointTimer(key);
    }
  }

  _scheduleCooldownSelfHealMidpointTimer(adapterKey, failureAt, midpointAt) {
    const cfg = this._resolveCooldownSelfHealConfig();
    if (!cfg.enabled) return false;
    const failureTs = Number(failureAt || 0);
    const midpointTs = Number(midpointAt || 0);
    if (!Number.isFinite(failureTs) || failureTs <= 0) return false;
    if (!Number.isFinite(midpointTs) || midpointTs <= 0) return false;

    this._clearCooldownSelfHealMidpointTimer(adapterKey);
    const delayMs = Math.max(0, midpointTs - Date.now());
    const timer = setTimeout(() => {
      this._cooldownSelfHealMidpointTimers.delete(adapterKey);
      const recent = this._getRecentFastFail(adapterKey);
      if (!recent) return;
      if (Number(recent.at || 0) !== failureTs) return;
      this._triggerMidpointSelfHealProbe(adapterKey, recent, {
        source: 'timer_midpoint_exact',
      });
    }, delayMs);
    if (timer.unref) timer.unref();

    this._cooldownSelfHealMidpointTimers.set(adapterKey, {
      timer,
      failureAt: failureTs,
      midpointAt: midpointTs,
    });
    this._cooldownSelfHealMeta[adapterKey] = {
      ...this._cooldownSelfHealMeta[adapterKey],
      midpointAt: midpointTs,
      midpointTimerForFailureAt: failureTs,
      midpointTimerArmedAt: Date.now(),
      lastOutcome: 'midpoint_timer_armed',
    };
    return true;
  }

  _triggerMidpointSelfHealProbe(adapterKey, recentFail = null, options = {}) {
    const recent = recentFail || this._getRecentFastFail(adapterKey);
    if (!recent) return false;
    const now = Date.now();
    const meta = this._cooldownSelfHealMeta[adapterKey] || {};
    const failureAt = Number(recent.at || 0);
    const midpointAt = Number(meta.midpointAt || 0) > 0
      ? Number(meta.midpointAt)
      : (failureAt + Math.max(1000, Math.floor(Number(recent.cooldownMs || 0) / 2)));
    if (!Number.isFinite(midpointAt) || now < midpointAt) return false;
    if (meta.midpointProbeForFailureAt && Number(meta.midpointProbeForFailureAt) === failureAt) return false;

    const statusName = (() => {
      const entry = this._adapters.find(a => a.key === adapterKey);
      if (!entry) return adapterKey;
      try { return entry.adapter.getStatus().name || adapterKey; } catch { return adapterKey; }
    })();

    const scheduled = this._maybeScheduleCooldownSelfHealProbe(adapterKey, recent, {
      source: String(options.source || 'timer_midpoint'),
      adapterDisplayName: statusName,
    });
    if (!scheduled) return false;

    this._cooldownSelfHealMeta[adapterKey] = {
      ...this._cooldownSelfHealMeta[adapterKey],
      midpointAt,
      midpointProbeForFailureAt: failureAt,
      midpointProbeAt: now,
      lastOutcome: `midpoint_probe_scheduled:${String(options.source || 'timer_midpoint')}`,
    };
    return true;
  }

  async _recordAdapterFailure(adapterKey, errorType, error) {
    const normalizedType = String(errorType || '').trim() || 'unknown';
    const cooldownMs = this._resolveFastFailCooldownMs(adapterKey, normalizedType, error);
    const now = Date.now();
    const sanitizedError = _sanitizeFailureMessage(error || 'unknown error');
    const previousLocalFailures = Number(this._adapterFailures[adapterKey] || 0);

    // Keep local mirror hot immediately (before any async I/O) so fast-fail
    // checks in the same tick can observe this failure.
    this._adapterLastError[adapterKey] = {
      at: now,
      errorType: normalizedType,
      error: sanitizedError,
      cooldownMs,
      circuitOpen: false,
    };
    this._adapterFailures[adapterKey] = previousLocalFailures + 1;

    const consecutiveFailures = await this._healthStore.getFailureCount(adapterKey);

    // Circuit breaker: if adapter fails 5+ times consecutively, extend cooldown
    // to 60s regardless of error type (prevents hammering a dead adapter)
    const CIRCUIT_BREAKER_THRESHOLD = _parsePositiveInt(
      process.env.GATEWAY_CIRCUIT_BREAKER_THRESHOLD, 3, 2, 20
    );
    const CIRCUIT_BREAKER_COOLDOWN_MS = _parseMs(
      process.env.GATEWAY_CIRCUIT_BREAKER_COOLDOWN_MS || '30000', 30000, 10000
    );
    // Exponential cooldown: baseCooldown * 2^min(failures-threshold, 4), cap at 5min
    const overThreshold = Math.max(0, consecutiveFailures - CIRCUIT_BREAKER_THRESHOLD);
    const circuitOpen = consecutiveFailures >= CIRCUIT_BREAKER_THRESHOLD;
    const effectiveCooldownMs = circuitOpen
      ? Math.min(300000, Math.max(cooldownMs, CIRCUIT_BREAKER_COOLDOWN_MS) * Math.pow(2, Math.min(overThreshold, 4)))
      : cooldownMs;

    const record = {
      at: now,
      errorType: normalizedType,
      error: sanitizedError,
      cooldownMs: effectiveCooldownMs,
      circuitOpen,
    };

    // Persist to Redis (or memory fallback)
    await this._healthStore.incrFailure(adapterKey);
    await this._healthStore.recordLastError(adapterKey, record, effectiveCooldownMs + 10000);
    if (circuitOpen) {
      await this._healthStore.setCooldown(adapterKey, effectiveCooldownMs);
      await this._healthStore.resetHalfOpen(adapterKey);
    }

    // Keep legacy in-memory copy for sync reads that haven't been migrated
    this._adapterLastError[adapterKey] = record;
    this._adapterFailures[adapterKey] = consecutiveFailures + 1;
    this._cooldownSelfHealMeta[adapterKey] = {
      failureAt: now,
      cooldownMs: effectiveCooldownMs,
      midpointAt: now + Math.max(1000, Math.floor(effectiveCooldownMs / 2)),
      midpointProbeForFailureAt: null,
      nextAllowedAt: now,
      lastAttemptAt: 0,
      lastOutcome: 'failure_recorded',
    };
    this._scheduleCooldownSelfHealMidpointTimer(
      adapterKey,
      now,
      this._cooldownSelfHealMeta[adapterKey].midpointAt
    );

    // Broadcast health event
    this._healthBroadcaster.recordRequestActivity(adapterKey, 'failure', normalizedType);
  }

  async _clearAdapterFailure(adapterKey) {
    this._clearCooldownSelfHealMidpointTimer(adapterKey);
    delete this._adapterLastError[adapterKey];
    this._adapterFailures[adapterKey] = 0;
    delete this._cooldownSelfHealMeta[adapterKey];
    this._cooldownSelfHealInFlight.delete(adapterKey);
    await this._healthStore.clearFailure(adapterKey);
    this._healthBroadcaster.recordRequestActivity(adapterKey, 'success', 'circuit cleared');
  }

  _getRecentFastFail(adapterKey) {
    // Fast path: synchronous in-memory mirror.
    const item = this._adapterLastError[adapterKey] || null;
    if (!item) return null;
    const fallbackCooldownMs = _parseMs(process.env.GATEWAY_FAST_FAIL_COOLDOWN_MS || '30000', 30000, 5000);
    const cooldownMs = _parseMs(item.cooldownMs, fallbackCooldownMs, 5000);
    const elapsedMs = Date.now() - Number(item.at || 0);
    if (elapsedMs > cooldownMs) return null;
    // Circuit breaker: always fast-fail when circuit is open, regardless of error type
    if (!item.circuitOpen && !_shouldUseFastFail(item.errorType)) return null;

    return {
      ...item,
      cooldownMs,
      remainingMs: Math.max(0, cooldownMs - elapsedMs),
    };
  }

  _resolveCooldownSelfHealConfig() {
    return {
      enabled: String(process.env.GATEWAY_COOLDOWN_SELF_HEAL_ENABLED || 'true').toLowerCase() !== 'false',
      minRemainingMs: _parseMs(
        process.env.GATEWAY_COOLDOWN_SELF_HEAL_MIN_REMAINING_MS || '2500',
        2500,
        1000
      ),
      minIntervalMs: _parseMs(
        process.env.GATEWAY_COOLDOWN_SELF_HEAL_MIN_INTERVAL_MS || '7000',
        7000,
        1000
      ),
      successQuietMs: _parseMs(
        process.env.GATEWAY_COOLDOWN_SELF_HEAL_SUCCESS_QUIET_MS || '45000',
        45000,
        5000
      ),
      failureRetryMs: _parseMs(
        process.env.GATEWAY_COOLDOWN_SELF_HEAL_FAILURE_RETRY_MS || '15000',
        15000,
        3000
      ),
      probeTimeoutMs: _parseMs(
        process.env.GATEWAY_COOLDOWN_SELF_HEAL_PROBE_TIMEOUT_MS || '9000',
        9000,
        2000
      ),
      generationProbeTimeoutMs: _parseMs(
        process.env.GATEWAY_COOLDOWN_SELF_HEAL_PROBE_GENERATION_TIMEOUT_MS || '7000',
        7000,
        2000
      ),
      tickMs: _parseMs(
        process.env.GATEWAY_COOLDOWN_SELF_HEAL_TICK_MS || '3000',
        3000,
        1000
      ),
    };
  }

  async _runCooldownSelfHealTick() {
    const cfg = this._resolveCooldownSelfHealConfig();
    if (!cfg.enabled) return;
    const keys = Object.keys(this._adapterLastError || {});
    for (const adapterKey of keys) {
      const recent = this._getRecentFastFail(adapterKey);
      if (!recent) continue;
      this._triggerMidpointSelfHealProbe(adapterKey, recent, { source: 'timer_midpoint_tick' });
    }
  }

  _startCooldownSelfHealTicker() {
    this._stopCooldownSelfHealTicker();
    const cfg = this._resolveCooldownSelfHealConfig();
    if (!cfg.enabled) return;
    const tick = () => {
      this._runCooldownSelfHealTick().catch(() => {});
    };
    this._cooldownSelfHealTimer = setInterval(tick, cfg.tickMs);
    if (this._cooldownSelfHealTimer.unref) this._cooldownSelfHealTimer.unref();
    for (const [adapterKey, recent] of Object.entries(this._adapterLastError || {})) {
      if (!recent) continue;
      const failureAt = Number(recent.at || 0);
      const cooldownMs = Number(recent.cooldownMs || 0);
      if (!Number.isFinite(failureAt) || failureAt <= 0) continue;
      const midpointAt = failureAt + Math.max(1000, Math.floor(cooldownMs / 2));
      this._scheduleCooldownSelfHealMidpointTimer(adapterKey, failureAt, midpointAt);
    }
    tick();
  }

  _stopCooldownSelfHealTicker() {
    if (this._cooldownSelfHealTimer) {
      clearInterval(this._cooldownSelfHealTimer);
      this._cooldownSelfHealTimer = null;
    }
    this._clearAllCooldownSelfHealMidpointTimers();
  }

  _isHealthyProbeResult(probeResult) {
    if (!probeResult || typeof probeResult !== 'object') return false;
    const connectivityOk = !!probeResult.connectivity?.success;
    if (!connectivityOk) return false;
    if (Object.prototype.hasOwnProperty.call(probeResult, 'generation')) {
      return !!probeResult.generation?.success;
    }
    if (Object.prototype.hasOwnProperty.call(probeResult, 'models')) {
      return !!probeResult.models?.success;
    }
    return true;
  }

  _maybeScheduleCooldownSelfHealProbe(adapterKey, recentFail = null, options = {}) {
    const cfg = this._resolveCooldownSelfHealConfig();
    if (!cfg.enabled) return false;
    const entry = this._adapters.find(a => a.key === adapterKey && a.enabled);
    if (!entry) return false;
    const cached = recentFail || this._getRecentFastFail(adapterKey);
    if (!cached) return false;
    if ((cached.remainingMs || 0) < cfg.minRemainingMs) return false;
    const now = Date.now();
    const meta = this._cooldownSelfHealMeta[adapterKey] || {};
    if (this._cooldownSelfHealInFlight.has(adapterKey)) return false;
    if (meta.nextAllowedAt && now < meta.nextAllowedAt) return false;
    if (meta.lastAttemptAt && (now - meta.lastAttemptAt) < cfg.minIntervalMs) return false;

    const emitStatus = typeof options.emitStatus === 'function' ? options.emitStatus : () => {};
    const adapterDisplayName = String(options.adapterDisplayName || (() => {
      try { return entry.adapter.getStatus().name || adapterKey; } catch { return adapterKey; }
    })());
    const sourceLabel = String(options.source || 'generate').trim() || 'generate';
    const shouldDeepProbe = _isProcessSensitiveAdapter(adapterKey)
      || adapterKey === 'relay_api'
      || adapterKey === 'api'
      || adapterKey === 'relay';

    this._cooldownSelfHealMeta[adapterKey] = {
      ...meta,
      lastAttemptAt: now,
      nextAllowedAt: now + cfg.minIntervalMs,
      lastSource: sourceLabel,
    };

    const probePromise = (async () => {
      try {
        emitStatus(`冷却探活: 已启动 ${adapterDisplayName} 通道后台健康检测（目标: 提前解除冷却）`);
        this._healthBroadcaster.recordRequestActivity(
          adapterKey,
          'attempt',
          `cooldown_self_heal_probe:${sourceLabel}`
        );
        const probeResult = await this.testAdapter(adapterKey, {
          quick: !shouldDeepProbe,
          timeoutMs: cfg.probeTimeoutMs,
          probeGenerationTimeoutMs: shouldDeepProbe ? cfg.generationProbeTimeoutMs : 0,
        });
        if (this._isHealthyProbeResult(probeResult)) {
          await this._clearAdapterFailure(adapterKey);
          this._cooldownSelfHealMeta[adapterKey] = {
            ...this._cooldownSelfHealMeta[adapterKey],
            lastSuccessAt: Date.now(),
            nextAllowedAt: Date.now() + cfg.successQuietMs,
            lastOutcome: 'recovered',
          };
          emitStatus(`冷却探活完成: ${adapterDisplayName} 通道已恢复（已提前解除冷却）`);
          this._healthBroadcaster.recordRequestActivity(
            adapterKey,
            'success',
            `cooldown_self_heal_probe_recovered:${sourceLabel}`
          );
          return;
        }
        const retryAt = Date.now() + cfg.failureRetryMs;
        this._cooldownSelfHealMeta[adapterKey] = {
          ...this._cooldownSelfHealMeta[adapterKey],
          nextAllowedAt: retryAt,
          lastOutcome: 'still_unhealthy',
        };
        emitStatus(`冷却探活结果: ${adapterDisplayName} 通道仍异常（继续冷却，稍后再探活）`);
        this._healthBroadcaster.recordRequestActivity(
          adapterKey,
          'failure',
          `cooldown_self_heal_probe_still_unhealthy:${sourceLabel}`
        );
      } catch (err) {
        const retryAt = Date.now() + cfg.failureRetryMs;
        this._cooldownSelfHealMeta[adapterKey] = {
          ...this._cooldownSelfHealMeta[adapterKey],
          nextAllowedAt: retryAt,
          lastOutcome: `probe_error:${err?.message || 'unknown'}`,
        };
        emitStatus(`冷却探活错误: ${adapterDisplayName} 通道检测失败（将保持冷却）`);
        this._healthBroadcaster.recordRequestActivity(
          adapterKey,
          'failure',
          `cooldown_self_heal_probe_error:${err?.message || 'unknown'}`
        );
      } finally {
        this._cooldownSelfHealInFlight.delete(adapterKey);
      }
    })();

    this._cooldownSelfHealInFlight.set(adapterKey, probePromise);
    return true;
  }

  _resolveFastFailCooldownMs(adapterKey, errorType, error) {
    const baseCooldownMs = _parseMs(process.env.GATEWAY_FAST_FAIL_COOLDOWN_MS || '30000', 30000, 5000);
    if (String(adapterKey || '').toLowerCase() !== 'codex') return baseCooldownMs;

    const errorKind = String(errorType || '').toLowerCase();
    const message = String(error || '').toLowerCase();
    const processCooldownMs = _parseMs(
      process.env.GATEWAY_FAST_FAIL_CODEX_PROCESS_COOLDOWN_MS || '30000',
      30000,
      baseCooldownMs
    );
    const reconnectCooldownMs = _parseMs(
      process.env.GATEWAY_FAST_FAIL_CODEX_RECONNECT_COOLDOWN_MS || String(processCooldownMs),
      processCooldownMs,
      baseCooldownMs
    );
    const networkCooldownMs = _parseMs(
      process.env.GATEWAY_FAST_FAIL_CODEX_NETWORK_COOLDOWN_MS || '60000',
      60000,
      baseCooldownMs
    );
    const timeoutCooldownMs = _parseMs(
      process.env.GATEWAY_FAST_FAIL_CODEX_TIMEOUT_COOLDOWN_MS || '45000',
      45000,
      baseCooldownMs
    );

    if (errorKind === 'process') {
      if (/reconnecting|channel closed|without emitting stream-json|failed to record rollout items/.test(message)) {
        return reconnectCooldownMs;
      }
      return processCooldownMs;
    }
    if (errorKind === 'network') return networkCooldownMs;
    if (errorKind === 'timeout') return timeoutCooldownMs;
    return baseCooldownMs;
  }

  _resolveAdapterTimeoutMs(adapterKey, fallbackTimeoutMs) {
    const fallbackMs = _parseMs(fallbackTimeoutMs, 60000, 1000);
    const envTimeout = process.env[`GATEWAY_${String(adapterKey || '').toUpperCase()}_TIMEOUT_MS`];
    if (String(envTimeout || '').trim()) {
      return _parseMs(envTimeout, fallbackMs, 1000);
    }

    const resolvedMs = _parseMs(
      process.env.GATEWAY_PER_ADAPTER_TIMEOUT_MS || String(fallbackMs),
      fallbackMs,
      1000
    );
    const normalizedAdapterKey = String(adapterKey || '').trim().toLowerCase();
    if (normalizedAdapterKey !== 'localllm' && normalizedAdapterKey !== 'ollama') {
      return resolvedMs;
    }

    if (normalizedAdapterKey === 'localllm') {
      let status = null;
      try {
        status = localLLMService && typeof localLLMService.getStatus === 'function'
          ? localLLMService.getStatus()
          : null;
      } catch {
        status = null;
      }
      if (!status || !status.available) return resolvedMs;

      const coldStartTimeoutMs = _parseMs(
        process.env.GATEWAY_LOCAL_LLM_COLD_TIMEOUT_MS || '180000',
        180000,
        Math.max(1000, resolvedMs)
      );
      const warmTimeoutMs = _parseMs(
        process.env.GATEWAY_LOCAL_LLM_WARM_TIMEOUT_MS || String(Math.max(90000, resolvedMs)),
        Math.max(90000, resolvedMs),
        1000
      );
      const degradedTimeoutMs = _parseMs(
        process.env.GATEWAY_LOCAL_LLM_DEGRADED_TIMEOUT_MS || String(Math.max(coldStartTimeoutMs, 210000)),
        Math.max(coldStartTimeoutMs, 210000),
        1000
      );

      if (status.lastError) return Math.max(resolvedMs, degradedTimeoutMs);
      if (!status.loaded) return Math.max(resolvedMs, coldStartTimeoutMs);
      return Math.max(1000, warmTimeoutMs);
    }

    let ollamaStatus = null;
    try {
      ollamaStatus = ollamaAdapter && typeof ollamaAdapter.getStatus === 'function'
        ? ollamaAdapter.getStatus()
        : null;
    } catch {
      ollamaStatus = null;
    }

    const ollamaWarmTimeoutMs = _parseMs(
      process.env.GATEWAY_OLLAMA_WARM_TIMEOUT_MS || String(Math.max(120000, resolvedMs)),
      Math.max(120000, resolvedMs),
      1000
    );
    const ollamaColdTimeoutMs = _parseMs(
      process.env.GATEWAY_OLLAMA_COLD_TIMEOUT_MS || String(Math.max(180000, ollamaWarmTimeoutMs)),
      Math.max(180000, ollamaWarmTimeoutMs),
      1000
    );
    const ollamaDegradedTimeoutMs = _parseMs(
      process.env.GATEWAY_OLLAMA_DEGRADED_TIMEOUT_MS || String(Math.max(210000, ollamaColdTimeoutMs)),
      Math.max(210000, ollamaColdTimeoutMs),
      1000
    );
    const recentOllamaFail = this._getRecentFastFail('ollama');
    if (recentOllamaFail) return Math.max(resolvedMs, ollamaDegradedTimeoutMs);
    if (ollamaStatus && ollamaStatus.available) return Math.max(resolvedMs, ollamaColdTimeoutMs);
    return Math.max(resolvedMs, ollamaWarmTimeoutMs);
  }

  _shouldSerializeAdapter(adapterKey) {
    const raw = String(adapterKey || '').trim();
    if (!raw) return false;
    if (this._serializedAdapterKeys.has(raw)) return true;
    const lower = raw.toLowerCase();
    for (const key of this._serializedAdapterKeys) {
      if (String(key || '').toLowerCase() === lower) return true;
    }
    return false;
  }

  async _maybePromoteProcessFailoverAdapters(orderedAdapters, options = {}) {
    const list = Array.isArray(orderedAdapters) ? orderedAdapters : [];
    const preferredAdapter = String(options.preferredAdapter || '').trim();
    const strictPreferredOnly = !!options.strictPreferredOnly;
    const emitStatus = typeof options.emitStatus === 'function' ? options.emitStatus : () => {};
    const featureEnabled = String(
      process.env.GATEWAY_PROCESS_FAILOVER_PARALLEL_ENABLED || 'true'
    ).toLowerCase() !== 'false';

    if (!featureEnabled || strictPreferredOnly) return list;
    if (!preferredAdapter || preferredAdapter === 'auto') return list;
    if (!_isProcessSensitiveAdapter(preferredAdapter)) return list;

    const recentPreferredFail = await this._getRecentFastFail(preferredAdapter);
    const hasRecentProcessFailure = !!(recentPreferredFail && recentPreferredFail.errorType === 'process');
    const preferredFailureCount = Number(this._adapterFailures[preferredAdapter] || 0);
    if (!hasRecentProcessFailure && preferredFailureCount < 1) return list;
    if (recentPreferredFail) {
      this._maybeScheduleCooldownSelfHealProbe(preferredAdapter, recentPreferredFail, {
        emitStatus,
        adapterDisplayName: preferredAdapter,
        source: 'preferred_parallel_failover',
      });
    }

    const candidateKeys = _parseProcessFailoverCandidates(
      process.env.GATEWAY_PROCESS_FAILOVER_CANDIDATES || ''
    );
    if (candidateKeys.length === 0) return list;

    const byLowerKey = new Map(
      list.map(entry => [String(entry?.key || '').toLowerCase(), entry])
    );
    const candidateEntries = candidateKeys
      .map(key => byLowerKey.get(String(key || '').toLowerCase()))
      .filter(entry => entry && entry.enabled && entry.key !== preferredAdapter);
    if (candidateEntries.length === 0) return list;

    emitStatus(`检测到 ${preferredAdapter} 通道近期异常，正在并行探测远端兜底通道...`);

    const probeResults = await Promise.all(candidateEntries.map(async (entry) => {
      const statusName = (() => {
        try { return entry.adapter.getStatus().name || entry.key; } catch { return entry.key; }
      })();
      const recentFail = await this._getRecentFastFail(entry.key);
      if (recentFail) {
        this._maybeScheduleCooldownSelfHealProbe(entry.key, recentFail, {
          emitStatus,
          adapterDisplayName: statusName,
          source: 'candidate_parallel_failover',
        });
        return {
          key: entry.key,
          name: statusName,
          available: false,
          reason: `cooldown:${recentFail.errorType || 'unknown'}`,
        };
      }
      try {
        const available = entry.adapter.detectAsync
          ? await entry.adapter.detectAsync(true)
          : !!entry.adapter.detect(true);
        entry.available = !!available;
        return {
          key: entry.key,
          name: statusName,
          available: !!available,
          reason: available ? 'ok' : 'unavailable',
        };
      } catch {
        entry.available = false;
        return {
          key: entry.key,
          name: statusName,
          available: false,
          reason: 'detect_error',
        };
      }
    }));

    const availableByLower = new Map(
      probeResults
        .filter(item => item.available)
        .map(item => [String(item.key || '').toLowerCase(), item])
    );
    if (availableByLower.size === 0) {
      emitStatus('并行探测完成：未发现可用远端兜底通道');
      return list;
    }

    const promotedEntries = candidateKeys
      .map(key => byLowerKey.get(String(key || '').toLowerCase()))
      .filter(entry => entry && availableByLower.has(String(entry.key || '').toLowerCase()));
    if (promotedEntries.length === 0) return list;

    emitStatus(`并行探测完成：优先兜底通道 ${promotedEntries.map(e => {
      try { return e.adapter.getStatus().name || e.key; } catch { return e.key; }
    }).join(', ')}`);

    const promotedSet = new Set(promotedEntries.map(entry => entry.key));
    const preferredEntries = list.filter(entry => entry.key === preferredAdapter);
    const restEntries = list.filter(entry => entry.key !== preferredAdapter && !promotedSet.has(entry.key));
    return [
      ...preferredEntries,
      ...promotedEntries,
      ...restEntries,
    ];
  }

  async _generateWithAdapterIsolation(entry, prompt, adapterOptions = {}) {
    const { beforeRun, afterRun, onRunError, ...generateOptions } = adapterOptions || {};
    const run = async () => {
      if (typeof beforeRun === 'function') {
        const precheck = await beforeRun();
        if (precheck && precheck.skip) {
          return {
            success: false,
            error: precheck.error || 'adapter skipped',
            errorType: precheck.errorType || 'unavailable',
            statusCode: 0,
            provider: entry.adapter.getStatus().name,
            adapter: entry.key,
            gatewaySkipFastFail: true,
            attempts: [],
          };
        }
      }
      try {
        const output = await entry.adapter.generate(prompt, generateOptions);
        if (typeof afterRun === 'function') {
          try { await afterRun(output); } catch { /* best effort */ }
        }
        return output;
      } catch (err) {
        if (typeof onRunError === 'function') {
          try { await onRunError(err); } catch { /* best effort */ }
        }
        throw err;
      }
    };
    if (!this._shouldSerializeAdapter(entry.key)) {
      return run();
    }

    const queueKey = `adapter:${entry.key}`;
    const pendingBefore = typeof this._adapterQueue.getPending === 'function'
      ? this._adapterQueue.getPending(queueKey)
      : 0;
    const statusName = (() => {
      try {
        return entry.adapter.getStatus().name || entry.key;
      } catch {
        return entry.key;
      }
    })();
    const emitQueueStatus = (text) => {
      if (!text || typeof adapterOptions.onChunk !== 'function') return;
      try {
        adapterOptions.onChunk({ type: 'status', text: String(text) });
      } catch { /* best effort */ }
    };

    let queuePulse = null;
    let queuedAt = 0;
    if (pendingBefore > 0) {
      queuedAt = Date.now();
      emitQueueStatus(`Adapter queueing: ${statusName} (${pendingBefore + 1} in line)`);
      const pulseMs = Math.max(
        1500,
        parseInt(process.env.GATEWAY_QUEUE_STATUS_PULSE_MS || '3000', 10) || 3000
      );
      let lastNoticeSec = -1;
      queuePulse = setInterval(() => {
        const waitedSec = Math.floor((Date.now() - queuedAt) / 1000);
        if (waitedSec <= lastNoticeSec) return;
        lastNoticeSec = waitedSec;
        emitQueueStatus(`Waiting for adapter slot: ${statusName} ${waitedSec}s`);
      }, pulseMs);
      queuePulse.unref?.();
    }

    const runWhenReady = async () => {
      if (queuePulse) {
        clearInterval(queuePulse);
        queuePulse = null;
        const waitedSec = Math.max(1, Math.round((Date.now() - queuedAt) / 1000));
        emitQueueStatus(`Adapter slot acquired: ${statusName} (+${waitedSec}s)`);
      }
      return run();
    };

    let queueResult;
    try {
      queueResult = await this._adapterQueue(queueKey, runWhenReady);
    } finally {
      if (queuePulse) {
        clearInterval(queuePulse);
        queuePulse = null;
      }
    }

    if (typeof queueResult === 'undefined') {
      throw new Error(`adapter ${entry.key} queue timeout`);
    }
    return queueResult;
  }

  /**
   * Force reconnect a specific adapter — clears circuit breaker, failure cache,
   * re-enables it, and re-detects availability.
   * Use after account switch, environment cleanup, or machine code update.
   * @param {string} adapterKey
   * @returns {Promise<{success: boolean, adapter: string, available: boolean, error?: string}>}
   */
  async forceReconnect(adapterKey) {
    const entry = this._adapters.find(a => a.key === adapterKey);
    if (!entry) {
      return { success: false, adapter: adapterKey, available: false, error: 'Adapter not found' };
    }

    // Clear all failure state
    await this._clearAdapterFailure(adapterKey);
    entry.enabled = true;

    // Call adapter's manualRefresh if available (e.g. kiroAdapter clears token cache)
    if (typeof entry.adapter.manualRefresh === 'function') {
      try { entry.adapter.manualRefresh(); } catch { /* ignore */ }
    }

    // Re-detect
    try {
      if (entry.adapter.detectAsync) {
        entry.available = await entry.adapter.detectAsync(true);
      } else {
        entry.available = entry.adapter.detect(true);
      }
    } catch {
      entry.available = false;
    }

    return {
      success: entry.available,
      adapter: adapterKey,
      available: entry.available,
    };
  }

  /**
   * Re-detect all adapters (called periodically or after failures).
   * Useful when IDEs update and new auth tokens become available.
   */
  async refreshAdapters() {
    for (const entry of this._adapters) {
      if (!entry.enabled) continue;
      try {
        if (entry.adapter.detectAsync) {
          entry.available = await entry.adapter.detectAsync(true);
        } else {
          entry.available = entry.adapter.detect(true); // force refresh
        }
      } catch {
        entry.available = false;
      }
    }
    this._lastRefreshTime = Date.now();
  }

  /**
   * Anti-ban: enforce minimum request interval with jitter (per adapter).
   * Uses token bucket algorithm — max 10 requests per minute per adapter.
   * Skips rate limiting for local adapters (e.g. Ollama).
   * @param {string} adapterKey
   * @param {object} [options] - { onWait: (key, ms) => void }
   */
  async _enforceRateLimit(adapterKey, options = {}) {
    // Skip rate limiting for local adapters
    if (this._localAdapters.has(adapterKey)) return;
    const runtimeIsKhy = String(process.env.KHY_RUNTIME_MODE || '').trim().toLowerCase() === 'khy';
    const fastInteractive = !!options.fastInteractive
      || (runtimeIsKhy && String(process.env.KHY_GATEWAY_FAST_RATE_LIMIT || 'true').toLowerCase() !== 'false');
    const rateLimitJitterMaxMs = _parseMs(
      options.rateLimitJitterMaxMs
      ?? process.env.GATEWAY_RATE_LIMIT_JITTER_MAX_MS
      ?? (fastInteractive ? '600' : '2000'),
      fastInteractive ? 600 : 2000,
      0
    );
    const maxRateLimitWaitMs = _parseMs(
      options.maxRateLimitWaitMs
      ?? process.env.GATEWAY_RATE_LIMIT_MAX_WAIT_MS
      ?? (fastInteractive ? '2500' : '120000'),
      fastInteractive ? 2500 : 120000,
      100
    );

    // Use distributed rate limiter (Redis or in-memory fallback)
    const result = await this._distributedLimiter.consume(adapterKey);

    if (!result.allowed) {
      // Rate limited — wait until window reopens + random jitter
      const waitMs = Number(result.retryAfterMs || 0) + Math.random() * rateLimitJitterMaxMs;
      const actualWait = Math.max(80, Math.min(maxRateLimitWaitMs, waitMs));
      if (actualWait > 2000 && options.onWait) {
        options.onWait(adapterKey, actualWait);
      }
      await new Promise(r => setTimeout(r, actualWait));
    }

    // Per-adapter exponential backoff on consecutive failures (capped at 10s for fast failover)
    const failures = this._adapterFailures[adapterKey] || 0;
    if (failures > 0) {
      const attemptIndex = Math.max(0, parseInt(options.attemptIndex, 10) || 0);
      const allowFirstAttemptBackoff = String(
        process.env.GATEWAY_FAILURE_BACKOFF_ON_FIRST_ATTEMPT || 'false'
      ).toLowerCase() === 'true';
      if (attemptIndex === 0 && !allowFirstAttemptBackoff) return;
      const baseFailureBackoffMs = _parseMs(
        options.baseFailureBackoffMs
        ?? process.env.GATEWAY_FAILURE_BACKOFF_BASE_MS
        ?? (fastInteractive ? '250' : '1000'),
        fastInteractive ? 250 : 1000,
        50
      );
      const maxFailureBackoffMs = _parseMs(
        options.maxFailureBackoffMs
        ?? process.env.GATEWAY_FAILURE_BACKOFF_CAP_MS
        ?? (fastInteractive ? '1800' : '10000'),
        fastInteractive ? 1800 : 10000,
        baseFailureBackoffMs
      );
      const backoffMs = Math.min(maxFailureBackoffMs, baseFailureBackoffMs * Math.pow(2, failures - 1));
      const jitter = Math.random() * backoffMs * 0.3;
      const totalWait = backoffMs + jitter;
      if (totalWait > 2000 && options.onWait) {
        options.onWait(adapterKey, totalWait);
      }
      await new Promise(r => setTimeout(r, totalWait));
    }
  }

  /**
   * Initialize the gateway: detect available adapters.
   * Safe to call multiple times (idempotent after first, race-safe).
   */
  async init() {
    if (this._initialized) return;
    if (this._initPromise) return this._initPromise;
    this._initPromise = this._doInit().catch((err) => {
      this._initPromise = null;
      throw err;
    });
    return this._initPromise;
  }

  async _doInit() {

    // Initialize Redis-backed health store (gracefully degrades to memory)
    await this._healthStore.init();

    // Periodic cleanup to prevent memory leaks from stale adapter data
    if (this._cleanupInterval) {
      clearInterval(this._cleanupInterval);
      this._cleanupInterval = null;
    }
    this._cleanupInterval = setInterval(() => this._cleanupStaleData(), 5 * 60 * 1000);
    if (this._cleanupInterval.unref) this._cleanupInterval.unref();
    this._startCooldownSelfHealTicker();

    // Respect environment toggles
    if (process.env.GATEWAY_CLI_ENABLED === 'false') {
      this._adapters.find(a => a.key === 'cli').enabled = false;
    }
    if (process.env.GATEWAY_OLLAMA_ENABLED === 'false') {
      this._adapters.find(a => a.key === 'ollama').enabled = false;
    }
    if (process.env.GATEWAY_RELAY_ENABLED === 'false') {
      this._adapters.find(a => a.key === 'relay').enabled = false;
    }

    // Respect IDE adapter toggles
    for (const ideKey of ['kiro', 'cursor', 'trae', 'claude', 'codex', 'windsurf', 'vscode', 'warp', 'cursor2api']) {
      const envKey = `GATEWAY_${ideKey.toUpperCase()}_ENABLED`;
      if (process.env[envKey] === 'false') {
        const entry = this._adapters.find(a => a.key === ideKey);
        if (entry) entry.enabled = false;
      }
    }

    // Run detection on all enabled adapters IN PARALLEL with timeout protection
    const INIT_TIMEOUT_MS = _parseMs(process.env.GATEWAY_INIT_TIMEOUT_MS || '8000', 8000, 3000);
    const detectionJobs = this._adapters
      .filter(e => e.enabled)
      .map(async (entry) => {
        let timerId = null;
        try {
          const detect = entry.adapter.detectAsync
            ? entry.adapter.detectAsync(true)
            : Promise.resolve(entry.adapter.detect(true));
          const timer = new Promise((_, rej) => {
            timerId = setTimeout(() => rej(new Error('detect timeout')), INIT_TIMEOUT_MS);
          });
          entry.available = await Promise.race([detect, timer]);
        } catch {
          entry.available = false;
        } finally {
          if (timerId) clearTimeout(timerId);
        }
      });
    await Promise.all(detectionJobs);

    // Start background model refresh timer (default 5 min)
    const MODEL_REFRESH_INTERVAL_MS = Math.max(60000,
      parseInt(process.env.MODEL_REFRESH_INTERVAL_MS || '300000', 10) || 300000);
    if (this._modelRefreshTimer) clearInterval(this._modelRefreshTimer);
    this._modelRefreshTimer = setInterval(() => this._refreshModelsBackground(), MODEL_REFRESH_INTERVAL_MS);
    if (this._modelRefreshTimer.unref) this._modelRefreshTimer.unref();

    this._initialized = true;
    this._initPromise = null;

    // Invalidate selfProfile cache so dynamic adapter counts refresh
    try { require('../selfProfile').invalidateStaticCache(); } catch { /* optional */ }

    // Start channel health broadcaster with detected adapter keys
    const adapterKeys = this._adapters.filter(a => a.enabled).map(a => a.key);
    this._healthBroadcaster.setAdapterKeys(adapterKeys);
    this._healthBroadcaster.start();
  }

  /**
   * Background model list refresh — keeps adapter model caches up to date.
   * Runs periodically so CLI `/model` always shows latest models.
   */
  async _refreshModelsBackground() {
    for (const entry of this._adapters) {
      if (!entry.enabled || !entry.available) continue;
      if (typeof entry.adapter.listModels !== 'function') continue;
      try { await entry.adapter.listModels(); } catch { /* ignore */ }
    }
  }

  /**
   * Generate a response by cascading through adapters.
   * Returns the same shape as MultiFreeService.generateResponse().
   */
  async generate(prompt, options = {}) {
    if (!this._initialized) await this.init();

    // ── Request deduplication ─────────────────────────────────────────────
    const dedupFp = this._dedup.fingerprint({
      userId: options.userId || options.sessionId || 'anon',
      model: options.model || 'auto',
      prompt,
    });
    const isNewRequest = await this._dedup.tryAcquire(dedupFp);
    if (!isNewRequest) {
      const cached = await this._dedup.getCached(dedupFp);
      if (cached) {
        return { ...cached, deduplicated: true };
      }
      // Lock exists but no cached response yet — first request still in flight.
      // Fall through and let this request proceed (the lock holder will store the result).
    }

    const startTime = Date.now();
    const promptSize = String(prompt || '').length;
    const explicitTaskScale = String(options.taskScale || '').trim().toLowerCase();
    const isLargeTask = explicitTaskScale === 'large'
      || (explicitTaskScale !== 'small' && promptSize >= 1200);
    const isSmallTask = explicitTaskScale === 'small'
      || (explicitTaskScale !== 'large' && promptSize > 0 && promptSize <= 220);
    const isKhyInteractiveRuntime = String(process.env.KHY_RUNTIME_MODE || '').trim().toLowerCase() === 'khy';
    const fastInteractiveRateLimit = isKhyInteractiveRuntime
      && isSmallTask
      && String(process.env.KHY_GATEWAY_FAST_RATE_LIMIT || 'true').toLowerCase() !== 'false';
    // Normalize images once at the gateway entry — all downstream adapters
    // receive a guaranteed { base64, mimeType, dataUrl, url? }[] shape.
    let hasImageInput = Array.isArray(options.images) && options.images.length > 0;
    if (hasImageInput) {
      const { normalizeImages } = require('./adapters/_imageCompat');
      options.images = normalizeImages(options.images);
      hasImageInput = options.images.length > 0;
    }
    const externalAbortSignal = options.abortSignal || null;
    const getAbortReason = () => normalizeAbortReason(externalAbortSignal ? externalAbortSignal.reason : 'aborted');
    const throwIfCancelled = () => throwIfAborted(externalAbortSignal);
    const buildEarlyCancelledResult = (reasonText = getAbortReason()) => ({
      success: false,
      content: `请求已取消: ${reasonText}`,
      provider: 'none',
      adapter: 'none',
      attempts: [],
      errorType: 'cancelled',
      cancelled: true,
    });
    const _statusDedupMs = (() => {
      const defaultMs = isKhyInteractiveRuntime ? 700 : 1500;
      const raw = process.env.GATEWAY_STATUS_DEDUP_MS || process.env.KHY_AI_STATUS_DEDUP_MS || String(defaultMs);
      const parsed = Number.parseInt(String(raw).trim(), 10);
      if (!Number.isFinite(parsed) || parsed < 200) return defaultMs;
      return parsed;
    })();
    const _activityPulseMs = (() => {
      const defaultMs = isKhyInteractiveRuntime ? 4000 : 10000;
      const raw = process.env.GATEWAY_ACTIVITY_PULSE_MS || process.env.KHY_AI_ACTIVITY_PULSE_MS || String(defaultMs);
      const parsed = Number.parseInt(String(raw).trim(), 10);
      if (!Number.isFinite(parsed) || parsed < 2000) return defaultMs;
      return parsed;
    })();
    let _lastStatusText = '';
    let _lastStatusAt = 0;
    let _lastActivityText = '';
    let _lastActivityAt = 0;
    const emitStatus = (text) => {
      if (externalAbortSignal && externalAbortSignal.aborted) return;
      try {
        if (typeof options.onChunk === 'function' && text) {
          const normalized = String(text).replace(/\s+/g, ' ').trim();
          if (!normalized) return;
          const now = Date.now();
          if (normalized === _lastStatusText && (now - _lastStatusAt) < _statusDedupMs) return;
          _lastStatusText = normalized;
          _lastStatusAt = now;
          options.onChunk({ type: 'status', text: normalized });
        }
      } catch { /* best effort */ }
    };
    const emitActivity = (text, force = false) => {
      if (externalAbortSignal && externalAbortSignal.aborted) return;
      try {
        if (typeof options.onChunk !== 'function' || !text) return;
        const normalized = String(text).replace(/\s+/g, ' ').trim();
        if (!normalized) return;
        const now = Date.now();
        if (!force && normalized === _lastActivityText && (now - _lastActivityAt) < _activityPulseMs) return;
        _lastActivityText = normalized;
        _lastActivityAt = now;
        options.onChunk({ type: 'status', text: normalized });
      } catch { /* best effort */ }
    };
    const startAdapterPulse = (adapterName, onPulse = null) => {
      const startedAt = Date.now();
      let pulseTimer = null;
      const tick = () => {
        const elapsedSec = Math.max(1, Math.floor((Date.now() - startedAt) / 1000));
        if (typeof onPulse === 'function') {
          try { onPulse(); } catch { /* best effort */ }
        }
        emitActivity(`${adapterName} 处理中（${elapsedSec}s）`);
      };
      pulseTimer = setInterval(tick, _activityPulseMs);
      pulseTimer.unref?.();
      return () => {
        if (pulseTimer) {
          clearInterval(pulseTimer);
          pulseTimer = null;
        }
      };
    };
    const createAdapterIdleTimeout = (adapterKey, timeoutMs, attemptAbort) => {
      const resolvedTimeoutMs = Math.max(1000, _parseMs(timeoutMs, 60000, 1000));
      let lastActivityAt = Date.now();
      let stopped = false;
      let timer = null;
      const reason = `adapter ${adapterKey} idle timeout (${resolvedTimeoutMs}ms)`;
      const timeoutPromise = new Promise((_, reject) => {
        timer = setInterval(() => {
          if (stopped) return;
          if ((Date.now() - lastActivityAt) < resolvedTimeoutMs) return;
          stopped = true;
          if (timer) {
            clearInterval(timer);
            timer = null;
          }
          try { attemptAbort.abort(reason); } catch { /* best effort */ }
          reject(new Error(reason));
        }, 1000);
        timer.unref?.();
      });
      return {
        timeoutPromise,
        touch: () => {
          if (!stopped) lastActivityAt = Date.now();
        },
        stop: () => {
          stopped = true;
          if (timer) {
            clearInterval(timer);
            timer = null;
          }
        },
      };
    };
    if (externalAbortSignal && externalAbortSignal.aborted) {
      if (_modelSwitch) _modelSwitch.generationCompleted();
      return buildEarlyCancelledResult(getAbortReason());
    }

    // Live model switching: apply active model if no explicit model specified
    if (_modelSwitch && !options.model) {
      const activeModel = _modelSwitch.getActiveModel();
      if (activeModel && activeModel !== 'auto') {
        options.model = activeModel;
      }
    }
    if (_modelSwitch) _modelSwitch.generationStarted();

    // Diagnostic trace context
    options._diagTraceId = options._diagTraceId || genDiagTraceId();
    if (_traceAudit) {
      try {
        if (options.sessionId) _traceAudit.attachTrace(options._diagTraceId, options.sessionId);
        _traceAudit.logEvent('llm.request', {
          requestedModel: options.model || 'auto',
          preferredAdapter: options.preferredAdapter || options.adapter || 'auto',
          prompt,
          hasTools: Array.isArray(options.tools) && options.tools.length > 0,
          messagesCount: Array.isArray(options.messages) ? options.messages.length : 0,
          strictPreferred: options.strictPreferred !== false,
        }, {
          sessionId: options.sessionId || null,
          traceId: options._diagTraceId,
          source: 'ai-gateway',
          visibility: 'internal',
        });
      } catch { /* non-critical */ }
    }
    diagnostics.emitModelRequest(
      options.model || 'auto',
      options.adapter || 'auto',
      null, // token estimate not available here
      { traceId: options._diagTraceId }
    );

    // AI Monitor: start trace
    const monitor = require('../aiMonitor');
    const traceId = monitor.startTrace({ prompt, model: options.model, adapter: options.adapter, options });
    let traceClosed = false;
    let generationCompleted = false;
    const endTraceOnce = (response, meta = {}) => {
      if (traceClosed) return;
      traceClosed = true;
      monitor.endTrace(traceId, response || null, meta || {});
    };
    const completeGenerationOnce = () => {
      if (generationCompleted) return;
      generationCompleted = true;
      if (_modelSwitch) _modelSwitch.generationCompleted();
    };
    const finishResult = (result, { response = null, error = null } = {}) => {
      const durationMs = Date.now() - startTime;
      if (_traceAudit) {
        try {
          _traceAudit.logEvent('llm.response', {
            success: !!result?.success,
            model: result?.model || response?.model || options.model || 'unknown',
            provider: result?.provider || response?.provider || 'unknown',
            adapter: result?.adapter || result?.actualAdapter || options?.preferredAdapter || null,
            errorType: result?.errorType || null,
            error: result?.error || error || null,
            contentPreview: result?.content || response?.content || null,
            attempts: Array.isArray(result?.attempts) ? result.attempts : [],
            tokenUsage: result?.tokenUsage || response?.tokens || null,
            durationMs,
          }, {
            sessionId: options.sessionId || null,
            traceId: options._diagTraceId || null,
            source: 'ai-gateway',
            visibility: 'internal',
          });
        } catch { /* non-critical */ }
      }
      if (response) {
        endTraceOnce(response, { tokens: response.tokens || response.tokenUsage || null });
      } else if (error) {
        endTraceOnce(null, { error });
      } else {
        endTraceOnce(null, { error: 'Gateway finished without response' });
      }
      completeGenerationOnce();
      // Cache successful result for dedup
      if (result && result.success && isNewRequest) {
        this._dedup.storeResponse(dedupFp, {
          success: result.success,
          content: result.content,
          thinking: result.thinking || null,
          provider: result.provider,
          adapter: result.adapter,
        }).catch(() => {});
      }
      return result;
    };
    if (externalAbortSignal && externalAbortSignal.aborted) {
      return finishResult(
        buildEarlyCancelledResult(getAbortReason()),
        { error: `Cancelled: ${getAbortReason()}` }
      );
    }

    // Plugin Chain: onBeforeRequest
    const pluginChain = require('./pluginChain');
    let pluginCtx;
    try {
      pluginCtx = await pluginChain.executeBeforeRequest({ prompt, options, adapter: null, cancelled: false });
    } catch (pluginErr) {
      return finishResult({
        success: false,
        content: `Gateway plugin error: ${pluginErr.message || 'beforeRequest failed'}`,
        provider: 'plugin',
        adapter: 'plugin',
        attempts: [],
        errorType: 'plugin_error',
      }, { error: `Gateway plugin beforeRequest error: ${pluginErr.message || 'unknown'}` });
    }
    if (externalAbortSignal && externalAbortSignal.aborted) {
      return finishResult(
        buildEarlyCancelledResult(getAbortReason()),
        { error: `Cancelled: ${getAbortReason()}` }
      );
    }
    if (pluginCtx.cancelled) {
      return finishResult(
        { success: false, content: 'Request cancelled by gateway plugin', provider: 'plugin', attempts: [] },
        { error: 'Cancelled by plugin' }
      );
    }
    prompt = pluginCtx.prompt || prompt;
    options = pluginCtx.options || options;

    // Periodic adapter re-detection (every 30 minutes)
    const REFRESH_INTERVAL = 30 * 60 * 1000;
    if (Date.now() - this._lastRefreshTime > REFRESH_INTERVAL) {
      const nonBlockingRefresh = isKhyInteractiveRuntime
        && isSmallTask
        && String(process.env.KHY_GATEWAY_REFRESH_NON_BLOCKING || 'true').toLowerCase() !== 'false';
      if (nonBlockingRefresh) {
        this._lastRefreshTime = Date.now();
        emitStatus('通道状态刷新已切换为后台执行（本次请求不等待）');
        this.refreshAdapters().catch(() => {});
      } else {
        await this.refreshAdapters();
      }
      if (externalAbortSignal && externalAbortSignal.aborted) {
        return finishResult(
          buildEarlyCancelledResult(getAbortReason()),
          { error: `Cancelled: ${getAbortReason()}` }
        );
      }
    }

    const allAttempts = [];
    const preferredAdapterFromOptions = options.preferredAdapter !== undefined;
    const preferredAdapterInput = String(
      preferredAdapterFromOptions
        ? options.preferredAdapter
        : (process.env.GATEWAY_PREFERRED_ADAPTER || '')
    ).trim();
    const preferredAdapterLower = preferredAdapterInput.toLowerCase();
    let preferredAdapter = '';
    if (preferredAdapterLower) {
      if (preferredAdapterLower === 'localllm') {
        preferredAdapter = 'localLLM';
      } else {
        const matched = this._adapters.find(a => String(a.key || '').toLowerCase() === preferredAdapterLower);
        // Keep unknown preferred adapter values visible so strict mode can
        // fail fast with a clear "not registered" error instead of silently
        // dropping preference and falling through to other adapters.
        preferredAdapter = matched ? matched.key : preferredAdapterLower;
      }
    }
    const preferredStrictRaw = options.preferredStrict !== undefined
      ? options.preferredStrict
      : process.env.GATEWAY_PREFERRED_STRICT;
    const strictPreferredByEnv = !!(
      preferredAdapter &&
      preferredAdapter !== 'auto' &&
      String(preferredStrictRaw).toLowerCase() !== 'false'
    );
    let strictPreferredOnly = options.strictPreferred === false ? false : strictPreferredByEnv;
    let firstTriedAdapter = null;
    let failedPreferredReason = null;
    const defaultTotalAttemptsBudget = isLargeTask ? 18 : (isSmallTask ? 6 : 10);
    const baseMaxTotalAttempts = _parsePositiveInt(
      options.maxTotalAttempts ?? process.env.GATEWAY_MAX_TOTAL_ATTEMPTS ?? String(defaultTotalAttemptsBudget),
      defaultTotalAttemptsBudget,
      1,
      64
    );
    const defaultRetryDelayBudgetMs = isLargeTask ? 60000 : (isSmallTask ? 8000 : 20000);
    const baseMaxRetryDelayBudgetMs = _parseMs(
      options.maxRetryDelayBudgetMs ?? process.env.GATEWAY_MAX_RETRY_DELAY_BUDGET_MS ?? String(defaultRetryDelayBudgetMs),
      defaultRetryDelayBudgetMs,
      1000
    );
    let maxTotalAttempts = baseMaxTotalAttempts;
    let maxRetryDelayBudgetMs = baseMaxRetryDelayBudgetMs;
    const retryBudgetAutoBoostEnabled = (() => {
      if (options.retryBudgetJitterAutoBoost !== undefined) {
        return !!options.retryBudgetJitterAutoBoost;
      }
      const fallback = isKhyInteractiveRuntime ? 'true' : 'false';
      const raw = String(process.env.GATEWAY_RETRY_BUDGET_JITTER_AUTO_BOOST || fallback).trim().toLowerCase();
      return !['0', 'false', 'off', 'no'].includes(raw);
    })();
    const retryBudgetBoostExtraAttemptsDefault = isLargeTask ? 4 : (isSmallTask ? 2 : 3);
    const retryBudgetBoostExtraAttempts = _parsePositiveInt(
      options.retryBudgetJitterExtraAttempts ?? process.env.GATEWAY_RETRY_BUDGET_JITTER_EXTRA_ATTEMPTS ?? String(retryBudgetBoostExtraAttemptsDefault),
      retryBudgetBoostExtraAttemptsDefault,
      1,
      24
    );
    const retryBudgetBoostExtraDelayMsDefault = isLargeTask ? 20000 : (isSmallTask ? 6000 : 12000);
    const retryBudgetBoostExtraDelayMs = _parseMs(
      options.retryBudgetJitterExtraDelayMs ?? process.env.GATEWAY_RETRY_BUDGET_JITTER_EXTRA_DELAY_MS ?? String(retryBudgetBoostExtraDelayMsDefault),
      retryBudgetBoostExtraDelayMsDefault,
      1000
    );
    let retryBudgetBoostApplied = false;
    const _isNetworkJitterLikeFailure = (errorType, errorMessage, statusCode) => {
      const type = String(errorType || '').trim().toLowerCase();
      const msg = String(errorMessage || '').toLowerCase();
      const statusNum = Number(statusCode || 0);
      if ([502, 503, 504, 522, 524, 525, 526].includes(statusNum)) return true;
      if (/client network socket disconnected before secure tls connection was established/.test(msg)) return true;
      if (/econnreset|socket hang up|eai_again|enotfound|tls|ssl|handshake|proxy error|upstream connect error|network .* disconnected|connection reset|temporarily unavailable/.test(msg)) {
        return true;
      }
      if ((type === 'network' || type === 'timeout') && /(socket|network|connection|tls|ssl|dns|proxy|upstream|disconnect|timeout)/.test(msg)) {
        return true;
      }
      return false;
    };
    const _maybeBoostRetryBudgetForNetworkJitter = (errorType, errorMessage, statusCode, adapterKey = '') => {
      if (!retryBudgetAutoBoostEnabled || retryBudgetBoostApplied) return false;
      if (strictPreferredOnly && preferredAdapter && adapterKey === preferredAdapter) return false;
      if (!_isNetworkJitterLikeFailure(errorType, errorMessage, statusCode)) return false;
      const prevAttempts = maxTotalAttempts;
      const prevRetryDelay = maxRetryDelayBudgetMs;
      maxTotalAttempts = Math.max(prevAttempts, Math.min(96, prevAttempts + retryBudgetBoostExtraAttempts));
      maxRetryDelayBudgetMs = Math.max(prevRetryDelay, Math.min(240000, prevRetryDelay + retryBudgetBoostExtraDelayMs));
      retryBudgetBoostApplied = true;
      emitStatus(
        `检测到网络抖动，本次请求临时扩展重试预算: attempts ${prevAttempts}->${maxTotalAttempts}, retry-delay ${prevRetryDelay}ms->${maxRetryDelayBudgetMs}ms`
      );
      return true;
    };
    let totalAdapterAttempts = 0;
    let totalRetryDelayMs = 0;
    const buildCancelledResult = (reasonText = getAbortReason()) => ({
      success: false,
      content: `请求已取消: ${reasonText}`,
      provider: 'none',
      adapter: 'none',
      preferredAdapter,
      actualAdapter: firstTriedAdapter,
      fallbackReason: failedPreferredReason || null,
      attempts: allAttempts,
      errorType: 'cancelled',
      cancelled: true,
    });
    const buildRetryBudgetExceededContent = (reasonText) => {
      const lines = [
        `请求重试预算已用尽: ${reasonText}`,
        '',
        '建议下一步:',
        '  1) 运行 `khy gateway status` 查看各通道状态',
        '  2) 拆分任务后重试，减少单次请求跨度',
        '  3) 如确需更多预算，设置 `GATEWAY_MAX_TOTAL_ATTEMPTS` / `GATEWAY_MAX_RETRY_DELAY_BUDGET_MS`',
      ];
      if (retryBudgetBoostApplied) {
        lines.push(`  4) 本次已自动扩展网络抖动预算（attempts ${baseMaxTotalAttempts}->${maxTotalAttempts}, delay ${baseMaxRetryDelayBudgetMs}ms->${maxRetryDelayBudgetMs}ms）`);
      }
      return lines.join('\n');
    };
    const failRetryBudgetExceeded = (reasonText) => finishResult({
      success: false,
      content: _prependFailureReason(buildRetryBudgetExceededContent(reasonText), allAttempts, 8),
      provider: 'none',
      adapter: 'none',
      preferredAdapter,
      actualAdapter: firstTriedAdapter,
      fallbackReason: reasonText,
      attempts: allAttempts,
      errorType: 'retry_budget_exceeded',
    }, { error: reasonText });
    const reserveAttemptBudget = () => {
      const nextAttemptCount = totalAdapterAttempts + 1;
      if (nextAttemptCount > maxTotalAttempts) {
        const reason = `总尝试次数超限 (${nextAttemptCount}/${maxTotalAttempts})`;
        emitStatus(`停止重试: ${reason}`);
        return failRetryBudgetExceeded(reason);
      }
      totalAdapterAttempts = nextAttemptCount;
      return null;
    };
    const releaseAttemptBudget = () => {
      if (totalAdapterAttempts > 0) totalAdapterAttempts -= 1;
    };
    const waitWithRetryDelayBudget = async (delayMs) => {
      const waitMs = Math.max(0, Math.floor(Number(delayMs) || 0));
      if (waitMs <= 0) return null;
      const nextDelay = totalRetryDelayMs + waitMs;
      if (nextDelay > maxRetryDelayBudgetMs) {
        const reason = `重试等待预算超限 (${nextDelay}ms/${maxRetryDelayBudgetMs}ms)`;
        emitStatus(`停止重试: ${reason}`);
        return failRetryBudgetExceeded(reason);
      }
      totalRetryDelayMs = nextDelay;
      await new Promise((resolve) => setTimeout(resolve, waitMs));
      return null;
    };

    // Use preferred adapter/model from env if set
    const preferredModel = String(
      options.preferredModel !== undefined
        ? options.preferredModel
        : (process.env.GATEWAY_PREFERRED_MODEL || '')
    ).trim();

    const allowStrictAutoRelaxByEnv = String(
      process.env.GATEWAY_STRICT_AUTO_RELAX_ON_PROCESS || 'true'
    ).toLowerCase() !== 'false';
    const strictAutoRelaxForLargeTasks = String(
      process.env.GATEWAY_STRICT_AUTO_RELAX_LARGE_TASKS || 'true'
    ).toLowerCase() !== 'false';
    const allowStrictAutoRelaxOnProcess = allowStrictAutoRelaxByEnv
      && (!isLargeTask || strictAutoRelaxForLargeTasks);
    const strictAutoRelaxMinFailures = Math.max(
      1,
      parseInt(process.env.GATEWAY_STRICT_AUTO_RELAX_MIN_FAILURES || '1', 10) || 1
    );
    if (
      strictPreferredOnly &&
      allowStrictAutoRelaxOnProcess &&
      preferredAdapter &&
      preferredAdapter !== 'auto' &&
      _isProcessSensitiveAdapter(preferredAdapter)
    ) {
      const recentPreferredFail = await this._getRecentFastFail(preferredAdapter);
      const recentIsProcess = !!(recentPreferredFail && recentPreferredFail.errorType === 'process');
      const preferredFailureCount = Number(this._adapterFailures[preferredAdapter] || 0);
      if (recentIsProcess || preferredFailureCount >= strictAutoRelaxMinFailures) {
        strictPreferredOnly = false;
        emitStatus(`检测到 ${preferredAdapter} 通道连续 process 异常，本次请求临时放宽 strict 并启用兜底通道`);
      }
    }
    const _shouldRelaxStrictPreferredOnFailure = (entryKey, errorType, errorMessage) => {
      if (!strictPreferredOnly) return false;
      if (!allowStrictAutoRelaxOnProcess) return false;
      if (!preferredAdapter || preferredAdapter === 'auto') return false;
      if (entryKey !== preferredAdapter) return false;
      if (!_isProcessSensitiveAdapter(preferredAdapter)) return false;
      const normalizedType = String(errorType || '').trim().toLowerCase();
      const msg = String(errorMessage || '').toLowerCase();
      if (normalizedType === 'process' || normalizedType === 'timeout' || normalizedType === 'network') return true;
      if (/adapter\s+\S+\s+queue timeout|queue task timeout/.test(msg)) return true;
      if (/stream idle timeout|socket hang up|channel closed|reconnecting/.test(msg)) return true;
      return false;
    };
    const _maybeRelaxStrictPreferredOnFailure = (entryKey, errorType, errorMessage) => {
      if (!_shouldRelaxStrictPreferredOnFailure(entryKey, errorType, errorMessage)) return false;
      strictPreferredOnly = false;
      const normalizedType = String(errorType || '').trim().toLowerCase();
      const msg = String(errorMessage || '').toLowerCase();
      const reasonLabel = /adapter\s+\S+\s+queue timeout|queue task timeout/.test(msg)
        ? '队列异常'
        : (normalizedType === 'timeout'
          ? '超时异常'
          : (normalizedType === 'network' ? '网络异常' : 'process 异常'));
      emitStatus(`检测到 ${entryKey} 通道${reasonLabel}，本次请求临时放宽 strict 并启用兜底通道`);
      return true;
    };

    // Auto mode: select best adapter for this task
    let orderedAdapters = this._adapters;
    if (preferredAdapter === 'auto') {
      const autoResult = this.autoSelectModel(options.taskType || 'conversation');
      if (autoResult.adapter !== 'relay') {
        options = { ...options, model: autoResult.model || options.model };
        // Reorder to try auto-selected first
        orderedAdapters = [
          ...this._adapters.filter(a => a.key === autoResult.adapter),
          ...this._adapters.filter(a => a.key !== autoResult.adapter),
        ];
      }
    } else if (preferredAdapter) {
      const preferredModelForAdapter = resolvePreferredModelForAdapter(preferredAdapter, preferredModel);
      if (!options.model && preferredModelForAdapter) {
        options = { ...options, model: preferredModelForAdapter };
      }
      orderedAdapters = [
        ...this._adapters.filter(a => a.key === preferredAdapter),
        ...this._adapters.filter(a => a.key !== preferredAdapter),
      ];
    } else {
      // Habit-based preference: if no env override, use learned preference
      let habitPreferred = null;
      try {
        const { getPreferredModel } = require('../usageHabitService');
        habitPreferred = getPreferredModel('conversation');
      } catch { /* best effort */ }

      if (habitPreferred && habitPreferred.adapter) {
        orderedAdapters = [
          ...this._adapters.filter(a => a.key === habitPreferred.adapter),
          ...this._adapters.filter(a => a.key !== habitPreferred.adapter),
        ];
        if (habitPreferred.model && !options.model) {
          options = { ...options, model: habitPreferred.model };
        }
      }
    }

    orderedAdapters = await this._maybePromoteProcessFailoverAdapters(orderedAdapters, {
      preferredAdapter,
      strictPreferredOnly,
      emitStatus,
    });

    if (hasImageInput) {
      emitStatus('检测到图片输入：保持当前通道，按适配器能力自动处理并兜底');
    }

    if (preferredAdapter && preferredAdapter !== 'auto') {
      emitStatus(`首选通道: ${preferredAdapter}`);
    }
    if (isSmallTask) {
      emitStatus('任务模式: 快速（小任务，优先低延迟）');
    } else if (isLargeTask) {
      emitStatus('任务模式: 稳态（大任务，优先稳定性）');
    }

    const inspectCachedFastFail = async (adapterKey, adapterDisplayName) => {
      const cached = await this._getRecentFastFail(adapterKey);
      if (!cached) return null;
      this._maybeScheduleCooldownSelfHealProbe(adapterKey, cached, {
        emitStatus,
        adapterDisplayName,
        source: 'generate_skip',
      });
      if (cached.remainingMs > 0) {
        emitStatus(`${adapterDisplayName} 重试中（等待冷却窗口，约 ${Math.max(1, Math.ceil(cached.remainingMs / 1000))}s）`);
      }
      const cooldownSuffix = cached.remainingMs > 0
        ? ` (cooldown ${Math.max(1, Math.ceil(cached.remainingMs / 1000))}s)`
        : '';
      const cachedMsg = `recent ${cached.errorType} failure cached: ${cached.error}${cooldownSuffix}`;
      emitStatus(`跳过不稳定通道 ${adapterDisplayName}: ${cachedMsg}`);
      return {
        error: cachedMsg,
        rawError: cached.error,
        errorType: cached.errorType || 'unknown',
      };
    };

    if (strictPreferredOnly && preferredAdapter && preferredAdapter !== 'auto') {
      const preferredEntry = orderedAdapters.find(a => a.key === preferredAdapter);
      if (!preferredEntry) {
        const missingMsg = `preferred adapter "${preferredAdapter}" is not registered`;
        allAttempts.push({
          provider: preferredAdapter,
          adapterKey: preferredAdapter,
          success: false,
          error: missingMsg,
          statusCode: 0,
          errorType: 'unavailable',
        });
        return finishResult({
          success: false,
          content: _prependFailureReason(buildPreferredAdapterRecoveryHint(preferredAdapter, missingMsg), allAttempts, 4),
          provider: 'none',
          adapter: 'none',
          preferredAdapter,
          actualAdapter: firstTriedAdapter,
          fallbackReason: missingMsg,
          attempts: allAttempts,
          errorType: 'unavailable',
        }, { error: missingMsg });
      }
      if (!preferredEntry.enabled) {
        const disabledMsg = `${preferredAdapter} disabled by configuration`;
        allAttempts.push({
          provider: preferredEntry.adapter.getStatus().name,
          adapterKey: preferredAdapter,
          success: false,
          error: disabledMsg,
          statusCode: 0,
          errorType: 'unavailable',
        });
        return finishResult({
          success: false,
          content: _prependFailureReason(buildPreferredAdapterRecoveryHint(preferredAdapter, disabledMsg), allAttempts, 4),
          provider: 'none',
          adapter: 'none',
          preferredAdapter,
          actualAdapter: firstTriedAdapter,
          fallbackReason: disabledMsg,
          attempts: allAttempts,
          errorType: 'unavailable',
        }, { error: disabledMsg });
      }
    }

    for (const entry of orderedAdapters) {
      if (externalAbortSignal && externalAbortSignal.aborted) {
        return finishResult(
          buildCancelledResult(getAbortReason()),
          { error: `Cancelled: ${getAbortReason()}` }
        );
      }
      if (strictPreferredOnly && entry.key !== preferredAdapter) break;
      if (!entry.enabled) continue;
      if (!firstTriedAdapter) firstTriedAdapter = entry.key;
      const adapterDisplayName = entry.adapter.getStatus().name;
      emitStatus(`尝试通道: ${adapterDisplayName}`);
      const allowOllamaOnDemand = entry.key === 'ollama' && preferredAdapter === 'ollama';
      const adapterOptions = {
        ...options,
        model: allowOllamaOnDemand || entry.key === 'ollama'
          ? normalizeModelForAdapter(entry.key, options.model)
          : (preferredAdapter === 'ollama' ? null : normalizeModelForAdapter(entry.key, options.model)),
      };

      // Re-check availability for api adapter (keys might have changed)
      if (entry.key === 'api') {
        entry.available = entry.adapter.detect();
      }

      if (!entry.available && entry.key !== 'relay' && !allowOllamaOnDemand && !options.forceAdapter) {
        emitStatus(`${adapterDisplayName} 不可用，跳过`);
        allAttempts.push({
          provider: adapterDisplayName,
          adapterKey: entry.key,
          success: false,
          error: `${adapterDisplayName} unavailable`,
          statusCode: 0,
          errorType: 'unavailable',
        });
        if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
          failedPreferredReason = `${preferredAdapter} unavailable`;
        }
        if (strictPreferredOnly && entry.key === preferredAdapter) {
          const baseContent = [
            `已选择模型通道不可用: ${preferredAdapter}。`,
            '',
            '建议下一步:',
            '  1) 运行 `khy gateway status` 查看各通道实测状态',
            '  2) 运行 `khy gateway model` 仅选择”可执行”模型',
            '  3) 若仍失败，检查登录状态或网络',
            `  4) 运行 \`khy gateway reconnect ${preferredAdapter}\` 强制重新连接`,
          ].join('\n');
          return finishResult({
            success: false,
            content: _prependFailureReason(baseContent, allAttempts, 6),
            provider: 'none',
            adapter: 'none',
            preferredAdapter,
            actualAdapter: firstTriedAdapter,
            fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} unavailable`,
            attempts: allAttempts,
            errorType: 'unavailable',
          }, { error: failedPreferredReason || `preferred adapter ${preferredAdapter} unavailable` });
        }
        continue;
      }

      const recentFailInfo = await inspectCachedFastFail(entry.key, adapterDisplayName);
      if (recentFailInfo) {
        allAttempts.push({
          provider: adapterDisplayName,
          adapterKey: entry.key,
          success: false,
          error: recentFailInfo.error,
          statusCode: 0,
          errorType: recentFailInfo.errorType,
          virtualSkip: true,
        });
        if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
          failedPreferredReason = recentFailInfo.rawError || recentFailInfo.error;
        }
        if (strictPreferredOnly && entry.key === preferredAdapter) {
          return finishResult({
            success: false,
            content: _prependFailureReason(
              buildPreferredAdapterRecoveryHint(preferredAdapter, recentFailInfo.rawError || recentFailInfo.error),
              allAttempts,
              6
            ),
            provider: 'none',
            adapter: 'none',
            preferredAdapter,
            actualAdapter: firstTriedAdapter,
            fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} failed`,
            attempts: allAttempts,
            errorType: recentFailInfo.errorType || 'unavailable',
          }, { error: failedPreferredReason || `preferred adapter ${preferredAdapter} failed` });
        }
        continue;
      }

      // If user preferred adapter is unavailable/unstable, fail over quickly.
      // Skip anti-ban delay on non-preferred adapters during this failover window.
      const skipRateLimit = !!(preferredAdapter && failedPreferredReason && entry.key !== preferredAdapter);
      const defaultTimeoutByAdapter = {
        claude: 300000,
        codex: 180000,
        cli: 300000,
        localLLM: 120000,
        ollama: 180000,
      };
      let fallbackTimeout = defaultTimeoutByAdapter[entry.key] || 60000;
      if (isSmallTask) {
        const codexSmallTaskCap = _parseMs(
          process.env.GATEWAY_CODEX_SMALL_TASK_TIMEOUT_MS || '120000',
          120000,
          30000
        );
        const defaultGeneralSmallTaskCap = _parseMs(
          process.env.GATEWAY_GENERAL_SMALL_TASK_TIMEOUT_MS
          || process.env.KHY_GENERAL_SMALL_TASK_TIMEOUT_MS
          || '120000',
          120000,
          30000
        );
        const claudeSmallTaskCap = _parseMs(
          process.env.GATEWAY_CLAUDE_SMALL_TASK_TIMEOUT_MS
          || process.env.KHY_CLAUDE_SMALL_TASK_TIMEOUT_MS
          || '90000',
          90000,
          10000
        );
        const cliSmallTaskCap = _parseMs(
          process.env.GATEWAY_CLI_SMALL_TASK_TIMEOUT_MS || String(defaultGeneralSmallTaskCap),
          defaultGeneralSmallTaskCap,
          30000
        );
        const imageSmallTaskCap = _parseMs(
          process.env.GATEWAY_IMAGE_SMALL_TASK_TIMEOUT_MS
          || process.env.KHY_IMAGE_SMALL_TASK_TIMEOUT_MS
          || '120000',
          120000,
          30000
        );
        const localLlmSmallTaskCap = _parseMs(
          process.env.GATEWAY_LOCAL_LLM_SMALL_TASK_TIMEOUT_MS || '90000',
          90000,
          30000
        );
        const ollamaSmallTaskCap = _parseMs(
          process.env.GATEWAY_OLLAMA_SMALL_TASK_TIMEOUT_MS || '180000',
          180000,
          30000
        );
        let fastCap = entry.key === 'localLLM'
          ? localLlmSmallTaskCap
          : (entry.key === 'ollama'
            ? ollamaSmallTaskCap
            : (entry.key === 'codex'
              ? codexSmallTaskCap
              : (entry.key === 'claude'
                ? claudeSmallTaskCap
                : (entry.key === 'cli' ? cliSmallTaskCap : 30000))));

        // Image + execution tasks frequently exceed the generic 30s "small task"
        // cap (e.g. model reasoning + file writes). Relax timeout to avoid false
        // adapter timeout failures in these flows.
        if (hasImageInput) {
          if (entry.key === 'codex') {
            fastCap = Math.max(fastCap, imageSmallTaskCap);
          } else if (entry.key === 'localLLM' || entry.key === 'ollama') {
            fastCap = Math.max(fastCap, 120000);
          } else {
            fastCap = Math.max(fastCap, imageSmallTaskCap);
          }
        }
        fallbackTimeout = Math.min(fallbackTimeout, fastCap);
      } else if (isLargeTask) {
        const largeTaskFloor = _parseMs(
          process.env.GATEWAY_LARGE_TASK_ADAPTER_TIMEOUT_MS
          || process.env.KHY_AI_REQUEST_TIMEOUT_LARGE_MS
          || '900000',
          900000,
          90000
        );
        const steadyFloor = (entry.key === 'localLLM' || entry.key === 'ollama')
          ? Math.max(240000, largeTaskFloor)
          : Math.max(90000, largeTaskFloor);
        fallbackTimeout = Math.max(fallbackTimeout, steadyFloor);
      }
      const PER_ADAPTER_TIMEOUT_MS = this._resolveAdapterTimeoutMs(entry.key, fallbackTimeout);
      const recordFailureEarly = async (rawResult) => {
        if (!rawResult || rawResult.success !== false) return;
        const sc = rawResult.statusCode || 0;
        const errType = rawResult.errorType || classifyError(sc, rawResult.error);
        await this._recordAdapterFailure(entry.key, errType, rawResult.error || 'unknown');
      };
      const recordThrownFailureEarly = async (err, abortSignal = null) => {
        if (!err) return;
        const sc = err.status || err.statusCode || err.response?.status || 0;
        let errorType = classifyError(sc, err.message);
        let errorMessage = err.message || 'unknown';
        if (abortSignal && abortSignal.aborted) {
          const abortReason = normalizeAbortReason(abortSignal.reason);
          if (/idle timeout/i.test(abortReason)) {
            // When gateway-side idle timeout actively aborts the adapter process,
            // downstream bridges may surface a generic "canceled". Keep it as timeout.
            errorType = 'timeout';
            if (!errorMessage || /\bcancel(?:ed|led)\b/i.test(String(errorMessage))) {
              errorMessage = abortReason;
            }
          }
        }
        await this._recordAdapterFailure(entry.key, errorType, errorMessage);
      };

      // API Key Pool integration: for relay/api adapters, try multiple keys
      let poolProvider = null;
      try {
          const pool = require('../apiKeyPool');
          pool.init();
        // Map adapter key to pool provider
        if (entry.key === 'relay_api' || entry.key === 'relay') poolProvider = 'relay';
        else if (entry.key === 'api') poolProvider = _resolveApiPoolProviderForRequest(adapterOptions);
        // Check if pool has keys for this provider
        if (poolProvider && pool.hasAvailableKeys(poolProvider)) {
          // Pool-based multi-key retry loop
          const maxPoolRetries = Math.max(
            1,
            parseInt(process.env.GATEWAY_POOL_MAX_RETRIES || '5', 10) || 5
          );
          const poolStrategy = keySelector.resolveStrategy(poolProvider);
          const attemptedPoolKeyIds = new Set();
          const slots = require('../concurrencySlots');
          for (let pi = 0; pi < maxPoolRetries; pi++) {
            let candidates = typeof pool.listAvailableKeys === 'function'
              ? pool.listAvailableKeys(poolProvider)
              : [];
            if (candidates.length === 0) break;

            const freshCandidates = candidates.filter(c => !attemptedPoolKeyIds.has(c.keyId));
            if (freshCandidates.length > 0) {
              candidates = freshCandidates;
            }

            const selected = keySelector.selectCandidate(candidates, {
              provider: poolProvider,
              strategy: poolStrategy,
            });
            if (!selected) break;
            attemptedPoolKeyIds.add(selected.keyId);

            const picked = typeof pool.pickById === 'function'
              ? pool.pickById(poolProvider, selected.keyId)
              : pool.pick(poolProvider);
            if (!picked) continue;

            // Acquire concurrency slot
            const releaseSlot = slots.acquire(picked.keyId);

            try {
              const apiServiceProvider = entry.key === 'api'
                ? _mapApiPoolProviderToServiceProvider(poolProvider)
                : null;
              const apiDefaultModel = entry.key === 'api'
                ? _defaultModelForApiPoolProvider(poolProvider)
                : null;
              const cachedFastFail = await inspectCachedFastFail(entry.key, adapterDisplayName);
              if (cachedFastFail) {
                allAttempts.push({
                  provider: adapterDisplayName,
                  adapterKey: entry.key,
                  success: false,
                  error: cachedFastFail.error,
                  statusCode: 0,
                  errorType: cachedFastFail.errorType,
                  virtualSkip: true,
                });
                if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
                  failedPreferredReason = cachedFastFail.rawError || cachedFastFail.error;
                }
                if (strictPreferredOnly && entry.key === preferredAdapter) {
                  return finishResult({
                    success: false,
                    content: _prependFailureReason(
                      buildPreferredAdapterRecoveryHint(preferredAdapter, cachedFastFail.rawError || cachedFastFail.error),
                      allAttempts,
                      6
                    ),
                    provider: 'none',
                    adapter: 'none',
                    preferredAdapter,
                    actualAdapter: firstTriedAdapter,
                    fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} failed`,
                    attempts: allAttempts,
                    errorType: cachedFastFail.errorType || 'unavailable',
                  }, { error: failedPreferredReason || `preferred adapter ${preferredAdapter} failed` });
                }
                continue;
              }
              throwIfCancelled();
              const attemptBudgetExceeded = reserveAttemptBudget();
              if (attemptBudgetExceeded) return attemptBudgetExceeded;
              if (!skipRateLimit) {
                await this._enforceRateLimit(entry.key, {
                  onWait: options.onWait,
                  fastInteractive: fastInteractiveRateLimit,
                  attemptIndex: pi,
                });
              }
              throwIfCancelled();

              const attemptAbort = createLinkedAbortController(externalAbortSignal);
              let idleTimeout = null;
              let result;
              let stopPulse = () => {};
              try {
                idleTimeout = createAdapterIdleTimeout(entry.key, PER_ADAPTER_TIMEOUT_MS, attemptAbort);
                const touchActivity = () => {
                  if (idleTimeout) idleTimeout.touch();
                };
                stopPulse = startAdapterPulse(adapterDisplayName);
                const adapterPromise = this._generateWithAdapterIsolation(entry, prompt, {
                  ...adapterOptions,
                  timeoutMs: PER_ADAPTER_TIMEOUT_MS,
                  provider: apiServiceProvider || adapterOptions.provider,
                  apiPoolProvider: poolProvider || adapterOptions.apiPoolProvider,
                  model: adapterOptions.model || apiDefaultModel || adapterOptions.model,
                  apiKey: picked.key,
                  apiEndpoint: picked.endpoint || undefined,
                  onChunk: (chunk) => {
                    touchActivity();
                    if (typeof adapterOptions.onChunk === 'function') {
                      try { adapterOptions.onChunk(chunk); } catch { /* best effort */ }
                    }
                  },
                  abortSignal: attemptAbort.signal,
                  beforeRun: async () => {
                    const cached = await inspectCachedFastFail(entry.key, adapterDisplayName);
                    if (!cached) return null;
                    return {
                      skip: true,
                      error: cached.error,
                      errorType: cached.errorType,
                    };
                  },
                  afterRun: recordFailureEarly,
                  onRunError: async (err) => {
                    await recordThrownFailureEarly(err, attemptAbort.signal);
                  },
                });
                result = await Promise.race([adapterPromise, idleTimeout.timeoutPromise]);
              } finally {
                stopPulse();
                if (idleTimeout) idleTimeout.stop();
                attemptAbort.cleanup();
              }

              throwIfCancelled();
              if (releaseSlot) releaseSlot();
              if (result.attempts) allAttempts.push(...result.attempts);
              if (result && result.gatewaySkipFastFail) {
                releaseAttemptBudget();
                allAttempts.push({
                  provider: adapterDisplayName,
                  adapterKey: entry.key,
                  success: false,
                  error: result.error || 'adapter skipped',
                  statusCode: 0,
                  errorType: result.errorType || 'unavailable',
                  virtualSkip: true,
                });
                if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
                  failedPreferredReason = result.error || 'preferred adapter skipped';
                }
                if (strictPreferredOnly && entry.key === preferredAdapter) {
                  return finishResult({
                    success: false,
                    content: _prependFailureReason(
                      buildPreferredAdapterRecoveryHint(preferredAdapter, result.error || 'adapter skipped'),
                      allAttempts,
                      6
                    ),
                    provider: 'none',
                    adapter: 'none',
                    preferredAdapter,
                    actualAdapter: firstTriedAdapter,
                    fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} failed`,
                    attempts: allAttempts,
                    errorType: result.errorType || 'unavailable',
                  }, { error: failedPreferredReason || result.error || `preferred adapter ${preferredAdapter} failed` });
                }
                continue;
              }

              if (result.success) {
                emitStatus(`${adapterDisplayName} 已连接并响应`);
                pool.markSuccess(picked.keyId);
                await this._clearAdapterFailure(entry.key);
                if (_advDiag) _advDiag.recordLatency(`adapter:${entry.key}`, Date.now() - startTime);
                try {
                  await pluginChain.executeAfterResponse({ prompt, options, response: result, adapter: entry.key });
                } catch (hookErr) {
                  emitStatus(`Gateway plugin warning: ${hookErr.message || 'afterResponse failed'}`);
                }
                const canonicalProvider = result.provider || entry.key;
                const providerDisplay = picked.label
                  ? `${canonicalProvider} [${picked.label}]`
                  : canonicalProvider;
                return finishResult({
                  success: true,
                  content: result.content,
                  thinking: result.thinking || null,
                  provider: canonicalProvider,
                  providerDisplay,
                  adapter: result.adapter,
                  preferredAdapter,
                  actualAdapter: entry.key,
                  fallbackReason: preferredAdapter && entry.key !== preferredAdapter
                    ? (failedPreferredReason || `preferred adapter ${preferredAdapter} failed`)
                    : null,
                  model: result.model || null,
                  tokenUsage: result.tokenUsage || null,
                  toolSummary: result.toolSummary || null,
                  attempts: allAttempts,
                }, {
                  response: {
                    content: result.content,
                    model: result.model,
                    provider: canonicalProvider,
                    providerDisplay,
                    tokens: result.tokenUsage || null,
                  }
                });
              }

              // Failed but no exception
              const sc = result.statusCode || 0;
              const resolvedErrMsg = _extractResultErrorMessage(result);
              const errType = _resolveResultErrorType(sc, resolvedErrMsg, result.errorType);
              const resHeaders = result.headers || null;
              emitStatus(`${entry.adapter.getStatus().name} 失败: ${resolvedErrMsg}`);
              pool.markFailure(picked.keyId, sc, resolvedErrMsg, resHeaders);
              allAttempts.push({
                provider: entry.adapter.getStatus().name,
                adapterKey: entry.key,
                success: false,
                error: resolvedErrMsg,
                statusCode: sc,
                errorType: errType,
              });
              _maybeBoostRetryBudgetForNetworkJitter(errType, resolvedErrMsg, sc, entry.key);
              await this._recordAdapterFailure(entry.key, errType, resolvedErrMsg);
              if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
                failedPreferredReason = resolvedErrMsg || 'preferred adapter failed';
              }
              monitor.addCascadeAttempt(traceId, { adapter: entry.key, success: false, error: resolvedErrMsg, model: options.model });
              if (strictPreferredOnly && entry.key === preferredAdapter) {
                if (_maybeRelaxStrictPreferredOnFailure(entry.key, errType, resolvedErrMsg)) {
                  continue;
                }
                return finishResult({
                  success: false,
                  content: _prependFailureReason(
                    buildPreferredAdapterRecoveryHint(preferredAdapter, resolvedErrMsg || 'unknown error'),
                    allAttempts,
                    6
                  ),
                  provider: 'none',
                  adapter: 'none',
                  preferredAdapter,
                  actualAdapter: firstTriedAdapter,
                  fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} failed`,
                  attempts: allAttempts,
                  errorType: errType,
                }, { error: failedPreferredReason || resolvedErrMsg || 'preferred adapter failed' });
              }
              // Continue to next pool key
            } catch (err) {
              if (releaseSlot) releaseSlot();
              if (externalAbortSignal && externalAbortSignal.aborted) {
                return finishResult(
                  buildCancelledResult(getAbortReason()),
                  { error: `Cancelled: ${getAbortReason()}` }
                );
              }
              emitStatus(`${entry.adapter.getStatus().name} 错误: ${err.message || '未知错误'}`);
              const sc = err.status || err.statusCode || err.response?.status || 0;
              const errHeaders = err.response?.headers || null;
              const errType = classifyError(sc, err.message);
              pool.markFailure(picked.keyId, sc, err.message, errHeaders);
              allAttempts.push({
                provider: adapterDisplayName,
                adapterKey: entry.key,
                success: false,
                error: err.message,
                statusCode: sc,
                errorType: errType,
              });
              _maybeBoostRetryBudgetForNetworkJitter(errType, err.message, sc, entry.key);
              await this._recordAdapterFailure(entry.key, errType, err.message || 'unknown');
              if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
                failedPreferredReason = err.message || 'preferred adapter failed';
              }
              if (strictPreferredOnly && entry.key === preferredAdapter) {
                if (_maybeRelaxStrictPreferredOnFailure(entry.key, errType, err.message)) {
                  continue;
                }
                return finishResult({
                  success: false,
                  content: _prependFailureReason(
                    buildPreferredAdapterRecoveryHint(preferredAdapter, err.message),
                    allAttempts,
                    6
                  ),
                  provider: 'none',
                  adapter: 'none',
                  preferredAdapter,
                  actualAdapter: firstTriedAdapter,
                  fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} failed`,
                  attempts: allAttempts,
                  errorType: errType,
                }, { error: failedPreferredReason || err.message || 'preferred adapter failed' });
              }
              // Continue to next pool key for retryable errors
              if (![429, 403, 401, 529].includes(sc) && !/rate.?limit|overloaded/i.test(err.message)) {
                break; // Non-retryable, move to next adapter
              }
            }
          }
          // Pool exhausted for this adapter, notify and move to next adapter
          if (!(externalAbortSignal && externalAbortSignal.aborted) && options.onFallback) {
            const nextEntry = orderedAdapters.find(a =>
              a.key !== entry.key && a.enabled && (a.available || a.key === 'relay')
            );
            emitStatus(`密钥池耗尽，切换通道: ${adapterDisplayName}${nextEntry ? ` → ${nextEntry.adapter.getStatus().name}` : ''}`);
            try {
              options.onFallback({
                failedAdapter: adapterDisplayName,
                failedError: 'all pool keys exhausted',
                failedErrorType: 'pool_exhausted',
                nextAdapter: nextEntry ? nextEntry.adapter.getStatus().name : null,
              });
            } catch (fallbackErr) {
              emitStatus(`Fallback callback warning: ${fallbackErr.message || 'onFallback failed'}`);
            }
          }
          continue; // Move to next adapter in cascade
        }
      } catch { /* pool not available, fall through to normal flow */ }

      // Standard single-key flow (no pool or pool not applicable)
      // Retry budget is configurable for long/large tasks.
      const baseAttempts = isLargeTask
        ? 3
        : (isSmallTask
          ? ((entry.key === 'relay_api' || entry.key === 'api') ? 2 : 1)
          : 2);
      const maxAdapterAttempts = _parsePositiveInt(
        options.maxAdapterAttempts || process.env.GATEWAY_ADAPTER_MAX_ATTEMPTS || String(baseAttempts),
        baseAttempts,
        1,
        8
      );
      for (let attempt = 0; attempt < maxAdapterAttempts; attempt++) {
        try {
          const cachedFastFail = await inspectCachedFastFail(entry.key, adapterDisplayName);
          if (cachedFastFail) {
            allAttempts.push({
              provider: adapterDisplayName,
              adapterKey: entry.key,
              success: false,
              error: cachedFastFail.error,
              statusCode: 0,
              errorType: cachedFastFail.errorType,
              virtualSkip: true,
            });
            if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
              failedPreferredReason = cachedFastFail.rawError || cachedFastFail.error;
            }
            if (strictPreferredOnly && entry.key === preferredAdapter) {
              return finishResult({
                success: false,
                content: _prependFailureReason(
                  buildPreferredAdapterRecoveryHint(preferredAdapter, cachedFastFail.rawError || cachedFastFail.error),
                  allAttempts,
                  6
                ),
                provider: 'none',
                adapter: 'none',
                preferredAdapter,
                actualAdapter: firstTriedAdapter,
                fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} failed`,
                attempts: allAttempts,
                errorType: cachedFastFail.errorType || 'unavailable',
              }, { error: failedPreferredReason || `preferred adapter ${preferredAdapter} failed` });
            }
            break;
          }
          const attemptBudgetExceeded = reserveAttemptBudget();
          if (attemptBudgetExceeded) return attemptBudgetExceeded;
          throwIfCancelled();
          if (attempt > 0) {
            emitStatus(`重试 ${adapterDisplayName} (${attempt + 1}/${maxAdapterAttempts})`);
          }
          // Anti-ban: enforce per-adapter rate limit with jitter
          if (!skipRateLimit) {
            await this._enforceRateLimit(entry.key, {
              onWait: options.onWait,
              fastInteractive: fastInteractiveRateLimit,
              attemptIndex: attempt,
            });
          }
          throwIfCancelled();

          // Per-adapter idle-timeout: only timeout when no activity for timeout window.
          const attemptAbort = createLinkedAbortController(externalAbortSignal);
          let idleTimeout = null;
          let result;
          let stopPulse = () => {};
          try {
            idleTimeout = createAdapterIdleTimeout(entry.key, PER_ADAPTER_TIMEOUT_MS, attemptAbort);
            const touchActivity = () => {
              if (idleTimeout) idleTimeout.touch();
            };
            stopPulse = startAdapterPulse(adapterDisplayName);
            const adapterPromise = this._generateWithAdapterIsolation(entry, prompt, {
              ...adapterOptions,
              timeoutMs: PER_ADAPTER_TIMEOUT_MS,
              onChunk: (chunk) => {
                touchActivity();
                if (typeof adapterOptions.onChunk === 'function') {
                  try { adapterOptions.onChunk(chunk); } catch { /* best effort */ }
                }
              },
              abortSignal: attemptAbort.signal,
              beforeRun: async () => {
                const cached = await inspectCachedFastFail(entry.key, adapterDisplayName);
                if (!cached) return null;
                return {
                  skip: true,
                  error: cached.error,
                  errorType: cached.errorType,
                };
              },
              afterRun: recordFailureEarly,
              onRunError: async (err) => {
                await recordThrownFailureEarly(err, attemptAbort.signal);
              },
            });
            result = await Promise.race([adapterPromise, idleTimeout.timeoutPromise]);
          } finally {
            stopPulse();
            if (idleTimeout) idleTimeout.stop();
            attemptAbort.cleanup();
          }

          throwIfCancelled();
          if (result.attempts) allAttempts.push(...result.attempts);
          if (result && result.gatewaySkipFastFail) {
            releaseAttemptBudget();
            allAttempts.push({
              provider: adapterDisplayName,
              adapterKey: entry.key,
              success: false,
              error: result.error || 'adapter skipped',
              statusCode: 0,
              errorType: result.errorType || 'unavailable',
              virtualSkip: true,
            });
            if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
              failedPreferredReason = result.error || 'preferred adapter skipped';
            }
            if (strictPreferredOnly && entry.key === preferredAdapter) {
              return finishResult({
                success: false,
                content: _prependFailureReason(
                  buildPreferredAdapterRecoveryHint(preferredAdapter, result.error || 'adapter skipped'),
                  allAttempts,
                  6
                ),
                provider: 'none',
                adapter: 'none',
                preferredAdapter,
                actualAdapter: firstTriedAdapter,
                fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} failed`,
                attempts: allAttempts,
                errorType: result.errorType || 'unavailable',
              }, { error: failedPreferredReason || result.error || `preferred adapter ${preferredAdapter} failed` });
            }
            continue;
          }

          if (result.success) {
            emitStatus(`${adapterDisplayName} 已连接并响应`);
            await this._clearAdapterFailure(entry.key);
            if (_advDiag) _advDiag.recordLatency(`adapter:${entry.key}`, Date.now() - startTime);
            try {
              await pluginChain.executeAfterResponse({ prompt, options, response: result, adapter: entry.key });
            } catch (hookErr) {
              emitStatus(`Gateway plugin warning: ${hookErr.message || 'afterResponse failed'}`);
            }

            let usageTrackErr = null;
            try {
              // Track usage and emit diagnostic
              const reqDuration = Date.now() - startTime;
              usageTracker.record({
                sessionId: options.sessionId || 'default',
                model: result.model || 'unknown',
                provider: result.provider || entry.key,
                inputTokens: result.tokenUsage?.inputTokens || 0,
                outputTokens: result.tokenUsage?.outputTokens || 0,
                durationMs: reqDuration,
                cached: !!result.tokenUsage?.cached,
                success: true,
              });
              diagnostics.emitModelResponse(
                result.model || 'unknown',
                result.provider || entry.key,
                result.tokenUsage,
                reqDuration,
                { traceId: options._diagTraceId }
              );
            } catch (diagErr) {
              usageTrackErr = diagErr;
            }

            const successResult = {
              success: true,
              content: result.content,
              thinking: result.thinking || null,
              provider: result.provider,
              adapter: result.adapter,
              preferredAdapter,
              actualAdapter: entry.key,
              fallbackReason: preferredAdapter && entry.key !== preferredAdapter
                ? (failedPreferredReason || `preferred adapter ${preferredAdapter} failed`)
                : null,
              model: result.model || null,
              tokenUsage: result.tokenUsage || null,
              toolSummary: result.toolSummary || null,
              attempts: allAttempts,
            };
            const finalized = finishResult(successResult, {
              response: {
                content: result.content,
                model: result.model,
                provider: result.provider,
                tokens: result.tokenUsage || null,
              }
            });
            if (usageTrackErr) {
              emitStatus(`Gateway telemetry warning: ${usageTrackErr.message || 'usage tracking failed'}`);
            }
            return finalized;
          }

          // Not success but no exception — extract error info if present
          const resolvedErrMsg = _extractResultErrorMessage(result);
          const errType = _resolveResultErrorType(result.statusCode, resolvedErrMsg, result.errorType);
          emitStatus(`${entry.adapter.getStatus().name} 失败: ${resolvedErrMsg}`);
          allAttempts.push({
            provider: entry.adapter.getStatus().name,
            adapterKey: entry.key,
            success: false,
            error: resolvedErrMsg,
            statusCode: result.statusCode,
            errorType: errType,
          });
          _maybeBoostRetryBudgetForNetworkJitter(errType, resolvedErrMsg, result.statusCode, entry.key);
          await this._recordAdapterFailure(entry.key, errType, resolvedErrMsg);
          if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
            failedPreferredReason = resolvedErrMsg || 'preferred adapter failed';
          }
          if (strictPreferredOnly && entry.key === preferredAdapter) {
            if (_maybeRelaxStrictPreferredOnFailure(entry.key, errType, resolvedErrMsg)) {
              continue;
            }
            return finishResult({
              success: false,
              content: _prependFailureReason(
                buildPreferredAdapterRecoveryHint(preferredAdapter, resolvedErrMsg || 'unknown error'),
                allAttempts,
                6
              ),
              provider: 'none',
              adapter: 'none',
              preferredAdapter,
              actualAdapter: firstTriedAdapter,
              fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} failed`,
              attempts: allAttempts,
              errorType: errType,
            }, { error: failedPreferredReason || resolvedErrMsg || 'preferred adapter failed' });
          }

          // Retry non-throwing transient failures as well.
          if (attempt < (maxAdapterAttempts - 1) && _isRetryableResultErrorType(errType)) {
            const baseDelay = errType === 'rate_limit' ? 3000 : 1200;
            const jitter = Math.random() * baseDelay * 0.5;
            const budgetExceeded = await waitWithRetryDelayBudget(baseDelay + jitter);
            if (budgetExceeded) return budgetExceeded;
            continue;
          }

          // Notify caller about fallback (don't silently switch)
          if (!(externalAbortSignal && externalAbortSignal.aborted) && options.onFallback) {
            const nextEntry = orderedAdapters.find(a =>
              a.key !== entry.key && a.enabled && (a.available || a.key === 'relay')
            );
            emitStatus(`切换通道: ${entry.adapter.getStatus().name}${nextEntry ? ` → ${nextEntry.adapter.getStatus().name}` : ''}`);
            try {
              options.onFallback({
                failedAdapter: entry.adapter.getStatus().name,
                failedError: resolvedErrMsg,
                failedErrorType: errType,
                failedStatusCode: result.statusCode,
                nextAdapter: nextEntry ? nextEntry.adapter.getStatus().name : null,
              });
            } catch (fallbackErr) {
              emitStatus(`Fallback callback warning: ${fallbackErr.message || 'onFallback failed'}`);
            }
          }
          break; // non-exception failure, move to next adapter
        } catch (err) {
          if (externalAbortSignal && externalAbortSignal.aborted) {
            return finishResult(
              buildCancelledResult(getAbortReason()),
              { error: `Cancelled: ${getAbortReason()}` }
            );
          }
          const status = err.status || err.statusCode || err.response?.status;
          const errorType = classifyError(status, err.message);
          emitStatus(`${entry.adapter.getStatus().name} 错误: ${err.message || '未知错误'}`);

          allAttempts.push({
            provider: entry.adapter.getStatus().name,
            adapterKey: entry.key,
            success: false,
            error: err.message,
            statusCode: status,
            errorType,
          });
          _maybeBoostRetryBudgetForNetworkJitter(errorType, err.message, status, entry.key);
          await this._recordAdapterFailure(entry.key, errorType, err.message || 'unknown');
          if (preferredAdapter && entry.key === preferredAdapter && !failedPreferredReason) {
            failedPreferredReason = err.message || 'preferred adapter failed';
          }
          if (strictPreferredOnly && entry.key === preferredAdapter) {
            if (_maybeRelaxStrictPreferredOnFailure(entry.key, errorType, err.message)) {
              continue;
            }
            return finishResult({
              success: false,
              content: _prependFailureReason(
                buildPreferredAdapterRecoveryHint(preferredAdapter, err.message),
                allAttempts,
                6
              ),
              provider: 'none',
              adapter: 'none',
              preferredAdapter,
              actualAdapter: firstTriedAdapter,
              fallbackReason: failedPreferredReason || `preferred adapter ${preferredAdapter} failed`,
              attempts: allAttempts,
              errorType,
            }, { error: failedPreferredReason || err.message || 'preferred adapter failed' });
          }

          // Auto-retry transient thrown errors within configured budget.
          if (attempt < (maxAdapterAttempts - 1) && isRetryableError(err)) {
            // Respect server Retry-After header if present
            const serverDelay = parseRetryAfter(err);
            const baseDelay = serverDelay || (errorType === 'rate_limit' ? 3000 : 1500);
            const jitter = Math.random() * baseDelay * 0.5;
            const budgetExceeded = await waitWithRetryDelayBudget(baseDelay + jitter);
            if (budgetExceeded) return budgetExceeded;
            continue; // retry same adapter
          }

          // Notify caller about fallback (don't silently switch)
          if (!(externalAbortSignal && externalAbortSignal.aborted) && options.onFallback) {
            const nextEntry = orderedAdapters.find(a =>
              a.key !== entry.key && a.enabled && (a.available || a.key === 'relay')
            );
            emitStatus(`切换通道: ${entry.adapter.getStatus().name}${nextEntry ? ` → ${nextEntry.adapter.getStatus().name}` : ''}`);
            try {
              options.onFallback({
                failedAdapter: entry.adapter.getStatus().name,
                failedError: err.message,
                failedErrorType: errorType,
                failedStatusCode: status,
                nextAdapter: nextEntry ? nextEntry.adapter.getStatus().name : null,
              });
            } catch (fallbackErr) {
              emitStatus(`Fallback callback warning: ${fallbackErr.message || 'onFallback failed'}`);
            }
          }
          break; // non-retryable or already retried, move to next adapter
        }
      }
    }

    if (externalAbortSignal && externalAbortSignal.aborted) {
      return finishResult(
        buildCancelledResult(getAbortReason()),
        { error: `Cancelled: ${getAbortReason()}` }
      );
    }

    // All adapters failed — increment failures via healthStore for attempted adapters
    const attemptedAdapterKeys = new Set(
      allAttempts
        .filter(a => a && !a.virtualSkip)
        .map(a => a.adapterKey)
        .filter(Boolean)
    );
    let totalFailures = 0;
    for (const entry of orderedAdapters) {
      if (entry.enabled && entry.available && attemptedAdapterKeys.has(entry.key)) {
        const newCount = await this._healthStore.incrFailure(entry.key);
        this._adapterFailures[entry.key] = newCount; // keep mirror in sync
        totalFailures += newCount;
      }
    }
    if (totalFailures >= 2) {
      // Force re-detect adapters on next call (IDE might have updated tokens)
      this.refreshAdapters().catch(() => {});
    }

    if (_advDiag) _advDiag.recordError('gateway', 'All adapters failed');

    // Build detailed failure report
    const guidanceContent = [
      '所有 AI 通道均不可用。',
      '',
      '🆓 免费方案 (推荐):',
      '  • Kiro IDE — 免费 Claude 4 额度: https://kiro.dev',
      '  • Trae IDE — 免费 Claude/GPT 额度: https://trae.ai',
      '  • Ollama 本地模型 — 无需网络，运行 /models 安装',
      '',
      '💰 付费订阅:',
      '  • Claude: https://claude.ai/pricing',
      '  • OpenAI: https://platform.openai.com',
      '  • Cursor: https://cursor.com/pricing',
      '  • 智谱AI (国内直连): https://open.bigmodel.cn',
      '  • 通义千问 (国内直连): https://dashscope.aliyun.com',
      '',
      '⚡ 快速配置:',
      '  • ai config — 配置 API 密钥',
      '  • /proxy — 配置代理 (Clash/VPN)',
      '  • khy gateway relay — 启动 Web 中转服务',
    ].join('\n');

    return finishResult({
      success: false,
      content: _prependFailureReason(guidanceContent, allAttempts, 10),
      provider: 'none',
      adapter: 'none',
      preferredAdapter,
      actualAdapter: firstTriedAdapter,
      fallbackReason: preferredAdapter ? (failedPreferredReason || `preferred adapter ${preferredAdapter} unavailable`) : null,
      attempts: allAttempts,
      errorType: allAttempts.length > 0 ? allAttempts[allAttempts.length - 1].errorType : 'unknown',
    }, { error: 'All adapters failed' });
  }

  /**
   * Auto-select the best available model.
   * Priority: user preference > habit > capability score > priority order.
   * @param {string} [taskType] - 'conversation', 'analysis', 'code', 'reasoning'
   * @returns {{ adapter: string, model: string|null, reason: string }}
   */
  autoSelectModel(taskType = 'conversation') {
    if (!this._initialized) {
      // Quick sync check
      for (const entry of this._adapters) {
        if (entry.enabled && entry.adapter.detect()) {
          entry.available = true;
        }
      }
    }

    // 1. Check user preference
    const preferred = process.env.GATEWAY_PREFERRED_ADAPTER;
    if (preferred && preferred !== 'auto') {
      const entry = this._adapters.find(a => a.key === preferred && a.enabled);
      if (entry && (entry.available || entry.adapter.detect())) {
        return {
          adapter: preferred,
          model: process.env.GATEWAY_PREFERRED_MODEL || null,
          reason: 'user_preference',
        };
      }
    }

    // 2. Check habit-based preference
    try {
      const { getPreferredModel } = require('../usageHabitService');
      const habit = getPreferredModel(taskType);
      if (habit && habit.adapter) {
        const entry = this._adapters.find(a => a.key === habit.adapter && a.enabled);
        if (entry && entry.available) {
          return { adapter: habit.adapter, model: habit.model || null, reason: 'learned_habit' };
        }
      }
    } catch { /* best effort */ }

    // 3. Task-based capability matching
    const TASK_PREFERENCES = {
      reasoning: ['claude', 'codex', 'cursor', 'api', 'ollama'],
      code: ['claude', 'codex', 'cursor', 'kiro', 'api'],
      analysis: ['api', 'claude', 'cursor', 'ollama', 'windsurf', 'warp'],
      conversation: null, // use default priority
    };

    const taskOrder = TASK_PREFERENCES[taskType];
    if (taskOrder) {
      for (const key of taskOrder) {
        const entry = this._adapters.find(a => a.key === key && a.enabled && a.available);
        if (entry) {
          return { adapter: key, model: null, reason: `best_for_${taskType}` };
        }
      }
    }

    // 4. Fallback: first available by priority
    for (const entry of this._adapters) {
      if (!entry.enabled || !entry.available) continue;
      if (entry.key === 'relay') continue; // relay is last resort
      return { adapter: entry.key, model: null, reason: 'priority_order' };
    }

    // 5. Relay as absolute fallback
    return { adapter: 'relay', model: null, reason: 'fallback' };
  }

  /**
   * Generate with a specific sub-model (for delegation from main model).
   * @param {string} prompt
   * @param {string} adapterKey - specific adapter to use
   * @param {object} [options]
   * @returns {Promise<object>}
   */
  async generateWithSubModel(prompt, adapterKey, options = {}) {
    if (!this._initialized) await this.init();

    const entry = this._adapters.find(a => a.key === adapterKey && a.enabled);
    if (!entry || (!entry.available && !options.forceAdapter)) {
      return {
        success: false,
        content: `Sub-model adapter "${adapterKey}" is not available.`,
        provider: 'none',
        adapter: adapterKey,
        attempts: [{ provider: adapterKey, success: false, error: 'not_available' }],
      };
    }

    try {
      const result = await retryWithBackoff(
        () => this._generateWithAdapterIsolation(entry, prompt, options),
        {
          attempts: 2,
          minDelayMs: 1000,
          maxDelayMs: 10000,
          label: `submodel:${adapterKey}`,
          shouldRetry: (err) => isRetryableError(err),
          retryAfterMs: (err) => parseRetryAfter(err),
        }
      );
      return result;
    } catch (err) {
      return {
        success: false,
        content: err.message,
        provider: entry.adapter.getStatus().name,
        adapter: adapterKey,
        attempts: [{ provider: adapterKey, success: false, error: err.message }],
      };
    }
  }

  /**
   * Get status of all adapters (for display).
   */
  getStatus() {
    return this._adapters.map(entry => {
      const status = entry.adapter.getStatus();
      const cached = this._adapterLastError[entry.key] || null;
      let recent = null;
      if (cached) {
        const fallbackCooldownMs = _parseMs(process.env.GATEWAY_FAST_FAIL_COOLDOWN_MS || '30000', 30000, 5000);
        const cooldownMs = _parseMs(cached.cooldownMs, fallbackCooldownMs, 5000);
        const elapsedMs = Date.now() - Number(cached.at || 0);
        if (elapsedMs <= cooldownMs && (cached.circuitOpen || _shouldUseFastFail(cached.errorType))) {
          recent = {
            ...cached,
            cooldownMs,
            remainingMs: Math.max(0, cooldownMs - elapsedMs),
          };
        }
      }
      const lastError = cached ? {
        at: cached.at,
        errorType: cached.errorType,
        error: cached.error,
        coolingDown: !!recent,
        cooldownMs: cached.cooldownMs || null,
        remainingMs: recent?.remainingMs || 0,
      } : null;
      const cooldownHint = recent
        ? ` · cooldown ${Math.max(1, Math.ceil((recent.remainingMs || 0) / 1000))}s`
        : '';
      const detailWithFailure = lastError
        ? `${status.detail || ''}${status.detail ? ' · ' : ''}last failure [${lastError.errorType}]: ${lastError.error}${cooldownHint}`
        : status.detail;
      return {
        ...status,
        detail: detailWithFailure,
        lastError,
        enabled: entry.enabled,
        priority: entry.priority,
      };
    });
  }

  /**
   * Get the key of the first available adapter (e.g. 'localLLM', 'ollama', 'api').
   * Used by ai.js to determine timeout strategy before generation starts.
   */
  getFirstAvailableAdapter() {
    const preferred = String(process.env.GATEWAY_PREFERRED_ADAPTER || '').trim().toLowerCase();
    if (preferred && preferred !== 'auto') {
      const entry = this._adapters.find(a => a.key === preferred && a.enabled);
      if (entry && entry.adapter.detect()) return entry.key;
    }
    for (const entry of this._adapters) {
      if (!entry.enabled) continue;
      try { if (entry.adapter.detect()) return entry.key; } catch { /* skip */ }
    }
    return null;
  }

  /**
   * Get the first available adapter (for banner display).
   * Returns status object with activeModel if a preferred model is set.
   */
  getActiveAdapter() {
    const preferredAdapter = process.env.GATEWAY_PREFERRED_ADAPTER;
    const preferredModel = process.env.GATEWAY_PREFERRED_MODEL;
    const attachModelForEntry = (entryKey, statusObj) => {
      const shouldAttachPreferred = !!preferredAdapter && preferredAdapter !== 'auto' && entryKey === preferredAdapter;
      const resolved = shouldAttachPreferred ? resolvePreferredModelForAdapter(entryKey, preferredModel) : null;
      statusObj.activeModel = resolved || statusObj.activeModel || null;
      return statusObj;
    };

    if (!this._initialized) {
      // Quick sync detection (no async needed for status display).
      // Respect preferred adapter first to avoid mismatched adapter/model display.
      try {
        if (preferredAdapter && preferredAdapter !== 'auto') {
          const preferredEntry = this._adapters.find(a => a.key === preferredAdapter && a.enabled);
          if (preferredEntry && preferredEntry.adapter.detect()) {
            return attachModelForEntry(preferredEntry.key, preferredEntry.adapter.getStatus());
          }
        }
        for (const entry of this._adapters) {
          if (!entry.enabled) continue;
          if (entry.adapter.detect()) {
            return attachModelForEntry(entry.key, entry.adapter.getStatus());
          }
        }
      } catch { /* ignore */ }
      return null;
    }

    // If preferred adapter is set, try it first
    if (preferredAdapter) {
      const entry = this._adapters.find(a => a.key === preferredAdapter && a.enabled);
      if (entry) {
        const status = entry.adapter.getStatus();
        if (status.available) {
          return attachModelForEntry(entry.key, status);
        }
      }
    }

    for (const entry of this._adapters) {
      if (!entry.enabled) continue;
      const status = entry.adapter.getStatus();
      if (status.available) {
        return attachModelForEntry(entry.key, status);
      }
    }
    return null;
  }

  /**
   * Get the web relay adapter directly (for `gateway relay` command).
   */
  getRelayAdapter() {
    return webRelayAdapter;
  }

  /**
   * Get a specific adapter by key (for IDE commands).
   */
  getAdapter(key) {
    const entry = this._adapters.find(a => a.key === key);
    return entry ? entry.adapter : null;
  }

  /**
   * Generate using a specific adapter + model (for IDE commands).
   */
  async generateWithAdapter(adapterKey, prompt, options = {}) {
    const entry = this._adapters.find(a => a.key === adapterKey && a.enabled);
    if (!entry) throw new Error(`Adapter "${adapterKey}" not found`);
    return this._generateWithAdapterIsolation(entry, prompt, options);
  }

  /**
   * List models from a specific IDE adapter.
   */
  async listModels(adapterKey) {
    const adapter = this.getAdapter(adapterKey);
    if (!adapter?.listModels) return [];
    return adapter.listModels();
  }

  /**
   * Tear down all adapters.
   */
  async destroy() {
    if (this._cleanupInterval) {
      clearInterval(this._cleanupInterval);
      this._cleanupInterval = null;
    }
    this._stopCooldownSelfHealTicker();
    if (this._modelRefreshTimer) {
      clearInterval(this._modelRefreshTimer);
      this._modelRefreshTimer = null;
    }
    const errors = [];
    for (const entry of this._adapters) {
      if (!entry?.adapter?.destroy) continue;
      try {
        await entry.adapter.destroy();
      } catch (err) {
        errors.push({ key: entry.key, error: err });
      }
    }
    this._initialized = false;
    this._initPromise = null;
    this._adapterFailures = {};
    this._adapterLastError = {};
    this._cooldownSelfHealMeta = {};
    this._cooldownSelfHealInFlight.clear();
    this._clearAllCooldownSelfHealMidpointTimers();
    this._requestLog = {};
    this._lastRefreshTime = 0;
    if (errors.length > 0) {
      const summary = errors.map(e => `${e.key}: ${e.error?.message || String(e.error)}`).join('; ');
      const err = new Error(`Gateway destroy completed with adapter cleanup errors: ${summary}`);
      err.cleanupErrors = errors;
      throw err;
    }
  }

  /**
   * Test adapter connectivity with a lightweight request.
   * Two-step test pattern (inspired by cc-haha ProviderTestResult):
   *   Step 1: detect() — is the adapter reachable?
   *   Step 2: listModels() or generate ping — can it actually serve requests?
   *   Step 3 (selected adapters): real generation smoke test.
   * @param {string} adapterKey
   * @returns {Promise<{connectivity: {success,latencyMs,error?}, models?: {success,latencyMs,error?,count?}, generation?: {success,latencyMs,error?}}>}
   */
  async testAdapter(adapterKey, options = {}) {
    const entry = this._adapters.find(a => a.key === adapterKey);
    if (!entry || !entry.adapter) {
      return { connectivity: { success: false, latencyMs: 0, error: 'Adapter not found' } };
    }

    const quickMode = !!options.quick;
    const timeoutMs = Math.max(
      2000,
      parseInt(
        String(
          options.timeoutMs
          || process.env.GATEWAY_TEST_TIMEOUT_MS
          || 6000
        ),
        10
      ) || 6000
    );
    const generationProbeTimeoutMs = Math.max(
      0,
      parseInt(
        String(
          options.probeGenerationTimeoutMs
          || process.env.GATEWAY_GENERATION_PROBE_TIMEOUT_MS
          || 0
        ),
        10
      ) || 0
    );
    const result = { connectivity: null, models: null };

    // Step 1: Basic detection / connectivity
    const t1 = Date.now();
    let step1Timer = null;
    try {
      let ok;
      // Relay needs a real bind check; detect() is intentionally optimistic.
      if (adapterKey === 'relay' && typeof entry.adapter.start === 'function') {
        ok = await Promise.race([
          entry.adapter.start().then(() => true),
          new Promise((_, rej) => {
            step1Timer = setTimeout(() => rej(new Error(`timeout (${Math.round(timeoutMs / 1000)}s)`)), timeoutMs);
          }),
        ]);
      } else if (entry.adapter.detectAsync) {
        ok = await Promise.race([
          entry.adapter.detectAsync(true),
          new Promise((_, rej) => {
            step1Timer = setTimeout(() => rej(new Error(`timeout (${Math.round(timeoutMs / 1000)}s)`)), timeoutMs);
          }),
        ]);
      } else {
        ok = entry.adapter.detect(true);
      }
      result.connectivity = { success: !!ok, latencyMs: Date.now() - t1 };
      if (!ok) result.connectivity.error = 'not detected';
    } catch (err) {
      result.connectivity = { success: false, latencyMs: Date.now() - t1, error: err.message };
    } finally {
      if (step1Timer) clearTimeout(step1Timer);
    }

    if (!result.connectivity.success) return result;

    // Step 2: Model listing (if supported) — verifies API actually works
    if (entry.adapter.listModels) {
      const t2 = Date.now();
      let step2Timer = null;
      try {
        const models = await Promise.race([
          entry.adapter.listModels(),
          new Promise((_, rej) => {
            step2Timer = setTimeout(() => rej(new Error(`timeout (${Math.round(timeoutMs / 1000)}s)`)), timeoutMs);
          }),
        ]);
        result.models = {
          success: true,
          latencyMs: Date.now() - t2,
          count: Array.isArray(models) ? models.length : 0,
          list: Array.isArray(models) ? models.slice(0, 10) : [],
        };
      } catch (err) {
        result.models = { success: false, latencyMs: Date.now() - t2, error: err.message };
      } finally {
        if (step2Timer) clearTimeout(step2Timer);
      }
    }

    // Step 3: For adapters with frequent "detected but unusable" cases, run a tiny real-generation probe.
    // This avoids status false positives (e.g. codex command exists but request path is broken).
    if (!quickMode && adapterKey === 'codex' && typeof entry.adapter.generate === 'function') {
      const t3 = Date.now();
      try {
        // Use sync subprocess for probe to avoid leaving child-process handles
        // in this Node process when codex hangs or reconnect-loops.
        // Codex first-run/warm-up can exceed a few seconds; give a more realistic probe window.
        const timeoutMs = generationProbeTimeoutMs > 0
          ? Math.max(5000, generationProbeTimeoutMs)
          : Math.max(5000, parseInt(process.env.GATEWAY_CODEX_TIMEOUT_MS || '8000', 10) + 500);
        const preferredProbeModel = process.env.GATEWAY_PREFERRED_MODEL || '';
        const isCodexModel = /^(gpt[-_]|o\d)/i.test(preferredProbeModel);
        const probeModel = isCodexModel
          ? preferredProbeModel
          : (
            (Array.isArray(result.models?.list) && result.models.list[0] && (result.models.list[0].id || result.models.list[0].name))
              || 'o4-mini'
          );
        const probe = await new Promise((resolve) => {
          let stdout = '', stderr = '';
          const child = spawn('codex', [
            'exec', '--color', 'never', '--skip-git-repo-check',
            '--sandbox', 'read-only', '--model', probeModel,
          ], { env: process.env, stdio: ['pipe', 'pipe', 'pipe'] });
          const timer = setTimeout(() => { child.kill(); resolve({ stdout, stderr, status: null, timedOut: true }); }, timeoutMs);
          child.stdout.on('data', d => { stdout += d; if (stdout.length > 2 * 1024 * 1024) child.kill(); });
          child.stderr.on('data', d => { stderr += d; });
          child.stdin.write('Reply with exactly: OK');
          child.stdin.end();
          child.on('close', (code) => { clearTimeout(timer); resolve({ stdout: stdout.trim(), stderr: stderr.trim(), status: code, timedOut: false }); });
          child.on('error', (err) => { clearTimeout(timer); resolve({ stdout, stderr: err.message, status: 1, timedOut: false }); });
        });

        if (!probe.timedOut && probe.status === 0 && probe.stdout.length > 0) {
          result.generation = { success: true, latencyMs: Date.now() - t3 };
        } else {
          const errMsg = probe.timedOut
            ? `codex probe timeout after ${Math.max(1000, timeoutMs)}ms`
            : (probe.stderr || `codex exited with code ${probe.status}`);
          result.generation = {
            success: false,
            latencyMs: Date.now() - t3,
            error: errMsg,
          };
        }
      } catch (err) {
        result.generation = { success: false, latencyMs: Date.now() - t3, error: err.message };
      }
    }

    // Local LLM can appear "available" when model file exists, while runtime load
    // actually fails (e.g. GGUF mismatch, backend boot timeout). Probe a tiny
    // generation once so model-selection UI does not show false "available".
    if (!quickMode && adapterKey === 'localLLM' && typeof entry.adapter.generate === 'function') {
      const t3 = Date.now();
      try {
        const probeTimeout = generationProbeTimeoutMs > 0
          ? Math.max(4000, generationProbeTimeoutMs)
          : Math.max(4000, parseInt(process.env.GATEWAY_LOCAL_LLM_PROBE_TIMEOUT_MS || '30000', 10));
        const probePromise = entry.adapter.generate('Reply with exactly: OK', {
          maxTokens: 32,
          temperature: 0,
          top_p: 1,
          think: false, // Disable thinking for probe (avoids slow startup)
        });
        let probeTimer = null;
        const timeoutPromise = new Promise((_, reject) => {
          probeTimer = setTimeout(() => reject(new Error(`localLLM timeout (${probeTimeout}ms)`)), probeTimeout);
          if (probeTimer.unref) probeTimer.unref();
        });
        const probe = await Promise.race([probePromise, timeoutPromise]);
        if (probeTimer) clearTimeout(probeTimer);
        const text = String(probe?.content || '').trim();
        if (probe?.success && text) {
          result.generation = { success: true, latencyMs: Date.now() - t3 };
        } else {
          result.generation = {
            success: false,
            latencyMs: Date.now() - t3,
            error: probe?.error || 'empty generation',
          };
        }
      } catch (err) {
        result.generation = {
          success: false,
          latencyMs: Date.now() - t3,
          error: err.message || String(err),
        };
      }
    }

    // Claude CLI can be detected but unusable when login/API auth is missing.
    // Run a short non-interactive probe to catch this and avoid false "available".
    if (!quickMode && adapterKey === 'claude') {
      const t3 = Date.now();
      try {
        const timeoutMs = generationProbeTimeoutMs > 0
          ? Math.max(6000, generationProbeTimeoutMs)
          : Math.max(6000, parseInt(process.env.GATEWAY_CLAUDE_PROBE_TIMEOUT_MS || '10000', 10));
        const rawProbeModel = (process.env.GATEWAY_PREFERRED_MODEL || '').trim();
        const probeModel = rawProbeModel.includes('::')
          ? rawProbeModel.split('::')[0].trim()
          : rawProbeModel;
        const args = [
          '-p',
          '--output-format', 'stream-json',
          '--verbose',
          '--include-partial-messages',
          '--permission-mode', 'bypassPermissions',
        ];
        if (probeModel && /^claude[-_]/i.test(probeModel)) {
          args.push('--model', probeModel);
        }
        const runClaudeProbe = (argv) => new Promise((resolve) => {
          let stdout = '', stderr = '';
          const child = spawn('claude', argv, { env: process.env, stdio: ['pipe', 'pipe', 'pipe'] });
          const timer = setTimeout(() => { child.kill(); resolve({ stdout, stderr, status: null, timedOut: true }); }, timeoutMs);
          child.stdout.on('data', d => { stdout += d; if (stdout.length > 2 * 1024 * 1024) child.kill(); });
          child.stderr.on('data', d => { stderr += d; });
          child.stdin.write('Reply with exactly: OK');
          child.stdin.end();
          child.on('close', (code) => { clearTimeout(timer); resolve({ stdout, stderr, status: code, timedOut: false }); });
          child.on('error', (err) => { clearTimeout(timer); resolve({ stdout, stderr: err.message, status: 1, timedOut: false }); });
        });
        const evaluateProbe = (probe) => {
          const combined = `${probe.stdout}\n${probe.stderr}`.toLowerCase();
          // `apiKeySource:"none"` can still be valid when Claude Code uses local login/session.
          // Only treat explicit auth failures as "login unavailable".
          const authMissing = combined.includes('api_retry')
            || combined.includes('unauthorized')
            || combined.includes('not authenticated');
          const hasUsableContent = combined.includes('"type":"assistant"')
            || combined.includes('"type":"text"')
            || combined.includes('"type":"result"');
          const success = !probe.timedOut && probe.status === 0 && hasUsableContent && !authMissing;
          return { combined, authMissing, hasUsableContent, success };
        };
        let probe = await runClaudeProbe(args);
        let evaluated = evaluateProbe(probe);

        // If model-qualified probe fails (common with adapter suffix model ids), retry once without --model.
        if (!evaluated.success && args.includes('--model') && !evaluated.authMissing && !probe.timedOut) {
          const retryArgs = args.slice();
          const modelIdx = retryArgs.indexOf('--model');
          if (modelIdx >= 0) retryArgs.splice(modelIdx, 2);
          const retry = await runClaudeProbe(retryArgs);
          const retryEval = evaluateProbe(retry);
          if (retryEval.success) {
            probe = retry;
            evaluated = retryEval;
          }
        }

        if (evaluated.success) {
          result.generation = { success: true, latencyMs: Date.now() - t3 };
        } else {
          const reason = probe.timedOut
            ? `claude probe timeout after ${timeoutMs}ms`
            : (evaluated.authMissing ? 'claude auth/login unavailable' : (String(probe.stderr).trim() || `claude exited with code ${probe.status}`));
          result.generation = {
            success: false,
            latencyMs: Date.now() - t3,
            error: reason,
          };
        }
      } catch (err) {
        result.generation = {
          success: false,
          latencyMs: Date.now() - t3,
          error: err.message || String(err),
        };
      }
    }

    // Cursor/Windsurf can appear available from local token/cache only.
    // Run a tiny generation probe to ensure the remote channel actually works.
    if (!quickMode && (adapterKey === 'cursor' || adapterKey === 'windsurf') && typeof entry.adapter.generate === 'function') {
      const t3 = Date.now();
      try {
        const probeTimeout = generationProbeTimeoutMs > 0
          ? Math.max(6000, generationProbeTimeoutMs)
          : Math.max(6000, parseInt(process.env.GATEWAY_IDE_PROBE_TIMEOUT_MS || '10000', 10));
        const probeModel = (
          Array.isArray(result.models?.list)
            ? (result.models.list[0]?.id || result.models.list[0]?.name || '')
            : ''
        );
        const probePromise = entry.adapter.generate('Reply with exactly: OK', {
          model: probeModel || undefined,
          maxTokens: 32,
          temperature: 0,
          top_p: 1,
          think: false,
        });
        let probeTimer2 = null;
        const timeoutPromise = new Promise((_, reject) => {
          probeTimer2 = setTimeout(() => reject(new Error(`${adapterKey} probe timeout (${probeTimeout}ms)`)), probeTimeout);
          if (probeTimer2.unref) probeTimer2.unref();
        });
        const probe = await Promise.race([probePromise, timeoutPromise]);
        if (probeTimer2) clearTimeout(probeTimer2);
        const text = String(probe?.content || '').trim();
        if (probe?.success && text) {
          result.generation = { success: true, latencyMs: Date.now() - t3 };
        } else {
          result.generation = {
            success: false,
            latencyMs: Date.now() - t3,
            error: probe?.error || 'empty generation',
          };
        }
      } catch (err) {
        result.generation = {
          success: false,
          latencyMs: Date.now() - t3,
          error: err.message || String(err),
        };
      }
    }

    // Relay API can pass detect/listModels while configured default model is invalid.
    // Probe a tiny real generation to verify model-serving path.
    if (!quickMode && adapterKey === 'relay_api' && typeof entry.adapter.generate === 'function') {
      const t3 = Date.now();
      try {
        const probeTimeout = generationProbeTimeoutMs > 0
          ? Math.max(6000, generationProbeTimeoutMs)
          : Math.max(6000, parseInt(process.env.GATEWAY_RELAY_API_PROBE_TIMEOUT_MS || '10000', 10));
        const modelList = Array.isArray(result.models?.list) ? result.models.list : [];
        const remotePreferred = modelList.find((m) => String(m?.discoverySource || '').toLowerCase() === 'remote' && m?.isDefault)
          || modelList.find((m) => String(m?.discoverySource || '').toLowerCase() === 'remote')
          || modelList.find((m) => m && m.isDefault)
          || modelList[0]
          || null;
        const probeModel = remotePreferred ? (remotePreferred.id || remotePreferred.name || '') : '';
        const probePromise = entry.adapter.generate('Reply with exactly: OK', {
          model: probeModel || undefined,
          maxTokens: 24,
          temperature: 0,
          top_p: 1,
        });
        let probeTimer3 = null;
        const timeoutPromise = new Promise((_, reject) => {
          probeTimer3 = setTimeout(() => reject(new Error(`relay_api probe timeout (${probeTimeout}ms)`)), probeTimeout);
          if (probeTimer3.unref) probeTimer3.unref();
        });
        const probe = await Promise.race([probePromise, timeoutPromise]);
        if (probeTimer3) clearTimeout(probeTimer3);
        const text = String(probe?.content || '').trim();
        if (probe?.success && text) {
          result.generation = { success: true, latencyMs: Date.now() - t3 };
        } else {
          result.generation = {
            success: false,
            latencyMs: Date.now() - t3,
            error: probe?.error || 'empty generation',
          };
        }
      } catch (err) {
        result.generation = {
          success: false,
          latencyMs: Date.now() - t3,
          error: err.message || String(err),
        };
      }
    }

    return result;
  }
}

const gateway = new AIGateway();
gateway.classifyError = classifyError;

/**
 * Notify the live model switch about a manual model change from /model.
 * Without this, _modelSwitch.getActiveModel() returns the old value
 * and overrides process.env.GATEWAY_PREFERRED_MODEL on the next generate().
 */
gateway.syncModelSwitch = function syncModelSwitch(model) {
  if (_modelSwitch && model) {
    try {
      _modelSwitch.switchModel(model, { reason: 'gateway_preference', persist: false, force: true });
    } catch { /* best effort */ }
  }
};

module.exports = gateway;
