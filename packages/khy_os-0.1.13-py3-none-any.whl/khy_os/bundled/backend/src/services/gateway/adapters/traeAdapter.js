/**
 * Trae IDE Adapter — connect to Trae (ByteDance) models.
 *
 * Strategy:
 * 1) Prefer proprietary Trae Network SDK (if available)
 * 2) Fallback to HTTP OpenAI-compatible endpoint
 * 3) Support streaming chunks via options.onChunk
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { sanitizeOutgoingHeaders } = require('./ipAnonymizer');
const { attachImagesToOpenAIMessages } = require('./_imageCompat');
const { requestJson } = require('./_proxyTunnel');

const TRAE_STORAGE_PATHS = [
  path.join(os.homedir(), '.config', 'Nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), '.config', 'nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'Library', 'Application Support', 'Nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'Library', 'Application Support', 'nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'Nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'nirvana', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), '.config', 'Trae CN', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'Library', 'Application Support', 'Trae CN', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'Trae CN', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), '.config', 'Trae', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'Library', 'Application Support', 'Trae', 'User', 'globalStorage', 'storage.json'),
  path.join(os.homedir(), 'AppData', 'Roaming', 'Trae', 'User', 'globalStorage', 'storage.json'),
];

const KNOWN_MODELS = [
  { id: 'gpt-5.4-beta', name: 'GPT-5.4 Beta', isDefault: true },
  { id: 'gpt-5.2', name: 'GPT-5.2', isDefault: false },
  { id: 'minimax-m2.7', name: 'MiniMax-M2.7', isDefault: false },
  { id: 'kimi-k2.5', name: 'Kimi-K2.5', isDefault: false },
  { id: 'deepseek-v3.2', name: 'DeepSeek-V3.2', isDefault: false },
  { id: 'gemini-3.1-pro-preview', name: 'Gemini-3.1-Pro-Preview', isDefault: false },
  { id: 'gemini-3-flash-preview', name: 'Gemini-3-Flash-Preview', isDefault: false },
  { id: 'gemini-2.5-flash', name: 'Gemini-2.5-Flash', isDefault: false },
];

// Models that Trae IDE has offered historically or may add soon.
// Injected when the API doesn't list them, same strategy as Kiro.
// Source: Trae CN model picker (2026-05).
const TRAE_INJECTED_MODELS = [
  { id: 'doubao-1.5-pro', name: 'Doubao 1.5 Pro' },
  { id: 'doubao-1.5-thinking', name: 'Doubao 1.5 Thinking' },
  { id: 'deepseek-r1', name: 'DeepSeek R1' },
  { id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet' },
  { id: 'gpt-4o', name: 'GPT-4o' },
];
const TRAE_INJECT_MODELS = !/^(0|false|off)$/i.test(
  String(process.env.TRAE_INJECT_MODELS || '1').trim()
);

const ACCOUNT_POOL_TYPE = 'trae';
const TIMEOUT_MS = 60_000;
const MODEL_DISCOVERY_CACHE_MS = Math.max(5000, parseInt(process.env.TRAE_MODEL_CACHE_MS || '120000', 10) || 120000);
const MODEL_TOKEN_REGEX = /\b[a-zA-Z0-9][a-zA-Z0-9._:-]{2,80}\b/g;

let _available = null;
let _token = null;
let _models = [];
let _modelsFetchedAt = 0;
let _lastApiMeta = {
  at: 0,
  endpoint: '',
  officialHit: false,
  officialCount: 0,
  localCount: 0,
  mergedCount: 0,
  error: '',
  mode: 'http',
};

let _sdkLoadTried = false;
let _sdkModule = null;
let _sdkLoadError = null;
let _sdkClient = null;
let _sdkClientEndpoint = '';

function parseList(raw) {
  return String(raw || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
}

function dedupe(values = []) {
  const out = [];
  const seen = new Set();
  for (const value of values) {
    const key = String(value || '').trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(key);
  }
  return out;
}

function normalizeModelId(id) {
  return String(id || '')
    .trim()
    .replace(/^["']|["']$/g, '')
    .replace(/\s+/g, '');
}

function canonicalModelKey(id) {
  return normalizeModelId(id).toLowerCase();
}

function normalizeToken(raw) {
  return String(raw || '').trim();
}

function isLikelyCredentialToken(raw) {
  const token = normalizeToken(raw);
  if (!token) return false;
  if (token.length < 20 || token.length > 4096) return false;
  if (/\s/.test(token)) return false;
  if (!/^[A-Za-z0-9._\-+/=~:]+$/.test(token)) return false;
  if (/^(null|undefined|token|access[_-]?token|bearer)$/i.test(token)) return false;
  // Keep acceptance broad: some IDE sessions use pure-hex credentials.
  if (/^(eyJ|sk-|rk-|rt_|atk-|khy-)/i.test(token)) return true;
  if (/^[A-Za-z0-9]{20,}$/i.test(token)) return true;
  return /[A-Za-z]/.test(token) || /\d/.test(token);
}

function normalizeEndpointBase(raw) {
  const text = String(raw || '').trim();
  if (!text) return '';

  let base = text;
  if (!/^https?:\/\//i.test(base)) {
    base = `https://${base.replace(/^\/+/, '')}`;
  }

  try {
    const url = new URL(base);
    let pathname = String(url.pathname || '').trim();
    if (pathname.endsWith('/chat/completions')) {
      pathname = pathname.slice(0, -('/chat/completions'.length));
    }
    if (!pathname || pathname === '/') {
      pathname = '/v1';
    }
    pathname = pathname.replace(/\/+$/, '') || '/v1';
    return `${url.protocol}//${url.host}${pathname}`;
  } catch {
    return '';
  }
}

function toRelayEndpointBase(raw) {
  const normalized = normalizeEndpointBase(raw);
  if (!normalized) return '';
  return normalized
    .replace(/\/chat\/completions$/i, '')
    .replace(/\/models$/i, '')
    .replace(/\/+$/, '');
}

function buildChatUrl(base) {
  return `${String(base || '').replace(/\/+$/, '')}/chat/completions`;
}

function buildModelsUrl(base) {
  return `${String(base || '').replace(/\/+$/, '')}/models`;
}

function isLikelyModelId(id) {
  const model = canonicalModelKey(id);
  if (!model) return false;
  if (model.length < 3 || model.length > 96) return false;
  if (model.startsWith('http') || model.includes('@') || model.includes('\\')) return false;
  if (/[^a-z0-9._:-]/i.test(model)) return false;
  if (!/\d/.test(model) && !/(sonnet|haiku|opus|cascade|chat|turbo)/i.test(model)) return false;
  return /(gpt|claude|deepseek|qwen|glm|doubao|llama|mistral|moonshot|yi|kimi|minimax|gemini|swe|sonnet|haiku|opus|cascade)/i.test(model);
}

function modelDisplayName(id) {
  const normalized = normalizeModelId(id);
  const known = KNOWN_MODELS.find(m => canonicalModelKey(m.id) === canonicalModelKey(normalized));
  if (known?.name) return known.name;
  if (/^gpt/i.test(normalized)) return normalized.replace(/^gpt/i, 'GPT');
  if (/^claude/i.test(normalized)) return normalized.replace(/^claude/i, 'Claude');
  if (/^deepseek/i.test(normalized)) return normalized.replace(/^deepseek/i, 'DeepSeek');
  if (/^doubao/i.test(normalized)) return normalized.replace(/^doubao/i, 'Doubao');
  if (/^minimax/i.test(normalized)) return normalized.replace(/^minimax/i, 'MiniMax');
  if (/^gemini/i.test(normalized)) return normalized.replace(/^gemini/i, 'Gemini');
  if (/^kimi/i.test(normalized)) return normalized.replace(/^kimi/i, 'Kimi');
  return normalized;
}

function extractModelIdsFromString(text) {
  const out = new Set();
  const src = String(text || '');
  if (!src) return out;

  if (isLikelyModelId(src)) out.add(normalizeModelId(src));

  const cleaned = src.replace(/[,"'()[\]{}]/g, ' ');
  const regex = new RegExp(MODEL_TOKEN_REGEX.source, 'g');
  let m;
  while ((m = regex.exec(cleaned)) !== null) {
    const token = normalizeModelId(m[0]);
    if (isLikelyModelId(token)) out.add(token);
  }
  return out;
}

function readTraeStorageSnapshots() {
  const snapshots = [];
  for (const p of TRAE_STORAGE_PATHS) {
    try {
      if (!fs.existsSync(p)) continue;
      const data = JSON.parse(fs.readFileSync(p, 'utf8'));
      snapshots.push({ path: p, data });
    } catch {
      // ignore malformed storage snapshots
    }
  }
  return snapshots;
}

function readTraeToken() {
  const snapshots = readTraeStorageSnapshots();
  for (const snap of snapshots) {
    const data = snap.data || {};
    const token = data.traeAuth?.accessToken
      || data['traeAuth/accessToken']
      || data['trae.auth']?.accessToken
      || data['bytedance.auth']?.accessToken
      || data.nirvanaAuth?.accessToken
      || data['nirvanaAuth/accessToken']
      || data.accessToken;

    if (!isLikelyCredentialToken(token)) continue;

    const endpoint = normalizeEndpointBase(
      data.traeAuth?.endpoint
      || data.traeAuth?.host
      || data['trae.auth']?.endpoint
      || data['trae.auth']?.host
      || data.nirvanaAuth?.host
      || data['nirvanaAuth/host']
      || data.endpoint
      || data.baseUrl
      || data.baseURL
    );

    return {
      accessToken: normalizeToken(token),
      refreshToken: data.traeAuth?.refreshToken
        || data['traeAuth/refreshToken']
        || data['trae.auth']?.refreshToken
        || data['bytedance.auth']?.refreshToken
        || data.nirvanaAuth?.refreshToken
        || data['nirvanaAuth/refreshToken']
        || null,
      source: path.basename(path.dirname(path.dirname(path.dirname(snap.path)))),
      path: snap.path,
      endpoint,
      sdkEndpoint: data.traeAuth?.sdkEndpoint || data.nirvanaAuth?.sdkEndpoint || null,
      expiresAt: data.traeAuth?.expiresAt
        || data['traeAuth/expiresAt']
        || data['trae.auth']?.expiresAt
        || data['bytedance.auth']?.expiresAt
        || data.nirvanaAuth?.refreshExpireAt
        || data['nirvanaAuth/refreshExpireAt']
        || null,
    };
  }
  return null;
}

function isTokenExpired(tokenData) {
  if (!tokenData || !tokenData.expiresAt) return false;
  const ts = new Date(tokenData.expiresAt).getTime();
  if (!Number.isFinite(ts)) return false;
  return ts < (Date.now() + 60 * 1000);
}

function resolveTokenPriority() {
  const raw = String(process.env.TRAE_TOKEN_PRIORITY || 'pool-first').trim().toLowerCase();
  if (raw === 'local-first' || raw === 'local_first' || raw === 'local') return 'local-first';
  return 'pool-first';
}

function dedupeTokens(tokens = []) {
  const out = [];
  const seen = new Set();
  for (const token of tokens) {
    if (!token || !isLikelyCredentialToken(token.accessToken)) continue;
    const key = normalizeToken(token.accessToken);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(token);
  }
  return out;
}

function toPoolTokenShape(poolToken = null) {
  if (!poolToken || !isLikelyCredentialToken(poolToken.accessToken)) return null;

  const auth = poolToken.authData && typeof poolToken.authData === 'object' ? poolToken.authData : {};
  const endpoint = normalizeEndpointBase(
    auth.endpoint
    || auth.host
    || auth.baseUrl
    || auth.baseURL
    || auth.callback?.host
  );

  return {
    accessToken: normalizeToken(poolToken.accessToken),
    refreshToken: poolToken.refreshToken ? normalizeToken(poolToken.refreshToken) : null,
    source: `pool:${poolToken.label || ACCOUNT_POOL_TYPE}`,
    path: poolToken.sourcePath || '',
    expiresAt: poolToken.expiresAt || auth.expiresAt || null,
    endpoint,
    sdkEndpoint: auth.sdkEndpoint || auth.socketEndpoint || null,
  };
}

async function getPoolActiveToken() {
  try {
    const pool = require('../../accountPool');
    await pool.init();
    const token = await pool.getActiveToken(ACCOUNT_POOL_TYPE);
    return toPoolTokenShape(token);
  } catch {
    return null;
  }
}

async function getTokenCandidates() {
  const localToken = readTraeToken();
  const poolToken = await getPoolActiveToken();
  const currentToken = (_token && _token.accessToken) ? _token : null;

  if (localToken && localToken.accessToken) {
    persistObservedToken(localToken);
  }

  const ordered = resolveTokenPriority() === 'local-first'
    ? [localToken, poolToken, currentToken]
    : [poolToken, localToken, currentToken];
  return dedupeTokens(ordered);
}

async function selectToken({ allowExpired = false } = {}) {
  const candidates = await getTokenCandidates();
  if (candidates.length === 0) {
    return { token: null, fallback: null, candidates: [] };
  }

  const nonExpired = candidates.filter(t => !isTokenExpired(t));
  const token = nonExpired[0] || (allowExpired ? candidates[0] : null);
  if (!token) {
    return { token: null, fallback: null, candidates };
  }

  const fallback = nonExpired.find(t => t.accessToken !== token.accessToken) || null;
  return { token, fallback, candidates };
}

function _stableLabel(source) {
  // Strip accumulated "pool:" / "trae:" prefixes to prevent label growth loop
  const stripped = String(source || '').replace(/^(?:pool:|trae:)+/g, '');
  return `${ACCOUNT_POOL_TYPE}:${stripped || 'pool'}`;
}

function persistObservedToken(token = null) {
  if (!token || !isLikelyCredentialToken(token.accessToken)) return;

  Promise.resolve().then(async () => {
    try {
      const pool = require('../../accountPool');
      await pool.init();
      await pool.saveObservedToken(ACCOUNT_POOL_TYPE, {
        accessToken: token.accessToken,
        refreshToken: token.refreshToken || null,
        sourcePath: token.path || '',
        label: _stableLabel(token.source),
        authData: {
          source: token.source || ACCOUNT_POOL_TYPE,
          path: token.path || '',
          endpoint: token.endpoint || null,
          sdkEndpoint: token.sdkEndpoint || null,
          expiresAt: token.expiresAt || null,
        },
      }, { activateIfNone: true });
      await pool.autoImportObservedCredentials(ACCOUNT_POOL_TYPE);
    } catch {
      // best effort only
    }
  });
}

function discoverModelsFromSnapshots(snapshots = []) {
  const discoveredByKey = new Map();
  const defaultHints = [];

  const addModel = (raw, options = {}) => {
    const normalized = normalizeModelId(raw);
    if (!isLikelyModelId(normalized)) return;
    const key = canonicalModelKey(normalized);
    if (!discoveredByKey.has(key)) discoveredByKey.set(key, normalized);
    if (options.defaultHint) defaultHints.push(normalized);
  };

  const walk = (value, keyHint = '') => {
    if (value == null) return;
    const key = String(keyHint || '').toLowerCase();

    if (typeof value === 'string') {
      for (const id of extractModelIdsFromString(value)) {
        addModel(id, {
          defaultHint: key.includes('default') || key.includes('selected') || key.includes('current') || key.includes('active'),
        });
      }
      return;
    }

    if (Array.isArray(value)) {
      for (const item of value) walk(item, keyHint);
      return;
    }

    if (typeof value === 'object') {
      for (const [k, v] of Object.entries(value)) {
        const lk = String(k || '').toLowerCase();
        if (isLikelyModelId(k)) addModel(k, { defaultHint: lk.includes('default') || lk.includes('selected') });
        if (typeof v === 'string' && (lk.includes('model') || lk.includes('assistant') || lk.includes('engine'))) {
          addModel(v, {
            defaultHint: lk.includes('default') || lk.includes('selected') || lk.includes('current') || lk.includes('active'),
          });
        }
        walk(v, lk);
      }
    }
  };

  for (const snapshot of snapshots) walk(snapshot.data);
  return {
    discoveredModelIds: [...discoveredByKey.values()],
    defaultModelId: defaultHints[0] || null,
  };
}

function buildModelList(discoveredModelIds = [], defaultModelId = null, options = {}) {
  const seen = new Set();
  const catalog = [];
  const defaultKey = canonicalModelKey(defaultModelId);
  const apiModelKeys = new Set((options.apiModelIds || []).map(canonicalModelKey));
  const localModelKeys = new Set((options.localModelIds || []).map(canonicalModelKey));
  let hasDefault = false;

  const sourceFor = (id, fallback = 'builtin') => {
    const key = canonicalModelKey(id);
    if (apiModelKeys.has(key)) return 'official';
    if (localModelKeys.has(key)) return 'local';
    return fallback;
  };

  const addModel = (id, name, isDefault = false, fallbackSource = 'builtin') => {
    const normalized = normalizeModelId(id);
    if (!isLikelyModelId(normalized)) return;
    const key = canonicalModelKey(normalized);
    if (seen.has(key)) return;
    seen.add(key);
    catalog.push({
      id: normalized,
      name: name || modelDisplayName(normalized),
      isDefault: !!isDefault,
      discoverySource: sourceFor(normalized, fallbackSource),
    });
    if (isDefault) hasDefault = true;
  };

  for (const model of KNOWN_MODELS) {
    const key = canonicalModelKey(model.id);
    addModel(model.id, model.name, defaultKey ? key === defaultKey : !!model.isDefault, 'builtin');
  }

  for (const discoveredId of discoveredModelIds) {
    const key = canonicalModelKey(discoveredId);
    addModel(discoveredId, modelDisplayName(discoveredId), defaultKey ? key === defaultKey : false, 'local');
  }

  if (!hasDefault && catalog.length > 0) {
    const fallback = catalog.find(m => canonicalModelKey(m.id) === 'doubao-1.5-pro') || catalog[0];
    fallback.isDefault = true;
  }

  return catalog;
}

function resolveTraeApiBases(tokenData = null) {
  const envList = [
    ...parseList(process.env.TRAE_API_ENDPOINTS),
    ...parseList(process.env.TRAE_API_ENDPOINT),
    ...parseList(process.env.TRAE_API_BASE_URL),
  ];

  const tokenList = [
    tokenData?.endpoint,
    tokenData?.host,
    tokenData?.baseUrl,
    tokenData?.baseURL,
  ];

  const defaults = [
    'https://api.trae.ai/v1',
    'https://api.trae.ai',
  ];

  return dedupe([...envList, ...tokenList, ...defaults].map(normalizeEndpointBase).filter(Boolean));
}

function parseApiModels(payload = {}) {
  const rows = Array.isArray(payload?.data)
    ? payload.data
    : (Array.isArray(payload?.models) ? payload.models : []);

  const out = [];
  const seen = new Set();
  let defaultModelId = null;

  const push = (id, name, isDefault = false) => {
    const normalized = normalizeModelId(id);
    if (!isLikelyModelId(normalized)) return;
    const key = canonicalModelKey(normalized);
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ id: normalized, name: name || modelDisplayName(normalized), isDefault: !!isDefault });
    if (isDefault && !defaultModelId) defaultModelId = normalized;
  };

  for (const row of rows) {
    const id = row?.id || row?.model || row?.modelId;
    const name = row?.name || row?.display_name || row?.displayName || row?.title || id;
    const isDefault = !!(row?.is_default || row?.isDefault || row?.default || row?.selected);
    push(id, name, isDefault);
  }

  if (!defaultModelId && payload?.default_model) {
    const d = normalizeModelId(payload.default_model);
    if (isLikelyModelId(d)) defaultModelId = d;
  }

  return { models: out, defaultModelId };
}

function jsonRequest(url, { method = 'GET', headers = {}, body = null, timeout = 12000 } = {}) {
  return requestJson(
    url,
    {
      method,
      timeout,
      headers: sanitizeOutgoingHeaders(headers),
      body,
    },
    {
      namespace: 'trae',
      envKeys: ['TRAE_HTTP_PROXY', 'TRAE_HTTPS_PROXY', 'TRAE_PROXY', 'TRAE_ALL_PROXY'],
      autoEnvKey: 'TRAE_AUTO_PROXY',
      portsEnvKey: 'TRAE_AUTO_PROXY_PORTS',
    }
  );
}

async function fetchModelsFromApi(tokenData, options = {}) {
  const timeoutMs = Math.max(3000, parseInt(options.timeoutMs || '10000', 10) || 10000);
  const bases = resolveTraeApiBases(tokenData);
  let lastErr = null;

  for (const base of bases) {
    const url = buildModelsUrl(base);
    try {
      const res = await jsonRequest(url, {
        method: 'GET',
        timeout: timeoutMs,
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${tokenData.accessToken}`,
          'x-api-key': tokenData.accessToken,
        },
      });

      if (res.status === 401 || res.status === 403) {
        const authErr = new Error(`Trae auth failed (${res.status})`);
        authErr.code = 'AUTH';
        throw authErr;
      }
      if (res.status < 200 || res.status >= 300) {
        lastErr = new Error(`models endpoint ${url} -> HTTP ${res.status}`);
        continue;
      }

      const parsed = parseApiModels(res.data || {});
      if (parsed.models.length > 0) {
        return { ...parsed, endpoint: base, mode: 'http' };
      }
      lastErr = new Error(`models endpoint ${url} returned empty model list`);
    } catch (err) {
      if (err && err.code === 'AUTH') throw err;
      lastErr = err instanceof Error ? err : new Error(String(err || 'models endpoint error'));
    }
  }

  if (lastErr) throw lastErr;
  throw new Error('models endpoint unavailable');
}

function extractMessageText(payload = {}) {
  if (typeof payload?.choices?.[0]?.message?.content === 'string') return payload.choices[0].message.content;
  if (typeof payload?.choices?.[0]?.delta?.content === 'string') return payload.choices[0].delta.content;
  if (typeof payload?.output_text === 'string') return payload.output_text;
  if (typeof payload?.content === 'string') return payload.content;
  return '';
}

function consumeSseText(text = '', onChunk = null) {
  const chunks = String(text || '').split(/\r?\n/);
  let full = '';

  for (const lineRaw of chunks) {
    const line = String(lineRaw || '').trim();
    if (!line || !line.startsWith('data:')) continue;
    const data = line.slice(5).trim();
    if (!data || data === '[DONE]') continue;
    try {
      const obj = JSON.parse(data);
      const delta = obj?.choices?.[0]?.delta?.content;
      const textPart = typeof delta === 'string'
        ? delta
        : (typeof obj?.choices?.[0]?.message?.content === 'string' ? obj.choices[0].message.content : '');
      if (!textPart) continue;
      full += textPart;
      if (typeof onChunk === 'function') onChunk({ type: 'text', text: textPart });
    } catch {
      // tolerate non-json SSE lines
    }
  }

  return full;
}

async function readWebReadable(stream) {
  if (!stream) return '';
  if (typeof stream.getReader !== 'function') {
    if (typeof stream.on === 'function') {
      return await new Promise((resolve, reject) => {
        let out = '';
        stream.on('data', (chunk) => { out += String(chunk); });
        stream.on('end', () => resolve(out));
        stream.on('error', reject);
      });
    }
    return '';
  }

  const reader = stream.getReader();
  let out = '';
  const decoder = new TextDecoder();
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    out += decoder.decode(value, { stream: true });
  }
  out += decoder.decode();
  return out;
}

function buildTraeMessages(prompt, options = {}) {
  let messages;
  if (Array.isArray(options.messages) && options.messages.length > 0) {
    messages = options.messages.map((m) => ({
      role: m.role || 'user',
      content: (typeof m.content === 'string' || Array.isArray(m.content))
        ? m.content
        : String(m.content || ''),
    }));
  } else {
    messages = [{ role: 'user', content: String(prompt || '') }];
  }
  return attachImagesToOpenAIMessages(messages, options.images || []);
}

function resolveTraeSdkMode() {
  const mode = String(process.env.TRAE_SDK_MODE || 'auto').trim().toLowerCase();
  if (mode === 'off' || mode === 'disable' || mode === 'disabled') return 'off';
  if (mode === 'force' || mode === 'only') return 'force';
  return 'auto';
}

function resolveTraeInstallPaths() {
  const out = [];
  const envInstall = String(process.env.TRAE_INSTALL_PATH || '').trim();
  if (envInstall) out.push(envInstall);

  try {
    const { findInstallation } = require('./ideDetector');
    const detected = findInstallation('trae');
    if (detected) out.push(detected);
  } catch {
    // ignore detector failure
  }

  return dedupe(out);
}

function resolveTraeSdkModuleCandidates() {
  const out = [];

  for (const item of parseList(process.env.TRAE_SDK_MODULE_PATHS || process.env.TRAE_SDK_MODULE_PATH || '')) {
    out.push(item);
  }

  out.push('@byted-icube/trae-network-client');

  const installs = resolveTraeInstallPaths();
  for (const root of installs) {
    out.push(path.join(root, 'resources', 'app', 'node_modules', '@byted-icube', 'trae-network-client'));
  }

  return dedupe(out);
}

function loadTraeSdkModule() {
  if (_sdkLoadTried) return _sdkModule;
  _sdkLoadTried = true;

  const errors = [];
  for (const candidate of resolveTraeSdkModuleCandidates()) {
    try {
      const mod = require(candidate);
      if (mod && typeof mod.fetch === 'function' && typeof mod.ZmqClient === 'function') {
        _sdkModule = mod;
        _sdkLoadError = null;
        return _sdkModule;
      }
      errors.push(`invalid exports: ${candidate}`);
    } catch (err) {
      errors.push(`${candidate}: ${err && err.message ? err.message : String(err)}`);
    }
  }

  _sdkModule = null;
  _sdkLoadError = errors.join(' | ');
  return null;
}

function resolveTraeSdkEndpoints(tokenData = null) {
  const endpoints = [
    ...parseList(process.env.TRAE_SDK_ENDPOINTS || process.env.TRAE_SDK_ENDPOINT || ''),
    tokenData?.sdkEndpoint || '',
    tokenData?.socketEndpoint || '',
    'ipc:///tmp/trae.sock',
  ];

  if (process.platform === 'win32') {
    endpoints.push('ipc://./pipe/trae.sock');
  }

  return dedupe(endpoints.map(s => String(s || '').trim()).filter(Boolean));
}

function getTraeSdkClient(tokenData = null) {
  const sdk = loadTraeSdkModule();
  if (!sdk) return null;

  const endpoints = resolveTraeSdkEndpoints(tokenData);
  if (_sdkClient && _sdkClientEndpoint && endpoints.includes(_sdkClientEndpoint)) {
    return { sdk, client: _sdkClient, endpoint: _sdkClientEndpoint };
  }

  for (const endpoint of endpoints) {
    try {
      const client = new sdk.ZmqClient(endpoint);
      _sdkClient = client;
      _sdkClientEndpoint = endpoint;
      return { sdk, client, endpoint };
    } catch {
      // try next endpoint
    }
  }

  return null;
}

function mergeAttempts(...groups) {
  const out = [];
  for (const group of groups) {
    for (const item of (group || [])) {
      if (!item || typeof item !== 'object') continue;
      out.push(item);
    }
  }
  return out;
}

async function callTraeBySdk(tokenData, prompt, model, options = {}) {
  const sdkCtx = getTraeSdkClient(tokenData);
  if (!sdkCtx) {
    return {
      success: false,
      content: _sdkLoadError ? `Trae SDK unavailable: ${_sdkLoadError}` : 'Trae SDK unavailable',
      provider: 'Trae',
      adapter: 'trae',
      model,
      errorType: 'unavailable',
      attempts: [{ provider: 'Trae(SDK)', success: false, error: 'sdk_unavailable' }],
    };
  }

  const { sdk, client, endpoint: sdkEndpoint } = sdkCtx;
  const useStream = options.stream === true || typeof options.onChunk === 'function';
  const payload = {
    model,
    messages: buildTraeMessages(prompt, options),
    stream: useStream,
    max_tokens: options.maxTokens || 2048,
    temperature: options.temperature || 0.4,
  };

  const attempts = [];
  for (const base of resolveTraeApiBases(tokenData)) {
    const url = buildChatUrl(base);
    try {
      const res = await sdk.fetch(client, url, {
        method: 'POST',
        headers: sanitizeOutgoingHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${tokenData.accessToken}`,
          'x-api-key': tokenData.accessToken,
        }),
        body: JSON.stringify(payload),
      });

      const statusCode = Number(res.status || 0);
      if (statusCode === 401 || statusCode === 403) {
        return {
          success: false,
          content: `Trae SDK auth failed (${statusCode})`,
          provider: 'Trae',
          adapter: 'trae',
          model,
          errorType: 'auth',
          statusCode,
          attempts: mergeAttempts(attempts, [{ provider: `Trae(SDK:${sdkEndpoint})`, success: false, error: `auth failed (${statusCode})`, statusCode }]),
        };
      }

      const contentType = String(res.headers?.get?.('content-type') || '').toLowerCase();
      if (useStream || contentType.includes('text/event-stream')) {
        const sseRaw = await readWebReadable(res.body);
        const content = consumeSseText(sseRaw, options.onChunk).trim();
        if (content) {
          return {
            success: true,
            content,
            provider: `Trae SDK (${model})`,
            adapter: 'trae',
            model,
            attempts: mergeAttempts(attempts, [{ provider: `Trae(SDK:${sdkEndpoint})`, success: true }]),
          };
        }
        attempts.push({ provider: `Trae(SDK:${sdkEndpoint})`, success: false, error: `empty stream from ${url}` });
        continue;
      }

      const bodyText = await res.text();
      let json = null;
      try { json = JSON.parse(bodyText); } catch {
        json = null;
      }

      const text = extractMessageText(json || {}).trim();
      if (text) {
        return {
          success: true,
          content: text,
          provider: `Trae SDK (${model})`,
          adapter: 'trae',
          model,
          attempts: mergeAttempts(attempts, [{ provider: `Trae(SDK:${sdkEndpoint})`, success: true }]),
        };
      }

      attempts.push({
        provider: `Trae(SDK:${sdkEndpoint})`,
        success: false,
        error: json?.error?.message || `invalid response (${statusCode})`,
        statusCode,
      });
    } catch (err) {
      attempts.push({ provider: `Trae(SDK:${sdkEndpoint})`, success: false, error: err?.message || String(err) });
    }
  }

  return {
    success: false,
    content: attempts[attempts.length - 1]?.error || 'Trae SDK request failed',
    provider: 'Trae',
    adapter: 'trae',
    model,
    errorType: 'network',
    attempts,
  };
}

function callTraeByHttp(tokenData, prompt, model, options = {}) {
  const useStream = options.stream === true || typeof options.onChunk === 'function';
  const payload = {
    model,
    messages: buildTraeMessages(prompt, options),
    stream: useStream,
    max_tokens: options.maxTokens || 2048,
    temperature: options.temperature || 0.4,
  };

  const bases = resolveTraeApiBases(tokenData);
  const attempts = [];

  const runOne = (baseIndex) => {
    if (baseIndex >= bases.length) {
      return Promise.resolve({
        success: false,
        content: attempts[attempts.length - 1]?.error || 'Trae HTTP request failed',
        provider: 'Trae',
        adapter: 'trae',
        model,
        errorType: 'network',
        attempts,
      });
    }

    const base = bases[baseIndex];
    const endpoint = buildChatUrl(base);
    return jsonRequest(endpoint, {
      method: 'POST',
      timeout: TIMEOUT_MS,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenData.accessToken}`,
        'x-api-key': tokenData.accessToken,
      },
      body: payload,
    }).then(async (res) => {
      const statusCode = Number(res.status || 0);
      if (statusCode === 401 || statusCode === 403) {
        return {
          success: false,
          content: `Trae auth failed (${statusCode})`,
          provider: 'Trae',
          adapter: 'trae',
          model,
          errorType: 'auth',
          statusCode,
          attempts: mergeAttempts(attempts, [{ provider: 'Trae(HTTP)', success: false, error: `auth failed (${statusCode})`, statusCode }]),
        };
      }
      if (statusCode < 200 || statusCode >= 300) {
        attempts.push({ provider: 'Trae(HTTP)', success: false, error: `HTTP ${statusCode}`, statusCode });
        return runOne(baseIndex + 1);
      }

      const contentType = String(res.headers?.['content-type'] || '').toLowerCase();
      const streamLike = useStream || contentType.includes('text/event-stream');
      const dataText = String(res.raw || '');

      if (streamLike) {
        const streamedText = consumeSseText(dataText, options.onChunk).trim();
        if (streamedText) {
          return {
            success: true,
            content: streamedText,
            provider: `Trae (${model})`,
            adapter: 'trae',
            model,
            attempts: mergeAttempts(attempts, [{ provider: 'Trae(HTTP)', success: true }]),
          };
        }
      }

      const json = res.data || {};
      const text = extractMessageText(json).trim();
      if (text) {
        return {
          success: true,
          content: text,
          provider: `Trae (${model})`,
          adapter: 'trae',
          model,
          attempts: mergeAttempts(attempts, [{ provider: 'Trae(HTTP)', success: true }]),
        };
      }

      const errorText = json.error?.message || `invalid response (${statusCode})`;
      attempts.push({ provider: 'Trae(HTTP)', success: false, error: errorText, statusCode });
      return runOne(baseIndex + 1);
    }).catch(async (err) => {
      attempts.push({ provider: 'Trae(HTTP)', success: false, error: err?.message || String(err) });
      return runOne(baseIndex + 1);
    });
  };

  return runOne(0);
}

function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;

  const localToken = readTraeToken();
  if (localToken) {
    _token = localToken;
    persistObservedToken(localToken);
  } else if (!(_token && _token.accessToken && String(_token.source || '').startsWith('pool:'))) {
    _token = null;
  }

  _available = !!(_token && isLikelyCredentialToken(_token.accessToken));
  if (!_available) _models = [];
  return _available;
}

async function detectAsync(forceRefresh = false) {
  let ok = detect(forceRefresh);
  const selected = await selectToken({ allowExpired: false });
  if (selected.token && selected.token.accessToken) {
    _token = selected.token;
    _available = true;
    ok = true;
    persistObservedToken(_token);
  }
  return ok;
}

async function listModels() {
  detect(true);
  const selected = await selectToken({ allowExpired: true });
  if (selected.token && selected.token.accessToken) {
    _token = selected.token;
    _available = true;
    persistObservedToken(_token);
  }

  if (!_token || !_token.accessToken) {
    // No token — still return known + injected models so users can see what's
    // available (generate() will report auth errors at call time).
    const fallback = KNOWN_MODELS.map(m => ({
      id: m.id,
      name: m.name,
      isDefault: !!m.isDefault,
      provider: 'trae',
      description: 'No Trae token — login in Trae IDE to use this model.',
      discoverySource: 'builtin',
    }));
    if (TRAE_INJECT_MODELS) {
      const existingIds = new Set(fallback.map(m => canonicalModelKey(m.id)));
      for (const im of TRAE_INJECTED_MODELS) {
        if (existingIds.has(canonicalModelKey(im.id))) continue;
        fallback.push({
          id: im.id,
          name: im.name,
          isDefault: false,
          provider: 'trae',
          description: 'No Trae token — login in Trae IDE to use this model.',
          discoverySource: 'injected',
        });
      }
    }
    _models = fallback;
    _available = false;
    return _models;
  }

  if (_models.length > 0 && (Date.now() - _modelsFetchedAt) < MODEL_DISCOVERY_CACHE_MS) {
    return _models;
  }

  const snapshots = readTraeStorageSnapshots();
  const discovered = discoverModelsFromSnapshots(snapshots);
  const localModelIds = discovered.discoveredModelIds || [];
  let apiModels = [];
  let apiDefault = null;
  let officialHit = false;
  let officialEndpoint = '';
  let apiError = '';

  if (_token && _token.accessToken && !isTokenExpired(_token)) {
    try {
      const api = await fetchModelsFromApi(_token);
      apiModels = (api.models || []).map(m => m.id);
      apiDefault = api.defaultModelId || null;
      officialEndpoint = api.endpoint || '';
      officialHit = apiModels.length > 0;
    } catch (err) {
      apiError = err?.message || String(err);
      if (err && err.code === 'AUTH' && selected.fallback && selected.fallback.accessToken && !isTokenExpired(selected.fallback)) {
        _token = selected.fallback;
        persistObservedToken(_token);
        try {
          const retry = await fetchModelsFromApi(_token);
          apiModels = (retry.models || []).map(m => m.id);
          apiDefault = retry.defaultModelId || null;
          officialEndpoint = retry.endpoint || '';
          officialHit = apiModels.length > 0;
          apiError = '';
        } catch (retryErr) {
          apiError = retryErr?.message || apiError;
          if (retryErr && retryErr.code === 'AUTH') {
            _available = false;
            _models = [];
            _modelsFetchedAt = Date.now();
            _lastApiMeta = {
              at: Date.now(),
              endpoint: '',
              officialHit: false,
              officialCount: 0,
              localCount: localModelIds.length,
              mergedCount: 0,
              error: apiError,
              mode: 'http',
            };
            return [];
          }
        }
      } else if (err && err.code === 'AUTH') {
        _available = false;
        _models = [];
        _modelsFetchedAt = Date.now();
        _lastApiMeta = {
          at: Date.now(),
          endpoint: '',
          officialHit: false,
          officialCount: 0,
          localCount: localModelIds.length,
          mergedCount: 0,
          error: apiError,
          mode: 'http',
        };
        return [];
      }
    }
  }

  const merged = buildModelList(
    [...apiModels, ...localModelIds],
    apiDefault || discovered.defaultModelId,
    { apiModelIds: apiModels, localModelIds }
  );

  _models = merged.map(m => ({ ...m, provider: 'trae', description: '' }));

  // Inject models that Trae IDE shows but API omits (same pattern as Kiro).
  if (TRAE_INJECT_MODELS) {
    const existingIds = new Set(_models.map(m => canonicalModelKey(m.id)));
    for (const im of TRAE_INJECTED_MODELS) {
      if (existingIds.has(canonicalModelKey(im.id))) continue;
      _models.push({
        id: im.id,
        name: im.name,
        isDefault: false,
        provider: 'trae',
        description: 'Injected — Trae IDE shows this model but API may not list it.',
        discoverySource: 'injected',
      });
    }
  }

  _available = true;
  _modelsFetchedAt = Date.now();
  _lastApiMeta = {
    at: Date.now(),
    endpoint: officialEndpoint,
    officialHit,
    officialCount: apiModels.length,
    localCount: localModelIds.length,
    mergedCount: _models.length,
    error: apiError,
    mode: 'http',
  };

  return _models;
}

function getStatus() {
  detect(true);
  const modelCount = _models.length || KNOWN_MODELS.length;
  const sdk = loadTraeSdkModule();

  let detail = '';
  if (_available) {
    detail = `Token 有效 (${modelCount} 个模型)`;
  } else {
    detail = '未检测到 Trae token — 请先登录 Trae IDE';
  }

  return {
    name: 'Trae IDE',
    type: 'trae',
    available: _available,
    detail,
    tokenPath: _token?.path || '',
    tokenSource: _token?.source || '',
    sdk: {
      available: !!sdk,
      endpoint: _sdkClientEndpoint || '',
      error: sdk ? '' : (_sdkLoadError || ''),
      mode: resolveTraeSdkMode(),
    },
    officialModels: {
      hit: !!_lastApiMeta.officialHit,
      endpoint: _lastApiMeta.endpoint || '',
      officialCount: _lastApiMeta.officialCount || 0,
      localCount: _lastApiMeta.localCount || 0,
      mergedCount: _lastApiMeta.mergedCount || modelCount,
      error: _lastApiMeta.error || '',
      at: _lastApiMeta.at || 0,
      mode: _lastApiMeta.mode || 'http',
    },
    refreshModels: listModels,
  };
}

async function generate(prompt, options = {}) {
  const selected = await selectToken({ allowExpired: true });
  if (selected.token && selected.token.accessToken) {
    _token = selected.token;
    _available = true;
    persistObservedToken(_token);
  }

  if (!_token || !_token.accessToken) {
    return {
      success: false,
      content: 'Trae token not found',
      provider: 'Trae',
      adapter: 'trae',
      attempts: [{ provider: 'Trae', success: false, error: 'No token' }],
    };
  }

  if (!isLikelyCredentialToken(_token.accessToken)) {
    return {
      success: false,
      content: 'Trae token invalid — please refresh account pool/import data',
      provider: 'Trae',
      adapter: 'trae',
      errorType: 'auth',
      attempts: [{ provider: 'Trae', success: false, error: 'invalid token shape' }],
    };
  }

  if (isTokenExpired(_token)) {
    return {
      success: false,
      content: 'Trae token expired — please re-login in Trae IDE',
      provider: 'Trae',
      adapter: 'trae',
      errorType: 'auth',
      attempts: [{ provider: 'Trae', success: false, error: 'token expired' }],
    };
  }

  const defaultModel = (_models.find(m => m.isDefault) || _models[0] || {}).id || 'doubao-1.5-pro';
  const model = options.model || defaultModel;

  const sdkMode = resolveTraeSdkMode();
  let sdkResult = null;

  if (sdkMode !== 'off') {
    sdkResult = await callTraeBySdk(_token, prompt, model, options);
    if (sdkResult.success) return sdkResult;
    if (sdkMode === 'force') return sdkResult;
  }

  let result = await callTraeByHttp(_token, prompt, model, options);
  if (result.success) {
    if (sdkResult) {
      result.attempts = mergeAttempts(sdkResult.attempts, result.attempts);
    }
    return result;
  }

  if (result.errorType === 'auth' && selected.fallback && selected.fallback.accessToken && !isTokenExpired(selected.fallback)) {
    _token = selected.fallback;
    persistObservedToken(_token);

    const retry = await callTraeByHttp(_token, prompt, model, options);
    if (retry.success) {
      retry.attempts = mergeAttempts(sdkResult?.attempts, result.attempts, retry.attempts);
      return retry;
    }

    return {
      ...retry,
      attempts: mergeAttempts(sdkResult?.attempts, result.attempts, retry.attempts),
    };
  }

  if (sdkResult) {
    result.attempts = mergeAttempts(sdkResult.attempts, result.attempts);
  }
  return result;
}

function destroy() {
  _available = null;
  _token = null;
  _models = [];
  _modelsFetchedAt = 0;
  _lastApiMeta = {
    at: 0,
    endpoint: '',
    officialHit: false,
    officialCount: 0,
    localCount: 0,
    mergedCount: 0,
    error: '',
    mode: 'http',
  };

  try {
    if (_sdkClient && typeof _sdkClient.close === 'function') {
      _sdkClient.close();
    }
  } catch {
    // ignore sdk client close errors
  }
  _sdkClient = null;
  _sdkClientEndpoint = '';
}

/**
 * Build an OpenAI-compatible relay profile from current Trae login state.
 * Used by `proxy switch-center sync --provider trae` and auto sync flow.
 */
async function getRelayProfile(options = {}) {
  const selected = await selectToken({ allowExpired: false });
  if (!selected.token || !selected.token.accessToken) {
    throw new Error('Trae token not found. Please login in Trae IDE first.');
  }
  _token = selected.token;
  _available = true;
  persistObservedToken(_token);

  if (isTokenExpired(_token)) {
    throw new Error('Trae token expired. Please re-login in Trae IDE.');
  }

  const models = await listModels();
  const modelIds = (Array.isArray(models) ? models : [])
    .map(m => normalizeModelId(m?.id || ''))
    .filter(Boolean);
  if (modelIds.length === 0) {
    throw new Error('No Trae models discovered from current account.');
  }

  const defaultModel = normalizeModelId(
    options.defaultModel
    || options.model
    || (models.find(m => m && m.isDefault) || {}).id
    || modelIds[0]
  ) || modelIds[0];

  const endpointOverride = toRelayEndpointBase(options.endpoint || options.baseUrl || options.base || '');
  const endpointFromToken = toRelayEndpointBase(_token.endpoint || '');
  const endpointFromApi = toRelayEndpointBase(resolveTraeApiBases(_token)[0] || '');
  const endpoint = endpointOverride
    || endpointFromToken
    || endpointFromApi
    || 'https://api.trae.ai/v1';

  const modelMap = {};
  for (const id of modelIds) modelMap[id] = id;

  return {
    id: String(options.id || 'trae-auto').trim() || 'trae-auto',
    name: String(options.name || 'Trae Auto').trim() || 'Trae Auto',
    endpoint,
    key: String(options.key || '').trim() || _token.accessToken,
    models: modelIds,
    modelMap,
    defaultModel,
    source: _token.source || '',
    path: _token.path || '',
    generatedAt: new Date().toISOString(),
  };
}

module.exports = { detect, detectAsync, getStatus, listModels, generate, destroy, getRelayProfile };
