/**
 * Reverse Proxy Server — unified OpenAI-compatible API endpoint
 * that routes requests to gateway adapters (IDE + local + relay/API).
 *
 * Endpoints:
 *   POST /v1/chat/completions  — OpenAI-compatible chat (stream/non-stream)
 *   POST /v1/messages          — Anthropic-compatible messages
 *   GET  /v1/models            — Aggregated model list from public adapters
 *   GET  /health               — Health check
 *   GET  /reservoir/stats      — Reservoir cache statistics
 */
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const protocolConverter = require('./protocolConverter');
const modelRouter = require('./modelRouter');
const { getDataHome, getLegacyDataHome } = require('../../utils/dataHome');
const { PROTOCOLS } = protocolConverter;

let _server = null;
let _httpServer = null;
let _httpsServer = null;
let _runtime = null;
let _gateway = null;
let _memoryAuthToken = '';
let _memoryManagedTokens = [];

const KHY_DIR = getDataHome();
const LEGACY_KHY_DIR = getLegacyDataHome();
const PROXY_AUTH_FILE = path.join(KHY_DIR, 'proxy_server_auth.json');
const LEGACY_PROXY_AUTH_FILE = path.join(LEGACY_KHY_DIR, 'proxy_server_auth.json');

function getGateway() {
  if (!_gateway) _gateway = require('./aiGateway');
  return _gateway;
}

const PUBLIC_ADAPTERS = [
  'kiro',
  'cursor',
  'claude',
  'codex',
  'trae',
  'warp',
  'windsurf',
  'vscode',
  'localLLM',
  'ollama',
  'cursor2api',
  'relay_api',
  'api',
];
const ADAPTER_KEY_TO_PREFIX = modelRouter.DEFAULT_ADAPTER_TO_PREFIX;
const WINDSURF_MODEL_CONFIG_PATHS = new Set([
  '/exa.language_server_pb.LanguageServerService/GetCascadeModelConfigs',
  '/exa.api_server_pb.ApiServerService/GetCascadeModelConfigs',
]);
const WINDSURF_PROXY_DEFAULT_MODELS = [
  'gpt-4o',
  'claude-3.5-sonnet',
  'windsurf-cascade',
];

const LOW_TIER_MODEL_PATTERN = /(mini|lite|flash|haiku|small|7b|8b|3b|1\.5b|nano|tiny)/i;
const _reservoir = new Map();

function parseList(raw) {
  return String(raw || '')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function parseBoolean(raw, fallback = false) {
  if (raw === undefined || raw === null || raw === '') return fallback;
  if (typeof raw === 'boolean') return raw;
  const normalized = String(raw).trim().toLowerCase();
  if (['1', 'true', 'yes', 'on', 'y'].includes(normalized)) return true;
  if (['0', 'false', 'no', 'off', 'n'].includes(normalized)) return false;
  return fallback;
}

function shouldExposeRawRelayModels() {
  return parseBoolean(process.env.PROXY_EXPOSE_RAW_RELAY_MODELS, true);
}

function toPort(raw, fallback = null) {
  if (raw === undefined || raw === null || raw === '') return fallback;
  const n = parseInt(String(raw), 10);
  if (!Number.isFinite(n) || n <= 0 || n > 65535) return fallback;
  return n;
}

function loadTlsCredentials(options = {}) {
  const certPem = String(options.tlsCertPem ?? process.env.PROXY_TLS_CERT_PEM ?? '').trim();
  const keyPem = String(options.tlsKeyPem ?? process.env.PROXY_TLS_KEY_PEM ?? '').trim();
  if (certPem && keyPem) {
    return {
      cert: certPem,
      key: keyPem,
      source: 'env-pem',
      certFile: '',
      keyFile: '',
    };
  }

  const certFile = String(options.tlsCertFile ?? process.env.PROXY_TLS_CERT_FILE ?? '').trim();
  const keyFile = String(options.tlsKeyFile ?? process.env.PROXY_TLS_KEY_FILE ?? '').trim();
  if (certFile || keyFile) {
    if (!certFile || !keyFile) {
      throw new Error('HTTPS 需要同时提供证书与私钥：PROXY_TLS_CERT_FILE + PROXY_TLS_KEY_FILE');
    }
    if (!fs.existsSync(certFile)) {
      throw new Error(`HTTPS 证书文件不存在: ${certFile}`);
    }
    if (!fs.existsSync(keyFile)) {
      throw new Error(`HTTPS 私钥文件不存在: ${keyFile}`);
    }
    return {
      cert: fs.readFileSync(certFile, 'utf8'),
      key: fs.readFileSync(keyFile, 'utf8'),
      source: 'file',
      certFile,
      keyFile,
    };
  }

  return null;
}

function buildRuntimeStatus(config = {}, authToken = '') {
  const host = config.host || '127.0.0.1';
  const httpInfo = config.http?.enabled
    ? {
      enabled: true,
      port: config.http.port,
      host,
      url: `http://${host}:${config.http.port}`,
    }
    : { enabled: false, port: null, host, url: '' };
  const httpsInfo = config.https?.enabled
    ? {
      enabled: true,
      port: config.https.port,
      host,
      url: `https://${host}:${config.https.port}`,
      certSource: config.https.certSource || '',
      certFile: config.https.certFile || '',
      keyFile: config.https.keyFile || '',
    }
    : { enabled: false, port: null, host, url: '', certSource: '', certFile: '', keyFile: '' };
  const mode = httpInfo.enabled && httpsInfo.enabled
    ? 'dual'
    : (httpsInfo.enabled ? 'https-only' : 'http-only');
  return {
    mode,
    host,
    http: httpInfo,
    https: httpsInfo,
    authTokenMasked: maskToken(authToken),
  };
}

function resolveStartConfig(portOrOptions = null) {
  const options = (portOrOptions && typeof portOrOptions === 'object')
    ? { ...portOrOptions }
    : { port: portOrOptions };

  const host = String(options.host || process.env.PROXY_HOST || '127.0.0.1').trim() || '127.0.0.1';
  const basePort = toPort(options.port, toPort(process.env.PROXY_PORT, 9100)) || 9100;

  const httpsOnly = parseBoolean(
    options.httpsOnly ?? options.https_only ?? process.env.PROXY_HTTPS_ONLY,
    false
  );
  let httpsEnabled = parseBoolean(options.https ?? process.env.PROXY_ENABLE_HTTPS, false);
  if (options.tlsCertFile || options.tlsKeyFile || options.tlsCertPem || options.tlsKeyPem) {
    httpsEnabled = true;
  }
  if (httpsOnly) httpsEnabled = true;

  let httpEnabled = parseBoolean(options.http ?? process.env.PROXY_ENABLE_HTTP, true);
  if (httpsOnly) httpEnabled = false;

  if (!httpEnabled && !httpsEnabled) {
    throw new Error('HTTP 与 HTTPS 不能同时禁用');
  }

  const httpPort = httpEnabled ? toPort(options.httpPort, basePort) : null;
  const httpsPort = httpsEnabled
    ? toPort(
      options.httpsPort,
      toPort(
        process.env.PROXY_HTTPS_PORT,
        httpsOnly
          ? basePort
          : (httpEnabled ? Math.min(basePort + 1, 65535) : basePort)
      )
    )
    : null;

  if (httpEnabled && !httpPort) throw new Error('HTTP 端口无效');
  if (httpsEnabled && !httpsPort) throw new Error('HTTPS 端口无效');
  if (httpEnabled && httpsEnabled && httpPort === httpsPort) {
    throw new Error(`HTTP 与 HTTPS 端口冲突: ${httpPort}`);
  }

  let tls = null;
  if (httpsEnabled) {
    tls = loadTlsCredentials(options);
    if (!tls) {
      throw new Error(
        'HTTPS 已启用，但未配置证书。请设置 PROXY_TLS_CERT_FILE/PROXY_TLS_KEY_FILE 或 PROXY_TLS_CERT_PEM/PROXY_TLS_KEY_PEM'
      );
    }
  }

  return {
    host,
    http: {
      enabled: httpEnabled,
      port: httpPort,
    },
    https: {
      enabled: httpsEnabled,
      port: httpsPort,
      cert: tls?.cert || '',
      key: tls?.key || '',
      certSource: tls?.source || '',
      certFile: tls?.certFile || '',
      keyFile: tls?.keyFile || '',
    },
  };
}

function closeServer(server) {
  return new Promise((resolve) => {
    if (!server) {
      resolve();
      return;
    }
    try {
      server.close(() => resolve());
    } catch {
      resolve();
    }
  });
}

function listenServer(server, port, host) {
  return new Promise((resolve, reject) => {
    const onError = (err) => {
      server.off('listening', onListening);
      reject(err);
    };
    const onListening = () => {
      server.off('error', onError);
      resolve();
    };
    server.once('error', onError);
    server.once('listening', onListening);
    server.listen(port, host);
  });
}

function normalizeAuthToken(raw, { allowEmpty = true } = {}) {
  const token = String(raw || '').trim();
  if (!token) return allowEmpty ? '' : null;

  let suffix = '';
  if (/^khy-/i.test(token)) {
    suffix = token.slice(4);
  } else if (/^khy/i.test(token)) {
    suffix = token.slice(3).replace(/^[-_]+/, '');
  } else {
    suffix = token;
  }
  suffix = String(suffix || '').trim();
  if (!suffix) return allowEmpty ? '' : null;
  return `khy-${suffix}`;
}

function generateAuthToken() {
  return `khy-${crypto.randomBytes(24).toString('hex')}`;
}

function maskToken(raw) {
  const token = String(raw || '').trim();
  if (!token) return '(empty)';
  if (token.length <= 10) return `${token.slice(0, 3)}***`;
  return `${token.slice(0, 6)}***${token.slice(-4)}`;
}

function normalizeTokenId(raw, fallback = '') {
  const id = String(raw || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
  return id || fallback;
}

function generateTokenId(existing = new Set()) {
  for (let i = 0; i < 10; i += 1) {
    const id = `tk_${crypto.randomBytes(4).toString('hex')}`;
    if (!existing.has(id)) return id;
  }
  return `tk_${Date.now().toString(36)}`;
}

function normalizeManagedTokens(rawTokens) {
  const rows = Array.isArray(rawTokens) ? rawTokens : [];
  const usedIds = new Set();
  const now = new Date().toISOString();
  const out = [];

  for (const row of rows) {
    const token = normalizeAuthToken(row?.token, { allowEmpty: true });
    if (!token) continue;

    let id = normalizeTokenId(row?.id);
    if (!id || usedIds.has(id)) {
      id = generateTokenId(usedIds);
    }
    usedIds.add(id);

    const label = String(row?.label || row?.name || '').trim().slice(0, 120);
    const enabled = row?.enabled !== false;
    out.push({
      id,
      label,
      token,
      enabled,
      createdAt: row?.createdAt || now,
      updatedAt: row?.updatedAt || row?.createdAt || now,
    });
  }

  return out;
}

function toManagedTokenView(item) {
  return {
    id: item.id,
    label: item.label || '',
    enabled: item.enabled !== false,
    tokenMasked: maskToken(item.token),
    createdAt: item.createdAt || null,
    updatedAt: item.updatedAt || null,
  };
}

function loadAuthConfig() {
  const candidates = [PROXY_AUTH_FILE, LEGACY_PROXY_AUTH_FILE];
  for (const filePath of candidates) {
    try {
      if (!fs.existsSync(filePath)) continue;
      const raw = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      return {
        authToken: normalizeAuthToken(raw.authToken, { allowEmpty: true }),
        managedTokens: normalizeManagedTokens(raw.managedTokens),
        updatedAt: raw.updatedAt || null,
      };
    } catch {
      // try next file
    }
  }
  return {
    authToken: _memoryAuthToken || '',
    managedTokens: normalizeManagedTokens(_memoryManagedTokens),
  };
}

function saveAuthConfig(next = {}) {
  const current = loadAuthConfig();
  const authToken = normalizeAuthToken(
    next.authToken !== undefined ? next.authToken : current.authToken,
    { allowEmpty: true }
  );
  const merged = {
    ...current,
    ...next,
    authToken,
    managedTokens: normalizeManagedTokens(
      next.managedTokens !== undefined ? next.managedTokens : current.managedTokens
    ),
    updatedAt: new Date().toISOString(),
  };
  _memoryAuthToken = String(merged.authToken || '');
  _memoryManagedTokens = normalizeManagedTokens(merged.managedTokens);
  try {
    ensureDir(path.dirname(PROXY_AUTH_FILE));
    fs.writeFileSync(PROXY_AUTH_FILE, JSON.stringify(merged, null, 2), 'utf-8');
  } catch {
    // Read-only env fallback: keep token for current process lifecycle.
    _memoryAuthToken = String(merged.authToken || '');
    _memoryManagedTokens = normalizeManagedTokens(merged.managedTokens);
  }
  return merged;
}

function resolvePrimaryAuthToken() {
  const envToken = normalizeAuthToken(process.env.PROXY_AUTH_TOKEN, { allowEmpty: true });
  if (envToken) {
    process.env.PROXY_AUTH_TOKEN = envToken;
    return { token: envToken, source: 'env', generated: false };
  }

  const cfg = loadAuthConfig();
  if (cfg.authToken) {
    return { token: cfg.authToken, source: 'persisted', generated: false };
  }

  const generated = generateAuthToken();
  saveAuthConfig({ authToken: generated });
  return { token: generated, source: 'generated', generated: true };
}

function setAuthToken(rawToken) {
  const token = normalizeAuthToken(rawToken, { allowEmpty: false });
  if (!token) {
    throw new Error('token 不能为空');
  }
  saveAuthConfig({ authToken: token });
  return {
    authToken: token,
    authTokenMasked: maskToken(token),
  };
}

function rotateAuthToken() {
  const token = generateAuthToken();
  saveAuthConfig({ authToken: token });
  return {
    authToken: token,
    authTokenMasked: maskToken(token),
  };
}

function getAuthStatus() {
  const primary = resolvePrimaryAuthToken();
  const cfg = loadAuthConfig();
  const managedTokens = normalizeManagedTokens(cfg.managedTokens);
  const authTokens = buildAuthTokenSet(primary.token, { managedTokens });
  return {
    authToken: primary.token,
    authTokenMasked: maskToken(primary.token),
    source: primary.source,
    generated: primary.generated,
    tokenCount: authTokens.size,
    managedTokenCount: managedTokens.length,
    managedTokenEnabledCount: managedTokens.filter(t => t.enabled !== false).length,
    managedTokens: managedTokens.map(toManagedTokenView),
  };
}

function buildAuthTokenSet(primaryToken, { managedTokens = [] } = {}) {
  const tokens = new Set();
  const primary = normalizeAuthToken(primaryToken, { allowEmpty: true });
  if (primary) tokens.add(primary);
  for (const t of parseList(process.env.PROXY_AUTH_TOKENS)) {
    const n = normalizeAuthToken(t, { allowEmpty: true });
    if (n) tokens.add(n);
  }
  for (const row of normalizeManagedTokens(managedTokens)) {
    if (row.enabled === false) continue;
    const n = normalizeAuthToken(row.token, { allowEmpty: true });
    if (n) tokens.add(n);
  }
  return tokens;
}

function listManagedTokens() {
  const cfg = loadAuthConfig();
  const rows = normalizeManagedTokens(cfg.managedTokens);
  return rows.map(toManagedTokenView);
}

function createManagedToken({ label = '', token = '', enabled = true } = {}) {
  const cfg = loadAuthConfig();
  const rows = normalizeManagedTokens(cfg.managedTokens);
  const used = new Set(rows.map(r => r.id));
  const createdToken = normalizeAuthToken(token, { allowEmpty: true }) || generateAuthToken();
  const entry = {
    id: generateTokenId(used),
    label: String(label || '').trim().slice(0, 120),
    token: createdToken,
    enabled: enabled !== false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  rows.push(entry);
  saveAuthConfig({ managedTokens: rows });
  return {
    ...toManagedTokenView(entry),
    token: entry.token,
  };
}

function setManagedTokenEnabled(tokenId, enabled) {
  const id = normalizeTokenId(tokenId);
  if (!id) throw new Error('token id 不能为空');
  const cfg = loadAuthConfig();
  const rows = normalizeManagedTokens(cfg.managedTokens);
  const idx = rows.findIndex(r => r.id === id);
  if (idx < 0) throw new Error(`未找到 token: ${tokenId}`);
  rows[idx] = {
    ...rows[idx],
    enabled: enabled !== false,
    updatedAt: new Date().toISOString(),
  };
  saveAuthConfig({ managedTokens: rows });
  return toManagedTokenView(rows[idx]);
}

function deleteManagedToken(tokenId) {
  const id = normalizeTokenId(tokenId);
  if (!id) throw new Error('token id 不能为空');
  const cfg = loadAuthConfig();
  const rows = normalizeManagedTokens(cfg.managedTokens);
  const idx = rows.findIndex(r => r.id === id);
  if (idx < 0) throw new Error(`未找到 token: ${tokenId}`);
  const removed = rows[idx];
  rows.splice(idx, 1);
  saveAuthConfig({ managedTokens: rows });
  return toManagedTokenView(removed);
}

function rotateManagedToken(tokenId, nextToken = '') {
  const id = normalizeTokenId(tokenId);
  if (!id) throw new Error('token id 不能为空');
  const cfg = loadAuthConfig();
  const rows = normalizeManagedTokens(cfg.managedTokens);
  const idx = rows.findIndex(r => r.id === id);
  if (idx < 0) throw new Error(`未找到 token: ${tokenId}`);
  const token = normalizeAuthToken(nextToken, { allowEmpty: true }) || generateAuthToken();
  rows[idx] = {
    ...rows[idx],
    token,
    updatedAt: new Date().toISOString(),
  };
  saveAuthConfig({ managedTokens: rows });
  return {
    ...toManagedTokenView(rows[idx]),
    token,
  };
}

function normalizeText(input) {
  return String(input || '')
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function isLowTierRoute(route, options) {
  const adapter = String(route?.adapterKey || '').toLowerCase();
  if (adapter === 'localllm' || adapter === 'ollama') return true;
  const model = String(options?.model || route?.modelId || '').toLowerCase();
  return LOW_TIER_MODEL_PATTERN.test(model);
}

function optimizeLowTier(route, prompt, options) {
  if (!isLowTierRoute(route, options)) {
    return { prompt, options };
  }

  const maxChars = Math.max(2000, parseInt(process.env.PROXY_LOW_MODEL_MAX_CHARS || '12000', 10) || 12000);
  const cleanedMessages = Array.isArray(options.messages)
    ? options.messages
      .map(m => ({ ...m, content: normalizeText(m.content) }))
      .filter(m => m.content.length > 0)
    : [];

  let total = cleanedMessages.reduce((sum, m) => sum + m.content.length, 0);
  if (total > maxChars && cleanedMessages.length > 1) {
    // Keep latest messages for smaller models.
    const kept = [];
    for (let i = cleanedMessages.length - 1; i >= 0; i--) {
      const msg = cleanedMessages[i];
      if (msg.content.length > maxChars && kept.length === 0) {
        kept.unshift({ ...msg, content: msg.content.slice(-maxChars) });
        total = maxChars;
        break;
      }
      if (total > maxChars) {
        total -= msg.content.length;
        continue;
      }
      kept.unshift(msg);
    }
    cleanedMessages.length = 0;
    cleanedMessages.push(...kept);
  }

  const system = normalizeText(options.system || '');
  const nextPrompt = normalizeText([
    system ? `System: ${system}` : '',
    ...cleanedMessages.map(m => `${m.role}: ${m.content}`),
  ].filter(Boolean).join('\n'));

  return {
    prompt: nextPrompt || prompt,
    options: {
      ...options,
      system: system || undefined,
      messages: cleanedMessages,
    },
  };
}

function getReservoirConfig() {
  return {
    enabled: process.env.PROXY_RESERVOIR_ENABLED !== 'false',
    ttlMs: Math.max(1000, parseInt(process.env.PROXY_RESERVOIR_TTL_MS || '300000', 10) || 300000),
    maxEntries: Math.max(50, parseInt(process.env.PROXY_RESERVOIR_MAX_ENTRIES || '500', 10) || 500),
  };
}

function makeReservoirKey(kind, route, prompt, options) {
  return JSON.stringify({
    k: kind,
    a: route?.adapterKey || 'auto',
    m: options?.model || '',
    t: options?.temperature ?? null,
    n: options?.maxTokens ?? null,
    s: options?.system || '',
    x: options?.messages || [],
    p: prompt || '',
  });
}

function reservoirGet(key) {
  const cfg = getReservoirConfig();
  if (!cfg.enabled) return null;

  const item = _reservoir.get(key);
  if (!item) return null;
  if (Date.now() > item.expiresAt) {
    _reservoir.delete(key);
    return null;
  }
  return item.value;
}

function reservoirSet(key, value) {
  const cfg = getReservoirConfig();
  if (!cfg.enabled) return;

  _reservoir.set(key, {
    value,
    expiresAt: Date.now() + cfg.ttlMs,
  });

  if (_reservoir.size > cfg.maxEntries) {
    const overflow = _reservoir.size - cfg.maxEntries;
    let i = 0;
    for (const k of _reservoir.keys()) {
      _reservoir.delete(k);
      i += 1;
      if (i >= overflow) break;
    }
  }
}

function reservoirGetDegraded(kind, route) {
  const cfg = getReservoirConfig();
  if (!cfg.enabled || _reservoir.size === 0) return null;

  const desiredAdapter = route?.adapterKey || 'auto';
  const entries = Array.from(_reservoir.entries()).reverse();

  for (const [rawKey, item] of entries) {
    try {
      const key = JSON.parse(rawKey);
      if (key.k !== kind) continue;
      if (desiredAdapter !== 'auto' && key.a !== desiredAdapter) continue;
      return {
        value: item.value,
        stale: Date.now() > item.expiresAt,
        adapter: key.a || 'auto',
      };
    } catch {
      // skip malformed key
    }
  }
  return null;
}

function withFallbackMeta(payload, reason, source = 'reservoir') {
  if (!payload || typeof payload !== 'object') return payload;
  return {
    ...payload,
    khyFallback: {
      mode: 'degraded',
      source,
      reason: String(reason || 'upstream_unavailable'),
      generatedAt: new Date().toISOString(),
    },
  };
}

function extractOpenAIContent(responseBody) {
  try {
    return String(responseBody?.choices?.[0]?.message?.content || '').trim();
  } catch {
    return '';
  }
}

/**
 * Strip real IP headers from outgoing requests to prevent IP leaking.
 * Called before forwarding to IDE adapters.
 */
function sanitizeIpHeaders() {
  // Set fake forwarded headers to mask real IP
  const fakeIp = `10.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
  return {
    'X-Forwarded-For': fakeIp,
    'X-Real-IP': fakeIp,
    'CF-Connecting-IP': fakeIp,
    'True-Client-IP': fakeIp,
  };
}

function normalizeModelId(raw) {
  return String(raw || '').trim().replace(/^['"]|['"]$/g, '');
}

function isWindsurfModelConfigPath(pathname = '') {
  return WINDSURF_MODEL_CONFIG_PATHS.has(String(pathname || ''));
}

function parseWindsurfProxyModelOverrides() {
  return parseList(
    process.env.WINDSURF_PROXY_MODELS
    || process.env.WINDSURF_MODELS
    || ''
  )
    .map(normalizeModelId)
    .filter(Boolean);
}

function dedupeModels(models = []) {
  const out = [];
  const seen = new Set();
  for (const model of models) {
    const id = normalizeModelId(model);
    const key = id.toLowerCase();
    if (!id || seen.has(key)) continue;
    seen.add(key);
    out.push(id);
  }
  return out;
}

function appendVarint(buf, value) {
  let v = BigInt(Math.max(0, Number(value) || 0));
  while (v >= 0x80n) {
    buf.push(Number((v & 0x7fn) | 0x80n));
    v >>= 7n;
  }
  buf.push(Number(v));
}

function appendTag(buf, fieldNum, wireType) {
  appendVarint(buf, (fieldNum << 3) | wireType);
}

function appendStringField(buf, fieldNum, text) {
  const payload = Buffer.from(String(text || ''), 'utf8');
  appendTag(buf, fieldNum, 2);
  appendVarint(buf, payload.length);
  for (const b of payload) buf.push(b);
}

function appendBoolField(buf, fieldNum, flag) {
  appendTag(buf, fieldNum, 0);
  buf.push(flag ? 1 : 0);
}

function encodeWindsurfClientModelConfig(modelId, recommended = false) {
  const msg = [];
  appendStringField(msg, 1, modelId); // label
  appendStringField(msg, 22, modelId); // model_uid
  if (recommended) appendBoolField(msg, 11, true); // is_recommended
  return Buffer.from(msg);
}

function encodeWindsurfModelConfigResponse(models = []) {
  const out = [];
  const list = dedupeModels(models);
  for (let i = 0; i < list.length; i += 1) {
    const inner = encodeWindsurfClientModelConfig(list[i], i === 0);
    appendTag(out, 1, 2); // repeated client_model_configs
    appendVarint(out, inner.length);
    for (const b of inner) out.push(b);
  }
  return Buffer.from(out);
}

async function resolveWindsurfProxyModels() {
  const overridden = parseWindsurfProxyModelOverrides();
  if (overridden.length > 0) return dedupeModels(overridden);

  try {
    const gw = getGateway();
    if (!gw._initialized) await gw.init();
    const models = await gw.listModels('windsurf');
    if (Array.isArray(models) && models.length > 0) {
      const prioritized = [
        ...models.filter(m => m && m.isDefault),
        ...models.filter(m => m && !m.isDefault),
      ];
      const resolved = prioritized
        .map(m => normalizeModelId(m?.id))
        .filter(Boolean);
      if (resolved.length > 0) return dedupeModels(resolved);
    }
  } catch {
    // fallback to defaults
  }

  return WINDSURF_PROXY_DEFAULT_MODELS.slice();
}

async function handleWindsurfModelConfigs(req, res) {
  const models = await resolveWindsurfProxyModels();
  const payload = encodeWindsurfModelConfigResponse(models);
  const reqContentType = String(req.headers['content-type'] || '').toLowerCase();

  if (reqContentType.includes('application/json')) {
    return sendJson(res, 200, {
      ok: true,
      models,
      source: 'khy-windsurf-proxy',
    });
  }

  res.writeHead(200, {
    'Content-Type': reqContentType || 'application/proto',
    'Access-Control-Allow-Origin': process.env.PROXY_CORS_ORIGINS || '*',
    'X-KHY-Intercepted': 'GetCascadeModelConfigs',
    'Content-Length': payload.length,
  });
  res.end(payload);
}

/**
 * Parse request body as JSON.
 */
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => { data += chunk; });
    req.on('end', () => {
      try { resolve(JSON.parse(data)); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

/**
 * Send JSON response.
 */
function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': process.env.PROXY_CORS_ORIGINS || '*',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function flattenMessageContent(content) {
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  return content
    .map((part) => {
      if (typeof part === 'string') return part;
      if (part?.text) return String(part.text);
      if (part?.type === 'image_url') return '[image]';
      return '';
    })
    .filter(Boolean)
    .join('\n');
}

async function generateByRoute(gw, route, prompt, options) {
  const mergedOptions = {
    ...options,
    preferredAdapter: route?.preferredAdapter || options.preferredAdapter || undefined,
    preferredModel: route?.preferredModel || options.preferredModel || undefined,
    strictPreferred: route?.strictPreferred !== undefined
      ? !!route.strictPreferred
      : options.strictPreferred,
  };
  return gw.generate(prompt, mergedOptions);
}

function recordTrainingSample(prompt, reply, meta = {}) {
  const p = String(prompt || '').trim();
  const r = String(reply || '').trim();
  if (!p || !r) return;
  try {
    const training = require('../modelTrainingService');
    const saved = training.recordConversation(p, r, {
      provider: meta.provider || 'proxy',
      model: meta.model || '',
      quality: 'neutral',
      tokenCount: meta.tokenCount || 0,
    });
    if (saved && !saved.accepted && String(process.env.PROXY_TRAINING_DEBUG || '').toLowerCase() === 'true') {
      console.warn('[proxyServer] training sample skipped', {
        reasons: saved.reasons || [],
        path: saved.path || '',
      });
    }
  } catch { /* best-effort */ }
  try {
    const habits = require('../usageHabitService');
    habits.recordModelUsage(meta.adapter || meta.provider || 'proxy', meta.model || '', 'conversation', 1);
    habits.recordInteraction(p);
  } catch { /* best-effort */ }
}

/**
 * Handle POST /v1/chat/completions
 */
async function handleChatCompletions(req, res) {
  const body = await parseBody(req);
  const {
    messages: rawMsgs,
    model,
    stream,
    temperature,
    max_tokens: maxTokens,
    max_completion_tokens: maxCompletionTokens,
  } = body;

  if (!rawMsgs?.length) return sendJson(res, 400, { error: { message: 'messages required' } });

  // Extract system prompt and convert to flat prompt
  let system;
  const messages = [];
  for (const m of rawMsgs) {
    if (m.role === 'system') {
      system = flattenMessageContent(m.content);
      continue;
    }
    messages.push({ role: m.role, content: flattenMessageContent(m.content) });
  }

  const prompt = [
    system ? `System: ${system}` : '',
    ...messages.map(m => `${m.role}: ${m.content}`),
  ].filter(Boolean).join('\n');

  const route = modelRouter.resolveModelRoute({ model });
  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  const generateOptions = {
    system: system || undefined,
    messages,
    model: route.modelId || undefined,
    temperature: typeof temperature === 'number' ? temperature : undefined,
    maxTokens: typeof maxTokens === 'number'
      ? maxTokens
      : (typeof maxCompletionTokens === 'number' ? maxCompletionTokens : undefined),
  };
  const optimized = optimizeLowTier(route, prompt, generateOptions);
  const runPrompt = optimized.prompt;
  const runOptions = optimized.options;

  if (stream) {
    // SSE streaming response
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': process.env.PROXY_CORS_ORIGINS || '*',
    });

    const responseId = `chatcmpl-${crypto.randomUUID()}`;
    const created = Math.floor(Date.now() / 1000);
    const streamModel = model
      || (route.adapterKey ? `${ADAPTER_KEY_TO_PREFIX[route.adapterKey] || route.adapterKey}/${route.modelId || 'default'}` : (route.modelId || 'default'));

    const sendSSE = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    try {
      const result = await generateByRoute(gw, route, runPrompt, {
        ...runOptions,
        onChunk: (chunk) => {
          if (chunk.type === 'text') {
            sendSSE({
              id: responseId, object: 'chat.completion.chunk', created,
              model: streamModel,
              choices: [{ index: 0, delta: { content: chunk.text }, finish_reason: null }],
            });
          }
        },
      });

      if (!result.success) {
        throw new Error(result.error || result.content || 'Generation failed');
      }

      const responseModel = model
        || (route.adapterKey ? `${ADAPTER_KEY_TO_PREFIX[route.adapterKey] || route.adapterKey}/${result.model || route.modelId || 'default'}` : (result.model || 'default'));

      recordTrainingSample(runPrompt, result.content, {
        provider: result.provider || route.adapterKey || 'proxy',
        adapter: route.adapterKey || result.adapter || null,
        model: responseModel,
      });

      sendSSE({
        id: responseId, object: 'chat.completion.chunk', created,
        model: responseModel,
        choices: [{ index: 0, delta: {}, finish_reason: 'stop' }],
      });
      res.write('data: [DONE]\n\n');
      res.end();
    } catch (err) {
      res.write(`data: ${JSON.stringify({ error: { message: err.message } })}\n\n`);
      res.end();
    }
  } else {
    // Non-streaming
    try {
      const reservoirKey = makeReservoirKey('chat', route, runPrompt, runOptions);
      const cached = reservoirGet(reservoirKey);
      if (cached) {
        return sendJson(res, 200, cached);
      }

      const result = await generateByRoute(gw, route, runPrompt, runOptions);

      if (!result.success) {
        return sendJson(res, 500, { error: { message: result.error || result.content || 'Generation failed' } });
      }

      const responseModel = model
        || (route.adapterKey ? `${ADAPTER_KEY_TO_PREFIX[route.adapterKey] || route.adapterKey}/${result.model || route.modelId || 'default'}` : (result.model || 'default'));

      const responseBody = {
        id: `chatcmpl-${crypto.randomUUID()}`,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model: responseModel,
        choices: [{ index: 0, message: { role: 'assistant', content: result.content }, finish_reason: 'stop' }],
        usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
      };
      recordTrainingSample(runPrompt, result.content, {
        provider: result.provider || route.adapterKey || 'proxy',
        adapter: route.adapterKey || result.adapter || null,
        model: responseModel,
      });
      reservoirSet(reservoirKey, responseBody);
      sendJson(res, 200, responseBody);
    } catch (err) {
      sendJson(res, 500, { error: { message: err.message } });
    }
  }
}

/**
 * Handle multi-protocol requests — converts input protocol to canonical,
 * generates via gateway, then converts response back to source protocol.
 */
async function handleMultiProtocol(req, res, sourceProtocol) {
  const body = await parseBody(req);
  const { canonical, detectedProtocol } = protocolConverter.convertRequest(body, sourceProtocol);
  const route = modelRouter.resolveModelRoute({ model: canonical.model || null });

  // Preserve structured messages for adapters that support multi-turn
  const structuredMessages = canonical.messages.map(m => ({
    role: m.role,
    content: typeof m.content === 'string' ? m.content : (Array.isArray(m.content) ? m.content.map(b => b.text || '').join('') : ''),
  }));

  // Flat prompt as fallback for adapters that only accept a string
  const prompt = [
    canonical.system ? `System: ${canonical.system}` : '',
    ...structuredMessages.map(m => `${m.role}: ${m.content}`),
  ].filter(Boolean).join('\n');

  const generateOptions = {
    system: canonical.system || undefined,
    messages: structuredMessages,
    model: route.modelId || undefined,
    temperature: canonical.metadata.temperature || undefined,
    maxTokens: canonical.metadata.maxTokens || undefined,
    tools: canonical.tools || undefined,
  };
  const optimized = optimizeLowTier(route, prompt, generateOptions);
  const runPrompt = optimized.prompt;
  const runOptions = optimized.options;

  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  const outputProtocol = detectedProtocol;

  if (canonical.metadata.stream) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': process.env.PROXY_CORS_ORIGINS || '*',
    });

    let fullContent = '';
    try {
      const result = await generateByRoute(gw, route, runPrompt, {
        ...runOptions,
        onChunk: (chunk) => {
          if (chunk.type === 'text') {
            fullContent += chunk.text;
            res.write(`data: ${JSON.stringify({ type: 'content_block_delta', delta: { text: chunk.text } })}\n\n`);
          }
        },
      });
      if (!result.success) {
        throw new Error(result.error || result.content || 'Generation failed');
      }
      if (!fullContent && result.content) {
        fullContent = result.content;
      }

      // Build canonical response and convert to output protocol
      const resolvedModel = canonical.model || result.model || 'default';
      const canonicalResp = { id: `msg_${crypto.randomUUID()}`, model: resolvedModel, content: fullContent, thinking: null, toolCalls: null, stopReason: 'end_turn', usage: { inputTokens: 0, outputTokens: 0, totalTokens: 0 } };
      recordTrainingSample(runPrompt, fullContent, {
        provider: result.provider || route.adapterKey || 'proxy',
        adapter: route.adapterKey || result.adapter || null,
        model: resolvedModel,
      });
      const formatted = protocolConverter.convertResponse(canonicalResp, outputProtocol);
      res.write(`data: ${JSON.stringify(formatted)}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    } catch (err) {
      res.write(`data: ${JSON.stringify({ error: { message: err.message } })}\n\n`);
      res.end();
    }
  } else {
    try {
      const reservoirKey = makeReservoirKey(`proto:${sourceProtocol}`, route, runPrompt, runOptions);
      const cached = reservoirGet(reservoirKey);
      if (cached) {
        return sendJson(res, 200, cached);
      }

      const result = await generateByRoute(gw, route, runPrompt, runOptions);
      if (!result.success) {
        return sendJson(res, 500, { error: { message: result.error || result.content || 'Generation failed' } });
      }

      const resolvedModel = canonical.model || result.model || 'default';
      const canonicalResp = { id: `msg_${crypto.randomUUID()}`, model: resolvedModel, content: result.content, thinking: null, toolCalls: null, stopReason: 'end_turn', usage: { inputTokens: 0, outputTokens: 0, totalTokens: 0 } };
      const formatted = protocolConverter.convertResponse(canonicalResp, outputProtocol);
      recordTrainingSample(runPrompt, result.content, {
        provider: result.provider || route.adapterKey || 'proxy',
        adapter: route.adapterKey || result.adapter || null,
        model: resolvedModel,
      });
      reservoirSet(reservoirKey, formatted);
      sendJson(res, 200, formatted);
    } catch (err) {
      sendJson(res, 500, { error: { message: err.message } });
    }
  }
}

/**
 * Handle GET /v1/models — aggregate from all public adapters
 */
async function handleListModels(req, res) {
  const gw = getGateway();
  if (!gw._initialized) await gw.init();

  const created = Math.floor(Date.now() / 1000);
  const includeRawRelayModels = shouldExposeRawRelayModels();
  const allModels = [];
  const seen = new Set();
  const pushModel = ({
    id,
    owner = 'proxy',
    name = '',
    description = '',
    isDefault = false,
  } = {}) => {
    const normalizedId = String(id || '').trim();
    if (!normalizedId || seen.has(normalizedId)) return;
    seen.add(normalizedId);
    allModels.push({
      id: normalizedId,
      object: 'model',
      created,
      owned_by: owner,
      name: name || normalizedId,
      description: description || '',
      is_default: !!isDefault,
    });
  };

  for (const key of PUBLIC_ADAPTERS) {
    try {
      const models = await gw.listModels(key);
      const prefix = ADAPTER_KEY_TO_PREFIX[key] || key;
      for (const m of models) {
        if (!m?.id) continue;
        pushModel({
          id: `${prefix}/${m.id}`,
          owner: key,
          name: m.name || m.id,
          description: m.description || '',
          isDefault: m.isDefault || false,
        });
        if (key === 'relay_api' && includeRawRelayModels) {
          pushModel({
            id: m.id,
            owner: key,
            name: m.name || m.id,
            description: m.description || '',
            isDefault: m.isDefault || false,
          });
        }
        // Compatibility aliases: antigravity/* and nirvana/* route to Trae adapter.
        if (key === 'trae') {
          pushModel({
            id: `antigravity/${m.id}`,
            owner: key,
            name: `Antigravity ${m.name || m.id}`,
            description: m.description || '',
            isDefault: false,
          });
          pushModel({
            id: `nirvana/${m.id}`,
            owner: key,
            name: `Nirvana ${m.name || m.id}`,
            description: m.description || '',
            isDefault: false,
          });
        }
      }
    } catch { /* adapter not available */ }
  }

  sendJson(res, 200, { object: 'list', data: allModels });
}

/**
 * Start the proxy server.
 */
async function start(portOrOptions) {
  if (_server) {
    throw new Error('Proxy server already running');
  }

  const config = resolveStartConfig(portOrOptions);
  const primaryAuth = resolvePrimaryAuthToken();
  const authToken = primaryAuth.token;
  const cfg = loadAuthConfig();
  const authTokens = buildAuthTokenSet(authToken, { managedTokens: cfg.managedTokens });

  // Log token source on start for IDE/client configuration.
  if (primaryAuth.generated) {
    console.log(`[Proxy] Auto-generated auth token: ${authToken}`);
    console.log('[Proxy] Token has been persisted at ~/.khy/proxy_server_auth.json');
  } else if (primaryAuth.source === 'persisted') {
    console.log(`[Proxy] Using persisted auth token: ${maskToken(authToken)}`);
  } else {
    console.log('[Proxy] Using auth token from PROXY_AUTH_TOKEN');
  }

  const requestHandler = async (req, res) => {
    // CORS preflight
    if (req.method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin': process.env.PROXY_CORS_ORIGINS || '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-key, x-goog-api-key',
        'Access-Control-Max-Age': '86400',
      });
      return res.end();
    }

    // Auth check (always enforced — token is auto-generated if not configured)
    const auth = String(req.headers.authorization || '');
    const bearer = auth.startsWith('Bearer ') ? auth.slice(7).trim() : '';
    const apiKey = String(req.headers['x-api-key'] || req.headers['x-goog-api-key'] || '').trim();
    const liveCfg = loadAuthConfig();
    const livePrimary = resolvePrimaryAuthToken();
    const liveTokens = buildAuthTokenSet(livePrimary.token, { managedTokens: liveCfg.managedTokens });
    const queryKey = String(new URL(req.url, 'http://localhost').searchParams.get('key') || '').trim();
    const presented = bearer || apiKey || queryKey;
    if (!presented || !liveTokens.has(presented)) {
      return sendJson(res, 401, { error: { message: 'Unauthorized — use Authorization: Bearer <khy-...> (PROXY_AUTH_TOKEN or PROXY_AUTH_TOKENS)' } });
    }

    // Strip real client IP from incoming request before processing
    delete req.headers['x-forwarded-for'];
    delete req.headers['x-real-ip'];
    delete req.headers['cf-connecting-ip'];
    delete req.headers['true-client-ip'];

    const url = new URL(req.url, 'http://localhost');
    const pathname = url.pathname;

    try {
      if (req.method === 'POST' && isWindsurfModelConfigPath(pathname)) {
        await handleWindsurfModelConfigs(req, res);
      } else if (req.method === 'POST' && pathname === '/v1/chat/completions') {
        await handleChatCompletions(req, res);
      } else if (req.method === 'POST' && pathname === '/v1/messages') {
        await handleMultiProtocol(req, res, PROTOCOLS.ANTHROPIC);
      } else if (req.method === 'POST' && pathname.match(/^\/v1beta\/models\/[^/]+:generateContent$/)) {
        await handleMultiProtocol(req, res, PROTOCOLS.GEMINI);
      } else if (req.method === 'POST' && pathname === '/v1/responses') {
        await handleMultiProtocol(req, res, PROTOCOLS.CODEX);
      } else if (req.method === 'GET' && pathname === '/v1/models') {
        await handleListModels(req, res);
      } else if (req.method === 'GET' && pathname === '/health') {
        const r = getReservoirConfig();
        sendJson(res, 200, {
          status: 'ok',
          adapters: PUBLIC_ADAPTERS,
          protocols: protocolConverter.getSupportedProtocols(),
          runtime: _runtime || buildRuntimeStatus(config, authToken),
          reservoir: { enabled: r.enabled, size: _reservoir.size, ttlMs: r.ttlMs, maxEntries: r.maxEntries },
        });
      } else if (req.method === 'GET' && pathname === '/reservoir/stats') {
        const r = getReservoirConfig();
        sendJson(res, 200, {
          enabled: r.enabled,
          size: _reservoir.size,
          ttlMs: r.ttlMs,
          maxEntries: r.maxEntries,
        });
      } else {
        sendJson(res, 404, { error: { message: 'Not found' } });
      }
    } catch (err) {
      sendJson(res, 500, { error: { message: err.message } });
    }
  };

  const localHttpServer = config.http.enabled ? http.createServer(requestHandler) : null;
  const localHttpsServer = config.https.enabled
    ? https.createServer({ cert: config.https.cert, key: config.https.key }, requestHandler)
    : null;

  try {
    if (localHttpServer) await listenServer(localHttpServer, config.http.port, config.host);
    if (localHttpsServer) await listenServer(localHttpsServer, config.https.port, config.host);
  } catch (err) {
    await closeServer(localHttpServer);
    await closeServer(localHttpsServer);
    throw err;
  }

  _httpServer = localHttpServer;
  _httpsServer = localHttpsServer;
  _server = _httpServer || _httpsServer;
  _runtime = buildRuntimeStatus(config, authToken);

  return {
    port: getPort(),
    host: config.host,
    mode: _runtime.mode,
    http: _runtime.http,
    https: _runtime.https,
    authToken,
    authTokenMasked: maskToken(authToken),
    generatedToken: primaryAuth.generated,
    authTokenSource: primaryAuth.source,
    tokenCount: authTokens.size,
  };
}

/**
 * Stop the proxy server.
 */
function stop() {
  return Promise.resolve().then(async () => {
    await closeServer(_httpServer);
    await closeServer(_httpsServer);
    _httpServer = null;
    _httpsServer = null;
    _server = null;
    _runtime = null;
  });
}

function isRunning() { return !!_httpServer || !!_httpsServer; }

function getPort() {
  if (_runtime?.http?.enabled && Number.isFinite(_runtime.http.port)) return _runtime.http.port;
  if (_runtime?.https?.enabled && Number.isFinite(_runtime.https.port)) return _runtime.https.port;
  return toPort(process.env.PROXY_PORT, 9100) || 9100;
}

function getRuntimeStatus() {
  if (_runtime) return { ..._runtime, http: { ..._runtime.http }, https: { ..._runtime.https } };
  try {
    const fallback = resolveStartConfig({ port: getPort() });
    return buildRuntimeStatus(fallback, resolvePrimaryAuthToken().token);
  } catch {
    return {
      mode: 'http-only',
      host: process.env.PROXY_HOST || '127.0.0.1',
      http: {
        enabled: true,
        port: toPort(process.env.PROXY_PORT, 9100) || 9100,
        host: process.env.PROXY_HOST || '127.0.0.1',
        url: `http://${process.env.PROXY_HOST || '127.0.0.1'}:${toPort(process.env.PROXY_PORT, 9100) || 9100}`,
      },
      https: {
        enabled: false,
        port: null,
        host: process.env.PROXY_HOST || '127.0.0.1',
        url: '',
        certSource: '',
        certFile: '',
        keyFile: '',
      },
      authTokenMasked: maskToken(resolvePrimaryAuthToken().token),
    };
  }
}

module.exports = {
  start,
  stop,
  isRunning,
  getPort,
  getRuntimeStatus,
  getAuthStatus,
  setAuthToken,
  rotateAuthToken,
  listManagedTokens,
  createManagedToken,
  setManagedTokenEnabled,
  deleteManagedToken,
  rotateManagedToken,
  normalizeAuthToken,
};
