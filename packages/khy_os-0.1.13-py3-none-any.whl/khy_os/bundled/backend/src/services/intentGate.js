'use strict';

/**
 * intentGate.js
 *
 * Keyword-triggered mode injection before the tool-use loop starts.
 * Mode support:
 *   - ultrawork / ulw   — high-agency autonomous execution
 *   - coding            — project creation / implementation tasks
 *   - analyze           — deep analysis / code review tasks
 *
 * Keywords inside fenced or indented code blocks are ignored.
 */

const CODE_BLOCK_RE = /(`{3,}|~{3,})[^\n]*\n[\s\S]*?\n\1[^\n]*|(?:(?:^|\n)(?:    |\t)[^\n]*)+/gm;
const ULTRAWORK_TRIGGER_RE = /(^|[^a-z0-9_])(ultrawork|ulw)(?=$|[^a-z0-9_])/i;

// Coding mode: project scaffolding, multi-file creation, build tasks
// Uses simpler boundaries — CJK text doesn't have word separators like Latin
// Covers 30+ project types: Java/SSM/React/Vue/Angular/Express/Flask/Django/Go/Rust/C++ etc.
const CODING_TRIGGER_RE = /(创建项目|新建工程|新建项目|SSM|Spring\s*Boot|scaffold|create\s+project|new\s+project|init\s+project|maven项目|gradle项目|npm\s+init|写一个[\s\S]{0,20}(?:项目|工程|应用|服务|系统|网站|后端|前端)|build\s+a[\s\S]{0,20}(?:app|project|server|website|api)|搭建[\s\S]{0,20}(?:项目|工程|环境|系统)|创建[\s\S]{0,10}工程|setup\s+(?:a\s+)?(?:new\s+)?project|bootstrap\s+(?:a\s+)?project|开发[\s\S]{0,10}(?:项目|应用|网站|后端|前端|系统|服务)|做一个[\s\S]{0,20}(?:项目|应用|网站|后端|前端|系统|服务)|帮我写[\s\S]{0,20}(?:项目|服务|后端|前端|网站)|React|Vue(?:\.?js)?|Angular|Express|Flask|Django|FastAPI|Next\.?js|Nuxt|Svelte|Rails|Laravel|Cargo\s+(?:new|init)|go\s+mod\s+init|CMakeLists|full[\s-]?stack|create[-\s]react[-\s]app|vite\s+create|cargo\s+new|CRUD[\s\S]{0,20}(?:app|应用|系统)|REST\s*(?:ful)?\s*API|GraphQL[\s\S]{0,20}server|Gin|Fiber|Echo|NestJS|Koa|Hapi|Actix|Rocket|Warp|Phoenix|Electron|Tauri|Flutter|React\s*Native|小程序|uni-?app|微信开发|Taro)/i;

// Analyze mode: deep analysis, code review (excludes bare "分析" to avoid false positives)
const ANALYZE_TRIGGER_RE = /(深度分析|全面分析|综合分析|代码审查|code\s*review|architecture\s*review|性能分析|performance\s*analysis|安全审计|security\s*audit)/i;

const ULTRAWORK_DIRECTIVE = [
  '## ULTRAWORK mode activated by user keyword.',
  'Operate in high-agency execution mode:',
  '1. Create a short execution plan (2-5 concrete steps) and keep it updated.',
  '2. Prefer direct tool actions over long speculation.',
  '3. Batch or parallelize independent work when safe.',
  '4. If a step fails, retry with a different tactic and explain the delta.',
  '5. Continue until the goal is completed or a real blocker is proven.',
].join('\n');

const CODING_DIRECTIVE = [
  '## CODING mode activated — project creation/implementation task detected.',
  'Operate as a senior engineer. Deliver a production-grade, Docker-ready project.',
  '',
  '### Phase 1 — Environment & Planning',
  '1. Detect the project type and check required tools exist (e.g., `java -Xmx64m -version`, `node -v`, `mvn --version`, `python3 --version`, `cargo --version`, `go version`). Use `-Xmx64m` for Java in sandboxed environments.',
  '2. If a required tool is missing, install it proactively (`apt-get install -y` / `brew install`). Do NOT stop — fix the environment and continue.',
  '3. Before writing code, explain your project structure plan: directories, key files, and the layered architecture.',
  '',
  '### Phase 2 — Scaffolding & Architecture',
  '4. Use the projectTemplate tool first if a matching template exists — it provides a verified skeleton. Then use scaffoldFiles for batch file creation. Never create files one-by-one with Write.',
  '5. As you create each file, briefly describe its purpose (1 sentence). Example: "Creating UserController.java — REST endpoints for user CRUD."',
  '6. Enforce layered architecture: backend must have controller/service/model/config layers; frontend must have components/pages/hooks/utils separation. No single-file projects.',
  '7. Write configuration files (pom.xml, package.json, Cargo.toml, go.mod, requirements.txt, etc.) with correct, complete values — no placeholders or TODOs.',
  '',
  '### Phase 3 — Code Quality',
  '8. Write real business logic — NEVER use hardcoded mock data like `return [{id:1, name:"Alice"}]`. Implement actual database queries, service calls, and data persistence.',
  '9. All API responses must use structured JSON format: `{code, msg, data}` with standard HTTP status codes (200/201/400/404/500).',
  '10. Add input validation on all endpoints: check for null/empty, format, length constraints. Prevent SQL injection and XSS.',
  '11. Add logging for key operations (login, data mutations, errors) using the framework\'s standard logger.',
  '12. For frontend projects: use a UI framework (Ant Design, Material UI, Element Plus, or Tailwind CSS). Buttons must show loading states; forms must show validation feedback.',
  '',
  '### Phase 4 — Docker Delivery',
  '13. Create a `Dockerfile` with multi-stage build: build stage compiles/bundles, production stage runs a minimal image. Declare all dependencies.',
  '14. Create `docker-compose.yml` with all required services (app, database, cache, etc.). Include health checks, volume mounts for DB data, and environment variables.',
  '15. Create `.dockerignore` excluding: node_modules, .venv, __pycache__, dist, .git, .env, target, bin.',
  '16. Ensure `docker compose up` starts the entire stack with zero manual steps. Database schema must auto-initialize (via init scripts or migrations).',
  '',
  '### Phase 5 — Testing',
  '17. Create `unit_tests/` directory with unit tests for core business logic (services, models, utilities).',
  '18. Create `API_tests/` directory with integration tests for every API endpoint (test CRUD operations, error cases, validation).',
  '19. Create `run_tests.sh` script that installs test dependencies and runs both unit and API tests with a single command.',
  '',
  '### Phase 6 — Documentation & Verification',
  '20. Create `README.md` with: project description, tech stack, prerequisites, quick start (`docker compose up`), manual setup steps, API documentation (endpoints + request/response examples), test instructions, and project structure overview. All ports, URLs, and credentials in README must match the actual code.',
  '21. Run the build/compile command to verify the project compiles. If the build fails, fix and retry until it succeeds.',
  '22. When finished, summarize: what was created, how to start with Docker, and how to run tests.',
  '',
  '### Post-Completion Gate',
  'After you finish, the system will automatically verify that Dockerfile, docker-compose.yml, unit_tests/, run_tests.sh, and README.md exist in the project. If any required deliverable is missing, you will be asked to create it. Plan accordingly — do not skip any phase.',
].join('\n');

const ANALYZE_DIRECTIVE = [
  '## ANALYZE mode activated — deep analysis/review task detected.',
  'Operate in thorough analysis mode:',
  '1. Read all relevant source files before forming conclusions.',
  '2. Use grep/glob to find related code across the codebase.',
  '3. Provide concrete evidence (file paths, line numbers, code snippets) for every claim.',
  '4. Structure output with clear sections: findings, impact, recommendations.',
  '5. Do not speculate — verify every assertion by reading the actual code.',
].join('\n');

function _firstNonEmpty(...values) {
  for (const value of values) {
    const text = String(value === undefined || value === null ? '' : value).trim();
    if (text) return text;
  }
  return '';
}

function _parseBoolean(value) {
  if (value === true || value === false) return value;
  const text = String(value === undefined || value === null ? '' : value).trim().toLowerCase();
  if (!text) return undefined;
  if (['1', 'true', 'yes', 'on', 'y'].includes(text)) return true;
  if (['0', 'false', 'no', 'off', 'n'].includes(text)) return false;
  return undefined;
}

function _resolveUltraworkChatOpts(options = {}) {
  const preferredModel = _firstNonEmpty(
    options.ultraworkModel,
    process.env.KHY_ULTRAWORK_MODEL,
    process.env.KHY_ULTRAWORK_PREFERRED_MODEL,
  );
  const preferredAdapter = _firstNonEmpty(
    options.ultraworkAdapter,
    process.env.KHY_ULTRAWORK_ADAPTER,
    process.env.KHY_ULTRAWORK_PREFERRED_ADAPTER,
  );
  const strict = _parseBoolean(
    options.ultraworkStrict !== undefined
      ? options.ultraworkStrict
      : process.env.KHY_ULTRAWORK_PREFERRED_STRICT,
  );

  const patch = {};
  if (preferredModel) patch.preferredModel = preferredModel;
  if (preferredAdapter) patch.preferredAdapter = preferredAdapter;
  if (strict !== undefined) {
    patch.preferredStrict = strict;
    patch.strictPreferred = strict;
  }
  // Force tool use for first iterations in ultrawork mode
  const forceToolChoice = _parseBoolean(
    process.env.KHY_ULTRAWORK_FORCE_TOOL_CHOICE,
  );
  if (forceToolChoice !== false) patch._intentToolChoice = 'required';
  return patch;
}

function _resolveCodingChatOpts(options = {}) {
  const preferredModel = _firstNonEmpty(
    options.codingModel,
    process.env.KHY_CODING_MODEL,
  );
  const patch = {};
  if (preferredModel) patch.preferredModel = preferredModel;
  // Force tool use for first iterations in coding mode
  const forceToolChoice = _parseBoolean(
    process.env.KHY_CODING_FORCE_TOOL_CHOICE,
  );
  if (forceToolChoice !== false) patch._intentToolChoice = 'required';
  return patch;
}

function _resolveAnalyzeChatOpts(options = {}) {
  const preferredModel = _firstNonEmpty(
    options.analyzeModel,
    process.env.KHY_ANALYZE_MODEL,
  );
  const patch = {};
  if (preferredModel) patch.preferredModel = preferredModel;
  return patch;
}

function removeCodeBlocks(text) {
  if (!text || typeof text !== 'string') return '';
  return text.replace(CODE_BLOCK_RE, '\n');
}

function detectModes(text) {
  const cleaned = removeCodeBlocks(String(text || ''));

  const ultraworkMatch = cleaned.match(ULTRAWORK_TRIGGER_RE);
  const ultrawork = !!ultraworkMatch;

  const codingMatch = cleaned.match(CODING_TRIGGER_RE);
  const coding = !!codingMatch;

  const analyzeMatch = cleaned.match(ANALYZE_TRIGGER_RE);
  const analyze = !!analyzeMatch;

  const modes = [];
  if (ultrawork) modes.push('ultrawork');
  if (coding) modes.push('coding');
  if (analyze) modes.push('analyze');

  return {
    ultrawork,
    coding,
    analyze,
    trigger: ultrawork ? String(ultraworkMatch[2] || '').toLowerCase() : null,
    codingTrigger: coding ? String(codingMatch[1] || '') : null,
    analyzeTrigger: analyze ? String(analyzeMatch[1] || '') : null,
    modes,
  };
}

function applyIntentGate(message, options = {}) {
  const original = String(message || '');
  const detected = detectModes(original);

  const directives = [];
  let chatOptsPatch = {};

  // ultrawork: highest priority autonomous mode
  if (detected.ultrawork) {
    const directive = String(options.ultraworkDirective || ULTRAWORK_DIRECTIVE).trim();
    if (directive) directives.push({ mode: 'ultrawork', trigger: detected.trigger, text: directive });
    chatOptsPatch = { ...chatOptsPatch, ..._resolveUltraworkChatOpts(options) };
  }

  // coding: project creation / implementation mode (combinable with ultrawork)
  if (detected.coding) {
    let codingText = String(options.codingDirective || CODING_DIRECTIVE).trim();

    // Inject platform context so the AI knows the environment without a tool call
    try {
      const { getPlatform } = require('../tools/platformUtils');
      const platform = getPlatform();
      codingText += `\nEnvironment: Platform=${platform}, Node=${process.version}, Arch=${process.arch}.`;
    } catch { /* platformUtils not available — skip */ }

    // Append template hint if a matching template is available
    try {
      const { matchTemplate } = require('./projectTemplateService');
      const matched = matchTemplate(original);
      if (matched) {
        codingText += `\nTemplate "${matched.name}" is available. Use the projectTemplate tool to load it (template: "${matched.name}"), then pass the rendered output directly to scaffoldFiles.`;
      }
    } catch { /* projectTemplateService not available — skip hint */ }
    if (codingText) directives.push({ mode: 'coding', trigger: detected.codingTrigger, text: codingText });
    chatOptsPatch = { ...chatOptsPatch, ..._resolveCodingChatOpts(options) };
  }

  // analyze: deep analysis / review mode
  if (detected.analyze) {
    const directive = String(options.analyzeDirective || ANALYZE_DIRECTIVE).trim();
    if (directive) directives.push({ mode: 'analyze', trigger: detected.analyzeTrigger, text: directive });
    chatOptsPatch = { ...chatOptsPatch, ..._resolveAnalyzeChatOpts(options) };
  }

  if (directives.length === 0) {
    return {
      message: original,
      systemDirective: '',
      activatedModes: detected.modes,
      directives: [],
      chatOptsPatch,
      detection: detected,
    };
  }

  const injected = directives.map(d => d.text).join('\n\n');
  return {
    message: original,
    systemDirective: injected,
    activatedModes: detected.modes,
    directives,
    chatOptsPatch,
    detection: detected,
  };
}

/**
 * Get combined acceptance criteria for a set of activated modes.
 * @param {string[]} modes - e.g. ['coding'], ['ultrawork', 'coding']
 * @returns {Array} Criterion objects from acceptanceCriteria.js
 */
function getAcceptanceCriteria(modes) {
  const { MODE_ACCEPTANCE } = require('./acceptanceCriteria');
  const criteria = [];
  for (const mode of (modes || [])) {
    const modeCriteria = MODE_ACCEPTANCE[mode];
    if (Array.isArray(modeCriteria)) {
      criteria.push(...modeCriteria);
    }
  }
  return criteria;
}

/**
 * Return mode-specific loop iteration boosts for toolUseLoop (outer) and ai.js (inner).
 * @param {string[]} modes - Activated mode names (e.g. ['coding', 'ultrawork'])
 * @returns {{ outerBoost: number, innerBoost: number }}
 */
function getLoopLimitBoost(modes) {
  if (!Array.isArray(modes) || modes.length === 0) return { outerBoost: 0, innerBoost: 0 };
  if (modes.includes('coding'))    return { outerBoost: 18, innerBoost: 8 };
  if (modes.includes('ultrawork')) return { outerBoost: 12, innerBoost: 6 };
  if (modes.includes('analyze'))   return { outerBoost: 6,  innerBoost: 4 };
  return { outerBoost: 0, innerBoost: 0 };
}

module.exports = {
  ULTRAWORK_DIRECTIVE,
  CODING_DIRECTIVE,
  ANALYZE_DIRECTIVE,
  removeCodeBlocks,
  detectModes,
  applyIntentGate,
  getAcceptanceCriteria,
  getLoopLimitBoost,
};
