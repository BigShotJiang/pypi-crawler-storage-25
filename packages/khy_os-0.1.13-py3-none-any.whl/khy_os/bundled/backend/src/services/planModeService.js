/**
 * Plan Mode Service — structured plan → approve → execute workflow.
 *
 * When a complex task is detected, AI generates a numbered execution plan.
 * The user can approve, modify, or reject before step-by-step execution.
 *
 * State machine: idle → generating → reviewing → executing → complete
 */
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

// ── Plan Persistence ─────────────────────────────────────────────────
const PLANS_DIR_NAME = 'plans';

function _getPlansDir() {
  const home = os.homedir();
  return path.join(home, '.khyquant', PLANS_DIR_NAME);
}

function _ensurePlansDir() {
  const dir = _getPlansDir();
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function _slugify(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\u4e00-\u9fff]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60);
}

/**
 * Save a plan to disk for cross-session recovery.
 * @param {object} plan - The parsed plan object
 * @param {string} userRequest - Original user request
 * @param {object} [meta] - Additional metadata (cwd, provider, etc.)
 * @returns {{ slug: string, filePath: string }}
 */
function savePlan(plan, userRequest, meta = {}) {
  const dir = _ensurePlansDir();
  const slug = _slugify(userRequest || 'plan') + '-' + crypto.randomBytes(3).toString('hex');
  const filePath = path.join(dir, `${slug}.json`);

  const payload = {
    slug,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    state: _state,
    userRequest: (userRequest || '').slice(0, 2000),
    plan,
    cwd: meta.cwd || process.cwd(),
    provider: meta.provider || null,
  };

  fs.writeFileSync(filePath, JSON.stringify(payload, null, 2), 'utf-8');
  return { slug, filePath };
}

/**
 * Update an existing persisted plan (e.g., step status changes).
 * @param {string} slug
 * @param {object} updates - Partial fields to merge
 * @returns {boolean}
 */
function updatePersistedPlan(slug, updates) {
  const filePath = path.join(_getPlansDir(), `${slug}.json`);
  try {
    if (!fs.existsSync(filePath)) return false;
    const existing = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    const merged = { ...existing, ...updates, updatedAt: new Date().toISOString() };
    fs.writeFileSync(filePath, JSON.stringify(merged, null, 2), 'utf-8');
    return true;
  } catch {
    return false;
  }
}

/**
 * Load a persisted plan by slug.
 * @param {string} slug
 * @returns {object|null}
 */
function loadPersistedPlan(slug) {
  const filePath = path.join(_getPlansDir(), `${slug}.json`);
  try {
    if (!fs.existsSync(filePath)) return null;
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return null;
  }
}

/**
 * List recent persisted plans (most recent first).
 * @param {number} [limit=10]
 * @returns {Array<{ slug: string, userRequest: string, state: string, createdAt: string, cwd: string }>}
 */
function listPersistedPlans(limit = 10) {
  const dir = _getPlansDir();
  try {
    if (!fs.existsSync(dir)) return [];
    const files = fs.readdirSync(dir)
      .filter(f => f.endsWith('.json'))
      .map(f => {
        try {
          const data = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf-8'));
          return { slug: data.slug, userRequest: (data.userRequest || '').slice(0, 120), state: data.state, createdAt: data.createdAt, cwd: data.cwd };
        } catch { return null; }
      })
      .filter(Boolean)
      .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
    return files.slice(0, limit);
  } catch { return []; }
}

// ── State ─────────────────────────────────────────────────────────────
let _state = 'idle'; // idle | generating | reviewing | executing | complete
let _currentPlan = null;
let _currentPlanSlug = null;

function isStepExecutionFailure(result) {
  if (!result || typeof result !== 'object') return true;
  if (result.errorType || result.blocked) return true;

  const reply = String(result.reply || '').trim();
  if (!reply) return true;

  if (/^\s*(AI 请求失败|AI 未返回有效回复|error:|错误:)/i.test(reply)) return true;
  if (/(permission denied|operation not permitted|access denied|forbidden|not allowed)/i.test(reply)) return true;
  if (/(权限被拒绝|未授权|任务被权限阻止|无法完成|无法运行|未创建)/.test(reply)) return true;

  return false;
}

function runWithActivityTimeout(taskFactory, timeoutMs, errorMessage) {
  const idleMs = Math.max(1000, Number(timeoutMs) || 0);
  const checkEveryMs = Math.min(1000, Math.max(200, Math.floor(idleMs / 6)));

  return new Promise((resolve, reject) => {
    let settled = false;
    let lastActivity = Date.now();
    let watcher = null;

    const cleanup = () => {
      if (watcher) {
        clearInterval(watcher);
        watcher = null;
      }
    };

    const touch = () => {
      lastActivity = Date.now();
    };

    watcher = setInterval(() => {
      if (settled) return;
      const idleFor = Date.now() - lastActivity;
      if (idleFor <= idleMs) return;
      settled = true;
      cleanup();
      reject(new Error(errorMessage || `Timeout after ${idleMs}ms`));
    }, checkEveryMs);
    if (watcher.unref) watcher.unref();

    Promise.resolve()
      .then(() => taskFactory({ touch }))
      .then((value) => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve(value);
      })
      .catch((err) => {
        if (settled) return;
        settled = true;
        cleanup();
        reject(err);
      });
  });
}

function extractAbsolutePaths(text) {
  if (!text) return [];
  const paths = new Set();
  const pattern = /(?:^|[\s`'"])(\/[^\s`'"]+)/g;
  let m;
  while ((m = pattern.exec(String(text)))) {
    const cleaned = m[1].replace(/[),.;:]+$/g, '').trim();
    if (cleaned) paths.add(cleaned);
  }
  return Array.from(paths);
}

function inferPlanBaseDirs(plan) {
  const combined = [
    ...(plan?.dataNeeds || []),
    ...(plan?.expectedOutputs || []),
    ...(plan?.risks || []),
    ...(plan?.steps || []).map(s => s.description || ''),
  ].join('\n');
  const absPaths = extractAbsolutePaths(combined);
  const dirs = [];
  for (const p of absPaths) {
    const last = path.basename(p);
    if (/\.[a-z0-9]{1,8}$/i.test(last)) {
      dirs.push(path.dirname(p));
    } else {
      dirs.push(p);
    }
  }
  const cwd = process.env.KHYQUANT_CWD || process.cwd();
  if (cwd) dirs.push(path.resolve(cwd));
  return Array.from(new Set(dirs.filter(Boolean)));
}

function inferStepFileTargets(stepDescription, plan) {
  const desc = String(stepDescription || '');
  const namePattern = /(?:^|[\s`'"])([A-Za-z0-9_.\/-]+\.[A-Za-z0-9]{1,8})(?=$|[\s`'".,;:])/g;
  const names = new Set();
  let m;
  while ((m = namePattern.exec(desc))) {
    names.add(m[1]);
  }
  const baseDirs = inferPlanBaseDirs(plan);
  const targets = new Set();
  for (const n of names) {
    if (n.startsWith('/')) {
      targets.add(path.resolve(n));
      continue;
    }
    for (const dir of baseDirs) {
      targets.add(path.resolve(dir, n));
    }
  }

  // If assistant reply already contains absolute artifact paths, include them.
  for (const p of extractAbsolutePaths(desc)) {
    const base = path.basename(p);
    if (/\.[a-z0-9]{1,8}$/i.test(base)) targets.add(path.resolve(p));
  }

  return Array.from(targets);
}

function hasExecutionIntent(stepDescription) {
  return /(创建|新建|写入|编写|生成|修改|编辑|运行|执行|测试|校验|验证|create|write|add|update|edit|run|execute|test|verify)/i
    .test(String(stepDescription || ''));
}

function hasWriteIntent(stepDescription) {
  return /(创建|新建|写入|编写|生成|修改|编辑|create|write|add|update|edit|文件|目录)/i
    .test(String(stepDescription || ''));
}

function hasRunIntent(stepDescription) {
  return /(运行|执行|测试|校验|验证|run|execute|test|verify|命令|command)/i
    .test(String(stepDescription || ''));
}

function hasRuntimeEvidence(reply) {
  const text = String(reply || '');
  if (!text.trim()) return false;
  if (/\b(pass|passed|fail|failed|exit code|stdout|stderr)\b/i.test(text)) return true;
  if (/(测试结果|通过|失败|退出码|命令输出|执行结果)/.test(text)) return true;
  if (/`(?:bash|node|npm|pnpm|yarn)\s+/i.test(text)) return true;
  return false;
}

function shortenReason(reason, maxLen = 220) {
  const text = String(reason || '').replace(/\s+/g, ' ').trim();
  if (!text) return 'unknown reason';
  return text.length > maxLen ? `${text.slice(0, maxLen)}...` : text;
}

function getPlanPreviewStyle() {
  const raw = String(process.env.KHY_PLAN_PREVIEW_STYLE || 'natural').trim().toLowerCase();
  if (raw === 'compact' || raw === 'coach' || raw === 'natural') return raw;
  return 'natural';
}

function buildStepPreviewText(stepDescription, index, totalSteps, style = 'natural') {
  const summary = shortenReason(stepDescription, 100);
  if (style === 'compact') {
    return `第 ${index + 1}/${totalSteps} 步：${summary}`;
  }
  if (style === 'coach') {
    const leads = [
      `先把这一项拿下：${summary}`,
      `这一步是关键环节，我先推进：${summary}`,
      `我先处理这块核心任务：${summary}`,
      `这一步我会先落地，再马上反馈：${summary}`,
    ];
    return `${leads[index % leads.length]}（进度 ${index + 1}/${totalSteps}）`;
  }
  const leads = [
    `我先从这一项开始：${summary}`,
    `接下来我会处理这一步：${summary}`,
    `这一步我先落地执行：${summary}`,
    `先推进这一块内容：${summary}`,
  ];
  return `${leads[index % leads.length]}（当前进度 ${index + 1}/${totalSteps}）`;
}

function buildAttemptPreviewText(stepId, attemptNumber, maxAttempts, style = 'natural') {
  if (style === 'compact') {
    return `执行第 ${stepId} 步，尝试 ${attemptNumber}/${maxAttempts}。`;
  }
  if (style === 'coach') {
    if (maxAttempts <= 1) {
      return `开始执行第 ${stepId} 步，我会边做边汇报进展。`;
    }
    return `开始执行第 ${stepId} 步（第 ${attemptNumber}/${maxAttempts} 次尝试），我会及时调整并同步结果。`;
  }
  if (maxAttempts <= 1) {
    return `开始执行第 ${stepId} 步，完成后我会立刻同步结果。`;
  }
  return `开始执行第 ${stepId} 步（第 ${attemptNumber}/${maxAttempts} 次尝试），我会实时反馈结果。`;
}

function validateStepResult(step, plan, result, stepStartedAtMs) {
  if (isStepExecutionFailure(result)) {
    return { ok: false, reason: 'AI response indicates failure or no valid output' };
  }

  const desc = String(step?.description || '');
  if (!hasExecutionIntent(desc)) {
    return { ok: true, reason: '' };
  }

  const reply = String(result?.reply || '');
  const toolCalls = Number(result?.toolSummary?.totalCalls || 0);
  const fileTargets = inferStepFileTargets(desc, plan);
  const missingFiles = [];
  const staleFiles = [];

  for (const filePath of fileTargets) {
    if (!fs.existsSync(filePath)) {
      missingFiles.push(filePath);
      continue;
    }
    if (hasWriteIntent(desc)) {
      try {
        const st = fs.statSync(filePath);
        if (st.mtimeMs + 1500 < stepStartedAtMs) {
          staleFiles.push(filePath);
        }
      } catch {
        staleFiles.push(filePath);
      }
    }
  }

  if (missingFiles.length > 0) {
    return { ok: false, reason: `missing expected files: ${missingFiles.join(', ')}` };
  }

  if (hasWriteIntent(desc) && fileTargets.length > 0 && staleFiles.length === fileTargets.length && toolCalls <= 0) {
    return { ok: false, reason: 'no observable file updates for a write/create step' };
  }

  if (hasRunIntent(desc) && toolCalls <= 0 && !hasRuntimeEvidence(reply)) {
    return { ok: false, reason: 'run/test step has no executable evidence in output' };
  }

  // For mutation steps, require at least one concrete signal.
  if (hasWriteIntent(desc) && fileTargets.length === 0 && toolCalls <= 0 && !hasRuntimeEvidence(reply)) {
    return { ok: false, reason: 'write step has no tool evidence and no detectable artifacts' };
  }

  return { ok: true, reason: '' };
}

// ── Plan Prompt Template ──────────────────────────────────────────────
const PLAN_PROMPT = `[大型任务 — 请先制定详细执行计划]

用户请求: {REQUEST}

请输出一个结构化的执行计划，格式如下:

## 执行计划
1. [步骤描述]
2. [步骤描述]
...

## 需要的数据
- [数据项]

## 预计输出
- [输出描述]

## 风险与注意事项
- [风险项]

注意: 每个步骤应独立可执行，步骤之间有明确的输入/输出关系。`;

/**
 * Enter plan mode: generate a plan from AI.
 * @param {string} userRequest - the user's original request
 * @param {object} aiModule - the ai module (lazy-loaded)
 * @param {object} [opts] - { onChunk, effort }
 * @returns {{ plan: object, rawResponse: string }}
 */
async function enterPlanMode(userRequest, aiModule, opts = {}) {
  _state = 'generating';

  const prompt = PLAN_PROMPT.replace('{REQUEST}', userRequest);
  let result;
  try {
    const preferredAdapter = String(process.env.GATEWAY_PREFERRED_ADAPTER || '').trim().toLowerCase();
    const isLocalLikeAdapter = !preferredAdapter
      || preferredAdapter === 'localllm'
      || preferredAdapter === 'local-llm'
      || preferredAdapter === 'local'
      || preferredAdapter === 'ollama';
    const defaultPlanTimeout = isLocalLikeAdapter ? '120000' : '90000';
    const timeoutMs = Math.max(10000, parseInt(process.env.KHY_PLAN_MODE_TIMEOUT_MS || defaultPlanTimeout, 10));
    result = await runWithActivityTimeout(
      ({ touch }) => {
        const userOnChunk = typeof opts.onChunk === 'function' ? opts.onChunk : null;
        const userOnStatus = typeof opts.onStatus === 'function' ? opts.onStatus : null;
        const userOnControlRequest = typeof opts.onControlRequest === 'function' ? opts.onControlRequest : null;
        return aiModule.chat(prompt, {
          ...opts,
          _isFollowUp: false,
          onChunk: (chunk) => {
            touch();
            if (userOnChunk) {
              try { userOnChunk(chunk); } catch { /* best effort */ }
            }
          },
          onStatus: (status) => {
            touch();
            if (userOnStatus) {
              try { userOnStatus(status); } catch { /* best effort */ }
            }
          },
          onControlRequest: (...args) => {
            touch();
            if (userOnControlRequest) {
              return userOnControlRequest(...args);
            }
            return undefined;
          },
        });
      },
      timeoutMs,
      `Plan generation timeout after ${Math.round(timeoutMs / 1000)}s`
    );
  } catch (err) {
    _state = 'idle';
    const lowerMsg = String(err && err.message ? err.message : '').toLowerCase();
    const timeoutLike = lowerMsg.includes('timeout') || lowerMsg.includes('timed out') || lowerMsg.includes('超时');
    return {
      plan: null,
      rawResponse: `计划模式生成失败: ${err && err.message ? err.message : 'unknown error'}`,
      provider: null,
      elapsed: 0,
      errorType: timeoutLike ? 'timeout' : 'error',
    };
  }

  if (!result.reply) {
    _state = 'idle';
    return { plan: null, rawResponse: '' };
  }

  if (result.errorType) {
    _state = 'idle';
    return {
      plan: null,
      rawResponse: result.reply,
      provider: result.provider || null,
      elapsed: result.elapsed || 0,
      errorType: result.errorType,
    };
  }

  const plan = parsePlanFromResponse(result.reply);
  _currentPlan = plan;
  _state = 'reviewing';

  // Persist plan to disk for cross-session recovery
  try {
    const persisted = savePlan(plan, userRequest, { provider: result.provider });
    _currentPlanSlug = persisted.slug;
  } catch { /* persistence is best-effort */ }

  return { plan, rawResponse: result.reply, provider: result.provider, elapsed: result.elapsed, slug: _currentPlanSlug };
}

/**
 * Parse a numbered plan from AI response text.
 * Extracts steps from patterns like "1. xxx\n2. xxx\n..."
 *
 * @param {string} text - AI response containing a plan
 * @returns {{ steps: Array<{id: number, description: string, status: string}>, dataNeeds: string[], expectedOutputs: string[], risks: string[] }}
 */
function parsePlanFromResponse(text) {
  const plan = {
    steps: [],
    dataNeeds: [],
    expectedOutputs: [],
    risks: [],
  };

  // Extract numbered steps
  const stepPattern = /(?:^|\n)\s*(\d+)[.、）)]\s*(.+)/g;
  const matches = [...text.matchAll(stepPattern)];
  for (const m of matches) {
    plan.steps.push({
      id: parseInt(m[1], 10),
      description: m[2].trim().slice(0, 100),
      status: 'pending', // pending | in_progress | completed | skipped | error
      blocks: [],        // Step IDs that this step blocks
      blockedBy: [],     // Step IDs that must complete before this step
    });
  }

  // Auto-infer sequential dependencies: each step blocks the next
  for (let i = 0; i < plan.steps.length - 1; i++) {
    plan.steps[i].blocks.push(plan.steps[i + 1].id);
    plan.steps[i + 1].blockedBy.push(plan.steps[i].id);
  }

  // Parse explicit dependency annotations (e.g., "[depends: 1,3]" or "[after: 2]")
  for (const step of plan.steps) {
    const depMatch = step.description.match(/\[(?:depends|after|依赖)[:\s]+([0-9,\s]+)\]/i);
    if (depMatch) {
      const depIds = depMatch[1].split(',').map(s => parseInt(s.trim(), 10)).filter(n => !isNaN(n));
      step.blockedBy = [...new Set([...step.blockedBy, ...depIds])];
      step.description = step.description.replace(depMatch[0], '').trim();
      // Update reverse references
      for (const depId of depIds) {
        const depStep = plan.steps.find(s => s.id === depId);
        if (depStep && !depStep.blocks.includes(step.id)) {
          depStep.blocks.push(step.id);
        }
      }
    }
  }

  // Extract data needs section
  const dataSection = text.match(/需要的数据[\s\S]*?(?=##|$)/);
  if (dataSection) {
    const dataItems = [...dataSection[0].matchAll(/[-•]\s*(.+)/g)];
    plan.dataNeeds = dataItems.map(m => m[1].trim());
  }

  // Extract expected outputs section
  const outputSection = text.match(/预计输出[\s\S]*?(?=##|$)/);
  if (outputSection) {
    const outputItems = [...outputSection[0].matchAll(/[-•]\s*(.+)/g)];
    plan.expectedOutputs = outputItems.map(m => m[1].trim());
  }

  // Extract risks section
  const riskSection = text.match(/风险[\s\S]*?(?=##|$)/);
  if (riskSection) {
    const riskItems = [...riskSection[0].matchAll(/[-•]\s*(.+)/g)];
    plan.risks = riskItems.map(m => m[1].trim());
  }

  return plan;
}

/**
 * Present plan for user approval via interactive prompt.
 * @param {object} plan - parsed plan object
 * @param {object} renderer - aiRenderer module
 * @param {readline.Interface} rl - existing readline interface
 * @returns {Promise<{approved: boolean, modifications: string[]}>}
 */
async function presentForApproval(plan, renderer, rl) {
  // Render plan as task checklist
  const planTracker = new renderer.TaskPlanTracker();
  for (const step of plan.steps) {
    planTracker.addTask(step.description);
  }
  planTracker.render();

  // Show data needs and risks if present
  let _chalk;
  const c = () => (_chalk ??= (require('chalk').default || require('chalk')));

  if (plan.dataNeeds.length > 0) {
    console.log('');
    console.log(c().dim('  需要的数据:'));
    plan.dataNeeds.forEach(d => console.log(c().dim(`    • ${d}`)));
  }

  if (plan.risks.length > 0) {
    console.log('');
    console.log(c().yellow('  风险提示:'));
    plan.risks.forEach(r => console.log(c().yellow(`    ⚠ ${r}`)));
  }

  console.log('');
  console.log(c().cyan('  操作: ') +
    c().white('Enter') + c().dim(' 确认执行 · ') +
    c().white('skip N') + c().dim(' 跳过步骤 · ') +
    c().white('edit N 描述') + c().dim(' 修改步骤 · ') +
    c().white('add after N 描述') + c().dim(' 新增步骤 · ') +
    c().white('n') + c().dim(' 取消')
  );
  console.log(c().dim('  输入 ? 查看示例；支持英文/中文命令，例如：跳过 2, 修改 1 更新描述'));

  return new Promise((resolve) => {
    const autoApproveMs = Math.max(0, parseInt(process.env.KHY_PLAN_AUTO_APPROVE_MS || '0', 10));
    let resolved = false;
    let autoTimer = null;

    const done = (payload) => {
      if (resolved) return;
      resolved = true;
      if (autoTimer) clearTimeout(autoTimer);
      resolve(payload);
    };

    if (autoApproveMs > 0) {
      const autoApproveSec = autoApproveMs >= 1000
        ? `${Math.round(autoApproveMs / 1000)}`
        : `${(autoApproveMs / 1000).toFixed(1)}`;
      console.log(c().dim(`  ${autoApproveSec} 秒无输入将自动确认执行`));
      autoTimer = setTimeout(() => {
        console.log(c().dim('  ⏱ 已自动确认，开始执行计划'));
        done({ approved: true, modifications: [] });
      }, autoApproveMs);
      if (autoTimer.unref) autoTimer.unref();
    }

    const askApproval = () => {
      rl.question(c().dim('  计划确认 > '), (answer) => {
        if (autoTimer) {
          clearTimeout(autoTimer);
          autoTimer = null;
        }
        const raw = String(answer || '').trim();
        const trimmed = raw.toLowerCase();

        if (!trimmed || ['y', 'yes', 'ok', '确认', '执行', '继续'].includes(trimmed)) {
          done({ approved: true, modifications: [] });
          return;
        }

        if (['n', 'no', '取消', 'abort', 'stop'].includes(trimmed)) {
          _state = 'idle';
          _currentPlan = null;
          done({ approved: false, modifications: [] });
          return;
        }

        if (trimmed === '?' || trimmed === 'help' || trimmed === 'h') {
          console.log(c().dim('  示例:'));
          console.log(c().dim('    skip 2'));
          console.log(c().dim('    edit 1 补充输入数据下载与校验'));
          console.log(c().dim('    add after 2 运行自测并记录关键输出'));
          askApproval();
          return;
        }

        const modifications = [];
        const invalidCommands = [];
        const commands = raw.split(/[;,]/).map(s => s.trim()).filter(Boolean);

        for (const cmd of commands) {
          const skipMatch = cmd.match(/^(?:skip|跳过)\s+(\d+)$/i);
          const editMatch = cmd.match(/^(?:edit|修改)\s+(\d+)\s+(.+)$/i);
          const addMatch = cmd.match(/^(?:add|添加)\s+(?:after\s+)?(\d+)\s+(.+)$/i) || cmd.match(/^在\s*(\d+)\s*后(?:添加)?\s+(.+)$/i);

          if (skipMatch) {
            const idx = parseInt(skipMatch[1], 10) - 1;
            if (idx >= 0 && idx < plan.steps.length) {
              plan.steps[idx].status = 'skipped';
              modifications.push(`Skipped step ${skipMatch[1]}`);
            } else {
              invalidCommands.push(`${cmd} (step out of range)`);
            }
            continue;
          }

          if (editMatch) {
            const idx = parseInt(editMatch[1], 10) - 1;
            if (idx >= 0 && idx < plan.steps.length) {
              plan.steps[idx].description = editMatch[2].trim();
              modifications.push(`Edited step ${editMatch[1]}`);
            } else {
              invalidCommands.push(`${cmd} (step out of range)`);
            }
            continue;
          }

          if (addMatch) {
            const afterIdx = parseInt(addMatch[1], 10);
            if (Number.isNaN(afterIdx) || afterIdx < 0 || afterIdx > plan.steps.length) {
              invalidCommands.push(`${cmd} (step out of range)`);
              continue;
            }
            plan.steps.splice(afterIdx, 0, {
              id: afterIdx + 1,
              description: addMatch[2].trim(),
              status: 'pending',
            });
            plan.steps.forEach((s, i) => { s.id = i + 1; });
            modifications.push(`Added step after ${addMatch[1]}`);
            continue;
          }

          invalidCommands.push(cmd);
        }

        if (invalidCommands.length > 0) {
          console.log(c().yellow(`  未识别输入: ${invalidCommands.join(' ; ')}`));
          console.log(c().dim('  可用格式: Enter / skip N / edit N 描述 / add after N 描述 / n'));
          if (modifications.length === 0) {
            askApproval();
            return;
          }
        }

        done({ approved: true, modifications });
      });
    };

    askApproval();
  });
}

/**
 * Execute plan steps one by one with live progress tracking.
 * @param {object} plan - the plan with steps
 * @param {object} opts - { ai, renderer, rl, route, parseInput, onStepResult, onStepStart }
 * @returns {Array<{step: object, result: object}>}
 */
async function executePlanSteps(plan, opts) {
  const { ai: aiModule, renderer, rl, onStepResult, onStepStart } = opts;
  _state = 'executing';
  const stepTimeoutMs = parseInt(process.env.KHY_PLAN_STEP_TIMEOUT_MS || '180000', 10);
  const maxStepRetry = Math.max(0, parseInt(process.env.KHY_PLAN_STEP_RETRY || '1', 10));

  const results = [];
  const planTracker = new renderer.TaskPlanTracker({ rewriteInPlace: false });

  // Add all non-skipped steps
  const activeSteps = plan.steps.filter(s => s.status !== 'skipped');
  const totalSteps = activeSteps.length;
  const previewStyle = getPlanPreviewStyle();
  for (const step of activeSteps) {
    planTracker.addTask(step.description);
  }
  planTracker.render();

  for (let i = 0; i < activeSteps.length; i++) {
    const step = activeSteps[i];
    renderer.printStepLine('active', '准备执行', `第 ${step.id} 步`, `进度 ${i + 1}/${totalSteps}`);
    renderer.printStepDetail(buildStepPreviewText(step.description, i, totalSteps, previewStyle), false);
    if (typeof onStepStart === 'function') {
      try { onStepStart({ step, index: i, total: totalSteps }); } catch { /* best effort */ }
    }
    planTracker.start(i);
    const stepStartedAt = Date.now();

    try {
      // Execute step via AI with follow-up flag (prevents recursive plan mode)
      const basePrompt = `[执行计划步骤 ${step.id}/${plan.steps.length}]\n\n任务: ${step.description}\n\n要求:\n1) 必须实际执行，不要只描述计划。\n2) 如果涉及文件创建/修改，请直接完成并在回复中给出具体文件路径。\n3) 如果涉及命令执行，请给出命令与关键输出。\n4) 若执行失败，明确说明失败原因。`;

      let attempt = 0;
      let acceptedResult = null;
      let lastResult = null;
      let lastValidation = { ok: false, reason: 'unknown' };
      const maxAttempts = maxStepRetry + 1;

      while (attempt <= maxStepRetry) {
        const attemptNumber = attempt + 1;
        const prompt = attempt === 0
          ? basePrompt
          : `${basePrompt}\n\n上次执行未通过校验：${lastValidation.reason}\n请重新执行该步骤，并提供可验证证据。`;

        renderer.printStepDetail(buildAttemptPreviewText(step.id, attemptNumber, maxAttempts, previewStyle), false);

        const result = await runWithActivityTimeout(
          ({ touch }) => aiModule.chat(prompt, {
            _isFollowUp: true,
            onChunk: () => { touch(); },
            onStatus: () => { touch(); },
            onControlRequest: () => { touch(); },
          }),
          stepTimeoutMs,
          `Plan step timeout after ${stepTimeoutMs}ms`
        );
        lastResult = result;
        lastValidation = validateStepResult(step, plan, result, stepStartedAt);
        if (lastValidation.ok) {
          acceptedResult = result;
          break;
        }

        renderer.printStepDetail(`步骤 ${step.id} 校验未通过: ${shortenReason(lastValidation.reason)}`, false);
        attempt += 1;
      }

      if (acceptedResult) {
        planTracker.complete(i);
        step.status = 'completed';
        const finalStepResult = { step, result: { ...acceptedResult, _planAttempts: attempt + 1 } };
        results.push(finalStepResult);
        if (typeof onStepResult === 'function') {
          try { onStepResult(finalStepResult); } catch { /* best effort */ }
        }
      } else {
        planTracker.fail(i);
        step.status = 'error';
        const errorMsg = lastValidation.reason || (lastResult && lastResult.reply ? lastResult.reply : 'No response');
        renderer.printStepDetail(`步骤 ${step.id} 失败: ${shortenReason(errorMsg)}`, false);
        const finalStepResult = { step, result: { ...lastResult, error: errorMsg, _planAttempts: maxAttempts } };
        results.push(finalStepResult);
        if (typeof onStepResult === 'function') {
          try { onStepResult(finalStepResult); } catch { /* best effort */ }
        }
      }
    } catch (err) {
      planTracker.fail(i);
      step.status = 'error';
      const finalStepResult = { step, result: { error: err.message } };
      results.push(finalStepResult);
      if (typeof onStepResult === 'function') {
        try { onStepResult(finalStepResult); } catch { /* best effort */ }
      }
    }
  }

  _state = 'complete';
  _currentPlan = null;

  // Persist final plan state
  if (_currentPlanSlug) {
    try { updatePersistedPlan(_currentPlanSlug, { state: 'complete', plan }); } catch { /* best effort */ }
    _currentPlanSlug = null;
  }

  return results;
}

/**
 * Get current plan mode state.
 */
function getState() {
  return _state;
}

/**
 * Reset plan mode to idle.
 */
function reset() {
  _state = 'idle';
  _currentPlan = null;
  _currentPlanSlug = null;
}

module.exports = {
  enterPlanMode,
  parsePlanFromResponse,
  presentForApproval,
  executePlanSteps,
  getState,
  reset,
  savePlan,
  updatePersistedPlan,
  loadPersistedPlan,
  listPersistedPlans,
  PLAN_PROMPT,
};
