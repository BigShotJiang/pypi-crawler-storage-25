'use strict';

/**
 * Daemon Manager — start/stop/status/restart the KHY AI daemon process.
 *
 * The daemon runs aiManagementServer (HTTP+WS on port 9090) as a detached
 * background process. PID and port are stored in ~/.khyquant/daemon.pid.
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');
const { getDataDir } = require('../utils/dataHome');

const PID_FILE = path.join(getDataDir(), 'daemon.pid');
const LOG_FILE = path.join(getDataDir('logs'), 'daemon.log');
const DAEMON_ENTRY = path.join(__dirname, 'daemonEntry.js');
const DEFAULT_PORT = parseInt(process.env.KHY_DAEMON_PORT || '9090', 10);

/**
 * Read the PID file.
 * @returns {{ pid: number, port: number, startedAt: number } | null}
 */
function _readPidFile() {
  try {
    const raw = fs.readFileSync(PID_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/**
 * Check if a process is alive.
 * @param {number} pid
 * @returns {boolean}
 */
function _isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

/**
 * Start the daemon process.
 * @param {object} [opts]
 * @param {number} [opts.port] - Port for HTTP/WS server
 * @returns {{ pid: number, port: number }}
 */
function daemonStart(opts = {}) {
  const existing = _readPidFile();
  if (existing && _isAlive(existing.pid)) {
    throw new Error(`Daemon already running (PID ${existing.pid}, port ${existing.port})`);
  }

  const port = opts.port || DEFAULT_PORT;

  // Open log file for append
  const logFd = fs.openSync(LOG_FILE, 'a');

  const child = spawn(process.execPath, [DAEMON_ENTRY], {
    detached: true,
    stdio: ['ignore', logFd, logFd],
    env: {
      ...process.env,
      KHY_DAEMON_PORT: String(port),
      KHY_DAEMON_PID_FILE: PID_FILE,
    },
  });

  // Write PID file
  const info = {
    pid: child.pid,
    port,
    startedAt: Date.now(),
    nodeVersion: process.version,
  };
  fs.writeFileSync(PID_FILE, JSON.stringify(info, null, 2), 'utf-8');

  child.unref();
  fs.closeSync(logFd);

  return { pid: child.pid, port };
}

/**
 * Stop the daemon process.
 * @returns {boolean}
 */
function daemonStop() {
  const info = _readPidFile();
  if (!info) return false;

  if (_isAlive(info.pid)) {
    // Graceful shutdown
    try { process.kill(info.pid, 'SIGTERM'); } catch { /* already gone */ }

    // Wait up to 3 seconds, then force kill
    const deadline = Date.now() + 3000;
    while (_isAlive(info.pid) && Date.now() < deadline) {
      // Busy-wait with short sleep
      const waitUntil = Date.now() + 100;
      while (Date.now() < waitUntil) { /* spin */ }
    }

    if (_isAlive(info.pid)) {
      try { process.kill(info.pid, 'SIGKILL'); } catch { /* ignore */ }
    }
  }

  // Remove PID file
  try { fs.unlinkSync(PID_FILE); } catch { /* ignore */ }
  return true;
}

/**
 * Get daemon status.
 * @returns {{ running: boolean, pid: number|null, port: number|null, uptime: number|null, health: object|null }}
 */
async function daemonStatus() {
  const info = _readPidFile();
  if (!info || !_isAlive(info.pid)) {
    // Clean up stale PID file
    if (info) try { fs.unlinkSync(PID_FILE); } catch { /* ignore */ }
    return { running: false, pid: null, port: null, uptime: null, health: null };
  }

  const uptime = Date.now() - info.startedAt;

  // Probe health endpoint
  let health = null;
  try {
    health = await _httpGet(`http://127.0.0.1:${info.port}/api/health`, 3000);
  } catch { /* not responding yet */ }

  return {
    running: true,
    pid: info.pid,
    port: info.port,
    uptime,
    health,
  };
}

/**
 * Restart the daemon.
 * @param {object} [opts]
 * @returns {{ pid: number, port: number }}
 */
function daemonRestart(opts = {}) {
  daemonStop();
  return daemonStart(opts);
}

/**
 * Get the log file path.
 * @returns {string}
 */
function getLogPath() {
  return LOG_FILE;
}

// ── Helpers ─────────────────────────────────────────────────────────────

function _httpGet(url, timeoutMs) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, { timeout: timeoutMs }, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        try { resolve(JSON.parse(body)); }
        catch { resolve(body); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

module.exports = {
  daemonStart,
  daemonStop,
  daemonStatus,
  daemonRestart,
  getLogPath,
};
