'use strict';

/**
 * Daemon Entry Point — runs the AI management server as a background daemon.
 *
 * This file is spawned by daemonManager.daemonStart() as a detached process.
 * It loads aiManagementServer and keeps running until SIGTERM/SIGINT.
 */
const fs = require('fs');
const path = require('path');

const PORT = parseInt(process.env.KHY_DAEMON_PORT || '9090', 10);
const PID_FILE = process.env.KHY_DAEMON_PID_FILE || '';

function log(msg) {
  const ts = new Date().toISOString();
  process.stdout.write(`[${ts}] [daemon] ${msg}\n`);
}

// ── Startup ─────────────────────────────────────────────────────────────

log(`Starting KHY daemon on port ${PORT} (PID ${process.pid})`);

let server = null;

async function start() {
  try {
    // Try to load aiManagementServer
    const mgmtServer = require('./aiManagementServer');
    if (typeof mgmtServer.start === 'function') {
      server = await mgmtServer.start({ port: PORT });
      log(`Management server started on port ${PORT}`);
    } else if (typeof mgmtServer.createServer === 'function') {
      server = mgmtServer.createServer({ port: PORT });
      log(`Management server created on port ${PORT}`);
    } else {
      // Fallback: start a simple health endpoint
      const http = require('http');
      server = http.createServer((req, res) => {
        if (req.url === '/api/health') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ status: 'ok', pid: process.pid, uptime: process.uptime() }));
        } else {
          res.writeHead(404);
          res.end('Not Found');
        }
      });
      server.listen(PORT, '127.0.0.1', () => {
        log(`Health endpoint started on port ${PORT}`);
      });
    }

    // Restore persisted sessions
    try {
      const sessionPersistence = require('./sessionPersistence');
      const sessions = sessionPersistence.listPersistedSessions();
      log(`Found ${sessions.length} persisted sessions`);
    } catch { /* sessionPersistence not available */ }

  } catch (err) {
    log(`Failed to start: ${err.message}`);
    process.exit(1);
  }
}

// ── Signal handling ─────────────────────────────────────────────────────

function shutdown(signal) {
  log(`Received ${signal}, shutting down...`);

  if (server) {
    if (typeof server.close === 'function') {
      server.close(() => {
        log('Server closed');
        cleanup();
      });
    } else {
      cleanup();
    }
  } else {
    cleanup();
  }

  // Force exit after 5 seconds
  setTimeout(() => {
    log('Force exit after timeout');
    process.exit(0);
  }, 5000).unref();
}

function cleanup() {
  // Remove PID file
  if (PID_FILE) {
    try { fs.unlinkSync(PID_FILE); } catch { /* ignore */ }
  }
  log('Daemon stopped');
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('uncaughtException', (err) => {
  log(`Uncaught exception: ${err.message}`);
  log(err.stack || '');
  // Don't crash — daemon should be resilient
});
process.on('unhandledRejection', (reason) => {
  log(`Unhandled rejection: ${reason instanceof Error ? reason.message : reason}`);
});

start();
