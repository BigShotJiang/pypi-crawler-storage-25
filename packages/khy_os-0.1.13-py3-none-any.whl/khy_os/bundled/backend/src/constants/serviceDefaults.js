'use strict';

/**
 * serviceDefaults.js — Single source of truth for external service URLs/ports.
 *
 * Every env-based default lives here so no file needs to independently
 * hardcode "localhost:XXXX".  Import from this module instead.
 */

const OLLAMA_HOST = process.env.OLLAMA_HOST || 'http://localhost:11434';
const INFERENCE_SERVER_PORT = parseInt(process.env.INFERENCE_SERVER_PORT || '8765', 10);
const AI_BACKEND_URL = process.env.AI_BACKEND_URL || 'http://localhost:9090';
const BACKEND_PORT = parseInt(process.env.PORT || '3000', 10);

// Redis gateway key prefix (shared across all gateway Redis keys)
const REDIS_KEY_PREFIX = process.env.REDIS_KEY_PREFIX || 'khy:gw:';

module.exports = {
  OLLAMA_HOST,
  INFERENCE_SERVER_PORT,
  AI_BACKEND_URL,
  BACKEND_PORT,
  REDIS_KEY_PREFIX,
};
