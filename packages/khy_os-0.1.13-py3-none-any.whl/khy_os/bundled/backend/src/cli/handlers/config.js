/**
 * Hermes-style model configuration helpers.
 * Supports:
 *   - khy config set <key> <value>
 *   - khy config get <key>
 *   - khy config list
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { printSuccess, printError, printInfo, printWarn, printTable } = require('../formatters');
const { parseApiKeyEntries, extractPrimaryApiKey } = require('../../services/apiKeyFormat');

const KEY_ALIASES = Object.freeze({
  'model.provider': 'model.provider',
  model_provider: 'model.provider',
  'model.base_url': 'model.base_url',
  model_base_url: 'model.base_url',
  'model.api_key': 'model.api_key',
  model_api_key: 'model.api_key',
  'model.name': 'model.name',
  model_name: 'model.name',
  'model.default': 'model.default',
  model_default: 'model.default',
  'model.auth_provider': 'model.provider',
  model_auth_provider: 'model.provider',
  'model.api_base_url': 'model.base_url',
  model_api_base_url: 'model.base_url',
  'model.model_id': 'model.name',
  model_model_id: 'model.name',
  'model.endpoint_compatibility': 'model.endpoint_compatibility',
  model_endpoint_compatibility: 'model.endpoint_compatibility',
});

const PROVIDER_TO_ADAPTER = Object.freeze({
  custom: 'relay_api',
  relay: 'relay_api',
  relay_api: 'relay_api',
  relayapi: 'relay_api',
  openai_compatible: 'relay_api',
  'openai-compatible': 'relay_api',

  auto: 'auto',
  ollama: 'ollama',
  localllm: 'localllm',
  local: 'localllm',
  claude: 'claude',
  codex: 'codex',
  kiro: 'kiro',
  cursor: 'cursor',
  trae: 'trae',
  windsurf: 'windsurf',
  api: 'api',
  webrelay: 'relay',
  browserrelay: 'relay',
});

function _adapterToProvider(adapter) {
  const key = String(adapter || '').trim().toLowerCase();
  if (!key) return '';
  if (key === 'relay_api') return 'custom';
  return key;
}

function _normalizeKey(rawKey = '') {
  const raw = String(rawKey || '').trim().toLowerCase();
  if (!raw) return '';
  const compact = raw.replace(/[\s-]+/g, '_');
  return KEY_ALIASES[raw] || KEY_ALIASES[compact] || '';
}

function _resolveAdapterFromProvider(rawProvider = '') {
  const provider = String(rawProvider || '').trim().toLowerCase();
  if (!provider) return '';
  const compact = provider.replace(/\s+/g, '').replace(/-/g, '_');
  return PROVIDER_TO_ADAPTER[provider] || PROVIDER_TO_ADAPTER[compact] || '';
}

function _normalizeCompatibility(raw = '') {
  const value = String(raw || '').trim().toLowerCase();
  if (!value) return 'openai';
  if (value === 'openai' || value === 'openai-compatible' || value === 'openai_compatible') return 'openai';
  if (value === 'anthropic' || value === 'anthropic-compatible' || value === 'anthropic_compatible') return 'anthropic';
  if (value === 'unknown' || value === 'auto' || value === 'detect') return 'unknown';
  return '';
}

function _pickFirstNonEmpty(...candidates) {
  for (const item of candidates) {
    if (item === undefined || item === null) continue;
    const text = String(item).trim();
    if (!text || text === 'true') continue;
    return text;
  }
  return '';
}

function _normalizeOpenAiLikeBaseUrl(raw = '') {
  const input = String(raw || '').trim();
  if (!input) {
    return { ok: false, error: 'empty' };
  }
  let parsed = null;
  try {
    parsed = new URL(input);
  } catch {
    return { ok: false, error: 'invalid-url' };
  }
  const protocol = String(parsed.protocol || '').toLowerCase();
  if (protocol !== 'http:' && protocol !== 'https:') {
    return { ok: false, error: 'invalid-protocol' };
  }

  let pathname = String(parsed.pathname || '').replace(/\/+$/g, '');
  let appendedV1 = false;
  if (!pathname) {
    pathname = '/v1';
    appendedV1 = true;
  } else if (!/\/v1$/i.test(pathname)) {
    pathname = `${pathname}/v1`;
    appendedV1 = true;
  }
  parsed.pathname = pathname;
  parsed.search = '';
  parsed.hash = '';

  const normalized = parsed.toString().replace(/\/$/, '');
  return { ok: true, url: normalized, appendedV1 };
}

function _resolveDefaultOpenCodeConfigPath() {
  return path.join(os.homedir(), '.config', 'opencode', 'opencode.json');
}

function _readJsonFile(filePath) {
  try {
    const text = fs.readFileSync(filePath, 'utf-8');
    return { ok: true, value: JSON.parse(text) };
  } catch (error) {
    return { ok: false, error };
  }
}

function _resolveOpenCodeProfileFromConfig(doc, opts = {}) {
  if (!doc || typeof doc !== 'object') {
    return { ok: false, error: 'invalid-doc' };
  }
  const providerMap = (doc.provider && typeof doc.provider === 'object') ? doc.provider : {};
  const providerKeys = Object.keys(providerMap);
  if (providerKeys.length === 0) {
    return { ok: false, error: 'provider-empty' };
  }

  const requestedProvider = String(opts.providerId || '').trim();
  const providerId = requestedProvider || providerKeys[0];
  const provider = providerMap[providerId];
  if (!provider || typeof provider !== 'object') {
    return { ok: false, error: `provider-missing:${providerId}` };
  }

  const providerOptions = (provider.options && typeof provider.options === 'object') ? provider.options : {};
  const modelMap = (provider.models && typeof provider.models === 'object') ? provider.models : {};
  const modelKeys = Object.keys(modelMap);
  const requestedModel = String(opts.modelId || '').trim();
  const modelId = requestedModel || modelKeys[0] || '';
  if (!modelId) {
    return { ok: false, error: 'model-empty' };
  }

  const baseUrl = _pickFirstNonEmpty(
    providerOptions.baseURL,
    providerOptions.baseUrl,
    providerOptions.url,
    providerOptions.endpoint,
  );
  const apiKeyInput = _pickFirstNonEmpty(
    providerOptions.apiKey,
    providerOptions.apikey,
  );
  const npmProvider = String(provider.npm || '').trim().toLowerCase();
  const compatibility = npmProvider.includes('anthropic') ? 'anthropic' : 'openai';

  return {
    ok: true,
    providerId,
    modelId,
    baseUrl,
    apiKeyInput,
    compatibility,
  };
}

function _resolveEnvPaths() {
  const canonicalPath = process.env.KHY_ENV_FILE
    ? path.resolve(process.env.KHY_ENV_FILE)
    : path.resolve(__dirname, '../../../.env'); // backend/.env
  const mirrorPath = path.resolve(__dirname, '../../../../.env'); // repo root .env
  const syncMirror = String(process.env.KHY_ENV_SYNC_ROOT || 'true').toLowerCase() !== 'false';

  const targets = [canonicalPath];
  if (syncMirror && mirrorPath !== canonicalPath && (fs.existsSync(mirrorPath) || fs.existsSync(canonicalPath))) {
    targets.push(mirrorPath);
  }
  return { canonicalPath, targets };
}

function _patchEnvContent(content, envMap = {}, unsetKeys = []) {
  let next = String(content || '');
  for (const [key, value] of Object.entries(envMap)) {
    const regex = new RegExp(`^${key}=.*$`, 'm');
    const line = `${key}=${value}`;
    if (regex.test(next)) next = next.replace(regex, line);
    else next = next.trimEnd() + '\n' + line + '\n';
  }
  for (const key of unsetKeys) {
    const regex = new RegExp(`^${key}=.*\\n?`, 'm');
    next = next.replace(regex, '');
  }
  return next;
}

function _writeEnvPatch(envMap = {}, unsetKeys = [], options = {}) {
  const { canonicalPath, targets: defaultTargets } = _resolveEnvPaths();
  const targetPath = options.envPath ? path.resolve(options.envPath) : canonicalPath;
  const targets = options.envPath ? [targetPath] : defaultTargets;

  for (const file of targets) {
    let content = '';
    try { content = fs.readFileSync(file, 'utf-8'); } catch { /* no .env yet */ }
    const patched = _patchEnvContent(content, envMap, unsetKeys);
    fs.writeFileSync(file, patched);
  }

  for (const [key, value] of Object.entries(envMap)) {
    process.env[key] = String(value);
  }
  for (const key of unsetKeys) {
    delete process.env[key];
  }
  return targetPath;
}

function _readEnvMap(envPath) {
  const out = {};
  let content = '';
  try {
    content = fs.readFileSync(envPath, 'utf-8');
  } catch {
    return out;
  }
  for (const line of String(content || '').split(/\r?\n/)) {
    if (!line || /^\s*#/.test(line)) continue;
    const idx = line.indexOf('=');
    if (idx <= 0) continue;
    const key = line.slice(0, idx).trim();
    if (!key) continue;
    const rawValue = line.slice(idx + 1).trim();
    out[key] = rawValue.replace(/^['"]|['"]$/g, '');
  }
  return out;
}

function _maskSecret(value = '') {
  const text = String(value || '').trim();
  if (!text) return '';
  if (text.length <= 8) return `${text.slice(0, 2)}****`;
  return `${text.slice(0, 4)}...${text.slice(-2)}`;
}

function _parseModelDefault(value = '') {
  const raw = String(value || '').trim();
  if (!raw) return null;
  const idx = raw.indexOf('/');
  if (idx <= 0 || idx >= raw.length - 1) return null;
  const provider = raw.slice(0, idx).trim();
  const model = raw.slice(idx + 1).trim();
  if (!provider || !model) return null;
  return { provider, model };
}

function _readCurrentModelConfig() {
  const { canonicalPath } = _resolveEnvPaths();
  const envMap = _readEnvMap(canonicalPath);
  const read = (key) => {
    const runtime = process.env[key];
    if (runtime !== undefined && String(runtime).trim() !== '') return String(runtime).trim();
    return String(envMap[key] || '').trim();
  };

  const preferredAdapter = read('GATEWAY_PREFERRED_ADAPTER');
  const preferredModel = read('GATEWAY_PREFERRED_MODEL');
  const relayEndpoint = read('RELAY_API_ENDPOINT');
  const relayApiKey = read('RELAY_API_KEY');
  const relayModel = read('RELAY_API_MODEL');
  const relayCompatibility = read('RELAY_API_COMPATIBILITY');

  const provider = _adapterToProvider(preferredAdapter || (relayEndpoint || relayApiKey || relayModel ? 'relay_api' : ''));
  const defaultModel = preferredModel || (String(preferredAdapter).toLowerCase() === 'relay_api' ? relayModel : '');
  const modelDefault = (provider && defaultModel) ? `${provider}/${defaultModel}` : '';
  const compatibility = relayCompatibility || (String(preferredAdapter).toLowerCase() === 'relay_api' ? 'openai' : '(not set)');

  return {
    envPath: canonicalPath,
    values: {
      'model.provider': provider || '(not set)',
      'model.base_url': relayEndpoint || '(not set)',
      'model.api_key': relayApiKey ? _maskSecret(relayApiKey) : '(not set)',
      'model.name': relayModel || '(not set)',
      'model.default': modelDefault || '(not set)',
      'model.endpoint_compatibility': compatibility || '(not set)',
    },
    raw: {
      preferredAdapter,
      preferredModel,
      relayEndpoint,
      relayApiKey,
      relayModel,
      relayCompatibility,
    },
  };
}

function _printUsage() {
  printInfo('Usage:');
  printInfo('  khy config set model.provider custom');
  printInfo('  khy config set model.base_url https://token.sensenova.cn/v1');
  printInfo('  khy config set model.api_key sk-xxxxx');
  printInfo('  khy config set model.name sensenova-6.7-flash-lite');
  printInfo('  khy config set model.default custom/sensenova-6.7-flash-lite');
  printInfo('  khy config openclaw --custom-base-url https://token.sensenova.cn/v1 --custom-model-id <your-model-id> --custom-api-key sk-xxxxx');
  printInfo('  khy config opencode --base-url https://token.sensenova.cn/v1 --model-id <your-model-id> --api-key sk-xxxxx');
  printInfo('  khy config opencode --config ~/.config/opencode/opencode.json --provider sense-nova');
  printInfo('  khy config get model.default');
  printInfo('  khy config list');
  printInfo('Interactive wizard: khy setup  (full) / khy model  (model only)');
}

function _printSupportedProviders() {
  printInfo('Supported providers: custom, auto, ollama, localllm, claude, codex, kiro, cursor, trae, windsurf, api, relay');
}

function _applyConfigSet(key, value) {
  const canonicalKey = _normalizeKey(key);
  if (!canonicalKey) {
    printError(`Unsupported key: ${key}`);
    printInfo('Supported keys: model.provider, model.base_url, model.api_key, model.name, model.default, model.endpoint_compatibility');
    return false;
  }
  if (!String(value || '').trim()) {
    printError(`Missing value for ${canonicalKey}`);
    return false;
  }

  const envMap = {};
  const unsetKeys = [];
  let successMessage = '';

  if (canonicalKey === 'model.provider') {
    const adapter = _resolveAdapterFromProvider(value);
    if (!adapter) {
      printError(`Unsupported provider: ${value}`);
      _printSupportedProviders();
      return false;
    }
    envMap.GATEWAY_PREFERRED_ADAPTER = adapter;
    envMap.GATEWAY_PREFERRED_STRICT = 'true';
    if (adapter === 'auto') unsetKeys.push('GATEWAY_PREFERRED_MODEL');
    successMessage = `Set model.provider=${_adapterToProvider(adapter)}`;
  } else if (canonicalKey === 'model.base_url') {
    const endpoint = String(value || '').trim();
    if (!/^https?:\/\//i.test(endpoint)) {
      printError('model.base_url must start with http:// or https://');
      return false;
    }
    envMap.RELAY_API_ENDPOINT = endpoint;
    envMap.GATEWAY_PREFERRED_ADAPTER = 'relay_api';
    envMap.GATEWAY_PREFERRED_STRICT = 'true';
    successMessage = `Set model.base_url=${endpoint}`;
  } else if (canonicalKey === 'model.api_key') {
    const parsedEntries = parseApiKeyEntries(value);
    const primaryKey = extractPrimaryApiKey(value);
    const primary = String(primaryKey || (parsedEntries[0] && parsedEntries[0].key) || '').trim();
    if (!primary) {
      printError('model.api_key is empty after parsing');
      return false;
    }
    envMap.RELAY_API_KEY = primary;
    envMap.GATEWAY_PREFERRED_ADAPTER = 'relay_api';
    envMap.GATEWAY_PREFERRED_STRICT = 'true';
    if (parsedEntries.length > 1) envMap.RELAY_API_KEYS = parsedEntries.map((entry) => entry.key).join(',');
    else unsetKeys.push('RELAY_API_KEYS');
    successMessage = parsedEntries.length > 1
      ? `Set model.api_key (parsed ${parsedEntries.length} keys, primary=${_maskSecret(primary)})`
      : 'Set model.api_key';
  } else if (canonicalKey === 'model.name') {
    const modelName = String(value || '').trim();
    envMap.RELAY_API_MODEL = modelName;
    envMap.GATEWAY_PREFERRED_MODEL = modelName;
    envMap.GATEWAY_PREFERRED_ADAPTER = 'relay_api';
    envMap.GATEWAY_PREFERRED_STRICT = 'true';
    successMessage = `Set model.name=${modelName}`;
  } else if (canonicalKey === 'model.endpoint_compatibility') {
    const compatibility = _normalizeCompatibility(value);
    if (!compatibility) {
      printError(`Unsupported endpoint compatibility: ${value}`);
      printInfo('Use: openai-compatible, anthropic-compatible, or unknown');
      return false;
    }
    envMap.GATEWAY_PREFERRED_ADAPTER = 'relay_api';
    envMap.GATEWAY_PREFERRED_STRICT = 'true';
    envMap.RELAY_API_COMPATIBILITY = compatibility;
    if (compatibility === 'anthropic') {
      printWarn('Current relay adapter sends OpenAI-style /chat/completions payloads. Anthropic-only endpoints may fail.');
    }
    successMessage = `Set model.endpoint_compatibility=${compatibility}`;
  } else if (canonicalKey === 'model.default') {
    const parsed = _parseModelDefault(value);
    if (!parsed) {
      printError('model.default must be <provider>/<model>, e.g. custom/sensenova-6.7-flash-lite');
      return false;
    }
    const adapter = _resolveAdapterFromProvider(parsed.provider);
    if (!adapter) {
      printError(`Unsupported provider in model.default: ${parsed.provider}`);
      _printSupportedProviders();
      return false;
    }
    envMap.GATEWAY_PREFERRED_ADAPTER = adapter;
    envMap.GATEWAY_PREFERRED_MODEL = parsed.model;
    envMap.GATEWAY_PREFERRED_STRICT = 'true';
    if (adapter === 'relay_api') envMap.RELAY_API_MODEL = parsed.model;
    successMessage = `Set model.default=${_adapterToProvider(adapter)}/${parsed.model}`;
  }

  const envPath = _writeEnvPatch(envMap, unsetKeys);
  printSuccess(successMessage);
  printInfo(`Saved to: ${envPath}`);
  return true;
}

function _handleConfigOpenClaw(args = [], options = {}) {
  const baseUrl = _pickFirstNonEmpty(
    options['custom-base-url'],
    options.customBaseUrl,
    options['base-url'],
    options.base_url,
    args[0],
  );
  const modelId = _pickFirstNonEmpty(
    options['custom-model-id'],
    options.customModelId,
    options['model-id'],
    options.modelId,
    options.model,
    args[1],
  );
  const apiKeyInput = _pickFirstNonEmpty(
    options['custom-api-key'],
    options.customApiKey,
    options['api-key'],
    options.apiKey,
    options.key,
    args[2],
    process.env.CUSTOM_API_KEY,
  );
  const compatibilityRaw = _pickFirstNonEmpty(
    options['custom-compatibility'],
    options.customCompatibility,
    options.compatibility,
    options.compat,
    options['endpoint-compatibility'],
    options.endpointCompatibility,
    'openai',
  );
  const compatibility = _normalizeCompatibility(compatibilityRaw);

  if (!baseUrl || !modelId) {
    printError('OpenClaw-compatible setup requires base URL and model ID.');
    printInfo('Usage: khy config openclaw --custom-base-url <url> --custom-model-id <model> [--custom-api-key <key>] [--custom-compatibility openai|anthropic]');
    return false;
  }
  if (!compatibility) {
    printError(`Invalid compatibility: ${compatibilityRaw}`);
    printInfo('Use: openai, anthropic, or unknown');
    return false;
  }

  const baseUrlNormalized = _normalizeOpenAiLikeBaseUrl(baseUrl);
  if (!baseUrlNormalized.ok) {
    printError('Invalid custom base URL.');
    printInfo('Use a valid http(s) URL, e.g. https://token.sensenova.cn/v1');
    return false;
  }
  if (baseUrlNormalized.appendedV1) {
    printWarn(`Base URL did not end with /v1. Auto-normalized to: ${baseUrlNormalized.url}`);
  }

  const parsedEntries = parseApiKeyEntries(apiKeyInput);
  const primaryKey = extractPrimaryApiKey(apiKeyInput);
  const primary = String(primaryKey || (parsedEntries[0] && parsedEntries[0].key) || '').trim();
  const envMap = {
    GATEWAY_PREFERRED_ADAPTER: 'relay_api',
    GATEWAY_PREFERRED_STRICT: 'true',
    GATEWAY_PREFERRED_MODEL: modelId,
    RELAY_API_ENDPOINT: baseUrlNormalized.url,
    RELAY_API_MODEL: modelId,
    RELAY_API_COMPATIBILITY: compatibility,
  };
  const unsetKeys = [];
  if (primary) {
    envMap.RELAY_API_KEY = primary;
    if (parsedEntries.length > 1) envMap.RELAY_API_KEYS = parsedEntries.map((entry) => entry.key).join(',');
    else unsetKeys.push('RELAY_API_KEYS');
  } else {
    printWarn('No API key provided. This mirrors OpenClaw optional custom API key mode; runtime may require credentials.');
    unsetKeys.push('RELAY_API_KEY', 'RELAY_API_KEYS');
  }

  const envPath = _writeEnvPatch(envMap, unsetKeys);
  printSuccess(`Applied OpenClaw-compatible custom provider profile: custom/${modelId}`);
  printInfo(`Endpoint compatibility: ${compatibility}`);
  if (compatibility === 'anthropic') {
    printWarn('Current relay adapter uses OpenAI-style requests; anthropic-only endpoints may fail without a compatible bridge.');
  }
  printInfo(`Saved to: ${envPath}`);
  return true;
}

function _handleConfigOpenCode(args = [], options = {}) {
  const configPathRaw = _pickFirstNonEmpty(
    options.config,
    options.file,
    options['config-file'],
    options.opencodeConfig,
  );
  const resolvedConfigPath = configPathRaw
    ? path.resolve(String(configPathRaw))
    : _resolveDefaultOpenCodeConfigPath();
  const providerIdFlag = _pickFirstNonEmpty(
    options.provider,
    options['provider-id'],
    options.providerId,
  );
  const modelIdFlag = _pickFirstNonEmpty(
    options['model-id'],
    options.modelId,
    options.model,
    args[0],
  );
  const baseUrlFlag = _pickFirstNonEmpty(
    options['base-url'],
    options.baseUrl,
    options.baseURL,
    options.url,
    args[1],
  );
  const apiKeyFlag = _pickFirstNonEmpty(
    options['api-key'],
    options.apiKey,
    options.key,
    args[2],
  );
  const compatibilityRaw = _pickFirstNonEmpty(
    options.compatibility,
    options.compat,
    options['endpoint-compatibility'],
    'openai',
  );
  const compatibilityFlag = _normalizeCompatibility(compatibilityRaw);
  if (!compatibilityFlag) {
    printError(`Invalid compatibility: ${compatibilityRaw}`);
    printInfo('Use: openai, anthropic, or unknown');
    return false;
  }

  let profile = null;
  if (!baseUrlFlag || !modelIdFlag || !apiKeyFlag || !providerIdFlag) {
    if (fs.existsSync(resolvedConfigPath)) {
      const readResult = _readJsonFile(resolvedConfigPath);
      if (!readResult.ok) {
        printError(`Failed to parse OpenCode config: ${resolvedConfigPath}`);
        printInfo(`Parse error: ${readResult.error.message || String(readResult.error)}`);
        return false;
      }
      const extracted = _resolveOpenCodeProfileFromConfig(readResult.value, {
        providerId: providerIdFlag,
        modelId: modelIdFlag,
      });
      if (!extracted.ok) {
        printError(`Unable to extract provider/model from OpenCode config (${extracted.error}).`);
        printInfo('Use --provider and --model-id, or provide --base-url/--model-id directly.');
        return false;
      }
      profile = extracted;
    }
  }

  const providerId = providerIdFlag || (profile && profile.providerId) || 'custom';
  const modelId = modelIdFlag || (profile && profile.modelId) || '';
  const baseUrlRaw = baseUrlFlag || (profile && profile.baseUrl) || '';
  const apiKeyInput = apiKeyFlag || (profile && profile.apiKeyInput) || process.env.CUSTOM_API_KEY || '';
  const compatibility = compatibilityFlag === 'openai' && profile && profile.compatibility
    ? profile.compatibility
    : compatibilityFlag;

  if (!baseUrlRaw || !modelId) {
    printError('OpenCode-compatible setup requires base URL and model ID.');
    printInfo('Usage: khy config opencode --base-url <url> --model-id <model> [--api-key <key>] [--compatibility openai|anthropic]');
    printInfo('Or provide --config <opencode.json> and optional --provider/--model-id.');
    return false;
  }

  const baseUrlNormalized = _normalizeOpenAiLikeBaseUrl(baseUrlRaw);
  if (!baseUrlNormalized.ok) {
    printError('Invalid OpenCode base URL.');
    printInfo('Use a valid http(s) URL, e.g. https://token.sensenova.cn/v1');
    return false;
  }
  if (baseUrlNormalized.appendedV1) {
    printWarn(`OpenCode baseURL did not end with /v1. Auto-normalized to: ${baseUrlNormalized.url}`);
  }

  const parsedEntries = parseApiKeyEntries(apiKeyInput);
  const primaryKey = extractPrimaryApiKey(apiKeyInput);
  const primary = String(primaryKey || (parsedEntries[0] && parsedEntries[0].key) || '').trim();
  const envMap = {
    GATEWAY_PREFERRED_ADAPTER: 'relay_api',
    GATEWAY_PREFERRED_STRICT: 'true',
    GATEWAY_PREFERRED_MODEL: modelId,
    RELAY_API_ENDPOINT: baseUrlNormalized.url,
    RELAY_API_MODEL: modelId,
    RELAY_API_COMPATIBILITY: compatibility || 'openai',
  };
  const unsetKeys = [];
  if (primary) {
    envMap.RELAY_API_KEY = primary;
    if (parsedEntries.length > 1) envMap.RELAY_API_KEYS = parsedEntries.map((entry) => entry.key).join(',');
    else unsetKeys.push('RELAY_API_KEYS');
  } else {
    printWarn('No API key provided from OpenCode config/flags. Runtime may require credentials.');
    unsetKeys.push('RELAY_API_KEY', 'RELAY_API_KEYS');
  }

  const envPath = _writeEnvPatch(envMap, unsetKeys);
  printSuccess(`Applied OpenCode-compatible profile: ${providerId}/${modelId}`);
  printInfo(`Endpoint compatibility: ${compatibility || 'openai'}`);
  if (configPathRaw || fs.existsSync(resolvedConfigPath)) {
    printInfo(`Source config: ${resolvedConfigPath}`);
  }
  if (compatibility === 'anthropic') {
    printWarn('Current relay adapter uses OpenAI-style requests; anthropic-only endpoints may fail without a compatible bridge.');
  }
  printInfo(`Saved to: ${envPath}`);
  return true;
}

function _handleConfigGet(args = []) {
  const key = _normalizeKey(args[0] || '');
  if (!key) {
    printError('Usage: khy config get <key>');
    printInfo('Supported keys: model.provider, model.base_url, model.api_key, model.name, model.default, model.endpoint_compatibility');
    return false;
  }
  const snapshot = _readCurrentModelConfig();
  const value = snapshot.values[key];
  printInfo(`${key} = ${value === undefined ? '(not set)' : value}`);
  return true;
}

function _handleConfigList() {
  const snapshot = _readCurrentModelConfig();
  const rows = Object.entries(snapshot.values).map(([key, value]) => [key, String(value)]);
  printTable(['Key', 'Value'], rows);
  printInfo(`Config file: ${snapshot.envPath}`);
  return true;
}

async function handleConfig(subCommand, args = [], options = {}) {
  const action = String(subCommand || args[0] || 'list').trim().toLowerCase();
  const rest = subCommand ? args : args.slice(1);

  if (action === 'set') {
    if (!rest[0]) {
      printError('Usage: khy config set <key> <value>');
      _printUsage();
      return;
    }
    const key = rest[0];
    const value = rest.slice(1).join(' ').trim();
    _applyConfigSet(key, value);
    return;
  }

  if (action === 'get') {
    _handleConfigGet(rest);
    return;
  }

  if (action === 'list') {
    _handleConfigList();
    return;
  }

  if (action === 'openclaw') {
    _handleConfigOpenClaw(args, options);
    return;
  }

  if (action === 'opencode') {
    _handleConfigOpenCode(args, options);
    return;
  }

  printError(`Unsupported sub-command: ${action}`);
  _printUsage();
}

module.exports = {
  handleConfig,
};
