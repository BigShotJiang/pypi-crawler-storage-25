/**
 * CLI Handlers for the AI Gateway system.
 * Commands: gateway status, gateway config, gateway relay
 */
const chalkModule = require('chalk');
const chalk = chalkModule.default || chalkModule;
const readline = require('readline');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { spawn, spawnSync } = require('child_process');
const {
  printSuccess,
  printError,
  printInfo,
  printTable,
  ICON_GATEWAY,
  stripAnsi,
  displayWidth,
  padToWidth,
  truncateToWidth,
  safeTerminalString,
} = require('../formatters');
const { getDataHome, getLegacyDataHome } = require('../../utils/dataHome');
const { OLLAMA_HOST: OLLAMA_HOST_DEFAULT } = require('../../constants/serviceDefaults');
const { parseApiKeyEntries, extractPrimaryApiKey } = require('../../services/apiKeyFormat');

const STRICT_OPERATIONAL_ADAPTERS = new Set(
  String(process.env.KHY_MODEL_STRICT_ADAPTERS || 'codex,claude,windsurf,trae,cursor,relay_api')
    .split(',')
    .map(x => String(x || '').trim().toLowerCase())
    .filter(Boolean)
);
const MODEL_DEEP_PROBE_CACHE_MS = Math.max(
  10000,
  parseInt(process.env.KHY_MODEL_DEEP_PROBE_CACHE_MS || '300000', 10) || 300000
);
const KIRO_PROBE_TIMEOUT_MS = Math.max(
  8000,
  parseInt(process.env.KHY_MODEL_KIRO_PROBE_TIMEOUT_MS || '20000', 10) || 20000
);
const KIRO_MODEL_LIST_TIMEOUT_MS = Math.max(
  KIRO_PROBE_TIMEOUT_MS,
  parseInt(process.env.KHY_MODEL_KIRO_LIST_TIMEOUT_MS || '25000', 10) || 25000
);
const MODEL_PROBE_DEBOUNCE_ENABLED = String(process.env.KHY_MODEL_PROBE_DEBOUNCE || 'true').toLowerCase() !== 'false';
const MODEL_PROBE_DEBOUNCE_DELAY_MS = Math.max(
  0,
  parseInt(process.env.KHY_MODEL_PROBE_DEBOUNCE_DELAY_MS || '600', 10) || 600
);
const MODEL_PROBE_DEBOUNCE_MAX_RETRIES = Math.max(
  1,
  parseInt(process.env.KHY_MODEL_PROBE_DEBOUNCE_MAX_RETRIES || '2', 10) || 2
);
const MODEL_HIDE_UNVERIFIED_ENABLED = String(process.env.KHY_MODEL_HIDE_UNVERIFIED || 'true').toLowerCase() !== 'false';
const MODEL_HIDE_FALLBACK_MODELS_ENABLED = String(process.env.KHY_MODEL_HIDE_FALLBACK_MODELS || 'false').toLowerCase() !== 'false';
const MODEL_HIDE_HINT_MODELS_ENABLED = String(process.env.KHY_MODEL_HIDE_HINT_MODELS || 'false').toLowerCase() !== 'false';
const MODEL_WARN_KEEP_MAX = Math.max(
  1,
  parseInt(process.env.KHY_MODEL_WARN_KEEP_MAX || '3', 10) || 3
);
const _modelDeepProbeCache = new Map(); // key: adapter type -> { at, test }
const _modelDeepProbeInFlight = new Map();
const AI_MANAGE_RUNTIME_FILE = path.join(getDataHome(), 'ai_manage_runtime.json');
const AI_MANAGE_RUNTIME_FILE_LEGACY = path.join(getLegacyDataHome(), 'ai_manage_runtime.json');
const AI_MANAGE_READY_TIMEOUT_MS = Math.max(
  20000,
  parseInt(process.env.AI_MANAGE_READY_TIMEOUT_MS || '65000', 10) || 65000
);
const AI_MANAGE_HEALTH_WAIT_MS = Math.max(
  5000,
  parseInt(process.env.AI_MANAGE_HEALTH_WAIT_MS || '18000', 10) || 18000
);
const AI_MANAGE_HEALTH_POLL_MS = Math.max(
  200,
  parseInt(process.env.AI_MANAGE_HEALTH_POLL_MS || '600', 10) || 600
);
const AI_MANAGE_DAEMON_SCRIPT = path.resolve(__dirname, '../../../scripts/ai-manage-daemon.js');

async function promptWithReplGuard(questions = []) {
  const inquirer = require('inquirer');
  const hadGuard = global.__KHY_INQUIRER_ACTIVE__ === true;
  global.__KHY_INQUIRER_ACTIVE__ = true;
  try {
    return await inquirer.prompt(questions);
  } finally {
    if (!hadGuard) global.__KHY_INQUIRER_ACTIVE__ = false;
  }
}

function _getDeepProbeCache(adapterType) {
  const key = String(adapterType || '').toLowerCase();
  if (!key) return null;
  const entry = _modelDeepProbeCache.get(key);
  if (!entry) return null;
  if ((Date.now() - entry.at) > MODEL_DEEP_PROBE_CACHE_MS) {
    _modelDeepProbeCache.delete(key);
    return null;
  }
  return entry;
}

function _setDeepProbeCache(adapterType, test) {
  const key = String(adapterType || '').toLowerCase();
  if (!key) return;
  _modelDeepProbeCache.set(key, { at: Date.now(), test });
}

function _getAdapterProbeTimeoutMs(adapterType, fallbackMs) {
  const type = String(adapterType || '').toLowerCase();
  if (type === 'kiro') return Math.max(fallbackMs, KIRO_PROBE_TIMEOUT_MS);
  return fallbackMs;
}

function _getAdapterModelListTimeoutMs(adapterType, fallbackMs) {
  const type = String(adapterType || '').toLowerCase();
  if (type === 'kiro') return Math.max(fallbackMs, KIRO_MODEL_LIST_TIMEOUT_MS);
  return fallbackMs;
}

function shouldTreatGenerationFailureAsWarning(adapterType) {
  // CLI-bridge related adapters can be environment-dependent.
  // Keep them selectable with warning instead of hard-blocking.
  // Local inference adapters must pass generation probe; otherwise mark unavailable.
  return ['cli', 'claude', 'codex'].includes(String(adapterType || '').toLowerCase());
}

function _compactReasonText(text, maxLen = 140) {
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (!clean) return '';
  return clean.length > maxLen ? `${clean.slice(0, maxLen - 1)}…` : clean;
}

function _isTimeoutLikeReason(reasonText = '') {
  return /timeout|timed out|stream stalled|reconnecting|channel closed|socket hang up|econnreset|broken pipe|fetch failed|network error/i
    .test(String(reasonText || ''));
}

function _isAuthOrInstallLikeReason(reasonText = '') {
  return /auth|api[_\s-]?key|apikeysource|token|not authenticated|unauthorized|forbidden|login|permission denied|no token|not set|unavailable|command .* not found|not found|enoent/i
    .test(String(reasonText || ''));
}

function _isTransientProbeLikeReason(reasonText = '') {
  return _isTimeoutLikeReason(reasonText)
    || /exited with code|without emitting stream-json output|launch blocked|failed to record rollout items|temporarily unavailable|service unavailable|try again later|overloaded|busy/i
      .test(String(reasonText || ''));
}

function _classifyHiddenReason(status, test, fallbackReason = '') {
  const preferred = _compactReasonText(fallbackReason)
    || _compactReasonText(test?.generation?.error)
    || _compactReasonText(test?.models?.error)
    || _compactReasonText(test?.connectivity?.error)
    || '';
  const text = preferred.toLowerCase();
  if (!text) return '实测失败';
  if (_isAuthOrInstallLikeReason(text)) return `未登录/缺少凭证或未安装: ${preferred}`;
  if (_isTimeoutLikeReason(text)) return `探测超时: ${preferred}`;
  if (text.includes('not detected')) return '未检测到通道可用';
  return preferred;
}

function _extractProbeReasonText(test = {}) {
  return String(
    test?.generation?.error
    || test?.models?.error
    || test?.connectivity?.error
    || ''
  ).trim();
}

function _shouldRetryProbeByDebounce(status = {}, test = {}) {
  const reasonText = _extractProbeReasonText(test);
  if (!reasonText) return false;
  if (_isAuthOrInstallLikeReason(reasonText)) return false;
  return _isTransientProbeLikeReason(reasonText);
}

function _formatModelSourceTag(model = {}) {
  const raw = String(model.discoverySource || model.source || '').trim().toLowerCase();
  if (!raw) return '';
  const map = {
    remote: '远端发现',
    local: '本地发现',
    'remote+local': '远端+本地',
    builtin: '内置',
    config: '配置项',
  };
  const label = map[raw] || raw;
  return chalk.dim(`[${label}]`);
}

function _formatConnectionTag(model = {}) {
  const mode = String(model.connectionMode || '').trim().toLowerCase();
  if (!mode) return '';
  const map = {
    direct: chalk.cyan('⚡直连'),
    bridge: chalk.yellow('🔗中转桥接'),
    proxy: chalk.dim('🔗代理中转'),
    local: chalk.green('📦本地推理'),
    auto: chalk.magenta('✨自动'),
  };
  return map[mode] || chalk.dim(mode);
}

function _formatUpstreamTag(model = {}) {
  const provider = String(model.upstreamProvider || '').trim();
  const host = String(model.upstreamHost || '').trim();
  if (!provider && !host) return '';
  const payload = host ? `${provider || 'unknown'} @ ${host}` : provider;
  return chalk.dim(`[上游:${payload}]`);
}

function _isPreferredAdapterModel(adapterType, modelId) {
  const preferredAdapter = String(process.env.GATEWAY_PREFERRED_ADAPTER || '').trim().toLowerCase();
  const preferredModel = String(process.env.GATEWAY_PREFERRED_MODEL || '').trim();
  if (!preferredAdapter || !preferredModel) return false;
  return preferredAdapter === String(adapterType || '').trim().toLowerCase()
    && String(modelId || '').trim() === preferredModel;
}

function _resolvePreferredAdapterIssue(statuses = [], testResults = {}) {
  const configuredRaw = String(process.env.GATEWAY_PREFERRED_ADAPTER || '').trim();
  const configured = configuredRaw.toLowerCase();
  if (!configured || configured === 'auto') return null;
  const matched = Array.isArray(statuses)
    ? statuses.find((s) => String(s?.type || '').trim().toLowerCase() === configured)
    : null;
  if (!matched) {
    return {
      type: 'invalid',
      configured: configuredRaw,
      message: `首选通道配置错误: "${configuredRaw}" 未注册`,
    };
  }

  const test = testResults && typeof testResults === 'object' ? testResults[matched.type] : null;
  const reason = _compactReasonText(
    test?.generation?.error
    || test?.models?.error
    || test?.connectivity?.error
    || matched.detail
    || ''
  );
  if (!matched.enabled || !matched.available) {
    return {
      type: 'unavailable',
      configured: configuredRaw,
      adapterType: matched.type,
      reason,
      message: reason
        ? `首选通道当前不可用: ${matched.type}（${reason}）`
        : `首选通道当前不可用: ${matched.type}`,
    };
  }
  return null;
}

function _normalizeGatewayStatusCellText(value) {
  return safeTerminalString(String(value || ''))
    .replace(/\r?\n/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function _buildGatewayStatusColumnWidths() {
  const terminalWidth = Math.max(27, Number(process.stdout.columns || 100));
  const fixedChars = 21; // indent + borders + separators + paddings for 6 columns
  const contentBudget = Math.max(6, terminalWidth - fixedChars);

  const preferred = [6, 16, 9, 9, 16, 25];
  const softMinimum = [4, 12, 6, 8, 10, 12];
  const hardMinimum = [1, 4, 3, 4, 6, 6];
  const widths = preferred.slice();
  // Keep adapter names readable as long as possible.
  const shrinkOrder = [5, 4, 2, 3, 0, 1];

  const sumWidths = () => widths.reduce((sum, w) => sum + w, 0);
  const shrinkToMinimum = (minSet) => {
    let total = sumWidths();
    for (const idx of shrinkOrder) {
      if (total <= contentBudget) break;
      const canShrink = Math.max(0, widths[idx] - minSet[idx]);
      if (canShrink <= 0) continue;
      const delta = Math.min(canShrink, total - contentBudget);
      widths[idx] -= delta;
      total -= delta;
    }
  };

  shrinkToMinimum(softMinimum);
  shrinkToMinimum(hardMinimum);

  // Extreme narrow fallback: continue shrinking down to 1-char columns.
  let total = sumWidths();
  if (total > contentBudget) {
    for (const idx of shrinkOrder) {
      while (total > contentBudget && widths[idx] > 1) {
        widths[idx] -= 1;
        total -= 1;
      }
      if (total <= contentBudget) break;
    }
  }

  if (total < contentBudget) widths[5] += (contentBudget - total);

  return widths;
}

function _truncatePlainByWidth(text, maxWidth) {
  const source = String(text || '');
  if (maxWidth <= 0) return '';
  if (displayWidth(source) <= maxWidth) return source;
  let out = '';
  for (const ch of source) {
    if (displayWidth(out + ch) > maxWidth) break;
    out += ch;
  }
  return out;
}

function _renderGatewayStatusCell(value, width, colorizer) {
  const safeWidth = Math.max(1, Number(width) || 1);
  const plain = _normalizeGatewayStatusCellText(stripAnsi(String(value || '')));
  const trimmed = safeWidth >= 4
    ? truncateToWidth(plain, safeWidth)
    : _truncatePlainByWidth(plain, safeWidth);
  const styled = typeof colorizer === 'function' ? colorizer(trimmed) : trimmed;
  return padToWidth(styled, safeWidth);
}

function _printGatewayStatusTable(rows = []) {
  const headers = ['优先级', '适配器', '类型', '状态', '连通', '详情'];
  const widths = _buildGatewayStatusColumnWidths();
  const top = `  ╭${widths.map((w) => '─'.repeat(w + 2)).join('┬')}╮`;
  const mid = `  ├${widths.map((w) => '─'.repeat(w + 2)).join('┼')}┤`;
  const bot = `  ╰${widths.map((w) => '─'.repeat(w + 2)).join('┴')}╯`;

  console.log(chalk.dim(top));
  const headerLine = headers
    .map((header, i) => ` ${_renderGatewayStatusCell(header, widths[i], chalk.cyan)} `)
    .join(chalk.dim('│'));
  console.log(chalk.dim('  │') + headerLine + chalk.dim('│'));
  console.log(chalk.dim(mid));

  for (const row of rows) {
    const cells = [
      _renderGatewayStatusCell(row.priority, widths[0]),
      _renderGatewayStatusCell(row.adapter, widths[1]),
      _renderGatewayStatusCell(row.type, widths[2]),
      _renderGatewayStatusCell(row.status.text, widths[3], row.status.color),
      _renderGatewayStatusCell(row.connectivity.text, widths[4], row.connectivity.color),
      _renderGatewayStatusCell(row.detail, widths[5]),
    ];
    const line = cells.map((cell) => ` ${cell} `).join(chalk.dim('│'));
    console.log(chalk.dim('  │') + line + chalk.dim('│'));
  }
  console.log(chalk.dim(bot));
}

function _modelFamilyKey(model = {}) {
  const base = String(model._baseModelId || '').trim();
  if (base) return base;
  const raw = String(model.id || model.name || '').trim();
  if (!raw) return '';
  return raw.includes('::') ? raw.split('::')[0] : raw;
}

function _isClaudeFamilyModel(model = {}) {
  const modelId = String(model.id || '').trim().toLowerCase();
  const modelName = String(model.name || '').trim().toLowerCase();
  return modelId.startsWith('claude-')
    || modelId.startsWith('claude_')
    || modelName.startsWith('claude ');
}

function _printLatencyAutoTuneSnapshot() {
  try {
    const tuner = require('../../services/chatLatencyAutoTuner');
    if (!tuner || typeof tuner.getAutoTuneSnapshot !== 'function') return;
    const runtimeIsKhy = String(process.env.KHY_RUNTIME_MODE || '').trim().toLowerCase() === 'khy';
    const profile = runtimeIsKhy ? 'khy_chat_interactive' : 'default_chat';
    const snapshot = tuner.getAutoTuneSnapshot(profile);
    const summary = snapshot && snapshot.summary ? snapshot.summary : null;
    if (!summary) return;
    const count = Math.max(0, parseInt(String(summary.count || 0), 10) || 0);
    if (count <= 0) return;

    const p50 = Math.max(0, parseInt(String(summary.p50 || 0), 10) || 0);
    const p95 = Math.max(0, parseInt(String(summary.p95 || 0), 10) || 0);
    const failures = Math.max(0, parseInt(String(summary.failureCount || 0), 10) || 0);
    const noFirst = Math.max(0, parseInt(String(summary.noFirstTokenCount || 0), 10) || 0);
    const failureRate = count > 0 ? Math.round((failures / count) * 100) : 0;
    const noFirstRate = count > 0 ? Math.round((noFirst / count) * 100) : 0;
    const preset = String(snapshot.lastProfile || '') === profile
      ? (String(snapshot.lastPreset || '').trim() || 'pending')
      : 'pending';
    const decisionReason = String(snapshot?.lastDecision?.reason || '').trim();
    const adaptiveTag = String(snapshot?.lastDecision?.adaptiveTag || '').trim();
    const reasonSuffix = decisionReason
      ? `（${decisionReason}${adaptiveTag ? ` · ${adaptiveTag}` : ''}）`
      : '';

    const autoRaw = String(process.env.KHY_CHAT_AUTOTUNE || '').trim().toLowerCase();
    const autoEnabled = autoRaw
      ? !['false', '0', 'off', 'no'].includes(autoRaw)
      : (profile === 'khy_chat_interactive');
    const conf = snapshot?.currentConfig || {};
    const preflightMs = Math.max(0, parseInt(String(conf.KHY_PREFLIGHT_MAX_MS || 0), 10) || 0);
    const preflightProbeMs = Math.max(0, parseInt(String(conf.KHY_PREFLIGHT_ADAPTER_TIMEOUT_MS || 0), 10) || 0);
    const preflightCandidates = Math.max(0, parseInt(String(conf.KHY_PREFLIGHT_MAX_CANDIDATES || 0), 10) || 0);
    const rateWaitMs = Math.max(0, parseInt(String(conf.GATEWAY_RATE_LIMIT_MAX_WAIT_MS || 0), 10) || 0);

    printInfo(`首包延迟统计(${profile}): P50/P95=${p50}/${p95}ms，失败率 ${failureRate}%（${failures}/${count}），无首包 ${noFirstRate}%`);
    printInfo(`自动调参状态: ${autoEnabled ? '已启用' : '已关闭'}，当前档位: ${preset}${reasonSuffix}`);
    printInfo(`自动调参参数: preflight ${preflightMs}ms / probe ${preflightProbeMs}ms / candidates ${preflightCandidates} / retry-wait ${rateWaitMs}ms`);
  } catch { /* best effort */ }
}

function _filterModelsByReliability(adapterStatus = {}, test = {}, models = []) {
  const sourceModels = Array.isArray(models) ? models.filter(Boolean) : [];
  if (sourceModels.length <= 1) {
    return { models: sourceModels, filtered: 0, reasons: [] };
  }
  const adapterType = String(adapterStatus.type || '').toLowerCase();
  const generationWarn = !!(test?.generation && !test.generation.success && shouldTreatGenerationFailureAsWarning(adapterType));
  let kept = sourceModels.slice();
  let filtered = 0;
  const reasons = [];
  const hideFallbackForAdapter = adapterType === 'codex';
  const hideHintForAdapter = adapterType === 'codex';

  if (adapterType === 'codex') {
    const next = kept.filter((m) => !_isClaudeFamilyModel(m));
    const removed = kept.length - next.length;
    if (removed > 0) {
      filtered += removed;
      reasons.push('cross-provider-claude');
    }
    kept = next;
  }

  if (MODEL_HIDE_HINT_MODELS_ENABLED && hideHintForAdapter) {
    const next = kept.filter((m) => String(m.discoverySource || '').trim().toLowerCase() !== 'hint');
    const removed = kept.length - next.length;
    if (removed > 0) {
      filtered += removed;
      reasons.push('hint');
    }
    kept = next;
  }

  if (MODEL_HIDE_FALLBACK_MODELS_ENABLED && hideFallbackForAdapter) {
    const next = kept.filter((m) => String(m.discoverySource || '').trim().toLowerCase() !== 'builtin');
    const removed = kept.length - next.length;
    if (removed > 0) {
      filtered += removed;
      reasons.push('builtin');
    }
    kept = next;
  }

  if (MODEL_HIDE_UNVERIFIED_ENABLED && generationWarn && kept.length > MODEL_WARN_KEEP_MAX) {
    const strictKeep = kept.filter((m) => (
      !!m.isDefault || _isPreferredAdapterModel(adapterType, m.id)
    ));
    const normalizedKeep = [];
    const seenIds = new Set();
    const seenFamilies = new Set();
    const pushOne = (m) => {
      if (!m || normalizedKeep.length >= MODEL_WARN_KEEP_MAX) return;
      const id = String(m.id || '');
      if (id && seenIds.has(id)) return;
      normalizedKeep.push(m);
      if (id) seenIds.add(id);
      const fam = _modelFamilyKey(m);
      if (fam) seenFamilies.add(fam);
    };
    for (const m of strictKeep) pushOne(m);
    for (const m of kept) {
      if (normalizedKeep.length >= MODEL_WARN_KEEP_MAX) break;
      const fam = _modelFamilyKey(m);
      if (fam && seenFamilies.has(fam)) continue;
      pushOne(m);
    }
    for (const m of kept) {
      if (normalizedKeep.length >= MODEL_WARN_KEEP_MAX) break;
      pushOne(m);
    }
    const removed = kept.length - normalizedKeep.length;
    if (removed > 0) {
      filtered += removed;
      reasons.push('warn-unverified');
    }
    kept = normalizedKeep;
  }

  if (kept.length === 0) {
    const fallback = sourceModels.find((m) => (
      !!m.isDefault || _isPreferredAdapterModel(adapterType, m.id)
    )) || sourceModels[0];
    kept = fallback ? [fallback] : [];
  }
  return { models: kept, filtered, reasons };
}

async function maybeAutoSyncSwitchCenterForGateway(source = 'gateway') {
  try {
    const proxyHandlers = require('./proxy');
    if (!proxyHandlers || typeof proxyHandlers.maybeAutoSyncSwitchCenter !== 'function') return null;
    const preferredAdapter = String(process.env.GATEWAY_PREFERRED_ADAPTER || '').trim().toLowerCase();
    const inferredProvider = preferredAdapter === 'trae'
      ? 'trae'
      : (preferredAdapter === 'windsurf' ? 'windsurf' : 'windsurf');
    return await proxyHandlers.maybeAutoSyncSwitchCenter({
      quiet: true,
      source,
      provider: process.env.SWITCH_CENTER_AUTO_PROVIDER || 'auto',
      preferredProvider: inferredProvider,
    });
  } catch {
    return null;
  }
}

function maskTokenValue(raw) {
  const token = String(raw || '').trim();
  if (!token) return '(empty)';
  if (token.length <= 10) return `${token.slice(0, 3)}***`;
  return `${token.slice(0, 6)}***${token.slice(-4)}`;
}

function parseProviderFromModelId(modelId) {
  const m = String(modelId || '').trim().match(/^([a-z0-9_-]+)[:/](.+)$/i);
  return m ? m[1].toLowerCase() : null;
}

const KEY_SELECTION_STRATEGY_CHOICES = [
  { name: 'round-robin (默认，优先级内轮询)', value: 'round-robin' },
  { name: 'least-fail (优先失败率低的 key)', value: 'least-fail' },
  { name: 'least-used (优先调用次数少的 key)', value: 'least-used' },
  { name: 'hybrid (综合失败率/退避/使用次数)', value: 'hybrid' },
];

const API_POOL_PROVIDER_KEYS = [
  'openai',
  'anthropic',
  'trae',
  'deepseek',
  'qwen',
  'glm',
  'doubao',
  'wenxin',
  'relay',
];

function _parseJsonObject(raw, fallback = {}) {
  const text = String(raw || '').trim();
  if (!text) return { ...fallback };
  try {
    const parsed = JSON.parse(text);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
  } catch {
    return { ...fallback };
  }
  return { ...fallback };
}

function _safeJsonLine(obj) {
  try {
    return JSON.stringify(obj || {});
  } catch {
    return '{}';
  }
}

function getPoolHint(provider) {
  if (!provider) return null;
  try {
    const pool = require('../../services/apiKeyPool');
    pool.init();
    const entries = pool.getPoolStatus(provider);
    if (!entries || entries.length === 0) return null;
    const previews = entries.slice(0, 2).map(e => e.keyPreview).join(', ');
    const more = entries.length > 2 ? ` +${entries.length - 2}` : '';
    return `池中 ${entries.length} 把 key (${previews}${more})`;
  } catch {
    return null;
  }
}

function getTokenInfoForSelection(selected) {
  const adapter = String(selected?.adapter || '').toLowerCase();
  const model = selected?.model || '';

  if (!adapter) return { source: 'unknown', detail: '未知适配器' };

  if (adapter === 'cursor2api') {
    try {
      const svc = require('../../services/cursor2apiIntegrationService');
      const cfg = svc.loadConfig();
      const token = process.env.CURSOR2API_TOKEN || cfg.authToken || '';
      return token
        ? { source: 'CURSOR2API_TOKEN', detail: maskTokenValue(token) }
        : { source: 'CURSOR2API_TOKEN', detail: '未设置' };
    } catch {
      return { source: 'CURSOR2API_TOKEN', detail: '读取失败' };
    }
  }

  if (adapter === 'relay_api') {
    const token = process.env.RELAY_API_KEY || '';
    if (token) return { source: 'RELAY_API_KEY', detail: maskTokenValue(token) };
    const poolHint = getPoolHint('relay');
    return { source: 'RELAY_API_KEY', detail: poolHint || '未设置' };
  }

  if (adapter === 'api') {
    const provider = parseProviderFromModelId(model);
    const envMap = {
      openai: 'OPENAI_API_KEY',
      anthropic: 'ANTHROPIC_API_KEY',
      deepseek: 'DEEPSEEK_API_KEY',
      qwen: 'QWEN_API_KEY',
      glm: 'GLM_API_KEY',
      doubao: 'DOUBAO_API_KEY',
      wenxin: 'WENXIN_API_KEY',
      trae: 'TRAE_API_KEY',
      relay: 'RELAY_API_KEY',
    };
    const envKey = provider ? envMap[provider] : null;
    if (envKey && process.env[envKey]) {
      return { source: envKey, detail: maskTokenValue(process.env[envKey]) };
    }
    const poolHint = getPoolHint(provider);
    if (provider) {
      return { source: provider, detail: poolHint || '未设置' };
    }
    return { source: 'api', detail: '该模型未包含 provider 前缀，无法定位 token' };
  }

  if (['cli', 'claude', 'codex', 'cursor', 'kiro', 'trae', 'warp', 'windsurf', 'vscode'].includes(adapter)) {
    return { source: 'local-login', detail: '本地 IDE/CLI 登录态（非显式 API token）' };
  }

  if (adapter === 'ollama' || adapter === 'localllm') {
    return { source: 'local-model', detail: '本地模型通道（无需 token）' };
  }

  if (adapter === 'relay' || adapter === 'clipboard') {
    return { source: 'manual-relay', detail: '网页/剪贴板中转（无需 API token）' };
  }

  return { source: adapter, detail: '未定义 token 映射' };
}

function getSharedReadline() {
  try {
    const toolCalling = require('../../services/toolCalling');
    const provider = toolCalling.getReadlineProvider ? toolCalling.getReadlineProvider() : null;
    return typeof provider === 'function' ? provider() : provider;
  } catch {
    return null;
  }
}

function askLine(promptText) {
  return new Promise((resolve) => {
    const shared = getSharedReadline();
    if (shared && typeof shared.question === 'function') {
      shared.question(promptText, (answer) => resolve(answer));
      return;
    }
    const temp = readline.createInterface({ input: process.stdin, output: process.stdout });
    temp.question(promptText, (answer) => {
      temp.close();
      resolve(answer);
    });
  });
}

function recoverGatewayPromptInput() {
  try {
    if (typeof process.stdin.setRawMode === 'function' && process.stdin.isRaw) {
      process.stdin.setRawMode(false);
    }
  } catch { /* ignore */ }
  try { process.stdin.resume(); } catch { /* ignore */ }
}

async function withTimeout(promise, ms, label = 'operation') {
  let timer = null;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} timeout after ${ms}ms`)), ms);
    if (timer && typeof timer.unref === 'function') timer.unref();
  });
  try {
    return await Promise.race([promise, timeout]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function isAdapterOperational(status, test, strictOperationalAdapters = STRICT_OPERATIONAL_ADAPTERS) {
  if (!status || !status.enabled || !status.available) return false;
  if (!test?.connectivity?.success) return false;
  const adapterType = String(status.type || '').toLowerCase();
  const strictMode = strictOperationalAdapters.has(adapterType);
  if (strictMode && test?.models) {
    if (!test.models.success) return false;
    if (Number(test.models.count || 0) <= 0) return false;
  }
  if (test?.generation && !test.generation.success) {
    if (!shouldTreatGenerationFailureAsWarning(adapterType)) return false;
    if (strictMode) {
      const reasonText = String(test?.generation?.error || '');
      // For strict adapters, keep auth/install failures blocked.
      // Timeout/process-like probe failures are treated as warning to avoid false negatives.
      if (_isAuthOrInstallLikeReason(reasonText)) return false;
      if (!_isTransientProbeLikeReason(reasonText)) return false;
    }
  }
  return true;
}

function _resolveEnvPathsForGateway() {
  const fs = require('fs');
  const path = require('path');
  const canonicalPath = process.env.KHY_ENV_FILE
    ? path.resolve(process.env.KHY_ENV_FILE)
    : path.resolve(__dirname, '../../../.env'); // backend/.env
  const mirrorPath = path.resolve(__dirname, '../../../../.env'); // repo root .env
  const syncMirror = String(process.env.KHY_ENV_SYNC_ROOT || 'true').toLowerCase() !== 'false';

  const targets = [canonicalPath];
  if (syncMirror && mirrorPath !== canonicalPath && (fs.existsSync(mirrorPath) || fs.existsSync(canonicalPath))) {
    targets.push(mirrorPath);
  }
  return {
    canonicalPath,
    targets,
  };
}

function _patchEnvContent(content, envMap = {}, unsetKeys = []) {
  let next = String(content || '');
  for (const [key, value] of Object.entries(envMap)) {
    const regex = new RegExp(`^${key}=.*$`, 'm');
    const line = `${key}=${value}`;
    if (regex.test(next)) next = next.replace(regex, line);
    else next = next.trimEnd() + '\n' + line + '\n';
  }
  for (const key of unsetKeys) {
    const regex = new RegExp(`^${key}=.*\\n?`, 'm');
    next = next.replace(regex, '');
  }
  return next;
}

function _writeEnvPatch(envMap = {}, unsetKeys = [], options = {}) {
  const fs = require('fs');
  const path = require('path');
  const resolved = _resolveEnvPathsForGateway();
  const canonicalPath = options.envPath
    ? path.resolve(options.envPath)
    : resolved.canonicalPath;
  const targets = options.envPath ? [canonicalPath] : resolved.targets;

  for (const targetPath of targets) {
    let content = '';
    try { content = fs.readFileSync(targetPath, 'utf-8'); } catch { /* no .env yet */ }
    const patched = _patchEnvContent(content, envMap, unsetKeys);
    fs.writeFileSync(targetPath, patched);
  }

  for (const [key, value] of Object.entries(envMap)) {
    process.env[key] = String(value);
  }
  for (const key of unsetKeys) {
    delete process.env[key];
  }
  return canonicalPath;
}

function persistGatewayPreference(selected) {
  const envMap = {
    GATEWAY_PREFERRED_ADAPTER: selected.adapter,
    GATEWAY_PREFERRED_STRICT: 'true',
  };
  if (selected.model) envMap.GATEWAY_PREFERRED_MODEL = selected.model;
  const unsetKeys = selected.model ? [] : ['GATEWAY_PREFERRED_MODEL'];
  _writeEnvPatch(envMap, unsetKeys);
}

function _resolveEnvPathForGateway() {
  const { canonicalPath } = _resolveEnvPathsForGateway();
  return canonicalPath;
}

function _resolveEnvPathForDiscoverModels() {
  const fs = require('fs');
  const path = require('path');
  const { canonicalPath } = _resolveEnvPathsForGateway();
  const candidates = [
    canonicalPath,
    path.resolve(__dirname, '../../../../.env'),
  ];
  return candidates.find(p => fs.existsSync(p)) || candidates[0];
}

function _writeEnvMap(envMap = {}, options = {}) {
  return _writeEnvPatch(envMap, [], options);
}

function _unsetEnvKeys(keys = [], options = {}) {
  return _writeEnvPatch({}, keys, options);
}

async function handleGatewayTuneLocal(args = [], options = {}) {
  const hw = require('../../services/hardwareProfileService');
  const modeArg = String(args[0] || options.mode || 'auto').trim().toLowerCase();
  const mode = ['auto', 'fast', 'balanced', 'quality'].includes(modeArg) ? modeArg : 'auto';
  const apply = !!options.apply
    || modeArg === 'apply'
    || String(args[1] || '').trim().toLowerCase() === 'apply'
    || String(args[1] || '').trim().toLowerCase() === '--apply'
    || String(args[2] || '').trim().toLowerCase() === '--apply';
  const rec = hw.recommendLocalAiTuning(mode);
  const rows = Object.entries(rec.env).map(([k, v]) => [k, String(v)]);

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('本地 AI 智能调优')}`);
  console.log('');
  printInfo(`硬件画像: ${rec.profile}`);
  printInfo(`推荐档位: ${rec.label} (${rec.mode})`);
  printInfo(`依据: ${rec.reason}`);
  console.log('');
  printTable(['配置项', '推荐值'], rows);
  console.log('');

  if (apply) {
    const envPath = _writeEnvMap(rec.env, {});
    printSuccess(`已写入智能匹配配置: ${envPath}`);
    printInfo('新会话将自动生效；当前进程已更新环境变量');
    console.log('');
    return {
      applied: true,
      mode,
      profile: rec.profile,
      envPath,
      values: rec.env,
    };
  }

  printInfo('预览模式：未写入 .env');
  printInfo('应用命令: khy gateway tune-local ' + mode + ' apply');
  console.log('');
  return {
    applied: false,
    mode,
    profile: rec.profile,
    values: rec.env,
  };
}

async function handleGatewayPreferRemote(options = {}) {
  const silent = !!options.silent;
  const probeOnlyAvailable = !!options.probeOnlyAvailable;
  const logInfo = (...args) => { if (!silent) printInfo(...args); };
  const logError = (...args) => { if (!silent) printError(...args); };
  const logSuccess = (...args) => { if (!silent) printSuccess(...args); };

  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus().filter(s => s.enabled);
  const localTypes = new Set(['localllm', 'ollama']);
  const remoteStatuses = statuses.filter((s) => {
    if (localTypes.has(String(s.type || '').toLowerCase())) return false;
    if (probeOnlyAvailable && !s.available) return false;
    return true;
  });
  if (remoteStatuses.length === 0) {
    logError('未找到远程通道（API/桥接/CLI）');
    logInfo('可运行 khy gateway config 配置 API 或桥接通道');
    return {
      switched: false,
      selected: null,
      reason: 'no-remote-channel',
      tested: 0,
    };
  }

  const requestedProbeTimeoutMs = Number(options.probeTimeoutMs);
  const probeTimeoutDefaultMs = parseInt(process.env.KHY_MODEL_PROBE_TIMEOUT_MS || '8000', 10) || 8000;
  const probeTimeoutBaseMs = Number.isFinite(requestedProbeTimeoutMs) ? requestedProbeTimeoutMs : probeTimeoutDefaultMs;
  const probeTimeoutMs = Math.max(Number.isFinite(requestedProbeTimeoutMs) ? 1000 : 4000, probeTimeoutBaseMs);
  const requestedGenerationProbeTimeoutMs = Number(options.probeGenerationTimeoutMs);
  const generationProbeTimeoutDefaultMs = parseInt(
    process.env.KHY_MODEL_PROBE_GENERATION_TIMEOUT_MS || '25000',
    10
  ) || 25000;
  const generationProbeTimeoutBaseMs = Number.isFinite(requestedGenerationProbeTimeoutMs)
    ? requestedGenerationProbeTimeoutMs
    : generationProbeTimeoutDefaultMs;
  const generationProbeTimeoutMs = Math.max(
    probeTimeoutMs,
    generationProbeTimeoutBaseMs
  );
  logInfo(`探测远程通道可用性（单通道超时 ${Math.round(probeTimeoutMs / 1000)}s）...`);

  const testResults = {};
  await Promise.all(remoteStatuses.map(async (s) => {
    const adapterType = String(s.type || '').toLowerCase();
    const requireGenerationProbe = STRICT_OPERATIONAL_ADAPTERS.has(adapterType);
    const adapterProbeTimeoutMs = _getAdapterProbeTimeoutMs(adapterType, probeTimeoutMs);
    const adapterGenerationProbeTimeoutMs = Math.max(adapterProbeTimeoutMs, generationProbeTimeoutMs);
    try {
      testResults[s.type] = await withTimeout(
        gateway.testAdapter(s.type, {
          quick: !requireGenerationProbe,
          timeoutMs: adapterProbeTimeoutMs,
          probeGenerationTimeoutMs: adapterGenerationProbeTimeoutMs,
        }),
        Math.max(adapterProbeTimeoutMs + 1000, adapterGenerationProbeTimeoutMs + 1000),
        `${s.type} probe`
      );
    } catch (err) {
      testResults[s.type] = {
        connectivity: {
          success: false,
          latencyMs: adapterProbeTimeoutMs,
          error: err && err.message ? err.message : 'probe failed',
        },
      };
    }
  }));

  const rankByAdapter = {
    api: 100,
    relay_api: 95,
    cursor2api: 90,
    cli: 85,
    claude: 80,
    codex: 78,
    cursor: 76,
    kiro: 74,
    trae: 72,
    windsurf: 68,
    vscode: 66,
    warp: 64,
    relay: 50,
  };

  const candidates = [];
  for (const s of remoteStatuses) {
    const test = testResults[s.type];
    if (!isAdapterOperational(s, test, STRICT_OPERATIONAL_ADAPTERS)) continue;

    const generationWarn = !!(test?.generation && !test.generation.success && shouldTreatGenerationFailureAsWarning(s.type));
    let selectedModel = null;
    try {
      const modelListTimeoutMs = _getAdapterModelListTimeoutMs(s.type, Math.max(3000, probeTimeoutMs));
      const models = await withTimeout(gateway.listModels(s.type), modelListTimeoutMs, `${s.type} listModels`);
      if (Array.isArray(models) && models.length > 0) {
        const filteredModels = _filterModelsByReliability(s, test, models).models;
        const preferred = filteredModels.find(m => m && m.isDefault) || filteredModels[0];
        selectedModel = preferred ? preferred.id : null;
      }
    } catch { /* keep null */ }

    const baseRank = Number(rankByAdapter[s.type] || 40);
    const warnPenalty = generationWarn ? 15 : 0;
    const latencyPenalty = Math.min(20, Math.round((Number(test?.connectivity?.latencyMs || 0) || 0) / 200));
    const score = baseRank - warnPenalty - latencyPenalty;

    candidates.push({
      adapter: s.type,
      model: selectedModel,
      score,
      latencyMs: Number(test?.connectivity?.latencyMs || 0) || 0,
      warn: generationWarn,
      detail: generationWarn ? (test?.generation?.error || 'generation warn') : '',
    });
  }

  if (candidates.length === 0) {
    logError('未找到可用远程通道');
    logInfo('可运行 khy gateway status 查看失败详情，或 khy gateway config 配置 API/桥接');
    return {
      switched: false,
      selected: null,
      reason: 'no-operational-remote',
      tested: remoteStatuses.length,
    };
  }

  candidates.sort((a, b) => b.score - a.score || a.latencyMs - b.latencyMs);
  const selected = candidates[0];
  persistGatewayPreference(selected);
  try { gateway.syncModelSwitch(selected.model || null); } catch { /* best effort */ }
  try { await gateway.refreshAdapters(); } catch { /* best effort */ }

  const tokenInfo = getTokenInfoForSelection(selected);
  const warnText = selected.warn ? `（实测告警: ${selected.detail || 'generation warn'}）` : '';
  logSuccess(`已切换默认远程通道: ${selected.adapter}${selected.model ? ` · ${selected.model}` : ''}`);
  logInfo(`探测得分: ${selected.score} · 延迟: ${selected.latencyMs}ms ${warnText}`);
  logInfo(`Token: ${tokenInfo.source} → ${tokenInfo.detail}`);

  if (options.fromDoctor) {
    logInfo('已根据 doctor 诊断自动避开本地受限通道');
  }

  return {
    switched: true,
    selected,
    tokenInfo,
    tested: remoteStatuses.length,
    reason: 'switched',
  };
}

/**
 * Display status of all gateway adapters with live connectivity test.
 */
async function handleGatewayStatus() {
  const gateway = require('../../services/gateway/aiGateway');
  const autoSync = await maybeAutoSyncSwitchCenterForGateway('gateway-status');
  if (!gateway._initialized) await gateway.init();
  if (autoSync && autoSync.synced && (autoSync.changed || autoSync.activeChanged)) {
    try { await gateway.refreshAdapters(); } catch { /* best effort */ }
    printInfo(`已自动同步 switch-center: ${(autoSync.profileName || autoSync.profileId || 'windsurf-auto')} (${autoSync.modelsCount || 0} models)`);
  }

  const statuses = gateway.getStatus();

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('AI 网关状态')}`);
  console.log(chalk.dim('  正在检测各通道连通性...'));
  console.log('');

  // Run connectivity tests in parallel for enabled+available adapters
  // Global timeout ensures the entire test phase finishes within a reasonable wall-clock window.
  const GLOBAL_TEST_TIMEOUT_MS = parseInt(process.env.GATEWAY_STATUS_TIMEOUT_MS || '20000', 10) || 20000;
  const testPromises = {};
  for (const s of statuses) {
    if (s.enabled && s.available) {
      testPromises[s.type] = gateway.testAdapter(s.type).catch(() => null);
    }
  }
  const testResults = {};
  const globalDeadline = Date.now() + GLOBAL_TEST_TIMEOUT_MS;
  for (const [key, promise] of Object.entries(testPromises)) {
    const remaining = globalDeadline - Date.now();
    if (remaining <= 0) {
      testResults[key] = { connectivity: { success: false, latencyMs: 0, error: 'global timeout' } };
      continue;
    }
    testResults[key] = await Promise.race([
      promise,
      new Promise(resolve => setTimeout(() => resolve({ connectivity: { success: false, latencyMs: 0, error: 'global timeout' } }), remaining)),
    ]);
  }
  const preferredIssue = _resolvePreferredAdapterIssue(statuses, testResults);
  const importCommands = [];

  const effectiveStatuses = statuses.map(s => {
    const test = testResults[s.type];
    if (s.enabled && s.available && test?.connectivity && !test.connectivity.success) {
      const reason = test.connectivity.error || 'connectivity failed';
      return {
        ...s,
        available: false,
        detail: `${s.detail}（连通失败: ${reason}）`,
      };
    }
    if (s.enabled && s.available && test?.generation && !test.generation.success) {
      if (shouldTreatGenerationFailureAsWarning(s.type)) {
        const reason = test.generation.error || 'generation probe failed';
        return {
          ...s,
          available: true,
          detail: `${s.detail}（实测告警: ${reason}）`,
        };
      }
      const reason = test.generation.error || 'generation probe failed';
      return {
        ...s,
        available: false,
        detail: `${s.detail}（实测不可用: ${reason}）`,
      };
    }
    return s;
  });

  _printGatewayStatusTable(
    effectiveStatuses.map(s => {
      const test = testResults[s.type];
      if (
        String(s.type || '').toLowerCase() === 'localllm'
        && !s.available
        && typeof s.importCommand === 'string'
        && s.importCommand.trim()
      ) {
        importCommands.push(s.importCommand.trim());
      }
      let connectivityText = '—';
      let connectivityColor = chalk.dim;
      if (!s.enabled) {
        connectivityText = '已禁用';
        connectivityColor = chalk.dim;
      } else if (!s.available) {
        if (test?.generation && !test.generation.success) {
          connectivityText = `● ${test.generation.error || 'generation failed'}`;
          connectivityColor = chalk.red;
        } else {
          connectivityText = '—';
          connectivityColor = chalk.dim;
        }
      } else if (test) {
        if (test.connectivity?.success) {
          const ms = test.connectivity.latencyMs;
          const modelOk = test.models?.success;
          const generationFail = test.generation && !test.generation.success;
          if (generationFail) {
            connectivityText = `● ${test.generation.error || 'generation failed'}`;
            connectivityColor = chalk.red;
          } else if (modelOk) {
            connectivityText = `● ${ms}ms (${test.models.count} models)`;
            connectivityColor = chalk.green;
          } else if (test.models) {
            connectivityText = `● ${ms}ms (models: ${test.models.error})`;
            connectivityColor = chalk.yellow;
          } else {
            connectivityText = `● ${ms}ms`;
            connectivityColor = chalk.green;
          }
        } else {
          connectivityText = `● ${test.connectivity?.error || 'failed'}`;
          connectivityColor = chalk.red;
        }
      }

      const statusText = s.enabled
        ? (s.available ? '✓ 可用' : '⚠ 不可用')
        : '已禁用';
      const statusColor = !s.enabled
        ? chalk.dim
        : (s.available ? chalk.green : chalk.yellow);

      return {
        priority: String(s.priority),
        adapter: s.name,
        type: s.type,
        status: {
          text: statusText,
          color: statusColor,
        },
        connectivity: {
          text: connectivityText,
          color: connectivityColor,
        },
        detail: s.detail,
      };
    })
  );

  if (importCommands.length > 0) {
    const uniqueCommands = [...new Set(importCommands)];
    printInfo('检测到可导入模型格式，可直接执行:');
    for (const command of uniqueCommands) {
      printInfo(`  ${command}`);
    }
  }

  // Keep the "active channel" consistent with effective availability shown above.
  const activeEntry = effectiveStatuses.find(s => s.enabled && s.available);
  const active = activeEntry ? { name: activeEntry.name, type: activeEntry.type } : null;
  if (active) {
    console.log('');
    printSuccess(`当前活跃通道: ${active.name} (${active.type})`);
  } else {
    console.log('');
    printInfo('无活跃通道 — 可用 khy gateway relay 启动 Web 中转');
  }
  if (preferredIssue) {
    if (preferredIssue.type === 'invalid') {
      printError(preferredIssue.message);
      printInfo('修复建议: 运行 khy gateway model 重新选择可执行通道');
    } else if (preferredIssue.type === 'unavailable') {
      printInfo(preferredIssue.message);
      printInfo('建议: 运行 khy gateway test <adapter> 复测，或用 khy gateway model 切换通道');
    }
  }
  _printLatencyAutoTuneSnapshot();
  const envPath = _resolveEnvPathForGateway();
  const proxyFile = path.join(os.homedir(), '.khyquant', 'proxy.json');
  const apiKeysPoolFile = path.join(os.homedir(), '.khyquant', 'api_keys.json');
  const routeMode = String(process.env.GATEWAY_PROXY_ROUTE_MODE || 'auto').trim().toLowerCase() || 'auto';
  printInfo(`代理配置位置: ${proxyFile}`);
  printInfo(`模型/API Key 配置位置: ${envPath}`);
  printInfo(`多 Key 池位置: ${apiKeysPoolFile}`);
  printInfo(`智能代理路由: GATEWAY_PROXY_ROUTE_MODE=${routeMode} (auto=国外优先代理, 国内直连)`);
  console.log('');
}

/**
 * Interactive gateway configuration.
 */
async function handleGatewayConfig() {
  const inquirer = require('inquirer');
  const hadGuard = global.__KHY_INQUIRER_ACTIVE__ === true;
  global.__KHY_INQUIRER_ACTIVE__ = true;
  try {

  const { action } = await inquirer.prompt([{
    type: 'list',
    name: 'action',
    message: '网关配置:',
    choices: [
      { name: '配置网络代理 (Clash/HTTP)', value: 'proxy-config' },
      { name: '设置 CLI 工具桥接 (开/关)', value: 'cli-toggle' },
      { name: '配置 Ollama 本地模型', value: 'ollama-config' },
      { name: '配置 API 中转 (Claude/GPT 中转站)', value: 'relay-api' },
      { name: '配置模型厂商 API Key (DeepSeek/Qwen/GLM/豆包等)', value: 'provider-keys' },
      { name: '高级: 模型路由规则 (GATEWAY_MODEL_ROUTE_MAP)', value: 'routing-policy' },
      { name: '高级: Key 选择策略 (GATEWAY_KEY_SELECTION_STRATEGY)', value: 'key-strategy' },
      { name: '高级: API 池默认 provider (GATEWAY_API_POOL_PROVIDER)', value: 'api-pool-default' },
      { name: '高级: 供应商映射 (alias/service/default-model)', value: 'api-provider-map' },
      { name: '设置 Web 中转端口', value: 'relay-port' },
      { name: '设置中转超时时间', value: 'relay-timeout' },
      { name: '↩️  返回', value: 'back' },
    ],
  }]);

  if (action === 'back') return;

  function setEnvVar(key, value) {
    _writeEnvMap({ [key]: String(value) });
  }
  function unsetEnvVar(key) {
    _unsetEnvKeys([key]);
  }

  if (action === 'proxy-config') {
    const proxyConfig = require('../../services/proxyConfigService');
    const proxyFile = path.join(os.homedir(), '.khyquant', 'proxy.json');
    const status = proxyConfig.getStatus();

    console.log('');
    if (status.active) printSuccess(`代理已启用: ${status.url}`);
    else printInfo('代理当前未启用');
    if (status.compatibilityWarning) printInfo(`兼容性提示: ${status.compatibilityWarning}`);
    printInfo(`配置文件: ${proxyFile}`);
    console.log('');

    const { proxyAction } = await inquirer.prompt([{
      type: 'list',
      name: 'proxyAction',
      message: '代理设置:',
      choices: [
        { name: '自动检测 Clash', value: 'detect' },
        { name: '手动配置 HTTP 代理', value: 'http' },
        { name: '管理 VPN/Clash 订阅链接', value: 'subscription' },
        { name: '关闭代理', value: 'off' },
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (proxyAction === 'back') return;
    if (proxyAction === 'off') {
      proxyConfig.disableProxy();
      printSuccess('代理已关闭');
      return;
    }
    if (proxyAction === 'subscription') {
      const list = proxyConfig.listSubscriptions();
      const { subAction } = await inquirer.prompt([{
        type: 'list',
        name: 'subAction',
        message: '订阅管理:',
        choices: [
          { name: '新增订阅链接', value: 'add' },
          { name: '刷新激活订阅（仅检测）', value: 'refresh' },
          { name: '应用激活订阅到本地代理', value: 'apply' },
          { name: '切换激活订阅', value: 'use' },
          { name: '删除订阅', value: 'remove' },
          { name: '↩️  返回', value: 'back' },
        ],
      }]);
      if (subAction === 'back') return;

      if (subAction === 'add') {
        const answer = await inquirer.prompt([
          {
            type: 'input',
            name: 'url',
            message: '订阅 URL:',
            validate: (v) => {
              const text = String(v || '').trim();
              if (/^https?:\/\//i.test(text)) return true;
              if (/^clash:\/\//i.test(text)) return true;
              if (/^sub:\/\//i.test(text)) return true;
              return '请输入 http(s) / clash:// / sub:// 链接';
            },
          },
          {
            type: 'input',
            name: 'name',
            message: '名称（可选）:',
            default: '',
          },
        ]);
        const result = proxyConfig.addSubscription(answer.url, answer.name);
        if (!result.success) printError(result.error || '添加订阅失败');
        else printSuccess(`已添加订阅: ${result.subscription.name}`);
        return;
      }

      if (subAction === 'refresh') {
        const result = await proxyConfig.refreshSubscription('', { timeout: 12000, apply: false });
        if (!result.success) printError(`刷新失败: ${result.error}`);
        else printSuccess(`刷新成功: ${result.subscription.name}`);
        return;
      }

      if (subAction === 'apply') {
        const result = await proxyConfig.applySubscription('', { timeout: 12000 });
        if (!result.success) printError(`应用失败: ${result.error}`);
        else if (result.proxy?.url) printSuccess(`已应用代理: ${result.proxy.url}`);
        else printInfo('订阅刷新成功，但未识别到可应用端口');
        return;
      }

      if (subAction === 'use') {
        if (!list.length) {
          printInfo('暂无订阅，请先新增');
          return;
        }
        const answer = await inquirer.prompt([{
          type: 'list',
          name: 'id',
          message: '选择激活订阅:',
          choices: list.map(item => ({ name: `${item.name} (${item.id})`, value: item.id })),
        }]);
        const result = proxyConfig.setActiveSubscription(answer.id);
        if (!result.success) printError(result.error || '切换失败');
        else printSuccess(`已切换激活订阅: ${result.active.name}`);
        return;
      }

      if (subAction === 'remove') {
        if (!list.length) {
          printInfo('暂无订阅可删除');
          return;
        }
        const answer = await inquirer.prompt([{
          type: 'list',
          name: 'id',
          message: '选择删除订阅:',
          choices: list.map(item => ({ name: `${item.name} (${item.id})`, value: item.id })),
        }]);
        const result = proxyConfig.removeSubscription(answer.id);
        if (!result.success) printError(result.error || '删除失败');
        else printSuccess(`已删除订阅: ${result.removed.name}`);
        return;
      }
      return;
    }
    if (proxyAction === 'detect') {
      printInfo('正在检测 Clash...');
      const r = await proxyConfig.autoDetectAndEnable();
      r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
      return;
    }

    if (proxyAction === 'socks5') {
      printError('当前网关请求隧道仅支持 HTTP CONNECT。请改用 Clash mixed-port/http-port（例如 127.0.0.1:7890）。');
      return;
    }

    const { port } = await inquirer.prompt([{
      type: 'input',
      name: 'port',
      message: `端口 (默认 ${proxyAction === 'http' ? '7890' : '1080'}):`,
      default: proxyAction === 'http' ? '7890' : '1080',
      validate: v => /^\d+$/.test(String(v || '').trim()) ? true : '请输入端口数字',
    }]);
    const r = await proxyConfig.enableProxy({ type: proxyAction, host: '127.0.0.1', port });
    r.success ? printSuccess(`代理已启用: ${r.proxy.url}`) : printError(r.error);
    return;
  }

  if (action === 'cli-toggle') {
    const current = process.env.GATEWAY_CLI_ENABLED !== 'false';
    const { enabled } = await inquirer.prompt([{
      type: 'confirm',
      name: 'enabled',
      message: `CLI 工具桥接当前${current ? '已开启' : '已关闭'}，是否开启?`,
      default: true,
    }]);
    setEnvVar('GATEWAY_CLI_ENABLED', enabled);
    printSuccess(`CLI 工具桥接已${enabled ? '开启' : '关闭'}`);
  }

  if (action === 'ollama-config') {
    const ollamaAdapter = require('../../services/gateway/adapters/ollamaAdapter');
    const available = ollamaAdapter.detect(true); // force refresh
    const models = ollamaAdapter.getModels();

    if (!available) {
      printError('Ollama 服务未运行');
      printInfo('安装: https://ollama.com');
      printInfo('启动: ollama serve');
      printInfo('拉取模型: ollama pull qwen2.5:7b');
      return;
    }

    printSuccess(`Ollama 运行中，${models.length} 个模型可用`);

    if (models.length > 0) {
      const { model } = await inquirer.prompt([{
        type: 'list',
        name: 'model',
        message: '选择默认模型:',
        choices: models.map(m => ({ name: m, value: m })),
        default: process.env.OLLAMA_MODEL || 'qwen2.5:7b',
      }]);
      setEnvVar('OLLAMA_MODEL', model);
      printSuccess(`默认模型已设为 ${model}`);
    }

    const { host } = await inquirer.prompt([{
      type: 'input',
      name: 'host',
      message: 'Ollama 地址:',
      default: process.env.OLLAMA_HOST || OLLAMA_HOST_DEFAULT,
    }]);
    if (host !== OLLAMA_HOST_DEFAULT) {
      setEnvVar('OLLAMA_HOST', host);
      printSuccess(`Ollama 地址已设为 ${host}`);
    }
    return;
  }

  if (action === 'relay-api') {
    const chalk = require('chalk').default || require('chalk');
    const currentEndpoint = process.env.RELAY_API_ENDPOINT || '';
    const currentKey = process.env.RELAY_API_KEY || '';
    const currentModel = process.env.RELAY_API_MODEL || 'claude-sonnet-4-20250514';
    const currentProvider = process.env.RELAY_API_PROVIDER || 'openai-compatible';

    if (currentEndpoint) {
      console.log(chalk.dim(`  当前: ${currentEndpoint} / ${currentModel}`));
    }

    console.log('');
    printInfo('填写以下 4 项即可完成配置 (示例仅供参考，请填写你自己的):');
    console.log(chalk.dim('  1. API Provider  — 接口协议类型 (如 OpenAI Compatible)'));
    console.log(chalk.dim('  2. Base URL      — 你的中转站地址 (如 https://your-relay.com/v1)'));
    console.log(chalk.dim('  3. API Key       — 你的密钥 (如 sk-xxxxx)'));
    console.log(chalk.dim('  4. Model ID      — 你要使用的模型 (如 gpt-4o, claude-3.5-sonnet)'));
    console.log('');

    const { provider } = await inquirer.prompt([{
      type: 'list',
      name: 'provider',
      message: 'API Provider (接口协议):',
      default: currentProvider,
      choices: [
        { name: 'OpenAI Compatible (大多数中转站/OneAPI/API2D)', value: 'openai-compatible' },
        { name: 'Anthropic (Claude 原生 API)', value: 'anthropic' },
        { name: 'Azure OpenAI', value: 'azure' },
        { name: 'Custom (自定义)', value: 'custom' },
      ],
    }]);

    const defaultEndpoints = {
      'openai-compatible': 'https://your-relay.com/v1',
      'anthropic': 'https://api.anthropic.com/v1',
      'azure': 'https://your-resource.openai.azure.com/openai/deployments/your-deployment',
      'custom': 'https://your-api.com/v1',
    };

    const endpointPlaceholder = currentEndpoint || defaultEndpoints[provider] || '';
    const { endpoint } = await inquirer.prompt([{
      type: 'input',
      name: 'endpoint',
      message: `Base URL${currentEndpoint ? '' : ` (示例: ${chalk.dim(endpointPlaceholder)})`}:`,
      default: currentEndpoint || undefined,
      validate: v => {
        if (!v || !v.trim()) return '请输入你的 API 地址';
        if (!v.startsWith('http')) return '请输入完整 URL (https://...)';
        return true;
      },
    }]);

    const { key } = await inquirer.prompt([{
      type: 'password',
      name: 'key',
      message: `API Key${currentKey ? '' : ' (你的密钥)'}:`,
      mask: '*',
      default: currentKey || undefined,
      validate: v => v && v.length > 0 ? true : '请输入你的 API Key',
    }]);

    const { model } = await inquirer.prompt([{
      type: 'input',
      name: 'model',
      message: `Model ID${currentModel && currentModel !== 'claude-sonnet-4-20250514' ? '' : ' (示例: gpt-4o, claude-3.5-sonnet, deepseek-chat)'}:`,
      default: currentModel && currentModel !== 'claude-sonnet-4-20250514' ? currentModel : undefined,
      validate: v => v && v.trim() ? true : '请输入模型名称',
    }]);

    setEnvVar('RELAY_API_ENDPOINT', endpoint);
    setEnvVar('RELAY_API_KEY', key);
    setEnvVar('RELAY_API_MODEL', model);
    setEnvVar('RELAY_API_PROVIDER', provider);

    printSuccess(`API 中转已配置: ${endpoint}`);
    printInfo(`Provider: ${provider}, 模型: ${model}`);

    // Test connection
    const { test } = await inquirer.prompt([{
      type: 'confirm',
      name: 'test',
      message: '是否测试连接?',
      default: true,
    }]);

    if (test) {
      printInfo('测试中...');
      try {
        const relayAdapter = require('../../services/gateway/adapters/relayApiAdapter');
        relayAdapter.detect(true);
        const result = await relayAdapter.generate('Say "hello" in one word.', { maxTokens: 10 });
        if (result.success) {
          printSuccess(`连接成功! 响应: "${result.content.slice(0, 50)}" (${result.provider})`);
        } else {
          printError(`连接失败: ${result.error}`);
        }
      } catch (e) {
        printError(`测试错误: ${e.message}`);
      }
    }
    return;
  }

  if (action === 'provider-keys') {
    const pool = require('../../services/apiKeyPool');
    pool.init();

    const PROVIDERS = [
      { name: 'DeepSeek', poolKey: 'deepseek', envKey: 'DEEPSEEK_API_KEY', envEndpoint: 'DEEPSEEK_API_ENDPOINT', defaultEndpoint: 'https://api.deepseek.com/v1', models: ['deepseek-chat', 'deepseek-coder', 'deepseek-reasoner'] },
      { name: '通义千问 (Qwen)', poolKey: 'qwen', envKey: 'QWEN_API_KEY', envEndpoint: 'QWEN_API_ENDPOINT', defaultEndpoint: 'https://dashscope.aliyuncs.com/compatible-mode/v1', models: ['qwen-turbo', 'qwen-plus', 'qwen-max'] },
      { name: '智谱 GLM', poolKey: 'glm', envKey: 'GLM_API_KEY', envEndpoint: 'GLM_API_ENDPOINT', defaultEndpoint: 'https://open.bigmodel.cn/api/paas/v4', models: ['glm-4', 'glm-4-flash', 'glm-4-air'] },
      { name: '豆包 (Doubao)', poolKey: 'doubao', envKey: 'DOUBAO_API_KEY', envEndpoint: 'DOUBAO_API_ENDPOINT', defaultEndpoint: 'https://ark.cn-beijing.volces.com/api/v3', models: ['doubao-pro-32k', 'doubao-lite-32k'] },
      { name: '百度文心', poolKey: 'wenxin', envKey: 'WENXIN_API_KEY', envEndpoint: 'WENXIN_API_ENDPOINT', defaultEndpoint: 'https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop', models: ['ernie-4.0', 'ernie-speed'] },
      { name: 'OpenAI', poolKey: 'openai', envKey: 'OPENAI_API_KEY', envEndpoint: 'OPENAI_API_ENDPOINT', defaultEndpoint: 'https://api.openai.com/v1', models: ['gpt-4o', 'gpt-4o-mini', 'o1-mini'] },
      { name: 'Anthropic (Claude)', poolKey: 'anthropic', envKey: 'ANTHROPIC_API_KEY', envEndpoint: 'ANTHROPIC_API_ENDPOINT', defaultEndpoint: 'https://api.anthropic.com/v1', models: ['claude-sonnet-4-20250514', 'claude-3-5-haiku-20241022'] },
      { name: 'Trae API', poolKey: 'trae', envKey: 'TRAE_API_KEY', envEndpoint: 'TRAE_API_ENDPOINT', defaultEndpoint: 'https://api.trae.ai/v1', models: ['gpt-4o', 'claude-3.5-sonnet', 'deepseek-v3', 'doubao-1.5-pro'] },
      { name: 'HuggingFace', poolKey: null, envKey: 'HF_TOKEN', envEndpoint: null, defaultEndpoint: null, models: [], isToken: true },
      { name: 'Relay (中转站)', poolKey: 'relay', envKey: 'RELAY_API_KEY', envEndpoint: 'RELAY_API_ENDPOINT', defaultEndpoint: '', models: [] },
    ];

    // Show current pool status
    console.log('');
    console.log(chalk.cyan.bold('  API Key 池管理'));
    console.log('');
    for (const p of PROVIDERS) {
      if (p.poolKey) {
        const status = pool.getPoolStatus(p.poolKey);
        if (status.length > 0) {
          console.log(`  ${chalk.white(p.name)} ${chalk.dim(`(${status.length} keys)`)}`);
          for (const s of status) {
            const icon = s.status === 'active' ? chalk.green('●')
              : s.status === 'cooldown' ? chalk.yellow('○')
              : chalk.red('○');
            const cooldown = s.cooldownRemaining > 0 ? chalk.yellow(` ⏳${s.cooldownRemaining}s`) : '';
            console.log(`    ${icon} ${chalk.dim(s.keyPreview)}  ${s.label || ''}  P:${s.priority}  ${chalk.dim(`${s.totalRequests} req`)}${cooldown}`);
          }
        } else {
          const hasEnv = !!process.env[p.envKey];
          const icon = hasEnv ? chalk.green('●') : chalk.dim('○');
          console.log(`  ${icon} ${chalk.white(p.name)}${hasEnv ? chalk.dim(` (env)`) : ''}`);
        }
      } else {
        const hasKey = !!process.env[p.envKey];
        const icon = hasKey ? chalk.green('●') : chalk.dim('○');
        console.log(`  ${icon} ${chalk.white(p.name)}${hasKey ? chalk.dim(` (${process.env[p.envKey].slice(0, 6)}...)`) : ''}`);
      }
    }
    console.log('');

    const { providerAction } = await inquirer.prompt([{
      type: 'list',
      name: 'providerAction',
      message: '操作:',
      choices: [
        { name: '添加 API Key', value: 'add' },
        { name: '移除 API Key', value: 'remove' },
        { name: '查看 Key 池详情', value: 'status' },
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (providerAction === 'back') return;

    if (providerAction === 'add') {
      const { provider } = await inquirer.prompt([{
        type: 'list',
        name: 'provider',
        message: '选择厂商:',
        choices: [
          ...PROVIDERS.map(p => ({ name: p.name, value: p })),
          { name: '↩️  返回', value: null },
        ],
      }]);

      if (!provider) return;

      const { key: keyInput } = await inquirer.prompt([{
        type: 'password',
        name: 'key',
        message: `${provider.name} API Key (支持单个/逗号分隔/JSON):`,
        mask: '*',
        validate: v => v.length > 0 ? true : '请输入 API Key',
      }]);

      // HuggingFace: token only, save to env
      if (provider.isToken) {
        const hfPrimary = extractPrimaryApiKey(keyInput);
        if (!hfPrimary) {
          printError('未解析到有效 Token');
          return;
        }
        setEnvVar(provider.envKey, hfPrimary);
        printSuccess(`${provider.name} Token 已保存`);
        return;
      }

      // Endpoint
      let keyEndpoint = provider.defaultEndpoint;
      const { useDefault } = await inquirer.prompt([{
        type: 'confirm',
        name: 'useDefault',
        message: `使用默认地址 (${provider.defaultEndpoint || '无'})？`,
        default: true,
      }]);
      if (!useDefault) {
        const { ep } = await inquirer.prompt([{
          type: 'input',
          name: 'ep',
          message: 'API 地址:',
          default: provider.defaultEndpoint,
        }]);
        keyEndpoint = ep;
      }

      // Priority
      const { priority } = await inquirer.prompt([{
        type: 'input',
        name: 'priority',
        message: '优先级 (数字越大越优先, 0=默认):',
        default: '10',
        validate: v => /^\d+$/.test(v) ? true : '请输入数字',
      }]);

      // Label
      const { label } = await inquirer.prompt([{
        type: 'input',
        name: 'label',
        message: '标签 (可选, 如 "付费号"):',
        default: '',
      }]);

      const parsedEntries = parseApiKeyEntries(keyInput, {
        endpoint: keyEndpoint,
        priority: parseInt(priority, 10),
        label,
      });
      if (parsedEntries.length === 0) {
        printError('未解析到有效 API Key');
        return;
      }
      const primaryKey = parsedEntries[0].key;

      if (provider.poolKey) {
        let addedCount = 0;
        let duplicateCount = 0;
        for (const entry of parsedEntries) {
          try {
            pool.addKey(provider.poolKey, entry);
            addedCount += 1;
          } catch (e) {
            if (/already exists/i.test(String(e && e.message ? e.message : ''))) {
              duplicateCount += 1;
            } else {
              printError(e.message);
            }
          }
        }
        if (addedCount > 0) {
          printSuccess(`已添加到 ${provider.name} Key 池 (${addedCount} 个)`);
        }
        if (duplicateCount > 0) {
          printInfo(`跳过重复 Key: ${duplicateCount} 个`);
        }
      }

      // Also set as RELAY_API for gateway compatibility (first key)
      setEnvVar(provider.envKey, primaryKey);
      if (provider.envEndpoint && keyEndpoint) {
        setEnvVar(provider.envEndpoint, keyEndpoint);
      }
      if (/_API_KEY$/i.test(provider.envKey)) {
        const prefix = provider.envKey.replace(/_API_KEY$/i, '');
        if (parsedEntries.length > 1) {
          setEnvVar(`${prefix}_API_KEYS`, parsedEntries.map(e => e.key).join(','));
        } else {
          unsetEnvVar(`${prefix}_API_KEYS`);
        }
      }

      // Model selection for non-relay providers
      if (provider.models.length > 0) {
        const { model } = await inquirer.prompt([{
          type: 'list',
          name: 'model',
          message: '选择默认模型:',
          choices: provider.models,
        }]);
        setEnvVar('RELAY_API_ENDPOINT', keyEndpoint);
        setEnvVar('RELAY_API_KEY', primaryKey);
        setEnvVar('RELAY_API_MODEL', model);
        printSuccess(`${provider.name} 已配置: ${model}`);
      }
    }

    if (providerAction === 'remove') {
      const allStatus = pool.getAllStatus();
      const removeChoices = [];
      for (const [prov, keys] of Object.entries(allStatus)) {
        for (const k of keys) {
          removeChoices.push({
            name: `${prov} · ${k.keyPreview} · ${k.label || '无标签'} · P:${k.priority}`,
            value: { provider: prov, keyId: k.keyId },
          });
        }
      }
      if (removeChoices.length === 0) {
        printInfo('Key 池为空');
        return;
      }
      const { toRemove } = await inquirer.prompt([{
        type: 'list',
        name: 'toRemove',
        message: '选择要移除的 Key:',
        choices: [...removeChoices, { name: '↩️  返回', value: null }],
      }]);
      if (toRemove) {
        pool.removeKey(toRemove.provider, toRemove.keyId);
        printSuccess('已移除');
      }
    }

    if (providerAction === 'status') {
      const allStatus = pool.getAllStatus();
      if (Object.keys(allStatus).length === 0) {
        printInfo('Key 池为空。使用「添加 API Key」开始配置');
        return;
      }
      console.log('');
      for (const [prov, keys] of Object.entries(allStatus)) {
        console.log(chalk.cyan(`  ${prov} (${keys.length} keys)`));
        for (const k of keys) {
          const icon = k.status === 'active' ? chalk.green('●')
            : k.status === 'cooldown' ? chalk.yellow('○')
            : chalk.red('○');
          const cooldown = k.cooldownRemaining > 0 ? chalk.yellow(` ⏳ ${k.cooldownRemaining}s`) : '';
          const error = k.lastError ? chalk.red(` · ${k.lastError.slice(0, 40)}`) : '';
          console.log(`    ${icon} ${chalk.dim(k.keyPreview)}  ${k.label || ''}  P:${k.priority}  ${chalk.dim(`✓ ${k.totalRequests} req · ✗ ${k.totalFailures} fail`)}${cooldown}${error}`);
        }
        console.log('');
      }
    }
    return;
  }

  if (action === 'routing-policy') {
    const routeMap = _parseJsonObject(process.env.GATEWAY_MODEL_ROUTE_MAP, {});
    const routeEntries = Object.entries(routeMap);
    const strictDefault = String(process.env.GATEWAY_MODEL_ROUTE_STRICT || 'false').toLowerCase() === 'true';

    console.log('');
    console.log(chalk.cyan.bold('  模型路由策略'));
    console.log(chalk.dim(`  strict 默认值: ${strictDefault ? 'true' : 'false'}`));
    if (routeEntries.length === 0) {
      console.log(chalk.dim('  当前无路由规则'));
    } else {
      for (const [pattern, target] of routeEntries) {
        if (target && typeof target === 'object') {
          console.log(`  ${chalk.green(pattern)} -> ${chalk.white(target.target || '')} ${chalk.dim(`(strict=${target.strict === true ? 'true' : 'false'})`)}`);
        } else {
          console.log(`  ${chalk.green(pattern)} -> ${chalk.white(String(target || ''))}`);
        }
      }
    }
    console.log('');

    const { policyAction } = await inquirer.prompt([{
      type: 'list',
      name: 'policyAction',
      message: '操作:',
      choices: [
        { name: '新增/更新规则', value: 'set' },
        { name: '移除规则', value: 'remove' },
        { name: '清空所有规则', value: 'clear' },
        { name: '设置 strict 默认值', value: 'strict' },
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (policyAction === 'back') return;
    if (policyAction === 'set') {
      const { pattern, target, strictMode } = await inquirer.prompt([
        {
          type: 'input',
          name: 'pattern',
          message: '匹配规则 (例: gpt-4o-mini 或 claude-*):',
          validate: v => String(v || '').trim() ? true : '请输入匹配规则',
        },
        {
          type: 'input',
          name: 'target',
          message: '目标路由 (例: api/openai:gpt-4o-mini 或 kiro/claude-sonnet-4):',
          validate: v => String(v || '').trim() ? true : '请输入目标路由',
        },
        {
          type: 'list',
          name: 'strictMode',
          message: 'strict 行为:',
          choices: [
            { name: '继承默认值', value: 'inherit' },
            { name: '强制 strict=true', value: 'true' },
            { name: '强制 strict=false', value: 'false' },
          ],
          default: 'inherit',
        },
      ]);
      if (strictMode === 'inherit') {
        routeMap[String(pattern).trim()] = String(target).trim();
      } else {
        routeMap[String(pattern).trim()] = {
          target: String(target).trim(),
          strict: strictMode === 'true',
        };
      }
      setEnvVar('GATEWAY_MODEL_ROUTE_MAP', _safeJsonLine(routeMap));
      printSuccess('模型路由规则已更新');
      return;
    }

    if (policyAction === 'remove') {
      const keys = Object.keys(routeMap);
      if (keys.length === 0) {
        printInfo('当前无规则可移除');
        return;
      }
      const { toRemove } = await inquirer.prompt([{
        type: 'list',
        name: 'toRemove',
        message: '选择要移除的规则:',
        choices: [...keys.map(k => ({ name: k, value: k })), { name: '↩️  返回', value: null }],
      }]);
      if (!toRemove) return;
      delete routeMap[toRemove];
      if (Object.keys(routeMap).length === 0) {
        unsetEnvVar('GATEWAY_MODEL_ROUTE_MAP');
      } else {
        setEnvVar('GATEWAY_MODEL_ROUTE_MAP', _safeJsonLine(routeMap));
      }
      printSuccess(`已移除规则: ${toRemove}`);
      return;
    }

    if (policyAction === 'clear') {
      const { confirmClear } = await inquirer.prompt([{
        type: 'confirm',
        name: 'confirmClear',
        message: '确认清空全部模型路由规则?',
        default: false,
      }]);
      if (!confirmClear) return;
      unsetEnvVar('GATEWAY_MODEL_ROUTE_MAP');
      printSuccess('已清空模型路由规则');
      return;
    }

    if (policyAction === 'strict') {
      const { strictOn } = await inquirer.prompt([{
        type: 'confirm',
        name: 'strictOn',
        message: '当规则未显式指定 strict 时，是否默认 strict=true?',
        default: strictDefault,
      }]);
      setEnvVar('GATEWAY_MODEL_ROUTE_STRICT', strictOn ? 'true' : 'false');
      printSuccess(`已设置 GATEWAY_MODEL_ROUTE_STRICT=${strictOn ? 'true' : 'false'}`);
      return;
    }
  }

  if (action === 'key-strategy') {
    const currentStrategy = String(process.env.GATEWAY_KEY_SELECTION_STRATEGY || 'round-robin').trim().toLowerCase();
    const currentStrategyMap = _parseJsonObject(process.env.GATEWAY_KEY_SELECTION_STRATEGY_MAP, {});

    const { strategy } = await inquirer.prompt([{
      type: 'list',
      name: 'strategy',
      message: '全局 Key 选择策略:',
      choices: KEY_SELECTION_STRATEGY_CHOICES,
      default: KEY_SELECTION_STRATEGY_CHOICES.some(c => c.value === currentStrategy) ? currentStrategy : 'round-robin',
    }]);
    setEnvVar('GATEWAY_KEY_SELECTION_STRATEGY', strategy);

    let nextMap = { ...currentStrategyMap };
    while (true) {
      const providerCount = Object.keys(nextMap).length;
      const { op } = await inquirer.prompt([{
        type: 'list',
        name: 'op',
        message: `Provider 覆盖策略 (${providerCount} 条):`,
        choices: [
          { name: '新增/更新覆盖', value: 'set' },
          { name: '移除覆盖', value: 'remove' },
          { name: '清空覆盖', value: 'clear' },
          { name: '完成', value: 'done' },
        ],
      }]);

      if (op === 'done') break;
      if (op === 'clear') {
        nextMap = {};
        continue;
      }
      if (op === 'remove') {
        const keys = Object.keys(nextMap);
        if (keys.length === 0) {
          printInfo('当前无覆盖项可移除');
          continue;
        }
        const { key } = await inquirer.prompt([{
          type: 'list',
          name: 'key',
          message: '选择要移除的 provider:',
          choices: [...keys.map(k => ({ name: `${k} => ${nextMap[k]}`, value: k })), { name: '↩️  返回', value: null }],
        }]);
        if (!key) continue;
        delete nextMap[key];
        continue;
      }

      if (op === 'set') {
        const { providerChoice } = await inquirer.prompt([{
          type: 'list',
          name: 'providerChoice',
          message: '选择 provider:',
          choices: [
            ...API_POOL_PROVIDER_KEYS.map(k => ({ name: k, value: k })),
            { name: '自定义 provider', value: '__custom__' },
            { name: '↩️  返回', value: null },
          ],
        }]);
        if (!providerChoice) continue;
        let providerKey = providerChoice;
        if (providerChoice === '__custom__') {
          const { customProvider } = await inquirer.prompt([{
            type: 'input',
            name: 'customProvider',
            message: '输入 provider 名称:',
            validate: v => String(v || '').trim() ? true : '请输入 provider',
          }]);
          providerKey = String(customProvider).trim().toLowerCase();
        }
        const { providerStrategy } = await inquirer.prompt([{
          type: 'list',
          name: 'providerStrategy',
          message: `${providerKey} 的策略:`,
          choices: KEY_SELECTION_STRATEGY_CHOICES,
          default: KEY_SELECTION_STRATEGY_CHOICES.some(c => c.value === String(nextMap[providerKey] || strategy))
            ? String(nextMap[providerKey] || strategy)
            : 'round-robin',
        }]);
        nextMap[providerKey] = providerStrategy;
      }
    }

    if (Object.keys(nextMap).length === 0) {
      unsetEnvVar('GATEWAY_KEY_SELECTION_STRATEGY_MAP');
    } else {
      setEnvVar('GATEWAY_KEY_SELECTION_STRATEGY_MAP', _safeJsonLine(nextMap));
    }
    printSuccess(`Key 选择策略已更新: ${strategy}`);
    if (Object.keys(nextMap).length > 0) {
      printInfo(`Provider 覆盖: ${_safeJsonLine(nextMap)}`);
    } else {
      printInfo('Provider 覆盖: 无');
    }
    return;
  }

  if (action === 'api-pool-default') {
    const current = String(process.env.GATEWAY_API_POOL_PROVIDER || '').trim().toLowerCase();
    const { provider } = await inquirer.prompt([{
      type: 'list',
      name: 'provider',
      message: 'API 适配器默认池 provider（未指定 model/provider 时生效）:',
      choices: [
        { name: '自动推断（默认）', value: '' },
        ...API_POOL_PROVIDER_KEYS.map(k => ({ name: k, value: k })),
      ],
      default: (current && API_POOL_PROVIDER_KEYS.includes(current)) ? current : '',
    }]);

    if (!provider) {
      unsetEnvVar('GATEWAY_API_POOL_PROVIDER');
      printSuccess('已恢复自动推断 provider');
    } else {
      setEnvVar('GATEWAY_API_POOL_PROVIDER', provider);
      printSuccess(`默认 provider 已设为 ${provider}`);
    }
    return;
  }

  if (action === 'api-provider-map') {
    const MAP_PRESETS = [
      {
        envKey: 'GATEWAY_API_POOL_PROVIDER_ALIAS_MAP',
        title: 'Alias 映射',
        keyHint: '别名',
        valueHint: '池 provider（如 deepseek/qwen/glm/openai）',
      },
      {
        envKey: 'GATEWAY_API_POOL_SERVICE_MAP',
        title: '池 -> 服务映射',
        keyHint: '池 provider',
        valueHint: '服务 provider（MultiFreeService key，如 openai/alibaba/zhipu/baidu）',
      },
      {
        envKey: 'GATEWAY_API_POOL_DEFAULT_MODEL_MAP',
        title: '池默认模型映射',
        keyHint: '池 provider',
        valueHint: '默认模型（如 deepseek-chat / qwen-plus）',
      },
    ];

    const { preset } = await inquirer.prompt([{
      type: 'list',
      name: 'preset',
      message: '选择映射类型:',
      choices: [
        ...MAP_PRESETS.map(p => ({ name: `${p.title} (${p.envKey})`, value: p })),
        { name: '↩️  返回', value: null },
      ],
    }]);
    if (!preset) return;

    const nextMap = _parseJsonObject(process.env[preset.envKey], {});
    while (true) {
      const rows = Object.entries(nextMap);
      console.log('');
      console.log(chalk.cyan.bold(`  ${preset.title}`));
      if (rows.length === 0) {
        console.log(chalk.dim('  当前为空'));
      } else {
        for (const [k, v] of rows) {
          console.log(`  ${chalk.green(k)} => ${chalk.white(String(v))}`);
        }
      }
      console.log('');

      const { op } = await inquirer.prompt([{
        type: 'list',
        name: 'op',
        message: '操作:',
        choices: [
          { name: '新增/更新', value: 'set' },
          { name: '移除', value: 'remove' },
          { name: '清空', value: 'clear' },
          { name: '完成', value: 'done' },
        ],
      }]);

      if (op === 'done') break;
      if (op === 'clear') {
        Object.keys(nextMap).forEach(k => { delete nextMap[k]; });
        continue;
      }
      if (op === 'remove') {
        const keys = Object.keys(nextMap);
        if (keys.length === 0) {
          printInfo('当前无可移除项');
          continue;
        }
        const { key } = await inquirer.prompt([{
          type: 'list',
          name: 'key',
          message: '选择要移除的键:',
          choices: [...keys.map(k => ({ name: k, value: k })), { name: '↩️  返回', value: null }],
        }]);
        if (!key) continue;
        delete nextMap[key];
        continue;
      }
      if (op === 'set') {
        const { mapKey, mapValue } = await inquirer.prompt([
          {
            type: 'input',
            name: 'mapKey',
            message: `${preset.keyHint}:`,
            validate: v => String(v || '').trim() ? true : '请输入 key',
          },
          {
            type: 'input',
            name: 'mapValue',
            message: `${preset.valueHint}:`,
            validate: v => String(v || '').trim() ? true : '请输入 value',
          },
        ]);
        nextMap[String(mapKey).trim().toLowerCase()] = String(mapValue).trim();
      }
    }

    if (Object.keys(nextMap).length === 0) {
      unsetEnvVar(preset.envKey);
      printSuccess(`已清空 ${preset.envKey}`);
    } else {
      setEnvVar(preset.envKey, _safeJsonLine(nextMap));
      printSuccess(`已更新 ${preset.envKey}`);
      printInfo(_safeJsonLine(nextMap));
    }
    return;
  }

  if (action === 'relay-port') {
    const { port } = await inquirer.prompt([{
      type: 'input',
      name: 'port',
      message: '中转服务端口:',
      default: process.env.GATEWAY_RELAY_PORT || '9099',
      validate: v => /^\d+$/.test(v) ? true : '请输入数字',
    }]);
    setEnvVar('GATEWAY_RELAY_PORT', port);
    printSuccess(`中转端口已设为 ${port}`);
    printInfo('重启中转服务后生效');
  }

  if (action === 'relay-timeout') {
    const { minutes } = await inquirer.prompt([{
      type: 'input',
      name: 'minutes',
      message: '中转超时 (分钟):',
      default: String(Math.round((parseInt(process.env.GATEWAY_RELAY_TIMEOUT, 10) || 600000) / 60000)),
      validate: v => /^\d+$/.test(v) ? true : '请输入数字',
    }]);
    setEnvVar('GATEWAY_RELAY_TIMEOUT', parseInt(minutes, 10) * 60000);
    printSuccess(`中转超时已设为 ${minutes} 分钟`);
  }
  } finally {
    if (!hadGuard) global.__KHY_INQUIRER_ACTIVE__ = false;
    // Ensure stdin is resumed after inquirer sessions
    try { process.stdin.resume(); } catch { /* ignore */ }
  }
}

/**
 * Select AI model from available adapters (with connectivity indicators).
 */
async function handleGatewaySelectModel(args = [], options = {}) {
  try {
    const gateway = require('../../services/gateway/aiGateway');
    const autoSync = await maybeAutoSyncSwitchCenterForGateway('gateway-model');
    if (!gateway._initialized) await gateway.init();
    if (autoSync && autoSync.synced && (autoSync.changed || autoSync.activeChanged)) {
      try { await gateway.refreshAdapters(); } catch { /* best effort */ }
      printInfo(`已自动同步 switch-center: ${(autoSync.profileName || autoSync.profileId || 'windsurf-auto')} (${autoSync.modelsCount || 0} models)`);
    }

  const statuses = gateway.getStatus();
  const enabledAdapters = statuses.filter(s => s.enabled);
  const verboseAdapterDetails = String(process.env.KHY_MODEL_VERBOSE_ADAPTER_DETAILS || 'false').toLowerCase() === 'true';

  if (enabledAdapters.length === 0) {
    printError('无已启用 AI 通道');
    return;
  }

  if (verboseAdapterDetails) {
    const windsurfStatus = statuses.find(s => String(s.type || '').toLowerCase() === 'windsurf');
    if (windsurfStatus && windsurfStatus.tokenPath) {
      printInfo(`Windsurf token 位置: ${windsurfStatus.tokenPath}`);
      const official = windsurfStatus.officialModels || null;
      if (official) {
        if (official.hit) {
          const endpointLabel = official.endpoint ? ` (${official.endpoint})` : '';
          printInfo(`Windsurf 官方模型列表: 已命中${endpointLabel} · 官方 ${official.officialCount} / 本地 ${official.localCount} / 合并 ${official.mergedCount}`);
        } else {
          const reason = String(official.error || '').trim();
          printInfo(`Windsurf 官方模型列表: 未命中${reason ? ` (${reason})` : '（已回退本地发现）'}`);
        }
      }
    }
  }

  const preferredIssueBeforeProbe = _resolvePreferredAdapterIssue(statuses, {});
  if (preferredIssueBeforeProbe && preferredIssueBeforeProbe.type === 'invalid') {
    printError(preferredIssueBeforeProbe.message);
    printInfo('当前将忽略该无效配置，并仅展示可执行通道');
  }

  // Fast probe for model-selection UX.
  // For unstable-prone adapters, include a lightweight generation probe
  // to avoid "detected but unusable" false positives in /model.
  const probeTimeoutMs = Math.max(
    4000,
    parseInt(process.env.KHY_MODEL_PROBE_TIMEOUT_MS || '8000', 10) || 8000,
  );
  const generationProbeTimeoutMs = Math.max(
    probeTimeoutMs,
    parseInt(process.env.KHY_MODEL_PROBE_GENERATION_TIMEOUT_MS || '25000', 10) || 25000,
  );
  const strictOperationalAdapters = STRICT_OPERATIONAL_ADAPTERS;
  const twoPhaseProbeEnabled = String(process.env.KHY_MODEL_TWO_PHASE_PROBE || 'true').toLowerCase() !== 'false';
  printInfo(`检测各通道连通性（快速模式，单通道超时 ${Math.round(probeTimeoutMs / 1000)}s）...`);
  const testResults = {};
  const strictCandidates = [];
  const testPromises = enabledAdapters.map(async (s) => {
    const adapterType = String(s.type || '').toLowerCase();
    const requireGenerationProbe = strictOperationalAdapters.has(adapterType);
    const adapterProbeTimeoutMs = _getAdapterProbeTimeoutMs(adapterType, probeTimeoutMs);
    const adapterGenerationProbeTimeoutMs = Math.max(adapterProbeTimeoutMs, generationProbeTimeoutMs);
    if (requireGenerationProbe) strictCandidates.push(s);
    try {
      testResults[s.type] = await withTimeout(
        gateway.testAdapter(s.type, {
          quick: !requireGenerationProbe,
          timeoutMs: adapterProbeTimeoutMs,
          probeGenerationTimeoutMs: adapterGenerationProbeTimeoutMs,
        }),
        Math.max(adapterProbeTimeoutMs + 1000, adapterGenerationProbeTimeoutMs + 1000),
        `${s.type} probe`,
      );
    } catch (err) {
      testResults[s.type] = {
        connectivity: {
          success: false,
          latencyMs: adapterProbeTimeoutMs,
          error: err && err.message ? err.message : 'probe failed',
        },
      };
    }
  });
  await Promise.all(testPromises);
  const preferredIssueAfterProbe = _resolvePreferredAdapterIssue(enabledAdapters, testResults);

  let debounceRetried = 0;
  let debounceRecovered = 0;
  if (MODEL_PROBE_DEBOUNCE_ENABLED) {
    const retryCandidates = enabledAdapters.filter((s) => {
      const firstTest = testResults[s.type];
      if (isAdapterOperational(s, firstTest, strictOperationalAdapters)) return false;
      return _shouldRetryProbeByDebounce(s, firstTest);
    });
    if (retryCandidates.length > 0) {
      debounceRetried = retryCandidates.length;
      await Promise.all(retryCandidates.map(async (s) => {
        const adapterType = String(s.type || '').toLowerCase();
        const requireGenerationProbe = strictOperationalAdapters.has(adapterType);
        const adapterProbeTimeoutMs = _getAdapterProbeTimeoutMs(adapterType, probeTimeoutMs);
        const adapterGenerationProbeTimeoutMs = Math.max(adapterProbeTimeoutMs, generationProbeTimeoutMs);
        for (let attempt = 1; attempt <= MODEL_PROBE_DEBOUNCE_MAX_RETRIES; attempt++) {
          if (MODEL_PROBE_DEBOUNCE_DELAY_MS > 0) {
            const waitMs = MODEL_PROBE_DEBOUNCE_DELAY_MS * attempt;
            await new Promise((resolve) => setTimeout(resolve, waitMs));
          }
          try {
            const retried = await withTimeout(
              gateway.testAdapter(s.type, {
                quick: !requireGenerationProbe,
                timeoutMs: adapterProbeTimeoutMs,
                probeGenerationTimeoutMs: adapterGenerationProbeTimeoutMs,
              }),
              Math.max(adapterProbeTimeoutMs + 1000, adapterGenerationProbeTimeoutMs + 1000),
              `${s.type} debounce-probe`,
            );
            testResults[s.type] = retried;
            if (isAdapterOperational(s, retried, strictOperationalAdapters)) {
              debounceRecovered += 1;
              break;
            }
            if (!_shouldRetryProbeByDebounce(s, retried)) break;
          } catch (err) {
            testResults[s.type] = {
              connectivity: {
                success: false,
                latencyMs: adapterProbeTimeoutMs,
                error: err && err.message ? err.message : 'debounce probe failed',
              },
            };
          }
        }
      }));
    }
  }

  let backgroundDeepProbeStarted = 0;
  if (twoPhaseProbeEnabled && strictCandidates.length > 0) {
    for (const s of strictCandidates) {
      const adapterType = String(s.type || '').toLowerCase();
      const currentGeneration = testResults[s.type]?.generation || null;
      if (currentGeneration?.success) continue;
      if (currentGeneration && !_isTransientProbeLikeReason(String(currentGeneration.error || ''))) continue;
      const cached = _getDeepProbeCache(adapterType);
      if (cached && cached.test && cached.test.generation) {
        const cachedGeneration = cached.test.generation;
        // Prefer fresh live probe result; only use cache when it can improve confidence.
        if (!currentGeneration || (cachedGeneration?.success && !currentGeneration.success)) {
          testResults[s.type] = {
            ...(testResults[s.type] || {}),
            generation: cachedGeneration,
          };
        }
        continue;
      }
      if (_modelDeepProbeInFlight.has(adapterType)) continue;
      backgroundDeepProbeStarted += 1;
      const deepTask = (async () => {
        try {
          const adapterProbeTimeoutMs = _getAdapterProbeTimeoutMs(s.type, probeTimeoutMs);
          const adapterGenerationProbeTimeoutMs = Math.max(adapterProbeTimeoutMs, generationProbeTimeoutMs);
          const deep = await withTimeout(
            gateway.testAdapter(s.type, {
              quick: false,
              timeoutMs: adapterProbeTimeoutMs,
              probeGenerationTimeoutMs: adapterGenerationProbeTimeoutMs,
            }),
            Math.max(adapterProbeTimeoutMs + 3000, adapterGenerationProbeTimeoutMs + 3000),
            `${s.type} deep-probe`,
          );
          _setDeepProbeCache(adapterType, deep);
        } catch (err) {
          _setDeepProbeCache(adapterType, {
            connectivity: { success: false, error: err && err.message ? err.message : 'deep probe failed' },
            generation: { success: false, error: err && err.message ? err.message : 'deep probe failed' },
          });
        } finally {
          _modelDeepProbeInFlight.delete(adapterType);
        }
      })();
      _modelDeepProbeInFlight.set(adapterType, deepTask);
      deepTask.catch(() => {});
    }
  }

// Collect models from all available adapters with indicators
  const modelChoices = [];
  let skippedUnavailableAdapters = 0;
  const hiddenAdapters = [];
  let generationWarnCount = 0;
  let filteredModelCount = 0;
  const filteredModelReasonCount = {};
  for (const s of enabledAdapters) {
    const test = testResults[s.type];
    const adapterOk = isAdapterOperational(s, test);
    if (!adapterOk) {
      skippedUnavailableAdapters += 1;
      hiddenAdapters.push({
        name: s.name || s.type,
        type: s.type,
        reason: _classifyHiddenReason(s, test),
      });
      continue;
    }
    const generationWarn = !!(test?.generation && !test.generation.success && shouldTreatGenerationFailureAsWarning(s.type));
    if (generationWarn) generationWarnCount += 1;
    const indicator = generationWarn
      ? chalk.yellow(`● ${test.generation.error || '实测告警'}`)
      : chalk.green(`● ${test.connectivity.latencyMs}ms`);
    const statusTag = generationWarn ? chalk.yellow('[可用-告警]') : chalk.green('[可用]');

    try {
      const modelListTimeoutMs = _getAdapterModelListTimeoutMs(s.type, Math.max(3000, probeTimeoutMs));
      const models = await withTimeout(
        gateway.listModels(s.type),
        modelListTimeoutMs,
        `${s.type} listModels`,
      );
      if (models && models.length > 0) {
        const reliabilityFiltered = _filterModelsByReliability(s, test, models);
        if (reliabilityFiltered.filtered > 0) {
          filteredModelCount += reliabilityFiltered.filtered;
          for (const reason of reliabilityFiltered.reasons) {
            filteredModelReasonCount[reason] = (filteredModelReasonCount[reason] || 0) + 1;
          }
        }
        for (const m of reliabilityFiltered.models) {
          const sourceTag = _formatModelSourceTag(m);
          const connTag = _formatConnectionTag(m);
          const upstreamTag = _formatUpstreamTag(m);
          const adapterTag = chalk.dim(`(执行:${s.name}/${s.type})`);
          modelChoices.push({
            name: `${statusTag} ${m.name || m.id}${sourceTag ? ` ${sourceTag}` : ''}${upstreamTag ? ` ${upstreamTag}` : ''}${connTag ? ` ${connTag}` : ''} ${adapterTag} ${indicator}${m.isDefault ? chalk.green(' ✓ 当前') : ''}`,
            value: { adapter: s.type, model: m.id },
            disabled: false,
          });
        }
      } else {
        // Adapter available but no model list (e.g. relay)
        modelChoices.push({
          name: `${statusTag} ${s.name} ${chalk.dim('(默认模型)')} ${indicator}`,
          value: { adapter: s.type, model: null },
          disabled: false,
        });
      }
    } catch (err) {
      const reasonText = err && err.message ? err.message : 'listModels failed';
      if (String(s.type || '').toLowerCase() === 'kiro' && _isTimeoutLikeReason(reasonText)) {
        // Keep Kiro selectable when model listing is slow; selection still works
        // and runtime can refresh models in background.
        modelChoices.push({
          name: `${statusTag} ${s.name} ${chalk.dim('(模型列表超时，使用默认模型)')} ${indicator}`,
          value: { adapter: s.type, model: null },
          disabled: false,
        });
        hiddenAdapters.push({
          name: s.name || s.type,
          type: s.type,
          reason: `模型列表超时，已保留默认模型入口: ${_compactReasonText(reasonText)}`,
        });
        continue;
      }
      skippedUnavailableAdapters += 1;
      hiddenAdapters.push({
        name: s.name || s.type,
        type: s.type,
        reason: _classifyHiddenReason(s, test, reasonText),
      });
    }
  }

  if (modelChoices.length === 0) {
    printInfo('当前无可执行模型可选（已过滤未通过实测的通道）');
    if (preferredIssueAfterProbe && preferredIssueAfterProbe.type === 'unavailable') {
      printInfo(preferredIssueAfterProbe.message);
      printInfo('可先运行 khy gateway status 查看失败细节，再切换到可执行通道');
    }
    return;
  }

  if (skippedUnavailableAdapters > 0) {
    printInfo(`已隐藏 ${skippedUnavailableAdapters} 个未通过实测的通道（可用 khy gateway status 查看详情）`);
    const shown = [];
    const seen = new Set();
    for (const item of hiddenAdapters) {
      const key = `${String(item.type || '').toLowerCase()}|${String(item.reason || '').toLowerCase()}`;
      if (seen.has(key)) continue;
      seen.add(key);
      shown.push(item);
      if (shown.length >= 3) break;
    }
    for (const item of shown) {
      printInfo(`  - ${item.name} (${item.type}): ${item.reason}`);
    }
    if (hiddenAdapters.length > shown.length) {
      printInfo(`  - 其余 ${hiddenAdapters.length - shown.length} 个通道请用 khy gateway status 查看完整原因`);
    }
  }
  if (preferredIssueAfterProbe && preferredIssueAfterProbe.type === 'unavailable') {
    printInfo(preferredIssueAfterProbe.message);
  }
  if (generationWarnCount > 0) {
    printInfo(`探测告警 ${generationWarnCount} 项：为快速健康探测结果，不等同于运行时必然失败`);
  }
  if (filteredModelCount > 0) {
    const reasonLabels = {
      hint: '提示源模型',
      builtin: '内置回退模型',
      'warn-unverified': '告警通道的未验证模型',
      'cross-provider-claude': '跨提供商 Claude 模型',
    };
    const reasonSummary = Object.keys(filteredModelReasonCount)
      .map((key) => `${reasonLabels[key] || key}×${filteredModelReasonCount[key]}`)
      .join('，');
    printInfo(`已过滤 ${filteredModelCount} 个低置信模型（${reasonSummary || '默认可靠性策略'}）`);
  }
  if (debounceRetried > 0) {
    printInfo(`防抖复检: 已复检 ${debounceRetried} 个抖动通道，恢复 ${debounceRecovered} 个`);
  }
  if (twoPhaseProbeEnabled && backgroundDeepProbeStarted > 0) {
    printInfo(`已启动 ${backgroundDeepProbeStarted} 个后台深测任务（strict 通道），下次 /model 会显示更准确告警`);
  }

  const isInteractive = !!(process.stdin && process.stdin.isTTY && process.stdout && process.stdout.isTTY);
  const requestedAdapter = (args[0] || options.adapter || '').toLowerCase();
  const requestedModel = options.model || args[1] || '';

  // Non-interactive mode: auto-pick a model without prompting.
  if (!isInteractive) {
    let pick = null;
    if (requestedAdapter || requestedModel) {
      pick = modelChoices.find(c => {
        if (!c || !c.value || c.disabled) return false;
        const adapterOk = !requestedAdapter || c.value.adapter === requestedAdapter;
        const modelOk = !requestedModel || c.value.model === requestedModel;
        return adapterOk && modelOk;
      }) || null;
    }
    if (!pick) {
      pick = modelChoices.find(c => c && c.value && !c.disabled) || null;
    }
    if (!pick) {
      printError('无可用模型可选择');
      return;
    }
    const selected = pick.value;
    persistGatewayPreference(selected);
    try { gateway.syncModelSwitch(selected.model || null); } catch { /* best effort */ }
    try {
      await gateway.refreshAdapters();
    } catch { /* best effort */ }
    printSuccess(`已选择: ${selected.model || '默认模型'} (${selected.adapter})`);
    const tokenInfo = getTokenInfoForSelection(selected);
    printInfo(`可用性: ${pick.disabled ? '不可用' : '可用'}`);
    printInfo(`Token: ${tokenInfo.source} → ${tokenInfo.detail}`);
    return;
  }

  let selected = null;
  let picked = null;
  try {
    const inquirer = require('inquirer');
    const preferredAdapter = String(process.env.GATEWAY_PREFERRED_ADAPTER || '').trim().toLowerCase();
    const preferredModel = String(process.env.GATEWAY_PREFERRED_MODEL || '').trim();
    const defaultChoice = modelChoices.find((c) => {
      if (!c || !c.value || c.disabled) return false;
      if (!preferredAdapter) return false;
      if (c.value.adapter !== preferredAdapter) return false;
      return preferredModel ? String(c.value.model || '') === preferredModel : true;
    });

    const { selectedValue } = await promptWithReplGuard([{
      type: 'list',
      name: 'selectedValue',
      message: '选择模型（上下方向键选择，回车确认）:',
      choices: [
        ...modelChoices.map(c => ({
          name: c.name,
          value: c.value,
          disabled: c.disabled ? '不可选' : false,
        })),
        new inquirer.Separator(),
        { name: '返回', value: null },
      ],
      pageSize: Math.min(16, Math.max(8, modelChoices.length + 2)),
      default: defaultChoice ? defaultChoice.value : undefined,
      loop: false,
    }]);
    if (!selectedValue) return;
    selected = selectedValue;
    picked = modelChoices.find((c) => (
      c && c.value
      && c.value.adapter === selected.adapter
      && String(c.value.model || '') === String(selected.model || '')
    )) || null;
  } catch {
    // Fallback: numeric selection for environments where inquirer is unavailable.
    console.log('');
    for (let i = 0; i < modelChoices.length; i++) {
      const c = modelChoices[i];
      const unavailable = c.disabled ? chalk.dim(' (不可选)') : '';
      console.log(`  ${chalk.white(`${i + 1}.`)} ${c.name}${unavailable}`);
    }
    console.log(`  ${chalk.dim('0. 返回')}`);
    console.log('');

    const answer = await askLine(chalk.dim('  输入编号: '));
    const idx = Number.parseInt(String(answer || '').trim(), 10);
    if (!Number.isFinite(idx) || idx === 0) return;
    if (idx < 1 || idx > modelChoices.length) {
      printError('编号超出范围');
      return;
    }
    picked = modelChoices[idx - 1];
    if (!picked || picked.disabled) {
      printError('该模型当前不可选，请选择可用模型');
      return;
    }
    selected = picked.value;
  }

  // Save selection to .env
  persistGatewayPreference(selected);
  try { gateway.syncModelSwitch(selected.model || null); } catch { /* best effort */ }
  try {
    await gateway.refreshAdapters();
  } catch { /* best effort */ }

  printSuccess(`已选择: ${selected.model || '默认模型'} (${selected.adapter})`);
  const selectedChoice = modelChoices.find((c) => {
    if (!c || !c.value) return false;
    return c.value.adapter === selected.adapter
      && String(c.value.model || '') === String(selected.model || '');
  });
  printInfo(`可用性: ${selectedChoice && selectedChoice.disabled ? '不可用' : '可用'}`);
  const tokenInfo = getTokenInfoForSelection(selected);
  printInfo(`Token: ${tokenInfo.source} → ${tokenInfo.detail}`);
  console.log('');
  } finally {
    recoverGatewayPromptInput();
  }
}

/**
 * Explicitly start the web relay server.
 */
async function handleGatewayRelay() {
  const { requireLogin } = require('../../services/authGuard');
  const auth = requireLogin('gateway relay');
  if (!auth.ok) {
    printError(auth.error);
    return;
  }

  const gateway = require('../../services/gateway/aiGateway');
  const relay = gateway.getRelayAdapter();

  if (relay.isRunning()) {
    printInfo(`中转服务已在运行: http://localhost:${relay.getPort()}`);
    return;
  }

  const port = await relay.start();
  console.log('');
  printSuccess(`AI 中转服务已启动`);
  console.log('');
  console.log(chalk.bold(`  🌐 打开浏览器访问: ${chalk.cyan(`http://localhost:${port}`)}`));
  console.log('');
  console.log(chalk.dim('  使用方式:'));
  console.log(chalk.dim('    1. 终端发送 AI 请求后，提示会出现在网页上'));
  console.log(chalk.dim('    2. 点击「一键复制」将提示复制到剪贴板'));
  console.log(chalk.dim('    3. 粘贴到任意 AI 网页（ChatGPT、Claude、Gemini 等）'));
  console.log(chalk.dim('    4. 复制 AI 回复，粘贴到网页文本框，点击「提交」'));
  console.log(chalk.dim('    5. 回复将自动返回到终端'));
  console.log('');
}

/**
 * Detect IDE installations and allow manual path configuration.
 */
async function handleGatewayDetect() {
  const hadGuard = global.__KHY_INQUIRER_ACTIVE__ === true;
  global.__KHY_INQUIRER_ACTIVE__ = true;
  try {
  const { detectAll, setCustomPath, findInstallation, findDataPath } = require('../../services/gateway/adapters/ideDetector');

  const results = detectAll();

  console.log('');
  console.log(`  ${chalk.cyan.bold('IDE 安装检测')}`);
  console.log('');

  printTable(
    ['IDE', '安装路径', '数据路径', '状态'],
    results.map(r => [
      r.name.charAt(0).toUpperCase() + r.name.slice(1),
      r.installPath || chalk.dim('未找到'),
      r.dataPath ? chalk.dim('✓') : chalk.dim('—'),
      r.available ? chalk.green('✓ 已检测') : chalk.yellow('⚠ 未检测到'),
    ])
  );
  console.log('');

  // Offer to set custom paths for missing IDEs
  const missing = results.filter(r => !r.available);
  if (missing.length > 0) {
    printInfo('未检测到的 IDE 可手动设置安装路径');
    const inquirer = require('inquirer');

    const { action } = await inquirer.prompt([{
      type: 'list',
      name: 'action',
      message: '操作:',
      choices: [
        ...missing.map(r => ({
          name: `设置 ${r.name} 安装路径`,
          value: r.name,
        })),
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (action !== 'back') {
      const { customPath } = await inquirer.prompt([{
        type: 'input',
        name: 'customPath',
        message: `输入 ${action} 安装路径:`,
        validate: (v) => {
          if (!v.trim()) return '路径不能为空';
          return true;
        },
      }]);

      const envKey = `${action.toUpperCase()}_INSTALL_PATH`;
      _writeEnvMap({ [envKey]: customPath.trim() });
      setCustomPath(action, customPath.trim());

      printSuccess(`${action} 安装路径已设为: ${customPath.trim()}`);
    }
  }
  } finally {
    if (!hadGuard) global.__KHY_INQUIRER_ACTIVE__ = false;
    try { process.stdin.resume(); } catch { /* ignore */ }
  }
}

/**
 * Two-step connectivity test for all or specific adapters.
 * Pattern inspired by cc-haha ProviderTestResult (connectivity + models).
 */
async function handleGatewayTest(targetAdapter) {
  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus();
  const toTest = targetAdapter
    ? statuses.filter(s => s.type === targetAdapter || s.name.toLowerCase().includes(targetAdapter.toLowerCase()))
    : statuses.filter(s => s.enabled);

  if (toTest.length === 0) {
    printError(targetAdapter ? `未找到适配器: ${targetAdapter}` : '无已启用的适配器');
    return;
  }

  console.log('');
  console.log(`  ${chalk.cyan.bold('AI 通道连通测试')}`);
  console.log('');

  for (const s of toTest) {
    console.log(`  ${chalk.bold(s.name)} ${chalk.dim(`(${s.type})`)}`);

    if (!s.available) {
      console.log(`    ${chalk.dim('① 检测')}  ${chalk.red('● 不可用')} ${chalk.dim(s.detail || '')}`);
      console.log('');
      continue;
    }

    const probeGenerationTimeoutMs = Math.max(
      1000,
      parseInt(process.env.GATEWAY_LOCAL_LLM_PROBE_TIMEOUT_MS || '30000', 10) || 30000
    );
    const result = await gateway.testAdapter(s.type, {
      probeGenerationTimeoutMs: s.type === 'localLLM' ? probeGenerationTimeoutMs : undefined,
    });

    // Step 1: Connectivity
    if (result.connectivity?.success) {
      console.log(`    ${chalk.dim('① 连接')}  ${chalk.green('● 已连接')} ${chalk.dim(`(${result.connectivity.latencyMs}ms)`)}`);
    } else {
      console.log(`    ${chalk.dim('① 连接')}  ${chalk.red('● 失败:')} ${chalk.red(result.connectivity?.error || 'unknown')}`);
      console.log('');
      continue;
    }

    // Step 2: Models (if tested)
    if (result.models) {
      if (result.models.success) {
        const modelNames = result.models.list?.slice(0, 3).map(m => m.name || m.id).join(', ') || '';
        const more = result.models.count > 3 ? ` +${result.models.count - 3}` : '';
        console.log(`    ${chalk.dim('② 模型')}  ${chalk.green('● 可用')} ${chalk.dim(`(${result.models.latencyMs}ms · ${result.models.count} models)`)}${modelNames ? chalk.dim(` ${modelNames}${more}`) : ''}`);
      } else {
        console.log(`    ${chalk.dim('② 模型')}  ${chalk.red('● 失败:')} ${chalk.red(result.models.error || 'unknown')} ${chalk.dim(`(${result.models.latencyMs}ms)`)}`);
      }
    }

    if (result.generation) {
      if (result.generation.success) {
        console.log(`    ${chalk.dim('③ 实测')}  ${chalk.green('● 可用')} ${chalk.dim(`(${result.generation.latencyMs}ms)`)}`);
      } else {
        console.log(`    ${chalk.dim('③ 实测')}  ${chalk.red('● 失败:')} ${chalk.red(result.generation.error || 'unknown')} ${chalk.dim(`(${result.generation.latencyMs}ms)`)}`);
      }
    }

    console.log('');
  }
}

function _parsePort(value, fallback) {
  const n = parseInt(String(value ?? '').trim(), 10);
  if (!Number.isFinite(n) || n <= 0 || n > 65535) return fallback;
  return n;
}

function _parseIntWithMin(value, fallback, min = 1) {
  const n = parseInt(String(value ?? '').trim(), 10);
  if (!Number.isFinite(n) || n < min) return fallback;
  return n;
}

function _isPidAlive(pid) {
  const p = parseInt(pid, 10);
  if (!Number.isFinite(p) || p <= 0) return false;
  try {
    process.kill(p, 0);
    return true;
  } catch {
    return false;
  }
}

function _loadAiManageRuntime() {
  const files = [AI_MANAGE_RUNTIME_FILE, AI_MANAGE_RUNTIME_FILE_LEGACY];
  for (const file of files) {
    try {
      if (!fs.existsSync(file)) continue;
      const raw = JSON.parse(fs.readFileSync(file, 'utf-8'));
      if (!raw || typeof raw !== 'object') continue;
      return raw;
    } catch {
      // try next
    }
  }
  return null;
}

function _clearAiManageRuntime() {
  for (const file of [AI_MANAGE_RUNTIME_FILE, AI_MANAGE_RUNTIME_FILE_LEGACY]) {
    try {
      if (fs.existsSync(file)) fs.unlinkSync(file);
    } catch {
      // best effort
    }
  }
}

function _resolveAiFrontendDir(options = {}) {
  const candidates = [];
  const explicit = String(
    options['frontend-dir']
    || options.frontendDir
    || process.env.AI_FRONTEND_DIR
    || process.env.KHY_AI_FRONTEND_DIR
    || ''
  ).trim();
  if (explicit) {
    candidates.push(path.resolve(explicit));
  }
  if (process.env.KHYQUANT_ROOT) {
    candidates.push(path.resolve(process.env.KHYQUANT_ROOT, 'ai-frontend'));
    candidates.push(path.resolve(process.env.KHYQUANT_ROOT, '..', 'ai-frontend'));
    candidates.push(path.resolve(process.env.KHYQUANT_ROOT, '..', '..', 'ai-frontend'));
  }
  candidates.push(path.resolve(process.cwd(), 'ai-frontend'));

  for (const dir of candidates) {
    try {
      if (fs.existsSync(path.join(dir, 'package.json'))) return dir;
    } catch {
      // try next
    }
  }
  return null;
}

function _resolveAiFrontendDistDir(options = {}, frontendDir = null) {
  const candidates = [];
  const seen = new Set();
  const push = (value) => {
    const text = String(value || '').trim();
    if (!text) return;
    const resolved = path.resolve(text);
    if (seen.has(resolved)) return;
    seen.add(resolved);
    candidates.push(resolved);
  };

  push(
    options['frontend-dist-dir']
    || options.frontendDistDir
    || process.env.AI_FRONTEND_DIST_DIR
    || process.env.KHY_AI_FRONTEND_DIST_DIR
    || ''
  );

  if (frontendDir) {
    push(path.join(frontendDir, 'dist'));
    push(path.join(frontendDir, 'build'));
  }

  if (process.env.KHYQUANT_ROOT) {
    const root = path.resolve(process.env.KHYQUANT_ROOT);
    const parent = path.resolve(root, '..');
    const grandParent = path.resolve(root, '..', '..');
    const roots = [root, parent, grandParent];
    for (const base of roots) {
      push(path.join(base, 'ai-frontend', 'dist'));
      push(path.join(base, 'frontend', 'dist'));
    }
  }

  push(path.resolve(process.cwd(), 'ai-frontend', 'dist'));
  push(path.resolve(process.cwd(), 'frontend', 'dist'));

  for (const dir of candidates) {
    try {
      if (fs.existsSync(path.join(dir, 'index.html'))) return dir;
    } catch {
      // try next
    }
  }
  return null;
}

function _sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function _requestAiManageControl(runtime, method = 'GET', endpoint = '/status', body = null, timeoutMs = 2500) {
  return new Promise((resolve, reject) => {
    if (!runtime || !runtime.controlPort || !runtime.controlToken) {
      reject(new Error('runtime control 信息缺失'));
      return;
    }

    const queryJoiner = endpoint.includes('?') ? '&' : '?';
    const endpointWithToken = `${endpoint}${queryJoiner}token=${encodeURIComponent(runtime.controlToken)}`;
    const payload = body ? JSON.stringify(body) : null;
    const req = http.request({
      host: '127.0.0.1',
      port: runtime.controlPort,
      path: endpointWithToken,
      method,
      timeout: timeoutMs,
      headers: {
        'X-Khy-Token': runtime.controlToken,
        ...(payload ? {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload),
        } : {}),
      },
    }, (res) => {
      let raw = '';
      res.on('data', chunk => { raw += chunk.toString(); });
      res.on('end', () => {
        let parsed = {};
        try { parsed = raw ? JSON.parse(raw) : {}; } catch { parsed = {}; }
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(parsed);
        } else {
          reject(new Error(parsed.error || `HTTP ${res.statusCode}`));
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('control request timeout')));
    if (payload) req.write(payload);
    req.end();
  });
}

async function _syncManageAuthBootstrapFromCli(runtime, options = {}) {
  const cliAuth = require('../../services/cliAuthService');
  const session = (typeof cliAuth.checkSession === 'function')
    ? (cliAuth.checkSession() || { loggedIn: false })
    : { loggedIn: false };
  const token = (typeof cliAuth.getSessionAuthToken === 'function')
    ? String(cliAuth.getSessionAuthToken() || '').trim()
    : '';
  const username = String(session.username || '').trim();
  const ttlMs = _parseIntWithMin(
    options['auth-ttl-ms'] ?? options.authTtlMs ?? process.env.AI_MANAGE_AUTH_BOOTSTRAP_TTL_MS,
    30 * 60 * 1000,
    30_000
  );
  const enabled = !!token;

  try {
    await _requestAiManageControl(runtime, 'POST', '/auth/bootstrap', {
      enabled,
      token,
      username,
      ttlMs,
    }, 3000);
    return {
      ok: true,
      enabled,
      username,
      loggedIn: !!session.loggedIn,
      hasServerToken: !!token,
    };
  } catch (err) {
    return {
      ok: false,
      enabled: false,
      username,
      loggedIn: !!session.loggedIn,
      hasServerToken: !!token,
      error: err && err.message ? err.message : String(err || ''),
    };
  }
}

async function _waitAiManageRuntimeReady(timeoutMs = 15000) {
  const started = Date.now();
  while ((Date.now() - started) < timeoutMs) {
    const runtime = _loadAiManageRuntime();
    if (runtime?.pid && _isPidAlive(runtime.pid) && runtime.controlPort && runtime.controlToken) {
      try {
        // eslint-disable-next-line no-await-in-loop
        const status = await _requestAiManageControl(runtime, 'GET', '/status');
        if (status?.ok) return { runtime, status };
      } catch {
        // still starting
      }
    }
    // eslint-disable-next-line no-await-in-loop
    await _sleep(250);
  }
  return null;
}

function _openUrlInBrowser(url) {
  const { openDefault } = require('../../tools/platformUtils');
  try {
    openDefault(url);
    return true;
  } catch {
    return false;
  }
}

function _buildManageOpenUrl(runtime) {
  const base = String(runtime?.frontendUrl || `http://127.0.0.1:${runtime?.frontendPort || 8090}`).trim();
  if (!base) return '';
  if (!runtime?.controlPort || !runtime?.controlToken) return base;
  const ctl = `http://127.0.0.1:${runtime.controlPort}`;
  const joiner = base.includes('?') ? '&' : '?';
  return `${base}${joiner}khy_manage_ctl=${encodeURIComponent(ctl)}&khy_manage_token=${encodeURIComponent(runtime.controlToken)}`;
}

function _truthyFlag(value) {
  if (value === true) return true;
  const raw = String(value || '').trim().toLowerCase();
  return raw === '1' || raw === 'true' || raw === 'yes' || raw === 'on';
}

function _normalizePath(pathname = '/admin/ai-gateway') {
  const raw = String(pathname || '').trim();
  if (!raw) return '/admin/ai-gateway';
  return raw.startsWith('/') ? raw : `/${raw}`;
}

function _toValidPort(raw) {
  const n = parseInt(String(raw ?? '').trim(), 10);
  if (!Number.isFinite(n) || n <= 0 || n > 65535) return 0;
  return n;
}

function _appendPath(baseUrl, pathname = '/admin/ai-gateway') {
  const pathValue = _normalizePath(pathname);
  try {
    const parsed = new URL(String(baseUrl || '').trim());
    parsed.pathname = pathValue;
    parsed.search = '';
    parsed.hash = '';
    return parsed.toString().replace(/\/$/, '');
  } catch {
    return '';
  }
}

function _buildMainAdminUrlCandidates(options = {}) {
  const candidates = [];
  const seen = new Set();
  const push = (url) => {
    const text = String(url || '').trim();
    if (!text || seen.has(text)) return;
    seen.add(text);
    candidates.push(text);
  };

  const adminPath = _normalizePath(
    options['admin-path']
    || process.env.KHY_ADMIN_PATH
    || '/admin/ai-gateway'
  );

  const explicitFull = String(
    options['admin-url']
    || process.env.KHY_ADMIN_URL
    || ''
  ).trim();
  if (explicitFull) {
    if (/^https?:\/\//i.test(explicitFull)) {
      push(_appendPath(explicitFull, adminPath));
    } else {
      push(_appendPath(`http://${explicitFull}`, adminPath));
    }
  }

  const explicitBase = String(
    options['web-url']
    || options['web-base']
    || process.env.KHY_WEB_URL
    || process.env.KHY_WEB_BASE_URL
    || ''
  ).trim();
  if (explicitBase) {
    if (/^https?:\/\//i.test(explicitBase)) {
      push(_appendPath(explicitBase, adminPath));
    } else {
      push(_appendPath(`http://${explicitBase}`, adminPath));
    }
  }

  const host = String(options['web-host'] || process.env.KHY_WEB_HOST || '127.0.0.1').trim() || '127.0.0.1';
  const portCandidates = [];
  const portValues = [
    options['web-port'],
    options.port,
    process.env.KHY_WEB_PORT,
    process.env.FRONTEND_PORT,
    process.env.VITE_PORT,
    process.env.PORT,
    // Common local dev/prod ports; values can still be overridden by env/flags.
    5173,
    3000,
  ];
  for (const value of portValues) {
    const p = _toValidPort(value);
    if (!p) continue;
    if (!portCandidates.includes(p)) portCandidates.push(p);
  }

  for (const port of portCandidates) {
    push(`http://${host}:${port}${adminPath}`);
    if (host === '127.0.0.1') push(`http://localhost:${port}${adminPath}`);
  }
  return candidates;
}

function _probeUrlReachable(url, timeoutMs = 1200) {
  return new Promise((resolve) => {
    let parsed = null;
    try {
      parsed = new URL(String(url || '').trim());
    } catch {
      resolve({ ok: false, statusCode: 0 });
      return;
    }
    const transport = parsed.protocol === 'https:' ? require('https') : require('http');
    const req = transport.request({
      hostname: parsed.hostname,
      port: parsed.port || undefined,
      path: `${parsed.pathname}${parsed.search || ''}`,
      method: 'GET',
      timeout: timeoutMs,
      headers: { Accept: 'text/html,application/json;q=0.9,*/*;q=0.8' },
    }, (res) => {
      const statusCode = Number(res.statusCode || 0);
      // consume response quickly to release socket
      res.resume();
      resolve({ ok: statusCode >= 200 && statusCode < 400, statusCode });
    });
    req.on('error', () => resolve({ ok: false, statusCode: 0 }));
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.end();
  });
}

function _buildRuntimeForOpen(statusRuntime = {}, runtime = {}) {
  return {
    ...(statusRuntime || {}),
    controlPort: statusRuntime?.controlPort || runtime?.controlPort || 0,
    controlToken: runtime?.controlToken || statusRuntime?.controlToken || '',
    frontendHost: statusRuntime?.frontendHost || runtime?.frontendHost || '127.0.0.1',
    frontendPort: statusRuntime?.frontendPort || runtime?.frontendPort || 8090,
    frontendUrl: statusRuntime?.frontendUrl || runtime?.frontendUrl || '',
  };
}

async function _collectManageHealth(runtime = {}, liveStatus = null, probeTimeoutMs = 1200) {
  const statusRuntime = liveStatus?.runtime || runtime;
  const runtimeForOpen = _buildRuntimeForOpen(statusRuntime, runtime);
  const frontendAvailable = !!statusRuntime?.frontendAvailable;
  const frontendReason = String(statusRuntime?.frontendReason || runtime?.frontendReason || '').trim();
  const frontendLogFile = String(statusRuntime?.frontendLogFile || runtime?.frontendLogFile || '').trim();
  const apiDisplay = `http://127.0.0.1:${runtimeForOpen.apiPort || statusRuntime?.apiPort || runtime?.apiPort || 9090}`;
  const frontendDisplay = String(runtimeForOpen.frontendUrl || `http://${runtimeForOpen.frontendHost}:${runtimeForOpen.frontendPort}`).trim()
    || `http://${runtimeForOpen.frontendHost}:${runtimeForOpen.frontendPort}`;
  const keepaliveUrl = _buildManageOpenUrl(runtimeForOpen);
  const apiHealthUrl = `${apiDisplay}/api/health`;
  let apiReachable = false;
  let frontendReachable = false;
  try {
    const apiProbe = await _probeUrlReachable(apiHealthUrl, probeTimeoutMs);
    apiReachable = !!apiProbe.ok;
  } catch {
    apiReachable = false;
  }
  try {
    const frontendProbe = await _probeUrlReachable(frontendDisplay, probeTimeoutMs);
    frontendReachable = !!frontendProbe.ok;
  } catch {
    frontendReachable = false;
  }

  return {
    runtimeForOpen,
    statusRuntime,
    frontendAvailable,
    frontendReason,
    frontendLogFile,
    apiDisplay,
    frontendDisplay,
    keepaliveUrl,
    apiHealthUrl,
    apiReachable,
    frontendReachable,
  };
}

async function _waitManageHealthReady(runtime = {}, options = {}) {
  const timeoutMs = _parseIntWithMin(
    options.timeoutMs ?? AI_MANAGE_HEALTH_WAIT_MS,
    AI_MANAGE_HEALTH_WAIT_MS,
    1000
  );
  const requireFrontend = options.requireFrontend !== false;
  const probeTimeoutMs = _parseIntWithMin(options.probeTimeoutMs ?? 1200, 1200, 300);
  const startedAt = Date.now();
  let latestRuntime = { ...(runtime || {}) };
  let latestStatus = null;
  let lastHealth = null;

  while ((Date.now() - startedAt) < timeoutMs) {
    try {
      // eslint-disable-next-line no-await-in-loop
      latestStatus = await _requestAiManageControl(latestRuntime, 'GET', '/status', null, Math.max(2200, probeTimeoutMs + 800));
      if (latestStatus?.runtime) {
        latestRuntime = {
          ...latestRuntime,
          ...latestStatus.runtime,
          controlPort: latestRuntime.controlPort || latestStatus.runtime.controlPort || 0,
          controlToken: latestRuntime.controlToken || latestStatus.runtime.controlToken || '',
        };
      }
    } catch {
      // ignore transient control request failures and continue probing
    }

    // eslint-disable-next-line no-await-in-loop
    lastHealth = await _collectManageHealth(latestRuntime, latestStatus, probeTimeoutMs);
    const frontendReady = !requireFrontend || (lastHealth.frontendAvailable && lastHealth.frontendReachable);
    if (lastHealth.apiReachable && frontendReady) {
      return { ok: true, health: lastHealth, runtime: latestRuntime, status: latestStatus };
    }
    if (requireFrontend && String(lastHealth.frontendReason || '').trim().toLowerCase() === 'disabled') {
      return { ok: false, health: lastHealth, runtime: latestRuntime, status: latestStatus, reason: 'frontend-disabled' };
    }
    // eslint-disable-next-line no-await-in-loop
    await _sleep(AI_MANAGE_HEALTH_POLL_MS);
  }

  return { ok: false, health: lastHealth, runtime: latestRuntime, status: latestStatus, reason: 'wait-timeout' };
}

async function _openMainAdminIfAvailable(options = {}) {
  const candidates = _buildMainAdminUrlCandidates(options);
  for (const url of candidates) {
    // eslint-disable-next-line no-await-in-loop
    const probe = await _probeUrlReachable(url, 1200);
    if (!probe.ok) continue;
    const opened = _openUrlInBrowser(url);
    return { success: true, url, opened };
  }
  return { success: false, candidates };
}

async function _waitPidExit(pid, timeoutMs = 6000) {
  const started = Date.now();
  while ((Date.now() - started) < timeoutMs) {
    if (!_isPidAlive(pid)) return true;
    // eslint-disable-next-line no-await-in-loop
    await _sleep(150);
  }
  return !_isPidAlive(pid);
}

function _spawnAiManageDaemon({
  apiPort,
  frontendPort,
  idleMs,
  frontendHost,
  frontendDir,
  frontendDistDir,
  noFrontend = false,
  noAutoFrontend = false,
}) {
  if (!fs.existsSync(AI_MANAGE_DAEMON_SCRIPT)) {
    throw new Error(`未找到守护脚本: ${AI_MANAGE_DAEMON_SCRIPT}`);
  }

  const args = [
    AI_MANAGE_DAEMON_SCRIPT,
    '--api-port', String(apiPort),
    '--frontend-port', String(frontendPort),
    '--idle-ms', String(idleMs),
    '--frontend-host', String(frontendHost || '127.0.0.1'),
  ];

  if (frontendDir) {
    args.push('--frontend-dir', frontendDir);
  }
  if (frontendDistDir) {
    args.push('--frontend-dist-dir', frontendDistDir);
  }
  if (noFrontend) {
    args.push('--no-frontend');
  }
  if (noAutoFrontend) {
    args.push('--no-auto-frontend');
  }

  let fd = null;
  let stdio = 'ignore';
  try {
    const logDir = path.join(path.dirname(AI_MANAGE_RUNTIME_FILE), 'logs');
    fs.mkdirSync(logDir, { recursive: true });
    const daemonLogFile = path.join(logDir, 'ai_manage_daemon.log');
    fd = fs.openSync(daemonLogFile, 'a');
    stdio = ['ignore', fd, fd];
  } catch {
    stdio = 'ignore';
  }

  const child = spawn(process.execPath, args, {
    detached: true,
    stdio,
    env: { ...process.env },
    cwd: process.env.KHYQUANT_ROOT || path.resolve(__dirname, '../..'),
  });
  if (fd != null) {
    try { fs.closeSync(fd); } catch { /* ignore */ }
  }
  child.unref();
  return child.pid || 0;
}

async function handleGatewayManage(args = [], options = {}) {
  const action = String(args[0] || 'open').trim().toLowerCase();
  const validActions = new Set(['open', 'start', 'status', 'stop']);
  if (!validActions.has(action)) {
    printError(`未知 manage 操作: ${action}`);
    printInfo('用法: gateway manage [open|start|status|stop] [--daemon] [--frontend-port 8090] [--api-port 9090] [--idle-ms 600000] [--wait-ms 18000] [--frontend-dir <path>] [--frontend-dist-dir <path>]');
    return;
  }

  const forceDaemon = _truthyFlag(options.daemon);
  if (action === 'open' && !forceDaemon) {
    const webOpen = await _openMainAdminIfAvailable(options);
    if (webOpen.success) {
      if (webOpen.opened) {
        printSuccess(`已打开管理页面: ${webOpen.url}`);
      } else {
        printInfo(`请手动打开管理页面: ${webOpen.url}`);
      }
      printInfo('如需使用独立守护会话入口，可运行: khy gateway manage open --daemon');
      return;
    }
    const previewList = (webOpen.candidates || []).slice(0, 2);
    if (previewList.length > 0) {
      printInfo('主站管理页未就绪，已回退独立会话模式。');
      for (const url of previewList) {
        printInfo(`探测地址: ${url}`);
      }
    } else {
      printInfo('主站管理页未就绪，已回退独立会话模式。');
    }
  }

  let runtime = _loadAiManageRuntime();
  let liveStatus = null;
  if (runtime?.pid && _isPidAlive(runtime.pid)) {
    try {
      liveStatus = await _requestAiManageControl(runtime, 'GET', '/status');
      if (!liveStatus?.ok) throw new Error('status not ok');
    } catch {
      runtime = null;
      liveStatus = null;
      _clearAiManageRuntime();
    }
  } else if (runtime) {
    _clearAiManageRuntime();
    runtime = null;
  }

  if (action === 'stop') {
    if (!runtime) {
      printInfo('AI 管理会话未运行');
      return;
    }

    try {
      await _requestAiManageControl(runtime, 'POST', '/shutdown', {});
    } catch {
      // fallback to signal
      const { safeSignal: _sig } = require('../../tools/platformUtils');
      try { _sig(runtime.pid, 'SIGTERM'); } catch { /* ignore */ }
    }

    const exited = await _waitPidExit(runtime.pid, 8000);
    if (!exited) {
      const { safeSignal: _sigKill } = require('../../tools/platformUtils');
      try { _sigKill(runtime.pid, 'SIGKILL'); } catch { /* ignore */ }
      await _waitPidExit(runtime.pid, 2000);
    }
    _clearAiManageRuntime();
    printSuccess('AI 管理会话已停止，端口已释放');
    return;
  }

  if (action === 'status' && !runtime) {
    printInfo('AI 管理会话未运行');
    printInfo('启动命令: khy gateway manage');
    printInfo('主站入口: khy guanli');
    return;
  }

  if (!runtime) {
    const frontendPort = _parsePort(
      options['frontend-port'] ?? options.port ?? process.env.AI_FRONTEND_PORT ?? process.env.VITE_AI_FRONTEND_PORT,
      8090
    );
    const apiPort = _parsePort(
      options['api-port'] ?? process.env.AI_MGMT_PORT,
      9090
    );
    const idleMs = _parseIntWithMin(
      options['idle-ms'] ?? process.env.AI_MANAGE_IDLE_MS,
      10 * 60 * 1000,
      10000
    );
    const frontendHost = String(options['frontend-host'] || process.env.AI_FRONTEND_HOST || '127.0.0.1').trim() || '127.0.0.1';
    const frontendDir = _resolveAiFrontendDir(options);
    const frontendDistDir = _resolveAiFrontendDistDir(options, frontendDir);
    const noFrontend = _truthyFlag(options['no-frontend']) || _truthyFlag(options.noFrontend);
    const noAutoFrontend = _truthyFlag(options['no-auto-frontend']) || _truthyFlag(options.noAutoFrontend);

    _spawnAiManageDaemon({
      apiPort,
      frontendPort,
      idleMs,
      frontendHost,
      frontendDir,
      frontendDistDir,
      noFrontend,
      noAutoFrontend,
    });
    const ready = await _waitAiManageRuntimeReady(AI_MANAGE_READY_TIMEOUT_MS);
    if (!ready) {
      printError('AI 管理会话启动失败或超时');
      printInfo('可检查日志: ~/.khy/logs/ai_manage_daemon.log 与 ~/.khy/logs/ai_frontend_dev.log');
      return;
    }
    runtime = ready.runtime;
    liveStatus = ready.status;
  }

  if (!liveStatus) {
    try {
      liveStatus = await _requestAiManageControl(runtime, 'GET', '/status');
    } catch {
      liveStatus = null;
    }
  }

  if (action === 'open' || action === 'start') {
    const authSync = await _syncManageAuthBootstrapFromCli(runtime, options);
    if (authSync.ok && authSync.enabled) {
      printInfo(`已同步 CLI 登录态到管理页（用户: ${authSync.username || 'cli-user'}）`);
    } else if (authSync.ok && authSync.loggedIn && !authSync.hasServerToken) {
      printInfo('检测到 CLI 为本地离线登录态，管理页将进入登录页（可在页面登录）。');
      printInfo('诊断: 当前 CLI 会话缺少服务端 token，无法桥接管理页自动免登录。');
      printInfo('下一步 1/2: 在 CLI 执行 `/login`，完成服务端账号登录。');
      printInfo('下一步 2/2: 重新执行 `khyguanli` 或 `khy gateway manage open`。');
    } else if (authSync.ok && !authSync.loggedIn) {
      printInfo('CLI 当前未登录，管理页将进入登录页。可先执行 `/login`。');
    }
  }

  let health = await _collectManageHealth(runtime, liveStatus, 1200);
  if (action !== 'status') {
    const waitMs = _parseIntWithMin(
      options['wait-ms'] ?? options.waitMs ?? process.env.AI_MANAGE_HEALTH_WAIT_MS,
      AI_MANAGE_HEALTH_WAIT_MS,
      1000
    );
    const initiallyReady = health.apiReachable && health.frontendAvailable && health.frontendReachable;
    if (!initiallyReady) {
      printInfo(`正在确认管理页可达（API+前端，最长 ${Math.round(waitMs / 1000)}s）...`);
      const waited = await _waitManageHealthReady(runtime, {
        timeoutMs: waitMs,
        requireFrontend: true,
        probeTimeoutMs: 1200,
      });
      if (waited?.runtime) runtime = waited.runtime;
      if (waited?.status) liveStatus = waited.status;
      if (waited?.health) health = waited.health;
    }
  }

  const statusRuntime = health.statusRuntime || liveStatus?.runtime || runtime;
  const runtimeForOpen = health.runtimeForOpen || _buildRuntimeForOpen(statusRuntime, runtime);
  const frontendAvailable = !!health.frontendAvailable;
  const frontendReason = String(health.frontendReason || '').trim();
  const frontendLogFile = String(health.frontendLogFile || '').trim();
  const apiDisplay = String(health.apiDisplay || '').trim() || `http://127.0.0.1:${runtimeForOpen.apiPort || 9090}`;
  const frontendDisplay = String(health.frontendDisplay || '').trim() || `http://${runtimeForOpen.frontendHost}:${runtimeForOpen.frontendPort}`;
  const keepaliveUrl = String(health.keepaliveUrl || _buildManageOpenUrl(runtimeForOpen)).trim();
  const apiHealthUrl = String(health.apiHealthUrl || `${apiDisplay}/api/health`).trim();
  const apiReachable = !!health.apiReachable;
  const frontendReachable = !!health.frontendReachable;

  if (action === 'status') {
    const runningHealthy = apiReachable && frontendAvailable && frontendReachable;
    console.log('');
    console.log(`  ${chalk.cyan.bold('AI 管理会话状态')}`);
    console.log('');
    console.log(`  ${chalk.gray('运行状态:')} ${runningHealthy ? chalk.green('● 运行中') : chalk.yellow('● 运行中（服务未完全就绪）')}`);
    console.log(`  ${chalk.gray('守护进程 PID:')} ${statusRuntime.pid || runtime.pid}`);
    console.log(`  ${chalk.gray('API:')} ${apiReachable ? chalk.cyan(apiHealthUrl) : chalk.yellow(`${apiHealthUrl} (不可达)`)}`);
    if (!frontendAvailable) {
      console.log(`  ${chalk.gray('前端:')} ${chalk.yellow('未就绪')}`);
      if (frontendReason) {
        console.log(`  ${chalk.gray('前端原因:')} ${chalk.yellow(frontendReason)}`);
      }
      if (frontendLogFile) {
        console.log(`  ${chalk.gray('前端日志:')} ${chalk.dim(frontendLogFile)}`);
      }
    } else {
      console.log(`  ${chalk.gray('前端:')} ${frontendReachable ? chalk.cyan(frontendDisplay) : chalk.yellow(`${frontendDisplay} (不可达)`)}`);
    }
    console.log(`  ${chalk.gray('推荐入口:')} ${chalk.cyan('khy aiguanli  或  khy gateway manage open')}`);
    console.log(`  ${chalk.gray('保活直链:')} ${chalk.dim('已生成（复制下一行）')}`);
    console.log(`    ${chalk.dim(keepaliveUrl)}`);
    console.log(`  ${chalk.gray('自动关闭:')} ${chalk.cyan('页面关闭后空闲自动释放端口')}`);
    console.log(`  ${chalk.gray('活跃页面:')} ${String(statusRuntime.sessions || 0)}`);
    if (!runningHealthy) {
      printInfo('检测到管理会话未完全就绪。可先运行: khy gateway manage stop && khy gateway manage start --daemon');
      printInfo('若仍失败，请检查日志: ~/.khy/logs/ai_manage_daemon.log 与 ~/.khy/logs/ai_frontend_dev.log');
    }
    console.log('');
    return;
  }

  const openUrl = _buildManageOpenUrl(runtimeForOpen);
  if (action === 'start') {
    printSuccess('AI 管理会话已启动');
  } else {
    if (frontendAvailable && frontendReachable) {
      const opened = _openUrlInBrowser(openUrl);
      if (opened) {
        printSuccess(`已打开管理页面: ${frontendDisplay}`);
      } else {
        printInfo(`请手动打开管理页面: ${openUrl}`);
      }
    } else {
      printError('前端尚未就绪，未自动打开管理页面。');
      if (frontendReason) {
        printInfo(`前端原因: ${frontendReason}`);
      }
    }
  }

  console.log('');
  console.log(`  ${chalk.gray('API:')} ${apiReachable ? chalk.cyan(apiHealthUrl) : chalk.yellow(`${apiHealthUrl} (不可达)`)}`);
  if (!frontendAvailable) {
    console.log(`  ${chalk.gray('前端:')} ${chalk.yellow('未就绪')}`);
    if (frontendReason) {
      console.log(`  ${chalk.gray('前端原因:')} ${chalk.yellow(frontendReason)}`);
    }
    if (frontendLogFile) {
      console.log(`  ${chalk.gray('前端日志:')} ${chalk.dim(frontendLogFile)}`);
    }
  } else {
    console.log(`  ${chalk.gray('前端:')} ${frontendReachable ? chalk.cyan(frontendDisplay) : chalk.yellow(`${frontendDisplay} (不可达)`)}`);
  }
  console.log(`  ${chalk.gray('推荐入口:')} ${chalk.cyan('khy aiguanli  或  khy gateway manage open')}`);
  console.log(`  ${chalk.gray('保活直链:')} ${chalk.dim('已生成（复制下一行）')}`);
  console.log(`    ${chalk.dim(openUrl)}`);
  console.log(`  ${chalk.gray('状态:')} ${chalk.dim('khy gateway manage status')}`);
  console.log(`  ${chalk.gray('停止:')} ${chalk.dim('khy gateway manage stop')}`);
  console.log(`  ${chalk.gray('登录提示:')} ${chalk.dim('admin / admin123 (旧安装兼容 admin123.)')}`);
  console.log(`  ${chalk.gray('重置账号:')} ${chalk.dim('node backend/scripts/seed.js')}`);
  console.log('');

  if (!frontendAvailable || !frontendReachable || !apiReachable) {
    printInfo('管理服务未完全就绪。可先运行: khy gateway manage stop && khy gateway manage start --daemon');
    printInfo('可选：显式指定前端目录 `--frontend-dir <ai-frontend绝对路径>`，或静态目录 `--frontend-dist-dir <dist绝对路径>`。');
    printInfo('若使用源码前端开发模式，请先在 ai-frontend 目录执行 `npm install`。');
    printInfo('若仍失败，请检查日志: ~/.khy/logs/ai_manage_daemon.log 与 ~/.khy/logs/ai_frontend_dev.log');
  }
}

/**
 * Start/stop/status the AI management backend server.
 * @param {string} action - 'start' | 'stop' | 'status'
 */
async function handleAiServer(action) {
  const server = require('../../services/aiManagementServer');

  if (action === 'stop') {
    if (!server.isRunning()) {
      printInfo('AI 管理服务未运行');
      return;
    }
    await server.stop();
    printSuccess('AI 管理服务已停止');
    return;
  }

  if (action === 'status') {
    if (server.isRunning()) {
      printSuccess(`AI 管理服务运行中: http://localhost:${server.getPort()}`);
    } else {
      printInfo('AI 管理服务未运行');
    }
    return;
  }

  // Default: start
  if (server.isRunning()) {
    printInfo(`AI 管理服务已在运行: http://localhost:${server.getPort()}`);
    return;
  }

  const port = await server.start();
  console.log('');
  printSuccess('AI 管理服务已启动');
  console.log('');
  console.log(chalk.bold(`  🌐 API:       ${chalk.cyan(`http://localhost:${port}/api/health`)}`));
  console.log(chalk.bold(`  🔌 WebSocket: ${chalk.cyan(`ws://localhost:${port}/ws`)}`));
  console.log('');
  console.log(chalk.dim('  REST 端点:'));
  console.log(chalk.dim('    GET  /api/status          — 适配器状态'));
  console.log(chalk.dim('    GET  /api/models          — 模型列表 (含健康指标)'));
  console.log(chalk.dim('    POST /api/test/:adapter   — 两步连通测试'));
  console.log(chalk.dim('    GET  /api/config          — 网关配置'));
  console.log(chalk.dim('    PUT  /api/config          — 更新配置'));
  console.log(chalk.dim('    GET  /api/conversations   — 会话列表'));
  console.log(chalk.dim('    GET  /api/usage           — Token 用量'));
  console.log(chalk.dim('    GET  /api/tools           — 工具列表'));
  console.log(chalk.dim('    POST /api/tools/:name     — 执行工具'));
  console.log('');
}

/**
 * Display supported protocol conversion formats.
 */
function handleGatewayProtocols() {
  const { getSupportedProtocols, PROTOCOLS } = require('../../services/gateway/protocolConverter');

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('协议转换支持')}`);
  console.log('');

  const protocols = getSupportedProtocols();
  const rows = protocols.map(p => {
    const endpoints = {
      [PROTOCOLS.OPENAI]: '/v1/chat/completions',
      [PROTOCOLS.ANTHROPIC]: '/v1/messages',
      [PROTOCOLS.GEMINI]: '/v1beta/models/:model:generateContent',
      [PROTOCOLS.GROK]: '/v1/chat/completions (Grok)',
      [PROTOCOLS.CODEX]: '/v1/responses',
    };
    return [p, endpoints[p] || '—', chalk.green('✓ 双向')];
  });

  printTable(['协议', '端点', '转换方向'], rows);

  console.log('');
  printInfo('任意协议间可互转（通过 Canonical 中间格式）');
  printInfo('代理服务自动检测输入协议，以原协议格式返回');
  console.log('');
}

/**
 * OAuth token management.
 */
async function handleGatewayOAuth(action, provider) {
  const oauth = require('../../services/gateway/oauthManager');
  oauth.init();

  if (action === 'refresh' && provider) {
    printInfo(`正在刷新 ${provider} token...`);
    const token = await oauth.refreshToken(provider);
    if (token) {
      printSuccess(`${provider} token 已刷新`);
    } else {
      printError(`${provider} 刷新失败 — 请检查 refresh_token 配置`);
    }
    return;
  }

  // Default: status
  const allStatus = oauth.getAllStatus();
  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('OAuth Token 状态')}`);
  console.log('');

  for (const [key, status] of Object.entries(allStatus)) {
    const icon = status.valid ? chalk.green('●') : (status.registered ? chalk.yellow('●') : chalk.dim('○'));
    const expiry = status.expiresIn > 0 ? chalk.dim(`(${Math.round(status.expiresIn / 60)}min)`) : '';
    const error = status.error ? chalk.red(` · ${status.error.slice(0, 40)}`) : '';
    const refresh = status.hasRefreshToken ? chalk.dim(' [refresh]') : '';
    console.log(`  ${icon} ${chalk.white(status.provider || key)} ${status.valid ? chalk.green('有效') : (status.registered ? chalk.yellow('已过期') : chalk.dim('未配置'))} ${expiry}${refresh}${error}`);
  }

  console.log('');
  printInfo('使用 gateway oauth refresh <provider> 强制刷新');
  console.log('');
}

/**
 * Scan local IDE/config files and merge discovered model IDs into RELAY_API_MODELS.
 */
async function handleGatewayDiscoverModels() {
  const { discoverModels, updateRelayModelsInEnvFile } = require('../../services/gateway/modelDiscovery');
  const envPath = _resolveEnvPathForDiscoverModels();
  const result = discoverModels();
  const discovered = result.models || [];

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('模型自动发现')}`);
  console.log('');

  if (discovered.length === 0) {
    printInfo('未发现可用模型 ID。可手动设置 RELAY_API_MODELS。');
    console.log('');
    return;
  }

  const merged = updateRelayModelsInEnvFile(envPath, discovered);
  let mergedCount = 0;
  try { mergedCount = String(merged).split(',').filter(Boolean).length; } catch { mergedCount = 0; }

  printSuccess(`已发现 ${discovered.length} 个模型候选，并写入 RELAY_API_MODELS (${mergedCount} 个)`);

  if (result.evidence && result.evidence.length > 0) {
    printInfo('来源文件:');
    for (const e of result.evidence.slice(0, 12)) {
      const short = e.file.replace((process.env.HOME || ''), '~');
      console.log(`  ${chalk.dim('-')} ${short} ${chalk.dim(`(${e.count})`)}`);
    }
  }

  console.log('');
  printInfo('可运行 khy gateway model 重新选择模型');
  console.log('');
}

// ── Key Health Probe CLI ──

async function handleGatewayKeyHealth(args = []) {
  const probe = require('../../services/keyHealthProbe');
  const filterProvider = args[0] || null;

  console.log('');
  console.log(chalk.bold('  Key Health Probe'));
  console.log('');

  const results = await probe.probeAll();
  const filtered = filterProvider
    ? results.filter(r => r.provider === filterProvider)
    : results;

  if (filtered.length === 0) {
    printInfo(filterProvider
      ? `No keys found for provider "${filterProvider}".`
      : 'No keys configured in pool.');
    console.log('');
    return;
  }

  for (const r of filtered) {
    const status = r.healthy
      ? chalk.green('healthy')
      : chalk.red('unhealthy');
    const latency = r.latencyMs > 0 ? chalk.dim(`${r.latencyMs}ms`) : '';
    const error = r.error ? chalk.dim(`(${r.error})`) : '';
    console.log(`  ${chalk.cyan(r.provider.padEnd(12))} ${r.keyId.padEnd(14)} ${status} ${latency} ${error}`);
  }

  const healthy = filtered.filter(r => r.healthy).length;
  console.log('');
  printInfo(`${healthy}/${filtered.length} keys healthy`);
  console.log('');
}

async function handleGatewayKeyRotate(args = []) {
  const pool = require('../../services/apiKeyPool');
  const provider = args[0];

  if (!provider) {
    printError('Usage: gateway key rotate <provider>');
    return;
  }

  pool.init();

  const keys = pool.listAvailableKeys(provider);
  if (!keys || keys.length === 0) {
    printError(`No keys configured for "${provider}".`);
    return;
  }

  // Force-pick the next key (round-robin advances cursor)
  const next = pool.pick(provider);
  if (next) {
    printSuccess(`Rotated to key ${next.keyId || next.id} (${provider})`);
  } else {
    printError(`All keys for "${provider}" are in cooldown or disabled.`);
  }
}

async function handleGatewayKey(subAction = '', args = []) {
  if (subAction === 'health') {
    return handleGatewayKeyHealth(args);
  } else if (subAction === 'rotate') {
    return handleGatewayKeyRotate(args);
  } else {
    console.log('');
    console.log(chalk.bold('  Gateway Key Management'));
    console.log('');
    console.log('  Usage:');
    console.log(chalk.dim('    gateway key health [provider]    Probe all keys (or filter by provider)'));
    console.log(chalk.dim('    gateway key rotate <provider>    Force rotate to next available key'));
    console.log('');
  }
}

module.exports = {
  handleGatewayStatus,
  handleGatewayConfig,
  handleGatewayRelay,
  handleGatewayDetect,
  handleGatewaySelectModel,
  handleGatewayPreferRemote,
  handleGatewayTest,
  handleGatewayManage,
  handleAiServer,
  handleGatewayProtocols,
  handleGatewayOAuth,
  handleGatewayDiscoverModels,
  handleGatewayTuneLocal,
  handleGatewayKey,
};
