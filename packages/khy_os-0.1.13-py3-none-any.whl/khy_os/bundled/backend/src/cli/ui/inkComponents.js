'use strict';

/**
 * Ink UI Components — React-like composable CLI rendering.
 *
 * Provides reusable UI components for the KHY CLI interface.
 * Uses a lightweight component model inspired by Ink (React for CLI).
 *
 * Unlike full Ink, this module:
 *   - No JSX/transpilation required
 *   - Pure Node.js, zero external dependencies
 *   - Compatible with existing chalk-based rendering
 *   - Progressive adoption: use alongside existing formatters
 *
 * Components:
 *   - Box: Flexible container with padding, borders, alignment
 *   - Text: Styled text with chalk integration
 *   - Spinner: Animated spinner with label
 *   - ProgressBar: Horizontal bar with percentage
 *   - Table: Auto-sizing table with headers
 *   - Select: Interactive single/multi-select menu
 *   - TextInput: Single-line text input
 *   - StatusBar: Persistent bottom status line
 *
 * @module inkComponents
 */

const readline = require('readline');

let chalk;
try { chalk = require('chalk'); } catch { chalk = { bold: (t) => t, dim: (t) => t, green: (t) => t, red: (t) => t, yellow: (t) => t, cyan: (t) => t, blue: (t) => t, gray: (t) => t, white: (t) => t, hex: () => (t) => t, bgRed: (t) => t, bgGreen: (t) => t, bgYellow: (t) => t, bgBlue: (t) => t, bgCyan: (t) => t, bgHex: () => (t) => t, strikethrough: (t) => t, underline: (t) => t, italic: (t) => t }; }

// ── Box Component ──

/**
 * Render a box with borders and padding.
 *
 * @param {object} props
 * @param {string} props.content - Box content (multi-line)
 * @param {string} [props.title] - Optional title in top border
 * @param {string} [props.borderStyle] - 'single' | 'double' | 'round' | 'none'
 * @param {number} [props.padding] - Internal padding
 * @param {number} [props.width] - Fixed width (auto if omitted)
 * @param {'left'|'center'|'right'} [props.align] - Content alignment
 * @param {string} [props.borderColor] - Chalk color for border
 * @returns {string}
 */
function Box(props) {
  const {
    content = '',
    title = '',
    borderStyle = 'single',
    padding = 0,
    width,
    align = 'left',
    borderColor,
  } = props;

  const lines = content.split('\n');
  const pad = ' '.repeat(padding);

  // Calculate width
  const contentWidth = width
    ? width - 2 - padding * 2
    : Math.max(...lines.map((l) => _stripAnsi(l).length), title.length + 4);

  const chars = _getBorderChars(borderStyle);
  const colorFn = borderColor ? (chalk.hex ? chalk.hex(borderColor) : chalk.white) : chalk.dim;

  const output = [];

  // Top border
  let topLine = chars.tl + chars.h.repeat(contentWidth + padding * 2) + chars.tr;
  if (title) {
    const titleStr = ` ${title} `;
    topLine = chars.tl + chars.h + titleStr + chars.h.repeat(Math.max(0, contentWidth + padding * 2 - titleStr.length - 1)) + chars.tr;
  }
  output.push(colorFn(topLine));

  // Padding top
  for (let i = 0; i < padding; i++) {
    output.push(colorFn(chars.v) + ' '.repeat(contentWidth + padding * 2) + colorFn(chars.v));
  }

  // Content lines
  for (const line of lines) {
    const stripped = _stripAnsi(line);
    const padded = _align(line, stripped.length, contentWidth, align);
    output.push(colorFn(chars.v) + pad + padded + pad + colorFn(chars.v));
  }

  // Padding bottom
  for (let i = 0; i < padding; i++) {
    output.push(colorFn(chars.v) + ' '.repeat(contentWidth + padding * 2) + colorFn(chars.v));
  }

  // Bottom border
  output.push(colorFn(chars.bl + chars.h.repeat(contentWidth + padding * 2) + chars.br));

  return output.join('\n');
}

// ── Text Component ──

/**
 * Render styled text.
 *
 * @param {string} content
 * @param {object} [style]
 * @param {boolean} [style.bold]
 * @param {boolean} [style.dim]
 * @param {boolean} [style.italic]
 * @param {boolean} [style.underline]
 * @param {string} [style.color] - Chalk color name or hex
 * @param {string} [style.bg] - Background color
 * @returns {string}
 */
function Text(content, style) {
  if (!style) return content;
  let result = content;
  if (style.bold) result = chalk.bold(result);
  if (style.dim) result = chalk.dim(result);
  if (style.italic && chalk.italic) result = chalk.italic(result);
  if (style.underline && chalk.underline) result = chalk.underline(result);
  if (style.color) {
    const fn = chalk[style.color] || (chalk.hex ? chalk.hex(style.color) : null);
    if (fn) result = fn(result);
  }
  if (style.bg) {
    const bgKey = 'bg' + style.bg.charAt(0).toUpperCase() + style.bg.slice(1);
    if (chalk[bgKey]) result = chalk[bgKey](result);
  }
  return result;
}

// ── Spinner Component ──

const SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];

/**
 * Create an animated spinner.
 *
 * @param {object} props
 * @param {string} [props.label] - Text next to spinner
 * @param {string} [props.color] - Spinner color
 * @param {number} [props.interval] - Frame interval in ms (default 80)
 * @returns {{start(), stop(), update(label), succeed(label), fail(label)}}
 */
function Spinner(props) {
  const { label = '', color = 'cyan', interval = 80 } = props || {};

  let frame = 0;
  let timer = null;
  let currentLabel = label;
  const colorFn = chalk[color] || chalk.cyan;

  function render() {
    const spinner = colorFn(SPINNER_FRAMES[frame % SPINNER_FRAMES.length]);
    process.stderr.write(`\r  ${spinner} ${currentLabel}  `);
    frame++;
  }

  return {
    start() {
      if (timer) return;
      timer = setInterval(render, interval);
      render();
    },
    stop() {
      if (timer) { clearInterval(timer); timer = null; }
      process.stderr.write('\r' + ' '.repeat(currentLabel.length + 10) + '\r');
    },
    update(newLabel) {
      currentLabel = newLabel;
    },
    succeed(msg) {
      this.stop();
      console.log(`  ${chalk.green('✓')} ${msg || currentLabel}`);
    },
    fail(msg) {
      this.stop();
      console.log(`  ${chalk.red('✗')} ${msg || currentLabel}`);
    },
  };
}

// ── ProgressBar Component ──

/**
 * Render a progress bar.
 *
 * @param {object} props
 * @param {number} props.value - Current value (0-100)
 * @param {number} [props.width] - Bar width in chars (default 30)
 * @param {string} [props.label] - Label text
 * @param {boolean} [props.showPercent] - Show percentage (default true)
 * @param {string} [props.completeChar] - Filled char (default █)
 * @param {string} [props.incompleteChar] - Empty char (default ░)
 * @returns {string}
 */
function ProgressBar(props) {
  const {
    value = 0,
    width = 30,
    label = '',
    showPercent = true,
    completeChar = '█',
    incompleteChar = '░',
  } = props;

  const pct = Math.max(0, Math.min(100, value));
  const filled = Math.round(pct / 100 * width);
  const empty = width - filled;

  const bar = chalk.green(completeChar.repeat(filled)) + chalk.gray(incompleteChar.repeat(empty));
  const percentStr = showPercent ? chalk.dim(` ${Math.round(pct)}%`) : '';
  const labelStr = label ? `${label} ` : '';

  return `  ${labelStr}${bar}${percentStr}`;
}

// ── Table Component ──

/**
 * Render a formatted table.
 *
 * @param {object} props
 * @param {string[]} props.headers - Column headers
 * @param {string[][]} props.rows - Data rows
 * @param {number[]} [props.widths] - Column widths (auto if omitted)
 * @param {'left'|'center'|'right'} [props.align] - Default alignment
 * @returns {string}
 */
function Table(props) {
  const { headers = [], rows = [], widths, align = 'left' } = props;

  // Auto-calculate widths
  const colWidths = widths || headers.map((h, i) => {
    const maxData = rows.reduce((max, row) => {
      const cell = _stripAnsi(String(row[i] || ''));
      return Math.max(max, cell.length);
    }, 0);
    return Math.max(_stripAnsi(h).length, maxData, 3);
  });

  const lines = [];

  // Header
  const headerLine = headers.map((h, i) =>
    chalk.bold(_padCell(h, colWidths[i], align))
  ).join(chalk.dim(' │ '));
  lines.push('  ' + headerLine);

  // Separator
  const sep = colWidths.map((w) => '─'.repeat(w)).join('─┼─');
  lines.push(chalk.dim('  ' + sep));

  // Rows
  for (const row of rows) {
    const cells = row.map((cell, i) =>
      _padCell(String(cell || ''), colWidths[i], align)
    ).join(chalk.dim(' │ '));
    lines.push('  ' + cells);
  }

  return lines.join('\n');
}

// ── Select Component ──

/**
 * Interactive select menu.
 *
 * @param {object} props
 * @param {string} props.message - Prompt message
 * @param {Array<{label: string, value: any, description?: string}>} props.options
 * @param {boolean} [props.multi] - Multi-select mode
 * @returns {Promise<any>} Selected value(s)
 */
function Select(props) {
  const { message, options, multi = false } = props;

  return new Promise((resolve) => {
    let cursor = 0;
    const selected = new Set();
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

    function render() {
      process.stdout.write('\x1B[?25l'); // Hide cursor
      process.stdout.write(`\r\x1B[K  ${chalk.bold(message)}\n`);

      for (let i = 0; i < options.length; i++) {
        const opt = options[i];
        const isCursor = i === cursor;
        const isSelected = selected.has(i);

        let prefix = isCursor ? chalk.cyan('❯ ') : '  ';
        if (multi) {
          prefix += isSelected ? chalk.green('◉ ') : chalk.dim('○ ');
        }

        const label = isCursor ? chalk.cyan(opt.label) : opt.label;
        const desc = opt.description ? chalk.dim(` — ${opt.description}`) : '';
        process.stdout.write(`\x1B[K${prefix}${label}${desc}\n`);
      }

      // Move cursor back up
      process.stdout.write(`\x1B[${options.length + 1}A`);
    }

    function cleanup() {
      process.stdout.write('\x1B[?25h'); // Show cursor
      process.stdout.write(`\x1B[${options.length + 1}B\r`);
      rl.close();
    }

    process.stdin.setRawMode(true);
    process.stdin.resume();

    render();

    process.stdin.on('keypress', (ch, key) => {
      if (!key) return;

      if (key.name === 'up' || key.name === 'k') {
        cursor = (cursor - 1 + options.length) % options.length;
        render();
      } else if (key.name === 'down' || key.name === 'j') {
        cursor = (cursor + 1) % options.length;
        render();
      } else if (key.name === 'space' && multi) {
        if (selected.has(cursor)) selected.delete(cursor);
        else selected.add(cursor);
        render();
      } else if (key.name === 'return') {
        cleanup();
        process.stdin.setRawMode(false);
        if (multi) {
          resolve([...selected].map((i) => options[i].value));
        } else {
          resolve(options[cursor].value);
        }
      } else if (key.name === 'escape' || (key.ctrl && key.name === 'c')) {
        cleanup();
        process.stdin.setRawMode(false);
        resolve(null);
      }
    });
  });
}

// ── StatusBar Component ──

/**
 * Create a persistent status bar at the bottom of the terminal.
 *
 * @param {object} props
 * @param {string} [props.left] - Left-aligned text
 * @param {string} [props.center] - Center text
 * @param {string} [props.right] - Right-aligned text
 * @param {string} [props.bg] - Background color
 * @returns {{update(props), destroy()}}
 */
function StatusBar(props) {
  let currentProps = props || {};
  let active = true;

  function render() {
    if (!active || !process.stdout.isTTY) return;

    const cols = process.stdout.columns || 80;
    const left = currentProps.left || '';
    const center = currentProps.center || '';
    const right = currentProps.right || '';

    const leftLen = _stripAnsi(left).length;
    const centerLen = _stripAnsi(center).length;
    const rightLen = _stripAnsi(right).length;

    const gap1 = Math.max(1, Math.floor((cols - leftLen - centerLen - rightLen) / 2));
    const gap2 = Math.max(1, cols - leftLen - gap1 - centerLen - rightLen);

    let line = left + ' '.repeat(gap1) + center + ' '.repeat(gap2) + right;
    line = line.substring(0, cols);

    const bgFn = currentProps.bg ? (chalk.bgHex ? chalk.bgHex(currentProps.bg) : chalk.bgBlue) : chalk.bgBlue;

    // Save cursor, move to bottom, render, restore cursor
    process.stdout.write(`\x1B7\x1B[${process.stdout.rows};1H${bgFn(chalk.white(line))}\x1B8`);
  }

  render();

  return {
    update(newProps) {
      currentProps = { ...currentProps, ...newProps };
      render();
    },
    destroy() {
      active = false;
      if (process.stdout.isTTY) {
        process.stdout.write(`\x1B[${process.stdout.rows};1H\x1B[K`);
      }
    },
  };
}

// ── Layout Helpers ──

/**
 * Render components vertically (column layout).
 * @param {...string} components
 * @returns {string}
 */
function VStack(...components) {
  return components.filter(Boolean).join('\n');
}

/**
 * Render components horizontally (row layout).
 * @param {string[]} components
 * @param {number} [gap] - Space between components
 * @returns {string}
 */
function HStack(components, gap) {
  const g = ' '.repeat(gap || 2);
  const lines = components.map((c) => (c || '').split('\n'));
  const maxLines = Math.max(...lines.map((l) => l.length));

  const result = [];
  for (let i = 0; i < maxLines; i++) {
    result.push(lines.map((l) => l[i] || '').join(g));
  }
  return result.join('\n');
}

// ── Internal Helpers ──

function _getBorderChars(style) {
  switch (style) {
    case 'double': return { tl: '╔', tr: '╗', bl: '╚', br: '╝', h: '═', v: '║' };
    case 'round':  return { tl: '╭', tr: '╮', bl: '╰', br: '╯', h: '─', v: '│' };
    case 'none':   return { tl: ' ', tr: ' ', bl: ' ', br: ' ', h: ' ', v: ' ' };
    case 'single':
    default:       return { tl: '┌', tr: '┐', bl: '└', br: '┘', h: '─', v: '│' };
  }
}

function _stripAnsi(str) {
  return str.replace(/\x1B\[[0-9;]*m/g, '');
}

function _align(str, strippedLen, width, align) {
  const gap = Math.max(0, width - strippedLen);
  switch (align) {
    case 'center': {
      const left = Math.floor(gap / 2);
      return ' '.repeat(left) + str + ' '.repeat(gap - left);
    }
    case 'right':
      return ' '.repeat(gap) + str;
    default:
      return str + ' '.repeat(gap);
  }
}

function _padCell(str, width, align) {
  const stripped = _stripAnsi(str);
  const gap = Math.max(0, width - stripped.length);
  if (align === 'right') return ' '.repeat(gap) + str;
  if (align === 'center') {
    const left = Math.floor(gap / 2);
    return ' '.repeat(left) + str + ' '.repeat(gap - left);
  }
  return str + ' '.repeat(gap);
}

// ── Sparkline ───────────────────────────────────────────────────────────

const SPARK_CHARS = '▁▂▃▄▅▆▇█';

/**
 * Inline mini-chart using block characters (8-level height).
 *
 * @param {{ data: number[], width?: number, color?: string, label?: string, min?: number, max?: number }} props
 * @returns {string}
 */
function Sparkline(props) {
  const { data = [], width, color, label } = props;
  if (!data.length) return label ? `  ${label} (no data)` : '  (no data)';

  const lo = props.min !== undefined ? props.min : Math.min(...data);
  const hi = props.max !== undefined ? props.max : Math.max(...data);
  const range = hi - lo || 1;

  // Downsample if width specified and smaller than data length
  let samples = data;
  const maxW = width || Math.min(data.length, (process.stdout.columns || 80) - 10);
  if (data.length > maxW) {
    samples = [];
    const step = data.length / maxW;
    for (let i = 0; i < maxW; i++) {
      const idx = Math.min(Math.floor(i * step), data.length - 1);
      samples.push(data[idx]);
    }
  }

  let line = samples.map(v => {
    const idx = Math.round(((v - lo) / range) * (SPARK_CHARS.length - 1));
    return SPARK_CHARS[Math.max(0, Math.min(SPARK_CHARS.length - 1, idx))];
  }).join('');

  if (color) {
    try { line = chalk.hex(color)(line); } catch { /* ignore invalid color */ }
  }

  const loStr = chalk.dim(lo.toFixed(1));
  const hiStr = chalk.dim(hi.toFixed(1));
  const labelStr = label ? `${label} ` : '';
  return `  ${labelStr}${loStr} ${line} ${hiStr}`;
}

// ── BarChart ────────────────────────────────────────────────────────────

/**
 * Horizontal bar chart with auto-colored bars.
 *
 * @param {{ items: Array<{label: string, value: number, color?: string, maxValue?: number}>, width?: number, showValue?: boolean }} props
 * @returns {string}
 */
function BarChart(props) {
  const { items = [], showValue = true } = props;
  if (!items.length) return '  (no data)';

  const barWidth = props.width || Math.min(20, Math.max(10, ((process.stdout.columns || 80) - 30)));
  const maxLabel = Math.max(...items.map(it => _stripAnsi(it.label).length));
  const globalMax = Math.max(...items.map(it => it.maxValue || it.value), 1);

  const lines = items.map(it => {
    const pct = Math.max(0, Math.min(100, (it.value / globalMax) * 100));
    const filled = Math.round(pct / 100 * barWidth);
    const empty = barWidth - filled;

    const barColor = it.color
      ? (str => { try { return chalk.hex(it.color)(str); } catch { return str; } })
      : pct > 80 ? chalk.red : pct > 50 ? chalk.yellow : chalk.green;

    const bar = barColor('█'.repeat(filled)) + chalk.dim('░'.repeat(empty));
    const lbl = _align(it.label, _stripAnsi(it.label).length, maxLabel, 'right');
    const val = showValue ? chalk.dim(` ${Math.round(pct)}%`) : '';
    return `  ${lbl}  ${bar}${val}`;
  });

  return lines.join('\n');
}

module.exports = {
  Box,
  Text,
  Spinner,
  ProgressBar,
  Table,
  Select,
  StatusBar,
  VStack,
  HStack,
  Sparkline,
  BarChart,
};
