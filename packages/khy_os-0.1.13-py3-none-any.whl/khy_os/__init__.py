"""KHY OS bundled payload container package."""
