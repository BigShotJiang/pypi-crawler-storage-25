"""Local policy gates for CI-friendly MCP audit enforcement."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from mcp_audit.models import AuditReport, PermissionCategory, PolicyResult, PolicyViolation

_SEVERITY_RANK = {"low": 1, "medium": 2, "high": 3}


@dataclass(frozen=True)
class PolicyConfig:
    """Parsed local policy gate configuration."""

    fail_on_severity: str | None = None
    fail_on_drift: bool = False
    denied_permissions: list[PermissionCategory] = field(default_factory=list)
    max_risk: float | None = None
    allow_servers: list[str] = field(default_factory=list)
    server_rules: dict[str, ServerPolicyConfig] = field(default_factory=dict)


@dataclass(frozen=True)
class ServerPolicyConfig:
    """Policy overrides scoped to one server name."""

    denied_permissions: list[PermissionCategory] = field(default_factory=list)
    max_risk: float | None = None


def load_policy(path: Path) -> PolicyConfig:
    """Load a policy YAML file from disk."""
    raw = yaml.safe_load(path.read_text())
    if not isinstance(raw, dict):
        raise ValueError("Policy file must contain a YAML mapping.")

    fail_on = _mapping(raw.get("fail_on"), "fail_on")
    deny = _mapping(raw.get("deny"), "deny")
    server_rules = _server_rules(raw.get("servers"))

    severity = fail_on.get("severity")
    if severity is not None:
        severity = str(severity).lower()
        if severity not in _SEVERITY_RANK:
            valid = ", ".join(_SEVERITY_RANK)
            raise ValueError(f"Unknown policy severity '{severity}'. Valid values: {valid}.")

    permissions = [_permission(value) for value in _sequence(deny.get("permissions"), "deny.permissions")]

    max_risk = raw.get("max_risk")
    if max_risk is not None:
        max_risk = float(max_risk)
        if max_risk < 0 or max_risk > 10:
            raise ValueError("max_risk must be between 0 and 10.")

    return PolicyConfig(
        fail_on_severity=severity,
        fail_on_drift=bool(fail_on.get("drift", False)),
        denied_permissions=permissions,
        max_risk=max_risk,
        allow_servers=[str(value) for value in _sequence(raw.get("allow_servers"), "allow_servers")],
        server_rules=server_rules,
    )


def evaluate_policy(report: AuditReport, policy: PolicyConfig) -> PolicyResult:
    """Evaluate a completed audit report against a local policy."""
    violations: list[PolicyViolation] = []

    for audit in report.audits:
        server_name = audit.server.name
        server_rule = policy.server_rules.get(server_name, ServerPolicyConfig())

        if policy.allow_servers and server_name not in policy.allow_servers:
            violations.append(
                PolicyViolation(
                    rule="allow_servers",
                    server_name=server_name,
                    severity="medium",
                    message=f"Server '{server_name}' is not listed in allow_servers.",
                )
            )

        max_risk = server_rule.max_risk if server_rule.max_risk is not None else policy.max_risk
        if max_risk is not None and audit.risk_score is not None:
            score = audit.risk_score.composite
            if score >= max_risk:
                violations.append(
                    PolicyViolation(
                        rule="max_risk",
                        server_name=server_name,
                        severity="high",
                        message=(
                            f"Server risk score {score:.1f} meets or exceeds policy limit {max_risk:.1f}."
                        ),
                    )
                )

        if policy.fail_on_severity is not None:
            threshold = _SEVERITY_RANK[policy.fail_on_severity]
            for permission_finding in audit.permissions:
                if _SEVERITY_RANK[permission_finding.severity] >= threshold:
                    violations.append(
                        PolicyViolation(
                            rule="fail_on.severity",
                            server_name=server_name,
                            tool_name=permission_finding.tool_name,
                            severity=permission_finding.severity,
                            message=(
                                f"{permission_finding.rule_id} "
                                f"{permission_finding.category.value} finding is "
                                f"{permission_finding.severity} severity."
                            ),
                        )
                    )
            for injection_finding in audit.injection_findings:
                if _SEVERITY_RANK[injection_finding.severity.value] >= threshold:
                    violations.append(
                        PolicyViolation(
                            rule="fail_on.severity",
                            server_name=server_name,
                            tool_name=injection_finding.tool_name,
                            severity=injection_finding.severity.value,
                            message=(
                                f"{injection_finding.rule_id} prompt-injection finding is "
                                f"{injection_finding.severity.value} severity."
                            ),
                        )
                    )
            for capability_finding in audit.capability_findings:
                if _SEVERITY_RANK[capability_finding.severity] >= threshold:
                    violations.append(
                        PolicyViolation(
                            rule="fail_on.severity",
                            server_name=server_name,
                            tool_name=capability_finding.target_name,
                            severity=capability_finding.severity,
                            message=(
                                f"{capability_finding.rule_id} "
                                f"{capability_finding.target_type.value} "
                                f"{capability_finding.category.value} finding is "
                                f"{capability_finding.severity} severity."
                            ),
                        )
                    )

        denied_permissions = [*policy.denied_permissions, *server_rule.denied_permissions]

        for permission_finding in audit.permissions:
            if permission_finding.category in denied_permissions:
                violations.append(
                    PolicyViolation(
                        rule="deny.permissions",
                        server_name=server_name,
                        tool_name=permission_finding.tool_name,
                        severity=permission_finding.severity,
                        message=f"{permission_finding.category.value} is denied by local policy.",
                    )
                )
        for capability_finding in audit.capability_findings:
            if capability_finding.category in denied_permissions:
                violations.append(
                    PolicyViolation(
                        rule="deny.permissions",
                        server_name=server_name,
                        tool_name=capability_finding.target_name,
                        severity=capability_finding.severity,
                        message=(
                            f"{capability_finding.target_type.value} "
                            f"{capability_finding.category.value} is denied by local policy."
                        ),
                    )
                )

        if policy.fail_on_drift:
            for drift_finding in audit.drift_findings:
                violations.append(
                    PolicyViolation(
                        rule="fail_on.drift",
                        server_name=server_name,
                        tool_name=drift_finding.tool_name,
                        severity="medium",
                        message=f"Tool schema drift detected: {drift_finding.status.value}.",
                    )
                )

    return PolicyResult(passed=not violations, violations=violations)


def _mapping(value: Any, name: str) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be a YAML mapping.")
    return value


def _sequence(value: Any, name: str) -> list[Any]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError(f"{name} must be a YAML list.")
    return value


def _permission(value: Any) -> PermissionCategory:
    try:
        return PermissionCategory(str(value))
    except ValueError as exc:
        valid = ", ".join(category.value for category in PermissionCategory)
        raise ValueError(f"Unknown permission category '{value}'. Valid values: {valid}.") from exc


def _server_rules(value: Any) -> dict[str, ServerPolicyConfig]:
    raw_rules = _mapping(value, "servers")
    rules: dict[str, ServerPolicyConfig] = {}
    for server_name, rule_value in raw_rules.items():
        rule = _mapping(rule_value, f"servers.{server_name}")
        deny = _mapping(rule.get("deny"), f"servers.{server_name}.deny")
        max_risk = rule.get("max_risk")
        if max_risk is not None:
            max_risk = float(max_risk)
            if max_risk < 0 or max_risk > 10:
                raise ValueError(f"servers.{server_name}.max_risk must be between 0 and 10.")
        rules[str(server_name)] = ServerPolicyConfig(
            denied_permissions=[
                _permission(permission)
                for permission in _sequence(
                    deny.get("permissions"),
                    f"servers.{server_name}.deny.permissions",
                )
            ],
            max_risk=max_risk,
        )
    return rules
