"""Tests for models module."""

import pytest

from tsugite.config import Config, update_config
from tsugite.models import parse_model_string, resolve_effective_model, resolve_model_alias


def test_parse_model_string():
    """Test parsing model strings."""
    provider, model, variant = parse_model_string("ollama:qwen2.5-coder:7b")
    assert provider == "ollama"
    assert model == "qwen2.5-coder"
    assert variant == "7b"

    provider, model, variant = parse_model_string("openai:gpt-4")
    assert provider == "openai"
    assert model == "gpt-4"
    assert variant is None


def test_parse_model_string_invalid():
    """Test parsing invalid model strings."""
    with pytest.raises(ValueError):
        parse_model_string("invalid")


def test_resolve_model_alias_with_full_string(tmp_path):
    """Test that full model strings pass through unchanged."""
    config_path = tmp_path / "config.json"
    update_config(config_path, lambda cfg: cfg.model_aliases.update({"cheap": "openai:gpt-4o-mini"}))

    full_model = "ollama:qwen2.5-coder:7b"
    resolved = resolve_model_alias(full_model)
    assert resolved == full_model


def test_resolve_model_alias_with_alias(tmp_path, monkeypatch):
    """Test resolving an alias to its model string."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

    config_path = tmp_path / "tsugite" / "config.json"
    update_config(config_path, lambda cfg: cfg.model_aliases.update({"cheap": "openai:gpt-4o-mini"}))

    resolved = resolve_model_alias("cheap")
    assert resolved == "openai:gpt-4o-mini"


def test_resolve_model_alias_nonexistent(tmp_path, monkeypatch):
    """Test resolving nonexistent alias returns original string."""
    Config().save_config = lambda path: None

    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))

    resolved = resolve_model_alias("nonexistent")
    assert resolved == "nonexistent"


def test_resolve_effective_model_override_wins(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert resolve_effective_model("openai:gpt-4", "ollama:llama3") == "openai:gpt-4"


def test_resolve_effective_model_agent_model(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert resolve_effective_model(None, "ollama:llama3") == "ollama:llama3"


def test_resolve_effective_model_config_default(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    config_path = tmp_path / "tsugite" / "config.json"
    update_config(config_path, lambda cfg: setattr(cfg, "default_model", "anthropic:claude-3-haiku"))
    assert resolve_effective_model(None, None) == "anthropic:claude-3-haiku"


def test_resolve_effective_model_none_when_nothing_set(tmp_path, monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    monkeypatch.setenv("HOME", str(tmp_path))
    assert resolve_effective_model(None, None) is None
