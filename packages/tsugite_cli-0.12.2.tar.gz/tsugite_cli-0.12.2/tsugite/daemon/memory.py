"""Memory management helpers for daemon."""

import asyncio
import logging
import re

DEFAULT_COMPACT_MODEL = "openai:gpt-4o-mini"
DEFAULT_CONTEXT_LIMIT = 128_000
CONTEXT_RESERVE_RATIO = 0.25
RETENTION_BUDGET_RATIO = 0.15
MIN_RETAINED_TURNS = 2

PROVIDER_COMPACT_MODELS = {
    "openai": DEFAULT_COMPACT_MODEL,
    "anthropic": "anthropic:claude-3-haiku-20240307",
    "google": "google:gemini-2.0-flash-lite",
    "openrouter": "openrouter:openai/gpt-4o-mini",
    "claude_code": "claude_code:haiku",
    "ollama": None,  # use agent model as-is
}

logger = logging.getLogger(__name__)

_FILE_PATH_PATTERN = re.compile(r'(?:file_path|path|filename)["\s:=]+["\'`]?(/[^\s"\'`\],}]+)', re.IGNORECASE)

_SUMMARY_FORMAT = """\
## Current Task
What is actively being worked on or discussed right now.

## Key Decisions
Important decisions made during the conversation.

## Facts & Preferences
Facts learned about the user, project, or environment. User preferences and conventions.

## Files Accessed
Files that were read, written, or modified during the conversation. Include full paths.

## Work Progress
What was completed, what was attempted and failed, what is partially done.

## Open Questions
Unresolved questions or ambiguities that still need answers.

## Action Items
Concrete next steps or pending tasks."""

SUMMARIZE_SYSTEM_PROMPT = (
    "Summarize this conversation using the structured format below.\n"
    "Keep the total summary under 800 words. Omit any section that has no content.\n\n"
    f"{_SUMMARY_FORMAT}"
)

COMBINE_SYSTEM_PROMPT = (
    "You are given multiple summaries of consecutive conversation chunks.\n"
    "Combine them into a single coherent summary using the structured format below.\n"
    "Keep the total summary under 800 words. Omit any section that has no content.\n\n"
    f"{_SUMMARY_FORMAT}"
)


def infer_compaction_model(agent_model: str) -> str:
    """Pick a cheap model from the same provider as the agent."""
    from tsugite.models import parse_model_string, resolve_model_alias

    resolved = resolve_model_alias(agent_model)
    try:
        provider, _, _ = parse_model_string(resolved)
    except ValueError:
        return DEFAULT_COMPACT_MODEL

    if provider not in PROVIDER_COMPACT_MODELS:
        return resolved

    compact = PROVIDER_COMPACT_MODELS[provider]
    return compact if compact is not None else resolved


def get_context_limit(model: str, fallback: int | None = None) -> int:
    """Get context limit for a model via the provider system.

    Priority: provider model_info -> fallback -> DEFAULT_CONTEXT_LIMIT.
    """
    from tsugite.models import get_provider_and_model

    try:
        provider_name, provider, model_id = get_provider_and_model(model)
        info = provider.get_model_info(model_id)
        if info and info.max_input_tokens:
            return info.max_input_tokens
    except Exception:
        pass

    return fallback if fallback is not None else DEFAULT_CONTEXT_LIMIT


def _count_tokens(text: str, model: str) -> int:
    """Count tokens using the provider, falling back to len//4."""
    from tsugite.models import get_provider_and_model

    try:
        _, provider, model_id = get_provider_and_model(model)
        return provider.count_tokens(text, model_id)
    except Exception:
        return len(text) // 4


def _message_text(msg: dict) -> str:
    """Extract text content from a message dict."""
    content = msg.get("content")
    if not content:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [
            block if isinstance(block, str) else block["text"]
            for block in content
            if isinstance(block, str) or (isinstance(block, dict) and "text" in block)
        ]
        return "\n".join(parts)
    return str(content)


def _chunk_messages(messages: list[dict], max_chunk_tokens: int, model: str) -> list[list[dict]]:
    """Split messages into chunks that fit within token budget.

    Keeps user/assistant pairs together when possible.
    """
    if not messages:
        return []

    chunks: list[list[dict]] = []
    current_chunk: list[dict] = []
    current_tokens = 0

    for msg in messages:
        msg_text = _message_text(msg)
        text = f"{msg.get('role', 'user').upper()}: {msg_text}"
        msg_tokens = _count_tokens(text, model)

        if msg_tokens > max_chunk_tokens:
            if current_chunk:
                chunks.append(current_chunk)
                current_chunk = []
                current_tokens = 0
            chars_budget = max_chunk_tokens * 4
            chunks.append([{**msg, "content": msg_text[:chars_budget]}])
            continue

        # Would adding this message exceed the budget?
        if current_tokens + msg_tokens > max_chunk_tokens and current_chunk:
            chunks.append(current_chunk)
            current_chunk = []
            current_tokens = 0

        current_chunk.append(msg)
        current_tokens += msg_tokens

    if current_chunk:
        chunks.append(current_chunk)

    return chunks


async def _llm_complete(system_prompt: str, user_content: str, model: str) -> str:
    """Send a system+user message pair to the LLM and return the response text."""
    from tsugite.models import get_provider_and_model

    try:
        _, provider, model_id = get_provider_and_model(model)
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]
        response = await provider.acompletion(messages=messages, model=model_id)
        content = response.content
    except Exception as e:
        raise RuntimeError(f"LLM call failed ({model}): {e}") from e

    if not content:
        raise RuntimeError(f"LLM returned empty response ({model})")
    return content


async def _summarize_chunk(messages: list[dict], model: str) -> str:
    """Summarize a single chunk of conversation messages."""
    convo_text = "\n\n".join(f"{msg['role'].upper()}: {_message_text(msg)}" for msg in messages)
    return await _llm_complete(SUMMARIZE_SYSTEM_PROMPT, convo_text, model)


async def _combine_summaries(summaries: list[str], model: str) -> str:
    """Combine multiple chunk summaries into one."""
    numbered = "\n\n".join(f"--- Chunk {i + 1} ---\n{s}" for i, s in enumerate(summaries))
    return await _llm_complete(COMBINE_SYSTEM_PROMPT, numbered, model)


async def summarize_session(
    conversation_history: list[dict],
    model: str | None = None,
    max_context_tokens: int | None = None,
) -> str:
    """Summarize conversation history using LLM with chunked map-reduce.

    Args:
        conversation_history: List of {role, content} dicts
        model: Model to use for summarization (Tsugite format: provider:model).
        max_context_tokens: Override context limit (for Ollama/custom models).
    """
    if not conversation_history:
        return "No conversation to summarize."

    if model is None:
        model = DEFAULT_COMPACT_MODEL

    context_limit = get_context_limit(model, fallback=max_context_tokens)
    usable_tokens = int(context_limit * (1 - CONTEXT_RESERVE_RATIO))

    chunks = _chunk_messages(conversation_history, usable_tokens, model)
    if not chunks:
        return "No conversation to summarize."

    if len(chunks) == 1:
        return await _summarize_chunk(chunks[0], model)

    logger.info("Summarizing %d chunks (context limit: %d, usable: %d)", len(chunks), context_limit, usable_tokens)
    chunk_summaries = await asyncio.gather(*[_summarize_chunk(chunk, model) for chunk in chunks])
    return await _combine_summaries(chunk_summaries, model)


TITLE_SYSTEM_PROMPT = (
    "Generate a short title (3-6 words) for this conversation. "
    "Return only the title, nothing else. No quotes, no punctuation at the end."
)

TITLE_TIMEOUT = 30
SHORT_TITLE_THRESHOLD = 60


async def generate_session_title(messages: list[dict], model: str) -> str:
    """Generate a short title from conversation messages using a cheap model."""
    text_parts = []
    for msg in messages:
        content = _message_text(msg)
        if content:
            text_parts.append(f"{msg.get('role', 'user').upper()}: {content[:500]}")
    if not text_parts:
        return ""
    convo_text = "\n\n".join(text_parts)
    title = await asyncio.wait_for(
        _llm_complete(TITLE_SYSTEM_PROMPT, convo_text, model),
        timeout=TITLE_TIMEOUT,
    )
    return title.strip().strip("\"'")[:80]


async def compute_session_title(
    user_content: str,
    assistant_content: str,
    agent_model: str,
) -> str:
    """Compute a title for a session. Returns empty string if no title could be generated."""
    if len(user_content) <= SHORT_TITLE_THRESHOLD:
        return user_content
    model = infer_compaction_model(agent_model)
    messages = [
        {"role": "user", "content": user_content},
        {"role": "assistant", "content": assistant_content},
    ]
    return await generate_session_title(messages, model)


def extract_file_paths_from_turns(turns: "list[Turn]") -> list[str]:
    """Extract file paths mentioned in tool calls across turns.

    Scans turn messages for common file path patterns in tool arguments
    (read_file, write_file, edit_file, etc.).

    Returns:
        Deduplicated list of file paths found.
    """
    paths: set[str] = set()
    for turn in turns:
        for msg in turn.messages:
            text = _message_text(msg)
            if text:
                paths.update(_FILE_PATH_PATTERN.findall(text))
    return sorted(paths)


def _estimate_turn_tokens(turn: "Turn", model: str) -> int:
    """Estimate token cost of a Turn by summing its messages."""
    return sum(
        _count_tokens(f"{msg.get('role', 'user').upper()}: {text}", model)
        for msg in turn.messages
        if (text := _message_text(msg))
    )


def split_turns_for_compaction(
    turns: list["Turn"],
    model: str,
    retention_budget_tokens: int,
    min_retained: int = MIN_RETAINED_TURNS,
) -> tuple[list["Turn"], list["Turn"]]:
    """Split turns into (old, recent) for compaction.

    Walks backward keeping recent turns that fit within the retention budget.
    Always keeps at least min_retained turns. If all turns fit, returns
    empty old list so the caller can skip compaction.

    Returns:
        (old_turns, recent_turns) — old_turns may be empty.
    """
    if not turns:
        return [], []

    if len(turns) <= min_retained:
        return [], list(turns)

    kept: list["Turn"] = []
    budget_remaining = retention_budget_tokens

    for turn in reversed(turns):
        cost = _estimate_turn_tokens(turn, model)
        if len(kept) >= min_retained and budget_remaining < cost:
            break
        kept.append(turn)
        budget_remaining -= cost

    kept.reverse()
    split_idx = len(turns) - len(kept)
    return turns[:split_idx], turns[split_idx:]
