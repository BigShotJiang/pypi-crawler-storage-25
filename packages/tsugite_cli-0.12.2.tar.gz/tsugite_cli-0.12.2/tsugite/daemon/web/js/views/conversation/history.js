import { get } from '../../api.js';
import { escapeHtml, contentBlockHtml, truncate } from '../../utils.js';

export const historyMixin = {
  _allHistoryMessages: [],
  _historyLoaded: 0,
  HISTORY_PAGE_SIZE: 20,
  hasMoreHistory: false,
  compactionSummary: null,
  compactedFrom: null,
  compactionReason: null,

  _historyDebounceTimer: null,

  _debouncedLoadHistory() {
    if (this._historyDebounceTimer) clearTimeout(this._historyDebounceTimer);
    this._historyDebounceTimer = setTimeout(() => this.loadHistory(), 200);
  },

  resetHistory() {
    this._allHistoryMessages = [];
    this._historyLoaded = 0;
    this.hasMoreHistory = false;
    this.compactionSummary = null;
    this.compactedFrom = null;
    this.compactionReason = null;
  },

  async loadHistory() {
    const agent = this.$store.app.selectedAgent;
    if (!agent) return;
    this.resetHistory();
    try {
      let histUrl = `/api/agents/${agent}/history?user_id=${encodeURIComponent(this.userId)}&limit=100&detail=true`;
      if (this.selectedSessionId) histUrl += `&session_id=${encodeURIComponent(this.selectedSessionId)}`;
      const data = await get(histUrl);
      this.compactionSummary = data.compaction_summary || null;
      this.compactedFrom = data.compacted_from || null;
      this.compactionReason = data.compaction_reason || null;
      if (data.turns?.length) {
        let pendingHooks = [];
        for (const turn of data.turns) {
          if (turn.type === 'compaction') {
            this._allHistoryMessages.push({ type: 'compaction', summary: turn.summary || null, reason: turn.reason || null });
            continue;
          }
          if (turn.type === 'hook_execution') {
            pendingHooks.push(turn);
            continue;
          }
          if (turn.user) {
            const msg = { type: 'user', text: turn.user };
            if (turn.reactions) msg.reactions = turn.reactions;
            this._allHistoryMessages.push(msg);
          }

          const steps = [];
          for (const h of pendingHooks) {
            const summary = this._hookStepHtml(h.name, h.phase, h.exit_code);
            const output = [h.stdout, h.stderr].filter(Boolean).join('\n');
            if (output) {
              steps.push({ hasDetails: true, summary, content: output, open: false });
            } else {
              steps.push({ html: summary });
            }
          }
          pendingHooks = [];
          if (turn.messages) {
            for (const item of this.extractMessages(turn)) {
              if (item.type === 'tool_call') {
                steps.push({ hasDetails: true, summary: `<code>${escapeHtml(item.name)}</code>`, content: item.args, open: false });
              } else if (item.type === 'tool_result') {
                steps.push({ hasDetails: true, summary: `<code>${escapeHtml(item.name || 'result')}</code>`, content: item.content, open: false });
              } else if (item.type === 'content_block') {
                steps.push({ html: contentBlockHtml(item.name, item.content) });
              } else if (item.type === 'thought') {
                steps.push({ hasDetails: true, summary: 'thought', content: item.content, open: false });
              }
            }
          }
          if (steps.length > 0) {
            this._allHistoryMessages.push({ type: 'progress-done', steps, turnCount: turn.turn_count || 1, toolCount: turn.tool_count || turn.tools_used?.length || 0 });
          }
          if (turn.assistant) {
            this._allHistoryMessages.push({ type: 'agent', text: turn.assistant });
          }
        }
        this._showRecentHistory();
      } else if (this.selectedSessionMeta) {
        const meta = this.selectedSessionMeta;
        if (meta.prompt) this._allHistoryMessages.push({ type: 'user', text: meta.prompt });
        if (meta.error) this._allHistoryMessages.push({ type: 'error', text: meta.error });
        if (meta.result) this._allHistoryMessages.push({ type: 'agent', text: meta.result });
        this._showRecentHistory();
      }
    } catch { /* ignore */ }
    this.scrollMessages(true);
  },

  _showRecentHistory() {
    const all = this._allHistoryMessages;
    const page = this.HISTORY_PAGE_SIZE;
    const startIdx = Math.max(0, all.length - page);
    const slice = all.slice(startIdx);
    this._historyLoaded = all.length - startIdx;
    this.hasMoreHistory = startIdx > 0;
    this.messages = [];
    if (this.hasMoreHistory) {
      this.messages.push({ type: 'separator', text: `${startIdx} earlier messages — load more ↑` });
    }
    this.messages.push(...slice);
    if (slice.length > 0) {
      this.messages.push({ type: 'separator', text: `${this._historyLoaded} of ${all.length} messages loaded` });
    }
  },

  loadMoreHistory() {
    if (!this.hasMoreHistory) return;
    const all = this._allHistoryMessages;
    const page = this.HISTORY_PAGE_SIZE;
    const currentlyShown = this._historyLoaded;
    const newShown = Math.min(all.length, currentlyShown + page);
    const startIdx = all.length - newShown;
    const newSlice = all.slice(startIdx, all.length - currentlyShown);
    this._historyLoaded = newShown;
    this.hasMoreHistory = startIdx > 0;

    if (this.messages.length > 0 && this.messages[0].type === 'separator') {
      this.messages.shift();
    }
    if (this.hasMoreHistory) {
      this.messages.unshift(...newSlice, { type: 'separator', text: `${startIdx} earlier messages — load more ↑` });
    } else {
      this.messages.unshift(...newSlice);
    }
    const lastSep = this.messages.findLastIndex(m => m.type === 'separator');
    if (lastSep >= 0) {
      this.messages[lastSep].text = `${this._historyLoaded} of ${all.length} messages loaded`;
    }
  },

  extractMessages(turn) {
    if (!turn.messages) return [];
    const items = [];
    // _build_turn_messages appends the final_answer a second time as a trailing plain-text
    // assistant message. It's already rendered as turn.assistant, so skip that duplicate here.
    const lastIdx = turn.messages.length - 1;
    const trailingFinal = turn.assistant && turn.messages[lastIdx]?.role === 'assistant'
      && (turn.messages[lastIdx]?.content || '').trim() === (turn.assistant || '').trim();
    for (let i = 0; i < turn.messages.length; i++) {
      const msg = turn.messages[i];
      if (msg.role === 'assistant') {
        const content = msg.content || '';
        const codeMatch = content.match(/```(?:python)?\n([\s\S]*?)```/);
        const isTrailingFinal = trailingFinal && i === lastIdx;
        const prose = isTrailingFinal ? '' : content.replace(/```(?:python)?\n[\s\S]*?```/g, '').replace(/^Thought:\s*/i, '').trim();
        if (prose) {
          items.push({ type: 'thought', content: prose });
        }
        if (codeMatch) {
          items.push({ type: 'tool_call', name: 'code', args: codeMatch[1] });
        }
        if (msg.tool_calls) {
          for (const tc of msg.tool_calls) {
            const fn = tc.function || {};
            items.push({ type: 'tool_call', name: fn.name || 'unknown', args: fn.arguments || '{}' });
          }
        }
        if (msg.content_blocks) {
          for (const [name, content] of Object.entries(msg.content_blocks)) {
            items.push({ type: 'content_block', name, content });
          }
        }
      } else if (msg.role === 'user' && msg.content?.includes('<tsugite_execution_result')) {
        const body = msg.content.replace(/<tsugite_execution_result[^>]*>|<\/tsugite_execution_result>/g, '').trim();
        items.push({ type: 'tool_result', name: 'result', content: truncate(body) });
      } else if (msg.role === 'tool') {
        const toolContent = typeof msg.content === 'string' ? msg.content : JSON.stringify(msg.content);
        items.push({ type: 'tool_result', name: msg.name || '', content: truncate(toolContent) });
      }
    }
    return items;
  },
};
