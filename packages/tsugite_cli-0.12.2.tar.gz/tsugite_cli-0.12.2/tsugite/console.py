"""Centralized console creation utilities."""

import sys

from rich.console import Console


def get_stderr_console(no_color: bool = False) -> Console:
    """Get console for error/warning output to stderr.

    Args:
        no_color: Disable color output

    Returns:
        Console instance configured for stderr
    """
    return Console(file=sys.stderr, no_color=no_color)


def get_stdout_console(no_color: bool = False, force_terminal: bool = False) -> Console:
    """Get console for standard output to stdout.

    Args:
        no_color: Disable color output
        force_terminal: Force terminal mode even if TTY not detected

    Returns:
        Console instance configured for stdout
    """
    return Console(file=sys.stdout, no_color=no_color, force_terminal=force_terminal)


def get_error_console(headless: bool, console: Console) -> Console:
    """Get console for error output based on mode.

    Args:
        headless: Whether running in headless mode
        console: Default console to use in non-headless mode

    Returns:
        Console for error output (no-color stderr in headless, console otherwise)
    """
    return get_stderr_console(no_color=True) if headless else console
