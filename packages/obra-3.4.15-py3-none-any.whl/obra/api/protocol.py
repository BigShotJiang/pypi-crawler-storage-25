"""Shared protocol types for the Hybrid Architecture.

This public module and its adjacent `protocol*.py` family modules are kept
byte-for-byte in sync between:
- functions/src/orchestration/protocol*.py
- obra/api/protocol*.py

Protocol Design (from PRD Section 1):
    - Server owns the brain (decisions, orchestration logic)
    - Client owns the hands (execution, code access)

Message Flow:
    Client -> Server: SessionStart, IntentReport, DerivedPlan, ExaminationReport,
                     RevisedPlan, ExecutionResult, AgentReport, FixResult, UserDecision
    Server -> Client: DeriveRequest, IntentRequest, SpikeRequest, ExamineRequest, RevisionRequest,
                     ExecutionRequest, ReviewRequest, FixRequest, EscalationNotice,
                     CompletionNotice, Story0Request

Phase Flow:
    DERIVATION -> STORY0 or EXECUTION -> REVIEW (workflow-governed)

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - functions/src/orchestration/coordinator.py
    - functions/src/state/session_schema.py
"""

import logging
from dataclasses import dataclass, field
from typing import Any

from .protocol_core import (
    ActionType,
    AgentReportStatus,
    AgentType,
    BYPASS_MODE_TO_CLI_FLAG,
    DEFAULT_REPORT_REVIEW_AGENT_TYPES,
    DEFAULT_REVIEW_AGENTS,
    EscalationEnvelope,
    EscalationReason,
    ExecutionStatus,
    FixStatus,
    LegacyPhaseNormalizationPayload,
    LifecycleDecisionPayload,
    PlanItemType,
    Priority,
    QualityPolicyMode,
    ServerAction,
    SessionPhase,
    SessionStatus,
    UserDecisionChoice,
    VerificationOutcome,
    VerificationScope,
    WorkflowLifecyclePayload,
    _coerce_optional_dict,
    safe_enum_parse,
)
from .protocol_reports import (
    AgentReport,
    DerivedPlan,
    EscalationDecision,
    ExaminationReport,
    ExecutionBatchResultItem,
    ExecutionResult,
    FixReport,
    FixResult,
    GenerateTestsReport,
    IntentReport,
    PlanUploadRequest,
    PlanUploadResponse,
    ProgressEvent,
    ResumeContext,
    ResumeRequest,
    RevisedPlan,
    SessionStart,
    UserDecision,
)
from .protocol_pipeline import (
    ArtifactReferencePayload,
    LoopResumePayload,
    PendingManualPayload,
    PipelineStageRequest,
    PipelineStageResult,
    ProducedArtifactPayload,
    ResolvedStageAssetBindingPayload,
    RunnerDiagnosticPayload,
    StageLoopSignal,
    StageRoutingSignal,
    StageRunnerContext,
    WaitPayload,
    _parse_artifact_refs,
    _parse_produced_artifacts,
    _parse_resolved_stage_asset_bindings,
)
from .protocol_workflow import (
    WorkflowCandidateEnvelope,
    WorkflowMutationEvent,
    WorkflowMutationResult,
    WorkflowRevisionPayload,
    WorkflowRevisionRef,
    WorkflowSemanticView,
)
logger = logging.getLogger(__name__)


@dataclass
class DeriveRequest:
    """Request to derive a plan from objective.

    Sent by server after SessionStart to instruct client
    to derive an implementation plan.

    Attributes:
        objective: Task objective to plan for
        userplan_id: Required UserPlan ID that this derivation is for
        userplan_version: Required version of UserPlan used for derivation
        userplan_steps: Optional UserPlan step metadata for source linkage
        project_context: Project context (languages, frameworks, etc.)
        llm_provider: LLM provider to use
        constraints: Derivation constraints
        plan_items_reference: Plan items to preserve from previous derivation (for --from-step)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        from_step: Re-derive from step N onwards (1-indexed), preserving earlier steps
        complexity_score: Pre-computed complexity score for exploration triggers (ADR-055)
        skip_story0: If True, skip Story 0 derivation step (debug/re-derive)
        intent_ready: If True, intent was pre-validated and should be loaded from storage
        workflow_derivation_request: Optional canonical workflow-derivation request
            carried from session start into the active derive action
        planning_resolution: Optional reusable planning-resolution handoff from
            INTENT/validator, including validated sizing and routing state
        spike_context: Optional spike-first handoff payload
    """

    objective: str
    userplan_id: str  # Required: UserPlan ID for derivation linkage
    userplan_version: int  # Required: Version of UserPlan used for derivation
    userplan_steps: list[dict[str, Any]] = field(default_factory=list)
    project_context: dict[str, Any] = field(default_factory=dict)
    llm_provider: str = "anthropic"
    constraints: dict[str, Any] = field(default_factory=dict)
    plan_items_reference: list[dict[str, Any]] = field(default_factory=list)
    base_prompt: str | None = None
    from_step: int | None = None  # Re-derive from step N, preserving steps 1 to N-1
    complexity_score: float | None = None  # Pre-computed complexity score (ADR-055)
    skip_story0: bool = False  # If True, skip Story 0 derivation step
    intent_ready: bool = False  # If True, intent pre-validated; load from storage
    workflow_derivation_request: dict[str, Any] | None = None
    planning_resolution: dict[str, Any] | None = None
    spike_context: dict[str, Any] | None = None
    failing_test_manifest: dict[str, Any] | None = None
    remediation_request: dict[str, Any] | None = None
    derivation_id: str | None = None
    operator_review_checkpoint_state: dict[str, Any] = field(default_factory=dict)
    accepted_revision_ref: dict[str, Any] = field(default_factory=dict)
    correlation: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "DeriveRequest":
        """Create from ServerAction payload.

        Raises:
            ValueError: If userplan_id is missing from the payload
            ValueError: If userplan_version is missing from the payload
        """
        userplan_id = payload.get("userplan_id")
        if not userplan_id:
            raise ValueError("userplan_id is required for derivation")
        userplan_version = payload.get("userplan_version")
        if userplan_version is None:
            raise ValueError("userplan_version is required for derivation")
        return cls(
            objective=payload.get("objective", ""),
            userplan_id=userplan_id,
            userplan_version=int(userplan_version),
            userplan_steps=payload.get("userplan_steps", []),
            project_context=payload.get("project_context", {}),
            llm_provider=payload.get("llm_provider", "anthropic"),
            constraints=payload.get("constraints", {}),
            plan_items_reference=payload.get("plan_items_reference", []),
            base_prompt=payload.get("base_prompt"),
            from_step=payload.get("from_step"),
            complexity_score=payload.get("complexity_score"),
            skip_story0=bool(payload.get("skip_story0", False)),
            intent_ready=bool(payload.get("intent_ready", False)),
            workflow_derivation_request=(
                payload.get("workflow_derivation_request")
                if isinstance(payload.get("workflow_derivation_request"), dict)
                else None
            ),
            planning_resolution=(
                payload.get("planning_resolution")
                if isinstance(payload.get("planning_resolution"), dict)
                else None
            ),
            spike_context=(
                payload.get("spike_context")
                if isinstance(payload.get("spike_context"), dict)
                else None
            ),
            failing_test_manifest=(
                payload.get("failing_test_manifest")
                if isinstance(payload.get("failing_test_manifest"), dict)
                else None
            ),
            remediation_request=(
                payload.get("remediation_request")
                if isinstance(payload.get("remediation_request"), dict)
                else None
            ),
            derivation_id=(
                str(payload.get("derivation_id"))
                if payload.get("derivation_id") is not None
                else None
            ),
            operator_review_checkpoint_state=_coerce_optional_dict(
                payload.get("operator_review_checkpoint_state")
            ),
            accepted_revision_ref=_coerce_optional_dict(
                payload.get("accepted_revision_ref")
            ),
            correlation=_coerce_optional_dict(payload.get("correlation")),
        )


@dataclass
class IntentRequest:
    """Request to generate and enrich intent before derivation.

    Sent by server when intent validation is enabled, to collect enriched
    intent content for SenseCheck validation prior to derivation.

    Attributes:
        objective: Task objective to derive intent for
        userplan_id: Required UserPlan ID that this intent is for
        userplan_version: Required version of UserPlan used for intent generation
        project_context: Project context (languages, frameworks, etc.)
        llm_provider: LLM provider to use
        from_step: Optional re-derivation start step for context
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
    """

    objective: str
    userplan_id: str
    userplan_version: int
    project_context: dict[str, Any] = field(default_factory=dict)
    llm_provider: str = "anthropic"
    from_step: int | None = None
    base_prompt: str | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "IntentRequest":
        """Create from ServerAction payload.

        Raises:
            ValueError: If userplan_id is missing from the payload
            ValueError: If userplan_version is missing from the payload
        """
        userplan_id = payload.get("userplan_id")
        if not userplan_id:
            raise ValueError("userplan_id is required for intent generation")
        userplan_version = payload.get("userplan_version")
        if userplan_version is None:
            raise ValueError("userplan_version is required for intent generation")
        return cls(
            objective=payload.get("objective", ""),
            userplan_id=userplan_id,
            userplan_version=int(userplan_version),
            project_context=payload.get("project_context", {}),
            llm_provider=payload.get("llm_provider", "anthropic"),
            from_step=payload.get("from_step"),
            base_prompt=payload.get("base_prompt"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        data: dict[str, Any] = {
            "objective": self.objective,
            "userplan_id": self.userplan_id,
            "userplan_version": self.userplan_version,
            "project_context": self.project_context,
            "llm_provider": self.llm_provider,
        }
        if self.from_step is not None:
            data["from_step"] = self.from_step
        if self.base_prompt is not None:
            data["base_prompt"] = self.base_prompt
        return data


@dataclass
class GenerateTestsRequest:
    """Request to generate failing acceptance tests from requirements."""

    objective: str
    userplan_id: str
    userplan_version: int
    project_context: dict[str, Any] = field(default_factory=dict)
    llm_provider: str = "anthropic"
    base_prompt: str | None = None
    intent: dict[str, Any] | None = None
    intent_enrichment: dict[str, Any] | None = None
    planning_resolution: dict[str, Any] | None = None
    correlation: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "GenerateTestsRequest":
        """Create from ServerAction payload."""
        userplan_id = payload.get("userplan_id")
        if not userplan_id:
            raise ValueError("userplan_id is required for test generation")
        userplan_version = payload.get("userplan_version")
        if userplan_version is None:
            raise ValueError("userplan_version is required for test generation")
        return cls(
            objective=payload.get("objective", ""),
            userplan_id=userplan_id,
            userplan_version=int(userplan_version),
            project_context=payload.get("project_context", {}),
            llm_provider=payload.get("llm_provider", "anthropic"),
            base_prompt=payload.get("base_prompt"),
            intent=(
                payload.get("intent")
                if isinstance(payload.get("intent"), dict)
                else None
            ),
            intent_enrichment=(
                payload.get("intent_enrichment")
                if isinstance(payload.get("intent_enrichment"), dict)
                else None
            ),
            planning_resolution=(
                payload.get("planning_resolution")
                if isinstance(payload.get("planning_resolution"), dict)
                else None
            ),
            correlation=_coerce_optional_dict(payload.get("correlation")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        data: dict[str, Any] = {
            "objective": self.objective,
            "userplan_id": self.userplan_id,
            "userplan_version": self.userplan_version,
            "project_context": self.project_context,
            "llm_provider": self.llm_provider,
        }
        if self.base_prompt is not None:
            data["base_prompt"] = self.base_prompt
        if self.intent is not None:
            data["intent"] = self.intent
        if self.intent_enrichment is not None:
            data["intent_enrichment"] = self.intent_enrichment
        if self.planning_resolution is not None:
            data["planning_resolution"] = self.planning_resolution
        if self.correlation:
            data["correlation"] = self.correlation
        return data


@dataclass
class SpikeRequest:
    """Request to run the isolated spike phase inside the orchestration loop.

    Sent by the server either after INTENT validation or directly from session
    start when the no-INTENT fallback still requires spike-first execution.

    Attributes:
        objective: Raw objective fallback for the spike prompt
        project_context: Optional project context for prompt/debug handoff
        llm_provider: Optional provider metadata for observability
        intent: Optional enriched structured intent document
        intent_enrichment: Optional lightweight enrichment metadata
        planning_resolution: Optional reusable sizing/routing payload from INTENT
        resume_after_spike: Nested DERIVE payload used when the spike routes to
            ``full_derive``
        spike_policy: Optional resolved spike sequencing policy from session start
    """

    objective: str
    project_context: dict[str, Any] = field(default_factory=dict)
    llm_provider: str = "anthropic"
    intent: dict[str, Any] | None = None
    intent_enrichment: dict[str, Any] | None = None
    planning_resolution: dict[str, Any] | None = None
    resume_after_spike: dict[str, Any] | None = None
    spike_policy: dict[str, Any] | None = None
    failing_test_manifest: dict[str, Any] | None = None
    remediation_request: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SpikeRequest":
        """Create from ServerAction payload."""
        return cls(
            objective=str(payload.get("objective", "")),
            project_context=(
                dict(payload.get("project_context", {}))
                if isinstance(payload.get("project_context"), dict)
                else {}
            ),
            llm_provider=str(payload.get("llm_provider", "anthropic") or "anthropic"),
            intent=(
                payload.get("intent")
                if isinstance(payload.get("intent"), dict)
                else None
            ),
            intent_enrichment=(
                payload.get("intent_enrichment")
                if isinstance(payload.get("intent_enrichment"), dict)
                else None
            ),
            planning_resolution=(
                payload.get("planning_resolution")
                if isinstance(payload.get("planning_resolution"), dict)
                else None
            ),
            resume_after_spike=(
                payload.get("resume_after_spike")
                if isinstance(payload.get("resume_after_spike"), dict)
                else None
            ),
            spike_policy=(
                payload.get("spike_policy")
                if isinstance(payload.get("spike_policy"), dict)
                else None
            ),
            failing_test_manifest=(
                payload.get("failing_test_manifest")
                if isinstance(payload.get("failing_test_manifest"), dict)
                else None
            ),
            remediation_request=(
                payload.get("remediation_request")
                if isinstance(payload.get("remediation_request"), dict)
                else None
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        data: dict[str, Any] = {
            "objective": self.objective,
            "project_context": self.project_context,
            "llm_provider": self.llm_provider,
        }
        if self.intent is not None:
            data["intent"] = self.intent
        if self.intent_enrichment is not None:
            data["intent_enrichment"] = self.intent_enrichment
        if self.planning_resolution is not None:
            data["planning_resolution"] = self.planning_resolution
        if self.resume_after_spike is not None:
            data["resume_after_spike"] = self.resume_after_spike
        if self.spike_policy is not None:
            data["spike_policy"] = self.spike_policy
        if self.failing_test_manifest is not None:
            data["failing_test_manifest"] = self.failing_test_manifest
        if self.remediation_request is not None:
            data["remediation_request"] = self.remediation_request
        return data


@dataclass
class ExamineRequest:
    """Request to examine the current plan.

    Sent by server after DerivedPlan or RevisedPlan to instruct
    client to examine the plan using LLM.

    Attributes:
        plan_version_id: Version ID of plan to examine
        plan_items: Plan items to examine
        all_plan_item_ids: Optional full plan item ID list for cross-batch dependency checks
        thinking_required: Whether extended thinking is required
        reasoning_level: Reasoning level (standard, high, max)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        iteration: Current refinement cycle number (None if not in a cycle)
        max_iterations: Maximum refinement iterations allowed (None if unbounded)
        batches: All examination batches for parallel dispatch (each batch has
            plan_items and all_plan_item_ids). Empty list for legacy single-batch flow.
    """

    plan_version_id: str
    plan_items: list[dict[str, Any]]
    thinking_required: bool = True
    reasoning_level: str = "standard"
    base_prompt: str | None = None
    iteration: int | None = None
    max_iterations: int | None = None
    all_plan_item_ids: list[str] | None = None
    batches: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ExamineRequest":
        """Create from ServerAction payload."""
        raw_all_plan_item_ids = payload.get("all_plan_item_ids")
        all_plan_item_ids = None
        if isinstance(raw_all_plan_item_ids, list):
            normalized_ids = [
                str(item_id).strip()
                for item_id in raw_all_plan_item_ids
                if str(item_id).strip()
            ]
            all_plan_item_ids = normalized_ids or None
        return cls(
            plan_version_id=payload.get("plan_version_id", ""),
            plan_items=payload.get("plan_items", []),
            thinking_required=payload.get("thinking_required", True),
            reasoning_level=payload.get("reasoning_level", "standard"),
            base_prompt=payload.get("base_prompt"),
            iteration=payload.get("iteration"),
            max_iterations=payload.get("max_iterations"),
            all_plan_item_ids=all_plan_item_ids,
            batches=payload.get("batches", []),
        )


@dataclass
class RevisionRequest:
    """Request to revise the plan based on issues.

    Sent by server after ExaminationReport when blocking issues found.

    Attributes:
        issues: All issues from examination
        blocking_issues: Issues that must be addressed
        current_plan_version_id: Current plan version ID
        focus_areas: Areas to focus revision on
        batch_index: Zero-based revision batch index for batched revise flows
        total_batches: Total revision batches in current revise flow
        batches_remaining: Number of remaining batches after current batch
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        proposed_defaults: Proposed defaults to unblock P1 issues (optional)
        userplan_id: Optional UserPlan ID for source_step_id fallbacks
        batches: All revision batches for parallel dispatch (each batch has
            issues, blocking_issues, focus_areas). Empty list for legacy single-batch flow.
        full_plan_items: Complete plan items used as merge base for client-side
            revision overlay in parallel dispatch mode.
    """

    issues: list[dict[str, Any]]
    blocking_issues: list[dict[str, Any]]
    current_plan_version_id: str = ""
    focus_areas: list[str] = field(default_factory=list)
    batch_index: int = 0
    total_batches: int = 0
    batches_remaining: int = 0
    base_prompt: str | None = None
    proposed_defaults: list[dict[str, Any]] | None = None
    userplan_id: str | None = None
    batches: list[dict[str, Any]] = field(default_factory=list)
    full_plan_items: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "RevisionRequest":
        """Create from ServerAction payload."""
        return cls(
            issues=payload.get("issues", []),
            blocking_issues=payload.get("blocking_issues", []),
            current_plan_version_id=payload.get("current_plan_version_id", ""),
            focus_areas=payload.get("focus_areas", []),
            batch_index=int(payload.get("batch_index", 0) or 0),
            total_batches=int(payload.get("total_batches", 0) or 0),
            batches_remaining=int(payload.get("batches_remaining", 0) or 0),
            base_prompt=payload.get("base_prompt"),
            proposed_defaults=payload.get("proposed_defaults"),
            userplan_id=payload.get("userplan_id"),
            batches=payload.get("batches", []),
            full_plan_items=payload.get("full_plan_items", []),
        )


@dataclass
class ExecutionBatchItem:
    """One sibling execution target inside an EXECUTE batch payload."""

    item_id: str
    execution_index: int
    execution_context: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionBatchItem":
        """Create from dictionary."""
        return cls(
            item_id=str(data.get("item_id", "")).strip(),
            execution_index=int(data.get("execution_index", 0) or 0),
            execution_context=_coerce_optional_dict(data.get("execution_context")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to API payload dictionary."""
        payload: dict[str, Any] = {
            "item_id": self.item_id,
            "execution_index": self.execution_index,
        }
        if self.execution_context is not None:
            payload["execution_context"] = self.execution_context
        return payload


@dataclass
class ExecutionBatchRequest:
    """Optional sibling-batch metadata for an EXECUTE action."""

    batch_id: str
    failure_policy: str = "all_settle"
    parallel_group: int | None = None
    topological_level: int | None = None
    items: list[ExecutionBatchItem] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionBatchRequest":
        """Create from dictionary."""
        return cls(
            batch_id=str(data.get("batch_id", "")).strip(),
            failure_policy=str(data.get("failure_policy", "all_settle") or "all_settle"),
            parallel_group=(
                int(data.get("parallel_group"))
                if data.get("parallel_group") is not None
                else None
            ),
            topological_level=(
                int(data.get("topological_level"))
                if data.get("topological_level") is not None
                else None
            ),
            items=[
                ExecutionBatchItem.from_dict(item)
                for item in data.get("items", [])
                if isinstance(item, dict)
            ],
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to API payload dictionary."""
        payload: dict[str, Any] = {
            "batch_id": self.batch_id,
            "failure_policy": self.failure_policy,
            "items": [item.to_dict() for item in self.items],
        }
        if self.parallel_group is not None:
            payload["parallel_group"] = self.parallel_group
        if self.topological_level is not None:
            payload["topological_level"] = self.topological_level
        return payload


@dataclass
class ExecutionRequest:
    """Request to execute a plan item.

    Sent by server when plan passes examination.

    Attributes:
        plan_items: All plan items
        execution_index: Index of item to execute
        current_item: The specific item to execute
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        execution_context: Server-supplied context for deduplication (Issue #6)
        execution_batch: Optional sibling-batch metadata for hybrid parallel execute
        spike_context: Optional spike-first routing payload
    """

    plan_items: list[dict[str, Any]]
    execution_index: int = 0
    current_item: dict[str, Any] | None = None
    base_prompt: str | None = None
    execution_context: dict[str, Any] | None = None
    execution_batch: ExecutionBatchRequest | None = None
    spike_context: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ExecutionRequest":
        """Create from ServerAction payload."""
        plan_items = payload.get("plan_items", [])
        execution_index = payload.get("execution_index", 0)
        batch_payload = payload.get("execution_batch")
        execution_batch = (
            ExecutionBatchRequest.from_dict(batch_payload)
            if isinstance(batch_payload, dict)
            else None
        )
        current_item = None
        if plan_items and not (0 <= execution_index < len(plan_items)):
            # Defensive fallback for partial plan payloads.
            execution_index = 0
        if plan_items and 0 <= execution_index < len(plan_items):
            current_item = plan_items[execution_index]
        return cls(
            plan_items=plan_items,
            execution_index=execution_index,
            current_item=current_item,
            base_prompt=payload.get("base_prompt"),
            execution_context=payload.get("execution_context"),
            execution_batch=execution_batch,
            spike_context=(
                payload.get("spike_context")
                if isinstance(payload.get("spike_context"), dict)
                else None
            ),
        )


@dataclass
class ReviewRequest:
    """Request to run review agents on executed item.

    Sent by server after ExecutionResult.

    Attributes:
        item_id: Plan item ID that was executed
        agents_to_run: Optional list of agent types to run; defaults to
            report-review compatible baseline when missing/None/empty
        agent_budgets: Timeout/weight budgets per agent
        format: Optional output format (e.g., text, json)
        fail_on: Optional fail-fast threshold (e.g., p1, p2)
        complexity: Optional complexity tier provided by the server (simple|medium|complex)
        tests_required: Whether coverage gaps should be treated as blocking
        review_cycle_id: Optional review cycle identifier for event correlation
        diagnostic: Optional review-routing diagnostic message from server
        execution_status: Optional execution status context from prior action
        changed_files: Optional execution-scoped file paths for focused review
        spike_context: Optional spike-first routing payload
    """

    item_id: str
    agents_to_run: list[str] | None = None
    agent_budgets: dict[str, dict[str, Any]] = field(default_factory=dict)
    format: str | None = None
    fail_on: str | None = None
    complexity: str | None = None
    tests_required: bool = False
    review_cycle_id: str | None = None
    diagnostic: str | None = None
    execution_status: str | None = None
    changed_files: list[str] | None = None
    spike_context: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ReviewRequest":
        """Create from ServerAction payload."""
        agents = payload.get("agents_to_run")
        if not agents:
            agents = payload.get("review_agents")

        agents_to_run = DEFAULT_REPORT_REVIEW_AGENT_TYPES.copy()
        if isinstance(agents, list) and agents:
            agents_to_run = agents

        complexity_value = payload.get("complexity")
        complexity = str(complexity_value) if complexity_value is not None else None
        return cls(
            item_id=payload.get("item_id", ""),
            agents_to_run=agents_to_run,
            agent_budgets=payload.get("agent_budgets", {}),
            format=payload.get("format"),
            fail_on=payload.get("fail_on"),
            complexity=complexity,
            tests_required=bool(payload.get("tests_required", False)),
            review_cycle_id=(
                str(payload.get("review_cycle_id"))
                if payload.get("review_cycle_id") is not None
                else None
            ),
            diagnostic=payload.get("diagnostic"),
            execution_status=(
                str(payload.get("execution_status"))
                if payload.get("execution_status") is not None
                else None
            ),
            changed_files=payload.get("changed_files"),
            spike_context=(
                payload.get("spike_context")
                if isinstance(payload.get("spike_context"), dict)
                else None
            ),
        )


@dataclass
class FixRequest:
    """Request to fix issues found during review.

    Sent by server after AgentReport when issues need fixing.

    Attributes:
        issues_to_fix: List of issues to fix (may be strings or dicts)
        execution_order: Order to fix issues (by ID)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        item_id: Plan item ID being fixed (ISSUE-SAAS-021)
        issue_details: Full issue dicts with priority info (FIX-PRIORITY-LOSS-001)
        issue_details may include test-gap metadata (issue_type, target_test_file,
        target_paths, test_name, arrange/act/assert) to guide test-focused fixes.
        fix_history: Optional summary of previous fix attempts
        fresh_fix: Whether this request is a guarded convergence fresh-fix pass
        refactor_mode: Whether this request permits architectural refactor scope
        fix_attempt: Current attempt number (1-indexed, 0 = not set)
        max_fix_attempts: Maximum fix attempts allowed
        item_context: Plan item metadata (title, description, acceptance_criteria)
        sibling_issues: Other blocking issues for cross-issue context awareness
    """

    issues_to_fix: list[dict[str, Any]]
    execution_order: list[str] = field(default_factory=list)
    base_prompt: str | None = None
    item_id: str = ""  # ISSUE-SAAS-021: Track item for fix-review loop
    issue_details: list[dict[str, Any]] = field(
        default_factory=list
    )  # FIX-PRIORITY-LOSS-001
    fix_history: str | None = None
    fresh_fix: bool = False
    refactor_mode: bool = False
    fix_attempt: int = 0  # Current attempt number (1-indexed, 0 = not set)
    max_fix_attempts: int = 2  # Maximum attempts allowed
    item_context: dict[str, Any] = field(default_factory=dict)  # Plan item metadata
    sibling_issues: list[dict[str, Any]] = field(
        default_factory=list
    )  # Other blocking issues for context
    failing_test_manifest: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "FixRequest":
        """Create from ServerAction payload."""
        return cls(
            issues_to_fix=payload.get("issues_to_fix", []),
            execution_order=payload.get("execution_order", []),
            base_prompt=payload.get("base_prompt"),
            item_id=payload.get("item_id", ""),  # ISSUE-SAAS-021
            issue_details=payload.get("issue_details", []),  # FIX-PRIORITY-LOSS-001
            fix_history=payload.get("fix_history"),
            fresh_fix=bool(payload.get("fresh_fix", False)),
            refactor_mode=bool(payload.get("refactor_mode", False)),
            fix_attempt=int(payload.get("fix_attempt", 0) or 0),
            max_fix_attempts=int(payload.get("max_fix_attempts", 2) or 2),
            item_context=payload.get("item_context", {}),
            sibling_issues=payload.get("sibling_issues", []),
            failing_test_manifest=(
                payload.get("failing_test_manifest")
                if isinstance(payload.get("failing_test_manifest"), dict)
                else None
            ),
        )


# =============================================================================
# Validator Messages (FEAT-SENSECHECK-PIPELINE-001)
# =============================================================================


@dataclass
class ValidatorRequest:
    """Request to execute a validator on the client.

    Sent by the server to request a validator run against a subject payload.

    Attributes:
        stage: Validation stage (intent, plan, review_filter, code)
        subject_type: Type of subject payload (intent, plan_items, agent_reports, code_delta)
        subject_payload: Payload to validate
        prompt_id: Prompt identifier for provenance
        prompt_version: Prompt version for provenance
        compiled_prompt: Fully compiled prompt text (server-owned)
        timeout_s: Timeout in seconds for validator execution
        config: Validator config (schema_validation, prompt_provenance, etc.)
    """

    stage: str
    subject_type: str
    subject_payload: dict[str, Any]
    prompt_id: str
    prompt_version: str
    compiled_prompt: str
    timeout_s: int
    config: dict[str, Any]

    @classmethod
    def from_payload(
        cls, payload: dict[str, Any], *, schema_validation: bool = True
    ) -> "ValidatorRequest":
        """Create from ServerAction payload with validation."""
        request = cls(
            stage=payload.get("stage", ""),
            subject_type=payload.get("subject_type", ""),
            subject_payload=payload.get("subject_payload", {}),
            prompt_id=payload.get("prompt_id", ""),
            prompt_version=payload.get("prompt_version", ""),
            compiled_prompt=payload.get("compiled_prompt", ""),
            timeout_s=payload.get("timeout_s", 30),
            config=payload.get("config", {}),
        )
        is_valid, error = validate_validator_request(
            request, schema_validation=schema_validation
        )
        if not is_valid:
            raise ValueError(f"ValidatorRequest validation failed: {error}")
        return request

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage": self.stage,
            "subject_type": self.subject_type,
            "subject_payload": self.subject_payload,
            "prompt_id": self.prompt_id,
            "prompt_version": self.prompt_version,
            "compiled_prompt": self.compiled_prompt,
            "timeout_s": self.timeout_s,
            "config": self.config,
        }


@dataclass
class ValidatorResult:
    """Result payload returned by a validator."""

    sound: bool
    issues: list[dict[str, Any]] = field(default_factory=list)
    constraints: list[str] = field(default_factory=list)
    decisions: list[dict[str, Any]] = field(default_factory=list)
    version: str = "v1"
    provenance: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "sound": self.sound,
            "issues": self.issues,
            "constraints": self.constraints,
            "decisions": self.decisions,
            "version": self.version,
            "provenance": self.provenance,
        }

    @classmethod
    def from_dict(
        cls, data: dict[str, Any], *, schema_validation: bool = True
    ) -> "ValidatorResult":
        """Create from dictionary with validation."""
        result = cls(
            sound=bool(data.get("sound", False)),
            issues=data.get("issues", []),
            constraints=data.get("constraints", []),
            decisions=data.get("decisions", []),
            version=data.get("version", "v1"),
            provenance=data.get("provenance", {}),
        )
        is_valid, error = validate_validator_result(
            result, schema_validation=schema_validation
        )
        if not is_valid:
            raise ValueError(f"ValidatorResult validation failed: {error}")
        return result


@dataclass
class EscalationFixerResult:
    """Result payload returned by the escalation-fixer validator."""

    repairable: bool
    route: str
    root_cause: str = ""
    summary: str = ""
    amend_plan: dict[str, Any] | None = None
    fix_code: dict[str, Any] | None = None
    reclassify_review: dict[str, Any] | None = None
    retry_stage: dict[str, Any] | None = None
    version: str = "v1"
    provenance: dict[str, Any] = field(default_factory=dict)
    stage: str = "escalation_fix"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        result: dict[str, Any] = {
            "stage": self.stage,
            "repairable": self.repairable,
            "route": self.route,
            "root_cause": self.root_cause,
            "summary": self.summary,
            "version": self.version,
            "provenance": self.provenance,
        }
        if self.amend_plan is not None:
            result["amend_plan"] = self.amend_plan
        if self.fix_code is not None:
            result["fix_code"] = self.fix_code
        if self.reclassify_review is not None:
            result["reclassify_review"] = self.reclassify_review
        if self.retry_stage is not None:
            result["retry_stage"] = self.retry_stage
        return result

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        *,
        schema_validation: bool = True,
    ) -> "EscalationFixerResult":
        """Create from dictionary with validation."""
        result = cls(
            stage=str(data.get("stage", "escalation_fix") or "escalation_fix"),
            repairable=bool(data.get("repairable", False)),
            route=str(data.get("route", "") or ""),
            root_cause=str(data.get("root_cause", "") or ""),
            summary=str(data.get("summary", "") or ""),
            amend_plan=_coerce_optional_dict(data.get("amend_plan"))
            if data.get("amend_plan") is not None
            else None,
            fix_code=_coerce_optional_dict(data.get("fix_code"))
            if data.get("fix_code") is not None
            else None,
            reclassify_review=_coerce_optional_dict(data.get("reclassify_review"))
            if data.get("reclassify_review") is not None
            else None,
            retry_stage=_coerce_optional_dict(data.get("retry_stage"))
            if data.get("retry_stage") is not None
            else None,
            version=str(data.get("version", "v1") or "v1"),
            provenance=_coerce_optional_dict(data.get("provenance")),
        )
        is_valid, error = validate_escalation_fixer_result(
            result, schema_validation=schema_validation
        )
        if not is_valid:
            raise ValueError(f"EscalationFixerResult validation failed: {error}")
        return result


@dataclass
class StoryPreflightResult:
    """Result payload returned by Story Pre-flight verification."""

    findings: list[dict[str, Any]] = field(default_factory=list)
    task_modifications: list[dict[str, Any]] = field(default_factory=list)
    sense_check: dict[str, Any] | None = None
    resolved_findings: list[dict[str, Any]] = field(default_factory=list)
    loop_metadata: dict[str, Any] = field(default_factory=dict)
    disposition: str = "PROCEED"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "findings": self.findings,
            "task_modifications": self.task_modifications,
            "sense_check": self.sense_check,
            "resolved_findings": self.resolved_findings,
            "loop_metadata": self.loop_metadata,
            "disposition": self.disposition,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StoryPreflightResult":
        """Create from dictionary with validation."""
        disposition = str(data.get("disposition", "PROCEED")).upper()
        allowed = {"PROCEED", "REVISE", "ESCALATE"}
        if disposition not in allowed:
            msg = (
                f"StoryPreflightResult disposition must be one of "
                f"{sorted(allowed)}, got {disposition!r}"
            )
            raise ValueError(msg)
        return cls(
            findings=data.get("findings", []),
            task_modifications=data.get("task_modifications", []),
            sense_check=data.get("sense_check"),
            resolved_findings=data.get("resolved_findings", []),
            loop_metadata=data.get("loop_metadata", {}),
            disposition=disposition,
        )


@dataclass
class StoryPreflightRequest:
    """Request to run story pre-flight verification and refinement.

    Sent by the server before entering execution for a story boundary.

    Attributes:
        story_item: Story-level item payload under evaluation
        plan_items: Full execution-plan items for context and dependency checks
        exploration_context: Optional exploration artifacts used by preflight checks
    """

    story_item: dict[str, Any] = field(default_factory=dict)
    plan_items: list[dict[str, Any]] = field(default_factory=list)
    exploration_context: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "StoryPreflightRequest":
        """Create from ServerAction payload."""
        raw_story_item = payload.get("story_item")
        raw_plan_items = payload.get("plan_items")
        raw_exploration_context = payload.get("exploration_context")
        return cls(
            story_item=raw_story_item if isinstance(raw_story_item, dict) else {},
            plan_items=raw_plan_items if isinstance(raw_plan_items, list) else [],
            exploration_context=(
                raw_exploration_context
                if isinstance(raw_exploration_context, dict)
                else None
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        data: dict[str, Any] = {
            "story_item": self.story_item,
            "plan_items": self.plan_items,
        }
        if self.exploration_context is not None:
            data["exploration_context"] = self.exploration_context
        return data


# Validator infrastructure — extracted to protocol_validator.py.
# Re-exported here for backward compatibility during migration.
from .protocol_validator import (  # noqa: E402, F401
    ESCALATION_FIXER_FIX_CODE_VERIFICATION_SCOPES,
    ESCALATION_FIXER_ROUTES,
    VALIDATOR_STAGES,
    VALIDATOR_SUBJECT_TYPES,
    validate_escalation_fixer_result,
    validate_validator_request,
    validate_validator_result,
)


@dataclass
class EscalationNotice:
    """Notice that session requires human intervention.

    Sent by server when max iterations reached or oscillation detected.

    Attributes:
        escalation_id: Unique escalation identifier
        reason: Reason for escalation
        reason_text: Human-readable escalation detail
        reason_code: Machine-readable escalation detail code
        invariant_errors: Structured invariant/integrity errors
        repair_attempt_history: Auto-repair attempt diagnostics
        blocking_issues: Issues causing escalation
        escalation_context: Structured phase-specific blocker context
        iteration_history: Summary of iterations
        options: Available user options
        convergence_diagnostic: Optional convergence guard context for user display
        metadata: ServerAction metadata attached to the escalation action
        extra: Escalation payload fields outside the canonical schema
    """

    escalation_id: str
    reason: EscalationReason
    reason_text: str = ""
    reason_code: str = ""
    invariant_errors: list[str] = field(default_factory=list)
    repair_attempt_history: list[dict[str, Any]] = field(default_factory=list)
    blocking_issues: list[dict[str, Any]] = field(default_factory=list)
    escalation_context: dict[str, Any] = field(default_factory=dict)
    iteration_history: list[dict[str, Any]] = field(default_factory=list)
    options: list[dict[str, Any]] = field(default_factory=list)
    convergence_diagnostic: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_payload(
        cls,
        payload: dict[str, Any],
        metadata: dict[str, Any] | None = None,
    ) -> "EscalationNotice":
        """Create from ServerAction payload.

        Uses safe enum parsing for forward compatibility - unknown escalation
        reasons from newer servers will be mapped to EscalationReason.UNKNOWN.
        """
        raw_convergence_diagnostic = payload.get("convergence_diagnostic", {})
        raw_escalation_context = payload.get("escalation_context", {})
        raw_invariant_errors = payload.get("invariant_errors", [])
        raw_repair_attempt_history = payload.get("repair_attempt_history", [])
        escalation_context: dict[str, Any] = {}
        if isinstance(raw_escalation_context, dict):
            escalation_context.update(raw_escalation_context)
        # Backward compatibility: older payloads may attach blocker context at top-level.
        for legacy_key in (
            "blocking_failures",
            "non_blocking_failures",
            "completed_prereqs",
            "failed_prereqs",
            "status",
        ):
            if legacy_key not in escalation_context and legacy_key in payload:
                escalation_context[legacy_key] = payload.get(legacy_key)
        known_keys = {
            "escalation_id",
            "reason",
            "reason_text",
            "reason_code",
            "invariant_errors",
            "repair_attempt_history",
            "blocking_issues",
            "escalation_context",
            "iteration_history",
            "options",
            "convergence_diagnostic",
            "blocking_failures",
            "non_blocking_failures",
            "completed_prereqs",
            "failed_prereqs",
            "status",
        }
        extra_payload = {
            key: value for key, value in payload.items() if key not in known_keys
        }
        return cls(
            escalation_id=payload.get("escalation_id", ""),
            reason=safe_enum_parse(
                EscalationReason,
                payload.get("reason"),
                EscalationReason.BLOCKED,
            ),
            reason_text=str(payload.get("reason_text", "") or ""),
            reason_code=str(payload.get("reason_code", "") or ""),
            invariant_errors=(
                raw_invariant_errors if isinstance(raw_invariant_errors, list) else []
            ),
            repair_attempt_history=(
                raw_repair_attempt_history
                if isinstance(raw_repair_attempt_history, list)
                else []
            ),
            blocking_issues=payload.get("blocking_issues", []),
            escalation_context=escalation_context,
            iteration_history=payload.get("iteration_history", []),
            options=payload.get("options", []),
            convergence_diagnostic=(
                raw_convergence_diagnostic
                if isinstance(raw_convergence_diagnostic, dict)
                else {}
            ),
            metadata=metadata if isinstance(metadata, dict) else {},
            extra=extra_payload,
        )


@dataclass
class CompletionNotice:
    """Notice that session has completed (success or escalation).

    Sent by server when all items executed/reviewed or session terminates.

    Attributes:
        session_summary: Summary of completed session
        items_completed: Number of items completed
        total_iterations: Total refinement iterations
        quality_score: Final quality score
        was_escalated: Whether session ended via escalation
        terminal_phase: Session phase when completion occurred
        plan_final: Final plan items (optional)
        objective: Original user objective
        work_summary: 2-3 bullet summary of work done
        duration_seconds: This invocation duration
        total_duration_seconds: Cumulative duration across invocations
        invocation_count: Number of run/resume calls
        files_created: List of files created
        files_modified: List of files modified
        git_branch: Current git branch
        git_commit_hash: Commit hash if committed
        termination_reason: Reason for non-success termination
        warnings: Any warnings to display
        spike_fallback_summary: Optional spike-first fallback summary for closeout
        epics_completed: Count of completed epics
        epics_total: Total epic count
        stories_completed: Count of completed stories
        stories_total: Total story count
        tasks_completed: Count of completed tasks
        tasks_total: Total task count

    Note:
        CompletionNotice is a distinct return type and does not carry an
        action field. Client code should handle it explicitly (e.g., via
        isinstance checks) rather than reading result.action.
    """

    session_summary: str = ""
    items_completed: int = 0
    total_iterations: int = 0
    quality_score: float = 0.0
    was_escalated: bool = False
    terminal_phase: str = ""
    plan_final: list[dict[str, Any]] = field(default_factory=list)
    # Enhanced closeout fields (FEAT-SESSION-CLOSEOUT-001)
    objective: str = ""
    work_summary: list[str] = field(default_factory=list)
    duration_seconds: float = 0.0
    total_duration_seconds: float = 0.0
    invocation_count: int = 1
    files_created: list[str] = field(default_factory=list)
    files_modified: list[str] = field(default_factory=list)
    git_branch: str = ""
    git_commit_hash: str = ""
    termination_reason: str = ""
    warnings: list[str] = field(default_factory=list)
    spike_fallback_summary: str = ""
    epics_completed: int = 0
    epics_total: int = 0
    stories_completed: int = 0
    stories_total: int = 0
    tasks_completed: int = 0
    tasks_total: int = 0

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "CompletionNotice":
        """Create from ServerAction payload."""
        summary = payload.get("session_summary", {})
        return cls(
            session_summary=summary.get("objective", ""),
            items_completed=summary.get("items_completed", 0),
            total_iterations=summary.get("total_iterations", 0),
            quality_score=summary.get("quality_score", 0.0),
            was_escalated=payload.get("was_escalated", False),
            terminal_phase=payload.get("terminal_phase", ""),
            plan_final=payload.get("plan_final", []),
            # Enhanced closeout fields
            objective=summary.get("objective", ""),
            work_summary=payload.get("work_summary", []),
            duration_seconds=payload.get("duration_seconds", 0.0),
            total_duration_seconds=payload.get("total_duration_seconds", 0.0),
            invocation_count=payload.get("invocation_count", 1),
            files_created=payload.get("files_created", []),
            files_modified=payload.get("files_modified", []),
            git_branch=payload.get("git_branch", ""),
            git_commit_hash=payload.get("git_commit_hash", ""),
            termination_reason=payload.get("termination_reason", ""),
            warnings=payload.get("warnings", []),
            spike_fallback_summary=payload.get("spike_fallback_summary", ""),
            epics_completed=payload.get("epics_completed", 0),
            epics_total=payload.get("epics_total", 0),
            stories_completed=payload.get("stories_completed", 0),
            stories_total=payload.get("stories_total", 0),
            tasks_completed=payload.get("tasks_completed", 0),
            tasks_total=payload.get("tasks_total", 0),
        )


__all__ = [
    # Utilities
    "safe_enum_parse",
    # Enums
    "ActionType",
    "SessionPhase",
    "SessionStatus",
    "Priority",
    "ExecutionStatus",
    "AgentType",
    "EscalationReason",
    "UserDecisionChoice",
    # Server -> Client
    "ServerAction",
    "EscalationEnvelope",
    "WorkflowLifecyclePayload",
    "LifecycleDecisionPayload",
    "LegacyPhaseNormalizationPayload",
    "DeriveRequest",
    "IntentRequest",
    "GenerateTestsRequest",
    "ExamineRequest",
    "RevisionRequest",
    "ExecutionBatchItem",
    "ExecutionBatchRequest",
    "ExecutionRequest",
    "ReviewRequest",
    "FixRequest",
    "ValidatorRequest",
    "ValidatorResult",
    "EscalationFixerResult",
    "StageRoutingSignal",
    "StageLoopSignal",
    "LoopResumePayload",
    "PendingManualPayload",
    "WaitPayload",
    "StageRunnerContext",
    "PipelineStageRequest",
    "PipelineStageResult",
    "EscalationNotice",
    "CompletionNotice",
    # Client -> Server
    "PlanUploadRequest",
    "PlanUploadResponse",
    "SessionStart",
    "ResumeRequest",
    "GenerateTestsReport",
    "DerivedPlan",
    "ExaminationReport",
    "RevisedPlan",
    "ExecutionBatchResultItem",
    "ExecutionResult",
    "AgentReport",
    "FixResult",
    "FixReport",
    "UserDecision",
    "EscalationDecision",
    "WorkflowCandidateEnvelope",
    "WorkflowMutationEvent",
    "WorkflowMutationResult",
    "WorkflowRevisionPayload",
    "WorkflowRevisionRef",
    "WorkflowSemanticView",
    # Resume
    "ResumeContext",
    # Progress (ISSUE-CLI-023)
    "ProgressEvent",
    # Validator schema validation
    "validate_validator_request",
    "validate_validator_result",
    "validate_escalation_fixer_result",
]
