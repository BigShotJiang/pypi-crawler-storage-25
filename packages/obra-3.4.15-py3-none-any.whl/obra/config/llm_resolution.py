"""LLM config resolution classes.

Extracted from obra/config/llm.py (REFACTOR-CONSOLIDATE-P24-001).
Contains LLMConfigResolver, RoleConfigResolver, and role-based
LLM configuration helpers.
"""

import logging
from typing import Any

from obra.config.llm_normalization import (
    DEFAULT_REASONING_LEVEL,
    DEFAULT_REASONING_SELECTION,
    _coerce_bool,
    _coerce_string_list,
)
from obra.config.provider_inference import infer_provider_from_model, validate_model
from obra.config.providers import (
    DEFAULT_AUTH_METHOD,
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    LLM_AUTH_METHODS,
    LLM_PROVIDERS,
)
from obra.config.reasoning_selection import _materialize_default_reasoning_level
from obra.exceptions import ConfigurationError
from obra.model_registry import REASONING_LEVELS, get_default_model, resolve_quality_tier

logger = logging.getLogger(__name__)

# Tier names used by resolution logic (same values as llm.TIER_NAMES).
_TIER_NAMES = ("fast", "medium", "high")


def _get_llm_config() -> dict[str, Any]:
    """Load and normalize LLM config.

    Uses a lazy import from obra.config.llm so that test patches applied to
    that module (e.g. ``patch("obra.config.llm.load_layered_config", ...)``)
    are respected.
    """
    import obra.config.llm as llm_mod

    return llm_mod.get_llm_config()


# ---------------------------------------------------------------------------
# Shared override helper
# ---------------------------------------------------------------------------


def _apply_overrides(
    resolved: dict[str, Any],
    override_provider: str | None,
    override_model: str | None,
    override_reasoning_level: str | None,
) -> None:
    """Apply session overrides to a resolved config dict (in-place).

    Shared between LLMConfigResolver and RoleConfigResolver.
    """
    if override_provider:
        if override_provider not in LLM_PROVIDERS:
            msg = f"Invalid provider: {override_provider}"
            raise ValueError(msg)
        resolved["provider"] = override_provider

    if override_model:
        resolved["model"] = validate_model(
            override_model, resolved.get("provider", DEFAULT_PROVIDER)
        )

    if override_reasoning_level:
        if override_reasoning_level not in (*REASONING_LEVELS, DEFAULT_REASONING_SELECTION):
            msg = (
                f"Invalid reasoning level: {override_reasoning_level}. "
                f"Valid: {', '.join([*REASONING_LEVELS, DEFAULT_REASONING_SELECTION])}"
            )
            raise ValueError(msg)
        resolved["reasoning_level"] = override_reasoning_level


# ---------------------------------------------------------------------------
# Role-based LLM configuration helpers (moved from llm.py)
# ---------------------------------------------------------------------------

# Handler role names for role-based LLM configuration (ADR-061)
# Canonical pre-planning keys use the "enrichment_*" prefix. Legacy
# "scaffolded_*" aliases are accepted via _ROLE_ALIASES.
HANDLER_ROLES = (
    "derive",
    "examine",
    "revise",
    "execute",
    "fix",
    "review",
    "json_conversion",
    "validator",
    "enrichment_assumptions",
    "enrichment_analogues",
    "enrichment_brief",
)

_ROLE_ALIASES: dict[str, str] = {
    "scaffolded_assumptions": "enrichment_assumptions",
    "scaffolded_analogues": "enrichment_analogues",
    "scaffolded_brief": "enrichment_brief",
}

# Default role-to-profile mappings when llm.roles is not configured
# Planning roles use orchestrator, execution roles use implementation
DEFAULT_ROLE_MAPPINGS: dict[str, str] = {
    # Handler actions
    "derive": "orchestrator",
    "examine": "orchestrator",
    "revise": "orchestrator",
    "execute": "implementation",
    "fix": "implementation",
    "review": "implementation",
    "json_conversion": "orchestrator",
    "validator": "implementation",
    # Intent enrichment stages (canonical keys)
    "enrichment_assumptions": "orchestrator",
    "enrichment_analogues": "orchestrator",
    "enrichment_brief": "orchestrator",
}


def _normalize_role_key(role: str) -> str:
    """Normalize role/action keys, supporting legacy aliases."""
    role_key = role.strip().lower()
    return _ROLE_ALIASES.get(role_key, role_key)


def _get_role_entry(roles: dict[str, Any], role: str) -> Any:
    """Return role config entry, checking canonical and legacy aliases."""
    if role in roles:
        return roles.get(role)
    for legacy_key, canonical_key in _ROLE_ALIASES.items():
        if canonical_key == role and legacy_key in roles:
            return roles.get(legacy_key)
    return None


def _resolve_action_profile(action: str) -> str:
    """Resolve action to orchestration profile role for tier-based routing."""
    action_key = _normalize_role_key(action)
    default_profile = DEFAULT_ROLE_MAPPINGS.get(action_key, "implementation")
    if default_profile not in ("orchestrator", "implementation"):
        default_profile = "implementation"

    llm_config = _get_llm_config()
    roles = llm_config.get("roles", {})
    profiles = llm_config.get("profiles", {})
    role_entry = _get_role_entry(roles, action_key)

    if isinstance(role_entry, str):
        if role_entry in ("orchestrator", "implementation"):
            return role_entry
        if role_entry in profiles:
            return default_profile
    elif isinstance(role_entry, dict):
        profile_name = role_entry.get("profile")
        if isinstance(profile_name, str) and profile_name in ("orchestrator", "implementation"):
            return profile_name
        if isinstance(profile_name, str) and profile_name in profiles:
            return default_profile

    return default_profile


def resolve_action_llm_config(
    action: str,
    *,
    model_tier: str | None = None,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_auth_method: str | None = None,
    override_reasoning_level: str | None = None,
) -> dict[str, Any]:
    """Canonical operation resolver: action -> role -> tier/model config.

    Args:
        action: Action/handler key (derive, examine, revise, execute, fix, review, ...)
        model_tier: Optional fast/medium/high tier selector for the action.
            If omitted, resolves action profile config directly.
        override_provider: Optional provider override.
        override_model: Optional model override.
        override_auth_method: Optional auth method override (tier path only).
        override_reasoning_level: Optional thinking level override.

    Returns:
        Resolved LLM config dictionary.
    """
    action_key = _normalize_role_key(action)
    return RoleConfigResolver().resolve(
        action_key,
        requested_tier=model_tier,
        override_provider=override_provider,
        override_model=override_model,
        override_auth_method=override_auth_method,
        override_reasoning_level=override_reasoning_level,
    )


# ---------------------------------------------------------------------------
# LLMConfigResolver
# ---------------------------------------------------------------------------


class LLMConfigResolver:
    """Resolves LLM configuration for orchestrator/implementation roles.

    Encapsulates the cascading provider/model/override resolution previously
    in the ``resolve_llm_config`` god-function.
    """

    def __init__(self) -> None:
        """Load both normalized and raw config sources.

        Routes through obra.config.llm so test patches are respected.
        """
        import obra.config.llm as llm_mod

        self._llm_mod = llm_mod
        self._llm_config = llm_mod.get_llm_config()
        raw_config, _, _ = llm_mod.load_layered_config()
        self._raw_llm = llm_mod.load_llm_section(raw_config)

    # -- public API ----------------------------------------------------------

    def resolve(
        self,
        role: str,
        override_provider: str | None = None,
        override_model: str | None = None,
        override_auth_method: str | None = None,
        override_reasoning_level: str | None = None,
        override_skip_git_check: bool | None = None,
        override_auto_init_git: bool | None = None,
    ) -> dict[str, Any]:
        """Resolve LLM configuration for a role with optional overrides.

        Resolution order (highest to lowest priority):
        1. Session overrides (passed as arguments, e.g., CLI flags)
        2. Layered config (user, project, session)
        3. Defaults (anthropic, oauth, default, medium)

        Args:
            role: "orchestrator" or "implementation"
            override_provider: Optional provider override (session-only)
            override_model: Optional model override (session-only)
            override_auth_method: Optional auth method override (session-only)
            override_reasoning_level: Optional thinking level override (session-only)
            override_skip_git_check: Optional git skip check override (CLI flag)
            override_auto_init_git: Optional git auto init override (CLI flag)

        Returns:
            Resolved config dict with provider, auth_method, model, reasoning_level keys
            and optional parse retry controls.
        """
        if role not in ("orchestrator", "implementation"):
            msg = f"Invalid role: {role}"
            raise ValueError(msg)

        role_config = self._llm_config.get(role, {})
        git_config, codex_config = self._load_config_sections()
        approval_mode, bypass_sandbox, enable_features, disable_features = (
            self._validate_codex_settings(codex_config)
        )
        skip_check = self._resolve_skip_check(git_config, codex_config)
        effective_provider = self._resolve_provider(role_config)
        effective_model = self._resolve_model(role_config, effective_provider, role)

        resolved = {
            "provider": effective_provider,
            "auth_method": role_config.get("auth_method", DEFAULT_AUTH_METHOD),
            "model": effective_model,
            "reasoning_level": role_config.get("reasoning_level", DEFAULT_REASONING_LEVEL),
            "parse_retry_enabled": role_config.get("parse_retry_enabled", True),
            "parse_retry_providers": role_config.get("parse_retry_providers"),
            "parse_retry_models": role_config.get("parse_retry_models"),
            "git": {
                "skip_check": skip_check,
                "auto_init": git_config.get("auto_init", False),
            },
            "codex": {
                "approval_mode": approval_mode,
                "bypass_sandbox": bypass_sandbox,
                "enable_features": enable_features,
                "disable_features": disable_features,
            },
        }

        # Apply overrides shared with RoleConfigResolver
        _apply_overrides(resolved, override_provider, override_model, override_reasoning_level)

        # Auth method override (LLMConfigResolver-specific)
        if override_auth_method:
            if override_auth_method not in LLM_AUTH_METHODS:
                msg = f"Invalid auth method: {override_auth_method}"
                raise ValueError(msg)
            resolved["auth_method"] = override_auth_method

        resolved["reasoning_level"] = _materialize_default_reasoning_level(
            resolved["provider"],
            resolved["model"],
            resolved.get("reasoning_level"),
            role=role,
            tier="medium",
        )

        # Apply git overrides (CLI flags override config)
        if override_skip_git_check is not None:
            resolved["git"]["skip_check"] = override_skip_git_check
            logger.debug(f"Git skip_check overridden by CLI flag: {override_skip_git_check}")

        if override_auto_init_git is not None:
            resolved["git"]["auto_init"] = override_auto_init_git
            logger.debug(f"Git auto_init overridden by CLI flag: {override_auto_init_git}")

        self._apply_provider_rules(resolved)
        return resolved

    # -- private helpers -----------------------------------------------------

    def _load_config_sections(self) -> tuple[dict[str, Any], dict[str, Any]]:
        """Extract git and codex config dicts from raw LLM section."""
        raw_llm = self._raw_llm
        git_config = raw_llm.get("git", {}) if raw_llm else {}
        codex_config = raw_llm.get("codex", {}) if raw_llm else {}
        return git_config, codex_config

    def _validate_codex_settings(
        self, codex_config: dict[str, Any]
    ) -> tuple[str | None, bool, list[str], list[str]]:
        """Validate codex approval_mode, bypass_sandbox, and feature lists.

        Returns:
            (approval_mode, bypass_sandbox, enable_features, disable_features)
        """
        approval_mode: str | None = None
        if isinstance(codex_config, dict):
            raw_approval = codex_config.get("approval_mode")
            if isinstance(raw_approval, str) and raw_approval.strip():
                approval_value = raw_approval.strip()
                if approval_value in {"suggest", "auto-edit", "full-auto"}:
                    approval_mode = approval_value
                else:
                    logger.warning(
                        "Ignoring invalid llm.codex.approval_mode '%s'. "
                        "Expected: suggest, auto-edit, full-auto.",
                        approval_value,
                    )

        bypass_sandbox = False
        if isinstance(codex_config, dict):
            bypass_sandbox = _coerce_bool(codex_config.get("bypass_sandbox", False), False)

        enable_features: list[str] = []
        disable_features: list[str] = []
        if isinstance(codex_config, dict):
            enable_features = _coerce_string_list(
                codex_config.get("enable_features"),
                "llm.codex.enable_features",
            )
            disable_features = _coerce_string_list(
                codex_config.get("disable_features"),
                "llm.codex.disable_features",
            )

        conflicting_features = set(enable_features) & set(disable_features)
        if conflicting_features:
            msg = (
                "Invalid Codex feature configuration: the same feature cannot appear in both "
                "llm.codex.enable_features and llm.codex.disable_features. "
                f"Conflicts: {', '.join(sorted(conflicting_features))}"
            )
            raise ConfigurationError(
                msg,
                "Remove overlapping feature names from one list.",
            )

        return approval_mode, bypass_sandbox, enable_features, disable_features

    def _resolve_skip_check(self, git_config: dict[str, Any], codex_config: dict[str, Any]) -> bool:
        """Resolve git skip_check with backward compatibility."""
        raw_llm = self._raw_llm
        skip_check = git_config.get("skip_check")
        if skip_check is None:
            # Check old config path: llm.codex.skip_git_check (GIT-HARD-001)
            old_codex_config = raw_llm.get("codex", {}) if raw_llm else {}
            old_skip_check = old_codex_config.get("skip_git_check")
            if old_skip_check is not None:
                skip_check = old_skip_check
                from obra.messages import get_message

                logger.warning(
                    get_message(
                        "warning.deprecation.config_key",
                        old="llm.codex.skip_git_check",
                        new="llm.git.skip_check",
                    )
                )
            else:
                skip_check = False
        else:
            skip_check = bool(skip_check)
        return skip_check

    def _resolve_provider(self, role_config: dict[str, Any]) -> str:
        """Resolve provider with 3-level cascade (top → role → tier)."""
        raw_llm = self._raw_llm
        raw_top_provider = raw_llm.get("provider") if raw_llm else None
        top_level_provider = self._llm_config.get("provider", "per-role")
        if not raw_top_provider:
            top_level_provider = "per-role"
        role_level_provider = role_config.get("provider", DEFAULT_PROVIDER)

        if top_level_provider not in ("per-role", "per-tier"):
            return top_level_provider
        elif role_level_provider not in ("per-role", "per-tier"):
            return role_level_provider
        else:
            tier_config = role_config.get("tiers", {})
            tier_entry = tier_config.get("medium", {})
            if isinstance(tier_entry, dict) and "provider" in tier_entry:
                return tier_entry["provider"]
            elif isinstance(tier_entry, str):
                inferred = infer_provider_from_model(tier_entry)
                return inferred if inferred else DEFAULT_PROVIDER
            else:
                return DEFAULT_PROVIDER

    def _resolve_model(
        self, role_config: dict[str, Any], effective_provider: str, role: str
    ) -> str:
        """Resolve model with 3-level cascade (top → role → tier)."""
        raw_llm = self._raw_llm
        _model_passthrough = ("per-tier", "per-role", "default")
        raw_top_model = raw_llm.get("model") if raw_llm else None
        top_level_model = self._llm_config.get("model", "per-tier")
        if not raw_top_model:
            top_level_model = "per-tier"
        role_level_model = role_config.get("model", "per-tier")

        provider_defaults = self._llm_mod.PROVIDER_TIER_DEFAULTS.get(effective_provider, {})

        if top_level_model not in _model_passthrough:
            return top_level_model
        elif role_level_model not in _model_passthrough:
            return role_level_model
        elif top_level_model == "default" or role_level_model == "default":
            return get_default_model(effective_provider) or DEFAULT_MODEL
        else:
            tier_config = role_config.get("tiers", {})
            tier_entry = tier_config.get("medium")
            if tier_entry and tier_entry not in _model_passthrough:
                if isinstance(tier_entry, str):
                    return tier_entry
                elif isinstance(tier_entry, dict):
                    tier_model = tier_entry.get("model", DEFAULT_MODEL)
                    if tier_model not in _model_passthrough:
                        return tier_model
                    else:
                        role_default = self._llm_mod.get_role_tier_default(
                            effective_provider, role, "medium"
                        )
                        return (
                            role_default
                            if role_default and role_default != "default"
                            else provider_defaults.get("medium", DEFAULT_MODEL)
                        )
                else:
                    return DEFAULT_MODEL
            else:
                role_default = self._llm_mod.get_role_tier_default(
                    effective_provider, role, "medium"
                )
                if role_default and role_default != "default":
                    return role_default
                else:
                    return provider_defaults.get("medium", DEFAULT_MODEL)

    @staticmethod
    def _apply_provider_rules(resolved: dict[str, Any]) -> None:
        """Handle OpenAI/Ollama special-case overrides."""
        if resolved["provider"] in ("openai", "ollama"):
            provider_label = "OpenAI" if resolved["provider"] == "openai" else "Ollama"
            if (
                resolved["git"]["skip_check"] is not True
                or resolved["codex"]["approval_mode"] != "full-auto"
                or resolved["codex"]["bypass_sandbox"] is not True
            ):
                logger.info(
                    "%s provider selected; forcing git.skip_check, codex.approval_mode, "
                    "and codex.bypass_sandbox to safe defaults for Codex CLI.",
                    provider_label,
                )
            resolved["git"]["skip_check"] = True
            resolved["codex"]["approval_mode"] = "full-auto"
            resolved["codex"]["bypass_sandbox"] = True


# ---------------------------------------------------------------------------
# RoleConfigResolver
# ---------------------------------------------------------------------------


class RoleConfigResolver:
    """Resolves LLM config for handler roles (derive, examine, execute, etc.).

    Encapsulates the ``resolve_role_llm_config`` function with dispatch-on-type
    branches factored into private methods.
    """

    def __init__(self) -> None:
        """Load normalized config for role resolution."""
        self._llm_config = _get_llm_config()

    # -- public API ----------------------------------------------------------

    def resolve(
        self,
        role: str,
        requested_tier: str | None = None,
        override_provider: str | None = None,
        override_model: str | None = None,
        override_auth_method: str | None = None,
        override_reasoning_level: str | None = None,
    ) -> dict[str, Any]:
        """Resolve LLM config for a handler role.

        Resolution order:
        1. llm.roles.<role> - explicit role configuration
        2. llm.profiles.<profile> - if role references a profile
        3. Default mapping (derive->orchestrator, execute->implementation)
        4. Top-level llm.* settings as final fallback

        Args:
            role: Handler role name (derive, examine, revise, execute, fix, review)
            override_provider: Optional provider override (session-only)
            override_model: Optional model override (session-only)
            override_reasoning_level: Optional thinking level override (session-only)

        Returns:
            Resolved config dict with provider, auth_method, model, reasoning_level keys

        See:
            ADR-069: Role-Based LLM Configuration
        """
        role_key = _normalize_role_key(role)

        if requested_tier is not None and requested_tier not in _TIER_NAMES:
            msg = f"Invalid tier '{requested_tier}' for role '{role_key}'"
            raise ValueError(msg)

        if role_key not in HANDLER_ROLES:
            logger.warning("Unknown handler role '%s', using implementation config", role)
            return LLMConfigResolver().resolve("implementation")

        profiles = self._llm_config.get("profiles", {})
        roles = self._llm_config.get("roles", {})
        role_entry = _get_role_entry(roles, role_key)

        if role_entry is None:
            resolved, context_role, context_tier = self._resolve_default_profile(
                role_key, profiles, requested_tier
            )
        elif isinstance(role_entry, str):
            resolved, context_role, context_tier = self._resolve_string_reference(
                role_key, role_entry, profiles, requested_tier
            )
        elif isinstance(role_entry, dict):
            resolved, context_role, context_tier = self._resolve_dict_config(
                role_key, role_entry, profiles, requested_tier
            )
        else:
            logger.warning(
                "Invalid role config type for '%s': %s, using default",
                role_key,
                type(role_entry).__name__,
            )
            resolved, context_role, context_tier = self._resolve_default_profile(
                role_key, profiles, requested_tier
            )

        # Apply session overrides (shared helper)
        _apply_overrides(resolved, override_provider, override_model, override_reasoning_level)
        if override_auth_method:
            if override_auth_method not in LLM_AUTH_METHODS:
                msg = f"Invalid auth method: {override_auth_method}"
                raise ValueError(msg)
            resolved["auth_method"] = override_auth_method

        # Materialize reasoning level using model's intrinsic quality tier
        if override_provider or override_model:
            context_tier = resolve_quality_tier(
                resolved.get("provider", DEFAULT_PROVIDER),
                resolved.get("model", ""),
            )
        resolved["reasoning_level"] = _materialize_default_reasoning_level(
            resolved.get("provider", DEFAULT_PROVIDER),
            resolved.get("model"),
            resolved.get("reasoning_level"),
            role=context_role,
            tier=context_tier,
        )

        logger.debug(
            "Resolved role '%s' config: provider=%s, model=%s, reasoning=%s",
            role_key,
            resolved.get("provider"),
            resolved.get("model"),
            resolved.get("reasoning_level"),
        )

        return resolved

    # -- private dispatch helpers --------------------------------------------

    def _resolve_default_profile(
        self,
        role_key: str,
        profiles: dict[str, Any],
        requested_tier: str | None,
    ) -> tuple[dict[str, Any], str, str]:
        """No explicit role config — use default mapping."""
        default_profile = DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation")
        return self._resolve_profile_reference(
            default_profile,
            profiles,
            requested_tier,
            fallback_role=default_profile,
        )

    def _resolve_string_reference(
        self,
        role_key: str,
        role_entry: str,
        profiles: dict[str, Any],
        requested_tier: str | None,
    ) -> tuple[dict[str, Any], str, str]:
        """Simple profile reference: ``derive: orchestrator``."""
        if role_entry in profiles or role_entry in ("orchestrator", "implementation"):
            return self._resolve_profile_reference(
                role_entry,
                profiles,
                requested_tier,
                fallback_role=DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation"),
            )

        logger.warning(
            "Role '%s' references unknown profile '%s', using default",
            role_key,
            role_entry,
        )
        return self._resolve_default_profile(role_key, profiles, requested_tier)

    def _resolve_dict_config(
        self,
        role_key: str,
        role_entry: dict[str, Any],
        profiles: dict[str, Any],
        requested_tier: str | None,
    ) -> tuple[dict[str, Any], str, str]:
        """Dict config — either profile-with-overrides or fully custom."""
        explicit_provider = role_entry.get("provider")
        explicit_model = role_entry.get("model")
        tier_value = role_entry.get("tier")
        selected_tier = requested_tier
        if isinstance(tier_value, str) and tier_value in _TIER_NAMES:
            selected_tier = tier_value

        if "profile" in role_entry:
            profile_name = role_entry["profile"]
            if profile_name in profiles or profile_name in ("orchestrator", "implementation"):
                context_role = (
                    profile_name
                    if profile_name in ("orchestrator", "implementation")
                    else DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation")
                )
                if explicit_provider is None and explicit_model is None and selected_tier is not None:
                    resolved, context_role, context_tier = self._resolve_profile_reference(
                        profile_name,
                        profiles,
                        selected_tier,
                        fallback_role=DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation"),
                    )
                else:
                    resolved, _, _ = self._resolve_profile_reference(
                        profile_name,
                        profiles,
                        None,
                        fallback_role=DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation"),
                    )
                    context_tier = selected_tier or resolve_quality_tier(
                        resolved.get("provider", DEFAULT_PROVIDER),
                        resolved.get("model", ""),
                    )
            else:
                logger.warning(
                    "Role '%s' references unknown profile '%s', using default",
                    role_key,
                    profile_name,
                )
                resolved, context_role, context_tier = self._resolve_default_profile(
                    role_key, profiles, selected_tier
                )
        else:
            # Fully custom config (no profile reference)
            default_profile = DEFAULT_ROLE_MAPPINGS.get(role_key, "implementation")
            resolved, context_role, context_tier = self._resolve_profile_reference(
                default_profile,
                profiles,
                None,
                fallback_role=default_profile,
            )
            if explicit_provider is None and explicit_model is None and selected_tier is not None:
                resolved, context_role, context_tier = self._resolve_profile_reference(
                    default_profile,
                    profiles,
                    selected_tier,
                    fallback_role=default_profile,
                )

        for key, value in role_entry.items():
            if key not in {"profile", "tier"} and value is not None:
                resolved[key] = value
        return resolved, context_role, context_tier

    def _resolve_profile_reference(
        self,
        profile_name: str,
        profiles: dict[str, Any],
        requested_tier: str | None,
        *,
        fallback_role: str,
    ) -> tuple[dict[str, Any], str, str]:
        """Resolve a named profile, optionally materialized through a tier."""
        import obra.config.llm as llm_mod

        if profile_name in ("orchestrator", "implementation"):
            context_role = profile_name
        else:
            context_role = fallback_role

        if requested_tier is not None:
            return (
                llm_mod.resolve_tier_config(
                    tier=requested_tier,
                    role=context_role,
                ),
                context_role,
                requested_tier,
            )

        if profile_name in profiles:
            resolved = profiles[profile_name].copy()
        else:
            resolved = LLMConfigResolver().resolve(profile_name)
        context_tier = resolve_quality_tier(
            resolved.get("provider", DEFAULT_PROVIDER),
            resolved.get("model", ""),
        )
        return resolved, context_role, context_tier
