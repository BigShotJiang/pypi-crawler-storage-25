"""Session-display helpers for CLI run/derive launch flow."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra import __version__
from obra.display.session_banner import _format_requested_permissive_mode_line
from obra.hybrid.llm_setup import (
    LLMConfigurator,
    merge_startup_llm_maps,
    resolve_startup_preflight,
    split_startup_llm_maps,
)
from obra.hybrid.runtime_bootstrap import SessionDisplayContext


@dataclass(frozen=True)
class CliPreflightState:
    """Resolved preflight and display inputs for CLI session startup."""

    session_display: SessionDisplayContext
    effective_map: dict[str, dict[str, str]]
    providers: tuple[str, ...]
    preflight_failures: tuple[str, ...]


@dataclass(frozen=True)
class SessionHeaderContext:
    """Rendered session-header values for the CLI startup banner."""

    project_display: str
    objective_preview: str
    config_summary: str
    run_mode: str
    git_status: str | None
    environment_label: str
    verbosity_label: str
    verbosity_flag: str
    permissive_status_line: str | None = None


def build_cli_preflight_state(*, working_dir: Path, verbose: int) -> CliPreflightState:
    """Build CLI preflight and typed session-display state."""
    configurator = LLMConfigurator(
        llm_config_getter=lambda: {"auth_method": "oauth"},
        server_review_agent_types=set(),
        working_dir=working_dir,
        build_error_context=lambda **_kwargs: None,
        session_display_getter=lambda: SessionDisplayContext(),
    )
    effective_map = configurator._build_effective_llm_map()
    auxiliary_map = configurator._build_auxiliary_llm_map()
    startup_outcome = resolve_startup_preflight(
        merge_startup_llm_maps(effective_map, auxiliary_map),
        working_dir=working_dir,
        auth_method="oauth",
    )
    effective_map, auxiliary_map = split_startup_llm_maps(
        startup_outcome.effective_map,
        pipeline_keys=set(effective_map),
        auxiliary_keys=set(auxiliary_map),
    )
    providers = tuple(
        sorted(
            {
                entry["provider"]
                for entry in merge_startup_llm_maps(effective_map, auxiliary_map).values()
            }
        )
    )
    return CliPreflightState(
        session_display=SessionDisplayContext(
            preflight_results=startup_outcome.preflight_results,
            preflight_failures=startup_outcome.preflight_failures,
            degraded_routes=startup_outcome.degraded_routes,
            header_already_rendered=True,
            verbose=verbose,
        ),
        effective_map=startup_outcome.effective_map,
        providers=providers,
        preflight_failures=startup_outcome.preflight_failures,
    )


def print_llm_preflight(cli: Any, preflight_state: CliPreflightState) -> None:
    """Print the CLI startup preflight summary."""
    cli.console.print()
    if not preflight_state.preflight_failures:
        provider_list = ", ".join(preflight_state.providers)
        cli.console.print(f"LLM preflight: {provider_list} ✓")
    else:
        cli.console.print("[red]LLM preflight failed:[/red]")
        for failure in preflight_state.preflight_failures:
            cli.console.print(f"  ✗ {failure}")
    for route in preflight_state.session_display.degraded_routes:
        cli.console.print(
            "  ! startup fallback: "
            f"{route.get('primary_provider')}/{route.get('primary_model')} -> "
            f"{route.get('active_provider')}/{route.get('active_model')} "
            f"({route.get('role')})"
        )
    cli.console.print()


def build_session_header_context(
    cli: Any,
    *,
    client: Any,
    project_id: str,
    objective_preview: str,
    work_dir: Path,
    verbose: int,
    requested_bypass_modes: list[str] | None = None,
) -> SessionHeaderContext:
    """Build the CLI session-header context shown before orchestration starts."""
    project_display = cli._resolve_project_display(client, project_id)
    try:
        from obra.config.loaders import load_layered_config

        _, origins, _ = load_layered_config(project_id=project_id, include_defaults=True)
        config_summary = cli._summarize_config_layers(origins)
    except Exception:
        config_summary = "unknown"

    verbosity_labels = {0: "quiet", 1: "progress", 2: "detail", 3: "debug"}
    if verbose == 0:
        verbosity_flag = "(-q)"
    elif verbose == 1:
        verbosity_flag = "(default)"
    else:
        verbosity_flag = f"(-{'v' * verbose})"

    return SessionHeaderContext(
        project_display=project_display,
        objective_preview=objective_preview,
        config_summary=config_summary,
        run_mode=cli._format_run_mode(),
        git_status=cli._format_git_status(work_dir),
        environment_label=cli._format_environment_label(),
        verbosity_label=verbosity_labels.get(verbose, f"level-{verbose}"),
        verbosity_flag=verbosity_flag,
        permissive_status_line=_format_requested_permissive_mode_line(requested_bypass_modes),
    )


def print_session_header(
    cli: Any,
    *,
    header: SessionHeaderContext,
    work_dir: Path,
    resume_session: str | None,
    effective_plan_id: str | None,
) -> None:
    """Render the CLI session header."""
    cli.console.print(f"[bold]Obra Run v{__version__}[/bold]", style="cyan")
    cli.console.print(f"Project: {header.project_display}")
    cli.console.print(f"Directory: {work_dir}")
    cli.console.print(f"Objective: {header.objective_preview}")
    if resume_session:
        cli.console.print(f"Resume: {resume_session}")
    if effective_plan_id:
        cli.console.print(f"Plan: {effective_plan_id}")
    cli.console.print(f"Run mode: {header.run_mode}")
    if header.permissive_status_line:
        cli.console.print(header.permissive_status_line)
    cli.console.print(f"Config: {header.config_summary}")
    if header.git_status:
        cli.console.print(f"Git: {header.git_status}")
    cli.console.print(f"Environment: {header.environment_label}")
    cli.console.print(
        "Auth: OAuth | Invocation: CLI | "
        f"Verbosity: {header.verbosity_label} {header.verbosity_flag}"
    )
