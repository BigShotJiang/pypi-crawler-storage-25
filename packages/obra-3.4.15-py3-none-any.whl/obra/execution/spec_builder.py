"""Orchestrator functions for the typed LLM pipeline.

This module provides three orchestrator functions that coordinate the
three-stage typed pipeline:

1. build_command_spec() - Stage 1: Extract high-level intent from config
2. build_provider_spec() - Stage 2: Dispatch to provider-specific builders
3. build_exec_spec() - Stage 3: Assemble subprocess.Popen-ready ExecSpec

These orchestrators are the entry points for the typed pipeline, replacing
the monolithic build_llm_args() function.

Related:
    - docs/design/briefs/ECL_PHASE2_TYPED_PIPELINE_BRIEF.md
    - obra/execution/pipeline_types.py (dataclass definitions)
    - obra/execution/provider_specs.py (provider-specific builders)
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from obra.hybrid.prompt_file import PromptFileManager

from obra.execution.os_compat import (
    EnvironmentProfile,
    build_popen_kwargs,
    build_subprocess_env,
)
from obra.execution.pipeline_types import CommandSpec, ExecSpec, ProviderSpec
from obra.execution.provider_specs import (
    build_anthropic_spec,
    build_default_spec,
    build_google_spec,
    build_ollama_spec,
    build_openai_spec,
)

logger = logging.getLogger(__name__)

# Shell command-line buffer limit for inline prompt delivery (protocol constant)
INLINE_PROMPT_MAX_CHARS = 4000


def _build_tool_restriction_prompt(allowed_tools: list[str]) -> str:
    tools = ", ".join(allowed_tools)
    return (
        f"CRITICAL: You MUST ONLY use these tools: {tools}. "
        "Do NOT use Write, Edit, or Bash under any circumstances."
    )


def _apply_tool_restrictions(
    cmd_spec: CommandSpec,
    provider_spec: ProviderSpec,
) -> ProviderSpec:
    """Apply tool restriction controls to a provider spec.

    Anthropic supports explicit `--allowedTools`. Other providers currently
    receive an explicit prompt-level restriction via provider metadata.
    """
    if cmd_spec.allowed_tools is None:
        return provider_spec

    allowed_tools = cmd_spec.allowed_tools
    provider = cmd_spec.provider.lower()

    if provider == "anthropic":
        return replace(
            provider_spec,
            argv=[*provider_spec.argv, "--allowedTools", ",".join(allowed_tools)],
        )

    restriction_prompt = _build_tool_restriction_prompt(allowed_tools)
    provider_meta = {
        **provider_spec.provider_meta,
        "tool_restriction_prompt": restriction_prompt,
    }
    return replace(provider_spec, provider_meta=provider_meta)


def build_command_spec(
    config: dict,
    mode: str,
    response_format: str,
    cwd: Path,
    streaming: bool,
    timeout_s: int,
    auth_method: str,
    allowed_tools: list[str] | None = None,
    output_schema: dict | None = None,
    mcp_servers: list[dict] | None = None,
    workspace_context: dict | None = None,
    run_id: str | None = None,
) -> CommandSpec:
    """Build CommandSpec from resolved LLM configuration.

    Extracts high-level intent (provider, model, thinking, mode, etc) from
    the config dict and produces a frozen CommandSpec. This is Stage 1 of
    the typed pipeline.

    Args:
        config: Resolved config dict with provider, model, reasoning_level, etc
        mode: Operation mode - "text" for derive/examine, "execute" for execute/fix
        response_format: Response format - "json" or "text"
        cwd: Working directory for LLM subprocess
        streaming: Whether to enable streaming output
        timeout_s: Timeout in seconds for LLM subprocess
        auth_method: Authentication method (e.g., "api_key")
        allowed_tools: Optional list of allowed tool names. None means no
            additional restriction.
        run_id: Optional run/session identifier for prompt-file ownership.

    Returns:
        Frozen CommandSpec with spec_id assigned for correlation
    """
    # Extract fields from config
    provider = config.get("provider", "anthropic")
    model = config.get("model", "default")
    reasoning_level = config.get("reasoning_level", "off")
    provider_reasoning_level = config.get("provider_reasoning_level")
    resolved_workspace_context = workspace_context
    if resolved_workspace_context is None:
        raw_workspace_context = config.get("workspace_context")
        if isinstance(raw_workspace_context, dict):
            resolved_workspace_context = raw_workspace_context

    # Extract Codex-specific config (if present)
    codex_config = config.get("codex")
    if isinstance(codex_config, dict):
        # Preserve codex config dict for OpenAI builder
        pass
    else:
        codex_config = None

    return CommandSpec(
        provider=provider,
        model=model,
        mode=mode,
        response_format=response_format,
        reasoning_level=reasoning_level,
        provider_reasoning_level=provider_reasoning_level,
        cwd=cwd,
        streaming=streaming,
        timeout_s=timeout_s,
        auth_method=auth_method,
        codex_config=codex_config,
        workspace_context=resolved_workspace_context,
        allowed_tools=allowed_tools,
        output_schema=output_schema,
        mcp_servers=mcp_servers,
        run_id=run_id,
        spec_id=str(uuid.uuid4()),  # Assign correlation ID
    )


def build_provider_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec by dispatching to provider-specific builder.

    This is Stage 2 of the typed pipeline. Dispatches to the appropriate
    provider-specific builder based on cmd_spec.provider.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile for platform-specific decisions

    Returns:
        ProviderSpec with provider-specific argv, env, and execution config

    Dispatch map:
        - anthropic -> build_anthropic_spec()
        - openai -> build_openai_spec()
        - google -> build_google_spec()
        - ollama -> build_ollama_spec()
        - fallback (unknown) -> build_default_spec()
    """
    # Provider dispatch map
    provider_builders = {
        "anthropic": build_anthropic_spec,
        "openai": build_openai_spec,
        "google": build_google_spec,
        "ollama": build_ollama_spec,
    }

    # Get provider-specific builder or fall back to default
    builder = provider_builders.get(cmd_spec.provider, build_default_spec)

    provider_spec = builder(cmd_spec, profile)
    return _apply_tool_restrictions(cmd_spec, provider_spec)


def build_exec_spec(
    provider_spec: ProviderSpec,
    profile: EnvironmentProfile,
    cmd_spec: CommandSpec,
    prompt: str,
    *,
    prompt_manager: "PromptFileManager | None" = None,
) -> ExecSpec:
    """Build ExecSpec from ProviderSpec, assembling subprocess.Popen-ready args.

    This is Stage 3 of the typed pipeline. Combines provider-specific argv
    with platform-specific environment, preexec_fn, and prompt delivery to
    produce a frozen ExecSpec ready for subprocess.Popen.

    Args:
        provider_spec: Provider-specific command construction from Stage 2
        profile: Resolved OS environment profile for encoding and preexec_fn
        cmd_spec: Original CommandSpec for cwd, timeout_s, streaming, auth_method
        prompt: Prompt text content for delivery (file or inline)
        prompt_manager: Optional PromptFileManager for file-based prompt delivery.
            If None and prompt_delivery is 'file', a default manager is created.

    Returns:
        Frozen ExecSpec with all fields resolved for subprocess.Popen

    Raises:
        NotImplementedError: If prompt_delivery is 'stdin' (deferred to Phase 3)
    """
    # 1. Build base command: [cli_executable, *argv]
    base_cmd = [provider_spec.cli_executable, *provider_spec.argv]

    # 2. Build subprocess environment with auth-aware API key handling
    env = build_subprocess_env(
        cmd_spec.auth_method,
        extra_env=provider_spec.env_overrides,
    )

    # 3. Resolve preexec_fn from platform profile
    popen_kwargs = build_popen_kwargs()
    preexec_fn = popen_kwargs.get("preexec_fn")

    # Inject prompt-level tool restrictions for providers that don't expose a
    # CLI-level allowlist flag.
    effective_prompt = prompt
    restriction_prompt = provider_spec.provider_meta.get("tool_restriction_prompt")
    if (
        isinstance(restriction_prompt, str)
        and restriction_prompt.strip()
        and cmd_spec.provider.lower() != "anthropic"
    ):
        effective_prompt = f"{restriction_prompt}\n\n{prompt}"

    # 4. Handle prompt delivery
    temp_files: list[str] = []
    prompt_delivery = provider_spec.prompt_delivery

    stdin_content: str | None = None
    if prompt_delivery == "stdin":
        # Prompt piped via subprocess stdin (e.g. Gemini CLI).
        # -p "" is already in argv to trigger headless mode; prompt goes via pipe.
        stdin_content = effective_prompt

    if prompt_delivery == "inline" and len(effective_prompt) > INLINE_PROMPT_MAX_CHARS:
        # Fall back to file delivery for prompts exceeding shell buffer limit
        logger.debug(
            "Inline prompt exceeds %d chars (%d), falling back to file delivery",
            INLINE_PROMPT_MAX_CHARS,
            len(effective_prompt),
        )
        prompt_delivery = "file"

    prompt_argument: str | None = None
    if prompt_delivery == "file":
        # Lazy import to avoid circular dependency
        from obra.hybrid.prompt_file import PromptFileManager as _PromptFileManager

        if prompt_manager is None:
            from obra.config.loaders import get_prompt_max_files, get_prompt_retention

            prompt_manager = _PromptFileManager(
                cmd_spec.cwd,
                retain=get_prompt_retention(),
                max_files=get_prompt_max_files(),
                run_id=cmd_spec.run_id,
            )

        prompt_path, prompt_instruction = prompt_manager.write_prompt(
            effective_prompt,
            use_absolute=provider_spec.use_absolute_paths,
            path_format=profile.path_format,
        )
        temp_files.append(str(prompt_path))
        prompt_argument = prompt_instruction
    elif prompt_delivery != "stdin":
        # Inline delivery: prompt text appended directly to command
        prompt_argument = effective_prompt
    # stdin delivery: prompt_argument stays None; content goes via pipe

    schema_argument: list[str] = []
    if isinstance(cmd_spec.output_schema, dict) and cmd_spec.response_format == "json":
        if cmd_spec.provider in {"openai", "ollama"}:
            schema_dir = cmd_spec.cwd / ".obra" / "schemas"
            schema_dir.mkdir(parents=True, exist_ok=True)
            schema_path = schema_dir / f".obra-schema-{uuid.uuid4().hex[:8]}.json"
            schema_path.write_text(
                json.dumps(cmd_spec.output_schema, indent=2),
                encoding="utf-8",
            )
            temp_files.append(str(schema_path))
            schema_argument = ["--output-schema", schema_path.as_posix()]
        elif cmd_spec.provider == "anthropic":
            schema_argument = ["--json-schema", json.dumps(cmd_spec.output_schema)]

    # MCP server configuration (Anthropic/Claude Code only)
    mcp_argument: list[str] = []
    if (
        cmd_spec.mcp_servers
        and cmd_spec.provider == "anthropic"
    ):
        mcp_config = {"mcpServers": {
            server["id"]: {
                k: v for k, v in server.items() if k != "id"
            }
            for server in cmd_spec.mcp_servers
        }}
        mcp_dir = cmd_spec.cwd / ".obra" / "mcp"
        mcp_dir.mkdir(parents=True, exist_ok=True)
        mcp_path = mcp_dir / f".obra-mcp-{uuid.uuid4().hex[:8]}.json"
        mcp_path.write_text(
            json.dumps(mcp_config, indent=2),
            encoding="utf-8",
        )
        temp_files.append(str(mcp_path))
        mcp_argument = ["--mcp-config", mcp_path.as_posix()]

    if cmd_spec.provider == "google":
        google_settings = provider_spec.provider_meta.get("gemini_settings")
        if isinstance(google_settings, dict) and google_settings:
            settings_dir = cmd_spec.cwd / ".obra" / "gemini"
            settings_dir.mkdir(parents=True, exist_ok=True)
            settings_path = settings_dir / f".obra-gemini-settings-{uuid.uuid4().hex[:8]}.json"
            settings_path.write_text(json.dumps(google_settings, indent=2), encoding="utf-8")
            env["GEMINI_CLI_SYSTEM_SETTINGS_PATH"] = settings_path.as_posix()
            temp_files.append(str(settings_path))

    # 5. Assemble full command (prompt_argument omitted for stdin delivery)
    cmd = [*base_cmd, *schema_argument, *mcp_argument]
    if prompt_argument is not None:
        cmd.append(prompt_argument)

    return ExecSpec(
        cmd=cmd,
        env=env,
        cwd=str(cmd_spec.cwd),
        encoding=profile.encoding,
        preexec_fn=preexec_fn,
        shell=False,
        timeout_s=cmd_spec.timeout_s,
        streaming=cmd_spec.streaming,
        temp_files=temp_files,
        spec_id=provider_spec.spec_id,
        stdin_content=stdin_content,
    )
