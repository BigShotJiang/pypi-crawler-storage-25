# Changelog

## [0.2.1](https://github.com/mahdilamb/redis-queen/compare/redis-queen-v0.2.0...redis-queen-v0.2.1) (2026-04-12)


### Bug Fixes

* wrap long line in __main__ to satisfy ruff E501 ([87a50f6](https://github.com/mahdilamb/redis-queen/commit/87a50f63a99d070baadeb961a8ae16244a5877a4))
* wrap long line in __main__ to satisfy ruff E501 ([6945787](https://github.com/mahdilamb/redis-queen/commit/6945787e6023dd896a64293436a7b82d1a8ad840))

## [0.2.0](https://github.com/mahdilamb/redis-queen/compare/redis-queen-v0.1.2...redis-queen-v0.2.0) (2026-04-12)


### ⚠ BREAKING CHANGES

* Package name, import module, CLI command, config section, and environment variable have all been renamed.

### Features

* initial release of red-queen ([2c69149](https://github.com/mahdilamb/redis-queen/commit/2c691498b342112aed5f7af48e8cce83cee3b587))


### Documentation

* add badges to README ([5c2d6d4](https://github.com/mahdilamb/redis-queen/commit/5c2d6d4dcd0f350f359d4f32085d626b8df13c34))
* add badges, classifiers, and 3.14 to CI matrix ([0b5b397](https://github.com/mahdilamb/redis-queen/commit/0b5b39786ee459576a231232639127f755fcabd0))
* remove alias-as-rename example from README ([2d3ac74](https://github.com/mahdilamb/redis-queen/commit/2d3ac74838922cb4d74d5026cfd7273796e8315d))
* remove alias-as-rename example from README ([5b5ecc3](https://github.com/mahdilamb/redis-queen/commit/5b5ecc38d5e40f492924a9cace1315d7fb066b30))


### Code Refactoring

* rename package from red-queen to redis-queen ([13532d6](https://github.com/mahdilamb/redis-queen/commit/13532d6b6be956f643d5dc4ec1f92f98f3f19019))

## [0.1.2](https://github.com/mahdilamb/redis-queen/compare/redis-queen-v0.1.1...redis-queen-v0.1.2) (2026-04-12)


### Documentation

* add badges to README ([5c2d6d4](https://github.com/mahdilamb/redis-queen/commit/5c2d6d4dcd0f350f359d4f32085d626b8df13c34))
* add badges, classifiers, and 3.14 to CI matrix ([0b5b397](https://github.com/mahdilamb/redis-queen/commit/0b5b39786ee459576a231232639127f755fcabd0))
* remove alias-as-rename example from README ([2d3ac74](https://github.com/mahdilamb/redis-queen/commit/2d3ac74838922cb4d74d5026cfd7273796e8315d))
* remove alias-as-rename example from README ([5b5ecc3](https://github.com/mahdilamb/redis-queen/commit/5b5ecc38d5e40f492924a9cace1315d7fb066b30))

## [0.1.1](https://github.com/mahdilamb/redis-queen/compare/redis-queen-v0.1.0...redis-queen-v0.1.1) (2026-04-12)


### Features

* initial release of redis-queen ([2c69149](https://github.com/mahdilamb/redis-queen/commit/2c691498b342112aed5f7af48e8cce83cee3b587))
