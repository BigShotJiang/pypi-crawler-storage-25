"""Shared fixtures for redis-queen tests."""

from __future__ import annotations

from typing import TYPE_CHECKING

import fakeredis.aioredis
import pytest

from redis_queen._decorator import _MODEL_REGISTRY

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
def fake_redis():
    """Provide a fakeredis async client."""
    return fakeredis.aioredis.FakeRedis(decode_responses=True)


@pytest.fixture
def migrations_dir(tmp_path: Path) -> Path:
    """Provide a temporary migrations directory."""
    d = tmp_path / "migrations"
    d.mkdir()
    return d


@pytest.fixture(autouse=True)
def _clear_registry():
    """Clear the model registry between tests."""
    _MODEL_REGISTRY.clear()
    yield
    _MODEL_REGISTRY.clear()


@pytest.fixture
def sample_pyproject(tmp_path: Path) -> Path:
    """Create a minimal pyproject.toml for testing."""
    content = """\
[tool.redis-queen]
migrations_dir = "migrations"

[tool.redis-queen.profiles.test]
default = true
host = "localhost"
port = 6379
db = 0
migrations_collection = "test_collection"
model_search_path = []
"""
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text(content)
    return pyproject
