"""Tests for the decorator and field annotations."""

from __future__ import annotations

import pytest
from pydantic import BaseModel

from redis_queen._decorator import (
    MigratesFrom,
    get_registered_model,
    get_registry,
    migrates_from,
    redis_queen,
    registered_model_key_placeholders,
    registered_model_resolve_key,
    registered_model_snapshot,
)


def test_decorator_with_key():
    @redis_queen(key="user:")
    class UserModel(BaseModel):
        name: str

    registry = get_registry()
    assert len(registry) == 1
    rm = next(iter(registry.values()))
    assert rm.key == "user:"
    assert rm.match == "user:*"
    assert rm.collection is None


def test_decorator_with_match():
    @redis_queen(match="user:*:profile")
    class UserModel(BaseModel):
        name: str

    rm = next(iter(get_registry().values()))
    assert rm.key is None
    assert rm.match == "user:*:profile"


def test_decorator_with_collection():
    @redis_queen(collection="my_col", key="item:")
    class ItemModel(BaseModel):
        value: int

    rm = next(iter(get_registry().values()))
    assert rm.collection == "my_col"


def test_decorator_requires_key_or_match():
    with pytest.raises(ValueError, match="At least one of"):

        @redis_queen()
        class BadModel(BaseModel):
            x: int


def test_snapshot_uses_json_schema():
    @redis_queen(key="m:")
    class M(BaseModel):
        x: int
        y: list[str]

    rm = next(iter(get_registry().values()))
    snapshot = registered_model_snapshot(rm)
    schema = snapshot["schema"]
    assert "properties" in schema
    assert "x" in schema["properties"]
    assert "y" in schema["properties"]
    assert schema["properties"]["x"]["type"] == "integer"


def test_snapshot_includes_nested_models():
    """model_json_schema captures nested model definitions."""

    class Inner(BaseModel):
        value: int

    @redis_queen(key="outer:")
    class Outer(BaseModel):
        items: list[Inner]

    rm = next(iter(get_registry().values()))
    snapshot = registered_model_snapshot(rm)
    schema = snapshot["schema"]
    assert "$defs" in schema
    assert "Inner" in schema["$defs"]


def test_get_registered_model():
    @redis_queen(key="x:")
    class X(BaseModel):
        v: int

    rm = get_registered_model(X)
    assert rm.model_class is X


def test_get_registered_model_not_found():
    class NotRegistered(BaseModel):
        v: int

    with pytest.raises(ValueError, match="not registered"):
        get_registered_model(NotRegistered)


def test_key_placeholders():
    @redis_queen(key="user:{user_id}:session:{session_id}")
    class SessionModel(BaseModel):
        data: str

    rm = next(iter(get_registry().values()))
    assert registered_model_key_placeholders(rm) == [
        "user_id",
        "session_id",
    ]


def test_resolve_key_positional():
    @redis_queen(key="user:{user_id}:profile:")
    class ProfileModel(BaseModel):
        name: str

    rm = next(iter(get_registry().values()))
    assert registered_model_resolve_key(rm, "123") == "user:123:profile:"


def test_resolve_key_kwargs():
    @redis_queen(key="user:{user_id}:profile:")
    class ProfileModel(BaseModel):
        name: str

    rm = next(iter(get_registry().values()))
    assert registered_model_resolve_key(rm, user_id="456") == "user:456:profile:"


def test_resolve_key_mixed():
    @redis_queen(key="{org}:user:{user_id}:profile:")
    class ProfileModel(BaseModel):
        name: str

    rm = next(iter(get_registry().values()))
    assert (
        registered_model_resolve_key(rm, "acme", user_id="789")
        == "acme:user:789:profile:"
    )


def test_resolve_key_wrong_param_count():
    @redis_queen(key="user:{user_id}:profile:")
    class ProfileModel(BaseModel):
        name: str

    rm = next(iter(get_registry().values()))
    with pytest.raises(ValueError, match="Cannot resolve key"):
        registered_model_resolve_key(rm, "a", "b")


def test_migrates_from_is_namedtuple():
    m = MigratesFrom(old_name="test")
    assert m.old_name == "test"
    assert list(m) == ["test"]


def test_migrates_from_still_importable():
    """migrates_from is still part of the public API."""
    m = migrates_from("old")
    assert isinstance(m, MigratesFrom)
    assert m.old_name == "old"
