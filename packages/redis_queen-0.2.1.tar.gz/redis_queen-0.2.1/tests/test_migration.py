"""Tests for migration staging and application."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
from pydantic import BaseModel

from redis_queen._decorator import redis_queen
from redis_queen._migration import apply_plan, migrate_down, migrate_up
from redis_queen._revision import generate_init
from redis_queen._state import get_state

if TYPE_CHECKING:
    from pathlib import Path

    from redis_queen._decorator import RegisteredModel
    from redis_queen._types import ModelSnapshot


@pytest.fixture
def sample_model():
    @redis_queen(key="item:")
    class ItemModel(BaseModel):
        name: str
        value: int

    return ItemModel


def _snapshot_from_model(rm: RegisteredModel) -> ModelSnapshot:
    from redis_queen._decorator import registered_model_snapshot

    return registered_model_snapshot(rm)


async def test_migrate_up_init_pending(fake_redis, migrations_dir: Path, sample_model):
    """The init revision should be pending when nothing has been applied."""
    from redis_queen._decorator import get_registry

    models = list(get_registry().values())
    snapshot = [_snapshot_from_model(m) for m in models]
    generate_init(migrations_dir, snapshot)

    plans = await migrate_up(fake_redis, migrations_dir, "test_col", models)
    assert len(plans) == 1
    assert plans[0]["revision_id"] == "0000"


async def test_migrate_up_no_pending_after_apply(
    fake_redis, migrations_dir: Path, sample_model
):
    """After applying init, no more pending revisions."""
    from redis_queen._decorator import get_registry

    models = list(get_registry().values())
    snapshot = [_snapshot_from_model(m) for m in models]
    generate_init(migrations_dir, snapshot)

    await migrate_up(fake_redis, migrations_dir, "test_col", models, auto_apply=True)
    plans = await migrate_up(fake_redis, migrations_dir, "test_col", models)
    assert plans == []


async def test_migrate_down(fake_redis, migrations_dir: Path, sample_model):
    from redis_queen._decorator import get_registry

    models = list(get_registry().values())
    snapshot = [_snapshot_from_model(m) for m in models]
    generate_init(migrations_dir, snapshot)

    await migrate_up(fake_redis, migrations_dir, "test_col", models, auto_apply=True)

    plans = await migrate_down(
        fake_redis,
        migrations_dir,
        "test_col",
        models,
        target_revision=None,
    )
    for plan in plans:
        await apply_plan(fake_redis, plan, "test_col")

    state = await get_state(fake_redis, "test_col")
    assert state["current_revision"] is None


async def test_state_tracking(fake_redis, migrations_dir: Path, sample_model):
    from redis_queen._decorator import get_registry

    models = list(get_registry().values())
    snapshot = [_snapshot_from_model(m) for m in models]
    generate_init(migrations_dir, snapshot)

    state = await get_state(fake_redis, "test_col")
    assert state["current_revision"] is None
    assert state["applied_revisions"] == []

    await migrate_up(fake_redis, migrations_dir, "test_col", models, auto_apply=True)

    state = await get_state(fake_redis, "test_col")
    assert state["current_revision"] == "0000"
