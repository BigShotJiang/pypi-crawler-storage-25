"""Tests for snapshot diffing."""

from __future__ import annotations

from typing import Any

from redis_queen._diff import diff_snapshots
from redis_queen._types import ModelSnapshot


def _model(
    name: str = "test.Model",
    schema: dict[str, Any] | None = None,
    **kwargs: Any,
) -> ModelSnapshot:
    return ModelSnapshot(
        qualified_name=name,
        collection=kwargs.get("collection"),
        key=kwargs.get("key", "test:"),
        match=kwargs.get("match", "test:*"),
        schema=schema or {"type": "object", "properties": {}},
    )


def test_no_changes():
    s = {"type": "object", "properties": {"x": {"type": "string"}}}
    old = [_model(schema=s)]
    new = [_model(schema=s)]
    assert diff_snapshots(old, new) == []


def test_model_added():
    changes = diff_snapshots([], [_model()])
    assert len(changes) == 1
    assert changes[0]["kind"] == "added"


def test_model_removed():
    changes = diff_snapshots([_model()], [])
    assert len(changes) == 1
    assert changes[0]["kind"] == "removed"


def test_schema_changed():
    old_schema = {
        "type": "object",
        "properties": {"x": {"type": "string"}},
    }
    new_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "string"},
            "y": {"type": "integer"},
        },
    }
    old = [_model(schema=old_schema)]
    new = [_model(schema=new_schema)]
    changes = diff_snapshots(old, new)
    assert len(changes) == 1
    assert changes[0]["kind"] == "modified"
    assert changes[0].get("old_schema") == old_schema
    assert changes[0].get("new_schema") == new_schema


def test_nested_schema_change():
    """Changes in nested models (e.g. $defs) are detected."""
    old_schema = {
        "type": "array",
        "items": {"$ref": "#/$defs/Item"},
        "$defs": {
            "Item": {
                "type": "object",
                "properties": {"name": {"type": "string"}},
            }
        },
    }
    new_schema = {
        "type": "array",
        "items": {"$ref": "#/$defs/Item"},
        "$defs": {
            "Item": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "value": {"type": "integer"},
                },
            }
        },
    }
    changes = diff_snapshots([_model(schema=old_schema)], [_model(schema=new_schema)])
    assert len(changes) == 1
    assert changes[0]["kind"] == "modified"


def test_same_schema_no_change():
    s = {
        "type": "array",
        "items": {"$ref": "#/$defs/Item"},
        "$defs": {
            "Item": {
                "type": "object",
                "properties": {"name": {"type": "string"}},
            }
        },
    }
    assert diff_snapshots([_model(schema=s)], [_model(schema=s)]) == []
