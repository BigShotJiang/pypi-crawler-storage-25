"""Tests for revision file generation and loading."""

from __future__ import annotations

from typing import TYPE_CHECKING

from redis_queen._revision import (
    generate_init,
    generate_revision,
    latest_revision,
    list_revisions,
    load_revision_module,
)
from redis_queen._types import ModelChange, ModelSnapshot

if TYPE_CHECKING:
    from pathlib import Path


def _snapshot(name: str = "test.Model") -> ModelSnapshot:
    return ModelSnapshot(
        qualified_name=name,
        collection=None,
        key="test:",
        match="test:*",
        schema={"type": "object", "properties": {"x": {"type": "string"}}},
    )


def test_generate_init(migrations_dir: Path):
    snapshot = [_snapshot()]
    path = generate_init(migrations_dir, snapshot)
    assert path.exists()
    assert path.name == "0000_init.py"
    module = load_revision_module(path)
    assert hasattr(module, "upgrade")
    assert hasattr(module, "downgrade")


def test_list_revisions_empty(migrations_dir: Path):
    assert list_revisions(migrations_dir) == []


def test_list_revisions_after_init(migrations_dir: Path):
    generate_init(migrations_dir, [_snapshot()])
    revisions = list_revisions(migrations_dir)
    assert len(revisions) == 1
    assert revisions[0]["revision_id"] == "0000"
    assert revisions[0]["parent_id"] is None


def test_generate_revision(migrations_dir: Path):
    old_snapshot = [_snapshot()]
    generate_init(migrations_dir, old_snapshot)

    new_schema = {
        "type": "object",
        "properties": {
            "x": {"type": "string"},
            "y": {"type": "integer"},
        },
    }
    new_snapshot = [
        ModelSnapshot(
            qualified_name="test.Model",
            collection=None,
            key="test:",
            match="test:*",
            schema=new_schema,
        )
    ]
    changes = [
        ModelChange(
            kind="modified",
            model_name="test.Model",
            match="test:*",
            old_schema=old_snapshot[0]["schema"],
            new_schema=new_schema,
        )
    ]
    path = generate_revision(
        migrations_dir,
        changes,
        old_snapshot,
        new_snapshot,
        message="add y field",
    )
    assert path.exists()
    assert path.name.startswith("0001_")
    module = load_revision_module(path)
    assert hasattr(module, "upgrade")
    assert hasattr(module, "downgrade")


def test_latest_revision(migrations_dir: Path):
    assert latest_revision(migrations_dir) is None
    generate_init(migrations_dir, [_snapshot()])
    rev = latest_revision(migrations_dir)
    assert rev is not None
    assert rev["revision_id"] == "0000"


def test_list_revisions_nonexistent():
    from pathlib import Path

    assert list_revisions(Path("/nonexistent")) == []
