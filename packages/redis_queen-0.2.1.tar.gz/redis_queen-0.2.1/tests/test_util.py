"""Tests for find_one and get_one utilities."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest
from pydantic import BaseModel

from redis_queen._decorator import redis_queen


@pytest.fixture
def user_profile_model():
    @redis_queen(key="user:{user_id}:profile:")
    class UserProfile(BaseModel):
        name: str
        email: str

    return UserProfile


@pytest.fixture
def item_model():
    @redis_queen(key="item:")
    class Item(BaseModel):
        value: int

    return Item


async def test_find_one(user_profile_model):
    from redis_queen._util import find_one

    data = {"name": "Alice", "email": "alice@example.com"}
    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=json.dumps(data))

    with patch("redis_queen._util._get_redis", return_value=mock_redis):
        result = await find_one(user_profile_model, "123")
        assert isinstance(result, user_profile_model)
        assert result.name == "Alice"
        mock_redis.get.assert_called_once_with("user:123:profile:")


async def test_find_one_return_raw(user_profile_model):
    from redis_queen._util import find_one

    data = {"name": "Alice", "email": "alice@example.com"}
    raw_json = json.dumps(data)
    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=raw_json)

    with patch("redis_queen._util._get_redis", return_value=mock_redis):
        result = await find_one(user_profile_model, "123", return_raw=True)
        assert result == raw_json


async def test_find_one_not_found(user_profile_model):
    from redis_queen._util import find_one

    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=None)

    with (
        patch("redis_queen._util._get_redis", return_value=mock_redis),
        pytest.raises(LookupError, match="No value found"),
    ):
        await find_one(user_profile_model, "999")


async def test_find_one_unregistered_model():
    from redis_queen._util import find_one

    class NotRegistered(BaseModel):
        x: int

    with pytest.raises(ValueError, match="not registered"):
        await find_one(NotRegistered, "123")


async def test_find_one_kwargs(user_profile_model):
    from redis_queen._util import find_one

    data = {"name": "Alice", "email": "alice@example.com"}
    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=json.dumps(data))

    with patch("redis_queen._util._get_redis", return_value=mock_redis):
        result = await find_one(user_profile_model, user_id="456")
        assert isinstance(result, user_profile_model)
        mock_redis.get.assert_called_once_with("user:456:profile:")


async def test_get_one(item_model):
    from redis_queen._util import get_one

    data = {"value": 42}
    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=json.dumps(data))

    with patch("redis_queen._util._get_redis", return_value=mock_redis):
        result = await get_one(item_model, "item:custom_key")
        assert isinstance(result, item_model)
        assert result.value == 42
        mock_redis.get.assert_called_once_with("item:custom_key")


async def test_get_one_return_raw(item_model):
    from redis_queen._util import get_one

    raw = json.dumps({"value": 42})
    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=raw)

    with patch("redis_queen._util._get_redis", return_value=mock_redis):
        result = await get_one(item_model, "item:custom_key", return_raw=True)
        assert result == raw


async def test_get_one_not_found(item_model):
    from redis_queen._util import get_one

    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=None)

    with (
        patch("redis_queen._util._get_redis", return_value=mock_redis),
        pytest.raises(LookupError),
    ):
        await get_one(item_model, "item:missing")
