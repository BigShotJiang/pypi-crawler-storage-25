"""Tests for configuration loading."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from redis_queen._config import (
    load_config,
    profile_redis_url,
    resolve_profile,
)

if TYPE_CHECKING:
    from pathlib import Path


def test_load_config(sample_pyproject: Path):
    config = load_config(sample_pyproject)
    assert "test" in config["profiles"]
    profile = config["profiles"]["test"]
    assert profile["name"] == "test"
    assert profile.get("default") is True
    assert config["migrations_dir"] == sample_pyproject.parent / "migrations"


def test_load_config_no_section(tmp_path: Path):
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("[project]\nname = 'test'\n")
    with pytest.raises(ValueError, match=r"No \[tool.redis-queen\]"):
        load_config(pyproject)


def test_load_config_no_profiles(tmp_path: Path):
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("[tool.redis-queen]\nmigrations_dir = 'migrations'\n")
    with pytest.raises(ValueError, match="No profiles defined"):
        load_config(pyproject)


def test_load_config_multiple_defaults(tmp_path: Path):
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("""\
[tool.redis-queen]
migrations_dir = "migrations"

[tool.redis-queen.profiles.a]
default = true
host = "localhost"

[tool.redis-queen.profiles.b]
default = true
host = "localhost"
""")
    with pytest.raises(ValueError, match="Multiple default"):
        load_config(pyproject)


def test_load_config_no_default(tmp_path: Path):
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("""\
[tool.redis-queen]
migrations_dir = "migrations"

[tool.redis-queen.profiles.a]
host = "localhost"
""")
    with pytest.raises(ValueError, match="No default profile"):
        load_config(pyproject)


def test_expandvars(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("TEST_HOST", "redis.example.com")
    pyproject = tmp_path / "pyproject.toml"
    pyproject.write_text("""\
[tool.redis-queen]
migrations_dir = "migrations"

[tool.redis-queen.profiles.env_test]
default = true
host = "$TEST_HOST"
port = 6379
""")
    config = load_config(pyproject)
    profile = config["profiles"]["env_test"]
    assert profile["host"] == "redis.example.com"


def test_resolve_profile_by_name(sample_pyproject: Path):
    config = load_config(sample_pyproject)
    profile = resolve_profile(config, "test")
    assert profile["name"] == "test"


def test_resolve_profile_by_env(
    sample_pyproject: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setenv("REDIS_QUEEN_PROFILE", "test")
    config = load_config(sample_pyproject)
    profile = resolve_profile(config)
    assert profile["name"] == "test"


def test_resolve_profile_default(sample_pyproject: Path):
    config = load_config(sample_pyproject)
    profile = resolve_profile(config)
    assert profile["name"] == "test"


def test_resolve_profile_not_found(sample_pyproject: Path):
    config = load_config(sample_pyproject)
    with pytest.raises(ValueError, match="not found"):
        resolve_profile(config, "nonexistent")


def test_profile_redis_url():
    from redis_queen._config import Profile

    profile = Profile(
        name="test",
        host="myhost",
        port=6380,
        db=2,
    )
    assert profile_redis_url(profile) == "redis://myhost:6380/2"


def test_profile_redis_url_with_auth():
    from redis_queen._config import Profile

    profile = Profile(
        name="test",
        host="myhost",
        port=6379,
        db=0,
        username="user",
        password="pass",
    )
    assert profile_redis_url(profile) == "redis://user:pass@myhost:6379/0"
