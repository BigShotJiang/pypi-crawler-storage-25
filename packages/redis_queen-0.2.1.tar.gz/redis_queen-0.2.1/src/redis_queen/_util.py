"""Query utilities: find_one and get_one."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Literal, TypeVar, overload

from pydantic import BaseModel

from redis_queen._config import load_config, profile_redis_url, resolve_profile
from redis_queen._decorator import (
    get_registered_model,
    registered_model_resolve_key,
)

if TYPE_CHECKING:
    from redis.asyncio import Redis

T = TypeVar("T", bound=BaseModel)

_redis_cache: dict[str, Redis] = {}  # type: ignore[type-arg]


async def _get_redis() -> Redis:  # type: ignore[type-arg]
    """Get or create a Redis client for the default profile."""
    from redis.asyncio import Redis as AsyncRedis

    config = load_config()
    profile = resolve_profile(config)
    url = profile_redis_url(profile)

    if url not in _redis_cache:
        _redis_cache[url] = AsyncRedis.from_url(url, decode_responses=True)
    return _redis_cache[url]


@overload
async def find_one(
    model: type[T],
    *args: str,
    return_raw: Literal[False] = ...,
    **kwargs: str,
) -> T: ...


@overload
async def find_one(
    model: type[T],
    *args: str,
    return_raw: Literal[True],
    **kwargs: str,
) -> str: ...


async def find_one(
    model: type[T],
    *args: str,
    return_raw: bool = False,
    **kwargs: str,
) -> T | str:
    """Find a single key using the model's key pattern.

    Formats the decorator's ``key`` with positional and/or keyword
    arguments (like ``str.format``), then performs a ``GET``::

        # key="user:{user_id}:profile:"
        await find_one(UserProfile, "123")
        await find_one(UserProfile, user_id="123")

    Raises ``ValueError`` if the model is not registered or if the
    arguments don't match the placeholders.
    """
    rm = get_registered_model(model)
    resolved_key = registered_model_resolve_key(rm, *args, **kwargs)
    redis = await _get_redis()
    value = await redis.get(resolved_key)
    if value is None:
        msg = f"No value found at key '{resolved_key}'"
        raise LookupError(msg)
    if return_raw:
        return value
    data = json.loads(value)
    return model.model_validate(data)


@overload
async def get_one(
    model: type[T],
    key: str,
    *,
    return_raw: Literal[False] = ...,
) -> T: ...


@overload
async def get_one(
    model: type[T],
    key: str,
    *,
    return_raw: Literal[True],
) -> str: ...


async def get_one(
    model: type[T],
    key: str,
    *,
    return_raw: bool = False,
) -> T | str:
    """GET a value by full literal Redis key and deserialize into *model*.

    Ignores the key/match pattern from the decorator — uses the exact *key*.

    Raises ``ValueError`` if the model is not registered.
    """
    get_registered_model(model)
    redis = await _get_redis()
    value = await redis.get(key)
    if value is None:
        msg = f"No value found at key '{key}'"
        raise LookupError(msg)
    if return_raw:
        return value
    data = json.loads(value)
    return model.model_validate(data)
