"""Diff two model snapshots to produce a list of changes."""

from __future__ import annotations

from redis_queen._types import ModelChange, ModelSnapshot


def diff_snapshots(
    old: list[ModelSnapshot],
    new: list[ModelSnapshot],
) -> list[ModelChange]:
    """Compare two sets of model snapshots and return the changes."""
    old_by_name = {m["qualified_name"]: m for m in old}
    new_by_name = {m["qualified_name"]: m for m in new}

    changes: list[ModelChange] = []

    # Removed models
    for name in old_by_name:
        if name not in new_by_name:
            changes.append(ModelChange(kind="removed", model_name=name))

    # Added models
    for name, model in new_by_name.items():
        if name not in old_by_name:
            changes.append(
                ModelChange(
                    kind="added",
                    model_name=name,
                    collection=model["collection"],
                    key=model["key"],
                    match=model["match"],
                    new_schema=model["schema"],
                )
            )

    # Modified models (schema changed)
    for name in old_by_name:
        if name not in new_by_name:
            continue
        old_model = old_by_name[name]
        new_model = new_by_name[name]
        if old_model["schema"] != new_model["schema"]:
            changes.append(
                ModelChange(
                    kind="modified",
                    model_name=name,
                    collection=new_model["collection"],
                    key=new_model["key"],
                    match=new_model["match"],
                    old_schema=old_model["schema"],
                    new_schema=new_model["schema"],
                )
            )

    return changes
