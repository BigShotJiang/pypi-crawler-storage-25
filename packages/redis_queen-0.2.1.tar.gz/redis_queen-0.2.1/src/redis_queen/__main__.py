"""CLI entry point for redis-queen."""


def main() -> None:
    try:
        from redis_queen.commands import cli
    except ImportError:
        raise SystemExit(
            "The CLI requires the 'cli' extra. "
            "Install with: pip install redis-queen[cli]"
        ) from None
    cli()


if __name__ == "__main__":
    main()
