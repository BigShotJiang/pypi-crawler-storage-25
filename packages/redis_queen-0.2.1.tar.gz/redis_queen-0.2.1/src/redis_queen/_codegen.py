"""Generate upgrade/downgrade function bodies from schema diffs."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from redis_queen._types import ModelChange

BACKUP_SUFFIX = ":__migration_backup__"


def generate_upgrade(
    changes: list[ModelChange],
    *,
    deletion_protection: bool | int = False,
) -> str:
    """Generate the ``upgrade`` function body."""
    lines = [
        "async def upgrade(redis: Redis, scan_match: dict[str, str]) -> None:",
    ]
    body = _generate_upgrade_body(changes, deletion_protection=deletion_protection)
    if body:
        lines.extend(body)
    else:
        lines.append("    pass")
    return "\n".join(lines)


def generate_downgrade(
    changes: list[ModelChange],
    *,
    deletion_protection: bool | int = False,
) -> str:
    """Generate the ``downgrade`` function body."""
    lines = [
        "async def downgrade(redis: Redis, scan_match: dict[str, str]) -> None:",
    ]
    body = _generate_downgrade_body(changes, deletion_protection=deletion_protection)
    if body:
        lines.extend(body)
    else:
        lines.append("    pass")
    return "\n".join(lines)


def _generate_upgrade_body(
    changes: list[ModelChange],
    *,
    deletion_protection: bool | int = False,
) -> list[str]:
    """Build upgrade code: add new fields, backup and remove old fields."""
    body: list[str] = []
    for change in changes:
        if change.get("kind") != "modified":
            continue
        match = change.get("match")
        if not match:
            continue
        old_schema = change.get("old_schema", {})
        new_schema = change.get("new_schema", {})

        added, removed = _collect_field_changes(old_schema, new_schema)
        if not added and not removed:
            continue

        body.append(f"    # {change['model_name']}")
        body.extend(_scan_loop_header(match))

        for name, prop, is_req in added:
            default = _resolve_default(name, prop, is_req)
            if default is _NO_DEFAULT:
                body.append(
                    f"            # TODO: set default for new required field {name!r}"
                )
                body.append("            changed = True")
            else:
                default_repr = json.dumps(default)
                body.append(f"            if {name!r} not in data:")
                body.append(f"                data[{name!r}] = {default_repr}")
                body.append("                changed = True")

        if removed and deletion_protection is True:
            for name in removed:
                body.append(
                    f"            # TODO: field {name!r} was removed"
                    " (deletion_protection is enabled)"
                )
        elif removed:
            ttl = deletion_protection if isinstance(deletion_protection, int) else None
            if ttl:
                body.append(f"            # Backup removed fields (TTL: {ttl}s)")
            else:
                body.append("            # Backup removed fields for downgrade")
            body.append("            backup = {}")
            for name in removed:
                body.append(f"            if {name!r} in data:")
                body.append(f"                backup[{name!r}] = data.pop({name!r})")
                body.append("                changed = True")
            body.append("            if backup:")
            if ttl:
                body.append(
                    "                await redis.set("
                    f"key + {BACKUP_SUFFIX!r}, json.dumps(backup),"
                    f" ex={ttl})"
                )
            else:
                body.append(
                    "                await redis.set("
                    f"key + {BACKUP_SUFFIX!r}, json.dumps(backup))"
                )

        body.extend(_scan_loop_footer())

    return body


def _generate_downgrade_body(
    changes: list[ModelChange],
    *,
    deletion_protection: bool | int = False,
) -> list[str]:
    """Build downgrade code: restore backed-up fields, remove added fields."""
    body: list[str] = []
    for change in changes:
        if change.get("kind") != "modified":
            continue
        match = change.get("match")
        if not match:
            continue
        old_schema = change.get("old_schema", {})
        new_schema = change.get("new_schema", {})

        added, removed = _collect_field_changes(old_schema, new_schema)
        if not added and not removed:
            continue

        body.append(f"    # {change['model_name']}")
        body.extend(_scan_loop_header(match))

        if removed and deletion_protection is not True:
            body.append("            # Restore fields from backup")
            body.append(
                f"            backup_raw = await redis.get(key + {BACKUP_SUFFIX!r})"
            )
            body.append("            if backup_raw:")
            body.append("                backup = json.loads(backup_raw)")
            body.append("                data.update(backup)")
            body.append(f"                await redis.delete(key + {BACKUP_SUFFIX!r})")
            body.append("                changed = True")
            if isinstance(deletion_protection, int):
                body.append("            else:")
                body.append("                import warnings")
                body.append("                warnings.warn(")
                body.append(
                    '                    f"Backup expired for'
                    ' {key}, removed fields cannot be restored.",'
                )
                body.append("                    stacklevel=1,")
                body.append("                )")

        for name, _prop, _is_req in added:
            body.append(f"            if {name!r} in data:")
            body.append(f"                del data[{name!r}]")
            body.append("                changed = True")

        body.extend(_scan_loop_footer())

    return body


def _scan_loop_header(match: str) -> list[str]:
    """Return the SCAN loop preamble."""
    return [
        "    cursor = 0",
        "    while True:",
        f"        cursor, keys = await redis.scan(cursor=cursor, match={match!r})",
        "        for key in keys:",
        "            raw = await redis.get(key)",
        "            if raw is None:",
        "                continue",
        "            data = json.loads(raw)",
        "            changed = False",
    ]


def _scan_loop_footer() -> list[str]:
    """Return the SCAN loop tail."""
    return [
        "            if changed:",
        "                await redis.set(key, json.dumps(data))",
        "        if not cursor:",
        "            break",
    ]


def _collect_field_changes(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
) -> tuple[list[tuple[str, dict[str, Any], bool]], list[str]]:
    """Return (added_fields, removed_field_names) across all property sets."""
    added: list[tuple[str, dict[str, Any], bool]] = []
    removed: list[str] = []

    for old_p, new_p, _old_req, new_req in _property_pairs(old_schema, new_schema):
        for name in new_p:
            if name not in old_p:
                added.append((name, new_p[name], name in new_req))
        for name in old_p:
            if name not in new_p:
                removed.append(name)

    return added, removed


def _property_pairs(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
) -> list[tuple[dict[str, Any], dict[str, Any], set[str], set[str]]]:
    """Collect property dicts from top-level and $defs."""
    pairs: list[tuple[dict[str, Any], dict[str, Any], set[str], set[str]]] = [
        (
            old_schema.get("properties", {}),
            new_schema.get("properties", {}),
            set(old_schema.get("required", [])),
            set(new_schema.get("required", [])),
        ),
    ]
    old_defs = old_schema.get("$defs", {})
    new_defs = new_schema.get("$defs", {})
    for def_name in set(old_defs) | set(new_defs):
        old_def = old_defs.get(def_name, {})
        new_def = new_defs.get(def_name, {})
        pairs.append(
            (
                old_def.get("properties", {}),
                new_def.get("properties", {}),
                set(old_def.get("required", [])),
                set(new_def.get("required", [])),
            )
        )
    return pairs


class _NoDefault:
    """Sentinel for fields with no default."""


_NO_DEFAULT = _NoDefault()


def _resolve_default(
    name: str,
    prop_schema: dict[str, Any],
    is_required: bool,
) -> Any:
    """Determine the default value for a new field."""
    if "default" in prop_schema:
        return prop_schema["default"]
    if not is_required:
        return _type_default(prop_schema)
    return _NO_DEFAULT


def _type_default(prop_schema: dict[str, Any]) -> Any:
    """Infer a zero-value default from the JSON schema type."""
    schema_type = prop_schema.get("type")
    if schema_type == "array":
        return []
    if schema_type == "object":
        return {}
    if schema_type == "string":
        return ""
    if schema_type == "integer":
        return 0
    if schema_type == "number":
        return 0.0
    if schema_type == "boolean":
        return False
    if "anyOf" in prop_schema:
        for variant in prop_schema["anyOf"]:
            if variant.get("type") == "null":
                return None
    return _NO_DEFAULT
