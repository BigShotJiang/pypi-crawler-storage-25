"""``redis-queen reset`` command."""

from __future__ import annotations

import asyncio
import sys

import click

from redis_queen._config import load_config, profile_redis_url, resolve_profile
from redis_queen._discovery import discover_models
from redis_queen._migration import apply_plan, migrate_down, migrate_up
from redis_queen._state import get_state
from redis_queen._types import migration_plan_summary


@click.command()
@click.argument("revision", required=False)
@click.option("--root", is_flag=True, help="Reset to before all migrations")
@click.option("--auto-apply", is_flag=True, help="Skip staging confirmation")
@click.pass_context
def reset(
    ctx: click.Context,
    revision: str | None,
    root: bool,
    auto_apply: bool,
) -> None:
    """Reset to a specific revision (up or down as needed)."""
    if revision is None and not root:
        click.echo("Error: must provide REVISION or --root", err=True)
        sys.exit(1)
    target = None if root else revision
    asyncio.run(_reset(ctx.obj["profile_name"], target, auto_apply))


async def _reset(
    profile_name: str | None,
    target_revision: str | None,
    auto_apply: bool,
) -> None:
    from redis.asyncio import Redis

    config = load_config()
    profile = resolve_profile(config, profile_name)
    url = profile_redis_url(profile)
    migrations_collection = profile.get("migrations_collection", "default")
    models = discover_models(
        profile.get("model_search_path", []),
        config["pyproject_dir"],
        collection_filter=migrations_collection,
    )

    async with Redis.from_url(url, decode_responses=True) as redis:
        state = await get_state(redis, migrations_collection)
        current = state["current_revision"]

        if target_revision is None:
            plans = await migrate_down(
                redis,
                config["migrations_dir"],
                migrations_collection,
                models,
                target_revision=None,
            )
        elif current is None or target_revision > current:
            plans = await migrate_up(
                redis,
                config["migrations_dir"],
                migrations_collection,
                models,
                target_revision=target_revision,
            )
        elif target_revision < current:
            plans = await migrate_down(
                redis,
                config["migrations_dir"],
                migrations_collection,
                models,
                target_revision=target_revision,
            )
        else:
            click.echo(f"Already at revision {target_revision}.")
            return

        if not plans:
            click.echo("Nothing to do.")
            return

        for plan in plans:
            click.echo(migration_plan_summary(plan))

        if auto_apply or click.confirm("Apply these changes?"):
            for plan in plans:
                await apply_plan(redis, plan, migrations_collection)
            click.echo("Reset complete.")
        else:
            click.echo("Aborted.")
