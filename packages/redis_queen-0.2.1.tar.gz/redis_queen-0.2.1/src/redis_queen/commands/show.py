"""``redis-queen show`` command."""

from __future__ import annotations

import asyncio

import click

from redis_queen._config import load_config, profile_redis_url, resolve_profile
from redis_queen._revision import list_revisions
from redis_queen._state import get_state


@click.command()
@click.option("--profile", "show_profile", default=None, help="Profile to show")
@click.pass_context
def show(ctx: click.Context, show_profile: str | None) -> None:
    """Show current revision and pending upgrades."""
    profile_name = show_profile or ctx.obj["profile_name"]
    asyncio.run(_show(profile_name))


async def _show(profile_name: str | None) -> None:
    from redis.asyncio import Redis

    config = load_config()
    profile = resolve_profile(config, profile_name)
    url = profile_redis_url(profile)
    migrations_collection = profile.get("migrations_collection", "default")

    async with Redis.from_url(url, decode_responses=True) as redis:
        state = await get_state(redis, migrations_collection)
        revisions = list_revisions(config["migrations_dir"])

        click.echo(f"Profile: {profile['name']}")
        click.echo(f"Collection: {migrations_collection}")
        click.echo(f"Current revision: {state['current_revision'] or '(none)'}")
        click.echo(f"Applied revisions: {len(state['applied_revisions'])}")

        applied = set(state["applied_revisions"])
        pending = [r for r in revisions if r["revision_id"] not in applied]
        if pending:
            click.echo(f"Pending upgrades: {len(pending)}")
            for rev in pending:
                click.echo(f"  {rev['revision_id']}: {rev['description']}")
        else:
            click.echo("No pending upgrades.")
