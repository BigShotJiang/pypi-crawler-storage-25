"""``redis-queen diff`` command."""

from __future__ import annotations

import asyncio
import json

import click

from redis_queen._config import load_config, resolve_profile
from redis_queen._decorator import registered_model_snapshot
from redis_queen._diff import diff_snapshots
from redis_queen._discovery import discover_models
from redis_queen._revision import latest_revision


@click.command(name="diff")
@click.option("--profile", "diff_profile", default=None, help="Profile to diff")
@click.pass_context
def diff_cmd(ctx: click.Context, diff_profile: str | None) -> None:
    """Show what changes are available to apply."""
    profile_name = diff_profile or ctx.obj["profile_name"]
    asyncio.run(_diff(profile_name))


async def _diff(profile_name: str | None) -> None:
    config = load_config()
    profile = resolve_profile(config, profile_name)
    migrations_collection = profile.get("migrations_collection", "default")

    models = discover_models(
        profile.get("model_search_path", []),
        config["pyproject_dir"],
        collection_filter=migrations_collection,
    )

    current_snapshot = [registered_model_snapshot(m) for m in models]
    last_rev = latest_revision(config["migrations_dir"])
    old_snapshot = last_rev["models_snapshot"] if last_rev else []

    changes = diff_snapshots(old_snapshot, current_snapshot)
    if not changes:
        click.echo("No differences detected.")
        return

    for change in changes:
        kind = change["kind"].upper()
        name = change["model_name"]
        click.echo(f"{kind}: {name}")
        if change.get("old_schema") or change.get("new_schema"):
            old = json.dumps(change.get("old_schema", {}), indent=2)
            new = json.dumps(change.get("new_schema", {}), indent=2)
            if old != new:
                click.echo(f"  old schema: {old}")
                click.echo(f"  new schema: {new}")
