"""CLI command group for redis-queen."""

from __future__ import annotations

import click

from redis_queen.commands.diff import diff_cmd
from redis_queen.commands.down import down
from redis_queen.commands.reset import reset
from redis_queen.commands.revision import revision_cmd
from redis_queen.commands.show import show
from redis_queen.commands.up import up


@click.group()
@click.option(
    "--profile",
    default=None,
    help="Profile name (overrides REDIS_QUEEN_PROFILE env var)",
)
@click.pass_context
def cli(ctx: click.Context, profile: str | None) -> None:
    """Redis migration management tool."""
    ctx.ensure_object(dict)
    ctx.obj["profile_name"] = profile


cli.add_command(up)
cli.add_command(down)
cli.add_command(show)
cli.add_command(diff_cmd)
cli.add_command(reset)
cli.add_command(revision_cmd)
