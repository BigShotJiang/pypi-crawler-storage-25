"""``redis-queen revision`` command."""

from __future__ import annotations

import asyncio
import sys

import click

from redis_queen._config import load_config, resolve_profile
from redis_queen._decorator import registered_model_snapshot
from redis_queen._diff import diff_snapshots
from redis_queen._discovery import discover_models
from redis_queen._revision import (
    generate_init,
    generate_revision,
    list_revisions,
)


@click.command(name="revision")
@click.option("-m", "--message", default="", help="Description for the revision")
@click.option("--check", is_flag=True, help="Exit 1 if no changes detected")
@click.pass_context
def revision_cmd(ctx: click.Context, message: str, check: bool) -> None:
    """Generate a new migration revision from model changes."""
    asyncio.run(_revision(ctx.obj["profile_name"], message, check))


async def _revision(
    profile_name: str | None,
    message: str,
    check: bool,
) -> None:
    config = load_config()
    profile = resolve_profile(config, profile_name)
    migrations_collection = profile.get("migrations_collection", "default")

    models = discover_models(
        profile.get("model_search_path", []),
        config["pyproject_dir"],
        collection_filter=migrations_collection,
    )

    current_snapshot = [registered_model_snapshot(m) for m in models]
    migrations_dir = config["migrations_dir"]

    revisions = list_revisions(migrations_dir)
    if not revisions:
        path = generate_init(migrations_dir, current_snapshot)
        click.echo(f"Created init migration: {path}")
        if check:
            sys.exit(0)
        return

    last_rev = revisions[-1]
    old_snapshot = last_rev["models_snapshot"]
    changes = diff_snapshots(old_snapshot, current_snapshot)

    if not changes:
        if check:
            click.echo("No changes detected.", err=True)
            sys.exit(1)
        click.echo("No changes detected.")
        return

    if check:
        click.echo("Changes detected.")
        sys.exit(0)

    path = generate_revision(
        migrations_dir,
        changes,
        old_snapshot,
        current_snapshot,
        message=message,
        deletion_protection=config.get("deletion_protection", False),
    )
    click.echo(f"Created migration: {path}")
