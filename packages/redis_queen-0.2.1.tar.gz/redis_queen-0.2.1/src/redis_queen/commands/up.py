"""``redis-queen up`` command."""

from __future__ import annotations

import asyncio

import click

from redis_queen._config import load_config, profile_redis_url, resolve_profile
from redis_queen._discovery import discover_models
from redis_queen._migration import apply_plan, migrate_up
from redis_queen._types import migration_plan_summary


@click.command()
@click.argument("revision", required=False)
@click.option("--auto-apply", is_flag=True, help="Skip staging confirmation")
@click.pass_context
def up(ctx: click.Context, revision: str | None, auto_apply: bool) -> None:
    """Migrate up to latest or a specific revision."""
    asyncio.run(_up(ctx.obj["profile_name"], revision, auto_apply))


async def _up(
    profile_name: str | None,
    target_revision: str | None,
    auto_apply: bool,
) -> None:
    from redis.asyncio import Redis

    config = load_config()
    profile = resolve_profile(config, profile_name)
    url = profile_redis_url(profile)
    migrations_collection = profile.get("migrations_collection", "default")
    models = discover_models(
        profile.get("model_search_path", []),
        config["pyproject_dir"],
        collection_filter=migrations_collection,
    )

    async with Redis.from_url(url, decode_responses=True) as redis:
        plans = await migrate_up(
            redis,
            config["migrations_dir"],
            migrations_collection,
            models,
            target_revision=target_revision,
        )

        if not plans:
            click.echo("Already up to date.")
            return

        for plan in plans:
            click.echo(migration_plan_summary(plan))
            if plan["changes"]:
                for change in plan["changes"][:10]:
                    click.echo(f"  {change['change_type']}: {change['key']}")
                if len(plan["changes"]) > 10:
                    click.echo(f"  ... and {len(plan['changes']) - 10} more")

        if auto_apply or click.confirm("Apply these migrations?"):
            for plan in plans:
                await apply_plan(redis, plan, migrations_collection)
            click.echo("Migrations applied successfully.")
        else:
            click.echo("Aborted.")
