"""Shared type definitions for redis-queen."""

from __future__ import annotations

from typing import Any, Literal, TypedDict


class ModelSnapshot(TypedDict):
    """Snapshot of a registered model at a point in time."""

    qualified_name: str
    collection: str | None
    key: str | None
    match: str | None
    schema: dict[str, Any]


class RevisionMeta(TypedDict):
    """Metadata for a single migration revision."""

    revision_id: str
    parent_id: str | None
    description: str
    created_at: str
    models_snapshot: list[ModelSnapshot]


class ModelChange(TypedDict, total=False):
    """A change to a model between two snapshots."""

    kind: Literal["added", "removed", "modified"]  # required
    model_name: str  # required
    collection: str | None
    key: str | None
    match: str | None
    old_schema: dict[str, Any]
    new_schema: dict[str, Any]


class KeyChange(TypedDict):
    """A staged change to a single Redis key."""

    key: str
    old_value: str | None
    new_value: str | None
    change_type: Literal["modify", "delete", "create"]


class MigrationPlan(TypedDict):
    """A collection of staged key changes for a single revision."""

    revision_id: str
    direction: Literal["up", "down"]
    changes: list[KeyChange]


def migration_plan_summary(plan: MigrationPlan) -> str:
    """Return a human-readable summary of a migration plan."""
    counts: dict[str, int] = {"modify": 0, "delete": 0, "create": 0}
    for change in plan["changes"]:
        counts[change["change_type"]] += 1
    parts = []
    if counts["create"]:
        parts.append(f"{counts['create']} create")
    if counts["modify"]:
        parts.append(f"{counts['modify']} modify")
    if counts["delete"]:
        parts.append(f"{counts['delete']} delete")
    direction = "upgrade" if plan["direction"] == "up" else "downgrade"
    changes_str = ", ".join(parts) if parts else "no changes"
    return f"Revision {plan['revision_id']} ({direction}): {changes_str}"
