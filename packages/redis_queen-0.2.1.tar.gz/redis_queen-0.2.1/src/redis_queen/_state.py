"""Read and write migration revision state in Redis."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    from redis.asyncio import Redis


class MigrationState(TypedDict):
    """Migration state stored in Redis."""

    current_revision: str | None
    applied_revisions: list[str]


def _state_key(migrations_collection: str) -> str:
    return f"redis_queen:{migrations_collection}:state"


async def get_state(redis: Redis, migrations_collection: str) -> MigrationState:  # type: ignore[type-arg]
    """Read the current migration state from Redis."""
    raw = await redis.get(_state_key(migrations_collection))
    if raw is None:
        return MigrationState(current_revision=None, applied_revisions=[])
    return json.loads(raw)


async def set_state(
    redis: Redis,  # type: ignore[type-arg]
    migrations_collection: str,
    state: MigrationState,
) -> None:
    """Write the migration state to Redis."""
    await redis.set(_state_key(migrations_collection), json.dumps(state))
