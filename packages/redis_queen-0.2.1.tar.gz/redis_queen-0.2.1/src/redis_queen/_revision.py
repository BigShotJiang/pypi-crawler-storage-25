"""Migration revision file generation, loading, and ordering."""

from __future__ import annotations

import importlib.util
import json
import re
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from redis_queen._codegen import generate_downgrade, generate_upgrade
from redis_queen._types import ModelChange, ModelSnapshot, RevisionMeta

if TYPE_CHECKING:
    from pathlib import Path
    from types import ModuleType

_REVISION_PATTERN = re.compile(r"^(\d{4})_.*\.py$")


def list_revisions(migrations_dir: Path) -> list[RevisionMeta]:
    """Load all revision files in order and return their metadata."""
    if not migrations_dir.is_dir():
        return []
    files = sorted(
        f
        for f in migrations_dir.iterdir()
        if f.is_file() and _REVISION_PATTERN.match(f.name)
    )
    revisions: list[RevisionMeta] = []
    for f in files:
        module = load_revision_module(f)
        meta = _extract_meta(module, f)
        revisions.append(meta)
    return revisions


def latest_revision(migrations_dir: Path) -> RevisionMeta | None:
    """Return the latest revision, or ``None`` if no revisions exist."""
    revisions = list_revisions(migrations_dir)
    return revisions[-1] if revisions else None


def load_revision_module(path: Path) -> ModuleType:
    """Import a revision ``.py`` file and return the module."""
    spec = importlib.util.spec_from_file_location(f"_migration_{path.stem}", path)
    if spec is None or spec.loader is None:
        msg = f"Cannot load revision file: {path}"
        raise ImportError(msg)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _extract_meta(module: ModuleType, path: Path) -> RevisionMeta:
    """Extract revision metadata from a loaded module."""
    doc = module.__doc__ or ""
    revision_id = _parse_docstring_field(doc, "Revision") or path.stem[:4]
    parent_id = _parse_docstring_field(doc, "Parent")
    description = _parse_docstring_field(doc, "Description") or ""
    created_at = _parse_docstring_field(doc, "Created") or ""

    snapshot_json = getattr(module, "MODELS_SNAPSHOT", "[]")
    models_snapshot: list[ModelSnapshot] = json.loads(snapshot_json)

    return RevisionMeta(
        revision_id=revision_id,
        parent_id=parent_id if parent_id != "None" else None,
        description=description,
        created_at=created_at,
        models_snapshot=models_snapshot,
    )


def _parse_docstring_field(doc: str, field: str) -> str | None:
    """Parse a ``Field: value`` line from a docstring."""
    for line in doc.splitlines():
        line = line.strip()
        if line.startswith(f"{field}:"):
            return line[len(field) + 1 :].strip()
    return None


def generate_revision(
    migrations_dir: Path,
    changes: list[ModelChange],
    old_snapshot: list[ModelSnapshot],
    new_snapshot: list[ModelSnapshot],
    *,
    message: str = "",
    deletion_protection: bool | int = False,
) -> Path:
    """Create a new migration file.  Returns the path to the created file."""
    migrations_dir.mkdir(parents=True, exist_ok=True)

    existing = list_revisions(migrations_dir)
    next_id = f"{len(existing):04d}"
    parent_id = existing[-1]["revision_id"] if existing else None

    slug = _slugify(message) if message else "auto"
    filename = f"{next_id}_{slug}.py"
    path = migrations_dir / filename

    now = datetime.now(timezone.utc).isoformat()
    snapshot_json = json.dumps(new_snapshot, indent=2)
    changes_json = json.dumps([dict(c) for c in changes], indent=2)
    upgrade_body = generate_upgrade(changes, deletion_protection=deletion_protection)
    downgrade_body = generate_downgrade(
        changes, deletion_protection=deletion_protection
    )

    lines = [
        '"""',
        f"Revision: {next_id}",
        f"Parent: {parent_id}",
        f"Created: {now}",
        f"Description: {message or 'Auto-generated migration'}",
        '"""',
        "from __future__ import annotations",
        "",
        "import json",
        "from typing import TYPE_CHECKING",
        "",
        "if TYPE_CHECKING:",
        "    from redis.asyncio import Redis",
        "",
        f"MODELS_SNAPSHOT = {snapshot_json!r}",
        "",
        f"CHANGES = {changes_json!r}",
        "",
        "",
        upgrade_body,
        "",
        "",
        downgrade_body,
        "",
    ]
    content = "\n".join(lines)

    path.write_text(content)
    return path


def generate_init(
    migrations_dir: Path,
    snapshot: list[ModelSnapshot],
) -> Path:
    """Generate the ``0000_init.py`` baseline revision."""
    migrations_dir.mkdir(parents=True, exist_ok=True)
    path = migrations_dir / "0000_init.py"
    now = datetime.now(timezone.utc).isoformat()
    snapshot_json = json.dumps(snapshot, indent=2)

    lines = [
        '"""',
        "Revision: 0000",
        "Parent: None",
        f"Created: {now}",
        "Description: Initial schema snapshot",
        '"""',
        "from __future__ import annotations",
        "",
        "from typing import TYPE_CHECKING",
        "",
        "if TYPE_CHECKING:",
        "    from redis.asyncio import Redis",
        "",
        f"MODELS_SNAPSHOT = {snapshot_json!r}",
        "",
        "",
        "async def upgrade(redis: Redis, scan_match: dict[str, str]) -> None:",
        "    pass",
        "",
        "",
        "async def downgrade(redis: Redis, scan_match: dict[str, str]) -> None:",
        "    pass",
        "",
    ]
    content = "\n".join(lines)

    path.write_text(content)
    return path


def _slugify(text: str) -> str:
    """Convert text to a filename-safe slug."""
    slug = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return slug[:40] if slug else "auto"
