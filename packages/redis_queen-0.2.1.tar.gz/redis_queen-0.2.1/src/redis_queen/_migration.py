"""Migration staging and application engine."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from redis_queen._revision import list_revisions, load_revision_module
from redis_queen._state import get_state
from redis_queen._types import MigrationPlan

if TYPE_CHECKING:
    from pathlib import Path

    from redis.asyncio import Redis

    from redis_queen._decorator import RegisteredModel


async def run_revision(
    redis: Redis,  # type: ignore[type-arg]
    revision_path: Path,
    registered_models: list[RegisteredModel],
    *,
    direction: str = "up",
) -> None:
    """Execute a revision's upgrade or downgrade function."""
    module = load_revision_module(revision_path)

    scan_match: dict[str, str] = {}
    for rm in registered_models:
        if rm.match:
            name = f"{rm.model_class.__module__}.{rm.model_class.__qualname__}"
            scan_match[name] = rm.match

    func = module.upgrade if direction == "up" else module.downgrade
    await func(redis, scan_match)


async def apply_revision(
    redis: Redis,  # type: ignore[type-arg]
    migrations_collection: str,
    revision_id: str,
    *,
    direction: str = "up",
) -> None:
    """Update the migration state after a revision is applied."""
    state = await get_state(redis, migrations_collection)
    if direction == "up":
        state["applied_revisions"].append(revision_id)
        state["current_revision"] = revision_id
    else:
        if revision_id in state["applied_revisions"]:
            state["applied_revisions"].remove(revision_id)
        state["current_revision"] = (
            state["applied_revisions"][-1] if state["applied_revisions"] else None
        )

    await redis.set(
        f"redis_queen:{migrations_collection}:state",
        json.dumps(state),
    )


async def migrate_up(
    redis: Redis,  # type: ignore[type-arg]
    migrations_dir: Path,
    migrations_collection: str,
    registered_models: list[RegisteredModel],
    *,
    target_revision: str | None = None,
    auto_apply: bool = False,
) -> list[MigrationPlan]:
    """Run pending upgrades up to *target_revision*."""
    state = await get_state(redis, migrations_collection)
    revisions = list_revisions(migrations_dir)

    applied = set(state["applied_revisions"])
    pending = [r for r in revisions if r["revision_id"] not in applied]

    if target_revision is not None:
        pending = [r for r in pending if r["revision_id"] <= target_revision]

    plans: list[MigrationPlan] = []
    for rev in pending:
        plan = MigrationPlan(
            revision_id=rev["revision_id"],
            direction="up",
            changes=[],
        )
        plans.append(plan)

        if auto_apply:
            rev_file = _find_revision_file(migrations_dir, rev["revision_id"])
            await run_revision(redis, rev_file, registered_models, direction="up")
            await apply_revision(
                redis,
                migrations_collection,
                rev["revision_id"],
                direction="up",
            )

    return plans


async def migrate_down(
    redis: Redis,  # type: ignore[type-arg]
    migrations_dir: Path,
    migrations_collection: str,
    registered_models: list[RegisteredModel],
    *,
    target_revision: str | None = None,
    auto_apply: bool = False,
) -> list[MigrationPlan]:
    """Run downgrades down to *target_revision*.

    If *target_revision* is ``None``, downgrade to root (revert all).
    """
    state = await get_state(redis, migrations_collection)
    applied_list = list(state["applied_revisions"])

    if target_revision is not None:
        to_revert = [r for r in reversed(applied_list) if r > target_revision]
    else:
        to_revert = list(reversed(applied_list))

    plans: list[MigrationPlan] = []
    for rev_id in to_revert:
        plan = MigrationPlan(
            revision_id=rev_id,
            direction="down",
            changes=[],
        )
        plans.append(plan)

        if auto_apply:
            rev_file = _find_revision_file(migrations_dir, rev_id)
            await run_revision(redis, rev_file, registered_models, direction="down")
            await apply_revision(
                redis,
                migrations_collection,
                rev_id,
                direction="down",
            )

    return plans


async def apply_plan(
    redis: Redis,  # type: ignore[type-arg]
    plan: MigrationPlan,
    migrations_collection: str,
) -> None:
    """Update state for a plan (called after staging confirmation)."""
    await apply_revision(
        redis,
        migrations_collection,
        plan["revision_id"],
        direction=plan["direction"],
    )


async def auto_migrate_up(
    redis: Redis | None = None,  # type: ignore[type-arg]
    *,
    target_revision: str | None = None,
) -> list[MigrationPlan]:
    """Resolve config, connect to Redis, and apply all pending upgrades.

    Uses the active profile (``REDIS_QUEEN_PROFILE`` env var or
    default) and auto-applies without prompting.  Optionally pass an
    existing *redis* client to reuse a connection::

        await auto_migrate_up()
        await auto_migrate_up(existing_redis_client)
    """
    from redis_queen._config import load_config, profile_redis_url, resolve_profile
    from redis_queen._discovery import discover_models

    config = load_config()
    profile = resolve_profile(config)
    migrations_collection = profile.get("migrations_collection", "default")
    models = discover_models(
        profile.get("model_search_path", []),
        config["pyproject_dir"],
        collection_filter=migrations_collection,
    )

    if redis is not None:
        return await migrate_up(
            redis,
            config["migrations_dir"],
            migrations_collection,
            models,
            target_revision=target_revision,
            auto_apply=True,
        )

    from redis.asyncio import Redis as AsyncRedis

    url = profile_redis_url(profile)
    async with AsyncRedis.from_url(url, decode_responses=True) as client:
        return await migrate_up(
            client,
            config["migrations_dir"],
            migrations_collection,
            models,
            target_revision=target_revision,
            auto_apply=True,
        )


def _find_revision_file(migrations_dir: Path, revision_id: str) -> Path:
    """Find the migration file for a given revision ID."""
    for f in migrations_dir.iterdir():
        if f.is_file() and f.name.startswith(revision_id) and f.suffix == ".py":
            return f
    msg = f"Migration file for revision {revision_id} not found in {migrations_dir}"
    raise FileNotFoundError(msg)
