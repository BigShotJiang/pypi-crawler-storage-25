"""Model decorator and field annotation for redis-queen."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, NamedTuple

from redis_queen._types import ModelSnapshot

if TYPE_CHECKING:
    from collections.abc import Callable

    from pydantic import BaseModel

_MODEL_REGISTRY: dict[str, RegisteredModel] = {}


class MigratesFrom(NamedTuple):
    """Annotated metadata marker indicating a field was renamed."""

    old_name: str


def migrates_from(old_name: str) -> MigratesFrom:
    """Create an ``Annotated`` metadata marker for a field rename.

    Usage::

        class MyModel(BaseModel):
            new_name: Annotated[str, migrates_from("old_name")]
    """
    return MigratesFrom(old_name=old_name)


class RegisteredModel(NamedTuple):
    """A Pydantic model registered for migration tracking."""

    model_class: type[BaseModel]
    collection: str | None
    key: str | None
    match: str | None


def registered_model_qualified_name(rm: RegisteredModel) -> str:
    """Return the fully-qualified name of a registered model."""
    cls = rm.model_class
    return f"{cls.__module__}.{cls.__qualname__}"


def registered_model_snapshot(rm: RegisteredModel) -> ModelSnapshot:
    """Create a snapshot of the current model state."""
    return ModelSnapshot(
        qualified_name=registered_model_qualified_name(rm),
        collection=rm.collection,
        key=rm.key,
        match=rm.match,
        schema=rm.model_class.model_json_schema(),
    )


def registered_model_key_placeholders(rm: RegisteredModel) -> list[str]:
    """Extract ``{placeholder}`` names from the key pattern."""
    if rm.key is None:
        return []
    return re.findall(r"\{([^}]+)\}", rm.key)


def registered_model_resolve_key(rm: RegisteredModel, *args: str, **kwargs: str) -> str:
    """Format the key pattern using positional and/or keyword arguments.

    Works like ``str.format``::

        # positional
        resolve_key(rm, "123")          # "user:123:profile:"
        # keyword
        resolve_key(rm, user_id="123")  # "user:123:profile:"
    """
    if rm.key is None:
        msg = f"Model {registered_model_qualified_name(rm)} has no key pattern"
        raise ValueError(msg)
    placeholders = registered_model_key_placeholders(rm)
    # Map positional args to named placeholders so both styles work
    merged = dict(kwargs)
    for i, value in enumerate(args):
        if i >= len(placeholders):
            msg = (
                f"Cannot resolve key '{rm.key}' "
                f"(placeholders: {placeholders}): "
                f"too many positional args ({len(args)})"
            )
            raise ValueError(msg)
        name = placeholders[i]
        if name in merged:
            msg = (
                f"Cannot resolve key '{rm.key}': "
                f"'{name}' given as both positional and keyword"
            )
            raise ValueError(msg)
        merged[name] = value
    try:
        return rm.key.format(**merged)
    except KeyError as e:
        msg = f"Cannot resolve key '{rm.key}' (placeholders: {placeholders}): {e}"
        raise ValueError(msg) from e


def _key_to_match(key: str) -> str:
    """Convert a key pattern with ``{placeholders}`` to a SCAN glob.

    ``"user:{id}:profile:"`` → ``"user:*:profile:*"``
    ``"item:"``             → ``"item:*"``
    """
    pattern = re.sub(r"\{[^}]+\}", "*", key)
    # Collapse consecutive wildcards
    pattern = re.sub(r"\*+", "*", pattern)
    # Ensure it ends with a wildcard
    if not pattern.endswith("*"):
        pattern += "*"
    return pattern


def redis_queen(
    *,
    collection: str | None = None,
    key: str | None = None,
    match: str | None = None,
) -> Callable[[type[BaseModel]], type[BaseModel]]:
    """Decorator to register a Pydantic model for Redis migration tracking.

    At least one of ``key`` or ``match`` must be provided.  If only ``key``
    is given, ``match`` is derived by replacing ``{placeholders}`` with
    ``*`` (e.g. ``"user:{id}:profile:"`` → ``"user:*:profile:*"``).
    """
    if key is None and match is None:
        msg = "At least one of 'key' or 'match' must be provided"
        raise ValueError(msg)

    if match is not None:
        resolved_match = match
    else:
        assert key is not None  # guaranteed by the guard above
        resolved_match = _key_to_match(key)

    def decorator(cls: type[BaseModel]) -> type[BaseModel]:
        qualified = f"{cls.__module__}.{cls.__qualname__}"
        _MODEL_REGISTRY[qualified] = RegisteredModel(
            model_class=cls,
            collection=collection,
            key=key,
            match=resolved_match,
        )
        return cls

    return decorator


def get_registry() -> dict[str, RegisteredModel]:
    """Return a copy of the model registry."""
    return dict(_MODEL_REGISTRY)


def get_registered_model(model: type[BaseModel]) -> RegisteredModel:
    """Look up a model in the registry, raising ``ValueError`` if not found."""
    qualified = f"{model.__module__}.{model.__qualname__}"
    if qualified not in _MODEL_REGISTRY:
        msg = f"Model {qualified} is not registered with @redis_queen"
        raise ValueError(msg)
    return _MODEL_REGISTRY[qualified]
