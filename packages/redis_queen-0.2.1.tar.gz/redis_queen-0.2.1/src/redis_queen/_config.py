"""Configuration loading from pyproject.toml."""

from __future__ import annotations

import inspect
import os

try:
    import tomllib  # ty: ignore[unresolved-import]
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore[no-redef]  # ty: ignore[unresolved-import]
from pathlib import Path
from typing import Any, TypedDict

PROFILE_ENV_VAR = "REDIS_QUEEN_PROFILE"


class Profile(TypedDict, total=False):
    """A redis-queen profile from pyproject.toml."""

    name: str  # required
    default: bool
    host: str
    port: int
    username: str | None
    password: str | None
    db: int
    migrations_collection: str
    model_search_path: list[str]


class Config(TypedDict):
    """Top-level redis-queen configuration."""

    migrations_dir: Path
    pyproject_dir: Path
    profiles: dict[str, Profile]
    deletion_protection: bool | int


def _expandvars_recursive(value: Any) -> Any:
    """Apply ``os.expandvars`` recursively to all string values."""
    if isinstance(value, str):
        return os.path.expandvars(value)
    if isinstance(value, dict):
        return {k: _expandvars_recursive(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expandvars_recursive(v) for v in value]
    return value


def _find_pyproject(start: Path | None = None) -> Path:
    """Find ``pyproject.toml`` containing ``[tool.redis-queen]``.

    Search order:
    1. From the external caller's directory upward to cwd
    2. From cwd upward to the filesystem root
    """
    cwd = Path.cwd().resolve()
    caller = _caller_dir()

    # 1. Caller dir up to cwd
    if caller is not None:
        result = _search_upward(caller, stop=cwd)
        if result is not None:
            return result

    # 2. cwd upward to root
    result = _search_upward(cwd)
    if result is not None:
        return result

    searched = f"{caller} -> {cwd} -> /" if caller else f"{cwd} -> /"
    msg = f"Could not find pyproject.toml with [tool.redis-queen] (searched {searched})"
    raise FileNotFoundError(msg)


def _search_upward(start: Path, *, stop: Path | None = None) -> Path | None:
    """Walk from *start* upward, checking each ``pyproject.toml``."""
    current = start.resolve()
    stop = stop.resolve() if stop is not None else None
    while True:
        candidate = current / "pyproject.toml"
        if candidate.is_file() and _has_redis_queen_section(candidate):
            return candidate
        if stop is not None and current == stop:
            return None
        parent = current.parent
        if parent == current:
            return None
        current = parent


def _caller_dir() -> Path | None:
    """Find the directory of the first caller outside ``redis_queen``."""
    for frame_info in inspect.stack():
        module = inspect.getmodule(frame_info.frame)
        if module is None:
            continue
        mod_name = module.__name__ or ""
        if not mod_name.startswith("redis_queen"):
            filename = frame_info.filename
            if filename and filename != "<string>":
                return Path(filename).resolve().parent
    return None


def _has_redis_queen_section(path: Path) -> bool:
    """Check if a pyproject.toml has a ``[tool.redis-queen]`` section."""
    with path.open("rb") as f:
        data = tomllib.load(f)
    return bool(data.get("tool", {}).get("redis-queen"))


def load_config(pyproject_path: Path | None = None) -> Config:
    """Load ``[tool.redis-queen]`` from *pyproject_path*.

    If *pyproject_path* is ``None``, searches upward from cwd.
    """
    path = pyproject_path or _find_pyproject()
    with path.open("rb") as f:
        data = tomllib.load(f)

    tool_config: dict[str, Any] = data.get("tool", {}).get("redis-queen", {})
    if not tool_config:
        msg = f"No [tool.redis-queen] section in {path}"
        raise ValueError(msg)

    pyproject_dir = path.parent
    migrations_dir = pyproject_dir / tool_config.get("migrations_dir", "migrations")

    raw_profiles: dict[str, Any] = tool_config.get("profiles", {})
    if not raw_profiles:
        msg = "No profiles defined in [tool.redis-queen.profiles]"
        raise ValueError(msg)

    profiles: dict[str, Profile] = {}
    default_count = 0
    for name, raw in raw_profiles.items():
        expanded = _expandvars_recursive(raw)
        profile = Profile(name=name, **expanded)
        if profile.get("default", False):
            default_count += 1
        profiles[name] = profile

    if default_count == 0:
        msg = "No default profile found (set default = true on exactly one profile)"
        raise ValueError(msg)
    if default_count > 1:
        msg = (
            "Multiple default profiles found (only one profile may have default = true)"
        )
        raise ValueError(msg)

    return Config(
        migrations_dir=migrations_dir,
        pyproject_dir=pyproject_dir,
        profiles=profiles,
        deletion_protection=tool_config.get("deletion_protection", False),
    )


def resolve_profile(
    config: Config,
    profile_name: str | None = None,
) -> Profile:
    """Resolve the active profile.

    Resolution order: *profile_name* arg > ``REDIS_QUEEN_PROFILE`` env var
    > profile with ``default = true``.
    """
    name = profile_name or os.environ.get(PROFILE_ENV_VAR)
    if name is not None:
        if name not in config["profiles"]:
            msg = f"Profile '{name}' not found in configuration"
            raise ValueError(msg)
        return config["profiles"][name]

    for profile in config["profiles"].values():
        if profile.get("default", False):
            return profile

    # Should not reach here because load_config validates exactly one default
    msg = "No default profile found"
    raise ValueError(msg)


def profile_redis_url(profile: Profile) -> str:
    """Build a Redis URL from a profile."""
    host = profile.get("host", "localhost")
    port = profile.get("port", 6379)
    db = profile.get("db", 0)
    username = profile.get("username")
    password = profile.get("password")
    auth = ""
    if username and password:
        auth = f"{username}:{password}@"
    elif password:
        auth = f":{password}@"
    return f"redis://{auth}{host}:{port}/{db}"
