"""Model discovery by importing modules from configured search paths."""

from __future__ import annotations

import contextlib
import importlib
import sys
from typing import TYPE_CHECKING

from redis_queen._decorator import _MODEL_REGISTRY, RegisteredModel

if TYPE_CHECKING:
    from pathlib import Path


def discover_models(
    search_paths: list[str],
    pyproject_dir: Path,
    *,
    collection_filter: str | None = None,
) -> list[RegisteredModel]:
    """Import all ``.py`` files under *search_paths* and return registered models.

    Each path is resolved relative to *pyproject_dir*.  After importing,
    models are filtered by *collection_filter* (if set).
    """
    for search_path in search_paths:
        resolved = (pyproject_dir / search_path).resolve()
        if resolved.is_dir():
            _import_directory(resolved, pyproject_dir)
        elif resolved.is_file() and resolved.suffix == ".py":
            _import_file(resolved, pyproject_dir)
        else:
            # Treat as a dotted module path (e.g. "myapp.models")
            _import_module_path(search_path)

    models = list(_MODEL_REGISTRY.values())
    if collection_filter is not None:
        models = [
            m
            for m in models
            if m.collection is None or m.collection == collection_filter
        ]
    return models


def _import_directory(directory: Path, pyproject_dir: Path) -> None:
    """Walk *directory* and import all ``.py`` files as modules."""
    # Determine the base directory for computing module names.
    # If directory is under a ``src/`` layout, use ``src/`` as the base.
    src_dir = directory
    while src_dir != pyproject_dir:
        if src_dir.name == "src":
            break
        src_dir = src_dir.parent
    else:
        src_dir = directory.parent

    # Make sure the base is on sys.path so imports work.
    base_str = str(src_dir)
    if base_str not in sys.path:
        sys.path.insert(0, base_str)

    for py_file in directory.rglob("*.py"):
        if py_file.name.startswith("_"):
            continue
        module_name = _path_to_module(py_file, src_dir)
        if module_name and module_name not in sys.modules:
            with contextlib.suppress(Exception):
                importlib.import_module(module_name)


def _import_file(py_file: Path, pyproject_dir: Path) -> None:
    """Import a single ``.py`` file."""
    src_dir = py_file.parent
    while src_dir != pyproject_dir:
        if src_dir.name == "src":
            break
        src_dir = src_dir.parent
    else:
        src_dir = py_file.parent

    base_str = str(src_dir)
    if base_str not in sys.path:
        sys.path.insert(0, base_str)

    module_name = _path_to_module(py_file, src_dir)
    if module_name and module_name not in sys.modules:
        with contextlib.suppress(Exception):
            importlib.import_module(module_name)


def _import_module_path(module_path: str) -> None:
    """Import a dotted module path and recurse into submodules."""
    with contextlib.suppress(Exception):
        mod = importlib.import_module(module_path)
        # If it's a package, walk its submodules
        pkg_path = getattr(mod, "__path__", None)
        if pkg_path is not None:
            import pkgutil

            for info in pkgutil.walk_packages(pkg_path, prefix=module_path + "."):
                if info.name not in sys.modules:
                    with contextlib.suppress(Exception):
                        importlib.import_module(info.name)


def _path_to_module(py_file: Path, base: Path) -> str | None:
    """Convert a file path to a dotted module name relative to *base*."""
    try:
        relative = py_file.relative_to(base)
    except ValueError:
        return None
    parts = list(relative.with_suffix("").parts)
    if not parts:
        return None
    # Convert ``__init__`` to the package name
    if parts[-1] == "__init__":
        parts = parts[:-1]
    if not parts:
        return None
    return ".".join(parts)
