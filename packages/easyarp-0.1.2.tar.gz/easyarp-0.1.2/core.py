from scapy.all import ARP, Ether, srp, sendp, sniff
import re

def DataType(data):
    if not data:
        return "other"
    
    dst_type = ""
    mac_pattern = r"^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$"
    ip_pattern = r"^(\d{1,3}\.){3}\d{1,3}$"

    if re.match(mac_pattern, data):
        return "mac"

    elif re.match(ip_pattern, data):
        return "ip"
    else:
        return "other"

class ArpDestination:
    def __init__(self, DIP=None , DMAC=None):
        self.DIP = DIP
        self.DMAC = DMAC

class ArpSource:
    def __init__(self, SIP=None , SMAC=None):
        self.SIP = SIP
        self.SMAC = SMAC

class ArpPacket:
    def __init__(self, ADestination: ArpDestination=None , Asource: ArpSource=None , Type=None):
        self.Destination = ADestination
        self.Source= Asource
        self.Type = Type

def ErrCheck(packet: ArpPacket , Mode=None):
    if not Mode:
        return False
    
    if not str(Mode).lower() in ["request" , "reply" , "req" , "rep"]:
        return False
    else:
        Mode = Mode.lower()
        if Mode in ["request", "req"]:
            Mode = "req"
        elif Mode in ["reply", "rep"]:
            Mode = "rep"
        else:
            return False

    SIP = packet.Source.SIP
    SMAC = packet.Source.SMAC
    DIP = packet.Destination.DIP
    DMAC = packet.Destination.DMAC

    if Mode == "req":
        if DIP == None:
            print("[EASYARP] Destination IP is Required.")
            return False
        
        if SIP == None:
            print("[EASYARP] Source IP is Required.")
            return False
        
    else:
        if DIP == None:
            print("[EASYARP] Destination IP is Required.")
            return False
        
        if SIP == None:
            print("[EASYARP] Source IP is Required.")
            return False

        if DMAC == None:
            print("[EASYARP] Destination MAC is Required.")
            return False
        
        if SMAC == None:
            print("[EASYARP] Source IP is Required.")
            return False

    return True

def BroadCastAsk(Packet: ArpPacket):
    check = ErrCheck(Packet , Mode="request")
    if check==False:
        return
    
    if not Packet.Destination or not Packet.Destination.DIP:
        return None

    pkt = Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(
            op=1,
            pdst=Packet.Destination.DIP
        )
    
    ans = srp(pkt , verbose=False , timeout=5)[0]
    for s, r in ans:
        return f"{r.hwsrc}"

def ArpRequest(Packet: ArpPacket):
    check = ErrCheck(Packet , Mode="request")
    if check==False:
        return

    PacketDestinationIP = Packet.Destination.DIP
    PacketSourceIP = Packet.Source.SIP
    Dmac = Packet.Destination.DMAC

    if Packet.Destination.DMAC == None:
        Dmac = BroadCastAsk(Packet=Packet)
        if DataType(Dmac) != "mac":
            print("[EASYARP] Invalid Destination.")
            return

    pkt = Ether(dst=Dmac)/ARP(
            op=1,
            pdst=Packet.Destination.DIP
        )
    
    ans = srp(pkt , verbose=False , timeout=5)[0]
    for s, r in ans:
        return f"{r.hwsrc}"

def ArpReply(Packet: ArpPacket):
    check = ErrCheck(Packet , Mode="reply")
    if check==False:
        return

    DIP = Packet.Destination.DIP
    SIP = Packet.Source.SIP
    DMAC = Packet.Destination.DMAC
    SMAC = Packet.Source.SMAC

    if DataType(DIP) != "ip":
        print("[EASYARP] Invalid Destination IP")
        return

    if DataType(SIP) != "ip":
        print("[EASYARP] Invalid Source IP")
        return 
    
    if DataType(DMAC) != "mac":
        print("[EASYARP] Invalid Destination MAC")
        return 
    
    if DataType(SMAC) != "mac":
        print("[EASYARP] Invalid Source MAC")
        return 

    pkt = Ether(dst=DMAC)/ARP(
            op=2,
            psrc=SIP,
            hwsrc=SMAC,
            pdst=DIP,
            hwdst=DMAC
        )
    
    try:
        sendp(pkt, verbose=0)
    except Exception:
        print(f"[EASYARP] Failed to send Packet.")

def CaptureArpPackets(cnt: int):
    raw_pkts = sniff(cnt , filter="arp")
    pure_packets = []

    for pkt in raw_pkts:
        if pkt.haslayer(ARP):
            pdst = pkt[ARP].pdst
            hwdst = pkt[ARP].hwdst
            psrc = pkt[ARP].psrc
            hwsrc = pkt[ARP].hwsrc
            op = pkt[ARP].op 

            Dst = ArpDestination(DIP=pdst , DMAC=hwdst)
            Src = ArpSource(SIP=psrc , SMAC=hwsrc)
            type = ""
            if op == 1:
                type = "request"
            else:
                type = "reply"

            Pkt = ArpPacket(Dst , Src , Type=type)
            pure_packets.append(Pkt)

    return pure_packets

