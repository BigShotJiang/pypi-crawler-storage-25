"""Base client with shared HTTP transport logic, retry, and error handling.

Provides both sync and async transports. Resource methods are transport-agnostic
and dispatch to whichever transport the client was constructed with.
"""

from __future__ import annotations

import logging
import math
import random
import time
from typing import Any
from urllib.parse import urlparse

import httpx

from kalshi.auth import KalshiAuth
from kalshi.config import KalshiConfig
from kalshi.errors import (
    KalshiAuthError,
    KalshiError,
    KalshiNotFoundError,
    KalshiRateLimitError,
    KalshiServerError,
    KalshiValidationError,
)

logger = logging.getLogger("kalshi")

RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
# DELETE excluded: cancel/batch_cancel are not safely idempotent
RETRYABLE_METHODS = {"GET", "HEAD", "OPTIONS"}


def _map_error(response: httpx.Response) -> KalshiError:
    """Map an HTTP error response to the appropriate SDK exception."""
    status = response.status_code
    try:
        body = response.json()
    except Exception:
        body = {}

    message = body.get("message") or body.get("error") or response.text or f"HTTP {status}"

    if status == 400:
        details = body.get("details") or body.get("errors")
        return KalshiValidationError(
            message=str(message),
            status_code=status,
            details=details if isinstance(details, dict) else None,
        )
    if status in (401, 403):
        return KalshiAuthError(message=str(message), status_code=status)
    if status == 404:
        return KalshiNotFoundError(message=str(message), status_code=status)
    if status == 429:
        retry_after = response.headers.get("Retry-After")
        retry_after_val: float | None = None
        if retry_after:
            try:
                retry_after_val = float(retry_after)
                # Reject non-finite/negative: NaN crashes time.sleep, negative busy-loops.
                if retry_after_val < 0 or not math.isfinite(retry_after_val):
                    retry_after_val = None
            except ValueError:
                retry_after_val = None  # HTTP-date format, fall back to computed backoff
        return KalshiRateLimitError(
            message=str(message), status_code=status, retry_after=retry_after_val
        )
    if status >= 500:
        return KalshiServerError(message=str(message), status_code=status)

    return KalshiError(message=str(message), status_code=status)


def _compute_backoff(attempt: int, config: KalshiConfig) -> float:
    """Exponential backoff with AWS "Full Jitter".

    Spreads colliding retries evenly across the full backoff window, so
    parallel clients that hit a rate limit at the same time don't bunch up
    in a narrow sub-window (the failure mode of fixed-magnitude jitter).
    Formula: ``sleep = random_uniform(0, min(cap, base * 2 ** attempt))``.
    Reference: https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/
    """
    capped = min(config.retry_base_delay * (2**attempt), config.retry_max_delay)
    return float(random.uniform(0, capped))


class SyncTransport:
    """Synchronous HTTP transport using httpx.Client."""

    def __init__(
        self,
        auth: KalshiAuth | None,
        config: KalshiConfig,
        *,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self._auth = auth
        self._config = config
        # Cached once: base_url is immutable on a frozen KalshiConfig.
        self._base_path = urlparse(config.base_url).path
        client_kwargs: dict[str, Any] = {
            "base_url": config.base_url,
            "timeout": config.timeout,
            "headers": config.extra_headers,
            "transport": transport,
            "http2": config.http2,
        }
        if config.limits is not None:
            client_kwargs["limits"] = config.limits
        self._client = httpx.Client(**client_kwargs)

    @property
    def is_authenticated(self) -> bool:
        """Whether this transport has auth credentials configured."""
        return self._auth is not None

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make an authenticated HTTP request with retry logic."""
        # Sign with path-only (not full URL). Kalshi expects: /trade-api/v2/endpoint
        sign_path = self._base_path + path
        last_error: KalshiError | None = None

        for attempt in range(self._config.max_retries + 1):
            auth_headers = self._auth.sign_request(method.upper(), sign_path) if self._auth else {}

            logger.debug(
                "Request: %s %s (attempt %d/%d)",
                method.upper(),
                path,
                attempt + 1,
                self._config.max_retries + 1,
            )

            try:
                response = self._client.request(
                    method=method.upper(),
                    url=path,
                    params=params,
                    json=json,
                    headers=auth_headers,
                )
            except httpx.TimeoutException as e:
                # F-O-09: don't interpolate httpx exception strings — they
                # include the full URL with query string and can leak
                # token-like values into uncaught-exception sinks. The
                # underlying exception is preserved via `__cause__`.
                last_error = KalshiError(f"Request timed out: {method.upper()} {path}")
                if method.upper() in RETRYABLE_METHODS and attempt < self._config.max_retries:
                    delay = _compute_backoff(attempt, self._config)
                    logger.warning("Timeout on %s %s, retrying in %.1fs", method, path, delay)
                    time.sleep(delay)
                    continue
                raise last_error from e
            except httpx.HTTPError as e:
                raise KalshiError(f"HTTP error: {method.upper()} {path}") from e

            logger.debug("Response: %s %s → %d", method.upper(), path, response.status_code)

            if response.is_success:
                return response

            error = _map_error(response)
            last_error = error

            # Only retry safe methods on transient errors
            should_retry = (
                response.status_code in RETRYABLE_STATUS_CODES
                and method.upper() in RETRYABLE_METHODS
                and attempt < self._config.max_retries
            )

            if not should_retry:
                raise error

            # Use Retry-After header if available for 429.
            # `is not None` — not truthy — so Retry-After: 0 ("retry immediately") is honored.
            if (
                isinstance(error, KalshiRateLimitError)
                and error.retry_after is not None
            ):
                delay = min(error.retry_after, self._config.retry_max_delay)
            else:
                delay = _compute_backoff(attempt, self._config)

            logger.warning(
                "%s %s returned %d, retrying in %.1fs (attempt %d/%d)",
                method.upper(),
                path,
                response.status_code,
                delay,
                attempt + 1,
                self._config.max_retries,
            )
            time.sleep(delay)

        # Should not reach here, but just in case
        if last_error:
            raise last_error
        raise KalshiError("Max retries exhausted")

    def close(self) -> None:
        self._client.close()


class AsyncTransport:
    """Asynchronous HTTP transport using httpx.AsyncClient."""

    def __init__(
        self,
        auth: KalshiAuth | None,
        config: KalshiConfig,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._auth = auth
        self._config = config
        # Cached once: base_url is immutable on a frozen KalshiConfig.
        self._base_path = urlparse(config.base_url).path
        client_kwargs: dict[str, Any] = {
            "base_url": config.base_url,
            "timeout": config.timeout,
            "headers": config.extra_headers,
            "transport": transport,
            "http2": config.http2,
        }
        if config.limits is not None:
            client_kwargs["limits"] = config.limits
        self._client = httpx.AsyncClient(**client_kwargs)

    @property
    def is_authenticated(self) -> bool:
        """Whether this transport has auth credentials configured."""
        return self._auth is not None

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make an authenticated async HTTP request with retry logic."""
        import asyncio

        # Sign with path-only (not full URL). Kalshi expects: /trade-api/v2/endpoint
        sign_path = self._base_path + path
        last_error: KalshiError | None = None

        for attempt in range(self._config.max_retries + 1):
            auth_headers = self._auth.sign_request(method.upper(), sign_path) if self._auth else {}

            logger.debug(
                "Async request: %s %s (attempt %d/%d)",
                method.upper(),
                path,
                attempt + 1,
                self._config.max_retries + 1,
            )

            try:
                response = await self._client.request(
                    method=method.upper(),
                    url=path,
                    params=params,
                    json=json,
                    headers=auth_headers,
                )
            except httpx.TimeoutException as e:
                # F-O-09: see sync transport above.
                last_error = KalshiError(f"Request timed out: {method.upper()} {path}")
                if method.upper() in RETRYABLE_METHODS and attempt < self._config.max_retries:
                    delay = _compute_backoff(attempt, self._config)
                    logger.warning("Timeout on %s %s, retrying in %.1fs", method, path, delay)
                    await asyncio.sleep(delay)
                    continue
                raise last_error from e
            except httpx.HTTPError as e:
                raise KalshiError(f"HTTP error: {method.upper()} {path}") from e

            logger.debug(
                "Async response: %s %s → %d", method.upper(), path, response.status_code
            )

            if response.is_success:
                return response

            error = _map_error(response)
            last_error = error

            should_retry = (
                response.status_code in RETRYABLE_STATUS_CODES
                and method.upper() in RETRYABLE_METHODS
                and attempt < self._config.max_retries
            )

            if not should_retry:
                raise error

            # `is not None` so Retry-After: 0 ("retry immediately") is honored.
            if (
                isinstance(error, KalshiRateLimitError)
                and error.retry_after is not None
            ):
                delay = min(error.retry_after, self._config.retry_max_delay)
            else:
                delay = _compute_backoff(attempt, self._config)

            logger.warning(
                "%s %s returned %d, retrying in %.1fs (attempt %d/%d)",
                method.upper(),
                path,
                response.status_code,
                delay,
                attempt + 1,
                self._config.max_retries,
            )
            await asyncio.sleep(delay)

        if last_error:
            raise last_error
        raise KalshiError("Max retries exhausted")

    async def close(self) -> None:
        await self._client.aclose()
