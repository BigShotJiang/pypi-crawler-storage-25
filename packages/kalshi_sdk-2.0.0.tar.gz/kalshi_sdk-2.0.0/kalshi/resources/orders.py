"""Orders resource — create, get, cancel, list, batch operations."""

from __future__ import annotations

import builtins
from collections.abc import AsyncIterator, Iterator, Sequence
from decimal import Decimal
from typing import Any, overload

from kalshi.errors import KalshiError
from kalshi.models.common import Page
from kalshi.models.orders import (
    ActionLiteral,
    AmendOrderRequest,
    AmendOrderResponse,
    BatchCancelOrdersRequest,
    BatchCancelOrdersRequestOrder,
    BatchCreateOrdersRequest,
    CreateOrderRequest,
    DecreaseOrderRequest,
    Fill,
    Order,
    OrderQueuePosition,
    OrderStatusLiteral,
    SelfTradePreventionTypeLiteral,
    SideLiteral,
    TimeInForceLiteral,
)
from kalshi.resources._base import (
    AsyncResource,
    SyncResource,
    _check_request_exclusive,
    _join_tickers,
    _params,
    _validate_max_pages,
)
from kalshi.types import to_decimal

# ---------------------------------------------------------------------------
# Shared request-body builders (issue #46: dedup sync/async resource bodies).
#
# These helpers are pure: kwargs in, ``dict[str, Any]`` out. Both the sync and
# async resource methods call the same builder so dispatcher logic, model
# construction, and serialization live in one place.
# ---------------------------------------------------------------------------


def _build_create_order_body(
    request: CreateOrderRequest | None,
    *,
    ticker: str | None,
    side: SideLiteral | None,
    action: ActionLiteral | None,
    count: int | None,
    yes_price: float | str | int | None,
    no_price: float | str | int | None,
    client_order_id: str | None,
    expiration_ts: int | None,
    buy_max_cost: int | None,
    time_in_force: TimeInForceLiteral | None,
    post_only: bool | None,
    reduce_only: bool | None,
    self_trade_prevention_type: SelfTradePreventionTypeLiteral | None,
    order_group_id: str | None,
    cancel_order_on_pause: bool | None,
    subaccount: int | None,
) -> dict[str, Any]:
    _check_request_exclusive(
        request,
        ticker=ticker, side=side, action=action, count=count,
        yes_price=yes_price, no_price=no_price,
        client_order_id=client_order_id, expiration_ts=expiration_ts,
        buy_max_cost=buy_max_cost, time_in_force=time_in_force,
        post_only=post_only, reduce_only=reduce_only,
        self_trade_prevention_type=self_trade_prevention_type,
        order_group_id=order_group_id,
        cancel_order_on_pause=cancel_order_on_pause,
        subaccount=subaccount,
    )
    if request is None:
        if ticker is None or side is None:
            raise TypeError(
                "create() requires `ticker` and `side` (or pass `request=...`)"
            )
        request = CreateOrderRequest(
            ticker=ticker,
            side=side,
            action=action if action is not None else "buy",
            count=to_decimal(count if count is not None else 1),
            yes_price=to_decimal(yes_price) if yes_price is not None else None,
            no_price=to_decimal(no_price) if no_price is not None else None,
            client_order_id=client_order_id,
            expiration_ts=expiration_ts,
            buy_max_cost=buy_max_cost,
            time_in_force=time_in_force,
            post_only=post_only,
            reduce_only=reduce_only,
            self_trade_prevention_type=self_trade_prevention_type,
            order_group_id=order_group_id,
            cancel_order_on_pause=cancel_order_on_pause,
            subaccount=subaccount,
        )
    return request.model_dump(exclude_none=True, by_alias=True, mode="json")


def _build_batch_create_body(
    request: BatchCreateOrdersRequest | None,
    orders: Sequence[CreateOrderRequest] | None,
) -> dict[str, Any]:
    _check_request_exclusive(request, orders=orders)
    if request is None:
        if orders is None:
            raise TypeError(
                "batch_create() requires `orders` (or pass `request=...`)"
            )
        request = BatchCreateOrdersRequest(orders=list(orders))
    return request.model_dump(exclude_none=True, by_alias=True, mode="json")


def _build_batch_cancel_body(
    request: BatchCancelOrdersRequest | None,
    orders: Sequence[BatchCancelOrdersRequestOrder | str] | None,
) -> dict[str, Any]:
    _check_request_exclusive(request, orders=orders)
    if request is None:
        if orders is None:
            raise TypeError(
                "batch_cancel() requires `orders` (or pass `request=...`)"
            )
        normalized = [
            (
                BatchCancelOrdersRequestOrder(order_id=o) if isinstance(o, str) else o
            )
            for o in orders
        ]
        request = BatchCancelOrdersRequest(orders=normalized)
    return request.model_dump(exclude_none=True, by_alias=True, mode="json")


def _build_amend_body(
    request: AmendOrderRequest | None,
    *,
    ticker: str | None,
    side: SideLiteral | None,
    action: ActionLiteral | None,
    yes_price: float | str | int | None,
    no_price: float | str | int | None,
    count: int | None,
    client_order_id: str | None,
    updated_client_order_id: str | None,
    subaccount: int | None,
) -> dict[str, Any]:
    _check_request_exclusive(
        request,
        ticker=ticker, side=side, action=action,
        yes_price=yes_price, no_price=no_price, count=count,
        client_order_id=client_order_id,
        updated_client_order_id=updated_client_order_id,
        subaccount=subaccount,
    )
    if request is None:
        if ticker is None or side is None or action is None:
            raise TypeError(
                "amend() requires `ticker`, `side`, and `action` "
                "(or pass `request=...`)"
            )
        if yes_price is None and no_price is None and count is None:
            raise ValueError(
                "amend() requires at least one of yes_price, no_price, or count"
            )
        request = AmendOrderRequest(
            ticker=ticker,
            side=side,
            action=action,
            yes_price=to_decimal(yes_price) if yes_price is not None else None,
            no_price=to_decimal(no_price) if no_price is not None else None,
            count=to_decimal(count) if count is not None else None,
            client_order_id=client_order_id,
            updated_client_order_id=updated_client_order_id,
            subaccount=subaccount,
        )
    return request.model_dump(exclude_none=True, by_alias=True, mode="json")


def _build_decrease_body(
    request: DecreaseOrderRequest | None,
    *,
    reduce_by: int | None,
    reduce_to: int | None,
    subaccount: int | None,
) -> dict[str, Any]:
    _check_request_exclusive(
        request, reduce_by=reduce_by, reduce_to=reduce_to, subaccount=subaccount,
    )
    if request is None:
        # Method-level guards mirror DecreaseOrderRequest._enforce_reduce_xor
        # by design: the model-first v0.9 API will rely on the model validator,
        # but this path preserves nicer ValueError messages for current callers.
        if reduce_by is None and reduce_to is None:
            raise ValueError("decrease() requires either reduce_by or reduce_to")
        if reduce_by is not None and reduce_to is not None:
            raise ValueError("decrease() accepts reduce_by or reduce_to, not both")
        request = DecreaseOrderRequest(
            reduce_by=reduce_by,
            reduce_to=reduce_to,
            subaccount=subaccount,
        )
    return request.model_dump(exclude_none=True, by_alias=True, mode="json")


def _list_orders_params(
    *,
    ticker: str | None,
    event_ticker: str | None,
    status: OrderStatusLiteral | None,
    min_ts: int | None,
    max_ts: int | None,
    limit: int | None,
    cursor: str | None,
    subaccount: int | None,
) -> dict[str, Any]:
    return _params(
        ticker=ticker,
        event_ticker=event_ticker,
        status=status,
        min_ts=min_ts,
        max_ts=max_ts,
        limit=limit,
        cursor=cursor,
        subaccount=subaccount,
    )


def _fills_params(
    *,
    ticker: str | None,
    order_id: str | None,
    min_ts: int | None,
    max_ts: int | None,
    limit: int | None,
    cursor: str | None,
    subaccount: int | None,
) -> dict[str, Any]:
    return _params(
        ticker=ticker,
        order_id=order_id,
        min_ts=min_ts,
        max_ts=max_ts,
        limit=limit,
        cursor=cursor,
        subaccount=subaccount,
    )


def _queue_positions_params(
    *,
    market_tickers: builtins.list[str] | str | None,
    event_ticker: str | None,
    subaccount: int | None,
) -> dict[str, Any]:
    return _params(
        market_tickers=_join_tickers(market_tickers),
        event_ticker=event_ticker,
        subaccount=subaccount,
    )


def _parse_queue_position(data: dict[str, Any]) -> Decimal:
    raw = data.get("queue_position_fp")
    if raw is None:
        raw = data.get("queue_position")
    if raw is None:
        raise KalshiError(
            "Unexpected response for queue_position: "
            f"missing 'queue_position_fp' and 'queue_position' in {data!r}"
        )
    return to_decimal(raw)


class OrdersResource(SyncResource):
    """Sync orders API."""

    @overload
    def create(self, *, request: CreateOrderRequest) -> Order: ...
    @overload
    def create(
        self,
        *,
        ticker: str,
        side: SideLiteral,
        action: ActionLiteral | None = ...,
        count: int | None = ...,
        yes_price: float | str | int | None = ...,
        no_price: float | str | int | None = ...,
        client_order_id: str | None = ...,
        expiration_ts: int | None = ...,
        buy_max_cost: int | None = ...,
        time_in_force: TimeInForceLiteral | None = ...,
        post_only: bool | None = ...,
        reduce_only: bool | None = ...,
        self_trade_prevention_type: SelfTradePreventionTypeLiteral | None = ...,
        order_group_id: str | None = ...,
        cancel_order_on_pause: bool | None = ...,
        subaccount: int | None = ...,
    ) -> Order: ...
    def create(
        self,
        *,
        request: CreateOrderRequest | None = None,
        ticker: str | None = None,
        side: SideLiteral | None = None,
        action: ActionLiteral | None = None,
        count: int | None = None,
        yes_price: float | str | int | None = None,
        no_price: float | str | int | None = None,
        client_order_id: str | None = None,
        expiration_ts: int | None = None,
        buy_max_cost: int | None = None,
        time_in_force: TimeInForceLiteral | None = None,
        post_only: bool | None = None,
        reduce_only: bool | None = None,
        self_trade_prevention_type: SelfTradePreventionTypeLiteral | None = None,
        order_group_id: str | None = None,
        cancel_order_on_pause: bool | None = None,
        subaccount: int | None = None,
    ) -> Order:
        """Place a new order.

        ``buy_max_cost`` is integer cents per OpenAPI spec (e.g., 500 for $5.00).

        ``time_in_force`` accepts ``"fill_or_kill"``, ``"good_till_canceled"``,
        ``"immediate_or_cancel"``. Passing ``None`` omits the field and lets
        Kalshi apply its server-side default (``good_till_canceled``).

        v0.8.0 removed the ``type`` kwarg: the field was never defined in
        the OpenAPI spec. Callers passing ``type="limit"`` now get a
        ``TypeError``.

        v1.1 (#56): pass a pre-built ``request=CreateOrderRequest(...)`` instead
        of individual kwargs. Mutually exclusive with the kwarg form.
        """
        self._require_auth()
        body = _build_create_order_body(
            request,
            ticker=ticker, side=side, action=action, count=count,
            yes_price=yes_price, no_price=no_price,
            client_order_id=client_order_id, expiration_ts=expiration_ts,
            buy_max_cost=buy_max_cost, time_in_force=time_in_force,
            post_only=post_only, reduce_only=reduce_only,
            self_trade_prevention_type=self_trade_prevention_type,
            order_group_id=order_group_id,
            cancel_order_on_pause=cancel_order_on_pause,
            subaccount=subaccount,
        )
        data = self._post("/portfolio/orders", json=body)
        order_data = data.get("order", data)
        return Order.model_validate(order_data)

    def get(self, order_id: str) -> Order:
        self._require_auth()
        data = self._get(f"/portfolio/orders/{order_id}")
        order_data = data.get("order", data)
        return Order.model_validate(order_data)

    def cancel(self, order_id: str, *, subaccount: int | None = None) -> None:
        self._require_auth()
        params = _params(subaccount=subaccount)
        self._delete(f"/portfolio/orders/{order_id}", params=params)

    def list(
        self,
        *,
        ticker: str | None = None,
        event_ticker: str | None = None,
        status: OrderStatusLiteral | None = None,
        min_ts: int | None = None,
        max_ts: int | None = None,
        limit: int | None = None,
        cursor: str | None = None,
        subaccount: int | None = None,
    ) -> Page[Order]:
        self._require_auth()
        params = _list_orders_params(
            ticker=ticker, event_ticker=event_ticker, status=status,
            min_ts=min_ts, max_ts=max_ts, limit=limit, cursor=cursor,
            subaccount=subaccount,
        )
        return self._list("/portfolio/orders", Order, "orders", params=params)

    def list_all(
        self,
        *,
        ticker: str | None = None,
        event_ticker: str | None = None,
        status: OrderStatusLiteral | None = None,
        min_ts: int | None = None,
        max_ts: int | None = None,
        limit: int | None = None,
        subaccount: int | None = None,
        max_pages: int | None = None,
    ) -> Iterator[Order]:
        self._require_auth()
        _validate_max_pages(max_pages)
        params = _list_orders_params(
            ticker=ticker, event_ticker=event_ticker, status=status,
            min_ts=min_ts, max_ts=max_ts, limit=limit, cursor=None,
            subaccount=subaccount,
        )
        return self._list_all(
            "/portfolio/orders", Order, "orders",
            params=params, max_pages=max_pages,
        )

    @overload
    def batch_create(
        self,
        *,
        request: BatchCreateOrdersRequest,
    ) -> builtins.list[Order]: ...
    @overload
    def batch_create(
        self,
        orders: Sequence[CreateOrderRequest],
    ) -> builtins.list[Order]: ...
    def batch_create(
        self,
        orders: Sequence[CreateOrderRequest] | None = None,
        *,
        request: BatchCreateOrdersRequest | None = None,
    ) -> builtins.list[Order]:
        self._require_auth()
        body = _build_batch_create_body(request, orders)
        data = self._post("/portfolio/orders/batched", json=body)
        raw_orders = data.get("orders", [])
        return [Order.model_validate(o.get("order", o)) for o in raw_orders]

    @overload
    def batch_cancel(
        self,
        *,
        request: BatchCancelOrdersRequest,
    ) -> None: ...
    @overload
    def batch_cancel(
        self,
        orders: Sequence[BatchCancelOrdersRequestOrder | str],
    ) -> None: ...
    def batch_cancel(
        self,
        orders: Sequence[BatchCancelOrdersRequestOrder | str] | None = None,
        *,
        request: BatchCancelOrdersRequest | None = None,
    ) -> None:
        """Batch-cancel orders.

        Accepts a sequence of either ``BatchCancelOrdersRequestOrder``
        entries (for per-order ``subaccount`` routing), plain order-id
        strings (convenience shortcut — each is wrapped internally), or a
        mix of both. String entries are wrapped as
        ``BatchCancelOrdersRequestOrder(order_id=<id>)`` before serialization.

        BREAKING in v0.8.0: previously the method signature was
        ``batch_cancel(order_ids: list[str])`` and the wire body used the
        spec-deprecated ``ids`` field. v0.8.0 emits the spec-preferred
        ``orders`` field and renames the kwarg. Callers passing a plain
        list of order-id strings still work without code changes via the
        convenience shortcut.
        """
        self._require_auth()
        body = _build_batch_cancel_body(request, orders)
        self._delete_with_body("/portfolio/orders/batched", json=body)

    def fills(
        self,
        *,
        ticker: str | None = None,
        order_id: str | None = None,
        min_ts: int | None = None,
        max_ts: int | None = None,
        limit: int | None = None,
        cursor: str | None = None,
        subaccount: int | None = None,
    ) -> Page[Fill]:
        self._require_auth()
        params = _fills_params(
            ticker=ticker, order_id=order_id,
            min_ts=min_ts, max_ts=max_ts, limit=limit, cursor=cursor,
            subaccount=subaccount,
        )
        return self._list("/portfolio/fills", Fill, "fills", params=params)

    def fills_all(
        self,
        *,
        ticker: str | None = None,
        order_id: str | None = None,
        min_ts: int | None = None,
        max_ts: int | None = None,
        limit: int | None = None,
        subaccount: int | None = None,
        max_pages: int | None = None,
    ) -> Iterator[Fill]:
        self._require_auth()
        _validate_max_pages(max_pages)
        params = _fills_params(
            ticker=ticker, order_id=order_id,
            min_ts=min_ts, max_ts=max_ts, limit=limit, cursor=None,
            subaccount=subaccount,
        )
        return self._list_all(
            "/portfolio/fills", Fill, "fills",
            params=params, max_pages=max_pages,
        )

    @overload
    def amend(
        self, order_id: str, *, request: AmendOrderRequest,
    ) -> AmendOrderResponse: ...
    @overload
    def amend(
        self,
        order_id: str,
        *,
        ticker: str,
        side: SideLiteral,
        action: ActionLiteral,
        yes_price: float | str | int | None = ...,
        no_price: float | str | int | None = ...,
        count: int | None = ...,
        client_order_id: str | None = ...,
        updated_client_order_id: str | None = ...,
        subaccount: int | None = ...,
    ) -> AmendOrderResponse: ...
    def amend(
        self,
        order_id: str,
        *,
        request: AmendOrderRequest | None = None,
        ticker: str | None = None,
        side: SideLiteral | None = None,
        action: ActionLiteral | None = None,
        yes_price: float | str | int | None = None,
        no_price: float | str | int | None = None,
        count: int | None = None,
        client_order_id: str | None = None,
        updated_client_order_id: str | None = None,
        subaccount: int | None = None,
    ) -> AmendOrderResponse:
        self._require_auth()
        body = _build_amend_body(
            request,
            ticker=ticker, side=side, action=action,
            yes_price=yes_price, no_price=no_price, count=count,
            client_order_id=client_order_id,
            updated_client_order_id=updated_client_order_id,
            subaccount=subaccount,
        )
        data = self._post(f"/portfolio/orders/{order_id}/amend", json=body)
        return AmendOrderResponse.model_validate(data)

    @overload
    def decrease(
        self, order_id: str, *, request: DecreaseOrderRequest,
    ) -> Order: ...
    @overload
    def decrease(
        self,
        order_id: str,
        *,
        reduce_by: int | None = ...,
        reduce_to: int | None = ...,
        subaccount: int | None = ...,
    ) -> Order: ...
    def decrease(
        self,
        order_id: str,
        *,
        request: DecreaseOrderRequest | None = None,
        reduce_by: int | None = None,
        reduce_to: int | None = None,
        subaccount: int | None = None,
    ) -> Order:
        self._require_auth()
        body = _build_decrease_body(
            request, reduce_by=reduce_by, reduce_to=reduce_to,
            subaccount=subaccount,
        )
        data = self._post(f"/portfolio/orders/{order_id}/decrease", json=body)
        order_data = data.get("order", data)
        return Order.model_validate(order_data)

    def queue_positions(
        self,
        *,
        market_tickers: builtins.list[str] | str | None = None,
        event_ticker: str | None = None,
        subaccount: int | None = None,
    ) -> builtins.list[OrderQueuePosition]:
        self._require_auth()
        params = _queue_positions_params(
            market_tickers=market_tickers,
            event_ticker=event_ticker,
            subaccount=subaccount,
        )
        data = self._get("/portfolio/orders/queue_positions", params=params)
        raw = data.get("queue_positions", [])
        return [OrderQueuePosition.model_validate(item) for item in raw]

    def queue_position(self, order_id: str) -> Decimal:
        self._require_auth()
        data = self._get(f"/portfolio/orders/{order_id}/queue_position")
        return _parse_queue_position(data)


class AsyncOrdersResource(AsyncResource):
    """Async orders API."""

    @overload
    async def create(self, *, request: CreateOrderRequest) -> Order: ...
    @overload
    async def create(
        self,
        *,
        ticker: str,
        side: SideLiteral,
        action: ActionLiteral | None = ...,
        count: int | None = ...,
        yes_price: float | str | int | None = ...,
        no_price: float | str | int | None = ...,
        client_order_id: str | None = ...,
        expiration_ts: int | None = ...,
        buy_max_cost: int | None = ...,
        time_in_force: TimeInForceLiteral | None = ...,
        post_only: bool | None = ...,
        reduce_only: bool | None = ...,
        self_trade_prevention_type: SelfTradePreventionTypeLiteral | None = ...,
        order_group_id: str | None = ...,
        cancel_order_on_pause: bool | None = ...,
        subaccount: int | None = ...,
    ) -> Order: ...
    async def create(
        self,
        *,
        request: CreateOrderRequest | None = None,
        ticker: str | None = None,
        side: SideLiteral | None = None,
        action: ActionLiteral | None = None,
        count: int | None = None,
        yes_price: float | str | int | None = None,
        no_price: float | str | int | None = None,
        client_order_id: str | None = None,
        expiration_ts: int | None = None,
        buy_max_cost: int | None = None,
        time_in_force: TimeInForceLiteral | None = None,
        post_only: bool | None = None,
        reduce_only: bool | None = None,
        self_trade_prevention_type: SelfTradePreventionTypeLiteral | None = None,
        order_group_id: str | None = None,
        cancel_order_on_pause: bool | None = None,
        subaccount: int | None = None,
    ) -> Order:
        """Place a new order.

        ``buy_max_cost`` is integer cents per OpenAPI spec (e.g., 500 for $5.00).

        ``time_in_force`` accepts ``"fill_or_kill"``, ``"good_till_canceled"``,
        ``"immediate_or_cancel"``. Passing ``None`` omits the field and lets
        Kalshi apply its server-side default (``good_till_canceled``).

        v0.8.0 removed the ``type`` kwarg: the field was never defined in
        the OpenAPI spec. Callers passing ``type="limit"`` now get a
        ``TypeError``.

        v1.1 (#56): pass a pre-built ``request=CreateOrderRequest(...)`` instead
        of individual kwargs. Mutually exclusive with the kwarg form.
        """
        self._require_auth()
        body = _build_create_order_body(
            request,
            ticker=ticker, side=side, action=action, count=count,
            yes_price=yes_price, no_price=no_price,
            client_order_id=client_order_id, expiration_ts=expiration_ts,
            buy_max_cost=buy_max_cost, time_in_force=time_in_force,
            post_only=post_only, reduce_only=reduce_only,
            self_trade_prevention_type=self_trade_prevention_type,
            order_group_id=order_group_id,
            cancel_order_on_pause=cancel_order_on_pause,
            subaccount=subaccount,
        )
        data = await self._post("/portfolio/orders", json=body)
        order_data = data.get("order", data)
        return Order.model_validate(order_data)

    async def get(self, order_id: str) -> Order:
        self._require_auth()
        data = await self._get(f"/portfolio/orders/{order_id}")
        order_data = data.get("order", data)
        return Order.model_validate(order_data)

    async def cancel(self, order_id: str, *, subaccount: int | None = None) -> None:
        self._require_auth()
        params = _params(subaccount=subaccount)
        await self._delete(f"/portfolio/orders/{order_id}", params=params)

    async def list(
        self,
        *,
        ticker: str | None = None,
        event_ticker: str | None = None,
        status: OrderStatusLiteral | None = None,
        min_ts: int | None = None,
        max_ts: int | None = None,
        limit: int | None = None,
        cursor: str | None = None,
        subaccount: int | None = None,
    ) -> Page[Order]:
        self._require_auth()
        params = _list_orders_params(
            ticker=ticker, event_ticker=event_ticker, status=status,
            min_ts=min_ts, max_ts=max_ts, limit=limit, cursor=cursor,
            subaccount=subaccount,
        )
        return await self._list("/portfolio/orders", Order, "orders", params=params)

    def list_all(
        self,
        *,
        ticker: str | None = None,
        event_ticker: str | None = None,
        status: OrderStatusLiteral | None = None,
        min_ts: int | None = None,
        max_ts: int | None = None,
        limit: int | None = None,
        subaccount: int | None = None,
        max_pages: int | None = None,
    ) -> AsyncIterator[Order]:
        """Non-async method that returns an async iterator for direct use with `async for`."""
        self._require_auth()
        _validate_max_pages(max_pages)
        params = _list_orders_params(
            ticker=ticker, event_ticker=event_ticker, status=status,
            min_ts=min_ts, max_ts=max_ts, limit=limit, cursor=None,
            subaccount=subaccount,
        )
        return self._list_all(
            "/portfolio/orders", Order, "orders",
            params=params, max_pages=max_pages,
        )

    @overload
    async def batch_create(
        self,
        *,
        request: BatchCreateOrdersRequest,
    ) -> builtins.list[Order]: ...
    @overload
    async def batch_create(
        self,
        orders: Sequence[CreateOrderRequest],
    ) -> builtins.list[Order]: ...
    async def batch_create(
        self,
        orders: Sequence[CreateOrderRequest] | None = None,
        *,
        request: BatchCreateOrdersRequest | None = None,
    ) -> builtins.list[Order]:
        self._require_auth()
        body = _build_batch_create_body(request, orders)
        data = await self._post("/portfolio/orders/batched", json=body)
        raw_orders = data.get("orders", [])
        return [Order.model_validate(o.get("order", o)) for o in raw_orders]

    @overload
    async def batch_cancel(
        self,
        *,
        request: BatchCancelOrdersRequest,
    ) -> None: ...
    @overload
    async def batch_cancel(
        self,
        orders: Sequence[BatchCancelOrdersRequestOrder | str],
    ) -> None: ...
    async def batch_cancel(
        self,
        orders: Sequence[BatchCancelOrdersRequestOrder | str] | None = None,
        *,
        request: BatchCancelOrdersRequest | None = None,
    ) -> None:
        """Batch-cancel orders.

        Accepts a sequence of either ``BatchCancelOrdersRequestOrder``
        entries (for per-order ``subaccount`` routing), plain order-id
        strings (convenience shortcut — each is wrapped internally), or a
        mix of both. String entries are wrapped as
        ``BatchCancelOrdersRequestOrder(order_id=<id>)`` before serialization.

        BREAKING in v0.8.0: previously the method signature was
        ``batch_cancel(order_ids: list[str])`` and the wire body used the
        spec-deprecated ``ids`` field. v0.8.0 emits the spec-preferred
        ``orders`` field and renames the kwarg. Callers passing a plain
        list of order-id strings still work without code changes via the
        convenience shortcut.
        """
        self._require_auth()
        body = _build_batch_cancel_body(request, orders)
        await self._delete_with_body("/portfolio/orders/batched", json=body)

    async def fills(
        self,
        *,
        ticker: str | None = None,
        order_id: str | None = None,
        min_ts: int | None = None,
        max_ts: int | None = None,
        limit: int | None = None,
        cursor: str | None = None,
        subaccount: int | None = None,
    ) -> Page[Fill]:
        self._require_auth()
        params = _fills_params(
            ticker=ticker, order_id=order_id,
            min_ts=min_ts, max_ts=max_ts, limit=limit, cursor=cursor,
            subaccount=subaccount,
        )
        return await self._list("/portfolio/fills", Fill, "fills", params=params)

    def fills_all(
        self,
        *,
        ticker: str | None = None,
        order_id: str | None = None,
        min_ts: int | None = None,
        max_ts: int | None = None,
        limit: int | None = None,
        subaccount: int | None = None,
        max_pages: int | None = None,
    ) -> AsyncIterator[Fill]:
        self._require_auth()
        _validate_max_pages(max_pages)
        params = _fills_params(
            ticker=ticker, order_id=order_id,
            min_ts=min_ts, max_ts=max_ts, limit=limit, cursor=None,
            subaccount=subaccount,
        )
        return self._list_all(
            "/portfolio/fills", Fill, "fills",
            params=params, max_pages=max_pages,
        )

    @overload
    async def amend(
        self, order_id: str, *, request: AmendOrderRequest,
    ) -> AmendOrderResponse: ...
    @overload
    async def amend(
        self,
        order_id: str,
        *,
        ticker: str,
        side: SideLiteral,
        action: ActionLiteral,
        yes_price: float | str | int | None = ...,
        no_price: float | str | int | None = ...,
        count: int | None = ...,
        client_order_id: str | None = ...,
        updated_client_order_id: str | None = ...,
        subaccount: int | None = ...,
    ) -> AmendOrderResponse: ...
    async def amend(
        self,
        order_id: str,
        *,
        request: AmendOrderRequest | None = None,
        ticker: str | None = None,
        side: SideLiteral | None = None,
        action: ActionLiteral | None = None,
        yes_price: float | str | int | None = None,
        no_price: float | str | int | None = None,
        count: int | None = None,
        client_order_id: str | None = None,
        updated_client_order_id: str | None = None,
        subaccount: int | None = None,
    ) -> AmendOrderResponse:
        self._require_auth()
        body = _build_amend_body(
            request,
            ticker=ticker, side=side, action=action,
            yes_price=yes_price, no_price=no_price, count=count,
            client_order_id=client_order_id,
            updated_client_order_id=updated_client_order_id,
            subaccount=subaccount,
        )
        data = await self._post(f"/portfolio/orders/{order_id}/amend", json=body)
        return AmendOrderResponse.model_validate(data)

    @overload
    async def decrease(
        self, order_id: str, *, request: DecreaseOrderRequest,
    ) -> Order: ...
    @overload
    async def decrease(
        self,
        order_id: str,
        *,
        reduce_by: int | None = ...,
        reduce_to: int | None = ...,
        subaccount: int | None = ...,
    ) -> Order: ...
    async def decrease(
        self,
        order_id: str,
        *,
        request: DecreaseOrderRequest | None = None,
        reduce_by: int | None = None,
        reduce_to: int | None = None,
        subaccount: int | None = None,
    ) -> Order:
        self._require_auth()
        body = _build_decrease_body(
            request, reduce_by=reduce_by, reduce_to=reduce_to,
            subaccount=subaccount,
        )
        data = await self._post(f"/portfolio/orders/{order_id}/decrease", json=body)
        order_data = data.get("order", data)
        return Order.model_validate(order_data)

    async def queue_positions(
        self,
        *,
        market_tickers: builtins.list[str] | str | None = None,
        event_ticker: str | None = None,
        subaccount: int | None = None,
    ) -> builtins.list[OrderQueuePosition]:
        self._require_auth()
        params = _queue_positions_params(
            market_tickers=market_tickers,
            event_ticker=event_ticker,
            subaccount=subaccount,
        )
        data = await self._get("/portfolio/orders/queue_positions", params=params)
        raw = data.get("queue_positions", [])
        return [OrderQueuePosition.model_validate(item) for item in raw]

    async def queue_position(self, order_id: str) -> Decimal:
        self._require_auth()
        data = await self._get(f"/portfolio/orders/{order_id}/queue_position")
        return _parse_queue_position(data)
