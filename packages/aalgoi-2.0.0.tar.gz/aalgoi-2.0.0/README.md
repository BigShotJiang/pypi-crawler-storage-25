# AAlgoI: Artificial Algorithm Intelligence

**The self-optimizing algorithm selector that gets smarter with every run.**

### What is it?

AAlgoI automatically chooses the fastest algorithm for your problem—sorting, pathfinding, optimization—by learning from experience. It ships with a **pre-trained RL model** that knows which algorithm works best for your data shape, size, and constraints.

### Installation

```bash
pip install aalgoi
```

### 5-Second Demo

```python
from aalgoi import UniversalSolver

solver = UniversalSolver()

# Sorting
result = solver.solve("sort this list", [64, 34, 25, 12, 22, 11, 90])
# → Uses timsort (87% faster than quicksort on nearly-sorted data)

# Pathfinding
result = solver.solve("find shortest path", {
    'graph': {'A': {'B': 4, 'C': 2}, 'B': {'D': 5}, 'C': {'D': 1}},
    'start': 'A', 'end': 'D'
})
# → Uses Dijkstra (optimal for weighted graphs)

# Optimization
result = solver.solve("knapsack problem", {
    'items': [{'value': 60, 'weight': 10}, {'value': 100, 'weight': 20}],
    'capacity': 50
})
# → Uses greedy knapsack (2ms, 95% optimal)
```

### How It Works

1. **Context Engine** analyzes your data (size, patterns, constraints)
2. **Knowledge Graph** narrows candidates by problem type
3. **RL Agent** selects the best algorithm from experience
4. **Self-Healing** falls back to alternatives if execution fails

### Performance

| Problem Type | Algorithms Tested | AAlgoI Speedup |
| :--- | :--- | :--- |
| Sorting (nearly sorted) | 6 | **87% faster** |
| Pathfinding (sparse) | 3 | **45% faster** |
| Optimization (small) | 2 | **2ms vs 15ms** |

### Features

✅ **Zero-config** - Works out of the box  
✅ **Pre-trained** - No cold start, instant intelligence  
✅ **Self-learning** - Improves with every execution  
✅ **Explainable** - Knows *why* it chose an algorithm  
✅ **Extensible** - Add custom algorithms via registry  

### Advanced Usage

```python
# Custom configuration
solver = UniversalSolver(config={
    'use_bandit': True,      # Enable multi-armed bandit exploration
    'use_drift': True,       # Detect data distribution changes
    'kg_enabled': True       # Use knowledge graph reasoning
})

# Get explanation
result = solver.solve(problem, data)
print(result.explanation)
# → "Selected timsort because data is 94% nearly-sorted..."
```

### Requirements

- Python 3.8+
- torch>=2.0.0
- numpy>=1.24.0

### License

MIT License - Use freely in personal and commercial projects.

### Contributing

1. Fork the repo
2. Add your algorithm to `algorithms/`
3. Submit a PR with benchmark results

---

**Built with ❤️ by the AAlgoI team**
