"""
Windows-specific implementation of the PlatformDriver protocol using AI Vision.
"""
import json
import os
import time
from typing import Any

import pyautogui
import win32gui

from shared.datatypes import ChatMessage, SidebarRow
from shared.platform_api import PlatformDriver
from shared.sidebar_classification import (
    parse_threads_json,
    threads_to_sidebar_rows,
)
from shared.vision_backend import VisionBackend, create_vision_backend
from shared.vision_prompts import (
    CHAT_PANEL_PROMPT,
    CHAT_PANEL_SAFE_CLICK_PROMPT,
    COORDS_PROMPT_TEMPLATE,
    CURRENT_CHAT_PROMPT,
    NEW_MESSAGES_BUTTON_PROMPT,
    SIDEBAR_PROMPT,
)
from platform_win.find_wechat_window import find_wechat_window as find_window
from platform_win.vision import _force_foreground_window, capture_window
from shared.message_dedup import dedupe_chat_messages
from shared.vision_response_json import parse_json_object_from_model_text
from utils.image_stitcher import save_stitched_debug, stitch_screenshots


class WinDriver(PlatformDriver):
    def __init__(self, vision_backend: VisionBackend | None = None):
        self.hwnd: int = 0
        self.vision_ai: VisionBackend = vision_backend or create_vision_backend("openrouter")

    def find_wechat_window(self, app_name: str = "微信") -> int:
        """Finds the WeChat window and stores its handle."""
        self.hwnd = find_window(app_name=app_name)
        if not self.hwnd:
            raise RuntimeError(
                f"WeChat window '{app_name}' not found. Please ensure it is running."
            )
        print(f"[+] WeChat window '{app_name}' found with HWND: {self.hwnd}")
        return self.hwnd

    def _get_precise_row_coords(self, row: SidebarRow) -> tuple[int, int] | None:
        """
        Captures the full window and uses the AI to find the precise coordinates
        for a specific chat name. This is used for accurate clicking.
        """
        chat_name = row.name
        print(f"[*] Getting precise coordinates for '{chat_name}' using full screenshot...")
        full_screenshot = capture_window(self.hwnd)
        if not full_screenshot:
            print(f"[WARN] Failed to capture window for precise coordinate detection.")
            return None

        window_rect = win32gui.GetWindowRect(self.hwnd)
        window_left, window_top, _, _ = window_rect

        print(f"[DEBUG] Precise coord prompt chat_name: '{chat_name}'")
        prompt = COORDS_PROMPT_TEMPLATE.format(chat_name=chat_name)
        response_str = self.vision_ai.query(prompt, full_screenshot)

        if not response_str:
            print(f"[ERROR] Received no response from Vision AI for precise coordinates.")
            return None

        print(f"[DEBUG] Raw AI response for precise coords:\n{response_str}")

        try:
            data = parse_json_object_from_model_text(response_str)
            win_rel_bbox = data.get("bbox")

            if not win_rel_bbox or len(win_rel_bbox) != 4:
                print(f"[WARN] AI returned invalid bbox for '{chat_name}': {win_rel_bbox}")
                print(f"[DEBUG] Raw AI response for invalid bbox: {response_str}")
                return None

            img_width, img_height = full_screenshot.size
            scaled_x1 = int(win_rel_bbox[0] / 1000 * img_width)
            scaled_y1 = int(win_rel_bbox[1] / 1000 * img_height)
            scaled_x2 = int(win_rel_bbox[2] / 1000 * img_width)
            scaled_y2 = int(win_rel_bbox[3] / 1000 * img_height)

            abs_x1 = window_left + scaled_x1
            abs_y1 = window_top + scaled_y1
            abs_x2 = window_left + scaled_x2
            abs_y2 = window_top + scaled_y2

            center_x = (abs_x1 + abs_x2) // 2
            center_y = (abs_y1 + abs_y2) // 2

            print(f"[+] Precise coordinates for '{chat_name}' found: ({center_x}, {center_y})")
            return (center_x, center_y)

        except Exception as e:
            print(f"[ERROR] Failed to parse precise coordinate response for '{chat_name}'. Exception type: {type(e)}, message: {e}")
            print(f"Raw response was: {response_str}")
            return None

    def get_sidebar_rows(self, window: Any) -> list[SidebarRow]:
        """Gets all visible rows in the sidebar using the Vision AI."""
        hwnd = window
        full_screenshot = capture_window(hwnd)
        if not full_screenshot:
            print("[WARN] Failed to capture window for sidebar row detection.")
            return []

        window_left, window_top, _, _ = win32gui.GetWindowRect(hwnd)

        sidebar_width = int(full_screenshot.width * 0.3)
        sidebar_crop_box = (0, 0, sidebar_width, full_screenshot.height)
        sidebar_image = full_screenshot.crop(sidebar_crop_box)

        print("[*] Querying Vision AI to analyze sidebar...")
        response_str = self.vision_ai.query(SIDEBAR_PROMPT, sidebar_image)

        if not response_str:
            print("[ERROR] Received no response from Vision AI for sidebar analysis.")
            return []

        try:
            threads = parse_threads_json(response_str)
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            print(f"[ERROR] Failed to parse sidebar classification JSON: {e}")
            print(f"Raw response was: {response_str}")
            return []

        img_width, img_height = sidebar_image.size
        sidebar_rows = threads_to_sidebar_rows(
            threads, img_width, img_height, window_left, window_top
        )
        print(f"[+] AI identified {len(sidebar_rows)} sidebar rows.")
        return sidebar_rows

    def ensure_permissions(self) -> None:
        raise NotImplementedError

    def scroll_sidebar(self, window: Any, direction: str) -> None:
        """Scrolls the sidebar up or down by simulating mouse wheel movement."""
        hwnd = window
        if not self.hwnd:
            raise RuntimeError("WeChat window not found. Call find_wechat_window() first.")

        _force_foreground_window(hwnd)

        scroll_amount = 500
        if direction == "up":
            clicks = scroll_amount
        elif direction == "down":
            clicks = -scroll_amount
        else:
            raise ValueError(f"Invalid scroll direction: '{direction}'. Must be 'up' or 'down'.")

        left, top, right, bottom = win32gui.GetWindowRect(hwnd)
        sidebar_x = left + int((right - left) * 0.15)
        sidebar_y = top + int((bottom - top) * 0.5)

        print(f"[*] Scrolling sidebar {direction}...", end=" ")
        pyautogui.moveTo(sidebar_x, sidebar_y, duration=0.1)
        pyautogui.scroll(clicks)
        print("Done.")

    def get_row_name(self, row: Any) -> str:
        """Extracts the chat name from a SidebarRow."""
        if not isinstance(row, SidebarRow):
            return ""
        return row.name

    def get_row_badge_text(self, row: Any) -> str | None:
        """Extracts the badge text (e.g., unread count) from a SidebarRow."""
        if not isinstance(row, SidebarRow):
            return None
        return row.badge_text

    def scroll_chat_panel(self, direction: str = "down") -> None:
        """Scrolls the chat panel via mouse wheel at the message area (same as scroll_messages)."""
        if not self.hwnd:
            raise RuntimeError("WeChat window not found. Call find_wechat_window() first.")
        if direction == "up":
            clicks = 500
        elif direction == "down":
            clicks = -500
        else:
            raise ValueError(f"Invalid scroll direction: '{direction}'. Must be 'up' or 'down'.")
        _force_foreground_window(self.hwnd)
        left, top, right, bottom = win32gui.GetWindowRect(self.hwnd)
        message_panel_x = left + int((right - left) * 0.65)
        message_panel_y = top + int((bottom - top) * 0.5)
        print(f"[*] Scrolling chat panel {direction} with mouse wheel.")
        pyautogui.moveTo(message_panel_x, message_panel_y, duration=0.1)
        pyautogui.scroll(clicks)
        time.sleep(1.0)

    def get_chat_messages(self, chat_name: str) -> list[ChatMessage]:
        """
        Orchestrates the process of scrolling, capturing, stitching, and extracting
        chat messages from the current chat.
        This version scrolls UP, captures, and then reverses the sequence for stitching.
        """
        print(f"[*] Starting message extraction for '{chat_name}'...")

        self._activate_chat_panel_safely()

        self.click_new_messages_button()

        screenshots = []
        for i in range(10):
            self.scroll_chat_panel(direction="up")
            screenshot = capture_window(self.hwnd)
            if screenshot:
                screenshots.append(screenshot)

        if not screenshots:
            print("[WARN] No screenshots were captured.")
            return []

        print("[*] Reversing screenshot order for processing...")
        screenshots.reverse()

        all_messages = []
        chunk_size = 5
        screenshot_chunks = [screenshots[i:i + chunk_size] for i in range(0, len(screenshots), chunk_size)]

        print(f"[*] Processing {len(screenshots)} screenshots in {len(screenshot_chunks)} chunks of size {chunk_size}.")

        for i, chunk in enumerate(screenshot_chunks):
            print(f"--- Processing chunk {i+1}/{len(screenshot_chunks)} ---")
            if not chunk:
                continue

            stitched_image = stitch_screenshots(images=chunk, scroll_region=None)

            if not stitched_image:
                print(f"[ERROR] Failed to stitch chunk {i+1}.")
                continue

            debug_dir = os.environ.get("WECLAW_DEBUG_STITCH_DIR", "").strip()
            if debug_dir:
                save_stitched_debug(stitched_image, debug_dir, chat_name, i)

            try:
                response_str = self.vision_ai.query(
                    CHAT_PANEL_PROMPT, stitched_image, max_tokens=16384
                )
            except Exception as e:
                print(f"[ERROR] Vision AI query for chunk {i+1} failed: {e}")
                continue

            if not response_str:
                print(f"[ERROR] No response from AI for message extraction on chunk {i+1}.")
                continue

            try:
                data = parse_json_object_from_model_text(response_str)
                messages_data = data.get("messages", [])
                chunk_messages = []

                for j, msg_data in enumerate(messages_data):
                    if "content" not in msg_data:
                        print(f"[WARN] Chunk {i+1}, Msg {j+1}: Skipping message due to missing 'content': {msg_data}")
                        continue

                    try:
                        chunk_messages.append(ChatMessage(**msg_data))
                    except TypeError as e:
                        print(f"[WARN] Chunk {i+1}, Msg {j+1}: Skipping message during creation: {msg_data}. Error: {e}")

                if chunk_messages:
                    print(f"[+] Extracted {len(chunk_messages)} messages from chunk {i+1}.")
                    all_messages.extend(chunk_messages)
                else:
                    print(f"[WARN] No valid messages extracted from chunk {i+1}.")

            except Exception as e:
                print(f"[ERROR] Failed to parse messages from AI response for chunk {i+1}: {e}")
                print(f"Raw response was: {response_str}")
                continue

        out = dedupe_chat_messages(all_messages)
        print(f"[*] Finished processing all chunks. Total messages: {len(out)} ({len(all_messages)} raw).")
        return out

    def _activate_chat_panel_safely(self) -> None:
        """Finds a safe spot in the chat panel to click to activate the window."""
        print("[*] Activating chat panel with a safe click...")
        _force_foreground_window(self.hwnd)
        time.sleep(0.5) # Wait for window to be focused

        full_screenshot = capture_window(self.hwnd)
        if not full_screenshot:
            print("[WARN] Failed to capture window for safe click.")
            return

        window_rect = win32gui.GetWindowRect(self.hwnd)
        window_left, window_top, _, _ = window_rect

        # Define and crop to the chat panel region
        chat_panel_x1 = int(full_screenshot.width * 0.31)
        chat_panel_y1 = 50 # Avoid header
        chat_panel_x2 = int(full_screenshot.width * 0.95)
        chat_panel_y2 = full_screenshot.height - 50 # Avoid input area
        chat_panel_crop_box = (chat_panel_x1, chat_panel_y1, chat_panel_x2, chat_panel_y2)
        chat_panel_image = full_screenshot.crop(chat_panel_crop_box)

        # Query AI for a safe spot
        response_str = self.vision_ai.query(CHAT_PANEL_SAFE_CLICK_PROMPT, chat_panel_image)

        safe_click_coords = None
        bbox = None
        bbox_width = None
        bbox_height = None
        bbox_center_y = None
        bbox_valid = False
        if response_str:
            try:
                data = parse_json_object_from_model_text(response_str)
                bbox = data.get("bbox")
                if bbox and len(bbox) == 4:
                    bbox_width = bbox[2] - bbox[0]
                    bbox_height = bbox[3] - bbox[1]
                    bbox_center_y = (bbox[1] + bbox[3]) / 2
                    bbox_valid = (
                        bbox_width >= 80
                        and bbox_height >= 60
                        and bbox_center_y <= 750
                    )
                if bbox_valid:
                    # The AI is assumed to return coordinates in a 1000x1000 space
                    img_width, img_height = chat_panel_image.size
                    scaled_x1 = int(bbox[0] / 1000 * img_width)
                    scaled_y1 = int(bbox[1] / 1000 * img_height)
                    scaled_x2 = int(bbox[2] / 1000 * img_width)
                    scaled_y2 = int(bbox[3] / 1000 * img_height)

                    # Calculate center and convert to absolute screen coordinates
                    center_x = (scaled_x1 + scaled_x2) // 2
                    center_y = (scaled_y1 + scaled_y2) // 2
                    abs_x = window_left + chat_panel_x1 + center_x
                    abs_y = window_top + chat_panel_y1 + center_y
                    safe_click_coords = (abs_x, abs_y)
                    print(f"[+] AI identified safe click spot at: {safe_click_coords}")
                elif bbox:
                    print(f"[WARN] AI returned an unsafe click bbox: {bbox}")
            except Exception as e:
                print(f"[WARN] Could not parse safe click response from AI: {e}. Falling back to default.")

        # If AI fails or doesn't provide a spot, fall back to clicking the center
        if not safe_click_coords:
            print("[INFO] AI did not provide a safe click spot. Falling back to center of chat panel.")
            fallback_x = window_left + (chat_panel_x1 + chat_panel_x2) // 2
            fallback_y = window_top + (chat_panel_y1 + chat_panel_y2) // 2
            safe_click_coords = (fallback_x, fallback_y)

        pyautogui.moveTo(safe_click_coords[0], safe_click_coords[1], duration=0.2)
        pyautogui.click()
        time.sleep(0.5)

    def get_current_chat_name(self) -> str | None:
        """Captures the sidebar and uses AI to get the name of the currently selected (highlighted) chat."""
        print("[*] Identifying current chat name from sidebar highlight...")
        full_screenshot = capture_window(self.hwnd)
        if not full_screenshot:
            print("[WARN] Failed to capture window for chat name verification.")
            return None

        sidebar_width = int(full_screenshot.width * 0.3)
        sidebar_crop_box = (0, 0, sidebar_width, full_screenshot.height)
        sidebar_image = full_screenshot.crop(sidebar_crop_box)

        response_str = self.vision_ai.query(CURRENT_CHAT_PROMPT, sidebar_image)

        if not response_str:
            print(f"[ERROR] Received no response from Vision AI for chat name.")
            return None

        try:
            data = parse_json_object_from_model_text(response_str)
            chat_name = data.get("chat_name")

            if chat_name:
                print(f"[+] Current chat identified as: '{chat_name}'")
                return chat_name
            else:
                print(f"[WARN] AI did not return a chat_name.")
                return None

        except (AssertionError, KeyError) as e:
            print(f"[ERROR] Failed to parse chat name response. Exception: {e}")
            print(f"Raw response was: {response_str}")
            return None

    def _get_chat_panel_region(self) -> tuple[int, int, int, int]:
        """Calculates the bounding box of the chat panel region."""
        full_screenshot = capture_window(self.hwnd)
        if not full_screenshot:
            return (0, 0, 0, 0)

        chat_panel_x1 = int(full_screenshot.width * 0.31)
        chat_panel_y1 = 0 
        chat_panel_x2 = int(full_screenshot.width * 0.95)
        chat_panel_y2 = full_screenshot.height

        return (chat_panel_x1, chat_panel_y1, chat_panel_x2, chat_panel_y2)

    def click_new_messages_button(self) -> bool:
        """
        Checks for a "new messages" button and clicks it if found.
        Returns True if a button was clicked, False otherwise.
        """
        print("[*] Checking for 'new messages' button...")
        full_screenshot = capture_window(self.hwnd)
        if not full_screenshot:
            print("[WARN] Failed to capture window for new messages button check.")
            return False

        window_rect = win32gui.GetWindowRect(self.hwnd)
        window_left, window_top, _, _ = window_rect

        chat_panel_region = (
            int(full_screenshot.width * 0.31),
            0,
            int(full_screenshot.width * 0.95),
            full_screenshot.height
        )
        chat_panel_screenshot = full_screenshot.crop(chat_panel_region)

        response_str = self.vision_ai.query(NEW_MESSAGES_BUTTON_PROMPT, chat_panel_screenshot)

        if not response_str:
            print("[DEBUG] No response from AI for new messages button check.")
            return False

        try:
            data = parse_json_object_from_model_text(response_str)
            bbox = data.get("bbox")

            if not bbox:
                print("[DEBUG] No 'new messages' button found by AI.")
                return False

            abs_x1 = window_left + chat_panel_region[0] + bbox[0]
            abs_y1 = window_top + chat_panel_region[1] + bbox[1]
            abs_x2 = window_left + chat_panel_region[0] + bbox[2]
            abs_y2 = window_top + chat_panel_region[1] + bbox[3]

            center_x = (abs_x1 + abs_x2) // 2
            center_y = (abs_y1 + abs_y2) // 2

            print(f"[+] 'New messages' button found. Clicking at ({center_x}, {center_y}).")
            pyautogui.moveTo(center_x, center_y, duration=0.2)
            pyautogui.click()
            time.sleep(1) 
            return True

        except Exception as e:
            print(f"[ERROR] Failed to process AI response for new messages button: {e}")
            print(f"Raw response was: {response_str}")
            return False

    def click_row(self, row: SidebarRow, attempt: int = 0) -> None:
        """
        Clicks on a given SidebarRow element.
        On subsequent attempts, it can apply a vertical offset.
        """
        if not isinstance(row, SidebarRow):
            print(f"[WARN] click_row called with invalid type: {type(row)}")
            return

        coords = self._get_precise_row_coords(row)
        if not coords:
            print(f"[ERROR] Could not get precise coordinates for '{row.name}'. Aborting click.")
            return

        center_x, center_y = coords

        y_offset = 0
        if attempt > 0:
            y_offset = -10 * attempt 

        adjusted_y = center_y + y_offset

        print(f"[*] Preparing to click on row '{row.name}'. Attempt: {attempt + 1}, Coords: ({center_x}, {adjusted_y})")

        pyautogui.moveTo(center_x, adjusted_y, duration=0.5)

        pyautogui.click()
        print("[+] Click action sent.")

    def get_message_elements(self, window: Any) -> list:
        """This function is obsolete in the new AI-driven driver."""
        print("[WARN] get_message_elements is not implemented in the AI driver and will be removed.")
        return []

    def scroll_messages(self, window: Any, direction: str) -> None:
        """Scrolls the message panel up or down."""
        hwnd = window
        if not self.hwnd:
            raise RuntimeError("WeChat window not found. Call find_wechat_window() first.")

        _force_foreground_window(hwnd)

        scroll_amount = 500
        if direction == "up":
            clicks = scroll_amount
        elif direction == "down":
            clicks = -scroll_amount
        else:
            raise ValueError(f"Invalid scroll direction: '{direction}'. Must be 'up' or 'down'.")

        left, top, right, bottom = win32gui.GetWindowRect(hwnd)
        message_panel_x = left + int((right - left) * 0.65)
        message_panel_y = top + int((bottom - top) * 0.5)

        print(f"[*] Scrolling message panel {direction}...", end=" ")
        pyautogui.moveTo(message_panel_x, message_panel_y, duration=0.1)
        pyautogui.scroll(clicks)
        print("Done.")


