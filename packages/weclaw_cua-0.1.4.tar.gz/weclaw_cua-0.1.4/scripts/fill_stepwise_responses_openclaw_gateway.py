#!/usr/bin/env python3
"""Fill step_*.response.txt by calling an OpenAI-compatible gateway (e.g. OpenClaw).

Usage:
  export OPENCLAW_GATEWAY_URL=http://127.0.0.1:<port>/v1
  export OPENCLAW_MODEL=<model_id>
  export OPENCLAW_API_KEY=<token_if_required>
  python scripts/fill_stepwise_responses_openclaw_gateway.py /path/to/output/work

  Optional:
    --force          overwrite existing non-empty .response.txt
    --skip-existing  skip tasks whose .response.txt already exists and is non-empty

Input spec:
  - work_dir: directory containing manifest.json, step_*.png, step_*.prompt.txt
  - OPENCLAW_GATEWAY_URL: chat completions base (must include /v1, same as OpenAI client)
  - OPENCLAW_MODEL: model name accepted by the gateway
  - OPENCLAW_API_KEY: bearer token; use any non-empty placeholder if gateway ignores it

Output spec:
  - Writes each task's response_file with assistant text (raw model output for weclaw finalize).
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys


def _b64_data_url_png(path: str) -> str:
    with open(path, "rb") as f:
        raw = f.read()
    b64 = base64.standard_b64encode(raw).decode("ascii")
    return f"data:image/png;base64,{b64}"


def _chat_vision(
    *,
    base_url: str,
    api_key: str,
    model: str,
    prompt: str,
    image_path: str,
    max_tokens: int,
) -> str:
    from openai import OpenAI

    client = OpenAI(base_url=base_url.rstrip("/"), api_key=api_key)
    data_url = _b64_data_url_png(image_path)
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": data_url}},
                ],
            }
        ],
        max_tokens=max_tokens,
    )
    assert resp.choices, "gateway returned no choices"
    msg = resp.choices[0].message
    assert msg is not None
    content = msg.content
    assert content is not None and str(content).strip(), "empty assistant content"
    return str(content).strip()


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "work_dir",
        help="Directory with manifest.json (e.g. output/work)",
    )
    p.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing non-empty response files",
    )
    p.add_argument(
        "--skip-existing",
        action="store_true",
        help="Skip tasks that already have a non-empty response file",
    )
    args = p.parse_args()

    work_dir = os.path.abspath(args.work_dir)
    assert os.path.isdir(work_dir), f"not a directory: {work_dir}"

    manifest_path = os.path.join(work_dir, "manifest.json")
    assert os.path.isfile(manifest_path), f"manifest not found: {manifest_path}"

    base_url = os.environ.get("OPENCLAW_GATEWAY_URL", "").strip()
    assert base_url, "Set OPENCLAW_GATEWAY_URL (e.g. http://127.0.0.1:18789/v1)"
    model = os.environ.get("OPENCLAW_MODEL", "").strip()
    assert model, "Set OPENCLAW_MODEL"
    api_key = os.environ.get("OPENCLAW_API_KEY", "openclaw-local").strip() or "openclaw-local"

    with open(manifest_path, encoding="utf-8") as f:
        manifest = json.load(f)
    tasks = manifest.get("tasks", [])
    assert isinstance(tasks, list) and tasks, "manifest has no tasks"

    for task in tasks:
        step_id = task["step_id"]
        img_name = task["image"]
        prompt_name = task["prompt_file"]
        out_name = task["response_file"]
        max_tokens = int(task.get("max_tokens", 4096))

        img_path = os.path.join(work_dir, img_name)
        prompt_path = os.path.join(work_dir, prompt_name)
        out_path = os.path.join(work_dir, out_name)

        assert os.path.isfile(img_path), f"missing image: {img_path}"
        assert os.path.isfile(prompt_path), f"missing prompt: {prompt_path}"

        if args.skip_existing and os.path.isfile(out_path):
            with open(out_path, encoding="utf-8") as ef:
                if ef.read().strip():
                    print(f"[skip] {step_id}: existing {out_name}")
                    continue

        if not args.force and os.path.isfile(out_path):
            with open(out_path, encoding="utf-8") as ef:
                if ef.read().strip():
                    print(f"[skip] {step_id}: use --force to overwrite")
                    continue

        with open(prompt_path, encoding="utf-8") as pf:
            prompt_text = pf.read()
        assert prompt_text.strip(), f"empty prompt: {prompt_path}"

        print(f"[call] {step_id} max_tokens={max_tokens} ...")
        text = _chat_vision(
            base_url=base_url,
            api_key=api_key,
            model=model,
            prompt=prompt_text,
            image_path=img_path,
            max_tokens=max_tokens,
        )
        with open(out_path, "w", encoding="utf-8") as wf:
            wf.write(text)
        print(f"[ok]   wrote {out_path}")

    print("Done. Next: weclaw finalize --work-dir", work_dir)


if __name__ == "__main__":
    main()
