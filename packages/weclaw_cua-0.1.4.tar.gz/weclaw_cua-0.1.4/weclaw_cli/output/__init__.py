from .formatter import output

__all__ = ["output"]
