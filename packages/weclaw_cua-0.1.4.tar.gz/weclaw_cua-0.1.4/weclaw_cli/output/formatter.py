"""CLI stdout helpers for JSON and plain text."""

import json


def output(data, fmt: str) -> None:
    if fmt == "json":
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print(data)
