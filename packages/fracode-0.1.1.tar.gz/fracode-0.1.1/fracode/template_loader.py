"""
Template loader for scaffolding commands.
Uses Jinja2 to render code templates.
"""

from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, Template


class TemplateLoader:
    """Load and render Jinja2 templates for code generation."""

    def __init__(self):
        """Initialize the template loader with the templates directory."""
        self.templates_dir = Path(__file__).parent / "templates"
        self.env = Environment(
            loader=FileSystemLoader(str(self.templates_dir)),
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=True,
        )

    def render(self, template_path: str, context: dict[str, Any] | None = None) -> str:
        """
        Render a template with the given context.

        Args:
            template_path: Path to template relative to templates directory
            context: Variables to pass to the template

        Returns:
            Rendered template string

        Example:
            loader = TemplateLoader()
            code = loader.render("controller/api.py.j2", {"class_name": "UserController"})
        """
        context = context or {}
        template = self.env.get_template(template_path)
        return template.render(**context)

    def render_string(self, template_str: str, context: dict[str, Any] | None = None) -> str:
        """
        Render a template from a string.

        Args:
            template_str: Template string to render
            context: Variables to pass to the template

        Returns:
            Rendered template string
        """
        context = context or {}
        template = Template(template_str)
        return template.render(**context)


# Global template loader instance
template_loader = TemplateLoader()
