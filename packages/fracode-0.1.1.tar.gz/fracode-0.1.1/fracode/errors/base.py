"""
Global exception handling for FraCode.
"""

from fastapi import HTTPException, Request
from fastapi.exceptions import RequestValidationError

from .helpers import error_response


def register_exception_handlers(app):
    """Register global exception handlers for the given app."""

    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        return error_response(
            message=exc.detail,
            status_code=exc.status_code,
            path=str(request.url),
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        return error_response(
            message="Validation failed",
            status_code=422,
            detail=exc.errors(),  # type: ignore[arg-type]
            path=str(request.url),
        )
