"""
Helper functions for consistent JSON error responses.
"""

import uuid
from datetime import UTC, datetime
from typing import Any

from fastapi.responses import JSONResponse


def generate_error_id() -> str:
    """Generate a short unique error ID for tracking."""
    return str(uuid.uuid4())[:8]


def format_validation_errors(errors: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Format validation errors to be more user-friendly."""
    formatted = []
    for err in errors:
        field_path = " -> ".join(str(loc) for loc in err.get("loc", []))
        formatted.append(
            {
                "field": field_path,
                "message": err.get("msg", "Invalid value"),
                "type": err.get("type", "validation_error"),
                "input": err.get("input", None),
            }
        )
    return formatted


def error_response(
    message: str,
    status_code: int,
    detail: str | dict | list | None = None,
    path: str | None = None,
    error_code: str | None = None,
) -> JSONResponse:
    """
    Create a standardized error response.
    """
    error_id = generate_error_id()

    payload: dict[str, Any] = {
        "success": False,
        "error": {
            "message": message,
            "code": error_code or f"HTTP_{status_code}",
            "status": status_code,
            "timestamp": datetime.now(UTC).isoformat(),
            "error_id": error_id,
        },
    }

    if path:
        payload["error"]["path"] = path

    if detail is not None:
        if isinstance(detail, list) and status_code == 422:
            payload["error"]["validation_errors"] = format_validation_errors(detail)
        else:
            payload["error"]["detail"] = detail

    return JSONResponse(status_code=status_code, content=payload)
