from fastapi import Request

from ..http.response import json


class Controller:
    """
    Base HTTP Controller. Extend this in app/controllers/*.

    FraCode controllers should stay compatible with normal FastAPI signatures:
    typed params, Pydantic models, Depends, BackgroundTasks, and request injection
    should all continue to work.
    """

    def ok(self, data, status_code: int = 200):
        return json(data, status_code=status_code)

    # Hook for dependency injection or per-controller middleware later
    async def before_action(self, request: Request):
        pass

    async def after_action(self, request: Request, response):
        return response
