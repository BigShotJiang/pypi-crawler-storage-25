from __future__ import annotations

import importlib
import inspect
import re
from collections.abc import Callable
from typing import Any, cast, get_args, get_origin

from fastapi import Request as FastAPIRequest

from .request import Request

Handler = str | Callable[..., Any]


def _to_snake(name: str) -> str:
    """Convert CamelCase class names to snake_case file names."""
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def _resolve_handler(handler: str) -> tuple[type[Any], str]:
    """
    Resolve "HomeController@index" to the controller class and action name.
    """
    if "@" not in handler:
        raise ValueError(f'Invalid handler "{handler}". Use "Controller@action".')

    controller_name, action = handler.split("@", 1)
    module_name = _to_snake(controller_name)
    module_path = f"app.controllers.{module_name}"

    module = importlib.import_module(module_path)
    ControllerCls = getattr(module, controller_name)
    endpoint = getattr(ControllerCls, action)

    if not callable(endpoint):
        raise TypeError(f"Action {action} on {controller_name} is not callable.")
    return ControllerCls, action


async def _call_maybe_async(value: Any) -> Any:
    """Await values when needed and return sync results unchanged."""
    if inspect.isawaitable(value):
        return await value
    return value


async def _noop_before_action(_request: Request) -> None:
    """Default no-op hook for controller classes without before_action."""
    return None


async def _passthrough_after_action(_request: Request, response: Any) -> Any:
    """Default passthrough hook for controller classes without after_action."""
    return response


def _coerce_path_param(value: Any, annotation: Any) -> Any:
    """Coerce path params when wrappers are invoked directly outside FastAPI."""
    if annotation is inspect.Signature.empty or annotation is Any or value is None:
        return value

    origin = get_origin(annotation)
    if origin is None:
        try:
            if annotation is bool:
                if isinstance(value, str):
                    lowered = value.strip().lower()
                    if lowered in {"1", "true", "yes", "on"}:
                        return True
                    if lowered in {"0", "false", "no", "off"}:
                        return False
                return bool(value)
            if annotation in {str, int, float}:
                return annotation(value)
        except (TypeError, ValueError):
            return value
        return value

    if origin in {list, dict, tuple, set}:
        return value

    args = [arg for arg in get_args(annotation) if arg is not type(None)]
    for arg in args:
        if isinstance(arg, type) and isinstance(value, arg):
            return value

        coerced = _coerce_path_param(value, arg)
        if isinstance(arg, type) and isinstance(coerced, arg):
            return coerced
    return value


def _coerce_route_arguments(
    signature: inspect.Signature, route_arguments: dict[str, Any]
) -> dict[str, Any]:
    """Coerce route arguments using endpoint annotations as a fallback."""
    coerced = dict(route_arguments)
    for name, parameter in signature.parameters.items():
        if name in coerced:
            coerced[name] = _coerce_path_param(coerced[name], parameter.annotation)
    return coerced


def _public_endpoint_signature(endpoint: Callable[..., Any]) -> inspect.Signature:
    """Expose the controller action signature without the bound self parameter."""
    signature = inspect.signature(endpoint)
    normalized_parameters: list[inspect.Parameter] = []
    parameters = list(signature.parameters.values())

    if parameters and parameters[0].name == "self":
        parameters = parameters[1:]

    has_request = False
    for parameter in parameters:
        if parameter.name == "request":
            has_request = True
            normalized_parameters.append(
                parameter.replace(
                    annotation=FastAPIRequest,
                    default=inspect.Signature.empty,
                )
            )
        else:
            normalized_parameters.append(parameter)

    if not has_request:
        request_parameter = inspect.Parameter(
            "request",
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            annotation=FastAPIRequest,
        )
        normalized_parameters.insert(0, request_parameter)

    return signature.replace(parameters=normalized_parameters)


def _to_fracode_request(request: FastAPIRequest) -> Request:
    """Wrap FastAPI's request object in the richer FraCode request type."""
    send = getattr(request, "_send", None)
    if send is None:
        return Request(request.scope, receive=request.receive)
    return Request(request.scope, receive=request.receive, send=send)


def _wrap(controller_cls: type[Any], action_name: str) -> Callable[..., Any]:
    endpoint = getattr(controller_cls, action_name)
    endpoint_signature = inspect.signature(endpoint)
    public_signature = _public_endpoint_signature(endpoint)
    endpoint_expects_request = any(
        p.kind in (p.POSITIONAL_OR_KEYWORD, p.KEYWORD_ONLY) and p.name == "request"
        for p in endpoint_signature.parameters.values()
    )

    async def asgi_endpoint(*args: Any, **kwargs: Any):
        bound_arguments = public_signature.bind_partial(*args, **kwargs)
        request = cast(FastAPIRequest, bound_arguments.arguments["request"])
        controller = controller_cls()
        fracode_request = _to_fracode_request(request)
        route_arguments = dict(bound_arguments.arguments)
        for name, value in (fracode_request.path_params or {}).items():
            route_arguments.setdefault(name, value)
        route_arguments = _coerce_route_arguments(endpoint_signature, route_arguments)
        before_action = getattr(controller, "before_action", _noop_before_action)
        after_action = getattr(controller, "after_action", _passthrough_after_action)
        before_result = await _call_maybe_async(before_action(fracode_request))
        if before_result is not None:
            response = before_result
        else:
            endpoint_kwargs = dict(route_arguments)
            endpoint_kwargs["request"] = fracode_request
            endpoint = getattr(controller, action_name)
            if endpoint_expects_request:
                response = endpoint(**endpoint_kwargs)
            else:
                endpoint_kwargs.pop("request", None)
                response = endpoint(**endpoint_kwargs)
            response = await _call_maybe_async(response)

        return await _call_maybe_async(after_action(fracode_request, response))

    asgi_endpoint.__name__ = action_name
    asgi_endpoint.__signature__ = public_signature  # type: ignore[attr-defined]
    return asgi_endpoint


def _resolve_handler_reference(handler: Handler) -> tuple[type[Any], str] | None:
    """Resolve direct controller method references into a controller/action pair."""
    if isinstance(handler, str):
        return _resolve_handler(handler)

    if inspect.ismethod(handler):
        handler = handler.__func__

    if not inspect.isfunction(handler):
        return None

    qualname_parts = handler.__qualname__.split(".")
    if len(qualname_parts) < 2:
        return None

    controller_name = qualname_parts[-2]
    action_name = handler.__name__
    module = importlib.import_module(handler.__module__)
    controller_cls = getattr(module, controller_name, None)
    if not inspect.isclass(controller_cls):
        return None

    endpoint = getattr(controller_cls, action_name, None)
    if endpoint is not handler:
        return None

    return controller_cls, action_name


class Router:
    """
    Router class that collects routes and can be attached to an app.

    Similar to FastAPI's APIRouter but with FraCode's controller syntax.

    Example:
        router = Router()
        router.get("/users", "UserController@index")
        router.post("/users", "UserController@store")

        app.include_router(router)
    """

    def __init__(self, prefix: str = "", tags: list[str] | None = None):
        """
        Initialize a new Router.

        Args:
            prefix: URL prefix for all routes in this router
            tags: OpenAPI tags for all routes in this router
        """
        self.prefix = prefix
        self.tags = tags or []
        self._routes: list[tuple[str, str, Handler]] = []

    def add(self, method: str, path: str, handler: Handler) -> None:
        """
        Add a route to this router.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: URL path
            handler: Controller action string, controller method reference, or FastAPI endpoint.
        """
        self._routes.append((method.upper(), path, handler))

    def get(self, path: str, handler: Handler) -> None:
        """Add a GET route."""
        self.add("GET", path, handler)

    def post(self, path: str, handler: Handler) -> None:
        """Add a POST route."""
        self.add("POST", path, handler)

    def put(self, path: str, handler: Handler) -> None:
        """Add a PUT route."""
        self.add("PUT", path, handler)

    def patch(self, path: str, handler: Handler) -> None:
        """Add a PATCH route."""
        self.add("PATCH", path, handler)

    def delete(self, path: str, handler: Handler) -> None:
        """Add a DELETE route."""
        self.add("DELETE", path, handler)

    def register(self, app) -> None:
        """
        Register all routes in this router to the given app.

        Args:
            app: FastAPI app instance to register routes to
        """
        for method, path, handler in self._routes:
            full_path = f"{self.prefix}{path}" if self.prefix else path
            controller_target = _resolve_handler_reference(handler)
            endpoint = handler if callable(handler) else None
            if controller_target is not None:
                controller_cls, action_name = controller_target
                endpoint = _wrap(controller_cls, action_name)

            if endpoint is None:
                raise TypeError(f"Unsupported route handler type: {type(handler).__name__}")

            app.add_api_route(
                full_path,
                endpoint,
                methods=[method],
                tags=self.tags or None,
            )

    @property
    def routes(self) -> list[tuple[str, str, Handler]]:
        """Get all routes in this router."""
        return self._routes.copy()
