# fracode/http/request.py
import json
from collections.abc import Mapping
from json import JSONDecodeError
from typing import Any
from urllib.parse import parse_qs

from fastapi import Request as FastAPIRequest
from starlette.datastructures import FormData

from fracode.errors import BadRequest


def _merge_items(data: dict[str, Any], items: list[tuple[str, Any]]) -> dict[str, Any]:
    """Merge repeated keys while preserving single values as scalars."""
    for key, value in items:
        if key not in data:
            data[key] = value
            continue

        existing = data[key]
        if isinstance(existing, list):
            existing.append(value)
        else:
            data[key] = [existing, value]
    return data


def _merge_form_data(data: dict[str, Any], form: FormData | Mapping[str, Any]) -> dict[str, Any]:
    if hasattr(form, "multi_items"):
        return _merge_items(data, list(form.multi_items()))

    return _merge_items(data, list(form.items()))


def _content_type_from_scope(scope: Any) -> str:
    """Read content type without assuming the ASGI scope always has headers."""
    if isinstance(scope, dict):
        for key, value in scope.get("headers", []):
            if (
                isinstance(key, bytes)
                and key.lower() == b"content-type"
                and isinstance(value, bytes)
            ):
                return value.decode("latin-1").lower()
        return ""

    headers = getattr(scope, "headers", None)
    if headers is None:
        return ""
    content_type = headers.get("content-type")
    if isinstance(content_type, str):
        return content_type.lower()
    return ""


class Request(FastAPIRequest):
    async def input(self) -> dict[str, Any]:
        """
        Return a unified dict combining query params, form data, and JSON body.
        Raises BadRequest when the request body cannot be interpreted as a mapping.
        """
        data = _merge_items({}, list(self.query_params.multi_items()))

        if not hasattr(self, "_receive"):
            return data

        content_type = _content_type_from_scope(getattr(self, "scope", {}))

        if "multipart/form-data" in content_type:
            try:
                form_data = await self.form()
            except RuntimeError:
                return data
            except Exception as exc:
                raise BadRequest("Failed to parse multipart form data.") from exc
            return _merge_form_data(data, form_data)

        try:
            body_bytes = await self.body()
        except RuntimeError:
            return data

        if not body_bytes:
            return data

        if "application/json" in content_type:
            try:
                parsed = json.loads(body_bytes.decode("utf-8"))
            except (UnicodeDecodeError, JSONDecodeError) as exc:
                raise BadRequest("Request body contains invalid JSON.") from exc

            if not isinstance(parsed, dict):
                raise BadRequest("Request JSON body must be an object.")

            data.update(parsed)
            return data

        if "application/x-www-form-urlencoded" in content_type:
            form_qs = parse_qs(body_bytes.decode("utf-8"))
            for key, values in form_qs.items():
                data[key] = values[0] if len(values) == 1 else values
            return data

        return data

    @property
    def user(self) -> Any:
        """
        Return authenticated user from scope if available, else None.
        Avoids raising if AuthenticationMiddleware is not installed.
        """
        scope = getattr(self, "scope", {}) or {}
        if isinstance(scope, dict) and "user" in scope:
            return scope.get("user")
        if hasattr(scope, "user"):
            return getattr(scope, "user", None)
        return None
