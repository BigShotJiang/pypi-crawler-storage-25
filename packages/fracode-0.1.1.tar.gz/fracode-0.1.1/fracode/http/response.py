from typing import Any

from fastapi.responses import JSONResponse


def json(data: Any, status_code: int = 200) -> JSONResponse:
    if isinstance(data, JSONResponse):
        return data
    return JSONResponse(content=data, status_code=status_code)
