# FraCode Templates

This directory contains Jinja2 templates used for scaffolding code via the FraCode CLI.

## Directory Structure

```
templates/
├── controller/          # Controller templates
│   ├── api.py.j2       # API resource controller (JSON responses)
│   ├── resource.py.j2  # Full resource controller (index, show, create, store, edit, update, destroy)
│   └── basic.py.j2     # Empty controller skeleton
├── model/              # Model templates
│   └── model.py.j2     # SQLAlchemy model with timestamps
└── project/            # New project templates
    ├── bootstrap_app.py.j2     # Application bootstrap
    ├── .env.j2                 # Environment configuration
    ├── .gitignore.j2           # Git ignore patterns
    ├── README.md.j2            # Project README
    ├── home_controller.py.j2   # Example home controller
    └── web_routes.py.j2        # Example route definitions
```

## Template Variables

### Controller Templates

- `class_name` - Name of the controller class (e.g., "UserController")

**Example:**
```python
from fracode.template_loader import template_loader

content = template_loader.render(
    "controller/api.py.j2",
    {"class_name": "UserController"}
)
```

### Model Templates

- `class_name` - Name of the model class (e.g., "User")
- `table_name` - Database table name (e.g., "users")

**Example:**
```python
content = template_loader.render(
    "model/model.py.j2",
    {"class_name": "User", "table_name": "users"}
)
```

### Project Templates

- `app_name` - Name of the application (used in .env and README)

**Example:**
```python
content = template_loader.render(
    "project/README.md.j2",
    {"app_name": "my_awesome_app"}
)
```

## Adding New Templates

1. Create a new `.j2` file in the appropriate subdirectory
2. Use Jinja2 syntax for variables: `{{ variable_name }}`
3. Update the `template_loader.py` if you need custom filters or functions
4. Update CLI commands to use the new template

### Template Best Practices

- **Keep templates focused**: One template per scaffold type
- **Use meaningful variable names**: `class_name`, not `cn`
- **Include helpful comments**: Guide developers on what to modify
- **Follow Python conventions**: PEP 8 formatting, proper imports
- **Add trailing newline**: Use `keep_trailing_newline=True` in Jinja2 env

## Template Engine

FraCode uses Jinja2 with the following configuration:

- `trim_blocks=True` - Remove first newline after template tags
- `lstrip_blocks=True` - Strip leading spaces/tabs from block content
- `keep_trailing_newline=True` - Preserve final newline in templates

## CLI Commands Using Templates

- `fra new <name>` - Uses all project templates
- `fra make:controller <name>` - Uses controller templates
- `fra make:model <name>` - Uses model templates

## Example Template

**File:** `controller/custom.py.j2`

```jinja2
from fracode.http import Controller


class {{ class_name }}(Controller):
    """{{ description|default("Custom controller") }}"""

    async def index(self, request=None):
        # TODO: Implement index action
        return self.ok({"message": "Hello from {{ class_name }}"})
```

**Usage:**

```python
content = template_loader.render(
    "controller/custom.py.j2",
    {
        "class_name": "CustomController",
        "description": "Handles custom operations"
    }
)
```

## Testing Templates

Templates are tested via the CLI test suite in `tests/test_cli.py`. When adding new templates, ensure:

1. Template renders without errors
2. Generated code is syntactically valid Python
3. Generated code passes linting (ruff, black)
4. Generated code includes proper imports

## Documentation

For more information about Jinja2 templating:
- [Jinja2 Documentation](https://jinja.palletsprojects.com/)
- [Jinja2 Template Designer Documentation](https://jinja.palletsprojects.com/en/3.1.x/templates/)
