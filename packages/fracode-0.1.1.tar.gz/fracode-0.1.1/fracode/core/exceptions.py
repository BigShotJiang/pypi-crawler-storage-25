"""
Core exception base for FraCode.
"""

from fastapi import HTTPException as FastAPIHTTPException
from fastapi.exceptions import RequestValidationError as FastAPIValidationError


class FraCodeException(FastAPIHTTPException):
    """Base exception for FraCode."""

    def __init__(self, status_code: int, detail: str):
        super().__init__(status_code=status_code, detail=detail)


HTTPException = FraCodeException
RequestValidationError = FastAPIValidationError

__all__ = ["FraCodeException", "HTTPException", "RequestValidationError"]
