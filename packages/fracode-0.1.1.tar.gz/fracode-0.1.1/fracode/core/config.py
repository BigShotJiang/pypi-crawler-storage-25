"""
Configuration system for FraCode.
Loads settings from environment variables with sane defaults.
"""

import os
from functools import lru_cache
from importlib import metadata

from dotenv import find_dotenv, load_dotenv

from fracode import __version__


def _default_version() -> str:
    """Read the installed package version when available."""
    try:
        return metadata.version("fracode")
    except metadata.PackageNotFoundError:
        return __version__


def _load_project_env() -> None:
    """Load the nearest project .env file from the current working directory."""
    env_override = os.getenv("FRACODE_ENV_FILE")
    if env_override:
        load_dotenv(dotenv_path=env_override, override=False)
        return

    env_path = find_dotenv(filename=".env", usecwd=True)
    if env_path:
        load_dotenv(dotenv_path=env_path, override=False)


class Settings:
    def __init__(self):
        _load_project_env()

        # Environment: dev, prod, test
        self.env = os.getenv("FRACODE_ENV", "dev")

        # Database URL
        self.database_url = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./fracode_dev.db")

        # Debug mode
        self.debug = os.getenv("DEBUG", "true").lower() in ("1", "true", "yes")

        # App name & version
        self.app_name = os.getenv("APP_NAME", "FraCode")
        self.version = os.getenv("APP_VERSION", _default_version())

        # Database pooling
        self.db_pool_size = int(os.getenv("DB_POOL_SIZE", "10"))
        self.db_max_overflow = int(os.getenv("DB_MAX_OVERFLOW", "20"))
        self.db_pool_timeout = int(os.getenv("DB_POOL_TIMEOUT", "30"))
        self.db_pool_recycle = int(os.getenv("DB_POOL_RECYCLE", "1800"))

        # CORS
        self.cors_enabled = os.getenv("CORS_ENABLED", "true").lower() in (
            "1",
            "true",
            "yes",
        )
        self.cors_origins = self._parse_list(os.getenv("CORS_ORIGINS", "*"))
        self.cors_credentials = os.getenv("CORS_ALLOW_CREDENTIALS", "false").lower() in (
            "1",
            "true",
            "yes",
        )
        self.cors_methods = self._parse_list(os.getenv("CORS_ALLOW_METHODS", "*"))
        self.cors_headers = self._parse_list(os.getenv("CORS_ALLOW_HEADERS", "*"))

        # Browsers disallow credentialed requests with wildcard origins.
        if self.cors_origins == ["*"] and self.cors_credentials:
            self.cors_credentials = False

    def _parse_list(self, value: str) -> list:
        """Parse comma-separated string into list, or return ['*'] if value is '*'."""
        if value == "*":
            return ["*"]
        return [item.strip() for item in value.split(",") if item.strip()]


@lru_cache
def fracode_settings() -> Settings:
    return Settings()
