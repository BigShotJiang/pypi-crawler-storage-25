from typing import Any

from fastapi import APIRouter, FastAPI, Request
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.errors import ServerErrorMiddleware

from fracode.core.config import fracode_settings
from fracode.errors.helpers import error_response


class FraCodeErrorMiddleware(ServerErrorMiddleware):
    """Convert unhandled server errors into stable JSON responses."""

    async def __call__(self, scope, receive, send):
        try:
            await self.app(scope, receive, send)
        except Exception as exc:
            detail = str(exc) if self.debug else None
            request = Request(scope)
            response = error_response(
                message="Internal Server Error",
                status_code=500,
                detail=detail,
                path=str(request.url),
            )
            await response(scope, receive, send)


class App(FastAPI):
    """FraCode application object built on FastAPI."""

    def __init__(self, *args, **kwargs):
        debug = kwargs.setdefault("debug", False)

        middleware = kwargs.pop("middleware", [])
        middleware.append((FraCodeErrorMiddleware, (), {"debug": debug}))
        kwargs["middleware"] = middleware

        super().__init__(*args, **kwargs)

        settings = fracode_settings()
        if settings.cors_enabled:
            self.add_middleware(
                CORSMiddleware,
                allow_origins=settings.cors_origins,
                allow_credentials=settings.cors_credentials,
                allow_methods=settings.cors_methods,
                allow_headers=settings.cors_headers,
            )

    def include_router(self, router: Any, **kwargs: Any) -> None:
        """
        Include a router in this app.

        Args:
            router: Prefer a FraCode Router. APIRouter remains available for escape hatches.

        Example:
            from fracode.http import Router

            router = Router(prefix="/api/v1", tags=["users"])
            router.get("/users", "UserController@index")
            router.post("/users", "UserController@store")
            app.include_router(router)
        """
        from fracode.http.routing import Router

        if isinstance(router, Router):
            router.register(self)
        elif isinstance(router, APIRouter):
            super().include_router(router, **kwargs)
        else:
            raise TypeError(f"Expected Router or APIRouter instance, got {type(router).__name__}")
