"""Database dependency injection helpers for FraCode."""

from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Database session dependency for FastAPI endpoints.

    Usage:
        @app.get("/users")
        async def get_users(db: AsyncSession = Depends(get_db)):
            result = await db.execute(select(User))
            users = result.scalars().all()
            return users
    """
    from .session import get_session_local

    session_factory = get_session_local()

    async with session_factory() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
