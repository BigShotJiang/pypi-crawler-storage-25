from __future__ import annotations

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from fracode.core import fracode_settings

settings = fracode_settings()

_engine: AsyncEngine | None = None
_session_local: async_sessionmaker[AsyncSession] | None = None


def normalize_database_url(database_url: str) -> str:
    """Normalize supported sync-style URLs to their async SQLAlchemy dialects."""
    if database_url.startswith("sqlite:///") and "+aiosqlite" not in database_url:
        return database_url.replace("sqlite:///", "sqlite+aiosqlite:///")

    if database_url.startswith("postgresql://") and "+asyncpg" not in database_url:
        return database_url.replace("postgresql://", "postgresql+asyncpg://")

    return database_url


def get_engine() -> AsyncEngine:
    """Create the async engine lazily so unrelated imports do not require DB drivers."""
    global _engine

    if _engine is None:
        db_url = normalize_database_url(settings.database_url)
        _engine = create_async_engine(
            db_url,
            echo=settings.debug,
            future=True,
            pool_size=getattr(settings, "db_pool_size", 10),
            max_overflow=getattr(settings, "db_max_overflow", 20),
            pool_timeout=getattr(settings, "db_pool_timeout", 30),
            pool_recycle=getattr(settings, "db_pool_recycle", 1800),
        )

    return _engine


def get_session_local() -> async_sessionmaker[AsyncSession]:
    """Create the session factory lazily alongside the engine."""
    global _session_local

    if _session_local is None:
        _session_local = async_sessionmaker(
            bind=get_engine(),
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False,
            autocommit=False,
        )

    return _session_local


__all__ = [
    "get_engine",
    "get_session_local",
    "normalize_database_url",
    "settings",
]
