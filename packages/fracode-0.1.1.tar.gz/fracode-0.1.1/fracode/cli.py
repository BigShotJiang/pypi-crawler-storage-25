import asyncio
import importlib.metadata
import re
import shutil
import subprocess
from pathlib import Path

import typer
import uvicorn

from . import __version__
from .core import fracode_settings
from .model import Base
from .template_loader import template_loader

settings = fracode_settings()
app = typer.Typer(help="FraCode - Fun Reliable Applications CLI")


def package_version() -> str:
    """Return the installed package version when available."""
    try:
        return importlib.metadata.version("fracode")
    except importlib.metadata.PackageNotFoundError:
        return __version__


def version_callback(value: bool):
    """Show version and exit."""
    if value:
        typer.echo(f"FraCode version {package_version()}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-v",
        help="Show the application version and exit",
        callback=version_callback,
        is_eager=True,
    ),
):
    """
    FraCode - Fun Reliable Applications in Python
    """
    pass


@app.command("new")
def new_project(
    name: str = typer.Argument(..., help="Name of the new project"),
    path: str = typer.Option(
        None, help="Path where to create the project (default: current directory)"
    ),
):
    """
    Create a new FraCode project with the recommended structure.
    """
    target_dir = Path(path) / name if path else Path(name)

    if target_dir.exists():
        typer.echo(f"Error: Directory '{target_dir}' already exists!")
        raise typer.Exit(1)

    typer.echo(f"Creating new FraCode project: {name}")

    # Create directory structure
    dirs = [
        "app/controllers",
        "app/models",
        "app/routes",
        "bootstrap",
        "public",
    ]

    for dir_path in dirs:
        (target_dir / dir_path).mkdir(parents=True, exist_ok=True)

    # Create __init__ files
    init_files = [
        "app/__init__.py",
        "app/controllers/__init__.py",
        "app/models/__init__.py",
    ]

    for init_file in init_files:
        (target_dir / init_file).touch()

    (target_dir / "app/routes/__init__.py").write_text(
        'ROUTE_MODULES = (\n    "app.routes.web",\n    "app.routes.api",\n)\n'
    )

    # Create bootstrap/app.py from template
    bootstrap_content = template_loader.render("project/bootstrap_app.py.j2")
    (target_dir / "bootstrap/app.py").write_text(bootstrap_content)

    # Create .env file from template
    env_content = template_loader.render(
        "project/.env.j2",
        {"app_name": name, "app_version": package_version()},
    )
    (target_dir / ".env").write_text(env_content)

    # Create .gitignore from template
    gitignore_content = template_loader.render("project/.gitignore.j2")
    (target_dir / ".gitignore").write_text(gitignore_content)

    # Create README.md from template
    readme_content = template_loader.render("project/README.md.j2", {"app_name": name})
    (target_dir / "README.md").write_text(readme_content)

    # Create example controller from template
    home_controller = template_loader.render("project/home_controller.py.j2")
    (target_dir / "app/controllers/home_controller.py").write_text(home_controller)

    # Create example routes from template
    routes_content = template_loader.render("project/web_routes.py.j2")
    (target_dir / "app/routes/web.py").write_text(routes_content)
    (target_dir / "app/routes/api.py").write_text("\n")

    typer.echo("\n Project created successfully!")
    typer.echo("\nNext steps:")
    typer.echo(f"  cd {name}")
    typer.echo("  fra serve")
    typer.echo("\nThen visit: http://127.0.0.1:8000")
    typer.echo("API Docs: http://127.0.0.1:8000/docs")


@app.command()
def serve(
    host: str = typer.Option("127.0.0.1", "--host", help="Host to bind the development server"),
    port: int = typer.Option(8000, "--port", help="Port to bind the development server"),
    reload: bool = typer.Option(True, "--reload/--no-reload", help="Enable auto-reload"),
):
    """
    Run the development server via bootstrap.app:create_app factory.
    """
    # Ensure required routes are importable before starting
    possible_web_routes = Path("app/routes/web.py")
    if not possible_web_routes.exists():
        typer.echo("No app/routes/web.py found. You can create it to add routes.")
    uvicorn.run(
        "bootstrap.app:create_app",
        host=host,
        port=port,
        reload=reload,
        factory=True,
    )


@app.command("make:controller")
def make_controller(
    name: str = typer.Argument(..., help="Name of the controller (e.g. UserController or User)."),
    api: bool = typer.Option(False, "--api", help="Generate an API controller"),
):
    """
    Generate a new controller inside app/controllers with validation and safety checks.
    """

    # Validate controller name
    if not re.match(r"^[A-Za-z][A-Za-z0-9]*$", name):
        typer.echo("Invalid controller name. Use only letters and numbers, starting with a letter.")
        raise typer.Exit(1)

    # Normalize name
    base_name = re.sub(r"Controller$", "", name, flags=re.IGNORECASE)
    base_name = base_name[0].upper() + base_name[1:]
    class_name = f"{base_name}Controller"

    # File name = snake_case + "_controller.py"
    filename = re.sub(r"(?<!^)(?=[A-Z])", "_", base_name).lower()
    path = Path(f"app/controllers/{filename}_controller.py")

    # Prevent overwriting without confirmation
    if path.exists():
        typer.echo(f"Controller '{class_name}' already exists at {path}")
        if not typer.confirm("Do you want to overwrite it?"):
            typer.echo("Operation cancelled.")
            raise typer.Exit(0)

    # Render template based on API flag
    if api:
        template_content = template_loader.render(
            "controller/api.py.j2", {"class_name": class_name}
        )
    else:
        template_content = template_loader.render(
            "controller/resource.py.j2", {"class_name": class_name}
        )

    path.write_text(template_content)
    typer.echo(f"Created {'API ' if api else ''}controller '{class_name}' at {path}")


@app.command("make:model")
def make_model(name: str = typer.Argument(..., help="Name of the model (e.g. User)")):
    """
    Generate a new model inside app/models with validation and overwrite confirmation.
    """

    # Validate model name
    if not re.match(r"^[A-Za-z][A-Za-z0-9]*$", name):
        typer.echo("Invalid model name. Use only letters and numbers, starting with a letter.")
        raise typer.Exit(1)

    # Normalize class name
    class_name = name[0].upper() + name[1:] if not name[0].isupper() else name
    filename = re.sub(r"(?<!^)(?=[A-Z])", "_", class_name).lower()
    path = Path(f"app/models/{filename}.py")

    # Check overwrite
    if path.exists():
        typer.echo(f"Model '{class_name}' already exists at {path}")
        if not typer.confirm("Do you want to overwrite it?"):
            typer.echo("Operation cancelled.")
            raise typer.Exit(0)

    # Render model template
    template_content = template_loader.render(
        "model/model.py.j2", {"class_name": class_name, "table_name": f"{filename}s"}
    )

    path.write_text(template_content)
    typer.echo(f"Created model '{class_name}' at {path}")


@app.command("make:db")
def make_db():
    from .model.session import get_engine

    async def init_models():
        async with get_engine().begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

    try:
        asyncio.run(init_models())
        typer.echo("Database created (async).")
    except Exception as exc:
        typer.echo(f"Database init failed: {exc}")
        raise typer.Exit(1)


@app.command("install")
def install():
    """Install project dependencies (with dev)."""
    typer.echo("Installing dependencies...")
    subprocess.run(["poetry", "install", "--with", "dev"], check=True)


@app.command("test")
def test():
    """Run tests with coverage reporting."""
    typer.echo("Running tests with coverage...")
    subprocess.run(
        [
            "poetry",
            "run",
            "pytest",
            "--cov=fracode",
            "--cov-report=term-missing",
            "--cov-report=html",
            "--cov-report=json",
        ],
        check=True,
    )


@app.command("test-fast")
def test_fast():
    """Run tests without coverage (faster)."""
    typer.echo("Running tests without coverage...")
    subprocess.run(["poetry", "run", "pytest", "-v"], check=True)


@app.command("lint")
def lint():
    """Run Ruff lint and format checks."""
    typer.echo("Running Ruff lint checks...")
    subprocess.run(["poetry", "run", "ruff", "check", "fracode/", "tests/"], check=True)
    typer.echo("Running Ruff format checks...")
    subprocess.run(["poetry", "run", "ruff", "format", "--check", "fracode/", "tests/"], check=True)


@app.command("format")
def format_code():
    """Auto-format code with Ruff."""
    typer.echo("Formatting code...")
    subprocess.run(["poetry", "run", "ruff", "check", "--fix", "fracode/", "tests/"], check=True)
    subprocess.run(["poetry", "run", "ruff", "format", "fracode/", "tests/"], check=True)


@app.command("type-check")
def type_check():
    """Run MyPy static type checker."""
    typer.echo("Running MyPy type checker...")
    subprocess.run(["poetry", "run", "mypy", "fracode/"], check=True)


@app.command("ci")
def ci():
    """Run all CI checks (lint, type-check, tests)."""
    typer.echo("=== Running CI Checks ===")
    lint()
    type_check()
    test()
    typer.echo("All CI checks passed!")


@app.command("clean")
def clean():
    """Clean generated files, caches, and build artifacts."""
    typer.echo("Cleaning project files...")
    targets = [
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        "htmlcov",
        "dist",
        "build",
        "coverage.xml",
        "coverage.json",
        ".coverage",
    ]

    for target in targets:
        target_path = Path(target)
        if target_path.is_dir():
            shutil.rmtree(target_path, ignore_errors=True)
        elif target_path.exists():
            target_path.unlink(missing_ok=True)

    for egg_info_path in Path(".").glob("*.egg-info"):
        if egg_info_path.is_dir():
            shutil.rmtree(egg_info_path, ignore_errors=True)
        else:
            egg_info_path.unlink(missing_ok=True)

    for pycache_dir in Path(".").rglob("__pycache__"):
        shutil.rmtree(pycache_dir, ignore_errors=True)

    for pyc_file in Path(".").rglob("*.pyc"):
        pyc_file.unlink(missing_ok=True)

    typer.echo("Clean complete.")


@app.command("build")
def build():
    """Build the package."""
    typer.echo("Building package...")
    subprocess.run(["poetry", "build"], check=True)
    typer.echo("Build successful!")


@app.command("publish")
def publish():
    """Publish the package to PyPI."""
    typer.echo("Publishing to PyPI...")
    subprocess.run(["poetry", "publish", "--build"], check=True)
    typer.echo("Package published successfully!")


if __name__ == "__main__":
    app()
