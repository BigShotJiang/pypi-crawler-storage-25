# FraCode - Fun Reliable Applications in Python

[![CI](https://github.com/iamceeso/FraCode/actions/workflows/ci.yml/badge.svg)](https://github.com/iamceeso/FraCode/actions/workflows/ci.yml)
[![codecov](https://codecov.io/gh/iamceeso/FraCode/branch/main/graph/badge.svg)](https://codecov.io/gh/iamceeso/FraCode)
[![Python Version](https://img.shields.io/badge/python-3.12%2B-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Type checked: mypy](https://img.shields.io/badge/type%20checked-mypy-blue.svg)](http://mypy-lang.org/)

FraCode is an opinionated FastAPI framework for teams that want controller-style organization, a clear project structure, and a batteries-included development workflow.

[Full documentation](https://fracode.com)

## Features

- A framework-level app model built around controllers and explicit route modules
- FraCode router sugar that stays compatible with native FastAPI handlers
- CLI commands for scaffolding projects, controllers, models, and database setup
- Explicit route module loading from `app/routes/__init__.py`
- Async SQLAlchemy support for SQLite and PostgreSQL
- Built-in DB dependency helpers, CORS support, and JSON error responses
- Built on FastAPI and ASGI under the hood

## Quick Start

```bash
# Install FraCode
pip install fracode

# Create a new project
fra new my-app
cd my-app

# Run the development server
fra serve
```

Your app is now running at `http://127.0.0.1:8000`.

FraCode adds structure on top of FastAPI. FastAPI still provides the typing, validation, dependency injection, background task, and OpenAPI model underneath it.

Route loading is explicit by default:

```python
# app/routes/__init__.py
ROUTE_MODULES = (
    "app.routes.web",
    "app.routes.api",
)
```

Visit the [documentation](https://fracode.com) for detailed guides and examples.

Rule of thumb: FraCode can add structure, but it should not replace FastAPI's typing and validation model.

Both of these remain first-class:

```python
from fastapi import Depends
from pydantic import BaseModel
from fracode.http import Router


class CreateUser(BaseModel):
    name: str
    email: str


async def get_current_user():
    return {"id": 1}


router = Router()


@router.post("/users")
async def create_user(payload: CreateUser, current_user=Depends(get_current_user)):
    return {"user": payload.model_dump(), "actor": current_user}
```

```python
from fastapi import Depends
from pydantic import BaseModel
from fracode.http import Controller, Router


class CreateUser(BaseModel):
    name: str
    email: str


async def get_current_user():
    return {"id": 1}


class UserController(Controller):
    async def store(
        self,
        payload: CreateUser,
        current_user=Depends(get_current_user),
    ):
        return self.ok({"user": payload.model_dump(), "actor": current_user})


router = Router()
router.post("/users", UserController.store)
```

## Documentation

For detailed documentation including:
- Complete CLI reference
- Routing and controllers guide
- Database and ORM usage
- Configuration options
- Testing guide
- API documentation

Visit **[fracode.com](https://fracode.com)**

## Development And Testing

FraCode uses modern Python tooling to ensure code quality:

### Code Quality Tools
- **Ruff** - Fun Python linter and formatter
- **MyPy** - Static type checker
- **pytest** - Testing framework with async support

### Run Tests

```bash
# Run all tests with coverage
pytest

# Run specific test file
pytest tests/test_routing.py -v

# Generate HTML coverage report
pytest --cov=fracode --cov-report=html
```

### Linting & Type Checking

```bash
# Run all checks
ruff check fracode/ tests/
ruff format fracode/ tests/
mypy fracode/

# Auto-fix issues
ruff check --fix fracode/ tests/
ruff format fracode/ tests/
```

### CI Pipeline

All PRs and commits are automatically checked for:
- Code formatting and linting
- Type checking
- Test coverage
- Package building

View the [CI status](https://github.com/iamceeso/FraCode/actions) and [coverage reports](https://codecov.io/gh/iamceeso/FraCode).

## Contributing

We welcome contributions! Please ensure your code passes all quality checks:

```bash
# Clone and setup
git clone https://github.com/iamceeso/fracode.git
cd fracode
poetry install --with dev

# Run tests
pytest

# Run all quality checks
ruff check fracode/ tests/
ruff format --check fracode/ tests/
mypy fracode/
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for details.

## License

FraCode is open-source software licensed under the [MIT license](LICENSE).

## Acknowledgments

- Built on top of [FastAPI](https://fastapi.tiangolo.com/)
- Inspired by [Laravel](https://laravel.com/)
- ORM powered by [SQLAlchemy](https://www.sqlalchemy.org/)

## Support

- **Issues**: [GitHub Issues](https://github.com/iamceeso/fracode/issues)
- **Discussions**: [GitHub Discussions](https://github.com/iamceeso/fracode/discussions)
- **Email**: hello@chidiesobe.com

---

Built by [Chidi E.](https://github.com/iamceeso)
