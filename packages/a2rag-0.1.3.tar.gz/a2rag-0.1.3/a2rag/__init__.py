"""
A2RAG — Abstention-Aware RAG Decision Layer
============================================
Decides when your RAG system should answer, clarify, or abstain.

Quick start:
    from a2rag import A2RAGClient

    client = A2RAGClient(api_key="your_key_here")
    decision = client.decide(query, contexts, draft_answer)
"""
from .client import A2RAGClient
from .models import Decision, Metrics, CalibrationResult
from .http import A2RAGError, AuthError, RateLimitError

__version__ = "0.1.3"
__all__ = ["A2RAGClient", "Decision", "Metrics", "CalibrationResult",
           "A2RAGError", "AuthError", "RateLimitError"]
