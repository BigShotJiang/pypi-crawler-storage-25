from setuptools import setup, find_packages
setup(
    name="a2rag",
    version="0.1.3",
    description="Abstention-Aware RAG Decision Layer",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="AIBee Research",
    python_requires=">=3.8",
    packages=find_packages(),
    install_requires=[],  # zero required dependencies
    extras_require={
        "full": ["requests", "rich"],
    },
    entry_points={
        "console_scripts": [
            "a2rag=a2rag.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
