"""Runbook evaluator — default-evaluator interceptors for pre-publish gates.

Operator-driven gate evaluation (3.4.0 / Codeberg-dev #3 Phase 1b).
Each ``pre-publish`` gate gets a default evaluator that consults the
``runbook_confirmations`` dict in the interceptor request payload and
emits a structured pass / unconfirmed result keyed on the gate name.

Composition with the project-rules layering surface (#288) is automatic:
the runbook evaluator is the inner-most layer, so a project-rule
``tighten`` extension can wrap the default behavior (e.g., convert an
``unconfirmed`` advisory result into a hard error). Without project
rules, the evaluator's default behavior is advisory — ``unconfirmed``
gates produce a warning but don't fail the chain.

Public surface:

* :func:`make_runbook_evaluator` — build an :class:`Interceptor` for
  one gate.
* :func:`register_runbook_evaluators` — scan a :class:`GateRegistry`
  and register evaluators for every pre-publish gate.

Wiring: :func:`register_runbook_evaluators` is called from
:func:`server.build.build_server` after the gate registry loads.
"""
from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

from .interceptors import Context, Interceptor
from .server.gates import register_default_evaluator

if TYPE_CHECKING:
    from .gate_registry import Gate, GateRegistry


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

#: Top-level key in the interceptor ``request`` payload that carries
#: the operator-supplied confirmation map. validate_release accepts a
#: ``runbook_confirmations`` parameter and threads it to the chain
#: under this key.
RUNBOOK_CONFIRMATIONS_REQUEST_KEY = "runbook_confirmations"


def make_runbook_evaluator(gate: "Gate") -> Interceptor:
    """Build the default-evaluator interceptor for a single runbook gate.

    The returned interceptor's ``enter`` handler reads
    ``ctx.request[RUNBOOK_CONFIRMATIONS_REQUEST_KEY][gate.name]`` and
    writes a result dict to ``ctx.response[gate.name]`` with status
    ``"passed"`` (operator confirmed) or ``"unconfirmed"`` (missing or
    explicit False). Unconfirmed results include a ``manual_steps``
    entry pointing the operator at the runbook.

    Raises :class:`ValueError` when ``gate.type != "pre-publish"`` or
    when ``runbook_url`` is missing — neither should happen at runtime
    (the ``Gate`` model validators enforce both), but defense-in-depth
    keeps a programming error from silently producing a no-op evaluator.
    """
    if gate.type != "pre-publish":
        raise ValueError(
            f"runbook evaluator only valid for type='pre-publish' gates; "
            f"got gate {gate.name!r} with type={gate.type!r}"
        )
    if not gate.runbook_url:
        raise ValueError(
            f"runbook evaluator requires runbook_url; gate {gate.name!r} "
            f"has none. (Gate model validator should have caught this.)"
        )

    gate_name = gate.name
    runbook_url = gate.runbook_url

    # Async handler — evaluate_gate dispatches through aexecute which
    # eagerly rejects mixed sync/async chains (interceptors.ChainError).
    # Other interceptor evaluators in the codebase (project_rules
    # extensions, future GitHub-API-backed checks) are async, so the
    # runbook evaluator joins the async cohort even though its body
    # is pure-CPU (no awaits needed).
    async def enter(ctx: Context) -> Context:
        confirmations = ctx.request.get(RUNBOOK_CONFIRMATIONS_REQUEST_KEY, {})
        confirmed = bool(confirmations.get(gate_name, False))
        result: dict = {
            "status": "passed" if confirmed else "unconfirmed",
            "gate_name": gate_name,
            "confirmed": confirmed,
            "runbook_url": runbook_url,
        }
        if not confirmed:
            result["manual_steps"] = [
                (
                    f"Run the operator runbook at "
                    f"$FORGE_MANAGER_DOCS_REPO/{runbook_url}."
                ),
                (
                    f"Pass runbook_confirmations[{gate_name!r}]=True to "
                    f"validate_release once the runbook reports pass."
                ),
            ]
        new_response = {**ctx.response, gate_name: result}
        return replace(ctx, response=new_response)

    return Interceptor(enter=enter, name=f"runbook_evaluator[{gate_name}]")


def register_runbook_evaluators(registry: "GateRegistry") -> list[str]:
    """Register a default evaluator for every pre-publish gate in the registry.

    Idempotent — re-registering for the same gate replaces the prior
    entry (last-wins, per :func:`register_default_evaluator`'s contract).
    Returns the list of gate names registered, for audit logging and
    test assertions.

    Called from :func:`forge_manager_mcp.server.build.build_server`
    after the gate registry loads. Safe to call from tests with a
    custom :class:`GateRegistry` — the module-level evaluator dict is
    process-wide so concurrent registrations against different
    registries clobber each other in last-wins order (intentional —
    matches the existing :func:`register_default_evaluator` semantics).
    """
    registered: list[str] = []
    for gate in registry.list_gates(type="pre-publish"):
        evaluator = make_runbook_evaluator(gate)
        register_default_evaluator(gate.name, evaluator)
        registered.append(gate.name)
    return registered


__all__ = [
    "RUNBOOK_CONFIRMATIONS_REQUEST_KEY",
    "make_runbook_evaluator",
    "register_runbook_evaluators",
]
