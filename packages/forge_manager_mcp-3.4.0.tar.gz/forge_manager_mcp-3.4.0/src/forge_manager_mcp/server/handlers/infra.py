"""Infrastructure handlers: replay_pending, check_skill_version,
scaffold_project."""
from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable

from mcp.types import TextContent

from ...adapters.local_store import DEFAULT_DOCS_REPO_ENV, LocalStoreAdapter
from ...buffer import clear_pending, read_pending
from ...context import ServerContext
from ...docs_repo import (
    DocsRepoOriginConflict,
    default_docs_repo_path as _shared_default_docs_repo_path,
    docs_repo_readme as _shared_docs_repo_readme,
    ensure_local_docs_repo as _shared_ensure_local_docs_repo,
    git_init_if_absent as _shared_git_init_if_absent,
    git_set_origin as _shared_git_set_origin,
    seed_docs_repo_readme as _shared_seed_docs_repo_readme,
)
from ...github.projects import STATUS_OPTIONS
from ...parsers import parse_changelog, parse_skill_version, semver_gt
# Late binding — see helpers.py docstring.
from forge_manager_mcp import server as _s
from ..helpers import (
    STANDARD_LABELS,
    fetch_upstream_skill_text,
    ok,
    resolve_local_skill_path,
)


CallTool = Callable[[str, dict], Awaitable[list[TextContent]]]

# Discussion categories every managed project needs. Created manually
# in the dev-repo UI (GitHub exposes no API for category creation);
# scaffold_project v2 pauses with instructions if any are missing.
#
# `Announcements` is created by default by GitHub when Discussions are
# enabled and is used as-is for Project Index, Session Lock, and
# running-log Discussions (the role that pre-2.0.0a2 called "Project").
# It's not in the required list because it always exists; we resolve
# it by ID at scaffold time. (#152)
REQUIRED_DISCUSSION_CATEGORIES: tuple[str, ...] = (
    "Architecture",
    "UX / UI",
    "Ideas",
    "claude-use-only",
)

# GitHub's default Status options on a freshly-created ProjectV2 board.
# If we see exactly this set on an existing board, it's safe to clobber
# with the canonical STATUS_OPTIONS.
_PROJECT_V2_DEFAULT_STATUS_OPTIONS: frozenset[str] = frozenset(
    {"Todo", "In Progress", "Done"}
)

_CONFIG_FILE_VERSION = "1.0.0"
_CONFIG_RELPATH = Path(".claude") / "github-config.json"


_DEFAULT_REPLAY_TARGETS = ("file", "replication")


async def replay_pending(
    ctx: ServerContext,
    call_tool: CallTool,
    *,
    targets: list[str] | None = None,
    inspect_only: bool = False,
) -> list[TextContent]:
    """Replay buffered operations (#57) through the server's dispatch.

    Two replay surfaces (#274 Phase D):

      * **File buffer** at ``.claude/pending-posts.md`` — populated
        when an MCP tool can't reach its backend (HTTP 403 / network
        / etc.). Each entry replays the original tool call through
        the normal dispatch.
      * **ReplicationManager pending writes** — populated when a
        remote mirror went DEGRADED during a fan-out write. Each
        entry is the original op callable; the manager re-issues it
        against the recovered adapter.

    ``targets`` scopes the drain. Default = both surfaces (legacy
    behavior). Pass ``["file"]`` or ``["replication"]`` to drain only
    one. Unknown values raise ValueError. Both drains report
    independently in the response — the section for an opted-out
    target is empty / zero-valued.

    ``inspect_only=True`` returns the buffer / queue contents without
    draining anything. Useful for diagnostics on a long-buffered
    project: see what's queued for which tool, which mirrors have
    pending writes, without committing to a replay run that might
    fail and re-buffer noisily. Response shape adds an
    ``inspect_only: true`` flag and a ``pending`` section describing
    what *would* drain.
    """
    selected = tuple(targets) if targets else _DEFAULT_REPLAY_TARGETS
    unknown = [t for t in selected if t not in _DEFAULT_REPLAY_TARGETS]
    if unknown:
        raise ValueError(
            f"Unknown replay target(s): {unknown!r}. Valid: "
            f"{list(_DEFAULT_REPLAY_TARGETS)}."
        )

    if inspect_only:
        return _inspect_pending(ctx, selected)

    failures: list[dict] = []
    entries: list[dict] = []
    if "file" in selected:
        entries = read_pending(ctx.project_dir)
        if entries:
            # Clear up front; individual failures re-buffer via the
            # normal path.
            clear_pending(ctx.project_dir)

            for entry in entries:
                tool_name = entry.get("tool", "")
                args = entry.get("args", {})
                try:
                    result_content = await call_tool(tool_name, args)
                except Exception as exc:  # noqa: BLE001 — one bad entry mustn't
                    # abort the whole replay
                    failures.append({"tool": tool_name, "error": str(exc), "args": args})
                    continue

                is_failure = False
                err_msg = ""
                if result_content:
                    text = result_content[0].text
                    try:
                        parsed = json.loads(text)
                        if isinstance(parsed, dict) and parsed.get("success") is False:
                            is_failure = True
                            err_msg = parsed.get("error", "unknown")
                    except (ValueError, json.JSONDecodeError):
                        pass  # plain-text success

                if is_failure:
                    failures.append({"tool": tool_name, "error": err_msg, "args": args})

    # Drain ReplicationManager pending writes too. ``replication`` is
    # only None pre-bootstrap; replay_pending requires config so we'd
    # never hit dispatch in that mode.
    replication_report: dict[str, dict] = {}
    if "replication" in selected and ctx.replication is not None:
        replication_report = await ctx.replication.replay_pending_writes()

    file_replayed = len(entries)
    return ok(
        {
            "replayed": file_replayed,
            "succeeded": file_replayed - len(failures),
            "failed": len(failures),
            "failures": failures,
            "replication": replication_report,
        }
    )


def _inspect_pending(
    ctx: ServerContext, selected: tuple[str, ...],
) -> list[TextContent]:
    """Return the buffer contents without draining anything.

    Pure read — counts file-buffer entries grouped by tool name and
    summarizes per-adapter ``pending_writes`` from the
    ReplicationManager. Useful for diagnostics before deciding
    whether to run a live replay.
    """
    file_summary: dict[str, int | list] = {"count": 0, "by_tool": {}}
    if "file" in selected:
        entries = read_pending(ctx.project_dir)
        by_tool: dict[str, int] = {}
        for entry in entries:
            name = entry.get("tool", "")
            by_tool[name] = by_tool.get(name, 0) + 1
        file_summary = {
            "count": len(entries),
            "by_tool": by_tool,
        }

    replication_summary: dict[str, dict] = {}
    if "replication" in selected and ctx.replication is not None:
        for platform_id, state in ctx.replication.states().items():
            count = ctx.replication.pending_count(platform_id)
            if count == 0 and state.value == "healthy":
                continue
            replication_summary[platform_id] = {
                "state": state.value,
                "pending_writes": count,
            }

    return ok(
        {
            "inspect_only": True,
            "pending": {
                "file": file_summary,
                "replication": replication_summary,
            },
        }
    )


async def check_skill_version(ctx: ServerContext) -> list[TextContent]:
    """Report drift between the local skill file and its upstream copy (#60).

    Pre-bootstrap-safe (#156): when `ctx.config` is None, returns the
    local-half result with `latest_version=None` — no upstream lookup
    is possible without knowing which repo pair to query.
    """
    local_path = resolve_local_skill_path(ctx.project_dir)
    installed_version: str | None = None
    if local_path is not None:
        try:
            installed_version = parse_skill_version(
                local_path.read_text(encoding="utf-8")
            )
        except OSError:
            installed_version = None

    latest_version: str | None = None
    upstream_changelog: list[dict] = []
    if ctx.config is not None:
        upstream_text = await fetch_upstream_skill_text(
            ctx.github_token,
            ctx.config.repos.public,
            ctx.config.repos.private,
        )
        if upstream_text:
            latest_version = parse_skill_version(upstream_text)
            upstream_changelog = parse_changelog(upstream_text)

    drift = (
        bool(installed_version)
        and bool(latest_version)
        and installed_version != latest_version
    )

    if installed_version and latest_version and upstream_changelog:
        changelog_summary = [
            e
            for e in upstream_changelog
            if semver_gt(e["version"], installed_version)
        ]
    else:
        changelog_summary = upstream_changelog if drift else []

    return ok(
        {
            "installed_version": installed_version,
            "installed_path": (
                str(local_path.relative_to(ctx.project_dir))
                if local_path is not None
                else None
            ),
            "latest_version": latest_version,
            "drift": drift,
            "changelog_summary": changelog_summary,
        }
    )


# Docs-repo helpers live in ``forge_manager_mcp.docs_repo`` so the
# migration runner can reuse them without dragging in the full
# handler stack (G6). The wrappers below preserve the existing
# private-name surface so handler tests (and any out-of-tree
# imports) keep resolving.

def _default_docs_repo_path(project_name: str) -> Path:
    return _shared_default_docs_repo_path(project_name)


def _docs_repo_readme(project_name: str) -> str:
    return _shared_docs_repo_readme(project_name)


def _seed_docs_repo_readme(path: Path, project_name: str) -> bool:
    return _shared_seed_docs_repo_readme(path, project_name)


def _git_init_if_absent(path: Path) -> bool:
    return _shared_git_init_if_absent(path)


def _git_set_origin(path: Path, remote_url: str) -> str:
    return _shared_git_set_origin(path, remote_url)


def _ensure_local_docs_repo(
    docs_path: Path,
    *,
    project_name: str,
    remote_url: str | None,
) -> dict[str, str]:
    return _shared_ensure_local_docs_repo(
        docs_path,
        project_name=project_name,
        remote_url=remote_url,
    )


async def _ensure_repo(
    token: str,
    org: str,
    org_id: str,
    name: str,
    visibility: str,
    description: str,
) -> dict:
    """Return a repo descriptor, creating the repo if it doesn't exist.

    Idempotency anchor for scaffold_project v2: a re-run against an
    org where the repo pair already exists skips creation and returns
    the existing node IDs.

    Descriptor: {"id", "name_with_owner", "url", "created_now": bool}.
    """
    try:
        node_id = await _s.get_repo_node_id(token, org, name)
        return {
            "id": node_id,
            "name_with_owner": f"{org}/{name}",
            "url": f"https://github.com/{org}/{name}",
            "created_now": False,
        }
    except _s.GitHubError:
        repo = await _s.create_repository(
            token,
            owner_id=org_id,
            name=name,
            visibility=visibility,
            description=description,
        )
        return {
            "id": repo["id"],
            "name_with_owner": repo["name_with_owner"],
            "url": repo["url"],
            "created_now": True,
        }


async def _seed_labels(token: str, repo_id: str) -> list[str]:
    """Create STANDARD_LABELS on a repo; swallow already-exists errors."""
    created: list[str] = []
    for label_name, color, label_desc in STANDARD_LABELS:
        try:
            await _s.create_label(token, repo_id, label_name, color, label_desc)
            created.append(label_name)
        except (_s.GitHubError, ValueError):
            pass
    return created


def _read_existing_config(path: Path) -> dict | None:
    """Return the existing github-config.json contents, or None if absent/invalid."""
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _try_parse_skill_version(project_dir: Path) -> str | None:
    """Parse the version header of a locally-installed skill file, or None."""
    local_path = resolve_local_skill_path(project_dir)
    if local_path is None:
        return None
    try:
        return parse_skill_version(local_path.read_text(encoding="utf-8"))
    except OSError:
        return None


def _build_config(
    *,
    org: str,
    public_repo: dict,
    dev_repo: dict,
    project: dict,
    status_field: dict,
    project_discussion_id: str,
    session_lock_discussion_id: str,
    categories: dict[str, dict],
    skill_version: str | None,
    existing: dict | None,
    docs_repo: dict | None = None,
    docs_repo_path: str | None = None,
) -> dict:
    """Compose the github-config.json payload, merging with any existing file.

    Existing values take precedence for `bootstrapped_at` (original
    timestamp) and `skill_version_at_bootstrap` (first-install pin).
    Every other key is recomputed from the current run so a re-run
    refreshes stale IDs.
    """
    existing = existing or {}
    bootstrapped_at = existing.get("bootstrapped_at") or datetime.now(
        timezone.utc
    ).isoformat().replace("+00:00", "Z")
    pinned_skill_version = existing.get("skill_version_at_bootstrap", skill_version)

    config: dict[str, Any] = {
        "version": _CONFIG_FILE_VERSION,
        "skill": "forge-manager",
        "account_type": "org",
        "owner": org,
        "repos": {
            "public": public_repo["name_with_owner"],
            "private": dev_repo["name_with_owner"],
            **(
                {"docs": docs_repo["name_with_owner"]}
                if docs_repo is not None
                else {}
            ),
        },
        "project_board": {
            "id": project["id"],
            "number": project["number"],
            "url": project["url"],
            "status_field_id": status_field["field_id"],
            "status_options": dict(status_field["options"]),
        },
        "project_discussion_id": project_discussion_id,
        "session_lock_discussion_id": session_lock_discussion_id,
        "discussion_categories": {
            name: {
                "id": categories[name]["id"],
                "isAnswerable": categories[name]["isAnswerable"],
            }
            # Include Announcements (the GitHub-default category we use
            # for Project Index / Session Lock) plus the required categories.
            # Pre-2.0.0a2 skill versions stored this under the key "Project";
            # consumers resolving by name should fall back to "Project" if
            # "Announcements" isn't present in older configs (#152).
            for name in ("Announcements",) + REQUIRED_DISCUSSION_CATEGORIES
            if name in categories
        },
        "skill_version_at_bootstrap": pinned_skill_version,
        "bootstrapped_at": bootstrapped_at,
    }
    if docs_repo_path is not None:
        config["docs_repo_path"] = docs_repo_path
    return config


def _write_config(path: Path, config: dict) -> None:
    """Write github-config.json, creating parent directories as needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")


_SETTINGS_RELPATH = Path(".claude") / "settings.json"


def _ensure_eager_tool_search(project_dir: Path) -> str:
    """Write `.claude/settings.json` with `env.ENABLE_TOOL_SEARCH=false` (#160).

    Claude Code's MCP launcher defers tool schemas by default — tools
    are listed but not callable until Claude calls `ToolSearch` to load
    each schema. For a forge-manager project that's friction at
    every session start (`open_session` is the first thing the protocol
    runs). Setting `ENABLE_TOOL_SEARCH=false` loads schemas eagerly.

    Behavior:
    - File absent → create with `{"env": {"ENABLE_TOOL_SEARCH": "false"}}`.
    - File exists, no `env.ENABLE_TOOL_SEARCH` key → merge the key in,
      preserving every other field.
    - Key already set to "false" → no-op.
    - Key set to anything else (operator chose differently) → leave it
      alone; do not overwrite a deliberate operator choice.

    Returns one of: "created", "merged", "unchanged", "preserved_user_value".
    """
    settings_path = project_dir / _SETTINGS_RELPATH
    if not settings_path.exists():
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"env": {"ENABLE_TOOL_SEARCH": "false"}}
        settings_path.write_text(
            json.dumps(payload, indent=2) + "\n", encoding="utf-8"
        )
        return "created"

    try:
        raw = settings_path.read_text(encoding="utf-8")
        existing = json.loads(raw) if raw.strip() else {}
    except (OSError, ValueError):
        # Malformed JSON: don't overwrite, surface via return value.
        return "preserved_user_value"

    if not isinstance(existing, dict):
        return "preserved_user_value"

    env = existing.get("env")
    if not isinstance(env, dict):
        existing["env"] = {"ENABLE_TOOL_SEARCH": "false"}
        settings_path.write_text(
            json.dumps(existing, indent=2) + "\n", encoding="utf-8"
        )
        return "merged"

    current_value = env.get("ENABLE_TOOL_SEARCH")
    if current_value == "false":
        return "unchanged"
    if current_value is None:
        env["ENABLE_TOOL_SEARCH"] = "false"
        settings_path.write_text(
            json.dumps(existing, indent=2) + "\n", encoding="utf-8"
        )
        return "merged"

    # Operator set the value to something else — respect that.
    return "preserved_user_value"


_CLAUDEMD_RELPATH = Path("CLAUDE.md")


_PROJECT_RULES_RELPATH = Path(".claude") / "project-rules.md"


def _ensure_project_rules_md(
    project_dir: Path,
    *,
    project_name: str,
    require_bazel_builds: bool = False,
    require_maximal_coverage: bool = False,
    enable_llm_verifier: bool | None = None,
    custom_running_log: str | None = None,
) -> str:
    """Write `.claude/project-rules.md` from the canonical template if absent (#289).

    Companion to ``_ensure_claude_md``. From #289 onward, scaffold
    splits identity (CLAUDE.md) from rules (this file) — greenfield
    projects start with a structured rules surface so they don't
    accumulate ad-hoc ``## Overrides`` content that #290's audit then
    has to detangle.

    Operator-input flags toggle each rule between an uncommented entry
    (operator opted in at scaffold time) and a commented example
    (operator can uncomment later without remembering the schema).
    Headings always present so the file is a complete skeleton.

    Returns one of: "created", "exists" (caller decides whether to
    flag the file for audit-then-migrate via #290).
    """
    path = project_dir / _PROJECT_RULES_RELPATH
    if path.exists():
        return "exists"
    path.parent.mkdir(parents=True, exist_ok=True)

    bazel_block = _bazel_rule_block(require_bazel_builds)
    coverage_block = _coverage_rule_block(require_maximal_coverage)
    llm_verifier_block = _llm_verifier_state_block(enable_llm_verifier)
    running_log_block = _running_log_rule_block(custom_running_log)

    body = (
        f"# Project Rules — {project_name}\n\n"
        "Per the protocol-vs-project separation framework (#288), this\n"
        "file carries every project-specific rule that extends, "
        "overrides, or open/closes a named skill gate. Identity\n"
        "(repo trio, dates, board URL) lives in `CLAUDE.md`; rules\n"
        "live here.\n\n"
        "Each rule cross-references a formal gate name from\n"
        "`.claude/skills/forge-manager/gates.yaml` (#287); the validator\n"
        "asserts every reference resolves at PR-open time.\n\n"
        "## Independent rules\n\n"
        "Project-internal rules with no skill-protocol interaction.\n\n"
        f"{bazel_block}\n\n"
        "## Gate extensions\n\n"
        "Tighter rules layered on top of named skill gates.\n\n"
        f"{coverage_block}\n\n"
        f"{running_log_block}\n\n"
        "## Gate overrides\n\n"
        "Replacement rules. Greenfield projects typically have none —\n"
        "if you find yourself wanting to override a skill gate's\n"
        "default evaluator, first ask whether an extension would suffice;\n"
        "overrides halt the chain and are blunter.\n\n"
        "<!--\n"
        "### Overrides `release.bazel_tests_green`\n"
        "**Replacement:** [your replacement evaluator description]\n"
        "**Why:** [project-specific rationale]\n"
        "-->\n\n"
        "## Gate state declarations\n\n"
        "Open or close named gates. `Closes` short-circuits the chain\n"
        "before any other layer runs; `Opens` is a documentation marker\n"
        "(gates default open).\n\n"
        f"{llm_verifier_block}\n"
    )
    path.write_text(body, encoding="utf-8")
    return "created"


def _bazel_rule_block(require: bool) -> str:
    if require:
        return (
            "### Use Bazel for all build and test\n\n"
            "Every language in this project (and any subsystem) is\n"
            "built and tested through Bazel. Do not invoke language-\n"
            "native runners directly — no `python -m pytest`, "
            "`npm test`, `cargo test`, `go test`, etc. Dev/test\n"
            "dependencies live in the Bazel `requirement(...)`\n"
            "mechanism, not in language-native package files."
        )
    return (
        "<!--\n"
        "### Use Bazel for all build and test\n"
        "Every language in this project uses Bazel. No language-native\n"
        "runners. Add this rule via `audit_project_prose --apply` if\n"
        "the project standardizes on Bazel.\n"
        "-->"
    )


def _coverage_rule_block(require: bool) -> str:
    if require:
        return (
            "### Extends `commit.test_coverage`\n\n"
            "**Extension:** Maximal coverage — every new code path "
            "in the diff (new function, new branch, new error case, "
            "new feature field) must be exercised by at least one test "
            "in the **same** commit.\n"
            "**Why:** Catches the test-after-the-fact pattern at PR "
            "review rather than after a regression ships.\n"
            "**How to apply:** `bazel test` (or the language-native "
            "equivalent) must be green; new branches that aren't "
            "covered surface in the verifier's `rule_violations` list."
        )
    return (
        "<!--\n"
        "### Extends `commit.test_coverage`\n"
        "**Extension:** [your tightening of the test-coverage gate]\n"
        "**Why:** [project-specific rationale]\n"
        "-->"
    )


def _llm_verifier_state_block(enabled: bool | None) -> str:
    if enabled is False:
        return (
            "### Closes `commit.llm_verifier`\n\n"
            "**Reason:** ANTHROPIC_API_KEY not configured for this "
            "project at scaffold time.\n"
            "**Re-open when:** the key is provisioned and the project "
            "wants drift-checking on plan assumptions during PR review.\n"
        )
    return (
        "<!--\n"
        "### Closes `commit.llm_verifier`\n"
        "**Reason:** [why the LLM verifier doesn't apply to this project]\n"
        "**Re-open when:** [condition under which the gate should fire]\n"
        "-->"
    )


def _running_log_rule_block(custom: str | None) -> str:
    if custom:
        return (
            "### Extends `commit.diff_covers_plan`\n\n"
            "**Extension:** Skill-prose ↔ running-log paired-edit "
            "rule — every PR that touches "
            "`.claude/skills/forge-manager/*.md` must also edit the "
            f"project's running-log Discussion ({custom}).\n"
            "**Why:** Keeps the protocol-rules map current without "
            "requiring a separate cleanup PR cycle.\n"
            "**Cross-link:** [discussion URL or bare reference]"
        )
    return (
        "<!--\n"
        "### Extends `commit.diff_covers_plan`\n"
        "**Extension:** [paired-edit signal — e.g., skill prose ↔\n"
        "running-log Discussion]\n"
        "**Why:** [project-specific rationale]\n"
        "**Cross-link:** [discussion / issue URL]\n"
        "-->"
    )


_PLATFORM_LABELS: dict[str, str] = {
    "github": "GitHub",
    "codeberg": "Codeberg",
    "forgejo": "Forgejo",
    "gitlab": "GitLab",
    "local": "local docs store",
}


def _platforms_phrase(platform_ids: list[str]) -> str:
    """Render a configured platform list as the human-readable phrase
    that goes into the CLAUDE.md template (#286).

    Maps each ``platform_id`` to its display label, joins with ' / ',
    and returns the phrase. Empty list → fallback to the legacy four-
    backend list so the template stays informative on configs that
    haven't run the multi-platform migration yet.
    """
    if not platform_ids:
        return "GitHub / Forgejo+Codeberg / GitLab / local docs store"
    seen: list[str] = []
    for pid in platform_ids:
        label = _PLATFORM_LABELS.get(pid, pid)
        if label not in seen:
            seen.append(label)
    return " / ".join(seen)


def _ensure_claude_md(
    project_dir: Path,
    *,
    org: str,
    project_name: str,
    skill_version: str | None,
    bootstrapped_at: str,
    platforms: list[str] | None = None,
) -> str:
    """Write `CLAUDE.md` from the canonical template if absent (#157).

    The template encodes the always-engage directive — at session
    start, before responding to user input, invoke
    `/forge-manager:forge-manager` to engage the protocol. The plugin-
    namespaced form (3.3.0 / Phase 2 plugin-format migration) works in
    both install paths: scaffolded projects with a project-level skill
    at .claude/skills/forge-manager/ AND plugin-installed projects.
    Bare `/forge-manager` resolves to the project-level skill when
    present (Claude Code priority); plugin-only installs require the
    namespaced form. CLAUDE.md content loads into Claude's context
    every session, so this directive runs deterministically (unlike
    Claude Code's probabilistic skill auto-invoke).

    The ``platforms`` arg (#286) carries the project's configured
    backend ids (``["local", "github"]``, ``["local", "codeberg"]``,
    etc.) so the §Skill Reference paragraph names only the actually-
    configured backends rather than the full four-backend list.
    Empty / None falls back to the legacy phrasing.

    Behavior:
    - File absent → write the template.
    - File exists → leave it alone (operator may have customized it).
      Surface the no-op via the return value so the caller can
      flag the file for manual update if it lacks the directive.

    Returns one of: "created", "exists" (caller decides whether to
    flag for manual update).
    """
    path = project_dir / _CLAUDEMD_RELPATH
    if path.exists():
        return "exists"

    skill_line = (
        f"- Skill version at bootstrap: {skill_version}"
        if skill_version
        else "- Skill version at bootstrap: (not detected)"
    )
    backends_phrase = _platforms_phrase(platforms or [])
    body = (
        f"# CLAUDE.md — {project_name}\n\n"
        "## Skill Reference\n\n"
        "This project uses the forge-manager skill at\n"
        "`.claude/skills/forge-manager/SKILL.md`. **At session start,\n"
        "before responding to user input, invoke `/forge-manager:forge-manager`\n"
        "to engage the protocol.** All conversation thereafter follows the\n"
        "recording, classification, and session-lifecycle protocol the skill\n"
        "defines — every turn recorded to the configured forge backends\n"
        f"({backends_phrase}, per `forge-config.json.platforms`).\n\n"
        "The plugin-namespaced engage form (3.3.0 / Phase 2) works in both\n"
        "install paths: scaffolded projects with a project-level skill at\n"
        "`.claude/skills/forge-manager/` AND `/plugin install`-installed\n"
        "projects. Bare `/forge-manager` resolves to the project-level skill\n"
        "when present (Claude Code priority); the namespaced form is\n"
        "required for plugin-only installs.\n\n"
        "Project-specific rules (extensions / overrides / gate state\n"
        "declarations) live in `.claude/project-rules.md` per #288, not\n"
        "in this file. CLAUDE.md is identity + structural information\n"
        "only from #289 onward.\n\n"
        "## Project Identity\n"
        f"- Public repo: {org}/{project_name}\n"
        f"- Private repo: {org}/{project_name}-dev\n"
        f"- Docs repo: {org}/{project_name}-docs\n"
        "- Account type: org\n"
        f"- Bootstrapped: {bootstrapped_at}\n"
        f"{skill_line}\n\n"
        "## Project-Specific Conventions\n"
        "[Filled in as the project develops — added by Claude when\n"
        "project-specific patterns emerge, or by user explicitly]\n"
    )
    path.write_text(body, encoding="utf-8")
    return "created"


async def scaffold_project(
    ctx: ServerContext,
    org: str,
    project_name: str,
    description: str,
) -> list[TextContent]:
    """#81 — Scaffold a new managed project (v2: full bootstrap).

    .. deprecated:: 3.0.x — multi-platform scaffold series

       Prefer ``scaffold_project_multi`` for new projects.
       ``GitHubAdapter.bootstrap_project`` (C2 absorbed in commits
       e8b0baa / 1fed4eb / 9e31c06 / 33e8af7) now drives the same
       flow at the canonical-dispatch layer. This legacy handler
       remains for backwards compat — every artifact-creation step
       it performs is duplicated by the adapter path. Once
       ``scaffold_project_multi`` smoke-tests live on GitHub, this
       handler is a candidate for replacement-as-thin-wrapper:
       it would build a default ``[local, github]`` platforms list,
       delegate to ``scaffold_project_multi``, and add the
       project-state side-effects (forge-config.json emission,
       .claude/settings.json wiring, CLAUDE.md generation) on top.

    Two-phase idempotent flow:

    * **Phase A** (first call against an empty org): create repo pair,
      seed labels, enable Discussions on dev repo, create ProjectV2
      board + Status field, link board to both repos. Pauses and
      returns manual-steps if Discussion categories are missing — the
      one GitHub feature with no API.
    * **Phase B** (re-run once categories are manually created):
      detect the required categories, seed Project + Session-Lock
      Discussions, write `.claude/github-config.json`.

    Every step inspects live state first and no-ops when already
    satisfied, so the tool is safe to re-run at any point.

    GitHub-only by design — multi-platform projects use
    ``scaffold_project_multi`` instead.
    """
    if not org.strip() or not project_name.strip():
        raise ValueError("org and project_name must not be empty.")

    # FIX-3: gate on canonical-adapter being GitHub when a config is
    # already present. ``ctx.replication is None`` is the
    # pre-bootstrap mode (no config yet) — we let that through since
    # this IS the bootstrap call. Once the config exists, dispatch
    # surface depends on canonical's platform_id.
    if ctx.replication is not None:
        canonical_id = ctx.replication.canonical().platform_id
        if canonical_id != "github":
            raise ValueError(
                f"scaffold_project is GitHub-only (canonical adapter "
                f"is {canonical_id!r}). Multi-platform scaffold "
                "dispatch is designed but not yet implemented; see "
                "plans/multi-platform-scaffold-design.md. To bootstrap "
                "a non-GitHub-canonical project today, create the "
                "platform-specific artifacts manually (repo / labels / "
                "Discussion-as-Issue category labels) and write "
                ".claude/forge-config.json by hand."
            )

    token = ctx.github_token

    # --- 1. Org exists? ---
    org_id = await _s.get_organization_id(token, org)
    if org_id is None:
        return ok(
            {
                "created": False,
                "phase": "awaiting_org",
                "manual_steps": [
                    (
                        f"Organization '{org}' does not exist. "
                        "Forge platforms generally have no API for "
                        "creating organisations. Create it manually "
                        "via the platform's web UI "
                        "(github.com/settings/organizations, "
                        "codeberg.org/org/create, "
                        "<self-hosted-forgejo>/org/create, "
                        "or gitlab.com/-/groups/new — match the public "
                        "face configured in forge-config.json), "
                        "then re-run scaffold_project."
                    )
                ],
            }
        )

    # --- 2. Ensure repo pair (idempotent) ---
    public_repo = await _ensure_repo(
        token,
        org,
        org_id,
        project_name,
        "PUBLIC",
        description or f"{project_name} — public mirror",
    )
    dev_name = f"{project_name}-dev"
    dev_repo = await _ensure_repo(
        token,
        org,
        org_id,
        dev_name,
        "PRIVATE",
        description or f"{project_name} — private dev, design, and archive",
    )

    # --- 2.5. Ensure docs repo (GitHub PUBLIC + local git init). ---
    # The docs repo is the canonical source the SiteRenderer reads
    # from. Bootstrap creates the GitHub repo as a third PUBLIC repo
    # alongside the public mirror and dev repo, then `git init`s the
    # local clone at ~/<project>-docs/ so subsequent build_site /
    # serve_site / deploy_site calls have a path to render from.
    docs_name = f"{project_name}-docs"
    docs_repo = await _ensure_repo(
        token,
        org,
        org_id,
        docs_name,
        "PUBLIC",
        description or f"{project_name} — rendered-site canonical source",
    )
    docs_local_path = _default_docs_repo_path(project_name)
    docs_remote_url = f"{docs_repo['url']}.git"
    docs_local_actions: dict[str, str] = {}
    docs_local_error: str | None = None
    try:
        docs_local_actions = _ensure_local_docs_repo(
            docs_local_path,
            project_name=project_name,
            remote_url=docs_remote_url,
        )
    except DocsRepoOriginConflict as exc:
        # FIX-6: an unrelated git repo at ~/<project>-docs/ has its own
        # origin. Surface the conflict explicitly rather than silently
        # rebinding the user's repo.
        docs_local_error = str(exc)
    except (subprocess.CalledProcessError, OSError) as exc:
        docs_local_error = (
            f"Local docs-repo init at {docs_local_path} failed: {exc}. "
            "Initialise it manually: "
            f"`mkdir -p {docs_local_path} && cd {docs_local_path} && "
            f"git init -b main && git remote add origin {docs_remote_url}`."
        )

    # --- 3. Seed labels on both repos ---
    public_labels = await _seed_labels(token, public_repo["id"])
    dev_labels = await _seed_labels(token, dev_repo["id"])

    # --- 4. Enable Discussions on dev repo ---
    state = await _s.get_repo_discussions_state(token, dev_repo["id"])
    discussions_enabled_now = False
    if not state["enabled"]:
        await _s.enable_discussions(token, dev_repo["id"])
        discussions_enabled_now = True
        state = await _s.get_repo_discussions_state(token, dev_repo["id"])

    # --- 5. Ensure ProjectV2 board + link both repos ---
    existing_projects = [
        p for p in await _s.list_owner_projects(token, org_id) if p["title"] == project_name
    ]
    if existing_projects:
        project = existing_projects[0]
        project_created_now = False
    else:
        project = await _s.create_projectv2(token, org_id, project_name)
        project_created_now = True

    await _s.link_projectv2_to_repo(token, project["id"], public_repo["id"])
    await _s.link_projectv2_to_repo(token, project["id"], dev_repo["id"])

    # --- 6. Set Status field options (read-diff-write, #6) ---
    status_field = await _s.get_project_status_field(token, project["id"])
    current_names = set(status_field["options"].keys())
    desired_names = set(STATUS_OPTIONS)
    status_manual_note: str | None = None
    if current_names == desired_names:
        pass  # already correct
    elif project_created_now or current_names == _PROJECT_V2_DEFAULT_STATUS_OPTIONS:
        status_field = await _s.update_projectv2_status_options(
            token, project["id"], status_field["field_id"], STATUS_OPTIONS
        )
    else:
        # Pre-existing board with custom Status options — don't clobber.
        status_manual_note = (
            f"Project board {project['url']} has custom Status options "
            f"({sorted(current_names)}). Expected: {list(STATUS_OPTIONS)}. "
            "Update them manually under the board's ⋯ → Settings → "
            "Fields → Status."
        )

    project_board_descriptor = {
        "id": project["id"],
        "number": project["number"],
        "url": project["url"],
        "status_field_id": status_field["field_id"],
        "status_options": dict(status_field["options"]),
        "created_now": project_created_now,
    }

    # --- 7. Discussion categories check ---
    missing_categories = [
        c for c in REQUIRED_DISCUSSION_CATEGORIES if c not in state["categories"]
    ]
    if missing_categories:
        manual_steps = [
            (
                f"Create Discussion categories on "
                f"{dev_repo['name_with_owner']} (Settings → Discussions "
                f"→ Categories) — missing: {missing_categories}. "
                "Required formats: Architecture (Q&A), UX / UI "
                "(Open-ended), Ideas (Open-ended), claude-use-only "
                "(Open-ended). The GitHub-default `Announcements` "
                "category is used as-is (no creation needed). After "
                "creating the missing categories, re-run scaffold_project "
                "to finish Phase B."
            )
        ]
        if status_manual_note:
            manual_steps.append(status_manual_note)
        if docs_local_error:
            manual_steps.append(docs_local_error)
        return ok(
            {
                "created": False,
                "phase": "awaiting_categories",
                "public_repo": public_repo,
                "dev_repo": dev_repo,
                "docs_repo": docs_repo,
                "docs_local_path": str(docs_local_path),
                "docs_local_actions": docs_local_actions,
                "labels_seeded": {
                    public_repo["name_with_owner"]: public_labels,
                    dev_repo["name_with_owner"]: dev_labels,
                },
                "discussions_enabled_now": discussions_enabled_now,
                "project_board": project_board_descriptor,
                "categories_present": sorted(state["categories"].keys()),
                "categories_missing": missing_categories,
                "manual_steps": manual_steps,
            }
        )

    # --- 8. Seed Project + Session-Lock Discussions ---
    config_path = ctx.project_dir / _CONFIG_RELPATH
    existing_config = _read_existing_config(config_path)
    # Prefer the GitHub-default `Announcements` category (#152). Fall
    # back to `Project` for repos that completed bootstrap before 2.0.0a2
    # — they continue to resolve as before.
    if "Announcements" in state["categories"]:
        project_category_id = state["categories"]["Announcements"]["id"]
    elif "Project" in state["categories"]:
        project_category_id = state["categories"]["Project"]["id"]
    else:
        raise ValueError(
            "Neither 'Announcements' (GitHub default, expected) nor "
            "'Project' (legacy, pre-2.0.0a2) category found on the dev "
            "repo. Enable Discussions and verify the default Announcements "
            "category exists, or create one manually."
        )

    project_discussion_id = (
        existing_config.get("project_discussion_id") if existing_config else None
    )
    project_discussion_created_now = False
    if not project_discussion_id:
        disc = await _s.create_discussion(
            token,
            dev_repo["id"],
            project_category_id,
            f"{project_name} — Project",
            (
                "Project Discussion (navigation hub).\n\n"
                "The server's `update_project_toc` will populate this "
                "post with the living Discussions + Issues TOC on the "
                "next turn that touches a tracked thread."
            ),
        )
        project_discussion_id = disc["id"]
        project_discussion_created_now = True

    session_lock_discussion_id = (
        existing_config.get("session_lock_discussion_id") if existing_config else None
    )
    session_lock_created_now = False
    if not session_lock_discussion_id:
        disc = await _s.create_discussion(
            token,
            dev_repo["id"],
            project_category_id,
            f"{project_name} — Session Lock",
            (
                "Session Lock Discussion.\n\n"
                "`open_session` posts a session-opened comment here; "
                "`close_session` posts a session-closed comment with "
                "the session summary. One session at a time, serialised "
                "through this discussion."
            ),
        )
        session_lock_discussion_id = disc["id"]
        session_lock_created_now = True

    # --- 9. Write .claude/github-config.json ---
    config = _build_config(
        org=org,
        public_repo=public_repo,
        dev_repo=dev_repo,
        project=project,
        status_field=status_field,
        project_discussion_id=project_discussion_id,
        session_lock_discussion_id=session_lock_discussion_id,
        categories=state["categories"],
        skill_version=_try_parse_skill_version(ctx.project_dir),
        existing=existing_config,
        docs_repo=docs_repo,
        docs_repo_path=str(docs_local_path),
    )
    _write_config(config_path, config)

    # --- 10. Seed .claude/settings.json with eager-load (#160) ---
    settings_action = _ensure_eager_tool_search(ctx.project_dir)

    # --- 11. Generate CLAUDE.md from template (#157) ---
    # #286: pass the configured platform list so the §Skill Reference
    # paragraph names only the actually-configured backends.
    configured_platforms = [
        entry.get("id", "")
        for entry in config.get("platforms", [])
        if isinstance(entry, dict) and entry.get("id")
    ]
    claudemd_action = _ensure_claude_md(
        ctx.project_dir,
        org=org,
        project_name=project_name,
        skill_version=_try_parse_skill_version(ctx.project_dir),
        bootstrapped_at=config["bootstrapped_at"],
        platforms=configured_platforms,
    )

    manual_steps: list[str] = []
    if status_manual_note:
        manual_steps.append(status_manual_note)
    if docs_local_error:
        manual_steps.append(docs_local_error)
    if settings_action == "preserved_user_value":
        manual_steps.append(
            "Note: .claude/settings.json contains a non-default "
            "ENABLE_TOOL_SEARCH value (or is malformed). Bootstrap "
            "left it alone. For best UX with forge-manager, "
            "set `env.ENABLE_TOOL_SEARCH = \"false\"` so MCP tool "
            "schemas load eagerly at session start."
        )
    if claudemd_action == "exists":
        manual_steps.append(
            "Note: CLAUDE.md exists; bootstrap did not overwrite it. "
            "Verify it contains the §Skill Reference always-engage "
            "directive (\"At session start, before responding to user "
            "input, invoke /forge-manager\") — see "
            "bootstrap.md §CLAUDE.md Template (#157)."
        )

    return ok(
        {
            "created": True,
            "phase": "complete",
            "public_repo": public_repo,
            "dev_repo": dev_repo,
            "docs_repo": docs_repo,
            "docs_local_path": str(docs_local_path),
            "docs_local_actions": docs_local_actions,
            "labels_seeded": {
                public_repo["name_with_owner"]: public_labels,
                dev_repo["name_with_owner"]: dev_labels,
            },
            "discussions_enabled_now": discussions_enabled_now,
            "project_board": project_board_descriptor,
            "project_discussion_id": project_discussion_id,
            "project_discussion_created_now": project_discussion_created_now,
            "session_lock_discussion_id": session_lock_discussion_id,
            "session_lock_created_now": session_lock_created_now,
            "discussion_categories": {
                name: state["categories"][name]
                for name in REQUIRED_DISCUSSION_CATEGORIES
            },
            "config_path": str(config_path.relative_to(ctx.project_dir)),
            "settings_json_action": settings_action,
            "claude_md_action": claudemd_action,
            "manual_steps": manual_steps,
        }
    )


# ---------------------------------------------------------------------------
# Multi-platform scaffold dispatch (C1 skeleton)
# ---------------------------------------------------------------------------
#
# Walks ``replication_order``; for each platform_id, instantiates the
# adapter and (when ``has_scaffold`` is True) calls
# ``bootstrap_project``. Per-platform results thread through
# ``existing_state`` so later adapters see what earlier ones built.
#
# C1 ships ``LocalStoreAdapter`` as the only ``has_scaffold = True``
# adapter. C2 / C3 / C4 flip GitHubAdapter / ForgejoAdapter /
# GitLabAdapter; once the GitHub refactor lands, this entry replaces
# the legacy GitHub-tight ``scaffold_project`` above. Until then,
# this is a parallel testable surface — not yet wired through the
# MCP tool layer.


def _bootstrap_construct_local(
    platform_config: dict, project_name: str
) -> LocalStoreAdapter:
    """Construct LocalStoreAdapter for the bootstrap path.

    ``LocalStoreAdapter.from_config`` raises if the docs-repo path
    doesn't exist — strict-by-design for run-time. Bootstrap creates
    the path, so resolution mirrors ``from_config`` but skips the
    existence check. C2 may generalize this into a Protocol-level
    ``for_bootstrap`` classmethod once the other adapters need
    similar scaffold-time construction.
    """
    path_str = (
        platform_config.get("path")
        or os.environ.get(DEFAULT_DOCS_REPO_ENV)
        or str(Path.home() / f"{project_name}-docs")
    )
    return LocalStoreAdapter(docs_repo_path=Path(path_str).expanduser())


async def scaffold_project_multi(
    ctx: ServerContext,
    *,
    project_name: str,
    description: str,
    platforms: list[dict],
    replication_order: list[str],
    require_bazel_builds: bool = False,
    require_maximal_coverage: bool = False,
    enable_llm_verifier: bool | None = None,
    custom_running_log: str | None = None,
) -> list[TextContent]:
    """Multi-platform scaffold dispatch (C1 skeleton).

    Per ``plans/multi-platform-scaffold-design.md``: walk
    ``replication_order`` (canonical first), instantiate each adapter,
    skip those with ``has_scaffold = False``, call
    ``bootstrap_project`` on the rest, and accumulate per-platform
    results. ``existing_state`` carries earlier adapters' artifacts so
    later ones can cross-link.

    From #289 onward, scaffold also writes the local project files —
    CLAUDE.md (identity-only) + .claude/project-rules.md (rules-only)
    — so the protocol-vs-project separation framework is in place
    from day one of every greenfield project. The four operator-input
    flags toggle each rule's project-rules entry between an
    uncommented entry (operator opted in) and a commented example
    (operator can uncomment later via audit_project_prose --apply or
    by hand).

    Mid-life adoption: when CLAUDE.md already exists, scaffold
    surfaces a manual_steps entry suggesting the operator run
    audit_project_prose first to detect rules-content that should
    migrate to the new project-rules.md surface before regenerating.
    """
    if not project_name.strip():
        raise ValueError("project_name must not be empty.")
    if not replication_order:
        raise ValueError("replication_order must list at least one platform.")

    from ...adapters.registry import PLATFORM_ADAPTERS

    platforms_by_id = {entry.get("id", ""): entry for entry in platforms}
    existing_state: dict = {}
    per_platform: list[dict] = []
    pending_manual: list[str] = []
    skipped: list[str] = []

    for platform_id in replication_order:
        adapter_cls = PLATFORM_ADAPTERS.get(platform_id)
        if adapter_cls is None:
            raise ValueError(
                f"Unknown platform_id {platform_id!r} in replication_order. "
                f"Known: {sorted(PLATFORM_ADAPTERS)}."
            )
        platform_config = platforms_by_id.get(platform_id, {"id": platform_id})

        if not adapter_cls.has_scaffold:
            skipped.append(platform_id)
            continue

        if platform_id == "local":
            adapter = _bootstrap_construct_local(platform_config, project_name)
        else:
            adapter = adapter_cls.from_config(platform_config)

        owner = platform_config.get("owner", "")
        result = await adapter.bootstrap_project(
            owner=owner,
            project_name=project_name,
            description=description,
            existing_state=existing_state,
        )
        existing_state[platform_id] = dict(result.artifacts)
        per_platform.append(
            {
                "platform_id": result.platform_id,
                "artifacts": dict(result.artifacts),
                "phase": result.phase,
                "manual_steps": list(result.manual_steps),
            }
        )
        pending_manual.extend(result.manual_steps)

    # --- Local project files (#289 — CLAUDE.md + project-rules.md) ---
    bootstrapped_at = datetime.now(timezone.utc).isoformat()
    public_face_owner = ""
    for platform_id in replication_order:
        if platform_id == "local":
            continue
        public_face_owner = platforms_by_id.get(platform_id, {}).get("owner", "")
        if public_face_owner:
            break

    configured_platform_ids = [
        entry.get("id", "")
        for entry in platforms
        if isinstance(entry, dict) and entry.get("id")
    ]

    claudemd_existed = (ctx.project_dir / _CLAUDEMD_RELPATH).exists()
    rules_existed = (ctx.project_dir / _PROJECT_RULES_RELPATH).exists()

    claudemd_action = _ensure_claude_md(
        ctx.project_dir,
        org=public_face_owner or "[org]",
        project_name=project_name,
        skill_version=_try_parse_skill_version(ctx.project_dir),
        bootstrapped_at=bootstrapped_at,
        platforms=configured_platform_ids,
    )
    rules_action = _ensure_project_rules_md(
        ctx.project_dir,
        project_name=project_name,
        require_bazel_builds=require_bazel_builds,
        require_maximal_coverage=require_maximal_coverage,
        enable_llm_verifier=enable_llm_verifier,
        custom_running_log=custom_running_log,
    )

    if claudemd_existed:
        pending_manual.append(
            "Note: CLAUDE.md exists; scaffold did not overwrite it. "
            "Run `audit_project_prose` (#290) to detect rules-content "
            "that should migrate to .claude/project-rules.md before "
            "regenerating CLAUDE.md by hand. The audit's findings "
            "feed into per-rule .claude/project-rules.md entries via "
            "`audit_project_prose --apply <finding-id>`."
        )
    if rules_existed:
        pending_manual.append(
            "Note: .claude/project-rules.md exists; scaffold did not "
            "overwrite it. Operator-input flags "
            "(require_bazel_builds / require_maximal_coverage / "
            "enable_llm_verifier / custom_running_log) had no effect "
            "on this run."
        )

    return ok(
        {
            "phase": "complete" if not pending_manual else "awaiting_manual",
            "manual_steps": pending_manual,
            "platforms": per_platform,
            "skipped_platforms": skipped,
            "claudemd_action": claudemd_action,
            "project_rules_action": rules_action,
        }
    )
