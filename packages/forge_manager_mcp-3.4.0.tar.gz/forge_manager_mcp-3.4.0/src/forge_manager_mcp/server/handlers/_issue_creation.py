"""Shared Issue-creation orchestration (#274 follow-up; DRY refactor).

`create_issue_tool` (issues.py) and `create_thread` Issue branch
(threads.py) both need the same four-step sequence:

  1. Dispatch through ``ctx.replication.write`` → ``adapter.create_issue``.
  2. Attach the new Issue to the project board (forgejo #10 / 3.4.0
     sub-Protocol — first replication adapter with
     ``has_project_boards=True`` wins; skips silently when none).
  3. Increment ``ctx.activity.issues_created``.

Factored here so the test surface is one helper, not two near-
duplicate handler call sites. The result-model shaping
(``CreateIssueResult`` vs ``CreateThreadResult``) and the
project-TOC-body fetch stay at the call sites — those genuinely
diverge between the two handlers.
"""
from __future__ import annotations

from ...adapters.errors import ForgeUnavailableError
from ...adapters.types import Issue
from ...context import ServerContext


async def _attach_to_project_board_if_supported(
    ctx: ServerContext, issue: Issue,
) -> str:
    """Attach an Issue to the configured project board on whichever
    replication adapter supports it (forgejo #10 / 3.4.0).

    Walks ``ctx.replication.entries()`` in order; the first adapter
    with ``has_project_boards=True`` performs the attach. If no
    adapter supports project boards, or no ``project_board`` is
    configured on this project, returns "" cleanly — the caller
    treats the empty string as "no board attachment performed".

    A ``ForgeUnavailableError`` from the supporting adapter falls
    through to the next; other exceptions propagate. This makes the
    helper resilient to a single-backend outage when multiple
    backends support project boards (a future scenario; today only
    GitHub does).

    On a LocalStore-only or Forgejo-only project, this returns ""
    every call — the calling handler should accept project_item_id
    being optional in its response model.
    """
    if ctx.config.project_board is None:
        return ""
    for _platform_id, adapter in ctx.replication.entries():
        if not getattr(adapter, "has_project_boards", False):
            continue
        try:
            return await adapter.add_to_project_board(
                board_id=ctx.config.project_board.id,
                ref=issue.ref,
            )
        except ForgeUnavailableError:
            continue
    return ""


async def create_issue_via_replication(
    ctx: ServerContext,
    *,
    owner: str,
    repo: str,
    title: str,
    body: str,
    labels: list[str],
    milestone: str | int | None = None,
) -> tuple[Issue, str]:
    """Create an Issue through the canonical ReplicationManager and
    attach it to the project board.

    Returns ``(issue, project_item_id)``. Increments
    ``ctx.activity.issues_created`` only after both the adapter call
    and the board attachment succeed — partial-success states (Issue
    created on GitHub but not on the board) leave the counter at its
    prior value so the operator-visible activity tally matches the
    fully-attached set.

    Failure semantics:

      * Adapter ``create_issue`` raises (typically wrapped as
        ``ReplicationWriteError``) → propagates; board attach is
        skipped; counter unchanged.
      * Adapter succeeds but board attach raises → the underlying
        ``ForgeError`` propagates; counter unchanged. The Issue
        exists in the canonical store and on the public face, just
        not on the board — operator can re-attach manually.
      * No adapter supports project boards → ``project_item_id`` is
        ``""`` and the counter still increments. Caller's response
        model treats project_item_id as optional.

    Caller is responsible for any ``ok(...)`` / ``err(...)`` shaping
    around the return value.
    """
    issue = await ctx.replication.write(
        lambda adapter: adapter.create_issue(
            owner=owner,
            repo=repo,
            title=title,
            body=body,
            labels=labels,
            milestone=milestone,
        ),
        operation_name="create_issue",
    )
    project_item_id = await _attach_to_project_board_if_supported(ctx, issue)
    ctx.activity.issues_created += 1
    return issue, project_item_id
