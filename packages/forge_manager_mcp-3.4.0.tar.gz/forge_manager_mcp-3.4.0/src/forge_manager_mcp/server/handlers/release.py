"""Release handlers: validate_release (#107), release_project (#106).

Both tools operate on the project_dir they're invoked against. The
repo-role detector (`_detect_repo_role`) decides which checklist to
run — skill-repo vs mcp-repo — so the same tools serve both release
surfaces per the #102 coordinated-minor protocol.
"""
from __future__ import annotations

import re
import subprocess
import sys
import tempfile
from pathlib import Path

from mcp.types import TextContent

from ...bootstrap_template_parity import (
    BOOTSTRAP_REL,
    TemplateParityError,
    validate_template,
)
from ...context import ServerContext
from ...flows.release import build_post_validate_chain
from ...github import releases as releases_mod
from ...interceptors import aexecute
from ...parsers import parse_changelog, parse_owner_repo, parse_skill_version
# Late binding — see helpers.py docstring.
from forge_manager_mcp import server as _s
from ..helpers import ok, resolve_local_skill_path


_BAZEL_TIMEOUT_SECONDS = 600
_MCP_PACKAGE_NAME = "forge-manager-mcp"

# [project].version = "X.Y.Z" or "X.Y.Z{a,b,rc}N"  — PEP 621 declaration
# in pyproject.toml. Pre-release suffix shape mirrors parsers.py:_VERSION_PAT
# (#218 / #159 — same fix class, distinct call sites).
_VERSION_PAT = r"[0-9]+(?:\.[0-9]+){1,2}(?:(?:a|b|rc)[0-9]+)?"

_PYPROJECT_VERSION_RE = re.compile(
    rf"^version\s*=\s*[\"']({_VERSION_PAT})[\"']\s*$", re.MULTILINE
)

_INIT_VERSION_RE = re.compile(
    rf"^__version__\s*=\s*[\"']({_VERSION_PAT})[\"']\s*$", re.MULTILINE
)


def _check(name: str, ok_: bool, severity: str, detail: str) -> dict:
    return {"name": name, "ok": ok_, "severity": severity, "detail": detail}


def _has_mcp_pyproject(project_dir: Path) -> bool:
    """True if there's a pyproject.toml declaring the forge-manager-mcp
    package, either at root (pre-2.0) or under mcp-server/ (2.0+ monorepo)."""
    for candidate in (
        project_dir / "mcp-server" / "pyproject.toml",
        project_dir / "pyproject.toml",
    ):
        if not candidate.exists():
            continue
        try:
            text = candidate.read_text(encoding="utf-8")
        except OSError:
            continue
        if _MCP_PACKAGE_NAME in text:
            return True
    return False


def _detect_repo_role(project_dir: Path) -> str:
    """Return "skill", "mcp", or "monorepo" based on what artefacts the
    repo owns. Monorepo means BOTH the skill and the MCP server live in
    the same repo (the 2.0+ shape after RFC #132).

    Raises ValueError if the directory is none of those — `validate_release`
    is a no-op on arbitrary repos.
    """
    has_skill = resolve_local_skill_path(project_dir) is not None
    has_mcp = _has_mcp_pyproject(project_dir)

    if has_skill and has_mcp:
        return "monorepo"
    if has_skill:
        return "skill"
    if has_mcp:
        return "mcp"

    raise ValueError(
        f"project_dir {project_dir} is neither a skill repo (no "
        ".claude/skills/forge-manager/SKILL.md and no legacy "
        "active-claude-github prose) nor an mcp repo (no "
        f"pyproject.toml with package {_MCP_PACKAGE_NAME!r}). "
        "validate_release can only run in a known release target."
    )


def _parse_pyproject_version(pyproject_text: str) -> str | None:
    m = _PYPROJECT_VERSION_RE.search(pyproject_text)
    return m.group(1) if m else None


def _parse_init_version(init_text: str) -> str | None:
    m = _INIT_VERSION_RE.search(init_text)
    return m.group(1) if m else None


# ----- Individual checks ---------------------------------------------------


async def _check_milestone_closed(
    token: str, owner: str, repo: str, version: str
) -> dict:
    milestone = await _s.get_milestone_by_title(token, owner, repo, version)
    if milestone is None:
        return _check(
            "milestone_closed",
            False,
            "fail",
            f"No milestone titled {version!r} exists on {owner}/{repo}.",
        )
    open_issues = milestone["open_issues"]
    if open_issues:
        summary = ", ".join(f"#{i['number']}" for i in open_issues[:10])
        suffix = "" if len(open_issues) <= 10 else f" (+{len(open_issues) - 10} more)"
        return _check(
            "milestone_closed",
            False,
            "fail",
            f"Milestone {version} has {len(open_issues)} open "
            f"Issue(s): {summary}{suffix}.",
        )
    if milestone["state"] != "CLOSED":
        return _check(
            "milestone_closed",
            True,
            "fail",
            f"All Issues closed; milestone #{milestone['number']} "
            "itself still OPEN (cosmetic — will close when release tag is cut).",
        )
    return _check(
        "milestone_closed",
        True,
        "fail",
        f"Milestone {version} closed with no open Issues.",
    )


def _check_working_tree_clean(
    project_dir: Path, *, pypi_only: bool = False,
) -> dict:
    """Check that the working tree is releasable.

    Three constraints in normal mode:
      1. ``git status --porcelain`` is empty (no uncommitted changes).
      2. HEAD is on ``main``.
      3. HEAD is at the same commit as ``origin/main`` (push/pull
         done; no local-only commits or remote-only commits).

    Under ``pypi_only=True`` only #1 applies. #2 and #3 both depend
    on a reachable origin / canonical-history discipline, which under
    suspended GitHub access is impossible to satisfy: ``origin/main``
    can't be fetched, and the operator's local main may legitimately
    be ahead of origin/main while waiting for access to return.
    Skipping these under pypi_only is consistent with the documented
    "ship while GitHub is down" semantics — the PyPI artefact's
    identity is its version + wheel contents, not its git provenance.
    The ``working_tree_clean`` check still gates on uncommitted local
    changes, so the operator can't accidentally publish a dirty
    working tree. (FIX-pypi-validate)
    """
    try:
        status = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=project_dir,
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return _check(
            "working_tree_clean",
            False,
            "fail",
            f"git invocation failed: {exc}",
        )

    if status.returncode != 0:
        return _check(
            "working_tree_clean",
            False,
            "fail",
            f"git status exited {status.returncode}: {status.stderr.strip()}",
        )
    if status.stdout.strip():
        lines = status.stdout.strip().splitlines()
        return _check(
            "working_tree_clean",
            False,
            "fail",
            f"{len(lines)} uncommitted change(s): {lines[0]}"
            + ("" if len(lines) == 1 else f" (+{len(lines) - 1} more)"),
        )

    branch = subprocess.run(
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        cwd=project_dir,
        capture_output=True,
        text=True,
        timeout=10,
        check=False,
    )
    branch_name = branch.stdout.strip()
    local_head = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=project_dir,
        capture_output=True,
        text=True,
        timeout=10,
        check=False,
    )

    if pypi_only:
        # See docstring — branch + origin/main equality are skipped.
        return _check(
            "working_tree_clean",
            True,
            "fail",
            f"Clean working tree on {branch_name} at "
            f"{local_head.stdout.strip()[:8]} (pypi_only mode skips "
            "branch and origin/main equality checks).",
        )

    if branch_name != "main":
        return _check(
            "working_tree_clean",
            False,
            "fail",
            f"HEAD is on {branch_name!r}; release must cut from main.",
        )

    remote_head = subprocess.run(
        ["git", "rev-parse", "origin/main"],
        cwd=project_dir,
        capture_output=True,
        text=True,
        timeout=10,
        check=False,
    )
    if remote_head.returncode != 0:
        return _check(
            "working_tree_clean",
            False,
            "fail",
            "origin/main not found locally — run `git fetch origin`.",
        )
    if local_head.stdout.strip() != remote_head.stdout.strip():
        return _check(
            "working_tree_clean",
            False,
            "fail",
            f"HEAD {local_head.stdout.strip()[:8]} != "
            f"origin/main {remote_head.stdout.strip()[:8]}; push or pull first.",
        )

    return _check(
        "working_tree_clean",
        True,
        "fail",
        f"Clean working tree on main at {local_head.stdout.strip()[:8]}.",
    )


# Workspace marker filenames probed to locate the Bazel workspace root.
_BAZEL_MARKERS = ("MODULE.bazel", "WORKSPACE", "WORKSPACE.bazel")

# Test target run by validate_release. Matches the canonical pre-merge
# CI gate (`bazel test //tests:unit_tests`); stays narrow so a broken
# integration BUILD or a flaky live-API test doesn't spuriously block
# a release of unrelated changes.
_BAZEL_TEST_TARGET = "//tests:unit_tests"


def _resolve_bazel_workspace_dir(project_dir: Path) -> Path | None:
    """Locate the Bazel workspace dir under ``project_dir``, or None.

    Probed in order: ``project_dir`` itself (standalone-mcp / repo-root
    layout) then ``project_dir/mcp-server/`` (2.0+ monorepo). First hit
    wins. The 2.0 monorepo merge left the workspace at ``mcp-server/``
    rather than at the repo root, so probing there is required for the
    release gate to fire on every project shipped in 2.0+ (#199).
    """
    for candidate in (project_dir, project_dir / "mcp-server"):
        if any((candidate / fname).is_file() for fname in _BAZEL_MARKERS):
            return candidate
    return None


def _check_bazel_tests_green(project_dir: Path, skip: bool) -> dict:
    if skip:
        return _check(
            "bazel_tests_green",
            True,
            "warn",
            f"Skipped (`skip_bazel=True`). Run `bazel test {_BAZEL_TEST_TARGET}` "
            "manually before tagging.",
        )
    workspace_dir = _resolve_bazel_workspace_dir(project_dir)
    if workspace_dir is None:
        return _check(
            "bazel_tests_green",
            True,
            "warn",
            "No Bazel workspace under project_dir (probed root and "
            "mcp-server/); check N/A for this repo role.",
        )
    try:
        result = subprocess.run(
            ["bazel", "test", _BAZEL_TEST_TARGET],
            cwd=workspace_dir,
            capture_output=True,
            text=True,
            timeout=_BAZEL_TIMEOUT_SECONDS,
            check=False,
        )
    except FileNotFoundError:
        return _check(
            "bazel_tests_green",
            False,
            "fail",
            "bazel not on PATH. Install bazelisk or pass skip_bazel=True.",
        )
    except subprocess.TimeoutExpired:
        return _check(
            "bazel_tests_green",
            False,
            "fail",
            f"`bazel test {_BAZEL_TEST_TARGET}` exceeded "
            f"{_BAZEL_TIMEOUT_SECONDS}s timeout.",
        )
    if result.returncode != 0:
        tail = "\n".join(result.stderr.splitlines()[-10:])
        return _check(
            "bazel_tests_green",
            False,
            "fail",
            f"`bazel test {_BAZEL_TEST_TARGET}` exited {result.returncode}. "
            f"stderr tail:\n{tail}",
        )
    return _check(
        "bazel_tests_green",
        True,
        "fail",
        f"`bazel test {_BAZEL_TEST_TARGET}` green (cwd={workspace_dir.name}/).",
    )


def _check_pending_buffer_empty(project_dir: Path) -> dict:
    buffer = project_dir / ".claude" / "pending-posts.md"
    if not buffer.exists():
        return _check(
            "pending_buffer_empty",
            True,
            "fail",
            ".claude/pending-posts.md absent (no buffered ops).",
        )
    try:
        content = buffer.read_text(encoding="utf-8").strip()
    except OSError as exc:
        return _check(
            "pending_buffer_empty",
            False,
            "fail",
            f"Cannot read {buffer}: {exc}",
        )
    if content:
        return _check(
            "pending_buffer_empty",
            False,
            "fail",
            "pending-posts.md non-empty; run replay_pending first.",
        )
    return _check(
        "pending_buffer_empty", True, "fail", "pending-posts.md empty."
    )


def _check_skill_version(project_dir: Path, target: str) -> dict:
    skill_path = resolve_local_skill_path(project_dir)
    if skill_path is None:
        return _check(
            "skill_version_matches",
            False,
            "fail",
            "No skill prose file found at any candidate path "
            "(.claude/skills/forge-manager/SKILL.md or legacy 2.x "
            "equivalents).",
        )
    try:
        text = skill_path.read_text(encoding="utf-8")
    except OSError as exc:
        return _check(
            "skill_version_matches",
            False,
            "fail",
            f"Cannot read {skill_path}: {exc}",
        )
    installed = parse_skill_version(text)
    if installed == target:
        return _check(
            "skill_version_matches",
            True,
            "fail",
            f"Skill **Version:** header == {target}.",
        )
    return _check(
        "skill_version_matches",
        False,
        "fail",
        f"Skill header is {installed!r}; expected {target!r}.",
    )


def _check_skill_changelog_entry(project_dir: Path, target: str) -> dict:
    skill_path = resolve_local_skill_path(project_dir)
    if skill_path is None:
        return _check(
            "skill_changelog_entry_exists",
            False,
            "fail",
            "No skill prose file found at any candidate path.",
        )
    try:
        text = skill_path.read_text(encoding="utf-8")
    except OSError as exc:
        return _check(
            "skill_changelog_entry_exists",
            False,
            "fail",
            f"Cannot read {skill_path}: {exc}",
        )
    entries = parse_changelog(text)
    for e in entries:
        if e["version"] == target:
            return _check(
                "skill_changelog_entry_exists",
                True,
                "fail",
                f"Changelog entry for {target}: {e['summary'][:60]}",
            )
    return _check(
        "skill_changelog_entry_exists",
        False,
        "fail",
        f"No changelog entry for {target} in the skill prose.",
    )


def _resolve_pyproject_path(project_dir: Path) -> Path | None:
    """Locate pyproject.toml: monorepo path first, then repo root."""
    for candidate in (
        project_dir / "mcp-server" / "pyproject.toml",
        project_dir / "pyproject.toml",
    ):
        if candidate.exists():
            return candidate
    return None


def _check_pyproject_version(project_dir: Path, target: str) -> dict:
    pyproject = _resolve_pyproject_path(project_dir)
    if pyproject is None:
        return _check(
            "pyproject_version_matches",
            False,
            "fail",
            "No pyproject.toml found (looked in mcp-server/ and at repo root).",
        )
    try:
        text = pyproject.read_text(encoding="utf-8")
    except OSError as exc:
        return _check(
            "pyproject_version_matches",
            False,
            "fail",
            f"Cannot read {pyproject}: {exc}",
        )
    found = _parse_pyproject_version(text)
    if found == target:
        return _check(
            "pyproject_version_matches",
            True,
            "fail",
            f"pyproject.toml version == {target}.",
        )
    return _check(
        "pyproject_version_matches",
        False,
        "fail",
        f"pyproject.toml version is {found!r}; expected {target!r}.",
    )


def _check_package_version(project_dir: Path, target: str) -> dict:
    candidates = (
        # 2.0+ monorepo: MCP code lives under mcp-server/
        project_dir / "mcp-server" / "src" / "forge_manager_mcp" / "__init__.py",
        project_dir / "mcp-server" / "forge_manager_mcp" / "__init__.py",
        # Pre-2.0 standalone MCP repo
        project_dir / "forge_manager_mcp" / "__init__.py",
        project_dir / "src" / "forge_manager_mcp" / "__init__.py",
    )
    for init_path in candidates:
        if init_path.exists():
            try:
                text = init_path.read_text(encoding="utf-8")
            except OSError as exc:
                return _check(
                    "package_version_matches",
                    False,
                    "fail",
                    f"Cannot read {init_path}: {exc}",
                )
            found = _parse_init_version(text)
            if found == target:
                return _check(
                    "package_version_matches",
                    True,
                    "fail",
                    f"__version__ == {target}.",
                )
            return _check(
                "package_version_matches",
                False,
                "fail",
                f"__version__ is {found!r}; expected {target!r}.",
            )
    return _check(
        "package_version_matches",
        False,
        "fail",
        "forge_manager_mcp/__init__.py not found.",
    )


def _check_bootstrap_template_parity(project_dir: Path) -> dict:
    """#189 — bootstrap.md §5g github-config.json template parses as
    GithubConfig. Catches prose-vs-schema field-name drift at release
    time rather than at first-`open_session`-time on consumer projects.
    """
    bootstrap = project_dir / BOOTSTRAP_REL
    if not bootstrap.exists():
        # Skill repos always carry bootstrap.md; mcp-only repos don't.
        # Caller decides whether to invoke this check based on repo_role.
        return _check(
            "bootstrap_template_parity",
            True,
            "fail",
            "bootstrap.md not present (skipped — not a skill repo).",
        )
    try:
        validate_template(project_dir)
    except TemplateParityError as exc:
        return _check(
            "bootstrap_template_parity",
            False,
            "fail",
            f"§5g template fails GithubConfig schema: {exc}",
        )
    return _check(
        "bootstrap_template_parity",
        True,
        "fail",
        "§5g github-config.json template parses as GithubConfig.",
    )


def _read_workflow_file(project_dir: Path) -> Path | None:
    """Return the Trusted-Publisher workflow path, or None if absent.

    Probes the canonical 2.0+ monorepo location first (workflow at
    repo root) and the standalone-mcp legacy form for completeness.
    The convention is one workflow per project named
    `publish-pypi.yml`.
    """
    candidates = (
        project_dir / ".github" / "workflows" / "publish-pypi.yml",
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def _parse_workflow_environment(workflow_text: str) -> str | None:
    """Pluck the deploy `environment:` name from a publish-pypi workflow.

    Looks for a top-level `environment: <name>` (or
    `environment:\n      name: <name>`) under any job. Returns the
    first match or None.
    """
    # First form: `environment: pypi` (one-line scalar).
    m = re.search(
        r"^\s*environment\s*:\s*(?P<name>[A-Za-z0-9_-]+)\s*$",
        workflow_text,
        re.MULTILINE,
    )
    if m:
        return m.group("name")
    # Second form: `environment:\n      name: pypi`.
    m = re.search(
        r"^\s*environment\s*:\s*\n\s*name\s*:\s*(?P<name>[A-Za-z0-9_-]+)\s*$",
        workflow_text,
        re.MULTILINE,
    )
    if m:
        return m.group("name")
    return None


_SMOKE_PROBE_SCRIPT = """\
import sys
from pathlib import Path
from forge_manager_mcp.site_renderer.hugo import HugoRenderer
r = HugoRenderer()
assert r._theme_dir.is_dir(), f"theme_dir {r._theme_dir} missing"
assert (r._theme_dir / "theme.toml").is_file(), "theme.toml missing"
print("ok")
"""


def _check_installed_wheel_smoke_test(
    project_dir: Path, version: str, skip: bool,
) -> dict:
    """forgejo #3 — build wheel + scratch venv install + import probe.

    Closes the source-vs-artifact validation gap that let #1 (Hugo theme
    tree missing from wheel) ship: every existing release-validation
    gate validates the source tree (Bazel test suite, twine check,
    metadata-only checks). Source-vs-artifact divergences (missing data
    files in the wheel, broken __main__, wrong entry-point binding) sail
    through untouched until the operator pipx-installs and the binary
    crashes at first MCP handshake.

    Smoke flow:

      1. Locate / build the version-matching wheel under mcp-server/dist/.
      2. Create a scratch venv in a temp dir.
      3. ``pip install`` the wheel into the venv.
      4. Run ``_SMOKE_PROBE_SCRIPT`` in the venv: imports
         ``forge_manager_mcp.site_renderer.hugo`` and constructs
         ``HugoRenderer()`` no-arg, asserting ``_theme_dir.is_dir()``
         and theme.toml present. Catches the #1 bug-class
         deterministically.

    Severity is ``fail`` (release-blocking). Operator override via
    ``skip_smoke_test=True``.

    Future enhancement (per the Issue body): full MCP ``initialize``
    handshake + ``tools/list`` assertion. Today's probe catches the
    specific bug-class that motivated #3 (data-file packaging) without
    the full handshake plumbing.
    """
    if skip:
        return _check(
            "installed_wheel_smoke_test",
            True,
            "warn",
            "Skipped (`skip_smoke_test=True`). Run wheel install + import "
            "probe manually before tagging.",
        )

    mcp_dir = project_dir / "mcp-server"
    if not mcp_dir.is_dir():
        # Skill-only repos don't ship a wheel; check N/A.
        return _check(
            "installed_wheel_smoke_test",
            True,
            "warn",
            "No mcp-server/ subdirectory; check N/A for this repo role.",
        )

    dist_dir = mcp_dir / "dist"
    wheel = _find_or_build_wheel(mcp_dir, dist_dir, version)
    if isinstance(wheel, dict):
        return wheel  # _check dict surfaced from build failure

    import tempfile

    with tempfile.TemporaryDirectory(prefix="acg-wheel-smoke-") as work:
        venv_dir = Path(work) / "venv"
        venv_python = venv_dir / "bin" / "python"

        venv_err = _create_smoke_venv(venv_dir)
        if venv_err is not None:
            return venv_err

        install_err = _install_wheel_in_venv(venv_python, wheel)
        if install_err is not None:
            return install_err

        return _run_smoke_probe(venv_python, wheel)


def _find_or_build_wheel(
    mcp_dir: Path, dist_dir: Path, version: str,
) -> "Path | dict":
    """Return the version-matching wheel Path, or build it if absent.

    On failure returns a `_check` dict (status fail) ready to short-
    circuit the caller; otherwise the resolved Path.
    """
    pattern = f"forge_manager_mcp-{version}*.whl"
    matches = list(dist_dir.glob(pattern)) if dist_dir.exists() else []
    if matches:
        return matches[0]

    try:
        subprocess.run(
            [sys.executable, "-m", "build", "--wheel"],
            cwd=mcp_dir, check=True, capture_output=True, text=True,
            timeout=180,
        )
    except FileNotFoundError:
        return _check(
            "installed_wheel_smoke_test",
            False,
            "fail",
            "python build module not on PATH — `pip install build` and retry.",
        )
    except subprocess.TimeoutExpired:
        return _check(
            "installed_wheel_smoke_test",
            False,
            "fail",
            "wheel build exceeded 180s timeout.",
        )
    except subprocess.CalledProcessError as exc:
        return _check(
            "installed_wheel_smoke_test",
            False,
            "fail",
            f"wheel build failed: {(exc.stderr or '').strip()[:500]}",
        )
    matches = list(dist_dir.glob(pattern)) if dist_dir.exists() else []
    if not matches:
        return _check(
            "installed_wheel_smoke_test",
            False,
            "fail",
            f"no wheel matching {pattern!r} produced under {dist_dir}.",
        )
    return matches[0]


def _create_smoke_venv(venv_dir: Path) -> dict | None:
    """Create a scratch venv. Returns _check dict on failure, None on success."""
    try:
        subprocess.run(
            [sys.executable, "-m", "venv", str(venv_dir)],
            check=True, capture_output=True, text=True, timeout=60,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        return _check(
            "installed_wheel_smoke_test",
            False,
            "fail",
            f"scratch venv create failed: {str(exc)[:500]}",
        )
    return None


def _install_wheel_in_venv(venv_python: Path, wheel: Path) -> dict | None:
    """pip install the wheel into the venv. Returns _check dict on failure."""
    try:
        subprocess.run(
            [str(venv_python), "-m", "pip", "install", "--quiet", str(wheel)],
            check=True, capture_output=True, text=True, timeout=180,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        stderr = getattr(exc, "stderr", "") or str(exc)
        return _check(
            "installed_wheel_smoke_test",
            False,
            "fail",
            f"pip install failed: {stderr.strip()[:500]}",
        )
    return None


def _run_smoke_probe(venv_python: Path, wheel: Path) -> dict:
    """Run _SMOKE_PROBE_SCRIPT in the venv. Returns the final _check dict."""
    try:
        result = subprocess.run(
            [str(venv_python), "-c", _SMOKE_PROBE_SCRIPT],
            check=True, capture_output=True, text=True, timeout=30,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        stderr = getattr(exc, "stderr", "") or str(exc)
        return _check(
            "installed_wheel_smoke_test",
            False,
            "fail",
            f"smoke probe failed against {wheel.name}: {stderr.strip()[:500]}",
        )
    return _check(
        "installed_wheel_smoke_test",
        True,
        "fail",
        f"wheel {wheel.name} imports cleanly; HugoRenderer() resolves theme dir "
        f"({result.stdout.strip()}).",
    )


def _check_pypi_trusted_publisher(
    project_dir: Path, mcp_repo_full: str
) -> dict:
    """#151 — surface the expected PyPI Trusted Publisher claims as an advisory.

    Reads `<project_dir>/.github/workflows/publish-pypi.yml` to extract
    the workflow filename and deployment environment, then composes the
    four claims a PyPI Trusted Publisher binding must declare:

    - `owner`     — derived from the dev-repo's `<owner>/<name>` config.
    - `repo`      — likewise (the publish workflow lives in the dev repo
                    pre-mirror, but at tag time it runs from main on
                    whichever repo carries the workflow file).
    - `workflow`  — the workflow filename (typically `publish-pypi.yml`).
    - `environment` — the GitHub deployment environment the job uses
                    (typically `pypi`); None if the workflow has no
                    `environment:` key (binding accepts any environment).

    Severity is `warn` (advisory; non-blocking). The detail string is
    the operator's checklist — one visit to the PyPI settings page
    confirms the binding before the release tag goes out.

    Skipped silently when the project doesn't have a publish workflow
    (e.g., skill-only repos that don't ship to PyPI). Caller invokes
    this check only for `mcp` / `monorepo` repo roles.
    """
    workflow_path = _read_workflow_file(project_dir)
    if workflow_path is None:
        return _check(
            "pypi_trusted_publisher",
            True,
            "warn",
            ".github/workflows/publish-pypi.yml not present — skipped. "
            "If this project publishes to PyPI manually, no binding to "
            "verify; otherwise add the workflow.",
        )
    try:
        workflow_text = workflow_path.read_text(encoding="utf-8")
    except OSError as exc:
        return _check(
            "pypi_trusted_publisher",
            True,
            "warn",
            f"could not read {workflow_path}: {exc}",
        )

    pyproject = _resolve_pyproject_path(project_dir)
    package_name = None
    if pyproject is not None:
        try:
            text = pyproject.read_text(encoding="utf-8")
            m = re.search(r'^name\s*=\s*[\"\']([^\"\']+)[\"\']', text, re.MULTILINE)
            if m:
                package_name = m.group(1)
        except OSError:
            package_name = None
    if not package_name:
        return _check(
            "pypi_trusted_publisher",
            True,
            "warn",
            "could not infer package name from pyproject.toml — "
            "skipped. Verify the binding manually before tagging.",
        )

    try:
        owner, repo = parse_owner_repo(mcp_repo_full)
    except ValueError:
        return _check(
            "pypi_trusted_publisher",
            True,
            "warn",
            f"could not parse repo from {mcp_repo_full!r} — skipped.",
        )

    environment = _parse_workflow_environment(workflow_text)
    workflow_filename = workflow_path.name

    settings_url = (
        f"https://pypi.org/manage/project/{package_name}/settings/publishing/"
    )
    env_display = repr(environment) if environment else "any"
    detail = (
        f"Verify a Trusted Publisher binding exists at {settings_url} "
        f"matching: owner={owner!r}, repository={repo!r}, "
        f"workflow={workflow_filename!r}, environment={env_display}. "
        "Tag-push will 401 from `gh release` if the binding is missing or "
        "stale; the gate above this is advisory because PyPI does not "
        "expose a stable public bindings API to verify automatically."
    )
    return _check(
        "pypi_trusted_publisher",
        True,
        "warn",
        detail,
    )


def _check_changelog_regenerated(project_dir: Path, target: str) -> dict:
    """CHANGELOG.md's newest version header equals `target` (warn-only until #108 ships)."""
    changelog = project_dir / "CHANGELOG.md"
    if not changelog.exists():
        return _check(
            "changelog_regenerated",
            True,
            "warn",
            "CHANGELOG.md not present (#108 generator has not shipped yet).",
        )
    try:
        text = changelog.read_text(encoding="utf-8")
    except OSError as exc:
        return _check(
            "changelog_regenerated",
            False,
            "warn",
            f"Cannot read {changelog}: {exc}",
        )
    # Look for first ## <version> or ## vX.Y.Z header
    m = re.search(
        r"^##\s+v?([0-9]+(?:\.[0-9]+){1,2})\b", text, re.MULTILINE
    )
    found = m.group(1) if m else None
    if found == target:
        return _check(
            "changelog_regenerated",
            True,
            "warn",
            f"CHANGELOG.md newest entry == {target}.",
        )
    return _check(
        "changelog_regenerated",
        False,
        "warn",
        f"CHANGELOG.md newest entry is {found!r}; expected {target!r}. "
        "Re-run the generator (#108).",
    )


# ----- Public handler ------------------------------------------------------


async def validate_release(
    ctx: ServerContext,
    version: str,
    skip_bazel: bool = False,
    skip_smoke_test: bool = False,
    runbook_confirmations: dict[str, bool] | None = None,
) -> list[TextContent]:
    """#107 — read-only pre-flight check runner for a target release version.

    ``runbook_confirmations`` (3.4.0 / Codeberg-dev #3) is the operator-
    supplied confirmation map for ``pre-publish`` runbook gates. Each
    key is a gate name (e.g. ``"publish.live_marketplace_add_smoke_test"``);
    each value is ``True`` if the operator has run the corresponding
    runbook and confirms it passed. Missing keys are treated as
    unconfirmed. With default project rules, unconfirmed runbook gates
    surface as ``severity: "warn"`` (advisory) and don't block ``ready``;
    project rules can ``tighten`` to enforced, in which case the
    corresponding extension interceptor elevates to ``severity: "fail"``.
    """
    if not version.strip():
        raise ValueError("version must not be empty.")

    repo_role = _detect_repo_role(ctx.project_dir)

    # Milestone lookup always targets the authoritative dev repo (#43).
    owner, dev_repo = parse_owner_repo(ctx.config.repos.private)

    checks: list[dict] = []
    checks.append(await _check_milestone_closed(ctx.github_token, owner, dev_repo, version))
    checks.append(_check_working_tree_clean(ctx.project_dir))
    checks.append(_check_bazel_tests_green(ctx.project_dir, skip_bazel))
    checks.append(_check_pending_buffer_empty(ctx.project_dir))

    if repo_role in ("skill", "monorepo"):
        checks.append(_check_skill_version(ctx.project_dir, version))
        checks.append(_check_skill_changelog_entry(ctx.project_dir, version))
        checks.append(_check_bootstrap_template_parity(ctx.project_dir))
    if repo_role in ("mcp", "monorepo"):
        checks.append(_check_pyproject_version(ctx.project_dir, version))
        checks.append(_check_package_version(ctx.project_dir, version))
        checks.append(
            _check_pypi_trusted_publisher(
                ctx.project_dir, ctx.config.repos.private
            )
        )
        checks.append(
            _check_installed_wheel_smoke_test(
                ctx.project_dir, version, skip_smoke_test,
            )
        )

    checks.append(_check_changelog_regenerated(ctx.project_dir, version))

    # (Codeberg-dev #3 Phase 1c) Operator-driven runbook gates. Appends
    # one check per pre-publish gate in the registry. No-op when the
    # registry isn't loaded (pre-bootstrap) or has no pre-publish gates.
    checks.extend(await _check_runbook_gates(ctx, runbook_confirmations))

    ready = all(c["ok"] for c in checks if c["severity"] == "fail")

    return ok(
        {
            "version": version,
            "ready": ready,
            "repo_role": repo_role,
            "checks": checks,
        }
    )


async def _check_runbook_gates(
    ctx: ServerContext,
    runbook_confirmations: dict[str, bool] | None,
) -> list[dict]:
    """Evaluate every pre-publish runbook gate and return one check per gate.

    Threads ``runbook_confirmations`` (defaulted to ``{}``) into
    ``evaluate_gate`` via the ``request`` payload under
    ``RUNBOOK_CONFIRMATIONS_REQUEST_KEY``. The default evaluator emits
    ``status: "passed"`` (operator confirmed) or ``status: "unconfirmed"``
    (missing or explicit False); project-rule extensions can also emit
    ``status: "failed"`` to elevate to a hard error.

    Severity mapping:

    - ``passed`` → ``info`` (no-op check, ``ok=True``)
    - ``unconfirmed`` → ``warn`` (advisory; doesn't block ``ready``)
    - ``failed`` → ``fail`` (blocks; reserved for project-rule
      extensions that elevate)
    - any other status → ``info`` (forward-compat for new evaluator
      states without ``ok=False`` regression)
    """
    if ctx.gate_registry is None:
        return []

    from ..gates import evaluate_gate, UnknownGate
    from ...runbook_evaluator import RUNBOOK_CONFIRMATIONS_REQUEST_KEY

    confirmations = runbook_confirmations or {}
    request = {RUNBOOK_CONFIRMATIONS_REQUEST_KEY: confirmations}

    checks: list[dict] = []
    for gate in ctx.gate_registry.list_gates(type="pre-publish"):
        try:
            response = await evaluate_gate(ctx, gate.name, request=request)
        except UnknownGate:
            # Gate declared in registry but no evaluator registered.
            # register_runbook_evaluators should have covered every
            # pre-publish gate at server startup; reaching here means
            # a Phase 1b regression. Surface as a fail check rather
            # than silently skipping.
            checks.append(_check(
                name=f"runbook.{gate.name}",
                ok_=False,
                severity="fail",
                detail=(
                    f"runbook evaluator missing for gate {gate.name!r}; "
                    f"register_runbook_evaluators may not have run at "
                    f"server startup"
                ),
            ))
            continue

        gate_response = response.get(gate.name, {})
        status = gate_response.get("status", "unknown")

        if status == "passed":
            ok_flag, severity = True, "info"
            detail = f"operator confirmed: {gate.runbook_url}"
        elif status == "unconfirmed":
            ok_flag, severity = True, "warn"
            detail = (
                f"runbook unconfirmed; run "
                f"$FORGE_MANAGER_DOCS_REPO/{gate.runbook_url} "
                f"and pass runbook_confirmations[{gate.name!r}]=True"
            )
        elif status == "failed":
            ok_flag, severity = False, "fail"
            detail = gate_response.get(
                "detail", f"runbook gate {gate.name!r} failed"
            )
        else:
            ok_flag, severity = True, "info"
            detail = f"runbook gate emitted unrecognized status: {status!r}"

        checks.append(_check(
            name=f"runbook.{gate.name}",
            ok_=ok_flag,
            severity=severity,
            detail=detail,
        ))

    return checks


# ====== release_project (#106) =============================================
#
# Orchestrator. Calls validate_release, then runs five steps in sequence.
# Hard-gated on validate_release; no force override. Defaults to dry-run.
# A `stop_after` knob lets the operator cut the dev tag without touching
# the public mirror — useful when the mirror isn't ready yet.

_VERSION_BUMP_CHECK_NAMES = frozenset({
    "skill_version_matches",
    "pyproject_version_matches",
    "package_version_matches",
})

# Curated-subset exclusions per #102 Q1 decision. Glob-matched against
# `git ls-files` output before staging the squashed mirror commit.
_SKILL_EXCLUDE_PATTERNS: tuple[str, ...] = (
    ".claude",
)
_MCP_EXCLUDE_PATTERNS: tuple[str, ...] = (
    ".claude",
    "tests/integration/live",
)
# Monorepo (2.0+): single dev repo holds skill prose under .claude/skills/
# AND the MCP server under mcp-server/. The mirror excludes operational
# `.claude/` content (so consumers download via the release asset, not
# from source) and the live-integration tests (per the original mcp
# carve-out, now under the mcp-server/ prefix).
_MONOREPO_EXCLUDE_PATTERNS: tuple[str, ...] = (
    ".claude",
    "mcp-server/tests/integration/live",
)

_VALID_STOP_AFTER = ("validate", "dev_tag", "mirror_sync", "release_notes")

_SKILL_VERSION_LINE_RE = re.compile(
    r"^(\*\*Version:\*\*\s*)([0-9]+(?:\.[0-9]+){1,2})(\s*)$",
    re.MULTILINE,
)


def _step(name: str, status: str, detail) -> dict:
    return {"name": name, "status": status, "detail": detail}


# ----- Version-bump propose / apply ----------------------------------------


def _propose_version_bump_edits(
    project_dir: Path, repo_role: str, target: str
) -> list[dict]:
    """Compute the file edits needed to bring version artefacts to `target`.

    Returns a list of ``{"path": str, "before": str, "after": str}`` entries
    for the files whose version is currently != target. Empty list means
    no edits required.
    """
    edits: list[dict] = []
    if repo_role == "skill":
        skill_path = resolve_local_skill_path(project_dir)
        if skill_path is None:
            return edits
        text = skill_path.read_text(encoding="utf-8")
        m = _SKILL_VERSION_LINE_RE.search(text)
        if m and m.group(2) != target:
            new_text = (
                text[: m.start(2)] + target + text[m.end(2) :]
            )
            edits.append(
                {
                    "path": str(skill_path.relative_to(project_dir)),
                    "before": m.group(2),
                    "after": target,
                    "new_content": new_text,
                }
            )
        return edits

    # mcp role
    pyproject = project_dir / "pyproject.toml"
    if pyproject.exists():
        text = pyproject.read_text(encoding="utf-8")
        m = _PYPROJECT_VERSION_RE.search(text)
        if m and m.group(1) != target:
            new_text = text[: m.start(1)] + target + text[m.end(1) :]
            edits.append(
                {
                    "path": "pyproject.toml",
                    "before": m.group(1),
                    "after": target,
                    "new_content": new_text,
                }
            )

    for init_rel in (
        Path("forge_manager_mcp") / "__init__.py",
        Path("src") / "forge_manager_mcp" / "__init__.py",
    ):
        init_path = project_dir / init_rel
        if init_path.exists() and not init_path.is_symlink():
            text = init_path.read_text(encoding="utf-8")
            m = _INIT_VERSION_RE.search(text)
            if m and m.group(1) != target:
                new_text = text[: m.start(1)] + target + text[m.end(1) :]
                edits.append(
                    {
                        "path": str(init_rel),
                        "before": m.group(1),
                        "after": target,
                        "new_content": new_text,
                    }
                )
            # Only one __init__ exists in either layout; stop at first hit
            break
    return edits


def _apply_version_bump_edits(project_dir: Path, edits: list[dict]) -> None:
    for edit in edits:
        path = project_dir / edit["path"]
        path.write_text(edit["new_content"], encoding="utf-8")


# ----- Release notes / CHANGELOG.md ----------------------------------------


def _release_notes_for_version(project_dir: Path, version: str) -> str | None:
    """Extract the changelog entry for `version` from the skill .md.

    Resolves the skill file via the standard candidate paths. For mcp-repo
    callers the operator can keep a copy at .claude/skills/active-claude-
    github.md (or symlink it); release_project does not require the skill
    file to live in the project being released — just to be reachable.
    """
    skill_path = resolve_local_skill_path(project_dir)
    if skill_path is None:
        return None
    try:
        text = skill_path.read_text(encoding="utf-8")
    except OSError:
        return None
    for entry in parse_changelog(text):
        if entry["version"] == version:
            return f"## v{version} ({entry['date']})\n\n{entry['summary']}\n"
    return None


def _generate_changelog_md(project_dir: Path) -> str | None:
    """Return CHANGELOG.md text generated from the skill changelog, or None."""
    skill_path = resolve_local_skill_path(project_dir)
    if skill_path is None:
        return None
    try:
        text = skill_path.read_text(encoding="utf-8")
    except OSError:
        return None
    entries = parse_changelog(text)
    if not entries:
        return None
    lines = ["# Changelog", ""]
    for entry in entries:
        lines.append(f"## v{entry['version']} ({entry['date']})")
        lines.append("")
        lines.append(entry["summary"])
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


async def generate_changelog(
    ctx: ServerContext,
    write: bool = False,
) -> list[TextContent]:
    """#108 — regenerate CHANGELOG.md from the skill changelog.

    Two modes:
    - `write=False` (default): preview only — return the generated text
      without touching disk. Safe to call any time.
    - `write=True`: write the generated text to ``CHANGELOG.md`` at
      the project root, replacing whatever was there.

    `release_project` also auto-populates `CHANGELOG.md` from the same
    helper when the file is absent (#106 decision 1). This standalone
    tool covers the mid-cycle case where the operator wants to refresh
    the file without going through validate.
    """
    generated = _generate_changelog_md(ctx.project_dir)
    if generated is None:
        return ok(
            {
                "ok": False,
                "wrote": False,
                "path": "CHANGELOG.md",
                "preview": None,
                "error": (
                    "No skill file or no changelog entries — generator "
                    "needs a forge-manager SKILL.md (or 2.x equivalent) "
                    "with a populated ## Changelog section."
                ),
            }
        )
    target = ctx.project_dir / "CHANGELOG.md"
    if write:
        target.write_text(generated, encoding="utf-8")
    return ok(
        {
            "ok": True,
            "wrote": write,
            "path": "CHANGELOG.md",
            "preview": generated,
        }
    )


# ----- Curated subset / mirror sync ---------------------------------------


def _exclude_patterns_for(repo_role: str) -> tuple[str, ...]:
    if repo_role == "skill":
        return _SKILL_EXCLUDE_PATTERNS
    if repo_role == "mcp":
        return _MCP_EXCLUDE_PATTERNS
    if repo_role == "monorepo":
        return _MONOREPO_EXCLUDE_PATTERNS
    raise ValueError(f"unknown repo_role {repo_role!r}")


def _is_excluded(rel_path: str, exclusions: tuple[str, ...]) -> bool:
    for pattern in exclusions:
        if rel_path == pattern or rel_path.startswith(pattern + "/"):
            return True
    return False


def _curated_file_list(project_dir: Path, repo_role: str) -> tuple[list[str], list[str]]:
    """Split tracked-file list into (included, excluded) paths."""
    exclusions = _exclude_patterns_for(repo_role)
    tracked = releases_mod.list_tracked_files(project_dir)
    included = [p for p in tracked if not _is_excluded(p, exclusions)]
    excluded = [p for p in tracked if _is_excluded(p, exclusions)]
    return included, excluded


# ----- Step runners --------------------------------------------------------


async def _run_validate(
    ctx: ServerContext,
    version: str,
    skip_bazel: bool,
    *,
    pypi_only: bool = False,
    skip_smoke_test: bool = False,
) -> tuple[dict, list[dict], str]:
    """Run validate_release and return (step, full_validate_data, repo_role).

    Two checks are skipped under ``pypi_only=True``:

      * ``milestone_closed`` — the one GitHub-network call in the
        validate suite. With GitHub down, the milestone is neither
        queryable nor closable, so gating on it would prevent the
        very release pypi_only was added to enable.
      * ``pending_buffer_empty`` — typical buffered entries are
        GitHub-coupled tool calls (``open_session``, ``post_turn``,
        ``create_issue``) that cannot be drained while GitHub is
        unreachable. Forcing the operator to clear them would
        conflate "can't replay right now" with "no longer wanted",
        risking data loss. The buffer is left intact; ``replay_pending``
        will drain it when GitHub access returns.

    Both skips surface as ``warn``-severity entries so the operator
    can see what was bypassed. (FIX-pypi-validate)
    """
    repo_role = _detect_repo_role(ctx.project_dir)
    owner, dev_repo = parse_owner_repo(ctx.config.repos.private)

    checks: list[dict] = []
    if pypi_only:
        # See docstring — skip the only GitHub-network check.
        checks.append(_check(
            "milestone_closed",
            True,
            "warn",
            "Skipped under pypi_only mode — milestone_closed reaches "
            "GitHub, which is unreachable in this release path. The "
            "release is not gated on GitHub-side milestone state.",
        ))
    else:
        checks.append(
            await _check_milestone_closed(
                ctx.github_token, owner, dev_repo, version,
            )
        )
    checks.append(
        _check_working_tree_clean(ctx.project_dir, pypi_only=pypi_only)
    )
    checks.append(_check_bazel_tests_green(ctx.project_dir, skip_bazel))
    if pypi_only:
        checks.append(_check(
            "pending_buffer_empty",
            True,
            "warn",
            "Skipped under pypi_only mode — buffered entries are "
            "typically GitHub-coupled tool calls (open_session, "
            "post_turn, create_issue) that can't drain while GitHub is "
            "unreachable. Run `replay_pending` once GitHub access is "
            "restored to drain whatever's there.",
        ))
    else:
        checks.append(_check_pending_buffer_empty(ctx.project_dir))
    if repo_role == "skill":
        checks.append(_check_skill_version(ctx.project_dir, version))
        checks.append(_check_skill_changelog_entry(ctx.project_dir, version))
    else:
        checks.append(_check_pyproject_version(ctx.project_dir, version))
        checks.append(_check_package_version(ctx.project_dir, version))
        checks.append(
            _check_pypi_trusted_publisher(
                ctx.project_dir, ctx.config.repos.private
            )
        )
        checks.append(
            _check_installed_wheel_smoke_test(
                ctx.project_dir, version, skip_smoke_test,
            )
        )
    checks.append(_check_changelog_regenerated(ctx.project_dir, version))

    fail_checks = [c for c in checks if c["severity"] == "fail"]
    ready = all(c["ok"] for c in fail_checks)

    if ready:
        step = _step("validate", "ok", {"checks": checks})
    else:
        step = _step(
            "validate",
            "failed",
            {
                "failed_checks": [c for c in fail_checks if not c["ok"]],
                "all_checks": checks,
            },
        )
    return step, checks, repo_role


def _failures_are_only_version_bumps(checks: list[dict]) -> bool:
    """True iff every failing fail-severity check is a version-line check."""
    failing = [c for c in checks if c["severity"] == "fail" and not c["ok"]]
    if not failing:
        return False
    return all(c["name"] in _VERSION_BUMP_CHECK_NAMES for c in failing)


def _run_dev_tag(
    ctx: ServerContext, version: str, notes: str, dry_run: bool
) -> dict:
    tag_name = f"v{version}"
    sha = releases_mod.head_sha(ctx.project_dir)
    if dry_run:
        return _step(
            "dev_tag",
            "dry_run_preview",
            {
                "tag": tag_name,
                "sha": sha,
                "message_preview": notes.splitlines()[0] if notes else "",
                "would_push": "origin",
            },
        )
    try:
        releases_mod.create_annotated_tag(ctx.project_dir, tag_name, notes)
        releases_mod.push_tag(ctx.project_dir, "origin", tag_name)
    except releases_mod.ReleaseCommandError as exc:
        return _step("dev_tag", "failed", {"error": str(exc)})
    return _step("dev_tag", "ok", {"tag": tag_name, "sha": sha})


def _stage_curated_tree(project_dir: Path, repo_role: str, dest: Path) -> dict:
    """Copy the curated subset of `project_dir` into `dest`. Return a summary dict."""
    included, excluded = _curated_file_list(project_dir, repo_role)
    for rel in included:
        src = project_dir / rel
        if not src.exists():
            continue
        out = dest / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        # follow_symlinks=False preserves the symlink-based src/ layout
        # inside the dev repo without dragging the whole src/ tree across
        # the mirror.
        try:
            with open(src, "rb") as f_in:
                content = f_in.read()
        except OSError:
            content = b""
        out.write_bytes(content)
    return {"files_included": len(included), "files_excluded": len(excluded)}


def _resolve_mirror_url_and_email(ctx: ServerContext):
    """Return ``(mirror_url, noreply_email_fn)`` for the public-face target.

    forgejo #8 — pre-3.3.0 ``_run_mirror_sync`` hardcoded github.com for
    both the clone URL and the commit-author noreply email, defeating the
    whole point of 3.2.0's public_face neutrality work. This helper now
    routes through ``ctx.public_face.get_clone_url()`` and
    ``ctx.public_face.noreply_email()`` (Protocol methods that landed in
    3.2.0 #282) when the public_face adapter is wired and resolvable.

    Falls back to the legacy GitHub URL + noreply form when:
      * ctx.public_face is None (2.x-compat fallback or pre-bootstrap)
      * config.public_face_coords() returns None (config-shape edge case)

    Either fallback preserves pre-#8 behavior so un-migrated configs keep
    working without code changes.
    """
    coords = ctx.config.public_face_coords()
    if ctx.public_face is not None and coords is not None:
        owner, repo = coords
        url = ctx.public_face.get_clone_url(owner, repo)
        email_fn = ctx.public_face.noreply_email
    else:
        url = f"https://github.com/{ctx.config.repos.public}.git"
        def email_fn(login, user_id=None):
            return f"{login}@users.noreply.github.com"
    return url, email_fn


def _run_mirror_sync(
    ctx: ServerContext,
    version: str,
    notes: str,
    repo_role: str,
    dry_run: bool,
) -> tuple[dict, Path | None]:
    """Build the curated squashed commit and push to the public mirror.

    Returns (step, mirror_clone_path). The clone path is reused by the
    mirror_tag step so we don't reclone.
    """
    mirror_url, noreply_email_fn = _resolve_mirror_url_and_email(ctx)
    included, excluded = _curated_file_list(ctx.project_dir, repo_role)
    if dry_run:
        return (
            _step(
                "mirror_sync",
                "dry_run_preview",
                {
                    "mirror_url": mirror_url,
                    "files_included": len(included),
                    "files_excluded": len(excluded),
                    "exclusions": list(_exclude_patterns_for(repo_role)),
                    "commit_message_preview": notes.splitlines()[0]
                    if notes
                    else f"v{version}",
                },
            ),
            None,
        )

    work_root = Path(tempfile.mkdtemp(prefix=f"acg-release-v{version}-"))
    mirror_clone = work_root / "mirror"
    staging = work_root / "staging"
    staging.mkdir(parents=True, exist_ok=True)
    try:
        # Force-push safety: capture remote main SHA before the operation;
        # report it in detail so the operator can audit. We use --force-
        # with-lease at push time so a concurrent change at the remote
        # aborts the push instead of silently overwriting.
        existing_remote_sha = releases_mod.remote_main_sha(
            ctx.project_dir, mirror_url
        )

        try:
            releases_mod.clone_repo(mirror_url, mirror_clone)
        except releases_mod.ReleaseCommandError as exc:
            return _step("mirror_sync", "failed", {"error": str(exc)}), None

        _stage_curated_tree(ctx.project_dir, repo_role, staging)

        try:
            releases_mod.replace_tree_contents(mirror_clone, staging)
            user = ctx.config.owner
            releases_mod.configure_user(
                mirror_clone, user, noreply_email_fn(user)
            )
            squashed_sha = releases_mod.commit_all(
                mirror_clone,
                notes if notes else f"v{version}",
                allow_empty=True,
            )
            releases_mod.push_main(mirror_clone, "origin", force=True)
        except releases_mod.ReleaseCommandError as exc:
            return _step("mirror_sync", "failed", {"error": str(exc)}), mirror_clone

        return (
            _step(
                "mirror_sync",
                "ok",
                {
                    "mirror_url": mirror_url,
                    "previous_remote_sha": existing_remote_sha,
                    "new_squashed_sha": squashed_sha,
                    "files_included": len(included),
                    "files_excluded": len(excluded),
                },
            ),
            mirror_clone,
        )
    except Exception as exc:  # noqa: BLE001 — surface anything as step failure
        return _step("mirror_sync", "failed", {"error": str(exc)}), None


def _run_mirror_tag(
    mirror_clone: Path | None,
    version: str,
    notes: str,
    dry_run: bool,
) -> dict:
    tag_name = f"v{version}"
    if dry_run:
        return _step(
            "mirror_tag",
            "dry_run_preview",
            {"tag": tag_name, "would_push": "origin"},
        )
    if mirror_clone is None:
        return _step(
            "mirror_tag",
            "failed",
            {"error": "mirror_sync did not produce a clone — cannot tag."},
        )
    try:
        releases_mod.create_annotated_tag(mirror_clone, tag_name, notes)
        releases_mod.push_tag(mirror_clone, "origin", tag_name)
    except releases_mod.ReleaseCommandError as exc:
        return _step("mirror_tag", "failed", {"error": str(exc)})
    return _step("mirror_tag", "ok", {"tag": tag_name})


_SKILL_BUNDLE_ORDER: tuple[str, ...] = (
    "SKILL.md",
    "bootstrap.md",
    "recording.md",
    "classification.md",
    "multi-repo.md",
    "release.md",
    "commit-rules.md",
    "tools.md",
)

# Match `[label](other.md)` and `[label](other.md#anchor)` only when the
# target is a relative .md filename with no slashes (so we don't strip
# external links or fragments to other directories).
_CROSS_FILE_LINK_RE = re.compile(
    r"\[([^\]]+)\]\((?P<file>[^)/#]+\.md)(?P<anchor>#[^)]+)?\)"
)


def _bundle_skill(skill_dir: Path, dest: Path) -> dict:
    """Concatenate topic files in protocol order into a single file at
    `dest`. Strips relative cross-file links so anchors resolve in the
    bundled single-file context. Returns a summary dict (#137)."""
    if not skill_dir.is_dir():
        raise FileNotFoundError(
            f"skill dir not found: {skill_dir} (expected for skill / monorepo "
            "repo_role)"
        )
    parts: list[str] = []
    files_used: list[str] = []
    for fname in _SKILL_BUNDLE_ORDER:
        path = skill_dir / fname
        if not path.is_file():
            raise FileNotFoundError(
                f"missing topic file: {path} (bundle order requires all "
                f"{len(_SKILL_BUNDLE_ORDER)} files)"
            )
        text = path.read_text(encoding="utf-8")
        text = _CROSS_FILE_LINK_RE.sub(
            lambda m: f"[{m.group(1)}]({m.group('anchor') or ''})",
            text,
        )
        parts.append(text)
        files_used.append(fname)
    bundled = "\n\n".join(parts)
    dest.write_text(bundled, encoding="utf-8")
    return {
        "path": str(dest),
        "bytes": len(bundled),
        "files": files_used,
    }


def _release_asset_path(
    project_dir: Path,
    mirror_clone: Path,
    version: str,
    repo_role: str,
) -> Path | None:
    """Return the file path of the consumer asset to upload, or None.

    skill / monorepo: bundle the multi-file SKILL.md tree under one of
        the candidate skill directories into a single file (#137, G4):

          1. ``project_dir/.claude/skills/forge-manager/`` — 3.0+
             canonical
          2. ``project_dir/.claude/skills/active-claude-github/`` —
             2.x mid-migration fallback
          3. ``project_dir/forge-manager.md`` — pre-2.0 monolithic
             root file (3.0 name)
          4. ``project_dir/active-claude-github.md`` — pre-2.0
             monolithic root file (2.x name)

        Asset filename is always ``forge-manager.md`` from 3.0 onwards
        (matches the canonical skill name; pre-3.0 download URLs no
        longer resolve and operators are expected to update install
        scripts on the major-version bump).
    mcp: a ``git archive`` source tarball materialised next to the clone.
    """
    if repo_role in ("skill", "monorepo"):
        out = mirror_clone.parent / "forge-manager.md"
        # Probe directory candidates first (the canonical 2.0+ install
        # form), then fall through to monolithic root-file candidates
        # (the pre-2.0 layout).
        for skill_subdir in ("forge-manager", "active-claude-github"):
            skill_dir = project_dir / ".claude" / "skills" / skill_subdir
            if skill_dir.is_dir():
                try:
                    _bundle_skill(skill_dir, out)
                except (FileNotFoundError, OSError):
                    return None
                return out if out.is_file() else None
        # Pre-2.0 fallback: monolithic file at project root.
        for monolithic in ("forge-manager.md", "active-claude-github.md"):
            legacy = project_dir / monolithic
            if legacy.is_file():
                out.write_bytes(legacy.read_bytes())
                return out
        return None
    if repo_role == "mcp":
        prefix = f"forge-manager-mcp-v{version}"
        out = mirror_clone.parent / f"{prefix}.tar.gz"
        try:
            releases_mod.git_archive_tarball(
                mirror_clone, f"v{version}", prefix, out
            )
        except releases_mod.ReleaseCommandError:
            return None
        return out if out.is_file() else None
    return None


def _resolve_mirror_release_notes(
    project_dir: Path, fallback: str
) -> tuple[str, str]:
    """Pick the mirror Release page body (#175).

    Prefers ``<project_dir>/RELEASE_NOTES.md`` when present and
    non-empty; that's the curated end-user-facing summary the
    operator authors deliberately. Falls back to ``fallback`` (the
    CHANGELOG-derived contributor body) when the file is absent or
    empty. Returns ``(notes_text, source_label)``.
    """
    rn = project_dir / "RELEASE_NOTES.md"
    if rn.exists():
        try:
            text = rn.read_text(encoding="utf-8").strip()
        except OSError:
            text = ""
        if text:
            return text, "release_notes_md"
    return fallback, "changelog_md"


def _changelog_anchor(version: str) -> str:
    """Return the GitHub-flavored anchor for a `## vX.Y.Z` heading.

    GitHub's slugifier for `## v2.0.1` is `#v201`: lowercase, strip
    punctuation, keep alphanumerics + hyphens. The function reproduces
    that for the version-string shape this project uses (`X.Y.Z` and
    PEP-440 pre-releases like `2.0.0a3`).
    """
    cleaned = version.lower().replace(".", "").replace("-", "").replace("_", "")
    return f"v{cleaned}"


def _dev_release_body(
    version: str, mirror_release_url: str, dev_full: str
) -> str:
    """Compose the contributor-facing dev Release page body (#174).

    Default tagline + cross-link to the mirror release + cross-link to
    the project's CHANGELOG anchor. Operators who want a richer dev
    body still get to edit the page after the cut; this template covers
    the discovery use case (a contributor browsing the dev repo's
    Releases tab).
    """
    anchor = _changelog_anchor(version)
    changelog_url = (
        f"https://github.com/{dev_full}/blob/main/CHANGELOG.md#{anchor}"
    )
    return (
        f"## Dev-side companion to the [public release]({mirror_release_url}).\n\n"
        f"See [`CHANGELOG.md` § v{version}]({changelog_url}) "
        "for the full notes.\n"
    )


def _run_release_notes(
    project_dir: Path,
    mirror_clone: Path | None,
    version: str,
    notes: str,
    repo_role: str,
    dry_run: bool,
    dev_full: str = "",
) -> dict:
    tag_name = f"v{version}"
    mirror_notes, notes_source = _resolve_mirror_release_notes(
        project_dir, notes
    )
    if dry_run:
        if repo_role in ("skill", "monorepo"):
            asset_preview = "forge-manager.md"
        elif repo_role == "mcp":
            asset_preview = f"forge-manager-mcp-v{version}.tar.gz"
        else:
            asset_preview = None
        # Predict the dev release URL preview using the mirror URL
        # placeholder — real URLs land at execute time.
        dev_body_preview = (
            _dev_release_body(version, "<mirror-release-url>", dev_full)[:200]
            if dev_full
            else None
        )
        return _step(
            "release_notes",
            "dry_run_preview",
            {
                "tag": tag_name,
                "title": f"v{version}",
                "mirror_notes_preview": mirror_notes[:400],
                "release_notes_source": notes_source,
                "asset_preview": asset_preview,
                "dev_body_preview": dev_body_preview,
            },
        )
    if mirror_clone is None:
        return _step(
            "release_notes",
            "failed",
            {"error": "no mirror clone available — release_project must "
                      "run mirror_sync first (or stop_after=dev_tag)."},
        )
    notes_path = mirror_clone / ".release_notes.md"
    notes_path.write_text(mirror_notes, encoding="utf-8")
    try:
        mirror_url = releases_mod.create_github_release(
            mirror_clone, tag_name, f"v{version}", notes_path
        )
    except releases_mod.ReleaseCommandError as exc:
        return _step("release_notes", "failed", {"error": str(exc)})

    # Upload the consumer asset on the mirror.  Failure here doesn't
    # unwind the release object — it surfaces as a failed step so the
    # operator can manually recover with `gh release upload <tag>
    # <asset>` (#131).
    asset_path = _release_asset_path(project_dir, mirror_clone, version, repo_role)
    asset_failed: dict | None = None
    asset_note: str | None = None
    asset_name: str | None = None
    if asset_path is None:
        asset_note = (
            "no asset uploaded — repo_role does not produce a "
            "consumer asset, or asset materialisation failed."
        )
    else:
        try:
            releases_mod.upload_release_asset(
                mirror_clone, tag_name, asset_path
            )
            asset_name = asset_path.name
        except releases_mod.ReleaseCommandError as exc:
            asset_failed = {
                "release_url": mirror_url,
                "asset_path": str(asset_path),
                "error": (
                    f"release created but asset upload failed: {exc}. "
                    f"Recover manually: `gh release upload {tag_name} "
                    f"{asset_path.name}`."
                ),
                "release_notes_source": notes_source,
            }
    if asset_failed is not None:
        return _step("release_notes", "failed", asset_failed)

    # #174 — contributor-facing dev Release page. Cross-links to the
    # mirror and the dev-repo CHANGELOG.md anchor for the version.
    # Failure to create the dev page does NOT unwind the mirror
    # release — surfaces as a partial success the operator can
    # manually recover with `gh release create <tag> --repo <dev>`.
    dev_release_url: str | None = None
    dev_release_error: str | None = None
    if dev_full:
        dev_body_path = mirror_clone / ".dev_release_notes.md"
        dev_body_path.write_text(
            _dev_release_body(version, mirror_url, dev_full),
            encoding="utf-8",
        )
        try:
            dev_release_url = releases_mod.create_github_release(
                mirror_clone,
                tag_name,
                f"v{version}",
                dev_body_path,
                repo_full=dev_full,
            )
        except releases_mod.ReleaseCommandError as exc:
            dev_release_error = (
                f"mirror release created but dev release failed: {exc}. "
                f"Recover manually: `gh release create {tag_name} --repo "
                f"{dev_full} --notes-file <body>`."
            )

    detail: dict = {
        "mirror_release_url": mirror_url,
        "dev_release_url": dev_release_url,
        "release_notes_source": notes_source,
        "asset": asset_name,
    }
    if asset_note is not None:
        detail["asset_note"] = asset_note
    if dev_release_error is not None:
        detail["dev_release_error"] = dev_release_error
    return _step("release_notes", "ok", detail)


# ----- Public handler ------------------------------------------------------


# ---------------------------------------------------------------------------
# PyPI direct-publish (pypi_only mode)
# ---------------------------------------------------------------------------
#
# When GitHub access is unavailable, the GHA-driven publish-pypi.yml flow
# can't fire. ``pypi_only=True`` runs the local build + twine-upload
# pipeline instead, skipping the four GitHub-coupled steps (dev_tag,
# mirror_sync, mirror_tag, release_notes).
#
# Token: read from the env vars below (in order). twine's own convention
# is `TWINE_PASSWORD`; PyPI documentation calls the secret `PYPI_API_TOKEN`.
# We accept either name so operators don't have to learn a new one.

_PYPI_TOKEN_ENV_VARS: tuple[str, ...] = ("TWINE_PASSWORD", "PYPI_API_TOKEN")


def _resolve_pypi_token() -> tuple[str | None, str | None]:
    """Return ``(token, env_name)`` for the PyPI API token, or ``(None, None)``.

    Looks up the env vars in order; the first non-empty value wins.
    Doesn't echo the token value — the env name is enough for the
    response payload (``"using TWINE_PASSWORD"``) without leaking the
    secret to the caller.
    """
    import os
    for name in _PYPI_TOKEN_ENV_VARS:
        value = os.environ.get(name, "")
        if value.strip():
            return value, name
    return None, None


def _run_pypi_publish(
    project_dir: Path,
    version: str,
    repo_role: str,
    dry_run: bool,
) -> dict:
    """Build wheel + sdist and upload to PyPI via twine. (pypi_only mode)

    Steps:
      1. Locate ``pyproject.toml`` (monorepo or root).
      2. Verify the pyproject version matches ``version`` (defense in
         depth — ``validate`` already does this, but the local-only flow
         skips fewer things, so re-verify before shipping).
      3. Clean any stale ``dist/`` from previous runs (a stale wheel
         would otherwise be uploaded too).
      4. ``python -m build`` to produce the wheel + sdist.
      5. ``python -m twine check dist/*`` to catch metadata issues.
      6. ``python -m twine upload dist/*`` with ``__token__`` username
         and the env-resolved password.

    Aborts at the first failure with a clear ``error`` string. Caller
    decides whether to surface as the orchestrator's terminal step.
    """
    if repo_role not in ("monorepo", "mcp"):
        return _step(
            "pypi_publish",
            "failed",
            {
                "error": (
                    f"pypi_only mode requires a project with a "
                    f"pyproject.toml (repo_role 'monorepo' or 'mcp'); "
                    f"got {repo_role!r}."
                ),
            },
        )

    pyproject = _resolve_pyproject_path(project_dir)
    if pyproject is None:
        return _step(
            "pypi_publish",
            "failed",
            {"error": "pyproject.toml not found at any candidate path."},
        )
    pkg_dir = pyproject.parent
    dist_dir = pkg_dir / "dist"

    # Version sanity — guards against the operator running pypi_only on
    # a tree where they applied a version_bump in a previous interactive
    # session but rolled back, or where the pyproject is stale relative
    # to the requested version.
    try:
        pyproject_version = _parse_pyproject_version(
            pyproject.read_text(encoding="utf-8")
        )
    except OSError as exc:
        return _step(
            "pypi_publish",
            "failed",
            {"error": f"cannot read {pyproject}: {exc}"},
        )
    if pyproject_version != version:
        return _step(
            "pypi_publish",
            "failed",
            {
                "error": (
                    f"pyproject.toml version is {pyproject_version!r}, "
                    f"requested version is {version!r}. Run "
                    "release_project with approve_version_bump=True to "
                    "align them, or call validate_release to see the "
                    "specific drift."
                ),
            },
        )

    # Token must be present before we shell out (no point building if
    # we can't upload). Skip the check on dry runs so the operator can
    # preview the build path without leaking a token requirement.
    token, token_env_name = _resolve_pypi_token()
    if not dry_run and token is None:
        return _step(
            "pypi_publish",
            "failed",
            {
                "error": (
                    "no PyPI API token in env. Set TWINE_PASSWORD (or "
                    "PYPI_API_TOKEN) to a token from "
                    "https://pypi.org/manage/account/token/ before "
                    "running pypi_only mode."
                ),
                "env_vars_checked": list(_PYPI_TOKEN_ENV_VARS),
            },
        )

    if dry_run:
        return _step(
            "pypi_publish",
            "dry_run_preview",
            {
                "pyproject": str(pyproject.relative_to(project_dir)),
                "package_dir": str(pkg_dir.relative_to(project_dir)),
                "would_run": [
                    f"rm -rf {dist_dir.relative_to(project_dir)}",
                    "python -m build",
                    "python -m twine check dist/*",
                    "python -m twine upload dist/*",
                ],
                "token_env": (
                    f"using {token_env_name}" if token_env_name
                    else "no token in env (would fail in non-dry mode)"
                ),
            },
        )

    # ---- Real run ---------------------------------------------------------
    import os
    import shutil

    if dist_dir.exists():
        shutil.rmtree(dist_dir)

    def _run_subproc(argv: list[str], extra_env: dict[str, str] | None = None) -> dict:
        env = os.environ.copy()
        if extra_env:
            env.update(extra_env)
        result = subprocess.run(
            argv,
            cwd=pkg_dir,
            capture_output=True,
            text=True,
            env=env,
        )
        return {
            "argv": argv,
            "returncode": result.returncode,
            "stdout_tail": result.stdout[-2000:] if result.stdout else "",
            "stderr_tail": result.stderr[-2000:] if result.stderr else "",
        }

    build_log = _run_subproc(["python", "-m", "build"])
    if build_log["returncode"] != 0:
        return _step(
            "pypi_publish",
            "failed",
            {"phase": "build", "error": "python -m build failed", **build_log},
        )

    check_log = _run_subproc(
        ["python", "-m", "twine", "check"]
        + [str(p) for p in sorted(dist_dir.glob("*"))]
    )
    if check_log["returncode"] != 0:
        return _step(
            "pypi_publish",
            "failed",
            {"phase": "check", "error": "twine check failed", **check_log},
        )

    upload_argv = (
        ["python", "-m", "twine", "upload"]
        + [str(p) for p in sorted(dist_dir.glob("*"))]
    )
    upload_log = _run_subproc(
        upload_argv,
        extra_env={
            "TWINE_USERNAME": "__token__",
            "TWINE_PASSWORD": token,  # type: ignore[arg-type]
            "TWINE_NON_INTERACTIVE": "1",
        },
    )
    # Don't echo the upload argv (it would still be a list of file
    # paths — token never appears on argv since we use TWINE_PASSWORD —
    # but be conservative and trim).
    upload_log_safe = {
        k: v for k, v in upload_log.items() if k != "argv"
    } | {"argv": ["python", "-m", "twine", "upload", "<dist files>"]}
    if upload_log["returncode"] != 0:
        return _step(
            "pypi_publish",
            "failed",
            {"phase": "upload", "error": "twine upload failed", **upload_log_safe},
        )

    artifacts = sorted(p.name for p in dist_dir.glob("*"))
    return _step(
        "pypi_publish",
        "ok",
        {
            "version": version,
            "package_dir": str(pkg_dir.relative_to(project_dir)),
            "artifacts": artifacts,
            "token_env": token_env_name,
        },
    )


async def release_project(
    ctx: ServerContext,
    version: str,
    dry_run: bool = True,
    stop_after: str = "release_notes",
    approve_version_bump: bool = False,
    skip_bazel: bool = False,
    skip_smoke_test: bool = False,
    pypi_only: bool = False,
) -> list[TextContent]:
    """#106 — orchestrator: validate → dev_tag → mirror_sync → mirror_tag → release_notes.

    ``pypi_only=True`` (G-PyPI-direct): replaces the four GitHub-coupled
    steps with a single ``pypi_publish`` step that runs ``python -m
    build`` + ``twine upload`` locally, using a token from
    ``$TWINE_PASSWORD`` or ``$PYPI_API_TOKEN``. Useful when the GHA
    publish-pypi.yml flow can't fire (suspended GitHub access, etc.).
    Requires ``repo_role`` of ``monorepo`` or ``mcp`` (the roles that
    have a pyproject.toml). The ``stop_after`` knob is ignored in this
    mode — the flow is always validate → pypi_publish.
    """
    if not version.strip():
        raise ValueError("version must not be empty.")
    if stop_after not in _VALID_STOP_AFTER:
        raise ValueError(
            f"stop_after must be one of {_VALID_STOP_AFTER}; got {stop_after!r}."
        )

    steps: list[dict] = []

    # ----- Phase 1: validate (with optional version-bump propose-and-approve) ----
    validate_step, checks, repo_role = await _run_validate(
        ctx, version, skip_bazel,
        pypi_only=pypi_only, skip_smoke_test=skip_smoke_test,
    )
    steps.append(validate_step)

    if validate_step["status"] == "failed":
        # Special case: only the version-line checks are failing AND the
        # operator hasn't approved a bump yet → propose edits and stop.
        if (
            _failures_are_only_version_bumps(checks)
            and not approve_version_bump
        ):
            edits = _propose_version_bump_edits(
                ctx.project_dir, repo_role, version
            )
            return ok(
                {
                    "version": version,
                    "dry_run": dry_run,
                    "repo_role": repo_role,
                    "stopped_at": "awaiting_version_bump_approval",
                    "proposed_edits": [
                        {
                            "path": e["path"],
                            "before": e["before"],
                            "after": e["after"],
                        }
                        for e in edits
                    ],
                    "steps": steps,
                    "next_action": (
                        "Re-run release_project with approve_version_bump=True "
                        "to apply the edits and continue."
                    ),
                }
            )

        # Approval given — apply edits, commit, push, and re-validate.
        if (
            approve_version_bump
            and _failures_are_only_version_bumps(checks)
        ):
            edits = _propose_version_bump_edits(
                ctx.project_dir, repo_role, version
            )
            if not edits:
                # Propose returned empty — nothing to apply; bail with the
                # original validate failure intact.
                return ok(
                    {
                        "version": version,
                        "dry_run": dry_run,
                        "repo_role": repo_role,
                        "stopped_at": "validate",
                        "steps": steps,
                    }
                )
            if dry_run:
                steps.append(
                    _step(
                        "version_bump",
                        "dry_run_preview",
                        {"edits": edits},
                    )
                )
                return ok(
                    {
                        "version": version,
                        "dry_run": True,
                        "repo_role": repo_role,
                        "stopped_at": "version_bump",
                        "steps": steps,
                    }
                )
            _apply_version_bump_edits(ctx.project_dir, edits)
            try:
                bump_sha = releases_mod.commit_all(
                    ctx.project_dir,
                    f"chore: bump {repo_role} to v{version}",
                )
                releases_mod.push_main(ctx.project_dir, "origin")
            except releases_mod.ReleaseCommandError as exc:
                steps.append(
                    _step("version_bump", "failed", {"error": str(exc)})
                )
                return ok(
                    {
                        "version": version,
                        "dry_run": False,
                        "repo_role": repo_role,
                        "stopped_at": "version_bump",
                        "steps": steps,
                    }
                )
            steps.append(
                _step(
                    "version_bump",
                    "ok",
                    {"sha": bump_sha, "edits": [
                        {"path": e["path"], "before": e["before"], "after": e["after"]}
                        for e in edits
                    ]},
                )
            )
            # Re-validate after bump.
            validate_step, checks, repo_role = await _run_validate(
                ctx, version, skip_bazel, pypi_only=pypi_only,
            )
            steps.append(validate_step)
            if validate_step["status"] == "failed":
                return ok(
                    {
                        "version": version,
                        "dry_run": False,
                        "repo_role": repo_role,
                        "stopped_at": "validate",
                        "steps": steps,
                    }
                )
        else:
            return ok(
                {
                    "version": version,
                    "dry_run": dry_run,
                    "repo_role": repo_role,
                    "stopped_at": "validate",
                    "steps": steps,
                }
            )

    if stop_after == "validate":
        return ok(
            {
                "version": version,
                "dry_run": dry_run,
                "repo_role": repo_role,
                "stopped_at": "validate",
                "steps": steps,
            }
        )

    # ----- pypi_only mode: skip every GitHub-coupled step ---------------------
    # Validate already ran (above). Dispatch the build + upload phase via
    # the post-validate chain (#294 Phase A). pypi_only chain is just
    # [pypi_publish]. (G-PyPI-direct)
    if pypi_only:
        chain = build_post_validate_chain(
            pypi_only=True, stop_after=stop_after,
        )
        chain_request = {
            "server_ctx": ctx,
            "version": version,
            "repo_role": repo_role,
            "dry_run": dry_run,
        }
        final_ctx = await aexecute(chain, request=chain_request)
        pypi_step = final_ctx.response.get("pypi_publish")
        if pypi_step is not None:
            steps.append(dict(pypi_step))
        return ok(
            _finalise(version, dry_run, repo_role, "pypi_publish", steps)
        )

    # ----- Auto-populate CHANGELOG.md if absent (per #106 decision 1) -----
    changelog_path = ctx.project_dir / "CHANGELOG.md"
    if not changelog_path.exists():
        generated = _generate_changelog_md(ctx.project_dir)
        if generated is not None:
            if dry_run:
                steps.append(
                    _step(
                        "changelog_populate",
                        "dry_run_preview",
                        {"path": "CHANGELOG.md", "preview": generated[:400]},
                    )
                )
            else:
                changelog_path.write_text(generated, encoding="utf-8")
                # Commit + push so the file lands in dev main and the
                # subsequent dev_tag step tags a tree that includes it.
                # Without this, CHANGELOG.md ends up orphan-untracked in
                # the operator's working tree and absent from both dev
                # tag tree and mirror snapshot (#130).
                try:
                    bump_sha = releases_mod.commit_all(
                        ctx.project_dir,
                        f"chore: regenerate CHANGELOG.md for v{version}",
                    )
                    releases_mod.push_main(ctx.project_dir, "origin")
                except releases_mod.ReleaseCommandError as exc:
                    steps.append(
                        _step(
                            "changelog_populate",
                            "failed",
                            {"path": "CHANGELOG.md", "error": str(exc)},
                        )
                    )
                    return ok(
                        _finalise(
                            version, dry_run, repo_role,
                            "changelog_populate", steps,
                        )
                    )
                steps.append(
                    _step(
                        "changelog_populate",
                        "ok",
                        {
                            "path": "CHANGELOG.md",
                            "bytes": len(generated),
                            "commit_sha": bump_sha,
                        },
                    )
                )

    notes = _release_notes_for_version(ctx.project_dir, version) or (
        f"## v{version}\n\nNo changelog entry found — manual fill-in required."
    )

    # ----- Phases 2-5: dispatch via release-chain (#294 Phase A) -------------
    # The chain wraps dev_tag → mirror_sync → mirror_tag → release_notes
    # in compensating-transaction interceptors per Discussion #3. A
    # state-mutating step that fails surfaces ctx.error; subsequent
    # steps don't run; prior steps' error handlers compensate (delete
    # tag, restore mirror ref, etc.) on the unwind path.
    chain = build_post_validate_chain(
        pypi_only=False, stop_after=stop_after,
    )
    chain_request = {
        "server_ctx": ctx,
        "version": version,
        "notes": notes,
        "repo_role": repo_role,
        "dry_run": dry_run,
    }
    final_ctx = await aexecute(chain, request=chain_request)

    # Each interceptor stores its _step() output under a top-level
    # response key named after the step. Iterate in canonical chain
    # order so the steps list reflects execution order.
    for step_name in ("dev_tag", "mirror_sync", "mirror_tag", "release_notes"):
        step_dict = final_ctx.response.get(step_name)
        if step_dict is not None:
            steps.append(dict(step_dict))

    # stopped_at: if the chain errored, the failing step is the last
    # forward audit entry whose detail.status == "failed". Otherwise
    # the chain ran to completion at stop_after.
    if final_ctx.error is not None:
        failed_step = None
        for entry in reversed(final_ctx.steps_taken):
            detail = entry.get("detail") or {}
            if detail.get("status") == "failed":
                failed_step = entry.get("step")
                break
        stopped_at = failed_step or stop_after
    else:
        stopped_at = stop_after

    return ok(_finalise(version, dry_run, repo_role, stopped_at, steps))


def _finalise(
    version: str,
    dry_run: bool,
    repo_role: str,
    stopped_at: str,
    steps: list[dict],
) -> dict:
    return {
        "version": version,
        "dry_run": dry_run,
        "repo_role": repo_role,
        "stopped_at": stopped_at,
        "steps": steps,
    }
