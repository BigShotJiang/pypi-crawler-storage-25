"""GitLabAdapter — PlatformAdapter implementation for GitLab.com and
self-hosted GitLab instances (3.0 / Phase 4).

Pure-REST adapter against GitLab's v4 API. Auth header is
``Authorization: Bearer <T>`` (GitLab also accepts ``PRIVATE-TOKEN``;
Bearer is the more standard form used by recent OAuth-style PATs).

Project identification: GitLab's API addresses projects either by
numeric ``id`` or by URL-encoded ``namespace/path``. This adapter uses
the latter consistently so callers don't need to resolve a numeric ID
first; e.g. ``forge-manager-test/forge-manager-test`` becomes
``forge-manager-test%2Fforge-manager-test`` in the path.

Issue numbers: GitLab distinguishes ``id`` (global) from ``iid``
(project-internal). The Protocol's ``number`` field maps to ``iid``;
``ref.native_id`` carries the global ``id`` for traceability.

Discussions: GitLab has no separate Discussions surface. Per OQ1,
Discussions are Issues with ``kind:discussion`` + ``category:*``
labels (same approach as ForgejoAdapter).
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, ClassVar
from urllib.parse import quote

import httpx

from . import errors as _errors
from . import _recovery
from ._common import (
    find_milestone_by_title_in_list as _find_milestone_by_title_in_list,
    label_names_from_api as _label_names_from_api,
    milestone_title_from_api as _milestone_title_from_api,
    parse_iso as _parse_iso,
)
from . import _rest_base
# Standard label catalogue seeded on every GitLab-bootstrapped project.
# Mirrors the Forgejo/GitHub _STANDARD_LABELS sets — duplicated rather
# than imported because adapters must stay leaf-clean.
_GITLAB_STANDARD_LABELS: tuple[tuple[str, str, str], ...] = (
    ("bug", "d73a4a", "Something isn't working"),
    ("feature", "a2eeef", "New feature or enhancement"),
    ("refactor", "ededed", "Internal restructure with no external behaviour change"),
    ("rfc", "fbca04", "RFC for a significant change"),
    ("chore", "cccccc", "Tooling, deps, config, CI"),
    ("area:skill", "0e8a16", "Changes to the forge-manager skill prose"),
    ("area:mcp", "0e8a16", "Changes to MCP server code or behaviour"),
    ("area:public-mirror", "5319e7", "Triaged from or targeted at a public mirror"),
    ("area:bootstrap", "5319e7", "Bootstrap sequence"),
)

# GitLab has no native Discussions surface; same Issues-with-reserved-
# labels convention as Forgejo (per OQ1).
_GITLAB_DISCUSSION_LABELS: tuple[tuple[str, str, str], ...] = (
    ("kind:discussion", "0075ca", "Issue used as a Discussion (OQ1)"),
    ("category:Architecture", "1d76db", "System design decisions"),
    ("category:Ideas", "1d76db", "Early exploration, what-ifs"),
    ("category:UX_UI", "1d76db", "Interface, API shape, naming"),
    ("category:Announcements", "1d76db", "Project Index / Session Lock / running-log Discussions"),
    ("category:claude-use-only", "1d76db", "Session locks, bootstrap logs"),
    ("decided", "0e8a16", "Discussion has reached Decided ✓"),
)


from .types import (
    ArtifactRef,
    BootstrapResult,
    Comment,
    Discussion,
    DriftReport,
    Issue,
    Milestone,
    RecoveryBundle,
    Release,
    RemoteChange,
    SearchResult,
)


GITLAB_API_BASE = "https://gitlab.com"
"""GitLab.com's host. Self-hosted instances pass ``url`` in their config
blob."""


def _project_path(owner: str, repo: str) -> str:
    """URL-encode the project's ``namespace/path`` into the form GitLab's
    API expects in URL segments. Slash inside the namespace is encoded
    as %2F; nested groups (e.g., ``parent/child/repo``) work the same
    way."""
    return quote(f"{owner}/{repo}", safe="")


class GitLabAdapter(_rest_base.RestAdapterBase):
    """PlatformAdapter for GitLab via REST.

    Construction:
      * Pass ``platform_id="gitlab"`` (default); ``url`` field selects
        gitlab.com vs self-hosted.
      * Token from ``~/.gitlab-token`` (mode 600 expected) or
        ``$GITLAB_TOKEN`` env var. Env var wins so the Bazel
        hermetic sandbox can inherit the token via ``--test_env=``.
    """

    platform_id: ClassVar[str] = "gitlab"
    has_scaffold: ClassVar[bool] = True
    has_session_event_surface: ClassVar[bool] = False  # Same Issues-as-Discussions story as Forgejo.
    has_project_boards: ClassVar[bool] = False  # forgejo #10 / 3.4.0 — GitLab has Iterations + Boards but Issue-attach is in GraphQL Beta.

    # RestAdapterBase parameterization (DRY-B).
    _AUTH_SCHEME: ClassVar[str] = "Bearer"
    _API_PATH: ClassVar[str] = "/api/v4"
    _ADAPTER_NAME: ClassVar[str] = "GitLabAdapter"

    def __init__(
        self,
        *,
        token: str,
        api_base: str = GITLAB_API_BASE,
        platform_id: str = "gitlab",
    ):
        self._token = token
        self._api_base = api_base.rstrip("/")
        self.platform_id = platform_id  # type: ignore[misc]
        self._client: httpx.AsyncClient | None = None

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "GitLabAdapter":
        """Construct from a forge-config.json platform entry.

        Expected shape:

            {"id": "gitlab",
             "url": "https://gitlab.example.com",   # optional; defaults to gitlab.com
             "owner": "...",
             "private": "...-dev",
             "public": "...",
             "docs": "...-docs"}
        """
        platform_id = config.get("id", "gitlab")
        if platform_id != "gitlab":
            raise _errors.ForgeError(
                f"GitLabAdapter: unsupported platform_id={platform_id!r}; "
                f"expected 'gitlab'."
            )
        api_base = config.get("url") or GITLAB_API_BASE

        # Token discovery delegated to the unified dispatcher (#283).
        # Precedence: env first via dispatcher chain (GITLAB_TOKEN +
        # any platforms[].token_env override), then legacy token_path.
        from ..config import get_platform_token  # noqa: PLC0415

        token: str | None = get_platform_token(
            platform_id, token_env_override=config.get("token_env"),
        )
        if token is None:
            legacy_token_path = config.get("token_path")
            if legacy_token_path:
                path = Path(legacy_token_path).expanduser()
                if path.is_file():
                    content = path.read_text(encoding="utf-8").strip()
                    if content:
                        token = content
        if token is None:
            raise _errors.ForgeError(
                "GitLabAdapter: no token found. Set $GITLAB_TOKEN, create "
                "~/.gitlab-token (chmod 600, single-line PAT), or set "
                "platforms[].token_env to a custom env-var name."
            )
        return cls(token=token, api_base=api_base, platform_id=platform_id)

    # _headers, _get_client, _request, aclose lifted into
    # RestAdapterBase (DRY-B).

    # =====================================================================
    # Repo-level reads
    # =====================================================================

    async def get_repo_node_id(self, owner: str, repo: str) -> str:
        data = await self._request("GET", f"/projects/{_project_path(owner, repo)}")
        repo_id = data.get("id")
        if repo_id is None:
            raise _errors.InvalidArtifactRefError("repo", f"{owner}/{repo}")
        return str(repo_id)

    async def get_repo_visibility(self, owner: str, repo: str) -> str | None:
        """Return ``"PUBLIC"`` / ``"INTERNAL"`` / ``"PRIVATE"`` /
        ``None``. GitLab uses lowercase ``visibility`` values
        (``"public"``, ``"internal"``, ``"private"``); upper-case at
        the boundary so the Protocol returns the same alphabet across
        backends. (PAR-3)
        """
        data = await self._request(
            "GET", f"/projects/{_project_path(owner, repo)}",
            allow_404_as_none=True,
        )
        if data is None:
            return None
        raw = data.get("visibility") or ""
        return raw.upper() or None

    async def list_milestones(
        self, owner: str, repo: str, state: str = "all"
    ) -> list[Milestone]:
        # GitLab milestone state values are 'active' / 'closed'; map
        # the common 'open' to 'active'.
        params: dict[str, Any] = {"per_page": 50}
        if state == "open":
            params["state"] = "active"
        elif state == "closed":
            params["state"] = "closed"
        data = await self._request(
            "GET",
            f"/projects/{_project_path(owner, repo)}/milestones",
            params=params,
        ) or []
        return [_milestone_from_api(m) for m in data]

    async def find_milestone(
        self, owner: str, repo: str, name_or_number: str | int
    ) -> Milestone | None:
        if isinstance(name_or_number, int):
            data = await self._request(
                "GET",
                f"/projects/{_project_path(owner, repo)}/milestones/{name_or_number}",
                allow_404_as_none=True,
            )
            return _milestone_from_api(data) if data else None
        # Title-based: linear search via the shared helper (DRY-E).
        return await _find_milestone_by_title_in_list(
            self.list_milestones, owner, repo, name_or_number,
        )

    # =====================================================================
    # Issue operations
    # =====================================================================

    async def create_issue(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        labels: list[str],
        milestone: str | int | None = None,
    ) -> Issue:
        # Ensure all labels exist (GitLab create-issue silently accepts
        # unknown label names by creating them with a default color, but
        # we ensure colors are explicit + consistent).
        for name in labels:
            await self.ensure_label(owner=owner, repo=repo, name=name)

        payload: dict[str, Any] = {
            "title": title,
            "description": body,
            "labels": ",".join(labels),
        }
        if milestone is not None:
            ms = await self.find_milestone(owner, repo, milestone)
            if ms is None:
                raise _errors.InvalidArtifactRefError(
                    "milestone", str(milestone),
                )
            payload["milestone_id"] = ms.number

        data = await self._request(
            "POST",
            f"/projects/{_project_path(owner, repo)}/issues",
            json=payload,
        )
        return _issue_from_api(data, owner=owner, repo=repo, platform_id=self.platform_id)

    async def get_issue(self, owner: str, repo: str, number: int) -> Issue:
        data = await self._request(
            "GET",
            f"/projects/{_project_path(owner, repo)}/issues/{number}",
            allow_404_as_none=True,
        )
        if data is None:
            raise _errors.InvalidArtifactRefError("issue number", str(number))
        return _issue_from_api(data, owner=owner, repo=repo, platform_id=self.platform_id)

    async def get_issue_body(self, ref: ArtifactRef) -> str:
        if ref.number is None:
            raise _errors.InvalidArtifactRefError(
                "ref.number",
                "GitLabAdapter.get_issue_body requires ref.number; "
                "node-ID-only refs from other adapters cannot be resolved "
                "via the GitLab REST API.",
            )
        data = await self._request(
            "GET",
            f"/projects/{_project_path(ref.owner, ref.repo)}/issues/{ref.number}",
            allow_404_as_none=True,
        )
        if data is None:
            raise _errors.InvalidArtifactRefError(
                "issue number", str(ref.number),
            )
        # GitLab uses "description" for the issue body.
        return data.get("description", "") or ""

    async def update_issue_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        await self._request(
            "PUT",
            f"/projects/{_project_path(ref.owner, ref.repo)}/issues/{ref.number}",
            json={"description": new_body},
        )

    async def close_issue(
        self, ref: ArtifactRef, state_reason: str = "completed"
    ) -> Issue:
        # GitLab uses state_event=close (not state=closed). The PUT
        # response carries the updated issue — shape into canonical.
        data = await self._request(
            "PUT",
            f"/projects/{_project_path(ref.owner, ref.repo)}/issues/{ref.number}",
            json={"state_event": "close"},
        )
        return _issue_from_api(
            data, owner=ref.owner, repo=ref.repo,
            platform_id=self.platform_id,
        )

    async def add_label(self, ref: ArtifactRef, label_name: str) -> None:
        # Use add_labels query param so existing labels survive.
        await self.ensure_label(owner=ref.owner, repo=ref.repo, name=label_name)
        await self._request(
            "PUT",
            f"/projects/{_project_path(ref.owner, ref.repo)}/issues/{ref.number}",
            json={"add_labels": label_name},
        )

    async def remove_label(self, ref: ArtifactRef, label_name: str) -> None:
        await self._request(
            "PUT",
            f"/projects/{_project_path(ref.owner, ref.repo)}/issues/{ref.number}",
            json={"remove_labels": label_name},
        )

    async def search_issues(
        self,
        *,
        owner: str,
        repo: str,
        query: str = "",
        state: str = "all",
        labels: list[str] | None = None,
        milestone: str | None = None,
        limit: int = 30,
    ) -> SearchResult:
        params: dict[str, Any] = {"per_page": min(limit, 100)}
        # GitLab's state values are 'opened' / 'closed' / 'all' — note 'opened' not 'open'.
        if state == "open":
            params["state"] = "opened"
        elif state == "closed":
            params["state"] = "closed"
        if query:
            params["search"] = query
        if labels:
            params["labels"] = ",".join(labels)
        if milestone:
            params["milestone"] = milestone

        data = await self._request(
            "GET",
            f"/projects/{_project_path(owner, repo)}/issues",
            params=params,
        ) or []
        results = [
            _issue_from_api(item, owner=owner, repo=repo, platform_id=self.platform_id)
            for item in data[:limit]
        ]
        # GitLab returns the X-Total header on list endpoints but the
        # adapter's _request helper doesn't expose response headers
        # today; report the result length as the floor.
        return SearchResult(
            results=results,
            total_count=len(results),
            query=query,
        )

    async def list_open_issues(
        self, *, owner: str, repo: str, limit: int = 100
    ) -> list[Issue]:
        result = await self.search_issues(
            owner=owner, repo=repo, state="open", limit=limit,
        )
        return list(result.results)

    # =====================================================================
    # Discussion operations (Issues with kind:discussion + category:* labels)
    # =====================================================================

    async def create_discussion(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        category: str | None = None,
    ) -> Discussion:
        labels = ["kind:discussion"]
        if category:
            labels.append(f"category:{_normalize_category(category)}")
        issue = await self.create_issue(
            owner=owner, repo=repo, title=title, body=body, labels=labels,
        )
        return _discussion_from_issue(issue, category=category)

    async def get_discussion(
        self, owner: str, repo: str, number: int
    ) -> Discussion:
        issue = await self.get_issue(owner, repo, number)
        if "kind:discussion" not in issue.labels:
            raise _errors.InvalidArtifactRefError(
                "discussion number",
                f"{number} (resolved to issue without kind:discussion)",
            )
        category = _category_from_labels(issue.labels)
        return _discussion_from_issue(issue, category=category)

    async def get_discussion_body(self, ref: ArtifactRef) -> str:
        # GitLab models Discussions as Issues with kind:discussion +
        # category:* labels (per OQ1) — same REST endpoint.
        return await self.get_issue_body(ref)

    async def update_discussion_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        await self.update_issue_body(ref, new_body, force=force)

    async def list_recent_discussions(
        self, *, owner: str, repo: str, since_days: int = 7
    ) -> list[Discussion]:
        cutoff = datetime.now(timezone.utc).timestamp() - since_days * 86400
        params = {
            "labels": "kind:discussion",
            "state": "all",
            "per_page": 50,
        }
        data = await self._request(
            "GET",
            f"/projects/{_project_path(owner, repo)}/issues",
            params=params,
        ) or []
        result: list[Discussion] = []
        for item in data:
            created = _parse_iso(item.get("created_at"))
            if created is not None and created.timestamp() < cutoff:
                continue
            issue = _issue_from_api(
                item, owner=owner, repo=repo, platform_id=self.platform_id,
            )
            result.append(_discussion_from_issue(
                issue, category=_category_from_labels(issue.labels),
            ))
        return result

    async def mark_decided(self, ref: ArtifactRef) -> None:
        await self.add_label(ref, "decided")

    async def mark_answer(self, comment_ref: ArtifactRef) -> None:
        # GitLab has no comment-level "answer" surface. See
        # ForgejoAdapter.mark_answer for the rationale.
        raise NotImplementedError(
            "GitLabAdapter.mark_answer: GitLab has no comment-level "
            "answer feature. Use mark_decided(parent_ref) for the "
            "portable `decided` label on the parent discussion."
        )

    # =====================================================================
    # Comment operations (GitLab calls them "notes")
    # =====================================================================

    async def append_comment(self, target: ArtifactRef, body: str) -> Comment:
        if target.kind not in ("issue", "discussion"):
            raise ValueError(f"append_comment: unsupported target.kind={target.kind!r}")
        data = await self._request(
            "POST",
            f"/projects/{_project_path(target.owner, target.repo)}/issues/{target.number}/notes",
            json={"body": body},
        )
        return _comment_from_api(data, parent=target, platform_id=self.platform_id)

    async def list_comments(
        self,
        target: ArtifactRef,
        *,
        since_days: int | None = None,
        limit: int | None = None,
    ) -> list[Comment]:
        if target.kind not in ("issue", "discussion"):
            raise ValueError(f"list_comments: unsupported target.kind={target.kind!r}")
        # GitLab notes don't have a since-days filter; we filter locally.
        data = await self._request(
            "GET",
            f"/projects/{_project_path(target.owner, target.repo)}/issues/{target.number}/notes",
            params={"per_page": 100, "sort": "asc"},
        ) or []
        results: list[Comment] = []
        cutoff = (
            datetime.now(timezone.utc).timestamp() - since_days * 86400
            if since_days is not None else None
        )
        for d in data:
            # Skip system notes ("changed milestone", "added label", etc.)
            if d.get("system"):
                continue
            if cutoff is not None:
                created = _parse_iso(d.get("created_at"))
                if created is not None and created.timestamp() < cutoff:
                    continue
            results.append(_comment_from_api(
                d, parent=target, platform_id=self.platform_id,
            ))
        if limit is not None and len(results) > limit:
            results = results[-limit:]
        return results

    # =====================================================================
    # Label management
    # =====================================================================

    async def ensure_label(
        self,
        *,
        owner: str,
        repo: str,
        name: str,
        color: str = "0E8A16",
        description: str = "",
    ) -> str:
        existing = await self._find_label_id(owner=owner, repo=repo, name=name)
        if existing is not None:
            return str(existing)
        normalized_color = color if color.startswith("#") else f"#{color}"
        data = await self._request(
            "POST",
            f"/projects/{_project_path(owner, repo)}/labels",
            json={"name": name, "color": normalized_color, "description": description},
        )
        return str(data["id"])

    async def _find_label_id(
        self, *, owner: str, repo: str, name: str
    ) -> int | None:
        page = 1
        while True:
            data = await self._request(
                "GET",
                f"/projects/{_project_path(owner, repo)}/labels",
                params={"page": page, "per_page": 100},
            ) or []
            for label in data:
                if label.get("name") == name:
                    return int(label["id"])
            if len(data) < 100:
                return None
            page += 1

    async def _paginate_get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        page_size: int = 50,
        max_pages: int = 200,
    ) -> list[dict]:
        """Walk paginated GET results until the response is shorter than
        ``page_size`` or ``max_pages`` is reached (#279).

        GitLab pagination is per_page-based with explicit page=N
        cursor; an empty array signals the end. ``max_pages`` is a
        circuit breaker matching the Forgejo helper.
        """
        results: list[dict] = []
        page = 1
        merged: dict[str, Any] = {"page": page, "per_page": page_size}
        if params:
            merged.update(params)
        while page <= max_pages:
            merged["page"] = page
            data = await self._request("GET", path, params=dict(merged)) or []
            if not isinstance(data, list):
                break
            results.extend(data)
            if len(data) < page_size:
                break
            page += 1
        return results

    # =====================================================================
    # Release operations
    # =====================================================================

    async def create_release(
        self,
        *,
        owner: str,
        repo: str,
        tag: str,
        name: str,
        body: str = "",
        prerelease: bool = False,
        draft: bool = False,
    ) -> Release:
        # GitLab doesn't have a 'prerelease' or 'draft' boolean —
        # convention is to encode them in the release name or via the
        # milestone. We pass through but echo the caller's values back
        # in the returned Release for uniformity.
        del draft  # not natively supported; preserved for Protocol uniformity
        payload = {
            "tag_name": tag,
            "name": name,
            "description": body,
        }
        data = await self._request(
            "POST",
            f"/projects/{_project_path(owner, repo)}/releases",
            json=payload,
        )
        return Release(
            tag=data.get("tag_name", tag),
            name=data.get("name", name),
            body=data.get("description", body) or "",
            prerelease=prerelease,  # GitLab doesn't track this; pass through caller's value.
            created_at=_parse_iso(data.get("created_at")),
            url=data.get("_links", {}).get("self", "") if isinstance(data.get("_links"), dict) else "",
        )

    def get_clone_url(self, owner: str, repo: str) -> str:
        """GitLab clone URL — base from the configured ``api_base`` (#282)."""
        host = self._api_base
        if host.endswith("/api/v4"):
            host = host[: -len("/api/v4")]
        host = host.rstrip("/")
        return f"{host}/{owner}/{repo}.git"

    def noreply_email(
        self, login: str, user_id: int | None = None
    ) -> str:
        """GitLab-conventional noreply email (#282).

        gitlab.com uses ``{user_id}-{login}@users.noreply.gitlab.com``;
        self-hosted GitLab instances use the same host-derived form.
        Without ``user_id`` we fall back to ``{login}@users.noreply.{host}``
        which GitLab also accepts for commit attribution.
        """
        host = self._api_base
        if host.endswith("/api/v4"):
            host = host[: -len("/api/v4")]
        host = host.split("://", 1)[-1].rstrip("/")
        if user_id is not None:
            return f"{user_id}-{login}@users.noreply.{host}"
        return f"{login}@users.noreply.{host}"

    def public_issue_url_regex(self) -> "re.Pattern[str]":
        """GitLab Issue URL form (#11).

        Pattern: ``https?://{host}/(owner)/(repo)/issues/(\\d+)`` — does
        not yet handle GitLab's nested-group URL form (e.g. ``group/sub/
        project``); pure ``owner/repo`` (single-level namespace) covers
        the common case. Nested-group support is a follow-up.
        """
        import re
        host = self._api_base
        if host.endswith("/api/v4"):
            host = host[: -len("/api/v4")]
        host = host.split("://", 1)[-1].rstrip("/")
        return re.compile(
            rf"https?://{re.escape(host)}/([\w.-]+)/([\w.-]+)/issues/(\d+)"
        )

    async def delete_release(
        self, *, owner: str, repo: str, tag: str,
    ) -> None:
        """Delete a GitLab Release (#294 Phase A).

        GitLab keys releases by tag_name (URL-encoded) — single-step
        DELETE. Idempotent — 404 / 403 surface as no-op.
        """
        await self._request(
            "DELETE",
            f"/projects/{_project_path(owner, repo)}/releases/{tag}",
            allow_404_as_none=True,
        )

    # =====================================================================
    # File-content reads
    # =====================================================================

    async def fetch_file_content(
        self, *, owner: str, repo: str, path: str, ref: str = "main"
    ) -> str | None:
        # GitLab requires the file path to be URL-encoded in the segment.
        encoded_path = quote(path, safe="")
        data = await self._request(
            "GET",
            f"/projects/{_project_path(owner, repo)}/repository/files/{encoded_path}/raw",
            params={"ref": ref},
            allow_404_as_none=True,
        )
        if data is None:
            return None
        return data if isinstance(data, str) else None

    # =====================================================================
    # Bundled reads (Phase C5)
    # =====================================================================

    async def bundle_recover_context(
        self,
        *,
        owner: str,
        repo: str,
        toc_discussion_id: str,
        since_days: int = 7,
        issue_limit: int = 100,
    ) -> RecoveryBundle:
        # GitLab REST has no multi-query surface — delegate to the
        # shared decomposed default.
        return await _recovery.default_bundle_recover_context(
            self, owner=owner, repo=repo,
            toc_discussion_id=toc_discussion_id,
            since_days=since_days, issue_limit=issue_limit,
        )

    # =====================================================================
    # Health + drift
    # =====================================================================

    async def probe(self) -> bool:
        # /api/v4/version requires auth on gitlab.com; if the token is
        # valid we get 200. Use this as the auth+reachability probe.
        try:
            data = await self._request("GET", "/version")
            return isinstance(data, dict) and "version" in data
        except _errors.ForgeUnavailableError:
            return False
        except _errors.ForgeError:
            return False

    async def compute_drift(self, snapshot: dict) -> DriftReport:
        """Diff this adapter's remote state against the canonical
        ``snapshot`` (typically produced by ``LocalStoreAdapter.snapshot``).

        Mirrors ``ForgejoAdapter.compute_drift`` (set-based comparison of
        issues + discussions). GitLab differences from Forgejo: ``iid``
        instead of ``number`` for the project-internal ID; states are
        ``"opened"``/``"closed"`` (Forgejo: ``"open"``/``"closed"``);
        ``labels`` returns plain strings, not objects. (PAR-4)

        The snapshot dict must carry ``owner`` and ``repo`` fields so we
        know which GitLab project to inspect. Body-content divergence
        detection lands in a follow-up.
        """
        owner = snapshot.get("owner") or ""
        repo = snapshot.get("repo") or ""
        if not owner or not repo:
            return DriftReport(
                platform_id=self.platform_id,
                is_clean=False,
                notes=["snapshot missing owner/repo; cannot diff remote"],
            )

        local_issues: dict = snapshot.get("issues", {})
        local_discussions: dict = snapshot.get("discussions", {})

        try:
            raw_issues = await self._request(
                "GET",
                f"/projects/{_project_path(owner, repo)}/issues",
                params={"state": "all", "per_page": 100},
            ) or []
        except _errors.ForgeUnavailableError:
            return DriftReport(
                platform_id=self.platform_id,
                is_clean=False,
                notes=["compute_drift: remote unreachable; report inconclusive"],
            )

        # Partition remote items by kind via the kind:discussion label.
        remote_issues: dict[int, dict] = {}
        remote_discussions: dict[int, dict] = {}
        for item in raw_issues:
            iid = item.get("iid")
            if iid is None:
                continue
            # GitLab returns labels as a list of plain strings.
            label_names = list(item.get("labels") or [])
            entry = {
                "state": (
                    "closed" if (item.get("state") or "opened").lower() == "closed"
                    else "open"
                ),
                "labels": label_names,
            }
            if "kind:discussion" in label_names:
                remote_discussions[int(iid)] = entry
            else:
                remote_issues[int(iid)] = entry

        # Set-based diffs — issues.
        local_issue_nums = {int(k) for k in local_issues}
        remote_issue_nums = set(remote_issues)
        issues_only_local = sorted(local_issue_nums - remote_issue_nums)
        issues_only_remote = sorted(remote_issue_nums - local_issue_nums)
        issues_diverged: list[int] = []
        for n in local_issue_nums & remote_issue_nums:
            if local_issues[n].get("state") != remote_issues[n]["state"]:
                issues_diverged.append(n)
                continue
            if set(local_issues[n].get("labels") or []) != set(remote_issues[n]["labels"]):
                issues_diverged.append(n)

        # Set-based diffs — discussions.
        local_disc_nums = {int(k) for k in local_discussions}
        remote_disc_nums = set(remote_discussions)
        discussions_only_local = sorted(local_disc_nums - remote_disc_nums)
        discussions_only_remote = sorted(remote_disc_nums - local_disc_nums)
        discussions_diverged: list[int] = []
        for n in local_disc_nums & remote_disc_nums:
            if local_discussions[n].get("state") != remote_discussions[n]["state"]:
                discussions_diverged.append(n)
                continue
            if set(local_discussions[n].get("labels") or []) != set(remote_discussions[n]["labels"]):
                discussions_diverged.append(n)

        is_clean = (
            not issues_only_local
            and not issues_only_remote
            and not issues_diverged
            and not discussions_only_local
            and not discussions_only_remote
            and not discussions_diverged
        )
        return DriftReport(
            platform_id=self.platform_id,
            is_clean=is_clean,
            issues_only_local=issues_only_local,
            issues_only_remote=issues_only_remote,
            issues_diverged=sorted(issues_diverged),
            discussions_only_local=discussions_only_local,
            discussions_only_remote=discussions_only_remote,
            discussions_diverged=sorted(discussions_diverged),
        )

    # =====================================================================
    # Bootstrap (multi-platform scaffold C4)
    # =====================================================================

    async def bootstrap_project(
        self,
        *,
        owner: str,
        project_name: str,
        description: str,
        existing_state: dict | None = None,
    ) -> BootstrapResult:
        """Bootstrap a GitLab-canonical project (C4).

        Creates the project pair under ``<owner>/`` —
        ``<project>-dev`` (private) and ``<project>`` (public) — via
        the projects API. Idempotent: probes by URL-encoded path
        first; only creates on 404. Falls back from group-namespace
        lookup to user-namespace creation when ``<owner>`` resolves
        as a user account.

        Seeds the standard label catalogue + the
        Issues-as-Discussions reserved set on the dev project (GitLab,
        like Forgejo, has no native Discussions surface).

        Skips: GitLab Issue Boards (capability-flagged Premium-tier
        feature; non-uniform across self-hosted). Project board
        seeding lands when a portable Issue-board adapter design
        replaces today's GitHub-only Project board path.
        """
        if not owner.strip():
            raise _errors.ForgeError(
                "GitLabAdapter.bootstrap_project: owner must not be empty."
            )
        if not project_name.strip():
            raise _errors.ForgeError(
                "GitLabAdapter.bootstrap_project: project_name must not be empty."
            )

        manual_steps: list[str] = []
        artifacts: dict = {}

        namespace_id = await self._resolve_namespace_id(owner)
        artifacts["namespace_id"] = namespace_id

        dev_project, dev_existed = await self._ensure_project(
            owner=owner,
            name=f"{project_name}-dev",
            visibility="private",
            description=description or f"{project_name} — private dev, design, and archive",
            namespace_id=namespace_id,
        )
        public_project, public_existed = await self._ensure_project(
            owner=owner,
            name=project_name,
            visibility="public",
            description=description or f"{project_name} — public mirror",
            namespace_id=namespace_id,
        )
        artifacts["dev_project"] = {
            "full_name": f"{owner}/{project_name}-dev",
            "id": dev_project.get("id"),
            "web_url": dev_project.get("web_url", ""),
            "existed": dev_existed,
        }
        artifacts["public_project"] = {
            "full_name": f"{owner}/{project_name}",
            "id": public_project.get("id"),
            "web_url": public_project.get("web_url", ""),
            "existed": public_existed,
        }

        labels_seeded: list[str] = []
        catalogue = _GITLAB_STANDARD_LABELS + _GITLAB_DISCUSSION_LABELS
        for label_name, color, label_desc in catalogue:
            await self.ensure_label(
                owner=owner, repo=f"{project_name}-dev",
                name=label_name, color=color, description=label_desc,
            )
            labels_seeded.append(label_name)
        artifacts["labels_seeded"] = labels_seeded

        return BootstrapResult(
            platform_id=self.platform_id,
            artifacts=artifacts,
            manual_steps=manual_steps,
            phase="complete" if not manual_steps else "awaiting_manual",
        )

    async def _resolve_namespace_id(self, owner: str) -> int | None:
        """Look up the GitLab namespace ID for ``owner`` by name.

        GitLab requires ``namespace_id`` on POST /projects to place
        the project under a group. Probes /namespaces?search=<owner>;
        returns the first exact-name match, or None when no match
        (in which case the create path falls through to the
        authenticated user's default namespace).
        """
        results = await self._request(
            "GET", "/namespaces", params={"search": owner},
        )
        if not isinstance(results, list):
            return None
        for ns in results:
            if ns.get("path") == owner or ns.get("name") == owner:
                return ns.get("id")
        return None

    async def _ensure_project(
        self,
        *,
        owner: str,
        name: str,
        visibility: str,
        description: str,
        namespace_id: int | None,
    ) -> tuple[dict, bool]:
        """Idempotent project creation. Returns (project, existed).

        Probe via ``GET /projects/<owner>%2F<name>`` — 200 means it
        exists, 404 means create. POST /projects with ``namespace_id``
        when the owner resolves as a group; without ``namespace_id``
        the project lands under the authenticated user (fallback
        when /namespaces?search misses).
        """
        existing = await self._request(
            "GET", f"/projects/{_project_path(owner, name)}",
            allow_404_as_none=True,
        )
        if existing is not None:
            return existing, True

        payload: dict = {
            "name": name,
            "path": name,
            "visibility": visibility,
            "description": description,
            "initialize_with_readme": True,
            "default_branch": "main",
        }
        if namespace_id is not None:
            payload["namespace_id"] = namespace_id
        created = await self._request("POST", "/projects", json=payload)
        return created, False

    # =====================================================================
    # Project board sub-Protocol (forgejo #10 / 3.4.0) — NotImplementedError
    # =====================================================================
    #
    # GitLab has Iterations + Boards but the Issue-attach surface is
    # in the GraphQL Beta. Until that lands the four methods below
    # raise NotImplementedError. Callers gate on
    # ``has_project_boards = False`` and skip dispatch.

    async def add_to_project_board(
        self, *, board_id: str, ref,
    ) -> str:
        raise NotImplementedError(
            "GitLabAdapter.add_to_project_board: GitLab Boards have "
            "an Issue-attach surface in the GraphQL Beta "
            "(IssuableAddListIssue mutation). When that promotes to "
            "stable + ships REST counterparts, this method will "
            "delegate. Until then callers gate on "
            "has_project_boards=False."
        )

    async def get_project_status_field(
        self, *, board_id: str,
    ) -> dict:
        raise NotImplementedError(
            "GitLabAdapter.get_project_status_field: GitLab Boards "
            "model status as label-based lists rather than a typed "
            "field; the abstraction doesn't map cleanly to the "
            "GitHub Projects v2 status_field_id model. Pending design."
        )

    async def get_project_item_id(
        self, *, ref, board_id: str,
    ) -> str:
        raise NotImplementedError(
            "GitLabAdapter.get_project_item_id: same blocker as "
            "add_to_project_board — Issue-attach is GraphQL Beta."
        )

    async def move_project_item(
        self, *, board_id: str, item_id: str,
        status_field_id: str, option_id: str,
    ) -> None:
        raise NotImplementedError(
            "GitLabAdapter.move_project_item: column-move would map "
            "to label-based reassignment via PUT on the issue. "
            "Pending design alignment with the typed status-field "
            "model GitHubAdapter exposes."
        )

    async def fetch_remote_changes(
        self, *, since: datetime, owner: str, repo: str,
    ) -> list[RemoteChange]:
        """Paginated REST scan of issues + notes updated since ``since`` (#279).

        GitLab's pagination is per_page-based with explicit page=N
        cursor; the response carries ``X-Next-Page`` / ``X-Total``
        headers but the underlying httpx-based ``_request`` strips
        headers, so we walk by page number until the response is
        empty (works because GitLab returns an empty array when the
        page exceeds total).

        Operation detection mirrors Forgejo's smallest-unblock:

        * ``created_at >= since`` → ``create_issue``
        * ``state == "closed"`` and ``closed_at >= since`` → ``close_issue``
        * Otherwise → ``update_body``

        Notes (GitLab's term for comments) come from the project-
        scoped note feed when available; we walk per-issue
        ``notes`` because GitLab has no project-wide notes endpoint
        for issue comments.
        """
        changes: list[RemoteChange] = []
        since_iso = since.astimezone(timezone.utc).isoformat()
        project_path = _project_path(owner, repo)
        try:
            issues = await self._paginate_get(
                f"/projects/{project_path}/issues",
                params={
                    "updated_after": since_iso,
                    "state": "all",
                    "scope": "all",
                },
            )
        except _errors.ForgeUnavailableError as exc:
            return [_rate_limited_sentinel(self.platform_id, str(exc))]

        for item in issues:
            issue = _issue_from_api(
                item, owner=owner, repo=repo, platform_id=self.platform_id,
            )
            created_at = _parse_iso(item.get("created_at"))
            closed_at = _parse_iso(item.get("closed_at"))
            updated_at = _parse_iso(item.get("updated_at")) or datetime.now(timezone.utc)
            if created_at is not None and created_at >= since:
                changes.append(
                    RemoteChange(
                        source_platform_id=self.platform_id,
                        ref=issue.ref,
                        operation="create_issue",
                        observed_at=created_at,
                        payload={
                            "title": issue.title,
                            "body": issue.body,
                            "labels": list(issue.labels),
                        },
                    )
                )
                continue
            if (
                issue.state == "closed"
                and closed_at is not None
                and closed_at >= since
            ):
                changes.append(
                    RemoteChange(
                        source_platform_id=self.platform_id,
                        ref=issue.ref,
                        operation="close_issue",
                        observed_at=closed_at,
                        payload={"state_reason": "completed"},
                    )
                )
                continue
            changes.append(
                RemoteChange(
                    source_platform_id=self.platform_id,
                    ref=issue.ref,
                    operation="update_body",
                    observed_at=updated_at,
                    payload={"new_body": issue.body},
                )
            )

            # Per-issue notes (depth-1). GitLab has no project-wide
            # notes endpoint for issue comments, so we fan out per
            # touched issue. Notes returned by GitLab are sorted by
            # created_at desc by default; we filter client-side.
            try:
                notes = await self._paginate_get(
                    f"/projects/{project_path}/issues/"
                    f"{issue.ref.number}/notes",
                    params={"sort": "asc", "order_by": "updated_at"},
                )
            except _errors.ForgeUnavailableError as exc:
                changes.append(_rate_limited_sentinel(self.platform_id, str(exc)))
                return changes
            for n in notes:
                if n.get("system"):
                    continue  # skip GitLab system notes (close/label markers)
                note_updated = _parse_iso(n.get("updated_at"))
                if note_updated is None or note_updated < since:
                    continue
                comment = _comment_from_api(
                    n, parent=issue.ref, platform_id=self.platform_id,
                )
                changes.append(
                    RemoteChange(
                        source_platform_id=self.platform_id,
                        ref=comment.ref,
                        operation="add_comment",
                        observed_at=note_updated,
                        payload={
                            "parent_number": issue.ref.number,
                            "body": n.get("body", "") or "",
                            "author": comment.author,
                        },
                    )
                )

        return changes


# ---------------------------------------------------------------------------
# Internal: API-dict-to-canonical-type shapers
# ---------------------------------------------------------------------------

def _make_ref(
    *,
    platform_id: str,
    native_id: str,
    kind: str,
    owner: str,
    repo: str,
    number: int | None = None,
) -> ArtifactRef:
    return ArtifactRef(
        platform_id=platform_id,
        native_id=native_id,
        kind=kind,  # type: ignore[arg-type]
        owner=owner,
        repo=repo,
        number=number,
    )


def _issue_from_api(
    d: dict,
    *,
    owner: str,
    repo: str,
    platform_id: str,
) -> Issue:
    """Shape a GitLab /issues/* response into the canonical Issue type.

    Note GitLab uses ``iid`` (project-internal id) for the user-facing
    issue number; ``id`` is the global database row id and goes into
    ``ref.native_id``.
    """
    author = d.get("author") or {}
    # GitLab state is 'opened' / 'closed' (not 'open').
    state_raw = (d.get("state") or "opened").lower()
    state: str = "closed" if state_raw == "closed" else "open"
    return Issue(
        ref=_make_ref(
            platform_id=platform_id,
            native_id=str(d.get("id", "")),
            kind="issue",
            owner=owner,
            repo=repo,
            number=d.get("iid"),
        ),
        title=d.get("title", "") or "",
        body=d.get("description", "") or "",
        state=state,  # type: ignore[arg-type]
        labels=[n for n in _label_names_from_api(d) if n],
        milestone=_milestone_title_from_api(d),
        author=author.get("username", "") or "",
        created_at=_parse_iso(d.get("created_at")),
        updated_at=_parse_iso(d.get("updated_at")),
        url=d.get("web_url", "") or "",
    )


def _discussion_from_issue(issue: Issue, *, category: str | None) -> Discussion:
    new_ref = ArtifactRef(
        platform_id=issue.ref.platform_id,
        native_id=issue.ref.native_id,
        kind="discussion",
        owner=issue.ref.owner,
        repo=issue.ref.repo,
        number=issue.ref.number,
    )
    decided = "decided" in issue.labels
    return Discussion(
        ref=new_ref,
        title=issue.title,
        body=issue.body,
        state=issue.state,
        category=category,
        labels=issue.labels,
        decided=decided,
        author=issue.author,
        created_at=issue.created_at,
        url=issue.url,
    )


def _comment_from_api(
    d: dict, *, parent: ArtifactRef, platform_id: str,
) -> Comment:
    author = d.get("author") or {}
    created = _parse_iso(d.get("created_at")) or datetime.now(timezone.utc)
    return Comment(
        ref=_make_ref(
            platform_id=platform_id,
            native_id=str(d.get("id", "")),
            kind="comment",
            owner=parent.owner,
            repo=parent.repo,
        ),
        body=d.get("body", "") or "",
        author=author.get("username", "") or "",
        created_at=created,
        parent=parent,
        # GitLab REST doesn't return a per-note URL; the discussion/
        # issue page anchors aren't reliable across instances. Leave
        # empty per the Comment.url contract for backends that don't
        # expose deep-linkable comment URLs.
        url="",
    )


def _milestone_from_api(d: dict) -> Milestone:
    # GitLab milestone state is 'active' / 'closed'; map to canonical
    # 'open' / 'closed'.
    state_raw = (d.get("state") or "active").lower()
    state: str = "closed" if state_raw == "closed" else "open"
    return Milestone(
        title=d.get("title", "") or "",
        number=d.get("id", 0) or 0,
        state=state,  # type: ignore[arg-type]
        description=d.get("description", "") or "",
        due_on=_parse_iso(d.get("due_date")),
    )


def _normalize_category(category: str) -> str:
    return category.lower().replace(" / ", "_").replace(" ", "_")


def _category_from_labels(labels: list[str]) -> str | None:
    for label in labels:
        if label.startswith("category:"):
            return label.split(":", 1)[1]
    return None


# ---------------------------------------------------------------------------
# fetch_remote_changes helpers (#279)
# ---------------------------------------------------------------------------


def _rate_limited_sentinel(platform_id: str, message: str) -> RemoteChange:
    """A RemoteChange that signals the fetch was truncated (#279).

    Mirrors the Forgejo sentinel; the consumer (#294 backfill step)
    detects ``operation == "rate_limited"`` and surfaces a
    manual_steps entry directing the operator at re-running with a
    tighter ``since`` watermark.
    """
    sentinel_ref = ArtifactRef(
        platform_id=platform_id,
        native_id="<rate_limited>",
        kind="issue",
        owner="<unknown>",
        repo="<unknown>",
    )
    return RemoteChange(
        source_platform_id=platform_id,
        ref=sentinel_ref,
        operation="rate_limited",
        observed_at=datetime.now(timezone.utc),
        payload={"message": message},
    )


