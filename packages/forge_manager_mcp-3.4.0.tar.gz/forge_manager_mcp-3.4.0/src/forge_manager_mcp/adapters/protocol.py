"""PlatformAdapter Protocol — the 3.0 chokepoint between handlers and backends.

Every backend (GitHub / Forgejo+Codeberg / GitLab / LocalStore) implements
this Protocol. Handlers call adapter methods uniformly; the adapter
translates to backend-native calls. Adding a new platform is a new
implementation, not a handler change.

The surface is shaped by current MCP tool primitives. Methods are async
because the existing handlers are async (for httpx + asyncio.gather
parallelism); LocalStoreAdapter is async-but-non-blocking-IO under the
hood (filesystem ops in a thread pool when needed, synchronous when not).
"""
from __future__ import annotations

import re
from typing import ClassVar, Protocol, runtime_checkable

from datetime import datetime

from .types import (
    ArtifactRef,
    BootstrapResult,
    Comment,
    Discussion,
    DriftReport,
    Issue,
    Milestone,
    RecoveryBundle,
    Release,
    RemoteChange,
    SearchResult,
    SessionEvent,
)


@runtime_checkable
class PlatformAdapter(Protocol):
    """Common interface every forge backend implements.

    ``platform_id`` is a class-level identifier used in
    ``ArtifactRef.platform_id`` and in ``forge-config.json.platforms[].id``
    so refs and config entries can be routed back to the correct adapter.

    ``from_config`` is the constructor — takes the platform-specific
    config blob from ``forge-config.json.platforms[]`` and returns
    a ready-to-use adapter instance. Adapters that need a token file
    (per Phase 2.3+) read from ``~/.<platform_id>-token`` inside
    ``from_config``; missing-token raises a clear setup error.
    """

    platform_id: ClassVar[str]
    """Stable identifier — 'github', 'codeberg', 'forgejo', 'gitlab', 'local'."""

    has_scaffold: ClassVar[bool]
    """True iff this backend implements ``bootstrap_project`` (multi-
    platform scaffold C1+). LocalStore: True from C1. GitHub: True
    from C2 (currently False — handler still uses the GitHub-tight
    scaffold path in infra.py). Forgejo: True from C3. GitLab: True
    from C4. Adapters that don't yet implement bootstrap are skipped
    by the dispatching ``scaffold_project`` handler rather than
    raising."""

    has_session_event_surface: ClassVar[bool]
    """True iff this backend implements ``record_session_event`` /
    ``read_session_events`` natively (foundation for the canonical-
    first session-lock fix from f4853e7). LocalStore: True. GitHub /
    Forgejo / GitLab: False — their session-lock surface is a
    Discussion comment thread that the handler addresses through
    ``append_comment`` / ``list_comments`` directly. Adapters with
    ``has_session_event_surface = False`` MAY raise NotImplementedError
    from the two methods; callers (open_session handler today) must
    gate dispatch on this flag rather than catching the exception."""

    has_project_boards: ClassVar[bool]
    """True iff this backend exposes a project-board surface that
    ``add_to_project_board`` / ``move_project_item`` /
    ``get_project_status_field`` / ``get_project_item_id`` can
    target (forgejo #10 / 3.4.0). GitHub: True (Projects v2).
    Forgejo / GitLab / LocalStore: False today — Forgejo has
    organization-level Projects but no Issue-attach API at v1.20;
    GitLab has Iterations + Boards but the attach-Issue surface is
    in the GraphQL Beta; LocalStore has no concept. Callers MUST
    gate dispatch on this flag rather than catching
    NotImplementedError; the helpers in
    ``server/handlers/_issue_creation.py::_attach_to_project_board_if_supported``
    walk replication adapters and pick the first one with the flag
    set."""

    @classmethod
    def from_config(cls, config: dict) -> "PlatformAdapter":
        """Construct from a forge-config.json platform entry.

        Concrete adapters may add platform-specific kwargs to ``config``
        (e.g., ``url`` for self-hosted Forgejo). Missing required keys
        or unreachable token files raise ``ForgeError`` with a clear
        message.
        """
        ...

    # -----------------------------------------------------------------------
    # Repo-level reads
    # -----------------------------------------------------------------------

    async def get_repo_node_id(self, owner: str, repo: str) -> str:
        """Resolve owner/repo to the backend's native repo identifier."""
        ...

    async def get_repo_visibility(self, owner: str, repo: str) -> str | None:
        """Return the repo's visibility — ``"PUBLIC"`` / ``"PRIVATE"`` /
        ``"INTERNAL"`` — or ``None`` if the repo doesn't exist.

        Used by the session-start repo-shape audit (#116) to evaluate
        whether each managed repo's current visibility matches the
        protocol's compliance rules. ``"INTERNAL"`` is GitHub-specific
        (org-internal); Forgejo / GitLab return ``"PUBLIC"`` /
        ``"PRIVATE"`` only. LocalStore has no real visibility concept
        and reports ``"PUBLIC"`` by convention. (PAR-3)
        """
        ...

    async def list_milestones(
        self, owner: str, repo: str, state: str = "all"
    ) -> list[Milestone]:
        """List milestones for the repo. ``state`` is 'open', 'closed', or 'all'."""
        ...

    async def find_milestone(
        self, owner: str, repo: str, name_or_number: str | int
    ) -> Milestone | None:
        """Resolve a milestone by title or number. Returns None if not found."""
        ...

    # -----------------------------------------------------------------------
    # Issue operations
    # -----------------------------------------------------------------------

    async def create_issue(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        labels: list[str],
        milestone: str | int | None = None,
    ) -> Issue:
        """Create an Issue. Labels include reserved + open-set labels."""
        ...

    async def get_issue(self, owner: str, repo: str, number: int) -> Issue:
        """Fetch a specific Issue by number."""
        ...

    async def get_issue_body(self, ref: ArtifactRef) -> str:
        """Fetch the current opening-post body of an Issue by ref.

        Used by handlers that have a node-ID input but need the
        current body for the size-guardrail check before
        ``update_issue_body``. Complement to ``get_issue(owner, repo,
        number)`` for the node-ID-only call site.
        """
        ...

    async def update_issue_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        """Replace the Issue's opening-post body. ``force`` bypasses size guardrail."""
        ...

    async def close_issue(
        self, ref: ArtifactRef, state_reason: str = "completed"
    ) -> Issue:
        """Close an Issue and return the closed canonical Issue.

        ``state_reason`` is 'completed' or 'not_planned'. The returned
        ``Issue`` carries ``state="closed"`` and an ``updated_at``
        timestamp so callers can surface a closed-at marker without
        a separate read. Callers that don't need the returned value
        can ignore it (e.g., ``await adapter.close_issue(ref)`` is
        still valid).
        """
        ...

    async def add_label(self, ref: ArtifactRef, label_name: str) -> None:
        """Add a label to an Issue or Discussion."""
        ...

    async def remove_label(self, ref: ArtifactRef, label_name: str) -> None:
        """Remove a label."""
        ...

    async def search_issues(
        self,
        *,
        owner: str,
        repo: str,
        query: str = "",
        state: str = "all",
        labels: list[str] | None = None,
        milestone: str | None = None,
        limit: int = 30,
    ) -> SearchResult:
        """Search Issues. Backend-specific syntax permitted in ``query``.

        Returns a ``SearchResult`` carrying the issue list plus the
        backend-reported ``total_count`` and the dispatched ``query``
        string echoed back. The ``results`` list is capped at ``limit``
        even when ``total_count`` exceeds it — callers can page by
        narrowing the query or raising the limit.
        """
        ...

    async def list_open_issues(
        self, *, owner: str, repo: str, limit: int = 100
    ) -> list[Issue]:
        """List open Issues. Used by recover_context."""
        ...

    # -----------------------------------------------------------------------
    # Discussion operations
    # -----------------------------------------------------------------------

    async def create_discussion(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        category: str | None = None,
    ) -> Discussion:
        """Create a Discussion. On platforms without a native Discussions
        surface (Forgejo / Codeberg / GitLab), this creates an Issue with
        ``kind:discussion`` + ``category:<name>`` labels per OQ1."""
        ...

    async def get_discussion(
        self, owner: str, repo: str, number: int
    ) -> Discussion:
        """Fetch a specific Discussion by number."""
        ...

    async def get_discussion_body(self, ref: ArtifactRef) -> str:
        """Fetch the current opening-post body of a Discussion by ref.

        Symmetric to ``get_issue_body`` — complement to
        ``get_discussion(owner, repo, number)`` for the node-ID-only
        call site. Used by handlers that need the current body for
        the size-guardrail check before ``update_discussion_body``.
        """
        ...

    async def update_discussion_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        """Replace a Discussion's opening-post body."""
        ...

    async def list_recent_discussions(
        self, *, owner: str, repo: str, since_days: int = 7
    ) -> list[Discussion]:
        """Recent Discussions, ordered most-recent first. Used by recover_context."""
        ...

    async def mark_decided(self, ref: ArtifactRef) -> None:
        """Mark a Discussion as Decided ✓. Adds ``decided`` to state per OQ1."""
        ...

    async def mark_answer(self, comment_ref: ArtifactRef) -> None:
        """Mark a *comment* as the canonical answer to its parent Q&A
        Discussion (#274 Phase C6).

        Distinct from ``mark_decided(disc_ref)``: ``mark_answer``
        operates on a comment ref (kind=='comment') and toggles the
        backend's native answer-marking surface where one exists
        (GitHub Discussions Q&A categories). Backends without a
        comment-level answer concept (Forgejo / GitLab / LocalStore)
        raise ``NotImplementedError`` — callers should fall back to
        ``mark_decided`` against the parent discussion.
        """
        ...

    # -----------------------------------------------------------------------
    # Comment operations (work on Issues + Discussions uniformly)
    # -----------------------------------------------------------------------

    async def append_comment(
        self, target: ArtifactRef, body: str
    ) -> Comment:
        """Append a comment to an Issue or Discussion. Hot path for post_turn."""
        ...

    async def list_comments(
        self,
        target: ArtifactRef,
        *,
        since_days: int | None = None,
        limit: int | None = None,
    ) -> list[Comment]:
        """List comments on an Issue or Discussion in chronological order.

        Filtering: ``since_days`` keeps only comments newer than that
        many days; ``limit`` returns the most recent N (post-since-days
        filter). Both default-None means "all comments". Used by
        ``get_thread_comments`` (#274 Phase C3) and the recording-
        protocol comment-tail probes.
        """
        ...

    # -----------------------------------------------------------------------
    # Label management
    # -----------------------------------------------------------------------

    async def ensure_label(
        self,
        *,
        owner: str,
        repo: str,
        name: str,
        color: str = "0E8A16",
        description: str = "",
    ) -> str:
        """Create label if absent; return its native ID."""
        ...

    # -----------------------------------------------------------------------
    # Release operations
    # -----------------------------------------------------------------------

    async def create_release(
        self,
        *,
        owner: str,
        repo: str,
        tag: str,
        name: str,
        body: str = "",
        prerelease: bool = False,
        draft: bool = False,
    ) -> Release:
        """Create a tagged release.

        Generalized in #282 to be the canonical adapter surface for
        the release-page step of release_project. ``prerelease`` and
        ``draft`` are best-effort across backends — GitLab doesn't
        natively expose either flag (they're encoded by convention),
        Forgejo carries both natively, GitHub carries both natively,
        LocalStore preserves them in the on-disk frontmatter.
        """
        ...

    async def delete_release(
        self,
        *,
        owner: str,
        repo: str,
        tag: str,
    ) -> None:
        """Delete a Release page on this backend (#294 Phase A primitive).

        Compensation surface for the release_notes flow step — when a
        downstream step fails after release_notes wrote a Release
        page, the chain unwinds and this method removes the page so
        the operator doesn't have to clean up manually.

        Idempotent — tolerates "release does not exist" responses
        across every backend so re-running compensation against a
        partially-cleaned state succeeds. Per-backend translation:

        * GitHubAdapter → ``gh release delete <tag> --repo <owner>/<repo> --yes``
        * ForgejoAdapter → REST DELETE
          ``/api/v1/repos/{owner}/{repo}/releases/{id}``
        * GitLabAdapter → REST DELETE
          ``/api/v4/projects/{path}/releases/{tag}``
        * LocalStoreAdapter → unlinks ``<docs>/releases/{tag}.md``
        """
        ...

    def get_clone_url(self, owner: str, repo: str) -> str:
        """Return the git clone URL for ``owner/repo`` on this backend (#282).

        Synchronous — pure string construction from configured base URL
        + owner/repo. Used by release_project's mirror_sync step (post
        #294) and by any handler that needs to invoke ``git clone`` /
        ``git remote`` against the platform.

        Backends:

        * GitHubAdapter → ``https://github.com/{owner}/{repo}.git``
        * ForgejoAdapter → ``{base_url}/{owner}/{repo}.git`` (e.g.
          ``https://codeberg.org/owner/repo.git`` or
          ``http://localhost:3000/owner/repo.git`` for self-hosted)
        * GitLabAdapter → ``{base_url}/{owner}/{repo}.git``
          (gitlab.com or self-hosted)
        * LocalStoreAdapter → ``local://{owner}/{repo}`` synthetic URL
          (no remote; the local docs path is read-only canonical)
        """
        ...

    def noreply_email(self, login: str, user_id: int | None = None) -> str:
        """Return the platform-conventional noreply email for ``login`` (#282).

        Synchronous — pure string construction. Used by
        release_project's mirror-push step to set the commit-author
        email for the squashed-mirror commit.

        Backends:

        * GitHubAdapter → ``{user_id}+{login}@users.noreply.github.com``
          when ``user_id`` is provided; falls back to
          ``{login}@users.noreply.github.com``.
        * ForgejoAdapter → ``{login}@noreply.{host}`` where ``host`` is
          derived from the configured base URL.
        * GitLabAdapter → ``{user_id}-{login}@users.noreply.{host}``
          (gitlab.com convention) or ``noreply@{host}`` for self-hosted.
        * LocalStoreAdapter → ``claude+{login}@local.invalid``.
        """
        ...

    def public_issue_url_regex(self) -> "re.Pattern[str]":
        """Return a compiled regex matching this backend's Issue URL form (#11).

        Pattern captures three groups in order: ``(owner, repo, number)``.
        Used by :func:`extract_public_mirror_urls` (consumed by
        ``close_triaged_public_issues``) to find body cross-links to
        public-mirror Issues that should be auto-closed post-release per
        multi-repo.md §Public Issue triage closure (Rule B).

        Synchronous — pure string construction from the adapter's
        configured base URL. Pre-3.3.0 the caller hardcoded
        ``https://github.com/...`` in ``github/triage.py`` regardless of
        public_face; this Protocol method dispatches per-backend.

        Backends:

        * GitHubAdapter → ``https://github.com/(owner)/(repo)/issues/(\\d+)``
        * ForgejoAdapter → ``https?://{host}/(owner)/(repo)/issues/(\\d+)``
          where ``host`` is derived from the configured base URL
          (``codeberg.org``, ``localhost:3000``, etc.).
        * GitLabAdapter → ``https?://{host}/(owner)/(repo)/issues/(\\d+)``
          (does not yet handle GitLab's nested-group URL form).
        * LocalStoreAdapter → never-matches sentinel; LocalStore has no
          public-issue URL surface so any pattern would be wrong.
        """
        ...

    # -----------------------------------------------------------------------
    # File-content reads (for check_skill_version etc.)
    # -----------------------------------------------------------------------

    async def fetch_file_content(
        self, *, owner: str, repo: str, path: str, ref: str = "main"
    ) -> str | None:
        """Fetch the content of a file at a ref. Returns None if not found."""
        ...

    # -----------------------------------------------------------------------
    # Bundled reads (Phase C5)
    # -----------------------------------------------------------------------

    async def bundle_recover_context(
        self,
        *,
        owner: str,
        repo: str,
        toc_discussion_id: str,
        since_days: int = 7,
        issue_limit: int = 100,
    ) -> RecoveryBundle:
        """Fetch every artifact ``recover_context`` needs in one call.

        Backends with native batching (GitHub's GraphQL aliased
        multi-query) override this for one-round-trip perf. Backends
        without batching can delegate to
        ``forge_manager_mcp.adapters._recovery.default_bundle_recover_context``
        which sequentially calls the existing ``list_open_issues`` /
        ``list_recent_discussions`` / ``list_milestones`` /
        ``get_discussion_body`` Protocol methods.
        """
        ...

    # -----------------------------------------------------------------------
    # Health + drift (Phase 6)
    # -----------------------------------------------------------------------

    async def probe(self) -> bool:
        """Cheap reachability check. Returns True if the backend
        responded successfully; False on classified-unavailable error.
        Phase 6 uses this to drive the per-adapter state machine."""
        ...

    async def compute_drift(self, snapshot: dict) -> DriftReport:
        """Compare ``snapshot`` (canonical local state) against the
        backend's actual state. Phase 6 deliverable; adapters in Phase
        2 may stub this with an empty DriftReport."""
        ...

    # -----------------------------------------------------------------------
    # Session-lock canonical surface (f4853e7 follow-on)
    # -----------------------------------------------------------------------

    async def record_session_event(
        self,
        *,
        session_id: str,
        event: str,
        body: str = "",
    ) -> SessionEvent:
        """Persist one session-lifecycle event (opened / closed /
        heartbeat) to the canonical store.

        ``has_session_event_surface = True`` adapters MUST implement
        this; ``False`` adapters MAY raise ``NotImplementedError`` —
        callers gate on the capability flag, not exception-catching.
        Backends without a native session-lock surface (GitHub /
        Forgejo / GitLab today) write session events as Discussion
        comments via ``append_comment`` instead, addressed by the
        handler not the Protocol.
        """
        ...

    async def read_session_events(
        self,
        *,
        last_n: int | None = None,
    ) -> list[SessionEvent]:
        """Return session events oldest-first; optionally clip to the
        most recent ``last_n``. Used for ``prior_session_clean``
        detection from the canonical store. Same capability-flag
        semantics as ``record_session_event``."""
        ...

    # -----------------------------------------------------------------------
    # Bootstrap (multi-platform scaffold C1+)
    # -----------------------------------------------------------------------

    async def bootstrap_project(
        self,
        *,
        owner: str,
        project_name: str,
        description: str,
        existing_state: dict | None = None,
    ) -> BootstrapResult:
        """Create the per-backend artifacts a new managed project needs.

        Idempotent — re-running against an existing project no-ops on
        artifacts that already exist; the adapter inspects live state
        first.

        ``existing_state`` carries the artifacts created by previously-
        run adapters in the same ``scaffold_project`` invocation, keyed
        by platform_id. Adapters can use this to cross-link (e.g., a
        GitHub bootstrap step that references the LocalStore canonical
        path, or a Forgejo step that mirrors a GitHub repo's labels).

        Adapters with ``has_scaffold = False`` aren't required to
        implement this method — the dispatching handler skips them.
        Adapters with ``has_scaffold = True`` MUST return a
        ``BootstrapResult`` whose ``platform_id`` matches their own.

        ``manual_steps`` carries operator-pick gaps the adapter couldn't
        automate (GitHub Discussion categories — no API). When non-empty,
        ``phase`` is ``"awaiting_manual"`` and the operator re-runs the
        bootstrap after completing the steps.
        """
        ...

    # =====================================================================
    # Project board sub-Protocol (forgejo #10 / 3.4.0)
    # =====================================================================
    #
    # Capability-flagged via ``has_project_boards``. Today only
    # GitHubAdapter implements them live; Forgejo / GitLab / LocalStore
    # raise NotImplementedError with a smallest-unblock message. The
    # ``_attach_to_project_board_if_supported`` helper in the
    # _issue_creation handler walks replication adapters and picks the
    # first one with ``has_project_boards = True``; if none support,
    # the project-item attach is silently skipped (project_item_id ==
    # "" in the response).

    async def add_to_project_board(
        self, *, board_id: str, ref: ArtifactRef,
    ) -> str:
        """Add an Issue to the project board (e.g. GitHub Projects v2
        default Backlog column). Returns the backend-native project
        item ID.

        Adapters with ``has_project_boards = False`` raise
        ``NotImplementedError`` with a smallest-unblock message
        naming the missing API. Callers must gate on the capability
        flag rather than catching the exception.
        """
        ...

    async def get_project_status_field(
        self, *, board_id: str,
    ) -> dict:
        """Return the board's Status field metadata as
        ``{"field_id": str, "options": {<column-name>: <option-id>, ...}}``.

        Used by ``move_project_item`` when the project's
        ``forge-config.json`` doesn't pre-cache the status_field_id /
        status_options. Adapters with ``has_project_boards = False``
        raise ``NotImplementedError``.
        """
        ...

    async def get_project_item_id(
        self, *, ref: ArtifactRef, board_id: str,
    ) -> str:
        """Resolve an Issue's project-item ID on the board (the
        per-board ID, distinct from the Issue's repo-level ID).
        Adapters with ``has_project_boards = False`` raise
        ``NotImplementedError``.
        """
        ...

    async def move_project_item(
        self, *, board_id: str, item_id: str,
        status_field_id: str, option_id: str,
    ) -> None:
        """Move a project item to a different Status column. Adapters
        with ``has_project_boards = False`` raise
        ``NotImplementedError``.
        """
        ...

    async def fetch_remote_changes(
        self, *, since: datetime, owner: str, repo: str,
    ) -> list[RemoteChange]:
        """Return changes the backend has observed since ``since``
        (#274 Phase D foundation for OQ4 import_remote_changes).

        Each entry is the per-mutation record needed by
        ``LocalStoreAdapter.apply_remote_change``. Foundation only —
        adapters that don't yet implement this raise
        ``NotImplementedError`` with a message naming the smallest
        unblocking change.

        Implementations target backend-native change-feeds:
          * GitHub: GraphQL ``Repository.issues(orderBy: UPDATED_AT)``
            + ``Repository.discussions(orderBy: UPDATED_AT)`` filtered
            by updatedAt >= since.
          * Forgejo / GitLab: REST ``/issues?since=<iso>``.
          * LocalStore: returns its own history as RemoteChange (used
            in tests; not meaningful as a "remote" change source in
            production).
        """
        ...
