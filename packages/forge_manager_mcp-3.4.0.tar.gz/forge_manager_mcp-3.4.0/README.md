# claude-skills-mcp-dev

Private dev repo for the
[`active-claude-github`](https://codeberg.org/telejester-skills/telejester-claude-skills)
Claude Code skill's MCP server. Consumer docs live at the publish
target: <https://codeberg.org/telejester-skills/telejester-claude-skills>.

This repo is where MCP server development happens — Issues,
Discussions, CI, Bazel build graph, tests. Releases are published to
the publish-target repo linked above.

## What lives here

- **Python package** `active_claude_github_mcp/` implementing the MCP
  tool surface.
- **`tests/`** — Bazel-orchestrated unit and integration tests in two
  layers: helper-level (#79, ephemeral repos) and tool-level (#89,
  persistent fixture repo at `telejester-test-org/integration-fixture`).
  See [`CONTRIBUTING.md`](CONTRIBUTING.md) for the build and test
  conventions and §Persistent fixture repo for the provisioning
  protocol.
- **`.github/workflows/`** — CI (`bazel test` + `bazel coverage` on
  every PR; `workflow_dispatch` live-GitHub integration tests).
- **Issues / Discussions / Project board** cross-referenced with the
  skill dev repo at
  <https://github.com/orgs/telejester-claude-skills/projects/1>.

## Bootstrapping a new project

`scaffold_project` is the MCP tool that stands up a new managed project
end-to-end: creates the `<org>/<name>` public + `<org>/<name>-dev`
private repo pair, seeds the standard label set, enables Discussions on
the dev repo, creates a ProjectV2 board (linked to both repos) with the
canonical `Backlog → In Progress → In Review → Done / Parked` Status
field, seeds the Project and Session-Lock Discussions, and writes
`.claude/github-config.json` with every resolved ID.

The tool is idempotent and pauses for exactly one manual step: creating
the five Discussion categories (`Project`, `Architecture`, `UX / UI`,
`Ideas`, `claude-use-only`) via the dev-repo's Settings page, which
GitHub exposes no API for. Re-run the tool once the categories exist
and it picks up where it left off.

The exact bootstrap flow — invocation, expected pauses, and follow-up
`open_session` — lives in the consumer skill's §Self-Bootstrap
Instructions: <https://codeberg.org/telejester-skills/telejester-claude-skills>.

## Multi-repo relations (1.3.0+)

`github-config.json` accepts a `related_repos` list that tags each
connected repo with one of six relationship types. The server uses
these tags at dispatch time to gate cross-repo mutations per the
skill's §Cross-repo work protocol:

| Type | Gate |
|---|---|
| `subsystem`, `publish_target`, `sibling`, `neighbor` | Allowed |
| `cousin` (different org, skill-managed) | **Blocked — requires explicit user permission per operation** |
| `foreign` (no write access) | **Blocked — treat as informational only** |

Blocks surface as a non-buffered `OperationError` with `manual_step`
populated; no GitHub calls are issued. Unknown targets (not declared
in `related_repos`) pass through — the preflight doesn't invent
policy for undeclared repos.

The pre-1.3.0 `contribution_target` type still parses for backward
compat but emits a `DeprecationWarning` at load. Migrate each entry
to its precise sub-type at next config edit.

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md).

## Related repos

- MCP server publish target (consumer-facing):
  <https://codeberg.org/telejester-skills/telejester-claude-skills>
- Skill (consumer-facing):
  <https://codeberg.org/telejester-skills/telejester-claude-skills>
- Skill dev repo:
  <https://codeberg.org/telejester-skills/telejester-claude-skills-dev>

## License

[Apache License 2.0](LICENSE) — © 2026 Telejester.
