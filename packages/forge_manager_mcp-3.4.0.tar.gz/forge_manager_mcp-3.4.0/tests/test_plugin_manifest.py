"""Plugin manifest validity test (forgejo #14 / 3.3.0 Phase 4).

Asserts `.claude-plugin/plugin.json` is well-formed and consistent with
the rest of the project — required fields present, name is kebab-case,
version is semver and matches the MCP package version (semver coupling
since 2.0), `skills` path resolves to a directory containing at least
one `<name>/SKILL.md`, and URL fields parse as URLs.

The test runs against the source-tree manifest staged via the
`claude-plugin-mirror` symlink at the Bazel workspace root (mirrors the
themes/ symlink pattern from #2's test_site_renderer_hugo). When the
symlink can't be resolved (manifest absent / dropped), the test skips
with a structured reason rather than failing the suite — keeps
mid-migration projects green.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from urllib.parse import urlparse

import pytest

# Locate plugin.json + pyproject.toml. Bazel test sandbox stages the
# `data` attribute files alongside the test source under the test
# package. The symlinks tests/plugin.json + tests/pyproject.toml
# resolve to the real .claude-plugin/plugin.json + mcp-server/
# pyproject.toml at the workspace root — the symlink content gets
# materialized into the runfiles tree.
_HERE = Path(__file__).resolve().parent
_MANIFEST_CANDIDATES = (
    _HERE / "plugin.json",                              # Bazel sandbox + symlink
    _HERE.parent.parent / ".claude-plugin" / "plugin.json",  # source-tree fallback
)
_PYPROJECT_CANDIDATES = (
    _HERE / "pyproject.toml",                           # Bazel sandbox + symlink
    _HERE.parent / "pyproject.toml",                    # source-tree fallback
)


def _load_manifest() -> dict:
    for candidate in _MANIFEST_CANDIDATES:
        if candidate.is_file():
            return json.loads(candidate.read_text(encoding="utf-8"))
    pytest.skip(
        f"plugin.json not found at any of: "
        f"{[str(c) for c in _MANIFEST_CANDIDATES]}"
    )


def _load_pyproject_version() -> str:
    """Read [project].version from mcp-server/pyproject.toml.

    Stdlib-only — uses regex over tomllib (which only ships in 3.11+
    and would still need the file to be staged as Bazel data). Pattern
    matches a single-line `version = "X.Y.Z"` declaration.
    """
    for candidate in _PYPROJECT_CANDIDATES:
        if candidate.is_file():
            text = candidate.read_text(encoding="utf-8")
            match = re.search(
                r'^version\s*=\s*[\'"]([^\'"]+)[\'"]',
                text, re.MULTILINE,
            )
            if match:
                return match.group(1)
    pytest.skip(
        f"pyproject.toml not found / no version line at any of: "
        f"{[str(c) for c in _PYPROJECT_CANDIDATES]}"
    )


_NAME_PATTERN = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")
# semver MAJOR.MINOR.PATCH, optional PEP 440 pre-release suffix
# (a/b/rc) so 3.3.0a1 / 3.3.0rc1 / 3.3.0 all parse.
_VERSION_PATTERN = re.compile(r"^\d+\.\d+\.\d+(?:[ab]\d+|rc\d+)?$")


class TestPluginManifestRequiredFields:
    """Schema-required fields per claude-code-guide reference 2026-05-02."""

    def test_manifest_parses_as_json(self):
        manifest = _load_manifest()
        assert isinstance(manifest, dict)

    def test_required_name_present(self):
        manifest = _load_manifest()
        assert "name" in manifest
        assert isinstance(manifest["name"], str)
        assert manifest["name"], "name must be non-empty"

    def test_name_is_kebab_case(self):
        manifest = _load_manifest()
        name = manifest["name"]
        assert _NAME_PATTERN.match(name), (
            f"name {name!r} not kebab-case (lowercase + hyphens, must "
            f"start with a letter)"
        )

    def test_version_present_and_semver(self):
        manifest = _load_manifest()
        version = manifest.get("version")
        assert version, "version field required (or git SHA fallback per docs)"
        assert _VERSION_PATTERN.match(version), (
            f"version {version!r} not semver shape (X.Y.Z optionally "
            f"followed by aN / bN / rcN PEP-440 pre-release suffix)"
        )

    def test_description_present_and_non_empty(self):
        manifest = _load_manifest()
        assert manifest.get("description"), "description should not be empty"


class TestPluginManifestVersionCoupling:
    """Skill protocol semver and MCP package semver are coupled since 2.0
    (RFC #132 D5). Plugin manifest version joins the same coupling from
    3.3.0 onward — all three must move together at release."""

    def test_plugin_version_matches_pyproject(self):
        manifest = _load_manifest()
        manifest_version = manifest.get("version")
        pyproject_version = _load_pyproject_version()
        # During pre-release iteration the manifest may target the next
        # version while pyproject still carries the current. Allow that
        # only when manifest is strictly newer; otherwise must match.
        if manifest_version != pyproject_version:
            pytest.fail(
                f"plugin.json version {manifest_version!r} doesn't match "
                f"pyproject.toml version {pyproject_version!r}. Coupled "
                f"semver — both must be bumped together at release "
                f"(or both pre-bumped to the next target during "
                f"pre-release iteration)."
            )


class TestPluginManifestSkillsResolution:
    """The `skills` field overrides the default `skills/` discovery path
    (per claude-code-guide). Must resolve to a real directory containing
    at least one `<name>/SKILL.md`."""

    def test_skills_path_resolves(self):
        manifest = _load_manifest()
        skills_field = manifest.get("skills", "./skills")
        # Resolve relative to the source-tree plugin root only — the
        # Bazel sandbox doesn't stage skill files (they're not test
        # data). Skip in sandbox; rely on source-tree run for this AC.
        source_root = _HERE.parent.parent / ".claude-plugin"
        if not source_root.is_dir():
            pytest.skip(
                "source-tree .claude-plugin/ not reachable in sandbox; "
                "skill resolution checked via source-tree pytest run"
            )
        plugin_root = source_root.parent
        skills_path = (plugin_root / skills_field).resolve()
        assert skills_path.is_dir(), (
            f"skills field {skills_field!r} resolved to "
            f"{skills_path!r} which is not an existing directory"
        )

    def test_skills_dir_contains_a_skill(self):
        """At least one subdirectory containing a SKILL.md."""
        manifest = _load_manifest()
        skills_field = manifest.get("skills", "./skills")
        source_root = _HERE.parent.parent / ".claude-plugin"
        if not source_root.is_dir():
            pytest.skip("source-tree .claude-plugin/ not reachable in sandbox")
        plugin_root = source_root.parent
        skills_path = (plugin_root / skills_field).resolve()
        if not skills_path.is_dir():
            pytest.fail(f"skills path missing: {skills_path}")
        skill_files = list(skills_path.glob("*/SKILL.md"))
        assert skill_files, (
            f"no <name>/SKILL.md under {skills_path} — plugin "
            f"would auto-discover 0 skills"
        )


class TestPluginManifestUrls:
    """URL fields, when present, must parse as URLs with a scheme + host."""

    @pytest.mark.parametrize("field", ["homepage", "repository"])
    def test_url_field_well_formed(self, field):
        manifest = _load_manifest()
        url = manifest.get(field)
        if url is None:
            pytest.skip(f"{field} not set in manifest")
        parsed = urlparse(url)
        assert parsed.scheme in ("http", "https"), (
            f"{field}={url!r} has no http/https scheme"
        )
        assert parsed.netloc, f"{field}={url!r} has no host"


# ---------------------------------------------------------------------------
# .mcp.json shape sanity (forgejo #15 automatable subset)
# ---------------------------------------------------------------------------

_MCP_JSON_CANDIDATES = (
    _HERE / "mcp.json",                          # Bazel sandbox + symlink
    _HERE.parent.parent / ".mcp.json",           # source-tree fallback
)


def _load_mcp_json() -> dict:
    for candidate in _MCP_JSON_CANDIDATES:
        if candidate.is_file():
            return json.loads(candidate.read_text(encoding="utf-8"))
    pytest.skip(
        f".mcp.json not found at any of: "
        f"{[str(c) for c in _MCP_JSON_CANDIDATES]}"
    )


class TestMcpJsonShape:
    """forgejo #15 (automatable subset) — static shape check on the
    plugin-shipped `.mcp.json` at the repo root. Live auto-merge
    behavior on `/plugin install` requires a Claude Code session and
    is operator-driven (#15 main body). What we CAN assert deterministically
    is that the shape Claude Code's plugin layer will merge is correct."""

    def test_mcp_json_parses(self):
        cfg = _load_mcp_json()
        assert isinstance(cfg, dict)

    def test_mcp_servers_block_present(self):
        cfg = _load_mcp_json()
        assert "mcpServers" in cfg
        assert isinstance(cfg["mcpServers"], dict)

    def test_forge_manager_server_declared(self):
        cfg = _load_mcp_json()
        servers = cfg["mcpServers"]
        assert "forge-manager" in servers, (
            f"mcpServers must declare 'forge-manager'; got keys "
            f"{list(servers.keys())!r}"
        )

    def test_command_uses_path_form_not_absolute(self):
        """The bare `command: \"forge-manager-mcp\"` form (PATH-resolved)
        is the canonical 3.0+ shape per the bootstrap.md §5h prose. An
        absolute path here would force consumers to edit the bundled
        .mcp.json by hand on every install — defeats the plugin auto-
        wiring purpose."""
        cfg = _load_mcp_json()
        cmd = cfg["mcpServers"]["forge-manager"]["command"]
        assert cmd == "forge-manager-mcp", (
            f"command should be bare 'forge-manager-mcp' (PATH-resolved); "
            f"got {cmd!r}. Absolute paths force per-install hand-edit."
        )

    def test_anthropic_api_key_referenced_via_env_var(self):
        """ANTHROPIC_API_KEY must come from the parent shell — Claude
        Code doesn't forward its internal key to MCP subprocesses
        (per bootstrap.md §5h). Hardcoded keys here would leak into
        every plugin-install consumer's .mcp.json."""
        cfg = _load_mcp_json()
        env = cfg["mcpServers"]["forge-manager"].get("env", {})
        api_key_ref = env.get("ANTHROPIC_API_KEY")
        assert api_key_ref == "${ANTHROPIC_API_KEY}", (
            f"ANTHROPIC_API_KEY env entry must reference "
            f"${{ANTHROPIC_API_KEY}} (parent shell var); got "
            f"{api_key_ref!r}"
        )


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
