"""Unit tests for HugoRenderer construction (forgejo #2).

Covers the gap surfaced by 3.3.0 Phase 1 dogfood: pre-#2 no test ever
constructed ``HugoRenderer()`` with no arguments, so the runtime
resolution path that production code (``build_server`` →
``_build_site_rebuilder``) actually takes was untested. That gap let
the wheel-vs-source layout drift in #1 ship undetected.

These tests run under Bazel against the source-tree path that the
`themes/` symlink + ``data = glob(["themes/forge-manager-default/**"])``
on ``:site_renderer_hugo`` exposes. The same tests run against a
pipx-installed wheel via the new gate from #3 (``installed_wheel_smoke_test``).
"""
from __future__ import annotations

from pathlib import Path

import pytest

from forge_manager_mcp.site_renderer.hugo import HugoRenderer, _theme_root


class TestThemeRootResolver:
    """Bundled-theme path discovery — the resolver hit by no-arg construction."""

    def test_returns_existing_directory(self):
        path = _theme_root()
        assert path.is_dir(), (
            f"_theme_root() returned {path!r}, which is not an existing dir"
        )

    def test_resolved_dir_contains_expected_theme_subtree(self):
        """Sanity — the resolved dir actually IS the forge-manager theme,
        not some unrelated dir that happens to live at the right path."""
        path = _theme_root()
        assert (path / "theme.toml").is_file(), (
            f"theme.toml missing from {path}"
        )
        assert (path / "layouts").is_dir(), f"layouts/ missing from {path}"
        assert (path / "static").is_dir(), f"static/ missing from {path}"

    def test_raises_filenotfounderror_when_theme_dir_absent(self, monkeypatch):
        """Degenerate path — if the theme dir is somehow missing (e.g.,
        a future packaging regression of #1), the error message points
        at the wheel-bundling concern rather than failing silently."""
        import forge_manager_mcp.site_renderer.hugo as _hugo

        # Monkeypatch __file__ to a location whose parent has no themes/
        # subdirectory, forcing the resolver into its raise branch.
        monkeypatch.setattr(_hugo, "__file__", "/tmp/nonexistent/hugo.py")
        with pytest.raises(FileNotFoundError, match="theme directory not found"):
            _hugo._theme_root()


class TestHugoRendererNoArgConstruction:
    """The crash path from #1 — production builds construct without
    overriding ``theme_dir``, exercising ``_theme_root()`` on the install
    layout. Pre-#2, no test ever did this."""

    def test_no_arg_construction_succeeds(self):
        renderer = HugoRenderer()
        assert renderer is not None

    def test_no_arg_construction_resolves_theme_dir_to_real_path(self):
        renderer = HugoRenderer()
        assert isinstance(renderer._theme_dir, Path)
        assert renderer._theme_dir.is_dir(), (
            f"HugoRenderer()._theme_dir = {renderer._theme_dir!r}, "
            "which is not an existing dir — wheel/install-layout drift?"
        )

    def test_explicit_theme_dir_override_still_works(self, tmp_path):
        """Regression guard — the no-arg path is the one #1 broke, but the
        explicit override path that the existing test suite already
        exercises must keep working."""
        custom = tmp_path / "custom-theme"
        custom.mkdir()
        renderer = HugoRenderer(theme_dir=custom)
        assert renderer._theme_dir == custom


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
