"""Unit tests for forge_manager_mcp.gate_registry (#287).

Covers:

* Pydantic model construction + dot-namespace validator.
* Constrained-shape YAML parser — happy path, scalars, inline lists,
  block scalars, nested sequences (steps).
* Loader behavior — file-not-found, schema violation, duplicate name.
* Registry accessors — get_gate / list_gates(type=) / containment.
* The same shape coverage on processes.yaml.
"""
from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from forge_manager_mcp.gate_registry import (
    Gate,
    GateRegistry,
    GateRegistryError,
    Process,
    ProcessRegistry,
    ProcessStep,
    load_gates,
    load_processes,
    parse_yaml_text,
)


# ---------------------------------------------------------------------------
# Pydantic model tests
# ---------------------------------------------------------------------------

class TestGateModel:
    def test_minimal_gate_constructs(self) -> None:
        gate = Gate(
            name="commit.example",
            type="pre-commit",
            location="commit-rules.md#commit.example",
            summary="example",
            default_state="open",
            extension_semantics="tighten",
            override_semantics="replace",
            state_change_semantics="open_close",
            rationale_doc="commit-rules.md#commit.example",
            introduced_in="1.0.0",
        )
        assert gate.name == "commit.example"
        assert gate.related == ()
        assert gate.notes is None

    def test_dot_namespace_required(self) -> None:
        with pytest.raises(Exception):
            Gate(
                name="missingdot",
                type="pre-commit",
                location="x.md#x",
                summary="x",
                default_state="open",
                extension_semantics="tighten",
                override_semantics="replace",
                state_change_semantics="open_close",
                rationale_doc="x.md#x",
                introduced_in="1.0.0",
            )

    def test_extra_field_forbidden(self) -> None:
        with pytest.raises(Exception):
            Gate(
                name="commit.x",
                type="pre-commit",
                location="x.md#x",
                summary="x",
                default_state="open",
                extension_semantics="tighten",
                override_semantics="replace",
                state_change_semantics="open_close",
                rationale_doc="x.md#x",
                introduced_in="1.0.0",
                bogus_extra="nope",
            )

    def test_pre_publish_gate_requires_runbook_url(self) -> None:
        """3.4.0 #3: pre-publish gates are operator-driven and must
        reference a runbook in the docs repo. The model rejects a
        pre-publish gate without runbook_url."""
        with pytest.raises(Exception):
            Gate(
                name="publish.example",
                type="pre-publish",
                location="release.md#publish.example",
                summary="x",
                default_state="open",
                extension_semantics="tighten",
                override_semantics="replace",
                state_change_semantics="open_close",
                rationale_doc="release.md#publish.example",
                introduced_in="3.4.0",
            )

    def test_pre_publish_gate_with_runbook_url_constructs(self) -> None:
        gate = Gate(
            name="publish.example",
            type="pre-publish",
            location="release.md#publish.example",
            summary="x",
            default_state="open",
            extension_semantics="tighten",
            override_semantics="replace",
            state_change_semantics="open_close",
            rationale_doc="release.md#publish.example",
            introduced_in="3.4.0",
            runbook_url="runbooks/publish-example.md",
        )
        assert gate.runbook_url == "runbooks/publish-example.md"

    def test_non_pre_publish_gate_rejects_runbook_url(self) -> None:
        """runbook_url is only meaningful for pre-publish gates. A
        pre-tag or pre-commit gate with runbook_url is a misuse."""
        with pytest.raises(Exception):
            Gate(
                name="commit.example",
                type="pre-commit",
                location="x.md#x",
                summary="x",
                default_state="open",
                extension_semantics="tighten",
                override_semantics="replace",
                state_change_semantics="open_close",
                rationale_doc="x.md#x",
                introduced_in="1.0.0",
                runbook_url="runbooks/x.md",
            )


class TestProcessModel:
    def test_minimal_process(self) -> None:
        proc = Process(
            name="session.start",
            type="lifecycle",
            location="bootstrap.md#session.start",
            summary="bootstrap",
            rationale_doc="bootstrap.md#session.start",
            introduced_in="1.0.0",
        )
        assert proc.steps == ()
        assert proc.related_processes == ()

    def test_steps_construct(self) -> None:
        proc = Process(
            name="session.start",
            type="lifecycle",
            location="bootstrap.md#session.start",
            summary="bootstrap",
            rationale_doc="bootstrap.md#session.start",
            introduced_in="1.0.0",
            steps=[
                ProcessStep(id="s1", location="bootstrap.md#s1", gates=[]),
                ProcessStep(id="s2", location="bootstrap.md#s2", gates=["g.x"]),
            ],
        )
        assert len(proc.steps) == 2
        assert proc.steps[1].gates == ("g.x",)


# ---------------------------------------------------------------------------
# Registry accessors
# ---------------------------------------------------------------------------

def _make_gate(name: str, gtype: str = "pre-commit") -> Gate:
    return Gate(
        name=name,
        type=gtype,
        location=f"x.md#{name}",
        summary=name,
        default_state="open",
        extension_semantics="tighten",
        override_semantics="replace",
        state_change_semantics="open_close",
        rationale_doc=f"x.md#{name}",
        introduced_in="1.0.0",
    )


class TestGateRegistry:
    def test_get_and_list(self) -> None:
        reg = GateRegistry([
            _make_gate("commit.a"),
            _make_gate("release.b", gtype="pre-tag"),
        ])
        assert reg.get_gate("commit.a") is not None
        assert reg.get_gate("missing") is None
        assert "commit.a" in reg
        assert "missing" not in reg
        assert len(reg) == 2

    def test_filter_by_type(self) -> None:
        reg = GateRegistry([
            _make_gate("commit.a"),
            _make_gate("commit.b"),
            _make_gate("release.c", gtype="pre-tag"),
        ])
        commit_gates = reg.list_gates(type="pre-commit")
        assert {g.name for g in commit_gates} == {"commit.a", "commit.b"}
        release_gates = reg.list_gates(type="pre-tag")
        assert {g.name for g in release_gates} == {"release.c"}

    def test_duplicate_name_raises(self) -> None:
        with pytest.raises(GateRegistryError):
            GateRegistry([_make_gate("commit.a"), _make_gate("commit.a")])


class TestProcessRegistry:
    def test_get_and_list(self) -> None:
        reg = ProcessRegistry([
            Process(
                name="session.start",
                type="lifecycle",
                location="b.md#x",
                summary="x",
                rationale_doc="b.md#x",
                introduced_in="1.0.0",
            ),
            Process(
                name="release.process",
                type="release",
                location="r.md#x",
                summary="x",
                rationale_doc="r.md#x",
                introduced_in="1.0.0",
            ),
        ])
        assert reg.get_process("session.start") is not None
        assert reg.get_process("missing") is None
        lifecycles = reg.list_processes(type="lifecycle")
        assert len(lifecycles) == 1

    def test_duplicate_name_raises(self) -> None:
        proc = Process(
            name="session.start",
            type="lifecycle",
            location="b.md#x",
            summary="x",
            rationale_doc="b.md#x",
            introduced_in="1.0.0",
        )
        with pytest.raises(GateRegistryError):
            ProcessRegistry([proc, proc])


# ---------------------------------------------------------------------------
# Constrained-YAML parser
# ---------------------------------------------------------------------------

class TestParseYAML:
    def test_minimal_document(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert len(result) == 1
        assert result[0]["name"] == "commit.x"
        assert result[0]["introduced_in"] == "1.0.0"

    def test_inline_list(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
                related: [commit.a, commit.b, commit.c]
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert result[0]["related"] == ["commit.a", "commit.b", "commit.c"]

    def test_empty_inline_list(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
                related: []
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert result[0]["related"] == []

    def test_block_scalar(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
                notes: |
                  Line one.
                  Line two.
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert result[0]["notes"] == "Line one.\nLine two."

    def test_nested_sequence_for_steps(self) -> None:
        doc = textwrap.dedent("""\
            processes:
              - name: session.start
                type: lifecycle
                location: b.md#x
                summary: x
                rationale_doc: b.md#x
                introduced_in: "1.0.0"
                steps:
                  - id: s1
                    location: b.md#s1
                    gates: []
                  - id: s2
                    location: b.md#s2
                    gates: [g.x]
        """)
        result = parse_yaml_text(doc, root_key="processes")
        assert len(result[0]["steps"]) == 2
        assert result[0]["steps"][1]["id"] == "s2"
        assert result[0]["steps"][1]["gates"] == ["g.x"]

    def test_comments_skipped(self) -> None:
        doc = textwrap.dedent("""\
            # Top comment
            gates:
              # Item-level comment
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert len(result) == 1

    def test_quoted_strings(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: "commit.x"
                type: 'pre-commit'
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0a1"
        """)
        result = parse_yaml_text(doc, root_key="gates")
        assert result[0]["name"] == "commit.x"
        assert result[0]["type"] == "pre-commit"
        assert result[0]["introduced_in"] == "1.0.0a1"

    def test_tabs_rejected(self) -> None:
        doc = "gates:\n\t- name: commit.x\n"
        with pytest.raises(GateRegistryError, match="tabs"):
            parse_yaml_text(doc, root_key="gates")

    def test_missing_root_key(self) -> None:
        with pytest.raises(GateRegistryError, match="expected root key"):
            parse_yaml_text("processes:\n  - name: x\n", root_key="gates")

    def test_root_key_must_be_at_column_zero(self) -> None:
        with pytest.raises(GateRegistryError):
            parse_yaml_text("  gates:\n    - name: x\n", root_key="gates")

    def test_inline_value_on_root_rejected(self) -> None:
        with pytest.raises(GateRegistryError, match="inline value"):
            parse_yaml_text("gates: [a, b]\n", root_key="gates")

    def test_dash_line_must_have_inline_value(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name:
                type: pre-commit
        """)
        with pytest.raises(GateRegistryError, match="inline value"):
            parse_yaml_text(doc, root_key="gates")

    def test_empty_document(self) -> None:
        with pytest.raises(GateRegistryError, match="empty"):
            parse_yaml_text("# only comments\n\n", root_key="gates")

    def test_trailing_garbage_rejected(self) -> None:
        doc = textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
            unexpected_top_level: value
        """)
        with pytest.raises(GateRegistryError, match="unexpected content"):
            parse_yaml_text(doc, root_key="gates")


# ---------------------------------------------------------------------------
# Loader (file-system entry points)
# ---------------------------------------------------------------------------

class TestLoaders:
    def test_load_gates_happy(self, tmp_path: Path) -> None:
        path = tmp_path / "gates.yaml"
        path.write_text(textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: open
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
                related: [commit.a]
        """))
        registry = load_gates(path)
        gate = registry.get_gate("commit.x")
        assert gate is not None
        assert gate.related == ("commit.a",)

    def test_load_gates_missing_file(self, tmp_path: Path) -> None:
        with pytest.raises(GateRegistryError, match="not found"):
            load_gates(tmp_path / "absent.yaml")

    def test_load_gates_schema_violation(self, tmp_path: Path) -> None:
        # `default_state` must be open|closed; "maybe" violates the Literal.
        path = tmp_path / "gates.yaml"
        path.write_text(textwrap.dedent("""\
            gates:
              - name: commit.x
                type: pre-commit
                location: c.md#x
                summary: x
                default_state: maybe
                extension_semantics: tighten
                override_semantics: replace
                state_change_semantics: open_close
                rationale_doc: c.md#x
                introduced_in: "1.0.0"
        """))
        with pytest.raises(GateRegistryError, match="schema validation"):
            load_gates(path)

    def test_load_processes_with_steps(self, tmp_path: Path) -> None:
        path = tmp_path / "processes.yaml"
        path.write_text(textwrap.dedent("""\
            processes:
              - name: session.start
                type: lifecycle
                location: b.md#session.start
                summary: bootstrap
                rationale_doc: b.md#session.start
                introduced_in: "1.0.0"
                steps:
                  - id: step1
                    location: b.md#step1
                    gates: []
        """))
        registry = load_processes(path)
        proc = registry.get_process("session.start")
        assert proc is not None
        assert len(proc.steps) == 1
        assert proc.steps[0].id == "step1"


# Bazel-required entry point so this file isn't a silent no-op when run
# directly (#198 lint gate).
if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
