"""Unit tests for ForgejoAdapter (3.0 / Phase 3 sub-run A).

Covers:
  - platform_id ClassVar + per-instance override (codeberg / forgejo)
  - from_config token-file resolution and clear errors
  - shape converters (issue / discussion / comment / milestone)
  - _normalize_category / _category_from_labels round-trip
  - _parse_iso edge cases
  - probe() returns False on classified-unavailable status

Live integration (real HTTP against localhost:3000 / codeberg.org) is
covered by the cross-adapter conformance suite (sub-run D, parameterized
per-backend).
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
import pytest

from forge_manager_mcp.adapters import errors as _errors
from forge_manager_mcp.adapters.forgejo import (
    CODEBERG_API_BASE,
    ForgejoAdapter,
    _FORGEJO_DISCUSSION_LABELS,
    _FORGEJO_STANDARD_LABELS,
    _category_from_labels,
    _comment_from_api,
    _discussion_from_issue,
    _issue_from_api,
    _make_ref,
    _milestone_from_api,
    _normalize_category,
    _parse_iso,
)
from forge_manager_mcp.adapters.types import (
    ArtifactRef,
    Comment,
    Discussion,
    Issue,
    Milestone,
)


# ---------------------------------------------------------------------------
# platform_id
# ---------------------------------------------------------------------------

class TestPlatformId:
    def test_default_classvar(self):
        assert ForgejoAdapter.platform_id == "forgejo"

    def test_instance_codeberg_override(self):
        adapter = ForgejoAdapter(
            token="t", api_base=CODEBERG_API_BASE, platform_id="codeberg",
        )
        assert adapter.platform_id == "codeberg"

    def test_instance_forgejo_default(self):
        adapter = ForgejoAdapter(token="t", api_base="http://x")
        assert adapter.platform_id == "forgejo"


# ---------------------------------------------------------------------------
# from_config
# ---------------------------------------------------------------------------

class TestFromConfig:
    def test_codeberg_uses_hosted_url(self, tmp_path: Path):
        token_file = tmp_path / ".codeberg-token"
        token_file.write_text("ABC123\n")
        adapter = ForgejoAdapter.from_config({
            "id": "codeberg",
            "token_path": str(token_file),
        })
        assert adapter.platform_id == "codeberg"
        assert adapter._api_base == CODEBERG_API_BASE
        assert adapter._token == "ABC123"

    def test_forgejo_self_hosted_uses_url(self, tmp_path: Path):
        token_file = tmp_path / ".forgejo-token"
        token_file.write_text("XYZ\n")
        adapter = ForgejoAdapter.from_config({
            "id": "forgejo",
            "url": "http://localhost:3000",
            "token_path": str(token_file),
        })
        assert adapter.platform_id == "forgejo"
        assert adapter._api_base == "http://localhost:3000"
        assert adapter._token == "XYZ"

    def test_forgejo_default_url_when_unset(self, tmp_path: Path):
        token_file = tmp_path / ".forgejo-token"
        token_file.write_text("Y\n")
        adapter = ForgejoAdapter.from_config({
            "id": "forgejo",
            "token_path": str(token_file),
        })
        assert adapter._api_base == "http://localhost:3000"

    def test_unsupported_platform_id_raises(self, tmp_path: Path):
        with pytest.raises(_errors.ForgeError, match="unsupported platform_id"):
            ForgejoAdapter.from_config({"id": "github"})

    def test_missing_token_file_raises(self, tmp_path: Path, monkeypatch):
        # No env vars + nonexistent token_path + nonexistent default → no token
        monkeypatch.delenv("CODEBERG_TOKEN", raising=False)
        monkeypatch.delenv("FORGEJO_TOKEN", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))  # no ~/.codeberg-token here
        with pytest.raises(_errors.ForgeError, match="no token found"):
            ForgejoAdapter.from_config({
                "id": "codeberg",
                "token_path": str(tmp_path / "nonexistent"),
            })

    def test_empty_token_file_raises(self, tmp_path: Path, monkeypatch):
        # Empty token_path file, no env, no fallback → no token
        monkeypatch.delenv("CODEBERG_TOKEN", raising=False)
        monkeypatch.delenv("FORGEJO_TOKEN", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))
        token_file = tmp_path / "empty"
        token_file.write_text("   \n")
        with pytest.raises(_errors.ForgeError, match="no token found"):
            ForgejoAdapter.from_config({
                "id": "codeberg",
                "token_path": str(token_file),
            })

    def test_strips_trailing_slash_from_url(self, tmp_path: Path):
        token_file = tmp_path / "t"
        token_file.write_text("X")
        adapter = ForgejoAdapter.from_config({
            "id": "forgejo",
            "url": "http://localhost:3000/",
            "token_path": str(token_file),
        })
        assert adapter._api_base == "http://localhost:3000"


# ---------------------------------------------------------------------------
# Shape converters
# ---------------------------------------------------------------------------

class TestMakeRef:
    def test_basic(self):
        ref = _make_ref(
            platform_id="forgejo",
            native_id="42",
            kind="issue",
            owner="o",
            repo="r",
            number=7,
        )
        assert ref.platform_id == "forgejo"
        assert ref.native_id == "42"
        assert ref.kind == "issue"
        assert ref.number == 7

    def test_codeberg_platform_id(self):
        ref = _make_ref(
            platform_id="codeberg",
            native_id="99",
            kind="discussion",
            owner="o",
            repo="r",
            number=3,
        )
        assert ref.platform_id == "codeberg"


class TestIssueFromApi:
    def test_minimal(self):
        d = {
            "id": 1, "number": 7, "title": "t", "body": "b",
            "state": "open",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert isinstance(issue, Issue)
        assert issue.ref.number == 7
        assert issue.ref.native_id == "1"
        assert issue.ref.platform_id == "forgejo"
        assert issue.title == "t"
        assert issue.state == "open"
        assert issue.labels == []

    def test_closed_state(self):
        d = {"id": 2, "number": 1, "title": "x", "body": "", "state": "closed"}
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.state == "closed"

    def test_label_objects_become_names(self):
        d = {
            "id": 3, "number": 1, "title": "t", "body": "",
            "state": "open",
            "labels": [
                {"id": 1, "name": "kind:bug", "color": "ff0000"},
                {"id": 2, "name": "priority:high", "color": "0e8a16"},
            ],
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.labels == ["kind:bug", "priority:high"]

    def test_label_strings_pass_through(self):
        d = {
            "id": 4, "number": 2, "title": "t", "body": "",
            "state": "open",
            "labels": ["kind:rfc", "status:wip"],
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.labels == ["kind:rfc", "status:wip"]

    def test_milestone_dict_extracts_title(self):
        d = {
            "id": 5, "number": 3, "title": "t", "body": "",
            "state": "open",
            "milestone": {"id": 1, "title": "v1.0", "state": "open"},
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.milestone == "v1.0"

    def test_milestone_none(self):
        d = {
            "id": 6, "number": 4, "title": "t", "body": "",
            "state": "open", "milestone": None,
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.milestone is None

    def test_user_login_becomes_author(self):
        d = {
            "id": 7, "number": 5, "title": "t", "body": "",
            "state": "open",
            "user": {"login": "alice", "id": 100},
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.author == "alice"

    def test_html_url_becomes_url(self):
        d = {
            "id": 8, "number": 6, "title": "t", "body": "",
            "state": "open",
            "html_url": "https://codeberg.org/o/r/issues/6",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.url == "https://codeberg.org/o/r/issues/6"

    def test_iso_timestamps_parsed(self):
        d = {
            "id": 9, "number": 7, "title": "t", "body": "",
            "state": "open",
            "created_at": "2026-04-29T12:00:00Z",
            "updated_at": "2026-04-29T13:00:00Z",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="forgejo")
        assert issue.created_at is not None
        assert issue.created_at.year == 2026
        assert issue.updated_at is not None


class TestDiscussionFromIssue:
    def test_re_emits_ref_with_discussion_kind(self):
        issue = _issue_from_api(
            {
                "id": 1, "number": 7, "title": "t", "body": "b",
                "state": "open",
                "labels": [{"id": 1, "name": "kind:discussion"}],
            },
            owner="o", repo="r", platform_id="forgejo",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.ref.kind == "discussion"
        assert disc.ref.number == 7
        assert disc.title == "t"
        assert disc.body == "b"

    def test_decided_label_lifts_to_decided_field(self):
        issue = _issue_from_api(
            {
                "id": 2, "number": 1, "title": "t", "body": "",
                "state": "open",
                "labels": [
                    {"id": 1, "name": "kind:discussion"},
                    {"id": 2, "name": "decided"},
                ],
            },
            owner="o", repo="r", platform_id="forgejo",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.decided is True

    def test_no_decided_label(self):
        issue = _issue_from_api(
            {
                "id": 3, "number": 2, "title": "t", "body": "",
                "state": "open",
                "labels": [{"id": 1, "name": "kind:discussion"}],
            },
            owner="o", repo="r", platform_id="forgejo",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.decided is False

    def test_category_pass_through(self):
        issue = _issue_from_api(
            {"id": 4, "number": 1, "title": "t", "body": "", "state": "open"},
            owner="o", repo="r", platform_id="forgejo",
        )
        disc = _discussion_from_issue(issue, category="Architecture")
        assert disc.category == "Architecture"


class TestCommentFromApi:
    def test_basic(self):
        parent = ArtifactRef(
            platform_id="forgejo", native_id="1", kind="issue",
            owner="o", repo="r", number=7,
        )
        d = {
            "id": 100, "body": "first",
            "user": {"login": "bob"},
            "created_at": "2026-04-29T10:00:00Z",
        }
        comment = _comment_from_api(d, parent=parent, platform_id="forgejo")
        assert isinstance(comment, Comment)
        assert comment.body == "first"
        assert comment.author == "bob"
        assert comment.parent.kind == "issue"
        assert comment.parent.number == 7
        assert comment.ref.kind == "comment"
        assert comment.ref.number is None  # comments have no repo-scoped number

    def test_falls_back_to_now_on_missing_created_at(self):
        parent = ArtifactRef(
            platform_id="forgejo", native_id="1", kind="issue",
            owner="o", repo="r", number=1,
        )
        d = {"id": 1, "body": "x", "user": {"login": "u"}}
        comment = _comment_from_api(d, parent=parent, platform_id="forgejo")
        # Just verify it's a recent UTC datetime; tolerate clock skew.
        assert comment.created_at.tzinfo is not None


class TestMilestoneFromApi:
    def test_basic(self):
        d = {"id": 1, "title": "v1.0", "state": "open", "description": "first"}
        m = _milestone_from_api(d)
        assert isinstance(m, Milestone)
        assert m.title == "v1.0"
        assert m.number == 1
        assert m.state == "open"
        assert m.description == "first"

    def test_closed_state(self):
        d = {"id": 2, "title": "v2.0", "state": "closed"}
        m = _milestone_from_api(d)
        assert m.state == "closed"


class TestNormalizeCategory:
    def test_lowercase(self):
        assert _normalize_category("Architecture") == "architecture"

    def test_spaces_become_underscores(self):
        assert _normalize_category("UX UI") == "ux_ui"

    def test_slash_compound_collapses(self):
        assert _normalize_category("UX / UI") == "ux_ui"


class TestCategoryFromLabels:
    def test_finds_first(self):
        assert _category_from_labels([
            "kind:discussion", "category:architecture", "decided",
        ]) == "architecture"

    def test_returns_none_when_absent(self):
        assert _category_from_labels(["kind:discussion", "decided"]) is None


class TestParseIso:
    def test_z_suffix(self):
        result = _parse_iso("2026-04-29T12:00:00Z")
        assert result is not None
        assert result.year == 2026
        assert result.month == 4

    def test_offset(self):
        result = _parse_iso("2026-04-29T12:00:00+00:00")
        assert result is not None

    def test_none_returns_none(self):
        assert _parse_iso(None) is None

    def test_empty_string_returns_none(self):
        assert _parse_iso("") is None

    def test_garbage_returns_none(self):
        assert _parse_iso("not a timestamp") is None

    def test_non_string_returns_none(self):
        assert _parse_iso(12345) is None


# ---------------------------------------------------------------------------
# _request error classification — uses MockTransport so we don't open
# real sockets. Verifies the unavailable-vs-caller-fault split.
# ---------------------------------------------------------------------------

def _adapter_with_mock(handler) -> ForgejoAdapter:
    """Build an adapter whose httpx client uses a MockTransport."""
    adapter = ForgejoAdapter(
        token="fake", api_base="http://forgejo.test", platform_id="forgejo",
    )
    adapter._client = httpx.AsyncClient(
        base_url=f"{adapter._api_base}/api/v1",
        transport=httpx.MockTransport(handler),
        headers=adapter._headers(),
    )
    return adapter


class TestRequestErrorClassification:
    @pytest.mark.asyncio
    async def test_5xx_raises_forge_unavailable(self):
        def handler(req):
            return httpx.Response(503, text="upstream broken")
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.ForgeUnavailableError) as exc_info:
                await adapter._request("GET", "/version")
            assert exc_info.value.status_code == 503
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_403_raises_forge_unavailable(self):
        def handler(req):
            return httpx.Response(403, text="suspended")
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.ForgeUnavailableError):
                await adapter._request("GET", "/version")
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_404_with_allow_returns_none(self):
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._request(
                "GET", "/repos/x/y/issues/9999", allow_404_as_none=True,
            )
            assert result is None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_404_without_allow_raises_forge_error(self):
        def handler(req):
            return httpx.Response(404, text="nope")
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.ForgeError) as exc_info:
                await adapter._request("GET", "/repos/x/y")
            # 404 is caller-fault, so NOT classified as unavailable.
            assert not isinstance(exc_info.value, _errors.ForgeUnavailableError)
            assert exc_info.value.status_code == 404
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_422_raises_forge_error_not_unavailable(self):
        def handler(req):
            return httpx.Response(422, text="validation")
        adapter = _adapter_with_mock(handler)
        try:
            with pytest.raises(_errors.ForgeError) as exc_info:
                await adapter._request("POST", "/repos/x/y/issues", json={})
            assert exc_info.value.status_code == 422
            assert not isinstance(exc_info.value, _errors.ForgeUnavailableError)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_204_returns_none(self):
        def handler(req):
            return httpx.Response(204)
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._request(
                "DELETE", "/repos/x/y/issues/1/labels/3",
            )
            assert result is None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_2xx_json_parses(self):
        def handler(req):
            return httpx.Response(200, json={"version": "13.0.4"})
        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter._request("GET", "/version")
            assert result == {"version": "13.0.4"}
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# get_issue_body / get_discussion_body (Phase C1)
# ---------------------------------------------------------------------------

class TestGetBodyByRef:
    """#274 Phase C1 — node-ID-based body fetch. Forgejo's REST API
    is number-based, so the implementation requires ref.number to be
    populated; node-ID-only refs from other adapters surface a clear
    InvalidArtifactRefError."""

    @pytest.mark.asyncio
    async def test_get_issue_body_returns_body_on_200(self):
        def handler(req):
            return httpx.Response(200, json={
                "number": 7, "body": "current body content",
                "title": "t", "user": {"login": "u"},
                "labels": [], "state": "open", "comments": 0,
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z",
                "html_url": "http://forgejo.test/x/y/issues/7",
            })
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="x/y#7",
                kind="issue", owner="x", repo="y", number=7,
            )
            body = await adapter.get_issue_body(ref)
            assert body == "current body content"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_body_404_raises_invalid_ref(self):
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="x/y#9999",
                kind="issue", owner="x", repo="y", number=9999,
            )
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue_body(ref)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_body_missing_number_raises(self):
        """Cross-adapter ref without ref.number → can't be resolved
        via Forgejo REST. InvalidArtifactRefError surfaces a clear
        diagnostic."""
        def handler(req):
            return httpx.Response(500, text="should never be called")
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="github", native_id="I_kwDO_xx",
                kind="issue", owner="x", repo="y", number=None,
            )
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue_body(ref)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_discussion_body_uses_same_endpoint(self):
        """Forgejo models Discussions as Issues — get_discussion_body
        delegates to get_issue_body."""
        def handler(req):
            return httpx.Response(200, json={
                "number": 9, "body": "discussion body",
                "title": "d", "user": {"login": "u"},
                "labels": [{"name": "kind:discussion"}],
                "state": "open", "comments": 0,
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z",
                "html_url": "http://forgejo.test/x/y/issues/9",
            })
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="forgejo", native_id="x/y#9",
                kind="discussion", owner="x", repo="y", number=9,
            )
            body = await adapter.get_discussion_body(ref)
            assert body == "discussion body"
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# probe()
# ---------------------------------------------------------------------------

class TestProbe:
    @pytest.mark.asyncio
    async def test_returns_true_on_version_response(self):
        def handler(req):
            return httpx.Response(200, json={"version": "13.0.4"})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is True
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_returns_false_on_503(self):
        def handler(req):
            return httpx.Response(503, text="down")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_returns_false_on_403(self):
        def handler(req):
            return httpx.Response(403, text="auth")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# Header construction
# ---------------------------------------------------------------------------

class TestHeaders:
    def test_token_auth_header(self):
        adapter = ForgejoAdapter(
            token="ABC123", api_base="http://x", platform_id="forgejo",
        )
        headers = adapter._headers()
        # Forgejo/Gitea uses 'token <T>', not GitHub's 'Bearer <T>'.
        assert headers["Authorization"] == "token ABC123"
        assert headers["Accept"] == "application/json"
        assert headers["Content-Type"] == "application/json"


# ---------------------------------------------------------------------------
# compute_drift stub
# ---------------------------------------------------------------------------

class TestComputeDrift:
    @pytest.mark.asyncio
    async def test_inconclusive_without_owner_repo_in_snapshot(self):
        # Phase 6 sub-run B: compute_drift now requires owner/repo in
        # the snapshot dict to know which remote project to diff.
        # Empty snapshot → inconclusive report. Comprehensive coverage
        # of the diff logic lives in tests/test_drift_detection.py.
        adapter = ForgejoAdapter(
            token="t", api_base="http://x", platform_id="codeberg",
        )
        report = await adapter.compute_drift({})
        assert report.platform_id == "codeberg"
        assert report.is_clean is False
        assert any("owner/repo" in n for n in report.notes)


class TestRepoVisibility:
    """PAR-3: get_repo_visibility maps Forgejo's boolean ``private`` flag
    onto the Protocol's PUBLIC/PRIVATE/INTERNAL alphabet."""

    @pytest.mark.asyncio
    async def test_public_repo(self):
        def handler(req):
            return httpx.Response(200, json={"id": 1, "private": False})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PUBLIC"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_private_repo(self):
        def handler(req):
            return httpx.Response(200, json={"id": 1, "private": True})
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PRIVATE"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_missing_repo_returns_none(self):
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") is None
        finally:
            await adapter.aclose()


class TestBootstrapProject:
    """Multi-platform scaffold C3 — ForgejoAdapter.bootstrap_project."""

    def test_has_scaffold_classvar_true(self):
        assert ForgejoAdapter.has_scaffold is True

    def test_has_session_event_surface_classvar_false(self):
        # Forgejo / Codeberg session-lock surface is comments on the
        # Issues-as-Discussions Project Index Issue, addressed by the
        # handler via append_comment — not a dedicated Protocol surface.
        assert ForgejoAdapter.has_session_event_surface is False

    @pytest.mark.asyncio
    async def test_bootstrap_creates_repo_pair_and_seeds_labels(self):
        seen_calls: list[tuple[str, str]] = []
        labels_created: list[str] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path  # full path including /api/v1
            seen_calls.append((method, path))

            # Probe: GET /repos/<owner>/<name> — both repos new (404).
            if method == "GET" and path.startswith("/api/v1/repos/myorg/widgets") \
                    and "/labels" not in path:
                return httpx.Response(404, json={"message": "not found"})

            # Org-namespace repo create succeeds.
            if method == "POST" and path == "/api/v1/orgs/myorg/repos":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                return httpx.Response(201, json={
                    "id": 42 if body["name"] == "widgets-dev" else 43,
                    "full_name": f"myorg/{body['name']}",
                    "html_url": f"http://forgejo.test/myorg/{body['name']}",
                    "private": body["private"],
                })

            # Label probe (always-empty paginated list → trigger create).
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                labels_created.append(body["name"])
                return httpx.Response(201, json={"id": len(labels_created)})

            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="myorg", project_name="widgets",
                description="widgets project",
            )
        finally:
            await adapter.aclose()

        assert result.platform_id == "forgejo"
        assert result.phase == "complete"
        assert result.manual_steps == []
        assert result.artifacts["dev_repo"]["existed"] is False
        assert result.artifacts["public_repo"]["existed"] is False
        assert result.artifacts["dev_repo"]["full_name"] == "myorg/widgets-dev"
        assert result.artifacts["public_repo"]["full_name"] == "myorg/widgets"
        # forgejo #7 (3.4.0): docs repo joins the trio per #263.
        assert result.artifacts["docs_repo"]["existed"] is False
        assert result.artifacts["docs_repo"]["full_name"] == "myorg/widgets-docs"
        assert result.artifacts["docs_repo"]["html_url"] == (
            "http://forgejo.test/myorg/widgets-docs"
        )

        # Standard labels seeded.
        assert "bug" in labels_created
        assert "rfc" in labels_created
        assert "area:mcp" in labels_created
        # Discussions-as-Issues reserved labels seeded.
        assert "kind:discussion" in labels_created
        assert "category:Architecture" in labels_created
        assert "decided" in labels_created

    @pytest.mark.asyncio
    async def test_bootstrap_idempotent_when_repos_exist(self):
        """Re-running bootstrap when both repos exist no-ops the
        creation (probe returns 200) and reports existed=True. Labels
        still iterate (each ``ensure_label`` no-ops on a present label
        via the repo-labels probe)."""
        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            if method == "GET" and "/labels" not in path \
                    and path.startswith("/api/v1/repos/myorg/widgets"):
                # Repo exists with required unit flags already correct
                # (post-#9 steady state — units enabled at create time).
                name = path.rsplit("/", 1)[-1]
                return httpx.Response(200, json={
                    "id": 42 if name == "widgets-dev" else 43,
                    "full_name": f"myorg/{name}",
                    "html_url": f"http://forgejo.test/myorg/{name}",
                    "private": name.endswith("-dev"),
                    "has_releases": True,
                    "has_issues": True,
                })
            if method == "GET" and path.endswith("/labels"):
                # Every label already present — return matching by name.
                return httpx.Response(200, json=[
                    {"id": i + 1, "name": n} for i, (n, _, _) in enumerate(
                        list(_FORGEJO_STANDARD_LABELS) +
                        list(_FORGEJO_DISCUSSION_LABELS)
                    )
                ])
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert result.phase == "complete"
        assert result.artifacts["dev_repo"]["existed"] is True
        assert result.artifacts["public_repo"]["existed"] is True
        # forgejo #7 (3.4.0): docs repo idempotent on probe.
        assert result.artifacts["docs_repo"]["existed"] is True

    @pytest.mark.asyncio
    async def test_bootstrap_falls_back_to_user_repos_when_org_404s(self):
        """When the owner is a user (not an org), the org-create POST
        returns 404; the adapter falls back to ``POST /user/repos``."""
        org_create_attempts: list[str] = []
        user_create_attempts: list[str] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            if method == "GET" and path.startswith("/api/v1/repos/alice/") \
                    and "/labels" not in path:
                return httpx.Response(404, text="not found")
            if method == "POST" and path == "/api/v1/orgs/alice/repos":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                org_create_attempts.append(body["name"])
                return httpx.Response(404, text="org not found")
            if method == "POST" and path == "/api/v1/user/repos":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                user_create_attempts.append(body["name"])
                return httpx.Response(201, json={
                    "id": 99,
                    "full_name": f"alice/{body['name']}",
                    "html_url": f"http://forgejo.test/alice/{body['name']}",
                    "private": body["private"],
                })
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                return httpx.Response(201, json={"id": 1})
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="alice", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert result.phase == "complete"
        # All three repos went through the user-fallback path.
        # forgejo #7 (3.4.0): docs repo joins the trio per #263.
        assert org_create_attempts == ["widgets-dev", "widgets", "widgets-docs"]
        assert user_create_attempts == ["widgets-dev", "widgets", "widgets-docs"]

    @pytest.mark.asyncio
    async def test_bootstrap_rejects_empty_owner(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(500))
        try:
            with pytest.raises(_errors.ForgeError, match="owner"):
                await adapter.bootstrap_project(
                    owner="  ", project_name="widgets", description="",
                )
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_bootstrap_rejects_empty_project_name(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(500))
        try:
            with pytest.raises(_errors.ForgeError, match="project_name"):
                await adapter.bootstrap_project(
                    owner="myorg", project_name="  ", description="",
                )
        finally:
            await adapter.aclose()

    # ---- forgejo #9: required repo unit flags ---------------------------

    @pytest.mark.asyncio
    async def test_bootstrap_create_payload_enables_required_units(self):
        """#9: create payload must include has_releases=True so freshly-
        scaffolded Codeberg repos accept ``POST /repos/.../releases``
        without requiring a manual PATCH."""
        from forge_manager_mcp.adapters.forgejo import _REQUIRED_UNIT_FLAGS

        create_payloads: list[dict] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            if method == "GET" and path.startswith("/api/v1/repos/myorg/widgets") \
                    and "/labels" not in path:
                return httpx.Response(404, text="not found")
            if method == "POST" and path == "/api/v1/orgs/myorg/repos":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                create_payloads.append(body)
                return httpx.Response(201, json={
                    "id": len(create_payloads),
                    "full_name": f"myorg/{body['name']}",
                    "html_url": f"http://forgejo.test/myorg/{body['name']}",
                    "private": body["private"],
                    "has_releases": body.get("has_releases", False),
                    "has_issues": body.get("has_issues", True),
                })
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                return httpx.Response(201, json={"id": 1})
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert len(create_payloads) == 3  # dev + public + docs (#7 / 3.4.0)
        for payload in create_payloads:
            for flag, required in _REQUIRED_UNIT_FLAGS.items():
                assert payload[flag] is required, (
                    f"create payload missing or wrong value for {flag!r}: "
                    f"{payload!r}"
                )

    @pytest.mark.asyncio
    async def test_bootstrap_patches_existing_repo_with_disabled_units(self):
        """#9: probe-found existing repo with diverging unit flags
        triggers a PATCH carrying only the diverging flags. Mid-life
        adoption path — pre-#9 bootstrap or hand-created Codeberg repos."""
        patch_calls: list[tuple[str, dict]] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            if method == "GET" and "/labels" not in path \
                    and path.startswith("/api/v1/repos/myorg/widgets"):
                name = path.rsplit("/", 1)[-1]
                return httpx.Response(200, json={
                    "id": 42,
                    "full_name": f"myorg/{name}",
                    "html_url": f"http://forgejo.test/myorg/{name}",
                    "private": name.endswith("-dev"),
                    "has_releases": False,  # the diverging flag
                    "has_issues": True,
                })
            if method == "PATCH" and path.startswith("/api/v1/repos/myorg/widgets"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                name = path.rsplit("/", 1)[-1]
                patch_calls.append((name, body))
                return httpx.Response(200, json={
                    "id": 42, "has_releases": True, "has_issues": True,
                })
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[
                    {"id": i + 1, "name": n} for i, (n, _, _) in enumerate(
                        list(_FORGEJO_STANDARD_LABELS) +
                        list(_FORGEJO_DISCUSSION_LABELS)
                    )
                ])
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        # forgejo #7 (3.4.0): docs repo joins the trio.
        assert {name for name, _ in patch_calls} == {
            "widgets-dev", "widgets", "widgets-docs",
        }
        for _, body in patch_calls:
            # Only the diverging flag — has_issues was already True so omitted.
            assert body == {"has_releases": True}

    @pytest.mark.asyncio
    async def test_bootstrap_skips_patch_when_units_already_correct(self):
        """#9: probe-found existing repo whose units already match the
        required state issues no PATCH (pure idempotence)."""
        patch_calls: list[str] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            if method == "GET" and "/labels" not in path \
                    and path.startswith("/api/v1/repos/myorg/widgets"):
                name = path.rsplit("/", 1)[-1]
                return httpx.Response(200, json={
                    "id": 42,
                    "full_name": f"myorg/{name}",
                    "html_url": f"http://forgejo.test/myorg/{name}",
                    "private": name.endswith("-dev"),
                    "has_releases": True,
                    "has_issues": True,
                })
            if method == "PATCH":
                patch_calls.append(path)
                return httpx.Response(200, json={})
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[
                    {"id": i + 1, "name": n} for i, (n, _, _) in enumerate(
                        list(_FORGEJO_STANDARD_LABELS) +
                        list(_FORGEJO_DISCUSSION_LABELS)
                    )
                ])
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert patch_calls == []


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
