"""Runbook-gate conformance test (3.4.0 / Codeberg-dev #3 Phase 1f).

For every ``pre-publish`` gate declared in the skill's ``gates.yaml``,
asserts that the gate's ``runbook_url`` resolves to a real markdown
file in the docs repo with valid YAML frontmatter declaring the same
``gate_name``.

The docs repo path is configurable via ``$FORGE_MANAGER_DOCS_REPO``
(per the 3.0.1 G7-G10 / migration manual_steps convention). When the
env var is unset or the path doesn't exist, this test SKIPS rather
than failing — matches the test_plugin_manifest staging convention
that allows the suite to remain green in Bazel sandboxes that don't
stage external paths.

When the env var IS set + reachable + every runbook is in place,
this test gives the runbook gate framework structural teeth: a
future ``git rm runbooks/<gate-name>.md`` from the docs repo, or a
gates.yaml entry with a typo'd ``runbook_url``, fails the test
before tag.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

import pytest

from forge_manager_mcp import gate_registry as _gr


_HERE = Path(__file__).resolve().parent
_GATES_YAML_CANDIDATES = (
    _HERE / "gates.yaml",                                                     # Bazel sandbox + symlink
    _HERE.parent.parent / ".claude" / "skills" / "forge-manager" / "gates.yaml",  # source-tree fallback
)


def _load_skill_gates() -> _gr.GateRegistry:
    for candidate in _GATES_YAML_CANDIDATES:
        if candidate.is_file():
            return _gr.load_gates(candidate)
    pytest.skip(
        f"gates.yaml not reachable from any of: "
        f"{[str(c) for c in _GATES_YAML_CANDIDATES]}"
    )


def _resolve_docs_repo() -> Path:
    env = os.environ.get("FORGE_MANAGER_DOCS_REPO")
    if not env:
        pytest.skip(
            "FORGE_MANAGER_DOCS_REPO unset; runbook resolution skipped. "
            "Set the env var to your local docs-repo checkout to exercise "
            "this conformance gate."
        )
    docs_repo = Path(env).expanduser().resolve()
    if not docs_repo.is_dir():
        pytest.skip(
            f"FORGE_MANAGER_DOCS_REPO={env!r} does not resolve to a "
            f"directory; skipping runbook resolution"
        )
    return docs_repo


_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)^---\s*\n", re.MULTILINE | re.DOTALL)


def _parse_frontmatter(text: str) -> dict[str, str]:
    """Tiny YAML-frontmatter parser — ``key: value`` lines only.

    Avoids a PyYAML dependency. Sufficient for the runbook frontmatter
    schema (``gate_name`` / ``gate_version`` / ``last_verified_against_release``).
    """
    match = _FRONTMATTER_RE.match(text)
    if not match:
        return {}
    out: dict[str, str] = {}
    for line in match.group(1).splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        out[key.strip()] = value.strip()
    return out


def _runbook_gates() -> list[_gr.Gate]:
    return [g for g in _load_skill_gates().list_gates() if g.type == "pre-publish"]


class TestRunbookGateRegistry:
    """Static checks on the registry side — no docs repo needed."""

    def test_at_least_one_runbook_gate_declared(self) -> None:
        gates = _runbook_gates()
        assert gates, (
            "expected at least one pre-publish runbook gate from "
            "3.4.0 onward"
        )

    def test_every_runbook_gate_has_runbook_url(self) -> None:
        for gate in _runbook_gates():
            assert gate.runbook_url, (
                f"gate {gate.name!r} is type pre-publish but has no "
                f"runbook_url — model validator should have caught this"
            )

    def test_runbook_urls_unique(self) -> None:
        urls = [g.runbook_url for g in _runbook_gates()]
        assert len(urls) == len(set(urls)), (
            f"duplicate runbook_url across gates: {urls}"
        )


class TestRunbookProseResolution:
    """Cross-repo checks — resolve runbook_url against docs repo."""

    def test_every_runbook_resolves_to_a_file(self) -> None:
        docs_repo = _resolve_docs_repo()
        missing: list[tuple[str, str]] = []
        for gate in _runbook_gates():
            target = (docs_repo / gate.runbook_url).resolve()
            if not target.is_file():
                missing.append((gate.name, str(target)))
        assert not missing, (
            f"runbook_url(s) point at nonexistent files: {missing}"
        )

    def test_every_runbook_has_required_frontmatter(self) -> None:
        docs_repo = _resolve_docs_repo()
        violations: list[tuple[str, str]] = []
        for gate in _runbook_gates():
            target = (docs_repo / gate.runbook_url).resolve()
            if not target.is_file():
                continue  # covered by resolves-to-file test
            fm = _parse_frontmatter(target.read_text(encoding="utf-8"))
            for required in ("gate_name", "gate_version", "last_verified_against_release"):
                if required not in fm:
                    violations.append((gate.name, f"missing {required}"))
        assert not violations, (
            f"runbook frontmatter violations: {violations}"
        )

    def test_runbook_frontmatter_gate_name_matches(self) -> None:
        docs_repo = _resolve_docs_repo()
        mismatches: list[tuple[str, str, str]] = []
        for gate in _runbook_gates():
            target = (docs_repo / gate.runbook_url).resolve()
            if not target.is_file():
                continue
            fm = _parse_frontmatter(target.read_text(encoding="utf-8"))
            if fm.get("gate_name") != gate.name:
                mismatches.append(
                    (gate.name, gate.runbook_url, fm.get("gate_name", "<missing>"))
                )
        assert not mismatches, (
            f"runbook frontmatter gate_name does not match registry "
            f"gate name: {mismatches}"
        )


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
