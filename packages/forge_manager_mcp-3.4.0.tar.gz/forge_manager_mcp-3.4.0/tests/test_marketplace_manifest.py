"""Marketplace manifest validity test (Codeberg-dev #1 + #2 / 3.3.2 hotfix).

Asserts `.claude-plugin/marketplace.json` is well-formed against the
schema Claude Code's `/plugin marketplace add` enforces — the same
schema the `anthropics/claude-plugins-official` marketplace uses.

The 3.3.1 cut shipped this test asserting `source == "."` based on
incorrect prior guidance. Live `/plugin marketplace add` against
3.3.1 returned `plugins.0.source: Invalid input` (Codeberg-dev #2);
this test was rewritten in 3.3.2 to match the verified shape from
the official marketplace.

Verified shapes for the `source` field:

* Bare string path to a subdirectory: `"./plugins/<name>"` — never
  bare `"."`. Plugin lives in that subdir with its own
  `.claude-plugin/plugin.json`.
* Typed object: `{source: "url", url: "..."}` — clones URL fresh and
  treats the cloned tree as the plugin.
* Typed object: `{source: "git-subdir", url: "...", path: "...", ref: "..."}`.
* Typed object: `{source: "github", repo: "owner/repo", commit?: "..."}`.

Our 3.3.2 marketplace.json uses the `{source: "url", url: ...}` form
because the marketplace AND the plugin live in the same repo without
restructuring into a `./plugins/<name>/` subdir. Test asserts that
specific shape — restructure to a different form is allowed but
requires a deliberate test rewrite.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from urllib.parse import urlparse

import pytest

_HERE = Path(__file__).resolve().parent
_MARKETPLACE_CANDIDATES = (
    _HERE / "marketplace.json",
    _HERE.parent.parent / ".claude-plugin" / "marketplace.json",
)
_PLUGIN_CANDIDATES = (
    _HERE / "plugin.json",
    _HERE.parent.parent / ".claude-plugin" / "plugin.json",
)
_PYPROJECT_CANDIDATES = (
    _HERE / "pyproject.toml",
    _HERE.parent / "pyproject.toml",
)


def _load_marketplace() -> dict:
    for candidate in _MARKETPLACE_CANDIDATES:
        if candidate.is_file():
            return json.loads(candidate.read_text(encoding="utf-8"))
    pytest.skip("marketplace.json not found")


def _load_plugin() -> dict:
    for candidate in _PLUGIN_CANDIDATES:
        if candidate.is_file():
            return json.loads(candidate.read_text(encoding="utf-8"))
    pytest.skip("plugin.json not found")


def _load_pyproject_version() -> str:
    for candidate in _PYPROJECT_CANDIDATES:
        if candidate.is_file():
            text = candidate.read_text(encoding="utf-8")
            match = re.search(
                r'^version\s*=\s*[\'"]([^\'"]+)[\'"]',
                text, re.MULTILINE,
            )
            if match:
                return match.group(1)
    pytest.skip("pyproject.toml version not resolvable")


_VERSION_PATTERN = re.compile(r"^\d+\.\d+\.\d+(?:[ab]\d+|rc\d+)?$")
_CANONICAL_REPO_URL = (
    "https://codeberg.org/telejester-skills/telejester-claude-skills.git"
)


class TestMarketplaceRequiredFields:
    """Top-level fields against the schema the official marketplace
    follows (anthropics/claude-plugins-official): `$schema` / `name` /
    `description` / `owner` / `plugins`. No `version` field at top
    level — pinning is per-plugin via source object's `sha` / `ref`."""

    def test_marketplace_parses_as_json(self):
        manifest = _load_marketplace()
        assert isinstance(manifest, dict)

    def test_required_name_present(self):
        manifest = _load_marketplace()
        assert manifest.get("name"), "name field required"
        assert isinstance(manifest["name"], str)

    def test_required_owner_object(self):
        manifest = _load_marketplace()
        owner = manifest.get("owner")
        assert isinstance(owner, dict), (
            f"owner must be an object {{name, email?}}"
        )
        assert owner.get("name"), "owner.name required"

    def test_required_plugins_array_non_empty(self):
        manifest = _load_marketplace()
        plugins = manifest.get("plugins")
        assert isinstance(plugins, list), "plugins must be an array"
        assert plugins, "plugins[] must declare at least one plugin"


class TestMarketplaceForgemanagerEntry:
    """The marketplace declares exactly one plugin, `forge-manager`,
    sourced from this same repo via the typed url-source object."""

    def test_single_plugin_entry(self):
        manifest = _load_marketplace()
        assert len(manifest["plugins"]) == 1, (
            "3.3.x design ships one plugin per marketplace"
        )

    def test_plugin_named_forge_manager(self):
        manifest = _load_marketplace()
        entry = manifest["plugins"][0]
        assert entry.get("name") == "forge-manager"

    def test_plugin_description_present(self):
        manifest = _load_marketplace()
        entry = manifest["plugins"][0]
        assert entry.get("description"), (
            "plugin description should be non-empty"
        )

    def test_source_is_typed_url_object(self):
        """3.3.2 fix: source must be the typed `{source: "url", url: ...}`
        object, NOT a bare `"."` string. The schema rejects `"."`
        outright. We commit to the url-source form because:

        * The official marketplace exercises it heavily (~half of
          all plugin entries use url-source).
        * It avoids restructuring this repo into a
          `./plugins/<name>/` subdirectory layout, which would
          conflict with the dev repo's project-level skill loading.
        * It has no known schema-validation bugs (unlike git-subdir
          per anthropics/claude-code#35805).
        """
        manifest = _load_marketplace()
        entry = manifest["plugins"][0]
        source = entry.get("source")
        assert isinstance(source, dict), (
            f"source must be a typed object, not a bare string. "
            f"3.3.1 had source=='.' and Claude Code's Zod schema "
            f"rejected it (Codeberg-dev #2). Got {type(source).__name__}: "
            f"{source!r}"
        )

    def test_source_type_is_url(self):
        manifest = _load_marketplace()
        source = manifest["plugins"][0]["source"]
        assert source.get("source") == "url", (
            f"source.source should be 'url' (canonical typed form for "
            f"a self-hosted repo without subdir restructure); got "
            f"{source.get('source')!r}"
        )

    def test_source_url_matches_canonical_repo(self):
        manifest = _load_marketplace()
        source = manifest["plugins"][0]["source"]
        assert source.get("url") == _CANONICAL_REPO_URL, (
            f"source.url should point at the canonical Codeberg "
            f"public repo {_CANONICAL_REPO_URL!r}; got "
            f"{source.get('url')!r}"
        )

    def test_source_url_well_formed(self):
        manifest = _load_marketplace()
        source = manifest["plugins"][0]["source"]
        parsed = urlparse(source.get("url", ""))
        assert parsed.scheme in ("http", "https")
        assert parsed.netloc
        assert parsed.path.endswith(".git"), (
            "url should end with .git per official-marketplace convention"
        )


class TestMarketplaceConsistencyWithPluginJson:
    """Marketplace and plugin manifests live side-by-side; the plugin
    name + the plugin.json name must match. Version coupling is
    asserted in test_plugin_manifest.py — the marketplace itself
    doesn't carry a version (per the official schema)."""

    def test_plugin_name_matches_plugin_json(self):
        marketplace = _load_marketplace()
        plugin = _load_plugin()
        assert marketplace["plugins"][0]["name"] == plugin["name"]


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
