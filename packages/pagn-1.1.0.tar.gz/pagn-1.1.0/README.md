[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.10723301.svg)](https://doi.org/10.5281/zenodo.10723301)

## pagn

`pagn` is a Python module for solving the AGN disk models of [Sirko & Goodman (2003)](https://academic.oup.com/mnras/article/341/2/501/1105444) and [Thompson et al. (2005)](https://iopscience.iop.org/article/10.1086/431923). It is designed to be simple, transparent, and highly customizable.

Given a set of physical inputs, `pagn` computes fully evolved 1D AGN disk structures, providing parametric radial profiles of key quantities such as temperature, density, and related disk properties.

Typical applications include:
- Migration torques in AGN disks
- Formation and evolution of compact objects embedded in gas disks
- Benchmarking and comparison with more complex AGN disk models

---

## Installation

Install from PyPI with:

	pip install pagn

---

## Documentation

Documentation and example usage are available at:
https://aatrani.gitlab.io/pagn/

---

## Citation

If you use `pagn`, please cite:

- *pAGN: the one-stop solution for AGN disc modeling.*  
  Daria Gangardt, Alessandro Alberto Trani, Clément Bonnerot, Davide Gerosa.  
  Monthly Notices of the Royal Astronomical Society.  
  [arXiv:2403.00060](https://arxiv.org/abs/2403.00060) | [ADS Link](https://scixplorer.org/abs/2024MNRAS.530.3689G/abstract)

---

## Source Code

The code is hosted at:
- https://gitlab.com/aatrani/pagn

---

## Authors and Contributions

Developed by Daria Gangardt and Alessandro A. Trani.  
Currently maintained by [Alessandro A. Trani](https://alessandrotrani.space).

Bug reports, feature requests, and suggestions are welcome via GitLab issues.

---

## License

`pagn` is distributed under the GPLv3 license.

---

## Development and Release Workflow

1. Build the package:
   
	python -m build

   This generates `.whl` and `.tar.gz` files in the `dist/` directory.

2. Test locally:

	pip install dist/pagn-x.y.z-py3-none-any.whl

3. Upload to TestPyPI:

	twine upload --repository testpypi dist/*

4. Test installation from TestPyPI:

	pip install --index-url https://test.pypi.org/simple/ pagn

5. If successful, upload to PyPI:

	twine upload dist/*