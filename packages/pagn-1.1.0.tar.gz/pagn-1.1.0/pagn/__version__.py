"""
Information about the current version of the pagn package.
"""

__version__ = '1.1.0'
__all__ = ['__version__']
