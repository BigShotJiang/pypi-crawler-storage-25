import joblib
from buaiir_spectra.utils.device import Device
from pathlib import Path
from typing import Tuple, Union, List
import numpy as np
from importlib.resources import files



COMPILED_DATA_PATH = files("buaiir_spectra").joinpath("compiled_data.pkl")
COMPILED_WAVELENGTH_PATH = files("buaiir_spectra").joinpath("compiled_wavelength.pkl")

compiled_data = joblib.load(COMPILED_DATA_PATH)
compiled_wavelength = joblib.load(COMPILED_WAVELENGTH_PATH)



def load_spectral(device: Device, with_wavelenght: bool=False, with_target_cols: bool=False) -> Union[
    Tuple[np.ndarray, np.ndarray],
    Tuple[np.ndarray, np.ndarray, np.ndarray],
    Tuple[np.ndarray, np.ndarray, np.ndarray, List[str]]
]:
    """
    Loads the custom wavelength data

    Arg:
        device: Target device whose data to be loaded
        with_wavlength: flag that specifies whether to include wavelength data or not
        with_target_col: flag that specifiies whether to include column wavelenth


    Return:
        Tuple: (x, y) if with_wavelenght is false, (x, y, wavelength) if with_wavelength is true, (x, y, wavelength, target_cols) if with_target_cols is true
    """

    x, y = compiled_data[device.name]
    wavelength = compiled_wavelength[device.name]
    
    cols = ['titer_avg', 'score', 'plant_type', 'week', 'disease_class']

    out = []
    out.append(x)
    out.append(y)

    if with_wavelenght:
        out.append(wavelength)

    if with_target_cols:
        out.append(cols)

    return tuple(out)

    



if __name__ == '__main__':
    import os

    os.system('clear')

    x, y, wavelength, cols = load_spectral(Device.BIO_SCIENCE, with_wavelenght=True, with_target_cols=True)
    print(x.shape, y.shape, wavelength.shape, cols)
