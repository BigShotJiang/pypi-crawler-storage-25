//! Top-level engine: Facade over storage, retrieval, governance, and organization layers.
//!
//! Coordinates `BlockPool` + `BruteForceRetriever` + SLB + `VamanaIndex` + `TraceGraph` + WAL
//! behind a unified `mem_write` / `mem_read` API.
//!
//! ## Retrieval Pipeline (Chain of Responsibility)
//!
//! ```text
//! encoded query → PerTokenRetriever(Top5Avg) → SLB fallback → Vamana/BruteForce fallback
//! plain query   → SLB hot cache → RetrieverPipeline fallback
//! ```
//!
//! Encoded per-token keys are mean-pooled before they enter fixed-dimension
//! stages such as SLB, Vamana, and brute-force fallback.

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use tdb_core::error::{Result, TardigradeError};
use tdb_core::kv_pack::{KVLayerPayload, KVPack, PackId, PackReadResult};
use tdb_core::memory_cell::{MemoryCell, MemoryCellBuilder};
use tdb_core::synaptic_bank::SynapticBankEntry;
use tdb_core::{CellId, OwnerId, Tier};
use tdb_governance::decay::recency_decay;
use tdb_governance::scoring::ImportanceScorer;
use tdb_governance::tiers::TierStateMachine;
use tdb_index::trace::{EdgeType, TraceGraph};
use tdb_index::vamana::VamanaIndex;
use tdb_index::wal::{Wal, WalEntry};
use tdb_retrieval::attention::RetrievalResult;
use tdb_retrieval::key_view::{fixed_dim_key, is_encoded_per_token_key};
use tdb_retrieval::per_token::{
    HEADER_SENTINEL, HEADER_SIZE, N_TOKENS_IDX, PerTokenConfig, ScoringMode,
};
use tdb_retrieval::pipeline::RetrieverPipeline;
use tdb_retrieval::retriever::Retriever;
use tdb_retrieval::slb::SemanticLookasideBuffer;
use tdb_storage::block_pool::BlockPool;
use tdb_storage::deletion_log::DeletionLog;
use tdb_storage::synaptic_store::SynapticStore;
use tdb_storage::text_store::TextStore;

use crate::pack_directory::PackDirectory;
use crate::pack_materialization::{
    PackAccessSnapshot, PackCandidate, build_pack_read_result, keep_first_ranked_pack_candidates,
};

/// Default SLB capacity.
const DEFAULT_SLB_CAPACITY: usize = 4096;

/// Compute a mean-pooled key from a potentially per-token encoded key.
///
/// If the key is per-token encoded (has header), averages all token vectors.
/// If it's already a plain vector, returns it unchanged.
fn mean_pool_key(key: &[f32]) -> Vec<f32> {
    fixed_dim_key(key).unwrap_or_default()
}

fn should_index_for_retrieval(cell: &MemoryCell) -> bool {
    cell.token_span.0 == 0 || cell.layer == PACK_RETRIEVAL_LAYER
}

/// Default Vamana max degree.
const DEFAULT_VAMANA_MAX_DEGREE: usize = 16;
/// Default cell count threshold before activating Vamana.
const DEFAULT_VAMANA_THRESHOLD: usize = 10_000;
/// Sentinel token position marking a cell as a view key (not the canonical retrieval key).
///
/// View keys are additional retrieval vectors attached to a pack after initial write.
/// They share the same `PACK_RETRIEVAL_LAYER` but use this marker in `token_span.1`
/// to distinguish them from the canonical key (which uses `token_span.1 = 0`).
const VIEW_CELL_MARKER: u64 = u64::MAX;

/// Adapter: wraps `VamanaIndex` (from `tdb-index`) to implement `Retriever` (from `tdb-retrieval`).
///
/// Bridges the interface gap: Vamana returns `(CellId, f32)` tuples with no owner info,
/// while `Retriever` returns `RetrievalResult` with owner. The adapter sets owner to 0
/// — the pipeline caller is responsible for final owner filtering.
struct VamanaAdapter {
    inner: VamanaIndex,
}

impl Retriever for VamanaAdapter {
    fn query(
        &mut self,
        query_key: &[f32],
        k: usize,
        _owner_filter: Option<OwnerId>,
    ) -> Vec<RetrievalResult> {
        let query = mean_pool_key(query_key);
        self.inner
            .query(&query, k)
            .into_iter()
            .map(|(cell_id, score)| RetrievalResult { cell_id, owner: 0, score })
            .collect()
    }

    fn insert(&mut self, cell_id: CellId, _owner: OwnerId, key: &[f32]) {
        let key = mean_pool_key(key);
        self.inner.insert(cell_id, &key);
    }

    fn remove(&mut self, _cell_id: CellId) {
        // Vamana doesn't support removal — deleted cells are filtered at the
        // PackDirectory level. This is a no-op.
    }

    fn len(&self) -> usize {
        self.inner.len()
    }
}

/// Per-cell governance state tracked by the engine.
#[derive(Debug)]
struct CellGovernance {
    scorer: ImportanceScorer,
    tier_sm: TierStateMachine,
    days_since_update: f32,
}

/// A result from `mem_read` including the cell data and its retrieval score.
#[derive(Debug)]
pub struct ReadResult {
    pub cell: MemoryCell,
    pub score: f32,
    pub tier: Tier,
}

/// Default similarity threshold for auto-linking packs during write.
///
/// Used as the Python-side default when callers omit the threshold parameter.
pub const DEFAULT_AUTO_LINK_THRESHOLD: f32 = 250.0;

/// Result of writing a pack with auto-link discovery.
///
/// Contains the assigned pack ID and any packs that were automatically
/// linked based on retrieval similarity exceeding the threshold.
#[derive(Debug, Clone)]
pub struct PackWriteResult {
    /// The assigned pack ID for the newly written pack.
    pub pack_id: PackId,
    /// IDs of existing packs that were auto-linked to the new pack.
    pub linked_pack_ids: Vec<PackId>,
}

/// Snapshot of engine state for monitoring and diagnostics.
#[derive(Debug, Clone)]
pub struct EngineStatus {
    pub cell_count: usize,
    pub pack_count: usize,
    pub segment_count: usize,
    pub slb_occupancy: usize,
    pub slb_capacity: usize,
    pub vamana_active: bool,
    pub pipeline_stages: usize,
    pub governance_entries: usize,
    pub trace_edges: usize,
    /// Total on-disk bytes across all storage segments (active + sealed).
    /// Surfaces engine footprint for the `positioning/latency_first.md`
    /// claims and for the bench harness's footprint reporter.
    pub arena_bytes: u64,
    /// Derived: `arena_bytes / cell_count`, or 0 when `cell_count == 0`.
    /// Pre-computed so callers don't replicate the div-by-zero guard.
    pub arena_bytes_per_cell: u64,
}

/// A single write request for batch operations (Batch Command pattern).
///
/// Groups the parameters that `mem_write` accepts into a reusable struct
/// so multiple writes can be collected and committed with a single fsync.
#[derive(Debug, Clone)]
pub struct WriteRequest {
    pub owner: OwnerId,
    pub layer: u16,
    pub key: Vec<f32>,
    pub value: Vec<f32>,
    pub salience: f32,
    pub parent_cell_id: Option<CellId>,
}

/// Top-level `TardigradeDB` engine.
///
/// Facade pattern: single entry point coordinating storage, retrieval,
/// governance, and organization (trace + WAL).
///
/// ## Retrieval Architecture
///
/// ```text
/// query → SLB (cache, separate) → Pipeline [BruteForce, Vamana*] → merge
/// ```
///
/// The SLB is a separate LRU cache (needs direct access for warming on reads).
/// The [`RetrieverPipeline`] chains cold-path retrievers via the [`Retriever`] trait.
/// Vamana is lazily activated when cell count crosses the threshold.
/// Sentinel layer index for KV Pack retrieval key cells.
const PACK_RETRIEVAL_LAYER: u16 = 0xFFFE;

/// Hours per simulated day, for converting sweep cadence units.
const HOURS_PER_DAY: f32 = 24.0;

pub struct Engine {
    pool: BlockPool,
    /// Cold-path retrieval: `BruteForce` + Vamana (when active).
    pipeline: RetrieverPipeline,
    /// Hot-path cache: separate from pipeline for direct LRU warming on reads/writes.
    slb: SemanticLookasideBuffer,
    vamana: Option<VamanaIndex>,
    trace: TraceGraph,
    wal: Wal,
    synaptic_store: SynapticStore,
    governance: HashMap<CellId, CellGovernance>,
    next_id: CellId,
    dir: PathBuf,
    vamana_threshold: usize,
    /// Private pack membership repository with forward and reverse lookup.
    pack_directory: PackDirectory,
    next_pack_id: PackId,
    /// Key dimension (detected from first write, used for SLB/Vamana init).
    key_dim: Option<usize>,
    /// Per-token retrieval config (stored for pipeline rebuild on refresh).
    per_token_config: PerTokenConfig,
    /// Optional vague-query refinement applied after first-stage retrieval (Strategy pattern).
    refinement_strategy: Box<dyn tdb_retrieval::refinement::RefinementStrategy>,
    /// Durable text store for KV pack fact text.
    text_store: TextStore,
    /// Durable deletion log for pack deletions.
    deletion_log: DeletionLog,
    /// Enable corpus-mean distance reweighting of per-token scores (Decorator pattern).
    ///
    /// When `true`, each token's contribution is scaled by
    /// `1 - cosine(token, corpus_mean)` before aggregation — distinctive tokens
    /// carry more weight than tokens aligned with the mean activation.
    token_reweighting: bool,
    /// Optional streaming-ingest write buffer. When `Some`,
    /// [`Engine::mem_write_pack`] appends to the buffer and returns
    /// the pre-assigned pack id synchronously; the actual fsync is
    /// deferred until the buffer reaches its size threshold or
    /// [`Engine::flush_buffer`] / [`Engine::flush`] is called.
    write_buffer: Option<WriteBuffer>,
    /// Durable action scheduler. Persists pending actions to a
    /// JSON sidecar so a scheduled action survives engine reopen.
    scheduler: crate::scheduler::Scheduler,
}

/// Configuration for the optional streaming-ingest write buffer.
///
/// Buffered writes collapse N pack fsyncs into one per batch.
/// Trade-off: queries do not see a pack until the buffer is
/// flushed (or auto-flushed when `max_batch_size` is reached).
///
/// Picked at `Engine::open_with_write_buffer` time; cannot be
/// changed afterwards without reopening the engine.
#[derive(Debug, Clone, Copy)]
pub struct BufferConfig {
    /// Auto-flush when this many packs are buffered. Picking a
    /// value matters: small values reduce visibility latency but
    /// give up fsync amortisation; large values amortise harder
    /// but defer durability longer.
    pub max_batch_size: usize,
    /// Idle-timer flush (milliseconds). `0` disables the timer
    /// — only `max_batch_size` and explicit flush trigger writes.
    /// (Timer-driven flush requires a background thread; deferred
    /// to a follow-up commit. The field is reserved here so the
    /// configuration shape is stable.)
    pub max_idle_ms: u64,
}

/// Internal: a bounded queue of pre-assigned `(pack_id, pack)`
/// pairs awaiting a coalesced fsync.
#[derive(Debug)]
struct WriteBuffer {
    config: BufferConfig,
    pending: Vec<(PackId, KVPack)>,
}

impl WriteBuffer {
    fn new(config: BufferConfig) -> Self {
        Self { config, pending: Vec::with_capacity(config.max_batch_size) }
    }
}

/// Per-pack metadata stitched together during a coalesced flush so
/// all in-memory bookkeeping (pipeline, slb, governance,
/// `pack_directory`) can run in one pass after the single fsync.
struct PackInfo {
    pack_id: PackId,
    owner: tdb_core::OwnerId,
    retrieval_key: Vec<f32>,
    retrieval_cell_id: CellId,
    cell_ids: Vec<CellId>,
    scorer: ImportanceScorer,
    tier_sm: TierStateMachine,
}

impl Engine {
    /// Open or create an engine at the given directory path.
    pub fn open(dir: &Path) -> Result<Self> {
        Self::open_with_options(dir, DEFAULT_VAMANA_THRESHOLD, None)
    }

    /// Open with a custom segment size threshold (for testing segment rollover).
    pub fn open_with_segment_size(dir: &Path, segment_size: u64) -> Result<Self> {
        Self::open_with_options(dir, DEFAULT_VAMANA_THRESHOLD, Some(segment_size))
    }

    /// Open with a custom Vamana activation threshold.
    pub fn open_with_vamana_threshold(dir: &Path, threshold: usize) -> Result<Self> {
        Self::open_with_options(dir, threshold, None)
    }

    /// Configure the post-retrieval refinement strategy (vague-query rescue).
    ///
    /// Default is `RefinementMode::None`. See `tdb_retrieval::refinement` for
    /// available strategies (mean-centering, latent-space PRF).
    pub fn set_refinement_mode(&mut self, mode: tdb_retrieval::refinement::RefinementMode) {
        use tdb_retrieval::refinement::RefinementMode;
        let strategy: Box<dyn tdb_retrieval::refinement::RefinementStrategy> = match mode {
            RefinementMode::None => Box::new(tdb_retrieval::refinement::NoOpStrategy),
            RefinementMode::MeanCentered => {
                Box::new(tdb_retrieval::refinement::MeanCenteredStrategy)
            }
            RefinementMode::LatentPrf { alpha, beta, k_prime } => {
                Box::new(tdb_retrieval::refinement::LatentPrfStrategy { alpha, beta, k_prime })
            }
        };
        self.refinement_strategy = strategy;
    }

    /// Replace the refinement strategy with a trait object directly (Strategy pattern).
    pub fn set_refinement_strategy(
        &mut self,
        strategy: Box<dyn tdb_retrieval::refinement::RefinementStrategy>,
    ) {
        self.refinement_strategy = strategy;
    }

    /// Currently configured refinement mode as an enum (backwards compat).
    pub fn refinement_mode(&self) -> tdb_retrieval::refinement::RefinementMode {
        match self.refinement_strategy.name() {
            "none" => tdb_retrieval::refinement::RefinementMode::None,
            "centered" => tdb_retrieval::refinement::RefinementMode::MeanCentered,
            // For PRF we return defaults — the exact params aren't recoverable from the trait.
            _ => tdb_retrieval::refinement::RefinementMode::LatentPrf {
                alpha: 0.7,
                beta: 0.3,
                k_prime: 3,
            },
        }
    }

    /// Currently configured refinement mode name (for Python bindings).
    pub fn refinement_mode_name(&self) -> &'static str {
        self.refinement_strategy.name()
    }

    /// Enable or disable corpus-mean distance token importance reweighting.
    ///
    /// When enabled, each per-token score is multiplied by
    /// `1 - cosine(token, corpus_mean)` before aggregation. Tokens that are
    /// close to the mean activation are downweighted; distinctive tokens carry
    /// more retrieval signal. See `tdb_retrieval::token_weighter`.
    pub fn set_token_reweighting(&mut self, enabled: bool) {
        self.token_reweighting = enabled;
    }

    /// Whether corpus-mean distance token importance reweighting is enabled.
    pub fn token_reweighting(&self) -> bool {
        self.token_reweighting
    }

    fn open_with_options(
        dir: &Path,
        vamana_threshold: usize,
        segment_size: Option<u64>,
    ) -> Result<Self> {
        // Open durable backing stores (files + WAL handle).
        let pool = match segment_size {
            Some(size) => BlockPool::open_with_segment_size(dir, size)?,
            None => BlockPool::open(dir)?,
        };
        let synaptic_store =
            SynapticStore::open(dir).map_err(|e| TardigradeError::Io { source: e })?;
        let wal = Wal::open(dir).map_err(|e| TardigradeError::WalRecovery(e.to_string()))?;
        let text_store = TextStore::open(dir).map_err(|e| TardigradeError::Io { source: e })?;
        let deletion_log = DeletionLog::open(dir).map_err(|e| TardigradeError::Io { source: e })?;

        let per_token_config = PerTokenConfig::default();
        let pipeline = Self::build_default_pipeline(&per_token_config);

        // Construct with empty derived state, then rebuild via refresh().
        // DRY: open and refresh share the same Memento rebuild path
        // (reindex_cell, pack_directory scan, WAL replay, deletion filter).
        let mut engine = Self {
            pool,
            pipeline,
            slb: SemanticLookasideBuffer::new(DEFAULT_SLB_CAPACITY, 128),
            vamana: None,
            trace: TraceGraph::new(),
            wal,
            synaptic_store,
            governance: HashMap::new(),
            next_id: 0,
            dir: dir.to_path_buf(),
            vamana_threshold,
            pack_directory: PackDirectory::new(),
            next_pack_id: 0,
            key_dim: None,
            per_token_config,
            refinement_strategy: Box::new(tdb_retrieval::refinement::NoOpStrategy),
            text_store,
            deletion_log,
            token_reweighting: false,
            write_buffer: None,
            scheduler: crate::scheduler::Scheduler::open(dir)?,
        };

        engine.refresh()?;

        Ok(engine)
    }

    /// Open an engine with a streaming-ingest write buffer enabled.
    ///
    /// Writes via [`Engine::mem_write_pack`] return their assigned
    /// pack id synchronously but defer the fsync until the buffer
    /// reaches `config.max_batch_size` or [`Engine::flush_buffer`]
    /// is called. [`Engine::flush`] also drains the buffer, so any
    /// existing flush-as-durability-barrier code keeps working.
    ///
    /// Consumers expecting reads to see their writes immediately
    /// should leave the buffer off (`Engine::open`).
    ///
    /// Reliability contract (per CLAUDE.md):
    /// - Unbuffered writes: confirmed-immediately at fsync.
    /// - Buffered writes: confirmed-on-flush. A crash before flush
    ///   loses the buffered packs by design.
    pub fn open_with_write_buffer(dir: &Path, config: BufferConfig) -> Result<Self> {
        let mut engine = Self::open(dir)?;
        engine.write_buffer = Some(WriteBuffer::new(config));
        Ok(engine)
    }

    /// Re-sync in-memory state from disk without dropping the instance.
    ///
    /// Full **Memento** rebuild: rescans segments, rebuilds the retrieval
    /// pipeline from scratch (`PerToken` + `BruteForce`), re-populates all
    /// cells into both pipeline and SLB, replays the WAL, refreshes
    /// governance, rebuilds `pack_directory`, and re-syncs backing stores.
    /// Vamana is reset and re-activated lazily if cell count exceeds
    /// threshold. After this returns, the engine reflects writes performed
    /// by other [`Engine`] handles at the same path — same guarantee as
    /// a fresh [`open`](Self::open).
    ///
    /// **Idempotency:** `refresh().refresh()` is identical to a single
    /// `refresh()`.
    ///
    /// **Concurrency:** takes `&mut self`. Caller must ensure no other
    /// reader holds a borrow.
    pub fn refresh(&mut self) -> Result<()> {
        // 1. Rescan segments — picks up new cells written by another handle.
        self.pool.refresh_index()?;

        // 2. Detect whether the SLB needs rebuilding at a different dimension.
        //    If the engine was opened empty, the SLB defaults to dim=128. When
        //    refresh discovers cells written by another handle whose mean-pooled
        //    key has a different dim, the SLB's INT8 dot product would panic.
        //    Detect the dim from the first new indexable cell and rebuild SLB
        //    in place if needed.
        let known: std::collections::HashSet<CellId> = self.governance.keys().copied().collect();
        let all_cells: Vec<CellId> = self.pool.iter_cell_ids().collect();

        let mut observed_dim: Option<usize> = None;
        for cell_id in &all_cells {
            if known.contains(cell_id) {
                continue;
            }
            let cell = self.pool.get(*cell_id)?;
            if should_index_for_retrieval(&cell) {
                observed_dim = Some(mean_pool_key(&cell.key).len());
                break;
            }
        }
        if let Some(new_dim) = observed_dim
            && new_dim != self.slb.dim()
        {
            let cap = self.slb.capacity();
            self.slb = SemanticLookasideBuffer::new(cap, new_dim);
            self.key_dim = Some(new_dim);
        }

        // 3. Rebuild retrieval pipeline from scratch (Memento pattern).
        //    PerToken/BruteForce have no duplicate-insert protection, so we
        //    must start with empty stages and re-populate all cells below.
        self.pipeline = Self::build_default_pipeline(&self.per_token_config);
        self.vamana = None;

        // 4. Re-derive governance for new cells; re-populate pipeline for ALL cells.
        for cell_id in &all_cells {
            if known.contains(cell_id) {
                continue;
            }
            let cell = self.pool.get(*cell_id)?;
            self.reindex_cell(&cell);
            if cell.id >= self.next_id {
                self.next_id = cell.id + 1;
            }
        }

        // Re-populate rebuilt pipeline + SLB with previously-known cells.
        // Governance stays intact (accumulated importance scores preserved).
        for &cell_id in &known {
            if let Ok(cell) = self.pool.get(cell_id)
                && should_index_for_retrieval(&cell)
            {
                self.pipeline.insert(cell.id, cell.owner, &cell.key);
                let slb_key = mean_pool_key(&cell.key);
                self.slb.insert(cell.id, cell.owner, &slb_key);
            }
        }

        // 3. Rebuild pack_directory from current pool state. Idempotent —
        //    same cell set yields same directory.
        let mut pack_cells = Vec::new();
        for cell_id in &all_cells {
            if let Ok(cell) = self.pool.get(*cell_id) {
                let stored_pack_id = cell.token_span.0;
                if stored_pack_id > 0 || cell.layer == PACK_RETRIEVAL_LAYER {
                    pack_cells.push((stored_pack_id, cell.id));
                }
            }
        }
        let mut pack_directory = PackDirectory::from_cells(pack_cells);
        let next_pack_id = pack_directory.next_pack_id();

        // 4. Replay WAL again. TraceGraph.add_edge dedups so re-apply is safe.
        let entries = self.wal.replay().map_err(|e| TardigradeError::WalRecovery(e.to_string()))?;
        for entry in &entries {
            match entry {
                WalEntry::AddEdge { src, dst, edge_type, timestamp } => {
                    if let Some(et) = EdgeType::from_u8(*edge_type) {
                        self.trace.add_edge(*src, *dst, et, *timestamp);
                    }
                }
            }
        }

        // 5. Refresh persistent backing stores.
        self.text_store.refresh().map_err(|e| TardigradeError::Io { source: e })?;
        self.deletion_log.refresh().map_err(|e| TardigradeError::Io { source: e })?;

        // 6. Apply deletions to the rebuilt directory and text_store.
        for &pack_id in self.deletion_log.deleted_set() {
            pack_directory.remove_pack(pack_id);
            self.text_store.remove(pack_id);
        }

        // Commit the rebuilt pack directory + counter.
        self.pack_directory = pack_directory;
        self.next_pack_id = self.next_pack_id.max(next_pack_id);

        // 7. Re-check Vamana activation: try loading persisted index first,
        //    fall back to O(n²) rebuild only if no valid snapshot exists.
        if self.vamana.is_none() && self.pool.cell_count() >= self.vamana_threshold {
            let loaded = self.try_load_vamana()?;
            if !loaded {
                self.activate_vamana()?;
            }
        }

        // 8. Checkpoint WAL — all entries have been replayed into the in-memory
        //    TraceGraph. Truncating is safe: a crash during truncation means the
        //    next refresh re-applies edges that are deduplicated by add_edge.
        if !entries.is_empty() {
            self.wal.checkpoint().map_err(|e| TardigradeError::WalRecovery(e.to_string()))?;
        }

        Ok(())
    }

    /// Re-index a single cell into pipeline + SLB + governance.
    ///
    /// **DRY hook** shared by `open_with_options` and `refresh()` — both
    /// rebuild paths must compute identical state for the same input cell.
    /// Idempotent at the call-site level: callers ensure they don't pass
    /// the same cell twice.
    fn reindex_cell(&mut self, cell: &MemoryCell) {
        if should_index_for_retrieval(cell) {
            let slb_key = mean_pool_key(&cell.key);
            if self.key_dim.is_none() {
                self.key_dim = Some(slb_key.len());
            }
            self.pipeline.insert(cell.id, cell.owner, &cell.key);
            self.slb.insert(cell.id, cell.owner, &slb_key);
        }
        let scorer = ImportanceScorer::new(cell.meta.importance);
        let tier_sm = TierStateMachine::with_tier(cell.meta.tier);
        self.governance.insert(cell.id, CellGovernance { scorer, tier_sm, days_since_update: 0.0 });
    }

    /// Write key/value vectors to the engine. Returns the assigned cell ID.
    ///
    /// `parent_cell_id`: optional causal parent for Trace graph edges.
    pub fn mem_write(
        &mut self,
        owner: OwnerId,
        layer: u16,
        key: &[f32],
        value: Vec<f32>,
        salience: f32,
        parent_cell_id: Option<CellId>,
    ) -> Result<CellId> {
        let id = self.next_id;
        self.next_id += 1;

        // Detect key dimension on first write (use mean-pooled dim for SLB).
        if self.key_dim.is_none() {
            let mean_dim = mean_pool_key(key).len();
            self.key_dim = Some(mean_dim);
            self.slb = SemanticLookasideBuffer::new(DEFAULT_SLB_CAPACITY, mean_dim);
        }

        let now_nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos() as u64);

        // Compute governance before persisting (Memento rebuild requirement).
        let mut scorer = ImportanceScorer::new(salience);
        scorer.on_update();
        let mut tier_sm = TierStateMachine::new();
        tier_sm.evaluate(scorer.importance());

        let cell = MemoryCellBuilder::new(id, owner, layer, key.to_vec(), value)
            .importance(scorer.importance())
            .tier(tier_sm.current())
            .created_at(now_nanos)
            .updated_at(now_nanos)
            .build();

        // Persist to block pool.
        self.pool.append(&cell)?;

        // Index for retrieval.
        // Pipeline gets the raw key (PerTokenRetriever decodes per-token encoding).
        self.pipeline.insert(id, owner, key);

        // SLB gets a mean-pooled summary (it needs fixed-dim vectors for INT8 scoring).
        let slb_key = mean_pool_key(key);
        self.slb.insert(id, owner, &slb_key);

        self.governance.insert(id, CellGovernance { scorer, tier_sm, days_since_update: 0.0 });

        // Trace graph: log causal edge via WAL (Observer pattern).
        if let Some(parent_id) = parent_cell_id {
            let wal_entry = WalEntry::AddEdge {
                src: id,
                dst: parent_id,
                edge_type: EdgeType::CausedBy as u8,
                timestamp: now_nanos,
            };
            self.wal.append(&wal_entry).map_err(|e| TardigradeError::WalRecovery(e.to_string()))?;
            self.trace.add_edge(id, parent_id, EdgeType::CausedBy, now_nanos);
        }

        // Lazy Vamana activation: build when cell count crosses threshold.
        if self.vamana.is_none() && self.pool.cell_count() >= self.vamana_threshold {
            self.activate_vamana()?;
        }

        Ok(id)
    }

    /// Write multiple cells in a single batch with one fsync (Batch Command pattern).
    ///
    /// All cells are persisted to the block pool in one operation, then indexed
    /// into the retrieval pipeline, SLB, and governance. Causal edges (if any)
    /// are written to the WAL after the batch is persisted.
    ///
    /// Throughput: ~80us/cell amortized vs ~8ms/cell for individual writes.
    pub fn mem_write_batch(&mut self, requests: &[WriteRequest]) -> Result<Vec<CellId>> {
        if requests.is_empty() {
            return Ok(Vec::new());
        }

        // Detect key dimension on first write (use mean-pooled dim for SLB).
        if self.key_dim.is_none() {
            let mean_dim = mean_pool_key(&requests[0].key).len();
            self.key_dim = Some(mean_dim);
            self.slb = SemanticLookasideBuffer::new(DEFAULT_SLB_CAPACITY, mean_dim);
        }

        let now_nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos() as u64);

        // Phase 1: Build all cells and compute governance (in memory, no I/O).
        let mut cells = Vec::with_capacity(requests.len());
        let mut gov_entries = Vec::with_capacity(requests.len());

        for req in requests {
            let id = self.next_id;
            self.next_id += 1;

            let mut scorer = ImportanceScorer::new(req.salience);
            scorer.on_update();
            let mut tier_sm = TierStateMachine::new();
            tier_sm.evaluate(scorer.importance());

            let cell = MemoryCellBuilder::new(
                id,
                req.owner,
                req.layer,
                req.key.clone(),
                req.value.clone(),
            )
            .importance(scorer.importance())
            .tier(tier_sm.current())
            .created_at(now_nanos)
            .updated_at(now_nanos)
            .build();

            gov_entries.push((
                id,
                req.owner,
                req.key.clone(),
                req.parent_cell_id,
                CellGovernance { scorer, tier_sm, days_since_update: 0.0 },
            ));
            cells.push(cell);
        }

        // Phase 2: Persist all cells with single fsync.
        let ids = self.pool.append_batch(&cells)?;

        // Phase 3: Index all cells into retrieval + governance (in memory, fast).
        for (id, owner, key, parent_cell_id, gov) in gov_entries {
            self.pipeline.insert(id, owner, &key);
            let slb_key = mean_pool_key(&key);
            self.slb.insert(id, owner, &slb_key);
            self.governance.insert(id, gov);

            // Causal edges via WAL.
            if let Some(parent_id) = parent_cell_id {
                let wal_entry = WalEntry::AddEdge {
                    src: id,
                    dst: parent_id,
                    edge_type: EdgeType::CausedBy as u8,
                    timestamp: now_nanos,
                };
                self.wal
                    .append(&wal_entry)
                    .map_err(|e| TardigradeError::WalRecovery(e.to_string()))?;
                self.trace.add_edge(id, parent_id, EdgeType::CausedBy, now_nanos);
            }
        }

        // Lazy Vamana activation.
        if self.vamana.is_none() && self.pool.cell_count() >= self.vamana_threshold {
            self.activate_vamana()?;
        }

        Ok(ids)
    }

    /// Read the top-k most relevant cells for a query key.
    ///
    /// Encoded per-token queries run the [`RetrieverPipeline`] first so
    /// `PerTokenRetriever(Top5Avg)` scores the raw token matrix. The SLB uses
    /// mean-pooled summaries only as a fallback/hot cache because it requires
    /// fixed-size vectors. Results are merged, deduplicated, scored with
    /// recency decay, and filtered by owner.
    pub fn mem_read(
        &mut self,
        query_key: &[f32],
        k: usize,
        owner_filter: Option<OwnerId>,
    ) -> Result<Vec<ReadResult>> {
        if query_key.is_empty() {
            return Ok(Vec::new());
        }

        let is_per_token_query = is_encoded_per_token_key(query_key);

        // Phase 1: SLB hot cache (uses mean-pooled query for fixed-dim INT8 scoring).
        let slb_query = mean_pool_key(query_key);
        let mut candidates = Vec::new();

        if is_per_token_query {
            // Encoded per-token queries require max-sim scoring. SLB can fill gaps,
            // but it must not suppress the cold per-token retriever.
            let source = crate::cell_source_pool::BlockPoolCellSource::new(&self.pool);
            let cold_results =
                self.pipeline.query_with_source(query_key, k * 2, owner_filter, Some(&source));
            let mut seen: std::collections::HashSet<CellId> = std::collections::HashSet::new();
            for r in cold_results {
                if seen.insert(r.cell_id) {
                    candidates.push(r);
                }
            }

            if candidates.len() < k && !self.slb.is_empty() {
                for r in self.slb.query(&slb_query, k * 2) {
                    if seen.insert(r.cell_id) {
                        candidates.push(r);
                    }
                }
            }
        } else {
            candidates =
                if self.slb.is_empty() { Vec::new() } else { self.slb.query(&slb_query, k * 2) };

            // Phase 2: Cold-path pipeline (PerToken + BruteForce) — gets raw query.
            if candidates.len() < k {
                let source = crate::cell_source_pool::BlockPoolCellSource::new(&self.pool);
                let cold_results =
                    self.pipeline.query_with_source(query_key, k * 2, owner_filter, Some(&source));
                // Deduplicate against SLB results.
                let seen: std::collections::HashSet<CellId> =
                    candidates.iter().map(|r| r.cell_id).collect();
                for r in cold_results {
                    if !seen.contains(&r.cell_id) {
                        candidates.push(r);
                    }
                }
            }
        }

        // Optional vague-query refinement: re-score / re-query before governance.
        // NoOpStrategy short-circuits via is_noop() — zero overhead on the default path.
        if !self.refinement_strategy.is_noop() && is_per_token_query {
            let pool_ref = &self.pool;
            let strategy = &self.refinement_strategy;
            if let Some(per_token) =
                self.pipeline.first_stage_as_mut::<tdb_retrieval::per_token::PerTokenRetriever>()
            {
                let source = crate::cell_source_pool::BlockPoolCellSource::new(pool_ref);
                candidates = strategy.refine(
                    per_token,
                    query_key,
                    candidates,
                    k * 2,
                    owner_filter,
                    Some(&source),
                );
            }
        }

        // Materialize all candidates with governance-adjusted scores.
        // Cannot early-exit before the final sort: tier boost may reorder results.
        let mut results = Vec::with_capacity(candidates.len());
        for rr in &candidates {
            let (decay_factor, tier) =
                self.governance.get(&rr.cell_id).map_or((1.0, Tier::Draft), |g| {
                    (recency_decay(g.days_since_update), g.tier_sm.current())
                });

            let adjusted_score = rr.score * decay_factor * tier.retrieval_boost();

            match self.pool.get(rr.cell_id) {
                Ok(cell) => {
                    if let Some(filter_owner) = owner_filter
                        && cell.owner != filter_owner
                    {
                        continue;
                    }

                    results.push(ReadResult { cell, score: adjusted_score, tier });
                }
                Err(TardigradeError::CellNotFound(_)) => {}
                Err(e) => return Err(e),
            }
        }

        // Sort by adjusted score, truncate, then apply governance side effects.
        results.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));
        results.truncate(k);

        for result in &results {
            if let Some(gov) = self.governance.get_mut(&result.cell.id) {
                gov.scorer.on_access();
                gov.tier_sm.evaluate(gov.scorer.importance());
            }
            let slb_key = mean_pool_key(&result.cell.key);
            self.slb.insert(result.cell.id, result.cell.owner, &slb_key);
        }

        Ok(results)
    }

    /// Read top-k cells using a raw per-token query matrix (Facade Simplification).
    ///
    /// Bypasses the Python-side `encode_per_token` round-trip: the caller passes
    /// the flat `n_tokens × dim` query matrix directly, and the engine builds the
    /// per-token encoded key in Rust before delegating to [`Self::mem_read`]. This
    /// eliminates a redundant Python encoding + Rust parsing cycle in the hot path.
    ///
    /// `query_tokens` length must equal `n_tokens * dim`.
    pub fn mem_read_tokens(
        &mut self,
        query_tokens: &[f32],
        n_tokens: usize,
        dim: usize,
        k: usize,
        owner_filter: Option<OwnerId>,
    ) -> Result<Vec<ReadResult>> {
        if n_tokens == 0 || dim == 0 || query_tokens.len() != n_tokens * dim {
            return Ok(Vec::new());
        }

        // Build the encoded key in-place: header + flattened tokens (one allocation).
        // The `n_tokens` slot is left at 0.0 — it does not survive Q4 round-trip
        // (see HEADER_SIZE docs in tdb-retrieval/per_token.rs). Decoders infer
        // `n` from `data.len() / dim`.
        let _ = n_tokens;
        let mut encoded = Vec::with_capacity(HEADER_SIZE + query_tokens.len());
        encoded.push(HEADER_SENTINEL);
        encoded.resize(N_TOKENS_IDX, 0.0);
        encoded.push(0.0);
        encoded.push(dim as f32);
        encoded.resize(HEADER_SIZE, 0.0);
        encoded.extend_from_slice(query_tokens);

        self.mem_read(&encoded, k, owner_filter)
    }

    /// Get transitive ancestors of a cell following `CausedBy` edges.
    pub fn trace_ancestors(&self, cell_id: CellId) -> Vec<CellId> {
        self.trace.ancestors(cell_id, EdgeType::CausedBy)
    }

    /// Whether the Vamana index is currently active.
    pub fn has_vamana(&self) -> bool {
        self.vamana.is_some()
    }

    /// Number of stages in the retrieval pipeline.
    pub fn pipeline_stage_count(&self) -> usize {
        self.pipeline.stage_count()
    }

    /// Get the current tier of a cell.
    pub fn cell_tier(&self, cell_id: CellId) -> Option<Tier> {
        self.governance.get(&cell_id).map(|g| g.tier_sm.current())
    }

    /// Get the current importance score of a cell.
    pub fn cell_importance(&self, cell_id: CellId) -> Option<f32> {
        self.governance.get(&cell_id).map(|g| g.scorer.importance())
    }

    /// Total number of cells in the engine.
    pub fn cell_count(&self) -> usize {
        self.pool.cell_count()
    }

    /// Directory path of this engine.
    pub fn dir(&self) -> &Path {
        &self.dir
    }

    /// Snapshot of engine state for monitoring and diagnostics.
    pub fn status(&self) -> EngineStatus {
        let cell_count = self.pool.cell_count();
        let arena_bytes = self.pool.arena_bytes();
        let arena_bytes_per_cell = if cell_count > 0 { arena_bytes / cell_count as u64 } else { 0 };
        EngineStatus {
            cell_count,
            pack_count: self.pack_directory.len(),
            segment_count: self.pool.segment_count(),
            slb_occupancy: self.slb.len(),
            slb_capacity: self.slb.capacity(),
            vamana_active: self.vamana.is_some(),
            pipeline_stages: self.pipeline.stage_count(),
            governance_entries: self.governance.len(),
            trace_edges: self.trace.edge_count(),
            arena_bytes,
            arena_bytes_per_cell,
        }
    }

    /// Explicit durability checkpoint (Write Fence / Barrier pattern).
    ///
    /// Ensures all durable components have fsynced. Individual writes already
    /// fsync on each operation, so this is a semantic guarantee: after `flush()`
    /// returns, reopening the engine will see all prior writes.
    ///
    /// Auto-drains the streaming write buffer if one is
    /// configured, so consumers using `flush()` as their durability
    /// barrier don't have to track the buffer separately.
    pub fn flush(&mut self) -> Result<()> {
        self.flush_buffer()?;
        self.wal.checkpoint()?;
        Ok(())
    }

    /// Snapshot the engine's persistent state into a portable tar
    /// archive at `out_path`.
    ///
    /// Flushes first, then packages the working directory under
    /// `engine_state/` alongside a versioned [`crate::snapshot::SnapshotManifest`]
    /// containing magic bytes, format version, codec identifiers,
    /// stats, and a SHA-256 of the payload. The archive is
    /// portable across machines so long as the receiving engine
    /// supports the same `format_version` and codecs.
    ///
    /// See [`crate::snapshot`] for the on-disk layout and
    /// reliability contract. Pair with [`Engine::restore_from`] for
    /// the read side.
    pub fn snapshot(
        &mut self,
        out_path: &std::path::Path,
    ) -> Result<crate::snapshot::SnapshotManifest> {
        self.flush()?;
        let stats = crate::snapshot::SnapshotStats {
            pack_count: self.pack_count(),
            owner_count: self.list_owners().len(),
        };
        crate::snapshot::write_snapshot(&self.dir, out_path, stats)
    }

    /// Restore a snapshot archive at `in_path` into `target_dir`,
    /// validate its manifest, and return the engine opened on the
    /// restored directory.
    ///
    /// `target_dir` must be empty or non-existent. Errors thrown
    /// during restore are typed: [`TardigradeError::NotATardigradeSnapshot`],
    /// [`TardigradeError::UnsupportedFormatVersion`],
    /// [`TardigradeError::SnapshotCodecMismatch`],
    /// [`TardigradeError::SnapshotIntegrity`].
    pub fn restore_from(in_path: &std::path::Path, target_dir: &std::path::Path) -> Result<Self> {
        let _manifest = crate::snapshot::read_snapshot(in_path, target_dir)?;
        Self::open(target_dir)
    }

    /// Simulate passage of time for governance decay.
    pub fn advance_days(&mut self, days: f32) {
        for gov in self.governance.values_mut() {
            let old_whole = gov.days_since_update as u32;
            gov.days_since_update += days;
            let new_whole = gov.days_since_update as u32;
            let elapsed = new_whole.saturating_sub(old_whole);
            if elapsed > 0 {
                gov.scorer.apply_daily_decay(elapsed);
                gov.tier_sm.evaluate(gov.scorer.importance());
            }
        }
    }

    /// Evict Draft-tier packs whose importance falls below the threshold.
    ///
    /// Only Draft-tier packs are eligible for eviction. Validated and Core
    /// packs are never evicted regardless of importance. When `owner_filter`
    /// is `Some`, only that owner's packs are considered. Returns the number
    /// of packs evicted.
    pub fn evict_draft_packs(
        &mut self,
        importance_threshold: f32,
        owner_filter: Option<OwnerId>,
    ) -> Result<usize> {
        let to_evict: Vec<PackId> = self
            .list_packs(owner_filter)
            .into_iter()
            .filter(|&(_, _, tier, importance)| {
                tier == Tier::Draft && importance < importance_threshold
            })
            .map(|(pack_id, _, _, _)| pack_id)
            .collect();

        let count = to_evict.len();
        for pack_id in to_evict {
            self.delete_pack(pack_id)?;
        }
        Ok(count)
    }

    /// Enqueue a [`crate::scheduler::ScheduledAction`] to fire at
    /// `fires_at`. The schedule is persisted to disk before this
    /// returns, so the action survives engine reopen. Returns the
    /// assigned id; pass it to [`Engine::cancel_scheduled`] to
    /// remove the entry before it fires.
    pub fn schedule(
        &mut self,
        fires_at: std::time::SystemTime,
        action: crate::scheduler::ScheduledAction,
    ) -> Result<crate::scheduler::ScheduledId> {
        self.scheduler.schedule(fires_at, action)
    }

    /// Cancel a previously-scheduled action. Returns `true` if a
    /// matching entry was found and removed, `false` if not.
    pub fn cancel_scheduled(&mut self, id: crate::scheduler::ScheduledId) -> Result<bool> {
        self.scheduler.cancel(id)
    }

    /// Return every pending scheduled entry, sorted by fire time
    /// ascending.
    #[must_use]
    pub fn list_scheduled(&self) -> Vec<crate::scheduler::ScheduledEntry> {
        self.scheduler.list()
    }

    /// Fire every scheduled action whose `fires_at <= now`,
    /// remove it from the schedule once execute returns
    /// successfully, and return the count of completed actions.
    ///
    /// **At-least-once across crashes.** Each entry stays in the
    /// durable schedule until *after* its action's execute call
    /// returns `Ok`. A crash between execute returning and the
    /// post-fire persist leaves the entry on disk; the next
    /// invocation will re-fire it. Combined with the idempotent
    /// [`crate::scheduler::ScheduledAction`] contract this yields
    /// fire-once-in-effect across process restarts.
    ///
    /// If an action's execute fails, its entry is left in the
    /// schedule (no entry is committed until *all* successful
    /// ones are batched into a single persist). The failure is
    /// surfaced to the caller. The maintenance worker logs and
    /// moves on; consumers calling this directly can retry.
    pub fn fire_due_scheduled(&mut self, now: std::time::SystemTime) -> Result<usize> {
        let due = self.scheduler.peek_due(now);
        let mut completed: Vec<crate::scheduler::ScheduledId> = Vec::with_capacity(due.len());
        for entry in &due {
            self.execute_scheduled_action(&entry.action)?;
            completed.push(entry.id);
        }
        let count = completed.len();
        self.scheduler.commit_fired(&completed)?;
        Ok(count)
    }

    fn execute_scheduled_action(
        &mut self,
        action: &crate::scheduler::ScheduledAction,
    ) -> Result<()> {
        match *action {
            crate::scheduler::ScheduledAction::EvictDraft { owner, threshold } => {
                self.evict_draft_packs(threshold, Some(owner))?;
                Ok(())
            }
        }
    }

    /// Run a governance sweep synchronously: apply time-decay to all
    /// owners, then evict Draft-tier packs that fall below
    /// `eviction_threshold`. Returns the number of packs evicted.
    ///
    /// Equivalent to one tick of the background
    /// [`crate::maintenance::MaintenanceWorker`], but blocking. Use
    /// when a known event (episode boundary, save-game checkpoint,
    /// agent reset) should commit tier transitions before the next
    /// read instead of waiting for the next sweep interval.
    ///
    /// `hours` controls the simulated time advance — the daily decay
    /// curve fires once per integral day, so a value below 24 advances
    /// the clock without applying decay this call. Pass `0.0` to skip
    /// decay and just run the eviction pass.
    pub fn sweep_now(&mut self, hours: f32, eviction_threshold: f32) -> Result<usize> {
        if hours > 0.0 {
            self.advance_days(hours / HOURS_PER_DAY);
        }
        self.evict_draft_packs(eviction_threshold, None)
    }

    /// Compact storage segments by rewriting live cells and deleting dead ones.
    ///
    /// Computes the live cell set from the current `PackDirectory`, then
    /// delegates to `BlockPool::compact`. Returns compaction statistics.
    pub fn compact(&mut self) -> Result<tdb_storage::block_pool::CompactionResult> {
        let live_cell_ids: std::collections::HashSet<CellId> =
            self.pack_directory.all_cell_ids().collect();
        self.pool.compact(&live_cell_ids)
    }

    /// Store a `SynapticBankEntry` (`LoRA` adapter) for an agent/user.
    pub fn store_synapsis(&mut self, entry: &SynapticBankEntry) -> Result<()> {
        self.synaptic_store.append(entry).map_err(|e| TardigradeError::Io { source: e })
    }

    /// Load all `SynapticBankEntry` records for a given owner.
    pub fn load_synapsis(&self, owner: OwnerId) -> Result<Vec<SynapticBankEntry>> {
        self.synaptic_store.load_by_owner(owner).map_err(|e| TardigradeError::Io { source: e })
    }

    // ── KV Pack API (Repository pattern) ──────────────────────────────────

    /// Store a complete multi-layer KV cache as a single atomic pack.
    ///
    /// All layers are persisted with a single fsync. The retrieval key is
    /// indexed for search. Returns the assigned pack ID.
    ///
    /// When the engine was opened with
    /// [`Engine::open_with_write_buffer`], this method instead
    /// appends the pack to the buffer, returns its pre-assigned
    /// pack id, and defers the fsync until the buffer reaches
    /// `max_batch_size` or [`Engine::flush_buffer`] is called.
    pub fn mem_write_pack(&mut self, pack: &KVPack) -> Result<PackId> {
        if self.write_buffer.is_some() {
            return self.enqueue_buffered_pack(pack);
        }
        let pack_id = self.next_pack_id;
        self.next_pack_id += 1;

        let now_nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos() as u64);

        // Detect key dimension from retrieval key.
        let retrieval_key_pooled = mean_pool_key(&pack.retrieval_key);
        if self.key_dim.is_none() {
            let dim = retrieval_key_pooled.len();
            self.key_dim = Some(dim);
            self.slb = SemanticLookasideBuffer::new(DEFAULT_SLB_CAPACITY, dim);
        }

        // Build cells: one for retrieval key + one per layer payload.
        let mut cells = Vec::with_capacity(1 + pack.layers.len());
        let mut cell_ids = Vec::with_capacity(1 + pack.layers.len());

        // Retrieval key cell (sentinel layer = PACK_RETRIEVAL_LAYER).
        let retrieval_cell_id = self.next_id;
        self.next_id += 1;

        let mut scorer = ImportanceScorer::new(pack.salience);
        scorer.on_update();
        let mut tier_sm = TierStateMachine::new();
        tier_sm.evaluate(scorer.importance());

        // Store full per-token encoded key in the cell (for PerTokenRetriever scoring).
        cells.push(
            MemoryCellBuilder::new(
                retrieval_cell_id,
                pack.owner,
                PACK_RETRIEVAL_LAYER,
                pack.retrieval_key.clone(),
                vec![], // no value for retrieval cell
            )
            .importance(scorer.importance())
            .tier(tier_sm.current())
            .token_span(pack_id, 0) // pack_id stored for cross-session rebuild
            .created_at(now_nanos)
            .updated_at(now_nanos)
            .build(),
        );
        cell_ids.push(retrieval_cell_id);

        // Layer payload cells.
        for layer in &pack.layers {
            let cell_id = self.next_id;
            self.next_id += 1;

            cells.push(
                MemoryCellBuilder::new(
                    cell_id,
                    pack.owner,
                    layer.layer_idx,
                    pack.retrieval_key.clone(),
                    layer.data.clone(),
                )
                .importance(scorer.importance())
                .tier(tier_sm.current())
                .token_span(pack_id, 0)
                .created_at(now_nanos)
                .updated_at(now_nanos)
                .build(),
            );
            cell_ids.push(cell_id);
        }

        // Persist atomically (single fsync).
        self.pool.append_batch(&cells)?;

        // Persist fact text if provided.
        if let Some(ref text) = pack.text {
            self.text_store.store(pack_id, text).map_err(|e| TardigradeError::Io { source: e })?;
        }

        // Index only the retrieval cell. Layer payload cells are persisted for
        // reconstruction, not search signal.
        let slb_key = mean_pool_key(&pack.retrieval_key);
        self.pipeline.insert(retrieval_cell_id, pack.owner, &pack.retrieval_key);
        self.slb.insert(retrieval_cell_id, pack.owner, &slb_key);

        // Governance for the pack (tracked on retrieval cell).
        self.governance
            .insert(retrieval_cell_id, CellGovernance { scorer, tier_sm, days_since_update: 0.0 });

        // Pack index.
        self.pack_directory.insert_pack(pack_id, cell_ids);

        Ok(pack_id)
    }

    /// Enqueue a pack into the streaming write buffer.
    ///
    /// Pre-assigns the pack id, clones the pack into the buffer,
    /// and auto-flushes when the buffer reaches `max_batch_size`.
    /// Called by [`Engine::mem_write_pack`] when a buffer is
    /// configured.
    fn enqueue_buffered_pack(&mut self, pack: &KVPack) -> Result<PackId> {
        let pack_id = self.next_pack_id;
        self.next_pack_id += 1;

        let should_flush = {
            let buf = self
                .write_buffer
                .as_mut()
                .expect("enqueue_buffered_pack called without a write buffer");
            buf.pending.push((pack_id, pack.clone()));
            buf.pending.len() >= buf.config.max_batch_size
        };

        if should_flush {
            self.flush_buffer()?;
        }
        Ok(pack_id)
    }

    /// Drain the streaming write buffer and persist every pending
    /// pack with a single coalesced fsync.
    ///
    /// No-op when the buffer is empty or when the engine was opened
    /// without a buffer. Idempotent — calling repeatedly with an
    /// empty buffer is safe and free.
    pub fn flush_buffer(&mut self) -> Result<()> {
        let drained: Vec<(PackId, KVPack)> = match self.write_buffer.as_mut() {
            Some(buf) if !buf.pending.is_empty() => std::mem::take(&mut buf.pending),
            _ => return Ok(()),
        };
        self.persist_packs_coalesced(&drained)
    }

    /// Persist a slice of `(pack_id, pack)` tuples with a single
    /// `pool.append_batch` fsync. The pack ids must already be
    /// reserved (we do not increment `next_pack_id` here).
    fn persist_packs_coalesced(&mut self, packs: &[(PackId, KVPack)]) -> Result<()> {
        if packs.is_empty() {
            return Ok(());
        }
        let now_nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos() as u64);

        // Detect key dimension from the first pack if not already
        // pinned (mirrors the single-pack path).
        if self.key_dim.is_none() {
            let dim = mean_pool_key(&packs[0].1.retrieval_key).len();
            self.key_dim = Some(dim);
            self.slb = SemanticLookasideBuffer::new(DEFAULT_SLB_CAPACITY, dim);
        }

        let (all_cells, infos, texts) = self.build_packs_for_persist(packs, now_nanos);

        // Single coalesced fsync for all cells across all packs.
        self.pool.append_batch(&all_cells)?;
        if !texts.is_empty() {
            self.text_store.store_batch(&texts).map_err(|e| TardigradeError::Io { source: e })?;
        }

        // Index in-memory state for each pack.
        for info in infos {
            let slb_key = mean_pool_key(&info.retrieval_key);
            self.pipeline.insert(info.retrieval_cell_id, info.owner, &info.retrieval_key);
            self.slb.insert(info.retrieval_cell_id, info.owner, &slb_key);
            self.governance.insert(
                info.retrieval_cell_id,
                CellGovernance {
                    scorer: info.scorer,
                    tier_sm: info.tier_sm,
                    days_since_update: 0.0,
                },
            );
            self.pack_directory.insert_pack(info.pack_id, info.cell_ids);
        }

        // Lazy Vamana activation.
        if self.vamana.is_none() && self.pool.cell_count() >= self.vamana_threshold {
            self.activate_vamana()?;
        }
        Ok(())
    }

    /// Pure-CPU phase of [`Engine::persist_packs_coalesced`]: turns
    /// pending packs into the flat cell vector to fsync, the
    /// per-pack `PackInfo` records for in-memory bookkeeping, and
    /// the text-store batch entries. No I/O happens here.
    fn build_packs_for_persist<'a>(
        &mut self,
        packs: &'a [(PackId, KVPack)],
        now_nanos: u64,
    ) -> (Vec<tdb_core::MemoryCell>, Vec<PackInfo>, Vec<(PackId, &'a str)>) {
        let mut all_cells: Vec<tdb_core::MemoryCell> = Vec::new();
        let mut infos: Vec<PackInfo> = Vec::with_capacity(packs.len());
        let mut texts: Vec<(PackId, &str)> = Vec::new();

        for (pack_id, pack) in packs {
            let retrieval_cell_id = self.next_id;
            self.next_id += 1;

            let mut scorer = ImportanceScorer::new(pack.salience);
            scorer.on_update();
            let mut tier_sm = TierStateMachine::new();
            tier_sm.evaluate(scorer.importance());

            let mut cell_ids = Vec::with_capacity(1 + pack.layers.len());
            all_cells.push(
                MemoryCellBuilder::new(
                    retrieval_cell_id,
                    pack.owner,
                    PACK_RETRIEVAL_LAYER,
                    pack.retrieval_key.clone(),
                    vec![],
                )
                .importance(scorer.importance())
                .tier(tier_sm.current())
                .token_span(*pack_id, 0)
                .created_at(now_nanos)
                .updated_at(now_nanos)
                .build(),
            );
            cell_ids.push(retrieval_cell_id);

            for layer in &pack.layers {
                let cid = self.next_id;
                self.next_id += 1;
                all_cells.push(
                    MemoryCellBuilder::new(
                        cid,
                        pack.owner,
                        layer.layer_idx,
                        pack.retrieval_key.clone(),
                        layer.data.clone(),
                    )
                    .importance(scorer.importance())
                    .tier(tier_sm.current())
                    .token_span(*pack_id, 0)
                    .created_at(now_nanos)
                    .updated_at(now_nanos)
                    .build(),
                );
                cell_ids.push(cid);
            }

            if let Some(text) = pack.text.as_deref() {
                texts.push((*pack_id, text));
            }

            infos.push(PackInfo {
                pack_id: *pack_id,
                owner: pack.owner,
                retrieval_key: pack.retrieval_key.clone(),
                retrieval_cell_id,
                cell_ids,
                scorer,
                tier_sm,
            });
        }

        (all_cells, infos, texts)
    }

    /// Attach additional retrieval keys ("views") to an existing pack.
    ///
    /// Each view key creates a new cell at `PACK_RETRIEVAL_LAYER` with the
    /// `VIEW_CELL_MARKER` sentinel in `token_span.1`. These cells are indexed
    /// in the retrieval pipeline and SLB, so the pack becomes discoverable
    /// via any of its view keys in addition to the canonical retrieval key.
    ///
    /// Returns the number of view keys successfully added.
    ///
    /// # Errors
    ///
    /// Returns [`TardigradeError::PackNotFound`] if `pack_id` does not exist
    /// in the pack directory.
    pub fn add_view_keys(&mut self, pack_id: PackId, view_keys: &[Vec<f32>]) -> Result<usize> {
        let cell_ids =
            self.pack_directory.cell_ids(pack_id).ok_or(TardigradeError::PackNotFound(pack_id))?;

        let canonical_cell_id = *cell_ids.first().ok_or(TardigradeError::PackNotFound(pack_id))?;
        let canonical = self.pool.get(canonical_cell_id)?;
        let owner = canonical.owner;

        let now_nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos() as u64);

        let mut count = 0;
        for vk in view_keys {
            let cell_id = self.next_id;
            self.next_id += 1;

            let cell =
                MemoryCellBuilder::new(cell_id, owner, PACK_RETRIEVAL_LAYER, vk.clone(), vec![])
                    .token_span(pack_id, VIEW_CELL_MARKER)
                    .created_at(now_nanos)
                    .updated_at(now_nanos)
                    .build();

            self.pool.append(&cell)?;
            self.pipeline.insert(cell_id, owner, vk);

            let slb_key = mean_pool_key(vk);
            self.slb.insert(cell_id, owner, &slb_key);

            self.pack_directory.add_cell(pack_id, cell_id);
            count += 1;
        }
        Ok(count)
    }

    /// Count the number of view keys attached to a pack.
    ///
    /// Returns 0 for a pack with only its canonical retrieval key.
    /// The count excludes the canonical retrieval cell — only additional
    /// view keys are counted.
    ///
    /// # Errors
    ///
    /// Returns [`TardigradeError::PackNotFound`] if `pack_id` does not exist.
    pub fn view_count(&self, pack_id: PackId) -> Result<usize> {
        let cell_ids =
            self.pack_directory.cell_ids(pack_id).ok_or(TardigradeError::PackNotFound(pack_id))?;

        let retrieval_cells = cell_ids
            .iter()
            .filter(|&&cid| self.pool.get(cid).is_ok_and(|c| c.layer == PACK_RETRIEVAL_LAYER))
            .count();

        Ok(retrieval_cells.saturating_sub(1))
    }

    /// Store a pack with automatic discovery and linking of similar existing packs.
    ///
    /// Before writing, queries existing packs for the same owner. Any candidate
    /// whose retrieval score meets or exceeds `auto_link_threshold` is linked to
    /// the new pack via a trace edge. This moves the Python-side auto-link logic
    /// into Rust for transactional safety and eliminates a Python-Rust round-trip.
    pub fn mem_write_pack_with_auto_link(
        &mut self,
        pack: &KVPack,
        auto_link_threshold: f32,
    ) -> Result<PackWriteResult> {
        let mut linked_pack_ids = Vec::new();

        if self.pack_count() > 0 {
            let candidates = self.mem_read_pack(&pack.retrieval_key, 1, Some(pack.owner))?;
            for candidate in &candidates {
                if candidate.score >= auto_link_threshold {
                    linked_pack_ids.push(candidate.pack.id);
                }
            }
        }

        let pack_id = self.mem_write_pack(pack)?;

        for &linked_id in &linked_pack_ids {
            self.add_pack_link(pack_id, linked_id)?;
        }

        Ok(PackWriteResult { pack_id, linked_pack_ids })
    }

    /// Retrieve the top-k KV Packs matching a query key.
    ///
    /// Returns complete packs with all layer payloads reconstructed.
    pub fn mem_read_pack(
        &mut self,
        query_key: &[f32],
        k: usize,
        owner_filter: Option<OwnerId>,
    ) -> Result<Vec<PackReadResult>> {
        let candidates = self.collect_pack_candidates(query_key, k, owner_filter);
        let candidates = self.deduplicate_pack_candidates(candidates, k, owner_filter);
        let mut results = Vec::with_capacity(k);

        for candidate in &candidates {
            let layers = self.hydrate_pack_layers(&candidate.cell_ids)?;
            let access = self.apply_pack_access_governance(candidate.retrieval_cell_id);
            let mut result = build_pack_read_result(candidate, layers, access);
            result.pack.text = self.text_store.get(candidate.pack_id).map(str::to_owned);
            results.push(result);
        }

        results.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));
        Ok(results)
    }

    /// Retrieve packs with trace-boosted scoring.
    ///
    /// Retrieves an expanded candidate set, boosts scores by trace link
    /// count (discovery hubs rank higher), then returns the top k.
    pub fn mem_read_pack_with_trace_boost(
        &mut self,
        query_key: &[f32],
        k: usize,
        owner_filter: Option<OwnerId>,
        boost_factor: f32,
    ) -> Result<Vec<PackReadResult>> {
        let k_expanded = k.saturating_mul(5).max(10);
        let candidates = self.collect_pack_candidates(query_key, k_expanded, owner_filter);
        let candidates = self.deduplicate_pack_candidates(candidates, k_expanded, owner_filter);

        // Materialize all expanded candidates with trace boost + tier boost.
        // Cannot truncate before governance: tier boost may reorder results.
        let mut results = Vec::with_capacity(candidates.len());
        for mut candidate in candidates {
            let link_count = self.pack_links(candidate.pack_id).len() as f32;
            candidate.score *= 1.0 + link_count * boost_factor;

            let layers = self.hydrate_pack_layers(&candidate.cell_ids)?;
            let access = self.apply_pack_access_governance(candidate.retrieval_cell_id);
            let mut result = build_pack_read_result(&candidate, layers, access);
            result.pack.text = self.text_store.get(candidate.pack_id).map(str::to_owned);
            results.push(result);
        }

        results.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));
        results.truncate(k);
        Ok(results)
    }

    /// Trace-boosted retrieval with automatic link traversal.
    ///
    /// Returns top-k packs with trace boost, plus all transitively
    /// linked packs not already in the result set.
    pub fn mem_read_pack_with_trace_boost_and_follow(
        &mut self,
        query_key: &[f32],
        k: usize,
        owner_filter: Option<OwnerId>,
        boost_factor: f32,
    ) -> Result<Vec<PackReadResult>> {
        let mut results =
            self.mem_read_pack_with_trace_boost(query_key, k, owner_filter, boost_factor)?;

        let retrieved_ids: std::collections::HashSet<PackId> =
            results.iter().map(|r| r.pack.id).collect();

        let mut linked_ids = std::collections::HashSet::new();
        for r in &results {
            for linked in self.pack_links(r.pack.id) {
                if !retrieved_ids.contains(&linked) {
                    linked_ids.insert(linked);
                }
            }
        }

        for linked_id in linked_ids {
            if let Ok(pack) = self.load_pack_by_id(linked_id) {
                results.push(pack);
            }
        }

        Ok(results)
    }

    fn collect_pack_candidates(
        &mut self,
        query_key: &[f32],
        k: usize,
        owner_filter: Option<OwnerId>,
    ) -> Vec<RetrievalResult> {
        // Per-token queries need pipeline first (same logic as mem_read).
        let is_per_token = is_encoded_per_token_key(query_key);
        let slb_query = mean_pool_key(query_key);
        let mut candidates = Vec::new();

        if is_per_token {
            let source = crate::cell_source_pool::BlockPoolCellSource::new(&self.pool);
            let cold =
                self.pipeline.query_with_source(query_key, k * 4, owner_filter, Some(&source));
            let mut seen: std::collections::HashSet<CellId> = std::collections::HashSet::new();
            for r in cold {
                if seen.insert(r.cell_id) {
                    candidates.push(r);
                }
            }
            if candidates.len() < k && !self.slb.is_empty() {
                for r in self.slb.query(&slb_query, k * 2) {
                    if seen.insert(r.cell_id) {
                        candidates.push(r);
                    }
                }
            }
        } else {
            candidates =
                if self.slb.is_empty() { Vec::new() } else { self.slb.query(&slb_query, k * 2) };
            if candidates.len() < k {
                let source = crate::cell_source_pool::BlockPoolCellSource::new(&self.pool);
                let cold =
                    self.pipeline.query_with_source(query_key, k * 2, owner_filter, Some(&source));
                let seen: std::collections::HashSet<CellId> =
                    candidates.iter().map(|r| r.cell_id).collect();
                for r in cold {
                    if !seen.contains(&r.cell_id) {
                        candidates.push(r);
                    }
                }
            }
        }

        candidates
    }

    fn deduplicate_pack_candidates(
        &self,
        mut retrieval_results: Vec<RetrievalResult>,
        k: usize,
        owner_filter: Option<OwnerId>,
    ) -> Vec<PackCandidate> {
        retrieval_results
            .sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));

        let candidates = retrieval_results
            .into_iter()
            .filter_map(|rr| {
                let pack_id = self.pack_directory.pack_for_cell(rr.cell_id)?;
                let cell_ids = self.pack_directory.cell_ids(pack_id)?;
                if owner_filter.is_some_and(|filter_owner| filter_owner != rr.owner) {
                    return None;
                }
                Some(PackCandidate::new(pack_id, rr.cell_id, rr.owner, rr.score, cell_ids.to_vec()))
            })
            .collect();

        keep_first_ranked_pack_candidates(candidates, k)
    }

    fn hydrate_pack_layers(&self, cell_ids: &[CellId]) -> Result<Vec<KVLayerPayload>> {
        let mut layers = Vec::with_capacity(cell_ids.len());
        for &cell_id in cell_ids {
            match self.pool.get(cell_id) {
                Ok(cell) if cell.layer != PACK_RETRIEVAL_LAYER => {
                    layers.push(KVLayerPayload { layer_idx: cell.layer, data: cell.value });
                }
                Ok(_) | Err(TardigradeError::CellNotFound(_)) => {}
                Err(e) => return Err(e),
            }
        }
        layers.sort_by_key(|layer| layer.layer_idx);
        Ok(layers)
    }

    fn apply_pack_access_governance(&mut self, retrieval_cell_id: CellId) -> PackAccessSnapshot {
        let Some(gov) = self.governance.get_mut(&retrieval_cell_id) else {
            return PackAccessSnapshot { tier: Tier::Draft, decay_factor: 1.0, tier_boost: 1.0 };
        };

        gov.scorer.on_access();
        gov.tier_sm.evaluate(gov.scorer.importance());

        let tier = gov.tier_sm.current();
        PackAccessSnapshot {
            tier,
            decay_factor: recency_decay(gov.days_since_update),
            tier_boost: tier.retrieval_boost(),
        }
    }

    /// Number of KV Packs stored.
    pub fn pack_count(&self) -> usize {
        self.pack_directory.len()
    }

    /// Get the stored text for a pack, if any.
    pub fn pack_text(&self, pack_id: PackId) -> Option<&str> {
        self.text_store.get(pack_id)
    }

    /// Whether a pack with the given ID exists (and has not been deleted).
    ///
    /// Distinguishes "pack exists but has no text" from "pack doesn't exist"
    /// — both cases return `None` from [`Self::pack_text`].
    pub fn pack_exists(&self, pack_id: PackId) -> bool {
        self.pack_directory.cell_ids(pack_id).is_some()
    }

    /// Set or update the stored text for an existing pack.
    ///
    /// Thin wrapper over [`Self::set_pack_texts`] for the single-entry case.
    /// Last-writer-wins semantics — the latest call's text is what reads return.
    ///
    /// # Errors
    ///
    /// Returns `CellNotFound` if the pack does not exist.
    pub fn set_pack_text(&mut self, pack_id: PackId, text: &str) -> Result<()> {
        self.set_pack_texts(&[(pack_id, text)])
    }

    /// Set or update text for many packs in a single batched fsync.
    ///
    /// Validates all `pack_id`s exist before any write — fail-fast: if any
    /// pack is missing, returns `CellNotFound` and **no entries are written**.
    /// This matches the existing batch convention from [`Self::mem_write_batch`]
    /// and avoids partial-write states.
    ///
    /// # When to use
    ///
    /// - Migrating a legacy text sidecar into the durable text store
    /// - Bulk-editing many memories in one operation
    ///
    /// For a single entry, prefer [`Self::set_pack_text`] for readability —
    /// it delegates here, so semantics are identical.
    ///
    /// # Errors
    ///
    /// Returns `CellNotFound` for the first missing pack ID encountered, with
    /// no on-disk side effects.
    pub fn set_pack_texts(&mut self, entries: &[(PackId, &str)]) -> Result<()> {
        for (pack_id, _) in entries {
            if !self.pack_exists(*pack_id) {
                return Err(TardigradeError::CellNotFound(*pack_id));
            }
        }
        self.text_store.store_batch(entries).map_err(|e| TardigradeError::Io { source: e })
    }

    /// Delete a pack permanently.
    ///
    /// Writes to the durable deletion log (fsynced) before updating in-memory
    /// state. Cells remain on disk in the `BlockPool` but become inaccessible.
    /// Trace edges are not removed — orphaned edges are filtered by
    /// `pack_directory` absence on query.
    ///
    /// # Errors
    ///
    /// Returns `CellNotFound` if the pack does not exist.
    pub fn delete_pack(&mut self, pack_id: PackId) -> Result<()> {
        // Verify pack exists.
        let cell_ids = self
            .pack_directory
            .cell_ids(pack_id)
            .ok_or(TardigradeError::CellNotFound(pack_id))?
            .to_vec();

        // Durable: write to deletion log (fsync before in-memory changes).
        self.deletion_log.mark_deleted(pack_id).map_err(|e| TardigradeError::Io { source: e })?;

        // Remove cells from retrieval pipeline and SLB.
        for &cell_id in &cell_ids {
            self.pipeline.remove(cell_id);
            self.slb.remove(cell_id);
            self.governance.remove(&cell_id);
        }

        // Remove from pack directory (in-memory).
        self.pack_directory.remove_pack(pack_id);

        // Remove text from in-memory text store.
        self.text_store.remove(pack_id);

        Ok(())
    }

    /// Get the importance score of a pack.
    pub fn pack_importance(&self, pack_id: PackId) -> Option<f32> {
        let cell_ids = self.pack_directory.cell_ids(pack_id)?;
        let retrieval_cell_id = *cell_ids.first()?;
        self.governance.get(&retrieval_cell_id).map(|g| g.scorer.importance())
    }

    /// Enumerate every owner that has at least one pack stored.
    ///
    /// Returns the unique [`OwnerId`]s in ascending order. The
    /// implementation walks the pack directory and reads each pack's
    /// retrieval cell to recover its owner — there is no separate
    /// owner table to maintain, so this is durable-by-derivation.
    ///
    /// Useful for consumers with multiple parties (multi-agent
    /// runtimes, multi-NPC games, multi-tenant `SaaS`) that need to
    /// enumerate or audit which owners have memory recorded.
    pub fn list_owners(&self) -> Vec<OwnerId> {
        let mut owners: std::collections::BTreeSet<OwnerId> = std::collections::BTreeSet::new();
        for &pack_id in self.pack_directory.pack_ids() {
            let Some(cell_ids) = self.pack_directory.cell_ids(pack_id) else {
                continue;
            };
            let Some(&retrieval_cell_id) = cell_ids.first() else {
                continue;
            };
            if let Ok(cell) = self.pool.get(retrieval_cell_id) {
                owners.insert(cell.owner);
            }
        }
        owners.into_iter().collect()
    }

    /// Return `true` iff at least one pack belongs to `owner`.
    ///
    /// Convenience wrapper over [`Engine::list_owners`] for the
    /// frequent "does this owner exist?" check.
    pub fn owner_exists(&self, owner: OwnerId) -> bool {
        self.list_owners().contains(&owner)
    }

    /// Remove every pack owned by `owner`, returning the count
    /// deleted.
    ///
    /// Unlike [`Engine::evict_draft_packs`], this is unconditional —
    /// validated and core-tier packs are removed too. The intended
    /// use is "this user logged out" / "this NPC was killed" /
    /// "this tenant was deleted." Each pack is deleted via
    /// [`Engine::delete_pack`] which writes a deletion log entry
    /// before the in-memory state changes, so the operation is
    /// crash-safe with the existing recovery contract.
    ///
    /// Returns `Ok(0)` and is a no-op when `owner` has no packs.
    pub fn delete_owner(&mut self, owner: OwnerId) -> Result<usize> {
        let to_delete: Vec<PackId> =
            self.list_packs(Some(owner)).into_iter().map(|(pack_id, _, _, _)| pack_id).collect();

        let count = to_delete.len();
        for pack_id in to_delete {
            self.delete_pack(pack_id)?;
        }
        Ok(count)
    }

    /// Enumerate all packs, optionally filtered by owner.
    ///
    /// Returns `(pack_id, owner, tier, importance)` sorted by importance
    /// descending. Packs without governance default to `(Draft, 0.0)`.
    pub fn list_packs(&self, owner_filter: Option<OwnerId>) -> Vec<(PackId, OwnerId, Tier, f32)> {
        let mut results = Vec::new();
        for &pack_id in self.pack_directory.pack_ids() {
            let Some(cell_ids) = self.pack_directory.cell_ids(pack_id) else {
                continue;
            };
            let Some(&retrieval_cell_id) = cell_ids.first() else {
                continue;
            };
            let owner = match self.pool.get(retrieval_cell_id) {
                Ok(cell) => cell.owner,
                Err(_) => continue,
            };
            if let Some(filter) = owner_filter
                && owner != filter
            {
                continue;
            }
            let (tier, importance) = self
                .governance
                .get(&retrieval_cell_id)
                .map_or((Tier::Draft, 0.0), |g| (g.tier_sm.current(), g.scorer.importance()));
            results.push((pack_id, owner, tier, importance));
        }
        results.sort_by(|a, b| b.3.partial_cmp(&a.3).unwrap_or(std::cmp::Ordering::Equal));
        results
    }

    /// Load a pack by ID without retrieval scoring.
    ///
    /// Returns the complete pack with all layer payloads. Applies access
    /// governance (importance boost + recency decay).
    pub fn load_pack_by_id(&mut self, pack_id: PackId) -> Result<PackReadResult> {
        let cell_ids = self
            .pack_directory
            .cell_ids(pack_id)
            .ok_or(TardigradeError::CellNotFound(pack_id))?
            .to_vec();

        let retrieval_cell_id = *cell_ids.first().ok_or(TardigradeError::CellNotFound(pack_id))?;

        let owner = self.pool.get(retrieval_cell_id).map_or(0, |cell| cell.owner);

        let layers = self.hydrate_pack_layers(&cell_ids)?;
        let access = self.apply_pack_access_governance(retrieval_cell_id);

        let candidate = PackCandidate::new(pack_id, retrieval_cell_id, owner, 0.0, cell_ids);
        let mut result = build_pack_read_result(&candidate, layers, access);
        result.pack.text = self.text_store.get(pack_id).map(str::to_owned);
        Ok(result)
    }

    /// Create a durable typed trace edge between two packs (Generalized Command).
    ///
    /// Bidirectional: creates edges in both directions. WAL-logged for
    /// crash recovery. This is the generalized form — `add_pack_link`
    /// delegates here with `EdgeType::Follows`.
    pub fn add_pack_edge(
        &mut self,
        pack_id_1: PackId,
        pack_id_2: PackId,
        edge_type: EdgeType,
    ) -> Result<()> {
        let cell_1 = self
            .pack_directory
            .cell_ids(pack_id_1)
            .and_then(|ids| ids.first().copied())
            .ok_or(TardigradeError::CellNotFound(pack_id_1))?;

        let cell_2 = self
            .pack_directory
            .cell_ids(pack_id_2)
            .and_then(|ids| ids.first().copied())
            .ok_or(TardigradeError::CellNotFound(pack_id_2))?;

        let now_nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |d| d.as_nanos() as u64);

        let wal_fwd = WalEntry::AddEdge {
            src: cell_1,
            dst: cell_2,
            edge_type: edge_type as u8,
            timestamp: now_nanos,
        };
        self.wal.append(&wal_fwd).map_err(|e| TardigradeError::WalRecovery(e.to_string()))?;
        self.trace.add_edge(cell_1, cell_2, edge_type, now_nanos);

        let wal_rev = WalEntry::AddEdge {
            src: cell_2,
            dst: cell_1,
            edge_type: edge_type as u8,
            timestamp: now_nanos,
        };
        self.wal.append(&wal_rev).map_err(|e| TardigradeError::WalRecovery(e.to_string()))?;
        self.trace.add_edge(cell_2, cell_1, edge_type, now_nanos);

        Ok(())
    }

    /// Create a durable `Follows` link between two packs.
    ///
    /// Convenience alias for `add_pack_edge(..., EdgeType::Follows)`.
    pub fn add_pack_link(&mut self, pack_id_1: PackId, pack_id_2: PackId) -> Result<()> {
        self.add_pack_edge(pack_id_1, pack_id_2, EdgeType::Follows)
    }

    /// Get all packs linked to a given pack via trace edges (any type).
    pub fn pack_links(&self, pack_id: PackId) -> Vec<PackId> {
        self.pack_links_by_type_filter(pack_id, None)
    }

    /// Get packs linked via a specific edge type.
    pub fn pack_links_by_type(&self, pack_id: PackId, edge_type: EdgeType) -> Vec<PackId> {
        self.pack_links_by_type_filter(pack_id, Some(edge_type))
    }

    /// Get packs that support a given pack.
    pub fn pack_supports(&self, pack_id: PackId) -> Vec<PackId> {
        self.pack_links_by_type(pack_id, EdgeType::Supports)
    }

    /// Get packs that contradict a given pack.
    pub fn pack_contradicts(&self, pack_id: PackId) -> Vec<PackId> {
        self.pack_links_by_type(pack_id, EdgeType::Contradicts)
    }

    fn pack_links_by_type_filter(
        &self,
        pack_id: PackId,
        edge_type_filter: Option<EdgeType>,
    ) -> Vec<PackId> {
        let Some(cell_ids) = self.pack_directory.cell_ids(pack_id) else {
            return Vec::new();
        };
        let Some(&retrieval_cell) = cell_ids.first() else {
            return Vec::new();
        };

        let mut linked_packs = std::collections::HashSet::new();

        for edge in self.trace.outgoing(retrieval_cell, edge_type_filter) {
            if let Some(linked_pack) = self.pack_directory.pack_for_cell(edge.dst)
                && linked_pack != pack_id
            {
                linked_packs.insert(linked_pack);
            }
        }

        for edge in self.trace.incoming(retrieval_cell, edge_type_filter) {
            if let Some(linked_pack) = self.pack_directory.pack_for_cell(edge.src)
                && linked_pack != pack_id
            {
                linked_packs.insert(linked_pack);
            }
        }

        linked_packs.into_iter().collect()
    }

    /// Build the default retrieval pipeline: `PerTokenRetriever` (`Top5Avg`,
    /// **lazy mode**) → `BruteForce`.
    ///
    /// The per-token retriever is constructed in lazy mode: it stores only
    /// per-cell summaries (~4 KB/cell) and decodes raw tokens on demand via
    /// the [`crate::cell_source_pool::BlockPoolCellSource`] handed to it at
    /// query time. This makes
    /// engine memory scale with the corpus's summaries, not with the
    /// corpus's full per-token data — full `LoCoMo` fits in ~1 GB instead
    /// of ~28 GB.
    ///
    /// DRY helper shared by `open_with_options` and `refresh()` (Memento rebuild).
    fn build_default_pipeline(config: &PerTokenConfig) -> RetrieverPipeline {
        let int8_tier_capacity = Self::int8_tier_capacity_from_env();
        let use_eager = Self::eager_mode_from_env();
        let mut pipeline = RetrieverPipeline::new();
        let per_token = if use_eager {
            tdb_retrieval::per_token::PerTokenRetriever::with_config_and_cache_capacity(
                ScoringMode::Top5Avg,
                config.clone(),
                tdb_retrieval::per_token::DEFAULT_TOKEN_CACHE_CAPACITY,
            )
        } else {
            tdb_retrieval::per_token::PerTokenRetriever::lazy_with_int8_tier_capacity(
                ScoringMode::Top5Avg,
                config.clone(),
                tdb_retrieval::per_token::DEFAULT_TOKEN_CACHE_CAPACITY,
                int8_tier_capacity,
            )
        };
        pipeline.add_stage(Box::new(per_token));
        pipeline.add_stage(Box::new(tdb_retrieval::attention::BruteForceRetriever::new()));
        pipeline
    }

    /// Diagnostic escape hatch — set `TDB_PER_TOKEN_EAGER=1` to build
    /// the per-token retriever in legacy eager mode (in-memory
    /// `TokenStore`). Used to A/B against the lazy + INT8-tier path
    /// when investigating recall regressions. Default: lazy mode.
    fn eager_mode_from_env() -> bool {
        const ENV_VAR: &str = "TDB_PER_TOKEN_EAGER";
        matches!(std::env::var(ENV_VAR).as_deref(), Ok("1" | "true"))
    }

    /// Resolve the INT8 retrieval-tier capacity from the
    /// `TDB_INT8_TIER_CAPACITY` env var. Falls back to
    /// [`tdb_retrieval::per_token::DEFAULT_INT8_TIER_CAPACITY`] when
    /// unset or unparsable. Capacity is in *cells*; each cell
    /// occupies ~150 KB at Qwen3-0.6B shape.
    fn int8_tier_capacity_from_env() -> std::num::NonZeroUsize {
        const ENV_VAR: &str = "TDB_INT8_TIER_CAPACITY";
        std::env::var(ENV_VAR)
            .ok()
            .and_then(|raw| raw.parse::<usize>().ok())
            .and_then(std::num::NonZeroUsize::new)
            .unwrap_or(tdb_retrieval::per_token::DEFAULT_INT8_TIER_CAPACITY)
    }

    /// Build and activate the Vamana index, adding it as a pipeline stage.
    fn activate_vamana(&mut self) -> Result<()> {
        let dim = self.key_dim.unwrap_or(128);
        let mut vamana = VamanaIndex::new(dim, DEFAULT_VAMANA_MAX_DEGREE);

        // Defense in depth: an entire 10k+ cell index rebuild must not panic
        // because a single cell carries a malformed key. Cells whose pooled
        // representation does not match the established `dim` are skipped
        // rather than crashing Vamana's dim assertion. Regression coverage:
        // tests/acceptance_vamana_threshold.rs.
        let cell_ids: Vec<CellId> = self.pool.iter_cell_ids().collect();
        for cell_id in &cell_ids {
            let cell = self.pool.get(*cell_id)?;
            let key = mean_pool_key(&cell.key);
            if key.len() != dim {
                continue;
            }
            vamana.insert(cell.id, &key);
        }

        vamana.build();
        vamana.save(&self.dir).map_err(|e| TardigradeError::Io { source: e })?;

        self.pipeline.add_stage(Box::new(VamanaAdapter { inner: vamana }));
        self.vamana = Some(VamanaIndex::new(dim, DEFAULT_VAMANA_MAX_DEGREE));
        Ok(())
    }

    fn try_load_vamana(&mut self) -> Result<bool> {
        let dim = self.key_dim.unwrap_or(128);
        let mut vectors = std::collections::HashMap::new();

        for cell_id in self.pool.iter_cell_ids() {
            if let Ok(cell) = self.pool.get(cell_id)
                && should_index_for_retrieval(&cell)
            {
                vectors.insert(cell_id, mean_pool_key(&cell.key));
            }
        }

        let loaded = VamanaIndex::load(&self.dir, &vectors)
            .map_err(|e| TardigradeError::Io { source: e })?;

        if let Some(vamana) = loaded
            && vamana.len() == vectors.len()
        {
            self.pipeline.add_stage(Box::new(VamanaAdapter { inner: vamana }));
            self.vamana = Some(VamanaIndex::new(dim, DEFAULT_VAMANA_MAX_DEGREE));
            return Ok(true);
        }
        Ok(false)
    }
}

impl std::fmt::Debug for Engine {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Engine")
            .field("dir", &self.dir)
            .field("cell_count", &self.pool.cell_count())
            .field("has_vamana", &self.vamana.is_some())
            .field("trace_edges", &self.trace.edge_count())
            .finish_non_exhaustive()
    }
}
