"""Agent runtime and tools."""
