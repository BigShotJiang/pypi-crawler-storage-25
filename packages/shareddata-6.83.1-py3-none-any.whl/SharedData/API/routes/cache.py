"""
Cache routes blueprint for SharedData API.

Provides CRUD and utility operations for Redis-backed CacheRedis instances.
"""

import datetime
import json
import time

from flask import Blueprint, Response, jsonify, request

from SharedData.Logger import Logger
from SharedData.API.constants import DEFAULT_USER, ERROR_SLEEP_SECONDS
from SharedData.API.utils import (
    get_user_param,
    make_error_response,
    make_empty_response,
)


class _DatetimeEncoder(json.JSONEncoder):
    """JSON encoder that serializes datetime/date objects as ISO 8601 strings."""
    def default(self, obj):
        if isinstance(obj, (datetime.datetime, datetime.date)):
            return obj.isoformat()
        return super().default(obj)


def _dumps(obj):
    return json.dumps(obj, cls=_DatetimeEncoder)


# Blueprint definition
cache_bp = Blueprint('cache', __name__)


def init_cache_routes(shdata, authenticate_fn):
    """
    Initialize cache routes with required dependencies.

    Parameters:
        shdata: SharedData instance.
        authenticate_fn: Authentication function.
    """

    @cache_bp.route('/cache/<database>/<period>/<source>/<tablename>', methods=['GET'])
    def list_cache_keys(database, period, source, tablename):
        """
        GET /api/cache/{database}/{period}/{source}/{tablename} — List cache keys.

        Query Parameters:
            pattern (str): Wildcard pattern to filter keys (default: '*').
            user (str): User identifier (default: 'master').

        Returns:
            JSON: {"keys": [...], "count": N}
        """
        try:
            if not authenticate_fn(request, shdata):
                return jsonify({'error': 'unauthorized'}), 401

            user = get_user_param(request)
            pattern = request.args.get('pattern', '*')

            cache = shdata.cache(database, period, source, tablename, user=user)
            keys = cache.list_keys(keyword=pattern)

            response_data = _dumps({'keys': keys, 'count': len(keys)}).encode('utf-8')
            response = Response(response_data, mimetype='application/json')
            response.headers['Content-Length'] = len(response_data)
            return response

        except Exception as e:
            Logger.log.error(f'list_cache_keys error: {e}')
            time.sleep(ERROR_SLEEP_SECONDS)
            return make_error_response(e)

    @cache_bp.route('/cache/<database>/<period>/<source>/<tablename>/flush', methods=['POST'])
    def flush_cache(database, period, source, tablename):
        """
        POST /api/cache/{database}/{period}/{source}/{tablename}/flush — Flush cache.

        Query Parameters:
            pattern (str): Wildcard pattern for selective flush. If omitted, flushes all keys.
            user (str): User identifier (default: 'master').

        Returns:
            JSON: {"deleted": N}
        """
        try:
            if not authenticate_fn(request, shdata):
                return jsonify({'error': 'unauthorized'}), 401

            user = get_user_param(request)
            pattern = request.args.get('pattern')

            cache = shdata.cache(database, period, source, tablename, user=user)

            if pattern:
                keys = cache.list_keys(keyword=pattern)
                for key in keys:
                    del cache[key]
                count = len(keys)
            else:
                keys = cache.list_keys('*')
                count = len(keys)
                cache.clear()

            response_data = _dumps({'deleted': count}).encode('utf-8')
            response = Response(response_data, mimetype='application/json')
            response.headers['Content-Length'] = len(response_data)
            return response

        except Exception as e:
            Logger.log.error(f'flush_cache error: {e}')
            time.sleep(ERROR_SLEEP_SECONDS)
            return make_error_response(e)

    @cache_bp.route('/cache/<database>/<period>/<source>/<tablename>/<key>/exists', methods=['GET'])
    def cache_key_exists(database, period, source, tablename, key):
        """
        GET /api/cache/{database}/{period}/{source}/{tablename}/{key}/exists — Check if key exists.

        Query Parameters:
            user (str): User identifier (default: 'master').

        Returns:
            JSON: {"exists": true|false, "key": "..."}
        """
        try:
            if not authenticate_fn(request, shdata):
                return jsonify({'error': 'unauthorized'}), 401

            user = get_user_param(request)

            cache = shdata.cache(database, period, source, tablename, user=user)
            found = cache.exists(key)

            response_data = _dumps({'exists': found, 'key': key}).encode('utf-8')
            response = Response(response_data, mimetype='application/json')
            response.headers['Content-Length'] = len(response_data)
            return response

        except Exception as e:
            Logger.log.error(f'cache_key_exists error: {e}')
            time.sleep(ERROR_SLEEP_SECONDS)
            return make_error_response(e)

    @cache_bp.route('/cache/<database>/<period>/<source>/<tablename>/<key>/ttl', methods=['GET'])
    def cache_key_ttl(database, period, source, tablename, key):
        """
        GET /api/cache/{database}/{period}/{source}/{tablename}/{key}/ttl — Get TTL for a key.

        Query Parameters:
            user (str): User identifier (default: 'master').

        Returns:
            JSON: {"ttl": N, "key": "..."}
            ttl: seconds remaining, -1 = no expiry, -2 = key not found.
        """
        try:
            if not authenticate_fn(request, shdata):
                return jsonify({'error': 'unauthorized'}), 401

            user = get_user_param(request)

            cache = shdata.cache(database, period, source, tablename, user=user)
            ttl = cache.key_ttl(key)

            response_data = _dumps({'ttl': ttl, 'key': key}).encode('utf-8')
            response = Response(response_data, mimetype='application/json')
            response.headers['Content-Length'] = len(response_data)
            return response

        except Exception as e:
            Logger.log.error(f'cache_key_ttl error: {e}')
            time.sleep(ERROR_SLEEP_SECONDS)
            return make_error_response(e)

    @cache_bp.route(
        '/cache/<database>/<period>/<source>/<tablename>/<key>',
        methods=['GET', 'POST', 'DELETE']
    )
    def cache_key(database, period, source, tablename, key):
        """
        CRUD operations on a single cache key.

        GET    — retrieve value; 204 if key not found.
        POST   — set value; body: JSON {"value": {...}, "ttl": N (optional)}.
        DELETE — delete key; 204 on success, 404 if not found.
        """
        try:
            if not authenticate_fn(request, shdata):
                return jsonify({'error': 'unauthorized'}), 401

            if request.method == 'GET':
                return get_cache_key(database, period, source, tablename, key, request)
            elif request.method == 'POST':
                return post_cache_key(database, period, source, tablename, key, request)
            elif request.method == 'DELETE':
                return delete_cache_key(database, period, source, tablename, key, request)
            else:
                return jsonify({'error': 'method not allowed'}), 405

        except Exception as e:
            Logger.log.error(f'cache_key error ({request.method} {key}): {e}')
            time.sleep(ERROR_SLEEP_SECONDS)
            return make_error_response(e)

    def get_cache_key(database, period, source, tablename, key, request):
        """Retrieve a value by key. Returns 204 if key does not exist."""
        user = get_user_param(request)

        cache = shdata.cache(database, period, source, tablename, user=user)
        value = cache[key]

        if not value:
            return make_empty_response(204)

        response_data = _dumps(value).encode('utf-8')
        response = Response(response_data, mimetype='application/json')
        response.headers['Content-Length'] = len(response_data)
        return response

    def post_cache_key(database, period, source, tablename, key, request):
        """Set a value for a key. Body: JSON {"value": {...}, "ttl": N (optional)}."""
        user = get_user_param(request)

        body = request.get_json(silent=True)
        if body is None or 'value' not in body:
            return jsonify({'error': 'request body must be JSON with a "value" field'}), 400

        value = body['value']
        ttl = body.get('ttl')

        if not isinstance(value, dict):
            return jsonify({'error': '"value" must be a JSON object (dict)'}), 400

        cache = shdata.cache(database, period, source, tablename, user=user)

        if ttl is not None:
            cache.set_ex(key, value, int(ttl))
        else:
            cache[key] = value

        response = Response(status=201)
        response.headers['Content-Length'] = 0
        return response

    def delete_cache_key(database, period, source, tablename, key, request):
        """Delete a key. Returns 204 on success, 404 if key not found."""
        user = get_user_param(request)

        cache = shdata.cache(database, period, source, tablename, user=user)

        if not cache.exists(key):
            return Response(status=404)

        del cache[key]
        return make_empty_response(204)

    return cache_bp
