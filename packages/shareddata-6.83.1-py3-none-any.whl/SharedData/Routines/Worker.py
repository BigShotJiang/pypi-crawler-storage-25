# SharedData/Routines/Worker.py

# implements a decentralized routines worker
# connects to worker pool
# broadcast heartbeat
# listen to commands
# environment variables:
# SOURCE_FOLDER
# WORKERPOOL_STREAM
# GIT_SERVER
# GIT_USER
# GIT_ACRONYM
# GIT_TOKEN

import os
import time
import sys
import numpy as np
import importlib.metadata
import argparse
import psutil
import subprocess

# Note: ~/.shareddata.env is loaded automatically by Defaults.py via load_dotenv()
# when SharedData modules are imported below

def get_gpu_metrics():
    """Per-NVIDIA-GPU metrics via nvidia-smi. Returns [] on any failure (no GPU, tool missing, etc.)."""
    try:
        result = subprocess.run(
            ['nvidia-smi',
             '--query-gpu=index,utilization.gpu,temperature.gpu,power.draw,memory.used,memory.total',
             '--format=csv,noheader,nounits'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            return []
        gpus = []
        for line in result.stdout.strip().split('\n'):
            if not line.strip():
                continue
            parts = [p.strip() for p in line.split(',')]
            if len(parts) >= 6:
                gpus.append({
                    'index': int(parts[0]),
                    'util': float(parts[1]),
                    'temp': float(parts[2]),
                    'power': float(parts[3]),
                    'mem_used': float(parts[4]),
                    'mem_total': float(parts[5]),
                })
        return gpus
    except Exception:
        return []


def _cpu_sockets():
    """Linux-only: map socket_id -> list of logical CPU indices. Returns {} on non-Linux or read failure."""
    try:
        out = {}
        base = '/sys/devices/system/cpu'
        for entry in os.listdir(base):
            if not (entry.startswith('cpu') and entry[3:].isdigit()):
                continue
            ppath = os.path.join(base, entry, 'topology', 'physical_package_id')
            if not os.path.isfile(ppath):
                continue
            with open(ppath) as f:
                pkg = int(f.read().strip())
            out.setdefault(pkg, []).append(int(entry[3:]))
        return out
    except Exception:
        return {}


def _cpu_temp_by_socket(n_sockets):
    """Best-effort CPU temperature per socket via psutil.sensors_temperatures().
    Returns {socket_id: celsius}. Empty {} if not supported (Windows, macOS) or no sensors exposed.
    Handles Intel coretemp ('Package id N') and AMD k10temp/zenpower (one entry per CPU)."""
    try:
        sensors = psutil.sensors_temperatures()
    except Exception:
        return {}
    if not sensors:
        return {}
    out = {}
    # Intel coretemp labels each package explicitly
    for entry in sensors.get('coretemp', []):
        label = entry.label or ''
        if label.startswith('Package id '):
            try:
                out[int(label.split()[-1])] = float(entry.current)
            except Exception:
                pass
    if out:
        return out
    # AMD exposes one entry per CPU in k10temp / zenpower; order matches socket order
    amd = sensors.get('k10temp') or sensors.get('zenpower') or []
    for i, entry in enumerate(amd[:max(n_sockets, 1)]):
        if entry.current is not None and entry.label in ('Tctl', 'Tdie', ''):
            out[i] = float(entry.current)
    return out


def get_cpu_metrics():
    """Per-socket CPU metrics on Linux, single aggregate entry elsewhere.
    Returns [{index, util, temp}] — temp is None when no sensor is available."""
    try:
        percpu = psutil.cpu_percent(interval=0.1, percpu=True)
    except Exception:
        return []
    sockets = _cpu_sockets()
    temps = _cpu_temp_by_socket(len(sockets) or 1)
    if sockets:
        out = []
        for sock in sorted(sockets):
            cores = [percpu[c] for c in sockets[sock] if c < len(percpu)]
            out.append({
                'index': sock,
                'util': sum(cores) / len(cores) if cores else 0.0,
                'temp': temps.get(sock),
            })
        return out
    # Non-Linux or topology unreadable — single aggregate
    return [{
        'index': 0,
        'util': sum(percpu) / len(percpu) if percpu else 0.0,
        'temp': next(iter(temps.values()), None),
    }]

from SharedData.Routines.WorkerLib import *
from SharedData.SharedData import SharedData
shdata = SharedData('SharedData.Routines.Worker',quiet=True)
from SharedData.Logger import Logger
from SharedData.Routines.WorkerPool import WorkerPool
from SharedData.Users import get_master_user

parser = argparse.ArgumentParser(description="Worker configuration")
parser.add_argument('--schedules', default='', help='Schedules to start')
parser.add_argument('--server', type=bool, default=False, help='Is a server instance')
parser.add_argument('--election', type=bool, default=False, help='Run master election')
parser.add_argument('--port', type=int, default=8002, help='Server port number')
parser.add_argument('--nproc', type=int, default=4, help='Number of server processes')
parser.add_argument('--nthreads', type=int, default=8, help='Number of server threads')
parser.add_argument('--batchjobs', type=int, default=0, help='Max number of jobs to fetch')
parser.add_argument('--sleep', type=int, default=5, help='Sleep time between fetches')
args = parser.parse_args()

if args.server:
    # INITIALIZE WORKER POOL SERVER COMMAND AND JOBS TABLE
    cmd_table = WorkerPool.get_command_table(shdata)
    jobs_table = WorkerPool.get_job_table(shdata)
    # SET ENVIRONMENT VARIABLE FOR THE SERVER TO CONNECT TO THE WORKERPOOL
    if bool(args.election):
        os.environ['SHAREDDATA_ENDPOINT'] = f'http://localhost:8002'
    else:
        os.environ['SHAREDDATA_ENDPOINT'] = f'http://localhost:{args.port}'
    # CHECK IF THE MASTER USER IS PRESENT
    master_user = get_master_user(shdata)
    # START THE SERVER API
    start_server(args.port, args.nproc,args.nthreads)
    # START THE WORKERPOOL JOBS STATUS UPDATE THREAD
    update_jobs_status_thread = threading.Thread(
        target=WorkerPool.update_active_jobs,
        args=(shdata,),
        daemon=True
    )
    update_jobs_status_thread.start()

if not 'MAX_BATCH_JOBS' in os.environ:
    os.environ['MAX_BATCH_JOBS'] = str(int(args.batchjobs))

if not 'RUN_MASTER_ELECTION' in os.environ:
    os.environ['RUN_MASTER_ELECTION'] = str(args.election).upper()
    
SCHEDULE_NAMES = args.schedules
if SCHEDULE_NAMES != '' and str(os.environ.get('RUN_MASTER_ELECTION', '')).upper() != 'TRUE':
    Logger.log.info('SharedData Worker schedules:%s STARTED!' % (SCHEDULE_NAMES))
    start_schedules(SCHEDULE_NAMES)    

lastheartbeat = time.time()

SLEEP_TIME = int(args.sleep)
SHAREDDATA_VERSION = ''
try:
    SHAREDDATA_VERSION = importlib.metadata.version("shareddata")    
except:
    pass    

cpu_model = get_cpu_model()
mem = psutil.virtual_memory()
mem_total_gb = mem.total / (1024 ** 3)
own_ip = get_own_ip()
own_id = os.environ.get('COMPUTERNAME', own_ip)
own_id = own_id.replace('.','#')
cluster_folder = 'CLUSTERS/MASTER/'
own_path = f'{cluster_folder}{own_id}'

if str(os.environ['RUN_MASTER_ELECTION']).upper() == 'TRUE':
    init_worker_election(own_path, own_ip, own_id)

if args.server:
    time.sleep(15)  # wait for server to start

Logger.log.info(
    "ROUTINE STARTED!"
    f"{cpu_model} {mem_total_gb:.1f} RAM"
)

routines = []
batch_jobs = []
completed_batch_jobs = 0
error_batch_jobs = 0
master_count = 0
is_current_master = False
scheduler_routine = None

while True:

    try:
        if str(os.environ['RUN_MASTER_ELECTION']).upper() == 'TRUE':
            is_current_master, master_count = run_worker_election(cluster_folder, own_path, own_id, own_ip, master_count)
    except Exception as e:
        Logger.log.error(f'Run election error:{e}')

    # Master scheduler lifecycle management
    if is_current_master:
        if scheduler_routine is None:
            # Promotion: just became master, start scheduler
            Logger.log.info('Promoted to master — starting MASTER schedule')
            scheduler_routine = start_schedules('MASTER')
        else:
            # Health check: ensure scheduler process is still alive
            try:
                proc = scheduler_routine.get('process')
                is_alive = proc is not None and proc.is_running()
            except Exception:
                is_alive = False
            if not is_alive:
                Logger.log.warning('Master scheduler process died — restarting MASTER schedule')
                scheduler_routine = start_schedules('MASTER')
    elif scheduler_routine is not None:
        # Demotion: lost master status, kill the scheduler
        Logger.log.info('Demoted from master — stopping MASTER schedule')
        kill_routine(scheduler_routine['command'], [scheduler_routine])
        scheduler_routine = None

    jobs = get_workerpool_jobs(batch_jobs)
    update_routines(routines)
    for command in jobs:           
        if ('job' in command) & ('target' in command):
            if ((command['target'].upper() == os.environ['USER_COMPUTER'].upper())
                    | (command['target'] == 'ALL')):                
                update_routines(routines)
                command = validate_command(command)
                process_command(command,routines,batch_jobs)
                routines = remove_finished_routines(routines)

    routines = remove_finished_routines(routines)
    batch_jobs, nfinished, nerror = remove_finished_batch_jobs(batch_jobs)
    completed_batch_jobs += nfinished
    error_batch_jobs += nerror    

    if (time.time()-lastheartbeat > 15):
        lastheartbeat = time.time()
        nroutines = len(routines)

        # Per-socket CPU metrics (util% and temp°C). Single socket -> "cpu=...", multi -> "cpu0=...,cpu1=..."
        cpus = get_cpu_metrics()
        if len(cpus) <= 1:
            c = cpus[0] if cpus else {'util': 0.0, 'temp': None}
            cpu_str = f",cpu={c['util']:.0f}%"
            if c['temp'] is not None:
                cpu_str += f"/{c['temp']:.0f}C"
        else:
            cpu_str = ''
            for c in cpus:
                cpu_str += f",cpu{c['index']}={c['util']:.0f}%"
                if c['temp'] is not None:
                    cpu_str += f"/{c['temp']:.0f}C"

        mem = psutil.virtual_memory()
        mem_total_gb = mem.total / (1024 ** 3)

        # Per-GPU metrics (util%/temp°C/power W/mem_used/mem_total GB)
        gpu_str = ''
        for g in get_gpu_metrics():
            gpu_str += (
                f",gpu{g['index']}={g['util']:.0f}%"
                f"/{g['temp']:.0f}C"
                f"/{g['power']:.0f}W"
                f"/{g['mem_used']/1024:.1f}/{g['mem_total']/1024:.1f}GB"
            )

        Logger.log.debug(
            f"#heartbeat# {SHAREDDATA_VERSION},"
            f"{'MASTER,' if is_current_master else ''}"
            f"{nroutines}routines,"
            f"{len(batch_jobs)}/{int(os.environ['MAX_BATCH_JOBS'])}jobs,"
            f"{completed_batch_jobs}completed,"
            f"{error_batch_jobs}errors"
            f"{cpu_str},"
            f"mem={mem.percent:.1f}%/{mem_total_gb:.0f}GB"
            f"{gpu_str}"
        )
        # Logger.log.debug(f'#heartbeat# {nroutines}routines,{running_batch_jobs}/{MAX_BATCH_JOBS}jobs,{completed_batch_jobs}completed,{error_batch_jobs}errors,{SHAREDDATA_VERSION}')
    
    time.sleep(SLEEP_TIME * np.random.rand())