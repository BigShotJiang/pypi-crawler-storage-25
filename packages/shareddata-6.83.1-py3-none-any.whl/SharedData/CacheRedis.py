"""
Redis-backed last-state cache for Kafka stream consumers.

Design goals:
    - At-least-once durability: caller writes via apply_batch(), awaits the
      Redis ack, only then commits the Kafka offset. No data lost on crash.
    - Atomic read-modify-write: CAS via Lua script; one round-trip per pkey
      in the uncontended case, retry loop on cross-writer contention.
    - Cluster-safe: every logical cache sits in one slot via hash-tag
      '{path}:…', so multi-key scripts and SCAN stay slot-local.
    - No secondary index: key enumeration uses SCAN with a slot-local pattern,
      eliminating drift from the old '#pkeys' set.
    - BSON encoding preserved (handles datetime natively; same format as the
      Kafka pipeline).
    - No silent write-only local cache; self.data is gone. Callers that want
      locality should keep their own.

Key layout (all share the hash-tag '{path}'):
    {path}:DATA:<pkey>     BSON-encoded dict, one per logical entity
    {path}:META:<field>    counters and arbitrary metadata (replaces CacheHeader)

Backward compatibility:
    - `cache[pkey]` reads still return {} for missing (NOT KeyError) so
      existing callers survive. Use `cache.at(pkey)` for strict semantics.
    - `cache[pkey] = value` merges (same semantics as before).
    - `cache.set(value[, pkey])` merges.
    - `cache.async_set(value_or_list)` calls apply_batch — the at-least-once
      durable write. Semantic change: it now blocks until Redis has acked.
      Callers that relied on fire-and-forget are now safe by default.
    - `cache.header.get(...)` / `cache.header.async_incrby(...)` / `cache.header[...]`
      still work via a compatibility shim over META keys.
    - `cache.load()` returns a fresh dict (no retained buffer).
"""
from __future__ import annotations

import asyncio
import os
import random
from collections.abc import Iterable, Iterator, Mapping
from typing import Any

import bson
from redis import Redis
from redis.cluster import ClusterNode, RedisCluster
from redis.asyncio import Redis as RedisAsync
from redis.asyncio.cluster import ClusterNode as ClusterNodeAsync
from redis.asyncio.cluster import RedisCluster as RedisClusterAsync

from SharedData.Database import DATABASE_PKEYS


# ---------------------------------------------------------------------------
# Lua: atomic compare-and-set with TTL and counter increment
# ---------------------------------------------------------------------------
# KEYS[1] = {path}:DATA:<pkey>
# KEYS[2] = {path}:META:cache->counter
# ARGV[1] = expected previous bytes ('' if caller expects key to be absent)
# ARGV[2] = new bytes (BSON-encoded merged dict)
# ARGV[3] = TTL seconds (0 = no TTL)
# Returns: 1 on success, 0 on CAS conflict (caller retries).
_CAS_LUA = r"""
local current = redis.call('GET', KEYS[1])
if current == false then current = '' end
if current ~= ARGV[1] then
    return 0
end
local ttl = tonumber(ARGV[3])
if ttl and ttl > 0 then
    redis.call('SET', KEYS[1], ARGV[2], 'EX', ttl)
else
    redis.call('SET', KEYS[1], ARGV[2])
end
redis.call('INCR', KEYS[2])
return 1
"""


_TEMPORAL_PKEY_COLS = frozenset({'date', 'mtime', 'timestamp', 'time', 'datetime'})
_COUNTER_FIELD = 'cache->counter'
# Production Kafka path: 1 writer per pkey (partition ownership) → CAS always
# succeeds on attempt 1. Retries matter only when a strategy/script writes to
# the same pkey concurrently with the consumer. 32 attempts with jittered
# backoff survives ~30 concurrent writers per pkey.
_MAX_CAS_RETRIES = 32
_CAS_BACKOFF_BASE_MS = 0.5
_CAS_BACKOFF_MAX_MS = 50.0


def _deep_merge(target: dict, source: Mapping) -> dict:
    """Recursively merge source into target. Mutates target; returns it."""
    for k, v in source.items():
        if isinstance(v, Mapping) and isinstance(target.get(k), dict):
            _deep_merge(target[k], v)
        else:
            target[k] = v
    return target


def _check_pkey(pkey: str) -> None:
    if not isinstance(pkey, str):
        raise TypeError('pkey must be a string')
    if not pkey:
        raise ValueError('pkey must be non-empty')
    if '#' in pkey or ':' in pkey:
        raise ValueError(f'pkey cannot contain # or : (got {pkey!r})')


def _parse_cluster_nodes() -> list[tuple[str, int]]:
    raw = os.environ.get('REDIS_CLUSTER_NODES')
    if not raw:
        raise RuntimeError('REDIS_CLUSTER_NODES not defined')
    nodes = []
    for part in raw.split(','):
        host, port = part.strip().split(':')
        nodes.append((host.strip(), int(port)))
    return nodes


def _build_sync_client():
    nodes = _parse_cluster_nodes()
    if len(nodes) > 1:
        return RedisCluster(
            startup_nodes=[ClusterNode(h, p) for h, p in nodes],
            decode_responses=False,
        )
    host, port = nodes[0]
    return Redis(host=host, port=port, decode_responses=False)


def _build_async_client():
    nodes = _parse_cluster_nodes()
    if len(nodes) > 1:
        return RedisClusterAsync(
            startup_nodes=[ClusterNodeAsync(h, p) for h, p in nodes],
            decode_responses=False,
        )
    host, port = nodes[0]
    return RedisAsync(host=host, port=port, decode_responses=False)


class _KeyNS:
    """Build Redis keys sharing a cluster slot via hash-tag '{path}'."""
    __slots__ = ('_tag',)

    def __init__(self, path: str):
        self._tag = '{' + path + '}'

    def data(self, pkey: str) -> str:
        return f'{self._tag}:DATA:{pkey}'

    def data_pattern(self, keyword: str = '*') -> str:
        return f'{self._tag}:DATA:{keyword}'

    def meta(self, field: str) -> str:
        return f'{self._tag}:META:{field}'

    def meta_pattern(self, keyword: str = '*') -> str:
        return f'{self._tag}:META:{keyword}'

    def extract_pkey(self, key) -> str:
        if isinstance(key, bytes):
            key = key.decode('utf-8')
        prefix = f'{self._tag}:DATA:'
        if not key.startswith(prefix):
            raise ValueError(f'key outside namespace: {key!r}')
        return key[len(prefix):]

    def extract_meta(self, key) -> str:
        if isinstance(key, bytes):
            key = key.decode('utf-8')
        prefix = f'{self._tag}:META:'
        if not key.startswith(prefix):
            raise ValueError(f'key outside namespace: {key!r}')
        return key[len(prefix):]


class CacheRedis:
    def __init__(
        self,
        database: str,
        period: str,
        source: str,
        tablename: str,
        user: str = 'master',
        ttl_seconds: int = 0,
        pkey_columns: list[str] | None = None,
    ):
        if database not in DATABASE_PKEYS:
            raise ValueError(f'unknown database {database!r}')
        self.database = database
        self.period = period
        self.source = source
        self.tablename = tablename
        self.user = user
        self.ttl_seconds = int(ttl_seconds)

        self.path = f'{user}/{database}/{period}/{source}/cache/{tablename}'
        self._keys = _KeyNS(self.path)

        if pkey_columns is None:
            pkey_columns = [
                c for c in DATABASE_PKEYS[database]
                if c not in _TEMPORAL_PKEY_COLS
            ]
        if not pkey_columns:
            raise ValueError(
                f'no non-temporal pkey columns for database {database!r}; '
                f'pass pkey_columns explicitly'
            )
        self.pkey_columns = list(pkey_columns)

        self._redis = _build_sync_client()
        self._redis_async: Any | None = None
        self._redis_async_loop: Any | None = None

        # Register CAS script. Each client (sync and async) registers its own
        # Script instance — redis-py's Script handles evalsha + NOSCRIPT fallback.
        self._cas = self._redis.register_script(_CAS_LUA)
        self._cas_async: Any | None = None

        # Back-compat surfaces
        self.header = _HeaderShim(self)
        self.pkeycolumns = self.pkey_columns
        self.set_pkeys = f'{{{self.path}}}#pkeys'  # legacy, unused

    # ------------------------------------------------------------------
    # Async client (lazy; bound to the event loop that first asks for it)
    # ------------------------------------------------------------------
    def _get_async(self):
        # Defensive: if the current event loop differs from the one the client
        # was created on, rebuild. Production has one loop per process so this
        # almost never fires; protects test harnesses and rare respawn cases.
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if self._redis_async is not None and self._redis_async_loop is not loop:
            self._redis_async = None
            self._cas_async = None
            self._redis_async_loop = None
        if self._redis_async is None:
            self._redis_async = _build_async_client()
            self._redis_async_loop = loop
        return self._redis_async

    def _get_async_cas(self):
        """Lazy async Script (Redis Cluster blocks evalsha in pipelines, so
        we invoke the Script object directly and let redis-py route each call)."""
        if self._cas_async is None:
            self._cas_async = self._get_async().register_script(_CAS_LUA)
        return self._cas_async

    async def aclose(self) -> None:
        if self._redis_async is not None:
            try:
                await self._redis_async.close()
            except Exception:
                pass
            self._redis_async = None

    # ------------------------------------------------------------------
    # pkey derivation
    # ------------------------------------------------------------------
    def pkey_of(self, value: Mapping[str, Any]) -> str:
        parts = []
        for col in self.pkey_columns:
            if col not in value:
                raise KeyError(
                    f'message missing pkey column {col!r}: keys={list(value.keys())}'
                )
            s = str(value[col])
            if not s:
                raise ValueError(f'empty pkey value for column {col!r}')
            if '#' in s or ':' in s:
                raise ValueError(f'invalid pkey value for {col!r}: {s!r}')
            parts.append(s)
        return ','.join(parts)

    def get_pkey(self, value: Mapping[str, Any]) -> str:
        return self.pkey_of(value)

    def get_hash(self, pkey: str) -> str:
        return self._keys.data(pkey)

    # ------------------------------------------------------------------
    # Point reads
    # ------------------------------------------------------------------
    def __getitem__(self, pkey: str) -> dict:
        _check_pkey(pkey)
        raw = self._redis.get(self._keys.data(pkey))
        if raw is None:
            return {}
        return bson.BSON.decode(raw)

    def at(self, pkey: str) -> dict:
        _check_pkey(pkey)
        raw = self._redis.get(self._keys.data(pkey))
        if raw is None:
            raise KeyError(pkey)
        return bson.BSON.decode(raw)

    def get(self, pkey: str, default: Any = None) -> Any:
        _check_pkey(pkey)
        raw = self._redis.get(self._keys.data(pkey))
        if raw is None:
            return {} if default is None else default
        return bson.BSON.decode(raw)

    def mget(self, pkeys: Iterable[str]) -> list[dict]:
        pkeys = list(pkeys)
        if not pkeys:
            return []
        for pkey in pkeys:
            _check_pkey(pkey)
        raws = self._redis.mget([self._keys.data(p) for p in pkeys])
        return [bson.BSON.decode(r) if r is not None else {} for r in raws]

    async def aget(self, pkey: str, default: Any = None) -> Any:
        _check_pkey(pkey)
        r = self._get_async()
        raw = await r.get(self._keys.data(pkey))
        if raw is None:
            return {} if default is None else default
        return bson.BSON.decode(raw)

    async def amget(self, pkeys: Iterable[str]) -> list[dict]:
        pkeys = list(pkeys)
        if not pkeys:
            return []
        for pkey in pkeys:
            _check_pkey(pkey)
        r = self._get_async()
        raws = await r.mget([self._keys.data(p) for p in pkeys])
        return [bson.BSON.decode(raw) if raw is not None else {} for raw in raws]

    def exists(self, pkey: str) -> bool:
        _check_pkey(pkey)
        return bool(self._redis.exists(self._keys.data(pkey)))

    def key_ttl(self, pkey: str) -> int:
        _check_pkey(pkey)
        return int(self._redis.ttl(self._keys.data(pkey)))

    def load(self) -> dict:
        pkeys = self.list_keys('*')
        values = self.mget(pkeys)
        return dict(zip(pkeys, values))

    # ------------------------------------------------------------------
    # Writes
    # ------------------------------------------------------------------
    def __setitem__(self, pkey: str, new_value: Mapping[str, Any]) -> None:
        _check_pkey(pkey)
        self._cas_merge_sync(pkey, dict(new_value))

    def set(self, new_value: Mapping[str, Any], pkey: str | None = None) -> None:
        if pkey is None:
            pkey = self.pkey_of(new_value)
        self[pkey] = new_value

    def set_ex(self, pkey: str, value: Mapping[str, Any], ex: int) -> None:
        _check_pkey(pkey)
        self._cas_merge_sync(pkey, dict(value), ttl=int(ex))

    def __delitem__(self, pkey: str) -> None:
        _check_pkey(pkey)
        self._redis.delete(self._keys.data(pkey))

    # ------------------------------------------------------------------
    # Batch writes — the Kafka path
    # ------------------------------------------------------------------
    async def apply_batch(
        self,
        messages: Iterable[Mapping[str, Any]],
        mode: str = 'merge',
        strict: bool = False,
    ) -> int:
        """
        Apply a batch of messages.

        Kafka consumers call this with `strict=False` (default). Messages whose
        pkey can't be derived (missing/empty column, forbidden chars) are
        skipped with a single warning per batch — otherwise one malformed
        message would poison the whole stream (Kafka offset never advances,
        consumer retries the same batch forever).

        For direct callers that want loud failures, pass `strict=True`.
        """
        if mode not in ('merge', 'replace'):
            raise ValueError(f'invalid mode {mode!r}')
        messages = list(messages)
        if not messages:
            return 0

        conflated: dict[str, dict] = {}
        skipped = 0
        first_error: str | None = None
        for msg in messages:
            try:
                pkey = self.pkey_of(msg)
            except (KeyError, ValueError, TypeError) as e:
                if strict:
                    raise
                skipped += 1
                if first_error is None:
                    first_error = f'{type(e).__name__}: {e}'
                continue
            if pkey in conflated:
                _deep_merge(conflated[pkey], dict(msg))
            else:
                conflated[pkey] = dict(msg)

        if skipped:
            # Use stdlib logging directly — SharedData.Logger.log may be None
            # if this CacheRedis is instantiated before Logger.connect() ran
            # (e.g. in scripts or tests). Stdlib logging always has a root
            # logger available.
            import logging
            logging.getLogger('SharedData.CacheRedis').warning(
                'apply_batch[%s]: skipped %d/%d messages with invalid pkey (first: %s)',
                self.path, skipped, len(messages), first_error,
            )

        await self._cas_write_many(conflated, mode=mode)
        return len(conflated)

    async def async_set(self, value_or_list) -> int:
        """Back-compat: now a durable write, returns after Redis ack."""
        if isinstance(value_or_list, list):
            return await self.apply_batch(value_or_list)
        return await self.apply_batch([value_or_list])

    # ------------------------------------------------------------------
    # CAS primitives
    # ------------------------------------------------------------------
    def _cas_merge_sync(self, pkey: str, delta: dict, ttl: int | None = None) -> None:
        data_key = self._keys.data(pkey)
        counter_key = self._keys.meta(_COUNTER_FIELD)
        ttl_val = int(ttl if ttl is not None else self.ttl_seconds)

        for _ in range(_MAX_CAS_RETRIES):
            prev = self._redis.get(data_key)
            current = bson.BSON.decode(prev) if prev else {}
            merged = _deep_merge(current, delta) if current else dict(delta)
            new_bytes = bson.BSON.encode(merged)
            ok = self._cas(
                keys=[data_key, counter_key],
                args=[prev if prev else b'', new_bytes, ttl_val],
                client=self._redis,
            )
            if ok:
                return
        raise RuntimeError(f'CAS retry exhausted for {pkey!r}')

    async def _cas_write_many(self, deltas: dict[str, dict], mode: str) -> None:
        if not deltas:
            return
        r = self._get_async()
        counter_key = self._keys.meta(_COUNTER_FIELD)
        ttl = self.ttl_seconds
        script = self._get_async_cas()

        # Phase 1: pipelined GET (same-slot; cluster allows this).
        pkeys = list(deltas.keys())
        data_keys = [self._keys.data(p) for p in pkeys]
        pipe = r.pipeline(transaction=False)
        for k in data_keys:
            pipe.get(k)
        prevs = await pipe.execute()

        attempts: dict[str, bytes] = {
            pkey: (prev or b'') for pkey, prev in zip(pkeys, prevs)
        }

        # Phase 2: concurrent CAS via asyncio.gather. Cluster blocks evalsha
        # inside pipelines, so each Script call is routed independently.
        async def _one(pkey: str, prev: bytes):
            delta = deltas[pkey]
            if mode == 'merge':
                prev_dict = bson.BSON.decode(prev) if prev else {}
                merged = (
                    _deep_merge(prev_dict, delta) if prev_dict else dict(delta)
                )
            else:
                merged = dict(delta)
            new_bytes = bson.BSON.encode(merged)
            return await script(
                keys=[self._keys.data(pkey), counter_key],
                args=[prev, new_bytes, ttl],
                client=r,
            )

        for attempt in range(_MAX_CAS_RETRIES):
            if not attempts:
                return
            ordered = list(attempts.items())
            results = await asyncio.gather(
                *(_one(pk, prev) for pk, prev in ordered)
            )
            retry_keys = [pk for (pk, _), ok in zip(ordered, results) if not ok]
            if not retry_keys:
                return
            # Jittered exponential backoff to spread out re-contention.
            delay_ms = min(
                _CAS_BACKOFF_BASE_MS * (2 ** min(attempt, 6)),
                _CAS_BACKOFF_MAX_MS,
            )
            await asyncio.sleep(random.uniform(0, delay_ms) / 1000.0)
            # Re-snapshot conflicted keys and loop
            pipe = r.pipeline(transaction=False)
            for pk in retry_keys:
                pipe.get(self._keys.data(pk))
            new_prevs = await pipe.execute()
            attempts = {
                pk: (np or b'') for pk, np in zip(retry_keys, new_prevs)
            }

        raise RuntimeError(f'CAS retry exhausted for {list(attempts.keys())}')

    # ------------------------------------------------------------------
    # Enumeration — SCAN, no secondary index
    # ------------------------------------------------------------------
    def scan(self, keyword: str = '*', count: int = 500) -> Iterator[str]:
        pattern = self._keys.data_pattern(keyword)
        for key in self._redis.scan_iter(match=pattern, count=count):
            yield self._keys.extract_pkey(key)

    def list_keys(self, keyword: str = '*', count: int | None = None) -> list[str]:
        pattern = self._keys.data_pattern(keyword)
        scan_kw = {'match': pattern}
        if count is not None:
            scan_kw['count'] = count
        seen: set[str] = set()
        out: list[str] = []
        for key in self._redis.scan_iter(**scan_kw):
            pkey = self._keys.extract_pkey(key)
            if pkey in seen:
                continue
            seen.add(pkey)
            out.append(pkey)
            if count is not None and len(out) >= count:
                break
        return out

    def update_keys(self, keyword: str = '*', count: int | None = None) -> list[str]:
        """Legacy no-op: SCAN-based enumeration has nothing to rebuild."""
        return self.list_keys(keyword=keyword, count=count)

    def __iter__(self) -> Iterator[str]:
        yield from self.scan()

    # ------------------------------------------------------------------
    # Admin
    # ------------------------------------------------------------------
    def clear(self) -> None:
        batch: list = []
        for key in self._redis.scan_iter(match=self._keys.data_pattern(), count=1000):
            batch.append(key)
            if len(batch) >= 1000:
                self._redis.delete(*batch)
                batch.clear()
        if batch:
            self._redis.delete(*batch)
        meta_batch: list = []
        for key in self._redis.scan_iter(match=self._keys.meta_pattern(), count=1000):
            meta_batch.append(key)
            if len(meta_batch) >= 1000:
                self._redis.delete(*meta_batch)
                meta_batch.clear()
        if meta_batch:
            self._redis.delete(*meta_batch)

    def recursive_update(self, original: dict, updates: Mapping) -> dict:
        return _deep_merge(original, updates)


class _HeaderShim:
    """Dict-like view over {path}:META:<field>. Compatible with old CacheHeader."""

    def __init__(self, cache: CacheRedis):
        self._cache = cache

    def _key(self, field: str) -> str:
        return self._cache._keys.meta(field)

    def get_hash(self, field: str) -> str:
        return self._key(field)

    def __getitem__(self, field: str):
        return self._cache._redis.get(self._key(field))

    def get(self, field: str, default=None):
        val = self._cache._redis.get(self._key(field))
        return val if val is not None else default

    def __setitem__(self, field: str, value) -> None:
        self._cache._redis.set(self._key(field), value)

    def set(self, field: str, value) -> None:
        self._cache._redis.set(self._key(field), value)

    def __delitem__(self, field: str) -> None:
        self._cache._redis.delete(self._key(field))

    def __iter__(self):
        for key in self._cache._redis.scan_iter(match=self._cache._keys.meta_pattern()):
            yield self._cache._keys.extract_meta(key)

    def list_keys(self, keyword: str = '*', count: int | None = None) -> list[str]:
        pattern = self._cache._keys.meta_pattern(keyword)
        scan_kw = {'match': pattern}
        if count is not None:
            scan_kw['count'] = count
        return [
            self._cache._keys.extract_meta(k)
            for k in self._cache._redis.scan_iter(**scan_kw)
        ]

    def incrby(self, field: str, value: int) -> int:
        return int(self._cache._redis.incrby(self._key(field), value))

    async def async_incrby(self, field: str, value: int) -> int:
        r = self._cache._get_async()
        return int(await r.incrby(self._key(field), value))


# Back-compat: old imports of CacheHeader still resolve.
CacheHeader = _HeaderShim
