"""Tests for Tika extraction enqueue logic in CatalogStateProcessor."""

from plone.pgcatalog.processor import _should_extract
from plone.pgcatalog.processor import CatalogStateProcessor
from plone.pgcatalog.processor import TIKA_URL
from plone.pgcatalog.schema import TEXT_EXTRACTION_QUEUE
from psycopg.rows import dict_row
from tests.conftest import DSN
from tests.conftest import insert_object
from unittest import mock

import json
import psycopg.errors
import pytest


class TestMimeTypeFromIdx:
    """Test content_type extraction from idx.mime_type (#90).

    Pure unit tests — no PG or TIKA_URL needed.
    """

    def test_mime_type_from_idx(self):
        """MIME type is read from idx.mime_type for Tika enqueue."""
        from plone.pgcatalog.pending import set_pending

        proc = CatalogStateProcessor()
        proc._tika_candidates = []

        with mock.patch("plone.pgcatalog.processor.TIKA_URL", "http://tika:9998"):
            zoid = 600
            set_pending(
                zoid,
                {
                    "path": "/plone/test.pdf",
                    "idx": {"portal_type": "File", "mime_type": "application/pdf"},
                    "searchable_text": "",
                },
            )

            state = json.dumps({"file": {"_blob": {"@ref": "00000000000003e8"}}})
            proc.process(zoid, "plone.app.contenttypes.content", "File", state)

        assert len(proc._tika_candidates) == 1
        assert proc._tika_candidates[0]["content_type"] == "application/pdf"

    def test_no_mime_type_no_candidate(self):
        """No mime_type in idx → no Tika candidate (e.g. Document, no blob)."""
        from plone.pgcatalog.pending import set_pending

        proc = CatalogStateProcessor()
        proc._tika_candidates = []

        with mock.patch("plone.pgcatalog.processor.TIKA_URL", "http://tika:9998"):
            zoid = 601
            set_pending(
                zoid,
                {
                    "path": "/plone/page",
                    "idx": {"portal_type": "Document"},
                    "searchable_text": "text",
                },
            )

            state = json.dumps({"title": "A page"})
            proc.process(zoid, "plone.app.contenttypes.content", "Document", state)

        assert len(proc._tika_candidates) == 0

    def test_non_extractable_mime_type(self):
        """text/html mime_type → not extractable, no candidate."""
        from plone.pgcatalog.pending import set_pending

        proc = CatalogStateProcessor()
        proc._tika_candidates = []

        with mock.patch("plone.pgcatalog.processor.TIKA_URL", "http://tika:9998"):
            zoid = 602
            set_pending(
                zoid,
                {
                    "path": "/plone/page.html",
                    "idx": {"portal_type": "Document", "mime_type": "text/html"},
                    "searchable_text": "",
                },
            )

            state = json.dumps({"title": "HTML page"})
            proc.process(zoid, "plone.app.contenttypes.content", "Document", state)

        assert len(proc._tika_candidates) == 0


# Skip if no PG available
pytestmark = pytest.mark.skipif(not DSN, reason="No PostgreSQL DSN configured")


@pytest.fixture
def pg_conn_with_queue(pg_conn_with_catalog):
    """Database with catalog schema + extraction queue table."""
    conn = pg_conn_with_catalog
    # Drop and recreate to ensure clean state between tests
    conn.execute("DROP TABLE IF EXISTS text_extraction_queue, blob_state CASCADE")
    conn.commit()
    conn.execute(TEXT_EXTRACTION_QUEUE)
    conn.commit()
    conn.execute(
        "CREATE TABLE IF NOT EXISTS blob_state ("
        "  zoid BIGINT NOT NULL,"
        "  tid BIGINT NOT NULL,"
        "  blob_size BIGINT NOT NULL DEFAULT 0,"
        "  data BYTEA,"
        "  s3_key TEXT,"
        "  PRIMARY KEY (zoid, tid)"
        ")"
    )
    conn.commit()
    return conn


class TestShouldExtract:
    """Test content type filtering."""

    def test_pdf(self):
        assert _should_extract("application/pdf") is True

    def test_docx(self):
        assert (
            _should_extract(
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
            is True
        )

    def test_jpeg(self):
        assert _should_extract("image/jpeg") is True

    def test_png(self):
        assert _should_extract("image/png") is True

    def test_html_not_extracted(self):
        assert _should_extract("text/html") is False

    def test_none_not_extracted(self):
        assert _should_extract(None) is False

    def test_empty_not_extracted(self):
        assert _should_extract("") is False


class TestEnqueueLogic:
    """Test that finalize() enqueues jobs for blobs."""

    def _insert_blob(self, conn, zoid, tid, data=b"fake-pdf-data"):
        """Insert a blob_state row."""
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO blob_state (zoid, tid, blob_size, data) "
                "VALUES (%(zoid)s, %(tid)s, %(size)s, %(data)s) "
                "ON CONFLICT DO NOTHING",
                {"zoid": zoid, "tid": tid, "size": len(data), "data": data},
            )
        conn.commit()

    def _get_queue(self, conn):
        """Return all rows from text_extraction_queue."""
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute("SELECT * FROM text_extraction_queue ORDER BY id")
            return cur.fetchall()

    @pytest.mark.skipif(not TIKA_URL, reason="PGCATALOG_TIKA_URL not set")
    def test_enqueue_blob_with_tika_url(self, pg_conn_with_queue):
        """When TIKA_URL is set and object has a blob, job is enqueued.

        The content object (zoid=100) references a separate blob object
        (zoid=999) via @ref in its state.  The queue must store both.
        """
        conn = pg_conn_with_queue
        content_zoid, blob_zoid, tid = 100, 999, 1

        insert_object(conn, content_zoid, tid)
        self._insert_blob(conn, blob_zoid, tid)

        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {
                "zoid": content_zoid,
                "content_type": "application/pdf",
                "blob_refs": [blob_zoid],
            }
        ]

        with conn.cursor(row_factory=dict_row) as cur:
            proc._enqueue_tika_jobs(cur)
        conn.commit()

        rows = self._get_queue(conn)
        assert len(rows) == 1
        assert rows[0]["zoid"] == content_zoid
        assert rows[0]["blob_zoid"] == blob_zoid
        assert rows[0]["tid"] == tid
        assert rows[0]["content_type"] == "application/pdf"
        assert rows[0]["status"] == "pending"

    @pytest.mark.skipif(not TIKA_URL, reason="PGCATALOG_TIKA_URL not set")
    def test_no_enqueue_without_blob(self, pg_conn_with_queue):
        """When referenced oids have no blob_state entry, no job is enqueued."""
        conn = pg_conn_with_queue
        content_zoid, tid = 200, 1

        insert_object(conn, content_zoid, tid)

        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {
                "zoid": content_zoid,
                "content_type": "application/pdf",
                "blob_refs": [9999],  # no blob_state entry for this ref
            }
        ]

        with conn.cursor(row_factory=dict_row) as cur:
            proc._enqueue_tika_jobs(cur)
        conn.commit()

        rows = self._get_queue(conn)
        assert len(rows) == 0

    @pytest.mark.skipif(not TIKA_URL, reason="PGCATALOG_TIKA_URL not set")
    def test_no_enqueue_without_refs(self, pg_conn_with_queue):
        """Candidates with empty blob_refs don't query blob_state."""
        conn = pg_conn_with_queue

        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {"zoid": 200, "content_type": "application/pdf", "blob_refs": []}
        ]

        with conn.cursor(row_factory=dict_row) as cur:
            proc._enqueue_tika_jobs(cur)
        conn.commit()

        assert self._get_queue(conn) == []

    @pytest.mark.skipif(not TIKA_URL, reason="PGCATALOG_TIKA_URL not set")
    def test_idempotent_enqueue(self, pg_conn_with_queue):
        """Duplicate enqueue for same blob_zoid+tid is ignored."""
        conn = pg_conn_with_queue
        content_zoid, blob_zoid, tid = 300, 888, 1

        insert_object(conn, content_zoid, tid)
        self._insert_blob(conn, blob_zoid, tid)

        proc = CatalogStateProcessor()

        for _ in range(2):
            proc._tika_candidates = [
                {
                    "zoid": content_zoid,
                    "content_type": "application/pdf",
                    "blob_refs": [blob_zoid],
                }
            ]
            with conn.cursor(row_factory=dict_row) as cur:
                proc._enqueue_tika_jobs(cur)
            conn.commit()

        rows = self._get_queue(conn)
        assert len(rows) == 1

    @pytest.mark.skipif(not TIKA_URL, reason="PGCATALOG_TIKA_URL not set")
    def test_enqueue_resolves_wrapper_oid(self, pg_conn_with_queue):
        """Dexterity NamedBlobFile wrapper: one-level hop to inner Blob.

        Content state @ref points at wrapper (object_state), wrapper
        state @ref points at Blob (blob_state).  Queue must store the
        inner Blob OID, not the wrapper.
        """
        conn = pg_conn_with_queue
        content_zoid, wrapper_zoid, blob_zoid, tid = 700, 701, 702, 1

        # Content object has no direct blob entry; its ref points at the
        # NamedBlobFile wrapper.
        insert_object(conn, content_zoid, tid)
        # The wrapper is a persistent object whose state carries the
        # real Blob @ref.
        wrapper_state = json.dumps(
            {
                "_blob": {
                    "@ref": [f"{blob_zoid:016x}", "ZODB.blob.Blob"],
                },
                "filename": "sample.pdf",
                "contentType": "application/pdf",
            }
        )
        insert_object(
            conn,
            wrapper_zoid,
            tid,
            class_mod="plone.namedfile.file",
            class_name="NamedBlobFile",
            state=wrapper_state,
        )
        self._insert_blob(conn, blob_zoid, tid)

        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {
                "zoid": content_zoid,
                "content_type": "application/pdf",
                "blob_refs": [wrapper_zoid],  # wrapper only, no direct blob
            }
        ]

        with conn.cursor(row_factory=dict_row) as cur:
            proc._enqueue_tika_jobs(cur)
        conn.commit()

        rows = self._get_queue(conn)
        assert len(rows) == 1
        assert rows[0]["zoid"] == content_zoid
        assert rows[0]["blob_zoid"] == blob_zoid  # inner, NOT wrapper_zoid
        assert rows[0]["tid"] == tid
        assert rows[0]["content_type"] == "application/pdf"

    @pytest.mark.skipif(not TIKA_URL, reason="PGCATALOG_TIKA_URL not set")
    def test_enqueue_mixed_flat_and_wrapper(self, pg_conn_with_queue):
        """Mix: one candidate has direct blob ref, another has wrapper ref.

        Both should enqueue against the correct inner OID.
        """
        conn = pg_conn_with_queue

        # Flat: content 800 -> blob 801 (direct)
        flat_content, flat_blob, tid = 800, 801, 1
        insert_object(conn, flat_content, tid)
        self._insert_blob(conn, flat_blob, tid)

        # Wrapped: content 810 -> wrapper 811 -> blob 812
        wrap_content, wrap_oid, wrap_blob = 810, 811, 812
        insert_object(conn, wrap_content, tid)
        insert_object(
            conn,
            wrap_oid,
            tid,
            class_mod="plone.namedfile.file",
            class_name="NamedBlobImage",
            state=json.dumps(
                {"_blob": {"@ref": [f"{wrap_blob:016x}", "ZODB.blob.Blob"]}}
            ),
        )
        self._insert_blob(conn, wrap_blob, tid)

        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {
                "zoid": flat_content,
                "content_type": "application/pdf",
                "blob_refs": [flat_blob],
            },
            {
                "zoid": wrap_content,
                "content_type": "image/png",
                "blob_refs": [wrap_oid],
            },
        ]

        with conn.cursor(row_factory=dict_row) as cur:
            proc._enqueue_tika_jobs(cur)
        conn.commit()

        rows = {r["zoid"]: r for r in self._get_queue(conn)}
        assert rows[flat_content]["blob_zoid"] == flat_blob
        assert rows[wrap_content]["blob_zoid"] == wrap_blob
        assert rows[wrap_content]["content_type"] == "image/png"

    @pytest.mark.skipif(not TIKA_URL, reason="PGCATALOG_TIKA_URL not set")
    def test_enqueue_wrapper_with_missing_inner_blob(self, pg_conn_with_queue):
        """Wrapper exists in object_state but inner blob is missing."""
        conn = pg_conn_with_queue
        content_zoid, wrapper_zoid, tid = 820, 821, 1
        missing_blob = 99999

        insert_object(conn, content_zoid, tid)
        insert_object(
            conn,
            wrapper_zoid,
            tid,
            class_mod="plone.namedfile.file",
            class_name="NamedBlobFile",
            state=json.dumps(
                {"_blob": {"@ref": [f"{missing_blob:016x}", "ZODB.blob.Blob"]}}
            ),
        )
        # no blob_state row for missing_blob

        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {
                "zoid": content_zoid,
                "content_type": "application/pdf",
                "blob_refs": [wrapper_zoid],
            }
        ]

        with conn.cursor(row_factory=dict_row) as cur:
            proc._enqueue_tika_jobs(cur)
        conn.commit()

        assert self._get_queue(conn) == []

    @pytest.mark.skipif(not TIKA_URL, reason="PGCATALOG_TIKA_URL not set")
    def test_enqueue_ignores_unresolvable_refs(self, pg_conn_with_queue):
        """Ref with neither blob_state nor object_state entry is a noop."""
        conn = pg_conn_with_queue
        content_zoid, tid = 830, 1
        ghost_ref = 0xDEADBEEF

        insert_object(conn, content_zoid, tid)

        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {
                "zoid": content_zoid,
                "content_type": "application/pdf",
                "blob_refs": [ghost_ref],
            }
        ]

        with conn.cursor(row_factory=dict_row) as cur:
            proc._enqueue_tika_jobs(cur)
        conn.commit()

        assert self._get_queue(conn) == []

    def test_process_accumulates_candidates_with_blob_refs(self, pg_conn_with_queue):
        """process() accumulates tika candidates with blob_refs from state."""
        from plone.pgcatalog.pending import set_pending

        proc = CatalogStateProcessor()
        proc._tika_candidates = []

        if not TIKA_URL:
            pytest.skip("PGCATALOG_TIKA_URL not set")

        zoid = 400
        set_pending(
            zoid,
            {
                "path": "/plone/test",
                "idx": {"portal_type": "File", "mime_type": "application/pdf"},
                "searchable_text": "test document",
            },
        )

        # State with a blob @ref
        state = {"file": {"_blob": {"@ref": "00000000000003e8"}}}
        proc.process(zoid, "plone.app.contenttypes.content", "File", state)
        assert len(proc._tika_candidates) == 1
        assert proc._tika_candidates[0]["zoid"] == zoid
        assert proc._tika_candidates[0]["content_type"] == "application/pdf"
        assert proc._tika_candidates[0]["blob_refs"] == [0x3E8]

    def test_process_skips_candidate_without_refs(self, pg_conn_with_queue):
        """process() does not accumulate candidate if state has no @ref."""
        from plone.pgcatalog.pending import set_pending

        proc = CatalogStateProcessor()
        proc._tika_candidates = []

        if not TIKA_URL:
            pytest.skip("PGCATALOG_TIKA_URL not set")

        zoid = 500
        set_pending(
            zoid,
            {
                "path": "/plone/test2",
                "idx": {"portal_type": "File", "mime_type": "application/pdf"},
                "searchable_text": "",
            },
        )

        # State with no blob references
        state = {"title": "No blob here"}
        proc.process(zoid, "plone.app.contenttypes.content", "File", state)
        assert len(proc._tika_candidates) == 0


class TestEnqueueUnit:
    """Unit tests for _enqueue_tika_jobs + _insert_queue_row — mocked cursor, no DB, no TIKA_URL gate.

    These tests run unconditionally so the wrapper-resolution code
    path is exercised in environments (e.g. CI) where
    PGCATALOG_TIKA_URL is not configured.
    """

    def _make_cursor(self, responses):
        """Return a MagicMock cursor whose consecutive fetchall() calls
        return the rows in *responses* (a list of row-lists).
        """
        cur = mock.MagicMock()
        cur.fetchall.side_effect = responses
        return cur

    def test_empty_candidates_is_noop(self):
        proc = CatalogStateProcessor()
        proc._tika_candidates = []
        cur = mock.MagicMock()
        proc._enqueue_tika_jobs(cur)
        cur.execute.assert_not_called()

    def test_direct_blob_ref_inserts_row(self):
        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {"zoid": 100, "content_type": "application/pdf", "blob_refs": [999]}
        ]
        # First fetchall: direct blob_state lookup returns {"zoid": 999, "tid": 1}
        cur = self._make_cursor([[{"zoid": 999, "tid": 1}]])

        proc._enqueue_tika_jobs(cur)

        # Exactly 2 execute calls: 1 SELECT (direct lookup) + 1 INSERT
        assert cur.execute.call_count == 2
        insert_sql = cur.execute.call_args_list[1].args[0]
        insert_params = cur.execute.call_args_list[1].args[1]
        assert "INSERT INTO text_extraction_queue" in insert_sql
        assert insert_params == {
            "zoid": 100,
            "blob_zoid": 999,
            "tid": 1,
            "ct": "application/pdf",
        }

    def test_wrapper_oid_hops_through_object_state(self):
        """Wrapper ref -> object_state -> inner blob ref -> blob_state.

        Content ref is a wrapper OID with no direct blob_state entry.
        Second-hop fetch returns the wrapper's state (JSON string with
        @ref to inner Blob).  Third fetch returns the inner blob row.
        """
        proc = CatalogStateProcessor()
        wrapper_oid = 701
        inner_blob_oid = 702
        proc._tika_candidates = [
            {
                "zoid": 700,
                "content_type": "application/pdf",
                "blob_refs": [wrapper_oid],
            }
        ]
        wrapper_state = json.dumps(
            {"_blob": {"@ref": [f"{inner_blob_oid:016x}", "ZODB.blob.Blob"]}}
        )
        cur = self._make_cursor(
            [
                [],  # 1st SELECT: no direct blob_state row for wrapper_oid
                [{"zoid": wrapper_oid, "state": wrapper_state}],  # 2nd SELECT
                [{"zoid": inner_blob_oid, "tid": 1}],  # 3rd SELECT
            ]
        )

        proc._enqueue_tika_jobs(cur)

        # 3 SELECT + 1 INSERT = 4 execute calls
        assert cur.execute.call_count == 4
        insert_params = cur.execute.call_args_list[3].args[1]
        assert insert_params["zoid"] == 700
        assert insert_params["blob_zoid"] == inner_blob_oid  # NOT wrapper
        assert insert_params["tid"] == 1

    def test_unresolved_ref_without_wrapper_state_is_silent_skip(self):
        """Ref has neither blob_state nor object_state row — no INSERT, no error."""
        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {"zoid": 800, "content_type": "application/pdf", "blob_refs": [9999]}
        ]
        cur = self._make_cursor(
            [
                [],  # 1st SELECT: blob_state empty
                [],  # 2nd SELECT: object_state empty (no wrapper state)
            ]
        )

        proc._enqueue_tika_jobs(cur)

        # 2 SELECTs, 0 INSERTs
        assert cur.execute.call_count == 2
        # No INSERT call
        for call in cur.execute.call_args_list:
            assert "INSERT" not in call.args[0]

    def test_wrapper_state_without_inner_refs_is_silent_skip(self):
        """Wrapper exists in object_state but its state has no @ref."""
        proc = CatalogStateProcessor()
        proc._tika_candidates = [
            {"zoid": 810, "content_type": "application/pdf", "blob_refs": [811]}
        ]
        # Wrapper state has no @ref — defensive path
        cur = self._make_cursor(
            [
                [],  # no direct blob row
                [{"zoid": 811, "state": json.dumps({"filename": "empty.pdf"})}],
            ]
        )

        proc._enqueue_tika_jobs(cur)

        # Only 2 SELECTs (no 3rd because inner_refs is empty), no INSERT
        assert cur.execute.call_count == 2

    def test_insert_queue_row_uses_correct_sql_and_params(self):
        proc = CatalogStateProcessor()
        cur = mock.MagicMock()
        proc._insert_queue_row(
            cur, zoid=42, blob_zoid=43, tid=7, content_type="image/png"
        )

        cur.execute.assert_called_once()
        sql, params = cur.execute.call_args.args
        assert "INSERT INTO text_extraction_queue" in sql
        assert "ON CONFLICT (blob_zoid, tid) DO NOTHING" in sql
        assert params == {
            "zoid": 42,
            "blob_zoid": 43,
            "tid": 7,
            "ct": "image/png",
        }


class TestQueueSchema:
    """Test the queue table schema."""

    def test_queue_table_exists(self, pg_conn_with_queue):
        conn = pg_conn_with_queue
        with conn.cursor() as cur:
            cur.execute(
                "SELECT EXISTS ("
                "  SELECT FROM information_schema.tables "
                "  WHERE table_name = 'text_extraction_queue'"
                ")"
            )
            assert cur.fetchone()["exists"] is True

    def test_unique_constraint_on_blob_zoid_tid(self, pg_conn_with_queue):
        conn = pg_conn_with_queue
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO text_extraction_queue (zoid, blob_zoid, tid) "
                "VALUES (1, 10, 1)"
            )
            conn.commit()
            # Same blob_zoid+tid should conflict
            with pytest.raises(psycopg.errors.UniqueViolation):
                cur.execute(
                    "INSERT INTO text_extraction_queue (zoid, blob_zoid, tid) "
                    "VALUES (2, 10, 1)"
                )
            conn.rollback()

    def test_different_content_same_blob_allowed(self, pg_conn_with_queue):
        """Different content zoids with same blob_zoid+tid still conflict."""
        conn = pg_conn_with_queue
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO text_extraction_queue (zoid, blob_zoid, tid) "
                "VALUES (1, 10, 1)"
            )
            conn.commit()
            # Different zoid, same blob_zoid+tid — still unique violation
            with pytest.raises(psycopg.errors.UniqueViolation):
                cur.execute(
                    "INSERT INTO text_extraction_queue (zoid, blob_zoid, tid) "
                    "VALUES (99, 10, 1)"
                )
            conn.rollback()

    def test_notify_trigger_exists(self, pg_conn_with_queue):
        conn = pg_conn_with_queue
        with conn.cursor() as cur:
            cur.execute(
                "SELECT tgname FROM pg_trigger WHERE tgname = 'trg_notify_extraction'"
            )
            row = cur.fetchone()
            assert row is not None
