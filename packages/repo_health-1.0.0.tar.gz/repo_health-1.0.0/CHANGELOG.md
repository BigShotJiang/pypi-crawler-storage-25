# Changelog

## [1.0.0] - 2026-04-30

### Added

- 8 category scanners: CI/CD, Testing, Documentation, Security, Dependencies, Community, Release, Git Hygiene
- 20+ health signals with weighted scoring (0-100)
- A-F grading system with actionable recommendations
- Rich terminal output with colored tables and panels
- JSON, Markdown, and SVG badge output formats
- Custom weights via `.repo-health.toml` or `pyproject.toml`
- `--min-score` flag for CI gating
- `--ci` mode for automated pipelines
- GitHub Action for PR checks
- PyPI distribution via Hatchling
- 95%+ test coverage
