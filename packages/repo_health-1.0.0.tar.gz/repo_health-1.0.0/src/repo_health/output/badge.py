"""SVG badge generator for health score."""

from __future__ import annotations

from pathlib import Path

from repo_health.scoring.grades import grade_color_hex

BADGE_TEMPLATE = """\
<svg xmlns="http://www.w3.org/2000/svg" width="144" height="20">
  <linearGradient id="b" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <mask id="a">
    <rect width="144" height="20" rx="3" fill="#fff"/>
  </mask>
  <g mask="url(#a)">
    <rect width="82" height="20" fill="#555"/>
    <rect x="82" width="62" height="20" fill="{color}"/>
    <rect width="144" height="20" fill="url(#b)"/>
  </g>
  <g fill="#fff" text-anchor="middle"
     font-family="DejaVu Sans,Verdana,Geneva,sans-serif"
     font-size="11">
    <text x="41" y="15" fill="#010101" fill-opacity=".3">repo health</text>
    <text x="41" y="14">repo health</text>
    <text x="113" y="15" fill="#010101" fill-opacity=".3">{score} {grade}</text>
    <text x="113" y="14">{score} {grade}</text>
  </g>
</svg>"""


def render_badge(score: float, grade: str, output_path: Path | None = None) -> str:
    color = grade_color_hex(grade)
    svg = BADGE_TEMPLATE.format(score=f"{score:.0f}", grade=grade, color=color)

    if output_path:
        output_path.write_text(svg, encoding="utf-8")

    return svg
