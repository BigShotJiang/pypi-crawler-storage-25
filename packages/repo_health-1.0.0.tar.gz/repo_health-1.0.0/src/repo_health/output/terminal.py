"""Rich terminal output for health reports."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from repo_health.scoring.engine import HealthReport
from repo_health.scoring.grades import grade_color
from repo_health.scoring.tips import get_recommendations


def render_terminal(report: HealthReport, console: Console | None = None) -> None:
    console = console or Console()

    score = report.total_score
    grade = report.grade
    color = grade_color(grade)

    score_line = (
        f"[bold]{report.repo_name}[/bold]  ·  "
        f"Score: [bold {color}]{score:.0f}/100  {grade}[/bold {color}]"
    )
    header = Panel(
        score_line,
        title="[bold]\U0001f3e5 Repository Health Report[/bold]",
        expand=False,
    )
    console.print(header)
    console.print()

    table = Table(show_header=True, header_style="bold")
    table.add_column("Category", style="bold", min_width=14)
    table.add_column("Score", justify="right", min_width=6)
    table.add_column("Details", min_width=30)

    for category, result in report.results.items():
        cat_score = result.score
        details = ", ".join(result.details)
        if cat_score >= 80:
            score_str = f"[bright_green]{cat_score:.0f}[/bright_green]"
        elif cat_score >= 60:
            score_str = f"[yellow]{cat_score:.0f}[/yellow]"
        else:
            score_str = f"[red]{cat_score:.0f}[/red]"
        table.add_row(category, score_str, details)

    console.print(table)
    console.print()

    tips = get_recommendations(report)
    if tips:
        console.print("[bold]\U0001f4a1 Top Recommendations:[/bold]")
        for i, tip in enumerate(tips, 1):
            console.print(f"  {i}. {tip}")
        console.print()
