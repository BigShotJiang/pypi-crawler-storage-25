"""JSON output for health reports."""

from __future__ import annotations

import json
from pathlib import Path

from repo_health.scoring.engine import HealthReport
from repo_health.scoring.tips import get_recommendations


def render_json(report: HealthReport, output_path: Path | None = None) -> str:
    data = {
        "repo": report.repo_name,
        "score": round(report.total_score, 1),
        "grade": report.grade,
        "categories": {},
        "recommendations": get_recommendations(report),
    }

    for category, result in report.results.items():
        data["categories"][category] = {
            "score": round(result.score, 1),
            "checks": [
                {
                    "name": c.name,
                    "passed": c.passed,
                    "message": c.message,
                }
                for c in result.checks
            ],
        }

    json_str = json.dumps(data, indent=2)

    if output_path:
        output_path.write_text(json_str, encoding="utf-8")

    return json_str
