"""Markdown output for health reports."""

from __future__ import annotations

from pathlib import Path

from repo_health.scoring.engine import HealthReport
from repo_health.scoring.tips import get_recommendations


def render_markdown(report: HealthReport, output_path: Path | None = None) -> str:
    lines: list[str] = []

    lines.append(f"# Repository Health Report: {report.repo_name}")
    lines.append("")
    lines.append(f"**Score: {report.total_score:.0f}/100 ({report.grade})**")
    lines.append("")
    lines.append("| Category | Score | Details |")
    lines.append("|----------|------:|---------|")

    for category, result in report.results.items():
        details = ", ".join(result.details)
        lines.append(f"| {category} | {result.score:.0f} | {details} |")

    lines.append("")

    tips = get_recommendations(report)
    if tips:
        lines.append("## Recommendations")
        lines.append("")
        for i, tip in enumerate(tips, 1):
            lines.append(f"{i}. {tip}")
        lines.append("")

    md = "\n".join(lines)

    if output_path:
        output_path.write_text(md, encoding="utf-8")

    return md
