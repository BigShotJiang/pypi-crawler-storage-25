"""Scoring engine — calculates weighted health score from scan results."""

from __future__ import annotations

from dataclasses import dataclass, field

from repo_health.scanners.base import ScanResult

DEFAULT_WEIGHTS: dict[str, int] = {
    "CI/CD": 15,
    "Testing": 15,
    "Documentation": 15,
    "Security": 15,
    "Dependencies": 10,
    "Community": 10,
    "Release": 10,
    "Git Hygiene": 10,
}


@dataclass
class HealthReport:
    """Complete health report for a repository."""

    repo_name: str
    results: dict[str, ScanResult] = field(default_factory=dict)
    weights: dict[str, int] = field(default_factory=lambda: dict(DEFAULT_WEIGHTS))

    @property
    def total_score(self) -> float:
        total_weight = sum(self.weights.get(cat, 10) for cat in self.results)
        if total_weight == 0:
            return 0.0
        weighted_sum = sum(
            result.score * self.weights.get(cat, 10)
            for cat, result in self.results.items()
        )
        return weighted_sum / total_weight

    @property
    def grade(self) -> str:
        from repo_health.scoring.grades import score_to_grade

        return score_to_grade(self.total_score)

    def category_scores(self) -> dict[str, float]:
        return {cat: result.score for cat, result in self.results.items()}


def calculate_score(
    results: list[ScanResult],
    weights: dict[str, int] | None = None,
    repo_name: str = "",
) -> HealthReport:
    w = weights or dict(DEFAULT_WEIGHTS)
    report = HealthReport(repo_name=repo_name, weights=w)
    for result in results:
        report.results[result.category] = result
    return report
