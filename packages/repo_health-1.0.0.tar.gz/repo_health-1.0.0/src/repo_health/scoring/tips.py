"""Actionable recommendations based on scan results."""

from __future__ import annotations

from repo_health.scoring.engine import HealthReport

TIPS: dict[str, list[tuple[str, str]]] = {
    "CI/CD": [
        ("ci_config_exists", "Add a CI configuration (e.g., .github/workflows/ci.yml)"),
        ("tests_in_ci", "Add a test step to your CI pipeline"),
        ("build_step", "Add a build step to your CI pipeline"),
        ("deploy_step", "Add a deploy/publish step for automated releases"),
    ],
    "Testing": [
        ("test_files_exist", "Add test files to validate your code"),
        ("coverage_config", "Configure coverage reporting (e.g., pytest-cov)"),
        ("coverage_threshold", "Set a coverage threshold to prevent regressions"),
    ],
    "Documentation": [
        ("readme_exists", "Create a README.md with project description"),
        ("readme_quality", "Add install, usage, and contributing sections to README"),
        ("readme_badges", "Add status badges (CI, coverage, version) to README"),
        ("license_exists", "Add a LICENSE file to clarify usage rights"),
        ("contributing_exists", "Add CONTRIBUTING.md with contribution guidelines"),
        ("changelog_exists", "Add CHANGELOG.md to track version history"),
    ],
    "Security": [
        (
            "gitignore_quality",
            "Improve .gitignore to cover common patterns"
            " (.env, __pycache__, node_modules)",
        ),
        ("no_secrets", "Remove detected secrets and use environment variables instead"),
        ("security_md", "Create SECURITY.md with vulnerability reporting process"),
        ("dependency_audit", "Add dependency auditing (pip-audit, npm audit) to CI"),
    ],
    "Dependencies": [
        ("manifest_exists", "Add a dependency manifest (pyproject.toml, package.json)"),
        ("lock_file", "Add a lock file for reproducible builds"),
        ("version_pinning", "Pin dependency versions to avoid breaking changes"),
        ("audit_tool", "Configure Dependabot or Renovate for dependency updates"),
    ],
    "Community": [
        ("issue_template", "Add issue templates in .github/ISSUE_TEMPLATE/"),
        ("pr_template", "Add a PR template at .github/PULL_REQUEST_TEMPLATE.md"),
        ("code_of_conduct", "Add CODE_OF_CONDUCT.md for community standards"),
        ("contributing_guide", "Add CONTRIBUTING.md to guide contributors"),
    ],
    "Release": [
        ("has_tags", "Create release tags (e.g., v1.0.0) for versioned releases"),
        ("semver", "Use semantic versioning (vMAJOR.MINOR.PATCH) for tags"),
        ("release_notes", "Add a CHANGELOG.md or release notes"),
    ],
    "Git Hygiene": [
        ("is_git_repo", "Initialize a git repository"),
        (
            "commit_quality",
            "Write descriptive commit messages (consider conventional commits)",
        ),
        ("default_branch", "Ensure a main or master branch exists"),
    ],
}


def get_recommendations(report: HealthReport, max_tips: int = 5) -> list[str]:
    recommendations: list[str] = []
    for category, result in report.results.items():
        failed_checks = {c.name for c in result.checks if not c.passed}
        category_tips = TIPS.get(category, [])
        for check_name, tip in category_tips:
            if check_name in failed_checks:
                recommendations.append(tip)

    return recommendations[:max_tips]
