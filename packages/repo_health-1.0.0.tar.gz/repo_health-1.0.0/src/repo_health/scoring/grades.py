"""Grading system — converts numeric score to letter grade."""

from __future__ import annotations

GRADE_THRESHOLDS: list[tuple[float, str]] = [
    (90, "A+"),
    (85, "A"),
    (80, "A-"),
    (75, "B+"),
    (70, "B"),
    (65, "B-"),
    (60, "C+"),
    (55, "C"),
    (50, "C-"),
    (40, "D"),
    (0, "F"),
]


def score_to_grade(score: float) -> str:
    for threshold, grade in GRADE_THRESHOLDS:
        if score >= threshold:
            return grade
    return "F"


def grade_color(grade: str) -> str:
    if grade.startswith("A"):
        return "bright_green"
    if grade.startswith("B"):
        return "green"
    if grade.startswith("C"):
        return "yellow"
    if grade.startswith("D"):
        return "orange1"
    return "red"


def grade_color_hex(grade: str) -> str:
    if grade.startswith("A"):
        return "#4c1"
    if grade.startswith("B"):
        return "#97ca00"
    if grade.startswith("C"):
        return "#dfb317"
    if grade.startswith("D"):
        return "#fe7d37"
    return "#e05d44"
