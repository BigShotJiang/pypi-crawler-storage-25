"""Configuration loading from .repo-health.toml or pyproject.toml."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib
    except ModuleNotFoundError:
        import tomli as tomllib  # type: ignore[no-redef]


@dataclass
class Config:
    weights: dict[str, int] = field(default_factory=dict)
    min_score: float = 0.0
    ignore_scanners: list[str] = field(default_factory=list)
    ignore_paths: list[str] = field(default_factory=list)


def load_config(repo_path: Path, config_path: str | None = None) -> Config:
    if config_path:
        p = Path(config_path)
        if p.is_file():
            return _parse_config(p)

    repo_config = repo_path / ".repo-health.toml"
    if repo_config.is_file():
        return _parse_config(repo_config)

    pyproject = repo_path / "pyproject.toml"
    if pyproject.is_file():
        data = _load_toml(pyproject)
        tool_section = data.get("tool", {}).get("repo-health", {})
        if tool_section:
            return _extract_config(tool_section)

    return Config()


def _load_toml(path: Path) -> dict:
    with open(path, "rb") as f:
        return tomllib.load(f)


def _parse_config(path: Path) -> Config:
    data = _load_toml(path)
    return _extract_config(data)


def _extract_config(data: dict) -> Config:
    config = Config()

    if "weights" in data:
        config.weights = {k: int(v) for k, v in data["weights"].items()}

    thresholds = data.get("thresholds", {})
    config.min_score = float(thresholds.get("min_score", 0))

    ignore = data.get("ignore", {})
    config.ignore_scanners = list(ignore.get("scanners", []))
    config.ignore_paths = list(ignore.get("files", []))

    return config
