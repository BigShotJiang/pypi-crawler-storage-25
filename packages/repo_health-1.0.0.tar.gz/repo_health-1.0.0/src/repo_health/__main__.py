"""Allow running as `python -m repo_health`."""

from repo_health.cli import app

if __name__ == "__main__":  # pragma: no cover
    app()
