"""Typer CLI for repo-health."""

from __future__ import annotations

from enum import Enum
from pathlib import Path

import typer
from rich.console import Console

from repo_health import __version__
from repo_health.config import load_config
from repo_health.output.badge import render_badge
from repo_health.output.json_output import render_json
from repo_health.output.markdown_output import render_markdown
from repo_health.output.terminal import render_terminal
from repo_health.scanners.base import ScanResult
from repo_health.scanners.ci_scanner import CIScanner
from repo_health.scanners.community_scanner import CommunityScanner
from repo_health.scanners.deps_scanner import DepsScanner
from repo_health.scanners.docs_scanner import DocsScanner
from repo_health.scanners.git_scanner import GitScanner
from repo_health.scanners.release_scanner import ReleaseScanner
from repo_health.scanners.security_scanner import SecurityScanner
from repo_health.scanners.test_scanner import TestScanner
from repo_health.scoring.engine import DEFAULT_WEIGHTS, calculate_score

app = typer.Typer(
    name="repo-health",
    help="Scan a Git repository and produce a health score (0-100).",
    no_args_is_help=False,
)

console = Console()


class OutputFormat(str, Enum):
    terminal = "terminal"
    json = "json"
    markdown = "markdown"


SCANNER_CLASSES = [
    CIScanner,
    TestScanner,
    DocsScanner,
    SecurityScanner,
    DepsScanner,
    CommunityScanner,
    ReleaseScanner,
    GitScanner,
]


def _run_scanners(
    repo_path: Path, ignore_scanners: list[str] | None = None
) -> list[ScanResult]:
    ignore = {s.lower() for s in (ignore_scanners or [])}
    results: list[ScanResult] = []
    for cls in SCANNER_CLASSES:
        scanner = cls(repo_path)
        if scanner.category.lower() in ignore:
            continue
        results.append(scanner.scan())
    return results


def version_callback(value: bool) -> None:
    if value:
        console.print(f"repo-health {__version__}")
        raise typer.Exit()


@app.command()
def scan(
    path: Path = typer.Argument(Path("."), help="Path to the repository to scan."),
    format: OutputFormat = typer.Option(
        OutputFormat.terminal, "--format", "-f", help="Output format."
    ),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Output file path."
    ),
    min_score: float = typer.Option(
        0, "--min-score", help="Minimum passing score (exit 1 if below)."
    ),
    config: str | None = typer.Option(None, "--config", "-c", help="Config file path."),
    ci: bool = typer.Option(
        False, "--ci", help="CI mode (implies --format json if not set)."
    ),
) -> None:
    """Scan a repository and produce a health report."""
    repo_path = path.resolve()
    if not repo_path.is_dir():
        console.print(f"[red]Error: {repo_path} is not a directory[/red]")
        raise typer.Exit(code=1)

    cfg = load_config(repo_path, config)

    effective_min = min_score or cfg.min_score
    weights = {**DEFAULT_WEIGHTS, **cfg.weights}

    if ci and format == OutputFormat.terminal:
        format = OutputFormat.json

    results = _run_scanners(repo_path, cfg.ignore_scanners)
    report = calculate_score(results, weights=weights, repo_name=repo_path.name)

    if format == OutputFormat.terminal:
        render_terminal(report, console)
    elif format == OutputFormat.json:
        json_str = render_json(report, output)
        if not output:
            console.print(json_str)
    elif format == OutputFormat.markdown:
        md_str = render_markdown(report, output)
        if not output:
            console.print(md_str)

    if effective_min > 0 and report.total_score < effective_min:
        score_val = f"{report.total_score:.0f}"
        min_val = f"{effective_min:.0f}"
        console.print(f"[red]Health score {score_val} is below minimum {min_val}[/red]")
        raise typer.Exit(code=1)


@app.command()
def badge(
    path: Path = typer.Argument(Path("."), help="Path to the repository to scan."),
    output: Path = typer.Option(
        Path("health-badge.svg"), "--output", "-o", help="Badge SVG output path."
    ),
    config: str | None = typer.Option(None, "--config", "-c", help="Config file path."),
) -> None:
    """Generate an SVG health badge."""
    repo_path = path.resolve()
    if not repo_path.is_dir():
        console.print(f"[red]Error: {repo_path} is not a directory[/red]")
        raise typer.Exit(code=1)

    cfg = load_config(repo_path, config)
    weights = {**DEFAULT_WEIGHTS, **cfg.weights}

    results = _run_scanners(repo_path, cfg.ignore_scanners)
    report = calculate_score(results, weights=weights, repo_name=repo_path.name)

    render_badge(report.total_score, report.grade, output)
    console.print(f"Badge saved to {output}")


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-v", callback=version_callback, is_eager=True
    ),
) -> None:
    """repo-health: Repository Health Score CLI."""
    if ctx.invoked_subcommand is None:
        scan(
            path=Path("."),
            format=OutputFormat.terminal,
            output=None,
            min_score=0,
            config=None,
            ci=False,
        )
