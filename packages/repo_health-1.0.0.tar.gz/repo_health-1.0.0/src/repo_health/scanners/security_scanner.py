"""Security scanner — checks .gitignore, secrets exposure, SECURITY.md."""

from __future__ import annotations

import re

from repo_health.scanners.base import BaseScanner, CheckResult, ScanResult

GITIGNORE_EXPECTED = [
    "__pycache__",
    "node_modules",
    ".env",
    "*.pyc",
    ".DS_Store",
    "venv",
    ".venv",
    "dist",
    "build",
]

SECRET_PATTERNS = [
    re.compile(
        r"(?:api[_-]?key|apikey)\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{16,}", re.IGNORECASE
    ),
    re.compile(
        r"(?:secret|password|passwd|token)\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{8,}",
        re.IGNORECASE,
    ),
    re.compile(r"-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----"),
    re.compile(r"AKIA[0-9A-Z]{16}"),  # AWS access key
]

SCAN_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".rb",
    ".go",
    ".java",
    ".yaml",
    ".yml",
    ".json",
    ".toml",
    ".cfg",
    ".ini",
    ".env",
    ".sh",
}


class SecurityScanner(BaseScanner):
    @property
    def category(self) -> str:
        return "Security"

    def scan(self) -> ScanResult:
        checks: list[CheckResult] = []

        gitignore = self.repo_path / ".gitignore"
        if gitignore.is_file():
            content = self._read_file(gitignore).lower()
            matched = sum(1 for e in GITIGNORE_EXPECTED if e.lower() in content)
            good = matched >= 3
            checks.append(
                CheckResult(
                    name="gitignore_quality",
                    passed=good,
                    message=f".gitignore covers {matched} common pattern(s)"
                    if good
                    else f".gitignore only covers {matched} common pattern(s)",
                    weight=1.5,
                )
            )
        else:
            checks.append(
                CheckResult(
                    name="gitignore_quality",
                    passed=False,
                    message="No .gitignore found",
                    weight=1.5,
                )
            )

        secrets_found = self._scan_for_secrets()
        checks.append(
            CheckResult(
                name="no_secrets",
                passed=not secrets_found,
                message="No secrets detected"
                if not secrets_found
                else f"Potential secrets in {len(secrets_found)} file(s)",
                weight=2.0,
            )
        )

        security_md = self._file_exists("SECURITY.md", "SECURITY.rst", "SECURITY")
        checks.append(
            CheckResult(
                name="security_md",
                passed=security_md is not None,
                message="SECURITY.md present"
                if security_md
                else "No SECURITY.md found",
            )
        )

        dep_audit = self._check_dep_audit_in_ci()
        checks.append(
            CheckResult(
                name="dependency_audit",
                passed=dep_audit,
                message="Dependency audit in CI"
                if dep_audit
                else "No dependency audit in CI",
            )
        )

        return ScanResult(category=self.category, checks=checks)

    def _scan_for_secrets(self) -> list[str]:
        flagged: list[str] = []
        for p in self.repo_path.rglob("*"):
            if not p.is_file():
                continue
            if p.suffix not in SCAN_EXTENSIONS:
                continue
            rel = str(p.relative_to(self.repo_path))
            if any(
                skip in rel
                for skip in [
                    ".git/",
                    "node_modules/",
                    "venv/",
                    ".venv/",
                    "__pycache__/",
                ]
            ):
                continue
            try:
                content = p.read_text(encoding="utf-8", errors="replace")[:32768]
            except OSError:
                continue
            for pattern in SECRET_PATTERNS:
                if pattern.search(content):
                    flagged.append(rel)
                    break
        return flagged

    def _check_dep_audit_in_ci(self) -> bool:
        audit_keywords = [
            "pip-audit",
            "npm audit",
            "safety check",
            "snyk",
            "trivy",
            "grype",
            "dependabot",
        ]
        for pattern in [".github/workflows/*.yml", ".github/workflows/*.yaml"]:
            for p in self.repo_path.glob(pattern):
                if p.is_file():
                    content = self._read_file(p).lower()
                    if any(kw in content for kw in audit_keywords):
                        return True
        return False
