"""Git hygiene scanner — checks commit message quality and branch conventions."""

from __future__ import annotations

import subprocess

from repo_health.scanners.base import BaseScanner, CheckResult, ScanResult

CONVENTIONAL_PREFIXES = [
    "feat",
    "fix",
    "docs",
    "style",
    "refactor",
    "perf",
    "test",
    "build",
    "ci",
    "chore",
    "revert",
]


class GitScanner(BaseScanner):
    @property
    def category(self) -> str:
        return "Git Hygiene"

    def scan(self) -> ScanResult:
        checks: list[CheckResult] = []

        is_git = (self.repo_path / ".git").exists()
        checks.append(
            CheckResult(
                name="is_git_repo",
                passed=is_git,
                message="Git repository" if is_git else "Not a git repository",
                weight=2.0,
            )
        )

        if not is_git:
            return ScanResult(category=self.category, checks=checks)

        messages = self._get_recent_commits(50)
        if messages:
            good = sum(1 for m in messages if self._is_good_message(m))
            ratio = good / len(messages)
            ok = ratio >= 0.5
            checks.append(
                CheckResult(
                    name="commit_quality",
                    passed=ok,
                    message=f"{good}/{len(messages)} commits have good messages"
                    if ok
                    else f"Only {good}/{len(messages)} commits have good messages",
                )
            )
        else:
            checks.append(
                CheckResult(
                    name="commit_quality",
                    passed=False,
                    message="No commits found",
                )
            )

        has_main = self._branch_exists("main") or self._branch_exists("master")
        checks.append(
            CheckResult(
                name="default_branch",
                passed=has_main,
                message="Default branch (main/master) exists"
                if has_main
                else "No main/master branch found",
            )
        )

        return ScanResult(category=self.category, checks=checks)

    def _get_recent_commits(self, count: int) -> list[str]:
        try:
            result = subprocess.run(
                ["git", "log", f"-{count}", "--format=%s"],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                return [
                    line.strip() for line in result.stdout.splitlines() if line.strip()
                ]
        except (subprocess.SubprocessError, FileNotFoundError):
            pass
        return []

    def _is_good_message(self, message: str) -> bool:
        if len(message) < 5 or len(message) > 200:
            return False
        lower = message.lower()
        if lower in ("wip", "fix", "update", "changes", "stuff", "asdf", "temp"):
            return False
        for prefix in CONVENTIONAL_PREFIXES:
            if lower.startswith(f"{prefix}:") or lower.startswith(f"{prefix}("):
                return True
        if message[0].isupper() and len(message) >= 10:
            return True
        return len(message) >= 15

    def _branch_exists(self, name: str) -> bool:
        try:
            result = subprocess.run(
                ["git", "branch", "--list", name],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=10,
            )
            return bool(result.stdout.strip())
        except (subprocess.SubprocessError, FileNotFoundError):
            return False
