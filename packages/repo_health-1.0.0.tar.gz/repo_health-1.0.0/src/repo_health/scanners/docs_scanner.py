"""Documentation scanner — checks README, LICENSE, CONTRIBUTING, CHANGELOG quality."""

from __future__ import annotations

import re

from repo_health.scanners.base import BaseScanner, CheckResult, ScanResult

README_SECTIONS = [
    "install",
    "usage",
    "getting started",
    "contributing",
    "license",
    "api",
    "configuration",
    "features",
]

BADGE_PATTERN = re.compile(
    r"\[!\[.*?\]\(.*?\)\]|!\[.*?\]\(https?://.*?badge.*?\)", re.IGNORECASE
)


class DocsScanner(BaseScanner):
    @property
    def category(self) -> str:
        return "Documentation"

    def scan(self) -> ScanResult:
        checks: list[CheckResult] = []

        readme = self._file_exists("README.md", "README.rst", "README.txt", "README")
        checks.append(
            CheckResult(
                name="readme_exists",
                passed=readme is not None,
                message="README present" if readme else "No README found",
                weight=2.0,
            )
        )

        if readme:
            content = self._read_file(readme).lower()
            found_sections = [s for s in README_SECTIONS if s in content]
            good = len(found_sections) >= 3
            checks.append(
                CheckResult(
                    name="readme_quality",
                    passed=good,
                    message=f"README has {len(found_sections)} key section(s)"
                    if good
                    else f"README lacks detail ({len(found_sections)} section(s))",
                )
            )

            raw_content = self._read_file(readme)
            badges = BADGE_PATTERN.findall(raw_content)
            checks.append(
                CheckResult(
                    name="readme_badges",
                    passed=len(badges) >= 1,
                    message=f"{len(badges)} badge(s) in README"
                    if badges
                    else "No badges in README",
                )
            )
        else:
            checks.append(
                CheckResult(
                    name="readme_quality", passed=False, message="No README to evaluate"
                )
            )
            checks.append(
                CheckResult(
                    name="readme_badges", passed=False, message="No README for badges"
                )
            )

        license_file = self._file_exists(
            "LICENSE", "LICENSE.md", "LICENSE.txt", "LICENCE", "LICENCE.md"
        )
        checks.append(
            CheckResult(
                name="license_exists",
                passed=license_file is not None,
                message="LICENSE present" if license_file else "No LICENSE found",
            )
        )

        contributing = self._file_exists(
            "CONTRIBUTING.md", "CONTRIBUTING.rst", "CONTRIBUTING"
        )
        checks.append(
            CheckResult(
                name="contributing_exists",
                passed=contributing is not None,
                message="CONTRIBUTING present"
                if contributing
                else "No CONTRIBUTING found",
            )
        )

        changelog = self._file_exists(
            "CHANGELOG.md", "CHANGELOG.rst", "CHANGELOG", "CHANGES.md", "HISTORY.md"
        )
        checks.append(
            CheckResult(
                name="changelog_exists",
                passed=changelog is not None,
                message="CHANGELOG present" if changelog else "No CHANGELOG found",
            )
        )

        return ScanResult(category=self.category, checks=checks)
