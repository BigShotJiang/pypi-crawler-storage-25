"""CI/CD scanner — checks for continuous integration configuration."""

from __future__ import annotations

from repo_health.scanners.base import BaseScanner, CheckResult, ScanResult

CI_CONFIG_PATTERNS = [
    ".github/workflows/*.yml",
    ".github/workflows/*.yaml",
    ".gitlab-ci.yml",
    ".circleci/config.yml",
    "Jenkinsfile",
    ".travis.yml",
    "azure-pipelines.yml",
    "bitbucket-pipelines.yml",
]

TEST_KEYWORDS = [
    "test",
    "pytest",
    "jest",
    "mocha",
    "rspec",
    "unittest",
    "cargo test",
    "go test",
]
BUILD_KEYWORDS = [
    "build",
    "compile",
    "make",
    "gradle",
    "maven",
    "npm run build",
    "cargo build",
]
DEPLOY_KEYWORDS = ["deploy", "publish", "release", "upload", "push"]


class CIScanner(BaseScanner):
    @property
    def category(self) -> str:
        return "CI/CD"

    def scan(self) -> ScanResult:
        checks: list[CheckResult] = []
        ci_files: list[str] = []
        ci_content = ""

        for pattern in CI_CONFIG_PATTERNS:
            for p in self.repo_path.glob(pattern):
                if p.is_file():
                    ci_files.append(str(p.relative_to(self.repo_path)))
                    ci_content += self._read_file(p).lower() + "\n"

        checks.append(
            CheckResult(
                name="ci_config_exists",
                passed=bool(ci_files),
                message="CI configuration" if ci_files else "No CI configuration found",
                weight=2.0,
            )
        )

        has_tests = any(kw in ci_content for kw in TEST_KEYWORDS)
        checks.append(
            CheckResult(
                name="tests_in_ci",
                passed=has_tests,
                message="Tests run in CI" if has_tests else "No test step in CI",
            )
        )

        has_build = any(kw in ci_content for kw in BUILD_KEYWORDS)
        checks.append(
            CheckResult(
                name="build_step",
                passed=has_build,
                message="Build step in CI" if has_build else "No build step in CI",
            )
        )

        has_deploy = any(kw in ci_content for kw in DEPLOY_KEYWORDS)
        checks.append(
            CheckResult(
                name="deploy_step",
                passed=has_deploy,
                message="Deploy/publish step" if has_deploy else "No deploy step in CI",
            )
        )

        return ScanResult(category=self.category, checks=checks)
