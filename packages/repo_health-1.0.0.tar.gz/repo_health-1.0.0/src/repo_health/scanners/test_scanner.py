"""Testing scanner — checks for test files and coverage configuration."""

from __future__ import annotations

from repo_health.scanners.base import BaseScanner, CheckResult, ScanResult

TEST_DIR_PATTERNS = [
    "tests/**/*.py",
    "test/**/*.py",
    "**/*_test.py",
    "**/*_test.go",
    "**/*.test.js",
    "**/*.test.ts",
    "**/*.spec.js",
    "**/*.spec.ts",
    "spec/**/*.rb",
    "**/*_test.rs",
]

COVERAGE_CONFIG_PATTERNS = [
    ".coveragerc",
    "setup.cfg",
    "pytest.ini",
    "tox.ini",
    "jest.config.*",
    "karma.conf.*",
    ".nycrc",
    ".nycrc.json",
    "codecov.yml",
    ".codecov.yml",
]

COVERAGE_KEYWORDS = [
    "coverage",
    "cov",
    "codecov",
    "coveralls",
    "istanbul",
    "nyc",
    "lcov",
]


class TestScanner(BaseScanner):
    @property
    def category(self) -> str:
        return "Testing"

    def scan(self) -> ScanResult:
        checks: list[CheckResult] = []

        test_files: list[str] = []
        for pattern in TEST_DIR_PATTERNS:
            for p in self.repo_path.glob(pattern):
                if p.is_file():
                    test_files.append(str(p.relative_to(self.repo_path)))

        checks.append(
            CheckResult(
                name="test_files_exist",
                passed=bool(test_files),
                message=f"{len(test_files)} test file(s)"
                if test_files
                else "No test files found",
                weight=2.0,
            )
        )

        has_cov_config = False
        for pattern in COVERAGE_CONFIG_PATTERNS:
            if self._any_file_exists(pattern):
                has_cov_config = True
                break

        if not has_cov_config:
            pyproject = self.repo_path / "pyproject.toml"
            if pyproject.is_file():
                content = self._read_file(pyproject).lower()
                if "coverage" in content or "pytest-cov" in content:
                    has_cov_config = True

        checks.append(
            CheckResult(
                name="coverage_config",
                passed=has_cov_config,
                message="Coverage configured"
                if has_cov_config
                else "No coverage configuration",
            )
        )

        has_cov_threshold = False
        pyproject = self.repo_path / "pyproject.toml"
        if pyproject.is_file():
            content = self._read_file(pyproject).lower()
            if "fail_under" in content or "fail-under" in content:
                has_cov_threshold = True

        if not has_cov_threshold:
            coveragerc = self.repo_path / ".coveragerc"
            if coveragerc.is_file():
                content = self._read_file(coveragerc).lower()
                if "fail_under" in content:
                    has_cov_threshold = True

        checks.append(
            CheckResult(
                name="coverage_threshold",
                passed=has_cov_threshold,
                message="Coverage threshold set"
                if has_cov_threshold
                else "No coverage threshold",
            )
        )

        return ScanResult(category=self.category, checks=checks)
