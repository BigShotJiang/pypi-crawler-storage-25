"""Base scanner abstract class."""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class CheckResult:
    """Result of a single health check."""

    name: str
    passed: bool
    message: str
    weight: float = 1.0


@dataclass
class ScanResult:
    """Aggregated result from a scanner."""

    category: str
    checks: list[CheckResult] = field(default_factory=list)

    @property
    def score(self) -> float:
        if not self.checks:
            return 0.0
        total_weight = sum(c.weight for c in self.checks)
        if total_weight == 0:
            return 0.0
        earned = sum(c.weight for c in self.checks if c.passed)
        return (earned / total_weight) * 100

    @property
    def details(self) -> list[str]:
        parts: list[str] = []
        for c in self.checks:
            icon = "\u2705" if c.passed else "\u274c"
            parts.append(f"{icon} {c.message}")
        return parts


class BaseScanner(abc.ABC):
    """Abstract base class for repository scanners."""

    def __init__(self, repo_path: Path) -> None:
        self.repo_path = repo_path

    @property
    @abc.abstractmethod
    def category(self) -> str: ...

    @abc.abstractmethod
    def scan(self) -> ScanResult: ...

    def _file_exists(self, *patterns: str) -> Path | None:
        for pattern in patterns:
            for p in self.repo_path.glob(pattern):
                if p.is_file():
                    return p
        return None

    def _any_file_exists(self, *patterns: str) -> bool:
        return self._file_exists(*patterns) is not None

    def _read_file(self, path: Path, max_bytes: int = 65536) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="replace")[:max_bytes]
        except OSError:
            return ""
