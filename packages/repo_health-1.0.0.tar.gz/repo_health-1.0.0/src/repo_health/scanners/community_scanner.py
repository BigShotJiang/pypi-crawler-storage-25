"""Community scanner — checks for issue templates, PR templates, code of conduct."""

from __future__ import annotations

from repo_health.scanners.base import BaseScanner, CheckResult, ScanResult


class CommunityScanner(BaseScanner):
    @property
    def category(self) -> str:
        return "Community"

    def scan(self) -> ScanResult:
        checks: list[CheckResult] = []

        has_issue_template = self._any_file_exists(
            ".github/ISSUE_TEMPLATE/*.md",
            ".github/ISSUE_TEMPLATE/*.yml",
            ".github/ISSUE_TEMPLATE/*.yaml",
            ".github/ISSUE_TEMPLATE.md",
        )
        checks.append(
            CheckResult(
                name="issue_template",
                passed=has_issue_template,
                message="Issue template(s) present"
                if has_issue_template
                else "No issue templates",
            )
        )

        has_pr_template = self._any_file_exists(
            ".github/PULL_REQUEST_TEMPLATE.md",
            ".github/PULL_REQUEST_TEMPLATE/*.md",
            "PULL_REQUEST_TEMPLATE.md",
        )
        checks.append(
            CheckResult(
                name="pr_template",
                passed=has_pr_template,
                message="PR template present" if has_pr_template else "No PR template",
            )
        )

        has_coc = self._any_file_exists(
            "CODE_OF_CONDUCT.md",
            "CODE_OF_CONDUCT.rst",
            "CODE_OF_CONDUCT",
            ".github/CODE_OF_CONDUCT.md",
        )
        checks.append(
            CheckResult(
                name="code_of_conduct",
                passed=has_coc,
                message="Code of Conduct present" if has_coc else "No Code of Conduct",
            )
        )

        has_contributing = self._any_file_exists(
            "CONTRIBUTING.md",
            "CONTRIBUTING.rst",
            "CONTRIBUTING",
            ".github/CONTRIBUTING.md",
        )
        checks.append(
            CheckResult(
                name="contributing_guide",
                passed=has_contributing,
                message="Contributing guide present"
                if has_contributing
                else "No contributing guide",
            )
        )

        return ScanResult(category=self.category, checks=checks)
