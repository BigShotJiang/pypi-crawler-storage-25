"""Dependency scanner — checks lock files, outdated deps, known CVEs config."""

from __future__ import annotations

from repo_health.scanners.base import BaseScanner, CheckResult, ScanResult

LOCK_FILES = [
    "poetry.lock",
    "Pipfile.lock",
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "Gemfile.lock",
    "Cargo.lock",
    "go.sum",
    "composer.lock",
]

MANIFEST_FILES = [
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "requirements.txt",
    "package.json",
    "Gemfile",
    "Cargo.toml",
    "go.mod",
    "composer.json",
    "pom.xml",
    "build.gradle",
]

PIN_PATTERNS_STRICT = ["==", "locked", "exact"]


class DepsScanner(BaseScanner):
    @property
    def category(self) -> str:
        return "Dependencies"

    def scan(self) -> ScanResult:
        checks: list[CheckResult] = []

        has_manifest = False
        for m in MANIFEST_FILES:
            if (self.repo_path / m).is_file():
                has_manifest = True
                break

        checks.append(
            CheckResult(
                name="manifest_exists",
                passed=has_manifest,
                message="Dependency manifest found"
                if has_manifest
                else "No dependency manifest",
            )
        )

        has_lock = False
        for lf in LOCK_FILES:
            if (self.repo_path / lf).is_file():
                has_lock = True
                break

        checks.append(
            CheckResult(
                name="lock_file",
                passed=has_lock,
                message="Lock file present" if has_lock else "No lock file found",
                weight=1.5,
            )
        )

        has_pinning = self._check_version_pinning()
        checks.append(
            CheckResult(
                name="version_pinning",
                passed=has_pinning,
                message="Dependencies are version-constrained"
                if has_pinning
                else "Dependencies lack version constraints",
            )
        )

        has_audit = self._check_audit_tool()
        checks.append(
            CheckResult(
                name="audit_tool",
                passed=has_audit,
                message="Dependency audit tool configured"
                if has_audit
                else "No dependency audit tool",
            )
        )

        return ScanResult(category=self.category, checks=checks)

    def _check_version_pinning(self) -> bool:
        req = self.repo_path / "requirements.txt"
        if req.is_file():
            content = self._read_file(req)
            lines = [
                line.strip()
                for line in content.splitlines()
                if line.strip() and not line.startswith("#")
            ]
            if lines:
                pinned = sum(
                    1 for line in lines if "==" in line or ">=" in line or "~=" in line
                )
                return pinned / len(lines) > 0.5

        pyproject = self.repo_path / "pyproject.toml"
        if pyproject.is_file():
            content = self._read_file(pyproject)
            if ">=" in content or "==" in content or "~=" in content:
                return True

        pkg_json = self.repo_path / "package.json"
        if pkg_json.is_file():
            return True  # package.json always has version specs

        return False

    def _check_audit_tool(self) -> bool:
        audit_files = [
            ".github/dependabot.yml",
            ".github/dependabot.yaml",
            "renovate.json",
            ".renovaterc",
            ".renovaterc.json",
        ]
        for f in audit_files:
            if (self.repo_path / f).is_file():
                return True

        for pattern in [".github/workflows/*.yml", ".github/workflows/*.yaml"]:
            for p in self.repo_path.glob(pattern):
                if p.is_file():
                    content = self._read_file(p).lower()
                    if any(
                        kw in content
                        for kw in ["pip-audit", "npm audit", "safety", "snyk"]
                    ):
                        return True
        return False
