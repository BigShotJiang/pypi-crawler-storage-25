"""Release scanner — checks for tagged releases, semver, release notes."""

from __future__ import annotations

import re
import subprocess

from repo_health.scanners.base import BaseScanner, CheckResult, ScanResult

SEMVER_PATTERN = re.compile(r"^v?\d+\.\d+\.\d+")


class ReleaseScanner(BaseScanner):
    @property
    def category(self) -> str:
        return "Release"

    def scan(self) -> ScanResult:
        checks: list[CheckResult] = []
        tags = self._get_tags()

        checks.append(
            CheckResult(
                name="has_tags",
                passed=bool(tags),
                message=f"{len(tags)} release tag(s)" if tags else "No release tags",
                weight=1.5,
            )
        )

        semver_tags = [t for t in tags if SEMVER_PATTERN.match(t)]
        checks.append(
            CheckResult(
                name="semver",
                passed=bool(semver_tags),
                message="Semantic versioning used"
                if semver_tags
                else "No semantic version tags",
            )
        )

        has_release_notes = self._any_file_exists(
            "CHANGELOG.md",
            "CHANGELOG.rst",
            "CHANGES.md",
            "HISTORY.md",
            "RELEASES.md",
        )
        checks.append(
            CheckResult(
                name="release_notes",
                passed=has_release_notes,
                message="Release notes/changelog present"
                if has_release_notes
                else "No release notes",
            )
        )

        return ScanResult(category=self.category, checks=checks)

    def _get_tags(self) -> list[str]:
        try:
            result = subprocess.run(
                ["git", "tag", "--list"],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                return [t.strip() for t in result.stdout.splitlines() if t.strip()]
        except (subprocess.SubprocessError, FileNotFoundError):
            pass
        return []
