"""repo-health: Repository Health Score CLI."""

__version__ = "1.0.0"
