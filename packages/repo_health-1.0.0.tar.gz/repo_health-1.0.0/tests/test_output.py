"""Tests for output formatters."""

from __future__ import annotations

import json
from io import StringIO
from pathlib import Path

from rich.console import Console

from repo_health.output.badge import render_badge
from repo_health.output.json_output import render_json
from repo_health.output.markdown_output import render_markdown
from repo_health.output.terminal import render_terminal
from repo_health.scanners.base import CheckResult, ScanResult
from repo_health.scoring.engine import calculate_score


def _sample_report():
    results = [
        ScanResult(
            category="CI/CD",
            checks=[
                CheckResult(
                    name="ci_config_exists", passed=True, message="CI configuration"
                ),
                CheckResult(name="tests_in_ci", passed=True, message="Tests run in CI"),
                CheckResult(
                    name="build_step", passed=False, message="No build step in CI"
                ),
            ],
        ),
        ScanResult(
            category="Testing",
            checks=[
                CheckResult(
                    name="test_files_exist", passed=True, message="5 test file(s)"
                ),
                CheckResult(
                    name="coverage_config",
                    passed=False,
                    message="No coverage configuration",
                ),
            ],
        ),
    ]
    return calculate_score(results, repo_name="test-project")


# --- JSON Output ---


def test_json_output_structure() -> None:
    report = _sample_report()
    json_str = render_json(report)
    data = json.loads(json_str)

    assert data["repo"] == "test-project"
    assert isinstance(data["score"], float)
    assert isinstance(data["grade"], str)
    assert "CI/CD" in data["categories"]
    assert "Testing" in data["categories"]
    assert isinstance(data["recommendations"], list)


def test_json_output_to_file(tmp_path: Path) -> None:
    report = _sample_report()
    out = tmp_path / "report.json"
    render_json(report, out)

    assert out.exists()
    data = json.loads(out.read_text())
    assert data["repo"] == "test-project"


def test_json_output_checks() -> None:
    report = _sample_report()
    data = json.loads(render_json(report))

    ci_checks = data["categories"]["CI/CD"]["checks"]
    assert len(ci_checks) == 3
    assert ci_checks[0]["name"] == "ci_config_exists"
    assert ci_checks[0]["passed"] is True


# --- Markdown Output ---


def test_markdown_output_structure() -> None:
    report = _sample_report()
    md = render_markdown(report)

    assert "# Repository Health Report: test-project" in md
    assert "| CI/CD |" in md
    assert "| Testing |" in md
    assert "Score:" in md


def test_markdown_output_to_file(tmp_path: Path) -> None:
    report = _sample_report()
    out = tmp_path / "HEALTH.md"
    render_markdown(report, out)

    assert out.exists()
    content = out.read_text()
    assert "test-project" in content


def test_markdown_recommendations() -> None:
    results = [
        ScanResult(
            category="CI/CD",
            checks=[
                CheckResult(name="ci_config_exists", passed=False, message="No CI"),
            ],
        ),
    ]
    report = calculate_score(results, repo_name="test")
    md = render_markdown(report)
    assert "## Recommendations" in md


# --- Badge Output ---


def test_badge_output_svg() -> None:
    svg = render_badge(85.0, "A")
    assert "<svg" in svg
    assert "repo health" in svg
    assert "85" in svg
    assert "A" in svg


def test_badge_output_to_file(tmp_path: Path) -> None:
    out = tmp_path / "badge.svg"
    render_badge(72.0, "B", out)

    assert out.exists()
    content = out.read_text()
    assert "72" in content
    assert "B" in content


def test_badge_colors() -> None:
    svg_a = render_badge(95, "A+")
    assert "#4c1" in svg_a

    svg_f = render_badge(20, "F")
    assert "#e05d44" in svg_f


# --- Terminal Output ---


def test_terminal_output_renders() -> None:
    report = _sample_report()
    output = StringIO()
    console = Console(file=output, force_terminal=True, width=120)
    render_terminal(report, console)

    text = output.getvalue()
    assert "Repository Health Report" in text
    assert "test-project" in text
    assert "CI/CD" in text


def test_terminal_output_with_tips() -> None:
    results = [
        ScanResult(
            category="CI/CD",
            checks=[
                CheckResult(name="ci_config_exists", passed=False, message="No CI"),
            ],
        ),
    ]
    report = calculate_score(results, repo_name="test")
    output = StringIO()
    console = Console(file=output, force_terminal=True, width=120)
    render_terminal(report, console)

    text = output.getvalue()
    assert "Recommendations" in text


def test_terminal_output_high_score() -> None:
    results = [
        ScanResult(
            category="CI/CD",
            checks=[
                CheckResult(name="a", passed=True, message="ok"),
                CheckResult(name="b", passed=True, message="ok"),
            ],
        ),
    ]
    report = calculate_score(results, repo_name="great-repo")
    output = StringIO()
    console = Console(file=output, force_terminal=True, width=120)
    render_terminal(report, console)

    text = output.getvalue()
    assert "100" in text


def test_terminal_output_low_score() -> None:
    results = [
        ScanResult(
            category="Testing",
            checks=[
                CheckResult(name="a", passed=False, message="nope"),
                CheckResult(name="b", passed=True, message="ok"),
            ],
        ),
    ]
    report = calculate_score(results, repo_name="mid-repo")
    output = StringIO()
    console = Console(file=output, force_terminal=True, width=120)
    render_terminal(report, console)

    text = output.getvalue()
    assert "50" in text
