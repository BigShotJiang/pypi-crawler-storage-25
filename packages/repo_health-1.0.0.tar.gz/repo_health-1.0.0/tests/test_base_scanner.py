"""Tests for base scanner."""

from __future__ import annotations

from pathlib import Path

from repo_health.scanners.base import BaseScanner, CheckResult, ScanResult


class ConcreteScanner(BaseScanner):
    @property
    def category(self) -> str:
        return "Test"

    def scan(self) -> ScanResult:
        return ScanResult(category=self.category)


def test_file_exists(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text("hi\n")
    scanner = ConcreteScanner(tmp_path)
    assert scanner._file_exists("README.md") is not None
    assert scanner._file_exists("MISSING.md") is None


def test_any_file_exists(tmp_path: Path) -> None:
    (tmp_path / "a.txt").write_text("a\n")
    scanner = ConcreteScanner(tmp_path)
    assert scanner._any_file_exists("a.txt") is True
    assert scanner._any_file_exists("b.txt") is False


def test_read_file(tmp_path: Path) -> None:
    f = tmp_path / "data.txt"
    f.write_text("hello world\n")
    scanner = ConcreteScanner(tmp_path)
    assert scanner._read_file(f) == "hello world\n"


def test_read_file_missing(tmp_path: Path) -> None:
    scanner = ConcreteScanner(tmp_path)
    assert scanner._read_file(tmp_path / "nope.txt") == ""


def test_read_file_max_bytes(tmp_path: Path) -> None:
    f = tmp_path / "big.txt"
    f.write_text("x" * 1000)
    scanner = ConcreteScanner(tmp_path)
    result = scanner._read_file(f, max_bytes=10)
    assert len(result) == 10


def test_check_result_defaults() -> None:
    c = CheckResult(name="test", passed=True, message="ok")
    assert c.weight == 1.0


def test_scan_result_score_mixed() -> None:
    result = ScanResult(
        category="X",
        checks=[
            CheckResult(name="a", passed=True, message="ok", weight=2.0),
            CheckResult(name="b", passed=False, message="fail", weight=2.0),
        ],
    )
    assert result.score == 50.0
