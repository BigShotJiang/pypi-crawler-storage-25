"""Tests for scoring engine, grades, and tips."""

from __future__ import annotations

from repo_health.scanners.base import CheckResult, ScanResult
from repo_health.scoring.engine import DEFAULT_WEIGHTS, HealthReport, calculate_score
from repo_health.scoring.grades import grade_color, grade_color_hex, score_to_grade
from repo_health.scoring.tips import get_recommendations

# --- Grades ---


def test_score_to_grade_all_thresholds() -> None:
    assert score_to_grade(95) == "A+"
    assert score_to_grade(90) == "A+"
    assert score_to_grade(87) == "A"
    assert score_to_grade(85) == "A"
    assert score_to_grade(82) == "A-"
    assert score_to_grade(80) == "A-"
    assert score_to_grade(77) == "B+"
    assert score_to_grade(75) == "B+"
    assert score_to_grade(72) == "B"
    assert score_to_grade(70) == "B"
    assert score_to_grade(67) == "B-"
    assert score_to_grade(65) == "B-"
    assert score_to_grade(62) == "C+"
    assert score_to_grade(60) == "C+"
    assert score_to_grade(57) == "C"
    assert score_to_grade(55) == "C"
    assert score_to_grade(52) == "C-"
    assert score_to_grade(50) == "C-"
    assert score_to_grade(45) == "D"
    assert score_to_grade(40) == "D"
    assert score_to_grade(30) == "F"
    assert score_to_grade(0) == "F"


def test_grade_color() -> None:
    assert grade_color("A+") == "bright_green"
    assert grade_color("A") == "bright_green"
    assert grade_color("B+") == "green"
    assert grade_color("C") == "yellow"
    assert grade_color("D") == "orange1"
    assert grade_color("F") == "red"


def test_grade_color_hex() -> None:
    assert grade_color_hex("A+") == "#4c1"
    assert grade_color_hex("B") == "#97ca00"
    assert grade_color_hex("C-") == "#dfb317"
    assert grade_color_hex("D") == "#fe7d37"
    assert grade_color_hex("F") == "#e05d44"


# --- Scoring Engine ---


def _make_result(category: str, passed: int, failed: int) -> ScanResult:
    checks = []
    for i in range(passed):
        checks.append(CheckResult(name=f"pass_{i}", passed=True, message="ok"))
    for i in range(failed):
        checks.append(CheckResult(name=f"fail_{i}", passed=False, message="nope"))
    return ScanResult(category=category, checks=checks)


def test_calculate_score_perfect() -> None:
    results = [_make_result(cat, 4, 0) for cat in DEFAULT_WEIGHTS]
    report = calculate_score(results, repo_name="test")
    assert report.total_score == 100.0
    assert report.grade == "A+"


def test_calculate_score_zero() -> None:
    results = [_make_result(cat, 0, 4) for cat in DEFAULT_WEIGHTS]
    report = calculate_score(results, repo_name="test")
    assert report.total_score == 0.0
    assert report.grade == "F"


def test_calculate_score_partial() -> None:
    results = [_make_result(cat, 2, 2) for cat in DEFAULT_WEIGHTS]
    report = calculate_score(results, repo_name="test")
    assert 45 <= report.total_score <= 55


def test_calculate_score_custom_weights() -> None:
    weights = {"CI/CD": 100, "Testing": 0}
    results = [
        _make_result("CI/CD", 4, 0),
        _make_result("Testing", 0, 4),
    ]
    report = calculate_score(results, weights=weights, repo_name="test")
    assert report.total_score == 100.0


def test_health_report_category_scores() -> None:
    results = [_make_result("CI/CD", 3, 1), _make_result("Testing", 1, 3)]
    report = calculate_score(results, repo_name="test")
    scores = report.category_scores()
    assert scores["CI/CD"] == 75.0
    assert scores["Testing"] == 25.0


def test_empty_report() -> None:
    report = HealthReport(repo_name="empty")
    assert report.total_score == 0.0


def test_scan_result_no_checks() -> None:
    result = ScanResult(category="X")
    assert result.score == 0.0
    assert result.details == []


def test_scan_result_details() -> None:
    result = ScanResult(
        category="X",
        checks=[
            CheckResult(name="a", passed=True, message="Good"),
            CheckResult(name="b", passed=False, message="Bad"),
        ],
    )
    details = result.details
    assert "\u2705 Good" in details
    assert "\u274c Bad" in details


def test_scan_result_weighted_score() -> None:
    result = ScanResult(
        category="X",
        checks=[
            CheckResult(name="heavy", passed=True, message="ok", weight=3.0),
            CheckResult(name="light", passed=False, message="nope", weight=1.0),
        ],
    )
    assert result.score == 75.0


def test_scan_result_zero_weight() -> None:
    result = ScanResult(
        category="X",
        checks=[CheckResult(name="z", passed=True, message="ok", weight=0.0)],
    )
    assert result.score == 0.0


# --- Tips ---


def test_get_recommendations_returns_tips() -> None:
    results = [_make_result("CI/CD", 0, 4)]
    report = calculate_score(results, repo_name="test")
    # Rename check names to match tips
    for i, check in enumerate(report.results["CI/CD"].checks):
        tip_names = ["ci_config_exists", "tests_in_ci", "build_step", "deploy_step"]
        check.name = tip_names[i] if i < len(tip_names) else check.name
    tips = get_recommendations(report)
    assert len(tips) > 0
    assert "CI configuration" in tips[0]


def test_get_recommendations_max_tips() -> None:
    results = [_make_result(cat, 0, 4) for cat in DEFAULT_WEIGHTS]
    report = calculate_score(results, repo_name="test")
    tips = get_recommendations(report, max_tips=3)
    assert len(tips) <= 3


def test_get_recommendations_no_failures() -> None:
    results = [_make_result("CI/CD", 4, 0)]
    report = calculate_score(results, repo_name="test")
    tips = get_recommendations(report)
    assert len(tips) == 0
