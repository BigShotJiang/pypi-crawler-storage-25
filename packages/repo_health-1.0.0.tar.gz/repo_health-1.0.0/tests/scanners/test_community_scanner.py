"""Tests for community scanner."""

from __future__ import annotations

from pathlib import Path

from repo_health.scanners.community_scanner import CommunityScanner


def test_community_scanner_healthy(healthy_repo: Path) -> None:
    scanner = CommunityScanner(healthy_repo)
    result = scanner.scan()
    assert result.category == "Community"

    by_name = {c.name: c for c in result.checks}
    assert by_name["issue_template"].passed is True
    assert by_name["pr_template"].passed is True
    assert by_name["code_of_conduct"].passed is True
    assert by_name["contributing_guide"].passed is True
    assert result.score == 100.0


def test_community_scanner_unhealthy(unhealthy_repo: Path) -> None:
    scanner = CommunityScanner(unhealthy_repo)
    result = scanner.scan()
    assert result.score == 0.0


def test_community_scanner_partial(tmp_path: Path) -> None:
    (tmp_path / "CODE_OF_CONDUCT.md").write_text("# CoC\n")
    (tmp_path / "CONTRIBUTING.md").write_text("# Contributing\n")
    scanner = CommunityScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["code_of_conduct"].passed is True
    assert by_name["contributing_guide"].passed is True
    assert by_name["issue_template"].passed is False
    assert by_name["pr_template"].passed is False


def test_community_scanner_pr_template_root(tmp_path: Path) -> None:
    (tmp_path / "PULL_REQUEST_TEMPLATE.md").write_text("## PR\n")
    scanner = CommunityScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["pr_template"].passed is True


def test_community_scanner_github_coc(tmp_path: Path) -> None:
    gh = tmp_path / ".github"
    gh.mkdir()
    (gh / "CODE_OF_CONDUCT.md").write_text("# CoC\n")
    scanner = CommunityScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["code_of_conduct"].passed is True


def test_community_scanner_yaml_issue_template(tmp_path: Path) -> None:
    it = tmp_path / ".github" / "ISSUE_TEMPLATE"
    it.mkdir(parents=True)
    (it / "bug.yaml").write_text("name: Bug\n")
    scanner = CommunityScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["issue_template"].passed is True
