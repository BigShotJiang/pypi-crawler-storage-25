"""Tests for release scanner."""

from __future__ import annotations

import subprocess
from pathlib import Path

from repo_health.scanners.release_scanner import ReleaseScanner


def test_release_scanner_healthy(healthy_repo: Path) -> None:
    scanner = ReleaseScanner(healthy_repo)
    result = scanner.scan()
    assert result.category == "Release"

    by_name = {c.name: c for c in result.checks}
    assert by_name["has_tags"].passed is True
    assert by_name["semver"].passed is True
    assert by_name["release_notes"].passed is True


def test_release_scanner_unhealthy(unhealthy_repo: Path) -> None:
    scanner = ReleaseScanner(unhealthy_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["has_tags"].passed is False
    assert by_name["semver"].passed is False
    assert by_name["release_notes"].passed is False


def test_release_scanner_non_semver_tags(tmp_repo: Path) -> None:
    subprocess.run(
        ["git", "-C", str(tmp_repo), "tag", "release-2024"],
        capture_output=True,
        check=True,
    )
    scanner = ReleaseScanner(tmp_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["has_tags"].passed is True
    assert by_name["semver"].passed is False


def test_release_scanner_multiple_semver(tmp_repo: Path) -> None:
    subprocess.run(
        ["git", "-C", str(tmp_repo), "tag", "v1.0.0"], capture_output=True, check=True
    )
    subprocess.run(
        ["git", "-C", str(tmp_repo), "tag", "v1.1.0"], capture_output=True, check=True
    )
    scanner = ReleaseScanner(tmp_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["has_tags"].passed is True
    assert "2 release tag" in by_name["has_tags"].message
    assert by_name["semver"].passed is True


def test_release_scanner_non_git(non_git_dir: Path) -> None:
    scanner = ReleaseScanner(non_git_dir)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["has_tags"].passed is False


def test_release_scanner_changes_md(tmp_path: Path) -> None:
    (tmp_path / "CHANGES.md").write_text("# Changes\n")
    scanner = ReleaseScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["release_notes"].passed is True
