"""Tests for CI scanner."""

from __future__ import annotations

from pathlib import Path

from repo_health.scanners.ci_scanner import CIScanner


def test_ci_scanner_healthy(healthy_repo: Path) -> None:
    scanner = CIScanner(healthy_repo)
    result = scanner.scan()
    assert result.category == "CI/CD"
    assert result.score > 0

    names = {c.name for c in result.checks}
    assert "ci_config_exists" in names
    assert "tests_in_ci" in names
    assert "build_step" in names
    assert "deploy_step" in names

    by_name = {c.name: c for c in result.checks}
    assert by_name["ci_config_exists"].passed is True
    assert by_name["tests_in_ci"].passed is True
    assert by_name["build_step"].passed is True
    assert by_name["deploy_step"].passed is True


def test_ci_scanner_unhealthy(unhealthy_repo: Path) -> None:
    scanner = CIScanner(unhealthy_repo)
    result = scanner.scan()
    assert result.score == 0.0

    by_name = {c.name: c for c in result.checks}
    assert by_name["ci_config_exists"].passed is False


def test_ci_scanner_gitlab(tmp_path: Path) -> None:
    (tmp_path / ".gitlab-ci.yml").write_text(
        "test:\n  script: pytest\n  artifacts:\n    paths: [build/]\n"
    )
    scanner = CIScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["ci_config_exists"].passed is True
    assert by_name["tests_in_ci"].passed is True


def test_ci_scanner_travis(tmp_path: Path) -> None:
    (tmp_path / ".travis.yml").write_text("script: go test ./...\n")
    scanner = CIScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["ci_config_exists"].passed is True
    assert by_name["tests_in_ci"].passed is True


def test_ci_scanner_jenkinsfile(tmp_path: Path) -> None:
    (tmp_path / "Jenkinsfile").write_text(
        "pipeline { stages { stage('Build') { steps { sh 'make build' } } } }\n"
    )
    scanner = CIScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["ci_config_exists"].passed is True
    assert by_name["build_step"].passed is True
