"""Tests for dependency scanner."""

from __future__ import annotations

from pathlib import Path

from repo_health.scanners.deps_scanner import DepsScanner


def test_deps_scanner_healthy(healthy_repo: Path) -> None:
    scanner = DepsScanner(healthy_repo)
    result = scanner.scan()
    assert result.category == "Dependencies"

    by_name = {c.name: c for c in result.checks}
    assert by_name["manifest_exists"].passed is True
    assert by_name["version_pinning"].passed is True
    assert by_name["audit_tool"].passed is True


def test_deps_scanner_unhealthy(unhealthy_repo: Path) -> None:
    scanner = DepsScanner(unhealthy_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["manifest_exists"].passed is False
    assert by_name["lock_file"].passed is False


def test_deps_scanner_lock_file(tmp_path: Path) -> None:
    (tmp_path / "package.json").write_text('{"name": "test"}\n')
    (tmp_path / "package-lock.json").write_text("{}\n")
    scanner = DepsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["manifest_exists"].passed is True
    assert by_name["lock_file"].passed is True
    assert by_name["version_pinning"].passed is True


def test_deps_scanner_poetry_lock(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "test"\ndependencies = ["requests>=2.0"]\n'
    )
    (tmp_path / "poetry.lock").write_text("[[package]]\n")
    scanner = DepsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["lock_file"].passed is True
    assert by_name["version_pinning"].passed is True


def test_deps_scanner_renovate(tmp_path: Path) -> None:
    (tmp_path / "renovate.json").write_text('{"extends": ["config:base"]}\n')
    scanner = DepsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["audit_tool"].passed is True


def test_deps_scanner_no_pinning(tmp_path: Path) -> None:
    (tmp_path / "requirements.txt").write_text("requests\nflask\nnumpy\n")
    scanner = DepsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["version_pinning"].passed is False


def test_deps_scanner_partial_pinning(tmp_path: Path) -> None:
    (tmp_path / "requirements.txt").write_text("requests==2.31.0\nflask>=3.0\nnumpy\n")
    scanner = DepsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["version_pinning"].passed is True  # 2/3 > 0.5


def test_deps_scanner_pip_audit_in_ci(tmp_path: Path) -> None:
    wf = tmp_path / ".github" / "workflows"
    wf.mkdir(parents=True)
    (wf / "ci.yml").write_text("steps:\n  - run: pip-audit\n")
    scanner = DepsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["audit_tool"].passed is True


def test_deps_scanner_empty_requirements(tmp_path: Path) -> None:
    (tmp_path / "requirements.txt").write_text("# no deps\n")
    scanner = DepsScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["version_pinning"].passed is False


def test_deps_scanner_no_manifest_no_pinning(tmp_path: Path) -> None:
    scanner = DepsScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["version_pinning"].passed is False
