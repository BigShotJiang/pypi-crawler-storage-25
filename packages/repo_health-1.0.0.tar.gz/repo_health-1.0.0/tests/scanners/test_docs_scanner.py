"""Tests for docs scanner."""

from __future__ import annotations

from pathlib import Path

from repo_health.scanners.docs_scanner import DocsScanner


def test_docs_scanner_healthy(healthy_repo: Path) -> None:
    scanner = DocsScanner(healthy_repo)
    result = scanner.scan()
    assert result.category == "Documentation"

    by_name = {c.name: c for c in result.checks}
    assert by_name["readme_exists"].passed is True
    assert by_name["readme_quality"].passed is True
    assert by_name["readme_badges"].passed is True
    assert by_name["license_exists"].passed is True
    assert by_name["contributing_exists"].passed is True
    assert by_name["changelog_exists"].passed is True


def test_docs_scanner_unhealthy(unhealthy_repo: Path) -> None:
    scanner = DocsScanner(unhealthy_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["readme_exists"].passed is False
    assert by_name["readme_quality"].passed is False
    assert by_name["readme_badges"].passed is False
    assert by_name["license_exists"].passed is False


def test_docs_scanner_minimal_readme(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text("# My Project\nHello world\n")
    scanner = DocsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["readme_exists"].passed is True
    assert by_name["readme_quality"].passed is False  # < 3 sections
    assert by_name["readme_badges"].passed is False


def test_docs_scanner_rst_readme(tmp_path: Path) -> None:
    (tmp_path / "README.rst").write_text(
        "My Project\n==========\n\nInstall\n-------\npip install\n\n"
        "Usage\n-----\nuse it\n\nLicense\n-------\nMIT\n"
    )
    scanner = DocsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["readme_exists"].passed is True
    assert by_name["readme_quality"].passed is True


def test_docs_scanner_licence_variant(tmp_path: Path) -> None:
    (tmp_path / "LICENCE.md").write_text("MIT\n")
    scanner = DocsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["license_exists"].passed is True


def test_docs_scanner_changes_variant(tmp_path: Path) -> None:
    (tmp_path / "CHANGES.md").write_text("# Changes\n")
    scanner = DocsScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["changelog_exists"].passed is True
