"""Tests for test scanner."""

from __future__ import annotations

from pathlib import Path

from repo_health.scanners.test_scanner import TestScanner


def test_test_scanner_healthy(healthy_repo: Path) -> None:
    scanner = TestScanner(healthy_repo)
    result = scanner.scan()
    assert result.category == "Testing"

    by_name = {c.name: c for c in result.checks}
    assert by_name["test_files_exist"].passed is True
    assert by_name["coverage_threshold"].passed is True


def test_test_scanner_unhealthy(unhealthy_repo: Path) -> None:
    scanner = TestScanner(unhealthy_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["test_files_exist"].passed is False
    assert by_name["coverage_config"].passed is False
    assert by_name["coverage_threshold"].passed is False


def test_test_scanner_js_tests(tmp_path: Path) -> None:
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "app.test.js").write_text("test('works', () => {})\n")
    scanner = TestScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["test_files_exist"].passed is True


def test_test_scanner_coverage_via_coveragerc(tmp_path: Path) -> None:
    (tmp_path / ".coveragerc").write_text("[report]\nfail_under = 80\n")
    scanner = TestScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["coverage_config"].passed is True
    assert by_name["coverage_threshold"].passed is True


def test_test_scanner_coverage_via_pyproject(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        '[tool.pytest.ini_options]\naddopts = "--cov"\n\n'
        "[tool.coverage.report]\nfail_under = 90\n"
    )
    scanner = TestScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["coverage_config"].passed is True
    assert by_name["coverage_threshold"].passed is True


def test_test_scanner_jest_config(tmp_path: Path) -> None:
    (tmp_path / "jest.config.js").write_text(
        "module.exports = { coverageThreshold: {} }\n"
    )
    scanner = TestScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["coverage_config"].passed is True


def test_test_scanner_codecov_yml(tmp_path: Path) -> None:
    (tmp_path / "codecov.yml").write_text("coverage:\n  status:\n    project: yes\n")
    scanner = TestScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["coverage_config"].passed is True


def test_test_scanner_spec_files(tmp_path: Path) -> None:
    spec = tmp_path / "spec"
    spec.mkdir()
    (spec / "model_spec.rb").write_text("describe Model do; end\n")
    # .rb doesn't match our patterns but spec/**/*.rb does
    # Actually our pattern is spec/**/*.rb - let me check
    scanner = TestScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["test_files_exist"].passed is True


def test_test_scanner_go_test(tmp_path: Path) -> None:
    (tmp_path / "main_test.go").write_text("package main\n")
    scanner = TestScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["test_files_exist"].passed is True


def test_test_scanner_ts_spec(tmp_path: Path) -> None:
    (tmp_path / "app.spec.ts").write_text("describe('app', () => {})\n")
    scanner = TestScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["test_files_exist"].passed is True
