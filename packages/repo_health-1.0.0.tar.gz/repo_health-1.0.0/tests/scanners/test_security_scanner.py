"""Tests for security scanner."""

from __future__ import annotations

from pathlib import Path

from repo_health.scanners.security_scanner import SecurityScanner


def test_security_scanner_healthy(healthy_repo: Path) -> None:
    scanner = SecurityScanner(healthy_repo)
    result = scanner.scan()
    assert result.category == "Security"

    by_name = {c.name: c for c in result.checks}
    assert by_name["gitignore_quality"].passed is True
    assert by_name["no_secrets"].passed is True
    assert by_name["security_md"].passed is True


def test_security_scanner_unhealthy(unhealthy_repo: Path) -> None:
    scanner = SecurityScanner(unhealthy_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["gitignore_quality"].passed is False
    assert by_name["security_md"].passed is False


def test_security_scanner_detects_secrets(tmp_path: Path) -> None:
    (tmp_path / "config.py").write_text('API_KEY = "sk_live_ABCDEFGHIJKLMNOP1234"\n')
    scanner = SecurityScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["no_secrets"].passed is False


def test_security_scanner_detects_aws_key(tmp_path: Path) -> None:
    (tmp_path / "settings.yaml").write_text("aws_access_key: AKIAIOSFODNN7EXAMPLE\n")
    scanner = SecurityScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["no_secrets"].passed is False


def test_security_scanner_detects_private_key(tmp_path: Path) -> None:
    (tmp_path / "key.py").write_text(
        'key = """-----BEGIN RSA PRIVATE KEY-----\nblah\n"""\n'
    )
    scanner = SecurityScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["no_secrets"].passed is False


def test_security_scanner_weak_gitignore(tmp_path: Path) -> None:
    (tmp_path / ".gitignore").write_text("*.log\n")
    scanner = SecurityScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["gitignore_quality"].passed is False


def test_security_scanner_dep_audit_in_ci(tmp_path: Path) -> None:
    wf = tmp_path / ".github" / "workflows"
    wf.mkdir(parents=True)
    (wf / "ci.yml").write_text("steps:\n  - run: pip-audit\n")
    scanner = SecurityScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["dependency_audit"].passed is True


def test_security_scanner_no_dep_audit(tmp_path: Path) -> None:
    scanner = SecurityScanner(tmp_path)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["dependency_audit"].passed is False


def test_security_scanner_ignores_binary_extensions(tmp_path: Path) -> None:
    # .png should be skipped (not in SCAN_EXTENSIONS)
    (tmp_path / "image.png").write_bytes(b"api_key = secret_1234567890abcdef")
    scanner = SecurityScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["no_secrets"].passed is True


def test_security_scanner_skips_venv(tmp_path: Path) -> None:
    venv = tmp_path / "venv" / "lib"
    venv.mkdir(parents=True)
    (venv / "config.py").write_text('SECRET = "supersecretpassword123"\n')
    scanner = SecurityScanner(tmp_path)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["no_secrets"].passed is True
