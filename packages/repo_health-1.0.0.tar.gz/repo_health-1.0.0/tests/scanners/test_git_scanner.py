"""Tests for git hygiene scanner."""

from __future__ import annotations

import subprocess
from pathlib import Path

from repo_health.scanners.git_scanner import GitScanner


def test_git_scanner_healthy(healthy_repo: Path) -> None:
    scanner = GitScanner(healthy_repo)
    result = scanner.scan()
    assert result.category == "Git Hygiene"

    by_name = {c.name: c for c in result.checks}
    assert by_name["is_git_repo"].passed is True
    assert by_name["commit_quality"].passed is True


def test_git_scanner_unhealthy(unhealthy_repo: Path) -> None:
    scanner = GitScanner(unhealthy_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["is_git_repo"].passed is True
    # Single "wip" commit should fail quality
    assert by_name["commit_quality"].passed is False


def test_git_scanner_non_git(non_git_dir: Path) -> None:
    scanner = GitScanner(non_git_dir)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["is_git_repo"].passed is False
    assert len(result.checks) == 1  # early return


def test_git_scanner_good_messages(tmp_repo: Path) -> None:
    for i in range(5):
        (tmp_repo / f"file{i}.txt").write_text(f"content {i}\n")
        subprocess.run(
            ["git", "-C", str(tmp_repo), "add", "."], capture_output=True, check=True
        )
        subprocess.run(
            [
                "git",
                "-C",
                str(tmp_repo),
                "commit",
                "-m",
                f"feat: Add feature number {i}",
            ],
            capture_output=True,
            check=True,
        )
    scanner = GitScanner(tmp_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["commit_quality"].passed is True


def test_git_scanner_bad_messages(tmp_repo: Path) -> None:
    for msg in ["wip", "fix", "asdf", "temp", "stuff"]:
        (tmp_repo / f"{msg}.txt").write_text("x\n")
        subprocess.run(
            ["git", "-C", str(tmp_repo), "add", "."], capture_output=True, check=True
        )
        subprocess.run(
            ["git", "-C", str(tmp_repo), "commit", "-m", msg],
            capture_output=True,
            check=True,
        )
    scanner = GitScanner(tmp_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    assert by_name["commit_quality"].passed is False


def test_git_scanner_branch_detection(tmp_repo: Path) -> None:
    scanner = GitScanner(tmp_repo)
    result = scanner.scan()

    by_name = {c.name: c for c in result.checks}
    # tmp_repo has master or main branch from git init
    assert by_name["default_branch"].passed is True


def test_git_scanner_conventional_prefixes(tmp_repo: Path) -> None:
    prefixes = ["feat:", "fix:", "docs:", "chore:", "refactor:"]
    for i, prefix in enumerate(prefixes):
        (tmp_repo / f"conv{i}.txt").write_text("x\n")
        subprocess.run(
            ["git", "-C", str(tmp_repo), "add", "."], capture_output=True, check=True
        )
        subprocess.run(
            ["git", "-C", str(tmp_repo), "commit", "-m", f"{prefix} something useful"],
            capture_output=True,
            check=True,
        )
    scanner = GitScanner(tmp_repo)
    result = scanner.scan()
    by_name = {c.name: c for c in result.checks}
    assert by_name["commit_quality"].passed is True
