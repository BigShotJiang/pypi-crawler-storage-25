"""Tests for CLI commands."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from repo_health.cli import app

runner = CliRunner()


def test_cli_scan_terminal(healthy_repo: Path) -> None:
    result = runner.invoke(app, ["scan", str(healthy_repo)])
    assert result.exit_code == 0
    assert "Repository Health Report" in result.output


def test_cli_scan_json(healthy_repo: Path) -> None:
    result = runner.invoke(app, ["scan", str(healthy_repo), "--format", "json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "score" in data
    assert "grade" in data
    assert "categories" in data


def test_cli_scan_markdown(healthy_repo: Path) -> None:
    result = runner.invoke(app, ["scan", str(healthy_repo), "--format", "markdown"])
    assert result.exit_code == 0
    assert "# Repository Health Report" in result.output


def test_cli_scan_json_to_file(healthy_repo: Path, tmp_path: Path) -> None:
    out = tmp_path / "report.json"
    result = runner.invoke(
        app, ["scan", str(healthy_repo), "--format", "json", "--output", str(out)]
    )
    assert result.exit_code == 0
    assert out.exists()
    data = json.loads(out.read_text())
    assert "score" in data


def test_cli_scan_markdown_to_file(healthy_repo: Path, tmp_path: Path) -> None:
    out = tmp_path / "HEALTH.md"
    result = runner.invoke(
        app, ["scan", str(healthy_repo), "--format", "markdown", "--output", str(out)]
    )
    assert result.exit_code == 0
    assert out.exists()


def test_cli_scan_min_score_pass(healthy_repo: Path) -> None:
    result = runner.invoke(
        app, ["scan", str(healthy_repo), "--format", "json", "--min-score", "10"]
    )
    assert result.exit_code == 0


def test_cli_scan_min_score_fail(unhealthy_repo: Path) -> None:
    result = runner.invoke(
        app, ["scan", str(unhealthy_repo), "--format", "json", "--min-score", "99"]
    )
    assert result.exit_code == 1
    assert "below minimum" in result.output


def test_cli_scan_ci_mode(healthy_repo: Path) -> None:
    result = runner.invoke(app, ["scan", str(healthy_repo), "--ci"])
    assert result.exit_code == 0
    # CI mode defaults to JSON
    data = json.loads(result.output)
    assert "score" in data


def test_cli_scan_invalid_path() -> None:
    result = runner.invoke(app, ["scan", "/nonexistent/path/abc123"])
    assert result.exit_code == 1
    assert "not a directory" in result.output


def test_cli_badge(healthy_repo: Path, tmp_path: Path) -> None:
    out = tmp_path / "badge.svg"
    result = runner.invoke(app, ["badge", str(healthy_repo), "--output", str(out)])
    assert result.exit_code == 0
    assert out.exists()
    assert "<svg" in out.read_text()


def test_cli_badge_invalid_path(tmp_path: Path) -> None:
    result = runner.invoke(app, ["badge", "/nonexistent/path/abc123"])
    assert result.exit_code == 1


def test_cli_version() -> None:
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "repo-health" in result.output


def test_cli_default_scan(healthy_repo: Path, monkeypatch) -> None:
    monkeypatch.chdir(healthy_repo)
    result = runner.invoke(app, [])
    assert result.exit_code == 0


def test_cli_scan_with_config(healthy_repo: Path) -> None:
    config_file = healthy_repo / ".repo-health.toml"
    config_file.write_text("[weights]\nci = 50\n\n[thresholds]\nmin_score = 10\n")
    result = runner.invoke(
        app,
        ["scan", str(healthy_repo), "--format", "json", "--config", str(config_file)],
    )
    assert result.exit_code == 0
