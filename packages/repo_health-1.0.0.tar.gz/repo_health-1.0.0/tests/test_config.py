"""Tests for config loading."""

from __future__ import annotations

from pathlib import Path

from repo_health.config import Config, load_config


def test_load_config_defaults(tmp_path: Path) -> None:
    config = load_config(tmp_path)
    assert isinstance(config, Config)
    assert config.weights == {}
    assert config.min_score == 0.0
    assert config.ignore_scanners == []
    assert config.ignore_paths == []


def test_load_config_from_repo_health_toml(tmp_path: Path) -> None:
    (tmp_path / ".repo-health.toml").write_text(
        "[weights]\nci = 20\ntesting = 25\n\n"
        "[thresholds]\nmin_score = 70\n\n"
        "[ignore]\nscanners = ['community']\nfiles = ['vendor/']\n"
    )
    config = load_config(tmp_path)
    assert config.weights == {"ci": 20, "testing": 25}
    assert config.min_score == 70.0
    assert config.ignore_scanners == ["community"]
    assert config.ignore_paths == ["vendor/"]


def test_load_config_from_pyproject(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "[tool.repo-health.weights]\nci = 10\n\n"
        "[tool.repo-health.thresholds]\nmin_score = 50\n"
    )
    config = load_config(tmp_path)
    assert config.weights == {"ci": 10}
    assert config.min_score == 50.0


def test_load_config_explicit_path(tmp_path: Path) -> None:
    custom = tmp_path / "custom.toml"
    custom.write_text("[weights]\nsecurity = 30\n")
    config = load_config(tmp_path, str(custom))
    assert config.weights == {"security": 30}


def test_load_config_explicit_path_missing(tmp_path: Path) -> None:
    config = load_config(tmp_path, str(tmp_path / "nonexistent.toml"))
    assert config.weights == {}


def test_load_config_priority_repo_health_over_pyproject(tmp_path: Path) -> None:
    (tmp_path / ".repo-health.toml").write_text("[weights]\nci = 99\n")
    (tmp_path / "pyproject.toml").write_text("[tool.repo-health.weights]\nci = 1\n")
    config = load_config(tmp_path)
    assert config.weights == {"ci": 99}


def test_load_config_pyproject_no_tool_section(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text('[project]\nname = "test"\n')
    config = load_config(tmp_path)
    assert config.weights == {}


def test_load_config_empty_ignore(tmp_path: Path) -> None:
    (tmp_path / ".repo-health.toml").write_text("[weights]\nci = 5\n")
    config = load_config(tmp_path)
    assert config.ignore_scanners == []
    assert config.ignore_paths == []
