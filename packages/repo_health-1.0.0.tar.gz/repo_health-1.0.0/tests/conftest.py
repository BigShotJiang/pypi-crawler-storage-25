"""Shared test fixtures for repo-health tests."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest


@pytest.fixture
def tmp_repo(tmp_path: Path) -> Path:
    """Create a minimal git repo in tmp_path."""
    subprocess.run(["git", "init", str(tmp_path)], capture_output=True, check=True)
    subprocess.run(
        ["git", "-C", str(tmp_path), "config", "user.email", "test@test.com"],
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "-C", str(tmp_path), "config", "user.name", "Test"],
        capture_output=True,
        check=True,
    )
    (tmp_path / "README.md").write_text("# Test Project\n")
    subprocess.run(
        ["git", "-C", str(tmp_path), "add", "."], capture_output=True, check=True
    )
    subprocess.run(
        ["git", "-C", str(tmp_path), "commit", "-m", "Initial commit"],
        capture_output=True,
        check=True,
    )
    return tmp_path


@pytest.fixture
def healthy_repo(tmp_path: Path) -> Path:
    """Create a repo with all health signals present."""
    repo = tmp_path / "healthy"
    repo.mkdir()

    subprocess.run(["git", "init", str(repo)], capture_output=True, check=True)
    subprocess.run(
        ["git", "-C", str(repo), "config", "user.email", "test@test.com"],
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "-C", str(repo), "config", "user.name", "Test"],
        capture_output=True,
        check=True,
    )

    # CI
    wf = repo / ".github" / "workflows"
    wf.mkdir(parents=True)
    ci_content = (
        "name: CI\non: push\njobs:\n  test:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n      - run: pytest\n"
        "      - run: npm run build\n"
        "      - run: deploy to prod\n"
    )
    (wf / "ci.yml").write_text(ci_content)

    # Tests
    tests_dir = repo / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_example.py").write_text("def test_one(): assert True\n")

    # Docs
    (repo / "README.md").write_text(
        "# Healthy Project\n\n[![CI](https://badge.svg)](url)\n\n"
        "## Install\npip install it\n\n## Usage\nuse it\n\n"
        "## Contributing\nsee CONTRIBUTING.md\n\n## License\nMIT\n"
    )
    (repo / "LICENSE").write_text("MIT License\n")
    (repo / "CONTRIBUTING.md").write_text("# Contributing\n")
    (repo / "CHANGELOG.md").write_text("# Changelog\n## 1.0.0\n- Initial\n")

    # Security
    (repo / ".gitignore").write_text(
        "__pycache__/\n*.pyc\nnode_modules/\n.env\n.DS_Store\nvenv/\ndist/\nbuild/\n"
    )
    (repo / "SECURITY.md").write_text("# Security Policy\n")

    # Dependencies
    (repo / "pyproject.toml").write_text(
        '[project]\nname = "test"\nversion = "1.0.0"\n'
        'dependencies = ["requests>=2.0"]\n\n'
        "[tool.coverage.report]\nfail_under = 90\n"
    )
    (repo / "requirements.txt").write_text("requests==2.31.0\nflask>=3.0\n")

    # Dependabot
    gh = repo / ".github"
    (gh / "dependabot.yml").write_text(
        "version: 2\nupdates:\n  - package-ecosystem: pip\n"
    )

    # Community
    it = gh / "ISSUE_TEMPLATE"
    it.mkdir(parents=True)
    (it / "bug.md").write_text("---\nname: Bug\n---\n")
    (gh / "PULL_REQUEST_TEMPLATE.md").write_text("## Description\n")
    (repo / "CODE_OF_CONDUCT.md").write_text("# Code of Conduct\n")

    # Release notes (CHANGELOG already created)
    # Git commit
    subprocess.run(
        ["git", "-C", str(repo), "add", "."], capture_output=True, check=True
    )
    subprocess.run(
        ["git", "-C", str(repo), "commit", "-m", "feat: Initial healthy project setup"],
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "-C", str(repo), "tag", "v1.0.0"], capture_output=True, check=True
    )

    return repo


@pytest.fixture
def unhealthy_repo(tmp_path: Path) -> Path:
    """Create a repo with minimal health signals."""
    repo = tmp_path / "unhealthy"
    repo.mkdir()

    subprocess.run(["git", "init", str(repo)], capture_output=True, check=True)
    subprocess.run(
        ["git", "-C", str(repo), "config", "user.email", "test@test.com"],
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "-C", str(repo), "config", "user.name", "Test"],
        capture_output=True,
        check=True,
    )

    (repo / "main.py").write_text("print('hello')\n")
    subprocess.run(
        ["git", "-C", str(repo), "add", "."], capture_output=True, check=True
    )
    subprocess.run(
        ["git", "-C", str(repo), "commit", "-m", "wip"], capture_output=True, check=True
    )

    return repo


@pytest.fixture
def non_git_dir(tmp_path: Path) -> Path:
    """A plain directory, not a git repo."""
    d = tmp_path / "nongit"
    d.mkdir()
    (d / "file.txt").write_text("hello\n")
    return d
