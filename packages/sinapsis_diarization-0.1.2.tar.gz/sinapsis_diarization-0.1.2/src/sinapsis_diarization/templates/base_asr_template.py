# -*- coding: utf-8 -*-
import os
from abc import abstractmethod
from typing import Literal, cast

from sinapsis_core.data_containers.annotations import AudioAnnotations
from sinapsis_core.data_containers.data_packet import DataContainer, TextPacket
from sinapsis_core.template_base import (
    Template,
    TemplateAttributes,
    TemplateAttributeType,
)
from sinapsis_core.utils.env_var_keys import SINAPSIS_CACHE_DIR

from sinapsis_diarization.base_models.diarization_output import AudioConfig
from sinapsis_diarization.pipelines.base_processors import ASREngine


class BaseASRAttributes(TemplateAttributes):
    """
    model_name (str): name of model to run
    device (str): device to run the model
    sample_rate (int): sample rate of the audio
    chunk_size_in_secs (int): Size of the chunks to divide the audio. -1 for full audio
    search_window (float): Size of the search window
    root_dir(str): Path to root directory. Optional
    audio_file_path (str): Path to audio file. Optional
    """

    model_name: str
    device: Literal["cpu", "cuda"] = "cuda"
    sample_rate: int = 16000
    chunk_size_in_secs: int = -1
    search_window: float = 5.0
    root_dir: str | None = None
    audio_file_path: str | None = None


class SinapsisBaseASR(Template):
    """Base template for ASR pipelines"""

    AttributesBaseModel = BaseASRAttributes

    def __init__(self, attributes: TemplateAttributeType):
        super().__init__(attributes)
        self.attributes.root_dir = self.attributes.root_dir or SINAPSIS_CACHE_DIR
        self.asr_pipeline: ASREngine = self.make_inference_engine()
        self.audio_config = AudioConfig(
            sample_rate=self.attributes.sample_rate,
            max_secs=self.attributes.chunk_size_in_secs,
            search_window=self.attributes.search_window,
        )

    @abstractmethod
    def make_inference_engine(self):
        pass

    def get_full_path(self):
        audio_file_path = cast(str, self.attributes.audio_file_path)
        full_path = os.path.join(self.attributes.root_dir, audio_file_path)
        return full_path

    def execute(self, container: DataContainer) -> DataContainer:
        """Call the ASR pipeline and add the information to container

        Args:
            container (DataContainer): data container

        Returns:
            DataContainer: data container with added information
        """
        if self.attributes.audio_file_path is not None:
            full_path = self.get_full_path()
            transcription_text: str = self.asr_pipeline.transcribe(
                audio_path_or_array=full_path,
                config=self.audio_config,
            )
            text_packet = TextPacket(
                content=transcription_text,
                source=full_path,
                generic_data={"produced_by_asr_model": self.attributes.model_name},
            )
            container.texts.append(text_packet)
        else:
            for audio_packet in container.audios:
                if audio_packet.sample_rate and audio_packet.sample_rate != self.attributes.sample_rate:
                    self.logger.warning("Sample rate in the incoming audio is not the same as used by the model")
                transcription_text = self.asr_pipeline.transcribe(
                    audio_path_or_array=audio_packet.content,
                    config=self.audio_config,
                )
                audio_packet.annotations.append(AudioAnnotations(raw_text=transcription_text))

        return container

    def reset_state(self, template_name: str | None = None) -> None:
        self.asr_pipeline.flush()
        super().reset_state(template_name)
