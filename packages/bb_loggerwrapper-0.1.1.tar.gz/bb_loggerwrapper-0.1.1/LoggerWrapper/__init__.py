import logging
import os
import re
import sys
from datetime import datetime as DT
from enum import IntEnum, EnumType
from rich.logging import RichHandler
from rich.traceback import install
from rich._null_file import NullFile
from rich.console import Console
from rich.style import Style
from typing import NamedTuple

install()

logging.LogRecord
def rm_esc(s):
    return re.sub( r'\x1b\[[0-9;]+m', '', str(s) )

def rlen(s):
    return len( rm_esc(s) )

def fit2term( string, width = None, indent = None, fill = False ):
    if not string.strip():
        return ''

    if width is None:
        width = term().x - 1

    if isinstance( indent, int ):
        pass
    elif isinstance( indent, str ):
        indent = len(rm_esc(indent))
    else:
        indent = 0
    _in = f"{'':{indent}}"

    lines = [string.strip()]
    while lines and rlen(lines[-1]) > ( width if len(lines) == 1 else width - indent ):
        # print(f"\x1b[1;33m{lines[-1] = }\x1b[0m\n")
        line = re.split( r'( +|\n+|\x1b\[[0-9;]+m)', lines.pop(-1) )
        # print(f"\x1b[1;33m{line = }\x1b[0m\n")
        newline = "" if not lines else _in
        if line and rlen(newline + line[0]) > width:
            # print(f"Line '{line[0]}' is greater than width {width}\n")
            l = line.pop(0)
            index = 0
            while rlen(newline + l[:index]) < width:
                index += 1
            newline += l[:index]
            line.insert( 0, l[index:] )
        else:
            while line and rlen(newline + line[0]) <= width:
                c = line.pop(0)
                if '\n' in c:
                    break
                else:
                    newline += c

        newline = newline.rstrip()
        if fill:
            while rlen(newline) < width:
                newline += ' '
        lines.append( newline )

        lastline = ''.join(line).strip()
        if lastline:
            lines.append( _in + lastline )

    lastline = re.split( r'\n+', lines.pop(-1) )
    lastlines = [ lastline.pop(0) ]
    for line in lastline:
        lastlines.append( _in + line )

    if fill:
        for line in lastlines:
            while rlen(line) < width:
                line += ' '
    return '\n'.join( lines + lastlines )

class Color:
    ce = '\x1b[39;38;2;9;197;246m'
    ceI = '\x1b[39;38;2;9;197;246;3m'
    err = '\x1b[39;38;2;200;25;5;1m'
    lb = '\x1b[39;38;2;20;130;180;1m'
    gd = '\x1b[39;38;2;184;174;18m'
    gdB = '\x1b[39;38;2;184;174;18;1m'
    gr = '\x1b[39;38;2;160;160;160;3m'
    pu = '\x1b[39;38;2;134;0;144;3m'
    pu2 = '\x1b[39;38;2;153;50;204;1m'
    lno = '\x1b[39;38;2;147;230;220;1m'
    wh = '\x1b[39;38;2;250;250;250m'
    blgr = '\x1b[39;38;2;60;90;140;1m'
    green = '\x1b[39;38;2;10;190;110m'
    dl = '\x1b[39;38;2;158;176;160m'
    dlI = '\x1b[39;38;2;158;176;160;3m'
    lr = '\x1b[39;38;2;225;80;60m'
    lrI = '\x1b[39;38;2;225;80;60;3m'
    _s = '\x1b[22;23;24;25;27;28;29m'
    _fg = '\x1b[39m'
    _ = '\x1b[0m'

    class BG:
        code = '\x1b[48;2;26;26;26m'
        error = '\x1b[48;2;61;12;2m'
        br = '\x1b[48;2;55;29;16m'
        _ = '\x1b[49m'

class Term(NamedTuple):
    x: int
    y: int

def term():
    try:
        return Term( *os.get_terminal_size() )
    except:
        return Term( 120, 24 )

class _LogLevelMeta( EnumType ):

    def __call__( mcls, value ):
        v = str(value).upper()
        for name, member in mcls.__members__.items():
            if v in [ *[ str(i) for i in [int(member), int(member/10)] ], name ]:
                return member
        raise ValueError(f"Invalid level '{value}'")

class LogLevel( IntEnum, metaclass = _LogLevelMeta ):
    NOTSET = 0
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50

    def __str__( self ):
        return self.name

    def __repr__( self ):
        return f"<(LogLevel: {self.name} - {self.value})>"

class ConsoleLogFormatter( logging.Formatter ):
    default_time_format = "%H:%M:%S"
    default_msec_format = "%s.%03d"

    def __init__( self, *, time_format = None ):
        super().__init__( validate = False )
        if time_format is None:
            time_format = self.default_time_format
        self.time_format = time_format
        self.fmt = (
            f"{{lvl_color}}[{{levelname}}]:"
            f" {Color.pu}{{module}}\x1b[23m{Color.wh}.{Color.pu2}{{funcName}}"
            f" {{lvl_color}}<{{lineno}}>{Color._}"
            f" {{txt_color}}{{message}}{Color._}{{time_color}}"
        )

    def _fmt_( self, record ):
        c = Color
        clvl, ctxt, ctime = [
            ("","",""),
            ( c.gr, c.dlI, c.ce ),
            ( c.blgr, c.dlI, c.wh ),
            ( c.gd, c.dlI, c.wh ),
            ( c.err, c.dlI, c.wh ),
            ( c.err, c.lr, c.err )
        ][ int(record.levelno / 10) ]
        msg = record.getMessage()
        return fit2term(
            self.fmt.format(
                lvl_color = clvl,
                txt_color = ctxt,
                time_color = ctime,
                levelname = record.levelname,
                module = record.module,
                funcName = record.funcName,
                lineno = record.lineno,
                message = msg
            ),
            indent = 6
        )

    def formatTime( self, record ):
        time = DT.fromtimestamp(record.created).strftime(self.time_format)
        return f"{time}.{int(record.msecs)}"

    def format( self, record ):
        lines = self._fmt_( record ).split('\n')
        time = f" [{self.formatTime( record )}]"
        if rlen( lines[-1] + time ) > term().x - 1:
            spc = "\n" + ( " " * ( term().x - 1 - len(time) ))
        else:
            spc = " " * ( term().x - 1 - len(time) - rlen(lines[-1]))
        lines[-1] += f"{spc}{time}{Color._}"
        return '\n'.join( lines )

class ConsoleHandler( RichHandler ):

    def __init__( self ):
        super().__init__( rich_tracebacks = True )
        self.setFormatter( ConsoleLogFormatter() )
        self.stream = sys.stderr

    def emit( self, record ):
        msg = self.formatter.format( record )
        if (
            self.rich_tracebacks
            and record.exc_info
            and record.exc_info != (None, None, None)
        ):
            _msg = record.msg
            record.msg = ""
            try:
                super().emit( record )
                record.msg = _msg
                self._print(msg)
            except:
                pass
            return

        if isinstance(self.console.file, NullFile):
            # Handles pythonw, where stdout/stderr are null, and we return NullFile
            # instance from Console.file. In this case, we still want to make a log record
            # even though we won't be writing anything to a file.
            self.handleError(record)
        else:
            try:
                self._print(msg)
            except Exception:
                self.handleError(record)

    def _print( self, msg ):
        self.stream.write( msg + '\n' )

class Logger( logging.getLoggerClass() ):

    def __init__( self, name, level = None ):
        super().__init__( name )

# import logging
# import tests
# log = logging.getLogger("tests")
# log.warning("Sadie the dog")
