# BB-LoggerWrapper

> Simple wrapper with a formatted StreamHandler (ConsoleHandler)

```python
# __init__.py

import logging
import os
from LoggerWrapper import Logger, ConsoleHandler, LogLevel

logging.setLoggerClass(Logger)

level = LogLevel( os.getenv( "PYTHON_LOGLEVEL", "info" ))
logger = logging.getLogger(__name__)
logger.setLevel(level)
logger.addHandler( ConsoleHandler() )

```

## Changelog

##### v0.1.1 - 2026-04-03

* Corrected README instructions
* Took over formatting the log record
    * fixed errors with messages containing '{' and '}'
* Changed ConsoleHandler formatting
* Added rich formatting to tracebacks
* ConsoleLogger now inherits from rich.logging.RichHandler

##### v0.1.0 - 2026-03-18

* Initial release
