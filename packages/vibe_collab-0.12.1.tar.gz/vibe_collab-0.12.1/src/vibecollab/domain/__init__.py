"""Domain models subpackage."""
