"""Core business logic subpackage."""
