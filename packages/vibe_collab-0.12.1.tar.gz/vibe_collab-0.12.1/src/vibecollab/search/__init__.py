"""Semantic search subpackage."""
