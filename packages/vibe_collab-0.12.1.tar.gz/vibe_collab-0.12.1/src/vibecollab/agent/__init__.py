"""Agent / LLM / MCP subpackage."""
