# Copyright (c) 2025, qBraid Development Team
# All rights reserved.

"""
Pydantic schemas for group job API requests and responses.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field, field_serializer

from qbraid_core.decimal import Credits

from .job import TimeStamps


class GroupStatus(str, Enum):
    """Status of a group job session.

    Attributes:
        OPEN: Group is accepting new job submissions.
        CLOSED: Group is closed for new submissions; jobs still executing.
        COMPLETED: All jobs reached COMPLETED state.
        FAILED: All jobs in terminal state, and at least 1 failed.
        CANCELLED: Group was explicitly cancelled by the user.
    """

    OPEN = "OPEN"
    CLOSED = "CLOSED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

    @classmethod
    def terminal_states(cls) -> set[GroupStatus]:
        """Returns the set of terminal group statuses."""
        return {cls.COMPLETED, cls.FAILED, cls.CANCELLED}


class GroupJob(BaseModel):
    """Schema for group job response model.

    Returned by the runtime API when creating, retrieving, or listing groups.
    The SDK's GroupJobSession wraps this model.
    """

    groupJobQrn: str = Field(..., description="Group job resource name")
    name: Optional[str] = Field(None, description="User-assigned group name")
    status: GroupStatus = Field(..., description="Group status")
    organizationUserId: str = Field(..., description="Organization user ID")

    # Job tracking
    jobCount: int = Field(0, ge=0, description="Total number of jobs in the group")
    completedCount: int = Field(0, ge=0, description="Number of completed jobs")
    failedCount: int = Field(0, ge=0, description="Number of failed jobs")
    cancelledCount: int = Field(0, ge=0, description="Number of cancelled jobs")

    # Cost aggregation
    totalEstimatedCost: Optional[Credits] = Field(
        None, ge=0, description="Sum of estimated costs for all jobs"
    )
    totalCost: Optional[Credits] = Field(
        None, ge=0, description="Sum of actual costs for completed jobs"
    )

    # Timestamps
    timeStamps: Optional[TimeStamps] = Field(None, description="Group timestamps")

    # TTL
    maxTTL: Optional[int] = Field(
        None, ge=1, le=86400, description="Max time-to-live in seconds (1s – 86400s / 24h)"
    )

    # User metadata
    tags: dict[str, Any] = Field(default_factory=dict, description="User-defined tags")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")

    @field_serializer("totalEstimatedCost", "totalCost")
    def serialize_credits(self, value: Optional[Credits]) -> Optional[float]:
        """Serialize Credits to float for JSON response."""
        if value is None:
            return None
        return float(value)

    @field_serializer("status")
    def serialize_status(self, value: GroupStatus) -> str:
        """Serialize GroupStatus enum to its string value."""
        return value.value
