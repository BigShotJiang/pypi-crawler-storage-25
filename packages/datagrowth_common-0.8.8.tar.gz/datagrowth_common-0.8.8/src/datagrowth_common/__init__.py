"""datagrowth-common — utilidades compartidas entre apps Datagrowth.

v0.8.8 (bugfix release):
- ui/csrf.js: monkey-patcha `window.fetch` para inyectar el header
  `X-CSRF-Token` en cualquier request same-origin con método no-safe
  (POST/PUT/PATCH/DELETE). Sin esto, todo `fetch(..., {method: 'POST',
  headers: {'Content-Type': 'application/json'}, ...})` daba
  403 `CSRF_TOKEN_MISMATCH` porque el wiring previo solo cubría HTMX
  y forms HTML clásicos. `sidebar_shell.html` y `empty.html` cargan
  ahora `csrf.js` sin `defer` para que el patch esté activo antes que
  cualquier `<script>` inline posterior.

v0.8.7 (bugfix release):
- errors: `register_error_handlers` ahora deja pasar los códigos 3xx
  como `RedirectResponse` en lugar de renderizarlos como banner. Bug
  reproducido en producción: `require_auth` levanta `HTTPException(303,
  headers={"Location": "/login"})` para redirigir al login cuando la
  sesión expira, pero el handler lo trataba como error y renderizaba
  "Error 303 / See Other" perdiendo el Location → el browser quedaba
  mirando el banner sin redirect. Ahora `[300, 400)` se devuelve
  intacto vía `RedirectResponse`. 2 tests nuevos cubren `Location`
  mayúscula y minúscula.

v0.8.6 (release):
- errors: nuevo helper `register_error_handlers(app, jinja_env)` que
  reemplaza el JSON-en-pantalla-blanca por un banner inferior-derecho.
  Tres ramas según cliente: navegación HTML (renderiza `dg/pages/error.html`
  con shell + toast inicial), HTMX (fragmento OOB que inyecta el toast
  vía `htmx:beforeSwap` adaptado en `htmx-events.js`) y API (sigue JSON).
  Mensajes por código (401/403/404/422/429/5xx); >=500 oculta detalles
  internos al usuario y vuelca el stack al logger.
- ui: `dg/layouts/empty.html` ahora monta `#dg-toasts` + carga
  `toasts.js`; `dg/layouts/sidebar_shell.html` expone `toast_initial`
  block para el toast pre-renderizado.
- middleware: `CSRFMiddleware` resuelve/genera el token al inicio del
  dispatch y lo expone como `request.state.dg_csrf_token`. Antes solo
  seteaba la cookie en el response, así que los templates Jinja del
  mismo request no podían leerlo.
- ui: nueva macro `dg/components/csrf.html::csrf_input(request)` que
  renderiza `<input type=hidden name=csrf_token>` server-side.
- template + ui: `template/src/templates/auth/login.html` (standalone,
  no cargaba `csrf.js`) y `dg/layouts/sidebar_shell.html` (form de
  logout del topbar) usan el macro. Login y logout funcionan sin JS.

v0.8.2 (bugfix release):
- UI: `dg/layouts/empty.html` (login/signup/reset) tambien carga
  `static/js/csrf.js`. v0.8.1 solo lo cableo en `sidebar_shell.html`,
  asi que `/auth/password` (POST desde la pagina de login) seguia
  reventando con 403 `CSRF_TOKEN_MISMATCH`. Ahora ambos layouts del
  paquete tienen el wiring.

v0.8.1 (bugfix release):
- UI: nuevo `static/js/csrf.js` cableado desde `dg/layouts/sidebar_shell.html`
  como `<script defer>`. Lee la cookie `dg_csrf` (no-httpOnly) que setea
  `CSRFMiddleware` e inyecta el token como header `X-CSRF-Token` (HTMX)
  o campo hidden `csrf_token` (forms HTML). Sin este wiring, el form de
  logout del topbar enviaba POST `/logout` sin token y el middleware
  respondia 403 `CSRF_TOKEN_MISMATCH` — incidente reproducido en
  `backend.dev.datagrowth.es` el 2026-05-22.
- template: nuevo helper `get_engine()` en `template/src/db.py` (lazy);
  `template/src/api/health.py` lo invoca dentro de `ready()`. Fix
  `ImportError: cannot import name 'engine' from 'src.db'` en el
  smoke test del template.

v0.8.0:
- Nuevo submódulo `observability` con `init_sentry()` (scrubbing de PII)
  y `default_instrumentator()` (Prometheus FastAPI).
- Nuevo submódulo `middleware` con `RequestIdMiddleware`,
  `SecurityHeadersMiddleware`, `CSRFMiddleware`, `MetricsAuthMiddleware`
  y `build_limiter()` (slowapi + Redis).
- Nuevo submódulo `me` con `make_me_router()`: endpoints GDPR
  self-service (export ZIP, delete diferido, cancel).
- Nuevo submódulo `legal` con `make_legal_router()`: páginas públicas
  `/privacy`, `/terms`, `/security` desde markdown.
- Nuevo submódulo `retention` con `make_retention_purger()`: cron que
  purga `user_deletion_request` vencidos + comprime audit log.
- Nuevo módulo `audit` con `emit()` para `user_audit_log` (incluye
  ip + user_agent).
- Template: nueva migración `v3_access_event.sql` (tabla
  `user_deletion_request` + columnas ip/user_agent en `user_audit_log`),
  workflow CI base, `infra/backup.sh`, plantillas `docs/PRIVACY.md` y
  `docs/RUNBOOK.md`, router `health` con `/live` y `/ready`.
- Nuevas extras opcionales: `[observability]` (sentry-sdk +
  prometheus-fastapi-instrumentator) y `[middleware]` (slowapi).
- Submódulo `qa` con auditor determinista `run_audit(repo_root)` (19 checks)
  + skill `prod-ready-checklist` en el template.
- Skills de desarrollo en el template (`architecture-blueprint`, `autodoc`,
  `readme-blueprint`, `skill-creator`, `output-skill`, `pytest-coverage`,
  `taste-skill`, `ui-ux-pro-max`).
- Regla `no-roadmap-comments` en `.claude/rules/` + `.cursor/rules/` del
  template.
- Nuevo módulo `env` con `dg_env()`, `is_dev_env()`, `is_prod_env()`:
  normaliza `DG_ENV` a la convención canónica `prod`/`dev`. Acepta
  legacy `production`/`development` por compat. Reemplaza todos los
  checks dispersos en `logger`, `auth.session`, `middleware.csrf`,
  `observability.sentry` y el template.
- Nuevo módulo `postgres` con `resolve_postgres_url()` y
  `to_sqlalchemy_url()`: helper común para construir la URL Postgres
  desde `DG_DATABASE_URL` o `POSTGRES_PASSWORD + DG_SUPABASE_DB_*`.
  Reemplaza la duplicación entre `app-backend/src/lib/postgres_url.py`
  y `template/src/db.py::_resolve_database_url`.

v0.7.x (mayo 2026):
- Nuevo módulo `datagrowth_common.migrations` con `apply_migrations(dir)`.
  Las apps generadas lo invocan en el lifespan para aplicar `migrations/*.sql`
  contra su Postgres (idempotente, tracking en `dg_internal._dg_applied_migrations`).
  Habilita despliegues a clientes en VPS distintos al del control plane.
- Nueva optional dep `[postgres]` con `psycopg[binary]>=3.2`.

v0.5.0 — v0.6.x:
- Nuevo módulo `datagrowth_common.users` con `make_users_router`,
  `PermissionCatalog`, `make_require_permission`, `bootstrap_roles` y audit log.
  Migración `001_users_rbac.sql` empaquetada en el wheel.
- Template del repo adopta el panel RBAC nuevo: gestión multi-rol, permisos
  por catálogo, audit log y endpoint `POST /admin/users/{id}/password/set`.

v0.3.1 — v0.4.x:
- Subpaquete `datagrowth_common.ui`: Jinja2 partials (`dg/...`), tokens CSS
  light/dark, Tailwind precompilado y JS de theme/toasts/htmx-events.
  `register_ui(app, jinja_env, mount_path)` cablea todo en una FastAPI host app.
- `tailwind-preset.cjs` empaquetado en el wheel para que apps con Tailwind
  local compartan tokens y safelist con el paquete.

v0.3.0 (BREAKING):
- Eliminados `datagrowth_common.authentik` y `datagrowth_common.auth_fastapi`
  (forward-auth Authentik). Importarlos lanza `ImportError`.
- `datagrowth_common.auth.local` renombrado a `datagrowth_common.auth.session_hmac`
  (alias deprecated eliminado en 0.8.0).
- Modelo único de auth: Supabase Auth (cookie JWT en `auth.session` +
  endpoints en `auth.router` + verify en `auth.supabase`).

Ver CHANGELOG.md para la guía de migración completa.
"""
from .auth.supabase import (
    SupabaseUser,
    SupabaseUserDep,
    require_role,
    require_supabase_jwt,
    verify_supabase_jwt,
)
from .auth.session import (
    ACCESS_COOKIE,
    REFRESH_COOKIE,
    SessionTokens,
    SessionUserDep,
    clear_session,
    get_session_tokens,
    refresh_session_tokens,
    require_session,
    set_session,
)
from .auth.router import auth_router, make_auth_router
from .api.users import users_router
from .errors import register_error_handlers
from .result import Result, ok, err
from .logger import get_logger, setup_logging
from .migrations import apply_migrations
from .postgres import resolve_postgres_url, to_sqlalchemy_url
from .ui import UI_VERSION, register_ui
from . import audit, env, legal, me, middleware, observability, postgres, qa, retention
from .env import dg_env, is_dev_env, is_prod_env

__version__ = "0.8.8"

__all__ = [
    # supabase auth (JWT)
    "SupabaseUser",
    "SupabaseUserDep",
    "require_role",
    "require_supabase_jwt",
    "verify_supabase_jwt",
    "users_router",
    # session (cookie httpOnly server-rendered)
    "ACCESS_COOKIE",
    "REFRESH_COOKIE",
    "SessionTokens",
    "SessionUserDep",
    "set_session",
    "clear_session",
    "get_session_tokens",
    "refresh_session_tokens",
    "require_session",
    # auth router (login + OAuth + refresh + logout)
    "auth_router",
    "make_auth_router",
    # core
    "Result",
    "ok",
    "err",
    "get_logger",
    "setup_logging",
    # migrations (auto-aplicadas en lifespan de la app generada)
    "apply_migrations",
    # postgres URL helpers (DG_DATABASE_URL o POSTGRES_PASSWORD + DG_SUPABASE_DB_*)
    "postgres",
    "resolve_postgres_url",
    "to_sqlalchemy_url",
    # ui (datagrowth_common.ui)
    "register_ui",
    "UI_VERSION",
    # error handlers (banner global server-rendered + JSON para API)
    "register_error_handlers",
    # qa — auditor de production-readiness compartido
    "qa",
    # production-readiness helpers (observabilidad + middleware + GDPR)
    "observability",
    "middleware",
    "me",
    "audit",
    "legal",
    "retention",
    # env (DG_ENV canónico = prod/dev; acepta production/development legacy)
    "env",
    "dg_env",
    "is_dev_env",
    "is_prod_env",
    "__version__",
]
