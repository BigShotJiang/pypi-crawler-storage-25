"""Resolucion de URL Postgres desde variables de entorno.

Convencion comun a todas las apps Datagrowth (backend + apps generadas):

1. `DG_DATABASE_URL` (URL libpq completa) tiene prioridad. Si esta:
   `postgresql://user:pass@host:port/db` o variantes (`postgres://`,
   `postgresql+psycopg://`).

2. Si no, se construye desde piezas:
   - `POSTGRES_PASSWORD` (obligatorio)
   - `DG_SUPABASE_DB_HOST` (obligatorio salvo `default_host`)
   - `DG_SUPABASE_DB_PORT` (default `5432`)
   - `DG_SUPABASE_DB_USER` (default `postgres`)
   - `DG_SUPABASE_DB_NAME` (default `postgres`)

`resolve_postgres_url` devuelve el URL libpq (`postgresql://`) listo para
psycopg, o `None` si la config esta incompleta. El caller decide si
levanta o sigue sin BD.

`to_sqlalchemy_url` traduce a `postgresql+psycopg://` (driver psycopg3),
el unico que SQLAlchemy 2.x acepta sin pedir `psycopg2`.

Antes de v0.8.0 esta logica vivia duplicada en
`app-backend/src/lib/postgres_url.py` y `template/src/db.py`.
"""

from __future__ import annotations

import os
from urllib.parse import quote_plus

_VALID_LIBPQ_PREFIXES = (
    "postgresql://",
    "postgres://",
    "postgresql+psycopg://",
    "postgresql+psycopg2://",
)


def resolve_postgres_url(*, default_host: str | None = None) -> str | None:
    """Devuelve URL libpq (`postgresql://...`) o `None` si no esta configurada.

    `default_host` se usa solo si `DG_SUPABASE_DB_HOST` no esta seteada.
    El backend lo pasa (`"supabase-db"` por compatibilidad historica); las
    apps generadas no, asi que requieren el host explicito en el `.env`.

    Si `DG_DATABASE_URL` esta rellenada pero con un esquema que NO es
    libpq (caso real visto en prod: alguien pego la `SUPABASE_URL`
    HTTPS por error), levantamos `ValueError` con mensaje claro en
    lugar de devolverla. Sin esto, SQLAlchemy intenta cargar el
    dialecto `https` y revienta el lifespan con
    `NoSuchModuleError: Can't load plugin: sqlalchemy.dialects:https`
    — un error cripticisimo para diagnosticar desde un crash loop.
    """
    explicit = (os.getenv("DG_DATABASE_URL") or "").strip()
    if explicit:
        if not explicit.startswith(_VALID_LIBPQ_PREFIXES):
            scheme = explicit.split("://", 1)[0] if "://" in explicit else explicit[:32]
            raise ValueError(
                f"DG_DATABASE_URL has invalid scheme '{scheme}': must start with "
                f"one of {_VALID_LIBPQ_PREFIXES}. Got prefix: '{explicit[:80]}'. "
                "Si querias usar Supabase via HTTPS, esa URL pertenece a "
                "`SUPABASE_URL`, no a `DG_DATABASE_URL`. `DG_DATABASE_URL` "
                "debe ser una URL libpq tipo "
                "`postgresql://user:pass@host:port/db`."
            )
        return explicit

    password = (os.getenv("POSTGRES_PASSWORD") or "").strip()
    if not password:
        return None

    host = (os.getenv("DG_SUPABASE_DB_HOST") or "").strip() or (default_host or "")
    if not host:
        return None

    port = (os.getenv("DG_SUPABASE_DB_PORT") or "5432").strip() or "5432"
    user = (os.getenv("DG_SUPABASE_DB_USER") or "postgres").strip() or "postgres"
    name = (os.getenv("DG_SUPABASE_DB_NAME") or "postgres").strip() or "postgres"

    return f"postgresql://{user}:{quote_plus(password)}@{host}:{port}/{name}"


def to_sqlalchemy_url(libpq_url: str) -> str:
    """Convierte un URL libpq al esquema `postgresql+psycopg://` para SQLAlchemy.

    SQLAlchemy 2.x asume `psycopg2` con `postgresql://`; este ecosistema
    usa psycopg 3 exclusivamente, asi que forzamos el driver.
    """
    if libpq_url.startswith("postgresql+psycopg://"):
        return libpq_url
    if libpq_url.startswith("postgresql+psycopg2://"):
        return "postgresql+psycopg://" + libpq_url[len("postgresql+psycopg2://"):]
    if libpq_url.startswith("postgresql://"):
        return "postgresql+psycopg://" + libpq_url[len("postgresql://"):]
    if libpq_url.startswith("postgres://"):
        return "postgresql+psycopg://" + libpq_url[len("postgres://"):]
    return libpq_url


__all__ = ["resolve_postgres_url", "to_sqlalchemy_url"]
