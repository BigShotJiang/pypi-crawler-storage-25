"""Handlers de error compartidos entre backend y apps generadas.

`register_error_handlers(app, jinja_env)` registra handlers para
`HTTPException`, `RequestValidationError` y `Exception`. La respuesta se
adapta al tipo de cliente:

**3xx no son errores**: `HTTPException(status_code=303,
headers={"Location": ...})` se usa en `require_auth` para redirigir al
login cuando la sesión expira. El handler detecta códigos `[300, 400)`
y los devuelve como `RedirectResponse` sin tocar — el browser hace el
redirect del Location header. Solo `[400, 600)` activa el flow de
banner/JSON descrito abajo.


- **HTMX** (`HX-Request: true`): devuelve `200 OK` con un fragmento OOB
  que inyecta un toast en `#dg-toasts`. Status original en header
  `HX-Status`. El default de HTMX de no swappear en 4xx/5xx queda
  cubierto por el wiring `htmx:beforeSwap` en `static/js/htmx-events.js`,
  que fuerza el swap cuando el body contiene `data-toast`.

- **Navegación HTML** (Accept incluye `text/html` explícito): renderiza
  `dg/pages/error.html`. El template selecciona layout en función de
  `request.state.dg_user`:
    - autenticado → `sidebar_shell.html` (body vacío + toast)
    - anónimo    → `empty.html` (banner + botón "Iniciar sesión")

- **API/JSON** (todo lo demás — Accept vacío, `*/*`, `application/json`,
  o paths `/api/*`/`/auth/*`): mantiene el JSON `{"detail": ...}` que
  esperan los clientes programáticos. Sin cambios respecto al
  comportamiento por defecto de FastAPI. La regla "JSON por defecto"
  cubre TestClient (`Accept: */*`), `curl` sin `-H Accept`, y cualquier
  endpoint REST del backend que no caiga bajo `/api/` o `/auth/` (p. ej.
  `/admin/inspect/*`, `/packages/*`, `/landings/*`).

El mensaje del toast se deriva de `exc.detail` (si es dict con `message`)
o cae a un mapeo por código de estado. Nunca se filtra el stack trace
del 500 al usuario; el logger estructurado lo recoge para Sentry.
"""
from __future__ import annotations

import structlog
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from jinja2 import Environment

logger = structlog.get_logger(__name__)


# Mensajes y nivel de toast por código HTTP. `level` mapea a las clases
# del macro `toast()` (info|success|warning|danger).
_STATUS_DEFAULTS: dict[int, tuple[str, str]] = {
    401: ("warning", "Sesión expirada. Inicia sesión de nuevo."),
    403: ("warning", "No tienes permiso para acceder a esta sección."),
    404: ("info", "No encontrado."),
    422: ("warning", "Datos inválidos. Revisa el formulario."),
    429: ("warning", "Demasiadas peticiones, espera un momento."),
}


def _message_for(exc: Exception, status_code: int) -> tuple[str, str]:
    """Devuelve `(level, message)` para mostrar en el toast.

    Si el handler levantó `HTTPException(detail={"message": "..."})` se
    respeta ese mensaje. Si no, cae al mapa por código. Para >=500 se
    fuerza un mensaje genérico para no filtrar detalles internos.
    """
    level, default_msg = _STATUS_DEFAULTS.get(
        status_code, ("danger", "Error inesperado. Vuelve a intentarlo.")
    )
    if status_code >= 500:
        return level, default_msg

    detail = getattr(exc, "detail", None)
    if isinstance(detail, dict):
        msg = detail.get("message")
        if isinstance(msg, str) and msg.strip():
            return level, msg.strip()
    if isinstance(detail, str) and detail.strip() and detail.lower() not in {
        "not found",
        "method not allowed",
        "internal server error",
    }:
        return level, detail.strip()
    return level, default_msg


def _wants_json(request: Request) -> bool:
    """`True` si el cliente espera JSON.

    JSON es el default: HTML solo cuando el navegador lo pide
    explícitamente con `Accept: text/html` (los browsers envían
    `text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8`).
    TestClient/`curl`/clientes REST envían `*/*` o `application/json`
    o nada — todos esos casos siguen recibiendo el JSON
    `{"detail": ...}` que esperaban antes del banner global.

    Los paths `/api/*` y `/auth/*` se fuerzan a JSON incluso si el
    cliente pide HTML (defensa contra browsers que tropiezan con
    endpoints REST por error).
    """
    path = request.url.path or ""
    if path.startswith(("/api/", "/auth/")):
        return True
    accept = request.headers.get("accept", "") or ""
    if "text/html" in accept.lower():
        return False
    return True


def _is_htmx(request: Request) -> bool:
    return (request.headers.get("HX-Request") or "").lower() == "true"


def _user_from_request(request: Request) -> object | None:
    """Best-effort: lee `request.state.dg_user` sin fallar si no existe."""
    try:
        return getattr(request.state, "dg_user", None)
    except Exception:
        return None


def _render_html(
    jinja_env: Environment,
    request: Request,
    status_code: int,
    level: str,
    message: str,
) -> HTMLResponse:
    user = _user_from_request(request)
    tokens_override_href = None
    try:
        tokens_override_href = getattr(request.state, "dg_tokens_override_href", None)
    except Exception:
        tokens_override_href = None

    template = jinja_env.get_template("dg/pages/error.html")
    body = template.render(
        request=request,
        user=user,
        status_code=status_code,
        message=message,
        level=level,
        tokens_override_href=tokens_override_href,
    )
    return HTMLResponse(content=body, status_code=status_code)


def _render_htmx_toast(
    jinja_env: Environment,
    status_code: int,
    level: str,
    message: str,
) -> HTMLResponse:
    template = jinja_env.get_template("dg/components/toast_oob.html")
    body = template.render(message=message, level=level)
    # Devolvemos status original (4xx/5xx) para que la lógica del caller
    # HTMX siga interpretándolo como error si lo necesita. `htmx-events.js`
    # detecta `data-toast` en el body y fuerza el swap con
    # `htmx:beforeSwap`. `HX-Status` queda como diagnóstico para devtools.
    return HTMLResponse(
        content=body,
        status_code=status_code,
        headers={
            "HX-Status": str(status_code),
            "HX-Reswap": "none",
        },
    )


def register_error_handlers(app: FastAPI, jinja_env: Environment) -> None:
    """Cablea handlers de error que renderizan banner HTML para
    navegaciones, OOB toast para HTMX y JSON para API."""

    async def _handle(request: Request, exc: Exception, status_code: int) -> Response:
        level, message = _message_for(exc, status_code)

        if _wants_json(request):
            detail = getattr(exc, "detail", None)
            payload = (
                detail if isinstance(detail, (dict, list, str))
                else {"code": "INTERNAL_ERROR", "message": message}
            )
            headers = getattr(exc, "headers", None) or {}
            return JSONResponse(
                status_code=status_code,
                content={"detail": payload}
                if not isinstance(payload, dict) or "detail" not in payload
                else payload,
                headers=headers,
            )

        try:
            if _is_htmx(request):
                return _render_htmx_toast(jinja_env, status_code, level, message)
            return _render_html(jinja_env, request, status_code, level, message)
        except Exception as render_exc:
            # Si el render del error falla, no podemos volver a renderizar
            # otro error (loop infinito). Caemos a JSON con el detalle
            # original. Logueamos el render fail para que se note en
            # observabilidad.
            logger.error(
                "error_render_failed",
                status_code=status_code,
                render_error=str(render_exc)[:300],
            )
            return JSONResponse(
                status_code=status_code,
                content={"detail": {"code": "RENDER_FAILED", "message": message}},
            )

    @app.exception_handler(HTTPException)
    async def _http_exception_handler(request: Request, exc: HTTPException) -> Response:
        # 3xx NO son errores: son redirects intencionales (`require_auth`
        # levanta `HTTPException(303, headers={"Location": "/login"})`
        # cuando la sesión expira para que el browser navegue al login).
        # Si los trato como error renderizo una página "Error 303 / See
        # Other" y el browser pierde el Location header — el usuario se
        # queda mirando un banner en vez de ir al login.
        if 300 <= exc.status_code < 400:
            headers = exc.headers or {}
            location = headers.get("Location") or headers.get("location") or "/"
            return RedirectResponse(url=location, status_code=exc.status_code)
        return await _handle(request, exc, exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def _validation_exception_handler(
        request: Request, exc: RequestValidationError,
    ) -> Response:
        return await _handle(request, exc, 422)

    @app.exception_handler(Exception)
    async def _unhandled_exception_handler(request: Request, exc: Exception) -> Response:
        # Logueamos con stack completo (structlog capturará exc_info si está
        # configurado). El usuario solo ve el mensaje genérico de >=500.
        logger.error(
            "unhandled_exception",
            path=request.url.path,
            method=request.method,
            error=str(exc)[:500],
            exc_info=True,
        )
        return await _handle(request, exc, 500)

    # `RateLimitExceeded` (slowapi) no es subclase de `HTTPException`, así
    # que el handler genérico no lo captura. Cuando slowapi está
    # instalado y la app lo está usando, lo cableamos aquí para que el
    # 429 también dispare el banner HTML/HTMX en lugar del JSON crudo
    # que devuelve el handler por defecto.
    try:
        from slowapi.errors import RateLimitExceeded
    except ImportError:  # slowapi es extra opcional `[middleware]`
        return

    @app.exception_handler(RateLimitExceeded)
    async def _rate_limit_handler(request: Request, exc: RateLimitExceeded) -> Response:
        # `exc.detail` en slowapi es el texto del límite (ej "5 per minute").
        # Lo pasamos al handler genérico como dict estructurado para que el
        # mapeo de mensajes encuentre el código 429.
        wrapped = HTTPException(
            status_code=429,
            detail={"code": "RATE_LIMITED", "message": str(getattr(exc, "detail", "rate-limit"))},
        )
        return await _handle(request, wrapped, 429)


__all__ = ["register_error_handlers"]
