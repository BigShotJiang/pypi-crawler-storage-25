// CSRF double-submit wiring para `CSRFMiddleware` del paquete.
//
// El middleware setea la cookie `dg_csrf` (no-httpOnly) en cada response.
// Este script:
//   - Lee la cookie y la mete como header `X-CSRF-Token` en cada request
//     de HTMX (`htmx:configRequest`).
//   - Para forms HTML clasicos (submit nativo, sin `hx-*`), inyecta un
//     campo hidden `csrf_token` que el middleware lee del body
//     url-encoded.
//   - Monkey-patcha `window.fetch` para inyectar el header en cualquier
//     llamada same-origin con metodo mutante (POST/PUT/PATCH/DELETE).
//     Sin esto, cualquier `fetch('/foo', {method: 'POST', headers:
//     {'Content-Type': 'application/json'}, body: ...})` muere con 403
//     `CSRF_TOKEN_MISMATCH` y al usuario le sale "Error 403:
//     [object Object]" — porque `data.detail` viene como dict y el
//     template literal hace coercion. Lo resolvemos en la frontera
//     (fetch) para que ningun consumidor del paquete tenga que
//     recordarse del token. Aplica a backend y a apps generadas.
//
// Multipart sigue requiriendo header (uploads van por HTMX o `fetch`,
// ambos cubiertos por el wiring).
//
// El script se incluye sin `defer` desde `sidebar_shell.html` / `empty.html`
// para que el monkey-patch de `fetch` este activo antes de que cualquier
// script inline posterior pueda lanzar un request. Los listeners (HTMX,
// submit) se attachan a `document` — no a `document.body` — porque el
// body aun no existe en ese punto del parsing.

(function () {
  function readCookie(name) {
    var match = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
    return match ? decodeURIComponent(match[1]) : null;
  }

  document.addEventListener("htmx:configRequest", function (evt) {
    var token = readCookie("dg_csrf");
    if (token) {
      evt.detail.headers["X-CSRF-Token"] = token;
    }
  });

  document.addEventListener("submit", function (evt) {
    var form = evt.target;
    if (!form || form.tagName !== "FORM") return;
    var method = (form.method || "GET").toUpperCase();
    if (method === "GET" || method === "HEAD") return;
    if (
      form.hasAttribute("hx-post") || form.hasAttribute("hx-put") ||
      form.hasAttribute("hx-patch") || form.hasAttribute("hx-delete")
    ) return;
    var token = readCookie("dg_csrf");
    if (!token) return;
    var existing = form.querySelector('input[name="csrf_token"]');
    if (existing) {
      existing.value = token;
      return;
    }
    var input = document.createElement("input");
    input.type = "hidden";
    input.name = "csrf_token";
    input.value = token;
    form.appendChild(input);
  }, true);

  // Monkey-patch de `window.fetch`. Solo inyectamos el header en metodos
  // no-safe (POST/PUT/PATCH/DELETE) y solo cuando la URL es same-origin.
  // Cross-origin queda intacto. La guarda `__dgFetchPatched` evita doble
  // patch si el script se incluye dos veces (caso: host app que tambien
  // lo cargue inline).
  if (typeof window.fetch === "function" && !window.__dgFetchPatched) {
    window.__dgFetchPatched = true;
    var _origFetch = window.fetch.bind(window);
    window.fetch = function (input, init) {
      init = init || {};
      var url = "";
      if (typeof input === "string") {
        url = input;
      } else if (input && input.url) {
        url = input.url;
      }
      var isSameOrigin = (
        url.length === 0 ||
        url.charAt(0) === "/" ||
        url.indexOf(location.origin) === 0
      );
      var method = ((init.method || (input && input.method) || "GET") + "").toUpperCase();
      var needsCsrf = isSameOrigin && method !== "GET" &&
        method !== "HEAD" && method !== "OPTIONS";
      if (!needsCsrf) return _origFetch(input, init);
      var token = readCookie("dg_csrf");
      if (!token) return _origFetch(input, init);
      // `init.headers` puede ser objeto literal, instancia de Headers,
      // o array de tuplas. Manejamos las tres formas.
      var h = init.headers;
      if (h instanceof Headers) {
        if (!h.has("X-CSRF-Token")) h.set("X-CSRF-Token", token);
      } else if (Array.isArray(h)) {
        var has = false;
        for (var i = 0; i < h.length; i++) {
          if ((h[i][0] + "").toLowerCase() === "x-csrf-token") { has = true; break; }
        }
        if (!has) h.push(["X-CSRF-Token", token]);
      } else {
        h = h || {};
        var hasKey = false;
        for (var k in h) {
          if (k.toLowerCase() === "x-csrf-token") { hasKey = true; break; }
        }
        if (!hasKey) h["X-CSRF-Token"] = token;
        init.headers = h;
      }
      return _origFetch(input, init);
    };
  }
})();
