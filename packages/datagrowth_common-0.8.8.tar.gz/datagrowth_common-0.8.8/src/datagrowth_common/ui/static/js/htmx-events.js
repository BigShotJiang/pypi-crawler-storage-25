// HTMX wiring + modal helpers + command palette + error-toast bridge.
(function () {
  "use strict";

  window.openModal = function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.classList.remove("hidden");
    var input = el.querySelector("input,select,textarea,button");
    if (input) try { input.focus(); } catch (_) { /* noop */ }
  };

  window.closeModal = function (id) {
    var el = document.getElementById(id);
    if (el) el.classList.add("hidden");
  };

  function isPaletteOpen() {
    var el = document.getElementById("dg-command-palette");
    return el && !el.classList.contains("hidden");
  }

  document.addEventListener("keydown", function (ev) {
    var meta = ev.metaKey || ev.ctrlKey;
    if (meta && ev.key && ev.key.toLowerCase() === "k") {
      ev.preventDefault();
      if (isPaletteOpen()) window.closeModal("dg-command-palette");
      else window.openModal("dg-command-palette");
      return;
    }
    if (ev.key === "Escape") {
      document.querySelectorAll('[role="dialog"]:not(.hidden)').forEach(function (el) {
        el.classList.add("hidden");
      });
    }
  });

  // HTMX por defecto no swappea las respuestas 4xx/5xx. El backend usa
  // `register_error_handlers` para devolver un fragmento OOB con un toast
  // server-rendered cuando la petición es HTMX. Forzamos el swap solo
  // cuando la respuesta trae `data-toast` para no romper otros handlers
  // que confíen en el comportamiento por defecto.
  document.body && document.body.addEventListener("htmx:beforeSwap", function (ev) {
    var xhr = ev.detail && ev.detail.xhr;
    if (!xhr || xhr.status < 400) return;
    var body = xhr.responseText || "";
    if (body.indexOf("data-toast") >= 0) {
      ev.detail.shouldSwap = true;
      ev.detail.isError = false;
    }
  });

  // Fallback client-side: si el servidor no devolvió un toast (caso típico:
  // proxy intermedio, timeout antes de llegar al backend, error de red),
  // inyectamos un toast genérico para que el usuario no se quede sin
  // feedback. Cuando el servidor SÍ devolvió un toast, el swap OOB ya lo
  // pintó y este listener no hace nada.
  document.body && document.body.addEventListener("htmx:responseError", function (ev) {
    var region = document.getElementById("dg-toasts");
    if (!region) return;
    var xhr = ev.detail && ev.detail.xhr;
    var body = (xhr && xhr.responseText) || "";
    if (body.indexOf("data-toast") >= 0) return;

    var status = (xhr && xhr.status) || "";
    var tpl = document.createElement("div");
    tpl.setAttribute("role", "status");
    tpl.setAttribute("data-toast", "");
    tpl.setAttribute("data-dismiss-after", "5000");
    tpl.className = "dg-toast dg-toast-danger px-4 py-3 rounded-lg shadow-popover text-sm bg-panel text-slate-900 border border-border";
    tpl.textContent = "Error " + status;
    region.appendChild(tpl);
    if (window.dispatchEvent) window.dispatchEvent(new CustomEvent("dg:toast"));
  });

  // Cuando un error inyecta el toast vía OOB, `htmx:afterSwap` dispara
  // `toasts.js::scheduleDismiss` automáticamente. Sin OOB (fallback de
  // arriba), también queremos auto-dismiss. `toasts.js` ya escucha
  // `htmx:afterSwap` para los swaps normales; aquí solo replicamos el
  // schedule para el toast inyectado a mano por el fallback.
  document.body && document.body.addEventListener("htmx:responseError", function () {
    var region = document.getElementById("dg-toasts");
    if (!region) return;
    region.querySelectorAll("[data-toast]:not([data-dg-scheduled])").forEach(function (el) {
      el.setAttribute("data-dg-scheduled", "1");
      var ms = parseInt(el.getAttribute("data-dismiss-after") || "5000", 10);
      if (!isFinite(ms) || ms <= 0) return;
      setTimeout(function () {
        el.classList.add("opacity-0");
        setTimeout(function () { el.remove(); }, 200);
      }, ms);
    });
  });
})();
