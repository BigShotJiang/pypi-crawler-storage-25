from __future__ import annotations

import logging
from pathlib import Path

import duckdb

logger = logging.getLogger(__name__)

from episodicdb.analytics import AnalyticsMixin
from episodicdb.temporal import TemporalMixin
from episodicdb.writer import WriterMixin
from episodicdb.schema import (
    CALLED_AT_INDEX_DDL,
    DECISIONS_DDL,
    EPISODES_DDL,
    FACTS_DDL,
    FACTS_KEY_IDX_DDL,
    HNSW_INDEX_DDL,
    SESSIONS_DDL,
    STARTED_AT_INDEX_DDL,
    TOOL_CALLS_DDL,
)

_DEFAULT_DIR = Path.home() / ".episodicdb"


class EpisodicDB(WriterMixin, AnalyticsMixin, TemporalMixin):
    def __init__(self, agent_id: str, path: str | None = None) -> None:
        self.agent_id = agent_id

        if path is None:
            _DEFAULT_DIR.mkdir(parents=True, exist_ok=True)
            resolved = str(_DEFAULT_DIR / f"{agent_id}.db")
        else:
            resolved = path

        try:
            self._conn = duckdb.connect(resolved)
        except Exception as exc:
            from episodicdb import EpisodicDBError
            raise EpisodicDBError(f"Cannot open database: {resolved}") from exc

        self._load_vss()
        self._init_schema()

    def _load_vss(self) -> None:
        try:
            self._conn.execute("LOAD vss")
        except Exception:
            try:
                self._conn.execute("INSTALL vss; LOAD vss")
            except Exception as exc:
                from episodicdb import EpisodicDBError
                raise EpisodicDBError("VSS extension unavailable") from exc

    def _init_schema(self) -> None:
        self._conn.execute(SESSIONS_DDL)
        self._conn.execute(EPISODES_DDL)
        self._conn.execute(TOOL_CALLS_DDL)
        self._conn.execute(DECISIONS_DDL)
        self._conn.execute(FACTS_DDL)
        self._migrate()
        try:
            self._conn.execute("SET hnsw_enable_experimental_persistence = true")
        except Exception:
            logger.warning(
                "hnsw_enable_experimental_persistence not supported; "
                "HNSW index will not persist across restarts"
            )
        self._conn.execute(HNSW_INDEX_DDL)
        self._conn.execute(CALLED_AT_INDEX_DDL)
        self._conn.execute(STARTED_AT_INDEX_DDL)
        self._conn.execute(FACTS_KEY_IDX_DDL)

    def _migrate(self) -> None:
        """Apply forward-only migrations for existing databases."""
        # v0.1.2: add session_id column to episodes (existing DBs lack it)
        cols = {
            row[0]
            for row in self._conn.execute(
                "SELECT column_name FROM information_schema.columns "
                "WHERE table_name = 'episodes'"
            ).fetchall()
        }
        if "session_id" not in cols:
            self._conn.execute(
                "ALTER TABLE episodes ADD COLUMN session_id UUID REFERENCES sessions(id)"
            )

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "EpisodicDB":
        return self

    def __exit__(self, *_) -> None:
        self.close()
