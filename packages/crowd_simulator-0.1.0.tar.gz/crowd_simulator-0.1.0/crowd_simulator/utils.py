def hex_to_rgb(hex: str):
    return int(hex[1:3], 16), int(hex[3:5], 16), int(hex[5:7], 16), 255