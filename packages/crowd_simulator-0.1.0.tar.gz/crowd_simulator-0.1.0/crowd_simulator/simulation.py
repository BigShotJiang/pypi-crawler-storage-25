from pyglet.window import Window
from pyglet import clock
from pyglet.app import run

from pyglet.graphics import Batch

class Simulation(Window):
    def __init__(self, name: str = "Crowd Simulation", width: int = 1280, height: int = 720):
        super().__init__(width, height, name)
        self.batch = Batch()
        self.objects = []
        
    def append_object(self, object) -> bool:
        try:
            object.batch = self.batch
            self.objects.append(object)
            return True
        except Exception as e:
            raise Exception(f"Error in fonction append_object: {e}")
    
    def update(self, dt):
        pass
    
    def on_draw(self):
        self.clear()
        self.batch.draw()
    
    def run(self):
        clock.schedule_interval(self.update, 1/60)
        run()