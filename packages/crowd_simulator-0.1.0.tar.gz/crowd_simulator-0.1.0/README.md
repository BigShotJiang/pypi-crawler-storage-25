# Crowd Simulator

A 2D engine to simulate crowds easily in Python.

## Installation

``` sh
pip install crowd-simulator
```

## To do
- [ ] Create 2D simulation space
- [ ] Create base entity class
- [ ] Create entities with special comportements
- [ ] Create config file system to be able to test comportements easily