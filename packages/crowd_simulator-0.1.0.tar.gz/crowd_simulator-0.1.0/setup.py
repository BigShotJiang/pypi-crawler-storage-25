from setuptools import setup, find_packages

setup(
    name="crowd-simulator",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "pyglet==2.1"
    ],
)