#!/usr/bin/env node
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/llm.ts
var llm_exports = {};
__export(llm_exports, {
  makeLLMProvider: () => makeLLMProvider
});
function makeLLMProvider(name) {
  switch (name) {
    case "anthropic":
      return makeAnthropicProvider();
    case "openai":
      return makeOpenAIProvider();
    case "gemini":
      return makeGeminiProvider();
    case "ollama":
      return makeOllamaProvider();
    default:
      throw new Error(`Unknown LLM provider: ${name}. Options: anthropic|openai|gemini|ollama`);
  }
}
function makeAnthropicProvider() {
  return async (prompt) => {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) throw new Error("ANTHROPIC_API_KEY not set");
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        // cheap, fast — right for extraction
        max_tokens: 4096,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (!res.ok) throw new Error(`Anthropic API error: ${res.status} ${await res.text()}`);
    const data = await res.json();
    return data.content[0].text;
  };
}
function makeOpenAIProvider() {
  return async (prompt) => {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) throw new Error("OPENAI_API_KEY not set");
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 4096
      })
    });
    if (!res.ok) throw new Error(`OpenAI API error: ${res.status} ${await res.text()}`);
    const data = await res.json();
    return data.choices[0].message.content;
  };
}
function makeOllamaProvider() {
  return async (prompt) => {
    const model = process.env.OLLAMA_MODEL ?? "qwen2.5:1.5b";
    const host = process.env.OLLAMA_HOST ?? "http://localhost:11434";
    const res = await fetch(`${host}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        stream: false,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (!res.ok) throw new Error(`Ollama error: ${res.status} ${await res.text()}`);
    const data = await res.json();
    return data.message.content;
  };
}
function makeGeminiProvider() {
  return async (prompt) => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error("GEMINI_API_KEY not set");
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // thinkingBudget: 0 disables thinking mode — extraction is a structured task, not reasoning
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { thinkingConfig: { thinkingBudget: 0 } }
        })
      }
    );
    if (!res.ok) throw new Error(`Gemini API error: ${res.status} ${await res.text()}`);
    const data = await res.json();
    return data.candidates[0].content.parts[0].text;
  };
}
var init_llm = __esm({
  "src/llm.ts"() {
  }
});

// src/format.ts
var format_exports = {};
__export(format_exports, {
  formatDecisionEntry: () => formatDecisionEntry,
  formatDeepADR: () => formatDeepADR,
  formatRejectionEntry: () => formatRejectionEntry,
  slugify: () => slugify
});
function slugify(title) {
  return title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);
}
function formatDecisionEntry(d) {
  const affects = (d.affects ?? []).join(", ") || "\u2014";
  return `## ${d.title ?? "Unnamed"}
**Affects**: ${affects} | **Risk**: ${d.risk ?? "low"}

${d.rationale ?? ""}
`;
}
function formatRejectionEntry(r) {
  return `## ${r.title ?? "Unnamed"} \u2014 rejected
**Replaced by**: _(see decisions)_ | **Reason**: ${r.rejected ?? "\u2014"}

${r.rationale ?? ""}
`;
}
function formatDeepADR(d) {
  const date = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const affects = (d.affects ?? []).join(", ") || "\u2014";
  const risk = d.risk ?? "low";
  return `# ADR: ${d.title ?? "Unnamed"}

**Date**: ${date}
**Status**: Accepted
**Affects**: ${affects}
**Risk**: ${risk}
**Reversibility**: ${risk === "high" ? "low" : risk === "medium" ? "medium" : "high"}

## Decision

${d.rationale ?? "\u2014"}

${d.rejected ? `## Rejected Alternatives

${d.rejected}
` : ""}## Consequences

_To be annotated as consequences become clear._
`;
}
var init_format = __esm({
  "src/format.ts"() {
  }
});

// src/cli.ts
import { Command } from "commander";

// src/commands/init.ts
init_llm();
init_format();
import ora from "ora";
import chalk from "chalk";
import { existsSync } from "fs";
import { join } from "path";
import {
  initStore,
  writeStore,
  appendToStore,
  writeDeepDecision,
  getCommits,
  extractFromCommits,
  createFileCache,
  buildEvolution,
  renderEvolutionMarkdown
} from "@chronicle/core";
async function cmdInit(opts) {
  const cwd = process.cwd();
  const depth = opts.depth;
  const limit = opts.limit ? parseInt(opts.limit, 10) : void 0;
  const concurrency = opts.concurrency ? parseInt(opts.concurrency, 10) : opts.llm === "ollama" ? 1 : 4;
  if (existsSync(join(cwd, ".lore"))) {
    console.log(chalk.yellow("\u26A0  .lore/ already exists. Run `chronicle deepen` to extend the scan."));
    return;
  }
  if (!existsSync(join(cwd, ".git"))) {
    console.error(chalk.red("\u2717  Not a git repository. Run `git init` first."));
    process.exit(1);
  }
  console.log(chalk.bold("\n\u25C6 Chronicle \u2014 initializing\n"));
  initStore(cwd);
  const spinner = ora("Scanning git history...").start();
  const commits = getCommits(cwd, depth, limit);
  spinner.text = `Found ${commits.length} meaningful commits \u2014 extracting decisions...`;
  if (commits.length === 0) {
    spinner.warn("No meaningful commits found in this range. Try --depth=all");
    writeBootstrapPlaceholder(cwd, depth);
    return;
  }
  const llm = makeLLMProvider(opts.llm);
  const cache = createFileCache(cwd);
  let processed = 0;
  let batchCount = 0;
  const results = await extractFromCommits(commits, async (prompt) => {
    const result = await llm(prompt);
    batchCount++;
    spinner.text = `Processing commits... batch ${batchCount}`;
    return result;
  }, { strategy: "simple", cache, concurrency });
  spinner.text = "Writing knowledge base...";
  buildStore(cwd, results);
  spinner.text = "Building evolution record...";
  const eras = buildEvolution(cwd);
  if (eras.length > 0) {
    writeStore(cwd, "evolution", renderEvolutionMarkdown(eras));
  }
  spinner.succeed(chalk.green(`Done! .lore/ initialized from ${commits.length} commits`));
  const decisions = results.filter((r) => r.isDecision);
  const rejections = results.filter((r) => r.isRejection);
  const deep = decisions.filter((r) => r.isDeep);
  console.log(`
  ${chalk.bold("Knowledge base:")}
  ${chalk.cyan(decisions.length)} decisions logged
  ${chalk.red(rejections.length)} rejections captured  ${chalk.dim("\u2190 what was tried & abandoned")}
  ${chalk.yellow(deep.length)} deep ADRs generated

  ${chalk.bold("Next steps:")}
  ${chalk.dim("chronicle inject")}          \u2014 pipe context into your AI tool
  ${chalk.dim("chronicle deepen")}          \u2014 scan further back in history
  ${chalk.dim("chronicle inject | claude")} \u2014 start a Claude session with full context
  `);
}
function buildStore(root, results) {
  const decisions = results.filter((r) => r.isDecision);
  const rejections = results.filter((r) => r.isRejection);
  const tableRows = decisions.map((d) => {
    const title = d.title ?? "Unnamed decision";
    const affects = (d.affects ?? []).join(", ");
    return `| ${title.slice(0, 50)} | ${affects.slice(0, 40)} | ${d.risk ?? "low"} |${d.isDeep ? ` [\u2192](decisions/${slugify(title)}.md)` : ""} |`;
  }).join("\n");
  writeStore(root, "decisions", `# Decision Log

| Decision | Affects | Risk | ADR |
|----------|---------|------|-----|
${tableRows}
`);
  for (const r of rejections) {
    appendToStore(root, "rejected", formatRejectionEntry(r));
  }
  for (const d of decisions.filter((r) => r.isDeep)) {
    const title = d.title ?? "unnamed-decision";
    writeDeepDecision(root, slugify(title), formatDeepADR(d));
  }
}
function writeBootstrapPlaceholder(root, depth) {
  writeStore(root, "decisions", `# Decision Log

_No commits found in depth: ${depth}. Run \`chronicle deepen --depth=all\` to scan full history._
`);
  writeStore(root, "index", `# Project Index

_Generated by Chronicle \u2014 run \`chronicle deepen\` to populate._
`);
}

// src/commands/inject.ts
import { findLoreRoot as findLoreRoot2, readStore, lorePath as lorePath2 } from "@chronicle/core";
import { readFileSync, existsSync as existsSync2, readdirSync } from "fs";
import { join as join2 } from "path";
import chalk2 from "chalk";
async function cmdInject(opts) {
  var _a;
  const root = findLoreRoot2();
  if (!root) {
    process.stderr.write(chalk2.red("\u2717  No .lore/ found. Run `chronicle init` first.\n"));
    process.exit(1);
  }
  const sections = [];
  const index = readStore(root, "index");
  if (index) sections.push(index);
  const decisions = readStore(root, "decisions");
  if (decisions) sections.push(decisions);
  const rejected = readStore(root, "rejected");
  if (rejected) sections.push(rejected);
  const risks = readStore(root, "risks");
  if (risks) {
    const relevant = opts.files ? filterByFiles(risks, opts.files.split(",")) : risks;
    if (relevant) sections.push(relevant);
  }
  if (opts.full) {
    const deepDir = lorePath2(root, "decisions");
    if (existsSync2(deepDir)) {
      for (const file of readdirSync(deepDir).filter((f) => f.endsWith(".md"))) {
        sections.push(readFileSync(join2(deepDir, file), "utf8"));
      }
    }
  } else if (opts.files) {
    sections.push(...getRelevantDeepADRs(root, opts.files.split(",")));
  }
  const evolution = readStore(root, "evolution");
  if (evolution) {
    const compact = (_a = evolution.split("---")[0]) == null ? void 0 : _a.trim();
    if (compact) sections.push(compact);
  }
  const sessionsDir = lorePath2(root, "sessions");
  if (existsSync2(sessionsDir)) {
    const sessions = readdirSync(sessionsDir).filter((f) => f.endsWith(".md")).sort().reverse();
    if (sessions[0]) {
      sections.push(`## Last Session
${readFileSync(join2(sessionsDir, sessions[0]), "utf8")}`);
    }
  }
  const output = formatOutput(sections.join("\n\n---\n\n"), opts.format);
  process.stdout.write(output);
}
function filterByFiles(content, files) {
  return content.split("\n").filter((line) => files.some((f) => line.includes(f)) || line.startsWith("#") || line.startsWith("|")).join("\n");
}
function getRelevantDeepADRs(root, files) {
  const deepDir = lorePath2(root, "decisions");
  if (!existsSync2(deepDir)) return [];
  return readdirSync(deepDir).filter((f) => f.endsWith(".md")).map((f) => readFileSync(join2(deepDir, f), "utf8")).filter((content) => files.some((file) => content.includes(file)));
}
function formatOutput(content, format) {
  switch (format) {
    case "xml":
      return `<chronicle-context>
${content}
</chronicle-context>
`;
    case "plain":
      return content.replace(/[#*`|]/g, "").replace(/\n{3,}/g, "\n\n");
    default:
      return `<!-- chronicle context -->
${content}
<!-- end chronicle context -->
`;
  }
}

// src/commands/deepen.ts
init_llm();
init_format();
import ora2 from "ora";
import chalk3 from "chalk";
import {
  findLoreRoot as findLoreRoot3,
  getCommits as getCommits2,
  extractFromCommits as extractFromCommits2,
  createFileCache as createFileCache2,
  appendToStore as appendToStore2,
  writeDeepDecision as writeDeepDecision2,
  readStore as readStore2
} from "@chronicle/core";
async function cmdDeepen(opts) {
  const root = findLoreRoot3();
  if (!root) {
    console.error(chalk3.red("\u2717  No .lore/ found. Run `chronicle init` first."));
    process.exit(1);
  }
  const depth = opts.depth;
  const limit = opts.limit ? parseInt(opts.limit, 10) : void 0;
  const llmName = opts.llm ?? "anthropic";
  const concurrency = opts.concurrency ? parseInt(opts.concurrency, 10) : llmName === "ollama" ? 1 : 4;
  const spinner = ora2(`Scanning deeper: ${depth}...`).start();
  const cache = createFileCache2(root);
  const commits = getCommits2(root, depth, limit);
  const uncached = commits.filter((c) => !cache.has(c.hash));
  if (uncached.length === 0) {
    spinner.info("No new commits to process at this depth.");
    return;
  }
  spinner.text = `Found ${uncached.length} new commits to process...`;
  const llm = makeLLMProvider(llmName);
  const results = await extractFromCommits2(uncached, llm, { strategy: "simple", cache, concurrency });
  const newDecisions = results.filter((r) => r.isDecision);
  const newRejections = results.filter((r) => r.isRejection);
  for (const r of newRejections) appendToStore2(root, "rejected", formatRejectionEntry(r));
  for (const d of newDecisions.filter((d2) => d2.isDeep)) {
    writeDeepDecision2(root, slugify(d.title ?? "unnamed"), formatDeepADR(d));
  }
  const existing = readStore2(root, "decisions");
  const newRows = newDecisions.map((d) => {
    const title = d.title ?? "Unnamed decision";
    const affects = (d.affects ?? []).join(", ");
    return `| ${title.slice(0, 50)} | ${affects.slice(0, 40)} | ${d.risk ?? "low"} |${d.isDeep ? ` [\u2192](decisions/${slugify(title)}.md)` : ""} |`;
  }).join("\n");
  if (newRows) {
    const insertAfter = "|----------|---------|------|-----|\n";
    appendToStore2(root, "decisions", existing.replace(insertAfter, insertAfter + newRows + "\n"));
  }
  spinner.succeed(chalk3.green(`Deepened: ${newDecisions.length} decisions, ${newRejections.length} rejections added`));
}

// src/commands/hooks.ts
import { execSync } from "child_process";
import { writeFileSync, readFileSync as readFileSync2, existsSync as existsSync3, chmodSync } from "fs";
import { join as join3 } from "path";
import chalk4 from "chalk";
import { findLoreRoot as findLoreRoot4, lorePath as lorePath3 } from "@chronicle/core";
var HOOK_MARKER = "# chronicle-managed";
var POST_COMMIT_HOOK = `#!/bin/sh
${HOOK_MARKER}
chronicle capture --from-commit HEAD &
`;
var PREPARE_COMMIT_MSG_HOOK = `#!/bin/sh
${HOOK_MARKER}
COMMIT_MSG_FILE=$1
COMMIT_SOURCE=$2

# Only enrich manual commits (not merges, squashes, amends)
if [ -z "$COMMIT_SOURCE" ]; then
  chronicle enrich-commit "$COMMIT_MSG_FILE" 2>/dev/null || true
fi
`;
async function cmdHooksInstall() {
  const root = findGitRoot();
  if (!root) {
    console.error(chalk4.red("\u2717  Not a git repository."));
    process.exit(1);
  }
  const hooksDir = join3(root, ".git", "hooks");
  installHook(hooksDir, "post-commit", POST_COMMIT_HOOK);
  installHook(hooksDir, "prepare-commit-msg", PREPARE_COMMIT_MSG_HOOK);
  console.log(chalk4.green("\u2713  Chronicle hooks installed"));
  console.log(chalk4.dim("   post-commit          \u2192 captures decisions after each commit (async)"));
  console.log(chalk4.dim("   prepare-commit-msg   \u2192 enriches commit messages with context"));
  console.log(chalk4.dim("\n   Run `chronicle hooks remove` to uninstall"));
}
async function cmdHooksRemove() {
  const root = findGitRoot();
  if (!root) {
    console.error(chalk4.red("\u2717  Not a git repository."));
    process.exit(1);
  }
  const hooksDir = join3(root, ".git", "hooks");
  for (const name of ["post-commit", "prepare-commit-msg"]) {
    removeChronicleFromHook(join3(hooksDir, name));
  }
  console.log(chalk4.green("\u2713  Chronicle hooks removed"));
}
async function cmdCapture(opts) {
  const root = findLoreRoot4();
  if (!root) return;
  const logFile = lorePath3(root, "capture.log");
  try {
    const { getCommits: getCommits3, extractFromCommits: extractFromCommits3, createFileCache: createFileCache3 } = await import("@chronicle/core");
    const { makeLLMProvider: makeLLMProvider2 } = await Promise.resolve().then(() => (init_llm(), llm_exports));
    const { formatRejectionEntry: formatRejectionEntry2, formatDeepADR: formatDeepADR2, slugify: slugify3 } = await Promise.resolve().then(() => (init_format(), format_exports));
    const { appendToStore: appendToStore4, writeDeepDecision: writeDeepDecision4 } = await import("@chronicle/core");
    const commits = getCommits3(root, "1month").slice(0, 1);
    if (commits.length === 0) return;
    const cache = createFileCache3(root);
    if (cache.has(commits[0].hash)) return;
    const llm = makeLLMProvider2(opts.llm ?? process.env.CHRONICLE_LLM ?? "anthropic");
    const results = await extractFromCommits3(commits, llm, { strategy: "simple", cache });
    for (const r of results.filter((r2) => r2.isRejection)) {
      appendToStore4(root, "rejected", formatRejectionEntry2(r));
    }
    for (const d of results.filter((d2) => d2.isDecision && d2.isDeep)) {
      writeDeepDecision4(root, slugify3(d.title), formatDeepADR2(d));
    }
    for (const d of results.filter((r) => r.isDecision)) {
      const row = `| ${d.title.slice(0, 50)} | ${d.affects.join(", ").slice(0, 40)} | ${d.risk} |${d.isDeep ? ` [\u2192](decisions/${slugify3(d.title)}.md)` : ""} |`;
      appendToStore4(root, "decisions", row);
    }
    appendLog(logFile, `[${(/* @__PURE__ */ new Date()).toISOString()}] captured commit ${commits[0].hash.slice(0, 8)}: ${results.filter((r) => r.isDecision).length} decisions`);
  } catch (err) {
    appendLog(logFile, `[${(/* @__PURE__ */ new Date()).toISOString()}] ERROR: ${err}`);
  }
}
async function cmdEnrichCommit(opts) {
  const root = findLoreRoot4();
  if (!root) return;
  const { readStore: readStore8 } = await import("@chronicle/core");
  const risks = readStore8(root, "risks");
  if (!risks) return;
  const msg = readFileSync2(opts.msgFile, "utf8");
  let staged = [];
  try {
    staged = execSync("git diff --cached --name-only").toString().split("\n").filter(Boolean);
  } catch {
    return;
  }
  const relevantRisks = risks.split("\n").filter((line) => staged.some((f) => line.includes(f))).slice(0, 3);
  if (relevantRisks.length === 0) return;
  const note = `

# Chronicle: high-risk files touched
${relevantRisks.map((r) => `# ${r}`).join("\n")}`;
  writeFileSync(opts.msgFile, msg + note);
}
function findGitRoot(from = process.cwd()) {
  try {
    return execSync("git rev-parse --show-toplevel", { cwd: from }).toString().trim();
  } catch {
    return null;
  }
}
function installHook(hooksDir, name, script) {
  const path = join3(hooksDir, name);
  if (existsSync3(path)) {
    const existing = readFileSync2(path, "utf8");
    if (existing.includes(HOOK_MARKER)) {
      console.log(chalk4.dim(`   ${name}: already installed`));
      return;
    }
    writeFileSync(path, existing.trimEnd() + "\n\n" + script.trim() + "\n");
    console.log(chalk4.cyan(`   ${name}: appended to existing hook`));
  } else {
    writeFileSync(path, script);
    console.log(chalk4.green(`   ${name}: installed`));
  }
  chmodSync(path, "755");
}
function removeChronicleFromHook(hookPath) {
  if (!existsSync3(hookPath)) return;
  const content = readFileSync2(hookPath, "utf8");
  if (!content.includes(HOOK_MARKER)) return;
  const cleaned = content.split("\n").reduce((acc, line) => {
    if (line === HOOK_MARKER) return { out: acc.out, skip: true };
    if (acc.skip && line === "") return { out: acc.out, skip: false };
    if (!acc.skip) acc.out.push(line);
    return acc;
  }, { out: [], skip: false }).out.join("\n");
  if (cleaned.trim() === "#!/bin/sh") {
    execSync(`rm "${hookPath}"`);
  } else {
    writeFileSync(hookPath, cleaned);
  }
}
function appendLog(path, line) {
  const existing = existsSync3(path) ? readFileSync2(path, "utf8") : "";
  writeFileSync(path, existing + line + "\n");
}

// src/commands/setup.ts
import chalk5 from "chalk";
import { findLoreRoot as findLoreRoot5 } from "@chronicle/core";

// src/adapters/index.ts
import { writeFileSync as writeFileSync2, mkdirSync, existsSync as existsSync4, readFileSync as readFileSync3 } from "fs";
import { join as join4 } from "path";
var ADAPTERS = {
  "claude-code": adapterClaudeCode,
  "cursor": adapterCursor,
  "aider": adapterAider,
  "gemini-cli": adapterGeminiCLI,
  "copilot": adapterCopilot,
  "codex": adapterCodex,
  "opencode": adapterOpenCode,
  "trae": adapterGenericPipe("trae"),
  "factory": adapterGenericPipe("factory"),
  "openclaw": adapterClaudeCode
  // same MCP protocol as Claude Code
};
function installAdapter(root, tool) {
  return ADAPTERS[tool](root);
}
var ALL_TOOLS = Object.keys(ADAPTERS);
function adapterClaudeCode(root) {
  var _a;
  const claudeDir = join4(root, ".claude");
  mkdirSync(claudeDir, { recursive: true });
  const mcpPath = join4(claudeDir, "mcp.json");
  const mcp = existsSync4(mcpPath) ? JSON.parse(readFileSync3(mcpPath, "utf8")) : { mcpServers: {} };
  const key = mcp.mcpServers !== void 0 ? "mcpServers" : "servers";
  mcp[key] = mcp[key] ?? {};
  mcp[key].chronicle = { command: "chronicle", args: ["mcp"] };
  writeFileSync2(mcpPath, JSON.stringify(mcp, null, 2));
  const settingsPath = join4(claudeDir, "settings.json");
  const settings = existsSync4(settingsPath) ? JSON.parse(readFileSync3(settingsPath, "utf8")) : {};
  settings.hooks = {
    ...settings.hooks,
    SessionStart: [
      ...((_a = settings.hooks) == null ? void 0 : _a.SessionStart) ?? [],
      { matcher: "", hooks: [{ type: "command", command: "chronicle inject --format=markdown 2>/dev/null || true" }] }
    ]
  };
  writeFileSync2(settingsPath, JSON.stringify(settings, null, 2));
  return {
    tool: "claude-code",
    filesWritten: [mcpPath, settingsPath],
    instructions: `MCP server + hooks installed. Run \`claude mcp list\` to verify chronicle is registered.`
  };
}
function adapterCursor(root) {
  const rulesPath = join4(root, ".cursorrules");
  const context = buildInjectContent(root);
  const content = `# Chronicle \u2014 AI development memory
# Auto-generated by \`chronicle hooks\`. Re-run to refresh.
# Source of truth: .lore/ directory

${context}

---
# Chronicle instructions
When making architectural decisions, note them as:
  DECISION: <what> | BECAUSE: <why> | AFFECTS: <files>
When abandoning an approach, note:
  REJECTED: <what> | REASON: <why>
`;
  writeFileSync2(rulesPath, content);
  return {
    tool: "cursor",
    filesWritten: [rulesPath],
    instructions: `.cursorrules written with current Chronicle context.
Re-run \`chronicle hooks install --tool=cursor\` to keep it fresh, or add to post-commit hook.`
  };
}
function adapterAider(root) {
  const confPath = join4(root, ".aider.conf.yml");
  const existing = existsSync4(confPath) ? readFileSync3(confPath, "utf8") : "";
  const MARKER = "# chronicle-managed";
  if (!existing.includes(MARKER)) {
    const addition = `
${MARKER}
# Chronicle context files (AI development memory)
read:
  - .lore/index.md
  - .lore/decisions.md
  - .lore/rejected.md
`;
    writeFileSync2(confPath, existing + addition);
  }
  return {
    tool: "aider",
    filesWritten: [confPath],
    instructions: `.aider.conf.yml updated.
Aider will automatically read .lore/ context files on every session.`
  };
}
function adapterGeminiCLI(root) {
  const geminiPath = join4(root, "GEMINI.md");
  const context = buildInjectContent(root);
  writeFileSync2(geminiPath, `# Project Context (Chronicle)

${context}
`);
  return {
    tool: "gemini-cli",
    filesWritten: [geminiPath],
    instructions: `GEMINI.md written. Gemini CLI loads this automatically as project context.`
  };
}
function adapterCopilot(root) {
  const githubDir = join4(root, ".github");
  mkdirSync(githubDir, { recursive: true });
  const instrPath = join4(githubDir, "copilot-instructions.md");
  const context = buildInjectContent(root);
  writeFileSync2(instrPath, `# Copilot Instructions (Chronicle)

${context}
`);
  return {
    tool: "copilot",
    filesWritten: [instrPath],
    instructions: `.github/copilot-instructions.md written. Copilot reads this as workspace context.`
  };
}
function adapterCodex(root) {
  const instrPath = join4(root, "AGENTS.md");
  const context = buildInjectContent(root);
  const content = existsSync4(instrPath) ? readFileSync3(instrPath, "utf8") : "";
  if (!content.includes("Chronicle")) {
    writeFileSync2(instrPath, content + `

## Chronicle Context

${context}
`);
  }
  return {
    tool: "codex",
    filesWritten: [instrPath],
    instructions: `AGENTS.md updated with Chronicle context.
Or pipe directly: chronicle inject | codex`
  };
}
function adapterOpenCode(root) {
  const confPath = join4(root, ".opencode.json");
  const conf = existsSync4(confPath) ? JSON.parse(readFileSync3(confPath, "utf8")) : {};
  conf.contextFiles = [
    ...conf.contextFiles ?? [],
    ".lore/index.md",
    ".lore/decisions.md",
    ".lore/rejected.md"
  ].filter((v, i, a) => a.indexOf(v) === i);
  writeFileSync2(confPath, JSON.stringify(conf, null, 2));
  return {
    tool: "opencode",
    filesWritten: [confPath],
    instructions: `.opencode.json updated with Chronicle context files.`
  };
}
function adapterGenericPipe(tool) {
  return (root) => ({
    tool,
    filesWritten: [],
    instructions: `${tool} uses the universal pipe interface:
  chronicle inject | ${tool} "<your prompt>"`
  });
}
function buildInjectContent(root) {
  const { readStore: readStore8, lorePath: lorePath12 } = __require("@chronicle/core");
  const parts = [];
  const index = readStore8(root, "index");
  if (index) parts.push(index);
  parts.push(readStore8(root, "decisions"));
  parts.push(readStore8(root, "rejected"));
  return parts.filter(Boolean).join("\n\n---\n\n");
}

// src/commands/setup.ts
async function cmdSetup(opts) {
  const root = findLoreRoot5();
  if (!root) {
    console.error(chalk5.red("\u2717  No .lore/ found. Run `chronicle init` first."));
    process.exit(1);
  }
  const tools = opts.all ? ALL_TOOLS : opts.tool ? [opts.tool] : [];
  if (tools.length === 0) {
    console.log(chalk5.bold("\nAvailable tool integrations:\n"));
    for (const t of ALL_TOOLS) {
      console.log(`  ${chalk5.cyan(t.padEnd(14))} chronicle setup --tool=${t}`);
    }
    console.log(`
  ${chalk5.dim("or")} chronicle setup --all   ${chalk5.dim("install all")}`);
    return;
  }
  for (const tool of tools) {
    if (!ALL_TOOLS.includes(tool)) {
      console.error(chalk5.red(`\u2717  Unknown tool: ${tool}. Run \`chronicle setup\` to see options.`));
      process.exit(1);
    }
    const result = installAdapter(root, tool);
    console.log(chalk5.green(`\u2713  ${tool}`));
    if (result.filesWritten.length) {
      for (const f of result.filesWritten) {
        console.log(chalk5.dim(`   ${f.replace(root + "/", "")}`));
      }
    }
    console.log(chalk5.dim(`   ${result.instructions.split("\n")[0]}`));
  }
}

// src/commands/diagram.ts
import chalk6 from "chalk";
import { execSync as execSync2 } from "child_process";
import { writeFileSync as writeFileSync3, readdirSync as readdirSync2, readFileSync as readFileSync4 } from "fs";
import { join as join5 } from "path";
import { findLoreRoot as findLoreRoot6, lorePath as lorePath4, readStore as readStore3 } from "@chronicle/core";
async function cmdDiagram(opts) {
  const root = findLoreRoot6();
  if (!root) {
    console.error(chalk6.red("\u2717  No .lore/ found. Run `chronicle init` first."));
    process.exit(1);
  }
  const types = opts.type ? [opts.type] : ["architecture", "dependencies", "evolution"];
  for (const type of types) {
    switch (type) {
      case "architecture":
        generateArchitecture(root);
        break;
      case "dependencies":
        generateDependencies(root);
        break;
      case "evolution":
        generateEvolution(root);
        break;
      default:
        console.error(chalk6.red(`\u2717  Unknown diagram type: ${type}. Options: architecture|dependencies|evolution`));
    }
  }
}
function generateArchitecture(root) {
  const decisions = readStore3(root, "decisions");
  const pairs = extractModulesFromDecisions(decisions);
  const allModules = [...new Set(pairs.flat())].filter((m) => m.length > 1);
  if (allModules.length === 0) {
    writeDiagram(root, "architecture", box("Architecture", "(no decisions logged yet \u2014 run `chronicle init`)"));
    console.log(chalk6.green("\u2713  .lore/diagrams/architecture.txt"));
    return;
  }
  const lines = [
    "\u250C\u2500 Architecture \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510",
    "\u2502  Modules referenced in decision log                   \u2502",
    "\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518",
    ""
  ];
  const groups = /* @__PURE__ */ new Map();
  for (const m of allModules) {
    const group = m.includes("/") ? m.split("/")[0] : "root";
    groups.set(group, [...groups.get(group) ?? [], m]);
  }
  for (const [group, members] of groups) {
    lines.push(`  [ ${group} ]`);
    for (const m of members) lines.push(`    \u251C\u2500\u2500 ${m}`);
    lines.push("");
  }
  if (pairs.length) {
    lines.push("  Relationships (from decisions):");
    for (const [a, b] of pairs.slice(0, 15)) {
      lines.push(`    ${a.padEnd(30)} \u2500\u2500\u2192  ${b}`);
    }
  }
  writeDiagram(root, "architecture", lines.join("\n"));
  console.log(chalk6.green("\u2713  .lore/diagrams/architecture.txt"));
}
function generateDependencies(root) {
  const imports = collectImports(root);
  if (imports.size === 0) {
    console.log(chalk6.yellow("\u26A0  No source files found for dependency analysis"));
    return;
  }
  const dependentCount = /* @__PURE__ */ new Map();
  for (const deps of imports.values()) {
    for (const d of deps) dependentCount.set(d, (dependentCount.get(d) ?? 0) + 1);
  }
  const sorted = [...imports.entries()].sort(([, a], [, b]) => b.length - a.length);
  const lines = [
    "\u250C\u2500 Dependency Map \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510",
    "\u2502  [!] = high blast radius (\u22653 dependents)              \u2502",
    "\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518",
    ""
  ];
  for (const [file, deps] of sorted.slice(0, 20)) {
    const count = dependentCount.get(file) ?? 0;
    const risk = count >= 3 ? " [!]" : "";
    lines.push(`  ${file}${risk}`);
    for (const dep of deps.slice(0, 5)) {
      lines.push(`    \u2514\u2500\u2500 imports: ${dep}`);
    }
    if (deps.length > 5) lines.push(`    \u2514\u2500\u2500 ... +${deps.length - 5} more`);
    lines.push("");
  }
  if (imports.size > 20) lines.push(`  ... and ${imports.size - 20} more files`);
  const highRisk = [...dependentCount.entries()].filter(([, c]) => c >= 3);
  if (highRisk.length) {
    lines.push("", "  High blast-radius files:");
    for (const [f, c] of highRisk.sort(([, a], [, b]) => b - a)) {
      lines.push(`    ${f.padEnd(40)} \u2190 imported by ${c} files`);
    }
  }
  writeDiagram(root, "dependencies", lines.join("\n"));
  console.log(chalk6.green("\u2713  .lore/diagrams/dependencies.txt"));
  if (highRisk.length) console.log(chalk6.dim(`   ${highRisk.length} high-risk files detected`));
}
function generateEvolution(root) {
  const entries = collectEvolutionEntries(root);
  if (entries.length === 0) {
    console.log(chalk6.yellow("\u26A0  No git tags or dated decisions found"));
    return;
  }
  const lines = [
    "\u250C\u2500 Evolution Timeline \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2510",
    "\u2502  Derived from git tags + decision log                 \u2502",
    "\u2514\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2518",
    "",
    "  DATE         EVENT",
    "  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"
  ];
  let prevYear = "";
  for (const e of entries) {
    const year = e.date.slice(0, 4);
    if (year !== prevYear) {
      lines.push(``, `  \u2500\u2500 ${year} ${"\u2500".repeat(45)}`);
      prevYear = year;
    }
    const marker = e.isRelease ? "\u25C6" : "\xB7";
    lines.push(`  ${e.date}  ${marker}  ${e.label}`);
  }
  writeDiagram(root, "evolution", lines.join("\n"));
  console.log(chalk6.green("\u2713  .lore/diagrams/evolution.txt"));
}
function writeDiagram(root, name, content) {
  const dir = lorePath4(root, "diagrams");
  writeFileSync3(join5(dir, `${name}.txt`), content);
}
function box(title, content) {
  const width = Math.max(title.length, content.length) + 4;
  const border = "\u2500".repeat(width);
  return `\u250C${border}\u2510
\u2502  ${title.padEnd(width - 2)}\u2502
\u2502  ${content.padEnd(width - 2)}\u2502
\u2514${border}\u2518`;
}
function extractModulesFromDecisions(decisions) {
  const affectsPattern = /\|\s*([^|]+?)\s*\|/g;
  const result = [];
  let match;
  while ((match = affectsPattern.exec(decisions)) !== null) {
    const modules = match[1].split(",").map((s) => s.trim()).filter(Boolean);
    if (modules.length >= 2) result.push(modules.slice(0, 2));
  }
  return result;
}
function collectImports(root) {
  const map = /* @__PURE__ */ new Map();
  const extensions = [".ts", ".tsx", ".js", ".jsx", ".py"];
  function walk(dir, depth = 0) {
    if (depth > 4) return;
    const skip = ["node_modules", ".git", "dist", ".lore", "__pycache__", ".venv"];
    let entries = [];
    try {
      entries = readdirSync2(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (skip.includes(entry.name)) continue;
      const full = join5(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full, depth + 1);
        continue;
      }
      if (!extensions.some((e) => entry.name.endsWith(e))) continue;
      const content = readFileSync4(full, "utf8");
      const shortName = full.replace(root + "/", "");
      const deps = extractImportPaths(content, shortName);
      if (deps.length) map.set(shortName, deps);
    }
  }
  walk(root);
  return map;
}
function extractImportPaths(content, fromFile) {
  const importRe = /(?:import|from)\s+['"]([^'"]+)['"]/g;
  const deps = [];
  let m;
  while ((m = importRe.exec(content)) !== null) {
    const path = m[1];
    if (path.startsWith(".")) {
      deps.push(path.replace(/^\.\.?\//, "").replace(/\.(ts|js|tsx|jsx)$/, ""));
    }
  }
  return deps;
}
function collectEvolutionEntries(root) {
  const entries = [];
  try {
    const tags = execSync2(`git -C "${root}" tag -l --sort=version:refname --format="%(refname:short)|%(creatordate:short)"`).toString().split("\n").filter(Boolean);
    for (const tag of tags) {
      const [name, date] = tag.split("|");
      if (date) entries.push({ date: date.slice(0, 10), label: `Release ${name}`, isRelease: true });
    }
  } catch {
  }
  const decisions = readStore3(root, "decisions");
  const dateRe = /\|\s*(\d{4}-\d{2}-\d{2})\s*\|([^|]+)\|/g;
  let m;
  while ((m = dateRe.exec(decisions)) !== null) {
    entries.push({ date: m[1], label: m[2].trim().slice(0, 50), isRelease: false });
  }
  return entries.sort((a, b) => a.date.localeCompare(b.date));
}

// src/commands/evolution.ts
import chalk7 from "chalk";
import ora3 from "ora";
import { readFileSync as readFileSync5, existsSync as existsSync6 } from "fs";
import { findLoreRoot as findLoreRoot7, writeStore as writeStore2, buildEvolution as buildEvolution2, renderEvolutionMarkdown as renderEvolutionMarkdown2, mergeWithExisting } from "@chronicle/core";
import { execSync as execSync3 } from "child_process";
async function cmdEvolution(opts) {
  const root = findLoreRoot7();
  if (!root) {
    console.error(chalk7.red("\u2717  No .lore/ found. Run `chronicle init` first."));
    process.exit(1);
  }
  const evolutionPath = root + "/.lore/evolution.md";
  const hasExisting = existsSync6(evolutionPath);
  if (opts.view && hasExisting) {
    process.stdout.write(readFileSync5(evolutionPath, "utf8"));
    return;
  }
  if (hasExisting && !opts.regen) {
    console.log(chalk7.dim("evolution.md already exists. Use --regen to rebuild it."));
    console.log(chalk7.dim("Use --view to print the current evolution record."));
    return;
  }
  const spinner = ora3("Building evolution record from git history...").start();
  const eras = buildEvolution2(root);
  if (eras.length === 0) {
    spinner.warn("No git tags found. Tag a release first: git tag v0.1.0");
    writeStore2(
      root,
      "evolution",
      "# System Evolution\n\n_No releases tagged yet. Run `git tag v0.1.0` to create your first era._\n"
    );
    return;
  }
  spinner.text = `Found ${eras.length} era${eras.length === 1 ? "" : "s"} \u2014 writing evolution.md...`;
  const projectName = detectProjectName(root);
  const newMd = renderEvolutionMarkdown2(eras, projectName);
  const finalMd = hasExisting ? mergeWithExisting(newMd, readFileSync5(evolutionPath, "utf8")) : newMd;
  writeStore2(root, "evolution", finalMd);
  spinner.succeed(chalk7.green(`evolution.md written \u2014 ${eras.length} era${eras.length === 1 ? "" : "s"}`));
  for (const era of eras) {
    const label = era.tag === "HEAD (current)" ? chalk7.cyan(era.tag) : chalk7.bold(era.tag);
    const period = `${era.fromDate.slice(0, 10)} \u2192 ${era.toDate === "present" ? chalk7.green("present") : era.toDate.slice(0, 10)}`;
    const counts = [
      era.decisions.length ? `${era.decisions.length} decisions` : "",
      era.rejections.length ? `${era.rejections.length} rejections` : ""
    ].filter(Boolean).join(", ");
    console.log(`  ${label.padEnd(30)} ${chalk7.dim(period)}  ${chalk7.dim(counts)}`);
  }
  console.log(chalk7.dim("\n  chronicle evolution --view   \u2014 print full record"));
}
function detectProjectName(root) {
  const pkgPath = root + "/package.json";
  if (existsSync6(pkgPath)) {
    try {
      const pkg = JSON.parse(readFileSync5(pkgPath, "utf8"));
      if (pkg.name) return pkg.name;
    } catch {
    }
  }
  try {
    const remote = execSync3(`git -C "${root}" remote get-url origin`, { stdio: ["pipe", "pipe", "ignore"] }).toString().trim();
    const match = remote.match(/\/([^/]+?)(?:\.git)?$/);
    if (match) return match[1];
  } catch {
  }
  return "Project";
}

// src/commands/doctor.ts
import chalk8 from "chalk";
import { existsSync as existsSync7, readFileSync as readFileSync6, readdirSync as readdirSync3, statSync } from "fs";
import { join as join6 } from "path";
import { findLoreRoot as findLoreRoot8, lorePath as lorePath6, STORE_FILES } from "@chronicle/core";
import { execSync as execSync4 } from "child_process";
async function cmdDoctor() {
  const root = findLoreRoot8();
  const checks = [];
  const isGit = existsSync7(join6(process.cwd(), ".git")) || (() => {
    try {
      execSync4("git rev-parse --git-dir", { stdio: "pipe" });
      return true;
    } catch {
      return false;
    }
  })();
  checks.push({ label: "Git repository", status: isGit ? "ok" : "error", detail: isGit ? void 0 : "Not inside a git repo" });
  if (!root) {
    checks.push({ label: ".lore/ exists", status: "error", detail: "Run `chronicle init` first" });
    printReport(checks);
    process.exit(1);
  }
  checks.push({ label: ".lore/ exists", status: "ok", detail: `${lorePath6(root)}` });
  for (const [key, file] of Object.entries(STORE_FILES)) {
    const path = lorePath6(root, file);
    if (!existsSync7(path)) {
      checks.push({ label: `${file}`, status: "warn", detail: "Missing \u2014 run `chronicle init`" });
    } else {
      const size = statSync(path).size;
      checks.push({ label: `${file}`, status: size > 50 ? "ok" : "warn", detail: `${(size / 1024).toFixed(1)} KB` });
    }
  }
  const decisionsFile = lorePath6(root, STORE_FILES.decisions);
  if (existsSync7(decisionsFile)) {
    const content = readFileSync6(decisionsFile, "utf8");
    const linkPattern = /\[→\]\(decisions\/([^)]+)\)/g;
    const adrDir2 = lorePath6(root, "decisions");
    let broken = 0;
    for (const match of content.matchAll(linkPattern)) {
      const adrPath = join6(adrDir2, match[1]);
      if (!existsSync7(adrPath)) broken++;
    }
    checks.push({
      label: "ADR link integrity",
      status: broken === 0 ? "ok" : "warn",
      detail: broken === 0 ? "All ADR links valid" : `${broken} broken link(s)`
    });
  }
  const cachePath = lorePath6(root, ".cache.json");
  const hasCache = existsSync7(cachePath);
  if (hasCache) {
    try {
      const cache = JSON.parse(readFileSync6(cachePath, "utf8"));
      const count = Object.keys(cache).length;
      checks.push({ label: "Extraction cache", status: "ok", detail: `${count} commits cached` });
    } catch {
      checks.push({ label: "Extraction cache", status: "warn", detail: "Cache file is corrupt" });
    }
  } else {
    checks.push({ label: "Extraction cache", status: "warn", detail: "No cache \u2014 re-runs will reprocess all commits" });
  }
  const hooksDir = join6(root, ".git", "hooks");
  const postCommit = join6(hooksDir, "post-commit");
  const hasHook = existsSync7(postCommit) && readFileSync6(postCommit, "utf8").includes("chronicle");
  checks.push({
    label: "Git hooks",
    status: hasHook ? "ok" : "warn",
    detail: hasHook ? "post-commit hook installed" : "Not installed \u2014 run `chronicle hooks install`"
  });
  const adrDir = lorePath6(root, "decisions");
  const adrCount = existsSync7(adrDir) ? readdirSync3(adrDir).filter((f) => f.endsWith(".md")).length : 0;
  checks.push({ label: "Deep ADRs", status: "ok", detail: `${adrCount} files in decisions/` });
  printReport(checks);
  const errors = checks.filter((c) => c.status === "error").length;
  const warnings = checks.filter((c) => c.status === "warn").length;
  if (errors > 0) {
    console.log(chalk8.red(`
${errors} error(s) found. Fix them to use Chronicle properly.`));
    process.exit(1);
  } else if (warnings > 0) {
    console.log(chalk8.yellow(`
${warnings} warning(s). Everything works but consider addressing them.`));
  } else {
    console.log(chalk8.green("\n\u2713 Everything looks healthy!"));
  }
}
function printReport(checks) {
  console.log(chalk8.bold("\n\u25C6 Chronicle Doctor\n"));
  for (const c of checks) {
    const icon = c.status === "ok" ? chalk8.green("\u2713") : c.status === "warn" ? chalk8.yellow("\u26A0") : chalk8.red("\u2717");
    const label = chalk8.bold(c.label.padEnd(26));
    const detail = c.detail ? chalk8.dim(c.detail) : "";
    console.log(`  ${icon}  ${label} ${detail}`);
  }
}

// src/commands/search.ts
import chalk9 from "chalk";
import { existsSync as existsSync8, readFileSync as readFileSync7, readdirSync as readdirSync4 } from "fs";
import { join as join7 } from "path";
import { findLoreRoot as findLoreRoot9, lorePath as lorePath7 } from "@chronicle/core";
async function cmdSearch(query, opts) {
  var _a, _b;
  const root = findLoreRoot9();
  if (!root) {
    process.stderr.write(chalk9.red("\u2717  No .lore/ found. Run `chronicle init` first.\n"));
    process.exit(1);
  }
  if (!(query == null ? void 0 : query.trim())) {
    process.stderr.write(chalk9.red("\u2717  Please provide a search query.\n"));
    process.exit(1);
  }
  const limit = opts.limit ? parseInt(opts.limit, 10) : 20;
  const loreDir = lorePath7(root);
  const pattern = new RegExp(query, "gi");
  const results = [];
  for (const file of walkMarkdown(loreDir)) {
    const content = readFileSync7(file, "utf8");
    const lines = content.split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (pattern.test(lines[i])) {
        results.push({
          file: file.replace(loreDir + "/", ""),
          line: i + 1,
          text: lines[i].trim(),
          // context: one line before and after
          context: [
            (_a = lines[i - 1]) == null ? void 0 : _a.trim(),
            (_b = lines[i + 1]) == null ? void 0 : _b.trim()
          ].filter(Boolean)
        });
        if (results.length >= limit) break;
      }
      pattern.lastIndex = 0;
    }
    if (results.length >= limit) break;
  }
  if (opts.json) {
    process.stdout.write(JSON.stringify(results, null, 2));
    return;
  }
  if (results.length === 0) {
    console.log(chalk9.yellow(`No results for "${query}"`));
    return;
  }
  console.log(chalk9.bold(`
\u25C6 Search: "${query}" \u2014 ${results.length} result(s)
`));
  const byFile = /* @__PURE__ */ new Map();
  for (const r of results) {
    const list = byFile.get(r.file) ?? [];
    list.push(r);
    byFile.set(r.file, list);
  }
  for (const [file, matches] of byFile) {
    console.log(chalk9.cyan(`  ${file}`));
    for (const m of matches) {
      const highlighted = m.text.replace(new RegExp(query, "gi"), (s) => chalk9.yellow(s));
      console.log(`    ${chalk9.dim(`L${m.line}:`)} ${highlighted}`);
      for (const ctx of m.context) {
        console.log(`         ${chalk9.dim(ctx.slice(0, 80))}`);
      }
    }
    console.log();
  }
  if (results.length >= limit) {
    console.log(chalk9.dim(`  (showing first ${limit} results \u2014 use --limit to see more)`));
  }
}
function walkMarkdown(dir) {
  if (!existsSync8(dir)) return [];
  const files = [];
  for (const entry of readdirSync4(dir, { withFileTypes: true })) {
    const full = join7(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...walkMarkdown(full));
    } else if (entry.name.endsWith(".md")) {
      files.push(full);
    }
  }
  return files;
}

// src/commands/serve.ts
import chalk10 from "chalk";
import { createServer } from "http";
import { existsSync as existsSync9, readFileSync as readFileSync8, readdirSync as readdirSync5 } from "fs";
import { join as join8 } from "path";
import { findLoreRoot as findLoreRoot10, lorePath as lorePath8, readStore as readStore5 } from "@chronicle/core";
async function cmdServe(opts) {
  const root = findLoreRoot10();
  if (!root) {
    console.error(chalk10.red("\u2717  No .lore/ found. Run `chronicle init` first."));
    process.exit(1);
  }
  const port = parseInt(opts.port ?? "4242", 10);
  const loreDir = lorePath8(root);
  const server = createServer((req, res) => {
    const url = req.url ?? "/";
    if (url === "/" || url === "/index.html") {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(renderIndex(root, loreDir));
      return;
    }
    if (url.startsWith("/file/")) {
      const rel = decodeURIComponent(url.slice(6));
      const full = join8(loreDir, rel);
      if (!full.startsWith(loreDir) || !existsSync9(full)) {
        res.writeHead(404);
        res.end("Not found");
        return;
      }
      const content = readFileSync8(full, "utf8");
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(renderFile(rel, content));
      return;
    }
    if (url === "/api/search") {
      const q = new URL(url, `http://localhost`).searchParams.get("q") ?? "";
      const results = searchLore(loreDir, q, 50);
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(results));
      return;
    }
    res.writeHead(404);
    res.end("Not found");
  });
  server.listen(port, () => {
    console.log(chalk10.bold(`
\u25C6 Chronicle Viewer
`));
    console.log(`  ${chalk10.cyan(`http://localhost:${port}`)}  \u2014 press Ctrl+C to stop
`);
    try {
      const { execSync: execSync5 } = __require("child_process");
      const open = process.platform === "darwin" ? "open" : process.platform === "win32" ? "start" : "xdg-open";
      execSync5(`${open} http://localhost:${port}`, { stdio: "ignore" });
    } catch {
    }
  });
}
function renderIndex(root, loreDir) {
  const decisions = readStore5(root, "decisions");
  const rejected = readStore5(root, "rejected");
  const evolution = readStore5(root, "evolution");
  const adrDir = join8(loreDir, "decisions");
  const adrs = existsSync9(adrDir) ? readdirSync5(adrDir).filter((f) => f.endsWith(".md")).map((f) => ({
    name: f.replace(/-/g, " ").replace(".md", ""),
    file: `decisions/${f}`
  })) : [];
  return html(`Chronicle \u2014 ${root.split("/").pop()}`, `
    <div class="sidebar">
      <h2>\u{1F4DA} Knowledge Base</h2>
      <nav>
        <a href="/file/decisions.md">Decision Log</a>
        <a href="/file/rejected.md">Rejected Ideas</a>
        <a href="/file/evolution.md">System Evolution</a>
        ${adrs.length ? `<hr><small>Deep ADRs (${adrs.length})</small>` : ""}
        ${adrs.map((a) => `<a href="/file/${encodeURIComponent(a.file)}">${a.name}</a>`).join("\n")}
      </nav>
    </div>
    <div class="main">
      <div class="search-bar">
        <input id="q" type="text" placeholder="Search .lore/\u2026" oninput="search(this.value)" />
        <div id="results"></div>
      </div>
      <div class="content">
        ${mdToHtml(decisions)}
      </div>
    </div>
    <script>
      let timer;
      function search(q) {
        clearTimeout(timer);
        if (!q.trim()) { document.getElementById('results').innerHTML = ''; return; }
        timer = setTimeout(async () => {
          const r = await fetch('/api/search?q=' + encodeURIComponent(q)).then(r => r.json());
          const el = document.getElementById('results');
          if (!r.length) { el.innerHTML = '<div class="no-results">No results</div>'; return; }
          el.innerHTML = r.map(x =>
            '<div class="result"><span class="file">' + x.file + ':' + x.line + '</span> ' +
            x.text.replace(new RegExp(q, 'gi'), m => '<mark>' + m + '</mark>') + '</div>'
          ).join('');
        }, 200);
      }
    </script>
  `);
}
function renderFile(rel, content) {
  return html(rel, `
    <div class="sidebar">
      <h2>\u{1F4DA} Chronicle</h2>
      <nav>
        <a href="/">\u2190 Overview</a>
        <a href="/file/decisions.md">Decision Log</a>
        <a href="/file/rejected.md">Rejected Ideas</a>
        <a href="/file/evolution.md">System Evolution</a>
      </nav>
    </div>
    <div class="main"><div class="content">${mdToHtml(content)}</div></div>
  `);
}
function html(title, body) {
  return `<!DOCTYPE html><html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0 }
  body { font: 15px/1.6 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
         background: #0d1117; color: #c9d1d9; display: flex; height: 100vh; overflow: hidden }
  .sidebar { width: 220px; min-width: 220px; background: #161b22; border-right: 1px solid #30363d;
             padding: 20px 12px; overflow-y: auto; flex-shrink: 0 }
  .sidebar h2 { font-size: 13px; color: #8b949e; text-transform: uppercase; letter-spacing: .08em;
                margin-bottom: 12px }
  .sidebar nav { display: flex; flex-direction: column; gap: 2px }
  .sidebar nav a { color: #58a6ff; text-decoration: none; font-size: 13px;
                    padding: 4px 8px; border-radius: 4px; white-space: nowrap; overflow: hidden;
                    text-overflow: ellipsis }
  .sidebar nav a:hover { background: #21262d }
  .sidebar hr { border: none; border-top: 1px solid #30363d; margin: 10px 0 }
  .sidebar small { color: #8b949e; font-size: 11px; padding: 0 8px }
  .main { flex: 1; overflow-y: auto; padding: 0 }
  .search-bar { position: sticky; top: 0; background: #0d1117; padding: 16px 24px;
                border-bottom: 1px solid #30363d; z-index: 10 }
  #q { width: 100%; background: #161b22; border: 1px solid #30363d; color: #c9d1d9;
       padding: 8px 12px; border-radius: 6px; font-size: 14px; outline: none }
  #q:focus { border-color: #58a6ff }
  #results { margin-top: 8px }
  .result { font-size: 13px; padding: 4px 0; border-bottom: 1px solid #21262d }
  .result .file { color: #8b949e; margin-right: 8px; font-family: monospace }
  .result mark { background: #2d4a22; color: #f0c05a; border-radius: 2px; padding: 0 2px }
  .no-results { color: #8b949e; font-size: 13px }
  .content { padding: 24px; max-width: 860px }
  .content h1 { font-size: 22px; border-bottom: 1px solid #30363d; padding-bottom: 8px; margin-bottom: 16px; color: #e6edf3 }
  .content h2 { font-size: 17px; margin: 24px 0 8px; color: #e6edf3 }
  .content h3 { font-size: 14px; margin: 16px 0 6px; color: #e6edf3 }
  .content p { margin-bottom: 12px; color: #c9d1d9 }
  .content table { border-collapse: collapse; width: 100%; margin-bottom: 16px; font-size: 13px }
  .content th, .content td { border: 1px solid #30363d; padding: 6px 10px; text-align: left }
  .content th { background: #161b22; color: #8b949e; font-weight: 600 }
  .content tr:hover td { background: #161b22 }
  .content code { background: #161b22; padding: 2px 6px; border-radius: 4px; font-size: 12px;
                  font-family: 'SF Mono', Consolas, monospace; color: #f85149 }
  .content pre { background: #161b22; border: 1px solid #30363d; border-radius: 6px;
                 padding: 14px; overflow-x: auto; margin-bottom: 16px }
  .content pre code { background: none; padding: 0; color: #c9d1d9 }
  .content a { color: #58a6ff; text-decoration: none }
  .content a:hover { text-decoration: underline }
  .content hr { border: none; border-top: 1px solid #30363d; margin: 20px 0 }
  .content ul, .content ol { padding-left: 20px; margin-bottom: 12px }
  .content li { margin-bottom: 4px }
  strong { color: #e6edf3 }
  em { color: #a5d6ff }
</style>
</head><body>${body}</body></html>`;
}
function mdToHtml(md) {
  if (!md) return "<p><em>No content yet.</em></p>";
  return md.replace(/```[\s\S]*?```/g, (m) => `<pre><code>${escHtml(m.slice(3, -3).replace(/^\w+\n/, ""))}</code></pre>`).replace(/^### (.+)$/gm, "<h3>$1</h3>").replace(/^## (.+)$/gm, "<h2>$1</h2>").replace(/^# (.+)$/gm, "<h1>$1</h1>").replace(/^---$/gm, "<hr>").replace(/((?:\|.+\|\n?)+)/g, (block) => {
    const rows = block.trim().split("\n").filter((r) => !/^\|[-:| ]+\|$/.test(r));
    if (rows.length === 0) return block;
    const [head, ...body] = rows;
    const th = head.split("|").filter(Boolean).map((c) => `<th>${c.trim()}</th>`).join("");
    const td = body.map((r) => "<tr>" + r.split("|").filter(Boolean).map((c) => `<td>${renderInline(c.trim())}</td>`).join("") + "</tr>").join("");
    return `<table><thead><tr>${th}</tr></thead><tbody>${td}</tbody></table>`;
  }).replace(/^[-*] (.+)$/gm, "<li>$1</li>").replace(/(<li>.*<\/li>\n?)+/g, (m) => `<ul>${m}</ul>`).split("\n").map((line) => {
    if (/^<(h[1-6]|ul|ol|li|pre|table|hr)/.test(line)) return line;
    return line.trim() ? `<p>${renderInline(line)}</p>` : "";
  }).join("\n");
}
function renderInline(text) {
  return text.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/\*(.+?)\*/g, "<em>$1</em>").replace(/`(.+?)`/g, "<code>$1</code>").replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
}
function escHtml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function searchLore(loreDir, query, limit) {
  if (!query.trim()) return [];
  const pattern = new RegExp(query, "gi");
  const results = [];
  function walk(dir) {
    if (!existsSync9(dir)) return;
    for (const entry of readdirSync5(dir, { withFileTypes: true })) {
      if (results.length >= limit) return;
      const full = join8(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full);
        continue;
      }
      if (!entry.name.endsWith(".md")) continue;
      const lines = readFileSync8(full, "utf8").split("\n");
      for (let i = 0; i < lines.length && results.length < limit; i++) {
        pattern.lastIndex = 0;
        if (pattern.test(lines[i])) {
          results.push({ file: full.replace(loreDir + "/", ""), line: i + 1, text: lines[i].trim() });
        }
      }
    }
  }
  walk(loreDir);
  return results;
}

// src/commands/session.ts
import chalk11 from "chalk";
import { existsSync as existsSync10, readFileSync as readFileSync9, readdirSync as readdirSync6, writeFileSync as writeFileSync4, mkdirSync as mkdirSync2 } from "fs";
import { join as join9 } from "path";
import { findLoreRoot as findLoreRoot11, lorePath as lorePath9 } from "@chronicle/core";
async function cmdSession(opts) {
  const root = findLoreRoot11();
  if (!root) {
    console.error(chalk11.red("\u2717  No .lore/ found. Run `chronicle init` first."));
    process.exit(1);
  }
  const sessionsDir = lorePath9(root, "sessions");
  mkdirSync2(sessionsDir, { recursive: true });
  switch (opts.action) {
    case "save":
      return saveSession(sessionsDir, opts.message);
    case "list":
      return listSessions(sessionsDir);
    case "show":
      return showSessions(sessionsDir, opts.n ? parseInt(opts.n, 10) : 1);
  }
}
function saveSession(dir, message) {
  const now = /* @__PURE__ */ new Date();
  const ts = now.toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const file = join9(dir, `${ts}.md`);
  const body = (message == null ? void 0 : message.trim()) ?? "";
  const content = `# Session \u2014 ${now.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", year: "numeric" })} ${now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}

${body || "_No session notes._"}
`;
  writeFileSync4(file, content);
  console.log(chalk11.green(`\u2713 Session saved: ${file.split("/").pop()}`));
  if (body) console.log(chalk11.dim(`  ${body.slice(0, 80)}${body.length > 80 ? "\u2026" : ""}`));
}
function listSessions(dir) {
  var _a;
  const files = getSessions(dir);
  if (files.length === 0) {
    console.log(chalk11.yellow("No sessions saved yet."));
    console.log(chalk11.dim('  chronicle session save "what you worked on"'));
    return;
  }
  console.log(chalk11.bold(`
\u25C6 Sessions (${files.length})
`));
  for (const f of files.slice(0, 20)) {
    const name = f.replace(".md", "").replace(/T|-/g, (m, i) => i === 10 ? " " : i > 10 ? ":" : "-");
    const content = readFileSync9(join9(dir, f), "utf8");
    const preview = ((_a = content.split("\n").find((l) => l && !l.startsWith("#"))) == null ? void 0 : _a.slice(0, 60)) ?? "";
    console.log(`  ${chalk11.cyan(name)}  ${chalk11.dim(preview)}`);
  }
  if (files.length > 20) console.log(chalk11.dim(`  \u2026 and ${files.length - 20} more`));
}
function showSessions(dir, n) {
  const files = getSessions(dir).slice(0, n);
  if (files.length === 0) {
    console.log(chalk11.yellow("No sessions saved yet."));
    return;
  }
  for (const f of files) {
    const content = readFileSync9(join9(dir, f), "utf8");
    console.log(content);
    console.log("---");
  }
}
function getSessions(dir) {
  if (!existsSync10(dir)) return [];
  return readdirSync6(dir).filter((f) => f.endsWith(".md")).sort().reverse();
}

// src/commands/mcp.ts
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import {
  findLoreRoot as findLoreRoot12,
  readStore as readStore6,
  appendToStore as appendToStore3,
  writeDeepDecision as writeDeepDecision3,
  lorePath as lorePath10
} from "@chronicle/core";
import { readFileSync as readFileSync10, writeFileSync as writeFileSync5, existsSync as existsSync11, mkdirSync as mkdirSync3, readdirSync as readdirSync7 } from "fs";
import { join as join10 } from "path";
async function cmdMcp() {
  const server = new McpServer({
    name: "chronicle",
    version: "0.5.1"
  });
  server.tool(
    "chronicle_get_context",
    "Get compressed project context: decisions, rejections, risks, last session",
    {
      files: z.string().optional().describe("Comma-separated file paths to scope context to"),
      full: z.boolean().optional().describe("Include all deep ADR files")
    },
    async ({ files, full }) => {
      const root = findLoreRoot12();
      if (!root) return { content: [{ type: "text", text: "(no .lore/ found \u2014 run `chronicle init`)" }] };
      const sections = [];
      const index = readStore6(root, "index");
      if (index) sections.push(index);
      sections.push(readStore6(root, "decisions"));
      sections.push(readStore6(root, "rejected"));
      const risks = readStore6(root, "risks");
      if (risks && files) {
        const scoped = risks.split("\n").filter((l) => files.split(",").some((f) => l.includes(f.trim())) || l.startsWith("#")).join("\n");
        if (scoped.trim()) sections.push(scoped);
      } else if (risks) {
        sections.push(risks);
      }
      if (full) {
        const deepDir = lorePath10(root, "decisions");
        if (existsSync11(deepDir)) {
          for (const f of readdirSync7(deepDir).filter((f2) => f2.endsWith(".md"))) {
            sections.push(readFileSync10(join10(deepDir, f), "utf8"));
          }
        }
      }
      const lastSession = getLastSession(root);
      if (lastSession) sections.push(`## Last Session
${lastSession}`);
      return {
        content: [{
          type: "text",
          text: `<!-- chronicle context -->
${sections.filter(Boolean).join("\n\n---\n\n")}
<!-- end chronicle context -->`
        }]
      };
    }
  );
  server.tool(
    "chronicle_log_decision",
    "Log an architectural decision made during this session",
    {
      title: z.string().describe("Short title of the decision"),
      rationale: z.string().describe("Why this decision was made"),
      affects: z.array(z.string()).describe("File paths or module names affected"),
      risk: z.enum(["low", "medium", "high"]).describe("Reversibility risk"),
      isDeep: z.boolean().optional().describe("True if this warrants a full ADR document")
    },
    async ({ title, rationale, affects, risk, isDeep }) => {
      const root = findLoreRoot12();
      if (!root) return { content: [{ type: "text", text: "No .lore/ found" }] };
      const date = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const slug = slugify2(title);
      const deepLink = isDeep ? ` [\u2192](decisions/${slug}.md)` : "";
      appendToStore3(
        root,
        "decisions",
        `| ${title.slice(0, 50)} | ${affects.join(", ").slice(0, 40)} | ${risk} |${deepLink} |`
      );
      if (isDeep) {
        writeDeepDecision3(
          root,
          slug,
          `# ADR: ${title}

**Date**: ${date}
**Status**: Accepted
**Affects**: ${affects.join(", ")}
**Risk**: ${risk}

## Decision

${rationale}

## Consequences

_To be annotated as consequences become clear._
`
        );
      }
      return { content: [{ type: "text", text: `\u2713 Decision logged: ${title}` }] };
    }
  );
  server.tool(
    "chronicle_log_rejection",
    "Log an approach that was tried and abandoned \u2014 prevents future AI from repeating the mistake",
    {
      what: z.string().describe("What was tried"),
      why: z.string().describe("Why it was abandoned"),
      replacedBy: z.string().optional().describe("What replaced it")
    },
    async ({ what, why, replacedBy }) => {
      const root = findLoreRoot12();
      if (!root) return { content: [{ type: "text", text: "No .lore/ found" }] };
      const date = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      appendToStore3(
        root,
        "rejected",
        `## ${what} \u2014 rejected ${date}
**Replaced by**: ${replacedBy ?? "n/a"}

${why}
`
      );
      return { content: [{ type: "text", text: `\u2713 Rejection logged: ${what}` }] };
    }
  );
  server.tool(
    "chronicle_get_risks",
    "Get risk information for files before modifying them",
    {
      files: z.array(z.string()).describe("File paths to check")
    },
    async ({ files }) => {
      const root = findLoreRoot12();
      if (!root) return { content: [{ type: "text", text: "No .lore/ found" }] };
      const risks = readStore6(root, "risks");
      if (!risks) return { content: [{ type: "text", text: "No risk data yet" }] };
      const relevant = risks.split("\n").filter((l) => files.some((f) => l.includes(f)) || l.startsWith("#")).join("\n");
      return {
        content: [{
          type: "text",
          text: relevant || `No specific risks recorded for: ${files.join(", ")}`
        }]
      };
    }
  );
  server.tool(
    "chronicle_save_session",
    "Save a summary of the current session to .lore/sessions/",
    {
      summary: z.string().describe("What was accomplished this session"),
      pending: z.string().optional().describe("What is still in progress"),
      decisions: z.array(z.string()).optional().describe("Key decisions made this session")
    },
    async ({ summary, pending, decisions }) => {
      const root = findLoreRoot12();
      if (!root) return { content: [{ type: "text", text: "No .lore/ found" }] };
      const date = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const sessionsDir = lorePath10(root, "sessions");
      mkdirSync3(sessionsDir, { recursive: true });
      const content = [
        `# Session ${date}`,
        `
## What was done
${summary}`,
        (decisions == null ? void 0 : decisions.length) ? `
## Decisions made
${decisions.map((d) => `- ${d}`).join("\n")}` : "",
        pending ? `
## Pending
${pending}` : ""
      ].filter(Boolean).join("\n");
      writeFileSync5(join10(sessionsDir, `${date}.md`), content);
      return { content: [{ type: "text", text: `\u2713 Session saved to .lore/sessions/${date}.md` }] };
    }
  );
  server.tool(
    "chronicle_search",
    "Search the .lore/ knowledge base for a term or concept",
    {
      query: z.string().describe("Search term or phrase")
    },
    async ({ query }) => {
      const root = findLoreRoot12();
      if (!root) return { content: [{ type: "text", text: "No .lore/ found" }] };
      const loreDir = lorePath10(root);
      const pattern = new RegExp(query, "gi");
      const hits = [];
      function walk(dir) {
        if (!existsSync11(dir)) return;
        for (const entry of readdirSync7(dir, { withFileTypes: true })) {
          const full = join10(dir, entry.name);
          if (entry.isDirectory()) {
            walk(full);
            continue;
          }
          if (!entry.name.endsWith(".md")) continue;
          const lines = readFileSync10(full, "utf8").split("\n");
          for (let i = 0; i < lines.length && hits.length < 10; i++) {
            pattern.lastIndex = 0;
            if (pattern.test(lines[i])) {
              hits.push(`${full.replace(loreDir + "/", "")}:${i + 1}: ${lines[i].trim()}`);
            }
          }
        }
      }
      walk(loreDir);
      return {
        content: [{
          type: "text",
          text: hits.length ? hits.join("\n") : `No results for "${query}"`
        }]
      };
    }
  );
  const transport = new StdioServerTransport();
  await server.connect(transport);
}
function slugify2(title) {
  return title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);
}
function getLastSession(root) {
  const dir = lorePath10(root, "sessions");
  if (!existsSync11(dir)) return null;
  const files = readdirSync7(dir).filter((f) => f.endsWith(".md")).sort().reverse();
  return files[0] ? readFileSync10(join10(dir, files[0]), "utf8") : null;
}

// src/cli.ts
import { findLoreRoot as findLoreRoot14 } from "@chronicle/core";

// src/status.ts
import { readStore as readStore7, listSessions as listSessions2, lorePath as lorePath11 } from "@chronicle/core";
import { existsSync as existsSync12, statSync as statSync2, readdirSync as readdirSync8 } from "fs";
import chalk12 from "chalk";
var ICON = "\u25C6";
function getStoreStats(root) {
  const decisions = countTableRows(readStore7(root, "decisions"));
  const rejections = countHeadings(readStore7(root, "rejected"));
  const deepADRs = countFiles(lorePath11(root, "decisions"), ".md");
  const sessions = listSessions2(root).length;
  const lastCapture = getLastModified(lorePath11(root, "decisions.md"));
  const hasEvolution = existsSync12(lorePath11(root, "evolution.md")) && readStore7(root, "evolution").length > 100;
  const hasDiagrams = countFiles(lorePath11(root, "diagrams"), ".txt") > 0;
  return { decisions, rejections, deepADRs, sessions, lastCapture, hasEvolution, hasDiagrams };
}
function printStatusBefore(root, command) {
  const stats = getStoreStats(root);
  const age = stats.lastCapture ? relativeTime(stats.lastCapture) : "never";
  const parts = [
    chalk12.cyan(`${ICON} chronicle`),
    chalk12.dim("\u2502"),
    chalk12.white(`${stats.decisions} decisions`),
    chalk12.dim("\xB7"),
    chalk12.red(`${stats.rejections} rejected`),
    chalk12.dim("\xB7"),
    chalk12.yellow(`${stats.deepADRs} ADRs`),
    chalk12.dim("\xB7"),
    chalk12.dim(`last capture: ${age}`)
  ];
  process.stderr.write(parts.join(" ") + "\n");
}
function printStatusAfter(root, beforeStats) {
  const after = getStoreStats(root);
  const newDecisions = after.decisions - beforeStats.decisions;
  const newRejections = after.rejections - beforeStats.rejections;
  const newADRs = after.deepADRs - beforeStats.deepADRs;
  const newSessions = after.sessions - beforeStats.sessions;
  const changes = [];
  if (newDecisions > 0) changes.push(chalk12.white(`+${newDecisions} decision${newDecisions > 1 ? "s" : ""}`));
  if (newRejections > 0) changes.push(chalk12.red(`+${newRejections} rejection${newRejections > 1 ? "s" : ""}`));
  if (newADRs > 0) changes.push(chalk12.yellow(`+${newADRs} ADR${newADRs > 1 ? "s" : ""}`));
  if (newSessions > 0) changes.push(chalk12.green(`+${newSessions} session${newSessions > 1 ? "s" : ""}`));
  if (changes.length === 0) return;
  process.stderr.write(
    chalk12.cyan(`${ICON}`) + chalk12.dim(" chronicle wrote ") + changes.join(chalk12.dim(", ")) + "\n"
  );
}
function countTableRows(content) {
  return content.split("\n").filter((l) => l.startsWith("|") && !l.includes("---") && !l.includes("Decision") && !l.includes("Affects")).length;
}
function countHeadings(content) {
  return (content.match(/^## /gm) ?? []).length;
}
function countFiles(dir, ext) {
  if (!existsSync12(dir)) return 0;
  try {
    return readdirSync8(dir).filter((f) => f.endsWith(ext)).length;
  } catch {
    return 0;
  }
}
function getLastModified(path) {
  if (!existsSync12(path)) return null;
  try {
    return statSync2(path).mtime.toISOString();
  } catch {
    return null;
  }
}
function relativeTime(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 6e4);
  const hours = Math.floor(diff / 36e5);
  const days = Math.floor(diff / 864e5);
  if (mins < 2) return "just now";
  if (mins < 60) return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

// src/cli.ts
var program = new Command();
program.name("chronicle").description("AI-native development memory \u2014 markdown RAG for every AI coding tool").version("0.5.1");
program.command("init").description("Bootstrap .lore/ from git history").option("-d, --depth <depth>", "how far back to scan: 1month|3months|6months|1year|all", "6months").option("--llm <provider>", "LLM provider: anthropic|openai|gemini|ollama", "anthropic").option("--limit <n>", "cap commits to N most recent (use with deepen to process incrementally)").option("--concurrency <n>", "parallel LLM calls (default: 4 for API providers, 1 for ollama)").action(cmdInit);
program.command("inject").description("Output compressed context for the current session").option("--files <files>", "comma-separated files to scope context to").option("--full", "include all deep ADR files, not just index").option("--format <format>", "output format: markdown|xml|plain", "markdown").action(cmdInject);
program.command("deepen").description("Extend the scan further back in history").option("-d, --depth <depth>", "new depth: 1year|all", "1year").option("--llm <provider>", "LLM provider: anthropic|openai|gemini|ollama", "anthropic").option("--limit <n>", "cap additional commits to N most recent").option("--concurrency <n>", "parallel LLM calls").action(cmdDeepen);
program.command("doctor").description("Validate .lore/ health \u2014 check files, links, cache, and hooks").action(cmdDoctor);
program.command("search <query>").description("Full-text search across .lore/ knowledge base").option("--limit <n>", "max results", "20").option("--json", "output results as JSON").action(cmdSearch);
program.command("serve").description("Start a local web viewer for .lore/").option("--port <n>", "port to listen on", "4242").action(cmdServe);
program.command("setup").description("Install integration for a specific AI tool").option("--tool <tool>", "tool name: claude-code|cursor|aider|gemini-cli|copilot|codex|opencode|trae|factory|openclaw").option("--all", "install all available integrations").action(cmdSetup);
program.command("evolution").description("Build or view the system evolution record (.lore/evolution.md)").option("--regen", "force regenerate even if evolution.md already exists").option("--view", "print current evolution record to stdout").action(cmdEvolution);
program.command("diagram").description("Generate ASCII diagrams from .lore/ store").option("--type <type>", "architecture|dependencies|evolution (default: all)").action(cmdDiagram);
var session = program.command("session").description("Manage session notes in .lore/sessions/");
session.command("save [message]").description("Save a session note with optional message").action((msg) => cmdSession({ action: "save", message: msg }));
session.command("list").description("List saved session notes").action(() => cmdSession({ action: "list" }));
session.command("show [n]").description("Show last N session notes (default: 1)").action((n) => cmdSession({ action: "show", n }));
program.command("mcp").description("Start the MCP server for Claude Code integration (stdio transport)").action(cmdMcp);
var hooks = program.command("hooks").description("Manage git hooks");
hooks.command("install").description("Install post-commit and prepare-commit-msg hooks").action(cmdHooksInstall);
hooks.command("remove").description("Remove Chronicle hooks from git").action(cmdHooksRemove);
program.command("capture", { hidden: true }).option("--from-commit <hash>").option("--llm <provider>").action(cmdCapture);
program.command("enrich-commit <msgFile>", { hidden: true }).action((msgFile) => cmdEnrichCommit({ msgFile }));
var WRITE_COMMANDS = /* @__PURE__ */ new Set(["init", "deepen", "capture", "setup", "diagram", "evolution"]);
program.hook("preAction", (thisCommand) => {
  const name = thisCommand.name();
  if (!WRITE_COMMANDS.has(name)) return;
  const root = findLoreRoot14();
  if (!root) return;
  thisCommand._chronicleStats = getStoreStats(root);
  printStatusBefore(root, name);
});
program.hook("postAction", (thisCommand) => {
  const name = thisCommand.name();
  if (!WRITE_COMMANDS.has(name)) return;
  const root = findLoreRoot14();
  const before = thisCommand._chronicleStats;
  if (!root || !before) return;
  printStatusAfter(root, before);
});
program.parse();
