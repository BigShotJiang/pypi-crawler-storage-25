from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import asyncpg


class TimescaleStorage:
    """
    Lightweight TimescaleDB (Postgres) helper using asyncpg.

    Schema (see SQL below) uses:
      - time (timestamptz)
      - session_id bigint
      - handle_id bigint
      - plugin text
      - room_id text (optional if available)
      - peer_id text (optional)
      - metrics jsonb   -- map of metric keys -> numeric values

    Usage:
      storage = TimescaleStorage(dsn="postgresql://user:pass@db:5432/dbname")
      await storage.connect()
      await storage.insert_metric(...)
      await storage.close()
    """

    def __init__(self, dsn: str, min_pool_size: int = 1, max_pool_size: int = 10):
        self._dsn = dsn
        self._pool: Optional[asyncpg.pool.Pool] = None
        self._min = min_pool_size
        self._max = max_pool_size

    async def connect(self) -> None:
        # self._pool = await asyncpg.create_pool(
        #     dsn=self._dsn,
        #     min_size=self._min,
        #     max_size=self._max
        # )
        async with asyncpg.create_pool(
                dsn=self._dsn,
                min_size=self._min,
                max_size=self._max
        ) as pool:
            self._pool = pool

    async def close(self) -> None:
        if self._pool:
            await self._pool.close()
            self._pool = None

    async def insert_metric(
            self,
            ts: Optional[float],
            session_id: Optional[int],
            handle_id: Optional[int],
            plugin: Optional[str],
            room_id: Optional[str],
            peer_id: Optional[str],
            metrics: Dict[str, Any],
    ) -> None:
        """
        Insert a new timeseries point. metrics should be JSON-serializable.
        ts: epoch seconds or None (server will use now()).
        """
        if not self._pool:
            raise RuntimeError("storage not connected")
        dt = datetime.fromtimestamp(ts, tz=timezone.utc) if ts else None
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO janus_metrics(time, session_id, handle_id, plugin, room_id, peer_id, metrics)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                """,
                dt,
                session_id,
                handle_id,
                plugin,
                room_id,
                peer_id,
                json.dumps(metrics),
            )

    async def query_aggregate(
            self,
            start: str,
            stop: str,
            group_by: str,
            metric_key: str,
            *,
            plugin: Optional[str] = None,
            room_id: Optional[str] = None,
            peer_id: Optional[str] = None,
            time_bucket: str = "1 minute",
    ) -> List[Dict[str, Any]]:
        """
        Returns aggregated series: time_bucket, label (group), avg(value), sum(value), max(value)
        group_by: 'plugin'|'room_id'|'peer_id'|'handle_id'
        start/stop: ISO timestamps
        metric_key: key inside metrics JSON to aggregate
        """
        if not self._pool:
            raise RuntimeError("storage not connected")

        filter_clauses = []
        args = [start, stop]
        arg_idx = 3
        if plugin:
            filter_clauses.append(f"plugin = ${arg_idx}")
            args.append(plugin);
            arg_idx += 1
        if room_id:
            filter_clauses.append(f"room_id = ${arg_idx}")
            args.append(room_id);
            arg_idx += 1
        if peer_id:
            filter_clauses.append(f"peer_id = ${arg_idx}")
            args.append(peer_id);
            arg_idx += 1

        where = " AND ".join(filter_clauses)
        if where:
            where = "AND " + where

        group_by_col = group_by
        q = f"""
        SELECT
          time_bucket($3::interval, time) AS bucket,
          {group_by_col} AS label,
          avg((metrics->>$4)::double precision) AS avg_val,
          sum((metrics->>$4)::double precision) AS sum_val,
          max((metrics->>$4)::double precision) AS max_val
        FROM janus_metrics
        WHERE time >= $1 AND time <= $2
        {where}
        GROUP BY bucket, {group_by_col}
        ORDER BY bucket ASC;
        """

        # note: $3 currently used in query for time_bucket interval - adjust parameters order for asyncpg
        # We'll set args as: [start, stop, time_bucket_interval, metric_key, ...filters]
        # So we need to rebuild with correct param indices
        # Rebuild properly:
        final_args = [start, stop, time_bucket, metric_key]
        if plugin:
            final_args.append(plugin)
        if room_id:
            final_args.append(room_id)
        if peer_id:
            final_args.append(peer_id)

        # Build SQL with placeholders $1..$N accordingly:
        sql = f"""
        SELECT
          time_bucket($3::interval, time) AS bucket,
          {group_by_col} AS label,
          avg((metrics->>$4)::double precision) AS avg_val,
          sum((metrics->>$4)::double precision) AS sum_val,
          max((metrics->>$4)::double precision) AS max_val
        FROM janus_metrics
        WHERE time >= $1 AND time <= $2
        """
        idx = 5
        if plugin:
            sql += f" AND plugin = ${idx}";
            idx += 1
        if room_id:
            sql += f" AND room_id = ${idx}";
            idx += 1
        if peer_id:
            sql += f" AND peer_id = ${idx}";
            idx += 1
        sql += f" GROUP BY bucket, {group_by_col} ORDER BY bucket ASC;"

        async with self._pool.acquire() as conn:
            records = await conn.fetch(sql, *final_args)
            return [
                {
                    "bucket": r["bucket"].isoformat(),
                    "label": r["label"],
                    "avg": r["avg_val"],
                    "sum": r["sum_val"],
                    "max": r["max_val"],
                }
                for r in records
            ]
