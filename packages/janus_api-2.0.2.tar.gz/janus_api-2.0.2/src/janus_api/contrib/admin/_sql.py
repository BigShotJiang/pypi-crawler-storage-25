CREATE_STATEMENTS = [
    # create extension
    "CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;",
    # create table
    """
    CREATE TABLE IF NOT EXISTS janus_metrics (
      time        timestamptz       NOT NULL,
      session_id  bigint,
      handle_id   bigint,
      plugin      text,
      room_id     text,
      peer_id     text,
      metrics     jsonb
    );
    """,
    # create hypertable
    "SELECT create_hypertable('janus_metrics', 'time', if_not_exists => TRUE);",
    # indexes
    "CREATE INDEX IF NOT EXISTS idx_janus_metrics_plugin ON janus_metrics(plugin);",
    "CREATE INDEX IF NOT EXISTS idx_janus_metrics_room ON janus_metrics(room_id);",
    "CREATE INDEX IF NOT EXISTS idx_janus_metrics_handle ON janus_metrics(handle_id);",
]

# Continuous aggregate (materialized view) for per-room 1-minute aggregates.
# You can add more continuous aggregates for other metrics or time buckets.
CONTINUOUS_AGG_SQL = """
CREATE MATERIALIZED VIEW IF NOT EXISTS janus_metrics_room_1m
WITH (timescaledb.continuous) AS
SELECT
  time_bucket('1 minute', time)           AS bucket,
  room_id,
  avg((metrics->>'inbound_bytes')::double precision) AS avg_inbound_bytes,
  avg((metrics->>'outbound_bytes')::double precision) AS avg_outbound_bytes,
  sum((metrics->>'packets_lost')::double precision)  AS sum_packets_lost
FROM janus_metrics
WHERE room_id IS NOT NULL
GROUP BY bucket, room_id;
"""

# Add a policy: keep aggregate data fresh for 7 days of materialization window (adjust as needed)
CONTINUOUS_AGG_POLICY_SQL = """
SELECT add_continuous_aggregate_policy('janus_metrics_room_1m',
    start_interval => INTERVAL '1 day',
    end_interval   => INTERVAL '1 minute',
    schedule_interval => INTERVAL '1 minute');
"""

# Retention policy for raw hypertable: keep raw points for 30 days (adjust as needed)
RETENTION_POLICY_SQL = """
SELECT add_retention_policy('janus_metrics', INTERVAL '30 days');
"""
# -- create the materialized view for 1-minute per-room aggregates
# -- policy to maintain the continuous aggregate (refresh window)
# -- retention policy for raw hypertable (delete raw points older than 30 days)
AGGREGATE_SQL = """

CREATE MATERIALIZED VIEW janus_metrics_room_1m
WITH (timescaledb.continuous) AS
SELECT
  time_bucket('1 minute', time)           AS bucket,
  room_id,
  avg((metrics->>'inbound_bytes')::double precision) AS avg_inbound_bytes,
  avg((metrics->>'outbound_bytes')::double precision) AS avg_outbound_bytes,
  sum((metrics->>'packets_lost')::double precision)  AS sum_packets_lost
FROM janus_metrics
WHERE room_id IS NOT NULL
GROUP BY bucket, room_id;


SELECT add_continuous_aggregate_policy(
  'janus_metrics_room_1m',
  start_interval => INTERVAL '1 day',
  end_interval => INTERVAL '1 minute',
  schedule_interval => INTERVAL '1 minute'
);


SELECT add_retention_policy('janus_metrics', INTERVAL '30 days');
"""