"""
### Tribulnation Bitteam
> An SDK to connect Bitteam with the Tribulnation ecosystem.

- Details
"""