# Tribulnation Bitteam SDK

> An SDK to connect Bitteam with the Tribulnation ecosystem.

🚧 Under construction.