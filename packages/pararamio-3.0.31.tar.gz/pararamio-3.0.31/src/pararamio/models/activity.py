"""Sync Activity model with sync-specific methods."""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime

from pararamio._core.api_schemas import UserActivityResponse
from pararamio._core.models import Activity as CoreActivity
from pararamio._core.models import ActivityAction
from pararamio._core.models.activity import iter_activity_windows

__all__ = ('Activity', 'ActivityAction')


class Activity(CoreActivity):
    """Sync Activity model with get_activity method."""

    @classmethod
    def get_activity(
        cls,
        page_loader: Callable[..., UserActivityResponse],
        start: datetime,
        end: datetime,
        actions: list[ActivityAction] | None = None,
    ) -> list[Activity]:
        """Get user activity within date range (sync version).

        The server filters by ``start``/``end`` directly and rejects periods longer
        than 14 days, so the range is split into 14-day windows here. With the
        time filter active the server returns the full window in one response —
        no pagination is needed.

        Args:
            page_loader: Function taking ``(start, end, actions)`` and returning
                a ``UserActivityResponse`` for that window.
            start: Range start (inclusive).
            end: Range end (inclusive).
            actions: Optional list of actions to filter.

        Returns:
            List of Activity objects sorted by time.
        """
        results: list[Activity] = []
        for window_start, window_end in iter_activity_windows(start, end):
            response = page_loader(window_start, window_end, actions)
            results.extend(
                cls.from_api_data(item)
                for item in response.get('data', response.get('activities', []))
            )
        return sorted(results, key=lambda x: x.time)
