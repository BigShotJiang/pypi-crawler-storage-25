from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING, Any, Generic, Self, TypeVar

from pararamio._core.models.base import AttrFormatterMixin

from pararamio.exceptions import PararamModelNotLoadedError

if TYPE_CHECKING:
    from collections.abc import Mapping

    from pararamio.client import Pararamio

__all__ = ('SyncClientMixin',)


DataT = TypeVar('DataT', bound='Mapping[str, Any]')


class SyncClientMixin(Generic[DataT], AttrFormatterMixin[DataT]):
    """Mixin for sync models with reference to a Pararamio client."""

    _client: Pararamio
    _data: DataT
    _is_loaded: bool

    def __init__(self, client: Pararamio, **kwargs: Any) -> None:  # noqa: ARG002
        """Initialize with the Pararamio client.

        Args:
            client: Pararamio client instance
            **kwargs: Model data passed to parent classes
        """
        self._is_loaded = False
        self._client = client

    @property
    def client(self) -> Pararamio:
        """Get the Pararamio client instance."""
        return self._client

    def _set_loaded(self) -> None:
        """Set model data as loaded."""
        self._is_loaded = True

    @property
    def is_loaded(self) -> bool:
        """Check if model data has been loaded.

        Override in subclasses to check for required fields.
        """
        return self._is_loaded

    def load(self, *, force: bool = False) -> Self:
        raise NotImplementedError

    def _get_annotations(self) -> dict[str, Any]:
        """Collect all type annotations from class hierarchy (MRO)."""
        annotations: dict[str, Any] = {}
        for cls in reversed(type(self).__mro__):
            annotations.update(getattr(cls, '__annotations__', {}))
        return annotations

    def __getattr__(self, key: str) -> Any:
        """Get attribute from _data with lazy loading for sync models.

        This is called only when attribute is not found in the instance.
        For sync, we do lazy loading if load_on_key_error is True.
        If the key is a known model attribute (in type annotations) but absent
        from _data, returns None instead of attempting to load or raising.
        """
        if key.startswith('_'):
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{key}'")

        # Try to get from _data
        with contextlib.suppress(KeyError):
            return self._get_formatted_attr(key)

        # If not found and not loaded
        if not self.is_loaded:
            if self._client.load_on_key_error:
                # Load the object (skip if subclass hasn't implemented load)
                try:
                    self.load()
                except NotImplementedError:
                    # load() not implemented — check if key is a known model attribute
                    if key in self._get_annotations():
                        return None
                    msg = (
                        f"'{self.__class__.__name__}' has no attribute "
                        f"'{key}' and load() is not implemented"
                    )
                    raise AttributeError(msg) from None
                # Try again after loading
                with contextlib.suppress(KeyError):
                    return self._get_formatted_attr(key)
            else:
                # Key is a known model attribute but not in _data — return None
                if key in self._get_annotations():
                    return None
                # Raise PararamModelNotLoadedError if load_on_key_error is False
                msg = (
                    f'{self.__class__.__name__} data has not been loaded. '
                    f'Attribute "{key}" is not available. Use load() to fetch data first.'
                )
                raise PararamModelNotLoadedError(msg)

        # Key is a known model attribute but not in _data after loading — return None
        if key in self._get_annotations():
            return None

        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{key}'")
