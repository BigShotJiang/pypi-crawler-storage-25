"""Sherpa transform annotations to categories processor"""

__version__ = "1.8.45"
