#    Copyright 2025 Genesis Corporation.
#
#    All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
from __future__ import annotations

import re
import ipaddress
import typing as tp
import dataclasses
import uuid
import random


@dataclasses.dataclass
class Port:
    mac: str
    ip: ipaddress.IPv4Address | None = None

    @classmethod
    def from_spec(cls, spec: dict[str, tp.Any]) -> Port:
        spec = spec.copy()
        spec["ip"] = (
            ipaddress.IPv4Address(spec["ip"]) if spec["ip"] is not None else None
        )
        return cls(**spec)

    @classmethod
    def gen_mac(cls) -> str:
        return (
            "52:54:00:"
            f"{random.randint(0, 255):02x}:"
            f"{random.randint(0, 255):02x}:"
            f"{random.randint(0, 255):02x}"
        )

    @classmethod
    def port_with_random_mac(cls) -> Port:
        return cls(mac=cls.gen_mac(), ip=None)


@dataclasses.dataclass
class Network:
    name: str
    cidr: ipaddress.IPv4Network
    dhcp: bool = False

    # Is an user's network bridge
    managed_network: bool = True

    @classmethod
    def dummy(cls) -> Network:
        return cls(
            name="dummy",
            cidr=ipaddress.IPv4Network("0.0.0.0/24"),
            managed_network=False,
        )

    @property
    def is_dummy(self) -> bool:
        return self.name == "dummy"

    @classmethod
    def from_spec(cls, spec: dict[str, tp.Any]) -> Network:
        spec = spec.copy()
        spec["cidr"] = ipaddress.IPv4Network(spec["cidr"])
        return cls(**spec)


@dataclasses.dataclass
class Disk:
    size: int
    label: str = ""

    def uuid(self, node_uuid: uuid.UUID) -> uuid.UUID:
        return uuid.uuid5(node_uuid, self.label)

    @classmethod
    def from_spec(cls, spec: dict[str, tp.Any]) -> Disk:
        return cls(**spec)


@dataclasses.dataclass
class Node:
    uuid: uuid.UUID = dataclasses.field(default_factory=uuid.uuid4)
    name: str = "genesis-node"
    memory: int = 1024
    cores: int = 1
    disks: list[Disk] = dataclasses.field(default_factory=lambda: [Disk(size=10)])
    image: str | None = None
    image_uri: str | None = None
    ports: list[Port] = dataclasses.field(default_factory=list)

    @classmethod
    def from_spec(cls, spec: dict[str, tp.Any]) -> Node:
        spec = spec.copy()
        spec["disks"] = [Disk.from_spec(d) for d in spec.pop("disks", [])]
        spec["ports"] = [Port.from_spec(p) for p in spec.pop("ports", [])]
        return cls(**spec)


@dataclasses.dataclass
class Bootstrap(Node):
    name: str = "genesis-bootstrap"
    # Two disks for the bootstrap, one for the root and one for the data
    disks: list[Disk] = dataclasses.field(
        default_factory=lambda: [
            Disk(size=10, label="root-volume"),
            Disk(size=10, label="data"),
        ]
    )

    @classmethod
    def from_node(cls, node: Node) -> Bootstrap:
        return cls(**dataclasses.asdict(node))


@dataclasses.dataclass
class Hypervisor:
    network_type: str
    network: str
    connection_uri: str
    storage_pool: str = "default"
    driver: str = "libvirt"
    machine_prefix: str = "vm-"
    iface_rom_file: str = "/usr/share/qemu/1af41041.rom"

    @classmethod
    def from_spec(cls, spec: dict[str, tp.Any]) -> Hypervisor:
        return cls(**spec)

    def is_valid(self, network: Network) -> bool:
        match = re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", self.connection_uri)
        if not match:
            # Perhaps it's a domain name
            return True

        ip_str = match.group(0)
        try:
            ip = ipaddress.ip_address(ip_str)
        except ValueError:
            return False

        return network.cidr.overlaps(ipaddress.ip_network(ip))


@dataclasses.dataclass
class Stand:
    # Main network of the installation. After bootstrap
    # procedure a node will be connected to this network.
    network: Network
    # Network used for the bootstrapping procedure.
    # It's an isolated private network.
    boot_network: Network
    bootstraps: list[Bootstrap]
    baremetals: list[Node]
    hypervisors: list[Hypervisor] = dataclasses.field(default_factory=list)
    name: str = "dev-stand"

    def is_valid(self) -> bool:
        if self.network.is_dummy or not self.bootstraps:
            return False

        if all(b.image is None for b in self.bootstraps):
            return False

        for h in self.hypervisors:
            if not h.is_valid(self.network):
                return False

        return True

    def has_bootstrap_image(self) -> bool:
        return any(b.image for b in self.bootstraps)

    def set_bootstrap_image(self, image: str):
        for b in self.bootstraps:
            b.image = image

    @classmethod
    def single_bootstrap_stand(
        cls,
        image: str,
        image_uri: str,
        core_ip: ipaddress.IPv4Address,
        network: Network,
        boot_network: Network,
        cores: int = 1,
        memory: int = 1024,
        name: str = "dev-stand",
        bootstrap_name: str = "bootstrap",
        hypervisors: tp.Collection[Hypervisor] = (),
    ) -> Stand:
        ports = [
            Port(mac=Port.gen_mac(), ip=core_ip),
            Port(mac=Port.gen_mac()),
        ]
        return cls(
            name=name,
            network=network,
            boot_network=boot_network,
            bootstraps=[
                Bootstrap(
                    name=bootstrap_name,
                    image=image,
                    image_uri=image_uri,
                    cores=cores,
                    memory=memory,
                    ports=ports,
                )
            ],
            baremetals=[],
            hypervisors=list(hypervisors),
        )

    @classmethod
    def empty_stand(
        cls,
        name: str = "dev-stand",
        network: Network | None = None,
        boot_network: Network | None = None,
    ) -> Stand:
        if network is None:
            network = Network.dummy()

        if boot_network is None:
            boot_network = Network.dummy()

        return cls(
            name=name,
            bootstraps=[],
            baremetals=[],
            network=network,
            boot_network=boot_network,
            hypervisors=[],
        )

    @classmethod
    def from_spec(cls, spec: dict[str, tp.Any]) -> Stand:
        spec = spec.copy()
        bootstraps = [Bootstrap.from_spec(b) for b in spec.pop("bootstraps", [])]
        baremetals = [Node.from_spec(n) for n in spec.pop("baremetals", [])]

        if "network" not in spec:
            network = Network.dummy()
        else:
            network = Network.from_spec(spec.pop("network"))

        if "boot_network" not in spec:
            boot_network = Network.dummy()
        else:
            boot_network = Network.from_spec(spec.pop("boot_network"))

        return cls(
            bootstraps=bootstraps,
            baremetals=baremetals,
            network=network,
            boot_network=boot_network,
            hypervisors=[Hypervisor.from_spec(h) for h in spec.pop("hypervisors", [])],
            **spec,
        )
