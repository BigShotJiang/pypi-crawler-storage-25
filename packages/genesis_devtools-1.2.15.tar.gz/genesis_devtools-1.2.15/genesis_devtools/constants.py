#    Copyright 2025 Genesis Corporation.
#
#    All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import enum
import os
import typing as tp

PKG_NAME = "genesis_devtools"
GITHUB_RELEASES_URL = f"https://api.github.com/repos/infraguys/{PKG_NAME}/releases"
GENESIS_REPO_URL = "https://repository.genesis-core.tech"
ELEMENT_REPO_URL = f"{GENESIS_REPO_URL}/genesis-elements"
LIBVIRT_DEF_POOL_PATH = "/var/lib/libvirt/images"
DEF_GEN_CFG_FILE_NAME = "genesis.yaml"
DEF_GEN_WORK_DIR_NAME = "genesis"
DEF_GEN_OUTPUT_DIR_NAME = "output"
RC_BRANCHES = ("master", "main")
ENCRYPTED_EXTENSION = ".encrypted"
EP_BACKUP_DRIVERS = "genesis_devtools.backup.drivers"
EP_REPO_DRIVERS = "genesis_devtools.repo.drivers"
GB_SHIFT = 30

# IAM constants
DEFAULT_IAM_TTL = 15 * 60
DEFAULT_IAM_REFRESH_TTL = 60 * 60
DEFAULT_IAM_SCOPE = "profile"

# ENV vars
ENV_GEN_DEV_KEYS = "GEN_DEV_KEYS"

# Types
ImageProfileType = tp.Literal["ubuntu_24", "genesis_base"]
ImageFormatType = tp.Literal["raw", "qcow2", "gz"]
NetType = tp.Literal["network", "bridge"]
VersionSuffixType = tp.Literal["latest", "none", "element"]
DomainState = tp.Literal["all", "inactive", "state-paused"]
NodeType = tp.Literal["bootstrap", "baremetal"]

ENV_FILE_FORMAT = tp.Literal["json", "env"]

MANIFEST_COLLECTION = "/v1/em/manifests/"
ELEMENT_COLLECTION = "/v1/em/elements/"
SERVICE_COLLECTION = "/v1/em/services/"

PROFILE_COLLECTION = "/v1/vs/profiles/"
VALUE_COLLECTION = "/v1/vs/values/"
VARIABLE_COLLECTION = "/v1/vs/variables/"

CERTIFICATE_COLLECTION = "/v1/secret/certificates/"
PASSWORD_COLLECTION = "/v1/secret/passwords/"
SSH_KEY_COLLECTION = "/v1/secret/ssh_keys/"
RSA_KEY_COLLECTION = "/v1/secret/rsa_keys/"

NODE_COLLECTION = "/v1/compute/nodes/"
HYPERVISOR_COLLECTION = "/v1/compute/hypervisors/"
SET_COLLECTION = "/v1/compute/sets/"

USER_COLLECTION = "/v1/iam/users/"
IDP_COLLECTION = "/v1/iam/idp/"
CLIENT_COLLECTION = "/v1/iam/clients/"
ORGANIZATION_COLLECTION = "/v1/iam/organizations/"
PROJECT_COLLECTION = "/v1/iam/projects/"
ROLE_COLLECTION = "/v1/iam/roles/"
PERMISSION_COLLECTION = "/v1/iam/permissions/"
ROLE_BINDING_COLLECTION = "/v1/iam/role_bindings/"
PERMISSION_BINDING_COLLECTION = "/v1/iam/permission_bindings/"

# Cli
CONFIG_DIR = "~/.genesis"
CONFIG_FILE = os.path.expanduser(f"{CONFIG_DIR}/genesisctl.yaml")
LAST_CHECK_FILE = os.path.expanduser(f"{CONFIG_DIR}/genesisctl.last_version_check")
UPDATE_CHECK_INTERVAL = 60 * 60  # 1 hour in seconds


class BackupPeriod(str, enum.Enum):
    M1 = "1m"
    M5 = "5m"
    M15 = "15m"
    M30 = "30m"
    H1 = "1h"
    H3 = "3h"
    H6 = "6h"
    H12 = "12h"
    D1 = "1d"
    D3 = "3d"
    D7 = "7d"

    @property
    def timeout(self) -> int:
        """Return timeout in seconds based on current element in enum."""
        timeouts = {
            self.M1: 60,
            self.M5: 60 * 5,
            self.M15: 60 * 15,
            self.M30: 60 * 30,
            self.H1: 60 * 60,
            self.H3: 60 * 60 * 3,
            self.H6: 60 * 60 * 6,
            self.H12: 60 * 60 * 12,
            self.D1: 60 * 60 * 24,
            self.D3: 60 * 60 * 24 * 3,
            self.D7: 60 * 60 * 24 * 7,
        }
        return timeouts[self]


class Profile(str, enum.Enum):
    DEVELOP = "develop"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"
    LEGACY = "legacy"

    @property
    def ram(self) -> int:
        """Return memory in Mb based on current element in enum."""
        memory = {
            self.DEVELOP: 1024,
            self.SMALL: 2048,
            self.MEDIUM: 8192,
            self.LARGE: 16384,
            self.LEGACY: 4096,
        }
        return memory[self]

    @property
    def cores(self) -> int:
        """Return CPU cores based on current element in enum."""
        cores = {
            self.DEVELOP: 1,
            self.SMALL: 2,
            self.MEDIUM: 4,
            self.LARGE: 8,
            self.LEGACY: 2,
        }
        return cores[self]
