
# genesis_permissions

Manage permissions in the Genesis installation

## Usage

```console
                                                                                
 Usage: genesis permissions [OPTIONS] COMMAND [ARGS]...                         
                                                                                
```

## Options

* `help`:
    * Type: boolean
    * Default: `false`
    * Usage: `--help`

  Show this message and exit.

## CLI Help

```console
                                                                                
 Usage: genesis permissions [OPTIONS] COMMAND [ARGS]...                         
                                                                                
 Manage permissions in the Genesis installation                                
                                                                                
╭─ Options ────────────────────────────────────────────────────────────────────╮
│ --help  Show this message and exit.                                          │
╰──────────────────────────────────────────────────────────────────────────────╯
╭─ Commands ───────────────────────────────────────────────────────────────────╮
│ delete                 Delete permission                                     │
│ list                   List permissions                                      │
│ show                   Show permission                                       │
╰──────────────────────────────────────────────────────────────────────────────╯
```
