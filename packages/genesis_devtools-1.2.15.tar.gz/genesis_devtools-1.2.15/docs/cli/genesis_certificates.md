
# genesis_certificates

Manage certificates in the Genesis installation

## Usage

```console
                                                                                
 Usage: genesis certificates [OPTIONS] COMMAND [ARGS]...                        
                                                                                
```

## Options

* `help`:
    * Type: boolean
    * Default: `false`
    * Usage: `--help`

  Show this message and exit.

## CLI Help

```console
                                                                                
 Usage: genesis certificates [OPTIONS] COMMAND [ARGS]...                        
                                                                                
 Manage certificates in the Genesis installation                                
                                                                                
╭─ Options ────────────────────────────────────────────────────────────────────╮
│ --help  Show this message and exit.                                          │
╰──────────────────────────────────────────────────────────────────────────────╯
╭─ Commands ───────────────────────────────────────────────────────────────────╮
│ add        Add a new certificate to the Genesis installation                 │
│ delete     Delete certificate                                                │
│ list       List certificates                                                 │
│ show       Show certificate                                                  │
│ update     Update certificate                                                │
╰──────────────────────────────────────────────────────────────────────────────╯
```
