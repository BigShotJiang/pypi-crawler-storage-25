"""Seashell CLI — interactive genomic query tool."""

import getpass
import json
import sys
import threading
import time

from seashell.client import SeashellClient
from seashell.config import load_config, save_config, clear_config, DEFAULT_SERVER
from seashell.display import (display_result, print_job_progress, infer_action, show_more,
                               _print_gwas_complete)
from seashell.help import HELP_TEXT, welcome_banner, CYAN, BOLD, DIM, RESET, WHITE, BLUE


def _prompt_login():
    """Interactive login flow with wake-on-key.

    Every terminal session is a fresh login — credentials are NEVER cached
    between sessions. Closing the terminal logs you out. The only thing
    persisted across sessions is the server URL (so you don't have to
    re-type --server every time).

    Flow:
      1. Read API key (paste from clipboard) → fires POST /wake immediately
      2. /wake returns instantly with state="starting" + ETA + a poll job
      3. Background thread polls /wake_status while the user types email + password
      4. After /auth/login succeeds, block until the wake job reports ready
         (usually instant by then because the EC2 boot ran in parallel with the
         password prompt)
      5. Return client — session token lives only in this process's memory

    The whole point is that the ~30s EC2 boot time is HIDDEN behind the
    password prompt. The researcher experiences "paste key, type email,
    type password, hit enter, see prompt" — no perceived cold start.
    """
    print(welcome_banner())

    config = load_config()
    server = config.get("server", DEFAULT_SERVER)

    # ───── Fresh login path (always — no auto-reconnect) ─────

    # Step 1: read API key. Triggers wake immediately.
    api_key = input(CYAN + "  API Key: " + RESET).strip()
    if not api_key:
        print("  No API key provided. Exiting.")
        sys.exit(1)

    client = SeashellClient(server, api_key)

    # Fire wake-on-key. Returns a job handle immediately. The CLI starts
    # the background poll so the EC2 boot happens in parallel with the
    # password prompt below.
    print(DIM + "  Waking your institution's server..." + RESET)
    wake = client.wake()
    if wake.error:
        # /wake itself failed (network unreachable, invalid key, etc).
        # Show the error before prompting for password — there's no
        # point continuing the login if the wake call won't go through.
        print("  Cannot reach server: %s" % wake.error)
        print("  Check your API key + network and try again.")
        sys.exit(1)
    wake.start_poll(max_seconds=120)

    if wake.state == "running":
        # Single-instance / dev mode — no actual wake needed.
        print(DIM + "  Server is already running." + RESET)
    else:
        # Production gateway → real EC2. Show the ETA hint.
        print(DIM + "  Started warm-up (~%ds). Continuing to login while it boots." % wake.eta + RESET)

    # Step 2: prompt for credentials. The wake is happening in the background.
    email = input(CYAN + "  Username: " + RESET).strip()
    password = getpass.getpass(CYAN + "  Password: " + RESET)

    # Step 3: validate credentials. The /auth/login call also cross-checks
    # that the user.institution matches the API key's institution — closes
    # the privilege-escalation gap. SeashellClient.login() attaches the
    # returned session token to all subsequent requests automatically.
    try:
        login_data = client.login(email, password)
    except RuntimeError as e:
        print("\n  Login failed: %s" % str(e))
        sys.exit(1)
    except Exception as e:
        print("\n  Connection error: %s" % str(e))
        sys.exit(1)

    inst = login_data.get("institution", "")

    # Step 4: block until the wake completes. Usually instant at this
    # point — the user just spent 5–15 seconds typing email + password
    # and the EC2 finished booting in parallel.
    if not wake.is_ready():
        print(DIM + "  Waiting for engine to finish loading..." + RESET, end="", flush=True)
        ready = wake.wait_until_ready(timeout=120)
        if not ready:
            print(" timeout")
            print("  The engine is taking longer than expected to start.")
            print("  Try running a query in a moment — the wake will retry on the first request.")
        else:
            print(" ok")

    # Step 5: persist ONLY the server URL across sessions. Credentials
    # (api_key, session_token, email) live only in this process's memory.
    # Closing the terminal = logged out. Every relaunch is a fresh login.
    # The server URL is the one thing worth remembering so the user doesn't
    # have to retype --server every time.
    config = {
        "server": server,
        "institution": inst,  # purely for the welcome line on next launch
    }
    save_config(config)

    # Final hello — show patient count if the engine is reachable.
    health = client.health()
    count = "?"
    if health:
        if health.get("status") == "engine_unreachable":
            print(DIM + "\n  Engine is still starting up. "
                  "Your first query may take ~30s." + RESET)
        count = health.get("patients", health.get("patient_count", "?"))
    print("\n  " + BOLD + "Authenticated." + RESET + " %s patients loaded. Ready.\n" % count)
    return client, config


def _poll_gwas(client, job_id, output_prefix=None, interval=4):
    """Poll a GWAS async job until complete, then display results, download TSV, plot."""
    import sys
    url = client.server + "/gwas/" + job_id
    print("  GWAS job %s started. Running association tests..." % job_id)
    start = time.time()
    while True:
        try:
            resp = client.session.get(url, timeout=30)
            if resp.status_code != 200:
                sys.stderr.write("  Poll error: HTTP %d\n" % resp.status_code)
                return
            job = resp.json()
            status = job.get("status", "")
            elapsed = int(time.time() - start)
            if status == "running":
                sys.stdout.write("\r  Running GWAS... (%ds elapsed)   " % elapsed)
                sys.stdout.flush()
            elif status in ("complete", "done"):
                sys.stdout.write("\r  Done. (%ds)%s\n" % (elapsed, " " * 20))
                result = job.get("result") or job
                _print_gwas_complete(result)
                # Download TSV and generate plots
                prefix = output_prefix or ("gwas_%s" % job_id)
                _download_and_plot_gwas(client, job_id, prefix,
                                        result.get("significance_threshold", 5e-8))
                return
            elif status in ("error", "failed"):
                print("\n  GWAS failed: %s" % job.get("error", "unknown"))
                return
        except Exception as e:
            sys.stderr.write("\n  Poll error: %s\n" % str(e))
        time.sleep(interval)


def _download_and_plot_gwas(client, job_id, output_prefix, sig_threshold=5e-8):
    """Download GWAS TSV + server-generated PNGs to local disk, then open them."""
    import os
    import subprocess
    import platform

    # Download TSV
    tsv_url = client.server + "/gwas/%s/download" % job_id
    tsv_path = "%s.tsv" % output_prefix
    try:
        r = client.session.get(tsv_url, timeout=120)
        if r.status_code == 200:
            with open(tsv_path, "wb") as f:
                f.write(r.content)
            print("  Saved: %s" % os.path.abspath(tsv_path))
        else:
            sys.stderr.write("  Could not download TSV (HTTP %d)\n" % r.status_code)
    except Exception as e:
        sys.stderr.write("  Could not download TSV: %s\n" % str(e))

    # Download plots generated server-side and open them
    def _open_file(path):
        try:
            if platform.system() == "Darwin":
                subprocess.Popen(["open", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception:
            pass

    for plot_name, url_suffix in [("manhattan", "manhattan"), ("qq", "qq")]:
        png_path = "%s_%s.png" % (output_prefix, plot_name)
        url = client.server + "/gwas/%s/%s" % (job_id, url_suffix)
        try:
            r = client.session.get(url, timeout=60)
            if r.status_code == 200:
                with open(png_path, "wb") as f:
                    f.write(r.content)
                print("  Saved: %s" % os.path.abspath(png_path))
                _open_file(os.path.abspath(png_path))
            else:
                sys.stderr.write("  Could not download %s plot (HTTP %d)\n" % (plot_name, r.status_code))
        except Exception as e:
            sys.stderr.write("  Could not download %s plot: %s\n" % (plot_name, str(e)))


def _poll_gwas_quantitative(client, job_id, output_prefix=None, interval=4):
    """Poll a quantitative GWAS job until complete, then download TSV + plots."""
    print("  Quantitative GWAS job %s started. Running linear score tests..." % job_id)
    start = time.time()
    while True:
        try:
            resp = client.session.get(client.server + "/gwas/" + job_id, timeout=30)
            if resp.status_code != 200:
                sys.stderr.write("  Poll error: HTTP %d\n" % resp.status_code)
                return
            job = resp.json()
            status = job.get("status", "")
            elapsed = int(time.time() - start)
            if status == "running":
                sys.stdout.write("\r  Running quantitative GWAS... (%ds elapsed)   " % elapsed)
                sys.stdout.flush()
            elif status in ("complete", "done"):
                sys.stdout.write("\r  Done. (%ds)%s\n" % (elapsed, " " * 20))
                result = job.get("result") or job
                _print_gwas_complete(result)
                prefix = output_prefix or ("gwas_quant_%s" % job_id)
                _download_and_plot_gwas(client, job_id, prefix,
                                        result.get("significance_threshold", 5e-8))
                return
            elif status in ("error", "failed"):
                print("\n  Quantitative GWAS failed: %s" % job.get("error", "unknown"))
                return
        except Exception as e:
            sys.stderr.write("\n  Poll error: %s\n" % str(e))
        time.sleep(interval)


def _poll_prs(client, job_id, output_prefix=None, interval=4):
    """Poll a PRS job until complete, then download distribution plot."""
    import os
    import subprocess
    import platform

    print("  PRS job %s started. Computing polygenic risk scores..." % job_id)
    start = time.time()
    while True:
        try:
            resp = client.session.get(client.server + "/prs/" + job_id, timeout=30)
            if resp.status_code != 200:
                sys.stderr.write("  Poll error: HTTP %d\n" % resp.status_code)
                return
            job = resp.json()
            status = job.get("status", "")
            elapsed = int(time.time() - start)
            if status == "running":
                sys.stdout.write("\r  Computing PRS... (%ds elapsed)   " % elapsed)
                sys.stdout.flush()
            elif status in ("complete", "done"):
                sys.stdout.write("\r  Done. (%ds)%s\n" % (elapsed, " " * 20))
                result = job.get("result") or {}
                n_used = result.get("n_variants_used", 0)
                n_clumped = result.get("n_variants_clumped", 0)
                n_input = result.get("n_variants_input", 0)
                n_patients = result.get("n_patients", 0)
                print("  Variants: %d input → %d after LD clumping → %d used" % (
                    n_input, n_input - n_clumped, n_used))
                print("  Patients scored: %d" % n_patients)
                scores = result.get("scores", [])
                if scores:
                    sorted_scores = sorted(scores, key=lambda s: s.get("z_score", 0) or 0, reverse=True)
                    print("  %-20s  %8s  %8s" % ("Patient", "Raw PRS", "Z-score"))
                    print("  " + "-" * 42)
                    for s in sorted_scores:
                        raw = s.get("raw_prs")
                        z = s.get("z_score")
                        raw_str = ("%.4f" % raw) if raw is not None else "N/A"
                        z_str = ("%.3f" % z) if z is not None else "N/A"
                        print("  %-20s  %8s  %8s" % (s.get("patient_id", "?"), raw_str, z_str))

                # Download and open distribution plot
                prefix = output_prefix or ("prs_%s" % job_id)
                dist_url = client.server + "/prs/%s/distribution" % job_id
                png_path = "%s_distribution.png" % prefix
                try:
                    r = client.session.get(dist_url, timeout=60)
                    if r.status_code == 200:
                        with open(png_path, "wb") as f:
                            f.write(r.content)
                        print("  Saved: %s" % os.path.abspath(png_path))
                        try:
                            if platform.system() == "Darwin":
                                subprocess.Popen(["open", png_path])
                            else:
                                subprocess.Popen(["xdg-open", png_path])
                        except Exception:
                            pass
                    else:
                        sys.stderr.write("  Could not download distribution plot (HTTP %d)\n" % r.status_code)
                except Exception as e:
                    sys.stderr.write("  Could not download distribution plot: %s\n" % str(e))
                return
            elif status in ("error", "failed"):
                print("\n  PRS failed: %s" % job.get("error", "unknown"))
                return
        except Exception as e:
            sys.stderr.write("\n  Poll error: %s\n" % str(e))
        time.sleep(interval)


def _poll_burden(client, job_id, output_prefix=None, interval=5):
    """Poll a Burden/SKAT job until complete, then download Manhattan plot."""
    import os
    import subprocess
    import platform

    print("  Burden job %s started. Running gene-level association test..." % job_id)
    start = time.time()
    while True:
        try:
            resp = client.session.get(client.server + "/burden/" + job_id, timeout=30)
            if resp.status_code != 200:
                sys.stderr.write("  Poll error: HTTP %d\n" % resp.status_code)
                return
            job = resp.json()
            status = job.get("status", "")
            elapsed = int(time.time() - start)
            if status == "running":
                sys.stdout.write("\r  Running gene burden test... (%ds elapsed)   " % elapsed)
                sys.stdout.flush()
            elif status in ("complete", "done"):
                sys.stdout.write("\r  Done. (%ds)%s\n" % (elapsed, " " * 20))
                result = job.get("result") or {}
                n_cases    = result.get("n_cases", 0)
                n_controls = result.get("n_controls", 0)
                n_tested   = result.get("total_genes_tested", 0)
                n_skipped  = result.get("total_genes_skipped", 0)
                n_sig      = result.get("n_significant", 0)
                method     = result.get("method", "?")
                print("  Method: %s  |  Cases: %d  Controls: %d" % (method.upper(), n_cases, n_controls))
                print("  Genes tested: %d  |  Skipped (no rare variants): %d" % (n_tested, n_skipped))
                print("  Significant genes: %d" % n_sig)
                hits = result.get("hits", [])
                if hits:
                    print("  %-20s  %4s  %10s  %10s  %10s  %8s" % (
                        "Gene", "Chr", "P", "P_Bonferroni", "P_FDR", "N_Vars"))
                    print("  " + "-" * 70)
                    for h in hits[:20]:
                        p = h.get("p", 1.0)
                        pb = h.get("p_bonferroni", 1.0)
                        pf = h.get("p_fdr", 1.0)
                        nv = h.get("n_variants", 0)
                        rho_str = ""
                        if h.get("rho") is not None:
                            rho_str = " (ρ=%.2f)" % h["rho"]
                        print("  %-20s  %4s  %10.2e  %10.2e  %10.2e  %8d%s" % (
                            h.get("gene", "?")[:20], str(h.get("chrom", "?")),
                            p, pb, pf, nv, rho_str))
                    if len(hits) > 20:
                        print("  ... and %d more" % (len(hits) - 20))

                # Download and open Manhattan plot
                prefix = output_prefix or ("burden_%s" % job_id[:8])
                if job.get("manhattan_url"):
                    manhattan_url = client.server + "/burden/%s/manhattan" % job_id
                    png_path = "%s_burden_manhattan.png" % prefix
                    try:
                        r = client.session.get(manhattan_url, timeout=60)
                        if r.status_code == 200:
                            with open(png_path, "wb") as f:
                                f.write(r.content)
                            print("  Saved: %s" % os.path.abspath(png_path))
                            try:
                                if platform.system() == "Darwin":
                                    subprocess.Popen(["open", png_path])
                                else:
                                    subprocess.Popen(["xdg-open", png_path])
                            except Exception:
                                pass
                        else:
                            sys.stderr.write("  Could not download Manhattan plot (HTTP %d)\n" % r.status_code)
                    except Exception as e:
                        sys.stderr.write("  Could not download Manhattan plot: %s\n" % str(e))
                return
            elif status in ("error", "failed"):
                print("\n  Burden test failed: %s" % job.get("error", "unknown"))
                return
        except Exception as e:
            sys.stderr.write("\n  Poll error: %s\n" % str(e))
        time.sleep(interval)


def _poll_ld_clump(client, job_id, output_prefix=None, interval=3):
    """Poll an LD clump job until complete, then download plot."""
    import os
    import subprocess
    import platform

    print("  LD clump job %s started." % job_id)
    start = time.time()
    while True:
        try:
            resp = client.session.get(client.server + "/ld_clump/" + job_id, timeout=30)
            if resp.status_code != 200:
                sys.stderr.write("  Poll error: HTTP %d\n" % resp.status_code)
                return
            job = resp.json()
            status = job.get("status", "")
            elapsed = int(time.time() - start)
            if status == "running":
                sys.stdout.write("\r  Running LD clumping... (%ds elapsed)   " % elapsed)
                sys.stdout.flush()
            elif status in ("complete", "done"):
                sys.stdout.write("\r  Done. (%ds)%s\n" % (elapsed, " " * 20))
                result = job.get("result") or {}
                n_input   = result.get("n_input", 0)
                n_passing = result.get("n_passing_p_threshold", n_input)
                n_index   = result.get("n_index", 0)
                n_clumped = result.get("n_clumped", 0)
                r2        = result.get("r2_threshold", 0.1)
                window    = result.get("window_bp", 250000)
                n_ref     = result.get("n_ref_patients", 0)
                print("  %d input variants  →  %d pass p-threshold  →  %d independent index (r²≤%.2f, %dkb window)" % (
                    n_input, n_passing, n_index, r2, window // 1000))
                print("  LD reference panel: %d patients  |  Clumped away: %d" % (n_ref, n_clumped))
                index_variants = result.get("index_variants", [])
                if index_variants:
                    print("  %-4s  %-10s  %-4s  %-4s  %10s  %10s" % (
                        "Chr", "Pos", "Ref", "Alt", "Beta", "P"))
                    print("  " + "-" * 50)
                    for v in index_variants[:20]:
                        print("  %-4s  %-10s  %-4s  %-4s  %10.4f  %10.2e" % (
                            v.get("chrom", "?"), v.get("pos", "?"),
                            v.get("ref", "?")[:4], v.get("alt", "?")[:4],
                            v.get("beta", 0.0), v.get("p", 1.0)))
                    if len(index_variants) > 20:
                        print("  ... and %d more" % (len(index_variants) - 20))

                # Download and open plot
                if job.get("plot_url"):
                    prefix = output_prefix or ("ld_clump_%s" % job_id[:8])
                    plot_url = client.server + "/ld_clump/%s/plot" % job_id
                    png_path = "%s_ld_clump.png" % prefix
                    try:
                        r = client.session.get(plot_url, timeout=60)
                        if r.status_code == 200:
                            with open(png_path, "wb") as f:
                                f.write(r.content)
                            print("  Saved: %s" % os.path.abspath(png_path))
                            try:
                                if platform.system() == "Darwin":
                                    subprocess.Popen(["open", png_path])
                                else:
                                    subprocess.Popen(["xdg-open", png_path])
                            except Exception:
                                pass
                    except Exception as e:
                        sys.stderr.write("  Could not download plot: %s\n" % str(e))
                return
            elif status in ("error", "failed"):
                print("\n  LD clump failed: %s" % job.get("error", "unknown"))
                return
        except Exception as e:
            sys.stderr.write("\n  Poll error: %s\n" % str(e))
        time.sleep(interval)


def _poll_trio(client, job_id, interval=5):
    """Poll a MENDELIAN TRIO job until complete, then display via display module."""
    from seashell.display import display_result
    print("  Trio analysis job %s started (whole-genome dosage reconstruction ~60-120s)." % job_id)
    start = time.time()
    while True:
        try:
            resp = client.session.get(client.server + "/trio/" + job_id, timeout=30)
            if resp.status_code != 200:
                sys.stderr.write("  Poll error: HTTP %d\n" % resp.status_code)
                return
            job = resp.json()
            status = job.get("status", "")
            elapsed = int(time.time() - start)
            if status == "running":
                sys.stdout.write("\r  Reconstructing dosages across 22 chromosomes... (%ds)   " % elapsed)
                sys.stdout.flush()
            elif status in ("complete", "done"):
                sys.stdout.write("\r  Done. (%ds)%s\n" % (elapsed, " " * 30))
                result = job.get("result") or {}
                display_result(result, "table", action="mendelian_trio")
                return
            elif status in ("error", "failed"):
                print("\n  Trio analysis failed: %s" % job.get("error", "unknown"))
                return
        except Exception as e:
            sys.stderr.write("\n  Poll error: %s\n" % str(e))
        time.sleep(interval)


def _poll_pgx(client, job_id, output_prefix=None, interval=3):
    """Poll a PGx star allele job until complete, then download heatmap."""
    import os
    import subprocess
    import platform

    print("  PGx job %s started." % job_id)
    start = time.time()
    while True:
        try:
            resp = client.session.get(client.server + "/pgx/" + job_id, timeout=30)
            if resp.status_code != 200:
                sys.stderr.write("  Poll error: HTTP %d\n" % resp.status_code)
                return
            job = resp.json()
            status = job.get("status", "")
            elapsed = int(time.time() - start)
            if status == "running":
                sys.stdout.write("\r  Calling star alleles... (%ds elapsed)   " % elapsed)
                sys.stdout.flush()
            elif status in ("complete", "done"):
                sys.stdout.write("\r  Done. (%ds)%s\n" % (elapsed, " " * 20))
                result = job.get("result") or {}
                pgx_results = result.get("results", [])
                genes_tested = result.get("genes_tested", [])
                n_patients = result.get("n_patients", 0)

                print("  Patients: %d  |  Genes: %s" % (n_patients, ", ".join(genes_tested)))

                # Group results by gene for display
                for gene in genes_tested:
                    gene_rows = [r for r in pgx_results if r.get("gene") == gene]
                    if not gene_rows:
                        continue
                    print("\n  %s" % gene)
                    print("  %-20s  %-12s  %-8s  %s" % ("Patient", "Diplotype", "Status", "Activity"))
                    print("  " + "-" * 60)
                    for r in gene_rows:
                        recs = r.get("recommendations", [])
                        rec_str = "; ".join(r2["drug"] for r2 in recs[:2]) if recs else "—"
                        print("  %-20s  %-12s  %-8s  %.1f    %s" % (
                            r.get("patient_id", "?")[:20],
                            r.get("diplotype", "?/?"),
                            r.get("metabolizer_status", "NM"),
                            r.get("activity_score", 2.0),
                            rec_str))

                # Download and open heatmap
                if job.get("plot_url"):
                    prefix = output_prefix or ("pgx_%s" % job_id[:8])
                    plot_url = client.server + "/pgx/%s/heatmap" % job_id
                    png_path = "%s_pgx_heatmap.png" % prefix
                    try:
                        r = client.session.get(plot_url, timeout=60)
                        if r.status_code == 200:
                            with open(png_path, "wb") as f:
                                f.write(r.content)
                            print("\n  Saved: %s" % os.path.abspath(png_path))
                            try:
                                if platform.system() == "Darwin":
                                    subprocess.Popen(["open", png_path])
                                else:
                                    subprocess.Popen(["xdg-open", png_path])
                            except Exception:
                                pass
                    except Exception as e:
                        sys.stderr.write("  Could not download heatmap: %s\n" % str(e))
                return
            elif status in ("error", "failed"):
                print("\n  PGx failed: %s" % job.get("error", "unknown"))
                return
        except Exception as e:
            sys.stderr.write("\n  Poll error: %s\n" % str(e))
        time.sleep(interval)


def _run_query(client, query_text, output_format="table", repl_state=None):
    """Execute a single query and display the result.

    If repl_state is provided, caches the result + action for the `more` command.
    """
    query_upper = query_text.strip().upper()

    # Detect async operations (upload/export/GWAS/PRS/Burden/LD) that need job polling
    is_upload = query_upper.startswith("UPLOAD ") or query_upper.startswith("INGEST ")
    is_export = query_upper.startswith("EXPORT ")
    is_gwas_quant = query_upper.startswith("GWAS QUANTITATIVE ")
    is_gwas = query_upper.startswith("GWAS ") and not is_gwas_quant
    is_prs = query_upper.startswith("PRS ")
    is_burden = query_upper.startswith("BURDEN ")
    is_ld_clump = query_upper.startswith("LD CLUMP ")
    is_pgx = query_upper.startswith("PGX ")
    is_trio = query_upper.startswith("MENDELIAN TRIO ")

    try:
        result = client.query(query_text)
    except PermissionError as e:
        sys.stderr.write("  Permission denied: %s\n" % str(e))
        return
    except RuntimeError as e:
        sys.stderr.write("  %s\n" % str(e))
        return
    except Exception as e:
        sys.stderr.write("  Error: %s\n" % str(e))
        return

    # Handle async jobs
    job_id = result.get("job_id")
    if job_id and is_gwas_quant:
        import re as _re
        _om = _re.search(r'\bOUTPUT\s+(\S+)', query_text, _re.IGNORECASE)
        _prefix = _om.group(1) if _om else result.get("output_prefix")
        _poll_gwas_quantitative(client, job_id, output_prefix=_prefix)
        return
    if job_id and is_gwas:
        # Extract OUTPUT prefix from query, e.g. "GWAS ... OUTPUT test_chr22"
        import re as _re
        _om = _re.search(r'\bOUTPUT\s+(\S+)', query_text, _re.IGNORECASE)
        _prefix = _om.group(1) if _om else result.get("output_prefix")
        _poll_gwas(client, job_id, output_prefix=_prefix)
        return
    if job_id and is_prs:
        import re as _re
        _om = _re.search(r'\bOUTPUT\s+(\S+)', query_text, _re.IGNORECASE)
        _prefix = _om.group(1) if _om else result.get("output_prefix")
        _poll_prs(client, job_id, output_prefix=_prefix)
        return
    if job_id and is_burden:
        import re as _re
        _om = _re.search(r'\bOUTPUT\s+(\S+)', query_text, _re.IGNORECASE)
        _prefix = _om.group(1) if _om else result.get("output_prefix")
        _poll_burden(client, job_id, output_prefix=_prefix)
        return
    if job_id and is_ld_clump:
        import re as _re
        _om = _re.search(r'\bOUTPUT\s+(\S+)', query_text, _re.IGNORECASE)
        _prefix = _om.group(1) if _om else result.get("output_prefix")
        _poll_ld_clump(client, job_id, output_prefix=_prefix)
        return
    if job_id and is_pgx:
        import re as _re
        _om = _re.search(r'\bOUTPUT\s+(\S+)', query_text, _re.IGNORECASE)
        _prefix = _om.group(1) if _om else result.get("output_prefix")
        _poll_pgx(client, job_id, output_prefix=_prefix)
        return
    if job_id and is_trio:
        _poll_trio(client, job_id)
        return
    # VCF export returns synchronously (no job_id) — handle inline
    if is_export and result.get("status") == "complete" and not job_id:
        variants = result.get("variants", result.get("num_variants", "?"))
        patients = result.get("patients", result.get("num_patients", "?"))
        print("  Export complete: %s variants across %s patient(s)" % (variants, patients))
        if result.get("download_url"):
            print("  Download: %s%s" % (
                getattr(client, "server", ""), result["download_url"]))
            print("  (Link expires in 24h)")
        elif result.get("destination"):
            print("  Delivered to: %s" % result["destination"])
        return

    if job_id and (is_upload or is_export):
        endpoint = "ingest_gql" if is_upload else "export"
        print("  Job started: %s" % job_id)
        print("  Patients: %s" % result.get("patients", result.get("num_patients", "?")))
        print()
        final = client.poll_job(endpoint, job_id, callback=print_job_progress)
        print()
        final_status = final.get("status", "unknown")
        if final.get("errors"):
            for err in final["errors"]:
                sys.stderr.write("  Error: %s — %s\n" % (
                    err.get("patient_id", "?"), err.get("error", "?")))
        elapsed = final.get("completed_at", 0) - final.get("started_at", 0)
        if final_status == "failed":
            sys.stderr.write("  Failed: no patients were ingested. "
                             "Check the errors above.\n")
        elif final_status == "complete_with_errors":
            completed = final.get("patients_completed", 0)
            total = final.get("patients_completed", 0) + len(final.get("errors", []))
            print("  Completed %d/%d patients in %.1fs (some errors — see above)" % (
                completed, total, elapsed))
        elif elapsed > 0:
            print("  Completed in %.1fs" % elapsed)
        return

    action = infer_action(query_text)
    display_result(result, output_format, action=action)

    # Cache result for `more` command
    if repl_state is not None:
        repl_state["last_result"] = result
        repl_state["last_action"] = action
        repl_state["last_offset"] = 25  # default page size already shown


def _repl(client, config):
    """Interactive REPL loop."""
    repl_state = {"last_result": None, "last_action": None, "last_offset": 0}

    while True:
        try:
            query = input(CYAN + "seashell> " + RESET).strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Goodbye.")
            break

        if not query:
            continue

        lower = query.lower()

        if lower in ("exit", "quit", "q"):
            print("  Goodbye.")
            break
        elif lower == "help":
            print(HELP_TEXT)
        elif lower == "status":
            print("  Server:      %s" % config.get("server", "?"))
            print("  Institution: %s" % config.get("institution", "?"))
            print("  User:        %s" % config.get("email", "?"))
            health = client.health()
            if health:
                print("  Patients:    %s" % health.get("patients", health.get("patient_count", "?")))
                print("  Engine:      %s" % health.get("status", "?"))
            else:
                print("  Server:      unreachable")
        elif lower == "logout":
            clear_config()
            print("  Credentials cleared. Run 'seashell' to log in again.")
            break
        elif lower in ("more", "next"):
            if repl_state["last_result"] is None:
                print("  No previous query to expand. Run a query first.")
            else:
                new_offset = show_more(
                    repl_state["last_result"],
                    repl_state["last_action"],
                    repl_state["last_offset"])
                if new_offset is not None:
                    repl_state["last_offset"] = new_offset
        else:
            _run_query(client, query, repl_state=repl_state)


def main():
    """Entry point for the seashell CLI."""
    args = sys.argv[1:]

    # --help flag
    if args and args[0] in ("--help", "-h"):
        print("Usage:")
        print("  seashell                              Interactive mode")
        print("  seashell \"LIST PATIENTS\"               Single query")
        print("  seashell --server URL                  Set server URL")
        print("  seashell --format json \"LIST PATIENTS\" Output as JSON")
        print()
        print(HELP_TEXT)
        return

    # Parse flags
    server_override = None
    output_format = "table"
    query_parts = []

    i = 0
    while i < len(args):
        if args[i] == "--server" and i + 1 < len(args):
            server_override = args[i + 1]
            i += 2
        elif args[i] == "--format" and i + 1 < len(args):
            output_format = args[i + 1]
            i += 2
        elif args[i] == "--json":
            output_format = "json"
            i += 1
        elif args[i] == "--tsv":
            output_format = "tsv"
            i += 1
        else:
            query_parts.append(args[i])
            i += 1

    # Apply server override
    if server_override:
        config = load_config()
        config["server"] = server_override
        save_config(config)

    if query_parts:
        # Single query mode
        query_text = " ".join(query_parts)
        config = load_config()
        if not config.get("api_key"):
            # Not logged in — prompt first
            client, config = _prompt_login()
        else:
            client = SeashellClient(
                config.get("server", DEFAULT_SERVER),
                config["api_key"])
        _run_query(client, query_text, output_format)
    else:
        # Interactive mode
        client, config = _prompt_login()
        _repl(client, config)


if __name__ == "__main__":
    main()
