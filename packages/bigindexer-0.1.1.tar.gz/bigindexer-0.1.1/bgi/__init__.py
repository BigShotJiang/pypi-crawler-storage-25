"""BGI — Bio-Gate Indexing"""
