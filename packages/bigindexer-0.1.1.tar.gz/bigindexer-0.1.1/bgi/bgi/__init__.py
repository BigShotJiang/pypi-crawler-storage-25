"""BGI — Big Indexer"""
