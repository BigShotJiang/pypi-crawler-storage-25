"""
Internal utilities.
"""