"""Agent implementations."""

