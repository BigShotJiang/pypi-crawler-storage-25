"""
Platform Configuration

Centralized platform endpoints and API path profiles for all Timeback services.
This is the single source of truth for platform URLs and paths.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, TypedDict

# ═══════════════════════════════════════════════════════════════════════════════
# TYPE DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════════════

Platform = Literal["BEYOND_AI", "LEARNWITH_AI"]
Environment = Literal["staging", "production"]

DEFAULT_PLATFORM: Platform = "BEYOND_AI"


class PlatformEndpointConfig(TypedDict):
    """Endpoint bundle for a platform."""

    api: dict[Environment, str]
    caliper: dict[Environment, str]
    qti: dict[Environment, str]
    token: dict[Environment, str]
    tokenScope: str | None


# ═══════════════════════════════════════════════════════════════════════════════
# BEYONDAI PLATFORM ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

BEYONDAI_TOKEN_URLS: dict[Environment, str] = {
    "staging": "https://staging-beyond-timeback-api-2-idp.auth.us-east-1.amazoncognito.com/oauth2/token",
    "production": "https://prod-beyond-timeback-api-2-idp.auth.us-east-1.amazoncognito.com/oauth2/token",
}

BEYONDAI_API_URLS: dict[Environment, str] = {
    "staging": "https://api.staging.alpha-1edtech.ai",
    "production": "https://api.alpha-1edtech.ai",
}

BEYONDAI_CALIPER_URLS: dict[Environment, str] = {
    "staging": "https://caliper.staging.alpha-1edtech.ai",
    "production": "https://caliper.alpha-1edtech.ai",
}

BEYONDAI_QTI_URLS: dict[Environment, str] = {
    "staging": "https://qti.alpha-1edtech.ai/api",
    "production": "https://qti.alpha-1edtech.ai/api",
}

BEYONDAI_ENDPOINTS: PlatformEndpointConfig = {
    "api": BEYONDAI_API_URLS,
    "caliper": BEYONDAI_CALIPER_URLS,
    "qti": BEYONDAI_QTI_URLS,
    "token": BEYONDAI_TOKEN_URLS,
    "tokenScope": None,
}

# ═══════════════════════════════════════════════════════════════════════════════
# LEARNWITHAI PLATFORM ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

LEARNWITHAI_TOKEN_URLS: dict[Environment, str] = {
    "staging": "https://platform.dev.timeback.com/auth/1.0/token",
    "production": "https://platform.timeback.com/auth/1.0/token",
}

LEARNWITHAI_API_URLS: dict[Environment, str] = {
    "staging": "https://platform.dev.timeback.com",
    "production": "https://platform.timeback.com",
}

LEARNWITHAI_CALIPER_URLS: dict[Environment, str] = {
    "staging": "https://platform.dev.timeback.com",
    "production": "https://platform.timeback.com",
}

LEARNWITHAI_QTI_URLS: dict[Environment, str] = {
    "staging": "https://platform.dev.timeback.com",
    "production": "https://platform.timeback.com",
}

LEARNWITHAI_ENDPOINTS: PlatformEndpointConfig = {
    "api": LEARNWITHAI_API_URLS,
    "caliper": LEARNWITHAI_CALIPER_URLS,
    "qti": LEARNWITHAI_QTI_URLS,
    "token": LEARNWITHAI_TOKEN_URLS,
    "tokenScope": "https://purl.imsglobal.org/spec/caliper/v1p2/scope/events.write",
}

# ═══════════════════════════════════════════════════════════════════════════════
# PLATFORM ENDPOINT MAP
# ═══════════════════════════════════════════════════════════════════════════════

PLATFORM_ENDPOINTS: dict[Platform, PlatformEndpointConfig] = {
    "BEYOND_AI": BEYONDAI_ENDPOINTS,
    "LEARNWITH_AI": LEARNWITHAI_ENDPOINTS,
}

# ═══════════════════════════════════════════════════════════════════════════════
# PATH PROFILE DATACLASSES
# ═══════════════════════════════════════════════════════════════════════════════


@dataclass
class CaliperPaths:
    """Caliper API path profiles."""

    send: str
    validate: str | None
    list: str | None
    get: str | None
    job_status: str | None


@dataclass
class OneRosterPaths:
    """OneRoster API path profiles."""

    rostering: str = "/ims/oneroster/rostering/v1p2"
    gradebook: str = "/ims/oneroster/gradebook/v1p2"
    resources: str = "/ims/oneroster/resources/v1p2"


@dataclass
class EdubridgePaths:
    """EduBridge API path profiles."""

    base: str = "/edubridge"


@dataclass
class PowerPathPaths:
    """PowerPath API path profiles."""

    base: str = "/powerpath"


@dataclass
class QtiPaths:
    """QTI API path profiles."""

    base: str = ""


@dataclass
class ClrPaths:
    """CLR (Comprehensive Learner Record) API path profiles."""

    credentials: str = "/ims/clr/v2p0/credentials"
    discovery: str = "/ims/clr/v2p0/discovery"


@dataclass
class CasePaths:
    """CASE (Competency and Academic Standards Exchange) API path profiles."""

    base: str = "/ims/case/v1p1"


@dataclass
class WebhookPaths:
    """Webhook API path profiles."""

    webhook_list: str = "/webhooks/"
    webhook_get: str = "/webhooks/{id}"
    webhook_create: str = "/webhooks/"
    webhook_update: str = "/webhooks/{id}"
    webhook_delete: str = "/webhooks/{id}"
    webhook_activate: str = "/webhooks/{id}/activate"
    webhook_deactivate: str = "/webhooks/{id}/deactivate"
    webhook_filter_list: str = "/webhook-filters/"
    webhook_filter_get: str = "/webhook-filters/{id}"
    webhook_filter_create: str = "/webhook-filters/"
    webhook_filter_update: str = "/webhook-filters/{id}"
    webhook_filter_delete: str = "/webhook-filters/{id}"
    webhook_filters_by_webhook: str = "/webhook-filters/webhook/{webhookId}"


@dataclass
class PlatformPaths:
    """All service path profiles for a platform."""

    oneroster: OneRosterPaths
    edubridge: EdubridgePaths | None  # None means unsupported on platform
    caliper: CaliperPaths
    powerpath: PowerPathPaths | None
    qti: QtiPaths
    clr: ClrPaths | None = None  # None means unsupported on platform
    case: CasePaths | None = None  # None means unsupported on platform
    webhooks: WebhookPaths | None = None  # None means unsupported on platform


# ═══════════════════════════════════════════════════════════════════════════════
# BEYONDAI PATHS
# ═══════════════════════════════════════════════════════════════════════════════

BEYONDAI_CALIPER_PATHS = CaliperPaths(
    send="/caliper/event",
    validate="/caliper/event/validate",
    list="/caliper/events",
    get="/caliper/events/{id}",
    job_status="/jobs/{id}/status",
)

BEYONDAI_ONEROSTER_PATHS = OneRosterPaths()

BEYONDAI_EDUBRIDGE_PATHS = EdubridgePaths()

BEYONDAI_POWERPATH_PATHS = PowerPathPaths()

BEYONDAI_QTI_PATHS = QtiPaths()

BEYONDAI_CLR_PATHS = ClrPaths()

BEYONDAI_CASE_PATHS = CasePaths()

BEYONDAI_WEBHOOK_PATHS = WebhookPaths()

BEYONDAI_PATHS = PlatformPaths(
    oneroster=BEYONDAI_ONEROSTER_PATHS,
    edubridge=BEYONDAI_EDUBRIDGE_PATHS,
    caliper=BEYONDAI_CALIPER_PATHS,
    powerpath=BEYONDAI_POWERPATH_PATHS,
    qti=BEYONDAI_QTI_PATHS,
    clr=BEYONDAI_CLR_PATHS,
    case=BEYONDAI_CASE_PATHS,
    webhooks=BEYONDAI_WEBHOOK_PATHS,
)

# ═══════════════════════════════════════════════════════════════════════════════
# LEARNWITHAI PATHS
# ═══════════════════════════════════════════════════════════════════════════════

LEARNWITHAI_CALIPER_PATHS = CaliperPaths(
    send="/caliper/v1p2",
    validate=None,
    list=None,
    get=None,
    job_status=None,
)

LEARNWITHAI_ONEROSTER_PATHS = OneRosterPaths(
    rostering="/rostering/1.0",
    gradebook="/gradebook/1.0",
    resources="/resources/1.0",
)

# EduBridge not supported on LearnWith.AI
LEARNWITHAI_EDUBRIDGE_PATHS = None

# PowerPath not supported on LearnWith.AI
LEARNWITHAI_POWERPATH_PATHS = None

LEARNWITHAI_QTI_PATHS = QtiPaths()

# CLR and Webhooks not supported on LearnWith.AI
LEARNWITHAI_CLR_PATHS = None
LEARNWITHAI_CASE_PATHS = CasePaths(base="/case/1.1")
LEARNWITHAI_WEBHOOK_PATHS = None

LEARNWITHAI_PATHS = PlatformPaths(
    oneroster=LEARNWITHAI_ONEROSTER_PATHS,
    edubridge=None,  # Not supported on LearnWith.AI
    caliper=LEARNWITHAI_CALIPER_PATHS,
    powerpath=LEARNWITHAI_POWERPATH_PATHS,
    qti=LEARNWITHAI_QTI_PATHS,
    clr=None,  # Not supported on LearnWith.AI
    case=LEARNWITHAI_CASE_PATHS,
    webhooks=None,  # Not supported on LearnWith.AI
)

# ═══════════════════════════════════════════════════════════════════════════════
# PLATFORM PATH MAP
# ═══════════════════════════════════════════════════════════════════════════════

PLATFORM_CALIPER_PATHS: dict[str, CaliperPaths] = {
    "BEYOND_AI": BEYONDAI_CALIPER_PATHS,
    "LEARNWITH_AI": LEARNWITHAI_CALIPER_PATHS,
}

PLATFORM_ONEROSTER_PATHS: dict[str, OneRosterPaths] = {
    "BEYOND_AI": BEYONDAI_ONEROSTER_PATHS,
    "LEARNWITH_AI": LEARNWITHAI_ONEROSTER_PATHS,
}

PLATFORM_PATHS: dict[str, PlatformPaths] = {
    "BEYOND_AI": BEYONDAI_PATHS,
    "LEARNWITH_AI": LEARNWITHAI_PATHS,
}


__all__ = [
    "BEYONDAI_API_URLS",
    "BEYONDAI_CALIPER_PATHS",
    "BEYONDAI_CASE_PATHS",
    "BEYONDAI_CLR_PATHS",
    "BEYONDAI_ONEROSTER_PATHS",
    "BEYONDAI_POWERPATH_PATHS",
    "BEYONDAI_QTI_PATHS",
    "BEYONDAI_TOKEN_URLS",
    "BEYONDAI_WEBHOOK_PATHS",
    "DEFAULT_PLATFORM",
    "PLATFORM_CALIPER_PATHS",
    "PLATFORM_ENDPOINTS",
    "CaliperPaths",
    "CasePaths",
    "ClrPaths",
    "EdubridgePaths",
    "Environment",
    "OneRosterPaths",
    "Platform",
    "PlatformPaths",
    "PowerPathPaths",
    "QtiPaths",
    "WebhookPaths",
]
