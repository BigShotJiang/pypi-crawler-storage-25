"""Meta-installer that runs every install-* skill in dependency order.

Strategy:
- Tools are grouped into tiers. Each tier installs in parallel-friendly groups
  but the meta-installer runs sequentially for clear log output.
- A tool can be REQUIRED (failure aborts), OPTIONAL (failure logged, continue),
  or SKIP_ON_MISSING_ENV (silently skipped when its env vars are absent).
- Each tool exposes a `get_state()` function that says whether work is needed.
  We call it first; if `needs_install` is false the tool is reported `skipped`.
"""

import importlib
import json
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Annotated, Any

import typer


class Mode(StrEnum):
    REQUIRED = "required"
    OPTIONAL = "optional"


@dataclass(frozen=True)
class Tool:
    """One install-* skill to orchestrate."""

    name: str
    module: str  # import path, e.g. "pysae_ai_tools.install.glab"
    mode: Mode = Mode.OPTIONAL
    env_required: tuple[str, ...] = ()  # env vars needed for SKIP_ON_MISSING_ENV mode
    env_help: dict[str, str] = field(default_factory=dict)  # var → how to get it


# Order matters: foundational tools first, dependents next.
TOOLS: tuple[Tool, ...] = (
    # Tier 1 — auth foundations (REQUIRED: many downstream tools need these)
    # aws-cli must run first: kubectl/EKS, mongodb-atlas-mcp (Secrets Manager), env secret all depend on it.
    Tool("aws-cli", "pysae_ai_tools.install.aws_cli", Mode.REQUIRED),
    Tool("glab", "pysae_ai_tools.install.glab", Mode.REQUIRED),
    Tool("gh", "pysae_ai_tools.install.gh", Mode.OPTIONAL),
    # Tier 2 — Kubernetes stack (depends on aws-cli for EKS)
    Tool("kubectl", "pysae_ai_tools.install.kubectl", Mode.OPTIONAL),
    Tool("helm", "pysae_ai_tools.install.helm", Mode.OPTIONAL),
    Tool("argocd", "pysae_ai_tools.install.argocd", Mode.OPTIONAL),
    # Tier 3 — generic tools
    Tool("docker", "pysae_ai_tools.install.docker", Mode.OPTIONAL),
    Tool("terraform", "pysae_ai_tools.install.terraform", Mode.OPTIONAL),
    Tool("prefect", "pysae_ai_tools.install.prefect", Mode.OPTIONAL),
    Tool("mongo-tools", "pysae_ai_tools.install.mongo_tools", Mode.OPTIONAL),
    Tool("postman", "pysae_ai_tools.install.postman", Mode.OPTIONAL),
    # Tier 4 — MCP servers (no env vars needed)
    Tool("chrome-mcp", "pysae_ai_tools.install.chrome_mcp", Mode.OPTIONAL),
    # Tier 5 — MCP servers requiring secrets
    Tool(
        "datadog-mcp",
        "pysae_ai_tools.install.datadog_mcp",
        Mode.OPTIONAL,
        env_required=("DD_API_KEY", "DD_APP_KEY"),
        env_help={
            "DD_API_KEY": "Datadog → Organization Settings → API Keys → New Key",
            "DD_APP_KEY": "Datadog → Organization Settings → Application Keys → New Key",
        },
    ),
    Tool(
        "postman-mcp",
        "pysae_ai_tools.install.postman_mcp",
        Mode.OPTIONAL,
        env_required=("POSTMAN_API_KEY",),
        env_help={
            "POSTMAN_API_KEY": "Postman → Settings → API Keys → Generate API Key",
        },
    ),
    Tool(
        "mongo-mcp",
        "pysae_ai_tools.install.mongo_mcp",
        Mode.OPTIONAL,
        env_required=("MONGO_URI_DEV", "MONGO_URI_PROD"),
        env_help={
            "MONGO_URI_DEV": (
                "pysae-ai-tools env secret get pysae/local-dev/secrets "
                "api-mongo-uri --show-value  # fallback: pysae/dev/secrets"
            ),
            "MONGO_URI_PROD": (
                "pysae-ai-tools env secret get pysae/local-prod/secrets "
                "api-mongo-uri --show-value  # fallback: pysae/prod/secrets"
            ),
        },
    ),
    Tool(
        "mongodb-atlas-mcp",
        "pysae_ai_tools.install.mongodb_atlas_mcp",
        Mode.OPTIONAL,
        # Pulls keys from AWS Secrets Manager at install time — no env required.
    ),
)


@dataclass
class Result:
    name: str
    status: str  # "installed" | "up-to-date" | "skipped" | "failed"
    detail: dict[str, Any] = field(default_factory=dict)
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"name": self.name, "status": self.status}
        if self.detail:
            out["detail"] = self.detail
        if self.error:
            out["error"] = self.error
        return out


def _resolve_callables(module_path: str) -> tuple[Callable[[], Any] | None, Callable[[], Any] | None]:
    """Return (get_state, do_install) callables from the tool module, if present."""
    mod = importlib.import_module(module_path)
    get_state = getattr(mod, "get_state", None)
    do_install = getattr(mod, "do_install", None)
    return get_state, do_install


def _state_needs_work(state_obj: Any) -> bool:
    """Check whether a get_state() return value indicates any work is needed (install or update)."""
    if state_obj is None:
        return True
    to_dict = getattr(state_obj, "to_dict", None)
    if not callable(to_dict):
        return True
    payload = to_dict()
    if not isinstance(payload, dict):
        return True
    for k, v in payload.items():
        if isinstance(k, str) and (k.startswith("needs_install") or k.startswith("needs_update")) and v:
            return True
    return False


def _state_is_installed(state_obj: Any) -> bool:
    """Check whether a get_state() return value indicates the tool is installed (ignoring updates)."""
    if state_obj is None:
        return False
    to_dict = getattr(state_obj, "to_dict", None)
    if not callable(to_dict):
        return False
    payload = to_dict()
    if not isinstance(payload, dict):
        return False
    # If any needs_install* key is True, it's not fully installed
    for k, v in payload.items():
        if isinstance(k, str) and k.startswith("needs_install") and v:
            return False
    # If we got state data, it means the tool is at least partially detectable
    # Check for explicit installed indicators
    if "binary" in payload and isinstance(payload["binary"], dict):
        return bool(payload["binary"].get("installed"))
    # If no needs_install is True and we have state data, consider it installed
    return True


def _install_one(tool: Tool, *, dry_run: bool, interactive: bool = False) -> Result:
    # Resolve missing env vars (auto-resolve always, prompt only in interactive mode)
    if tool.env_required and not all(os.environ.get(v) for v in tool.env_required):
        from .common.interactive import ensure_env_vars

        if not ensure_env_vars(tool.env_required, tool.name, tool.env_help, interactive=interactive):
            return Result(name=tool.name, status="skipped", detail={"reason": "missing env vars"})

    try:
        get_state, do_install = _resolve_callables(tool.module)
    except Exception as exc:  # noqa: BLE001
        return Result(name=tool.name, status="failed", error=f"import: {exc}")

    state_payload: dict[str, Any] = {}
    if get_state is not None:
        try:
            state_obj = get_state()
            state_payload = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
        except Exception:  # noqa: BLE001
            state_obj = None
            state_payload = {}
        if not _state_needs_work(state_obj):
            return Result(name=tool.name, status="up-to-date", detail=state_payload)

    if dry_run:
        return Result(name=tool.name, status="installed", detail={"dry_run": True, **state_payload})

    if do_install is None:
        return Result(name=tool.name, status="failed", error="module has no do_install()")

    try:
        report = do_install()
    except Exception as exc:  # noqa: BLE001
        return Result(name=tool.name, status="failed", error=str(exc))

    payload = report.to_dict() if hasattr(report, "to_dict") else {}
    if isinstance(payload, dict) and payload.get("error"):
        return Result(name=tool.name, status="failed", error=str(payload["error"]), detail=payload)
    return Result(name=tool.name, status="installed", detail=payload if isinstance(payload, dict) else {})


def install_all(
    *,
    dry_run: bool = False,
    interactive: bool = False,
    only: tuple[str, ...] = (),
    skip: tuple[str, ...] = (),
) -> list[Result]:
    results: list[Result] = []
    for tool in TOOLS:
        if only and tool.name not in only:
            continue
        if tool.name in skip:
            results.append(Result(name=tool.name, status="skipped", detail={"reason": "user-skipped"}))
            continue
        result = _install_one(tool, dry_run=dry_run, interactive=interactive)
        results.append(result)
        # On REQUIRED failure, abort the chain
        if tool.mode is Mode.REQUIRED and result.status == "failed":
            results.append(
                Result(name="__abort__", status="failed", error=f"{tool.name} is REQUIRED — aborting remaining tools")
            )
            break
    return results


def _tool_is_installed(tool: Tool) -> bool:
    """Quick check if a tool is installed (for filtering env var display)."""
    try:
        get_state, _ = _resolve_callables(tool.module)
        if get_state is not None:
            return _state_is_installed(get_state())
    except Exception:  # noqa: BLE001
        pass
    return False


def _extract_identity(tool: "Tool", payload: dict[str, Any]) -> list[tuple[str, str | None]]:
    """Extract identity/context lines by delegating to the tool's extract_identity method."""
    try:
        mod = importlib.import_module(tool.module)
        tool_instance = getattr(mod, "_tool", None)
        if tool_instance is not None and hasattr(tool_instance, "extract_identity"):
            return list(tool_instance.extract_identity(payload))
    except Exception:  # noqa: BLE001
        pass
    return []


def _render_tool_status(tool: Tool) -> str:
    """Render a single tool's status line. Returns the detected status
    (``installed`` / ``needs-update`` / ``missing``).
    """
    import shutil

    found = False
    state_payload: dict[str, Any] = {}

    try:
        get_state, _ = _resolve_callables(tool.module)
        if get_state is not None:
            state_obj = get_state()
            state_payload = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
            found = _state_is_installed(state_obj)
    except Exception:  # noqa: BLE001
        pass

    if not found and not state_payload:
        found = shutil.which(tool.name) is not None

    needs_update = found and any(
        isinstance(k, str) and k.startswith("needs_update") and v for k, v in state_payload.items()
    )
    if not found:
        icon = "✗"
        color = typer.colors.RED
    elif needs_update:
        icon = "⬆"
        color = typer.colors.YELLOW
    else:
        icon = "✓"
        color = typer.colors.GREEN
    mode_tag = f" ({tool.mode.value})" if tool.mode != Mode.OPTIONAL else ""

    env_parts: list[str] = []
    if not found:
        for var in tool.env_required:
            if os.environ.get(var):
                env_parts.append(f"  ✓ ${var}")
            else:
                env_parts.append(f"  ✗ ${var}")

    identity_lines = _extract_identity(tool, state_payload)

    update_hint = ""
    if needs_update:
        current = state_payload.get("binary", {}).get("version", "")
        latest = state_payload.get("latest", "")
        if current and latest:
            update_hint = f" ({current} → {latest})"
        elif latest:
            update_hint = f" (→ {latest})"

    has_details = bool(identity_lines or env_parts)
    typer.secho(f"  {icon} {tool.name:<20}{update_hint}{mode_tag}", fg=color, nl=not has_details)
    if has_details:
        typer.echo("")
    for text, line_color in identity_lines:
        typer.secho(f"      {text}", fg=line_color or typer.colors.BRIGHT_BLACK)
    for part in env_parts:
        var_set = part.startswith("  ✓")
        typer.secho(f"    {part}", fg=typer.colors.GREEN if var_set else typer.colors.YELLOW)

    if not found:
        return "missing"
    if needs_update:
        return "needs-update"
    return "installed"


def _status_one(tool: Tool) -> None:
    """Show status for a single tool."""
    _render_tool_status(tool)


SECTION_TOOLS = "🔧 Tools"
SECTION_ENV = "🔑 Environment variables"
SECTION_SUMMARY = "📊 Summary"
SECTION_RULE = "─" * 60


def _section_header(title: str) -> None:
    typer.echo("")
    typer.echo(f"  {title}")
    typer.echo(f"  {SECTION_RULE}")


def _status_all() -> None:
    """Show installed/missing tools and required environment variables."""
    _section_header(SECTION_TOOLS)

    counts = {"installed": 0, "needs-update": 0, "missing": 0}
    for tool in TOOLS:
        status = _render_tool_status(tool)
        counts[status] = counts.get(status, 0) + 1

    tools_with_env = [t for t in TOOLS if t.env_required and not _tool_is_installed(t)]
    if tools_with_env:
        _section_header(SECTION_ENV)
        for tool in tools_with_env:
            typer.echo(f"  {tool.name}:")
            for var in tool.env_required:
                present = bool(os.environ.get(var))
                icon = "✓" if present else "✗"
                color = typer.colors.GREEN if present else typer.colors.YELLOW
                typer.secho(f"    {icon} ${var}", fg=color)
                if not present and var in tool.env_help:
                    typer.secho(f"      → {tool.env_help[var]}", fg=typer.colors.BRIGHT_BLACK)
            typer.echo("")

    _section_header(SECTION_SUMMARY)
    summary = ", ".join(f"{v} {k}" for k, v in counts.items() if v)
    typer.echo(f"  {summary or 'no tools'}")


def _preresolve_envs(tools: tuple[Tool, ...], interactive: bool) -> dict[str, list[str]]:
    """Resolve env vars across all tools. Emits the ``✓ $VAR resolved from …``
    lines (and ``✗ …`` for unresolved). Returns ``{tool_name: [missing_vars]}``.

    Each distinct env var is tried at most once, even when several tools share it.
    """
    from ..env.resolve import try_auto_resolve
    from .common.interactive import prompt_env_var

    missing: dict[str, list[str]] = {}
    tried: set[str] = set()
    for tool in tools:
        for var in tool.env_required:
            if os.environ.get(var):
                continue
            if var not in tried:
                tried.add(var)
                if try_auto_resolve(var) is not None:
                    continue
                if interactive:
                    prompt_env_var(var, tool.name, tool.env_help.get(var, ""))
            if not os.environ.get(var):
                missing.setdefault(tool.name, []).append(var)
    return missing


def _render_install_result(r: Result) -> None:
    """Render a single install result with icon + color, matching status style."""
    if r.status == "up-to-date":
        icon, color = "✓", typer.colors.GREEN
    elif r.status == "installed":
        icon, color = "⬆", typer.colors.YELLOW
    elif r.status == "skipped":
        icon, color = "⊘", typer.colors.BRIGHT_BLACK
    else:  # failed
        icon, color = "✗", typer.colors.RED

    tool = _find_tool(r.name)
    mode_tag = f" ({tool.mode.value})" if tool is not None and tool.mode != Mode.OPTIONAL else ""

    suffix = ""
    if r.status == "installed" and isinstance(r.detail, dict):
        version = r.detail.get("version", "")
        if version:
            suffix = f" → {version}"
    if r.error:
        suffix = f" — {r.error}"
    elif r.status == "skipped" and isinstance(r.detail, dict):
        reason = r.detail.get("reason")
        if reason:
            suffix = f" — {reason}"

    typer.secho(f"  {icon} {r.name:<20} {r.status}{suffix}{mode_tag}", fg=color)


def _install_pretty(
    *,
    skip: tuple[str, ...],
    interactive: bool,
) -> list[Result]:
    """Run the install pipeline with grouped 'Environment variables' + 'Tools' sections."""
    tools_to_run = tuple(t for t in TOOLS if t.name not in skip)

    # --- Section 1: environment variables (only shown if something needs resolving). ---
    needs_env_section = any(
        tool.env_required and any(not os.environ.get(v) for v in tool.env_required) for tool in tools_to_run
    )
    missing_envs: dict[str, list[str]] = {}
    if needs_env_section:
        _section_header(SECTION_ENV)
        missing_envs = _preresolve_envs(tools_to_run, interactive=interactive)
        # Show red lines for still-missing vars, grouped per tool.
        for tool_name, vars_left in missing_envs.items():
            for var in vars_left:
                typer.secho(f"  ✗ ${var} not set — {tool_name} will be skipped", fg=typer.colors.RED)

    # --- Section 2: tools. ---
    _section_header(SECTION_TOOLS)

    results: list[Result] = []
    for tool in tools_to_run:
        if tool.name in missing_envs:
            result = Result(name=tool.name, status="skipped", detail={"reason": "missing env vars"})
        else:
            # Env vars are already in os.environ at this point, so ensure_env_vars
            # inside _install_one will be a no-op.
            result = _install_one(tool, dry_run=False, interactive=interactive)
        results.append(result)
        _render_install_result(result)

        if tool.mode is Mode.REQUIRED and result.status == "failed":
            abort = Result(
                name="__abort__",
                status="failed",
                error=f"{tool.name} is REQUIRED — aborting remaining tools",
            )
            results.append(abort)
            typer.secho(f"  ✗ aborted — {abort.error}", fg=typer.colors.RED)
            break
    return results


def _find_tool(name: str) -> Tool | None:
    """Find a tool by name."""
    for t in TOOLS:
        if t.name == name:
            return t
    return None


TOOL_NAMES = [t.name for t in TOOLS]


# ---------------------------------------------------------------------------
# Unified CLI: pysae-ai-tools tools <command> [tool-name]
# ---------------------------------------------------------------------------

cli = typer.Typer(no_args_is_help=True, help="Install, check, and manage Pysae CLI tools and MCP servers")


@cli.command()
def status(
    tool_name: Annotated[str | None, typer.Argument(help="Tool name (default: all)")] = None,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
) -> None:
    """Show installed/missing tools and required environment variables."""
    if tool_name:
        tool = _find_tool(tool_name)
        if not tool:
            typer.echo(f"Unknown tool: {tool_name}. Available: {', '.join(TOOL_NAMES)}", err=True)
            raise typer.Exit(code=1)
        if json_output:
            try:
                get_state, _ = _resolve_callables(tool.module)
                if get_state is not None:
                    state_obj = get_state()
                    typer.echo(json.dumps(state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}))
            except Exception as exc:  # noqa: BLE001
                typer.echo(json.dumps({"error": str(exc)}))
                raise typer.Exit(code=1) from None
        else:
            _status_one(tool)
    else:
        if json_output:
            # Collect state for each tool without installing or resolving env vars
            all_states: list[dict[str, Any]] = []
            for tool in TOOLS:
                try:
                    get_state_fn, _ = _resolve_callables(tool.module)
                    if get_state_fn is not None:
                        state_obj = get_state_fn()
                        d = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
                        d["name"] = tool.name
                        all_states.append(d)
                except Exception:  # noqa: BLE001
                    all_states.append({"name": tool.name, "error": "failed to get state"})
            typer.echo(json.dumps(all_states))
        else:
            _status_all()


@cli.command()
def install(
    tool_name: Annotated[str | None, typer.Argument(help="Tool name (default: all)")] = None,
    skip: Annotated[
        list[str] | None,
        typer.Option("--skip", help="Skip these tools (repeatable)."),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json", help="JSON output")] = False,
    interactive: Annotated[bool, typer.Option("--interactive", "-i", help="Prompt for missing env vars")] = False,
) -> None:
    """Install or update tools."""
    if tool_name:
        tool = _find_tool(tool_name)
        if not tool:
            typer.echo(f"Unknown tool: {tool_name}. Available: {', '.join(TOOL_NAMES)}", err=True)
            raise typer.Exit(code=1)
        result = _install_one(tool, dry_run=False, interactive=interactive)
        if json_output:
            typer.echo(json.dumps(result.to_dict()))
        else:
            _render_install_result(result)
        if result.status == "failed":
            raise typer.Exit(code=1)
    else:
        if json_output:
            results = install_all(skip=tuple(skip or ()), interactive=interactive)
            counts = {"installed": 0, "up-to-date": 0, "skipped": 0, "failed": 0}
            for r in results:
                counts[r.status] = counts.get(r.status, 0) + 1
            typer.echo(json.dumps({"results": [r.to_dict() for r in results], "summary": counts}))
        else:
            results = _install_pretty(skip=tuple(skip or ()), interactive=interactive)
            counts = {"installed": 0, "up-to-date": 0, "skipped": 0, "failed": 0}
            for r in results:
                if r.name == "__abort__":
                    continue
                counts[r.status] = counts.get(r.status, 0) + 1
            _section_header(SECTION_SUMMARY)
            summary = ", ".join(f"{v} {k}" for k, v in counts.items() if v)
            typer.echo(f"  {summary or 'no tools processed'}")
        if counts["failed"]:
            raise typer.Exit(code=1)


if __name__ == "__main__":
    cli()
